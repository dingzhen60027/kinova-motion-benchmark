NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 E  R55     
 L  R56     
 L  R57     
 L  R58     
 L  R59     
 L  R60     
 L  R61     
 L  R62     
 L  R63     
 L  R64     
 L  R65     
 L  R66     
 L  R67     
 L  R68     
 L  R69     
 L  R70     
 L  R71     
 L  R72     
 L  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R56       -3.0999999046325684e+00
    phi[0,1]  R57       -3.0999999046325684e+00
    phi[0,1]  R58       -2.2400000095367432e+00
    phi[0,1]  R59       -2.2400000095367432e+00
    phi[0,1]  R60       -3.0999999046325684e+00
    phi[0,1]  R61       -3.0999999046325684e+00
    phi[0,1]  R62       -2.5699999332427979e+00
    phi[0,1]  R63       -2.5699999332427979e+00
    phi[0,1]  R64       -3.0999999046325684e+00
    phi[0,1]  R65       -3.0999999046325684e+00
    phi[0,1]  R66       -2.0899999141693115e+00
    phi[0,1]  R67       -2.0899999141693115e+00
    phi[0,1]  R68       -3.0999999046325684e+00
    phi[0,1]  R69       -3.0999999046325684e+00
    phi[0,1]  R70       -3.0899229645729065e-01
    phi[0,1]  R71       3.8263458013534546e-01
    phi[0,1]  R72       1.0281485319137573e-01
    phi[0,1]  R73       2.5092551112174988e-01
    phi[0,1]  R74       -2.1233309805393219e-01
    phi[0,1]  R75       -4.6634262800216675e-01
    phi[0,1]  R76       8.2335025072097778e-01
    phi[0,1]  R77       -1.8395014107227325e-02
    phi[0,1]  R78       -1.7214520275592804e-01
    phi[0,1]  R79       1.0827137231826782e+00
    phi[0,1]  R80       -1.2471863031387329e+00
    phi[0,1]  R81       -1.4683265686035156e+00
    phi[0,1]  R82       -1.6501139402389526e+00
    phi[0,1]  R83       -1.8043681383132935e+00
    phi[0,1]  R84       -1.3986213505268097e-01
    phi[0,1]  R85       -0.880050003528595
    phi[0,1]  R86       -2.1837350726127625e-01
    phi[0,1]  R87       -1.2354835271835327e+00
    phi[0,1]  R88       -7.1926474571228027e-01
    phi[0,1]  R89       1.7339248955249786e-01
    phi[0,1]  R90       -1.5486200153827667e-01
    phi[0,1]  R91       -7.3945659399032593e-01
    phi[0,1]  R92       3.8078850507736206e-01
    phi[0,1]  R93       2.6897782087326050e-01
    phi[0,1]  R94       -0.475409597158432
    phi[0,1]  R95       0.447275310754776
    phi[0,1]  R96       6.9797587394714355e-01
    phi[0,1]  R97       6.6721779108047485e-01
    phi[0,1]  R98       4.0925610065460205e-01
    phi[0,1]  R99       -6.1293929815292358e-01
    phi[0,1]  R100      -1.3899784088134766e+00
    phi[0,1]  R101      -6.4538371562957764e-01
    phi[0,1]  R102      -2.6561182737350464e-01
    phi[0,1]  R103      3.6727637052536011e-01
    phi[0,1]  R104      -2.5555620193481445e+00
    phi[0,1]  R105      -1.1934937238693237e+00
    phi[0,1]  R106      -2.1112194061279297e+00
    phi[0,1]  R107      -2.1435065269470215e+00
    phi[0,1]  R108      -3.3133497238159180e+00
    phi[0,1]  R109      -3.3218452930450439e+00
    phi[0,1]  R110      -1.8037002086639404e+00
    phi[0,1]  R111      -1.3226397037506104e+00
    phi[0,1]  R112      -1.6005049943923950e+00
    phi[0,1]  R113      -1.2533605098724365e+00
    phi[0,1]  R114      -1.2455857992172241e+00
    phi[0,1]  R115      -1.0587503910064697e+00
    phi[0,1]  R116      -1.3580213785171509e+00
    phi[0,1]  R117      -1.7613842487335205e+00
    phi[0,1]  R118      1.0010520219802856e+00
    phi[0,1]  R119      7.4042063951492310e-01
    phi[0,1]  R120      1.0317177772521973e+00
    phi[0,1]  R121      -2.0787246525287628e-01
    phi[0,1]  R122      1.0802415758371353e-01
    phi[0,1]  R123      1.1002836376428604e-01
    phi[0,1]  R124      1.3066293299198151e-01
    phi[0,1]  R125      6.6278654336929321e-01
    phi[0,1]  R126      1.0316032171249390e+00
    phi[0,1]  R127      1.0527113676071167e+00
    phi[0,1]  R128      9.6436882019042969e-01
    phi[0,1]  R129      0.942690372467041
    phi[0,1]  R130      -1.5611532926559448e+00
    phi[0,1]  R131      -1.9499567747116089e+00
    phi[0,1]  R132      -2.0060327053070068e+00
    phi[0,1]  R133      -1.8601968288421631e+00
    phi[0,1]  R134      -1.6125484704971313e+00
    phi[0,1]  R135      -1.6199873685836792e+00
    phi[0,1]  R136      -1.0704367160797119e+00
    phi[0,1]  R137      -2.6994326710700989e-01
    phi[0,1]  R138      -9.1971337795257568e-01
    phi[0,1]  R139      -9.0835738182067871e-01
    phi[0,1]  R140      -1.2064650058746338e+00
    phi[0,1]  R141      -1.0584374666213989e+00
    phi[0,1]  R142      -7.5192493200302124e-01
    phi[0,1]  R143      -3.0816310644149780e-01
    phi[0,1]  R144      -1.0907855033874512e+00
    phi[0,1]  R145      -9.1714465618133545e-01
    phi[0,1]  R146      4.6552099287509918e-02
    phi[0,1]  R147      -1.8066576123237610e-01
    phi[0,1]  R148      -4.0153422951698303e-01
    phi[0,1]  R149      -1.1737054586410522e+00
    phi[0,1]  R150      -1.5332914590835571e+00
    phi[0,1]  R151      -2.0016133785247803e+00
    phi[0,1]  R152      -1.2348955869674683e+00
    phi[0,1]  R153      -4.6866655349731445e-02
    phi[0,1]  R154      -1.0846086740493774e+00
    phi[0,1]  R155      -1.0385133028030396e+00
    phi[0,1]  R156      3.3063229918479919e-01
    phi[0,1]  R157      -5.6197237968444824e-01
    phi[0,1]  R158      1.8063329160213470e-01
    phi[0,1]  R159      0.744917094707489
    phi[0,1]  R160      -1.1982963085174561e+00
    phi[0,1]  R161      8.2398509979248047e-01
    phi[0,1]  R162      1.0782244205474854e+00
    phi[0,1]  R163      1.0274049043655396e+00
    phi[0,1]  R164      9.5594388246536255e-01
    phi[0,1]  R165      5.4100722074508667e-01
    phi[0,1]  R166      1.3617775440216064e+00
    phi[0,1]  R167      1.0227026939392090e+00
    phi[0,1]  R168      6.6641956567764282e-01
    phi[0,1]  R169      1.1064631938934326e+00
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R170      -3.0999999046325684e+00
    phi[1,0]  R171      -3.0999999046325684e+00
    phi[1,0]  R172      -2.2400000095367432e+00
    phi[1,0]  R173      -2.2400000095367432e+00
    phi[1,0]  R174      -3.0999999046325684e+00
    phi[1,0]  R175      -3.0999999046325684e+00
    phi[1,0]  R176      -2.5699999332427979e+00
    phi[1,0]  R177      -2.5699999332427979e+00
    phi[1,0]  R178      -3.0999999046325684e+00
    phi[1,0]  R179      -3.0999999046325684e+00
    phi[1,0]  R180      -2.0899999141693115e+00
    phi[1,0]  R181      -2.0899999141693115e+00
    phi[1,0]  R182      -3.0999999046325684e+00
    phi[1,0]  R183      -3.0999999046325684e+00
    phi[1,0]  R184      -1.8037002086639404e+00
    phi[1,0]  R185      -1.3226397037506104e+00
    phi[1,0]  R186      -1.6005049943923950e+00
    phi[1,0]  R187      -1.2533605098724365e+00
    phi[1,0]  R188      -1.2455857992172241e+00
    phi[1,0]  R189      -1.0587503910064697e+00
    phi[1,0]  R190      -1.3580213785171509e+00
    phi[1,0]  R191      -1.7613842487335205e+00
    phi[1,0]  R192      1.0010520219802856e+00
    phi[1,0]  R193      7.4042063951492310e-01
    phi[1,0]  R194      1.0317177772521973e+00
    phi[1,0]  R195      -2.0787246525287628e-01
    phi[1,0]  R196      1.0802415758371353e-01
    phi[1,0]  R197      1.1002836376428604e-01
    phi[1,0]  R198      1.3066293299198151e-01
    phi[1,0]  R199      6.6278654336929321e-01
    phi[1,0]  R200      1.0316032171249390e+00
    phi[1,0]  R201      1.0527113676071167e+00
    phi[1,0]  R202      9.6436882019042969e-01
    phi[1,0]  R203      0.942690372467041
    phi[1,0]  R204      -1.5611532926559448e+00
    phi[1,0]  R205      -1.9499567747116089e+00
    phi[1,0]  R206      -2.0060327053070068e+00
    phi[1,0]  R207      -1.8601968288421631e+00
    phi[1,0]  R208      -1.6125484704971313e+00
    phi[1,0]  R209      -1.6199873685836792e+00
    phi[1,0]  R210      -1.0704367160797119e+00
    phi[1,0]  R211      -2.6994326710700989e-01
    phi[1,0]  R212      -9.1971337795257568e-01
    phi[1,0]  R213      -9.0835738182067871e-01
    phi[1,0]  R214      -1.2064650058746338e+00
    phi[1,0]  R215      -1.0584374666213989e+00
    phi[1,0]  R216      -7.5192493200302124e-01
    phi[1,0]  R217      -3.0816310644149780e-01
    phi[1,0]  R218      -1.0907855033874512e+00
    phi[1,0]  R219      -9.1714465618133545e-01
    phi[1,0]  R220      4.6552099287509918e-02
    phi[1,0]  R221      -1.8066576123237610e-01
    phi[1,0]  R222      -4.0153422951698303e-01
    phi[1,0]  R223      -1.1737054586410522e+00
    phi[1,0]  R224      -1.5332914590835571e+00
    phi[1,0]  R225      -2.0016133785247803e+00
    phi[1,0]  R226      -1.2348955869674683e+00
    phi[1,0]  R227      -4.6866655349731445e-02
    phi[1,0]  R228      -1.0846086740493774e+00
    phi[1,0]  R229      -1.0385133028030396e+00
    phi[1,0]  R230      3.3063229918479919e-01
    phi[1,0]  R231      -5.6197237968444824e-01
    phi[1,0]  R232      1.8063329160213470e-01
    phi[1,0]  R233      0.744917094707489
    phi[1,0]  R234      -1.1982963085174561e+00
    phi[1,0]  R235      8.2398509979248047e-01
    phi[1,0]  R236      1.0782244205474854e+00
    phi[1,0]  R237      1.0274049043655396e+00
    phi[1,0]  R238      9.5594388246536255e-01
    phi[1,0]  R239      5.4100722074508667e-01
    phi[1,0]  R240      1.3617775440216064e+00
    phi[1,0]  R241      1.0227026939392090e+00
    phi[1,0]  R242      6.6641956567764282e-01
    phi[1,0]  R243      1.1064631938934326e+00
    phi[1,0]  R244      -3.0899229645729065e-01
    phi[1,0]  R245      3.8263458013534546e-01
    phi[1,0]  R246      1.0281485319137573e-01
    phi[1,0]  R247      2.5092551112174988e-01
    phi[1,0]  R248      -2.1233309805393219e-01
    phi[1,0]  R249      -4.6634262800216675e-01
    phi[1,0]  R250      8.2335025072097778e-01
    phi[1,0]  R251      -1.8395014107227325e-02
    phi[1,0]  R252      -1.7214520275592804e-01
    phi[1,0]  R253      1.0827137231826782e+00
    phi[1,0]  R254      -1.2471863031387329e+00
    phi[1,0]  R255      -1.4683265686035156e+00
    phi[1,0]  R256      -1.6501139402389526e+00
    phi[1,0]  R257      -1.8043681383132935e+00
    phi[1,0]  R258      -1.3986213505268097e-01
    phi[1,0]  R259      -0.880050003528595
    phi[1,0]  R260      -2.1837350726127625e-01
    phi[1,0]  R261      -1.2354835271835327e+00
    phi[1,0]  R262      -7.1926474571228027e-01
    phi[1,0]  R263      1.7339248955249786e-01
    phi[1,0]  R264      -1.5486200153827667e-01
    phi[1,0]  R265      -7.3945659399032593e-01
    phi[1,0]  R266      3.8078850507736206e-01
    phi[1,0]  R267      2.6897782087326050e-01
    phi[1,0]  R268      -0.475409597158432
    phi[1,0]  R269      0.447275310754776
    phi[1,0]  R270      6.9797587394714355e-01
    phi[1,0]  R271      6.6721779108047485e-01
    phi[1,0]  R272      4.0925610065460205e-01
    phi[1,0]  R273      -6.1293929815292358e-01
    phi[1,0]  R274      -1.3899784088134766e+00
    phi[1,0]  R275      -6.4538371562957764e-01
    phi[1,0]  R276      -2.6561182737350464e-01
    phi[1,0]  R277      3.6727637052536011e-01
    phi[1,0]  R278      -2.5555620193481445e+00
    phi[1,0]  R279      -1.1934937238693237e+00
    phi[1,0]  R280      -2.1112194061279297e+00
    phi[1,0]  R281      -2.1435065269470215e+00
    phi[1,0]  R282      -3.3133497238159180e+00
    phi[1,0]  R283      -3.3218452930450439e+00
    phi[0,3]  R0        1
    phi[0,3]  R1        1
    phi[0,3]  R27       -1
    phi[0,3]  R284      -3.0999999046325684e+00
    phi[0,3]  R285      -3.0999999046325684e+00
    phi[0,3]  R286      -2.2400000095367432e+00
    phi[0,3]  R287      -2.2400000095367432e+00
    phi[0,3]  R288      -3.0999999046325684e+00
    phi[0,3]  R289      -3.0999999046325684e+00
    phi[0,3]  R290      -2.5699999332427979e+00
    phi[0,3]  R291      -2.5699999332427979e+00
    phi[0,3]  R292      -3.0999999046325684e+00
    phi[0,3]  R293      -3.0999999046325684e+00
    phi[0,3]  R294      -2.0899999141693115e+00
    phi[0,3]  R295      -2.0899999141693115e+00
    phi[0,3]  R296      -3.0999999046325684e+00
    phi[0,3]  R297      -3.0999999046325684e+00
    phi[0,3]  R298      -3.0899229645729065e-01
    phi[0,3]  R299      3.8263458013534546e-01
    phi[0,3]  R300      1.0281485319137573e-01
    phi[0,3]  R301      2.5092551112174988e-01
    phi[0,3]  R302      -2.1233309805393219e-01
    phi[0,3]  R303      -4.6634262800216675e-01
    phi[0,3]  R304      8.2335025072097778e-01
    phi[0,3]  R305      -1.8395014107227325e-02
    phi[0,3]  R306      -1.7214520275592804e-01
    phi[0,3]  R307      1.0827137231826782e+00
    phi[0,3]  R308      -1.2471863031387329e+00
    phi[0,3]  R309      -1.4683265686035156e+00
    phi[0,3]  R310      -1.6501139402389526e+00
    phi[0,3]  R311      -1.8043681383132935e+00
    phi[0,3]  R312      -1.3986213505268097e-01
    phi[0,3]  R313      -0.880050003528595
    phi[0,3]  R314      -2.1837350726127625e-01
    phi[0,3]  R315      -1.2354835271835327e+00
    phi[0,3]  R316      -7.1926474571228027e-01
    phi[0,3]  R317      1.7339248955249786e-01
    phi[0,3]  R318      -1.5486200153827667e-01
    phi[0,3]  R319      -7.3945659399032593e-01
    phi[0,3]  R320      3.8078850507736206e-01
    phi[0,3]  R321      2.6897782087326050e-01
    phi[0,3]  R322      -0.475409597158432
    phi[0,3]  R323      0.447275310754776
    phi[0,3]  R324      6.9797587394714355e-01
    phi[0,3]  R325      6.6721779108047485e-01
    phi[0,3]  R326      4.0925610065460205e-01
    phi[0,3]  R327      -6.1293929815292358e-01
    phi[0,3]  R328      -1.3899784088134766e+00
    phi[0,3]  R329      -6.4538371562957764e-01
    phi[0,3]  R330      -2.6561182737350464e-01
    phi[0,3]  R331      3.6727637052536011e-01
    phi[0,3]  R332      -2.5555620193481445e+00
    phi[0,3]  R333      -1.1934937238693237e+00
    phi[0,3]  R334      -2.1112194061279297e+00
    phi[0,3]  R335      -2.1435065269470215e+00
    phi[0,3]  R336      -3.3133497238159180e+00
    phi[0,3]  R337      -3.3218452930450439e+00
    phi[0,3]  R338      9.6314847469329834e-01
    phi[0,3]  R339      0.960550844669342
    phi[0,3]  R340      1.3743402957916260e+00
    phi[0,3]  R341      1.1893818378448486e+00
    phi[0,3]  R342      1.3840620517730713e+00
    phi[0,3]  R343      8.8364201784133911e-01
    phi[0,3]  R344      1.4328553676605225e+00
    phi[0,3]  R345      7.8162901103496552e-02
    phi[0,3]  R346      1.7502503395080566e+00
    phi[0,3]  R347      9.7523730993270874e-01
    phi[0,3]  R348      -1.8237093687057495e+00
    phi[0,3]  R349      -1.8392630815505981e+00
    phi[0,3]  R350      -1.8007401227951050e+00
    phi[0,3]  R351      -2.5955519676208496e+00
    phi[0,3]  R352      -3.1359648704528809e-01
    phi[0,3]  R353      -1.0644038915634155e+00
    phi[0,3]  R354      -1.8577504903078079e-02
    phi[0,3]  R355      -2.6399847865104675e-01
    phi[0,3]  R356      -1.3170360326766968e+00
    phi[0,3]  R357      -1.5790328979492188e+00
    phi[0,3]  R358      -2.3304946422576904e+00
    phi[0,3]  R359      -3.5896944999694824e+00
    phi[0,3]  R360      5.0934958457946777e-01
    phi[0,3]  R361      -1.0928772389888763e-01
    phi[0,3]  R362      -2.7448687553405762e+00
    phi[0,3]  R363      -2.7660226821899414e+00
    phi[0,3]  R364      1.8788412809371948e+00
    phi[0,3]  R365      -8.9053803682327271e-01
    phi[0,3]  R366      1.0950303077697754e+00
    phi[0,3]  R367      7.2714394330978394e-01
    phi[0,3]  R368      -1.4358063936233521e+00
    phi[0,3]  R369      -1.7135733366012573e+00
    phi[0,3]  R370      -7.7095526456832886e-01
    phi[0,3]  R371      -2.0472218990325928e+00
    phi[0,3]  R372      -1.3490383625030518e+00
    phi[0,3]  R373      -8.2180166244506836e-01
    phi[0,3]  R374      -2.2112317085266113e+00
    phi[0,3]  R375      1.1089618504047394e-01
    phi[0,3]  R376      3.0463927984237671e-01
    phi[0,3]  R377      1.2539277076721191e+00
    phi[0,3]  R378      -1.6471302509307861e+00
    phi[0,3]  R379      -2.0244398117065430e+00
    phi[0,3]  R380      -2.8703789710998535e+00
    phi[0,3]  R381      -2.9911041259765625e+00
    phi[0,3]  R382      3.2949250936508179e-01
    phi[0,3]  R383      4.4693106412887573e-01
    phi[0,3]  R384      -3.7081069946289062e+00
    phi[0,3]  R385      -9.6719181537628174e-01
    phi[0,3]  R386      5.2185666561126709e-01
    phi[0,3]  R387      -2.1560356616973877e+00
    phi[0,3]  R388      -1.0176507234573364e+00
    phi[0,3]  R389      -2.5792727470397949e+00
    phi[0,3]  R390      -3.1357989311218262e+00
    phi[0,3]  R391      -1.2313365936279297e+00
    phi[0,3]  R392      -2.4998769760131836e+00
    phi[0,3]  R393      6.8935108184814453e-01
    phi[0,3]  R394      1.6830998659133911e+00
    phi[0,3]  R395      8.9807915687561035e-01
    phi[0,3]  R396      -1.7425943613052368e+00
    phi[0,3]  R397      3.5300529003143311e-01
    phi[3,0]  R0        -1
    phi[3,0]  R27       1
    phi[3,0]  R28       1
    phi[3,0]  R398      -3.0999999046325684e+00
    phi[3,0]  R399      -3.0999999046325684e+00
    phi[3,0]  R400      -2.2400000095367432e+00
    phi[3,0]  R401      -2.2400000095367432e+00
    phi[3,0]  R402      -3.0999999046325684e+00
    phi[3,0]  R403      -3.0999999046325684e+00
    phi[3,0]  R404      -2.5699999332427979e+00
    phi[3,0]  R405      -2.5699999332427979e+00
    phi[3,0]  R406      -3.0999999046325684e+00
    phi[3,0]  R407      -3.0999999046325684e+00
    phi[3,0]  R408      -2.0899999141693115e+00
    phi[3,0]  R409      -2.0899999141693115e+00
    phi[3,0]  R410      -3.0999999046325684e+00
    phi[3,0]  R411      -3.0999999046325684e+00
    phi[3,0]  R412      9.6314847469329834e-01
    phi[3,0]  R413      0.960550844669342
    phi[3,0]  R414      1.3743402957916260e+00
    phi[3,0]  R415      1.1893818378448486e+00
    phi[3,0]  R416      1.3840620517730713e+00
    phi[3,0]  R417      8.8364201784133911e-01
    phi[3,0]  R418      1.4328553676605225e+00
    phi[3,0]  R419      7.8162901103496552e-02
    phi[3,0]  R420      1.7502503395080566e+00
    phi[3,0]  R421      9.7523730993270874e-01
    phi[3,0]  R422      -1.8237093687057495e+00
    phi[3,0]  R423      -1.8392630815505981e+00
    phi[3,0]  R424      -1.8007401227951050e+00
    phi[3,0]  R425      -2.5955519676208496e+00
    phi[3,0]  R426      -3.1359648704528809e-01
    phi[3,0]  R427      -1.0644038915634155e+00
    phi[3,0]  R428      -1.8577504903078079e-02
    phi[3,0]  R429      -2.6399847865104675e-01
    phi[3,0]  R430      -1.3170360326766968e+00
    phi[3,0]  R431      -1.5790328979492188e+00
    phi[3,0]  R432      -2.3304946422576904e+00
    phi[3,0]  R433      -3.5896944999694824e+00
    phi[3,0]  R434      5.0934958457946777e-01
    phi[3,0]  R435      -1.0928772389888763e-01
    phi[3,0]  R436      -2.7448687553405762e+00
    phi[3,0]  R437      -2.7660226821899414e+00
    phi[3,0]  R438      1.8788412809371948e+00
    phi[3,0]  R439      -8.9053803682327271e-01
    phi[3,0]  R440      1.0950303077697754e+00
    phi[3,0]  R441      7.2714394330978394e-01
    phi[3,0]  R442      -1.4358063936233521e+00
    phi[3,0]  R443      -1.7135733366012573e+00
    phi[3,0]  R444      -7.7095526456832886e-01
    phi[3,0]  R445      -2.0472218990325928e+00
    phi[3,0]  R446      -1.3490383625030518e+00
    phi[3,0]  R447      -8.2180166244506836e-01
    phi[3,0]  R448      -2.2112317085266113e+00
    phi[3,0]  R449      1.1089618504047394e-01
    phi[3,0]  R450      3.0463927984237671e-01
    phi[3,0]  R451      1.2539277076721191e+00
    phi[3,0]  R452      -1.6471302509307861e+00
    phi[3,0]  R453      -2.0244398117065430e+00
    phi[3,0]  R454      -2.8703789710998535e+00
    phi[3,0]  R455      -2.9911041259765625e+00
    phi[3,0]  R456      3.2949250936508179e-01
    phi[3,0]  R457      4.4693106412887573e-01
    phi[3,0]  R458      -3.7081069946289062e+00
    phi[3,0]  R459      -9.6719181537628174e-01
    phi[3,0]  R460      5.2185666561126709e-01
    phi[3,0]  R461      -2.1560356616973877e+00
    phi[3,0]  R462      -1.0176507234573364e+00
    phi[3,0]  R463      -2.5792727470397949e+00
    phi[3,0]  R464      -3.1357989311218262e+00
    phi[3,0]  R465      -1.2313365936279297e+00
    phi[3,0]  R466      -2.4998769760131836e+00
    phi[3,0]  R467      6.8935108184814453e-01
    phi[3,0]  R468      1.6830998659133911e+00
    phi[3,0]  R469      8.9807915687561035e-01
    phi[3,0]  R470      -1.7425943613052368e+00
    phi[3,0]  R471      3.5300529003143311e-01
    phi[3,0]  R472      -3.0899229645729065e-01
    phi[3,0]  R473      3.8263458013534546e-01
    phi[3,0]  R474      1.0281485319137573e-01
    phi[3,0]  R475      2.5092551112174988e-01
    phi[3,0]  R476      -2.1233309805393219e-01
    phi[3,0]  R477      -4.6634262800216675e-01
    phi[3,0]  R478      8.2335025072097778e-01
    phi[3,0]  R479      -1.8395014107227325e-02
    phi[3,0]  R480      -1.7214520275592804e-01
    phi[3,0]  R481      1.0827137231826782e+00
    phi[3,0]  R482      -1.2471863031387329e+00
    phi[3,0]  R483      -1.4683265686035156e+00
    phi[3,0]  R484      -1.6501139402389526e+00
    phi[3,0]  R485      -1.8043681383132935e+00
    phi[3,0]  R486      -1.3986213505268097e-01
    phi[3,0]  R487      -0.880050003528595
    phi[3,0]  R488      -2.1837350726127625e-01
    phi[3,0]  R489      -1.2354835271835327e+00
    phi[3,0]  R490      -7.1926474571228027e-01
    phi[3,0]  R491      1.7339248955249786e-01
    phi[3,0]  R492      -1.5486200153827667e-01
    phi[3,0]  R493      -7.3945659399032593e-01
    phi[3,0]  R494      3.8078850507736206e-01
    phi[3,0]  R495      2.6897782087326050e-01
    phi[3,0]  R496      -0.475409597158432
    phi[3,0]  R497      0.447275310754776
    phi[3,0]  R498      6.9797587394714355e-01
    phi[3,0]  R499      6.6721779108047485e-01
    phi[3,0]  R500      4.0925610065460205e-01
    phi[3,0]  R501      -6.1293929815292358e-01
    phi[3,0]  R502      -1.3899784088134766e+00
    phi[3,0]  R503      -6.4538371562957764e-01
    phi[3,0]  R504      -2.6561182737350464e-01
    phi[3,0]  R505      3.6727637052536011e-01
    phi[3,0]  R506      -2.5555620193481445e+00
    phi[3,0]  R507      -1.1934937238693237e+00
    phi[3,0]  R508      -2.1112194061279297e+00
    phi[3,0]  R509      -2.1435065269470215e+00
    phi[3,0]  R510      -3.3133497238159180e+00
    phi[3,0]  R511      -3.3218452930450439e+00
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R512      -3.0999999046325684e+00
    phi[0,4]  R513      -3.0999999046325684e+00
    phi[0,4]  R514      -2.2400000095367432e+00
    phi[0,4]  R515      -2.2400000095367432e+00
    phi[0,4]  R516      -3.0999999046325684e+00
    phi[0,4]  R517      -3.0999999046325684e+00
    phi[0,4]  R518      -2.5699999332427979e+00
    phi[0,4]  R519      -2.5699999332427979e+00
    phi[0,4]  R520      -3.0999999046325684e+00
    phi[0,4]  R521      -3.0999999046325684e+00
    phi[0,4]  R522      -2.0899999141693115e+00
    phi[0,4]  R523      -2.0899999141693115e+00
    phi[0,4]  R524      -3.0999999046325684e+00
    phi[0,4]  R525      -3.0999999046325684e+00
    phi[0,4]  R526      -3.0899229645729065e-01
    phi[0,4]  R527      3.8263458013534546e-01
    phi[0,4]  R528      1.0281485319137573e-01
    phi[0,4]  R529      2.5092551112174988e-01
    phi[0,4]  R530      -2.1233309805393219e-01
    phi[0,4]  R531      -4.6634262800216675e-01
    phi[0,4]  R532      8.2335025072097778e-01
    phi[0,4]  R533      -1.8395014107227325e-02
    phi[0,4]  R534      -1.7214520275592804e-01
    phi[0,4]  R535      1.0827137231826782e+00
    phi[0,4]  R536      -1.2471863031387329e+00
    phi[0,4]  R537      -1.4683265686035156e+00
    phi[0,4]  R538      -1.6501139402389526e+00
    phi[0,4]  R539      -1.8043681383132935e+00
    phi[0,4]  R540      -1.3986213505268097e-01
    phi[0,4]  R541      -0.880050003528595
    phi[0,4]  R542      -2.1837350726127625e-01
    phi[0,4]  R543      -1.2354835271835327e+00
    phi[0,4]  R544      -7.1926474571228027e-01
    phi[0,4]  R545      1.7339248955249786e-01
    phi[0,4]  R546      -1.5486200153827667e-01
    phi[0,4]  R547      -7.3945659399032593e-01
    phi[0,4]  R548      3.8078850507736206e-01
    phi[0,4]  R549      2.6897782087326050e-01
    phi[0,4]  R550      -0.475409597158432
    phi[0,4]  R551      0.447275310754776
    phi[0,4]  R552      6.9797587394714355e-01
    phi[0,4]  R553      6.6721779108047485e-01
    phi[0,4]  R554      4.0925610065460205e-01
    phi[0,4]  R555      -6.1293929815292358e-01
    phi[0,4]  R556      -1.3899784088134766e+00
    phi[0,4]  R557      -6.4538371562957764e-01
    phi[0,4]  R558      -2.6561182737350464e-01
    phi[0,4]  R559      3.6727637052536011e-01
    phi[0,4]  R560      -2.5555620193481445e+00
    phi[0,4]  R561      -1.1934937238693237e+00
    phi[0,4]  R562      -2.1112194061279297e+00
    phi[0,4]  R563      -2.1435065269470215e+00
    phi[0,4]  R564      -3.3133497238159180e+00
    phi[0,4]  R565      -3.3218452930450439e+00
    phi[0,4]  R566      -1.1349966526031494e+00
    phi[0,4]  R567      -1.1427879333496094e+00
    phi[0,4]  R568      -7.2888344526290894e-01
    phi[0,4]  R569      -7.4036091566085815e-01
    phi[0,4]  R570      -9.2340862751007080e-01
    phi[0,4]  R571      -4.0682223439216614e-01
    phi[0,4]  R572      -6.4768642187118530e-01
    phi[0,4]  R573      -1.8927834033966064e+00
    phi[0,4]  R574      -4.7784546017646790e-01
    phi[0,4]  R575      -9.3285769224166870e-01
    phi[0,4]  R576      1.1380215883255005e+00
    phi[0,4]  R577      6.9943785667419434e-01
    phi[0,4]  R578      -8.2722121477127075e-01
    phi[0,4]  R579      7.4775010347366333e-01
    phi[0,4]  R580      1.4682742357254028e+00
    phi[0,4]  R581      1.5242244005203247e+00
    phi[0,4]  R582      1.4790067672729492e+00
    phi[0,4]  R583      -5.5802255868911743e-01
    phi[0,4]  R584      8.3793580532073975e-01
    phi[0,4]  R585      2.0132152736186981e-01
    phi[0,4]  R586      -1.9470099210739136e+00
    phi[0,4]  R587      -1.3906112909317017e+00
    phi[0,4]  R588      8.8488626480102539e-01
    phi[0,4]  R589      -1.9665704667568207e-01
    phi[0,4]  R590      3.6203145980834961e-01
    phi[0,4]  R591      -1.7883622646331787e+00
    phi[0,4]  R592      -8.2152163982391357e-01
    phi[0,4]  R593      1.5952751040458679e-01
    phi[0,4]  R594      -1.2830153107643127e-01
    phi[0,4]  R595      -0.751623272895813
    phi[0,4]  R596      -1.3494781255722046e+00
    phi[0,4]  R597      -1.84017014503479
    phi[0,4]  R598      3.6190178990364075e-01
    phi[0,4]  R599      2.6068103313446045e-01
    phi[0,4]  R600      -5.7612460851669312e-01
    phi[0,4]  R601      -9.3409514427185059e-01
    phi[0,4]  R602      6.1517262458801270e-01
    phi[0,4]  R603      3.9461475610733032e-01
    phi[0,4]  R604      -9.8060362040996552e-02
    phi[0,4]  R605      1.4719067513942719e-01
    phi[0,4]  R606      4.5779719948768616e-01
    phi[0,4]  R607      -2.0165763795375824e-01
    phi[0,4]  R608      2.3757264018058777e-01
    phi[0,4]  R609      4.3969199061393738e-01
    phi[0,4]  R610      -0.282153844833374
    phi[0,4]  R611      -1.4814805984497070e+00
    phi[0,4]  R612      -7.8956365585327148e-01
    phi[0,4]  R613      1.1392768621444702e+00
    phi[0,4]  R614      1.0514466762542725e+00
    phi[0,4]  R615      1.1114830970764160e+00
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R616      -3.0999999046325684e+00
    phi[4,0]  R617      -3.0999999046325684e+00
    phi[4,0]  R618      -2.2400000095367432e+00
    phi[4,0]  R619      -2.2400000095367432e+00
    phi[4,0]  R620      -3.0999999046325684e+00
    phi[4,0]  R621      -3.0999999046325684e+00
    phi[4,0]  R622      -2.5699999332427979e+00
    phi[4,0]  R623      -2.5699999332427979e+00
    phi[4,0]  R624      -3.0999999046325684e+00
    phi[4,0]  R625      -3.0999999046325684e+00
    phi[4,0]  R626      -2.0899999141693115e+00
    phi[4,0]  R627      -2.0899999141693115e+00
    phi[4,0]  R628      -3.0999999046325684e+00
    phi[4,0]  R629      -3.0999999046325684e+00
    phi[4,0]  R630      -1.1349966526031494e+00
    phi[4,0]  R631      -1.1427879333496094e+00
    phi[4,0]  R632      -7.2888344526290894e-01
    phi[4,0]  R633      -7.4036091566085815e-01
    phi[4,0]  R634      -9.2340862751007080e-01
    phi[4,0]  R635      -4.0682223439216614e-01
    phi[4,0]  R636      -6.4768642187118530e-01
    phi[4,0]  R637      -1.8927834033966064e+00
    phi[4,0]  R638      -4.7784546017646790e-01
    phi[4,0]  R639      -9.3285769224166870e-01
    phi[4,0]  R640      1.1380215883255005e+00
    phi[4,0]  R641      6.9943785667419434e-01
    phi[4,0]  R642      -8.2722121477127075e-01
    phi[4,0]  R643      7.4775010347366333e-01
    phi[4,0]  R644      1.4682742357254028e+00
    phi[4,0]  R645      1.5242244005203247e+00
    phi[4,0]  R646      1.4790067672729492e+00
    phi[4,0]  R647      -5.5802255868911743e-01
    phi[4,0]  R648      8.3793580532073975e-01
    phi[4,0]  R649      2.0132152736186981e-01
    phi[4,0]  R650      -1.9470099210739136e+00
    phi[4,0]  R651      -1.3906112909317017e+00
    phi[4,0]  R652      8.8488626480102539e-01
    phi[4,0]  R653      -1.9665704667568207e-01
    phi[4,0]  R654      3.6203145980834961e-01
    phi[4,0]  R655      -1.7883622646331787e+00
    phi[4,0]  R656      -8.2152163982391357e-01
    phi[4,0]  R657      1.5952751040458679e-01
    phi[4,0]  R658      -1.2830153107643127e-01
    phi[4,0]  R659      -0.751623272895813
    phi[4,0]  R660      -1.3494781255722046e+00
    phi[4,0]  R661      -1.84017014503479
    phi[4,0]  R662      3.6190178990364075e-01
    phi[4,0]  R663      2.6068103313446045e-01
    phi[4,0]  R664      -5.7612460851669312e-01
    phi[4,0]  R665      -9.3409514427185059e-01
    phi[4,0]  R666      6.1517262458801270e-01
    phi[4,0]  R667      3.9461475610733032e-01
    phi[4,0]  R668      -9.8060362040996552e-02
    phi[4,0]  R669      1.4719067513942719e-01
    phi[4,0]  R670      4.5779719948768616e-01
    phi[4,0]  R671      -2.0165763795375824e-01
    phi[4,0]  R672      2.3757264018058777e-01
    phi[4,0]  R673      4.3969199061393738e-01
    phi[4,0]  R674      -0.282153844833374
    phi[4,0]  R675      -1.4814805984497070e+00
    phi[4,0]  R676      -7.8956365585327148e-01
    phi[4,0]  R677      1.1392768621444702e+00
    phi[4,0]  R678      1.0514466762542725e+00
    phi[4,0]  R679      1.1114830970764160e+00
    phi[4,0]  R680      -3.0899229645729065e-01
    phi[4,0]  R681      3.8263458013534546e-01
    phi[4,0]  R682      1.0281485319137573e-01
    phi[4,0]  R683      2.5092551112174988e-01
    phi[4,0]  R684      -2.1233309805393219e-01
    phi[4,0]  R685      -4.6634262800216675e-01
    phi[4,0]  R686      8.2335025072097778e-01
    phi[4,0]  R687      -1.8395014107227325e-02
    phi[4,0]  R688      -1.7214520275592804e-01
    phi[4,0]  R689      1.0827137231826782e+00
    phi[4,0]  R690      -1.2471863031387329e+00
    phi[4,0]  R691      -1.4683265686035156e+00
    phi[4,0]  R692      -1.6501139402389526e+00
    phi[4,0]  R693      -1.8043681383132935e+00
    phi[4,0]  R694      -1.3986213505268097e-01
    phi[4,0]  R695      -0.880050003528595
    phi[4,0]  R696      -2.1837350726127625e-01
    phi[4,0]  R697      -1.2354835271835327e+00
    phi[4,0]  R698      -7.1926474571228027e-01
    phi[4,0]  R699      1.7339248955249786e-01
    phi[4,0]  R700      -1.5486200153827667e-01
    phi[4,0]  R701      -7.3945659399032593e-01
    phi[4,0]  R702      3.8078850507736206e-01
    phi[4,0]  R703      2.6897782087326050e-01
    phi[4,0]  R704      -0.475409597158432
    phi[4,0]  R705      0.447275310754776
    phi[4,0]  R706      6.9797587394714355e-01
    phi[4,0]  R707      6.6721779108047485e-01
    phi[4,0]  R708      4.0925610065460205e-01
    phi[4,0]  R709      -6.1293929815292358e-01
    phi[4,0]  R710      -1.3899784088134766e+00
    phi[4,0]  R711      -6.4538371562957764e-01
    phi[4,0]  R712      -2.6561182737350464e-01
    phi[4,0]  R713      3.6727637052536011e-01
    phi[4,0]  R714      -2.5555620193481445e+00
    phi[4,0]  R715      -1.1934937238693237e+00
    phi[4,0]  R716      -2.1112194061279297e+00
    phi[4,0]  R717      -2.1435065269470215e+00
    phi[4,0]  R718      -3.3133497238159180e+00
    phi[4,0]  R719      -3.3218452930450439e+00
    phi[6,0]  R0        -1
    phi[6,0]  R2        -2.6378120462742412e+00
    phi[6,0]  R3        1.7539923790988148e+00
    phi[6,0]  R4        1.0896098196541497e+00
    phi[6,0]  R5        -2.2967377102008397e+00
    phi[6,0]  R6        -8.0463834768247766e-01
    phi[6,0]  R7        -1.6750513392469486e+00
    phi[6,0]  R8        -2.81952984395939
    phi[6,0]  R54       1
    phi[6,0]  R720      -4.6218785835832721e-01
    phi[6,0]  R721      -5.73781195090681
    phi[6,0]  R722      -3.9939923886355579e+00
    phi[6,0]  R723      -4.8600763043792838e-01
    phi[6,0]  R724      -4.1896097242867185e+00
    phi[6,0]  R725      -2.0103900849784186e+00
    phi[6,0]  R726      -2.7326222304195813e-01
    phi[6,0]  R727      -4.8667376434436376e+00
    phi[6,0]  R728      -2.2953615569500907e+00
    phi[6,0]  R729      -3.9046382523150460e+00
    phi[6,0]  R730      -4.1494857492236292e-01
    phi[6,0]  R731      -3.76505125341626
    phi[6,0]  R732      -2.8047006067317826e-01
    phi[6,0]  R733      -5.9195297485919589e+00
    phi[6,0]  R734      -0.0976627605197411
    phi[6,0]  R735      -1.0257324466364731e-01
    phi[6,0]  R736      -1.0934637769181055e-01
    phi[6,0]  R737      -2.5343439610609508e-01
    phi[6,0]  R738      -3.1242525293912327e-01
    phi[6,0]  R739      -3.1578217774534595e-01
    phi[6,0]  R740      -3.2291819881495343e-01
    phi[6,0]  R741      -3.2697822030148249e-01
    phi[6,0]  R742      -3.3307954200218870e-01
    phi[6,0]  R743      -3.3986647769942691e-01
    phi[6,0]  R744      -8.2182347451936977e-02
    phi[6,0]  R745      -8.5088193536674517e-02
    phi[6,0]  R746      -8.7598370862844277e-02
    phi[6,0]  R747      -0.0909063367881644
    phi[6,0]  R748      -0.197130771786298
    phi[6,0]  R749      -2.0716264420094621e-01
    phi[6,0]  R750      -2.0805342407293148e-01
    phi[6,0]  R751      -2.2041765417484749e-01
    phi[6,0]  R752      -2.2608067432776635e-01
    phi[6,0]  R753      -0.23354046986125
    phi[6,0]  R754      -1.3999112888229992e-01
    phi[6,0]  R755      -1.5519037917769796e-01
    phi[6,0]  R756      -1.6162417812432972e-01
    phi[6,0]  R757      -1.6543282467073644e-01
    phi[6,0]  R758      -1.6687149633539455e-01
    phi[6,0]  R759      -1.7110677395740093e-01
    phi[6,0]  R760      -1.8316318254488417e-01
    phi[6,0]  R761      -1.8591030732500213e-01
    phi[6,0]  R762      -1.9166537753758361e-01
    phi[6,0]  R763      -1.9368054545809532e-01
    phi[6,0]  R764      -1.0627374551078805e-01
    phi[6,0]  R765      -1.6045906655370429e-01
    phi[6,0]  R766      -1.6774630643976485e-01
    phi[6,0]  R767      -1.9376169432453716e-01
    phi[6,0]  R768      -3.4918602707640156e-01
    phi[6,0]  R769      -3.5059148159352149e-01
    phi[6,0]  R770      -3.5342986133253751e-01
    phi[6,0]  R771      -3.6182246310368749e-01
    phi[6,0]  R772      -4.2999037899327908e-01
    phi[6,0]  R773      -4.4976644414782907e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R774      -3.0999999046325684e+00
    phi[1,2]  R775      -3.0999999046325684e+00
    phi[1,2]  R776      -2.2400000095367432e+00
    phi[1,2]  R777      -2.2400000095367432e+00
    phi[1,2]  R778      -3.0999999046325684e+00
    phi[1,2]  R779      -3.0999999046325684e+00
    phi[1,2]  R780      -2.5699999332427979e+00
    phi[1,2]  R781      -2.5699999332427979e+00
    phi[1,2]  R782      -3.0999999046325684e+00
    phi[1,2]  R783      -3.0999999046325684e+00
    phi[1,2]  R784      -2.0899999141693115e+00
    phi[1,2]  R785      -2.0899999141693115e+00
    phi[1,2]  R786      -3.0999999046325684e+00
    phi[1,2]  R787      -3.0999999046325684e+00
    phi[1,2]  R788      -1.8037002086639404e+00
    phi[1,2]  R789      -1.3226397037506104e+00
    phi[1,2]  R790      -1.6005049943923950e+00
    phi[1,2]  R791      -1.2533605098724365e+00
    phi[1,2]  R792      -1.2455857992172241e+00
    phi[1,2]  R793      -1.0587503910064697e+00
    phi[1,2]  R794      -1.3580213785171509e+00
    phi[1,2]  R795      -1.7613842487335205e+00
    phi[1,2]  R796      1.0010520219802856e+00
    phi[1,2]  R797      7.4042063951492310e-01
    phi[1,2]  R798      1.0317177772521973e+00
    phi[1,2]  R799      -2.0787246525287628e-01
    phi[1,2]  R800      1.0802415758371353e-01
    phi[1,2]  R801      1.1002836376428604e-01
    phi[1,2]  R802      1.3066293299198151e-01
    phi[1,2]  R803      6.6278654336929321e-01
    phi[1,2]  R804      1.0316032171249390e+00
    phi[1,2]  R805      1.0527113676071167e+00
    phi[1,2]  R806      9.6436882019042969e-01
    phi[1,2]  R807      0.942690372467041
    phi[1,2]  R808      -1.5611532926559448e+00
    phi[1,2]  R809      -1.9499567747116089e+00
    phi[1,2]  R810      -2.0060327053070068e+00
    phi[1,2]  R811      -1.8601968288421631e+00
    phi[1,2]  R812      -1.6125484704971313e+00
    phi[1,2]  R813      -1.6199873685836792e+00
    phi[1,2]  R814      -1.0704367160797119e+00
    phi[1,2]  R815      -2.6994326710700989e-01
    phi[1,2]  R816      -9.1971337795257568e-01
    phi[1,2]  R817      -9.0835738182067871e-01
    phi[1,2]  R818      -1.2064650058746338e+00
    phi[1,2]  R819      -1.0584374666213989e+00
    phi[1,2]  R820      -7.5192493200302124e-01
    phi[1,2]  R821      -3.0816310644149780e-01
    phi[1,2]  R822      -1.0907855033874512e+00
    phi[1,2]  R823      -9.1714465618133545e-01
    phi[1,2]  R824      4.6552099287509918e-02
    phi[1,2]  R825      -1.8066576123237610e-01
    phi[1,2]  R826      -4.0153422951698303e-01
    phi[1,2]  R827      -1.1737054586410522e+00
    phi[1,2]  R828      -1.5332914590835571e+00
    phi[1,2]  R829      -2.0016133785247803e+00
    phi[1,2]  R830      -1.2348955869674683e+00
    phi[1,2]  R831      -4.6866655349731445e-02
    phi[1,2]  R832      -1.0846086740493774e+00
    phi[1,2]  R833      -1.0385133028030396e+00
    phi[1,2]  R834      3.3063229918479919e-01
    phi[1,2]  R835      -5.6197237968444824e-01
    phi[1,2]  R836      1.8063329160213470e-01
    phi[1,2]  R837      0.744917094707489
    phi[1,2]  R838      -1.1982963085174561e+00
    phi[1,2]  R839      8.2398509979248047e-01
    phi[1,2]  R840      1.0782244205474854e+00
    phi[1,2]  R841      1.0274049043655396e+00
    phi[1,2]  R842      9.5594388246536255e-01
    phi[1,2]  R843      5.4100722074508667e-01
    phi[1,2]  R844      1.3617775440216064e+00
    phi[1,2]  R845      1.0227026939392090e+00
    phi[1,2]  R846      6.6641956567764282e-01
    phi[1,2]  R847      1.1064631938934326e+00
    phi[1,2]  R848      7.6698881387710571e-01
    phi[1,2]  R849      1.5146030187606812e+00
    phi[1,2]  R850      7.1752482652664185e-01
    phi[1,2]  R851      6.0613554716110229e-01
    phi[1,2]  R852      7.1540546417236328e-01
    phi[1,2]  R853      4.4752874970436096e-01
    phi[1,2]  R854      0.436477392911911
    phi[1,2]  R855      2.5649794936180115e-01
    phi[1,2]  R856      7.3551744222640991e-01
    phi[1,2]  R857      1.4776686429977417e+00
    phi[1,2]  R858      -2.1814320087432861e+00
    phi[1,2]  R859      3.0235034227371216e-01
    phi[1,2]  R860      -1.3693563640117645e-01
    phi[1,2]  R861      -8.7340199947357178e-01
    phi[1,2]  R862      -5.8996640145778656e-02
    phi[1,2]  R863      -2.1620402336120605e+00
    phi[1,2]  R864      -2.8184912204742432e+00
    phi[1,2]  R865      -2.6938042044639587e-01
    phi[1,2]  R866      -1.9580932855606079e+00
    phi[1,2]  R867      -4.6835231781005859e-01
    phi[1,2]  R868      -8.7909328937530518e-01
    phi[1,2]  R869      -5.5021303892135620e-01
    phi[1,2]  R870      -1.8325360119342804e-01
    phi[1,2]  R871      4.6054601669311523e-01
    phi[1,2]  R872      -3.5265591740608215e-01
    phi[1,2]  R873      -1.7214349508285522e+00
    phi[1,2]  R874      -2.9151445627212524e-01
    phi[1,2]  R875      -6.6358792781829834e-01
    phi[1,2]  R876      -6.7215710878372192e-01
    phi[1,2]  R877      7.6747441291809082e-01
    phi[1,2]  R878      -0.57674640417099
    phi[1,2]  R879      -4.4487684965133667e-01
    phi[1,2]  R880      -1.2324304580688477e+00
    phi[1,2]  R881      -1.6218124628067017e+00
    phi[1,2]  R882      0.327092707157135
    phi[1,2]  R883      -5.7638436555862427e-01
    phi[1,2]  R884      -1.6843650341033936e+00
    phi[1,2]  R885      1.4579778909683228e-01
    phi[1,2]  R886      -4.9343603849411011e-01
    phi[1,2]  R887      -1.9866304397583008e+00
    phi[1,2]  R888      -2.3450188636779785e+00
    phi[1,2]  R889      4.0974387526512146e-01
    phi[1,2]  R890      -1.3416094779968262e+00
    phi[1,2]  R891      -1.2005747556686401e+00
    phi[1,2]  R892      -5.5474698543548584e-01
    phi[1,2]  R893      -1.3973701000213623e+00
    phi[1,2]  R894      -1.6571727991104126e+00
    phi[1,2]  R895      -5.5363941192626953e-01
    phi[1,2]  R896      -1.7982462644577026e+00
    phi[1,2]  R897      -1.2034163475036621e+00
    phi[1,2]  R898      -2.1944010257720947e+00
    phi[1,2]  R899      -7.7861803770065308e-01
    phi[1,2]  R900      -1.9219276905059814e+00
    phi[1,2]  R901      -1.4077451229095459e+00
    phi[1,2]  R902      -4.7231793403625488e-01
    phi[1,2]  R903      -1.7380250990390778e-01
    phi[1,2]  R904      9.6614801883697510e-01
    phi[1,2]  R905      3.9480510354042053e-01
    phi[1,2]  R906      2.1665847301483154e+00
    phi[1,2]  R907      1.4957511425018311e+00
    phi[1,2]  R908      -2.5708334445953369e+00
    phi[1,2]  R909      -1.3701149225234985e+00
    phi[1,2]  R910      -0.444678395986557
    phi[1,2]  R911      -1.4362951517105103e+00
    phi[1,2]  R912      2.8492897748947144e-01
    phi[1,2]  R913      6.3467703759670258e-02
    phi[1,2]  R914      1.2392323017120361e+00
    phi[1,2]  R915      2.3891956806182861e+00
    phi[1,2]  R916      -1.8771700859069824e+00
    phi[1,2]  R917      -7.1829926967620850e-01
    phi[1,2]  R918      -6.5130412578582764e-01
    phi[1,2]  R919      -6.2219995260238647e-01
    phi[1,2]  R920      -8.1019508838653564e-01
    phi[1,2]  R921      0.621577799320221
    phi[1,2]  R922      -7.8086328506469727e-01
    phi[1,2]  R923      1.5921211242675781e-01
    phi[1,2]  R924      -2.0980694293975830e+00
    phi[1,2]  R925      -6.1335884034633636e-02
    phi[1,2]  R926      -5.3565853834152222e-01
    phi[1,2]  R927      -2.8359022736549377e-01
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R928      -3.0999999046325684e+00
    phi[2,1]  R929      -3.0999999046325684e+00
    phi[2,1]  R930      -2.2400000095367432e+00
    phi[2,1]  R931      -2.2400000095367432e+00
    phi[2,1]  R932      -3.0999999046325684e+00
    phi[2,1]  R933      -3.0999999046325684e+00
    phi[2,1]  R934      -2.5699999332427979e+00
    phi[2,1]  R935      -2.5699999332427979e+00
    phi[2,1]  R936      -3.0999999046325684e+00
    phi[2,1]  R937      -3.0999999046325684e+00
    phi[2,1]  R938      -2.0899999141693115e+00
    phi[2,1]  R939      -2.0899999141693115e+00
    phi[2,1]  R940      -3.0999999046325684e+00
    phi[2,1]  R941      -3.0999999046325684e+00
    phi[2,1]  R942      7.6698881387710571e-01
    phi[2,1]  R943      1.5146030187606812e+00
    phi[2,1]  R944      7.1752482652664185e-01
    phi[2,1]  R945      6.0613554716110229e-01
    phi[2,1]  R946      7.1540546417236328e-01
    phi[2,1]  R947      4.4752874970436096e-01
    phi[2,1]  R948      0.436477392911911
    phi[2,1]  R949      2.5649794936180115e-01
    phi[2,1]  R950      7.3551744222640991e-01
    phi[2,1]  R951      1.4776686429977417e+00
    phi[2,1]  R952      -2.1814320087432861e+00
    phi[2,1]  R953      3.0235034227371216e-01
    phi[2,1]  R954      -1.3693563640117645e-01
    phi[2,1]  R955      -8.7340199947357178e-01
    phi[2,1]  R956      -5.8996640145778656e-02
    phi[2,1]  R957      -2.1620402336120605e+00
    phi[2,1]  R958      -2.8184912204742432e+00
    phi[2,1]  R959      -2.6938042044639587e-01
    phi[2,1]  R960      -1.9580932855606079e+00
    phi[2,1]  R961      -4.6835231781005859e-01
    phi[2,1]  R962      -8.7909328937530518e-01
    phi[2,1]  R963      -5.5021303892135620e-01
    phi[2,1]  R964      -1.8325360119342804e-01
    phi[2,1]  R965      4.6054601669311523e-01
    phi[2,1]  R966      -3.5265591740608215e-01
    phi[2,1]  R967      -1.7214349508285522e+00
    phi[2,1]  R968      -2.9151445627212524e-01
    phi[2,1]  R969      -6.6358792781829834e-01
    phi[2,1]  R970      -6.7215710878372192e-01
    phi[2,1]  R971      7.6747441291809082e-01
    phi[2,1]  R972      -0.57674640417099
    phi[2,1]  R973      -4.4487684965133667e-01
    phi[2,1]  R974      -1.2324304580688477e+00
    phi[2,1]  R975      -1.6218124628067017e+00
    phi[2,1]  R976      0.327092707157135
    phi[2,1]  R977      -5.7638436555862427e-01
    phi[2,1]  R978      -1.6843650341033936e+00
    phi[2,1]  R979      1.4579778909683228e-01
    phi[2,1]  R980      -4.9343603849411011e-01
    phi[2,1]  R981      -1.9866304397583008e+00
    phi[2,1]  R982      -2.3450188636779785e+00
    phi[2,1]  R983      4.0974387526512146e-01
    phi[2,1]  R984      -1.3416094779968262e+00
    phi[2,1]  R985      -1.2005747556686401e+00
    phi[2,1]  R986      -5.5474698543548584e-01
    phi[2,1]  R987      -1.3973701000213623e+00
    phi[2,1]  R988      -1.6571727991104126e+00
    phi[2,1]  R989      -5.5363941192626953e-01
    phi[2,1]  R990      -1.7982462644577026e+00
    phi[2,1]  R991      -1.2034163475036621e+00
    phi[2,1]  R992      -2.1944010257720947e+00
    phi[2,1]  R993      -7.7861803770065308e-01
    phi[2,1]  R994      -1.9219276905059814e+00
    phi[2,1]  R995      -1.4077451229095459e+00
    phi[2,1]  R996      -4.7231793403625488e-01
    phi[2,1]  R997      -1.7380250990390778e-01
    phi[2,1]  R998      9.6614801883697510e-01
    phi[2,1]  R999      3.9480510354042053e-01
    phi[2,1]  R1000     2.1665847301483154e+00
    phi[2,1]  R1001     1.4957511425018311e+00
    phi[2,1]  R1002     -2.5708334445953369e+00
    phi[2,1]  R1003     -1.3701149225234985e+00
    phi[2,1]  R1004     -0.444678395986557
    phi[2,1]  R1005     -1.4362951517105103e+00
    phi[2,1]  R1006     2.8492897748947144e-01
    phi[2,1]  R1007     6.3467703759670258e-02
    phi[2,1]  R1008     1.2392323017120361e+00
    phi[2,1]  R1009     2.3891956806182861e+00
    phi[2,1]  R1010     -1.8771700859069824e+00
    phi[2,1]  R1011     -7.1829926967620850e-01
    phi[2,1]  R1012     -6.5130412578582764e-01
    phi[2,1]  R1013     -6.2219995260238647e-01
    phi[2,1]  R1014     -8.1019508838653564e-01
    phi[2,1]  R1015     0.621577799320221
    phi[2,1]  R1016     -7.8086328506469727e-01
    phi[2,1]  R1017     1.5921211242675781e-01
    phi[2,1]  R1018     -2.0980694293975830e+00
    phi[2,1]  R1019     -6.1335884034633636e-02
    phi[2,1]  R1020     -5.3565853834152222e-01
    phi[2,1]  R1021     -2.8359022736549377e-01
    phi[2,1]  R1022     -1.8037002086639404e+00
    phi[2,1]  R1023     -1.3226397037506104e+00
    phi[2,1]  R1024     -1.6005049943923950e+00
    phi[2,1]  R1025     -1.2533605098724365e+00
    phi[2,1]  R1026     -1.2455857992172241e+00
    phi[2,1]  R1027     -1.0587503910064697e+00
    phi[2,1]  R1028     -1.3580213785171509e+00
    phi[2,1]  R1029     -1.7613842487335205e+00
    phi[2,1]  R1030     1.0010520219802856e+00
    phi[2,1]  R1031     7.4042063951492310e-01
    phi[2,1]  R1032     1.0317177772521973e+00
    phi[2,1]  R1033     -2.0787246525287628e-01
    phi[2,1]  R1034     1.0802415758371353e-01
    phi[2,1]  R1035     1.1002836376428604e-01
    phi[2,1]  R1036     1.3066293299198151e-01
    phi[2,1]  R1037     6.6278654336929321e-01
    phi[2,1]  R1038     1.0316032171249390e+00
    phi[2,1]  R1039     1.0527113676071167e+00
    phi[2,1]  R1040     9.6436882019042969e-01
    phi[2,1]  R1041     0.942690372467041
    phi[2,1]  R1042     -1.5611532926559448e+00
    phi[2,1]  R1043     -1.9499567747116089e+00
    phi[2,1]  R1044     -2.0060327053070068e+00
    phi[2,1]  R1045     -1.8601968288421631e+00
    phi[2,1]  R1046     -1.6125484704971313e+00
    phi[2,1]  R1047     -1.6199873685836792e+00
    phi[2,1]  R1048     -1.0704367160797119e+00
    phi[2,1]  R1049     -2.6994326710700989e-01
    phi[2,1]  R1050     -9.1971337795257568e-01
    phi[2,1]  R1051     -9.0835738182067871e-01
    phi[2,1]  R1052     -1.2064650058746338e+00
    phi[2,1]  R1053     -1.0584374666213989e+00
    phi[2,1]  R1054     -7.5192493200302124e-01
    phi[2,1]  R1055     -3.0816310644149780e-01
    phi[2,1]  R1056     -1.0907855033874512e+00
    phi[2,1]  R1057     -9.1714465618133545e-01
    phi[2,1]  R1058     4.6552099287509918e-02
    phi[2,1]  R1059     -1.8066576123237610e-01
    phi[2,1]  R1060     -4.0153422951698303e-01
    phi[2,1]  R1061     -1.1737054586410522e+00
    phi[2,1]  R1062     -1.5332914590835571e+00
    phi[2,1]  R1063     -2.0016133785247803e+00
    phi[2,1]  R1064     -1.2348955869674683e+00
    phi[2,1]  R1065     -4.6866655349731445e-02
    phi[2,1]  R1066     -1.0846086740493774e+00
    phi[2,1]  R1067     -1.0385133028030396e+00
    phi[2,1]  R1068     3.3063229918479919e-01
    phi[2,1]  R1069     -5.6197237968444824e-01
    phi[2,1]  R1070     1.8063329160213470e-01
    phi[2,1]  R1071     0.744917094707489
    phi[2,1]  R1072     -1.1982963085174561e+00
    phi[2,1]  R1073     8.2398509979248047e-01
    phi[2,1]  R1074     1.0782244205474854e+00
    phi[2,1]  R1075     1.0274049043655396e+00
    phi[2,1]  R1076     9.5594388246536255e-01
    phi[2,1]  R1077     5.4100722074508667e-01
    phi[2,1]  R1078     1.3617775440216064e+00
    phi[2,1]  R1079     1.0227026939392090e+00
    phi[2,1]  R1080     6.6641956567764282e-01
    phi[2,1]  R1081     1.1064631938934326e+00
    phi[1,4]  R9        1
    phi[1,4]  R10       1
    phi[1,4]  R36       -1
    phi[1,4]  R1082     -3.0999999046325684e+00
    phi[1,4]  R1083     -3.0999999046325684e+00
    phi[1,4]  R1084     -2.2400000095367432e+00
    phi[1,4]  R1085     -2.2400000095367432e+00
    phi[1,4]  R1086     -3.0999999046325684e+00
    phi[1,4]  R1087     -3.0999999046325684e+00
    phi[1,4]  R1088     -2.5699999332427979e+00
    phi[1,4]  R1089     -2.5699999332427979e+00
    phi[1,4]  R1090     -3.0999999046325684e+00
    phi[1,4]  R1091     -3.0999999046325684e+00
    phi[1,4]  R1092     -2.0899999141693115e+00
    phi[1,4]  R1093     -2.0899999141693115e+00
    phi[1,4]  R1094     -3.0999999046325684e+00
    phi[1,4]  R1095     -3.0999999046325684e+00
    phi[1,4]  R1096     -1.8037002086639404e+00
    phi[1,4]  R1097     -1.3226397037506104e+00
    phi[1,4]  R1098     -1.6005049943923950e+00
    phi[1,4]  R1099     -1.2533605098724365e+00
    phi[1,4]  R1100     -1.2455857992172241e+00
    phi[1,4]  R1101     -1.0587503910064697e+00
    phi[1,4]  R1102     -1.3580213785171509e+00
    phi[1,4]  R1103     -1.7613842487335205e+00
    phi[1,4]  R1104     1.0010520219802856e+00
    phi[1,4]  R1105     7.4042063951492310e-01
    phi[1,4]  R1106     1.0317177772521973e+00
    phi[1,4]  R1107     -2.0787246525287628e-01
    phi[1,4]  R1108     1.0802415758371353e-01
    phi[1,4]  R1109     1.1002836376428604e-01
    phi[1,4]  R1110     1.3066293299198151e-01
    phi[1,4]  R1111     6.6278654336929321e-01
    phi[1,4]  R1112     1.0316032171249390e+00
    phi[1,4]  R1113     1.0527113676071167e+00
    phi[1,4]  R1114     9.6436882019042969e-01
    phi[1,4]  R1115     0.942690372467041
    phi[1,4]  R1116     -1.5611532926559448e+00
    phi[1,4]  R1117     -1.9499567747116089e+00
    phi[1,4]  R1118     -2.0060327053070068e+00
    phi[1,4]  R1119     -1.8601968288421631e+00
    phi[1,4]  R1120     -1.6125484704971313e+00
    phi[1,4]  R1121     -1.6199873685836792e+00
    phi[1,4]  R1122     -1.0704367160797119e+00
    phi[1,4]  R1123     -2.6994326710700989e-01
    phi[1,4]  R1124     -9.1971337795257568e-01
    phi[1,4]  R1125     -9.0835738182067871e-01
    phi[1,4]  R1126     -1.2064650058746338e+00
    phi[1,4]  R1127     -1.0584374666213989e+00
    phi[1,4]  R1128     -7.5192493200302124e-01
    phi[1,4]  R1129     -3.0816310644149780e-01
    phi[1,4]  R1130     -1.0907855033874512e+00
    phi[1,4]  R1131     -9.1714465618133545e-01
    phi[1,4]  R1132     4.6552099287509918e-02
    phi[1,4]  R1133     -1.8066576123237610e-01
    phi[1,4]  R1134     -4.0153422951698303e-01
    phi[1,4]  R1135     -1.1737054586410522e+00
    phi[1,4]  R1136     -1.5332914590835571e+00
    phi[1,4]  R1137     -2.0016133785247803e+00
    phi[1,4]  R1138     -1.2348955869674683e+00
    phi[1,4]  R1139     -4.6866655349731445e-02
    phi[1,4]  R1140     -1.0846086740493774e+00
    phi[1,4]  R1141     -1.0385133028030396e+00
    phi[1,4]  R1142     3.3063229918479919e-01
    phi[1,4]  R1143     -5.6197237968444824e-01
    phi[1,4]  R1144     1.8063329160213470e-01
    phi[1,4]  R1145     0.744917094707489
    phi[1,4]  R1146     -1.1982963085174561e+00
    phi[1,4]  R1147     8.2398509979248047e-01
    phi[1,4]  R1148     1.0782244205474854e+00
    phi[1,4]  R1149     1.0274049043655396e+00
    phi[1,4]  R1150     9.5594388246536255e-01
    phi[1,4]  R1151     5.4100722074508667e-01
    phi[1,4]  R1152     1.3617775440216064e+00
    phi[1,4]  R1153     1.0227026939392090e+00
    phi[1,4]  R1154     6.6641956567764282e-01
    phi[1,4]  R1155     1.1064631938934326e+00
    phi[1,4]  R1156     -1.1349966526031494e+00
    phi[1,4]  R1157     -1.1427879333496094e+00
    phi[1,4]  R1158     -7.2888344526290894e-01
    phi[1,4]  R1159     -7.4036091566085815e-01
    phi[1,4]  R1160     -9.2340862751007080e-01
    phi[1,4]  R1161     -4.0682223439216614e-01
    phi[1,4]  R1162     -6.4768642187118530e-01
    phi[1,4]  R1163     -1.8927834033966064e+00
    phi[1,4]  R1164     -4.7784546017646790e-01
    phi[1,4]  R1165     -9.3285769224166870e-01
    phi[1,4]  R1166     1.1380215883255005e+00
    phi[1,4]  R1167     6.9943785667419434e-01
    phi[1,4]  R1168     -8.2722121477127075e-01
    phi[1,4]  R1169     7.4775010347366333e-01
    phi[1,4]  R1170     1.4682742357254028e+00
    phi[1,4]  R1171     1.5242244005203247e+00
    phi[1,4]  R1172     1.4790067672729492e+00
    phi[1,4]  R1173     -5.5802255868911743e-01
    phi[1,4]  R1174     8.3793580532073975e-01
    phi[1,4]  R1175     2.0132152736186981e-01
    phi[1,4]  R1176     -1.9470099210739136e+00
    phi[1,4]  R1177     -1.3906112909317017e+00
    phi[1,4]  R1178     8.8488626480102539e-01
    phi[1,4]  R1179     -1.9665704667568207e-01
    phi[1,4]  R1180     3.6203145980834961e-01
    phi[1,4]  R1181     -1.7883622646331787e+00
    phi[1,4]  R1182     -8.2152163982391357e-01
    phi[1,4]  R1183     1.5952751040458679e-01
    phi[1,4]  R1184     -1.2830153107643127e-01
    phi[1,4]  R1185     -0.751623272895813
    phi[1,4]  R1186     -1.3494781255722046e+00
    phi[1,4]  R1187     -1.84017014503479
    phi[1,4]  R1188     3.6190178990364075e-01
    phi[1,4]  R1189     2.6068103313446045e-01
    phi[1,4]  R1190     -5.7612460851669312e-01
    phi[1,4]  R1191     -9.3409514427185059e-01
    phi[1,4]  R1192     6.1517262458801270e-01
    phi[1,4]  R1193     3.9461475610733032e-01
    phi[1,4]  R1194     -9.8060362040996552e-02
    phi[1,4]  R1195     1.4719067513942719e-01
    phi[1,4]  R1196     4.5779719948768616e-01
    phi[1,4]  R1197     -2.0165763795375824e-01
    phi[1,4]  R1198     2.3757264018058777e-01
    phi[1,4]  R1199     4.3969199061393738e-01
    phi[1,4]  R1200     -0.282153844833374
    phi[1,4]  R1201     -1.4814805984497070e+00
    phi[1,4]  R1202     -7.8956365585327148e-01
    phi[1,4]  R1203     1.1392768621444702e+00
    phi[1,4]  R1204     1.0514466762542725e+00
    phi[1,4]  R1205     1.1114830970764160e+00
    phi[4,1]  R9        -1
    phi[4,1]  R36       1
    phi[4,1]  R37       1
    phi[4,1]  R1206     -3.0999999046325684e+00
    phi[4,1]  R1207     -3.0999999046325684e+00
    phi[4,1]  R1208     -2.2400000095367432e+00
    phi[4,1]  R1209     -2.2400000095367432e+00
    phi[4,1]  R1210     -3.0999999046325684e+00
    phi[4,1]  R1211     -3.0999999046325684e+00
    phi[4,1]  R1212     -2.5699999332427979e+00
    phi[4,1]  R1213     -2.5699999332427979e+00
    phi[4,1]  R1214     -3.0999999046325684e+00
    phi[4,1]  R1215     -3.0999999046325684e+00
    phi[4,1]  R1216     -2.0899999141693115e+00
    phi[4,1]  R1217     -2.0899999141693115e+00
    phi[4,1]  R1218     -3.0999999046325684e+00
    phi[4,1]  R1219     -3.0999999046325684e+00
    phi[4,1]  R1220     -1.1349966526031494e+00
    phi[4,1]  R1221     -1.1427879333496094e+00
    phi[4,1]  R1222     -7.2888344526290894e-01
    phi[4,1]  R1223     -7.4036091566085815e-01
    phi[4,1]  R1224     -9.2340862751007080e-01
    phi[4,1]  R1225     -4.0682223439216614e-01
    phi[4,1]  R1226     -6.4768642187118530e-01
    phi[4,1]  R1227     -1.8927834033966064e+00
    phi[4,1]  R1228     -4.7784546017646790e-01
    phi[4,1]  R1229     -9.3285769224166870e-01
    phi[4,1]  R1230     1.1380215883255005e+00
    phi[4,1]  R1231     6.9943785667419434e-01
    phi[4,1]  R1232     -8.2722121477127075e-01
    phi[4,1]  R1233     7.4775010347366333e-01
    phi[4,1]  R1234     1.4682742357254028e+00
    phi[4,1]  R1235     1.5242244005203247e+00
    phi[4,1]  R1236     1.4790067672729492e+00
    phi[4,1]  R1237     -5.5802255868911743e-01
    phi[4,1]  R1238     8.3793580532073975e-01
    phi[4,1]  R1239     2.0132152736186981e-01
    phi[4,1]  R1240     -1.9470099210739136e+00
    phi[4,1]  R1241     -1.3906112909317017e+00
    phi[4,1]  R1242     8.8488626480102539e-01
    phi[4,1]  R1243     -1.9665704667568207e-01
    phi[4,1]  R1244     3.6203145980834961e-01
    phi[4,1]  R1245     -1.7883622646331787e+00
    phi[4,1]  R1246     -8.2152163982391357e-01
    phi[4,1]  R1247     1.5952751040458679e-01
    phi[4,1]  R1248     -1.2830153107643127e-01
    phi[4,1]  R1249     -0.751623272895813
    phi[4,1]  R1250     -1.3494781255722046e+00
    phi[4,1]  R1251     -1.84017014503479
    phi[4,1]  R1252     3.6190178990364075e-01
    phi[4,1]  R1253     2.6068103313446045e-01
    phi[4,1]  R1254     -5.7612460851669312e-01
    phi[4,1]  R1255     -9.3409514427185059e-01
    phi[4,1]  R1256     6.1517262458801270e-01
    phi[4,1]  R1257     3.9461475610733032e-01
    phi[4,1]  R1258     -9.8060362040996552e-02
    phi[4,1]  R1259     1.4719067513942719e-01
    phi[4,1]  R1260     4.5779719948768616e-01
    phi[4,1]  R1261     -2.0165763795375824e-01
    phi[4,1]  R1262     2.3757264018058777e-01
    phi[4,1]  R1263     4.3969199061393738e-01
    phi[4,1]  R1264     -0.282153844833374
    phi[4,1]  R1265     -1.4814805984497070e+00
    phi[4,1]  R1266     -7.8956365585327148e-01
    phi[4,1]  R1267     1.1392768621444702e+00
    phi[4,1]  R1268     1.0514466762542725e+00
    phi[4,1]  R1269     1.1114830970764160e+00
    phi[4,1]  R1270     -1.8037002086639404e+00
    phi[4,1]  R1271     -1.3226397037506104e+00
    phi[4,1]  R1272     -1.6005049943923950e+00
    phi[4,1]  R1273     -1.2533605098724365e+00
    phi[4,1]  R1274     -1.2455857992172241e+00
    phi[4,1]  R1275     -1.0587503910064697e+00
    phi[4,1]  R1276     -1.3580213785171509e+00
    phi[4,1]  R1277     -1.7613842487335205e+00
    phi[4,1]  R1278     1.0010520219802856e+00
    phi[4,1]  R1279     7.4042063951492310e-01
    phi[4,1]  R1280     1.0317177772521973e+00
    phi[4,1]  R1281     -2.0787246525287628e-01
    phi[4,1]  R1282     1.0802415758371353e-01
    phi[4,1]  R1283     1.1002836376428604e-01
    phi[4,1]  R1284     1.3066293299198151e-01
    phi[4,1]  R1285     6.6278654336929321e-01
    phi[4,1]  R1286     1.0316032171249390e+00
    phi[4,1]  R1287     1.0527113676071167e+00
    phi[4,1]  R1288     9.6436882019042969e-01
    phi[4,1]  R1289     0.942690372467041
    phi[4,1]  R1290     -1.5611532926559448e+00
    phi[4,1]  R1291     -1.9499567747116089e+00
    phi[4,1]  R1292     -2.0060327053070068e+00
    phi[4,1]  R1293     -1.8601968288421631e+00
    phi[4,1]  R1294     -1.6125484704971313e+00
    phi[4,1]  R1295     -1.6199873685836792e+00
    phi[4,1]  R1296     -1.0704367160797119e+00
    phi[4,1]  R1297     -2.6994326710700989e-01
    phi[4,1]  R1298     -9.1971337795257568e-01
    phi[4,1]  R1299     -9.0835738182067871e-01
    phi[4,1]  R1300     -1.2064650058746338e+00
    phi[4,1]  R1301     -1.0584374666213989e+00
    phi[4,1]  R1302     -7.5192493200302124e-01
    phi[4,1]  R1303     -3.0816310644149780e-01
    phi[4,1]  R1304     -1.0907855033874512e+00
    phi[4,1]  R1305     -9.1714465618133545e-01
    phi[4,1]  R1306     4.6552099287509918e-02
    phi[4,1]  R1307     -1.8066576123237610e-01
    phi[4,1]  R1308     -4.0153422951698303e-01
    phi[4,1]  R1309     -1.1737054586410522e+00
    phi[4,1]  R1310     -1.5332914590835571e+00
    phi[4,1]  R1311     -2.0016133785247803e+00
    phi[4,1]  R1312     -1.2348955869674683e+00
    phi[4,1]  R1313     -4.6866655349731445e-02
    phi[4,1]  R1314     -1.0846086740493774e+00
    phi[4,1]  R1315     -1.0385133028030396e+00
    phi[4,1]  R1316     3.3063229918479919e-01
    phi[4,1]  R1317     -5.6197237968444824e-01
    phi[4,1]  R1318     1.8063329160213470e-01
    phi[4,1]  R1319     0.744917094707489
    phi[4,1]  R1320     -1.1982963085174561e+00
    phi[4,1]  R1321     8.2398509979248047e-01
    phi[4,1]  R1322     1.0782244205474854e+00
    phi[4,1]  R1323     1.0274049043655396e+00
    phi[4,1]  R1324     9.5594388246536255e-01
    phi[4,1]  R1325     5.4100722074508667e-01
    phi[4,1]  R1326     1.3617775440216064e+00
    phi[4,1]  R1327     1.0227026939392090e+00
    phi[4,1]  R1328     6.6641956567764282e-01
    phi[4,1]  R1329     1.1064631938934326e+00
    phi[1,5]  R9        1
    phi[1,5]  R10       1
    phi[1,5]  R45       -1
    phi[1,5]  R1330     -3.0999999046325684e+00
    phi[1,5]  R1331     -3.0999999046325684e+00
    phi[1,5]  R1332     -2.2400000095367432e+00
    phi[1,5]  R1333     -2.2400000095367432e+00
    phi[1,5]  R1334     -3.0999999046325684e+00
    phi[1,5]  R1335     -3.0999999046325684e+00
    phi[1,5]  R1336     -2.5699999332427979e+00
    phi[1,5]  R1337     -2.5699999332427979e+00
    phi[1,5]  R1338     -3.0999999046325684e+00
    phi[1,5]  R1339     -3.0999999046325684e+00
    phi[1,5]  R1340     -2.0899999141693115e+00
    phi[1,5]  R1341     -2.0899999141693115e+00
    phi[1,5]  R1342     -3.0999999046325684e+00
    phi[1,5]  R1343     -3.0999999046325684e+00
    phi[1,5]  R1344     -1.8037002086639404e+00
    phi[1,5]  R1345     -1.3226397037506104e+00
    phi[1,5]  R1346     -1.6005049943923950e+00
    phi[1,5]  R1347     -1.2533605098724365e+00
    phi[1,5]  R1348     -1.2455857992172241e+00
    phi[1,5]  R1349     -1.0587503910064697e+00
    phi[1,5]  R1350     -1.3580213785171509e+00
    phi[1,5]  R1351     -1.7613842487335205e+00
    phi[1,5]  R1352     1.0010520219802856e+00
    phi[1,5]  R1353     7.4042063951492310e-01
    phi[1,5]  R1354     1.0317177772521973e+00
    phi[1,5]  R1355     -2.0787246525287628e-01
    phi[1,5]  R1356     1.0802415758371353e-01
    phi[1,5]  R1357     1.1002836376428604e-01
    phi[1,5]  R1358     1.3066293299198151e-01
    phi[1,5]  R1359     6.6278654336929321e-01
    phi[1,5]  R1360     1.0316032171249390e+00
    phi[1,5]  R1361     1.0527113676071167e+00
    phi[1,5]  R1362     9.6436882019042969e-01
    phi[1,5]  R1363     0.942690372467041
    phi[1,5]  R1364     -1.5611532926559448e+00
    phi[1,5]  R1365     -1.9499567747116089e+00
    phi[1,5]  R1366     -2.0060327053070068e+00
    phi[1,5]  R1367     -1.8601968288421631e+00
    phi[1,5]  R1368     -1.6125484704971313e+00
    phi[1,5]  R1369     -1.6199873685836792e+00
    phi[1,5]  R1370     -1.0704367160797119e+00
    phi[1,5]  R1371     -2.6994326710700989e-01
    phi[1,5]  R1372     -9.1971337795257568e-01
    phi[1,5]  R1373     -9.0835738182067871e-01
    phi[1,5]  R1374     -1.2064650058746338e+00
    phi[1,5]  R1375     -1.0584374666213989e+00
    phi[1,5]  R1376     -7.5192493200302124e-01
    phi[1,5]  R1377     -3.0816310644149780e-01
    phi[1,5]  R1378     -1.0907855033874512e+00
    phi[1,5]  R1379     -9.1714465618133545e-01
    phi[1,5]  R1380     4.6552099287509918e-02
    phi[1,5]  R1381     -1.8066576123237610e-01
    phi[1,5]  R1382     -4.0153422951698303e-01
    phi[1,5]  R1383     -1.1737054586410522e+00
    phi[1,5]  R1384     -1.5332914590835571e+00
    phi[1,5]  R1385     -2.0016133785247803e+00
    phi[1,5]  R1386     -1.2348955869674683e+00
    phi[1,5]  R1387     -4.6866655349731445e-02
    phi[1,5]  R1388     -1.0846086740493774e+00
    phi[1,5]  R1389     -1.0385133028030396e+00
    phi[1,5]  R1390     3.3063229918479919e-01
    phi[1,5]  R1391     -5.6197237968444824e-01
    phi[1,5]  R1392     1.8063329160213470e-01
    phi[1,5]  R1393     0.744917094707489
    phi[1,5]  R1394     -1.1982963085174561e+00
    phi[1,5]  R1395     8.2398509979248047e-01
    phi[1,5]  R1396     1.0782244205474854e+00
    phi[1,5]  R1397     1.0274049043655396e+00
    phi[1,5]  R1398     9.5594388246536255e-01
    phi[1,5]  R1399     5.4100722074508667e-01
    phi[1,5]  R1400     1.3617775440216064e+00
    phi[1,5]  R1401     1.0227026939392090e+00
    phi[1,5]  R1402     6.6641956567764282e-01
    phi[1,5]  R1403     1.1064631938934326e+00
    phi[1,5]  R1404     3.6585351824760437e-01
    phi[1,5]  R1405     6.4783477783203125e-01
    phi[1,5]  R1406     2.8783312439918518e-01
    phi[1,5]  R1407     -3.3419579267501831e-01
    phi[1,5]  R1408     -3.8654603064060211e-02
    phi[1,5]  R1409     -3.8230374455451965e-01
    phi[1,5]  R1410     -1.1140504479408264e-01
    phi[1,5]  R1411     -1.2809278964996338e+00
    phi[1,5]  R1412     -1.8217583000659943e-01
    phi[1,5]  R1413     7.8476691246032715e-01
    phi[1,5]  R1414     7.9176551103591919e-01
    phi[1,5]  R1415     2.4629805982112885e-01
    phi[1,5]  R1416     4.1538584232330322e-01
    phi[1,5]  R1417     -2.0035283565521240e+00
    phi[1,5]  R1418     1.2539389133453369e+00
    phi[1,5]  R1419     -2.2836899757385254e+00
    phi[1,5]  R1420     0.252595454454422
    phi[1,5]  R1421     3.1737816333770752e-01
    phi[1,5]  R1422     1.0776723623275757e+00
    phi[1,5]  R1423     -4.1990213096141815e-02
    phi[1,5]  R1424     -1.6295845508575439e+00
    phi[1,5]  R1425     5.7241827249526978e-01
    phi[1,5]  R1426     -9.9667298793792725e-01
    phi[1,5]  R1427     -4.1352930665016174e-01
    phi[1,5]  R1428     -6.9618147611618042e-01
    phi[1,5]  R1429     3.9993104338645935e-01
    phi[1,5]  R1430     -0.596386194229126
    phi[1,5]  R1431     -1.5543608665466309e+00
    phi[1,5]  R1432     -1.2189731746912003e-01
    phi[1,5]  R1433     1.3955628871917725e+00
    phi[1,5]  R1434     3.9716142416000366e-01
    phi[1,5]  R1435     9.4110108911991119e-02
    phi[1,5]  R1436     -7.0378565788269043e-01
    phi[1,5]  R1437     9.2047137022018433e-01
    phi[1,5]  R1438     0.299384206533432
    phi[1,5]  R1439     -2.0542659759521484e+00
    phi[1,5]  R1440     -1.5622515678405762e+00
    phi[1,5]  R1441     -1.4764670133590698e+00
    phi[1,5]  R1442     -1.1220639944076538e+00
    phi[1,5]  R1443     -1.5764595270156860e+00
    phi[5,1]  R9        -1
    phi[5,1]  R45       1
    phi[5,1]  R46       1
    phi[5,1]  R1444     -3.0999999046325684e+00
    phi[5,1]  R1445     -3.0999999046325684e+00
    phi[5,1]  R1446     -2.2400000095367432e+00
    phi[5,1]  R1447     -2.2400000095367432e+00
    phi[5,1]  R1448     -3.0999999046325684e+00
    phi[5,1]  R1449     -3.0999999046325684e+00
    phi[5,1]  R1450     -2.5699999332427979e+00
    phi[5,1]  R1451     -2.5699999332427979e+00
    phi[5,1]  R1452     -3.0999999046325684e+00
    phi[5,1]  R1453     -3.0999999046325684e+00
    phi[5,1]  R1454     -2.0899999141693115e+00
    phi[5,1]  R1455     -2.0899999141693115e+00
    phi[5,1]  R1456     -3.0999999046325684e+00
    phi[5,1]  R1457     -3.0999999046325684e+00
    phi[5,1]  R1458     3.6585351824760437e-01
    phi[5,1]  R1459     6.4783477783203125e-01
    phi[5,1]  R1460     2.8783312439918518e-01
    phi[5,1]  R1461     -3.3419579267501831e-01
    phi[5,1]  R1462     -3.8654603064060211e-02
    phi[5,1]  R1463     -3.8230374455451965e-01
    phi[5,1]  R1464     -1.1140504479408264e-01
    phi[5,1]  R1465     -1.2809278964996338e+00
    phi[5,1]  R1466     -1.8217583000659943e-01
    phi[5,1]  R1467     7.8476691246032715e-01
    phi[5,1]  R1468     7.9176551103591919e-01
    phi[5,1]  R1469     2.4629805982112885e-01
    phi[5,1]  R1470     4.1538584232330322e-01
    phi[5,1]  R1471     -2.0035283565521240e+00
    phi[5,1]  R1472     1.2539389133453369e+00
    phi[5,1]  R1473     -2.2836899757385254e+00
    phi[5,1]  R1474     0.252595454454422
    phi[5,1]  R1475     3.1737816333770752e-01
    phi[5,1]  R1476     1.0776723623275757e+00
    phi[5,1]  R1477     -4.1990213096141815e-02
    phi[5,1]  R1478     -1.6295845508575439e+00
    phi[5,1]  R1479     5.7241827249526978e-01
    phi[5,1]  R1480     -9.9667298793792725e-01
    phi[5,1]  R1481     -4.1352930665016174e-01
    phi[5,1]  R1482     -6.9618147611618042e-01
    phi[5,1]  R1483     3.9993104338645935e-01
    phi[5,1]  R1484     -0.596386194229126
    phi[5,1]  R1485     -1.5543608665466309e+00
    phi[5,1]  R1486     -1.2189731746912003e-01
    phi[5,1]  R1487     1.3955628871917725e+00
    phi[5,1]  R1488     3.9716142416000366e-01
    phi[5,1]  R1489     9.4110108911991119e-02
    phi[5,1]  R1490     -7.0378565788269043e-01
    phi[5,1]  R1491     9.2047137022018433e-01
    phi[5,1]  R1492     0.299384206533432
    phi[5,1]  R1493     -2.0542659759521484e+00
    phi[5,1]  R1494     -1.5622515678405762e+00
    phi[5,1]  R1495     -1.4764670133590698e+00
    phi[5,1]  R1496     -1.1220639944076538e+00
    phi[5,1]  R1497     -1.5764595270156860e+00
    phi[5,1]  R1498     -1.8037002086639404e+00
    phi[5,1]  R1499     -1.3226397037506104e+00
    phi[5,1]  R1500     -1.6005049943923950e+00
    phi[5,1]  R1501     -1.2533605098724365e+00
    phi[5,1]  R1502     -1.2455857992172241e+00
    phi[5,1]  R1503     -1.0587503910064697e+00
    phi[5,1]  R1504     -1.3580213785171509e+00
    phi[5,1]  R1505     -1.7613842487335205e+00
    phi[5,1]  R1506     1.0010520219802856e+00
    phi[5,1]  R1507     7.4042063951492310e-01
    phi[5,1]  R1508     1.0317177772521973e+00
    phi[5,1]  R1509     -2.0787246525287628e-01
    phi[5,1]  R1510     1.0802415758371353e-01
    phi[5,1]  R1511     1.1002836376428604e-01
    phi[5,1]  R1512     1.3066293299198151e-01
    phi[5,1]  R1513     6.6278654336929321e-01
    phi[5,1]  R1514     1.0316032171249390e+00
    phi[5,1]  R1515     1.0527113676071167e+00
    phi[5,1]  R1516     9.6436882019042969e-01
    phi[5,1]  R1517     0.942690372467041
    phi[5,1]  R1518     -1.5611532926559448e+00
    phi[5,1]  R1519     -1.9499567747116089e+00
    phi[5,1]  R1520     -2.0060327053070068e+00
    phi[5,1]  R1521     -1.8601968288421631e+00
    phi[5,1]  R1522     -1.6125484704971313e+00
    phi[5,1]  R1523     -1.6199873685836792e+00
    phi[5,1]  R1524     -1.0704367160797119e+00
    phi[5,1]  R1525     -2.6994326710700989e-01
    phi[5,1]  R1526     -9.1971337795257568e-01
    phi[5,1]  R1527     -9.0835738182067871e-01
    phi[5,1]  R1528     -1.2064650058746338e+00
    phi[5,1]  R1529     -1.0584374666213989e+00
    phi[5,1]  R1530     -7.5192493200302124e-01
    phi[5,1]  R1531     -3.0816310644149780e-01
    phi[5,1]  R1532     -1.0907855033874512e+00
    phi[5,1]  R1533     -9.1714465618133545e-01
    phi[5,1]  R1534     4.6552099287509918e-02
    phi[5,1]  R1535     -1.8066576123237610e-01
    phi[5,1]  R1536     -4.0153422951698303e-01
    phi[5,1]  R1537     -1.1737054586410522e+00
    phi[5,1]  R1538     -1.5332914590835571e+00
    phi[5,1]  R1539     -2.0016133785247803e+00
    phi[5,1]  R1540     -1.2348955869674683e+00
    phi[5,1]  R1541     -4.6866655349731445e-02
    phi[5,1]  R1542     -1.0846086740493774e+00
    phi[5,1]  R1543     -1.0385133028030396e+00
    phi[5,1]  R1544     3.3063229918479919e-01
    phi[5,1]  R1545     -5.6197237968444824e-01
    phi[5,1]  R1546     1.8063329160213470e-01
    phi[5,1]  R1547     0.744917094707489
    phi[5,1]  R1548     -1.1982963085174561e+00
    phi[5,1]  R1549     8.2398509979248047e-01
    phi[5,1]  R1550     1.0782244205474854e+00
    phi[5,1]  R1551     1.0274049043655396e+00
    phi[5,1]  R1552     9.5594388246536255e-01
    phi[5,1]  R1553     5.4100722074508667e-01
    phi[5,1]  R1554     1.3617775440216064e+00
    phi[5,1]  R1555     1.0227026939392090e+00
    phi[5,1]  R1556     6.6641956567764282e-01
    phi[5,1]  R1557     1.1064631938934326e+00
    phi[2,5]  R18       1
    phi[2,5]  R19       1
    phi[2,5]  R45       -1
    phi[2,5]  R1558     -3.0999999046325684e+00
    phi[2,5]  R1559     -3.0999999046325684e+00
    phi[2,5]  R1560     -2.2400000095367432e+00
    phi[2,5]  R1561     -2.2400000095367432e+00
    phi[2,5]  R1562     -3.0999999046325684e+00
    phi[2,5]  R1563     -3.0999999046325684e+00
    phi[2,5]  R1564     -2.5699999332427979e+00
    phi[2,5]  R1565     -2.5699999332427979e+00
    phi[2,5]  R1566     -3.0999999046325684e+00
    phi[2,5]  R1567     -3.0999999046325684e+00
    phi[2,5]  R1568     -2.0899999141693115e+00
    phi[2,5]  R1569     -2.0899999141693115e+00
    phi[2,5]  R1570     -3.0999999046325684e+00
    phi[2,5]  R1571     -3.0999999046325684e+00
    phi[2,5]  R1572     7.6698881387710571e-01
    phi[2,5]  R1573     1.5146030187606812e+00
    phi[2,5]  R1574     7.1752482652664185e-01
    phi[2,5]  R1575     6.0613554716110229e-01
    phi[2,5]  R1576     7.1540546417236328e-01
    phi[2,5]  R1577     4.4752874970436096e-01
    phi[2,5]  R1578     0.436477392911911
    phi[2,5]  R1579     2.5649794936180115e-01
    phi[2,5]  R1580     7.3551744222640991e-01
    phi[2,5]  R1581     1.4776686429977417e+00
    phi[2,5]  R1582     -2.1814320087432861e+00
    phi[2,5]  R1583     3.0235034227371216e-01
    phi[2,5]  R1584     -1.3693563640117645e-01
    phi[2,5]  R1585     -8.7340199947357178e-01
    phi[2,5]  R1586     -5.8996640145778656e-02
    phi[2,5]  R1587     -2.1620402336120605e+00
    phi[2,5]  R1588     -2.8184912204742432e+00
    phi[2,5]  R1589     -2.6938042044639587e-01
    phi[2,5]  R1590     -1.9580932855606079e+00
    phi[2,5]  R1591     -4.6835231781005859e-01
    phi[2,5]  R1592     -8.7909328937530518e-01
    phi[2,5]  R1593     -5.5021303892135620e-01
    phi[2,5]  R1594     -1.8325360119342804e-01
    phi[2,5]  R1595     4.6054601669311523e-01
    phi[2,5]  R1596     -3.5265591740608215e-01
    phi[2,5]  R1597     -1.7214349508285522e+00
    phi[2,5]  R1598     -2.9151445627212524e-01
    phi[2,5]  R1599     -6.6358792781829834e-01
    phi[2,5]  R1600     -6.7215710878372192e-01
    phi[2,5]  R1601     7.6747441291809082e-01
    phi[2,5]  R1602     -0.57674640417099
    phi[2,5]  R1603     -4.4487684965133667e-01
    phi[2,5]  R1604     -1.2324304580688477e+00
    phi[2,5]  R1605     -1.6218124628067017e+00
    phi[2,5]  R1606     0.327092707157135
    phi[2,5]  R1607     -5.7638436555862427e-01
    phi[2,5]  R1608     -1.6843650341033936e+00
    phi[2,5]  R1609     1.4579778909683228e-01
    phi[2,5]  R1610     -4.9343603849411011e-01
    phi[2,5]  R1611     -1.9866304397583008e+00
    phi[2,5]  R1612     -2.3450188636779785e+00
    phi[2,5]  R1613     4.0974387526512146e-01
    phi[2,5]  R1614     -1.3416094779968262e+00
    phi[2,5]  R1615     -1.2005747556686401e+00
    phi[2,5]  R1616     -5.5474698543548584e-01
    phi[2,5]  R1617     -1.3973701000213623e+00
    phi[2,5]  R1618     -1.6571727991104126e+00
    phi[2,5]  R1619     -5.5363941192626953e-01
    phi[2,5]  R1620     -1.7982462644577026e+00
    phi[2,5]  R1621     -1.2034163475036621e+00
    phi[2,5]  R1622     -2.1944010257720947e+00
    phi[2,5]  R1623     -7.7861803770065308e-01
    phi[2,5]  R1624     -1.9219276905059814e+00
    phi[2,5]  R1625     -1.4077451229095459e+00
    phi[2,5]  R1626     -4.7231793403625488e-01
    phi[2,5]  R1627     -1.7380250990390778e-01
    phi[2,5]  R1628     9.6614801883697510e-01
    phi[2,5]  R1629     3.9480510354042053e-01
    phi[2,5]  R1630     2.1665847301483154e+00
    phi[2,5]  R1631     1.4957511425018311e+00
    phi[2,5]  R1632     -2.5708334445953369e+00
    phi[2,5]  R1633     -1.3701149225234985e+00
    phi[2,5]  R1634     -0.444678395986557
    phi[2,5]  R1635     -1.4362951517105103e+00
    phi[2,5]  R1636     2.8492897748947144e-01
    phi[2,5]  R1637     6.3467703759670258e-02
    phi[2,5]  R1638     1.2392323017120361e+00
    phi[2,5]  R1639     2.3891956806182861e+00
    phi[2,5]  R1640     -1.8771700859069824e+00
    phi[2,5]  R1641     -7.1829926967620850e-01
    phi[2,5]  R1642     -6.5130412578582764e-01
    phi[2,5]  R1643     -6.2219995260238647e-01
    phi[2,5]  R1644     -8.1019508838653564e-01
    phi[2,5]  R1645     0.621577799320221
    phi[2,5]  R1646     -7.8086328506469727e-01
    phi[2,5]  R1647     1.5921211242675781e-01
    phi[2,5]  R1648     -2.0980694293975830e+00
    phi[2,5]  R1649     -6.1335884034633636e-02
    phi[2,5]  R1650     -5.3565853834152222e-01
    phi[2,5]  R1651     -2.8359022736549377e-01
    phi[2,5]  R1652     3.6585351824760437e-01
    phi[2,5]  R1653     6.4783477783203125e-01
    phi[2,5]  R1654     2.8783312439918518e-01
    phi[2,5]  R1655     -3.3419579267501831e-01
    phi[2,5]  R1656     -3.8654603064060211e-02
    phi[2,5]  R1657     -3.8230374455451965e-01
    phi[2,5]  R1658     -1.1140504479408264e-01
    phi[2,5]  R1659     -1.2809278964996338e+00
    phi[2,5]  R1660     -1.8217583000659943e-01
    phi[2,5]  R1661     7.8476691246032715e-01
    phi[2,5]  R1662     7.9176551103591919e-01
    phi[2,5]  R1663     2.4629805982112885e-01
    phi[2,5]  R1664     4.1538584232330322e-01
    phi[2,5]  R1665     -2.0035283565521240e+00
    phi[2,5]  R1666     1.2539389133453369e+00
    phi[2,5]  R1667     -2.2836899757385254e+00
    phi[2,5]  R1668     0.252595454454422
    phi[2,5]  R1669     3.1737816333770752e-01
    phi[2,5]  R1670     1.0776723623275757e+00
    phi[2,5]  R1671     -4.1990213096141815e-02
    phi[2,5]  R1672     -1.6295845508575439e+00
    phi[2,5]  R1673     5.7241827249526978e-01
    phi[2,5]  R1674     -9.9667298793792725e-01
    phi[2,5]  R1675     -4.1352930665016174e-01
    phi[2,5]  R1676     -6.9618147611618042e-01
    phi[2,5]  R1677     3.9993104338645935e-01
    phi[2,5]  R1678     -0.596386194229126
    phi[2,5]  R1679     -1.5543608665466309e+00
    phi[2,5]  R1680     -1.2189731746912003e-01
    phi[2,5]  R1681     1.3955628871917725e+00
    phi[2,5]  R1682     3.9716142416000366e-01
    phi[2,5]  R1683     9.4110108911991119e-02
    phi[2,5]  R1684     -7.0378565788269043e-01
    phi[2,5]  R1685     9.2047137022018433e-01
    phi[2,5]  R1686     0.299384206533432
    phi[2,5]  R1687     -2.0542659759521484e+00
    phi[2,5]  R1688     -1.5622515678405762e+00
    phi[2,5]  R1689     -1.4764670133590698e+00
    phi[2,5]  R1690     -1.1220639944076538e+00
    phi[2,5]  R1691     -1.5764595270156860e+00
    phi[5,2]  R18       -1
    phi[5,2]  R45       1
    phi[5,2]  R46       1
    phi[5,2]  R1692     -3.0999999046325684e+00
    phi[5,2]  R1693     -3.0999999046325684e+00
    phi[5,2]  R1694     -2.2400000095367432e+00
    phi[5,2]  R1695     -2.2400000095367432e+00
    phi[5,2]  R1696     -3.0999999046325684e+00
    phi[5,2]  R1697     -3.0999999046325684e+00
    phi[5,2]  R1698     -2.5699999332427979e+00
    phi[5,2]  R1699     -2.5699999332427979e+00
    phi[5,2]  R1700     -3.0999999046325684e+00
    phi[5,2]  R1701     -3.0999999046325684e+00
    phi[5,2]  R1702     -2.0899999141693115e+00
    phi[5,2]  R1703     -2.0899999141693115e+00
    phi[5,2]  R1704     -3.0999999046325684e+00
    phi[5,2]  R1705     -3.0999999046325684e+00
    phi[5,2]  R1706     3.6585351824760437e-01
    phi[5,2]  R1707     6.4783477783203125e-01
    phi[5,2]  R1708     2.8783312439918518e-01
    phi[5,2]  R1709     -3.3419579267501831e-01
    phi[5,2]  R1710     -3.8654603064060211e-02
    phi[5,2]  R1711     -3.8230374455451965e-01
    phi[5,2]  R1712     -1.1140504479408264e-01
    phi[5,2]  R1713     -1.2809278964996338e+00
    phi[5,2]  R1714     -1.8217583000659943e-01
    phi[5,2]  R1715     7.8476691246032715e-01
    phi[5,2]  R1716     7.9176551103591919e-01
    phi[5,2]  R1717     2.4629805982112885e-01
    phi[5,2]  R1718     4.1538584232330322e-01
    phi[5,2]  R1719     -2.0035283565521240e+00
    phi[5,2]  R1720     1.2539389133453369e+00
    phi[5,2]  R1721     -2.2836899757385254e+00
    phi[5,2]  R1722     0.252595454454422
    phi[5,2]  R1723     3.1737816333770752e-01
    phi[5,2]  R1724     1.0776723623275757e+00
    phi[5,2]  R1725     -4.1990213096141815e-02
    phi[5,2]  R1726     -1.6295845508575439e+00
    phi[5,2]  R1727     5.7241827249526978e-01
    phi[5,2]  R1728     -9.9667298793792725e-01
    phi[5,2]  R1729     -4.1352930665016174e-01
    phi[5,2]  R1730     -6.9618147611618042e-01
    phi[5,2]  R1731     3.9993104338645935e-01
    phi[5,2]  R1732     -0.596386194229126
    phi[5,2]  R1733     -1.5543608665466309e+00
    phi[5,2]  R1734     -1.2189731746912003e-01
    phi[5,2]  R1735     1.3955628871917725e+00
    phi[5,2]  R1736     3.9716142416000366e-01
    phi[5,2]  R1737     9.4110108911991119e-02
    phi[5,2]  R1738     -7.0378565788269043e-01
    phi[5,2]  R1739     9.2047137022018433e-01
    phi[5,2]  R1740     0.299384206533432
    phi[5,2]  R1741     -2.0542659759521484e+00
    phi[5,2]  R1742     -1.5622515678405762e+00
    phi[5,2]  R1743     -1.4764670133590698e+00
    phi[5,2]  R1744     -1.1220639944076538e+00
    phi[5,2]  R1745     -1.5764595270156860e+00
    phi[5,2]  R1746     7.6698881387710571e-01
    phi[5,2]  R1747     1.5146030187606812e+00
    phi[5,2]  R1748     7.1752482652664185e-01
    phi[5,2]  R1749     6.0613554716110229e-01
    phi[5,2]  R1750     7.1540546417236328e-01
    phi[5,2]  R1751     4.4752874970436096e-01
    phi[5,2]  R1752     0.436477392911911
    phi[5,2]  R1753     2.5649794936180115e-01
    phi[5,2]  R1754     7.3551744222640991e-01
    phi[5,2]  R1755     1.4776686429977417e+00
    phi[5,2]  R1756     -2.1814320087432861e+00
    phi[5,2]  R1757     3.0235034227371216e-01
    phi[5,2]  R1758     -1.3693563640117645e-01
    phi[5,2]  R1759     -8.7340199947357178e-01
    phi[5,2]  R1760     -5.8996640145778656e-02
    phi[5,2]  R1761     -2.1620402336120605e+00
    phi[5,2]  R1762     -2.8184912204742432e+00
    phi[5,2]  R1763     -2.6938042044639587e-01
    phi[5,2]  R1764     -1.9580932855606079e+00
    phi[5,2]  R1765     -4.6835231781005859e-01
    phi[5,2]  R1766     -8.7909328937530518e-01
    phi[5,2]  R1767     -5.5021303892135620e-01
    phi[5,2]  R1768     -1.8325360119342804e-01
    phi[5,2]  R1769     4.6054601669311523e-01
    phi[5,2]  R1770     -3.5265591740608215e-01
    phi[5,2]  R1771     -1.7214349508285522e+00
    phi[5,2]  R1772     -2.9151445627212524e-01
    phi[5,2]  R1773     -6.6358792781829834e-01
    phi[5,2]  R1774     -6.7215710878372192e-01
    phi[5,2]  R1775     7.6747441291809082e-01
    phi[5,2]  R1776     -0.57674640417099
    phi[5,2]  R1777     -4.4487684965133667e-01
    phi[5,2]  R1778     -1.2324304580688477e+00
    phi[5,2]  R1779     -1.6218124628067017e+00
    phi[5,2]  R1780     0.327092707157135
    phi[5,2]  R1781     -5.7638436555862427e-01
    phi[5,2]  R1782     -1.6843650341033936e+00
    phi[5,2]  R1783     1.4579778909683228e-01
    phi[5,2]  R1784     -4.9343603849411011e-01
    phi[5,2]  R1785     -1.9866304397583008e+00
    phi[5,2]  R1786     -2.3450188636779785e+00
    phi[5,2]  R1787     4.0974387526512146e-01
    phi[5,2]  R1788     -1.3416094779968262e+00
    phi[5,2]  R1789     -1.2005747556686401e+00
    phi[5,2]  R1790     -5.5474698543548584e-01
    phi[5,2]  R1791     -1.3973701000213623e+00
    phi[5,2]  R1792     -1.6571727991104126e+00
    phi[5,2]  R1793     -5.5363941192626953e-01
    phi[5,2]  R1794     -1.7982462644577026e+00
    phi[5,2]  R1795     -1.2034163475036621e+00
    phi[5,2]  R1796     -2.1944010257720947e+00
    phi[5,2]  R1797     -7.7861803770065308e-01
    phi[5,2]  R1798     -1.9219276905059814e+00
    phi[5,2]  R1799     -1.4077451229095459e+00
    phi[5,2]  R1800     -4.7231793403625488e-01
    phi[5,2]  R1801     -1.7380250990390778e-01
    phi[5,2]  R1802     9.6614801883697510e-01
    phi[5,2]  R1803     3.9480510354042053e-01
    phi[5,2]  R1804     2.1665847301483154e+00
    phi[5,2]  R1805     1.4957511425018311e+00
    phi[5,2]  R1806     -2.5708334445953369e+00
    phi[5,2]  R1807     -1.3701149225234985e+00
    phi[5,2]  R1808     -0.444678395986557
    phi[5,2]  R1809     -1.4362951517105103e+00
    phi[5,2]  R1810     2.8492897748947144e-01
    phi[5,2]  R1811     6.3467703759670258e-02
    phi[5,2]  R1812     1.2392323017120361e+00
    phi[5,2]  R1813     2.3891956806182861e+00
    phi[5,2]  R1814     -1.8771700859069824e+00
    phi[5,2]  R1815     -7.1829926967620850e-01
    phi[5,2]  R1816     -6.5130412578582764e-01
    phi[5,2]  R1817     -6.2219995260238647e-01
    phi[5,2]  R1818     -8.1019508838653564e-01
    phi[5,2]  R1819     0.621577799320221
    phi[5,2]  R1820     -7.8086328506469727e-01
    phi[5,2]  R1821     1.5921211242675781e-01
    phi[5,2]  R1822     -2.0980694293975830e+00
    phi[5,2]  R1823     -6.1335884034633636e-02
    phi[5,2]  R1824     -5.3565853834152222e-01
    phi[5,2]  R1825     -2.8359022736549377e-01
    phi[2,7]  R18       1
    phi[2,7]  R19       1
    phi[2,7]  R20       2.7359062150079505e+00
    phi[2,7]  R21       -7.0629272807530219e-01
    phi[2,7]  R22       -5.3743823186215289e-01
    phi[2,7]  R23       -2.5121044811386191e+00
    phi[2,7]  R24       -2.8049010216032149e+00
    phi[2,7]  R25       -1.6649331117196753e+00
    phi[2,7]  R26       -1.7087547323619128e+00
    phi[2,7]  R55       -1
    phi[2,7]  R1826     -3.6409368962461786e-01
    phi[2,7]  R1827     -5.8359061196405193e+00
    phi[2,7]  R1828     -2.9462927376120454e+00
    phi[2,7]  R1829     -1.5337072814614410e+00
    phi[2,7]  R1830     -3.6374381364947213e+00
    phi[2,7]  R1831     -2.5625616727704155e+00
    phi[2,7]  R1832     -5.0821044143814174e+00
    phi[2,7]  R1833     -5.7895452104178791e-02
    phi[2,7]  R1834     -5.9049009262357828e+00
    phi[2,7]  R1835     -2.9509888302935350e-01
    phi[2,7]  R1836     -3.7549330258889868e+00
    phi[2,7]  R1837     -4.2506680244963624e-01
    phi[2,7]  R1838     -4.8087546369944807e+00
    phi[2,7]  R1839     -1.3912451722706556e+00
    phi[2,7]  R1840     -3.1296923235323471e-01
    phi[2,7]  R1841     -4.0220350816812989e-01
    phi[2,7]  R1842     -1.0392504876059709e+00
    phi[2,7]  R1843     -5.9296742746861542e-01
    phi[2,7]  R1844     -4.6733085534418084e-01
    phi[2,7]  R1845     -1.1254967458357628e+00
    phi[2,7]  R1846     -1.2891087780919872e+00
    phi[2,7]  R1847     -4.9791433386319373e-01
    phi[2,7]  R1848     -5.2223869079072571e-01
    phi[2,7]  R1849     -5.2268163761127528e-01
    phi[2,7]  R1850     -2.4776743881982410e-01
    phi[2,7]  R1851     -3.3015037691640314e-01
    phi[2,7]  R1852     -3.3366367577321093e-01
    phi[2,7]  R1853     -0.388683988231752
    phi[2,7]  R1854     -3.9306150153957820e-01
    phi[2,7]  R1855     -4.7448135220590304e-01
    phi[2,7]  R1856     -0.478103727537182
    phi[2,7]  R1857     -4.9075978750988941e-01
    phi[2,7]  R1858     -4.9265549686197607e-01
    phi[2,7]  R1859     -5.0034347785939559e-01
    phi[2,7]  R1860     -3.3679360483843235e-01
    phi[2,7]  R1861     -1.0653614770003439e+00
    phi[2,7]  R1862     -3.9686281317930888e-01
    phi[2,7]  R1863     -4.2795018833265419e-01
    phi[2,7]  R1864     -4.3997577496453166e-01
    phi[2,7]  R1865     -4.4357641974984663e-01
    phi[2,7]  R1866     -4.4543918595456644e-01
    phi[2,7]  R1867     -4.5928924108841018e-01
    phi[2,7]  R1868     -4.6635301628623460e-01
    phi[2,7]  R1869     -5.0089103329205287e-01
    phi[2,7]  R1870     -2.3659976919209857e-01
    phi[2,7]  R1871     -2.8265130022211626e-01
    phi[2,7]  R1872     -2.8678639735777267e-01
    phi[2,7]  R1873     -2.9384234123135422e-01
    phi[2,7]  R1874     -3.0538142594836282e-01
    phi[2,7]  R1875     -3.4250815238686527e-01
    phi[2,7]  R1876     -3.4429181361983985e-01
    phi[2,7]  R1877     -3.9642129141378868e-01
    phi[2,7]  R1878     -4.8315639290576023e-01
    phi[2,7]  R1879     -6.4673227461181293e-01
    phi[2,7]  R1880     -1.7941081829691363e-01
    phi[2,7]  R1881     -2.8704724057669961e-01
    phi[2,7]  R1882     -3.1675816765585019e-01
    phi[2,7]  R1883     -3.1848682902522829e-01
    phi[2,7]  R1884     -3.3255741231441710e-01
    phi[2,7]  R1885     -3.4327338104246596e-01
    phi[2,7]  R1886     -3.7097834222126691e-01
    phi[2,7]  R1887     -3.9256726315258555e-01
    phi[2,7]  R1888     -1.3631802114784608e+00
    phi[2,7]  R1889     -4.8438082576457442e-01
    phi[2,7]  R1890     -2.0151577048551661e-01
    phi[2,7]  R1891     -1.0201813538348010e+00
    phi[2,7]  R1892     -3.4864257882290084e-01
    phi[2,7]  R1893     -9.5795453794783769e-01
    phi[2,7]  R1894     -4.2494136398166926e-01
    phi[2,7]  R1895     -1.9316137567321148e+00
    phi[2,7]  R1896     -4.9799408629538755e-01
    phi[2,7]  R1897     -5.8898428291366922e-01
    phi[2,7]  R1898     -0.7018427538337
    phi[2,7]  R1899     -0.72315239378546
    phi[2,7]  R1900     -2.8133050099739965e-01
    phi[2,7]  R1901     -2.8433231305193463e-01
    phi[2,7]  R1902     -8.4092514076066927e-01
    phi[2,7]  R1903     -3.9119762277229486e-01
    phi[2,7]  R1904     -2.2370770103941364e+00
    phi[2,7]  R1905     -4.3496518054220312e-01
    phi[2,7]  R1906     -5.3103719176572106e-01
    phi[2,7]  R1907     -5.4792932931133764e-01
    phi[2,7]  R1908     -8.2064253964014489e-01
    phi[2,7]  R1909     -8.7370434675024544e-01
    phi[2,7]  R1910     -2.1380622683923856e-01
    phi[2,7]  R1911     -1.6676729698324233e+00
    phi[2,7]  R1912     -3.7651441029928423e-01
    phi[2,7]  R1913     -4.1765888715070654e-01
    phi[2,7]  R1914     -4.2293153841411157e-01
    phi[2,7]  R1915     -5.9796397034943483e-01
    phi[2,7]  R1916     -6.0630965789785018e-01
    phi[2,7]  R1917     -1.8898038574933205e+00
    phi[2,7]  R1918     -9.4297030957084149e-01
    phi[2,7]  R1919     -9.5397572197606473e-01
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R1920     -3.0999999046325684e+00
    phi[3,4]  R1921     -3.0999999046325684e+00
    phi[3,4]  R1922     -2.2400000095367432e+00
    phi[3,4]  R1923     -2.2400000095367432e+00
    phi[3,4]  R1924     -3.0999999046325684e+00
    phi[3,4]  R1925     -3.0999999046325684e+00
    phi[3,4]  R1926     -2.5699999332427979e+00
    phi[3,4]  R1927     -2.5699999332427979e+00
    phi[3,4]  R1928     -3.0999999046325684e+00
    phi[3,4]  R1929     -3.0999999046325684e+00
    phi[3,4]  R1930     -2.0899999141693115e+00
    phi[3,4]  R1931     -2.0899999141693115e+00
    phi[3,4]  R1932     -3.0999999046325684e+00
    phi[3,4]  R1933     -3.0999999046325684e+00
    phi[3,4]  R1934     9.6314847469329834e-01
    phi[3,4]  R1935     0.960550844669342
    phi[3,4]  R1936     1.3743402957916260e+00
    phi[3,4]  R1937     1.1893818378448486e+00
    phi[3,4]  R1938     1.3840620517730713e+00
    phi[3,4]  R1939     8.8364201784133911e-01
    phi[3,4]  R1940     1.4328553676605225e+00
    phi[3,4]  R1941     7.8162901103496552e-02
    phi[3,4]  R1942     1.7502503395080566e+00
    phi[3,4]  R1943     9.7523730993270874e-01
    phi[3,4]  R1944     -1.8237093687057495e+00
    phi[3,4]  R1945     -1.8392630815505981e+00
    phi[3,4]  R1946     -1.8007401227951050e+00
    phi[3,4]  R1947     -2.5955519676208496e+00
    phi[3,4]  R1948     -3.1359648704528809e-01
    phi[3,4]  R1949     -1.0644038915634155e+00
    phi[3,4]  R1950     -1.8577504903078079e-02
    phi[3,4]  R1951     -2.6399847865104675e-01
    phi[3,4]  R1952     -1.3170360326766968e+00
    phi[3,4]  R1953     -1.5790328979492188e+00
    phi[3,4]  R1954     -2.3304946422576904e+00
    phi[3,4]  R1955     -3.5896944999694824e+00
    phi[3,4]  R1956     5.0934958457946777e-01
    phi[3,4]  R1957     -1.0928772389888763e-01
    phi[3,4]  R1958     -2.7448687553405762e+00
    phi[3,4]  R1959     -2.7660226821899414e+00
    phi[3,4]  R1960     1.8788412809371948e+00
    phi[3,4]  R1961     -8.9053803682327271e-01
    phi[3,4]  R1962     1.0950303077697754e+00
    phi[3,4]  R1963     7.2714394330978394e-01
    phi[3,4]  R1964     -1.4358063936233521e+00
    phi[3,4]  R1965     -1.7135733366012573e+00
    phi[3,4]  R1966     -7.7095526456832886e-01
    phi[3,4]  R1967     -2.0472218990325928e+00
    phi[3,4]  R1968     -1.3490383625030518e+00
    phi[3,4]  R1969     -8.2180166244506836e-01
    phi[3,4]  R1970     -2.2112317085266113e+00
    phi[3,4]  R1971     1.1089618504047394e-01
    phi[3,4]  R1972     3.0463927984237671e-01
    phi[3,4]  R1973     1.2539277076721191e+00
    phi[3,4]  R1974     -1.6471302509307861e+00
    phi[3,4]  R1975     -2.0244398117065430e+00
    phi[3,4]  R1976     -2.8703789710998535e+00
    phi[3,4]  R1977     -2.9911041259765625e+00
    phi[3,4]  R1978     3.2949250936508179e-01
    phi[3,4]  R1979     4.4693106412887573e-01
    phi[3,4]  R1980     -3.7081069946289062e+00
    phi[3,4]  R1981     -9.6719181537628174e-01
    phi[3,4]  R1982     5.2185666561126709e-01
    phi[3,4]  R1983     -2.1560356616973877e+00
    phi[3,4]  R1984     -1.0176507234573364e+00
    phi[3,4]  R1985     -2.5792727470397949e+00
    phi[3,4]  R1986     -3.1357989311218262e+00
    phi[3,4]  R1987     -1.2313365936279297e+00
    phi[3,4]  R1988     -2.4998769760131836e+00
    phi[3,4]  R1989     6.8935108184814453e-01
    phi[3,4]  R1990     1.6830998659133911e+00
    phi[3,4]  R1991     8.9807915687561035e-01
    phi[3,4]  R1992     -1.7425943613052368e+00
    phi[3,4]  R1993     3.5300529003143311e-01
    phi[3,4]  R1994     -1.1349966526031494e+00
    phi[3,4]  R1995     -1.1427879333496094e+00
    phi[3,4]  R1996     -7.2888344526290894e-01
    phi[3,4]  R1997     -7.4036091566085815e-01
    phi[3,4]  R1998     -9.2340862751007080e-01
    phi[3,4]  R1999     -4.0682223439216614e-01
    phi[3,4]  R2000     -6.4768642187118530e-01
    phi[3,4]  R2001     -1.8927834033966064e+00
    phi[3,4]  R2002     -4.7784546017646790e-01
    phi[3,4]  R2003     -9.3285769224166870e-01
    phi[3,4]  R2004     1.1380215883255005e+00
    phi[3,4]  R2005     6.9943785667419434e-01
    phi[3,4]  R2006     -8.2722121477127075e-01
    phi[3,4]  R2007     7.4775010347366333e-01
    phi[3,4]  R2008     1.4682742357254028e+00
    phi[3,4]  R2009     1.5242244005203247e+00
    phi[3,4]  R2010     1.4790067672729492e+00
    phi[3,4]  R2011     -5.5802255868911743e-01
    phi[3,4]  R2012     8.3793580532073975e-01
    phi[3,4]  R2013     2.0132152736186981e-01
    phi[3,4]  R2014     -1.9470099210739136e+00
    phi[3,4]  R2015     -1.3906112909317017e+00
    phi[3,4]  R2016     8.8488626480102539e-01
    phi[3,4]  R2017     -1.9665704667568207e-01
    phi[3,4]  R2018     3.6203145980834961e-01
    phi[3,4]  R2019     -1.7883622646331787e+00
    phi[3,4]  R2020     -8.2152163982391357e-01
    phi[3,4]  R2021     1.5952751040458679e-01
    phi[3,4]  R2022     -1.2830153107643127e-01
    phi[3,4]  R2023     -0.751623272895813
    phi[3,4]  R2024     -1.3494781255722046e+00
    phi[3,4]  R2025     -1.84017014503479
    phi[3,4]  R2026     3.6190178990364075e-01
    phi[3,4]  R2027     2.6068103313446045e-01
    phi[3,4]  R2028     -5.7612460851669312e-01
    phi[3,4]  R2029     -9.3409514427185059e-01
    phi[3,4]  R2030     6.1517262458801270e-01
    phi[3,4]  R2031     3.9461475610733032e-01
    phi[3,4]  R2032     -9.8060362040996552e-02
    phi[3,4]  R2033     1.4719067513942719e-01
    phi[3,4]  R2034     4.5779719948768616e-01
    phi[3,4]  R2035     -2.0165763795375824e-01
    phi[3,4]  R2036     2.3757264018058777e-01
    phi[3,4]  R2037     4.3969199061393738e-01
    phi[3,4]  R2038     -0.282153844833374
    phi[3,4]  R2039     -1.4814805984497070e+00
    phi[3,4]  R2040     -7.8956365585327148e-01
    phi[3,4]  R2041     1.1392768621444702e+00
    phi[3,4]  R2042     1.0514466762542725e+00
    phi[3,4]  R2043     1.1114830970764160e+00
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R2044     -3.0999999046325684e+00
    phi[4,3]  R2045     -3.0999999046325684e+00
    phi[4,3]  R2046     -2.2400000095367432e+00
    phi[4,3]  R2047     -2.2400000095367432e+00
    phi[4,3]  R2048     -3.0999999046325684e+00
    phi[4,3]  R2049     -3.0999999046325684e+00
    phi[4,3]  R2050     -2.5699999332427979e+00
    phi[4,3]  R2051     -2.5699999332427979e+00
    phi[4,3]  R2052     -3.0999999046325684e+00
    phi[4,3]  R2053     -3.0999999046325684e+00
    phi[4,3]  R2054     -2.0899999141693115e+00
    phi[4,3]  R2055     -2.0899999141693115e+00
    phi[4,3]  R2056     -3.0999999046325684e+00
    phi[4,3]  R2057     -3.0999999046325684e+00
    phi[4,3]  R2058     -1.1349966526031494e+00
    phi[4,3]  R2059     -1.1427879333496094e+00
    phi[4,3]  R2060     -7.2888344526290894e-01
    phi[4,3]  R2061     -7.4036091566085815e-01
    phi[4,3]  R2062     -9.2340862751007080e-01
    phi[4,3]  R2063     -4.0682223439216614e-01
    phi[4,3]  R2064     -6.4768642187118530e-01
    phi[4,3]  R2065     -1.8927834033966064e+00
    phi[4,3]  R2066     -4.7784546017646790e-01
    phi[4,3]  R2067     -9.3285769224166870e-01
    phi[4,3]  R2068     1.1380215883255005e+00
    phi[4,3]  R2069     6.9943785667419434e-01
    phi[4,3]  R2070     -8.2722121477127075e-01
    phi[4,3]  R2071     7.4775010347366333e-01
    phi[4,3]  R2072     1.4682742357254028e+00
    phi[4,3]  R2073     1.5242244005203247e+00
    phi[4,3]  R2074     1.4790067672729492e+00
    phi[4,3]  R2075     -5.5802255868911743e-01
    phi[4,3]  R2076     8.3793580532073975e-01
    phi[4,3]  R2077     2.0132152736186981e-01
    phi[4,3]  R2078     -1.9470099210739136e+00
    phi[4,3]  R2079     -1.3906112909317017e+00
    phi[4,3]  R2080     8.8488626480102539e-01
    phi[4,3]  R2081     -1.9665704667568207e-01
    phi[4,3]  R2082     3.6203145980834961e-01
    phi[4,3]  R2083     -1.7883622646331787e+00
    phi[4,3]  R2084     -8.2152163982391357e-01
    phi[4,3]  R2085     1.5952751040458679e-01
    phi[4,3]  R2086     -1.2830153107643127e-01
    phi[4,3]  R2087     -0.751623272895813
    phi[4,3]  R2088     -1.3494781255722046e+00
    phi[4,3]  R2089     -1.84017014503479
    phi[4,3]  R2090     3.6190178990364075e-01
    phi[4,3]  R2091     2.6068103313446045e-01
    phi[4,3]  R2092     -5.7612460851669312e-01
    phi[4,3]  R2093     -9.3409514427185059e-01
    phi[4,3]  R2094     6.1517262458801270e-01
    phi[4,3]  R2095     3.9461475610733032e-01
    phi[4,3]  R2096     -9.8060362040996552e-02
    phi[4,3]  R2097     1.4719067513942719e-01
    phi[4,3]  R2098     4.5779719948768616e-01
    phi[4,3]  R2099     -2.0165763795375824e-01
    phi[4,3]  R2100     2.3757264018058777e-01
    phi[4,3]  R2101     4.3969199061393738e-01
    phi[4,3]  R2102     -0.282153844833374
    phi[4,3]  R2103     -1.4814805984497070e+00
    phi[4,3]  R2104     -7.8956365585327148e-01
    phi[4,3]  R2105     1.1392768621444702e+00
    phi[4,3]  R2106     1.0514466762542725e+00
    phi[4,3]  R2107     1.1114830970764160e+00
    phi[4,3]  R2108     9.6314847469329834e-01
    phi[4,3]  R2109     0.960550844669342
    phi[4,3]  R2110     1.3743402957916260e+00
    phi[4,3]  R2111     1.1893818378448486e+00
    phi[4,3]  R2112     1.3840620517730713e+00
    phi[4,3]  R2113     8.8364201784133911e-01
    phi[4,3]  R2114     1.4328553676605225e+00
    phi[4,3]  R2115     7.8162901103496552e-02
    phi[4,3]  R2116     1.7502503395080566e+00
    phi[4,3]  R2117     9.7523730993270874e-01
    phi[4,3]  R2118     -1.8237093687057495e+00
    phi[4,3]  R2119     -1.8392630815505981e+00
    phi[4,3]  R2120     -1.8007401227951050e+00
    phi[4,3]  R2121     -2.5955519676208496e+00
    phi[4,3]  R2122     -3.1359648704528809e-01
    phi[4,3]  R2123     -1.0644038915634155e+00
    phi[4,3]  R2124     -1.8577504903078079e-02
    phi[4,3]  R2125     -2.6399847865104675e-01
    phi[4,3]  R2126     -1.3170360326766968e+00
    phi[4,3]  R2127     -1.5790328979492188e+00
    phi[4,3]  R2128     -2.3304946422576904e+00
    phi[4,3]  R2129     -3.5896944999694824e+00
    phi[4,3]  R2130     5.0934958457946777e-01
    phi[4,3]  R2131     -1.0928772389888763e-01
    phi[4,3]  R2132     -2.7448687553405762e+00
    phi[4,3]  R2133     -2.7660226821899414e+00
    phi[4,3]  R2134     1.8788412809371948e+00
    phi[4,3]  R2135     -8.9053803682327271e-01
    phi[4,3]  R2136     1.0950303077697754e+00
    phi[4,3]  R2137     7.2714394330978394e-01
    phi[4,3]  R2138     -1.4358063936233521e+00
    phi[4,3]  R2139     -1.7135733366012573e+00
    phi[4,3]  R2140     -7.7095526456832886e-01
    phi[4,3]  R2141     -2.0472218990325928e+00
    phi[4,3]  R2142     -1.3490383625030518e+00
    phi[4,3]  R2143     -8.2180166244506836e-01
    phi[4,3]  R2144     -2.2112317085266113e+00
    phi[4,3]  R2145     1.1089618504047394e-01
    phi[4,3]  R2146     3.0463927984237671e-01
    phi[4,3]  R2147     1.2539277076721191e+00
    phi[4,3]  R2148     -1.6471302509307861e+00
    phi[4,3]  R2149     -2.0244398117065430e+00
    phi[4,3]  R2150     -2.8703789710998535e+00
    phi[4,3]  R2151     -2.9911041259765625e+00
    phi[4,3]  R2152     3.2949250936508179e-01
    phi[4,3]  R2153     4.4693106412887573e-01
    phi[4,3]  R2154     -3.7081069946289062e+00
    phi[4,3]  R2155     -9.6719181537628174e-01
    phi[4,3]  R2156     5.2185666561126709e-01
    phi[4,3]  R2157     -2.1560356616973877e+00
    phi[4,3]  R2158     -1.0176507234573364e+00
    phi[4,3]  R2159     -2.5792727470397949e+00
    phi[4,3]  R2160     -3.1357989311218262e+00
    phi[4,3]  R2161     -1.2313365936279297e+00
    phi[4,3]  R2162     -2.4998769760131836e+00
    phi[4,3]  R2163     6.8935108184814453e-01
    phi[4,3]  R2164     1.6830998659133911e+00
    phi[4,3]  R2165     8.9807915687561035e-01
    phi[4,3]  R2166     -1.7425943613052368e+00
    phi[4,3]  R2167     3.5300529003143311e-01
    phi[6,3]  R27       -1
    phi[6,3]  R29       -2.6378120462742412e+00
    phi[6,3]  R30       1.7539923790988148e+00
    phi[6,3]  R31       1.0896098196541497e+00
    phi[6,3]  R32       -2.2967377102008397e+00
    phi[6,3]  R33       -8.0463834768247766e-01
    phi[6,3]  R34       -1.6750513392469486e+00
    phi[6,3]  R35       -2.81952984395939
    phi[6,3]  R54       1
    phi[6,3]  R2168     -4.6218785835832721e-01
    phi[6,3]  R2169     -5.73781195090681
    phi[6,3]  R2170     -3.9939923886355579e+00
    phi[6,3]  R2171     -4.8600763043792838e-01
    phi[6,3]  R2172     -4.1896097242867185e+00
    phi[6,3]  R2173     -2.0103900849784186e+00
    phi[6,3]  R2174     -2.7326222304195813e-01
    phi[6,3]  R2175     -4.8667376434436376e+00
    phi[6,3]  R2176     -2.2953615569500907e+00
    phi[6,3]  R2177     -3.9046382523150460e+00
    phi[6,3]  R2178     -4.1494857492236292e-01
    phi[6,3]  R2179     -3.76505125341626
    phi[6,3]  R2180     -2.8047006067317826e-01
    phi[6,3]  R2181     -5.9195297485919589e+00
    phi[6,3]  R2182     -8.3498185048535678e-02
    phi[6,3]  R2183     -8.6777711936305568e-02
    phi[6,3]  R2184     -9.0297618126280232e-02
    phi[6,3]  R2185     -5.1449149495936686e-01
    phi[6,3]  R2186     -1.1554786429826813e+00
    phi[6,3]  R2187     -3.9043994366371182e-01
    phi[6,3]  R2188     -9.3845563748450633e-01
    phi[6,3]  R2189     -5.3878006089830022e-01
    phi[6,3]  R2190     -1.2010000126170937e+00
    phi[6,3]  R2191     -1.2526248523442267e+00
    phi[6,3]  R2192     -0.0912932642321509
    phi[6,3]  R2193     -1.1605436178803274e-01
    phi[6,3]  R2194     -1.4414635467381842e-01
    phi[6,3]  R2195     -4.1320400899904941e-01
    phi[6,3]  R2196     -4.1326274039664734e-01
    phi[6,3]  R2197     -4.1430240796066720e-01
    phi[6,3]  R2198     -4.4161071099633020e-01
    phi[6,3]  R2199     -4.4860979062600154e-01
    phi[6,3]  R2200     -4.5293788329582707e-01
    phi[6,3]  R2201     -4.5539154963670314e-01
    phi[6,3]  R2202     -2.0746160148945858e-01
    phi[6,3]  R2203     -3.5270503491646954e-01
    phi[6,3]  R2204     -3.6050015474156738e-01
    phi[6,3]  R2205     -3.6374488925462767e-01
    phi[6,3]  R2206     -3.7053613191482082e-01
    phi[6,3]  R2207     -3.7268413926168664e-01
    phi[6,3]  R2208     -3.7318513126354480e-01
    phi[6,3]  R2209     -3.7831533169467924e-01
    phi[6,3]  R2210     -3.8714963767697608e-01
    phi[6,3]  R2211     -3.9626164918185269e-01
    phi[6,3]  R2212     -3.4848856769337355e-01
    phi[6,3]  R2213     -3.5124878627794032e-01
    phi[6,3]  R2214     -3.6490076958031975e-01
    phi[6,3]  R2215     -3.6994320531864489e-01
    phi[6,3]  R2216     -3.7953283124158188e-01
    phi[6,3]  R2217     -3.9006449181827996e-01
    phi[6,3]  R2218     -3.9441877490750121e-01
    phi[6,3]  R2219     -3.9474853674688104e-01
    phi[6,3]  R2220     -3.9786873410457058e-01
    phi[6,3]  R2221     -4.0467433669787756e-01
    phi[6,3]  R2222     -0.340262163860912
    phi[6,3]  R2223     -3.4861067598245943e-01
    phi[6,3]  R2224     -3.6414242787785511e-01
    phi[6,3]  R2225     -3.6450599941869788e-01
    phi[6,3]  R2226     -3.7377131602386737e-01
    phi[6,3]  R2227     -3.7390915012257897e-01
    phi[6,3]  R2228     -3.8009508620493104e-01
    phi[6,3]  R2229     -3.8404803858278691e-01
    phi[6,3]  R2230     -3.9234141832767611e-01
    phi[6,3]  R2231     -3.9451106856052864e-01
    phi[6,3]  R2232     -3.2631997443127980e-01
    phi[6,3]  R2233     -0.339979770837322
    phi[6,3]  R2234     -3.4076986850382340e-01
    phi[6,3]  R2235     -3.6328326687216594e-01
    phi[6,3]  R2236     -3.7605178417251128e-01
    phi[6,3]  R2237     -3.7755418424292886e-01
    phi[6,3]  R2238     -3.8062934011224536e-01
    phi[6,3]  R2239     -4.0048126129504835e-01
    phi[6,3]  R2240     -4.0065399707983818e-01
    phi[6,3]  R2241     -4.0553558882332075e-01
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R2242     -3.0999999046325684e+00
    phi[4,5]  R2243     -3.0999999046325684e+00
    phi[4,5]  R2244     -2.2400000095367432e+00
    phi[4,5]  R2245     -2.2400000095367432e+00
    phi[4,5]  R2246     -3.0999999046325684e+00
    phi[4,5]  R2247     -3.0999999046325684e+00
    phi[4,5]  R2248     -2.5699999332427979e+00
    phi[4,5]  R2249     -2.5699999332427979e+00
    phi[4,5]  R2250     -3.0999999046325684e+00
    phi[4,5]  R2251     -3.0999999046325684e+00
    phi[4,5]  R2252     -2.0899999141693115e+00
    phi[4,5]  R2253     -2.0899999141693115e+00
    phi[4,5]  R2254     -3.0999999046325684e+00
    phi[4,5]  R2255     -3.0999999046325684e+00
    phi[4,5]  R2256     -1.1349966526031494e+00
    phi[4,5]  R2257     -1.1427879333496094e+00
    phi[4,5]  R2258     -7.2888344526290894e-01
    phi[4,5]  R2259     -7.4036091566085815e-01
    phi[4,5]  R2260     -9.2340862751007080e-01
    phi[4,5]  R2261     -4.0682223439216614e-01
    phi[4,5]  R2262     -6.4768642187118530e-01
    phi[4,5]  R2263     -1.8927834033966064e+00
    phi[4,5]  R2264     -4.7784546017646790e-01
    phi[4,5]  R2265     -9.3285769224166870e-01
    phi[4,5]  R2266     1.1380215883255005e+00
    phi[4,5]  R2267     6.9943785667419434e-01
    phi[4,5]  R2268     -8.2722121477127075e-01
    phi[4,5]  R2269     7.4775010347366333e-01
    phi[4,5]  R2270     1.4682742357254028e+00
    phi[4,5]  R2271     1.5242244005203247e+00
    phi[4,5]  R2272     1.4790067672729492e+00
    phi[4,5]  R2273     -5.5802255868911743e-01
    phi[4,5]  R2274     8.3793580532073975e-01
    phi[4,5]  R2275     2.0132152736186981e-01
    phi[4,5]  R2276     -1.9470099210739136e+00
    phi[4,5]  R2277     -1.3906112909317017e+00
    phi[4,5]  R2278     8.8488626480102539e-01
    phi[4,5]  R2279     -1.9665704667568207e-01
    phi[4,5]  R2280     3.6203145980834961e-01
    phi[4,5]  R2281     -1.7883622646331787e+00
    phi[4,5]  R2282     -8.2152163982391357e-01
    phi[4,5]  R2283     1.5952751040458679e-01
    phi[4,5]  R2284     -1.2830153107643127e-01
    phi[4,5]  R2285     -0.751623272895813
    phi[4,5]  R2286     -1.3494781255722046e+00
    phi[4,5]  R2287     -1.84017014503479
    phi[4,5]  R2288     3.6190178990364075e-01
    phi[4,5]  R2289     2.6068103313446045e-01
    phi[4,5]  R2290     -5.7612460851669312e-01
    phi[4,5]  R2291     -9.3409514427185059e-01
    phi[4,5]  R2292     6.1517262458801270e-01
    phi[4,5]  R2293     3.9461475610733032e-01
    phi[4,5]  R2294     -9.8060362040996552e-02
    phi[4,5]  R2295     1.4719067513942719e-01
    phi[4,5]  R2296     4.5779719948768616e-01
    phi[4,5]  R2297     -2.0165763795375824e-01
    phi[4,5]  R2298     2.3757264018058777e-01
    phi[4,5]  R2299     4.3969199061393738e-01
    phi[4,5]  R2300     -0.282153844833374
    phi[4,5]  R2301     -1.4814805984497070e+00
    phi[4,5]  R2302     -7.8956365585327148e-01
    phi[4,5]  R2303     1.1392768621444702e+00
    phi[4,5]  R2304     1.0514466762542725e+00
    phi[4,5]  R2305     1.1114830970764160e+00
    phi[4,5]  R2306     3.6585351824760437e-01
    phi[4,5]  R2307     6.4783477783203125e-01
    phi[4,5]  R2308     2.8783312439918518e-01
    phi[4,5]  R2309     -3.3419579267501831e-01
    phi[4,5]  R2310     -3.8654603064060211e-02
    phi[4,5]  R2311     -3.8230374455451965e-01
    phi[4,5]  R2312     -1.1140504479408264e-01
    phi[4,5]  R2313     -1.2809278964996338e+00
    phi[4,5]  R2314     -1.8217583000659943e-01
    phi[4,5]  R2315     7.8476691246032715e-01
    phi[4,5]  R2316     7.9176551103591919e-01
    phi[4,5]  R2317     2.4629805982112885e-01
    phi[4,5]  R2318     4.1538584232330322e-01
    phi[4,5]  R2319     -2.0035283565521240e+00
    phi[4,5]  R2320     1.2539389133453369e+00
    phi[4,5]  R2321     -2.2836899757385254e+00
    phi[4,5]  R2322     0.252595454454422
    phi[4,5]  R2323     3.1737816333770752e-01
    phi[4,5]  R2324     1.0776723623275757e+00
    phi[4,5]  R2325     -4.1990213096141815e-02
    phi[4,5]  R2326     -1.6295845508575439e+00
    phi[4,5]  R2327     5.7241827249526978e-01
    phi[4,5]  R2328     -9.9667298793792725e-01
    phi[4,5]  R2329     -4.1352930665016174e-01
    phi[4,5]  R2330     -6.9618147611618042e-01
    phi[4,5]  R2331     3.9993104338645935e-01
    phi[4,5]  R2332     -0.596386194229126
    phi[4,5]  R2333     -1.5543608665466309e+00
    phi[4,5]  R2334     -1.2189731746912003e-01
    phi[4,5]  R2335     1.3955628871917725e+00
    phi[4,5]  R2336     3.9716142416000366e-01
    phi[4,5]  R2337     9.4110108911991119e-02
    phi[4,5]  R2338     -7.0378565788269043e-01
    phi[4,5]  R2339     9.2047137022018433e-01
    phi[4,5]  R2340     0.299384206533432
    phi[4,5]  R2341     -2.0542659759521484e+00
    phi[4,5]  R2342     -1.5622515678405762e+00
    phi[4,5]  R2343     -1.4764670133590698e+00
    phi[4,5]  R2344     -1.1220639944076538e+00
    phi[4,5]  R2345     -1.5764595270156860e+00
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R2346     -3.0999999046325684e+00
    phi[5,4]  R2347     -3.0999999046325684e+00
    phi[5,4]  R2348     -2.2400000095367432e+00
    phi[5,4]  R2349     -2.2400000095367432e+00
    phi[5,4]  R2350     -3.0999999046325684e+00
    phi[5,4]  R2351     -3.0999999046325684e+00
    phi[5,4]  R2352     -2.5699999332427979e+00
    phi[5,4]  R2353     -2.5699999332427979e+00
    phi[5,4]  R2354     -3.0999999046325684e+00
    phi[5,4]  R2355     -3.0999999046325684e+00
    phi[5,4]  R2356     -2.0899999141693115e+00
    phi[5,4]  R2357     -2.0899999141693115e+00
    phi[5,4]  R2358     -3.0999999046325684e+00
    phi[5,4]  R2359     -3.0999999046325684e+00
    phi[5,4]  R2360     3.6585351824760437e-01
    phi[5,4]  R2361     6.4783477783203125e-01
    phi[5,4]  R2362     2.8783312439918518e-01
    phi[5,4]  R2363     -3.3419579267501831e-01
    phi[5,4]  R2364     -3.8654603064060211e-02
    phi[5,4]  R2365     -3.8230374455451965e-01
    phi[5,4]  R2366     -1.1140504479408264e-01
    phi[5,4]  R2367     -1.2809278964996338e+00
    phi[5,4]  R2368     -1.8217583000659943e-01
    phi[5,4]  R2369     7.8476691246032715e-01
    phi[5,4]  R2370     7.9176551103591919e-01
    phi[5,4]  R2371     2.4629805982112885e-01
    phi[5,4]  R2372     4.1538584232330322e-01
    phi[5,4]  R2373     -2.0035283565521240e+00
    phi[5,4]  R2374     1.2539389133453369e+00
    phi[5,4]  R2375     -2.2836899757385254e+00
    phi[5,4]  R2376     0.252595454454422
    phi[5,4]  R2377     3.1737816333770752e-01
    phi[5,4]  R2378     1.0776723623275757e+00
    phi[5,4]  R2379     -4.1990213096141815e-02
    phi[5,4]  R2380     -1.6295845508575439e+00
    phi[5,4]  R2381     5.7241827249526978e-01
    phi[5,4]  R2382     -9.9667298793792725e-01
    phi[5,4]  R2383     -4.1352930665016174e-01
    phi[5,4]  R2384     -6.9618147611618042e-01
    phi[5,4]  R2385     3.9993104338645935e-01
    phi[5,4]  R2386     -0.596386194229126
    phi[5,4]  R2387     -1.5543608665466309e+00
    phi[5,4]  R2388     -1.2189731746912003e-01
    phi[5,4]  R2389     1.3955628871917725e+00
    phi[5,4]  R2390     3.9716142416000366e-01
    phi[5,4]  R2391     9.4110108911991119e-02
    phi[5,4]  R2392     -7.0378565788269043e-01
    phi[5,4]  R2393     9.2047137022018433e-01
    phi[5,4]  R2394     0.299384206533432
    phi[5,4]  R2395     -2.0542659759521484e+00
    phi[5,4]  R2396     -1.5622515678405762e+00
    phi[5,4]  R2397     -1.4764670133590698e+00
    phi[5,4]  R2398     -1.1220639944076538e+00
    phi[5,4]  R2399     -1.5764595270156860e+00
    phi[5,4]  R2400     -1.1349966526031494e+00
    phi[5,4]  R2401     -1.1427879333496094e+00
    phi[5,4]  R2402     -7.2888344526290894e-01
    phi[5,4]  R2403     -7.4036091566085815e-01
    phi[5,4]  R2404     -9.2340862751007080e-01
    phi[5,4]  R2405     -4.0682223439216614e-01
    phi[5,4]  R2406     -6.4768642187118530e-01
    phi[5,4]  R2407     -1.8927834033966064e+00
    phi[5,4]  R2408     -4.7784546017646790e-01
    phi[5,4]  R2409     -9.3285769224166870e-01
    phi[5,4]  R2410     1.1380215883255005e+00
    phi[5,4]  R2411     6.9943785667419434e-01
    phi[5,4]  R2412     -8.2722121477127075e-01
    phi[5,4]  R2413     7.4775010347366333e-01
    phi[5,4]  R2414     1.4682742357254028e+00
    phi[5,4]  R2415     1.5242244005203247e+00
    phi[5,4]  R2416     1.4790067672729492e+00
    phi[5,4]  R2417     -5.5802255868911743e-01
    phi[5,4]  R2418     8.3793580532073975e-01
    phi[5,4]  R2419     2.0132152736186981e-01
    phi[5,4]  R2420     -1.9470099210739136e+00
    phi[5,4]  R2421     -1.3906112909317017e+00
    phi[5,4]  R2422     8.8488626480102539e-01
    phi[5,4]  R2423     -1.9665704667568207e-01
    phi[5,4]  R2424     3.6203145980834961e-01
    phi[5,4]  R2425     -1.7883622646331787e+00
    phi[5,4]  R2426     -8.2152163982391357e-01
    phi[5,4]  R2427     1.5952751040458679e-01
    phi[5,4]  R2428     -1.2830153107643127e-01
    phi[5,4]  R2429     -0.751623272895813
    phi[5,4]  R2430     -1.3494781255722046e+00
    phi[5,4]  R2431     -1.84017014503479
    phi[5,4]  R2432     3.6190178990364075e-01
    phi[5,4]  R2433     2.6068103313446045e-01
    phi[5,4]  R2434     -5.7612460851669312e-01
    phi[5,4]  R2435     -9.3409514427185059e-01
    phi[5,4]  R2436     6.1517262458801270e-01
    phi[5,4]  R2437     3.9461475610733032e-01
    phi[5,4]  R2438     -9.8060362040996552e-02
    phi[5,4]  R2439     1.4719067513942719e-01
    phi[5,4]  R2440     4.5779719948768616e-01
    phi[5,4]  R2441     -2.0165763795375824e-01
    phi[5,4]  R2442     2.3757264018058777e-01
    phi[5,4]  R2443     4.3969199061393738e-01
    phi[5,4]  R2444     -0.282153844833374
    phi[5,4]  R2445     -1.4814805984497070e+00
    phi[5,4]  R2446     -7.8956365585327148e-01
    phi[5,4]  R2447     1.1392768621444702e+00
    phi[5,4]  R2448     1.0514466762542725e+00
    phi[5,4]  R2449     1.1114830970764160e+00
    phi[5,7]  R45       1
    phi[5,7]  R46       1
    phi[5,7]  R47       2.7359062150079505e+00
    phi[5,7]  R48       -7.0629272807530219e-01
    phi[5,7]  R49       -5.3743823186215289e-01
    phi[5,7]  R50       -2.5121044811386191e+00
    phi[5,7]  R51       -2.8049010216032149e+00
    phi[5,7]  R52       -1.6649331117196753e+00
    phi[5,7]  R53       -1.7087547323619128e+00
    phi[5,7]  R55       -1
    phi[5,7]  R2450     -3.6409368962461786e-01
    phi[5,7]  R2451     -5.8359061196405193e+00
    phi[5,7]  R2452     -2.9462927376120454e+00
    phi[5,7]  R2453     -1.5337072814614410e+00
    phi[5,7]  R2454     -3.6374381364947213e+00
    phi[5,7]  R2455     -2.5625616727704155e+00
    phi[5,7]  R2456     -5.0821044143814174e+00
    phi[5,7]  R2457     -5.7895452104178791e-02
    phi[5,7]  R2458     -5.9049009262357828e+00
    phi[5,7]  R2459     -2.9509888302935350e-01
    phi[5,7]  R2460     -3.7549330258889868e+00
    phi[5,7]  R2461     -4.2506680244963624e-01
    phi[5,7]  R2462     -4.8087546369944807e+00
    phi[5,7]  R2463     -1.3912451722706556e+00
    phi[5,7]  R2464     -1.4357242293455741e-01
    phi[5,7]  R2465     -1.4988104221861442e-01
    phi[5,7]  R2466     -1.6077132520768095e-01
    phi[5,7]  R2467     -0.164728018334363
    phi[5,7]  R2468     -1.0375962062812405e+00
    phi[5,7]  R2469     -1.8527662502547715e-01
    phi[5,7]  R2470     -1.8830061237188733e-01
    phi[5,7]  R2471     -1.9292728784856727e-01
    phi[5,7]  R2472     -1.9804703101610821e-01
    phi[5,7]  R2473     -0.867159948553037
    phi[5,7]  R2474     -1.2787155902186731e+00
    phi[5,7]  R2475     -1.6088078615650523e+00
    phi[5,7]  R2476     -4.8122996044434097e-01
    phi[5,7]  R2477     -4.9652145312641704e-01
    phi[5,7]  R2478     -5.0752097034967814e-01
    phi[5,7]  R2479     -5.0782452780204723e-01
    phi[5,7]  R2480     -5.1914841827233116e-01
    phi[5,7]  R2481     -1.4879951653040382e+00
    phi[5,7]  R2482     -5.4112095609954092e-01
    phi[5,7]  R2483     -5.4182918074964981e-01
    phi[5,7]  R2484     -0.0947762678653632
    phi[5,7]  R2485     -8.6516775273001523e-01
    phi[5,7]  R2486     -2.6055869141626076e-01
    phi[5,7]  R2487     -2.7626729892287127e-01
    phi[5,7]  R2488     -1.8923157659754368e+00
    phi[5,7]  R2489     -3.1663450650378533e-01
    phi[5,7]  R2490     -3.1670913001750367e-01
    phi[5,7]  R2491     -3.1683966019065868e-01
    phi[5,7]  R2492     -3.3264531643538531e-01
    phi[5,7]  R2493     -2.9555879272080468e+00
    phi[5,7]  R2494     -2.6972567206551745e-01
    phi[5,7]  R2495     -2.7763033112229130e-01
    phi[5,7]  R2496     -2.7944401248241563e-01
    phi[5,7]  R2497     -2.8896885145184670e-01
    phi[5,7]  R2498     -3.5031213846501541e-01
    phi[5,7]  R2499     -0.378319723649186
    phi[5,7]  R2500     -4.0202313381368393e-01
    phi[5,7]  R2501     -4.0337830794202745e-01
    phi[5,7]  R2502     -4.0644751984831307e-01
    phi[5,7]  R2503     -4.3164514771095930e-01
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R56       -1
    z[0,1,0]  R57       1
    z[0,1,0]  R70       -2.1535484492778778e-01
    z[0,1,0]  R71       -3.9488885551691055e-02
    z[0,1,0]  R72       -7.8452125191688538e-02
    z[0,1,0]  R73       7.0918244123458862e-01
    z[0,1,0]  R74       -3.8819867372512817e-01
    z[0,1,0]  R75       -1.5058794617652893e-01
    z[0,1,0]  R76       4.4029292464256287e-01
    z[0,1,0]  R77       -2.1365895867347717e-01
    z[0,1,0]  R78       -2.2509813308715820e-01
    z[0,1,0]  R79       6.6602796316146851e-01
    z[0,1,0]  R80       -1.6778011620044708e-01
    z[0,1,0]  R81       -7.2544538974761963e-01
    z[0,1,0]  R82       -4.0250718593597412e-01
    z[0,1,0]  R83       -3.7084838747978210e-01
    z[0,1,0]  R84       2.3428241908550262e-01
    z[0,1,0]  R85       -2.2190895676612854e-01
    z[0,1,0]  R86       1.9234074652194977e-01
    z[0,1,0]  R87       -0.652498722076416
    z[0,1,0]  R88       3.4856978803873062e-02
    z[0,1,0]  R89       0.348032146692276
    z[0,1,0]  R90       2.4526895582675934e-01
    z[0,1,0]  R91       -1.3026286661624908e-01
    z[0,1,0]  R92       -9.4464438734576106e-04
    z[0,1,0]  R93       8.1791661679744720e-02
    z[0,1,0]  R94       3.4186458587646484e-01
    z[0,1,0]  R95       2.3441174626350403e-01
    z[0,1,0]  R96       3.6524090170860291e-01
    z[0,1,0]  R97       5.5541205406188965e-01
    z[0,1,0]  R98       7.0683604478836060e-01
    z[0,1,0]  R99       -4.6727705001831055e-01
    z[0,1,0]  R100      -5.2773147821426392e-01
    z[0,1,0]  R101      -2.0565573871135712e-01
    z[0,1,0]  R102      2.9430902004241943e-01
    z[0,1,0]  R103      4.7490376234054565e-01
    z[0,1,0]  R104      -2.2350879013538361e-01
    z[0,1,0]  R105      4.8200567252933979e-03
    z[0,1,0]  R106      -1.8080001696944237e-02
    z[0,1,0]  R107      -1.2275114655494690e-01
    z[0,1,0]  R108      -6.5519958734512329e-01
    z[0,1,0]  R109      -6.2339651584625244e-01
    z[0,1,0]  R110      -5.4846620559692383e-01
    z[0,1,0]  R111      -5.3737568855285645e-01
    z[0,1,0]  R112      -3.4947690367698669e-01
    z[0,1,0]  R113      -3.8337504863739014e-01
    z[0,1,0]  R114      -3.3478114008903503e-01
    z[0,1,0]  R115      -2.9309570789337158e-01
    z[0,1,0]  R116      -4.8481833934783936e-01
    z[0,1,0]  R117      -5.7584816217422485e-01
    z[0,1,0]  R118      2.5187286734580994e-01
    z[0,1,0]  R119      4.6663612127304077e-02
    z[0,1,0]  R120      9.1005897521972656e-01
    z[0,1,0]  R121      1.3805174827575684e-01
    z[0,1,0]  R122      4.7126758098602295e-01
    z[0,1,0]  R123      4.3676313757896423e-01
    z[0,1,0]  R124      0.534625232219696
    z[0,1,0]  R125      7.4053883552551270e-01
    z[0,1,0]  R126      7.1643579006195068e-01
    z[0,1,0]  R127      6.3351887464523315e-01
    z[0,1,0]  R128      8.7949562072753906e-01
    z[0,1,0]  R129      7.2757941484451294e-01
    z[0,1,0]  R130      -8.9046663045883179e-01
    z[0,1,0]  R131      -7.7508997917175293e-01
    z[0,1,0]  R132      -5.2592891454696655e-01
    z[0,1,0]  R133      -7.9635888338088989e-01
    z[0,1,0]  R134      -6.9828587770462036e-01
    z[0,1,0]  R135      -6.2233519554138184e-01
    z[0,1,0]  R136      -5.0729984045028687e-01
    z[0,1,0]  R137      3.2287669181823730e-01
    z[0,1,0]  R138      2.2204083204269409e-01
    z[0,1,0]  R139      4.0584060549736023e-01
    z[0,1,0]  R140      -4.2859551310539246e-01
    z[0,1,0]  R141      -5.0588089227676392e-01
    z[0,1,0]  R142      -6.6504962742328644e-02
    z[0,1,0]  R143      9.3613542616367340e-02
    z[0,1,0]  R144      1.6056878864765167e-01
    z[0,1,0]  R145      1.9732825458049774e-01
    z[0,1,0]  R146      5.2592545747756958e-01
    z[0,1,0]  R147      3.2273855805397034e-01
    z[0,1,0]  R148      0.145841583609581
    z[0,1,0]  R149      1.4634659886360168e-01
    z[0,1,0]  R150      -4.9644985795021057e-01
    z[0,1,0]  R151      -5.6475734710693359e-01
    z[0,1,0]  R152      -4.7109922766685486e-01
    z[0,1,0]  R153      5.1703029870986938e-01
    z[0,1,0]  R154      4.9828074872493744e-02
    z[0,1,0]  R155      -6.4766839146614075e-02
    z[0,1,0]  R156      3.1029042601585388e-01
    z[0,1,0]  R157      2.6755779981613159e-01
    z[0,1,0]  R158      4.5220926403999329e-01
    z[0,1,0]  R159      7.0565128326416016e-01
    z[0,1,0]  R160      -7.2389864921569824e-01
    z[0,1,0]  R161      4.7058889269828796e-01
    z[0,1,0]  R162      3.2659158110618591e-01
    z[0,1,0]  R163      2.9244866967201233e-01
    z[0,1,0]  R164      1.8340951204299927e-01
    z[0,1,0]  R165      1.1921054124832153e-01
    z[0,1,0]  R166      4.4222906231880188e-01
    z[0,1,0]  R167      4.4989496469497681e-01
    z[0,1,0]  R168      0.354343980550766
    z[0,1,0]  R169      4.8459321260452271e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R58       -1
    z[0,1,1]  R59       1
    z[0,1,1]  R70       -3.0321920290589333e-02
    z[0,1,1]  R71       -7.5307391583919525e-02
    z[0,1,1]  R72       -3.1644946336746216e-01
    z[0,1,1]  R73       -1.5134041011333466e-01
    z[0,1,1]  R74       -6.8925797939300537e-01
    z[0,1,1]  R75       -4.8932152986526489e-01
    z[0,1,1]  R76       -5.0690180063247681e-01
    z[0,1,1]  R77       -4.5356574654579163e-01
    z[0,1,1]  R78       -6.5307593345642090e-01
    z[0,1,1]  R79       -3.5230189561843872e-01
    z[0,1,1]  R80       7.1265035867691040e-01
    z[0,1,1]  R81       5.2123963832855225e-01
    z[0,1,1]  R82       3.3907601237297058e-01
    z[0,1,1]  R83       7.0849084854125977e-01
    z[0,1,1]  R84       -4.3920555710792542e-01
    z[0,1,1]  R85       -3.4710294008255005e-01
    z[0,1,1]  R86       2.8536980971693993e-02
    z[0,1,1]  R87       -3.4474188089370728e-01
    z[0,1,1]  R88       -3.0235031247138977e-01
    z[0,1,1]  R89       3.3155802637338638e-02
    z[0,1,1]  R90       5.0876444578170776e-01
    z[0,1,1]  R91       -3.3810412883758545e-01
    z[0,1,1]  R92       -5.5801117420196533e-01
    z[0,1,1]  R93       -6.1173391342163086e-01
    z[0,1,1]  R94       2.6103922724723816e-01
    z[0,1,1]  R95       -4.5754346251487732e-01
    z[0,1,1]  R96       -2.2389478981494904e-01
    z[0,1,1]  R97       -1.1795723438262939e-01
    z[0,1,1]  R98       -1.2165439873933792e-01
    z[0,1,1]  R99       -5.4975450038909912e-01
    z[0,1,1]  R100      3.0264306068420410e-01
    z[0,1,1]  R101      -3.2424178719520569e-01
    z[0,1,1]  R102      -4.3738925457000732e-01
    z[0,1,1]  R103      -2.7944907546043396e-01
    z[0,1,1]  R104      3.3062603324651718e-02
    z[0,1,1]  R105      4.6390235424041748e-02
    z[0,1,1]  R106      2.0292538404464722e-01
    z[0,1,1]  R107      -8.7912291288375854e-02
    z[0,1,1]  R108      -3.1532719731330872e-01
    z[0,1,1]  R109      -3.0995562672615051e-01
    z[0,1,1]  R110      3.8442826271057129e-01
    z[0,1,1]  R111      -2.6387885212898254e-01
    z[0,1,1]  R112      3.1713566184043884e-01
    z[0,1,1]  R113      -6.0303714126348495e-03
    z[0,1,1]  R114      2.7103728055953979e-01
    z[0,1,1]  R115      1.1794888228178024e-01
    z[0,1,1]  R116      1.6418954730033875e-01
    z[0,1,1]  R117      4.1713860630989075e-01
    z[0,1,1]  R118      -6.7177355289459229e-01
    z[0,1,1]  R119      -6.6847103834152222e-01
    z[0,1,1]  R120      2.9807296395301819e-01
    z[0,1,1]  R121      2.4385875463485718e-01
    z[0,1,1]  R122      -3.8807126879692078e-01
    z[0,1,1]  R123      3.3396932482719421e-01
    z[0,1,1]  R124      3.5263964533805847e-01
    z[0,1,1]  R125      2.4720968306064606e-01
    z[0,1,1]  R126      -3.7510228157043457e-01
    z[0,1,1]  R127      -5.7581549882888794e-01
    z[0,1,1]  R128      1.4785762131214142e-01
    z[0,1,1]  R129      -3.0817532539367676e-01
    z[0,1,1]  R130      -2.1939820051193237e-01
    z[0,1,1]  R131      1.9416160881519318e-01
    z[0,1,1]  R132      4.9348825216293335e-01
    z[0,1,1]  R133      -1.4357546344399452e-02
    z[0,1,1]  R134      -7.9884245991706848e-02
    z[0,1,1]  R135      1.5804682672023773e-01
    z[0,1,1]  R136      1.9286023080348969e-01
    z[0,1,1]  R137      6.6589933633804321e-01
    z[0,1,1]  R138      -4.4424888491630554e-01
    z[0,1,1]  R139      -4.4897049665451050e-02
    z[0,1,1]  R140      4.5701089501380920e-01
    z[0,1,1]  R141      6.6072843968868256e-02
    z[0,1,1]  R142      -6.2168675661087036e-01
    z[0,1,1]  R143      -7.2063046693801880e-01
    z[0,1,1]  R144      -1.4998872578144073e-01
    z[0,1,1]  R145      -2.9883316159248352e-01
    z[0,1,1]  R146      -4.1531211137771606e-01
    z[0,1,1]  R147      -3.4737905859947205e-01
    z[0,1,1]  R148      -2.5700709223747253e-01
    z[0,1,1]  R149      0.885625422000885
    z[0,1,1]  R150      5.2399653196334839e-01
    z[0,1,1]  R151      6.6193324327468872e-01
    z[0,1,1]  R152      2.1502195298671722e-01
    z[0,1,1]  R153      -3.4582906961441040e-01
    z[0,1,1]  R154      -0.293354332447052
    z[0,1,1]  R155      -5.0657910108566284e-01
    z[0,1,1]  R156      -5.3950250148773193e-01
    z[0,1,1]  R157      -1.9510462880134583e-01
    z[0,1,1]  R158      -3.7244316935539246e-01
    z[0,1,1]  R159      -1.6403743624687195e-01
    z[0,1,1]  R160      -3.8011498749256134e-02
    z[0,1,1]  R161      -2.4596635997295380e-01
    z[0,1,1]  R162      -8.6322838068008423e-01
    z[0,1,1]  R163      -9.1503816843032837e-01
    z[0,1,1]  R164      -9.3509048223495483e-01
    z[0,1,1]  R165      -8.8453543186187744e-01
    z[0,1,1]  R166      -7.9997146129608154e-01
    z[0,1,1]  R167      -7.4838405847549438e-01
    z[0,1,1]  R168      -0.752017617225647
    z[0,1,1]  R169      -7.7209919691085815e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R60       -1
    z[0,1,2]  R61       1
    z[0,1,2]  R70       6.7125105857849121e-01
    z[0,1,2]  R71       8.3312809467315674e-01
    z[0,1,2]  R72       7.2451949119567871e-01
    z[0,1,2]  R73       -3.2872074842453003e-01
    z[0,1,2]  R74       -4.1633170843124390e-01
    z[0,1,2]  R75       -0.743471622467041
    z[0,1,2]  R76       -3.3147627115249634e-01
    z[0,1,2]  R77       -5.0266003608703613e-01
    z[0,1,2]  R78       -4.0125921368598938e-01
    z[0,1,2]  R79       -2.0253057777881622e-01
    z[0,1,2]  R80       -1.5846388041973114e-01
    z[0,1,2]  R81       -1.2504948675632477e-01
    z[0,1,2]  R82       -2.1178555488586426e-01
    z[0,1,2]  R83       -2.9686334729194641e-01
    z[0,1,2]  R84       -0.304912269115448
    z[0,1,2]  R85       -7.9474258422851562e-01
    z[0,1,2]  R86       -3.6457756161689758e-01
    z[0,1,2]  R87       -6.0136336088180542e-01
    z[0,1,2]  R88       -6.6898334026336670e-01
    z[0,1,2]  R89       -4.3192937970161438e-01
    z[0,1,2]  R90       3.6812517046928406e-01
    z[0,1,2]  R91       -5.8046752214431763e-01
    z[0,1,2]  R92       -0.46873739361763
    z[0,1,2]  R93       -4.2359763383865356e-01
    z[0,1,2]  R94       -7.3792028427124023e-01
    z[0,1,2]  R95       -0.58502197265625
    z[0,1,2]  R96       -3.7277403473854065e-01
    z[0,1,2]  R97       -5.4082602262496948e-01
    z[0,1,2]  R98       -0.410214364528656
    z[0,1,2]  R99       -3.9602348208427429e-01
    z[0,1,2]  R100      2.6167321205139160e-01
    z[0,1,2]  R101      -8.2806068658828735e-01
    z[0,1,2]  R102      -4.2722231149673462e-01
    z[0,1,2]  R103      -5.6709778308868408e-01
    z[0,1,2]  R104      3.5582524538040161e-01
    z[0,1,2]  R105      0.215763658285141
    z[0,1,2]  R106      3.0487173795700073e-01
    z[0,1,2]  R107      3.3832532167434692e-01
    z[0,1,2]  R108      3.5561352968215942e-01
    z[0,1,2]  R109      2.7809631824493408e-01
    z[0,1,2]  R110      4.0556451678276062e-01
    z[0,1,2]  R111      5.7136386632919312e-01
    z[0,1,2]  R112      6.8847596645355225e-01
    z[0,1,2]  R113      2.0886674523353577e-01
    z[0,1,2]  R114      -1.5248348005115986e-02
    z[0,1,2]  R115      5.3124696016311646e-01
    z[0,1,2]  R116      -2.1343810856342316e-01
    z[0,1,2]  R117      -2.7728474140167236e-01
    z[0,1,2]  R118      -1.0162437707185745e-01
    z[0,1,2]  R119      -2.3174107074737549e-01
    z[0,1,2]  R120      -1.1740779131650925e-01
    z[0,1,2]  R121      -6.8835496902465820e-01
    z[0,1,2]  R122      5.9588211774826050e-01
    z[0,1,2]  R123      -6.0378080606460571e-01
    z[0,1,2]  R124      -3.1660494208335876e-01
    z[0,1,2]  R125      -4.0137115865945816e-02
    z[0,1,2]  R126      2.5910025835037231e-01
    z[0,1,2]  R127      4.1383656859397888e-01
    z[0,1,2]  R128      -2.9499918222427368e-01
    z[0,1,2]  R129      3.6738941073417664e-01
    z[0,1,2]  R130      -1.9834670424461365e-01
    z[0,1,2]  R131      -3.6132711917161942e-02
    z[0,1,2]  R132      2.9677665233612061e-01
    z[0,1,2]  R133      2.6175066828727722e-01
    z[0,1,2]  R134      -1.4722524583339691e-01
    z[0,1,2]  R135      -2.3189820349216461e-01
    z[0,1,2]  R136      -7.4641996622085571e-01
    z[0,1,2]  R137      -5.8503359556198120e-01
    z[0,1,2]  R138      -1.5049757063388824e-01
    z[0,1,2]  R139      4.7004982829093933e-02
    z[0,1,2]  R140      -4.8428988456726074e-01
    z[0,1,2]  R141      -2.0427714288234711e-01
    z[0,1,2]  R142      1.7326584085822105e-02
    z[0,1,2]  R143      -2.0517694950103760e-01
    z[0,1,2]  R144      -6.6344380378723145e-02
    z[0,1,2]  R145      1.9156554341316223e-01
    z[0,1,2]  R146      0.0657258853316307
    z[0,1,2]  R147      -4.1535636410117149e-03
    z[0,1,2]  R148      -2.2964255511760712e-01
    z[0,1,2]  R149      -1.2464547902345657e-01
    z[0,1,2]  R150      -5.8535808324813843e-01
    z[0,1,2]  R151      -2.8683599829673767e-01
    z[0,1,2]  R152      -4.8880372196435928e-02
    z[0,1,2]  R153      -2.0156674087047577e-01
    z[0,1,2]  R154      -2.2471249103546143e-01
    z[0,1,2]  R155      -3.3468988537788391e-01
    z[0,1,2]  R156      1.8343251943588257e-01
    z[0,1,2]  R157      -2.5035008788108826e-01
    z[0,1,2]  R158      2.0671902596950531e-01
    z[0,1,2]  R159      -0.0722411647439003
    z[0,1,2]  R160      -5.3254854679107666e-01
    z[0,1,2]  R161      -1.6451023519039154e-01
    z[0,1,2]  R162      1.6175574064254761e-01
    z[0,1,2]  R163      0.000609697075560689
    z[0,1,2]  R164      -5.0387654453516006e-02
    z[0,1,2]  R165      2.9645591974258423e-01
    z[0,1,2]  R166      -3.1568646430969238e-01
    z[0,1,2]  R167      3.7175349891185760e-02
    z[0,1,2]  R168      3.4580063819885254e-01
    z[0,1,2]  R169      1.1843249201774597e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R62       -1
    z[0,1,3]  R63       1
    z[0,1,3]  R70       2.0664745569229126e-01
    z[0,1,3]  R71       4.7480484843254089e-01
    z[0,1,3]  R72       4.3962135910987854e-01
    z[0,1,3]  R73       -2.5441274046897888e-01
    z[0,1,3]  R74       -2.7254417538642883e-01
    z[0,1,3]  R75       -2.8050050139427185e-01
    z[0,1,3]  R76       -4.8772194981575012e-01
    z[0,1,3]  R77       -4.4571301341056824e-01
    z[0,1,3]  R78       -3.7584298849105835e-01
    z[0,1,3]  R79       -4.0352451801300049e-01
    z[0,1,3]  R80       5.4689025878906250e-01
    z[0,1,3]  R81       3.3585020899772644e-01
    z[0,1,3]  R82       6.2764382362365723e-01
    z[0,1,3]  R83       3.7380534410476685e-01
    z[0,1,3]  R84       -3.0621209740638733e-01
    z[0,1,3]  R85       -2.4470698833465576e-01
    z[0,1,3]  R86       -6.1684083938598633e-01
    z[0,1,3]  R87       -1.7534834146499634e-01
    z[0,1,3]  R88       6.0059234499931335e-02
    z[0,1,3]  R89       -2.3793654143810272e-01
    z[0,1,3]  R90       1.5104448795318604e-01
    z[0,1,3]  R91       -3.2698428630828857e-01
    z[0,1,3]  R92       -6.1881709098815918e-01
    z[0,1,3]  R93       -1.8161654472351074e-01
    z[0,1,3]  R94       -0.421463280916214
    z[0,1,3]  R95       -3.1157109141349792e-01
    z[0,1,3]  R96       -5.0003111362457275e-01
    z[0,1,3]  R97       -0.556904673576355
    z[0,1,3]  R98       -1.4032730460166931e-01
    z[0,1,3]  R99       -1.6827519237995148e-01
    z[0,1,3]  R100      4.3971300125122070e-01
    z[0,1,3]  R101      -2.5773823261260986e-01
    z[0,1,3]  R102      4.9456138163805008e-02
    z[0,1,3]  R103      -4.9626830220222473e-01
    z[0,1,3]  R104      -0.551245391368866
    z[0,1,3]  R105      -6.5397721529006958e-01
    z[0,1,3]  R106      -5.5598431825637817e-01
    z[0,1,3]  R107      -5.1718544960021973e-01
    z[0,1,3]  R108      -5.0143682956695557e-01
    z[0,1,3]  R109      -4.1073319315910339e-01
    z[0,1,3]  R110      3.9904925227165222e-01
    z[0,1,3]  R111      -4.4947284460067749e-01
    z[0,1,3]  R112      -2.5990280508995056e-01
    z[0,1,3]  R113      -3.9733633399009705e-01
    z[0,1,3]  R114      -2.7447342872619629e-01
    z[0,1,3]  R115      -5.7482278347015381e-01
    z[0,1,3]  R116      -6.4267545938491821e-01
    z[0,1,3]  R117      -2.6924726553261280e-03
    z[0,1,3]  R118      -4.3043103814125061e-01
    z[0,1,3]  R119      -5.6083846092224121e-01
    z[0,1,3]  R120      -4.9707889556884766e-03
    z[0,1,3]  R121      5.6251049041748047e-01
    z[0,1,3]  R122      4.5717990398406982e-01
    z[0,1,3]  R123      5.6790667772293091e-01
    z[0,1,3]  R124      6.6686850786209106e-01
    z[0,1,3]  R125      4.8297506570816040e-01
    z[0,1,3]  R126      4.2766058444976807e-01
    z[0,1,3]  R127      2.0888186991214752e-01
    z[0,1,3]  R128      2.5776371359825134e-01
    z[0,1,3]  R129      2.2306315600872040e-01
    z[0,1,3]  R130      -1.1081153899431229e-01
    z[0,1,3]  R131      -0.454868882894516
    z[0,1,3]  R132      -4.9220845103263855e-01
    z[0,1,3]  R133      0.456521600484848
    z[0,1,3]  R134      0.0790027603507042
    z[0,1,3]  R135      5.3736311197280884e-01
    z[0,1,3]  R136      1.2507483363151550e-01
    z[0,1,3]  R137      3.1046831607818604e-01
    z[0,1,3]  R138      -4.5002856850624084e-01
    z[0,1,3]  R139      -7.8516000509262085e-01
    z[0,1,3]  R140      -0.120479054749012
    z[0,1,3]  R141      8.1015847623348236e-02
    z[0,1,3]  R142      -5.2535998821258545e-01
    z[0,1,3]  R143      -4.3817153573036194e-01
    z[0,1,3]  R144      -7.7117341756820679e-01
    z[0,1,3]  R145      -6.7462337017059326e-01
    z[0,1,3]  R146      -3.9227211475372314e-01
    z[0,1,3]  R147      -6.4566022157669067e-01
    z[0,1,3]  R148      -8.5562658309936523e-01
    z[0,1,3]  R149      9.8151132464408875e-02
    z[0,1,3]  R150      3.6296206712722778e-01
    z[0,1,3]  R151      1.9905048608779907e-01
    z[0,1,3]  R152      1.3431535661220551e-01
    z[0,1,3]  R153      -6.5590482950210571e-01
    z[0,1,3]  R154      -7.0590674877166748e-01
    z[0,1,3]  R155      -4.9436318874359131e-01
    z[0,1,3]  R156      -7.5713771581649780e-01
    z[0,1,3]  R157      -8.6876374483108521e-01
    z[0,1,3]  R158      -5.4235792160034180e-01
    z[0,1,3]  R159      -6.7413049936294556e-01
    z[0,1,3]  R160      8.8837943971157074e-02
    z[0,1,3]  R161      -7.3519039154052734e-01
    z[0,1,3]  R162      -1.9255171716213226e-01
    z[0,1,3]  R163      1.3584984838962555e-01
    z[0,1,3]  R164      2.1812172234058380e-01
    z[0,1,3]  R165      9.1849960386753082e-02
    z[0,1,3]  R166      1.8861801922321320e-01
    z[0,1,3]  R167      -2.7884244918823242e-01
    z[0,1,3]  R168      1.2510600499808788e-02
    z[0,1,3]  R169      -2.7186835184693336e-02
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R64       -1
    z[0,1,4]  R65       1
    z[0,1,4]  R70       -5.7896101474761963e-01
    z[0,1,4]  R71       1.5035691857337952e-01
    z[0,1,4]  R72       -2.7070587873458862e-01
    z[0,1,4]  R73       -4.3372547626495361e-01
    z[0,1,4]  R74       2.7717721462249756e-01
    z[0,1,4]  R75       1.5353174507617950e-01
    z[0,1,4]  R76       0.305014431476593
    z[0,1,4]  R77       4.7453922033309937e-01
    z[0,1,4]  R78       -1.6413001343607903e-02
    z[0,1,4]  R79       3.7839943170547485e-01
    z[0,1,4]  R80       1.5287660062313080e-01
    z[0,1,4]  R81       2.5118967890739441e-01
    z[0,1,4]  R82       -2.6883220672607422e-01
    z[0,1,4]  R83       -3.3918708562850952e-01
    z[0,1,4]  R84       -6.6147160530090332e-01
    z[0,1,4]  R85       -2.0417188107967377e-01
    z[0,1,4]  R86       -5.5270522832870483e-01
    z[0,1,4]  R87       -1.6242443025112152e-01
    z[0,1,4]  R88       -1.1494395136833191e-01
    z[0,1,4]  R89       0.266864150762558
    z[0,1,4]  R90       -2.5346624851226807e-01
    z[0,1,4]  R91       -6.0920345783233643e-01
    z[0,1,4]  R92       8.4399111568927765e-02
    z[0,1,4]  R93       1.6527533531188965e-01
    z[0,1,4]  R94       -2.7962797880172729e-01
    z[0,1,4]  R95       4.2009231448173523e-01
    z[0,1,4]  R96       0.295994371175766
    z[0,1,4]  R97       2.5245073437690735e-01
    z[0,1,4]  R98       -6.1801366508007050e-02
    z[0,1,4]  R99       -1.2375334650278091e-01
    z[0,1,4]  R100      -4.7407916188240051e-01
    z[0,1,4]  R101      8.1504352390766144e-02
    z[0,1,4]  R102      -4.5216631889343262e-01
    z[0,1,4]  R103      -6.6905029118061066e-02
    z[0,1,4]  R104      6.5174782276153564e-01
    z[0,1,4]  R105      7.1326738595962524e-01
    z[0,1,4]  R106      7.3842769861221313e-01
    z[0,1,4]  R107      7.4505013227462769e-01
    z[0,1,4]  R108      2.8075304627418518e-01
    z[0,1,4]  R109      2.9651144146919250e-01
    z[0,1,4]  R110      -3.1760153174400330e-01
    z[0,1,4]  R111      1.2788502871990204e-01
    z[0,1,4]  R112      -4.5941525697708130e-01
    z[0,1,4]  R113      -4.5679351687431335e-01
    z[0,1,4]  R114      -6.8453729152679443e-01
    z[0,1,4]  R115      -2.0277164876461029e-02
    z[0,1,4]  R116      5.1528328657150269e-01
    z[0,1,4]  R117      5.8601063489913940e-01
    z[0,1,4]  R118      3.4970134496688843e-01
    z[0,1,4]  R119      2.0519576966762543e-01
    z[0,1,4]  R120      -2.5997087359428406e-02
    z[0,1,4]  R121      -3.1932753324508667e-01
    z[0,1,4]  R122      -2.0619036257266998e-01
    z[0,1,4]  R123      2.2363530471920967e-02
    z[0,1,4]  R124      2.4442672729492188e-02
    z[0,1,4]  R125      -2.2545643150806427e-01
    z[0,1,4]  R126      -2.4691025912761688e-01
    z[0,1,4]  R127      -1.8389484286308289e-01
    z[0,1,4]  R128      6.4173959195613861e-02
    z[0,1,4]  R129      -4.2985841631889343e-01
    z[0,1,4]  R130      2.8474089503288269e-01
    z[0,1,4]  R131      -1.8321696668863297e-02
    z[0,1,4]  R132      1.2423494458198547e-01
    z[0,1,4]  R133      -0.0837835893034935
    z[0,1,4]  R134      -4.8522930592298508e-02
    z[0,1,4]  R135      -2.8666019439697266e-01
    z[0,1,4]  R136      -2.0664894580841064e-01
    z[0,1,4]  R137      -3.7180971354246140e-02
    z[0,1,4]  R138      -9.1457515954971313e-02
    z[0,1,4]  R139      -8.6750283837318420e-02
    z[0,1,4]  R140      1.3383789360523224e-01
    z[0,1,4]  R141      -6.1846762895584106e-01
    z[0,1,4]  R142      -9.6565060317516327e-02
    z[0,1,4]  R143      -3.8908189535140991e-01
    z[0,1,4]  R144      -1.9357408583164215e-01
    z[0,1,4]  R145      -1.5970006585121155e-01
    z[0,1,4]  R146      -3.8437676429748535e-01
    z[0,1,4]  R147      -4.9526163935661316e-01
    z[0,1,4]  R148      2.0835416018962860e-01
    z[0,1,4]  R149      -2.9163017868995667e-01
    z[0,1,4]  R150      0.0585007481276989
    z[0,1,4]  R151      2.9259911179542542e-01
    z[0,1,4]  R152      -6.8360525369644165e-01
    z[0,1,4]  R153      -0.242141455411911
    z[0,1,4]  R154      -2.4339766800403595e-01
    z[0,1,4]  R155      -1.4195046387612820e-02
    z[0,1,4]  R156      -0.0697336345911026
    z[0,1,4]  R157      -7.0744507014751434e-02
    z[0,1,4]  R158      -1.7798207700252533e-01
    z[0,1,4]  R159      -3.3123213797807693e-03
    z[0,1,4]  R160      -2.9495945572853088e-01
    z[0,1,4]  R161      9.0996541082859039e-02
    z[0,1,4]  R162      -2.4021466076374054e-01
    z[0,1,4]  R163      -1.0266276448965073e-01
    z[0,1,4]  R164      -1.9709125161170959e-01
    z[0,1,4]  R165      1.9474083185195923e-01
    z[0,1,4]  R166      -1.4570684731006622e-01
    z[0,1,4]  R167      7.8483283519744873e-02
    z[0,1,4]  R168      5.5651620030403137e-02
    z[0,1,4]  R169      2.9908114671707153e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R66       -1
    z[0,1,5]  R67       1
    z[0,1,5]  R70       2.9928517341613770e-01
    z[0,1,5]  R71       -1.6527405381202698e-01
    z[0,1,5]  R72       2.5092652440071106e-01
    z[0,1,5]  R73       -8.0992072820663452e-02
    z[0,1,5]  R74       -2.0962081849575043e-01
    z[0,1,5]  R75       -2.1431510150432587e-01
    z[0,1,5]  R76       2.0304968953132629e-01
    z[0,1,5]  R77       2.5308430194854736e-01
    z[0,1,5]  R78       -3.9577043056488037e-01
    z[0,1,5]  R79       -2.9112765192985535e-01
    z[0,1,5]  R80       -4.1370846331119537e-02
    z[0,1,5]  R81       4.4306054711341858e-02
    z[0,1,5]  R82       -3.8293343782424927e-01
    z[0,1,5]  R83       -1.0646264255046844e-01
    z[0,1,5]  R84       2.1969746053218842e-01
    z[0,1,5]  R85       2.3867359384894371e-02
    z[0,1,5]  R86       -0.0388689860701561
    z[0,1,5]  R87       1.6128288209438324e-01
    z[0,1,5]  R88       -0.00794797670096159
    z[0,1,5]  R89       -7.1854341030120850e-01
    z[0,1,5]  R90       -4.9171975255012512e-01
    z[0,1,5]  R91       -2.2538807988166809e-01
    z[0,1,5]  R92       -1.5266773104667664e-01
    z[0,1,5]  R93       -6.1591911315917969e-01
    z[0,1,5]  R94       -9.8307415843009949e-02
    z[0,1,5]  R95       -2.7063596248626709e-01
    z[0,1,5]  R96       -4.9661588668823242e-01
    z[0,1,5]  R97       -2.4874383583664894e-02
    z[0,1,5]  R98       -4.6894603967666626e-01
    z[0,1,5]  R99       -4.6838322281837463e-01
    z[0,1,5]  R100      3.6219111084938049e-01
    z[0,1,5]  R101      -1.4578401111066341e-02
    z[0,1,5]  R102      -3.8394668698310852e-01
    z[0,1,5]  R103      1.6332481801509857e-01
    z[0,1,5]  R104      -0.304740846157074
    z[0,1,5]  R105      8.4416776895523071e-02
    z[0,1,5]  R106      -0.0711945965886116
    z[0,1,5]  R107      -8.8213659822940826e-02
    z[0,1,5]  R108      -6.8204671144485474e-02
    z[0,1,5]  R109      1.8763428926467896e-01
    z[0,1,5]  R110      -3.3961209654808044e-01
    z[0,1,5]  R111      1.8544797599315643e-01
    z[0,1,5]  R112      1.1440439522266388e-01
    z[0,1,5]  R113      6.5428024530410767e-01
    z[0,1,5]  R114      4.4936504960060120e-01
    z[0,1,5]  R115      -3.0648830533027649e-01
    z[0,1,5]  R116      1.1762021481990814e-01
    z[0,1,5]  R117      -2.5380519032478333e-01
    z[0,1,5]  R118      -3.1958609819412231e-01
    z[0,1,5]  R119      -8.4092825651168823e-02
    z[0,1,5]  R120      -1.1361759155988693e-01
    z[0,1,5]  R121      4.4120015809312463e-04
    z[0,1,5]  R122      -2.7406115084886551e-02
    z[0,1,5]  R123      1.1172773083671927e-03
    z[0,1,5]  R124      -9.8782189190387726e-02
    z[0,1,5]  R125      -2.7341619133949280e-01
    z[0,1,5]  R126      1.3734828680753708e-02
    z[0,1,5]  R127      -2.1597044542431831e-02
    z[0,1,5]  R128      1.3793526589870453e-01
    z[0,1,5]  R129      0.0759831964969635
    z[0,1,5]  R130      4.6145290136337280e-02
    z[0,1,5]  R131      3.8462081551551819e-01
    z[0,1,5]  R132      0.309256374835968
    z[0,1,5]  R133      -1.5847636759281158e-01
    z[0,1,5]  R134      5.0776267051696777e-01
    z[0,1,5]  R135      2.5914970040321350e-01
    z[0,1,5]  R136      7.1749143302440643e-02
    z[0,1,5]  R137      -3.7542516365647316e-03
    z[0,1,5]  R138      -2.2628861665725708e-01
    z[0,1,5]  R139      -1.9060148298740387e-01
    z[0,1,5]  R140      -3.3287471532821655e-01
    z[0,1,5]  R141      -9.2252299189567566e-02
    z[0,1,5]  R142      -5.5725795030593872e-01
    z[0,1,5]  R143      -2.5712516903877258e-01
    z[0,1,5]  R144      -5.5599504709243774e-01
    z[0,1,5]  R145      -5.6729829311370850e-01
    z[0,1,5]  R146      -4.8965570330619812e-01
    z[0,1,5]  R147      -2.9055011272430420e-01
    z[0,1,5]  R148      1.7456176877021790e-01
    z[0,1,5]  R149      2.8850591182708740e-01
    z[0,1,5]  R150      -2.4103295058012009e-02
    z[0,1,5]  R151      -6.2595404684543610e-02
    z[0,1,5]  R152      -7.4984863400459290e-02
    z[0,1,5]  R153      -1.5337084233760834e-01
    z[0,1,5]  R154      -5.4406648874282837e-01
    z[0,1,5]  R155      -5.2214270830154419e-01
    z[0,1,5]  R156      7.0977574214339256e-03
    z[0,1,5]  R157      5.4667755961418152e-02
    z[0,1,5]  R158      -5.1970493793487549e-01
    z[0,1,5]  R159      -6.0246225446462631e-02
    z[0,1,5]  R160      3.3154781907796860e-02
    z[0,1,5]  R161      -5.5117465555667877e-02
    z[0,1,5]  R162      1.1985098570585251e-01
    z[0,1,5]  R163      1.4734235405921936e-01
    z[0,1,5]  R164      -3.7574142217636108e-02
    z[0,1,5]  R165      -1.2454599142074585e-01
    z[0,1,5]  R166      8.0336481332778931e-02
    z[0,1,5]  R167      3.3352074027061462e-01
    z[0,1,5]  R168      0.199890598654747
    z[0,1,5]  R169      4.5918133109807968e-03
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R68       -1
    z[0,1,6]  R69       1
    z[0,1,6]  R70       1.8615677952766418e-01
    z[0,1,6]  R71       1.5265858173370361e-01
    z[0,1,6]  R72       -1.9815099239349365e-01
    z[0,1,6]  R73       -3.2664310932159424e-01
    z[0,1,6]  R74       7.6450914144515991e-02
    z[0,1,6]  R75       -1.9223439693450928e-01
    z[0,1,6]  R76       -2.5919172167778015e-01
    z[0,1,6]  R77       -0.0897860899567604
    z[0,1,6]  R78       2.5229376554489136e-01
    z[0,1,6]  R79       -2.2316303104162216e-02
    z[0,1,6]  R80       -0.338669091463089
    z[0,1,6]  R81       9.2445842921733856e-02
    z[0,1,6]  R82       -2.5557151436805725e-01
    z[0,1,6]  R83       -7.9194277524948120e-02
    z[0,1,6]  R84       -2.8224322199821472e-01
    z[0,1,6]  R85       -3.1068131327629089e-01
    z[0,1,6]  R86       3.7654665112495422e-01
    z[0,1,6]  R87       -1.0305192321538925e-01
    z[0,1,6]  R88       -6.6554355621337891e-01
    z[0,1,6]  R89       2.1697089076042175e-01
    z[0,1,6]  R90       4.6544370055198669e-01
    z[0,1,6]  R91       5.4104685783386230e-02
    z[0,1,6]  R92       2.3567487299442291e-01
    z[0,1,6]  R93       -1.3590492926596198e-05
    z[0,1,6]  R94       -7.0521339774131775e-02
    z[0,1,6]  R95       -2.1600113809108734e-01
    z[0,1,6]  R96       3.0534991621971130e-01
    z[0,1,6]  R97       -1.0304258763790131e-01
    z[0,1,6]  R98       -0.271819144487381
    z[0,1,6]  R99       2.4407637119293213e-01
    z[0,1,6]  R100      -1.1023992300033569e-01
    z[0,1,6]  R101      -3.0594781041145325e-01
    z[0,1,6]  R102      -4.3039354681968689e-01
    z[0,1,6]  R103      -3.1199550628662109e-01
    z[0,1,6]  R104      2.8728822246193886e-02
    z[0,1,6]  R105      8.7794452905654907e-02
    z[0,1,6]  R106      -7.8005760908126831e-02
    z[0,1,6]  R107      -1.7993733286857605e-01
    z[0,1,6]  R108      -0.0995403379201889
    z[0,1,6]  R109      -0.382281631231308
    z[0,1,6]  R110      1.0709770768880844e-01
    z[0,1,6]  R111      -2.4973434209823608e-01
    z[0,1,6]  R112      1.0766394436359406e-01
    z[0,1,6]  R113      -1.2142031639814377e-01
    z[0,1,6]  R114      2.6148018240928650e-01
    z[0,1,6]  R115      4.3953621387481689e-01
    z[0,1,6]  R116      -7.3536694981157780e-03
    z[0,1,6]  R117      -9.8360069096088409e-02
    z[0,1,6]  R118      2.5545188784599304e-01
    z[0,1,6]  R119      3.6544266343116760e-01
    z[0,1,6]  R120      2.3569293320178986e-01
    z[0,1,6]  R121      1.7103728652000427e-01
    z[0,1,6]  R122      -1.4125512540340424e-01
    z[0,1,6]  R123      -1.0065762698650360e-01
    z[0,1,6]  R124      -1.8577769398689270e-01
    z[0,1,6]  R125      1.7328223586082458e-01
    z[0,1,6]  R126      -1.8665000796318054e-01
    z[0,1,6]  R127      -1.3384471833705902e-01
    z[0,1,6]  R128      -1.6737556457519531e-01
    z[0,1,6]  R129      -1.9298050552606583e-02
    z[0,1,6]  R130      -1.5526151657104492e-01
    z[0,1,6]  R131      -7.1109756827354431e-02
    z[0,1,6]  R132      -1.9608356058597565e-01
    z[0,1,6]  R133      -2.3779530823230743e-01
    z[0,1,6]  R134      -4.6682038903236389e-01
    z[0,1,6]  R135      -3.0959886312484741e-01
    z[0,1,6]  R136      2.9122793674468994e-01
    z[0,1,6]  R137      1.1080313473939896e-01
    z[0,1,6]  R138      -6.8453967571258545e-01
    z[0,1,6]  R139      -4.1320380568504333e-01
    z[0,1,6]  R140      4.7924613952636719e-01
    z[0,1,6]  R141      5.4809981584548950e-01
    z[0,1,6]  R142      -1.1365757137537003e-01
    z[0,1,6]  R143      -1.4261193573474884e-01
    z[0,1,6]  R144      -7.7522225677967072e-02
    z[0,1,6]  R145      -1.8059577047824860e-01
    z[0,1,6]  R146      -7.2199523448944092e-02
    z[0,1,6]  R147      1.6902619600296021e-01
    z[0,1,6]  R148      -2.3229663074016571e-01
    z[0,1,6]  R149      -2.8217615559697151e-02
    z[0,1,6]  R150      -2.4007629603147507e-02
    z[0,1,6]  R151      -1.7738421261310577e-01
    z[0,1,6]  R152      4.8832595348358154e-01
    z[0,1,6]  R153      -2.4512539803981781e-01
    z[0,1,6]  R154      -8.6079455912113190e-02
    z[0,1,6]  R155      -3.3156612515449524e-01
    z[0,1,6]  R156      2.8960786759853363e-02
    z[0,1,6]  R157      -2.5481003522872925e-01
    z[0,1,6]  R158      1.3467422127723694e-01
    z[0,1,6]  R159      1.0879641771316528e-01
    z[0,1,6]  R160      3.0809977650642395e-01
    z[0,1,6]  R161      3.7304118275642395e-01
    z[0,1,6]  R162      1.1342987418174744e-01
    z[0,1,6]  R163      -1.6270875930786133e-01
    z[0,1,6]  R164      3.9924681186676025e-02
    z[0,1,6]  R165      -2.3157656192779541e-01
    z[0,1,6]  R166      3.9496082812547684e-02
    z[0,1,6]  R167      -2.0244711637496948e-01
    z[0,1,6]  R168      -3.8225898146629333e-01
    z[0,1,6]  R169      -2.5455081462860107e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R170      -1
    z[1,0,0]  R171      1
    z[1,0,0]  R184      -5.4846620559692383e-01
    z[1,0,0]  R185      -5.3737568855285645e-01
    z[1,0,0]  R186      -3.4947690367698669e-01
    z[1,0,0]  R187      -3.8337504863739014e-01
    z[1,0,0]  R188      -3.3478114008903503e-01
    z[1,0,0]  R189      -2.9309570789337158e-01
    z[1,0,0]  R190      -4.8481833934783936e-01
    z[1,0,0]  R191      -5.7584816217422485e-01
    z[1,0,0]  R192      2.5187286734580994e-01
    z[1,0,0]  R193      4.6663612127304077e-02
    z[1,0,0]  R194      9.1005897521972656e-01
    z[1,0,0]  R195      1.3805174827575684e-01
    z[1,0,0]  R196      4.7126758098602295e-01
    z[1,0,0]  R197      4.3676313757896423e-01
    z[1,0,0]  R198      0.534625232219696
    z[1,0,0]  R199      7.4053883552551270e-01
    z[1,0,0]  R200      7.1643579006195068e-01
    z[1,0,0]  R201      6.3351887464523315e-01
    z[1,0,0]  R202      8.7949562072753906e-01
    z[1,0,0]  R203      7.2757941484451294e-01
    z[1,0,0]  R204      -8.9046663045883179e-01
    z[1,0,0]  R205      -7.7508997917175293e-01
    z[1,0,0]  R206      -5.2592891454696655e-01
    z[1,0,0]  R207      -7.9635888338088989e-01
    z[1,0,0]  R208      -6.9828587770462036e-01
    z[1,0,0]  R209      -6.2233519554138184e-01
    z[1,0,0]  R210      -5.0729984045028687e-01
    z[1,0,0]  R211      3.2287669181823730e-01
    z[1,0,0]  R212      2.2204083204269409e-01
    z[1,0,0]  R213      4.0584060549736023e-01
    z[1,0,0]  R214      -4.2859551310539246e-01
    z[1,0,0]  R215      -5.0588089227676392e-01
    z[1,0,0]  R216      -6.6504962742328644e-02
    z[1,0,0]  R217      9.3613542616367340e-02
    z[1,0,0]  R218      1.6056878864765167e-01
    z[1,0,0]  R219      1.9732825458049774e-01
    z[1,0,0]  R220      5.2592545747756958e-01
    z[1,0,0]  R221      3.2273855805397034e-01
    z[1,0,0]  R222      0.145841583609581
    z[1,0,0]  R223      1.4634659886360168e-01
    z[1,0,0]  R224      -4.9644985795021057e-01
    z[1,0,0]  R225      -5.6475734710693359e-01
    z[1,0,0]  R226      -4.7109922766685486e-01
    z[1,0,0]  R227      5.1703029870986938e-01
    z[1,0,0]  R228      4.9828074872493744e-02
    z[1,0,0]  R229      -6.4766839146614075e-02
    z[1,0,0]  R230      3.1029042601585388e-01
    z[1,0,0]  R231      2.6755779981613159e-01
    z[1,0,0]  R232      4.5220926403999329e-01
    z[1,0,0]  R233      7.0565128326416016e-01
    z[1,0,0]  R234      -7.2389864921569824e-01
    z[1,0,0]  R235      4.7058889269828796e-01
    z[1,0,0]  R236      3.2659158110618591e-01
    z[1,0,0]  R237      2.9244866967201233e-01
    z[1,0,0]  R238      1.8340951204299927e-01
    z[1,0,0]  R239      1.1921054124832153e-01
    z[1,0,0]  R240      4.4222906231880188e-01
    z[1,0,0]  R241      4.4989496469497681e-01
    z[1,0,0]  R242      0.354343980550766
    z[1,0,0]  R243      4.8459321260452271e-01
    z[1,0,0]  R244      -2.1535484492778778e-01
    z[1,0,0]  R245      -3.9488885551691055e-02
    z[1,0,0]  R246      -7.8452125191688538e-02
    z[1,0,0]  R247      7.0918244123458862e-01
    z[1,0,0]  R248      -3.8819867372512817e-01
    z[1,0,0]  R249      -1.5058794617652893e-01
    z[1,0,0]  R250      4.4029292464256287e-01
    z[1,0,0]  R251      -2.1365895867347717e-01
    z[1,0,0]  R252      -2.2509813308715820e-01
    z[1,0,0]  R253      6.6602796316146851e-01
    z[1,0,0]  R254      -1.6778011620044708e-01
    z[1,0,0]  R255      -7.2544538974761963e-01
    z[1,0,0]  R256      -4.0250718593597412e-01
    z[1,0,0]  R257      -3.7084838747978210e-01
    z[1,0,0]  R258      2.3428241908550262e-01
    z[1,0,0]  R259      -2.2190895676612854e-01
    z[1,0,0]  R260      1.9234074652194977e-01
    z[1,0,0]  R261      -0.652498722076416
    z[1,0,0]  R262      3.4856978803873062e-02
    z[1,0,0]  R263      0.348032146692276
    z[1,0,0]  R264      2.4526895582675934e-01
    z[1,0,0]  R265      -1.3026286661624908e-01
    z[1,0,0]  R266      -9.4464438734576106e-04
    z[1,0,0]  R267      8.1791661679744720e-02
    z[1,0,0]  R268      3.4186458587646484e-01
    z[1,0,0]  R269      2.3441174626350403e-01
    z[1,0,0]  R270      3.6524090170860291e-01
    z[1,0,0]  R271      5.5541205406188965e-01
    z[1,0,0]  R272      7.0683604478836060e-01
    z[1,0,0]  R273      -4.6727705001831055e-01
    z[1,0,0]  R274      -5.2773147821426392e-01
    z[1,0,0]  R275      -2.0565573871135712e-01
    z[1,0,0]  R276      2.9430902004241943e-01
    z[1,0,0]  R277      4.7490376234054565e-01
    z[1,0,0]  R278      -2.2350879013538361e-01
    z[1,0,0]  R279      4.8200567252933979e-03
    z[1,0,0]  R280      -1.8080001696944237e-02
    z[1,0,0]  R281      -1.2275114655494690e-01
    z[1,0,0]  R282      -6.5519958734512329e-01
    z[1,0,0]  R283      -6.2339651584625244e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R172      -1
    z[1,0,1]  R173      1
    z[1,0,1]  R184      3.8442826271057129e-01
    z[1,0,1]  R185      -2.6387885212898254e-01
    z[1,0,1]  R186      3.1713566184043884e-01
    z[1,0,1]  R187      -6.0303714126348495e-03
    z[1,0,1]  R188      2.7103728055953979e-01
    z[1,0,1]  R189      1.1794888228178024e-01
    z[1,0,1]  R190      1.6418954730033875e-01
    z[1,0,1]  R191      4.1713860630989075e-01
    z[1,0,1]  R192      -6.7177355289459229e-01
    z[1,0,1]  R193      -6.6847103834152222e-01
    z[1,0,1]  R194      2.9807296395301819e-01
    z[1,0,1]  R195      2.4385875463485718e-01
    z[1,0,1]  R196      -3.8807126879692078e-01
    z[1,0,1]  R197      3.3396932482719421e-01
    z[1,0,1]  R198      3.5263964533805847e-01
    z[1,0,1]  R199      2.4720968306064606e-01
    z[1,0,1]  R200      -3.7510228157043457e-01
    z[1,0,1]  R201      -5.7581549882888794e-01
    z[1,0,1]  R202      1.4785762131214142e-01
    z[1,0,1]  R203      -3.0817532539367676e-01
    z[1,0,1]  R204      -2.1939820051193237e-01
    z[1,0,1]  R205      1.9416160881519318e-01
    z[1,0,1]  R206      4.9348825216293335e-01
    z[1,0,1]  R207      -1.4357546344399452e-02
    z[1,0,1]  R208      -7.9884245991706848e-02
    z[1,0,1]  R209      1.5804682672023773e-01
    z[1,0,1]  R210      1.9286023080348969e-01
    z[1,0,1]  R211      6.6589933633804321e-01
    z[1,0,1]  R212      -4.4424888491630554e-01
    z[1,0,1]  R213      -4.4897049665451050e-02
    z[1,0,1]  R214      4.5701089501380920e-01
    z[1,0,1]  R215      6.6072843968868256e-02
    z[1,0,1]  R216      -6.2168675661087036e-01
    z[1,0,1]  R217      -7.2063046693801880e-01
    z[1,0,1]  R218      -1.4998872578144073e-01
    z[1,0,1]  R219      -2.9883316159248352e-01
    z[1,0,1]  R220      -4.1531211137771606e-01
    z[1,0,1]  R221      -3.4737905859947205e-01
    z[1,0,1]  R222      -2.5700709223747253e-01
    z[1,0,1]  R223      0.885625422000885
    z[1,0,1]  R224      5.2399653196334839e-01
    z[1,0,1]  R225      6.6193324327468872e-01
    z[1,0,1]  R226      2.1502195298671722e-01
    z[1,0,1]  R227      -3.4582906961441040e-01
    z[1,0,1]  R228      -0.293354332447052
    z[1,0,1]  R229      -5.0657910108566284e-01
    z[1,0,1]  R230      -5.3950250148773193e-01
    z[1,0,1]  R231      -1.9510462880134583e-01
    z[1,0,1]  R232      -3.7244316935539246e-01
    z[1,0,1]  R233      -1.6403743624687195e-01
    z[1,0,1]  R234      -3.8011498749256134e-02
    z[1,0,1]  R235      -2.4596635997295380e-01
    z[1,0,1]  R236      -8.6322838068008423e-01
    z[1,0,1]  R237      -9.1503816843032837e-01
    z[1,0,1]  R238      -9.3509048223495483e-01
    z[1,0,1]  R239      -8.8453543186187744e-01
    z[1,0,1]  R240      -7.9997146129608154e-01
    z[1,0,1]  R241      -7.4838405847549438e-01
    z[1,0,1]  R242      -0.752017617225647
    z[1,0,1]  R243      -7.7209919691085815e-01
    z[1,0,1]  R244      -3.0321920290589333e-02
    z[1,0,1]  R245      -7.5307391583919525e-02
    z[1,0,1]  R246      -3.1644946336746216e-01
    z[1,0,1]  R247      -1.5134041011333466e-01
    z[1,0,1]  R248      -6.8925797939300537e-01
    z[1,0,1]  R249      -4.8932152986526489e-01
    z[1,0,1]  R250      -5.0690180063247681e-01
    z[1,0,1]  R251      -4.5356574654579163e-01
    z[1,0,1]  R252      -6.5307593345642090e-01
    z[1,0,1]  R253      -3.5230189561843872e-01
    z[1,0,1]  R254      7.1265035867691040e-01
    z[1,0,1]  R255      5.2123963832855225e-01
    z[1,0,1]  R256      3.3907601237297058e-01
    z[1,0,1]  R257      7.0849084854125977e-01
    z[1,0,1]  R258      -4.3920555710792542e-01
    z[1,0,1]  R259      -3.4710294008255005e-01
    z[1,0,1]  R260      2.8536980971693993e-02
    z[1,0,1]  R261      -3.4474188089370728e-01
    z[1,0,1]  R262      -3.0235031247138977e-01
    z[1,0,1]  R263      3.3155802637338638e-02
    z[1,0,1]  R264      5.0876444578170776e-01
    z[1,0,1]  R265      -3.3810412883758545e-01
    z[1,0,1]  R266      -5.5801117420196533e-01
    z[1,0,1]  R267      -6.1173391342163086e-01
    z[1,0,1]  R268      2.6103922724723816e-01
    z[1,0,1]  R269      -4.5754346251487732e-01
    z[1,0,1]  R270      -2.2389478981494904e-01
    z[1,0,1]  R271      -1.1795723438262939e-01
    z[1,0,1]  R272      -1.2165439873933792e-01
    z[1,0,1]  R273      -5.4975450038909912e-01
    z[1,0,1]  R274      3.0264306068420410e-01
    z[1,0,1]  R275      -3.2424178719520569e-01
    z[1,0,1]  R276      -4.3738925457000732e-01
    z[1,0,1]  R277      -2.7944907546043396e-01
    z[1,0,1]  R278      3.3062603324651718e-02
    z[1,0,1]  R279      4.6390235424041748e-02
    z[1,0,1]  R280      2.0292538404464722e-01
    z[1,0,1]  R281      -8.7912291288375854e-02
    z[1,0,1]  R282      -3.1532719731330872e-01
    z[1,0,1]  R283      -3.0995562672615051e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R174      -1
    z[1,0,2]  R175      1
    z[1,0,2]  R184      4.0556451678276062e-01
    z[1,0,2]  R185      5.7136386632919312e-01
    z[1,0,2]  R186      6.8847596645355225e-01
    z[1,0,2]  R187      2.0886674523353577e-01
    z[1,0,2]  R188      -1.5248348005115986e-02
    z[1,0,2]  R189      5.3124696016311646e-01
    z[1,0,2]  R190      -2.1343810856342316e-01
    z[1,0,2]  R191      -2.7728474140167236e-01
    z[1,0,2]  R192      -1.0162437707185745e-01
    z[1,0,2]  R193      -2.3174107074737549e-01
    z[1,0,2]  R194      -1.1740779131650925e-01
    z[1,0,2]  R195      -6.8835496902465820e-01
    z[1,0,2]  R196      5.9588211774826050e-01
    z[1,0,2]  R197      -6.0378080606460571e-01
    z[1,0,2]  R198      -3.1660494208335876e-01
    z[1,0,2]  R199      -4.0137115865945816e-02
    z[1,0,2]  R200      2.5910025835037231e-01
    z[1,0,2]  R201      4.1383656859397888e-01
    z[1,0,2]  R202      -2.9499918222427368e-01
    z[1,0,2]  R203      3.6738941073417664e-01
    z[1,0,2]  R204      -1.9834670424461365e-01
    z[1,0,2]  R205      -3.6132711917161942e-02
    z[1,0,2]  R206      2.9677665233612061e-01
    z[1,0,2]  R207      2.6175066828727722e-01
    z[1,0,2]  R208      -1.4722524583339691e-01
    z[1,0,2]  R209      -2.3189820349216461e-01
    z[1,0,2]  R210      -7.4641996622085571e-01
    z[1,0,2]  R211      -5.8503359556198120e-01
    z[1,0,2]  R212      -1.5049757063388824e-01
    z[1,0,2]  R213      4.7004982829093933e-02
    z[1,0,2]  R214      -4.8428988456726074e-01
    z[1,0,2]  R215      -2.0427714288234711e-01
    z[1,0,2]  R216      1.7326584085822105e-02
    z[1,0,2]  R217      -2.0517694950103760e-01
    z[1,0,2]  R218      -6.6344380378723145e-02
    z[1,0,2]  R219      1.9156554341316223e-01
    z[1,0,2]  R220      0.0657258853316307
    z[1,0,2]  R221      -4.1535636410117149e-03
    z[1,0,2]  R222      -2.2964255511760712e-01
    z[1,0,2]  R223      -1.2464547902345657e-01
    z[1,0,2]  R224      -5.8535808324813843e-01
    z[1,0,2]  R225      -2.8683599829673767e-01
    z[1,0,2]  R226      -4.8880372196435928e-02
    z[1,0,2]  R227      -2.0156674087047577e-01
    z[1,0,2]  R228      -2.2471249103546143e-01
    z[1,0,2]  R229      -3.3468988537788391e-01
    z[1,0,2]  R230      1.8343251943588257e-01
    z[1,0,2]  R231      -2.5035008788108826e-01
    z[1,0,2]  R232      2.0671902596950531e-01
    z[1,0,2]  R233      -0.0722411647439003
    z[1,0,2]  R234      -5.3254854679107666e-01
    z[1,0,2]  R235      -1.6451023519039154e-01
    z[1,0,2]  R236      1.6175574064254761e-01
    z[1,0,2]  R237      0.000609697075560689
    z[1,0,2]  R238      -5.0387654453516006e-02
    z[1,0,2]  R239      2.9645591974258423e-01
    z[1,0,2]  R240      -3.1568646430969238e-01
    z[1,0,2]  R241      3.7175349891185760e-02
    z[1,0,2]  R242      3.4580063819885254e-01
    z[1,0,2]  R243      1.1843249201774597e-01
    z[1,0,2]  R244      6.7125105857849121e-01
    z[1,0,2]  R245      8.3312809467315674e-01
    z[1,0,2]  R246      7.2451949119567871e-01
    z[1,0,2]  R247      -3.2872074842453003e-01
    z[1,0,2]  R248      -4.1633170843124390e-01
    z[1,0,2]  R249      -0.743471622467041
    z[1,0,2]  R250      -3.3147627115249634e-01
    z[1,0,2]  R251      -5.0266003608703613e-01
    z[1,0,2]  R252      -4.0125921368598938e-01
    z[1,0,2]  R253      -2.0253057777881622e-01
    z[1,0,2]  R254      -1.5846388041973114e-01
    z[1,0,2]  R255      -1.2504948675632477e-01
    z[1,0,2]  R256      -2.1178555488586426e-01
    z[1,0,2]  R257      -2.9686334729194641e-01
    z[1,0,2]  R258      -0.304912269115448
    z[1,0,2]  R259      -7.9474258422851562e-01
    z[1,0,2]  R260      -3.6457756161689758e-01
    z[1,0,2]  R261      -6.0136336088180542e-01
    z[1,0,2]  R262      -6.6898334026336670e-01
    z[1,0,2]  R263      -4.3192937970161438e-01
    z[1,0,2]  R264      3.6812517046928406e-01
    z[1,0,2]  R265      -5.8046752214431763e-01
    z[1,0,2]  R266      -0.46873739361763
    z[1,0,2]  R267      -4.2359763383865356e-01
    z[1,0,2]  R268      -7.3792028427124023e-01
    z[1,0,2]  R269      -0.58502197265625
    z[1,0,2]  R270      -3.7277403473854065e-01
    z[1,0,2]  R271      -5.4082602262496948e-01
    z[1,0,2]  R272      -0.410214364528656
    z[1,0,2]  R273      -3.9602348208427429e-01
    z[1,0,2]  R274      2.6167321205139160e-01
    z[1,0,2]  R275      -8.2806068658828735e-01
    z[1,0,2]  R276      -4.2722231149673462e-01
    z[1,0,2]  R277      -5.6709778308868408e-01
    z[1,0,2]  R278      3.5582524538040161e-01
    z[1,0,2]  R279      0.215763658285141
    z[1,0,2]  R280      3.0487173795700073e-01
    z[1,0,2]  R281      3.3832532167434692e-01
    z[1,0,2]  R282      3.5561352968215942e-01
    z[1,0,2]  R283      2.7809631824493408e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R176      -1
    z[1,0,3]  R177      1
    z[1,0,3]  R184      3.9904925227165222e-01
    z[1,0,3]  R185      -4.4947284460067749e-01
    z[1,0,3]  R186      -2.5990280508995056e-01
    z[1,0,3]  R187      -3.9733633399009705e-01
    z[1,0,3]  R188      -2.7447342872619629e-01
    z[1,0,3]  R189      -5.7482278347015381e-01
    z[1,0,3]  R190      -6.4267545938491821e-01
    z[1,0,3]  R191      -2.6924726553261280e-03
    z[1,0,3]  R192      -4.3043103814125061e-01
    z[1,0,3]  R193      -5.6083846092224121e-01
    z[1,0,3]  R194      -4.9707889556884766e-03
    z[1,0,3]  R195      5.6251049041748047e-01
    z[1,0,3]  R196      4.5717990398406982e-01
    z[1,0,3]  R197      5.6790667772293091e-01
    z[1,0,3]  R198      6.6686850786209106e-01
    z[1,0,3]  R199      4.8297506570816040e-01
    z[1,0,3]  R200      4.2766058444976807e-01
    z[1,0,3]  R201      2.0888186991214752e-01
    z[1,0,3]  R202      2.5776371359825134e-01
    z[1,0,3]  R203      2.2306315600872040e-01
    z[1,0,3]  R204      -1.1081153899431229e-01
    z[1,0,3]  R205      -0.454868882894516
    z[1,0,3]  R206      -4.9220845103263855e-01
    z[1,0,3]  R207      0.456521600484848
    z[1,0,3]  R208      0.0790027603507042
    z[1,0,3]  R209      5.3736311197280884e-01
    z[1,0,3]  R210      1.2507483363151550e-01
    z[1,0,3]  R211      3.1046831607818604e-01
    z[1,0,3]  R212      -4.5002856850624084e-01
    z[1,0,3]  R213      -7.8516000509262085e-01
    z[1,0,3]  R214      -0.120479054749012
    z[1,0,3]  R215      8.1015847623348236e-02
    z[1,0,3]  R216      -5.2535998821258545e-01
    z[1,0,3]  R217      -4.3817153573036194e-01
    z[1,0,3]  R218      -7.7117341756820679e-01
    z[1,0,3]  R219      -6.7462337017059326e-01
    z[1,0,3]  R220      -3.9227211475372314e-01
    z[1,0,3]  R221      -6.4566022157669067e-01
    z[1,0,3]  R222      -8.5562658309936523e-01
    z[1,0,3]  R223      9.8151132464408875e-02
    z[1,0,3]  R224      3.6296206712722778e-01
    z[1,0,3]  R225      1.9905048608779907e-01
    z[1,0,3]  R226      1.3431535661220551e-01
    z[1,0,3]  R227      -6.5590482950210571e-01
    z[1,0,3]  R228      -7.0590674877166748e-01
    z[1,0,3]  R229      -4.9436318874359131e-01
    z[1,0,3]  R230      -7.5713771581649780e-01
    z[1,0,3]  R231      -8.6876374483108521e-01
    z[1,0,3]  R232      -5.4235792160034180e-01
    z[1,0,3]  R233      -6.7413049936294556e-01
    z[1,0,3]  R234      8.8837943971157074e-02
    z[1,0,3]  R235      -7.3519039154052734e-01
    z[1,0,3]  R236      -1.9255171716213226e-01
    z[1,0,3]  R237      1.3584984838962555e-01
    z[1,0,3]  R238      2.1812172234058380e-01
    z[1,0,3]  R239      9.1849960386753082e-02
    z[1,0,3]  R240      1.8861801922321320e-01
    z[1,0,3]  R241      -2.7884244918823242e-01
    z[1,0,3]  R242      1.2510600499808788e-02
    z[1,0,3]  R243      -2.7186835184693336e-02
    z[1,0,3]  R244      2.0664745569229126e-01
    z[1,0,3]  R245      4.7480484843254089e-01
    z[1,0,3]  R246      4.3962135910987854e-01
    z[1,0,3]  R247      -2.5441274046897888e-01
    z[1,0,3]  R248      -2.7254417538642883e-01
    z[1,0,3]  R249      -2.8050050139427185e-01
    z[1,0,3]  R250      -4.8772194981575012e-01
    z[1,0,3]  R251      -4.4571301341056824e-01
    z[1,0,3]  R252      -3.7584298849105835e-01
    z[1,0,3]  R253      -4.0352451801300049e-01
    z[1,0,3]  R254      5.4689025878906250e-01
    z[1,0,3]  R255      3.3585020899772644e-01
    z[1,0,3]  R256      6.2764382362365723e-01
    z[1,0,3]  R257      3.7380534410476685e-01
    z[1,0,3]  R258      -3.0621209740638733e-01
    z[1,0,3]  R259      -2.4470698833465576e-01
    z[1,0,3]  R260      -6.1684083938598633e-01
    z[1,0,3]  R261      -1.7534834146499634e-01
    z[1,0,3]  R262      6.0059234499931335e-02
    z[1,0,3]  R263      -2.3793654143810272e-01
    z[1,0,3]  R264      1.5104448795318604e-01
    z[1,0,3]  R265      -3.2698428630828857e-01
    z[1,0,3]  R266      -6.1881709098815918e-01
    z[1,0,3]  R267      -1.8161654472351074e-01
    z[1,0,3]  R268      -0.421463280916214
    z[1,0,3]  R269      -3.1157109141349792e-01
    z[1,0,3]  R270      -5.0003111362457275e-01
    z[1,0,3]  R271      -0.556904673576355
    z[1,0,3]  R272      -1.4032730460166931e-01
    z[1,0,3]  R273      -1.6827519237995148e-01
    z[1,0,3]  R274      4.3971300125122070e-01
    z[1,0,3]  R275      -2.5773823261260986e-01
    z[1,0,3]  R276      4.9456138163805008e-02
    z[1,0,3]  R277      -4.9626830220222473e-01
    z[1,0,3]  R278      -0.551245391368866
    z[1,0,3]  R279      -6.5397721529006958e-01
    z[1,0,3]  R280      -5.5598431825637817e-01
    z[1,0,3]  R281      -5.1718544960021973e-01
    z[1,0,3]  R282      -5.0143682956695557e-01
    z[1,0,3]  R283      -4.1073319315910339e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R178      -1
    z[1,0,4]  R179      1
    z[1,0,4]  R184      -3.1760153174400330e-01
    z[1,0,4]  R185      1.2788502871990204e-01
    z[1,0,4]  R186      -4.5941525697708130e-01
    z[1,0,4]  R187      -4.5679351687431335e-01
    z[1,0,4]  R188      -6.8453729152679443e-01
    z[1,0,4]  R189      -2.0277164876461029e-02
    z[1,0,4]  R190      5.1528328657150269e-01
    z[1,0,4]  R191      5.8601063489913940e-01
    z[1,0,4]  R192      3.4970134496688843e-01
    z[1,0,4]  R193      2.0519576966762543e-01
    z[1,0,4]  R194      -2.5997087359428406e-02
    z[1,0,4]  R195      -3.1932753324508667e-01
    z[1,0,4]  R196      -2.0619036257266998e-01
    z[1,0,4]  R197      2.2363530471920967e-02
    z[1,0,4]  R198      2.4442672729492188e-02
    z[1,0,4]  R199      -2.2545643150806427e-01
    z[1,0,4]  R200      -2.4691025912761688e-01
    z[1,0,4]  R201      -1.8389484286308289e-01
    z[1,0,4]  R202      6.4173959195613861e-02
    z[1,0,4]  R203      -4.2985841631889343e-01
    z[1,0,4]  R204      2.8474089503288269e-01
    z[1,0,4]  R205      -1.8321696668863297e-02
    z[1,0,4]  R206      1.2423494458198547e-01
    z[1,0,4]  R207      -0.0837835893034935
    z[1,0,4]  R208      -4.8522930592298508e-02
    z[1,0,4]  R209      -2.8666019439697266e-01
    z[1,0,4]  R210      -2.0664894580841064e-01
    z[1,0,4]  R211      -3.7180971354246140e-02
    z[1,0,4]  R212      -9.1457515954971313e-02
    z[1,0,4]  R213      -8.6750283837318420e-02
    z[1,0,4]  R214      1.3383789360523224e-01
    z[1,0,4]  R215      -6.1846762895584106e-01
    z[1,0,4]  R216      -9.6565060317516327e-02
    z[1,0,4]  R217      -3.8908189535140991e-01
    z[1,0,4]  R218      -1.9357408583164215e-01
    z[1,0,4]  R219      -1.5970006585121155e-01
    z[1,0,4]  R220      -3.8437676429748535e-01
    z[1,0,4]  R221      -4.9526163935661316e-01
    z[1,0,4]  R222      2.0835416018962860e-01
    z[1,0,4]  R223      -2.9163017868995667e-01
    z[1,0,4]  R224      0.0585007481276989
    z[1,0,4]  R225      2.9259911179542542e-01
    z[1,0,4]  R226      -6.8360525369644165e-01
    z[1,0,4]  R227      -0.242141455411911
    z[1,0,4]  R228      -2.4339766800403595e-01
    z[1,0,4]  R229      -1.4195046387612820e-02
    z[1,0,4]  R230      -0.0697336345911026
    z[1,0,4]  R231      -7.0744507014751434e-02
    z[1,0,4]  R232      -1.7798207700252533e-01
    z[1,0,4]  R233      -3.3123213797807693e-03
    z[1,0,4]  R234      -2.9495945572853088e-01
    z[1,0,4]  R235      9.0996541082859039e-02
    z[1,0,4]  R236      -2.4021466076374054e-01
    z[1,0,4]  R237      -1.0266276448965073e-01
    z[1,0,4]  R238      -1.9709125161170959e-01
    z[1,0,4]  R239      1.9474083185195923e-01
    z[1,0,4]  R240      -1.4570684731006622e-01
    z[1,0,4]  R241      7.8483283519744873e-02
    z[1,0,4]  R242      5.5651620030403137e-02
    z[1,0,4]  R243      2.9908114671707153e-01
    z[1,0,4]  R244      -5.7896101474761963e-01
    z[1,0,4]  R245      1.5035691857337952e-01
    z[1,0,4]  R246      -2.7070587873458862e-01
    z[1,0,4]  R247      -4.3372547626495361e-01
    z[1,0,4]  R248      2.7717721462249756e-01
    z[1,0,4]  R249      1.5353174507617950e-01
    z[1,0,4]  R250      0.305014431476593
    z[1,0,4]  R251      4.7453922033309937e-01
    z[1,0,4]  R252      -1.6413001343607903e-02
    z[1,0,4]  R253      3.7839943170547485e-01
    z[1,0,4]  R254      1.5287660062313080e-01
    z[1,0,4]  R255      2.5118967890739441e-01
    z[1,0,4]  R256      -2.6883220672607422e-01
    z[1,0,4]  R257      -3.3918708562850952e-01
    z[1,0,4]  R258      -6.6147160530090332e-01
    z[1,0,4]  R259      -2.0417188107967377e-01
    z[1,0,4]  R260      -5.5270522832870483e-01
    z[1,0,4]  R261      -1.6242443025112152e-01
    z[1,0,4]  R262      -1.1494395136833191e-01
    z[1,0,4]  R263      0.266864150762558
    z[1,0,4]  R264      -2.5346624851226807e-01
    z[1,0,4]  R265      -6.0920345783233643e-01
    z[1,0,4]  R266      8.4399111568927765e-02
    z[1,0,4]  R267      1.6527533531188965e-01
    z[1,0,4]  R268      -2.7962797880172729e-01
    z[1,0,4]  R269      4.2009231448173523e-01
    z[1,0,4]  R270      0.295994371175766
    z[1,0,4]  R271      2.5245073437690735e-01
    z[1,0,4]  R272      -6.1801366508007050e-02
    z[1,0,4]  R273      -1.2375334650278091e-01
    z[1,0,4]  R274      -4.7407916188240051e-01
    z[1,0,4]  R275      8.1504352390766144e-02
    z[1,0,4]  R276      -4.5216631889343262e-01
    z[1,0,4]  R277      -6.6905029118061066e-02
    z[1,0,4]  R278      6.5174782276153564e-01
    z[1,0,4]  R279      7.1326738595962524e-01
    z[1,0,4]  R280      7.3842769861221313e-01
    z[1,0,4]  R281      7.4505013227462769e-01
    z[1,0,4]  R282      2.8075304627418518e-01
    z[1,0,4]  R283      2.9651144146919250e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R180      -1
    z[1,0,5]  R181      1
    z[1,0,5]  R184      -3.3961209654808044e-01
    z[1,0,5]  R185      1.8544797599315643e-01
    z[1,0,5]  R186      1.1440439522266388e-01
    z[1,0,5]  R187      6.5428024530410767e-01
    z[1,0,5]  R188      4.4936504960060120e-01
    z[1,0,5]  R189      -3.0648830533027649e-01
    z[1,0,5]  R190      1.1762021481990814e-01
    z[1,0,5]  R191      -2.5380519032478333e-01
    z[1,0,5]  R192      -3.1958609819412231e-01
    z[1,0,5]  R193      -8.4092825651168823e-02
    z[1,0,5]  R194      -1.1361759155988693e-01
    z[1,0,5]  R195      4.4120015809312463e-04
    z[1,0,5]  R196      -2.7406115084886551e-02
    z[1,0,5]  R197      1.1172773083671927e-03
    z[1,0,5]  R198      -9.8782189190387726e-02
    z[1,0,5]  R199      -2.7341619133949280e-01
    z[1,0,5]  R200      1.3734828680753708e-02
    z[1,0,5]  R201      -2.1597044542431831e-02
    z[1,0,5]  R202      1.3793526589870453e-01
    z[1,0,5]  R203      0.0759831964969635
    z[1,0,5]  R204      4.6145290136337280e-02
    z[1,0,5]  R205      3.8462081551551819e-01
    z[1,0,5]  R206      0.309256374835968
    z[1,0,5]  R207      -1.5847636759281158e-01
    z[1,0,5]  R208      5.0776267051696777e-01
    z[1,0,5]  R209      2.5914970040321350e-01
    z[1,0,5]  R210      7.1749143302440643e-02
    z[1,0,5]  R211      -3.7542516365647316e-03
    z[1,0,5]  R212      -2.2628861665725708e-01
    z[1,0,5]  R213      -1.9060148298740387e-01
    z[1,0,5]  R214      -3.3287471532821655e-01
    z[1,0,5]  R215      -9.2252299189567566e-02
    z[1,0,5]  R216      -5.5725795030593872e-01
    z[1,0,5]  R217      -2.5712516903877258e-01
    z[1,0,5]  R218      -5.5599504709243774e-01
    z[1,0,5]  R219      -5.6729829311370850e-01
    z[1,0,5]  R220      -4.8965570330619812e-01
    z[1,0,5]  R221      -2.9055011272430420e-01
    z[1,0,5]  R222      1.7456176877021790e-01
    z[1,0,5]  R223      2.8850591182708740e-01
    z[1,0,5]  R224      -2.4103295058012009e-02
    z[1,0,5]  R225      -6.2595404684543610e-02
    z[1,0,5]  R226      -7.4984863400459290e-02
    z[1,0,5]  R227      -1.5337084233760834e-01
    z[1,0,5]  R228      -5.4406648874282837e-01
    z[1,0,5]  R229      -5.2214270830154419e-01
    z[1,0,5]  R230      7.0977574214339256e-03
    z[1,0,5]  R231      5.4667755961418152e-02
    z[1,0,5]  R232      -5.1970493793487549e-01
    z[1,0,5]  R233      -6.0246225446462631e-02
    z[1,0,5]  R234      3.3154781907796860e-02
    z[1,0,5]  R235      -5.5117465555667877e-02
    z[1,0,5]  R236      1.1985098570585251e-01
    z[1,0,5]  R237      1.4734235405921936e-01
    z[1,0,5]  R238      -3.7574142217636108e-02
    z[1,0,5]  R239      -1.2454599142074585e-01
    z[1,0,5]  R240      8.0336481332778931e-02
    z[1,0,5]  R241      3.3352074027061462e-01
    z[1,0,5]  R242      0.199890598654747
    z[1,0,5]  R243      4.5918133109807968e-03
    z[1,0,5]  R244      2.9928517341613770e-01
    z[1,0,5]  R245      -1.6527405381202698e-01
    z[1,0,5]  R246      2.5092652440071106e-01
    z[1,0,5]  R247      -8.0992072820663452e-02
    z[1,0,5]  R248      -2.0962081849575043e-01
    z[1,0,5]  R249      -2.1431510150432587e-01
    z[1,0,5]  R250      2.0304968953132629e-01
    z[1,0,5]  R251      2.5308430194854736e-01
    z[1,0,5]  R252      -3.9577043056488037e-01
    z[1,0,5]  R253      -2.9112765192985535e-01
    z[1,0,5]  R254      -4.1370846331119537e-02
    z[1,0,5]  R255      4.4306054711341858e-02
    z[1,0,5]  R256      -3.8293343782424927e-01
    z[1,0,5]  R257      -1.0646264255046844e-01
    z[1,0,5]  R258      2.1969746053218842e-01
    z[1,0,5]  R259      2.3867359384894371e-02
    z[1,0,5]  R260      -0.0388689860701561
    z[1,0,5]  R261      1.6128288209438324e-01
    z[1,0,5]  R262      -0.00794797670096159
    z[1,0,5]  R263      -7.1854341030120850e-01
    z[1,0,5]  R264      -4.9171975255012512e-01
    z[1,0,5]  R265      -2.2538807988166809e-01
    z[1,0,5]  R266      -1.5266773104667664e-01
    z[1,0,5]  R267      -6.1591911315917969e-01
    z[1,0,5]  R268      -9.8307415843009949e-02
    z[1,0,5]  R269      -2.7063596248626709e-01
    z[1,0,5]  R270      -4.9661588668823242e-01
    z[1,0,5]  R271      -2.4874383583664894e-02
    z[1,0,5]  R272      -4.6894603967666626e-01
    z[1,0,5]  R273      -4.6838322281837463e-01
    z[1,0,5]  R274      3.6219111084938049e-01
    z[1,0,5]  R275      -1.4578401111066341e-02
    z[1,0,5]  R276      -3.8394668698310852e-01
    z[1,0,5]  R277      1.6332481801509857e-01
    z[1,0,5]  R278      -0.304740846157074
    z[1,0,5]  R279      8.4416776895523071e-02
    z[1,0,5]  R280      -0.0711945965886116
    z[1,0,5]  R281      -8.8213659822940826e-02
    z[1,0,5]  R282      -6.8204671144485474e-02
    z[1,0,5]  R283      1.8763428926467896e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R182      -1
    z[1,0,6]  R183      1
    z[1,0,6]  R184      1.0709770768880844e-01
    z[1,0,6]  R185      -2.4973434209823608e-01
    z[1,0,6]  R186      1.0766394436359406e-01
    z[1,0,6]  R187      -1.2142031639814377e-01
    z[1,0,6]  R188      2.6148018240928650e-01
    z[1,0,6]  R189      4.3953621387481689e-01
    z[1,0,6]  R190      -7.3536694981157780e-03
    z[1,0,6]  R191      -9.8360069096088409e-02
    z[1,0,6]  R192      2.5545188784599304e-01
    z[1,0,6]  R193      3.6544266343116760e-01
    z[1,0,6]  R194      2.3569293320178986e-01
    z[1,0,6]  R195      1.7103728652000427e-01
    z[1,0,6]  R196      -1.4125512540340424e-01
    z[1,0,6]  R197      -1.0065762698650360e-01
    z[1,0,6]  R198      -1.8577769398689270e-01
    z[1,0,6]  R199      1.7328223586082458e-01
    z[1,0,6]  R200      -1.8665000796318054e-01
    z[1,0,6]  R201      -1.3384471833705902e-01
    z[1,0,6]  R202      -1.6737556457519531e-01
    z[1,0,6]  R203      -1.9298050552606583e-02
    z[1,0,6]  R204      -1.5526151657104492e-01
    z[1,0,6]  R205      -7.1109756827354431e-02
    z[1,0,6]  R206      -1.9608356058597565e-01
    z[1,0,6]  R207      -2.3779530823230743e-01
    z[1,0,6]  R208      -4.6682038903236389e-01
    z[1,0,6]  R209      -3.0959886312484741e-01
    z[1,0,6]  R210      2.9122793674468994e-01
    z[1,0,6]  R211      1.1080313473939896e-01
    z[1,0,6]  R212      -6.8453967571258545e-01
    z[1,0,6]  R213      -4.1320380568504333e-01
    z[1,0,6]  R214      4.7924613952636719e-01
    z[1,0,6]  R215      5.4809981584548950e-01
    z[1,0,6]  R216      -1.1365757137537003e-01
    z[1,0,6]  R217      -1.4261193573474884e-01
    z[1,0,6]  R218      -7.7522225677967072e-02
    z[1,0,6]  R219      -1.8059577047824860e-01
    z[1,0,6]  R220      -7.2199523448944092e-02
    z[1,0,6]  R221      1.6902619600296021e-01
    z[1,0,6]  R222      -2.3229663074016571e-01
    z[1,0,6]  R223      -2.8217615559697151e-02
    z[1,0,6]  R224      -2.4007629603147507e-02
    z[1,0,6]  R225      -1.7738421261310577e-01
    z[1,0,6]  R226      4.8832595348358154e-01
    z[1,0,6]  R227      -2.4512539803981781e-01
    z[1,0,6]  R228      -8.6079455912113190e-02
    z[1,0,6]  R229      -3.3156612515449524e-01
    z[1,0,6]  R230      2.8960786759853363e-02
    z[1,0,6]  R231      -2.5481003522872925e-01
    z[1,0,6]  R232      1.3467422127723694e-01
    z[1,0,6]  R233      1.0879641771316528e-01
    z[1,0,6]  R234      3.0809977650642395e-01
    z[1,0,6]  R235      3.7304118275642395e-01
    z[1,0,6]  R236      1.1342987418174744e-01
    z[1,0,6]  R237      -1.6270875930786133e-01
    z[1,0,6]  R238      3.9924681186676025e-02
    z[1,0,6]  R239      -2.3157656192779541e-01
    z[1,0,6]  R240      3.9496082812547684e-02
    z[1,0,6]  R241      -2.0244711637496948e-01
    z[1,0,6]  R242      -3.8225898146629333e-01
    z[1,0,6]  R243      -2.5455081462860107e-01
    z[1,0,6]  R244      1.8615677952766418e-01
    z[1,0,6]  R245      1.5265858173370361e-01
    z[1,0,6]  R246      -1.9815099239349365e-01
    z[1,0,6]  R247      -3.2664310932159424e-01
    z[1,0,6]  R248      7.6450914144515991e-02
    z[1,0,6]  R249      -1.9223439693450928e-01
    z[1,0,6]  R250      -2.5919172167778015e-01
    z[1,0,6]  R251      -0.0897860899567604
    z[1,0,6]  R252      2.5229376554489136e-01
    z[1,0,6]  R253      -2.2316303104162216e-02
    z[1,0,6]  R254      -0.338669091463089
    z[1,0,6]  R255      9.2445842921733856e-02
    z[1,0,6]  R256      -2.5557151436805725e-01
    z[1,0,6]  R257      -7.9194277524948120e-02
    z[1,0,6]  R258      -2.8224322199821472e-01
    z[1,0,6]  R259      -3.1068131327629089e-01
    z[1,0,6]  R260      3.7654665112495422e-01
    z[1,0,6]  R261      -1.0305192321538925e-01
    z[1,0,6]  R262      -6.6554355621337891e-01
    z[1,0,6]  R263      2.1697089076042175e-01
    z[1,0,6]  R264      4.6544370055198669e-01
    z[1,0,6]  R265      5.4104685783386230e-02
    z[1,0,6]  R266      2.3567487299442291e-01
    z[1,0,6]  R267      -1.3590492926596198e-05
    z[1,0,6]  R268      -7.0521339774131775e-02
    z[1,0,6]  R269      -2.1600113809108734e-01
    z[1,0,6]  R270      3.0534991621971130e-01
    z[1,0,6]  R271      -1.0304258763790131e-01
    z[1,0,6]  R272      -0.271819144487381
    z[1,0,6]  R273      2.4407637119293213e-01
    z[1,0,6]  R274      -1.1023992300033569e-01
    z[1,0,6]  R275      -3.0594781041145325e-01
    z[1,0,6]  R276      -4.3039354681968689e-01
    z[1,0,6]  R277      -3.1199550628662109e-01
    z[1,0,6]  R278      2.8728822246193886e-02
    z[1,0,6]  R279      8.7794452905654907e-02
    z[1,0,6]  R280      -7.8005760908126831e-02
    z[1,0,6]  R281      -1.7993733286857605e-01
    z[1,0,6]  R282      -0.0995403379201889
    z[1,0,6]  R283      -0.382281631231308
    z[0,3,0]  R2        -1
    z[0,3,0]  R29       1
    z[0,3,0]  R284      -1
    z[0,3,0]  R285      1
    z[0,3,0]  R298      -2.1535484492778778e-01
    z[0,3,0]  R299      -3.9488885551691055e-02
    z[0,3,0]  R300      -7.8452125191688538e-02
    z[0,3,0]  R301      7.0918244123458862e-01
    z[0,3,0]  R302      -3.8819867372512817e-01
    z[0,3,0]  R303      -1.5058794617652893e-01
    z[0,3,0]  R304      4.4029292464256287e-01
    z[0,3,0]  R305      -2.1365895867347717e-01
    z[0,3,0]  R306      -2.2509813308715820e-01
    z[0,3,0]  R307      6.6602796316146851e-01
    z[0,3,0]  R308      -1.6778011620044708e-01
    z[0,3,0]  R309      -7.2544538974761963e-01
    z[0,3,0]  R310      -4.0250718593597412e-01
    z[0,3,0]  R311      -3.7084838747978210e-01
    z[0,3,0]  R312      2.3428241908550262e-01
    z[0,3,0]  R313      -2.2190895676612854e-01
    z[0,3,0]  R314      1.9234074652194977e-01
    z[0,3,0]  R315      -0.652498722076416
    z[0,3,0]  R316      3.4856978803873062e-02
    z[0,3,0]  R317      0.348032146692276
    z[0,3,0]  R318      2.4526895582675934e-01
    z[0,3,0]  R319      -1.3026286661624908e-01
    z[0,3,0]  R320      -9.4464438734576106e-04
    z[0,3,0]  R321      8.1791661679744720e-02
    z[0,3,0]  R322      3.4186458587646484e-01
    z[0,3,0]  R323      2.3441174626350403e-01
    z[0,3,0]  R324      3.6524090170860291e-01
    z[0,3,0]  R325      5.5541205406188965e-01
    z[0,3,0]  R326      7.0683604478836060e-01
    z[0,3,0]  R327      -4.6727705001831055e-01
    z[0,3,0]  R328      -5.2773147821426392e-01
    z[0,3,0]  R329      -2.0565573871135712e-01
    z[0,3,0]  R330      2.9430902004241943e-01
    z[0,3,0]  R331      4.7490376234054565e-01
    z[0,3,0]  R332      -2.2350879013538361e-01
    z[0,3,0]  R333      4.8200567252933979e-03
    z[0,3,0]  R334      -1.8080001696944237e-02
    z[0,3,0]  R335      -1.2275114655494690e-01
    z[0,3,0]  R336      -6.5519958734512329e-01
    z[0,3,0]  R337      -6.2339651584625244e-01
    z[0,3,0]  R338      -0.0724978893995285
    z[0,3,0]  R339      -4.6777565032243729e-02
    z[0,3,0]  R340      -2.4329090118408203e-01
    z[0,3,0]  R341      4.0715175867080688e-01
    z[0,3,0]  R342      4.3260368704795837e-01
    z[0,3,0]  R343      0.0834726095199585
    z[0,3,0]  R344      2.7277067303657532e-01
    z[0,3,0]  R345      -1.8065112829208374e-01
    z[0,3,0]  R346      6.1964333057403564e-01
    z[0,3,0]  R347      0.50345778465271
    z[0,3,0]  R348      -4.7514325380325317e-01
    z[0,3,0]  R349      -7.3216485977172852e-01
    z[0,3,0]  R350      -6.8617612123489380e-02
    z[0,3,0]  R351      -1.3920140266418457e-01
    z[0,3,0]  R352      3.6757206916809082e-01
    z[0,3,0]  R353      -6.3396227359771729e-01
    z[0,3,0]  R354      1.8794808536767960e-02
    z[0,3,0]  R355      5.7484483718872070e-01
    z[0,3,0]  R356      -0.646687924861908
    z[0,3,0]  R357      -3.1646620482206345e-02
    z[0,3,0]  R358      5.3065598011016846e-02
    z[0,3,0]  R359      -4.2238497734069824e-01
    z[0,3,0]  R360      1.4733880758285522e-01
    z[0,3,0]  R361      1.1937868595123291e-01
    z[0,3,0]  R362      -3.7263453006744385e-01
    z[0,3,0]  R363      -4.0921968221664429e-01
    z[0,3,0]  R364      -3.6647709202952683e-04
    z[0,3,0]  R365      1.9305494427680969e-01
    z[0,3,0]  R366      5.4454523324966431e-01
    z[0,3,0]  R367      -0.0954597219824791
    z[0,3,0]  R368      -1.1888053268194199e-02
    z[0,3,0]  R369      0.171873077750206
    z[0,3,0]  R370      1.6375808417797089e-01
    z[0,3,0]  R371      -3.5804528743028641e-02
    z[0,3,0]  R372      2.4036203324794769e-01
    z[0,3,0]  R373      1.1482414603233337e-01
    z[0,3,0]  R374      2.5157424807548523e-01
    z[0,3,0]  R375      1.0743453353643417e-01
    z[0,3,0]  R376      4.7169345617294312e-01
    z[0,3,0]  R377      0.588336706161499
    z[0,3,0]  R378      0.281033456325531
    z[0,3,0]  R379      1.3424830138683319e-01
    z[0,3,0]  R380      -4.6949443221092224e-01
    z[0,3,0]  R381      -1.7303615808486938e-01
    z[0,3,0]  R382      7.3897249996662140e-02
    z[0,3,0]  R383      5.4487264156341553e-01
    z[0,3,0]  R384      -0.185902938246727
    z[0,3,0]  R385      1.8640726804733276e-01
    z[0,3,0]  R386      2.7073812484741211e-01
    z[0,3,0]  R387      -4.0726426243782043e-01
    z[0,3,0]  R388      -3.0519025400280952e-02
    z[0,3,0]  R389      1.7708288133144379e-01
    z[0,3,0]  R390      -3.5844030976295471e-01
    z[0,3,0]  R391      -1.4807590842247009e-01
    z[0,3,0]  R392      0.0971425324678421
    z[0,3,0]  R393      4.5451264828443527e-02
    z[0,3,0]  R394      7.7890351414680481e-02
    z[0,3,0]  R395      -2.6252783834934235e-02
    z[0,3,0]  R396      1.1205359548330307e-01
    z[0,3,0]  R397      8.0074248835444450e-03
    z[0,3,1]  R3        -1
    z[0,3,1]  R30       1
    z[0,3,1]  R286      -1
    z[0,3,1]  R287      1
    z[0,3,1]  R298      -3.0321920290589333e-02
    z[0,3,1]  R299      -7.5307391583919525e-02
    z[0,3,1]  R300      -3.1644946336746216e-01
    z[0,3,1]  R301      -1.5134041011333466e-01
    z[0,3,1]  R302      -6.8925797939300537e-01
    z[0,3,1]  R303      -4.8932152986526489e-01
    z[0,3,1]  R304      -5.0690180063247681e-01
    z[0,3,1]  R305      -4.5356574654579163e-01
    z[0,3,1]  R306      -6.5307593345642090e-01
    z[0,3,1]  R307      -3.5230189561843872e-01
    z[0,3,1]  R308      7.1265035867691040e-01
    z[0,3,1]  R309      5.2123963832855225e-01
    z[0,3,1]  R310      3.3907601237297058e-01
    z[0,3,1]  R311      7.0849084854125977e-01
    z[0,3,1]  R312      -4.3920555710792542e-01
    z[0,3,1]  R313      -3.4710294008255005e-01
    z[0,3,1]  R314      2.8536980971693993e-02
    z[0,3,1]  R315      -3.4474188089370728e-01
    z[0,3,1]  R316      -3.0235031247138977e-01
    z[0,3,1]  R317      3.3155802637338638e-02
    z[0,3,1]  R318      5.0876444578170776e-01
    z[0,3,1]  R319      -3.3810412883758545e-01
    z[0,3,1]  R320      -5.5801117420196533e-01
    z[0,3,1]  R321      -6.1173391342163086e-01
    z[0,3,1]  R322      2.6103922724723816e-01
    z[0,3,1]  R323      -4.5754346251487732e-01
    z[0,3,1]  R324      -2.2389478981494904e-01
    z[0,3,1]  R325      -1.1795723438262939e-01
    z[0,3,1]  R326      -1.2165439873933792e-01
    z[0,3,1]  R327      -5.4975450038909912e-01
    z[0,3,1]  R328      3.0264306068420410e-01
    z[0,3,1]  R329      -3.2424178719520569e-01
    z[0,3,1]  R330      -4.3738925457000732e-01
    z[0,3,1]  R331      -2.7944907546043396e-01
    z[0,3,1]  R332      3.3062603324651718e-02
    z[0,3,1]  R333      4.6390235424041748e-02
    z[0,3,1]  R334      2.0292538404464722e-01
    z[0,3,1]  R335      -8.7912291288375854e-02
    z[0,3,1]  R336      -3.1532719731330872e-01
    z[0,3,1]  R337      -3.0995562672615051e-01
    z[0,3,1]  R338      -4.9576304852962494e-02
    z[0,3,1]  R339      7.2479605674743652e-02
    z[0,3,1]  R340      2.3105706274509430e-01
    z[0,3,1]  R341      -2.5389257073402405e-01
    z[0,3,1]  R342      -4.3938377499580383e-01
    z[0,3,1]  R343      -3.6427742242813110e-01
    z[0,3,1]  R344      -2.4248623847961426e-01
    z[0,3,1]  R345      -4.6545240283012390e-01
    z[0,3,1]  R346      -7.4089878797531128e-01
    z[0,3,1]  R347      -7.9328811168670654e-01
    z[0,3,1]  R348      5.8730334043502808e-01
    z[0,3,1]  R349      -1.2613086402416229e-01
    z[0,3,1]  R350      6.6275602579116821e-01
    z[0,3,1]  R351      -4.1508737206459045e-01
    z[0,3,1]  R352      3.2214462757110596e-01
    z[0,3,1]  R353      -5.2270042896270752e-01
    z[0,3,1]  R354      -2.3105403780937195e-01
    z[0,3,1]  R355      6.9843542575836182e-01
    z[0,3,1]  R356      -1.9056378304958344e-01
    z[0,3,1]  R357      2.1849560737609863e-01
    z[0,3,1]  R358      1.7878186702728271e-01
    z[0,3,1]  R359      2.7323865890502930e-01
    z[0,3,1]  R360      1.0493151843547821e-01
    z[0,3,1]  R361      -3.5202798247337341e-01
    z[0,3,1]  R362      1.1936495453119278e-01
    z[0,3,1]  R363      1.4401400089263916e-01
    z[0,3,1]  R364      -1.7586109042167664e-01
    z[0,3,1]  R365      2.0621287822723389e-01
    z[0,3,1]  R366      1.2347144633531570e-01
    z[0,3,1]  R367      -1.7415875196456909e-01
    z[0,3,1]  R368      0.224227637052536
    z[0,3,1]  R369      -1.6536530852317810e-01
    z[0,3,1]  R370      2.7318241074681282e-02
    z[0,3,1]  R371      -5.0901472568511963e-01
    z[0,3,1]  R372      0.830104649066925
    z[0,3,1]  R373      -7.4446122162044048e-03
    z[0,3,1]  R374      5.8689326047897339e-01
    z[0,3,1]  R375      -1.6676047444343567e-01
    z[0,3,1]  R376      -1.4324536919593811e-01
    z[0,3,1]  R377      -1.6525343060493469e-01
    z[0,3,1]  R378      6.4252667129039764e-02
    z[0,3,1]  R379      -3.2476228475570679e-01
    z[0,3,1]  R380      -1.9919112324714661e-01
    z[0,3,1]  R381      5.5956762284040451e-02
    z[0,3,1]  R382      -4.8003333806991577e-01
    z[0,3,1]  R383      -1.9607719033956528e-02
    z[0,3,1]  R384      1.0768979787826538e-01
    z[0,3,1]  R385      1.4857201278209686e-01
    z[0,3,1]  R386      -1.0986895859241486e-01
    z[0,3,1]  R387      -3.8663852214813232e-01
    z[0,3,1]  R388      -2.2436386346817017e-01
    z[0,3,1]  R389      1.0586047172546387e-01
    z[0,3,1]  R390      8.6570112034678459e-03
    z[0,3,1]  R391      6.6662162542343140e-02
    z[0,3,1]  R392      2.4361225962638855e-01
    z[0,3,1]  R393      -1.4660495519638062e-01
    z[0,3,1]  R394      -3.5686942934989929e-01
    z[0,3,1]  R395      -4.2440363764762878e-01
    z[0,3,1]  R396      -2.1864071488380432e-01
    z[0,3,1]  R397      -0.318697065114975
    z[0,3,2]  R4        -1
    z[0,3,2]  R31       1
    z[0,3,2]  R288      -1
    z[0,3,2]  R289      1
    z[0,3,2]  R298      6.7125105857849121e-01
    z[0,3,2]  R299      8.3312809467315674e-01
    z[0,3,2]  R300      7.2451949119567871e-01
    z[0,3,2]  R301      -3.2872074842453003e-01
    z[0,3,2]  R302      -4.1633170843124390e-01
    z[0,3,2]  R303      -0.743471622467041
    z[0,3,2]  R304      -3.3147627115249634e-01
    z[0,3,2]  R305      -5.0266003608703613e-01
    z[0,3,2]  R306      -4.0125921368598938e-01
    z[0,3,2]  R307      -2.0253057777881622e-01
    z[0,3,2]  R308      -1.5846388041973114e-01
    z[0,3,2]  R309      -1.2504948675632477e-01
    z[0,3,2]  R310      -2.1178555488586426e-01
    z[0,3,2]  R311      -2.9686334729194641e-01
    z[0,3,2]  R312      -0.304912269115448
    z[0,3,2]  R313      -7.9474258422851562e-01
    z[0,3,2]  R314      -3.6457756161689758e-01
    z[0,3,2]  R315      -6.0136336088180542e-01
    z[0,3,2]  R316      -6.6898334026336670e-01
    z[0,3,2]  R317      -4.3192937970161438e-01
    z[0,3,2]  R318      3.6812517046928406e-01
    z[0,3,2]  R319      -5.8046752214431763e-01
    z[0,3,2]  R320      -0.46873739361763
    z[0,3,2]  R321      -4.2359763383865356e-01
    z[0,3,2]  R322      -7.3792028427124023e-01
    z[0,3,2]  R323      -0.58502197265625
    z[0,3,2]  R324      -3.7277403473854065e-01
    z[0,3,2]  R325      -5.4082602262496948e-01
    z[0,3,2]  R326      -0.410214364528656
    z[0,3,2]  R327      -3.9602348208427429e-01
    z[0,3,2]  R328      2.6167321205139160e-01
    z[0,3,2]  R329      -8.2806068658828735e-01
    z[0,3,2]  R330      -4.2722231149673462e-01
    z[0,3,2]  R331      -5.6709778308868408e-01
    z[0,3,2]  R332      3.5582524538040161e-01
    z[0,3,2]  R333      0.215763658285141
    z[0,3,2]  R334      3.0487173795700073e-01
    z[0,3,2]  R335      3.3832532167434692e-01
    z[0,3,2]  R336      3.5561352968215942e-01
    z[0,3,2]  R337      2.7809631824493408e-01
    z[0,3,2]  R338      7.7604496479034424e-01
    z[0,3,2]  R339      6.0417407751083374e-01
    z[0,3,2]  R340      5.0335592031478882e-01
    z[0,3,2]  R341      -6.9426339864730835e-01
    z[0,3,2]  R342      -7.7314120531082153e-01
    z[0,3,2]  R343      -7.2934788465499878e-01
    z[0,3,2]  R344      -8.4491407871246338e-01
    z[0,3,2]  R345      -8.0140662193298340e-01
    z[0,3,2]  R346      2.1349819377064705e-02
    z[0,3,2]  R347      -1.2619367334991693e-03
    z[0,3,2]  R348      -2.8861820697784424e-01
    z[0,3,2]  R349      2.0243752002716064e-01
    z[0,3,2]  R350      1.3058094680309296e-01
    z[0,3,2]  R351      -4.0662899613380432e-01
    z[0,3,2]  R352      -2.4025954306125641e-01
    z[0,3,2]  R353      -4.4705423712730408e-01
    z[0,3,2]  R354      -3.4929844737052917e-01
    z[0,3,2]  R355      -2.6159957051277161e-01
    z[0,3,2]  R356      -3.8386201858520508e-01
    z[0,3,2]  R357      -1.2975965440273285e-01
    z[0,3,2]  R358      6.3734084367752075e-01
    z[0,3,2]  R359      -1.9241769611835480e-01
    z[0,3,2]  R360      -8.8255876302719116e-01
    z[0,3,2]  R361      -5.4816991090774536e-01
    z[0,3,2]  R362      -6.3943284749984741e-01
    z[0,3,2]  R363      -4.0944692492485046e-01
    z[0,3,2]  R364      -6.5266954898834229e-01
    z[0,3,2]  R365      -1.9232214987277985e-01
    z[0,3,2]  R366      -5.2635037899017334e-01
    z[0,3,2]  R367      -6.7669701576232910e-01
    z[0,3,2]  R368      -6.8888491392135620e-01
    z[0,3,2]  R369      -0.37347611784935
    z[0,3,2]  R370      -0.797686755657196
    z[0,3,2]  R371      -1.9151577353477478e-01
    z[0,3,2]  R372      -5.8459974825382233e-02
    z[0,3,2]  R373      1.5644293278455734e-02
    z[0,3,2]  R374      -3.7999540567398071e-01
    z[0,3,2]  R375      -2.8968313336372375e-01
    z[0,3,2]  R376      2.9470187425613403e-01
    z[0,3,2]  R377      -2.9661780595779419e-01
    z[0,3,2]  R378      -5.4275822639465332e-01
    z[0,3,2]  R379      -3.4621232748031616e-01
    z[0,3,2]  R380      -2.6808315515518188e-01
    z[0,3,2]  R381      -1.0409136116504669e-01
    z[0,3,2]  R382      -4.9149307608604431e-01
    z[0,3,2]  R383      -4.5655825734138489e-01
    z[0,3,2]  R384      -4.3433123826980591e-01
    z[0,3,2]  R385      -4.2819681763648987e-01
    z[0,3,2]  R386      -8.9572280645370483e-02
    z[0,3,2]  R387      -1.3207964599132538e-01
    z[0,3,2]  R388      -4.7002637386322021e-01
    z[0,3,2]  R389      -2.5709491968154907e-01
    z[0,3,2]  R390      -1.9683119654655457e-01
    z[0,3,2]  R391      -3.2945030927658081e-01
    z[0,3,2]  R392      -4.3652319908142090e-01
    z[0,3,2]  R393      -6.7894309759140015e-01
    z[0,3,2]  R394      -4.7322505712509155e-01
    z[0,3,2]  R395      -4.1342398524284363e-01
    z[0,3,2]  R396      9.5625430345535278e-02
    z[0,3,2]  R397      -1.9718685746192932e-01
    z[0,3,3]  R5        -1
    z[0,3,3]  R32       1
    z[0,3,3]  R290      -1
    z[0,3,3]  R291      1
    z[0,3,3]  R298      2.0664745569229126e-01
    z[0,3,3]  R299      4.7480484843254089e-01
    z[0,3,3]  R300      4.3962135910987854e-01
    z[0,3,3]  R301      -2.5441274046897888e-01
    z[0,3,3]  R302      -2.7254417538642883e-01
    z[0,3,3]  R303      -2.8050050139427185e-01
    z[0,3,3]  R304      -4.8772194981575012e-01
    z[0,3,3]  R305      -4.4571301341056824e-01
    z[0,3,3]  R306      -3.7584298849105835e-01
    z[0,3,3]  R307      -4.0352451801300049e-01
    z[0,3,3]  R308      5.4689025878906250e-01
    z[0,3,3]  R309      3.3585020899772644e-01
    z[0,3,3]  R310      6.2764382362365723e-01
    z[0,3,3]  R311      3.7380534410476685e-01
    z[0,3,3]  R312      -3.0621209740638733e-01
    z[0,3,3]  R313      -2.4470698833465576e-01
    z[0,3,3]  R314      -6.1684083938598633e-01
    z[0,3,3]  R315      -1.7534834146499634e-01
    z[0,3,3]  R316      6.0059234499931335e-02
    z[0,3,3]  R317      -2.3793654143810272e-01
    z[0,3,3]  R318      1.5104448795318604e-01
    z[0,3,3]  R319      -3.2698428630828857e-01
    z[0,3,3]  R320      -6.1881709098815918e-01
    z[0,3,3]  R321      -1.8161654472351074e-01
    z[0,3,3]  R322      -0.421463280916214
    z[0,3,3]  R323      -3.1157109141349792e-01
    z[0,3,3]  R324      -5.0003111362457275e-01
    z[0,3,3]  R325      -0.556904673576355
    z[0,3,3]  R326      -1.4032730460166931e-01
    z[0,3,3]  R327      -1.6827519237995148e-01
    z[0,3,3]  R328      4.3971300125122070e-01
    z[0,3,3]  R329      -2.5773823261260986e-01
    z[0,3,3]  R330      4.9456138163805008e-02
    z[0,3,3]  R331      -4.9626830220222473e-01
    z[0,3,3]  R332      -0.551245391368866
    z[0,3,3]  R333      -6.5397721529006958e-01
    z[0,3,3]  R334      -5.5598431825637817e-01
    z[0,3,3]  R335      -5.1718544960021973e-01
    z[0,3,3]  R336      -5.0143682956695557e-01
    z[0,3,3]  R337      -4.1073319315910339e-01
    z[0,3,3]  R338      4.6331736445426941e-01
    z[0,3,3]  R339      5.4184055328369141e-01
    z[0,3,3]  R340      2.7046254277229309e-01
    z[0,3,3]  R341      -2.1978422999382019e-01
    z[0,3,3]  R342      -8.0081552267074585e-02
    z[0,3,3]  R343      -1.6590537130832672e-01
    z[0,3,3]  R344      -1.3935063779354095e-01
    z[0,3,3]  R345      -2.6957049965858459e-01
    z[0,3,3]  R346      2.0872354507446289e-02
    z[0,3,3]  R347      -1.9338840246200562e-01
    z[0,3,3]  R348      4.6935191750526428e-01
    z[0,3,3]  R349      1.7970761656761169e-01
    z[0,3,3]  R350      1.6824183985590935e-02
    z[0,3,3]  R351      -5.7796674966812134e-01
    z[0,3,3]  R352      -6.2334847450256348e-01
    z[0,3,3]  R353      -1.8919529020786285e-01
    z[0,3,3]  R354      -5.4911768436431885e-01
    z[0,3,3]  R355      -1.9732019305229187e-01
    z[0,3,3]  R356      -3.9041116833686829e-01
    z[0,3,3]  R357      -5.4226309061050415e-01
    z[0,3,3]  R358      4.0418922901153564e-02
    z[0,3,3]  R359      -7.1027135848999023e-01
    z[0,3,3]  R360      -1.6832639276981354e-01
    z[0,3,3]  R361      -3.5620700567960739e-02
    z[0,3,3]  R362      -6.4964437484741211e-01
    z[0,3,3]  R363      -6.6607069969177246e-01
    z[0,3,3]  R364      -1.9485194236040115e-02
    z[0,3,3]  R365      -6.3764536380767822e-01
    z[0,3,3]  R366      -7.3052115738391876e-02
    z[0,3,3]  R367      -1.2792097032070160e-01
    z[0,3,3]  R368      -6.7898309230804443e-01
    z[0,3,3]  R369      -6.8302422761917114e-01
    z[0,3,3]  R370      -1.9481922686100006e-01
    z[0,3,3]  R371      -7.0268255472183228e-01
    z[0,3,3]  R372      -3.1143969297409058e-01
    z[0,3,3]  R373      -6.5013659000396729e-01
    z[0,3,3]  R374      -6.2126046419143677e-01
    z[0,3,3]  R375      -6.1172151565551758e-01
    z[0,3,3]  R376      -0.515038788318634
    z[0,3,3]  R377      -4.8638768494129181e-02
    z[0,3,3]  R378      -7.3414909839630127e-01
    z[0,3,3]  R379      -6.8878930807113647e-01
    z[0,3,3]  R380      -6.7565697431564331e-01
    z[0,3,3]  R381      -6.7065227031707764e-01
    z[0,3,3]  R382      -6.6765159368515015e-01
    z[0,3,3]  R383      -7.4274338781833649e-02
    z[0,3,3]  R384      -6.3615453243255615e-01
    z[0,3,3]  R385      -6.1579936742782593e-01
    z[0,3,3]  R386      -6.6821444034576416e-01
    z[0,3,3]  R387      -0.645698070526123
    z[0,3,3]  R388      -7.2707247734069824e-01
    z[0,3,3]  R389      -7.0280331373214722e-01
    z[0,3,3]  R390      -7.2421997785568237e-01
    z[0,3,3]  R391      -6.5282362699508667e-01
    z[0,3,3]  R392      -6.3655519485473633e-01
    z[0,3,3]  R393      -4.8466604202985764e-02
    z[0,3,3]  R394      7.0134699344635010e-03
    z[0,3,3]  R395      1.9812983274459839e-01
    z[0,3,3]  R396      -5.5316168069839478e-01
    z[0,3,3]  R397      -6.0439020395278931e-01
    z[0,3,4]  R6        -1
    z[0,3,4]  R33       1
    z[0,3,4]  R292      -1
    z[0,3,4]  R293      1
    z[0,3,4]  R298      -5.7896101474761963e-01
    z[0,3,4]  R299      1.5035691857337952e-01
    z[0,3,4]  R300      -2.7070587873458862e-01
    z[0,3,4]  R301      -4.3372547626495361e-01
    z[0,3,4]  R302      2.7717721462249756e-01
    z[0,3,4]  R303      1.5353174507617950e-01
    z[0,3,4]  R304      0.305014431476593
    z[0,3,4]  R305      4.7453922033309937e-01
    z[0,3,4]  R306      -1.6413001343607903e-02
    z[0,3,4]  R307      3.7839943170547485e-01
    z[0,3,4]  R308      1.5287660062313080e-01
    z[0,3,4]  R309      2.5118967890739441e-01
    z[0,3,4]  R310      -2.6883220672607422e-01
    z[0,3,4]  R311      -3.3918708562850952e-01
    z[0,3,4]  R312      -6.6147160530090332e-01
    z[0,3,4]  R313      -2.0417188107967377e-01
    z[0,3,4]  R314      -5.5270522832870483e-01
    z[0,3,4]  R315      -1.6242443025112152e-01
    z[0,3,4]  R316      -1.1494395136833191e-01
    z[0,3,4]  R317      0.266864150762558
    z[0,3,4]  R318      -2.5346624851226807e-01
    z[0,3,4]  R319      -6.0920345783233643e-01
    z[0,3,4]  R320      8.4399111568927765e-02
    z[0,3,4]  R321      1.6527533531188965e-01
    z[0,3,4]  R322      -2.7962797880172729e-01
    z[0,3,4]  R323      4.2009231448173523e-01
    z[0,3,4]  R324      0.295994371175766
    z[0,3,4]  R325      2.5245073437690735e-01
    z[0,3,4]  R326      -6.1801366508007050e-02
    z[0,3,4]  R327      -1.2375334650278091e-01
    z[0,3,4]  R328      -4.7407916188240051e-01
    z[0,3,4]  R329      8.1504352390766144e-02
    z[0,3,4]  R330      -4.5216631889343262e-01
    z[0,3,4]  R331      -6.6905029118061066e-02
    z[0,3,4]  R332      6.5174782276153564e-01
    z[0,3,4]  R333      7.1326738595962524e-01
    z[0,3,4]  R334      7.3842769861221313e-01
    z[0,3,4]  R335      7.4505013227462769e-01
    z[0,3,4]  R336      2.8075304627418518e-01
    z[0,3,4]  R337      2.9651144146919250e-01
    z[0,3,4]  R338      4.3865670450031757e-03
    z[0,3,4]  R339      -4.6118754148483276e-01
    z[0,3,4]  R340      1.1841346323490143e-01
    z[0,3,4]  R341      -4.7443667054176331e-01
    z[0,3,4]  R342      -1.2131082266569138e-01
    z[0,3,4]  R343      -4.9943828582763672e-01
    z[0,3,4]  R344      6.9983549416065216e-02
    z[0,3,4]  R345      -0.00828845240175724
    z[0,3,4]  R346      -1.6975876688957214e-01
    z[0,3,4]  R347      2.5520551204681396e-01
    z[0,3,4]  R348      8.3239749073982239e-02
    z[0,3,4]  R349      5.7291269302368164e-01
    z[0,3,4]  R350      0.691063642501831
    z[0,3,4]  R351      -3.2358980178833008e-01
    z[0,3,4]  R352      -2.2980056703090668e-01
    z[0,3,4]  R353      -2.0617288351058960e-01
    z[0,3,4]  R354      6.4487653970718384e-01
    z[0,3,4]  R355      -1.8258714675903320e-01
    z[0,3,4]  R356      -2.4823729693889618e-01
    z[0,3,4]  R357      -5.5757266283035278e-01
    z[0,3,4]  R358      1.7272646725177765e-01
    z[0,3,4]  R359      -4.4808611273765564e-01
    z[0,3,4]  R360      -0.305568128824234
    z[0,3,4]  R361      -7.2267204523086548e-01
    z[0,3,4]  R362      -6.1701640486717224e-02
    z[0,3,4]  R363      -2.0890070497989655e-01
    z[0,3,4]  R364      -4.6491956710815430e-01
    z[0,3,4]  R365      -5.3467798233032227e-01
    z[0,3,4]  R366      -4.5001673698425293e-01
    z[0,3,4]  R367      -5.4272848367691040e-01
    z[0,3,4]  R368      -0.089384526014328
    z[0,3,4]  R369      -5.0186169147491455e-01
    z[0,3,4]  R370      -4.6230247616767883e-01
    z[0,3,4]  R371      -2.9163831472396851e-01
    z[0,3,4]  R372      -3.0278894305229187e-01
    z[0,3,4]  R373      -6.4142870903015137e-01
    z[0,3,4]  R374      -2.3578768968582153e-01
    z[0,3,4]  R375      -3.8169345259666443e-01
    z[0,3,4]  R376      5.5134284496307373e-01
    z[0,3,4]  R377      -6.7655169963836670e-01
    z[0,3,4]  R378      -0.108512744307518
    z[0,3,4]  R379      -4.1247400641441345e-01
    z[0,3,4]  R380      -4.0192928910255432e-01
    z[0,3,4]  R381      -6.9580215215682983e-01
    z[0,3,4]  R382      -1.1318396031856537e-01
    z[0,3,4]  R383      -6.7420035600662231e-01
    z[0,3,4]  R384      -2.3520049452781677e-01
    z[0,3,4]  R385      -2.8921106457710266e-01
    z[0,3,4]  R386      -3.5419189929962158e-01
    z[0,3,4]  R387      -3.9894768595695496e-01
    z[0,3,4]  R388      -3.5633343458175659e-01
    z[0,3,4]  R389      -5.8956694602966309e-01
    z[0,3,4]  R390      -5.1626938581466675e-01
    z[0,3,4]  R391      -4.4307643175125122e-01
    z[0,3,4]  R392      -2.6427084207534790e-01
    z[0,3,4]  R393      -6.7825454473495483e-01
    z[0,3,4]  R394      -7.0003032684326172e-01
    z[0,3,4]  R395      -5.7839977741241455e-01
    z[0,3,4]  R396      4.3254518508911133e-01
    z[0,3,4]  R397      6.2546718120574951e-01
    z[0,3,5]  R7        -1
    z[0,3,5]  R34       1
    z[0,3,5]  R294      -1
    z[0,3,5]  R295      1
    z[0,3,5]  R298      2.9928517341613770e-01
    z[0,3,5]  R299      -1.6527405381202698e-01
    z[0,3,5]  R300      2.5092652440071106e-01
    z[0,3,5]  R301      -8.0992072820663452e-02
    z[0,3,5]  R302      -2.0962081849575043e-01
    z[0,3,5]  R303      -2.1431510150432587e-01
    z[0,3,5]  R304      2.0304968953132629e-01
    z[0,3,5]  R305      2.5308430194854736e-01
    z[0,3,5]  R306      -3.9577043056488037e-01
    z[0,3,5]  R307      -2.9112765192985535e-01
    z[0,3,5]  R308      -4.1370846331119537e-02
    z[0,3,5]  R309      4.4306054711341858e-02
    z[0,3,5]  R310      -3.8293343782424927e-01
    z[0,3,5]  R311      -1.0646264255046844e-01
    z[0,3,5]  R312      2.1969746053218842e-01
    z[0,3,5]  R313      2.3867359384894371e-02
    z[0,3,5]  R314      -0.0388689860701561
    z[0,3,5]  R315      1.6128288209438324e-01
    z[0,3,5]  R316      -0.00794797670096159
    z[0,3,5]  R317      -7.1854341030120850e-01
    z[0,3,5]  R318      -4.9171975255012512e-01
    z[0,3,5]  R319      -2.2538807988166809e-01
    z[0,3,5]  R320      -1.5266773104667664e-01
    z[0,3,5]  R321      -6.1591911315917969e-01
    z[0,3,5]  R322      -9.8307415843009949e-02
    z[0,3,5]  R323      -2.7063596248626709e-01
    z[0,3,5]  R324      -4.9661588668823242e-01
    z[0,3,5]  R325      -2.4874383583664894e-02
    z[0,3,5]  R326      -4.6894603967666626e-01
    z[0,3,5]  R327      -4.6838322281837463e-01
    z[0,3,5]  R328      3.6219111084938049e-01
    z[0,3,5]  R329      -1.4578401111066341e-02
    z[0,3,5]  R330      -3.8394668698310852e-01
    z[0,3,5]  R331      1.6332481801509857e-01
    z[0,3,5]  R332      -0.304740846157074
    z[0,3,5]  R333      8.4416776895523071e-02
    z[0,3,5]  R334      -0.0711945965886116
    z[0,3,5]  R335      -8.8213659822940826e-02
    z[0,3,5]  R336      -6.8204671144485474e-02
    z[0,3,5]  R337      1.8763428926467896e-01
    z[0,3,5]  R338      -1.2052126228809357e-01
    z[0,3,5]  R339      2.6374953985214233e-01
    z[0,3,5]  R340      5.2855336666107178e-01
    z[0,3,5]  R341      -1.2794802896678448e-02
    z[0,3,5]  R342      2.9707642272114754e-02
    z[0,3,5]  R343      -1.0103664547204971e-01
    z[0,3,5]  R344      -1.8102893233299255e-01
    z[0,3,5]  R345      -1.5770480036735535e-01
    z[0,3,5]  R346      -1.4267264306545258e-01
    z[0,3,5]  R347      -1.1971701681613922e-01
    z[0,3,5]  R348      -3.1781506538391113e-01
    z[0,3,5]  R349      -1.6603751480579376e-01
    z[0,3,5]  R350      -1.8935577571392059e-01
    z[0,3,5]  R351      -8.9161597192287445e-02
    z[0,3,5]  R352      0.506896436214447
    z[0,3,5]  R353      2.1081382036209106e-01
    z[0,3,5]  R354      -2.1602389216423035e-01
    z[0,3,5]  R355      1.9781798124313354e-01
    z[0,3,5]  R356      -1.3992623426020145e-02
    z[0,3,5]  R357      5.7354468107223511e-01
    z[0,3,5]  R358      2.5632017850875854e-01
    z[0,3,5]  R359      -2.4334864690899849e-02
    z[0,3,5]  R360      -1.5140607953071594e-01
    z[0,3,5]  R361      -4.8199485987424850e-02
    z[0,3,5]  R362      -8.7031446397304535e-02
    z[0,3,5]  R363      -3.0716273188591003e-01
    z[0,3,5]  R364      2.5415403768420219e-02
    z[0,3,5]  R365      4.2185807228088379e-01
    z[0,3,5]  R366      -3.4934419393539429e-01
    z[0,3,5]  R367      4.1864994168281555e-01
    z[0,3,5]  R368      -3.0094233807176352e-04
    z[0,3,5]  R369      -2.9137805104255676e-01
    z[0,3,5]  R370      -1.2672282755374908e-02
    z[0,3,5]  R371      -3.3931252360343933e-01
    z[0,3,5]  R372      3.4515149891376495e-02
    z[0,3,5]  R373      2.1613213419914246e-01
    z[0,3,5]  R374      -5.9224888682365417e-02
    z[0,3,5]  R375      -1.7145846784114838e-01
    z[0,3,5]  R376      -2.2228464484214783e-01
    z[0,3,5]  R377      -2.1431162953376770e-01
    z[0,3,5]  R378      -2.3515079915523529e-01
    z[0,3,5]  R379      -9.3471392989158630e-02
    z[0,3,5]  R380      1.8666934967041016e-01
    z[0,3,5]  R381      1.1278792470693588e-01
    z[0,3,5]  R382      2.7752861380577087e-02
    z[0,3,5]  R383      -1.7858222126960754e-01
    z[0,3,5]  R384      4.7819722443819046e-02
    z[0,3,5]  R385      -4.0153592824935913e-01
    z[0,3,5]  R386      6.4882233738899231e-02
    z[0,3,5]  R387      -2.0185214281082153e-01
    z[0,3,5]  R388      -1.3158781826496124e-01
    z[0,3,5]  R389      -1.5511341392993927e-01
    z[0,3,5]  R390      -1.7066916823387146e-01
    z[0,3,5]  R391      4.7792237997055054e-01
    z[0,3,5]  R392      0.279199481010437
    z[0,3,5]  R393      2.1251642704010010e-01
    z[0,3,5]  R394      1.4224325120449066e-01
    z[0,3,5]  R395      -4.1929554939270020e-01
    z[0,3,5]  R396      -6.6018944978713989e-01
    z[0,3,5]  R397      -3.1133770942687988e-02
    z[0,3,6]  R8        -1
    z[0,3,6]  R35       1
    z[0,3,6]  R296      -1
    z[0,3,6]  R297      1
    z[0,3,6]  R298      1.8615677952766418e-01
    z[0,3,6]  R299      1.5265858173370361e-01
    z[0,3,6]  R300      -1.9815099239349365e-01
    z[0,3,6]  R301      -3.2664310932159424e-01
    z[0,3,6]  R302      7.6450914144515991e-02
    z[0,3,6]  R303      -1.9223439693450928e-01
    z[0,3,6]  R304      -2.5919172167778015e-01
    z[0,3,6]  R305      -0.0897860899567604
    z[0,3,6]  R306      2.5229376554489136e-01
    z[0,3,6]  R307      -2.2316303104162216e-02
    z[0,3,6]  R308      -0.338669091463089
    z[0,3,6]  R309      9.2445842921733856e-02
    z[0,3,6]  R310      -2.5557151436805725e-01
    z[0,3,6]  R311      -7.9194277524948120e-02
    z[0,3,6]  R312      -2.8224322199821472e-01
    z[0,3,6]  R313      -3.1068131327629089e-01
    z[0,3,6]  R314      3.7654665112495422e-01
    z[0,3,6]  R315      -1.0305192321538925e-01
    z[0,3,6]  R316      -6.6554355621337891e-01
    z[0,3,6]  R317      2.1697089076042175e-01
    z[0,3,6]  R318      4.6544370055198669e-01
    z[0,3,6]  R319      5.4104685783386230e-02
    z[0,3,6]  R320      2.3567487299442291e-01
    z[0,3,6]  R321      -1.3590492926596198e-05
    z[0,3,6]  R322      -7.0521339774131775e-02
    z[0,3,6]  R323      -2.1600113809108734e-01
    z[0,3,6]  R324      3.0534991621971130e-01
    z[0,3,6]  R325      -1.0304258763790131e-01
    z[0,3,6]  R326      -0.271819144487381
    z[0,3,6]  R327      2.4407637119293213e-01
    z[0,3,6]  R328      -1.1023992300033569e-01
    z[0,3,6]  R329      -3.0594781041145325e-01
    z[0,3,6]  R330      -4.3039354681968689e-01
    z[0,3,6]  R331      -3.1199550628662109e-01
    z[0,3,6]  R332      2.8728822246193886e-02
    z[0,3,6]  R333      8.7794452905654907e-02
    z[0,3,6]  R334      -7.8005760908126831e-02
    z[0,3,6]  R335      -1.7993733286857605e-01
    z[0,3,6]  R336      -0.0995403379201889
    z[0,3,6]  R337      -0.382281631231308
    z[0,3,6]  R338      0.401039719581604
    z[0,3,6]  R339      2.2733974456787109e-01
    z[0,3,6]  R340      5.1721811294555664e-01
    z[0,3,6]  R341      1.1918663978576660e-01
    z[0,3,6]  R342      6.0617448762059212e-03
    z[0,3,6]  R343      2.0301340520381927e-01
    z[0,3,6]  R344      3.0956250429153442e-01
    z[0,3,6]  R345      1.0420594364404678e-01
    z[0,3,6]  R346      1.3056075572967529e-01
    z[0,3,6]  R347      -1.9015483558177948e-02
    z[0,3,6]  R348      -1.3336718082427979e-01
    z[0,3,6]  R349      -1.3766746222972870e-01
    z[0,3,6]  R350      -1.5901888906955719e-01
    z[0,3,6]  R351      -4.4302663207054138e-01
    z[0,3,6]  R352      7.1227133274078369e-02
    z[0,3,6]  R353      -4.7686256468296051e-02
    z[0,3,6]  R354      2.4533452093601227e-01
    z[0,3,6]  R355      -4.3609503656625748e-02
    z[0,3,6]  R356      4.2882591485977173e-01
    z[0,3,6]  R357      -2.3034913465380669e-02
    z[0,3,6]  R358      -6.7959511280059814e-01
    z[0,3,6]  R359      0.063626728951931
    z[0,3,6]  R360      2.0914423465728760e-01
    z[0,3,6]  R361      -1.8838226795196533e-01
    z[0,3,6]  R362      -6.7836657166481018e-02
    z[0,3,6]  R363      2.5002774596214294e-01
    z[0,3,6]  R364      5.7089352607727051e-01
    z[0,3,6]  R365      1.1305678635835648e-01
    z[0,3,6]  R366      2.8510963916778564e-01
    z[0,3,6]  R367      1.2826339900493622e-01
    z[0,3,6]  R368      7.7527396380901337e-02
    z[0,3,6]  R369      -1.8467016518115997e-02
    z[0,3,6]  R370      -2.9033464193344116e-01
    z[0,3,6]  R371      -9.4842657446861267e-02
    z[0,3,6]  R372      2.4467891454696655e-01
    z[0,3,6]  R373      3.2510584592819214e-01
    z[0,3,6]  R374      -5.2937213331460953e-02
    z[0,3,6]  R375      5.7222491502761841e-01
    z[0,3,6]  R376      2.2689729928970337e-01
    z[0,3,6]  R377      1.8042099475860596e-01
    z[0,3,6]  R378      -1.2751290202140808e-01
    z[0,3,6]  R379      -3.2146766781806946e-01
    z[0,3,6]  R380      -1.2298163771629333e-01
    z[0,3,6]  R381      -9.7241960465908051e-02
    z[0,3,6]  R382      2.5140061974525452e-01
    z[0,3,6]  R383      -4.8264440149068832e-02
    z[0,3,6]  R384      -5.5036425590515137e-01
    z[0,3,6]  R385      3.6843335628509521e-01
    z[0,3,6]  R386      5.7483422756195068e-01
    z[0,3,6]  R387      2.2443674504756927e-01
    z[0,3,6]  R388      2.3426796495914459e-01
    z[0,3,6]  R389      -1.6048528254032135e-01
    z[0,3,6]  R390      1.1201063543558121e-01
    z[0,3,6]  R391      1.1910926550626755e-01
    z[0,3,6]  R392      -4.3320894241333008e-01
    z[0,3,6]  R393      8.9084036648273468e-02
    z[0,3,6]  R394      3.6374524235725403e-01
    z[0,3,6]  R395      3.1410580873489380e-01
    z[0,3,6]  R396      3.9531286805868149e-02
    z[0,3,6]  R397      3.1940481066703796e-01
    z[3,0,0]  R2        1
    z[3,0,0]  R29       -1
    z[3,0,0]  R398      -1
    z[3,0,0]  R399      1
    z[3,0,0]  R412      -0.0724978893995285
    z[3,0,0]  R413      -4.6777565032243729e-02
    z[3,0,0]  R414      -2.4329090118408203e-01
    z[3,0,0]  R415      4.0715175867080688e-01
    z[3,0,0]  R416      4.3260368704795837e-01
    z[3,0,0]  R417      0.0834726095199585
    z[3,0,0]  R418      2.7277067303657532e-01
    z[3,0,0]  R419      -1.8065112829208374e-01
    z[3,0,0]  R420      6.1964333057403564e-01
    z[3,0,0]  R421      0.50345778465271
    z[3,0,0]  R422      -4.7514325380325317e-01
    z[3,0,0]  R423      -7.3216485977172852e-01
    z[3,0,0]  R424      -6.8617612123489380e-02
    z[3,0,0]  R425      -1.3920140266418457e-01
    z[3,0,0]  R426      3.6757206916809082e-01
    z[3,0,0]  R427      -6.3396227359771729e-01
    z[3,0,0]  R428      1.8794808536767960e-02
    z[3,0,0]  R429      5.7484483718872070e-01
    z[3,0,0]  R430      -0.646687924861908
    z[3,0,0]  R431      -3.1646620482206345e-02
    z[3,0,0]  R432      5.3065598011016846e-02
    z[3,0,0]  R433      -4.2238497734069824e-01
    z[3,0,0]  R434      1.4733880758285522e-01
    z[3,0,0]  R435      1.1937868595123291e-01
    z[3,0,0]  R436      -3.7263453006744385e-01
    z[3,0,0]  R437      -4.0921968221664429e-01
    z[3,0,0]  R438      -3.6647709202952683e-04
    z[3,0,0]  R439      1.9305494427680969e-01
    z[3,0,0]  R440      5.4454523324966431e-01
    z[3,0,0]  R441      -0.0954597219824791
    z[3,0,0]  R442      -1.1888053268194199e-02
    z[3,0,0]  R443      0.171873077750206
    z[3,0,0]  R444      1.6375808417797089e-01
    z[3,0,0]  R445      -3.5804528743028641e-02
    z[3,0,0]  R446      2.4036203324794769e-01
    z[3,0,0]  R447      1.1482414603233337e-01
    z[3,0,0]  R448      2.5157424807548523e-01
    z[3,0,0]  R449      1.0743453353643417e-01
    z[3,0,0]  R450      4.7169345617294312e-01
    z[3,0,0]  R451      0.588336706161499
    z[3,0,0]  R452      0.281033456325531
    z[3,0,0]  R453      1.3424830138683319e-01
    z[3,0,0]  R454      -4.6949443221092224e-01
    z[3,0,0]  R455      -1.7303615808486938e-01
    z[3,0,0]  R456      7.3897249996662140e-02
    z[3,0,0]  R457      5.4487264156341553e-01
    z[3,0,0]  R458      -0.185902938246727
    z[3,0,0]  R459      1.8640726804733276e-01
    z[3,0,0]  R460      2.7073812484741211e-01
    z[3,0,0]  R461      -4.0726426243782043e-01
    z[3,0,0]  R462      -3.0519025400280952e-02
    z[3,0,0]  R463      1.7708288133144379e-01
    z[3,0,0]  R464      -3.5844030976295471e-01
    z[3,0,0]  R465      -1.4807590842247009e-01
    z[3,0,0]  R466      0.0971425324678421
    z[3,0,0]  R467      4.5451264828443527e-02
    z[3,0,0]  R468      7.7890351414680481e-02
    z[3,0,0]  R469      -2.6252783834934235e-02
    z[3,0,0]  R470      1.1205359548330307e-01
    z[3,0,0]  R471      8.0074248835444450e-03
    z[3,0,0]  R472      -2.1535484492778778e-01
    z[3,0,0]  R473      -3.9488885551691055e-02
    z[3,0,0]  R474      -7.8452125191688538e-02
    z[3,0,0]  R475      7.0918244123458862e-01
    z[3,0,0]  R476      -3.8819867372512817e-01
    z[3,0,0]  R477      -1.5058794617652893e-01
    z[3,0,0]  R478      4.4029292464256287e-01
    z[3,0,0]  R479      -2.1365895867347717e-01
    z[3,0,0]  R480      -2.2509813308715820e-01
    z[3,0,0]  R481      6.6602796316146851e-01
    z[3,0,0]  R482      -1.6778011620044708e-01
    z[3,0,0]  R483      -7.2544538974761963e-01
    z[3,0,0]  R484      -4.0250718593597412e-01
    z[3,0,0]  R485      -3.7084838747978210e-01
    z[3,0,0]  R486      2.3428241908550262e-01
    z[3,0,0]  R487      -2.2190895676612854e-01
    z[3,0,0]  R488      1.9234074652194977e-01
    z[3,0,0]  R489      -0.652498722076416
    z[3,0,0]  R490      3.4856978803873062e-02
    z[3,0,0]  R491      0.348032146692276
    z[3,0,0]  R492      2.4526895582675934e-01
    z[3,0,0]  R493      -1.3026286661624908e-01
    z[3,0,0]  R494      -9.4464438734576106e-04
    z[3,0,0]  R495      8.1791661679744720e-02
    z[3,0,0]  R496      3.4186458587646484e-01
    z[3,0,0]  R497      2.3441174626350403e-01
    z[3,0,0]  R498      3.6524090170860291e-01
    z[3,0,0]  R499      5.5541205406188965e-01
    z[3,0,0]  R500      7.0683604478836060e-01
    z[3,0,0]  R501      -4.6727705001831055e-01
    z[3,0,0]  R502      -5.2773147821426392e-01
    z[3,0,0]  R503      -2.0565573871135712e-01
    z[3,0,0]  R504      2.9430902004241943e-01
    z[3,0,0]  R505      4.7490376234054565e-01
    z[3,0,0]  R506      -2.2350879013538361e-01
    z[3,0,0]  R507      4.8200567252933979e-03
    z[3,0,0]  R508      -1.8080001696944237e-02
    z[3,0,0]  R509      -1.2275114655494690e-01
    z[3,0,0]  R510      -6.5519958734512329e-01
    z[3,0,0]  R511      -6.2339651584625244e-01
    z[3,0,1]  R3        1
    z[3,0,1]  R30       -1
    z[3,0,1]  R400      -1
    z[3,0,1]  R401      1
    z[3,0,1]  R412      -4.9576304852962494e-02
    z[3,0,1]  R413      7.2479605674743652e-02
    z[3,0,1]  R414      2.3105706274509430e-01
    z[3,0,1]  R415      -2.5389257073402405e-01
    z[3,0,1]  R416      -4.3938377499580383e-01
    z[3,0,1]  R417      -3.6427742242813110e-01
    z[3,0,1]  R418      -2.4248623847961426e-01
    z[3,0,1]  R419      -4.6545240283012390e-01
    z[3,0,1]  R420      -7.4089878797531128e-01
    z[3,0,1]  R421      -7.9328811168670654e-01
    z[3,0,1]  R422      5.8730334043502808e-01
    z[3,0,1]  R423      -1.2613086402416229e-01
    z[3,0,1]  R424      6.6275602579116821e-01
    z[3,0,1]  R425      -4.1508737206459045e-01
    z[3,0,1]  R426      3.2214462757110596e-01
    z[3,0,1]  R427      -5.2270042896270752e-01
    z[3,0,1]  R428      -2.3105403780937195e-01
    z[3,0,1]  R429      6.9843542575836182e-01
    z[3,0,1]  R430      -1.9056378304958344e-01
    z[3,0,1]  R431      2.1849560737609863e-01
    z[3,0,1]  R432      1.7878186702728271e-01
    z[3,0,1]  R433      2.7323865890502930e-01
    z[3,0,1]  R434      1.0493151843547821e-01
    z[3,0,1]  R435      -3.5202798247337341e-01
    z[3,0,1]  R436      1.1936495453119278e-01
    z[3,0,1]  R437      1.4401400089263916e-01
    z[3,0,1]  R438      -1.7586109042167664e-01
    z[3,0,1]  R439      2.0621287822723389e-01
    z[3,0,1]  R440      1.2347144633531570e-01
    z[3,0,1]  R441      -1.7415875196456909e-01
    z[3,0,1]  R442      0.224227637052536
    z[3,0,1]  R443      -1.6536530852317810e-01
    z[3,0,1]  R444      2.7318241074681282e-02
    z[3,0,1]  R445      -5.0901472568511963e-01
    z[3,0,1]  R446      0.830104649066925
    z[3,0,1]  R447      -7.4446122162044048e-03
    z[3,0,1]  R448      5.8689326047897339e-01
    z[3,0,1]  R449      -1.6676047444343567e-01
    z[3,0,1]  R450      -1.4324536919593811e-01
    z[3,0,1]  R451      -1.6525343060493469e-01
    z[3,0,1]  R452      6.4252667129039764e-02
    z[3,0,1]  R453      -3.2476228475570679e-01
    z[3,0,1]  R454      -1.9919112324714661e-01
    z[3,0,1]  R455      5.5956762284040451e-02
    z[3,0,1]  R456      -4.8003333806991577e-01
    z[3,0,1]  R457      -1.9607719033956528e-02
    z[3,0,1]  R458      1.0768979787826538e-01
    z[3,0,1]  R459      1.4857201278209686e-01
    z[3,0,1]  R460      -1.0986895859241486e-01
    z[3,0,1]  R461      -3.8663852214813232e-01
    z[3,0,1]  R462      -2.2436386346817017e-01
    z[3,0,1]  R463      1.0586047172546387e-01
    z[3,0,1]  R464      8.6570112034678459e-03
    z[3,0,1]  R465      6.6662162542343140e-02
    z[3,0,1]  R466      2.4361225962638855e-01
    z[3,0,1]  R467      -1.4660495519638062e-01
    z[3,0,1]  R468      -3.5686942934989929e-01
    z[3,0,1]  R469      -4.2440363764762878e-01
    z[3,0,1]  R470      -2.1864071488380432e-01
    z[3,0,1]  R471      -0.318697065114975
    z[3,0,1]  R472      -3.0321920290589333e-02
    z[3,0,1]  R473      -7.5307391583919525e-02
    z[3,0,1]  R474      -3.1644946336746216e-01
    z[3,0,1]  R475      -1.5134041011333466e-01
    z[3,0,1]  R476      -6.8925797939300537e-01
    z[3,0,1]  R477      -4.8932152986526489e-01
    z[3,0,1]  R478      -5.0690180063247681e-01
    z[3,0,1]  R479      -4.5356574654579163e-01
    z[3,0,1]  R480      -6.5307593345642090e-01
    z[3,0,1]  R481      -3.5230189561843872e-01
    z[3,0,1]  R482      7.1265035867691040e-01
    z[3,0,1]  R483      5.2123963832855225e-01
    z[3,0,1]  R484      3.3907601237297058e-01
    z[3,0,1]  R485      7.0849084854125977e-01
    z[3,0,1]  R486      -4.3920555710792542e-01
    z[3,0,1]  R487      -3.4710294008255005e-01
    z[3,0,1]  R488      2.8536980971693993e-02
    z[3,0,1]  R489      -3.4474188089370728e-01
    z[3,0,1]  R490      -3.0235031247138977e-01
    z[3,0,1]  R491      3.3155802637338638e-02
    z[3,0,1]  R492      5.0876444578170776e-01
    z[3,0,1]  R493      -3.3810412883758545e-01
    z[3,0,1]  R494      -5.5801117420196533e-01
    z[3,0,1]  R495      -6.1173391342163086e-01
    z[3,0,1]  R496      2.6103922724723816e-01
    z[3,0,1]  R497      -4.5754346251487732e-01
    z[3,0,1]  R498      -2.2389478981494904e-01
    z[3,0,1]  R499      -1.1795723438262939e-01
    z[3,0,1]  R500      -1.2165439873933792e-01
    z[3,0,1]  R501      -5.4975450038909912e-01
    z[3,0,1]  R502      3.0264306068420410e-01
    z[3,0,1]  R503      -3.2424178719520569e-01
    z[3,0,1]  R504      -4.3738925457000732e-01
    z[3,0,1]  R505      -2.7944907546043396e-01
    z[3,0,1]  R506      3.3062603324651718e-02
    z[3,0,1]  R507      4.6390235424041748e-02
    z[3,0,1]  R508      2.0292538404464722e-01
    z[3,0,1]  R509      -8.7912291288375854e-02
    z[3,0,1]  R510      -3.1532719731330872e-01
    z[3,0,1]  R511      -3.0995562672615051e-01
    z[3,0,2]  R4        1
    z[3,0,2]  R31       -1
    z[3,0,2]  R402      -1
    z[3,0,2]  R403      1
    z[3,0,2]  R412      7.7604496479034424e-01
    z[3,0,2]  R413      6.0417407751083374e-01
    z[3,0,2]  R414      5.0335592031478882e-01
    z[3,0,2]  R415      -6.9426339864730835e-01
    z[3,0,2]  R416      -7.7314120531082153e-01
    z[3,0,2]  R417      -7.2934788465499878e-01
    z[3,0,2]  R418      -8.4491407871246338e-01
    z[3,0,2]  R419      -8.0140662193298340e-01
    z[3,0,2]  R420      2.1349819377064705e-02
    z[3,0,2]  R421      -1.2619367334991693e-03
    z[3,0,2]  R422      -2.8861820697784424e-01
    z[3,0,2]  R423      2.0243752002716064e-01
    z[3,0,2]  R424      1.3058094680309296e-01
    z[3,0,2]  R425      -4.0662899613380432e-01
    z[3,0,2]  R426      -2.4025954306125641e-01
    z[3,0,2]  R427      -4.4705423712730408e-01
    z[3,0,2]  R428      -3.4929844737052917e-01
    z[3,0,2]  R429      -2.6159957051277161e-01
    z[3,0,2]  R430      -3.8386201858520508e-01
    z[3,0,2]  R431      -1.2975965440273285e-01
    z[3,0,2]  R432      6.3734084367752075e-01
    z[3,0,2]  R433      -1.9241769611835480e-01
    z[3,0,2]  R434      -8.8255876302719116e-01
    z[3,0,2]  R435      -5.4816991090774536e-01
    z[3,0,2]  R436      -6.3943284749984741e-01
    z[3,0,2]  R437      -4.0944692492485046e-01
    z[3,0,2]  R438      -6.5266954898834229e-01
    z[3,0,2]  R439      -1.9232214987277985e-01
    z[3,0,2]  R440      -5.2635037899017334e-01
    z[3,0,2]  R441      -6.7669701576232910e-01
    z[3,0,2]  R442      -6.8888491392135620e-01
    z[3,0,2]  R443      -0.37347611784935
    z[3,0,2]  R444      -0.797686755657196
    z[3,0,2]  R445      -1.9151577353477478e-01
    z[3,0,2]  R446      -5.8459974825382233e-02
    z[3,0,2]  R447      1.5644293278455734e-02
    z[3,0,2]  R448      -3.7999540567398071e-01
    z[3,0,2]  R449      -2.8968313336372375e-01
    z[3,0,2]  R450      2.9470187425613403e-01
    z[3,0,2]  R451      -2.9661780595779419e-01
    z[3,0,2]  R452      -5.4275822639465332e-01
    z[3,0,2]  R453      -3.4621232748031616e-01
    z[3,0,2]  R454      -2.6808315515518188e-01
    z[3,0,2]  R455      -1.0409136116504669e-01
    z[3,0,2]  R456      -4.9149307608604431e-01
    z[3,0,2]  R457      -4.5655825734138489e-01
    z[3,0,2]  R458      -4.3433123826980591e-01
    z[3,0,2]  R459      -4.2819681763648987e-01
    z[3,0,2]  R460      -8.9572280645370483e-02
    z[3,0,2]  R461      -1.3207964599132538e-01
    z[3,0,2]  R462      -4.7002637386322021e-01
    z[3,0,2]  R463      -2.5709491968154907e-01
    z[3,0,2]  R464      -1.9683119654655457e-01
    z[3,0,2]  R465      -3.2945030927658081e-01
    z[3,0,2]  R466      -4.3652319908142090e-01
    z[3,0,2]  R467      -6.7894309759140015e-01
    z[3,0,2]  R468      -4.7322505712509155e-01
    z[3,0,2]  R469      -4.1342398524284363e-01
    z[3,0,2]  R470      9.5625430345535278e-02
    z[3,0,2]  R471      -1.9718685746192932e-01
    z[3,0,2]  R472      6.7125105857849121e-01
    z[3,0,2]  R473      8.3312809467315674e-01
    z[3,0,2]  R474      7.2451949119567871e-01
    z[3,0,2]  R475      -3.2872074842453003e-01
    z[3,0,2]  R476      -4.1633170843124390e-01
    z[3,0,2]  R477      -0.743471622467041
    z[3,0,2]  R478      -3.3147627115249634e-01
    z[3,0,2]  R479      -5.0266003608703613e-01
    z[3,0,2]  R480      -4.0125921368598938e-01
    z[3,0,2]  R481      -2.0253057777881622e-01
    z[3,0,2]  R482      -1.5846388041973114e-01
    z[3,0,2]  R483      -1.2504948675632477e-01
    z[3,0,2]  R484      -2.1178555488586426e-01
    z[3,0,2]  R485      -2.9686334729194641e-01
    z[3,0,2]  R486      -0.304912269115448
    z[3,0,2]  R487      -7.9474258422851562e-01
    z[3,0,2]  R488      -3.6457756161689758e-01
    z[3,0,2]  R489      -6.0136336088180542e-01
    z[3,0,2]  R490      -6.6898334026336670e-01
    z[3,0,2]  R491      -4.3192937970161438e-01
    z[3,0,2]  R492      3.6812517046928406e-01
    z[3,0,2]  R493      -5.8046752214431763e-01
    z[3,0,2]  R494      -0.46873739361763
    z[3,0,2]  R495      -4.2359763383865356e-01
    z[3,0,2]  R496      -7.3792028427124023e-01
    z[3,0,2]  R497      -0.58502197265625
    z[3,0,2]  R498      -3.7277403473854065e-01
    z[3,0,2]  R499      -5.4082602262496948e-01
    z[3,0,2]  R500      -0.410214364528656
    z[3,0,2]  R501      -3.9602348208427429e-01
    z[3,0,2]  R502      2.6167321205139160e-01
    z[3,0,2]  R503      -8.2806068658828735e-01
    z[3,0,2]  R504      -4.2722231149673462e-01
    z[3,0,2]  R505      -5.6709778308868408e-01
    z[3,0,2]  R506      3.5582524538040161e-01
    z[3,0,2]  R507      0.215763658285141
    z[3,0,2]  R508      3.0487173795700073e-01
    z[3,0,2]  R509      3.3832532167434692e-01
    z[3,0,2]  R510      3.5561352968215942e-01
    z[3,0,2]  R511      2.7809631824493408e-01
    z[3,0,3]  R5        1
    z[3,0,3]  R32       -1
    z[3,0,3]  R404      -1
    z[3,0,3]  R405      1
    z[3,0,3]  R412      4.6331736445426941e-01
    z[3,0,3]  R413      5.4184055328369141e-01
    z[3,0,3]  R414      2.7046254277229309e-01
    z[3,0,3]  R415      -2.1978422999382019e-01
    z[3,0,3]  R416      -8.0081552267074585e-02
    z[3,0,3]  R417      -1.6590537130832672e-01
    z[3,0,3]  R418      -1.3935063779354095e-01
    z[3,0,3]  R419      -2.6957049965858459e-01
    z[3,0,3]  R420      2.0872354507446289e-02
    z[3,0,3]  R421      -1.9338840246200562e-01
    z[3,0,3]  R422      4.6935191750526428e-01
    z[3,0,3]  R423      1.7970761656761169e-01
    z[3,0,3]  R424      1.6824183985590935e-02
    z[3,0,3]  R425      -5.7796674966812134e-01
    z[3,0,3]  R426      -6.2334847450256348e-01
    z[3,0,3]  R427      -1.8919529020786285e-01
    z[3,0,3]  R428      -5.4911768436431885e-01
    z[3,0,3]  R429      -1.9732019305229187e-01
    z[3,0,3]  R430      -3.9041116833686829e-01
    z[3,0,3]  R431      -5.4226309061050415e-01
    z[3,0,3]  R432      4.0418922901153564e-02
    z[3,0,3]  R433      -7.1027135848999023e-01
    z[3,0,3]  R434      -1.6832639276981354e-01
    z[3,0,3]  R435      -3.5620700567960739e-02
    z[3,0,3]  R436      -6.4964437484741211e-01
    z[3,0,3]  R437      -6.6607069969177246e-01
    z[3,0,3]  R438      -1.9485194236040115e-02
    z[3,0,3]  R439      -6.3764536380767822e-01
    z[3,0,3]  R440      -7.3052115738391876e-02
    z[3,0,3]  R441      -1.2792097032070160e-01
    z[3,0,3]  R442      -6.7898309230804443e-01
    z[3,0,3]  R443      -6.8302422761917114e-01
    z[3,0,3]  R444      -1.9481922686100006e-01
    z[3,0,3]  R445      -7.0268255472183228e-01
    z[3,0,3]  R446      -3.1143969297409058e-01
    z[3,0,3]  R447      -6.5013659000396729e-01
    z[3,0,3]  R448      -6.2126046419143677e-01
    z[3,0,3]  R449      -6.1172151565551758e-01
    z[3,0,3]  R450      -0.515038788318634
    z[3,0,3]  R451      -4.8638768494129181e-02
    z[3,0,3]  R452      -7.3414909839630127e-01
    z[3,0,3]  R453      -6.8878930807113647e-01
    z[3,0,3]  R454      -6.7565697431564331e-01
    z[3,0,3]  R455      -6.7065227031707764e-01
    z[3,0,3]  R456      -6.6765159368515015e-01
    z[3,0,3]  R457      -7.4274338781833649e-02
    z[3,0,3]  R458      -6.3615453243255615e-01
    z[3,0,3]  R459      -6.1579936742782593e-01
    z[3,0,3]  R460      -6.6821444034576416e-01
    z[3,0,3]  R461      -0.645698070526123
    z[3,0,3]  R462      -7.2707247734069824e-01
    z[3,0,3]  R463      -7.0280331373214722e-01
    z[3,0,3]  R464      -7.2421997785568237e-01
    z[3,0,3]  R465      -6.5282362699508667e-01
    z[3,0,3]  R466      -6.3655519485473633e-01
    z[3,0,3]  R467      -4.8466604202985764e-02
    z[3,0,3]  R468      7.0134699344635010e-03
    z[3,0,3]  R469      1.9812983274459839e-01
    z[3,0,3]  R470      -5.5316168069839478e-01
    z[3,0,3]  R471      -6.0439020395278931e-01
    z[3,0,3]  R472      2.0664745569229126e-01
    z[3,0,3]  R473      4.7480484843254089e-01
    z[3,0,3]  R474      4.3962135910987854e-01
    z[3,0,3]  R475      -2.5441274046897888e-01
    z[3,0,3]  R476      -2.7254417538642883e-01
    z[3,0,3]  R477      -2.8050050139427185e-01
    z[3,0,3]  R478      -4.8772194981575012e-01
    z[3,0,3]  R479      -4.4571301341056824e-01
    z[3,0,3]  R480      -3.7584298849105835e-01
    z[3,0,3]  R481      -4.0352451801300049e-01
    z[3,0,3]  R482      5.4689025878906250e-01
    z[3,0,3]  R483      3.3585020899772644e-01
    z[3,0,3]  R484      6.2764382362365723e-01
    z[3,0,3]  R485      3.7380534410476685e-01
    z[3,0,3]  R486      -3.0621209740638733e-01
    z[3,0,3]  R487      -2.4470698833465576e-01
    z[3,0,3]  R488      -6.1684083938598633e-01
    z[3,0,3]  R489      -1.7534834146499634e-01
    z[3,0,3]  R490      6.0059234499931335e-02
    z[3,0,3]  R491      -2.3793654143810272e-01
    z[3,0,3]  R492      1.5104448795318604e-01
    z[3,0,3]  R493      -3.2698428630828857e-01
    z[3,0,3]  R494      -6.1881709098815918e-01
    z[3,0,3]  R495      -1.8161654472351074e-01
    z[3,0,3]  R496      -0.421463280916214
    z[3,0,3]  R497      -3.1157109141349792e-01
    z[3,0,3]  R498      -5.0003111362457275e-01
    z[3,0,3]  R499      -0.556904673576355
    z[3,0,3]  R500      -1.4032730460166931e-01
    z[3,0,3]  R501      -1.6827519237995148e-01
    z[3,0,3]  R502      4.3971300125122070e-01
    z[3,0,3]  R503      -2.5773823261260986e-01
    z[3,0,3]  R504      4.9456138163805008e-02
    z[3,0,3]  R505      -4.9626830220222473e-01
    z[3,0,3]  R506      -0.551245391368866
    z[3,0,3]  R507      -6.5397721529006958e-01
    z[3,0,3]  R508      -5.5598431825637817e-01
    z[3,0,3]  R509      -5.1718544960021973e-01
    z[3,0,3]  R510      -5.0143682956695557e-01
    z[3,0,3]  R511      -4.1073319315910339e-01
    z[3,0,4]  R6        1
    z[3,0,4]  R33       -1
    z[3,0,4]  R406      -1
    z[3,0,4]  R407      1
    z[3,0,4]  R412      4.3865670450031757e-03
    z[3,0,4]  R413      -4.6118754148483276e-01
    z[3,0,4]  R414      1.1841346323490143e-01
    z[3,0,4]  R415      -4.7443667054176331e-01
    z[3,0,4]  R416      -1.2131082266569138e-01
    z[3,0,4]  R417      -4.9943828582763672e-01
    z[3,0,4]  R418      6.9983549416065216e-02
    z[3,0,4]  R419      -0.00828845240175724
    z[3,0,4]  R420      -1.6975876688957214e-01
    z[3,0,4]  R421      2.5520551204681396e-01
    z[3,0,4]  R422      8.3239749073982239e-02
    z[3,0,4]  R423      5.7291269302368164e-01
    z[3,0,4]  R424      0.691063642501831
    z[3,0,4]  R425      -3.2358980178833008e-01
    z[3,0,4]  R426      -2.2980056703090668e-01
    z[3,0,4]  R427      -2.0617288351058960e-01
    z[3,0,4]  R428      6.4487653970718384e-01
    z[3,0,4]  R429      -1.8258714675903320e-01
    z[3,0,4]  R430      -2.4823729693889618e-01
    z[3,0,4]  R431      -5.5757266283035278e-01
    z[3,0,4]  R432      1.7272646725177765e-01
    z[3,0,4]  R433      -4.4808611273765564e-01
    z[3,0,4]  R434      -0.305568128824234
    z[3,0,4]  R435      -7.2267204523086548e-01
    z[3,0,4]  R436      -6.1701640486717224e-02
    z[3,0,4]  R437      -2.0890070497989655e-01
    z[3,0,4]  R438      -4.6491956710815430e-01
    z[3,0,4]  R439      -5.3467798233032227e-01
    z[3,0,4]  R440      -4.5001673698425293e-01
    z[3,0,4]  R441      -5.4272848367691040e-01
    z[3,0,4]  R442      -0.089384526014328
    z[3,0,4]  R443      -5.0186169147491455e-01
    z[3,0,4]  R444      -4.6230247616767883e-01
    z[3,0,4]  R445      -2.9163831472396851e-01
    z[3,0,4]  R446      -3.0278894305229187e-01
    z[3,0,4]  R447      -6.4142870903015137e-01
    z[3,0,4]  R448      -2.3578768968582153e-01
    z[3,0,4]  R449      -3.8169345259666443e-01
    z[3,0,4]  R450      5.5134284496307373e-01
    z[3,0,4]  R451      -6.7655169963836670e-01
    z[3,0,4]  R452      -0.108512744307518
    z[3,0,4]  R453      -4.1247400641441345e-01
    z[3,0,4]  R454      -4.0192928910255432e-01
    z[3,0,4]  R455      -6.9580215215682983e-01
    z[3,0,4]  R456      -1.1318396031856537e-01
    z[3,0,4]  R457      -6.7420035600662231e-01
    z[3,0,4]  R458      -2.3520049452781677e-01
    z[3,0,4]  R459      -2.8921106457710266e-01
    z[3,0,4]  R460      -3.5419189929962158e-01
    z[3,0,4]  R461      -3.9894768595695496e-01
    z[3,0,4]  R462      -3.5633343458175659e-01
    z[3,0,4]  R463      -5.8956694602966309e-01
    z[3,0,4]  R464      -5.1626938581466675e-01
    z[3,0,4]  R465      -4.4307643175125122e-01
    z[3,0,4]  R466      -2.6427084207534790e-01
    z[3,0,4]  R467      -6.7825454473495483e-01
    z[3,0,4]  R468      -7.0003032684326172e-01
    z[3,0,4]  R469      -5.7839977741241455e-01
    z[3,0,4]  R470      4.3254518508911133e-01
    z[3,0,4]  R471      6.2546718120574951e-01
    z[3,0,4]  R472      -5.7896101474761963e-01
    z[3,0,4]  R473      1.5035691857337952e-01
    z[3,0,4]  R474      -2.7070587873458862e-01
    z[3,0,4]  R475      -4.3372547626495361e-01
    z[3,0,4]  R476      2.7717721462249756e-01
    z[3,0,4]  R477      1.5353174507617950e-01
    z[3,0,4]  R478      0.305014431476593
    z[3,0,4]  R479      4.7453922033309937e-01
    z[3,0,4]  R480      -1.6413001343607903e-02
    z[3,0,4]  R481      3.7839943170547485e-01
    z[3,0,4]  R482      1.5287660062313080e-01
    z[3,0,4]  R483      2.5118967890739441e-01
    z[3,0,4]  R484      -2.6883220672607422e-01
    z[3,0,4]  R485      -3.3918708562850952e-01
    z[3,0,4]  R486      -6.6147160530090332e-01
    z[3,0,4]  R487      -2.0417188107967377e-01
    z[3,0,4]  R488      -5.5270522832870483e-01
    z[3,0,4]  R489      -1.6242443025112152e-01
    z[3,0,4]  R490      -1.1494395136833191e-01
    z[3,0,4]  R491      0.266864150762558
    z[3,0,4]  R492      -2.5346624851226807e-01
    z[3,0,4]  R493      -6.0920345783233643e-01
    z[3,0,4]  R494      8.4399111568927765e-02
    z[3,0,4]  R495      1.6527533531188965e-01
    z[3,0,4]  R496      -2.7962797880172729e-01
    z[3,0,4]  R497      4.2009231448173523e-01
    z[3,0,4]  R498      0.295994371175766
    z[3,0,4]  R499      2.5245073437690735e-01
    z[3,0,4]  R500      -6.1801366508007050e-02
    z[3,0,4]  R501      -1.2375334650278091e-01
    z[3,0,4]  R502      -4.7407916188240051e-01
    z[3,0,4]  R503      8.1504352390766144e-02
    z[3,0,4]  R504      -4.5216631889343262e-01
    z[3,0,4]  R505      -6.6905029118061066e-02
    z[3,0,4]  R506      6.5174782276153564e-01
    z[3,0,4]  R507      7.1326738595962524e-01
    z[3,0,4]  R508      7.3842769861221313e-01
    z[3,0,4]  R509      7.4505013227462769e-01
    z[3,0,4]  R510      2.8075304627418518e-01
    z[3,0,4]  R511      2.9651144146919250e-01
    z[3,0,5]  R7        1
    z[3,0,5]  R34       -1
    z[3,0,5]  R408      -1
    z[3,0,5]  R409      1
    z[3,0,5]  R412      -1.2052126228809357e-01
    z[3,0,5]  R413      2.6374953985214233e-01
    z[3,0,5]  R414      5.2855336666107178e-01
    z[3,0,5]  R415      -1.2794802896678448e-02
    z[3,0,5]  R416      2.9707642272114754e-02
    z[3,0,5]  R417      -1.0103664547204971e-01
    z[3,0,5]  R418      -1.8102893233299255e-01
    z[3,0,5]  R419      -1.5770480036735535e-01
    z[3,0,5]  R420      -1.4267264306545258e-01
    z[3,0,5]  R421      -1.1971701681613922e-01
    z[3,0,5]  R422      -3.1781506538391113e-01
    z[3,0,5]  R423      -1.6603751480579376e-01
    z[3,0,5]  R424      -1.8935577571392059e-01
    z[3,0,5]  R425      -8.9161597192287445e-02
    z[3,0,5]  R426      0.506896436214447
    z[3,0,5]  R427      2.1081382036209106e-01
    z[3,0,5]  R428      -2.1602389216423035e-01
    z[3,0,5]  R429      1.9781798124313354e-01
    z[3,0,5]  R430      -1.3992623426020145e-02
    z[3,0,5]  R431      5.7354468107223511e-01
    z[3,0,5]  R432      2.5632017850875854e-01
    z[3,0,5]  R433      -2.4334864690899849e-02
    z[3,0,5]  R434      -1.5140607953071594e-01
    z[3,0,5]  R435      -4.8199485987424850e-02
    z[3,0,5]  R436      -8.7031446397304535e-02
    z[3,0,5]  R437      -3.0716273188591003e-01
    z[3,0,5]  R438      2.5415403768420219e-02
    z[3,0,5]  R439      4.2185807228088379e-01
    z[3,0,5]  R440      -3.4934419393539429e-01
    z[3,0,5]  R441      4.1864994168281555e-01
    z[3,0,5]  R442      -3.0094233807176352e-04
    z[3,0,5]  R443      -2.9137805104255676e-01
    z[3,0,5]  R444      -1.2672282755374908e-02
    z[3,0,5]  R445      -3.3931252360343933e-01
    z[3,0,5]  R446      3.4515149891376495e-02
    z[3,0,5]  R447      2.1613213419914246e-01
    z[3,0,5]  R448      -5.9224888682365417e-02
    z[3,0,5]  R449      -1.7145846784114838e-01
    z[3,0,5]  R450      -2.2228464484214783e-01
    z[3,0,5]  R451      -2.1431162953376770e-01
    z[3,0,5]  R452      -2.3515079915523529e-01
    z[3,0,5]  R453      -9.3471392989158630e-02
    z[3,0,5]  R454      1.8666934967041016e-01
    z[3,0,5]  R455      1.1278792470693588e-01
    z[3,0,5]  R456      2.7752861380577087e-02
    z[3,0,5]  R457      -1.7858222126960754e-01
    z[3,0,5]  R458      4.7819722443819046e-02
    z[3,0,5]  R459      -4.0153592824935913e-01
    z[3,0,5]  R460      6.4882233738899231e-02
    z[3,0,5]  R461      -2.0185214281082153e-01
    z[3,0,5]  R462      -1.3158781826496124e-01
    z[3,0,5]  R463      -1.5511341392993927e-01
    z[3,0,5]  R464      -1.7066916823387146e-01
    z[3,0,5]  R465      4.7792237997055054e-01
    z[3,0,5]  R466      0.279199481010437
    z[3,0,5]  R467      2.1251642704010010e-01
    z[3,0,5]  R468      1.4224325120449066e-01
    z[3,0,5]  R469      -4.1929554939270020e-01
    z[3,0,5]  R470      -6.6018944978713989e-01
    z[3,0,5]  R471      -3.1133770942687988e-02
    z[3,0,5]  R472      2.9928517341613770e-01
    z[3,0,5]  R473      -1.6527405381202698e-01
    z[3,0,5]  R474      2.5092652440071106e-01
    z[3,0,5]  R475      -8.0992072820663452e-02
    z[3,0,5]  R476      -2.0962081849575043e-01
    z[3,0,5]  R477      -2.1431510150432587e-01
    z[3,0,5]  R478      2.0304968953132629e-01
    z[3,0,5]  R479      2.5308430194854736e-01
    z[3,0,5]  R480      -3.9577043056488037e-01
    z[3,0,5]  R481      -2.9112765192985535e-01
    z[3,0,5]  R482      -4.1370846331119537e-02
    z[3,0,5]  R483      4.4306054711341858e-02
    z[3,0,5]  R484      -3.8293343782424927e-01
    z[3,0,5]  R485      -1.0646264255046844e-01
    z[3,0,5]  R486      2.1969746053218842e-01
    z[3,0,5]  R487      2.3867359384894371e-02
    z[3,0,5]  R488      -0.0388689860701561
    z[3,0,5]  R489      1.6128288209438324e-01
    z[3,0,5]  R490      -0.00794797670096159
    z[3,0,5]  R491      -7.1854341030120850e-01
    z[3,0,5]  R492      -4.9171975255012512e-01
    z[3,0,5]  R493      -2.2538807988166809e-01
    z[3,0,5]  R494      -1.5266773104667664e-01
    z[3,0,5]  R495      -6.1591911315917969e-01
    z[3,0,5]  R496      -9.8307415843009949e-02
    z[3,0,5]  R497      -2.7063596248626709e-01
    z[3,0,5]  R498      -4.9661588668823242e-01
    z[3,0,5]  R499      -2.4874383583664894e-02
    z[3,0,5]  R500      -4.6894603967666626e-01
    z[3,0,5]  R501      -4.6838322281837463e-01
    z[3,0,5]  R502      3.6219111084938049e-01
    z[3,0,5]  R503      -1.4578401111066341e-02
    z[3,0,5]  R504      -3.8394668698310852e-01
    z[3,0,5]  R505      1.6332481801509857e-01
    z[3,0,5]  R506      -0.304740846157074
    z[3,0,5]  R507      8.4416776895523071e-02
    z[3,0,5]  R508      -0.0711945965886116
    z[3,0,5]  R509      -8.8213659822940826e-02
    z[3,0,5]  R510      -6.8204671144485474e-02
    z[3,0,5]  R511      1.8763428926467896e-01
    z[3,0,6]  R8        1
    z[3,0,6]  R35       -1
    z[3,0,6]  R410      -1
    z[3,0,6]  R411      1
    z[3,0,6]  R412      0.401039719581604
    z[3,0,6]  R413      2.2733974456787109e-01
    z[3,0,6]  R414      5.1721811294555664e-01
    z[3,0,6]  R415      1.1918663978576660e-01
    z[3,0,6]  R416      6.0617448762059212e-03
    z[3,0,6]  R417      2.0301340520381927e-01
    z[3,0,6]  R418      3.0956250429153442e-01
    z[3,0,6]  R419      1.0420594364404678e-01
    z[3,0,6]  R420      1.3056075572967529e-01
    z[3,0,6]  R421      -1.9015483558177948e-02
    z[3,0,6]  R422      -1.3336718082427979e-01
    z[3,0,6]  R423      -1.3766746222972870e-01
    z[3,0,6]  R424      -1.5901888906955719e-01
    z[3,0,6]  R425      -4.4302663207054138e-01
    z[3,0,6]  R426      7.1227133274078369e-02
    z[3,0,6]  R427      -4.7686256468296051e-02
    z[3,0,6]  R428      2.4533452093601227e-01
    z[3,0,6]  R429      -4.3609503656625748e-02
    z[3,0,6]  R430      4.2882591485977173e-01
    z[3,0,6]  R431      -2.3034913465380669e-02
    z[3,0,6]  R432      -6.7959511280059814e-01
    z[3,0,6]  R433      0.063626728951931
    z[3,0,6]  R434      2.0914423465728760e-01
    z[3,0,6]  R435      -1.8838226795196533e-01
    z[3,0,6]  R436      -6.7836657166481018e-02
    z[3,0,6]  R437      2.5002774596214294e-01
    z[3,0,6]  R438      5.7089352607727051e-01
    z[3,0,6]  R439      1.1305678635835648e-01
    z[3,0,6]  R440      2.8510963916778564e-01
    z[3,0,6]  R441      1.2826339900493622e-01
    z[3,0,6]  R442      7.7527396380901337e-02
    z[3,0,6]  R443      -1.8467016518115997e-02
    z[3,0,6]  R444      -2.9033464193344116e-01
    z[3,0,6]  R445      -9.4842657446861267e-02
    z[3,0,6]  R446      2.4467891454696655e-01
    z[3,0,6]  R447      3.2510584592819214e-01
    z[3,0,6]  R448      -5.2937213331460953e-02
    z[3,0,6]  R449      5.7222491502761841e-01
    z[3,0,6]  R450      2.2689729928970337e-01
    z[3,0,6]  R451      1.8042099475860596e-01
    z[3,0,6]  R452      -1.2751290202140808e-01
    z[3,0,6]  R453      -3.2146766781806946e-01
    z[3,0,6]  R454      -1.2298163771629333e-01
    z[3,0,6]  R455      -9.7241960465908051e-02
    z[3,0,6]  R456      2.5140061974525452e-01
    z[3,0,6]  R457      -4.8264440149068832e-02
    z[3,0,6]  R458      -5.5036425590515137e-01
    z[3,0,6]  R459      3.6843335628509521e-01
    z[3,0,6]  R460      5.7483422756195068e-01
    z[3,0,6]  R461      2.2443674504756927e-01
    z[3,0,6]  R462      2.3426796495914459e-01
    z[3,0,6]  R463      -1.6048528254032135e-01
    z[3,0,6]  R464      1.1201063543558121e-01
    z[3,0,6]  R465      1.1910926550626755e-01
    z[3,0,6]  R466      -4.3320894241333008e-01
    z[3,0,6]  R467      8.9084036648273468e-02
    z[3,0,6]  R468      3.6374524235725403e-01
    z[3,0,6]  R469      3.1410580873489380e-01
    z[3,0,6]  R470      3.9531286805868149e-02
    z[3,0,6]  R471      3.1940481066703796e-01
    z[3,0,6]  R472      1.8615677952766418e-01
    z[3,0,6]  R473      1.5265858173370361e-01
    z[3,0,6]  R474      -1.9815099239349365e-01
    z[3,0,6]  R475      -3.2664310932159424e-01
    z[3,0,6]  R476      7.6450914144515991e-02
    z[3,0,6]  R477      -1.9223439693450928e-01
    z[3,0,6]  R478      -2.5919172167778015e-01
    z[3,0,6]  R479      -0.0897860899567604
    z[3,0,6]  R480      2.5229376554489136e-01
    z[3,0,6]  R481      -2.2316303104162216e-02
    z[3,0,6]  R482      -0.338669091463089
    z[3,0,6]  R483      9.2445842921733856e-02
    z[3,0,6]  R484      -2.5557151436805725e-01
    z[3,0,6]  R485      -7.9194277524948120e-02
    z[3,0,6]  R486      -2.8224322199821472e-01
    z[3,0,6]  R487      -3.1068131327629089e-01
    z[3,0,6]  R488      3.7654665112495422e-01
    z[3,0,6]  R489      -1.0305192321538925e-01
    z[3,0,6]  R490      -6.6554355621337891e-01
    z[3,0,6]  R491      2.1697089076042175e-01
    z[3,0,6]  R492      4.6544370055198669e-01
    z[3,0,6]  R493      5.4104685783386230e-02
    z[3,0,6]  R494      2.3567487299442291e-01
    z[3,0,6]  R495      -1.3590492926596198e-05
    z[3,0,6]  R496      -7.0521339774131775e-02
    z[3,0,6]  R497      -2.1600113809108734e-01
    z[3,0,6]  R498      3.0534991621971130e-01
    z[3,0,6]  R499      -1.0304258763790131e-01
    z[3,0,6]  R500      -0.271819144487381
    z[3,0,6]  R501      2.4407637119293213e-01
    z[3,0,6]  R502      -1.1023992300033569e-01
    z[3,0,6]  R503      -3.0594781041145325e-01
    z[3,0,6]  R504      -4.3039354681968689e-01
    z[3,0,6]  R505      -3.1199550628662109e-01
    z[3,0,6]  R506      2.8728822246193886e-02
    z[3,0,6]  R507      8.7794452905654907e-02
    z[3,0,6]  R508      -7.8005760908126831e-02
    z[3,0,6]  R509      -1.7993733286857605e-01
    z[3,0,6]  R510      -0.0995403379201889
    z[3,0,6]  R511      -0.382281631231308
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R512      -1
    z[0,4,0]  R513      1
    z[0,4,0]  R526      -2.1535484492778778e-01
    z[0,4,0]  R527      -3.9488885551691055e-02
    z[0,4,0]  R528      -7.8452125191688538e-02
    z[0,4,0]  R529      7.0918244123458862e-01
    z[0,4,0]  R530      -3.8819867372512817e-01
    z[0,4,0]  R531      -1.5058794617652893e-01
    z[0,4,0]  R532      4.4029292464256287e-01
    z[0,4,0]  R533      -2.1365895867347717e-01
    z[0,4,0]  R534      -2.2509813308715820e-01
    z[0,4,0]  R535      6.6602796316146851e-01
    z[0,4,0]  R536      -1.6778011620044708e-01
    z[0,4,0]  R537      -7.2544538974761963e-01
    z[0,4,0]  R538      -4.0250718593597412e-01
    z[0,4,0]  R539      -3.7084838747978210e-01
    z[0,4,0]  R540      2.3428241908550262e-01
    z[0,4,0]  R541      -2.2190895676612854e-01
    z[0,4,0]  R542      1.9234074652194977e-01
    z[0,4,0]  R543      -0.652498722076416
    z[0,4,0]  R544      3.4856978803873062e-02
    z[0,4,0]  R545      0.348032146692276
    z[0,4,0]  R546      2.4526895582675934e-01
    z[0,4,0]  R547      -1.3026286661624908e-01
    z[0,4,0]  R548      -9.4464438734576106e-04
    z[0,4,0]  R549      8.1791661679744720e-02
    z[0,4,0]  R550      3.4186458587646484e-01
    z[0,4,0]  R551      2.3441174626350403e-01
    z[0,4,0]  R552      3.6524090170860291e-01
    z[0,4,0]  R553      5.5541205406188965e-01
    z[0,4,0]  R554      7.0683604478836060e-01
    z[0,4,0]  R555      -4.6727705001831055e-01
    z[0,4,0]  R556      -5.2773147821426392e-01
    z[0,4,0]  R557      -2.0565573871135712e-01
    z[0,4,0]  R558      2.9430902004241943e-01
    z[0,4,0]  R559      4.7490376234054565e-01
    z[0,4,0]  R560      -2.2350879013538361e-01
    z[0,4,0]  R561      4.8200567252933979e-03
    z[0,4,0]  R562      -1.8080001696944237e-02
    z[0,4,0]  R563      -1.2275114655494690e-01
    z[0,4,0]  R564      -6.5519958734512329e-01
    z[0,4,0]  R565      -6.2339651584625244e-01
    z[0,4,0]  R566      -3.5911047458648682e-01
    z[0,4,0]  R567      -3.5800606012344360e-01
    z[0,4,0]  R568      -1.3780531287193298e-01
    z[0,4,0]  R569      -2.9238942265510559e-01
    z[0,4,0]  R570      -1.8122249841690063e-01
    z[0,4,0]  R571      -1.4514103531837463e-01
    z[0,4,0]  R572      -3.9680501818656921e-01
    z[0,4,0]  R573      -3.6523446440696716e-01
    z[0,4,0]  R574      -7.7383734285831451e-02
    z[0,4,0]  R575      -4.0516808629035950e-01
    z[0,4,0]  R576      0.942054808139801
    z[0,4,0]  R577      8.9981865882873535e-01
    z[0,4,0]  R578      5.8713823556900024e-01
    z[0,4,0]  R579      6.0660946369171143e-01
    z[0,4,0]  R580      6.0895085334777832e-01
    z[0,4,0]  R581      0.65199875831604
    z[0,4,0]  R582      5.9659922122955322e-01
    z[0,4,0]  R583      1.1463463306427002e-01
    z[0,4,0]  R584      5.4364860057830811e-01
    z[0,4,0]  R585      2.2304007411003113e-01
    z[0,4,0]  R586      -0.943132221698761
    z[0,4,0]  R587      -4.1723379492759705e-01
    z[0,4,0]  R588      3.8019508123397827e-01
    z[0,4,0]  R589      4.4824984669685364e-01
    z[0,4,0]  R590      5.2685993909835815e-01
    z[0,4,0]  R591      9.4603672623634338e-02
    z[0,4,0]  R592      -2.4945980310440063e-01
    z[0,4,0]  R593      -2.7539214491844177e-01
    z[0,4,0]  R594      1.0563543438911438e-01
    z[0,4,0]  R595      7.7304452657699585e-02
    z[0,4,0]  R596      -9.3091838061809540e-02
    z[0,4,0]  R597      -5.1429796218872070e-01
    z[0,4,0]  R598      6.5010762214660645e-01
    z[0,4,0]  R599      -1.0805778205394745e-02
    z[0,4,0]  R600      1.4774626493453979e-01
    z[0,4,0]  R601      1.1612449586391449e-01
    z[0,4,0]  R602      3.6412292718887329e-01
    z[0,4,0]  R603      5.1719751209020615e-02
    z[0,4,0]  R604      -9.9702635779976845e-03
    z[0,4,0]  R605      -5.7827834039926529e-02
    z[0,4,0]  R606      3.3384832739830017e-01
    z[0,4,0]  R607      -1.3449686765670776e-01
    z[0,4,0]  R608      -8.7584452703595161e-03
    z[0,4,0]  R609      4.8221364617347717e-01
    z[0,4,0]  R610      8.4913492202758789e-02
    z[0,4,0]  R611      -3.2118913531303406e-01
    z[0,4,0]  R612      2.1783185005187988e-01
    z[0,4,0]  R613      2.6415199041366577e-01
    z[0,4,0]  R614      1.2744180858135223e-01
    z[0,4,0]  R615      1.4033287763595581e-01
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R514      -1
    z[0,4,1]  R515      1
    z[0,4,1]  R526      -3.0321920290589333e-02
    z[0,4,1]  R527      -7.5307391583919525e-02
    z[0,4,1]  R528      -3.1644946336746216e-01
    z[0,4,1]  R529      -1.5134041011333466e-01
    z[0,4,1]  R530      -6.8925797939300537e-01
    z[0,4,1]  R531      -4.8932152986526489e-01
    z[0,4,1]  R532      -5.0690180063247681e-01
    z[0,4,1]  R533      -4.5356574654579163e-01
    z[0,4,1]  R534      -6.5307593345642090e-01
    z[0,4,1]  R535      -3.5230189561843872e-01
    z[0,4,1]  R536      7.1265035867691040e-01
    z[0,4,1]  R537      5.2123963832855225e-01
    z[0,4,1]  R538      3.3907601237297058e-01
    z[0,4,1]  R539      7.0849084854125977e-01
    z[0,4,1]  R540      -4.3920555710792542e-01
    z[0,4,1]  R541      -3.4710294008255005e-01
    z[0,4,1]  R542      2.8536980971693993e-02
    z[0,4,1]  R543      -3.4474188089370728e-01
    z[0,4,1]  R544      -3.0235031247138977e-01
    z[0,4,1]  R545      3.3155802637338638e-02
    z[0,4,1]  R546      5.0876444578170776e-01
    z[0,4,1]  R547      -3.3810412883758545e-01
    z[0,4,1]  R548      -5.5801117420196533e-01
    z[0,4,1]  R549      -6.1173391342163086e-01
    z[0,4,1]  R550      2.6103922724723816e-01
    z[0,4,1]  R551      -4.5754346251487732e-01
    z[0,4,1]  R552      -2.2389478981494904e-01
    z[0,4,1]  R553      -1.1795723438262939e-01
    z[0,4,1]  R554      -1.2165439873933792e-01
    z[0,4,1]  R555      -5.4975450038909912e-01
    z[0,4,1]  R556      3.0264306068420410e-01
    z[0,4,1]  R557      -3.2424178719520569e-01
    z[0,4,1]  R558      -4.3738925457000732e-01
    z[0,4,1]  R559      -2.7944907546043396e-01
    z[0,4,1]  R560      3.3062603324651718e-02
    z[0,4,1]  R561      4.6390235424041748e-02
    z[0,4,1]  R562      2.0292538404464722e-01
    z[0,4,1]  R563      -8.7912291288375854e-02
    z[0,4,1]  R564      -3.1532719731330872e-01
    z[0,4,1]  R565      -3.0995562672615051e-01
    z[0,4,1]  R566      3.9992593228816986e-02
    z[0,4,1]  R567      8.8066153228282928e-02
    z[0,4,1]  R568      -1.4184577763080597e-01
    z[0,4,1]  R569      1.9708101451396942e-01
    z[0,4,1]  R570      1.9181822240352631e-01
    z[0,4,1]  R571      1.7235554754734039e-01
    z[0,4,1]  R572      1.0931375622749329e-01
    z[0,4,1]  R573      0.334354430437088
    z[0,4,1]  R574      1.9728232920169830e-01
    z[0,4,1]  R575      1.5075589530169964e-02
    z[0,4,1]  R576      5.3768295794725418e-02
    z[0,4,1]  R577      2.5043004751205444e-01
    z[0,4,1]  R578      0.412627249956131
    z[0,4,1]  R579      -4.2724588513374329e-01
    z[0,4,1]  R580      -7.0076274871826172e-01
    z[0,4,1]  R581      -6.1578017473220825e-01
    z[0,4,1]  R582      -7.4422496557235718e-01
    z[0,4,1]  R583      -3.5293185710906982e-01
    z[0,4,1]  R584      -5.6348502635955811e-01
    z[0,4,1]  R585      -3.0520507693290710e-01
    z[0,4,1]  R586      2.6929962635040283e-01
    z[0,4,1]  R587      0.547633171081543
    z[0,4,1]  R588      -3.4225234389305115e-01
    z[0,4,1]  R589      -3.7711513042449951e-01
    z[0,4,1]  R590      5.0179883837699890e-02
    z[0,4,1]  R591      4.6545788645744324e-02
    z[0,4,1]  R592      -4.1894862055778503e-01
    z[0,4,1]  R593      -0.589698076248169
    z[0,4,1]  R594      -2.8642225265502930e-01
    z[0,4,1]  R595      0.365046888589859
    z[0,4,1]  R596      7.0368468761444092e-01
    z[0,4,1]  R597      6.3230073451995850e-01
    z[0,4,1]  R598      5.2852157503366470e-02
    z[0,4,1]  R599      -3.5425764322280884e-01
    z[0,4,1]  R600      -0.572669506072998
    z[0,4,1]  R601      3.5959962755441666e-02
    z[0,4,1]  R602      6.5954573452472687e-02
    z[0,4,1]  R603      -3.4190490841865540e-01
    z[0,4,1]  R604      -1.7867447435855865e-01
    z[0,4,1]  R605      -2.2493988275527954e-01
    z[0,4,1]  R606      -2.8695452213287354e-01
    z[0,4,1]  R607      -5.7241046428680420e-01
    z[0,4,1]  R608      -3.8586992025375366e-01
    z[0,4,1]  R609      -2.0042078197002411e-01
    z[0,4,1]  R610      -1.7952386289834976e-02
    z[0,4,1]  R611      -1.3532178103923798e-01
    z[0,4,1]  R612      0.408532053232193
    z[0,4,1]  R613      -0.789068877696991
    z[0,4,1]  R614      -0.81621253490448
    z[0,4,1]  R615      -7.4622911214828491e-01
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R516      -1
    z[0,4,2]  R517      1
    z[0,4,2]  R526      6.7125105857849121e-01
    z[0,4,2]  R527      8.3312809467315674e-01
    z[0,4,2]  R528      7.2451949119567871e-01
    z[0,4,2]  R529      -3.2872074842453003e-01
    z[0,4,2]  R530      -4.1633170843124390e-01
    z[0,4,2]  R531      -0.743471622467041
    z[0,4,2]  R532      -3.3147627115249634e-01
    z[0,4,2]  R533      -5.0266003608703613e-01
    z[0,4,2]  R534      -4.0125921368598938e-01
    z[0,4,2]  R535      -2.0253057777881622e-01
    z[0,4,2]  R536      -1.5846388041973114e-01
    z[0,4,2]  R537      -1.2504948675632477e-01
    z[0,4,2]  R538      -2.1178555488586426e-01
    z[0,4,2]  R539      -2.9686334729194641e-01
    z[0,4,2]  R540      -0.304912269115448
    z[0,4,2]  R541      -7.9474258422851562e-01
    z[0,4,2]  R542      -3.6457756161689758e-01
    z[0,4,2]  R543      -6.0136336088180542e-01
    z[0,4,2]  R544      -6.6898334026336670e-01
    z[0,4,2]  R545      -4.3192937970161438e-01
    z[0,4,2]  R546      3.6812517046928406e-01
    z[0,4,2]  R547      -5.8046752214431763e-01
    z[0,4,2]  R548      -0.46873739361763
    z[0,4,2]  R549      -4.2359763383865356e-01
    z[0,4,2]  R550      -7.3792028427124023e-01
    z[0,4,2]  R551      -0.58502197265625
    z[0,4,2]  R552      -3.7277403473854065e-01
    z[0,4,2]  R553      -5.4082602262496948e-01
    z[0,4,2]  R554      -0.410214364528656
    z[0,4,2]  R555      -3.9602348208427429e-01
    z[0,4,2]  R556      2.6167321205139160e-01
    z[0,4,2]  R557      -8.2806068658828735e-01
    z[0,4,2]  R558      -4.2722231149673462e-01
    z[0,4,2]  R559      -5.6709778308868408e-01
    z[0,4,2]  R560      3.5582524538040161e-01
    z[0,4,2]  R561      0.215763658285141
    z[0,4,2]  R562      3.0487173795700073e-01
    z[0,4,2]  R563      3.3832532167434692e-01
    z[0,4,2]  R564      3.5561352968215942e-01
    z[0,4,2]  R565      2.7809631824493408e-01
    z[0,4,2]  R566      7.0885759592056274e-01
    z[0,4,2]  R567      7.2918081283569336e-01
    z[0,4,2]  R568      0.774948239326477
    z[0,4,2]  R569      8.6175012588500977e-01
    z[0,4,2]  R570      -0.421764612197876
    z[0,4,2]  R571      -0.676142156124115
    z[0,4,2]  R572      4.2299043387174606e-02
    z[0,4,2]  R573      1.0496312379837036e-01
    z[0,4,2]  R574      -4.2408052086830139e-01
    z[0,4,2]  R575      4.8272809386253357e-01
    z[0,4,2]  R576      7.6136313378810883e-02
    z[0,4,2]  R577      -1.1208809167146683e-01
    z[0,4,2]  R578      -0.0673513412475586
    z[0,4,2]  R579      -3.7408652901649475e-01
    z[0,4,2]  R580      -1.6330179572105408e-01
    z[0,4,2]  R581      -7.6653786003589630e-02
    z[0,4,2]  R582      -2.0851986110210419e-01
    z[0,4,2]  R583      -5.0066363811492920e-01
    z[0,4,2]  R584      -1.8591651320457458e-01
    z[0,4,2]  R585      -5.1453369855880737e-01
    z[0,4,2]  R586      -1.3060493767261505e-01
    z[0,4,2]  R587      -8.7851323187351227e-02
    z[0,4,2]  R588      -0.742438793182373
    z[0,4,2]  R589      -4.8063719272613525e-01
    z[0,4,2]  R590      -6.5481591224670410e-01
    z[0,4,2]  R591      -3.4209641814231873e-01
    z[0,4,2]  R592      -7.1385228633880615e-01
    z[0,4,2]  R593      -6.4999693632125854e-01
    z[0,4,2]  R594      -0.809843122959137
    z[0,4,2]  R595      -6.0245621204376221e-01
    z[0,4,2]  R596      4.5894297957420349e-01
    z[0,4,2]  R597      1.1132667958736420e-01
    z[0,4,2]  R598      -6.6455513238906860e-01
    z[0,4,2]  R599      -5.2812069654464722e-01
    z[0,4,2]  R600      -5.6795650720596313e-01
    z[0,4,2]  R601      -6.9453239440917969e-01
    z[0,4,2]  R602      -0.555451512336731
    z[0,4,2]  R603      -7.9939246177673340e-01
    z[0,4,2]  R604      -6.5235203504562378e-01
    z[0,4,2]  R605      -6.0514295101165771e-01
    z[0,4,2]  R606      -7.2713285684585571e-01
    z[0,4,2]  R607      -7.5922089815139771e-01
    z[0,4,2]  R608      -5.8087509870529175e-01
    z[0,4,2]  R609      -7.8284674882888794e-01
    z[0,4,2]  R610      -7.4088609218597412e-01
    z[0,4,2]  R611      -0.635337233543396
    z[0,4,2]  R612      -3.9858633279800415e-01
    z[0,4,2]  R613      4.3616119772195816e-02
    z[0,4,2]  R614      1.5644568204879761e-01
    z[0,4,2]  R615      -9.8282612860202789e-02
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R518      -1
    z[0,4,3]  R519      1
    z[0,4,3]  R526      2.0664745569229126e-01
    z[0,4,3]  R527      4.7480484843254089e-01
    z[0,4,3]  R528      4.3962135910987854e-01
    z[0,4,3]  R529      -2.5441274046897888e-01
    z[0,4,3]  R530      -2.7254417538642883e-01
    z[0,4,3]  R531      -2.8050050139427185e-01
    z[0,4,3]  R532      -4.8772194981575012e-01
    z[0,4,3]  R533      -4.4571301341056824e-01
    z[0,4,3]  R534      -3.7584298849105835e-01
    z[0,4,3]  R535      -4.0352451801300049e-01
    z[0,4,3]  R536      5.4689025878906250e-01
    z[0,4,3]  R537      3.3585020899772644e-01
    z[0,4,3]  R538      6.2764382362365723e-01
    z[0,4,3]  R539      3.7380534410476685e-01
    z[0,4,3]  R540      -3.0621209740638733e-01
    z[0,4,3]  R541      -2.4470698833465576e-01
    z[0,4,3]  R542      -6.1684083938598633e-01
    z[0,4,3]  R543      -1.7534834146499634e-01
    z[0,4,3]  R544      6.0059234499931335e-02
    z[0,4,3]  R545      -2.3793654143810272e-01
    z[0,4,3]  R546      1.5104448795318604e-01
    z[0,4,3]  R547      -3.2698428630828857e-01
    z[0,4,3]  R548      -6.1881709098815918e-01
    z[0,4,3]  R549      -1.8161654472351074e-01
    z[0,4,3]  R550      -0.421463280916214
    z[0,4,3]  R551      -3.1157109141349792e-01
    z[0,4,3]  R552      -5.0003111362457275e-01
    z[0,4,3]  R553      -0.556904673576355
    z[0,4,3]  R554      -1.4032730460166931e-01
    z[0,4,3]  R555      -1.6827519237995148e-01
    z[0,4,3]  R556      4.3971300125122070e-01
    z[0,4,3]  R557      -2.5773823261260986e-01
    z[0,4,3]  R558      4.9456138163805008e-02
    z[0,4,3]  R559      -4.9626830220222473e-01
    z[0,4,3]  R560      -0.551245391368866
    z[0,4,3]  R561      -6.5397721529006958e-01
    z[0,4,3]  R562      -5.5598431825637817e-01
    z[0,4,3]  R563      -5.1718544960021973e-01
    z[0,4,3]  R564      -5.0143682956695557e-01
    z[0,4,3]  R565      -4.1073319315910339e-01
    z[0,4,3]  R566      1.5453018248081207e-01
    z[0,4,3]  R567      2.4318028986454010e-01
    z[0,4,3]  R568      -6.6407345235347748e-02
    z[0,4,3]  R569      3.7617892958223820e-03
    z[0,4,3]  R570      7.7589273452758789e-01
    z[0,4,3]  R571      4.9217936396598816e-01
    z[0,4,3]  R572      8.0812788009643555e-01
    z[0,4,3]  R573      9.9210254848003387e-02
    z[0,4,3]  R574      2.9624202847480774e-01
    z[0,4,3]  R575      -5.8686983585357666e-01
    z[0,4,3]  R576      2.3793120682239532e-01
    z[0,4,3]  R577      1.7997060716152191e-01
    z[0,4,3]  R578      -2.1408474445343018e-01
    z[0,4,3]  R579      -3.9325478672981262e-01
    z[0,4,3]  R580      -2.1021410822868347e-01
    z[0,4,3]  R581      -3.5917416214942932e-01
    z[0,4,3]  R582      1.9981622695922852e-02
    z[0,4,3]  R583      -5.4983055591583252e-01
    z[0,4,3]  R584      1.9537252373993397e-03
    z[0,4,3]  R585      -5.0493568181991577e-01
    z[0,4,3]  R586      2.7512183412909508e-02
    z[0,4,3]  R587      5.0766932964324951e-01
    z[0,4,3]  R588      -2.9457315802574158e-01
    z[0,4,3]  R589      -4.6839483082294464e-02
    z[0,4,3]  R590      -4.3036738038063049e-01
    z[0,4,3]  R591      -0.267819881439209
    z[0,4,3]  R592      -3.9078226685523987e-01
    z[0,4,3]  R593      -2.8767085075378418e-01
    z[0,4,3]  R594      -3.8902035355567932e-01
    z[0,4,3]  R595      -0.190802201628685
    z[0,4,3]  R596      5.1662659645080566e-01
    z[0,4,3]  R597      1.0520192235708237e-01
    z[0,4,3]  R598      -2.2982361912727356e-01
    z[0,4,3]  R599      -5.8106422424316406e-01
    z[0,4,3]  R600      -3.6560976505279541e-01
    z[0,4,3]  R601      -6.9852042198181152e-01
    z[0,4,3]  R602      -3.0261768028140068e-02
    z[0,4,3]  R603      -6.6269993782043457e-02
    z[0,4,3]  R604      -6.4941161870956421e-01
    z[0,4,3]  R605      8.2603186368942261e-02
    z[0,4,3]  R606      -2.2602368891239166e-01
    z[0,4,3]  R607      -1.2361246347427368e-01
    z[0,4,3]  R608      -5.3486543893814087e-01
    z[0,4,3]  R609      -1.1051447689533234e-01
    z[0,4,3]  R610      -6.4729940891265869e-01
    z[0,4,3]  R611      -3.4381550550460815e-01
    z[0,4,3]  R612      -3.5488963127136230e-01
    z[0,4,3]  R613      0.317862868309021
    z[0,4,3]  R614      1.6077440977096558e-01
    z[0,4,3]  R615      4.6951431035995483e-01
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R520      -1
    z[0,4,4]  R521      1
    z[0,4,4]  R526      -5.7896101474761963e-01
    z[0,4,4]  R527      1.5035691857337952e-01
    z[0,4,4]  R528      -2.7070587873458862e-01
    z[0,4,4]  R529      -4.3372547626495361e-01
    z[0,4,4]  R530      2.7717721462249756e-01
    z[0,4,4]  R531      1.5353174507617950e-01
    z[0,4,4]  R532      0.305014431476593
    z[0,4,4]  R533      4.7453922033309937e-01
    z[0,4,4]  R534      -1.6413001343607903e-02
    z[0,4,4]  R535      3.7839943170547485e-01
    z[0,4,4]  R536      1.5287660062313080e-01
    z[0,4,4]  R537      2.5118967890739441e-01
    z[0,4,4]  R538      -2.6883220672607422e-01
    z[0,4,4]  R539      -3.3918708562850952e-01
    z[0,4,4]  R540      -6.6147160530090332e-01
    z[0,4,4]  R541      -2.0417188107967377e-01
    z[0,4,4]  R542      -5.5270522832870483e-01
    z[0,4,4]  R543      -1.6242443025112152e-01
    z[0,4,4]  R544      -1.1494395136833191e-01
    z[0,4,4]  R545      0.266864150762558
    z[0,4,4]  R546      -2.5346624851226807e-01
    z[0,4,4]  R547      -6.0920345783233643e-01
    z[0,4,4]  R548      8.4399111568927765e-02
    z[0,4,4]  R549      1.6527533531188965e-01
    z[0,4,4]  R550      -2.7962797880172729e-01
    z[0,4,4]  R551      4.2009231448173523e-01
    z[0,4,4]  R552      0.295994371175766
    z[0,4,4]  R553      2.5245073437690735e-01
    z[0,4,4]  R554      -6.1801366508007050e-02
    z[0,4,4]  R555      -1.2375334650278091e-01
    z[0,4,4]  R556      -4.7407916188240051e-01
    z[0,4,4]  R557      8.1504352390766144e-02
    z[0,4,4]  R558      -4.5216631889343262e-01
    z[0,4,4]  R559      -6.6905029118061066e-02
    z[0,4,4]  R560      6.5174782276153564e-01
    z[0,4,4]  R561      7.1326738595962524e-01
    z[0,4,4]  R562      7.3842769861221313e-01
    z[0,4,4]  R563      7.4505013227462769e-01
    z[0,4,4]  R564      2.8075304627418518e-01
    z[0,4,4]  R565      2.9651144146919250e-01
    z[0,4,4]  R566      0.584718644618988
    z[0,4,4]  R567      1.1929895728826523e-01
    z[0,4,4]  R568      4.4568312168121338e-01
    z[0,4,4]  R569      -1.9457225501537323e-01
    z[0,4,4]  R570      -2.3900421336293221e-02
    z[0,4,4]  R571      -3.1577959656715393e-01
    z[0,4,4]  R572      -3.5803741216659546e-01
    z[0,4,4]  R573      6.9361424446105957e-01
    z[0,4,4]  R574      -0.651825487613678
    z[0,4,4]  R575      1.3738542795181274e-01
    z[0,4,4]  R576      -1.3454273343086243e-01
    z[0,4,4]  R577      1.5022955834865570e-01
    z[0,4,4]  R578      0.452536016702652
    z[0,4,4]  R579      3.3214700222015381e-01
    z[0,4,4]  R580      2.2784835100173950e-01
    z[0,4,4]  R581      -1.3697463274002075e-01
    z[0,4,4]  R582      1.7680658400058746e-01
    z[0,4,4]  R583      -4.9967506527900696e-01
    z[0,4,4]  R584      2.7726349234580994e-01
    z[0,4,4]  R585      -4.2929565906524658e-01
    z[0,4,4]  R586      -7.9094909131526947e-02
    z[0,4,4]  R587      8.4954008460044861e-02
    z[0,4,4]  R588      -3.1500864028930664e-01
    z[0,4,4]  R589      -4.3252453207969666e-01
    z[0,4,4]  R590      -8.6337188258767128e-03
    z[0,4,4]  R591      -6.2996000051498413e-01
    z[0,4,4]  R592      8.6528457701206207e-02
    z[0,4,4]  R593      -2.3535829782485962e-01
    z[0,4,4]  R594      2.9225587844848633e-01
    z[0,4,4]  R595      -4.7899162769317627e-01
    z[0,4,4]  R596      5.1167141646146774e-02
    z[0,4,4]  R597      2.7436983585357666e-01
    z[0,4,4]  R598      -1.1434942483901978e-01
    z[0,4,4]  R599      -4.6427333354949951e-01
    z[0,4,4]  R600      9.7543504089117050e-03
    z[0,4,4]  R601      3.3553630113601685e-02
    z[0,4,4]  R602      -4.8827984929084778e-01
    z[0,4,4]  R603      9.5876671373844147e-02
    z[0,4,4]  R604      -1.2067833542823792e-01
    z[0,4,4]  R605      -4.4259798526763916e-01
    z[0,4,4]  R606      -4.3967342376708984e-01
    z[0,4,4]  R607      -1.3392937183380127e-01
    z[0,4,4]  R608      -4.1266137361526489e-01
    z[0,4,4]  R609      2.2943212091922760e-01
    z[0,4,4]  R610      -1.1504572629928589e-01
    z[0,4,4]  R611      -3.9065372943878174e-01
    z[0,4,4]  R612      -6.8254613876342773e-01
    z[0,4,4]  R613      -3.9675071835517883e-01
    z[0,4,4]  R614      -4.9660202860832214e-01
    z[0,4,4]  R615      -3.6722466349601746e-01
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R522      -1
    z[0,4,5]  R523      1
    z[0,4,5]  R526      2.9928517341613770e-01
    z[0,4,5]  R527      -1.6527405381202698e-01
    z[0,4,5]  R528      2.5092652440071106e-01
    z[0,4,5]  R529      -8.0992072820663452e-02
    z[0,4,5]  R530      -2.0962081849575043e-01
    z[0,4,5]  R531      -2.1431510150432587e-01
    z[0,4,5]  R532      2.0304968953132629e-01
    z[0,4,5]  R533      2.5308430194854736e-01
    z[0,4,5]  R534      -3.9577043056488037e-01
    z[0,4,5]  R535      -2.9112765192985535e-01
    z[0,4,5]  R536      -4.1370846331119537e-02
    z[0,4,5]  R537      4.4306054711341858e-02
    z[0,4,5]  R538      -3.8293343782424927e-01
    z[0,4,5]  R539      -1.0646264255046844e-01
    z[0,4,5]  R540      2.1969746053218842e-01
    z[0,4,5]  R541      2.3867359384894371e-02
    z[0,4,5]  R542      -0.0388689860701561
    z[0,4,5]  R543      1.6128288209438324e-01
    z[0,4,5]  R544      -0.00794797670096159
    z[0,4,5]  R545      -7.1854341030120850e-01
    z[0,4,5]  R546      -4.9171975255012512e-01
    z[0,4,5]  R547      -2.2538807988166809e-01
    z[0,4,5]  R548      -1.5266773104667664e-01
    z[0,4,5]  R549      -6.1591911315917969e-01
    z[0,4,5]  R550      -9.8307415843009949e-02
    z[0,4,5]  R551      -2.7063596248626709e-01
    z[0,4,5]  R552      -4.9661588668823242e-01
    z[0,4,5]  R553      -2.4874383583664894e-02
    z[0,4,5]  R554      -4.6894603967666626e-01
    z[0,4,5]  R555      -4.6838322281837463e-01
    z[0,4,5]  R556      3.6219111084938049e-01
    z[0,4,5]  R557      -1.4578401111066341e-02
    z[0,4,5]  R558      -3.8394668698310852e-01
    z[0,4,5]  R559      1.6332481801509857e-01
    z[0,4,5]  R560      -0.304740846157074
    z[0,4,5]  R561      8.4416776895523071e-02
    z[0,4,5]  R562      -0.0711945965886116
    z[0,4,5]  R563      -8.8213659822940826e-02
    z[0,4,5]  R564      -6.8204671144485474e-02
    z[0,4,5]  R565      1.8763428926467896e-01
    z[0,4,5]  R566      1.1528528295457363e-02
    z[0,4,5]  R567      0.46016725897789
    z[0,4,5]  R568      3.6443573236465454e-01
    z[0,4,5]  R569      -1.1830856651067734e-01
    z[0,4,5]  R570      2.3036555945873260e-01
    z[0,4,5]  R571      2.3484787344932556e-01
    z[0,4,5]  R572      1.8928836286067963e-01
    z[0,4,5]  R573      3.3975234627723694e-01
    z[0,4,5]  R574      2.8387647867202759e-01
    z[0,4,5]  R575      -2.4164432287216187e-01
    z[0,4,5]  R576      2.3776585236191750e-02
    z[0,4,5]  R577      -2.4114778637886047e-01
    z[0,4,5]  R578      1.0148690640926361e-01
    z[0,4,5]  R579      3.1827643513679504e-02
    z[0,4,5]  R580      -1.2022651731967926e-01
    z[0,4,5]  R581      -4.6280834823846817e-02
    z[0,4,5]  R582      -3.2995335757732391e-02
    z[0,4,5]  R583      -2.3742890357971191e-01
    z[0,4,5]  R584      -2.3853017017245293e-02
    z[0,4,5]  R585      -3.4963092207908630e-01
    z[0,4,5]  R586      1.0461068153381348e-01
    z[0,4,5]  R587      -4.8696655035018921e-01
    z[0,4,5]  R588      3.3102143555879593e-02
    z[0,4,5]  R589      -3.9775168895721436e-01
    z[0,4,5]  R590      -3.0349004268646240e-01
    z[0,4,5]  R591      -6.0651499032974243e-01
    z[0,4,5]  R592      -3.0408149957656860e-01
    z[0,4,5]  R593      7.3091499507427216e-02
    z[0,4,5]  R594      5.0470467656850815e-02
    z[0,4,5]  R595      -4.5190271735191345e-01
    z[0,4,5]  R596      -6.0405898839235306e-02
    z[0,4,5]  R597      -4.4078135490417480e-01
    z[0,4,5]  R598      -2.4801802635192871e-01
    z[0,4,5]  R599      1.0184463113546371e-01
    z[0,4,5]  R600      -3.9927187561988831e-01
    z[0,4,5]  R601      4.3250724673271179e-02
    z[0,4,5]  R602      -4.8846244812011719e-01
    z[0,4,5]  R603      -4.4637325406074524e-01
    z[0,4,5]  R604      -1.9911728799343109e-01
    z[0,4,5]  R605      -5.6191688776016235e-01
    z[0,4,5]  R606      -1.7829376459121704e-01
    z[0,4,5]  R607      -1.8528230488300323e-01
    z[0,4,5]  R608      2.2916388511657715e-01
    z[0,4,5]  R609      2.1229531615972519e-02
    z[0,4,5]  R610      -2.6011077687144279e-02
    z[0,4,5]  R611      -4.5171543955802917e-01
    z[0,4,5]  R612      -1.7164134979248047e-01
    z[0,4,5]  R613      2.0519137382507324e-01
    z[0,4,5]  R614      8.1515289843082428e-02
    z[0,4,5]  R615      -2.0793452858924866e-01
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R524      -1
    z[0,4,6]  R525      1
    z[0,4,6]  R526      1.8615677952766418e-01
    z[0,4,6]  R527      1.5265858173370361e-01
    z[0,4,6]  R528      -1.9815099239349365e-01
    z[0,4,6]  R529      -3.2664310932159424e-01
    z[0,4,6]  R530      7.6450914144515991e-02
    z[0,4,6]  R531      -1.9223439693450928e-01
    z[0,4,6]  R532      -2.5919172167778015e-01
    z[0,4,6]  R533      -0.0897860899567604
    z[0,4,6]  R534      2.5229376554489136e-01
    z[0,4,6]  R535      -2.2316303104162216e-02
    z[0,4,6]  R536      -0.338669091463089
    z[0,4,6]  R537      9.2445842921733856e-02
    z[0,4,6]  R538      -2.5557151436805725e-01
    z[0,4,6]  R539      -7.9194277524948120e-02
    z[0,4,6]  R540      -2.8224322199821472e-01
    z[0,4,6]  R541      -3.1068131327629089e-01
    z[0,4,6]  R542      3.7654665112495422e-01
    z[0,4,6]  R543      -1.0305192321538925e-01
    z[0,4,6]  R544      -6.6554355621337891e-01
    z[0,4,6]  R545      2.1697089076042175e-01
    z[0,4,6]  R546      4.6544370055198669e-01
    z[0,4,6]  R547      5.4104685783386230e-02
    z[0,4,6]  R548      2.3567487299442291e-01
    z[0,4,6]  R549      -1.3590492926596198e-05
    z[0,4,6]  R550      -7.0521339774131775e-02
    z[0,4,6]  R551      -2.1600113809108734e-01
    z[0,4,6]  R552      3.0534991621971130e-01
    z[0,4,6]  R553      -1.0304258763790131e-01
    z[0,4,6]  R554      -0.271819144487381
    z[0,4,6]  R555      2.4407637119293213e-01
    z[0,4,6]  R556      -1.1023992300033569e-01
    z[0,4,6]  R557      -3.0594781041145325e-01
    z[0,4,6]  R558      -4.3039354681968689e-01
    z[0,4,6]  R559      -3.1199550628662109e-01
    z[0,4,6]  R560      2.8728822246193886e-02
    z[0,4,6]  R561      8.7794452905654907e-02
    z[0,4,6]  R562      -7.8005760908126831e-02
    z[0,4,6]  R563      -1.7993733286857605e-01
    z[0,4,6]  R564      -0.0995403379201889
    z[0,4,6]  R565      -0.382281631231308
    z[0,4,6]  R566      -3.2446052879095078e-02
    z[0,4,6]  R567      -2.1736724674701691e-01
    z[0,4,6]  R568      -1.5648598968982697e-01
    z[0,4,6]  R569      2.8492954373359680e-01
    z[0,4,6]  R570      3.1117478013038635e-01
    z[0,4,6]  R571      -3.0813741683959961e-01
    z[0,4,6]  R572      -1.0823823511600494e-01
    z[0,4,6]  R573      -3.7070021033287048e-01
    z[0,4,6]  R574      4.2664456367492676e-01
    z[0,4,6]  R575      4.2532593011856079e-01
    z[0,4,6]  R576      -1.6901694238185883e-01
    z[0,4,6]  R577      -4.4010091572999954e-02
    z[0,4,6]  R578      4.6856218576431274e-01
    z[0,4,6]  R579      2.0871374011039734e-01
    z[0,4,6]  R580      2.9726946726441383e-02
    z[0,4,6]  R581      1.9981640577316284e-01
    z[0,4,6]  R582      1.1819269508123398e-01
    z[0,4,6]  R583      -5.7206183671951294e-02
    z[0,4,6]  R584      5.2432626485824585e-01
    z[0,4,6]  R585      1.7567428946495056e-01
    z[0,4,6]  R586      5.4454866796731949e-02
    z[0,4,6]  R587      1.2733514606952667e-01
    z[0,4,6]  R588      2.4166754155885428e-04
    z[0,4,6]  R589      -2.7993968129158020e-01
    z[0,4,6]  R590      1.1713202297687531e-01
    z[0,4,6]  R591      -1.8819177150726318e-01
    z[0,4,6]  R592      -1.8090275116264820e-03
    z[0,4,6]  R593      1.0212234407663345e-01
    z[0,4,6]  R594      -1.0798142850399017e-01
    z[0,4,6]  R595      1.6660369932651520e-01
    z[0,4,6]  R596      -1.1118955910205841e-01
    z[0,4,6]  R597      2.0655590295791626e-01
    z[0,4,6]  R598      -7.4333444237709045e-02
    z[0,4,6]  R599      1.7864930629730225e-01
    z[0,4,6]  R600      -1.8564037978649139e-01
    z[0,4,6]  R601      -1.0917651653289795e-01
    z[0,4,6]  R602      2.7678442001342773e-01
    z[0,4,6]  R603      1.6901065409183502e-01
    z[0,4,6]  R604      2.5781095027923584e-01
    z[0,4,6]  R605      2.4777625501155853e-01
    z[0,4,6]  R606      -3.5946812480688095e-02
    z[0,4,6]  R607      -1.0145907104015350e-01
    z[0,4,6]  R608      6.8740755319595337e-02
    z[0,4,6]  R609      -2.2169624269008636e-01
    z[0,4,6]  R610      1.0318201780319214e-01
    z[0,4,6]  R611      2.4264785461127758e-03
    z[0,4,6]  R612      7.4183098971843719e-02
    z[0,4,6]  R613      -7.1695089340209961e-02
    z[0,4,6]  R614      1.1821021884679794e-01
    z[0,4,6]  R615      1.2351055443286896e-01
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R616      -1
    z[4,0,0]  R617      1
    z[4,0,0]  R630      -3.5911047458648682e-01
    z[4,0,0]  R631      -3.5800606012344360e-01
    z[4,0,0]  R632      -1.3780531287193298e-01
    z[4,0,0]  R633      -2.9238942265510559e-01
    z[4,0,0]  R634      -1.8122249841690063e-01
    z[4,0,0]  R635      -1.4514103531837463e-01
    z[4,0,0]  R636      -3.9680501818656921e-01
    z[4,0,0]  R637      -3.6523446440696716e-01
    z[4,0,0]  R638      -7.7383734285831451e-02
    z[4,0,0]  R639      -4.0516808629035950e-01
    z[4,0,0]  R640      0.942054808139801
    z[4,0,0]  R641      8.9981865882873535e-01
    z[4,0,0]  R642      5.8713823556900024e-01
    z[4,0,0]  R643      6.0660946369171143e-01
    z[4,0,0]  R644      6.0895085334777832e-01
    z[4,0,0]  R645      0.65199875831604
    z[4,0,0]  R646      5.9659922122955322e-01
    z[4,0,0]  R647      1.1463463306427002e-01
    z[4,0,0]  R648      5.4364860057830811e-01
    z[4,0,0]  R649      2.2304007411003113e-01
    z[4,0,0]  R650      -0.943132221698761
    z[4,0,0]  R651      -4.1723379492759705e-01
    z[4,0,0]  R652      3.8019508123397827e-01
    z[4,0,0]  R653      4.4824984669685364e-01
    z[4,0,0]  R654      5.2685993909835815e-01
    z[4,0,0]  R655      9.4603672623634338e-02
    z[4,0,0]  R656      -2.4945980310440063e-01
    z[4,0,0]  R657      -2.7539214491844177e-01
    z[4,0,0]  R658      1.0563543438911438e-01
    z[4,0,0]  R659      7.7304452657699585e-02
    z[4,0,0]  R660      -9.3091838061809540e-02
    z[4,0,0]  R661      -5.1429796218872070e-01
    z[4,0,0]  R662      6.5010762214660645e-01
    z[4,0,0]  R663      -1.0805778205394745e-02
    z[4,0,0]  R664      1.4774626493453979e-01
    z[4,0,0]  R665      1.1612449586391449e-01
    z[4,0,0]  R666      3.6412292718887329e-01
    z[4,0,0]  R667      5.1719751209020615e-02
    z[4,0,0]  R668      -9.9702635779976845e-03
    z[4,0,0]  R669      -5.7827834039926529e-02
    z[4,0,0]  R670      3.3384832739830017e-01
    z[4,0,0]  R671      -1.3449686765670776e-01
    z[4,0,0]  R672      -8.7584452703595161e-03
    z[4,0,0]  R673      4.8221364617347717e-01
    z[4,0,0]  R674      8.4913492202758789e-02
    z[4,0,0]  R675      -3.2118913531303406e-01
    z[4,0,0]  R676      2.1783185005187988e-01
    z[4,0,0]  R677      2.6415199041366577e-01
    z[4,0,0]  R678      1.2744180858135223e-01
    z[4,0,0]  R679      1.4033287763595581e-01
    z[4,0,0]  R680      -2.1535484492778778e-01
    z[4,0,0]  R681      -3.9488885551691055e-02
    z[4,0,0]  R682      -7.8452125191688538e-02
    z[4,0,0]  R683      7.0918244123458862e-01
    z[4,0,0]  R684      -3.8819867372512817e-01
    z[4,0,0]  R685      -1.5058794617652893e-01
    z[4,0,0]  R686      4.4029292464256287e-01
    z[4,0,0]  R687      -2.1365895867347717e-01
    z[4,0,0]  R688      -2.2509813308715820e-01
    z[4,0,0]  R689      6.6602796316146851e-01
    z[4,0,0]  R690      -1.6778011620044708e-01
    z[4,0,0]  R691      -7.2544538974761963e-01
    z[4,0,0]  R692      -4.0250718593597412e-01
    z[4,0,0]  R693      -3.7084838747978210e-01
    z[4,0,0]  R694      2.3428241908550262e-01
    z[4,0,0]  R695      -2.2190895676612854e-01
    z[4,0,0]  R696      1.9234074652194977e-01
    z[4,0,0]  R697      -0.652498722076416
    z[4,0,0]  R698      3.4856978803873062e-02
    z[4,0,0]  R699      0.348032146692276
    z[4,0,0]  R700      2.4526895582675934e-01
    z[4,0,0]  R701      -1.3026286661624908e-01
    z[4,0,0]  R702      -9.4464438734576106e-04
    z[4,0,0]  R703      8.1791661679744720e-02
    z[4,0,0]  R704      3.4186458587646484e-01
    z[4,0,0]  R705      2.3441174626350403e-01
    z[4,0,0]  R706      3.6524090170860291e-01
    z[4,0,0]  R707      5.5541205406188965e-01
    z[4,0,0]  R708      7.0683604478836060e-01
    z[4,0,0]  R709      -4.6727705001831055e-01
    z[4,0,0]  R710      -5.2773147821426392e-01
    z[4,0,0]  R711      -2.0565573871135712e-01
    z[4,0,0]  R712      2.9430902004241943e-01
    z[4,0,0]  R713      4.7490376234054565e-01
    z[4,0,0]  R714      -2.2350879013538361e-01
    z[4,0,0]  R715      4.8200567252933979e-03
    z[4,0,0]  R716      -1.8080001696944237e-02
    z[4,0,0]  R717      -1.2275114655494690e-01
    z[4,0,0]  R718      -6.5519958734512329e-01
    z[4,0,0]  R719      -6.2339651584625244e-01
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R618      -1
    z[4,0,1]  R619      1
    z[4,0,1]  R630      3.9992593228816986e-02
    z[4,0,1]  R631      8.8066153228282928e-02
    z[4,0,1]  R632      -1.4184577763080597e-01
    z[4,0,1]  R633      1.9708101451396942e-01
    z[4,0,1]  R634      1.9181822240352631e-01
    z[4,0,1]  R635      1.7235554754734039e-01
    z[4,0,1]  R636      1.0931375622749329e-01
    z[4,0,1]  R637      0.334354430437088
    z[4,0,1]  R638      1.9728232920169830e-01
    z[4,0,1]  R639      1.5075589530169964e-02
    z[4,0,1]  R640      5.3768295794725418e-02
    z[4,0,1]  R641      2.5043004751205444e-01
    z[4,0,1]  R642      0.412627249956131
    z[4,0,1]  R643      -4.2724588513374329e-01
    z[4,0,1]  R644      -7.0076274871826172e-01
    z[4,0,1]  R645      -6.1578017473220825e-01
    z[4,0,1]  R646      -7.4422496557235718e-01
    z[4,0,1]  R647      -3.5293185710906982e-01
    z[4,0,1]  R648      -5.6348502635955811e-01
    z[4,0,1]  R649      -3.0520507693290710e-01
    z[4,0,1]  R650      2.6929962635040283e-01
    z[4,0,1]  R651      0.547633171081543
    z[4,0,1]  R652      -3.4225234389305115e-01
    z[4,0,1]  R653      -3.7711513042449951e-01
    z[4,0,1]  R654      5.0179883837699890e-02
    z[4,0,1]  R655      4.6545788645744324e-02
    z[4,0,1]  R656      -4.1894862055778503e-01
    z[4,0,1]  R657      -0.589698076248169
    z[4,0,1]  R658      -2.8642225265502930e-01
    z[4,0,1]  R659      0.365046888589859
    z[4,0,1]  R660      7.0368468761444092e-01
    z[4,0,1]  R661      6.3230073451995850e-01
    z[4,0,1]  R662      5.2852157503366470e-02
    z[4,0,1]  R663      -3.5425764322280884e-01
    z[4,0,1]  R664      -0.572669506072998
    z[4,0,1]  R665      3.5959962755441666e-02
    z[4,0,1]  R666      6.5954573452472687e-02
    z[4,0,1]  R667      -3.4190490841865540e-01
    z[4,0,1]  R668      -1.7867447435855865e-01
    z[4,0,1]  R669      -2.2493988275527954e-01
    z[4,0,1]  R670      -2.8695452213287354e-01
    z[4,0,1]  R671      -5.7241046428680420e-01
    z[4,0,1]  R672      -3.8586992025375366e-01
    z[4,0,1]  R673      -2.0042078197002411e-01
    z[4,0,1]  R674      -1.7952386289834976e-02
    z[4,0,1]  R675      -1.3532178103923798e-01
    z[4,0,1]  R676      0.408532053232193
    z[4,0,1]  R677      -0.789068877696991
    z[4,0,1]  R678      -0.81621253490448
    z[4,0,1]  R679      -7.4622911214828491e-01
    z[4,0,1]  R680      -3.0321920290589333e-02
    z[4,0,1]  R681      -7.5307391583919525e-02
    z[4,0,1]  R682      -3.1644946336746216e-01
    z[4,0,1]  R683      -1.5134041011333466e-01
    z[4,0,1]  R684      -6.8925797939300537e-01
    z[4,0,1]  R685      -4.8932152986526489e-01
    z[4,0,1]  R686      -5.0690180063247681e-01
    z[4,0,1]  R687      -4.5356574654579163e-01
    z[4,0,1]  R688      -6.5307593345642090e-01
    z[4,0,1]  R689      -3.5230189561843872e-01
    z[4,0,1]  R690      7.1265035867691040e-01
    z[4,0,1]  R691      5.2123963832855225e-01
    z[4,0,1]  R692      3.3907601237297058e-01
    z[4,0,1]  R693      7.0849084854125977e-01
    z[4,0,1]  R694      -4.3920555710792542e-01
    z[4,0,1]  R695      -3.4710294008255005e-01
    z[4,0,1]  R696      2.8536980971693993e-02
    z[4,0,1]  R697      -3.4474188089370728e-01
    z[4,0,1]  R698      -3.0235031247138977e-01
    z[4,0,1]  R699      3.3155802637338638e-02
    z[4,0,1]  R700      5.0876444578170776e-01
    z[4,0,1]  R701      -3.3810412883758545e-01
    z[4,0,1]  R702      -5.5801117420196533e-01
    z[4,0,1]  R703      -6.1173391342163086e-01
    z[4,0,1]  R704      2.6103922724723816e-01
    z[4,0,1]  R705      -4.5754346251487732e-01
    z[4,0,1]  R706      -2.2389478981494904e-01
    z[4,0,1]  R707      -1.1795723438262939e-01
    z[4,0,1]  R708      -1.2165439873933792e-01
    z[4,0,1]  R709      -5.4975450038909912e-01
    z[4,0,1]  R710      3.0264306068420410e-01
    z[4,0,1]  R711      -3.2424178719520569e-01
    z[4,0,1]  R712      -4.3738925457000732e-01
    z[4,0,1]  R713      -2.7944907546043396e-01
    z[4,0,1]  R714      3.3062603324651718e-02
    z[4,0,1]  R715      4.6390235424041748e-02
    z[4,0,1]  R716      2.0292538404464722e-01
    z[4,0,1]  R717      -8.7912291288375854e-02
    z[4,0,1]  R718      -3.1532719731330872e-01
    z[4,0,1]  R719      -3.0995562672615051e-01
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R620      -1
    z[4,0,2]  R621      1
    z[4,0,2]  R630      7.0885759592056274e-01
    z[4,0,2]  R631      7.2918081283569336e-01
    z[4,0,2]  R632      0.774948239326477
    z[4,0,2]  R633      8.6175012588500977e-01
    z[4,0,2]  R634      -0.421764612197876
    z[4,0,2]  R635      -0.676142156124115
    z[4,0,2]  R636      4.2299043387174606e-02
    z[4,0,2]  R637      1.0496312379837036e-01
    z[4,0,2]  R638      -4.2408052086830139e-01
    z[4,0,2]  R639      4.8272809386253357e-01
    z[4,0,2]  R640      7.6136313378810883e-02
    z[4,0,2]  R641      -1.1208809167146683e-01
    z[4,0,2]  R642      -0.0673513412475586
    z[4,0,2]  R643      -3.7408652901649475e-01
    z[4,0,2]  R644      -1.6330179572105408e-01
    z[4,0,2]  R645      -7.6653786003589630e-02
    z[4,0,2]  R646      -2.0851986110210419e-01
    z[4,0,2]  R647      -5.0066363811492920e-01
    z[4,0,2]  R648      -1.8591651320457458e-01
    z[4,0,2]  R649      -5.1453369855880737e-01
    z[4,0,2]  R650      -1.3060493767261505e-01
    z[4,0,2]  R651      -8.7851323187351227e-02
    z[4,0,2]  R652      -0.742438793182373
    z[4,0,2]  R653      -4.8063719272613525e-01
    z[4,0,2]  R654      -6.5481591224670410e-01
    z[4,0,2]  R655      -3.4209641814231873e-01
    z[4,0,2]  R656      -7.1385228633880615e-01
    z[4,0,2]  R657      -6.4999693632125854e-01
    z[4,0,2]  R658      -0.809843122959137
    z[4,0,2]  R659      -6.0245621204376221e-01
    z[4,0,2]  R660      4.5894297957420349e-01
    z[4,0,2]  R661      1.1132667958736420e-01
    z[4,0,2]  R662      -6.6455513238906860e-01
    z[4,0,2]  R663      -5.2812069654464722e-01
    z[4,0,2]  R664      -5.6795650720596313e-01
    z[4,0,2]  R665      -6.9453239440917969e-01
    z[4,0,2]  R666      -0.555451512336731
    z[4,0,2]  R667      -7.9939246177673340e-01
    z[4,0,2]  R668      -6.5235203504562378e-01
    z[4,0,2]  R669      -6.0514295101165771e-01
    z[4,0,2]  R670      -7.2713285684585571e-01
    z[4,0,2]  R671      -7.5922089815139771e-01
    z[4,0,2]  R672      -5.8087509870529175e-01
    z[4,0,2]  R673      -7.8284674882888794e-01
    z[4,0,2]  R674      -7.4088609218597412e-01
    z[4,0,2]  R675      -0.635337233543396
    z[4,0,2]  R676      -3.9858633279800415e-01
    z[4,0,2]  R677      4.3616119772195816e-02
    z[4,0,2]  R678      1.5644568204879761e-01
    z[4,0,2]  R679      -9.8282612860202789e-02
    z[4,0,2]  R680      6.7125105857849121e-01
    z[4,0,2]  R681      8.3312809467315674e-01
    z[4,0,2]  R682      7.2451949119567871e-01
    z[4,0,2]  R683      -3.2872074842453003e-01
    z[4,0,2]  R684      -4.1633170843124390e-01
    z[4,0,2]  R685      -0.743471622467041
    z[4,0,2]  R686      -3.3147627115249634e-01
    z[4,0,2]  R687      -5.0266003608703613e-01
    z[4,0,2]  R688      -4.0125921368598938e-01
    z[4,0,2]  R689      -2.0253057777881622e-01
    z[4,0,2]  R690      -1.5846388041973114e-01
    z[4,0,2]  R691      -1.2504948675632477e-01
    z[4,0,2]  R692      -2.1178555488586426e-01
    z[4,0,2]  R693      -2.9686334729194641e-01
    z[4,0,2]  R694      -0.304912269115448
    z[4,0,2]  R695      -7.9474258422851562e-01
    z[4,0,2]  R696      -3.6457756161689758e-01
    z[4,0,2]  R697      -6.0136336088180542e-01
    z[4,0,2]  R698      -6.6898334026336670e-01
    z[4,0,2]  R699      -4.3192937970161438e-01
    z[4,0,2]  R700      3.6812517046928406e-01
    z[4,0,2]  R701      -5.8046752214431763e-01
    z[4,0,2]  R702      -0.46873739361763
    z[4,0,2]  R703      -4.2359763383865356e-01
    z[4,0,2]  R704      -7.3792028427124023e-01
    z[4,0,2]  R705      -0.58502197265625
    z[4,0,2]  R706      -3.7277403473854065e-01
    z[4,0,2]  R707      -5.4082602262496948e-01
    z[4,0,2]  R708      -0.410214364528656
    z[4,0,2]  R709      -3.9602348208427429e-01
    z[4,0,2]  R710      2.6167321205139160e-01
    z[4,0,2]  R711      -8.2806068658828735e-01
    z[4,0,2]  R712      -4.2722231149673462e-01
    z[4,0,2]  R713      -5.6709778308868408e-01
    z[4,0,2]  R714      3.5582524538040161e-01
    z[4,0,2]  R715      0.215763658285141
    z[4,0,2]  R716      3.0487173795700073e-01
    z[4,0,2]  R717      3.3832532167434692e-01
    z[4,0,2]  R718      3.5561352968215942e-01
    z[4,0,2]  R719      2.7809631824493408e-01
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R622      -1
    z[4,0,3]  R623      1
    z[4,0,3]  R630      1.5453018248081207e-01
    z[4,0,3]  R631      2.4318028986454010e-01
    z[4,0,3]  R632      -6.6407345235347748e-02
    z[4,0,3]  R633      3.7617892958223820e-03
    z[4,0,3]  R634      7.7589273452758789e-01
    z[4,0,3]  R635      4.9217936396598816e-01
    z[4,0,3]  R636      8.0812788009643555e-01
    z[4,0,3]  R637      9.9210254848003387e-02
    z[4,0,3]  R638      2.9624202847480774e-01
    z[4,0,3]  R639      -5.8686983585357666e-01
    z[4,0,3]  R640      2.3793120682239532e-01
    z[4,0,3]  R641      1.7997060716152191e-01
    z[4,0,3]  R642      -2.1408474445343018e-01
    z[4,0,3]  R643      -3.9325478672981262e-01
    z[4,0,3]  R644      -2.1021410822868347e-01
    z[4,0,3]  R645      -3.5917416214942932e-01
    z[4,0,3]  R646      1.9981622695922852e-02
    z[4,0,3]  R647      -5.4983055591583252e-01
    z[4,0,3]  R648      1.9537252373993397e-03
    z[4,0,3]  R649      -5.0493568181991577e-01
    z[4,0,3]  R650      2.7512183412909508e-02
    z[4,0,3]  R651      5.0766932964324951e-01
    z[4,0,3]  R652      -2.9457315802574158e-01
    z[4,0,3]  R653      -4.6839483082294464e-02
    z[4,0,3]  R654      -4.3036738038063049e-01
    z[4,0,3]  R655      -0.267819881439209
    z[4,0,3]  R656      -3.9078226685523987e-01
    z[4,0,3]  R657      -2.8767085075378418e-01
    z[4,0,3]  R658      -3.8902035355567932e-01
    z[4,0,3]  R659      -0.190802201628685
    z[4,0,3]  R660      5.1662659645080566e-01
    z[4,0,3]  R661      1.0520192235708237e-01
    z[4,0,3]  R662      -2.2982361912727356e-01
    z[4,0,3]  R663      -5.8106422424316406e-01
    z[4,0,3]  R664      -3.6560976505279541e-01
    z[4,0,3]  R665      -6.9852042198181152e-01
    z[4,0,3]  R666      -3.0261768028140068e-02
    z[4,0,3]  R667      -6.6269993782043457e-02
    z[4,0,3]  R668      -6.4941161870956421e-01
    z[4,0,3]  R669      8.2603186368942261e-02
    z[4,0,3]  R670      -2.2602368891239166e-01
    z[4,0,3]  R671      -1.2361246347427368e-01
    z[4,0,3]  R672      -5.3486543893814087e-01
    z[4,0,3]  R673      -1.1051447689533234e-01
    z[4,0,3]  R674      -6.4729940891265869e-01
    z[4,0,3]  R675      -3.4381550550460815e-01
    z[4,0,3]  R676      -3.5488963127136230e-01
    z[4,0,3]  R677      0.317862868309021
    z[4,0,3]  R678      1.6077440977096558e-01
    z[4,0,3]  R679      4.6951431035995483e-01
    z[4,0,3]  R680      2.0664745569229126e-01
    z[4,0,3]  R681      4.7480484843254089e-01
    z[4,0,3]  R682      4.3962135910987854e-01
    z[4,0,3]  R683      -2.5441274046897888e-01
    z[4,0,3]  R684      -2.7254417538642883e-01
    z[4,0,3]  R685      -2.8050050139427185e-01
    z[4,0,3]  R686      -4.8772194981575012e-01
    z[4,0,3]  R687      -4.4571301341056824e-01
    z[4,0,3]  R688      -3.7584298849105835e-01
    z[4,0,3]  R689      -4.0352451801300049e-01
    z[4,0,3]  R690      5.4689025878906250e-01
    z[4,0,3]  R691      3.3585020899772644e-01
    z[4,0,3]  R692      6.2764382362365723e-01
    z[4,0,3]  R693      3.7380534410476685e-01
    z[4,0,3]  R694      -3.0621209740638733e-01
    z[4,0,3]  R695      -2.4470698833465576e-01
    z[4,0,3]  R696      -6.1684083938598633e-01
    z[4,0,3]  R697      -1.7534834146499634e-01
    z[4,0,3]  R698      6.0059234499931335e-02
    z[4,0,3]  R699      -2.3793654143810272e-01
    z[4,0,3]  R700      1.5104448795318604e-01
    z[4,0,3]  R701      -3.2698428630828857e-01
    z[4,0,3]  R702      -6.1881709098815918e-01
    z[4,0,3]  R703      -1.8161654472351074e-01
    z[4,0,3]  R704      -0.421463280916214
    z[4,0,3]  R705      -3.1157109141349792e-01
    z[4,0,3]  R706      -5.0003111362457275e-01
    z[4,0,3]  R707      -0.556904673576355
    z[4,0,3]  R708      -1.4032730460166931e-01
    z[4,0,3]  R709      -1.6827519237995148e-01
    z[4,0,3]  R710      4.3971300125122070e-01
    z[4,0,3]  R711      -2.5773823261260986e-01
    z[4,0,3]  R712      4.9456138163805008e-02
    z[4,0,3]  R713      -4.9626830220222473e-01
    z[4,0,3]  R714      -0.551245391368866
    z[4,0,3]  R715      -6.5397721529006958e-01
    z[4,0,3]  R716      -5.5598431825637817e-01
    z[4,0,3]  R717      -5.1718544960021973e-01
    z[4,0,3]  R718      -5.0143682956695557e-01
    z[4,0,3]  R719      -4.1073319315910339e-01
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R624      -1
    z[4,0,4]  R625      1
    z[4,0,4]  R630      0.584718644618988
    z[4,0,4]  R631      1.1929895728826523e-01
    z[4,0,4]  R632      4.4568312168121338e-01
    z[4,0,4]  R633      -1.9457225501537323e-01
    z[4,0,4]  R634      -2.3900421336293221e-02
    z[4,0,4]  R635      -3.1577959656715393e-01
    z[4,0,4]  R636      -3.5803741216659546e-01
    z[4,0,4]  R637      6.9361424446105957e-01
    z[4,0,4]  R638      -0.651825487613678
    z[4,0,4]  R639      1.3738542795181274e-01
    z[4,0,4]  R640      -1.3454273343086243e-01
    z[4,0,4]  R641      1.5022955834865570e-01
    z[4,0,4]  R642      0.452536016702652
    z[4,0,4]  R643      3.3214700222015381e-01
    z[4,0,4]  R644      2.2784835100173950e-01
    z[4,0,4]  R645      -1.3697463274002075e-01
    z[4,0,4]  R646      1.7680658400058746e-01
    z[4,0,4]  R647      -4.9967506527900696e-01
    z[4,0,4]  R648      2.7726349234580994e-01
    z[4,0,4]  R649      -4.2929565906524658e-01
    z[4,0,4]  R650      -7.9094909131526947e-02
    z[4,0,4]  R651      8.4954008460044861e-02
    z[4,0,4]  R652      -3.1500864028930664e-01
    z[4,0,4]  R653      -4.3252453207969666e-01
    z[4,0,4]  R654      -8.6337188258767128e-03
    z[4,0,4]  R655      -6.2996000051498413e-01
    z[4,0,4]  R656      8.6528457701206207e-02
    z[4,0,4]  R657      -2.3535829782485962e-01
    z[4,0,4]  R658      2.9225587844848633e-01
    z[4,0,4]  R659      -4.7899162769317627e-01
    z[4,0,4]  R660      5.1167141646146774e-02
    z[4,0,4]  R661      2.7436983585357666e-01
    z[4,0,4]  R662      -1.1434942483901978e-01
    z[4,0,4]  R663      -4.6427333354949951e-01
    z[4,0,4]  R664      9.7543504089117050e-03
    z[4,0,4]  R665      3.3553630113601685e-02
    z[4,0,4]  R666      -4.8827984929084778e-01
    z[4,0,4]  R667      9.5876671373844147e-02
    z[4,0,4]  R668      -1.2067833542823792e-01
    z[4,0,4]  R669      -4.4259798526763916e-01
    z[4,0,4]  R670      -4.3967342376708984e-01
    z[4,0,4]  R671      -1.3392937183380127e-01
    z[4,0,4]  R672      -4.1266137361526489e-01
    z[4,0,4]  R673      2.2943212091922760e-01
    z[4,0,4]  R674      -1.1504572629928589e-01
    z[4,0,4]  R675      -3.9065372943878174e-01
    z[4,0,4]  R676      -6.8254613876342773e-01
    z[4,0,4]  R677      -3.9675071835517883e-01
    z[4,0,4]  R678      -4.9660202860832214e-01
    z[4,0,4]  R679      -3.6722466349601746e-01
    z[4,0,4]  R680      -5.7896101474761963e-01
    z[4,0,4]  R681      1.5035691857337952e-01
    z[4,0,4]  R682      -2.7070587873458862e-01
    z[4,0,4]  R683      -4.3372547626495361e-01
    z[4,0,4]  R684      2.7717721462249756e-01
    z[4,0,4]  R685      1.5353174507617950e-01
    z[4,0,4]  R686      0.305014431476593
    z[4,0,4]  R687      4.7453922033309937e-01
    z[4,0,4]  R688      -1.6413001343607903e-02
    z[4,0,4]  R689      3.7839943170547485e-01
    z[4,0,4]  R690      1.5287660062313080e-01
    z[4,0,4]  R691      2.5118967890739441e-01
    z[4,0,4]  R692      -2.6883220672607422e-01
    z[4,0,4]  R693      -3.3918708562850952e-01
    z[4,0,4]  R694      -6.6147160530090332e-01
    z[4,0,4]  R695      -2.0417188107967377e-01
    z[4,0,4]  R696      -5.5270522832870483e-01
    z[4,0,4]  R697      -1.6242443025112152e-01
    z[4,0,4]  R698      -1.1494395136833191e-01
    z[4,0,4]  R699      0.266864150762558
    z[4,0,4]  R700      -2.5346624851226807e-01
    z[4,0,4]  R701      -6.0920345783233643e-01
    z[4,0,4]  R702      8.4399111568927765e-02
    z[4,0,4]  R703      1.6527533531188965e-01
    z[4,0,4]  R704      -2.7962797880172729e-01
    z[4,0,4]  R705      4.2009231448173523e-01
    z[4,0,4]  R706      0.295994371175766
    z[4,0,4]  R707      2.5245073437690735e-01
    z[4,0,4]  R708      -6.1801366508007050e-02
    z[4,0,4]  R709      -1.2375334650278091e-01
    z[4,0,4]  R710      -4.7407916188240051e-01
    z[4,0,4]  R711      8.1504352390766144e-02
    z[4,0,4]  R712      -4.5216631889343262e-01
    z[4,0,4]  R713      -6.6905029118061066e-02
    z[4,0,4]  R714      6.5174782276153564e-01
    z[4,0,4]  R715      7.1326738595962524e-01
    z[4,0,4]  R716      7.3842769861221313e-01
    z[4,0,4]  R717      7.4505013227462769e-01
    z[4,0,4]  R718      2.8075304627418518e-01
    z[4,0,4]  R719      2.9651144146919250e-01
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R626      -1
    z[4,0,5]  R627      1
    z[4,0,5]  R630      1.1528528295457363e-02
    z[4,0,5]  R631      0.46016725897789
    z[4,0,5]  R632      3.6443573236465454e-01
    z[4,0,5]  R633      -1.1830856651067734e-01
    z[4,0,5]  R634      2.3036555945873260e-01
    z[4,0,5]  R635      2.3484787344932556e-01
    z[4,0,5]  R636      1.8928836286067963e-01
    z[4,0,5]  R637      3.3975234627723694e-01
    z[4,0,5]  R638      2.8387647867202759e-01
    z[4,0,5]  R639      -2.4164432287216187e-01
    z[4,0,5]  R640      2.3776585236191750e-02
    z[4,0,5]  R641      -2.4114778637886047e-01
    z[4,0,5]  R642      1.0148690640926361e-01
    z[4,0,5]  R643      3.1827643513679504e-02
    z[4,0,5]  R644      -1.2022651731967926e-01
    z[4,0,5]  R645      -4.6280834823846817e-02
    z[4,0,5]  R646      -3.2995335757732391e-02
    z[4,0,5]  R647      -2.3742890357971191e-01
    z[4,0,5]  R648      -2.3853017017245293e-02
    z[4,0,5]  R649      -3.4963092207908630e-01
    z[4,0,5]  R650      1.0461068153381348e-01
    z[4,0,5]  R651      -4.8696655035018921e-01
    z[4,0,5]  R652      3.3102143555879593e-02
    z[4,0,5]  R653      -3.9775168895721436e-01
    z[4,0,5]  R654      -3.0349004268646240e-01
    z[4,0,5]  R655      -6.0651499032974243e-01
    z[4,0,5]  R656      -3.0408149957656860e-01
    z[4,0,5]  R657      7.3091499507427216e-02
    z[4,0,5]  R658      5.0470467656850815e-02
    z[4,0,5]  R659      -4.5190271735191345e-01
    z[4,0,5]  R660      -6.0405898839235306e-02
    z[4,0,5]  R661      -4.4078135490417480e-01
    z[4,0,5]  R662      -2.4801802635192871e-01
    z[4,0,5]  R663      1.0184463113546371e-01
    z[4,0,5]  R664      -3.9927187561988831e-01
    z[4,0,5]  R665      4.3250724673271179e-02
    z[4,0,5]  R666      -4.8846244812011719e-01
    z[4,0,5]  R667      -4.4637325406074524e-01
    z[4,0,5]  R668      -1.9911728799343109e-01
    z[4,0,5]  R669      -5.6191688776016235e-01
    z[4,0,5]  R670      -1.7829376459121704e-01
    z[4,0,5]  R671      -1.8528230488300323e-01
    z[4,0,5]  R672      2.2916388511657715e-01
    z[4,0,5]  R673      2.1229531615972519e-02
    z[4,0,5]  R674      -2.6011077687144279e-02
    z[4,0,5]  R675      -4.5171543955802917e-01
    z[4,0,5]  R676      -1.7164134979248047e-01
    z[4,0,5]  R677      2.0519137382507324e-01
    z[4,0,5]  R678      8.1515289843082428e-02
    z[4,0,5]  R679      -2.0793452858924866e-01
    z[4,0,5]  R680      2.9928517341613770e-01
    z[4,0,5]  R681      -1.6527405381202698e-01
    z[4,0,5]  R682      2.5092652440071106e-01
    z[4,0,5]  R683      -8.0992072820663452e-02
    z[4,0,5]  R684      -2.0962081849575043e-01
    z[4,0,5]  R685      -2.1431510150432587e-01
    z[4,0,5]  R686      2.0304968953132629e-01
    z[4,0,5]  R687      2.5308430194854736e-01
    z[4,0,5]  R688      -3.9577043056488037e-01
    z[4,0,5]  R689      -2.9112765192985535e-01
    z[4,0,5]  R690      -4.1370846331119537e-02
    z[4,0,5]  R691      4.4306054711341858e-02
    z[4,0,5]  R692      -3.8293343782424927e-01
    z[4,0,5]  R693      -1.0646264255046844e-01
    z[4,0,5]  R694      2.1969746053218842e-01
    z[4,0,5]  R695      2.3867359384894371e-02
    z[4,0,5]  R696      -0.0388689860701561
    z[4,0,5]  R697      1.6128288209438324e-01
    z[4,0,5]  R698      -0.00794797670096159
    z[4,0,5]  R699      -7.1854341030120850e-01
    z[4,0,5]  R700      -4.9171975255012512e-01
    z[4,0,5]  R701      -2.2538807988166809e-01
    z[4,0,5]  R702      -1.5266773104667664e-01
    z[4,0,5]  R703      -6.1591911315917969e-01
    z[4,0,5]  R704      -9.8307415843009949e-02
    z[4,0,5]  R705      -2.7063596248626709e-01
    z[4,0,5]  R706      -4.9661588668823242e-01
    z[4,0,5]  R707      -2.4874383583664894e-02
    z[4,0,5]  R708      -4.6894603967666626e-01
    z[4,0,5]  R709      -4.6838322281837463e-01
    z[4,0,5]  R710      3.6219111084938049e-01
    z[4,0,5]  R711      -1.4578401111066341e-02
    z[4,0,5]  R712      -3.8394668698310852e-01
    z[4,0,5]  R713      1.6332481801509857e-01
    z[4,0,5]  R714      -0.304740846157074
    z[4,0,5]  R715      8.4416776895523071e-02
    z[4,0,5]  R716      -0.0711945965886116
    z[4,0,5]  R717      -8.8213659822940826e-02
    z[4,0,5]  R718      -6.8204671144485474e-02
    z[4,0,5]  R719      1.8763428926467896e-01
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R628      -1
    z[4,0,6]  R629      1
    z[4,0,6]  R630      -3.2446052879095078e-02
    z[4,0,6]  R631      -2.1736724674701691e-01
    z[4,0,6]  R632      -1.5648598968982697e-01
    z[4,0,6]  R633      2.8492954373359680e-01
    z[4,0,6]  R634      3.1117478013038635e-01
    z[4,0,6]  R635      -3.0813741683959961e-01
    z[4,0,6]  R636      -1.0823823511600494e-01
    z[4,0,6]  R637      -3.7070021033287048e-01
    z[4,0,6]  R638      4.2664456367492676e-01
    z[4,0,6]  R639      4.2532593011856079e-01
    z[4,0,6]  R640      -1.6901694238185883e-01
    z[4,0,6]  R641      -4.4010091572999954e-02
    z[4,0,6]  R642      4.6856218576431274e-01
    z[4,0,6]  R643      2.0871374011039734e-01
    z[4,0,6]  R644      2.9726946726441383e-02
    z[4,0,6]  R645      1.9981640577316284e-01
    z[4,0,6]  R646      1.1819269508123398e-01
    z[4,0,6]  R647      -5.7206183671951294e-02
    z[4,0,6]  R648      5.2432626485824585e-01
    z[4,0,6]  R649      1.7567428946495056e-01
    z[4,0,6]  R650      5.4454866796731949e-02
    z[4,0,6]  R651      1.2733514606952667e-01
    z[4,0,6]  R652      2.4166754155885428e-04
    z[4,0,6]  R653      -2.7993968129158020e-01
    z[4,0,6]  R654      1.1713202297687531e-01
    z[4,0,6]  R655      -1.8819177150726318e-01
    z[4,0,6]  R656      -1.8090275116264820e-03
    z[4,0,6]  R657      1.0212234407663345e-01
    z[4,0,6]  R658      -1.0798142850399017e-01
    z[4,0,6]  R659      1.6660369932651520e-01
    z[4,0,6]  R660      -1.1118955910205841e-01
    z[4,0,6]  R661      2.0655590295791626e-01
    z[4,0,6]  R662      -7.4333444237709045e-02
    z[4,0,6]  R663      1.7864930629730225e-01
    z[4,0,6]  R664      -1.8564037978649139e-01
    z[4,0,6]  R665      -1.0917651653289795e-01
    z[4,0,6]  R666      2.7678442001342773e-01
    z[4,0,6]  R667      1.6901065409183502e-01
    z[4,0,6]  R668      2.5781095027923584e-01
    z[4,0,6]  R669      2.4777625501155853e-01
    z[4,0,6]  R670      -3.5946812480688095e-02
    z[4,0,6]  R671      -1.0145907104015350e-01
    z[4,0,6]  R672      6.8740755319595337e-02
    z[4,0,6]  R673      -2.2169624269008636e-01
    z[4,0,6]  R674      1.0318201780319214e-01
    z[4,0,6]  R675      2.4264785461127758e-03
    z[4,0,6]  R676      7.4183098971843719e-02
    z[4,0,6]  R677      -7.1695089340209961e-02
    z[4,0,6]  R678      1.1821021884679794e-01
    z[4,0,6]  R679      1.2351055443286896e-01
    z[4,0,6]  R680      1.8615677952766418e-01
    z[4,0,6]  R681      1.5265858173370361e-01
    z[4,0,6]  R682      -1.9815099239349365e-01
    z[4,0,6]  R683      -3.2664310932159424e-01
    z[4,0,6]  R684      7.6450914144515991e-02
    z[4,0,6]  R685      -1.9223439693450928e-01
    z[4,0,6]  R686      -2.5919172167778015e-01
    z[4,0,6]  R687      -0.0897860899567604
    z[4,0,6]  R688      2.5229376554489136e-01
    z[4,0,6]  R689      -2.2316303104162216e-02
    z[4,0,6]  R690      -0.338669091463089
    z[4,0,6]  R691      9.2445842921733856e-02
    z[4,0,6]  R692      -2.5557151436805725e-01
    z[4,0,6]  R693      -7.9194277524948120e-02
    z[4,0,6]  R694      -2.8224322199821472e-01
    z[4,0,6]  R695      -3.1068131327629089e-01
    z[4,0,6]  R696      3.7654665112495422e-01
    z[4,0,6]  R697      -1.0305192321538925e-01
    z[4,0,6]  R698      -6.6554355621337891e-01
    z[4,0,6]  R699      2.1697089076042175e-01
    z[4,0,6]  R700      4.6544370055198669e-01
    z[4,0,6]  R701      5.4104685783386230e-02
    z[4,0,6]  R702      2.3567487299442291e-01
    z[4,0,6]  R703      -1.3590492926596198e-05
    z[4,0,6]  R704      -7.0521339774131775e-02
    z[4,0,6]  R705      -2.1600113809108734e-01
    z[4,0,6]  R706      3.0534991621971130e-01
    z[4,0,6]  R707      -1.0304258763790131e-01
    z[4,0,6]  R708      -0.271819144487381
    z[4,0,6]  R709      2.4407637119293213e-01
    z[4,0,6]  R710      -1.1023992300033569e-01
    z[4,0,6]  R711      -3.0594781041145325e-01
    z[4,0,6]  R712      -4.3039354681968689e-01
    z[4,0,6]  R713      -3.1199550628662109e-01
    z[4,0,6]  R714      2.8728822246193886e-02
    z[4,0,6]  R715      8.7794452905654907e-02
    z[4,0,6]  R716      -7.8005760908126831e-02
    z[4,0,6]  R717      -1.7993733286857605e-01
    z[4,0,6]  R718      -0.0995403379201889
    z[4,0,6]  R719      -0.382281631231308
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R774      -1
    z[1,2,0]  R775      1
    z[1,2,0]  R788      -5.4846620559692383e-01
    z[1,2,0]  R789      -5.3737568855285645e-01
    z[1,2,0]  R790      -3.4947690367698669e-01
    z[1,2,0]  R791      -3.8337504863739014e-01
    z[1,2,0]  R792      -3.3478114008903503e-01
    z[1,2,0]  R793      -2.9309570789337158e-01
    z[1,2,0]  R794      -4.8481833934783936e-01
    z[1,2,0]  R795      -5.7584816217422485e-01
    z[1,2,0]  R796      2.5187286734580994e-01
    z[1,2,0]  R797      4.6663612127304077e-02
    z[1,2,0]  R798      9.1005897521972656e-01
    z[1,2,0]  R799      1.3805174827575684e-01
    z[1,2,0]  R800      4.7126758098602295e-01
    z[1,2,0]  R801      4.3676313757896423e-01
    z[1,2,0]  R802      0.534625232219696
    z[1,2,0]  R803      7.4053883552551270e-01
    z[1,2,0]  R804      7.1643579006195068e-01
    z[1,2,0]  R805      6.3351887464523315e-01
    z[1,2,0]  R806      8.7949562072753906e-01
    z[1,2,0]  R807      7.2757941484451294e-01
    z[1,2,0]  R808      -8.9046663045883179e-01
    z[1,2,0]  R809      -7.7508997917175293e-01
    z[1,2,0]  R810      -5.2592891454696655e-01
    z[1,2,0]  R811      -7.9635888338088989e-01
    z[1,2,0]  R812      -6.9828587770462036e-01
    z[1,2,0]  R813      -6.2233519554138184e-01
    z[1,2,0]  R814      -5.0729984045028687e-01
    z[1,2,0]  R815      3.2287669181823730e-01
    z[1,2,0]  R816      2.2204083204269409e-01
    z[1,2,0]  R817      4.0584060549736023e-01
    z[1,2,0]  R818      -4.2859551310539246e-01
    z[1,2,0]  R819      -5.0588089227676392e-01
    z[1,2,0]  R820      -6.6504962742328644e-02
    z[1,2,0]  R821      9.3613542616367340e-02
    z[1,2,0]  R822      1.6056878864765167e-01
    z[1,2,0]  R823      1.9732825458049774e-01
    z[1,2,0]  R824      5.2592545747756958e-01
    z[1,2,0]  R825      3.2273855805397034e-01
    z[1,2,0]  R826      0.145841583609581
    z[1,2,0]  R827      1.4634659886360168e-01
    z[1,2,0]  R828      -4.9644985795021057e-01
    z[1,2,0]  R829      -5.6475734710693359e-01
    z[1,2,0]  R830      -4.7109922766685486e-01
    z[1,2,0]  R831      5.1703029870986938e-01
    z[1,2,0]  R832      4.9828074872493744e-02
    z[1,2,0]  R833      -6.4766839146614075e-02
    z[1,2,0]  R834      3.1029042601585388e-01
    z[1,2,0]  R835      2.6755779981613159e-01
    z[1,2,0]  R836      4.5220926403999329e-01
    z[1,2,0]  R837      7.0565128326416016e-01
    z[1,2,0]  R838      -7.2389864921569824e-01
    z[1,2,0]  R839      4.7058889269828796e-01
    z[1,2,0]  R840      3.2659158110618591e-01
    z[1,2,0]  R841      2.9244866967201233e-01
    z[1,2,0]  R842      1.8340951204299927e-01
    z[1,2,0]  R843      1.1921054124832153e-01
    z[1,2,0]  R844      4.4222906231880188e-01
    z[1,2,0]  R845      4.4989496469497681e-01
    z[1,2,0]  R846      0.354343980550766
    z[1,2,0]  R847      4.8459321260452271e-01
    z[1,2,0]  R848      4.8943213187158108e-04
    z[1,2,0]  R849      -4.1603740304708481e-02
    z[1,2,0]  R850      5.1707643270492554e-01
    z[1,2,0]  R851      -1.4327304065227509e-01
    z[1,2,0]  R852      2.5914323329925537e-01
    z[1,2,0]  R853      -2.7291810512542725e-01
    z[1,2,0]  R854      0.0910104289650917
    z[1,2,0]  R855      -2.3256616294384003e-01
    z[1,2,0]  R856      7.7293801307678223e-01
    z[1,2,0]  R857      2.8755825757980347e-01
    z[1,2,0]  R858      -2.6728084683418274e-01
    z[1,2,0]  R859      -4.1889202594757080e-01
    z[1,2,0]  R860      -5.4728162288665771e-01
    z[1,2,0]  R861      -3.1786096096038818e-01
    z[1,2,0]  R862      -2.7575197815895081e-01
    z[1,2,0]  R863      -1.1141210794448853e-01
    z[1,2,0]  R864      -1.1405264586210251e-01
    z[1,2,0]  R865      6.0256361961364746e-01
    z[1,2,0]  R866      -3.8535487651824951e-01
    z[1,2,0]  R867      1.9974620640277863e-01
    z[1,2,0]  R868      -4.6212542057037354e-01
    z[1,2,0]  R869      4.2640066146850586e-01
    z[1,2,0]  R870      -8.5050441324710846e-02
    z[1,2,0]  R871      3.2335484027862549e-01
    z[1,2,0]  R872      4.4760033488273621e-01
    z[1,2,0]  R873      7.1173951029777527e-02
    z[1,2,0]  R874      1.7132215201854706e-01
    z[1,2,0]  R875      2.4897687137126923e-01
    z[1,2,0]  R876      -4.1180300712585449e-01
    z[1,2,0]  R877      -5.4998654872179031e-02
    z[1,2,0]  R878      -8.2180071622133255e-03
    z[1,2,0]  R879      -8.3000110462307930e-03
    z[1,2,0]  R880      -4.5677873492240906e-01
    z[1,2,0]  R881      -3.5773512721061707e-01
    z[1,2,0]  R882      -1.5139569342136383e-01
    z[1,2,0]  R883      1.9323521852493286e-01
    z[1,2,0]  R884      2.3085275292396545e-01
    z[1,2,0]  R885      2.4176497757434845e-01
    z[1,2,0]  R886      -2.2811214625835419e-01
    z[1,2,0]  R887      -4.9839547276496887e-01
    z[1,2,0]  R888      -3.8368764519691467e-01
    z[1,2,0]  R889      1.6560640186071396e-02
    z[1,2,0]  R890      -0.744409441947937
    z[1,2,0]  R891      1.3075286149978638e-01
    z[1,2,0]  R892      4.6359366178512573e-01
    z[1,2,0]  R893      -5.2053827047348022e-01
    z[1,2,0]  R894      -8.0672997236251831e-01
    z[1,2,0]  R895      8.6004018783569336e-02
    z[1,2,0]  R896      8.1646546721458435e-02
    z[1,2,0]  R897      -4.4128152728080750e-01
    z[1,2,0]  R898      -7.7038669586181641e-01
    z[1,2,0]  R899      7.9201817512512207e-02
    z[1,2,0]  R900      -4.1911327838897705e-01
    z[1,2,0]  R901      3.4808114171028137e-02
    z[1,2,0]  R902      -2.0323015749454498e-01
    z[1,2,0]  R903      1.3780252635478973e-01
    z[1,2,0]  R904      1.7994193732738495e-01
    z[1,2,0]  R905      6.8335193395614624e-01
    z[1,2,0]  R906      6.8507421016693115e-01
    z[1,2,0]  R907      6.7109113931655884e-01
    z[1,2,0]  R908      -8.6218303442001343e-01
    z[1,2,0]  R909      -0.7164306640625
    z[1,2,0]  R910      5.2741557359695435e-02
    z[1,2,0]  R911      -1.5142881870269775e-01
    z[1,2,0]  R912      2.1789434552192688e-01
    z[1,2,0]  R913      2.3207060992717743e-01
    z[1,2,0]  R914      2.4701507389545441e-01
    z[1,2,0]  R915      4.1877689957618713e-01
    z[1,2,0]  R916      2.0265518128871918e-01
    z[1,2,0]  R917      6.7721772193908691e-01
    z[1,2,0]  R918      -6.6606831550598145e-01
    z[1,2,0]  R919      2.2552803158760071e-01
    z[1,2,0]  R920      -1.7429448664188385e-01
    z[1,2,0]  R921      4.7464754432439804e-02
    z[1,2,0]  R922      2.4472886323928833e-01
    z[1,2,0]  R923      1.1265747249126434e-01
    z[1,2,0]  R924      -4.1515317559242249e-01
    z[1,2,0]  R925      4.6510735154151917e-01
    z[1,2,0]  R926      4.1333022713661194e-01
    z[1,2,0]  R927      2.1875010430812836e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R776      -1
    z[1,2,1]  R777      1
    z[1,2,1]  R788      3.8442826271057129e-01
    z[1,2,1]  R789      -2.6387885212898254e-01
    z[1,2,1]  R790      3.1713566184043884e-01
    z[1,2,1]  R791      -6.0303714126348495e-03
    z[1,2,1]  R792      2.7103728055953979e-01
    z[1,2,1]  R793      1.1794888228178024e-01
    z[1,2,1]  R794      1.6418954730033875e-01
    z[1,2,1]  R795      4.1713860630989075e-01
    z[1,2,1]  R796      -6.7177355289459229e-01
    z[1,2,1]  R797      -6.6847103834152222e-01
    z[1,2,1]  R798      2.9807296395301819e-01
    z[1,2,1]  R799      2.4385875463485718e-01
    z[1,2,1]  R800      -3.8807126879692078e-01
    z[1,2,1]  R801      3.3396932482719421e-01
    z[1,2,1]  R802      3.5263964533805847e-01
    z[1,2,1]  R803      2.4720968306064606e-01
    z[1,2,1]  R804      -3.7510228157043457e-01
    z[1,2,1]  R805      -5.7581549882888794e-01
    z[1,2,1]  R806      1.4785762131214142e-01
    z[1,2,1]  R807      -3.0817532539367676e-01
    z[1,2,1]  R808      -2.1939820051193237e-01
    z[1,2,1]  R809      1.9416160881519318e-01
    z[1,2,1]  R810      4.9348825216293335e-01
    z[1,2,1]  R811      -1.4357546344399452e-02
    z[1,2,1]  R812      -7.9884245991706848e-02
    z[1,2,1]  R813      1.5804682672023773e-01
    z[1,2,1]  R814      1.9286023080348969e-01
    z[1,2,1]  R815      6.6589933633804321e-01
    z[1,2,1]  R816      -4.4424888491630554e-01
    z[1,2,1]  R817      -4.4897049665451050e-02
    z[1,2,1]  R818      4.5701089501380920e-01
    z[1,2,1]  R819      6.6072843968868256e-02
    z[1,2,1]  R820      -6.2168675661087036e-01
    z[1,2,1]  R821      -7.2063046693801880e-01
    z[1,2,1]  R822      -1.4998872578144073e-01
    z[1,2,1]  R823      -2.9883316159248352e-01
    z[1,2,1]  R824      -4.1531211137771606e-01
    z[1,2,1]  R825      -3.4737905859947205e-01
    z[1,2,1]  R826      -2.5700709223747253e-01
    z[1,2,1]  R827      0.885625422000885
    z[1,2,1]  R828      5.2399653196334839e-01
    z[1,2,1]  R829      6.6193324327468872e-01
    z[1,2,1]  R830      2.1502195298671722e-01
    z[1,2,1]  R831      -3.4582906961441040e-01
    z[1,2,1]  R832      -0.293354332447052
    z[1,2,1]  R833      -5.0657910108566284e-01
    z[1,2,1]  R834      -5.3950250148773193e-01
    z[1,2,1]  R835      -1.9510462880134583e-01
    z[1,2,1]  R836      -3.7244316935539246e-01
    z[1,2,1]  R837      -1.6403743624687195e-01
    z[1,2,1]  R838      -3.8011498749256134e-02
    z[1,2,1]  R839      -2.4596635997295380e-01
    z[1,2,1]  R840      -8.6322838068008423e-01
    z[1,2,1]  R841      -9.1503816843032837e-01
    z[1,2,1]  R842      -9.3509048223495483e-01
    z[1,2,1]  R843      -8.8453543186187744e-01
    z[1,2,1]  R844      -7.9997146129608154e-01
    z[1,2,1]  R845      -7.4838405847549438e-01
    z[1,2,1]  R846      -0.752017617225647
    z[1,2,1]  R847      -7.7209919691085815e-01
    z[1,2,1]  R848      -1.7235042154788971e-01
    z[1,2,1]  R849      -1.4341805875301361e-01
    z[1,2,1]  R850      -4.5372587442398071e-01
    z[1,2,1]  R851      -7.9453641176223755e-01
    z[1,2,1]  R852      -7.8642803430557251e-01
    z[1,2,1]  R853      -6.6147613525390625e-01
    z[1,2,1]  R854      -3.4755858778953552e-01
    z[1,2,1]  R855      -7.4693953990936279e-01
    z[1,2,1]  R856      -4.9149137735366821e-01
    z[1,2,1]  R857      -9.4544291496276855e-01
    z[1,2,1]  R858      6.6605281829833984e-01
    z[1,2,1]  R859      -1.5432612597942352e-01
    z[1,2,1]  R860      3.9257392287254333e-01
    z[1,2,1]  R861      0.361191064119339
    z[1,2,1]  R862      -5.7884609699249268e-01
    z[1,2,1]  R863      -3.0517965555191040e-01
    z[1,2,1]  R864      7.2201509028673172e-03
    z[1,2,1]  R865      -2.5021719932556152e-01
    z[1,2,1]  R866      -3.3093348145484924e-01
    z[1,2,1]  R867      -5.2963387966156006e-01
    z[1,2,1]  R868      -4.6676069498062134e-01
    z[1,2,1]  R869      -4.0153455734252930e-01
    z[1,2,1]  R870      -8.6335390806198120e-01
    z[1,2,1]  R871      -7.5709640979766846e-01
    z[1,2,1]  R872      -0.536909818649292
    z[1,2,1]  R873      -3.9367112517356873e-01
    z[1,2,1]  R874      -6.8513208627700806e-01
    z[1,2,1]  R875      -5.6272447109222412e-01
    z[1,2,1]  R876      1.3906291127204895e-01
    z[1,2,1]  R877      -8.3963996171951294e-01
    z[1,2,1]  R878      -3.7191800773143768e-02
    z[1,2,1]  R879      8.4010317921638489e-02
    z[1,2,1]  R880      -4.7721635550260544e-02
    z[1,2,1]  R881      -4.1309773921966553e-01
    z[1,2,1]  R882      6.1856579780578613e-01
    z[1,2,1]  R883      -0.745434045791626
    z[1,2,1]  R884      -1.3233341276645660e-01
    z[1,2,1]  R885      -7.6522946357727051e-01
    z[1,2,1]  R886      -2.7406048774719238e-01
    z[1,2,1]  R887      -0.157062828540802
    z[1,2,1]  R888      4.5490020513534546e-01
    z[1,2,1]  R889      0.120367631316185
    z[1,2,1]  R890      -2.3461724817752838e-01
    z[1,2,1]  R891      -5.3307074308395386e-01
    z[1,2,1]  R892      -4.9710500240325928e-01
    z[1,2,1]  R893      2.9275098443031311e-01
    z[1,2,1]  R894      3.2075801491737366e-01
    z[1,2,1]  R895      -6.2702691555023193e-01
    z[1,2,1]  R896      -2.8525643050670624e-02
    z[1,2,1]  R897      -3.5387694835662842e-01
    z[1,2,1]  R898      -2.1547524631023407e-01
    z[1,2,1]  R899      -3.0064329504966736e-01
    z[1,2,1]  R900      -4.3781730532646179e-01
    z[1,2,1]  R901      -4.3824225664138794e-01
    z[1,2,1]  R902      -4.5453169941902161e-01
    z[1,2,1]  R903      -1.2614880502223969e-01
    z[1,2,1]  R904      9.5038950443267822e-02
    z[1,2,1]  R905      1.1190351843833923e-01
    z[1,2,1]  R906      -4.8688662052154541e-01
    z[1,2,1]  R907      -4.1617318987846375e-01
    z[1,2,1]  R908      -2.1365673840045929e-01
    z[1,2,1]  R909      4.6142336726188660e-01
    z[1,2,1]  R910      -3.1917089223861694e-01
    z[1,2,1]  R911      -5.1795506477355957e-01
    z[1,2,1]  R912      -2.7693209052085876e-01
    z[1,2,1]  R913      -0.516141951084137
    z[1,2,1]  R914      -8.5702389478683472e-01
    z[1,2,1]  R915      -7.4201732873916626e-01
    z[1,2,1]  R916      6.8862313032150269e-01
    z[1,2,1]  R917      5.7169044017791748e-01
    z[1,2,1]  R918      -3.4451025724411011e-01
    z[1,2,1]  R919      -2.4015264213085175e-01
    z[1,2,1]  R920      -0.594580352306366
    z[1,2,1]  R921      -6.5241134166717529e-01
    z[1,2,1]  R922      -2.0614735782146454e-01
    z[1,2,1]  R923      -0.346598744392395
    z[1,2,1]  R924      1.3930635154247284e-01
    z[1,2,1]  R925      6.6393280029296875e-01
    z[1,2,1]  R926      4.4265350699424744e-01
    z[1,2,1]  R927      0.444812536239624
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R778      -1
    z[1,2,2]  R779      1
    z[1,2,2]  R788      4.0556451678276062e-01
    z[1,2,2]  R789      5.7136386632919312e-01
    z[1,2,2]  R790      6.8847596645355225e-01
    z[1,2,2]  R791      2.0886674523353577e-01
    z[1,2,2]  R792      -1.5248348005115986e-02
    z[1,2,2]  R793      5.3124696016311646e-01
    z[1,2,2]  R794      -2.1343810856342316e-01
    z[1,2,2]  R795      -2.7728474140167236e-01
    z[1,2,2]  R796      -1.0162437707185745e-01
    z[1,2,2]  R797      -2.3174107074737549e-01
    z[1,2,2]  R798      -1.1740779131650925e-01
    z[1,2,2]  R799      -6.8835496902465820e-01
    z[1,2,2]  R800      5.9588211774826050e-01
    z[1,2,2]  R801      -6.0378080606460571e-01
    z[1,2,2]  R802      -3.1660494208335876e-01
    z[1,2,2]  R803      -4.0137115865945816e-02
    z[1,2,2]  R804      2.5910025835037231e-01
    z[1,2,2]  R805      4.1383656859397888e-01
    z[1,2,2]  R806      -2.9499918222427368e-01
    z[1,2,2]  R807      3.6738941073417664e-01
    z[1,2,2]  R808      -1.9834670424461365e-01
    z[1,2,2]  R809      -3.6132711917161942e-02
    z[1,2,2]  R810      2.9677665233612061e-01
    z[1,2,2]  R811      2.6175066828727722e-01
    z[1,2,2]  R812      -1.4722524583339691e-01
    z[1,2,2]  R813      -2.3189820349216461e-01
    z[1,2,2]  R814      -7.4641996622085571e-01
    z[1,2,2]  R815      -5.8503359556198120e-01
    z[1,2,2]  R816      -1.5049757063388824e-01
    z[1,2,2]  R817      4.7004982829093933e-02
    z[1,2,2]  R818      -4.8428988456726074e-01
    z[1,2,2]  R819      -2.0427714288234711e-01
    z[1,2,2]  R820      1.7326584085822105e-02
    z[1,2,2]  R821      -2.0517694950103760e-01
    z[1,2,2]  R822      -6.6344380378723145e-02
    z[1,2,2]  R823      1.9156554341316223e-01
    z[1,2,2]  R824      0.0657258853316307
    z[1,2,2]  R825      -4.1535636410117149e-03
    z[1,2,2]  R826      -2.2964255511760712e-01
    z[1,2,2]  R827      -1.2464547902345657e-01
    z[1,2,2]  R828      -5.8535808324813843e-01
    z[1,2,2]  R829      -2.8683599829673767e-01
    z[1,2,2]  R830      -4.8880372196435928e-02
    z[1,2,2]  R831      -2.0156674087047577e-01
    z[1,2,2]  R832      -2.2471249103546143e-01
    z[1,2,2]  R833      -3.3468988537788391e-01
    z[1,2,2]  R834      1.8343251943588257e-01
    z[1,2,2]  R835      -2.5035008788108826e-01
    z[1,2,2]  R836      2.0671902596950531e-01
    z[1,2,2]  R837      -0.0722411647439003
    z[1,2,2]  R838      -5.3254854679107666e-01
    z[1,2,2]  R839      -1.6451023519039154e-01
    z[1,2,2]  R840      1.6175574064254761e-01
    z[1,2,2]  R841      0.000609697075560689
    z[1,2,2]  R842      -5.0387654453516006e-02
    z[1,2,2]  R843      2.9645591974258423e-01
    z[1,2,2]  R844      -3.1568646430969238e-01
    z[1,2,2]  R845      3.7175349891185760e-02
    z[1,2,2]  R846      3.4580063819885254e-01
    z[1,2,2]  R847      1.1843249201774597e-01
    z[1,2,2]  R848      -9.7293847799301147e-01
    z[1,2,2]  R849      -0.603140115737915
    z[1,2,2]  R850      0.538955569267273
    z[1,2,2]  R851      3.4552767872810364e-01
    z[1,2,2]  R852      4.6513897180557251e-01
    z[1,2,2]  R853      3.9125081896781921e-01
    z[1,2,2]  R854      0.631007969379425
    z[1,2,2]  R855      4.0838566422462463e-01
    z[1,2,2]  R856      2.9552167654037476e-01
    z[1,2,2]  R857      -7.1046546101570129e-02
    z[1,2,2]  R858      -2.2020098567008972e-01
    z[1,2,2]  R859      -3.8433471322059631e-01
    z[1,2,2]  R860      -6.2234717607498169e-01
    z[1,2,2]  R861      -2.7834331989288330e-01
    z[1,2,2]  R862      -3.2542139291763306e-01
    z[1,2,2]  R863      6.6539543867111206e-01
    z[1,2,2]  R864      7.9765558242797852e-01
    z[1,2,2]  R865      3.8779592514038086e-01
    z[1,2,2]  R866      5.2622526884078979e-01
    z[1,2,2]  R867      1.4367006719112396e-01
    z[1,2,2]  R868      -1.7414540052413940e-01
    z[1,2,2]  R869      6.0414743423461914e-01
    z[1,2,2]  R870      4.3512764573097229e-01
    z[1,2,2]  R871      1.7907401919364929e-01
    z[1,2,2]  R872      1.1400596052408218e-01
    z[1,2,2]  R873      0.640015721321106
    z[1,2,2]  R874      3.4429121017456055e-01
    z[1,2,2]  R875      5.1569050550460815e-01
    z[1,2,2]  R876      3.5431039333343506e-01
    z[1,2,2]  R877      -1.0312790423631668e-01
    z[1,2,2]  R878      -4.5585840940475464e-01
    z[1,2,2]  R879      -8.5497385263442993e-01
    z[1,2,2]  R880      -6.3647091388702393e-01
    z[1,2,2]  R881      -4.1328567266464233e-01
    z[1,2,2]  R882      -4.7504201531410217e-01
    z[1,2,2]  R883      0.516404390335083
    z[1,2,2]  R884      6.6580301523208618e-01
    z[1,2,2]  R885      4.2725303769111633e-01
    z[1,2,2]  R886      2.8814834356307983e-01
    z[1,2,2]  R887      7.9223197698593140e-01
    z[1,2,2]  R888      -5.8989274501800537e-01
    z[1,2,2]  R889      -0.674820601940155
    z[1,2,2]  R890      -1.7844487726688385e-01
    z[1,2,2]  R891      4.4019383192062378e-01
    z[1,2,2]  R892      2.5102981925010681e-01
    z[1,2,2]  R893      -2.7532413601875305e-01
    z[1,2,2]  R894      2.7033400535583496e-01
    z[1,2,2]  R895      -1.5471804141998291e-01
    z[1,2,2]  R896      8.2182055711746216e-01
    z[1,2,2]  R897      5.1102900505065918e-01
    z[1,2,2]  R898      -3.8311538100242615e-01
    z[1,2,2]  R899      0.812807559967041
    z[1,2,2]  R900      6.2336695194244385e-01
    z[1,2,2]  R901      3.4351414442062378e-01
    z[1,2,2]  R902      2.3672124743461609e-01
    z[1,2,2]  R903      6.7838686704635620e-01
    z[1,2,2]  R904      -2.6348397135734558e-01
    z[1,2,2]  R905      -2.3500017821788788e-01
    z[1,2,2]  R906      -4.5101469755172729e-01
    z[1,2,2]  R907      -5.6494605541229248e-01
    z[1,2,2]  R908      1.8569216132164001e-01
    z[1,2,2]  R909      -1.2094815820455551e-01
    z[1,2,2]  R910      5.0320732593536377e-01
    z[1,2,2]  R911      8.1830513477325439e-01
    z[1,2,2]  R912      4.7848334908485413e-01
    z[1,2,2]  R913      5.3767633438110352e-01
    z[1,2,2]  R914      -1.4037846028804779e-01
    z[1,2,2]  R915      -2.8815340995788574e-01
    z[1,2,2]  R916      -2.9185838066041470e-03
    z[1,2,2]  R917      7.4860163033008575e-02
    z[1,2,2]  R918      -3.8576507568359375e-01
    z[1,2,2]  R919      6.0245078802108765e-01
    z[1,2,2]  R920      7.6126885414123535e-01
    z[1,2,2]  R921      1.1741225421428680e-01
    z[1,2,2]  R922      8.1855398416519165e-01
    z[1,2,2]  R923      -3.4392636269330978e-02
    z[1,2,2]  R924      1.3338804244995117e-01
    z[1,2,2]  R925      -1.5795648097991943e-01
    z[1,2,2]  R926      -1.1510962992906570e-01
    z[1,2,2]  R927      5.6414250284433365e-02
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R780      -1
    z[1,2,3]  R781      1
    z[1,2,3]  R788      3.9904925227165222e-01
    z[1,2,3]  R789      -4.4947284460067749e-01
    z[1,2,3]  R790      -2.5990280508995056e-01
    z[1,2,3]  R791      -3.9733633399009705e-01
    z[1,2,3]  R792      -2.7447342872619629e-01
    z[1,2,3]  R793      -5.7482278347015381e-01
    z[1,2,3]  R794      -6.4267545938491821e-01
    z[1,2,3]  R795      -2.6924726553261280e-03
    z[1,2,3]  R796      -4.3043103814125061e-01
    z[1,2,3]  R797      -5.6083846092224121e-01
    z[1,2,3]  R798      -4.9707889556884766e-03
    z[1,2,3]  R799      5.6251049041748047e-01
    z[1,2,3]  R800      4.5717990398406982e-01
    z[1,2,3]  R801      5.6790667772293091e-01
    z[1,2,3]  R802      6.6686850786209106e-01
    z[1,2,3]  R803      4.8297506570816040e-01
    z[1,2,3]  R804      4.2766058444976807e-01
    z[1,2,3]  R805      2.0888186991214752e-01
    z[1,2,3]  R806      2.5776371359825134e-01
    z[1,2,3]  R807      2.2306315600872040e-01
    z[1,2,3]  R808      -1.1081153899431229e-01
    z[1,2,3]  R809      -0.454868882894516
    z[1,2,3]  R810      -4.9220845103263855e-01
    z[1,2,3]  R811      0.456521600484848
    z[1,2,3]  R812      0.0790027603507042
    z[1,2,3]  R813      5.3736311197280884e-01
    z[1,2,3]  R814      1.2507483363151550e-01
    z[1,2,3]  R815      3.1046831607818604e-01
    z[1,2,3]  R816      -4.5002856850624084e-01
    z[1,2,3]  R817      -7.8516000509262085e-01
    z[1,2,3]  R818      -0.120479054749012
    z[1,2,3]  R819      8.1015847623348236e-02
    z[1,2,3]  R820      -5.2535998821258545e-01
    z[1,2,3]  R821      -4.3817153573036194e-01
    z[1,2,3]  R822      -7.7117341756820679e-01
    z[1,2,3]  R823      -6.7462337017059326e-01
    z[1,2,3]  R824      -3.9227211475372314e-01
    z[1,2,3]  R825      -6.4566022157669067e-01
    z[1,2,3]  R826      -8.5562658309936523e-01
    z[1,2,3]  R827      9.8151132464408875e-02
    z[1,2,3]  R828      3.6296206712722778e-01
    z[1,2,3]  R829      1.9905048608779907e-01
    z[1,2,3]  R830      1.3431535661220551e-01
    z[1,2,3]  R831      -6.5590482950210571e-01
    z[1,2,3]  R832      -7.0590674877166748e-01
    z[1,2,3]  R833      -4.9436318874359131e-01
    z[1,2,3]  R834      -7.5713771581649780e-01
    z[1,2,3]  R835      -8.6876374483108521e-01
    z[1,2,3]  R836      -5.4235792160034180e-01
    z[1,2,3]  R837      -6.7413049936294556e-01
    z[1,2,3]  R838      8.8837943971157074e-02
    z[1,2,3]  R839      -7.3519039154052734e-01
    z[1,2,3]  R840      -1.9255171716213226e-01
    z[1,2,3]  R841      1.3584984838962555e-01
    z[1,2,3]  R842      2.1812172234058380e-01
    z[1,2,3]  R843      9.1849960386753082e-02
    z[1,2,3]  R844      1.8861801922321320e-01
    z[1,2,3]  R845      -2.7884244918823242e-01
    z[1,2,3]  R846      1.2510600499808788e-02
    z[1,2,3]  R847      -2.7186835184693336e-02
    z[1,2,3]  R848      -8.8208511471748352e-02
    z[1,2,3]  R849      -4.7521755099296570e-01
    z[1,2,3]  R850      -3.1744179129600525e-01
    z[1,2,3]  R851      -2.5882029533386230e-01
    z[1,2,3]  R852      1.6882614791393280e-01
    z[1,2,3]  R853      -1.2544415891170502e-01
    z[1,2,3]  R854      -3.3502653241157532e-01
    z[1,2,3]  R855      1.2970754504203796e-01
    z[1,2,3]  R856      2.1457606554031372e-01
    z[1,2,3]  R857      -5.3176287561655045e-02
    z[1,2,3]  R858      -3.4870305657386780e-01
    z[1,2,3]  R859      -3.8045141100883484e-01
    z[1,2,3]  R860      -2.4736273288726807e-01
    z[1,2,3]  R861      -5.5625128746032715e-01
    z[1,2,3]  R862      -6.0599648952484131e-01
    z[1,2,3]  R863      -6.9442704319953918e-02
    z[1,2,3]  R864      3.6038818955421448e-01
    z[1,2,3]  R865      0.411622554063797
    z[1,2,3]  R866      -2.1343001723289490e-01
    z[1,2,3]  R867      5.3617221117019653e-01
    z[1,2,3]  R868      -1.0586037300527096e-02
    z[1,2,3]  R869      -0.266049325466156
    z[1,2,3]  R870      0.000654847186524421
    z[1,2,3]  R871      1.8572027981281281e-01
    z[1,2,3]  R872      6.1764854937791824e-02
    z[1,2,3]  R873      -2.6875153183937073e-01
    z[1,2,3]  R874      -3.9000564813613892e-01
    z[1,2,3]  R875      0.418507844209671
    z[1,2,3]  R876      -1.8928614258766174e-01
    z[1,2,3]  R877      -1.2874467670917511e-01
    z[1,2,3]  R878      -4.7685131430625916e-01
    z[1,2,3]  R879      -1.7664164304733276e-01
    z[1,2,3]  R880      -4.7321975231170654e-02
    z[1,2,3]  R881      -1.9970078021287918e-02
    z[1,2,3]  R882      -2.7834182977676392e-01
    z[1,2,3]  R883      1.3912315666675568e-01
    z[1,2,3]  R884      4.6573978662490845e-01
    z[1,2,3]  R885      -2.5322949886322021e-01
    z[1,2,3]  R886      -6.7431682348251343e-01
    z[1,2,3]  R887      1.8873554468154907e-01
    z[1,2,3]  R888      -5.1140058785676956e-02
    z[1,2,3]  R889      -6.1911731958389282e-01
    z[1,2,3]  R890      -1.6849631071090698e-01
    z[1,2,3]  R891      -1.8016840517520905e-01
    z[1,2,3]  R892      1.9928215444087982e-01
    z[1,2,3]  R893      1.0604322701692581e-01
    z[1,2,3]  R894      -1.2245579808950424e-01
    z[1,2,3]  R895      -1.8359085917472839e-01
    z[1,2,3]  R896      9.3848649412393570e-03
    z[1,2,3]  R897      3.6554974317550659e-01
    z[1,2,3]  R898      -1.3364183902740479e-01
    z[1,2,3]  R899      2.7470090985298157e-01
    z[1,2,3]  R900      2.1028025448322296e-01
    z[1,2,3]  R901      -2.8887799382209778e-01
    z[1,2,3]  R902      3.1354019045829773e-01
    z[1,2,3]  R903      -3.2518345117568970e-01
    z[1,2,3]  R904      6.3137114048004150e-01
    z[1,2,3]  R905      6.0915040969848633e-01
    z[1,2,3]  R906      -1.0930795967578888e-01
    z[1,2,3]  R907      9.4762936234474182e-02
    z[1,2,3]  R908      0.0528901144862175
    z[1,2,3]  R909      -2.2071680426597595e-01
    z[1,2,3]  R910      2.7505340054631233e-02
    z[1,2,3]  R911      -5.4072678089141846e-02
    z[1,2,3]  R912      -0.508666455745697
    z[1,2,3]  R913      1.5174891054630280e-01
    z[1,2,3]  R914      1.5501870773732662e-02
    z[1,2,3]  R915      -1.4099037647247314e-01
    z[1,2,3]  R916      5.5263692140579224e-01
    z[1,2,3]  R917      1.0978803038597107e-01
    z[1,2,3]  R918      -5.9805382043123245e-02
    z[1,2,3]  R919      -3.5006541013717651e-01
    z[1,2,3]  R920      1.3073551654815674e-01
    z[1,2,3]  R921      -6.5448500216007233e-02
    z[1,2,3]  R922      1.7718425393104553e-01
    z[1,2,3]  R923      4.4877770543098450e-01
    z[1,2,3]  R924      5.1594823598861694e-01
    z[1,2,3]  R925      1.2030216306447983e-01
    z[1,2,3]  R926      3.7173676490783691e-01
    z[1,2,3]  R927      1.4595986902713776e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R782      -1
    z[1,2,4]  R783      1
    z[1,2,4]  R788      -3.1760153174400330e-01
    z[1,2,4]  R789      1.2788502871990204e-01
    z[1,2,4]  R790      -4.5941525697708130e-01
    z[1,2,4]  R791      -4.5679351687431335e-01
    z[1,2,4]  R792      -6.8453729152679443e-01
    z[1,2,4]  R793      -2.0277164876461029e-02
    z[1,2,4]  R794      5.1528328657150269e-01
    z[1,2,4]  R795      5.8601063489913940e-01
    z[1,2,4]  R796      3.4970134496688843e-01
    z[1,2,4]  R797      2.0519576966762543e-01
    z[1,2,4]  R798      -2.5997087359428406e-02
    z[1,2,4]  R799      -3.1932753324508667e-01
    z[1,2,4]  R800      -2.0619036257266998e-01
    z[1,2,4]  R801      2.2363530471920967e-02
    z[1,2,4]  R802      2.4442672729492188e-02
    z[1,2,4]  R803      -2.2545643150806427e-01
    z[1,2,4]  R804      -2.4691025912761688e-01
    z[1,2,4]  R805      -1.8389484286308289e-01
    z[1,2,4]  R806      6.4173959195613861e-02
    z[1,2,4]  R807      -4.2985841631889343e-01
    z[1,2,4]  R808      2.8474089503288269e-01
    z[1,2,4]  R809      -1.8321696668863297e-02
    z[1,2,4]  R810      1.2423494458198547e-01
    z[1,2,4]  R811      -0.0837835893034935
    z[1,2,4]  R812      -4.8522930592298508e-02
    z[1,2,4]  R813      -2.8666019439697266e-01
    z[1,2,4]  R814      -2.0664894580841064e-01
    z[1,2,4]  R815      -3.7180971354246140e-02
    z[1,2,4]  R816      -9.1457515954971313e-02
    z[1,2,4]  R817      -8.6750283837318420e-02
    z[1,2,4]  R818      1.3383789360523224e-01
    z[1,2,4]  R819      -6.1846762895584106e-01
    z[1,2,4]  R820      -9.6565060317516327e-02
    z[1,2,4]  R821      -3.8908189535140991e-01
    z[1,2,4]  R822      -1.9357408583164215e-01
    z[1,2,4]  R823      -1.5970006585121155e-01
    z[1,2,4]  R824      -3.8437676429748535e-01
    z[1,2,4]  R825      -4.9526163935661316e-01
    z[1,2,4]  R826      2.0835416018962860e-01
    z[1,2,4]  R827      -2.9163017868995667e-01
    z[1,2,4]  R828      0.0585007481276989
    z[1,2,4]  R829      2.9259911179542542e-01
    z[1,2,4]  R830      -6.8360525369644165e-01
    z[1,2,4]  R831      -0.242141455411911
    z[1,2,4]  R832      -2.4339766800403595e-01
    z[1,2,4]  R833      -1.4195046387612820e-02
    z[1,2,4]  R834      -0.0697336345911026
    z[1,2,4]  R835      -7.0744507014751434e-02
    z[1,2,4]  R836      -1.7798207700252533e-01
    z[1,2,4]  R837      -3.3123213797807693e-03
    z[1,2,4]  R838      -2.9495945572853088e-01
    z[1,2,4]  R839      9.0996541082859039e-02
    z[1,2,4]  R840      -2.4021466076374054e-01
    z[1,2,4]  R841      -1.0266276448965073e-01
    z[1,2,4]  R842      -1.9709125161170959e-01
    z[1,2,4]  R843      1.9474083185195923e-01
    z[1,2,4]  R844      -1.4570684731006622e-01
    z[1,2,4]  R845      7.8483283519744873e-02
    z[1,2,4]  R846      5.5651620030403137e-02
    z[1,2,4]  R847      2.9908114671707153e-01
    z[1,2,4]  R848      -6.8349972367286682e-02
    z[1,2,4]  R849      6.0959316790103912e-02
    z[1,2,4]  R850      2.9346242547035217e-01
    z[1,2,4]  R851      8.8077321648597717e-02
    z[1,2,4]  R852      9.8922697361558676e-04
    z[1,2,4]  R853      -3.4094041585922241e-01
    z[1,2,4]  R854      1.2515866756439209e-01
    z[1,2,4]  R855      -1.7869557440280914e-01
    z[1,2,4]  R856      1.4933820068836212e-01
    z[1,2,4]  R857      -8.8455349206924438e-02
    z[1,2,4]  R858      2.0481154322624207e-01
    z[1,2,4]  R859      1.1627225577831268e-01
    z[1,2,4]  R860      -1.8047428131103516e-01
    z[1,2,4]  R861      4.3158102035522461e-01
    z[1,2,4]  R862      8.9279748499393463e-02
    z[1,2,4]  R863      4.7327745705842972e-02
    z[1,2,4]  R864      -1.3478185236454010e-01
    z[1,2,4]  R865      9.2412687838077545e-02
    z[1,2,4]  R866      2.3024432361125946e-01
    z[1,2,4]  R867      -4.7474950551986694e-01
    z[1,2,4]  R868      3.2538694143295288e-01
    z[1,2,4]  R869      6.5021462738513947e-02
    z[1,2,4]  R870      -1.3610567152500153e-01
    z[1,2,4]  R871      -4.4518828392028809e-02
    z[1,2,4]  R872      1.2379807233810425e-01
    z[1,2,4]  R873      4.1480544209480286e-01
    z[1,2,4]  R874      3.1806635856628418e-01
    z[1,2,4]  R875      -2.6723667979240417e-01
    z[1,2,4]  R876      0.335847407579422
    z[1,2,4]  R877      -5.1931455731391907e-02
    z[1,2,4]  R878      5.0190949440002441e-01
    z[1,2,4]  R879      2.3953368887305260e-02
    z[1,2,4]  R880      -3.0785033106803894e-01
    z[1,2,4]  R881      2.9963433742523193e-01
    z[1,2,4]  R882      2.2519567608833313e-01
    z[1,2,4]  R883      -4.9410410225391388e-02
    z[1,2,4]  R884      -3.4072495996952057e-02
    z[1,2,4]  R885      2.7562731504440308e-01
    z[1,2,4]  R886      5.3666192293167114e-01
    z[1,2,4]  R887      -1.4008262753486633e-01
    z[1,2,4]  R888      5.3228306770324707e-01
    z[1,2,4]  R889      3.5014921426773071e-01
    z[1,2,4]  R890      -2.6225471496582031e-01
    z[1,2,4]  R891      2.9552286863327026e-01
    z[1,2,4]  R892      4.7938823699951172e-02
    z[1,2,4]  R893      -1.8676073849201202e-01
    z[1,2,4]  R894      -2.2156653925776482e-02
    z[1,2,4]  R895      1.5780363464727998e-03
    z[1,2,4]  R896      -3.1281030178070068e-01
    z[1,2,4]  R897      -3.3786624670028687e-01
    z[1,2,4]  R898      -9.9446296691894531e-02
    z[1,2,4]  R899      -3.9691093564033508e-01
    z[1,2,4]  R900      -2.2341039776802063e-01
    z[1,2,4]  R901      -1.5150465071201324e-01
    z[1,2,4]  R902      -2.4573905766010284e-01
    z[1,2,4]  R903      -2.2003591060638428e-01
    z[1,2,4]  R904      -4.6767142415046692e-01
    z[1,2,4]  R905      -0.273552268743515
    z[1,2,4]  R906      1.2600430846214294e-01
    z[1,2,4]  R907      -1.2882158160209656e-01
    z[1,2,4]  R908      2.3652262985706329e-01
    z[1,2,4]  R909      3.1723294407129288e-02
    z[1,2,4]  R910      -2.9491975903511047e-02
    z[1,2,4]  R911      1.5443550050258636e-01
    z[1,2,4]  R912      -4.2121908068656921e-01
    z[1,2,4]  R913      1.8458089232444763e-01
    z[1,2,4]  R914      1.7301696538925171e-01
    z[1,2,4]  R915      7.5182333588600159e-02
    z[1,2,4]  R916      -2.9577374458312988e-01
    z[1,2,4]  R917      3.4480038285255432e-01
    z[1,2,4]  R918      1.5085572004318237e-01
    z[1,2,4]  R919      -1.7213378846645355e-01
    z[1,2,4]  R920      -2.7899801731109619e-02
    z[1,2,4]  R921      1.2818282842636108e-01
    z[1,2,4]  R922      2.9733744263648987e-01
    z[1,2,4]  R923      -5.7709133625030518e-01
    z[1,2,4]  R924      -6.4456969499588013e-01
    z[1,2,4]  R925      -4.7712764143943787e-01
    z[1,2,4]  R926      -2.0363937318325043e-01
    z[1,2,4]  R927      -2.2551403380930424e-03
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R784      -1
    z[1,2,5]  R785      1
    z[1,2,5]  R788      -3.3961209654808044e-01
    z[1,2,5]  R789      1.8544797599315643e-01
    z[1,2,5]  R790      1.1440439522266388e-01
    z[1,2,5]  R791      6.5428024530410767e-01
    z[1,2,5]  R792      4.4936504960060120e-01
    z[1,2,5]  R793      -3.0648830533027649e-01
    z[1,2,5]  R794      1.1762021481990814e-01
    z[1,2,5]  R795      -2.5380519032478333e-01
    z[1,2,5]  R796      -3.1958609819412231e-01
    z[1,2,5]  R797      -8.4092825651168823e-02
    z[1,2,5]  R798      -1.1361759155988693e-01
    z[1,2,5]  R799      4.4120015809312463e-04
    z[1,2,5]  R800      -2.7406115084886551e-02
    z[1,2,5]  R801      1.1172773083671927e-03
    z[1,2,5]  R802      -9.8782189190387726e-02
    z[1,2,5]  R803      -2.7341619133949280e-01
    z[1,2,5]  R804      1.3734828680753708e-02
    z[1,2,5]  R805      -2.1597044542431831e-02
    z[1,2,5]  R806      1.3793526589870453e-01
    z[1,2,5]  R807      0.0759831964969635
    z[1,2,5]  R808      4.6145290136337280e-02
    z[1,2,5]  R809      3.8462081551551819e-01
    z[1,2,5]  R810      0.309256374835968
    z[1,2,5]  R811      -1.5847636759281158e-01
    z[1,2,5]  R812      5.0776267051696777e-01
    z[1,2,5]  R813      2.5914970040321350e-01
    z[1,2,5]  R814      7.1749143302440643e-02
    z[1,2,5]  R815      -3.7542516365647316e-03
    z[1,2,5]  R816      -2.2628861665725708e-01
    z[1,2,5]  R817      -1.9060148298740387e-01
    z[1,2,5]  R818      -3.3287471532821655e-01
    z[1,2,5]  R819      -9.2252299189567566e-02
    z[1,2,5]  R820      -5.5725795030593872e-01
    z[1,2,5]  R821      -2.5712516903877258e-01
    z[1,2,5]  R822      -5.5599504709243774e-01
    z[1,2,5]  R823      -5.6729829311370850e-01
    z[1,2,5]  R824      -4.8965570330619812e-01
    z[1,2,5]  R825      -2.9055011272430420e-01
    z[1,2,5]  R826      1.7456176877021790e-01
    z[1,2,5]  R827      2.8850591182708740e-01
    z[1,2,5]  R828      -2.4103295058012009e-02
    z[1,2,5]  R829      -6.2595404684543610e-02
    z[1,2,5]  R830      -7.4984863400459290e-02
    z[1,2,5]  R831      -1.5337084233760834e-01
    z[1,2,5]  R832      -5.4406648874282837e-01
    z[1,2,5]  R833      -5.2214270830154419e-01
    z[1,2,5]  R834      7.0977574214339256e-03
    z[1,2,5]  R835      5.4667755961418152e-02
    z[1,2,5]  R836      -5.1970493793487549e-01
    z[1,2,5]  R837      -6.0246225446462631e-02
    z[1,2,5]  R838      3.3154781907796860e-02
    z[1,2,5]  R839      -5.5117465555667877e-02
    z[1,2,5]  R840      1.1985098570585251e-01
    z[1,2,5]  R841      1.4734235405921936e-01
    z[1,2,5]  R842      -3.7574142217636108e-02
    z[1,2,5]  R843      -1.2454599142074585e-01
    z[1,2,5]  R844      8.0336481332778931e-02
    z[1,2,5]  R845      3.3352074027061462e-01
    z[1,2,5]  R846      0.199890598654747
    z[1,2,5]  R847      4.5918133109807968e-03
    z[1,2,5]  R848      -8.1709325313568115e-02
    z[1,2,5]  R849      -5.7853251695632935e-01
    z[1,2,5]  R850      2.4344623088836670e-02
    z[1,2,5]  R851      -9.7902357578277588e-02
    z[1,2,5]  R852      -1.1295893043279648e-01
    z[1,2,5]  R853      -1.3188610784709454e-02
    z[1,2,5]  R854      -4.7790925949811935e-02
    z[1,2,5]  R855      -1.4583942294120789e-01
    z[1,2,5]  R856      -0.0196728203445673
    z[1,2,5]  R857      -8.7292753159999847e-02
    z[1,2,5]  R858      1.9400827586650848e-01
    z[1,2,5]  R859      1.9348324835300446e-01
    z[1,2,5]  R860      -2.4957165122032166e-01
    z[1,2,5]  R861      2.1434809267520905e-01
    z[1,2,5]  R862      1.7687307298183441e-01
    z[1,2,5]  R863      0.0924796313047409
    z[1,2,5]  R864      2.7627438306808472e-01
    z[1,2,5]  R865      3.8378086686134338e-01
    z[1,2,5]  R866      5.0076556205749512e-01
    z[1,2,5]  R867      3.6635959148406982e-01
    z[1,2,5]  R868      -0.655155599117279
    z[1,2,5]  R869      2.6621329784393311e-01
    z[1,2,5]  R870      -0.0172334685921669
    z[1,2,5]  R871      0.386877179145813
    z[1,2,5]  R872      6.8370831012725830e-01
    z[1,2,5]  R873      4.0803152322769165e-01
    z[1,2,5]  R874      0.0565381720662117
    z[1,2,5]  R875      0.100244902074337
    z[1,2,5]  R876      -3.4102091193199158e-01
    z[1,2,5]  R877      2.6719495654106140e-01
    z[1,2,5]  R878      -2.7230077981948853e-01
    z[1,2,5]  R879      6.2127064913511276e-02
    z[1,2,5]  R880      9.1365143656730652e-02
    z[1,2,5]  R881      -4.5349341630935669e-01
    z[1,2,5]  R882      -2.9470628499984741e-01
    z[1,2,5]  R883      2.8922820091247559e-01
    z[1,2,5]  R884      5.0339066982269287e-01
    z[1,2,5]  R885      -1.0987876914441586e-02
    z[1,2,5]  R886      -2.1653366088867188e-01
    z[1,2,5]  R887      -2.0477293431758881e-01
    z[1,2,5]  R888      -5.5073618888854980e-02
    z[1,2,5]  R889      0.151590496301651
    z[1,2,5]  R890      4.6486937999725342e-01
    z[1,2,5]  R891      6.2038439512252808e-01
    z[1,2,5]  R892      6.5783679485321045e-01
    z[1,2,5]  R893      4.6448069810867310e-01
    z[1,2,5]  R894      -2.0570924878120422e-01
    z[1,2,5]  R895      7.2977238893508911e-01
    z[1,2,5]  R896      2.4681676924228668e-01
    z[1,2,5]  R897      1.1680758744478226e-01
    z[1,2,5]  R898      4.2079731822013855e-01
    z[1,2,5]  R899      9.8230935633182526e-02
    z[1,2,5]  R900      3.7939116358757019e-01
    z[1,2,5]  R901      5.3273308277130127e-01
    z[1,2,5]  R902      3.8930308818817139e-01
    z[1,2,5]  R903      3.5388889908790588e-01
    z[1,2,5]  R904      -2.1736070513725281e-01
    z[1,2,5]  R905      1.3541743159294128e-01
    z[1,2,5]  R906      -2.4555966258049011e-01
    z[1,2,5]  R907      2.1628174930810928e-02
    z[1,2,5]  R908      -0.213386669754982
    z[1,2,5]  R909      6.2998242676258087e-02
    z[1,2,5]  R910      4.8398381471633911e-01
    z[1,2,5]  R911      9.2903882265090942e-02
    z[1,2,5]  R912      4.3472254276275635e-01
    z[1,2,5]  R913      1.5766884386539459e-01
    z[1,2,5]  R914      -2.6922854781150818e-01
    z[1,2,5]  R915      -2.9883456230163574e-01
    z[1,2,5]  R916      3.1535025686025620e-02
    z[1,2,5]  R917      -1.9695109128952026e-01
    z[1,2,5]  R918      -2.9514765739440918e-01
    z[1,2,5]  R919      5.9990507364273071e-01
    z[1,2,5]  R920      -3.3689178526401520e-02
    z[1,2,5]  R921      2.7362295985221863e-01
    z[1,2,5]  R922      8.9038470759987831e-03
    z[1,2,5]  R923      -0.312675416469574
    z[1,2,5]  R924      9.4866394996643066e-02
    z[1,2,5]  R925      -1.6696314513683319e-01
    z[1,2,5]  R926      -4.4190770387649536e-01
    z[1,2,5]  R927      -7.9289132356643677e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R786      -1
    z[1,2,6]  R787      1
    z[1,2,6]  R788      1.0709770768880844e-01
    z[1,2,6]  R789      -2.4973434209823608e-01
    z[1,2,6]  R790      1.0766394436359406e-01
    z[1,2,6]  R791      -1.2142031639814377e-01
    z[1,2,6]  R792      2.6148018240928650e-01
    z[1,2,6]  R793      4.3953621387481689e-01
    z[1,2,6]  R794      -7.3536694981157780e-03
    z[1,2,6]  R795      -9.8360069096088409e-02
    z[1,2,6]  R796      2.5545188784599304e-01
    z[1,2,6]  R797      3.6544266343116760e-01
    z[1,2,6]  R798      2.3569293320178986e-01
    z[1,2,6]  R799      1.7103728652000427e-01
    z[1,2,6]  R800      -1.4125512540340424e-01
    z[1,2,6]  R801      -1.0065762698650360e-01
    z[1,2,6]  R802      -1.8577769398689270e-01
    z[1,2,6]  R803      1.7328223586082458e-01
    z[1,2,6]  R804      -1.8665000796318054e-01
    z[1,2,6]  R805      -1.3384471833705902e-01
    z[1,2,6]  R806      -1.6737556457519531e-01
    z[1,2,6]  R807      -1.9298050552606583e-02
    z[1,2,6]  R808      -1.5526151657104492e-01
    z[1,2,6]  R809      -7.1109756827354431e-02
    z[1,2,6]  R810      -1.9608356058597565e-01
    z[1,2,6]  R811      -2.3779530823230743e-01
    z[1,2,6]  R812      -4.6682038903236389e-01
    z[1,2,6]  R813      -3.0959886312484741e-01
    z[1,2,6]  R814      2.9122793674468994e-01
    z[1,2,6]  R815      1.1080313473939896e-01
    z[1,2,6]  R816      -6.8453967571258545e-01
    z[1,2,6]  R817      -4.1320380568504333e-01
    z[1,2,6]  R818      4.7924613952636719e-01
    z[1,2,6]  R819      5.4809981584548950e-01
    z[1,2,6]  R820      -1.1365757137537003e-01
    z[1,2,6]  R821      -1.4261193573474884e-01
    z[1,2,6]  R822      -7.7522225677967072e-02
    z[1,2,6]  R823      -1.8059577047824860e-01
    z[1,2,6]  R824      -7.2199523448944092e-02
    z[1,2,6]  R825      1.6902619600296021e-01
    z[1,2,6]  R826      -2.3229663074016571e-01
    z[1,2,6]  R827      -2.8217615559697151e-02
    z[1,2,6]  R828      -2.4007629603147507e-02
    z[1,2,6]  R829      -1.7738421261310577e-01
    z[1,2,6]  R830      4.8832595348358154e-01
    z[1,2,6]  R831      -2.4512539803981781e-01
    z[1,2,6]  R832      -8.6079455912113190e-02
    z[1,2,6]  R833      -3.3156612515449524e-01
    z[1,2,6]  R834      2.8960786759853363e-02
    z[1,2,6]  R835      -2.5481003522872925e-01
    z[1,2,6]  R836      1.3467422127723694e-01
    z[1,2,6]  R837      1.0879641771316528e-01
    z[1,2,6]  R838      3.0809977650642395e-01
    z[1,2,6]  R839      3.7304118275642395e-01
    z[1,2,6]  R840      1.1342987418174744e-01
    z[1,2,6]  R841      -1.6270875930786133e-01
    z[1,2,6]  R842      3.9924681186676025e-02
    z[1,2,6]  R843      -2.3157656192779541e-01
    z[1,2,6]  R844      3.9496082812547684e-02
    z[1,2,6]  R845      -2.0244711637496948e-01
    z[1,2,6]  R846      -3.8225898146629333e-01
    z[1,2,6]  R847      -2.5455081462860107e-01
    z[1,2,6]  R848      6.7505091428756714e-02
    z[1,2,6]  R849      2.2287836670875549e-01
    z[1,2,6]  R850      -2.2092872858047485e-01
    z[1,2,6]  R851      -3.8008540868759155e-01
    z[1,2,6]  R852      -2.3824036121368408e-01
    z[1,2,6]  R853      -4.5026361942291260e-01
    z[1,2,6]  R854      -5.8528423309326172e-01
    z[1,2,6]  R855      -3.8883182406425476e-01
    z[1,2,6]  R856      7.0273093879222870e-02
    z[1,2,6]  R857      1.1326502077281475e-02
    z[1,2,6]  R858      4.8504152894020081e-01
    z[1,2,6]  R859      -6.7624074220657349e-01
    z[1,2,6]  R860      -0.0548379123210907
    z[1,2,6]  R861      -3.8653293251991272e-01
    z[1,2,6]  R862      2.7660849690437317e-01
    z[1,2,6]  R863      0.660368800163269
    z[1,2,6]  R864      3.5540419816970825e-01
    z[1,2,6]  R865      -3.1410497426986694e-01
    z[1,2,6]  R866      -3.4020674228668213e-01
    z[1,2,6]  R867      1.0890915989875793e-01
    z[1,2,6]  R868      -5.5048700422048569e-02
    z[1,2,6]  R869      3.8220253586769104e-01
    z[1,2,6]  R870      1.9806094467639923e-01
    z[1,2,6]  R871      -3.2253879308700562e-01
    z[1,2,6]  R872      -1.0856601595878601e-01
    z[1,2,6]  R873      1.3984479010105133e-01
    z[1,2,6]  R874      3.5530152916908264e-01
    z[1,2,6]  R875      3.1432738900184631e-01
    z[1,2,6]  R876      -6.4855682849884033e-01
    z[1,2,6]  R877      -4.3666839599609375e-01
    z[1,2,6]  R878      4.8712867498397827e-01
    z[1,2,6]  R879      4.7566527128219604e-01
    z[1,2,6]  R880      5.2784645557403564e-01
    z[1,2,6]  R881      4.8449450731277466e-01
    z[1,2,6]  R882      -3.9211180806159973e-01
    z[1,2,6]  R883      1.8672230839729309e-01
    z[1,2,6]  R884      -0.120102658867836
    z[1,2,6]  R885      1.8224196135997772e-01
    z[1,2,6]  R886      -1.5171281993389130e-02
    z[1,2,6]  R887      -4.6104211360216141e-02
    z[1,2,6]  R888      -9.4352580606937408e-02
    z[1,2,6]  R889      -3.1050495803356171e-02
    z[1,2,6]  R890      -2.1376334130764008e-01
    z[1,2,6]  R891      -1.7244471237063408e-02
    z[1,2,6]  R892      -1.3816219754517078e-02
    z[1,2,6]  R893      -5.5287098884582520e-01
    z[1,2,6]  R894      -3.3973211050033569e-01
    z[1,2,6]  R895      9.6057079732418060e-02
    z[1,2,6]  R896      3.9783695340156555e-01
    z[1,2,6]  R897      -0.396820992231369
    z[1,2,6]  R898      9.2072226107120514e-02
    z[1,2,6]  R899      6.0303029604256153e-03
    z[1,2,6]  R900      -7.7498771250247955e-02
    z[1,2,6]  R901      5.4637116193771362e-01
    z[1,2,6]  R902      -6.2113553285598755e-01
    z[1,2,6]  R903      -4.7485873103141785e-01
    z[1,2,6]  R904      -4.7389128804206848e-01
    z[1,2,6]  R905      -3.2400522381067276e-02
    z[1,2,6]  R906      -4.5558240264654160e-02
    z[1,2,6]  R907      1.7671963572502136e-01
    z[1,2,6]  R908      -2.6876670122146606e-01
    z[1,2,6]  R909      -4.5331677794456482e-01
    z[1,2,6]  R910      -6.3738840818405151e-01
    z[1,2,6]  R911      6.1344724148511887e-02
    z[1,2,6]  R912      -1.4742341637611389e-01
    z[1,2,6]  R913      -5.5559659004211426e-01
    z[1,2,6]  R914      -2.8658014535903931e-01
    z[1,2,6]  R915      -2.7599132061004639e-01
    z[1,2,6]  R916      3.0139073729515076e-01
    z[1,2,6]  R917      1.9801907241344452e-01
    z[1,2,6]  R918      -4.1881343722343445e-01
    z[1,2,6]  R919      -1.2827715277671814e-01
    z[1,2,6]  R920      -1.3251449167728424e-01
    z[1,2,6]  R921      -6.8024778366088867e-01
    z[1,2,6]  R922      -3.2817268371582031e-01
    z[1,2,6]  R923      0.483521431684494
    z[1,2,6]  R924      3.1587496399879456e-01
    z[1,2,6]  R925      2.1890194714069366e-01
    z[1,2,6]  R926      4.9500128626823425e-01
    z[1,2,6]  R927      3.1799605488777161e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R928      -1
    z[2,1,0]  R929      1
    z[2,1,0]  R942      4.8943213187158108e-04
    z[2,1,0]  R943      -4.1603740304708481e-02
    z[2,1,0]  R944      5.1707643270492554e-01
    z[2,1,0]  R945      -1.4327304065227509e-01
    z[2,1,0]  R946      2.5914323329925537e-01
    z[2,1,0]  R947      -2.7291810512542725e-01
    z[2,1,0]  R948      0.0910104289650917
    z[2,1,0]  R949      -2.3256616294384003e-01
    z[2,1,0]  R950      7.7293801307678223e-01
    z[2,1,0]  R951      2.8755825757980347e-01
    z[2,1,0]  R952      -2.6728084683418274e-01
    z[2,1,0]  R953      -4.1889202594757080e-01
    z[2,1,0]  R954      -5.4728162288665771e-01
    z[2,1,0]  R955      -3.1786096096038818e-01
    z[2,1,0]  R956      -2.7575197815895081e-01
    z[2,1,0]  R957      -1.1141210794448853e-01
    z[2,1,0]  R958      -1.1405264586210251e-01
    z[2,1,0]  R959      6.0256361961364746e-01
    z[2,1,0]  R960      -3.8535487651824951e-01
    z[2,1,0]  R961      1.9974620640277863e-01
    z[2,1,0]  R962      -4.6212542057037354e-01
    z[2,1,0]  R963      4.2640066146850586e-01
    z[2,1,0]  R964      -8.5050441324710846e-02
    z[2,1,0]  R965      3.2335484027862549e-01
    z[2,1,0]  R966      4.4760033488273621e-01
    z[2,1,0]  R967      7.1173951029777527e-02
    z[2,1,0]  R968      1.7132215201854706e-01
    z[2,1,0]  R969      2.4897687137126923e-01
    z[2,1,0]  R970      -4.1180300712585449e-01
    z[2,1,0]  R971      -5.4998654872179031e-02
    z[2,1,0]  R972      -8.2180071622133255e-03
    z[2,1,0]  R973      -8.3000110462307930e-03
    z[2,1,0]  R974      -4.5677873492240906e-01
    z[2,1,0]  R975      -3.5773512721061707e-01
    z[2,1,0]  R976      -1.5139569342136383e-01
    z[2,1,0]  R977      1.9323521852493286e-01
    z[2,1,0]  R978      2.3085275292396545e-01
    z[2,1,0]  R979      2.4176497757434845e-01
    z[2,1,0]  R980      -2.2811214625835419e-01
    z[2,1,0]  R981      -4.9839547276496887e-01
    z[2,1,0]  R982      -3.8368764519691467e-01
    z[2,1,0]  R983      1.6560640186071396e-02
    z[2,1,0]  R984      -0.744409441947937
    z[2,1,0]  R985      1.3075286149978638e-01
    z[2,1,0]  R986      4.6359366178512573e-01
    z[2,1,0]  R987      -5.2053827047348022e-01
    z[2,1,0]  R988      -8.0672997236251831e-01
    z[2,1,0]  R989      8.6004018783569336e-02
    z[2,1,0]  R990      8.1646546721458435e-02
    z[2,1,0]  R991      -4.4128152728080750e-01
    z[2,1,0]  R992      -7.7038669586181641e-01
    z[2,1,0]  R993      7.9201817512512207e-02
    z[2,1,0]  R994      -4.1911327838897705e-01
    z[2,1,0]  R995      3.4808114171028137e-02
    z[2,1,0]  R996      -2.0323015749454498e-01
    z[2,1,0]  R997      1.3780252635478973e-01
    z[2,1,0]  R998      1.7994193732738495e-01
    z[2,1,0]  R999      6.8335193395614624e-01
    z[2,1,0]  R1000     6.8507421016693115e-01
    z[2,1,0]  R1001     6.7109113931655884e-01
    z[2,1,0]  R1002     -8.6218303442001343e-01
    z[2,1,0]  R1003     -0.7164306640625
    z[2,1,0]  R1004     5.2741557359695435e-02
    z[2,1,0]  R1005     -1.5142881870269775e-01
    z[2,1,0]  R1006     2.1789434552192688e-01
    z[2,1,0]  R1007     2.3207060992717743e-01
    z[2,1,0]  R1008     2.4701507389545441e-01
    z[2,1,0]  R1009     4.1877689957618713e-01
    z[2,1,0]  R1010     2.0265518128871918e-01
    z[2,1,0]  R1011     6.7721772193908691e-01
    z[2,1,0]  R1012     -6.6606831550598145e-01
    z[2,1,0]  R1013     2.2552803158760071e-01
    z[2,1,0]  R1014     -1.7429448664188385e-01
    z[2,1,0]  R1015     4.7464754432439804e-02
    z[2,1,0]  R1016     2.4472886323928833e-01
    z[2,1,0]  R1017     1.1265747249126434e-01
    z[2,1,0]  R1018     -4.1515317559242249e-01
    z[2,1,0]  R1019     4.6510735154151917e-01
    z[2,1,0]  R1020     4.1333022713661194e-01
    z[2,1,0]  R1021     2.1875010430812836e-01
    z[2,1,0]  R1022     -5.4846620559692383e-01
    z[2,1,0]  R1023     -5.3737568855285645e-01
    z[2,1,0]  R1024     -3.4947690367698669e-01
    z[2,1,0]  R1025     -3.8337504863739014e-01
    z[2,1,0]  R1026     -3.3478114008903503e-01
    z[2,1,0]  R1027     -2.9309570789337158e-01
    z[2,1,0]  R1028     -4.8481833934783936e-01
    z[2,1,0]  R1029     -5.7584816217422485e-01
    z[2,1,0]  R1030     2.5187286734580994e-01
    z[2,1,0]  R1031     4.6663612127304077e-02
    z[2,1,0]  R1032     9.1005897521972656e-01
    z[2,1,0]  R1033     1.3805174827575684e-01
    z[2,1,0]  R1034     4.7126758098602295e-01
    z[2,1,0]  R1035     4.3676313757896423e-01
    z[2,1,0]  R1036     0.534625232219696
    z[2,1,0]  R1037     7.4053883552551270e-01
    z[2,1,0]  R1038     7.1643579006195068e-01
    z[2,1,0]  R1039     6.3351887464523315e-01
    z[2,1,0]  R1040     8.7949562072753906e-01
    z[2,1,0]  R1041     7.2757941484451294e-01
    z[2,1,0]  R1042     -8.9046663045883179e-01
    z[2,1,0]  R1043     -7.7508997917175293e-01
    z[2,1,0]  R1044     -5.2592891454696655e-01
    z[2,1,0]  R1045     -7.9635888338088989e-01
    z[2,1,0]  R1046     -6.9828587770462036e-01
    z[2,1,0]  R1047     -6.2233519554138184e-01
    z[2,1,0]  R1048     -5.0729984045028687e-01
    z[2,1,0]  R1049     3.2287669181823730e-01
    z[2,1,0]  R1050     2.2204083204269409e-01
    z[2,1,0]  R1051     4.0584060549736023e-01
    z[2,1,0]  R1052     -4.2859551310539246e-01
    z[2,1,0]  R1053     -5.0588089227676392e-01
    z[2,1,0]  R1054     -6.6504962742328644e-02
    z[2,1,0]  R1055     9.3613542616367340e-02
    z[2,1,0]  R1056     1.6056878864765167e-01
    z[2,1,0]  R1057     1.9732825458049774e-01
    z[2,1,0]  R1058     5.2592545747756958e-01
    z[2,1,0]  R1059     3.2273855805397034e-01
    z[2,1,0]  R1060     0.145841583609581
    z[2,1,0]  R1061     1.4634659886360168e-01
    z[2,1,0]  R1062     -4.9644985795021057e-01
    z[2,1,0]  R1063     -5.6475734710693359e-01
    z[2,1,0]  R1064     -4.7109922766685486e-01
    z[2,1,0]  R1065     5.1703029870986938e-01
    z[2,1,0]  R1066     4.9828074872493744e-02
    z[2,1,0]  R1067     -6.4766839146614075e-02
    z[2,1,0]  R1068     3.1029042601585388e-01
    z[2,1,0]  R1069     2.6755779981613159e-01
    z[2,1,0]  R1070     4.5220926403999329e-01
    z[2,1,0]  R1071     7.0565128326416016e-01
    z[2,1,0]  R1072     -7.2389864921569824e-01
    z[2,1,0]  R1073     4.7058889269828796e-01
    z[2,1,0]  R1074     3.2659158110618591e-01
    z[2,1,0]  R1075     2.9244866967201233e-01
    z[2,1,0]  R1076     1.8340951204299927e-01
    z[2,1,0]  R1077     1.1921054124832153e-01
    z[2,1,0]  R1078     4.4222906231880188e-01
    z[2,1,0]  R1079     4.4989496469497681e-01
    z[2,1,0]  R1080     0.354343980550766
    z[2,1,0]  R1081     4.8459321260452271e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R930      -1
    z[2,1,1]  R931      1
    z[2,1,1]  R942      -1.7235042154788971e-01
    z[2,1,1]  R943      -1.4341805875301361e-01
    z[2,1,1]  R944      -4.5372587442398071e-01
    z[2,1,1]  R945      -7.9453641176223755e-01
    z[2,1,1]  R946      -7.8642803430557251e-01
    z[2,1,1]  R947      -6.6147613525390625e-01
    z[2,1,1]  R948      -3.4755858778953552e-01
    z[2,1,1]  R949      -7.4693953990936279e-01
    z[2,1,1]  R950      -4.9149137735366821e-01
    z[2,1,1]  R951      -9.4544291496276855e-01
    z[2,1,1]  R952      6.6605281829833984e-01
    z[2,1,1]  R953      -1.5432612597942352e-01
    z[2,1,1]  R954      3.9257392287254333e-01
    z[2,1,1]  R955      0.361191064119339
    z[2,1,1]  R956      -5.7884609699249268e-01
    z[2,1,1]  R957      -3.0517965555191040e-01
    z[2,1,1]  R958      7.2201509028673172e-03
    z[2,1,1]  R959      -2.5021719932556152e-01
    z[2,1,1]  R960      -3.3093348145484924e-01
    z[2,1,1]  R961      -5.2963387966156006e-01
    z[2,1,1]  R962      -4.6676069498062134e-01
    z[2,1,1]  R963      -4.0153455734252930e-01
    z[2,1,1]  R964      -8.6335390806198120e-01
    z[2,1,1]  R965      -7.5709640979766846e-01
    z[2,1,1]  R966      -0.536909818649292
    z[2,1,1]  R967      -3.9367112517356873e-01
    z[2,1,1]  R968      -6.8513208627700806e-01
    z[2,1,1]  R969      -5.6272447109222412e-01
    z[2,1,1]  R970      1.3906291127204895e-01
    z[2,1,1]  R971      -8.3963996171951294e-01
    z[2,1,1]  R972      -3.7191800773143768e-02
    z[2,1,1]  R973      8.4010317921638489e-02
    z[2,1,1]  R974      -4.7721635550260544e-02
    z[2,1,1]  R975      -4.1309773921966553e-01
    z[2,1,1]  R976      6.1856579780578613e-01
    z[2,1,1]  R977      -0.745434045791626
    z[2,1,1]  R978      -1.3233341276645660e-01
    z[2,1,1]  R979      -7.6522946357727051e-01
    z[2,1,1]  R980      -2.7406048774719238e-01
    z[2,1,1]  R981      -0.157062828540802
    z[2,1,1]  R982      4.5490020513534546e-01
    z[2,1,1]  R983      0.120367631316185
    z[2,1,1]  R984      -2.3461724817752838e-01
    z[2,1,1]  R985      -5.3307074308395386e-01
    z[2,1,1]  R986      -4.9710500240325928e-01
    z[2,1,1]  R987      2.9275098443031311e-01
    z[2,1,1]  R988      3.2075801491737366e-01
    z[2,1,1]  R989      -6.2702691555023193e-01
    z[2,1,1]  R990      -2.8525643050670624e-02
    z[2,1,1]  R991      -3.5387694835662842e-01
    z[2,1,1]  R992      -2.1547524631023407e-01
    z[2,1,1]  R993      -3.0064329504966736e-01
    z[2,1,1]  R994      -4.3781730532646179e-01
    z[2,1,1]  R995      -4.3824225664138794e-01
    z[2,1,1]  R996      -4.5453169941902161e-01
    z[2,1,1]  R997      -1.2614880502223969e-01
    z[2,1,1]  R998      9.5038950443267822e-02
    z[2,1,1]  R999      1.1190351843833923e-01
    z[2,1,1]  R1000     -4.8688662052154541e-01
    z[2,1,1]  R1001     -4.1617318987846375e-01
    z[2,1,1]  R1002     -2.1365673840045929e-01
    z[2,1,1]  R1003     4.6142336726188660e-01
    z[2,1,1]  R1004     -3.1917089223861694e-01
    z[2,1,1]  R1005     -5.1795506477355957e-01
    z[2,1,1]  R1006     -2.7693209052085876e-01
    z[2,1,1]  R1007     -0.516141951084137
    z[2,1,1]  R1008     -8.5702389478683472e-01
    z[2,1,1]  R1009     -7.4201732873916626e-01
    z[2,1,1]  R1010     6.8862313032150269e-01
    z[2,1,1]  R1011     5.7169044017791748e-01
    z[2,1,1]  R1012     -3.4451025724411011e-01
    z[2,1,1]  R1013     -2.4015264213085175e-01
    z[2,1,1]  R1014     -0.594580352306366
    z[2,1,1]  R1015     -6.5241134166717529e-01
    z[2,1,1]  R1016     -2.0614735782146454e-01
    z[2,1,1]  R1017     -0.346598744392395
    z[2,1,1]  R1018     1.3930635154247284e-01
    z[2,1,1]  R1019     6.6393280029296875e-01
    z[2,1,1]  R1020     4.4265350699424744e-01
    z[2,1,1]  R1021     0.444812536239624
    z[2,1,1]  R1022     3.8442826271057129e-01
    z[2,1,1]  R1023     -2.6387885212898254e-01
    z[2,1,1]  R1024     3.1713566184043884e-01
    z[2,1,1]  R1025     -6.0303714126348495e-03
    z[2,1,1]  R1026     2.7103728055953979e-01
    z[2,1,1]  R1027     1.1794888228178024e-01
    z[2,1,1]  R1028     1.6418954730033875e-01
    z[2,1,1]  R1029     4.1713860630989075e-01
    z[2,1,1]  R1030     -6.7177355289459229e-01
    z[2,1,1]  R1031     -6.6847103834152222e-01
    z[2,1,1]  R1032     2.9807296395301819e-01
    z[2,1,1]  R1033     2.4385875463485718e-01
    z[2,1,1]  R1034     -3.8807126879692078e-01
    z[2,1,1]  R1035     3.3396932482719421e-01
    z[2,1,1]  R1036     3.5263964533805847e-01
    z[2,1,1]  R1037     2.4720968306064606e-01
    z[2,1,1]  R1038     -3.7510228157043457e-01
    z[2,1,1]  R1039     -5.7581549882888794e-01
    z[2,1,1]  R1040     1.4785762131214142e-01
    z[2,1,1]  R1041     -3.0817532539367676e-01
    z[2,1,1]  R1042     -2.1939820051193237e-01
    z[2,1,1]  R1043     1.9416160881519318e-01
    z[2,1,1]  R1044     4.9348825216293335e-01
    z[2,1,1]  R1045     -1.4357546344399452e-02
    z[2,1,1]  R1046     -7.9884245991706848e-02
    z[2,1,1]  R1047     1.5804682672023773e-01
    z[2,1,1]  R1048     1.9286023080348969e-01
    z[2,1,1]  R1049     6.6589933633804321e-01
    z[2,1,1]  R1050     -4.4424888491630554e-01
    z[2,1,1]  R1051     -4.4897049665451050e-02
    z[2,1,1]  R1052     4.5701089501380920e-01
    z[2,1,1]  R1053     6.6072843968868256e-02
    z[2,1,1]  R1054     -6.2168675661087036e-01
    z[2,1,1]  R1055     -7.2063046693801880e-01
    z[2,1,1]  R1056     -1.4998872578144073e-01
    z[2,1,1]  R1057     -2.9883316159248352e-01
    z[2,1,1]  R1058     -4.1531211137771606e-01
    z[2,1,1]  R1059     -3.4737905859947205e-01
    z[2,1,1]  R1060     -2.5700709223747253e-01
    z[2,1,1]  R1061     0.885625422000885
    z[2,1,1]  R1062     5.2399653196334839e-01
    z[2,1,1]  R1063     6.6193324327468872e-01
    z[2,1,1]  R1064     2.1502195298671722e-01
    z[2,1,1]  R1065     -3.4582906961441040e-01
    z[2,1,1]  R1066     -0.293354332447052
    z[2,1,1]  R1067     -5.0657910108566284e-01
    z[2,1,1]  R1068     -5.3950250148773193e-01
    z[2,1,1]  R1069     -1.9510462880134583e-01
    z[2,1,1]  R1070     -3.7244316935539246e-01
    z[2,1,1]  R1071     -1.6403743624687195e-01
    z[2,1,1]  R1072     -3.8011498749256134e-02
    z[2,1,1]  R1073     -2.4596635997295380e-01
    z[2,1,1]  R1074     -8.6322838068008423e-01
    z[2,1,1]  R1075     -9.1503816843032837e-01
    z[2,1,1]  R1076     -9.3509048223495483e-01
    z[2,1,1]  R1077     -8.8453543186187744e-01
    z[2,1,1]  R1078     -7.9997146129608154e-01
    z[2,1,1]  R1079     -7.4838405847549438e-01
    z[2,1,1]  R1080     -0.752017617225647
    z[2,1,1]  R1081     -7.7209919691085815e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R932      -1
    z[2,1,2]  R933      1
    z[2,1,2]  R942      -9.7293847799301147e-01
    z[2,1,2]  R943      -0.603140115737915
    z[2,1,2]  R944      0.538955569267273
    z[2,1,2]  R945      3.4552767872810364e-01
    z[2,1,2]  R946      4.6513897180557251e-01
    z[2,1,2]  R947      3.9125081896781921e-01
    z[2,1,2]  R948      0.631007969379425
    z[2,1,2]  R949      4.0838566422462463e-01
    z[2,1,2]  R950      2.9552167654037476e-01
    z[2,1,2]  R951      -7.1046546101570129e-02
    z[2,1,2]  R952      -2.2020098567008972e-01
    z[2,1,2]  R953      -3.8433471322059631e-01
    z[2,1,2]  R954      -6.2234717607498169e-01
    z[2,1,2]  R955      -2.7834331989288330e-01
    z[2,1,2]  R956      -3.2542139291763306e-01
    z[2,1,2]  R957      6.6539543867111206e-01
    z[2,1,2]  R958      7.9765558242797852e-01
    z[2,1,2]  R959      3.8779592514038086e-01
    z[2,1,2]  R960      5.2622526884078979e-01
    z[2,1,2]  R961      1.4367006719112396e-01
    z[2,1,2]  R962      -1.7414540052413940e-01
    z[2,1,2]  R963      6.0414743423461914e-01
    z[2,1,2]  R964      4.3512764573097229e-01
    z[2,1,2]  R965      1.7907401919364929e-01
    z[2,1,2]  R966      1.1400596052408218e-01
    z[2,1,2]  R967      0.640015721321106
    z[2,1,2]  R968      3.4429121017456055e-01
    z[2,1,2]  R969      5.1569050550460815e-01
    z[2,1,2]  R970      3.5431039333343506e-01
    z[2,1,2]  R971      -1.0312790423631668e-01
    z[2,1,2]  R972      -4.5585840940475464e-01
    z[2,1,2]  R973      -8.5497385263442993e-01
    z[2,1,2]  R974      -6.3647091388702393e-01
    z[2,1,2]  R975      -4.1328567266464233e-01
    z[2,1,2]  R976      -4.7504201531410217e-01
    z[2,1,2]  R977      0.516404390335083
    z[2,1,2]  R978      6.6580301523208618e-01
    z[2,1,2]  R979      4.2725303769111633e-01
    z[2,1,2]  R980      2.8814834356307983e-01
    z[2,1,2]  R981      7.9223197698593140e-01
    z[2,1,2]  R982      -5.8989274501800537e-01
    z[2,1,2]  R983      -0.674820601940155
    z[2,1,2]  R984      -1.7844487726688385e-01
    z[2,1,2]  R985      4.4019383192062378e-01
    z[2,1,2]  R986      2.5102981925010681e-01
    z[2,1,2]  R987      -2.7532413601875305e-01
    z[2,1,2]  R988      2.7033400535583496e-01
    z[2,1,2]  R989      -1.5471804141998291e-01
    z[2,1,2]  R990      8.2182055711746216e-01
    z[2,1,2]  R991      5.1102900505065918e-01
    z[2,1,2]  R992      -3.8311538100242615e-01
    z[2,1,2]  R993      0.812807559967041
    z[2,1,2]  R994      6.2336695194244385e-01
    z[2,1,2]  R995      3.4351414442062378e-01
    z[2,1,2]  R996      2.3672124743461609e-01
    z[2,1,2]  R997      6.7838686704635620e-01
    z[2,1,2]  R998      -2.6348397135734558e-01
    z[2,1,2]  R999      -2.3500017821788788e-01
    z[2,1,2]  R1000     -4.5101469755172729e-01
    z[2,1,2]  R1001     -5.6494605541229248e-01
    z[2,1,2]  R1002     1.8569216132164001e-01
    z[2,1,2]  R1003     -1.2094815820455551e-01
    z[2,1,2]  R1004     5.0320732593536377e-01
    z[2,1,2]  R1005     8.1830513477325439e-01
    z[2,1,2]  R1006     4.7848334908485413e-01
    z[2,1,2]  R1007     5.3767633438110352e-01
    z[2,1,2]  R1008     -1.4037846028804779e-01
    z[2,1,2]  R1009     -2.8815340995788574e-01
    z[2,1,2]  R1010     -2.9185838066041470e-03
    z[2,1,2]  R1011     7.4860163033008575e-02
    z[2,1,2]  R1012     -3.8576507568359375e-01
    z[2,1,2]  R1013     6.0245078802108765e-01
    z[2,1,2]  R1014     7.6126885414123535e-01
    z[2,1,2]  R1015     1.1741225421428680e-01
    z[2,1,2]  R1016     8.1855398416519165e-01
    z[2,1,2]  R1017     -3.4392636269330978e-02
    z[2,1,2]  R1018     1.3338804244995117e-01
    z[2,1,2]  R1019     -1.5795648097991943e-01
    z[2,1,2]  R1020     -1.1510962992906570e-01
    z[2,1,2]  R1021     5.6414250284433365e-02
    z[2,1,2]  R1022     4.0556451678276062e-01
    z[2,1,2]  R1023     5.7136386632919312e-01
    z[2,1,2]  R1024     6.8847596645355225e-01
    z[2,1,2]  R1025     2.0886674523353577e-01
    z[2,1,2]  R1026     -1.5248348005115986e-02
    z[2,1,2]  R1027     5.3124696016311646e-01
    z[2,1,2]  R1028     -2.1343810856342316e-01
    z[2,1,2]  R1029     -2.7728474140167236e-01
    z[2,1,2]  R1030     -1.0162437707185745e-01
    z[2,1,2]  R1031     -2.3174107074737549e-01
    z[2,1,2]  R1032     -1.1740779131650925e-01
    z[2,1,2]  R1033     -6.8835496902465820e-01
    z[2,1,2]  R1034     5.9588211774826050e-01
    z[2,1,2]  R1035     -6.0378080606460571e-01
    z[2,1,2]  R1036     -3.1660494208335876e-01
    z[2,1,2]  R1037     -4.0137115865945816e-02
    z[2,1,2]  R1038     2.5910025835037231e-01
    z[2,1,2]  R1039     4.1383656859397888e-01
    z[2,1,2]  R1040     -2.9499918222427368e-01
    z[2,1,2]  R1041     3.6738941073417664e-01
    z[2,1,2]  R1042     -1.9834670424461365e-01
    z[2,1,2]  R1043     -3.6132711917161942e-02
    z[2,1,2]  R1044     2.9677665233612061e-01
    z[2,1,2]  R1045     2.6175066828727722e-01
    z[2,1,2]  R1046     -1.4722524583339691e-01
    z[2,1,2]  R1047     -2.3189820349216461e-01
    z[2,1,2]  R1048     -7.4641996622085571e-01
    z[2,1,2]  R1049     -5.8503359556198120e-01
    z[2,1,2]  R1050     -1.5049757063388824e-01
    z[2,1,2]  R1051     4.7004982829093933e-02
    z[2,1,2]  R1052     -4.8428988456726074e-01
    z[2,1,2]  R1053     -2.0427714288234711e-01
    z[2,1,2]  R1054     1.7326584085822105e-02
    z[2,1,2]  R1055     -2.0517694950103760e-01
    z[2,1,2]  R1056     -6.6344380378723145e-02
    z[2,1,2]  R1057     1.9156554341316223e-01
    z[2,1,2]  R1058     0.0657258853316307
    z[2,1,2]  R1059     -4.1535636410117149e-03
    z[2,1,2]  R1060     -2.2964255511760712e-01
    z[2,1,2]  R1061     -1.2464547902345657e-01
    z[2,1,2]  R1062     -5.8535808324813843e-01
    z[2,1,2]  R1063     -2.8683599829673767e-01
    z[2,1,2]  R1064     -4.8880372196435928e-02
    z[2,1,2]  R1065     -2.0156674087047577e-01
    z[2,1,2]  R1066     -2.2471249103546143e-01
    z[2,1,2]  R1067     -3.3468988537788391e-01
    z[2,1,2]  R1068     1.8343251943588257e-01
    z[2,1,2]  R1069     -2.5035008788108826e-01
    z[2,1,2]  R1070     2.0671902596950531e-01
    z[2,1,2]  R1071     -0.0722411647439003
    z[2,1,2]  R1072     -5.3254854679107666e-01
    z[2,1,2]  R1073     -1.6451023519039154e-01
    z[2,1,2]  R1074     1.6175574064254761e-01
    z[2,1,2]  R1075     0.000609697075560689
    z[2,1,2]  R1076     -5.0387654453516006e-02
    z[2,1,2]  R1077     2.9645591974258423e-01
    z[2,1,2]  R1078     -3.1568646430969238e-01
    z[2,1,2]  R1079     3.7175349891185760e-02
    z[2,1,2]  R1080     3.4580063819885254e-01
    z[2,1,2]  R1081     1.1843249201774597e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R934      -1
    z[2,1,3]  R935      1
    z[2,1,3]  R942      -8.8208511471748352e-02
    z[2,1,3]  R943      -4.7521755099296570e-01
    z[2,1,3]  R944      -3.1744179129600525e-01
    z[2,1,3]  R945      -2.5882029533386230e-01
    z[2,1,3]  R946      1.6882614791393280e-01
    z[2,1,3]  R947      -1.2544415891170502e-01
    z[2,1,3]  R948      -3.3502653241157532e-01
    z[2,1,3]  R949      1.2970754504203796e-01
    z[2,1,3]  R950      2.1457606554031372e-01
    z[2,1,3]  R951      -5.3176287561655045e-02
    z[2,1,3]  R952      -3.4870305657386780e-01
    z[2,1,3]  R953      -3.8045141100883484e-01
    z[2,1,3]  R954      -2.4736273288726807e-01
    z[2,1,3]  R955      -5.5625128746032715e-01
    z[2,1,3]  R956      -6.0599648952484131e-01
    z[2,1,3]  R957      -6.9442704319953918e-02
    z[2,1,3]  R958      3.6038818955421448e-01
    z[2,1,3]  R959      0.411622554063797
    z[2,1,3]  R960      -2.1343001723289490e-01
    z[2,1,3]  R961      5.3617221117019653e-01
    z[2,1,3]  R962      -1.0586037300527096e-02
    z[2,1,3]  R963      -0.266049325466156
    z[2,1,3]  R964      0.000654847186524421
    z[2,1,3]  R965      1.8572027981281281e-01
    z[2,1,3]  R966      6.1764854937791824e-02
    z[2,1,3]  R967      -2.6875153183937073e-01
    z[2,1,3]  R968      -3.9000564813613892e-01
    z[2,1,3]  R969      0.418507844209671
    z[2,1,3]  R970      -1.8928614258766174e-01
    z[2,1,3]  R971      -1.2874467670917511e-01
    z[2,1,3]  R972      -4.7685131430625916e-01
    z[2,1,3]  R973      -1.7664164304733276e-01
    z[2,1,3]  R974      -4.7321975231170654e-02
    z[2,1,3]  R975      -1.9970078021287918e-02
    z[2,1,3]  R976      -2.7834182977676392e-01
    z[2,1,3]  R977      1.3912315666675568e-01
    z[2,1,3]  R978      4.6573978662490845e-01
    z[2,1,3]  R979      -2.5322949886322021e-01
    z[2,1,3]  R980      -6.7431682348251343e-01
    z[2,1,3]  R981      1.8873554468154907e-01
    z[2,1,3]  R982      -5.1140058785676956e-02
    z[2,1,3]  R983      -6.1911731958389282e-01
    z[2,1,3]  R984      -1.6849631071090698e-01
    z[2,1,3]  R985      -1.8016840517520905e-01
    z[2,1,3]  R986      1.9928215444087982e-01
    z[2,1,3]  R987      1.0604322701692581e-01
    z[2,1,3]  R988      -1.2245579808950424e-01
    z[2,1,3]  R989      -1.8359085917472839e-01
    z[2,1,3]  R990      9.3848649412393570e-03
    z[2,1,3]  R991      3.6554974317550659e-01
    z[2,1,3]  R992      -1.3364183902740479e-01
    z[2,1,3]  R993      2.7470090985298157e-01
    z[2,1,3]  R994      2.1028025448322296e-01
    z[2,1,3]  R995      -2.8887799382209778e-01
    z[2,1,3]  R996      3.1354019045829773e-01
    z[2,1,3]  R997      -3.2518345117568970e-01
    z[2,1,3]  R998      6.3137114048004150e-01
    z[2,1,3]  R999      6.0915040969848633e-01
    z[2,1,3]  R1000     -1.0930795967578888e-01
    z[2,1,3]  R1001     9.4762936234474182e-02
    z[2,1,3]  R1002     0.0528901144862175
    z[2,1,3]  R1003     -2.2071680426597595e-01
    z[2,1,3]  R1004     2.7505340054631233e-02
    z[2,1,3]  R1005     -5.4072678089141846e-02
    z[2,1,3]  R1006     -0.508666455745697
    z[2,1,3]  R1007     1.5174891054630280e-01
    z[2,1,3]  R1008     1.5501870773732662e-02
    z[2,1,3]  R1009     -1.4099037647247314e-01
    z[2,1,3]  R1010     5.5263692140579224e-01
    z[2,1,3]  R1011     1.0978803038597107e-01
    z[2,1,3]  R1012     -5.9805382043123245e-02
    z[2,1,3]  R1013     -3.5006541013717651e-01
    z[2,1,3]  R1014     1.3073551654815674e-01
    z[2,1,3]  R1015     -6.5448500216007233e-02
    z[2,1,3]  R1016     1.7718425393104553e-01
    z[2,1,3]  R1017     4.4877770543098450e-01
    z[2,1,3]  R1018     5.1594823598861694e-01
    z[2,1,3]  R1019     1.2030216306447983e-01
    z[2,1,3]  R1020     3.7173676490783691e-01
    z[2,1,3]  R1021     1.4595986902713776e-01
    z[2,1,3]  R1022     3.9904925227165222e-01
    z[2,1,3]  R1023     -4.4947284460067749e-01
    z[2,1,3]  R1024     -2.5990280508995056e-01
    z[2,1,3]  R1025     -3.9733633399009705e-01
    z[2,1,3]  R1026     -2.7447342872619629e-01
    z[2,1,3]  R1027     -5.7482278347015381e-01
    z[2,1,3]  R1028     -6.4267545938491821e-01
    z[2,1,3]  R1029     -2.6924726553261280e-03
    z[2,1,3]  R1030     -4.3043103814125061e-01
    z[2,1,3]  R1031     -5.6083846092224121e-01
    z[2,1,3]  R1032     -4.9707889556884766e-03
    z[2,1,3]  R1033     5.6251049041748047e-01
    z[2,1,3]  R1034     4.5717990398406982e-01
    z[2,1,3]  R1035     5.6790667772293091e-01
    z[2,1,3]  R1036     6.6686850786209106e-01
    z[2,1,3]  R1037     4.8297506570816040e-01
    z[2,1,3]  R1038     4.2766058444976807e-01
    z[2,1,3]  R1039     2.0888186991214752e-01
    z[2,1,3]  R1040     2.5776371359825134e-01
    z[2,1,3]  R1041     2.2306315600872040e-01
    z[2,1,3]  R1042     -1.1081153899431229e-01
    z[2,1,3]  R1043     -0.454868882894516
    z[2,1,3]  R1044     -4.9220845103263855e-01
    z[2,1,3]  R1045     0.456521600484848
    z[2,1,3]  R1046     0.0790027603507042
    z[2,1,3]  R1047     5.3736311197280884e-01
    z[2,1,3]  R1048     1.2507483363151550e-01
    z[2,1,3]  R1049     3.1046831607818604e-01
    z[2,1,3]  R1050     -4.5002856850624084e-01
    z[2,1,3]  R1051     -7.8516000509262085e-01
    z[2,1,3]  R1052     -0.120479054749012
    z[2,1,3]  R1053     8.1015847623348236e-02
    z[2,1,3]  R1054     -5.2535998821258545e-01
    z[2,1,3]  R1055     -4.3817153573036194e-01
    z[2,1,3]  R1056     -7.7117341756820679e-01
    z[2,1,3]  R1057     -6.7462337017059326e-01
    z[2,1,3]  R1058     -3.9227211475372314e-01
    z[2,1,3]  R1059     -6.4566022157669067e-01
    z[2,1,3]  R1060     -8.5562658309936523e-01
    z[2,1,3]  R1061     9.8151132464408875e-02
    z[2,1,3]  R1062     3.6296206712722778e-01
    z[2,1,3]  R1063     1.9905048608779907e-01
    z[2,1,3]  R1064     1.3431535661220551e-01
    z[2,1,3]  R1065     -6.5590482950210571e-01
    z[2,1,3]  R1066     -7.0590674877166748e-01
    z[2,1,3]  R1067     -4.9436318874359131e-01
    z[2,1,3]  R1068     -7.5713771581649780e-01
    z[2,1,3]  R1069     -8.6876374483108521e-01
    z[2,1,3]  R1070     -5.4235792160034180e-01
    z[2,1,3]  R1071     -6.7413049936294556e-01
    z[2,1,3]  R1072     8.8837943971157074e-02
    z[2,1,3]  R1073     -7.3519039154052734e-01
    z[2,1,3]  R1074     -1.9255171716213226e-01
    z[2,1,3]  R1075     1.3584984838962555e-01
    z[2,1,3]  R1076     2.1812172234058380e-01
    z[2,1,3]  R1077     9.1849960386753082e-02
    z[2,1,3]  R1078     1.8861801922321320e-01
    z[2,1,3]  R1079     -2.7884244918823242e-01
    z[2,1,3]  R1080     1.2510600499808788e-02
    z[2,1,3]  R1081     -2.7186835184693336e-02
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R936      -1
    z[2,1,4]  R937      1
    z[2,1,4]  R942      -6.8349972367286682e-02
    z[2,1,4]  R943      6.0959316790103912e-02
    z[2,1,4]  R944      2.9346242547035217e-01
    z[2,1,4]  R945      8.8077321648597717e-02
    z[2,1,4]  R946      9.8922697361558676e-04
    z[2,1,4]  R947      -3.4094041585922241e-01
    z[2,1,4]  R948      1.2515866756439209e-01
    z[2,1,4]  R949      -1.7869557440280914e-01
    z[2,1,4]  R950      1.4933820068836212e-01
    z[2,1,4]  R951      -8.8455349206924438e-02
    z[2,1,4]  R952      2.0481154322624207e-01
    z[2,1,4]  R953      1.1627225577831268e-01
    z[2,1,4]  R954      -1.8047428131103516e-01
    z[2,1,4]  R955      4.3158102035522461e-01
    z[2,1,4]  R956      8.9279748499393463e-02
    z[2,1,4]  R957      4.7327745705842972e-02
    z[2,1,4]  R958      -1.3478185236454010e-01
    z[2,1,4]  R959      9.2412687838077545e-02
    z[2,1,4]  R960      2.3024432361125946e-01
    z[2,1,4]  R961      -4.7474950551986694e-01
    z[2,1,4]  R962      3.2538694143295288e-01
    z[2,1,4]  R963      6.5021462738513947e-02
    z[2,1,4]  R964      -1.3610567152500153e-01
    z[2,1,4]  R965      -4.4518828392028809e-02
    z[2,1,4]  R966      1.2379807233810425e-01
    z[2,1,4]  R967      4.1480544209480286e-01
    z[2,1,4]  R968      3.1806635856628418e-01
    z[2,1,4]  R969      -2.6723667979240417e-01
    z[2,1,4]  R970      0.335847407579422
    z[2,1,4]  R971      -5.1931455731391907e-02
    z[2,1,4]  R972      5.0190949440002441e-01
    z[2,1,4]  R973      2.3953368887305260e-02
    z[2,1,4]  R974      -3.0785033106803894e-01
    z[2,1,4]  R975      2.9963433742523193e-01
    z[2,1,4]  R976      2.2519567608833313e-01
    z[2,1,4]  R977      -4.9410410225391388e-02
    z[2,1,4]  R978      -3.4072495996952057e-02
    z[2,1,4]  R979      2.7562731504440308e-01
    z[2,1,4]  R980      5.3666192293167114e-01
    z[2,1,4]  R981      -1.4008262753486633e-01
    z[2,1,4]  R982      5.3228306770324707e-01
    z[2,1,4]  R983      3.5014921426773071e-01
    z[2,1,4]  R984      -2.6225471496582031e-01
    z[2,1,4]  R985      2.9552286863327026e-01
    z[2,1,4]  R986      4.7938823699951172e-02
    z[2,1,4]  R987      -1.8676073849201202e-01
    z[2,1,4]  R988      -2.2156653925776482e-02
    z[2,1,4]  R989      1.5780363464727998e-03
    z[2,1,4]  R990      -3.1281030178070068e-01
    z[2,1,4]  R991      -3.3786624670028687e-01
    z[2,1,4]  R992      -9.9446296691894531e-02
    z[2,1,4]  R993      -3.9691093564033508e-01
    z[2,1,4]  R994      -2.2341039776802063e-01
    z[2,1,4]  R995      -1.5150465071201324e-01
    z[2,1,4]  R996      -2.4573905766010284e-01
    z[2,1,4]  R997      -2.2003591060638428e-01
    z[2,1,4]  R998      -4.6767142415046692e-01
    z[2,1,4]  R999      -0.273552268743515
    z[2,1,4]  R1000     1.2600430846214294e-01
    z[2,1,4]  R1001     -1.2882158160209656e-01
    z[2,1,4]  R1002     2.3652262985706329e-01
    z[2,1,4]  R1003     3.1723294407129288e-02
    z[2,1,4]  R1004     -2.9491975903511047e-02
    z[2,1,4]  R1005     1.5443550050258636e-01
    z[2,1,4]  R1006     -4.2121908068656921e-01
    z[2,1,4]  R1007     1.8458089232444763e-01
    z[2,1,4]  R1008     1.7301696538925171e-01
    z[2,1,4]  R1009     7.5182333588600159e-02
    z[2,1,4]  R1010     -2.9577374458312988e-01
    z[2,1,4]  R1011     3.4480038285255432e-01
    z[2,1,4]  R1012     1.5085572004318237e-01
    z[2,1,4]  R1013     -1.7213378846645355e-01
    z[2,1,4]  R1014     -2.7899801731109619e-02
    z[2,1,4]  R1015     1.2818282842636108e-01
    z[2,1,4]  R1016     2.9733744263648987e-01
    z[2,1,4]  R1017     -5.7709133625030518e-01
    z[2,1,4]  R1018     -6.4456969499588013e-01
    z[2,1,4]  R1019     -4.7712764143943787e-01
    z[2,1,4]  R1020     -2.0363937318325043e-01
    z[2,1,4]  R1021     -2.2551403380930424e-03
    z[2,1,4]  R1022     -3.1760153174400330e-01
    z[2,1,4]  R1023     1.2788502871990204e-01
    z[2,1,4]  R1024     -4.5941525697708130e-01
    z[2,1,4]  R1025     -4.5679351687431335e-01
    z[2,1,4]  R1026     -6.8453729152679443e-01
    z[2,1,4]  R1027     -2.0277164876461029e-02
    z[2,1,4]  R1028     5.1528328657150269e-01
    z[2,1,4]  R1029     5.8601063489913940e-01
    z[2,1,4]  R1030     3.4970134496688843e-01
    z[2,1,4]  R1031     2.0519576966762543e-01
    z[2,1,4]  R1032     -2.5997087359428406e-02
    z[2,1,4]  R1033     -3.1932753324508667e-01
    z[2,1,4]  R1034     -2.0619036257266998e-01
    z[2,1,4]  R1035     2.2363530471920967e-02
    z[2,1,4]  R1036     2.4442672729492188e-02
    z[2,1,4]  R1037     -2.2545643150806427e-01
    z[2,1,4]  R1038     -2.4691025912761688e-01
    z[2,1,4]  R1039     -1.8389484286308289e-01
    z[2,1,4]  R1040     6.4173959195613861e-02
    z[2,1,4]  R1041     -4.2985841631889343e-01
    z[2,1,4]  R1042     2.8474089503288269e-01
    z[2,1,4]  R1043     -1.8321696668863297e-02
    z[2,1,4]  R1044     1.2423494458198547e-01
    z[2,1,4]  R1045     -0.0837835893034935
    z[2,1,4]  R1046     -4.8522930592298508e-02
    z[2,1,4]  R1047     -2.8666019439697266e-01
    z[2,1,4]  R1048     -2.0664894580841064e-01
    z[2,1,4]  R1049     -3.7180971354246140e-02
    z[2,1,4]  R1050     -9.1457515954971313e-02
    z[2,1,4]  R1051     -8.6750283837318420e-02
    z[2,1,4]  R1052     1.3383789360523224e-01
    z[2,1,4]  R1053     -6.1846762895584106e-01
    z[2,1,4]  R1054     -9.6565060317516327e-02
    z[2,1,4]  R1055     -3.8908189535140991e-01
    z[2,1,4]  R1056     -1.9357408583164215e-01
    z[2,1,4]  R1057     -1.5970006585121155e-01
    z[2,1,4]  R1058     -3.8437676429748535e-01
    z[2,1,4]  R1059     -4.9526163935661316e-01
    z[2,1,4]  R1060     2.0835416018962860e-01
    z[2,1,4]  R1061     -2.9163017868995667e-01
    z[2,1,4]  R1062     0.0585007481276989
    z[2,1,4]  R1063     2.9259911179542542e-01
    z[2,1,4]  R1064     -6.8360525369644165e-01
    z[2,1,4]  R1065     -0.242141455411911
    z[2,1,4]  R1066     -2.4339766800403595e-01
    z[2,1,4]  R1067     -1.4195046387612820e-02
    z[2,1,4]  R1068     -0.0697336345911026
    z[2,1,4]  R1069     -7.0744507014751434e-02
    z[2,1,4]  R1070     -1.7798207700252533e-01
    z[2,1,4]  R1071     -3.3123213797807693e-03
    z[2,1,4]  R1072     -2.9495945572853088e-01
    z[2,1,4]  R1073     9.0996541082859039e-02
    z[2,1,4]  R1074     -2.4021466076374054e-01
    z[2,1,4]  R1075     -1.0266276448965073e-01
    z[2,1,4]  R1076     -1.9709125161170959e-01
    z[2,1,4]  R1077     1.9474083185195923e-01
    z[2,1,4]  R1078     -1.4570684731006622e-01
    z[2,1,4]  R1079     7.8483283519744873e-02
    z[2,1,4]  R1080     5.5651620030403137e-02
    z[2,1,4]  R1081     2.9908114671707153e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R938      -1
    z[2,1,5]  R939      1
    z[2,1,5]  R942      -8.1709325313568115e-02
    z[2,1,5]  R943      -5.7853251695632935e-01
    z[2,1,5]  R944      2.4344623088836670e-02
    z[2,1,5]  R945      -9.7902357578277588e-02
    z[2,1,5]  R946      -1.1295893043279648e-01
    z[2,1,5]  R947      -1.3188610784709454e-02
    z[2,1,5]  R948      -4.7790925949811935e-02
    z[2,1,5]  R949      -1.4583942294120789e-01
    z[2,1,5]  R950      -0.0196728203445673
    z[2,1,5]  R951      -8.7292753159999847e-02
    z[2,1,5]  R952      1.9400827586650848e-01
    z[2,1,5]  R953      1.9348324835300446e-01
    z[2,1,5]  R954      -2.4957165122032166e-01
    z[2,1,5]  R955      2.1434809267520905e-01
    z[2,1,5]  R956      1.7687307298183441e-01
    z[2,1,5]  R957      0.0924796313047409
    z[2,1,5]  R958      2.7627438306808472e-01
    z[2,1,5]  R959      3.8378086686134338e-01
    z[2,1,5]  R960      5.0076556205749512e-01
    z[2,1,5]  R961      3.6635959148406982e-01
    z[2,1,5]  R962      -0.655155599117279
    z[2,1,5]  R963      2.6621329784393311e-01
    z[2,1,5]  R964      -0.0172334685921669
    z[2,1,5]  R965      0.386877179145813
    z[2,1,5]  R966      6.8370831012725830e-01
    z[2,1,5]  R967      4.0803152322769165e-01
    z[2,1,5]  R968      0.0565381720662117
    z[2,1,5]  R969      0.100244902074337
    z[2,1,5]  R970      -3.4102091193199158e-01
    z[2,1,5]  R971      2.6719495654106140e-01
    z[2,1,5]  R972      -2.7230077981948853e-01
    z[2,1,5]  R973      6.2127064913511276e-02
    z[2,1,5]  R974      9.1365143656730652e-02
    z[2,1,5]  R975      -4.5349341630935669e-01
    z[2,1,5]  R976      -2.9470628499984741e-01
    z[2,1,5]  R977      2.8922820091247559e-01
    z[2,1,5]  R978      5.0339066982269287e-01
    z[2,1,5]  R979      -1.0987876914441586e-02
    z[2,1,5]  R980      -2.1653366088867188e-01
    z[2,1,5]  R981      -2.0477293431758881e-01
    z[2,1,5]  R982      -5.5073618888854980e-02
    z[2,1,5]  R983      0.151590496301651
    z[2,1,5]  R984      4.6486937999725342e-01
    z[2,1,5]  R985      6.2038439512252808e-01
    z[2,1,5]  R986      6.5783679485321045e-01
    z[2,1,5]  R987      4.6448069810867310e-01
    z[2,1,5]  R988      -2.0570924878120422e-01
    z[2,1,5]  R989      7.2977238893508911e-01
    z[2,1,5]  R990      2.4681676924228668e-01
    z[2,1,5]  R991      1.1680758744478226e-01
    z[2,1,5]  R992      4.2079731822013855e-01
    z[2,1,5]  R993      9.8230935633182526e-02
    z[2,1,5]  R994      3.7939116358757019e-01
    z[2,1,5]  R995      5.3273308277130127e-01
    z[2,1,5]  R996      3.8930308818817139e-01
    z[2,1,5]  R997      3.5388889908790588e-01
    z[2,1,5]  R998      -2.1736070513725281e-01
    z[2,1,5]  R999      1.3541743159294128e-01
    z[2,1,5]  R1000     -2.4555966258049011e-01
    z[2,1,5]  R1001     2.1628174930810928e-02
    z[2,1,5]  R1002     -0.213386669754982
    z[2,1,5]  R1003     6.2998242676258087e-02
    z[2,1,5]  R1004     4.8398381471633911e-01
    z[2,1,5]  R1005     9.2903882265090942e-02
    z[2,1,5]  R1006     4.3472254276275635e-01
    z[2,1,5]  R1007     1.5766884386539459e-01
    z[2,1,5]  R1008     -2.6922854781150818e-01
    z[2,1,5]  R1009     -2.9883456230163574e-01
    z[2,1,5]  R1010     3.1535025686025620e-02
    z[2,1,5]  R1011     -1.9695109128952026e-01
    z[2,1,5]  R1012     -2.9514765739440918e-01
    z[2,1,5]  R1013     5.9990507364273071e-01
    z[2,1,5]  R1014     -3.3689178526401520e-02
    z[2,1,5]  R1015     2.7362295985221863e-01
    z[2,1,5]  R1016     8.9038470759987831e-03
    z[2,1,5]  R1017     -0.312675416469574
    z[2,1,5]  R1018     9.4866394996643066e-02
    z[2,1,5]  R1019     -1.6696314513683319e-01
    z[2,1,5]  R1020     -4.4190770387649536e-01
    z[2,1,5]  R1021     -7.9289132356643677e-01
    z[2,1,5]  R1022     -3.3961209654808044e-01
    z[2,1,5]  R1023     1.8544797599315643e-01
    z[2,1,5]  R1024     1.1440439522266388e-01
    z[2,1,5]  R1025     6.5428024530410767e-01
    z[2,1,5]  R1026     4.4936504960060120e-01
    z[2,1,5]  R1027     -3.0648830533027649e-01
    z[2,1,5]  R1028     1.1762021481990814e-01
    z[2,1,5]  R1029     -2.5380519032478333e-01
    z[2,1,5]  R1030     -3.1958609819412231e-01
    z[2,1,5]  R1031     -8.4092825651168823e-02
    z[2,1,5]  R1032     -1.1361759155988693e-01
    z[2,1,5]  R1033     4.4120015809312463e-04
    z[2,1,5]  R1034     -2.7406115084886551e-02
    z[2,1,5]  R1035     1.1172773083671927e-03
    z[2,1,5]  R1036     -9.8782189190387726e-02
    z[2,1,5]  R1037     -2.7341619133949280e-01
    z[2,1,5]  R1038     1.3734828680753708e-02
    z[2,1,5]  R1039     -2.1597044542431831e-02
    z[2,1,5]  R1040     1.3793526589870453e-01
    z[2,1,5]  R1041     0.0759831964969635
    z[2,1,5]  R1042     4.6145290136337280e-02
    z[2,1,5]  R1043     3.8462081551551819e-01
    z[2,1,5]  R1044     0.309256374835968
    z[2,1,5]  R1045     -1.5847636759281158e-01
    z[2,1,5]  R1046     5.0776267051696777e-01
    z[2,1,5]  R1047     2.5914970040321350e-01
    z[2,1,5]  R1048     7.1749143302440643e-02
    z[2,1,5]  R1049     -3.7542516365647316e-03
    z[2,1,5]  R1050     -2.2628861665725708e-01
    z[2,1,5]  R1051     -1.9060148298740387e-01
    z[2,1,5]  R1052     -3.3287471532821655e-01
    z[2,1,5]  R1053     -9.2252299189567566e-02
    z[2,1,5]  R1054     -5.5725795030593872e-01
    z[2,1,5]  R1055     -2.5712516903877258e-01
    z[2,1,5]  R1056     -5.5599504709243774e-01
    z[2,1,5]  R1057     -5.6729829311370850e-01
    z[2,1,5]  R1058     -4.8965570330619812e-01
    z[2,1,5]  R1059     -2.9055011272430420e-01
    z[2,1,5]  R1060     1.7456176877021790e-01
    z[2,1,5]  R1061     2.8850591182708740e-01
    z[2,1,5]  R1062     -2.4103295058012009e-02
    z[2,1,5]  R1063     -6.2595404684543610e-02
    z[2,1,5]  R1064     -7.4984863400459290e-02
    z[2,1,5]  R1065     -1.5337084233760834e-01
    z[2,1,5]  R1066     -5.4406648874282837e-01
    z[2,1,5]  R1067     -5.2214270830154419e-01
    z[2,1,5]  R1068     7.0977574214339256e-03
    z[2,1,5]  R1069     5.4667755961418152e-02
    z[2,1,5]  R1070     -5.1970493793487549e-01
    z[2,1,5]  R1071     -6.0246225446462631e-02
    z[2,1,5]  R1072     3.3154781907796860e-02
    z[2,1,5]  R1073     -5.5117465555667877e-02
    z[2,1,5]  R1074     1.1985098570585251e-01
    z[2,1,5]  R1075     1.4734235405921936e-01
    z[2,1,5]  R1076     -3.7574142217636108e-02
    z[2,1,5]  R1077     -1.2454599142074585e-01
    z[2,1,5]  R1078     8.0336481332778931e-02
    z[2,1,5]  R1079     3.3352074027061462e-01
    z[2,1,5]  R1080     0.199890598654747
    z[2,1,5]  R1081     4.5918133109807968e-03
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R940      -1
    z[2,1,6]  R941      1
    z[2,1,6]  R942      6.7505091428756714e-02
    z[2,1,6]  R943      2.2287836670875549e-01
    z[2,1,6]  R944      -2.2092872858047485e-01
    z[2,1,6]  R945      -3.8008540868759155e-01
    z[2,1,6]  R946      -2.3824036121368408e-01
    z[2,1,6]  R947      -4.5026361942291260e-01
    z[2,1,6]  R948      -5.8528423309326172e-01
    z[2,1,6]  R949      -3.8883182406425476e-01
    z[2,1,6]  R950      7.0273093879222870e-02
    z[2,1,6]  R951      1.1326502077281475e-02
    z[2,1,6]  R952      4.8504152894020081e-01
    z[2,1,6]  R953      -6.7624074220657349e-01
    z[2,1,6]  R954      -0.0548379123210907
    z[2,1,6]  R955      -3.8653293251991272e-01
    z[2,1,6]  R956      2.7660849690437317e-01
    z[2,1,6]  R957      0.660368800163269
    z[2,1,6]  R958      3.5540419816970825e-01
    z[2,1,6]  R959      -3.1410497426986694e-01
    z[2,1,6]  R960      -3.4020674228668213e-01
    z[2,1,6]  R961      1.0890915989875793e-01
    z[2,1,6]  R962      -5.5048700422048569e-02
    z[2,1,6]  R963      3.8220253586769104e-01
    z[2,1,6]  R964      1.9806094467639923e-01
    z[2,1,6]  R965      -3.2253879308700562e-01
    z[2,1,6]  R966      -1.0856601595878601e-01
    z[2,1,6]  R967      1.3984479010105133e-01
    z[2,1,6]  R968      3.5530152916908264e-01
    z[2,1,6]  R969      3.1432738900184631e-01
    z[2,1,6]  R970      -6.4855682849884033e-01
    z[2,1,6]  R971      -4.3666839599609375e-01
    z[2,1,6]  R972      4.8712867498397827e-01
    z[2,1,6]  R973      4.7566527128219604e-01
    z[2,1,6]  R974      5.2784645557403564e-01
    z[2,1,6]  R975      4.8449450731277466e-01
    z[2,1,6]  R976      -3.9211180806159973e-01
    z[2,1,6]  R977      1.8672230839729309e-01
    z[2,1,6]  R978      -0.120102658867836
    z[2,1,6]  R979      1.8224196135997772e-01
    z[2,1,6]  R980      -1.5171281993389130e-02
    z[2,1,6]  R981      -4.6104211360216141e-02
    z[2,1,6]  R982      -9.4352580606937408e-02
    z[2,1,6]  R983      -3.1050495803356171e-02
    z[2,1,6]  R984      -2.1376334130764008e-01
    z[2,1,6]  R985      -1.7244471237063408e-02
    z[2,1,6]  R986      -1.3816219754517078e-02
    z[2,1,6]  R987      -5.5287098884582520e-01
    z[2,1,6]  R988      -3.3973211050033569e-01
    z[2,1,6]  R989      9.6057079732418060e-02
    z[2,1,6]  R990      3.9783695340156555e-01
    z[2,1,6]  R991      -0.396820992231369
    z[2,1,6]  R992      9.2072226107120514e-02
    z[2,1,6]  R993      6.0303029604256153e-03
    z[2,1,6]  R994      -7.7498771250247955e-02
    z[2,1,6]  R995      5.4637116193771362e-01
    z[2,1,6]  R996      -6.2113553285598755e-01
    z[2,1,6]  R997      -4.7485873103141785e-01
    z[2,1,6]  R998      -4.7389128804206848e-01
    z[2,1,6]  R999      -3.2400522381067276e-02
    z[2,1,6]  R1000     -4.5558240264654160e-02
    z[2,1,6]  R1001     1.7671963572502136e-01
    z[2,1,6]  R1002     -2.6876670122146606e-01
    z[2,1,6]  R1003     -4.5331677794456482e-01
    z[2,1,6]  R1004     -6.3738840818405151e-01
    z[2,1,6]  R1005     6.1344724148511887e-02
    z[2,1,6]  R1006     -1.4742341637611389e-01
    z[2,1,6]  R1007     -5.5559659004211426e-01
    z[2,1,6]  R1008     -2.8658014535903931e-01
    z[2,1,6]  R1009     -2.7599132061004639e-01
    z[2,1,6]  R1010     3.0139073729515076e-01
    z[2,1,6]  R1011     1.9801907241344452e-01
    z[2,1,6]  R1012     -4.1881343722343445e-01
    z[2,1,6]  R1013     -1.2827715277671814e-01
    z[2,1,6]  R1014     -1.3251449167728424e-01
    z[2,1,6]  R1015     -6.8024778366088867e-01
    z[2,1,6]  R1016     -3.2817268371582031e-01
    z[2,1,6]  R1017     0.483521431684494
    z[2,1,6]  R1018     3.1587496399879456e-01
    z[2,1,6]  R1019     2.1890194714069366e-01
    z[2,1,6]  R1020     4.9500128626823425e-01
    z[2,1,6]  R1021     3.1799605488777161e-01
    z[2,1,6]  R1022     1.0709770768880844e-01
    z[2,1,6]  R1023     -2.4973434209823608e-01
    z[2,1,6]  R1024     1.0766394436359406e-01
    z[2,1,6]  R1025     -1.2142031639814377e-01
    z[2,1,6]  R1026     2.6148018240928650e-01
    z[2,1,6]  R1027     4.3953621387481689e-01
    z[2,1,6]  R1028     -7.3536694981157780e-03
    z[2,1,6]  R1029     -9.8360069096088409e-02
    z[2,1,6]  R1030     2.5545188784599304e-01
    z[2,1,6]  R1031     3.6544266343116760e-01
    z[2,1,6]  R1032     2.3569293320178986e-01
    z[2,1,6]  R1033     1.7103728652000427e-01
    z[2,1,6]  R1034     -1.4125512540340424e-01
    z[2,1,6]  R1035     -1.0065762698650360e-01
    z[2,1,6]  R1036     -1.8577769398689270e-01
    z[2,1,6]  R1037     1.7328223586082458e-01
    z[2,1,6]  R1038     -1.8665000796318054e-01
    z[2,1,6]  R1039     -1.3384471833705902e-01
    z[2,1,6]  R1040     -1.6737556457519531e-01
    z[2,1,6]  R1041     -1.9298050552606583e-02
    z[2,1,6]  R1042     -1.5526151657104492e-01
    z[2,1,6]  R1043     -7.1109756827354431e-02
    z[2,1,6]  R1044     -1.9608356058597565e-01
    z[2,1,6]  R1045     -2.3779530823230743e-01
    z[2,1,6]  R1046     -4.6682038903236389e-01
    z[2,1,6]  R1047     -3.0959886312484741e-01
    z[2,1,6]  R1048     2.9122793674468994e-01
    z[2,1,6]  R1049     1.1080313473939896e-01
    z[2,1,6]  R1050     -6.8453967571258545e-01
    z[2,1,6]  R1051     -4.1320380568504333e-01
    z[2,1,6]  R1052     4.7924613952636719e-01
    z[2,1,6]  R1053     5.4809981584548950e-01
    z[2,1,6]  R1054     -1.1365757137537003e-01
    z[2,1,6]  R1055     -1.4261193573474884e-01
    z[2,1,6]  R1056     -7.7522225677967072e-02
    z[2,1,6]  R1057     -1.8059577047824860e-01
    z[2,1,6]  R1058     -7.2199523448944092e-02
    z[2,1,6]  R1059     1.6902619600296021e-01
    z[2,1,6]  R1060     -2.3229663074016571e-01
    z[2,1,6]  R1061     -2.8217615559697151e-02
    z[2,1,6]  R1062     -2.4007629603147507e-02
    z[2,1,6]  R1063     -1.7738421261310577e-01
    z[2,1,6]  R1064     4.8832595348358154e-01
    z[2,1,6]  R1065     -2.4512539803981781e-01
    z[2,1,6]  R1066     -8.6079455912113190e-02
    z[2,1,6]  R1067     -3.3156612515449524e-01
    z[2,1,6]  R1068     2.8960786759853363e-02
    z[2,1,6]  R1069     -2.5481003522872925e-01
    z[2,1,6]  R1070     1.3467422127723694e-01
    z[2,1,6]  R1071     1.0879641771316528e-01
    z[2,1,6]  R1072     3.0809977650642395e-01
    z[2,1,6]  R1073     3.7304118275642395e-01
    z[2,1,6]  R1074     1.1342987418174744e-01
    z[2,1,6]  R1075     -1.6270875930786133e-01
    z[2,1,6]  R1076     3.9924681186676025e-02
    z[2,1,6]  R1077     -2.3157656192779541e-01
    z[2,1,6]  R1078     3.9496082812547684e-02
    z[2,1,6]  R1079     -2.0244711637496948e-01
    z[2,1,6]  R1080     -3.8225898146629333e-01
    z[2,1,6]  R1081     -2.5455081462860107e-01
    z[1,4,0]  R11       -1
    z[1,4,0]  R38       1
    z[1,4,0]  R1082     -1
    z[1,4,0]  R1083     1
    z[1,4,0]  R1096     -5.4846620559692383e-01
    z[1,4,0]  R1097     -5.3737568855285645e-01
    z[1,4,0]  R1098     -3.4947690367698669e-01
    z[1,4,0]  R1099     -3.8337504863739014e-01
    z[1,4,0]  R1100     -3.3478114008903503e-01
    z[1,4,0]  R1101     -2.9309570789337158e-01
    z[1,4,0]  R1102     -4.8481833934783936e-01
    z[1,4,0]  R1103     -5.7584816217422485e-01
    z[1,4,0]  R1104     2.5187286734580994e-01
    z[1,4,0]  R1105     4.6663612127304077e-02
    z[1,4,0]  R1106     9.1005897521972656e-01
    z[1,4,0]  R1107     1.3805174827575684e-01
    z[1,4,0]  R1108     4.7126758098602295e-01
    z[1,4,0]  R1109     4.3676313757896423e-01
    z[1,4,0]  R1110     0.534625232219696
    z[1,4,0]  R1111     7.4053883552551270e-01
    z[1,4,0]  R1112     7.1643579006195068e-01
    z[1,4,0]  R1113     6.3351887464523315e-01
    z[1,4,0]  R1114     8.7949562072753906e-01
    z[1,4,0]  R1115     7.2757941484451294e-01
    z[1,4,0]  R1116     -8.9046663045883179e-01
    z[1,4,0]  R1117     -7.7508997917175293e-01
    z[1,4,0]  R1118     -5.2592891454696655e-01
    z[1,4,0]  R1119     -7.9635888338088989e-01
    z[1,4,0]  R1120     -6.9828587770462036e-01
    z[1,4,0]  R1121     -6.2233519554138184e-01
    z[1,4,0]  R1122     -5.0729984045028687e-01
    z[1,4,0]  R1123     3.2287669181823730e-01
    z[1,4,0]  R1124     2.2204083204269409e-01
    z[1,4,0]  R1125     4.0584060549736023e-01
    z[1,4,0]  R1126     -4.2859551310539246e-01
    z[1,4,0]  R1127     -5.0588089227676392e-01
    z[1,4,0]  R1128     -6.6504962742328644e-02
    z[1,4,0]  R1129     9.3613542616367340e-02
    z[1,4,0]  R1130     1.6056878864765167e-01
    z[1,4,0]  R1131     1.9732825458049774e-01
    z[1,4,0]  R1132     5.2592545747756958e-01
    z[1,4,0]  R1133     3.2273855805397034e-01
    z[1,4,0]  R1134     0.145841583609581
    z[1,4,0]  R1135     1.4634659886360168e-01
    z[1,4,0]  R1136     -4.9644985795021057e-01
    z[1,4,0]  R1137     -5.6475734710693359e-01
    z[1,4,0]  R1138     -4.7109922766685486e-01
    z[1,4,0]  R1139     5.1703029870986938e-01
    z[1,4,0]  R1140     4.9828074872493744e-02
    z[1,4,0]  R1141     -6.4766839146614075e-02
    z[1,4,0]  R1142     3.1029042601585388e-01
    z[1,4,0]  R1143     2.6755779981613159e-01
    z[1,4,0]  R1144     4.5220926403999329e-01
    z[1,4,0]  R1145     7.0565128326416016e-01
    z[1,4,0]  R1146     -7.2389864921569824e-01
    z[1,4,0]  R1147     4.7058889269828796e-01
    z[1,4,0]  R1148     3.2659158110618591e-01
    z[1,4,0]  R1149     2.9244866967201233e-01
    z[1,4,0]  R1150     1.8340951204299927e-01
    z[1,4,0]  R1151     1.1921054124832153e-01
    z[1,4,0]  R1152     4.4222906231880188e-01
    z[1,4,0]  R1153     4.4989496469497681e-01
    z[1,4,0]  R1154     0.354343980550766
    z[1,4,0]  R1155     4.8459321260452271e-01
    z[1,4,0]  R1156     -3.5911047458648682e-01
    z[1,4,0]  R1157     -3.5800606012344360e-01
    z[1,4,0]  R1158     -1.3780531287193298e-01
    z[1,4,0]  R1159     -2.9238942265510559e-01
    z[1,4,0]  R1160     -1.8122249841690063e-01
    z[1,4,0]  R1161     -1.4514103531837463e-01
    z[1,4,0]  R1162     -3.9680501818656921e-01
    z[1,4,0]  R1163     -3.6523446440696716e-01
    z[1,4,0]  R1164     -7.7383734285831451e-02
    z[1,4,0]  R1165     -4.0516808629035950e-01
    z[1,4,0]  R1166     0.942054808139801
    z[1,4,0]  R1167     8.9981865882873535e-01
    z[1,4,0]  R1168     5.8713823556900024e-01
    z[1,4,0]  R1169     6.0660946369171143e-01
    z[1,4,0]  R1170     6.0895085334777832e-01
    z[1,4,0]  R1171     0.65199875831604
    z[1,4,0]  R1172     5.9659922122955322e-01
    z[1,4,0]  R1173     1.1463463306427002e-01
    z[1,4,0]  R1174     5.4364860057830811e-01
    z[1,4,0]  R1175     2.2304007411003113e-01
    z[1,4,0]  R1176     -0.943132221698761
    z[1,4,0]  R1177     -4.1723379492759705e-01
    z[1,4,0]  R1178     3.8019508123397827e-01
    z[1,4,0]  R1179     4.4824984669685364e-01
    z[1,4,0]  R1180     5.2685993909835815e-01
    z[1,4,0]  R1181     9.4603672623634338e-02
    z[1,4,0]  R1182     -2.4945980310440063e-01
    z[1,4,0]  R1183     -2.7539214491844177e-01
    z[1,4,0]  R1184     1.0563543438911438e-01
    z[1,4,0]  R1185     7.7304452657699585e-02
    z[1,4,0]  R1186     -9.3091838061809540e-02
    z[1,4,0]  R1187     -5.1429796218872070e-01
    z[1,4,0]  R1188     6.5010762214660645e-01
    z[1,4,0]  R1189     -1.0805778205394745e-02
    z[1,4,0]  R1190     1.4774626493453979e-01
    z[1,4,0]  R1191     1.1612449586391449e-01
    z[1,4,0]  R1192     3.6412292718887329e-01
    z[1,4,0]  R1193     5.1719751209020615e-02
    z[1,4,0]  R1194     -9.9702635779976845e-03
    z[1,4,0]  R1195     -5.7827834039926529e-02
    z[1,4,0]  R1196     3.3384832739830017e-01
    z[1,4,0]  R1197     -1.3449686765670776e-01
    z[1,4,0]  R1198     -8.7584452703595161e-03
    z[1,4,0]  R1199     4.8221364617347717e-01
    z[1,4,0]  R1200     8.4913492202758789e-02
    z[1,4,0]  R1201     -3.2118913531303406e-01
    z[1,4,0]  R1202     2.1783185005187988e-01
    z[1,4,0]  R1203     2.6415199041366577e-01
    z[1,4,0]  R1204     1.2744180858135223e-01
    z[1,4,0]  R1205     1.4033287763595581e-01
    z[1,4,1]  R12       -1
    z[1,4,1]  R39       1
    z[1,4,1]  R1084     -1
    z[1,4,1]  R1085     1
    z[1,4,1]  R1096     3.8442826271057129e-01
    z[1,4,1]  R1097     -2.6387885212898254e-01
    z[1,4,1]  R1098     3.1713566184043884e-01
    z[1,4,1]  R1099     -6.0303714126348495e-03
    z[1,4,1]  R1100     2.7103728055953979e-01
    z[1,4,1]  R1101     1.1794888228178024e-01
    z[1,4,1]  R1102     1.6418954730033875e-01
    z[1,4,1]  R1103     4.1713860630989075e-01
    z[1,4,1]  R1104     -6.7177355289459229e-01
    z[1,4,1]  R1105     -6.6847103834152222e-01
    z[1,4,1]  R1106     2.9807296395301819e-01
    z[1,4,1]  R1107     2.4385875463485718e-01
    z[1,4,1]  R1108     -3.8807126879692078e-01
    z[1,4,1]  R1109     3.3396932482719421e-01
    z[1,4,1]  R1110     3.5263964533805847e-01
    z[1,4,1]  R1111     2.4720968306064606e-01
    z[1,4,1]  R1112     -3.7510228157043457e-01
    z[1,4,1]  R1113     -5.7581549882888794e-01
    z[1,4,1]  R1114     1.4785762131214142e-01
    z[1,4,1]  R1115     -3.0817532539367676e-01
    z[1,4,1]  R1116     -2.1939820051193237e-01
    z[1,4,1]  R1117     1.9416160881519318e-01
    z[1,4,1]  R1118     4.9348825216293335e-01
    z[1,4,1]  R1119     -1.4357546344399452e-02
    z[1,4,1]  R1120     -7.9884245991706848e-02
    z[1,4,1]  R1121     1.5804682672023773e-01
    z[1,4,1]  R1122     1.9286023080348969e-01
    z[1,4,1]  R1123     6.6589933633804321e-01
    z[1,4,1]  R1124     -4.4424888491630554e-01
    z[1,4,1]  R1125     -4.4897049665451050e-02
    z[1,4,1]  R1126     4.5701089501380920e-01
    z[1,4,1]  R1127     6.6072843968868256e-02
    z[1,4,1]  R1128     -6.2168675661087036e-01
    z[1,4,1]  R1129     -7.2063046693801880e-01
    z[1,4,1]  R1130     -1.4998872578144073e-01
    z[1,4,1]  R1131     -2.9883316159248352e-01
    z[1,4,1]  R1132     -4.1531211137771606e-01
    z[1,4,1]  R1133     -3.4737905859947205e-01
    z[1,4,1]  R1134     -2.5700709223747253e-01
    z[1,4,1]  R1135     0.885625422000885
    z[1,4,1]  R1136     5.2399653196334839e-01
    z[1,4,1]  R1137     6.6193324327468872e-01
    z[1,4,1]  R1138     2.1502195298671722e-01
    z[1,4,1]  R1139     -3.4582906961441040e-01
    z[1,4,1]  R1140     -0.293354332447052
    z[1,4,1]  R1141     -5.0657910108566284e-01
    z[1,4,1]  R1142     -5.3950250148773193e-01
    z[1,4,1]  R1143     -1.9510462880134583e-01
    z[1,4,1]  R1144     -3.7244316935539246e-01
    z[1,4,1]  R1145     -1.6403743624687195e-01
    z[1,4,1]  R1146     -3.8011498749256134e-02
    z[1,4,1]  R1147     -2.4596635997295380e-01
    z[1,4,1]  R1148     -8.6322838068008423e-01
    z[1,4,1]  R1149     -9.1503816843032837e-01
    z[1,4,1]  R1150     -9.3509048223495483e-01
    z[1,4,1]  R1151     -8.8453543186187744e-01
    z[1,4,1]  R1152     -7.9997146129608154e-01
    z[1,4,1]  R1153     -7.4838405847549438e-01
    z[1,4,1]  R1154     -0.752017617225647
    z[1,4,1]  R1155     -7.7209919691085815e-01
    z[1,4,1]  R1156     3.9992593228816986e-02
    z[1,4,1]  R1157     8.8066153228282928e-02
    z[1,4,1]  R1158     -1.4184577763080597e-01
    z[1,4,1]  R1159     1.9708101451396942e-01
    z[1,4,1]  R1160     1.9181822240352631e-01
    z[1,4,1]  R1161     1.7235554754734039e-01
    z[1,4,1]  R1162     1.0931375622749329e-01
    z[1,4,1]  R1163     0.334354430437088
    z[1,4,1]  R1164     1.9728232920169830e-01
    z[1,4,1]  R1165     1.5075589530169964e-02
    z[1,4,1]  R1166     5.3768295794725418e-02
    z[1,4,1]  R1167     2.5043004751205444e-01
    z[1,4,1]  R1168     0.412627249956131
    z[1,4,1]  R1169     -4.2724588513374329e-01
    z[1,4,1]  R1170     -7.0076274871826172e-01
    z[1,4,1]  R1171     -6.1578017473220825e-01
    z[1,4,1]  R1172     -7.4422496557235718e-01
    z[1,4,1]  R1173     -3.5293185710906982e-01
    z[1,4,1]  R1174     -5.6348502635955811e-01
    z[1,4,1]  R1175     -3.0520507693290710e-01
    z[1,4,1]  R1176     2.6929962635040283e-01
    z[1,4,1]  R1177     0.547633171081543
    z[1,4,1]  R1178     -3.4225234389305115e-01
    z[1,4,1]  R1179     -3.7711513042449951e-01
    z[1,4,1]  R1180     5.0179883837699890e-02
    z[1,4,1]  R1181     4.6545788645744324e-02
    z[1,4,1]  R1182     -4.1894862055778503e-01
    z[1,4,1]  R1183     -0.589698076248169
    z[1,4,1]  R1184     -2.8642225265502930e-01
    z[1,4,1]  R1185     0.365046888589859
    z[1,4,1]  R1186     7.0368468761444092e-01
    z[1,4,1]  R1187     6.3230073451995850e-01
    z[1,4,1]  R1188     5.2852157503366470e-02
    z[1,4,1]  R1189     -3.5425764322280884e-01
    z[1,4,1]  R1190     -0.572669506072998
    z[1,4,1]  R1191     3.5959962755441666e-02
    z[1,4,1]  R1192     6.5954573452472687e-02
    z[1,4,1]  R1193     -3.4190490841865540e-01
    z[1,4,1]  R1194     -1.7867447435855865e-01
    z[1,4,1]  R1195     -2.2493988275527954e-01
    z[1,4,1]  R1196     -2.8695452213287354e-01
    z[1,4,1]  R1197     -5.7241046428680420e-01
    z[1,4,1]  R1198     -3.8586992025375366e-01
    z[1,4,1]  R1199     -2.0042078197002411e-01
    z[1,4,1]  R1200     -1.7952386289834976e-02
    z[1,4,1]  R1201     -1.3532178103923798e-01
    z[1,4,1]  R1202     0.408532053232193
    z[1,4,1]  R1203     -0.789068877696991
    z[1,4,1]  R1204     -0.81621253490448
    z[1,4,1]  R1205     -7.4622911214828491e-01
    z[1,4,2]  R13       -1
    z[1,4,2]  R40       1
    z[1,4,2]  R1086     -1
    z[1,4,2]  R1087     1
    z[1,4,2]  R1096     4.0556451678276062e-01
    z[1,4,2]  R1097     5.7136386632919312e-01
    z[1,4,2]  R1098     6.8847596645355225e-01
    z[1,4,2]  R1099     2.0886674523353577e-01
    z[1,4,2]  R1100     -1.5248348005115986e-02
    z[1,4,2]  R1101     5.3124696016311646e-01
    z[1,4,2]  R1102     -2.1343810856342316e-01
    z[1,4,2]  R1103     -2.7728474140167236e-01
    z[1,4,2]  R1104     -1.0162437707185745e-01
    z[1,4,2]  R1105     -2.3174107074737549e-01
    z[1,4,2]  R1106     -1.1740779131650925e-01
    z[1,4,2]  R1107     -6.8835496902465820e-01
    z[1,4,2]  R1108     5.9588211774826050e-01
    z[1,4,2]  R1109     -6.0378080606460571e-01
    z[1,4,2]  R1110     -3.1660494208335876e-01
    z[1,4,2]  R1111     -4.0137115865945816e-02
    z[1,4,2]  R1112     2.5910025835037231e-01
    z[1,4,2]  R1113     4.1383656859397888e-01
    z[1,4,2]  R1114     -2.9499918222427368e-01
    z[1,4,2]  R1115     3.6738941073417664e-01
    z[1,4,2]  R1116     -1.9834670424461365e-01
    z[1,4,2]  R1117     -3.6132711917161942e-02
    z[1,4,2]  R1118     2.9677665233612061e-01
    z[1,4,2]  R1119     2.6175066828727722e-01
    z[1,4,2]  R1120     -1.4722524583339691e-01
    z[1,4,2]  R1121     -2.3189820349216461e-01
    z[1,4,2]  R1122     -7.4641996622085571e-01
    z[1,4,2]  R1123     -5.8503359556198120e-01
    z[1,4,2]  R1124     -1.5049757063388824e-01
    z[1,4,2]  R1125     4.7004982829093933e-02
    z[1,4,2]  R1126     -4.8428988456726074e-01
    z[1,4,2]  R1127     -2.0427714288234711e-01
    z[1,4,2]  R1128     1.7326584085822105e-02
    z[1,4,2]  R1129     -2.0517694950103760e-01
    z[1,4,2]  R1130     -6.6344380378723145e-02
    z[1,4,2]  R1131     1.9156554341316223e-01
    z[1,4,2]  R1132     0.0657258853316307
    z[1,4,2]  R1133     -4.1535636410117149e-03
    z[1,4,2]  R1134     -2.2964255511760712e-01
    z[1,4,2]  R1135     -1.2464547902345657e-01
    z[1,4,2]  R1136     -5.8535808324813843e-01
    z[1,4,2]  R1137     -2.8683599829673767e-01
    z[1,4,2]  R1138     -4.8880372196435928e-02
    z[1,4,2]  R1139     -2.0156674087047577e-01
    z[1,4,2]  R1140     -2.2471249103546143e-01
    z[1,4,2]  R1141     -3.3468988537788391e-01
    z[1,4,2]  R1142     1.8343251943588257e-01
    z[1,4,2]  R1143     -2.5035008788108826e-01
    z[1,4,2]  R1144     2.0671902596950531e-01
    z[1,4,2]  R1145     -0.0722411647439003
    z[1,4,2]  R1146     -5.3254854679107666e-01
    z[1,4,2]  R1147     -1.6451023519039154e-01
    z[1,4,2]  R1148     1.6175574064254761e-01
    z[1,4,2]  R1149     0.000609697075560689
    z[1,4,2]  R1150     -5.0387654453516006e-02
    z[1,4,2]  R1151     2.9645591974258423e-01
    z[1,4,2]  R1152     -3.1568646430969238e-01
    z[1,4,2]  R1153     3.7175349891185760e-02
    z[1,4,2]  R1154     3.4580063819885254e-01
    z[1,4,2]  R1155     1.1843249201774597e-01
    z[1,4,2]  R1156     7.0885759592056274e-01
    z[1,4,2]  R1157     7.2918081283569336e-01
    z[1,4,2]  R1158     0.774948239326477
    z[1,4,2]  R1159     8.6175012588500977e-01
    z[1,4,2]  R1160     -0.421764612197876
    z[1,4,2]  R1161     -0.676142156124115
    z[1,4,2]  R1162     4.2299043387174606e-02
    z[1,4,2]  R1163     1.0496312379837036e-01
    z[1,4,2]  R1164     -4.2408052086830139e-01
    z[1,4,2]  R1165     4.8272809386253357e-01
    z[1,4,2]  R1166     7.6136313378810883e-02
    z[1,4,2]  R1167     -1.1208809167146683e-01
    z[1,4,2]  R1168     -0.0673513412475586
    z[1,4,2]  R1169     -3.7408652901649475e-01
    z[1,4,2]  R1170     -1.6330179572105408e-01
    z[1,4,2]  R1171     -7.6653786003589630e-02
    z[1,4,2]  R1172     -2.0851986110210419e-01
    z[1,4,2]  R1173     -5.0066363811492920e-01
    z[1,4,2]  R1174     -1.8591651320457458e-01
    z[1,4,2]  R1175     -5.1453369855880737e-01
    z[1,4,2]  R1176     -1.3060493767261505e-01
    z[1,4,2]  R1177     -8.7851323187351227e-02
    z[1,4,2]  R1178     -0.742438793182373
    z[1,4,2]  R1179     -4.8063719272613525e-01
    z[1,4,2]  R1180     -6.5481591224670410e-01
    z[1,4,2]  R1181     -3.4209641814231873e-01
    z[1,4,2]  R1182     -7.1385228633880615e-01
    z[1,4,2]  R1183     -6.4999693632125854e-01
    z[1,4,2]  R1184     -0.809843122959137
    z[1,4,2]  R1185     -6.0245621204376221e-01
    z[1,4,2]  R1186     4.5894297957420349e-01
    z[1,4,2]  R1187     1.1132667958736420e-01
    z[1,4,2]  R1188     -6.6455513238906860e-01
    z[1,4,2]  R1189     -5.2812069654464722e-01
    z[1,4,2]  R1190     -5.6795650720596313e-01
    z[1,4,2]  R1191     -6.9453239440917969e-01
    z[1,4,2]  R1192     -0.555451512336731
    z[1,4,2]  R1193     -7.9939246177673340e-01
    z[1,4,2]  R1194     -6.5235203504562378e-01
    z[1,4,2]  R1195     -6.0514295101165771e-01
    z[1,4,2]  R1196     -7.2713285684585571e-01
    z[1,4,2]  R1197     -7.5922089815139771e-01
    z[1,4,2]  R1198     -5.8087509870529175e-01
    z[1,4,2]  R1199     -7.8284674882888794e-01
    z[1,4,2]  R1200     -7.4088609218597412e-01
    z[1,4,2]  R1201     -0.635337233543396
    z[1,4,2]  R1202     -3.9858633279800415e-01
    z[1,4,2]  R1203     4.3616119772195816e-02
    z[1,4,2]  R1204     1.5644568204879761e-01
    z[1,4,2]  R1205     -9.8282612860202789e-02
    z[1,4,3]  R14       -1
    z[1,4,3]  R41       1
    z[1,4,3]  R1088     -1
    z[1,4,3]  R1089     1
    z[1,4,3]  R1096     3.9904925227165222e-01
    z[1,4,3]  R1097     -4.4947284460067749e-01
    z[1,4,3]  R1098     -2.5990280508995056e-01
    z[1,4,3]  R1099     -3.9733633399009705e-01
    z[1,4,3]  R1100     -2.7447342872619629e-01
    z[1,4,3]  R1101     -5.7482278347015381e-01
    z[1,4,3]  R1102     -6.4267545938491821e-01
    z[1,4,3]  R1103     -2.6924726553261280e-03
    z[1,4,3]  R1104     -4.3043103814125061e-01
    z[1,4,3]  R1105     -5.6083846092224121e-01
    z[1,4,3]  R1106     -4.9707889556884766e-03
    z[1,4,3]  R1107     5.6251049041748047e-01
    z[1,4,3]  R1108     4.5717990398406982e-01
    z[1,4,3]  R1109     5.6790667772293091e-01
    z[1,4,3]  R1110     6.6686850786209106e-01
    z[1,4,3]  R1111     4.8297506570816040e-01
    z[1,4,3]  R1112     4.2766058444976807e-01
    z[1,4,3]  R1113     2.0888186991214752e-01
    z[1,4,3]  R1114     2.5776371359825134e-01
    z[1,4,3]  R1115     2.2306315600872040e-01
    z[1,4,3]  R1116     -1.1081153899431229e-01
    z[1,4,3]  R1117     -0.454868882894516
    z[1,4,3]  R1118     -4.9220845103263855e-01
    z[1,4,3]  R1119     0.456521600484848
    z[1,4,3]  R1120     0.0790027603507042
    z[1,4,3]  R1121     5.3736311197280884e-01
    z[1,4,3]  R1122     1.2507483363151550e-01
    z[1,4,3]  R1123     3.1046831607818604e-01
    z[1,4,3]  R1124     -4.5002856850624084e-01
    z[1,4,3]  R1125     -7.8516000509262085e-01
    z[1,4,3]  R1126     -0.120479054749012
    z[1,4,3]  R1127     8.1015847623348236e-02
    z[1,4,3]  R1128     -5.2535998821258545e-01
    z[1,4,3]  R1129     -4.3817153573036194e-01
    z[1,4,3]  R1130     -7.7117341756820679e-01
    z[1,4,3]  R1131     -6.7462337017059326e-01
    z[1,4,3]  R1132     -3.9227211475372314e-01
    z[1,4,3]  R1133     -6.4566022157669067e-01
    z[1,4,3]  R1134     -8.5562658309936523e-01
    z[1,4,3]  R1135     9.8151132464408875e-02
    z[1,4,3]  R1136     3.6296206712722778e-01
    z[1,4,3]  R1137     1.9905048608779907e-01
    z[1,4,3]  R1138     1.3431535661220551e-01
    z[1,4,3]  R1139     -6.5590482950210571e-01
    z[1,4,3]  R1140     -7.0590674877166748e-01
    z[1,4,3]  R1141     -4.9436318874359131e-01
    z[1,4,3]  R1142     -7.5713771581649780e-01
    z[1,4,3]  R1143     -8.6876374483108521e-01
    z[1,4,3]  R1144     -5.4235792160034180e-01
    z[1,4,3]  R1145     -6.7413049936294556e-01
    z[1,4,3]  R1146     8.8837943971157074e-02
    z[1,4,3]  R1147     -7.3519039154052734e-01
    z[1,4,3]  R1148     -1.9255171716213226e-01
    z[1,4,3]  R1149     1.3584984838962555e-01
    z[1,4,3]  R1150     2.1812172234058380e-01
    z[1,4,3]  R1151     9.1849960386753082e-02
    z[1,4,3]  R1152     1.8861801922321320e-01
    z[1,4,3]  R1153     -2.7884244918823242e-01
    z[1,4,3]  R1154     1.2510600499808788e-02
    z[1,4,3]  R1155     -2.7186835184693336e-02
    z[1,4,3]  R1156     1.5453018248081207e-01
    z[1,4,3]  R1157     2.4318028986454010e-01
    z[1,4,3]  R1158     -6.6407345235347748e-02
    z[1,4,3]  R1159     3.7617892958223820e-03
    z[1,4,3]  R1160     7.7589273452758789e-01
    z[1,4,3]  R1161     4.9217936396598816e-01
    z[1,4,3]  R1162     8.0812788009643555e-01
    z[1,4,3]  R1163     9.9210254848003387e-02
    z[1,4,3]  R1164     2.9624202847480774e-01
    z[1,4,3]  R1165     -5.8686983585357666e-01
    z[1,4,3]  R1166     2.3793120682239532e-01
    z[1,4,3]  R1167     1.7997060716152191e-01
    z[1,4,3]  R1168     -2.1408474445343018e-01
    z[1,4,3]  R1169     -3.9325478672981262e-01
    z[1,4,3]  R1170     -2.1021410822868347e-01
    z[1,4,3]  R1171     -3.5917416214942932e-01
    z[1,4,3]  R1172     1.9981622695922852e-02
    z[1,4,3]  R1173     -5.4983055591583252e-01
    z[1,4,3]  R1174     1.9537252373993397e-03
    z[1,4,3]  R1175     -5.0493568181991577e-01
    z[1,4,3]  R1176     2.7512183412909508e-02
    z[1,4,3]  R1177     5.0766932964324951e-01
    z[1,4,3]  R1178     -2.9457315802574158e-01
    z[1,4,3]  R1179     -4.6839483082294464e-02
    z[1,4,3]  R1180     -4.3036738038063049e-01
    z[1,4,3]  R1181     -0.267819881439209
    z[1,4,3]  R1182     -3.9078226685523987e-01
    z[1,4,3]  R1183     -2.8767085075378418e-01
    z[1,4,3]  R1184     -3.8902035355567932e-01
    z[1,4,3]  R1185     -0.190802201628685
    z[1,4,3]  R1186     5.1662659645080566e-01
    z[1,4,3]  R1187     1.0520192235708237e-01
    z[1,4,3]  R1188     -2.2982361912727356e-01
    z[1,4,3]  R1189     -5.8106422424316406e-01
    z[1,4,3]  R1190     -3.6560976505279541e-01
    z[1,4,3]  R1191     -6.9852042198181152e-01
    z[1,4,3]  R1192     -3.0261768028140068e-02
    z[1,4,3]  R1193     -6.6269993782043457e-02
    z[1,4,3]  R1194     -6.4941161870956421e-01
    z[1,4,3]  R1195     8.2603186368942261e-02
    z[1,4,3]  R1196     -2.2602368891239166e-01
    z[1,4,3]  R1197     -1.2361246347427368e-01
    z[1,4,3]  R1198     -5.3486543893814087e-01
    z[1,4,3]  R1199     -1.1051447689533234e-01
    z[1,4,3]  R1200     -6.4729940891265869e-01
    z[1,4,3]  R1201     -3.4381550550460815e-01
    z[1,4,3]  R1202     -3.5488963127136230e-01
    z[1,4,3]  R1203     0.317862868309021
    z[1,4,3]  R1204     1.6077440977096558e-01
    z[1,4,3]  R1205     4.6951431035995483e-01
    z[1,4,4]  R15       -1
    z[1,4,4]  R42       1
    z[1,4,4]  R1090     -1
    z[1,4,4]  R1091     1
    z[1,4,4]  R1096     -3.1760153174400330e-01
    z[1,4,4]  R1097     1.2788502871990204e-01
    z[1,4,4]  R1098     -4.5941525697708130e-01
    z[1,4,4]  R1099     -4.5679351687431335e-01
    z[1,4,4]  R1100     -6.8453729152679443e-01
    z[1,4,4]  R1101     -2.0277164876461029e-02
    z[1,4,4]  R1102     5.1528328657150269e-01
    z[1,4,4]  R1103     5.8601063489913940e-01
    z[1,4,4]  R1104     3.4970134496688843e-01
    z[1,4,4]  R1105     2.0519576966762543e-01
    z[1,4,4]  R1106     -2.5997087359428406e-02
    z[1,4,4]  R1107     -3.1932753324508667e-01
    z[1,4,4]  R1108     -2.0619036257266998e-01
    z[1,4,4]  R1109     2.2363530471920967e-02
    z[1,4,4]  R1110     2.4442672729492188e-02
    z[1,4,4]  R1111     -2.2545643150806427e-01
    z[1,4,4]  R1112     -2.4691025912761688e-01
    z[1,4,4]  R1113     -1.8389484286308289e-01
    z[1,4,4]  R1114     6.4173959195613861e-02
    z[1,4,4]  R1115     -4.2985841631889343e-01
    z[1,4,4]  R1116     2.8474089503288269e-01
    z[1,4,4]  R1117     -1.8321696668863297e-02
    z[1,4,4]  R1118     1.2423494458198547e-01
    z[1,4,4]  R1119     -0.0837835893034935
    z[1,4,4]  R1120     -4.8522930592298508e-02
    z[1,4,4]  R1121     -2.8666019439697266e-01
    z[1,4,4]  R1122     -2.0664894580841064e-01
    z[1,4,4]  R1123     -3.7180971354246140e-02
    z[1,4,4]  R1124     -9.1457515954971313e-02
    z[1,4,4]  R1125     -8.6750283837318420e-02
    z[1,4,4]  R1126     1.3383789360523224e-01
    z[1,4,4]  R1127     -6.1846762895584106e-01
    z[1,4,4]  R1128     -9.6565060317516327e-02
    z[1,4,4]  R1129     -3.8908189535140991e-01
    z[1,4,4]  R1130     -1.9357408583164215e-01
    z[1,4,4]  R1131     -1.5970006585121155e-01
    z[1,4,4]  R1132     -3.8437676429748535e-01
    z[1,4,4]  R1133     -4.9526163935661316e-01
    z[1,4,4]  R1134     2.0835416018962860e-01
    z[1,4,4]  R1135     -2.9163017868995667e-01
    z[1,4,4]  R1136     0.0585007481276989
    z[1,4,4]  R1137     2.9259911179542542e-01
    z[1,4,4]  R1138     -6.8360525369644165e-01
    z[1,4,4]  R1139     -0.242141455411911
    z[1,4,4]  R1140     -2.4339766800403595e-01
    z[1,4,4]  R1141     -1.4195046387612820e-02
    z[1,4,4]  R1142     -0.0697336345911026
    z[1,4,4]  R1143     -7.0744507014751434e-02
    z[1,4,4]  R1144     -1.7798207700252533e-01
    z[1,4,4]  R1145     -3.3123213797807693e-03
    z[1,4,4]  R1146     -2.9495945572853088e-01
    z[1,4,4]  R1147     9.0996541082859039e-02
    z[1,4,4]  R1148     -2.4021466076374054e-01
    z[1,4,4]  R1149     -1.0266276448965073e-01
    z[1,4,4]  R1150     -1.9709125161170959e-01
    z[1,4,4]  R1151     1.9474083185195923e-01
    z[1,4,4]  R1152     -1.4570684731006622e-01
    z[1,4,4]  R1153     7.8483283519744873e-02
    z[1,4,4]  R1154     5.5651620030403137e-02
    z[1,4,4]  R1155     2.9908114671707153e-01
    z[1,4,4]  R1156     0.584718644618988
    z[1,4,4]  R1157     1.1929895728826523e-01
    z[1,4,4]  R1158     4.4568312168121338e-01
    z[1,4,4]  R1159     -1.9457225501537323e-01
    z[1,4,4]  R1160     -2.3900421336293221e-02
    z[1,4,4]  R1161     -3.1577959656715393e-01
    z[1,4,4]  R1162     -3.5803741216659546e-01
    z[1,4,4]  R1163     6.9361424446105957e-01
    z[1,4,4]  R1164     -0.651825487613678
    z[1,4,4]  R1165     1.3738542795181274e-01
    z[1,4,4]  R1166     -1.3454273343086243e-01
    z[1,4,4]  R1167     1.5022955834865570e-01
    z[1,4,4]  R1168     0.452536016702652
    z[1,4,4]  R1169     3.3214700222015381e-01
    z[1,4,4]  R1170     2.2784835100173950e-01
    z[1,4,4]  R1171     -1.3697463274002075e-01
    z[1,4,4]  R1172     1.7680658400058746e-01
    z[1,4,4]  R1173     -4.9967506527900696e-01
    z[1,4,4]  R1174     2.7726349234580994e-01
    z[1,4,4]  R1175     -4.2929565906524658e-01
    z[1,4,4]  R1176     -7.9094909131526947e-02
    z[1,4,4]  R1177     8.4954008460044861e-02
    z[1,4,4]  R1178     -3.1500864028930664e-01
    z[1,4,4]  R1179     -4.3252453207969666e-01
    z[1,4,4]  R1180     -8.6337188258767128e-03
    z[1,4,4]  R1181     -6.2996000051498413e-01
    z[1,4,4]  R1182     8.6528457701206207e-02
    z[1,4,4]  R1183     -2.3535829782485962e-01
    z[1,4,4]  R1184     2.9225587844848633e-01
    z[1,4,4]  R1185     -4.7899162769317627e-01
    z[1,4,4]  R1186     5.1167141646146774e-02
    z[1,4,4]  R1187     2.7436983585357666e-01
    z[1,4,4]  R1188     -1.1434942483901978e-01
    z[1,4,4]  R1189     -4.6427333354949951e-01
    z[1,4,4]  R1190     9.7543504089117050e-03
    z[1,4,4]  R1191     3.3553630113601685e-02
    z[1,4,4]  R1192     -4.8827984929084778e-01
    z[1,4,4]  R1193     9.5876671373844147e-02
    z[1,4,4]  R1194     -1.2067833542823792e-01
    z[1,4,4]  R1195     -4.4259798526763916e-01
    z[1,4,4]  R1196     -4.3967342376708984e-01
    z[1,4,4]  R1197     -1.3392937183380127e-01
    z[1,4,4]  R1198     -4.1266137361526489e-01
    z[1,4,4]  R1199     2.2943212091922760e-01
    z[1,4,4]  R1200     -1.1504572629928589e-01
    z[1,4,4]  R1201     -3.9065372943878174e-01
    z[1,4,4]  R1202     -6.8254613876342773e-01
    z[1,4,4]  R1203     -3.9675071835517883e-01
    z[1,4,4]  R1204     -4.9660202860832214e-01
    z[1,4,4]  R1205     -3.6722466349601746e-01
    z[1,4,5]  R16       -1
    z[1,4,5]  R43       1
    z[1,4,5]  R1092     -1
    z[1,4,5]  R1093     1
    z[1,4,5]  R1096     -3.3961209654808044e-01
    z[1,4,5]  R1097     1.8544797599315643e-01
    z[1,4,5]  R1098     1.1440439522266388e-01
    z[1,4,5]  R1099     6.5428024530410767e-01
    z[1,4,5]  R1100     4.4936504960060120e-01
    z[1,4,5]  R1101     -3.0648830533027649e-01
    z[1,4,5]  R1102     1.1762021481990814e-01
    z[1,4,5]  R1103     -2.5380519032478333e-01
    z[1,4,5]  R1104     -3.1958609819412231e-01
    z[1,4,5]  R1105     -8.4092825651168823e-02
    z[1,4,5]  R1106     -1.1361759155988693e-01
    z[1,4,5]  R1107     4.4120015809312463e-04
    z[1,4,5]  R1108     -2.7406115084886551e-02
    z[1,4,5]  R1109     1.1172773083671927e-03
    z[1,4,5]  R1110     -9.8782189190387726e-02
    z[1,4,5]  R1111     -2.7341619133949280e-01
    z[1,4,5]  R1112     1.3734828680753708e-02
    z[1,4,5]  R1113     -2.1597044542431831e-02
    z[1,4,5]  R1114     1.3793526589870453e-01
    z[1,4,5]  R1115     0.0759831964969635
    z[1,4,5]  R1116     4.6145290136337280e-02
    z[1,4,5]  R1117     3.8462081551551819e-01
    z[1,4,5]  R1118     0.309256374835968
    z[1,4,5]  R1119     -1.5847636759281158e-01
    z[1,4,5]  R1120     5.0776267051696777e-01
    z[1,4,5]  R1121     2.5914970040321350e-01
    z[1,4,5]  R1122     7.1749143302440643e-02
    z[1,4,5]  R1123     -3.7542516365647316e-03
    z[1,4,5]  R1124     -2.2628861665725708e-01
    z[1,4,5]  R1125     -1.9060148298740387e-01
    z[1,4,5]  R1126     -3.3287471532821655e-01
    z[1,4,5]  R1127     -9.2252299189567566e-02
    z[1,4,5]  R1128     -5.5725795030593872e-01
    z[1,4,5]  R1129     -2.5712516903877258e-01
    z[1,4,5]  R1130     -5.5599504709243774e-01
    z[1,4,5]  R1131     -5.6729829311370850e-01
    z[1,4,5]  R1132     -4.8965570330619812e-01
    z[1,4,5]  R1133     -2.9055011272430420e-01
    z[1,4,5]  R1134     1.7456176877021790e-01
    z[1,4,5]  R1135     2.8850591182708740e-01
    z[1,4,5]  R1136     -2.4103295058012009e-02
    z[1,4,5]  R1137     -6.2595404684543610e-02
    z[1,4,5]  R1138     -7.4984863400459290e-02
    z[1,4,5]  R1139     -1.5337084233760834e-01
    z[1,4,5]  R1140     -5.4406648874282837e-01
    z[1,4,5]  R1141     -5.2214270830154419e-01
    z[1,4,5]  R1142     7.0977574214339256e-03
    z[1,4,5]  R1143     5.4667755961418152e-02
    z[1,4,5]  R1144     -5.1970493793487549e-01
    z[1,4,5]  R1145     -6.0246225446462631e-02
    z[1,4,5]  R1146     3.3154781907796860e-02
    z[1,4,5]  R1147     -5.5117465555667877e-02
    z[1,4,5]  R1148     1.1985098570585251e-01
    z[1,4,5]  R1149     1.4734235405921936e-01
    z[1,4,5]  R1150     -3.7574142217636108e-02
    z[1,4,5]  R1151     -1.2454599142074585e-01
    z[1,4,5]  R1152     8.0336481332778931e-02
    z[1,4,5]  R1153     3.3352074027061462e-01
    z[1,4,5]  R1154     0.199890598654747
    z[1,4,5]  R1155     4.5918133109807968e-03
    z[1,4,5]  R1156     1.1528528295457363e-02
    z[1,4,5]  R1157     0.46016725897789
    z[1,4,5]  R1158     3.6443573236465454e-01
    z[1,4,5]  R1159     -1.1830856651067734e-01
    z[1,4,5]  R1160     2.3036555945873260e-01
    z[1,4,5]  R1161     2.3484787344932556e-01
    z[1,4,5]  R1162     1.8928836286067963e-01
    z[1,4,5]  R1163     3.3975234627723694e-01
    z[1,4,5]  R1164     2.8387647867202759e-01
    z[1,4,5]  R1165     -2.4164432287216187e-01
    z[1,4,5]  R1166     2.3776585236191750e-02
    z[1,4,5]  R1167     -2.4114778637886047e-01
    z[1,4,5]  R1168     1.0148690640926361e-01
    z[1,4,5]  R1169     3.1827643513679504e-02
    z[1,4,5]  R1170     -1.2022651731967926e-01
    z[1,4,5]  R1171     -4.6280834823846817e-02
    z[1,4,5]  R1172     -3.2995335757732391e-02
    z[1,4,5]  R1173     -2.3742890357971191e-01
    z[1,4,5]  R1174     -2.3853017017245293e-02
    z[1,4,5]  R1175     -3.4963092207908630e-01
    z[1,4,5]  R1176     1.0461068153381348e-01
    z[1,4,5]  R1177     -4.8696655035018921e-01
    z[1,4,5]  R1178     3.3102143555879593e-02
    z[1,4,5]  R1179     -3.9775168895721436e-01
    z[1,4,5]  R1180     -3.0349004268646240e-01
    z[1,4,5]  R1181     -6.0651499032974243e-01
    z[1,4,5]  R1182     -3.0408149957656860e-01
    z[1,4,5]  R1183     7.3091499507427216e-02
    z[1,4,5]  R1184     5.0470467656850815e-02
    z[1,4,5]  R1185     -4.5190271735191345e-01
    z[1,4,5]  R1186     -6.0405898839235306e-02
    z[1,4,5]  R1187     -4.4078135490417480e-01
    z[1,4,5]  R1188     -2.4801802635192871e-01
    z[1,4,5]  R1189     1.0184463113546371e-01
    z[1,4,5]  R1190     -3.9927187561988831e-01
    z[1,4,5]  R1191     4.3250724673271179e-02
    z[1,4,5]  R1192     -4.8846244812011719e-01
    z[1,4,5]  R1193     -4.4637325406074524e-01
    z[1,4,5]  R1194     -1.9911728799343109e-01
    z[1,4,5]  R1195     -5.6191688776016235e-01
    z[1,4,5]  R1196     -1.7829376459121704e-01
    z[1,4,5]  R1197     -1.8528230488300323e-01
    z[1,4,5]  R1198     2.2916388511657715e-01
    z[1,4,5]  R1199     2.1229531615972519e-02
    z[1,4,5]  R1200     -2.6011077687144279e-02
    z[1,4,5]  R1201     -4.5171543955802917e-01
    z[1,4,5]  R1202     -1.7164134979248047e-01
    z[1,4,5]  R1203     2.0519137382507324e-01
    z[1,4,5]  R1204     8.1515289843082428e-02
    z[1,4,5]  R1205     -2.0793452858924866e-01
    z[1,4,6]  R17       -1
    z[1,4,6]  R44       1
    z[1,4,6]  R1094     -1
    z[1,4,6]  R1095     1
    z[1,4,6]  R1096     1.0709770768880844e-01
    z[1,4,6]  R1097     -2.4973434209823608e-01
    z[1,4,6]  R1098     1.0766394436359406e-01
    z[1,4,6]  R1099     -1.2142031639814377e-01
    z[1,4,6]  R1100     2.6148018240928650e-01
    z[1,4,6]  R1101     4.3953621387481689e-01
    z[1,4,6]  R1102     -7.3536694981157780e-03
    z[1,4,6]  R1103     -9.8360069096088409e-02
    z[1,4,6]  R1104     2.5545188784599304e-01
    z[1,4,6]  R1105     3.6544266343116760e-01
    z[1,4,6]  R1106     2.3569293320178986e-01
    z[1,4,6]  R1107     1.7103728652000427e-01
    z[1,4,6]  R1108     -1.4125512540340424e-01
    z[1,4,6]  R1109     -1.0065762698650360e-01
    z[1,4,6]  R1110     -1.8577769398689270e-01
    z[1,4,6]  R1111     1.7328223586082458e-01
    z[1,4,6]  R1112     -1.8665000796318054e-01
    z[1,4,6]  R1113     -1.3384471833705902e-01
    z[1,4,6]  R1114     -1.6737556457519531e-01
    z[1,4,6]  R1115     -1.9298050552606583e-02
    z[1,4,6]  R1116     -1.5526151657104492e-01
    z[1,4,6]  R1117     -7.1109756827354431e-02
    z[1,4,6]  R1118     -1.9608356058597565e-01
    z[1,4,6]  R1119     -2.3779530823230743e-01
    z[1,4,6]  R1120     -4.6682038903236389e-01
    z[1,4,6]  R1121     -3.0959886312484741e-01
    z[1,4,6]  R1122     2.9122793674468994e-01
    z[1,4,6]  R1123     1.1080313473939896e-01
    z[1,4,6]  R1124     -6.8453967571258545e-01
    z[1,4,6]  R1125     -4.1320380568504333e-01
    z[1,4,6]  R1126     4.7924613952636719e-01
    z[1,4,6]  R1127     5.4809981584548950e-01
    z[1,4,6]  R1128     -1.1365757137537003e-01
    z[1,4,6]  R1129     -1.4261193573474884e-01
    z[1,4,6]  R1130     -7.7522225677967072e-02
    z[1,4,6]  R1131     -1.8059577047824860e-01
    z[1,4,6]  R1132     -7.2199523448944092e-02
    z[1,4,6]  R1133     1.6902619600296021e-01
    z[1,4,6]  R1134     -2.3229663074016571e-01
    z[1,4,6]  R1135     -2.8217615559697151e-02
    z[1,4,6]  R1136     -2.4007629603147507e-02
    z[1,4,6]  R1137     -1.7738421261310577e-01
    z[1,4,6]  R1138     4.8832595348358154e-01
    z[1,4,6]  R1139     -2.4512539803981781e-01
    z[1,4,6]  R1140     -8.6079455912113190e-02
    z[1,4,6]  R1141     -3.3156612515449524e-01
    z[1,4,6]  R1142     2.8960786759853363e-02
    z[1,4,6]  R1143     -2.5481003522872925e-01
    z[1,4,6]  R1144     1.3467422127723694e-01
    z[1,4,6]  R1145     1.0879641771316528e-01
    z[1,4,6]  R1146     3.0809977650642395e-01
    z[1,4,6]  R1147     3.7304118275642395e-01
    z[1,4,6]  R1148     1.1342987418174744e-01
    z[1,4,6]  R1149     -1.6270875930786133e-01
    z[1,4,6]  R1150     3.9924681186676025e-02
    z[1,4,6]  R1151     -2.3157656192779541e-01
    z[1,4,6]  R1152     3.9496082812547684e-02
    z[1,4,6]  R1153     -2.0244711637496948e-01
    z[1,4,6]  R1154     -3.8225898146629333e-01
    z[1,4,6]  R1155     -2.5455081462860107e-01
    z[1,4,6]  R1156     -3.2446052879095078e-02
    z[1,4,6]  R1157     -2.1736724674701691e-01
    z[1,4,6]  R1158     -1.5648598968982697e-01
    z[1,4,6]  R1159     2.8492954373359680e-01
    z[1,4,6]  R1160     3.1117478013038635e-01
    z[1,4,6]  R1161     -3.0813741683959961e-01
    z[1,4,6]  R1162     -1.0823823511600494e-01
    z[1,4,6]  R1163     -3.7070021033287048e-01
    z[1,4,6]  R1164     4.2664456367492676e-01
    z[1,4,6]  R1165     4.2532593011856079e-01
    z[1,4,6]  R1166     -1.6901694238185883e-01
    z[1,4,6]  R1167     -4.4010091572999954e-02
    z[1,4,6]  R1168     4.6856218576431274e-01
    z[1,4,6]  R1169     2.0871374011039734e-01
    z[1,4,6]  R1170     2.9726946726441383e-02
    z[1,4,6]  R1171     1.9981640577316284e-01
    z[1,4,6]  R1172     1.1819269508123398e-01
    z[1,4,6]  R1173     -5.7206183671951294e-02
    z[1,4,6]  R1174     5.2432626485824585e-01
    z[1,4,6]  R1175     1.7567428946495056e-01
    z[1,4,6]  R1176     5.4454866796731949e-02
    z[1,4,6]  R1177     1.2733514606952667e-01
    z[1,4,6]  R1178     2.4166754155885428e-04
    z[1,4,6]  R1179     -2.7993968129158020e-01
    z[1,4,6]  R1180     1.1713202297687531e-01
    z[1,4,6]  R1181     -1.8819177150726318e-01
    z[1,4,6]  R1182     -1.8090275116264820e-03
    z[1,4,6]  R1183     1.0212234407663345e-01
    z[1,4,6]  R1184     -1.0798142850399017e-01
    z[1,4,6]  R1185     1.6660369932651520e-01
    z[1,4,6]  R1186     -1.1118955910205841e-01
    z[1,4,6]  R1187     2.0655590295791626e-01
    z[1,4,6]  R1188     -7.4333444237709045e-02
    z[1,4,6]  R1189     1.7864930629730225e-01
    z[1,4,6]  R1190     -1.8564037978649139e-01
    z[1,4,6]  R1191     -1.0917651653289795e-01
    z[1,4,6]  R1192     2.7678442001342773e-01
    z[1,4,6]  R1193     1.6901065409183502e-01
    z[1,4,6]  R1194     2.5781095027923584e-01
    z[1,4,6]  R1195     2.4777625501155853e-01
    z[1,4,6]  R1196     -3.5946812480688095e-02
    z[1,4,6]  R1197     -1.0145907104015350e-01
    z[1,4,6]  R1198     6.8740755319595337e-02
    z[1,4,6]  R1199     -2.2169624269008636e-01
    z[1,4,6]  R1200     1.0318201780319214e-01
    z[1,4,6]  R1201     2.4264785461127758e-03
    z[1,4,6]  R1202     7.4183098971843719e-02
    z[1,4,6]  R1203     -7.1695089340209961e-02
    z[1,4,6]  R1204     1.1821021884679794e-01
    z[1,4,6]  R1205     1.2351055443286896e-01
    z[4,1,0]  R11       1
    z[4,1,0]  R38       -1
    z[4,1,0]  R1206     -1
    z[4,1,0]  R1207     1
    z[4,1,0]  R1220     -3.5911047458648682e-01
    z[4,1,0]  R1221     -3.5800606012344360e-01
    z[4,1,0]  R1222     -1.3780531287193298e-01
    z[4,1,0]  R1223     -2.9238942265510559e-01
    z[4,1,0]  R1224     -1.8122249841690063e-01
    z[4,1,0]  R1225     -1.4514103531837463e-01
    z[4,1,0]  R1226     -3.9680501818656921e-01
    z[4,1,0]  R1227     -3.6523446440696716e-01
    z[4,1,0]  R1228     -7.7383734285831451e-02
    z[4,1,0]  R1229     -4.0516808629035950e-01
    z[4,1,0]  R1230     0.942054808139801
    z[4,1,0]  R1231     8.9981865882873535e-01
    z[4,1,0]  R1232     5.8713823556900024e-01
    z[4,1,0]  R1233     6.0660946369171143e-01
    z[4,1,0]  R1234     6.0895085334777832e-01
    z[4,1,0]  R1235     0.65199875831604
    z[4,1,0]  R1236     5.9659922122955322e-01
    z[4,1,0]  R1237     1.1463463306427002e-01
    z[4,1,0]  R1238     5.4364860057830811e-01
    z[4,1,0]  R1239     2.2304007411003113e-01
    z[4,1,0]  R1240     -0.943132221698761
    z[4,1,0]  R1241     -4.1723379492759705e-01
    z[4,1,0]  R1242     3.8019508123397827e-01
    z[4,1,0]  R1243     4.4824984669685364e-01
    z[4,1,0]  R1244     5.2685993909835815e-01
    z[4,1,0]  R1245     9.4603672623634338e-02
    z[4,1,0]  R1246     -2.4945980310440063e-01
    z[4,1,0]  R1247     -2.7539214491844177e-01
    z[4,1,0]  R1248     1.0563543438911438e-01
    z[4,1,0]  R1249     7.7304452657699585e-02
    z[4,1,0]  R1250     -9.3091838061809540e-02
    z[4,1,0]  R1251     -5.1429796218872070e-01
    z[4,1,0]  R1252     6.5010762214660645e-01
    z[4,1,0]  R1253     -1.0805778205394745e-02
    z[4,1,0]  R1254     1.4774626493453979e-01
    z[4,1,0]  R1255     1.1612449586391449e-01
    z[4,1,0]  R1256     3.6412292718887329e-01
    z[4,1,0]  R1257     5.1719751209020615e-02
    z[4,1,0]  R1258     -9.9702635779976845e-03
    z[4,1,0]  R1259     -5.7827834039926529e-02
    z[4,1,0]  R1260     3.3384832739830017e-01
    z[4,1,0]  R1261     -1.3449686765670776e-01
    z[4,1,0]  R1262     -8.7584452703595161e-03
    z[4,1,0]  R1263     4.8221364617347717e-01
    z[4,1,0]  R1264     8.4913492202758789e-02
    z[4,1,0]  R1265     -3.2118913531303406e-01
    z[4,1,0]  R1266     2.1783185005187988e-01
    z[4,1,0]  R1267     2.6415199041366577e-01
    z[4,1,0]  R1268     1.2744180858135223e-01
    z[4,1,0]  R1269     1.4033287763595581e-01
    z[4,1,0]  R1270     -5.4846620559692383e-01
    z[4,1,0]  R1271     -5.3737568855285645e-01
    z[4,1,0]  R1272     -3.4947690367698669e-01
    z[4,1,0]  R1273     -3.8337504863739014e-01
    z[4,1,0]  R1274     -3.3478114008903503e-01
    z[4,1,0]  R1275     -2.9309570789337158e-01
    z[4,1,0]  R1276     -4.8481833934783936e-01
    z[4,1,0]  R1277     -5.7584816217422485e-01
    z[4,1,0]  R1278     2.5187286734580994e-01
    z[4,1,0]  R1279     4.6663612127304077e-02
    z[4,1,0]  R1280     9.1005897521972656e-01
    z[4,1,0]  R1281     1.3805174827575684e-01
    z[4,1,0]  R1282     4.7126758098602295e-01
    z[4,1,0]  R1283     4.3676313757896423e-01
    z[4,1,0]  R1284     0.534625232219696
    z[4,1,0]  R1285     7.4053883552551270e-01
    z[4,1,0]  R1286     7.1643579006195068e-01
    z[4,1,0]  R1287     6.3351887464523315e-01
    z[4,1,0]  R1288     8.7949562072753906e-01
    z[4,1,0]  R1289     7.2757941484451294e-01
    z[4,1,0]  R1290     -8.9046663045883179e-01
    z[4,1,0]  R1291     -7.7508997917175293e-01
    z[4,1,0]  R1292     -5.2592891454696655e-01
    z[4,1,0]  R1293     -7.9635888338088989e-01
    z[4,1,0]  R1294     -6.9828587770462036e-01
    z[4,1,0]  R1295     -6.2233519554138184e-01
    z[4,1,0]  R1296     -5.0729984045028687e-01
    z[4,1,0]  R1297     3.2287669181823730e-01
    z[4,1,0]  R1298     2.2204083204269409e-01
    z[4,1,0]  R1299     4.0584060549736023e-01
    z[4,1,0]  R1300     -4.2859551310539246e-01
    z[4,1,0]  R1301     -5.0588089227676392e-01
    z[4,1,0]  R1302     -6.6504962742328644e-02
    z[4,1,0]  R1303     9.3613542616367340e-02
    z[4,1,0]  R1304     1.6056878864765167e-01
    z[4,1,0]  R1305     1.9732825458049774e-01
    z[4,1,0]  R1306     5.2592545747756958e-01
    z[4,1,0]  R1307     3.2273855805397034e-01
    z[4,1,0]  R1308     0.145841583609581
    z[4,1,0]  R1309     1.4634659886360168e-01
    z[4,1,0]  R1310     -4.9644985795021057e-01
    z[4,1,0]  R1311     -5.6475734710693359e-01
    z[4,1,0]  R1312     -4.7109922766685486e-01
    z[4,1,0]  R1313     5.1703029870986938e-01
    z[4,1,0]  R1314     4.9828074872493744e-02
    z[4,1,0]  R1315     -6.4766839146614075e-02
    z[4,1,0]  R1316     3.1029042601585388e-01
    z[4,1,0]  R1317     2.6755779981613159e-01
    z[4,1,0]  R1318     4.5220926403999329e-01
    z[4,1,0]  R1319     7.0565128326416016e-01
    z[4,1,0]  R1320     -7.2389864921569824e-01
    z[4,1,0]  R1321     4.7058889269828796e-01
    z[4,1,0]  R1322     3.2659158110618591e-01
    z[4,1,0]  R1323     2.9244866967201233e-01
    z[4,1,0]  R1324     1.8340951204299927e-01
    z[4,1,0]  R1325     1.1921054124832153e-01
    z[4,1,0]  R1326     4.4222906231880188e-01
    z[4,1,0]  R1327     4.4989496469497681e-01
    z[4,1,0]  R1328     0.354343980550766
    z[4,1,0]  R1329     4.8459321260452271e-01
    z[4,1,1]  R12       1
    z[4,1,1]  R39       -1
    z[4,1,1]  R1208     -1
    z[4,1,1]  R1209     1
    z[4,1,1]  R1220     3.9992593228816986e-02
    z[4,1,1]  R1221     8.8066153228282928e-02
    z[4,1,1]  R1222     -1.4184577763080597e-01
    z[4,1,1]  R1223     1.9708101451396942e-01
    z[4,1,1]  R1224     1.9181822240352631e-01
    z[4,1,1]  R1225     1.7235554754734039e-01
    z[4,1,1]  R1226     1.0931375622749329e-01
    z[4,1,1]  R1227     0.334354430437088
    z[4,1,1]  R1228     1.9728232920169830e-01
    z[4,1,1]  R1229     1.5075589530169964e-02
    z[4,1,1]  R1230     5.3768295794725418e-02
    z[4,1,1]  R1231     2.5043004751205444e-01
    z[4,1,1]  R1232     0.412627249956131
    z[4,1,1]  R1233     -4.2724588513374329e-01
    z[4,1,1]  R1234     -7.0076274871826172e-01
    z[4,1,1]  R1235     -6.1578017473220825e-01
    z[4,1,1]  R1236     -7.4422496557235718e-01
    z[4,1,1]  R1237     -3.5293185710906982e-01
    z[4,1,1]  R1238     -5.6348502635955811e-01
    z[4,1,1]  R1239     -3.0520507693290710e-01
    z[4,1,1]  R1240     2.6929962635040283e-01
    z[4,1,1]  R1241     0.547633171081543
    z[4,1,1]  R1242     -3.4225234389305115e-01
    z[4,1,1]  R1243     -3.7711513042449951e-01
    z[4,1,1]  R1244     5.0179883837699890e-02
    z[4,1,1]  R1245     4.6545788645744324e-02
    z[4,1,1]  R1246     -4.1894862055778503e-01
    z[4,1,1]  R1247     -0.589698076248169
    z[4,1,1]  R1248     -2.8642225265502930e-01
    z[4,1,1]  R1249     0.365046888589859
    z[4,1,1]  R1250     7.0368468761444092e-01
    z[4,1,1]  R1251     6.3230073451995850e-01
    z[4,1,1]  R1252     5.2852157503366470e-02
    z[4,1,1]  R1253     -3.5425764322280884e-01
    z[4,1,1]  R1254     -0.572669506072998
    z[4,1,1]  R1255     3.5959962755441666e-02
    z[4,1,1]  R1256     6.5954573452472687e-02
    z[4,1,1]  R1257     -3.4190490841865540e-01
    z[4,1,1]  R1258     -1.7867447435855865e-01
    z[4,1,1]  R1259     -2.2493988275527954e-01
    z[4,1,1]  R1260     -2.8695452213287354e-01
    z[4,1,1]  R1261     -5.7241046428680420e-01
    z[4,1,1]  R1262     -3.8586992025375366e-01
    z[4,1,1]  R1263     -2.0042078197002411e-01
    z[4,1,1]  R1264     -1.7952386289834976e-02
    z[4,1,1]  R1265     -1.3532178103923798e-01
    z[4,1,1]  R1266     0.408532053232193
    z[4,1,1]  R1267     -0.789068877696991
    z[4,1,1]  R1268     -0.81621253490448
    z[4,1,1]  R1269     -7.4622911214828491e-01
    z[4,1,1]  R1270     3.8442826271057129e-01
    z[4,1,1]  R1271     -2.6387885212898254e-01
    z[4,1,1]  R1272     3.1713566184043884e-01
    z[4,1,1]  R1273     -6.0303714126348495e-03
    z[4,1,1]  R1274     2.7103728055953979e-01
    z[4,1,1]  R1275     1.1794888228178024e-01
    z[4,1,1]  R1276     1.6418954730033875e-01
    z[4,1,1]  R1277     4.1713860630989075e-01
    z[4,1,1]  R1278     -6.7177355289459229e-01
    z[4,1,1]  R1279     -6.6847103834152222e-01
    z[4,1,1]  R1280     2.9807296395301819e-01
    z[4,1,1]  R1281     2.4385875463485718e-01
    z[4,1,1]  R1282     -3.8807126879692078e-01
    z[4,1,1]  R1283     3.3396932482719421e-01
    z[4,1,1]  R1284     3.5263964533805847e-01
    z[4,1,1]  R1285     2.4720968306064606e-01
    z[4,1,1]  R1286     -3.7510228157043457e-01
    z[4,1,1]  R1287     -5.7581549882888794e-01
    z[4,1,1]  R1288     1.4785762131214142e-01
    z[4,1,1]  R1289     -3.0817532539367676e-01
    z[4,1,1]  R1290     -2.1939820051193237e-01
    z[4,1,1]  R1291     1.9416160881519318e-01
    z[4,1,1]  R1292     4.9348825216293335e-01
    z[4,1,1]  R1293     -1.4357546344399452e-02
    z[4,1,1]  R1294     -7.9884245991706848e-02
    z[4,1,1]  R1295     1.5804682672023773e-01
    z[4,1,1]  R1296     1.9286023080348969e-01
    z[4,1,1]  R1297     6.6589933633804321e-01
    z[4,1,1]  R1298     -4.4424888491630554e-01
    z[4,1,1]  R1299     -4.4897049665451050e-02
    z[4,1,1]  R1300     4.5701089501380920e-01
    z[4,1,1]  R1301     6.6072843968868256e-02
    z[4,1,1]  R1302     -6.2168675661087036e-01
    z[4,1,1]  R1303     -7.2063046693801880e-01
    z[4,1,1]  R1304     -1.4998872578144073e-01
    z[4,1,1]  R1305     -2.9883316159248352e-01
    z[4,1,1]  R1306     -4.1531211137771606e-01
    z[4,1,1]  R1307     -3.4737905859947205e-01
    z[4,1,1]  R1308     -2.5700709223747253e-01
    z[4,1,1]  R1309     0.885625422000885
    z[4,1,1]  R1310     5.2399653196334839e-01
    z[4,1,1]  R1311     6.6193324327468872e-01
    z[4,1,1]  R1312     2.1502195298671722e-01
    z[4,1,1]  R1313     -3.4582906961441040e-01
    z[4,1,1]  R1314     -0.293354332447052
    z[4,1,1]  R1315     -5.0657910108566284e-01
    z[4,1,1]  R1316     -5.3950250148773193e-01
    z[4,1,1]  R1317     -1.9510462880134583e-01
    z[4,1,1]  R1318     -3.7244316935539246e-01
    z[4,1,1]  R1319     -1.6403743624687195e-01
    z[4,1,1]  R1320     -3.8011498749256134e-02
    z[4,1,1]  R1321     -2.4596635997295380e-01
    z[4,1,1]  R1322     -8.6322838068008423e-01
    z[4,1,1]  R1323     -9.1503816843032837e-01
    z[4,1,1]  R1324     -9.3509048223495483e-01
    z[4,1,1]  R1325     -8.8453543186187744e-01
    z[4,1,1]  R1326     -7.9997146129608154e-01
    z[4,1,1]  R1327     -7.4838405847549438e-01
    z[4,1,1]  R1328     -0.752017617225647
    z[4,1,1]  R1329     -7.7209919691085815e-01
    z[4,1,2]  R13       1
    z[4,1,2]  R40       -1
    z[4,1,2]  R1210     -1
    z[4,1,2]  R1211     1
    z[4,1,2]  R1220     7.0885759592056274e-01
    z[4,1,2]  R1221     7.2918081283569336e-01
    z[4,1,2]  R1222     0.774948239326477
    z[4,1,2]  R1223     8.6175012588500977e-01
    z[4,1,2]  R1224     -0.421764612197876
    z[4,1,2]  R1225     -0.676142156124115
    z[4,1,2]  R1226     4.2299043387174606e-02
    z[4,1,2]  R1227     1.0496312379837036e-01
    z[4,1,2]  R1228     -4.2408052086830139e-01
    z[4,1,2]  R1229     4.8272809386253357e-01
    z[4,1,2]  R1230     7.6136313378810883e-02
    z[4,1,2]  R1231     -1.1208809167146683e-01
    z[4,1,2]  R1232     -0.0673513412475586
    z[4,1,2]  R1233     -3.7408652901649475e-01
    z[4,1,2]  R1234     -1.6330179572105408e-01
    z[4,1,2]  R1235     -7.6653786003589630e-02
    z[4,1,2]  R1236     -2.0851986110210419e-01
    z[4,1,2]  R1237     -5.0066363811492920e-01
    z[4,1,2]  R1238     -1.8591651320457458e-01
    z[4,1,2]  R1239     -5.1453369855880737e-01
    z[4,1,2]  R1240     -1.3060493767261505e-01
    z[4,1,2]  R1241     -8.7851323187351227e-02
    z[4,1,2]  R1242     -0.742438793182373
    z[4,1,2]  R1243     -4.8063719272613525e-01
    z[4,1,2]  R1244     -6.5481591224670410e-01
    z[4,1,2]  R1245     -3.4209641814231873e-01
    z[4,1,2]  R1246     -7.1385228633880615e-01
    z[4,1,2]  R1247     -6.4999693632125854e-01
    z[4,1,2]  R1248     -0.809843122959137
    z[4,1,2]  R1249     -6.0245621204376221e-01
    z[4,1,2]  R1250     4.5894297957420349e-01
    z[4,1,2]  R1251     1.1132667958736420e-01
    z[4,1,2]  R1252     -6.6455513238906860e-01
    z[4,1,2]  R1253     -5.2812069654464722e-01
    z[4,1,2]  R1254     -5.6795650720596313e-01
    z[4,1,2]  R1255     -6.9453239440917969e-01
    z[4,1,2]  R1256     -0.555451512336731
    z[4,1,2]  R1257     -7.9939246177673340e-01
    z[4,1,2]  R1258     -6.5235203504562378e-01
    z[4,1,2]  R1259     -6.0514295101165771e-01
    z[4,1,2]  R1260     -7.2713285684585571e-01
    z[4,1,2]  R1261     -7.5922089815139771e-01
    z[4,1,2]  R1262     -5.8087509870529175e-01
    z[4,1,2]  R1263     -7.8284674882888794e-01
    z[4,1,2]  R1264     -7.4088609218597412e-01
    z[4,1,2]  R1265     -0.635337233543396
    z[4,1,2]  R1266     -3.9858633279800415e-01
    z[4,1,2]  R1267     4.3616119772195816e-02
    z[4,1,2]  R1268     1.5644568204879761e-01
    z[4,1,2]  R1269     -9.8282612860202789e-02
    z[4,1,2]  R1270     4.0556451678276062e-01
    z[4,1,2]  R1271     5.7136386632919312e-01
    z[4,1,2]  R1272     6.8847596645355225e-01
    z[4,1,2]  R1273     2.0886674523353577e-01
    z[4,1,2]  R1274     -1.5248348005115986e-02
    z[4,1,2]  R1275     5.3124696016311646e-01
    z[4,1,2]  R1276     -2.1343810856342316e-01
    z[4,1,2]  R1277     -2.7728474140167236e-01
    z[4,1,2]  R1278     -1.0162437707185745e-01
    z[4,1,2]  R1279     -2.3174107074737549e-01
    z[4,1,2]  R1280     -1.1740779131650925e-01
    z[4,1,2]  R1281     -6.8835496902465820e-01
    z[4,1,2]  R1282     5.9588211774826050e-01
    z[4,1,2]  R1283     -6.0378080606460571e-01
    z[4,1,2]  R1284     -3.1660494208335876e-01
    z[4,1,2]  R1285     -4.0137115865945816e-02
    z[4,1,2]  R1286     2.5910025835037231e-01
    z[4,1,2]  R1287     4.1383656859397888e-01
    z[4,1,2]  R1288     -2.9499918222427368e-01
    z[4,1,2]  R1289     3.6738941073417664e-01
    z[4,1,2]  R1290     -1.9834670424461365e-01
    z[4,1,2]  R1291     -3.6132711917161942e-02
    z[4,1,2]  R1292     2.9677665233612061e-01
    z[4,1,2]  R1293     2.6175066828727722e-01
    z[4,1,2]  R1294     -1.4722524583339691e-01
    z[4,1,2]  R1295     -2.3189820349216461e-01
    z[4,1,2]  R1296     -7.4641996622085571e-01
    z[4,1,2]  R1297     -5.8503359556198120e-01
    z[4,1,2]  R1298     -1.5049757063388824e-01
    z[4,1,2]  R1299     4.7004982829093933e-02
    z[4,1,2]  R1300     -4.8428988456726074e-01
    z[4,1,2]  R1301     -2.0427714288234711e-01
    z[4,1,2]  R1302     1.7326584085822105e-02
    z[4,1,2]  R1303     -2.0517694950103760e-01
    z[4,1,2]  R1304     -6.6344380378723145e-02
    z[4,1,2]  R1305     1.9156554341316223e-01
    z[4,1,2]  R1306     0.0657258853316307
    z[4,1,2]  R1307     -4.1535636410117149e-03
    z[4,1,2]  R1308     -2.2964255511760712e-01
    z[4,1,2]  R1309     -1.2464547902345657e-01
    z[4,1,2]  R1310     -5.8535808324813843e-01
    z[4,1,2]  R1311     -2.8683599829673767e-01
    z[4,1,2]  R1312     -4.8880372196435928e-02
    z[4,1,2]  R1313     -2.0156674087047577e-01
    z[4,1,2]  R1314     -2.2471249103546143e-01
    z[4,1,2]  R1315     -3.3468988537788391e-01
    z[4,1,2]  R1316     1.8343251943588257e-01
    z[4,1,2]  R1317     -2.5035008788108826e-01
    z[4,1,2]  R1318     2.0671902596950531e-01
    z[4,1,2]  R1319     -0.0722411647439003
    z[4,1,2]  R1320     -5.3254854679107666e-01
    z[4,1,2]  R1321     -1.6451023519039154e-01
    z[4,1,2]  R1322     1.6175574064254761e-01
    z[4,1,2]  R1323     0.000609697075560689
    z[4,1,2]  R1324     -5.0387654453516006e-02
    z[4,1,2]  R1325     2.9645591974258423e-01
    z[4,1,2]  R1326     -3.1568646430969238e-01
    z[4,1,2]  R1327     3.7175349891185760e-02
    z[4,1,2]  R1328     3.4580063819885254e-01
    z[4,1,2]  R1329     1.1843249201774597e-01
    z[4,1,3]  R14       1
    z[4,1,3]  R41       -1
    z[4,1,3]  R1212     -1
    z[4,1,3]  R1213     1
    z[4,1,3]  R1220     1.5453018248081207e-01
    z[4,1,3]  R1221     2.4318028986454010e-01
    z[4,1,3]  R1222     -6.6407345235347748e-02
    z[4,1,3]  R1223     3.7617892958223820e-03
    z[4,1,3]  R1224     7.7589273452758789e-01
    z[4,1,3]  R1225     4.9217936396598816e-01
    z[4,1,3]  R1226     8.0812788009643555e-01
    z[4,1,3]  R1227     9.9210254848003387e-02
    z[4,1,3]  R1228     2.9624202847480774e-01
    z[4,1,3]  R1229     -5.8686983585357666e-01
    z[4,1,3]  R1230     2.3793120682239532e-01
    z[4,1,3]  R1231     1.7997060716152191e-01
    z[4,1,3]  R1232     -2.1408474445343018e-01
    z[4,1,3]  R1233     -3.9325478672981262e-01
    z[4,1,3]  R1234     -2.1021410822868347e-01
    z[4,1,3]  R1235     -3.5917416214942932e-01
    z[4,1,3]  R1236     1.9981622695922852e-02
    z[4,1,3]  R1237     -5.4983055591583252e-01
    z[4,1,3]  R1238     1.9537252373993397e-03
    z[4,1,3]  R1239     -5.0493568181991577e-01
    z[4,1,3]  R1240     2.7512183412909508e-02
    z[4,1,3]  R1241     5.0766932964324951e-01
    z[4,1,3]  R1242     -2.9457315802574158e-01
    z[4,1,3]  R1243     -4.6839483082294464e-02
    z[4,1,3]  R1244     -4.3036738038063049e-01
    z[4,1,3]  R1245     -0.267819881439209
    z[4,1,3]  R1246     -3.9078226685523987e-01
    z[4,1,3]  R1247     -2.8767085075378418e-01
    z[4,1,3]  R1248     -3.8902035355567932e-01
    z[4,1,3]  R1249     -0.190802201628685
    z[4,1,3]  R1250     5.1662659645080566e-01
    z[4,1,3]  R1251     1.0520192235708237e-01
    z[4,1,3]  R1252     -2.2982361912727356e-01
    z[4,1,3]  R1253     -5.8106422424316406e-01
    z[4,1,3]  R1254     -3.6560976505279541e-01
    z[4,1,3]  R1255     -6.9852042198181152e-01
    z[4,1,3]  R1256     -3.0261768028140068e-02
    z[4,1,3]  R1257     -6.6269993782043457e-02
    z[4,1,3]  R1258     -6.4941161870956421e-01
    z[4,1,3]  R1259     8.2603186368942261e-02
    z[4,1,3]  R1260     -2.2602368891239166e-01
    z[4,1,3]  R1261     -1.2361246347427368e-01
    z[4,1,3]  R1262     -5.3486543893814087e-01
    z[4,1,3]  R1263     -1.1051447689533234e-01
    z[4,1,3]  R1264     -6.4729940891265869e-01
    z[4,1,3]  R1265     -3.4381550550460815e-01
    z[4,1,3]  R1266     -3.5488963127136230e-01
    z[4,1,3]  R1267     0.317862868309021
    z[4,1,3]  R1268     1.6077440977096558e-01
    z[4,1,3]  R1269     4.6951431035995483e-01
    z[4,1,3]  R1270     3.9904925227165222e-01
    z[4,1,3]  R1271     -4.4947284460067749e-01
    z[4,1,3]  R1272     -2.5990280508995056e-01
    z[4,1,3]  R1273     -3.9733633399009705e-01
    z[4,1,3]  R1274     -2.7447342872619629e-01
    z[4,1,3]  R1275     -5.7482278347015381e-01
    z[4,1,3]  R1276     -6.4267545938491821e-01
    z[4,1,3]  R1277     -2.6924726553261280e-03
    z[4,1,3]  R1278     -4.3043103814125061e-01
    z[4,1,3]  R1279     -5.6083846092224121e-01
    z[4,1,3]  R1280     -4.9707889556884766e-03
    z[4,1,3]  R1281     5.6251049041748047e-01
    z[4,1,3]  R1282     4.5717990398406982e-01
    z[4,1,3]  R1283     5.6790667772293091e-01
    z[4,1,3]  R1284     6.6686850786209106e-01
    z[4,1,3]  R1285     4.8297506570816040e-01
    z[4,1,3]  R1286     4.2766058444976807e-01
    z[4,1,3]  R1287     2.0888186991214752e-01
    z[4,1,3]  R1288     2.5776371359825134e-01
    z[4,1,3]  R1289     2.2306315600872040e-01
    z[4,1,3]  R1290     -1.1081153899431229e-01
    z[4,1,3]  R1291     -0.454868882894516
    z[4,1,3]  R1292     -4.9220845103263855e-01
    z[4,1,3]  R1293     0.456521600484848
    z[4,1,3]  R1294     0.0790027603507042
    z[4,1,3]  R1295     5.3736311197280884e-01
    z[4,1,3]  R1296     1.2507483363151550e-01
    z[4,1,3]  R1297     3.1046831607818604e-01
    z[4,1,3]  R1298     -4.5002856850624084e-01
    z[4,1,3]  R1299     -7.8516000509262085e-01
    z[4,1,3]  R1300     -0.120479054749012
    z[4,1,3]  R1301     8.1015847623348236e-02
    z[4,1,3]  R1302     -5.2535998821258545e-01
    z[4,1,3]  R1303     -4.3817153573036194e-01
    z[4,1,3]  R1304     -7.7117341756820679e-01
    z[4,1,3]  R1305     -6.7462337017059326e-01
    z[4,1,3]  R1306     -3.9227211475372314e-01
    z[4,1,3]  R1307     -6.4566022157669067e-01
    z[4,1,3]  R1308     -8.5562658309936523e-01
    z[4,1,3]  R1309     9.8151132464408875e-02
    z[4,1,3]  R1310     3.6296206712722778e-01
    z[4,1,3]  R1311     1.9905048608779907e-01
    z[4,1,3]  R1312     1.3431535661220551e-01
    z[4,1,3]  R1313     -6.5590482950210571e-01
    z[4,1,3]  R1314     -7.0590674877166748e-01
    z[4,1,3]  R1315     -4.9436318874359131e-01
    z[4,1,3]  R1316     -7.5713771581649780e-01
    z[4,1,3]  R1317     -8.6876374483108521e-01
    z[4,1,3]  R1318     -5.4235792160034180e-01
    z[4,1,3]  R1319     -6.7413049936294556e-01
    z[4,1,3]  R1320     8.8837943971157074e-02
    z[4,1,3]  R1321     -7.3519039154052734e-01
    z[4,1,3]  R1322     -1.9255171716213226e-01
    z[4,1,3]  R1323     1.3584984838962555e-01
    z[4,1,3]  R1324     2.1812172234058380e-01
    z[4,1,3]  R1325     9.1849960386753082e-02
    z[4,1,3]  R1326     1.8861801922321320e-01
    z[4,1,3]  R1327     -2.7884244918823242e-01
    z[4,1,3]  R1328     1.2510600499808788e-02
    z[4,1,3]  R1329     -2.7186835184693336e-02
    z[4,1,4]  R15       1
    z[4,1,4]  R42       -1
    z[4,1,4]  R1214     -1
    z[4,1,4]  R1215     1
    z[4,1,4]  R1220     0.584718644618988
    z[4,1,4]  R1221     1.1929895728826523e-01
    z[4,1,4]  R1222     4.4568312168121338e-01
    z[4,1,4]  R1223     -1.9457225501537323e-01
    z[4,1,4]  R1224     -2.3900421336293221e-02
    z[4,1,4]  R1225     -3.1577959656715393e-01
    z[4,1,4]  R1226     -3.5803741216659546e-01
    z[4,1,4]  R1227     6.9361424446105957e-01
    z[4,1,4]  R1228     -0.651825487613678
    z[4,1,4]  R1229     1.3738542795181274e-01
    z[4,1,4]  R1230     -1.3454273343086243e-01
    z[4,1,4]  R1231     1.5022955834865570e-01
    z[4,1,4]  R1232     0.452536016702652
    z[4,1,4]  R1233     3.3214700222015381e-01
    z[4,1,4]  R1234     2.2784835100173950e-01
    z[4,1,4]  R1235     -1.3697463274002075e-01
    z[4,1,4]  R1236     1.7680658400058746e-01
    z[4,1,4]  R1237     -4.9967506527900696e-01
    z[4,1,4]  R1238     2.7726349234580994e-01
    z[4,1,4]  R1239     -4.2929565906524658e-01
    z[4,1,4]  R1240     -7.9094909131526947e-02
    z[4,1,4]  R1241     8.4954008460044861e-02
    z[4,1,4]  R1242     -3.1500864028930664e-01
    z[4,1,4]  R1243     -4.3252453207969666e-01
    z[4,1,4]  R1244     -8.6337188258767128e-03
    z[4,1,4]  R1245     -6.2996000051498413e-01
    z[4,1,4]  R1246     8.6528457701206207e-02
    z[4,1,4]  R1247     -2.3535829782485962e-01
    z[4,1,4]  R1248     2.9225587844848633e-01
    z[4,1,4]  R1249     -4.7899162769317627e-01
    z[4,1,4]  R1250     5.1167141646146774e-02
    z[4,1,4]  R1251     2.7436983585357666e-01
    z[4,1,4]  R1252     -1.1434942483901978e-01
    z[4,1,4]  R1253     -4.6427333354949951e-01
    z[4,1,4]  R1254     9.7543504089117050e-03
    z[4,1,4]  R1255     3.3553630113601685e-02
    z[4,1,4]  R1256     -4.8827984929084778e-01
    z[4,1,4]  R1257     9.5876671373844147e-02
    z[4,1,4]  R1258     -1.2067833542823792e-01
    z[4,1,4]  R1259     -4.4259798526763916e-01
    z[4,1,4]  R1260     -4.3967342376708984e-01
    z[4,1,4]  R1261     -1.3392937183380127e-01
    z[4,1,4]  R1262     -4.1266137361526489e-01
    z[4,1,4]  R1263     2.2943212091922760e-01
    z[4,1,4]  R1264     -1.1504572629928589e-01
    z[4,1,4]  R1265     -3.9065372943878174e-01
    z[4,1,4]  R1266     -6.8254613876342773e-01
    z[4,1,4]  R1267     -3.9675071835517883e-01
    z[4,1,4]  R1268     -4.9660202860832214e-01
    z[4,1,4]  R1269     -3.6722466349601746e-01
    z[4,1,4]  R1270     -3.1760153174400330e-01
    z[4,1,4]  R1271     1.2788502871990204e-01
    z[4,1,4]  R1272     -4.5941525697708130e-01
    z[4,1,4]  R1273     -4.5679351687431335e-01
    z[4,1,4]  R1274     -6.8453729152679443e-01
    z[4,1,4]  R1275     -2.0277164876461029e-02
    z[4,1,4]  R1276     5.1528328657150269e-01
    z[4,1,4]  R1277     5.8601063489913940e-01
    z[4,1,4]  R1278     3.4970134496688843e-01
    z[4,1,4]  R1279     2.0519576966762543e-01
    z[4,1,4]  R1280     -2.5997087359428406e-02
    z[4,1,4]  R1281     -3.1932753324508667e-01
    z[4,1,4]  R1282     -2.0619036257266998e-01
    z[4,1,4]  R1283     2.2363530471920967e-02
    z[4,1,4]  R1284     2.4442672729492188e-02
    z[4,1,4]  R1285     -2.2545643150806427e-01
    z[4,1,4]  R1286     -2.4691025912761688e-01
    z[4,1,4]  R1287     -1.8389484286308289e-01
    z[4,1,4]  R1288     6.4173959195613861e-02
    z[4,1,4]  R1289     -4.2985841631889343e-01
    z[4,1,4]  R1290     2.8474089503288269e-01
    z[4,1,4]  R1291     -1.8321696668863297e-02
    z[4,1,4]  R1292     1.2423494458198547e-01
    z[4,1,4]  R1293     -0.0837835893034935
    z[4,1,4]  R1294     -4.8522930592298508e-02
    z[4,1,4]  R1295     -2.8666019439697266e-01
    z[4,1,4]  R1296     -2.0664894580841064e-01
    z[4,1,4]  R1297     -3.7180971354246140e-02
    z[4,1,4]  R1298     -9.1457515954971313e-02
    z[4,1,4]  R1299     -8.6750283837318420e-02
    z[4,1,4]  R1300     1.3383789360523224e-01
    z[4,1,4]  R1301     -6.1846762895584106e-01
    z[4,1,4]  R1302     -9.6565060317516327e-02
    z[4,1,4]  R1303     -3.8908189535140991e-01
    z[4,1,4]  R1304     -1.9357408583164215e-01
    z[4,1,4]  R1305     -1.5970006585121155e-01
    z[4,1,4]  R1306     -3.8437676429748535e-01
    z[4,1,4]  R1307     -4.9526163935661316e-01
    z[4,1,4]  R1308     2.0835416018962860e-01
    z[4,1,4]  R1309     -2.9163017868995667e-01
    z[4,1,4]  R1310     0.0585007481276989
    z[4,1,4]  R1311     2.9259911179542542e-01
    z[4,1,4]  R1312     -6.8360525369644165e-01
    z[4,1,4]  R1313     -0.242141455411911
    z[4,1,4]  R1314     -2.4339766800403595e-01
    z[4,1,4]  R1315     -1.4195046387612820e-02
    z[4,1,4]  R1316     -0.0697336345911026
    z[4,1,4]  R1317     -7.0744507014751434e-02
    z[4,1,4]  R1318     -1.7798207700252533e-01
    z[4,1,4]  R1319     -3.3123213797807693e-03
    z[4,1,4]  R1320     -2.9495945572853088e-01
    z[4,1,4]  R1321     9.0996541082859039e-02
    z[4,1,4]  R1322     -2.4021466076374054e-01
    z[4,1,4]  R1323     -1.0266276448965073e-01
    z[4,1,4]  R1324     -1.9709125161170959e-01
    z[4,1,4]  R1325     1.9474083185195923e-01
    z[4,1,4]  R1326     -1.4570684731006622e-01
    z[4,1,4]  R1327     7.8483283519744873e-02
    z[4,1,4]  R1328     5.5651620030403137e-02
    z[4,1,4]  R1329     2.9908114671707153e-01
    z[4,1,5]  R16       1
    z[4,1,5]  R43       -1
    z[4,1,5]  R1216     -1
    z[4,1,5]  R1217     1
    z[4,1,5]  R1220     1.1528528295457363e-02
    z[4,1,5]  R1221     0.46016725897789
    z[4,1,5]  R1222     3.6443573236465454e-01
    z[4,1,5]  R1223     -1.1830856651067734e-01
    z[4,1,5]  R1224     2.3036555945873260e-01
    z[4,1,5]  R1225     2.3484787344932556e-01
    z[4,1,5]  R1226     1.8928836286067963e-01
    z[4,1,5]  R1227     3.3975234627723694e-01
    z[4,1,5]  R1228     2.8387647867202759e-01
    z[4,1,5]  R1229     -2.4164432287216187e-01
    z[4,1,5]  R1230     2.3776585236191750e-02
    z[4,1,5]  R1231     -2.4114778637886047e-01
    z[4,1,5]  R1232     1.0148690640926361e-01
    z[4,1,5]  R1233     3.1827643513679504e-02
    z[4,1,5]  R1234     -1.2022651731967926e-01
    z[4,1,5]  R1235     -4.6280834823846817e-02
    z[4,1,5]  R1236     -3.2995335757732391e-02
    z[4,1,5]  R1237     -2.3742890357971191e-01
    z[4,1,5]  R1238     -2.3853017017245293e-02
    z[4,1,5]  R1239     -3.4963092207908630e-01
    z[4,1,5]  R1240     1.0461068153381348e-01
    z[4,1,5]  R1241     -4.8696655035018921e-01
    z[4,1,5]  R1242     3.3102143555879593e-02
    z[4,1,5]  R1243     -3.9775168895721436e-01
    z[4,1,5]  R1244     -3.0349004268646240e-01
    z[4,1,5]  R1245     -6.0651499032974243e-01
    z[4,1,5]  R1246     -3.0408149957656860e-01
    z[4,1,5]  R1247     7.3091499507427216e-02
    z[4,1,5]  R1248     5.0470467656850815e-02
    z[4,1,5]  R1249     -4.5190271735191345e-01
    z[4,1,5]  R1250     -6.0405898839235306e-02
    z[4,1,5]  R1251     -4.4078135490417480e-01
    z[4,1,5]  R1252     -2.4801802635192871e-01
    z[4,1,5]  R1253     1.0184463113546371e-01
    z[4,1,5]  R1254     -3.9927187561988831e-01
    z[4,1,5]  R1255     4.3250724673271179e-02
    z[4,1,5]  R1256     -4.8846244812011719e-01
    z[4,1,5]  R1257     -4.4637325406074524e-01
    z[4,1,5]  R1258     -1.9911728799343109e-01
    z[4,1,5]  R1259     -5.6191688776016235e-01
    z[4,1,5]  R1260     -1.7829376459121704e-01
    z[4,1,5]  R1261     -1.8528230488300323e-01
    z[4,1,5]  R1262     2.2916388511657715e-01
    z[4,1,5]  R1263     2.1229531615972519e-02
    z[4,1,5]  R1264     -2.6011077687144279e-02
    z[4,1,5]  R1265     -4.5171543955802917e-01
    z[4,1,5]  R1266     -1.7164134979248047e-01
    z[4,1,5]  R1267     2.0519137382507324e-01
    z[4,1,5]  R1268     8.1515289843082428e-02
    z[4,1,5]  R1269     -2.0793452858924866e-01
    z[4,1,5]  R1270     -3.3961209654808044e-01
    z[4,1,5]  R1271     1.8544797599315643e-01
    z[4,1,5]  R1272     1.1440439522266388e-01
    z[4,1,5]  R1273     6.5428024530410767e-01
    z[4,1,5]  R1274     4.4936504960060120e-01
    z[4,1,5]  R1275     -3.0648830533027649e-01
    z[4,1,5]  R1276     1.1762021481990814e-01
    z[4,1,5]  R1277     -2.5380519032478333e-01
    z[4,1,5]  R1278     -3.1958609819412231e-01
    z[4,1,5]  R1279     -8.4092825651168823e-02
    z[4,1,5]  R1280     -1.1361759155988693e-01
    z[4,1,5]  R1281     4.4120015809312463e-04
    z[4,1,5]  R1282     -2.7406115084886551e-02
    z[4,1,5]  R1283     1.1172773083671927e-03
    z[4,1,5]  R1284     -9.8782189190387726e-02
    z[4,1,5]  R1285     -2.7341619133949280e-01
    z[4,1,5]  R1286     1.3734828680753708e-02
    z[4,1,5]  R1287     -2.1597044542431831e-02
    z[4,1,5]  R1288     1.3793526589870453e-01
    z[4,1,5]  R1289     0.0759831964969635
    z[4,1,5]  R1290     4.6145290136337280e-02
    z[4,1,5]  R1291     3.8462081551551819e-01
    z[4,1,5]  R1292     0.309256374835968
    z[4,1,5]  R1293     -1.5847636759281158e-01
    z[4,1,5]  R1294     5.0776267051696777e-01
    z[4,1,5]  R1295     2.5914970040321350e-01
    z[4,1,5]  R1296     7.1749143302440643e-02
    z[4,1,5]  R1297     -3.7542516365647316e-03
    z[4,1,5]  R1298     -2.2628861665725708e-01
    z[4,1,5]  R1299     -1.9060148298740387e-01
    z[4,1,5]  R1300     -3.3287471532821655e-01
    z[4,1,5]  R1301     -9.2252299189567566e-02
    z[4,1,5]  R1302     -5.5725795030593872e-01
    z[4,1,5]  R1303     -2.5712516903877258e-01
    z[4,1,5]  R1304     -5.5599504709243774e-01
    z[4,1,5]  R1305     -5.6729829311370850e-01
    z[4,1,5]  R1306     -4.8965570330619812e-01
    z[4,1,5]  R1307     -2.9055011272430420e-01
    z[4,1,5]  R1308     1.7456176877021790e-01
    z[4,1,5]  R1309     2.8850591182708740e-01
    z[4,1,5]  R1310     -2.4103295058012009e-02
    z[4,1,5]  R1311     -6.2595404684543610e-02
    z[4,1,5]  R1312     -7.4984863400459290e-02
    z[4,1,5]  R1313     -1.5337084233760834e-01
    z[4,1,5]  R1314     -5.4406648874282837e-01
    z[4,1,5]  R1315     -5.2214270830154419e-01
    z[4,1,5]  R1316     7.0977574214339256e-03
    z[4,1,5]  R1317     5.4667755961418152e-02
    z[4,1,5]  R1318     -5.1970493793487549e-01
    z[4,1,5]  R1319     -6.0246225446462631e-02
    z[4,1,5]  R1320     3.3154781907796860e-02
    z[4,1,5]  R1321     -5.5117465555667877e-02
    z[4,1,5]  R1322     1.1985098570585251e-01
    z[4,1,5]  R1323     1.4734235405921936e-01
    z[4,1,5]  R1324     -3.7574142217636108e-02
    z[4,1,5]  R1325     -1.2454599142074585e-01
    z[4,1,5]  R1326     8.0336481332778931e-02
    z[4,1,5]  R1327     3.3352074027061462e-01
    z[4,1,5]  R1328     0.199890598654747
    z[4,1,5]  R1329     4.5918133109807968e-03
    z[4,1,6]  R17       1
    z[4,1,6]  R44       -1
    z[4,1,6]  R1218     -1
    z[4,1,6]  R1219     1
    z[4,1,6]  R1220     -3.2446052879095078e-02
    z[4,1,6]  R1221     -2.1736724674701691e-01
    z[4,1,6]  R1222     -1.5648598968982697e-01
    z[4,1,6]  R1223     2.8492954373359680e-01
    z[4,1,6]  R1224     3.1117478013038635e-01
    z[4,1,6]  R1225     -3.0813741683959961e-01
    z[4,1,6]  R1226     -1.0823823511600494e-01
    z[4,1,6]  R1227     -3.7070021033287048e-01
    z[4,1,6]  R1228     4.2664456367492676e-01
    z[4,1,6]  R1229     4.2532593011856079e-01
    z[4,1,6]  R1230     -1.6901694238185883e-01
    z[4,1,6]  R1231     -4.4010091572999954e-02
    z[4,1,6]  R1232     4.6856218576431274e-01
    z[4,1,6]  R1233     2.0871374011039734e-01
    z[4,1,6]  R1234     2.9726946726441383e-02
    z[4,1,6]  R1235     1.9981640577316284e-01
    z[4,1,6]  R1236     1.1819269508123398e-01
    z[4,1,6]  R1237     -5.7206183671951294e-02
    z[4,1,6]  R1238     5.2432626485824585e-01
    z[4,1,6]  R1239     1.7567428946495056e-01
    z[4,1,6]  R1240     5.4454866796731949e-02
    z[4,1,6]  R1241     1.2733514606952667e-01
    z[4,1,6]  R1242     2.4166754155885428e-04
    z[4,1,6]  R1243     -2.7993968129158020e-01
    z[4,1,6]  R1244     1.1713202297687531e-01
    z[4,1,6]  R1245     -1.8819177150726318e-01
    z[4,1,6]  R1246     -1.8090275116264820e-03
    z[4,1,6]  R1247     1.0212234407663345e-01
    z[4,1,6]  R1248     -1.0798142850399017e-01
    z[4,1,6]  R1249     1.6660369932651520e-01
    z[4,1,6]  R1250     -1.1118955910205841e-01
    z[4,1,6]  R1251     2.0655590295791626e-01
    z[4,1,6]  R1252     -7.4333444237709045e-02
    z[4,1,6]  R1253     1.7864930629730225e-01
    z[4,1,6]  R1254     -1.8564037978649139e-01
    z[4,1,6]  R1255     -1.0917651653289795e-01
    z[4,1,6]  R1256     2.7678442001342773e-01
    z[4,1,6]  R1257     1.6901065409183502e-01
    z[4,1,6]  R1258     2.5781095027923584e-01
    z[4,1,6]  R1259     2.4777625501155853e-01
    z[4,1,6]  R1260     -3.5946812480688095e-02
    z[4,1,6]  R1261     -1.0145907104015350e-01
    z[4,1,6]  R1262     6.8740755319595337e-02
    z[4,1,6]  R1263     -2.2169624269008636e-01
    z[4,1,6]  R1264     1.0318201780319214e-01
    z[4,1,6]  R1265     2.4264785461127758e-03
    z[4,1,6]  R1266     7.4183098971843719e-02
    z[4,1,6]  R1267     -7.1695089340209961e-02
    z[4,1,6]  R1268     1.1821021884679794e-01
    z[4,1,6]  R1269     1.2351055443286896e-01
    z[4,1,6]  R1270     1.0709770768880844e-01
    z[4,1,6]  R1271     -2.4973434209823608e-01
    z[4,1,6]  R1272     1.0766394436359406e-01
    z[4,1,6]  R1273     -1.2142031639814377e-01
    z[4,1,6]  R1274     2.6148018240928650e-01
    z[4,1,6]  R1275     4.3953621387481689e-01
    z[4,1,6]  R1276     -7.3536694981157780e-03
    z[4,1,6]  R1277     -9.8360069096088409e-02
    z[4,1,6]  R1278     2.5545188784599304e-01
    z[4,1,6]  R1279     3.6544266343116760e-01
    z[4,1,6]  R1280     2.3569293320178986e-01
    z[4,1,6]  R1281     1.7103728652000427e-01
    z[4,1,6]  R1282     -1.4125512540340424e-01
    z[4,1,6]  R1283     -1.0065762698650360e-01
    z[4,1,6]  R1284     -1.8577769398689270e-01
    z[4,1,6]  R1285     1.7328223586082458e-01
    z[4,1,6]  R1286     -1.8665000796318054e-01
    z[4,1,6]  R1287     -1.3384471833705902e-01
    z[4,1,6]  R1288     -1.6737556457519531e-01
    z[4,1,6]  R1289     -1.9298050552606583e-02
    z[4,1,6]  R1290     -1.5526151657104492e-01
    z[4,1,6]  R1291     -7.1109756827354431e-02
    z[4,1,6]  R1292     -1.9608356058597565e-01
    z[4,1,6]  R1293     -2.3779530823230743e-01
    z[4,1,6]  R1294     -4.6682038903236389e-01
    z[4,1,6]  R1295     -3.0959886312484741e-01
    z[4,1,6]  R1296     2.9122793674468994e-01
    z[4,1,6]  R1297     1.1080313473939896e-01
    z[4,1,6]  R1298     -6.8453967571258545e-01
    z[4,1,6]  R1299     -4.1320380568504333e-01
    z[4,1,6]  R1300     4.7924613952636719e-01
    z[4,1,6]  R1301     5.4809981584548950e-01
    z[4,1,6]  R1302     -1.1365757137537003e-01
    z[4,1,6]  R1303     -1.4261193573474884e-01
    z[4,1,6]  R1304     -7.7522225677967072e-02
    z[4,1,6]  R1305     -1.8059577047824860e-01
    z[4,1,6]  R1306     -7.2199523448944092e-02
    z[4,1,6]  R1307     1.6902619600296021e-01
    z[4,1,6]  R1308     -2.3229663074016571e-01
    z[4,1,6]  R1309     -2.8217615559697151e-02
    z[4,1,6]  R1310     -2.4007629603147507e-02
    z[4,1,6]  R1311     -1.7738421261310577e-01
    z[4,1,6]  R1312     4.8832595348358154e-01
    z[4,1,6]  R1313     -2.4512539803981781e-01
    z[4,1,6]  R1314     -8.6079455912113190e-02
    z[4,1,6]  R1315     -3.3156612515449524e-01
    z[4,1,6]  R1316     2.8960786759853363e-02
    z[4,1,6]  R1317     -2.5481003522872925e-01
    z[4,1,6]  R1318     1.3467422127723694e-01
    z[4,1,6]  R1319     1.0879641771316528e-01
    z[4,1,6]  R1320     3.0809977650642395e-01
    z[4,1,6]  R1321     3.7304118275642395e-01
    z[4,1,6]  R1322     1.1342987418174744e-01
    z[4,1,6]  R1323     -1.6270875930786133e-01
    z[4,1,6]  R1324     3.9924681186676025e-02
    z[4,1,6]  R1325     -2.3157656192779541e-01
    z[4,1,6]  R1326     3.9496082812547684e-02
    z[4,1,6]  R1327     -2.0244711637496948e-01
    z[4,1,6]  R1328     -3.8225898146629333e-01
    z[4,1,6]  R1329     -2.5455081462860107e-01
    z[1,5,0]  R11       -1
    z[1,5,0]  R47       1
    z[1,5,0]  R1330     -1
    z[1,5,0]  R1331     1
    z[1,5,0]  R1344     -5.4846620559692383e-01
    z[1,5,0]  R1345     -5.3737568855285645e-01
    z[1,5,0]  R1346     -3.4947690367698669e-01
    z[1,5,0]  R1347     -3.8337504863739014e-01
    z[1,5,0]  R1348     -3.3478114008903503e-01
    z[1,5,0]  R1349     -2.9309570789337158e-01
    z[1,5,0]  R1350     -4.8481833934783936e-01
    z[1,5,0]  R1351     -5.7584816217422485e-01
    z[1,5,0]  R1352     2.5187286734580994e-01
    z[1,5,0]  R1353     4.6663612127304077e-02
    z[1,5,0]  R1354     9.1005897521972656e-01
    z[1,5,0]  R1355     1.3805174827575684e-01
    z[1,5,0]  R1356     4.7126758098602295e-01
    z[1,5,0]  R1357     4.3676313757896423e-01
    z[1,5,0]  R1358     0.534625232219696
    z[1,5,0]  R1359     7.4053883552551270e-01
    z[1,5,0]  R1360     7.1643579006195068e-01
    z[1,5,0]  R1361     6.3351887464523315e-01
    z[1,5,0]  R1362     8.7949562072753906e-01
    z[1,5,0]  R1363     7.2757941484451294e-01
    z[1,5,0]  R1364     -8.9046663045883179e-01
    z[1,5,0]  R1365     -7.7508997917175293e-01
    z[1,5,0]  R1366     -5.2592891454696655e-01
    z[1,5,0]  R1367     -7.9635888338088989e-01
    z[1,5,0]  R1368     -6.9828587770462036e-01
    z[1,5,0]  R1369     -6.2233519554138184e-01
    z[1,5,0]  R1370     -5.0729984045028687e-01
    z[1,5,0]  R1371     3.2287669181823730e-01
    z[1,5,0]  R1372     2.2204083204269409e-01
    z[1,5,0]  R1373     4.0584060549736023e-01
    z[1,5,0]  R1374     -4.2859551310539246e-01
    z[1,5,0]  R1375     -5.0588089227676392e-01
    z[1,5,0]  R1376     -6.6504962742328644e-02
    z[1,5,0]  R1377     9.3613542616367340e-02
    z[1,5,0]  R1378     1.6056878864765167e-01
    z[1,5,0]  R1379     1.9732825458049774e-01
    z[1,5,0]  R1380     5.2592545747756958e-01
    z[1,5,0]  R1381     3.2273855805397034e-01
    z[1,5,0]  R1382     0.145841583609581
    z[1,5,0]  R1383     1.4634659886360168e-01
    z[1,5,0]  R1384     -4.9644985795021057e-01
    z[1,5,0]  R1385     -5.6475734710693359e-01
    z[1,5,0]  R1386     -4.7109922766685486e-01
    z[1,5,0]  R1387     5.1703029870986938e-01
    z[1,5,0]  R1388     4.9828074872493744e-02
    z[1,5,0]  R1389     -6.4766839146614075e-02
    z[1,5,0]  R1390     3.1029042601585388e-01
    z[1,5,0]  R1391     2.6755779981613159e-01
    z[1,5,0]  R1392     4.5220926403999329e-01
    z[1,5,0]  R1393     7.0565128326416016e-01
    z[1,5,0]  R1394     -7.2389864921569824e-01
    z[1,5,0]  R1395     4.7058889269828796e-01
    z[1,5,0]  R1396     3.2659158110618591e-01
    z[1,5,0]  R1397     2.9244866967201233e-01
    z[1,5,0]  R1398     1.8340951204299927e-01
    z[1,5,0]  R1399     1.1921054124832153e-01
    z[1,5,0]  R1400     4.4222906231880188e-01
    z[1,5,0]  R1401     4.4989496469497681e-01
    z[1,5,0]  R1402     0.354343980550766
    z[1,5,0]  R1403     4.8459321260452271e-01
    z[1,5,0]  R1404     -1.3997809030115604e-02
    z[1,5,0]  R1405     5.5758005380630493e-01
    z[1,5,0]  R1406     5.0523781776428223e-01
    z[1,5,0]  R1407     -5.2187938243150711e-02
    z[1,5,0]  R1408     1.2089616805315018e-01
    z[1,5,0]  R1409     -8.6801508441567421e-03
    z[1,5,0]  R1410     8.7563628330826759e-03
    z[1,5,0]  R1411     -7.5780510902404785e-02
    z[1,5,0]  R1412     -2.1654142066836357e-02
    z[1,5,0]  R1413     8.2768142223358154e-01
    z[1,5,0]  R1414     4.0742865204811096e-01
    z[1,5,0]  R1415     4.3945017457008362e-01
    z[1,5,0]  R1416     3.8547104597091675e-01
    z[1,5,0]  R1417     -5.6935763359069824e-01
    z[1,5,0]  R1418     1.4344798028469086e-01
    z[1,5,0]  R1419     -5.0438129901885986e-01
    z[1,5,0]  R1420     2.9635295271873474e-01
    z[1,5,0]  R1421     3.9452192187309265e-01
    z[1,5,0]  R1422     2.0532502233982086e-01
    z[1,5,0]  R1423     3.9675658941268921e-01
    z[1,5,0]  R1424     -9.2806547880172729e-02
    z[1,5,0]  R1425     7.5493997335433960e-01
    z[1,5,0]  R1426     3.9099308848381042e-01
    z[1,5,0]  R1427     -3.3919128775596619e-01
    z[1,5,0]  R1428     5.5431425571441650e-01
    z[1,5,0]  R1429     6.5923231840133667e-01
    z[1,5,0]  R1430     6.0001599788665771e-01
    z[1,5,0]  R1431     -5.4473632574081421e-01
    z[1,5,0]  R1432     6.8981027603149414e-01
    z[1,5,0]  R1433     7.3579502105712891e-01
    z[1,5,0]  R1434     7.4069178104400635e-01
    z[1,5,0]  R1435     7.2650265693664551e-01
    z[1,5,0]  R1436     5.7322221994400024e-01
    z[1,5,0]  R1437     6.9887030124664307e-01
    z[1,5,0]  R1438     7.1005409955978394e-01
    z[1,5,0]  R1439     -7.6446205377578735e-01
    z[1,5,0]  R1440     -8.9940339326858521e-01
    z[1,5,0]  R1441     -0.898152232170105
    z[1,5,0]  R1442     -8.1273835897445679e-01
    z[1,5,0]  R1443     -7.4537557363510132e-01
    z[1,5,1]  R12       -1
    z[1,5,1]  R48       1
    z[1,5,1]  R1332     -1
    z[1,5,1]  R1333     1
    z[1,5,1]  R1344     3.8442826271057129e-01
    z[1,5,1]  R1345     -2.6387885212898254e-01
    z[1,5,1]  R1346     3.1713566184043884e-01
    z[1,5,1]  R1347     -6.0303714126348495e-03
    z[1,5,1]  R1348     2.7103728055953979e-01
    z[1,5,1]  R1349     1.1794888228178024e-01
    z[1,5,1]  R1350     1.6418954730033875e-01
    z[1,5,1]  R1351     4.1713860630989075e-01
    z[1,5,1]  R1352     -6.7177355289459229e-01
    z[1,5,1]  R1353     -6.6847103834152222e-01
    z[1,5,1]  R1354     2.9807296395301819e-01
    z[1,5,1]  R1355     2.4385875463485718e-01
    z[1,5,1]  R1356     -3.8807126879692078e-01
    z[1,5,1]  R1357     3.3396932482719421e-01
    z[1,5,1]  R1358     3.5263964533805847e-01
    z[1,5,1]  R1359     2.4720968306064606e-01
    z[1,5,1]  R1360     -3.7510228157043457e-01
    z[1,5,1]  R1361     -5.7581549882888794e-01
    z[1,5,1]  R1362     1.4785762131214142e-01
    z[1,5,1]  R1363     -3.0817532539367676e-01
    z[1,5,1]  R1364     -2.1939820051193237e-01
    z[1,5,1]  R1365     1.9416160881519318e-01
    z[1,5,1]  R1366     4.9348825216293335e-01
    z[1,5,1]  R1367     -1.4357546344399452e-02
    z[1,5,1]  R1368     -7.9884245991706848e-02
    z[1,5,1]  R1369     1.5804682672023773e-01
    z[1,5,1]  R1370     1.9286023080348969e-01
    z[1,5,1]  R1371     6.6589933633804321e-01
    z[1,5,1]  R1372     -4.4424888491630554e-01
    z[1,5,1]  R1373     -4.4897049665451050e-02
    z[1,5,1]  R1374     4.5701089501380920e-01
    z[1,5,1]  R1375     6.6072843968868256e-02
    z[1,5,1]  R1376     -6.2168675661087036e-01
    z[1,5,1]  R1377     -7.2063046693801880e-01
    z[1,5,1]  R1378     -1.4998872578144073e-01
    z[1,5,1]  R1379     -2.9883316159248352e-01
    z[1,5,1]  R1380     -4.1531211137771606e-01
    z[1,5,1]  R1381     -3.4737905859947205e-01
    z[1,5,1]  R1382     -2.5700709223747253e-01
    z[1,5,1]  R1383     0.885625422000885
    z[1,5,1]  R1384     5.2399653196334839e-01
    z[1,5,1]  R1385     6.6193324327468872e-01
    z[1,5,1]  R1386     2.1502195298671722e-01
    z[1,5,1]  R1387     -3.4582906961441040e-01
    z[1,5,1]  R1388     -0.293354332447052
    z[1,5,1]  R1389     -5.0657910108566284e-01
    z[1,5,1]  R1390     -5.3950250148773193e-01
    z[1,5,1]  R1391     -1.9510462880134583e-01
    z[1,5,1]  R1392     -3.7244316935539246e-01
    z[1,5,1]  R1393     -1.6403743624687195e-01
    z[1,5,1]  R1394     -3.8011498749256134e-02
    z[1,5,1]  R1395     -2.4596635997295380e-01
    z[1,5,1]  R1396     -8.6322838068008423e-01
    z[1,5,1]  R1397     -9.1503816843032837e-01
    z[1,5,1]  R1398     -9.3509048223495483e-01
    z[1,5,1]  R1399     -8.8453543186187744e-01
    z[1,5,1]  R1400     -7.9997146129608154e-01
    z[1,5,1]  R1401     -7.4838405847549438e-01
    z[1,5,1]  R1402     -0.752017617225647
    z[1,5,1]  R1403     -7.7209919691085815e-01
    z[1,5,1]  R1404     1.8905310332775116e-01
    z[1,5,1]  R1405     2.1017962694168091e-01
    z[1,5,1]  R1406     1.5771448612213135e-01
    z[1,5,1]  R1407     2.1219782531261444e-01
    z[1,5,1]  R1408     2.2072224318981171e-01
    z[1,5,1]  R1409     2.5600370764732361e-01
    z[1,5,1]  R1410     1.7782041430473328e-01
    z[1,5,1]  R1411     4.4399213790893555e-01
    z[1,5,1]  R1412     1.2944982945919037e-01
    z[1,5,1]  R1413     1.2567570805549622e-01
    z[1,5,1]  R1414     -6.5594899654388428e-01
    z[1,5,1]  R1415     -3.3320096135139465e-01
    z[1,5,1]  R1416     -0.617285430431366
    z[1,5,1]  R1417     2.8803017735481262e-01
    z[1,5,1]  R1418     -9.5162212848663330e-01
    z[1,5,1]  R1419     4.3394145369529724e-01
    z[1,5,1]  R1420     -5.5049043893814087e-01
    z[1,5,1]  R1421     -3.2727000117301941e-01
    z[1,5,1]  R1422     -9.1263920068740845e-01
    z[1,5,1]  R1423     -3.4390786290168762e-01
    z[1,5,1]  R1424     9.4008797407150269e-01
    z[1,5,1]  R1425     -2.5318646430969238e-01
    z[1,5,1]  R1426     5.1840496063232422e-01
    z[1,5,1]  R1427     -3.7790334224700928e-01
    z[1,5,1]  R1428     0.398128867149353
    z[1,5,1]  R1429     -2.2204957902431488e-01
    z[1,5,1]  R1430     1.0989034920930862e-01
    z[1,5,1]  R1431     -8.0375164747238159e-02
    z[1,5,1]  R1432     2.8845466673374176e-02
    z[1,5,1]  R1433     -3.4753879904747009e-01
    z[1,5,1]  R1434     -0.0806993618607521
    z[1,5,1]  R1435     -0.042476586997509
    z[1,5,1]  R1436     2.8685966134071350e-01
    z[1,5,1]  R1437     -4.3638747930526733e-01
    z[1,5,1]  R1438     1.0166170448064804e-01
    z[1,5,1]  R1439     2.1396577358245850e-01
    z[1,5,1]  R1440     -1.3196200598031282e-03
    z[1,5,1]  R1441     -0.0641687661409378
    z[1,5,1]  R1442     -2.0167045295238495e-01
    z[1,5,1]  R1443     1.0248646140098572e-02
    z[1,5,2]  R13       -1
    z[1,5,2]  R49       1
    z[1,5,2]  R1334     -1
    z[1,5,2]  R1335     1
    z[1,5,2]  R1344     4.0556451678276062e-01
    z[1,5,2]  R1345     5.7136386632919312e-01
    z[1,5,2]  R1346     6.8847596645355225e-01
    z[1,5,2]  R1347     2.0886674523353577e-01
    z[1,5,2]  R1348     -1.5248348005115986e-02
    z[1,5,2]  R1349     5.3124696016311646e-01
    z[1,5,2]  R1350     -2.1343810856342316e-01
    z[1,5,2]  R1351     -2.7728474140167236e-01
    z[1,5,2]  R1352     -1.0162437707185745e-01
    z[1,5,2]  R1353     -2.3174107074737549e-01
    z[1,5,2]  R1354     -1.1740779131650925e-01
    z[1,5,2]  R1355     -6.8835496902465820e-01
    z[1,5,2]  R1356     5.9588211774826050e-01
    z[1,5,2]  R1357     -6.0378080606460571e-01
    z[1,5,2]  R1358     -3.1660494208335876e-01
    z[1,5,2]  R1359     -4.0137115865945816e-02
    z[1,5,2]  R1360     2.5910025835037231e-01
    z[1,5,2]  R1361     4.1383656859397888e-01
    z[1,5,2]  R1362     -2.9499918222427368e-01
    z[1,5,2]  R1363     3.6738941073417664e-01
    z[1,5,2]  R1364     -1.9834670424461365e-01
    z[1,5,2]  R1365     -3.6132711917161942e-02
    z[1,5,2]  R1366     2.9677665233612061e-01
    z[1,5,2]  R1367     2.6175066828727722e-01
    z[1,5,2]  R1368     -1.4722524583339691e-01
    z[1,5,2]  R1369     -2.3189820349216461e-01
    z[1,5,2]  R1370     -7.4641996622085571e-01
    z[1,5,2]  R1371     -5.8503359556198120e-01
    z[1,5,2]  R1372     -1.5049757063388824e-01
    z[1,5,2]  R1373     4.7004982829093933e-02
    z[1,5,2]  R1374     -4.8428988456726074e-01
    z[1,5,2]  R1375     -2.0427714288234711e-01
    z[1,5,2]  R1376     1.7326584085822105e-02
    z[1,5,2]  R1377     -2.0517694950103760e-01
    z[1,5,2]  R1378     -6.6344380378723145e-02
    z[1,5,2]  R1379     1.9156554341316223e-01
    z[1,5,2]  R1380     0.0657258853316307
    z[1,5,2]  R1381     -4.1535636410117149e-03
    z[1,5,2]  R1382     -2.2964255511760712e-01
    z[1,5,2]  R1383     -1.2464547902345657e-01
    z[1,5,2]  R1384     -5.8535808324813843e-01
    z[1,5,2]  R1385     -2.8683599829673767e-01
    z[1,5,2]  R1386     -4.8880372196435928e-02
    z[1,5,2]  R1387     -2.0156674087047577e-01
    z[1,5,2]  R1388     -2.2471249103546143e-01
    z[1,5,2]  R1389     -3.3468988537788391e-01
    z[1,5,2]  R1390     1.8343251943588257e-01
    z[1,5,2]  R1391     -2.5035008788108826e-01
    z[1,5,2]  R1392     2.0671902596950531e-01
    z[1,5,2]  R1393     -0.0722411647439003
    z[1,5,2]  R1394     -5.3254854679107666e-01
    z[1,5,2]  R1395     -1.6451023519039154e-01
    z[1,5,2]  R1396     1.6175574064254761e-01
    z[1,5,2]  R1397     0.000609697075560689
    z[1,5,2]  R1398     -5.0387654453516006e-02
    z[1,5,2]  R1399     2.9645591974258423e-01
    z[1,5,2]  R1400     -3.1568646430969238e-01
    z[1,5,2]  R1401     3.7175349891185760e-02
    z[1,5,2]  R1402     3.4580063819885254e-01
    z[1,5,2]  R1403     1.1843249201774597e-01
    z[1,5,2]  R1404     -2.8237661719322205e-01
    z[1,5,2]  R1405     -1.2899863719940186e-01
    z[1,5,2]  R1406     -5.5287480354309082e-01
    z[1,5,2]  R1407     -6.1866492033004761e-01
    z[1,5,2]  R1408     -2.5025400519371033e-01
    z[1,5,2]  R1409     5.1847383379936218e-02
    z[1,5,2]  R1410     -6.7677521705627441e-01
    z[1,5,2]  R1411     -8.1299352645874023e-01
    z[1,5,2]  R1412     -5.4551094770431519e-01
    z[1,5,2]  R1413     2.4136213958263397e-01
    z[1,5,2]  R1414     4.0681045502424240e-02
    z[1,5,2]  R1415     1.4646363258361816e-01
    z[1,5,2]  R1416     -2.1235128864645958e-02
    z[1,5,2]  R1417     2.7705490589141846e-01
    z[1,5,2]  R1418     -2.4117190390825272e-02
    z[1,5,2]  R1419     5.7482112199068069e-02
    z[1,5,2]  R1420     4.7844356298446655e-01
    z[1,5,2]  R1421     -3.3507618308067322e-01
    z[1,5,2]  R1422     0.0655309185385704
    z[1,5,2]  R1423     3.3724945783615112e-01
    z[1,5,2]  R1424     1.1411363631486893e-01
    z[1,5,2]  R1425     1.8625865876674652e-01
    z[1,5,2]  R1426     -0.144407719373703
    z[1,5,2]  R1427     -4.1109225153923035e-01
    z[1,5,2]  R1428     2.6722699403762817e-01
    z[1,5,2]  R1429     5.5550694465637207e-01
    z[1,5,2]  R1430     5.9672847390174866e-02
    z[1,5,2]  R1431     -2.2553333640098572e-01
    z[1,5,2]  R1432     6.7317962646484375e-02
    z[1,5,2]  R1433     -2.5654649734497070e-01
    z[1,5,2]  R1434     3.3794519305229187e-01
    z[1,5,2]  R1435     -2.4270488321781158e-01
    z[1,5,2]  R1436     1.8770545721054077e-01
    z[1,5,2]  R1437     1.3617783784866333e-01
    z[1,5,2]  R1438     3.6944913864135742e-01
    z[1,5,2]  R1439     -3.4059572219848633e-01
    z[1,5,2]  R1440     -1.6890175640583038e-01
    z[1,5,2]  R1441     6.1599317938089371e-02
    z[1,5,2]  R1442     1.7163710668683052e-02
    z[1,5,2]  R1443     -3.3075023442506790e-02
    z[1,5,3]  R14       -1
    z[1,5,3]  R50       1
    z[1,5,3]  R1336     -1
    z[1,5,3]  R1337     1
    z[1,5,3]  R1344     3.9904925227165222e-01
    z[1,5,3]  R1345     -4.4947284460067749e-01
    z[1,5,3]  R1346     -2.5990280508995056e-01
    z[1,5,3]  R1347     -3.9733633399009705e-01
    z[1,5,3]  R1348     -2.7447342872619629e-01
    z[1,5,3]  R1349     -5.7482278347015381e-01
    z[1,5,3]  R1350     -6.4267545938491821e-01
    z[1,5,3]  R1351     -2.6924726553261280e-03
    z[1,5,3]  R1352     -4.3043103814125061e-01
    z[1,5,3]  R1353     -5.6083846092224121e-01
    z[1,5,3]  R1354     -4.9707889556884766e-03
    z[1,5,3]  R1355     5.6251049041748047e-01
    z[1,5,3]  R1356     4.5717990398406982e-01
    z[1,5,3]  R1357     5.6790667772293091e-01
    z[1,5,3]  R1358     6.6686850786209106e-01
    z[1,5,3]  R1359     4.8297506570816040e-01
    z[1,5,3]  R1360     4.2766058444976807e-01
    z[1,5,3]  R1361     2.0888186991214752e-01
    z[1,5,3]  R1362     2.5776371359825134e-01
    z[1,5,3]  R1363     2.2306315600872040e-01
    z[1,5,3]  R1364     -1.1081153899431229e-01
    z[1,5,3]  R1365     -0.454868882894516
    z[1,5,3]  R1366     -4.9220845103263855e-01
    z[1,5,3]  R1367     0.456521600484848
    z[1,5,3]  R1368     0.0790027603507042
    z[1,5,3]  R1369     5.3736311197280884e-01
    z[1,5,3]  R1370     1.2507483363151550e-01
    z[1,5,3]  R1371     3.1046831607818604e-01
    z[1,5,3]  R1372     -4.5002856850624084e-01
    z[1,5,3]  R1373     -7.8516000509262085e-01
    z[1,5,3]  R1374     -0.120479054749012
    z[1,5,3]  R1375     8.1015847623348236e-02
    z[1,5,3]  R1376     -5.2535998821258545e-01
    z[1,5,3]  R1377     -4.3817153573036194e-01
    z[1,5,3]  R1378     -7.7117341756820679e-01
    z[1,5,3]  R1379     -6.7462337017059326e-01
    z[1,5,3]  R1380     -3.9227211475372314e-01
    z[1,5,3]  R1381     -6.4566022157669067e-01
    z[1,5,3]  R1382     -8.5562658309936523e-01
    z[1,5,3]  R1383     9.8151132464408875e-02
    z[1,5,3]  R1384     3.6296206712722778e-01
    z[1,5,3]  R1385     1.9905048608779907e-01
    z[1,5,3]  R1386     1.3431535661220551e-01
    z[1,5,3]  R1387     -6.5590482950210571e-01
    z[1,5,3]  R1388     -7.0590674877166748e-01
    z[1,5,3]  R1389     -4.9436318874359131e-01
    z[1,5,3]  R1390     -7.5713771581649780e-01
    z[1,5,3]  R1391     -8.6876374483108521e-01
    z[1,5,3]  R1392     -5.4235792160034180e-01
    z[1,5,3]  R1393     -6.7413049936294556e-01
    z[1,5,3]  R1394     8.8837943971157074e-02
    z[1,5,3]  R1395     -7.3519039154052734e-01
    z[1,5,3]  R1396     -1.9255171716213226e-01
    z[1,5,3]  R1397     1.3584984838962555e-01
    z[1,5,3]  R1398     2.1812172234058380e-01
    z[1,5,3]  R1399     9.1849960386753082e-02
    z[1,5,3]  R1400     1.8861801922321320e-01
    z[1,5,3]  R1401     -2.7884244918823242e-01
    z[1,5,3]  R1402     1.2510600499808788e-02
    z[1,5,3]  R1403     -2.7186835184693336e-02
    z[1,5,3]  R1404     6.6540360450744629e-01
    z[1,5,3]  R1405     6.5713709592819214e-01
    z[1,5,3]  R1406     5.0276738405227661e-01
    z[1,5,3]  R1407     3.6557447910308838e-01
    z[1,5,3]  R1408     3.9716669917106628e-01
    z[1,5,3]  R1409     3.7337687611579895e-01
    z[1,5,3]  R1410     4.5556488633155823e-01
    z[1,5,3]  R1411     1.1686177551746368e-01
    z[1,5,3]  R1412     5.0188434123992920e-01
    z[1,5,3]  R1413     2.3232667148113251e-01
    z[1,5,3]  R1414     -5.7432240247726440e-01
    z[1,5,3]  R1415     -6.3345789909362793e-01
    z[1,5,3]  R1416     -4.6149781346321106e-01
    z[1,5,3]  R1417     -4.6182355284690857e-01
    z[1,5,3]  R1418     -1.3038317859172821e-01
    z[1,5,3]  R1419     -5.3972136974334717e-01
    z[1,5,3]  R1420     -3.8895878195762634e-01
    z[1,5,3]  R1421     -5.3050237894058228e-01
    z[1,5,3]  R1422     -2.5320374965667725e-01
    z[1,5,3]  R1423     -4.2305126786231995e-01
    z[1,5,3]  R1424     2.9098740220069885e-01
    z[1,5,3]  R1425     -2.9129517078399658e-01
    z[1,5,3]  R1426     -1.4781875908374786e-01
    z[1,5,3]  R1427     -3.1002059578895569e-01
    z[1,5,3]  R1428     -3.9259654283523560e-01
    z[1,5,3]  R1429     -1.4276312291622162e-01
    z[1,5,3]  R1430     -2.5168719887733459e-01
    z[1,5,3]  R1431     -6.5503165125846863e-02
    z[1,5,3]  R1432     -1.3038103282451630e-01
    z[1,5,3]  R1433     -0.469923198223114
    z[1,5,3]  R1434     1.0379044711589813e-01
    z[1,5,3]  R1435     -1.3402193784713745e-01
    z[1,5,3]  R1436     -2.9712323099374771e-02
    z[1,5,3]  R1437     5.9156041592359543e-02
    z[1,5,3]  R1438     1.1013500392436981e-02
    z[1,5,3]  R1439     -4.3319210410118103e-01
    z[1,5,3]  R1440     -3.8658967614173889e-01
    z[1,5,3]  R1441     -4.2065268754959106e-01
    z[1,5,3]  R1442     -4.7309896349906921e-01
    z[1,5,3]  R1443     -4.2904523015022278e-01
    z[1,5,4]  R15       -1
    z[1,5,4]  R51       1
    z[1,5,4]  R1338     -1
    z[1,5,4]  R1339     1
    z[1,5,4]  R1344     -3.1760153174400330e-01
    z[1,5,4]  R1345     1.2788502871990204e-01
    z[1,5,4]  R1346     -4.5941525697708130e-01
    z[1,5,4]  R1347     -4.5679351687431335e-01
    z[1,5,4]  R1348     -6.8453729152679443e-01
    z[1,5,4]  R1349     -2.0277164876461029e-02
    z[1,5,4]  R1350     5.1528328657150269e-01
    z[1,5,4]  R1351     5.8601063489913940e-01
    z[1,5,4]  R1352     3.4970134496688843e-01
    z[1,5,4]  R1353     2.0519576966762543e-01
    z[1,5,4]  R1354     -2.5997087359428406e-02
    z[1,5,4]  R1355     -3.1932753324508667e-01
    z[1,5,4]  R1356     -2.0619036257266998e-01
    z[1,5,4]  R1357     2.2363530471920967e-02
    z[1,5,4]  R1358     2.4442672729492188e-02
    z[1,5,4]  R1359     -2.2545643150806427e-01
    z[1,5,4]  R1360     -2.4691025912761688e-01
    z[1,5,4]  R1361     -1.8389484286308289e-01
    z[1,5,4]  R1362     6.4173959195613861e-02
    z[1,5,4]  R1363     -4.2985841631889343e-01
    z[1,5,4]  R1364     2.8474089503288269e-01
    z[1,5,4]  R1365     -1.8321696668863297e-02
    z[1,5,4]  R1366     1.2423494458198547e-01
    z[1,5,4]  R1367     -0.0837835893034935
    z[1,5,4]  R1368     -4.8522930592298508e-02
    z[1,5,4]  R1369     -2.8666019439697266e-01
    z[1,5,4]  R1370     -2.0664894580841064e-01
    z[1,5,4]  R1371     -3.7180971354246140e-02
    z[1,5,4]  R1372     -9.1457515954971313e-02
    z[1,5,4]  R1373     -8.6750283837318420e-02
    z[1,5,4]  R1374     1.3383789360523224e-01
    z[1,5,4]  R1375     -6.1846762895584106e-01
    z[1,5,4]  R1376     -9.6565060317516327e-02
    z[1,5,4]  R1377     -3.8908189535140991e-01
    z[1,5,4]  R1378     -1.9357408583164215e-01
    z[1,5,4]  R1379     -1.5970006585121155e-01
    z[1,5,4]  R1380     -3.8437676429748535e-01
    z[1,5,4]  R1381     -4.9526163935661316e-01
    z[1,5,4]  R1382     2.0835416018962860e-01
    z[1,5,4]  R1383     -2.9163017868995667e-01
    z[1,5,4]  R1384     0.0585007481276989
    z[1,5,4]  R1385     2.9259911179542542e-01
    z[1,5,4]  R1386     -6.8360525369644165e-01
    z[1,5,4]  R1387     -0.242141455411911
    z[1,5,4]  R1388     -2.4339766800403595e-01
    z[1,5,4]  R1389     -1.4195046387612820e-02
    z[1,5,4]  R1390     -0.0697336345911026
    z[1,5,4]  R1391     -7.0744507014751434e-02
    z[1,5,4]  R1392     -1.7798207700252533e-01
    z[1,5,4]  R1393     -3.3123213797807693e-03
    z[1,5,4]  R1394     -2.9495945572853088e-01
    z[1,5,4]  R1395     9.0996541082859039e-02
    z[1,5,4]  R1396     -2.4021466076374054e-01
    z[1,5,4]  R1397     -1.0266276448965073e-01
    z[1,5,4]  R1398     -1.9709125161170959e-01
    z[1,5,4]  R1399     1.9474083185195923e-01
    z[1,5,4]  R1400     -1.4570684731006622e-01
    z[1,5,4]  R1401     7.8483283519744873e-02
    z[1,5,4]  R1402     5.5651620030403137e-02
    z[1,5,4]  R1403     2.9908114671707153e-01
    z[1,5,4]  R1404     -5.6736266613006592e-01
    z[1,5,4]  R1405     -4.2338716983795166e-01
    z[1,5,4]  R1406     -2.7609494328498840e-01
    z[1,5,4]  R1407     -5.4130053520202637e-01
    z[1,5,4]  R1408     -5.4473882913589478e-01
    z[1,5,4]  R1409     -7.5190836191177368e-01
    z[1,5,4]  R1410     6.0095246881246567e-02
    z[1,5,4]  R1411     1.6605155169963837e-01
    z[1,5,4]  R1412     -2.0370914041996002e-01
    z[1,5,4]  R1413     2.3565191030502319e-01
    z[1,5,4]  R1414     1.3322633504867554e-01
    z[1,5,4]  R1415     -1.5834622085094452e-02
    z[1,5,4]  R1416     0.277626633644104
    z[1,5,4]  R1417     0.466239869594574
    z[1,5,4]  R1418     2.0291706547141075e-02
    z[1,5,4]  R1419     2.7662605047225952e-01
    z[1,5,4]  R1420     7.7883275225758553e-03
    z[1,5,4]  R1421     2.1679170429706573e-01
    z[1,5,4]  R1422     -1.0537905991077423e-01
    z[1,5,4]  R1423     0.0986253172159195
    z[1,5,4]  R1424     0.00849322509020567
    z[1,5,4]  R1425     2.1699893474578857e-01
    z[1,5,4]  R1426     3.9246338605880737e-01
    z[1,5,4]  R1427     3.7728101015090942e-01
    z[1,5,4]  R1428     5.4241657257080078e-02
    z[1,5,4]  R1429     0.154581680893898
    z[1,5,4]  R1430     3.2734036445617676e-01
    z[1,5,4]  R1431     6.6526606678962708e-02
    z[1,5,4]  R1432     1.0396488755941391e-01
    z[1,5,4]  R1433     -1.1083486676216125e-01
    z[1,5,4]  R1434     2.1375261247158051e-01
    z[1,5,4]  R1435     5.8546119928359985e-01
    z[1,5,4]  R1436     3.8419520854949951e-01
    z[1,5,4]  R1437     3.7921886891126633e-02
    z[1,5,4]  R1438     2.2218170762062073e-01
    z[1,5,4]  R1439     3.6676891148090363e-02
    z[1,5,4]  R1440     -7.9336911439895630e-02
    z[1,5,4]  R1441     -6.3870586454868317e-02
    z[1,5,4]  R1442     -1.1375338584184647e-01
    z[1,5,4]  R1443     -2.6194578409194946e-01
    z[1,5,5]  R16       -1
    z[1,5,5]  R52       1
    z[1,5,5]  R1340     -1
    z[1,5,5]  R1341     1
    z[1,5,5]  R1344     -3.3961209654808044e-01
    z[1,5,5]  R1345     1.8544797599315643e-01
    z[1,5,5]  R1346     1.1440439522266388e-01
    z[1,5,5]  R1347     6.5428024530410767e-01
    z[1,5,5]  R1348     4.4936504960060120e-01
    z[1,5,5]  R1349     -3.0648830533027649e-01
    z[1,5,5]  R1350     1.1762021481990814e-01
    z[1,5,5]  R1351     -2.5380519032478333e-01
    z[1,5,5]  R1352     -3.1958609819412231e-01
    z[1,5,5]  R1353     -8.4092825651168823e-02
    z[1,5,5]  R1354     -1.1361759155988693e-01
    z[1,5,5]  R1355     4.4120015809312463e-04
    z[1,5,5]  R1356     -2.7406115084886551e-02
    z[1,5,5]  R1357     1.1172773083671927e-03
    z[1,5,5]  R1358     -9.8782189190387726e-02
    z[1,5,5]  R1359     -2.7341619133949280e-01
    z[1,5,5]  R1360     1.3734828680753708e-02
    z[1,5,5]  R1361     -2.1597044542431831e-02
    z[1,5,5]  R1362     1.3793526589870453e-01
    z[1,5,5]  R1363     0.0759831964969635
    z[1,5,5]  R1364     4.6145290136337280e-02
    z[1,5,5]  R1365     3.8462081551551819e-01
    z[1,5,5]  R1366     0.309256374835968
    z[1,5,5]  R1367     -1.5847636759281158e-01
    z[1,5,5]  R1368     5.0776267051696777e-01
    z[1,5,5]  R1369     2.5914970040321350e-01
    z[1,5,5]  R1370     7.1749143302440643e-02
    z[1,5,5]  R1371     -3.7542516365647316e-03
    z[1,5,5]  R1372     -2.2628861665725708e-01
    z[1,5,5]  R1373     -1.9060148298740387e-01
    z[1,5,5]  R1374     -3.3287471532821655e-01
    z[1,5,5]  R1375     -9.2252299189567566e-02
    z[1,5,5]  R1376     -5.5725795030593872e-01
    z[1,5,5]  R1377     -2.5712516903877258e-01
    z[1,5,5]  R1378     -5.5599504709243774e-01
    z[1,5,5]  R1379     -5.6729829311370850e-01
    z[1,5,5]  R1380     -4.8965570330619812e-01
    z[1,5,5]  R1381     -2.9055011272430420e-01
    z[1,5,5]  R1382     1.7456176877021790e-01
    z[1,5,5]  R1383     2.8850591182708740e-01
    z[1,5,5]  R1384     -2.4103295058012009e-02
    z[1,5,5]  R1385     -6.2595404684543610e-02
    z[1,5,5]  R1386     -7.4984863400459290e-02
    z[1,5,5]  R1387     -1.5337084233760834e-01
    z[1,5,5]  R1388     -5.4406648874282837e-01
    z[1,5,5]  R1389     -5.2214270830154419e-01
    z[1,5,5]  R1390     7.0977574214339256e-03
    z[1,5,5]  R1391     5.4667755961418152e-02
    z[1,5,5]  R1392     -5.1970493793487549e-01
    z[1,5,5]  R1393     -6.0246225446462631e-02
    z[1,5,5]  R1394     3.3154781907796860e-02
    z[1,5,5]  R1395     -5.5117465555667877e-02
    z[1,5,5]  R1396     1.1985098570585251e-01
    z[1,5,5]  R1397     1.4734235405921936e-01
    z[1,5,5]  R1398     -3.7574142217636108e-02
    z[1,5,5]  R1399     -1.2454599142074585e-01
    z[1,5,5]  R1400     8.0336481332778931e-02
    z[1,5,5]  R1401     3.3352074027061462e-01
    z[1,5,5]  R1402     0.199890598654747
    z[1,5,5]  R1403     4.5918133109807968e-03
    z[1,5,5]  R1404     -3.4532821178436279e-01
    z[1,5,5]  R1405     -2.1436698734760284e-02
    z[1,5,5]  R1406     2.7303391695022583e-01
    z[1,5,5]  R1407     1.1729851365089417e-01
    z[1,5,5]  R1408     4.1483619809150696e-01
    z[1,5,5]  R1409     3.1923133134841919e-01
    z[1,5,5]  R1410     -1.3287958502769470e-01
    z[1,5,5]  R1411     2.7967765927314758e-01
    z[1,5,5]  R1412     2.5065195560455322e-01
    z[1,5,5]  R1413     -2.0192395150661469e-01
    z[1,5,5]  R1414     1.4752630889415741e-01
    z[1,5,5]  R1415     1.8181920051574707e-01
    z[1,5,5]  R1416     0.220264732837677
    z[1,5,5]  R1417     -3.2586917281150818e-02
    z[1,5,5]  R1418     -5.7722595520317554e-03
    z[1,5,5]  R1419     -5.5649623274803162e-02
    z[1,5,5]  R1420     3.8544493913650513e-01
    z[1,5,5]  R1421     -2.5023165345191956e-01
    z[1,5,5]  R1422     9.4785392284393311e-02
    z[1,5,5]  R1423     2.4255488812923431e-01
    z[1,5,5]  R1424     -1.9831936806440353e-02
    z[1,5,5]  R1425     4.4322180747985840e-01
    z[1,5,5]  R1426     -1.4351183176040649e-01
    z[1,5,5]  R1427     2.0533630251884460e-01
    z[1,5,5]  R1428     5.4337686300277710e-01
    z[1,5,5]  R1429     3.7895879149436951e-01
    z[1,5,5]  R1430     5.9802955389022827e-01
    z[1,5,5]  R1431     -0.599342405796051
    z[1,5,5]  R1432     4.1543442010879517e-01
    z[1,5,5]  R1433     -1.1101827770471573e-01
    z[1,5,5]  R1434     4.6737310290336609e-01
    z[1,5,5]  R1435     2.1555164456367493e-01
    z[1,5,5]  R1436     0.607568085193634
    z[1,5,5]  R1437     0.532397449016571
    z[1,5,5]  R1438     -2.6702085137367249e-01
    z[1,5,5]  R1439     2.0080116391181946e-01
    z[1,5,5]  R1440     -6.3286215066909790e-02
    z[1,5,5]  R1441     -1.5741702169179916e-02
    z[1,5,5]  R1442     -1.3458141684532166e-01
    z[1,5,5]  R1443     1.3015043735504150e-01
    z[1,5,6]  R17       -1
    z[1,5,6]  R53       1
    z[1,5,6]  R1342     -1
    z[1,5,6]  R1343     1
    z[1,5,6]  R1344     1.0709770768880844e-01
    z[1,5,6]  R1345     -2.4973434209823608e-01
    z[1,5,6]  R1346     1.0766394436359406e-01
    z[1,5,6]  R1347     -1.2142031639814377e-01
    z[1,5,6]  R1348     2.6148018240928650e-01
    z[1,5,6]  R1349     4.3953621387481689e-01
    z[1,5,6]  R1350     -7.3536694981157780e-03
    z[1,5,6]  R1351     -9.8360069096088409e-02
    z[1,5,6]  R1352     2.5545188784599304e-01
    z[1,5,6]  R1353     3.6544266343116760e-01
    z[1,5,6]  R1354     2.3569293320178986e-01
    z[1,5,6]  R1355     1.7103728652000427e-01
    z[1,5,6]  R1356     -1.4125512540340424e-01
    z[1,5,6]  R1357     -1.0065762698650360e-01
    z[1,5,6]  R1358     -1.8577769398689270e-01
    z[1,5,6]  R1359     1.7328223586082458e-01
    z[1,5,6]  R1360     -1.8665000796318054e-01
    z[1,5,6]  R1361     -1.3384471833705902e-01
    z[1,5,6]  R1362     -1.6737556457519531e-01
    z[1,5,6]  R1363     -1.9298050552606583e-02
    z[1,5,6]  R1364     -1.5526151657104492e-01
    z[1,5,6]  R1365     -7.1109756827354431e-02
    z[1,5,6]  R1366     -1.9608356058597565e-01
    z[1,5,6]  R1367     -2.3779530823230743e-01
    z[1,5,6]  R1368     -4.6682038903236389e-01
    z[1,5,6]  R1369     -3.0959886312484741e-01
    z[1,5,6]  R1370     2.9122793674468994e-01
    z[1,5,6]  R1371     1.1080313473939896e-01
    z[1,5,6]  R1372     -6.8453967571258545e-01
    z[1,5,6]  R1373     -4.1320380568504333e-01
    z[1,5,6]  R1374     4.7924613952636719e-01
    z[1,5,6]  R1375     5.4809981584548950e-01
    z[1,5,6]  R1376     -1.1365757137537003e-01
    z[1,5,6]  R1377     -1.4261193573474884e-01
    z[1,5,6]  R1378     -7.7522225677967072e-02
    z[1,5,6]  R1379     -1.8059577047824860e-01
    z[1,5,6]  R1380     -7.2199523448944092e-02
    z[1,5,6]  R1381     1.6902619600296021e-01
    z[1,5,6]  R1382     -2.3229663074016571e-01
    z[1,5,6]  R1383     -2.8217615559697151e-02
    z[1,5,6]  R1384     -2.4007629603147507e-02
    z[1,5,6]  R1385     -1.7738421261310577e-01
    z[1,5,6]  R1386     4.8832595348358154e-01
    z[1,5,6]  R1387     -2.4512539803981781e-01
    z[1,5,6]  R1388     -8.6079455912113190e-02
    z[1,5,6]  R1389     -3.3156612515449524e-01
    z[1,5,6]  R1390     2.8960786759853363e-02
    z[1,5,6]  R1391     -2.5481003522872925e-01
    z[1,5,6]  R1392     1.3467422127723694e-01
    z[1,5,6]  R1393     1.0879641771316528e-01
    z[1,5,6]  R1394     3.0809977650642395e-01
    z[1,5,6]  R1395     3.7304118275642395e-01
    z[1,5,6]  R1396     1.1342987418174744e-01
    z[1,5,6]  R1397     -1.6270875930786133e-01
    z[1,5,6]  R1398     3.9924681186676025e-02
    z[1,5,6]  R1399     -2.3157656192779541e-01
    z[1,5,6]  R1400     3.9496082812547684e-02
    z[1,5,6]  R1401     -2.0244711637496948e-01
    z[1,5,6]  R1402     -3.8225898146629333e-01
    z[1,5,6]  R1403     -2.5455081462860107e-01
    z[1,5,6]  R1404     -2.0312076434493065e-02
    z[1,5,6]  R1405     1.2939487397670746e-01
    z[1,5,6]  R1406     1.0314755886793137e-01
    z[1,5,6]  R1407     3.5929429531097412e-01
    z[1,5,6]  R1408     -4.9746152758598328e-01
    z[1,5,6]  R1409     3.5357251763343811e-01
    z[1,5,6]  R1410     -5.3053814172744751e-01
    z[1,5,6]  R1411     -1.2930710613727570e-01
    z[1,5,6]  R1412     -5.7356774806976318e-01
    z[1,5,6]  R1413     -3.0101948976516724e-01
    z[1,5,6]  R1414     1.8088242411613464e-01
    z[1,5,6]  R1415     4.8972561955451965e-01
    z[1,5,6]  R1416     3.6241775751113892e-01
    z[1,5,6]  R1417     -2.9049712419509888e-01
    z[1,5,6]  R1418     -2.3624455928802490e-01
    z[1,5,6]  R1419     4.2786914110183716e-01
    z[1,5,6]  R1420     2.8338947892189026e-01
    z[1,5,6]  R1421     4.8365625739097595e-01
    z[1,5,6]  R1422     0.19088114798069
    z[1,5,6]  R1423     6.0252988338470459e-01
    z[1,5,6]  R1424     -0.0972653478384018
    z[1,5,6]  R1425     5.3693417459726334e-02
    z[1,5,6]  R1426     6.0087740421295166e-01
    z[1,5,6]  R1427     -5.4085552692413330e-01
    z[1,5,6]  R1428     -1.0240268707275391e-01
    z[1,5,6]  R1429     1.4011496305465698e-01
    z[1,5,6]  R1430     3.1017169356346130e-01
    z[1,5,6]  R1431     5.2726560831069946e-01
    z[1,5,6]  R1432     5.6427329778671265e-01
    z[1,5,6]  R1433     -1.6300034523010254e-01
    z[1,5,6]  R1434     -2.3612719774246216e-01
    z[1,5,6]  R1435     6.5532989799976349e-02
    z[1,5,6]  R1436     -1.9043833017349243e-01
    z[1,5,6]  R1437     -1.1923649907112122e-01
    z[1,5,6]  R1438     4.7771230340003967e-01
    z[1,5,6]  R1439     1.5649099647998810e-01
    z[1,5,6]  R1440     5.2848167717456818e-02
    z[1,5,6]  R1441     -6.4299695193767548e-02
    z[1,5,6]  R1442     2.0884481072425842e-01
    z[1,5,6]  R1443     4.1663125157356262e-01
    z[5,1,0]  R11       1
    z[5,1,0]  R47       -1
    z[5,1,0]  R1444     -1
    z[5,1,0]  R1445     1
    z[5,1,0]  R1458     -1.3997809030115604e-02
    z[5,1,0]  R1459     5.5758005380630493e-01
    z[5,1,0]  R1460     5.0523781776428223e-01
    z[5,1,0]  R1461     -5.2187938243150711e-02
    z[5,1,0]  R1462     1.2089616805315018e-01
    z[5,1,0]  R1463     -8.6801508441567421e-03
    z[5,1,0]  R1464     8.7563628330826759e-03
    z[5,1,0]  R1465     -7.5780510902404785e-02
    z[5,1,0]  R1466     -2.1654142066836357e-02
    z[5,1,0]  R1467     8.2768142223358154e-01
    z[5,1,0]  R1468     4.0742865204811096e-01
    z[5,1,0]  R1469     4.3945017457008362e-01
    z[5,1,0]  R1470     3.8547104597091675e-01
    z[5,1,0]  R1471     -5.6935763359069824e-01
    z[5,1,0]  R1472     1.4344798028469086e-01
    z[5,1,0]  R1473     -5.0438129901885986e-01
    z[5,1,0]  R1474     2.9635295271873474e-01
    z[5,1,0]  R1475     3.9452192187309265e-01
    z[5,1,0]  R1476     2.0532502233982086e-01
    z[5,1,0]  R1477     3.9675658941268921e-01
    z[5,1,0]  R1478     -9.2806547880172729e-02
    z[5,1,0]  R1479     7.5493997335433960e-01
    z[5,1,0]  R1480     3.9099308848381042e-01
    z[5,1,0]  R1481     -3.3919128775596619e-01
    z[5,1,0]  R1482     5.5431425571441650e-01
    z[5,1,0]  R1483     6.5923231840133667e-01
    z[5,1,0]  R1484     6.0001599788665771e-01
    z[5,1,0]  R1485     -5.4473632574081421e-01
    z[5,1,0]  R1486     6.8981027603149414e-01
    z[5,1,0]  R1487     7.3579502105712891e-01
    z[5,1,0]  R1488     7.4069178104400635e-01
    z[5,1,0]  R1489     7.2650265693664551e-01
    z[5,1,0]  R1490     5.7322221994400024e-01
    z[5,1,0]  R1491     6.9887030124664307e-01
    z[5,1,0]  R1492     7.1005409955978394e-01
    z[5,1,0]  R1493     -7.6446205377578735e-01
    z[5,1,0]  R1494     -8.9940339326858521e-01
    z[5,1,0]  R1495     -0.898152232170105
    z[5,1,0]  R1496     -8.1273835897445679e-01
    z[5,1,0]  R1497     -7.4537557363510132e-01
    z[5,1,0]  R1498     -5.4846620559692383e-01
    z[5,1,0]  R1499     -5.3737568855285645e-01
    z[5,1,0]  R1500     -3.4947690367698669e-01
    z[5,1,0]  R1501     -3.8337504863739014e-01
    z[5,1,0]  R1502     -3.3478114008903503e-01
    z[5,1,0]  R1503     -2.9309570789337158e-01
    z[5,1,0]  R1504     -4.8481833934783936e-01
    z[5,1,0]  R1505     -5.7584816217422485e-01
    z[5,1,0]  R1506     2.5187286734580994e-01
    z[5,1,0]  R1507     4.6663612127304077e-02
    z[5,1,0]  R1508     9.1005897521972656e-01
    z[5,1,0]  R1509     1.3805174827575684e-01
    z[5,1,0]  R1510     4.7126758098602295e-01
    z[5,1,0]  R1511     4.3676313757896423e-01
    z[5,1,0]  R1512     0.534625232219696
    z[5,1,0]  R1513     7.4053883552551270e-01
    z[5,1,0]  R1514     7.1643579006195068e-01
    z[5,1,0]  R1515     6.3351887464523315e-01
    z[5,1,0]  R1516     8.7949562072753906e-01
    z[5,1,0]  R1517     7.2757941484451294e-01
    z[5,1,0]  R1518     -8.9046663045883179e-01
    z[5,1,0]  R1519     -7.7508997917175293e-01
    z[5,1,0]  R1520     -5.2592891454696655e-01
    z[5,1,0]  R1521     -7.9635888338088989e-01
    z[5,1,0]  R1522     -6.9828587770462036e-01
    z[5,1,0]  R1523     -6.2233519554138184e-01
    z[5,1,0]  R1524     -5.0729984045028687e-01
    z[5,1,0]  R1525     3.2287669181823730e-01
    z[5,1,0]  R1526     2.2204083204269409e-01
    z[5,1,0]  R1527     4.0584060549736023e-01
    z[5,1,0]  R1528     -4.2859551310539246e-01
    z[5,1,0]  R1529     -5.0588089227676392e-01
    z[5,1,0]  R1530     -6.6504962742328644e-02
    z[5,1,0]  R1531     9.3613542616367340e-02
    z[5,1,0]  R1532     1.6056878864765167e-01
    z[5,1,0]  R1533     1.9732825458049774e-01
    z[5,1,0]  R1534     5.2592545747756958e-01
    z[5,1,0]  R1535     3.2273855805397034e-01
    z[5,1,0]  R1536     0.145841583609581
    z[5,1,0]  R1537     1.4634659886360168e-01
    z[5,1,0]  R1538     -4.9644985795021057e-01
    z[5,1,0]  R1539     -5.6475734710693359e-01
    z[5,1,0]  R1540     -4.7109922766685486e-01
    z[5,1,0]  R1541     5.1703029870986938e-01
    z[5,1,0]  R1542     4.9828074872493744e-02
    z[5,1,0]  R1543     -6.4766839146614075e-02
    z[5,1,0]  R1544     3.1029042601585388e-01
    z[5,1,0]  R1545     2.6755779981613159e-01
    z[5,1,0]  R1546     4.5220926403999329e-01
    z[5,1,0]  R1547     7.0565128326416016e-01
    z[5,1,0]  R1548     -7.2389864921569824e-01
    z[5,1,0]  R1549     4.7058889269828796e-01
    z[5,1,0]  R1550     3.2659158110618591e-01
    z[5,1,0]  R1551     2.9244866967201233e-01
    z[5,1,0]  R1552     1.8340951204299927e-01
    z[5,1,0]  R1553     1.1921054124832153e-01
    z[5,1,0]  R1554     4.4222906231880188e-01
    z[5,1,0]  R1555     4.4989496469497681e-01
    z[5,1,0]  R1556     0.354343980550766
    z[5,1,0]  R1557     4.8459321260452271e-01
    z[5,1,1]  R12       1
    z[5,1,1]  R48       -1
    z[5,1,1]  R1446     -1
    z[5,1,1]  R1447     1
    z[5,1,1]  R1458     1.8905310332775116e-01
    z[5,1,1]  R1459     2.1017962694168091e-01
    z[5,1,1]  R1460     1.5771448612213135e-01
    z[5,1,1]  R1461     2.1219782531261444e-01
    z[5,1,1]  R1462     2.2072224318981171e-01
    z[5,1,1]  R1463     2.5600370764732361e-01
    z[5,1,1]  R1464     1.7782041430473328e-01
    z[5,1,1]  R1465     4.4399213790893555e-01
    z[5,1,1]  R1466     1.2944982945919037e-01
    z[5,1,1]  R1467     1.2567570805549622e-01
    z[5,1,1]  R1468     -6.5594899654388428e-01
    z[5,1,1]  R1469     -3.3320096135139465e-01
    z[5,1,1]  R1470     -0.617285430431366
    z[5,1,1]  R1471     2.8803017735481262e-01
    z[5,1,1]  R1472     -9.5162212848663330e-01
    z[5,1,1]  R1473     4.3394145369529724e-01
    z[5,1,1]  R1474     -5.5049043893814087e-01
    z[5,1,1]  R1475     -3.2727000117301941e-01
    z[5,1,1]  R1476     -9.1263920068740845e-01
    z[5,1,1]  R1477     -3.4390786290168762e-01
    z[5,1,1]  R1478     9.4008797407150269e-01
    z[5,1,1]  R1479     -2.5318646430969238e-01
    z[5,1,1]  R1480     5.1840496063232422e-01
    z[5,1,1]  R1481     -3.7790334224700928e-01
    z[5,1,1]  R1482     0.398128867149353
    z[5,1,1]  R1483     -2.2204957902431488e-01
    z[5,1,1]  R1484     1.0989034920930862e-01
    z[5,1,1]  R1485     -8.0375164747238159e-02
    z[5,1,1]  R1486     2.8845466673374176e-02
    z[5,1,1]  R1487     -3.4753879904747009e-01
    z[5,1,1]  R1488     -0.0806993618607521
    z[5,1,1]  R1489     -0.042476586997509
    z[5,1,1]  R1490     2.8685966134071350e-01
    z[5,1,1]  R1491     -4.3638747930526733e-01
    z[5,1,1]  R1492     1.0166170448064804e-01
    z[5,1,1]  R1493     2.1396577358245850e-01
    z[5,1,1]  R1494     -1.3196200598031282e-03
    z[5,1,1]  R1495     -0.0641687661409378
    z[5,1,1]  R1496     -2.0167045295238495e-01
    z[5,1,1]  R1497     1.0248646140098572e-02
    z[5,1,1]  R1498     3.8442826271057129e-01
    z[5,1,1]  R1499     -2.6387885212898254e-01
    z[5,1,1]  R1500     3.1713566184043884e-01
    z[5,1,1]  R1501     -6.0303714126348495e-03
    z[5,1,1]  R1502     2.7103728055953979e-01
    z[5,1,1]  R1503     1.1794888228178024e-01
    z[5,1,1]  R1504     1.6418954730033875e-01
    z[5,1,1]  R1505     4.1713860630989075e-01
    z[5,1,1]  R1506     -6.7177355289459229e-01
    z[5,1,1]  R1507     -6.6847103834152222e-01
    z[5,1,1]  R1508     2.9807296395301819e-01
    z[5,1,1]  R1509     2.4385875463485718e-01
    z[5,1,1]  R1510     -3.8807126879692078e-01
    z[5,1,1]  R1511     3.3396932482719421e-01
    z[5,1,1]  R1512     3.5263964533805847e-01
    z[5,1,1]  R1513     2.4720968306064606e-01
    z[5,1,1]  R1514     -3.7510228157043457e-01
    z[5,1,1]  R1515     -5.7581549882888794e-01
    z[5,1,1]  R1516     1.4785762131214142e-01
    z[5,1,1]  R1517     -3.0817532539367676e-01
    z[5,1,1]  R1518     -2.1939820051193237e-01
    z[5,1,1]  R1519     1.9416160881519318e-01
    z[5,1,1]  R1520     4.9348825216293335e-01
    z[5,1,1]  R1521     -1.4357546344399452e-02
    z[5,1,1]  R1522     -7.9884245991706848e-02
    z[5,1,1]  R1523     1.5804682672023773e-01
    z[5,1,1]  R1524     1.9286023080348969e-01
    z[5,1,1]  R1525     6.6589933633804321e-01
    z[5,1,1]  R1526     -4.4424888491630554e-01
    z[5,1,1]  R1527     -4.4897049665451050e-02
    z[5,1,1]  R1528     4.5701089501380920e-01
    z[5,1,1]  R1529     6.6072843968868256e-02
    z[5,1,1]  R1530     -6.2168675661087036e-01
    z[5,1,1]  R1531     -7.2063046693801880e-01
    z[5,1,1]  R1532     -1.4998872578144073e-01
    z[5,1,1]  R1533     -2.9883316159248352e-01
    z[5,1,1]  R1534     -4.1531211137771606e-01
    z[5,1,1]  R1535     -3.4737905859947205e-01
    z[5,1,1]  R1536     -2.5700709223747253e-01
    z[5,1,1]  R1537     0.885625422000885
    z[5,1,1]  R1538     5.2399653196334839e-01
    z[5,1,1]  R1539     6.6193324327468872e-01
    z[5,1,1]  R1540     2.1502195298671722e-01
    z[5,1,1]  R1541     -3.4582906961441040e-01
    z[5,1,1]  R1542     -0.293354332447052
    z[5,1,1]  R1543     -5.0657910108566284e-01
    z[5,1,1]  R1544     -5.3950250148773193e-01
    z[5,1,1]  R1545     -1.9510462880134583e-01
    z[5,1,1]  R1546     -3.7244316935539246e-01
    z[5,1,1]  R1547     -1.6403743624687195e-01
    z[5,1,1]  R1548     -3.8011498749256134e-02
    z[5,1,1]  R1549     -2.4596635997295380e-01
    z[5,1,1]  R1550     -8.6322838068008423e-01
    z[5,1,1]  R1551     -9.1503816843032837e-01
    z[5,1,1]  R1552     -9.3509048223495483e-01
    z[5,1,1]  R1553     -8.8453543186187744e-01
    z[5,1,1]  R1554     -7.9997146129608154e-01
    z[5,1,1]  R1555     -7.4838405847549438e-01
    z[5,1,1]  R1556     -0.752017617225647
    z[5,1,1]  R1557     -7.7209919691085815e-01
    z[5,1,2]  R13       1
    z[5,1,2]  R49       -1
    z[5,1,2]  R1448     -1
    z[5,1,2]  R1449     1
    z[5,1,2]  R1458     -2.8237661719322205e-01
    z[5,1,2]  R1459     -1.2899863719940186e-01
    z[5,1,2]  R1460     -5.5287480354309082e-01
    z[5,1,2]  R1461     -6.1866492033004761e-01
    z[5,1,2]  R1462     -2.5025400519371033e-01
    z[5,1,2]  R1463     5.1847383379936218e-02
    z[5,1,2]  R1464     -6.7677521705627441e-01
    z[5,1,2]  R1465     -8.1299352645874023e-01
    z[5,1,2]  R1466     -5.4551094770431519e-01
    z[5,1,2]  R1467     2.4136213958263397e-01
    z[5,1,2]  R1468     4.0681045502424240e-02
    z[5,1,2]  R1469     1.4646363258361816e-01
    z[5,1,2]  R1470     -2.1235128864645958e-02
    z[5,1,2]  R1471     2.7705490589141846e-01
    z[5,1,2]  R1472     -2.4117190390825272e-02
    z[5,1,2]  R1473     5.7482112199068069e-02
    z[5,1,2]  R1474     4.7844356298446655e-01
    z[5,1,2]  R1475     -3.3507618308067322e-01
    z[5,1,2]  R1476     0.0655309185385704
    z[5,1,2]  R1477     3.3724945783615112e-01
    z[5,1,2]  R1478     1.1411363631486893e-01
    z[5,1,2]  R1479     1.8625865876674652e-01
    z[5,1,2]  R1480     -0.144407719373703
    z[5,1,2]  R1481     -4.1109225153923035e-01
    z[5,1,2]  R1482     2.6722699403762817e-01
    z[5,1,2]  R1483     5.5550694465637207e-01
    z[5,1,2]  R1484     5.9672847390174866e-02
    z[5,1,2]  R1485     -2.2553333640098572e-01
    z[5,1,2]  R1486     6.7317962646484375e-02
    z[5,1,2]  R1487     -2.5654649734497070e-01
    z[5,1,2]  R1488     3.3794519305229187e-01
    z[5,1,2]  R1489     -2.4270488321781158e-01
    z[5,1,2]  R1490     1.8770545721054077e-01
    z[5,1,2]  R1491     1.3617783784866333e-01
    z[5,1,2]  R1492     3.6944913864135742e-01
    z[5,1,2]  R1493     -3.4059572219848633e-01
    z[5,1,2]  R1494     -1.6890175640583038e-01
    z[5,1,2]  R1495     6.1599317938089371e-02
    z[5,1,2]  R1496     1.7163710668683052e-02
    z[5,1,2]  R1497     -3.3075023442506790e-02
    z[5,1,2]  R1498     4.0556451678276062e-01
    z[5,1,2]  R1499     5.7136386632919312e-01
    z[5,1,2]  R1500     6.8847596645355225e-01
    z[5,1,2]  R1501     2.0886674523353577e-01
    z[5,1,2]  R1502     -1.5248348005115986e-02
    z[5,1,2]  R1503     5.3124696016311646e-01
    z[5,1,2]  R1504     -2.1343810856342316e-01
    z[5,1,2]  R1505     -2.7728474140167236e-01
    z[5,1,2]  R1506     -1.0162437707185745e-01
    z[5,1,2]  R1507     -2.3174107074737549e-01
    z[5,1,2]  R1508     -1.1740779131650925e-01
    z[5,1,2]  R1509     -6.8835496902465820e-01
    z[5,1,2]  R1510     5.9588211774826050e-01
    z[5,1,2]  R1511     -6.0378080606460571e-01
    z[5,1,2]  R1512     -3.1660494208335876e-01
    z[5,1,2]  R1513     -4.0137115865945816e-02
    z[5,1,2]  R1514     2.5910025835037231e-01
    z[5,1,2]  R1515     4.1383656859397888e-01
    z[5,1,2]  R1516     -2.9499918222427368e-01
    z[5,1,2]  R1517     3.6738941073417664e-01
    z[5,1,2]  R1518     -1.9834670424461365e-01
    z[5,1,2]  R1519     -3.6132711917161942e-02
    z[5,1,2]  R1520     2.9677665233612061e-01
    z[5,1,2]  R1521     2.6175066828727722e-01
    z[5,1,2]  R1522     -1.4722524583339691e-01
    z[5,1,2]  R1523     -2.3189820349216461e-01
    z[5,1,2]  R1524     -7.4641996622085571e-01
    z[5,1,2]  R1525     -5.8503359556198120e-01
    z[5,1,2]  R1526     -1.5049757063388824e-01
    z[5,1,2]  R1527     4.7004982829093933e-02
    z[5,1,2]  R1528     -4.8428988456726074e-01
    z[5,1,2]  R1529     -2.0427714288234711e-01
    z[5,1,2]  R1530     1.7326584085822105e-02
    z[5,1,2]  R1531     -2.0517694950103760e-01
    z[5,1,2]  R1532     -6.6344380378723145e-02
    z[5,1,2]  R1533     1.9156554341316223e-01
    z[5,1,2]  R1534     0.0657258853316307
    z[5,1,2]  R1535     -4.1535636410117149e-03
    z[5,1,2]  R1536     -2.2964255511760712e-01
    z[5,1,2]  R1537     -1.2464547902345657e-01
    z[5,1,2]  R1538     -5.8535808324813843e-01
    z[5,1,2]  R1539     -2.8683599829673767e-01
    z[5,1,2]  R1540     -4.8880372196435928e-02
    z[5,1,2]  R1541     -2.0156674087047577e-01
    z[5,1,2]  R1542     -2.2471249103546143e-01
    z[5,1,2]  R1543     -3.3468988537788391e-01
    z[5,1,2]  R1544     1.8343251943588257e-01
    z[5,1,2]  R1545     -2.5035008788108826e-01
    z[5,1,2]  R1546     2.0671902596950531e-01
    z[5,1,2]  R1547     -0.0722411647439003
    z[5,1,2]  R1548     -5.3254854679107666e-01
    z[5,1,2]  R1549     -1.6451023519039154e-01
    z[5,1,2]  R1550     1.6175574064254761e-01
    z[5,1,2]  R1551     0.000609697075560689
    z[5,1,2]  R1552     -5.0387654453516006e-02
    z[5,1,2]  R1553     2.9645591974258423e-01
    z[5,1,2]  R1554     -3.1568646430969238e-01
    z[5,1,2]  R1555     3.7175349891185760e-02
    z[5,1,2]  R1556     3.4580063819885254e-01
    z[5,1,2]  R1557     1.1843249201774597e-01
    z[5,1,3]  R14       1
    z[5,1,3]  R50       -1
    z[5,1,3]  R1450     -1
    z[5,1,3]  R1451     1
    z[5,1,3]  R1458     6.6540360450744629e-01
    z[5,1,3]  R1459     6.5713709592819214e-01
    z[5,1,3]  R1460     5.0276738405227661e-01
    z[5,1,3]  R1461     3.6557447910308838e-01
    z[5,1,3]  R1462     3.9716669917106628e-01
    z[5,1,3]  R1463     3.7337687611579895e-01
    z[5,1,3]  R1464     4.5556488633155823e-01
    z[5,1,3]  R1465     1.1686177551746368e-01
    z[5,1,3]  R1466     5.0188434123992920e-01
    z[5,1,3]  R1467     2.3232667148113251e-01
    z[5,1,3]  R1468     -5.7432240247726440e-01
    z[5,1,3]  R1469     -6.3345789909362793e-01
    z[5,1,3]  R1470     -4.6149781346321106e-01
    z[5,1,3]  R1471     -4.6182355284690857e-01
    z[5,1,3]  R1472     -1.3038317859172821e-01
    z[5,1,3]  R1473     -5.3972136974334717e-01
    z[5,1,3]  R1474     -3.8895878195762634e-01
    z[5,1,3]  R1475     -5.3050237894058228e-01
    z[5,1,3]  R1476     -2.5320374965667725e-01
    z[5,1,3]  R1477     -4.2305126786231995e-01
    z[5,1,3]  R1478     2.9098740220069885e-01
    z[5,1,3]  R1479     -2.9129517078399658e-01
    z[5,1,3]  R1480     -1.4781875908374786e-01
    z[5,1,3]  R1481     -3.1002059578895569e-01
    z[5,1,3]  R1482     -3.9259654283523560e-01
    z[5,1,3]  R1483     -1.4276312291622162e-01
    z[5,1,3]  R1484     -2.5168719887733459e-01
    z[5,1,3]  R1485     -6.5503165125846863e-02
    z[5,1,3]  R1486     -1.3038103282451630e-01
    z[5,1,3]  R1487     -0.469923198223114
    z[5,1,3]  R1488     1.0379044711589813e-01
    z[5,1,3]  R1489     -1.3402193784713745e-01
    z[5,1,3]  R1490     -2.9712323099374771e-02
    z[5,1,3]  R1491     5.9156041592359543e-02
    z[5,1,3]  R1492     1.1013500392436981e-02
    z[5,1,3]  R1493     -4.3319210410118103e-01
    z[5,1,3]  R1494     -3.8658967614173889e-01
    z[5,1,3]  R1495     -4.2065268754959106e-01
    z[5,1,3]  R1496     -4.7309896349906921e-01
    z[5,1,3]  R1497     -4.2904523015022278e-01
    z[5,1,3]  R1498     3.9904925227165222e-01
    z[5,1,3]  R1499     -4.4947284460067749e-01
    z[5,1,3]  R1500     -2.5990280508995056e-01
    z[5,1,3]  R1501     -3.9733633399009705e-01
    z[5,1,3]  R1502     -2.7447342872619629e-01
    z[5,1,3]  R1503     -5.7482278347015381e-01
    z[5,1,3]  R1504     -6.4267545938491821e-01
    z[5,1,3]  R1505     -2.6924726553261280e-03
    z[5,1,3]  R1506     -4.3043103814125061e-01
    z[5,1,3]  R1507     -5.6083846092224121e-01
    z[5,1,3]  R1508     -4.9707889556884766e-03
    z[5,1,3]  R1509     5.6251049041748047e-01
    z[5,1,3]  R1510     4.5717990398406982e-01
    z[5,1,3]  R1511     5.6790667772293091e-01
    z[5,1,3]  R1512     6.6686850786209106e-01
    z[5,1,3]  R1513     4.8297506570816040e-01
    z[5,1,3]  R1514     4.2766058444976807e-01
    z[5,1,3]  R1515     2.0888186991214752e-01
    z[5,1,3]  R1516     2.5776371359825134e-01
    z[5,1,3]  R1517     2.2306315600872040e-01
    z[5,1,3]  R1518     -1.1081153899431229e-01
    z[5,1,3]  R1519     -0.454868882894516
    z[5,1,3]  R1520     -4.9220845103263855e-01
    z[5,1,3]  R1521     0.456521600484848
    z[5,1,3]  R1522     0.0790027603507042
    z[5,1,3]  R1523     5.3736311197280884e-01
    z[5,1,3]  R1524     1.2507483363151550e-01
    z[5,1,3]  R1525     3.1046831607818604e-01
    z[5,1,3]  R1526     -4.5002856850624084e-01
    z[5,1,3]  R1527     -7.8516000509262085e-01
    z[5,1,3]  R1528     -0.120479054749012
    z[5,1,3]  R1529     8.1015847623348236e-02
    z[5,1,3]  R1530     -5.2535998821258545e-01
    z[5,1,3]  R1531     -4.3817153573036194e-01
    z[5,1,3]  R1532     -7.7117341756820679e-01
    z[5,1,3]  R1533     -6.7462337017059326e-01
    z[5,1,3]  R1534     -3.9227211475372314e-01
    z[5,1,3]  R1535     -6.4566022157669067e-01
    z[5,1,3]  R1536     -8.5562658309936523e-01
    z[5,1,3]  R1537     9.8151132464408875e-02
    z[5,1,3]  R1538     3.6296206712722778e-01
    z[5,1,3]  R1539     1.9905048608779907e-01
    z[5,1,3]  R1540     1.3431535661220551e-01
    z[5,1,3]  R1541     -6.5590482950210571e-01
    z[5,1,3]  R1542     -7.0590674877166748e-01
    z[5,1,3]  R1543     -4.9436318874359131e-01
    z[5,1,3]  R1544     -7.5713771581649780e-01
    z[5,1,3]  R1545     -8.6876374483108521e-01
    z[5,1,3]  R1546     -5.4235792160034180e-01
    z[5,1,3]  R1547     -6.7413049936294556e-01
    z[5,1,3]  R1548     8.8837943971157074e-02
    z[5,1,3]  R1549     -7.3519039154052734e-01
    z[5,1,3]  R1550     -1.9255171716213226e-01
    z[5,1,3]  R1551     1.3584984838962555e-01
    z[5,1,3]  R1552     2.1812172234058380e-01
    z[5,1,3]  R1553     9.1849960386753082e-02
    z[5,1,3]  R1554     1.8861801922321320e-01
    z[5,1,3]  R1555     -2.7884244918823242e-01
    z[5,1,3]  R1556     1.2510600499808788e-02
    z[5,1,3]  R1557     -2.7186835184693336e-02
    z[5,1,4]  R15       1
    z[5,1,4]  R51       -1
    z[5,1,4]  R1452     -1
    z[5,1,4]  R1453     1
    z[5,1,4]  R1458     -5.6736266613006592e-01
    z[5,1,4]  R1459     -4.2338716983795166e-01
    z[5,1,4]  R1460     -2.7609494328498840e-01
    z[5,1,4]  R1461     -5.4130053520202637e-01
    z[5,1,4]  R1462     -5.4473882913589478e-01
    z[5,1,4]  R1463     -7.5190836191177368e-01
    z[5,1,4]  R1464     6.0095246881246567e-02
    z[5,1,4]  R1465     1.6605155169963837e-01
    z[5,1,4]  R1466     -2.0370914041996002e-01
    z[5,1,4]  R1467     2.3565191030502319e-01
    z[5,1,4]  R1468     1.3322633504867554e-01
    z[5,1,4]  R1469     -1.5834622085094452e-02
    z[5,1,4]  R1470     0.277626633644104
    z[5,1,4]  R1471     0.466239869594574
    z[5,1,4]  R1472     2.0291706547141075e-02
    z[5,1,4]  R1473     2.7662605047225952e-01
    z[5,1,4]  R1474     7.7883275225758553e-03
    z[5,1,4]  R1475     2.1679170429706573e-01
    z[5,1,4]  R1476     -1.0537905991077423e-01
    z[5,1,4]  R1477     0.0986253172159195
    z[5,1,4]  R1478     0.00849322509020567
    z[5,1,4]  R1479     2.1699893474578857e-01
    z[5,1,4]  R1480     3.9246338605880737e-01
    z[5,1,4]  R1481     3.7728101015090942e-01
    z[5,1,4]  R1482     5.4241657257080078e-02
    z[5,1,4]  R1483     0.154581680893898
    z[5,1,4]  R1484     3.2734036445617676e-01
    z[5,1,4]  R1485     6.6526606678962708e-02
    z[5,1,4]  R1486     1.0396488755941391e-01
    z[5,1,4]  R1487     -1.1083486676216125e-01
    z[5,1,4]  R1488     2.1375261247158051e-01
    z[5,1,4]  R1489     5.8546119928359985e-01
    z[5,1,4]  R1490     3.8419520854949951e-01
    z[5,1,4]  R1491     3.7921886891126633e-02
    z[5,1,4]  R1492     2.2218170762062073e-01
    z[5,1,4]  R1493     3.6676891148090363e-02
    z[5,1,4]  R1494     -7.9336911439895630e-02
    z[5,1,4]  R1495     -6.3870586454868317e-02
    z[5,1,4]  R1496     -1.1375338584184647e-01
    z[5,1,4]  R1497     -2.6194578409194946e-01
    z[5,1,4]  R1498     -3.1760153174400330e-01
    z[5,1,4]  R1499     1.2788502871990204e-01
    z[5,1,4]  R1500     -4.5941525697708130e-01
    z[5,1,4]  R1501     -4.5679351687431335e-01
    z[5,1,4]  R1502     -6.8453729152679443e-01
    z[5,1,4]  R1503     -2.0277164876461029e-02
    z[5,1,4]  R1504     5.1528328657150269e-01
    z[5,1,4]  R1505     5.8601063489913940e-01
    z[5,1,4]  R1506     3.4970134496688843e-01
    z[5,1,4]  R1507     2.0519576966762543e-01
    z[5,1,4]  R1508     -2.5997087359428406e-02
    z[5,1,4]  R1509     -3.1932753324508667e-01
    z[5,1,4]  R1510     -2.0619036257266998e-01
    z[5,1,4]  R1511     2.2363530471920967e-02
    z[5,1,4]  R1512     2.4442672729492188e-02
    z[5,1,4]  R1513     -2.2545643150806427e-01
    z[5,1,4]  R1514     -2.4691025912761688e-01
    z[5,1,4]  R1515     -1.8389484286308289e-01
    z[5,1,4]  R1516     6.4173959195613861e-02
    z[5,1,4]  R1517     -4.2985841631889343e-01
    z[5,1,4]  R1518     2.8474089503288269e-01
    z[5,1,4]  R1519     -1.8321696668863297e-02
    z[5,1,4]  R1520     1.2423494458198547e-01
    z[5,1,4]  R1521     -0.0837835893034935
    z[5,1,4]  R1522     -4.8522930592298508e-02
    z[5,1,4]  R1523     -2.8666019439697266e-01
    z[5,1,4]  R1524     -2.0664894580841064e-01
    z[5,1,4]  R1525     -3.7180971354246140e-02
    z[5,1,4]  R1526     -9.1457515954971313e-02
    z[5,1,4]  R1527     -8.6750283837318420e-02
    z[5,1,4]  R1528     1.3383789360523224e-01
    z[5,1,4]  R1529     -6.1846762895584106e-01
    z[5,1,4]  R1530     -9.6565060317516327e-02
    z[5,1,4]  R1531     -3.8908189535140991e-01
    z[5,1,4]  R1532     -1.9357408583164215e-01
    z[5,1,4]  R1533     -1.5970006585121155e-01
    z[5,1,4]  R1534     -3.8437676429748535e-01
    z[5,1,4]  R1535     -4.9526163935661316e-01
    z[5,1,4]  R1536     2.0835416018962860e-01
    z[5,1,4]  R1537     -2.9163017868995667e-01
    z[5,1,4]  R1538     0.0585007481276989
    z[5,1,4]  R1539     2.9259911179542542e-01
    z[5,1,4]  R1540     -6.8360525369644165e-01
    z[5,1,4]  R1541     -0.242141455411911
    z[5,1,4]  R1542     -2.4339766800403595e-01
    z[5,1,4]  R1543     -1.4195046387612820e-02
    z[5,1,4]  R1544     -0.0697336345911026
    z[5,1,4]  R1545     -7.0744507014751434e-02
    z[5,1,4]  R1546     -1.7798207700252533e-01
    z[5,1,4]  R1547     -3.3123213797807693e-03
    z[5,1,4]  R1548     -2.9495945572853088e-01
    z[5,1,4]  R1549     9.0996541082859039e-02
    z[5,1,4]  R1550     -2.4021466076374054e-01
    z[5,1,4]  R1551     -1.0266276448965073e-01
    z[5,1,4]  R1552     -1.9709125161170959e-01
    z[5,1,4]  R1553     1.9474083185195923e-01
    z[5,1,4]  R1554     -1.4570684731006622e-01
    z[5,1,4]  R1555     7.8483283519744873e-02
    z[5,1,4]  R1556     5.5651620030403137e-02
    z[5,1,4]  R1557     2.9908114671707153e-01
    z[5,1,5]  R16       1
    z[5,1,5]  R52       -1
    z[5,1,5]  R1454     -1
    z[5,1,5]  R1455     1
    z[5,1,5]  R1458     -3.4532821178436279e-01
    z[5,1,5]  R1459     -2.1436698734760284e-02
    z[5,1,5]  R1460     2.7303391695022583e-01
    z[5,1,5]  R1461     1.1729851365089417e-01
    z[5,1,5]  R1462     4.1483619809150696e-01
    z[5,1,5]  R1463     3.1923133134841919e-01
    z[5,1,5]  R1464     -1.3287958502769470e-01
    z[5,1,5]  R1465     2.7967765927314758e-01
    z[5,1,5]  R1466     2.5065195560455322e-01
    z[5,1,5]  R1467     -2.0192395150661469e-01
    z[5,1,5]  R1468     1.4752630889415741e-01
    z[5,1,5]  R1469     1.8181920051574707e-01
    z[5,1,5]  R1470     0.220264732837677
    z[5,1,5]  R1471     -3.2586917281150818e-02
    z[5,1,5]  R1472     -5.7722595520317554e-03
    z[5,1,5]  R1473     -5.5649623274803162e-02
    z[5,1,5]  R1474     3.8544493913650513e-01
    z[5,1,5]  R1475     -2.5023165345191956e-01
    z[5,1,5]  R1476     9.4785392284393311e-02
    z[5,1,5]  R1477     2.4255488812923431e-01
    z[5,1,5]  R1478     -1.9831936806440353e-02
    z[5,1,5]  R1479     4.4322180747985840e-01
    z[5,1,5]  R1480     -1.4351183176040649e-01
    z[5,1,5]  R1481     2.0533630251884460e-01
    z[5,1,5]  R1482     5.4337686300277710e-01
    z[5,1,5]  R1483     3.7895879149436951e-01
    z[5,1,5]  R1484     5.9802955389022827e-01
    z[5,1,5]  R1485     -0.599342405796051
    z[5,1,5]  R1486     4.1543442010879517e-01
    z[5,1,5]  R1487     -1.1101827770471573e-01
    z[5,1,5]  R1488     4.6737310290336609e-01
    z[5,1,5]  R1489     2.1555164456367493e-01
    z[5,1,5]  R1490     0.607568085193634
    z[5,1,5]  R1491     0.532397449016571
    z[5,1,5]  R1492     -2.6702085137367249e-01
    z[5,1,5]  R1493     2.0080116391181946e-01
    z[5,1,5]  R1494     -6.3286215066909790e-02
    z[5,1,5]  R1495     -1.5741702169179916e-02
    z[5,1,5]  R1496     -1.3458141684532166e-01
    z[5,1,5]  R1497     1.3015043735504150e-01
    z[5,1,5]  R1498     -3.3961209654808044e-01
    z[5,1,5]  R1499     1.8544797599315643e-01
    z[5,1,5]  R1500     1.1440439522266388e-01
    z[5,1,5]  R1501     6.5428024530410767e-01
    z[5,1,5]  R1502     4.4936504960060120e-01
    z[5,1,5]  R1503     -3.0648830533027649e-01
    z[5,1,5]  R1504     1.1762021481990814e-01
    z[5,1,5]  R1505     -2.5380519032478333e-01
    z[5,1,5]  R1506     -3.1958609819412231e-01
    z[5,1,5]  R1507     -8.4092825651168823e-02
    z[5,1,5]  R1508     -1.1361759155988693e-01
    z[5,1,5]  R1509     4.4120015809312463e-04
    z[5,1,5]  R1510     -2.7406115084886551e-02
    z[5,1,5]  R1511     1.1172773083671927e-03
    z[5,1,5]  R1512     -9.8782189190387726e-02
    z[5,1,5]  R1513     -2.7341619133949280e-01
    z[5,1,5]  R1514     1.3734828680753708e-02
    z[5,1,5]  R1515     -2.1597044542431831e-02
    z[5,1,5]  R1516     1.3793526589870453e-01
    z[5,1,5]  R1517     0.0759831964969635
    z[5,1,5]  R1518     4.6145290136337280e-02
    z[5,1,5]  R1519     3.8462081551551819e-01
    z[5,1,5]  R1520     0.309256374835968
    z[5,1,5]  R1521     -1.5847636759281158e-01
    z[5,1,5]  R1522     5.0776267051696777e-01
    z[5,1,5]  R1523     2.5914970040321350e-01
    z[5,1,5]  R1524     7.1749143302440643e-02
    z[5,1,5]  R1525     -3.7542516365647316e-03
    z[5,1,5]  R1526     -2.2628861665725708e-01
    z[5,1,5]  R1527     -1.9060148298740387e-01
    z[5,1,5]  R1528     -3.3287471532821655e-01
    z[5,1,5]  R1529     -9.2252299189567566e-02
    z[5,1,5]  R1530     -5.5725795030593872e-01
    z[5,1,5]  R1531     -2.5712516903877258e-01
    z[5,1,5]  R1532     -5.5599504709243774e-01
    z[5,1,5]  R1533     -5.6729829311370850e-01
    z[5,1,5]  R1534     -4.8965570330619812e-01
    z[5,1,5]  R1535     -2.9055011272430420e-01
    z[5,1,5]  R1536     1.7456176877021790e-01
    z[5,1,5]  R1537     2.8850591182708740e-01
    z[5,1,5]  R1538     -2.4103295058012009e-02
    z[5,1,5]  R1539     -6.2595404684543610e-02
    z[5,1,5]  R1540     -7.4984863400459290e-02
    z[5,1,5]  R1541     -1.5337084233760834e-01
    z[5,1,5]  R1542     -5.4406648874282837e-01
    z[5,1,5]  R1543     -5.2214270830154419e-01
    z[5,1,5]  R1544     7.0977574214339256e-03
    z[5,1,5]  R1545     5.4667755961418152e-02
    z[5,1,5]  R1546     -5.1970493793487549e-01
    z[5,1,5]  R1547     -6.0246225446462631e-02
    z[5,1,5]  R1548     3.3154781907796860e-02
    z[5,1,5]  R1549     -5.5117465555667877e-02
    z[5,1,5]  R1550     1.1985098570585251e-01
    z[5,1,5]  R1551     1.4734235405921936e-01
    z[5,1,5]  R1552     -3.7574142217636108e-02
    z[5,1,5]  R1553     -1.2454599142074585e-01
    z[5,1,5]  R1554     8.0336481332778931e-02
    z[5,1,5]  R1555     3.3352074027061462e-01
    z[5,1,5]  R1556     0.199890598654747
    z[5,1,5]  R1557     4.5918133109807968e-03
    z[5,1,6]  R17       1
    z[5,1,6]  R53       -1
    z[5,1,6]  R1456     -1
    z[5,1,6]  R1457     1
    z[5,1,6]  R1458     -2.0312076434493065e-02
    z[5,1,6]  R1459     1.2939487397670746e-01
    z[5,1,6]  R1460     1.0314755886793137e-01
    z[5,1,6]  R1461     3.5929429531097412e-01
    z[5,1,6]  R1462     -4.9746152758598328e-01
    z[5,1,6]  R1463     3.5357251763343811e-01
    z[5,1,6]  R1464     -5.3053814172744751e-01
    z[5,1,6]  R1465     -1.2930710613727570e-01
    z[5,1,6]  R1466     -5.7356774806976318e-01
    z[5,1,6]  R1467     -3.0101948976516724e-01
    z[5,1,6]  R1468     1.8088242411613464e-01
    z[5,1,6]  R1469     4.8972561955451965e-01
    z[5,1,6]  R1470     3.6241775751113892e-01
    z[5,1,6]  R1471     -2.9049712419509888e-01
    z[5,1,6]  R1472     -2.3624455928802490e-01
    z[5,1,6]  R1473     4.2786914110183716e-01
    z[5,1,6]  R1474     2.8338947892189026e-01
    z[5,1,6]  R1475     4.8365625739097595e-01
    z[5,1,6]  R1476     0.19088114798069
    z[5,1,6]  R1477     6.0252988338470459e-01
    z[5,1,6]  R1478     -0.0972653478384018
    z[5,1,6]  R1479     5.3693417459726334e-02
    z[5,1,6]  R1480     6.0087740421295166e-01
    z[5,1,6]  R1481     -5.4085552692413330e-01
    z[5,1,6]  R1482     -1.0240268707275391e-01
    z[5,1,6]  R1483     1.4011496305465698e-01
    z[5,1,6]  R1484     3.1017169356346130e-01
    z[5,1,6]  R1485     5.2726560831069946e-01
    z[5,1,6]  R1486     5.6427329778671265e-01
    z[5,1,6]  R1487     -1.6300034523010254e-01
    z[5,1,6]  R1488     -2.3612719774246216e-01
    z[5,1,6]  R1489     6.5532989799976349e-02
    z[5,1,6]  R1490     -1.9043833017349243e-01
    z[5,1,6]  R1491     -1.1923649907112122e-01
    z[5,1,6]  R1492     4.7771230340003967e-01
    z[5,1,6]  R1493     1.5649099647998810e-01
    z[5,1,6]  R1494     5.2848167717456818e-02
    z[5,1,6]  R1495     -6.4299695193767548e-02
    z[5,1,6]  R1496     2.0884481072425842e-01
    z[5,1,6]  R1497     4.1663125157356262e-01
    z[5,1,6]  R1498     1.0709770768880844e-01
    z[5,1,6]  R1499     -2.4973434209823608e-01
    z[5,1,6]  R1500     1.0766394436359406e-01
    z[5,1,6]  R1501     -1.2142031639814377e-01
    z[5,1,6]  R1502     2.6148018240928650e-01
    z[5,1,6]  R1503     4.3953621387481689e-01
    z[5,1,6]  R1504     -7.3536694981157780e-03
    z[5,1,6]  R1505     -9.8360069096088409e-02
    z[5,1,6]  R1506     2.5545188784599304e-01
    z[5,1,6]  R1507     3.6544266343116760e-01
    z[5,1,6]  R1508     2.3569293320178986e-01
    z[5,1,6]  R1509     1.7103728652000427e-01
    z[5,1,6]  R1510     -1.4125512540340424e-01
    z[5,1,6]  R1511     -1.0065762698650360e-01
    z[5,1,6]  R1512     -1.8577769398689270e-01
    z[5,1,6]  R1513     1.7328223586082458e-01
    z[5,1,6]  R1514     -1.8665000796318054e-01
    z[5,1,6]  R1515     -1.3384471833705902e-01
    z[5,1,6]  R1516     -1.6737556457519531e-01
    z[5,1,6]  R1517     -1.9298050552606583e-02
    z[5,1,6]  R1518     -1.5526151657104492e-01
    z[5,1,6]  R1519     -7.1109756827354431e-02
    z[5,1,6]  R1520     -1.9608356058597565e-01
    z[5,1,6]  R1521     -2.3779530823230743e-01
    z[5,1,6]  R1522     -4.6682038903236389e-01
    z[5,1,6]  R1523     -3.0959886312484741e-01
    z[5,1,6]  R1524     2.9122793674468994e-01
    z[5,1,6]  R1525     1.1080313473939896e-01
    z[5,1,6]  R1526     -6.8453967571258545e-01
    z[5,1,6]  R1527     -4.1320380568504333e-01
    z[5,1,6]  R1528     4.7924613952636719e-01
    z[5,1,6]  R1529     5.4809981584548950e-01
    z[5,1,6]  R1530     -1.1365757137537003e-01
    z[5,1,6]  R1531     -1.4261193573474884e-01
    z[5,1,6]  R1532     -7.7522225677967072e-02
    z[5,1,6]  R1533     -1.8059577047824860e-01
    z[5,1,6]  R1534     -7.2199523448944092e-02
    z[5,1,6]  R1535     1.6902619600296021e-01
    z[5,1,6]  R1536     -2.3229663074016571e-01
    z[5,1,6]  R1537     -2.8217615559697151e-02
    z[5,1,6]  R1538     -2.4007629603147507e-02
    z[5,1,6]  R1539     -1.7738421261310577e-01
    z[5,1,6]  R1540     4.8832595348358154e-01
    z[5,1,6]  R1541     -2.4512539803981781e-01
    z[5,1,6]  R1542     -8.6079455912113190e-02
    z[5,1,6]  R1543     -3.3156612515449524e-01
    z[5,1,6]  R1544     2.8960786759853363e-02
    z[5,1,6]  R1545     -2.5481003522872925e-01
    z[5,1,6]  R1546     1.3467422127723694e-01
    z[5,1,6]  R1547     1.0879641771316528e-01
    z[5,1,6]  R1548     3.0809977650642395e-01
    z[5,1,6]  R1549     3.7304118275642395e-01
    z[5,1,6]  R1550     1.1342987418174744e-01
    z[5,1,6]  R1551     -1.6270875930786133e-01
    z[5,1,6]  R1552     3.9924681186676025e-02
    z[5,1,6]  R1553     -2.3157656192779541e-01
    z[5,1,6]  R1554     3.9496082812547684e-02
    z[5,1,6]  R1555     -2.0244711637496948e-01
    z[5,1,6]  R1556     -3.8225898146629333e-01
    z[5,1,6]  R1557     -2.5455081462860107e-01
    z[2,5,0]  R20       -1
    z[2,5,0]  R47       1
    z[2,5,0]  R1558     -1
    z[2,5,0]  R1559     1
    z[2,5,0]  R1572     4.8943213187158108e-04
    z[2,5,0]  R1573     -4.1603740304708481e-02
    z[2,5,0]  R1574     5.1707643270492554e-01
    z[2,5,0]  R1575     -1.4327304065227509e-01
    z[2,5,0]  R1576     2.5914323329925537e-01
    z[2,5,0]  R1577     -2.7291810512542725e-01
    z[2,5,0]  R1578     0.0910104289650917
    z[2,5,0]  R1579     -2.3256616294384003e-01
    z[2,5,0]  R1580     7.7293801307678223e-01
    z[2,5,0]  R1581     2.8755825757980347e-01
    z[2,5,0]  R1582     -2.6728084683418274e-01
    z[2,5,0]  R1583     -4.1889202594757080e-01
    z[2,5,0]  R1584     -5.4728162288665771e-01
    z[2,5,0]  R1585     -3.1786096096038818e-01
    z[2,5,0]  R1586     -2.7575197815895081e-01
    z[2,5,0]  R1587     -1.1141210794448853e-01
    z[2,5,0]  R1588     -1.1405264586210251e-01
    z[2,5,0]  R1589     6.0256361961364746e-01
    z[2,5,0]  R1590     -3.8535487651824951e-01
    z[2,5,0]  R1591     1.9974620640277863e-01
    z[2,5,0]  R1592     -4.6212542057037354e-01
    z[2,5,0]  R1593     4.2640066146850586e-01
    z[2,5,0]  R1594     -8.5050441324710846e-02
    z[2,5,0]  R1595     3.2335484027862549e-01
    z[2,5,0]  R1596     4.4760033488273621e-01
    z[2,5,0]  R1597     7.1173951029777527e-02
    z[2,5,0]  R1598     1.7132215201854706e-01
    z[2,5,0]  R1599     2.4897687137126923e-01
    z[2,5,0]  R1600     -4.1180300712585449e-01
    z[2,5,0]  R1601     -5.4998654872179031e-02
    z[2,5,0]  R1602     -8.2180071622133255e-03
    z[2,5,0]  R1603     -8.3000110462307930e-03
    z[2,5,0]  R1604     -4.5677873492240906e-01
    z[2,5,0]  R1605     -3.5773512721061707e-01
    z[2,5,0]  R1606     -1.5139569342136383e-01
    z[2,5,0]  R1607     1.9323521852493286e-01
    z[2,5,0]  R1608     2.3085275292396545e-01
    z[2,5,0]  R1609     2.4176497757434845e-01
    z[2,5,0]  R1610     -2.2811214625835419e-01
    z[2,5,0]  R1611     -4.9839547276496887e-01
    z[2,5,0]  R1612     -3.8368764519691467e-01
    z[2,5,0]  R1613     1.6560640186071396e-02
    z[2,5,0]  R1614     -0.744409441947937
    z[2,5,0]  R1615     1.3075286149978638e-01
    z[2,5,0]  R1616     4.6359366178512573e-01
    z[2,5,0]  R1617     -5.2053827047348022e-01
    z[2,5,0]  R1618     -8.0672997236251831e-01
    z[2,5,0]  R1619     8.6004018783569336e-02
    z[2,5,0]  R1620     8.1646546721458435e-02
    z[2,5,0]  R1621     -4.4128152728080750e-01
    z[2,5,0]  R1622     -7.7038669586181641e-01
    z[2,5,0]  R1623     7.9201817512512207e-02
    z[2,5,0]  R1624     -4.1911327838897705e-01
    z[2,5,0]  R1625     3.4808114171028137e-02
    z[2,5,0]  R1626     -2.0323015749454498e-01
    z[2,5,0]  R1627     1.3780252635478973e-01
    z[2,5,0]  R1628     1.7994193732738495e-01
    z[2,5,0]  R1629     6.8335193395614624e-01
    z[2,5,0]  R1630     6.8507421016693115e-01
    z[2,5,0]  R1631     6.7109113931655884e-01
    z[2,5,0]  R1632     -8.6218303442001343e-01
    z[2,5,0]  R1633     -0.7164306640625
    z[2,5,0]  R1634     5.2741557359695435e-02
    z[2,5,0]  R1635     -1.5142881870269775e-01
    z[2,5,0]  R1636     2.1789434552192688e-01
    z[2,5,0]  R1637     2.3207060992717743e-01
    z[2,5,0]  R1638     2.4701507389545441e-01
    z[2,5,0]  R1639     4.1877689957618713e-01
    z[2,5,0]  R1640     2.0265518128871918e-01
    z[2,5,0]  R1641     6.7721772193908691e-01
    z[2,5,0]  R1642     -6.6606831550598145e-01
    z[2,5,0]  R1643     2.2552803158760071e-01
    z[2,5,0]  R1644     -1.7429448664188385e-01
    z[2,5,0]  R1645     4.7464754432439804e-02
    z[2,5,0]  R1646     2.4472886323928833e-01
    z[2,5,0]  R1647     1.1265747249126434e-01
    z[2,5,0]  R1648     -4.1515317559242249e-01
    z[2,5,0]  R1649     4.6510735154151917e-01
    z[2,5,0]  R1650     4.1333022713661194e-01
    z[2,5,0]  R1651     2.1875010430812836e-01
    z[2,5,0]  R1652     -1.3997809030115604e-02
    z[2,5,0]  R1653     5.5758005380630493e-01
    z[2,5,0]  R1654     5.0523781776428223e-01
    z[2,5,0]  R1655     -5.2187938243150711e-02
    z[2,5,0]  R1656     1.2089616805315018e-01
    z[2,5,0]  R1657     -8.6801508441567421e-03
    z[2,5,0]  R1658     8.7563628330826759e-03
    z[2,5,0]  R1659     -7.5780510902404785e-02
    z[2,5,0]  R1660     -2.1654142066836357e-02
    z[2,5,0]  R1661     8.2768142223358154e-01
    z[2,5,0]  R1662     4.0742865204811096e-01
    z[2,5,0]  R1663     4.3945017457008362e-01
    z[2,5,0]  R1664     3.8547104597091675e-01
    z[2,5,0]  R1665     -5.6935763359069824e-01
    z[2,5,0]  R1666     1.4344798028469086e-01
    z[2,5,0]  R1667     -5.0438129901885986e-01
    z[2,5,0]  R1668     2.9635295271873474e-01
    z[2,5,0]  R1669     3.9452192187309265e-01
    z[2,5,0]  R1670     2.0532502233982086e-01
    z[2,5,0]  R1671     3.9675658941268921e-01
    z[2,5,0]  R1672     -9.2806547880172729e-02
    z[2,5,0]  R1673     7.5493997335433960e-01
    z[2,5,0]  R1674     3.9099308848381042e-01
    z[2,5,0]  R1675     -3.3919128775596619e-01
    z[2,5,0]  R1676     5.5431425571441650e-01
    z[2,5,0]  R1677     6.5923231840133667e-01
    z[2,5,0]  R1678     6.0001599788665771e-01
    z[2,5,0]  R1679     -5.4473632574081421e-01
    z[2,5,0]  R1680     6.8981027603149414e-01
    z[2,5,0]  R1681     7.3579502105712891e-01
    z[2,5,0]  R1682     7.4069178104400635e-01
    z[2,5,0]  R1683     7.2650265693664551e-01
    z[2,5,0]  R1684     5.7322221994400024e-01
    z[2,5,0]  R1685     6.9887030124664307e-01
    z[2,5,0]  R1686     7.1005409955978394e-01
    z[2,5,0]  R1687     -7.6446205377578735e-01
    z[2,5,0]  R1688     -8.9940339326858521e-01
    z[2,5,0]  R1689     -0.898152232170105
    z[2,5,0]  R1690     -8.1273835897445679e-01
    z[2,5,0]  R1691     -7.4537557363510132e-01
    z[2,5,1]  R21       -1
    z[2,5,1]  R48       1
    z[2,5,1]  R1560     -1
    z[2,5,1]  R1561     1
    z[2,5,1]  R1572     -1.7235042154788971e-01
    z[2,5,1]  R1573     -1.4341805875301361e-01
    z[2,5,1]  R1574     -4.5372587442398071e-01
    z[2,5,1]  R1575     -7.9453641176223755e-01
    z[2,5,1]  R1576     -7.8642803430557251e-01
    z[2,5,1]  R1577     -6.6147613525390625e-01
    z[2,5,1]  R1578     -3.4755858778953552e-01
    z[2,5,1]  R1579     -7.4693953990936279e-01
    z[2,5,1]  R1580     -4.9149137735366821e-01
    z[2,5,1]  R1581     -9.4544291496276855e-01
    z[2,5,1]  R1582     6.6605281829833984e-01
    z[2,5,1]  R1583     -1.5432612597942352e-01
    z[2,5,1]  R1584     3.9257392287254333e-01
    z[2,5,1]  R1585     0.361191064119339
    z[2,5,1]  R1586     -5.7884609699249268e-01
    z[2,5,1]  R1587     -3.0517965555191040e-01
    z[2,5,1]  R1588     7.2201509028673172e-03
    z[2,5,1]  R1589     -2.5021719932556152e-01
    z[2,5,1]  R1590     -3.3093348145484924e-01
    z[2,5,1]  R1591     -5.2963387966156006e-01
    z[2,5,1]  R1592     -4.6676069498062134e-01
    z[2,5,1]  R1593     -4.0153455734252930e-01
    z[2,5,1]  R1594     -8.6335390806198120e-01
    z[2,5,1]  R1595     -7.5709640979766846e-01
    z[2,5,1]  R1596     -0.536909818649292
    z[2,5,1]  R1597     -3.9367112517356873e-01
    z[2,5,1]  R1598     -6.8513208627700806e-01
    z[2,5,1]  R1599     -5.6272447109222412e-01
    z[2,5,1]  R1600     1.3906291127204895e-01
    z[2,5,1]  R1601     -8.3963996171951294e-01
    z[2,5,1]  R1602     -3.7191800773143768e-02
    z[2,5,1]  R1603     8.4010317921638489e-02
    z[2,5,1]  R1604     -4.7721635550260544e-02
    z[2,5,1]  R1605     -4.1309773921966553e-01
    z[2,5,1]  R1606     6.1856579780578613e-01
    z[2,5,1]  R1607     -0.745434045791626
    z[2,5,1]  R1608     -1.3233341276645660e-01
    z[2,5,1]  R1609     -7.6522946357727051e-01
    z[2,5,1]  R1610     -2.7406048774719238e-01
    z[2,5,1]  R1611     -0.157062828540802
    z[2,5,1]  R1612     4.5490020513534546e-01
    z[2,5,1]  R1613     0.120367631316185
    z[2,5,1]  R1614     -2.3461724817752838e-01
    z[2,5,1]  R1615     -5.3307074308395386e-01
    z[2,5,1]  R1616     -4.9710500240325928e-01
    z[2,5,1]  R1617     2.9275098443031311e-01
    z[2,5,1]  R1618     3.2075801491737366e-01
    z[2,5,1]  R1619     -6.2702691555023193e-01
    z[2,5,1]  R1620     -2.8525643050670624e-02
    z[2,5,1]  R1621     -3.5387694835662842e-01
    z[2,5,1]  R1622     -2.1547524631023407e-01
    z[2,5,1]  R1623     -3.0064329504966736e-01
    z[2,5,1]  R1624     -4.3781730532646179e-01
    z[2,5,1]  R1625     -4.3824225664138794e-01
    z[2,5,1]  R1626     -4.5453169941902161e-01
    z[2,5,1]  R1627     -1.2614880502223969e-01
    z[2,5,1]  R1628     9.5038950443267822e-02
    z[2,5,1]  R1629     1.1190351843833923e-01
    z[2,5,1]  R1630     -4.8688662052154541e-01
    z[2,5,1]  R1631     -4.1617318987846375e-01
    z[2,5,1]  R1632     -2.1365673840045929e-01
    z[2,5,1]  R1633     4.6142336726188660e-01
    z[2,5,1]  R1634     -3.1917089223861694e-01
    z[2,5,1]  R1635     -5.1795506477355957e-01
    z[2,5,1]  R1636     -2.7693209052085876e-01
    z[2,5,1]  R1637     -0.516141951084137
    z[2,5,1]  R1638     -8.5702389478683472e-01
    z[2,5,1]  R1639     -7.4201732873916626e-01
    z[2,5,1]  R1640     6.8862313032150269e-01
    z[2,5,1]  R1641     5.7169044017791748e-01
    z[2,5,1]  R1642     -3.4451025724411011e-01
    z[2,5,1]  R1643     -2.4015264213085175e-01
    z[2,5,1]  R1644     -0.594580352306366
    z[2,5,1]  R1645     -6.5241134166717529e-01
    z[2,5,1]  R1646     -2.0614735782146454e-01
    z[2,5,1]  R1647     -0.346598744392395
    z[2,5,1]  R1648     1.3930635154247284e-01
    z[2,5,1]  R1649     6.6393280029296875e-01
    z[2,5,1]  R1650     4.4265350699424744e-01
    z[2,5,1]  R1651     0.444812536239624
    z[2,5,1]  R1652     1.8905310332775116e-01
    z[2,5,1]  R1653     2.1017962694168091e-01
    z[2,5,1]  R1654     1.5771448612213135e-01
    z[2,5,1]  R1655     2.1219782531261444e-01
    z[2,5,1]  R1656     2.2072224318981171e-01
    z[2,5,1]  R1657     2.5600370764732361e-01
    z[2,5,1]  R1658     1.7782041430473328e-01
    z[2,5,1]  R1659     4.4399213790893555e-01
    z[2,5,1]  R1660     1.2944982945919037e-01
    z[2,5,1]  R1661     1.2567570805549622e-01
    z[2,5,1]  R1662     -6.5594899654388428e-01
    z[2,5,1]  R1663     -3.3320096135139465e-01
    z[2,5,1]  R1664     -0.617285430431366
    z[2,5,1]  R1665     2.8803017735481262e-01
    z[2,5,1]  R1666     -9.5162212848663330e-01
    z[2,5,1]  R1667     4.3394145369529724e-01
    z[2,5,1]  R1668     -5.5049043893814087e-01
    z[2,5,1]  R1669     -3.2727000117301941e-01
    z[2,5,1]  R1670     -9.1263920068740845e-01
    z[2,5,1]  R1671     -3.4390786290168762e-01
    z[2,5,1]  R1672     9.4008797407150269e-01
    z[2,5,1]  R1673     -2.5318646430969238e-01
    z[2,5,1]  R1674     5.1840496063232422e-01
    z[2,5,1]  R1675     -3.7790334224700928e-01
    z[2,5,1]  R1676     0.398128867149353
    z[2,5,1]  R1677     -2.2204957902431488e-01
    z[2,5,1]  R1678     1.0989034920930862e-01
    z[2,5,1]  R1679     -8.0375164747238159e-02
    z[2,5,1]  R1680     2.8845466673374176e-02
    z[2,5,1]  R1681     -3.4753879904747009e-01
    z[2,5,1]  R1682     -0.0806993618607521
    z[2,5,1]  R1683     -0.042476586997509
    z[2,5,1]  R1684     2.8685966134071350e-01
    z[2,5,1]  R1685     -4.3638747930526733e-01
    z[2,5,1]  R1686     1.0166170448064804e-01
    z[2,5,1]  R1687     2.1396577358245850e-01
    z[2,5,1]  R1688     -1.3196200598031282e-03
    z[2,5,1]  R1689     -0.0641687661409378
    z[2,5,1]  R1690     -2.0167045295238495e-01
    z[2,5,1]  R1691     1.0248646140098572e-02
    z[2,5,2]  R22       -1
    z[2,5,2]  R49       1
    z[2,5,2]  R1562     -1
    z[2,5,2]  R1563     1
    z[2,5,2]  R1572     -9.7293847799301147e-01
    z[2,5,2]  R1573     -0.603140115737915
    z[2,5,2]  R1574     0.538955569267273
    z[2,5,2]  R1575     3.4552767872810364e-01
    z[2,5,2]  R1576     4.6513897180557251e-01
    z[2,5,2]  R1577     3.9125081896781921e-01
    z[2,5,2]  R1578     0.631007969379425
    z[2,5,2]  R1579     4.0838566422462463e-01
    z[2,5,2]  R1580     2.9552167654037476e-01
    z[2,5,2]  R1581     -7.1046546101570129e-02
    z[2,5,2]  R1582     -2.2020098567008972e-01
    z[2,5,2]  R1583     -3.8433471322059631e-01
    z[2,5,2]  R1584     -6.2234717607498169e-01
    z[2,5,2]  R1585     -2.7834331989288330e-01
    z[2,5,2]  R1586     -3.2542139291763306e-01
    z[2,5,2]  R1587     6.6539543867111206e-01
    z[2,5,2]  R1588     7.9765558242797852e-01
    z[2,5,2]  R1589     3.8779592514038086e-01
    z[2,5,2]  R1590     5.2622526884078979e-01
    z[2,5,2]  R1591     1.4367006719112396e-01
    z[2,5,2]  R1592     -1.7414540052413940e-01
    z[2,5,2]  R1593     6.0414743423461914e-01
    z[2,5,2]  R1594     4.3512764573097229e-01
    z[2,5,2]  R1595     1.7907401919364929e-01
    z[2,5,2]  R1596     1.1400596052408218e-01
    z[2,5,2]  R1597     0.640015721321106
    z[2,5,2]  R1598     3.4429121017456055e-01
    z[2,5,2]  R1599     5.1569050550460815e-01
    z[2,5,2]  R1600     3.5431039333343506e-01
    z[2,5,2]  R1601     -1.0312790423631668e-01
    z[2,5,2]  R1602     -4.5585840940475464e-01
    z[2,5,2]  R1603     -8.5497385263442993e-01
    z[2,5,2]  R1604     -6.3647091388702393e-01
    z[2,5,2]  R1605     -4.1328567266464233e-01
    z[2,5,2]  R1606     -4.7504201531410217e-01
    z[2,5,2]  R1607     0.516404390335083
    z[2,5,2]  R1608     6.6580301523208618e-01
    z[2,5,2]  R1609     4.2725303769111633e-01
    z[2,5,2]  R1610     2.8814834356307983e-01
    z[2,5,2]  R1611     7.9223197698593140e-01
    z[2,5,2]  R1612     -5.8989274501800537e-01
    z[2,5,2]  R1613     -0.674820601940155
    z[2,5,2]  R1614     -1.7844487726688385e-01
    z[2,5,2]  R1615     4.4019383192062378e-01
    z[2,5,2]  R1616     2.5102981925010681e-01
    z[2,5,2]  R1617     -2.7532413601875305e-01
    z[2,5,2]  R1618     2.7033400535583496e-01
    z[2,5,2]  R1619     -1.5471804141998291e-01
    z[2,5,2]  R1620     8.2182055711746216e-01
    z[2,5,2]  R1621     5.1102900505065918e-01
    z[2,5,2]  R1622     -3.8311538100242615e-01
    z[2,5,2]  R1623     0.812807559967041
    z[2,5,2]  R1624     6.2336695194244385e-01
    z[2,5,2]  R1625     3.4351414442062378e-01
    z[2,5,2]  R1626     2.3672124743461609e-01
    z[2,5,2]  R1627     6.7838686704635620e-01
    z[2,5,2]  R1628     -2.6348397135734558e-01
    z[2,5,2]  R1629     -2.3500017821788788e-01
    z[2,5,2]  R1630     -4.5101469755172729e-01
    z[2,5,2]  R1631     -5.6494605541229248e-01
    z[2,5,2]  R1632     1.8569216132164001e-01
    z[2,5,2]  R1633     -1.2094815820455551e-01
    z[2,5,2]  R1634     5.0320732593536377e-01
    z[2,5,2]  R1635     8.1830513477325439e-01
    z[2,5,2]  R1636     4.7848334908485413e-01
    z[2,5,2]  R1637     5.3767633438110352e-01
    z[2,5,2]  R1638     -1.4037846028804779e-01
    z[2,5,2]  R1639     -2.8815340995788574e-01
    z[2,5,2]  R1640     -2.9185838066041470e-03
    z[2,5,2]  R1641     7.4860163033008575e-02
    z[2,5,2]  R1642     -3.8576507568359375e-01
    z[2,5,2]  R1643     6.0245078802108765e-01
    z[2,5,2]  R1644     7.6126885414123535e-01
    z[2,5,2]  R1645     1.1741225421428680e-01
    z[2,5,2]  R1646     8.1855398416519165e-01
    z[2,5,2]  R1647     -3.4392636269330978e-02
    z[2,5,2]  R1648     1.3338804244995117e-01
    z[2,5,2]  R1649     -1.5795648097991943e-01
    z[2,5,2]  R1650     -1.1510962992906570e-01
    z[2,5,2]  R1651     5.6414250284433365e-02
    z[2,5,2]  R1652     -2.8237661719322205e-01
    z[2,5,2]  R1653     -1.2899863719940186e-01
    z[2,5,2]  R1654     -5.5287480354309082e-01
    z[2,5,2]  R1655     -6.1866492033004761e-01
    z[2,5,2]  R1656     -2.5025400519371033e-01
    z[2,5,2]  R1657     5.1847383379936218e-02
    z[2,5,2]  R1658     -6.7677521705627441e-01
    z[2,5,2]  R1659     -8.1299352645874023e-01
    z[2,5,2]  R1660     -5.4551094770431519e-01
    z[2,5,2]  R1661     2.4136213958263397e-01
    z[2,5,2]  R1662     4.0681045502424240e-02
    z[2,5,2]  R1663     1.4646363258361816e-01
    z[2,5,2]  R1664     -2.1235128864645958e-02
    z[2,5,2]  R1665     2.7705490589141846e-01
    z[2,5,2]  R1666     -2.4117190390825272e-02
    z[2,5,2]  R1667     5.7482112199068069e-02
    z[2,5,2]  R1668     4.7844356298446655e-01
    z[2,5,2]  R1669     -3.3507618308067322e-01
    z[2,5,2]  R1670     0.0655309185385704
    z[2,5,2]  R1671     3.3724945783615112e-01
    z[2,5,2]  R1672     1.1411363631486893e-01
    z[2,5,2]  R1673     1.8625865876674652e-01
    z[2,5,2]  R1674     -0.144407719373703
    z[2,5,2]  R1675     -4.1109225153923035e-01
    z[2,5,2]  R1676     2.6722699403762817e-01
    z[2,5,2]  R1677     5.5550694465637207e-01
    z[2,5,2]  R1678     5.9672847390174866e-02
    z[2,5,2]  R1679     -2.2553333640098572e-01
    z[2,5,2]  R1680     6.7317962646484375e-02
    z[2,5,2]  R1681     -2.5654649734497070e-01
    z[2,5,2]  R1682     3.3794519305229187e-01
    z[2,5,2]  R1683     -2.4270488321781158e-01
    z[2,5,2]  R1684     1.8770545721054077e-01
    z[2,5,2]  R1685     1.3617783784866333e-01
    z[2,5,2]  R1686     3.6944913864135742e-01
    z[2,5,2]  R1687     -3.4059572219848633e-01
    z[2,5,2]  R1688     -1.6890175640583038e-01
    z[2,5,2]  R1689     6.1599317938089371e-02
    z[2,5,2]  R1690     1.7163710668683052e-02
    z[2,5,2]  R1691     -3.3075023442506790e-02
    z[2,5,3]  R23       -1
    z[2,5,3]  R50       1
    z[2,5,3]  R1564     -1
    z[2,5,3]  R1565     1
    z[2,5,3]  R1572     -8.8208511471748352e-02
    z[2,5,3]  R1573     -4.7521755099296570e-01
    z[2,5,3]  R1574     -3.1744179129600525e-01
    z[2,5,3]  R1575     -2.5882029533386230e-01
    z[2,5,3]  R1576     1.6882614791393280e-01
    z[2,5,3]  R1577     -1.2544415891170502e-01
    z[2,5,3]  R1578     -3.3502653241157532e-01
    z[2,5,3]  R1579     1.2970754504203796e-01
    z[2,5,3]  R1580     2.1457606554031372e-01
    z[2,5,3]  R1581     -5.3176287561655045e-02
    z[2,5,3]  R1582     -3.4870305657386780e-01
    z[2,5,3]  R1583     -3.8045141100883484e-01
    z[2,5,3]  R1584     -2.4736273288726807e-01
    z[2,5,3]  R1585     -5.5625128746032715e-01
    z[2,5,3]  R1586     -6.0599648952484131e-01
    z[2,5,3]  R1587     -6.9442704319953918e-02
    z[2,5,3]  R1588     3.6038818955421448e-01
    z[2,5,3]  R1589     0.411622554063797
    z[2,5,3]  R1590     -2.1343001723289490e-01
    z[2,5,3]  R1591     5.3617221117019653e-01
    z[2,5,3]  R1592     -1.0586037300527096e-02
    z[2,5,3]  R1593     -0.266049325466156
    z[2,5,3]  R1594     0.000654847186524421
    z[2,5,3]  R1595     1.8572027981281281e-01
    z[2,5,3]  R1596     6.1764854937791824e-02
    z[2,5,3]  R1597     -2.6875153183937073e-01
    z[2,5,3]  R1598     -3.9000564813613892e-01
    z[2,5,3]  R1599     0.418507844209671
    z[2,5,3]  R1600     -1.8928614258766174e-01
    z[2,5,3]  R1601     -1.2874467670917511e-01
    z[2,5,3]  R1602     -4.7685131430625916e-01
    z[2,5,3]  R1603     -1.7664164304733276e-01
    z[2,5,3]  R1604     -4.7321975231170654e-02
    z[2,5,3]  R1605     -1.9970078021287918e-02
    z[2,5,3]  R1606     -2.7834182977676392e-01
    z[2,5,3]  R1607     1.3912315666675568e-01
    z[2,5,3]  R1608     4.6573978662490845e-01
    z[2,5,3]  R1609     -2.5322949886322021e-01
    z[2,5,3]  R1610     -6.7431682348251343e-01
    z[2,5,3]  R1611     1.8873554468154907e-01
    z[2,5,3]  R1612     -5.1140058785676956e-02
    z[2,5,3]  R1613     -6.1911731958389282e-01
    z[2,5,3]  R1614     -1.6849631071090698e-01
    z[2,5,3]  R1615     -1.8016840517520905e-01
    z[2,5,3]  R1616     1.9928215444087982e-01
    z[2,5,3]  R1617     1.0604322701692581e-01
    z[2,5,3]  R1618     -1.2245579808950424e-01
    z[2,5,3]  R1619     -1.8359085917472839e-01
    z[2,5,3]  R1620     9.3848649412393570e-03
    z[2,5,3]  R1621     3.6554974317550659e-01
    z[2,5,3]  R1622     -1.3364183902740479e-01
    z[2,5,3]  R1623     2.7470090985298157e-01
    z[2,5,3]  R1624     2.1028025448322296e-01
    z[2,5,3]  R1625     -2.8887799382209778e-01
    z[2,5,3]  R1626     3.1354019045829773e-01
    z[2,5,3]  R1627     -3.2518345117568970e-01
    z[2,5,3]  R1628     6.3137114048004150e-01
    z[2,5,3]  R1629     6.0915040969848633e-01
    z[2,5,3]  R1630     -1.0930795967578888e-01
    z[2,5,3]  R1631     9.4762936234474182e-02
    z[2,5,3]  R1632     0.0528901144862175
    z[2,5,3]  R1633     -2.2071680426597595e-01
    z[2,5,3]  R1634     2.7505340054631233e-02
    z[2,5,3]  R1635     -5.4072678089141846e-02
    z[2,5,3]  R1636     -0.508666455745697
    z[2,5,3]  R1637     1.5174891054630280e-01
    z[2,5,3]  R1638     1.5501870773732662e-02
    z[2,5,3]  R1639     -1.4099037647247314e-01
    z[2,5,3]  R1640     5.5263692140579224e-01
    z[2,5,3]  R1641     1.0978803038597107e-01
    z[2,5,3]  R1642     -5.9805382043123245e-02
    z[2,5,3]  R1643     -3.5006541013717651e-01
    z[2,5,3]  R1644     1.3073551654815674e-01
    z[2,5,3]  R1645     -6.5448500216007233e-02
    z[2,5,3]  R1646     1.7718425393104553e-01
    z[2,5,3]  R1647     4.4877770543098450e-01
    z[2,5,3]  R1648     5.1594823598861694e-01
    z[2,5,3]  R1649     1.2030216306447983e-01
    z[2,5,3]  R1650     3.7173676490783691e-01
    z[2,5,3]  R1651     1.4595986902713776e-01
    z[2,5,3]  R1652     6.6540360450744629e-01
    z[2,5,3]  R1653     6.5713709592819214e-01
    z[2,5,3]  R1654     5.0276738405227661e-01
    z[2,5,3]  R1655     3.6557447910308838e-01
    z[2,5,3]  R1656     3.9716669917106628e-01
    z[2,5,3]  R1657     3.7337687611579895e-01
    z[2,5,3]  R1658     4.5556488633155823e-01
    z[2,5,3]  R1659     1.1686177551746368e-01
    z[2,5,3]  R1660     5.0188434123992920e-01
    z[2,5,3]  R1661     2.3232667148113251e-01
    z[2,5,3]  R1662     -5.7432240247726440e-01
    z[2,5,3]  R1663     -6.3345789909362793e-01
    z[2,5,3]  R1664     -4.6149781346321106e-01
    z[2,5,3]  R1665     -4.6182355284690857e-01
    z[2,5,3]  R1666     -1.3038317859172821e-01
    z[2,5,3]  R1667     -5.3972136974334717e-01
    z[2,5,3]  R1668     -3.8895878195762634e-01
    z[2,5,3]  R1669     -5.3050237894058228e-01
    z[2,5,3]  R1670     -2.5320374965667725e-01
    z[2,5,3]  R1671     -4.2305126786231995e-01
    z[2,5,3]  R1672     2.9098740220069885e-01
    z[2,5,3]  R1673     -2.9129517078399658e-01
    z[2,5,3]  R1674     -1.4781875908374786e-01
    z[2,5,3]  R1675     -3.1002059578895569e-01
    z[2,5,3]  R1676     -3.9259654283523560e-01
    z[2,5,3]  R1677     -1.4276312291622162e-01
    z[2,5,3]  R1678     -2.5168719887733459e-01
    z[2,5,3]  R1679     -6.5503165125846863e-02
    z[2,5,3]  R1680     -1.3038103282451630e-01
    z[2,5,3]  R1681     -0.469923198223114
    z[2,5,3]  R1682     1.0379044711589813e-01
    z[2,5,3]  R1683     -1.3402193784713745e-01
    z[2,5,3]  R1684     -2.9712323099374771e-02
    z[2,5,3]  R1685     5.9156041592359543e-02
    z[2,5,3]  R1686     1.1013500392436981e-02
    z[2,5,3]  R1687     -4.3319210410118103e-01
    z[2,5,3]  R1688     -3.8658967614173889e-01
    z[2,5,3]  R1689     -4.2065268754959106e-01
    z[2,5,3]  R1690     -4.7309896349906921e-01
    z[2,5,3]  R1691     -4.2904523015022278e-01
    z[2,5,4]  R24       -1
    z[2,5,4]  R51       1
    z[2,5,4]  R1566     -1
    z[2,5,4]  R1567     1
    z[2,5,4]  R1572     -6.8349972367286682e-02
    z[2,5,4]  R1573     6.0959316790103912e-02
    z[2,5,4]  R1574     2.9346242547035217e-01
    z[2,5,4]  R1575     8.8077321648597717e-02
    z[2,5,4]  R1576     9.8922697361558676e-04
    z[2,5,4]  R1577     -3.4094041585922241e-01
    z[2,5,4]  R1578     1.2515866756439209e-01
    z[2,5,4]  R1579     -1.7869557440280914e-01
    z[2,5,4]  R1580     1.4933820068836212e-01
    z[2,5,4]  R1581     -8.8455349206924438e-02
    z[2,5,4]  R1582     2.0481154322624207e-01
    z[2,5,4]  R1583     1.1627225577831268e-01
    z[2,5,4]  R1584     -1.8047428131103516e-01
    z[2,5,4]  R1585     4.3158102035522461e-01
    z[2,5,4]  R1586     8.9279748499393463e-02
    z[2,5,4]  R1587     4.7327745705842972e-02
    z[2,5,4]  R1588     -1.3478185236454010e-01
    z[2,5,4]  R1589     9.2412687838077545e-02
    z[2,5,4]  R1590     2.3024432361125946e-01
    z[2,5,4]  R1591     -4.7474950551986694e-01
    z[2,5,4]  R1592     3.2538694143295288e-01
    z[2,5,4]  R1593     6.5021462738513947e-02
    z[2,5,4]  R1594     -1.3610567152500153e-01
    z[2,5,4]  R1595     -4.4518828392028809e-02
    z[2,5,4]  R1596     1.2379807233810425e-01
    z[2,5,4]  R1597     4.1480544209480286e-01
    z[2,5,4]  R1598     3.1806635856628418e-01
    z[2,5,4]  R1599     -2.6723667979240417e-01
    z[2,5,4]  R1600     0.335847407579422
    z[2,5,4]  R1601     -5.1931455731391907e-02
    z[2,5,4]  R1602     5.0190949440002441e-01
    z[2,5,4]  R1603     2.3953368887305260e-02
    z[2,5,4]  R1604     -3.0785033106803894e-01
    z[2,5,4]  R1605     2.9963433742523193e-01
    z[2,5,4]  R1606     2.2519567608833313e-01
    z[2,5,4]  R1607     -4.9410410225391388e-02
    z[2,5,4]  R1608     -3.4072495996952057e-02
    z[2,5,4]  R1609     2.7562731504440308e-01
    z[2,5,4]  R1610     5.3666192293167114e-01
    z[2,5,4]  R1611     -1.4008262753486633e-01
    z[2,5,4]  R1612     5.3228306770324707e-01
    z[2,5,4]  R1613     3.5014921426773071e-01
    z[2,5,4]  R1614     -2.6225471496582031e-01
    z[2,5,4]  R1615     2.9552286863327026e-01
    z[2,5,4]  R1616     4.7938823699951172e-02
    z[2,5,4]  R1617     -1.8676073849201202e-01
    z[2,5,4]  R1618     -2.2156653925776482e-02
    z[2,5,4]  R1619     1.5780363464727998e-03
    z[2,5,4]  R1620     -3.1281030178070068e-01
    z[2,5,4]  R1621     -3.3786624670028687e-01
    z[2,5,4]  R1622     -9.9446296691894531e-02
    z[2,5,4]  R1623     -3.9691093564033508e-01
    z[2,5,4]  R1624     -2.2341039776802063e-01
    z[2,5,4]  R1625     -1.5150465071201324e-01
    z[2,5,4]  R1626     -2.4573905766010284e-01
    z[2,5,4]  R1627     -2.2003591060638428e-01
    z[2,5,4]  R1628     -4.6767142415046692e-01
    z[2,5,4]  R1629     -0.273552268743515
    z[2,5,4]  R1630     1.2600430846214294e-01
    z[2,5,4]  R1631     -1.2882158160209656e-01
    z[2,5,4]  R1632     2.3652262985706329e-01
    z[2,5,4]  R1633     3.1723294407129288e-02
    z[2,5,4]  R1634     -2.9491975903511047e-02
    z[2,5,4]  R1635     1.5443550050258636e-01
    z[2,5,4]  R1636     -4.2121908068656921e-01
    z[2,5,4]  R1637     1.8458089232444763e-01
    z[2,5,4]  R1638     1.7301696538925171e-01
    z[2,5,4]  R1639     7.5182333588600159e-02
    z[2,5,4]  R1640     -2.9577374458312988e-01
    z[2,5,4]  R1641     3.4480038285255432e-01
    z[2,5,4]  R1642     1.5085572004318237e-01
    z[2,5,4]  R1643     -1.7213378846645355e-01
    z[2,5,4]  R1644     -2.7899801731109619e-02
    z[2,5,4]  R1645     1.2818282842636108e-01
    z[2,5,4]  R1646     2.9733744263648987e-01
    z[2,5,4]  R1647     -5.7709133625030518e-01
    z[2,5,4]  R1648     -6.4456969499588013e-01
    z[2,5,4]  R1649     -4.7712764143943787e-01
    z[2,5,4]  R1650     -2.0363937318325043e-01
    z[2,5,4]  R1651     -2.2551403380930424e-03
    z[2,5,4]  R1652     -5.6736266613006592e-01
    z[2,5,4]  R1653     -4.2338716983795166e-01
    z[2,5,4]  R1654     -2.7609494328498840e-01
    z[2,5,4]  R1655     -5.4130053520202637e-01
    z[2,5,4]  R1656     -5.4473882913589478e-01
    z[2,5,4]  R1657     -7.5190836191177368e-01
    z[2,5,4]  R1658     6.0095246881246567e-02
    z[2,5,4]  R1659     1.6605155169963837e-01
    z[2,5,4]  R1660     -2.0370914041996002e-01
    z[2,5,4]  R1661     2.3565191030502319e-01
    z[2,5,4]  R1662     1.3322633504867554e-01
    z[2,5,4]  R1663     -1.5834622085094452e-02
    z[2,5,4]  R1664     0.277626633644104
    z[2,5,4]  R1665     0.466239869594574
    z[2,5,4]  R1666     2.0291706547141075e-02
    z[2,5,4]  R1667     2.7662605047225952e-01
    z[2,5,4]  R1668     7.7883275225758553e-03
    z[2,5,4]  R1669     2.1679170429706573e-01
    z[2,5,4]  R1670     -1.0537905991077423e-01
    z[2,5,4]  R1671     0.0986253172159195
    z[2,5,4]  R1672     0.00849322509020567
    z[2,5,4]  R1673     2.1699893474578857e-01
    z[2,5,4]  R1674     3.9246338605880737e-01
    z[2,5,4]  R1675     3.7728101015090942e-01
    z[2,5,4]  R1676     5.4241657257080078e-02
    z[2,5,4]  R1677     0.154581680893898
    z[2,5,4]  R1678     3.2734036445617676e-01
    z[2,5,4]  R1679     6.6526606678962708e-02
    z[2,5,4]  R1680     1.0396488755941391e-01
    z[2,5,4]  R1681     -1.1083486676216125e-01
    z[2,5,4]  R1682     2.1375261247158051e-01
    z[2,5,4]  R1683     5.8546119928359985e-01
    z[2,5,4]  R1684     3.8419520854949951e-01
    z[2,5,4]  R1685     3.7921886891126633e-02
    z[2,5,4]  R1686     2.2218170762062073e-01
    z[2,5,4]  R1687     3.6676891148090363e-02
    z[2,5,4]  R1688     -7.9336911439895630e-02
    z[2,5,4]  R1689     -6.3870586454868317e-02
    z[2,5,4]  R1690     -1.1375338584184647e-01
    z[2,5,4]  R1691     -2.6194578409194946e-01
    z[2,5,5]  R25       -1
    z[2,5,5]  R52       1
    z[2,5,5]  R1568     -1
    z[2,5,5]  R1569     1
    z[2,5,5]  R1572     -8.1709325313568115e-02
    z[2,5,5]  R1573     -5.7853251695632935e-01
    z[2,5,5]  R1574     2.4344623088836670e-02
    z[2,5,5]  R1575     -9.7902357578277588e-02
    z[2,5,5]  R1576     -1.1295893043279648e-01
    z[2,5,5]  R1577     -1.3188610784709454e-02
    z[2,5,5]  R1578     -4.7790925949811935e-02
    z[2,5,5]  R1579     -1.4583942294120789e-01
    z[2,5,5]  R1580     -0.0196728203445673
    z[2,5,5]  R1581     -8.7292753159999847e-02
    z[2,5,5]  R1582     1.9400827586650848e-01
    z[2,5,5]  R1583     1.9348324835300446e-01
    z[2,5,5]  R1584     -2.4957165122032166e-01
    z[2,5,5]  R1585     2.1434809267520905e-01
    z[2,5,5]  R1586     1.7687307298183441e-01
    z[2,5,5]  R1587     0.0924796313047409
    z[2,5,5]  R1588     2.7627438306808472e-01
    z[2,5,5]  R1589     3.8378086686134338e-01
    z[2,5,5]  R1590     5.0076556205749512e-01
    z[2,5,5]  R1591     3.6635959148406982e-01
    z[2,5,5]  R1592     -0.655155599117279
    z[2,5,5]  R1593     2.6621329784393311e-01
    z[2,5,5]  R1594     -0.0172334685921669
    z[2,5,5]  R1595     0.386877179145813
    z[2,5,5]  R1596     6.8370831012725830e-01
    z[2,5,5]  R1597     4.0803152322769165e-01
    z[2,5,5]  R1598     0.0565381720662117
    z[2,5,5]  R1599     0.100244902074337
    z[2,5,5]  R1600     -3.4102091193199158e-01
    z[2,5,5]  R1601     2.6719495654106140e-01
    z[2,5,5]  R1602     -2.7230077981948853e-01
    z[2,5,5]  R1603     6.2127064913511276e-02
    z[2,5,5]  R1604     9.1365143656730652e-02
    z[2,5,5]  R1605     -4.5349341630935669e-01
    z[2,5,5]  R1606     -2.9470628499984741e-01
    z[2,5,5]  R1607     2.8922820091247559e-01
    z[2,5,5]  R1608     5.0339066982269287e-01
    z[2,5,5]  R1609     -1.0987876914441586e-02
    z[2,5,5]  R1610     -2.1653366088867188e-01
    z[2,5,5]  R1611     -2.0477293431758881e-01
    z[2,5,5]  R1612     -5.5073618888854980e-02
    z[2,5,5]  R1613     0.151590496301651
    z[2,5,5]  R1614     4.6486937999725342e-01
    z[2,5,5]  R1615     6.2038439512252808e-01
    z[2,5,5]  R1616     6.5783679485321045e-01
    z[2,5,5]  R1617     4.6448069810867310e-01
    z[2,5,5]  R1618     -2.0570924878120422e-01
    z[2,5,5]  R1619     7.2977238893508911e-01
    z[2,5,5]  R1620     2.4681676924228668e-01
    z[2,5,5]  R1621     1.1680758744478226e-01
    z[2,5,5]  R1622     4.2079731822013855e-01
    z[2,5,5]  R1623     9.8230935633182526e-02
    z[2,5,5]  R1624     3.7939116358757019e-01
    z[2,5,5]  R1625     5.3273308277130127e-01
    z[2,5,5]  R1626     3.8930308818817139e-01
    z[2,5,5]  R1627     3.5388889908790588e-01
    z[2,5,5]  R1628     -2.1736070513725281e-01
    z[2,5,5]  R1629     1.3541743159294128e-01
    z[2,5,5]  R1630     -2.4555966258049011e-01
    z[2,5,5]  R1631     2.1628174930810928e-02
    z[2,5,5]  R1632     -0.213386669754982
    z[2,5,5]  R1633     6.2998242676258087e-02
    z[2,5,5]  R1634     4.8398381471633911e-01
    z[2,5,5]  R1635     9.2903882265090942e-02
    z[2,5,5]  R1636     4.3472254276275635e-01
    z[2,5,5]  R1637     1.5766884386539459e-01
    z[2,5,5]  R1638     -2.6922854781150818e-01
    z[2,5,5]  R1639     -2.9883456230163574e-01
    z[2,5,5]  R1640     3.1535025686025620e-02
    z[2,5,5]  R1641     -1.9695109128952026e-01
    z[2,5,5]  R1642     -2.9514765739440918e-01
    z[2,5,5]  R1643     5.9990507364273071e-01
    z[2,5,5]  R1644     -3.3689178526401520e-02
    z[2,5,5]  R1645     2.7362295985221863e-01
    z[2,5,5]  R1646     8.9038470759987831e-03
    z[2,5,5]  R1647     -0.312675416469574
    z[2,5,5]  R1648     9.4866394996643066e-02
    z[2,5,5]  R1649     -1.6696314513683319e-01
    z[2,5,5]  R1650     -4.4190770387649536e-01
    z[2,5,5]  R1651     -7.9289132356643677e-01
    z[2,5,5]  R1652     -3.4532821178436279e-01
    z[2,5,5]  R1653     -2.1436698734760284e-02
    z[2,5,5]  R1654     2.7303391695022583e-01
    z[2,5,5]  R1655     1.1729851365089417e-01
    z[2,5,5]  R1656     4.1483619809150696e-01
    z[2,5,5]  R1657     3.1923133134841919e-01
    z[2,5,5]  R1658     -1.3287958502769470e-01
    z[2,5,5]  R1659     2.7967765927314758e-01
    z[2,5,5]  R1660     2.5065195560455322e-01
    z[2,5,5]  R1661     -2.0192395150661469e-01
    z[2,5,5]  R1662     1.4752630889415741e-01
    z[2,5,5]  R1663     1.8181920051574707e-01
    z[2,5,5]  R1664     0.220264732837677
    z[2,5,5]  R1665     -3.2586917281150818e-02
    z[2,5,5]  R1666     -5.7722595520317554e-03
    z[2,5,5]  R1667     -5.5649623274803162e-02
    z[2,5,5]  R1668     3.8544493913650513e-01
    z[2,5,5]  R1669     -2.5023165345191956e-01
    z[2,5,5]  R1670     9.4785392284393311e-02
    z[2,5,5]  R1671     2.4255488812923431e-01
    z[2,5,5]  R1672     -1.9831936806440353e-02
    z[2,5,5]  R1673     4.4322180747985840e-01
    z[2,5,5]  R1674     -1.4351183176040649e-01
    z[2,5,5]  R1675     2.0533630251884460e-01
    z[2,5,5]  R1676     5.4337686300277710e-01
    z[2,5,5]  R1677     3.7895879149436951e-01
    z[2,5,5]  R1678     5.9802955389022827e-01
    z[2,5,5]  R1679     -0.599342405796051
    z[2,5,5]  R1680     4.1543442010879517e-01
    z[2,5,5]  R1681     -1.1101827770471573e-01
    z[2,5,5]  R1682     4.6737310290336609e-01
    z[2,5,5]  R1683     2.1555164456367493e-01
    z[2,5,5]  R1684     0.607568085193634
    z[2,5,5]  R1685     0.532397449016571
    z[2,5,5]  R1686     -2.6702085137367249e-01
    z[2,5,5]  R1687     2.0080116391181946e-01
    z[2,5,5]  R1688     -6.3286215066909790e-02
    z[2,5,5]  R1689     -1.5741702169179916e-02
    z[2,5,5]  R1690     -1.3458141684532166e-01
    z[2,5,5]  R1691     1.3015043735504150e-01
    z[2,5,6]  R26       -1
    z[2,5,6]  R53       1
    z[2,5,6]  R1570     -1
    z[2,5,6]  R1571     1
    z[2,5,6]  R1572     6.7505091428756714e-02
    z[2,5,6]  R1573     2.2287836670875549e-01
    z[2,5,6]  R1574     -2.2092872858047485e-01
    z[2,5,6]  R1575     -3.8008540868759155e-01
    z[2,5,6]  R1576     -2.3824036121368408e-01
    z[2,5,6]  R1577     -4.5026361942291260e-01
    z[2,5,6]  R1578     -5.8528423309326172e-01
    z[2,5,6]  R1579     -3.8883182406425476e-01
    z[2,5,6]  R1580     7.0273093879222870e-02
    z[2,5,6]  R1581     1.1326502077281475e-02
    z[2,5,6]  R1582     4.8504152894020081e-01
    z[2,5,6]  R1583     -6.7624074220657349e-01
    z[2,5,6]  R1584     -0.0548379123210907
    z[2,5,6]  R1585     -3.8653293251991272e-01
    z[2,5,6]  R1586     2.7660849690437317e-01
    z[2,5,6]  R1587     0.660368800163269
    z[2,5,6]  R1588     3.5540419816970825e-01
    z[2,5,6]  R1589     -3.1410497426986694e-01
    z[2,5,6]  R1590     -3.4020674228668213e-01
    z[2,5,6]  R1591     1.0890915989875793e-01
    z[2,5,6]  R1592     -5.5048700422048569e-02
    z[2,5,6]  R1593     3.8220253586769104e-01
    z[2,5,6]  R1594     1.9806094467639923e-01
    z[2,5,6]  R1595     -3.2253879308700562e-01
    z[2,5,6]  R1596     -1.0856601595878601e-01
    z[2,5,6]  R1597     1.3984479010105133e-01
    z[2,5,6]  R1598     3.5530152916908264e-01
    z[2,5,6]  R1599     3.1432738900184631e-01
    z[2,5,6]  R1600     -6.4855682849884033e-01
    z[2,5,6]  R1601     -4.3666839599609375e-01
    z[2,5,6]  R1602     4.8712867498397827e-01
    z[2,5,6]  R1603     4.7566527128219604e-01
    z[2,5,6]  R1604     5.2784645557403564e-01
    z[2,5,6]  R1605     4.8449450731277466e-01
    z[2,5,6]  R1606     -3.9211180806159973e-01
    z[2,5,6]  R1607     1.8672230839729309e-01
    z[2,5,6]  R1608     -0.120102658867836
    z[2,5,6]  R1609     1.8224196135997772e-01
    z[2,5,6]  R1610     -1.5171281993389130e-02
    z[2,5,6]  R1611     -4.6104211360216141e-02
    z[2,5,6]  R1612     -9.4352580606937408e-02
    z[2,5,6]  R1613     -3.1050495803356171e-02
    z[2,5,6]  R1614     -2.1376334130764008e-01
    z[2,5,6]  R1615     -1.7244471237063408e-02
    z[2,5,6]  R1616     -1.3816219754517078e-02
    z[2,5,6]  R1617     -5.5287098884582520e-01
    z[2,5,6]  R1618     -3.3973211050033569e-01
    z[2,5,6]  R1619     9.6057079732418060e-02
    z[2,5,6]  R1620     3.9783695340156555e-01
    z[2,5,6]  R1621     -0.396820992231369
    z[2,5,6]  R1622     9.2072226107120514e-02
    z[2,5,6]  R1623     6.0303029604256153e-03
    z[2,5,6]  R1624     -7.7498771250247955e-02
    z[2,5,6]  R1625     5.4637116193771362e-01
    z[2,5,6]  R1626     -6.2113553285598755e-01
    z[2,5,6]  R1627     -4.7485873103141785e-01
    z[2,5,6]  R1628     -4.7389128804206848e-01
    z[2,5,6]  R1629     -3.2400522381067276e-02
    z[2,5,6]  R1630     -4.5558240264654160e-02
    z[2,5,6]  R1631     1.7671963572502136e-01
    z[2,5,6]  R1632     -2.6876670122146606e-01
    z[2,5,6]  R1633     -4.5331677794456482e-01
    z[2,5,6]  R1634     -6.3738840818405151e-01
    z[2,5,6]  R1635     6.1344724148511887e-02
    z[2,5,6]  R1636     -1.4742341637611389e-01
    z[2,5,6]  R1637     -5.5559659004211426e-01
    z[2,5,6]  R1638     -2.8658014535903931e-01
    z[2,5,6]  R1639     -2.7599132061004639e-01
    z[2,5,6]  R1640     3.0139073729515076e-01
    z[2,5,6]  R1641     1.9801907241344452e-01
    z[2,5,6]  R1642     -4.1881343722343445e-01
    z[2,5,6]  R1643     -1.2827715277671814e-01
    z[2,5,6]  R1644     -1.3251449167728424e-01
    z[2,5,6]  R1645     -6.8024778366088867e-01
    z[2,5,6]  R1646     -3.2817268371582031e-01
    z[2,5,6]  R1647     0.483521431684494
    z[2,5,6]  R1648     3.1587496399879456e-01
    z[2,5,6]  R1649     2.1890194714069366e-01
    z[2,5,6]  R1650     4.9500128626823425e-01
    z[2,5,6]  R1651     3.1799605488777161e-01
    z[2,5,6]  R1652     -2.0312076434493065e-02
    z[2,5,6]  R1653     1.2939487397670746e-01
    z[2,5,6]  R1654     1.0314755886793137e-01
    z[2,5,6]  R1655     3.5929429531097412e-01
    z[2,5,6]  R1656     -4.9746152758598328e-01
    z[2,5,6]  R1657     3.5357251763343811e-01
    z[2,5,6]  R1658     -5.3053814172744751e-01
    z[2,5,6]  R1659     -1.2930710613727570e-01
    z[2,5,6]  R1660     -5.7356774806976318e-01
    z[2,5,6]  R1661     -3.0101948976516724e-01
    z[2,5,6]  R1662     1.8088242411613464e-01
    z[2,5,6]  R1663     4.8972561955451965e-01
    z[2,5,6]  R1664     3.6241775751113892e-01
    z[2,5,6]  R1665     -2.9049712419509888e-01
    z[2,5,6]  R1666     -2.3624455928802490e-01
    z[2,5,6]  R1667     4.2786914110183716e-01
    z[2,5,6]  R1668     2.8338947892189026e-01
    z[2,5,6]  R1669     4.8365625739097595e-01
    z[2,5,6]  R1670     0.19088114798069
    z[2,5,6]  R1671     6.0252988338470459e-01
    z[2,5,6]  R1672     -0.0972653478384018
    z[2,5,6]  R1673     5.3693417459726334e-02
    z[2,5,6]  R1674     6.0087740421295166e-01
    z[2,5,6]  R1675     -5.4085552692413330e-01
    z[2,5,6]  R1676     -1.0240268707275391e-01
    z[2,5,6]  R1677     1.4011496305465698e-01
    z[2,5,6]  R1678     3.1017169356346130e-01
    z[2,5,6]  R1679     5.2726560831069946e-01
    z[2,5,6]  R1680     5.6427329778671265e-01
    z[2,5,6]  R1681     -1.6300034523010254e-01
    z[2,5,6]  R1682     -2.3612719774246216e-01
    z[2,5,6]  R1683     6.5532989799976349e-02
    z[2,5,6]  R1684     -1.9043833017349243e-01
    z[2,5,6]  R1685     -1.1923649907112122e-01
    z[2,5,6]  R1686     4.7771230340003967e-01
    z[2,5,6]  R1687     1.5649099647998810e-01
    z[2,5,6]  R1688     5.2848167717456818e-02
    z[2,5,6]  R1689     -6.4299695193767548e-02
    z[2,5,6]  R1690     2.0884481072425842e-01
    z[2,5,6]  R1691     4.1663125157356262e-01
    z[5,2,0]  R20       1
    z[5,2,0]  R47       -1
    z[5,2,0]  R1692     -1
    z[5,2,0]  R1693     1
    z[5,2,0]  R1706     -1.3997809030115604e-02
    z[5,2,0]  R1707     5.5758005380630493e-01
    z[5,2,0]  R1708     5.0523781776428223e-01
    z[5,2,0]  R1709     -5.2187938243150711e-02
    z[5,2,0]  R1710     1.2089616805315018e-01
    z[5,2,0]  R1711     -8.6801508441567421e-03
    z[5,2,0]  R1712     8.7563628330826759e-03
    z[5,2,0]  R1713     -7.5780510902404785e-02
    z[5,2,0]  R1714     -2.1654142066836357e-02
    z[5,2,0]  R1715     8.2768142223358154e-01
    z[5,2,0]  R1716     4.0742865204811096e-01
    z[5,2,0]  R1717     4.3945017457008362e-01
    z[5,2,0]  R1718     3.8547104597091675e-01
    z[5,2,0]  R1719     -5.6935763359069824e-01
    z[5,2,0]  R1720     1.4344798028469086e-01
    z[5,2,0]  R1721     -5.0438129901885986e-01
    z[5,2,0]  R1722     2.9635295271873474e-01
    z[5,2,0]  R1723     3.9452192187309265e-01
    z[5,2,0]  R1724     2.0532502233982086e-01
    z[5,2,0]  R1725     3.9675658941268921e-01
    z[5,2,0]  R1726     -9.2806547880172729e-02
    z[5,2,0]  R1727     7.5493997335433960e-01
    z[5,2,0]  R1728     3.9099308848381042e-01
    z[5,2,0]  R1729     -3.3919128775596619e-01
    z[5,2,0]  R1730     5.5431425571441650e-01
    z[5,2,0]  R1731     6.5923231840133667e-01
    z[5,2,0]  R1732     6.0001599788665771e-01
    z[5,2,0]  R1733     -5.4473632574081421e-01
    z[5,2,0]  R1734     6.8981027603149414e-01
    z[5,2,0]  R1735     7.3579502105712891e-01
    z[5,2,0]  R1736     7.4069178104400635e-01
    z[5,2,0]  R1737     7.2650265693664551e-01
    z[5,2,0]  R1738     5.7322221994400024e-01
    z[5,2,0]  R1739     6.9887030124664307e-01
    z[5,2,0]  R1740     7.1005409955978394e-01
    z[5,2,0]  R1741     -7.6446205377578735e-01
    z[5,2,0]  R1742     -8.9940339326858521e-01
    z[5,2,0]  R1743     -0.898152232170105
    z[5,2,0]  R1744     -8.1273835897445679e-01
    z[5,2,0]  R1745     -7.4537557363510132e-01
    z[5,2,0]  R1746     4.8943213187158108e-04
    z[5,2,0]  R1747     -4.1603740304708481e-02
    z[5,2,0]  R1748     5.1707643270492554e-01
    z[5,2,0]  R1749     -1.4327304065227509e-01
    z[5,2,0]  R1750     2.5914323329925537e-01
    z[5,2,0]  R1751     -2.7291810512542725e-01
    z[5,2,0]  R1752     0.0910104289650917
    z[5,2,0]  R1753     -2.3256616294384003e-01
    z[5,2,0]  R1754     7.7293801307678223e-01
    z[5,2,0]  R1755     2.8755825757980347e-01
    z[5,2,0]  R1756     -2.6728084683418274e-01
    z[5,2,0]  R1757     -4.1889202594757080e-01
    z[5,2,0]  R1758     -5.4728162288665771e-01
    z[5,2,0]  R1759     -3.1786096096038818e-01
    z[5,2,0]  R1760     -2.7575197815895081e-01
    z[5,2,0]  R1761     -1.1141210794448853e-01
    z[5,2,0]  R1762     -1.1405264586210251e-01
    z[5,2,0]  R1763     6.0256361961364746e-01
    z[5,2,0]  R1764     -3.8535487651824951e-01
    z[5,2,0]  R1765     1.9974620640277863e-01
    z[5,2,0]  R1766     -4.6212542057037354e-01
    z[5,2,0]  R1767     4.2640066146850586e-01
    z[5,2,0]  R1768     -8.5050441324710846e-02
    z[5,2,0]  R1769     3.2335484027862549e-01
    z[5,2,0]  R1770     4.4760033488273621e-01
    z[5,2,0]  R1771     7.1173951029777527e-02
    z[5,2,0]  R1772     1.7132215201854706e-01
    z[5,2,0]  R1773     2.4897687137126923e-01
    z[5,2,0]  R1774     -4.1180300712585449e-01
    z[5,2,0]  R1775     -5.4998654872179031e-02
    z[5,2,0]  R1776     -8.2180071622133255e-03
    z[5,2,0]  R1777     -8.3000110462307930e-03
    z[5,2,0]  R1778     -4.5677873492240906e-01
    z[5,2,0]  R1779     -3.5773512721061707e-01
    z[5,2,0]  R1780     -1.5139569342136383e-01
    z[5,2,0]  R1781     1.9323521852493286e-01
    z[5,2,0]  R1782     2.3085275292396545e-01
    z[5,2,0]  R1783     2.4176497757434845e-01
    z[5,2,0]  R1784     -2.2811214625835419e-01
    z[5,2,0]  R1785     -4.9839547276496887e-01
    z[5,2,0]  R1786     -3.8368764519691467e-01
    z[5,2,0]  R1787     1.6560640186071396e-02
    z[5,2,0]  R1788     -0.744409441947937
    z[5,2,0]  R1789     1.3075286149978638e-01
    z[5,2,0]  R1790     4.6359366178512573e-01
    z[5,2,0]  R1791     -5.2053827047348022e-01
    z[5,2,0]  R1792     -8.0672997236251831e-01
    z[5,2,0]  R1793     8.6004018783569336e-02
    z[5,2,0]  R1794     8.1646546721458435e-02
    z[5,2,0]  R1795     -4.4128152728080750e-01
    z[5,2,0]  R1796     -7.7038669586181641e-01
    z[5,2,0]  R1797     7.9201817512512207e-02
    z[5,2,0]  R1798     -4.1911327838897705e-01
    z[5,2,0]  R1799     3.4808114171028137e-02
    z[5,2,0]  R1800     -2.0323015749454498e-01
    z[5,2,0]  R1801     1.3780252635478973e-01
    z[5,2,0]  R1802     1.7994193732738495e-01
    z[5,2,0]  R1803     6.8335193395614624e-01
    z[5,2,0]  R1804     6.8507421016693115e-01
    z[5,2,0]  R1805     6.7109113931655884e-01
    z[5,2,0]  R1806     -8.6218303442001343e-01
    z[5,2,0]  R1807     -0.7164306640625
    z[5,2,0]  R1808     5.2741557359695435e-02
    z[5,2,0]  R1809     -1.5142881870269775e-01
    z[5,2,0]  R1810     2.1789434552192688e-01
    z[5,2,0]  R1811     2.3207060992717743e-01
    z[5,2,0]  R1812     2.4701507389545441e-01
    z[5,2,0]  R1813     4.1877689957618713e-01
    z[5,2,0]  R1814     2.0265518128871918e-01
    z[5,2,0]  R1815     6.7721772193908691e-01
    z[5,2,0]  R1816     -6.6606831550598145e-01
    z[5,2,0]  R1817     2.2552803158760071e-01
    z[5,2,0]  R1818     -1.7429448664188385e-01
    z[5,2,0]  R1819     4.7464754432439804e-02
    z[5,2,0]  R1820     2.4472886323928833e-01
    z[5,2,0]  R1821     1.1265747249126434e-01
    z[5,2,0]  R1822     -4.1515317559242249e-01
    z[5,2,0]  R1823     4.6510735154151917e-01
    z[5,2,0]  R1824     4.1333022713661194e-01
    z[5,2,0]  R1825     2.1875010430812836e-01
    z[5,2,1]  R21       1
    z[5,2,1]  R48       -1
    z[5,2,1]  R1694     -1
    z[5,2,1]  R1695     1
    z[5,2,1]  R1706     1.8905310332775116e-01
    z[5,2,1]  R1707     2.1017962694168091e-01
    z[5,2,1]  R1708     1.5771448612213135e-01
    z[5,2,1]  R1709     2.1219782531261444e-01
    z[5,2,1]  R1710     2.2072224318981171e-01
    z[5,2,1]  R1711     2.5600370764732361e-01
    z[5,2,1]  R1712     1.7782041430473328e-01
    z[5,2,1]  R1713     4.4399213790893555e-01
    z[5,2,1]  R1714     1.2944982945919037e-01
    z[5,2,1]  R1715     1.2567570805549622e-01
    z[5,2,1]  R1716     -6.5594899654388428e-01
    z[5,2,1]  R1717     -3.3320096135139465e-01
    z[5,2,1]  R1718     -0.617285430431366
    z[5,2,1]  R1719     2.8803017735481262e-01
    z[5,2,1]  R1720     -9.5162212848663330e-01
    z[5,2,1]  R1721     4.3394145369529724e-01
    z[5,2,1]  R1722     -5.5049043893814087e-01
    z[5,2,1]  R1723     -3.2727000117301941e-01
    z[5,2,1]  R1724     -9.1263920068740845e-01
    z[5,2,1]  R1725     -3.4390786290168762e-01
    z[5,2,1]  R1726     9.4008797407150269e-01
    z[5,2,1]  R1727     -2.5318646430969238e-01
    z[5,2,1]  R1728     5.1840496063232422e-01
    z[5,2,1]  R1729     -3.7790334224700928e-01
    z[5,2,1]  R1730     0.398128867149353
    z[5,2,1]  R1731     -2.2204957902431488e-01
    z[5,2,1]  R1732     1.0989034920930862e-01
    z[5,2,1]  R1733     -8.0375164747238159e-02
    z[5,2,1]  R1734     2.8845466673374176e-02
    z[5,2,1]  R1735     -3.4753879904747009e-01
    z[5,2,1]  R1736     -0.0806993618607521
    z[5,2,1]  R1737     -0.042476586997509
    z[5,2,1]  R1738     2.8685966134071350e-01
    z[5,2,1]  R1739     -4.3638747930526733e-01
    z[5,2,1]  R1740     1.0166170448064804e-01
    z[5,2,1]  R1741     2.1396577358245850e-01
    z[5,2,1]  R1742     -1.3196200598031282e-03
    z[5,2,1]  R1743     -0.0641687661409378
    z[5,2,1]  R1744     -2.0167045295238495e-01
    z[5,2,1]  R1745     1.0248646140098572e-02
    z[5,2,1]  R1746     -1.7235042154788971e-01
    z[5,2,1]  R1747     -1.4341805875301361e-01
    z[5,2,1]  R1748     -4.5372587442398071e-01
    z[5,2,1]  R1749     -7.9453641176223755e-01
    z[5,2,1]  R1750     -7.8642803430557251e-01
    z[5,2,1]  R1751     -6.6147613525390625e-01
    z[5,2,1]  R1752     -3.4755858778953552e-01
    z[5,2,1]  R1753     -7.4693953990936279e-01
    z[5,2,1]  R1754     -4.9149137735366821e-01
    z[5,2,1]  R1755     -9.4544291496276855e-01
    z[5,2,1]  R1756     6.6605281829833984e-01
    z[5,2,1]  R1757     -1.5432612597942352e-01
    z[5,2,1]  R1758     3.9257392287254333e-01
    z[5,2,1]  R1759     0.361191064119339
    z[5,2,1]  R1760     -5.7884609699249268e-01
    z[5,2,1]  R1761     -3.0517965555191040e-01
    z[5,2,1]  R1762     7.2201509028673172e-03
    z[5,2,1]  R1763     -2.5021719932556152e-01
    z[5,2,1]  R1764     -3.3093348145484924e-01
    z[5,2,1]  R1765     -5.2963387966156006e-01
    z[5,2,1]  R1766     -4.6676069498062134e-01
    z[5,2,1]  R1767     -4.0153455734252930e-01
    z[5,2,1]  R1768     -8.6335390806198120e-01
    z[5,2,1]  R1769     -7.5709640979766846e-01
    z[5,2,1]  R1770     -0.536909818649292
    z[5,2,1]  R1771     -3.9367112517356873e-01
    z[5,2,1]  R1772     -6.8513208627700806e-01
    z[5,2,1]  R1773     -5.6272447109222412e-01
    z[5,2,1]  R1774     1.3906291127204895e-01
    z[5,2,1]  R1775     -8.3963996171951294e-01
    z[5,2,1]  R1776     -3.7191800773143768e-02
    z[5,2,1]  R1777     8.4010317921638489e-02
    z[5,2,1]  R1778     -4.7721635550260544e-02
    z[5,2,1]  R1779     -4.1309773921966553e-01
    z[5,2,1]  R1780     6.1856579780578613e-01
    z[5,2,1]  R1781     -0.745434045791626
    z[5,2,1]  R1782     -1.3233341276645660e-01
    z[5,2,1]  R1783     -7.6522946357727051e-01
    z[5,2,1]  R1784     -2.7406048774719238e-01
    z[5,2,1]  R1785     -0.157062828540802
    z[5,2,1]  R1786     4.5490020513534546e-01
    z[5,2,1]  R1787     0.120367631316185
    z[5,2,1]  R1788     -2.3461724817752838e-01
    z[5,2,1]  R1789     -5.3307074308395386e-01
    z[5,2,1]  R1790     -4.9710500240325928e-01
    z[5,2,1]  R1791     2.9275098443031311e-01
    z[5,2,1]  R1792     3.2075801491737366e-01
    z[5,2,1]  R1793     -6.2702691555023193e-01
    z[5,2,1]  R1794     -2.8525643050670624e-02
    z[5,2,1]  R1795     -3.5387694835662842e-01
    z[5,2,1]  R1796     -2.1547524631023407e-01
    z[5,2,1]  R1797     -3.0064329504966736e-01
    z[5,2,1]  R1798     -4.3781730532646179e-01
    z[5,2,1]  R1799     -4.3824225664138794e-01
    z[5,2,1]  R1800     -4.5453169941902161e-01
    z[5,2,1]  R1801     -1.2614880502223969e-01
    z[5,2,1]  R1802     9.5038950443267822e-02
    z[5,2,1]  R1803     1.1190351843833923e-01
    z[5,2,1]  R1804     -4.8688662052154541e-01
    z[5,2,1]  R1805     -4.1617318987846375e-01
    z[5,2,1]  R1806     -2.1365673840045929e-01
    z[5,2,1]  R1807     4.6142336726188660e-01
    z[5,2,1]  R1808     -3.1917089223861694e-01
    z[5,2,1]  R1809     -5.1795506477355957e-01
    z[5,2,1]  R1810     -2.7693209052085876e-01
    z[5,2,1]  R1811     -0.516141951084137
    z[5,2,1]  R1812     -8.5702389478683472e-01
    z[5,2,1]  R1813     -7.4201732873916626e-01
    z[5,2,1]  R1814     6.8862313032150269e-01
    z[5,2,1]  R1815     5.7169044017791748e-01
    z[5,2,1]  R1816     -3.4451025724411011e-01
    z[5,2,1]  R1817     -2.4015264213085175e-01
    z[5,2,1]  R1818     -0.594580352306366
    z[5,2,1]  R1819     -6.5241134166717529e-01
    z[5,2,1]  R1820     -2.0614735782146454e-01
    z[5,2,1]  R1821     -0.346598744392395
    z[5,2,1]  R1822     1.3930635154247284e-01
    z[5,2,1]  R1823     6.6393280029296875e-01
    z[5,2,1]  R1824     4.4265350699424744e-01
    z[5,2,1]  R1825     0.444812536239624
    z[5,2,2]  R22       1
    z[5,2,2]  R49       -1
    z[5,2,2]  R1696     -1
    z[5,2,2]  R1697     1
    z[5,2,2]  R1706     -2.8237661719322205e-01
    z[5,2,2]  R1707     -1.2899863719940186e-01
    z[5,2,2]  R1708     -5.5287480354309082e-01
    z[5,2,2]  R1709     -6.1866492033004761e-01
    z[5,2,2]  R1710     -2.5025400519371033e-01
    z[5,2,2]  R1711     5.1847383379936218e-02
    z[5,2,2]  R1712     -6.7677521705627441e-01
    z[5,2,2]  R1713     -8.1299352645874023e-01
    z[5,2,2]  R1714     -5.4551094770431519e-01
    z[5,2,2]  R1715     2.4136213958263397e-01
    z[5,2,2]  R1716     4.0681045502424240e-02
    z[5,2,2]  R1717     1.4646363258361816e-01
    z[5,2,2]  R1718     -2.1235128864645958e-02
    z[5,2,2]  R1719     2.7705490589141846e-01
    z[5,2,2]  R1720     -2.4117190390825272e-02
    z[5,2,2]  R1721     5.7482112199068069e-02
    z[5,2,2]  R1722     4.7844356298446655e-01
    z[5,2,2]  R1723     -3.3507618308067322e-01
    z[5,2,2]  R1724     0.0655309185385704
    z[5,2,2]  R1725     3.3724945783615112e-01
    z[5,2,2]  R1726     1.1411363631486893e-01
    z[5,2,2]  R1727     1.8625865876674652e-01
    z[5,2,2]  R1728     -0.144407719373703
    z[5,2,2]  R1729     -4.1109225153923035e-01
    z[5,2,2]  R1730     2.6722699403762817e-01
    z[5,2,2]  R1731     5.5550694465637207e-01
    z[5,2,2]  R1732     5.9672847390174866e-02
    z[5,2,2]  R1733     -2.2553333640098572e-01
    z[5,2,2]  R1734     6.7317962646484375e-02
    z[5,2,2]  R1735     -2.5654649734497070e-01
    z[5,2,2]  R1736     3.3794519305229187e-01
    z[5,2,2]  R1737     -2.4270488321781158e-01
    z[5,2,2]  R1738     1.8770545721054077e-01
    z[5,2,2]  R1739     1.3617783784866333e-01
    z[5,2,2]  R1740     3.6944913864135742e-01
    z[5,2,2]  R1741     -3.4059572219848633e-01
    z[5,2,2]  R1742     -1.6890175640583038e-01
    z[5,2,2]  R1743     6.1599317938089371e-02
    z[5,2,2]  R1744     1.7163710668683052e-02
    z[5,2,2]  R1745     -3.3075023442506790e-02
    z[5,2,2]  R1746     -9.7293847799301147e-01
    z[5,2,2]  R1747     -0.603140115737915
    z[5,2,2]  R1748     0.538955569267273
    z[5,2,2]  R1749     3.4552767872810364e-01
    z[5,2,2]  R1750     4.6513897180557251e-01
    z[5,2,2]  R1751     3.9125081896781921e-01
    z[5,2,2]  R1752     0.631007969379425
    z[5,2,2]  R1753     4.0838566422462463e-01
    z[5,2,2]  R1754     2.9552167654037476e-01
    z[5,2,2]  R1755     -7.1046546101570129e-02
    z[5,2,2]  R1756     -2.2020098567008972e-01
    z[5,2,2]  R1757     -3.8433471322059631e-01
    z[5,2,2]  R1758     -6.2234717607498169e-01
    z[5,2,2]  R1759     -2.7834331989288330e-01
    z[5,2,2]  R1760     -3.2542139291763306e-01
    z[5,2,2]  R1761     6.6539543867111206e-01
    z[5,2,2]  R1762     7.9765558242797852e-01
    z[5,2,2]  R1763     3.8779592514038086e-01
    z[5,2,2]  R1764     5.2622526884078979e-01
    z[5,2,2]  R1765     1.4367006719112396e-01
    z[5,2,2]  R1766     -1.7414540052413940e-01
    z[5,2,2]  R1767     6.0414743423461914e-01
    z[5,2,2]  R1768     4.3512764573097229e-01
    z[5,2,2]  R1769     1.7907401919364929e-01
    z[5,2,2]  R1770     1.1400596052408218e-01
    z[5,2,2]  R1771     0.640015721321106
    z[5,2,2]  R1772     3.4429121017456055e-01
    z[5,2,2]  R1773     5.1569050550460815e-01
    z[5,2,2]  R1774     3.5431039333343506e-01
    z[5,2,2]  R1775     -1.0312790423631668e-01
    z[5,2,2]  R1776     -4.5585840940475464e-01
    z[5,2,2]  R1777     -8.5497385263442993e-01
    z[5,2,2]  R1778     -6.3647091388702393e-01
    z[5,2,2]  R1779     -4.1328567266464233e-01
    z[5,2,2]  R1780     -4.7504201531410217e-01
    z[5,2,2]  R1781     0.516404390335083
    z[5,2,2]  R1782     6.6580301523208618e-01
    z[5,2,2]  R1783     4.2725303769111633e-01
    z[5,2,2]  R1784     2.8814834356307983e-01
    z[5,2,2]  R1785     7.9223197698593140e-01
    z[5,2,2]  R1786     -5.8989274501800537e-01
    z[5,2,2]  R1787     -0.674820601940155
    z[5,2,2]  R1788     -1.7844487726688385e-01
    z[5,2,2]  R1789     4.4019383192062378e-01
    z[5,2,2]  R1790     2.5102981925010681e-01
    z[5,2,2]  R1791     -2.7532413601875305e-01
    z[5,2,2]  R1792     2.7033400535583496e-01
    z[5,2,2]  R1793     -1.5471804141998291e-01
    z[5,2,2]  R1794     8.2182055711746216e-01
    z[5,2,2]  R1795     5.1102900505065918e-01
    z[5,2,2]  R1796     -3.8311538100242615e-01
    z[5,2,2]  R1797     0.812807559967041
    z[5,2,2]  R1798     6.2336695194244385e-01
    z[5,2,2]  R1799     3.4351414442062378e-01
    z[5,2,2]  R1800     2.3672124743461609e-01
    z[5,2,2]  R1801     6.7838686704635620e-01
    z[5,2,2]  R1802     -2.6348397135734558e-01
    z[5,2,2]  R1803     -2.3500017821788788e-01
    z[5,2,2]  R1804     -4.5101469755172729e-01
    z[5,2,2]  R1805     -5.6494605541229248e-01
    z[5,2,2]  R1806     1.8569216132164001e-01
    z[5,2,2]  R1807     -1.2094815820455551e-01
    z[5,2,2]  R1808     5.0320732593536377e-01
    z[5,2,2]  R1809     8.1830513477325439e-01
    z[5,2,2]  R1810     4.7848334908485413e-01
    z[5,2,2]  R1811     5.3767633438110352e-01
    z[5,2,2]  R1812     -1.4037846028804779e-01
    z[5,2,2]  R1813     -2.8815340995788574e-01
    z[5,2,2]  R1814     -2.9185838066041470e-03
    z[5,2,2]  R1815     7.4860163033008575e-02
    z[5,2,2]  R1816     -3.8576507568359375e-01
    z[5,2,2]  R1817     6.0245078802108765e-01
    z[5,2,2]  R1818     7.6126885414123535e-01
    z[5,2,2]  R1819     1.1741225421428680e-01
    z[5,2,2]  R1820     8.1855398416519165e-01
    z[5,2,2]  R1821     -3.4392636269330978e-02
    z[5,2,2]  R1822     1.3338804244995117e-01
    z[5,2,2]  R1823     -1.5795648097991943e-01
    z[5,2,2]  R1824     -1.1510962992906570e-01
    z[5,2,2]  R1825     5.6414250284433365e-02
    z[5,2,3]  R23       1
    z[5,2,3]  R50       -1
    z[5,2,3]  R1698     -1
    z[5,2,3]  R1699     1
    z[5,2,3]  R1706     6.6540360450744629e-01
    z[5,2,3]  R1707     6.5713709592819214e-01
    z[5,2,3]  R1708     5.0276738405227661e-01
    z[5,2,3]  R1709     3.6557447910308838e-01
    z[5,2,3]  R1710     3.9716669917106628e-01
    z[5,2,3]  R1711     3.7337687611579895e-01
    z[5,2,3]  R1712     4.5556488633155823e-01
    z[5,2,3]  R1713     1.1686177551746368e-01
    z[5,2,3]  R1714     5.0188434123992920e-01
    z[5,2,3]  R1715     2.3232667148113251e-01
    z[5,2,3]  R1716     -5.7432240247726440e-01
    z[5,2,3]  R1717     -6.3345789909362793e-01
    z[5,2,3]  R1718     -4.6149781346321106e-01
    z[5,2,3]  R1719     -4.6182355284690857e-01
    z[5,2,3]  R1720     -1.3038317859172821e-01
    z[5,2,3]  R1721     -5.3972136974334717e-01
    z[5,2,3]  R1722     -3.8895878195762634e-01
    z[5,2,3]  R1723     -5.3050237894058228e-01
    z[5,2,3]  R1724     -2.5320374965667725e-01
    z[5,2,3]  R1725     -4.2305126786231995e-01
    z[5,2,3]  R1726     2.9098740220069885e-01
    z[5,2,3]  R1727     -2.9129517078399658e-01
    z[5,2,3]  R1728     -1.4781875908374786e-01
    z[5,2,3]  R1729     -3.1002059578895569e-01
    z[5,2,3]  R1730     -3.9259654283523560e-01
    z[5,2,3]  R1731     -1.4276312291622162e-01
    z[5,2,3]  R1732     -2.5168719887733459e-01
    z[5,2,3]  R1733     -6.5503165125846863e-02
    z[5,2,3]  R1734     -1.3038103282451630e-01
    z[5,2,3]  R1735     -0.469923198223114
    z[5,2,3]  R1736     1.0379044711589813e-01
    z[5,2,3]  R1737     -1.3402193784713745e-01
    z[5,2,3]  R1738     -2.9712323099374771e-02
    z[5,2,3]  R1739     5.9156041592359543e-02
    z[5,2,3]  R1740     1.1013500392436981e-02
    z[5,2,3]  R1741     -4.3319210410118103e-01
    z[5,2,3]  R1742     -3.8658967614173889e-01
    z[5,2,3]  R1743     -4.2065268754959106e-01
    z[5,2,3]  R1744     -4.7309896349906921e-01
    z[5,2,3]  R1745     -4.2904523015022278e-01
    z[5,2,3]  R1746     -8.8208511471748352e-02
    z[5,2,3]  R1747     -4.7521755099296570e-01
    z[5,2,3]  R1748     -3.1744179129600525e-01
    z[5,2,3]  R1749     -2.5882029533386230e-01
    z[5,2,3]  R1750     1.6882614791393280e-01
    z[5,2,3]  R1751     -1.2544415891170502e-01
    z[5,2,3]  R1752     -3.3502653241157532e-01
    z[5,2,3]  R1753     1.2970754504203796e-01
    z[5,2,3]  R1754     2.1457606554031372e-01
    z[5,2,3]  R1755     -5.3176287561655045e-02
    z[5,2,3]  R1756     -3.4870305657386780e-01
    z[5,2,3]  R1757     -3.8045141100883484e-01
    z[5,2,3]  R1758     -2.4736273288726807e-01
    z[5,2,3]  R1759     -5.5625128746032715e-01
    z[5,2,3]  R1760     -6.0599648952484131e-01
    z[5,2,3]  R1761     -6.9442704319953918e-02
    z[5,2,3]  R1762     3.6038818955421448e-01
    z[5,2,3]  R1763     0.411622554063797
    z[5,2,3]  R1764     -2.1343001723289490e-01
    z[5,2,3]  R1765     5.3617221117019653e-01
    z[5,2,3]  R1766     -1.0586037300527096e-02
    z[5,2,3]  R1767     -0.266049325466156
    z[5,2,3]  R1768     0.000654847186524421
    z[5,2,3]  R1769     1.8572027981281281e-01
    z[5,2,3]  R1770     6.1764854937791824e-02
    z[5,2,3]  R1771     -2.6875153183937073e-01
    z[5,2,3]  R1772     -3.9000564813613892e-01
    z[5,2,3]  R1773     0.418507844209671
    z[5,2,3]  R1774     -1.8928614258766174e-01
    z[5,2,3]  R1775     -1.2874467670917511e-01
    z[5,2,3]  R1776     -4.7685131430625916e-01
    z[5,2,3]  R1777     -1.7664164304733276e-01
    z[5,2,3]  R1778     -4.7321975231170654e-02
    z[5,2,3]  R1779     -1.9970078021287918e-02
    z[5,2,3]  R1780     -2.7834182977676392e-01
    z[5,2,3]  R1781     1.3912315666675568e-01
    z[5,2,3]  R1782     4.6573978662490845e-01
    z[5,2,3]  R1783     -2.5322949886322021e-01
    z[5,2,3]  R1784     -6.7431682348251343e-01
    z[5,2,3]  R1785     1.8873554468154907e-01
    z[5,2,3]  R1786     -5.1140058785676956e-02
    z[5,2,3]  R1787     -6.1911731958389282e-01
    z[5,2,3]  R1788     -1.6849631071090698e-01
    z[5,2,3]  R1789     -1.8016840517520905e-01
    z[5,2,3]  R1790     1.9928215444087982e-01
    z[5,2,3]  R1791     1.0604322701692581e-01
    z[5,2,3]  R1792     -1.2245579808950424e-01
    z[5,2,3]  R1793     -1.8359085917472839e-01
    z[5,2,3]  R1794     9.3848649412393570e-03
    z[5,2,3]  R1795     3.6554974317550659e-01
    z[5,2,3]  R1796     -1.3364183902740479e-01
    z[5,2,3]  R1797     2.7470090985298157e-01
    z[5,2,3]  R1798     2.1028025448322296e-01
    z[5,2,3]  R1799     -2.8887799382209778e-01
    z[5,2,3]  R1800     3.1354019045829773e-01
    z[5,2,3]  R1801     -3.2518345117568970e-01
    z[5,2,3]  R1802     6.3137114048004150e-01
    z[5,2,3]  R1803     6.0915040969848633e-01
    z[5,2,3]  R1804     -1.0930795967578888e-01
    z[5,2,3]  R1805     9.4762936234474182e-02
    z[5,2,3]  R1806     0.0528901144862175
    z[5,2,3]  R1807     -2.2071680426597595e-01
    z[5,2,3]  R1808     2.7505340054631233e-02
    z[5,2,3]  R1809     -5.4072678089141846e-02
    z[5,2,3]  R1810     -0.508666455745697
    z[5,2,3]  R1811     1.5174891054630280e-01
    z[5,2,3]  R1812     1.5501870773732662e-02
    z[5,2,3]  R1813     -1.4099037647247314e-01
    z[5,2,3]  R1814     5.5263692140579224e-01
    z[5,2,3]  R1815     1.0978803038597107e-01
    z[5,2,3]  R1816     -5.9805382043123245e-02
    z[5,2,3]  R1817     -3.5006541013717651e-01
    z[5,2,3]  R1818     1.3073551654815674e-01
    z[5,2,3]  R1819     -6.5448500216007233e-02
    z[5,2,3]  R1820     1.7718425393104553e-01
    z[5,2,3]  R1821     4.4877770543098450e-01
    z[5,2,3]  R1822     5.1594823598861694e-01
    z[5,2,3]  R1823     1.2030216306447983e-01
    z[5,2,3]  R1824     3.7173676490783691e-01
    z[5,2,3]  R1825     1.4595986902713776e-01
    z[5,2,4]  R24       1
    z[5,2,4]  R51       -1
    z[5,2,4]  R1700     -1
    z[5,2,4]  R1701     1
    z[5,2,4]  R1706     -5.6736266613006592e-01
    z[5,2,4]  R1707     -4.2338716983795166e-01
    z[5,2,4]  R1708     -2.7609494328498840e-01
    z[5,2,4]  R1709     -5.4130053520202637e-01
    z[5,2,4]  R1710     -5.4473882913589478e-01
    z[5,2,4]  R1711     -7.5190836191177368e-01
    z[5,2,4]  R1712     6.0095246881246567e-02
    z[5,2,4]  R1713     1.6605155169963837e-01
    z[5,2,4]  R1714     -2.0370914041996002e-01
    z[5,2,4]  R1715     2.3565191030502319e-01
    z[5,2,4]  R1716     1.3322633504867554e-01
    z[5,2,4]  R1717     -1.5834622085094452e-02
    z[5,2,4]  R1718     0.277626633644104
    z[5,2,4]  R1719     0.466239869594574
    z[5,2,4]  R1720     2.0291706547141075e-02
    z[5,2,4]  R1721     2.7662605047225952e-01
    z[5,2,4]  R1722     7.7883275225758553e-03
    z[5,2,4]  R1723     2.1679170429706573e-01
    z[5,2,4]  R1724     -1.0537905991077423e-01
    z[5,2,4]  R1725     0.0986253172159195
    z[5,2,4]  R1726     0.00849322509020567
    z[5,2,4]  R1727     2.1699893474578857e-01
    z[5,2,4]  R1728     3.9246338605880737e-01
    z[5,2,4]  R1729     3.7728101015090942e-01
    z[5,2,4]  R1730     5.4241657257080078e-02
    z[5,2,4]  R1731     0.154581680893898
    z[5,2,4]  R1732     3.2734036445617676e-01
    z[5,2,4]  R1733     6.6526606678962708e-02
    z[5,2,4]  R1734     1.0396488755941391e-01
    z[5,2,4]  R1735     -1.1083486676216125e-01
    z[5,2,4]  R1736     2.1375261247158051e-01
    z[5,2,4]  R1737     5.8546119928359985e-01
    z[5,2,4]  R1738     3.8419520854949951e-01
    z[5,2,4]  R1739     3.7921886891126633e-02
    z[5,2,4]  R1740     2.2218170762062073e-01
    z[5,2,4]  R1741     3.6676891148090363e-02
    z[5,2,4]  R1742     -7.9336911439895630e-02
    z[5,2,4]  R1743     -6.3870586454868317e-02
    z[5,2,4]  R1744     -1.1375338584184647e-01
    z[5,2,4]  R1745     -2.6194578409194946e-01
    z[5,2,4]  R1746     -6.8349972367286682e-02
    z[5,2,4]  R1747     6.0959316790103912e-02
    z[5,2,4]  R1748     2.9346242547035217e-01
    z[5,2,4]  R1749     8.8077321648597717e-02
    z[5,2,4]  R1750     9.8922697361558676e-04
    z[5,2,4]  R1751     -3.4094041585922241e-01
    z[5,2,4]  R1752     1.2515866756439209e-01
    z[5,2,4]  R1753     -1.7869557440280914e-01
    z[5,2,4]  R1754     1.4933820068836212e-01
    z[5,2,4]  R1755     -8.8455349206924438e-02
    z[5,2,4]  R1756     2.0481154322624207e-01
    z[5,2,4]  R1757     1.1627225577831268e-01
    z[5,2,4]  R1758     -1.8047428131103516e-01
    z[5,2,4]  R1759     4.3158102035522461e-01
    z[5,2,4]  R1760     8.9279748499393463e-02
    z[5,2,4]  R1761     4.7327745705842972e-02
    z[5,2,4]  R1762     -1.3478185236454010e-01
    z[5,2,4]  R1763     9.2412687838077545e-02
    z[5,2,4]  R1764     2.3024432361125946e-01
    z[5,2,4]  R1765     -4.7474950551986694e-01
    z[5,2,4]  R1766     3.2538694143295288e-01
    z[5,2,4]  R1767     6.5021462738513947e-02
    z[5,2,4]  R1768     -1.3610567152500153e-01
    z[5,2,4]  R1769     -4.4518828392028809e-02
    z[5,2,4]  R1770     1.2379807233810425e-01
    z[5,2,4]  R1771     4.1480544209480286e-01
    z[5,2,4]  R1772     3.1806635856628418e-01
    z[5,2,4]  R1773     -2.6723667979240417e-01
    z[5,2,4]  R1774     0.335847407579422
    z[5,2,4]  R1775     -5.1931455731391907e-02
    z[5,2,4]  R1776     5.0190949440002441e-01
    z[5,2,4]  R1777     2.3953368887305260e-02
    z[5,2,4]  R1778     -3.0785033106803894e-01
    z[5,2,4]  R1779     2.9963433742523193e-01
    z[5,2,4]  R1780     2.2519567608833313e-01
    z[5,2,4]  R1781     -4.9410410225391388e-02
    z[5,2,4]  R1782     -3.4072495996952057e-02
    z[5,2,4]  R1783     2.7562731504440308e-01
    z[5,2,4]  R1784     5.3666192293167114e-01
    z[5,2,4]  R1785     -1.4008262753486633e-01
    z[5,2,4]  R1786     5.3228306770324707e-01
    z[5,2,4]  R1787     3.5014921426773071e-01
    z[5,2,4]  R1788     -2.6225471496582031e-01
    z[5,2,4]  R1789     2.9552286863327026e-01
    z[5,2,4]  R1790     4.7938823699951172e-02
    z[5,2,4]  R1791     -1.8676073849201202e-01
    z[5,2,4]  R1792     -2.2156653925776482e-02
    z[5,2,4]  R1793     1.5780363464727998e-03
    z[5,2,4]  R1794     -3.1281030178070068e-01
    z[5,2,4]  R1795     -3.3786624670028687e-01
    z[5,2,4]  R1796     -9.9446296691894531e-02
    z[5,2,4]  R1797     -3.9691093564033508e-01
    z[5,2,4]  R1798     -2.2341039776802063e-01
    z[5,2,4]  R1799     -1.5150465071201324e-01
    z[5,2,4]  R1800     -2.4573905766010284e-01
    z[5,2,4]  R1801     -2.2003591060638428e-01
    z[5,2,4]  R1802     -4.6767142415046692e-01
    z[5,2,4]  R1803     -0.273552268743515
    z[5,2,4]  R1804     1.2600430846214294e-01
    z[5,2,4]  R1805     -1.2882158160209656e-01
    z[5,2,4]  R1806     2.3652262985706329e-01
    z[5,2,4]  R1807     3.1723294407129288e-02
    z[5,2,4]  R1808     -2.9491975903511047e-02
    z[5,2,4]  R1809     1.5443550050258636e-01
    z[5,2,4]  R1810     -4.2121908068656921e-01
    z[5,2,4]  R1811     1.8458089232444763e-01
    z[5,2,4]  R1812     1.7301696538925171e-01
    z[5,2,4]  R1813     7.5182333588600159e-02
    z[5,2,4]  R1814     -2.9577374458312988e-01
    z[5,2,4]  R1815     3.4480038285255432e-01
    z[5,2,4]  R1816     1.5085572004318237e-01
    z[5,2,4]  R1817     -1.7213378846645355e-01
    z[5,2,4]  R1818     -2.7899801731109619e-02
    z[5,2,4]  R1819     1.2818282842636108e-01
    z[5,2,4]  R1820     2.9733744263648987e-01
    z[5,2,4]  R1821     -5.7709133625030518e-01
    z[5,2,4]  R1822     -6.4456969499588013e-01
    z[5,2,4]  R1823     -4.7712764143943787e-01
    z[5,2,4]  R1824     -2.0363937318325043e-01
    z[5,2,4]  R1825     -2.2551403380930424e-03
    z[5,2,5]  R25       1
    z[5,2,5]  R52       -1
    z[5,2,5]  R1702     -1
    z[5,2,5]  R1703     1
    z[5,2,5]  R1706     -3.4532821178436279e-01
    z[5,2,5]  R1707     -2.1436698734760284e-02
    z[5,2,5]  R1708     2.7303391695022583e-01
    z[5,2,5]  R1709     1.1729851365089417e-01
    z[5,2,5]  R1710     4.1483619809150696e-01
    z[5,2,5]  R1711     3.1923133134841919e-01
    z[5,2,5]  R1712     -1.3287958502769470e-01
    z[5,2,5]  R1713     2.7967765927314758e-01
    z[5,2,5]  R1714     2.5065195560455322e-01
    z[5,2,5]  R1715     -2.0192395150661469e-01
    z[5,2,5]  R1716     1.4752630889415741e-01
    z[5,2,5]  R1717     1.8181920051574707e-01
    z[5,2,5]  R1718     0.220264732837677
    z[5,2,5]  R1719     -3.2586917281150818e-02
    z[5,2,5]  R1720     -5.7722595520317554e-03
    z[5,2,5]  R1721     -5.5649623274803162e-02
    z[5,2,5]  R1722     3.8544493913650513e-01
    z[5,2,5]  R1723     -2.5023165345191956e-01
    z[5,2,5]  R1724     9.4785392284393311e-02
    z[5,2,5]  R1725     2.4255488812923431e-01
    z[5,2,5]  R1726     -1.9831936806440353e-02
    z[5,2,5]  R1727     4.4322180747985840e-01
    z[5,2,5]  R1728     -1.4351183176040649e-01
    z[5,2,5]  R1729     2.0533630251884460e-01
    z[5,2,5]  R1730     5.4337686300277710e-01
    z[5,2,5]  R1731     3.7895879149436951e-01
    z[5,2,5]  R1732     5.9802955389022827e-01
    z[5,2,5]  R1733     -0.599342405796051
    z[5,2,5]  R1734     4.1543442010879517e-01
    z[5,2,5]  R1735     -1.1101827770471573e-01
    z[5,2,5]  R1736     4.6737310290336609e-01
    z[5,2,5]  R1737     2.1555164456367493e-01
    z[5,2,5]  R1738     0.607568085193634
    z[5,2,5]  R1739     0.532397449016571
    z[5,2,5]  R1740     -2.6702085137367249e-01
    z[5,2,5]  R1741     2.0080116391181946e-01
    z[5,2,5]  R1742     -6.3286215066909790e-02
    z[5,2,5]  R1743     -1.5741702169179916e-02
    z[5,2,5]  R1744     -1.3458141684532166e-01
    z[5,2,5]  R1745     1.3015043735504150e-01
    z[5,2,5]  R1746     -8.1709325313568115e-02
    z[5,2,5]  R1747     -5.7853251695632935e-01
    z[5,2,5]  R1748     2.4344623088836670e-02
    z[5,2,5]  R1749     -9.7902357578277588e-02
    z[5,2,5]  R1750     -1.1295893043279648e-01
    z[5,2,5]  R1751     -1.3188610784709454e-02
    z[5,2,5]  R1752     -4.7790925949811935e-02
    z[5,2,5]  R1753     -1.4583942294120789e-01
    z[5,2,5]  R1754     -0.0196728203445673
    z[5,2,5]  R1755     -8.7292753159999847e-02
    z[5,2,5]  R1756     1.9400827586650848e-01
    z[5,2,5]  R1757     1.9348324835300446e-01
    z[5,2,5]  R1758     -2.4957165122032166e-01
    z[5,2,5]  R1759     2.1434809267520905e-01
    z[5,2,5]  R1760     1.7687307298183441e-01
    z[5,2,5]  R1761     0.0924796313047409
    z[5,2,5]  R1762     2.7627438306808472e-01
    z[5,2,5]  R1763     3.8378086686134338e-01
    z[5,2,5]  R1764     5.0076556205749512e-01
    z[5,2,5]  R1765     3.6635959148406982e-01
    z[5,2,5]  R1766     -0.655155599117279
    z[5,2,5]  R1767     2.6621329784393311e-01
    z[5,2,5]  R1768     -0.0172334685921669
    z[5,2,5]  R1769     0.386877179145813
    z[5,2,5]  R1770     6.8370831012725830e-01
    z[5,2,5]  R1771     4.0803152322769165e-01
    z[5,2,5]  R1772     0.0565381720662117
    z[5,2,5]  R1773     0.100244902074337
    z[5,2,5]  R1774     -3.4102091193199158e-01
    z[5,2,5]  R1775     2.6719495654106140e-01
    z[5,2,5]  R1776     -2.7230077981948853e-01
    z[5,2,5]  R1777     6.2127064913511276e-02
    z[5,2,5]  R1778     9.1365143656730652e-02
    z[5,2,5]  R1779     -4.5349341630935669e-01
    z[5,2,5]  R1780     -2.9470628499984741e-01
    z[5,2,5]  R1781     2.8922820091247559e-01
    z[5,2,5]  R1782     5.0339066982269287e-01
    z[5,2,5]  R1783     -1.0987876914441586e-02
    z[5,2,5]  R1784     -2.1653366088867188e-01
    z[5,2,5]  R1785     -2.0477293431758881e-01
    z[5,2,5]  R1786     -5.5073618888854980e-02
    z[5,2,5]  R1787     0.151590496301651
    z[5,2,5]  R1788     4.6486937999725342e-01
    z[5,2,5]  R1789     6.2038439512252808e-01
    z[5,2,5]  R1790     6.5783679485321045e-01
    z[5,2,5]  R1791     4.6448069810867310e-01
    z[5,2,5]  R1792     -2.0570924878120422e-01
    z[5,2,5]  R1793     7.2977238893508911e-01
    z[5,2,5]  R1794     2.4681676924228668e-01
    z[5,2,5]  R1795     1.1680758744478226e-01
    z[5,2,5]  R1796     4.2079731822013855e-01
    z[5,2,5]  R1797     9.8230935633182526e-02
    z[5,2,5]  R1798     3.7939116358757019e-01
    z[5,2,5]  R1799     5.3273308277130127e-01
    z[5,2,5]  R1800     3.8930308818817139e-01
    z[5,2,5]  R1801     3.5388889908790588e-01
    z[5,2,5]  R1802     -2.1736070513725281e-01
    z[5,2,5]  R1803     1.3541743159294128e-01
    z[5,2,5]  R1804     -2.4555966258049011e-01
    z[5,2,5]  R1805     2.1628174930810928e-02
    z[5,2,5]  R1806     -0.213386669754982
    z[5,2,5]  R1807     6.2998242676258087e-02
    z[5,2,5]  R1808     4.8398381471633911e-01
    z[5,2,5]  R1809     9.2903882265090942e-02
    z[5,2,5]  R1810     4.3472254276275635e-01
    z[5,2,5]  R1811     1.5766884386539459e-01
    z[5,2,5]  R1812     -2.6922854781150818e-01
    z[5,2,5]  R1813     -2.9883456230163574e-01
    z[5,2,5]  R1814     3.1535025686025620e-02
    z[5,2,5]  R1815     -1.9695109128952026e-01
    z[5,2,5]  R1816     -2.9514765739440918e-01
    z[5,2,5]  R1817     5.9990507364273071e-01
    z[5,2,5]  R1818     -3.3689178526401520e-02
    z[5,2,5]  R1819     2.7362295985221863e-01
    z[5,2,5]  R1820     8.9038470759987831e-03
    z[5,2,5]  R1821     -0.312675416469574
    z[5,2,5]  R1822     9.4866394996643066e-02
    z[5,2,5]  R1823     -1.6696314513683319e-01
    z[5,2,5]  R1824     -4.4190770387649536e-01
    z[5,2,5]  R1825     -7.9289132356643677e-01
    z[5,2,6]  R26       1
    z[5,2,6]  R53       -1
    z[5,2,6]  R1704     -1
    z[5,2,6]  R1705     1
    z[5,2,6]  R1706     -2.0312076434493065e-02
    z[5,2,6]  R1707     1.2939487397670746e-01
    z[5,2,6]  R1708     1.0314755886793137e-01
    z[5,2,6]  R1709     3.5929429531097412e-01
    z[5,2,6]  R1710     -4.9746152758598328e-01
    z[5,2,6]  R1711     3.5357251763343811e-01
    z[5,2,6]  R1712     -5.3053814172744751e-01
    z[5,2,6]  R1713     -1.2930710613727570e-01
    z[5,2,6]  R1714     -5.7356774806976318e-01
    z[5,2,6]  R1715     -3.0101948976516724e-01
    z[5,2,6]  R1716     1.8088242411613464e-01
    z[5,2,6]  R1717     4.8972561955451965e-01
    z[5,2,6]  R1718     3.6241775751113892e-01
    z[5,2,6]  R1719     -2.9049712419509888e-01
    z[5,2,6]  R1720     -2.3624455928802490e-01
    z[5,2,6]  R1721     4.2786914110183716e-01
    z[5,2,6]  R1722     2.8338947892189026e-01
    z[5,2,6]  R1723     4.8365625739097595e-01
    z[5,2,6]  R1724     0.19088114798069
    z[5,2,6]  R1725     6.0252988338470459e-01
    z[5,2,6]  R1726     -0.0972653478384018
    z[5,2,6]  R1727     5.3693417459726334e-02
    z[5,2,6]  R1728     6.0087740421295166e-01
    z[5,2,6]  R1729     -5.4085552692413330e-01
    z[5,2,6]  R1730     -1.0240268707275391e-01
    z[5,2,6]  R1731     1.4011496305465698e-01
    z[5,2,6]  R1732     3.1017169356346130e-01
    z[5,2,6]  R1733     5.2726560831069946e-01
    z[5,2,6]  R1734     5.6427329778671265e-01
    z[5,2,6]  R1735     -1.6300034523010254e-01
    z[5,2,6]  R1736     -2.3612719774246216e-01
    z[5,2,6]  R1737     6.5532989799976349e-02
    z[5,2,6]  R1738     -1.9043833017349243e-01
    z[5,2,6]  R1739     -1.1923649907112122e-01
    z[5,2,6]  R1740     4.7771230340003967e-01
    z[5,2,6]  R1741     1.5649099647998810e-01
    z[5,2,6]  R1742     5.2848167717456818e-02
    z[5,2,6]  R1743     -6.4299695193767548e-02
    z[5,2,6]  R1744     2.0884481072425842e-01
    z[5,2,6]  R1745     4.1663125157356262e-01
    z[5,2,6]  R1746     6.7505091428756714e-02
    z[5,2,6]  R1747     2.2287836670875549e-01
    z[5,2,6]  R1748     -2.2092872858047485e-01
    z[5,2,6]  R1749     -3.8008540868759155e-01
    z[5,2,6]  R1750     -2.3824036121368408e-01
    z[5,2,6]  R1751     -4.5026361942291260e-01
    z[5,2,6]  R1752     -5.8528423309326172e-01
    z[5,2,6]  R1753     -3.8883182406425476e-01
    z[5,2,6]  R1754     7.0273093879222870e-02
    z[5,2,6]  R1755     1.1326502077281475e-02
    z[5,2,6]  R1756     4.8504152894020081e-01
    z[5,2,6]  R1757     -6.7624074220657349e-01
    z[5,2,6]  R1758     -0.0548379123210907
    z[5,2,6]  R1759     -3.8653293251991272e-01
    z[5,2,6]  R1760     2.7660849690437317e-01
    z[5,2,6]  R1761     0.660368800163269
    z[5,2,6]  R1762     3.5540419816970825e-01
    z[5,2,6]  R1763     -3.1410497426986694e-01
    z[5,2,6]  R1764     -3.4020674228668213e-01
    z[5,2,6]  R1765     1.0890915989875793e-01
    z[5,2,6]  R1766     -5.5048700422048569e-02
    z[5,2,6]  R1767     3.8220253586769104e-01
    z[5,2,6]  R1768     1.9806094467639923e-01
    z[5,2,6]  R1769     -3.2253879308700562e-01
    z[5,2,6]  R1770     -1.0856601595878601e-01
    z[5,2,6]  R1771     1.3984479010105133e-01
    z[5,2,6]  R1772     3.5530152916908264e-01
    z[5,2,6]  R1773     3.1432738900184631e-01
    z[5,2,6]  R1774     -6.4855682849884033e-01
    z[5,2,6]  R1775     -4.3666839599609375e-01
    z[5,2,6]  R1776     4.8712867498397827e-01
    z[5,2,6]  R1777     4.7566527128219604e-01
    z[5,2,6]  R1778     5.2784645557403564e-01
    z[5,2,6]  R1779     4.8449450731277466e-01
    z[5,2,6]  R1780     -3.9211180806159973e-01
    z[5,2,6]  R1781     1.8672230839729309e-01
    z[5,2,6]  R1782     -0.120102658867836
    z[5,2,6]  R1783     1.8224196135997772e-01
    z[5,2,6]  R1784     -1.5171281993389130e-02
    z[5,2,6]  R1785     -4.6104211360216141e-02
    z[5,2,6]  R1786     -9.4352580606937408e-02
    z[5,2,6]  R1787     -3.1050495803356171e-02
    z[5,2,6]  R1788     -2.1376334130764008e-01
    z[5,2,6]  R1789     -1.7244471237063408e-02
    z[5,2,6]  R1790     -1.3816219754517078e-02
    z[5,2,6]  R1791     -5.5287098884582520e-01
    z[5,2,6]  R1792     -3.3973211050033569e-01
    z[5,2,6]  R1793     9.6057079732418060e-02
    z[5,2,6]  R1794     3.9783695340156555e-01
    z[5,2,6]  R1795     -0.396820992231369
    z[5,2,6]  R1796     9.2072226107120514e-02
    z[5,2,6]  R1797     6.0303029604256153e-03
    z[5,2,6]  R1798     -7.7498771250247955e-02
    z[5,2,6]  R1799     5.4637116193771362e-01
    z[5,2,6]  R1800     -6.2113553285598755e-01
    z[5,2,6]  R1801     -4.7485873103141785e-01
    z[5,2,6]  R1802     -4.7389128804206848e-01
    z[5,2,6]  R1803     -3.2400522381067276e-02
    z[5,2,6]  R1804     -4.5558240264654160e-02
    z[5,2,6]  R1805     1.7671963572502136e-01
    z[5,2,6]  R1806     -2.6876670122146606e-01
    z[5,2,6]  R1807     -4.5331677794456482e-01
    z[5,2,6]  R1808     -6.3738840818405151e-01
    z[5,2,6]  R1809     6.1344724148511887e-02
    z[5,2,6]  R1810     -1.4742341637611389e-01
    z[5,2,6]  R1811     -5.5559659004211426e-01
    z[5,2,6]  R1812     -2.8658014535903931e-01
    z[5,2,6]  R1813     -2.7599132061004639e-01
    z[5,2,6]  R1814     3.0139073729515076e-01
    z[5,2,6]  R1815     1.9801907241344452e-01
    z[5,2,6]  R1816     -4.1881343722343445e-01
    z[5,2,6]  R1817     -1.2827715277671814e-01
    z[5,2,6]  R1818     -1.3251449167728424e-01
    z[5,2,6]  R1819     -6.8024778366088867e-01
    z[5,2,6]  R1820     -3.2817268371582031e-01
    z[5,2,6]  R1821     0.483521431684494
    z[5,2,6]  R1822     3.1587496399879456e-01
    z[5,2,6]  R1823     2.1890194714069366e-01
    z[5,2,6]  R1824     4.9500128626823425e-01
    z[5,2,6]  R1825     3.1799605488777161e-01
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R1920     -1
    z[3,4,0]  R1921     1
    z[3,4,0]  R1934     -0.0724978893995285
    z[3,4,0]  R1935     -4.6777565032243729e-02
    z[3,4,0]  R1936     -2.4329090118408203e-01
    z[3,4,0]  R1937     4.0715175867080688e-01
    z[3,4,0]  R1938     4.3260368704795837e-01
    z[3,4,0]  R1939     0.0834726095199585
    z[3,4,0]  R1940     2.7277067303657532e-01
    z[3,4,0]  R1941     -1.8065112829208374e-01
    z[3,4,0]  R1942     6.1964333057403564e-01
    z[3,4,0]  R1943     0.50345778465271
    z[3,4,0]  R1944     -4.7514325380325317e-01
    z[3,4,0]  R1945     -7.3216485977172852e-01
    z[3,4,0]  R1946     -6.8617612123489380e-02
    z[3,4,0]  R1947     -1.3920140266418457e-01
    z[3,4,0]  R1948     3.6757206916809082e-01
    z[3,4,0]  R1949     -6.3396227359771729e-01
    z[3,4,0]  R1950     1.8794808536767960e-02
    z[3,4,0]  R1951     5.7484483718872070e-01
    z[3,4,0]  R1952     -0.646687924861908
    z[3,4,0]  R1953     -3.1646620482206345e-02
    z[3,4,0]  R1954     5.3065598011016846e-02
    z[3,4,0]  R1955     -4.2238497734069824e-01
    z[3,4,0]  R1956     1.4733880758285522e-01
    z[3,4,0]  R1957     1.1937868595123291e-01
    z[3,4,0]  R1958     -3.7263453006744385e-01
    z[3,4,0]  R1959     -4.0921968221664429e-01
    z[3,4,0]  R1960     -3.6647709202952683e-04
    z[3,4,0]  R1961     1.9305494427680969e-01
    z[3,4,0]  R1962     5.4454523324966431e-01
    z[3,4,0]  R1963     -0.0954597219824791
    z[3,4,0]  R1964     -1.1888053268194199e-02
    z[3,4,0]  R1965     0.171873077750206
    z[3,4,0]  R1966     1.6375808417797089e-01
    z[3,4,0]  R1967     -3.5804528743028641e-02
    z[3,4,0]  R1968     2.4036203324794769e-01
    z[3,4,0]  R1969     1.1482414603233337e-01
    z[3,4,0]  R1970     2.5157424807548523e-01
    z[3,4,0]  R1971     1.0743453353643417e-01
    z[3,4,0]  R1972     4.7169345617294312e-01
    z[3,4,0]  R1973     0.588336706161499
    z[3,4,0]  R1974     0.281033456325531
    z[3,4,0]  R1975     1.3424830138683319e-01
    z[3,4,0]  R1976     -4.6949443221092224e-01
    z[3,4,0]  R1977     -1.7303615808486938e-01
    z[3,4,0]  R1978     7.3897249996662140e-02
    z[3,4,0]  R1979     5.4487264156341553e-01
    z[3,4,0]  R1980     -0.185902938246727
    z[3,4,0]  R1981     1.8640726804733276e-01
    z[3,4,0]  R1982     2.7073812484741211e-01
    z[3,4,0]  R1983     -4.0726426243782043e-01
    z[3,4,0]  R1984     -3.0519025400280952e-02
    z[3,4,0]  R1985     1.7708288133144379e-01
    z[3,4,0]  R1986     -3.5844030976295471e-01
    z[3,4,0]  R1987     -1.4807590842247009e-01
    z[3,4,0]  R1988     0.0971425324678421
    z[3,4,0]  R1989     4.5451264828443527e-02
    z[3,4,0]  R1990     7.7890351414680481e-02
    z[3,4,0]  R1991     -2.6252783834934235e-02
    z[3,4,0]  R1992     1.1205359548330307e-01
    z[3,4,0]  R1993     8.0074248835444450e-03
    z[3,4,0]  R1994     -3.5911047458648682e-01
    z[3,4,0]  R1995     -3.5800606012344360e-01
    z[3,4,0]  R1996     -1.3780531287193298e-01
    z[3,4,0]  R1997     -2.9238942265510559e-01
    z[3,4,0]  R1998     -1.8122249841690063e-01
    z[3,4,0]  R1999     -1.4514103531837463e-01
    z[3,4,0]  R2000     -3.9680501818656921e-01
    z[3,4,0]  R2001     -3.6523446440696716e-01
    z[3,4,0]  R2002     -7.7383734285831451e-02
    z[3,4,0]  R2003     -4.0516808629035950e-01
    z[3,4,0]  R2004     0.942054808139801
    z[3,4,0]  R2005     8.9981865882873535e-01
    z[3,4,0]  R2006     5.8713823556900024e-01
    z[3,4,0]  R2007     6.0660946369171143e-01
    z[3,4,0]  R2008     6.0895085334777832e-01
    z[3,4,0]  R2009     0.65199875831604
    z[3,4,0]  R2010     5.9659922122955322e-01
    z[3,4,0]  R2011     1.1463463306427002e-01
    z[3,4,0]  R2012     5.4364860057830811e-01
    z[3,4,0]  R2013     2.2304007411003113e-01
    z[3,4,0]  R2014     -0.943132221698761
    z[3,4,0]  R2015     -4.1723379492759705e-01
    z[3,4,0]  R2016     3.8019508123397827e-01
    z[3,4,0]  R2017     4.4824984669685364e-01
    z[3,4,0]  R2018     5.2685993909835815e-01
    z[3,4,0]  R2019     9.4603672623634338e-02
    z[3,4,0]  R2020     -2.4945980310440063e-01
    z[3,4,0]  R2021     -2.7539214491844177e-01
    z[3,4,0]  R2022     1.0563543438911438e-01
    z[3,4,0]  R2023     7.7304452657699585e-02
    z[3,4,0]  R2024     -9.3091838061809540e-02
    z[3,4,0]  R2025     -5.1429796218872070e-01
    z[3,4,0]  R2026     6.5010762214660645e-01
    z[3,4,0]  R2027     -1.0805778205394745e-02
    z[3,4,0]  R2028     1.4774626493453979e-01
    z[3,4,0]  R2029     1.1612449586391449e-01
    z[3,4,0]  R2030     3.6412292718887329e-01
    z[3,4,0]  R2031     5.1719751209020615e-02
    z[3,4,0]  R2032     -9.9702635779976845e-03
    z[3,4,0]  R2033     -5.7827834039926529e-02
    z[3,4,0]  R2034     3.3384832739830017e-01
    z[3,4,0]  R2035     -1.3449686765670776e-01
    z[3,4,0]  R2036     -8.7584452703595161e-03
    z[3,4,0]  R2037     4.8221364617347717e-01
    z[3,4,0]  R2038     8.4913492202758789e-02
    z[3,4,0]  R2039     -3.2118913531303406e-01
    z[3,4,0]  R2040     2.1783185005187988e-01
    z[3,4,0]  R2041     2.6415199041366577e-01
    z[3,4,0]  R2042     1.2744180858135223e-01
    z[3,4,0]  R2043     1.4033287763595581e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R1922     -1
    z[3,4,1]  R1923     1
    z[3,4,1]  R1934     -4.9576304852962494e-02
    z[3,4,1]  R1935     7.2479605674743652e-02
    z[3,4,1]  R1936     2.3105706274509430e-01
    z[3,4,1]  R1937     -2.5389257073402405e-01
    z[3,4,1]  R1938     -4.3938377499580383e-01
    z[3,4,1]  R1939     -3.6427742242813110e-01
    z[3,4,1]  R1940     -2.4248623847961426e-01
    z[3,4,1]  R1941     -4.6545240283012390e-01
    z[3,4,1]  R1942     -7.4089878797531128e-01
    z[3,4,1]  R1943     -7.9328811168670654e-01
    z[3,4,1]  R1944     5.8730334043502808e-01
    z[3,4,1]  R1945     -1.2613086402416229e-01
    z[3,4,1]  R1946     6.6275602579116821e-01
    z[3,4,1]  R1947     -4.1508737206459045e-01
    z[3,4,1]  R1948     3.2214462757110596e-01
    z[3,4,1]  R1949     -5.2270042896270752e-01
    z[3,4,1]  R1950     -2.3105403780937195e-01
    z[3,4,1]  R1951     6.9843542575836182e-01
    z[3,4,1]  R1952     -1.9056378304958344e-01
    z[3,4,1]  R1953     2.1849560737609863e-01
    z[3,4,1]  R1954     1.7878186702728271e-01
    z[3,4,1]  R1955     2.7323865890502930e-01
    z[3,4,1]  R1956     1.0493151843547821e-01
    z[3,4,1]  R1957     -3.5202798247337341e-01
    z[3,4,1]  R1958     1.1936495453119278e-01
    z[3,4,1]  R1959     1.4401400089263916e-01
    z[3,4,1]  R1960     -1.7586109042167664e-01
    z[3,4,1]  R1961     2.0621287822723389e-01
    z[3,4,1]  R1962     1.2347144633531570e-01
    z[3,4,1]  R1963     -1.7415875196456909e-01
    z[3,4,1]  R1964     0.224227637052536
    z[3,4,1]  R1965     -1.6536530852317810e-01
    z[3,4,1]  R1966     2.7318241074681282e-02
    z[3,4,1]  R1967     -5.0901472568511963e-01
    z[3,4,1]  R1968     0.830104649066925
    z[3,4,1]  R1969     -7.4446122162044048e-03
    z[3,4,1]  R1970     5.8689326047897339e-01
    z[3,4,1]  R1971     -1.6676047444343567e-01
    z[3,4,1]  R1972     -1.4324536919593811e-01
    z[3,4,1]  R1973     -1.6525343060493469e-01
    z[3,4,1]  R1974     6.4252667129039764e-02
    z[3,4,1]  R1975     -3.2476228475570679e-01
    z[3,4,1]  R1976     -1.9919112324714661e-01
    z[3,4,1]  R1977     5.5956762284040451e-02
    z[3,4,1]  R1978     -4.8003333806991577e-01
    z[3,4,1]  R1979     -1.9607719033956528e-02
    z[3,4,1]  R1980     1.0768979787826538e-01
    z[3,4,1]  R1981     1.4857201278209686e-01
    z[3,4,1]  R1982     -1.0986895859241486e-01
    z[3,4,1]  R1983     -3.8663852214813232e-01
    z[3,4,1]  R1984     -2.2436386346817017e-01
    z[3,4,1]  R1985     1.0586047172546387e-01
    z[3,4,1]  R1986     8.6570112034678459e-03
    z[3,4,1]  R1987     6.6662162542343140e-02
    z[3,4,1]  R1988     2.4361225962638855e-01
    z[3,4,1]  R1989     -1.4660495519638062e-01
    z[3,4,1]  R1990     -3.5686942934989929e-01
    z[3,4,1]  R1991     -4.2440363764762878e-01
    z[3,4,1]  R1992     -2.1864071488380432e-01
    z[3,4,1]  R1993     -0.318697065114975
    z[3,4,1]  R1994     3.9992593228816986e-02
    z[3,4,1]  R1995     8.8066153228282928e-02
    z[3,4,1]  R1996     -1.4184577763080597e-01
    z[3,4,1]  R1997     1.9708101451396942e-01
    z[3,4,1]  R1998     1.9181822240352631e-01
    z[3,4,1]  R1999     1.7235554754734039e-01
    z[3,4,1]  R2000     1.0931375622749329e-01
    z[3,4,1]  R2001     0.334354430437088
    z[3,4,1]  R2002     1.9728232920169830e-01
    z[3,4,1]  R2003     1.5075589530169964e-02
    z[3,4,1]  R2004     5.3768295794725418e-02
    z[3,4,1]  R2005     2.5043004751205444e-01
    z[3,4,1]  R2006     0.412627249956131
    z[3,4,1]  R2007     -4.2724588513374329e-01
    z[3,4,1]  R2008     -7.0076274871826172e-01
    z[3,4,1]  R2009     -6.1578017473220825e-01
    z[3,4,1]  R2010     -7.4422496557235718e-01
    z[3,4,1]  R2011     -3.5293185710906982e-01
    z[3,4,1]  R2012     -5.6348502635955811e-01
    z[3,4,1]  R2013     -3.0520507693290710e-01
    z[3,4,1]  R2014     2.6929962635040283e-01
    z[3,4,1]  R2015     0.547633171081543
    z[3,4,1]  R2016     -3.4225234389305115e-01
    z[3,4,1]  R2017     -3.7711513042449951e-01
    z[3,4,1]  R2018     5.0179883837699890e-02
    z[3,4,1]  R2019     4.6545788645744324e-02
    z[3,4,1]  R2020     -4.1894862055778503e-01
    z[3,4,1]  R2021     -0.589698076248169
    z[3,4,1]  R2022     -2.8642225265502930e-01
    z[3,4,1]  R2023     0.365046888589859
    z[3,4,1]  R2024     7.0368468761444092e-01
    z[3,4,1]  R2025     6.3230073451995850e-01
    z[3,4,1]  R2026     5.2852157503366470e-02
    z[3,4,1]  R2027     -3.5425764322280884e-01
    z[3,4,1]  R2028     -0.572669506072998
    z[3,4,1]  R2029     3.5959962755441666e-02
    z[3,4,1]  R2030     6.5954573452472687e-02
    z[3,4,1]  R2031     -3.4190490841865540e-01
    z[3,4,1]  R2032     -1.7867447435855865e-01
    z[3,4,1]  R2033     -2.2493988275527954e-01
    z[3,4,1]  R2034     -2.8695452213287354e-01
    z[3,4,1]  R2035     -5.7241046428680420e-01
    z[3,4,1]  R2036     -3.8586992025375366e-01
    z[3,4,1]  R2037     -2.0042078197002411e-01
    z[3,4,1]  R2038     -1.7952386289834976e-02
    z[3,4,1]  R2039     -1.3532178103923798e-01
    z[3,4,1]  R2040     0.408532053232193
    z[3,4,1]  R2041     -0.789068877696991
    z[3,4,1]  R2042     -0.81621253490448
    z[3,4,1]  R2043     -7.4622911214828491e-01
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R1924     -1
    z[3,4,2]  R1925     1
    z[3,4,2]  R1934     7.7604496479034424e-01
    z[3,4,2]  R1935     6.0417407751083374e-01
    z[3,4,2]  R1936     5.0335592031478882e-01
    z[3,4,2]  R1937     -6.9426339864730835e-01
    z[3,4,2]  R1938     -7.7314120531082153e-01
    z[3,4,2]  R1939     -7.2934788465499878e-01
    z[3,4,2]  R1940     -8.4491407871246338e-01
    z[3,4,2]  R1941     -8.0140662193298340e-01
    z[3,4,2]  R1942     2.1349819377064705e-02
    z[3,4,2]  R1943     -1.2619367334991693e-03
    z[3,4,2]  R1944     -2.8861820697784424e-01
    z[3,4,2]  R1945     2.0243752002716064e-01
    z[3,4,2]  R1946     1.3058094680309296e-01
    z[3,4,2]  R1947     -4.0662899613380432e-01
    z[3,4,2]  R1948     -2.4025954306125641e-01
    z[3,4,2]  R1949     -4.4705423712730408e-01
    z[3,4,2]  R1950     -3.4929844737052917e-01
    z[3,4,2]  R1951     -2.6159957051277161e-01
    z[3,4,2]  R1952     -3.8386201858520508e-01
    z[3,4,2]  R1953     -1.2975965440273285e-01
    z[3,4,2]  R1954     6.3734084367752075e-01
    z[3,4,2]  R1955     -1.9241769611835480e-01
    z[3,4,2]  R1956     -8.8255876302719116e-01
    z[3,4,2]  R1957     -5.4816991090774536e-01
    z[3,4,2]  R1958     -6.3943284749984741e-01
    z[3,4,2]  R1959     -4.0944692492485046e-01
    z[3,4,2]  R1960     -6.5266954898834229e-01
    z[3,4,2]  R1961     -1.9232214987277985e-01
    z[3,4,2]  R1962     -5.2635037899017334e-01
    z[3,4,2]  R1963     -6.7669701576232910e-01
    z[3,4,2]  R1964     -6.8888491392135620e-01
    z[3,4,2]  R1965     -0.37347611784935
    z[3,4,2]  R1966     -0.797686755657196
    z[3,4,2]  R1967     -1.9151577353477478e-01
    z[3,4,2]  R1968     -5.8459974825382233e-02
    z[3,4,2]  R1969     1.5644293278455734e-02
    z[3,4,2]  R1970     -3.7999540567398071e-01
    z[3,4,2]  R1971     -2.8968313336372375e-01
    z[3,4,2]  R1972     2.9470187425613403e-01
    z[3,4,2]  R1973     -2.9661780595779419e-01
    z[3,4,2]  R1974     -5.4275822639465332e-01
    z[3,4,2]  R1975     -3.4621232748031616e-01
    z[3,4,2]  R1976     -2.6808315515518188e-01
    z[3,4,2]  R1977     -1.0409136116504669e-01
    z[3,4,2]  R1978     -4.9149307608604431e-01
    z[3,4,2]  R1979     -4.5655825734138489e-01
    z[3,4,2]  R1980     -4.3433123826980591e-01
    z[3,4,2]  R1981     -4.2819681763648987e-01
    z[3,4,2]  R1982     -8.9572280645370483e-02
    z[3,4,2]  R1983     -1.3207964599132538e-01
    z[3,4,2]  R1984     -4.7002637386322021e-01
    z[3,4,2]  R1985     -2.5709491968154907e-01
    z[3,4,2]  R1986     -1.9683119654655457e-01
    z[3,4,2]  R1987     -3.2945030927658081e-01
    z[3,4,2]  R1988     -4.3652319908142090e-01
    z[3,4,2]  R1989     -6.7894309759140015e-01
    z[3,4,2]  R1990     -4.7322505712509155e-01
    z[3,4,2]  R1991     -4.1342398524284363e-01
    z[3,4,2]  R1992     9.5625430345535278e-02
    z[3,4,2]  R1993     -1.9718685746192932e-01
    z[3,4,2]  R1994     7.0885759592056274e-01
    z[3,4,2]  R1995     7.2918081283569336e-01
    z[3,4,2]  R1996     0.774948239326477
    z[3,4,2]  R1997     8.6175012588500977e-01
    z[3,4,2]  R1998     -0.421764612197876
    z[3,4,2]  R1999     -0.676142156124115
    z[3,4,2]  R2000     4.2299043387174606e-02
    z[3,4,2]  R2001     1.0496312379837036e-01
    z[3,4,2]  R2002     -4.2408052086830139e-01
    z[3,4,2]  R2003     4.8272809386253357e-01
    z[3,4,2]  R2004     7.6136313378810883e-02
    z[3,4,2]  R2005     -1.1208809167146683e-01
    z[3,4,2]  R2006     -0.0673513412475586
    z[3,4,2]  R2007     -3.7408652901649475e-01
    z[3,4,2]  R2008     -1.6330179572105408e-01
    z[3,4,2]  R2009     -7.6653786003589630e-02
    z[3,4,2]  R2010     -2.0851986110210419e-01
    z[3,4,2]  R2011     -5.0066363811492920e-01
    z[3,4,2]  R2012     -1.8591651320457458e-01
    z[3,4,2]  R2013     -5.1453369855880737e-01
    z[3,4,2]  R2014     -1.3060493767261505e-01
    z[3,4,2]  R2015     -8.7851323187351227e-02
    z[3,4,2]  R2016     -0.742438793182373
    z[3,4,2]  R2017     -4.8063719272613525e-01
    z[3,4,2]  R2018     -6.5481591224670410e-01
    z[3,4,2]  R2019     -3.4209641814231873e-01
    z[3,4,2]  R2020     -7.1385228633880615e-01
    z[3,4,2]  R2021     -6.4999693632125854e-01
    z[3,4,2]  R2022     -0.809843122959137
    z[3,4,2]  R2023     -6.0245621204376221e-01
    z[3,4,2]  R2024     4.5894297957420349e-01
    z[3,4,2]  R2025     1.1132667958736420e-01
    z[3,4,2]  R2026     -6.6455513238906860e-01
    z[3,4,2]  R2027     -5.2812069654464722e-01
    z[3,4,2]  R2028     -5.6795650720596313e-01
    z[3,4,2]  R2029     -6.9453239440917969e-01
    z[3,4,2]  R2030     -0.555451512336731
    z[3,4,2]  R2031     -7.9939246177673340e-01
    z[3,4,2]  R2032     -6.5235203504562378e-01
    z[3,4,2]  R2033     -6.0514295101165771e-01
    z[3,4,2]  R2034     -7.2713285684585571e-01
    z[3,4,2]  R2035     -7.5922089815139771e-01
    z[3,4,2]  R2036     -5.8087509870529175e-01
    z[3,4,2]  R2037     -7.8284674882888794e-01
    z[3,4,2]  R2038     -7.4088609218597412e-01
    z[3,4,2]  R2039     -0.635337233543396
    z[3,4,2]  R2040     -3.9858633279800415e-01
    z[3,4,2]  R2041     4.3616119772195816e-02
    z[3,4,2]  R2042     1.5644568204879761e-01
    z[3,4,2]  R2043     -9.8282612860202789e-02
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R1926     -1
    z[3,4,3]  R1927     1
    z[3,4,3]  R1934     4.6331736445426941e-01
    z[3,4,3]  R1935     5.4184055328369141e-01
    z[3,4,3]  R1936     2.7046254277229309e-01
    z[3,4,3]  R1937     -2.1978422999382019e-01
    z[3,4,3]  R1938     -8.0081552267074585e-02
    z[3,4,3]  R1939     -1.6590537130832672e-01
    z[3,4,3]  R1940     -1.3935063779354095e-01
    z[3,4,3]  R1941     -2.6957049965858459e-01
    z[3,4,3]  R1942     2.0872354507446289e-02
    z[3,4,3]  R1943     -1.9338840246200562e-01
    z[3,4,3]  R1944     4.6935191750526428e-01
    z[3,4,3]  R1945     1.7970761656761169e-01
    z[3,4,3]  R1946     1.6824183985590935e-02
    z[3,4,3]  R1947     -5.7796674966812134e-01
    z[3,4,3]  R1948     -6.2334847450256348e-01
    z[3,4,3]  R1949     -1.8919529020786285e-01
    z[3,4,3]  R1950     -5.4911768436431885e-01
    z[3,4,3]  R1951     -1.9732019305229187e-01
    z[3,4,3]  R1952     -3.9041116833686829e-01
    z[3,4,3]  R1953     -5.4226309061050415e-01
    z[3,4,3]  R1954     4.0418922901153564e-02
    z[3,4,3]  R1955     -7.1027135848999023e-01
    z[3,4,3]  R1956     -1.6832639276981354e-01
    z[3,4,3]  R1957     -3.5620700567960739e-02
    z[3,4,3]  R1958     -6.4964437484741211e-01
    z[3,4,3]  R1959     -6.6607069969177246e-01
    z[3,4,3]  R1960     -1.9485194236040115e-02
    z[3,4,3]  R1961     -6.3764536380767822e-01
    z[3,4,3]  R1962     -7.3052115738391876e-02
    z[3,4,3]  R1963     -1.2792097032070160e-01
    z[3,4,3]  R1964     -6.7898309230804443e-01
    z[3,4,3]  R1965     -6.8302422761917114e-01
    z[3,4,3]  R1966     -1.9481922686100006e-01
    z[3,4,3]  R1967     -7.0268255472183228e-01
    z[3,4,3]  R1968     -3.1143969297409058e-01
    z[3,4,3]  R1969     -6.5013659000396729e-01
    z[3,4,3]  R1970     -6.2126046419143677e-01
    z[3,4,3]  R1971     -6.1172151565551758e-01
    z[3,4,3]  R1972     -0.515038788318634
    z[3,4,3]  R1973     -4.8638768494129181e-02
    z[3,4,3]  R1974     -7.3414909839630127e-01
    z[3,4,3]  R1975     -6.8878930807113647e-01
    z[3,4,3]  R1976     -6.7565697431564331e-01
    z[3,4,3]  R1977     -6.7065227031707764e-01
    z[3,4,3]  R1978     -6.6765159368515015e-01
    z[3,4,3]  R1979     -7.4274338781833649e-02
    z[3,4,3]  R1980     -6.3615453243255615e-01
    z[3,4,3]  R1981     -6.1579936742782593e-01
    z[3,4,3]  R1982     -6.6821444034576416e-01
    z[3,4,3]  R1983     -0.645698070526123
    z[3,4,3]  R1984     -7.2707247734069824e-01
    z[3,4,3]  R1985     -7.0280331373214722e-01
    z[3,4,3]  R1986     -7.2421997785568237e-01
    z[3,4,3]  R1987     -6.5282362699508667e-01
    z[3,4,3]  R1988     -6.3655519485473633e-01
    z[3,4,3]  R1989     -4.8466604202985764e-02
    z[3,4,3]  R1990     7.0134699344635010e-03
    z[3,4,3]  R1991     1.9812983274459839e-01
    z[3,4,3]  R1992     -5.5316168069839478e-01
    z[3,4,3]  R1993     -6.0439020395278931e-01
    z[3,4,3]  R1994     1.5453018248081207e-01
    z[3,4,3]  R1995     2.4318028986454010e-01
    z[3,4,3]  R1996     -6.6407345235347748e-02
    z[3,4,3]  R1997     3.7617892958223820e-03
    z[3,4,3]  R1998     7.7589273452758789e-01
    z[3,4,3]  R1999     4.9217936396598816e-01
    z[3,4,3]  R2000     8.0812788009643555e-01
    z[3,4,3]  R2001     9.9210254848003387e-02
    z[3,4,3]  R2002     2.9624202847480774e-01
    z[3,4,3]  R2003     -5.8686983585357666e-01
    z[3,4,3]  R2004     2.3793120682239532e-01
    z[3,4,3]  R2005     1.7997060716152191e-01
    z[3,4,3]  R2006     -2.1408474445343018e-01
    z[3,4,3]  R2007     -3.9325478672981262e-01
    z[3,4,3]  R2008     -2.1021410822868347e-01
    z[3,4,3]  R2009     -3.5917416214942932e-01
    z[3,4,3]  R2010     1.9981622695922852e-02
    z[3,4,3]  R2011     -5.4983055591583252e-01
    z[3,4,3]  R2012     1.9537252373993397e-03
    z[3,4,3]  R2013     -5.0493568181991577e-01
    z[3,4,3]  R2014     2.7512183412909508e-02
    z[3,4,3]  R2015     5.0766932964324951e-01
    z[3,4,3]  R2016     -2.9457315802574158e-01
    z[3,4,3]  R2017     -4.6839483082294464e-02
    z[3,4,3]  R2018     -4.3036738038063049e-01
    z[3,4,3]  R2019     -0.267819881439209
    z[3,4,3]  R2020     -3.9078226685523987e-01
    z[3,4,3]  R2021     -2.8767085075378418e-01
    z[3,4,3]  R2022     -3.8902035355567932e-01
    z[3,4,3]  R2023     -0.190802201628685
    z[3,4,3]  R2024     5.1662659645080566e-01
    z[3,4,3]  R2025     1.0520192235708237e-01
    z[3,4,3]  R2026     -2.2982361912727356e-01
    z[3,4,3]  R2027     -5.8106422424316406e-01
    z[3,4,3]  R2028     -3.6560976505279541e-01
    z[3,4,3]  R2029     -6.9852042198181152e-01
    z[3,4,3]  R2030     -3.0261768028140068e-02
    z[3,4,3]  R2031     -6.6269993782043457e-02
    z[3,4,3]  R2032     -6.4941161870956421e-01
    z[3,4,3]  R2033     8.2603186368942261e-02
    z[3,4,3]  R2034     -2.2602368891239166e-01
    z[3,4,3]  R2035     -1.2361246347427368e-01
    z[3,4,3]  R2036     -5.3486543893814087e-01
    z[3,4,3]  R2037     -1.1051447689533234e-01
    z[3,4,3]  R2038     -6.4729940891265869e-01
    z[3,4,3]  R2039     -3.4381550550460815e-01
    z[3,4,3]  R2040     -3.5488963127136230e-01
    z[3,4,3]  R2041     0.317862868309021
    z[3,4,3]  R2042     1.6077440977096558e-01
    z[3,4,3]  R2043     4.6951431035995483e-01
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R1928     -1
    z[3,4,4]  R1929     1
    z[3,4,4]  R1934     4.3865670450031757e-03
    z[3,4,4]  R1935     -4.6118754148483276e-01
    z[3,4,4]  R1936     1.1841346323490143e-01
    z[3,4,4]  R1937     -4.7443667054176331e-01
    z[3,4,4]  R1938     -1.2131082266569138e-01
    z[3,4,4]  R1939     -4.9943828582763672e-01
    z[3,4,4]  R1940     6.9983549416065216e-02
    z[3,4,4]  R1941     -0.00828845240175724
    z[3,4,4]  R1942     -1.6975876688957214e-01
    z[3,4,4]  R1943     2.5520551204681396e-01
    z[3,4,4]  R1944     8.3239749073982239e-02
    z[3,4,4]  R1945     5.7291269302368164e-01
    z[3,4,4]  R1946     0.691063642501831
    z[3,4,4]  R1947     -3.2358980178833008e-01
    z[3,4,4]  R1948     -2.2980056703090668e-01
    z[3,4,4]  R1949     -2.0617288351058960e-01
    z[3,4,4]  R1950     6.4487653970718384e-01
    z[3,4,4]  R1951     -1.8258714675903320e-01
    z[3,4,4]  R1952     -2.4823729693889618e-01
    z[3,4,4]  R1953     -5.5757266283035278e-01
    z[3,4,4]  R1954     1.7272646725177765e-01
    z[3,4,4]  R1955     -4.4808611273765564e-01
    z[3,4,4]  R1956     -0.305568128824234
    z[3,4,4]  R1957     -7.2267204523086548e-01
    z[3,4,4]  R1958     -6.1701640486717224e-02
    z[3,4,4]  R1959     -2.0890070497989655e-01
    z[3,4,4]  R1960     -4.6491956710815430e-01
    z[3,4,4]  R1961     -5.3467798233032227e-01
    z[3,4,4]  R1962     -4.5001673698425293e-01
    z[3,4,4]  R1963     -5.4272848367691040e-01
    z[3,4,4]  R1964     -0.089384526014328
    z[3,4,4]  R1965     -5.0186169147491455e-01
    z[3,4,4]  R1966     -4.6230247616767883e-01
    z[3,4,4]  R1967     -2.9163831472396851e-01
    z[3,4,4]  R1968     -3.0278894305229187e-01
    z[3,4,4]  R1969     -6.4142870903015137e-01
    z[3,4,4]  R1970     -2.3578768968582153e-01
    z[3,4,4]  R1971     -3.8169345259666443e-01
    z[3,4,4]  R1972     5.5134284496307373e-01
    z[3,4,4]  R1973     -6.7655169963836670e-01
    z[3,4,4]  R1974     -0.108512744307518
    z[3,4,4]  R1975     -4.1247400641441345e-01
    z[3,4,4]  R1976     -4.0192928910255432e-01
    z[3,4,4]  R1977     -6.9580215215682983e-01
    z[3,4,4]  R1978     -1.1318396031856537e-01
    z[3,4,4]  R1979     -6.7420035600662231e-01
    z[3,4,4]  R1980     -2.3520049452781677e-01
    z[3,4,4]  R1981     -2.8921106457710266e-01
    z[3,4,4]  R1982     -3.5419189929962158e-01
    z[3,4,4]  R1983     -3.9894768595695496e-01
    z[3,4,4]  R1984     -3.5633343458175659e-01
    z[3,4,4]  R1985     -5.8956694602966309e-01
    z[3,4,4]  R1986     -5.1626938581466675e-01
    z[3,4,4]  R1987     -4.4307643175125122e-01
    z[3,4,4]  R1988     -2.6427084207534790e-01
    z[3,4,4]  R1989     -6.7825454473495483e-01
    z[3,4,4]  R1990     -7.0003032684326172e-01
    z[3,4,4]  R1991     -5.7839977741241455e-01
    z[3,4,4]  R1992     4.3254518508911133e-01
    z[3,4,4]  R1993     6.2546718120574951e-01
    z[3,4,4]  R1994     0.584718644618988
    z[3,4,4]  R1995     1.1929895728826523e-01
    z[3,4,4]  R1996     4.4568312168121338e-01
    z[3,4,4]  R1997     -1.9457225501537323e-01
    z[3,4,4]  R1998     -2.3900421336293221e-02
    z[3,4,4]  R1999     -3.1577959656715393e-01
    z[3,4,4]  R2000     -3.5803741216659546e-01
    z[3,4,4]  R2001     6.9361424446105957e-01
    z[3,4,4]  R2002     -0.651825487613678
    z[3,4,4]  R2003     1.3738542795181274e-01
    z[3,4,4]  R2004     -1.3454273343086243e-01
    z[3,4,4]  R2005     1.5022955834865570e-01
    z[3,4,4]  R2006     0.452536016702652
    z[3,4,4]  R2007     3.3214700222015381e-01
    z[3,4,4]  R2008     2.2784835100173950e-01
    z[3,4,4]  R2009     -1.3697463274002075e-01
    z[3,4,4]  R2010     1.7680658400058746e-01
    z[3,4,4]  R2011     -4.9967506527900696e-01
    z[3,4,4]  R2012     2.7726349234580994e-01
    z[3,4,4]  R2013     -4.2929565906524658e-01
    z[3,4,4]  R2014     -7.9094909131526947e-02
    z[3,4,4]  R2015     8.4954008460044861e-02
    z[3,4,4]  R2016     -3.1500864028930664e-01
    z[3,4,4]  R2017     -4.3252453207969666e-01
    z[3,4,4]  R2018     -8.6337188258767128e-03
    z[3,4,4]  R2019     -6.2996000051498413e-01
    z[3,4,4]  R2020     8.6528457701206207e-02
    z[3,4,4]  R2021     -2.3535829782485962e-01
    z[3,4,4]  R2022     2.9225587844848633e-01
    z[3,4,4]  R2023     -4.7899162769317627e-01
    z[3,4,4]  R2024     5.1167141646146774e-02
    z[3,4,4]  R2025     2.7436983585357666e-01
    z[3,4,4]  R2026     -1.1434942483901978e-01
    z[3,4,4]  R2027     -4.6427333354949951e-01
    z[3,4,4]  R2028     9.7543504089117050e-03
    z[3,4,4]  R2029     3.3553630113601685e-02
    z[3,4,4]  R2030     -4.8827984929084778e-01
    z[3,4,4]  R2031     9.5876671373844147e-02
    z[3,4,4]  R2032     -1.2067833542823792e-01
    z[3,4,4]  R2033     -4.4259798526763916e-01
    z[3,4,4]  R2034     -4.3967342376708984e-01
    z[3,4,4]  R2035     -1.3392937183380127e-01
    z[3,4,4]  R2036     -4.1266137361526489e-01
    z[3,4,4]  R2037     2.2943212091922760e-01
    z[3,4,4]  R2038     -1.1504572629928589e-01
    z[3,4,4]  R2039     -3.9065372943878174e-01
    z[3,4,4]  R2040     -6.8254613876342773e-01
    z[3,4,4]  R2041     -3.9675071835517883e-01
    z[3,4,4]  R2042     -4.9660202860832214e-01
    z[3,4,4]  R2043     -3.6722466349601746e-01
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R1930     -1
    z[3,4,5]  R1931     1
    z[3,4,5]  R1934     -1.2052126228809357e-01
    z[3,4,5]  R1935     2.6374953985214233e-01
    z[3,4,5]  R1936     5.2855336666107178e-01
    z[3,4,5]  R1937     -1.2794802896678448e-02
    z[3,4,5]  R1938     2.9707642272114754e-02
    z[3,4,5]  R1939     -1.0103664547204971e-01
    z[3,4,5]  R1940     -1.8102893233299255e-01
    z[3,4,5]  R1941     -1.5770480036735535e-01
    z[3,4,5]  R1942     -1.4267264306545258e-01
    z[3,4,5]  R1943     -1.1971701681613922e-01
    z[3,4,5]  R1944     -3.1781506538391113e-01
    z[3,4,5]  R1945     -1.6603751480579376e-01
    z[3,4,5]  R1946     -1.8935577571392059e-01
    z[3,4,5]  R1947     -8.9161597192287445e-02
    z[3,4,5]  R1948     0.506896436214447
    z[3,4,5]  R1949     2.1081382036209106e-01
    z[3,4,5]  R1950     -2.1602389216423035e-01
    z[3,4,5]  R1951     1.9781798124313354e-01
    z[3,4,5]  R1952     -1.3992623426020145e-02
    z[3,4,5]  R1953     5.7354468107223511e-01
    z[3,4,5]  R1954     2.5632017850875854e-01
    z[3,4,5]  R1955     -2.4334864690899849e-02
    z[3,4,5]  R1956     -1.5140607953071594e-01
    z[3,4,5]  R1957     -4.8199485987424850e-02
    z[3,4,5]  R1958     -8.7031446397304535e-02
    z[3,4,5]  R1959     -3.0716273188591003e-01
    z[3,4,5]  R1960     2.5415403768420219e-02
    z[3,4,5]  R1961     4.2185807228088379e-01
    z[3,4,5]  R1962     -3.4934419393539429e-01
    z[3,4,5]  R1963     4.1864994168281555e-01
    z[3,4,5]  R1964     -3.0094233807176352e-04
    z[3,4,5]  R1965     -2.9137805104255676e-01
    z[3,4,5]  R1966     -1.2672282755374908e-02
    z[3,4,5]  R1967     -3.3931252360343933e-01
    z[3,4,5]  R1968     3.4515149891376495e-02
    z[3,4,5]  R1969     2.1613213419914246e-01
    z[3,4,5]  R1970     -5.9224888682365417e-02
    z[3,4,5]  R1971     -1.7145846784114838e-01
    z[3,4,5]  R1972     -2.2228464484214783e-01
    z[3,4,5]  R1973     -2.1431162953376770e-01
    z[3,4,5]  R1974     -2.3515079915523529e-01
    z[3,4,5]  R1975     -9.3471392989158630e-02
    z[3,4,5]  R1976     1.8666934967041016e-01
    z[3,4,5]  R1977     1.1278792470693588e-01
    z[3,4,5]  R1978     2.7752861380577087e-02
    z[3,4,5]  R1979     -1.7858222126960754e-01
    z[3,4,5]  R1980     4.7819722443819046e-02
    z[3,4,5]  R1981     -4.0153592824935913e-01
    z[3,4,5]  R1982     6.4882233738899231e-02
    z[3,4,5]  R1983     -2.0185214281082153e-01
    z[3,4,5]  R1984     -1.3158781826496124e-01
    z[3,4,5]  R1985     -1.5511341392993927e-01
    z[3,4,5]  R1986     -1.7066916823387146e-01
    z[3,4,5]  R1987     4.7792237997055054e-01
    z[3,4,5]  R1988     0.279199481010437
    z[3,4,5]  R1989     2.1251642704010010e-01
    z[3,4,5]  R1990     1.4224325120449066e-01
    z[3,4,5]  R1991     -4.1929554939270020e-01
    z[3,4,5]  R1992     -6.6018944978713989e-01
    z[3,4,5]  R1993     -3.1133770942687988e-02
    z[3,4,5]  R1994     1.1528528295457363e-02
    z[3,4,5]  R1995     0.46016725897789
    z[3,4,5]  R1996     3.6443573236465454e-01
    z[3,4,5]  R1997     -1.1830856651067734e-01
    z[3,4,5]  R1998     2.3036555945873260e-01
    z[3,4,5]  R1999     2.3484787344932556e-01
    z[3,4,5]  R2000     1.8928836286067963e-01
    z[3,4,5]  R2001     3.3975234627723694e-01
    z[3,4,5]  R2002     2.8387647867202759e-01
    z[3,4,5]  R2003     -2.4164432287216187e-01
    z[3,4,5]  R2004     2.3776585236191750e-02
    z[3,4,5]  R2005     -2.4114778637886047e-01
    z[3,4,5]  R2006     1.0148690640926361e-01
    z[3,4,5]  R2007     3.1827643513679504e-02
    z[3,4,5]  R2008     -1.2022651731967926e-01
    z[3,4,5]  R2009     -4.6280834823846817e-02
    z[3,4,5]  R2010     -3.2995335757732391e-02
    z[3,4,5]  R2011     -2.3742890357971191e-01
    z[3,4,5]  R2012     -2.3853017017245293e-02
    z[3,4,5]  R2013     -3.4963092207908630e-01
    z[3,4,5]  R2014     1.0461068153381348e-01
    z[3,4,5]  R2015     -4.8696655035018921e-01
    z[3,4,5]  R2016     3.3102143555879593e-02
    z[3,4,5]  R2017     -3.9775168895721436e-01
    z[3,4,5]  R2018     -3.0349004268646240e-01
    z[3,4,5]  R2019     -6.0651499032974243e-01
    z[3,4,5]  R2020     -3.0408149957656860e-01
    z[3,4,5]  R2021     7.3091499507427216e-02
    z[3,4,5]  R2022     5.0470467656850815e-02
    z[3,4,5]  R2023     -4.5190271735191345e-01
    z[3,4,5]  R2024     -6.0405898839235306e-02
    z[3,4,5]  R2025     -4.4078135490417480e-01
    z[3,4,5]  R2026     -2.4801802635192871e-01
    z[3,4,5]  R2027     1.0184463113546371e-01
    z[3,4,5]  R2028     -3.9927187561988831e-01
    z[3,4,5]  R2029     4.3250724673271179e-02
    z[3,4,5]  R2030     -4.8846244812011719e-01
    z[3,4,5]  R2031     -4.4637325406074524e-01
    z[3,4,5]  R2032     -1.9911728799343109e-01
    z[3,4,5]  R2033     -5.6191688776016235e-01
    z[3,4,5]  R2034     -1.7829376459121704e-01
    z[3,4,5]  R2035     -1.8528230488300323e-01
    z[3,4,5]  R2036     2.2916388511657715e-01
    z[3,4,5]  R2037     2.1229531615972519e-02
    z[3,4,5]  R2038     -2.6011077687144279e-02
    z[3,4,5]  R2039     -4.5171543955802917e-01
    z[3,4,5]  R2040     -1.7164134979248047e-01
    z[3,4,5]  R2041     2.0519137382507324e-01
    z[3,4,5]  R2042     8.1515289843082428e-02
    z[3,4,5]  R2043     -2.0793452858924866e-01
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R1932     -1
    z[3,4,6]  R1933     1
    z[3,4,6]  R1934     0.401039719581604
    z[3,4,6]  R1935     2.2733974456787109e-01
    z[3,4,6]  R1936     5.1721811294555664e-01
    z[3,4,6]  R1937     1.1918663978576660e-01
    z[3,4,6]  R1938     6.0617448762059212e-03
    z[3,4,6]  R1939     2.0301340520381927e-01
    z[3,4,6]  R1940     3.0956250429153442e-01
    z[3,4,6]  R1941     1.0420594364404678e-01
    z[3,4,6]  R1942     1.3056075572967529e-01
    z[3,4,6]  R1943     -1.9015483558177948e-02
    z[3,4,6]  R1944     -1.3336718082427979e-01
    z[3,4,6]  R1945     -1.3766746222972870e-01
    z[3,4,6]  R1946     -1.5901888906955719e-01
    z[3,4,6]  R1947     -4.4302663207054138e-01
    z[3,4,6]  R1948     7.1227133274078369e-02
    z[3,4,6]  R1949     -4.7686256468296051e-02
    z[3,4,6]  R1950     2.4533452093601227e-01
    z[3,4,6]  R1951     -4.3609503656625748e-02
    z[3,4,6]  R1952     4.2882591485977173e-01
    z[3,4,6]  R1953     -2.3034913465380669e-02
    z[3,4,6]  R1954     -6.7959511280059814e-01
    z[3,4,6]  R1955     0.063626728951931
    z[3,4,6]  R1956     2.0914423465728760e-01
    z[3,4,6]  R1957     -1.8838226795196533e-01
    z[3,4,6]  R1958     -6.7836657166481018e-02
    z[3,4,6]  R1959     2.5002774596214294e-01
    z[3,4,6]  R1960     5.7089352607727051e-01
    z[3,4,6]  R1961     1.1305678635835648e-01
    z[3,4,6]  R1962     2.8510963916778564e-01
    z[3,4,6]  R1963     1.2826339900493622e-01
    z[3,4,6]  R1964     7.7527396380901337e-02
    z[3,4,6]  R1965     -1.8467016518115997e-02
    z[3,4,6]  R1966     -2.9033464193344116e-01
    z[3,4,6]  R1967     -9.4842657446861267e-02
    z[3,4,6]  R1968     2.4467891454696655e-01
    z[3,4,6]  R1969     3.2510584592819214e-01
    z[3,4,6]  R1970     -5.2937213331460953e-02
    z[3,4,6]  R1971     5.7222491502761841e-01
    z[3,4,6]  R1972     2.2689729928970337e-01
    z[3,4,6]  R1973     1.8042099475860596e-01
    z[3,4,6]  R1974     -1.2751290202140808e-01
    z[3,4,6]  R1975     -3.2146766781806946e-01
    z[3,4,6]  R1976     -1.2298163771629333e-01
    z[3,4,6]  R1977     -9.7241960465908051e-02
    z[3,4,6]  R1978     2.5140061974525452e-01
    z[3,4,6]  R1979     -4.8264440149068832e-02
    z[3,4,6]  R1980     -5.5036425590515137e-01
    z[3,4,6]  R1981     3.6843335628509521e-01
    z[3,4,6]  R1982     5.7483422756195068e-01
    z[3,4,6]  R1983     2.2443674504756927e-01
    z[3,4,6]  R1984     2.3426796495914459e-01
    z[3,4,6]  R1985     -1.6048528254032135e-01
    z[3,4,6]  R1986     1.1201063543558121e-01
    z[3,4,6]  R1987     1.1910926550626755e-01
    z[3,4,6]  R1988     -4.3320894241333008e-01
    z[3,4,6]  R1989     8.9084036648273468e-02
    z[3,4,6]  R1990     3.6374524235725403e-01
    z[3,4,6]  R1991     3.1410580873489380e-01
    z[3,4,6]  R1992     3.9531286805868149e-02
    z[3,4,6]  R1993     3.1940481066703796e-01
    z[3,4,6]  R1994     -3.2446052879095078e-02
    z[3,4,6]  R1995     -2.1736724674701691e-01
    z[3,4,6]  R1996     -1.5648598968982697e-01
    z[3,4,6]  R1997     2.8492954373359680e-01
    z[3,4,6]  R1998     3.1117478013038635e-01
    z[3,4,6]  R1999     -3.0813741683959961e-01
    z[3,4,6]  R2000     -1.0823823511600494e-01
    z[3,4,6]  R2001     -3.7070021033287048e-01
    z[3,4,6]  R2002     4.2664456367492676e-01
    z[3,4,6]  R2003     4.2532593011856079e-01
    z[3,4,6]  R2004     -1.6901694238185883e-01
    z[3,4,6]  R2005     -4.4010091572999954e-02
    z[3,4,6]  R2006     4.6856218576431274e-01
    z[3,4,6]  R2007     2.0871374011039734e-01
    z[3,4,6]  R2008     2.9726946726441383e-02
    z[3,4,6]  R2009     1.9981640577316284e-01
    z[3,4,6]  R2010     1.1819269508123398e-01
    z[3,4,6]  R2011     -5.7206183671951294e-02
    z[3,4,6]  R2012     5.2432626485824585e-01
    z[3,4,6]  R2013     1.7567428946495056e-01
    z[3,4,6]  R2014     5.4454866796731949e-02
    z[3,4,6]  R2015     1.2733514606952667e-01
    z[3,4,6]  R2016     2.4166754155885428e-04
    z[3,4,6]  R2017     -2.7993968129158020e-01
    z[3,4,6]  R2018     1.1713202297687531e-01
    z[3,4,6]  R2019     -1.8819177150726318e-01
    z[3,4,6]  R2020     -1.8090275116264820e-03
    z[3,4,6]  R2021     1.0212234407663345e-01
    z[3,4,6]  R2022     -1.0798142850399017e-01
    z[3,4,6]  R2023     1.6660369932651520e-01
    z[3,4,6]  R2024     -1.1118955910205841e-01
    z[3,4,6]  R2025     2.0655590295791626e-01
    z[3,4,6]  R2026     -7.4333444237709045e-02
    z[3,4,6]  R2027     1.7864930629730225e-01
    z[3,4,6]  R2028     -1.8564037978649139e-01
    z[3,4,6]  R2029     -1.0917651653289795e-01
    z[3,4,6]  R2030     2.7678442001342773e-01
    z[3,4,6]  R2031     1.6901065409183502e-01
    z[3,4,6]  R2032     2.5781095027923584e-01
    z[3,4,6]  R2033     2.4777625501155853e-01
    z[3,4,6]  R2034     -3.5946812480688095e-02
    z[3,4,6]  R2035     -1.0145907104015350e-01
    z[3,4,6]  R2036     6.8740755319595337e-02
    z[3,4,6]  R2037     -2.2169624269008636e-01
    z[3,4,6]  R2038     1.0318201780319214e-01
    z[3,4,6]  R2039     2.4264785461127758e-03
    z[3,4,6]  R2040     7.4183098971843719e-02
    z[3,4,6]  R2041     -7.1695089340209961e-02
    z[3,4,6]  R2042     1.1821021884679794e-01
    z[3,4,6]  R2043     1.2351055443286896e-01
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R2044     -1
    z[4,3,0]  R2045     1
    z[4,3,0]  R2058     -3.5911047458648682e-01
    z[4,3,0]  R2059     -3.5800606012344360e-01
    z[4,3,0]  R2060     -1.3780531287193298e-01
    z[4,3,0]  R2061     -2.9238942265510559e-01
    z[4,3,0]  R2062     -1.8122249841690063e-01
    z[4,3,0]  R2063     -1.4514103531837463e-01
    z[4,3,0]  R2064     -3.9680501818656921e-01
    z[4,3,0]  R2065     -3.6523446440696716e-01
    z[4,3,0]  R2066     -7.7383734285831451e-02
    z[4,3,0]  R2067     -4.0516808629035950e-01
    z[4,3,0]  R2068     0.942054808139801
    z[4,3,0]  R2069     8.9981865882873535e-01
    z[4,3,0]  R2070     5.8713823556900024e-01
    z[4,3,0]  R2071     6.0660946369171143e-01
    z[4,3,0]  R2072     6.0895085334777832e-01
    z[4,3,0]  R2073     0.65199875831604
    z[4,3,0]  R2074     5.9659922122955322e-01
    z[4,3,0]  R2075     1.1463463306427002e-01
    z[4,3,0]  R2076     5.4364860057830811e-01
    z[4,3,0]  R2077     2.2304007411003113e-01
    z[4,3,0]  R2078     -0.943132221698761
    z[4,3,0]  R2079     -4.1723379492759705e-01
    z[4,3,0]  R2080     3.8019508123397827e-01
    z[4,3,0]  R2081     4.4824984669685364e-01
    z[4,3,0]  R2082     5.2685993909835815e-01
    z[4,3,0]  R2083     9.4603672623634338e-02
    z[4,3,0]  R2084     -2.4945980310440063e-01
    z[4,3,0]  R2085     -2.7539214491844177e-01
    z[4,3,0]  R2086     1.0563543438911438e-01
    z[4,3,0]  R2087     7.7304452657699585e-02
    z[4,3,0]  R2088     -9.3091838061809540e-02
    z[4,3,0]  R2089     -5.1429796218872070e-01
    z[4,3,0]  R2090     6.5010762214660645e-01
    z[4,3,0]  R2091     -1.0805778205394745e-02
    z[4,3,0]  R2092     1.4774626493453979e-01
    z[4,3,0]  R2093     1.1612449586391449e-01
    z[4,3,0]  R2094     3.6412292718887329e-01
    z[4,3,0]  R2095     5.1719751209020615e-02
    z[4,3,0]  R2096     -9.9702635779976845e-03
    z[4,3,0]  R2097     -5.7827834039926529e-02
    z[4,3,0]  R2098     3.3384832739830017e-01
    z[4,3,0]  R2099     -1.3449686765670776e-01
    z[4,3,0]  R2100     -8.7584452703595161e-03
    z[4,3,0]  R2101     4.8221364617347717e-01
    z[4,3,0]  R2102     8.4913492202758789e-02
    z[4,3,0]  R2103     -3.2118913531303406e-01
    z[4,3,0]  R2104     2.1783185005187988e-01
    z[4,3,0]  R2105     2.6415199041366577e-01
    z[4,3,0]  R2106     1.2744180858135223e-01
    z[4,3,0]  R2107     1.4033287763595581e-01
    z[4,3,0]  R2108     -0.0724978893995285
    z[4,3,0]  R2109     -4.6777565032243729e-02
    z[4,3,0]  R2110     -2.4329090118408203e-01
    z[4,3,0]  R2111     4.0715175867080688e-01
    z[4,3,0]  R2112     4.3260368704795837e-01
    z[4,3,0]  R2113     0.0834726095199585
    z[4,3,0]  R2114     2.7277067303657532e-01
    z[4,3,0]  R2115     -1.8065112829208374e-01
    z[4,3,0]  R2116     6.1964333057403564e-01
    z[4,3,0]  R2117     0.50345778465271
    z[4,3,0]  R2118     -4.7514325380325317e-01
    z[4,3,0]  R2119     -7.3216485977172852e-01
    z[4,3,0]  R2120     -6.8617612123489380e-02
    z[4,3,0]  R2121     -1.3920140266418457e-01
    z[4,3,0]  R2122     3.6757206916809082e-01
    z[4,3,0]  R2123     -6.3396227359771729e-01
    z[4,3,0]  R2124     1.8794808536767960e-02
    z[4,3,0]  R2125     5.7484483718872070e-01
    z[4,3,0]  R2126     -0.646687924861908
    z[4,3,0]  R2127     -3.1646620482206345e-02
    z[4,3,0]  R2128     5.3065598011016846e-02
    z[4,3,0]  R2129     -4.2238497734069824e-01
    z[4,3,0]  R2130     1.4733880758285522e-01
    z[4,3,0]  R2131     1.1937868595123291e-01
    z[4,3,0]  R2132     -3.7263453006744385e-01
    z[4,3,0]  R2133     -4.0921968221664429e-01
    z[4,3,0]  R2134     -3.6647709202952683e-04
    z[4,3,0]  R2135     1.9305494427680969e-01
    z[4,3,0]  R2136     5.4454523324966431e-01
    z[4,3,0]  R2137     -0.0954597219824791
    z[4,3,0]  R2138     -1.1888053268194199e-02
    z[4,3,0]  R2139     0.171873077750206
    z[4,3,0]  R2140     1.6375808417797089e-01
    z[4,3,0]  R2141     -3.5804528743028641e-02
    z[4,3,0]  R2142     2.4036203324794769e-01
    z[4,3,0]  R2143     1.1482414603233337e-01
    z[4,3,0]  R2144     2.5157424807548523e-01
    z[4,3,0]  R2145     1.0743453353643417e-01
    z[4,3,0]  R2146     4.7169345617294312e-01
    z[4,3,0]  R2147     0.588336706161499
    z[4,3,0]  R2148     0.281033456325531
    z[4,3,0]  R2149     1.3424830138683319e-01
    z[4,3,0]  R2150     -4.6949443221092224e-01
    z[4,3,0]  R2151     -1.7303615808486938e-01
    z[4,3,0]  R2152     7.3897249996662140e-02
    z[4,3,0]  R2153     5.4487264156341553e-01
    z[4,3,0]  R2154     -0.185902938246727
    z[4,3,0]  R2155     1.8640726804733276e-01
    z[4,3,0]  R2156     2.7073812484741211e-01
    z[4,3,0]  R2157     -4.0726426243782043e-01
    z[4,3,0]  R2158     -3.0519025400280952e-02
    z[4,3,0]  R2159     1.7708288133144379e-01
    z[4,3,0]  R2160     -3.5844030976295471e-01
    z[4,3,0]  R2161     -1.4807590842247009e-01
    z[4,3,0]  R2162     0.0971425324678421
    z[4,3,0]  R2163     4.5451264828443527e-02
    z[4,3,0]  R2164     7.7890351414680481e-02
    z[4,3,0]  R2165     -2.6252783834934235e-02
    z[4,3,0]  R2166     1.1205359548330307e-01
    z[4,3,0]  R2167     8.0074248835444450e-03
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R2046     -1
    z[4,3,1]  R2047     1
    z[4,3,1]  R2058     3.9992593228816986e-02
    z[4,3,1]  R2059     8.8066153228282928e-02
    z[4,3,1]  R2060     -1.4184577763080597e-01
    z[4,3,1]  R2061     1.9708101451396942e-01
    z[4,3,1]  R2062     1.9181822240352631e-01
    z[4,3,1]  R2063     1.7235554754734039e-01
    z[4,3,1]  R2064     1.0931375622749329e-01
    z[4,3,1]  R2065     0.334354430437088
    z[4,3,1]  R2066     1.9728232920169830e-01
    z[4,3,1]  R2067     1.5075589530169964e-02
    z[4,3,1]  R2068     5.3768295794725418e-02
    z[4,3,1]  R2069     2.5043004751205444e-01
    z[4,3,1]  R2070     0.412627249956131
    z[4,3,1]  R2071     -4.2724588513374329e-01
    z[4,3,1]  R2072     -7.0076274871826172e-01
    z[4,3,1]  R2073     -6.1578017473220825e-01
    z[4,3,1]  R2074     -7.4422496557235718e-01
    z[4,3,1]  R2075     -3.5293185710906982e-01
    z[4,3,1]  R2076     -5.6348502635955811e-01
    z[4,3,1]  R2077     -3.0520507693290710e-01
    z[4,3,1]  R2078     2.6929962635040283e-01
    z[4,3,1]  R2079     0.547633171081543
    z[4,3,1]  R2080     -3.4225234389305115e-01
    z[4,3,1]  R2081     -3.7711513042449951e-01
    z[4,3,1]  R2082     5.0179883837699890e-02
    z[4,3,1]  R2083     4.6545788645744324e-02
    z[4,3,1]  R2084     -4.1894862055778503e-01
    z[4,3,1]  R2085     -0.589698076248169
    z[4,3,1]  R2086     -2.8642225265502930e-01
    z[4,3,1]  R2087     0.365046888589859
    z[4,3,1]  R2088     7.0368468761444092e-01
    z[4,3,1]  R2089     6.3230073451995850e-01
    z[4,3,1]  R2090     5.2852157503366470e-02
    z[4,3,1]  R2091     -3.5425764322280884e-01
    z[4,3,1]  R2092     -0.572669506072998
    z[4,3,1]  R2093     3.5959962755441666e-02
    z[4,3,1]  R2094     6.5954573452472687e-02
    z[4,3,1]  R2095     -3.4190490841865540e-01
    z[4,3,1]  R2096     -1.7867447435855865e-01
    z[4,3,1]  R2097     -2.2493988275527954e-01
    z[4,3,1]  R2098     -2.8695452213287354e-01
    z[4,3,1]  R2099     -5.7241046428680420e-01
    z[4,3,1]  R2100     -3.8586992025375366e-01
    z[4,3,1]  R2101     -2.0042078197002411e-01
    z[4,3,1]  R2102     -1.7952386289834976e-02
    z[4,3,1]  R2103     -1.3532178103923798e-01
    z[4,3,1]  R2104     0.408532053232193
    z[4,3,1]  R2105     -0.789068877696991
    z[4,3,1]  R2106     -0.81621253490448
    z[4,3,1]  R2107     -7.4622911214828491e-01
    z[4,3,1]  R2108     -4.9576304852962494e-02
    z[4,3,1]  R2109     7.2479605674743652e-02
    z[4,3,1]  R2110     2.3105706274509430e-01
    z[4,3,1]  R2111     -2.5389257073402405e-01
    z[4,3,1]  R2112     -4.3938377499580383e-01
    z[4,3,1]  R2113     -3.6427742242813110e-01
    z[4,3,1]  R2114     -2.4248623847961426e-01
    z[4,3,1]  R2115     -4.6545240283012390e-01
    z[4,3,1]  R2116     -7.4089878797531128e-01
    z[4,3,1]  R2117     -7.9328811168670654e-01
    z[4,3,1]  R2118     5.8730334043502808e-01
    z[4,3,1]  R2119     -1.2613086402416229e-01
    z[4,3,1]  R2120     6.6275602579116821e-01
    z[4,3,1]  R2121     -4.1508737206459045e-01
    z[4,3,1]  R2122     3.2214462757110596e-01
    z[4,3,1]  R2123     -5.2270042896270752e-01
    z[4,3,1]  R2124     -2.3105403780937195e-01
    z[4,3,1]  R2125     6.9843542575836182e-01
    z[4,3,1]  R2126     -1.9056378304958344e-01
    z[4,3,1]  R2127     2.1849560737609863e-01
    z[4,3,1]  R2128     1.7878186702728271e-01
    z[4,3,1]  R2129     2.7323865890502930e-01
    z[4,3,1]  R2130     1.0493151843547821e-01
    z[4,3,1]  R2131     -3.5202798247337341e-01
    z[4,3,1]  R2132     1.1936495453119278e-01
    z[4,3,1]  R2133     1.4401400089263916e-01
    z[4,3,1]  R2134     -1.7586109042167664e-01
    z[4,3,1]  R2135     2.0621287822723389e-01
    z[4,3,1]  R2136     1.2347144633531570e-01
    z[4,3,1]  R2137     -1.7415875196456909e-01
    z[4,3,1]  R2138     0.224227637052536
    z[4,3,1]  R2139     -1.6536530852317810e-01
    z[4,3,1]  R2140     2.7318241074681282e-02
    z[4,3,1]  R2141     -5.0901472568511963e-01
    z[4,3,1]  R2142     0.830104649066925
    z[4,3,1]  R2143     -7.4446122162044048e-03
    z[4,3,1]  R2144     5.8689326047897339e-01
    z[4,3,1]  R2145     -1.6676047444343567e-01
    z[4,3,1]  R2146     -1.4324536919593811e-01
    z[4,3,1]  R2147     -1.6525343060493469e-01
    z[4,3,1]  R2148     6.4252667129039764e-02
    z[4,3,1]  R2149     -3.2476228475570679e-01
    z[4,3,1]  R2150     -1.9919112324714661e-01
    z[4,3,1]  R2151     5.5956762284040451e-02
    z[4,3,1]  R2152     -4.8003333806991577e-01
    z[4,3,1]  R2153     -1.9607719033956528e-02
    z[4,3,1]  R2154     1.0768979787826538e-01
    z[4,3,1]  R2155     1.4857201278209686e-01
    z[4,3,1]  R2156     -1.0986895859241486e-01
    z[4,3,1]  R2157     -3.8663852214813232e-01
    z[4,3,1]  R2158     -2.2436386346817017e-01
    z[4,3,1]  R2159     1.0586047172546387e-01
    z[4,3,1]  R2160     8.6570112034678459e-03
    z[4,3,1]  R2161     6.6662162542343140e-02
    z[4,3,1]  R2162     2.4361225962638855e-01
    z[4,3,1]  R2163     -1.4660495519638062e-01
    z[4,3,1]  R2164     -3.5686942934989929e-01
    z[4,3,1]  R2165     -4.2440363764762878e-01
    z[4,3,1]  R2166     -2.1864071488380432e-01
    z[4,3,1]  R2167     -0.318697065114975
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R2048     -1
    z[4,3,2]  R2049     1
    z[4,3,2]  R2058     7.0885759592056274e-01
    z[4,3,2]  R2059     7.2918081283569336e-01
    z[4,3,2]  R2060     0.774948239326477
    z[4,3,2]  R2061     8.6175012588500977e-01
    z[4,3,2]  R2062     -0.421764612197876
    z[4,3,2]  R2063     -0.676142156124115
    z[4,3,2]  R2064     4.2299043387174606e-02
    z[4,3,2]  R2065     1.0496312379837036e-01
    z[4,3,2]  R2066     -4.2408052086830139e-01
    z[4,3,2]  R2067     4.8272809386253357e-01
    z[4,3,2]  R2068     7.6136313378810883e-02
    z[4,3,2]  R2069     -1.1208809167146683e-01
    z[4,3,2]  R2070     -0.0673513412475586
    z[4,3,2]  R2071     -3.7408652901649475e-01
    z[4,3,2]  R2072     -1.6330179572105408e-01
    z[4,3,2]  R2073     -7.6653786003589630e-02
    z[4,3,2]  R2074     -2.0851986110210419e-01
    z[4,3,2]  R2075     -5.0066363811492920e-01
    z[4,3,2]  R2076     -1.8591651320457458e-01
    z[4,3,2]  R2077     -5.1453369855880737e-01
    z[4,3,2]  R2078     -1.3060493767261505e-01
    z[4,3,2]  R2079     -8.7851323187351227e-02
    z[4,3,2]  R2080     -0.742438793182373
    z[4,3,2]  R2081     -4.8063719272613525e-01
    z[4,3,2]  R2082     -6.5481591224670410e-01
    z[4,3,2]  R2083     -3.4209641814231873e-01
    z[4,3,2]  R2084     -7.1385228633880615e-01
    z[4,3,2]  R2085     -6.4999693632125854e-01
    z[4,3,2]  R2086     -0.809843122959137
    z[4,3,2]  R2087     -6.0245621204376221e-01
    z[4,3,2]  R2088     4.5894297957420349e-01
    z[4,3,2]  R2089     1.1132667958736420e-01
    z[4,3,2]  R2090     -6.6455513238906860e-01
    z[4,3,2]  R2091     -5.2812069654464722e-01
    z[4,3,2]  R2092     -5.6795650720596313e-01
    z[4,3,2]  R2093     -6.9453239440917969e-01
    z[4,3,2]  R2094     -0.555451512336731
    z[4,3,2]  R2095     -7.9939246177673340e-01
    z[4,3,2]  R2096     -6.5235203504562378e-01
    z[4,3,2]  R2097     -6.0514295101165771e-01
    z[4,3,2]  R2098     -7.2713285684585571e-01
    z[4,3,2]  R2099     -7.5922089815139771e-01
    z[4,3,2]  R2100     -5.8087509870529175e-01
    z[4,3,2]  R2101     -7.8284674882888794e-01
    z[4,3,2]  R2102     -7.4088609218597412e-01
    z[4,3,2]  R2103     -0.635337233543396
    z[4,3,2]  R2104     -3.9858633279800415e-01
    z[4,3,2]  R2105     4.3616119772195816e-02
    z[4,3,2]  R2106     1.5644568204879761e-01
    z[4,3,2]  R2107     -9.8282612860202789e-02
    z[4,3,2]  R2108     7.7604496479034424e-01
    z[4,3,2]  R2109     6.0417407751083374e-01
    z[4,3,2]  R2110     5.0335592031478882e-01
    z[4,3,2]  R2111     -6.9426339864730835e-01
    z[4,3,2]  R2112     -7.7314120531082153e-01
    z[4,3,2]  R2113     -7.2934788465499878e-01
    z[4,3,2]  R2114     -8.4491407871246338e-01
    z[4,3,2]  R2115     -8.0140662193298340e-01
    z[4,3,2]  R2116     2.1349819377064705e-02
    z[4,3,2]  R2117     -1.2619367334991693e-03
    z[4,3,2]  R2118     -2.8861820697784424e-01
    z[4,3,2]  R2119     2.0243752002716064e-01
    z[4,3,2]  R2120     1.3058094680309296e-01
    z[4,3,2]  R2121     -4.0662899613380432e-01
    z[4,3,2]  R2122     -2.4025954306125641e-01
    z[4,3,2]  R2123     -4.4705423712730408e-01
    z[4,3,2]  R2124     -3.4929844737052917e-01
    z[4,3,2]  R2125     -2.6159957051277161e-01
    z[4,3,2]  R2126     -3.8386201858520508e-01
    z[4,3,2]  R2127     -1.2975965440273285e-01
    z[4,3,2]  R2128     6.3734084367752075e-01
    z[4,3,2]  R2129     -1.9241769611835480e-01
    z[4,3,2]  R2130     -8.8255876302719116e-01
    z[4,3,2]  R2131     -5.4816991090774536e-01
    z[4,3,2]  R2132     -6.3943284749984741e-01
    z[4,3,2]  R2133     -4.0944692492485046e-01
    z[4,3,2]  R2134     -6.5266954898834229e-01
    z[4,3,2]  R2135     -1.9232214987277985e-01
    z[4,3,2]  R2136     -5.2635037899017334e-01
    z[4,3,2]  R2137     -6.7669701576232910e-01
    z[4,3,2]  R2138     -6.8888491392135620e-01
    z[4,3,2]  R2139     -0.37347611784935
    z[4,3,2]  R2140     -0.797686755657196
    z[4,3,2]  R2141     -1.9151577353477478e-01
    z[4,3,2]  R2142     -5.8459974825382233e-02
    z[4,3,2]  R2143     1.5644293278455734e-02
    z[4,3,2]  R2144     -3.7999540567398071e-01
    z[4,3,2]  R2145     -2.8968313336372375e-01
    z[4,3,2]  R2146     2.9470187425613403e-01
    z[4,3,2]  R2147     -2.9661780595779419e-01
    z[4,3,2]  R2148     -5.4275822639465332e-01
    z[4,3,2]  R2149     -3.4621232748031616e-01
    z[4,3,2]  R2150     -2.6808315515518188e-01
    z[4,3,2]  R2151     -1.0409136116504669e-01
    z[4,3,2]  R2152     -4.9149307608604431e-01
    z[4,3,2]  R2153     -4.5655825734138489e-01
    z[4,3,2]  R2154     -4.3433123826980591e-01
    z[4,3,2]  R2155     -4.2819681763648987e-01
    z[4,3,2]  R2156     -8.9572280645370483e-02
    z[4,3,2]  R2157     -1.3207964599132538e-01
    z[4,3,2]  R2158     -4.7002637386322021e-01
    z[4,3,2]  R2159     -2.5709491968154907e-01
    z[4,3,2]  R2160     -1.9683119654655457e-01
    z[4,3,2]  R2161     -3.2945030927658081e-01
    z[4,3,2]  R2162     -4.3652319908142090e-01
    z[4,3,2]  R2163     -6.7894309759140015e-01
    z[4,3,2]  R2164     -4.7322505712509155e-01
    z[4,3,2]  R2165     -4.1342398524284363e-01
    z[4,3,2]  R2166     9.5625430345535278e-02
    z[4,3,2]  R2167     -1.9718685746192932e-01
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R2050     -1
    z[4,3,3]  R2051     1
    z[4,3,3]  R2058     1.5453018248081207e-01
    z[4,3,3]  R2059     2.4318028986454010e-01
    z[4,3,3]  R2060     -6.6407345235347748e-02
    z[4,3,3]  R2061     3.7617892958223820e-03
    z[4,3,3]  R2062     7.7589273452758789e-01
    z[4,3,3]  R2063     4.9217936396598816e-01
    z[4,3,3]  R2064     8.0812788009643555e-01
    z[4,3,3]  R2065     9.9210254848003387e-02
    z[4,3,3]  R2066     2.9624202847480774e-01
    z[4,3,3]  R2067     -5.8686983585357666e-01
    z[4,3,3]  R2068     2.3793120682239532e-01
    z[4,3,3]  R2069     1.7997060716152191e-01
    z[4,3,3]  R2070     -2.1408474445343018e-01
    z[4,3,3]  R2071     -3.9325478672981262e-01
    z[4,3,3]  R2072     -2.1021410822868347e-01
    z[4,3,3]  R2073     -3.5917416214942932e-01
    z[4,3,3]  R2074     1.9981622695922852e-02
    z[4,3,3]  R2075     -5.4983055591583252e-01
    z[4,3,3]  R2076     1.9537252373993397e-03
    z[4,3,3]  R2077     -5.0493568181991577e-01
    z[4,3,3]  R2078     2.7512183412909508e-02
    z[4,3,3]  R2079     5.0766932964324951e-01
    z[4,3,3]  R2080     -2.9457315802574158e-01
    z[4,3,3]  R2081     -4.6839483082294464e-02
    z[4,3,3]  R2082     -4.3036738038063049e-01
    z[4,3,3]  R2083     -0.267819881439209
    z[4,3,3]  R2084     -3.9078226685523987e-01
    z[4,3,3]  R2085     -2.8767085075378418e-01
    z[4,3,3]  R2086     -3.8902035355567932e-01
    z[4,3,3]  R2087     -0.190802201628685
    z[4,3,3]  R2088     5.1662659645080566e-01
    z[4,3,3]  R2089     1.0520192235708237e-01
    z[4,3,3]  R2090     -2.2982361912727356e-01
    z[4,3,3]  R2091     -5.8106422424316406e-01
    z[4,3,3]  R2092     -3.6560976505279541e-01
    z[4,3,3]  R2093     -6.9852042198181152e-01
    z[4,3,3]  R2094     -3.0261768028140068e-02
    z[4,3,3]  R2095     -6.6269993782043457e-02
    z[4,3,3]  R2096     -6.4941161870956421e-01
    z[4,3,3]  R2097     8.2603186368942261e-02
    z[4,3,3]  R2098     -2.2602368891239166e-01
    z[4,3,3]  R2099     -1.2361246347427368e-01
    z[4,3,3]  R2100     -5.3486543893814087e-01
    z[4,3,3]  R2101     -1.1051447689533234e-01
    z[4,3,3]  R2102     -6.4729940891265869e-01
    z[4,3,3]  R2103     -3.4381550550460815e-01
    z[4,3,3]  R2104     -3.5488963127136230e-01
    z[4,3,3]  R2105     0.317862868309021
    z[4,3,3]  R2106     1.6077440977096558e-01
    z[4,3,3]  R2107     4.6951431035995483e-01
    z[4,3,3]  R2108     4.6331736445426941e-01
    z[4,3,3]  R2109     5.4184055328369141e-01
    z[4,3,3]  R2110     2.7046254277229309e-01
    z[4,3,3]  R2111     -2.1978422999382019e-01
    z[4,3,3]  R2112     -8.0081552267074585e-02
    z[4,3,3]  R2113     -1.6590537130832672e-01
    z[4,3,3]  R2114     -1.3935063779354095e-01
    z[4,3,3]  R2115     -2.6957049965858459e-01
    z[4,3,3]  R2116     2.0872354507446289e-02
    z[4,3,3]  R2117     -1.9338840246200562e-01
    z[4,3,3]  R2118     4.6935191750526428e-01
    z[4,3,3]  R2119     1.7970761656761169e-01
    z[4,3,3]  R2120     1.6824183985590935e-02
    z[4,3,3]  R2121     -5.7796674966812134e-01
    z[4,3,3]  R2122     -6.2334847450256348e-01
    z[4,3,3]  R2123     -1.8919529020786285e-01
    z[4,3,3]  R2124     -5.4911768436431885e-01
    z[4,3,3]  R2125     -1.9732019305229187e-01
    z[4,3,3]  R2126     -3.9041116833686829e-01
    z[4,3,3]  R2127     -5.4226309061050415e-01
    z[4,3,3]  R2128     4.0418922901153564e-02
    z[4,3,3]  R2129     -7.1027135848999023e-01
    z[4,3,3]  R2130     -1.6832639276981354e-01
    z[4,3,3]  R2131     -3.5620700567960739e-02
    z[4,3,3]  R2132     -6.4964437484741211e-01
    z[4,3,3]  R2133     -6.6607069969177246e-01
    z[4,3,3]  R2134     -1.9485194236040115e-02
    z[4,3,3]  R2135     -6.3764536380767822e-01
    z[4,3,3]  R2136     -7.3052115738391876e-02
    z[4,3,3]  R2137     -1.2792097032070160e-01
    z[4,3,3]  R2138     -6.7898309230804443e-01
    z[4,3,3]  R2139     -6.8302422761917114e-01
    z[4,3,3]  R2140     -1.9481922686100006e-01
    z[4,3,3]  R2141     -7.0268255472183228e-01
    z[4,3,3]  R2142     -3.1143969297409058e-01
    z[4,3,3]  R2143     -6.5013659000396729e-01
    z[4,3,3]  R2144     -6.2126046419143677e-01
    z[4,3,3]  R2145     -6.1172151565551758e-01
    z[4,3,3]  R2146     -0.515038788318634
    z[4,3,3]  R2147     -4.8638768494129181e-02
    z[4,3,3]  R2148     -7.3414909839630127e-01
    z[4,3,3]  R2149     -6.8878930807113647e-01
    z[4,3,3]  R2150     -6.7565697431564331e-01
    z[4,3,3]  R2151     -6.7065227031707764e-01
    z[4,3,3]  R2152     -6.6765159368515015e-01
    z[4,3,3]  R2153     -7.4274338781833649e-02
    z[4,3,3]  R2154     -6.3615453243255615e-01
    z[4,3,3]  R2155     -6.1579936742782593e-01
    z[4,3,3]  R2156     -6.6821444034576416e-01
    z[4,3,3]  R2157     -0.645698070526123
    z[4,3,3]  R2158     -7.2707247734069824e-01
    z[4,3,3]  R2159     -7.0280331373214722e-01
    z[4,3,3]  R2160     -7.2421997785568237e-01
    z[4,3,3]  R2161     -6.5282362699508667e-01
    z[4,3,3]  R2162     -6.3655519485473633e-01
    z[4,3,3]  R2163     -4.8466604202985764e-02
    z[4,3,3]  R2164     7.0134699344635010e-03
    z[4,3,3]  R2165     1.9812983274459839e-01
    z[4,3,3]  R2166     -5.5316168069839478e-01
    z[4,3,3]  R2167     -6.0439020395278931e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R2052     -1
    z[4,3,4]  R2053     1
    z[4,3,4]  R2058     0.584718644618988
    z[4,3,4]  R2059     1.1929895728826523e-01
    z[4,3,4]  R2060     4.4568312168121338e-01
    z[4,3,4]  R2061     -1.9457225501537323e-01
    z[4,3,4]  R2062     -2.3900421336293221e-02
    z[4,3,4]  R2063     -3.1577959656715393e-01
    z[4,3,4]  R2064     -3.5803741216659546e-01
    z[4,3,4]  R2065     6.9361424446105957e-01
    z[4,3,4]  R2066     -0.651825487613678
    z[4,3,4]  R2067     1.3738542795181274e-01
    z[4,3,4]  R2068     -1.3454273343086243e-01
    z[4,3,4]  R2069     1.5022955834865570e-01
    z[4,3,4]  R2070     0.452536016702652
    z[4,3,4]  R2071     3.3214700222015381e-01
    z[4,3,4]  R2072     2.2784835100173950e-01
    z[4,3,4]  R2073     -1.3697463274002075e-01
    z[4,3,4]  R2074     1.7680658400058746e-01
    z[4,3,4]  R2075     -4.9967506527900696e-01
    z[4,3,4]  R2076     2.7726349234580994e-01
    z[4,3,4]  R2077     -4.2929565906524658e-01
    z[4,3,4]  R2078     -7.9094909131526947e-02
    z[4,3,4]  R2079     8.4954008460044861e-02
    z[4,3,4]  R2080     -3.1500864028930664e-01
    z[4,3,4]  R2081     -4.3252453207969666e-01
    z[4,3,4]  R2082     -8.6337188258767128e-03
    z[4,3,4]  R2083     -6.2996000051498413e-01
    z[4,3,4]  R2084     8.6528457701206207e-02
    z[4,3,4]  R2085     -2.3535829782485962e-01
    z[4,3,4]  R2086     2.9225587844848633e-01
    z[4,3,4]  R2087     -4.7899162769317627e-01
    z[4,3,4]  R2088     5.1167141646146774e-02
    z[4,3,4]  R2089     2.7436983585357666e-01
    z[4,3,4]  R2090     -1.1434942483901978e-01
    z[4,3,4]  R2091     -4.6427333354949951e-01
    z[4,3,4]  R2092     9.7543504089117050e-03
    z[4,3,4]  R2093     3.3553630113601685e-02
    z[4,3,4]  R2094     -4.8827984929084778e-01
    z[4,3,4]  R2095     9.5876671373844147e-02
    z[4,3,4]  R2096     -1.2067833542823792e-01
    z[4,3,4]  R2097     -4.4259798526763916e-01
    z[4,3,4]  R2098     -4.3967342376708984e-01
    z[4,3,4]  R2099     -1.3392937183380127e-01
    z[4,3,4]  R2100     -4.1266137361526489e-01
    z[4,3,4]  R2101     2.2943212091922760e-01
    z[4,3,4]  R2102     -1.1504572629928589e-01
    z[4,3,4]  R2103     -3.9065372943878174e-01
    z[4,3,4]  R2104     -6.8254613876342773e-01
    z[4,3,4]  R2105     -3.9675071835517883e-01
    z[4,3,4]  R2106     -4.9660202860832214e-01
    z[4,3,4]  R2107     -3.6722466349601746e-01
    z[4,3,4]  R2108     4.3865670450031757e-03
    z[4,3,4]  R2109     -4.6118754148483276e-01
    z[4,3,4]  R2110     1.1841346323490143e-01
    z[4,3,4]  R2111     -4.7443667054176331e-01
    z[4,3,4]  R2112     -1.2131082266569138e-01
    z[4,3,4]  R2113     -4.9943828582763672e-01
    z[4,3,4]  R2114     6.9983549416065216e-02
    z[4,3,4]  R2115     -0.00828845240175724
    z[4,3,4]  R2116     -1.6975876688957214e-01
    z[4,3,4]  R2117     2.5520551204681396e-01
    z[4,3,4]  R2118     8.3239749073982239e-02
    z[4,3,4]  R2119     5.7291269302368164e-01
    z[4,3,4]  R2120     0.691063642501831
    z[4,3,4]  R2121     -3.2358980178833008e-01
    z[4,3,4]  R2122     -2.2980056703090668e-01
    z[4,3,4]  R2123     -2.0617288351058960e-01
    z[4,3,4]  R2124     6.4487653970718384e-01
    z[4,3,4]  R2125     -1.8258714675903320e-01
    z[4,3,4]  R2126     -2.4823729693889618e-01
    z[4,3,4]  R2127     -5.5757266283035278e-01
    z[4,3,4]  R2128     1.7272646725177765e-01
    z[4,3,4]  R2129     -4.4808611273765564e-01
    z[4,3,4]  R2130     -0.305568128824234
    z[4,3,4]  R2131     -7.2267204523086548e-01
    z[4,3,4]  R2132     -6.1701640486717224e-02
    z[4,3,4]  R2133     -2.0890070497989655e-01
    z[4,3,4]  R2134     -4.6491956710815430e-01
    z[4,3,4]  R2135     -5.3467798233032227e-01
    z[4,3,4]  R2136     -4.5001673698425293e-01
    z[4,3,4]  R2137     -5.4272848367691040e-01
    z[4,3,4]  R2138     -0.089384526014328
    z[4,3,4]  R2139     -5.0186169147491455e-01
    z[4,3,4]  R2140     -4.6230247616767883e-01
    z[4,3,4]  R2141     -2.9163831472396851e-01
    z[4,3,4]  R2142     -3.0278894305229187e-01
    z[4,3,4]  R2143     -6.4142870903015137e-01
    z[4,3,4]  R2144     -2.3578768968582153e-01
    z[4,3,4]  R2145     -3.8169345259666443e-01
    z[4,3,4]  R2146     5.5134284496307373e-01
    z[4,3,4]  R2147     -6.7655169963836670e-01
    z[4,3,4]  R2148     -0.108512744307518
    z[4,3,4]  R2149     -4.1247400641441345e-01
    z[4,3,4]  R2150     -4.0192928910255432e-01
    z[4,3,4]  R2151     -6.9580215215682983e-01
    z[4,3,4]  R2152     -1.1318396031856537e-01
    z[4,3,4]  R2153     -6.7420035600662231e-01
    z[4,3,4]  R2154     -2.3520049452781677e-01
    z[4,3,4]  R2155     -2.8921106457710266e-01
    z[4,3,4]  R2156     -3.5419189929962158e-01
    z[4,3,4]  R2157     -3.9894768595695496e-01
    z[4,3,4]  R2158     -3.5633343458175659e-01
    z[4,3,4]  R2159     -5.8956694602966309e-01
    z[4,3,4]  R2160     -5.1626938581466675e-01
    z[4,3,4]  R2161     -4.4307643175125122e-01
    z[4,3,4]  R2162     -2.6427084207534790e-01
    z[4,3,4]  R2163     -6.7825454473495483e-01
    z[4,3,4]  R2164     -7.0003032684326172e-01
    z[4,3,4]  R2165     -5.7839977741241455e-01
    z[4,3,4]  R2166     4.3254518508911133e-01
    z[4,3,4]  R2167     6.2546718120574951e-01
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R2054     -1
    z[4,3,5]  R2055     1
    z[4,3,5]  R2058     1.1528528295457363e-02
    z[4,3,5]  R2059     0.46016725897789
    z[4,3,5]  R2060     3.6443573236465454e-01
    z[4,3,5]  R2061     -1.1830856651067734e-01
    z[4,3,5]  R2062     2.3036555945873260e-01
    z[4,3,5]  R2063     2.3484787344932556e-01
    z[4,3,5]  R2064     1.8928836286067963e-01
    z[4,3,5]  R2065     3.3975234627723694e-01
    z[4,3,5]  R2066     2.8387647867202759e-01
    z[4,3,5]  R2067     -2.4164432287216187e-01
    z[4,3,5]  R2068     2.3776585236191750e-02
    z[4,3,5]  R2069     -2.4114778637886047e-01
    z[4,3,5]  R2070     1.0148690640926361e-01
    z[4,3,5]  R2071     3.1827643513679504e-02
    z[4,3,5]  R2072     -1.2022651731967926e-01
    z[4,3,5]  R2073     -4.6280834823846817e-02
    z[4,3,5]  R2074     -3.2995335757732391e-02
    z[4,3,5]  R2075     -2.3742890357971191e-01
    z[4,3,5]  R2076     -2.3853017017245293e-02
    z[4,3,5]  R2077     -3.4963092207908630e-01
    z[4,3,5]  R2078     1.0461068153381348e-01
    z[4,3,5]  R2079     -4.8696655035018921e-01
    z[4,3,5]  R2080     3.3102143555879593e-02
    z[4,3,5]  R2081     -3.9775168895721436e-01
    z[4,3,5]  R2082     -3.0349004268646240e-01
    z[4,3,5]  R2083     -6.0651499032974243e-01
    z[4,3,5]  R2084     -3.0408149957656860e-01
    z[4,3,5]  R2085     7.3091499507427216e-02
    z[4,3,5]  R2086     5.0470467656850815e-02
    z[4,3,5]  R2087     -4.5190271735191345e-01
    z[4,3,5]  R2088     -6.0405898839235306e-02
    z[4,3,5]  R2089     -4.4078135490417480e-01
    z[4,3,5]  R2090     -2.4801802635192871e-01
    z[4,3,5]  R2091     1.0184463113546371e-01
    z[4,3,5]  R2092     -3.9927187561988831e-01
    z[4,3,5]  R2093     4.3250724673271179e-02
    z[4,3,5]  R2094     -4.8846244812011719e-01
    z[4,3,5]  R2095     -4.4637325406074524e-01
    z[4,3,5]  R2096     -1.9911728799343109e-01
    z[4,3,5]  R2097     -5.6191688776016235e-01
    z[4,3,5]  R2098     -1.7829376459121704e-01
    z[4,3,5]  R2099     -1.8528230488300323e-01
    z[4,3,5]  R2100     2.2916388511657715e-01
    z[4,3,5]  R2101     2.1229531615972519e-02
    z[4,3,5]  R2102     -2.6011077687144279e-02
    z[4,3,5]  R2103     -4.5171543955802917e-01
    z[4,3,5]  R2104     -1.7164134979248047e-01
    z[4,3,5]  R2105     2.0519137382507324e-01
    z[4,3,5]  R2106     8.1515289843082428e-02
    z[4,3,5]  R2107     -2.0793452858924866e-01
    z[4,3,5]  R2108     -1.2052126228809357e-01
    z[4,3,5]  R2109     2.6374953985214233e-01
    z[4,3,5]  R2110     5.2855336666107178e-01
    z[4,3,5]  R2111     -1.2794802896678448e-02
    z[4,3,5]  R2112     2.9707642272114754e-02
    z[4,3,5]  R2113     -1.0103664547204971e-01
    z[4,3,5]  R2114     -1.8102893233299255e-01
    z[4,3,5]  R2115     -1.5770480036735535e-01
    z[4,3,5]  R2116     -1.4267264306545258e-01
    z[4,3,5]  R2117     -1.1971701681613922e-01
    z[4,3,5]  R2118     -3.1781506538391113e-01
    z[4,3,5]  R2119     -1.6603751480579376e-01
    z[4,3,5]  R2120     -1.8935577571392059e-01
    z[4,3,5]  R2121     -8.9161597192287445e-02
    z[4,3,5]  R2122     0.506896436214447
    z[4,3,5]  R2123     2.1081382036209106e-01
    z[4,3,5]  R2124     -2.1602389216423035e-01
    z[4,3,5]  R2125     1.9781798124313354e-01
    z[4,3,5]  R2126     -1.3992623426020145e-02
    z[4,3,5]  R2127     5.7354468107223511e-01
    z[4,3,5]  R2128     2.5632017850875854e-01
    z[4,3,5]  R2129     -2.4334864690899849e-02
    z[4,3,5]  R2130     -1.5140607953071594e-01
    z[4,3,5]  R2131     -4.8199485987424850e-02
    z[4,3,5]  R2132     -8.7031446397304535e-02
    z[4,3,5]  R2133     -3.0716273188591003e-01
    z[4,3,5]  R2134     2.5415403768420219e-02
    z[4,3,5]  R2135     4.2185807228088379e-01
    z[4,3,5]  R2136     -3.4934419393539429e-01
    z[4,3,5]  R2137     4.1864994168281555e-01
    z[4,3,5]  R2138     -3.0094233807176352e-04
    z[4,3,5]  R2139     -2.9137805104255676e-01
    z[4,3,5]  R2140     -1.2672282755374908e-02
    z[4,3,5]  R2141     -3.3931252360343933e-01
    z[4,3,5]  R2142     3.4515149891376495e-02
    z[4,3,5]  R2143     2.1613213419914246e-01
    z[4,3,5]  R2144     -5.9224888682365417e-02
    z[4,3,5]  R2145     -1.7145846784114838e-01
    z[4,3,5]  R2146     -2.2228464484214783e-01
    z[4,3,5]  R2147     -2.1431162953376770e-01
    z[4,3,5]  R2148     -2.3515079915523529e-01
    z[4,3,5]  R2149     -9.3471392989158630e-02
    z[4,3,5]  R2150     1.8666934967041016e-01
    z[4,3,5]  R2151     1.1278792470693588e-01
    z[4,3,5]  R2152     2.7752861380577087e-02
    z[4,3,5]  R2153     -1.7858222126960754e-01
    z[4,3,5]  R2154     4.7819722443819046e-02
    z[4,3,5]  R2155     -4.0153592824935913e-01
    z[4,3,5]  R2156     6.4882233738899231e-02
    z[4,3,5]  R2157     -2.0185214281082153e-01
    z[4,3,5]  R2158     -1.3158781826496124e-01
    z[4,3,5]  R2159     -1.5511341392993927e-01
    z[4,3,5]  R2160     -1.7066916823387146e-01
    z[4,3,5]  R2161     4.7792237997055054e-01
    z[4,3,5]  R2162     0.279199481010437
    z[4,3,5]  R2163     2.1251642704010010e-01
    z[4,3,5]  R2164     1.4224325120449066e-01
    z[4,3,5]  R2165     -4.1929554939270020e-01
    z[4,3,5]  R2166     -6.6018944978713989e-01
    z[4,3,5]  R2167     -3.1133770942687988e-02
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R2056     -1
    z[4,3,6]  R2057     1
    z[4,3,6]  R2058     -3.2446052879095078e-02
    z[4,3,6]  R2059     -2.1736724674701691e-01
    z[4,3,6]  R2060     -1.5648598968982697e-01
    z[4,3,6]  R2061     2.8492954373359680e-01
    z[4,3,6]  R2062     3.1117478013038635e-01
    z[4,3,6]  R2063     -3.0813741683959961e-01
    z[4,3,6]  R2064     -1.0823823511600494e-01
    z[4,3,6]  R2065     -3.7070021033287048e-01
    z[4,3,6]  R2066     4.2664456367492676e-01
    z[4,3,6]  R2067     4.2532593011856079e-01
    z[4,3,6]  R2068     -1.6901694238185883e-01
    z[4,3,6]  R2069     -4.4010091572999954e-02
    z[4,3,6]  R2070     4.6856218576431274e-01
    z[4,3,6]  R2071     2.0871374011039734e-01
    z[4,3,6]  R2072     2.9726946726441383e-02
    z[4,3,6]  R2073     1.9981640577316284e-01
    z[4,3,6]  R2074     1.1819269508123398e-01
    z[4,3,6]  R2075     -5.7206183671951294e-02
    z[4,3,6]  R2076     5.2432626485824585e-01
    z[4,3,6]  R2077     1.7567428946495056e-01
    z[4,3,6]  R2078     5.4454866796731949e-02
    z[4,3,6]  R2079     1.2733514606952667e-01
    z[4,3,6]  R2080     2.4166754155885428e-04
    z[4,3,6]  R2081     -2.7993968129158020e-01
    z[4,3,6]  R2082     1.1713202297687531e-01
    z[4,3,6]  R2083     -1.8819177150726318e-01
    z[4,3,6]  R2084     -1.8090275116264820e-03
    z[4,3,6]  R2085     1.0212234407663345e-01
    z[4,3,6]  R2086     -1.0798142850399017e-01
    z[4,3,6]  R2087     1.6660369932651520e-01
    z[4,3,6]  R2088     -1.1118955910205841e-01
    z[4,3,6]  R2089     2.0655590295791626e-01
    z[4,3,6]  R2090     -7.4333444237709045e-02
    z[4,3,6]  R2091     1.7864930629730225e-01
    z[4,3,6]  R2092     -1.8564037978649139e-01
    z[4,3,6]  R2093     -1.0917651653289795e-01
    z[4,3,6]  R2094     2.7678442001342773e-01
    z[4,3,6]  R2095     1.6901065409183502e-01
    z[4,3,6]  R2096     2.5781095027923584e-01
    z[4,3,6]  R2097     2.4777625501155853e-01
    z[4,3,6]  R2098     -3.5946812480688095e-02
    z[4,3,6]  R2099     -1.0145907104015350e-01
    z[4,3,6]  R2100     6.8740755319595337e-02
    z[4,3,6]  R2101     -2.2169624269008636e-01
    z[4,3,6]  R2102     1.0318201780319214e-01
    z[4,3,6]  R2103     2.4264785461127758e-03
    z[4,3,6]  R2104     7.4183098971843719e-02
    z[4,3,6]  R2105     -7.1695089340209961e-02
    z[4,3,6]  R2106     1.1821021884679794e-01
    z[4,3,6]  R2107     1.2351055443286896e-01
    z[4,3,6]  R2108     0.401039719581604
    z[4,3,6]  R2109     2.2733974456787109e-01
    z[4,3,6]  R2110     5.1721811294555664e-01
    z[4,3,6]  R2111     1.1918663978576660e-01
    z[4,3,6]  R2112     6.0617448762059212e-03
    z[4,3,6]  R2113     2.0301340520381927e-01
    z[4,3,6]  R2114     3.0956250429153442e-01
    z[4,3,6]  R2115     1.0420594364404678e-01
    z[4,3,6]  R2116     1.3056075572967529e-01
    z[4,3,6]  R2117     -1.9015483558177948e-02
    z[4,3,6]  R2118     -1.3336718082427979e-01
    z[4,3,6]  R2119     -1.3766746222972870e-01
    z[4,3,6]  R2120     -1.5901888906955719e-01
    z[4,3,6]  R2121     -4.4302663207054138e-01
    z[4,3,6]  R2122     7.1227133274078369e-02
    z[4,3,6]  R2123     -4.7686256468296051e-02
    z[4,3,6]  R2124     2.4533452093601227e-01
    z[4,3,6]  R2125     -4.3609503656625748e-02
    z[4,3,6]  R2126     4.2882591485977173e-01
    z[4,3,6]  R2127     -2.3034913465380669e-02
    z[4,3,6]  R2128     -6.7959511280059814e-01
    z[4,3,6]  R2129     0.063626728951931
    z[4,3,6]  R2130     2.0914423465728760e-01
    z[4,3,6]  R2131     -1.8838226795196533e-01
    z[4,3,6]  R2132     -6.7836657166481018e-02
    z[4,3,6]  R2133     2.5002774596214294e-01
    z[4,3,6]  R2134     5.7089352607727051e-01
    z[4,3,6]  R2135     1.1305678635835648e-01
    z[4,3,6]  R2136     2.8510963916778564e-01
    z[4,3,6]  R2137     1.2826339900493622e-01
    z[4,3,6]  R2138     7.7527396380901337e-02
    z[4,3,6]  R2139     -1.8467016518115997e-02
    z[4,3,6]  R2140     -2.9033464193344116e-01
    z[4,3,6]  R2141     -9.4842657446861267e-02
    z[4,3,6]  R2142     2.4467891454696655e-01
    z[4,3,6]  R2143     3.2510584592819214e-01
    z[4,3,6]  R2144     -5.2937213331460953e-02
    z[4,3,6]  R2145     5.7222491502761841e-01
    z[4,3,6]  R2146     2.2689729928970337e-01
    z[4,3,6]  R2147     1.8042099475860596e-01
    z[4,3,6]  R2148     -1.2751290202140808e-01
    z[4,3,6]  R2149     -3.2146766781806946e-01
    z[4,3,6]  R2150     -1.2298163771629333e-01
    z[4,3,6]  R2151     -9.7241960465908051e-02
    z[4,3,6]  R2152     2.5140061974525452e-01
    z[4,3,6]  R2153     -4.8264440149068832e-02
    z[4,3,6]  R2154     -5.5036425590515137e-01
    z[4,3,6]  R2155     3.6843335628509521e-01
    z[4,3,6]  R2156     5.7483422756195068e-01
    z[4,3,6]  R2157     2.2443674504756927e-01
    z[4,3,6]  R2158     2.3426796495914459e-01
    z[4,3,6]  R2159     -1.6048528254032135e-01
    z[4,3,6]  R2160     1.1201063543558121e-01
    z[4,3,6]  R2161     1.1910926550626755e-01
    z[4,3,6]  R2162     -4.3320894241333008e-01
    z[4,3,6]  R2163     8.9084036648273468e-02
    z[4,3,6]  R2164     3.6374524235725403e-01
    z[4,3,6]  R2165     3.1410580873489380e-01
    z[4,3,6]  R2166     3.9531286805868149e-02
    z[4,3,6]  R2167     3.1940481066703796e-01
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R2242     -1
    z[4,5,0]  R2243     1
    z[4,5,0]  R2256     -3.5911047458648682e-01
    z[4,5,0]  R2257     -3.5800606012344360e-01
    z[4,5,0]  R2258     -1.3780531287193298e-01
    z[4,5,0]  R2259     -2.9238942265510559e-01
    z[4,5,0]  R2260     -1.8122249841690063e-01
    z[4,5,0]  R2261     -1.4514103531837463e-01
    z[4,5,0]  R2262     -3.9680501818656921e-01
    z[4,5,0]  R2263     -3.6523446440696716e-01
    z[4,5,0]  R2264     -7.7383734285831451e-02
    z[4,5,0]  R2265     -4.0516808629035950e-01
    z[4,5,0]  R2266     0.942054808139801
    z[4,5,0]  R2267     8.9981865882873535e-01
    z[4,5,0]  R2268     5.8713823556900024e-01
    z[4,5,0]  R2269     6.0660946369171143e-01
    z[4,5,0]  R2270     6.0895085334777832e-01
    z[4,5,0]  R2271     0.65199875831604
    z[4,5,0]  R2272     5.9659922122955322e-01
    z[4,5,0]  R2273     1.1463463306427002e-01
    z[4,5,0]  R2274     5.4364860057830811e-01
    z[4,5,0]  R2275     2.2304007411003113e-01
    z[4,5,0]  R2276     -0.943132221698761
    z[4,5,0]  R2277     -4.1723379492759705e-01
    z[4,5,0]  R2278     3.8019508123397827e-01
    z[4,5,0]  R2279     4.4824984669685364e-01
    z[4,5,0]  R2280     5.2685993909835815e-01
    z[4,5,0]  R2281     9.4603672623634338e-02
    z[4,5,0]  R2282     -2.4945980310440063e-01
    z[4,5,0]  R2283     -2.7539214491844177e-01
    z[4,5,0]  R2284     1.0563543438911438e-01
    z[4,5,0]  R2285     7.7304452657699585e-02
    z[4,5,0]  R2286     -9.3091838061809540e-02
    z[4,5,0]  R2287     -5.1429796218872070e-01
    z[4,5,0]  R2288     6.5010762214660645e-01
    z[4,5,0]  R2289     -1.0805778205394745e-02
    z[4,5,0]  R2290     1.4774626493453979e-01
    z[4,5,0]  R2291     1.1612449586391449e-01
    z[4,5,0]  R2292     3.6412292718887329e-01
    z[4,5,0]  R2293     5.1719751209020615e-02
    z[4,5,0]  R2294     -9.9702635779976845e-03
    z[4,5,0]  R2295     -5.7827834039926529e-02
    z[4,5,0]  R2296     3.3384832739830017e-01
    z[4,5,0]  R2297     -1.3449686765670776e-01
    z[4,5,0]  R2298     -8.7584452703595161e-03
    z[4,5,0]  R2299     4.8221364617347717e-01
    z[4,5,0]  R2300     8.4913492202758789e-02
    z[4,5,0]  R2301     -3.2118913531303406e-01
    z[4,5,0]  R2302     2.1783185005187988e-01
    z[4,5,0]  R2303     2.6415199041366577e-01
    z[4,5,0]  R2304     1.2744180858135223e-01
    z[4,5,0]  R2305     1.4033287763595581e-01
    z[4,5,0]  R2306     -1.3997809030115604e-02
    z[4,5,0]  R2307     5.5758005380630493e-01
    z[4,5,0]  R2308     5.0523781776428223e-01
    z[4,5,0]  R2309     -5.2187938243150711e-02
    z[4,5,0]  R2310     1.2089616805315018e-01
    z[4,5,0]  R2311     -8.6801508441567421e-03
    z[4,5,0]  R2312     8.7563628330826759e-03
    z[4,5,0]  R2313     -7.5780510902404785e-02
    z[4,5,0]  R2314     -2.1654142066836357e-02
    z[4,5,0]  R2315     8.2768142223358154e-01
    z[4,5,0]  R2316     4.0742865204811096e-01
    z[4,5,0]  R2317     4.3945017457008362e-01
    z[4,5,0]  R2318     3.8547104597091675e-01
    z[4,5,0]  R2319     -5.6935763359069824e-01
    z[4,5,0]  R2320     1.4344798028469086e-01
    z[4,5,0]  R2321     -5.0438129901885986e-01
    z[4,5,0]  R2322     2.9635295271873474e-01
    z[4,5,0]  R2323     3.9452192187309265e-01
    z[4,5,0]  R2324     2.0532502233982086e-01
    z[4,5,0]  R2325     3.9675658941268921e-01
    z[4,5,0]  R2326     -9.2806547880172729e-02
    z[4,5,0]  R2327     7.5493997335433960e-01
    z[4,5,0]  R2328     3.9099308848381042e-01
    z[4,5,0]  R2329     -3.3919128775596619e-01
    z[4,5,0]  R2330     5.5431425571441650e-01
    z[4,5,0]  R2331     6.5923231840133667e-01
    z[4,5,0]  R2332     6.0001599788665771e-01
    z[4,5,0]  R2333     -5.4473632574081421e-01
    z[4,5,0]  R2334     6.8981027603149414e-01
    z[4,5,0]  R2335     7.3579502105712891e-01
    z[4,5,0]  R2336     7.4069178104400635e-01
    z[4,5,0]  R2337     7.2650265693664551e-01
    z[4,5,0]  R2338     5.7322221994400024e-01
    z[4,5,0]  R2339     6.9887030124664307e-01
    z[4,5,0]  R2340     7.1005409955978394e-01
    z[4,5,0]  R2341     -7.6446205377578735e-01
    z[4,5,0]  R2342     -8.9940339326858521e-01
    z[4,5,0]  R2343     -0.898152232170105
    z[4,5,0]  R2344     -8.1273835897445679e-01
    z[4,5,0]  R2345     -7.4537557363510132e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R2244     -1
    z[4,5,1]  R2245     1
    z[4,5,1]  R2256     3.9992593228816986e-02
    z[4,5,1]  R2257     8.8066153228282928e-02
    z[4,5,1]  R2258     -1.4184577763080597e-01
    z[4,5,1]  R2259     1.9708101451396942e-01
    z[4,5,1]  R2260     1.9181822240352631e-01
    z[4,5,1]  R2261     1.7235554754734039e-01
    z[4,5,1]  R2262     1.0931375622749329e-01
    z[4,5,1]  R2263     0.334354430437088
    z[4,5,1]  R2264     1.9728232920169830e-01
    z[4,5,1]  R2265     1.5075589530169964e-02
    z[4,5,1]  R2266     5.3768295794725418e-02
    z[4,5,1]  R2267     2.5043004751205444e-01
    z[4,5,1]  R2268     0.412627249956131
    z[4,5,1]  R2269     -4.2724588513374329e-01
    z[4,5,1]  R2270     -7.0076274871826172e-01
    z[4,5,1]  R2271     -6.1578017473220825e-01
    z[4,5,1]  R2272     -7.4422496557235718e-01
    z[4,5,1]  R2273     -3.5293185710906982e-01
    z[4,5,1]  R2274     -5.6348502635955811e-01
    z[4,5,1]  R2275     -3.0520507693290710e-01
    z[4,5,1]  R2276     2.6929962635040283e-01
    z[4,5,1]  R2277     0.547633171081543
    z[4,5,1]  R2278     -3.4225234389305115e-01
    z[4,5,1]  R2279     -3.7711513042449951e-01
    z[4,5,1]  R2280     5.0179883837699890e-02
    z[4,5,1]  R2281     4.6545788645744324e-02
    z[4,5,1]  R2282     -4.1894862055778503e-01
    z[4,5,1]  R2283     -0.589698076248169
    z[4,5,1]  R2284     -2.8642225265502930e-01
    z[4,5,1]  R2285     0.365046888589859
    z[4,5,1]  R2286     7.0368468761444092e-01
    z[4,5,1]  R2287     6.3230073451995850e-01
    z[4,5,1]  R2288     5.2852157503366470e-02
    z[4,5,1]  R2289     -3.5425764322280884e-01
    z[4,5,1]  R2290     -0.572669506072998
    z[4,5,1]  R2291     3.5959962755441666e-02
    z[4,5,1]  R2292     6.5954573452472687e-02
    z[4,5,1]  R2293     -3.4190490841865540e-01
    z[4,5,1]  R2294     -1.7867447435855865e-01
    z[4,5,1]  R2295     -2.2493988275527954e-01
    z[4,5,1]  R2296     -2.8695452213287354e-01
    z[4,5,1]  R2297     -5.7241046428680420e-01
    z[4,5,1]  R2298     -3.8586992025375366e-01
    z[4,5,1]  R2299     -2.0042078197002411e-01
    z[4,5,1]  R2300     -1.7952386289834976e-02
    z[4,5,1]  R2301     -1.3532178103923798e-01
    z[4,5,1]  R2302     0.408532053232193
    z[4,5,1]  R2303     -0.789068877696991
    z[4,5,1]  R2304     -0.81621253490448
    z[4,5,1]  R2305     -7.4622911214828491e-01
    z[4,5,1]  R2306     1.8905310332775116e-01
    z[4,5,1]  R2307     2.1017962694168091e-01
    z[4,5,1]  R2308     1.5771448612213135e-01
    z[4,5,1]  R2309     2.1219782531261444e-01
    z[4,5,1]  R2310     2.2072224318981171e-01
    z[4,5,1]  R2311     2.5600370764732361e-01
    z[4,5,1]  R2312     1.7782041430473328e-01
    z[4,5,1]  R2313     4.4399213790893555e-01
    z[4,5,1]  R2314     1.2944982945919037e-01
    z[4,5,1]  R2315     1.2567570805549622e-01
    z[4,5,1]  R2316     -6.5594899654388428e-01
    z[4,5,1]  R2317     -3.3320096135139465e-01
    z[4,5,1]  R2318     -0.617285430431366
    z[4,5,1]  R2319     2.8803017735481262e-01
    z[4,5,1]  R2320     -9.5162212848663330e-01
    z[4,5,1]  R2321     4.3394145369529724e-01
    z[4,5,1]  R2322     -5.5049043893814087e-01
    z[4,5,1]  R2323     -3.2727000117301941e-01
    z[4,5,1]  R2324     -9.1263920068740845e-01
    z[4,5,1]  R2325     -3.4390786290168762e-01
    z[4,5,1]  R2326     9.4008797407150269e-01
    z[4,5,1]  R2327     -2.5318646430969238e-01
    z[4,5,1]  R2328     5.1840496063232422e-01
    z[4,5,1]  R2329     -3.7790334224700928e-01
    z[4,5,1]  R2330     0.398128867149353
    z[4,5,1]  R2331     -2.2204957902431488e-01
    z[4,5,1]  R2332     1.0989034920930862e-01
    z[4,5,1]  R2333     -8.0375164747238159e-02
    z[4,5,1]  R2334     2.8845466673374176e-02
    z[4,5,1]  R2335     -3.4753879904747009e-01
    z[4,5,1]  R2336     -0.0806993618607521
    z[4,5,1]  R2337     -0.042476586997509
    z[4,5,1]  R2338     2.8685966134071350e-01
    z[4,5,1]  R2339     -4.3638747930526733e-01
    z[4,5,1]  R2340     1.0166170448064804e-01
    z[4,5,1]  R2341     2.1396577358245850e-01
    z[4,5,1]  R2342     -1.3196200598031282e-03
    z[4,5,1]  R2343     -0.0641687661409378
    z[4,5,1]  R2344     -2.0167045295238495e-01
    z[4,5,1]  R2345     1.0248646140098572e-02
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R2246     -1
    z[4,5,2]  R2247     1
    z[4,5,2]  R2256     7.0885759592056274e-01
    z[4,5,2]  R2257     7.2918081283569336e-01
    z[4,5,2]  R2258     0.774948239326477
    z[4,5,2]  R2259     8.6175012588500977e-01
    z[4,5,2]  R2260     -0.421764612197876
    z[4,5,2]  R2261     -0.676142156124115
    z[4,5,2]  R2262     4.2299043387174606e-02
    z[4,5,2]  R2263     1.0496312379837036e-01
    z[4,5,2]  R2264     -4.2408052086830139e-01
    z[4,5,2]  R2265     4.8272809386253357e-01
    z[4,5,2]  R2266     7.6136313378810883e-02
    z[4,5,2]  R2267     -1.1208809167146683e-01
    z[4,5,2]  R2268     -0.0673513412475586
    z[4,5,2]  R2269     -3.7408652901649475e-01
    z[4,5,2]  R2270     -1.6330179572105408e-01
    z[4,5,2]  R2271     -7.6653786003589630e-02
    z[4,5,2]  R2272     -2.0851986110210419e-01
    z[4,5,2]  R2273     -5.0066363811492920e-01
    z[4,5,2]  R2274     -1.8591651320457458e-01
    z[4,5,2]  R2275     -5.1453369855880737e-01
    z[4,5,2]  R2276     -1.3060493767261505e-01
    z[4,5,2]  R2277     -8.7851323187351227e-02
    z[4,5,2]  R2278     -0.742438793182373
    z[4,5,2]  R2279     -4.8063719272613525e-01
    z[4,5,2]  R2280     -6.5481591224670410e-01
    z[4,5,2]  R2281     -3.4209641814231873e-01
    z[4,5,2]  R2282     -7.1385228633880615e-01
    z[4,5,2]  R2283     -6.4999693632125854e-01
    z[4,5,2]  R2284     -0.809843122959137
    z[4,5,2]  R2285     -6.0245621204376221e-01
    z[4,5,2]  R2286     4.5894297957420349e-01
    z[4,5,2]  R2287     1.1132667958736420e-01
    z[4,5,2]  R2288     -6.6455513238906860e-01
    z[4,5,2]  R2289     -5.2812069654464722e-01
    z[4,5,2]  R2290     -5.6795650720596313e-01
    z[4,5,2]  R2291     -6.9453239440917969e-01
    z[4,5,2]  R2292     -0.555451512336731
    z[4,5,2]  R2293     -7.9939246177673340e-01
    z[4,5,2]  R2294     -6.5235203504562378e-01
    z[4,5,2]  R2295     -6.0514295101165771e-01
    z[4,5,2]  R2296     -7.2713285684585571e-01
    z[4,5,2]  R2297     -7.5922089815139771e-01
    z[4,5,2]  R2298     -5.8087509870529175e-01
    z[4,5,2]  R2299     -7.8284674882888794e-01
    z[4,5,2]  R2300     -7.4088609218597412e-01
    z[4,5,2]  R2301     -0.635337233543396
    z[4,5,2]  R2302     -3.9858633279800415e-01
    z[4,5,2]  R2303     4.3616119772195816e-02
    z[4,5,2]  R2304     1.5644568204879761e-01
    z[4,5,2]  R2305     -9.8282612860202789e-02
    z[4,5,2]  R2306     -2.8237661719322205e-01
    z[4,5,2]  R2307     -1.2899863719940186e-01
    z[4,5,2]  R2308     -5.5287480354309082e-01
    z[4,5,2]  R2309     -6.1866492033004761e-01
    z[4,5,2]  R2310     -2.5025400519371033e-01
    z[4,5,2]  R2311     5.1847383379936218e-02
    z[4,5,2]  R2312     -6.7677521705627441e-01
    z[4,5,2]  R2313     -8.1299352645874023e-01
    z[4,5,2]  R2314     -5.4551094770431519e-01
    z[4,5,2]  R2315     2.4136213958263397e-01
    z[4,5,2]  R2316     4.0681045502424240e-02
    z[4,5,2]  R2317     1.4646363258361816e-01
    z[4,5,2]  R2318     -2.1235128864645958e-02
    z[4,5,2]  R2319     2.7705490589141846e-01
    z[4,5,2]  R2320     -2.4117190390825272e-02
    z[4,5,2]  R2321     5.7482112199068069e-02
    z[4,5,2]  R2322     4.7844356298446655e-01
    z[4,5,2]  R2323     -3.3507618308067322e-01
    z[4,5,2]  R2324     0.0655309185385704
    z[4,5,2]  R2325     3.3724945783615112e-01
    z[4,5,2]  R2326     1.1411363631486893e-01
    z[4,5,2]  R2327     1.8625865876674652e-01
    z[4,5,2]  R2328     -0.144407719373703
    z[4,5,2]  R2329     -4.1109225153923035e-01
    z[4,5,2]  R2330     2.6722699403762817e-01
    z[4,5,2]  R2331     5.5550694465637207e-01
    z[4,5,2]  R2332     5.9672847390174866e-02
    z[4,5,2]  R2333     -2.2553333640098572e-01
    z[4,5,2]  R2334     6.7317962646484375e-02
    z[4,5,2]  R2335     -2.5654649734497070e-01
    z[4,5,2]  R2336     3.3794519305229187e-01
    z[4,5,2]  R2337     -2.4270488321781158e-01
    z[4,5,2]  R2338     1.8770545721054077e-01
    z[4,5,2]  R2339     1.3617783784866333e-01
    z[4,5,2]  R2340     3.6944913864135742e-01
    z[4,5,2]  R2341     -3.4059572219848633e-01
    z[4,5,2]  R2342     -1.6890175640583038e-01
    z[4,5,2]  R2343     6.1599317938089371e-02
    z[4,5,2]  R2344     1.7163710668683052e-02
    z[4,5,2]  R2345     -3.3075023442506790e-02
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R2248     -1
    z[4,5,3]  R2249     1
    z[4,5,3]  R2256     1.5453018248081207e-01
    z[4,5,3]  R2257     2.4318028986454010e-01
    z[4,5,3]  R2258     -6.6407345235347748e-02
    z[4,5,3]  R2259     3.7617892958223820e-03
    z[4,5,3]  R2260     7.7589273452758789e-01
    z[4,5,3]  R2261     4.9217936396598816e-01
    z[4,5,3]  R2262     8.0812788009643555e-01
    z[4,5,3]  R2263     9.9210254848003387e-02
    z[4,5,3]  R2264     2.9624202847480774e-01
    z[4,5,3]  R2265     -5.8686983585357666e-01
    z[4,5,3]  R2266     2.3793120682239532e-01
    z[4,5,3]  R2267     1.7997060716152191e-01
    z[4,5,3]  R2268     -2.1408474445343018e-01
    z[4,5,3]  R2269     -3.9325478672981262e-01
    z[4,5,3]  R2270     -2.1021410822868347e-01
    z[4,5,3]  R2271     -3.5917416214942932e-01
    z[4,5,3]  R2272     1.9981622695922852e-02
    z[4,5,3]  R2273     -5.4983055591583252e-01
    z[4,5,3]  R2274     1.9537252373993397e-03
    z[4,5,3]  R2275     -5.0493568181991577e-01
    z[4,5,3]  R2276     2.7512183412909508e-02
    z[4,5,3]  R2277     5.0766932964324951e-01
    z[4,5,3]  R2278     -2.9457315802574158e-01
    z[4,5,3]  R2279     -4.6839483082294464e-02
    z[4,5,3]  R2280     -4.3036738038063049e-01
    z[4,5,3]  R2281     -0.267819881439209
    z[4,5,3]  R2282     -3.9078226685523987e-01
    z[4,5,3]  R2283     -2.8767085075378418e-01
    z[4,5,3]  R2284     -3.8902035355567932e-01
    z[4,5,3]  R2285     -0.190802201628685
    z[4,5,3]  R2286     5.1662659645080566e-01
    z[4,5,3]  R2287     1.0520192235708237e-01
    z[4,5,3]  R2288     -2.2982361912727356e-01
    z[4,5,3]  R2289     -5.8106422424316406e-01
    z[4,5,3]  R2290     -3.6560976505279541e-01
    z[4,5,3]  R2291     -6.9852042198181152e-01
    z[4,5,3]  R2292     -3.0261768028140068e-02
    z[4,5,3]  R2293     -6.6269993782043457e-02
    z[4,5,3]  R2294     -6.4941161870956421e-01
    z[4,5,3]  R2295     8.2603186368942261e-02
    z[4,5,3]  R2296     -2.2602368891239166e-01
    z[4,5,3]  R2297     -1.2361246347427368e-01
    z[4,5,3]  R2298     -5.3486543893814087e-01
    z[4,5,3]  R2299     -1.1051447689533234e-01
    z[4,5,3]  R2300     -6.4729940891265869e-01
    z[4,5,3]  R2301     -3.4381550550460815e-01
    z[4,5,3]  R2302     -3.5488963127136230e-01
    z[4,5,3]  R2303     0.317862868309021
    z[4,5,3]  R2304     1.6077440977096558e-01
    z[4,5,3]  R2305     4.6951431035995483e-01
    z[4,5,3]  R2306     6.6540360450744629e-01
    z[4,5,3]  R2307     6.5713709592819214e-01
    z[4,5,3]  R2308     5.0276738405227661e-01
    z[4,5,3]  R2309     3.6557447910308838e-01
    z[4,5,3]  R2310     3.9716669917106628e-01
    z[4,5,3]  R2311     3.7337687611579895e-01
    z[4,5,3]  R2312     4.5556488633155823e-01
    z[4,5,3]  R2313     1.1686177551746368e-01
    z[4,5,3]  R2314     5.0188434123992920e-01
    z[4,5,3]  R2315     2.3232667148113251e-01
    z[4,5,3]  R2316     -5.7432240247726440e-01
    z[4,5,3]  R2317     -6.3345789909362793e-01
    z[4,5,3]  R2318     -4.6149781346321106e-01
    z[4,5,3]  R2319     -4.6182355284690857e-01
    z[4,5,3]  R2320     -1.3038317859172821e-01
    z[4,5,3]  R2321     -5.3972136974334717e-01
    z[4,5,3]  R2322     -3.8895878195762634e-01
    z[4,5,3]  R2323     -5.3050237894058228e-01
    z[4,5,3]  R2324     -2.5320374965667725e-01
    z[4,5,3]  R2325     -4.2305126786231995e-01
    z[4,5,3]  R2326     2.9098740220069885e-01
    z[4,5,3]  R2327     -2.9129517078399658e-01
    z[4,5,3]  R2328     -1.4781875908374786e-01
    z[4,5,3]  R2329     -3.1002059578895569e-01
    z[4,5,3]  R2330     -3.9259654283523560e-01
    z[4,5,3]  R2331     -1.4276312291622162e-01
    z[4,5,3]  R2332     -2.5168719887733459e-01
    z[4,5,3]  R2333     -6.5503165125846863e-02
    z[4,5,3]  R2334     -1.3038103282451630e-01
    z[4,5,3]  R2335     -0.469923198223114
    z[4,5,3]  R2336     1.0379044711589813e-01
    z[4,5,3]  R2337     -1.3402193784713745e-01
    z[4,5,3]  R2338     -2.9712323099374771e-02
    z[4,5,3]  R2339     5.9156041592359543e-02
    z[4,5,3]  R2340     1.1013500392436981e-02
    z[4,5,3]  R2341     -4.3319210410118103e-01
    z[4,5,3]  R2342     -3.8658967614173889e-01
    z[4,5,3]  R2343     -4.2065268754959106e-01
    z[4,5,3]  R2344     -4.7309896349906921e-01
    z[4,5,3]  R2345     -4.2904523015022278e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R2250     -1
    z[4,5,4]  R2251     1
    z[4,5,4]  R2256     0.584718644618988
    z[4,5,4]  R2257     1.1929895728826523e-01
    z[4,5,4]  R2258     4.4568312168121338e-01
    z[4,5,4]  R2259     -1.9457225501537323e-01
    z[4,5,4]  R2260     -2.3900421336293221e-02
    z[4,5,4]  R2261     -3.1577959656715393e-01
    z[4,5,4]  R2262     -3.5803741216659546e-01
    z[4,5,4]  R2263     6.9361424446105957e-01
    z[4,5,4]  R2264     -0.651825487613678
    z[4,5,4]  R2265     1.3738542795181274e-01
    z[4,5,4]  R2266     -1.3454273343086243e-01
    z[4,5,4]  R2267     1.5022955834865570e-01
    z[4,5,4]  R2268     0.452536016702652
    z[4,5,4]  R2269     3.3214700222015381e-01
    z[4,5,4]  R2270     2.2784835100173950e-01
    z[4,5,4]  R2271     -1.3697463274002075e-01
    z[4,5,4]  R2272     1.7680658400058746e-01
    z[4,5,4]  R2273     -4.9967506527900696e-01
    z[4,5,4]  R2274     2.7726349234580994e-01
    z[4,5,4]  R2275     -4.2929565906524658e-01
    z[4,5,4]  R2276     -7.9094909131526947e-02
    z[4,5,4]  R2277     8.4954008460044861e-02
    z[4,5,4]  R2278     -3.1500864028930664e-01
    z[4,5,4]  R2279     -4.3252453207969666e-01
    z[4,5,4]  R2280     -8.6337188258767128e-03
    z[4,5,4]  R2281     -6.2996000051498413e-01
    z[4,5,4]  R2282     8.6528457701206207e-02
    z[4,5,4]  R2283     -2.3535829782485962e-01
    z[4,5,4]  R2284     2.9225587844848633e-01
    z[4,5,4]  R2285     -4.7899162769317627e-01
    z[4,5,4]  R2286     5.1167141646146774e-02
    z[4,5,4]  R2287     2.7436983585357666e-01
    z[4,5,4]  R2288     -1.1434942483901978e-01
    z[4,5,4]  R2289     -4.6427333354949951e-01
    z[4,5,4]  R2290     9.7543504089117050e-03
    z[4,5,4]  R2291     3.3553630113601685e-02
    z[4,5,4]  R2292     -4.8827984929084778e-01
    z[4,5,4]  R2293     9.5876671373844147e-02
    z[4,5,4]  R2294     -1.2067833542823792e-01
    z[4,5,4]  R2295     -4.4259798526763916e-01
    z[4,5,4]  R2296     -4.3967342376708984e-01
    z[4,5,4]  R2297     -1.3392937183380127e-01
    z[4,5,4]  R2298     -4.1266137361526489e-01
    z[4,5,4]  R2299     2.2943212091922760e-01
    z[4,5,4]  R2300     -1.1504572629928589e-01
    z[4,5,4]  R2301     -3.9065372943878174e-01
    z[4,5,4]  R2302     -6.8254613876342773e-01
    z[4,5,4]  R2303     -3.9675071835517883e-01
    z[4,5,4]  R2304     -4.9660202860832214e-01
    z[4,5,4]  R2305     -3.6722466349601746e-01
    z[4,5,4]  R2306     -5.6736266613006592e-01
    z[4,5,4]  R2307     -4.2338716983795166e-01
    z[4,5,4]  R2308     -2.7609494328498840e-01
    z[4,5,4]  R2309     -5.4130053520202637e-01
    z[4,5,4]  R2310     -5.4473882913589478e-01
    z[4,5,4]  R2311     -7.5190836191177368e-01
    z[4,5,4]  R2312     6.0095246881246567e-02
    z[4,5,4]  R2313     1.6605155169963837e-01
    z[4,5,4]  R2314     -2.0370914041996002e-01
    z[4,5,4]  R2315     2.3565191030502319e-01
    z[4,5,4]  R2316     1.3322633504867554e-01
    z[4,5,4]  R2317     -1.5834622085094452e-02
    z[4,5,4]  R2318     0.277626633644104
    z[4,5,4]  R2319     0.466239869594574
    z[4,5,4]  R2320     2.0291706547141075e-02
    z[4,5,4]  R2321     2.7662605047225952e-01
    z[4,5,4]  R2322     7.7883275225758553e-03
    z[4,5,4]  R2323     2.1679170429706573e-01
    z[4,5,4]  R2324     -1.0537905991077423e-01
    z[4,5,4]  R2325     0.0986253172159195
    z[4,5,4]  R2326     0.00849322509020567
    z[4,5,4]  R2327     2.1699893474578857e-01
    z[4,5,4]  R2328     3.9246338605880737e-01
    z[4,5,4]  R2329     3.7728101015090942e-01
    z[4,5,4]  R2330     5.4241657257080078e-02
    z[4,5,4]  R2331     0.154581680893898
    z[4,5,4]  R2332     3.2734036445617676e-01
    z[4,5,4]  R2333     6.6526606678962708e-02
    z[4,5,4]  R2334     1.0396488755941391e-01
    z[4,5,4]  R2335     -1.1083486676216125e-01
    z[4,5,4]  R2336     2.1375261247158051e-01
    z[4,5,4]  R2337     5.8546119928359985e-01
    z[4,5,4]  R2338     3.8419520854949951e-01
    z[4,5,4]  R2339     3.7921886891126633e-02
    z[4,5,4]  R2340     2.2218170762062073e-01
    z[4,5,4]  R2341     3.6676891148090363e-02
    z[4,5,4]  R2342     -7.9336911439895630e-02
    z[4,5,4]  R2343     -6.3870586454868317e-02
    z[4,5,4]  R2344     -1.1375338584184647e-01
    z[4,5,4]  R2345     -2.6194578409194946e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R2252     -1
    z[4,5,5]  R2253     1
    z[4,5,5]  R2256     1.1528528295457363e-02
    z[4,5,5]  R2257     0.46016725897789
    z[4,5,5]  R2258     3.6443573236465454e-01
    z[4,5,5]  R2259     -1.1830856651067734e-01
    z[4,5,5]  R2260     2.3036555945873260e-01
    z[4,5,5]  R2261     2.3484787344932556e-01
    z[4,5,5]  R2262     1.8928836286067963e-01
    z[4,5,5]  R2263     3.3975234627723694e-01
    z[4,5,5]  R2264     2.8387647867202759e-01
    z[4,5,5]  R2265     -2.4164432287216187e-01
    z[4,5,5]  R2266     2.3776585236191750e-02
    z[4,5,5]  R2267     -2.4114778637886047e-01
    z[4,5,5]  R2268     1.0148690640926361e-01
    z[4,5,5]  R2269     3.1827643513679504e-02
    z[4,5,5]  R2270     -1.2022651731967926e-01
    z[4,5,5]  R2271     -4.6280834823846817e-02
    z[4,5,5]  R2272     -3.2995335757732391e-02
    z[4,5,5]  R2273     -2.3742890357971191e-01
    z[4,5,5]  R2274     -2.3853017017245293e-02
    z[4,5,5]  R2275     -3.4963092207908630e-01
    z[4,5,5]  R2276     1.0461068153381348e-01
    z[4,5,5]  R2277     -4.8696655035018921e-01
    z[4,5,5]  R2278     3.3102143555879593e-02
    z[4,5,5]  R2279     -3.9775168895721436e-01
    z[4,5,5]  R2280     -3.0349004268646240e-01
    z[4,5,5]  R2281     -6.0651499032974243e-01
    z[4,5,5]  R2282     -3.0408149957656860e-01
    z[4,5,5]  R2283     7.3091499507427216e-02
    z[4,5,5]  R2284     5.0470467656850815e-02
    z[4,5,5]  R2285     -4.5190271735191345e-01
    z[4,5,5]  R2286     -6.0405898839235306e-02
    z[4,5,5]  R2287     -4.4078135490417480e-01
    z[4,5,5]  R2288     -2.4801802635192871e-01
    z[4,5,5]  R2289     1.0184463113546371e-01
    z[4,5,5]  R2290     -3.9927187561988831e-01
    z[4,5,5]  R2291     4.3250724673271179e-02
    z[4,5,5]  R2292     -4.8846244812011719e-01
    z[4,5,5]  R2293     -4.4637325406074524e-01
    z[4,5,5]  R2294     -1.9911728799343109e-01
    z[4,5,5]  R2295     -5.6191688776016235e-01
    z[4,5,5]  R2296     -1.7829376459121704e-01
    z[4,5,5]  R2297     -1.8528230488300323e-01
    z[4,5,5]  R2298     2.2916388511657715e-01
    z[4,5,5]  R2299     2.1229531615972519e-02
    z[4,5,5]  R2300     -2.6011077687144279e-02
    z[4,5,5]  R2301     -4.5171543955802917e-01
    z[4,5,5]  R2302     -1.7164134979248047e-01
    z[4,5,5]  R2303     2.0519137382507324e-01
    z[4,5,5]  R2304     8.1515289843082428e-02
    z[4,5,5]  R2305     -2.0793452858924866e-01
    z[4,5,5]  R2306     -3.4532821178436279e-01
    z[4,5,5]  R2307     -2.1436698734760284e-02
    z[4,5,5]  R2308     2.7303391695022583e-01
    z[4,5,5]  R2309     1.1729851365089417e-01
    z[4,5,5]  R2310     4.1483619809150696e-01
    z[4,5,5]  R2311     3.1923133134841919e-01
    z[4,5,5]  R2312     -1.3287958502769470e-01
    z[4,5,5]  R2313     2.7967765927314758e-01
    z[4,5,5]  R2314     2.5065195560455322e-01
    z[4,5,5]  R2315     -2.0192395150661469e-01
    z[4,5,5]  R2316     1.4752630889415741e-01
    z[4,5,5]  R2317     1.8181920051574707e-01
    z[4,5,5]  R2318     0.220264732837677
    z[4,5,5]  R2319     -3.2586917281150818e-02
    z[4,5,5]  R2320     -5.7722595520317554e-03
    z[4,5,5]  R2321     -5.5649623274803162e-02
    z[4,5,5]  R2322     3.8544493913650513e-01
    z[4,5,5]  R2323     -2.5023165345191956e-01
    z[4,5,5]  R2324     9.4785392284393311e-02
    z[4,5,5]  R2325     2.4255488812923431e-01
    z[4,5,5]  R2326     -1.9831936806440353e-02
    z[4,5,5]  R2327     4.4322180747985840e-01
    z[4,5,5]  R2328     -1.4351183176040649e-01
    z[4,5,5]  R2329     2.0533630251884460e-01
    z[4,5,5]  R2330     5.4337686300277710e-01
    z[4,5,5]  R2331     3.7895879149436951e-01
    z[4,5,5]  R2332     5.9802955389022827e-01
    z[4,5,5]  R2333     -0.599342405796051
    z[4,5,5]  R2334     4.1543442010879517e-01
    z[4,5,5]  R2335     -1.1101827770471573e-01
    z[4,5,5]  R2336     4.6737310290336609e-01
    z[4,5,5]  R2337     2.1555164456367493e-01
    z[4,5,5]  R2338     0.607568085193634
    z[4,5,5]  R2339     0.532397449016571
    z[4,5,5]  R2340     -2.6702085137367249e-01
    z[4,5,5]  R2341     2.0080116391181946e-01
    z[4,5,5]  R2342     -6.3286215066909790e-02
    z[4,5,5]  R2343     -1.5741702169179916e-02
    z[4,5,5]  R2344     -1.3458141684532166e-01
    z[4,5,5]  R2345     1.3015043735504150e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R2254     -1
    z[4,5,6]  R2255     1
    z[4,5,6]  R2256     -3.2446052879095078e-02
    z[4,5,6]  R2257     -2.1736724674701691e-01
    z[4,5,6]  R2258     -1.5648598968982697e-01
    z[4,5,6]  R2259     2.8492954373359680e-01
    z[4,5,6]  R2260     3.1117478013038635e-01
    z[4,5,6]  R2261     -3.0813741683959961e-01
    z[4,5,6]  R2262     -1.0823823511600494e-01
    z[4,5,6]  R2263     -3.7070021033287048e-01
    z[4,5,6]  R2264     4.2664456367492676e-01
    z[4,5,6]  R2265     4.2532593011856079e-01
    z[4,5,6]  R2266     -1.6901694238185883e-01
    z[4,5,6]  R2267     -4.4010091572999954e-02
    z[4,5,6]  R2268     4.6856218576431274e-01
    z[4,5,6]  R2269     2.0871374011039734e-01
    z[4,5,6]  R2270     2.9726946726441383e-02
    z[4,5,6]  R2271     1.9981640577316284e-01
    z[4,5,6]  R2272     1.1819269508123398e-01
    z[4,5,6]  R2273     -5.7206183671951294e-02
    z[4,5,6]  R2274     5.2432626485824585e-01
    z[4,5,6]  R2275     1.7567428946495056e-01
    z[4,5,6]  R2276     5.4454866796731949e-02
    z[4,5,6]  R2277     1.2733514606952667e-01
    z[4,5,6]  R2278     2.4166754155885428e-04
    z[4,5,6]  R2279     -2.7993968129158020e-01
    z[4,5,6]  R2280     1.1713202297687531e-01
    z[4,5,6]  R2281     -1.8819177150726318e-01
    z[4,5,6]  R2282     -1.8090275116264820e-03
    z[4,5,6]  R2283     1.0212234407663345e-01
    z[4,5,6]  R2284     -1.0798142850399017e-01
    z[4,5,6]  R2285     1.6660369932651520e-01
    z[4,5,6]  R2286     -1.1118955910205841e-01
    z[4,5,6]  R2287     2.0655590295791626e-01
    z[4,5,6]  R2288     -7.4333444237709045e-02
    z[4,5,6]  R2289     1.7864930629730225e-01
    z[4,5,6]  R2290     -1.8564037978649139e-01
    z[4,5,6]  R2291     -1.0917651653289795e-01
    z[4,5,6]  R2292     2.7678442001342773e-01
    z[4,5,6]  R2293     1.6901065409183502e-01
    z[4,5,6]  R2294     2.5781095027923584e-01
    z[4,5,6]  R2295     2.4777625501155853e-01
    z[4,5,6]  R2296     -3.5946812480688095e-02
    z[4,5,6]  R2297     -1.0145907104015350e-01
    z[4,5,6]  R2298     6.8740755319595337e-02
    z[4,5,6]  R2299     -2.2169624269008636e-01
    z[4,5,6]  R2300     1.0318201780319214e-01
    z[4,5,6]  R2301     2.4264785461127758e-03
    z[4,5,6]  R2302     7.4183098971843719e-02
    z[4,5,6]  R2303     -7.1695089340209961e-02
    z[4,5,6]  R2304     1.1821021884679794e-01
    z[4,5,6]  R2305     1.2351055443286896e-01
    z[4,5,6]  R2306     -2.0312076434493065e-02
    z[4,5,6]  R2307     1.2939487397670746e-01
    z[4,5,6]  R2308     1.0314755886793137e-01
    z[4,5,6]  R2309     3.5929429531097412e-01
    z[4,5,6]  R2310     -4.9746152758598328e-01
    z[4,5,6]  R2311     3.5357251763343811e-01
    z[4,5,6]  R2312     -5.3053814172744751e-01
    z[4,5,6]  R2313     -1.2930710613727570e-01
    z[4,5,6]  R2314     -5.7356774806976318e-01
    z[4,5,6]  R2315     -3.0101948976516724e-01
    z[4,5,6]  R2316     1.8088242411613464e-01
    z[4,5,6]  R2317     4.8972561955451965e-01
    z[4,5,6]  R2318     3.6241775751113892e-01
    z[4,5,6]  R2319     -2.9049712419509888e-01
    z[4,5,6]  R2320     -2.3624455928802490e-01
    z[4,5,6]  R2321     4.2786914110183716e-01
    z[4,5,6]  R2322     2.8338947892189026e-01
    z[4,5,6]  R2323     4.8365625739097595e-01
    z[4,5,6]  R2324     0.19088114798069
    z[4,5,6]  R2325     6.0252988338470459e-01
    z[4,5,6]  R2326     -0.0972653478384018
    z[4,5,6]  R2327     5.3693417459726334e-02
    z[4,5,6]  R2328     6.0087740421295166e-01
    z[4,5,6]  R2329     -5.4085552692413330e-01
    z[4,5,6]  R2330     -1.0240268707275391e-01
    z[4,5,6]  R2331     1.4011496305465698e-01
    z[4,5,6]  R2332     3.1017169356346130e-01
    z[4,5,6]  R2333     5.2726560831069946e-01
    z[4,5,6]  R2334     5.6427329778671265e-01
    z[4,5,6]  R2335     -1.6300034523010254e-01
    z[4,5,6]  R2336     -2.3612719774246216e-01
    z[4,5,6]  R2337     6.5532989799976349e-02
    z[4,5,6]  R2338     -1.9043833017349243e-01
    z[4,5,6]  R2339     -1.1923649907112122e-01
    z[4,5,6]  R2340     4.7771230340003967e-01
    z[4,5,6]  R2341     1.5649099647998810e-01
    z[4,5,6]  R2342     5.2848167717456818e-02
    z[4,5,6]  R2343     -6.4299695193767548e-02
    z[4,5,6]  R2344     2.0884481072425842e-01
    z[4,5,6]  R2345     4.1663125157356262e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R2346     -1
    z[5,4,0]  R2347     1
    z[5,4,0]  R2360     -1.3997809030115604e-02
    z[5,4,0]  R2361     5.5758005380630493e-01
    z[5,4,0]  R2362     5.0523781776428223e-01
    z[5,4,0]  R2363     -5.2187938243150711e-02
    z[5,4,0]  R2364     1.2089616805315018e-01
    z[5,4,0]  R2365     -8.6801508441567421e-03
    z[5,4,0]  R2366     8.7563628330826759e-03
    z[5,4,0]  R2367     -7.5780510902404785e-02
    z[5,4,0]  R2368     -2.1654142066836357e-02
    z[5,4,0]  R2369     8.2768142223358154e-01
    z[5,4,0]  R2370     4.0742865204811096e-01
    z[5,4,0]  R2371     4.3945017457008362e-01
    z[5,4,0]  R2372     3.8547104597091675e-01
    z[5,4,0]  R2373     -5.6935763359069824e-01
    z[5,4,0]  R2374     1.4344798028469086e-01
    z[5,4,0]  R2375     -5.0438129901885986e-01
    z[5,4,0]  R2376     2.9635295271873474e-01
    z[5,4,0]  R2377     3.9452192187309265e-01
    z[5,4,0]  R2378     2.0532502233982086e-01
    z[5,4,0]  R2379     3.9675658941268921e-01
    z[5,4,0]  R2380     -9.2806547880172729e-02
    z[5,4,0]  R2381     7.5493997335433960e-01
    z[5,4,0]  R2382     3.9099308848381042e-01
    z[5,4,0]  R2383     -3.3919128775596619e-01
    z[5,4,0]  R2384     5.5431425571441650e-01
    z[5,4,0]  R2385     6.5923231840133667e-01
    z[5,4,0]  R2386     6.0001599788665771e-01
    z[5,4,0]  R2387     -5.4473632574081421e-01
    z[5,4,0]  R2388     6.8981027603149414e-01
    z[5,4,0]  R2389     7.3579502105712891e-01
    z[5,4,0]  R2390     7.4069178104400635e-01
    z[5,4,0]  R2391     7.2650265693664551e-01
    z[5,4,0]  R2392     5.7322221994400024e-01
    z[5,4,0]  R2393     6.9887030124664307e-01
    z[5,4,0]  R2394     7.1005409955978394e-01
    z[5,4,0]  R2395     -7.6446205377578735e-01
    z[5,4,0]  R2396     -8.9940339326858521e-01
    z[5,4,0]  R2397     -0.898152232170105
    z[5,4,0]  R2398     -8.1273835897445679e-01
    z[5,4,0]  R2399     -7.4537557363510132e-01
    z[5,4,0]  R2400     -3.5911047458648682e-01
    z[5,4,0]  R2401     -3.5800606012344360e-01
    z[5,4,0]  R2402     -1.3780531287193298e-01
    z[5,4,0]  R2403     -2.9238942265510559e-01
    z[5,4,0]  R2404     -1.8122249841690063e-01
    z[5,4,0]  R2405     -1.4514103531837463e-01
    z[5,4,0]  R2406     -3.9680501818656921e-01
    z[5,4,0]  R2407     -3.6523446440696716e-01
    z[5,4,0]  R2408     -7.7383734285831451e-02
    z[5,4,0]  R2409     -4.0516808629035950e-01
    z[5,4,0]  R2410     0.942054808139801
    z[5,4,0]  R2411     8.9981865882873535e-01
    z[5,4,0]  R2412     5.8713823556900024e-01
    z[5,4,0]  R2413     6.0660946369171143e-01
    z[5,4,0]  R2414     6.0895085334777832e-01
    z[5,4,0]  R2415     0.65199875831604
    z[5,4,0]  R2416     5.9659922122955322e-01
    z[5,4,0]  R2417     1.1463463306427002e-01
    z[5,4,0]  R2418     5.4364860057830811e-01
    z[5,4,0]  R2419     2.2304007411003113e-01
    z[5,4,0]  R2420     -0.943132221698761
    z[5,4,0]  R2421     -4.1723379492759705e-01
    z[5,4,0]  R2422     3.8019508123397827e-01
    z[5,4,0]  R2423     4.4824984669685364e-01
    z[5,4,0]  R2424     5.2685993909835815e-01
    z[5,4,0]  R2425     9.4603672623634338e-02
    z[5,4,0]  R2426     -2.4945980310440063e-01
    z[5,4,0]  R2427     -2.7539214491844177e-01
    z[5,4,0]  R2428     1.0563543438911438e-01
    z[5,4,0]  R2429     7.7304452657699585e-02
    z[5,4,0]  R2430     -9.3091838061809540e-02
    z[5,4,0]  R2431     -5.1429796218872070e-01
    z[5,4,0]  R2432     6.5010762214660645e-01
    z[5,4,0]  R2433     -1.0805778205394745e-02
    z[5,4,0]  R2434     1.4774626493453979e-01
    z[5,4,0]  R2435     1.1612449586391449e-01
    z[5,4,0]  R2436     3.6412292718887329e-01
    z[5,4,0]  R2437     5.1719751209020615e-02
    z[5,4,0]  R2438     -9.9702635779976845e-03
    z[5,4,0]  R2439     -5.7827834039926529e-02
    z[5,4,0]  R2440     3.3384832739830017e-01
    z[5,4,0]  R2441     -1.3449686765670776e-01
    z[5,4,0]  R2442     -8.7584452703595161e-03
    z[5,4,0]  R2443     4.8221364617347717e-01
    z[5,4,0]  R2444     8.4913492202758789e-02
    z[5,4,0]  R2445     -3.2118913531303406e-01
    z[5,4,0]  R2446     2.1783185005187988e-01
    z[5,4,0]  R2447     2.6415199041366577e-01
    z[5,4,0]  R2448     1.2744180858135223e-01
    z[5,4,0]  R2449     1.4033287763595581e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R2348     -1
    z[5,4,1]  R2349     1
    z[5,4,1]  R2360     1.8905310332775116e-01
    z[5,4,1]  R2361     2.1017962694168091e-01
    z[5,4,1]  R2362     1.5771448612213135e-01
    z[5,4,1]  R2363     2.1219782531261444e-01
    z[5,4,1]  R2364     2.2072224318981171e-01
    z[5,4,1]  R2365     2.5600370764732361e-01
    z[5,4,1]  R2366     1.7782041430473328e-01
    z[5,4,1]  R2367     4.4399213790893555e-01
    z[5,4,1]  R2368     1.2944982945919037e-01
    z[5,4,1]  R2369     1.2567570805549622e-01
    z[5,4,1]  R2370     -6.5594899654388428e-01
    z[5,4,1]  R2371     -3.3320096135139465e-01
    z[5,4,1]  R2372     -0.617285430431366
    z[5,4,1]  R2373     2.8803017735481262e-01
    z[5,4,1]  R2374     -9.5162212848663330e-01
    z[5,4,1]  R2375     4.3394145369529724e-01
    z[5,4,1]  R2376     -5.5049043893814087e-01
    z[5,4,1]  R2377     -3.2727000117301941e-01
    z[5,4,1]  R2378     -9.1263920068740845e-01
    z[5,4,1]  R2379     -3.4390786290168762e-01
    z[5,4,1]  R2380     9.4008797407150269e-01
    z[5,4,1]  R2381     -2.5318646430969238e-01
    z[5,4,1]  R2382     5.1840496063232422e-01
    z[5,4,1]  R2383     -3.7790334224700928e-01
    z[5,4,1]  R2384     0.398128867149353
    z[5,4,1]  R2385     -2.2204957902431488e-01
    z[5,4,1]  R2386     1.0989034920930862e-01
    z[5,4,1]  R2387     -8.0375164747238159e-02
    z[5,4,1]  R2388     2.8845466673374176e-02
    z[5,4,1]  R2389     -3.4753879904747009e-01
    z[5,4,1]  R2390     -0.0806993618607521
    z[5,4,1]  R2391     -0.042476586997509
    z[5,4,1]  R2392     2.8685966134071350e-01
    z[5,4,1]  R2393     -4.3638747930526733e-01
    z[5,4,1]  R2394     1.0166170448064804e-01
    z[5,4,1]  R2395     2.1396577358245850e-01
    z[5,4,1]  R2396     -1.3196200598031282e-03
    z[5,4,1]  R2397     -0.0641687661409378
    z[5,4,1]  R2398     -2.0167045295238495e-01
    z[5,4,1]  R2399     1.0248646140098572e-02
    z[5,4,1]  R2400     3.9992593228816986e-02
    z[5,4,1]  R2401     8.8066153228282928e-02
    z[5,4,1]  R2402     -1.4184577763080597e-01
    z[5,4,1]  R2403     1.9708101451396942e-01
    z[5,4,1]  R2404     1.9181822240352631e-01
    z[5,4,1]  R2405     1.7235554754734039e-01
    z[5,4,1]  R2406     1.0931375622749329e-01
    z[5,4,1]  R2407     0.334354430437088
    z[5,4,1]  R2408     1.9728232920169830e-01
    z[5,4,1]  R2409     1.5075589530169964e-02
    z[5,4,1]  R2410     5.3768295794725418e-02
    z[5,4,1]  R2411     2.5043004751205444e-01
    z[5,4,1]  R2412     0.412627249956131
    z[5,4,1]  R2413     -4.2724588513374329e-01
    z[5,4,1]  R2414     -7.0076274871826172e-01
    z[5,4,1]  R2415     -6.1578017473220825e-01
    z[5,4,1]  R2416     -7.4422496557235718e-01
    z[5,4,1]  R2417     -3.5293185710906982e-01
    z[5,4,1]  R2418     -5.6348502635955811e-01
    z[5,4,1]  R2419     -3.0520507693290710e-01
    z[5,4,1]  R2420     2.6929962635040283e-01
    z[5,4,1]  R2421     0.547633171081543
    z[5,4,1]  R2422     -3.4225234389305115e-01
    z[5,4,1]  R2423     -3.7711513042449951e-01
    z[5,4,1]  R2424     5.0179883837699890e-02
    z[5,4,1]  R2425     4.6545788645744324e-02
    z[5,4,1]  R2426     -4.1894862055778503e-01
    z[5,4,1]  R2427     -0.589698076248169
    z[5,4,1]  R2428     -2.8642225265502930e-01
    z[5,4,1]  R2429     0.365046888589859
    z[5,4,1]  R2430     7.0368468761444092e-01
    z[5,4,1]  R2431     6.3230073451995850e-01
    z[5,4,1]  R2432     5.2852157503366470e-02
    z[5,4,1]  R2433     -3.5425764322280884e-01
    z[5,4,1]  R2434     -0.572669506072998
    z[5,4,1]  R2435     3.5959962755441666e-02
    z[5,4,1]  R2436     6.5954573452472687e-02
    z[5,4,1]  R2437     -3.4190490841865540e-01
    z[5,4,1]  R2438     -1.7867447435855865e-01
    z[5,4,1]  R2439     -2.2493988275527954e-01
    z[5,4,1]  R2440     -2.8695452213287354e-01
    z[5,4,1]  R2441     -5.7241046428680420e-01
    z[5,4,1]  R2442     -3.8586992025375366e-01
    z[5,4,1]  R2443     -2.0042078197002411e-01
    z[5,4,1]  R2444     -1.7952386289834976e-02
    z[5,4,1]  R2445     -1.3532178103923798e-01
    z[5,4,1]  R2446     0.408532053232193
    z[5,4,1]  R2447     -0.789068877696991
    z[5,4,1]  R2448     -0.81621253490448
    z[5,4,1]  R2449     -7.4622911214828491e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R2350     -1
    z[5,4,2]  R2351     1
    z[5,4,2]  R2360     -2.8237661719322205e-01
    z[5,4,2]  R2361     -1.2899863719940186e-01
    z[5,4,2]  R2362     -5.5287480354309082e-01
    z[5,4,2]  R2363     -6.1866492033004761e-01
    z[5,4,2]  R2364     -2.5025400519371033e-01
    z[5,4,2]  R2365     5.1847383379936218e-02
    z[5,4,2]  R2366     -6.7677521705627441e-01
    z[5,4,2]  R2367     -8.1299352645874023e-01
    z[5,4,2]  R2368     -5.4551094770431519e-01
    z[5,4,2]  R2369     2.4136213958263397e-01
    z[5,4,2]  R2370     4.0681045502424240e-02
    z[5,4,2]  R2371     1.4646363258361816e-01
    z[5,4,2]  R2372     -2.1235128864645958e-02
    z[5,4,2]  R2373     2.7705490589141846e-01
    z[5,4,2]  R2374     -2.4117190390825272e-02
    z[5,4,2]  R2375     5.7482112199068069e-02
    z[5,4,2]  R2376     4.7844356298446655e-01
    z[5,4,2]  R2377     -3.3507618308067322e-01
    z[5,4,2]  R2378     0.0655309185385704
    z[5,4,2]  R2379     3.3724945783615112e-01
    z[5,4,2]  R2380     1.1411363631486893e-01
    z[5,4,2]  R2381     1.8625865876674652e-01
    z[5,4,2]  R2382     -0.144407719373703
    z[5,4,2]  R2383     -4.1109225153923035e-01
    z[5,4,2]  R2384     2.6722699403762817e-01
    z[5,4,2]  R2385     5.5550694465637207e-01
    z[5,4,2]  R2386     5.9672847390174866e-02
    z[5,4,2]  R2387     -2.2553333640098572e-01
    z[5,4,2]  R2388     6.7317962646484375e-02
    z[5,4,2]  R2389     -2.5654649734497070e-01
    z[5,4,2]  R2390     3.3794519305229187e-01
    z[5,4,2]  R2391     -2.4270488321781158e-01
    z[5,4,2]  R2392     1.8770545721054077e-01
    z[5,4,2]  R2393     1.3617783784866333e-01
    z[5,4,2]  R2394     3.6944913864135742e-01
    z[5,4,2]  R2395     -3.4059572219848633e-01
    z[5,4,2]  R2396     -1.6890175640583038e-01
    z[5,4,2]  R2397     6.1599317938089371e-02
    z[5,4,2]  R2398     1.7163710668683052e-02
    z[5,4,2]  R2399     -3.3075023442506790e-02
    z[5,4,2]  R2400     7.0885759592056274e-01
    z[5,4,2]  R2401     7.2918081283569336e-01
    z[5,4,2]  R2402     0.774948239326477
    z[5,4,2]  R2403     8.6175012588500977e-01
    z[5,4,2]  R2404     -0.421764612197876
    z[5,4,2]  R2405     -0.676142156124115
    z[5,4,2]  R2406     4.2299043387174606e-02
    z[5,4,2]  R2407     1.0496312379837036e-01
    z[5,4,2]  R2408     -4.2408052086830139e-01
    z[5,4,2]  R2409     4.8272809386253357e-01
    z[5,4,2]  R2410     7.6136313378810883e-02
    z[5,4,2]  R2411     -1.1208809167146683e-01
    z[5,4,2]  R2412     -0.0673513412475586
    z[5,4,2]  R2413     -3.7408652901649475e-01
    z[5,4,2]  R2414     -1.6330179572105408e-01
    z[5,4,2]  R2415     -7.6653786003589630e-02
    z[5,4,2]  R2416     -2.0851986110210419e-01
    z[5,4,2]  R2417     -5.0066363811492920e-01
    z[5,4,2]  R2418     -1.8591651320457458e-01
    z[5,4,2]  R2419     -5.1453369855880737e-01
    z[5,4,2]  R2420     -1.3060493767261505e-01
    z[5,4,2]  R2421     -8.7851323187351227e-02
    z[5,4,2]  R2422     -0.742438793182373
    z[5,4,2]  R2423     -4.8063719272613525e-01
    z[5,4,2]  R2424     -6.5481591224670410e-01
    z[5,4,2]  R2425     -3.4209641814231873e-01
    z[5,4,2]  R2426     -7.1385228633880615e-01
    z[5,4,2]  R2427     -6.4999693632125854e-01
    z[5,4,2]  R2428     -0.809843122959137
    z[5,4,2]  R2429     -6.0245621204376221e-01
    z[5,4,2]  R2430     4.5894297957420349e-01
    z[5,4,2]  R2431     1.1132667958736420e-01
    z[5,4,2]  R2432     -6.6455513238906860e-01
    z[5,4,2]  R2433     -5.2812069654464722e-01
    z[5,4,2]  R2434     -5.6795650720596313e-01
    z[5,4,2]  R2435     -6.9453239440917969e-01
    z[5,4,2]  R2436     -0.555451512336731
    z[5,4,2]  R2437     -7.9939246177673340e-01
    z[5,4,2]  R2438     -6.5235203504562378e-01
    z[5,4,2]  R2439     -6.0514295101165771e-01
    z[5,4,2]  R2440     -7.2713285684585571e-01
    z[5,4,2]  R2441     -7.5922089815139771e-01
    z[5,4,2]  R2442     -5.8087509870529175e-01
    z[5,4,2]  R2443     -7.8284674882888794e-01
    z[5,4,2]  R2444     -7.4088609218597412e-01
    z[5,4,2]  R2445     -0.635337233543396
    z[5,4,2]  R2446     -3.9858633279800415e-01
    z[5,4,2]  R2447     4.3616119772195816e-02
    z[5,4,2]  R2448     1.5644568204879761e-01
    z[5,4,2]  R2449     -9.8282612860202789e-02
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R2352     -1
    z[5,4,3]  R2353     1
    z[5,4,3]  R2360     6.6540360450744629e-01
    z[5,4,3]  R2361     6.5713709592819214e-01
    z[5,4,3]  R2362     5.0276738405227661e-01
    z[5,4,3]  R2363     3.6557447910308838e-01
    z[5,4,3]  R2364     3.9716669917106628e-01
    z[5,4,3]  R2365     3.7337687611579895e-01
    z[5,4,3]  R2366     4.5556488633155823e-01
    z[5,4,3]  R2367     1.1686177551746368e-01
    z[5,4,3]  R2368     5.0188434123992920e-01
    z[5,4,3]  R2369     2.3232667148113251e-01
    z[5,4,3]  R2370     -5.7432240247726440e-01
    z[5,4,3]  R2371     -6.3345789909362793e-01
    z[5,4,3]  R2372     -4.6149781346321106e-01
    z[5,4,3]  R2373     -4.6182355284690857e-01
    z[5,4,3]  R2374     -1.3038317859172821e-01
    z[5,4,3]  R2375     -5.3972136974334717e-01
    z[5,4,3]  R2376     -3.8895878195762634e-01
    z[5,4,3]  R2377     -5.3050237894058228e-01
    z[5,4,3]  R2378     -2.5320374965667725e-01
    z[5,4,3]  R2379     -4.2305126786231995e-01
    z[5,4,3]  R2380     2.9098740220069885e-01
    z[5,4,3]  R2381     -2.9129517078399658e-01
    z[5,4,3]  R2382     -1.4781875908374786e-01
    z[5,4,3]  R2383     -3.1002059578895569e-01
    z[5,4,3]  R2384     -3.9259654283523560e-01
    z[5,4,3]  R2385     -1.4276312291622162e-01
    z[5,4,3]  R2386     -2.5168719887733459e-01
    z[5,4,3]  R2387     -6.5503165125846863e-02
    z[5,4,3]  R2388     -1.3038103282451630e-01
    z[5,4,3]  R2389     -0.469923198223114
    z[5,4,3]  R2390     1.0379044711589813e-01
    z[5,4,3]  R2391     -1.3402193784713745e-01
    z[5,4,3]  R2392     -2.9712323099374771e-02
    z[5,4,3]  R2393     5.9156041592359543e-02
    z[5,4,3]  R2394     1.1013500392436981e-02
    z[5,4,3]  R2395     -4.3319210410118103e-01
    z[5,4,3]  R2396     -3.8658967614173889e-01
    z[5,4,3]  R2397     -4.2065268754959106e-01
    z[5,4,3]  R2398     -4.7309896349906921e-01
    z[5,4,3]  R2399     -4.2904523015022278e-01
    z[5,4,3]  R2400     1.5453018248081207e-01
    z[5,4,3]  R2401     2.4318028986454010e-01
    z[5,4,3]  R2402     -6.6407345235347748e-02
    z[5,4,3]  R2403     3.7617892958223820e-03
    z[5,4,3]  R2404     7.7589273452758789e-01
    z[5,4,3]  R2405     4.9217936396598816e-01
    z[5,4,3]  R2406     8.0812788009643555e-01
    z[5,4,3]  R2407     9.9210254848003387e-02
    z[5,4,3]  R2408     2.9624202847480774e-01
    z[5,4,3]  R2409     -5.8686983585357666e-01
    z[5,4,3]  R2410     2.3793120682239532e-01
    z[5,4,3]  R2411     1.7997060716152191e-01
    z[5,4,3]  R2412     -2.1408474445343018e-01
    z[5,4,3]  R2413     -3.9325478672981262e-01
    z[5,4,3]  R2414     -2.1021410822868347e-01
    z[5,4,3]  R2415     -3.5917416214942932e-01
    z[5,4,3]  R2416     1.9981622695922852e-02
    z[5,4,3]  R2417     -5.4983055591583252e-01
    z[5,4,3]  R2418     1.9537252373993397e-03
    z[5,4,3]  R2419     -5.0493568181991577e-01
    z[5,4,3]  R2420     2.7512183412909508e-02
    z[5,4,3]  R2421     5.0766932964324951e-01
    z[5,4,3]  R2422     -2.9457315802574158e-01
    z[5,4,3]  R2423     -4.6839483082294464e-02
    z[5,4,3]  R2424     -4.3036738038063049e-01
    z[5,4,3]  R2425     -0.267819881439209
    z[5,4,3]  R2426     -3.9078226685523987e-01
    z[5,4,3]  R2427     -2.8767085075378418e-01
    z[5,4,3]  R2428     -3.8902035355567932e-01
    z[5,4,3]  R2429     -0.190802201628685
    z[5,4,3]  R2430     5.1662659645080566e-01
    z[5,4,3]  R2431     1.0520192235708237e-01
    z[5,4,3]  R2432     -2.2982361912727356e-01
    z[5,4,3]  R2433     -5.8106422424316406e-01
    z[5,4,3]  R2434     -3.6560976505279541e-01
    z[5,4,3]  R2435     -6.9852042198181152e-01
    z[5,4,3]  R2436     -3.0261768028140068e-02
    z[5,4,3]  R2437     -6.6269993782043457e-02
    z[5,4,3]  R2438     -6.4941161870956421e-01
    z[5,4,3]  R2439     8.2603186368942261e-02
    z[5,4,3]  R2440     -2.2602368891239166e-01
    z[5,4,3]  R2441     -1.2361246347427368e-01
    z[5,4,3]  R2442     -5.3486543893814087e-01
    z[5,4,3]  R2443     -1.1051447689533234e-01
    z[5,4,3]  R2444     -6.4729940891265869e-01
    z[5,4,3]  R2445     -3.4381550550460815e-01
    z[5,4,3]  R2446     -3.5488963127136230e-01
    z[5,4,3]  R2447     0.317862868309021
    z[5,4,3]  R2448     1.6077440977096558e-01
    z[5,4,3]  R2449     4.6951431035995483e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R2354     -1
    z[5,4,4]  R2355     1
    z[5,4,4]  R2360     -5.6736266613006592e-01
    z[5,4,4]  R2361     -4.2338716983795166e-01
    z[5,4,4]  R2362     -2.7609494328498840e-01
    z[5,4,4]  R2363     -5.4130053520202637e-01
    z[5,4,4]  R2364     -5.4473882913589478e-01
    z[5,4,4]  R2365     -7.5190836191177368e-01
    z[5,4,4]  R2366     6.0095246881246567e-02
    z[5,4,4]  R2367     1.6605155169963837e-01
    z[5,4,4]  R2368     -2.0370914041996002e-01
    z[5,4,4]  R2369     2.3565191030502319e-01
    z[5,4,4]  R2370     1.3322633504867554e-01
    z[5,4,4]  R2371     -1.5834622085094452e-02
    z[5,4,4]  R2372     0.277626633644104
    z[5,4,4]  R2373     0.466239869594574
    z[5,4,4]  R2374     2.0291706547141075e-02
    z[5,4,4]  R2375     2.7662605047225952e-01
    z[5,4,4]  R2376     7.7883275225758553e-03
    z[5,4,4]  R2377     2.1679170429706573e-01
    z[5,4,4]  R2378     -1.0537905991077423e-01
    z[5,4,4]  R2379     0.0986253172159195
    z[5,4,4]  R2380     0.00849322509020567
    z[5,4,4]  R2381     2.1699893474578857e-01
    z[5,4,4]  R2382     3.9246338605880737e-01
    z[5,4,4]  R2383     3.7728101015090942e-01
    z[5,4,4]  R2384     5.4241657257080078e-02
    z[5,4,4]  R2385     0.154581680893898
    z[5,4,4]  R2386     3.2734036445617676e-01
    z[5,4,4]  R2387     6.6526606678962708e-02
    z[5,4,4]  R2388     1.0396488755941391e-01
    z[5,4,4]  R2389     -1.1083486676216125e-01
    z[5,4,4]  R2390     2.1375261247158051e-01
    z[5,4,4]  R2391     5.8546119928359985e-01
    z[5,4,4]  R2392     3.8419520854949951e-01
    z[5,4,4]  R2393     3.7921886891126633e-02
    z[5,4,4]  R2394     2.2218170762062073e-01
    z[5,4,4]  R2395     3.6676891148090363e-02
    z[5,4,4]  R2396     -7.9336911439895630e-02
    z[5,4,4]  R2397     -6.3870586454868317e-02
    z[5,4,4]  R2398     -1.1375338584184647e-01
    z[5,4,4]  R2399     -2.6194578409194946e-01
    z[5,4,4]  R2400     0.584718644618988
    z[5,4,4]  R2401     1.1929895728826523e-01
    z[5,4,4]  R2402     4.4568312168121338e-01
    z[5,4,4]  R2403     -1.9457225501537323e-01
    z[5,4,4]  R2404     -2.3900421336293221e-02
    z[5,4,4]  R2405     -3.1577959656715393e-01
    z[5,4,4]  R2406     -3.5803741216659546e-01
    z[5,4,4]  R2407     6.9361424446105957e-01
    z[5,4,4]  R2408     -0.651825487613678
    z[5,4,4]  R2409     1.3738542795181274e-01
    z[5,4,4]  R2410     -1.3454273343086243e-01
    z[5,4,4]  R2411     1.5022955834865570e-01
    z[5,4,4]  R2412     0.452536016702652
    z[5,4,4]  R2413     3.3214700222015381e-01
    z[5,4,4]  R2414     2.2784835100173950e-01
    z[5,4,4]  R2415     -1.3697463274002075e-01
    z[5,4,4]  R2416     1.7680658400058746e-01
    z[5,4,4]  R2417     -4.9967506527900696e-01
    z[5,4,4]  R2418     2.7726349234580994e-01
    z[5,4,4]  R2419     -4.2929565906524658e-01
    z[5,4,4]  R2420     -7.9094909131526947e-02
    z[5,4,4]  R2421     8.4954008460044861e-02
    z[5,4,4]  R2422     -3.1500864028930664e-01
    z[5,4,4]  R2423     -4.3252453207969666e-01
    z[5,4,4]  R2424     -8.6337188258767128e-03
    z[5,4,4]  R2425     -6.2996000051498413e-01
    z[5,4,4]  R2426     8.6528457701206207e-02
    z[5,4,4]  R2427     -2.3535829782485962e-01
    z[5,4,4]  R2428     2.9225587844848633e-01
    z[5,4,4]  R2429     -4.7899162769317627e-01
    z[5,4,4]  R2430     5.1167141646146774e-02
    z[5,4,4]  R2431     2.7436983585357666e-01
    z[5,4,4]  R2432     -1.1434942483901978e-01
    z[5,4,4]  R2433     -4.6427333354949951e-01
    z[5,4,4]  R2434     9.7543504089117050e-03
    z[5,4,4]  R2435     3.3553630113601685e-02
    z[5,4,4]  R2436     -4.8827984929084778e-01
    z[5,4,4]  R2437     9.5876671373844147e-02
    z[5,4,4]  R2438     -1.2067833542823792e-01
    z[5,4,4]  R2439     -4.4259798526763916e-01
    z[5,4,4]  R2440     -4.3967342376708984e-01
    z[5,4,4]  R2441     -1.3392937183380127e-01
    z[5,4,4]  R2442     -4.1266137361526489e-01
    z[5,4,4]  R2443     2.2943212091922760e-01
    z[5,4,4]  R2444     -1.1504572629928589e-01
    z[5,4,4]  R2445     -3.9065372943878174e-01
    z[5,4,4]  R2446     -6.8254613876342773e-01
    z[5,4,4]  R2447     -3.9675071835517883e-01
    z[5,4,4]  R2448     -4.9660202860832214e-01
    z[5,4,4]  R2449     -3.6722466349601746e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R2356     -1
    z[5,4,5]  R2357     1
    z[5,4,5]  R2360     -3.4532821178436279e-01
    z[5,4,5]  R2361     -2.1436698734760284e-02
    z[5,4,5]  R2362     2.7303391695022583e-01
    z[5,4,5]  R2363     1.1729851365089417e-01
    z[5,4,5]  R2364     4.1483619809150696e-01
    z[5,4,5]  R2365     3.1923133134841919e-01
    z[5,4,5]  R2366     -1.3287958502769470e-01
    z[5,4,5]  R2367     2.7967765927314758e-01
    z[5,4,5]  R2368     2.5065195560455322e-01
    z[5,4,5]  R2369     -2.0192395150661469e-01
    z[5,4,5]  R2370     1.4752630889415741e-01
    z[5,4,5]  R2371     1.8181920051574707e-01
    z[5,4,5]  R2372     0.220264732837677
    z[5,4,5]  R2373     -3.2586917281150818e-02
    z[5,4,5]  R2374     -5.7722595520317554e-03
    z[5,4,5]  R2375     -5.5649623274803162e-02
    z[5,4,5]  R2376     3.8544493913650513e-01
    z[5,4,5]  R2377     -2.5023165345191956e-01
    z[5,4,5]  R2378     9.4785392284393311e-02
    z[5,4,5]  R2379     2.4255488812923431e-01
    z[5,4,5]  R2380     -1.9831936806440353e-02
    z[5,4,5]  R2381     4.4322180747985840e-01
    z[5,4,5]  R2382     -1.4351183176040649e-01
    z[5,4,5]  R2383     2.0533630251884460e-01
    z[5,4,5]  R2384     5.4337686300277710e-01
    z[5,4,5]  R2385     3.7895879149436951e-01
    z[5,4,5]  R2386     5.9802955389022827e-01
    z[5,4,5]  R2387     -0.599342405796051
    z[5,4,5]  R2388     4.1543442010879517e-01
    z[5,4,5]  R2389     -1.1101827770471573e-01
    z[5,4,5]  R2390     4.6737310290336609e-01
    z[5,4,5]  R2391     2.1555164456367493e-01
    z[5,4,5]  R2392     0.607568085193634
    z[5,4,5]  R2393     0.532397449016571
    z[5,4,5]  R2394     -2.6702085137367249e-01
    z[5,4,5]  R2395     2.0080116391181946e-01
    z[5,4,5]  R2396     -6.3286215066909790e-02
    z[5,4,5]  R2397     -1.5741702169179916e-02
    z[5,4,5]  R2398     -1.3458141684532166e-01
    z[5,4,5]  R2399     1.3015043735504150e-01
    z[5,4,5]  R2400     1.1528528295457363e-02
    z[5,4,5]  R2401     0.46016725897789
    z[5,4,5]  R2402     3.6443573236465454e-01
    z[5,4,5]  R2403     -1.1830856651067734e-01
    z[5,4,5]  R2404     2.3036555945873260e-01
    z[5,4,5]  R2405     2.3484787344932556e-01
    z[5,4,5]  R2406     1.8928836286067963e-01
    z[5,4,5]  R2407     3.3975234627723694e-01
    z[5,4,5]  R2408     2.8387647867202759e-01
    z[5,4,5]  R2409     -2.4164432287216187e-01
    z[5,4,5]  R2410     2.3776585236191750e-02
    z[5,4,5]  R2411     -2.4114778637886047e-01
    z[5,4,5]  R2412     1.0148690640926361e-01
    z[5,4,5]  R2413     3.1827643513679504e-02
    z[5,4,5]  R2414     -1.2022651731967926e-01
    z[5,4,5]  R2415     -4.6280834823846817e-02
    z[5,4,5]  R2416     -3.2995335757732391e-02
    z[5,4,5]  R2417     -2.3742890357971191e-01
    z[5,4,5]  R2418     -2.3853017017245293e-02
    z[5,4,5]  R2419     -3.4963092207908630e-01
    z[5,4,5]  R2420     1.0461068153381348e-01
    z[5,4,5]  R2421     -4.8696655035018921e-01
    z[5,4,5]  R2422     3.3102143555879593e-02
    z[5,4,5]  R2423     -3.9775168895721436e-01
    z[5,4,5]  R2424     -3.0349004268646240e-01
    z[5,4,5]  R2425     -6.0651499032974243e-01
    z[5,4,5]  R2426     -3.0408149957656860e-01
    z[5,4,5]  R2427     7.3091499507427216e-02
    z[5,4,5]  R2428     5.0470467656850815e-02
    z[5,4,5]  R2429     -4.5190271735191345e-01
    z[5,4,5]  R2430     -6.0405898839235306e-02
    z[5,4,5]  R2431     -4.4078135490417480e-01
    z[5,4,5]  R2432     -2.4801802635192871e-01
    z[5,4,5]  R2433     1.0184463113546371e-01
    z[5,4,5]  R2434     -3.9927187561988831e-01
    z[5,4,5]  R2435     4.3250724673271179e-02
    z[5,4,5]  R2436     -4.8846244812011719e-01
    z[5,4,5]  R2437     -4.4637325406074524e-01
    z[5,4,5]  R2438     -1.9911728799343109e-01
    z[5,4,5]  R2439     -5.6191688776016235e-01
    z[5,4,5]  R2440     -1.7829376459121704e-01
    z[5,4,5]  R2441     -1.8528230488300323e-01
    z[5,4,5]  R2442     2.2916388511657715e-01
    z[5,4,5]  R2443     2.1229531615972519e-02
    z[5,4,5]  R2444     -2.6011077687144279e-02
    z[5,4,5]  R2445     -4.5171543955802917e-01
    z[5,4,5]  R2446     -1.7164134979248047e-01
    z[5,4,5]  R2447     2.0519137382507324e-01
    z[5,4,5]  R2448     8.1515289843082428e-02
    z[5,4,5]  R2449     -2.0793452858924866e-01
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R2358     -1
    z[5,4,6]  R2359     1
    z[5,4,6]  R2360     -2.0312076434493065e-02
    z[5,4,6]  R2361     1.2939487397670746e-01
    z[5,4,6]  R2362     1.0314755886793137e-01
    z[5,4,6]  R2363     3.5929429531097412e-01
    z[5,4,6]  R2364     -4.9746152758598328e-01
    z[5,4,6]  R2365     3.5357251763343811e-01
    z[5,4,6]  R2366     -5.3053814172744751e-01
    z[5,4,6]  R2367     -1.2930710613727570e-01
    z[5,4,6]  R2368     -5.7356774806976318e-01
    z[5,4,6]  R2369     -3.0101948976516724e-01
    z[5,4,6]  R2370     1.8088242411613464e-01
    z[5,4,6]  R2371     4.8972561955451965e-01
    z[5,4,6]  R2372     3.6241775751113892e-01
    z[5,4,6]  R2373     -2.9049712419509888e-01
    z[5,4,6]  R2374     -2.3624455928802490e-01
    z[5,4,6]  R2375     4.2786914110183716e-01
    z[5,4,6]  R2376     2.8338947892189026e-01
    z[5,4,6]  R2377     4.8365625739097595e-01
    z[5,4,6]  R2378     0.19088114798069
    z[5,4,6]  R2379     6.0252988338470459e-01
    z[5,4,6]  R2380     -0.0972653478384018
    z[5,4,6]  R2381     5.3693417459726334e-02
    z[5,4,6]  R2382     6.0087740421295166e-01
    z[5,4,6]  R2383     -5.4085552692413330e-01
    z[5,4,6]  R2384     -1.0240268707275391e-01
    z[5,4,6]  R2385     1.4011496305465698e-01
    z[5,4,6]  R2386     3.1017169356346130e-01
    z[5,4,6]  R2387     5.2726560831069946e-01
    z[5,4,6]  R2388     5.6427329778671265e-01
    z[5,4,6]  R2389     -1.6300034523010254e-01
    z[5,4,6]  R2390     -2.3612719774246216e-01
    z[5,4,6]  R2391     6.5532989799976349e-02
    z[5,4,6]  R2392     -1.9043833017349243e-01
    z[5,4,6]  R2393     -1.1923649907112122e-01
    z[5,4,6]  R2394     4.7771230340003967e-01
    z[5,4,6]  R2395     1.5649099647998810e-01
    z[5,4,6]  R2396     5.2848167717456818e-02
    z[5,4,6]  R2397     -6.4299695193767548e-02
    z[5,4,6]  R2398     2.0884481072425842e-01
    z[5,4,6]  R2399     4.1663125157356262e-01
    z[5,4,6]  R2400     -3.2446052879095078e-02
    z[5,4,6]  R2401     -2.1736724674701691e-01
    z[5,4,6]  R2402     -1.5648598968982697e-01
    z[5,4,6]  R2403     2.8492954373359680e-01
    z[5,4,6]  R2404     3.1117478013038635e-01
    z[5,4,6]  R2405     -3.0813741683959961e-01
    z[5,4,6]  R2406     -1.0823823511600494e-01
    z[5,4,6]  R2407     -3.7070021033287048e-01
    z[5,4,6]  R2408     4.2664456367492676e-01
    z[5,4,6]  R2409     4.2532593011856079e-01
    z[5,4,6]  R2410     -1.6901694238185883e-01
    z[5,4,6]  R2411     -4.4010091572999954e-02
    z[5,4,6]  R2412     4.6856218576431274e-01
    z[5,4,6]  R2413     2.0871374011039734e-01
    z[5,4,6]  R2414     2.9726946726441383e-02
    z[5,4,6]  R2415     1.9981640577316284e-01
    z[5,4,6]  R2416     1.1819269508123398e-01
    z[5,4,6]  R2417     -5.7206183671951294e-02
    z[5,4,6]  R2418     5.2432626485824585e-01
    z[5,4,6]  R2419     1.7567428946495056e-01
    z[5,4,6]  R2420     5.4454866796731949e-02
    z[5,4,6]  R2421     1.2733514606952667e-01
    z[5,4,6]  R2422     2.4166754155885428e-04
    z[5,4,6]  R2423     -2.7993968129158020e-01
    z[5,4,6]  R2424     1.1713202297687531e-01
    z[5,4,6]  R2425     -1.8819177150726318e-01
    z[5,4,6]  R2426     -1.8090275116264820e-03
    z[5,4,6]  R2427     1.0212234407663345e-01
    z[5,4,6]  R2428     -1.0798142850399017e-01
    z[5,4,6]  R2429     1.6660369932651520e-01
    z[5,4,6]  R2430     -1.1118955910205841e-01
    z[5,4,6]  R2431     2.0655590295791626e-01
    z[5,4,6]  R2432     -7.4333444237709045e-02
    z[5,4,6]  R2433     1.7864930629730225e-01
    z[5,4,6]  R2434     -1.8564037978649139e-01
    z[5,4,6]  R2435     -1.0917651653289795e-01
    z[5,4,6]  R2436     2.7678442001342773e-01
    z[5,4,6]  R2437     1.6901065409183502e-01
    z[5,4,6]  R2438     2.5781095027923584e-01
    z[5,4,6]  R2439     2.4777625501155853e-01
    z[5,4,6]  R2440     -3.5946812480688095e-02
    z[5,4,6]  R2441     -1.0145907104015350e-01
    z[5,4,6]  R2442     6.8740755319595337e-02
    z[5,4,6]  R2443     -2.2169624269008636e-01
    z[5,4,6]  R2444     1.0318201780319214e-01
    z[5,4,6]  R2445     2.4264785461127758e-03
    z[5,4,6]  R2446     7.4183098971843719e-02
    z[5,4,6]  R2447     -7.1695089340209961e-02
    z[5,4,6]  R2448     1.1821021884679794e-01
    z[5,4,6]  R2449     1.2351055443286896e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R54       1
    RHS1      R55       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,3]
 BV BND1      phi[3,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[6,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,4]
 BV BND1      phi[4,1]
 BV BND1      phi[1,5]
 BV BND1      phi[5,1]
 BV BND1      phi[2,5]
 BV BND1      phi[5,2]
 BV BND1      phi[2,7]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[6,3]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[5,7]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,3,0]
 FR BND1      z[0,3,1]
 FR BND1      z[0,3,2]
 FR BND1      z[0,3,3]
 FR BND1      z[0,3,4]
 FR BND1      z[0,3,5]
 FR BND1      z[0,3,6]
 FR BND1      z[3,0,0]
 FR BND1      z[3,0,1]
 FR BND1      z[3,0,2]
 FR BND1      z[3,0,3]
 FR BND1      z[3,0,4]
 FR BND1      z[3,0,5]
 FR BND1      z[3,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,4,0]
 FR BND1      z[1,4,1]
 FR BND1      z[1,4,2]
 FR BND1      z[1,4,3]
 FR BND1      z[1,4,4]
 FR BND1      z[1,4,5]
 FR BND1      z[1,4,6]
 FR BND1      z[4,1,0]
 FR BND1      z[4,1,1]
 FR BND1      z[4,1,2]
 FR BND1      z[4,1,3]
 FR BND1      z[4,1,4]
 FR BND1      z[4,1,5]
 FR BND1      z[4,1,6]
 FR BND1      z[1,5,0]
 FR BND1      z[1,5,1]
 FR BND1      z[1,5,2]
 FR BND1      z[1,5,3]
 FR BND1      z[1,5,4]
 FR BND1      z[1,5,5]
 FR BND1      z[1,5,6]
 FR BND1      z[5,1,0]
 FR BND1      z[5,1,1]
 FR BND1      z[5,1,2]
 FR BND1      z[5,1,3]
 FR BND1      z[5,1,4]
 FR BND1      z[5,1,5]
 FR BND1      z[5,1,6]
 FR BND1      z[2,5,0]
 FR BND1      z[2,5,1]
 FR BND1      z[2,5,2]
 FR BND1      z[2,5,3]
 FR BND1      z[2,5,4]
 FR BND1      z[2,5,5]
 FR BND1      z[2,5,6]
 FR BND1      z[5,2,0]
 FR BND1      z[5,2,1]
 FR BND1      z[5,2,2]
 FR BND1      z[5,2,3]
 FR BND1      z[5,2,4]
 FR BND1      z[5,2,5]
 FR BND1      z[5,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
ENDATA
