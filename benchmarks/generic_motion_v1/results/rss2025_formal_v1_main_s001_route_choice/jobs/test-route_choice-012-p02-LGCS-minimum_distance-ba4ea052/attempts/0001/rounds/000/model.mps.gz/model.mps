NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 E  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  R2670   
 L  R2671   
 L  R2672   
 L  R2673   
 L  R2674   
 L  R2675   
 L  R2676   
 L  R2677   
 L  R2678   
 L  R2679   
 L  R2680   
 L  R2681   
 L  R2682   
 L  R2683   
 L  R2684   
 L  R2685   
 L  R2686   
 L  R2687   
 L  R2688   
 L  R2689   
 L  R2690   
 L  R2691   
 L  R2692   
 L  R2693   
 L  R2694   
 L  R2695   
 L  R2696   
 L  R2697   
 L  R2698   
 L  R2699   
 L  R2700   
 L  R2701   
 L  R2702   
 L  R2703   
 L  R2704   
 L  R2705   
 L  R2706   
 L  R2707   
 L  R2708   
 L  R2709   
 L  R2710   
 L  R2711   
 L  R2712   
 L  R2713   
 L  R2714   
 L  R2715   
 L  R2716   
 L  R2717   
 L  R2718   
 L  R2719   
 L  R2720   
 L  R2721   
 L  R2722   
 L  R2723   
 L  R2724   
 L  R2725   
 L  R2726   
 L  R2727   
 L  R2728   
 L  R2729   
 L  R2730   
 L  R2731   
 L  R2732   
 L  R2733   
 L  R2734   
 L  R2735   
 L  R2736   
 L  R2737   
 L  R2738   
 L  R2739   
 L  R2740   
 L  R2741   
 L  R2742   
 L  R2743   
 L  R2744   
 L  R2745   
 L  R2746   
 L  R2747   
 L  R2748   
 L  R2749   
 L  R2750   
 L  R2751   
 L  R2752   
 L  R2753   
 L  R2754   
 L  R2755   
 L  R2756   
 L  R2757   
 L  R2758   
 L  R2759   
 L  R2760   
 L  R2761   
 L  R2762   
 L  R2763   
 L  R2764   
 L  R2765   
 L  R2766   
 L  R2767   
 L  R2768   
 L  R2769   
 L  R2770   
 L  R2771   
 L  R2772   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R74       -3.0999999046325684e+00
    phi[0,1]  R75       -3.0999999046325684e+00
    phi[0,1]  R76       -2.2400000095367432e+00
    phi[0,1]  R77       -2.2400000095367432e+00
    phi[0,1]  R78       -3.0999999046325684e+00
    phi[0,1]  R79       -3.0999999046325684e+00
    phi[0,1]  R80       -2.5699999332427979e+00
    phi[0,1]  R81       -2.5699999332427979e+00
    phi[0,1]  R82       -3.0999999046325684e+00
    phi[0,1]  R83       -3.0999999046325684e+00
    phi[0,1]  R84       -2.0899999141693115e+00
    phi[0,1]  R85       -2.0899999141693115e+00
    phi[0,1]  R86       -3.0999999046325684e+00
    phi[0,1]  R87       -3.0999999046325684e+00
    phi[0,1]  R88       1.7145581245422363e+00
    phi[0,1]  R89       1.4445383548736572e+00
    phi[0,1]  R90       1.3001598119735718e+00
    phi[0,1]  R91       -4.8051971197128296e-01
    phi[0,1]  R92       2.7111512422561646e-01
    phi[0,1]  R93       0.496223121881485
    phi[0,1]  R94       -2.9247125983238220e-01
    phi[0,1]  R95       5.6794756650924683e-01
    phi[0,1]  R96       6.0412257909774780e-01
    phi[0,1]  R97       2.3192022740840912e-01
    phi[0,1]  R98       -2.2571575641632080e+00
    phi[0,1]  R99       -2.4981462955474854e+00
    phi[0,1]  R100      -2.8391900062561035e+00
    phi[0,1]  R101      -2.6086461544036865e+00
    phi[0,1]  R102      -1.8027795553207397e+00
    phi[0,1]  R103      -2.3305709362030029e+00
    phi[0,1]  R104      -2.6670083999633789e+00
    phi[0,1]  R105      -1.1279600858688354e+00
    phi[0,1]  R106      -1.6650457382202148e+00
    phi[0,1]  R107      -2.0190687179565430e+00
    phi[0,1]  R108      -2.3345603942871094e+00
    phi[0,1]  R109      -1.9748090505599976e+00
    phi[0,1]  R110      -1.78983736038208
    phi[0,1]  R111      4.5438376069068909e-01
    phi[0,1]  R112      6.7388898134231567e-01
    phi[0,1]  R113      3.9373758435249329e-01
    phi[0,1]  R114      -1.3576176166534424e+00
    phi[0,1]  R115      -2.8481829166412354e+00
    phi[0,1]  R116      -3.2946033477783203e+00
    phi[0,1]  R117      -2.6888034343719482e+00
    phi[0,1]  R118      -1.1842092275619507e+00
    phi[0,1]  R119      -1.1080672740936279e+00
    phi[0,1]  R120      -1.0955878496170044e+00
    phi[0,1]  R121      -2.0255734920501709e+00
    phi[0,1]  R122      4.4700416922569275e-01
    phi[0,1]  R123      -1.4050878584384918e-01
    phi[0,1]  R124      -1.1859025955200195e+00
    phi[0,1]  R125      -1.5169923305511475e+00
    phi[0,1]  R126      3.9713934063911438e-01
    phi[0,1]  R127      0.531472384929657
    phi[0,1]  R128      8.7951347231864929e-02
    phi[0,1]  R129      -3.3694958686828613e-01
    phi[0,1]  R130      5.9234869480133057e-01
    phi[0,1]  R131      1.1230713874101639e-01
    phi[0,1]  R132      5.5940353870391846e-01
    phi[0,1]  R133      6.4491838216781616e-01
    phi[0,1]  R134      1.1368455886840820e+00
    phi[0,1]  R135      5.1497679948806763e-01
    phi[0,1]  R136      9.6771270036697388e-01
    phi[0,1]  R137      2.1446537226438522e-02
    phi[0,1]  R138      -1.6293519735336304e+00
    phi[0,1]  R139      -1.8735386133193970e+00
    phi[0,1]  R140      -1.8169267177581787e+00
    phi[0,1]  R141      -1.4900690317153931e+00
    phi[0,1]  R142      -1.4974399805068970e+00
    phi[0,1]  R143      -2.22248911857605
    phi[0,1]  R144      -0.912834644317627
    phi[0,1]  R145      -1.4112000465393066e+00
    phi[0,1]  R146      -1.5503877401351929e+00
    phi[0,1]  R147      -2.6074275970458984e+00
    phi[0,1]  R148      -2.0081003010272980e-01
    phi[0,1]  R149      -1.5397937297821045e+00
    phi[0,1]  R150      -1.7660311460494995e+00
    phi[0,1]  R151      -1.6142354011535645e+00
    phi[0,1]  R152      -1.9802361726760864e+00
    phi[0,1]  R153      -1.4654186964035034e+00
    phi[0,1]  R154      -1.4228112697601318e+00
    phi[0,1]  R155      -1.18171226978302
    phi[0,1]  R156      -2.2047138214111328e+00
    phi[0,1]  R157      -2.8698575496673584e+00
    phi[0,1]  R158      -1.2087937593460083e+00
    phi[0,1]  R159      -2.2263717651367188e+00
    phi[0,1]  R160      -1.2378278970718384e+00
    phi[0,1]  R161      -2.0760664939880371e+00
    phi[0,1]  R162      -1.5134587883949280e-03
    phi[0,1]  R163      -0.637428879737854
    phi[0,1]  R164      3.1015443801879883e-01
    phi[0,1]  R165      -2.3218820095062256e+00
    phi[0,1]  R166      -2.1789546012878418e+00
    phi[0,1]  R167      -1.2254248857498169e+00
    phi[0,1]  R168      1.3291998207569122e-01
    phi[0,1]  R169      -1.3452390432357788e+00
    phi[0,1]  R170      2.5147804990410805e-03
    phi[0,1]  R171      -1.7297762632369995e+00
    phi[0,1]  R172      -5.7918506860733032e-01
    phi[0,1]  R173      -3.2762501239776611e+00
    phi[0,1]  R174      -1.3444849252700806e+00
    phi[0,1]  R175      -1.0472964048385620e+00
    phi[0,1]  R176      -7.1784019470214844e-01
    phi[0,1]  R177      -2.0061371326446533e+00
    phi[0,1]  R178      -1.6152055263519287e+00
    phi[0,1]  R179      -1.8375148773193359e+00
    phi[0,1]  R180      -1.4262689352035522e+00
    phi[0,1]  R181      -2.4771697521209717e+00
    phi[0,1]  R182      -0.0289363544434309
    phi[0,1]  R183      -2.5869073867797852e+00
    phi[0,1]  R184      -8.6672621965408325e-01
    phi[0,1]  R185      -1.6943770647048950e+00
    phi[0,1]  R186      -6.1104822158813477e-01
    phi[0,1]  R187      -3.3916926383972168e-01
    phi[0,1]  R188      1.3346369564533234e-01
    phi[0,1]  R189      -1.6124694347381592e+00
    phi[0,1]  R190      -2.1778790950775146e+00
    phi[0,1]  R191      -4.5567941665649414e-01
    phi[0,1]  R192      -1.0057600587606430e-01
    phi[0,1]  R193      -1.4860936403274536e+00
    phi[0,1]  R194      -8.1424689292907715e-01
    phi[0,1]  R195      -2.0693848133087158e+00
    phi[0,1]  R196      -0.861158013343811
    phi[0,1]  R197      -2.0915164947509766e+00
    phi[0,1]  R198      -5.9360277652740479e-01
    phi[0,1]  R199      -2.4567847251892090e+00
    phi[0,1]  R200      -2.6184012889862061e+00
    phi[0,1]  R201      -1.4719244241714478e+00
    phi[0,1]  R202      -1.2461595535278320e+00
    phi[0,1]  R203      -1.5171217918395996e+00
    phi[0,1]  R204      -2.2083458900451660e+00
    phi[0,1]  R205      -1.9676368236541748e+00
    phi[0,1]  R206      -1.4736702442169189e+00
    phi[0,1]  R207      -1.2641810178756714e+00
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R208      -3.0999999046325684e+00
    phi[1,0]  R209      -3.0999999046325684e+00
    phi[1,0]  R210      -2.2400000095367432e+00
    phi[1,0]  R211      -2.2400000095367432e+00
    phi[1,0]  R212      -3.0999999046325684e+00
    phi[1,0]  R213      -3.0999999046325684e+00
    phi[1,0]  R214      -2.5699999332427979e+00
    phi[1,0]  R215      -2.5699999332427979e+00
    phi[1,0]  R216      -3.0999999046325684e+00
    phi[1,0]  R217      -3.0999999046325684e+00
    phi[1,0]  R218      -2.0899999141693115e+00
    phi[1,0]  R219      -2.0899999141693115e+00
    phi[1,0]  R220      -3.0999999046325684e+00
    phi[1,0]  R221      -3.0999999046325684e+00
    phi[1,0]  R222      8.7951347231864929e-02
    phi[1,0]  R223      -3.3694958686828613e-01
    phi[1,0]  R224      5.9234869480133057e-01
    phi[1,0]  R225      1.1230713874101639e-01
    phi[1,0]  R226      5.5940353870391846e-01
    phi[1,0]  R227      6.4491838216781616e-01
    phi[1,0]  R228      1.1368455886840820e+00
    phi[1,0]  R229      5.1497679948806763e-01
    phi[1,0]  R230      9.6771270036697388e-01
    phi[1,0]  R231      2.1446537226438522e-02
    phi[1,0]  R232      -1.6293519735336304e+00
    phi[1,0]  R233      -1.8735386133193970e+00
    phi[1,0]  R234      -1.8169267177581787e+00
    phi[1,0]  R235      -1.4900690317153931e+00
    phi[1,0]  R236      -1.4974399805068970e+00
    phi[1,0]  R237      -2.22248911857605
    phi[1,0]  R238      -0.912834644317627
    phi[1,0]  R239      -1.4112000465393066e+00
    phi[1,0]  R240      -1.5503877401351929e+00
    phi[1,0]  R241      -2.6074275970458984e+00
    phi[1,0]  R242      -2.0081003010272980e-01
    phi[1,0]  R243      -1.5397937297821045e+00
    phi[1,0]  R244      -1.7660311460494995e+00
    phi[1,0]  R245      -1.6142354011535645e+00
    phi[1,0]  R246      -1.9802361726760864e+00
    phi[1,0]  R247      -1.4654186964035034e+00
    phi[1,0]  R248      -1.4228112697601318e+00
    phi[1,0]  R249      -1.18171226978302
    phi[1,0]  R250      -2.2047138214111328e+00
    phi[1,0]  R251      -2.8698575496673584e+00
    phi[1,0]  R252      -1.2087937593460083e+00
    phi[1,0]  R253      -2.2263717651367188e+00
    phi[1,0]  R254      -1.2378278970718384e+00
    phi[1,0]  R255      -2.0760664939880371e+00
    phi[1,0]  R256      -1.5134587883949280e-03
    phi[1,0]  R257      -0.637428879737854
    phi[1,0]  R258      3.1015443801879883e-01
    phi[1,0]  R259      -2.3218820095062256e+00
    phi[1,0]  R260      -2.1789546012878418e+00
    phi[1,0]  R261      -1.2254248857498169e+00
    phi[1,0]  R262      1.3291998207569122e-01
    phi[1,0]  R263      -1.3452390432357788e+00
    phi[1,0]  R264      2.5147804990410805e-03
    phi[1,0]  R265      -1.7297762632369995e+00
    phi[1,0]  R266      -5.7918506860733032e-01
    phi[1,0]  R267      -3.2762501239776611e+00
    phi[1,0]  R268      -1.3444849252700806e+00
    phi[1,0]  R269      -1.0472964048385620e+00
    phi[1,0]  R270      -7.1784019470214844e-01
    phi[1,0]  R271      -2.0061371326446533e+00
    phi[1,0]  R272      -1.6152055263519287e+00
    phi[1,0]  R273      -1.8375148773193359e+00
    phi[1,0]  R274      -1.4262689352035522e+00
    phi[1,0]  R275      -2.4771697521209717e+00
    phi[1,0]  R276      -0.0289363544434309
    phi[1,0]  R277      -2.5869073867797852e+00
    phi[1,0]  R278      -8.6672621965408325e-01
    phi[1,0]  R279      -1.6943770647048950e+00
    phi[1,0]  R280      -6.1104822158813477e-01
    phi[1,0]  R281      -3.3916926383972168e-01
    phi[1,0]  R282      1.3346369564533234e-01
    phi[1,0]  R283      -1.6124694347381592e+00
    phi[1,0]  R284      -2.1778790950775146e+00
    phi[1,0]  R285      -4.5567941665649414e-01
    phi[1,0]  R286      -1.0057600587606430e-01
    phi[1,0]  R287      -1.4860936403274536e+00
    phi[1,0]  R288      -8.1424689292907715e-01
    phi[1,0]  R289      -2.0693848133087158e+00
    phi[1,0]  R290      -0.861158013343811
    phi[1,0]  R291      -2.0915164947509766e+00
    phi[1,0]  R292      -5.9360277652740479e-01
    phi[1,0]  R293      -2.4567847251892090e+00
    phi[1,0]  R294      -2.6184012889862061e+00
    phi[1,0]  R295      -1.4719244241714478e+00
    phi[1,0]  R296      -1.2461595535278320e+00
    phi[1,0]  R297      -1.5171217918395996e+00
    phi[1,0]  R298      -2.2083458900451660e+00
    phi[1,0]  R299      -1.9676368236541748e+00
    phi[1,0]  R300      -1.4736702442169189e+00
    phi[1,0]  R301      -1.2641810178756714e+00
    phi[1,0]  R302      1.7145581245422363e+00
    phi[1,0]  R303      1.4445383548736572e+00
    phi[1,0]  R304      1.3001598119735718e+00
    phi[1,0]  R305      -4.8051971197128296e-01
    phi[1,0]  R306      2.7111512422561646e-01
    phi[1,0]  R307      0.496223121881485
    phi[1,0]  R308      -2.9247125983238220e-01
    phi[1,0]  R309      5.6794756650924683e-01
    phi[1,0]  R310      6.0412257909774780e-01
    phi[1,0]  R311      2.3192022740840912e-01
    phi[1,0]  R312      -2.2571575641632080e+00
    phi[1,0]  R313      -2.4981462955474854e+00
    phi[1,0]  R314      -2.8391900062561035e+00
    phi[1,0]  R315      -2.6086461544036865e+00
    phi[1,0]  R316      -1.8027795553207397e+00
    phi[1,0]  R317      -2.3305709362030029e+00
    phi[1,0]  R318      -2.6670083999633789e+00
    phi[1,0]  R319      -1.1279600858688354e+00
    phi[1,0]  R320      -1.6650457382202148e+00
    phi[1,0]  R321      -2.0190687179565430e+00
    phi[1,0]  R322      -2.3345603942871094e+00
    phi[1,0]  R323      -1.9748090505599976e+00
    phi[1,0]  R324      -1.78983736038208
    phi[1,0]  R325      4.5438376069068909e-01
    phi[1,0]  R326      6.7388898134231567e-01
    phi[1,0]  R327      3.9373758435249329e-01
    phi[1,0]  R328      -1.3576176166534424e+00
    phi[1,0]  R329      -2.8481829166412354e+00
    phi[1,0]  R330      -3.2946033477783203e+00
    phi[1,0]  R331      -2.6888034343719482e+00
    phi[1,0]  R332      -1.1842092275619507e+00
    phi[1,0]  R333      -1.1080672740936279e+00
    phi[1,0]  R334      -1.0955878496170044e+00
    phi[1,0]  R335      -2.0255734920501709e+00
    phi[1,0]  R336      4.4700416922569275e-01
    phi[1,0]  R337      -1.4050878584384918e-01
    phi[1,0]  R338      -1.1859025955200195e+00
    phi[1,0]  R339      -1.5169923305511475e+00
    phi[1,0]  R340      3.9713934063911438e-01
    phi[1,0]  R341      0.531472384929657
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R342      -3.0999999046325684e+00
    phi[0,4]  R343      -3.0999999046325684e+00
    phi[0,4]  R344      -2.2400000095367432e+00
    phi[0,4]  R345      -2.2400000095367432e+00
    phi[0,4]  R346      -3.0999999046325684e+00
    phi[0,4]  R347      -3.0999999046325684e+00
    phi[0,4]  R348      -2.5699999332427979e+00
    phi[0,4]  R349      -2.5699999332427979e+00
    phi[0,4]  R350      -3.0999999046325684e+00
    phi[0,4]  R351      -3.0999999046325684e+00
    phi[0,4]  R352      -2.0899999141693115e+00
    phi[0,4]  R353      -2.0899999141693115e+00
    phi[0,4]  R354      -3.0999999046325684e+00
    phi[0,4]  R355      -3.0999999046325684e+00
    phi[0,4]  R356      1.7145581245422363e+00
    phi[0,4]  R357      1.4445383548736572e+00
    phi[0,4]  R358      1.3001598119735718e+00
    phi[0,4]  R359      -4.8051971197128296e-01
    phi[0,4]  R360      2.7111512422561646e-01
    phi[0,4]  R361      0.496223121881485
    phi[0,4]  R362      -2.9247125983238220e-01
    phi[0,4]  R363      5.6794756650924683e-01
    phi[0,4]  R364      6.0412257909774780e-01
    phi[0,4]  R365      2.3192022740840912e-01
    phi[0,4]  R366      -2.2571575641632080e+00
    phi[0,4]  R367      -2.4981462955474854e+00
    phi[0,4]  R368      -2.8391900062561035e+00
    phi[0,4]  R369      -2.6086461544036865e+00
    phi[0,4]  R370      -1.8027795553207397e+00
    phi[0,4]  R371      -2.3305709362030029e+00
    phi[0,4]  R372      -2.6670083999633789e+00
    phi[0,4]  R373      -1.1279600858688354e+00
    phi[0,4]  R374      -1.6650457382202148e+00
    phi[0,4]  R375      -2.0190687179565430e+00
    phi[0,4]  R376      -2.3345603942871094e+00
    phi[0,4]  R377      -1.9748090505599976e+00
    phi[0,4]  R378      -1.78983736038208
    phi[0,4]  R379      4.5438376069068909e-01
    phi[0,4]  R380      6.7388898134231567e-01
    phi[0,4]  R381      3.9373758435249329e-01
    phi[0,4]  R382      -1.3576176166534424e+00
    phi[0,4]  R383      -2.8481829166412354e+00
    phi[0,4]  R384      -3.2946033477783203e+00
    phi[0,4]  R385      -2.6888034343719482e+00
    phi[0,4]  R386      -1.1842092275619507e+00
    phi[0,4]  R387      -1.1080672740936279e+00
    phi[0,4]  R388      -1.0955878496170044e+00
    phi[0,4]  R389      -2.0255734920501709e+00
    phi[0,4]  R390      4.4700416922569275e-01
    phi[0,4]  R391      -1.4050878584384918e-01
    phi[0,4]  R392      -1.1859025955200195e+00
    phi[0,4]  R393      -1.5169923305511475e+00
    phi[0,4]  R394      3.9713934063911438e-01
    phi[0,4]  R395      0.531472384929657
    phi[0,4]  R396      6.1045378446578979e-01
    phi[0,4]  R397      1.5194685459136963e+00
    phi[0,4]  R398      1.7441809177398682e+00
    phi[0,4]  R399      2.1775019168853760e-01
    phi[0,4]  R400      5.4810017347335815e-01
    phi[0,4]  R401      8.0885022878646851e-01
    phi[0,4]  R402      1.7800904810428619e-01
    phi[0,4]  R403      -1.1691821366548538e-01
    phi[0,4]  R404      -1.2544251680374146e+00
    phi[0,4]  R405      -4.9588072299957275e-01
    phi[0,4]  R406      -1.8220334053039551e+00
    phi[0,4]  R407      -1.9680370092391968e+00
    phi[0,4]  R408      -1.83860182762146
    phi[0,4]  R409      -2.5332596302032471e+00
    phi[0,4]  R410      -2.6017794609069824e+00
    phi[0,4]  R411      -2.8047809600830078e+00
    phi[0,4]  R412      -3.0139188766479492e+00
    phi[0,4]  R413      -2.9120640754699707e+00
    phi[0,4]  R414      -1.8599801063537598e+00
    phi[0,4]  R415      -2.2048938274383545e+00
    phi[0,4]  R416      -5.2014064788818359e-01
    phi[0,4]  R417      -2.3481199741363525e+00
    phi[0,4]  R418      -2.2166116237640381e+00
    phi[0,4]  R419      -7.9038292169570923e-01
    phi[0,4]  R420      -1.3059748411178589e+00
    phi[0,4]  R421      -2.5339090824127197e+00
    phi[0,4]  R422      -1.5853928327560425e+00
    phi[0,4]  R423      -1.5559942722320557e+00
    phi[0,4]  R424      -2.1704151630401611e+00
    phi[0,4]  R425      -1.5431559085845947e+00
    phi[0,4]  R426      -1.0972702503204346e+00
    phi[0,4]  R427      -1.6390556097030640e+00
    phi[0,4]  R428      -1.5726720094680786e+00
    phi[0,4]  R429      -1.0558334589004517e+00
    phi[0,4]  R430      -2.3605084419250488e+00
    phi[0,4]  R431      -1.8757507801055908e+00
    phi[0,4]  R432      -1.0681279897689819e+00
    phi[0,4]  R433      -2.3651778697967529e+00
    phi[0,4]  R434      -3.4891297817230225e+00
    phi[0,4]  R435      -2.0149352550506592e+00
    phi[0,4]  R436      -1.51680588722229
    phi[0,4]  R437      -7.3832297325134277e-01
    phi[0,4]  R438      -9.9721217155456543e-01
    phi[0,4]  R439      -1.7784869670867920e+00
    phi[0,4]  R440      -2.0258498191833496e+00
    phi[0,4]  R441      -1.0495134592056274e+00
    phi[0,4]  R442      -3.7982496619224548e-01
    phi[0,4]  R443      -1.4693911075592041e+00
    phi[0,4]  R444      -1.6135748624801636e+00
    phi[0,4]  R445      -3.2682735919952393e+00
    phi[0,4]  R446      -2.0086922645568848e+00
    phi[0,4]  R447      -1.2367788553237915e+00
    phi[0,4]  R448      -1.1788260936737061e+00
    phi[0,4]  R449      -1.8245620727539062e+00
    phi[0,4]  R450      -1.5888966321945190e+00
    phi[0,4]  R451      -6.3916212320327759e-01
    phi[0,4]  R452      -1.0067584514617920e+00
    phi[0,4]  R453      -1.6372170448303223e+00
    phi[0,4]  R454      -1.3500940799713135e+00
    phi[0,4]  R455      -1.7709525823593140e+00
    phi[0,4]  R456      -9.8480802774429321e-01
    phi[0,4]  R457      -1.4922335147857666e+00
    phi[0,4]  R458      -1.4597337245941162e+00
    phi[0,4]  R459      -1.0903332233428955e+00
    phi[0,4]  R460      -9.6041518449783325e-01
    phi[0,4]  R461      -1.5780441761016846e+00
    phi[0,4]  R462      -1.6744485124945641e-02
    phi[0,4]  R463      -2.7442746162414551e+00
    phi[0,4]  R464      -3.5482704639434814e+00
    phi[0,4]  R465      -3.3309721946716309e+00
    phi[0,4]  R466      -7.5490885972976685e-01
    phi[0,4]  R467      -4.5960551500320435e-01
    phi[0,4]  R468      -1.4635163545608521e+00
    phi[0,4]  R469      -1.6087700128555298e+00
    phi[0,4]  R470      -0.616363525390625
    phi[0,4]  R471      -2.3368327617645264e+00
    phi[0,4]  R472      8.3472147583961487e-02
    phi[0,4]  R473      -1.3718928098678589e+00
    phi[0,4]  R474      -1.8614313006401062e-01
    phi[0,4]  R475      -3.8824608325958252e+00
    phi[0,4]  R476      -1.2489091157913208e+00
    phi[0,4]  R477      -7.5200676918029785e-01
    phi[0,4]  R478      -1.7051738500595093e+00
    phi[0,4]  R479      -2.9448795318603516e+00
    phi[0,4]  R480      -2.3365991115570068e+00
    phi[0,4]  R481      -3.3713517189025879e+00
    phi[0,4]  R482      -6.4887821674346924e-01
    phi[0,4]  R483      -4.0524382591247559e+00
    phi[0,4]  R484      -4.1985726356506348e+00
    phi[0,4]  R485      -3.8036713600158691e+00
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R486      -3.0999999046325684e+00
    phi[4,0]  R487      -3.0999999046325684e+00
    phi[4,0]  R488      -2.2400000095367432e+00
    phi[4,0]  R489      -2.2400000095367432e+00
    phi[4,0]  R490      -3.0999999046325684e+00
    phi[4,0]  R491      -3.0999999046325684e+00
    phi[4,0]  R492      -2.5699999332427979e+00
    phi[4,0]  R493      -2.5699999332427979e+00
    phi[4,0]  R494      -3.0999999046325684e+00
    phi[4,0]  R495      -3.0999999046325684e+00
    phi[4,0]  R496      -2.0899999141693115e+00
    phi[4,0]  R497      -2.0899999141693115e+00
    phi[4,0]  R498      -3.0999999046325684e+00
    phi[4,0]  R499      -3.0999999046325684e+00
    phi[4,0]  R500      6.1045378446578979e-01
    phi[4,0]  R501      1.5194685459136963e+00
    phi[4,0]  R502      1.7441809177398682e+00
    phi[4,0]  R503      2.1775019168853760e-01
    phi[4,0]  R504      5.4810017347335815e-01
    phi[4,0]  R505      8.0885022878646851e-01
    phi[4,0]  R506      1.7800904810428619e-01
    phi[4,0]  R507      -1.1691821366548538e-01
    phi[4,0]  R508      -1.2544251680374146e+00
    phi[4,0]  R509      -4.9588072299957275e-01
    phi[4,0]  R510      -1.8220334053039551e+00
    phi[4,0]  R511      -1.9680370092391968e+00
    phi[4,0]  R512      -1.83860182762146
    phi[4,0]  R513      -2.5332596302032471e+00
    phi[4,0]  R514      -2.6017794609069824e+00
    phi[4,0]  R515      -2.8047809600830078e+00
    phi[4,0]  R516      -3.0139188766479492e+00
    phi[4,0]  R517      -2.9120640754699707e+00
    phi[4,0]  R518      -1.8599801063537598e+00
    phi[4,0]  R519      -2.2048938274383545e+00
    phi[4,0]  R520      -5.2014064788818359e-01
    phi[4,0]  R521      -2.3481199741363525e+00
    phi[4,0]  R522      -2.2166116237640381e+00
    phi[4,0]  R523      -7.9038292169570923e-01
    phi[4,0]  R524      -1.3059748411178589e+00
    phi[4,0]  R525      -2.5339090824127197e+00
    phi[4,0]  R526      -1.5853928327560425e+00
    phi[4,0]  R527      -1.5559942722320557e+00
    phi[4,0]  R528      -2.1704151630401611e+00
    phi[4,0]  R529      -1.5431559085845947e+00
    phi[4,0]  R530      -1.0972702503204346e+00
    phi[4,0]  R531      -1.6390556097030640e+00
    phi[4,0]  R532      -1.5726720094680786e+00
    phi[4,0]  R533      -1.0558334589004517e+00
    phi[4,0]  R534      -2.3605084419250488e+00
    phi[4,0]  R535      -1.8757507801055908e+00
    phi[4,0]  R536      -1.0681279897689819e+00
    phi[4,0]  R537      -2.3651778697967529e+00
    phi[4,0]  R538      -3.4891297817230225e+00
    phi[4,0]  R539      -2.0149352550506592e+00
    phi[4,0]  R540      -1.51680588722229
    phi[4,0]  R541      -7.3832297325134277e-01
    phi[4,0]  R542      -9.9721217155456543e-01
    phi[4,0]  R543      -1.7784869670867920e+00
    phi[4,0]  R544      -2.0258498191833496e+00
    phi[4,0]  R545      -1.0495134592056274e+00
    phi[4,0]  R546      -3.7982496619224548e-01
    phi[4,0]  R547      -1.4693911075592041e+00
    phi[4,0]  R548      -1.6135748624801636e+00
    phi[4,0]  R549      -3.2682735919952393e+00
    phi[4,0]  R550      -2.0086922645568848e+00
    phi[4,0]  R551      -1.2367788553237915e+00
    phi[4,0]  R552      -1.1788260936737061e+00
    phi[4,0]  R553      -1.8245620727539062e+00
    phi[4,0]  R554      -1.5888966321945190e+00
    phi[4,0]  R555      -6.3916212320327759e-01
    phi[4,0]  R556      -1.0067584514617920e+00
    phi[4,0]  R557      -1.6372170448303223e+00
    phi[4,0]  R558      -1.3500940799713135e+00
    phi[4,0]  R559      -1.7709525823593140e+00
    phi[4,0]  R560      -9.8480802774429321e-01
    phi[4,0]  R561      -1.4922335147857666e+00
    phi[4,0]  R562      -1.4597337245941162e+00
    phi[4,0]  R563      -1.0903332233428955e+00
    phi[4,0]  R564      -9.6041518449783325e-01
    phi[4,0]  R565      -1.5780441761016846e+00
    phi[4,0]  R566      -1.6744485124945641e-02
    phi[4,0]  R567      -2.7442746162414551e+00
    phi[4,0]  R568      -3.5482704639434814e+00
    phi[4,0]  R569      -3.3309721946716309e+00
    phi[4,0]  R570      -7.5490885972976685e-01
    phi[4,0]  R571      -4.5960551500320435e-01
    phi[4,0]  R572      -1.4635163545608521e+00
    phi[4,0]  R573      -1.6087700128555298e+00
    phi[4,0]  R574      -0.616363525390625
    phi[4,0]  R575      -2.3368327617645264e+00
    phi[4,0]  R576      8.3472147583961487e-02
    phi[4,0]  R577      -1.3718928098678589e+00
    phi[4,0]  R578      -1.8614313006401062e-01
    phi[4,0]  R579      -3.8824608325958252e+00
    phi[4,0]  R580      -1.2489091157913208e+00
    phi[4,0]  R581      -7.5200676918029785e-01
    phi[4,0]  R582      -1.7051738500595093e+00
    phi[4,0]  R583      -2.9448795318603516e+00
    phi[4,0]  R584      -2.3365991115570068e+00
    phi[4,0]  R585      -3.3713517189025879e+00
    phi[4,0]  R586      -6.4887821674346924e-01
    phi[4,0]  R587      -4.0524382591247559e+00
    phi[4,0]  R588      -4.1985726356506348e+00
    phi[4,0]  R589      -3.8036713600158691e+00
    phi[4,0]  R590      1.7145581245422363e+00
    phi[4,0]  R591      1.4445383548736572e+00
    phi[4,0]  R592      1.3001598119735718e+00
    phi[4,0]  R593      -4.8051971197128296e-01
    phi[4,0]  R594      2.7111512422561646e-01
    phi[4,0]  R595      0.496223121881485
    phi[4,0]  R596      -2.9247125983238220e-01
    phi[4,0]  R597      5.6794756650924683e-01
    phi[4,0]  R598      6.0412257909774780e-01
    phi[4,0]  R599      2.3192022740840912e-01
    phi[4,0]  R600      -2.2571575641632080e+00
    phi[4,0]  R601      -2.4981462955474854e+00
    phi[4,0]  R602      -2.8391900062561035e+00
    phi[4,0]  R603      -2.6086461544036865e+00
    phi[4,0]  R604      -1.8027795553207397e+00
    phi[4,0]  R605      -2.3305709362030029e+00
    phi[4,0]  R606      -2.6670083999633789e+00
    phi[4,0]  R607      -1.1279600858688354e+00
    phi[4,0]  R608      -1.6650457382202148e+00
    phi[4,0]  R609      -2.0190687179565430e+00
    phi[4,0]  R610      -2.3345603942871094e+00
    phi[4,0]  R611      -1.9748090505599976e+00
    phi[4,0]  R612      -1.78983736038208
    phi[4,0]  R613      4.5438376069068909e-01
    phi[4,0]  R614      6.7388898134231567e-01
    phi[4,0]  R615      3.9373758435249329e-01
    phi[4,0]  R616      -1.3576176166534424e+00
    phi[4,0]  R617      -2.8481829166412354e+00
    phi[4,0]  R618      -3.2946033477783203e+00
    phi[4,0]  R619      -2.6888034343719482e+00
    phi[4,0]  R620      -1.1842092275619507e+00
    phi[4,0]  R621      -1.1080672740936279e+00
    phi[4,0]  R622      -1.0955878496170044e+00
    phi[4,0]  R623      -2.0255734920501709e+00
    phi[4,0]  R624      4.4700416922569275e-01
    phi[4,0]  R625      -1.4050878584384918e-01
    phi[4,0]  R626      -1.1859025955200195e+00
    phi[4,0]  R627      -1.5169923305511475e+00
    phi[4,0]  R628      3.9713934063911438e-01
    phi[4,0]  R629      0.531472384929657
    phi[0,5]  R0        1
    phi[0,5]  R1        1
    phi[0,5]  R45       -1
    phi[0,5]  R630      -3.0999999046325684e+00
    phi[0,5]  R631      -3.0999999046325684e+00
    phi[0,5]  R632      -2.2400000095367432e+00
    phi[0,5]  R633      -2.2400000095367432e+00
    phi[0,5]  R634      -3.0999999046325684e+00
    phi[0,5]  R635      -3.0999999046325684e+00
    phi[0,5]  R636      -2.5699999332427979e+00
    phi[0,5]  R637      -2.5699999332427979e+00
    phi[0,5]  R638      -3.0999999046325684e+00
    phi[0,5]  R639      -3.0999999046325684e+00
    phi[0,5]  R640      -2.0899999141693115e+00
    phi[0,5]  R641      -2.0899999141693115e+00
    phi[0,5]  R642      -3.0999999046325684e+00
    phi[0,5]  R643      -3.0999999046325684e+00
    phi[0,5]  R644      1.7145581245422363e+00
    phi[0,5]  R645      1.4445383548736572e+00
    phi[0,5]  R646      1.3001598119735718e+00
    phi[0,5]  R647      -4.8051971197128296e-01
    phi[0,5]  R648      2.7111512422561646e-01
    phi[0,5]  R649      0.496223121881485
    phi[0,5]  R650      -2.9247125983238220e-01
    phi[0,5]  R651      5.6794756650924683e-01
    phi[0,5]  R652      6.0412257909774780e-01
    phi[0,5]  R653      2.3192022740840912e-01
    phi[0,5]  R654      -2.2571575641632080e+00
    phi[0,5]  R655      -2.4981462955474854e+00
    phi[0,5]  R656      -2.8391900062561035e+00
    phi[0,5]  R657      -2.6086461544036865e+00
    phi[0,5]  R658      -1.8027795553207397e+00
    phi[0,5]  R659      -2.3305709362030029e+00
    phi[0,5]  R660      -2.6670083999633789e+00
    phi[0,5]  R661      -1.1279600858688354e+00
    phi[0,5]  R662      -1.6650457382202148e+00
    phi[0,5]  R663      -2.0190687179565430e+00
    phi[0,5]  R664      -2.3345603942871094e+00
    phi[0,5]  R665      -1.9748090505599976e+00
    phi[0,5]  R666      -1.78983736038208
    phi[0,5]  R667      4.5438376069068909e-01
    phi[0,5]  R668      6.7388898134231567e-01
    phi[0,5]  R669      3.9373758435249329e-01
    phi[0,5]  R670      -1.3576176166534424e+00
    phi[0,5]  R671      -2.8481829166412354e+00
    phi[0,5]  R672      -3.2946033477783203e+00
    phi[0,5]  R673      -2.6888034343719482e+00
    phi[0,5]  R674      -1.1842092275619507e+00
    phi[0,5]  R675      -1.1080672740936279e+00
    phi[0,5]  R676      -1.0955878496170044e+00
    phi[0,5]  R677      -2.0255734920501709e+00
    phi[0,5]  R678      4.4700416922569275e-01
    phi[0,5]  R679      -1.4050878584384918e-01
    phi[0,5]  R680      -1.1859025955200195e+00
    phi[0,5]  R681      -1.5169923305511475e+00
    phi[0,5]  R682      3.9713934063911438e-01
    phi[0,5]  R683      0.531472384929657
    phi[0,5]  R684      6.4821594953536987e-01
    phi[0,5]  R685      6.1494719982147217e-01
    phi[0,5]  R686      7.2807991504669189e-01
    phi[0,5]  R687      8.3418214321136475e-01
    phi[0,5]  R688      -5.7292856276035309e-02
    phi[0,5]  R689      -5.6086409091949463e-01
    phi[0,5]  R690      -2.7383455634117126e-01
    phi[0,5]  R691      -1.3843984603881836e+00
    phi[0,5]  R692      -4.0655997395515442e-01
    phi[0,5]  R693      -0.325659841299057
    phi[0,5]  R694      -6.4062255620956421e-01
    phi[0,5]  R695      -1.0018508434295654e+00
    phi[0,5]  R696      -7.7312028408050537e-01
    phi[0,5]  R697      -0.830652117729187
    phi[0,5]  R698      -5.9153360128402710e-01
    phi[0,5]  R699      -7.4118471145629883e-01
    phi[0,5]  R700      -1.0922553539276123e+00
    phi[0,5]  R701      -6.4204698801040649e-01
    phi[0,5]  R702      -2.6679468154907227e-01
    phi[0,5]  R703      -9.9438834190368652e-01
    phi[5,0]  R0        -1
    phi[5,0]  R45       1
    phi[5,0]  R46       1
    phi[5,0]  R704      -3.0999999046325684e+00
    phi[5,0]  R705      -3.0999999046325684e+00
    phi[5,0]  R706      -2.2400000095367432e+00
    phi[5,0]  R707      -2.2400000095367432e+00
    phi[5,0]  R708      -3.0999999046325684e+00
    phi[5,0]  R709      -3.0999999046325684e+00
    phi[5,0]  R710      -2.5699999332427979e+00
    phi[5,0]  R711      -2.5699999332427979e+00
    phi[5,0]  R712      -3.0999999046325684e+00
    phi[5,0]  R713      -3.0999999046325684e+00
    phi[5,0]  R714      -2.0899999141693115e+00
    phi[5,0]  R715      -2.0899999141693115e+00
    phi[5,0]  R716      -3.0999999046325684e+00
    phi[5,0]  R717      -3.0999999046325684e+00
    phi[5,0]  R718      6.4821594953536987e-01
    phi[5,0]  R719      6.1494719982147217e-01
    phi[5,0]  R720      7.2807991504669189e-01
    phi[5,0]  R721      8.3418214321136475e-01
    phi[5,0]  R722      -5.7292856276035309e-02
    phi[5,0]  R723      -5.6086409091949463e-01
    phi[5,0]  R724      -2.7383455634117126e-01
    phi[5,0]  R725      -1.3843984603881836e+00
    phi[5,0]  R726      -4.0655997395515442e-01
    phi[5,0]  R727      -0.325659841299057
    phi[5,0]  R728      -6.4062255620956421e-01
    phi[5,0]  R729      -1.0018508434295654e+00
    phi[5,0]  R730      -7.7312028408050537e-01
    phi[5,0]  R731      -0.830652117729187
    phi[5,0]  R732      -5.9153360128402710e-01
    phi[5,0]  R733      -7.4118471145629883e-01
    phi[5,0]  R734      -1.0922553539276123e+00
    phi[5,0]  R735      -6.4204698801040649e-01
    phi[5,0]  R736      -2.6679468154907227e-01
    phi[5,0]  R737      -9.9438834190368652e-01
    phi[5,0]  R738      1.7145581245422363e+00
    phi[5,0]  R739      1.4445383548736572e+00
    phi[5,0]  R740      1.3001598119735718e+00
    phi[5,0]  R741      -4.8051971197128296e-01
    phi[5,0]  R742      2.7111512422561646e-01
    phi[5,0]  R743      0.496223121881485
    phi[5,0]  R744      -2.9247125983238220e-01
    phi[5,0]  R745      5.6794756650924683e-01
    phi[5,0]  R746      6.0412257909774780e-01
    phi[5,0]  R747      2.3192022740840912e-01
    phi[5,0]  R748      -2.2571575641632080e+00
    phi[5,0]  R749      -2.4981462955474854e+00
    phi[5,0]  R750      -2.8391900062561035e+00
    phi[5,0]  R751      -2.6086461544036865e+00
    phi[5,0]  R752      -1.8027795553207397e+00
    phi[5,0]  R753      -2.3305709362030029e+00
    phi[5,0]  R754      -2.6670083999633789e+00
    phi[5,0]  R755      -1.1279600858688354e+00
    phi[5,0]  R756      -1.6650457382202148e+00
    phi[5,0]  R757      -2.0190687179565430e+00
    phi[5,0]  R758      -2.3345603942871094e+00
    phi[5,0]  R759      -1.9748090505599976e+00
    phi[5,0]  R760      -1.78983736038208
    phi[5,0]  R761      4.5438376069068909e-01
    phi[5,0]  R762      6.7388898134231567e-01
    phi[5,0]  R763      3.9373758435249329e-01
    phi[5,0]  R764      -1.3576176166534424e+00
    phi[5,0]  R765      -2.8481829166412354e+00
    phi[5,0]  R766      -3.2946033477783203e+00
    phi[5,0]  R767      -2.6888034343719482e+00
    phi[5,0]  R768      -1.1842092275619507e+00
    phi[5,0]  R769      -1.1080672740936279e+00
    phi[5,0]  R770      -1.0955878496170044e+00
    phi[5,0]  R771      -2.0255734920501709e+00
    phi[5,0]  R772      4.4700416922569275e-01
    phi[5,0]  R773      -1.4050878584384918e-01
    phi[5,0]  R774      -1.1859025955200195e+00
    phi[5,0]  R775      -1.5169923305511475e+00
    phi[5,0]  R776      3.9713934063911438e-01
    phi[5,0]  R777      0.531472384929657
    phi[8,0]  R0        -1
    phi[8,0]  R2        1.3583139362724279e+00
    phi[8,0]  R3        -6.2928327239970128e-01
    phi[8,0]  R4        2.5603210539907253e+00
    phi[8,0]  R5        1.6105845164723394e+00
    phi[8,0]  R6        -4.2848871274391742e-01
    phi[8,0]  R7        -1.7433816108660944e+00
    phi[8,0]  R8        1.0768066673331931e+00
    phi[8,0]  R72       1
    phi[8,0]  R778      -4.4583138409049958e+00
    phi[8,0]  R779      -1.7416859683601404e+00
    phi[8,0]  R780      -1.6107167371370419e+00
    phi[8,0]  R781      -2.8692832819364442e+00
    phi[8,0]  R782      -5.6603209586232932e+00
    phi[8,0]  R783      -5.3967885064184307e-01
    phi[8,0]  R784      -4.1805844497151377e+00
    phi[8,0]  R785      -9.5941541677045850e-01
    phi[8,0]  R786      -2.6715111918886509e+00
    phi[8,0]  R787      -3.5284886173764858e+00
    phi[8,0]  R788      -3.4661830330321708e-01
    phi[8,0]  R789      -3.8333815250354060e+00
    phi[8,0]  R790      -4.1768065719657610e+00
    phi[8,0]  R791      -2.0231932372993753e+00
    phi[8,0]  R792      -1.5786367554032044e-01
    phi[8,0]  R793      -1.5946411325101639e-01
    phi[8,0]  R794      -1.6842670766483514e-01
    phi[8,0]  R795      -2.4969007475459198e-01
    phi[8,0]  R796      -2.5840730236210785e-01
    phi[8,0]  R797      -2.8153313698647031e-01
    phi[8,0]  R798      -2.8170597760723526e-01
    phi[8,0]  R799      -2.8285000802803739e-01
    phi[8,0]  R800      -4.4474446543202006e-01
    phi[8,0]  R801      -8.9986368488425694e-01
    phi[8,0]  R802      -3.9674590791497244e-01
    phi[8,0]  R803      -4.0453737288510005e-01
    phi[8,0]  R804      -4.1831743807876887e-01
    phi[8,0]  R805      -4.2007967668473833e-01
    phi[8,0]  R806      -4.7132759823281556e-01
    phi[8,0]  R807      -4.8492615695148089e-01
    phi[8,0]  R808      -4.8759918073246267e-01
    phi[8,0]  R809      -1.1728906760924853e+00
    phi[8,0]  R810      -2.7811102969516619e+00
    phi[8,0]  R811      -7.9106531123815671e-01
    phi[8,0]  R812      -3.4342770824017066e-01
    phi[8,0]  R813      -5.2035401027439843e-01
    phi[8,0]  R814      -7.0836364648763794e-01
    phi[8,0]  R815      -7.2350360610608622e-01
    phi[8,0]  R816      -7.9739558786896447e-01
    phi[8,0]  R817      -8.0457128338930328e-01
    phi[8,0]  R818      -8.2472435899973640e-01
    phi[8,0]  R819      -9.6324147178117125e-01
    phi[8,0]  R820      -1.0502355491487889e+00
    phi[8,0]  R821      -1.1180202524309863e+00
    phi[8,0]  R822      -2.5096117371376470e-01
    phi[8,0]  R823      -2.9120465517227245e-01
    phi[8,0]  R824      -3.7032422292205558e-01
    phi[8,0]  R825      -3.8381521740736146e-01
    phi[8,0]  R826      -5.8510698642197334e-01
    phi[8,0]  R827      -1.3885955101873515e+00
    phi[8,0]  R828      -6.1683283712045822e-01
    phi[8,0]  R829      -1.7716904165395311e+00
    phi[8,0]  R830      -6.2832742177801926e-01
    phi[8,0]  R831      -6.6279682046841648e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R832      -3.0999999046325684e+00
    phi[1,2]  R833      -3.0999999046325684e+00
    phi[1,2]  R834      -2.2400000095367432e+00
    phi[1,2]  R835      -2.2400000095367432e+00
    phi[1,2]  R836      -3.0999999046325684e+00
    phi[1,2]  R837      -3.0999999046325684e+00
    phi[1,2]  R838      -2.5699999332427979e+00
    phi[1,2]  R839      -2.5699999332427979e+00
    phi[1,2]  R840      -3.0999999046325684e+00
    phi[1,2]  R841      -3.0999999046325684e+00
    phi[1,2]  R842      -2.0899999141693115e+00
    phi[1,2]  R843      -2.0899999141693115e+00
    phi[1,2]  R844      -3.0999999046325684e+00
    phi[1,2]  R845      -3.0999999046325684e+00
    phi[1,2]  R846      8.7951347231864929e-02
    phi[1,2]  R847      -3.3694958686828613e-01
    phi[1,2]  R848      5.9234869480133057e-01
    phi[1,2]  R849      1.1230713874101639e-01
    phi[1,2]  R850      5.5940353870391846e-01
    phi[1,2]  R851      6.4491838216781616e-01
    phi[1,2]  R852      1.1368455886840820e+00
    phi[1,2]  R853      5.1497679948806763e-01
    phi[1,2]  R854      9.6771270036697388e-01
    phi[1,2]  R855      2.1446537226438522e-02
    phi[1,2]  R856      -1.6293519735336304e+00
    phi[1,2]  R857      -1.8735386133193970e+00
    phi[1,2]  R858      -1.8169267177581787e+00
    phi[1,2]  R859      -1.4900690317153931e+00
    phi[1,2]  R860      -1.4974399805068970e+00
    phi[1,2]  R861      -2.22248911857605
    phi[1,2]  R862      -0.912834644317627
    phi[1,2]  R863      -1.4112000465393066e+00
    phi[1,2]  R864      -1.5503877401351929e+00
    phi[1,2]  R865      -2.6074275970458984e+00
    phi[1,2]  R866      -2.0081003010272980e-01
    phi[1,2]  R867      -1.5397937297821045e+00
    phi[1,2]  R868      -1.7660311460494995e+00
    phi[1,2]  R869      -1.6142354011535645e+00
    phi[1,2]  R870      -1.9802361726760864e+00
    phi[1,2]  R871      -1.4654186964035034e+00
    phi[1,2]  R872      -1.4228112697601318e+00
    phi[1,2]  R873      -1.18171226978302
    phi[1,2]  R874      -2.2047138214111328e+00
    phi[1,2]  R875      -2.8698575496673584e+00
    phi[1,2]  R876      -1.2087937593460083e+00
    phi[1,2]  R877      -2.2263717651367188e+00
    phi[1,2]  R878      -1.2378278970718384e+00
    phi[1,2]  R879      -2.0760664939880371e+00
    phi[1,2]  R880      -1.5134587883949280e-03
    phi[1,2]  R881      -0.637428879737854
    phi[1,2]  R882      3.1015443801879883e-01
    phi[1,2]  R883      -2.3218820095062256e+00
    phi[1,2]  R884      -2.1789546012878418e+00
    phi[1,2]  R885      -1.2254248857498169e+00
    phi[1,2]  R886      1.3291998207569122e-01
    phi[1,2]  R887      -1.3452390432357788e+00
    phi[1,2]  R888      2.5147804990410805e-03
    phi[1,2]  R889      -1.7297762632369995e+00
    phi[1,2]  R890      -5.7918506860733032e-01
    phi[1,2]  R891      -3.2762501239776611e+00
    phi[1,2]  R892      -1.3444849252700806e+00
    phi[1,2]  R893      -1.0472964048385620e+00
    phi[1,2]  R894      -7.1784019470214844e-01
    phi[1,2]  R895      -2.0061371326446533e+00
    phi[1,2]  R896      -1.6152055263519287e+00
    phi[1,2]  R897      -1.8375148773193359e+00
    phi[1,2]  R898      -1.4262689352035522e+00
    phi[1,2]  R899      -2.4771697521209717e+00
    phi[1,2]  R900      -0.0289363544434309
    phi[1,2]  R901      -2.5869073867797852e+00
    phi[1,2]  R902      -8.6672621965408325e-01
    phi[1,2]  R903      -1.6943770647048950e+00
    phi[1,2]  R904      -6.1104822158813477e-01
    phi[1,2]  R905      -3.3916926383972168e-01
    phi[1,2]  R906      1.3346369564533234e-01
    phi[1,2]  R907      -1.6124694347381592e+00
    phi[1,2]  R908      -2.1778790950775146e+00
    phi[1,2]  R909      -4.5567941665649414e-01
    phi[1,2]  R910      -1.0057600587606430e-01
    phi[1,2]  R911      -1.4860936403274536e+00
    phi[1,2]  R912      -8.1424689292907715e-01
    phi[1,2]  R913      -2.0693848133087158e+00
    phi[1,2]  R914      -0.861158013343811
    phi[1,2]  R915      -2.0915164947509766e+00
    phi[1,2]  R916      -5.9360277652740479e-01
    phi[1,2]  R917      -2.4567847251892090e+00
    phi[1,2]  R918      -2.6184012889862061e+00
    phi[1,2]  R919      -1.4719244241714478e+00
    phi[1,2]  R920      -1.2461595535278320e+00
    phi[1,2]  R921      -1.5171217918395996e+00
    phi[1,2]  R922      -2.2083458900451660e+00
    phi[1,2]  R923      -1.9676368236541748e+00
    phi[1,2]  R924      -1.4736702442169189e+00
    phi[1,2]  R925      -1.2641810178756714e+00
    phi[1,2]  R926      1.7017009258270264e+00
    phi[1,2]  R927      1.3313882350921631e+00
    phi[1,2]  R928      1.4700937271118164e+00
    phi[1,2]  R929      4.1428589820861816e-01
    phi[1,2]  R930      2.6595526933670044e-01
    phi[1,2]  R931      -3.4434521198272705e-01
    phi[1,2]  R932      7.0417642593383789e-01
    phi[1,2]  R933      1.2481210231781006e+00
    phi[1,2]  R934      1.2481045722961426e+00
    phi[1,2]  R935      0.506125807762146
    phi[1,2]  R936      -1.2794119119644165e+00
    phi[1,2]  R937      8.1900125741958618e-01
    phi[1,2]  R938      -5.3388023376464844e-01
    phi[1,2]  R939      -1.2311396598815918e+00
    phi[1,2]  R940      -1.3413236141204834e+00
    phi[1,2]  R941      -1.2598592042922974e+00
    phi[1,2]  R942      -5.2960634231567383e-01
    phi[1,2]  R943      -3.5278385877609253e-01
    phi[1,2]  R944      -3.6152765154838562e-01
    phi[1,2]  R945      -1.3272466659545898e+00
    phi[1,2]  R946      -1.1437535285949707e+00
    phi[1,2]  R947      -1.3830045461654663e+00
    phi[1,2]  R948      -5.6895148754119873e-01
    phi[1,2]  R949      -1.9224900007247925e+00
    phi[1,2]  R950      -2.5735080242156982e-01
    phi[1,2]  R951      -1.5573112964630127e+00
    phi[1,2]  R952      -2.2332363128662109e+00
    phi[1,2]  R953      -1.5781669616699219e+00
    phi[1,2]  R954      -1.9726530313491821e+00
    phi[1,2]  R955      -1.7848974466323853e+00
    phi[1,2]  R956      -1.0115809440612793e+00
    phi[1,2]  R957      3.2725065946578979e-01
    phi[1,2]  R958      -1.9182363748550415e+00
    phi[1,2]  R959      -1.8928976058959961e+00
    phi[1,2]  R960      0.850605309009552
    phi[1,2]  R961      -1.8358582258224487e+00
    phi[1,2]  R962      -6.1830836534500122e-01
    phi[1,2]  R963      -9.3510341644287109e-01
    phi[1,2]  R964      -2.0217123031616211e+00
    phi[1,2]  R965      -2.2757482528686523e+00
    phi[1,2]  R966      5.1695412397384644e-01
    phi[1,2]  R967      -7.9669165611267090e-01
    phi[1,2]  R968      -7.7933198213577271e-01
    phi[1,2]  R969      -1.0398589372634888e+00
    phi[1,2]  R970      2.9323211312294006e-01
    phi[1,2]  R971      -1.9802366495132446e+00
    phi[1,2]  R972      -1.9783204793930054e+00
    phi[1,2]  R973      -1.4503527432680130e-02
    phi[1,2]  R974      -1.2334446907043457e+00
    phi[1,2]  R975      -1.9392939805984497e+00
    phi[1,2]  R976      -2.0738766193389893e+00
    phi[1,2]  R977      -1.0702661275863647e+00
    phi[1,2]  R978      -1.0558699369430542e+00
    phi[1,2]  R979      -3.6107444763183594e-01
    phi[1,2]  R980      -1.9397468566894531e+00
    phi[1,2]  R981      -2.2155833244323730e+00
    phi[1,2]  R982      -0.684425413608551
    phi[1,2]  R983      -2.0316681861877441e+00
    phi[1,2]  R984      1.5907442569732666e-01
    phi[1,2]  R985      -1.0118864774703979e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R986      -3.0999999046325684e+00
    phi[2,1]  R987      -3.0999999046325684e+00
    phi[2,1]  R988      -2.2400000095367432e+00
    phi[2,1]  R989      -2.2400000095367432e+00
    phi[2,1]  R990      -3.0999999046325684e+00
    phi[2,1]  R991      -3.0999999046325684e+00
    phi[2,1]  R992      -2.5699999332427979e+00
    phi[2,1]  R993      -2.5699999332427979e+00
    phi[2,1]  R994      -3.0999999046325684e+00
    phi[2,1]  R995      -3.0999999046325684e+00
    phi[2,1]  R996      -2.0899999141693115e+00
    phi[2,1]  R997      -2.0899999141693115e+00
    phi[2,1]  R998      -3.0999999046325684e+00
    phi[2,1]  R999      -3.0999999046325684e+00
    phi[2,1]  R1000     1.7017009258270264e+00
    phi[2,1]  R1001     1.3313882350921631e+00
    phi[2,1]  R1002     1.4700937271118164e+00
    phi[2,1]  R1003     4.1428589820861816e-01
    phi[2,1]  R1004     2.6595526933670044e-01
    phi[2,1]  R1005     -3.4434521198272705e-01
    phi[2,1]  R1006     7.0417642593383789e-01
    phi[2,1]  R1007     1.2481210231781006e+00
    phi[2,1]  R1008     1.2481045722961426e+00
    phi[2,1]  R1009     0.506125807762146
    phi[2,1]  R1010     -1.2794119119644165e+00
    phi[2,1]  R1011     8.1900125741958618e-01
    phi[2,1]  R1012     -5.3388023376464844e-01
    phi[2,1]  R1013     -1.2311396598815918e+00
    phi[2,1]  R1014     -1.3413236141204834e+00
    phi[2,1]  R1015     -1.2598592042922974e+00
    phi[2,1]  R1016     -5.2960634231567383e-01
    phi[2,1]  R1017     -3.5278385877609253e-01
    phi[2,1]  R1018     -3.6152765154838562e-01
    phi[2,1]  R1019     -1.3272466659545898e+00
    phi[2,1]  R1020     -1.1437535285949707e+00
    phi[2,1]  R1021     -1.3830045461654663e+00
    phi[2,1]  R1022     -5.6895148754119873e-01
    phi[2,1]  R1023     -1.9224900007247925e+00
    phi[2,1]  R1024     -2.5735080242156982e-01
    phi[2,1]  R1025     -1.5573112964630127e+00
    phi[2,1]  R1026     -2.2332363128662109e+00
    phi[2,1]  R1027     -1.5781669616699219e+00
    phi[2,1]  R1028     -1.9726530313491821e+00
    phi[2,1]  R1029     -1.7848974466323853e+00
    phi[2,1]  R1030     -1.0115809440612793e+00
    phi[2,1]  R1031     3.2725065946578979e-01
    phi[2,1]  R1032     -1.9182363748550415e+00
    phi[2,1]  R1033     -1.8928976058959961e+00
    phi[2,1]  R1034     0.850605309009552
    phi[2,1]  R1035     -1.8358582258224487e+00
    phi[2,1]  R1036     -6.1830836534500122e-01
    phi[2,1]  R1037     -9.3510341644287109e-01
    phi[2,1]  R1038     -2.0217123031616211e+00
    phi[2,1]  R1039     -2.2757482528686523e+00
    phi[2,1]  R1040     5.1695412397384644e-01
    phi[2,1]  R1041     -7.9669165611267090e-01
    phi[2,1]  R1042     -7.7933198213577271e-01
    phi[2,1]  R1043     -1.0398589372634888e+00
    phi[2,1]  R1044     2.9323211312294006e-01
    phi[2,1]  R1045     -1.9802366495132446e+00
    phi[2,1]  R1046     -1.9783204793930054e+00
    phi[2,1]  R1047     -1.4503527432680130e-02
    phi[2,1]  R1048     -1.2334446907043457e+00
    phi[2,1]  R1049     -1.9392939805984497e+00
    phi[2,1]  R1050     -2.0738766193389893e+00
    phi[2,1]  R1051     -1.0702661275863647e+00
    phi[2,1]  R1052     -1.0558699369430542e+00
    phi[2,1]  R1053     -3.6107444763183594e-01
    phi[2,1]  R1054     -1.9397468566894531e+00
    phi[2,1]  R1055     -2.2155833244323730e+00
    phi[2,1]  R1056     -0.684425413608551
    phi[2,1]  R1057     -2.0316681861877441e+00
    phi[2,1]  R1058     1.5907442569732666e-01
    phi[2,1]  R1059     -1.0118864774703979e+00
    phi[2,1]  R1060     8.7951347231864929e-02
    phi[2,1]  R1061     -3.3694958686828613e-01
    phi[2,1]  R1062     5.9234869480133057e-01
    phi[2,1]  R1063     1.1230713874101639e-01
    phi[2,1]  R1064     5.5940353870391846e-01
    phi[2,1]  R1065     6.4491838216781616e-01
    phi[2,1]  R1066     1.1368455886840820e+00
    phi[2,1]  R1067     5.1497679948806763e-01
    phi[2,1]  R1068     9.6771270036697388e-01
    phi[2,1]  R1069     2.1446537226438522e-02
    phi[2,1]  R1070     -1.6293519735336304e+00
    phi[2,1]  R1071     -1.8735386133193970e+00
    phi[2,1]  R1072     -1.8169267177581787e+00
    phi[2,1]  R1073     -1.4900690317153931e+00
    phi[2,1]  R1074     -1.4974399805068970e+00
    phi[2,1]  R1075     -2.22248911857605
    phi[2,1]  R1076     -0.912834644317627
    phi[2,1]  R1077     -1.4112000465393066e+00
    phi[2,1]  R1078     -1.5503877401351929e+00
    phi[2,1]  R1079     -2.6074275970458984e+00
    phi[2,1]  R1080     -2.0081003010272980e-01
    phi[2,1]  R1081     -1.5397937297821045e+00
    phi[2,1]  R1082     -1.7660311460494995e+00
    phi[2,1]  R1083     -1.6142354011535645e+00
    phi[2,1]  R1084     -1.9802361726760864e+00
    phi[2,1]  R1085     -1.4654186964035034e+00
    phi[2,1]  R1086     -1.4228112697601318e+00
    phi[2,1]  R1087     -1.18171226978302
    phi[2,1]  R1088     -2.2047138214111328e+00
    phi[2,1]  R1089     -2.8698575496673584e+00
    phi[2,1]  R1090     -1.2087937593460083e+00
    phi[2,1]  R1091     -2.2263717651367188e+00
    phi[2,1]  R1092     -1.2378278970718384e+00
    phi[2,1]  R1093     -2.0760664939880371e+00
    phi[2,1]  R1094     -1.5134587883949280e-03
    phi[2,1]  R1095     -0.637428879737854
    phi[2,1]  R1096     3.1015443801879883e-01
    phi[2,1]  R1097     -2.3218820095062256e+00
    phi[2,1]  R1098     -2.1789546012878418e+00
    phi[2,1]  R1099     -1.2254248857498169e+00
    phi[2,1]  R1100     1.3291998207569122e-01
    phi[2,1]  R1101     -1.3452390432357788e+00
    phi[2,1]  R1102     2.5147804990410805e-03
    phi[2,1]  R1103     -1.7297762632369995e+00
    phi[2,1]  R1104     -5.7918506860733032e-01
    phi[2,1]  R1105     -3.2762501239776611e+00
    phi[2,1]  R1106     -1.3444849252700806e+00
    phi[2,1]  R1107     -1.0472964048385620e+00
    phi[2,1]  R1108     -7.1784019470214844e-01
    phi[2,1]  R1109     -2.0061371326446533e+00
    phi[2,1]  R1110     -1.6152055263519287e+00
    phi[2,1]  R1111     -1.8375148773193359e+00
    phi[2,1]  R1112     -1.4262689352035522e+00
    phi[2,1]  R1113     -2.4771697521209717e+00
    phi[2,1]  R1114     -0.0289363544434309
    phi[2,1]  R1115     -2.5869073867797852e+00
    phi[2,1]  R1116     -8.6672621965408325e-01
    phi[2,1]  R1117     -1.6943770647048950e+00
    phi[2,1]  R1118     -6.1104822158813477e-01
    phi[2,1]  R1119     -3.3916926383972168e-01
    phi[2,1]  R1120     1.3346369564533234e-01
    phi[2,1]  R1121     -1.6124694347381592e+00
    phi[2,1]  R1122     -2.1778790950775146e+00
    phi[2,1]  R1123     -4.5567941665649414e-01
    phi[2,1]  R1124     -1.0057600587606430e-01
    phi[2,1]  R1125     -1.4860936403274536e+00
    phi[2,1]  R1126     -8.1424689292907715e-01
    phi[2,1]  R1127     -2.0693848133087158e+00
    phi[2,1]  R1128     -0.861158013343811
    phi[2,1]  R1129     -2.0915164947509766e+00
    phi[2,1]  R1130     -5.9360277652740479e-01
    phi[2,1]  R1131     -2.4567847251892090e+00
    phi[2,1]  R1132     -2.6184012889862061e+00
    phi[2,1]  R1133     -1.4719244241714478e+00
    phi[2,1]  R1134     -1.2461595535278320e+00
    phi[2,1]  R1135     -1.5171217918395996e+00
    phi[2,1]  R1136     -2.2083458900451660e+00
    phi[2,1]  R1137     -1.9676368236541748e+00
    phi[2,1]  R1138     -1.4736702442169189e+00
    phi[2,1]  R1139     -1.2641810178756714e+00
    phi[1,4]  R9        1
    phi[1,4]  R10       1
    phi[1,4]  R36       -1
    phi[1,4]  R1140     -3.0999999046325684e+00
    phi[1,4]  R1141     -3.0999999046325684e+00
    phi[1,4]  R1142     -2.2400000095367432e+00
    phi[1,4]  R1143     -2.2400000095367432e+00
    phi[1,4]  R1144     -3.0999999046325684e+00
    phi[1,4]  R1145     -3.0999999046325684e+00
    phi[1,4]  R1146     -2.5699999332427979e+00
    phi[1,4]  R1147     -2.5699999332427979e+00
    phi[1,4]  R1148     -3.0999999046325684e+00
    phi[1,4]  R1149     -3.0999999046325684e+00
    phi[1,4]  R1150     -2.0899999141693115e+00
    phi[1,4]  R1151     -2.0899999141693115e+00
    phi[1,4]  R1152     -3.0999999046325684e+00
    phi[1,4]  R1153     -3.0999999046325684e+00
    phi[1,4]  R1154     8.7951347231864929e-02
    phi[1,4]  R1155     -3.3694958686828613e-01
    phi[1,4]  R1156     5.9234869480133057e-01
    phi[1,4]  R1157     1.1230713874101639e-01
    phi[1,4]  R1158     5.5940353870391846e-01
    phi[1,4]  R1159     6.4491838216781616e-01
    phi[1,4]  R1160     1.1368455886840820e+00
    phi[1,4]  R1161     5.1497679948806763e-01
    phi[1,4]  R1162     9.6771270036697388e-01
    phi[1,4]  R1163     2.1446537226438522e-02
    phi[1,4]  R1164     -1.6293519735336304e+00
    phi[1,4]  R1165     -1.8735386133193970e+00
    phi[1,4]  R1166     -1.8169267177581787e+00
    phi[1,4]  R1167     -1.4900690317153931e+00
    phi[1,4]  R1168     -1.4974399805068970e+00
    phi[1,4]  R1169     -2.22248911857605
    phi[1,4]  R1170     -0.912834644317627
    phi[1,4]  R1171     -1.4112000465393066e+00
    phi[1,4]  R1172     -1.5503877401351929e+00
    phi[1,4]  R1173     -2.6074275970458984e+00
    phi[1,4]  R1174     -2.0081003010272980e-01
    phi[1,4]  R1175     -1.5397937297821045e+00
    phi[1,4]  R1176     -1.7660311460494995e+00
    phi[1,4]  R1177     -1.6142354011535645e+00
    phi[1,4]  R1178     -1.9802361726760864e+00
    phi[1,4]  R1179     -1.4654186964035034e+00
    phi[1,4]  R1180     -1.4228112697601318e+00
    phi[1,4]  R1181     -1.18171226978302
    phi[1,4]  R1182     -2.2047138214111328e+00
    phi[1,4]  R1183     -2.8698575496673584e+00
    phi[1,4]  R1184     -1.2087937593460083e+00
    phi[1,4]  R1185     -2.2263717651367188e+00
    phi[1,4]  R1186     -1.2378278970718384e+00
    phi[1,4]  R1187     -2.0760664939880371e+00
    phi[1,4]  R1188     -1.5134587883949280e-03
    phi[1,4]  R1189     -0.637428879737854
    phi[1,4]  R1190     3.1015443801879883e-01
    phi[1,4]  R1191     -2.3218820095062256e+00
    phi[1,4]  R1192     -2.1789546012878418e+00
    phi[1,4]  R1193     -1.2254248857498169e+00
    phi[1,4]  R1194     1.3291998207569122e-01
    phi[1,4]  R1195     -1.3452390432357788e+00
    phi[1,4]  R1196     2.5147804990410805e-03
    phi[1,4]  R1197     -1.7297762632369995e+00
    phi[1,4]  R1198     -5.7918506860733032e-01
    phi[1,4]  R1199     -3.2762501239776611e+00
    phi[1,4]  R1200     -1.3444849252700806e+00
    phi[1,4]  R1201     -1.0472964048385620e+00
    phi[1,4]  R1202     -7.1784019470214844e-01
    phi[1,4]  R1203     -2.0061371326446533e+00
    phi[1,4]  R1204     -1.6152055263519287e+00
    phi[1,4]  R1205     -1.8375148773193359e+00
    phi[1,4]  R1206     -1.4262689352035522e+00
    phi[1,4]  R1207     -2.4771697521209717e+00
    phi[1,4]  R1208     -0.0289363544434309
    phi[1,4]  R1209     -2.5869073867797852e+00
    phi[1,4]  R1210     -8.6672621965408325e-01
    phi[1,4]  R1211     -1.6943770647048950e+00
    phi[1,4]  R1212     -6.1104822158813477e-01
    phi[1,4]  R1213     -3.3916926383972168e-01
    phi[1,4]  R1214     1.3346369564533234e-01
    phi[1,4]  R1215     -1.6124694347381592e+00
    phi[1,4]  R1216     -2.1778790950775146e+00
    phi[1,4]  R1217     -4.5567941665649414e-01
    phi[1,4]  R1218     -1.0057600587606430e-01
    phi[1,4]  R1219     -1.4860936403274536e+00
    phi[1,4]  R1220     -8.1424689292907715e-01
    phi[1,4]  R1221     -2.0693848133087158e+00
    phi[1,4]  R1222     -0.861158013343811
    phi[1,4]  R1223     -2.0915164947509766e+00
    phi[1,4]  R1224     -5.9360277652740479e-01
    phi[1,4]  R1225     -2.4567847251892090e+00
    phi[1,4]  R1226     -2.6184012889862061e+00
    phi[1,4]  R1227     -1.4719244241714478e+00
    phi[1,4]  R1228     -1.2461595535278320e+00
    phi[1,4]  R1229     -1.5171217918395996e+00
    phi[1,4]  R1230     -2.2083458900451660e+00
    phi[1,4]  R1231     -1.9676368236541748e+00
    phi[1,4]  R1232     -1.4736702442169189e+00
    phi[1,4]  R1233     -1.2641810178756714e+00
    phi[1,4]  R1234     6.1045378446578979e-01
    phi[1,4]  R1235     1.5194685459136963e+00
    phi[1,4]  R1236     1.7441809177398682e+00
    phi[1,4]  R1237     2.1775019168853760e-01
    phi[1,4]  R1238     5.4810017347335815e-01
    phi[1,4]  R1239     8.0885022878646851e-01
    phi[1,4]  R1240     1.7800904810428619e-01
    phi[1,4]  R1241     -1.1691821366548538e-01
    phi[1,4]  R1242     -1.2544251680374146e+00
    phi[1,4]  R1243     -4.9588072299957275e-01
    phi[1,4]  R1244     -1.8220334053039551e+00
    phi[1,4]  R1245     -1.9680370092391968e+00
    phi[1,4]  R1246     -1.83860182762146
    phi[1,4]  R1247     -2.5332596302032471e+00
    phi[1,4]  R1248     -2.6017794609069824e+00
    phi[1,4]  R1249     -2.8047809600830078e+00
    phi[1,4]  R1250     -3.0139188766479492e+00
    phi[1,4]  R1251     -2.9120640754699707e+00
    phi[1,4]  R1252     -1.8599801063537598e+00
    phi[1,4]  R1253     -2.2048938274383545e+00
    phi[1,4]  R1254     -5.2014064788818359e-01
    phi[1,4]  R1255     -2.3481199741363525e+00
    phi[1,4]  R1256     -2.2166116237640381e+00
    phi[1,4]  R1257     -7.9038292169570923e-01
    phi[1,4]  R1258     -1.3059748411178589e+00
    phi[1,4]  R1259     -2.5339090824127197e+00
    phi[1,4]  R1260     -1.5853928327560425e+00
    phi[1,4]  R1261     -1.5559942722320557e+00
    phi[1,4]  R1262     -2.1704151630401611e+00
    phi[1,4]  R1263     -1.5431559085845947e+00
    phi[1,4]  R1264     -1.0972702503204346e+00
    phi[1,4]  R1265     -1.6390556097030640e+00
    phi[1,4]  R1266     -1.5726720094680786e+00
    phi[1,4]  R1267     -1.0558334589004517e+00
    phi[1,4]  R1268     -2.3605084419250488e+00
    phi[1,4]  R1269     -1.8757507801055908e+00
    phi[1,4]  R1270     -1.0681279897689819e+00
    phi[1,4]  R1271     -2.3651778697967529e+00
    phi[1,4]  R1272     -3.4891297817230225e+00
    phi[1,4]  R1273     -2.0149352550506592e+00
    phi[1,4]  R1274     -1.51680588722229
    phi[1,4]  R1275     -7.3832297325134277e-01
    phi[1,4]  R1276     -9.9721217155456543e-01
    phi[1,4]  R1277     -1.7784869670867920e+00
    phi[1,4]  R1278     -2.0258498191833496e+00
    phi[1,4]  R1279     -1.0495134592056274e+00
    phi[1,4]  R1280     -3.7982496619224548e-01
    phi[1,4]  R1281     -1.4693911075592041e+00
    phi[1,4]  R1282     -1.6135748624801636e+00
    phi[1,4]  R1283     -3.2682735919952393e+00
    phi[1,4]  R1284     -2.0086922645568848e+00
    phi[1,4]  R1285     -1.2367788553237915e+00
    phi[1,4]  R1286     -1.1788260936737061e+00
    phi[1,4]  R1287     -1.8245620727539062e+00
    phi[1,4]  R1288     -1.5888966321945190e+00
    phi[1,4]  R1289     -6.3916212320327759e-01
    phi[1,4]  R1290     -1.0067584514617920e+00
    phi[1,4]  R1291     -1.6372170448303223e+00
    phi[1,4]  R1292     -1.3500940799713135e+00
    phi[1,4]  R1293     -1.7709525823593140e+00
    phi[1,4]  R1294     -9.8480802774429321e-01
    phi[1,4]  R1295     -1.4922335147857666e+00
    phi[1,4]  R1296     -1.4597337245941162e+00
    phi[1,4]  R1297     -1.0903332233428955e+00
    phi[1,4]  R1298     -9.6041518449783325e-01
    phi[1,4]  R1299     -1.5780441761016846e+00
    phi[1,4]  R1300     -1.6744485124945641e-02
    phi[1,4]  R1301     -2.7442746162414551e+00
    phi[1,4]  R1302     -3.5482704639434814e+00
    phi[1,4]  R1303     -3.3309721946716309e+00
    phi[1,4]  R1304     -7.5490885972976685e-01
    phi[1,4]  R1305     -4.5960551500320435e-01
    phi[1,4]  R1306     -1.4635163545608521e+00
    phi[1,4]  R1307     -1.6087700128555298e+00
    phi[1,4]  R1308     -0.616363525390625
    phi[1,4]  R1309     -2.3368327617645264e+00
    phi[1,4]  R1310     8.3472147583961487e-02
    phi[1,4]  R1311     -1.3718928098678589e+00
    phi[1,4]  R1312     -1.8614313006401062e-01
    phi[1,4]  R1313     -3.8824608325958252e+00
    phi[1,4]  R1314     -1.2489091157913208e+00
    phi[1,4]  R1315     -7.5200676918029785e-01
    phi[1,4]  R1316     -1.7051738500595093e+00
    phi[1,4]  R1317     -2.9448795318603516e+00
    phi[1,4]  R1318     -2.3365991115570068e+00
    phi[1,4]  R1319     -3.3713517189025879e+00
    phi[1,4]  R1320     -6.4887821674346924e-01
    phi[1,4]  R1321     -4.0524382591247559e+00
    phi[1,4]  R1322     -4.1985726356506348e+00
    phi[1,4]  R1323     -3.8036713600158691e+00
    phi[4,1]  R9        -1
    phi[4,1]  R36       1
    phi[4,1]  R37       1
    phi[4,1]  R1324     -3.0999999046325684e+00
    phi[4,1]  R1325     -3.0999999046325684e+00
    phi[4,1]  R1326     -2.2400000095367432e+00
    phi[4,1]  R1327     -2.2400000095367432e+00
    phi[4,1]  R1328     -3.0999999046325684e+00
    phi[4,1]  R1329     -3.0999999046325684e+00
    phi[4,1]  R1330     -2.5699999332427979e+00
    phi[4,1]  R1331     -2.5699999332427979e+00
    phi[4,1]  R1332     -3.0999999046325684e+00
    phi[4,1]  R1333     -3.0999999046325684e+00
    phi[4,1]  R1334     -2.0899999141693115e+00
    phi[4,1]  R1335     -2.0899999141693115e+00
    phi[4,1]  R1336     -3.0999999046325684e+00
    phi[4,1]  R1337     -3.0999999046325684e+00
    phi[4,1]  R1338     6.1045378446578979e-01
    phi[4,1]  R1339     1.5194685459136963e+00
    phi[4,1]  R1340     1.7441809177398682e+00
    phi[4,1]  R1341     2.1775019168853760e-01
    phi[4,1]  R1342     5.4810017347335815e-01
    phi[4,1]  R1343     8.0885022878646851e-01
    phi[4,1]  R1344     1.7800904810428619e-01
    phi[4,1]  R1345     -1.1691821366548538e-01
    phi[4,1]  R1346     -1.2544251680374146e+00
    phi[4,1]  R1347     -4.9588072299957275e-01
    phi[4,1]  R1348     -1.8220334053039551e+00
    phi[4,1]  R1349     -1.9680370092391968e+00
    phi[4,1]  R1350     -1.83860182762146
    phi[4,1]  R1351     -2.5332596302032471e+00
    phi[4,1]  R1352     -2.6017794609069824e+00
    phi[4,1]  R1353     -2.8047809600830078e+00
    phi[4,1]  R1354     -3.0139188766479492e+00
    phi[4,1]  R1355     -2.9120640754699707e+00
    phi[4,1]  R1356     -1.8599801063537598e+00
    phi[4,1]  R1357     -2.2048938274383545e+00
    phi[4,1]  R1358     -5.2014064788818359e-01
    phi[4,1]  R1359     -2.3481199741363525e+00
    phi[4,1]  R1360     -2.2166116237640381e+00
    phi[4,1]  R1361     -7.9038292169570923e-01
    phi[4,1]  R1362     -1.3059748411178589e+00
    phi[4,1]  R1363     -2.5339090824127197e+00
    phi[4,1]  R1364     -1.5853928327560425e+00
    phi[4,1]  R1365     -1.5559942722320557e+00
    phi[4,1]  R1366     -2.1704151630401611e+00
    phi[4,1]  R1367     -1.5431559085845947e+00
    phi[4,1]  R1368     -1.0972702503204346e+00
    phi[4,1]  R1369     -1.6390556097030640e+00
    phi[4,1]  R1370     -1.5726720094680786e+00
    phi[4,1]  R1371     -1.0558334589004517e+00
    phi[4,1]  R1372     -2.3605084419250488e+00
    phi[4,1]  R1373     -1.8757507801055908e+00
    phi[4,1]  R1374     -1.0681279897689819e+00
    phi[4,1]  R1375     -2.3651778697967529e+00
    phi[4,1]  R1376     -3.4891297817230225e+00
    phi[4,1]  R1377     -2.0149352550506592e+00
    phi[4,1]  R1378     -1.51680588722229
    phi[4,1]  R1379     -7.3832297325134277e-01
    phi[4,1]  R1380     -9.9721217155456543e-01
    phi[4,1]  R1381     -1.7784869670867920e+00
    phi[4,1]  R1382     -2.0258498191833496e+00
    phi[4,1]  R1383     -1.0495134592056274e+00
    phi[4,1]  R1384     -3.7982496619224548e-01
    phi[4,1]  R1385     -1.4693911075592041e+00
    phi[4,1]  R1386     -1.6135748624801636e+00
    phi[4,1]  R1387     -3.2682735919952393e+00
    phi[4,1]  R1388     -2.0086922645568848e+00
    phi[4,1]  R1389     -1.2367788553237915e+00
    phi[4,1]  R1390     -1.1788260936737061e+00
    phi[4,1]  R1391     -1.8245620727539062e+00
    phi[4,1]  R1392     -1.5888966321945190e+00
    phi[4,1]  R1393     -6.3916212320327759e-01
    phi[4,1]  R1394     -1.0067584514617920e+00
    phi[4,1]  R1395     -1.6372170448303223e+00
    phi[4,1]  R1396     -1.3500940799713135e+00
    phi[4,1]  R1397     -1.7709525823593140e+00
    phi[4,1]  R1398     -9.8480802774429321e-01
    phi[4,1]  R1399     -1.4922335147857666e+00
    phi[4,1]  R1400     -1.4597337245941162e+00
    phi[4,1]  R1401     -1.0903332233428955e+00
    phi[4,1]  R1402     -9.6041518449783325e-01
    phi[4,1]  R1403     -1.5780441761016846e+00
    phi[4,1]  R1404     -1.6744485124945641e-02
    phi[4,1]  R1405     -2.7442746162414551e+00
    phi[4,1]  R1406     -3.5482704639434814e+00
    phi[4,1]  R1407     -3.3309721946716309e+00
    phi[4,1]  R1408     -7.5490885972976685e-01
    phi[4,1]  R1409     -4.5960551500320435e-01
    phi[4,1]  R1410     -1.4635163545608521e+00
    phi[4,1]  R1411     -1.6087700128555298e+00
    phi[4,1]  R1412     -0.616363525390625
    phi[4,1]  R1413     -2.3368327617645264e+00
    phi[4,1]  R1414     8.3472147583961487e-02
    phi[4,1]  R1415     -1.3718928098678589e+00
    phi[4,1]  R1416     -1.8614313006401062e-01
    phi[4,1]  R1417     -3.8824608325958252e+00
    phi[4,1]  R1418     -1.2489091157913208e+00
    phi[4,1]  R1419     -7.5200676918029785e-01
    phi[4,1]  R1420     -1.7051738500595093e+00
    phi[4,1]  R1421     -2.9448795318603516e+00
    phi[4,1]  R1422     -2.3365991115570068e+00
    phi[4,1]  R1423     -3.3713517189025879e+00
    phi[4,1]  R1424     -6.4887821674346924e-01
    phi[4,1]  R1425     -4.0524382591247559e+00
    phi[4,1]  R1426     -4.1985726356506348e+00
    phi[4,1]  R1427     -3.8036713600158691e+00
    phi[4,1]  R1428     8.7951347231864929e-02
    phi[4,1]  R1429     -3.3694958686828613e-01
    phi[4,1]  R1430     5.9234869480133057e-01
    phi[4,1]  R1431     1.1230713874101639e-01
    phi[4,1]  R1432     5.5940353870391846e-01
    phi[4,1]  R1433     6.4491838216781616e-01
    phi[4,1]  R1434     1.1368455886840820e+00
    phi[4,1]  R1435     5.1497679948806763e-01
    phi[4,1]  R1436     9.6771270036697388e-01
    phi[4,1]  R1437     2.1446537226438522e-02
    phi[4,1]  R1438     -1.6293519735336304e+00
    phi[4,1]  R1439     -1.8735386133193970e+00
    phi[4,1]  R1440     -1.8169267177581787e+00
    phi[4,1]  R1441     -1.4900690317153931e+00
    phi[4,1]  R1442     -1.4974399805068970e+00
    phi[4,1]  R1443     -2.22248911857605
    phi[4,1]  R1444     -0.912834644317627
    phi[4,1]  R1445     -1.4112000465393066e+00
    phi[4,1]  R1446     -1.5503877401351929e+00
    phi[4,1]  R1447     -2.6074275970458984e+00
    phi[4,1]  R1448     -2.0081003010272980e-01
    phi[4,1]  R1449     -1.5397937297821045e+00
    phi[4,1]  R1450     -1.7660311460494995e+00
    phi[4,1]  R1451     -1.6142354011535645e+00
    phi[4,1]  R1452     -1.9802361726760864e+00
    phi[4,1]  R1453     -1.4654186964035034e+00
    phi[4,1]  R1454     -1.4228112697601318e+00
    phi[4,1]  R1455     -1.18171226978302
    phi[4,1]  R1456     -2.2047138214111328e+00
    phi[4,1]  R1457     -2.8698575496673584e+00
    phi[4,1]  R1458     -1.2087937593460083e+00
    phi[4,1]  R1459     -2.2263717651367188e+00
    phi[4,1]  R1460     -1.2378278970718384e+00
    phi[4,1]  R1461     -2.0760664939880371e+00
    phi[4,1]  R1462     -1.5134587883949280e-03
    phi[4,1]  R1463     -0.637428879737854
    phi[4,1]  R1464     3.1015443801879883e-01
    phi[4,1]  R1465     -2.3218820095062256e+00
    phi[4,1]  R1466     -2.1789546012878418e+00
    phi[4,1]  R1467     -1.2254248857498169e+00
    phi[4,1]  R1468     1.3291998207569122e-01
    phi[4,1]  R1469     -1.3452390432357788e+00
    phi[4,1]  R1470     2.5147804990410805e-03
    phi[4,1]  R1471     -1.7297762632369995e+00
    phi[4,1]  R1472     -5.7918506860733032e-01
    phi[4,1]  R1473     -3.2762501239776611e+00
    phi[4,1]  R1474     -1.3444849252700806e+00
    phi[4,1]  R1475     -1.0472964048385620e+00
    phi[4,1]  R1476     -7.1784019470214844e-01
    phi[4,1]  R1477     -2.0061371326446533e+00
    phi[4,1]  R1478     -1.6152055263519287e+00
    phi[4,1]  R1479     -1.8375148773193359e+00
    phi[4,1]  R1480     -1.4262689352035522e+00
    phi[4,1]  R1481     -2.4771697521209717e+00
    phi[4,1]  R1482     -0.0289363544434309
    phi[4,1]  R1483     -2.5869073867797852e+00
    phi[4,1]  R1484     -8.6672621965408325e-01
    phi[4,1]  R1485     -1.6943770647048950e+00
    phi[4,1]  R1486     -6.1104822158813477e-01
    phi[4,1]  R1487     -3.3916926383972168e-01
    phi[4,1]  R1488     1.3346369564533234e-01
    phi[4,1]  R1489     -1.6124694347381592e+00
    phi[4,1]  R1490     -2.1778790950775146e+00
    phi[4,1]  R1491     -4.5567941665649414e-01
    phi[4,1]  R1492     -1.0057600587606430e-01
    phi[4,1]  R1493     -1.4860936403274536e+00
    phi[4,1]  R1494     -8.1424689292907715e-01
    phi[4,1]  R1495     -2.0693848133087158e+00
    phi[4,1]  R1496     -0.861158013343811
    phi[4,1]  R1497     -2.0915164947509766e+00
    phi[4,1]  R1498     -5.9360277652740479e-01
    phi[4,1]  R1499     -2.4567847251892090e+00
    phi[4,1]  R1500     -2.6184012889862061e+00
    phi[4,1]  R1501     -1.4719244241714478e+00
    phi[4,1]  R1502     -1.2461595535278320e+00
    phi[4,1]  R1503     -1.5171217918395996e+00
    phi[4,1]  R1504     -2.2083458900451660e+00
    phi[4,1]  R1505     -1.9676368236541748e+00
    phi[4,1]  R1506     -1.4736702442169189e+00
    phi[4,1]  R1507     -1.2641810178756714e+00
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R1508     -3.0999999046325684e+00
    phi[2,3]  R1509     -3.0999999046325684e+00
    phi[2,3]  R1510     -2.2400000095367432e+00
    phi[2,3]  R1511     -2.2400000095367432e+00
    phi[2,3]  R1512     -3.0999999046325684e+00
    phi[2,3]  R1513     -3.0999999046325684e+00
    phi[2,3]  R1514     -2.5699999332427979e+00
    phi[2,3]  R1515     -2.5699999332427979e+00
    phi[2,3]  R1516     -3.0999999046325684e+00
    phi[2,3]  R1517     -3.0999999046325684e+00
    phi[2,3]  R1518     -2.0899999141693115e+00
    phi[2,3]  R1519     -2.0899999141693115e+00
    phi[2,3]  R1520     -3.0999999046325684e+00
    phi[2,3]  R1521     -3.0999999046325684e+00
    phi[2,3]  R1522     1.7017009258270264e+00
    phi[2,3]  R1523     1.3313882350921631e+00
    phi[2,3]  R1524     1.4700937271118164e+00
    phi[2,3]  R1525     4.1428589820861816e-01
    phi[2,3]  R1526     2.6595526933670044e-01
    phi[2,3]  R1527     -3.4434521198272705e-01
    phi[2,3]  R1528     7.0417642593383789e-01
    phi[2,3]  R1529     1.2481210231781006e+00
    phi[2,3]  R1530     1.2481045722961426e+00
    phi[2,3]  R1531     0.506125807762146
    phi[2,3]  R1532     -1.2794119119644165e+00
    phi[2,3]  R1533     8.1900125741958618e-01
    phi[2,3]  R1534     -5.3388023376464844e-01
    phi[2,3]  R1535     -1.2311396598815918e+00
    phi[2,3]  R1536     -1.3413236141204834e+00
    phi[2,3]  R1537     -1.2598592042922974e+00
    phi[2,3]  R1538     -5.2960634231567383e-01
    phi[2,3]  R1539     -3.5278385877609253e-01
    phi[2,3]  R1540     -3.6152765154838562e-01
    phi[2,3]  R1541     -1.3272466659545898e+00
    phi[2,3]  R1542     -1.1437535285949707e+00
    phi[2,3]  R1543     -1.3830045461654663e+00
    phi[2,3]  R1544     -5.6895148754119873e-01
    phi[2,3]  R1545     -1.9224900007247925e+00
    phi[2,3]  R1546     -2.5735080242156982e-01
    phi[2,3]  R1547     -1.5573112964630127e+00
    phi[2,3]  R1548     -2.2332363128662109e+00
    phi[2,3]  R1549     -1.5781669616699219e+00
    phi[2,3]  R1550     -1.9726530313491821e+00
    phi[2,3]  R1551     -1.7848974466323853e+00
    phi[2,3]  R1552     -1.0115809440612793e+00
    phi[2,3]  R1553     3.2725065946578979e-01
    phi[2,3]  R1554     -1.9182363748550415e+00
    phi[2,3]  R1555     -1.8928976058959961e+00
    phi[2,3]  R1556     0.850605309009552
    phi[2,3]  R1557     -1.8358582258224487e+00
    phi[2,3]  R1558     -6.1830836534500122e-01
    phi[2,3]  R1559     -9.3510341644287109e-01
    phi[2,3]  R1560     -2.0217123031616211e+00
    phi[2,3]  R1561     -2.2757482528686523e+00
    phi[2,3]  R1562     5.1695412397384644e-01
    phi[2,3]  R1563     -7.9669165611267090e-01
    phi[2,3]  R1564     -7.7933198213577271e-01
    phi[2,3]  R1565     -1.0398589372634888e+00
    phi[2,3]  R1566     2.9323211312294006e-01
    phi[2,3]  R1567     -1.9802366495132446e+00
    phi[2,3]  R1568     -1.9783204793930054e+00
    phi[2,3]  R1569     -1.4503527432680130e-02
    phi[2,3]  R1570     -1.2334446907043457e+00
    phi[2,3]  R1571     -1.9392939805984497e+00
    phi[2,3]  R1572     -2.0738766193389893e+00
    phi[2,3]  R1573     -1.0702661275863647e+00
    phi[2,3]  R1574     -1.0558699369430542e+00
    phi[2,3]  R1575     -3.6107444763183594e-01
    phi[2,3]  R1576     -1.9397468566894531e+00
    phi[2,3]  R1577     -2.2155833244323730e+00
    phi[2,3]  R1578     -0.684425413608551
    phi[2,3]  R1579     -2.0316681861877441e+00
    phi[2,3]  R1580     1.5907442569732666e-01
    phi[2,3]  R1581     -1.0118864774703979e+00
    phi[2,3]  R1582     1.5136082172393799e+00
    phi[2,3]  R1583     1.8531336784362793e+00
    phi[2,3]  R1584     1.2624870538711548e+00
    phi[2,3]  R1585     1.4570593833923340e+00
    phi[2,3]  R1586     1.0874385833740234e+00
    phi[2,3]  R1587     3.0561981201171875e+00
    phi[2,3]  R1588     1.0106421709060669e+00
    phi[2,3]  R1589     2.0857300758361816e+00
    phi[2,3]  R1590     7.4651867151260376e-01
    phi[2,3]  R1591     1.5876458883285522e+00
    phi[2,3]  R1592     -4.8618677258491516e-01
    phi[2,3]  R1593     -2.5391533374786377e+00
    phi[2,3]  R1594     -1.4547295570373535e+00
    phi[2,3]  R1595     5.1530009508132935e-01
    phi[2,3]  R1596     -2.5096268653869629e+00
    phi[2,3]  R1597     -3.1353104114532471e+00
    phi[2,3]  R1598     -7.6161170005798340e-01
    phi[2,3]  R1599     -2.8801937103271484e+00
    phi[2,3]  R1600     -1.1863753795623779e+00
    phi[2,3]  R1601     2.7767845988273621e-01
    phi[2,3]  R1602     1.6410991549491882e-02
    phi[2,3]  R1603     -2.7854695916175842e-01
    phi[2,3]  R1604     -1.9625873565673828e+00
    phi[2,3]  R1605     -2.3872990608215332e+00
    phi[2,3]  R1606     -1.7821986675262451e+00
    phi[2,3]  R1607     7.7229636907577515e-01
    phi[2,3]  R1608     -1.6937600374221802e+00
    phi[2,3]  R1609     -1.1862697452306747e-01
    phi[2,3]  R1610     -6.0415321588516235e-01
    phi[2,3]  R1611     -4.1701954603195190e-01
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R1612     -3.0999999046325684e+00
    phi[3,2]  R1613     -3.0999999046325684e+00
    phi[3,2]  R1614     -2.2400000095367432e+00
    phi[3,2]  R1615     -2.2400000095367432e+00
    phi[3,2]  R1616     -3.0999999046325684e+00
    phi[3,2]  R1617     -3.0999999046325684e+00
    phi[3,2]  R1618     -2.5699999332427979e+00
    phi[3,2]  R1619     -2.5699999332427979e+00
    phi[3,2]  R1620     -3.0999999046325684e+00
    phi[3,2]  R1621     -3.0999999046325684e+00
    phi[3,2]  R1622     -2.0899999141693115e+00
    phi[3,2]  R1623     -2.0899999141693115e+00
    phi[3,2]  R1624     -3.0999999046325684e+00
    phi[3,2]  R1625     -3.0999999046325684e+00
    phi[3,2]  R1626     1.5136082172393799e+00
    phi[3,2]  R1627     1.8531336784362793e+00
    phi[3,2]  R1628     1.2624870538711548e+00
    phi[3,2]  R1629     1.4570593833923340e+00
    phi[3,2]  R1630     1.0874385833740234e+00
    phi[3,2]  R1631     3.0561981201171875e+00
    phi[3,2]  R1632     1.0106421709060669e+00
    phi[3,2]  R1633     2.0857300758361816e+00
    phi[3,2]  R1634     7.4651867151260376e-01
    phi[3,2]  R1635     1.5876458883285522e+00
    phi[3,2]  R1636     -4.8618677258491516e-01
    phi[3,2]  R1637     -2.5391533374786377e+00
    phi[3,2]  R1638     -1.4547295570373535e+00
    phi[3,2]  R1639     5.1530009508132935e-01
    phi[3,2]  R1640     -2.5096268653869629e+00
    phi[3,2]  R1641     -3.1353104114532471e+00
    phi[3,2]  R1642     -7.6161170005798340e-01
    phi[3,2]  R1643     -2.8801937103271484e+00
    phi[3,2]  R1644     -1.1863753795623779e+00
    phi[3,2]  R1645     2.7767845988273621e-01
    phi[3,2]  R1646     1.6410991549491882e-02
    phi[3,2]  R1647     -2.7854695916175842e-01
    phi[3,2]  R1648     -1.9625873565673828e+00
    phi[3,2]  R1649     -2.3872990608215332e+00
    phi[3,2]  R1650     -1.7821986675262451e+00
    phi[3,2]  R1651     7.7229636907577515e-01
    phi[3,2]  R1652     -1.6937600374221802e+00
    phi[3,2]  R1653     -1.1862697452306747e-01
    phi[3,2]  R1654     -6.0415321588516235e-01
    phi[3,2]  R1655     -4.1701954603195190e-01
    phi[3,2]  R1656     1.7017009258270264e+00
    phi[3,2]  R1657     1.3313882350921631e+00
    phi[3,2]  R1658     1.4700937271118164e+00
    phi[3,2]  R1659     4.1428589820861816e-01
    phi[3,2]  R1660     2.6595526933670044e-01
    phi[3,2]  R1661     -3.4434521198272705e-01
    phi[3,2]  R1662     7.0417642593383789e-01
    phi[3,2]  R1663     1.2481210231781006e+00
    phi[3,2]  R1664     1.2481045722961426e+00
    phi[3,2]  R1665     0.506125807762146
    phi[3,2]  R1666     -1.2794119119644165e+00
    phi[3,2]  R1667     8.1900125741958618e-01
    phi[3,2]  R1668     -5.3388023376464844e-01
    phi[3,2]  R1669     -1.2311396598815918e+00
    phi[3,2]  R1670     -1.3413236141204834e+00
    phi[3,2]  R1671     -1.2598592042922974e+00
    phi[3,2]  R1672     -5.2960634231567383e-01
    phi[3,2]  R1673     -3.5278385877609253e-01
    phi[3,2]  R1674     -3.6152765154838562e-01
    phi[3,2]  R1675     -1.3272466659545898e+00
    phi[3,2]  R1676     -1.1437535285949707e+00
    phi[3,2]  R1677     -1.3830045461654663e+00
    phi[3,2]  R1678     -5.6895148754119873e-01
    phi[3,2]  R1679     -1.9224900007247925e+00
    phi[3,2]  R1680     -2.5735080242156982e-01
    phi[3,2]  R1681     -1.5573112964630127e+00
    phi[3,2]  R1682     -2.2332363128662109e+00
    phi[3,2]  R1683     -1.5781669616699219e+00
    phi[3,2]  R1684     -1.9726530313491821e+00
    phi[3,2]  R1685     -1.7848974466323853e+00
    phi[3,2]  R1686     -1.0115809440612793e+00
    phi[3,2]  R1687     3.2725065946578979e-01
    phi[3,2]  R1688     -1.9182363748550415e+00
    phi[3,2]  R1689     -1.8928976058959961e+00
    phi[3,2]  R1690     0.850605309009552
    phi[3,2]  R1691     -1.8358582258224487e+00
    phi[3,2]  R1692     -6.1830836534500122e-01
    phi[3,2]  R1693     -9.3510341644287109e-01
    phi[3,2]  R1694     -2.0217123031616211e+00
    phi[3,2]  R1695     -2.2757482528686523e+00
    phi[3,2]  R1696     5.1695412397384644e-01
    phi[3,2]  R1697     -7.9669165611267090e-01
    phi[3,2]  R1698     -7.7933198213577271e-01
    phi[3,2]  R1699     -1.0398589372634888e+00
    phi[3,2]  R1700     2.9323211312294006e-01
    phi[3,2]  R1701     -1.9802366495132446e+00
    phi[3,2]  R1702     -1.9783204793930054e+00
    phi[3,2]  R1703     -1.4503527432680130e-02
    phi[3,2]  R1704     -1.2334446907043457e+00
    phi[3,2]  R1705     -1.9392939805984497e+00
    phi[3,2]  R1706     -2.0738766193389893e+00
    phi[3,2]  R1707     -1.0702661275863647e+00
    phi[3,2]  R1708     -1.0558699369430542e+00
    phi[3,2]  R1709     -3.6107444763183594e-01
    phi[3,2]  R1710     -1.9397468566894531e+00
    phi[3,2]  R1711     -2.2155833244323730e+00
    phi[3,2]  R1712     -0.684425413608551
    phi[3,2]  R1713     -2.0316681861877441e+00
    phi[3,2]  R1714     1.5907442569732666e-01
    phi[3,2]  R1715     -1.0118864774703979e+00
    phi[3,6]  R27       1
    phi[3,6]  R28       1
    phi[3,6]  R54       -1
    phi[3,6]  R1716     -3.0999999046325684e+00
    phi[3,6]  R1717     -3.0999999046325684e+00
    phi[3,6]  R1718     -2.2400000095367432e+00
    phi[3,6]  R1719     -2.2400000095367432e+00
    phi[3,6]  R1720     -3.0999999046325684e+00
    phi[3,6]  R1721     -3.0999999046325684e+00
    phi[3,6]  R1722     -2.5699999332427979e+00
    phi[3,6]  R1723     -2.5699999332427979e+00
    phi[3,6]  R1724     -3.0999999046325684e+00
    phi[3,6]  R1725     -3.0999999046325684e+00
    phi[3,6]  R1726     -2.0899999141693115e+00
    phi[3,6]  R1727     -2.0899999141693115e+00
    phi[3,6]  R1728     -3.0999999046325684e+00
    phi[3,6]  R1729     -3.0999999046325684e+00
    phi[3,6]  R1730     1.5136082172393799e+00
    phi[3,6]  R1731     1.8531336784362793e+00
    phi[3,6]  R1732     1.2624870538711548e+00
    phi[3,6]  R1733     1.4570593833923340e+00
    phi[3,6]  R1734     1.0874385833740234e+00
    phi[3,6]  R1735     3.0561981201171875e+00
    phi[3,6]  R1736     1.0106421709060669e+00
    phi[3,6]  R1737     2.0857300758361816e+00
    phi[3,6]  R1738     7.4651867151260376e-01
    phi[3,6]  R1739     1.5876458883285522e+00
    phi[3,6]  R1740     -4.8618677258491516e-01
    phi[3,6]  R1741     -2.5391533374786377e+00
    phi[3,6]  R1742     -1.4547295570373535e+00
    phi[3,6]  R1743     5.1530009508132935e-01
    phi[3,6]  R1744     -2.5096268653869629e+00
    phi[3,6]  R1745     -3.1353104114532471e+00
    phi[3,6]  R1746     -7.6161170005798340e-01
    phi[3,6]  R1747     -2.8801937103271484e+00
    phi[3,6]  R1748     -1.1863753795623779e+00
    phi[3,6]  R1749     2.7767845988273621e-01
    phi[3,6]  R1750     1.6410991549491882e-02
    phi[3,6]  R1751     -2.7854695916175842e-01
    phi[3,6]  R1752     -1.9625873565673828e+00
    phi[3,6]  R1753     -2.3872990608215332e+00
    phi[3,6]  R1754     -1.7821986675262451e+00
    phi[3,6]  R1755     7.7229636907577515e-01
    phi[3,6]  R1756     -1.6937600374221802e+00
    phi[3,6]  R1757     -1.1862697452306747e-01
    phi[3,6]  R1758     -6.0415321588516235e-01
    phi[3,6]  R1759     -4.1701954603195190e-01
    phi[3,6]  R1760     1.1982522010803223e+00
    phi[3,6]  R1761     1.0372701883316040e+00
    phi[3,6]  R1762     2.7937896251678467e+00
    phi[3,6]  R1763     3.05489444732666
    phi[3,6]  R1764     3.4302885532379150e+00
    phi[3,6]  R1765     3.4601047039031982e+00
    phi[3,6]  R1766     2.4076180458068848e+00
    phi[3,6]  R1767     3.1213173866271973e+00
    phi[3,6]  R1768     2.2738730907440186e+00
    phi[3,6]  R1769     2.8594872951507568e+00
    phi[3,6]  R1770     -1.9659683704376221e+00
    phi[3,6]  R1771     -3.8028144836425781e+00
    phi[3,6]  R1772     -1.8790314197540283e+00
    phi[3,6]  R1773     -1.6930660009384155e+00
    phi[3,6]  R1774     -2.4119815826416016e+00
    phi[3,6]  R1775     -1.1744581460952759e+00
    phi[3,6]  R1776     -2.0287628173828125e+00
    phi[3,6]  R1777     -1.0977814197540283e+00
    phi[3,6]  R1778     -1.8458950519561768e+00
    phi[3,6]  R1779     -9.5130807161331177e-01
    phi[3,6]  R1780     -1.3627157211303711e+00
    phi[3,6]  R1781     -1.0181862115859985e+00
    phi[3,6]  R1782     3.6767834424972534e-01
    phi[3,6]  R1783     -1.7665230035781860e+00
    phi[3,6]  R1784     -1.0234335660934448e+00
    phi[3,6]  R1785     -2.7621755003929138e-01
    phi[3,6]  R1786     -4.6947345137596130e-01
    phi[3,6]  R1787     -1.2668325901031494e+00
    phi[3,6]  R1788     7.9747158288955688e-01
    phi[3,6]  R1789     1.2491682171821594e-01
    phi[6,3]  R27       -1
    phi[6,3]  R54       1
    phi[6,3]  R55       1
    phi[6,3]  R1790     -3.0999999046325684e+00
    phi[6,3]  R1791     -3.0999999046325684e+00
    phi[6,3]  R1792     -2.2400000095367432e+00
    phi[6,3]  R1793     -2.2400000095367432e+00
    phi[6,3]  R1794     -3.0999999046325684e+00
    phi[6,3]  R1795     -3.0999999046325684e+00
    phi[6,3]  R1796     -2.5699999332427979e+00
    phi[6,3]  R1797     -2.5699999332427979e+00
    phi[6,3]  R1798     -3.0999999046325684e+00
    phi[6,3]  R1799     -3.0999999046325684e+00
    phi[6,3]  R1800     -2.0899999141693115e+00
    phi[6,3]  R1801     -2.0899999141693115e+00
    phi[6,3]  R1802     -3.0999999046325684e+00
    phi[6,3]  R1803     -3.0999999046325684e+00
    phi[6,3]  R1804     1.1982522010803223e+00
    phi[6,3]  R1805     1.0372701883316040e+00
    phi[6,3]  R1806     2.7937896251678467e+00
    phi[6,3]  R1807     3.05489444732666
    phi[6,3]  R1808     3.4302885532379150e+00
    phi[6,3]  R1809     3.4601047039031982e+00
    phi[6,3]  R1810     2.4076180458068848e+00
    phi[6,3]  R1811     3.1213173866271973e+00
    phi[6,3]  R1812     2.2738730907440186e+00
    phi[6,3]  R1813     2.8594872951507568e+00
    phi[6,3]  R1814     -1.9659683704376221e+00
    phi[6,3]  R1815     -3.8028144836425781e+00
    phi[6,3]  R1816     -1.8790314197540283e+00
    phi[6,3]  R1817     -1.6930660009384155e+00
    phi[6,3]  R1818     -2.4119815826416016e+00
    phi[6,3]  R1819     -1.1744581460952759e+00
    phi[6,3]  R1820     -2.0287628173828125e+00
    phi[6,3]  R1821     -1.0977814197540283e+00
    phi[6,3]  R1822     -1.8458950519561768e+00
    phi[6,3]  R1823     -9.5130807161331177e-01
    phi[6,3]  R1824     -1.3627157211303711e+00
    phi[6,3]  R1825     -1.0181862115859985e+00
    phi[6,3]  R1826     3.6767834424972534e-01
    phi[6,3]  R1827     -1.7665230035781860e+00
    phi[6,3]  R1828     -1.0234335660934448e+00
    phi[6,3]  R1829     -2.7621755003929138e-01
    phi[6,3]  R1830     -4.6947345137596130e-01
    phi[6,3]  R1831     -1.2668325901031494e+00
    phi[6,3]  R1832     7.9747158288955688e-01
    phi[6,3]  R1833     1.2491682171821594e-01
    phi[6,3]  R1834     1.5136082172393799e+00
    phi[6,3]  R1835     1.8531336784362793e+00
    phi[6,3]  R1836     1.2624870538711548e+00
    phi[6,3]  R1837     1.4570593833923340e+00
    phi[6,3]  R1838     1.0874385833740234e+00
    phi[6,3]  R1839     3.0561981201171875e+00
    phi[6,3]  R1840     1.0106421709060669e+00
    phi[6,3]  R1841     2.0857300758361816e+00
    phi[6,3]  R1842     7.4651867151260376e-01
    phi[6,3]  R1843     1.5876458883285522e+00
    phi[6,3]  R1844     -4.8618677258491516e-01
    phi[6,3]  R1845     -2.5391533374786377e+00
    phi[6,3]  R1846     -1.4547295570373535e+00
    phi[6,3]  R1847     5.1530009508132935e-01
    phi[6,3]  R1848     -2.5096268653869629e+00
    phi[6,3]  R1849     -3.1353104114532471e+00
    phi[6,3]  R1850     -7.6161170005798340e-01
    phi[6,3]  R1851     -2.8801937103271484e+00
    phi[6,3]  R1852     -1.1863753795623779e+00
    phi[6,3]  R1853     2.7767845988273621e-01
    phi[6,3]  R1854     1.6410991549491882e-02
    phi[6,3]  R1855     -2.7854695916175842e-01
    phi[6,3]  R1856     -1.9625873565673828e+00
    phi[6,3]  R1857     -2.3872990608215332e+00
    phi[6,3]  R1858     -1.7821986675262451e+00
    phi[6,3]  R1859     7.7229636907577515e-01
    phi[6,3]  R1860     -1.6937600374221802e+00
    phi[6,3]  R1861     -1.1862697452306747e-01
    phi[6,3]  R1862     -6.0415321588516235e-01
    phi[6,3]  R1863     -4.1701954603195190e-01
    phi[3,7]  R27       1
    phi[3,7]  R28       1
    phi[3,7]  R63       -1
    phi[3,7]  R1864     -3.0999999046325684e+00
    phi[3,7]  R1865     -3.0999999046325684e+00
    phi[3,7]  R1866     -2.2400000095367432e+00
    phi[3,7]  R1867     -2.2400000095367432e+00
    phi[3,7]  R1868     -3.0999999046325684e+00
    phi[3,7]  R1869     -3.0999999046325684e+00
    phi[3,7]  R1870     -2.5699999332427979e+00
    phi[3,7]  R1871     -2.5699999332427979e+00
    phi[3,7]  R1872     -3.0999999046325684e+00
    phi[3,7]  R1873     -3.0999999046325684e+00
    phi[3,7]  R1874     -2.0899999141693115e+00
    phi[3,7]  R1875     -2.0899999141693115e+00
    phi[3,7]  R1876     -3.0999999046325684e+00
    phi[3,7]  R1877     -3.0999999046325684e+00
    phi[3,7]  R1878     1.5136082172393799e+00
    phi[3,7]  R1879     1.8531336784362793e+00
    phi[3,7]  R1880     1.2624870538711548e+00
    phi[3,7]  R1881     1.4570593833923340e+00
    phi[3,7]  R1882     1.0874385833740234e+00
    phi[3,7]  R1883     3.0561981201171875e+00
    phi[3,7]  R1884     1.0106421709060669e+00
    phi[3,7]  R1885     2.0857300758361816e+00
    phi[3,7]  R1886     7.4651867151260376e-01
    phi[3,7]  R1887     1.5876458883285522e+00
    phi[3,7]  R1888     -4.8618677258491516e-01
    phi[3,7]  R1889     -2.5391533374786377e+00
    phi[3,7]  R1890     -1.4547295570373535e+00
    phi[3,7]  R1891     5.1530009508132935e-01
    phi[3,7]  R1892     -2.5096268653869629e+00
    phi[3,7]  R1893     -3.1353104114532471e+00
    phi[3,7]  R1894     -7.6161170005798340e-01
    phi[3,7]  R1895     -2.8801937103271484e+00
    phi[3,7]  R1896     -1.1863753795623779e+00
    phi[3,7]  R1897     2.7767845988273621e-01
    phi[3,7]  R1898     1.6410991549491882e-02
    phi[3,7]  R1899     -2.7854695916175842e-01
    phi[3,7]  R1900     -1.9625873565673828e+00
    phi[3,7]  R1901     -2.3872990608215332e+00
    phi[3,7]  R1902     -1.7821986675262451e+00
    phi[3,7]  R1903     7.7229636907577515e-01
    phi[3,7]  R1904     -1.6937600374221802e+00
    phi[3,7]  R1905     -1.1862697452306747e-01
    phi[3,7]  R1906     -6.0415321588516235e-01
    phi[3,7]  R1907     -4.1701954603195190e-01
    phi[3,7]  R1908     2.4399502277374268e+00
    phi[3,7]  R1909     1.9086318016052246e+00
    phi[3,7]  R1910     2.9433188438415527e+00
    phi[3,7]  R1911     2.2258920669555664e+00
    phi[3,7]  R1912     2.7658801078796387e+00
    phi[3,7]  R1913     3.5100238323211670e+00
    phi[3,7]  R1914     3.0204703807830811e+00
    phi[3,7]  R1915     2.8518636226654053e+00
    phi[3,7]  R1916     2.4637827873229980e+00
    phi[3,7]  R1917     -4.0456734597682953e-02
    phi[3,7]  R1918     -3.2690486907958984e+00
    phi[3,7]  R1919     -2.8317265510559082e+00
    phi[3,7]  R1920     -2.0985348224639893e+00
    phi[3,7]  R1921     -2.4750828742980957e+00
    phi[3,7]  R1922     -4.7726964950561523e-01
    phi[3,7]  R1923     -3.0024192333221436e+00
    phi[3,7]  R1924     2.0783913135528564e-01
    phi[3,7]  R1925     -5.3549998998641968e-01
    phi[3,7]  R1926     -1.1081610918045044e+00
    phi[3,7]  R1927     -1.1269453763961792e+00
    phi[3,7]  R1928     -3.9214062690734863e-01
    phi[3,7]  R1929     -4.3502429127693176e-01
    phi[3,7]  R1930     2.7658998966217041e+00
    phi[3,7]  R1931     1.1566101312637329e+00
    phi[3,7]  R1932     -2.8441543579101562e+00
    phi[3,7]  R1933     -3.1554055213928223e-01
    phi[3,7]  R1934     -6.6691136360168457e-01
    phi[3,7]  R1935     6.8031764030456543e-01
    phi[3,7]  R1936     -1.5098035335540771e+00
    phi[3,7]  R1937     -1.7282464504241943e+00
    phi[3,7]  R1938     2.8469510078430176e+00
    phi[3,7]  R1939     9.1519957780838013e-01
    phi[3,7]  R1940     2.2538225650787354e+00
    phi[3,7]  R1941     5.9256039559841156e-02
    phi[3,7]  R1942     -1.4161154031753540e+00
    phi[3,7]  R1943     -1.0117256641387939e+00
    phi[3,7]  R1944     -7.5954395532608032e-01
    phi[3,7]  R1945     -8.7965291738510132e-01
    phi[3,7]  R1946     -1.0254024267196655e+00
    phi[7,3]  R27       -1
    phi[7,3]  R63       1
    phi[7,3]  R64       1
    phi[7,3]  R1947     -3.0999999046325684e+00
    phi[7,3]  R1948     -3.0999999046325684e+00
    phi[7,3]  R1949     -2.2400000095367432e+00
    phi[7,3]  R1950     -2.2400000095367432e+00
    phi[7,3]  R1951     -3.0999999046325684e+00
    phi[7,3]  R1952     -3.0999999046325684e+00
    phi[7,3]  R1953     -2.5699999332427979e+00
    phi[7,3]  R1954     -2.5699999332427979e+00
    phi[7,3]  R1955     -3.0999999046325684e+00
    phi[7,3]  R1956     -3.0999999046325684e+00
    phi[7,3]  R1957     -2.0899999141693115e+00
    phi[7,3]  R1958     -2.0899999141693115e+00
    phi[7,3]  R1959     -3.0999999046325684e+00
    phi[7,3]  R1960     -3.0999999046325684e+00
    phi[7,3]  R1961     2.4399502277374268e+00
    phi[7,3]  R1962     1.9086318016052246e+00
    phi[7,3]  R1963     2.9433188438415527e+00
    phi[7,3]  R1964     2.2258920669555664e+00
    phi[7,3]  R1965     2.7658801078796387e+00
    phi[7,3]  R1966     3.5100238323211670e+00
    phi[7,3]  R1967     3.0204703807830811e+00
    phi[7,3]  R1968     2.8518636226654053e+00
    phi[7,3]  R1969     2.4637827873229980e+00
    phi[7,3]  R1970     -4.0456734597682953e-02
    phi[7,3]  R1971     -3.2690486907958984e+00
    phi[7,3]  R1972     -2.8317265510559082e+00
    phi[7,3]  R1973     -2.0985348224639893e+00
    phi[7,3]  R1974     -2.4750828742980957e+00
    phi[7,3]  R1975     -4.7726964950561523e-01
    phi[7,3]  R1976     -3.0024192333221436e+00
    phi[7,3]  R1977     2.0783913135528564e-01
    phi[7,3]  R1978     -5.3549998998641968e-01
    phi[7,3]  R1979     -1.1081610918045044e+00
    phi[7,3]  R1980     -1.1269453763961792e+00
    phi[7,3]  R1981     -3.9214062690734863e-01
    phi[7,3]  R1982     -4.3502429127693176e-01
    phi[7,3]  R1983     2.7658998966217041e+00
    phi[7,3]  R1984     1.1566101312637329e+00
    phi[7,3]  R1985     -2.8441543579101562e+00
    phi[7,3]  R1986     -3.1554055213928223e-01
    phi[7,3]  R1987     -6.6691136360168457e-01
    phi[7,3]  R1988     6.8031764030456543e-01
    phi[7,3]  R1989     -1.5098035335540771e+00
    phi[7,3]  R1990     -1.7282464504241943e+00
    phi[7,3]  R1991     2.8469510078430176e+00
    phi[7,3]  R1992     9.1519957780838013e-01
    phi[7,3]  R1993     2.2538225650787354e+00
    phi[7,3]  R1994     5.9256039559841156e-02
    phi[7,3]  R1995     -1.4161154031753540e+00
    phi[7,3]  R1996     -1.0117256641387939e+00
    phi[7,3]  R1997     -7.5954395532608032e-01
    phi[7,3]  R1998     -8.7965291738510132e-01
    phi[7,3]  R1999     -1.0254024267196655e+00
    phi[7,3]  R2000     1.5136082172393799e+00
    phi[7,3]  R2001     1.8531336784362793e+00
    phi[7,3]  R2002     1.2624870538711548e+00
    phi[7,3]  R2003     1.4570593833923340e+00
    phi[7,3]  R2004     1.0874385833740234e+00
    phi[7,3]  R2005     3.0561981201171875e+00
    phi[7,3]  R2006     1.0106421709060669e+00
    phi[7,3]  R2007     2.0857300758361816e+00
    phi[7,3]  R2008     7.4651867151260376e-01
    phi[7,3]  R2009     1.5876458883285522e+00
    phi[7,3]  R2010     -4.8618677258491516e-01
    phi[7,3]  R2011     -2.5391533374786377e+00
    phi[7,3]  R2012     -1.4547295570373535e+00
    phi[7,3]  R2013     5.1530009508132935e-01
    phi[7,3]  R2014     -2.5096268653869629e+00
    phi[7,3]  R2015     -3.1353104114532471e+00
    phi[7,3]  R2016     -7.6161170005798340e-01
    phi[7,3]  R2017     -2.8801937103271484e+00
    phi[7,3]  R2018     -1.1863753795623779e+00
    phi[7,3]  R2019     2.7767845988273621e-01
    phi[7,3]  R2020     1.6410991549491882e-02
    phi[7,3]  R2021     -2.7854695916175842e-01
    phi[7,3]  R2022     -1.9625873565673828e+00
    phi[7,3]  R2023     -2.3872990608215332e+00
    phi[7,3]  R2024     -1.7821986675262451e+00
    phi[7,3]  R2025     7.7229636907577515e-01
    phi[7,3]  R2026     -1.6937600374221802e+00
    phi[7,3]  R2027     -1.1862697452306747e-01
    phi[7,3]  R2028     -6.0415321588516235e-01
    phi[7,3]  R2029     -4.1701954603195190e-01
    phi[3,9]  R27       1
    phi[3,9]  R28       1
    phi[3,9]  R29       1.5585360373754518e+00
    phi[3,9]  R30       -1.8418607432008236e+00
    phi[3,9]  R31       2.9731190103331193e+00
    phi[3,9]  R32       -1.5386497507623225e+00
    phi[3,9]  R33       -2.0330937445236263e+00
    phi[3,9]  R34       -1.5002020878785847e+00
    phi[3,9]  R35       1.1042864016893368e+00
    phi[3,9]  R73       -1
    phi[3,9]  R2030     -1.5414638672571166e+00
    phi[3,9]  R2031     -4.6585359420080206e+00
    phi[3,9]  R2032     -4.0818607527375672e+00
    phi[3,9]  R2033     -3.9813926633591956e-01
    phi[3,9]  R2034     -1.2688089429944904e-01
    phi[3,9]  R2035     -6.0731189149656881e+00
    phi[3,9]  R2036     -4.1086496840051208e+00
    phi[3,9]  R2037     -1.0313501824804754e+00
    phi[3,9]  R2038     -5.1330936491561943e+00
    phi[3,9]  R2039     -1.0669061601089420e+00
    phi[3,9]  R2040     -3.5902020020478962e+00
    phi[3,9]  R2041     -5.8979782629072686e-01
    phi[3,9]  R2042     -1.9957135029432316e+00
    phi[3,9]  R2043     -4.2042863063219054e+00
    phi[3,9]  R2044     -1.6245515165506186e-01
    phi[3,9]  R2045     -1.6344057593467554e-01
    phi[3,9]  R2046     -1.7743856273058678e-01
    phi[3,9]  R2047     -1.7861789320184518e-01
    phi[3,9]  R2048     -1.8123933654622881e-01
    phi[3,9]  R2049     -1.8294339005383575e-01
    phi[3,9]  R2050     -1.8324754187290848e-01
    phi[3,9]  R2051     -1.8443673269760330e-01
    phi[3,9]  R2052     -1.8572947543151785e-01
    phi[3,9]  R2053     -1.8859791586072117e-01
    phi[3,9]  R2054     -2.3336989061475955e-01
    phi[3,9]  R2055     -2.3512075320556614e-01
    phi[3,9]  R2056     -2.3661251541444095e-01
    phi[3,9]  R2057     -1.1350021979722695e+00
    phi[3,9]  R2058     -2.4073700573230461e-01
    phi[3,9]  R2059     -3.4173694632393881e-01
    phi[3,9]  R2060     -2.2420294063816497e+00
    phi[3,9]  R2061     -4.2987104461921044e-01
    phi[3,9]  R2062     -4.7973121276478814e-01
    phi[3,9]  R2063     -5.1812790554330446e-01
    phi[3,9]  R2064     -1.7126562852925742e-01
    phi[3,9]  R2065     -1.8100053529911528e-01
    phi[3,9]  R2066     -1.8552210437969974e-01
    phi[3,9]  R2067     -1.9116207070092273e-01
    phi[3,9]  R2068     -2.0765620984863142e-01
    phi[3,9]  R2069     -2.0975553609475728e-01
    phi[3,9]  R2070     -2.1820058083590776e-01
    phi[3,9]  R2071     -2.2036004894017561e-01
    phi[3,9]  R2072     -2.2737794680204931e-01
    phi[3,9]  R2073     -2.3024600809473877e-01
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R2074     -3.0999999046325684e+00
    phi[4,5]  R2075     -3.0999999046325684e+00
    phi[4,5]  R2076     -2.2400000095367432e+00
    phi[4,5]  R2077     -2.2400000095367432e+00
    phi[4,5]  R2078     -3.0999999046325684e+00
    phi[4,5]  R2079     -3.0999999046325684e+00
    phi[4,5]  R2080     -2.5699999332427979e+00
    phi[4,5]  R2081     -2.5699999332427979e+00
    phi[4,5]  R2082     -3.0999999046325684e+00
    phi[4,5]  R2083     -3.0999999046325684e+00
    phi[4,5]  R2084     -2.0899999141693115e+00
    phi[4,5]  R2085     -2.0899999141693115e+00
    phi[4,5]  R2086     -3.0999999046325684e+00
    phi[4,5]  R2087     -3.0999999046325684e+00
    phi[4,5]  R2088     6.1045378446578979e-01
    phi[4,5]  R2089     1.5194685459136963e+00
    phi[4,5]  R2090     1.7441809177398682e+00
    phi[4,5]  R2091     2.1775019168853760e-01
    phi[4,5]  R2092     5.4810017347335815e-01
    phi[4,5]  R2093     8.0885022878646851e-01
    phi[4,5]  R2094     1.7800904810428619e-01
    phi[4,5]  R2095     -1.1691821366548538e-01
    phi[4,5]  R2096     -1.2544251680374146e+00
    phi[4,5]  R2097     -4.9588072299957275e-01
    phi[4,5]  R2098     -1.8220334053039551e+00
    phi[4,5]  R2099     -1.9680370092391968e+00
    phi[4,5]  R2100     -1.83860182762146
    phi[4,5]  R2101     -2.5332596302032471e+00
    phi[4,5]  R2102     -2.6017794609069824e+00
    phi[4,5]  R2103     -2.8047809600830078e+00
    phi[4,5]  R2104     -3.0139188766479492e+00
    phi[4,5]  R2105     -2.9120640754699707e+00
    phi[4,5]  R2106     -1.8599801063537598e+00
    phi[4,5]  R2107     -2.2048938274383545e+00
    phi[4,5]  R2108     -5.2014064788818359e-01
    phi[4,5]  R2109     -2.3481199741363525e+00
    phi[4,5]  R2110     -2.2166116237640381e+00
    phi[4,5]  R2111     -7.9038292169570923e-01
    phi[4,5]  R2112     -1.3059748411178589e+00
    phi[4,5]  R2113     -2.5339090824127197e+00
    phi[4,5]  R2114     -1.5853928327560425e+00
    phi[4,5]  R2115     -1.5559942722320557e+00
    phi[4,5]  R2116     -2.1704151630401611e+00
    phi[4,5]  R2117     -1.5431559085845947e+00
    phi[4,5]  R2118     -1.0972702503204346e+00
    phi[4,5]  R2119     -1.6390556097030640e+00
    phi[4,5]  R2120     -1.5726720094680786e+00
    phi[4,5]  R2121     -1.0558334589004517e+00
    phi[4,5]  R2122     -2.3605084419250488e+00
    phi[4,5]  R2123     -1.8757507801055908e+00
    phi[4,5]  R2124     -1.0681279897689819e+00
    phi[4,5]  R2125     -2.3651778697967529e+00
    phi[4,5]  R2126     -3.4891297817230225e+00
    phi[4,5]  R2127     -2.0149352550506592e+00
    phi[4,5]  R2128     -1.51680588722229
    phi[4,5]  R2129     -7.3832297325134277e-01
    phi[4,5]  R2130     -9.9721217155456543e-01
    phi[4,5]  R2131     -1.7784869670867920e+00
    phi[4,5]  R2132     -2.0258498191833496e+00
    phi[4,5]  R2133     -1.0495134592056274e+00
    phi[4,5]  R2134     -3.7982496619224548e-01
    phi[4,5]  R2135     -1.4693911075592041e+00
    phi[4,5]  R2136     -1.6135748624801636e+00
    phi[4,5]  R2137     -3.2682735919952393e+00
    phi[4,5]  R2138     -2.0086922645568848e+00
    phi[4,5]  R2139     -1.2367788553237915e+00
    phi[4,5]  R2140     -1.1788260936737061e+00
    phi[4,5]  R2141     -1.8245620727539062e+00
    phi[4,5]  R2142     -1.5888966321945190e+00
    phi[4,5]  R2143     -6.3916212320327759e-01
    phi[4,5]  R2144     -1.0067584514617920e+00
    phi[4,5]  R2145     -1.6372170448303223e+00
    phi[4,5]  R2146     -1.3500940799713135e+00
    phi[4,5]  R2147     -1.7709525823593140e+00
    phi[4,5]  R2148     -9.8480802774429321e-01
    phi[4,5]  R2149     -1.4922335147857666e+00
    phi[4,5]  R2150     -1.4597337245941162e+00
    phi[4,5]  R2151     -1.0903332233428955e+00
    phi[4,5]  R2152     -9.6041518449783325e-01
    phi[4,5]  R2153     -1.5780441761016846e+00
    phi[4,5]  R2154     -1.6744485124945641e-02
    phi[4,5]  R2155     -2.7442746162414551e+00
    phi[4,5]  R2156     -3.5482704639434814e+00
    phi[4,5]  R2157     -3.3309721946716309e+00
    phi[4,5]  R2158     -7.5490885972976685e-01
    phi[4,5]  R2159     -4.5960551500320435e-01
    phi[4,5]  R2160     -1.4635163545608521e+00
    phi[4,5]  R2161     -1.6087700128555298e+00
    phi[4,5]  R2162     -0.616363525390625
    phi[4,5]  R2163     -2.3368327617645264e+00
    phi[4,5]  R2164     8.3472147583961487e-02
    phi[4,5]  R2165     -1.3718928098678589e+00
    phi[4,5]  R2166     -1.8614313006401062e-01
    phi[4,5]  R2167     -3.8824608325958252e+00
    phi[4,5]  R2168     -1.2489091157913208e+00
    phi[4,5]  R2169     -7.5200676918029785e-01
    phi[4,5]  R2170     -1.7051738500595093e+00
    phi[4,5]  R2171     -2.9448795318603516e+00
    phi[4,5]  R2172     -2.3365991115570068e+00
    phi[4,5]  R2173     -3.3713517189025879e+00
    phi[4,5]  R2174     -6.4887821674346924e-01
    phi[4,5]  R2175     -4.0524382591247559e+00
    phi[4,5]  R2176     -4.1985726356506348e+00
    phi[4,5]  R2177     -3.8036713600158691e+00
    phi[4,5]  R2178     6.4821594953536987e-01
    phi[4,5]  R2179     6.1494719982147217e-01
    phi[4,5]  R2180     7.2807991504669189e-01
    phi[4,5]  R2181     8.3418214321136475e-01
    phi[4,5]  R2182     -5.7292856276035309e-02
    phi[4,5]  R2183     -5.6086409091949463e-01
    phi[4,5]  R2184     -2.7383455634117126e-01
    phi[4,5]  R2185     -1.3843984603881836e+00
    phi[4,5]  R2186     -4.0655997395515442e-01
    phi[4,5]  R2187     -0.325659841299057
    phi[4,5]  R2188     -6.4062255620956421e-01
    phi[4,5]  R2189     -1.0018508434295654e+00
    phi[4,5]  R2190     -7.7312028408050537e-01
    phi[4,5]  R2191     -0.830652117729187
    phi[4,5]  R2192     -5.9153360128402710e-01
    phi[4,5]  R2193     -7.4118471145629883e-01
    phi[4,5]  R2194     -1.0922553539276123e+00
    phi[4,5]  R2195     -6.4204698801040649e-01
    phi[4,5]  R2196     -2.6679468154907227e-01
    phi[4,5]  R2197     -9.9438834190368652e-01
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R2198     -3.0999999046325684e+00
    phi[5,4]  R2199     -3.0999999046325684e+00
    phi[5,4]  R2200     -2.2400000095367432e+00
    phi[5,4]  R2201     -2.2400000095367432e+00
    phi[5,4]  R2202     -3.0999999046325684e+00
    phi[5,4]  R2203     -3.0999999046325684e+00
    phi[5,4]  R2204     -2.5699999332427979e+00
    phi[5,4]  R2205     -2.5699999332427979e+00
    phi[5,4]  R2206     -3.0999999046325684e+00
    phi[5,4]  R2207     -3.0999999046325684e+00
    phi[5,4]  R2208     -2.0899999141693115e+00
    phi[5,4]  R2209     -2.0899999141693115e+00
    phi[5,4]  R2210     -3.0999999046325684e+00
    phi[5,4]  R2211     -3.0999999046325684e+00
    phi[5,4]  R2212     6.4821594953536987e-01
    phi[5,4]  R2213     6.1494719982147217e-01
    phi[5,4]  R2214     7.2807991504669189e-01
    phi[5,4]  R2215     8.3418214321136475e-01
    phi[5,4]  R2216     -5.7292856276035309e-02
    phi[5,4]  R2217     -5.6086409091949463e-01
    phi[5,4]  R2218     -2.7383455634117126e-01
    phi[5,4]  R2219     -1.3843984603881836e+00
    phi[5,4]  R2220     -4.0655997395515442e-01
    phi[5,4]  R2221     -0.325659841299057
    phi[5,4]  R2222     -6.4062255620956421e-01
    phi[5,4]  R2223     -1.0018508434295654e+00
    phi[5,4]  R2224     -7.7312028408050537e-01
    phi[5,4]  R2225     -0.830652117729187
    phi[5,4]  R2226     -5.9153360128402710e-01
    phi[5,4]  R2227     -7.4118471145629883e-01
    phi[5,4]  R2228     -1.0922553539276123e+00
    phi[5,4]  R2229     -6.4204698801040649e-01
    phi[5,4]  R2230     -2.6679468154907227e-01
    phi[5,4]  R2231     -9.9438834190368652e-01
    phi[5,4]  R2232     6.1045378446578979e-01
    phi[5,4]  R2233     1.5194685459136963e+00
    phi[5,4]  R2234     1.7441809177398682e+00
    phi[5,4]  R2235     2.1775019168853760e-01
    phi[5,4]  R2236     5.4810017347335815e-01
    phi[5,4]  R2237     8.0885022878646851e-01
    phi[5,4]  R2238     1.7800904810428619e-01
    phi[5,4]  R2239     -1.1691821366548538e-01
    phi[5,4]  R2240     -1.2544251680374146e+00
    phi[5,4]  R2241     -4.9588072299957275e-01
    phi[5,4]  R2242     -1.8220334053039551e+00
    phi[5,4]  R2243     -1.9680370092391968e+00
    phi[5,4]  R2244     -1.83860182762146
    phi[5,4]  R2245     -2.5332596302032471e+00
    phi[5,4]  R2246     -2.6017794609069824e+00
    phi[5,4]  R2247     -2.8047809600830078e+00
    phi[5,4]  R2248     -3.0139188766479492e+00
    phi[5,4]  R2249     -2.9120640754699707e+00
    phi[5,4]  R2250     -1.8599801063537598e+00
    phi[5,4]  R2251     -2.2048938274383545e+00
    phi[5,4]  R2252     -5.2014064788818359e-01
    phi[5,4]  R2253     -2.3481199741363525e+00
    phi[5,4]  R2254     -2.2166116237640381e+00
    phi[5,4]  R2255     -7.9038292169570923e-01
    phi[5,4]  R2256     -1.3059748411178589e+00
    phi[5,4]  R2257     -2.5339090824127197e+00
    phi[5,4]  R2258     -1.5853928327560425e+00
    phi[5,4]  R2259     -1.5559942722320557e+00
    phi[5,4]  R2260     -2.1704151630401611e+00
    phi[5,4]  R2261     -1.5431559085845947e+00
    phi[5,4]  R2262     -1.0972702503204346e+00
    phi[5,4]  R2263     -1.6390556097030640e+00
    phi[5,4]  R2264     -1.5726720094680786e+00
    phi[5,4]  R2265     -1.0558334589004517e+00
    phi[5,4]  R2266     -2.3605084419250488e+00
    phi[5,4]  R2267     -1.8757507801055908e+00
    phi[5,4]  R2268     -1.0681279897689819e+00
    phi[5,4]  R2269     -2.3651778697967529e+00
    phi[5,4]  R2270     -3.4891297817230225e+00
    phi[5,4]  R2271     -2.0149352550506592e+00
    phi[5,4]  R2272     -1.51680588722229
    phi[5,4]  R2273     -7.3832297325134277e-01
    phi[5,4]  R2274     -9.9721217155456543e-01
    phi[5,4]  R2275     -1.7784869670867920e+00
    phi[5,4]  R2276     -2.0258498191833496e+00
    phi[5,4]  R2277     -1.0495134592056274e+00
    phi[5,4]  R2278     -3.7982496619224548e-01
    phi[5,4]  R2279     -1.4693911075592041e+00
    phi[5,4]  R2280     -1.6135748624801636e+00
    phi[5,4]  R2281     -3.2682735919952393e+00
    phi[5,4]  R2282     -2.0086922645568848e+00
    phi[5,4]  R2283     -1.2367788553237915e+00
    phi[5,4]  R2284     -1.1788260936737061e+00
    phi[5,4]  R2285     -1.8245620727539062e+00
    phi[5,4]  R2286     -1.5888966321945190e+00
    phi[5,4]  R2287     -6.3916212320327759e-01
    phi[5,4]  R2288     -1.0067584514617920e+00
    phi[5,4]  R2289     -1.6372170448303223e+00
    phi[5,4]  R2290     -1.3500940799713135e+00
    phi[5,4]  R2291     -1.7709525823593140e+00
    phi[5,4]  R2292     -9.8480802774429321e-01
    phi[5,4]  R2293     -1.4922335147857666e+00
    phi[5,4]  R2294     -1.4597337245941162e+00
    phi[5,4]  R2295     -1.0903332233428955e+00
    phi[5,4]  R2296     -9.6041518449783325e-01
    phi[5,4]  R2297     -1.5780441761016846e+00
    phi[5,4]  R2298     -1.6744485124945641e-02
    phi[5,4]  R2299     -2.7442746162414551e+00
    phi[5,4]  R2300     -3.5482704639434814e+00
    phi[5,4]  R2301     -3.3309721946716309e+00
    phi[5,4]  R2302     -7.5490885972976685e-01
    phi[5,4]  R2303     -4.5960551500320435e-01
    phi[5,4]  R2304     -1.4635163545608521e+00
    phi[5,4]  R2305     -1.6087700128555298e+00
    phi[5,4]  R2306     -0.616363525390625
    phi[5,4]  R2307     -2.3368327617645264e+00
    phi[5,4]  R2308     8.3472147583961487e-02
    phi[5,4]  R2309     -1.3718928098678589e+00
    phi[5,4]  R2310     -1.8614313006401062e-01
    phi[5,4]  R2311     -3.8824608325958252e+00
    phi[5,4]  R2312     -1.2489091157913208e+00
    phi[5,4]  R2313     -7.5200676918029785e-01
    phi[5,4]  R2314     -1.7051738500595093e+00
    phi[5,4]  R2315     -2.9448795318603516e+00
    phi[5,4]  R2316     -2.3365991115570068e+00
    phi[5,4]  R2317     -3.3713517189025879e+00
    phi[5,4]  R2318     -6.4887821674346924e-01
    phi[5,4]  R2319     -4.0524382591247559e+00
    phi[5,4]  R2320     -4.1985726356506348e+00
    phi[5,4]  R2321     -3.8036713600158691e+00
    phi[8,4]  R36       -1
    phi[8,4]  R38       1.3583139362724279e+00
    phi[8,4]  R39       -6.2928327239970128e-01
    phi[8,4]  R40       2.5603210539907253e+00
    phi[8,4]  R41       1.6105845164723394e+00
    phi[8,4]  R42       -4.2848871274391742e-01
    phi[8,4]  R43       -1.7433816108660944e+00
    phi[8,4]  R44       1.0768066673331931e+00
    phi[8,4]  R72       1
    phi[8,4]  R2322     -4.4583138409049958e+00
    phi[8,4]  R2323     -1.7416859683601404e+00
    phi[8,4]  R2324     -1.6107167371370419e+00
    phi[8,4]  R2325     -2.8692832819364442e+00
    phi[8,4]  R2326     -5.6603209586232932e+00
    phi[8,4]  R2327     -5.3967885064184307e-01
    phi[8,4]  R2328     -4.1805844497151377e+00
    phi[8,4]  R2329     -9.5941541677045850e-01
    phi[8,4]  R2330     -2.6715111918886509e+00
    phi[8,4]  R2331     -3.5284886173764858e+00
    phi[8,4]  R2332     -3.4661830330321708e-01
    phi[8,4]  R2333     -3.8333815250354060e+00
    phi[8,4]  R2334     -4.1768065719657610e+00
    phi[8,4]  R2335     -2.0231932372993753e+00
    phi[8,4]  R2336     -8.7237149271210068e-02
    phi[8,4]  R2337     -9.2871988200735389e-02
    phi[8,4]  R2338     -1.0954994393712481e-01
    phi[8,4]  R2339     -1.4723098094830078e-01
    phi[8,4]  R2340     -1.5858516144100143e-01
    phi[8,4]  R2341     -1.6044773280299163e-01
    phi[8,4]  R2342     -1.3844173912260491e+00
    phi[8,4]  R2343     -1.8243059876921874e+00
    phi[8,4]  R2344     -9.2163756625957682e-01
    phi[8,4]  R2345     -1.2348072537240686e+00
    phi[8,4]  R2346     -7.1825958408755830e-01
    phi[8,4]  R2347     -9.4022416585037227e-01
    phi[8,4]  R2348     -8.4308851130350215e-01
    phi[8,4]  R2349     -9.7768342310371681e-01
    phi[8,4]  R2350     -9.8596745594642843e-01
    phi[8,4]  R2351     -1.1739752624133706e+00
    phi[8,4]  R2352     -1.0379518800601120e+00
    phi[8,4]  R2353     -1.1007280130612882e+00
    phi[8,4]  R2354     -1.1168210938233147e+00
    phi[8,4]  R2355     -1.1289592276791676e+00
    phi[8,4]  R2356     -1.2395328058950879e+00
    phi[8,4]  R2357     -8.1170648306330007e-01
    phi[8,4]  R2358     -1.1962218158315581e+00
    phi[8,4]  R2359     -1.7896976140532432e+00
    phi[8,4]  R2360     -1.8584972402344153e+00
    phi[8,4]  R2361     -8.5889083105270392e-01
    phi[8,4]  R2362     -8.0740648304312979e-01
    phi[8,4]  R2363     -1.1369719574646504e+00
    phi[8,4]  R2364     -1.2511365937583512e+00
    phi[8,4]  R2365     -1.3886437453039011e+00
    phi[8,4]  R2366     -6.0886023152248070e-01
    phi[8,4]  R2367     -7.5698731930757091e-01
    phi[8,4]  R2368     -1.1336293654015073e+00
    phi[8,4]  R2369     -1.2378658117816297e+00
    phi[8,4]  R2370     -7.2714556663546581e-01
    phi[8,4]  R2371     -7.4611224784322983e-01
    phi[8,4]  R2372     -1.2722881286051835e+00
    phi[8,4]  R2373     -9.9664067788935329e-01
    phi[8,4]  R2374     -1.0620475126453566e+00
    phi[8,4]  R2375     -1.1081840232090270e+00
    phi[8,4]  R2376     -1.2200968998007129e+00
    phi[8,4]  R2377     -1.4170962496109705e+00
    phi[8,4]  R2378     -1.4097296464913365e+00
    phi[8,4]  R2379     -1.1637647975283336e+00
    phi[8,4]  R2380     -1.1335270444212846e+00
    phi[8,4]  R2381     -1.0680764992490959e+00
    phi[8,4]  R2382     -1.7082248198770955e+00
    phi[8,4]  R2383     -1.1932373084314878e+00
    phi[8,4]  R2384     -9.9632379051289255e-01
    phi[8,4]  R2385     -9.9738177448733545e-01
    phi[8,4]  R2386     -4.7950781183423952e-01
    phi[8,4]  R2387     -5.3049866088427411e-01
    phi[8,4]  R2388     -1.5207486728901425e+00
    phi[8,4]  R2389     -1.2383814757782625e+00
    phi[8,4]  R2390     -8.0973530098052593e-01
    phi[8,4]  R2391     -1.4998272673670920e+00
    phi[8,4]  R2392     -1.2306006187480591e+00
    phi[8,4]  R2393     -1.0012353204118323e+00
    phi[8,4]  R2394     -1.0825695668708326e+00
    phi[8,4]  R2395     -1.0864741688684343e+00
    phi[8,4]  R2396     -1.1670638435372513e+00
    phi[8,4]  R2397     -9.5960296449239935e-01
    phi[8,4]  R2398     -1.5601450321903194e+00
    phi[8,4]  R2399     -1.2298184754847932e+00
    phi[8,4]  R2400     -1.2358716513462458e+00
    phi[8,4]  R2401     -1.1209855576261685e+00
    phi[8,4]  R2402     -2.2013864115080932e+00
    phi[8,4]  R2403     -1.0036530149174712e+00
    phi[8,4]  R2404     -1.0652210426022650e+00
    phi[8,4]  R2405     -1.0752106155714998e+00
    phi[8,4]  R2406     -2.8904986828403967e-01
    phi[8,4]  R2407     -1.3419110097539004e+00
    phi[8,4]  R2408     -1.2987043234841875e+00
    phi[8,4]  R2409     -8.6279515597268452e-01
    phi[8,4]  R2410     -1.52531681017643
    phi[8,4]  R2411     -6.6772706360625955e-01
    phi[8,4]  R2412     -2.1058479344572936e+00
    phi[8,4]  R2413     -1.0664995767804331e+00
    phi[8,4]  R2414     -1.1321605813667905e+00
    phi[8,4]  R2415     -1.1579587255783537e+00
    phi[8,4]  R2416     -4.2718143880990012e-01
    phi[8,4]  R2417     -1.6629978783432584e+00
    phi[8,4]  R2418     -1.0454323356120891e+00
    phi[8,4]  R2419     -1.0749635836728997e+00
    phi[8,4]  R2420     -1.1111303651073623e+00
    phi[8,4]  R2421     -1.1491961504802588e+00
    phi[8,4]  R2422     -1.1747118574483331e+00
    phi[8,4]  R2423     -1.2189132760613695e+00
    phi[8,4]  R2424     -1.2451566324140537e+00
    phi[8,4]  R2425     -1.2980722966893126e+00
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R2426     -3.0999999046325684e+00
    phi[5,6]  R2427     -3.0999999046325684e+00
    phi[5,6]  R2428     -2.2400000095367432e+00
    phi[5,6]  R2429     -2.2400000095367432e+00
    phi[5,6]  R2430     -3.0999999046325684e+00
    phi[5,6]  R2431     -3.0999999046325684e+00
    phi[5,6]  R2432     -2.5699999332427979e+00
    phi[5,6]  R2433     -2.5699999332427979e+00
    phi[5,6]  R2434     -3.0999999046325684e+00
    phi[5,6]  R2435     -3.0999999046325684e+00
    phi[5,6]  R2436     -2.0899999141693115e+00
    phi[5,6]  R2437     -2.0899999141693115e+00
    phi[5,6]  R2438     -3.0999999046325684e+00
    phi[5,6]  R2439     -3.0999999046325684e+00
    phi[5,6]  R2440     6.4821594953536987e-01
    phi[5,6]  R2441     6.1494719982147217e-01
    phi[5,6]  R2442     7.2807991504669189e-01
    phi[5,6]  R2443     8.3418214321136475e-01
    phi[5,6]  R2444     -5.7292856276035309e-02
    phi[5,6]  R2445     -5.6086409091949463e-01
    phi[5,6]  R2446     -2.7383455634117126e-01
    phi[5,6]  R2447     -1.3843984603881836e+00
    phi[5,6]  R2448     -4.0655997395515442e-01
    phi[5,6]  R2449     -0.325659841299057
    phi[5,6]  R2450     -6.4062255620956421e-01
    phi[5,6]  R2451     -1.0018508434295654e+00
    phi[5,6]  R2452     -7.7312028408050537e-01
    phi[5,6]  R2453     -0.830652117729187
    phi[5,6]  R2454     -5.9153360128402710e-01
    phi[5,6]  R2455     -7.4118471145629883e-01
    phi[5,6]  R2456     -1.0922553539276123e+00
    phi[5,6]  R2457     -6.4204698801040649e-01
    phi[5,6]  R2458     -2.6679468154907227e-01
    phi[5,6]  R2459     -9.9438834190368652e-01
    phi[5,6]  R2460     1.1982522010803223e+00
    phi[5,6]  R2461     1.0372701883316040e+00
    phi[5,6]  R2462     2.7937896251678467e+00
    phi[5,6]  R2463     3.05489444732666
    phi[5,6]  R2464     3.4302885532379150e+00
    phi[5,6]  R2465     3.4601047039031982e+00
    phi[5,6]  R2466     2.4076180458068848e+00
    phi[5,6]  R2467     3.1213173866271973e+00
    phi[5,6]  R2468     2.2738730907440186e+00
    phi[5,6]  R2469     2.8594872951507568e+00
    phi[5,6]  R2470     -1.9659683704376221e+00
    phi[5,6]  R2471     -3.8028144836425781e+00
    phi[5,6]  R2472     -1.8790314197540283e+00
    phi[5,6]  R2473     -1.6930660009384155e+00
    phi[5,6]  R2474     -2.4119815826416016e+00
    phi[5,6]  R2475     -1.1744581460952759e+00
    phi[5,6]  R2476     -2.0287628173828125e+00
    phi[5,6]  R2477     -1.0977814197540283e+00
    phi[5,6]  R2478     -1.8458950519561768e+00
    phi[5,6]  R2479     -9.5130807161331177e-01
    phi[5,6]  R2480     -1.3627157211303711e+00
    phi[5,6]  R2481     -1.0181862115859985e+00
    phi[5,6]  R2482     3.6767834424972534e-01
    phi[5,6]  R2483     -1.7665230035781860e+00
    phi[5,6]  R2484     -1.0234335660934448e+00
    phi[5,6]  R2485     -2.7621755003929138e-01
    phi[5,6]  R2486     -4.6947345137596130e-01
    phi[5,6]  R2487     -1.2668325901031494e+00
    phi[5,6]  R2488     7.9747158288955688e-01
    phi[5,6]  R2489     1.2491682171821594e-01
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2490     -3.0999999046325684e+00
    phi[6,5]  R2491     -3.0999999046325684e+00
    phi[6,5]  R2492     -2.2400000095367432e+00
    phi[6,5]  R2493     -2.2400000095367432e+00
    phi[6,5]  R2494     -3.0999999046325684e+00
    phi[6,5]  R2495     -3.0999999046325684e+00
    phi[6,5]  R2496     -2.5699999332427979e+00
    phi[6,5]  R2497     -2.5699999332427979e+00
    phi[6,5]  R2498     -3.0999999046325684e+00
    phi[6,5]  R2499     -3.0999999046325684e+00
    phi[6,5]  R2500     -2.0899999141693115e+00
    phi[6,5]  R2501     -2.0899999141693115e+00
    phi[6,5]  R2502     -3.0999999046325684e+00
    phi[6,5]  R2503     -3.0999999046325684e+00
    phi[6,5]  R2504     1.1982522010803223e+00
    phi[6,5]  R2505     1.0372701883316040e+00
    phi[6,5]  R2506     2.7937896251678467e+00
    phi[6,5]  R2507     3.05489444732666
    phi[6,5]  R2508     3.4302885532379150e+00
    phi[6,5]  R2509     3.4601047039031982e+00
    phi[6,5]  R2510     2.4076180458068848e+00
    phi[6,5]  R2511     3.1213173866271973e+00
    phi[6,5]  R2512     2.2738730907440186e+00
    phi[6,5]  R2513     2.8594872951507568e+00
    phi[6,5]  R2514     -1.9659683704376221e+00
    phi[6,5]  R2515     -3.8028144836425781e+00
    phi[6,5]  R2516     -1.8790314197540283e+00
    phi[6,5]  R2517     -1.6930660009384155e+00
    phi[6,5]  R2518     -2.4119815826416016e+00
    phi[6,5]  R2519     -1.1744581460952759e+00
    phi[6,5]  R2520     -2.0287628173828125e+00
    phi[6,5]  R2521     -1.0977814197540283e+00
    phi[6,5]  R2522     -1.8458950519561768e+00
    phi[6,5]  R2523     -9.5130807161331177e-01
    phi[6,5]  R2524     -1.3627157211303711e+00
    phi[6,5]  R2525     -1.0181862115859985e+00
    phi[6,5]  R2526     3.6767834424972534e-01
    phi[6,5]  R2527     -1.7665230035781860e+00
    phi[6,5]  R2528     -1.0234335660934448e+00
    phi[6,5]  R2529     -2.7621755003929138e-01
    phi[6,5]  R2530     -4.6947345137596130e-01
    phi[6,5]  R2531     -1.2668325901031494e+00
    phi[6,5]  R2532     7.9747158288955688e-01
    phi[6,5]  R2533     1.2491682171821594e-01
    phi[6,5]  R2534     6.4821594953536987e-01
    phi[6,5]  R2535     6.1494719982147217e-01
    phi[6,5]  R2536     7.2807991504669189e-01
    phi[6,5]  R2537     8.3418214321136475e-01
    phi[6,5]  R2538     -5.7292856276035309e-02
    phi[6,5]  R2539     -5.6086409091949463e-01
    phi[6,5]  R2540     -2.7383455634117126e-01
    phi[6,5]  R2541     -1.3843984603881836e+00
    phi[6,5]  R2542     -4.0655997395515442e-01
    phi[6,5]  R2543     -0.325659841299057
    phi[6,5]  R2544     -6.4062255620956421e-01
    phi[6,5]  R2545     -1.0018508434295654e+00
    phi[6,5]  R2546     -7.7312028408050537e-01
    phi[6,5]  R2547     -0.830652117729187
    phi[6,5]  R2548     -5.9153360128402710e-01
    phi[6,5]  R2549     -7.4118471145629883e-01
    phi[6,5]  R2550     -1.0922553539276123e+00
    phi[6,5]  R2551     -6.4204698801040649e-01
    phi[6,5]  R2552     -2.6679468154907227e-01
    phi[6,5]  R2553     -9.9438834190368652e-01
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R2554     -3.0999999046325684e+00
    phi[6,7]  R2555     -3.0999999046325684e+00
    phi[6,7]  R2556     -2.2400000095367432e+00
    phi[6,7]  R2557     -2.2400000095367432e+00
    phi[6,7]  R2558     -3.0999999046325684e+00
    phi[6,7]  R2559     -3.0999999046325684e+00
    phi[6,7]  R2560     -2.5699999332427979e+00
    phi[6,7]  R2561     -2.5699999332427979e+00
    phi[6,7]  R2562     -3.0999999046325684e+00
    phi[6,7]  R2563     -3.0999999046325684e+00
    phi[6,7]  R2564     -2.0899999141693115e+00
    phi[6,7]  R2565     -2.0899999141693115e+00
    phi[6,7]  R2566     -3.0999999046325684e+00
    phi[6,7]  R2567     -3.0999999046325684e+00
    phi[6,7]  R2568     1.1982522010803223e+00
    phi[6,7]  R2569     1.0372701883316040e+00
    phi[6,7]  R2570     2.7937896251678467e+00
    phi[6,7]  R2571     3.05489444732666
    phi[6,7]  R2572     3.4302885532379150e+00
    phi[6,7]  R2573     3.4601047039031982e+00
    phi[6,7]  R2574     2.4076180458068848e+00
    phi[6,7]  R2575     3.1213173866271973e+00
    phi[6,7]  R2576     2.2738730907440186e+00
    phi[6,7]  R2577     2.8594872951507568e+00
    phi[6,7]  R2578     -1.9659683704376221e+00
    phi[6,7]  R2579     -3.8028144836425781e+00
    phi[6,7]  R2580     -1.8790314197540283e+00
    phi[6,7]  R2581     -1.6930660009384155e+00
    phi[6,7]  R2582     -2.4119815826416016e+00
    phi[6,7]  R2583     -1.1744581460952759e+00
    phi[6,7]  R2584     -2.0287628173828125e+00
    phi[6,7]  R2585     -1.0977814197540283e+00
    phi[6,7]  R2586     -1.8458950519561768e+00
    phi[6,7]  R2587     -9.5130807161331177e-01
    phi[6,7]  R2588     -1.3627157211303711e+00
    phi[6,7]  R2589     -1.0181862115859985e+00
    phi[6,7]  R2590     3.6767834424972534e-01
    phi[6,7]  R2591     -1.7665230035781860e+00
    phi[6,7]  R2592     -1.0234335660934448e+00
    phi[6,7]  R2593     -2.7621755003929138e-01
    phi[6,7]  R2594     -4.6947345137596130e-01
    phi[6,7]  R2595     -1.2668325901031494e+00
    phi[6,7]  R2596     7.9747158288955688e-01
    phi[6,7]  R2597     1.2491682171821594e-01
    phi[6,7]  R2598     2.4399502277374268e+00
    phi[6,7]  R2599     1.9086318016052246e+00
    phi[6,7]  R2600     2.9433188438415527e+00
    phi[6,7]  R2601     2.2258920669555664e+00
    phi[6,7]  R2602     2.7658801078796387e+00
    phi[6,7]  R2603     3.5100238323211670e+00
    phi[6,7]  R2604     3.0204703807830811e+00
    phi[6,7]  R2605     2.8518636226654053e+00
    phi[6,7]  R2606     2.4637827873229980e+00
    phi[6,7]  R2607     -4.0456734597682953e-02
    phi[6,7]  R2608     -3.2690486907958984e+00
    phi[6,7]  R2609     -2.8317265510559082e+00
    phi[6,7]  R2610     -2.0985348224639893e+00
    phi[6,7]  R2611     -2.4750828742980957e+00
    phi[6,7]  R2612     -4.7726964950561523e-01
    phi[6,7]  R2613     -3.0024192333221436e+00
    phi[6,7]  R2614     2.0783913135528564e-01
    phi[6,7]  R2615     -5.3549998998641968e-01
    phi[6,7]  R2616     -1.1081610918045044e+00
    phi[6,7]  R2617     -1.1269453763961792e+00
    phi[6,7]  R2618     -3.9214062690734863e-01
    phi[6,7]  R2619     -4.3502429127693176e-01
    phi[6,7]  R2620     2.7658998966217041e+00
    phi[6,7]  R2621     1.1566101312637329e+00
    phi[6,7]  R2622     -2.8441543579101562e+00
    phi[6,7]  R2623     -3.1554055213928223e-01
    phi[6,7]  R2624     -6.6691136360168457e-01
    phi[6,7]  R2625     6.8031764030456543e-01
    phi[6,7]  R2626     -1.5098035335540771e+00
    phi[6,7]  R2627     -1.7282464504241943e+00
    phi[6,7]  R2628     2.8469510078430176e+00
    phi[6,7]  R2629     9.1519957780838013e-01
    phi[6,7]  R2630     2.2538225650787354e+00
    phi[6,7]  R2631     5.9256039559841156e-02
    phi[6,7]  R2632     -1.4161154031753540e+00
    phi[6,7]  R2633     -1.0117256641387939e+00
    phi[6,7]  R2634     -7.5954395532608032e-01
    phi[6,7]  R2635     -8.7965291738510132e-01
    phi[6,7]  R2636     -1.0254024267196655e+00
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R2637     -3.0999999046325684e+00
    phi[7,6]  R2638     -3.0999999046325684e+00
    phi[7,6]  R2639     -2.2400000095367432e+00
    phi[7,6]  R2640     -2.2400000095367432e+00
    phi[7,6]  R2641     -3.0999999046325684e+00
    phi[7,6]  R2642     -3.0999999046325684e+00
    phi[7,6]  R2643     -2.5699999332427979e+00
    phi[7,6]  R2644     -2.5699999332427979e+00
    phi[7,6]  R2645     -3.0999999046325684e+00
    phi[7,6]  R2646     -3.0999999046325684e+00
    phi[7,6]  R2647     -2.0899999141693115e+00
    phi[7,6]  R2648     -2.0899999141693115e+00
    phi[7,6]  R2649     -3.0999999046325684e+00
    phi[7,6]  R2650     -3.0999999046325684e+00
    phi[7,6]  R2651     2.4399502277374268e+00
    phi[7,6]  R2652     1.9086318016052246e+00
    phi[7,6]  R2653     2.9433188438415527e+00
    phi[7,6]  R2654     2.2258920669555664e+00
    phi[7,6]  R2655     2.7658801078796387e+00
    phi[7,6]  R2656     3.5100238323211670e+00
    phi[7,6]  R2657     3.0204703807830811e+00
    phi[7,6]  R2658     2.8518636226654053e+00
    phi[7,6]  R2659     2.4637827873229980e+00
    phi[7,6]  R2660     -4.0456734597682953e-02
    phi[7,6]  R2661     -3.2690486907958984e+00
    phi[7,6]  R2662     -2.8317265510559082e+00
    phi[7,6]  R2663     -2.0985348224639893e+00
    phi[7,6]  R2664     -2.4750828742980957e+00
    phi[7,6]  R2665     -4.7726964950561523e-01
    phi[7,6]  R2666     -3.0024192333221436e+00
    phi[7,6]  R2667     2.0783913135528564e-01
    phi[7,6]  R2668     -5.3549998998641968e-01
    phi[7,6]  R2669     -1.1081610918045044e+00
    phi[7,6]  R2670     -1.1269453763961792e+00
    phi[7,6]  R2671     -3.9214062690734863e-01
    phi[7,6]  R2672     -4.3502429127693176e-01
    phi[7,6]  R2673     2.7658998966217041e+00
    phi[7,6]  R2674     1.1566101312637329e+00
    phi[7,6]  R2675     -2.8441543579101562e+00
    phi[7,6]  R2676     -3.1554055213928223e-01
    phi[7,6]  R2677     -6.6691136360168457e-01
    phi[7,6]  R2678     6.8031764030456543e-01
    phi[7,6]  R2679     -1.5098035335540771e+00
    phi[7,6]  R2680     -1.7282464504241943e+00
    phi[7,6]  R2681     2.8469510078430176e+00
    phi[7,6]  R2682     9.1519957780838013e-01
    phi[7,6]  R2683     2.2538225650787354e+00
    phi[7,6]  R2684     5.9256039559841156e-02
    phi[7,6]  R2685     -1.4161154031753540e+00
    phi[7,6]  R2686     -1.0117256641387939e+00
    phi[7,6]  R2687     -7.5954395532608032e-01
    phi[7,6]  R2688     -8.7965291738510132e-01
    phi[7,6]  R2689     -1.0254024267196655e+00
    phi[7,6]  R2690     1.1982522010803223e+00
    phi[7,6]  R2691     1.0372701883316040e+00
    phi[7,6]  R2692     2.7937896251678467e+00
    phi[7,6]  R2693     3.05489444732666
    phi[7,6]  R2694     3.4302885532379150e+00
    phi[7,6]  R2695     3.4601047039031982e+00
    phi[7,6]  R2696     2.4076180458068848e+00
    phi[7,6]  R2697     3.1213173866271973e+00
    phi[7,6]  R2698     2.2738730907440186e+00
    phi[7,6]  R2699     2.8594872951507568e+00
    phi[7,6]  R2700     -1.9659683704376221e+00
    phi[7,6]  R2701     -3.8028144836425781e+00
    phi[7,6]  R2702     -1.8790314197540283e+00
    phi[7,6]  R2703     -1.6930660009384155e+00
    phi[7,6]  R2704     -2.4119815826416016e+00
    phi[7,6]  R2705     -1.1744581460952759e+00
    phi[7,6]  R2706     -2.0287628173828125e+00
    phi[7,6]  R2707     -1.0977814197540283e+00
    phi[7,6]  R2708     -1.8458950519561768e+00
    phi[7,6]  R2709     -9.5130807161331177e-01
    phi[7,6]  R2710     -1.3627157211303711e+00
    phi[7,6]  R2711     -1.0181862115859985e+00
    phi[7,6]  R2712     3.6767834424972534e-01
    phi[7,6]  R2713     -1.7665230035781860e+00
    phi[7,6]  R2714     -1.0234335660934448e+00
    phi[7,6]  R2715     -2.7621755003929138e-01
    phi[7,6]  R2716     -4.6947345137596130e-01
    phi[7,6]  R2717     -1.2668325901031494e+00
    phi[7,6]  R2718     7.9747158288955688e-01
    phi[7,6]  R2719     1.2491682171821594e-01
    phi[7,9]  R63       1
    phi[7,9]  R64       1
    phi[7,9]  R65       1.5585360373754518e+00
    phi[7,9]  R66       -1.8418607432008236e+00
    phi[7,9]  R67       2.9731190103331193e+00
    phi[7,9]  R68       -1.5386497507623225e+00
    phi[7,9]  R69       -2.0330937445236263e+00
    phi[7,9]  R70       -1.5002020878785847e+00
    phi[7,9]  R71       1.1042864016893368e+00
    phi[7,9]  R73       -1
    phi[7,9]  R2720     -1.5414638672571166e+00
    phi[7,9]  R2721     -4.6585359420080206e+00
    phi[7,9]  R2722     -4.0818607527375672e+00
    phi[7,9]  R2723     -3.9813926633591956e-01
    phi[7,9]  R2724     -1.2688089429944904e-01
    phi[7,9]  R2725     -6.0731189149656881e+00
    phi[7,9]  R2726     -4.1086496840051208e+00
    phi[7,9]  R2727     -1.0313501824804754e+00
    phi[7,9]  R2728     -5.1330936491561943e+00
    phi[7,9]  R2729     -1.0669061601089420e+00
    phi[7,9]  R2730     -3.5902020020478962e+00
    phi[7,9]  R2731     -5.8979782629072686e-01
    phi[7,9]  R2732     -1.9957135029432316e+00
    phi[7,9]  R2733     -4.2042863063219054e+00
    phi[7,9]  R2734     -1.7433751231214156e-01
    phi[7,9]  R2735     -1.8199880714411965e-01
    phi[7,9]  R2736     -1.8654173678455122e-01
    phi[7,9]  R2737     -1.8910974361507460e-01
    phi[7,9]  R2738     -8.1782248130811341e-01
    phi[7,9]  R2739     -1.8986965575480896e-01
    phi[7,9]  R2740     -4.1073473663977911e-01
    phi[7,9]  R2741     -3.1735053811288028e-01
    phi[7,9]  R2742     -1.9527538696998858e-01
    phi[7,9]  R2743     -1.9822727043597210e-01
    phi[7,9]  R2744     -2.0658000479745819e-01
    phi[7,9]  R2745     -2.1465486657867450e-01
    phi[7,9]  R2746     -2.3649527212522914e-01
    phi[7,9]  R2747     -0.266128439240072
    phi[7,9]  R2748     -3.0915869396486734e-01
    phi[7,9]  R2749     -3.2521958255055017e-01
    phi[7,9]  R2750     -3.3013933877024293e-01
    phi[7,9]  R2751     -3.5385509130678139e-01
    phi[7,9]  R2752     -3.7784665654413152e-01
    phi[7,9]  R2753     -0.424621226794031
    phi[7,9]  R2754     -1.8518979005957176e-01
    phi[7,9]  R2755     -1.9311940470693983e-01
    phi[7,9]  R2756     -1.9844960833574987e-01
    phi[7,9]  R2757     -2.2566862183766245e-01
    phi[7,9]  R2758     -2.3856717807662076e-01
    phi[7,9]  R2759     -2.6499165531946850e-01
    phi[7,9]  R2760     -2.8519566924443718e-01
    phi[7,9]  R2761     -3.5664344566471473e-01
    phi[7,9]  R2762     -3.6034674450060455e-01
    phi[7,9]  R2763     -0.391438658475598
    phi[7,9]  R2764     -1.6499674953510635e-01
    phi[7,9]  R2765     -1.8229605875521848e-01
    phi[7,9]  R2766     -1.9889316837366389e-01
    phi[7,9]  R2767     -2.6149732269614029e-01
    phi[7,9]  R2768     -3.1729118138262447e-01
    phi[7,9]  R2769     -6.6721365444311842e-01
    phi[7,9]  R2770     -6.8794187056708811e-01
    phi[7,9]  R2771     -1.2857275240152961e+00
    phi[7,9]  R2772     -2.9246072618019885e+00
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R74       -1
    z[0,1,0]  R75       1
    z[0,1,0]  R88       -4.6641939878463745e-01
    z[0,1,0]  R89       -7.0453971624374390e-01
    z[0,1,0]  R90       -8.3414804935455322e-01
    z[0,1,0]  R91       1.1175207793712616e-01
    z[0,1,0]  R92       1.1520291864871979e-01
    z[0,1,0]  R93       -3.8944080471992493e-01
    z[0,1,0]  R94       -1.6368374228477478e-01
    z[0,1,0]  R95       1.8946231901645660e-01
    z[0,1,0]  R96       -7.5923389196395874e-01
    z[0,1,0]  R97       -7.3668062686920166e-01
    z[0,1,0]  R98       6.8893986940383911e-01
    z[0,1,0]  R99       7.6871931552886963e-01
    z[0,1,0]  R100      6.2952494621276855e-01
    z[0,1,0]  R101      8.2327091693878174e-01
    z[0,1,0]  R102      8.6730796098709106e-01
    z[0,1,0]  R103      -2.9360942542552948e-02
    z[0,1,0]  R104      6.6267901659011841e-01
    z[0,1,0]  R105      -1.1476036906242371e-01
    z[0,1,0]  R106      1.5397189557552338e-01
    z[0,1,0]  R107      -1.9980345666408539e-01
    z[0,1,0]  R108      3.2366719841957092e-01
    z[0,1,0]  R109      1.2916807830333710e-01
    z[0,1,0]  R110      -3.1732532382011414e-01
    z[0,1,0]  R111      -2.8837111592292786e-01
    z[0,1,0]  R112      -2.3688845336437225e-01
    z[0,1,0]  R113      -4.4216677546501160e-01
    z[0,1,0]  R114      -3.2980591058731079e-01
    z[0,1,0]  R115      3.8844794034957886e-01
    z[0,1,0]  R116      1.9508582353591919e-01
    z[0,1,0]  R117      1.3773867487907410e-01
    z[0,1,0]  R118      -1.1814265698194504e-01
    z[0,1,0]  R119      7.9213090240955353e-02
    z[0,1,0]  R120      3.9299392700195312e-01
    z[0,1,0]  R121      7.8699356317520142e-01
    z[0,1,0]  R122      -5.1321196556091309e-01
    z[0,1,0]  R123      -1.9562399387359619e-01
    z[0,1,0]  R124      -2.2464221715927124e-01
    z[0,1,0]  R125      -1.3430775701999664e-01
    z[0,1,0]  R126      -3.8461828231811523e-01
    z[0,1,0]  R127      -4.5845183730125427e-01
    z[0,1,0]  R128      -6.7375445365905762e-01
    z[0,1,0]  R129      -6.9888913631439209e-01
    z[0,1,0]  R130      -0.594390869140625
    z[0,1,0]  R131      -5.7361841201782227e-01
    z[0,1,0]  R132      -8.2231032848358154e-01
    z[0,1,0]  R133      -6.2316077947616577e-01
    z[0,1,0]  R134      -5.8995449542999268e-01
    z[0,1,0]  R135      -5.8598655462265015e-01
    z[0,1,0]  R136      -0.606269121170044
    z[0,1,0]  R137      -6.2820702791213989e-01
    z[0,1,0]  R138      6.9167673587799072e-01
    z[0,1,0]  R139      5.3233176469802856e-01
    z[0,1,0]  R140      8.2345694303512573e-01
    z[0,1,0]  R141      6.9714194536209106e-01
    z[0,1,0]  R142      6.9522601366043091e-01
    z[0,1,0]  R143      5.7812613248825073e-01
    z[0,1,0]  R144      6.6528755426406860e-01
    z[0,1,0]  R145      3.6091324687004089e-01
    z[0,1,0]  R146      9.0225964784622192e-01
    z[0,1,0]  R147      6.9183218479156494e-01
    z[0,1,0]  R148      -1.3907539844512939e-01
    z[0,1,0]  R149      -3.6842882633209229e-01
    z[0,1,0]  R150      2.7511421591043472e-02
    z[0,1,0]  R151      3.3677688241004944e-01
    z[0,1,0]  R152      -3.0400383472442627e-01
    z[0,1,0]  R153      0.129286989569664
    z[0,1,0]  R154      2.0904533565044403e-01
    z[0,1,0]  R155      -2.5468206405639648e-01
    z[0,1,0]  R156      1.1293878406286240e-01
    z[0,1,0]  R157      4.3662047386169434e-01
    z[0,1,0]  R158      3.9613431692123413e-01
    z[0,1,0]  R159      -3.3349683880805969e-01
    z[0,1,0]  R160      -5.5167776346206665e-01
    z[0,1,0]  R161      -2.6409402489662170e-01
    z[0,1,0]  R162      -0.34183269739151
    z[0,1,0]  R163      5.2882835268974304e-02
    z[0,1,0]  R164      -8.3833348751068115e-01
    z[0,1,0]  R165      -0.0875013917684555
    z[0,1,0]  R166      1.0923463106155396e-01
    z[0,1,0]  R167      -1.5071013569831848e-01
    z[0,1,0]  R168      2.0982383191585541e-01
    z[0,1,0]  R169      -2.2338643670082092e-01
    z[0,1,0]  R170      -1.9661673903465271e-01
    z[0,1,0]  R171      4.1472226381301880e-01
    z[0,1,0]  R172      6.9381761550903320e-01
    z[0,1,0]  R173      1.7683707177639008e-01
    z[0,1,0]  R174      1.4207929372787476e-01
    z[0,1,0]  R175      5.0470888614654541e-02
    z[0,1,0]  R176      -1.8071976304054260e-01
    z[0,1,0]  R177      -1.8040654063224792e-01
    z[0,1,0]  R178      9.3746155500411987e-01
    z[0,1,0]  R179      7.5093394517898560e-01
    z[0,1,0]  R180      0.723858654499054
    z[0,1,0]  R181      7.9731434583663940e-01
    z[0,1,0]  R182      -1.7402684688568115e-01
    z[0,1,0]  R183      4.5955085754394531e-01
    z[0,1,0]  R184      -3.2479703426361084e-01
    z[0,1,0]  R185      -8.4862513467669487e-03
    z[0,1,0]  R186      -9.2845153808593750e-01
    z[0,1,0]  R187      -8.3313882350921631e-01
    z[0,1,0]  R188      -3.1924718618392944e-01
    z[0,1,0]  R189      -4.2675679922103882e-01
    z[0,1,0]  R190      8.1410235166549683e-01
    z[0,1,0]  R191      -3.7976104021072388e-01
    z[0,1,0]  R192      7.1696668863296509e-02
    z[0,1,0]  R193      -4.5697745680809021e-01
    z[0,1,0]  R194      -4.2993064969778061e-02
    z[0,1,0]  R195      1.0481332242488861e-01
    z[0,1,0]  R196      -1.7297340929508209e-01
    z[0,1,0]  R197      4.1590067744255066e-01
    z[0,1,0]  R198      3.9963892102241516e-01
    z[0,1,0]  R199      -4.4773986935615540e-01
    z[0,1,0]  R200      2.3669132962822914e-02
    z[0,1,0]  R201      -1.5191610157489777e-01
    z[0,1,0]  R202      -3.5037714242935181e-01
    z[0,1,0]  R203      -1.9325231015682220e-01
    z[0,1,0]  R204      3.1451320648193359e-01
    z[0,1,0]  R205      -3.1922420859336853e-01
    z[0,1,0]  R206      2.4484528601169586e-01
    z[0,1,0]  R207      -4.3561407923698425e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R76       -1
    z[0,1,1]  R77       1
    z[0,1,1]  R88       -4.7570931911468506e-01
    z[0,1,1]  R89       -4.3014129996299744e-01
    z[0,1,1]  R90       -2.8695923089981079e-01
    z[0,1,1]  R91       -5.2187931537628174e-01
    z[0,1,1]  R92       -5.2770727872848511e-01
    z[0,1,1]  R93       -3.2496684789657593e-01
    z[0,1,1]  R94       -4.6004673838615417e-01
    z[0,1,1]  R95       9.7268037497997284e-02
    z[0,1,1]  R96       4.9998548626899719e-01
    z[0,1,1]  R97       4.9960720539093018e-01
    z[0,1,1]  R98       4.1678699851036072e-01
    z[0,1,1]  R99       3.9600458741188049e-01
    z[0,1,1]  R100      4.0015059709548950e-01
    z[0,1,1]  R101      3.0832698941230774e-01
    z[0,1,1]  R102      5.2855193614959717e-02
    z[0,1,1]  R103      4.2598018050193787e-01
    z[0,1,1]  R104      2.2485505044460297e-01
    z[0,1,1]  R105      5.4225105047225952e-01
    z[0,1,1]  R106      0.570558488368988
    z[0,1,1]  R107      4.7694614529609680e-01
    z[0,1,1]  R108      1.1703601479530334e-01
    z[0,1,1]  R109      2.1596144139766693e-01
    z[0,1,1]  R110      5.5512094497680664e-01
    z[0,1,1]  R111      -3.9444932341575623e-01
    z[0,1,1]  R112      -4.9376094341278076e-01
    z[0,1,1]  R113      1.6450468450784683e-02
    z[0,1,1]  R114      2.7394685149192810e-01
    z[0,1,1]  R115      -7.9921215772628784e-01
    z[0,1,1]  R116      -7.0963591337203979e-01
    z[0,1,1]  R117      -7.0107567310333252e-01
    z[0,1,1]  R118      3.4259140491485596e-01
    z[0,1,1]  R119      -4.2591649293899536e-01
    z[0,1,1]  R120      -1.0025259107351303e-02
    z[0,1,1]  R121      -1.4046677947044373e-01
    z[0,1,1]  R122      -0.120124951004982
    z[0,1,1]  R123      5.8132618665695190e-01
    z[0,1,1]  R124      4.9475657939910889e-01
    z[0,1,1]  R125      7.3078292608261108e-01
    z[0,1,1]  R126      -0.00295339897274971
    z[0,1,1]  R127      4.6341851353645325e-02
    z[0,1,1]  R128      5.6581604480743408e-01
    z[0,1,1]  R129      4.6107420325279236e-01
    z[0,1,1]  R130      5.8846014738082886e-01
    z[0,1,1]  R131      6.0418677330017090e-01
    z[0,1,1]  R132      4.1971653699874878e-01
    z[0,1,1]  R133      4.7782710194587708e-01
    z[0,1,1]  R134      -0.0804959312081337
    z[0,1,1]  R135      -1.3034315407276154e-01
    z[0,1,1]  R136      4.8019781708717346e-01
    z[0,1,1]  R137      4.2548415064811707e-01
    z[0,1,1]  R138      1.3635043799877167e-01
    z[0,1,1]  R139      1.9816307723522186e-01
    z[0,1,1]  R140      1.8716986477375031e-01
    z[0,1,1]  R141      3.2812580466270447e-01
    z[0,1,1]  R142      4.3138720095157623e-02
    z[0,1,1]  R143      3.2618638873100281e-01
    z[0,1,1]  R144      3.6346804350614548e-02
    z[0,1,1]  R145      2.0694455131888390e-02
    z[0,1,1]  R146      1.6249081492424011e-01
    z[0,1,1]  R147      3.1555914878845215e-01
    z[0,1,1]  R148      -5.7555562257766724e-01
    z[0,1,1]  R149      2.9388232156634331e-02
    z[0,1,1]  R150      1.3200907409191132e-01
    z[0,1,1]  R151      7.3984724283218384e-01
    z[0,1,1]  R152      2.4440020322799683e-02
    z[0,1,1]  R153      -7.2986435890197754e-01
    z[0,1,1]  R154      -0.655773401260376
    z[0,1,1]  R155      1.0935997962951660e-01
    z[0,1,1]  R156      4.1971331834793091e-01
    z[0,1,1]  R157      -6.3583093881607056e-01
    z[0,1,1]  R158      -4.6782466769218445e-01
    z[0,1,1]  R159      -7.1851402521133423e-01
    z[0,1,1]  R160      -3.1521740555763245e-01
    z[0,1,1]  R161      -4.8395147919654846e-01
    z[0,1,1]  R162      -5.0472050905227661e-01
    z[0,1,1]  R163      -7.5323802232742310e-01
    z[0,1,1]  R164      -1.8055382370948792e-01
    z[0,1,1]  R165      1.0876475274562836e-01
    z[0,1,1]  R166      2.4585419893264771e-01
    z[0,1,1]  R167      4.6252235770225525e-01
    z[0,1,1]  R168      -3.5149574279785156e-01
    z[0,1,1]  R169      -3.2818189263343811e-01
    z[0,1,1]  R170      -4.5154190063476562e-01
    z[0,1,1]  R171      -7.6954740285873413e-01
    z[0,1,1]  R172      -1.4450900256633759e-01
    z[0,1,1]  R173      -6.8819504976272583e-01
    z[0,1,1]  R174      2.1572996675968170e-01
    z[0,1,1]  R175      3.8106867671012878e-01
    z[0,1,1]  R176      2.7672821283340454e-01
    z[0,1,1]  R177      -0.621740996837616
    z[0,1,1]  R178      -0.0515022911131382
    z[0,1,1]  R179      -2.8066793084144592e-01
    z[0,1,1]  R180      -2.8422072529792786e-01
    z[0,1,1]  R181      -2.2228258848190308e-01
    z[0,1,1]  R182      -5.4552555084228516e-01
    z[0,1,1]  R183      -2.5604084134101868e-01
    z[0,1,1]  R184      -8.0818790197372437e-01
    z[0,1,1]  R185      -8.4745258092880249e-01
    z[0,1,1]  R186      -1.9298858940601349e-01
    z[0,1,1]  R187      -1.9169786944985390e-02
    z[0,1,1]  R188      -1.4883506298065186e-01
    z[0,1,1]  R189      -3.3743056654930115e-01
    z[0,1,1]  R190      -3.2267636060714722e-01
    z[0,1,1]  R191      -3.5981380939483643e-01
    z[0,1,1]  R192      -5.5066061019897461e-01
    z[0,1,1]  R193      -8.3241373300552368e-01
    z[0,1,1]  R194      -4.0126565098762512e-01
    z[0,1,1]  R195      -0.325792133808136
    z[0,1,1]  R196      3.9969906210899353e-01
    z[0,1,1]  R197      -6.9523072242736816e-01
    z[0,1,1]  R198      -2.1889136731624603e-01
    z[0,1,1]  R199      -7.2267115116119385e-01
    z[0,1,1]  R200      -3.3751270174980164e-01
    z[0,1,1]  R201      5.9211593866348267e-01
    z[0,1,1]  R202      2.6231136918067932e-01
    z[0,1,1]  R203      4.2199438810348511e-01
    z[0,1,1]  R204      8.6712735891342163e-01
    z[0,1,1]  R205      9.4980537891387939e-02
    z[0,1,1]  R206      -6.7621898651123047e-01
    z[0,1,1]  R207      2.8200818225741386e-02
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R78       -1
    z[0,1,2]  R79       1
    z[0,1,2]  R88       -2.7751281857490540e-01
    z[0,1,2]  R89       3.2427478581666946e-02
    z[0,1,2]  R90       -2.1592350304126740e-01
    z[0,1,2]  R91       2.3749215900897980e-01
    z[0,1,2]  R92       1.6844940185546875e-01
    z[0,1,2]  R93       -1.6035212576389313e-01
    z[0,1,2]  R94       4.0930435061454773e-02
    z[0,1,2]  R95       -8.3011329174041748e-02
    z[0,1,2]  R96       0.282932847738266
    z[0,1,2]  R97       1.0794003307819366e-01
    z[0,1,2]  R98       5.0963485240936279e-01
    z[0,1,2]  R99       2.9356148838996887e-01
    z[0,1,2]  R100      3.5316619277000427e-01
    z[0,1,2]  R101      2.4036282300949097e-01
    z[0,1,2]  R102      -8.5613265633583069e-02
    z[0,1,2]  R103      4.1041418910026550e-01
    z[0,1,2]  R104      -1.1305548995733261e-01
    z[0,1,2]  R105      -2.3243862390518188e-01
    z[0,1,2]  R106      -4.3270260095596313e-01
    z[0,1,2]  R107      -1.4517985284328461e-01
    z[0,1,2]  R108      2.1311147511005402e-01
    z[0,1,2]  R109      5.4877460002899170e-01
    z[0,1,2]  R110      3.2962255179882050e-02
    z[0,1,2]  R111      -2.2074329853057861e-01
    z[0,1,2]  R112      -4.7355014085769653e-01
    z[0,1,2]  R113      -1.0937143862247467e-01
    z[0,1,2]  R114      1.5144604444503784e-01
    z[0,1,2]  R115      -6.7280530929565430e-02
    z[0,1,2]  R116      2.2395841777324677e-01
    z[0,1,2]  R117      3.5116162896156311e-01
    z[0,1,2]  R118      3.6203429102897644e-01
    z[0,1,2]  R119      -2.9231157898902893e-01
    z[0,1,2]  R120      -4.4138431549072266e-01
    z[0,1,2]  R121      0.106072336435318
    z[0,1,2]  R122      -6.7699514329433441e-02
    z[0,1,2]  R123      -5.5849432945251465e-01
    z[0,1,2]  R124      -3.3190563321113586e-02
    z[0,1,2]  R125      -4.8151548951864243e-02
    z[0,1,2]  R126      -5.4949706792831421e-01
    z[0,1,2]  R127      -3.5029265284538269e-01
    z[0,1,2]  R128      -1.8583782017230988e-01
    z[0,1,2]  R129      4.0435454249382019e-01
    z[0,1,2]  R130      4.9485184252262115e-02
    z[0,1,2]  R131      3.0327681452035904e-02
    z[0,1,2]  R132      1.4825256168842316e-01
    z[0,1,2]  R133      3.9322644472122192e-01
    z[0,1,2]  R134      3.4202730655670166e-01
    z[0,1,2]  R135      3.8173198699951172e-01
    z[0,1,2]  R136      8.3235532045364380e-02
    z[0,1,2]  R137      3.8509148359298706e-01
    z[0,1,2]  R138      3.6533221602439880e-01
    z[0,1,2]  R139      6.9461631774902344e-01
    z[0,1,2]  R140      4.7899049520492554e-01
    z[0,1,2]  R141      2.2634410858154297e-01
    z[0,1,2]  R142      4.1579627990722656e-01
    z[0,1,2]  R143      4.0311416983604431e-01
    z[0,1,2]  R144      2.3965889215469360e-01
    z[0,1,2]  R145      7.5463271141052246e-01
    z[0,1,2]  R146      6.9754309952259064e-02
    z[0,1,2]  R147      4.0157452225685120e-01
    z[0,1,2]  R148      0.372557133436203
    z[0,1,2]  R149      -1.4441660046577454e-01
    z[0,1,2]  R150      -5.6320565938949585e-01
    z[0,1,2]  R151      -3.5228511691093445e-01
    z[0,1,2]  R152      -3.0513930320739746e-01
    z[0,1,2]  R153      4.9704313278198242e-01
    z[0,1,2]  R154      4.5590788125991821e-01
    z[0,1,2]  R155      -6.6915452480316162e-01
    z[0,1,2]  R156      -5.5253100395202637e-01
    z[0,1,2]  R157      3.0519595742225647e-01
    z[0,1,2]  R158      6.9835972785949707e-01
    z[0,1,2]  R159      2.0382064580917358e-01
    z[0,1,2]  R160      -2.1288146078586578e-01
    z[0,1,2]  R161      6.2886893749237061e-01
    z[0,1,2]  R162      1.3575246930122375e-01
    z[0,1,2]  R163      4.6135470271110535e-01
    z[0,1,2]  R164      -2.4484296143054962e-01
    z[0,1,2]  R165      -2.1331357955932617e-01
    z[0,1,2]  R166      -4.6741876006126404e-01
    z[0,1,2]  R167      -6.8512326478958130e-01
    z[0,1,2]  R168      6.0631680488586426e-01
    z[0,1,2]  R169      8.0816090106964111e-01
    z[0,1,2]  R170      7.1812593936920166e-01
    z[0,1,2]  R171      -1.1645172536373138e-01
    z[0,1,2]  R172      -2.2195224463939667e-01
    z[0,1,2]  R173      -3.4744247794151306e-01
    z[0,1,2]  R174      -6.0679125785827637e-01
    z[0,1,2]  R175      -3.5761341452598572e-01
    z[0,1,2]  R176      -1.6917374730110168e-01
    z[0,1,2]  R177      -3.7453171610832214e-01
    z[0,1,2]  R178      -2.8504827991127968e-02
    z[0,1,2]  R179      2.3543396592140198e-01
    z[0,1,2]  R180      5.1484811305999756e-01
    z[0,1,2]  R181      1.7536431550979614e-01
    z[0,1,2]  R182      3.4148257970809937e-01
    z[0,1,2]  R183      5.8263164758682251e-01
    z[0,1,2]  R184      1.6801603138446808e-01
    z[0,1,2]  R185      -9.2448271811008453e-02
    z[0,1,2]  R186      -7.8539937734603882e-02
    z[0,1,2]  R187      1.2315201759338379e-01
    z[0,1,2]  R188      6.9656980037689209e-01
    z[0,1,2]  R189      2.5004261732101440e-01
    z[0,1,2]  R190      2.6816296577453613e-01
    z[0,1,2]  R191      3.6138707399368286e-01
    z[0,1,2]  R192      4.6646651625633240e-01
    z[0,1,2]  R193      4.0568541735410690e-02
    z[0,1,2]  R194      7.9084801673889160e-01
    z[0,1,2]  R195      6.8234455585479736e-01
    z[0,1,2]  R196      -3.0624341964721680e-01
    z[0,1,2]  R197      -4.8970249295234680e-01
    z[0,1,2]  R198      6.5157341957092285e-01
    z[0,1,2]  R199      1.8652480095624924e-02
    z[0,1,2]  R200      6.6115683317184448e-01
    z[0,1,2]  R201      -1.5419077873229980e-01
    z[0,1,2]  R202      -1.6393500566482544e-01
    z[0,1,2]  R203      -5.4945224523544312e-01
    z[0,1,2]  R204      -1.7873485386371613e-01
    z[0,1,2]  R205      -2.0642848312854767e-01
    z[0,1,2]  R206      -3.5644856095314026e-01
    z[0,1,2]  R207      -0.48117595911026
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R80       -1
    z[0,1,3]  R81       1
    z[0,1,3]  R88       1.9135875999927521e-01
    z[0,1,3]  R89       6.8657793104648590e-02
    z[0,1,3]  R90       3.0188897252082825e-01
    z[0,1,3]  R91       2.8336721658706665e-01
    z[0,1,3]  R92       1.4530107378959656e-01
    z[0,1,3]  R93       4.2767179012298584e-01
    z[0,1,3]  R94       8.2895606756210327e-02
    z[0,1,3]  R95       2.5135058164596558e-01
    z[0,1,3]  R96       -7.1884766221046448e-02
    z[0,1,3]  R97       -9.1833256185054779e-02
    z[0,1,3]  R98       1.5541224181652069e-01
    z[0,1,3]  R99       2.2369624674320221e-01
    z[0,1,3]  R100      4.6875947713851929e-01
    z[0,1,3]  R101      2.9892998933792114e-01
    z[0,1,3]  R102      1.7789126932621002e-01
    z[0,1,3]  R103      0.769805908203125
    z[0,1,3]  R104      5.9138017892837524e-01
    z[0,1,3]  R105      1.6783721745014191e-01
    z[0,1,3]  R106      4.6502524614334106e-01
    z[0,1,3]  R107      6.3687413930892944e-01
    z[0,1,3]  R108      8.1289058923721313e-01
    z[0,1,3]  R109      4.5772558450698853e-01
    z[0,1,3]  R110      2.7774566411972046e-01
    z[0,1,3]  R111      -7.3069196939468384e-01
    z[0,1,3]  R112      -5.3437966108322144e-01
    z[0,1,3]  R113      -7.3799526691436768e-01
    z[0,1,3]  R114      -3.4302836656570435e-01
    z[0,1,3]  R115      2.0139060914516449e-01
    z[0,1,3]  R116      3.0195074155926704e-02
    z[0,1,3]  R117      -2.8804862499237061e-01
    z[0,1,3]  R118      7.4857777357101440e-01
    z[0,1,3]  R119      8.1203043460845947e-01
    z[0,1,3]  R120      6.4871352910995483e-01
    z[0,1,3]  R121      2.7941519021987915e-01
    z[0,1,3]  R122      -0.682442307472229
    z[0,1,3]  R123      2.4517105892300606e-02
    z[0,1,3]  R124      1.1850558966398239e-01
    z[0,1,3]  R125      -1.5918090939521790e-02
    z[0,1,3]  R126      -2.7980056405067444e-01
    z[0,1,3]  R127      -5.4726260900497437e-01
    z[0,1,3]  R128      8.6268782615661621e-02
    z[0,1,3]  R129      7.9351119697093964e-02
    z[0,1,3]  R130      -4.1238284111022949e-01
    z[0,1,3]  R131      0.27255779504776
    z[0,1,3]  R132      -1.6743110120296478e-01
    z[0,1,3]  R133      -7.4745684862136841e-02
    z[0,1,3]  R134      -0.693411111831665
    z[0,1,3]  R135      -6.0715156793594360e-01
    z[0,1,3]  R136      -4.3046516180038452e-01
    z[0,1,3]  R137      1.0837700963020325e-01
    z[0,1,3]  R138      3.6152294278144836e-01
    z[0,1,3]  R139      2.4025149643421173e-01
    z[0,1,3]  R140      -3.9704661816358566e-02
    z[0,1,3]  R141      1.3632193207740784e-01
    z[0,1,3]  R142      9.5584288239479065e-02
    z[0,1,3]  R143      5.7831990718841553e-01
    z[0,1,3]  R144      1.0920634120702744e-01
    z[0,1,3]  R145      1.6979576647281647e-01
    z[0,1,3]  R146      -8.3034120500087738e-02
    z[0,1,3]  R147      4.5772495865821838e-01
    z[0,1,3]  R148      -1.1041700094938278e-01
    z[0,1,3]  R149      8.7938672304153442e-01
    z[0,1,3]  R150      7.2547090053558350e-01
    z[0,1,3]  R151      1.1537463963031769e-01
    z[0,1,3]  R152      6.1914795637130737e-01
    z[0,1,3]  R153      0.170075923204422
    z[0,1,3]  R154      2.6926058530807495e-01
    z[0,1,3]  R155      5.0105082988739014e-01
    z[0,1,3]  R156      5.0233274698257446e-01
    z[0,1,3]  R157      5.8124684728682041e-03
    z[0,1,3]  R158      1.3400685787200928e-01
    z[0,1,3]  R159      3.0896854400634766e-01
    z[0,1,3]  R160      -1.0778423398733139e-01
    z[0,1,3]  R161      4.3510311841964722e-01
    z[0,1,3]  R162      -1.0263931006193161e-01
    z[0,1,3]  R163      -2.2846798598766327e-01
    z[0,1,3]  R164      1.6738660633563995e-01
    z[0,1,3]  R165      8.6282485723495483e-01
    z[0,1,3]  R166      7.1221959590911865e-01
    z[0,1,3]  R167      4.8533996939659119e-01
    z[0,1,3]  R168      -4.1398438811302185e-01
    z[0,1,3]  R169      4.2451298236846924e-01
    z[0,1,3]  R170      -2.6501944661140442e-01
    z[0,1,3]  R171      -1.0121706128120422e-01
    z[0,1,3]  R172      -8.4021300077438354e-02
    z[0,1,3]  R173      1.9870984554290771e-01
    z[0,1,3]  R174      6.7457318305969238e-01
    z[0,1,3]  R175      6.5682178735733032e-01
    z[0,1,3]  R176      6.9819372892379761e-01
    z[0,1,3]  R177      0.532219648361206
    z[0,1,3]  R178      1.5586647391319275e-01
    z[0,1,3]  R179      4.0449678897857666e-01
    z[0,1,3]  R180      -8.4880597889423370e-02
    z[0,1,3]  R181      4.5831638574600220e-01
    z[0,1,3]  R182      2.3949561640620232e-02
    z[0,1,3]  R183      4.4943434000015259e-01
    z[0,1,3]  R184      -0.0392412431538105
    z[0,1,3]  R185      2.4432432651519775e-01
    z[0,1,3]  R186      2.8851801156997681e-01
    z[0,1,3]  R187      5.0724571943283081e-01
    z[0,1,3]  R188      9.2477187514305115e-02
    z[0,1,3]  R189      -3.3023558557033539e-02
    z[0,1,3]  R190      3.7392783164978027e-01
    z[0,1,3]  R191      -8.7873362004756927e-02
    z[0,1,3]  R192      -6.6005373001098633e-01
    z[0,1,3]  R193      -1.6353135928511620e-02
    z[0,1,3]  R194      -2.2524943947792053e-01
    z[0,1,3]  R195      1.6651917248964310e-02
    z[0,1,3]  R196      7.5210946798324585e-01
    z[0,1,3]  R197      -2.6873955503106117e-02
    z[0,1,3]  R198      -2.3450862616300583e-02
    z[0,1,3]  R199      2.2883121669292450e-01
    z[0,1,3]  R200      2.7994289994239807e-01
    z[0,1,3]  R201      -1.3547608256340027e-01
    z[0,1,3]  R202      7.6073713600635529e-02
    z[0,1,3]  R203      5.8836966753005981e-01
    z[0,1,3]  R204      1.2514644861221313e-01
    z[0,1,3]  R205      7.5729668140411377e-01
    z[0,1,3]  R206      8.8596068322658539e-02
    z[0,1,3]  R207      4.1238108277320862e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R82       -1
    z[0,1,4]  R83       1
    z[0,1,4]  R88       -1.3734026253223419e-01
    z[0,1,4]  R89       1.9689242541790009e-01
    z[0,1,4]  R90       -1.7872823402285576e-02
    z[0,1,4]  R91       5.4330664873123169e-01
    z[0,1,4]  R92       2.6512509584426880e-01
    z[0,1,4]  R93       -1.5441097319126129e-01
    z[0,1,4]  R94       6.2950074672698975e-01
    z[0,1,4]  R95       -5.1566797494888306e-01
    z[0,1,4]  R96       -1.8406768143177032e-01
    z[0,1,4]  R97       1.5364494174718857e-02
    z[0,1,4]  R98       1.1874731630086899e-01
    z[0,1,4]  R99       1.5236093103885651e-01
    z[0,1,4]  R100      1.5645581483840942e-01
    z[0,1,4]  R101      5.7624153792858124e-02
    z[0,1,4]  R102      4.5855669304728508e-03
    z[0,1,4]  R103      2.3364938795566559e-01
    z[0,1,4]  R104      1.2672841548919678e-02
    z[0,1,4]  R105      -3.7586815655231476e-02
    z[0,1,4]  R106      4.5307138562202454e-01
    z[0,1,4]  R107      -1.8788692355155945e-01
    z[0,1,4]  R108      3.4083411097526550e-01
    z[0,1,4]  R109      2.6868802309036255e-01
    z[0,1,4]  R110      0.0283999964594841
    z[0,1,4]  R111      -3.1247171759605408e-01
    z[0,1,4]  R112      -1.0955525189638138e-01
    z[0,1,4]  R113      1.6455663368105888e-02
    z[0,1,4]  R114      3.3897200226783752e-01
    z[0,1,4]  R115      -2.9044884443283081e-01
    z[0,1,4]  R116      -5.1221090555191040e-01
    z[0,1,4]  R117      -5.1322090625762939e-01
    z[0,1,4]  R118      0.061478141695261
    z[0,1,4]  R119      2.3901236057281494e-01
    z[0,1,4]  R120      -2.7215710282325745e-01
    z[0,1,4]  R121      3.7062233686447144e-01
    z[0,1,4]  R122      1.1155769973993301e-01
    z[0,1,4]  R123      -4.0102687478065491e-01
    z[0,1,4]  R124      -3.8252141326665878e-02
    z[0,1,4]  R125      4.2325085401535034e-01
    z[0,1,4]  R126      -3.5322535037994385e-01
    z[0,1,4]  R127      -2.2889564931392670e-01
    z[0,1,4]  R128      -1.2811103463172913e-01
    z[0,1,4]  R129      9.8769381642341614e-02
    z[0,1,4]  R130      3.9514090865850449e-02
    z[0,1,4]  R131      1.7906357347965240e-01
    z[0,1,4]  R132      5.0745550543069839e-02
    z[0,1,4]  R133      -3.1483915448188782e-01
    z[0,1,4]  R134      1.2532761693000793e-01
    z[0,1,4]  R135      2.5661385059356689e-01
    z[0,1,4]  R136      -1.0935959964990616e-01
    z[0,1,4]  R137      -0.383960098028183
    z[0,1,4]  R138      -1.0561495274305344e-01
    z[0,1,4]  R139      -6.1047445982694626e-02
    z[0,1,4]  R140      -2.4713041260838509e-02
    z[0,1,4]  R141      2.0410059392452240e-01
    z[0,1,4]  R142      -2.5440940260887146e-01
    z[0,1,4]  R143      -1.5176208317279816e-01
    z[0,1,4]  R144      -1.5687119215726852e-02
    z[0,1,4]  R145      3.0090346932411194e-02
    z[0,1,4]  R146      2.2111959755420685e-01
    z[0,1,4]  R147      -1.6021193563938141e-01
    z[0,1,4]  R148      -6.7464607954025269e-01
    z[0,1,4]  R149      -7.1750218048691750e-03
    z[0,1,4]  R150      -1.0470546036958694e-01
    z[0,1,4]  R151      3.6146417260169983e-02
    z[0,1,4]  R152      4.6560221910476685e-01
    z[0,1,4]  R153      -2.4388229846954346e-01
    z[0,1,4]  R154      -0.421680748462677
    z[0,1,4]  R155      1.0703993588685989e-01
    z[0,1,4]  R156      4.0497452020645142e-01
    z[0,1,4]  R157      5.0599622726440430e-01
    z[0,1,4]  R158      -1.1077462881803513e-01
    z[0,1,4]  R159      4.4569492340087891e-01
    z[0,1,4]  R160      5.8734100311994553e-02
    z[0,1,4]  R161      2.5616383552551270e-01
    z[0,1,4]  R162      1.9701224565505981e-01
    z[0,1,4]  R163      -8.4607586264610291e-02
    z[0,1,4]  R164      -2.1708090603351593e-01
    z[0,1,4]  R165      3.2076227664947510e-01
    z[0,1,4]  R166      3.6794742941856384e-01
    z[0,1,4]  R167      7.5871430337429047e-02
    z[0,1,4]  R168      -4.4188475608825684e-01
    z[0,1,4]  R169      3.7901178002357483e-02
    z[0,1,4]  R170      -3.8594129681587219e-01
    z[0,1,4]  R171      -0.196554496884346
    z[0,1,4]  R172      -6.4528220891952515e-01
    z[0,1,4]  R173      3.7812665104866028e-01
    z[0,1,4]  R174      -2.7227890491485596e-01
    z[0,1,4]  R175      -4.9730318784713745e-01
    z[0,1,4]  R176      -4.7969445586204529e-01
    z[0,1,4]  R177      -3.1444844603538513e-01
    z[0,1,4]  R178      -2.6763904094696045e-01
    z[0,1,4]  R179      -3.6290460824966431e-01
    z[0,1,4]  R180      1.3922120630741119e-01
    z[0,1,4]  R181      2.2006702423095703e-01
    z[0,1,4]  R182      -1.4936453104019165e-01
    z[0,1,4]  R183      3.6574614048004150e-01
    z[0,1,4]  R184      -2.0260740816593170e-01
    z[0,1,4]  R185      -4.5631805062294006e-01
    z[0,1,4]  R186      -7.9937577247619629e-03
    z[0,1,4]  R187      -1.2307025492191315e-01
    z[0,1,4]  R188      -2.0108424127101898e-01
    z[0,1,4]  R189      7.9773432016372681e-01
    z[0,1,4]  R190      2.9656341299414635e-02
    z[0,1,4]  R191      -4.3531331419944763e-01
    z[0,1,4]  R192      -1.5251480042934418e-02
    z[0,1,4]  R193      1.6486409306526184e-01
    z[0,1,4]  R194      3.1822186708450317e-01
    z[0,1,4]  R195      3.8033452630043030e-01
    z[0,1,4]  R196      -2.7622884511947632e-01
    z[0,1,4]  R197      6.9422118365764618e-02
    z[0,1,4]  R198      -2.4084742367267609e-01
    z[0,1,4]  R199      2.7856758236885071e-01
    z[0,1,4]  R200      3.8693848252296448e-01
    z[0,1,4]  R201      4.1001993417739868e-01
    z[0,1,4]  R202      7.1121048927307129e-01
    z[0,1,4]  R203      3.3168014883995056e-01
    z[0,1,4]  R204      0.187080979347229
    z[0,1,4]  R205      1.0877946764230728e-01
    z[0,1,4]  R206      -2.9853085055947304e-02
    z[0,1,4]  R207      3.7477380037307739e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R84       -1
    z[0,1,5]  R85       1
    z[0,1,5]  R88       6.4809662103652954e-01
    z[0,1,5]  R89       5.0592297315597534e-01
    z[0,1,5]  R90       2.8670877218246460e-01
    z[0,1,5]  R91       4.8585128784179688e-01
    z[0,1,5]  R92       6.3074672222137451e-01
    z[0,1,5]  R93       1.6453932970762253e-02
    z[0,1,5]  R94       3.2417336106300354e-01
    z[0,1,5]  R95       0.781249463558197
    z[0,1,5]  R96       9.1276556253433228e-02
    z[0,1,5]  R97       -2.5241073966026306e-01
    z[0,1,5]  R98       4.1232284158468246e-02
    z[0,1,5]  R99       4.1825573891401291e-02
    z[0,1,5]  R100      -2.2501009702682495e-01
    z[0,1,5]  R101      -2.1672993898391724e-01
    z[0,1,5]  R102      1.8610468506813049e-01
    z[0,1,5]  R103      -6.4693358726799488e-03
    z[0,1,5]  R104      -2.6729911565780640e-01
    z[0,1,5]  R105      4.4847447425127029e-02
    z[0,1,5]  R106      1.5220044553279877e-01
    z[0,1,5]  R107      -4.5384258031845093e-01
    z[0,1,5]  R108      1.6075240075588226e-01
    z[0,1,5]  R109      -1.6099143773317337e-02
    z[0,1,5]  R110      -4.0589755773544312e-01
    z[0,1,5]  R111      -2.6492691040039062e-01
    z[0,1,5]  R112      -4.0279945731163025e-01
    z[0,1,5]  R113      -2.4074497818946838e-01
    z[0,1,5]  R114      -4.8913535475730896e-01
    z[0,1,5]  R115      -2.5961726903915405e-01
    z[0,1,5]  R116      -1.9433766603469849e-01
    z[0,1,5]  R117      -1.1268361657857895e-01
    z[0,1,5]  R118      4.0919068455696106e-01
    z[0,1,5]  R119      5.9867627918720245e-02
    z[0,1,5]  R120      1.3973297178745270e-01
    z[0,1,5]  R121      2.2402912378311157e-01
    z[0,1,5]  R122      -2.6954427361488342e-01
    z[0,1,5]  R123      -1.1689981073141098e-01
    z[0,1,5]  R124      -1.0135784000158310e-01
    z[0,1,5]  R125      -9.9021323025226593e-02
    z[0,1,5]  R126      -4.6825075149536133e-01
    z[0,1,5]  R127      -4.3617191910743713e-01
    z[0,1,5]  R128      -1.4402790367603302e-01
    z[0,1,5]  R129      4.5146383345127106e-02
    z[0,1,5]  R130      1.1751770973205566e-01
    z[0,1,5]  R131      4.2257276177406311e-01
    z[0,1,5]  R132      1.0330075025558472e-01
    z[0,1,5]  R133      3.4574690461158752e-01
    z[0,1,5]  R134      1.7807528376579285e-01
    z[0,1,5]  R135      -1.4250756241381168e-02
    z[0,1,5]  R136      5.1383594982326031e-03
    z[0,1,5]  R137      -1.3030184805393219e-01
    z[0,1,5]  R138      4.7639212012290955e-01
    z[0,1,5]  R139      3.3835160732269287e-01
    z[0,1,5]  R140      1.3196520507335663e-01
    z[0,1,5]  R141      5.4228603839874268e-01
    z[0,1,5]  R142      0.332433819770813
    z[0,1,5]  R143      1.7465837299823761e-01
    z[0,1,5]  R144      5.2098482847213745e-01
    z[0,1,5]  R145      5.0092417001724243e-01
    z[0,1,5]  R146      3.1437876820564270e-01
    z[0,1,5]  R147      -0.0597243569791317
    z[0,1,5]  R148      -1.8792058527469635e-01
    z[0,1,5]  R149      -1.9813102483749390e-01
    z[0,1,5]  R150      -3.5396766662597656e-01
    z[0,1,5]  R151      -1.2771297991275787e-01
    z[0,1,5]  R152      -4.5337450504302979e-01
    z[0,1,5]  R153      -2.8609189391136169e-01
    z[0,1,5]  R154      -1.7389757931232452e-01
    z[0,1,5]  R155      -4.0819168090820312e-01
    z[0,1,5]  R156      -2.2313356399536133e-01
    z[0,1,5]  R157      -2.3613187670707703e-01
    z[0,1,5]  R158      1.8409633636474609e-01
    z[0,1,5]  R159      8.4336094558238983e-02
    z[0,1,5]  R160      7.1165359020233154e-01
    z[0,1,5]  R161      -1.4875005185604095e-01
    z[0,1,5]  R162      -2.2034212946891785e-01
    z[0,1,5]  R163      -2.9223549365997314e-01
    z[0,1,5]  R164      -1.1317928880453110e-01
    z[0,1,5]  R165      -2.9599642753601074e-01
    z[0,1,5]  R166      -2.4392421543598175e-01
    z[0,1,5]  R167      -1.7684239149093628e-01
    z[0,1,5]  R168      3.1072497367858887e-01
    z[0,1,5]  R169      8.6572587490081787e-02
    z[0,1,5]  R170      9.3467950820922852e-02
    z[0,1,5]  R171      2.9265916347503662e-01
    z[0,1,5]  R172      9.4040319323539734e-02
    z[0,1,5]  R173      -0.300374835729599
    z[0,1,5]  R174      -1.2064851820468903e-01
    z[0,1,5]  R175      2.1226347982883453e-01
    z[0,1,5]  R176      2.9925328493118286e-01
    z[0,1,5]  R177      -2.4028530716896057e-01
    z[0,1,5]  R178      8.8568501174449921e-02
    z[0,1,5]  R179      -1.9132284214720130e-03
    z[0,1,5]  R180      2.4026885628700256e-01
    z[0,1,5]  R181      -6.7815303802490234e-02
    z[0,1,5]  R182      1.4808064699172974e-01
    z[0,1,5]  R183      -9.7954049706459045e-02
    z[0,1,5]  R184      -4.0656840801239014e-01
    z[0,1,5]  R185      5.9593491256237030e-02
    z[0,1,5]  R186      1.0588598251342773e-01
    z[0,1,5]  R187      -6.8894013762474060e-02
    z[0,1,5]  R188      4.7643181681632996e-01
    z[0,1,5]  R189      6.1530273407697678e-02
    z[0,1,5]  R190      -0.0348796509206295
    z[0,1,5]  R191      5.9020388126373291e-01
    z[0,1,5]  R192      -1.7851024866104126e-01
    z[0,1,5]  R193      -2.3533992469310760e-01
    z[0,1,5]  R194      1.3561421632766724e-01
    z[0,1,5]  R195      -2.1379022300243378e-01
    z[0,1,5]  R196      2.2489269077777863e-01
    z[0,1,5]  R197      -2.5495597720146179e-01
    z[0,1,5]  R198      4.8909124732017517e-01
    z[0,1,5]  R199      3.2360464334487915e-01
    z[0,1,5]  R200      1.2746696174144745e-01
    z[0,1,5]  R201      -6.3453322649002075e-01
    z[0,1,5]  R202      -3.8612812757492065e-01
    z[0,1,5]  R203      -1.6239969432353973e-01
    z[0,1,5]  R204      -2.5596126914024353e-01
    z[0,1,5]  R205      -4.0585622191429138e-01
    z[0,1,5]  R206      -4.1404470801353455e-01
    z[0,1,5]  R207      -4.8035117983818054e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R86       -1
    z[0,1,6]  R87       1
    z[0,1,6]  R88       -6.0252517461776733e-02
    z[0,1,6]  R89       -1.3458128273487091e-01
    z[0,1,6]  R90       3.9626464247703552e-02
    z[0,1,6]  R91       -2.1730247139930725e-01
    z[0,1,6]  R92       -4.3661540746688843e-01
    z[0,1,6]  R93       -7.1414500474929810e-01
    z[0,1,6]  R94       5.0165539979934692e-01
    z[0,1,6]  R95       -9.1163434088230133e-02
    z[0,1,6]  R96       -2.1482041478157043e-01
    z[0,1,6]  R97       -3.5165694355964661e-01
    z[0,1,6]  R98       -2.2796644270420074e-01
    z[0,1,6]  R99       3.0177685618400574e-01
    z[0,1,6]  R100      -1.5494552254676819e-01
    z[0,1,6]  R101      -1.7243444919586182e-01
    z[0,1,6]  R102      4.1394731402397156e-01
    z[0,1,6]  R103      -4.4765327125787735e-02
    z[0,1,6]  R104      2.7599847316741943e-01
    z[0,1,6]  R105      7.7921295166015625e-01
    z[0,1,6]  R106      -1.3724772632122040e-01
    z[0,1,6]  R107      2.5424492359161377e-01
    z[0,1,6]  R108      1.8255215883255005e-01
    z[0,1,6]  R109      -5.9460711479187012e-01
    z[0,1,6]  R110      5.8936983346939087e-01
    z[0,1,6]  R111      1.0386855900287628e-01
    z[0,1,6]  R112      -1.2658125162124634e-01
    z[0,1,6]  R113      0.435189425945282
    z[0,1,6]  R114      5.6694036722183228e-01
    z[0,1,6]  R115      1.1628223955631256e-01
    z[0,1,6]  R116      3.2735636830329895e-01
    z[0,1,6]  R117      8.4505289793014526e-02
    z[0,1,6]  R118      -0.0775846540927887
    z[0,1,6]  R119      8.2278758287429810e-02
    z[0,1,6]  R120      3.6906811594963074e-01
    z[0,1,6]  R121      2.8988981246948242e-01
    z[0,1,6]  R122      4.0837913751602173e-01
    z[0,1,6]  R123      3.6984574794769287e-01
    z[0,1,6]  R124      8.2332855463027954e-01
    z[0,1,6]  R125      5.0635886192321777e-01
    z[0,1,6]  R126      3.5748815536499023e-01
    z[0,1,6]  R127      3.5047656297683716e-01
    z[0,1,6]  R128      3.8310918211936951e-01
    z[0,1,6]  R129      3.4259554743766785e-01
    z[0,1,6]  R130      3.3546081185340881e-01
    z[0,1,6]  R131      -0.141708105802536
    z[0,1,6]  R132      2.9049226641654968e-01
    z[0,1,6]  R133      -6.6882841289043427e-02
    z[0,1,6]  R134      -1.5954727306962013e-02
    z[0,1,6]  R135      2.4336050450801849e-01
    z[0,1,6]  R136      -4.4455981254577637e-01
    z[0,1,6]  R137      -3.1602874398231506e-01
    z[0,1,6]  R138      2.6858173310756683e-02
    z[0,1,6]  R139      1.3759815692901611e-01
    z[0,1,6]  R140      -1.9455698132514954e-01
    z[0,1,6]  R141      -2.7928901836276054e-02
    z[0,1,6]  R142      3.9691379666328430e-01
    z[0,1,6]  R143      -9.4235010445117950e-02
    z[0,1,6]  R144      -4.6372160315513611e-01
    z[0,1,6]  R145      1.3849860429763794e-01
    z[0,1,6]  R146      6.0068508610129356e-03
    z[0,1,6]  R147      1.4758543670177460e-01
    z[0,1,6]  R148      8.9115403592586517e-02
    z[0,1,6]  R149      -1.7295074462890625e-01
    z[0,1,6]  R150      4.5295480638742447e-02
    z[0,1,6]  R151      -0.429155170917511
    z[0,1,6]  R152      -9.0533353388309479e-02
    z[0,1,6]  R153      -1.8242296576499939e-01
    z[0,1,6]  R154      -1.9455881416797638e-01
    z[0,1,6]  R155      -2.1512724459171295e-01
    z[0,1,6]  R156      1.9915764033794403e-01
    z[0,1,6]  R157      1.0617773979902267e-02
    z[0,1,6]  R158      -2.6905581355094910e-01
    z[0,1,6]  R159      -1.7250110208988190e-01
    z[0,1,6]  R160      1.7161907255649567e-01
    z[0,1,6]  R161      1.5332300961017609e-01
    z[0,1,6]  R162      -7.1559733152389526e-01
    z[0,1,6]  R163      -2.6875638961791992e-01
    z[0,1,6]  R164      -3.4160980582237244e-01
    z[0,1,6]  R165      -6.4790071919560432e-03
    z[0,1,6]  R166      -8.3678871393203735e-02
    z[0,1,6]  R167      1.4622308313846588e-01
    z[0,1,6]  R168      -4.0118601173162460e-02
    z[0,1,6]  R169      -0.0113369794562459
    z[0,1,6]  R170      1.1757802218198776e-01
    z[0,1,6]  R171      -2.9616445302963257e-01
    z[0,1,6]  R172      -1.2719714641571045e-01
    z[0,1,6]  R173      3.1891950964927673e-01
    z[0,1,6]  R174      -1.4607398211956024e-01
    z[0,1,6]  R175      2.3893110454082489e-02
    z[0,1,6]  R176      -2.3453857004642487e-01
    z[0,1,6]  R177      -2.7294633910059929e-02
    z[0,1,6]  R178      1.1803147196769714e-01
    z[0,1,6]  R179      8.1077076494693756e-02
    z[0,1,6]  R180      -2.1415489912033081e-01
    z[0,1,6]  R181      -1.4506998658180237e-01
    z[0,1,6]  R182      -7.1462929248809814e-01
    z[0,1,6]  R183      -1.9606147706508636e-01
    z[0,1,6]  R184      7.2265923023223877e-02
    z[0,1,6]  R185      -4.1635073721408844e-02
    z[0,1,6]  R186      6.7983572371304035e-03
    z[0,1,6]  R187      -1.1469484865665436e-01
    z[0,1,6]  R188      -3.3874136209487915e-01
    z[0,1,6]  R189      -1.5532813034951687e-02
    z[0,1,6]  R190      -1.3888043165206909e-01
    z[0,1,6]  R191      2.2395296394824982e-01
    z[0,1,6]  R192      7.9197414219379425e-02
    z[0,1,6]  R193      1.1739090085029602e-01
    z[0,1,6]  R194      -2.0323191583156586e-01
    z[0,1,6]  R195      4.7606897354125977e-01
    z[0,1,6]  R196      -1.5488071739673615e-01
    z[0,1,6]  R197      -1.8255972862243652e-01
    z[0,1,6]  R198      -2.6468801498413086e-01
    z[0,1,6]  R199      2.0553344488143921e-01
    z[0,1,6]  R200      0.451729416847229
    z[0,1,6]  R201      -1.1594294756650925e-01
    z[0,1,6]  R202      -3.4763699769973755e-01
    z[0,1,6]  R203      -1.0595864616334438e-02
    z[0,1,6]  R204      -3.2378476113080978e-02
    z[0,1,6]  R205      3.1050181388854980e-01
    z[0,1,6]  R206      -4.1898640990257263e-01
    z[0,1,6]  R207      -1.9147852063179016e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R208      -1
    z[1,0,0]  R209      1
    z[1,0,0]  R222      -6.7375445365905762e-01
    z[1,0,0]  R223      -6.9888913631439209e-01
    z[1,0,0]  R224      -0.594390869140625
    z[1,0,0]  R225      -5.7361841201782227e-01
    z[1,0,0]  R226      -8.2231032848358154e-01
    z[1,0,0]  R227      -6.2316077947616577e-01
    z[1,0,0]  R228      -5.8995449542999268e-01
    z[1,0,0]  R229      -5.8598655462265015e-01
    z[1,0,0]  R230      -0.606269121170044
    z[1,0,0]  R231      -6.2820702791213989e-01
    z[1,0,0]  R232      6.9167673587799072e-01
    z[1,0,0]  R233      5.3233176469802856e-01
    z[1,0,0]  R234      8.2345694303512573e-01
    z[1,0,0]  R235      6.9714194536209106e-01
    z[1,0,0]  R236      6.9522601366043091e-01
    z[1,0,0]  R237      5.7812613248825073e-01
    z[1,0,0]  R238      6.6528755426406860e-01
    z[1,0,0]  R239      3.6091324687004089e-01
    z[1,0,0]  R240      9.0225964784622192e-01
    z[1,0,0]  R241      6.9183218479156494e-01
    z[1,0,0]  R242      -1.3907539844512939e-01
    z[1,0,0]  R243      -3.6842882633209229e-01
    z[1,0,0]  R244      2.7511421591043472e-02
    z[1,0,0]  R245      3.3677688241004944e-01
    z[1,0,0]  R246      -3.0400383472442627e-01
    z[1,0,0]  R247      0.129286989569664
    z[1,0,0]  R248      2.0904533565044403e-01
    z[1,0,0]  R249      -2.5468206405639648e-01
    z[1,0,0]  R250      1.1293878406286240e-01
    z[1,0,0]  R251      4.3662047386169434e-01
    z[1,0,0]  R252      3.9613431692123413e-01
    z[1,0,0]  R253      -3.3349683880805969e-01
    z[1,0,0]  R254      -5.5167776346206665e-01
    z[1,0,0]  R255      -2.6409402489662170e-01
    z[1,0,0]  R256      -0.34183269739151
    z[1,0,0]  R257      5.2882835268974304e-02
    z[1,0,0]  R258      -8.3833348751068115e-01
    z[1,0,0]  R259      -0.0875013917684555
    z[1,0,0]  R260      1.0923463106155396e-01
    z[1,0,0]  R261      -1.5071013569831848e-01
    z[1,0,0]  R262      2.0982383191585541e-01
    z[1,0,0]  R263      -2.2338643670082092e-01
    z[1,0,0]  R264      -1.9661673903465271e-01
    z[1,0,0]  R265      4.1472226381301880e-01
    z[1,0,0]  R266      6.9381761550903320e-01
    z[1,0,0]  R267      1.7683707177639008e-01
    z[1,0,0]  R268      1.4207929372787476e-01
    z[1,0,0]  R269      5.0470888614654541e-02
    z[1,0,0]  R270      -1.8071976304054260e-01
    z[1,0,0]  R271      -1.8040654063224792e-01
    z[1,0,0]  R272      9.3746155500411987e-01
    z[1,0,0]  R273      7.5093394517898560e-01
    z[1,0,0]  R274      0.723858654499054
    z[1,0,0]  R275      7.9731434583663940e-01
    z[1,0,0]  R276      -1.7402684688568115e-01
    z[1,0,0]  R277      4.5955085754394531e-01
    z[1,0,0]  R278      -3.2479703426361084e-01
    z[1,0,0]  R279      -8.4862513467669487e-03
    z[1,0,0]  R280      -9.2845153808593750e-01
    z[1,0,0]  R281      -8.3313882350921631e-01
    z[1,0,0]  R282      -3.1924718618392944e-01
    z[1,0,0]  R283      -4.2675679922103882e-01
    z[1,0,0]  R284      8.1410235166549683e-01
    z[1,0,0]  R285      -3.7976104021072388e-01
    z[1,0,0]  R286      7.1696668863296509e-02
    z[1,0,0]  R287      -4.5697745680809021e-01
    z[1,0,0]  R288      -4.2993064969778061e-02
    z[1,0,0]  R289      1.0481332242488861e-01
    z[1,0,0]  R290      -1.7297340929508209e-01
    z[1,0,0]  R291      4.1590067744255066e-01
    z[1,0,0]  R292      3.9963892102241516e-01
    z[1,0,0]  R293      -4.4773986935615540e-01
    z[1,0,0]  R294      2.3669132962822914e-02
    z[1,0,0]  R295      -1.5191610157489777e-01
    z[1,0,0]  R296      -3.5037714242935181e-01
    z[1,0,0]  R297      -1.9325231015682220e-01
    z[1,0,0]  R298      3.1451320648193359e-01
    z[1,0,0]  R299      -3.1922420859336853e-01
    z[1,0,0]  R300      2.4484528601169586e-01
    z[1,0,0]  R301      -4.3561407923698425e-01
    z[1,0,0]  R302      -4.6641939878463745e-01
    z[1,0,0]  R303      -7.0453971624374390e-01
    z[1,0,0]  R304      -8.3414804935455322e-01
    z[1,0,0]  R305      1.1175207793712616e-01
    z[1,0,0]  R306      1.1520291864871979e-01
    z[1,0,0]  R307      -3.8944080471992493e-01
    z[1,0,0]  R308      -1.6368374228477478e-01
    z[1,0,0]  R309      1.8946231901645660e-01
    z[1,0,0]  R310      -7.5923389196395874e-01
    z[1,0,0]  R311      -7.3668062686920166e-01
    z[1,0,0]  R312      6.8893986940383911e-01
    z[1,0,0]  R313      7.6871931552886963e-01
    z[1,0,0]  R314      6.2952494621276855e-01
    z[1,0,0]  R315      8.2327091693878174e-01
    z[1,0,0]  R316      8.6730796098709106e-01
    z[1,0,0]  R317      -2.9360942542552948e-02
    z[1,0,0]  R318      6.6267901659011841e-01
    z[1,0,0]  R319      -1.1476036906242371e-01
    z[1,0,0]  R320      1.5397189557552338e-01
    z[1,0,0]  R321      -1.9980345666408539e-01
    z[1,0,0]  R322      3.2366719841957092e-01
    z[1,0,0]  R323      1.2916807830333710e-01
    z[1,0,0]  R324      -3.1732532382011414e-01
    z[1,0,0]  R325      -2.8837111592292786e-01
    z[1,0,0]  R326      -2.3688845336437225e-01
    z[1,0,0]  R327      -4.4216677546501160e-01
    z[1,0,0]  R328      -3.2980591058731079e-01
    z[1,0,0]  R329      3.8844794034957886e-01
    z[1,0,0]  R330      1.9508582353591919e-01
    z[1,0,0]  R331      1.3773867487907410e-01
    z[1,0,0]  R332      -1.1814265698194504e-01
    z[1,0,0]  R333      7.9213090240955353e-02
    z[1,0,0]  R334      3.9299392700195312e-01
    z[1,0,0]  R335      7.8699356317520142e-01
    z[1,0,0]  R336      -5.1321196556091309e-01
    z[1,0,0]  R337      -1.9562399387359619e-01
    z[1,0,0]  R338      -2.2464221715927124e-01
    z[1,0,0]  R339      -1.3430775701999664e-01
    z[1,0,0]  R340      -3.8461828231811523e-01
    z[1,0,0]  R341      -4.5845183730125427e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R210      -1
    z[1,0,1]  R211      1
    z[1,0,1]  R222      5.6581604480743408e-01
    z[1,0,1]  R223      4.6107420325279236e-01
    z[1,0,1]  R224      5.8846014738082886e-01
    z[1,0,1]  R225      6.0418677330017090e-01
    z[1,0,1]  R226      4.1971653699874878e-01
    z[1,0,1]  R227      4.7782710194587708e-01
    z[1,0,1]  R228      -0.0804959312081337
    z[1,0,1]  R229      -1.3034315407276154e-01
    z[1,0,1]  R230      4.8019781708717346e-01
    z[1,0,1]  R231      4.2548415064811707e-01
    z[1,0,1]  R232      1.3635043799877167e-01
    z[1,0,1]  R233      1.9816307723522186e-01
    z[1,0,1]  R234      1.8716986477375031e-01
    z[1,0,1]  R235      3.2812580466270447e-01
    z[1,0,1]  R236      4.3138720095157623e-02
    z[1,0,1]  R237      3.2618638873100281e-01
    z[1,0,1]  R238      3.6346804350614548e-02
    z[1,0,1]  R239      2.0694455131888390e-02
    z[1,0,1]  R240      1.6249081492424011e-01
    z[1,0,1]  R241      3.1555914878845215e-01
    z[1,0,1]  R242      -5.7555562257766724e-01
    z[1,0,1]  R243      2.9388232156634331e-02
    z[1,0,1]  R244      1.3200907409191132e-01
    z[1,0,1]  R245      7.3984724283218384e-01
    z[1,0,1]  R246      2.4440020322799683e-02
    z[1,0,1]  R247      -7.2986435890197754e-01
    z[1,0,1]  R248      -0.655773401260376
    z[1,0,1]  R249      1.0935997962951660e-01
    z[1,0,1]  R250      4.1971331834793091e-01
    z[1,0,1]  R251      -6.3583093881607056e-01
    z[1,0,1]  R252      -4.6782466769218445e-01
    z[1,0,1]  R253      -7.1851402521133423e-01
    z[1,0,1]  R254      -3.1521740555763245e-01
    z[1,0,1]  R255      -4.8395147919654846e-01
    z[1,0,1]  R256      -5.0472050905227661e-01
    z[1,0,1]  R257      -7.5323802232742310e-01
    z[1,0,1]  R258      -1.8055382370948792e-01
    z[1,0,1]  R259      1.0876475274562836e-01
    z[1,0,1]  R260      2.4585419893264771e-01
    z[1,0,1]  R261      4.6252235770225525e-01
    z[1,0,1]  R262      -3.5149574279785156e-01
    z[1,0,1]  R263      -3.2818189263343811e-01
    z[1,0,1]  R264      -4.5154190063476562e-01
    z[1,0,1]  R265      -7.6954740285873413e-01
    z[1,0,1]  R266      -1.4450900256633759e-01
    z[1,0,1]  R267      -6.8819504976272583e-01
    z[1,0,1]  R268      2.1572996675968170e-01
    z[1,0,1]  R269      3.8106867671012878e-01
    z[1,0,1]  R270      2.7672821283340454e-01
    z[1,0,1]  R271      -0.621740996837616
    z[1,0,1]  R272      -0.0515022911131382
    z[1,0,1]  R273      -2.8066793084144592e-01
    z[1,0,1]  R274      -2.8422072529792786e-01
    z[1,0,1]  R275      -2.2228258848190308e-01
    z[1,0,1]  R276      -5.4552555084228516e-01
    z[1,0,1]  R277      -2.5604084134101868e-01
    z[1,0,1]  R278      -8.0818790197372437e-01
    z[1,0,1]  R279      -8.4745258092880249e-01
    z[1,0,1]  R280      -1.9298858940601349e-01
    z[1,0,1]  R281      -1.9169786944985390e-02
    z[1,0,1]  R282      -1.4883506298065186e-01
    z[1,0,1]  R283      -3.3743056654930115e-01
    z[1,0,1]  R284      -3.2267636060714722e-01
    z[1,0,1]  R285      -3.5981380939483643e-01
    z[1,0,1]  R286      -5.5066061019897461e-01
    z[1,0,1]  R287      -8.3241373300552368e-01
    z[1,0,1]  R288      -4.0126565098762512e-01
    z[1,0,1]  R289      -0.325792133808136
    z[1,0,1]  R290      3.9969906210899353e-01
    z[1,0,1]  R291      -6.9523072242736816e-01
    z[1,0,1]  R292      -2.1889136731624603e-01
    z[1,0,1]  R293      -7.2267115116119385e-01
    z[1,0,1]  R294      -3.3751270174980164e-01
    z[1,0,1]  R295      5.9211593866348267e-01
    z[1,0,1]  R296      2.6231136918067932e-01
    z[1,0,1]  R297      4.2199438810348511e-01
    z[1,0,1]  R298      8.6712735891342163e-01
    z[1,0,1]  R299      9.4980537891387939e-02
    z[1,0,1]  R300      -6.7621898651123047e-01
    z[1,0,1]  R301      2.8200818225741386e-02
    z[1,0,1]  R302      -4.7570931911468506e-01
    z[1,0,1]  R303      -4.3014129996299744e-01
    z[1,0,1]  R304      -2.8695923089981079e-01
    z[1,0,1]  R305      -5.2187931537628174e-01
    z[1,0,1]  R306      -5.2770727872848511e-01
    z[1,0,1]  R307      -3.2496684789657593e-01
    z[1,0,1]  R308      -4.6004673838615417e-01
    z[1,0,1]  R309      9.7268037497997284e-02
    z[1,0,1]  R310      4.9998548626899719e-01
    z[1,0,1]  R311      4.9960720539093018e-01
    z[1,0,1]  R312      4.1678699851036072e-01
    z[1,0,1]  R313      3.9600458741188049e-01
    z[1,0,1]  R314      4.0015059709548950e-01
    z[1,0,1]  R315      3.0832698941230774e-01
    z[1,0,1]  R316      5.2855193614959717e-02
    z[1,0,1]  R317      4.2598018050193787e-01
    z[1,0,1]  R318      2.2485505044460297e-01
    z[1,0,1]  R319      5.4225105047225952e-01
    z[1,0,1]  R320      0.570558488368988
    z[1,0,1]  R321      4.7694614529609680e-01
    z[1,0,1]  R322      1.1703601479530334e-01
    z[1,0,1]  R323      2.1596144139766693e-01
    z[1,0,1]  R324      5.5512094497680664e-01
    z[1,0,1]  R325      -3.9444932341575623e-01
    z[1,0,1]  R326      -4.9376094341278076e-01
    z[1,0,1]  R327      1.6450468450784683e-02
    z[1,0,1]  R328      2.7394685149192810e-01
    z[1,0,1]  R329      -7.9921215772628784e-01
    z[1,0,1]  R330      -7.0963591337203979e-01
    z[1,0,1]  R331      -7.0107567310333252e-01
    z[1,0,1]  R332      3.4259140491485596e-01
    z[1,0,1]  R333      -4.2591649293899536e-01
    z[1,0,1]  R334      -1.0025259107351303e-02
    z[1,0,1]  R335      -1.4046677947044373e-01
    z[1,0,1]  R336      -0.120124951004982
    z[1,0,1]  R337      5.8132618665695190e-01
    z[1,0,1]  R338      4.9475657939910889e-01
    z[1,0,1]  R339      7.3078292608261108e-01
    z[1,0,1]  R340      -0.00295339897274971
    z[1,0,1]  R341      4.6341851353645325e-02
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R212      -1
    z[1,0,2]  R213      1
    z[1,0,2]  R222      -1.8583782017230988e-01
    z[1,0,2]  R223      4.0435454249382019e-01
    z[1,0,2]  R224      4.9485184252262115e-02
    z[1,0,2]  R225      3.0327681452035904e-02
    z[1,0,2]  R226      1.4825256168842316e-01
    z[1,0,2]  R227      3.9322644472122192e-01
    z[1,0,2]  R228      3.4202730655670166e-01
    z[1,0,2]  R229      3.8173198699951172e-01
    z[1,0,2]  R230      8.3235532045364380e-02
    z[1,0,2]  R231      3.8509148359298706e-01
    z[1,0,2]  R232      3.6533221602439880e-01
    z[1,0,2]  R233      6.9461631774902344e-01
    z[1,0,2]  R234      4.7899049520492554e-01
    z[1,0,2]  R235      2.2634410858154297e-01
    z[1,0,2]  R236      4.1579627990722656e-01
    z[1,0,2]  R237      4.0311416983604431e-01
    z[1,0,2]  R238      2.3965889215469360e-01
    z[1,0,2]  R239      7.5463271141052246e-01
    z[1,0,2]  R240      6.9754309952259064e-02
    z[1,0,2]  R241      4.0157452225685120e-01
    z[1,0,2]  R242      0.372557133436203
    z[1,0,2]  R243      -1.4441660046577454e-01
    z[1,0,2]  R244      -5.6320565938949585e-01
    z[1,0,2]  R245      -3.5228511691093445e-01
    z[1,0,2]  R246      -3.0513930320739746e-01
    z[1,0,2]  R247      4.9704313278198242e-01
    z[1,0,2]  R248      4.5590788125991821e-01
    z[1,0,2]  R249      -6.6915452480316162e-01
    z[1,0,2]  R250      -5.5253100395202637e-01
    z[1,0,2]  R251      3.0519595742225647e-01
    z[1,0,2]  R252      6.9835972785949707e-01
    z[1,0,2]  R253      2.0382064580917358e-01
    z[1,0,2]  R254      -2.1288146078586578e-01
    z[1,0,2]  R255      6.2886893749237061e-01
    z[1,0,2]  R256      1.3575246930122375e-01
    z[1,0,2]  R257      4.6135470271110535e-01
    z[1,0,2]  R258      -2.4484296143054962e-01
    z[1,0,2]  R259      -2.1331357955932617e-01
    z[1,0,2]  R260      -4.6741876006126404e-01
    z[1,0,2]  R261      -6.8512326478958130e-01
    z[1,0,2]  R262      6.0631680488586426e-01
    z[1,0,2]  R263      8.0816090106964111e-01
    z[1,0,2]  R264      7.1812593936920166e-01
    z[1,0,2]  R265      -1.1645172536373138e-01
    z[1,0,2]  R266      -2.2195224463939667e-01
    z[1,0,2]  R267      -3.4744247794151306e-01
    z[1,0,2]  R268      -6.0679125785827637e-01
    z[1,0,2]  R269      -3.5761341452598572e-01
    z[1,0,2]  R270      -1.6917374730110168e-01
    z[1,0,2]  R271      -3.7453171610832214e-01
    z[1,0,2]  R272      -2.8504827991127968e-02
    z[1,0,2]  R273      2.3543396592140198e-01
    z[1,0,2]  R274      5.1484811305999756e-01
    z[1,0,2]  R275      1.7536431550979614e-01
    z[1,0,2]  R276      3.4148257970809937e-01
    z[1,0,2]  R277      5.8263164758682251e-01
    z[1,0,2]  R278      1.6801603138446808e-01
    z[1,0,2]  R279      -9.2448271811008453e-02
    z[1,0,2]  R280      -7.8539937734603882e-02
    z[1,0,2]  R281      1.2315201759338379e-01
    z[1,0,2]  R282      6.9656980037689209e-01
    z[1,0,2]  R283      2.5004261732101440e-01
    z[1,0,2]  R284      2.6816296577453613e-01
    z[1,0,2]  R285      3.6138707399368286e-01
    z[1,0,2]  R286      4.6646651625633240e-01
    z[1,0,2]  R287      4.0568541735410690e-02
    z[1,0,2]  R288      7.9084801673889160e-01
    z[1,0,2]  R289      6.8234455585479736e-01
    z[1,0,2]  R290      -3.0624341964721680e-01
    z[1,0,2]  R291      -4.8970249295234680e-01
    z[1,0,2]  R292      6.5157341957092285e-01
    z[1,0,2]  R293      1.8652480095624924e-02
    z[1,0,2]  R294      6.6115683317184448e-01
    z[1,0,2]  R295      -1.5419077873229980e-01
    z[1,0,2]  R296      -1.6393500566482544e-01
    z[1,0,2]  R297      -5.4945224523544312e-01
    z[1,0,2]  R298      -1.7873485386371613e-01
    z[1,0,2]  R299      -2.0642848312854767e-01
    z[1,0,2]  R300      -3.5644856095314026e-01
    z[1,0,2]  R301      -0.48117595911026
    z[1,0,2]  R302      -2.7751281857490540e-01
    z[1,0,2]  R303      3.2427478581666946e-02
    z[1,0,2]  R304      -2.1592350304126740e-01
    z[1,0,2]  R305      2.3749215900897980e-01
    z[1,0,2]  R306      1.6844940185546875e-01
    z[1,0,2]  R307      -1.6035212576389313e-01
    z[1,0,2]  R308      4.0930435061454773e-02
    z[1,0,2]  R309      -8.3011329174041748e-02
    z[1,0,2]  R310      0.282932847738266
    z[1,0,2]  R311      1.0794003307819366e-01
    z[1,0,2]  R312      5.0963485240936279e-01
    z[1,0,2]  R313      2.9356148838996887e-01
    z[1,0,2]  R314      3.5316619277000427e-01
    z[1,0,2]  R315      2.4036282300949097e-01
    z[1,0,2]  R316      -8.5613265633583069e-02
    z[1,0,2]  R317      4.1041418910026550e-01
    z[1,0,2]  R318      -1.1305548995733261e-01
    z[1,0,2]  R319      -2.3243862390518188e-01
    z[1,0,2]  R320      -4.3270260095596313e-01
    z[1,0,2]  R321      -1.4517985284328461e-01
    z[1,0,2]  R322      2.1311147511005402e-01
    z[1,0,2]  R323      5.4877460002899170e-01
    z[1,0,2]  R324      3.2962255179882050e-02
    z[1,0,2]  R325      -2.2074329853057861e-01
    z[1,0,2]  R326      -4.7355014085769653e-01
    z[1,0,2]  R327      -1.0937143862247467e-01
    z[1,0,2]  R328      1.5144604444503784e-01
    z[1,0,2]  R329      -6.7280530929565430e-02
    z[1,0,2]  R330      2.2395841777324677e-01
    z[1,0,2]  R331      3.5116162896156311e-01
    z[1,0,2]  R332      3.6203429102897644e-01
    z[1,0,2]  R333      -2.9231157898902893e-01
    z[1,0,2]  R334      -4.4138431549072266e-01
    z[1,0,2]  R335      0.106072336435318
    z[1,0,2]  R336      -6.7699514329433441e-02
    z[1,0,2]  R337      -5.5849432945251465e-01
    z[1,0,2]  R338      -3.3190563321113586e-02
    z[1,0,2]  R339      -4.8151548951864243e-02
    z[1,0,2]  R340      -5.4949706792831421e-01
    z[1,0,2]  R341      -3.5029265284538269e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R214      -1
    z[1,0,3]  R215      1
    z[1,0,3]  R222      8.6268782615661621e-02
    z[1,0,3]  R223      7.9351119697093964e-02
    z[1,0,3]  R224      -4.1238284111022949e-01
    z[1,0,3]  R225      0.27255779504776
    z[1,0,3]  R226      -1.6743110120296478e-01
    z[1,0,3]  R227      -7.4745684862136841e-02
    z[1,0,3]  R228      -0.693411111831665
    z[1,0,3]  R229      -6.0715156793594360e-01
    z[1,0,3]  R230      -4.3046516180038452e-01
    z[1,0,3]  R231      1.0837700963020325e-01
    z[1,0,3]  R232      3.6152294278144836e-01
    z[1,0,3]  R233      2.4025149643421173e-01
    z[1,0,3]  R234      -3.9704661816358566e-02
    z[1,0,3]  R235      1.3632193207740784e-01
    z[1,0,3]  R236      9.5584288239479065e-02
    z[1,0,3]  R237      5.7831990718841553e-01
    z[1,0,3]  R238      1.0920634120702744e-01
    z[1,0,3]  R239      1.6979576647281647e-01
    z[1,0,3]  R240      -8.3034120500087738e-02
    z[1,0,3]  R241      4.5772495865821838e-01
    z[1,0,3]  R242      -1.1041700094938278e-01
    z[1,0,3]  R243      8.7938672304153442e-01
    z[1,0,3]  R244      7.2547090053558350e-01
    z[1,0,3]  R245      1.1537463963031769e-01
    z[1,0,3]  R246      6.1914795637130737e-01
    z[1,0,3]  R247      0.170075923204422
    z[1,0,3]  R248      2.6926058530807495e-01
    z[1,0,3]  R249      5.0105082988739014e-01
    z[1,0,3]  R250      5.0233274698257446e-01
    z[1,0,3]  R251      5.8124684728682041e-03
    z[1,0,3]  R252      1.3400685787200928e-01
    z[1,0,3]  R253      3.0896854400634766e-01
    z[1,0,3]  R254      -1.0778423398733139e-01
    z[1,0,3]  R255      4.3510311841964722e-01
    z[1,0,3]  R256      -1.0263931006193161e-01
    z[1,0,3]  R257      -2.2846798598766327e-01
    z[1,0,3]  R258      1.6738660633563995e-01
    z[1,0,3]  R259      8.6282485723495483e-01
    z[1,0,3]  R260      7.1221959590911865e-01
    z[1,0,3]  R261      4.8533996939659119e-01
    z[1,0,3]  R262      -4.1398438811302185e-01
    z[1,0,3]  R263      4.2451298236846924e-01
    z[1,0,3]  R264      -2.6501944661140442e-01
    z[1,0,3]  R265      -1.0121706128120422e-01
    z[1,0,3]  R266      -8.4021300077438354e-02
    z[1,0,3]  R267      1.9870984554290771e-01
    z[1,0,3]  R268      6.7457318305969238e-01
    z[1,0,3]  R269      6.5682178735733032e-01
    z[1,0,3]  R270      6.9819372892379761e-01
    z[1,0,3]  R271      0.532219648361206
    z[1,0,3]  R272      1.5586647391319275e-01
    z[1,0,3]  R273      4.0449678897857666e-01
    z[1,0,3]  R274      -8.4880597889423370e-02
    z[1,0,3]  R275      4.5831638574600220e-01
    z[1,0,3]  R276      2.3949561640620232e-02
    z[1,0,3]  R277      4.4943434000015259e-01
    z[1,0,3]  R278      -0.0392412431538105
    z[1,0,3]  R279      2.4432432651519775e-01
    z[1,0,3]  R280      2.8851801156997681e-01
    z[1,0,3]  R281      5.0724571943283081e-01
    z[1,0,3]  R282      9.2477187514305115e-02
    z[1,0,3]  R283      -3.3023558557033539e-02
    z[1,0,3]  R284      3.7392783164978027e-01
    z[1,0,3]  R285      -8.7873362004756927e-02
    z[1,0,3]  R286      -6.6005373001098633e-01
    z[1,0,3]  R287      -1.6353135928511620e-02
    z[1,0,3]  R288      -2.2524943947792053e-01
    z[1,0,3]  R289      1.6651917248964310e-02
    z[1,0,3]  R290      7.5210946798324585e-01
    z[1,0,3]  R291      -2.6873955503106117e-02
    z[1,0,3]  R292      -2.3450862616300583e-02
    z[1,0,3]  R293      2.2883121669292450e-01
    z[1,0,3]  R294      2.7994289994239807e-01
    z[1,0,3]  R295      -1.3547608256340027e-01
    z[1,0,3]  R296      7.6073713600635529e-02
    z[1,0,3]  R297      5.8836966753005981e-01
    z[1,0,3]  R298      1.2514644861221313e-01
    z[1,0,3]  R299      7.5729668140411377e-01
    z[1,0,3]  R300      8.8596068322658539e-02
    z[1,0,3]  R301      4.1238108277320862e-01
    z[1,0,3]  R302      1.9135875999927521e-01
    z[1,0,3]  R303      6.8657793104648590e-02
    z[1,0,3]  R304      3.0188897252082825e-01
    z[1,0,3]  R305      2.8336721658706665e-01
    z[1,0,3]  R306      1.4530107378959656e-01
    z[1,0,3]  R307      4.2767179012298584e-01
    z[1,0,3]  R308      8.2895606756210327e-02
    z[1,0,3]  R309      2.5135058164596558e-01
    z[1,0,3]  R310      -7.1884766221046448e-02
    z[1,0,3]  R311      -9.1833256185054779e-02
    z[1,0,3]  R312      1.5541224181652069e-01
    z[1,0,3]  R313      2.2369624674320221e-01
    z[1,0,3]  R314      4.6875947713851929e-01
    z[1,0,3]  R315      2.9892998933792114e-01
    z[1,0,3]  R316      1.7789126932621002e-01
    z[1,0,3]  R317      0.769805908203125
    z[1,0,3]  R318      5.9138017892837524e-01
    z[1,0,3]  R319      1.6783721745014191e-01
    z[1,0,3]  R320      4.6502524614334106e-01
    z[1,0,3]  R321      6.3687413930892944e-01
    z[1,0,3]  R322      8.1289058923721313e-01
    z[1,0,3]  R323      4.5772558450698853e-01
    z[1,0,3]  R324      2.7774566411972046e-01
    z[1,0,3]  R325      -7.3069196939468384e-01
    z[1,0,3]  R326      -5.3437966108322144e-01
    z[1,0,3]  R327      -7.3799526691436768e-01
    z[1,0,3]  R328      -3.4302836656570435e-01
    z[1,0,3]  R329      2.0139060914516449e-01
    z[1,0,3]  R330      3.0195074155926704e-02
    z[1,0,3]  R331      -2.8804862499237061e-01
    z[1,0,3]  R332      7.4857777357101440e-01
    z[1,0,3]  R333      8.1203043460845947e-01
    z[1,0,3]  R334      6.4871352910995483e-01
    z[1,0,3]  R335      2.7941519021987915e-01
    z[1,0,3]  R336      -0.682442307472229
    z[1,0,3]  R337      2.4517105892300606e-02
    z[1,0,3]  R338      1.1850558966398239e-01
    z[1,0,3]  R339      -1.5918090939521790e-02
    z[1,0,3]  R340      -2.7980056405067444e-01
    z[1,0,3]  R341      -5.4726260900497437e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R216      -1
    z[1,0,4]  R217      1
    z[1,0,4]  R222      -1.2811103463172913e-01
    z[1,0,4]  R223      9.8769381642341614e-02
    z[1,0,4]  R224      3.9514090865850449e-02
    z[1,0,4]  R225      1.7906357347965240e-01
    z[1,0,4]  R226      5.0745550543069839e-02
    z[1,0,4]  R227      -3.1483915448188782e-01
    z[1,0,4]  R228      1.2532761693000793e-01
    z[1,0,4]  R229      2.5661385059356689e-01
    z[1,0,4]  R230      -1.0935959964990616e-01
    z[1,0,4]  R231      -0.383960098028183
    z[1,0,4]  R232      -1.0561495274305344e-01
    z[1,0,4]  R233      -6.1047445982694626e-02
    z[1,0,4]  R234      -2.4713041260838509e-02
    z[1,0,4]  R235      2.0410059392452240e-01
    z[1,0,4]  R236      -2.5440940260887146e-01
    z[1,0,4]  R237      -1.5176208317279816e-01
    z[1,0,4]  R238      -1.5687119215726852e-02
    z[1,0,4]  R239      3.0090346932411194e-02
    z[1,0,4]  R240      2.2111959755420685e-01
    z[1,0,4]  R241      -1.6021193563938141e-01
    z[1,0,4]  R242      -6.7464607954025269e-01
    z[1,0,4]  R243      -7.1750218048691750e-03
    z[1,0,4]  R244      -1.0470546036958694e-01
    z[1,0,4]  R245      3.6146417260169983e-02
    z[1,0,4]  R246      4.6560221910476685e-01
    z[1,0,4]  R247      -2.4388229846954346e-01
    z[1,0,4]  R248      -0.421680748462677
    z[1,0,4]  R249      1.0703993588685989e-01
    z[1,0,4]  R250      4.0497452020645142e-01
    z[1,0,4]  R251      5.0599622726440430e-01
    z[1,0,4]  R252      -1.1077462881803513e-01
    z[1,0,4]  R253      4.4569492340087891e-01
    z[1,0,4]  R254      5.8734100311994553e-02
    z[1,0,4]  R255      2.5616383552551270e-01
    z[1,0,4]  R256      1.9701224565505981e-01
    z[1,0,4]  R257      -8.4607586264610291e-02
    z[1,0,4]  R258      -2.1708090603351593e-01
    z[1,0,4]  R259      3.2076227664947510e-01
    z[1,0,4]  R260      3.6794742941856384e-01
    z[1,0,4]  R261      7.5871430337429047e-02
    z[1,0,4]  R262      -4.4188475608825684e-01
    z[1,0,4]  R263      3.7901178002357483e-02
    z[1,0,4]  R264      -3.8594129681587219e-01
    z[1,0,4]  R265      -0.196554496884346
    z[1,0,4]  R266      -6.4528220891952515e-01
    z[1,0,4]  R267      3.7812665104866028e-01
    z[1,0,4]  R268      -2.7227890491485596e-01
    z[1,0,4]  R269      -4.9730318784713745e-01
    z[1,0,4]  R270      -4.7969445586204529e-01
    z[1,0,4]  R271      -3.1444844603538513e-01
    z[1,0,4]  R272      -2.6763904094696045e-01
    z[1,0,4]  R273      -3.6290460824966431e-01
    z[1,0,4]  R274      1.3922120630741119e-01
    z[1,0,4]  R275      2.2006702423095703e-01
    z[1,0,4]  R276      -1.4936453104019165e-01
    z[1,0,4]  R277      3.6574614048004150e-01
    z[1,0,4]  R278      -2.0260740816593170e-01
    z[1,0,4]  R279      -4.5631805062294006e-01
    z[1,0,4]  R280      -7.9937577247619629e-03
    z[1,0,4]  R281      -1.2307025492191315e-01
    z[1,0,4]  R282      -2.0108424127101898e-01
    z[1,0,4]  R283      7.9773432016372681e-01
    z[1,0,4]  R284      2.9656341299414635e-02
    z[1,0,4]  R285      -4.3531331419944763e-01
    z[1,0,4]  R286      -1.5251480042934418e-02
    z[1,0,4]  R287      1.6486409306526184e-01
    z[1,0,4]  R288      3.1822186708450317e-01
    z[1,0,4]  R289      3.8033452630043030e-01
    z[1,0,4]  R290      -2.7622884511947632e-01
    z[1,0,4]  R291      6.9422118365764618e-02
    z[1,0,4]  R292      -2.4084742367267609e-01
    z[1,0,4]  R293      2.7856758236885071e-01
    z[1,0,4]  R294      3.8693848252296448e-01
    z[1,0,4]  R295      4.1001993417739868e-01
    z[1,0,4]  R296      7.1121048927307129e-01
    z[1,0,4]  R297      3.3168014883995056e-01
    z[1,0,4]  R298      0.187080979347229
    z[1,0,4]  R299      1.0877946764230728e-01
    z[1,0,4]  R300      -2.9853085055947304e-02
    z[1,0,4]  R301      3.7477380037307739e-01
    z[1,0,4]  R302      -1.3734026253223419e-01
    z[1,0,4]  R303      1.9689242541790009e-01
    z[1,0,4]  R304      -1.7872823402285576e-02
    z[1,0,4]  R305      5.4330664873123169e-01
    z[1,0,4]  R306      2.6512509584426880e-01
    z[1,0,4]  R307      -1.5441097319126129e-01
    z[1,0,4]  R308      6.2950074672698975e-01
    z[1,0,4]  R309      -5.1566797494888306e-01
    z[1,0,4]  R310      -1.8406768143177032e-01
    z[1,0,4]  R311      1.5364494174718857e-02
    z[1,0,4]  R312      1.1874731630086899e-01
    z[1,0,4]  R313      1.5236093103885651e-01
    z[1,0,4]  R314      1.5645581483840942e-01
    z[1,0,4]  R315      5.7624153792858124e-02
    z[1,0,4]  R316      4.5855669304728508e-03
    z[1,0,4]  R317      2.3364938795566559e-01
    z[1,0,4]  R318      1.2672841548919678e-02
    z[1,0,4]  R319      -3.7586815655231476e-02
    z[1,0,4]  R320      4.5307138562202454e-01
    z[1,0,4]  R321      -1.8788692355155945e-01
    z[1,0,4]  R322      3.4083411097526550e-01
    z[1,0,4]  R323      2.6868802309036255e-01
    z[1,0,4]  R324      0.0283999964594841
    z[1,0,4]  R325      -3.1247171759605408e-01
    z[1,0,4]  R326      -1.0955525189638138e-01
    z[1,0,4]  R327      1.6455663368105888e-02
    z[1,0,4]  R328      3.3897200226783752e-01
    z[1,0,4]  R329      -2.9044884443283081e-01
    z[1,0,4]  R330      -5.1221090555191040e-01
    z[1,0,4]  R331      -5.1322090625762939e-01
    z[1,0,4]  R332      0.061478141695261
    z[1,0,4]  R333      2.3901236057281494e-01
    z[1,0,4]  R334      -2.7215710282325745e-01
    z[1,0,4]  R335      3.7062233686447144e-01
    z[1,0,4]  R336      1.1155769973993301e-01
    z[1,0,4]  R337      -4.0102687478065491e-01
    z[1,0,4]  R338      -3.8252141326665878e-02
    z[1,0,4]  R339      4.2325085401535034e-01
    z[1,0,4]  R340      -3.5322535037994385e-01
    z[1,0,4]  R341      -2.2889564931392670e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R218      -1
    z[1,0,5]  R219      1
    z[1,0,5]  R222      -1.4402790367603302e-01
    z[1,0,5]  R223      4.5146383345127106e-02
    z[1,0,5]  R224      1.1751770973205566e-01
    z[1,0,5]  R225      4.2257276177406311e-01
    z[1,0,5]  R226      1.0330075025558472e-01
    z[1,0,5]  R227      3.4574690461158752e-01
    z[1,0,5]  R228      1.7807528376579285e-01
    z[1,0,5]  R229      -1.4250756241381168e-02
    z[1,0,5]  R230      5.1383594982326031e-03
    z[1,0,5]  R231      -1.3030184805393219e-01
    z[1,0,5]  R232      4.7639212012290955e-01
    z[1,0,5]  R233      3.3835160732269287e-01
    z[1,0,5]  R234      1.3196520507335663e-01
    z[1,0,5]  R235      5.4228603839874268e-01
    z[1,0,5]  R236      0.332433819770813
    z[1,0,5]  R237      1.7465837299823761e-01
    z[1,0,5]  R238      5.2098482847213745e-01
    z[1,0,5]  R239      5.0092417001724243e-01
    z[1,0,5]  R240      3.1437876820564270e-01
    z[1,0,5]  R241      -0.0597243569791317
    z[1,0,5]  R242      -1.8792058527469635e-01
    z[1,0,5]  R243      -1.9813102483749390e-01
    z[1,0,5]  R244      -3.5396766662597656e-01
    z[1,0,5]  R245      -1.2771297991275787e-01
    z[1,0,5]  R246      -4.5337450504302979e-01
    z[1,0,5]  R247      -2.8609189391136169e-01
    z[1,0,5]  R248      -1.7389757931232452e-01
    z[1,0,5]  R249      -4.0819168090820312e-01
    z[1,0,5]  R250      -2.2313356399536133e-01
    z[1,0,5]  R251      -2.3613187670707703e-01
    z[1,0,5]  R252      1.8409633636474609e-01
    z[1,0,5]  R253      8.4336094558238983e-02
    z[1,0,5]  R254      7.1165359020233154e-01
    z[1,0,5]  R255      -1.4875005185604095e-01
    z[1,0,5]  R256      -2.2034212946891785e-01
    z[1,0,5]  R257      -2.9223549365997314e-01
    z[1,0,5]  R258      -1.1317928880453110e-01
    z[1,0,5]  R259      -2.9599642753601074e-01
    z[1,0,5]  R260      -2.4392421543598175e-01
    z[1,0,5]  R261      -1.7684239149093628e-01
    z[1,0,5]  R262      3.1072497367858887e-01
    z[1,0,5]  R263      8.6572587490081787e-02
    z[1,0,5]  R264      9.3467950820922852e-02
    z[1,0,5]  R265      2.9265916347503662e-01
    z[1,0,5]  R266      9.4040319323539734e-02
    z[1,0,5]  R267      -0.300374835729599
    z[1,0,5]  R268      -1.2064851820468903e-01
    z[1,0,5]  R269      2.1226347982883453e-01
    z[1,0,5]  R270      2.9925328493118286e-01
    z[1,0,5]  R271      -2.4028530716896057e-01
    z[1,0,5]  R272      8.8568501174449921e-02
    z[1,0,5]  R273      -1.9132284214720130e-03
    z[1,0,5]  R274      2.4026885628700256e-01
    z[1,0,5]  R275      -6.7815303802490234e-02
    z[1,0,5]  R276      1.4808064699172974e-01
    z[1,0,5]  R277      -9.7954049706459045e-02
    z[1,0,5]  R278      -4.0656840801239014e-01
    z[1,0,5]  R279      5.9593491256237030e-02
    z[1,0,5]  R280      1.0588598251342773e-01
    z[1,0,5]  R281      -6.8894013762474060e-02
    z[1,0,5]  R282      4.7643181681632996e-01
    z[1,0,5]  R283      6.1530273407697678e-02
    z[1,0,5]  R284      -0.0348796509206295
    z[1,0,5]  R285      5.9020388126373291e-01
    z[1,0,5]  R286      -1.7851024866104126e-01
    z[1,0,5]  R287      -2.3533992469310760e-01
    z[1,0,5]  R288      1.3561421632766724e-01
    z[1,0,5]  R289      -2.1379022300243378e-01
    z[1,0,5]  R290      2.2489269077777863e-01
    z[1,0,5]  R291      -2.5495597720146179e-01
    z[1,0,5]  R292      4.8909124732017517e-01
    z[1,0,5]  R293      3.2360464334487915e-01
    z[1,0,5]  R294      1.2746696174144745e-01
    z[1,0,5]  R295      -6.3453322649002075e-01
    z[1,0,5]  R296      -3.8612812757492065e-01
    z[1,0,5]  R297      -1.6239969432353973e-01
    z[1,0,5]  R298      -2.5596126914024353e-01
    z[1,0,5]  R299      -4.0585622191429138e-01
    z[1,0,5]  R300      -4.1404470801353455e-01
    z[1,0,5]  R301      -4.8035117983818054e-01
    z[1,0,5]  R302      6.4809662103652954e-01
    z[1,0,5]  R303      5.0592297315597534e-01
    z[1,0,5]  R304      2.8670877218246460e-01
    z[1,0,5]  R305      4.8585128784179688e-01
    z[1,0,5]  R306      6.3074672222137451e-01
    z[1,0,5]  R307      1.6453932970762253e-02
    z[1,0,5]  R308      3.2417336106300354e-01
    z[1,0,5]  R309      0.781249463558197
    z[1,0,5]  R310      9.1276556253433228e-02
    z[1,0,5]  R311      -2.5241073966026306e-01
    z[1,0,5]  R312      4.1232284158468246e-02
    z[1,0,5]  R313      4.1825573891401291e-02
    z[1,0,5]  R314      -2.2501009702682495e-01
    z[1,0,5]  R315      -2.1672993898391724e-01
    z[1,0,5]  R316      1.8610468506813049e-01
    z[1,0,5]  R317      -6.4693358726799488e-03
    z[1,0,5]  R318      -2.6729911565780640e-01
    z[1,0,5]  R319      4.4847447425127029e-02
    z[1,0,5]  R320      1.5220044553279877e-01
    z[1,0,5]  R321      -4.5384258031845093e-01
    z[1,0,5]  R322      1.6075240075588226e-01
    z[1,0,5]  R323      -1.6099143773317337e-02
    z[1,0,5]  R324      -4.0589755773544312e-01
    z[1,0,5]  R325      -2.6492691040039062e-01
    z[1,0,5]  R326      -4.0279945731163025e-01
    z[1,0,5]  R327      -2.4074497818946838e-01
    z[1,0,5]  R328      -4.8913535475730896e-01
    z[1,0,5]  R329      -2.5961726903915405e-01
    z[1,0,5]  R330      -1.9433766603469849e-01
    z[1,0,5]  R331      -1.1268361657857895e-01
    z[1,0,5]  R332      4.0919068455696106e-01
    z[1,0,5]  R333      5.9867627918720245e-02
    z[1,0,5]  R334      1.3973297178745270e-01
    z[1,0,5]  R335      2.2402912378311157e-01
    z[1,0,5]  R336      -2.6954427361488342e-01
    z[1,0,5]  R337      -1.1689981073141098e-01
    z[1,0,5]  R338      -1.0135784000158310e-01
    z[1,0,5]  R339      -9.9021323025226593e-02
    z[1,0,5]  R340      -4.6825075149536133e-01
    z[1,0,5]  R341      -4.3617191910743713e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R220      -1
    z[1,0,6]  R221      1
    z[1,0,6]  R222      3.8310918211936951e-01
    z[1,0,6]  R223      3.4259554743766785e-01
    z[1,0,6]  R224      3.3546081185340881e-01
    z[1,0,6]  R225      -0.141708105802536
    z[1,0,6]  R226      2.9049226641654968e-01
    z[1,0,6]  R227      -6.6882841289043427e-02
    z[1,0,6]  R228      -1.5954727306962013e-02
    z[1,0,6]  R229      2.4336050450801849e-01
    z[1,0,6]  R230      -4.4455981254577637e-01
    z[1,0,6]  R231      -3.1602874398231506e-01
    z[1,0,6]  R232      2.6858173310756683e-02
    z[1,0,6]  R233      1.3759815692901611e-01
    z[1,0,6]  R234      -1.9455698132514954e-01
    z[1,0,6]  R235      -2.7928901836276054e-02
    z[1,0,6]  R236      3.9691379666328430e-01
    z[1,0,6]  R237      -9.4235010445117950e-02
    z[1,0,6]  R238      -4.6372160315513611e-01
    z[1,0,6]  R239      1.3849860429763794e-01
    z[1,0,6]  R240      6.0068508610129356e-03
    z[1,0,6]  R241      1.4758543670177460e-01
    z[1,0,6]  R242      8.9115403592586517e-02
    z[1,0,6]  R243      -1.7295074462890625e-01
    z[1,0,6]  R244      4.5295480638742447e-02
    z[1,0,6]  R245      -0.429155170917511
    z[1,0,6]  R246      -9.0533353388309479e-02
    z[1,0,6]  R247      -1.8242296576499939e-01
    z[1,0,6]  R248      -1.9455881416797638e-01
    z[1,0,6]  R249      -2.1512724459171295e-01
    z[1,0,6]  R250      1.9915764033794403e-01
    z[1,0,6]  R251      1.0617773979902267e-02
    z[1,0,6]  R252      -2.6905581355094910e-01
    z[1,0,6]  R253      -1.7250110208988190e-01
    z[1,0,6]  R254      1.7161907255649567e-01
    z[1,0,6]  R255      1.5332300961017609e-01
    z[1,0,6]  R256      -7.1559733152389526e-01
    z[1,0,6]  R257      -2.6875638961791992e-01
    z[1,0,6]  R258      -3.4160980582237244e-01
    z[1,0,6]  R259      -6.4790071919560432e-03
    z[1,0,6]  R260      -8.3678871393203735e-02
    z[1,0,6]  R261      1.4622308313846588e-01
    z[1,0,6]  R262      -4.0118601173162460e-02
    z[1,0,6]  R263      -0.0113369794562459
    z[1,0,6]  R264      1.1757802218198776e-01
    z[1,0,6]  R265      -2.9616445302963257e-01
    z[1,0,6]  R266      -1.2719714641571045e-01
    z[1,0,6]  R267      3.1891950964927673e-01
    z[1,0,6]  R268      -1.4607398211956024e-01
    z[1,0,6]  R269      2.3893110454082489e-02
    z[1,0,6]  R270      -2.3453857004642487e-01
    z[1,0,6]  R271      -2.7294633910059929e-02
    z[1,0,6]  R272      1.1803147196769714e-01
    z[1,0,6]  R273      8.1077076494693756e-02
    z[1,0,6]  R274      -2.1415489912033081e-01
    z[1,0,6]  R275      -1.4506998658180237e-01
    z[1,0,6]  R276      -7.1462929248809814e-01
    z[1,0,6]  R277      -1.9606147706508636e-01
    z[1,0,6]  R278      7.2265923023223877e-02
    z[1,0,6]  R279      -4.1635073721408844e-02
    z[1,0,6]  R280      6.7983572371304035e-03
    z[1,0,6]  R281      -1.1469484865665436e-01
    z[1,0,6]  R282      -3.3874136209487915e-01
    z[1,0,6]  R283      -1.5532813034951687e-02
    z[1,0,6]  R284      -1.3888043165206909e-01
    z[1,0,6]  R285      2.2395296394824982e-01
    z[1,0,6]  R286      7.9197414219379425e-02
    z[1,0,6]  R287      1.1739090085029602e-01
    z[1,0,6]  R288      -2.0323191583156586e-01
    z[1,0,6]  R289      4.7606897354125977e-01
    z[1,0,6]  R290      -1.5488071739673615e-01
    z[1,0,6]  R291      -1.8255972862243652e-01
    z[1,0,6]  R292      -2.6468801498413086e-01
    z[1,0,6]  R293      2.0553344488143921e-01
    z[1,0,6]  R294      0.451729416847229
    z[1,0,6]  R295      -1.1594294756650925e-01
    z[1,0,6]  R296      -3.4763699769973755e-01
    z[1,0,6]  R297      -1.0595864616334438e-02
    z[1,0,6]  R298      -3.2378476113080978e-02
    z[1,0,6]  R299      3.1050181388854980e-01
    z[1,0,6]  R300      -4.1898640990257263e-01
    z[1,0,6]  R301      -1.9147852063179016e-01
    z[1,0,6]  R302      -6.0252517461776733e-02
    z[1,0,6]  R303      -1.3458128273487091e-01
    z[1,0,6]  R304      3.9626464247703552e-02
    z[1,0,6]  R305      -2.1730247139930725e-01
    z[1,0,6]  R306      -4.3661540746688843e-01
    z[1,0,6]  R307      -7.1414500474929810e-01
    z[1,0,6]  R308      5.0165539979934692e-01
    z[1,0,6]  R309      -9.1163434088230133e-02
    z[1,0,6]  R310      -2.1482041478157043e-01
    z[1,0,6]  R311      -3.5165694355964661e-01
    z[1,0,6]  R312      -2.2796644270420074e-01
    z[1,0,6]  R313      3.0177685618400574e-01
    z[1,0,6]  R314      -1.5494552254676819e-01
    z[1,0,6]  R315      -1.7243444919586182e-01
    z[1,0,6]  R316      4.1394731402397156e-01
    z[1,0,6]  R317      -4.4765327125787735e-02
    z[1,0,6]  R318      2.7599847316741943e-01
    z[1,0,6]  R319      7.7921295166015625e-01
    z[1,0,6]  R320      -1.3724772632122040e-01
    z[1,0,6]  R321      2.5424492359161377e-01
    z[1,0,6]  R322      1.8255215883255005e-01
    z[1,0,6]  R323      -5.9460711479187012e-01
    z[1,0,6]  R324      5.8936983346939087e-01
    z[1,0,6]  R325      1.0386855900287628e-01
    z[1,0,6]  R326      -1.2658125162124634e-01
    z[1,0,6]  R327      0.435189425945282
    z[1,0,6]  R328      5.6694036722183228e-01
    z[1,0,6]  R329      1.1628223955631256e-01
    z[1,0,6]  R330      3.2735636830329895e-01
    z[1,0,6]  R331      8.4505289793014526e-02
    z[1,0,6]  R332      -0.0775846540927887
    z[1,0,6]  R333      8.2278758287429810e-02
    z[1,0,6]  R334      3.6906811594963074e-01
    z[1,0,6]  R335      2.8988981246948242e-01
    z[1,0,6]  R336      4.0837913751602173e-01
    z[1,0,6]  R337      3.6984574794769287e-01
    z[1,0,6]  R338      8.2332855463027954e-01
    z[1,0,6]  R339      5.0635886192321777e-01
    z[1,0,6]  R340      3.5748815536499023e-01
    z[1,0,6]  R341      3.5047656297683716e-01
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R342      -1
    z[0,4,0]  R343      1
    z[0,4,0]  R356      -4.6641939878463745e-01
    z[0,4,0]  R357      -7.0453971624374390e-01
    z[0,4,0]  R358      -8.3414804935455322e-01
    z[0,4,0]  R359      1.1175207793712616e-01
    z[0,4,0]  R360      1.1520291864871979e-01
    z[0,4,0]  R361      -3.8944080471992493e-01
    z[0,4,0]  R362      -1.6368374228477478e-01
    z[0,4,0]  R363      1.8946231901645660e-01
    z[0,4,0]  R364      -7.5923389196395874e-01
    z[0,4,0]  R365      -7.3668062686920166e-01
    z[0,4,0]  R366      6.8893986940383911e-01
    z[0,4,0]  R367      7.6871931552886963e-01
    z[0,4,0]  R368      6.2952494621276855e-01
    z[0,4,0]  R369      8.2327091693878174e-01
    z[0,4,0]  R370      8.6730796098709106e-01
    z[0,4,0]  R371      -2.9360942542552948e-02
    z[0,4,0]  R372      6.6267901659011841e-01
    z[0,4,0]  R373      -1.1476036906242371e-01
    z[0,4,0]  R374      1.5397189557552338e-01
    z[0,4,0]  R375      -1.9980345666408539e-01
    z[0,4,0]  R376      3.2366719841957092e-01
    z[0,4,0]  R377      1.2916807830333710e-01
    z[0,4,0]  R378      -3.1732532382011414e-01
    z[0,4,0]  R379      -2.8837111592292786e-01
    z[0,4,0]  R380      -2.3688845336437225e-01
    z[0,4,0]  R381      -4.4216677546501160e-01
    z[0,4,0]  R382      -3.2980591058731079e-01
    z[0,4,0]  R383      3.8844794034957886e-01
    z[0,4,0]  R384      1.9508582353591919e-01
    z[0,4,0]  R385      1.3773867487907410e-01
    z[0,4,0]  R386      -1.1814265698194504e-01
    z[0,4,0]  R387      7.9213090240955353e-02
    z[0,4,0]  R388      3.9299392700195312e-01
    z[0,4,0]  R389      7.8699356317520142e-01
    z[0,4,0]  R390      -5.1321196556091309e-01
    z[0,4,0]  R391      -1.9562399387359619e-01
    z[0,4,0]  R392      -2.2464221715927124e-01
    z[0,4,0]  R393      -1.3430775701999664e-01
    z[0,4,0]  R394      -3.8461828231811523e-01
    z[0,4,0]  R395      -4.5845183730125427e-01
    z[0,4,0]  R396      -7.5595939159393311e-01
    z[0,4,0]  R397      -3.8382682204246521e-01
    z[0,4,0]  R398      -3.0085310339927673e-01
    z[0,4,0]  R399      -4.3898898363113403e-01
    z[0,4,0]  R400      -5.3916312754154205e-02
    z[0,4,0]  R401      2.0261155068874359e-01
    z[0,4,0]  R402      -3.3357802033424377e-01
    z[0,4,0]  R403      -4.6541181206703186e-01
    z[0,4,0]  R404      -1.7482081055641174e-01
    z[0,4,0]  R405      -3.2698640227317810e-01
    z[0,4,0]  R406      -2.0467326045036316e-01
    z[0,4,0]  R407      3.1608107686042786e-01
    z[0,4,0]  R408      1.9089536741375923e-02
    z[0,4,0]  R409      3.4732836484909058e-01
    z[0,4,0]  R410      8.6776286363601685e-01
    z[0,4,0]  R411      -6.4097873866558075e-02
    z[0,4,0]  R412      9.2839550971984863e-01
    z[0,4,0]  R413      8.8717746734619141e-01
    z[0,4,0]  R414      0.766423225402832
    z[0,4,0]  R415      8.0424225330352783e-01
    z[0,4,0]  R416      2.6922184973955154e-02
    z[0,4,0]  R417      -3.1197193264961243e-01
    z[0,4,0]  R418      -4.2019522190093994e-01
    z[0,4,0]  R419      8.5720755159854889e-02
    z[0,4,0]  R420      -4.9759708344936371e-02
    z[0,4,0]  R421      5.1685433834791183e-02
    z[0,4,0]  R422      1.4829632639884949e-01
    z[0,4,0]  R423      1.6176998615264893e-01
    z[0,4,0]  R424      2.3579502105712891e-01
    z[0,4,0]  R425      -1.4668072760105133e-01
    z[0,4,0]  R426      -2.1438447292894125e-03
    z[0,4,0]  R427      3.1725355982780457e-01
    z[0,4,0]  R428      -1.7180384695529938e-01
    z[0,4,0]  R429      -6.9005347788333893e-02
    z[0,4,0]  R430      5.3096253424882889e-02
    z[0,4,0]  R431      2.0548075437545776e-01
    z[0,4,0]  R432      3.2522976398468018e-01
    z[0,4,0]  R433      -5.1012493669986725e-02
    z[0,4,0]  R434      9.2113900184631348e-01
    z[0,4,0]  R435      5.6456762552261353e-01
    z[0,4,0]  R436      -3.2004863023757935e-01
    z[0,4,0]  R437      -1.2148412875831127e-02
    z[0,4,0]  R438      -6.3843570649623871e-02
    z[0,4,0]  R439      -5.1655262708663940e-02
    z[0,4,0]  R440      -1.8021368980407715e-01
    z[0,4,0]  R441      -1.5424399077892303e-01
    z[0,4,0]  R442      1.2154664099216461e-01
    z[0,4,0]  R443      8.8347233831882477e-02
    z[0,4,0]  R444      -2.8340601921081543e-01
    z[0,4,0]  R445      4.0016490221023560e-01
    z[0,4,0]  R446      -2.0374859869480133e-01
    z[0,4,0]  R447      -1.8331326544284821e-01
    z[0,4,0]  R448      -2.9987642168998718e-01
    z[0,4,0]  R449      -4.0957161784172058e-01
    z[0,4,0]  R450      -2.1545775234699249e-01
    z[0,4,0]  R451      -9.7865886986255646e-02
    z[0,4,0]  R452      3.2939872145652771e-01
    z[0,4,0]  R453      3.6172747611999512e-01
    z[0,4,0]  R454      6.9161552190780640e-01
    z[0,4,0]  R455      8.4867948293685913e-01
    z[0,4,0]  R456      3.0808833241462708e-01
    z[0,4,0]  R457      -1.6845524311065674e-01
    z[0,4,0]  R458      -1.5884728729724884e-01
    z[0,4,0]  R459      7.8646093606948853e-03
    z[0,4,0]  R460      -3.8685572147369385e-01
    z[0,4,0]  R461      -1.5796563029289246e-01
    z[0,4,0]  R462      -1.0707242041826248e-01
    z[0,4,0]  R463      9.2819523811340332e-01
    z[0,4,0]  R464      9.1676068305969238e-01
    z[0,4,0]  R465      8.5742688179016113e-01
    z[0,4,0]  R466      1.1749872565269470e-01
    z[0,4,0]  R467      -1.0967695713043213e-01
    z[0,4,0]  R468      -9.1911517083644867e-02
    z[0,4,0]  R469      -1.7805531620979309e-01
    z[0,4,0]  R470      -2.5043404102325439e-01
    z[0,4,0]  R471      2.8830792754888535e-02
    z[0,4,0]  R472      -5.3877104073762894e-02
    z[0,4,0]  R473      7.6644057035446167e-01
    z[0,4,0]  R474      4.5327857136726379e-01
    z[0,4,0]  R475      7.2841495275497437e-01
    z[0,4,0]  R476      -1.5652939677238464e-01
    z[0,4,0]  R477      -4.5320162177085876e-01
    z[0,4,0]  R478      8.3178174495697021e-01
    z[0,4,0]  R479      0.865403413772583
    z[0,4,0]  R480      6.3283419609069824e-01
    z[0,4,0]  R481      8.7871414422988892e-01
    z[0,4,0]  R482      3.6707940697669983e-01
    z[0,4,0]  R483      6.1472576856613159e-01
    z[0,4,0]  R484      4.5549169182777405e-01
    z[0,4,0]  R485      4.5406249165534973e-01
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R344      -1
    z[0,4,1]  R345      1
    z[0,4,1]  R356      -4.7570931911468506e-01
    z[0,4,1]  R357      -4.3014129996299744e-01
    z[0,4,1]  R358      -2.8695923089981079e-01
    z[0,4,1]  R359      -5.2187931537628174e-01
    z[0,4,1]  R360      -5.2770727872848511e-01
    z[0,4,1]  R361      -3.2496684789657593e-01
    z[0,4,1]  R362      -4.6004673838615417e-01
    z[0,4,1]  R363      9.7268037497997284e-02
    z[0,4,1]  R364      4.9998548626899719e-01
    z[0,4,1]  R365      4.9960720539093018e-01
    z[0,4,1]  R366      4.1678699851036072e-01
    z[0,4,1]  R367      3.9600458741188049e-01
    z[0,4,1]  R368      4.0015059709548950e-01
    z[0,4,1]  R369      3.0832698941230774e-01
    z[0,4,1]  R370      5.2855193614959717e-02
    z[0,4,1]  R371      4.2598018050193787e-01
    z[0,4,1]  R372      2.2485505044460297e-01
    z[0,4,1]  R373      5.4225105047225952e-01
    z[0,4,1]  R374      0.570558488368988
    z[0,4,1]  R375      4.7694614529609680e-01
    z[0,4,1]  R376      1.1703601479530334e-01
    z[0,4,1]  R377      2.1596144139766693e-01
    z[0,4,1]  R378      5.5512094497680664e-01
    z[0,4,1]  R379      -3.9444932341575623e-01
    z[0,4,1]  R380      -4.9376094341278076e-01
    z[0,4,1]  R381      1.6450468450784683e-02
    z[0,4,1]  R382      2.7394685149192810e-01
    z[0,4,1]  R383      -7.9921215772628784e-01
    z[0,4,1]  R384      -7.0963591337203979e-01
    z[0,4,1]  R385      -7.0107567310333252e-01
    z[0,4,1]  R386      3.4259140491485596e-01
    z[0,4,1]  R387      -4.2591649293899536e-01
    z[0,4,1]  R388      -1.0025259107351303e-02
    z[0,4,1]  R389      -1.4046677947044373e-01
    z[0,4,1]  R390      -0.120124951004982
    z[0,4,1]  R391      5.8132618665695190e-01
    z[0,4,1]  R392      4.9475657939910889e-01
    z[0,4,1]  R393      7.3078292608261108e-01
    z[0,4,1]  R394      -0.00295339897274971
    z[0,4,1]  R395      4.6341851353645325e-02
    z[0,4,1]  R396      -4.0895906090736389e-01
    z[0,4,1]  R397      -5.5129384994506836e-01
    z[0,4,1]  R398      -5.8258968591690063e-01
    z[0,4,1]  R399      -4.0229967236518860e-01
    z[0,4,1]  R400      -4.1316270828247070e-01
    z[0,4,1]  R401      -4.2161974310874939e-01
    z[0,4,1]  R402      9.1567748785018921e-01
    z[0,4,1]  R403      6.6368746757507324e-01
    z[0,4,1]  R404      7.1862238645553589e-01
    z[0,4,1]  R405      6.2939703464508057e-01
    z[0,4,1]  R406      -3.6118716001510620e-01
    z[0,4,1]  R407      0.643488883972168
    z[0,4,1]  R408      0.761551558971405
    z[0,4,1]  R409      6.5792787075042725e-01
    z[0,4,1]  R410      -3.0341061949729919e-01
    z[0,4,1]  R411      4.7267517447471619e-01
    z[0,4,1]  R412      -1.5194717049598694e-01
    z[0,4,1]  R413      -8.1752061843872070e-02
    z[0,4,1]  R414      -3.1761386990547180e-01
    z[0,4,1]  R415      -2.4149794876575470e-01
    z[0,4,1]  R416      7.0063757896423340e-01
    z[0,4,1]  R417      0.634477436542511
    z[0,4,1]  R418      5.1053810119628906e-01
    z[0,4,1]  R419      6.3336014747619629e-01
    z[0,4,1]  R420      0.571498453617096
    z[0,4,1]  R421      0.624488890171051
    z[0,4,1]  R422      6.8535220623016357e-01
    z[0,4,1]  R423      6.0414552688598633e-01
    z[0,4,1]  R424      0.617192268371582
    z[0,4,1]  R425      4.7669410705566406e-01
    z[0,4,1]  R426      -0.521144449710846
    z[0,4,1]  R427      8.1455355882644653e-01
    z[0,4,1]  R428      6.6145467758178711e-01
    z[0,4,1]  R429      6.5821504592895508e-01
    z[0,4,1]  R430      7.6134026050567627e-01
    z[0,4,1]  R431      6.7953163385391235e-01
    z[0,4,1]  R432      6.7852401733398438e-01
    z[0,4,1]  R433      -2.8339993953704834e-01
    z[0,4,1]  R434      -1.2914204597473145e-01
    z[0,4,1]  R435      -2.7889639139175415e-01
    z[0,4,1]  R436      0.661384105682373
    z[0,4,1]  R437      6.8406271934509277e-01
    z[0,4,1]  R438      0.609142005443573
    z[0,4,1]  R439      6.1185771226882935e-01
    z[0,4,1]  R440      5.1991587877273560e-01
    z[0,4,1]  R441      5.0892251729965210e-01
    z[0,4,1]  R442      6.2008982896804810e-01
    z[0,4,1]  R443      5.8739626407623291e-01
    z[0,4,1]  R444      4.4208192825317383e-01
    z[0,4,1]  R445      -7.5490063428878784e-01
    z[0,4,1]  R446      1.1428605020046234e-01
    z[0,4,1]  R447      -5.4980587959289551e-01
    z[0,4,1]  R448      6.8772667646408081e-01
    z[0,4,1]  R449      5.7774698734283447e-01
    z[0,4,1]  R450      6.1253947019577026e-01
    z[0,4,1]  R451      6.3415187597274780e-01
    z[0,4,1]  R452      7.2337609529495239e-01
    z[0,4,1]  R453      6.5873426198959351e-01
    z[0,4,1]  R454      -3.1618535518646240e-01
    z[0,4,1]  R455      -2.2307717800140381e-01
    z[0,4,1]  R456      0.907846212387085
    z[0,4,1]  R457      7.8116118907928467e-01
    z[0,4,1]  R458      6.5968692302703857e-01
    z[0,4,1]  R459      7.1707624197006226e-01
    z[0,4,1]  R460      5.8574253320693970e-01
    z[0,4,1]  R461      6.7232650518417358e-01
    z[0,4,1]  R462      5.0570577383041382e-01
    z[0,4,1]  R463      -2.2589710354804993e-01
    z[0,4,1]  R464      -6.9680139422416687e-02
    z[0,4,1]  R465      -5.0524167716503143e-02
    z[0,4,1]  R466      -4.7879534959793091e-01
    z[0,4,1]  R467      8.4078276157379150e-01
    z[0,4,1]  R468      8.1807190179824829e-01
    z[0,4,1]  R469      7.6242613792419434e-01
    z[0,4,1]  R470      7.4268090724945068e-01
    z[0,4,1]  R471      7.8609466552734375e-01
    z[0,4,1]  R472      5.7589423656463623e-01
    z[0,4,1]  R473      -2.7718749642372131e-01
    z[0,4,1]  R474      4.0824308991432190e-01
    z[0,4,1]  R475      1.9695796072483063e-01
    z[0,4,1]  R476      -3.7442067265510559e-01
    z[0,4,1]  R477      5.4200363159179688e-01
    z[0,4,1]  R478      -3.6016467213630676e-01
    z[0,4,1]  R479      -1.0555035620927811e-01
    z[0,4,1]  R480      -2.8569099307060242e-01
    z[0,4,1]  R481      7.3532074689865112e-02
    z[0,4,1]  R482      5.3862494230270386e-01
    z[0,4,1]  R483      5.9677477926015854e-02
    z[0,4,1]  R484      1.7477940022945404e-01
    z[0,4,1]  R485      2.8231540322303772e-01
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R346      -1
    z[0,4,2]  R347      1
    z[0,4,2]  R356      -2.7751281857490540e-01
    z[0,4,2]  R357      3.2427478581666946e-02
    z[0,4,2]  R358      -2.1592350304126740e-01
    z[0,4,2]  R359      2.3749215900897980e-01
    z[0,4,2]  R360      1.6844940185546875e-01
    z[0,4,2]  R361      -1.6035212576389313e-01
    z[0,4,2]  R362      4.0930435061454773e-02
    z[0,4,2]  R363      -8.3011329174041748e-02
    z[0,4,2]  R364      0.282932847738266
    z[0,4,2]  R365      1.0794003307819366e-01
    z[0,4,2]  R366      5.0963485240936279e-01
    z[0,4,2]  R367      2.9356148838996887e-01
    z[0,4,2]  R368      3.5316619277000427e-01
    z[0,4,2]  R369      2.4036282300949097e-01
    z[0,4,2]  R370      -8.5613265633583069e-02
    z[0,4,2]  R371      4.1041418910026550e-01
    z[0,4,2]  R372      -1.1305548995733261e-01
    z[0,4,2]  R373      -2.3243862390518188e-01
    z[0,4,2]  R374      -4.3270260095596313e-01
    z[0,4,2]  R375      -1.4517985284328461e-01
    z[0,4,2]  R376      2.1311147511005402e-01
    z[0,4,2]  R377      5.4877460002899170e-01
    z[0,4,2]  R378      3.2962255179882050e-02
    z[0,4,2]  R379      -2.2074329853057861e-01
    z[0,4,2]  R380      -4.7355014085769653e-01
    z[0,4,2]  R381      -1.0937143862247467e-01
    z[0,4,2]  R382      1.5144604444503784e-01
    z[0,4,2]  R383      -6.7280530929565430e-02
    z[0,4,2]  R384      2.2395841777324677e-01
    z[0,4,2]  R385      3.5116162896156311e-01
    z[0,4,2]  R386      3.6203429102897644e-01
    z[0,4,2]  R387      -2.9231157898902893e-01
    z[0,4,2]  R388      -4.4138431549072266e-01
    z[0,4,2]  R389      0.106072336435318
    z[0,4,2]  R390      -6.7699514329433441e-02
    z[0,4,2]  R391      -5.5849432945251465e-01
    z[0,4,2]  R392      -3.3190563321113586e-02
    z[0,4,2]  R393      -4.8151548951864243e-02
    z[0,4,2]  R394      -5.4949706792831421e-01
    z[0,4,2]  R395      -3.5029265284538269e-01
    z[0,4,2]  R396      5.2927613258361816e-02
    z[0,4,2]  R397      -3.7967246770858765e-01
    z[0,4,2]  R398      -6.2895250320434570e-01
    z[0,4,2]  R399      -1.4505137503147125e-01
    z[0,4,2]  R400      -3.4477221965789795e-01
    z[0,4,2]  R401      -2.7408489584922791e-01
    z[0,4,2]  R402      -1.8525023758411407e-01
    z[0,4,2]  R403      9.5642521977424622e-02
    z[0,4,2]  R404      7.1118585765361786e-02
    z[0,4,2]  R405      1.3777109980583191e-01
    z[0,4,2]  R406      5.7343918085098267e-01
    z[0,4,2]  R407      3.6670535802841187e-02
    z[0,4,2]  R408      1.3931621611118317e-01
    z[0,4,2]  R409      6.4815413951873779e-01
    z[0,4,2]  R410      -7.3000110685825348e-02
    z[0,4,2]  R411      4.9809610843658447e-01
    z[0,4,2]  R412      2.1548955142498016e-01
    z[0,4,2]  R413      2.7396270632743835e-01
    z[0,4,2]  R414      -1.0538420639932156e-02
    z[0,4,2]  R415      1.9095709919929504e-01
    z[0,4,2]  R416      -1.3599984347820282e-01
    z[0,4,2]  R417      6.3948506116867065e-01
    z[0,4,2]  R418      4.0348327159881592e-01
    z[0,4,2]  R419      -9.1357663273811340e-02
    z[0,4,2]  R420      2.3269453644752502e-01
    z[0,4,2]  R421      2.8954052925109863e-01
    z[0,4,2]  R422      9.3520984053611755e-02
    z[0,4,2]  R423      3.6777067184448242e-01
    z[0,4,2]  R424      4.8150235414505005e-01
    z[0,4,2]  R425      1.8627518415451050e-01
    z[0,4,2]  R426      7.9654440283775330e-02
    z[0,4,2]  R427      -6.9881482049822807e-03
    z[0,4,2]  R428      0.55242520570755
    z[0,4,2]  R429      0.517589807510376
    z[0,4,2]  R430      0.382357656955719
    z[0,4,2]  R431      4.3718099594116211e-01
    z[0,4,2]  R432      1.4393419027328491e-01
    z[0,4,2]  R433      7.7611964941024780e-01
    z[0,4,2]  R434      1.7767506837844849e-01
    z[0,4,2]  R435      4.2432352900505066e-01
    z[0,4,2]  R436      4.7660058736801147e-01
    z[0,4,2]  R437      4.2518422007560730e-01
    z[0,4,2]  R438      7.4195876717567444e-02
    z[0,4,2]  R439      1.4133690297603607e-01
    z[0,4,2]  R440      5.8930929750204086e-02
    z[0,4,2]  R441      -1.5129742026329041e-01
    z[0,4,2]  R442      -6.9181986153125763e-02
    z[0,4,2]  R443      4.6942636370658875e-02
    z[0,4,2]  R444      1.3853174448013306e-01
    z[0,4,2]  R445      4.1284161806106567e-01
    z[0,4,2]  R446      5.5429196357727051e-01
    z[0,4,2]  R447      3.2978755235671997e-01
    z[0,4,2]  R448      2.8025823831558228e-01
    z[0,4,2]  R449      2.6140713691711426e-01
    z[0,4,2]  R450      1.5084272250533104e-02
    z[0,4,2]  R451      -1.9392465054988861e-01
    z[0,4,2]  R452      -9.1017229715362191e-04
    z[0,4,2]  R453      3.2170155644416809e-01
    z[0,4,2]  R454      1.8902434408664703e-01
    z[0,4,2]  R455      7.8653432428836823e-02
    z[0,4,2]  R456      1.3745307922363281e-01
    z[0,4,2]  R457      4.8542514443397522e-01
    z[0,4,2]  R458      2.1271798014640808e-01
    z[0,4,2]  R459      -1.8609980121254921e-02
    z[0,4,2]  R460      1.2843313813209534e-01
    z[0,4,2]  R461      5.8540576696395874e-01
    z[0,4,2]  R462      1.0369451344013214e-01
    z[0,4,2]  R463      1.0151851177215576e-01
    z[0,4,2]  R464      2.9004657268524170e-01
    z[0,4,2]  R465      4.6488952636718750e-01
    z[0,4,2]  R466      1.6060872375965118e-01
    z[0,4,2]  R467      -1.2836912274360657e-01
    z[0,4,2]  R468      2.7374556660652161e-01
    z[0,4,2]  R469      1.6982159018516541e-01
    z[0,4,2]  R470      1.8278861045837402e-01
    z[0,4,2]  R471      4.2374005913734436e-01
    z[0,4,2]  R472      5.0773404538631439e-02
    z[0,4,2]  R473      7.4549637734889984e-02
    z[0,4,2]  R474      -6.2355047464370728e-01
    z[0,4,2]  R475      3.8519951701164246e-01
    z[0,4,2]  R476      4.8653751611709595e-02
    z[0,4,2]  R477      4.1227829456329346e-01
    z[0,4,2]  R478      -1.2187819182872772e-01
    z[0,4,2]  R479      4.1454848647117615e-01
    z[0,4,2]  R480      3.5861104726791382e-01
    z[0,4,2]  R481      3.0075496435165405e-01
    z[0,4,2]  R482      -0.518540620803833
    z[0,4,2]  R483      2.9725831747055054e-01
    z[0,4,2]  R484      3.5120970010757446e-01
    z[0,4,2]  R485      3.8471260666847229e-01
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R348      -1
    z[0,4,3]  R349      1
    z[0,4,3]  R356      1.9135875999927521e-01
    z[0,4,3]  R357      6.8657793104648590e-02
    z[0,4,3]  R358      3.0188897252082825e-01
    z[0,4,3]  R359      2.8336721658706665e-01
    z[0,4,3]  R360      1.4530107378959656e-01
    z[0,4,3]  R361      4.2767179012298584e-01
    z[0,4,3]  R362      8.2895606756210327e-02
    z[0,4,3]  R363      2.5135058164596558e-01
    z[0,4,3]  R364      -7.1884766221046448e-02
    z[0,4,3]  R365      -9.1833256185054779e-02
    z[0,4,3]  R366      1.5541224181652069e-01
    z[0,4,3]  R367      2.2369624674320221e-01
    z[0,4,3]  R368      4.6875947713851929e-01
    z[0,4,3]  R369      2.9892998933792114e-01
    z[0,4,3]  R370      1.7789126932621002e-01
    z[0,4,3]  R371      0.769805908203125
    z[0,4,3]  R372      5.9138017892837524e-01
    z[0,4,3]  R373      1.6783721745014191e-01
    z[0,4,3]  R374      4.6502524614334106e-01
    z[0,4,3]  R375      6.3687413930892944e-01
    z[0,4,3]  R376      8.1289058923721313e-01
    z[0,4,3]  R377      4.5772558450698853e-01
    z[0,4,3]  R378      2.7774566411972046e-01
    z[0,4,3]  R379      -7.3069196939468384e-01
    z[0,4,3]  R380      -5.3437966108322144e-01
    z[0,4,3]  R381      -7.3799526691436768e-01
    z[0,4,3]  R382      -3.4302836656570435e-01
    z[0,4,3]  R383      2.0139060914516449e-01
    z[0,4,3]  R384      3.0195074155926704e-02
    z[0,4,3]  R385      -2.8804862499237061e-01
    z[0,4,3]  R386      7.4857777357101440e-01
    z[0,4,3]  R387      8.1203043460845947e-01
    z[0,4,3]  R388      6.4871352910995483e-01
    z[0,4,3]  R389      2.7941519021987915e-01
    z[0,4,3]  R390      -0.682442307472229
    z[0,4,3]  R391      2.4517105892300606e-02
    z[0,4,3]  R392      1.1850558966398239e-01
    z[0,4,3]  R393      -1.5918090939521790e-02
    z[0,4,3]  R394      -2.7980056405067444e-01
    z[0,4,3]  R395      -5.4726260900497437e-01
    z[0,4,3]  R396      1.6001372039318085e-01
    z[0,4,3]  R397      2.8818270564079285e-01
    z[0,4,3]  R398      -1.6304506361484528e-01
    z[0,4,3]  R399      3.6362621188163757e-01
    z[0,4,3]  R400      1.2032174319028854e-01
    z[0,4,3]  R401      1.7823085188865662e-01
    z[0,4,3]  R402      -3.5893155727535486e-03
    z[0,4,3]  R403      -3.8156139850616455e-01
    z[0,4,3]  R404      6.0356277227401733e-01
    z[0,4,3]  R405      -2.8164786100387573e-01
    z[0,4,3]  R406      -5.4171049594879150e-01
    z[0,4,3]  R407      1.0718328505754471e-01
    z[0,4,3]  R408      -0.0906682088971138
    z[0,4,3]  R409      -6.5006553195416927e-03
    z[0,4,3]  R410      8.5837788879871368e-02
    z[0,4,3]  R411      2.3907181620597839e-01
    z[0,4,3]  R412      4.7946058213710785e-02
    z[0,4,3]  R413      -3.1040126085281372e-01
    z[0,4,3]  R414      -4.5869520306587219e-01
    z[0,4,3]  R415      -2.3695114254951477e-01
    z[0,4,3]  R416      -0.384262353181839
    z[0,4,3]  R417      0.0794503390789032
    z[0,4,3]  R418      2.3354966938495636e-01
    z[0,4,3]  R419      -3.7225788831710815e-01
    z[0,4,3]  R420      -0.152827650308609
    z[0,4,3]  R421      5.2892103791236877e-02
    z[0,4,3]  R422      4.5519590377807617e-01
    z[0,4,3]  R423      -5.3364926576614380e-01
    z[0,4,3]  R424      -3.1549653410911560e-01
    z[0,4,3]  R425      -5.7637596130371094e-01
    z[0,4,3]  R426      -4.6700218319892883e-01
    z[0,4,3]  R427      1.2275058031082153e-01
    z[0,4,3]  R428      2.8028586506843567e-01
    z[0,4,3]  R429      -2.9184681177139282e-01
    z[0,4,3]  R430      4.9547683447599411e-02
    z[0,4,3]  R431      1.1898304522037506e-01
    z[0,4,3]  R432      1.1744812875986099e-01
    z[0,4,3]  R433      1.3186505995690823e-02
    z[0,4,3]  R434      2.9272291064262390e-01
    z[0,4,3]  R435      -3.4841954708099365e-01
    z[0,4,3]  R436      7.4020475149154663e-02
    z[0,4,3]  R437      -3.4547463059425354e-01
    z[0,4,3]  R438      -2.3175922036170959e-01
    z[0,4,3]  R439      8.8113643229007721e-02
    z[0,4,3]  R440      1.1977697908878326e-01
    z[0,4,3]  R441      -3.4683072566986084e-01
    z[0,4,3]  R442      -6.3989430665969849e-01
    z[0,4,3]  R443      -4.4078847765922546e-01
    z[0,4,3]  R444      -3.9069369435310364e-01
    z[0,4,3]  R445      -1.4880749583244324e-01
    z[0,4,3]  R446      6.0058438777923584e-01
    z[0,4,3]  R447      -4.9394312500953674e-01
    z[0,4,3]  R448      1.3339401781558990e-01
    z[0,4,3]  R449      -3.6142196506261826e-02
    z[0,4,3]  R450      -8.2534685730934143e-02
    z[0,4,3]  R451      -4.1981092095375061e-01
    z[0,4,3]  R452      -1.6490165144205093e-02
    z[0,4,3]  R453      -4.8603683710098267e-01
    z[0,4,3]  R454      -4.1447019577026367e-01
    z[0,4,3]  R455      -1.4740024507045746e-01
    z[0,4,3]  R456      -1.9657707214355469e-01
    z[0,4,3]  R457      1.4049349725246429e-01
    z[0,4,3]  R458      -5.3508497774600983e-02
    z[0,4,3]  R459      -3.9368104934692383e-01
    z[0,4,3]  R460      -4.3956348299980164e-01
    z[0,4,3]  R461      -7.0799507200717926e-02
    z[0,4,3]  R462      -3.5371506214141846e-01
    z[0,4,3]  R463      -8.1046774983406067e-02
    z[0,4,3]  R464      5.0250524654984474e-03
    z[0,4,3]  R465      -1.6853669285774231e-01
    z[0,4,3]  R466      3.2198518514633179e-01
    z[0,4,3]  R467      -3.1587982177734375e-01
    z[0,4,3]  R468      1.2399684637784958e-01
    z[0,4,3]  R469      0.325998991727829
    z[0,4,3]  R470      1.2346013635396957e-01
    z[0,4,3]  R471      1.2125533074140549e-01
    z[0,4,3]  R472      -3.0911889672279358e-01
    z[0,4,3]  R473      -3.4176650643348694e-01
    z[0,4,3]  R474      3.5552024841308594e-01
    z[0,4,3]  R475      4.6924769878387451e-01
    z[0,4,3]  R476      -2.5024303793907166e-01
    z[0,4,3]  R477      -3.3788588643074036e-01
    z[0,4,3]  R478      -3.6288508772850037e-01
    z[0,4,3]  R479      -1.9072756171226501e-01
    z[0,4,3]  R480      -4.1188588738441467e-01
    z[0,4,3]  R481      1.1242207884788513e-01
    z[0,4,3]  R482      5.2938532829284668e-01
    z[0,4,3]  R483      3.5849779844284058e-01
    z[0,4,3]  R484      6.4723688364028931e-01
    z[0,4,3]  R485      4.5425498485565186e-01
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R350      -1
    z[0,4,4]  R351      1
    z[0,4,4]  R356      -1.3734026253223419e-01
    z[0,4,4]  R357      1.9689242541790009e-01
    z[0,4,4]  R358      -1.7872823402285576e-02
    z[0,4,4]  R359      5.4330664873123169e-01
    z[0,4,4]  R360      2.6512509584426880e-01
    z[0,4,4]  R361      -1.5441097319126129e-01
    z[0,4,4]  R362      6.2950074672698975e-01
    z[0,4,4]  R363      -5.1566797494888306e-01
    z[0,4,4]  R364      -1.8406768143177032e-01
    z[0,4,4]  R365      1.5364494174718857e-02
    z[0,4,4]  R366      1.1874731630086899e-01
    z[0,4,4]  R367      1.5236093103885651e-01
    z[0,4,4]  R368      1.5645581483840942e-01
    z[0,4,4]  R369      5.7624153792858124e-02
    z[0,4,4]  R370      4.5855669304728508e-03
    z[0,4,4]  R371      2.3364938795566559e-01
    z[0,4,4]  R372      1.2672841548919678e-02
    z[0,4,4]  R373      -3.7586815655231476e-02
    z[0,4,4]  R374      4.5307138562202454e-01
    z[0,4,4]  R375      -1.8788692355155945e-01
    z[0,4,4]  R376      3.4083411097526550e-01
    z[0,4,4]  R377      2.6868802309036255e-01
    z[0,4,4]  R378      0.0283999964594841
    z[0,4,4]  R379      -3.1247171759605408e-01
    z[0,4,4]  R380      -1.0955525189638138e-01
    z[0,4,4]  R381      1.6455663368105888e-02
    z[0,4,4]  R382      3.3897200226783752e-01
    z[0,4,4]  R383      -2.9044884443283081e-01
    z[0,4,4]  R384      -5.1221090555191040e-01
    z[0,4,4]  R385      -5.1322090625762939e-01
    z[0,4,4]  R386      0.061478141695261
    z[0,4,4]  R387      2.3901236057281494e-01
    z[0,4,4]  R388      -2.7215710282325745e-01
    z[0,4,4]  R389      3.7062233686447144e-01
    z[0,4,4]  R390      1.1155769973993301e-01
    z[0,4,4]  R391      -4.0102687478065491e-01
    z[0,4,4]  R392      -3.8252141326665878e-02
    z[0,4,4]  R393      4.2325085401535034e-01
    z[0,4,4]  R394      -3.5322535037994385e-01
    z[0,4,4]  R395      -2.2889564931392670e-01
    z[0,4,4]  R396      -1.1472114175558090e-01
    z[0,4,4]  R397      -1.1252373456954956e-01
    z[0,4,4]  R398      -2.7165785431861877e-02
    z[0,4,4]  R399      -4.0477615594863892e-01
    z[0,4,4]  R400      7.2668421268463135e-01
    z[0,4,4]  R401      6.1354964971542358e-01
    z[0,4,4]  R402      -9.9070511758327484e-02
    z[0,4,4]  R403      0.409146249294281
    z[0,4,4]  R404      -6.6583938896656036e-02
    z[0,4,4]  R405      2.5064873695373535e-01
    z[0,4,4]  R406      1.3133677840232849e-01
    z[0,4,4]  R407      -3.3229254186153412e-02
    z[0,4,4]  R408      -3.2199618220329285e-01
    z[0,4,4]  R409      1.4842495322227478e-01
    z[0,4,4]  R410      -3.7058830261230469e-01
    z[0,4,4]  R411      6.1142629384994507e-01
    z[0,4,4]  R412      -2.3097884654998779e-01
    z[0,4,4]  R413      3.4388538450002670e-02
    z[0,4,4]  R414      -3.0489778518676758e-01
    z[0,4,4]  R415      -0.0886390283703804
    z[0,4,4]  R416      3.1590268015861511e-01
    z[0,4,4]  R417      2.3376764729619026e-03
    z[0,4,4]  R418      3.7073215842247009e-01
    z[0,4,4]  R419      4.4369032979011536e-01
    z[0,4,4]  R420      4.6025916934013367e-01
    z[0,4,4]  R421      3.5726550966501236e-02
    z[0,4,4]  R422      3.6453232169151306e-01
    z[0,4,4]  R423      -3.4587019681930542e-01
    z[0,4,4]  R424      -2.4863809812813997e-03
    z[0,4,4]  R425      -5.2206773310899734e-02
    z[0,4,4]  R426      2.4215477705001831e-01
    z[0,4,4]  R427      1.8904080986976624e-01
    z[0,4,4]  R428      1.5691670775413513e-01
    z[0,4,4]  R429      5.7197425514459610e-02
    z[0,4,4]  R430      -1.7119950056076050e-01
    z[0,4,4]  R431      3.0332329869270325e-01
    z[0,4,4]  R432      -1.3827908039093018e-01
    z[0,4,4]  R433      3.6695733666419983e-01
    z[0,4,4]  R434      -1.0033635795116425e-01
    z[0,4,4]  R435      -3.8435709476470947e-01
    z[0,4,4]  R436      4.3267095088958740e-01
    z[0,4,4]  R437      -2.3215970396995544e-01
    z[0,4,4]  R438      -3.3439084887504578e-01
    z[0,4,4]  R439      -1.2737533450126648e-01
    z[0,4,4]  R440      2.2421942651271820e-01
    z[0,4,4]  R441      -3.1862971186637878e-01
    z[0,4,4]  R442      -1.4161466062068939e-01
    z[0,4,4]  R443      -2.0014038681983948e-01
    z[0,4,4]  R444      -1.7013674974441528e-01
    z[0,4,4]  R445      -2.2357928752899170e-01
    z[0,4,4]  R446      4.8134982585906982e-01
    z[0,4,4]  R447      3.0386200547218323e-01
    z[0,4,4]  R448      5.6228119134902954e-01
    z[0,4,4]  R449      2.6087793707847595e-01
    z[0,4,4]  R450      -1.7765650525689125e-02
    z[0,4,4]  R451      5.7998904958367348e-03
    z[0,4,4]  R452      -1.9561885297298431e-01
    z[0,4,4]  R453      -1.5254600346088409e-01
    z[0,4,4]  R454      -2.3245088756084442e-01
    z[0,4,4]  R455      -2.4510839581489563e-01
    z[0,4,4]  R456      3.4389652311801910e-02
    z[0,4,4]  R457      1.6696244478225708e-01
    z[0,4,4]  R458      3.9626786112785339e-01
    z[0,4,4]  R459      -4.9778923392295837e-02
    z[0,4,4]  R460      1.0410825908184052e-01
    z[0,4,4]  R461      -3.0679020285606384e-01
    z[0,4,4]  R462      2.2262823581695557e-01
    z[0,4,4]  R463      -0.0813310518860817
    z[0,4,4]  R464      9.8297655582427979e-02
    z[0,4,4]  R465      9.0512603521347046e-02
    z[0,4,4]  R466      4.6489360928535461e-01
    z[0,4,4]  R467      -9.3833103775978088e-02
    z[0,4,4]  R468      4.2973878979682922e-01
    z[0,4,4]  R469      3.6662909388542175e-01
    z[0,4,4]  R470      5.0199198722839355e-01
    z[0,4,4]  R471      -4.3391962535679340e-03
    z[0,4,4]  R472      1.9471764564514160e-01
    z[0,4,4]  R473      -2.9023903608322144e-01
    z[0,4,4]  R474      -2.7248394489288330e-01
    z[0,4,4]  R475      -2.4616238474845886e-01
    z[0,4,4]  R476      2.4163340032100677e-01
    z[0,4,4]  R477      -2.2500516474246979e-01
    z[0,4,4]  R478      -1.0002250224351883e-01
    z[0,4,4]  R479      -7.6770171523094177e-02
    z[0,4,4]  R480      -2.0987370610237122e-01
    z[0,4,4]  R481      -1.0867885500192642e-01
    z[0,4,4]  R482      -6.6451430320739746e-02
    z[0,4,4]  R483      -5.7496535778045654e-01
    z[0,4,4]  R484      -4.4193667173385620e-01
    z[0,4,4]  R485      -4.9371123313903809e-01
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R352      -1
    z[0,4,5]  R353      1
    z[0,4,5]  R356      6.4809662103652954e-01
    z[0,4,5]  R357      5.0592297315597534e-01
    z[0,4,5]  R358      2.8670877218246460e-01
    z[0,4,5]  R359      4.8585128784179688e-01
    z[0,4,5]  R360      6.3074672222137451e-01
    z[0,4,5]  R361      1.6453932970762253e-02
    z[0,4,5]  R362      3.2417336106300354e-01
    z[0,4,5]  R363      0.781249463558197
    z[0,4,5]  R364      9.1276556253433228e-02
    z[0,4,5]  R365      -2.5241073966026306e-01
    z[0,4,5]  R366      4.1232284158468246e-02
    z[0,4,5]  R367      4.1825573891401291e-02
    z[0,4,5]  R368      -2.2501009702682495e-01
    z[0,4,5]  R369      -2.1672993898391724e-01
    z[0,4,5]  R370      1.8610468506813049e-01
    z[0,4,5]  R371      -6.4693358726799488e-03
    z[0,4,5]  R372      -2.6729911565780640e-01
    z[0,4,5]  R373      4.4847447425127029e-02
    z[0,4,5]  R374      1.5220044553279877e-01
    z[0,4,5]  R375      -4.5384258031845093e-01
    z[0,4,5]  R376      1.6075240075588226e-01
    z[0,4,5]  R377      -1.6099143773317337e-02
    z[0,4,5]  R378      -4.0589755773544312e-01
    z[0,4,5]  R379      -2.6492691040039062e-01
    z[0,4,5]  R380      -4.0279945731163025e-01
    z[0,4,5]  R381      -2.4074497818946838e-01
    z[0,4,5]  R382      -4.8913535475730896e-01
    z[0,4,5]  R383      -2.5961726903915405e-01
    z[0,4,5]  R384      -1.9433766603469849e-01
    z[0,4,5]  R385      -1.1268361657857895e-01
    z[0,4,5]  R386      4.0919068455696106e-01
    z[0,4,5]  R387      5.9867627918720245e-02
    z[0,4,5]  R388      1.3973297178745270e-01
    z[0,4,5]  R389      2.2402912378311157e-01
    z[0,4,5]  R390      -2.6954427361488342e-01
    z[0,4,5]  R391      -1.1689981073141098e-01
    z[0,4,5]  R392      -1.0135784000158310e-01
    z[0,4,5]  R393      -9.9021323025226593e-02
    z[0,4,5]  R394      -4.6825075149536133e-01
    z[0,4,5]  R395      -4.3617191910743713e-01
    z[0,4,5]  R396      3.8111633062362671e-01
    z[0,4,5]  R397      5.5571067333221436e-01
    z[0,4,5]  R398      1.8060798943042755e-01
    z[0,4,5]  R399      -1.1214573681354523e-01
    z[0,4,5]  R400      1.6730263829231262e-01
    z[0,4,5]  R401      5.3711807727813721e-01
    z[0,4,5]  R402      7.2642147541046143e-02
    z[0,4,5]  R403      1.1676761507987976e-01
    z[0,4,5]  R404      -7.5571663677692413e-02
    z[0,4,5]  R405      1.6545480489730835e-01
    z[0,4,5]  R406      -4.1990029811859131e-01
    z[0,4,5]  R407      -6.0991442203521729e-01
    z[0,4,5]  R408      -4.6201825141906738e-01
    z[0,4,5]  R409      0.0101442476734519
    z[0,4,5]  R410      -6.8104475736618042e-02
    z[0,4,5]  R411      -2.8355339169502258e-01
    z[0,4,5]  R412      -7.7083487994968891e-03
    z[0,4,5]  R413      -1.7236265540122986e-01
    z[0,4,5]  R414      -2.4853106588125229e-02
    z[0,4,5]  R415      -8.7030403316020966e-02
    z[0,4,5]  R416      -1.6514272987842560e-01
    z[0,4,5]  R417      -2.5870227813720703e-01
    z[0,4,5]  R418      -4.4403988122940063e-01
    z[0,4,5]  R419      -3.7668019533157349e-01
    z[0,4,5]  R420      -2.0139142870903015e-01
    z[0,4,5]  R421      -7.1815311908721924e-01
    z[0,4,5]  R422      1.2453091889619827e-01
    z[0,4,5]  R423      -2.5025227665901184e-01
    z[0,4,5]  R424      -3.5274305939674377e-01
    z[0,4,5]  R425      -6.1772572994232178e-01
    z[0,4,5]  R426      -6.2005412578582764e-01
    z[0,4,5]  R427      -4.0256899595260620e-01
    z[0,4,5]  R428      3.3030384778976440e-01
    z[0,4,5]  R429      4.0965270996093750e-01
    z[0,4,5]  R430      -4.8622965812683105e-01
    z[0,4,5]  R431      1.9258794188499451e-01
    z[0,4,5]  R432      1.0406956821680069e-01
    z[0,4,5]  R433      8.2377210259437561e-02
    z[0,4,5]  R434      -8.4257304668426514e-02
    z[0,4,5]  R435      3.9063131809234619e-01
    z[0,4,5]  R436      1.0816441476345062e-01
    z[0,4,5]  R437      0.349244624376297
    z[0,4,5]  R438      -3.9362901449203491e-01
    z[0,4,5]  R439      -5.9012597799301147e-01
    z[0,4,5]  R440      -7.8150975704193115e-01
    z[0,4,5]  R441      -6.7393243312835693e-01
    z[0,4,5]  R442      -2.3224505782127380e-01
    z[0,4,5]  R443      -6.3647961616516113e-01
    z[0,4,5]  R444      -6.0548824071884155e-01
    z[0,4,5]  R445      -1.4366070926189423e-01
    z[0,4,5]  R446      4.4098678976297379e-02
    z[0,4,5]  R447      -4.5739594101905823e-01
    z[0,4,5]  R448      1.4385650865733624e-02
    z[0,4,5]  R449      -5.9956979751586914e-01
    z[0,4,5]  R450      -6.7116081714630127e-01
    z[0,4,5]  R451      -5.8865559101104736e-01
    z[0,4,5]  R452      -1.8110229074954987e-01
    z[0,4,5]  R453      -1.0773810744285583e-01
    z[0,4,5]  R454      2.6756206154823303e-01
    z[0,4,5]  R455      1.8646885454654694e-01
    z[0,4,5]  R456      -5.6428488343954086e-02
    z[0,4,5]  R457      2.0217919349670410e-01
    z[0,4,5]  R458      -3.9791306853294373e-01
    z[0,4,5]  R459      -5.7171505689620972e-01
    z[0,4,5]  R460      -3.4493902325630188e-01
    z[0,4,5]  R461      7.1420714259147644e-02
    z[0,4,5]  R462      3.5805463790893555e-01
    z[0,4,5]  R463      -1.9722411036491394e-01
    z[0,4,5]  R464      -1.6521330177783966e-01
    z[0,4,5]  R465      -5.1570698618888855e-02
    z[0,4,5]  R466      2.0275006070733070e-02
    z[0,4,5]  R467      -3.8745424151420593e-01
    z[0,4,5]  R468      -1.4860782027244568e-01
    z[0,4,5]  R469      -2.1801829338073730e-01
    z[0,4,5]  R470      2.8767675161361694e-01
    z[0,4,5]  R471      -4.2009210586547852e-01
    z[0,4,5]  R472      3.5468569397926331e-01
    z[0,4,5]  R473      2.0468638837337494e-01
    z[0,4,5]  R474      1.5067258477210999e-01
    z[0,4,5]  R475      -2.4595342576503754e-02
    z[0,4,5]  R476      -8.1414008140563965e-01
    z[0,4,5]  R477      0.0750207006931305
    z[0,4,5]  R478      -0.131648451089859
    z[0,4,5]  R479      1.3997261226177216e-01
    z[0,4,5]  R480      2.8227525949478149e-01
    z[0,4,5]  R481      1.3914388418197632e-01
    z[0,4,5]  R482      1.4618138968944550e-01
    z[0,4,5]  R483      -1.0838557034730911e-01
    z[0,4,5]  R484      -1.1386824399232864e-01
    z[0,4,5]  R485      1.1800454556941986e-01
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R354      -1
    z[0,4,6]  R355      1
    z[0,4,6]  R356      -6.0252517461776733e-02
    z[0,4,6]  R357      -1.3458128273487091e-01
    z[0,4,6]  R358      3.9626464247703552e-02
    z[0,4,6]  R359      -2.1730247139930725e-01
    z[0,4,6]  R360      -4.3661540746688843e-01
    z[0,4,6]  R361      -7.1414500474929810e-01
    z[0,4,6]  R362      5.0165539979934692e-01
    z[0,4,6]  R363      -9.1163434088230133e-02
    z[0,4,6]  R364      -2.1482041478157043e-01
    z[0,4,6]  R365      -3.5165694355964661e-01
    z[0,4,6]  R366      -2.2796644270420074e-01
    z[0,4,6]  R367      3.0177685618400574e-01
    z[0,4,6]  R368      -1.5494552254676819e-01
    z[0,4,6]  R369      -1.7243444919586182e-01
    z[0,4,6]  R370      4.1394731402397156e-01
    z[0,4,6]  R371      -4.4765327125787735e-02
    z[0,4,6]  R372      2.7599847316741943e-01
    z[0,4,6]  R373      7.7921295166015625e-01
    z[0,4,6]  R374      -1.3724772632122040e-01
    z[0,4,6]  R375      2.5424492359161377e-01
    z[0,4,6]  R376      1.8255215883255005e-01
    z[0,4,6]  R377      -5.9460711479187012e-01
    z[0,4,6]  R378      5.8936983346939087e-01
    z[0,4,6]  R379      1.0386855900287628e-01
    z[0,4,6]  R380      -1.2658125162124634e-01
    z[0,4,6]  R381      0.435189425945282
    z[0,4,6]  R382      5.6694036722183228e-01
    z[0,4,6]  R383      1.1628223955631256e-01
    z[0,4,6]  R384      3.2735636830329895e-01
    z[0,4,6]  R385      8.4505289793014526e-02
    z[0,4,6]  R386      -0.0775846540927887
    z[0,4,6]  R387      8.2278758287429810e-02
    z[0,4,6]  R388      3.6906811594963074e-01
    z[0,4,6]  R389      2.8988981246948242e-01
    z[0,4,6]  R390      4.0837913751602173e-01
    z[0,4,6]  R391      3.6984574794769287e-01
    z[0,4,6]  R392      8.2332855463027954e-01
    z[0,4,6]  R393      5.0635886192321777e-01
    z[0,4,6]  R394      3.5748815536499023e-01
    z[0,4,6]  R395      3.5047656297683716e-01
    z[0,4,6]  R396      2.7287659049034119e-01
    z[0,4,6]  R397      -8.6940238252282143e-03
    z[0,4,6]  R398      3.3845886588096619e-01
    z[0,4,6]  R399      -5.6192469596862793e-01
    z[0,4,6]  R400      3.7011390924453735e-01
    z[0,4,6]  R401      9.6734218299388885e-02
    z[0,4,6]  R402      2.8947748243808746e-02
    z[0,4,6]  R403      8.4491841495037079e-02
    z[0,4,6]  R404      -2.7116268873214722e-01
    z[0,4,6]  R405      5.5536723136901855e-01
    z[0,4,6]  R406      -1.0864780098199844e-01
    z[0,4,6]  R407      -3.1635737419128418e-01
    z[0,4,6]  R408      2.7368339896202087e-01
    z[0,4,6]  R409      -6.4924255013465881e-02
    z[0,4,6]  R410      1.6080971807241440e-02
    z[0,4,6]  R411      1.1388626694679260e-01
    z[0,4,6]  R412      -1.1335127800703049e-01
    z[0,4,6]  R413      6.2742494046688080e-02
    z[0,4,6]  R414      8.7315574288368225e-02
    z[0,4,6]  R415      -4.3224021792411804e-01
    z[0,4,6]  R416      4.6385556459426880e-01
    z[0,4,6]  R417      1.3388817012310028e-01
    z[0,4,6]  R418      -1.0406203567981720e-01
    z[0,4,6]  R419      -3.2532370090484619e-01
    z[0,4,6]  R420      -5.8396351337432861e-01
    z[0,4,6]  R421      -6.0750752687454224e-02
    z[0,4,6]  R422      3.7941977381706238e-01
    z[0,4,6]  R423      -8.0928064882755280e-02
    z[0,4,6]  R424      -3.2811298966407776e-01
    z[0,4,6]  R425      5.3886175155639648e-03
    z[0,4,6]  R426      -2.4670192599296570e-01
    z[0,4,6]  R427      1.5145288407802582e-01
    z[0,4,6]  R428      -1.2451510876417160e-01
    z[0,4,6]  R429      1.9450066983699799e-01
    z[0,4,6]  R430      5.6221973150968552e-02
    z[0,4,6]  R431      4.0203872323036194e-01
    z[0,4,6]  R432      -6.0775661468505859e-01
    z[0,4,6]  R433      -4.1605624556541443e-01
    z[0,4,6]  R434      -2.0083867013454437e-02
    z[0,4,6]  R435      -4.1355829685926437e-02
    z[0,4,6]  R436      0.169141948223114
    z[0,4,6]  R437      -2.3644529283046722e-01
    z[0,4,6]  R438      -5.4670977592468262e-01
    z[0,4,6]  R439      -4.8036286234855652e-01
    z[0,4,6]  R440      -1.3549636304378510e-01
    z[0,4,6]  R441      1.3533039391040802e-01
    z[0,4,6]  R442      -3.3536779880523682e-01
    z[0,4,6]  R443      -7.4160680174827576e-02
    z[0,4,6]  R444      3.9604222774505615e-01
    z[0,4,6]  R445      8.2372479140758514e-02
    z[0,4,6]  R446      -2.0938409864902496e-01
    z[0,4,6]  R447      -9.9131613969802856e-02
    z[0,4,6]  R448      -1.5620626509189606e-01
    z[0,4,6]  R449      -3.5751909017562866e-02
    z[0,4,6]  R450      3.4721937775611877e-01
    z[0,4,6]  R451      -1.6696329414844513e-01
    z[0,4,6]  R452      -5.4487246274948120e-01
    z[0,4,6]  R453      2.4621315300464630e-01
    z[0,4,6]  R454      -2.9758375883102417e-01
    z[0,4,6]  R455      -3.2744112610816956e-01
    z[0,4,6]  R456      -1.3781943917274475e-01
    z[0,4,6]  R457      1.9308337569236755e-01
    z[0,4,6]  R458      -4.1964939236640930e-01
    z[0,4,6]  R459      -3.2751351594924927e-02
    z[0,4,6]  R460      4.0953123569488525e-01
    z[0,4,6]  R461      -2.7584463357925415e-01
    z[0,4,6]  R462      -6.4742863178253174e-01
    z[0,4,6]  R463      -1.5823251008987427e-01
    z[0,4,6]  R464      1.8326042592525482e-01
    z[0,4,6]  R465      8.2990802824497223e-02
    z[0,4,6]  R466      -6.4104783535003662e-01
    z[0,4,6]  R467      -7.6623722910881042e-02
    z[0,4,6]  R468      -1.5886804461479187e-01
    z[0,4,6]  R469      2.6446020603179932e-01
    z[0,4,6]  R470      -4.7957371920347214e-02
    z[0,4,6]  R471      1.0231915861368179e-01
    z[0,4,6]  R472      -6.3529020547866821e-01
    z[0,4,6]  R473      -2.9536217451095581e-01
    z[0,4,6]  R474      -1.2536510825157166e-01
    z[0,4,6]  R475      -2.9091672971844673e-02
    z[0,4,6]  R476      -2.2160361707210541e-01
    z[0,4,6]  R477      -4.0055537223815918e-01
    z[0,4,6]  R478      -0.0674145370721817
    z[0,4,6]  R479      7.8882798552513123e-02
    z[0,4,6]  R480      3.0971509218215942e-01
    z[0,4,6]  R481      2.9696798324584961e-01
    z[0,4,6]  R482      1.4758327975869179e-02
    z[0,4,6]  R483      2.4358795583248138e-01
    z[0,4,6]  R484      1.0696541517972946e-01
    z[0,4,6]  R485      3.1952759623527527e-01
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R486      -1
    z[4,0,0]  R487      1
    z[4,0,0]  R500      -7.5595939159393311e-01
    z[4,0,0]  R501      -3.8382682204246521e-01
    z[4,0,0]  R502      -3.0085310339927673e-01
    z[4,0,0]  R503      -4.3898898363113403e-01
    z[4,0,0]  R504      -5.3916312754154205e-02
    z[4,0,0]  R505      2.0261155068874359e-01
    z[4,0,0]  R506      -3.3357802033424377e-01
    z[4,0,0]  R507      -4.6541181206703186e-01
    z[4,0,0]  R508      -1.7482081055641174e-01
    z[4,0,0]  R509      -3.2698640227317810e-01
    z[4,0,0]  R510      -2.0467326045036316e-01
    z[4,0,0]  R511      3.1608107686042786e-01
    z[4,0,0]  R512      1.9089536741375923e-02
    z[4,0,0]  R513      3.4732836484909058e-01
    z[4,0,0]  R514      8.6776286363601685e-01
    z[4,0,0]  R515      -6.4097873866558075e-02
    z[4,0,0]  R516      9.2839550971984863e-01
    z[4,0,0]  R517      8.8717746734619141e-01
    z[4,0,0]  R518      0.766423225402832
    z[4,0,0]  R519      8.0424225330352783e-01
    z[4,0,0]  R520      2.6922184973955154e-02
    z[4,0,0]  R521      -3.1197193264961243e-01
    z[4,0,0]  R522      -4.2019522190093994e-01
    z[4,0,0]  R523      8.5720755159854889e-02
    z[4,0,0]  R524      -4.9759708344936371e-02
    z[4,0,0]  R525      5.1685433834791183e-02
    z[4,0,0]  R526      1.4829632639884949e-01
    z[4,0,0]  R527      1.6176998615264893e-01
    z[4,0,0]  R528      2.3579502105712891e-01
    z[4,0,0]  R529      -1.4668072760105133e-01
    z[4,0,0]  R530      -2.1438447292894125e-03
    z[4,0,0]  R531      3.1725355982780457e-01
    z[4,0,0]  R532      -1.7180384695529938e-01
    z[4,0,0]  R533      -6.9005347788333893e-02
    z[4,0,0]  R534      5.3096253424882889e-02
    z[4,0,0]  R535      2.0548075437545776e-01
    z[4,0,0]  R536      3.2522976398468018e-01
    z[4,0,0]  R537      -5.1012493669986725e-02
    z[4,0,0]  R538      9.2113900184631348e-01
    z[4,0,0]  R539      5.6456762552261353e-01
    z[4,0,0]  R540      -3.2004863023757935e-01
    z[4,0,0]  R541      -1.2148412875831127e-02
    z[4,0,0]  R542      -6.3843570649623871e-02
    z[4,0,0]  R543      -5.1655262708663940e-02
    z[4,0,0]  R544      -1.8021368980407715e-01
    z[4,0,0]  R545      -1.5424399077892303e-01
    z[4,0,0]  R546      1.2154664099216461e-01
    z[4,0,0]  R547      8.8347233831882477e-02
    z[4,0,0]  R548      -2.8340601921081543e-01
    z[4,0,0]  R549      4.0016490221023560e-01
    z[4,0,0]  R550      -2.0374859869480133e-01
    z[4,0,0]  R551      -1.8331326544284821e-01
    z[4,0,0]  R552      -2.9987642168998718e-01
    z[4,0,0]  R553      -4.0957161784172058e-01
    z[4,0,0]  R554      -2.1545775234699249e-01
    z[4,0,0]  R555      -9.7865886986255646e-02
    z[4,0,0]  R556      3.2939872145652771e-01
    z[4,0,0]  R557      3.6172747611999512e-01
    z[4,0,0]  R558      6.9161552190780640e-01
    z[4,0,0]  R559      8.4867948293685913e-01
    z[4,0,0]  R560      3.0808833241462708e-01
    z[4,0,0]  R561      -1.6845524311065674e-01
    z[4,0,0]  R562      -1.5884728729724884e-01
    z[4,0,0]  R563      7.8646093606948853e-03
    z[4,0,0]  R564      -3.8685572147369385e-01
    z[4,0,0]  R565      -1.5796563029289246e-01
    z[4,0,0]  R566      -1.0707242041826248e-01
    z[4,0,0]  R567      9.2819523811340332e-01
    z[4,0,0]  R568      9.1676068305969238e-01
    z[4,0,0]  R569      8.5742688179016113e-01
    z[4,0,0]  R570      1.1749872565269470e-01
    z[4,0,0]  R571      -1.0967695713043213e-01
    z[4,0,0]  R572      -9.1911517083644867e-02
    z[4,0,0]  R573      -1.7805531620979309e-01
    z[4,0,0]  R574      -2.5043404102325439e-01
    z[4,0,0]  R575      2.8830792754888535e-02
    z[4,0,0]  R576      -5.3877104073762894e-02
    z[4,0,0]  R577      7.6644057035446167e-01
    z[4,0,0]  R578      4.5327857136726379e-01
    z[4,0,0]  R579      7.2841495275497437e-01
    z[4,0,0]  R580      -1.5652939677238464e-01
    z[4,0,0]  R581      -4.5320162177085876e-01
    z[4,0,0]  R582      8.3178174495697021e-01
    z[4,0,0]  R583      0.865403413772583
    z[4,0,0]  R584      6.3283419609069824e-01
    z[4,0,0]  R585      8.7871414422988892e-01
    z[4,0,0]  R586      3.6707940697669983e-01
    z[4,0,0]  R587      6.1472576856613159e-01
    z[4,0,0]  R588      4.5549169182777405e-01
    z[4,0,0]  R589      4.5406249165534973e-01
    z[4,0,0]  R590      -4.6641939878463745e-01
    z[4,0,0]  R591      -7.0453971624374390e-01
    z[4,0,0]  R592      -8.3414804935455322e-01
    z[4,0,0]  R593      1.1175207793712616e-01
    z[4,0,0]  R594      1.1520291864871979e-01
    z[4,0,0]  R595      -3.8944080471992493e-01
    z[4,0,0]  R596      -1.6368374228477478e-01
    z[4,0,0]  R597      1.8946231901645660e-01
    z[4,0,0]  R598      -7.5923389196395874e-01
    z[4,0,0]  R599      -7.3668062686920166e-01
    z[4,0,0]  R600      6.8893986940383911e-01
    z[4,0,0]  R601      7.6871931552886963e-01
    z[4,0,0]  R602      6.2952494621276855e-01
    z[4,0,0]  R603      8.2327091693878174e-01
    z[4,0,0]  R604      8.6730796098709106e-01
    z[4,0,0]  R605      -2.9360942542552948e-02
    z[4,0,0]  R606      6.6267901659011841e-01
    z[4,0,0]  R607      -1.1476036906242371e-01
    z[4,0,0]  R608      1.5397189557552338e-01
    z[4,0,0]  R609      -1.9980345666408539e-01
    z[4,0,0]  R610      3.2366719841957092e-01
    z[4,0,0]  R611      1.2916807830333710e-01
    z[4,0,0]  R612      -3.1732532382011414e-01
    z[4,0,0]  R613      -2.8837111592292786e-01
    z[4,0,0]  R614      -2.3688845336437225e-01
    z[4,0,0]  R615      -4.4216677546501160e-01
    z[4,0,0]  R616      -3.2980591058731079e-01
    z[4,0,0]  R617      3.8844794034957886e-01
    z[4,0,0]  R618      1.9508582353591919e-01
    z[4,0,0]  R619      1.3773867487907410e-01
    z[4,0,0]  R620      -1.1814265698194504e-01
    z[4,0,0]  R621      7.9213090240955353e-02
    z[4,0,0]  R622      3.9299392700195312e-01
    z[4,0,0]  R623      7.8699356317520142e-01
    z[4,0,0]  R624      -5.1321196556091309e-01
    z[4,0,0]  R625      -1.9562399387359619e-01
    z[4,0,0]  R626      -2.2464221715927124e-01
    z[4,0,0]  R627      -1.3430775701999664e-01
    z[4,0,0]  R628      -3.8461828231811523e-01
    z[4,0,0]  R629      -4.5845183730125427e-01
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R488      -1
    z[4,0,1]  R489      1
    z[4,0,1]  R500      -4.0895906090736389e-01
    z[4,0,1]  R501      -5.5129384994506836e-01
    z[4,0,1]  R502      -5.8258968591690063e-01
    z[4,0,1]  R503      -4.0229967236518860e-01
    z[4,0,1]  R504      -4.1316270828247070e-01
    z[4,0,1]  R505      -4.2161974310874939e-01
    z[4,0,1]  R506      9.1567748785018921e-01
    z[4,0,1]  R507      6.6368746757507324e-01
    z[4,0,1]  R508      7.1862238645553589e-01
    z[4,0,1]  R509      6.2939703464508057e-01
    z[4,0,1]  R510      -3.6118716001510620e-01
    z[4,0,1]  R511      0.643488883972168
    z[4,0,1]  R512      0.761551558971405
    z[4,0,1]  R513      6.5792787075042725e-01
    z[4,0,1]  R514      -3.0341061949729919e-01
    z[4,0,1]  R515      4.7267517447471619e-01
    z[4,0,1]  R516      -1.5194717049598694e-01
    z[4,0,1]  R517      -8.1752061843872070e-02
    z[4,0,1]  R518      -3.1761386990547180e-01
    z[4,0,1]  R519      -2.4149794876575470e-01
    z[4,0,1]  R520      7.0063757896423340e-01
    z[4,0,1]  R521      0.634477436542511
    z[4,0,1]  R522      5.1053810119628906e-01
    z[4,0,1]  R523      6.3336014747619629e-01
    z[4,0,1]  R524      0.571498453617096
    z[4,0,1]  R525      0.624488890171051
    z[4,0,1]  R526      6.8535220623016357e-01
    z[4,0,1]  R527      6.0414552688598633e-01
    z[4,0,1]  R528      0.617192268371582
    z[4,0,1]  R529      4.7669410705566406e-01
    z[4,0,1]  R530      -0.521144449710846
    z[4,0,1]  R531      8.1455355882644653e-01
    z[4,0,1]  R532      6.6145467758178711e-01
    z[4,0,1]  R533      6.5821504592895508e-01
    z[4,0,1]  R534      7.6134026050567627e-01
    z[4,0,1]  R535      6.7953163385391235e-01
    z[4,0,1]  R536      6.7852401733398438e-01
    z[4,0,1]  R537      -2.8339993953704834e-01
    z[4,0,1]  R538      -1.2914204597473145e-01
    z[4,0,1]  R539      -2.7889639139175415e-01
    z[4,0,1]  R540      0.661384105682373
    z[4,0,1]  R541      6.8406271934509277e-01
    z[4,0,1]  R542      0.609142005443573
    z[4,0,1]  R543      6.1185771226882935e-01
    z[4,0,1]  R544      5.1991587877273560e-01
    z[4,0,1]  R545      5.0892251729965210e-01
    z[4,0,1]  R546      6.2008982896804810e-01
    z[4,0,1]  R547      5.8739626407623291e-01
    z[4,0,1]  R548      4.4208192825317383e-01
    z[4,0,1]  R549      -7.5490063428878784e-01
    z[4,0,1]  R550      1.1428605020046234e-01
    z[4,0,1]  R551      -5.4980587959289551e-01
    z[4,0,1]  R552      6.8772667646408081e-01
    z[4,0,1]  R553      5.7774698734283447e-01
    z[4,0,1]  R554      6.1253947019577026e-01
    z[4,0,1]  R555      6.3415187597274780e-01
    z[4,0,1]  R556      7.2337609529495239e-01
    z[4,0,1]  R557      6.5873426198959351e-01
    z[4,0,1]  R558      -3.1618535518646240e-01
    z[4,0,1]  R559      -2.2307717800140381e-01
    z[4,0,1]  R560      0.907846212387085
    z[4,0,1]  R561      7.8116118907928467e-01
    z[4,0,1]  R562      6.5968692302703857e-01
    z[4,0,1]  R563      7.1707624197006226e-01
    z[4,0,1]  R564      5.8574253320693970e-01
    z[4,0,1]  R565      6.7232650518417358e-01
    z[4,0,1]  R566      5.0570577383041382e-01
    z[4,0,1]  R567      -2.2589710354804993e-01
    z[4,0,1]  R568      -6.9680139422416687e-02
    z[4,0,1]  R569      -5.0524167716503143e-02
    z[4,0,1]  R570      -4.7879534959793091e-01
    z[4,0,1]  R571      8.4078276157379150e-01
    z[4,0,1]  R572      8.1807190179824829e-01
    z[4,0,1]  R573      7.6242613792419434e-01
    z[4,0,1]  R574      7.4268090724945068e-01
    z[4,0,1]  R575      7.8609466552734375e-01
    z[4,0,1]  R576      5.7589423656463623e-01
    z[4,0,1]  R577      -2.7718749642372131e-01
    z[4,0,1]  R578      4.0824308991432190e-01
    z[4,0,1]  R579      1.9695796072483063e-01
    z[4,0,1]  R580      -3.7442067265510559e-01
    z[4,0,1]  R581      5.4200363159179688e-01
    z[4,0,1]  R582      -3.6016467213630676e-01
    z[4,0,1]  R583      -1.0555035620927811e-01
    z[4,0,1]  R584      -2.8569099307060242e-01
    z[4,0,1]  R585      7.3532074689865112e-02
    z[4,0,1]  R586      5.3862494230270386e-01
    z[4,0,1]  R587      5.9677477926015854e-02
    z[4,0,1]  R588      1.7477940022945404e-01
    z[4,0,1]  R589      2.8231540322303772e-01
    z[4,0,1]  R590      -4.7570931911468506e-01
    z[4,0,1]  R591      -4.3014129996299744e-01
    z[4,0,1]  R592      -2.8695923089981079e-01
    z[4,0,1]  R593      -5.2187931537628174e-01
    z[4,0,1]  R594      -5.2770727872848511e-01
    z[4,0,1]  R595      -3.2496684789657593e-01
    z[4,0,1]  R596      -4.6004673838615417e-01
    z[4,0,1]  R597      9.7268037497997284e-02
    z[4,0,1]  R598      4.9998548626899719e-01
    z[4,0,1]  R599      4.9960720539093018e-01
    z[4,0,1]  R600      4.1678699851036072e-01
    z[4,0,1]  R601      3.9600458741188049e-01
    z[4,0,1]  R602      4.0015059709548950e-01
    z[4,0,1]  R603      3.0832698941230774e-01
    z[4,0,1]  R604      5.2855193614959717e-02
    z[4,0,1]  R605      4.2598018050193787e-01
    z[4,0,1]  R606      2.2485505044460297e-01
    z[4,0,1]  R607      5.4225105047225952e-01
    z[4,0,1]  R608      0.570558488368988
    z[4,0,1]  R609      4.7694614529609680e-01
    z[4,0,1]  R610      1.1703601479530334e-01
    z[4,0,1]  R611      2.1596144139766693e-01
    z[4,0,1]  R612      5.5512094497680664e-01
    z[4,0,1]  R613      -3.9444932341575623e-01
    z[4,0,1]  R614      -4.9376094341278076e-01
    z[4,0,1]  R615      1.6450468450784683e-02
    z[4,0,1]  R616      2.7394685149192810e-01
    z[4,0,1]  R617      -7.9921215772628784e-01
    z[4,0,1]  R618      -7.0963591337203979e-01
    z[4,0,1]  R619      -7.0107567310333252e-01
    z[4,0,1]  R620      3.4259140491485596e-01
    z[4,0,1]  R621      -4.2591649293899536e-01
    z[4,0,1]  R622      -1.0025259107351303e-02
    z[4,0,1]  R623      -1.4046677947044373e-01
    z[4,0,1]  R624      -0.120124951004982
    z[4,0,1]  R625      5.8132618665695190e-01
    z[4,0,1]  R626      4.9475657939910889e-01
    z[4,0,1]  R627      7.3078292608261108e-01
    z[4,0,1]  R628      -0.00295339897274971
    z[4,0,1]  R629      4.6341851353645325e-02
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R490      -1
    z[4,0,2]  R491      1
    z[4,0,2]  R500      5.2927613258361816e-02
    z[4,0,2]  R501      -3.7967246770858765e-01
    z[4,0,2]  R502      -6.2895250320434570e-01
    z[4,0,2]  R503      -1.4505137503147125e-01
    z[4,0,2]  R504      -3.4477221965789795e-01
    z[4,0,2]  R505      -2.7408489584922791e-01
    z[4,0,2]  R506      -1.8525023758411407e-01
    z[4,0,2]  R507      9.5642521977424622e-02
    z[4,0,2]  R508      7.1118585765361786e-02
    z[4,0,2]  R509      1.3777109980583191e-01
    z[4,0,2]  R510      5.7343918085098267e-01
    z[4,0,2]  R511      3.6670535802841187e-02
    z[4,0,2]  R512      1.3931621611118317e-01
    z[4,0,2]  R513      6.4815413951873779e-01
    z[4,0,2]  R514      -7.3000110685825348e-02
    z[4,0,2]  R515      4.9809610843658447e-01
    z[4,0,2]  R516      2.1548955142498016e-01
    z[4,0,2]  R517      2.7396270632743835e-01
    z[4,0,2]  R518      -1.0538420639932156e-02
    z[4,0,2]  R519      1.9095709919929504e-01
    z[4,0,2]  R520      -1.3599984347820282e-01
    z[4,0,2]  R521      6.3948506116867065e-01
    z[4,0,2]  R522      4.0348327159881592e-01
    z[4,0,2]  R523      -9.1357663273811340e-02
    z[4,0,2]  R524      2.3269453644752502e-01
    z[4,0,2]  R525      2.8954052925109863e-01
    z[4,0,2]  R526      9.3520984053611755e-02
    z[4,0,2]  R527      3.6777067184448242e-01
    z[4,0,2]  R528      4.8150235414505005e-01
    z[4,0,2]  R529      1.8627518415451050e-01
    z[4,0,2]  R530      7.9654440283775330e-02
    z[4,0,2]  R531      -6.9881482049822807e-03
    z[4,0,2]  R532      0.55242520570755
    z[4,0,2]  R533      0.517589807510376
    z[4,0,2]  R534      0.382357656955719
    z[4,0,2]  R535      4.3718099594116211e-01
    z[4,0,2]  R536      1.4393419027328491e-01
    z[4,0,2]  R537      7.7611964941024780e-01
    z[4,0,2]  R538      1.7767506837844849e-01
    z[4,0,2]  R539      4.2432352900505066e-01
    z[4,0,2]  R540      4.7660058736801147e-01
    z[4,0,2]  R541      4.2518422007560730e-01
    z[4,0,2]  R542      7.4195876717567444e-02
    z[4,0,2]  R543      1.4133690297603607e-01
    z[4,0,2]  R544      5.8930929750204086e-02
    z[4,0,2]  R545      -1.5129742026329041e-01
    z[4,0,2]  R546      -6.9181986153125763e-02
    z[4,0,2]  R547      4.6942636370658875e-02
    z[4,0,2]  R548      1.3853174448013306e-01
    z[4,0,2]  R549      4.1284161806106567e-01
    z[4,0,2]  R550      5.5429196357727051e-01
    z[4,0,2]  R551      3.2978755235671997e-01
    z[4,0,2]  R552      2.8025823831558228e-01
    z[4,0,2]  R553      2.6140713691711426e-01
    z[4,0,2]  R554      1.5084272250533104e-02
    z[4,0,2]  R555      -1.9392465054988861e-01
    z[4,0,2]  R556      -9.1017229715362191e-04
    z[4,0,2]  R557      3.2170155644416809e-01
    z[4,0,2]  R558      1.8902434408664703e-01
    z[4,0,2]  R559      7.8653432428836823e-02
    z[4,0,2]  R560      1.3745307922363281e-01
    z[4,0,2]  R561      4.8542514443397522e-01
    z[4,0,2]  R562      2.1271798014640808e-01
    z[4,0,2]  R563      -1.8609980121254921e-02
    z[4,0,2]  R564      1.2843313813209534e-01
    z[4,0,2]  R565      5.8540576696395874e-01
    z[4,0,2]  R566      1.0369451344013214e-01
    z[4,0,2]  R567      1.0151851177215576e-01
    z[4,0,2]  R568      2.9004657268524170e-01
    z[4,0,2]  R569      4.6488952636718750e-01
    z[4,0,2]  R570      1.6060872375965118e-01
    z[4,0,2]  R571      -1.2836912274360657e-01
    z[4,0,2]  R572      2.7374556660652161e-01
    z[4,0,2]  R573      1.6982159018516541e-01
    z[4,0,2]  R574      1.8278861045837402e-01
    z[4,0,2]  R575      4.2374005913734436e-01
    z[4,0,2]  R576      5.0773404538631439e-02
    z[4,0,2]  R577      7.4549637734889984e-02
    z[4,0,2]  R578      -6.2355047464370728e-01
    z[4,0,2]  R579      3.8519951701164246e-01
    z[4,0,2]  R580      4.8653751611709595e-02
    z[4,0,2]  R581      4.1227829456329346e-01
    z[4,0,2]  R582      -1.2187819182872772e-01
    z[4,0,2]  R583      4.1454848647117615e-01
    z[4,0,2]  R584      3.5861104726791382e-01
    z[4,0,2]  R585      3.0075496435165405e-01
    z[4,0,2]  R586      -0.518540620803833
    z[4,0,2]  R587      2.9725831747055054e-01
    z[4,0,2]  R588      3.5120970010757446e-01
    z[4,0,2]  R589      3.8471260666847229e-01
    z[4,0,2]  R590      -2.7751281857490540e-01
    z[4,0,2]  R591      3.2427478581666946e-02
    z[4,0,2]  R592      -2.1592350304126740e-01
    z[4,0,2]  R593      2.3749215900897980e-01
    z[4,0,2]  R594      1.6844940185546875e-01
    z[4,0,2]  R595      -1.6035212576389313e-01
    z[4,0,2]  R596      4.0930435061454773e-02
    z[4,0,2]  R597      -8.3011329174041748e-02
    z[4,0,2]  R598      0.282932847738266
    z[4,0,2]  R599      1.0794003307819366e-01
    z[4,0,2]  R600      5.0963485240936279e-01
    z[4,0,2]  R601      2.9356148838996887e-01
    z[4,0,2]  R602      3.5316619277000427e-01
    z[4,0,2]  R603      2.4036282300949097e-01
    z[4,0,2]  R604      -8.5613265633583069e-02
    z[4,0,2]  R605      4.1041418910026550e-01
    z[4,0,2]  R606      -1.1305548995733261e-01
    z[4,0,2]  R607      -2.3243862390518188e-01
    z[4,0,2]  R608      -4.3270260095596313e-01
    z[4,0,2]  R609      -1.4517985284328461e-01
    z[4,0,2]  R610      2.1311147511005402e-01
    z[4,0,2]  R611      5.4877460002899170e-01
    z[4,0,2]  R612      3.2962255179882050e-02
    z[4,0,2]  R613      -2.2074329853057861e-01
    z[4,0,2]  R614      -4.7355014085769653e-01
    z[4,0,2]  R615      -1.0937143862247467e-01
    z[4,0,2]  R616      1.5144604444503784e-01
    z[4,0,2]  R617      -6.7280530929565430e-02
    z[4,0,2]  R618      2.2395841777324677e-01
    z[4,0,2]  R619      3.5116162896156311e-01
    z[4,0,2]  R620      3.6203429102897644e-01
    z[4,0,2]  R621      -2.9231157898902893e-01
    z[4,0,2]  R622      -4.4138431549072266e-01
    z[4,0,2]  R623      0.106072336435318
    z[4,0,2]  R624      -6.7699514329433441e-02
    z[4,0,2]  R625      -5.5849432945251465e-01
    z[4,0,2]  R626      -3.3190563321113586e-02
    z[4,0,2]  R627      -4.8151548951864243e-02
    z[4,0,2]  R628      -5.4949706792831421e-01
    z[4,0,2]  R629      -3.5029265284538269e-01
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R492      -1
    z[4,0,3]  R493      1
    z[4,0,3]  R500      1.6001372039318085e-01
    z[4,0,3]  R501      2.8818270564079285e-01
    z[4,0,3]  R502      -1.6304506361484528e-01
    z[4,0,3]  R503      3.6362621188163757e-01
    z[4,0,3]  R504      1.2032174319028854e-01
    z[4,0,3]  R505      1.7823085188865662e-01
    z[4,0,3]  R506      -3.5893155727535486e-03
    z[4,0,3]  R507      -3.8156139850616455e-01
    z[4,0,3]  R508      6.0356277227401733e-01
    z[4,0,3]  R509      -2.8164786100387573e-01
    z[4,0,3]  R510      -5.4171049594879150e-01
    z[4,0,3]  R511      1.0718328505754471e-01
    z[4,0,3]  R512      -0.0906682088971138
    z[4,0,3]  R513      -6.5006553195416927e-03
    z[4,0,3]  R514      8.5837788879871368e-02
    z[4,0,3]  R515      2.3907181620597839e-01
    z[4,0,3]  R516      4.7946058213710785e-02
    z[4,0,3]  R517      -3.1040126085281372e-01
    z[4,0,3]  R518      -4.5869520306587219e-01
    z[4,0,3]  R519      -2.3695114254951477e-01
    z[4,0,3]  R520      -0.384262353181839
    z[4,0,3]  R521      0.0794503390789032
    z[4,0,3]  R522      2.3354966938495636e-01
    z[4,0,3]  R523      -3.7225788831710815e-01
    z[4,0,3]  R524      -0.152827650308609
    z[4,0,3]  R525      5.2892103791236877e-02
    z[4,0,3]  R526      4.5519590377807617e-01
    z[4,0,3]  R527      -5.3364926576614380e-01
    z[4,0,3]  R528      -3.1549653410911560e-01
    z[4,0,3]  R529      -5.7637596130371094e-01
    z[4,0,3]  R530      -4.6700218319892883e-01
    z[4,0,3]  R531      1.2275058031082153e-01
    z[4,0,3]  R532      2.8028586506843567e-01
    z[4,0,3]  R533      -2.9184681177139282e-01
    z[4,0,3]  R534      4.9547683447599411e-02
    z[4,0,3]  R535      1.1898304522037506e-01
    z[4,0,3]  R536      1.1744812875986099e-01
    z[4,0,3]  R537      1.3186505995690823e-02
    z[4,0,3]  R538      2.9272291064262390e-01
    z[4,0,3]  R539      -3.4841954708099365e-01
    z[4,0,3]  R540      7.4020475149154663e-02
    z[4,0,3]  R541      -3.4547463059425354e-01
    z[4,0,3]  R542      -2.3175922036170959e-01
    z[4,0,3]  R543      8.8113643229007721e-02
    z[4,0,3]  R544      1.1977697908878326e-01
    z[4,0,3]  R545      -3.4683072566986084e-01
    z[4,0,3]  R546      -6.3989430665969849e-01
    z[4,0,3]  R547      -4.4078847765922546e-01
    z[4,0,3]  R548      -3.9069369435310364e-01
    z[4,0,3]  R549      -1.4880749583244324e-01
    z[4,0,3]  R550      6.0058438777923584e-01
    z[4,0,3]  R551      -4.9394312500953674e-01
    z[4,0,3]  R552      1.3339401781558990e-01
    z[4,0,3]  R553      -3.6142196506261826e-02
    z[4,0,3]  R554      -8.2534685730934143e-02
    z[4,0,3]  R555      -4.1981092095375061e-01
    z[4,0,3]  R556      -1.6490165144205093e-02
    z[4,0,3]  R557      -4.8603683710098267e-01
    z[4,0,3]  R558      -4.1447019577026367e-01
    z[4,0,3]  R559      -1.4740024507045746e-01
    z[4,0,3]  R560      -1.9657707214355469e-01
    z[4,0,3]  R561      1.4049349725246429e-01
    z[4,0,3]  R562      -5.3508497774600983e-02
    z[4,0,3]  R563      -3.9368104934692383e-01
    z[4,0,3]  R564      -4.3956348299980164e-01
    z[4,0,3]  R565      -7.0799507200717926e-02
    z[4,0,3]  R566      -3.5371506214141846e-01
    z[4,0,3]  R567      -8.1046774983406067e-02
    z[4,0,3]  R568      5.0250524654984474e-03
    z[4,0,3]  R569      -1.6853669285774231e-01
    z[4,0,3]  R570      3.2198518514633179e-01
    z[4,0,3]  R571      -3.1587982177734375e-01
    z[4,0,3]  R572      1.2399684637784958e-01
    z[4,0,3]  R573      0.325998991727829
    z[4,0,3]  R574      1.2346013635396957e-01
    z[4,0,3]  R575      1.2125533074140549e-01
    z[4,0,3]  R576      -3.0911889672279358e-01
    z[4,0,3]  R577      -3.4176650643348694e-01
    z[4,0,3]  R578      3.5552024841308594e-01
    z[4,0,3]  R579      4.6924769878387451e-01
    z[4,0,3]  R580      -2.5024303793907166e-01
    z[4,0,3]  R581      -3.3788588643074036e-01
    z[4,0,3]  R582      -3.6288508772850037e-01
    z[4,0,3]  R583      -1.9072756171226501e-01
    z[4,0,3]  R584      -4.1188588738441467e-01
    z[4,0,3]  R585      1.1242207884788513e-01
    z[4,0,3]  R586      5.2938532829284668e-01
    z[4,0,3]  R587      3.5849779844284058e-01
    z[4,0,3]  R588      6.4723688364028931e-01
    z[4,0,3]  R589      4.5425498485565186e-01
    z[4,0,3]  R590      1.9135875999927521e-01
    z[4,0,3]  R591      6.8657793104648590e-02
    z[4,0,3]  R592      3.0188897252082825e-01
    z[4,0,3]  R593      2.8336721658706665e-01
    z[4,0,3]  R594      1.4530107378959656e-01
    z[4,0,3]  R595      4.2767179012298584e-01
    z[4,0,3]  R596      8.2895606756210327e-02
    z[4,0,3]  R597      2.5135058164596558e-01
    z[4,0,3]  R598      -7.1884766221046448e-02
    z[4,0,3]  R599      -9.1833256185054779e-02
    z[4,0,3]  R600      1.5541224181652069e-01
    z[4,0,3]  R601      2.2369624674320221e-01
    z[4,0,3]  R602      4.6875947713851929e-01
    z[4,0,3]  R603      2.9892998933792114e-01
    z[4,0,3]  R604      1.7789126932621002e-01
    z[4,0,3]  R605      0.769805908203125
    z[4,0,3]  R606      5.9138017892837524e-01
    z[4,0,3]  R607      1.6783721745014191e-01
    z[4,0,3]  R608      4.6502524614334106e-01
    z[4,0,3]  R609      6.3687413930892944e-01
    z[4,0,3]  R610      8.1289058923721313e-01
    z[4,0,3]  R611      4.5772558450698853e-01
    z[4,0,3]  R612      2.7774566411972046e-01
    z[4,0,3]  R613      -7.3069196939468384e-01
    z[4,0,3]  R614      -5.3437966108322144e-01
    z[4,0,3]  R615      -7.3799526691436768e-01
    z[4,0,3]  R616      -3.4302836656570435e-01
    z[4,0,3]  R617      2.0139060914516449e-01
    z[4,0,3]  R618      3.0195074155926704e-02
    z[4,0,3]  R619      -2.8804862499237061e-01
    z[4,0,3]  R620      7.4857777357101440e-01
    z[4,0,3]  R621      8.1203043460845947e-01
    z[4,0,3]  R622      6.4871352910995483e-01
    z[4,0,3]  R623      2.7941519021987915e-01
    z[4,0,3]  R624      -0.682442307472229
    z[4,0,3]  R625      2.4517105892300606e-02
    z[4,0,3]  R626      1.1850558966398239e-01
    z[4,0,3]  R627      -1.5918090939521790e-02
    z[4,0,3]  R628      -2.7980056405067444e-01
    z[4,0,3]  R629      -5.4726260900497437e-01
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R494      -1
    z[4,0,4]  R495      1
    z[4,0,4]  R500      -1.1472114175558090e-01
    z[4,0,4]  R501      -1.1252373456954956e-01
    z[4,0,4]  R502      -2.7165785431861877e-02
    z[4,0,4]  R503      -4.0477615594863892e-01
    z[4,0,4]  R504      7.2668421268463135e-01
    z[4,0,4]  R505      6.1354964971542358e-01
    z[4,0,4]  R506      -9.9070511758327484e-02
    z[4,0,4]  R507      0.409146249294281
    z[4,0,4]  R508      -6.6583938896656036e-02
    z[4,0,4]  R509      2.5064873695373535e-01
    z[4,0,4]  R510      1.3133677840232849e-01
    z[4,0,4]  R511      -3.3229254186153412e-02
    z[4,0,4]  R512      -3.2199618220329285e-01
    z[4,0,4]  R513      1.4842495322227478e-01
    z[4,0,4]  R514      -3.7058830261230469e-01
    z[4,0,4]  R515      6.1142629384994507e-01
    z[4,0,4]  R516      -2.3097884654998779e-01
    z[4,0,4]  R517      3.4388538450002670e-02
    z[4,0,4]  R518      -3.0489778518676758e-01
    z[4,0,4]  R519      -0.0886390283703804
    z[4,0,4]  R520      3.1590268015861511e-01
    z[4,0,4]  R521      2.3376764729619026e-03
    z[4,0,4]  R522      3.7073215842247009e-01
    z[4,0,4]  R523      4.4369032979011536e-01
    z[4,0,4]  R524      4.6025916934013367e-01
    z[4,0,4]  R525      3.5726550966501236e-02
    z[4,0,4]  R526      3.6453232169151306e-01
    z[4,0,4]  R527      -3.4587019681930542e-01
    z[4,0,4]  R528      -2.4863809812813997e-03
    z[4,0,4]  R529      -5.2206773310899734e-02
    z[4,0,4]  R530      2.4215477705001831e-01
    z[4,0,4]  R531      1.8904080986976624e-01
    z[4,0,4]  R532      1.5691670775413513e-01
    z[4,0,4]  R533      5.7197425514459610e-02
    z[4,0,4]  R534      -1.7119950056076050e-01
    z[4,0,4]  R535      3.0332329869270325e-01
    z[4,0,4]  R536      -1.3827908039093018e-01
    z[4,0,4]  R537      3.6695733666419983e-01
    z[4,0,4]  R538      -1.0033635795116425e-01
    z[4,0,4]  R539      -3.8435709476470947e-01
    z[4,0,4]  R540      4.3267095088958740e-01
    z[4,0,4]  R541      -2.3215970396995544e-01
    z[4,0,4]  R542      -3.3439084887504578e-01
    z[4,0,4]  R543      -1.2737533450126648e-01
    z[4,0,4]  R544      2.2421942651271820e-01
    z[4,0,4]  R545      -3.1862971186637878e-01
    z[4,0,4]  R546      -1.4161466062068939e-01
    z[4,0,4]  R547      -2.0014038681983948e-01
    z[4,0,4]  R548      -1.7013674974441528e-01
    z[4,0,4]  R549      -2.2357928752899170e-01
    z[4,0,4]  R550      4.8134982585906982e-01
    z[4,0,4]  R551      3.0386200547218323e-01
    z[4,0,4]  R552      5.6228119134902954e-01
    z[4,0,4]  R553      2.6087793707847595e-01
    z[4,0,4]  R554      -1.7765650525689125e-02
    z[4,0,4]  R555      5.7998904958367348e-03
    z[4,0,4]  R556      -1.9561885297298431e-01
    z[4,0,4]  R557      -1.5254600346088409e-01
    z[4,0,4]  R558      -2.3245088756084442e-01
    z[4,0,4]  R559      -2.4510839581489563e-01
    z[4,0,4]  R560      3.4389652311801910e-02
    z[4,0,4]  R561      1.6696244478225708e-01
    z[4,0,4]  R562      3.9626786112785339e-01
    z[4,0,4]  R563      -4.9778923392295837e-02
    z[4,0,4]  R564      1.0410825908184052e-01
    z[4,0,4]  R565      -3.0679020285606384e-01
    z[4,0,4]  R566      2.2262823581695557e-01
    z[4,0,4]  R567      -0.0813310518860817
    z[4,0,4]  R568      9.8297655582427979e-02
    z[4,0,4]  R569      9.0512603521347046e-02
    z[4,0,4]  R570      4.6489360928535461e-01
    z[4,0,4]  R571      -9.3833103775978088e-02
    z[4,0,4]  R572      4.2973878979682922e-01
    z[4,0,4]  R573      3.6662909388542175e-01
    z[4,0,4]  R574      5.0199198722839355e-01
    z[4,0,4]  R575      -4.3391962535679340e-03
    z[4,0,4]  R576      1.9471764564514160e-01
    z[4,0,4]  R577      -2.9023903608322144e-01
    z[4,0,4]  R578      -2.7248394489288330e-01
    z[4,0,4]  R579      -2.4616238474845886e-01
    z[4,0,4]  R580      2.4163340032100677e-01
    z[4,0,4]  R581      -2.2500516474246979e-01
    z[4,0,4]  R582      -1.0002250224351883e-01
    z[4,0,4]  R583      -7.6770171523094177e-02
    z[4,0,4]  R584      -2.0987370610237122e-01
    z[4,0,4]  R585      -1.0867885500192642e-01
    z[4,0,4]  R586      -6.6451430320739746e-02
    z[4,0,4]  R587      -5.7496535778045654e-01
    z[4,0,4]  R588      -4.4193667173385620e-01
    z[4,0,4]  R589      -4.9371123313903809e-01
    z[4,0,4]  R590      -1.3734026253223419e-01
    z[4,0,4]  R591      1.9689242541790009e-01
    z[4,0,4]  R592      -1.7872823402285576e-02
    z[4,0,4]  R593      5.4330664873123169e-01
    z[4,0,4]  R594      2.6512509584426880e-01
    z[4,0,4]  R595      -1.5441097319126129e-01
    z[4,0,4]  R596      6.2950074672698975e-01
    z[4,0,4]  R597      -5.1566797494888306e-01
    z[4,0,4]  R598      -1.8406768143177032e-01
    z[4,0,4]  R599      1.5364494174718857e-02
    z[4,0,4]  R600      1.1874731630086899e-01
    z[4,0,4]  R601      1.5236093103885651e-01
    z[4,0,4]  R602      1.5645581483840942e-01
    z[4,0,4]  R603      5.7624153792858124e-02
    z[4,0,4]  R604      4.5855669304728508e-03
    z[4,0,4]  R605      2.3364938795566559e-01
    z[4,0,4]  R606      1.2672841548919678e-02
    z[4,0,4]  R607      -3.7586815655231476e-02
    z[4,0,4]  R608      4.5307138562202454e-01
    z[4,0,4]  R609      -1.8788692355155945e-01
    z[4,0,4]  R610      3.4083411097526550e-01
    z[4,0,4]  R611      2.6868802309036255e-01
    z[4,0,4]  R612      0.0283999964594841
    z[4,0,4]  R613      -3.1247171759605408e-01
    z[4,0,4]  R614      -1.0955525189638138e-01
    z[4,0,4]  R615      1.6455663368105888e-02
    z[4,0,4]  R616      3.3897200226783752e-01
    z[4,0,4]  R617      -2.9044884443283081e-01
    z[4,0,4]  R618      -5.1221090555191040e-01
    z[4,0,4]  R619      -5.1322090625762939e-01
    z[4,0,4]  R620      0.061478141695261
    z[4,0,4]  R621      2.3901236057281494e-01
    z[4,0,4]  R622      -2.7215710282325745e-01
    z[4,0,4]  R623      3.7062233686447144e-01
    z[4,0,4]  R624      1.1155769973993301e-01
    z[4,0,4]  R625      -4.0102687478065491e-01
    z[4,0,4]  R626      -3.8252141326665878e-02
    z[4,0,4]  R627      4.2325085401535034e-01
    z[4,0,4]  R628      -3.5322535037994385e-01
    z[4,0,4]  R629      -2.2889564931392670e-01
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R496      -1
    z[4,0,5]  R497      1
    z[4,0,5]  R500      3.8111633062362671e-01
    z[4,0,5]  R501      5.5571067333221436e-01
    z[4,0,5]  R502      1.8060798943042755e-01
    z[4,0,5]  R503      -1.1214573681354523e-01
    z[4,0,5]  R504      1.6730263829231262e-01
    z[4,0,5]  R505      5.3711807727813721e-01
    z[4,0,5]  R506      7.2642147541046143e-02
    z[4,0,5]  R507      1.1676761507987976e-01
    z[4,0,5]  R508      -7.5571663677692413e-02
    z[4,0,5]  R509      1.6545480489730835e-01
    z[4,0,5]  R510      -4.1990029811859131e-01
    z[4,0,5]  R511      -6.0991442203521729e-01
    z[4,0,5]  R512      -4.6201825141906738e-01
    z[4,0,5]  R513      0.0101442476734519
    z[4,0,5]  R514      -6.8104475736618042e-02
    z[4,0,5]  R515      -2.8355339169502258e-01
    z[4,0,5]  R516      -7.7083487994968891e-03
    z[4,0,5]  R517      -1.7236265540122986e-01
    z[4,0,5]  R518      -2.4853106588125229e-02
    z[4,0,5]  R519      -8.7030403316020966e-02
    z[4,0,5]  R520      -1.6514272987842560e-01
    z[4,0,5]  R521      -2.5870227813720703e-01
    z[4,0,5]  R522      -4.4403988122940063e-01
    z[4,0,5]  R523      -3.7668019533157349e-01
    z[4,0,5]  R524      -2.0139142870903015e-01
    z[4,0,5]  R525      -7.1815311908721924e-01
    z[4,0,5]  R526      1.2453091889619827e-01
    z[4,0,5]  R527      -2.5025227665901184e-01
    z[4,0,5]  R528      -3.5274305939674377e-01
    z[4,0,5]  R529      -6.1772572994232178e-01
    z[4,0,5]  R530      -6.2005412578582764e-01
    z[4,0,5]  R531      -4.0256899595260620e-01
    z[4,0,5]  R532      3.3030384778976440e-01
    z[4,0,5]  R533      4.0965270996093750e-01
    z[4,0,5]  R534      -4.8622965812683105e-01
    z[4,0,5]  R535      1.9258794188499451e-01
    z[4,0,5]  R536      1.0406956821680069e-01
    z[4,0,5]  R537      8.2377210259437561e-02
    z[4,0,5]  R538      -8.4257304668426514e-02
    z[4,0,5]  R539      3.9063131809234619e-01
    z[4,0,5]  R540      1.0816441476345062e-01
    z[4,0,5]  R541      0.349244624376297
    z[4,0,5]  R542      -3.9362901449203491e-01
    z[4,0,5]  R543      -5.9012597799301147e-01
    z[4,0,5]  R544      -7.8150975704193115e-01
    z[4,0,5]  R545      -6.7393243312835693e-01
    z[4,0,5]  R546      -2.3224505782127380e-01
    z[4,0,5]  R547      -6.3647961616516113e-01
    z[4,0,5]  R548      -6.0548824071884155e-01
    z[4,0,5]  R549      -1.4366070926189423e-01
    z[4,0,5]  R550      4.4098678976297379e-02
    z[4,0,5]  R551      -4.5739594101905823e-01
    z[4,0,5]  R552      1.4385650865733624e-02
    z[4,0,5]  R553      -5.9956979751586914e-01
    z[4,0,5]  R554      -6.7116081714630127e-01
    z[4,0,5]  R555      -5.8865559101104736e-01
    z[4,0,5]  R556      -1.8110229074954987e-01
    z[4,0,5]  R557      -1.0773810744285583e-01
    z[4,0,5]  R558      2.6756206154823303e-01
    z[4,0,5]  R559      1.8646885454654694e-01
    z[4,0,5]  R560      -5.6428488343954086e-02
    z[4,0,5]  R561      2.0217919349670410e-01
    z[4,0,5]  R562      -3.9791306853294373e-01
    z[4,0,5]  R563      -5.7171505689620972e-01
    z[4,0,5]  R564      -3.4493902325630188e-01
    z[4,0,5]  R565      7.1420714259147644e-02
    z[4,0,5]  R566      3.5805463790893555e-01
    z[4,0,5]  R567      -1.9722411036491394e-01
    z[4,0,5]  R568      -1.6521330177783966e-01
    z[4,0,5]  R569      -5.1570698618888855e-02
    z[4,0,5]  R570      2.0275006070733070e-02
    z[4,0,5]  R571      -3.8745424151420593e-01
    z[4,0,5]  R572      -1.4860782027244568e-01
    z[4,0,5]  R573      -2.1801829338073730e-01
    z[4,0,5]  R574      2.8767675161361694e-01
    z[4,0,5]  R575      -4.2009210586547852e-01
    z[4,0,5]  R576      3.5468569397926331e-01
    z[4,0,5]  R577      2.0468638837337494e-01
    z[4,0,5]  R578      1.5067258477210999e-01
    z[4,0,5]  R579      -2.4595342576503754e-02
    z[4,0,5]  R580      -8.1414008140563965e-01
    z[4,0,5]  R581      0.0750207006931305
    z[4,0,5]  R582      -0.131648451089859
    z[4,0,5]  R583      1.3997261226177216e-01
    z[4,0,5]  R584      2.8227525949478149e-01
    z[4,0,5]  R585      1.3914388418197632e-01
    z[4,0,5]  R586      1.4618138968944550e-01
    z[4,0,5]  R587      -1.0838557034730911e-01
    z[4,0,5]  R588      -1.1386824399232864e-01
    z[4,0,5]  R589      1.1800454556941986e-01
    z[4,0,5]  R590      6.4809662103652954e-01
    z[4,0,5]  R591      5.0592297315597534e-01
    z[4,0,5]  R592      2.8670877218246460e-01
    z[4,0,5]  R593      4.8585128784179688e-01
    z[4,0,5]  R594      6.3074672222137451e-01
    z[4,0,5]  R595      1.6453932970762253e-02
    z[4,0,5]  R596      3.2417336106300354e-01
    z[4,0,5]  R597      0.781249463558197
    z[4,0,5]  R598      9.1276556253433228e-02
    z[4,0,5]  R599      -2.5241073966026306e-01
    z[4,0,5]  R600      4.1232284158468246e-02
    z[4,0,5]  R601      4.1825573891401291e-02
    z[4,0,5]  R602      -2.2501009702682495e-01
    z[4,0,5]  R603      -2.1672993898391724e-01
    z[4,0,5]  R604      1.8610468506813049e-01
    z[4,0,5]  R605      -6.4693358726799488e-03
    z[4,0,5]  R606      -2.6729911565780640e-01
    z[4,0,5]  R607      4.4847447425127029e-02
    z[4,0,5]  R608      1.5220044553279877e-01
    z[4,0,5]  R609      -4.5384258031845093e-01
    z[4,0,5]  R610      1.6075240075588226e-01
    z[4,0,5]  R611      -1.6099143773317337e-02
    z[4,0,5]  R612      -4.0589755773544312e-01
    z[4,0,5]  R613      -2.6492691040039062e-01
    z[4,0,5]  R614      -4.0279945731163025e-01
    z[4,0,5]  R615      -2.4074497818946838e-01
    z[4,0,5]  R616      -4.8913535475730896e-01
    z[4,0,5]  R617      -2.5961726903915405e-01
    z[4,0,5]  R618      -1.9433766603469849e-01
    z[4,0,5]  R619      -1.1268361657857895e-01
    z[4,0,5]  R620      4.0919068455696106e-01
    z[4,0,5]  R621      5.9867627918720245e-02
    z[4,0,5]  R622      1.3973297178745270e-01
    z[4,0,5]  R623      2.2402912378311157e-01
    z[4,0,5]  R624      -2.6954427361488342e-01
    z[4,0,5]  R625      -1.1689981073141098e-01
    z[4,0,5]  R626      -1.0135784000158310e-01
    z[4,0,5]  R627      -9.9021323025226593e-02
    z[4,0,5]  R628      -4.6825075149536133e-01
    z[4,0,5]  R629      -4.3617191910743713e-01
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R498      -1
    z[4,0,6]  R499      1
    z[4,0,6]  R500      2.7287659049034119e-01
    z[4,0,6]  R501      -8.6940238252282143e-03
    z[4,0,6]  R502      3.3845886588096619e-01
    z[4,0,6]  R503      -5.6192469596862793e-01
    z[4,0,6]  R504      3.7011390924453735e-01
    z[4,0,6]  R505      9.6734218299388885e-02
    z[4,0,6]  R506      2.8947748243808746e-02
    z[4,0,6]  R507      8.4491841495037079e-02
    z[4,0,6]  R508      -2.7116268873214722e-01
    z[4,0,6]  R509      5.5536723136901855e-01
    z[4,0,6]  R510      -1.0864780098199844e-01
    z[4,0,6]  R511      -3.1635737419128418e-01
    z[4,0,6]  R512      2.7368339896202087e-01
    z[4,0,6]  R513      -6.4924255013465881e-02
    z[4,0,6]  R514      1.6080971807241440e-02
    z[4,0,6]  R515      1.1388626694679260e-01
    z[4,0,6]  R516      -1.1335127800703049e-01
    z[4,0,6]  R517      6.2742494046688080e-02
    z[4,0,6]  R518      8.7315574288368225e-02
    z[4,0,6]  R519      -4.3224021792411804e-01
    z[4,0,6]  R520      4.6385556459426880e-01
    z[4,0,6]  R521      1.3388817012310028e-01
    z[4,0,6]  R522      -1.0406203567981720e-01
    z[4,0,6]  R523      -3.2532370090484619e-01
    z[4,0,6]  R524      -5.8396351337432861e-01
    z[4,0,6]  R525      -6.0750752687454224e-02
    z[4,0,6]  R526      3.7941977381706238e-01
    z[4,0,6]  R527      -8.0928064882755280e-02
    z[4,0,6]  R528      -3.2811298966407776e-01
    z[4,0,6]  R529      5.3886175155639648e-03
    z[4,0,6]  R530      -2.4670192599296570e-01
    z[4,0,6]  R531      1.5145288407802582e-01
    z[4,0,6]  R532      -1.2451510876417160e-01
    z[4,0,6]  R533      1.9450066983699799e-01
    z[4,0,6]  R534      5.6221973150968552e-02
    z[4,0,6]  R535      4.0203872323036194e-01
    z[4,0,6]  R536      -6.0775661468505859e-01
    z[4,0,6]  R537      -4.1605624556541443e-01
    z[4,0,6]  R538      -2.0083867013454437e-02
    z[4,0,6]  R539      -4.1355829685926437e-02
    z[4,0,6]  R540      0.169141948223114
    z[4,0,6]  R541      -2.3644529283046722e-01
    z[4,0,6]  R542      -5.4670977592468262e-01
    z[4,0,6]  R543      -4.8036286234855652e-01
    z[4,0,6]  R544      -1.3549636304378510e-01
    z[4,0,6]  R545      1.3533039391040802e-01
    z[4,0,6]  R546      -3.3536779880523682e-01
    z[4,0,6]  R547      -7.4160680174827576e-02
    z[4,0,6]  R548      3.9604222774505615e-01
    z[4,0,6]  R549      8.2372479140758514e-02
    z[4,0,6]  R550      -2.0938409864902496e-01
    z[4,0,6]  R551      -9.9131613969802856e-02
    z[4,0,6]  R552      -1.5620626509189606e-01
    z[4,0,6]  R553      -3.5751909017562866e-02
    z[4,0,6]  R554      3.4721937775611877e-01
    z[4,0,6]  R555      -1.6696329414844513e-01
    z[4,0,6]  R556      -5.4487246274948120e-01
    z[4,0,6]  R557      2.4621315300464630e-01
    z[4,0,6]  R558      -2.9758375883102417e-01
    z[4,0,6]  R559      -3.2744112610816956e-01
    z[4,0,6]  R560      -1.3781943917274475e-01
    z[4,0,6]  R561      1.9308337569236755e-01
    z[4,0,6]  R562      -4.1964939236640930e-01
    z[4,0,6]  R563      -3.2751351594924927e-02
    z[4,0,6]  R564      4.0953123569488525e-01
    z[4,0,6]  R565      -2.7584463357925415e-01
    z[4,0,6]  R566      -6.4742863178253174e-01
    z[4,0,6]  R567      -1.5823251008987427e-01
    z[4,0,6]  R568      1.8326042592525482e-01
    z[4,0,6]  R569      8.2990802824497223e-02
    z[4,0,6]  R570      -6.4104783535003662e-01
    z[4,0,6]  R571      -7.6623722910881042e-02
    z[4,0,6]  R572      -1.5886804461479187e-01
    z[4,0,6]  R573      2.6446020603179932e-01
    z[4,0,6]  R574      -4.7957371920347214e-02
    z[4,0,6]  R575      1.0231915861368179e-01
    z[4,0,6]  R576      -6.3529020547866821e-01
    z[4,0,6]  R577      -2.9536217451095581e-01
    z[4,0,6]  R578      -1.2536510825157166e-01
    z[4,0,6]  R579      -2.9091672971844673e-02
    z[4,0,6]  R580      -2.2160361707210541e-01
    z[4,0,6]  R581      -4.0055537223815918e-01
    z[4,0,6]  R582      -0.0674145370721817
    z[4,0,6]  R583      7.8882798552513123e-02
    z[4,0,6]  R584      3.0971509218215942e-01
    z[4,0,6]  R585      2.9696798324584961e-01
    z[4,0,6]  R586      1.4758327975869179e-02
    z[4,0,6]  R587      2.4358795583248138e-01
    z[4,0,6]  R588      1.0696541517972946e-01
    z[4,0,6]  R589      3.1952759623527527e-01
    z[4,0,6]  R590      -6.0252517461776733e-02
    z[4,0,6]  R591      -1.3458128273487091e-01
    z[4,0,6]  R592      3.9626464247703552e-02
    z[4,0,6]  R593      -2.1730247139930725e-01
    z[4,0,6]  R594      -4.3661540746688843e-01
    z[4,0,6]  R595      -7.1414500474929810e-01
    z[4,0,6]  R596      5.0165539979934692e-01
    z[4,0,6]  R597      -9.1163434088230133e-02
    z[4,0,6]  R598      -2.1482041478157043e-01
    z[4,0,6]  R599      -3.5165694355964661e-01
    z[4,0,6]  R600      -2.2796644270420074e-01
    z[4,0,6]  R601      3.0177685618400574e-01
    z[4,0,6]  R602      -1.5494552254676819e-01
    z[4,0,6]  R603      -1.7243444919586182e-01
    z[4,0,6]  R604      4.1394731402397156e-01
    z[4,0,6]  R605      -4.4765327125787735e-02
    z[4,0,6]  R606      2.7599847316741943e-01
    z[4,0,6]  R607      7.7921295166015625e-01
    z[4,0,6]  R608      -1.3724772632122040e-01
    z[4,0,6]  R609      2.5424492359161377e-01
    z[4,0,6]  R610      1.8255215883255005e-01
    z[4,0,6]  R611      -5.9460711479187012e-01
    z[4,0,6]  R612      5.8936983346939087e-01
    z[4,0,6]  R613      1.0386855900287628e-01
    z[4,0,6]  R614      -1.2658125162124634e-01
    z[4,0,6]  R615      0.435189425945282
    z[4,0,6]  R616      5.6694036722183228e-01
    z[4,0,6]  R617      1.1628223955631256e-01
    z[4,0,6]  R618      3.2735636830329895e-01
    z[4,0,6]  R619      8.4505289793014526e-02
    z[4,0,6]  R620      -0.0775846540927887
    z[4,0,6]  R621      8.2278758287429810e-02
    z[4,0,6]  R622      3.6906811594963074e-01
    z[4,0,6]  R623      2.8988981246948242e-01
    z[4,0,6]  R624      4.0837913751602173e-01
    z[4,0,6]  R625      3.6984574794769287e-01
    z[4,0,6]  R626      8.2332855463027954e-01
    z[4,0,6]  R627      5.0635886192321777e-01
    z[4,0,6]  R628      3.5748815536499023e-01
    z[4,0,6]  R629      3.5047656297683716e-01
    z[0,5,0]  R2        -1
    z[0,5,0]  R47       1
    z[0,5,0]  R630      -1
    z[0,5,0]  R631      1
    z[0,5,0]  R644      -4.6641939878463745e-01
    z[0,5,0]  R645      -7.0453971624374390e-01
    z[0,5,0]  R646      -8.3414804935455322e-01
    z[0,5,0]  R647      1.1175207793712616e-01
    z[0,5,0]  R648      1.1520291864871979e-01
    z[0,5,0]  R649      -3.8944080471992493e-01
    z[0,5,0]  R650      -1.6368374228477478e-01
    z[0,5,0]  R651      1.8946231901645660e-01
    z[0,5,0]  R652      -7.5923389196395874e-01
    z[0,5,0]  R653      -7.3668062686920166e-01
    z[0,5,0]  R654      6.8893986940383911e-01
    z[0,5,0]  R655      7.6871931552886963e-01
    z[0,5,0]  R656      6.2952494621276855e-01
    z[0,5,0]  R657      8.2327091693878174e-01
    z[0,5,0]  R658      8.6730796098709106e-01
    z[0,5,0]  R659      -2.9360942542552948e-02
    z[0,5,0]  R660      6.6267901659011841e-01
    z[0,5,0]  R661      -1.1476036906242371e-01
    z[0,5,0]  R662      1.5397189557552338e-01
    z[0,5,0]  R663      -1.9980345666408539e-01
    z[0,5,0]  R664      3.2366719841957092e-01
    z[0,5,0]  R665      1.2916807830333710e-01
    z[0,5,0]  R666      -3.1732532382011414e-01
    z[0,5,0]  R667      -2.8837111592292786e-01
    z[0,5,0]  R668      -2.3688845336437225e-01
    z[0,5,0]  R669      -4.4216677546501160e-01
    z[0,5,0]  R670      -3.2980591058731079e-01
    z[0,5,0]  R671      3.8844794034957886e-01
    z[0,5,0]  R672      1.9508582353591919e-01
    z[0,5,0]  R673      1.3773867487907410e-01
    z[0,5,0]  R674      -1.1814265698194504e-01
    z[0,5,0]  R675      7.9213090240955353e-02
    z[0,5,0]  R676      3.9299392700195312e-01
    z[0,5,0]  R677      7.8699356317520142e-01
    z[0,5,0]  R678      -5.1321196556091309e-01
    z[0,5,0]  R679      -1.9562399387359619e-01
    z[0,5,0]  R680      -2.2464221715927124e-01
    z[0,5,0]  R681      -1.3430775701999664e-01
    z[0,5,0]  R682      -3.8461828231811523e-01
    z[0,5,0]  R683      -4.5845183730125427e-01
    z[0,5,0]  R684      -2.6823753118515015e-01
    z[0,5,0]  R685      -6.5219156444072723e-02
    z[0,5,0]  R686      -2.8410360217094421e-01
    z[0,5,0]  R687      -4.4057813286781311e-01
    z[0,5,0]  R688      -1.4141286909580231e-01
    z[0,5,0]  R689      6.6742408275604248e-01
    z[0,5,0]  R690      7.5001978874206543e-01
    z[0,5,0]  R691      1.8080644309520721e-01
    z[0,5,0]  R692      4.8582616448402405e-01
    z[0,5,0]  R693      4.6337318420410156e-01
    z[0,5,0]  R694      -3.2918116450309753e-01
    z[0,5,0]  R695      -5.2980142831802368e-01
    z[0,5,0]  R696      1.3590514659881592e-01
    z[0,5,0]  R697      1.8562240898609161e-01
    z[0,5,0]  R698      1.7441925406455994e-01
    z[0,5,0]  R699      -9.4519846141338348e-02
    z[0,5,0]  R700      4.6904768794775009e-02
    z[0,5,0]  R701      -5.8192804455757141e-02
    z[0,5,0]  R702      1.9962343573570251e-01
    z[0,5,0]  R703      -0.294490784406662
    z[0,5,1]  R3        -1
    z[0,5,1]  R48       1
    z[0,5,1]  R632      -1
    z[0,5,1]  R633      1
    z[0,5,1]  R644      -4.7570931911468506e-01
    z[0,5,1]  R645      -4.3014129996299744e-01
    z[0,5,1]  R646      -2.8695923089981079e-01
    z[0,5,1]  R647      -5.2187931537628174e-01
    z[0,5,1]  R648      -5.2770727872848511e-01
    z[0,5,1]  R649      -3.2496684789657593e-01
    z[0,5,1]  R650      -4.6004673838615417e-01
    z[0,5,1]  R651      9.7268037497997284e-02
    z[0,5,1]  R652      4.9998548626899719e-01
    z[0,5,1]  R653      4.9960720539093018e-01
    z[0,5,1]  R654      4.1678699851036072e-01
    z[0,5,1]  R655      3.9600458741188049e-01
    z[0,5,1]  R656      4.0015059709548950e-01
    z[0,5,1]  R657      3.0832698941230774e-01
    z[0,5,1]  R658      5.2855193614959717e-02
    z[0,5,1]  R659      4.2598018050193787e-01
    z[0,5,1]  R660      2.2485505044460297e-01
    z[0,5,1]  R661      5.4225105047225952e-01
    z[0,5,1]  R662      0.570558488368988
    z[0,5,1]  R663      4.7694614529609680e-01
    z[0,5,1]  R664      1.1703601479530334e-01
    z[0,5,1]  R665      2.1596144139766693e-01
    z[0,5,1]  R666      5.5512094497680664e-01
    z[0,5,1]  R667      -3.9444932341575623e-01
    z[0,5,1]  R668      -4.9376094341278076e-01
    z[0,5,1]  R669      1.6450468450784683e-02
    z[0,5,1]  R670      2.7394685149192810e-01
    z[0,5,1]  R671      -7.9921215772628784e-01
    z[0,5,1]  R672      -7.0963591337203979e-01
    z[0,5,1]  R673      -7.0107567310333252e-01
    z[0,5,1]  R674      3.4259140491485596e-01
    z[0,5,1]  R675      -4.2591649293899536e-01
    z[0,5,1]  R676      -1.0025259107351303e-02
    z[0,5,1]  R677      -1.4046677947044373e-01
    z[0,5,1]  R678      -0.120124951004982
    z[0,5,1]  R679      5.8132618665695190e-01
    z[0,5,1]  R680      4.9475657939910889e-01
    z[0,5,1]  R681      7.3078292608261108e-01
    z[0,5,1]  R682      -0.00295339897274971
    z[0,5,1]  R683      4.6341851353645325e-02
    z[0,5,1]  R684      2.4573600292205811e-01
    z[0,5,1]  R685      3.6279591917991638e-01
    z[0,5,1]  R686      -6.1442929506301880e-01
    z[0,5,1]  R687      2.6527587324380875e-02
    z[0,5,1]  R688      -3.9439103007316589e-01
    z[0,5,1]  R689      3.2276561856269836e-01
    z[0,5,1]  R690      4.2350569367408752e-01
    z[0,5,1]  R691      1.2853574752807617e-01
    z[0,5,1]  R692      5.3194683790206909e-01
    z[0,5,1]  R693      5.1429039239883423e-01
    z[0,5,1]  R694      3.9422520995140076e-01
    z[0,5,1]  R695      2.7047321200370789e-01
    z[0,5,1]  R696      -7.6316612958908081e-01
    z[0,5,1]  R697      -7.5528490543365479e-01
    z[0,5,1]  R698      -7.9375445842742920e-01
    z[0,5,1]  R699      -6.4786761999130249e-01
    z[0,5,1]  R700      -7.3607826232910156e-01
    z[0,5,1]  R701      -7.1364831924438477e-01
    z[0,5,1]  R702      -7.4419844150543213e-01
    z[0,5,1]  R703      -6.3241493701934814e-01
    z[0,5,2]  R4        -1
    z[0,5,2]  R49       1
    z[0,5,2]  R634      -1
    z[0,5,2]  R635      1
    z[0,5,2]  R644      -2.7751281857490540e-01
    z[0,5,2]  R645      3.2427478581666946e-02
    z[0,5,2]  R646      -2.1592350304126740e-01
    z[0,5,2]  R647      2.3749215900897980e-01
    z[0,5,2]  R648      1.6844940185546875e-01
    z[0,5,2]  R649      -1.6035212576389313e-01
    z[0,5,2]  R650      4.0930435061454773e-02
    z[0,5,2]  R651      -8.3011329174041748e-02
    z[0,5,2]  R652      0.282932847738266
    z[0,5,2]  R653      1.0794003307819366e-01
    z[0,5,2]  R654      5.0963485240936279e-01
    z[0,5,2]  R655      2.9356148838996887e-01
    z[0,5,2]  R656      3.5316619277000427e-01
    z[0,5,2]  R657      2.4036282300949097e-01
    z[0,5,2]  R658      -8.5613265633583069e-02
    z[0,5,2]  R659      4.1041418910026550e-01
    z[0,5,2]  R660      -1.1305548995733261e-01
    z[0,5,2]  R661      -2.3243862390518188e-01
    z[0,5,2]  R662      -4.3270260095596313e-01
    z[0,5,2]  R663      -1.4517985284328461e-01
    z[0,5,2]  R664      2.1311147511005402e-01
    z[0,5,2]  R665      5.4877460002899170e-01
    z[0,5,2]  R666      3.2962255179882050e-02
    z[0,5,2]  R667      -2.2074329853057861e-01
    z[0,5,2]  R668      -4.7355014085769653e-01
    z[0,5,2]  R669      -1.0937143862247467e-01
    z[0,5,2]  R670      1.5144604444503784e-01
    z[0,5,2]  R671      -6.7280530929565430e-02
    z[0,5,2]  R672      2.2395841777324677e-01
    z[0,5,2]  R673      3.5116162896156311e-01
    z[0,5,2]  R674      3.6203429102897644e-01
    z[0,5,2]  R675      -2.9231157898902893e-01
    z[0,5,2]  R676      -4.4138431549072266e-01
    z[0,5,2]  R677      0.106072336435318
    z[0,5,2]  R678      -6.7699514329433441e-02
    z[0,5,2]  R679      -5.5849432945251465e-01
    z[0,5,2]  R680      -3.3190563321113586e-02
    z[0,5,2]  R681      -4.8151548951864243e-02
    z[0,5,2]  R682      -5.4949706792831421e-01
    z[0,5,2]  R683      -3.5029265284538269e-01
    z[0,5,2]  R684      -3.1426379084587097e-01
    z[0,5,2]  R685      -3.8013070821762085e-01
    z[0,5,2]  R686      -2.6275274157524109e-01
    z[0,5,2]  R687      1.3911771774291992e-01
    z[0,5,2]  R688      -4.1727340221405029e-01
    z[0,5,2]  R689      -2.8148925304412842e-01
    z[0,5,2]  R690      -1.5927772223949432e-01
    z[0,5,2]  R691      3.7788701057434082e-01
    z[0,5,2]  R692      2.7874574065208435e-01
    z[0,5,2]  R693      -6.0055539011955261e-02
    z[0,5,2]  R694      6.1995659023523331e-02
    z[0,5,2]  R695      0.241798996925354
    z[0,5,2]  R696      0.273393839597702
    z[0,5,2]  R697      1.4513716101646423e-01
    z[0,5,2]  R698      2.1221699193120003e-02
    z[0,5,2]  R699      1.7214192450046539e-01
    z[0,5,2]  R700      2.2800672054290771e-01
    z[0,5,2]  R701      2.6251357793807983e-01
    z[0,5,2]  R702      1.3650007545948029e-01
    z[0,5,2]  R703      2.9738715291023254e-01
    z[0,5,3]  R5        -1
    z[0,5,3]  R50       1
    z[0,5,3]  R636      -1
    z[0,5,3]  R637      1
    z[0,5,3]  R644      1.9135875999927521e-01
    z[0,5,3]  R645      6.8657793104648590e-02
    z[0,5,3]  R646      3.0188897252082825e-01
    z[0,5,3]  R647      2.8336721658706665e-01
    z[0,5,3]  R648      1.4530107378959656e-01
    z[0,5,3]  R649      4.2767179012298584e-01
    z[0,5,3]  R650      8.2895606756210327e-02
    z[0,5,3]  R651      2.5135058164596558e-01
    z[0,5,3]  R652      -7.1884766221046448e-02
    z[0,5,3]  R653      -9.1833256185054779e-02
    z[0,5,3]  R654      1.5541224181652069e-01
    z[0,5,3]  R655      2.2369624674320221e-01
    z[0,5,3]  R656      4.6875947713851929e-01
    z[0,5,3]  R657      2.9892998933792114e-01
    z[0,5,3]  R658      1.7789126932621002e-01
    z[0,5,3]  R659      0.769805908203125
    z[0,5,3]  R660      5.9138017892837524e-01
    z[0,5,3]  R661      1.6783721745014191e-01
    z[0,5,3]  R662      4.6502524614334106e-01
    z[0,5,3]  R663      6.3687413930892944e-01
    z[0,5,3]  R664      8.1289058923721313e-01
    z[0,5,3]  R665      4.5772558450698853e-01
    z[0,5,3]  R666      2.7774566411972046e-01
    z[0,5,3]  R667      -7.3069196939468384e-01
    z[0,5,3]  R668      -5.3437966108322144e-01
    z[0,5,3]  R669      -7.3799526691436768e-01
    z[0,5,3]  R670      -3.4302836656570435e-01
    z[0,5,3]  R671      2.0139060914516449e-01
    z[0,5,3]  R672      3.0195074155926704e-02
    z[0,5,3]  R673      -2.8804862499237061e-01
    z[0,5,3]  R674      7.4857777357101440e-01
    z[0,5,3]  R675      8.1203043460845947e-01
    z[0,5,3]  R676      6.4871352910995483e-01
    z[0,5,3]  R677      2.7941519021987915e-01
    z[0,5,3]  R678      -0.682442307472229
    z[0,5,3]  R679      2.4517105892300606e-02
    z[0,5,3]  R680      1.1850558966398239e-01
    z[0,5,3]  R681      -1.5918090939521790e-02
    z[0,5,3]  R682      -2.7980056405067444e-01
    z[0,5,3]  R683      -5.4726260900497437e-01
    z[0,5,3]  R684      -5.9839230775833130e-01
    z[0,5,3]  R685      -5.6734341382980347e-01
    z[0,5,3]  R686      -5.5254191160202026e-01
    z[0,5,3]  R687      -0.86295485496521
    z[0,5,3]  R688      5.8465588837862015e-02
    z[0,5,3]  R689      5.6408715248107910e-01
    z[0,5,3]  R690      1.9337294995784760e-01
    z[0,5,3]  R691      7.1931129693984985e-01
    z[0,5,3]  R692      1.1560782790184021e-01
    z[0,5,3]  R693      2.3387832939624786e-01
    z[0,5,3]  R694      0.283197283744812
    z[0,5,3]  R695      3.9575561881065369e-01
    z[0,5,3]  R696      2.7132576704025269e-01
    z[0,5,3]  R697      3.9909040927886963e-01
    z[0,5,3]  R698      4.2910179495811462e-01
    z[0,5,3]  R699      4.4801110029220581e-01
    z[0,5,3]  R700      3.9648792147636414e-01
    z[0,5,3]  R701      2.7338972687721252e-01
    z[0,5,3]  R702      1.7293485999107361e-01
    z[0,5,3]  R703      4.2913112044334412e-01
    z[0,5,4]  R6        -1
    z[0,5,4]  R51       1
    z[0,5,4]  R638      -1
    z[0,5,4]  R639      1
    z[0,5,4]  R644      -1.3734026253223419e-01
    z[0,5,4]  R645      1.9689242541790009e-01
    z[0,5,4]  R646      -1.7872823402285576e-02
    z[0,5,4]  R647      5.4330664873123169e-01
    z[0,5,4]  R648      2.6512509584426880e-01
    z[0,5,4]  R649      -1.5441097319126129e-01
    z[0,5,4]  R650      6.2950074672698975e-01
    z[0,5,4]  R651      -5.1566797494888306e-01
    z[0,5,4]  R652      -1.8406768143177032e-01
    z[0,5,4]  R653      1.5364494174718857e-02
    z[0,5,4]  R654      1.1874731630086899e-01
    z[0,5,4]  R655      1.5236093103885651e-01
    z[0,5,4]  R656      1.5645581483840942e-01
    z[0,5,4]  R657      5.7624153792858124e-02
    z[0,5,4]  R658      4.5855669304728508e-03
    z[0,5,4]  R659      2.3364938795566559e-01
    z[0,5,4]  R660      1.2672841548919678e-02
    z[0,5,4]  R661      -3.7586815655231476e-02
    z[0,5,4]  R662      4.5307138562202454e-01
    z[0,5,4]  R663      -1.8788692355155945e-01
    z[0,5,4]  R664      3.4083411097526550e-01
    z[0,5,4]  R665      2.6868802309036255e-01
    z[0,5,4]  R666      0.0283999964594841
    z[0,5,4]  R667      -3.1247171759605408e-01
    z[0,5,4]  R668      -1.0955525189638138e-01
    z[0,5,4]  R669      1.6455663368105888e-02
    z[0,5,4]  R670      3.3897200226783752e-01
    z[0,5,4]  R671      -2.9044884443283081e-01
    z[0,5,4]  R672      -5.1221090555191040e-01
    z[0,5,4]  R673      -5.1322090625762939e-01
    z[0,5,4]  R674      0.061478141695261
    z[0,5,4]  R675      2.3901236057281494e-01
    z[0,5,4]  R676      -2.7215710282325745e-01
    z[0,5,4]  R677      3.7062233686447144e-01
    z[0,5,4]  R678      1.1155769973993301e-01
    z[0,5,4]  R679      -4.0102687478065491e-01
    z[0,5,4]  R680      -3.8252141326665878e-02
    z[0,5,4]  R681      4.2325085401535034e-01
    z[0,5,4]  R682      -3.5322535037994385e-01
    z[0,5,4]  R683      -2.2889564931392670e-01
    z[0,5,4]  R684      3.9711022377014160e-01
    z[0,5,4]  R685      -2.5315082073211670e-01
    z[0,5,4]  R686      -2.7344502508640289e-02
    z[0,5,4]  R687      -1.8611754477024078e-01
    z[0,5,4]  R688      -2.6278665661811829e-01
    z[0,5,4]  R689      2.2017116844654083e-01
    z[0,5,4]  R690      1.1359731853008270e-01
    z[0,5,4]  R691      -1.1853111535310745e-01
    z[0,5,4]  R692      0.072480209171772
    z[0,5,4]  R693      5.2598720788955688e-01
    z[0,5,4]  R694      -5.6802171468734741e-01
    z[0,5,4]  R695      -3.4810966253280640e-01
    z[0,5,4]  R696      -1.0453492403030396e-01
    z[0,5,4]  R697      -1.2242580950260162e-01
    z[0,5,4]  R698      2.1998232230544090e-02
    z[0,5,4]  R699      -3.9168462157249451e-01
    z[0,5,4]  R700      1.8533350527286530e-01
    z[0,5,4]  R701      1.9919458031654358e-01
    z[0,5,4]  R702      -9.9543638527393341e-02
    z[0,5,4]  R703      3.2287046313285828e-02
    z[0,5,5]  R7        -1
    z[0,5,5]  R52       1
    z[0,5,5]  R640      -1
    z[0,5,5]  R641      1
    z[0,5,5]  R644      6.4809662103652954e-01
    z[0,5,5]  R645      5.0592297315597534e-01
    z[0,5,5]  R646      2.8670877218246460e-01
    z[0,5,5]  R647      4.8585128784179688e-01
    z[0,5,5]  R648      6.3074672222137451e-01
    z[0,5,5]  R649      1.6453932970762253e-02
    z[0,5,5]  R650      3.2417336106300354e-01
    z[0,5,5]  R651      0.781249463558197
    z[0,5,5]  R652      9.1276556253433228e-02
    z[0,5,5]  R653      -2.5241073966026306e-01
    z[0,5,5]  R654      4.1232284158468246e-02
    z[0,5,5]  R655      4.1825573891401291e-02
    z[0,5,5]  R656      -2.2501009702682495e-01
    z[0,5,5]  R657      -2.1672993898391724e-01
    z[0,5,5]  R658      1.8610468506813049e-01
    z[0,5,5]  R659      -6.4693358726799488e-03
    z[0,5,5]  R660      -2.6729911565780640e-01
    z[0,5,5]  R661      4.4847447425127029e-02
    z[0,5,5]  R662      1.5220044553279877e-01
    z[0,5,5]  R663      -4.5384258031845093e-01
    z[0,5,5]  R664      1.6075240075588226e-01
    z[0,5,5]  R665      -1.6099143773317337e-02
    z[0,5,5]  R666      -4.0589755773544312e-01
    z[0,5,5]  R667      -2.6492691040039062e-01
    z[0,5,5]  R668      -4.0279945731163025e-01
    z[0,5,5]  R669      -2.4074497818946838e-01
    z[0,5,5]  R670      -4.8913535475730896e-01
    z[0,5,5]  R671      -2.5961726903915405e-01
    z[0,5,5]  R672      -1.9433766603469849e-01
    z[0,5,5]  R673      -1.1268361657857895e-01
    z[0,5,5]  R674      4.0919068455696106e-01
    z[0,5,5]  R675      5.9867627918720245e-02
    z[0,5,5]  R676      1.3973297178745270e-01
    z[0,5,5]  R677      2.2402912378311157e-01
    z[0,5,5]  R678      -2.6954427361488342e-01
    z[0,5,5]  R679      -1.1689981073141098e-01
    z[0,5,5]  R680      -1.0135784000158310e-01
    z[0,5,5]  R681      -9.9021323025226593e-02
    z[0,5,5]  R682      -4.6825075149536133e-01
    z[0,5,5]  R683      -4.3617191910743713e-01
    z[0,5,5]  R684      -3.6672794818878174e-01
    z[0,5,5]  R685      -5.5276203155517578e-01
    z[0,5,5]  R686      -4.0194973349571228e-01
    z[0,5,5]  R687      0.0419129841029644
    z[0,5,5]  R688      -0.748490035533905
    z[0,5,5]  R689      1.4861298725008965e-02
    z[0,5,5]  R690      8.3549067378044128e-02
    z[0,5,5]  R691      1.3186158239841461e-01
    z[0,5,5]  R692      5.1337409019470215e-01
    z[0,5,5]  R693      3.2437229156494141e-01
    z[0,5,5]  R694      3.2740112394094467e-02
    z[0,5,5]  R695      4.1143134236335754e-02
    z[0,5,5]  R696      4.3569406867027283e-01
    z[0,5,5]  R697      3.2644793391227722e-01
    z[0,5,5]  R698      3.2438716292381287e-01
    z[0,5,5]  R699      3.2985344529151917e-01
    z[0,5,5]  R700      2.5985753536224365e-01
    z[0,5,5]  R701      4.8788863420486450e-01
    z[0,5,5]  R702      5.6804078817367554e-01
    z[0,5,5]  R703      3.2667967677116394e-01
    z[0,5,6]  R8        -1
    z[0,5,6]  R53       1
    z[0,5,6]  R642      -1
    z[0,5,6]  R643      1
    z[0,5,6]  R644      -6.0252517461776733e-02
    z[0,5,6]  R645      -1.3458128273487091e-01
    z[0,5,6]  R646      3.9626464247703552e-02
    z[0,5,6]  R647      -2.1730247139930725e-01
    z[0,5,6]  R648      -4.3661540746688843e-01
    z[0,5,6]  R649      -7.1414500474929810e-01
    z[0,5,6]  R650      5.0165539979934692e-01
    z[0,5,6]  R651      -9.1163434088230133e-02
    z[0,5,6]  R652      -2.1482041478157043e-01
    z[0,5,6]  R653      -3.5165694355964661e-01
    z[0,5,6]  R654      -2.2796644270420074e-01
    z[0,5,6]  R655      3.0177685618400574e-01
    z[0,5,6]  R656      -1.5494552254676819e-01
    z[0,5,6]  R657      -1.7243444919586182e-01
    z[0,5,6]  R658      4.1394731402397156e-01
    z[0,5,6]  R659      -4.4765327125787735e-02
    z[0,5,6]  R660      2.7599847316741943e-01
    z[0,5,6]  R661      7.7921295166015625e-01
    z[0,5,6]  R662      -1.3724772632122040e-01
    z[0,5,6]  R663      2.5424492359161377e-01
    z[0,5,6]  R664      1.8255215883255005e-01
    z[0,5,6]  R665      -5.9460711479187012e-01
    z[0,5,6]  R666      5.8936983346939087e-01
    z[0,5,6]  R667      1.0386855900287628e-01
    z[0,5,6]  R668      -1.2658125162124634e-01
    z[0,5,6]  R669      0.435189425945282
    z[0,5,6]  R670      5.6694036722183228e-01
    z[0,5,6]  R671      1.1628223955631256e-01
    z[0,5,6]  R672      3.2735636830329895e-01
    z[0,5,6]  R673      8.4505289793014526e-02
    z[0,5,6]  R674      -0.0775846540927887
    z[0,5,6]  R675      8.2278758287429810e-02
    z[0,5,6]  R676      3.6906811594963074e-01
    z[0,5,6]  R677      2.8988981246948242e-01
    z[0,5,6]  R678      4.0837913751602173e-01
    z[0,5,6]  R679      3.6984574794769287e-01
    z[0,5,6]  R680      8.2332855463027954e-01
    z[0,5,6]  R681      5.0635886192321777e-01
    z[0,5,6]  R682      3.5748815536499023e-01
    z[0,5,6]  R683      3.5047656297683716e-01
    z[0,5,6]  R684      3.4444382786750793e-01
    z[0,5,6]  R685      -1.6767981648445129e-01
    z[0,5,6]  R686      -0.0714760273694992
    z[0,5,6]  R687      -6.8889975547790527e-02
    z[0,5,6]  R688      -1.3277265429496765e-01
    z[0,5,6]  R689      0.0651208832859993
    z[0,5,6]  R690      -4.1888660192489624e-01
    z[0,5,6]  R691      -5.0906103849411011e-01
    z[0,5,6]  R692      -3.4804448485374451e-01
    z[0,5,6]  R693      2.8391024470329285e-01
    z[0,5,6]  R694      5.7311558723449707e-01
    z[0,5,6]  R695      5.5515062808990479e-01
    z[0,5,6]  R696      2.2358103096485138e-01
    z[0,5,6]  R697      3.0527812242507935e-01
    z[0,5,6]  R698      2.2190552949905396e-01
    z[0,5,6]  R699      2.8065380454063416e-01
    z[0,5,6]  R700      3.8068944215774536e-01
    z[0,5,6]  R701      2.5680848956108093e-01
    z[0,5,6]  R702      1.5874877572059631e-01
    z[0,5,6]  R703      3.6465290188789368e-01
    z[5,0,0]  R2        1
    z[5,0,0]  R47       -1
    z[5,0,0]  R704      -1
    z[5,0,0]  R705      1
    z[5,0,0]  R718      -2.6823753118515015e-01
    z[5,0,0]  R719      -6.5219156444072723e-02
    z[5,0,0]  R720      -2.8410360217094421e-01
    z[5,0,0]  R721      -4.4057813286781311e-01
    z[5,0,0]  R722      -1.4141286909580231e-01
    z[5,0,0]  R723      6.6742408275604248e-01
    z[5,0,0]  R724      7.5001978874206543e-01
    z[5,0,0]  R725      1.8080644309520721e-01
    z[5,0,0]  R726      4.8582616448402405e-01
    z[5,0,0]  R727      4.6337318420410156e-01
    z[5,0,0]  R728      -3.2918116450309753e-01
    z[5,0,0]  R729      -5.2980142831802368e-01
    z[5,0,0]  R730      1.3590514659881592e-01
    z[5,0,0]  R731      1.8562240898609161e-01
    z[5,0,0]  R732      1.7441925406455994e-01
    z[5,0,0]  R733      -9.4519846141338348e-02
    z[5,0,0]  R734      4.6904768794775009e-02
    z[5,0,0]  R735      -5.8192804455757141e-02
    z[5,0,0]  R736      1.9962343573570251e-01
    z[5,0,0]  R737      -0.294490784406662
    z[5,0,0]  R738      -4.6641939878463745e-01
    z[5,0,0]  R739      -7.0453971624374390e-01
    z[5,0,0]  R740      -8.3414804935455322e-01
    z[5,0,0]  R741      1.1175207793712616e-01
    z[5,0,0]  R742      1.1520291864871979e-01
    z[5,0,0]  R743      -3.8944080471992493e-01
    z[5,0,0]  R744      -1.6368374228477478e-01
    z[5,0,0]  R745      1.8946231901645660e-01
    z[5,0,0]  R746      -7.5923389196395874e-01
    z[5,0,0]  R747      -7.3668062686920166e-01
    z[5,0,0]  R748      6.8893986940383911e-01
    z[5,0,0]  R749      7.6871931552886963e-01
    z[5,0,0]  R750      6.2952494621276855e-01
    z[5,0,0]  R751      8.2327091693878174e-01
    z[5,0,0]  R752      8.6730796098709106e-01
    z[5,0,0]  R753      -2.9360942542552948e-02
    z[5,0,0]  R754      6.6267901659011841e-01
    z[5,0,0]  R755      -1.1476036906242371e-01
    z[5,0,0]  R756      1.5397189557552338e-01
    z[5,0,0]  R757      -1.9980345666408539e-01
    z[5,0,0]  R758      3.2366719841957092e-01
    z[5,0,0]  R759      1.2916807830333710e-01
    z[5,0,0]  R760      -3.1732532382011414e-01
    z[5,0,0]  R761      -2.8837111592292786e-01
    z[5,0,0]  R762      -2.3688845336437225e-01
    z[5,0,0]  R763      -4.4216677546501160e-01
    z[5,0,0]  R764      -3.2980591058731079e-01
    z[5,0,0]  R765      3.8844794034957886e-01
    z[5,0,0]  R766      1.9508582353591919e-01
    z[5,0,0]  R767      1.3773867487907410e-01
    z[5,0,0]  R768      -1.1814265698194504e-01
    z[5,0,0]  R769      7.9213090240955353e-02
    z[5,0,0]  R770      3.9299392700195312e-01
    z[5,0,0]  R771      7.8699356317520142e-01
    z[5,0,0]  R772      -5.1321196556091309e-01
    z[5,0,0]  R773      -1.9562399387359619e-01
    z[5,0,0]  R774      -2.2464221715927124e-01
    z[5,0,0]  R775      -1.3430775701999664e-01
    z[5,0,0]  R776      -3.8461828231811523e-01
    z[5,0,0]  R777      -4.5845183730125427e-01
    z[5,0,1]  R3        1
    z[5,0,1]  R48       -1
    z[5,0,1]  R706      -1
    z[5,0,1]  R707      1
    z[5,0,1]  R718      2.4573600292205811e-01
    z[5,0,1]  R719      3.6279591917991638e-01
    z[5,0,1]  R720      -6.1442929506301880e-01
    z[5,0,1]  R721      2.6527587324380875e-02
    z[5,0,1]  R722      -3.9439103007316589e-01
    z[5,0,1]  R723      3.2276561856269836e-01
    z[5,0,1]  R724      4.2350569367408752e-01
    z[5,0,1]  R725      1.2853574752807617e-01
    z[5,0,1]  R726      5.3194683790206909e-01
    z[5,0,1]  R727      5.1429039239883423e-01
    z[5,0,1]  R728      3.9422520995140076e-01
    z[5,0,1]  R729      2.7047321200370789e-01
    z[5,0,1]  R730      -7.6316612958908081e-01
    z[5,0,1]  R731      -7.5528490543365479e-01
    z[5,0,1]  R732      -7.9375445842742920e-01
    z[5,0,1]  R733      -6.4786761999130249e-01
    z[5,0,1]  R734      -7.3607826232910156e-01
    z[5,0,1]  R735      -7.1364831924438477e-01
    z[5,0,1]  R736      -7.4419844150543213e-01
    z[5,0,1]  R737      -6.3241493701934814e-01
    z[5,0,1]  R738      -4.7570931911468506e-01
    z[5,0,1]  R739      -4.3014129996299744e-01
    z[5,0,1]  R740      -2.8695923089981079e-01
    z[5,0,1]  R741      -5.2187931537628174e-01
    z[5,0,1]  R742      -5.2770727872848511e-01
    z[5,0,1]  R743      -3.2496684789657593e-01
    z[5,0,1]  R744      -4.6004673838615417e-01
    z[5,0,1]  R745      9.7268037497997284e-02
    z[5,0,1]  R746      4.9998548626899719e-01
    z[5,0,1]  R747      4.9960720539093018e-01
    z[5,0,1]  R748      4.1678699851036072e-01
    z[5,0,1]  R749      3.9600458741188049e-01
    z[5,0,1]  R750      4.0015059709548950e-01
    z[5,0,1]  R751      3.0832698941230774e-01
    z[5,0,1]  R752      5.2855193614959717e-02
    z[5,0,1]  R753      4.2598018050193787e-01
    z[5,0,1]  R754      2.2485505044460297e-01
    z[5,0,1]  R755      5.4225105047225952e-01
    z[5,0,1]  R756      0.570558488368988
    z[5,0,1]  R757      4.7694614529609680e-01
    z[5,0,1]  R758      1.1703601479530334e-01
    z[5,0,1]  R759      2.1596144139766693e-01
    z[5,0,1]  R760      5.5512094497680664e-01
    z[5,0,1]  R761      -3.9444932341575623e-01
    z[5,0,1]  R762      -4.9376094341278076e-01
    z[5,0,1]  R763      1.6450468450784683e-02
    z[5,0,1]  R764      2.7394685149192810e-01
    z[5,0,1]  R765      -7.9921215772628784e-01
    z[5,0,1]  R766      -7.0963591337203979e-01
    z[5,0,1]  R767      -7.0107567310333252e-01
    z[5,0,1]  R768      3.4259140491485596e-01
    z[5,0,1]  R769      -4.2591649293899536e-01
    z[5,0,1]  R770      -1.0025259107351303e-02
    z[5,0,1]  R771      -1.4046677947044373e-01
    z[5,0,1]  R772      -0.120124951004982
    z[5,0,1]  R773      5.8132618665695190e-01
    z[5,0,1]  R774      4.9475657939910889e-01
    z[5,0,1]  R775      7.3078292608261108e-01
    z[5,0,1]  R776      -0.00295339897274971
    z[5,0,1]  R777      4.6341851353645325e-02
    z[5,0,2]  R4        1
    z[5,0,2]  R49       -1
    z[5,0,2]  R708      -1
    z[5,0,2]  R709      1
    z[5,0,2]  R718      -3.1426379084587097e-01
    z[5,0,2]  R719      -3.8013070821762085e-01
    z[5,0,2]  R720      -2.6275274157524109e-01
    z[5,0,2]  R721      1.3911771774291992e-01
    z[5,0,2]  R722      -4.1727340221405029e-01
    z[5,0,2]  R723      -2.8148925304412842e-01
    z[5,0,2]  R724      -1.5927772223949432e-01
    z[5,0,2]  R725      3.7788701057434082e-01
    z[5,0,2]  R726      2.7874574065208435e-01
    z[5,0,2]  R727      -6.0055539011955261e-02
    z[5,0,2]  R728      6.1995659023523331e-02
    z[5,0,2]  R729      0.241798996925354
    z[5,0,2]  R730      0.273393839597702
    z[5,0,2]  R731      1.4513716101646423e-01
    z[5,0,2]  R732      2.1221699193120003e-02
    z[5,0,2]  R733      1.7214192450046539e-01
    z[5,0,2]  R734      2.2800672054290771e-01
    z[5,0,2]  R735      2.6251357793807983e-01
    z[5,0,2]  R736      1.3650007545948029e-01
    z[5,0,2]  R737      2.9738715291023254e-01
    z[5,0,2]  R738      -2.7751281857490540e-01
    z[5,0,2]  R739      3.2427478581666946e-02
    z[5,0,2]  R740      -2.1592350304126740e-01
    z[5,0,2]  R741      2.3749215900897980e-01
    z[5,0,2]  R742      1.6844940185546875e-01
    z[5,0,2]  R743      -1.6035212576389313e-01
    z[5,0,2]  R744      4.0930435061454773e-02
    z[5,0,2]  R745      -8.3011329174041748e-02
    z[5,0,2]  R746      0.282932847738266
    z[5,0,2]  R747      1.0794003307819366e-01
    z[5,0,2]  R748      5.0963485240936279e-01
    z[5,0,2]  R749      2.9356148838996887e-01
    z[5,0,2]  R750      3.5316619277000427e-01
    z[5,0,2]  R751      2.4036282300949097e-01
    z[5,0,2]  R752      -8.5613265633583069e-02
    z[5,0,2]  R753      4.1041418910026550e-01
    z[5,0,2]  R754      -1.1305548995733261e-01
    z[5,0,2]  R755      -2.3243862390518188e-01
    z[5,0,2]  R756      -4.3270260095596313e-01
    z[5,0,2]  R757      -1.4517985284328461e-01
    z[5,0,2]  R758      2.1311147511005402e-01
    z[5,0,2]  R759      5.4877460002899170e-01
    z[5,0,2]  R760      3.2962255179882050e-02
    z[5,0,2]  R761      -2.2074329853057861e-01
    z[5,0,2]  R762      -4.7355014085769653e-01
    z[5,0,2]  R763      -1.0937143862247467e-01
    z[5,0,2]  R764      1.5144604444503784e-01
    z[5,0,2]  R765      -6.7280530929565430e-02
    z[5,0,2]  R766      2.2395841777324677e-01
    z[5,0,2]  R767      3.5116162896156311e-01
    z[5,0,2]  R768      3.6203429102897644e-01
    z[5,0,2]  R769      -2.9231157898902893e-01
    z[5,0,2]  R770      -4.4138431549072266e-01
    z[5,0,2]  R771      0.106072336435318
    z[5,0,2]  R772      -6.7699514329433441e-02
    z[5,0,2]  R773      -5.5849432945251465e-01
    z[5,0,2]  R774      -3.3190563321113586e-02
    z[5,0,2]  R775      -4.8151548951864243e-02
    z[5,0,2]  R776      -5.4949706792831421e-01
    z[5,0,2]  R777      -3.5029265284538269e-01
    z[5,0,3]  R5        1
    z[5,0,3]  R50       -1
    z[5,0,3]  R710      -1
    z[5,0,3]  R711      1
    z[5,0,3]  R718      -5.9839230775833130e-01
    z[5,0,3]  R719      -5.6734341382980347e-01
    z[5,0,3]  R720      -5.5254191160202026e-01
    z[5,0,3]  R721      -0.86295485496521
    z[5,0,3]  R722      5.8465588837862015e-02
    z[5,0,3]  R723      5.6408715248107910e-01
    z[5,0,3]  R724      1.9337294995784760e-01
    z[5,0,3]  R725      7.1931129693984985e-01
    z[5,0,3]  R726      1.1560782790184021e-01
    z[5,0,3]  R727      2.3387832939624786e-01
    z[5,0,3]  R728      0.283197283744812
    z[5,0,3]  R729      3.9575561881065369e-01
    z[5,0,3]  R730      2.7132576704025269e-01
    z[5,0,3]  R731      3.9909040927886963e-01
    z[5,0,3]  R732      4.2910179495811462e-01
    z[5,0,3]  R733      4.4801110029220581e-01
    z[5,0,3]  R734      3.9648792147636414e-01
    z[5,0,3]  R735      2.7338972687721252e-01
    z[5,0,3]  R736      1.7293485999107361e-01
    z[5,0,3]  R737      4.2913112044334412e-01
    z[5,0,3]  R738      1.9135875999927521e-01
    z[5,0,3]  R739      6.8657793104648590e-02
    z[5,0,3]  R740      3.0188897252082825e-01
    z[5,0,3]  R741      2.8336721658706665e-01
    z[5,0,3]  R742      1.4530107378959656e-01
    z[5,0,3]  R743      4.2767179012298584e-01
    z[5,0,3]  R744      8.2895606756210327e-02
    z[5,0,3]  R745      2.5135058164596558e-01
    z[5,0,3]  R746      -7.1884766221046448e-02
    z[5,0,3]  R747      -9.1833256185054779e-02
    z[5,0,3]  R748      1.5541224181652069e-01
    z[5,0,3]  R749      2.2369624674320221e-01
    z[5,0,3]  R750      4.6875947713851929e-01
    z[5,0,3]  R751      2.9892998933792114e-01
    z[5,0,3]  R752      1.7789126932621002e-01
    z[5,0,3]  R753      0.769805908203125
    z[5,0,3]  R754      5.9138017892837524e-01
    z[5,0,3]  R755      1.6783721745014191e-01
    z[5,0,3]  R756      4.6502524614334106e-01
    z[5,0,3]  R757      6.3687413930892944e-01
    z[5,0,3]  R758      8.1289058923721313e-01
    z[5,0,3]  R759      4.5772558450698853e-01
    z[5,0,3]  R760      2.7774566411972046e-01
    z[5,0,3]  R761      -7.3069196939468384e-01
    z[5,0,3]  R762      -5.3437966108322144e-01
    z[5,0,3]  R763      -7.3799526691436768e-01
    z[5,0,3]  R764      -3.4302836656570435e-01
    z[5,0,3]  R765      2.0139060914516449e-01
    z[5,0,3]  R766      3.0195074155926704e-02
    z[5,0,3]  R767      -2.8804862499237061e-01
    z[5,0,3]  R768      7.4857777357101440e-01
    z[5,0,3]  R769      8.1203043460845947e-01
    z[5,0,3]  R770      6.4871352910995483e-01
    z[5,0,3]  R771      2.7941519021987915e-01
    z[5,0,3]  R772      -0.682442307472229
    z[5,0,3]  R773      2.4517105892300606e-02
    z[5,0,3]  R774      1.1850558966398239e-01
    z[5,0,3]  R775      -1.5918090939521790e-02
    z[5,0,3]  R776      -2.7980056405067444e-01
    z[5,0,3]  R777      -5.4726260900497437e-01
    z[5,0,4]  R6        1
    z[5,0,4]  R51       -1
    z[5,0,4]  R712      -1
    z[5,0,4]  R713      1
    z[5,0,4]  R718      3.9711022377014160e-01
    z[5,0,4]  R719      -2.5315082073211670e-01
    z[5,0,4]  R720      -2.7344502508640289e-02
    z[5,0,4]  R721      -1.8611754477024078e-01
    z[5,0,4]  R722      -2.6278665661811829e-01
    z[5,0,4]  R723      2.2017116844654083e-01
    z[5,0,4]  R724      1.1359731853008270e-01
    z[5,0,4]  R725      -1.1853111535310745e-01
    z[5,0,4]  R726      0.072480209171772
    z[5,0,4]  R727      5.2598720788955688e-01
    z[5,0,4]  R728      -5.6802171468734741e-01
    z[5,0,4]  R729      -3.4810966253280640e-01
    z[5,0,4]  R730      -1.0453492403030396e-01
    z[5,0,4]  R731      -1.2242580950260162e-01
    z[5,0,4]  R732      2.1998232230544090e-02
    z[5,0,4]  R733      -3.9168462157249451e-01
    z[5,0,4]  R734      1.8533350527286530e-01
    z[5,0,4]  R735      1.9919458031654358e-01
    z[5,0,4]  R736      -9.9543638527393341e-02
    z[5,0,4]  R737      3.2287046313285828e-02
    z[5,0,4]  R738      -1.3734026253223419e-01
    z[5,0,4]  R739      1.9689242541790009e-01
    z[5,0,4]  R740      -1.7872823402285576e-02
    z[5,0,4]  R741      5.4330664873123169e-01
    z[5,0,4]  R742      2.6512509584426880e-01
    z[5,0,4]  R743      -1.5441097319126129e-01
    z[5,0,4]  R744      6.2950074672698975e-01
    z[5,0,4]  R745      -5.1566797494888306e-01
    z[5,0,4]  R746      -1.8406768143177032e-01
    z[5,0,4]  R747      1.5364494174718857e-02
    z[5,0,4]  R748      1.1874731630086899e-01
    z[5,0,4]  R749      1.5236093103885651e-01
    z[5,0,4]  R750      1.5645581483840942e-01
    z[5,0,4]  R751      5.7624153792858124e-02
    z[5,0,4]  R752      4.5855669304728508e-03
    z[5,0,4]  R753      2.3364938795566559e-01
    z[5,0,4]  R754      1.2672841548919678e-02
    z[5,0,4]  R755      -3.7586815655231476e-02
    z[5,0,4]  R756      4.5307138562202454e-01
    z[5,0,4]  R757      -1.8788692355155945e-01
    z[5,0,4]  R758      3.4083411097526550e-01
    z[5,0,4]  R759      2.6868802309036255e-01
    z[5,0,4]  R760      0.0283999964594841
    z[5,0,4]  R761      -3.1247171759605408e-01
    z[5,0,4]  R762      -1.0955525189638138e-01
    z[5,0,4]  R763      1.6455663368105888e-02
    z[5,0,4]  R764      3.3897200226783752e-01
    z[5,0,4]  R765      -2.9044884443283081e-01
    z[5,0,4]  R766      -5.1221090555191040e-01
    z[5,0,4]  R767      -5.1322090625762939e-01
    z[5,0,4]  R768      0.061478141695261
    z[5,0,4]  R769      2.3901236057281494e-01
    z[5,0,4]  R770      -2.7215710282325745e-01
    z[5,0,4]  R771      3.7062233686447144e-01
    z[5,0,4]  R772      1.1155769973993301e-01
    z[5,0,4]  R773      -4.0102687478065491e-01
    z[5,0,4]  R774      -3.8252141326665878e-02
    z[5,0,4]  R775      4.2325085401535034e-01
    z[5,0,4]  R776      -3.5322535037994385e-01
    z[5,0,4]  R777      -2.2889564931392670e-01
    z[5,0,5]  R7        1
    z[5,0,5]  R52       -1
    z[5,0,5]  R714      -1
    z[5,0,5]  R715      1
    z[5,0,5]  R718      -3.6672794818878174e-01
    z[5,0,5]  R719      -5.5276203155517578e-01
    z[5,0,5]  R720      -4.0194973349571228e-01
    z[5,0,5]  R721      0.0419129841029644
    z[5,0,5]  R722      -0.748490035533905
    z[5,0,5]  R723      1.4861298725008965e-02
    z[5,0,5]  R724      8.3549067378044128e-02
    z[5,0,5]  R725      1.3186158239841461e-01
    z[5,0,5]  R726      5.1337409019470215e-01
    z[5,0,5]  R727      3.2437229156494141e-01
    z[5,0,5]  R728      3.2740112394094467e-02
    z[5,0,5]  R729      4.1143134236335754e-02
    z[5,0,5]  R730      4.3569406867027283e-01
    z[5,0,5]  R731      3.2644793391227722e-01
    z[5,0,5]  R732      3.2438716292381287e-01
    z[5,0,5]  R733      3.2985344529151917e-01
    z[5,0,5]  R734      2.5985753536224365e-01
    z[5,0,5]  R735      4.8788863420486450e-01
    z[5,0,5]  R736      5.6804078817367554e-01
    z[5,0,5]  R737      3.2667967677116394e-01
    z[5,0,5]  R738      6.4809662103652954e-01
    z[5,0,5]  R739      5.0592297315597534e-01
    z[5,0,5]  R740      2.8670877218246460e-01
    z[5,0,5]  R741      4.8585128784179688e-01
    z[5,0,5]  R742      6.3074672222137451e-01
    z[5,0,5]  R743      1.6453932970762253e-02
    z[5,0,5]  R744      3.2417336106300354e-01
    z[5,0,5]  R745      0.781249463558197
    z[5,0,5]  R746      9.1276556253433228e-02
    z[5,0,5]  R747      -2.5241073966026306e-01
    z[5,0,5]  R748      4.1232284158468246e-02
    z[5,0,5]  R749      4.1825573891401291e-02
    z[5,0,5]  R750      -2.2501009702682495e-01
    z[5,0,5]  R751      -2.1672993898391724e-01
    z[5,0,5]  R752      1.8610468506813049e-01
    z[5,0,5]  R753      -6.4693358726799488e-03
    z[5,0,5]  R754      -2.6729911565780640e-01
    z[5,0,5]  R755      4.4847447425127029e-02
    z[5,0,5]  R756      1.5220044553279877e-01
    z[5,0,5]  R757      -4.5384258031845093e-01
    z[5,0,5]  R758      1.6075240075588226e-01
    z[5,0,5]  R759      -1.6099143773317337e-02
    z[5,0,5]  R760      -4.0589755773544312e-01
    z[5,0,5]  R761      -2.6492691040039062e-01
    z[5,0,5]  R762      -4.0279945731163025e-01
    z[5,0,5]  R763      -2.4074497818946838e-01
    z[5,0,5]  R764      -4.8913535475730896e-01
    z[5,0,5]  R765      -2.5961726903915405e-01
    z[5,0,5]  R766      -1.9433766603469849e-01
    z[5,0,5]  R767      -1.1268361657857895e-01
    z[5,0,5]  R768      4.0919068455696106e-01
    z[5,0,5]  R769      5.9867627918720245e-02
    z[5,0,5]  R770      1.3973297178745270e-01
    z[5,0,5]  R771      2.2402912378311157e-01
    z[5,0,5]  R772      -2.6954427361488342e-01
    z[5,0,5]  R773      -1.1689981073141098e-01
    z[5,0,5]  R774      -1.0135784000158310e-01
    z[5,0,5]  R775      -9.9021323025226593e-02
    z[5,0,5]  R776      -4.6825075149536133e-01
    z[5,0,5]  R777      -4.3617191910743713e-01
    z[5,0,6]  R8        1
    z[5,0,6]  R53       -1
    z[5,0,6]  R716      -1
    z[5,0,6]  R717      1
    z[5,0,6]  R718      3.4444382786750793e-01
    z[5,0,6]  R719      -1.6767981648445129e-01
    z[5,0,6]  R720      -0.0714760273694992
    z[5,0,6]  R721      -6.8889975547790527e-02
    z[5,0,6]  R722      -1.3277265429496765e-01
    z[5,0,6]  R723      0.0651208832859993
    z[5,0,6]  R724      -4.1888660192489624e-01
    z[5,0,6]  R725      -5.0906103849411011e-01
    z[5,0,6]  R726      -3.4804448485374451e-01
    z[5,0,6]  R727      2.8391024470329285e-01
    z[5,0,6]  R728      5.7311558723449707e-01
    z[5,0,6]  R729      5.5515062808990479e-01
    z[5,0,6]  R730      2.2358103096485138e-01
    z[5,0,6]  R731      3.0527812242507935e-01
    z[5,0,6]  R732      2.2190552949905396e-01
    z[5,0,6]  R733      2.8065380454063416e-01
    z[5,0,6]  R734      3.8068944215774536e-01
    z[5,0,6]  R735      2.5680848956108093e-01
    z[5,0,6]  R736      1.5874877572059631e-01
    z[5,0,6]  R737      3.6465290188789368e-01
    z[5,0,6]  R738      -6.0252517461776733e-02
    z[5,0,6]  R739      -1.3458128273487091e-01
    z[5,0,6]  R740      3.9626464247703552e-02
    z[5,0,6]  R741      -2.1730247139930725e-01
    z[5,0,6]  R742      -4.3661540746688843e-01
    z[5,0,6]  R743      -7.1414500474929810e-01
    z[5,0,6]  R744      5.0165539979934692e-01
    z[5,0,6]  R745      -9.1163434088230133e-02
    z[5,0,6]  R746      -2.1482041478157043e-01
    z[5,0,6]  R747      -3.5165694355964661e-01
    z[5,0,6]  R748      -2.2796644270420074e-01
    z[5,0,6]  R749      3.0177685618400574e-01
    z[5,0,6]  R750      -1.5494552254676819e-01
    z[5,0,6]  R751      -1.7243444919586182e-01
    z[5,0,6]  R752      4.1394731402397156e-01
    z[5,0,6]  R753      -4.4765327125787735e-02
    z[5,0,6]  R754      2.7599847316741943e-01
    z[5,0,6]  R755      7.7921295166015625e-01
    z[5,0,6]  R756      -1.3724772632122040e-01
    z[5,0,6]  R757      2.5424492359161377e-01
    z[5,0,6]  R758      1.8255215883255005e-01
    z[5,0,6]  R759      -5.9460711479187012e-01
    z[5,0,6]  R760      5.8936983346939087e-01
    z[5,0,6]  R761      1.0386855900287628e-01
    z[5,0,6]  R762      -1.2658125162124634e-01
    z[5,0,6]  R763      0.435189425945282
    z[5,0,6]  R764      5.6694036722183228e-01
    z[5,0,6]  R765      1.1628223955631256e-01
    z[5,0,6]  R766      3.2735636830329895e-01
    z[5,0,6]  R767      8.4505289793014526e-02
    z[5,0,6]  R768      -0.0775846540927887
    z[5,0,6]  R769      8.2278758287429810e-02
    z[5,0,6]  R770      3.6906811594963074e-01
    z[5,0,6]  R771      2.8988981246948242e-01
    z[5,0,6]  R772      4.0837913751602173e-01
    z[5,0,6]  R773      3.6984574794769287e-01
    z[5,0,6]  R774      8.2332855463027954e-01
    z[5,0,6]  R775      5.0635886192321777e-01
    z[5,0,6]  R776      3.5748815536499023e-01
    z[5,0,6]  R777      3.5047656297683716e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R832      -1
    z[1,2,0]  R833      1
    z[1,2,0]  R846      -6.7375445365905762e-01
    z[1,2,0]  R847      -6.9888913631439209e-01
    z[1,2,0]  R848      -0.594390869140625
    z[1,2,0]  R849      -5.7361841201782227e-01
    z[1,2,0]  R850      -8.2231032848358154e-01
    z[1,2,0]  R851      -6.2316077947616577e-01
    z[1,2,0]  R852      -5.8995449542999268e-01
    z[1,2,0]  R853      -5.8598655462265015e-01
    z[1,2,0]  R854      -0.606269121170044
    z[1,2,0]  R855      -6.2820702791213989e-01
    z[1,2,0]  R856      6.9167673587799072e-01
    z[1,2,0]  R857      5.3233176469802856e-01
    z[1,2,0]  R858      8.2345694303512573e-01
    z[1,2,0]  R859      6.9714194536209106e-01
    z[1,2,0]  R860      6.9522601366043091e-01
    z[1,2,0]  R861      5.7812613248825073e-01
    z[1,2,0]  R862      6.6528755426406860e-01
    z[1,2,0]  R863      3.6091324687004089e-01
    z[1,2,0]  R864      9.0225964784622192e-01
    z[1,2,0]  R865      6.9183218479156494e-01
    z[1,2,0]  R866      -1.3907539844512939e-01
    z[1,2,0]  R867      -3.6842882633209229e-01
    z[1,2,0]  R868      2.7511421591043472e-02
    z[1,2,0]  R869      3.3677688241004944e-01
    z[1,2,0]  R870      -3.0400383472442627e-01
    z[1,2,0]  R871      0.129286989569664
    z[1,2,0]  R872      2.0904533565044403e-01
    z[1,2,0]  R873      -2.5468206405639648e-01
    z[1,2,0]  R874      1.1293878406286240e-01
    z[1,2,0]  R875      4.3662047386169434e-01
    z[1,2,0]  R876      3.9613431692123413e-01
    z[1,2,0]  R877      -3.3349683880805969e-01
    z[1,2,0]  R878      -5.5167776346206665e-01
    z[1,2,0]  R879      -2.6409402489662170e-01
    z[1,2,0]  R880      -0.34183269739151
    z[1,2,0]  R881      5.2882835268974304e-02
    z[1,2,0]  R882      -8.3833348751068115e-01
    z[1,2,0]  R883      -0.0875013917684555
    z[1,2,0]  R884      1.0923463106155396e-01
    z[1,2,0]  R885      -1.5071013569831848e-01
    z[1,2,0]  R886      2.0982383191585541e-01
    z[1,2,0]  R887      -2.2338643670082092e-01
    z[1,2,0]  R888      -1.9661673903465271e-01
    z[1,2,0]  R889      4.1472226381301880e-01
    z[1,2,0]  R890      6.9381761550903320e-01
    z[1,2,0]  R891      1.7683707177639008e-01
    z[1,2,0]  R892      1.4207929372787476e-01
    z[1,2,0]  R893      5.0470888614654541e-02
    z[1,2,0]  R894      -1.8071976304054260e-01
    z[1,2,0]  R895      -1.8040654063224792e-01
    z[1,2,0]  R896      9.3746155500411987e-01
    z[1,2,0]  R897      7.5093394517898560e-01
    z[1,2,0]  R898      0.723858654499054
    z[1,2,0]  R899      7.9731434583663940e-01
    z[1,2,0]  R900      -1.7402684688568115e-01
    z[1,2,0]  R901      4.5955085754394531e-01
    z[1,2,0]  R902      -3.2479703426361084e-01
    z[1,2,0]  R903      -8.4862513467669487e-03
    z[1,2,0]  R904      -9.2845153808593750e-01
    z[1,2,0]  R905      -8.3313882350921631e-01
    z[1,2,0]  R906      -3.1924718618392944e-01
    z[1,2,0]  R907      -4.2675679922103882e-01
    z[1,2,0]  R908      8.1410235166549683e-01
    z[1,2,0]  R909      -3.7976104021072388e-01
    z[1,2,0]  R910      7.1696668863296509e-02
    z[1,2,0]  R911      -4.5697745680809021e-01
    z[1,2,0]  R912      -4.2993064969778061e-02
    z[1,2,0]  R913      1.0481332242488861e-01
    z[1,2,0]  R914      -1.7297340929508209e-01
    z[1,2,0]  R915      4.1590067744255066e-01
    z[1,2,0]  R916      3.9963892102241516e-01
    z[1,2,0]  R917      -4.4773986935615540e-01
    z[1,2,0]  R918      2.3669132962822914e-02
    z[1,2,0]  R919      -1.5191610157489777e-01
    z[1,2,0]  R920      -3.5037714242935181e-01
    z[1,2,0]  R921      -1.9325231015682220e-01
    z[1,2,0]  R922      3.1451320648193359e-01
    z[1,2,0]  R923      -3.1922420859336853e-01
    z[1,2,0]  R924      2.4484528601169586e-01
    z[1,2,0]  R925      -4.3561407923698425e-01
    z[1,2,0]  R926      1.1964980512857437e-01
    z[1,2,0]  R927      4.5635089278221130e-01
    z[1,2,0]  R928      -0.125092551112175
    z[1,2,0]  R929      4.7106048464775085e-01
    z[1,2,0]  R930      -3.9310479164123535e-01
    z[1,2,0]  R931      -3.6264759302139282e-01
    z[1,2,0]  R932      -4.9746543169021606e-01
    z[1,2,0]  R933      -3.1940698623657227e-01
    z[1,2,0]  R934      -5.8063352108001709e-01
    z[1,2,0]  R935      -2.9870501160621643e-01
    z[1,2,0]  R936      7.2426810860633850e-02
    z[1,2,0]  R937      -9.6556141972541809e-02
    z[1,2,0]  R938      -3.3674961328506470e-01
    z[1,2,0]  R939      -2.1139541268348694e-01
    z[1,2,0]  R940      -6.4578318595886230e-01
    z[1,2,0]  R941      -3.0570608377456665e-01
    z[1,2,0]  R942      1.4016310870647430e-01
    z[1,2,0]  R943      -3.0304387211799622e-01
    z[1,2,0]  R944      -8.4870404005050659e-01
    z[1,2,0]  R945      1.3653036952018738e-01
    z[1,2,0]  R946      1.0207693278789520e-01
    z[1,2,0]  R947      -4.5072686672210693e-01
    z[1,2,0]  R948      -0.650905191898346
    z[1,2,0]  R949      -4.1497984528541565e-01
    z[1,2,0]  R950      2.6181656122207642e-01
    z[1,2,0]  R951      -6.5905636548995972e-01
    z[1,2,0]  R952      -3.6861473321914673e-01
    z[1,2,0]  R953      -0.530968427658081
    z[1,2,0]  R954      -5.7315403223037720e-01
    z[1,2,0]  R955      -4.6986043453216553e-01
    z[1,2,0]  R956      3.0096715688705444e-01
    z[1,2,0]  R957      0.266201913356781
    z[1,2,0]  R958      3.9871039986610413e-01
    z[1,2,0]  R959      2.9021590948104858e-01
    z[1,2,0]  R960      -6.1205196380615234e-01
    z[1,2,0]  R961      0.790971040725708
    z[1,2,0]  R962      6.4641773700714111e-02
    z[1,2,0]  R963      -4.0440770983695984e-01
    z[1,2,0]  R964      -0.0990544930100441
    z[1,2,0]  R965      -1.8146137893199921e-01
    z[1,2,0]  R966      -0.0699734315276146
    z[1,2,0]  R967      0.806816041469574
    z[1,2,0]  R968      -1.2725955247879028e-01
    z[1,2,0]  R969      -2.3796859383583069e-01
    z[1,2,0]  R970      7.5944811105728149e-02
    z[1,2,0]  R971      -1.1690370738506317e-01
    z[1,2,0]  R972      2.7889090776443481e-01
    z[1,2,0]  R973      -1.2801650166511536e-01
    z[1,2,0]  R974      -2.1942233666777611e-02
    z[1,2,0]  R975      -3.4418243169784546e-01
    z[1,2,0]  R976      3.4553754329681396e-01
    z[1,2,0]  R977      -3.0406650900840759e-01
    z[1,2,0]  R978      -3.5892143845558167e-01
    z[1,2,0]  R979      -4.7762086987495422e-01
    z[1,2,0]  R980      -3.4556332975625992e-02
    z[1,2,0]  R981      -1.5605589747428894e-01
    z[1,2,0]  R982      -3.9361652731895447e-01
    z[1,2,0]  R983      -1.3211588561534882e-01
    z[1,2,0]  R984      -6.5518431365489960e-02
    z[1,2,0]  R985      -2.9194861650466919e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R834      -1
    z[1,2,1]  R835      1
    z[1,2,1]  R846      5.6581604480743408e-01
    z[1,2,1]  R847      4.6107420325279236e-01
    z[1,2,1]  R848      5.8846014738082886e-01
    z[1,2,1]  R849      6.0418677330017090e-01
    z[1,2,1]  R850      4.1971653699874878e-01
    z[1,2,1]  R851      4.7782710194587708e-01
    z[1,2,1]  R852      -0.0804959312081337
    z[1,2,1]  R853      -1.3034315407276154e-01
    z[1,2,1]  R854      4.8019781708717346e-01
    z[1,2,1]  R855      4.2548415064811707e-01
    z[1,2,1]  R856      1.3635043799877167e-01
    z[1,2,1]  R857      1.9816307723522186e-01
    z[1,2,1]  R858      1.8716986477375031e-01
    z[1,2,1]  R859      3.2812580466270447e-01
    z[1,2,1]  R860      4.3138720095157623e-02
    z[1,2,1]  R861      3.2618638873100281e-01
    z[1,2,1]  R862      3.6346804350614548e-02
    z[1,2,1]  R863      2.0694455131888390e-02
    z[1,2,1]  R864      1.6249081492424011e-01
    z[1,2,1]  R865      3.1555914878845215e-01
    z[1,2,1]  R866      -5.7555562257766724e-01
    z[1,2,1]  R867      2.9388232156634331e-02
    z[1,2,1]  R868      1.3200907409191132e-01
    z[1,2,1]  R869      7.3984724283218384e-01
    z[1,2,1]  R870      2.4440020322799683e-02
    z[1,2,1]  R871      -7.2986435890197754e-01
    z[1,2,1]  R872      -0.655773401260376
    z[1,2,1]  R873      1.0935997962951660e-01
    z[1,2,1]  R874      4.1971331834793091e-01
    z[1,2,1]  R875      -6.3583093881607056e-01
    z[1,2,1]  R876      -4.6782466769218445e-01
    z[1,2,1]  R877      -7.1851402521133423e-01
    z[1,2,1]  R878      -3.1521740555763245e-01
    z[1,2,1]  R879      -4.8395147919654846e-01
    z[1,2,1]  R880      -5.0472050905227661e-01
    z[1,2,1]  R881      -7.5323802232742310e-01
    z[1,2,1]  R882      -1.8055382370948792e-01
    z[1,2,1]  R883      1.0876475274562836e-01
    z[1,2,1]  R884      2.4585419893264771e-01
    z[1,2,1]  R885      4.6252235770225525e-01
    z[1,2,1]  R886      -3.5149574279785156e-01
    z[1,2,1]  R887      -3.2818189263343811e-01
    z[1,2,1]  R888      -4.5154190063476562e-01
    z[1,2,1]  R889      -7.6954740285873413e-01
    z[1,2,1]  R890      -1.4450900256633759e-01
    z[1,2,1]  R891      -6.8819504976272583e-01
    z[1,2,1]  R892      2.1572996675968170e-01
    z[1,2,1]  R893      3.8106867671012878e-01
    z[1,2,1]  R894      2.7672821283340454e-01
    z[1,2,1]  R895      -0.621740996837616
    z[1,2,1]  R896      -0.0515022911131382
    z[1,2,1]  R897      -2.8066793084144592e-01
    z[1,2,1]  R898      -2.8422072529792786e-01
    z[1,2,1]  R899      -2.2228258848190308e-01
    z[1,2,1]  R900      -5.4552555084228516e-01
    z[1,2,1]  R901      -2.5604084134101868e-01
    z[1,2,1]  R902      -8.0818790197372437e-01
    z[1,2,1]  R903      -8.4745258092880249e-01
    z[1,2,1]  R904      -1.9298858940601349e-01
    z[1,2,1]  R905      -1.9169786944985390e-02
    z[1,2,1]  R906      -1.4883506298065186e-01
    z[1,2,1]  R907      -3.3743056654930115e-01
    z[1,2,1]  R908      -3.2267636060714722e-01
    z[1,2,1]  R909      -3.5981380939483643e-01
    z[1,2,1]  R910      -5.5066061019897461e-01
    z[1,2,1]  R911      -8.3241373300552368e-01
    z[1,2,1]  R912      -4.0126565098762512e-01
    z[1,2,1]  R913      -0.325792133808136
    z[1,2,1]  R914      3.9969906210899353e-01
    z[1,2,1]  R915      -6.9523072242736816e-01
    z[1,2,1]  R916      -2.1889136731624603e-01
    z[1,2,1]  R917      -7.2267115116119385e-01
    z[1,2,1]  R918      -3.3751270174980164e-01
    z[1,2,1]  R919      5.9211593866348267e-01
    z[1,2,1]  R920      2.6231136918067932e-01
    z[1,2,1]  R921      4.2199438810348511e-01
    z[1,2,1]  R922      8.6712735891342163e-01
    z[1,2,1]  R923      9.4980537891387939e-02
    z[1,2,1]  R924      -6.7621898651123047e-01
    z[1,2,1]  R925      2.8200818225741386e-02
    z[1,2,1]  R926      5.9983724355697632e-01
    z[1,2,1]  R927      7.2173017263412476e-01
    z[1,2,1]  R928      4.3486005067825317e-01
    z[1,2,1]  R929      2.1249566972255707e-01
    z[1,2,1]  R930      -2.1284019947052002e-01
    z[1,2,1]  R931      -0.332770437002182
    z[1,2,1]  R932      -3.5462863743305206e-02
    z[1,2,1]  R933      -8.2390010356903076e-02
    z[1,2,1]  R934      -0.181112602353096
    z[1,2,1]  R935      -6.3754066824913025e-02
    z[1,2,1]  R936      3.5394972562789917e-01
    z[1,2,1]  R937      8.4005340933799744e-02
    z[1,2,1]  R938      -4.2696595191955566e-02
    z[1,2,1]  R939      0.0811346247792244
    z[1,2,1]  R940      4.2347289621829987e-02
    z[1,2,1]  R941      -9.2981308698654175e-02
    z[1,2,1]  R942      -2.3038220405578613e-01
    z[1,2,1]  R943      -2.3555132746696472e-01
    z[1,2,1]  R944      -9.0188965201377869e-02
    z[1,2,1]  R945      -2.9894340783357620e-02
    z[1,2,1]  R946      -9.5013357698917389e-02
    z[1,2,1]  R947      -8.7583720684051514e-01
    z[1,2,1]  R948      -7.2417879104614258e-01
    z[1,2,1]  R949      4.2553361505270004e-02
    z[1,2,1]  R950      -2.7154216170310974e-01
    z[1,2,1]  R951      -5.9841054677963257e-01
    z[1,2,1]  R952      -7.6666903495788574e-01
    z[1,2,1]  R953      -6.2934494018554688e-01
    z[1,2,1]  R954      -5.9415531158447266e-01
    z[1,2,1]  R955      -3.0684208869934082e-01
    z[1,2,1]  R956      -4.1537608951330185e-02
    z[1,2,1]  R957      -1.8900800496339798e-02
    z[1,2,1]  R958      -3.6691910028457642e-01
    z[1,2,1]  R959      -4.4243744015693665e-01
    z[1,2,1]  R960      -3.1237161159515381e-01
    z[1,2,1]  R961      0.0637897253036499
    z[1,2,1]  R962      -0.583785355091095
    z[1,2,1]  R963      -6.6741967201232910e-01
    z[1,2,1]  R964      -4.8305392265319824e-01
    z[1,2,1]  R965      -6.9934207201004028e-01
    z[1,2,1]  R966      4.1462263464927673e-01
    z[1,2,1]  R967      2.4976047873497009e-01
    z[1,2,1]  R968      4.0262803435325623e-01
    z[1,2,1]  R969      -3.2162415981292725e-01
    z[1,2,1]  R970      -3.1465274095535278e-01
    z[1,2,1]  R971      -8.8595676422119141e-01
    z[1,2,1]  R972      4.3278205394744873e-01
    z[1,2,1]  R973      3.2780739665031433e-01
    z[1,2,1]  R974      -0.562740683555603
    z[1,2,1]  R975      -4.7032970190048218e-01
    z[1,2,1]  R976      4.2216780781745911e-01
    z[1,2,1]  R977      -6.2297242879867554e-01
    z[1,2,1]  R978      -3.4845784306526184e-01
    z[1,2,1]  R979      -6.8859666585922241e-01
    z[1,2,1]  R980      -4.9920460581779480e-01
    z[1,2,1]  R981      -4.4212073087692261e-01
    z[1,2,1]  R982      -2.2997401654720306e-01
    z[1,2,1]  R983      -7.0381003618240356e-01
    z[1,2,1]  R984      -6.4303326606750488e-01
    z[1,2,1]  R985      -5.4580366611480713e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R836      -1
    z[1,2,2]  R837      1
    z[1,2,2]  R846      -1.8583782017230988e-01
    z[1,2,2]  R847      4.0435454249382019e-01
    z[1,2,2]  R848      4.9485184252262115e-02
    z[1,2,2]  R849      3.0327681452035904e-02
    z[1,2,2]  R850      1.4825256168842316e-01
    z[1,2,2]  R851      3.9322644472122192e-01
    z[1,2,2]  R852      3.4202730655670166e-01
    z[1,2,2]  R853      3.8173198699951172e-01
    z[1,2,2]  R854      8.3235532045364380e-02
    z[1,2,2]  R855      3.8509148359298706e-01
    z[1,2,2]  R856      3.6533221602439880e-01
    z[1,2,2]  R857      6.9461631774902344e-01
    z[1,2,2]  R858      4.7899049520492554e-01
    z[1,2,2]  R859      2.2634410858154297e-01
    z[1,2,2]  R860      4.1579627990722656e-01
    z[1,2,2]  R861      4.0311416983604431e-01
    z[1,2,2]  R862      2.3965889215469360e-01
    z[1,2,2]  R863      7.5463271141052246e-01
    z[1,2,2]  R864      6.9754309952259064e-02
    z[1,2,2]  R865      4.0157452225685120e-01
    z[1,2,2]  R866      0.372557133436203
    z[1,2,2]  R867      -1.4441660046577454e-01
    z[1,2,2]  R868      -5.6320565938949585e-01
    z[1,2,2]  R869      -3.5228511691093445e-01
    z[1,2,2]  R870      -3.0513930320739746e-01
    z[1,2,2]  R871      4.9704313278198242e-01
    z[1,2,2]  R872      4.5590788125991821e-01
    z[1,2,2]  R873      -6.6915452480316162e-01
    z[1,2,2]  R874      -5.5253100395202637e-01
    z[1,2,2]  R875      3.0519595742225647e-01
    z[1,2,2]  R876      6.9835972785949707e-01
    z[1,2,2]  R877      2.0382064580917358e-01
    z[1,2,2]  R878      -2.1288146078586578e-01
    z[1,2,2]  R879      6.2886893749237061e-01
    z[1,2,2]  R880      1.3575246930122375e-01
    z[1,2,2]  R881      4.6135470271110535e-01
    z[1,2,2]  R882      -2.4484296143054962e-01
    z[1,2,2]  R883      -2.1331357955932617e-01
    z[1,2,2]  R884      -4.6741876006126404e-01
    z[1,2,2]  R885      -6.8512326478958130e-01
    z[1,2,2]  R886      6.0631680488586426e-01
    z[1,2,2]  R887      8.0816090106964111e-01
    z[1,2,2]  R888      7.1812593936920166e-01
    z[1,2,2]  R889      -1.1645172536373138e-01
    z[1,2,2]  R890      -2.2195224463939667e-01
    z[1,2,2]  R891      -3.4744247794151306e-01
    z[1,2,2]  R892      -6.0679125785827637e-01
    z[1,2,2]  R893      -3.5761341452598572e-01
    z[1,2,2]  R894      -1.6917374730110168e-01
    z[1,2,2]  R895      -3.7453171610832214e-01
    z[1,2,2]  R896      -2.8504827991127968e-02
    z[1,2,2]  R897      2.3543396592140198e-01
    z[1,2,2]  R898      5.1484811305999756e-01
    z[1,2,2]  R899      1.7536431550979614e-01
    z[1,2,2]  R900      3.4148257970809937e-01
    z[1,2,2]  R901      5.8263164758682251e-01
    z[1,2,2]  R902      1.6801603138446808e-01
    z[1,2,2]  R903      -9.2448271811008453e-02
    z[1,2,2]  R904      -7.8539937734603882e-02
    z[1,2,2]  R905      1.2315201759338379e-01
    z[1,2,2]  R906      6.9656980037689209e-01
    z[1,2,2]  R907      2.5004261732101440e-01
    z[1,2,2]  R908      2.6816296577453613e-01
    z[1,2,2]  R909      3.6138707399368286e-01
    z[1,2,2]  R910      4.6646651625633240e-01
    z[1,2,2]  R911      4.0568541735410690e-02
    z[1,2,2]  R912      7.9084801673889160e-01
    z[1,2,2]  R913      6.8234455585479736e-01
    z[1,2,2]  R914      -3.0624341964721680e-01
    z[1,2,2]  R915      -4.8970249295234680e-01
    z[1,2,2]  R916      6.5157341957092285e-01
    z[1,2,2]  R917      1.8652480095624924e-02
    z[1,2,2]  R918      6.6115683317184448e-01
    z[1,2,2]  R919      -1.5419077873229980e-01
    z[1,2,2]  R920      -1.6393500566482544e-01
    z[1,2,2]  R921      -5.4945224523544312e-01
    z[1,2,2]  R922      -1.7873485386371613e-01
    z[1,2,2]  R923      -2.0642848312854767e-01
    z[1,2,2]  R924      -3.5644856095314026e-01
    z[1,2,2]  R925      -0.48117595911026
    z[1,2,2]  R926      3.0667799711227417e-01
    z[1,2,2]  R927      8.7701253592967987e-02
    z[1,2,2]  R928      5.4213011264801025e-01
    z[1,2,2]  R929      -1.9859565794467926e-01
    z[1,2,2]  R930      6.8247979879379272e-01
    z[1,2,2]  R931      5.1311510801315308e-01
    z[1,2,2]  R932      5.7735347747802734e-01
    z[1,2,2]  R933      5.7280987501144409e-01
    z[1,2,2]  R934      3.1305974721908569e-01
    z[1,2,2]  R935      9.0186780691146851e-01
    z[1,2,2]  R936      4.5689836144447327e-01
    z[1,2,2]  R937      -3.0133244395256042e-01
    z[1,2,2]  R938      -1.7264898121356964e-01
    z[1,2,2]  R939      -3.2008981704711914e-01
    z[1,2,2]  R940      -3.3835846930742264e-02
    z[1,2,2]  R941      -8.4999807178974152e-02
    z[1,2,2]  R942      -5.3778284788131714e-01
    z[1,2,2]  R943      -1.6220824420452118e-01
    z[1,2,2]  R944      4.5658446848392487e-02
    z[1,2,2]  R945      -0.291608065366745
    z[1,2,2]  R946      -0.0314226932823658
    z[1,2,2]  R947      -1.0495898127555847e-01
    z[1,2,2]  R948      9.9670603871345520e-02
    z[1,2,2]  R949      -7.1303009986877441e-01
    z[1,2,2]  R950      -9.3205086886882782e-02
    z[1,2,2]  R951      1.2623761594295502e-01
    z[1,2,2]  R952      -7.5511775910854340e-02
    z[1,2,2]  R953      1.6558539867401123e-01
    z[1,2,2]  R954      1.6087324917316437e-01
    z[1,2,2]  R955      -5.3906667232513428e-01
    z[1,2,2]  R956      1.5534909069538116e-01
    z[1,2,2]  R957      1.7812253534793854e-01
    z[1,2,2]  R958      -7.1083754301071167e-02
    z[1,2,2]  R959      -3.1101605296134949e-01
    z[1,2,2]  R960      5.8487743139266968e-01
    z[1,2,2]  R961      -2.8012701869010925e-01
    z[1,2,2]  R962      0.524462878704071
    z[1,2,2]  R963      1.7696005105972290e-01
    z[1,2,2]  R964      3.4141331911087036e-01
    z[1,2,2]  R965      5.0322753190994263e-01
    z[1,2,2]  R966      4.8755025863647461e-01
    z[1,2,2]  R967      -2.0616883039474487e-01
    z[1,2,2]  R968      3.0896782875061035e-01
    z[1,2,2]  R969      4.5889967679977417e-01
    z[1,2,2]  R970      8.2162946462631226e-01
    z[1,2,2]  R971      3.1508103013038635e-01
    z[1,2,2]  R972      -2.0668437704443932e-02
    z[1,2,2]  R973      -4.0846887230873108e-01
    z[1,2,2]  R974      -4.7836822271347046e-01
    z[1,2,2]  R975      -6.8681873381137848e-04
    z[1,2,2]  R976      -3.6278583109378815e-02
    z[1,2,2]  R977      7.0591771602630615e-01
    z[1,2,2]  R978      1.5450893342494965e-01
    z[1,2,2]  R979      -3.6272511351853609e-04
    z[1,2,2]  R980      6.5159320831298828e-01
    z[1,2,2]  R981      5.0417190790176392e-01
    z[1,2,2]  R982      3.4218469262123108e-01
    z[1,2,2]  R983      2.3716755211353302e-01
    z[1,2,2]  R984      6.0096681118011475e-01
    z[1,2,2]  R985      -4.2711740732192993e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R838      -1
    z[1,2,3]  R839      1
    z[1,2,3]  R846      8.6268782615661621e-02
    z[1,2,3]  R847      7.9351119697093964e-02
    z[1,2,3]  R848      -4.1238284111022949e-01
    z[1,2,3]  R849      0.27255779504776
    z[1,2,3]  R850      -1.6743110120296478e-01
    z[1,2,3]  R851      -7.4745684862136841e-02
    z[1,2,3]  R852      -0.693411111831665
    z[1,2,3]  R853      -6.0715156793594360e-01
    z[1,2,3]  R854      -4.3046516180038452e-01
    z[1,2,3]  R855      1.0837700963020325e-01
    z[1,2,3]  R856      3.6152294278144836e-01
    z[1,2,3]  R857      2.4025149643421173e-01
    z[1,2,3]  R858      -3.9704661816358566e-02
    z[1,2,3]  R859      1.3632193207740784e-01
    z[1,2,3]  R860      9.5584288239479065e-02
    z[1,2,3]  R861      5.7831990718841553e-01
    z[1,2,3]  R862      1.0920634120702744e-01
    z[1,2,3]  R863      1.6979576647281647e-01
    z[1,2,3]  R864      -8.3034120500087738e-02
    z[1,2,3]  R865      4.5772495865821838e-01
    z[1,2,3]  R866      -1.1041700094938278e-01
    z[1,2,3]  R867      8.7938672304153442e-01
    z[1,2,3]  R868      7.2547090053558350e-01
    z[1,2,3]  R869      1.1537463963031769e-01
    z[1,2,3]  R870      6.1914795637130737e-01
    z[1,2,3]  R871      0.170075923204422
    z[1,2,3]  R872      2.6926058530807495e-01
    z[1,2,3]  R873      5.0105082988739014e-01
    z[1,2,3]  R874      5.0233274698257446e-01
    z[1,2,3]  R875      5.8124684728682041e-03
    z[1,2,3]  R876      1.3400685787200928e-01
    z[1,2,3]  R877      3.0896854400634766e-01
    z[1,2,3]  R878      -1.0778423398733139e-01
    z[1,2,3]  R879      4.3510311841964722e-01
    z[1,2,3]  R880      -1.0263931006193161e-01
    z[1,2,3]  R881      -2.2846798598766327e-01
    z[1,2,3]  R882      1.6738660633563995e-01
    z[1,2,3]  R883      8.6282485723495483e-01
    z[1,2,3]  R884      7.1221959590911865e-01
    z[1,2,3]  R885      4.8533996939659119e-01
    z[1,2,3]  R886      -4.1398438811302185e-01
    z[1,2,3]  R887      4.2451298236846924e-01
    z[1,2,3]  R888      -2.6501944661140442e-01
    z[1,2,3]  R889      -1.0121706128120422e-01
    z[1,2,3]  R890      -8.4021300077438354e-02
    z[1,2,3]  R891      1.9870984554290771e-01
    z[1,2,3]  R892      6.7457318305969238e-01
    z[1,2,3]  R893      6.5682178735733032e-01
    z[1,2,3]  R894      6.9819372892379761e-01
    z[1,2,3]  R895      0.532219648361206
    z[1,2,3]  R896      1.5586647391319275e-01
    z[1,2,3]  R897      4.0449678897857666e-01
    z[1,2,3]  R898      -8.4880597889423370e-02
    z[1,2,3]  R899      4.5831638574600220e-01
    z[1,2,3]  R900      2.3949561640620232e-02
    z[1,2,3]  R901      4.4943434000015259e-01
    z[1,2,3]  R902      -0.0392412431538105
    z[1,2,3]  R903      2.4432432651519775e-01
    z[1,2,3]  R904      2.8851801156997681e-01
    z[1,2,3]  R905      5.0724571943283081e-01
    z[1,2,3]  R906      9.2477187514305115e-02
    z[1,2,3]  R907      -3.3023558557033539e-02
    z[1,2,3]  R908      3.7392783164978027e-01
    z[1,2,3]  R909      -8.7873362004756927e-02
    z[1,2,3]  R910      -6.6005373001098633e-01
    z[1,2,3]  R911      -1.6353135928511620e-02
    z[1,2,3]  R912      -2.2524943947792053e-01
    z[1,2,3]  R913      1.6651917248964310e-02
    z[1,2,3]  R914      7.5210946798324585e-01
    z[1,2,3]  R915      -2.6873955503106117e-02
    z[1,2,3]  R916      -2.3450862616300583e-02
    z[1,2,3]  R917      2.2883121669292450e-01
    z[1,2,3]  R918      2.7994289994239807e-01
    z[1,2,3]  R919      -1.3547608256340027e-01
    z[1,2,3]  R920      7.6073713600635529e-02
    z[1,2,3]  R921      5.8836966753005981e-01
    z[1,2,3]  R922      1.2514644861221313e-01
    z[1,2,3]  R923      7.5729668140411377e-01
    z[1,2,3]  R924      8.8596068322658539e-02
    z[1,2,3]  R925      4.1238108277320862e-01
    z[1,2,3]  R926      9.3609832227230072e-02
    z[1,2,3]  R927      -2.1035907790064812e-02
    z[1,2,3]  R928      1.3036954402923584e-01
    z[1,2,3]  R929      2.0052876323461533e-02
    z[1,2,3]  R930      -0.495135635137558
    z[1,2,3]  R931      -3.0368411540985107e-01
    z[1,2,3]  R932      -0.511141300201416
    z[1,2,3]  R933      -7.0996415615081787e-01
    z[1,2,3]  R934      -6.7732381820678711e-01
    z[1,2,3]  R935      -2.2971355915069580e-01
    z[1,2,3]  R936      7.1147501468658447e-01
    z[1,2,3]  R937      -7.3761200904846191e-01
    z[1,2,3]  R938      -0.451924204826355
    z[1,2,3]  R939      -2.0343993604183197e-01
    z[1,2,3]  R940      -2.2310629487037659e-01
    z[1,2,3]  R941      -2.8772500157356262e-01
    z[1,2,3]  R942      -6.3988798856735229e-01
    z[1,2,3]  R943      -2.6446914672851562e-01
    z[1,2,3]  R944      -2.9471242427825928e-01
    z[1,2,3]  R945      -3.5488110780715942e-01
    z[1,2,3]  R946      7.0867466926574707e-01
    z[1,2,3]  R947      1.1995280534029007e-01
    z[1,2,3]  R948      9.1283574700355530e-02
    z[1,2,3]  R949      -4.3391120433807373e-01
    z[1,2,3]  R950      3.7661322951316833e-01
    z[1,2,3]  R951      2.5445926189422607e-01
    z[1,2,3]  R952      0.0413551852107048
    z[1,2,3]  R953      6.5296448767185211e-02
    z[1,2,3]  R954      1.6322822868824005e-01
    z[1,2,3]  R955      -4.7423759102821350e-01
    z[1,2,3]  R956      6.3237917423248291e-01
    z[1,2,3]  R957      3.9997085928916931e-01
    z[1,2,3]  R958      6.8104404211044312e-01
    z[1,2,3]  R959      4.9130213260650635e-01
    z[1,2,3]  R960      -3.3424523472785950e-01
    z[1,2,3]  R961      2.3141415417194366e-01
    z[1,2,3]  R962      -3.3661547303199768e-01
    z[1,2,3]  R963      5.9688467532396317e-02
    z[1,2,3]  R964      -8.9241966605186462e-02
    z[1,2,3]  R965      2.6097431778907776e-01
    z[1,2,3]  R966      5.2706265449523926e-01
    z[1,2,3]  R967      3.2264092564582825e-01
    z[1,2,3]  R968      1.1933559924364090e-01
    z[1,2,3]  R969      5.2976008504629135e-02
    z[1,2,3]  R970      -0.276328444480896
    z[1,2,3]  R971      -5.9998266398906708e-02
    z[1,2,3]  R972      1.9840340316295624e-01
    z[1,2,3]  R973      -6.9231164455413818e-01
    z[1,2,3]  R974      -3.6303135752677917e-01
    z[1,2,3]  R975      -2.5195494294166565e-01
    z[1,2,3]  R976      3.2401415705680847e-01
    z[1,2,3]  R977      1.2854067981243134e-01
    z[1,2,3]  R978      -3.8726359605789185e-01
    z[1,2,3]  R979      -4.6152842044830322e-01
    z[1,2,3]  R980      -6.3248798251152039e-02
    z[1,2,3]  R981      4.4629681855440140e-02
    z[1,2,3]  R982      -2.6927703619003296e-01
    z[1,2,3]  R983      -6.9246530532836914e-02
    z[1,2,3]  R984      -2.1628679335117340e-01
    z[1,2,3]  R985      -5.7753199338912964e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R840      -1
    z[1,2,4]  R841      1
    z[1,2,4]  R846      -1.2811103463172913e-01
    z[1,2,4]  R847      9.8769381642341614e-02
    z[1,2,4]  R848      3.9514090865850449e-02
    z[1,2,4]  R849      1.7906357347965240e-01
    z[1,2,4]  R850      5.0745550543069839e-02
    z[1,2,4]  R851      -3.1483915448188782e-01
    z[1,2,4]  R852      1.2532761693000793e-01
    z[1,2,4]  R853      2.5661385059356689e-01
    z[1,2,4]  R854      -1.0935959964990616e-01
    z[1,2,4]  R855      -0.383960098028183
    z[1,2,4]  R856      -1.0561495274305344e-01
    z[1,2,4]  R857      -6.1047445982694626e-02
    z[1,2,4]  R858      -2.4713041260838509e-02
    z[1,2,4]  R859      2.0410059392452240e-01
    z[1,2,4]  R860      -2.5440940260887146e-01
    z[1,2,4]  R861      -1.5176208317279816e-01
    z[1,2,4]  R862      -1.5687119215726852e-02
    z[1,2,4]  R863      3.0090346932411194e-02
    z[1,2,4]  R864      2.2111959755420685e-01
    z[1,2,4]  R865      -1.6021193563938141e-01
    z[1,2,4]  R866      -6.7464607954025269e-01
    z[1,2,4]  R867      -7.1750218048691750e-03
    z[1,2,4]  R868      -1.0470546036958694e-01
    z[1,2,4]  R869      3.6146417260169983e-02
    z[1,2,4]  R870      4.6560221910476685e-01
    z[1,2,4]  R871      -2.4388229846954346e-01
    z[1,2,4]  R872      -0.421680748462677
    z[1,2,4]  R873      1.0703993588685989e-01
    z[1,2,4]  R874      4.0497452020645142e-01
    z[1,2,4]  R875      5.0599622726440430e-01
    z[1,2,4]  R876      -1.1077462881803513e-01
    z[1,2,4]  R877      4.4569492340087891e-01
    z[1,2,4]  R878      5.8734100311994553e-02
    z[1,2,4]  R879      2.5616383552551270e-01
    z[1,2,4]  R880      1.9701224565505981e-01
    z[1,2,4]  R881      -8.4607586264610291e-02
    z[1,2,4]  R882      -2.1708090603351593e-01
    z[1,2,4]  R883      3.2076227664947510e-01
    z[1,2,4]  R884      3.6794742941856384e-01
    z[1,2,4]  R885      7.5871430337429047e-02
    z[1,2,4]  R886      -4.4188475608825684e-01
    z[1,2,4]  R887      3.7901178002357483e-02
    z[1,2,4]  R888      -3.8594129681587219e-01
    z[1,2,4]  R889      -0.196554496884346
    z[1,2,4]  R890      -6.4528220891952515e-01
    z[1,2,4]  R891      3.7812665104866028e-01
    z[1,2,4]  R892      -2.7227890491485596e-01
    z[1,2,4]  R893      -4.9730318784713745e-01
    z[1,2,4]  R894      -4.7969445586204529e-01
    z[1,2,4]  R895      -3.1444844603538513e-01
    z[1,2,4]  R896      -2.6763904094696045e-01
    z[1,2,4]  R897      -3.6290460824966431e-01
    z[1,2,4]  R898      1.3922120630741119e-01
    z[1,2,4]  R899      2.2006702423095703e-01
    z[1,2,4]  R900      -1.4936453104019165e-01
    z[1,2,4]  R901      3.6574614048004150e-01
    z[1,2,4]  R902      -2.0260740816593170e-01
    z[1,2,4]  R903      -4.5631805062294006e-01
    z[1,2,4]  R904      -7.9937577247619629e-03
    z[1,2,4]  R905      -1.2307025492191315e-01
    z[1,2,4]  R906      -2.0108424127101898e-01
    z[1,2,4]  R907      7.9773432016372681e-01
    z[1,2,4]  R908      2.9656341299414635e-02
    z[1,2,4]  R909      -4.3531331419944763e-01
    z[1,2,4]  R910      -1.5251480042934418e-02
    z[1,2,4]  R911      1.6486409306526184e-01
    z[1,2,4]  R912      3.1822186708450317e-01
    z[1,2,4]  R913      3.8033452630043030e-01
    z[1,2,4]  R914      -2.7622884511947632e-01
    z[1,2,4]  R915      6.9422118365764618e-02
    z[1,2,4]  R916      -2.4084742367267609e-01
    z[1,2,4]  R917      2.7856758236885071e-01
    z[1,2,4]  R918      3.8693848252296448e-01
    z[1,2,4]  R919      4.1001993417739868e-01
    z[1,2,4]  R920      7.1121048927307129e-01
    z[1,2,4]  R921      3.3168014883995056e-01
    z[1,2,4]  R922      0.187080979347229
    z[1,2,4]  R923      1.0877946764230728e-01
    z[1,2,4]  R924      -2.9853085055947304e-02
    z[1,2,4]  R925      3.7477380037307739e-01
    z[1,2,4]  R926      -7.1888190507888794e-01
    z[1,2,4]  R927      -5.0630760192871094e-01
    z[1,2,4]  R928      -4.9986669421195984e-01
    z[1,2,4]  R929      -8.1424170732498169e-01
    z[1,2,4]  R930      1.8985408544540405e-01
    z[1,2,4]  R931      -4.0892388671636581e-02
    z[1,2,4]  R932      6.8054132163524628e-02
    z[1,2,4]  R933      8.9658878277987242e-04
    z[1,2,4]  R934      1.2329649180173874e-02
    z[1,2,4]  R935      -3.6802776157855988e-02
    z[1,2,4]  R936      3.6640360951423645e-01
    z[1,2,4]  R937      3.6034294962882996e-01
    z[1,2,4]  R938      5.6489914655685425e-01
    z[1,2,4]  R939      0.739863395690918
    z[1,2,4]  R940      5.7485264539718628e-01
    z[1,2,4]  R941      0.858572244644165
    z[1,2,4]  R942      4.0431788563728333e-01
    z[1,2,4]  R943      5.5548012256622314e-01
    z[1,2,4]  R944      3.0688369274139404e-01
    z[1,2,4]  R945      8.6194217205047607e-01
    z[1,2,4]  R946      -2.4086178839206696e-01
    z[1,2,4]  R947      -0.0619514137506485
    z[1,2,4]  R948      -1.5650069713592529e-01
    z[1,2,4]  R949      2.8335490822792053e-01
    z[1,2,4]  R950      -1.8668599426746368e-01
    z[1,2,4]  R951      1.1433929204940796e-01
    z[1,2,4]  R952      3.0734360218048096e-01
    z[1,2,4]  R953      3.4631672501564026e-01
    z[1,2,4]  R954      4.6331921219825745e-01
    z[1,2,4]  R955      2.0889858901500702e-01
    z[1,2,4]  R956      -5.2693516016006470e-01
    z[1,2,4]  R957      -3.3935031294822693e-01
    z[1,2,4]  R958      5.5278204381465912e-02
    z[1,2,4]  R959      -5.0832325220108032e-01
    z[1,2,4]  R960      9.5697872340679169e-02
    z[1,2,4]  R961      2.0208714902400970e-01
    z[1,2,4]  R962      3.4052771329879761e-01
    z[1,2,4]  R963      9.6334271132946014e-02
    z[1,2,4]  R964      7.3046833276748657e-01
    z[1,2,4]  R965      3.8761347532272339e-01
    z[1,2,4]  R966      -5.5150383710861206e-01
    z[1,2,4]  R967      1.8650289857760072e-03
    z[1,2,4]  R968      -1.4399588108062744e-01
    z[1,2,4]  R969      3.1894093751907349e-01
    z[1,2,4]  R970      6.0998909175395966e-02
    z[1,2,4]  R971      2.7304571866989136e-01
    z[1,2,4]  R972      2.5782135128974915e-01
    z[1,2,4]  R973      2.4912282824516296e-01
    z[1,2,4]  R974      4.3123376369476318e-01
    z[1,2,4]  R975      2.5804471969604492e-01
    z[1,2,4]  R976      3.0102011561393738e-01
    z[1,2,4]  R977      4.5850764960050583e-02
    z[1,2,4]  R978      6.2477457523345947e-01
    z[1,2,4]  R979      -6.8612575531005859e-02
    z[1,2,4]  R980      3.1580066680908203e-01
    z[1,2,4]  R981      4.3939542770385742e-01
    z[1,2,4]  R982      7.5136470794677734e-01
    z[1,2,4]  R983      5.2736049890518188e-01
    z[1,2,4]  R984      -2.9020509123802185e-01
    z[1,2,4]  R985      2.6936045289039612e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R842      -1
    z[1,2,5]  R843      1
    z[1,2,5]  R846      -1.4402790367603302e-01
    z[1,2,5]  R847      4.5146383345127106e-02
    z[1,2,5]  R848      1.1751770973205566e-01
    z[1,2,5]  R849      4.2257276177406311e-01
    z[1,2,5]  R850      1.0330075025558472e-01
    z[1,2,5]  R851      3.4574690461158752e-01
    z[1,2,5]  R852      1.7807528376579285e-01
    z[1,2,5]  R853      -1.4250756241381168e-02
    z[1,2,5]  R854      5.1383594982326031e-03
    z[1,2,5]  R855      -1.3030184805393219e-01
    z[1,2,5]  R856      4.7639212012290955e-01
    z[1,2,5]  R857      3.3835160732269287e-01
    z[1,2,5]  R858      1.3196520507335663e-01
    z[1,2,5]  R859      5.4228603839874268e-01
    z[1,2,5]  R860      0.332433819770813
    z[1,2,5]  R861      1.7465837299823761e-01
    z[1,2,5]  R862      5.2098482847213745e-01
    z[1,2,5]  R863      5.0092417001724243e-01
    z[1,2,5]  R864      3.1437876820564270e-01
    z[1,2,5]  R865      -0.0597243569791317
    z[1,2,5]  R866      -1.8792058527469635e-01
    z[1,2,5]  R867      -1.9813102483749390e-01
    z[1,2,5]  R868      -3.5396766662597656e-01
    z[1,2,5]  R869      -1.2771297991275787e-01
    z[1,2,5]  R870      -4.5337450504302979e-01
    z[1,2,5]  R871      -2.8609189391136169e-01
    z[1,2,5]  R872      -1.7389757931232452e-01
    z[1,2,5]  R873      -4.0819168090820312e-01
    z[1,2,5]  R874      -2.2313356399536133e-01
    z[1,2,5]  R875      -2.3613187670707703e-01
    z[1,2,5]  R876      1.8409633636474609e-01
    z[1,2,5]  R877      8.4336094558238983e-02
    z[1,2,5]  R878      7.1165359020233154e-01
    z[1,2,5]  R879      -1.4875005185604095e-01
    z[1,2,5]  R880      -2.2034212946891785e-01
    z[1,2,5]  R881      -2.9223549365997314e-01
    z[1,2,5]  R882      -1.1317928880453110e-01
    z[1,2,5]  R883      -2.9599642753601074e-01
    z[1,2,5]  R884      -2.4392421543598175e-01
    z[1,2,5]  R885      -1.7684239149093628e-01
    z[1,2,5]  R886      3.1072497367858887e-01
    z[1,2,5]  R887      8.6572587490081787e-02
    z[1,2,5]  R888      9.3467950820922852e-02
    z[1,2,5]  R889      2.9265916347503662e-01
    z[1,2,5]  R890      9.4040319323539734e-02
    z[1,2,5]  R891      -0.300374835729599
    z[1,2,5]  R892      -1.2064851820468903e-01
    z[1,2,5]  R893      2.1226347982883453e-01
    z[1,2,5]  R894      2.9925328493118286e-01
    z[1,2,5]  R895      -2.4028530716896057e-01
    z[1,2,5]  R896      8.8568501174449921e-02
    z[1,2,5]  R897      -1.9132284214720130e-03
    z[1,2,5]  R898      2.4026885628700256e-01
    z[1,2,5]  R899      -6.7815303802490234e-02
    z[1,2,5]  R900      1.4808064699172974e-01
    z[1,2,5]  R901      -9.7954049706459045e-02
    z[1,2,5]  R902      -4.0656840801239014e-01
    z[1,2,5]  R903      5.9593491256237030e-02
    z[1,2,5]  R904      1.0588598251342773e-01
    z[1,2,5]  R905      -6.8894013762474060e-02
    z[1,2,5]  R906      4.7643181681632996e-01
    z[1,2,5]  R907      6.1530273407697678e-02
    z[1,2,5]  R908      -0.0348796509206295
    z[1,2,5]  R909      5.9020388126373291e-01
    z[1,2,5]  R910      -1.7851024866104126e-01
    z[1,2,5]  R911      -2.3533992469310760e-01
    z[1,2,5]  R912      1.3561421632766724e-01
    z[1,2,5]  R913      -2.1379022300243378e-01
    z[1,2,5]  R914      2.2489269077777863e-01
    z[1,2,5]  R915      -2.5495597720146179e-01
    z[1,2,5]  R916      4.8909124732017517e-01
    z[1,2,5]  R917      3.2360464334487915e-01
    z[1,2,5]  R918      1.2746696174144745e-01
    z[1,2,5]  R919      -6.3453322649002075e-01
    z[1,2,5]  R920      -3.8612812757492065e-01
    z[1,2,5]  R921      -1.6239969432353973e-01
    z[1,2,5]  R922      -2.5596126914024353e-01
    z[1,2,5]  R923      -4.0585622191429138e-01
    z[1,2,5]  R924      -4.1404470801353455e-01
    z[1,2,5]  R925      -4.8035117983818054e-01
    z[1,2,5]  R926      -2.1863847970962524e-02
    z[1,2,5]  R927      -0.0313928946852684
    z[1,2,5]  R928      3.3899274468421936e-01
    z[1,2,5]  R929      7.5918912887573242e-02
    z[1,2,5]  R930      -1.5463545918464661e-02
    z[1,2,5]  R931      6.1474508047103882e-01
    z[1,2,5]  R932      3.8006502389907837e-01
    z[1,2,5]  R933      2.2136305272579193e-01
    z[1,2,5]  R934      2.3091264069080353e-01
    z[1,2,5]  R935      1.9786050915718079e-01
    z[1,2,5]  R936      1.0970976948738098e-01
    z[1,2,5]  R937      -3.9908087253570557e-01
    z[1,2,5]  R938      -4.2348787188529968e-01
    z[1,2,5]  R939      -4.9752873182296753e-01
    z[1,2,5]  R940      -1.4555752277374268e-01
    z[1,2,5]  R941      4.7893855720758438e-02
    z[1,2,5]  R942      -2.5469270348548889e-01
    z[1,2,5]  R943      -6.5651547908782959e-01
    z[1,2,5]  R944      -2.5598949193954468e-01
    z[1,2,5]  R945      -1.4976185560226440e-01
    z[1,2,5]  R946      -6.0912001132965088e-01
    z[1,2,5]  R947      9.3447407707571983e-03
    z[1,2,5]  R948      -6.2571600079536438e-02
    z[1,2,5]  R949      -4.6416290104389191e-02
    z[1,2,5]  R950      -3.6793848872184753e-01
    z[1,2,5]  R951      -1.3254623115062714e-01
    z[1,2,5]  R952      4.0630754828453064e-01
    z[1,2,5]  R953      3.9330080151557922e-01
    z[1,2,5]  R954      2.1390035748481750e-01
    z[1,2,5]  R955      3.5462772846221924e-01
    z[1,2,5]  R956      4.4799691438674927e-01
    z[1,2,5]  R957      1.1716803908348083e-01
    z[1,2,5]  R958      1.1035675555467606e-01
    z[1,2,5]  R959      4.8289110418409109e-04
    z[1,2,5]  R960      -0.0670744925737381
    z[1,2,5]  R961      3.7761366367340088e-01
    z[1,2,5]  R962      6.7873440682888031e-02
    z[1,2,5]  R963      4.2142614722251892e-01
    z[1,2,5]  R964      3.0900228023529053e-01
    z[1,2,5]  R965      3.9559951983392239e-03
    z[1,2,5]  R966      3.2422382384538651e-02
    z[1,2,5]  R967      7.8848125413060188e-03
    z[1,2,5]  R968      4.6986883878707886e-01
    z[1,2,5]  R969      6.4230072498321533e-01
    z[1,2,5]  R970      -1.2610211968421936e-01
    z[1,2,5]  R971      1.4766190946102142e-01
    z[1,2,5]  R972      1.8167679011821747e-01
    z[1,2,5]  R973      -2.7452623844146729e-01
    z[1,2,5]  R974      -8.5259661078453064e-02
    z[1,2,5]  R975      2.1010087430477142e-01
    z[1,2,5]  R976      6.7935936152935028e-02
    z[1,2,5]  R977      4.6180140227079391e-02
    z[1,2,5]  R978      4.3076780438423157e-01
    z[1,2,5]  R979      2.6315766572952271e-01
    z[1,2,5]  R980      2.5518137216567993e-01
    z[1,2,5]  R981      4.8160418868064880e-01
    z[1,2,5]  R982      6.2356390058994293e-02
    z[1,2,5]  R983      0.367984801530838
    z[1,2,5]  R984      -1.4788319170475006e-01
    z[1,2,5]  R985      1.0287480056285858e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R844      -1
    z[1,2,6]  R845      1
    z[1,2,6]  R846      3.8310918211936951e-01
    z[1,2,6]  R847      3.4259554743766785e-01
    z[1,2,6]  R848      3.3546081185340881e-01
    z[1,2,6]  R849      -0.141708105802536
    z[1,2,6]  R850      2.9049226641654968e-01
    z[1,2,6]  R851      -6.6882841289043427e-02
    z[1,2,6]  R852      -1.5954727306962013e-02
    z[1,2,6]  R853      2.4336050450801849e-01
    z[1,2,6]  R854      -4.4455981254577637e-01
    z[1,2,6]  R855      -3.1602874398231506e-01
    z[1,2,6]  R856      2.6858173310756683e-02
    z[1,2,6]  R857      1.3759815692901611e-01
    z[1,2,6]  R858      -1.9455698132514954e-01
    z[1,2,6]  R859      -2.7928901836276054e-02
    z[1,2,6]  R860      3.9691379666328430e-01
    z[1,2,6]  R861      -9.4235010445117950e-02
    z[1,2,6]  R862      -4.6372160315513611e-01
    z[1,2,6]  R863      1.3849860429763794e-01
    z[1,2,6]  R864      6.0068508610129356e-03
    z[1,2,6]  R865      1.4758543670177460e-01
    z[1,2,6]  R866      8.9115403592586517e-02
    z[1,2,6]  R867      -1.7295074462890625e-01
    z[1,2,6]  R868      4.5295480638742447e-02
    z[1,2,6]  R869      -0.429155170917511
    z[1,2,6]  R870      -9.0533353388309479e-02
    z[1,2,6]  R871      -1.8242296576499939e-01
    z[1,2,6]  R872      -1.9455881416797638e-01
    z[1,2,6]  R873      -2.1512724459171295e-01
    z[1,2,6]  R874      1.9915764033794403e-01
    z[1,2,6]  R875      1.0617773979902267e-02
    z[1,2,6]  R876      -2.6905581355094910e-01
    z[1,2,6]  R877      -1.7250110208988190e-01
    z[1,2,6]  R878      1.7161907255649567e-01
    z[1,2,6]  R879      1.5332300961017609e-01
    z[1,2,6]  R880      -7.1559733152389526e-01
    z[1,2,6]  R881      -2.6875638961791992e-01
    z[1,2,6]  R882      -3.4160980582237244e-01
    z[1,2,6]  R883      -6.4790071919560432e-03
    z[1,2,6]  R884      -8.3678871393203735e-02
    z[1,2,6]  R885      1.4622308313846588e-01
    z[1,2,6]  R886      -4.0118601173162460e-02
    z[1,2,6]  R887      -0.0113369794562459
    z[1,2,6]  R888      1.1757802218198776e-01
    z[1,2,6]  R889      -2.9616445302963257e-01
    z[1,2,6]  R890      -1.2719714641571045e-01
    z[1,2,6]  R891      3.1891950964927673e-01
    z[1,2,6]  R892      -1.4607398211956024e-01
    z[1,2,6]  R893      2.3893110454082489e-02
    z[1,2,6]  R894      -2.3453857004642487e-01
    z[1,2,6]  R895      -2.7294633910059929e-02
    z[1,2,6]  R896      1.1803147196769714e-01
    z[1,2,6]  R897      8.1077076494693756e-02
    z[1,2,6]  R898      -2.1415489912033081e-01
    z[1,2,6]  R899      -1.4506998658180237e-01
    z[1,2,6]  R900      -7.1462929248809814e-01
    z[1,2,6]  R901      -1.9606147706508636e-01
    z[1,2,6]  R902      7.2265923023223877e-02
    z[1,2,6]  R903      -4.1635073721408844e-02
    z[1,2,6]  R904      6.7983572371304035e-03
    z[1,2,6]  R905      -1.1469484865665436e-01
    z[1,2,6]  R906      -3.3874136209487915e-01
    z[1,2,6]  R907      -1.5532813034951687e-02
    z[1,2,6]  R908      -1.3888043165206909e-01
    z[1,2,6]  R909      2.2395296394824982e-01
    z[1,2,6]  R910      7.9197414219379425e-02
    z[1,2,6]  R911      1.1739090085029602e-01
    z[1,2,6]  R912      -2.0323191583156586e-01
    z[1,2,6]  R913      4.7606897354125977e-01
    z[1,2,6]  R914      -1.5488071739673615e-01
    z[1,2,6]  R915      -1.8255972862243652e-01
    z[1,2,6]  R916      -2.6468801498413086e-01
    z[1,2,6]  R917      2.0553344488143921e-01
    z[1,2,6]  R918      0.451729416847229
    z[1,2,6]  R919      -1.1594294756650925e-01
    z[1,2,6]  R920      -3.4763699769973755e-01
    z[1,2,6]  R921      -1.0595864616334438e-02
    z[1,2,6]  R922      -3.2378476113080978e-02
    z[1,2,6]  R923      3.1050181388854980e-01
    z[1,2,6]  R924      -4.1898640990257263e-01
    z[1,2,6]  R925      -1.9147852063179016e-01
    z[1,2,6]  R926      -7.6129332184791565e-02
    z[1,2,6]  R927      -7.3365390300750732e-02
    z[1,2,6]  R928      -3.4578087925910950e-01
    z[1,2,6]  R929      1.5605156123638153e-01
    z[1,2,6]  R930      2.3009985685348511e-01
    z[1,2,6]  R931      1.5051838755607605e-01
    z[1,2,6]  R932      8.7104015052318573e-02
    z[1,2,6]  R933      -1.0014154762029648e-01
    z[1,2,6]  R934      -1.4077019691467285e-01
    z[1,2,6]  R935      -8.5763055831193924e-03
    z[1,2,6]  R936      -9.0737998485565186e-02
    z[1,2,6]  R937      -2.4420207738876343e-01
    z[1,2,6]  R938      3.9023146033287048e-01
    z[1,2,6]  R939      -9.9755868315696716e-02
    z[1,2,6]  R940      4.2261913418769836e-01
    z[1,2,6]  R941      -2.6162469387054443e-01
    z[1,2,6]  R942      -1.6433786600828171e-02
    z[1,2,6]  R943      -1.2982209026813507e-01
    z[1,2,6]  R944      1.5139083564281464e-01
    z[1,2,6]  R945      -6.4163416624069214e-02
    z[1,2,6]  R946      2.1978148818016052e-01
    z[1,2,6]  R947      -2.0590944215655327e-02
    z[1,2,6]  R948      -7.2199642658233643e-02
    z[1,2,6]  R949      2.1643798053264618e-01
    z[1,2,6]  R950      -7.3277676105499268e-01
    z[1,2,6]  R951      3.1019678711891174e-01
    z[1,2,6]  R952      9.6868827939033508e-02
    z[1,2,6]  R953      -1.2527799606323242e-01
    z[1,2,6]  R954      7.4379876255989075e-02
    z[1,2,6]  R955      -1.3619431294500828e-02
    z[1,2,6]  R956      -7.2764731943607330e-02
    z[1,2,6]  R957      -7.7986407279968262e-01
    z[1,2,6]  R958      -4.7147876024246216e-01
    z[1,2,6]  R959      3.5145735740661621e-01
    z[1,2,6]  R960      -2.4567832052707672e-01
    z[1,2,6]  R961      -2.3418083786964417e-01
    z[1,2,6]  R962      -3.8220256567001343e-01
    z[1,2,6]  R963      -4.1139709949493408e-01
    z[1,2,6]  R964      -5.7040389627218246e-02
    z[1,2,6]  R965      7.9919129610061646e-02
    z[1,2,6]  R966      4.9838513135910034e-02
    z[1,2,6]  R967      -3.7416470050811768e-01
    z[1,2,6]  R968      6.8591696023941040e-01
    z[1,2,6]  R969      -3.3505210280418396e-01
    z[1,2,6]  R970      -3.5237908363342285e-01
    z[1,2,6]  R971      4.6693280339241028e-02
    z[1,2,6]  R972      7.7178376913070679e-01
    z[1,2,6]  R973      3.0427795648574829e-01
    z[1,2,6]  R974      -3.5914036631584167e-01
    z[1,2,6]  R975      6.9722110033035278e-01
    z[1,2,6]  R976      7.0770651102066040e-01
    z[1,2,6]  R977      1.9272483885288239e-02
    z[1,2,6]  R978      -1.4926255680620670e-03
    z[1,2,6]  R979      1.0365618020296097e-01
    z[1,2,6]  R980      3.9519476890563965e-01
    z[1,2,6]  R981      3.1461676955223083e-01
    z[1,2,6]  R982      -1.8477068841457367e-01
    z[1,2,6]  R983      -1.1238960921764374e-01
    z[1,2,6]  R984      -2.6112458109855652e-01
    z[1,2,6]  R985      1.3324251770973206e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R986      -1
    z[2,1,0]  R987      1
    z[2,1,0]  R1000     1.1964980512857437e-01
    z[2,1,0]  R1001     4.5635089278221130e-01
    z[2,1,0]  R1002     -0.125092551112175
    z[2,1,0]  R1003     4.7106048464775085e-01
    z[2,1,0]  R1004     -3.9310479164123535e-01
    z[2,1,0]  R1005     -3.6264759302139282e-01
    z[2,1,0]  R1006     -4.9746543169021606e-01
    z[2,1,0]  R1007     -3.1940698623657227e-01
    z[2,1,0]  R1008     -5.8063352108001709e-01
    z[2,1,0]  R1009     -2.9870501160621643e-01
    z[2,1,0]  R1010     7.2426810860633850e-02
    z[2,1,0]  R1011     -9.6556141972541809e-02
    z[2,1,0]  R1012     -3.3674961328506470e-01
    z[2,1,0]  R1013     -2.1139541268348694e-01
    z[2,1,0]  R1014     -6.4578318595886230e-01
    z[2,1,0]  R1015     -3.0570608377456665e-01
    z[2,1,0]  R1016     1.4016310870647430e-01
    z[2,1,0]  R1017     -3.0304387211799622e-01
    z[2,1,0]  R1018     -8.4870404005050659e-01
    z[2,1,0]  R1019     1.3653036952018738e-01
    z[2,1,0]  R1020     1.0207693278789520e-01
    z[2,1,0]  R1021     -4.5072686672210693e-01
    z[2,1,0]  R1022     -0.650905191898346
    z[2,1,0]  R1023     -4.1497984528541565e-01
    z[2,1,0]  R1024     2.6181656122207642e-01
    z[2,1,0]  R1025     -6.5905636548995972e-01
    z[2,1,0]  R1026     -3.6861473321914673e-01
    z[2,1,0]  R1027     -0.530968427658081
    z[2,1,0]  R1028     -5.7315403223037720e-01
    z[2,1,0]  R1029     -4.6986043453216553e-01
    z[2,1,0]  R1030     3.0096715688705444e-01
    z[2,1,0]  R1031     0.266201913356781
    z[2,1,0]  R1032     3.9871039986610413e-01
    z[2,1,0]  R1033     2.9021590948104858e-01
    z[2,1,0]  R1034     -6.1205196380615234e-01
    z[2,1,0]  R1035     0.790971040725708
    z[2,1,0]  R1036     6.4641773700714111e-02
    z[2,1,0]  R1037     -4.0440770983695984e-01
    z[2,1,0]  R1038     -0.0990544930100441
    z[2,1,0]  R1039     -1.8146137893199921e-01
    z[2,1,0]  R1040     -0.0699734315276146
    z[2,1,0]  R1041     0.806816041469574
    z[2,1,0]  R1042     -1.2725955247879028e-01
    z[2,1,0]  R1043     -2.3796859383583069e-01
    z[2,1,0]  R1044     7.5944811105728149e-02
    z[2,1,0]  R1045     -1.1690370738506317e-01
    z[2,1,0]  R1046     2.7889090776443481e-01
    z[2,1,0]  R1047     -1.2801650166511536e-01
    z[2,1,0]  R1048     -2.1942233666777611e-02
    z[2,1,0]  R1049     -3.4418243169784546e-01
    z[2,1,0]  R1050     3.4553754329681396e-01
    z[2,1,0]  R1051     -3.0406650900840759e-01
    z[2,1,0]  R1052     -3.5892143845558167e-01
    z[2,1,0]  R1053     -4.7762086987495422e-01
    z[2,1,0]  R1054     -3.4556332975625992e-02
    z[2,1,0]  R1055     -1.5605589747428894e-01
    z[2,1,0]  R1056     -3.9361652731895447e-01
    z[2,1,0]  R1057     -1.3211588561534882e-01
    z[2,1,0]  R1058     -6.5518431365489960e-02
    z[2,1,0]  R1059     -2.9194861650466919e-01
    z[2,1,0]  R1060     -6.7375445365905762e-01
    z[2,1,0]  R1061     -6.9888913631439209e-01
    z[2,1,0]  R1062     -0.594390869140625
    z[2,1,0]  R1063     -5.7361841201782227e-01
    z[2,1,0]  R1064     -8.2231032848358154e-01
    z[2,1,0]  R1065     -6.2316077947616577e-01
    z[2,1,0]  R1066     -5.8995449542999268e-01
    z[2,1,0]  R1067     -5.8598655462265015e-01
    z[2,1,0]  R1068     -0.606269121170044
    z[2,1,0]  R1069     -6.2820702791213989e-01
    z[2,1,0]  R1070     6.9167673587799072e-01
    z[2,1,0]  R1071     5.3233176469802856e-01
    z[2,1,0]  R1072     8.2345694303512573e-01
    z[2,1,0]  R1073     6.9714194536209106e-01
    z[2,1,0]  R1074     6.9522601366043091e-01
    z[2,1,0]  R1075     5.7812613248825073e-01
    z[2,1,0]  R1076     6.6528755426406860e-01
    z[2,1,0]  R1077     3.6091324687004089e-01
    z[2,1,0]  R1078     9.0225964784622192e-01
    z[2,1,0]  R1079     6.9183218479156494e-01
    z[2,1,0]  R1080     -1.3907539844512939e-01
    z[2,1,0]  R1081     -3.6842882633209229e-01
    z[2,1,0]  R1082     2.7511421591043472e-02
    z[2,1,0]  R1083     3.3677688241004944e-01
    z[2,1,0]  R1084     -3.0400383472442627e-01
    z[2,1,0]  R1085     0.129286989569664
    z[2,1,0]  R1086     2.0904533565044403e-01
    z[2,1,0]  R1087     -2.5468206405639648e-01
    z[2,1,0]  R1088     1.1293878406286240e-01
    z[2,1,0]  R1089     4.3662047386169434e-01
    z[2,1,0]  R1090     3.9613431692123413e-01
    z[2,1,0]  R1091     -3.3349683880805969e-01
    z[2,1,0]  R1092     -5.5167776346206665e-01
    z[2,1,0]  R1093     -2.6409402489662170e-01
    z[2,1,0]  R1094     -0.34183269739151
    z[2,1,0]  R1095     5.2882835268974304e-02
    z[2,1,0]  R1096     -8.3833348751068115e-01
    z[2,1,0]  R1097     -0.0875013917684555
    z[2,1,0]  R1098     1.0923463106155396e-01
    z[2,1,0]  R1099     -1.5071013569831848e-01
    z[2,1,0]  R1100     2.0982383191585541e-01
    z[2,1,0]  R1101     -2.2338643670082092e-01
    z[2,1,0]  R1102     -1.9661673903465271e-01
    z[2,1,0]  R1103     4.1472226381301880e-01
    z[2,1,0]  R1104     6.9381761550903320e-01
    z[2,1,0]  R1105     1.7683707177639008e-01
    z[2,1,0]  R1106     1.4207929372787476e-01
    z[2,1,0]  R1107     5.0470888614654541e-02
    z[2,1,0]  R1108     -1.8071976304054260e-01
    z[2,1,0]  R1109     -1.8040654063224792e-01
    z[2,1,0]  R1110     9.3746155500411987e-01
    z[2,1,0]  R1111     7.5093394517898560e-01
    z[2,1,0]  R1112     0.723858654499054
    z[2,1,0]  R1113     7.9731434583663940e-01
    z[2,1,0]  R1114     -1.7402684688568115e-01
    z[2,1,0]  R1115     4.5955085754394531e-01
    z[2,1,0]  R1116     -3.2479703426361084e-01
    z[2,1,0]  R1117     -8.4862513467669487e-03
    z[2,1,0]  R1118     -9.2845153808593750e-01
    z[2,1,0]  R1119     -8.3313882350921631e-01
    z[2,1,0]  R1120     -3.1924718618392944e-01
    z[2,1,0]  R1121     -4.2675679922103882e-01
    z[2,1,0]  R1122     8.1410235166549683e-01
    z[2,1,0]  R1123     -3.7976104021072388e-01
    z[2,1,0]  R1124     7.1696668863296509e-02
    z[2,1,0]  R1125     -4.5697745680809021e-01
    z[2,1,0]  R1126     -4.2993064969778061e-02
    z[2,1,0]  R1127     1.0481332242488861e-01
    z[2,1,0]  R1128     -1.7297340929508209e-01
    z[2,1,0]  R1129     4.1590067744255066e-01
    z[2,1,0]  R1130     3.9963892102241516e-01
    z[2,1,0]  R1131     -4.4773986935615540e-01
    z[2,1,0]  R1132     2.3669132962822914e-02
    z[2,1,0]  R1133     -1.5191610157489777e-01
    z[2,1,0]  R1134     -3.5037714242935181e-01
    z[2,1,0]  R1135     -1.9325231015682220e-01
    z[2,1,0]  R1136     3.1451320648193359e-01
    z[2,1,0]  R1137     -3.1922420859336853e-01
    z[2,1,0]  R1138     2.4484528601169586e-01
    z[2,1,0]  R1139     -4.3561407923698425e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R988      -1
    z[2,1,1]  R989      1
    z[2,1,1]  R1000     5.9983724355697632e-01
    z[2,1,1]  R1001     7.2173017263412476e-01
    z[2,1,1]  R1002     4.3486005067825317e-01
    z[2,1,1]  R1003     2.1249566972255707e-01
    z[2,1,1]  R1004     -2.1284019947052002e-01
    z[2,1,1]  R1005     -0.332770437002182
    z[2,1,1]  R1006     -3.5462863743305206e-02
    z[2,1,1]  R1007     -8.2390010356903076e-02
    z[2,1,1]  R1008     -0.181112602353096
    z[2,1,1]  R1009     -6.3754066824913025e-02
    z[2,1,1]  R1010     3.5394972562789917e-01
    z[2,1,1]  R1011     8.4005340933799744e-02
    z[2,1,1]  R1012     -4.2696595191955566e-02
    z[2,1,1]  R1013     0.0811346247792244
    z[2,1,1]  R1014     4.2347289621829987e-02
    z[2,1,1]  R1015     -9.2981308698654175e-02
    z[2,1,1]  R1016     -2.3038220405578613e-01
    z[2,1,1]  R1017     -2.3555132746696472e-01
    z[2,1,1]  R1018     -9.0188965201377869e-02
    z[2,1,1]  R1019     -2.9894340783357620e-02
    z[2,1,1]  R1020     -9.5013357698917389e-02
    z[2,1,1]  R1021     -8.7583720684051514e-01
    z[2,1,1]  R1022     -7.2417879104614258e-01
    z[2,1,1]  R1023     4.2553361505270004e-02
    z[2,1,1]  R1024     -2.7154216170310974e-01
    z[2,1,1]  R1025     -5.9841054677963257e-01
    z[2,1,1]  R1026     -7.6666903495788574e-01
    z[2,1,1]  R1027     -6.2934494018554688e-01
    z[2,1,1]  R1028     -5.9415531158447266e-01
    z[2,1,1]  R1029     -3.0684208869934082e-01
    z[2,1,1]  R1030     -4.1537608951330185e-02
    z[2,1,1]  R1031     -1.8900800496339798e-02
    z[2,1,1]  R1032     -3.6691910028457642e-01
    z[2,1,1]  R1033     -4.4243744015693665e-01
    z[2,1,1]  R1034     -3.1237161159515381e-01
    z[2,1,1]  R1035     0.0637897253036499
    z[2,1,1]  R1036     -0.583785355091095
    z[2,1,1]  R1037     -6.6741967201232910e-01
    z[2,1,1]  R1038     -4.8305392265319824e-01
    z[2,1,1]  R1039     -6.9934207201004028e-01
    z[2,1,1]  R1040     4.1462263464927673e-01
    z[2,1,1]  R1041     2.4976047873497009e-01
    z[2,1,1]  R1042     4.0262803435325623e-01
    z[2,1,1]  R1043     -3.2162415981292725e-01
    z[2,1,1]  R1044     -3.1465274095535278e-01
    z[2,1,1]  R1045     -8.8595676422119141e-01
    z[2,1,1]  R1046     4.3278205394744873e-01
    z[2,1,1]  R1047     3.2780739665031433e-01
    z[2,1,1]  R1048     -0.562740683555603
    z[2,1,1]  R1049     -4.7032970190048218e-01
    z[2,1,1]  R1050     4.2216780781745911e-01
    z[2,1,1]  R1051     -6.2297242879867554e-01
    z[2,1,1]  R1052     -3.4845784306526184e-01
    z[2,1,1]  R1053     -6.8859666585922241e-01
    z[2,1,1]  R1054     -4.9920460581779480e-01
    z[2,1,1]  R1055     -4.4212073087692261e-01
    z[2,1,1]  R1056     -2.2997401654720306e-01
    z[2,1,1]  R1057     -7.0381003618240356e-01
    z[2,1,1]  R1058     -6.4303326606750488e-01
    z[2,1,1]  R1059     -5.4580366611480713e-01
    z[2,1,1]  R1060     5.6581604480743408e-01
    z[2,1,1]  R1061     4.6107420325279236e-01
    z[2,1,1]  R1062     5.8846014738082886e-01
    z[2,1,1]  R1063     6.0418677330017090e-01
    z[2,1,1]  R1064     4.1971653699874878e-01
    z[2,1,1]  R1065     4.7782710194587708e-01
    z[2,1,1]  R1066     -0.0804959312081337
    z[2,1,1]  R1067     -1.3034315407276154e-01
    z[2,1,1]  R1068     4.8019781708717346e-01
    z[2,1,1]  R1069     4.2548415064811707e-01
    z[2,1,1]  R1070     1.3635043799877167e-01
    z[2,1,1]  R1071     1.9816307723522186e-01
    z[2,1,1]  R1072     1.8716986477375031e-01
    z[2,1,1]  R1073     3.2812580466270447e-01
    z[2,1,1]  R1074     4.3138720095157623e-02
    z[2,1,1]  R1075     3.2618638873100281e-01
    z[2,1,1]  R1076     3.6346804350614548e-02
    z[2,1,1]  R1077     2.0694455131888390e-02
    z[2,1,1]  R1078     1.6249081492424011e-01
    z[2,1,1]  R1079     3.1555914878845215e-01
    z[2,1,1]  R1080     -5.7555562257766724e-01
    z[2,1,1]  R1081     2.9388232156634331e-02
    z[2,1,1]  R1082     1.3200907409191132e-01
    z[2,1,1]  R1083     7.3984724283218384e-01
    z[2,1,1]  R1084     2.4440020322799683e-02
    z[2,1,1]  R1085     -7.2986435890197754e-01
    z[2,1,1]  R1086     -0.655773401260376
    z[2,1,1]  R1087     1.0935997962951660e-01
    z[2,1,1]  R1088     4.1971331834793091e-01
    z[2,1,1]  R1089     -6.3583093881607056e-01
    z[2,1,1]  R1090     -4.6782466769218445e-01
    z[2,1,1]  R1091     -7.1851402521133423e-01
    z[2,1,1]  R1092     -3.1521740555763245e-01
    z[2,1,1]  R1093     -4.8395147919654846e-01
    z[2,1,1]  R1094     -5.0472050905227661e-01
    z[2,1,1]  R1095     -7.5323802232742310e-01
    z[2,1,1]  R1096     -1.8055382370948792e-01
    z[2,1,1]  R1097     1.0876475274562836e-01
    z[2,1,1]  R1098     2.4585419893264771e-01
    z[2,1,1]  R1099     4.6252235770225525e-01
    z[2,1,1]  R1100     -3.5149574279785156e-01
    z[2,1,1]  R1101     -3.2818189263343811e-01
    z[2,1,1]  R1102     -4.5154190063476562e-01
    z[2,1,1]  R1103     -7.6954740285873413e-01
    z[2,1,1]  R1104     -1.4450900256633759e-01
    z[2,1,1]  R1105     -6.8819504976272583e-01
    z[2,1,1]  R1106     2.1572996675968170e-01
    z[2,1,1]  R1107     3.8106867671012878e-01
    z[2,1,1]  R1108     2.7672821283340454e-01
    z[2,1,1]  R1109     -0.621740996837616
    z[2,1,1]  R1110     -0.0515022911131382
    z[2,1,1]  R1111     -2.8066793084144592e-01
    z[2,1,1]  R1112     -2.8422072529792786e-01
    z[2,1,1]  R1113     -2.2228258848190308e-01
    z[2,1,1]  R1114     -5.4552555084228516e-01
    z[2,1,1]  R1115     -2.5604084134101868e-01
    z[2,1,1]  R1116     -8.0818790197372437e-01
    z[2,1,1]  R1117     -8.4745258092880249e-01
    z[2,1,1]  R1118     -1.9298858940601349e-01
    z[2,1,1]  R1119     -1.9169786944985390e-02
    z[2,1,1]  R1120     -1.4883506298065186e-01
    z[2,1,1]  R1121     -3.3743056654930115e-01
    z[2,1,1]  R1122     -3.2267636060714722e-01
    z[2,1,1]  R1123     -3.5981380939483643e-01
    z[2,1,1]  R1124     -5.5066061019897461e-01
    z[2,1,1]  R1125     -8.3241373300552368e-01
    z[2,1,1]  R1126     -4.0126565098762512e-01
    z[2,1,1]  R1127     -0.325792133808136
    z[2,1,1]  R1128     3.9969906210899353e-01
    z[2,1,1]  R1129     -6.9523072242736816e-01
    z[2,1,1]  R1130     -2.1889136731624603e-01
    z[2,1,1]  R1131     -7.2267115116119385e-01
    z[2,1,1]  R1132     -3.3751270174980164e-01
    z[2,1,1]  R1133     5.9211593866348267e-01
    z[2,1,1]  R1134     2.6231136918067932e-01
    z[2,1,1]  R1135     4.2199438810348511e-01
    z[2,1,1]  R1136     8.6712735891342163e-01
    z[2,1,1]  R1137     9.4980537891387939e-02
    z[2,1,1]  R1138     -6.7621898651123047e-01
    z[2,1,1]  R1139     2.8200818225741386e-02
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R990      -1
    z[2,1,2]  R991      1
    z[2,1,2]  R1000     3.0667799711227417e-01
    z[2,1,2]  R1001     8.7701253592967987e-02
    z[2,1,2]  R1002     5.4213011264801025e-01
    z[2,1,2]  R1003     -1.9859565794467926e-01
    z[2,1,2]  R1004     6.8247979879379272e-01
    z[2,1,2]  R1005     5.1311510801315308e-01
    z[2,1,2]  R1006     5.7735347747802734e-01
    z[2,1,2]  R1007     5.7280987501144409e-01
    z[2,1,2]  R1008     3.1305974721908569e-01
    z[2,1,2]  R1009     9.0186780691146851e-01
    z[2,1,2]  R1010     4.5689836144447327e-01
    z[2,1,2]  R1011     -3.0133244395256042e-01
    z[2,1,2]  R1012     -1.7264898121356964e-01
    z[2,1,2]  R1013     -3.2008981704711914e-01
    z[2,1,2]  R1014     -3.3835846930742264e-02
    z[2,1,2]  R1015     -8.4999807178974152e-02
    z[2,1,2]  R1016     -5.3778284788131714e-01
    z[2,1,2]  R1017     -1.6220824420452118e-01
    z[2,1,2]  R1018     4.5658446848392487e-02
    z[2,1,2]  R1019     -0.291608065366745
    z[2,1,2]  R1020     -0.0314226932823658
    z[2,1,2]  R1021     -1.0495898127555847e-01
    z[2,1,2]  R1022     9.9670603871345520e-02
    z[2,1,2]  R1023     -7.1303009986877441e-01
    z[2,1,2]  R1024     -9.3205086886882782e-02
    z[2,1,2]  R1025     1.2623761594295502e-01
    z[2,1,2]  R1026     -7.5511775910854340e-02
    z[2,1,2]  R1027     1.6558539867401123e-01
    z[2,1,2]  R1028     1.6087324917316437e-01
    z[2,1,2]  R1029     -5.3906667232513428e-01
    z[2,1,2]  R1030     1.5534909069538116e-01
    z[2,1,2]  R1031     1.7812253534793854e-01
    z[2,1,2]  R1032     -7.1083754301071167e-02
    z[2,1,2]  R1033     -3.1101605296134949e-01
    z[2,1,2]  R1034     5.8487743139266968e-01
    z[2,1,2]  R1035     -2.8012701869010925e-01
    z[2,1,2]  R1036     0.524462878704071
    z[2,1,2]  R1037     1.7696005105972290e-01
    z[2,1,2]  R1038     3.4141331911087036e-01
    z[2,1,2]  R1039     5.0322753190994263e-01
    z[2,1,2]  R1040     4.8755025863647461e-01
    z[2,1,2]  R1041     -2.0616883039474487e-01
    z[2,1,2]  R1042     3.0896782875061035e-01
    z[2,1,2]  R1043     4.5889967679977417e-01
    z[2,1,2]  R1044     8.2162946462631226e-01
    z[2,1,2]  R1045     3.1508103013038635e-01
    z[2,1,2]  R1046     -2.0668437704443932e-02
    z[2,1,2]  R1047     -4.0846887230873108e-01
    z[2,1,2]  R1048     -4.7836822271347046e-01
    z[2,1,2]  R1049     -6.8681873381137848e-04
    z[2,1,2]  R1050     -3.6278583109378815e-02
    z[2,1,2]  R1051     7.0591771602630615e-01
    z[2,1,2]  R1052     1.5450893342494965e-01
    z[2,1,2]  R1053     -3.6272511351853609e-04
    z[2,1,2]  R1054     6.5159320831298828e-01
    z[2,1,2]  R1055     5.0417190790176392e-01
    z[2,1,2]  R1056     3.4218469262123108e-01
    z[2,1,2]  R1057     2.3716755211353302e-01
    z[2,1,2]  R1058     6.0096681118011475e-01
    z[2,1,2]  R1059     -4.2711740732192993e-01
    z[2,1,2]  R1060     -1.8583782017230988e-01
    z[2,1,2]  R1061     4.0435454249382019e-01
    z[2,1,2]  R1062     4.9485184252262115e-02
    z[2,1,2]  R1063     3.0327681452035904e-02
    z[2,1,2]  R1064     1.4825256168842316e-01
    z[2,1,2]  R1065     3.9322644472122192e-01
    z[2,1,2]  R1066     3.4202730655670166e-01
    z[2,1,2]  R1067     3.8173198699951172e-01
    z[2,1,2]  R1068     8.3235532045364380e-02
    z[2,1,2]  R1069     3.8509148359298706e-01
    z[2,1,2]  R1070     3.6533221602439880e-01
    z[2,1,2]  R1071     6.9461631774902344e-01
    z[2,1,2]  R1072     4.7899049520492554e-01
    z[2,1,2]  R1073     2.2634410858154297e-01
    z[2,1,2]  R1074     4.1579627990722656e-01
    z[2,1,2]  R1075     4.0311416983604431e-01
    z[2,1,2]  R1076     2.3965889215469360e-01
    z[2,1,2]  R1077     7.5463271141052246e-01
    z[2,1,2]  R1078     6.9754309952259064e-02
    z[2,1,2]  R1079     4.0157452225685120e-01
    z[2,1,2]  R1080     0.372557133436203
    z[2,1,2]  R1081     -1.4441660046577454e-01
    z[2,1,2]  R1082     -5.6320565938949585e-01
    z[2,1,2]  R1083     -3.5228511691093445e-01
    z[2,1,2]  R1084     -3.0513930320739746e-01
    z[2,1,2]  R1085     4.9704313278198242e-01
    z[2,1,2]  R1086     4.5590788125991821e-01
    z[2,1,2]  R1087     -6.6915452480316162e-01
    z[2,1,2]  R1088     -5.5253100395202637e-01
    z[2,1,2]  R1089     3.0519595742225647e-01
    z[2,1,2]  R1090     6.9835972785949707e-01
    z[2,1,2]  R1091     2.0382064580917358e-01
    z[2,1,2]  R1092     -2.1288146078586578e-01
    z[2,1,2]  R1093     6.2886893749237061e-01
    z[2,1,2]  R1094     1.3575246930122375e-01
    z[2,1,2]  R1095     4.6135470271110535e-01
    z[2,1,2]  R1096     -2.4484296143054962e-01
    z[2,1,2]  R1097     -2.1331357955932617e-01
    z[2,1,2]  R1098     -4.6741876006126404e-01
    z[2,1,2]  R1099     -6.8512326478958130e-01
    z[2,1,2]  R1100     6.0631680488586426e-01
    z[2,1,2]  R1101     8.0816090106964111e-01
    z[2,1,2]  R1102     7.1812593936920166e-01
    z[2,1,2]  R1103     -1.1645172536373138e-01
    z[2,1,2]  R1104     -2.2195224463939667e-01
    z[2,1,2]  R1105     -3.4744247794151306e-01
    z[2,1,2]  R1106     -6.0679125785827637e-01
    z[2,1,2]  R1107     -3.5761341452598572e-01
    z[2,1,2]  R1108     -1.6917374730110168e-01
    z[2,1,2]  R1109     -3.7453171610832214e-01
    z[2,1,2]  R1110     -2.8504827991127968e-02
    z[2,1,2]  R1111     2.3543396592140198e-01
    z[2,1,2]  R1112     5.1484811305999756e-01
    z[2,1,2]  R1113     1.7536431550979614e-01
    z[2,1,2]  R1114     3.4148257970809937e-01
    z[2,1,2]  R1115     5.8263164758682251e-01
    z[2,1,2]  R1116     1.6801603138446808e-01
    z[2,1,2]  R1117     -9.2448271811008453e-02
    z[2,1,2]  R1118     -7.8539937734603882e-02
    z[2,1,2]  R1119     1.2315201759338379e-01
    z[2,1,2]  R1120     6.9656980037689209e-01
    z[2,1,2]  R1121     2.5004261732101440e-01
    z[2,1,2]  R1122     2.6816296577453613e-01
    z[2,1,2]  R1123     3.6138707399368286e-01
    z[2,1,2]  R1124     4.6646651625633240e-01
    z[2,1,2]  R1125     4.0568541735410690e-02
    z[2,1,2]  R1126     7.9084801673889160e-01
    z[2,1,2]  R1127     6.8234455585479736e-01
    z[2,1,2]  R1128     -3.0624341964721680e-01
    z[2,1,2]  R1129     -4.8970249295234680e-01
    z[2,1,2]  R1130     6.5157341957092285e-01
    z[2,1,2]  R1131     1.8652480095624924e-02
    z[2,1,2]  R1132     6.6115683317184448e-01
    z[2,1,2]  R1133     -1.5419077873229980e-01
    z[2,1,2]  R1134     -1.6393500566482544e-01
    z[2,1,2]  R1135     -5.4945224523544312e-01
    z[2,1,2]  R1136     -1.7873485386371613e-01
    z[2,1,2]  R1137     -2.0642848312854767e-01
    z[2,1,2]  R1138     -3.5644856095314026e-01
    z[2,1,2]  R1139     -0.48117595911026
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R992      -1
    z[2,1,3]  R993      1
    z[2,1,3]  R1000     9.3609832227230072e-02
    z[2,1,3]  R1001     -2.1035907790064812e-02
    z[2,1,3]  R1002     1.3036954402923584e-01
    z[2,1,3]  R1003     2.0052876323461533e-02
    z[2,1,3]  R1004     -0.495135635137558
    z[2,1,3]  R1005     -3.0368411540985107e-01
    z[2,1,3]  R1006     -0.511141300201416
    z[2,1,3]  R1007     -7.0996415615081787e-01
    z[2,1,3]  R1008     -6.7732381820678711e-01
    z[2,1,3]  R1009     -2.2971355915069580e-01
    z[2,1,3]  R1010     7.1147501468658447e-01
    z[2,1,3]  R1011     -7.3761200904846191e-01
    z[2,1,3]  R1012     -0.451924204826355
    z[2,1,3]  R1013     -2.0343993604183197e-01
    z[2,1,3]  R1014     -2.2310629487037659e-01
    z[2,1,3]  R1015     -2.8772500157356262e-01
    z[2,1,3]  R1016     -6.3988798856735229e-01
    z[2,1,3]  R1017     -2.6446914672851562e-01
    z[2,1,3]  R1018     -2.9471242427825928e-01
    z[2,1,3]  R1019     -3.5488110780715942e-01
    z[2,1,3]  R1020     7.0867466926574707e-01
    z[2,1,3]  R1021     1.1995280534029007e-01
    z[2,1,3]  R1022     9.1283574700355530e-02
    z[2,1,3]  R1023     -4.3391120433807373e-01
    z[2,1,3]  R1024     3.7661322951316833e-01
    z[2,1,3]  R1025     2.5445926189422607e-01
    z[2,1,3]  R1026     0.0413551852107048
    z[2,1,3]  R1027     6.5296448767185211e-02
    z[2,1,3]  R1028     1.6322822868824005e-01
    z[2,1,3]  R1029     -4.7423759102821350e-01
    z[2,1,3]  R1030     6.3237917423248291e-01
    z[2,1,3]  R1031     3.9997085928916931e-01
    z[2,1,3]  R1032     6.8104404211044312e-01
    z[2,1,3]  R1033     4.9130213260650635e-01
    z[2,1,3]  R1034     -3.3424523472785950e-01
    z[2,1,3]  R1035     2.3141415417194366e-01
    z[2,1,3]  R1036     -3.3661547303199768e-01
    z[2,1,3]  R1037     5.9688467532396317e-02
    z[2,1,3]  R1038     -8.9241966605186462e-02
    z[2,1,3]  R1039     2.6097431778907776e-01
    z[2,1,3]  R1040     5.2706265449523926e-01
    z[2,1,3]  R1041     3.2264092564582825e-01
    z[2,1,3]  R1042     1.1933559924364090e-01
    z[2,1,3]  R1043     5.2976008504629135e-02
    z[2,1,3]  R1044     -0.276328444480896
    z[2,1,3]  R1045     -5.9998266398906708e-02
    z[2,1,3]  R1046     1.9840340316295624e-01
    z[2,1,3]  R1047     -6.9231164455413818e-01
    z[2,1,3]  R1048     -3.6303135752677917e-01
    z[2,1,3]  R1049     -2.5195494294166565e-01
    z[2,1,3]  R1050     3.2401415705680847e-01
    z[2,1,3]  R1051     1.2854067981243134e-01
    z[2,1,3]  R1052     -3.8726359605789185e-01
    z[2,1,3]  R1053     -4.6152842044830322e-01
    z[2,1,3]  R1054     -6.3248798251152039e-02
    z[2,1,3]  R1055     4.4629681855440140e-02
    z[2,1,3]  R1056     -2.6927703619003296e-01
    z[2,1,3]  R1057     -6.9246530532836914e-02
    z[2,1,3]  R1058     -2.1628679335117340e-01
    z[2,1,3]  R1059     -5.7753199338912964e-01
    z[2,1,3]  R1060     8.6268782615661621e-02
    z[2,1,3]  R1061     7.9351119697093964e-02
    z[2,1,3]  R1062     -4.1238284111022949e-01
    z[2,1,3]  R1063     0.27255779504776
    z[2,1,3]  R1064     -1.6743110120296478e-01
    z[2,1,3]  R1065     -7.4745684862136841e-02
    z[2,1,3]  R1066     -0.693411111831665
    z[2,1,3]  R1067     -6.0715156793594360e-01
    z[2,1,3]  R1068     -4.3046516180038452e-01
    z[2,1,3]  R1069     1.0837700963020325e-01
    z[2,1,3]  R1070     3.6152294278144836e-01
    z[2,1,3]  R1071     2.4025149643421173e-01
    z[2,1,3]  R1072     -3.9704661816358566e-02
    z[2,1,3]  R1073     1.3632193207740784e-01
    z[2,1,3]  R1074     9.5584288239479065e-02
    z[2,1,3]  R1075     5.7831990718841553e-01
    z[2,1,3]  R1076     1.0920634120702744e-01
    z[2,1,3]  R1077     1.6979576647281647e-01
    z[2,1,3]  R1078     -8.3034120500087738e-02
    z[2,1,3]  R1079     4.5772495865821838e-01
    z[2,1,3]  R1080     -1.1041700094938278e-01
    z[2,1,3]  R1081     8.7938672304153442e-01
    z[2,1,3]  R1082     7.2547090053558350e-01
    z[2,1,3]  R1083     1.1537463963031769e-01
    z[2,1,3]  R1084     6.1914795637130737e-01
    z[2,1,3]  R1085     0.170075923204422
    z[2,1,3]  R1086     2.6926058530807495e-01
    z[2,1,3]  R1087     5.0105082988739014e-01
    z[2,1,3]  R1088     5.0233274698257446e-01
    z[2,1,3]  R1089     5.8124684728682041e-03
    z[2,1,3]  R1090     1.3400685787200928e-01
    z[2,1,3]  R1091     3.0896854400634766e-01
    z[2,1,3]  R1092     -1.0778423398733139e-01
    z[2,1,3]  R1093     4.3510311841964722e-01
    z[2,1,3]  R1094     -1.0263931006193161e-01
    z[2,1,3]  R1095     -2.2846798598766327e-01
    z[2,1,3]  R1096     1.6738660633563995e-01
    z[2,1,3]  R1097     8.6282485723495483e-01
    z[2,1,3]  R1098     7.1221959590911865e-01
    z[2,1,3]  R1099     4.8533996939659119e-01
    z[2,1,3]  R1100     -4.1398438811302185e-01
    z[2,1,3]  R1101     4.2451298236846924e-01
    z[2,1,3]  R1102     -2.6501944661140442e-01
    z[2,1,3]  R1103     -1.0121706128120422e-01
    z[2,1,3]  R1104     -8.4021300077438354e-02
    z[2,1,3]  R1105     1.9870984554290771e-01
    z[2,1,3]  R1106     6.7457318305969238e-01
    z[2,1,3]  R1107     6.5682178735733032e-01
    z[2,1,3]  R1108     6.9819372892379761e-01
    z[2,1,3]  R1109     0.532219648361206
    z[2,1,3]  R1110     1.5586647391319275e-01
    z[2,1,3]  R1111     4.0449678897857666e-01
    z[2,1,3]  R1112     -8.4880597889423370e-02
    z[2,1,3]  R1113     4.5831638574600220e-01
    z[2,1,3]  R1114     2.3949561640620232e-02
    z[2,1,3]  R1115     4.4943434000015259e-01
    z[2,1,3]  R1116     -0.0392412431538105
    z[2,1,3]  R1117     2.4432432651519775e-01
    z[2,1,3]  R1118     2.8851801156997681e-01
    z[2,1,3]  R1119     5.0724571943283081e-01
    z[2,1,3]  R1120     9.2477187514305115e-02
    z[2,1,3]  R1121     -3.3023558557033539e-02
    z[2,1,3]  R1122     3.7392783164978027e-01
    z[2,1,3]  R1123     -8.7873362004756927e-02
    z[2,1,3]  R1124     -6.6005373001098633e-01
    z[2,1,3]  R1125     -1.6353135928511620e-02
    z[2,1,3]  R1126     -2.2524943947792053e-01
    z[2,1,3]  R1127     1.6651917248964310e-02
    z[2,1,3]  R1128     7.5210946798324585e-01
    z[2,1,3]  R1129     -2.6873955503106117e-02
    z[2,1,3]  R1130     -2.3450862616300583e-02
    z[2,1,3]  R1131     2.2883121669292450e-01
    z[2,1,3]  R1132     2.7994289994239807e-01
    z[2,1,3]  R1133     -1.3547608256340027e-01
    z[2,1,3]  R1134     7.6073713600635529e-02
    z[2,1,3]  R1135     5.8836966753005981e-01
    z[2,1,3]  R1136     1.2514644861221313e-01
    z[2,1,3]  R1137     7.5729668140411377e-01
    z[2,1,3]  R1138     8.8596068322658539e-02
    z[2,1,3]  R1139     4.1238108277320862e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R994      -1
    z[2,1,4]  R995      1
    z[2,1,4]  R1000     -7.1888190507888794e-01
    z[2,1,4]  R1001     -5.0630760192871094e-01
    z[2,1,4]  R1002     -4.9986669421195984e-01
    z[2,1,4]  R1003     -8.1424170732498169e-01
    z[2,1,4]  R1004     1.8985408544540405e-01
    z[2,1,4]  R1005     -4.0892388671636581e-02
    z[2,1,4]  R1006     6.8054132163524628e-02
    z[2,1,4]  R1007     8.9658878277987242e-04
    z[2,1,4]  R1008     1.2329649180173874e-02
    z[2,1,4]  R1009     -3.6802776157855988e-02
    z[2,1,4]  R1010     3.6640360951423645e-01
    z[2,1,4]  R1011     3.6034294962882996e-01
    z[2,1,4]  R1012     5.6489914655685425e-01
    z[2,1,4]  R1013     0.739863395690918
    z[2,1,4]  R1014     5.7485264539718628e-01
    z[2,1,4]  R1015     0.858572244644165
    z[2,1,4]  R1016     4.0431788563728333e-01
    z[2,1,4]  R1017     5.5548012256622314e-01
    z[2,1,4]  R1018     3.0688369274139404e-01
    z[2,1,4]  R1019     8.6194217205047607e-01
    z[2,1,4]  R1020     -2.4086178839206696e-01
    z[2,1,4]  R1021     -0.0619514137506485
    z[2,1,4]  R1022     -1.5650069713592529e-01
    z[2,1,4]  R1023     2.8335490822792053e-01
    z[2,1,4]  R1024     -1.8668599426746368e-01
    z[2,1,4]  R1025     1.1433929204940796e-01
    z[2,1,4]  R1026     3.0734360218048096e-01
    z[2,1,4]  R1027     3.4631672501564026e-01
    z[2,1,4]  R1028     4.6331921219825745e-01
    z[2,1,4]  R1029     2.0889858901500702e-01
    z[2,1,4]  R1030     -5.2693516016006470e-01
    z[2,1,4]  R1031     -3.3935031294822693e-01
    z[2,1,4]  R1032     5.5278204381465912e-02
    z[2,1,4]  R1033     -5.0832325220108032e-01
    z[2,1,4]  R1034     9.5697872340679169e-02
    z[2,1,4]  R1035     2.0208714902400970e-01
    z[2,1,4]  R1036     3.4052771329879761e-01
    z[2,1,4]  R1037     9.6334271132946014e-02
    z[2,1,4]  R1038     7.3046833276748657e-01
    z[2,1,4]  R1039     3.8761347532272339e-01
    z[2,1,4]  R1040     -5.5150383710861206e-01
    z[2,1,4]  R1041     1.8650289857760072e-03
    z[2,1,4]  R1042     -1.4399588108062744e-01
    z[2,1,4]  R1043     3.1894093751907349e-01
    z[2,1,4]  R1044     6.0998909175395966e-02
    z[2,1,4]  R1045     2.7304571866989136e-01
    z[2,1,4]  R1046     2.5782135128974915e-01
    z[2,1,4]  R1047     2.4912282824516296e-01
    z[2,1,4]  R1048     4.3123376369476318e-01
    z[2,1,4]  R1049     2.5804471969604492e-01
    z[2,1,4]  R1050     3.0102011561393738e-01
    z[2,1,4]  R1051     4.5850764960050583e-02
    z[2,1,4]  R1052     6.2477457523345947e-01
    z[2,1,4]  R1053     -6.8612575531005859e-02
    z[2,1,4]  R1054     3.1580066680908203e-01
    z[2,1,4]  R1055     4.3939542770385742e-01
    z[2,1,4]  R1056     7.5136470794677734e-01
    z[2,1,4]  R1057     5.2736049890518188e-01
    z[2,1,4]  R1058     -2.9020509123802185e-01
    z[2,1,4]  R1059     2.6936045289039612e-01
    z[2,1,4]  R1060     -1.2811103463172913e-01
    z[2,1,4]  R1061     9.8769381642341614e-02
    z[2,1,4]  R1062     3.9514090865850449e-02
    z[2,1,4]  R1063     1.7906357347965240e-01
    z[2,1,4]  R1064     5.0745550543069839e-02
    z[2,1,4]  R1065     -3.1483915448188782e-01
    z[2,1,4]  R1066     1.2532761693000793e-01
    z[2,1,4]  R1067     2.5661385059356689e-01
    z[2,1,4]  R1068     -1.0935959964990616e-01
    z[2,1,4]  R1069     -0.383960098028183
    z[2,1,4]  R1070     -1.0561495274305344e-01
    z[2,1,4]  R1071     -6.1047445982694626e-02
    z[2,1,4]  R1072     -2.4713041260838509e-02
    z[2,1,4]  R1073     2.0410059392452240e-01
    z[2,1,4]  R1074     -2.5440940260887146e-01
    z[2,1,4]  R1075     -1.5176208317279816e-01
    z[2,1,4]  R1076     -1.5687119215726852e-02
    z[2,1,4]  R1077     3.0090346932411194e-02
    z[2,1,4]  R1078     2.2111959755420685e-01
    z[2,1,4]  R1079     -1.6021193563938141e-01
    z[2,1,4]  R1080     -6.7464607954025269e-01
    z[2,1,4]  R1081     -7.1750218048691750e-03
    z[2,1,4]  R1082     -1.0470546036958694e-01
    z[2,1,4]  R1083     3.6146417260169983e-02
    z[2,1,4]  R1084     4.6560221910476685e-01
    z[2,1,4]  R1085     -2.4388229846954346e-01
    z[2,1,4]  R1086     -0.421680748462677
    z[2,1,4]  R1087     1.0703993588685989e-01
    z[2,1,4]  R1088     4.0497452020645142e-01
    z[2,1,4]  R1089     5.0599622726440430e-01
    z[2,1,4]  R1090     -1.1077462881803513e-01
    z[2,1,4]  R1091     4.4569492340087891e-01
    z[2,1,4]  R1092     5.8734100311994553e-02
    z[2,1,4]  R1093     2.5616383552551270e-01
    z[2,1,4]  R1094     1.9701224565505981e-01
    z[2,1,4]  R1095     -8.4607586264610291e-02
    z[2,1,4]  R1096     -2.1708090603351593e-01
    z[2,1,4]  R1097     3.2076227664947510e-01
    z[2,1,4]  R1098     3.6794742941856384e-01
    z[2,1,4]  R1099     7.5871430337429047e-02
    z[2,1,4]  R1100     -4.4188475608825684e-01
    z[2,1,4]  R1101     3.7901178002357483e-02
    z[2,1,4]  R1102     -3.8594129681587219e-01
    z[2,1,4]  R1103     -0.196554496884346
    z[2,1,4]  R1104     -6.4528220891952515e-01
    z[2,1,4]  R1105     3.7812665104866028e-01
    z[2,1,4]  R1106     -2.7227890491485596e-01
    z[2,1,4]  R1107     -4.9730318784713745e-01
    z[2,1,4]  R1108     -4.7969445586204529e-01
    z[2,1,4]  R1109     -3.1444844603538513e-01
    z[2,1,4]  R1110     -2.6763904094696045e-01
    z[2,1,4]  R1111     -3.6290460824966431e-01
    z[2,1,4]  R1112     1.3922120630741119e-01
    z[2,1,4]  R1113     2.2006702423095703e-01
    z[2,1,4]  R1114     -1.4936453104019165e-01
    z[2,1,4]  R1115     3.6574614048004150e-01
    z[2,1,4]  R1116     -2.0260740816593170e-01
    z[2,1,4]  R1117     -4.5631805062294006e-01
    z[2,1,4]  R1118     -7.9937577247619629e-03
    z[2,1,4]  R1119     -1.2307025492191315e-01
    z[2,1,4]  R1120     -2.0108424127101898e-01
    z[2,1,4]  R1121     7.9773432016372681e-01
    z[2,1,4]  R1122     2.9656341299414635e-02
    z[2,1,4]  R1123     -4.3531331419944763e-01
    z[2,1,4]  R1124     -1.5251480042934418e-02
    z[2,1,4]  R1125     1.6486409306526184e-01
    z[2,1,4]  R1126     3.1822186708450317e-01
    z[2,1,4]  R1127     3.8033452630043030e-01
    z[2,1,4]  R1128     -2.7622884511947632e-01
    z[2,1,4]  R1129     6.9422118365764618e-02
    z[2,1,4]  R1130     -2.4084742367267609e-01
    z[2,1,4]  R1131     2.7856758236885071e-01
    z[2,1,4]  R1132     3.8693848252296448e-01
    z[2,1,4]  R1133     4.1001993417739868e-01
    z[2,1,4]  R1134     7.1121048927307129e-01
    z[2,1,4]  R1135     3.3168014883995056e-01
    z[2,1,4]  R1136     0.187080979347229
    z[2,1,4]  R1137     1.0877946764230728e-01
    z[2,1,4]  R1138     -2.9853085055947304e-02
    z[2,1,4]  R1139     3.7477380037307739e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R996      -1
    z[2,1,5]  R997      1
    z[2,1,5]  R1000     -2.1863847970962524e-02
    z[2,1,5]  R1001     -0.0313928946852684
    z[2,1,5]  R1002     3.3899274468421936e-01
    z[2,1,5]  R1003     7.5918912887573242e-02
    z[2,1,5]  R1004     -1.5463545918464661e-02
    z[2,1,5]  R1005     6.1474508047103882e-01
    z[2,1,5]  R1006     3.8006502389907837e-01
    z[2,1,5]  R1007     2.2136305272579193e-01
    z[2,1,5]  R1008     2.3091264069080353e-01
    z[2,1,5]  R1009     1.9786050915718079e-01
    z[2,1,5]  R1010     1.0970976948738098e-01
    z[2,1,5]  R1011     -3.9908087253570557e-01
    z[2,1,5]  R1012     -4.2348787188529968e-01
    z[2,1,5]  R1013     -4.9752873182296753e-01
    z[2,1,5]  R1014     -1.4555752277374268e-01
    z[2,1,5]  R1015     4.7893855720758438e-02
    z[2,1,5]  R1016     -2.5469270348548889e-01
    z[2,1,5]  R1017     -6.5651547908782959e-01
    z[2,1,5]  R1018     -2.5598949193954468e-01
    z[2,1,5]  R1019     -1.4976185560226440e-01
    z[2,1,5]  R1020     -6.0912001132965088e-01
    z[2,1,5]  R1021     9.3447407707571983e-03
    z[2,1,5]  R1022     -6.2571600079536438e-02
    z[2,1,5]  R1023     -4.6416290104389191e-02
    z[2,1,5]  R1024     -3.6793848872184753e-01
    z[2,1,5]  R1025     -1.3254623115062714e-01
    z[2,1,5]  R1026     4.0630754828453064e-01
    z[2,1,5]  R1027     3.9330080151557922e-01
    z[2,1,5]  R1028     2.1390035748481750e-01
    z[2,1,5]  R1029     3.5462772846221924e-01
    z[2,1,5]  R1030     4.4799691438674927e-01
    z[2,1,5]  R1031     1.1716803908348083e-01
    z[2,1,5]  R1032     1.1035675555467606e-01
    z[2,1,5]  R1033     4.8289110418409109e-04
    z[2,1,5]  R1034     -0.0670744925737381
    z[2,1,5]  R1035     3.7761366367340088e-01
    z[2,1,5]  R1036     6.7873440682888031e-02
    z[2,1,5]  R1037     4.2142614722251892e-01
    z[2,1,5]  R1038     3.0900228023529053e-01
    z[2,1,5]  R1039     3.9559951983392239e-03
    z[2,1,5]  R1040     3.2422382384538651e-02
    z[2,1,5]  R1041     7.8848125413060188e-03
    z[2,1,5]  R1042     4.6986883878707886e-01
    z[2,1,5]  R1043     6.4230072498321533e-01
    z[2,1,5]  R1044     -1.2610211968421936e-01
    z[2,1,5]  R1045     1.4766190946102142e-01
    z[2,1,5]  R1046     1.8167679011821747e-01
    z[2,1,5]  R1047     -2.7452623844146729e-01
    z[2,1,5]  R1048     -8.5259661078453064e-02
    z[2,1,5]  R1049     2.1010087430477142e-01
    z[2,1,5]  R1050     6.7935936152935028e-02
    z[2,1,5]  R1051     4.6180140227079391e-02
    z[2,1,5]  R1052     4.3076780438423157e-01
    z[2,1,5]  R1053     2.6315766572952271e-01
    z[2,1,5]  R1054     2.5518137216567993e-01
    z[2,1,5]  R1055     4.8160418868064880e-01
    z[2,1,5]  R1056     6.2356390058994293e-02
    z[2,1,5]  R1057     0.367984801530838
    z[2,1,5]  R1058     -1.4788319170475006e-01
    z[2,1,5]  R1059     1.0287480056285858e-01
    z[2,1,5]  R1060     -1.4402790367603302e-01
    z[2,1,5]  R1061     4.5146383345127106e-02
    z[2,1,5]  R1062     1.1751770973205566e-01
    z[2,1,5]  R1063     4.2257276177406311e-01
    z[2,1,5]  R1064     1.0330075025558472e-01
    z[2,1,5]  R1065     3.4574690461158752e-01
    z[2,1,5]  R1066     1.7807528376579285e-01
    z[2,1,5]  R1067     -1.4250756241381168e-02
    z[2,1,5]  R1068     5.1383594982326031e-03
    z[2,1,5]  R1069     -1.3030184805393219e-01
    z[2,1,5]  R1070     4.7639212012290955e-01
    z[2,1,5]  R1071     3.3835160732269287e-01
    z[2,1,5]  R1072     1.3196520507335663e-01
    z[2,1,5]  R1073     5.4228603839874268e-01
    z[2,1,5]  R1074     0.332433819770813
    z[2,1,5]  R1075     1.7465837299823761e-01
    z[2,1,5]  R1076     5.2098482847213745e-01
    z[2,1,5]  R1077     5.0092417001724243e-01
    z[2,1,5]  R1078     3.1437876820564270e-01
    z[2,1,5]  R1079     -0.0597243569791317
    z[2,1,5]  R1080     -1.8792058527469635e-01
    z[2,1,5]  R1081     -1.9813102483749390e-01
    z[2,1,5]  R1082     -3.5396766662597656e-01
    z[2,1,5]  R1083     -1.2771297991275787e-01
    z[2,1,5]  R1084     -4.5337450504302979e-01
    z[2,1,5]  R1085     -2.8609189391136169e-01
    z[2,1,5]  R1086     -1.7389757931232452e-01
    z[2,1,5]  R1087     -4.0819168090820312e-01
    z[2,1,5]  R1088     -2.2313356399536133e-01
    z[2,1,5]  R1089     -2.3613187670707703e-01
    z[2,1,5]  R1090     1.8409633636474609e-01
    z[2,1,5]  R1091     8.4336094558238983e-02
    z[2,1,5]  R1092     7.1165359020233154e-01
    z[2,1,5]  R1093     -1.4875005185604095e-01
    z[2,1,5]  R1094     -2.2034212946891785e-01
    z[2,1,5]  R1095     -2.9223549365997314e-01
    z[2,1,5]  R1096     -1.1317928880453110e-01
    z[2,1,5]  R1097     -2.9599642753601074e-01
    z[2,1,5]  R1098     -2.4392421543598175e-01
    z[2,1,5]  R1099     -1.7684239149093628e-01
    z[2,1,5]  R1100     3.1072497367858887e-01
    z[2,1,5]  R1101     8.6572587490081787e-02
    z[2,1,5]  R1102     9.3467950820922852e-02
    z[2,1,5]  R1103     2.9265916347503662e-01
    z[2,1,5]  R1104     9.4040319323539734e-02
    z[2,1,5]  R1105     -0.300374835729599
    z[2,1,5]  R1106     -1.2064851820468903e-01
    z[2,1,5]  R1107     2.1226347982883453e-01
    z[2,1,5]  R1108     2.9925328493118286e-01
    z[2,1,5]  R1109     -2.4028530716896057e-01
    z[2,1,5]  R1110     8.8568501174449921e-02
    z[2,1,5]  R1111     -1.9132284214720130e-03
    z[2,1,5]  R1112     2.4026885628700256e-01
    z[2,1,5]  R1113     -6.7815303802490234e-02
    z[2,1,5]  R1114     1.4808064699172974e-01
    z[2,1,5]  R1115     -9.7954049706459045e-02
    z[2,1,5]  R1116     -4.0656840801239014e-01
    z[2,1,5]  R1117     5.9593491256237030e-02
    z[2,1,5]  R1118     1.0588598251342773e-01
    z[2,1,5]  R1119     -6.8894013762474060e-02
    z[2,1,5]  R1120     4.7643181681632996e-01
    z[2,1,5]  R1121     6.1530273407697678e-02
    z[2,1,5]  R1122     -0.0348796509206295
    z[2,1,5]  R1123     5.9020388126373291e-01
    z[2,1,5]  R1124     -1.7851024866104126e-01
    z[2,1,5]  R1125     -2.3533992469310760e-01
    z[2,1,5]  R1126     1.3561421632766724e-01
    z[2,1,5]  R1127     -2.1379022300243378e-01
    z[2,1,5]  R1128     2.2489269077777863e-01
    z[2,1,5]  R1129     -2.5495597720146179e-01
    z[2,1,5]  R1130     4.8909124732017517e-01
    z[2,1,5]  R1131     3.2360464334487915e-01
    z[2,1,5]  R1132     1.2746696174144745e-01
    z[2,1,5]  R1133     -6.3453322649002075e-01
    z[2,1,5]  R1134     -3.8612812757492065e-01
    z[2,1,5]  R1135     -1.6239969432353973e-01
    z[2,1,5]  R1136     -2.5596126914024353e-01
    z[2,1,5]  R1137     -4.0585622191429138e-01
    z[2,1,5]  R1138     -4.1404470801353455e-01
    z[2,1,5]  R1139     -4.8035117983818054e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R998      -1
    z[2,1,6]  R999      1
    z[2,1,6]  R1000     -7.6129332184791565e-02
    z[2,1,6]  R1001     -7.3365390300750732e-02
    z[2,1,6]  R1002     -3.4578087925910950e-01
    z[2,1,6]  R1003     1.5605156123638153e-01
    z[2,1,6]  R1004     2.3009985685348511e-01
    z[2,1,6]  R1005     1.5051838755607605e-01
    z[2,1,6]  R1006     8.7104015052318573e-02
    z[2,1,6]  R1007     -1.0014154762029648e-01
    z[2,1,6]  R1008     -1.4077019691467285e-01
    z[2,1,6]  R1009     -8.5763055831193924e-03
    z[2,1,6]  R1010     -9.0737998485565186e-02
    z[2,1,6]  R1011     -2.4420207738876343e-01
    z[2,1,6]  R1012     3.9023146033287048e-01
    z[2,1,6]  R1013     -9.9755868315696716e-02
    z[2,1,6]  R1014     4.2261913418769836e-01
    z[2,1,6]  R1015     -2.6162469387054443e-01
    z[2,1,6]  R1016     -1.6433786600828171e-02
    z[2,1,6]  R1017     -1.2982209026813507e-01
    z[2,1,6]  R1018     1.5139083564281464e-01
    z[2,1,6]  R1019     -6.4163416624069214e-02
    z[2,1,6]  R1020     2.1978148818016052e-01
    z[2,1,6]  R1021     -2.0590944215655327e-02
    z[2,1,6]  R1022     -7.2199642658233643e-02
    z[2,1,6]  R1023     2.1643798053264618e-01
    z[2,1,6]  R1024     -7.3277676105499268e-01
    z[2,1,6]  R1025     3.1019678711891174e-01
    z[2,1,6]  R1026     9.6868827939033508e-02
    z[2,1,6]  R1027     -1.2527799606323242e-01
    z[2,1,6]  R1028     7.4379876255989075e-02
    z[2,1,6]  R1029     -1.3619431294500828e-02
    z[2,1,6]  R1030     -7.2764731943607330e-02
    z[2,1,6]  R1031     -7.7986407279968262e-01
    z[2,1,6]  R1032     -4.7147876024246216e-01
    z[2,1,6]  R1033     3.5145735740661621e-01
    z[2,1,6]  R1034     -2.4567832052707672e-01
    z[2,1,6]  R1035     -2.3418083786964417e-01
    z[2,1,6]  R1036     -3.8220256567001343e-01
    z[2,1,6]  R1037     -4.1139709949493408e-01
    z[2,1,6]  R1038     -5.7040389627218246e-02
    z[2,1,6]  R1039     7.9919129610061646e-02
    z[2,1,6]  R1040     4.9838513135910034e-02
    z[2,1,6]  R1041     -3.7416470050811768e-01
    z[2,1,6]  R1042     6.8591696023941040e-01
    z[2,1,6]  R1043     -3.3505210280418396e-01
    z[2,1,6]  R1044     -3.5237908363342285e-01
    z[2,1,6]  R1045     4.6693280339241028e-02
    z[2,1,6]  R1046     7.7178376913070679e-01
    z[2,1,6]  R1047     3.0427795648574829e-01
    z[2,1,6]  R1048     -3.5914036631584167e-01
    z[2,1,6]  R1049     6.9722110033035278e-01
    z[2,1,6]  R1050     7.0770651102066040e-01
    z[2,1,6]  R1051     1.9272483885288239e-02
    z[2,1,6]  R1052     -1.4926255680620670e-03
    z[2,1,6]  R1053     1.0365618020296097e-01
    z[2,1,6]  R1054     3.9519476890563965e-01
    z[2,1,6]  R1055     3.1461676955223083e-01
    z[2,1,6]  R1056     -1.8477068841457367e-01
    z[2,1,6]  R1057     -1.1238960921764374e-01
    z[2,1,6]  R1058     -2.6112458109855652e-01
    z[2,1,6]  R1059     1.3324251770973206e-01
    z[2,1,6]  R1060     3.8310918211936951e-01
    z[2,1,6]  R1061     3.4259554743766785e-01
    z[2,1,6]  R1062     3.3546081185340881e-01
    z[2,1,6]  R1063     -0.141708105802536
    z[2,1,6]  R1064     2.9049226641654968e-01
    z[2,1,6]  R1065     -6.6882841289043427e-02
    z[2,1,6]  R1066     -1.5954727306962013e-02
    z[2,1,6]  R1067     2.4336050450801849e-01
    z[2,1,6]  R1068     -4.4455981254577637e-01
    z[2,1,6]  R1069     -3.1602874398231506e-01
    z[2,1,6]  R1070     2.6858173310756683e-02
    z[2,1,6]  R1071     1.3759815692901611e-01
    z[2,1,6]  R1072     -1.9455698132514954e-01
    z[2,1,6]  R1073     -2.7928901836276054e-02
    z[2,1,6]  R1074     3.9691379666328430e-01
    z[2,1,6]  R1075     -9.4235010445117950e-02
    z[2,1,6]  R1076     -4.6372160315513611e-01
    z[2,1,6]  R1077     1.3849860429763794e-01
    z[2,1,6]  R1078     6.0068508610129356e-03
    z[2,1,6]  R1079     1.4758543670177460e-01
    z[2,1,6]  R1080     8.9115403592586517e-02
    z[2,1,6]  R1081     -1.7295074462890625e-01
    z[2,1,6]  R1082     4.5295480638742447e-02
    z[2,1,6]  R1083     -0.429155170917511
    z[2,1,6]  R1084     -9.0533353388309479e-02
    z[2,1,6]  R1085     -1.8242296576499939e-01
    z[2,1,6]  R1086     -1.9455881416797638e-01
    z[2,1,6]  R1087     -2.1512724459171295e-01
    z[2,1,6]  R1088     1.9915764033794403e-01
    z[2,1,6]  R1089     1.0617773979902267e-02
    z[2,1,6]  R1090     -2.6905581355094910e-01
    z[2,1,6]  R1091     -1.7250110208988190e-01
    z[2,1,6]  R1092     1.7161907255649567e-01
    z[2,1,6]  R1093     1.5332300961017609e-01
    z[2,1,6]  R1094     -7.1559733152389526e-01
    z[2,1,6]  R1095     -2.6875638961791992e-01
    z[2,1,6]  R1096     -3.4160980582237244e-01
    z[2,1,6]  R1097     -6.4790071919560432e-03
    z[2,1,6]  R1098     -8.3678871393203735e-02
    z[2,1,6]  R1099     1.4622308313846588e-01
    z[2,1,6]  R1100     -4.0118601173162460e-02
    z[2,1,6]  R1101     -0.0113369794562459
    z[2,1,6]  R1102     1.1757802218198776e-01
    z[2,1,6]  R1103     -2.9616445302963257e-01
    z[2,1,6]  R1104     -1.2719714641571045e-01
    z[2,1,6]  R1105     3.1891950964927673e-01
    z[2,1,6]  R1106     -1.4607398211956024e-01
    z[2,1,6]  R1107     2.3893110454082489e-02
    z[2,1,6]  R1108     -2.3453857004642487e-01
    z[2,1,6]  R1109     -2.7294633910059929e-02
    z[2,1,6]  R1110     1.1803147196769714e-01
    z[2,1,6]  R1111     8.1077076494693756e-02
    z[2,1,6]  R1112     -2.1415489912033081e-01
    z[2,1,6]  R1113     -1.4506998658180237e-01
    z[2,1,6]  R1114     -7.1462929248809814e-01
    z[2,1,6]  R1115     -1.9606147706508636e-01
    z[2,1,6]  R1116     7.2265923023223877e-02
    z[2,1,6]  R1117     -4.1635073721408844e-02
    z[2,1,6]  R1118     6.7983572371304035e-03
    z[2,1,6]  R1119     -1.1469484865665436e-01
    z[2,1,6]  R1120     -3.3874136209487915e-01
    z[2,1,6]  R1121     -1.5532813034951687e-02
    z[2,1,6]  R1122     -1.3888043165206909e-01
    z[2,1,6]  R1123     2.2395296394824982e-01
    z[2,1,6]  R1124     7.9197414219379425e-02
    z[2,1,6]  R1125     1.1739090085029602e-01
    z[2,1,6]  R1126     -2.0323191583156586e-01
    z[2,1,6]  R1127     4.7606897354125977e-01
    z[2,1,6]  R1128     -1.5488071739673615e-01
    z[2,1,6]  R1129     -1.8255972862243652e-01
    z[2,1,6]  R1130     -2.6468801498413086e-01
    z[2,1,6]  R1131     2.0553344488143921e-01
    z[2,1,6]  R1132     0.451729416847229
    z[2,1,6]  R1133     -1.1594294756650925e-01
    z[2,1,6]  R1134     -3.4763699769973755e-01
    z[2,1,6]  R1135     -1.0595864616334438e-02
    z[2,1,6]  R1136     -3.2378476113080978e-02
    z[2,1,6]  R1137     3.1050181388854980e-01
    z[2,1,6]  R1138     -4.1898640990257263e-01
    z[2,1,6]  R1139     -1.9147852063179016e-01
    z[1,4,0]  R11       -1
    z[1,4,0]  R38       1
    z[1,4,0]  R1140     -1
    z[1,4,0]  R1141     1
    z[1,4,0]  R1154     -6.7375445365905762e-01
    z[1,4,0]  R1155     -6.9888913631439209e-01
    z[1,4,0]  R1156     -0.594390869140625
    z[1,4,0]  R1157     -5.7361841201782227e-01
    z[1,4,0]  R1158     -8.2231032848358154e-01
    z[1,4,0]  R1159     -6.2316077947616577e-01
    z[1,4,0]  R1160     -5.8995449542999268e-01
    z[1,4,0]  R1161     -5.8598655462265015e-01
    z[1,4,0]  R1162     -0.606269121170044
    z[1,4,0]  R1163     -6.2820702791213989e-01
    z[1,4,0]  R1164     6.9167673587799072e-01
    z[1,4,0]  R1165     5.3233176469802856e-01
    z[1,4,0]  R1166     8.2345694303512573e-01
    z[1,4,0]  R1167     6.9714194536209106e-01
    z[1,4,0]  R1168     6.9522601366043091e-01
    z[1,4,0]  R1169     5.7812613248825073e-01
    z[1,4,0]  R1170     6.6528755426406860e-01
    z[1,4,0]  R1171     3.6091324687004089e-01
    z[1,4,0]  R1172     9.0225964784622192e-01
    z[1,4,0]  R1173     6.9183218479156494e-01
    z[1,4,0]  R1174     -1.3907539844512939e-01
    z[1,4,0]  R1175     -3.6842882633209229e-01
    z[1,4,0]  R1176     2.7511421591043472e-02
    z[1,4,0]  R1177     3.3677688241004944e-01
    z[1,4,0]  R1178     -3.0400383472442627e-01
    z[1,4,0]  R1179     0.129286989569664
    z[1,4,0]  R1180     2.0904533565044403e-01
    z[1,4,0]  R1181     -2.5468206405639648e-01
    z[1,4,0]  R1182     1.1293878406286240e-01
    z[1,4,0]  R1183     4.3662047386169434e-01
    z[1,4,0]  R1184     3.9613431692123413e-01
    z[1,4,0]  R1185     -3.3349683880805969e-01
    z[1,4,0]  R1186     -5.5167776346206665e-01
    z[1,4,0]  R1187     -2.6409402489662170e-01
    z[1,4,0]  R1188     -0.34183269739151
    z[1,4,0]  R1189     5.2882835268974304e-02
    z[1,4,0]  R1190     -8.3833348751068115e-01
    z[1,4,0]  R1191     -0.0875013917684555
    z[1,4,0]  R1192     1.0923463106155396e-01
    z[1,4,0]  R1193     -1.5071013569831848e-01
    z[1,4,0]  R1194     2.0982383191585541e-01
    z[1,4,0]  R1195     -2.2338643670082092e-01
    z[1,4,0]  R1196     -1.9661673903465271e-01
    z[1,4,0]  R1197     4.1472226381301880e-01
    z[1,4,0]  R1198     6.9381761550903320e-01
    z[1,4,0]  R1199     1.7683707177639008e-01
    z[1,4,0]  R1200     1.4207929372787476e-01
    z[1,4,0]  R1201     5.0470888614654541e-02
    z[1,4,0]  R1202     -1.8071976304054260e-01
    z[1,4,0]  R1203     -1.8040654063224792e-01
    z[1,4,0]  R1204     9.3746155500411987e-01
    z[1,4,0]  R1205     7.5093394517898560e-01
    z[1,4,0]  R1206     0.723858654499054
    z[1,4,0]  R1207     7.9731434583663940e-01
    z[1,4,0]  R1208     -1.7402684688568115e-01
    z[1,4,0]  R1209     4.5955085754394531e-01
    z[1,4,0]  R1210     -3.2479703426361084e-01
    z[1,4,0]  R1211     -8.4862513467669487e-03
    z[1,4,0]  R1212     -9.2845153808593750e-01
    z[1,4,0]  R1213     -8.3313882350921631e-01
    z[1,4,0]  R1214     -3.1924718618392944e-01
    z[1,4,0]  R1215     -4.2675679922103882e-01
    z[1,4,0]  R1216     8.1410235166549683e-01
    z[1,4,0]  R1217     -3.7976104021072388e-01
    z[1,4,0]  R1218     7.1696668863296509e-02
    z[1,4,0]  R1219     -4.5697745680809021e-01
    z[1,4,0]  R1220     -4.2993064969778061e-02
    z[1,4,0]  R1221     1.0481332242488861e-01
    z[1,4,0]  R1222     -1.7297340929508209e-01
    z[1,4,0]  R1223     4.1590067744255066e-01
    z[1,4,0]  R1224     3.9963892102241516e-01
    z[1,4,0]  R1225     -4.4773986935615540e-01
    z[1,4,0]  R1226     2.3669132962822914e-02
    z[1,4,0]  R1227     -1.5191610157489777e-01
    z[1,4,0]  R1228     -3.5037714242935181e-01
    z[1,4,0]  R1229     -1.9325231015682220e-01
    z[1,4,0]  R1230     3.1451320648193359e-01
    z[1,4,0]  R1231     -3.1922420859336853e-01
    z[1,4,0]  R1232     2.4484528601169586e-01
    z[1,4,0]  R1233     -4.3561407923698425e-01
    z[1,4,0]  R1234     -7.5595939159393311e-01
    z[1,4,0]  R1235     -3.8382682204246521e-01
    z[1,4,0]  R1236     -3.0085310339927673e-01
    z[1,4,0]  R1237     -4.3898898363113403e-01
    z[1,4,0]  R1238     -5.3916312754154205e-02
    z[1,4,0]  R1239     2.0261155068874359e-01
    z[1,4,0]  R1240     -3.3357802033424377e-01
    z[1,4,0]  R1241     -4.6541181206703186e-01
    z[1,4,0]  R1242     -1.7482081055641174e-01
    z[1,4,0]  R1243     -3.2698640227317810e-01
    z[1,4,0]  R1244     -2.0467326045036316e-01
    z[1,4,0]  R1245     3.1608107686042786e-01
    z[1,4,0]  R1246     1.9089536741375923e-02
    z[1,4,0]  R1247     3.4732836484909058e-01
    z[1,4,0]  R1248     8.6776286363601685e-01
    z[1,4,0]  R1249     -6.4097873866558075e-02
    z[1,4,0]  R1250     9.2839550971984863e-01
    z[1,4,0]  R1251     8.8717746734619141e-01
    z[1,4,0]  R1252     0.766423225402832
    z[1,4,0]  R1253     8.0424225330352783e-01
    z[1,4,0]  R1254     2.6922184973955154e-02
    z[1,4,0]  R1255     -3.1197193264961243e-01
    z[1,4,0]  R1256     -4.2019522190093994e-01
    z[1,4,0]  R1257     8.5720755159854889e-02
    z[1,4,0]  R1258     -4.9759708344936371e-02
    z[1,4,0]  R1259     5.1685433834791183e-02
    z[1,4,0]  R1260     1.4829632639884949e-01
    z[1,4,0]  R1261     1.6176998615264893e-01
    z[1,4,0]  R1262     2.3579502105712891e-01
    z[1,4,0]  R1263     -1.4668072760105133e-01
    z[1,4,0]  R1264     -2.1438447292894125e-03
    z[1,4,0]  R1265     3.1725355982780457e-01
    z[1,4,0]  R1266     -1.7180384695529938e-01
    z[1,4,0]  R1267     -6.9005347788333893e-02
    z[1,4,0]  R1268     5.3096253424882889e-02
    z[1,4,0]  R1269     2.0548075437545776e-01
    z[1,4,0]  R1270     3.2522976398468018e-01
    z[1,4,0]  R1271     -5.1012493669986725e-02
    z[1,4,0]  R1272     9.2113900184631348e-01
    z[1,4,0]  R1273     5.6456762552261353e-01
    z[1,4,0]  R1274     -3.2004863023757935e-01
    z[1,4,0]  R1275     -1.2148412875831127e-02
    z[1,4,0]  R1276     -6.3843570649623871e-02
    z[1,4,0]  R1277     -5.1655262708663940e-02
    z[1,4,0]  R1278     -1.8021368980407715e-01
    z[1,4,0]  R1279     -1.5424399077892303e-01
    z[1,4,0]  R1280     1.2154664099216461e-01
    z[1,4,0]  R1281     8.8347233831882477e-02
    z[1,4,0]  R1282     -2.8340601921081543e-01
    z[1,4,0]  R1283     4.0016490221023560e-01
    z[1,4,0]  R1284     -2.0374859869480133e-01
    z[1,4,0]  R1285     -1.8331326544284821e-01
    z[1,4,0]  R1286     -2.9987642168998718e-01
    z[1,4,0]  R1287     -4.0957161784172058e-01
    z[1,4,0]  R1288     -2.1545775234699249e-01
    z[1,4,0]  R1289     -9.7865886986255646e-02
    z[1,4,0]  R1290     3.2939872145652771e-01
    z[1,4,0]  R1291     3.6172747611999512e-01
    z[1,4,0]  R1292     6.9161552190780640e-01
    z[1,4,0]  R1293     8.4867948293685913e-01
    z[1,4,0]  R1294     3.0808833241462708e-01
    z[1,4,0]  R1295     -1.6845524311065674e-01
    z[1,4,0]  R1296     -1.5884728729724884e-01
    z[1,4,0]  R1297     7.8646093606948853e-03
    z[1,4,0]  R1298     -3.8685572147369385e-01
    z[1,4,0]  R1299     -1.5796563029289246e-01
    z[1,4,0]  R1300     -1.0707242041826248e-01
    z[1,4,0]  R1301     9.2819523811340332e-01
    z[1,4,0]  R1302     9.1676068305969238e-01
    z[1,4,0]  R1303     8.5742688179016113e-01
    z[1,4,0]  R1304     1.1749872565269470e-01
    z[1,4,0]  R1305     -1.0967695713043213e-01
    z[1,4,0]  R1306     -9.1911517083644867e-02
    z[1,4,0]  R1307     -1.7805531620979309e-01
    z[1,4,0]  R1308     -2.5043404102325439e-01
    z[1,4,0]  R1309     2.8830792754888535e-02
    z[1,4,0]  R1310     -5.3877104073762894e-02
    z[1,4,0]  R1311     7.6644057035446167e-01
    z[1,4,0]  R1312     4.5327857136726379e-01
    z[1,4,0]  R1313     7.2841495275497437e-01
    z[1,4,0]  R1314     -1.5652939677238464e-01
    z[1,4,0]  R1315     -4.5320162177085876e-01
    z[1,4,0]  R1316     8.3178174495697021e-01
    z[1,4,0]  R1317     0.865403413772583
    z[1,4,0]  R1318     6.3283419609069824e-01
    z[1,4,0]  R1319     8.7871414422988892e-01
    z[1,4,0]  R1320     3.6707940697669983e-01
    z[1,4,0]  R1321     6.1472576856613159e-01
    z[1,4,0]  R1322     4.5549169182777405e-01
    z[1,4,0]  R1323     4.5406249165534973e-01
    z[1,4,1]  R12       -1
    z[1,4,1]  R39       1
    z[1,4,1]  R1142     -1
    z[1,4,1]  R1143     1
    z[1,4,1]  R1154     5.6581604480743408e-01
    z[1,4,1]  R1155     4.6107420325279236e-01
    z[1,4,1]  R1156     5.8846014738082886e-01
    z[1,4,1]  R1157     6.0418677330017090e-01
    z[1,4,1]  R1158     4.1971653699874878e-01
    z[1,4,1]  R1159     4.7782710194587708e-01
    z[1,4,1]  R1160     -0.0804959312081337
    z[1,4,1]  R1161     -1.3034315407276154e-01
    z[1,4,1]  R1162     4.8019781708717346e-01
    z[1,4,1]  R1163     4.2548415064811707e-01
    z[1,4,1]  R1164     1.3635043799877167e-01
    z[1,4,1]  R1165     1.9816307723522186e-01
    z[1,4,1]  R1166     1.8716986477375031e-01
    z[1,4,1]  R1167     3.2812580466270447e-01
    z[1,4,1]  R1168     4.3138720095157623e-02
    z[1,4,1]  R1169     3.2618638873100281e-01
    z[1,4,1]  R1170     3.6346804350614548e-02
    z[1,4,1]  R1171     2.0694455131888390e-02
    z[1,4,1]  R1172     1.6249081492424011e-01
    z[1,4,1]  R1173     3.1555914878845215e-01
    z[1,4,1]  R1174     -5.7555562257766724e-01
    z[1,4,1]  R1175     2.9388232156634331e-02
    z[1,4,1]  R1176     1.3200907409191132e-01
    z[1,4,1]  R1177     7.3984724283218384e-01
    z[1,4,1]  R1178     2.4440020322799683e-02
    z[1,4,1]  R1179     -7.2986435890197754e-01
    z[1,4,1]  R1180     -0.655773401260376
    z[1,4,1]  R1181     1.0935997962951660e-01
    z[1,4,1]  R1182     4.1971331834793091e-01
    z[1,4,1]  R1183     -6.3583093881607056e-01
    z[1,4,1]  R1184     -4.6782466769218445e-01
    z[1,4,1]  R1185     -7.1851402521133423e-01
    z[1,4,1]  R1186     -3.1521740555763245e-01
    z[1,4,1]  R1187     -4.8395147919654846e-01
    z[1,4,1]  R1188     -5.0472050905227661e-01
    z[1,4,1]  R1189     -7.5323802232742310e-01
    z[1,4,1]  R1190     -1.8055382370948792e-01
    z[1,4,1]  R1191     1.0876475274562836e-01
    z[1,4,1]  R1192     2.4585419893264771e-01
    z[1,4,1]  R1193     4.6252235770225525e-01
    z[1,4,1]  R1194     -3.5149574279785156e-01
    z[1,4,1]  R1195     -3.2818189263343811e-01
    z[1,4,1]  R1196     -4.5154190063476562e-01
    z[1,4,1]  R1197     -7.6954740285873413e-01
    z[1,4,1]  R1198     -1.4450900256633759e-01
    z[1,4,1]  R1199     -6.8819504976272583e-01
    z[1,4,1]  R1200     2.1572996675968170e-01
    z[1,4,1]  R1201     3.8106867671012878e-01
    z[1,4,1]  R1202     2.7672821283340454e-01
    z[1,4,1]  R1203     -0.621740996837616
    z[1,4,1]  R1204     -0.0515022911131382
    z[1,4,1]  R1205     -2.8066793084144592e-01
    z[1,4,1]  R1206     -2.8422072529792786e-01
    z[1,4,1]  R1207     -2.2228258848190308e-01
    z[1,4,1]  R1208     -5.4552555084228516e-01
    z[1,4,1]  R1209     -2.5604084134101868e-01
    z[1,4,1]  R1210     -8.0818790197372437e-01
    z[1,4,1]  R1211     -8.4745258092880249e-01
    z[1,4,1]  R1212     -1.9298858940601349e-01
    z[1,4,1]  R1213     -1.9169786944985390e-02
    z[1,4,1]  R1214     -1.4883506298065186e-01
    z[1,4,1]  R1215     -3.3743056654930115e-01
    z[1,4,1]  R1216     -3.2267636060714722e-01
    z[1,4,1]  R1217     -3.5981380939483643e-01
    z[1,4,1]  R1218     -5.5066061019897461e-01
    z[1,4,1]  R1219     -8.3241373300552368e-01
    z[1,4,1]  R1220     -4.0126565098762512e-01
    z[1,4,1]  R1221     -0.325792133808136
    z[1,4,1]  R1222     3.9969906210899353e-01
    z[1,4,1]  R1223     -6.9523072242736816e-01
    z[1,4,1]  R1224     -2.1889136731624603e-01
    z[1,4,1]  R1225     -7.2267115116119385e-01
    z[1,4,1]  R1226     -3.3751270174980164e-01
    z[1,4,1]  R1227     5.9211593866348267e-01
    z[1,4,1]  R1228     2.6231136918067932e-01
    z[1,4,1]  R1229     4.2199438810348511e-01
    z[1,4,1]  R1230     8.6712735891342163e-01
    z[1,4,1]  R1231     9.4980537891387939e-02
    z[1,4,1]  R1232     -6.7621898651123047e-01
    z[1,4,1]  R1233     2.8200818225741386e-02
    z[1,4,1]  R1234     -4.0895906090736389e-01
    z[1,4,1]  R1235     -5.5129384994506836e-01
    z[1,4,1]  R1236     -5.8258968591690063e-01
    z[1,4,1]  R1237     -4.0229967236518860e-01
    z[1,4,1]  R1238     -4.1316270828247070e-01
    z[1,4,1]  R1239     -4.2161974310874939e-01
    z[1,4,1]  R1240     9.1567748785018921e-01
    z[1,4,1]  R1241     6.6368746757507324e-01
    z[1,4,1]  R1242     7.1862238645553589e-01
    z[1,4,1]  R1243     6.2939703464508057e-01
    z[1,4,1]  R1244     -3.6118716001510620e-01
    z[1,4,1]  R1245     0.643488883972168
    z[1,4,1]  R1246     0.761551558971405
    z[1,4,1]  R1247     6.5792787075042725e-01
    z[1,4,1]  R1248     -3.0341061949729919e-01
    z[1,4,1]  R1249     4.7267517447471619e-01
    z[1,4,1]  R1250     -1.5194717049598694e-01
    z[1,4,1]  R1251     -8.1752061843872070e-02
    z[1,4,1]  R1252     -3.1761386990547180e-01
    z[1,4,1]  R1253     -2.4149794876575470e-01
    z[1,4,1]  R1254     7.0063757896423340e-01
    z[1,4,1]  R1255     0.634477436542511
    z[1,4,1]  R1256     5.1053810119628906e-01
    z[1,4,1]  R1257     6.3336014747619629e-01
    z[1,4,1]  R1258     0.571498453617096
    z[1,4,1]  R1259     0.624488890171051
    z[1,4,1]  R1260     6.8535220623016357e-01
    z[1,4,1]  R1261     6.0414552688598633e-01
    z[1,4,1]  R1262     0.617192268371582
    z[1,4,1]  R1263     4.7669410705566406e-01
    z[1,4,1]  R1264     -0.521144449710846
    z[1,4,1]  R1265     8.1455355882644653e-01
    z[1,4,1]  R1266     6.6145467758178711e-01
    z[1,4,1]  R1267     6.5821504592895508e-01
    z[1,4,1]  R1268     7.6134026050567627e-01
    z[1,4,1]  R1269     6.7953163385391235e-01
    z[1,4,1]  R1270     6.7852401733398438e-01
    z[1,4,1]  R1271     -2.8339993953704834e-01
    z[1,4,1]  R1272     -1.2914204597473145e-01
    z[1,4,1]  R1273     -2.7889639139175415e-01
    z[1,4,1]  R1274     0.661384105682373
    z[1,4,1]  R1275     6.8406271934509277e-01
    z[1,4,1]  R1276     0.609142005443573
    z[1,4,1]  R1277     6.1185771226882935e-01
    z[1,4,1]  R1278     5.1991587877273560e-01
    z[1,4,1]  R1279     5.0892251729965210e-01
    z[1,4,1]  R1280     6.2008982896804810e-01
    z[1,4,1]  R1281     5.8739626407623291e-01
    z[1,4,1]  R1282     4.4208192825317383e-01
    z[1,4,1]  R1283     -7.5490063428878784e-01
    z[1,4,1]  R1284     1.1428605020046234e-01
    z[1,4,1]  R1285     -5.4980587959289551e-01
    z[1,4,1]  R1286     6.8772667646408081e-01
    z[1,4,1]  R1287     5.7774698734283447e-01
    z[1,4,1]  R1288     6.1253947019577026e-01
    z[1,4,1]  R1289     6.3415187597274780e-01
    z[1,4,1]  R1290     7.2337609529495239e-01
    z[1,4,1]  R1291     6.5873426198959351e-01
    z[1,4,1]  R1292     -3.1618535518646240e-01
    z[1,4,1]  R1293     -2.2307717800140381e-01
    z[1,4,1]  R1294     0.907846212387085
    z[1,4,1]  R1295     7.8116118907928467e-01
    z[1,4,1]  R1296     6.5968692302703857e-01
    z[1,4,1]  R1297     7.1707624197006226e-01
    z[1,4,1]  R1298     5.8574253320693970e-01
    z[1,4,1]  R1299     6.7232650518417358e-01
    z[1,4,1]  R1300     5.0570577383041382e-01
    z[1,4,1]  R1301     -2.2589710354804993e-01
    z[1,4,1]  R1302     -6.9680139422416687e-02
    z[1,4,1]  R1303     -5.0524167716503143e-02
    z[1,4,1]  R1304     -4.7879534959793091e-01
    z[1,4,1]  R1305     8.4078276157379150e-01
    z[1,4,1]  R1306     8.1807190179824829e-01
    z[1,4,1]  R1307     7.6242613792419434e-01
    z[1,4,1]  R1308     7.4268090724945068e-01
    z[1,4,1]  R1309     7.8609466552734375e-01
    z[1,4,1]  R1310     5.7589423656463623e-01
    z[1,4,1]  R1311     -2.7718749642372131e-01
    z[1,4,1]  R1312     4.0824308991432190e-01
    z[1,4,1]  R1313     1.9695796072483063e-01
    z[1,4,1]  R1314     -3.7442067265510559e-01
    z[1,4,1]  R1315     5.4200363159179688e-01
    z[1,4,1]  R1316     -3.6016467213630676e-01
    z[1,4,1]  R1317     -1.0555035620927811e-01
    z[1,4,1]  R1318     -2.8569099307060242e-01
    z[1,4,1]  R1319     7.3532074689865112e-02
    z[1,4,1]  R1320     5.3862494230270386e-01
    z[1,4,1]  R1321     5.9677477926015854e-02
    z[1,4,1]  R1322     1.7477940022945404e-01
    z[1,4,1]  R1323     2.8231540322303772e-01
    z[1,4,2]  R13       -1
    z[1,4,2]  R40       1
    z[1,4,2]  R1144     -1
    z[1,4,2]  R1145     1
    z[1,4,2]  R1154     -1.8583782017230988e-01
    z[1,4,2]  R1155     4.0435454249382019e-01
    z[1,4,2]  R1156     4.9485184252262115e-02
    z[1,4,2]  R1157     3.0327681452035904e-02
    z[1,4,2]  R1158     1.4825256168842316e-01
    z[1,4,2]  R1159     3.9322644472122192e-01
    z[1,4,2]  R1160     3.4202730655670166e-01
    z[1,4,2]  R1161     3.8173198699951172e-01
    z[1,4,2]  R1162     8.3235532045364380e-02
    z[1,4,2]  R1163     3.8509148359298706e-01
    z[1,4,2]  R1164     3.6533221602439880e-01
    z[1,4,2]  R1165     6.9461631774902344e-01
    z[1,4,2]  R1166     4.7899049520492554e-01
    z[1,4,2]  R1167     2.2634410858154297e-01
    z[1,4,2]  R1168     4.1579627990722656e-01
    z[1,4,2]  R1169     4.0311416983604431e-01
    z[1,4,2]  R1170     2.3965889215469360e-01
    z[1,4,2]  R1171     7.5463271141052246e-01
    z[1,4,2]  R1172     6.9754309952259064e-02
    z[1,4,2]  R1173     4.0157452225685120e-01
    z[1,4,2]  R1174     0.372557133436203
    z[1,4,2]  R1175     -1.4441660046577454e-01
    z[1,4,2]  R1176     -5.6320565938949585e-01
    z[1,4,2]  R1177     -3.5228511691093445e-01
    z[1,4,2]  R1178     -3.0513930320739746e-01
    z[1,4,2]  R1179     4.9704313278198242e-01
    z[1,4,2]  R1180     4.5590788125991821e-01
    z[1,4,2]  R1181     -6.6915452480316162e-01
    z[1,4,2]  R1182     -5.5253100395202637e-01
    z[1,4,2]  R1183     3.0519595742225647e-01
    z[1,4,2]  R1184     6.9835972785949707e-01
    z[1,4,2]  R1185     2.0382064580917358e-01
    z[1,4,2]  R1186     -2.1288146078586578e-01
    z[1,4,2]  R1187     6.2886893749237061e-01
    z[1,4,2]  R1188     1.3575246930122375e-01
    z[1,4,2]  R1189     4.6135470271110535e-01
    z[1,4,2]  R1190     -2.4484296143054962e-01
    z[1,4,2]  R1191     -2.1331357955932617e-01
    z[1,4,2]  R1192     -4.6741876006126404e-01
    z[1,4,2]  R1193     -6.8512326478958130e-01
    z[1,4,2]  R1194     6.0631680488586426e-01
    z[1,4,2]  R1195     8.0816090106964111e-01
    z[1,4,2]  R1196     7.1812593936920166e-01
    z[1,4,2]  R1197     -1.1645172536373138e-01
    z[1,4,2]  R1198     -2.2195224463939667e-01
    z[1,4,2]  R1199     -3.4744247794151306e-01
    z[1,4,2]  R1200     -6.0679125785827637e-01
    z[1,4,2]  R1201     -3.5761341452598572e-01
    z[1,4,2]  R1202     -1.6917374730110168e-01
    z[1,4,2]  R1203     -3.7453171610832214e-01
    z[1,4,2]  R1204     -2.8504827991127968e-02
    z[1,4,2]  R1205     2.3543396592140198e-01
    z[1,4,2]  R1206     5.1484811305999756e-01
    z[1,4,2]  R1207     1.7536431550979614e-01
    z[1,4,2]  R1208     3.4148257970809937e-01
    z[1,4,2]  R1209     5.8263164758682251e-01
    z[1,4,2]  R1210     1.6801603138446808e-01
    z[1,4,2]  R1211     -9.2448271811008453e-02
    z[1,4,2]  R1212     -7.8539937734603882e-02
    z[1,4,2]  R1213     1.2315201759338379e-01
    z[1,4,2]  R1214     6.9656980037689209e-01
    z[1,4,2]  R1215     2.5004261732101440e-01
    z[1,4,2]  R1216     2.6816296577453613e-01
    z[1,4,2]  R1217     3.6138707399368286e-01
    z[1,4,2]  R1218     4.6646651625633240e-01
    z[1,4,2]  R1219     4.0568541735410690e-02
    z[1,4,2]  R1220     7.9084801673889160e-01
    z[1,4,2]  R1221     6.8234455585479736e-01
    z[1,4,2]  R1222     -3.0624341964721680e-01
    z[1,4,2]  R1223     -4.8970249295234680e-01
    z[1,4,2]  R1224     6.5157341957092285e-01
    z[1,4,2]  R1225     1.8652480095624924e-02
    z[1,4,2]  R1226     6.6115683317184448e-01
    z[1,4,2]  R1227     -1.5419077873229980e-01
    z[1,4,2]  R1228     -1.6393500566482544e-01
    z[1,4,2]  R1229     -5.4945224523544312e-01
    z[1,4,2]  R1230     -1.7873485386371613e-01
    z[1,4,2]  R1231     -2.0642848312854767e-01
    z[1,4,2]  R1232     -3.5644856095314026e-01
    z[1,4,2]  R1233     -0.48117595911026
    z[1,4,2]  R1234     5.2927613258361816e-02
    z[1,4,2]  R1235     -3.7967246770858765e-01
    z[1,4,2]  R1236     -6.2895250320434570e-01
    z[1,4,2]  R1237     -1.4505137503147125e-01
    z[1,4,2]  R1238     -3.4477221965789795e-01
    z[1,4,2]  R1239     -2.7408489584922791e-01
    z[1,4,2]  R1240     -1.8525023758411407e-01
    z[1,4,2]  R1241     9.5642521977424622e-02
    z[1,4,2]  R1242     7.1118585765361786e-02
    z[1,4,2]  R1243     1.3777109980583191e-01
    z[1,4,2]  R1244     5.7343918085098267e-01
    z[1,4,2]  R1245     3.6670535802841187e-02
    z[1,4,2]  R1246     1.3931621611118317e-01
    z[1,4,2]  R1247     6.4815413951873779e-01
    z[1,4,2]  R1248     -7.3000110685825348e-02
    z[1,4,2]  R1249     4.9809610843658447e-01
    z[1,4,2]  R1250     2.1548955142498016e-01
    z[1,4,2]  R1251     2.7396270632743835e-01
    z[1,4,2]  R1252     -1.0538420639932156e-02
    z[1,4,2]  R1253     1.9095709919929504e-01
    z[1,4,2]  R1254     -1.3599984347820282e-01
    z[1,4,2]  R1255     6.3948506116867065e-01
    z[1,4,2]  R1256     4.0348327159881592e-01
    z[1,4,2]  R1257     -9.1357663273811340e-02
    z[1,4,2]  R1258     2.3269453644752502e-01
    z[1,4,2]  R1259     2.8954052925109863e-01
    z[1,4,2]  R1260     9.3520984053611755e-02
    z[1,4,2]  R1261     3.6777067184448242e-01
    z[1,4,2]  R1262     4.8150235414505005e-01
    z[1,4,2]  R1263     1.8627518415451050e-01
    z[1,4,2]  R1264     7.9654440283775330e-02
    z[1,4,2]  R1265     -6.9881482049822807e-03
    z[1,4,2]  R1266     0.55242520570755
    z[1,4,2]  R1267     0.517589807510376
    z[1,4,2]  R1268     0.382357656955719
    z[1,4,2]  R1269     4.3718099594116211e-01
    z[1,4,2]  R1270     1.4393419027328491e-01
    z[1,4,2]  R1271     7.7611964941024780e-01
    z[1,4,2]  R1272     1.7767506837844849e-01
    z[1,4,2]  R1273     4.2432352900505066e-01
    z[1,4,2]  R1274     4.7660058736801147e-01
    z[1,4,2]  R1275     4.2518422007560730e-01
    z[1,4,2]  R1276     7.4195876717567444e-02
    z[1,4,2]  R1277     1.4133690297603607e-01
    z[1,4,2]  R1278     5.8930929750204086e-02
    z[1,4,2]  R1279     -1.5129742026329041e-01
    z[1,4,2]  R1280     -6.9181986153125763e-02
    z[1,4,2]  R1281     4.6942636370658875e-02
    z[1,4,2]  R1282     1.3853174448013306e-01
    z[1,4,2]  R1283     4.1284161806106567e-01
    z[1,4,2]  R1284     5.5429196357727051e-01
    z[1,4,2]  R1285     3.2978755235671997e-01
    z[1,4,2]  R1286     2.8025823831558228e-01
    z[1,4,2]  R1287     2.6140713691711426e-01
    z[1,4,2]  R1288     1.5084272250533104e-02
    z[1,4,2]  R1289     -1.9392465054988861e-01
    z[1,4,2]  R1290     -9.1017229715362191e-04
    z[1,4,2]  R1291     3.2170155644416809e-01
    z[1,4,2]  R1292     1.8902434408664703e-01
    z[1,4,2]  R1293     7.8653432428836823e-02
    z[1,4,2]  R1294     1.3745307922363281e-01
    z[1,4,2]  R1295     4.8542514443397522e-01
    z[1,4,2]  R1296     2.1271798014640808e-01
    z[1,4,2]  R1297     -1.8609980121254921e-02
    z[1,4,2]  R1298     1.2843313813209534e-01
    z[1,4,2]  R1299     5.8540576696395874e-01
    z[1,4,2]  R1300     1.0369451344013214e-01
    z[1,4,2]  R1301     1.0151851177215576e-01
    z[1,4,2]  R1302     2.9004657268524170e-01
    z[1,4,2]  R1303     4.6488952636718750e-01
    z[1,4,2]  R1304     1.6060872375965118e-01
    z[1,4,2]  R1305     -1.2836912274360657e-01
    z[1,4,2]  R1306     2.7374556660652161e-01
    z[1,4,2]  R1307     1.6982159018516541e-01
    z[1,4,2]  R1308     1.8278861045837402e-01
    z[1,4,2]  R1309     4.2374005913734436e-01
    z[1,4,2]  R1310     5.0773404538631439e-02
    z[1,4,2]  R1311     7.4549637734889984e-02
    z[1,4,2]  R1312     -6.2355047464370728e-01
    z[1,4,2]  R1313     3.8519951701164246e-01
    z[1,4,2]  R1314     4.8653751611709595e-02
    z[1,4,2]  R1315     4.1227829456329346e-01
    z[1,4,2]  R1316     -1.2187819182872772e-01
    z[1,4,2]  R1317     4.1454848647117615e-01
    z[1,4,2]  R1318     3.5861104726791382e-01
    z[1,4,2]  R1319     3.0075496435165405e-01
    z[1,4,2]  R1320     -0.518540620803833
    z[1,4,2]  R1321     2.9725831747055054e-01
    z[1,4,2]  R1322     3.5120970010757446e-01
    z[1,4,2]  R1323     3.8471260666847229e-01
    z[1,4,3]  R14       -1
    z[1,4,3]  R41       1
    z[1,4,3]  R1146     -1
    z[1,4,3]  R1147     1
    z[1,4,3]  R1154     8.6268782615661621e-02
    z[1,4,3]  R1155     7.9351119697093964e-02
    z[1,4,3]  R1156     -4.1238284111022949e-01
    z[1,4,3]  R1157     0.27255779504776
    z[1,4,3]  R1158     -1.6743110120296478e-01
    z[1,4,3]  R1159     -7.4745684862136841e-02
    z[1,4,3]  R1160     -0.693411111831665
    z[1,4,3]  R1161     -6.0715156793594360e-01
    z[1,4,3]  R1162     -4.3046516180038452e-01
    z[1,4,3]  R1163     1.0837700963020325e-01
    z[1,4,3]  R1164     3.6152294278144836e-01
    z[1,4,3]  R1165     2.4025149643421173e-01
    z[1,4,3]  R1166     -3.9704661816358566e-02
    z[1,4,3]  R1167     1.3632193207740784e-01
    z[1,4,3]  R1168     9.5584288239479065e-02
    z[1,4,3]  R1169     5.7831990718841553e-01
    z[1,4,3]  R1170     1.0920634120702744e-01
    z[1,4,3]  R1171     1.6979576647281647e-01
    z[1,4,3]  R1172     -8.3034120500087738e-02
    z[1,4,3]  R1173     4.5772495865821838e-01
    z[1,4,3]  R1174     -1.1041700094938278e-01
    z[1,4,3]  R1175     8.7938672304153442e-01
    z[1,4,3]  R1176     7.2547090053558350e-01
    z[1,4,3]  R1177     1.1537463963031769e-01
    z[1,4,3]  R1178     6.1914795637130737e-01
    z[1,4,3]  R1179     0.170075923204422
    z[1,4,3]  R1180     2.6926058530807495e-01
    z[1,4,3]  R1181     5.0105082988739014e-01
    z[1,4,3]  R1182     5.0233274698257446e-01
    z[1,4,3]  R1183     5.8124684728682041e-03
    z[1,4,3]  R1184     1.3400685787200928e-01
    z[1,4,3]  R1185     3.0896854400634766e-01
    z[1,4,3]  R1186     -1.0778423398733139e-01
    z[1,4,3]  R1187     4.3510311841964722e-01
    z[1,4,3]  R1188     -1.0263931006193161e-01
    z[1,4,3]  R1189     -2.2846798598766327e-01
    z[1,4,3]  R1190     1.6738660633563995e-01
    z[1,4,3]  R1191     8.6282485723495483e-01
    z[1,4,3]  R1192     7.1221959590911865e-01
    z[1,4,3]  R1193     4.8533996939659119e-01
    z[1,4,3]  R1194     -4.1398438811302185e-01
    z[1,4,3]  R1195     4.2451298236846924e-01
    z[1,4,3]  R1196     -2.6501944661140442e-01
    z[1,4,3]  R1197     -1.0121706128120422e-01
    z[1,4,3]  R1198     -8.4021300077438354e-02
    z[1,4,3]  R1199     1.9870984554290771e-01
    z[1,4,3]  R1200     6.7457318305969238e-01
    z[1,4,3]  R1201     6.5682178735733032e-01
    z[1,4,3]  R1202     6.9819372892379761e-01
    z[1,4,3]  R1203     0.532219648361206
    z[1,4,3]  R1204     1.5586647391319275e-01
    z[1,4,3]  R1205     4.0449678897857666e-01
    z[1,4,3]  R1206     -8.4880597889423370e-02
    z[1,4,3]  R1207     4.5831638574600220e-01
    z[1,4,3]  R1208     2.3949561640620232e-02
    z[1,4,3]  R1209     4.4943434000015259e-01
    z[1,4,3]  R1210     -0.0392412431538105
    z[1,4,3]  R1211     2.4432432651519775e-01
    z[1,4,3]  R1212     2.8851801156997681e-01
    z[1,4,3]  R1213     5.0724571943283081e-01
    z[1,4,3]  R1214     9.2477187514305115e-02
    z[1,4,3]  R1215     -3.3023558557033539e-02
    z[1,4,3]  R1216     3.7392783164978027e-01
    z[1,4,3]  R1217     -8.7873362004756927e-02
    z[1,4,3]  R1218     -6.6005373001098633e-01
    z[1,4,3]  R1219     -1.6353135928511620e-02
    z[1,4,3]  R1220     -2.2524943947792053e-01
    z[1,4,3]  R1221     1.6651917248964310e-02
    z[1,4,3]  R1222     7.5210946798324585e-01
    z[1,4,3]  R1223     -2.6873955503106117e-02
    z[1,4,3]  R1224     -2.3450862616300583e-02
    z[1,4,3]  R1225     2.2883121669292450e-01
    z[1,4,3]  R1226     2.7994289994239807e-01
    z[1,4,3]  R1227     -1.3547608256340027e-01
    z[1,4,3]  R1228     7.6073713600635529e-02
    z[1,4,3]  R1229     5.8836966753005981e-01
    z[1,4,3]  R1230     1.2514644861221313e-01
    z[1,4,3]  R1231     7.5729668140411377e-01
    z[1,4,3]  R1232     8.8596068322658539e-02
    z[1,4,3]  R1233     4.1238108277320862e-01
    z[1,4,3]  R1234     1.6001372039318085e-01
    z[1,4,3]  R1235     2.8818270564079285e-01
    z[1,4,3]  R1236     -1.6304506361484528e-01
    z[1,4,3]  R1237     3.6362621188163757e-01
    z[1,4,3]  R1238     1.2032174319028854e-01
    z[1,4,3]  R1239     1.7823085188865662e-01
    z[1,4,3]  R1240     -3.5893155727535486e-03
    z[1,4,3]  R1241     -3.8156139850616455e-01
    z[1,4,3]  R1242     6.0356277227401733e-01
    z[1,4,3]  R1243     -2.8164786100387573e-01
    z[1,4,3]  R1244     -5.4171049594879150e-01
    z[1,4,3]  R1245     1.0718328505754471e-01
    z[1,4,3]  R1246     -0.0906682088971138
    z[1,4,3]  R1247     -6.5006553195416927e-03
    z[1,4,3]  R1248     8.5837788879871368e-02
    z[1,4,3]  R1249     2.3907181620597839e-01
    z[1,4,3]  R1250     4.7946058213710785e-02
    z[1,4,3]  R1251     -3.1040126085281372e-01
    z[1,4,3]  R1252     -4.5869520306587219e-01
    z[1,4,3]  R1253     -2.3695114254951477e-01
    z[1,4,3]  R1254     -0.384262353181839
    z[1,4,3]  R1255     0.0794503390789032
    z[1,4,3]  R1256     2.3354966938495636e-01
    z[1,4,3]  R1257     -3.7225788831710815e-01
    z[1,4,3]  R1258     -0.152827650308609
    z[1,4,3]  R1259     5.2892103791236877e-02
    z[1,4,3]  R1260     4.5519590377807617e-01
    z[1,4,3]  R1261     -5.3364926576614380e-01
    z[1,4,3]  R1262     -3.1549653410911560e-01
    z[1,4,3]  R1263     -5.7637596130371094e-01
    z[1,4,3]  R1264     -4.6700218319892883e-01
    z[1,4,3]  R1265     1.2275058031082153e-01
    z[1,4,3]  R1266     2.8028586506843567e-01
    z[1,4,3]  R1267     -2.9184681177139282e-01
    z[1,4,3]  R1268     4.9547683447599411e-02
    z[1,4,3]  R1269     1.1898304522037506e-01
    z[1,4,3]  R1270     1.1744812875986099e-01
    z[1,4,3]  R1271     1.3186505995690823e-02
    z[1,4,3]  R1272     2.9272291064262390e-01
    z[1,4,3]  R1273     -3.4841954708099365e-01
    z[1,4,3]  R1274     7.4020475149154663e-02
    z[1,4,3]  R1275     -3.4547463059425354e-01
    z[1,4,3]  R1276     -2.3175922036170959e-01
    z[1,4,3]  R1277     8.8113643229007721e-02
    z[1,4,3]  R1278     1.1977697908878326e-01
    z[1,4,3]  R1279     -3.4683072566986084e-01
    z[1,4,3]  R1280     -6.3989430665969849e-01
    z[1,4,3]  R1281     -4.4078847765922546e-01
    z[1,4,3]  R1282     -3.9069369435310364e-01
    z[1,4,3]  R1283     -1.4880749583244324e-01
    z[1,4,3]  R1284     6.0058438777923584e-01
    z[1,4,3]  R1285     -4.9394312500953674e-01
    z[1,4,3]  R1286     1.3339401781558990e-01
    z[1,4,3]  R1287     -3.6142196506261826e-02
    z[1,4,3]  R1288     -8.2534685730934143e-02
    z[1,4,3]  R1289     -4.1981092095375061e-01
    z[1,4,3]  R1290     -1.6490165144205093e-02
    z[1,4,3]  R1291     -4.8603683710098267e-01
    z[1,4,3]  R1292     -4.1447019577026367e-01
    z[1,4,3]  R1293     -1.4740024507045746e-01
    z[1,4,3]  R1294     -1.9657707214355469e-01
    z[1,4,3]  R1295     1.4049349725246429e-01
    z[1,4,3]  R1296     -5.3508497774600983e-02
    z[1,4,3]  R1297     -3.9368104934692383e-01
    z[1,4,3]  R1298     -4.3956348299980164e-01
    z[1,4,3]  R1299     -7.0799507200717926e-02
    z[1,4,3]  R1300     -3.5371506214141846e-01
    z[1,4,3]  R1301     -8.1046774983406067e-02
    z[1,4,3]  R1302     5.0250524654984474e-03
    z[1,4,3]  R1303     -1.6853669285774231e-01
    z[1,4,3]  R1304     3.2198518514633179e-01
    z[1,4,3]  R1305     -3.1587982177734375e-01
    z[1,4,3]  R1306     1.2399684637784958e-01
    z[1,4,3]  R1307     0.325998991727829
    z[1,4,3]  R1308     1.2346013635396957e-01
    z[1,4,3]  R1309     1.2125533074140549e-01
    z[1,4,3]  R1310     -3.0911889672279358e-01
    z[1,4,3]  R1311     -3.4176650643348694e-01
    z[1,4,3]  R1312     3.5552024841308594e-01
    z[1,4,3]  R1313     4.6924769878387451e-01
    z[1,4,3]  R1314     -2.5024303793907166e-01
    z[1,4,3]  R1315     -3.3788588643074036e-01
    z[1,4,3]  R1316     -3.6288508772850037e-01
    z[1,4,3]  R1317     -1.9072756171226501e-01
    z[1,4,3]  R1318     -4.1188588738441467e-01
    z[1,4,3]  R1319     1.1242207884788513e-01
    z[1,4,3]  R1320     5.2938532829284668e-01
    z[1,4,3]  R1321     3.5849779844284058e-01
    z[1,4,3]  R1322     6.4723688364028931e-01
    z[1,4,3]  R1323     4.5425498485565186e-01
    z[1,4,4]  R15       -1
    z[1,4,4]  R42       1
    z[1,4,4]  R1148     -1
    z[1,4,4]  R1149     1
    z[1,4,4]  R1154     -1.2811103463172913e-01
    z[1,4,4]  R1155     9.8769381642341614e-02
    z[1,4,4]  R1156     3.9514090865850449e-02
    z[1,4,4]  R1157     1.7906357347965240e-01
    z[1,4,4]  R1158     5.0745550543069839e-02
    z[1,4,4]  R1159     -3.1483915448188782e-01
    z[1,4,4]  R1160     1.2532761693000793e-01
    z[1,4,4]  R1161     2.5661385059356689e-01
    z[1,4,4]  R1162     -1.0935959964990616e-01
    z[1,4,4]  R1163     -0.383960098028183
    z[1,4,4]  R1164     -1.0561495274305344e-01
    z[1,4,4]  R1165     -6.1047445982694626e-02
    z[1,4,4]  R1166     -2.4713041260838509e-02
    z[1,4,4]  R1167     2.0410059392452240e-01
    z[1,4,4]  R1168     -2.5440940260887146e-01
    z[1,4,4]  R1169     -1.5176208317279816e-01
    z[1,4,4]  R1170     -1.5687119215726852e-02
    z[1,4,4]  R1171     3.0090346932411194e-02
    z[1,4,4]  R1172     2.2111959755420685e-01
    z[1,4,4]  R1173     -1.6021193563938141e-01
    z[1,4,4]  R1174     -6.7464607954025269e-01
    z[1,4,4]  R1175     -7.1750218048691750e-03
    z[1,4,4]  R1176     -1.0470546036958694e-01
    z[1,4,4]  R1177     3.6146417260169983e-02
    z[1,4,4]  R1178     4.6560221910476685e-01
    z[1,4,4]  R1179     -2.4388229846954346e-01
    z[1,4,4]  R1180     -0.421680748462677
    z[1,4,4]  R1181     1.0703993588685989e-01
    z[1,4,4]  R1182     4.0497452020645142e-01
    z[1,4,4]  R1183     5.0599622726440430e-01
    z[1,4,4]  R1184     -1.1077462881803513e-01
    z[1,4,4]  R1185     4.4569492340087891e-01
    z[1,4,4]  R1186     5.8734100311994553e-02
    z[1,4,4]  R1187     2.5616383552551270e-01
    z[1,4,4]  R1188     1.9701224565505981e-01
    z[1,4,4]  R1189     -8.4607586264610291e-02
    z[1,4,4]  R1190     -2.1708090603351593e-01
    z[1,4,4]  R1191     3.2076227664947510e-01
    z[1,4,4]  R1192     3.6794742941856384e-01
    z[1,4,4]  R1193     7.5871430337429047e-02
    z[1,4,4]  R1194     -4.4188475608825684e-01
    z[1,4,4]  R1195     3.7901178002357483e-02
    z[1,4,4]  R1196     -3.8594129681587219e-01
    z[1,4,4]  R1197     -0.196554496884346
    z[1,4,4]  R1198     -6.4528220891952515e-01
    z[1,4,4]  R1199     3.7812665104866028e-01
    z[1,4,4]  R1200     -2.7227890491485596e-01
    z[1,4,4]  R1201     -4.9730318784713745e-01
    z[1,4,4]  R1202     -4.7969445586204529e-01
    z[1,4,4]  R1203     -3.1444844603538513e-01
    z[1,4,4]  R1204     -2.6763904094696045e-01
    z[1,4,4]  R1205     -3.6290460824966431e-01
    z[1,4,4]  R1206     1.3922120630741119e-01
    z[1,4,4]  R1207     2.2006702423095703e-01
    z[1,4,4]  R1208     -1.4936453104019165e-01
    z[1,4,4]  R1209     3.6574614048004150e-01
    z[1,4,4]  R1210     -2.0260740816593170e-01
    z[1,4,4]  R1211     -4.5631805062294006e-01
    z[1,4,4]  R1212     -7.9937577247619629e-03
    z[1,4,4]  R1213     -1.2307025492191315e-01
    z[1,4,4]  R1214     -2.0108424127101898e-01
    z[1,4,4]  R1215     7.9773432016372681e-01
    z[1,4,4]  R1216     2.9656341299414635e-02
    z[1,4,4]  R1217     -4.3531331419944763e-01
    z[1,4,4]  R1218     -1.5251480042934418e-02
    z[1,4,4]  R1219     1.6486409306526184e-01
    z[1,4,4]  R1220     3.1822186708450317e-01
    z[1,4,4]  R1221     3.8033452630043030e-01
    z[1,4,4]  R1222     -2.7622884511947632e-01
    z[1,4,4]  R1223     6.9422118365764618e-02
    z[1,4,4]  R1224     -2.4084742367267609e-01
    z[1,4,4]  R1225     2.7856758236885071e-01
    z[1,4,4]  R1226     3.8693848252296448e-01
    z[1,4,4]  R1227     4.1001993417739868e-01
    z[1,4,4]  R1228     7.1121048927307129e-01
    z[1,4,4]  R1229     3.3168014883995056e-01
    z[1,4,4]  R1230     0.187080979347229
    z[1,4,4]  R1231     1.0877946764230728e-01
    z[1,4,4]  R1232     -2.9853085055947304e-02
    z[1,4,4]  R1233     3.7477380037307739e-01
    z[1,4,4]  R1234     -1.1472114175558090e-01
    z[1,4,4]  R1235     -1.1252373456954956e-01
    z[1,4,4]  R1236     -2.7165785431861877e-02
    z[1,4,4]  R1237     -4.0477615594863892e-01
    z[1,4,4]  R1238     7.2668421268463135e-01
    z[1,4,4]  R1239     6.1354964971542358e-01
    z[1,4,4]  R1240     -9.9070511758327484e-02
    z[1,4,4]  R1241     0.409146249294281
    z[1,4,4]  R1242     -6.6583938896656036e-02
    z[1,4,4]  R1243     2.5064873695373535e-01
    z[1,4,4]  R1244     1.3133677840232849e-01
    z[1,4,4]  R1245     -3.3229254186153412e-02
    z[1,4,4]  R1246     -3.2199618220329285e-01
    z[1,4,4]  R1247     1.4842495322227478e-01
    z[1,4,4]  R1248     -3.7058830261230469e-01
    z[1,4,4]  R1249     6.1142629384994507e-01
    z[1,4,4]  R1250     -2.3097884654998779e-01
    z[1,4,4]  R1251     3.4388538450002670e-02
    z[1,4,4]  R1252     -3.0489778518676758e-01
    z[1,4,4]  R1253     -0.0886390283703804
    z[1,4,4]  R1254     3.1590268015861511e-01
    z[1,4,4]  R1255     2.3376764729619026e-03
    z[1,4,4]  R1256     3.7073215842247009e-01
    z[1,4,4]  R1257     4.4369032979011536e-01
    z[1,4,4]  R1258     4.6025916934013367e-01
    z[1,4,4]  R1259     3.5726550966501236e-02
    z[1,4,4]  R1260     3.6453232169151306e-01
    z[1,4,4]  R1261     -3.4587019681930542e-01
    z[1,4,4]  R1262     -2.4863809812813997e-03
    z[1,4,4]  R1263     -5.2206773310899734e-02
    z[1,4,4]  R1264     2.4215477705001831e-01
    z[1,4,4]  R1265     1.8904080986976624e-01
    z[1,4,4]  R1266     1.5691670775413513e-01
    z[1,4,4]  R1267     5.7197425514459610e-02
    z[1,4,4]  R1268     -1.7119950056076050e-01
    z[1,4,4]  R1269     3.0332329869270325e-01
    z[1,4,4]  R1270     -1.3827908039093018e-01
    z[1,4,4]  R1271     3.6695733666419983e-01
    z[1,4,4]  R1272     -1.0033635795116425e-01
    z[1,4,4]  R1273     -3.8435709476470947e-01
    z[1,4,4]  R1274     4.3267095088958740e-01
    z[1,4,4]  R1275     -2.3215970396995544e-01
    z[1,4,4]  R1276     -3.3439084887504578e-01
    z[1,4,4]  R1277     -1.2737533450126648e-01
    z[1,4,4]  R1278     2.2421942651271820e-01
    z[1,4,4]  R1279     -3.1862971186637878e-01
    z[1,4,4]  R1280     -1.4161466062068939e-01
    z[1,4,4]  R1281     -2.0014038681983948e-01
    z[1,4,4]  R1282     -1.7013674974441528e-01
    z[1,4,4]  R1283     -2.2357928752899170e-01
    z[1,4,4]  R1284     4.8134982585906982e-01
    z[1,4,4]  R1285     3.0386200547218323e-01
    z[1,4,4]  R1286     5.6228119134902954e-01
    z[1,4,4]  R1287     2.6087793707847595e-01
    z[1,4,4]  R1288     -1.7765650525689125e-02
    z[1,4,4]  R1289     5.7998904958367348e-03
    z[1,4,4]  R1290     -1.9561885297298431e-01
    z[1,4,4]  R1291     -1.5254600346088409e-01
    z[1,4,4]  R1292     -2.3245088756084442e-01
    z[1,4,4]  R1293     -2.4510839581489563e-01
    z[1,4,4]  R1294     3.4389652311801910e-02
    z[1,4,4]  R1295     1.6696244478225708e-01
    z[1,4,4]  R1296     3.9626786112785339e-01
    z[1,4,4]  R1297     -4.9778923392295837e-02
    z[1,4,4]  R1298     1.0410825908184052e-01
    z[1,4,4]  R1299     -3.0679020285606384e-01
    z[1,4,4]  R1300     2.2262823581695557e-01
    z[1,4,4]  R1301     -0.0813310518860817
    z[1,4,4]  R1302     9.8297655582427979e-02
    z[1,4,4]  R1303     9.0512603521347046e-02
    z[1,4,4]  R1304     4.6489360928535461e-01
    z[1,4,4]  R1305     -9.3833103775978088e-02
    z[1,4,4]  R1306     4.2973878979682922e-01
    z[1,4,4]  R1307     3.6662909388542175e-01
    z[1,4,4]  R1308     5.0199198722839355e-01
    z[1,4,4]  R1309     -4.3391962535679340e-03
    z[1,4,4]  R1310     1.9471764564514160e-01
    z[1,4,4]  R1311     -2.9023903608322144e-01
    z[1,4,4]  R1312     -2.7248394489288330e-01
    z[1,4,4]  R1313     -2.4616238474845886e-01
    z[1,4,4]  R1314     2.4163340032100677e-01
    z[1,4,4]  R1315     -2.2500516474246979e-01
    z[1,4,4]  R1316     -1.0002250224351883e-01
    z[1,4,4]  R1317     -7.6770171523094177e-02
    z[1,4,4]  R1318     -2.0987370610237122e-01
    z[1,4,4]  R1319     -1.0867885500192642e-01
    z[1,4,4]  R1320     -6.6451430320739746e-02
    z[1,4,4]  R1321     -5.7496535778045654e-01
    z[1,4,4]  R1322     -4.4193667173385620e-01
    z[1,4,4]  R1323     -4.9371123313903809e-01
    z[1,4,5]  R16       -1
    z[1,4,5]  R43       1
    z[1,4,5]  R1150     -1
    z[1,4,5]  R1151     1
    z[1,4,5]  R1154     -1.4402790367603302e-01
    z[1,4,5]  R1155     4.5146383345127106e-02
    z[1,4,5]  R1156     1.1751770973205566e-01
    z[1,4,5]  R1157     4.2257276177406311e-01
    z[1,4,5]  R1158     1.0330075025558472e-01
    z[1,4,5]  R1159     3.4574690461158752e-01
    z[1,4,5]  R1160     1.7807528376579285e-01
    z[1,4,5]  R1161     -1.4250756241381168e-02
    z[1,4,5]  R1162     5.1383594982326031e-03
    z[1,4,5]  R1163     -1.3030184805393219e-01
    z[1,4,5]  R1164     4.7639212012290955e-01
    z[1,4,5]  R1165     3.3835160732269287e-01
    z[1,4,5]  R1166     1.3196520507335663e-01
    z[1,4,5]  R1167     5.4228603839874268e-01
    z[1,4,5]  R1168     0.332433819770813
    z[1,4,5]  R1169     1.7465837299823761e-01
    z[1,4,5]  R1170     5.2098482847213745e-01
    z[1,4,5]  R1171     5.0092417001724243e-01
    z[1,4,5]  R1172     3.1437876820564270e-01
    z[1,4,5]  R1173     -0.0597243569791317
    z[1,4,5]  R1174     -1.8792058527469635e-01
    z[1,4,5]  R1175     -1.9813102483749390e-01
    z[1,4,5]  R1176     -3.5396766662597656e-01
    z[1,4,5]  R1177     -1.2771297991275787e-01
    z[1,4,5]  R1178     -4.5337450504302979e-01
    z[1,4,5]  R1179     -2.8609189391136169e-01
    z[1,4,5]  R1180     -1.7389757931232452e-01
    z[1,4,5]  R1181     -4.0819168090820312e-01
    z[1,4,5]  R1182     -2.2313356399536133e-01
    z[1,4,5]  R1183     -2.3613187670707703e-01
    z[1,4,5]  R1184     1.8409633636474609e-01
    z[1,4,5]  R1185     8.4336094558238983e-02
    z[1,4,5]  R1186     7.1165359020233154e-01
    z[1,4,5]  R1187     -1.4875005185604095e-01
    z[1,4,5]  R1188     -2.2034212946891785e-01
    z[1,4,5]  R1189     -2.9223549365997314e-01
    z[1,4,5]  R1190     -1.1317928880453110e-01
    z[1,4,5]  R1191     -2.9599642753601074e-01
    z[1,4,5]  R1192     -2.4392421543598175e-01
    z[1,4,5]  R1193     -1.7684239149093628e-01
    z[1,4,5]  R1194     3.1072497367858887e-01
    z[1,4,5]  R1195     8.6572587490081787e-02
    z[1,4,5]  R1196     9.3467950820922852e-02
    z[1,4,5]  R1197     2.9265916347503662e-01
    z[1,4,5]  R1198     9.4040319323539734e-02
    z[1,4,5]  R1199     -0.300374835729599
    z[1,4,5]  R1200     -1.2064851820468903e-01
    z[1,4,5]  R1201     2.1226347982883453e-01
    z[1,4,5]  R1202     2.9925328493118286e-01
    z[1,4,5]  R1203     -2.4028530716896057e-01
    z[1,4,5]  R1204     8.8568501174449921e-02
    z[1,4,5]  R1205     -1.9132284214720130e-03
    z[1,4,5]  R1206     2.4026885628700256e-01
    z[1,4,5]  R1207     -6.7815303802490234e-02
    z[1,4,5]  R1208     1.4808064699172974e-01
    z[1,4,5]  R1209     -9.7954049706459045e-02
    z[1,4,5]  R1210     -4.0656840801239014e-01
    z[1,4,5]  R1211     5.9593491256237030e-02
    z[1,4,5]  R1212     1.0588598251342773e-01
    z[1,4,5]  R1213     -6.8894013762474060e-02
    z[1,4,5]  R1214     4.7643181681632996e-01
    z[1,4,5]  R1215     6.1530273407697678e-02
    z[1,4,5]  R1216     -0.0348796509206295
    z[1,4,5]  R1217     5.9020388126373291e-01
    z[1,4,5]  R1218     -1.7851024866104126e-01
    z[1,4,5]  R1219     -2.3533992469310760e-01
    z[1,4,5]  R1220     1.3561421632766724e-01
    z[1,4,5]  R1221     -2.1379022300243378e-01
    z[1,4,5]  R1222     2.2489269077777863e-01
    z[1,4,5]  R1223     -2.5495597720146179e-01
    z[1,4,5]  R1224     4.8909124732017517e-01
    z[1,4,5]  R1225     3.2360464334487915e-01
    z[1,4,5]  R1226     1.2746696174144745e-01
    z[1,4,5]  R1227     -6.3453322649002075e-01
    z[1,4,5]  R1228     -3.8612812757492065e-01
    z[1,4,5]  R1229     -1.6239969432353973e-01
    z[1,4,5]  R1230     -2.5596126914024353e-01
    z[1,4,5]  R1231     -4.0585622191429138e-01
    z[1,4,5]  R1232     -4.1404470801353455e-01
    z[1,4,5]  R1233     -4.8035117983818054e-01
    z[1,4,5]  R1234     3.8111633062362671e-01
    z[1,4,5]  R1235     5.5571067333221436e-01
    z[1,4,5]  R1236     1.8060798943042755e-01
    z[1,4,5]  R1237     -1.1214573681354523e-01
    z[1,4,5]  R1238     1.6730263829231262e-01
    z[1,4,5]  R1239     5.3711807727813721e-01
    z[1,4,5]  R1240     7.2642147541046143e-02
    z[1,4,5]  R1241     1.1676761507987976e-01
    z[1,4,5]  R1242     -7.5571663677692413e-02
    z[1,4,5]  R1243     1.6545480489730835e-01
    z[1,4,5]  R1244     -4.1990029811859131e-01
    z[1,4,5]  R1245     -6.0991442203521729e-01
    z[1,4,5]  R1246     -4.6201825141906738e-01
    z[1,4,5]  R1247     0.0101442476734519
    z[1,4,5]  R1248     -6.8104475736618042e-02
    z[1,4,5]  R1249     -2.8355339169502258e-01
    z[1,4,5]  R1250     -7.7083487994968891e-03
    z[1,4,5]  R1251     -1.7236265540122986e-01
    z[1,4,5]  R1252     -2.4853106588125229e-02
    z[1,4,5]  R1253     -8.7030403316020966e-02
    z[1,4,5]  R1254     -1.6514272987842560e-01
    z[1,4,5]  R1255     -2.5870227813720703e-01
    z[1,4,5]  R1256     -4.4403988122940063e-01
    z[1,4,5]  R1257     -3.7668019533157349e-01
    z[1,4,5]  R1258     -2.0139142870903015e-01
    z[1,4,5]  R1259     -7.1815311908721924e-01
    z[1,4,5]  R1260     1.2453091889619827e-01
    z[1,4,5]  R1261     -2.5025227665901184e-01
    z[1,4,5]  R1262     -3.5274305939674377e-01
    z[1,4,5]  R1263     -6.1772572994232178e-01
    z[1,4,5]  R1264     -6.2005412578582764e-01
    z[1,4,5]  R1265     -4.0256899595260620e-01
    z[1,4,5]  R1266     3.3030384778976440e-01
    z[1,4,5]  R1267     4.0965270996093750e-01
    z[1,4,5]  R1268     -4.8622965812683105e-01
    z[1,4,5]  R1269     1.9258794188499451e-01
    z[1,4,5]  R1270     1.0406956821680069e-01
    z[1,4,5]  R1271     8.2377210259437561e-02
    z[1,4,5]  R1272     -8.4257304668426514e-02
    z[1,4,5]  R1273     3.9063131809234619e-01
    z[1,4,5]  R1274     1.0816441476345062e-01
    z[1,4,5]  R1275     0.349244624376297
    z[1,4,5]  R1276     -3.9362901449203491e-01
    z[1,4,5]  R1277     -5.9012597799301147e-01
    z[1,4,5]  R1278     -7.8150975704193115e-01
    z[1,4,5]  R1279     -6.7393243312835693e-01
    z[1,4,5]  R1280     -2.3224505782127380e-01
    z[1,4,5]  R1281     -6.3647961616516113e-01
    z[1,4,5]  R1282     -6.0548824071884155e-01
    z[1,4,5]  R1283     -1.4366070926189423e-01
    z[1,4,5]  R1284     4.4098678976297379e-02
    z[1,4,5]  R1285     -4.5739594101905823e-01
    z[1,4,5]  R1286     1.4385650865733624e-02
    z[1,4,5]  R1287     -5.9956979751586914e-01
    z[1,4,5]  R1288     -6.7116081714630127e-01
    z[1,4,5]  R1289     -5.8865559101104736e-01
    z[1,4,5]  R1290     -1.8110229074954987e-01
    z[1,4,5]  R1291     -1.0773810744285583e-01
    z[1,4,5]  R1292     2.6756206154823303e-01
    z[1,4,5]  R1293     1.8646885454654694e-01
    z[1,4,5]  R1294     -5.6428488343954086e-02
    z[1,4,5]  R1295     2.0217919349670410e-01
    z[1,4,5]  R1296     -3.9791306853294373e-01
    z[1,4,5]  R1297     -5.7171505689620972e-01
    z[1,4,5]  R1298     -3.4493902325630188e-01
    z[1,4,5]  R1299     7.1420714259147644e-02
    z[1,4,5]  R1300     3.5805463790893555e-01
    z[1,4,5]  R1301     -1.9722411036491394e-01
    z[1,4,5]  R1302     -1.6521330177783966e-01
    z[1,4,5]  R1303     -5.1570698618888855e-02
    z[1,4,5]  R1304     2.0275006070733070e-02
    z[1,4,5]  R1305     -3.8745424151420593e-01
    z[1,4,5]  R1306     -1.4860782027244568e-01
    z[1,4,5]  R1307     -2.1801829338073730e-01
    z[1,4,5]  R1308     2.8767675161361694e-01
    z[1,4,5]  R1309     -4.2009210586547852e-01
    z[1,4,5]  R1310     3.5468569397926331e-01
    z[1,4,5]  R1311     2.0468638837337494e-01
    z[1,4,5]  R1312     1.5067258477210999e-01
    z[1,4,5]  R1313     -2.4595342576503754e-02
    z[1,4,5]  R1314     -8.1414008140563965e-01
    z[1,4,5]  R1315     0.0750207006931305
    z[1,4,5]  R1316     -0.131648451089859
    z[1,4,5]  R1317     1.3997261226177216e-01
    z[1,4,5]  R1318     2.8227525949478149e-01
    z[1,4,5]  R1319     1.3914388418197632e-01
    z[1,4,5]  R1320     1.4618138968944550e-01
    z[1,4,5]  R1321     -1.0838557034730911e-01
    z[1,4,5]  R1322     -1.1386824399232864e-01
    z[1,4,5]  R1323     1.1800454556941986e-01
    z[1,4,6]  R17       -1
    z[1,4,6]  R44       1
    z[1,4,6]  R1152     -1
    z[1,4,6]  R1153     1
    z[1,4,6]  R1154     3.8310918211936951e-01
    z[1,4,6]  R1155     3.4259554743766785e-01
    z[1,4,6]  R1156     3.3546081185340881e-01
    z[1,4,6]  R1157     -0.141708105802536
    z[1,4,6]  R1158     2.9049226641654968e-01
    z[1,4,6]  R1159     -6.6882841289043427e-02
    z[1,4,6]  R1160     -1.5954727306962013e-02
    z[1,4,6]  R1161     2.4336050450801849e-01
    z[1,4,6]  R1162     -4.4455981254577637e-01
    z[1,4,6]  R1163     -3.1602874398231506e-01
    z[1,4,6]  R1164     2.6858173310756683e-02
    z[1,4,6]  R1165     1.3759815692901611e-01
    z[1,4,6]  R1166     -1.9455698132514954e-01
    z[1,4,6]  R1167     -2.7928901836276054e-02
    z[1,4,6]  R1168     3.9691379666328430e-01
    z[1,4,6]  R1169     -9.4235010445117950e-02
    z[1,4,6]  R1170     -4.6372160315513611e-01
    z[1,4,6]  R1171     1.3849860429763794e-01
    z[1,4,6]  R1172     6.0068508610129356e-03
    z[1,4,6]  R1173     1.4758543670177460e-01
    z[1,4,6]  R1174     8.9115403592586517e-02
    z[1,4,6]  R1175     -1.7295074462890625e-01
    z[1,4,6]  R1176     4.5295480638742447e-02
    z[1,4,6]  R1177     -0.429155170917511
    z[1,4,6]  R1178     -9.0533353388309479e-02
    z[1,4,6]  R1179     -1.8242296576499939e-01
    z[1,4,6]  R1180     -1.9455881416797638e-01
    z[1,4,6]  R1181     -2.1512724459171295e-01
    z[1,4,6]  R1182     1.9915764033794403e-01
    z[1,4,6]  R1183     1.0617773979902267e-02
    z[1,4,6]  R1184     -2.6905581355094910e-01
    z[1,4,6]  R1185     -1.7250110208988190e-01
    z[1,4,6]  R1186     1.7161907255649567e-01
    z[1,4,6]  R1187     1.5332300961017609e-01
    z[1,4,6]  R1188     -7.1559733152389526e-01
    z[1,4,6]  R1189     -2.6875638961791992e-01
    z[1,4,6]  R1190     -3.4160980582237244e-01
    z[1,4,6]  R1191     -6.4790071919560432e-03
    z[1,4,6]  R1192     -8.3678871393203735e-02
    z[1,4,6]  R1193     1.4622308313846588e-01
    z[1,4,6]  R1194     -4.0118601173162460e-02
    z[1,4,6]  R1195     -0.0113369794562459
    z[1,4,6]  R1196     1.1757802218198776e-01
    z[1,4,6]  R1197     -2.9616445302963257e-01
    z[1,4,6]  R1198     -1.2719714641571045e-01
    z[1,4,6]  R1199     3.1891950964927673e-01
    z[1,4,6]  R1200     -1.4607398211956024e-01
    z[1,4,6]  R1201     2.3893110454082489e-02
    z[1,4,6]  R1202     -2.3453857004642487e-01
    z[1,4,6]  R1203     -2.7294633910059929e-02
    z[1,4,6]  R1204     1.1803147196769714e-01
    z[1,4,6]  R1205     8.1077076494693756e-02
    z[1,4,6]  R1206     -2.1415489912033081e-01
    z[1,4,6]  R1207     -1.4506998658180237e-01
    z[1,4,6]  R1208     -7.1462929248809814e-01
    z[1,4,6]  R1209     -1.9606147706508636e-01
    z[1,4,6]  R1210     7.2265923023223877e-02
    z[1,4,6]  R1211     -4.1635073721408844e-02
    z[1,4,6]  R1212     6.7983572371304035e-03
    z[1,4,6]  R1213     -1.1469484865665436e-01
    z[1,4,6]  R1214     -3.3874136209487915e-01
    z[1,4,6]  R1215     -1.5532813034951687e-02
    z[1,4,6]  R1216     -1.3888043165206909e-01
    z[1,4,6]  R1217     2.2395296394824982e-01
    z[1,4,6]  R1218     7.9197414219379425e-02
    z[1,4,6]  R1219     1.1739090085029602e-01
    z[1,4,6]  R1220     -2.0323191583156586e-01
    z[1,4,6]  R1221     4.7606897354125977e-01
    z[1,4,6]  R1222     -1.5488071739673615e-01
    z[1,4,6]  R1223     -1.8255972862243652e-01
    z[1,4,6]  R1224     -2.6468801498413086e-01
    z[1,4,6]  R1225     2.0553344488143921e-01
    z[1,4,6]  R1226     0.451729416847229
    z[1,4,6]  R1227     -1.1594294756650925e-01
    z[1,4,6]  R1228     -3.4763699769973755e-01
    z[1,4,6]  R1229     -1.0595864616334438e-02
    z[1,4,6]  R1230     -3.2378476113080978e-02
    z[1,4,6]  R1231     3.1050181388854980e-01
    z[1,4,6]  R1232     -4.1898640990257263e-01
    z[1,4,6]  R1233     -1.9147852063179016e-01
    z[1,4,6]  R1234     2.7287659049034119e-01
    z[1,4,6]  R1235     -8.6940238252282143e-03
    z[1,4,6]  R1236     3.3845886588096619e-01
    z[1,4,6]  R1237     -5.6192469596862793e-01
    z[1,4,6]  R1238     3.7011390924453735e-01
    z[1,4,6]  R1239     9.6734218299388885e-02
    z[1,4,6]  R1240     2.8947748243808746e-02
    z[1,4,6]  R1241     8.4491841495037079e-02
    z[1,4,6]  R1242     -2.7116268873214722e-01
    z[1,4,6]  R1243     5.5536723136901855e-01
    z[1,4,6]  R1244     -1.0864780098199844e-01
    z[1,4,6]  R1245     -3.1635737419128418e-01
    z[1,4,6]  R1246     2.7368339896202087e-01
    z[1,4,6]  R1247     -6.4924255013465881e-02
    z[1,4,6]  R1248     1.6080971807241440e-02
    z[1,4,6]  R1249     1.1388626694679260e-01
    z[1,4,6]  R1250     -1.1335127800703049e-01
    z[1,4,6]  R1251     6.2742494046688080e-02
    z[1,4,6]  R1252     8.7315574288368225e-02
    z[1,4,6]  R1253     -4.3224021792411804e-01
    z[1,4,6]  R1254     4.6385556459426880e-01
    z[1,4,6]  R1255     1.3388817012310028e-01
    z[1,4,6]  R1256     -1.0406203567981720e-01
    z[1,4,6]  R1257     -3.2532370090484619e-01
    z[1,4,6]  R1258     -5.8396351337432861e-01
    z[1,4,6]  R1259     -6.0750752687454224e-02
    z[1,4,6]  R1260     3.7941977381706238e-01
    z[1,4,6]  R1261     -8.0928064882755280e-02
    z[1,4,6]  R1262     -3.2811298966407776e-01
    z[1,4,6]  R1263     5.3886175155639648e-03
    z[1,4,6]  R1264     -2.4670192599296570e-01
    z[1,4,6]  R1265     1.5145288407802582e-01
    z[1,4,6]  R1266     -1.2451510876417160e-01
    z[1,4,6]  R1267     1.9450066983699799e-01
    z[1,4,6]  R1268     5.6221973150968552e-02
    z[1,4,6]  R1269     4.0203872323036194e-01
    z[1,4,6]  R1270     -6.0775661468505859e-01
    z[1,4,6]  R1271     -4.1605624556541443e-01
    z[1,4,6]  R1272     -2.0083867013454437e-02
    z[1,4,6]  R1273     -4.1355829685926437e-02
    z[1,4,6]  R1274     0.169141948223114
    z[1,4,6]  R1275     -2.3644529283046722e-01
    z[1,4,6]  R1276     -5.4670977592468262e-01
    z[1,4,6]  R1277     -4.8036286234855652e-01
    z[1,4,6]  R1278     -1.3549636304378510e-01
    z[1,4,6]  R1279     1.3533039391040802e-01
    z[1,4,6]  R1280     -3.3536779880523682e-01
    z[1,4,6]  R1281     -7.4160680174827576e-02
    z[1,4,6]  R1282     3.9604222774505615e-01
    z[1,4,6]  R1283     8.2372479140758514e-02
    z[1,4,6]  R1284     -2.0938409864902496e-01
    z[1,4,6]  R1285     -9.9131613969802856e-02
    z[1,4,6]  R1286     -1.5620626509189606e-01
    z[1,4,6]  R1287     -3.5751909017562866e-02
    z[1,4,6]  R1288     3.4721937775611877e-01
    z[1,4,6]  R1289     -1.6696329414844513e-01
    z[1,4,6]  R1290     -5.4487246274948120e-01
    z[1,4,6]  R1291     2.4621315300464630e-01
    z[1,4,6]  R1292     -2.9758375883102417e-01
    z[1,4,6]  R1293     -3.2744112610816956e-01
    z[1,4,6]  R1294     -1.3781943917274475e-01
    z[1,4,6]  R1295     1.9308337569236755e-01
    z[1,4,6]  R1296     -4.1964939236640930e-01
    z[1,4,6]  R1297     -3.2751351594924927e-02
    z[1,4,6]  R1298     4.0953123569488525e-01
    z[1,4,6]  R1299     -2.7584463357925415e-01
    z[1,4,6]  R1300     -6.4742863178253174e-01
    z[1,4,6]  R1301     -1.5823251008987427e-01
    z[1,4,6]  R1302     1.8326042592525482e-01
    z[1,4,6]  R1303     8.2990802824497223e-02
    z[1,4,6]  R1304     -6.4104783535003662e-01
    z[1,4,6]  R1305     -7.6623722910881042e-02
    z[1,4,6]  R1306     -1.5886804461479187e-01
    z[1,4,6]  R1307     2.6446020603179932e-01
    z[1,4,6]  R1308     -4.7957371920347214e-02
    z[1,4,6]  R1309     1.0231915861368179e-01
    z[1,4,6]  R1310     -6.3529020547866821e-01
    z[1,4,6]  R1311     -2.9536217451095581e-01
    z[1,4,6]  R1312     -1.2536510825157166e-01
    z[1,4,6]  R1313     -2.9091672971844673e-02
    z[1,4,6]  R1314     -2.2160361707210541e-01
    z[1,4,6]  R1315     -4.0055537223815918e-01
    z[1,4,6]  R1316     -0.0674145370721817
    z[1,4,6]  R1317     7.8882798552513123e-02
    z[1,4,6]  R1318     3.0971509218215942e-01
    z[1,4,6]  R1319     2.9696798324584961e-01
    z[1,4,6]  R1320     1.4758327975869179e-02
    z[1,4,6]  R1321     2.4358795583248138e-01
    z[1,4,6]  R1322     1.0696541517972946e-01
    z[1,4,6]  R1323     3.1952759623527527e-01
    z[4,1,0]  R11       1
    z[4,1,0]  R38       -1
    z[4,1,0]  R1324     -1
    z[4,1,0]  R1325     1
    z[4,1,0]  R1338     -7.5595939159393311e-01
    z[4,1,0]  R1339     -3.8382682204246521e-01
    z[4,1,0]  R1340     -3.0085310339927673e-01
    z[4,1,0]  R1341     -4.3898898363113403e-01
    z[4,1,0]  R1342     -5.3916312754154205e-02
    z[4,1,0]  R1343     2.0261155068874359e-01
    z[4,1,0]  R1344     -3.3357802033424377e-01
    z[4,1,0]  R1345     -4.6541181206703186e-01
    z[4,1,0]  R1346     -1.7482081055641174e-01
    z[4,1,0]  R1347     -3.2698640227317810e-01
    z[4,1,0]  R1348     -2.0467326045036316e-01
    z[4,1,0]  R1349     3.1608107686042786e-01
    z[4,1,0]  R1350     1.9089536741375923e-02
    z[4,1,0]  R1351     3.4732836484909058e-01
    z[4,1,0]  R1352     8.6776286363601685e-01
    z[4,1,0]  R1353     -6.4097873866558075e-02
    z[4,1,0]  R1354     9.2839550971984863e-01
    z[4,1,0]  R1355     8.8717746734619141e-01
    z[4,1,0]  R1356     0.766423225402832
    z[4,1,0]  R1357     8.0424225330352783e-01
    z[4,1,0]  R1358     2.6922184973955154e-02
    z[4,1,0]  R1359     -3.1197193264961243e-01
    z[4,1,0]  R1360     -4.2019522190093994e-01
    z[4,1,0]  R1361     8.5720755159854889e-02
    z[4,1,0]  R1362     -4.9759708344936371e-02
    z[4,1,0]  R1363     5.1685433834791183e-02
    z[4,1,0]  R1364     1.4829632639884949e-01
    z[4,1,0]  R1365     1.6176998615264893e-01
    z[4,1,0]  R1366     2.3579502105712891e-01
    z[4,1,0]  R1367     -1.4668072760105133e-01
    z[4,1,0]  R1368     -2.1438447292894125e-03
    z[4,1,0]  R1369     3.1725355982780457e-01
    z[4,1,0]  R1370     -1.7180384695529938e-01
    z[4,1,0]  R1371     -6.9005347788333893e-02
    z[4,1,0]  R1372     5.3096253424882889e-02
    z[4,1,0]  R1373     2.0548075437545776e-01
    z[4,1,0]  R1374     3.2522976398468018e-01
    z[4,1,0]  R1375     -5.1012493669986725e-02
    z[4,1,0]  R1376     9.2113900184631348e-01
    z[4,1,0]  R1377     5.6456762552261353e-01
    z[4,1,0]  R1378     -3.2004863023757935e-01
    z[4,1,0]  R1379     -1.2148412875831127e-02
    z[4,1,0]  R1380     -6.3843570649623871e-02
    z[4,1,0]  R1381     -5.1655262708663940e-02
    z[4,1,0]  R1382     -1.8021368980407715e-01
    z[4,1,0]  R1383     -1.5424399077892303e-01
    z[4,1,0]  R1384     1.2154664099216461e-01
    z[4,1,0]  R1385     8.8347233831882477e-02
    z[4,1,0]  R1386     -2.8340601921081543e-01
    z[4,1,0]  R1387     4.0016490221023560e-01
    z[4,1,0]  R1388     -2.0374859869480133e-01
    z[4,1,0]  R1389     -1.8331326544284821e-01
    z[4,1,0]  R1390     -2.9987642168998718e-01
    z[4,1,0]  R1391     -4.0957161784172058e-01
    z[4,1,0]  R1392     -2.1545775234699249e-01
    z[4,1,0]  R1393     -9.7865886986255646e-02
    z[4,1,0]  R1394     3.2939872145652771e-01
    z[4,1,0]  R1395     3.6172747611999512e-01
    z[4,1,0]  R1396     6.9161552190780640e-01
    z[4,1,0]  R1397     8.4867948293685913e-01
    z[4,1,0]  R1398     3.0808833241462708e-01
    z[4,1,0]  R1399     -1.6845524311065674e-01
    z[4,1,0]  R1400     -1.5884728729724884e-01
    z[4,1,0]  R1401     7.8646093606948853e-03
    z[4,1,0]  R1402     -3.8685572147369385e-01
    z[4,1,0]  R1403     -1.5796563029289246e-01
    z[4,1,0]  R1404     -1.0707242041826248e-01
    z[4,1,0]  R1405     9.2819523811340332e-01
    z[4,1,0]  R1406     9.1676068305969238e-01
    z[4,1,0]  R1407     8.5742688179016113e-01
    z[4,1,0]  R1408     1.1749872565269470e-01
    z[4,1,0]  R1409     -1.0967695713043213e-01
    z[4,1,0]  R1410     -9.1911517083644867e-02
    z[4,1,0]  R1411     -1.7805531620979309e-01
    z[4,1,0]  R1412     -2.5043404102325439e-01
    z[4,1,0]  R1413     2.8830792754888535e-02
    z[4,1,0]  R1414     -5.3877104073762894e-02
    z[4,1,0]  R1415     7.6644057035446167e-01
    z[4,1,0]  R1416     4.5327857136726379e-01
    z[4,1,0]  R1417     7.2841495275497437e-01
    z[4,1,0]  R1418     -1.5652939677238464e-01
    z[4,1,0]  R1419     -4.5320162177085876e-01
    z[4,1,0]  R1420     8.3178174495697021e-01
    z[4,1,0]  R1421     0.865403413772583
    z[4,1,0]  R1422     6.3283419609069824e-01
    z[4,1,0]  R1423     8.7871414422988892e-01
    z[4,1,0]  R1424     3.6707940697669983e-01
    z[4,1,0]  R1425     6.1472576856613159e-01
    z[4,1,0]  R1426     4.5549169182777405e-01
    z[4,1,0]  R1427     4.5406249165534973e-01
    z[4,1,0]  R1428     -6.7375445365905762e-01
    z[4,1,0]  R1429     -6.9888913631439209e-01
    z[4,1,0]  R1430     -0.594390869140625
    z[4,1,0]  R1431     -5.7361841201782227e-01
    z[4,1,0]  R1432     -8.2231032848358154e-01
    z[4,1,0]  R1433     -6.2316077947616577e-01
    z[4,1,0]  R1434     -5.8995449542999268e-01
    z[4,1,0]  R1435     -5.8598655462265015e-01
    z[4,1,0]  R1436     -0.606269121170044
    z[4,1,0]  R1437     -6.2820702791213989e-01
    z[4,1,0]  R1438     6.9167673587799072e-01
    z[4,1,0]  R1439     5.3233176469802856e-01
    z[4,1,0]  R1440     8.2345694303512573e-01
    z[4,1,0]  R1441     6.9714194536209106e-01
    z[4,1,0]  R1442     6.9522601366043091e-01
    z[4,1,0]  R1443     5.7812613248825073e-01
    z[4,1,0]  R1444     6.6528755426406860e-01
    z[4,1,0]  R1445     3.6091324687004089e-01
    z[4,1,0]  R1446     9.0225964784622192e-01
    z[4,1,0]  R1447     6.9183218479156494e-01
    z[4,1,0]  R1448     -1.3907539844512939e-01
    z[4,1,0]  R1449     -3.6842882633209229e-01
    z[4,1,0]  R1450     2.7511421591043472e-02
    z[4,1,0]  R1451     3.3677688241004944e-01
    z[4,1,0]  R1452     -3.0400383472442627e-01
    z[4,1,0]  R1453     0.129286989569664
    z[4,1,0]  R1454     2.0904533565044403e-01
    z[4,1,0]  R1455     -2.5468206405639648e-01
    z[4,1,0]  R1456     1.1293878406286240e-01
    z[4,1,0]  R1457     4.3662047386169434e-01
    z[4,1,0]  R1458     3.9613431692123413e-01
    z[4,1,0]  R1459     -3.3349683880805969e-01
    z[4,1,0]  R1460     -5.5167776346206665e-01
    z[4,1,0]  R1461     -2.6409402489662170e-01
    z[4,1,0]  R1462     -0.34183269739151
    z[4,1,0]  R1463     5.2882835268974304e-02
    z[4,1,0]  R1464     -8.3833348751068115e-01
    z[4,1,0]  R1465     -0.0875013917684555
    z[4,1,0]  R1466     1.0923463106155396e-01
    z[4,1,0]  R1467     -1.5071013569831848e-01
    z[4,1,0]  R1468     2.0982383191585541e-01
    z[4,1,0]  R1469     -2.2338643670082092e-01
    z[4,1,0]  R1470     -1.9661673903465271e-01
    z[4,1,0]  R1471     4.1472226381301880e-01
    z[4,1,0]  R1472     6.9381761550903320e-01
    z[4,1,0]  R1473     1.7683707177639008e-01
    z[4,1,0]  R1474     1.4207929372787476e-01
    z[4,1,0]  R1475     5.0470888614654541e-02
    z[4,1,0]  R1476     -1.8071976304054260e-01
    z[4,1,0]  R1477     -1.8040654063224792e-01
    z[4,1,0]  R1478     9.3746155500411987e-01
    z[4,1,0]  R1479     7.5093394517898560e-01
    z[4,1,0]  R1480     0.723858654499054
    z[4,1,0]  R1481     7.9731434583663940e-01
    z[4,1,0]  R1482     -1.7402684688568115e-01
    z[4,1,0]  R1483     4.5955085754394531e-01
    z[4,1,0]  R1484     -3.2479703426361084e-01
    z[4,1,0]  R1485     -8.4862513467669487e-03
    z[4,1,0]  R1486     -9.2845153808593750e-01
    z[4,1,0]  R1487     -8.3313882350921631e-01
    z[4,1,0]  R1488     -3.1924718618392944e-01
    z[4,1,0]  R1489     -4.2675679922103882e-01
    z[4,1,0]  R1490     8.1410235166549683e-01
    z[4,1,0]  R1491     -3.7976104021072388e-01
    z[4,1,0]  R1492     7.1696668863296509e-02
    z[4,1,0]  R1493     -4.5697745680809021e-01
    z[4,1,0]  R1494     -4.2993064969778061e-02
    z[4,1,0]  R1495     1.0481332242488861e-01
    z[4,1,0]  R1496     -1.7297340929508209e-01
    z[4,1,0]  R1497     4.1590067744255066e-01
    z[4,1,0]  R1498     3.9963892102241516e-01
    z[4,1,0]  R1499     -4.4773986935615540e-01
    z[4,1,0]  R1500     2.3669132962822914e-02
    z[4,1,0]  R1501     -1.5191610157489777e-01
    z[4,1,0]  R1502     -3.5037714242935181e-01
    z[4,1,0]  R1503     -1.9325231015682220e-01
    z[4,1,0]  R1504     3.1451320648193359e-01
    z[4,1,0]  R1505     -3.1922420859336853e-01
    z[4,1,0]  R1506     2.4484528601169586e-01
    z[4,1,0]  R1507     -4.3561407923698425e-01
    z[4,1,1]  R12       1
    z[4,1,1]  R39       -1
    z[4,1,1]  R1326     -1
    z[4,1,1]  R1327     1
    z[4,1,1]  R1338     -4.0895906090736389e-01
    z[4,1,1]  R1339     -5.5129384994506836e-01
    z[4,1,1]  R1340     -5.8258968591690063e-01
    z[4,1,1]  R1341     -4.0229967236518860e-01
    z[4,1,1]  R1342     -4.1316270828247070e-01
    z[4,1,1]  R1343     -4.2161974310874939e-01
    z[4,1,1]  R1344     9.1567748785018921e-01
    z[4,1,1]  R1345     6.6368746757507324e-01
    z[4,1,1]  R1346     7.1862238645553589e-01
    z[4,1,1]  R1347     6.2939703464508057e-01
    z[4,1,1]  R1348     -3.6118716001510620e-01
    z[4,1,1]  R1349     0.643488883972168
    z[4,1,1]  R1350     0.761551558971405
    z[4,1,1]  R1351     6.5792787075042725e-01
    z[4,1,1]  R1352     -3.0341061949729919e-01
    z[4,1,1]  R1353     4.7267517447471619e-01
    z[4,1,1]  R1354     -1.5194717049598694e-01
    z[4,1,1]  R1355     -8.1752061843872070e-02
    z[4,1,1]  R1356     -3.1761386990547180e-01
    z[4,1,1]  R1357     -2.4149794876575470e-01
    z[4,1,1]  R1358     7.0063757896423340e-01
    z[4,1,1]  R1359     0.634477436542511
    z[4,1,1]  R1360     5.1053810119628906e-01
    z[4,1,1]  R1361     6.3336014747619629e-01
    z[4,1,1]  R1362     0.571498453617096
    z[4,1,1]  R1363     0.624488890171051
    z[4,1,1]  R1364     6.8535220623016357e-01
    z[4,1,1]  R1365     6.0414552688598633e-01
    z[4,1,1]  R1366     0.617192268371582
    z[4,1,1]  R1367     4.7669410705566406e-01
    z[4,1,1]  R1368     -0.521144449710846
    z[4,1,1]  R1369     8.1455355882644653e-01
    z[4,1,1]  R1370     6.6145467758178711e-01
    z[4,1,1]  R1371     6.5821504592895508e-01
    z[4,1,1]  R1372     7.6134026050567627e-01
    z[4,1,1]  R1373     6.7953163385391235e-01
    z[4,1,1]  R1374     6.7852401733398438e-01
    z[4,1,1]  R1375     -2.8339993953704834e-01
    z[4,1,1]  R1376     -1.2914204597473145e-01
    z[4,1,1]  R1377     -2.7889639139175415e-01
    z[4,1,1]  R1378     0.661384105682373
    z[4,1,1]  R1379     6.8406271934509277e-01
    z[4,1,1]  R1380     0.609142005443573
    z[4,1,1]  R1381     6.1185771226882935e-01
    z[4,1,1]  R1382     5.1991587877273560e-01
    z[4,1,1]  R1383     5.0892251729965210e-01
    z[4,1,1]  R1384     6.2008982896804810e-01
    z[4,1,1]  R1385     5.8739626407623291e-01
    z[4,1,1]  R1386     4.4208192825317383e-01
    z[4,1,1]  R1387     -7.5490063428878784e-01
    z[4,1,1]  R1388     1.1428605020046234e-01
    z[4,1,1]  R1389     -5.4980587959289551e-01
    z[4,1,1]  R1390     6.8772667646408081e-01
    z[4,1,1]  R1391     5.7774698734283447e-01
    z[4,1,1]  R1392     6.1253947019577026e-01
    z[4,1,1]  R1393     6.3415187597274780e-01
    z[4,1,1]  R1394     7.2337609529495239e-01
    z[4,1,1]  R1395     6.5873426198959351e-01
    z[4,1,1]  R1396     -3.1618535518646240e-01
    z[4,1,1]  R1397     -2.2307717800140381e-01
    z[4,1,1]  R1398     0.907846212387085
    z[4,1,1]  R1399     7.8116118907928467e-01
    z[4,1,1]  R1400     6.5968692302703857e-01
    z[4,1,1]  R1401     7.1707624197006226e-01
    z[4,1,1]  R1402     5.8574253320693970e-01
    z[4,1,1]  R1403     6.7232650518417358e-01
    z[4,1,1]  R1404     5.0570577383041382e-01
    z[4,1,1]  R1405     -2.2589710354804993e-01
    z[4,1,1]  R1406     -6.9680139422416687e-02
    z[4,1,1]  R1407     -5.0524167716503143e-02
    z[4,1,1]  R1408     -4.7879534959793091e-01
    z[4,1,1]  R1409     8.4078276157379150e-01
    z[4,1,1]  R1410     8.1807190179824829e-01
    z[4,1,1]  R1411     7.6242613792419434e-01
    z[4,1,1]  R1412     7.4268090724945068e-01
    z[4,1,1]  R1413     7.8609466552734375e-01
    z[4,1,1]  R1414     5.7589423656463623e-01
    z[4,1,1]  R1415     -2.7718749642372131e-01
    z[4,1,1]  R1416     4.0824308991432190e-01
    z[4,1,1]  R1417     1.9695796072483063e-01
    z[4,1,1]  R1418     -3.7442067265510559e-01
    z[4,1,1]  R1419     5.4200363159179688e-01
    z[4,1,1]  R1420     -3.6016467213630676e-01
    z[4,1,1]  R1421     -1.0555035620927811e-01
    z[4,1,1]  R1422     -2.8569099307060242e-01
    z[4,1,1]  R1423     7.3532074689865112e-02
    z[4,1,1]  R1424     5.3862494230270386e-01
    z[4,1,1]  R1425     5.9677477926015854e-02
    z[4,1,1]  R1426     1.7477940022945404e-01
    z[4,1,1]  R1427     2.8231540322303772e-01
    z[4,1,1]  R1428     5.6581604480743408e-01
    z[4,1,1]  R1429     4.6107420325279236e-01
    z[4,1,1]  R1430     5.8846014738082886e-01
    z[4,1,1]  R1431     6.0418677330017090e-01
    z[4,1,1]  R1432     4.1971653699874878e-01
    z[4,1,1]  R1433     4.7782710194587708e-01
    z[4,1,1]  R1434     -0.0804959312081337
    z[4,1,1]  R1435     -1.3034315407276154e-01
    z[4,1,1]  R1436     4.8019781708717346e-01
    z[4,1,1]  R1437     4.2548415064811707e-01
    z[4,1,1]  R1438     1.3635043799877167e-01
    z[4,1,1]  R1439     1.9816307723522186e-01
    z[4,1,1]  R1440     1.8716986477375031e-01
    z[4,1,1]  R1441     3.2812580466270447e-01
    z[4,1,1]  R1442     4.3138720095157623e-02
    z[4,1,1]  R1443     3.2618638873100281e-01
    z[4,1,1]  R1444     3.6346804350614548e-02
    z[4,1,1]  R1445     2.0694455131888390e-02
    z[4,1,1]  R1446     1.6249081492424011e-01
    z[4,1,1]  R1447     3.1555914878845215e-01
    z[4,1,1]  R1448     -5.7555562257766724e-01
    z[4,1,1]  R1449     2.9388232156634331e-02
    z[4,1,1]  R1450     1.3200907409191132e-01
    z[4,1,1]  R1451     7.3984724283218384e-01
    z[4,1,1]  R1452     2.4440020322799683e-02
    z[4,1,1]  R1453     -7.2986435890197754e-01
    z[4,1,1]  R1454     -0.655773401260376
    z[4,1,1]  R1455     1.0935997962951660e-01
    z[4,1,1]  R1456     4.1971331834793091e-01
    z[4,1,1]  R1457     -6.3583093881607056e-01
    z[4,1,1]  R1458     -4.6782466769218445e-01
    z[4,1,1]  R1459     -7.1851402521133423e-01
    z[4,1,1]  R1460     -3.1521740555763245e-01
    z[4,1,1]  R1461     -4.8395147919654846e-01
    z[4,1,1]  R1462     -5.0472050905227661e-01
    z[4,1,1]  R1463     -7.5323802232742310e-01
    z[4,1,1]  R1464     -1.8055382370948792e-01
    z[4,1,1]  R1465     1.0876475274562836e-01
    z[4,1,1]  R1466     2.4585419893264771e-01
    z[4,1,1]  R1467     4.6252235770225525e-01
    z[4,1,1]  R1468     -3.5149574279785156e-01
    z[4,1,1]  R1469     -3.2818189263343811e-01
    z[4,1,1]  R1470     -4.5154190063476562e-01
    z[4,1,1]  R1471     -7.6954740285873413e-01
    z[4,1,1]  R1472     -1.4450900256633759e-01
    z[4,1,1]  R1473     -6.8819504976272583e-01
    z[4,1,1]  R1474     2.1572996675968170e-01
    z[4,1,1]  R1475     3.8106867671012878e-01
    z[4,1,1]  R1476     2.7672821283340454e-01
    z[4,1,1]  R1477     -0.621740996837616
    z[4,1,1]  R1478     -0.0515022911131382
    z[4,1,1]  R1479     -2.8066793084144592e-01
    z[4,1,1]  R1480     -2.8422072529792786e-01
    z[4,1,1]  R1481     -2.2228258848190308e-01
    z[4,1,1]  R1482     -5.4552555084228516e-01
    z[4,1,1]  R1483     -2.5604084134101868e-01
    z[4,1,1]  R1484     -8.0818790197372437e-01
    z[4,1,1]  R1485     -8.4745258092880249e-01
    z[4,1,1]  R1486     -1.9298858940601349e-01
    z[4,1,1]  R1487     -1.9169786944985390e-02
    z[4,1,1]  R1488     -1.4883506298065186e-01
    z[4,1,1]  R1489     -3.3743056654930115e-01
    z[4,1,1]  R1490     -3.2267636060714722e-01
    z[4,1,1]  R1491     -3.5981380939483643e-01
    z[4,1,1]  R1492     -5.5066061019897461e-01
    z[4,1,1]  R1493     -8.3241373300552368e-01
    z[4,1,1]  R1494     -4.0126565098762512e-01
    z[4,1,1]  R1495     -0.325792133808136
    z[4,1,1]  R1496     3.9969906210899353e-01
    z[4,1,1]  R1497     -6.9523072242736816e-01
    z[4,1,1]  R1498     -2.1889136731624603e-01
    z[4,1,1]  R1499     -7.2267115116119385e-01
    z[4,1,1]  R1500     -3.3751270174980164e-01
    z[4,1,1]  R1501     5.9211593866348267e-01
    z[4,1,1]  R1502     2.6231136918067932e-01
    z[4,1,1]  R1503     4.2199438810348511e-01
    z[4,1,1]  R1504     8.6712735891342163e-01
    z[4,1,1]  R1505     9.4980537891387939e-02
    z[4,1,1]  R1506     -6.7621898651123047e-01
    z[4,1,1]  R1507     2.8200818225741386e-02
    z[4,1,2]  R13       1
    z[4,1,2]  R40       -1
    z[4,1,2]  R1328     -1
    z[4,1,2]  R1329     1
    z[4,1,2]  R1338     5.2927613258361816e-02
    z[4,1,2]  R1339     -3.7967246770858765e-01
    z[4,1,2]  R1340     -6.2895250320434570e-01
    z[4,1,2]  R1341     -1.4505137503147125e-01
    z[4,1,2]  R1342     -3.4477221965789795e-01
    z[4,1,2]  R1343     -2.7408489584922791e-01
    z[4,1,2]  R1344     -1.8525023758411407e-01
    z[4,1,2]  R1345     9.5642521977424622e-02
    z[4,1,2]  R1346     7.1118585765361786e-02
    z[4,1,2]  R1347     1.3777109980583191e-01
    z[4,1,2]  R1348     5.7343918085098267e-01
    z[4,1,2]  R1349     3.6670535802841187e-02
    z[4,1,2]  R1350     1.3931621611118317e-01
    z[4,1,2]  R1351     6.4815413951873779e-01
    z[4,1,2]  R1352     -7.3000110685825348e-02
    z[4,1,2]  R1353     4.9809610843658447e-01
    z[4,1,2]  R1354     2.1548955142498016e-01
    z[4,1,2]  R1355     2.7396270632743835e-01
    z[4,1,2]  R1356     -1.0538420639932156e-02
    z[4,1,2]  R1357     1.9095709919929504e-01
    z[4,1,2]  R1358     -1.3599984347820282e-01
    z[4,1,2]  R1359     6.3948506116867065e-01
    z[4,1,2]  R1360     4.0348327159881592e-01
    z[4,1,2]  R1361     -9.1357663273811340e-02
    z[4,1,2]  R1362     2.3269453644752502e-01
    z[4,1,2]  R1363     2.8954052925109863e-01
    z[4,1,2]  R1364     9.3520984053611755e-02
    z[4,1,2]  R1365     3.6777067184448242e-01
    z[4,1,2]  R1366     4.8150235414505005e-01
    z[4,1,2]  R1367     1.8627518415451050e-01
    z[4,1,2]  R1368     7.9654440283775330e-02
    z[4,1,2]  R1369     -6.9881482049822807e-03
    z[4,1,2]  R1370     0.55242520570755
    z[4,1,2]  R1371     0.517589807510376
    z[4,1,2]  R1372     0.382357656955719
    z[4,1,2]  R1373     4.3718099594116211e-01
    z[4,1,2]  R1374     1.4393419027328491e-01
    z[4,1,2]  R1375     7.7611964941024780e-01
    z[4,1,2]  R1376     1.7767506837844849e-01
    z[4,1,2]  R1377     4.2432352900505066e-01
    z[4,1,2]  R1378     4.7660058736801147e-01
    z[4,1,2]  R1379     4.2518422007560730e-01
    z[4,1,2]  R1380     7.4195876717567444e-02
    z[4,1,2]  R1381     1.4133690297603607e-01
    z[4,1,2]  R1382     5.8930929750204086e-02
    z[4,1,2]  R1383     -1.5129742026329041e-01
    z[4,1,2]  R1384     -6.9181986153125763e-02
    z[4,1,2]  R1385     4.6942636370658875e-02
    z[4,1,2]  R1386     1.3853174448013306e-01
    z[4,1,2]  R1387     4.1284161806106567e-01
    z[4,1,2]  R1388     5.5429196357727051e-01
    z[4,1,2]  R1389     3.2978755235671997e-01
    z[4,1,2]  R1390     2.8025823831558228e-01
    z[4,1,2]  R1391     2.6140713691711426e-01
    z[4,1,2]  R1392     1.5084272250533104e-02
    z[4,1,2]  R1393     -1.9392465054988861e-01
    z[4,1,2]  R1394     -9.1017229715362191e-04
    z[4,1,2]  R1395     3.2170155644416809e-01
    z[4,1,2]  R1396     1.8902434408664703e-01
    z[4,1,2]  R1397     7.8653432428836823e-02
    z[4,1,2]  R1398     1.3745307922363281e-01
    z[4,1,2]  R1399     4.8542514443397522e-01
    z[4,1,2]  R1400     2.1271798014640808e-01
    z[4,1,2]  R1401     -1.8609980121254921e-02
    z[4,1,2]  R1402     1.2843313813209534e-01
    z[4,1,2]  R1403     5.8540576696395874e-01
    z[4,1,2]  R1404     1.0369451344013214e-01
    z[4,1,2]  R1405     1.0151851177215576e-01
    z[4,1,2]  R1406     2.9004657268524170e-01
    z[4,1,2]  R1407     4.6488952636718750e-01
    z[4,1,2]  R1408     1.6060872375965118e-01
    z[4,1,2]  R1409     -1.2836912274360657e-01
    z[4,1,2]  R1410     2.7374556660652161e-01
    z[4,1,2]  R1411     1.6982159018516541e-01
    z[4,1,2]  R1412     1.8278861045837402e-01
    z[4,1,2]  R1413     4.2374005913734436e-01
    z[4,1,2]  R1414     5.0773404538631439e-02
    z[4,1,2]  R1415     7.4549637734889984e-02
    z[4,1,2]  R1416     -6.2355047464370728e-01
    z[4,1,2]  R1417     3.8519951701164246e-01
    z[4,1,2]  R1418     4.8653751611709595e-02
    z[4,1,2]  R1419     4.1227829456329346e-01
    z[4,1,2]  R1420     -1.2187819182872772e-01
    z[4,1,2]  R1421     4.1454848647117615e-01
    z[4,1,2]  R1422     3.5861104726791382e-01
    z[4,1,2]  R1423     3.0075496435165405e-01
    z[4,1,2]  R1424     -0.518540620803833
    z[4,1,2]  R1425     2.9725831747055054e-01
    z[4,1,2]  R1426     3.5120970010757446e-01
    z[4,1,2]  R1427     3.8471260666847229e-01
    z[4,1,2]  R1428     -1.8583782017230988e-01
    z[4,1,2]  R1429     4.0435454249382019e-01
    z[4,1,2]  R1430     4.9485184252262115e-02
    z[4,1,2]  R1431     3.0327681452035904e-02
    z[4,1,2]  R1432     1.4825256168842316e-01
    z[4,1,2]  R1433     3.9322644472122192e-01
    z[4,1,2]  R1434     3.4202730655670166e-01
    z[4,1,2]  R1435     3.8173198699951172e-01
    z[4,1,2]  R1436     8.3235532045364380e-02
    z[4,1,2]  R1437     3.8509148359298706e-01
    z[4,1,2]  R1438     3.6533221602439880e-01
    z[4,1,2]  R1439     6.9461631774902344e-01
    z[4,1,2]  R1440     4.7899049520492554e-01
    z[4,1,2]  R1441     2.2634410858154297e-01
    z[4,1,2]  R1442     4.1579627990722656e-01
    z[4,1,2]  R1443     4.0311416983604431e-01
    z[4,1,2]  R1444     2.3965889215469360e-01
    z[4,1,2]  R1445     7.5463271141052246e-01
    z[4,1,2]  R1446     6.9754309952259064e-02
    z[4,1,2]  R1447     4.0157452225685120e-01
    z[4,1,2]  R1448     0.372557133436203
    z[4,1,2]  R1449     -1.4441660046577454e-01
    z[4,1,2]  R1450     -5.6320565938949585e-01
    z[4,1,2]  R1451     -3.5228511691093445e-01
    z[4,1,2]  R1452     -3.0513930320739746e-01
    z[4,1,2]  R1453     4.9704313278198242e-01
    z[4,1,2]  R1454     4.5590788125991821e-01
    z[4,1,2]  R1455     -6.6915452480316162e-01
    z[4,1,2]  R1456     -5.5253100395202637e-01
    z[4,1,2]  R1457     3.0519595742225647e-01
    z[4,1,2]  R1458     6.9835972785949707e-01
    z[4,1,2]  R1459     2.0382064580917358e-01
    z[4,1,2]  R1460     -2.1288146078586578e-01
    z[4,1,2]  R1461     6.2886893749237061e-01
    z[4,1,2]  R1462     1.3575246930122375e-01
    z[4,1,2]  R1463     4.6135470271110535e-01
    z[4,1,2]  R1464     -2.4484296143054962e-01
    z[4,1,2]  R1465     -2.1331357955932617e-01
    z[4,1,2]  R1466     -4.6741876006126404e-01
    z[4,1,2]  R1467     -6.8512326478958130e-01
    z[4,1,2]  R1468     6.0631680488586426e-01
    z[4,1,2]  R1469     8.0816090106964111e-01
    z[4,1,2]  R1470     7.1812593936920166e-01
    z[4,1,2]  R1471     -1.1645172536373138e-01
    z[4,1,2]  R1472     -2.2195224463939667e-01
    z[4,1,2]  R1473     -3.4744247794151306e-01
    z[4,1,2]  R1474     -6.0679125785827637e-01
    z[4,1,2]  R1475     -3.5761341452598572e-01
    z[4,1,2]  R1476     -1.6917374730110168e-01
    z[4,1,2]  R1477     -3.7453171610832214e-01
    z[4,1,2]  R1478     -2.8504827991127968e-02
    z[4,1,2]  R1479     2.3543396592140198e-01
    z[4,1,2]  R1480     5.1484811305999756e-01
    z[4,1,2]  R1481     1.7536431550979614e-01
    z[4,1,2]  R1482     3.4148257970809937e-01
    z[4,1,2]  R1483     5.8263164758682251e-01
    z[4,1,2]  R1484     1.6801603138446808e-01
    z[4,1,2]  R1485     -9.2448271811008453e-02
    z[4,1,2]  R1486     -7.8539937734603882e-02
    z[4,1,2]  R1487     1.2315201759338379e-01
    z[4,1,2]  R1488     6.9656980037689209e-01
    z[4,1,2]  R1489     2.5004261732101440e-01
    z[4,1,2]  R1490     2.6816296577453613e-01
    z[4,1,2]  R1491     3.6138707399368286e-01
    z[4,1,2]  R1492     4.6646651625633240e-01
    z[4,1,2]  R1493     4.0568541735410690e-02
    z[4,1,2]  R1494     7.9084801673889160e-01
    z[4,1,2]  R1495     6.8234455585479736e-01
    z[4,1,2]  R1496     -3.0624341964721680e-01
    z[4,1,2]  R1497     -4.8970249295234680e-01
    z[4,1,2]  R1498     6.5157341957092285e-01
    z[4,1,2]  R1499     1.8652480095624924e-02
    z[4,1,2]  R1500     6.6115683317184448e-01
    z[4,1,2]  R1501     -1.5419077873229980e-01
    z[4,1,2]  R1502     -1.6393500566482544e-01
    z[4,1,2]  R1503     -5.4945224523544312e-01
    z[4,1,2]  R1504     -1.7873485386371613e-01
    z[4,1,2]  R1505     -2.0642848312854767e-01
    z[4,1,2]  R1506     -3.5644856095314026e-01
    z[4,1,2]  R1507     -0.48117595911026
    z[4,1,3]  R14       1
    z[4,1,3]  R41       -1
    z[4,1,3]  R1330     -1
    z[4,1,3]  R1331     1
    z[4,1,3]  R1338     1.6001372039318085e-01
    z[4,1,3]  R1339     2.8818270564079285e-01
    z[4,1,3]  R1340     -1.6304506361484528e-01
    z[4,1,3]  R1341     3.6362621188163757e-01
    z[4,1,3]  R1342     1.2032174319028854e-01
    z[4,1,3]  R1343     1.7823085188865662e-01
    z[4,1,3]  R1344     -3.5893155727535486e-03
    z[4,1,3]  R1345     -3.8156139850616455e-01
    z[4,1,3]  R1346     6.0356277227401733e-01
    z[4,1,3]  R1347     -2.8164786100387573e-01
    z[4,1,3]  R1348     -5.4171049594879150e-01
    z[4,1,3]  R1349     1.0718328505754471e-01
    z[4,1,3]  R1350     -0.0906682088971138
    z[4,1,3]  R1351     -6.5006553195416927e-03
    z[4,1,3]  R1352     8.5837788879871368e-02
    z[4,1,3]  R1353     2.3907181620597839e-01
    z[4,1,3]  R1354     4.7946058213710785e-02
    z[4,1,3]  R1355     -3.1040126085281372e-01
    z[4,1,3]  R1356     -4.5869520306587219e-01
    z[4,1,3]  R1357     -2.3695114254951477e-01
    z[4,1,3]  R1358     -0.384262353181839
    z[4,1,3]  R1359     0.0794503390789032
    z[4,1,3]  R1360     2.3354966938495636e-01
    z[4,1,3]  R1361     -3.7225788831710815e-01
    z[4,1,3]  R1362     -0.152827650308609
    z[4,1,3]  R1363     5.2892103791236877e-02
    z[4,1,3]  R1364     4.5519590377807617e-01
    z[4,1,3]  R1365     -5.3364926576614380e-01
    z[4,1,3]  R1366     -3.1549653410911560e-01
    z[4,1,3]  R1367     -5.7637596130371094e-01
    z[4,1,3]  R1368     -4.6700218319892883e-01
    z[4,1,3]  R1369     1.2275058031082153e-01
    z[4,1,3]  R1370     2.8028586506843567e-01
    z[4,1,3]  R1371     -2.9184681177139282e-01
    z[4,1,3]  R1372     4.9547683447599411e-02
    z[4,1,3]  R1373     1.1898304522037506e-01
    z[4,1,3]  R1374     1.1744812875986099e-01
    z[4,1,3]  R1375     1.3186505995690823e-02
    z[4,1,3]  R1376     2.9272291064262390e-01
    z[4,1,3]  R1377     -3.4841954708099365e-01
    z[4,1,3]  R1378     7.4020475149154663e-02
    z[4,1,3]  R1379     -3.4547463059425354e-01
    z[4,1,3]  R1380     -2.3175922036170959e-01
    z[4,1,3]  R1381     8.8113643229007721e-02
    z[4,1,3]  R1382     1.1977697908878326e-01
    z[4,1,3]  R1383     -3.4683072566986084e-01
    z[4,1,3]  R1384     -6.3989430665969849e-01
    z[4,1,3]  R1385     -4.4078847765922546e-01
    z[4,1,3]  R1386     -3.9069369435310364e-01
    z[4,1,3]  R1387     -1.4880749583244324e-01
    z[4,1,3]  R1388     6.0058438777923584e-01
    z[4,1,3]  R1389     -4.9394312500953674e-01
    z[4,1,3]  R1390     1.3339401781558990e-01
    z[4,1,3]  R1391     -3.6142196506261826e-02
    z[4,1,3]  R1392     -8.2534685730934143e-02
    z[4,1,3]  R1393     -4.1981092095375061e-01
    z[4,1,3]  R1394     -1.6490165144205093e-02
    z[4,1,3]  R1395     -4.8603683710098267e-01
    z[4,1,3]  R1396     -4.1447019577026367e-01
    z[4,1,3]  R1397     -1.4740024507045746e-01
    z[4,1,3]  R1398     -1.9657707214355469e-01
    z[4,1,3]  R1399     1.4049349725246429e-01
    z[4,1,3]  R1400     -5.3508497774600983e-02
    z[4,1,3]  R1401     -3.9368104934692383e-01
    z[4,1,3]  R1402     -4.3956348299980164e-01
    z[4,1,3]  R1403     -7.0799507200717926e-02
    z[4,1,3]  R1404     -3.5371506214141846e-01
    z[4,1,3]  R1405     -8.1046774983406067e-02
    z[4,1,3]  R1406     5.0250524654984474e-03
    z[4,1,3]  R1407     -1.6853669285774231e-01
    z[4,1,3]  R1408     3.2198518514633179e-01
    z[4,1,3]  R1409     -3.1587982177734375e-01
    z[4,1,3]  R1410     1.2399684637784958e-01
    z[4,1,3]  R1411     0.325998991727829
    z[4,1,3]  R1412     1.2346013635396957e-01
    z[4,1,3]  R1413     1.2125533074140549e-01
    z[4,1,3]  R1414     -3.0911889672279358e-01
    z[4,1,3]  R1415     -3.4176650643348694e-01
    z[4,1,3]  R1416     3.5552024841308594e-01
    z[4,1,3]  R1417     4.6924769878387451e-01
    z[4,1,3]  R1418     -2.5024303793907166e-01
    z[4,1,3]  R1419     -3.3788588643074036e-01
    z[4,1,3]  R1420     -3.6288508772850037e-01
    z[4,1,3]  R1421     -1.9072756171226501e-01
    z[4,1,3]  R1422     -4.1188588738441467e-01
    z[4,1,3]  R1423     1.1242207884788513e-01
    z[4,1,3]  R1424     5.2938532829284668e-01
    z[4,1,3]  R1425     3.5849779844284058e-01
    z[4,1,3]  R1426     6.4723688364028931e-01
    z[4,1,3]  R1427     4.5425498485565186e-01
    z[4,1,3]  R1428     8.6268782615661621e-02
    z[4,1,3]  R1429     7.9351119697093964e-02
    z[4,1,3]  R1430     -4.1238284111022949e-01
    z[4,1,3]  R1431     0.27255779504776
    z[4,1,3]  R1432     -1.6743110120296478e-01
    z[4,1,3]  R1433     -7.4745684862136841e-02
    z[4,1,3]  R1434     -0.693411111831665
    z[4,1,3]  R1435     -6.0715156793594360e-01
    z[4,1,3]  R1436     -4.3046516180038452e-01
    z[4,1,3]  R1437     1.0837700963020325e-01
    z[4,1,3]  R1438     3.6152294278144836e-01
    z[4,1,3]  R1439     2.4025149643421173e-01
    z[4,1,3]  R1440     -3.9704661816358566e-02
    z[4,1,3]  R1441     1.3632193207740784e-01
    z[4,1,3]  R1442     9.5584288239479065e-02
    z[4,1,3]  R1443     5.7831990718841553e-01
    z[4,1,3]  R1444     1.0920634120702744e-01
    z[4,1,3]  R1445     1.6979576647281647e-01
    z[4,1,3]  R1446     -8.3034120500087738e-02
    z[4,1,3]  R1447     4.5772495865821838e-01
    z[4,1,3]  R1448     -1.1041700094938278e-01
    z[4,1,3]  R1449     8.7938672304153442e-01
    z[4,1,3]  R1450     7.2547090053558350e-01
    z[4,1,3]  R1451     1.1537463963031769e-01
    z[4,1,3]  R1452     6.1914795637130737e-01
    z[4,1,3]  R1453     0.170075923204422
    z[4,1,3]  R1454     2.6926058530807495e-01
    z[4,1,3]  R1455     5.0105082988739014e-01
    z[4,1,3]  R1456     5.0233274698257446e-01
    z[4,1,3]  R1457     5.8124684728682041e-03
    z[4,1,3]  R1458     1.3400685787200928e-01
    z[4,1,3]  R1459     3.0896854400634766e-01
    z[4,1,3]  R1460     -1.0778423398733139e-01
    z[4,1,3]  R1461     4.3510311841964722e-01
    z[4,1,3]  R1462     -1.0263931006193161e-01
    z[4,1,3]  R1463     -2.2846798598766327e-01
    z[4,1,3]  R1464     1.6738660633563995e-01
    z[4,1,3]  R1465     8.6282485723495483e-01
    z[4,1,3]  R1466     7.1221959590911865e-01
    z[4,1,3]  R1467     4.8533996939659119e-01
    z[4,1,3]  R1468     -4.1398438811302185e-01
    z[4,1,3]  R1469     4.2451298236846924e-01
    z[4,1,3]  R1470     -2.6501944661140442e-01
    z[4,1,3]  R1471     -1.0121706128120422e-01
    z[4,1,3]  R1472     -8.4021300077438354e-02
    z[4,1,3]  R1473     1.9870984554290771e-01
    z[4,1,3]  R1474     6.7457318305969238e-01
    z[4,1,3]  R1475     6.5682178735733032e-01
    z[4,1,3]  R1476     6.9819372892379761e-01
    z[4,1,3]  R1477     0.532219648361206
    z[4,1,3]  R1478     1.5586647391319275e-01
    z[4,1,3]  R1479     4.0449678897857666e-01
    z[4,1,3]  R1480     -8.4880597889423370e-02
    z[4,1,3]  R1481     4.5831638574600220e-01
    z[4,1,3]  R1482     2.3949561640620232e-02
    z[4,1,3]  R1483     4.4943434000015259e-01
    z[4,1,3]  R1484     -0.0392412431538105
    z[4,1,3]  R1485     2.4432432651519775e-01
    z[4,1,3]  R1486     2.8851801156997681e-01
    z[4,1,3]  R1487     5.0724571943283081e-01
    z[4,1,3]  R1488     9.2477187514305115e-02
    z[4,1,3]  R1489     -3.3023558557033539e-02
    z[4,1,3]  R1490     3.7392783164978027e-01
    z[4,1,3]  R1491     -8.7873362004756927e-02
    z[4,1,3]  R1492     -6.6005373001098633e-01
    z[4,1,3]  R1493     -1.6353135928511620e-02
    z[4,1,3]  R1494     -2.2524943947792053e-01
    z[4,1,3]  R1495     1.6651917248964310e-02
    z[4,1,3]  R1496     7.5210946798324585e-01
    z[4,1,3]  R1497     -2.6873955503106117e-02
    z[4,1,3]  R1498     -2.3450862616300583e-02
    z[4,1,3]  R1499     2.2883121669292450e-01
    z[4,1,3]  R1500     2.7994289994239807e-01
    z[4,1,3]  R1501     -1.3547608256340027e-01
    z[4,1,3]  R1502     7.6073713600635529e-02
    z[4,1,3]  R1503     5.8836966753005981e-01
    z[4,1,3]  R1504     1.2514644861221313e-01
    z[4,1,3]  R1505     7.5729668140411377e-01
    z[4,1,3]  R1506     8.8596068322658539e-02
    z[4,1,3]  R1507     4.1238108277320862e-01
    z[4,1,4]  R15       1
    z[4,1,4]  R42       -1
    z[4,1,4]  R1332     -1
    z[4,1,4]  R1333     1
    z[4,1,4]  R1338     -1.1472114175558090e-01
    z[4,1,4]  R1339     -1.1252373456954956e-01
    z[4,1,4]  R1340     -2.7165785431861877e-02
    z[4,1,4]  R1341     -4.0477615594863892e-01
    z[4,1,4]  R1342     7.2668421268463135e-01
    z[4,1,4]  R1343     6.1354964971542358e-01
    z[4,1,4]  R1344     -9.9070511758327484e-02
    z[4,1,4]  R1345     0.409146249294281
    z[4,1,4]  R1346     -6.6583938896656036e-02
    z[4,1,4]  R1347     2.5064873695373535e-01
    z[4,1,4]  R1348     1.3133677840232849e-01
    z[4,1,4]  R1349     -3.3229254186153412e-02
    z[4,1,4]  R1350     -3.2199618220329285e-01
    z[4,1,4]  R1351     1.4842495322227478e-01
    z[4,1,4]  R1352     -3.7058830261230469e-01
    z[4,1,4]  R1353     6.1142629384994507e-01
    z[4,1,4]  R1354     -2.3097884654998779e-01
    z[4,1,4]  R1355     3.4388538450002670e-02
    z[4,1,4]  R1356     -3.0489778518676758e-01
    z[4,1,4]  R1357     -0.0886390283703804
    z[4,1,4]  R1358     3.1590268015861511e-01
    z[4,1,4]  R1359     2.3376764729619026e-03
    z[4,1,4]  R1360     3.7073215842247009e-01
    z[4,1,4]  R1361     4.4369032979011536e-01
    z[4,1,4]  R1362     4.6025916934013367e-01
    z[4,1,4]  R1363     3.5726550966501236e-02
    z[4,1,4]  R1364     3.6453232169151306e-01
    z[4,1,4]  R1365     -3.4587019681930542e-01
    z[4,1,4]  R1366     -2.4863809812813997e-03
    z[4,1,4]  R1367     -5.2206773310899734e-02
    z[4,1,4]  R1368     2.4215477705001831e-01
    z[4,1,4]  R1369     1.8904080986976624e-01
    z[4,1,4]  R1370     1.5691670775413513e-01
    z[4,1,4]  R1371     5.7197425514459610e-02
    z[4,1,4]  R1372     -1.7119950056076050e-01
    z[4,1,4]  R1373     3.0332329869270325e-01
    z[4,1,4]  R1374     -1.3827908039093018e-01
    z[4,1,4]  R1375     3.6695733666419983e-01
    z[4,1,4]  R1376     -1.0033635795116425e-01
    z[4,1,4]  R1377     -3.8435709476470947e-01
    z[4,1,4]  R1378     4.3267095088958740e-01
    z[4,1,4]  R1379     -2.3215970396995544e-01
    z[4,1,4]  R1380     -3.3439084887504578e-01
    z[4,1,4]  R1381     -1.2737533450126648e-01
    z[4,1,4]  R1382     2.2421942651271820e-01
    z[4,1,4]  R1383     -3.1862971186637878e-01
    z[4,1,4]  R1384     -1.4161466062068939e-01
    z[4,1,4]  R1385     -2.0014038681983948e-01
    z[4,1,4]  R1386     -1.7013674974441528e-01
    z[4,1,4]  R1387     -2.2357928752899170e-01
    z[4,1,4]  R1388     4.8134982585906982e-01
    z[4,1,4]  R1389     3.0386200547218323e-01
    z[4,1,4]  R1390     5.6228119134902954e-01
    z[4,1,4]  R1391     2.6087793707847595e-01
    z[4,1,4]  R1392     -1.7765650525689125e-02
    z[4,1,4]  R1393     5.7998904958367348e-03
    z[4,1,4]  R1394     -1.9561885297298431e-01
    z[4,1,4]  R1395     -1.5254600346088409e-01
    z[4,1,4]  R1396     -2.3245088756084442e-01
    z[4,1,4]  R1397     -2.4510839581489563e-01
    z[4,1,4]  R1398     3.4389652311801910e-02
    z[4,1,4]  R1399     1.6696244478225708e-01
    z[4,1,4]  R1400     3.9626786112785339e-01
    z[4,1,4]  R1401     -4.9778923392295837e-02
    z[4,1,4]  R1402     1.0410825908184052e-01
    z[4,1,4]  R1403     -3.0679020285606384e-01
    z[4,1,4]  R1404     2.2262823581695557e-01
    z[4,1,4]  R1405     -0.0813310518860817
    z[4,1,4]  R1406     9.8297655582427979e-02
    z[4,1,4]  R1407     9.0512603521347046e-02
    z[4,1,4]  R1408     4.6489360928535461e-01
    z[4,1,4]  R1409     -9.3833103775978088e-02
    z[4,1,4]  R1410     4.2973878979682922e-01
    z[4,1,4]  R1411     3.6662909388542175e-01
    z[4,1,4]  R1412     5.0199198722839355e-01
    z[4,1,4]  R1413     -4.3391962535679340e-03
    z[4,1,4]  R1414     1.9471764564514160e-01
    z[4,1,4]  R1415     -2.9023903608322144e-01
    z[4,1,4]  R1416     -2.7248394489288330e-01
    z[4,1,4]  R1417     -2.4616238474845886e-01
    z[4,1,4]  R1418     2.4163340032100677e-01
    z[4,1,4]  R1419     -2.2500516474246979e-01
    z[4,1,4]  R1420     -1.0002250224351883e-01
    z[4,1,4]  R1421     -7.6770171523094177e-02
    z[4,1,4]  R1422     -2.0987370610237122e-01
    z[4,1,4]  R1423     -1.0867885500192642e-01
    z[4,1,4]  R1424     -6.6451430320739746e-02
    z[4,1,4]  R1425     -5.7496535778045654e-01
    z[4,1,4]  R1426     -4.4193667173385620e-01
    z[4,1,4]  R1427     -4.9371123313903809e-01
    z[4,1,4]  R1428     -1.2811103463172913e-01
    z[4,1,4]  R1429     9.8769381642341614e-02
    z[4,1,4]  R1430     3.9514090865850449e-02
    z[4,1,4]  R1431     1.7906357347965240e-01
    z[4,1,4]  R1432     5.0745550543069839e-02
    z[4,1,4]  R1433     -3.1483915448188782e-01
    z[4,1,4]  R1434     1.2532761693000793e-01
    z[4,1,4]  R1435     2.5661385059356689e-01
    z[4,1,4]  R1436     -1.0935959964990616e-01
    z[4,1,4]  R1437     -0.383960098028183
    z[4,1,4]  R1438     -1.0561495274305344e-01
    z[4,1,4]  R1439     -6.1047445982694626e-02
    z[4,1,4]  R1440     -2.4713041260838509e-02
    z[4,1,4]  R1441     2.0410059392452240e-01
    z[4,1,4]  R1442     -2.5440940260887146e-01
    z[4,1,4]  R1443     -1.5176208317279816e-01
    z[4,1,4]  R1444     -1.5687119215726852e-02
    z[4,1,4]  R1445     3.0090346932411194e-02
    z[4,1,4]  R1446     2.2111959755420685e-01
    z[4,1,4]  R1447     -1.6021193563938141e-01
    z[4,1,4]  R1448     -6.7464607954025269e-01
    z[4,1,4]  R1449     -7.1750218048691750e-03
    z[4,1,4]  R1450     -1.0470546036958694e-01
    z[4,1,4]  R1451     3.6146417260169983e-02
    z[4,1,4]  R1452     4.6560221910476685e-01
    z[4,1,4]  R1453     -2.4388229846954346e-01
    z[4,1,4]  R1454     -0.421680748462677
    z[4,1,4]  R1455     1.0703993588685989e-01
    z[4,1,4]  R1456     4.0497452020645142e-01
    z[4,1,4]  R1457     5.0599622726440430e-01
    z[4,1,4]  R1458     -1.1077462881803513e-01
    z[4,1,4]  R1459     4.4569492340087891e-01
    z[4,1,4]  R1460     5.8734100311994553e-02
    z[4,1,4]  R1461     2.5616383552551270e-01
    z[4,1,4]  R1462     1.9701224565505981e-01
    z[4,1,4]  R1463     -8.4607586264610291e-02
    z[4,1,4]  R1464     -2.1708090603351593e-01
    z[4,1,4]  R1465     3.2076227664947510e-01
    z[4,1,4]  R1466     3.6794742941856384e-01
    z[4,1,4]  R1467     7.5871430337429047e-02
    z[4,1,4]  R1468     -4.4188475608825684e-01
    z[4,1,4]  R1469     3.7901178002357483e-02
    z[4,1,4]  R1470     -3.8594129681587219e-01
    z[4,1,4]  R1471     -0.196554496884346
    z[4,1,4]  R1472     -6.4528220891952515e-01
    z[4,1,4]  R1473     3.7812665104866028e-01
    z[4,1,4]  R1474     -2.7227890491485596e-01
    z[4,1,4]  R1475     -4.9730318784713745e-01
    z[4,1,4]  R1476     -4.7969445586204529e-01
    z[4,1,4]  R1477     -3.1444844603538513e-01
    z[4,1,4]  R1478     -2.6763904094696045e-01
    z[4,1,4]  R1479     -3.6290460824966431e-01
    z[4,1,4]  R1480     1.3922120630741119e-01
    z[4,1,4]  R1481     2.2006702423095703e-01
    z[4,1,4]  R1482     -1.4936453104019165e-01
    z[4,1,4]  R1483     3.6574614048004150e-01
    z[4,1,4]  R1484     -2.0260740816593170e-01
    z[4,1,4]  R1485     -4.5631805062294006e-01
    z[4,1,4]  R1486     -7.9937577247619629e-03
    z[4,1,4]  R1487     -1.2307025492191315e-01
    z[4,1,4]  R1488     -2.0108424127101898e-01
    z[4,1,4]  R1489     7.9773432016372681e-01
    z[4,1,4]  R1490     2.9656341299414635e-02
    z[4,1,4]  R1491     -4.3531331419944763e-01
    z[4,1,4]  R1492     -1.5251480042934418e-02
    z[4,1,4]  R1493     1.6486409306526184e-01
    z[4,1,4]  R1494     3.1822186708450317e-01
    z[4,1,4]  R1495     3.8033452630043030e-01
    z[4,1,4]  R1496     -2.7622884511947632e-01
    z[4,1,4]  R1497     6.9422118365764618e-02
    z[4,1,4]  R1498     -2.4084742367267609e-01
    z[4,1,4]  R1499     2.7856758236885071e-01
    z[4,1,4]  R1500     3.8693848252296448e-01
    z[4,1,4]  R1501     4.1001993417739868e-01
    z[4,1,4]  R1502     7.1121048927307129e-01
    z[4,1,4]  R1503     3.3168014883995056e-01
    z[4,1,4]  R1504     0.187080979347229
    z[4,1,4]  R1505     1.0877946764230728e-01
    z[4,1,4]  R1506     -2.9853085055947304e-02
    z[4,1,4]  R1507     3.7477380037307739e-01
    z[4,1,5]  R16       1
    z[4,1,5]  R43       -1
    z[4,1,5]  R1334     -1
    z[4,1,5]  R1335     1
    z[4,1,5]  R1338     3.8111633062362671e-01
    z[4,1,5]  R1339     5.5571067333221436e-01
    z[4,1,5]  R1340     1.8060798943042755e-01
    z[4,1,5]  R1341     -1.1214573681354523e-01
    z[4,1,5]  R1342     1.6730263829231262e-01
    z[4,1,5]  R1343     5.3711807727813721e-01
    z[4,1,5]  R1344     7.2642147541046143e-02
    z[4,1,5]  R1345     1.1676761507987976e-01
    z[4,1,5]  R1346     -7.5571663677692413e-02
    z[4,1,5]  R1347     1.6545480489730835e-01
    z[4,1,5]  R1348     -4.1990029811859131e-01
    z[4,1,5]  R1349     -6.0991442203521729e-01
    z[4,1,5]  R1350     -4.6201825141906738e-01
    z[4,1,5]  R1351     0.0101442476734519
    z[4,1,5]  R1352     -6.8104475736618042e-02
    z[4,1,5]  R1353     -2.8355339169502258e-01
    z[4,1,5]  R1354     -7.7083487994968891e-03
    z[4,1,5]  R1355     -1.7236265540122986e-01
    z[4,1,5]  R1356     -2.4853106588125229e-02
    z[4,1,5]  R1357     -8.7030403316020966e-02
    z[4,1,5]  R1358     -1.6514272987842560e-01
    z[4,1,5]  R1359     -2.5870227813720703e-01
    z[4,1,5]  R1360     -4.4403988122940063e-01
    z[4,1,5]  R1361     -3.7668019533157349e-01
    z[4,1,5]  R1362     -2.0139142870903015e-01
    z[4,1,5]  R1363     -7.1815311908721924e-01
    z[4,1,5]  R1364     1.2453091889619827e-01
    z[4,1,5]  R1365     -2.5025227665901184e-01
    z[4,1,5]  R1366     -3.5274305939674377e-01
    z[4,1,5]  R1367     -6.1772572994232178e-01
    z[4,1,5]  R1368     -6.2005412578582764e-01
    z[4,1,5]  R1369     -4.0256899595260620e-01
    z[4,1,5]  R1370     3.3030384778976440e-01
    z[4,1,5]  R1371     4.0965270996093750e-01
    z[4,1,5]  R1372     -4.8622965812683105e-01
    z[4,1,5]  R1373     1.9258794188499451e-01
    z[4,1,5]  R1374     1.0406956821680069e-01
    z[4,1,5]  R1375     8.2377210259437561e-02
    z[4,1,5]  R1376     -8.4257304668426514e-02
    z[4,1,5]  R1377     3.9063131809234619e-01
    z[4,1,5]  R1378     1.0816441476345062e-01
    z[4,1,5]  R1379     0.349244624376297
    z[4,1,5]  R1380     -3.9362901449203491e-01
    z[4,1,5]  R1381     -5.9012597799301147e-01
    z[4,1,5]  R1382     -7.8150975704193115e-01
    z[4,1,5]  R1383     -6.7393243312835693e-01
    z[4,1,5]  R1384     -2.3224505782127380e-01
    z[4,1,5]  R1385     -6.3647961616516113e-01
    z[4,1,5]  R1386     -6.0548824071884155e-01
    z[4,1,5]  R1387     -1.4366070926189423e-01
    z[4,1,5]  R1388     4.4098678976297379e-02
    z[4,1,5]  R1389     -4.5739594101905823e-01
    z[4,1,5]  R1390     1.4385650865733624e-02
    z[4,1,5]  R1391     -5.9956979751586914e-01
    z[4,1,5]  R1392     -6.7116081714630127e-01
    z[4,1,5]  R1393     -5.8865559101104736e-01
    z[4,1,5]  R1394     -1.8110229074954987e-01
    z[4,1,5]  R1395     -1.0773810744285583e-01
    z[4,1,5]  R1396     2.6756206154823303e-01
    z[4,1,5]  R1397     1.8646885454654694e-01
    z[4,1,5]  R1398     -5.6428488343954086e-02
    z[4,1,5]  R1399     2.0217919349670410e-01
    z[4,1,5]  R1400     -3.9791306853294373e-01
    z[4,1,5]  R1401     -5.7171505689620972e-01
    z[4,1,5]  R1402     -3.4493902325630188e-01
    z[4,1,5]  R1403     7.1420714259147644e-02
    z[4,1,5]  R1404     3.5805463790893555e-01
    z[4,1,5]  R1405     -1.9722411036491394e-01
    z[4,1,5]  R1406     -1.6521330177783966e-01
    z[4,1,5]  R1407     -5.1570698618888855e-02
    z[4,1,5]  R1408     2.0275006070733070e-02
    z[4,1,5]  R1409     -3.8745424151420593e-01
    z[4,1,5]  R1410     -1.4860782027244568e-01
    z[4,1,5]  R1411     -2.1801829338073730e-01
    z[4,1,5]  R1412     2.8767675161361694e-01
    z[4,1,5]  R1413     -4.2009210586547852e-01
    z[4,1,5]  R1414     3.5468569397926331e-01
    z[4,1,5]  R1415     2.0468638837337494e-01
    z[4,1,5]  R1416     1.5067258477210999e-01
    z[4,1,5]  R1417     -2.4595342576503754e-02
    z[4,1,5]  R1418     -8.1414008140563965e-01
    z[4,1,5]  R1419     0.0750207006931305
    z[4,1,5]  R1420     -0.131648451089859
    z[4,1,5]  R1421     1.3997261226177216e-01
    z[4,1,5]  R1422     2.8227525949478149e-01
    z[4,1,5]  R1423     1.3914388418197632e-01
    z[4,1,5]  R1424     1.4618138968944550e-01
    z[4,1,5]  R1425     -1.0838557034730911e-01
    z[4,1,5]  R1426     -1.1386824399232864e-01
    z[4,1,5]  R1427     1.1800454556941986e-01
    z[4,1,5]  R1428     -1.4402790367603302e-01
    z[4,1,5]  R1429     4.5146383345127106e-02
    z[4,1,5]  R1430     1.1751770973205566e-01
    z[4,1,5]  R1431     4.2257276177406311e-01
    z[4,1,5]  R1432     1.0330075025558472e-01
    z[4,1,5]  R1433     3.4574690461158752e-01
    z[4,1,5]  R1434     1.7807528376579285e-01
    z[4,1,5]  R1435     -1.4250756241381168e-02
    z[4,1,5]  R1436     5.1383594982326031e-03
    z[4,1,5]  R1437     -1.3030184805393219e-01
    z[4,1,5]  R1438     4.7639212012290955e-01
    z[4,1,5]  R1439     3.3835160732269287e-01
    z[4,1,5]  R1440     1.3196520507335663e-01
    z[4,1,5]  R1441     5.4228603839874268e-01
    z[4,1,5]  R1442     0.332433819770813
    z[4,1,5]  R1443     1.7465837299823761e-01
    z[4,1,5]  R1444     5.2098482847213745e-01
    z[4,1,5]  R1445     5.0092417001724243e-01
    z[4,1,5]  R1446     3.1437876820564270e-01
    z[4,1,5]  R1447     -0.0597243569791317
    z[4,1,5]  R1448     -1.8792058527469635e-01
    z[4,1,5]  R1449     -1.9813102483749390e-01
    z[4,1,5]  R1450     -3.5396766662597656e-01
    z[4,1,5]  R1451     -1.2771297991275787e-01
    z[4,1,5]  R1452     -4.5337450504302979e-01
    z[4,1,5]  R1453     -2.8609189391136169e-01
    z[4,1,5]  R1454     -1.7389757931232452e-01
    z[4,1,5]  R1455     -4.0819168090820312e-01
    z[4,1,5]  R1456     -2.2313356399536133e-01
    z[4,1,5]  R1457     -2.3613187670707703e-01
    z[4,1,5]  R1458     1.8409633636474609e-01
    z[4,1,5]  R1459     8.4336094558238983e-02
    z[4,1,5]  R1460     7.1165359020233154e-01
    z[4,1,5]  R1461     -1.4875005185604095e-01
    z[4,1,5]  R1462     -2.2034212946891785e-01
    z[4,1,5]  R1463     -2.9223549365997314e-01
    z[4,1,5]  R1464     -1.1317928880453110e-01
    z[4,1,5]  R1465     -2.9599642753601074e-01
    z[4,1,5]  R1466     -2.4392421543598175e-01
    z[4,1,5]  R1467     -1.7684239149093628e-01
    z[4,1,5]  R1468     3.1072497367858887e-01
    z[4,1,5]  R1469     8.6572587490081787e-02
    z[4,1,5]  R1470     9.3467950820922852e-02
    z[4,1,5]  R1471     2.9265916347503662e-01
    z[4,1,5]  R1472     9.4040319323539734e-02
    z[4,1,5]  R1473     -0.300374835729599
    z[4,1,5]  R1474     -1.2064851820468903e-01
    z[4,1,5]  R1475     2.1226347982883453e-01
    z[4,1,5]  R1476     2.9925328493118286e-01
    z[4,1,5]  R1477     -2.4028530716896057e-01
    z[4,1,5]  R1478     8.8568501174449921e-02
    z[4,1,5]  R1479     -1.9132284214720130e-03
    z[4,1,5]  R1480     2.4026885628700256e-01
    z[4,1,5]  R1481     -6.7815303802490234e-02
    z[4,1,5]  R1482     1.4808064699172974e-01
    z[4,1,5]  R1483     -9.7954049706459045e-02
    z[4,1,5]  R1484     -4.0656840801239014e-01
    z[4,1,5]  R1485     5.9593491256237030e-02
    z[4,1,5]  R1486     1.0588598251342773e-01
    z[4,1,5]  R1487     -6.8894013762474060e-02
    z[4,1,5]  R1488     4.7643181681632996e-01
    z[4,1,5]  R1489     6.1530273407697678e-02
    z[4,1,5]  R1490     -0.0348796509206295
    z[4,1,5]  R1491     5.9020388126373291e-01
    z[4,1,5]  R1492     -1.7851024866104126e-01
    z[4,1,5]  R1493     -2.3533992469310760e-01
    z[4,1,5]  R1494     1.3561421632766724e-01
    z[4,1,5]  R1495     -2.1379022300243378e-01
    z[4,1,5]  R1496     2.2489269077777863e-01
    z[4,1,5]  R1497     -2.5495597720146179e-01
    z[4,1,5]  R1498     4.8909124732017517e-01
    z[4,1,5]  R1499     3.2360464334487915e-01
    z[4,1,5]  R1500     1.2746696174144745e-01
    z[4,1,5]  R1501     -6.3453322649002075e-01
    z[4,1,5]  R1502     -3.8612812757492065e-01
    z[4,1,5]  R1503     -1.6239969432353973e-01
    z[4,1,5]  R1504     -2.5596126914024353e-01
    z[4,1,5]  R1505     -4.0585622191429138e-01
    z[4,1,5]  R1506     -4.1404470801353455e-01
    z[4,1,5]  R1507     -4.8035117983818054e-01
    z[4,1,6]  R17       1
    z[4,1,6]  R44       -1
    z[4,1,6]  R1336     -1
    z[4,1,6]  R1337     1
    z[4,1,6]  R1338     2.7287659049034119e-01
    z[4,1,6]  R1339     -8.6940238252282143e-03
    z[4,1,6]  R1340     3.3845886588096619e-01
    z[4,1,6]  R1341     -5.6192469596862793e-01
    z[4,1,6]  R1342     3.7011390924453735e-01
    z[4,1,6]  R1343     9.6734218299388885e-02
    z[4,1,6]  R1344     2.8947748243808746e-02
    z[4,1,6]  R1345     8.4491841495037079e-02
    z[4,1,6]  R1346     -2.7116268873214722e-01
    z[4,1,6]  R1347     5.5536723136901855e-01
    z[4,1,6]  R1348     -1.0864780098199844e-01
    z[4,1,6]  R1349     -3.1635737419128418e-01
    z[4,1,6]  R1350     2.7368339896202087e-01
    z[4,1,6]  R1351     -6.4924255013465881e-02
    z[4,1,6]  R1352     1.6080971807241440e-02
    z[4,1,6]  R1353     1.1388626694679260e-01
    z[4,1,6]  R1354     -1.1335127800703049e-01
    z[4,1,6]  R1355     6.2742494046688080e-02
    z[4,1,6]  R1356     8.7315574288368225e-02
    z[4,1,6]  R1357     -4.3224021792411804e-01
    z[4,1,6]  R1358     4.6385556459426880e-01
    z[4,1,6]  R1359     1.3388817012310028e-01
    z[4,1,6]  R1360     -1.0406203567981720e-01
    z[4,1,6]  R1361     -3.2532370090484619e-01
    z[4,1,6]  R1362     -5.8396351337432861e-01
    z[4,1,6]  R1363     -6.0750752687454224e-02
    z[4,1,6]  R1364     3.7941977381706238e-01
    z[4,1,6]  R1365     -8.0928064882755280e-02
    z[4,1,6]  R1366     -3.2811298966407776e-01
    z[4,1,6]  R1367     5.3886175155639648e-03
    z[4,1,6]  R1368     -2.4670192599296570e-01
    z[4,1,6]  R1369     1.5145288407802582e-01
    z[4,1,6]  R1370     -1.2451510876417160e-01
    z[4,1,6]  R1371     1.9450066983699799e-01
    z[4,1,6]  R1372     5.6221973150968552e-02
    z[4,1,6]  R1373     4.0203872323036194e-01
    z[4,1,6]  R1374     -6.0775661468505859e-01
    z[4,1,6]  R1375     -4.1605624556541443e-01
    z[4,1,6]  R1376     -2.0083867013454437e-02
    z[4,1,6]  R1377     -4.1355829685926437e-02
    z[4,1,6]  R1378     0.169141948223114
    z[4,1,6]  R1379     -2.3644529283046722e-01
    z[4,1,6]  R1380     -5.4670977592468262e-01
    z[4,1,6]  R1381     -4.8036286234855652e-01
    z[4,1,6]  R1382     -1.3549636304378510e-01
    z[4,1,6]  R1383     1.3533039391040802e-01
    z[4,1,6]  R1384     -3.3536779880523682e-01
    z[4,1,6]  R1385     -7.4160680174827576e-02
    z[4,1,6]  R1386     3.9604222774505615e-01
    z[4,1,6]  R1387     8.2372479140758514e-02
    z[4,1,6]  R1388     -2.0938409864902496e-01
    z[4,1,6]  R1389     -9.9131613969802856e-02
    z[4,1,6]  R1390     -1.5620626509189606e-01
    z[4,1,6]  R1391     -3.5751909017562866e-02
    z[4,1,6]  R1392     3.4721937775611877e-01
    z[4,1,6]  R1393     -1.6696329414844513e-01
    z[4,1,6]  R1394     -5.4487246274948120e-01
    z[4,1,6]  R1395     2.4621315300464630e-01
    z[4,1,6]  R1396     -2.9758375883102417e-01
    z[4,1,6]  R1397     -3.2744112610816956e-01
    z[4,1,6]  R1398     -1.3781943917274475e-01
    z[4,1,6]  R1399     1.9308337569236755e-01
    z[4,1,6]  R1400     -4.1964939236640930e-01
    z[4,1,6]  R1401     -3.2751351594924927e-02
    z[4,1,6]  R1402     4.0953123569488525e-01
    z[4,1,6]  R1403     -2.7584463357925415e-01
    z[4,1,6]  R1404     -6.4742863178253174e-01
    z[4,1,6]  R1405     -1.5823251008987427e-01
    z[4,1,6]  R1406     1.8326042592525482e-01
    z[4,1,6]  R1407     8.2990802824497223e-02
    z[4,1,6]  R1408     -6.4104783535003662e-01
    z[4,1,6]  R1409     -7.6623722910881042e-02
    z[4,1,6]  R1410     -1.5886804461479187e-01
    z[4,1,6]  R1411     2.6446020603179932e-01
    z[4,1,6]  R1412     -4.7957371920347214e-02
    z[4,1,6]  R1413     1.0231915861368179e-01
    z[4,1,6]  R1414     -6.3529020547866821e-01
    z[4,1,6]  R1415     -2.9536217451095581e-01
    z[4,1,6]  R1416     -1.2536510825157166e-01
    z[4,1,6]  R1417     -2.9091672971844673e-02
    z[4,1,6]  R1418     -2.2160361707210541e-01
    z[4,1,6]  R1419     -4.0055537223815918e-01
    z[4,1,6]  R1420     -0.0674145370721817
    z[4,1,6]  R1421     7.8882798552513123e-02
    z[4,1,6]  R1422     3.0971509218215942e-01
    z[4,1,6]  R1423     2.9696798324584961e-01
    z[4,1,6]  R1424     1.4758327975869179e-02
    z[4,1,6]  R1425     2.4358795583248138e-01
    z[4,1,6]  R1426     1.0696541517972946e-01
    z[4,1,6]  R1427     3.1952759623527527e-01
    z[4,1,6]  R1428     3.8310918211936951e-01
    z[4,1,6]  R1429     3.4259554743766785e-01
    z[4,1,6]  R1430     3.3546081185340881e-01
    z[4,1,6]  R1431     -0.141708105802536
    z[4,1,6]  R1432     2.9049226641654968e-01
    z[4,1,6]  R1433     -6.6882841289043427e-02
    z[4,1,6]  R1434     -1.5954727306962013e-02
    z[4,1,6]  R1435     2.4336050450801849e-01
    z[4,1,6]  R1436     -4.4455981254577637e-01
    z[4,1,6]  R1437     -3.1602874398231506e-01
    z[4,1,6]  R1438     2.6858173310756683e-02
    z[4,1,6]  R1439     1.3759815692901611e-01
    z[4,1,6]  R1440     -1.9455698132514954e-01
    z[4,1,6]  R1441     -2.7928901836276054e-02
    z[4,1,6]  R1442     3.9691379666328430e-01
    z[4,1,6]  R1443     -9.4235010445117950e-02
    z[4,1,6]  R1444     -4.6372160315513611e-01
    z[4,1,6]  R1445     1.3849860429763794e-01
    z[4,1,6]  R1446     6.0068508610129356e-03
    z[4,1,6]  R1447     1.4758543670177460e-01
    z[4,1,6]  R1448     8.9115403592586517e-02
    z[4,1,6]  R1449     -1.7295074462890625e-01
    z[4,1,6]  R1450     4.5295480638742447e-02
    z[4,1,6]  R1451     -0.429155170917511
    z[4,1,6]  R1452     -9.0533353388309479e-02
    z[4,1,6]  R1453     -1.8242296576499939e-01
    z[4,1,6]  R1454     -1.9455881416797638e-01
    z[4,1,6]  R1455     -2.1512724459171295e-01
    z[4,1,6]  R1456     1.9915764033794403e-01
    z[4,1,6]  R1457     1.0617773979902267e-02
    z[4,1,6]  R1458     -2.6905581355094910e-01
    z[4,1,6]  R1459     -1.7250110208988190e-01
    z[4,1,6]  R1460     1.7161907255649567e-01
    z[4,1,6]  R1461     1.5332300961017609e-01
    z[4,1,6]  R1462     -7.1559733152389526e-01
    z[4,1,6]  R1463     -2.6875638961791992e-01
    z[4,1,6]  R1464     -3.4160980582237244e-01
    z[4,1,6]  R1465     -6.4790071919560432e-03
    z[4,1,6]  R1466     -8.3678871393203735e-02
    z[4,1,6]  R1467     1.4622308313846588e-01
    z[4,1,6]  R1468     -4.0118601173162460e-02
    z[4,1,6]  R1469     -0.0113369794562459
    z[4,1,6]  R1470     1.1757802218198776e-01
    z[4,1,6]  R1471     -2.9616445302963257e-01
    z[4,1,6]  R1472     -1.2719714641571045e-01
    z[4,1,6]  R1473     3.1891950964927673e-01
    z[4,1,6]  R1474     -1.4607398211956024e-01
    z[4,1,6]  R1475     2.3893110454082489e-02
    z[4,1,6]  R1476     -2.3453857004642487e-01
    z[4,1,6]  R1477     -2.7294633910059929e-02
    z[4,1,6]  R1478     1.1803147196769714e-01
    z[4,1,6]  R1479     8.1077076494693756e-02
    z[4,1,6]  R1480     -2.1415489912033081e-01
    z[4,1,6]  R1481     -1.4506998658180237e-01
    z[4,1,6]  R1482     -7.1462929248809814e-01
    z[4,1,6]  R1483     -1.9606147706508636e-01
    z[4,1,6]  R1484     7.2265923023223877e-02
    z[4,1,6]  R1485     -4.1635073721408844e-02
    z[4,1,6]  R1486     6.7983572371304035e-03
    z[4,1,6]  R1487     -1.1469484865665436e-01
    z[4,1,6]  R1488     -3.3874136209487915e-01
    z[4,1,6]  R1489     -1.5532813034951687e-02
    z[4,1,6]  R1490     -1.3888043165206909e-01
    z[4,1,6]  R1491     2.2395296394824982e-01
    z[4,1,6]  R1492     7.9197414219379425e-02
    z[4,1,6]  R1493     1.1739090085029602e-01
    z[4,1,6]  R1494     -2.0323191583156586e-01
    z[4,1,6]  R1495     4.7606897354125977e-01
    z[4,1,6]  R1496     -1.5488071739673615e-01
    z[4,1,6]  R1497     -1.8255972862243652e-01
    z[4,1,6]  R1498     -2.6468801498413086e-01
    z[4,1,6]  R1499     2.0553344488143921e-01
    z[4,1,6]  R1500     0.451729416847229
    z[4,1,6]  R1501     -1.1594294756650925e-01
    z[4,1,6]  R1502     -3.4763699769973755e-01
    z[4,1,6]  R1503     -1.0595864616334438e-02
    z[4,1,6]  R1504     -3.2378476113080978e-02
    z[4,1,6]  R1505     3.1050181388854980e-01
    z[4,1,6]  R1506     -4.1898640990257263e-01
    z[4,1,6]  R1507     -1.9147852063179016e-01
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R1508     -1
    z[2,3,0]  R1509     1
    z[2,3,0]  R1522     1.1964980512857437e-01
    z[2,3,0]  R1523     4.5635089278221130e-01
    z[2,3,0]  R1524     -0.125092551112175
    z[2,3,0]  R1525     4.7106048464775085e-01
    z[2,3,0]  R1526     -3.9310479164123535e-01
    z[2,3,0]  R1527     -3.6264759302139282e-01
    z[2,3,0]  R1528     -4.9746543169021606e-01
    z[2,3,0]  R1529     -3.1940698623657227e-01
    z[2,3,0]  R1530     -5.8063352108001709e-01
    z[2,3,0]  R1531     -2.9870501160621643e-01
    z[2,3,0]  R1532     7.2426810860633850e-02
    z[2,3,0]  R1533     -9.6556141972541809e-02
    z[2,3,0]  R1534     -3.3674961328506470e-01
    z[2,3,0]  R1535     -2.1139541268348694e-01
    z[2,3,0]  R1536     -6.4578318595886230e-01
    z[2,3,0]  R1537     -3.0570608377456665e-01
    z[2,3,0]  R1538     1.4016310870647430e-01
    z[2,3,0]  R1539     -3.0304387211799622e-01
    z[2,3,0]  R1540     -8.4870404005050659e-01
    z[2,3,0]  R1541     1.3653036952018738e-01
    z[2,3,0]  R1542     1.0207693278789520e-01
    z[2,3,0]  R1543     -4.5072686672210693e-01
    z[2,3,0]  R1544     -0.650905191898346
    z[2,3,0]  R1545     -4.1497984528541565e-01
    z[2,3,0]  R1546     2.6181656122207642e-01
    z[2,3,0]  R1547     -6.5905636548995972e-01
    z[2,3,0]  R1548     -3.6861473321914673e-01
    z[2,3,0]  R1549     -0.530968427658081
    z[2,3,0]  R1550     -5.7315403223037720e-01
    z[2,3,0]  R1551     -4.6986043453216553e-01
    z[2,3,0]  R1552     3.0096715688705444e-01
    z[2,3,0]  R1553     0.266201913356781
    z[2,3,0]  R1554     3.9871039986610413e-01
    z[2,3,0]  R1555     2.9021590948104858e-01
    z[2,3,0]  R1556     -6.1205196380615234e-01
    z[2,3,0]  R1557     0.790971040725708
    z[2,3,0]  R1558     6.4641773700714111e-02
    z[2,3,0]  R1559     -4.0440770983695984e-01
    z[2,3,0]  R1560     -0.0990544930100441
    z[2,3,0]  R1561     -1.8146137893199921e-01
    z[2,3,0]  R1562     -0.0699734315276146
    z[2,3,0]  R1563     0.806816041469574
    z[2,3,0]  R1564     -1.2725955247879028e-01
    z[2,3,0]  R1565     -2.3796859383583069e-01
    z[2,3,0]  R1566     7.5944811105728149e-02
    z[2,3,0]  R1567     -1.1690370738506317e-01
    z[2,3,0]  R1568     2.7889090776443481e-01
    z[2,3,0]  R1569     -1.2801650166511536e-01
    z[2,3,0]  R1570     -2.1942233666777611e-02
    z[2,3,0]  R1571     -3.4418243169784546e-01
    z[2,3,0]  R1572     3.4553754329681396e-01
    z[2,3,0]  R1573     -3.0406650900840759e-01
    z[2,3,0]  R1574     -3.5892143845558167e-01
    z[2,3,0]  R1575     -4.7762086987495422e-01
    z[2,3,0]  R1576     -3.4556332975625992e-02
    z[2,3,0]  R1577     -1.5605589747428894e-01
    z[2,3,0]  R1578     -3.9361652731895447e-01
    z[2,3,0]  R1579     -1.3211588561534882e-01
    z[2,3,0]  R1580     -6.5518431365489960e-02
    z[2,3,0]  R1581     -2.9194861650466919e-01
    z[2,3,0]  R1582     -5.6193226575851440e-01
    z[2,3,0]  R1583     -2.1877616643905640e-01
    z[2,3,0]  R1584     8.1439119577407837e-01
    z[2,3,0]  R1585     -4.3648043274879456e-01
    z[2,3,0]  R1586     8.5842144489288330e-01
    z[2,3,0]  R1587     6.6212922334671021e-01
    z[2,3,0]  R1588     7.5678145885467529e-01
    z[2,3,0]  R1589     -4.6959450840950012e-01
    z[2,3,0]  R1590     -1.8554012477397919e-01
    z[2,3,0]  R1591     8.1496782600879669e-02
    z[2,3,0]  R1592     4.0846642851829529e-01
    z[2,3,0]  R1593     5.4487776756286621e-01
    z[2,3,0]  R1594     2.1994680166244507e-01
    z[2,3,0]  R1595     2.4828505516052246e-01
    z[2,3,0]  R1596     3.4240600466728210e-01
    z[2,3,0]  R1597     -2.9961192607879639e-01
    z[2,3,0]  R1598     6.1994470655918121e-02
    z[2,3,0]  R1599     -4.5045062899589539e-01
    z[2,3,0]  R1600     1.7669546604156494e-01
    z[2,3,0]  R1601     -1.9386282563209534e-01
    z[2,3,0]  R1602     -3.6804085969924927e-01
    z[2,3,0]  R1603     -6.8062943220138550e-01
    z[2,3,0]  R1604     -7.5242631137371063e-02
    z[2,3,0]  R1605     5.4270535707473755e-01
    z[2,3,0]  R1606     -0.60260409116745
    z[2,3,0]  R1607     -0.841519296169281
    z[2,3,0]  R1608     -3.3021429181098938e-01
    z[2,3,0]  R1609     -1.4445284008979797e-01
    z[2,3,0]  R1610     -5.0922536849975586e-01
    z[2,3,0]  R1611     1.6006837785243988e-01
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R1510     -1
    z[2,3,1]  R1511     1
    z[2,3,1]  R1522     5.9983724355697632e-01
    z[2,3,1]  R1523     7.2173017263412476e-01
    z[2,3,1]  R1524     4.3486005067825317e-01
    z[2,3,1]  R1525     2.1249566972255707e-01
    z[2,3,1]  R1526     -2.1284019947052002e-01
    z[2,3,1]  R1527     -0.332770437002182
    z[2,3,1]  R1528     -3.5462863743305206e-02
    z[2,3,1]  R1529     -8.2390010356903076e-02
    z[2,3,1]  R1530     -0.181112602353096
    z[2,3,1]  R1531     -6.3754066824913025e-02
    z[2,3,1]  R1532     3.5394972562789917e-01
    z[2,3,1]  R1533     8.4005340933799744e-02
    z[2,3,1]  R1534     -4.2696595191955566e-02
    z[2,3,1]  R1535     0.0811346247792244
    z[2,3,1]  R1536     4.2347289621829987e-02
    z[2,3,1]  R1537     -9.2981308698654175e-02
    z[2,3,1]  R1538     -2.3038220405578613e-01
    z[2,3,1]  R1539     -2.3555132746696472e-01
    z[2,3,1]  R1540     -9.0188965201377869e-02
    z[2,3,1]  R1541     -2.9894340783357620e-02
    z[2,3,1]  R1542     -9.5013357698917389e-02
    z[2,3,1]  R1543     -8.7583720684051514e-01
    z[2,3,1]  R1544     -7.2417879104614258e-01
    z[2,3,1]  R1545     4.2553361505270004e-02
    z[2,3,1]  R1546     -2.7154216170310974e-01
    z[2,3,1]  R1547     -5.9841054677963257e-01
    z[2,3,1]  R1548     -7.6666903495788574e-01
    z[2,3,1]  R1549     -6.2934494018554688e-01
    z[2,3,1]  R1550     -5.9415531158447266e-01
    z[2,3,1]  R1551     -3.0684208869934082e-01
    z[2,3,1]  R1552     -4.1537608951330185e-02
    z[2,3,1]  R1553     -1.8900800496339798e-02
    z[2,3,1]  R1554     -3.6691910028457642e-01
    z[2,3,1]  R1555     -4.4243744015693665e-01
    z[2,3,1]  R1556     -3.1237161159515381e-01
    z[2,3,1]  R1557     0.0637897253036499
    z[2,3,1]  R1558     -0.583785355091095
    z[2,3,1]  R1559     -6.6741967201232910e-01
    z[2,3,1]  R1560     -4.8305392265319824e-01
    z[2,3,1]  R1561     -6.9934207201004028e-01
    z[2,3,1]  R1562     4.1462263464927673e-01
    z[2,3,1]  R1563     2.4976047873497009e-01
    z[2,3,1]  R1564     4.0262803435325623e-01
    z[2,3,1]  R1565     -3.2162415981292725e-01
    z[2,3,1]  R1566     -3.1465274095535278e-01
    z[2,3,1]  R1567     -8.8595676422119141e-01
    z[2,3,1]  R1568     4.3278205394744873e-01
    z[2,3,1]  R1569     3.2780739665031433e-01
    z[2,3,1]  R1570     -0.562740683555603
    z[2,3,1]  R1571     -4.7032970190048218e-01
    z[2,3,1]  R1572     4.2216780781745911e-01
    z[2,3,1]  R1573     -6.2297242879867554e-01
    z[2,3,1]  R1574     -3.4845784306526184e-01
    z[2,3,1]  R1575     -6.8859666585922241e-01
    z[2,3,1]  R1576     -4.9920460581779480e-01
    z[2,3,1]  R1577     -4.4212073087692261e-01
    z[2,3,1]  R1578     -2.2997401654720306e-01
    z[2,3,1]  R1579     -7.0381003618240356e-01
    z[2,3,1]  R1580     -6.4303326606750488e-01
    z[2,3,1]  R1581     -5.4580366611480713e-01
    z[2,3,1]  R1582     1.2658137083053589e-01
    z[2,3,1]  R1583     -4.0987440943717957e-01
    z[2,3,1]  R1584     -1.7743816599249840e-02
    z[2,3,1]  R1585     1.5095029026269913e-02
    z[2,3,1]  R1586     1.3860325515270233e-01
    z[2,3,1]  R1587     0.219833105802536
    z[2,3,1]  R1588     0.278201162815094
    z[2,3,1]  R1589     3.0335025861859322e-02
    z[2,3,1]  R1590     -6.4056468009948730e-01
    z[2,3,1]  R1591     -5.5411326885223389e-01
    z[2,3,1]  R1592     5.4294317960739136e-01
    z[2,3,1]  R1593     2.1319216489791870e-01
    z[2,3,1]  R1594     7.0009982585906982e-01
    z[2,3,1]  R1595     -1.4219549298286438e-01
    z[2,3,1]  R1596     4.1987210512161255e-01
    z[2,3,1]  R1597     -4.9000686407089233e-01
    z[2,3,1]  R1598     -2.4379158020019531e-01
    z[2,3,1]  R1599     -1.9936127960681915e-01
    z[2,3,1]  R1600     1.3906867243349552e-02
    z[2,3,1]  R1601     1.0930828005075455e-01
    z[2,3,1]  R1602     -3.1919276714324951e-01
    z[2,3,1]  R1603     -6.4516997337341309e-01
    z[2,3,1]  R1604     -4.2915329337120056e-01
    z[2,3,1]  R1605     2.8473719954490662e-01
    z[2,3,1]  R1606     -3.1105524301528931e-01
    z[2,3,1]  R1607     -2.6590937376022339e-01
    z[2,3,1]  R1608     -5.6255763769149780e-01
    z[2,3,1]  R1609     -3.5914209485054016e-01
    z[2,3,1]  R1610     1.9825773313641548e-02
    z[2,3,1]  R1611     -7.7108982950448990e-03
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R1512     -1
    z[2,3,2]  R1513     1
    z[2,3,2]  R1522     3.0667799711227417e-01
    z[2,3,2]  R1523     8.7701253592967987e-02
    z[2,3,2]  R1524     5.4213011264801025e-01
    z[2,3,2]  R1525     -1.9859565794467926e-01
    z[2,3,2]  R1526     6.8247979879379272e-01
    z[2,3,2]  R1527     5.1311510801315308e-01
    z[2,3,2]  R1528     5.7735347747802734e-01
    z[2,3,2]  R1529     5.7280987501144409e-01
    z[2,3,2]  R1530     3.1305974721908569e-01
    z[2,3,2]  R1531     9.0186780691146851e-01
    z[2,3,2]  R1532     4.5689836144447327e-01
    z[2,3,2]  R1533     -3.0133244395256042e-01
    z[2,3,2]  R1534     -1.7264898121356964e-01
    z[2,3,2]  R1535     -3.2008981704711914e-01
    z[2,3,2]  R1536     -3.3835846930742264e-02
    z[2,3,2]  R1537     -8.4999807178974152e-02
    z[2,3,2]  R1538     -5.3778284788131714e-01
    z[2,3,2]  R1539     -1.6220824420452118e-01
    z[2,3,2]  R1540     4.5658446848392487e-02
    z[2,3,2]  R1541     -0.291608065366745
    z[2,3,2]  R1542     -0.0314226932823658
    z[2,3,2]  R1543     -1.0495898127555847e-01
    z[2,3,2]  R1544     9.9670603871345520e-02
    z[2,3,2]  R1545     -7.1303009986877441e-01
    z[2,3,2]  R1546     -9.3205086886882782e-02
    z[2,3,2]  R1547     1.2623761594295502e-01
    z[2,3,2]  R1548     -7.5511775910854340e-02
    z[2,3,2]  R1549     1.6558539867401123e-01
    z[2,3,2]  R1550     1.6087324917316437e-01
    z[2,3,2]  R1551     -5.3906667232513428e-01
    z[2,3,2]  R1552     1.5534909069538116e-01
    z[2,3,2]  R1553     1.7812253534793854e-01
    z[2,3,2]  R1554     -7.1083754301071167e-02
    z[2,3,2]  R1555     -3.1101605296134949e-01
    z[2,3,2]  R1556     5.8487743139266968e-01
    z[2,3,2]  R1557     -2.8012701869010925e-01
    z[2,3,2]  R1558     0.524462878704071
    z[2,3,2]  R1559     1.7696005105972290e-01
    z[2,3,2]  R1560     3.4141331911087036e-01
    z[2,3,2]  R1561     5.0322753190994263e-01
    z[2,3,2]  R1562     4.8755025863647461e-01
    z[2,3,2]  R1563     -2.0616883039474487e-01
    z[2,3,2]  R1564     3.0896782875061035e-01
    z[2,3,2]  R1565     4.5889967679977417e-01
    z[2,3,2]  R1566     8.2162946462631226e-01
    z[2,3,2]  R1567     3.1508103013038635e-01
    z[2,3,2]  R1568     -2.0668437704443932e-02
    z[2,3,2]  R1569     -4.0846887230873108e-01
    z[2,3,2]  R1570     -4.7836822271347046e-01
    z[2,3,2]  R1571     -6.8681873381137848e-04
    z[2,3,2]  R1572     -3.6278583109378815e-02
    z[2,3,2]  R1573     7.0591771602630615e-01
    z[2,3,2]  R1574     1.5450893342494965e-01
    z[2,3,2]  R1575     -3.6272511351853609e-04
    z[2,3,2]  R1576     6.5159320831298828e-01
    z[2,3,2]  R1577     5.0417190790176392e-01
    z[2,3,2]  R1578     3.4218469262123108e-01
    z[2,3,2]  R1579     2.3716755211353302e-01
    z[2,3,2]  R1580     6.0096681118011475e-01
    z[2,3,2]  R1581     -4.2711740732192993e-01
    z[2,3,2]  R1582     6.9000810384750366e-01
    z[2,3,2]  R1583     0.210184246301651
    z[2,3,2]  R1584     1.1719269305467606e-01
    z[2,3,2]  R1585     6.9620794057846069e-01
    z[2,3,2]  R1586     3.2710447907447815e-01
    z[2,3,2]  R1587     5.0952249765396118e-01
    z[2,3,2]  R1588     7.6343074440956116e-02
    z[2,3,2]  R1589     6.8611919879913330e-01
    z[2,3,2]  R1590     1.4378747344017029e-01
    z[2,3,2]  R1591     -0.062874436378479
    z[2,3,2]  R1592     -2.8643596172332764e-01
    z[2,3,2]  R1593     -6.5241509675979614e-01
    z[2,3,2]  R1594     -1.8200229108333588e-01
    z[2,3,2]  R1595     -2.4465499818325043e-01
    z[2,3,2]  R1596     -2.4278061091899872e-01
    z[2,3,2]  R1597     -5.4686951637268066e-01
    z[2,3,2]  R1598     1.7173700034618378e-02
    z[2,3,2]  R1599     -7.0712512731552124e-01
    z[2,3,2]  R1600     -6.5931832790374756e-01
    z[2,3,2]  R1601     -4.0237104892730713e-01
    z[2,3,2]  R1602     -3.7199565768241882e-01
    z[2,3,2]  R1603     -1.3697220385074615e-01
    z[2,3,2]  R1604     -7.1549135446548462e-01
    z[2,3,2]  R1605     -1.8416188657283783e-01
    z[2,3,2]  R1606     -4.1858857870101929e-01
    z[2,3,2]  R1607     1.5182051062583923e-01
    z[2,3,2]  R1608     -3.4829905629158020e-01
    z[2,3,2]  R1609     -5.8139652013778687e-01
    z[2,3,2]  R1610     1.2566743791103363e-01
    z[2,3,2]  R1611     -0.649156391620636
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R1514     -1
    z[2,3,3]  R1515     1
    z[2,3,3]  R1522     9.3609832227230072e-02
    z[2,3,3]  R1523     -2.1035907790064812e-02
    z[2,3,3]  R1524     1.3036954402923584e-01
    z[2,3,3]  R1525     2.0052876323461533e-02
    z[2,3,3]  R1526     -0.495135635137558
    z[2,3,3]  R1527     -3.0368411540985107e-01
    z[2,3,3]  R1528     -0.511141300201416
    z[2,3,3]  R1529     -7.0996415615081787e-01
    z[2,3,3]  R1530     -6.7732381820678711e-01
    z[2,3,3]  R1531     -2.2971355915069580e-01
    z[2,3,3]  R1532     7.1147501468658447e-01
    z[2,3,3]  R1533     -7.3761200904846191e-01
    z[2,3,3]  R1534     -0.451924204826355
    z[2,3,3]  R1535     -2.0343993604183197e-01
    z[2,3,3]  R1536     -2.2310629487037659e-01
    z[2,3,3]  R1537     -2.8772500157356262e-01
    z[2,3,3]  R1538     -6.3988798856735229e-01
    z[2,3,3]  R1539     -2.6446914672851562e-01
    z[2,3,3]  R1540     -2.9471242427825928e-01
    z[2,3,3]  R1541     -3.5488110780715942e-01
    z[2,3,3]  R1542     7.0867466926574707e-01
    z[2,3,3]  R1543     1.1995280534029007e-01
    z[2,3,3]  R1544     9.1283574700355530e-02
    z[2,3,3]  R1545     -4.3391120433807373e-01
    z[2,3,3]  R1546     3.7661322951316833e-01
    z[2,3,3]  R1547     2.5445926189422607e-01
    z[2,3,3]  R1548     0.0413551852107048
    z[2,3,3]  R1549     6.5296448767185211e-02
    z[2,3,3]  R1550     1.6322822868824005e-01
    z[2,3,3]  R1551     -4.7423759102821350e-01
    z[2,3,3]  R1552     6.3237917423248291e-01
    z[2,3,3]  R1553     3.9997085928916931e-01
    z[2,3,3]  R1554     6.8104404211044312e-01
    z[2,3,3]  R1555     4.9130213260650635e-01
    z[2,3,3]  R1556     -3.3424523472785950e-01
    z[2,3,3]  R1557     2.3141415417194366e-01
    z[2,3,3]  R1558     -3.3661547303199768e-01
    z[2,3,3]  R1559     5.9688467532396317e-02
    z[2,3,3]  R1560     -8.9241966605186462e-02
    z[2,3,3]  R1561     2.6097431778907776e-01
    z[2,3,3]  R1562     5.2706265449523926e-01
    z[2,3,3]  R1563     3.2264092564582825e-01
    z[2,3,3]  R1564     1.1933559924364090e-01
    z[2,3,3]  R1565     5.2976008504629135e-02
    z[2,3,3]  R1566     -0.276328444480896
    z[2,3,3]  R1567     -5.9998266398906708e-02
    z[2,3,3]  R1568     1.9840340316295624e-01
    z[2,3,3]  R1569     -6.9231164455413818e-01
    z[2,3,3]  R1570     -3.6303135752677917e-01
    z[2,3,3]  R1571     -2.5195494294166565e-01
    z[2,3,3]  R1572     3.2401415705680847e-01
    z[2,3,3]  R1573     1.2854067981243134e-01
    z[2,3,3]  R1574     -3.8726359605789185e-01
    z[2,3,3]  R1575     -4.6152842044830322e-01
    z[2,3,3]  R1576     -6.3248798251152039e-02
    z[2,3,3]  R1577     4.4629681855440140e-02
    z[2,3,3]  R1578     -2.6927703619003296e-01
    z[2,3,3]  R1579     -6.9246530532836914e-02
    z[2,3,3]  R1580     -2.1628679335117340e-01
    z[2,3,3]  R1581     -5.7753199338912964e-01
    z[2,3,3]  R1582     1.3518603146076202e-01
    z[2,3,3]  R1583     -6.0827100276947021e-01
    z[2,3,3]  R1584     -4.3505945801734924e-01
    z[2,3,3]  R1585     -1.0539470240473747e-02
    z[2,3,3]  R1586     -6.3690222799777985e-02
    z[2,3,3]  R1587     -4.0693020820617676e-01
    z[2,3,3]  R1588     -2.1456105634570122e-02
    z[2,3,3]  R1589     -4.7923552989959717e-01
    z[2,3,3]  R1590     -3.9578646421432495e-02
    z[2,3,3]  R1591     -3.6662086844444275e-01
    z[2,3,3]  R1592     3.9195086807012558e-02
    z[2,3,3]  R1593     4.0870717167854309e-01
    z[2,3,3]  R1594     1.4911645650863647e-01
    z[2,3,3]  R1595     -0.0082710487768054
    z[2,3,3]  R1596     1.2566968798637390e-01
    z[2,3,3]  R1597     -7.5368061661720276e-03
    z[2,3,3]  R1598     2.3450877051800489e-03
    z[2,3,3]  R1599     -1.7732071876525879e-01
    z[2,3,3]  R1600     -5.8723551034927368e-01
    z[2,3,3]  R1601     -6.1758917570114136e-01
    z[2,3,3]  R1602     -1.6537846624851227e-01
    z[2,3,3]  R1603     -1.5702915191650391e-01
    z[2,3,3]  R1604     -1.2456391006708145e-01
    z[2,3,3]  R1605     2.1796748042106628e-01
    z[2,3,3]  R1606     -3.2868149876594543e-01
    z[2,3,3]  R1607     -2.8656652569770813e-01
    z[2,3,3]  R1608     -3.3567818999290466e-01
    z[2,3,3]  R1609     -6.9308197498321533e-01
    z[2,3,3]  R1610     1.7923320829868317e-01
    z[2,3,3]  R1611     -4.1287642717361450e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R1516     -1
    z[2,3,4]  R1517     1
    z[2,3,4]  R1522     -7.1888190507888794e-01
    z[2,3,4]  R1523     -5.0630760192871094e-01
    z[2,3,4]  R1524     -4.9986669421195984e-01
    z[2,3,4]  R1525     -8.1424170732498169e-01
    z[2,3,4]  R1526     1.8985408544540405e-01
    z[2,3,4]  R1527     -4.0892388671636581e-02
    z[2,3,4]  R1528     6.8054132163524628e-02
    z[2,3,4]  R1529     8.9658878277987242e-04
    z[2,3,4]  R1530     1.2329649180173874e-02
    z[2,3,4]  R1531     -3.6802776157855988e-02
    z[2,3,4]  R1532     3.6640360951423645e-01
    z[2,3,4]  R1533     3.6034294962882996e-01
    z[2,3,4]  R1534     5.6489914655685425e-01
    z[2,3,4]  R1535     0.739863395690918
    z[2,3,4]  R1536     5.7485264539718628e-01
    z[2,3,4]  R1537     0.858572244644165
    z[2,3,4]  R1538     4.0431788563728333e-01
    z[2,3,4]  R1539     5.5548012256622314e-01
    z[2,3,4]  R1540     3.0688369274139404e-01
    z[2,3,4]  R1541     8.6194217205047607e-01
    z[2,3,4]  R1542     -2.4086178839206696e-01
    z[2,3,4]  R1543     -0.0619514137506485
    z[2,3,4]  R1544     -1.5650069713592529e-01
    z[2,3,4]  R1545     2.8335490822792053e-01
    z[2,3,4]  R1546     -1.8668599426746368e-01
    z[2,3,4]  R1547     1.1433929204940796e-01
    z[2,3,4]  R1548     3.0734360218048096e-01
    z[2,3,4]  R1549     3.4631672501564026e-01
    z[2,3,4]  R1550     4.6331921219825745e-01
    z[2,3,4]  R1551     2.0889858901500702e-01
    z[2,3,4]  R1552     -5.2693516016006470e-01
    z[2,3,4]  R1553     -3.3935031294822693e-01
    z[2,3,4]  R1554     5.5278204381465912e-02
    z[2,3,4]  R1555     -5.0832325220108032e-01
    z[2,3,4]  R1556     9.5697872340679169e-02
    z[2,3,4]  R1557     2.0208714902400970e-01
    z[2,3,4]  R1558     3.4052771329879761e-01
    z[2,3,4]  R1559     9.6334271132946014e-02
    z[2,3,4]  R1560     7.3046833276748657e-01
    z[2,3,4]  R1561     3.8761347532272339e-01
    z[2,3,4]  R1562     -5.5150383710861206e-01
    z[2,3,4]  R1563     1.8650289857760072e-03
    z[2,3,4]  R1564     -1.4399588108062744e-01
    z[2,3,4]  R1565     3.1894093751907349e-01
    z[2,3,4]  R1566     6.0998909175395966e-02
    z[2,3,4]  R1567     2.7304571866989136e-01
    z[2,3,4]  R1568     2.5782135128974915e-01
    z[2,3,4]  R1569     2.4912282824516296e-01
    z[2,3,4]  R1570     4.3123376369476318e-01
    z[2,3,4]  R1571     2.5804471969604492e-01
    z[2,3,4]  R1572     3.0102011561393738e-01
    z[2,3,4]  R1573     4.5850764960050583e-02
    z[2,3,4]  R1574     6.2477457523345947e-01
    z[2,3,4]  R1575     -6.8612575531005859e-02
    z[2,3,4]  R1576     3.1580066680908203e-01
    z[2,3,4]  R1577     4.3939542770385742e-01
    z[2,3,4]  R1578     7.5136470794677734e-01
    z[2,3,4]  R1579     5.2736049890518188e-01
    z[2,3,4]  R1580     -2.9020509123802185e-01
    z[2,3,4]  R1581     2.6936045289039612e-01
    z[2,3,4]  R1582     -4.0334054827690125e-01
    z[2,3,4]  R1583     3.4928798675537109e-01
    z[2,3,4]  R1584     3.3656361699104309e-01
    z[2,3,4]  R1585     1.7802956700325012e-01
    z[2,3,4]  R1586     2.6296606659889221e-01
    z[2,3,4]  R1587     -3.5195663571357727e-02
    z[2,3,4]  R1588     2.0981298387050629e-01
    z[2,3,4]  R1589     -2.1187800168991089e-01
    z[2,3,4]  R1590     1.7886583507061005e-01
    z[2,3,4]  R1591     -1.1789031559601426e-03
    z[2,3,4]  R1592     -0.558672308921814
    z[2,3,4]  R1593     -1.1019662767648697e-01
    z[2,3,4]  R1594     -5.5909123271703720e-02
    z[2,3,4]  R1595     -9.2242914438247681e-01
    z[2,3,4]  R1596     5.5569779872894287e-01
    z[2,3,4]  R1597     4.8192042112350464e-01
    z[2,3,4]  R1598     -5.4806423187255859e-01
    z[2,3,4]  R1599     3.2528510689735413e-01
    z[2,3,4]  R1600     1.6369768977165222e-01
    z[2,3,4]  R1601     -3.7840676307678223e-01
    z[2,3,4]  R1602     1.8910128623247147e-02
    z[2,3,4]  R1603     -2.6657721027731895e-02
    z[2,3,4]  R1604     4.0477478504180908e-01
    z[2,3,4]  R1605     5.5097335577011108e-01
    z[2,3,4]  R1606     0.349839985370636
    z[2,3,4]  R1607     -2.0136989653110504e-01
    z[2,3,4]  R1608     4.9555456638336182e-01
    z[2,3,4]  R1609     -1.2139406055212021e-01
    z[2,3,4]  R1610     4.4311735033988953e-01
    z[2,3,4]  R1611     1.1949014663696289e-01
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R1518     -1
    z[2,3,5]  R1519     1
    z[2,3,5]  R1522     -2.1863847970962524e-02
    z[2,3,5]  R1523     -0.0313928946852684
    z[2,3,5]  R1524     3.3899274468421936e-01
    z[2,3,5]  R1525     7.5918912887573242e-02
    z[2,3,5]  R1526     -1.5463545918464661e-02
    z[2,3,5]  R1527     6.1474508047103882e-01
    z[2,3,5]  R1528     3.8006502389907837e-01
    z[2,3,5]  R1529     2.2136305272579193e-01
    z[2,3,5]  R1530     2.3091264069080353e-01
    z[2,3,5]  R1531     1.9786050915718079e-01
    z[2,3,5]  R1532     1.0970976948738098e-01
    z[2,3,5]  R1533     -3.9908087253570557e-01
    z[2,3,5]  R1534     -4.2348787188529968e-01
    z[2,3,5]  R1535     -4.9752873182296753e-01
    z[2,3,5]  R1536     -1.4555752277374268e-01
    z[2,3,5]  R1537     4.7893855720758438e-02
    z[2,3,5]  R1538     -2.5469270348548889e-01
    z[2,3,5]  R1539     -6.5651547908782959e-01
    z[2,3,5]  R1540     -2.5598949193954468e-01
    z[2,3,5]  R1541     -1.4976185560226440e-01
    z[2,3,5]  R1542     -6.0912001132965088e-01
    z[2,3,5]  R1543     9.3447407707571983e-03
    z[2,3,5]  R1544     -6.2571600079536438e-02
    z[2,3,5]  R1545     -4.6416290104389191e-02
    z[2,3,5]  R1546     -3.6793848872184753e-01
    z[2,3,5]  R1547     -1.3254623115062714e-01
    z[2,3,5]  R1548     4.0630754828453064e-01
    z[2,3,5]  R1549     3.9330080151557922e-01
    z[2,3,5]  R1550     2.1390035748481750e-01
    z[2,3,5]  R1551     3.5462772846221924e-01
    z[2,3,5]  R1552     4.4799691438674927e-01
    z[2,3,5]  R1553     1.1716803908348083e-01
    z[2,3,5]  R1554     1.1035675555467606e-01
    z[2,3,5]  R1555     4.8289110418409109e-04
    z[2,3,5]  R1556     -0.0670744925737381
    z[2,3,5]  R1557     3.7761366367340088e-01
    z[2,3,5]  R1558     6.7873440682888031e-02
    z[2,3,5]  R1559     4.2142614722251892e-01
    z[2,3,5]  R1560     3.0900228023529053e-01
    z[2,3,5]  R1561     3.9559951983392239e-03
    z[2,3,5]  R1562     3.2422382384538651e-02
    z[2,3,5]  R1563     7.8848125413060188e-03
    z[2,3,5]  R1564     4.6986883878707886e-01
    z[2,3,5]  R1565     6.4230072498321533e-01
    z[2,3,5]  R1566     -1.2610211968421936e-01
    z[2,3,5]  R1567     1.4766190946102142e-01
    z[2,3,5]  R1568     1.8167679011821747e-01
    z[2,3,5]  R1569     -2.7452623844146729e-01
    z[2,3,5]  R1570     -8.5259661078453064e-02
    z[2,3,5]  R1571     2.1010087430477142e-01
    z[2,3,5]  R1572     6.7935936152935028e-02
    z[2,3,5]  R1573     4.6180140227079391e-02
    z[2,3,5]  R1574     4.3076780438423157e-01
    z[2,3,5]  R1575     2.6315766572952271e-01
    z[2,3,5]  R1576     2.5518137216567993e-01
    z[2,3,5]  R1577     4.8160418868064880e-01
    z[2,3,5]  R1578     6.2356390058994293e-02
    z[2,3,5]  R1579     0.367984801530838
    z[2,3,5]  R1580     -1.4788319170475006e-01
    z[2,3,5]  R1581     1.0287480056285858e-01
    z[2,3,5]  R1582     -3.3380375243723392e-03
    z[2,3,5]  R1583     -4.9794283509254456e-01
    z[2,3,5]  R1584     2.7872281149029732e-02
    z[2,3,5]  R1585     -5.2084422111511230e-01
    z[2,3,5]  R1586     5.1263108849525452e-02
    z[2,3,5]  R1587     -2.9249009490013123e-01
    z[2,3,5]  R1588     -5.3765302896499634e-01
    z[2,3,5]  R1589     -3.2040674239397049e-02
    z[2,3,5]  R1590     -3.8281852006912231e-01
    z[2,3,5]  R1591     -0.539277970790863
    z[2,3,5]  R1592     2.6998212933540344e-01
    z[2,3,5]  R1593     1.4770534634590149e-01
    z[2,3,5]  R1594     1.8912889063358307e-01
    z[2,3,5]  R1595     0.0660073533654213
    z[2,3,5]  R1596     3.3002045750617981e-01
    z[2,3,5]  R1597     3.6354464292526245e-01
    z[2,3,5]  R1598     5.6534707546234131e-01
    z[2,3,5]  R1599     4.8115104436874390e-03
    z[2,3,5]  R1600     7.7572362497448921e-03
    z[2,3,5]  R1601     -1.5721473097801208e-01
    z[2,3,5]  R1602     -7.6816070079803467e-01
    z[2,3,5]  R1603     -1.1064589023590088e-01
    z[2,3,5]  R1604     -3.1259015202522278e-01
    z[2,3,5]  R1605     4.6183642745018005e-01
    z[2,3,5]  R1606     9.8798334598541260e-02
    z[2,3,5]  R1607     -0.185917928814888
    z[2,3,5]  R1608     0.307997465133667
    z[2,3,5]  R1609     3.8070093840360641e-02
    z[2,3,5]  R1610     -6.6336655616760254e-01
    z[2,3,5]  R1611     -5.6838154792785645e-01
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R1520     -1
    z[2,3,6]  R1521     1
    z[2,3,6]  R1522     -7.6129332184791565e-02
    z[2,3,6]  R1523     -7.3365390300750732e-02
    z[2,3,6]  R1524     -3.4578087925910950e-01
    z[2,3,6]  R1525     1.5605156123638153e-01
    z[2,3,6]  R1526     2.3009985685348511e-01
    z[2,3,6]  R1527     1.5051838755607605e-01
    z[2,3,6]  R1528     8.7104015052318573e-02
    z[2,3,6]  R1529     -1.0014154762029648e-01
    z[2,3,6]  R1530     -1.4077019691467285e-01
    z[2,3,6]  R1531     -8.5763055831193924e-03
    z[2,3,6]  R1532     -9.0737998485565186e-02
    z[2,3,6]  R1533     -2.4420207738876343e-01
    z[2,3,6]  R1534     3.9023146033287048e-01
    z[2,3,6]  R1535     -9.9755868315696716e-02
    z[2,3,6]  R1536     4.2261913418769836e-01
    z[2,3,6]  R1537     -2.6162469387054443e-01
    z[2,3,6]  R1538     -1.6433786600828171e-02
    z[2,3,6]  R1539     -1.2982209026813507e-01
    z[2,3,6]  R1540     1.5139083564281464e-01
    z[2,3,6]  R1541     -6.4163416624069214e-02
    z[2,3,6]  R1542     2.1978148818016052e-01
    z[2,3,6]  R1543     -2.0590944215655327e-02
    z[2,3,6]  R1544     -7.2199642658233643e-02
    z[2,3,6]  R1545     2.1643798053264618e-01
    z[2,3,6]  R1546     -7.3277676105499268e-01
    z[2,3,6]  R1547     3.1019678711891174e-01
    z[2,3,6]  R1548     9.6868827939033508e-02
    z[2,3,6]  R1549     -1.2527799606323242e-01
    z[2,3,6]  R1550     7.4379876255989075e-02
    z[2,3,6]  R1551     -1.3619431294500828e-02
    z[2,3,6]  R1552     -7.2764731943607330e-02
    z[2,3,6]  R1553     -7.7986407279968262e-01
    z[2,3,6]  R1554     -4.7147876024246216e-01
    z[2,3,6]  R1555     3.5145735740661621e-01
    z[2,3,6]  R1556     -2.4567832052707672e-01
    z[2,3,6]  R1557     -2.3418083786964417e-01
    z[2,3,6]  R1558     -3.8220256567001343e-01
    z[2,3,6]  R1559     -4.1139709949493408e-01
    z[2,3,6]  R1560     -5.7040389627218246e-02
    z[2,3,6]  R1561     7.9919129610061646e-02
    z[2,3,6]  R1562     4.9838513135910034e-02
    z[2,3,6]  R1563     -3.7416470050811768e-01
    z[2,3,6]  R1564     6.8591696023941040e-01
    z[2,3,6]  R1565     -3.3505210280418396e-01
    z[2,3,6]  R1566     -3.5237908363342285e-01
    z[2,3,6]  R1567     4.6693280339241028e-02
    z[2,3,6]  R1568     7.7178376913070679e-01
    z[2,3,6]  R1569     3.0427795648574829e-01
    z[2,3,6]  R1570     -3.5914036631584167e-01
    z[2,3,6]  R1571     6.9722110033035278e-01
    z[2,3,6]  R1572     7.0770651102066040e-01
    z[2,3,6]  R1573     1.9272483885288239e-02
    z[2,3,6]  R1574     -1.4926255680620670e-03
    z[2,3,6]  R1575     1.0365618020296097e-01
    z[2,3,6]  R1576     3.9519476890563965e-01
    z[2,3,6]  R1577     3.1461676955223083e-01
    z[2,3,6]  R1578     -1.8477068841457367e-01
    z[2,3,6]  R1579     -1.1238960921764374e-01
    z[2,3,6]  R1580     -2.6112458109855652e-01
    z[2,3,6]  R1581     1.3324251770973206e-01
    z[2,3,6]  R1582     1.0549000650644302e-01
    z[2,3,6]  R1583     4.4506066478788853e-03
    z[2,3,6]  R1584     -1.3924518227577209e-01
    z[2,3,6]  R1585     -1.4651606976985931e-01
    z[2,3,6]  R1586     -2.4712134897708893e-01
    z[2,3,6]  R1587     -3.5546213388442993e-02
    z[2,3,6]  R1588     -1.0249412804841995e-01
    z[2,3,6]  R1589     -1.7948724329471588e-01
    z[2,3,6]  R1590     -5.9537172317504883e-01
    z[2,3,6]  R1591     -5.0708043575286865e-01
    z[2,3,6]  R1592     0.264161080121994
    z[2,3,6]  R1593     -1.7609673738479614e-01
    z[2,3,6]  R1594     6.0599303245544434e-01
    z[2,3,6]  R1595     -5.4570611566305161e-02
    z[2,3,6]  R1596     4.6261945366859436e-01
    z[2,3,6]  R1597     -0.081184022128582
    z[2,3,6]  R1598     5.6252133846282959e-01
    z[2,3,6]  R1599     3.4647822380065918e-01
    z[2,3,6]  R1600     4.0271830558776855e-01
    z[2,3,6]  R1601     4.8912355303764343e-01
    z[2,3,6]  R1602     -8.0639824271202087e-02
    z[2,3,6]  R1603     -2.5323250889778137e-01
    z[2,3,6]  R1604     -1.4548771083354950e-01
    z[2,3,6]  R1605     1.6157284379005432e-01
    z[2,3,6]  R1606     3.5315132141113281e-01
    z[2,3,6]  R1607     2.0211941003799438e-01
    z[2,3,6]  R1608     -7.6526342891156673e-03
    z[2,3,6]  R1609     0.124819315969944
    z[2,3,6]  R1610     2.3658286035060883e-01
    z[2,3,6]  R1611     2.1239617466926575e-01
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R1612     -1
    z[3,2,0]  R1613     1
    z[3,2,0]  R1626     -5.6193226575851440e-01
    z[3,2,0]  R1627     -2.1877616643905640e-01
    z[3,2,0]  R1628     8.1439119577407837e-01
    z[3,2,0]  R1629     -4.3648043274879456e-01
    z[3,2,0]  R1630     8.5842144489288330e-01
    z[3,2,0]  R1631     6.6212922334671021e-01
    z[3,2,0]  R1632     7.5678145885467529e-01
    z[3,2,0]  R1633     -4.6959450840950012e-01
    z[3,2,0]  R1634     -1.8554012477397919e-01
    z[3,2,0]  R1635     8.1496782600879669e-02
    z[3,2,0]  R1636     4.0846642851829529e-01
    z[3,2,0]  R1637     5.4487776756286621e-01
    z[3,2,0]  R1638     2.1994680166244507e-01
    z[3,2,0]  R1639     2.4828505516052246e-01
    z[3,2,0]  R1640     3.4240600466728210e-01
    z[3,2,0]  R1641     -2.9961192607879639e-01
    z[3,2,0]  R1642     6.1994470655918121e-02
    z[3,2,0]  R1643     -4.5045062899589539e-01
    z[3,2,0]  R1644     1.7669546604156494e-01
    z[3,2,0]  R1645     -1.9386282563209534e-01
    z[3,2,0]  R1646     -3.6804085969924927e-01
    z[3,2,0]  R1647     -6.8062943220138550e-01
    z[3,2,0]  R1648     -7.5242631137371063e-02
    z[3,2,0]  R1649     5.4270535707473755e-01
    z[3,2,0]  R1650     -0.60260409116745
    z[3,2,0]  R1651     -0.841519296169281
    z[3,2,0]  R1652     -3.3021429181098938e-01
    z[3,2,0]  R1653     -1.4445284008979797e-01
    z[3,2,0]  R1654     -5.0922536849975586e-01
    z[3,2,0]  R1655     1.6006837785243988e-01
    z[3,2,0]  R1656     1.1964980512857437e-01
    z[3,2,0]  R1657     4.5635089278221130e-01
    z[3,2,0]  R1658     -0.125092551112175
    z[3,2,0]  R1659     4.7106048464775085e-01
    z[3,2,0]  R1660     -3.9310479164123535e-01
    z[3,2,0]  R1661     -3.6264759302139282e-01
    z[3,2,0]  R1662     -4.9746543169021606e-01
    z[3,2,0]  R1663     -3.1940698623657227e-01
    z[3,2,0]  R1664     -5.8063352108001709e-01
    z[3,2,0]  R1665     -2.9870501160621643e-01
    z[3,2,0]  R1666     7.2426810860633850e-02
    z[3,2,0]  R1667     -9.6556141972541809e-02
    z[3,2,0]  R1668     -3.3674961328506470e-01
    z[3,2,0]  R1669     -2.1139541268348694e-01
    z[3,2,0]  R1670     -6.4578318595886230e-01
    z[3,2,0]  R1671     -3.0570608377456665e-01
    z[3,2,0]  R1672     1.4016310870647430e-01
    z[3,2,0]  R1673     -3.0304387211799622e-01
    z[3,2,0]  R1674     -8.4870404005050659e-01
    z[3,2,0]  R1675     1.3653036952018738e-01
    z[3,2,0]  R1676     1.0207693278789520e-01
    z[3,2,0]  R1677     -4.5072686672210693e-01
    z[3,2,0]  R1678     -0.650905191898346
    z[3,2,0]  R1679     -4.1497984528541565e-01
    z[3,2,0]  R1680     2.6181656122207642e-01
    z[3,2,0]  R1681     -6.5905636548995972e-01
    z[3,2,0]  R1682     -3.6861473321914673e-01
    z[3,2,0]  R1683     -0.530968427658081
    z[3,2,0]  R1684     -5.7315403223037720e-01
    z[3,2,0]  R1685     -4.6986043453216553e-01
    z[3,2,0]  R1686     3.0096715688705444e-01
    z[3,2,0]  R1687     0.266201913356781
    z[3,2,0]  R1688     3.9871039986610413e-01
    z[3,2,0]  R1689     2.9021590948104858e-01
    z[3,2,0]  R1690     -6.1205196380615234e-01
    z[3,2,0]  R1691     0.790971040725708
    z[3,2,0]  R1692     6.4641773700714111e-02
    z[3,2,0]  R1693     -4.0440770983695984e-01
    z[3,2,0]  R1694     -0.0990544930100441
    z[3,2,0]  R1695     -1.8146137893199921e-01
    z[3,2,0]  R1696     -0.0699734315276146
    z[3,2,0]  R1697     0.806816041469574
    z[3,2,0]  R1698     -1.2725955247879028e-01
    z[3,2,0]  R1699     -2.3796859383583069e-01
    z[3,2,0]  R1700     7.5944811105728149e-02
    z[3,2,0]  R1701     -1.1690370738506317e-01
    z[3,2,0]  R1702     2.7889090776443481e-01
    z[3,2,0]  R1703     -1.2801650166511536e-01
    z[3,2,0]  R1704     -2.1942233666777611e-02
    z[3,2,0]  R1705     -3.4418243169784546e-01
    z[3,2,0]  R1706     3.4553754329681396e-01
    z[3,2,0]  R1707     -3.0406650900840759e-01
    z[3,2,0]  R1708     -3.5892143845558167e-01
    z[3,2,0]  R1709     -4.7762086987495422e-01
    z[3,2,0]  R1710     -3.4556332975625992e-02
    z[3,2,0]  R1711     -1.5605589747428894e-01
    z[3,2,0]  R1712     -3.9361652731895447e-01
    z[3,2,0]  R1713     -1.3211588561534882e-01
    z[3,2,0]  R1714     -6.5518431365489960e-02
    z[3,2,0]  R1715     -2.9194861650466919e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R1614     -1
    z[3,2,1]  R1615     1
    z[3,2,1]  R1626     1.2658137083053589e-01
    z[3,2,1]  R1627     -4.0987440943717957e-01
    z[3,2,1]  R1628     -1.7743816599249840e-02
    z[3,2,1]  R1629     1.5095029026269913e-02
    z[3,2,1]  R1630     1.3860325515270233e-01
    z[3,2,1]  R1631     0.219833105802536
    z[3,2,1]  R1632     0.278201162815094
    z[3,2,1]  R1633     3.0335025861859322e-02
    z[3,2,1]  R1634     -6.4056468009948730e-01
    z[3,2,1]  R1635     -5.5411326885223389e-01
    z[3,2,1]  R1636     5.4294317960739136e-01
    z[3,2,1]  R1637     2.1319216489791870e-01
    z[3,2,1]  R1638     7.0009982585906982e-01
    z[3,2,1]  R1639     -1.4219549298286438e-01
    z[3,2,1]  R1640     4.1987210512161255e-01
    z[3,2,1]  R1641     -4.9000686407089233e-01
    z[3,2,1]  R1642     -2.4379158020019531e-01
    z[3,2,1]  R1643     -1.9936127960681915e-01
    z[3,2,1]  R1644     1.3906867243349552e-02
    z[3,2,1]  R1645     1.0930828005075455e-01
    z[3,2,1]  R1646     -3.1919276714324951e-01
    z[3,2,1]  R1647     -6.4516997337341309e-01
    z[3,2,1]  R1648     -4.2915329337120056e-01
    z[3,2,1]  R1649     2.8473719954490662e-01
    z[3,2,1]  R1650     -3.1105524301528931e-01
    z[3,2,1]  R1651     -2.6590937376022339e-01
    z[3,2,1]  R1652     -5.6255763769149780e-01
    z[3,2,1]  R1653     -3.5914209485054016e-01
    z[3,2,1]  R1654     1.9825773313641548e-02
    z[3,2,1]  R1655     -7.7108982950448990e-03
    z[3,2,1]  R1656     5.9983724355697632e-01
    z[3,2,1]  R1657     7.2173017263412476e-01
    z[3,2,1]  R1658     4.3486005067825317e-01
    z[3,2,1]  R1659     2.1249566972255707e-01
    z[3,2,1]  R1660     -2.1284019947052002e-01
    z[3,2,1]  R1661     -0.332770437002182
    z[3,2,1]  R1662     -3.5462863743305206e-02
    z[3,2,1]  R1663     -8.2390010356903076e-02
    z[3,2,1]  R1664     -0.181112602353096
    z[3,2,1]  R1665     -6.3754066824913025e-02
    z[3,2,1]  R1666     3.5394972562789917e-01
    z[3,2,1]  R1667     8.4005340933799744e-02
    z[3,2,1]  R1668     -4.2696595191955566e-02
    z[3,2,1]  R1669     0.0811346247792244
    z[3,2,1]  R1670     4.2347289621829987e-02
    z[3,2,1]  R1671     -9.2981308698654175e-02
    z[3,2,1]  R1672     -2.3038220405578613e-01
    z[3,2,1]  R1673     -2.3555132746696472e-01
    z[3,2,1]  R1674     -9.0188965201377869e-02
    z[3,2,1]  R1675     -2.9894340783357620e-02
    z[3,2,1]  R1676     -9.5013357698917389e-02
    z[3,2,1]  R1677     -8.7583720684051514e-01
    z[3,2,1]  R1678     -7.2417879104614258e-01
    z[3,2,1]  R1679     4.2553361505270004e-02
    z[3,2,1]  R1680     -2.7154216170310974e-01
    z[3,2,1]  R1681     -5.9841054677963257e-01
    z[3,2,1]  R1682     -7.6666903495788574e-01
    z[3,2,1]  R1683     -6.2934494018554688e-01
    z[3,2,1]  R1684     -5.9415531158447266e-01
    z[3,2,1]  R1685     -3.0684208869934082e-01
    z[3,2,1]  R1686     -4.1537608951330185e-02
    z[3,2,1]  R1687     -1.8900800496339798e-02
    z[3,2,1]  R1688     -3.6691910028457642e-01
    z[3,2,1]  R1689     -4.4243744015693665e-01
    z[3,2,1]  R1690     -3.1237161159515381e-01
    z[3,2,1]  R1691     0.0637897253036499
    z[3,2,1]  R1692     -0.583785355091095
    z[3,2,1]  R1693     -6.6741967201232910e-01
    z[3,2,1]  R1694     -4.8305392265319824e-01
    z[3,2,1]  R1695     -6.9934207201004028e-01
    z[3,2,1]  R1696     4.1462263464927673e-01
    z[3,2,1]  R1697     2.4976047873497009e-01
    z[3,2,1]  R1698     4.0262803435325623e-01
    z[3,2,1]  R1699     -3.2162415981292725e-01
    z[3,2,1]  R1700     -3.1465274095535278e-01
    z[3,2,1]  R1701     -8.8595676422119141e-01
    z[3,2,1]  R1702     4.3278205394744873e-01
    z[3,2,1]  R1703     3.2780739665031433e-01
    z[3,2,1]  R1704     -0.562740683555603
    z[3,2,1]  R1705     -4.7032970190048218e-01
    z[3,2,1]  R1706     4.2216780781745911e-01
    z[3,2,1]  R1707     -6.2297242879867554e-01
    z[3,2,1]  R1708     -3.4845784306526184e-01
    z[3,2,1]  R1709     -6.8859666585922241e-01
    z[3,2,1]  R1710     -4.9920460581779480e-01
    z[3,2,1]  R1711     -4.4212073087692261e-01
    z[3,2,1]  R1712     -2.2997401654720306e-01
    z[3,2,1]  R1713     -7.0381003618240356e-01
    z[3,2,1]  R1714     -6.4303326606750488e-01
    z[3,2,1]  R1715     -5.4580366611480713e-01
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R1616     -1
    z[3,2,2]  R1617     1
    z[3,2,2]  R1626     6.9000810384750366e-01
    z[3,2,2]  R1627     0.210184246301651
    z[3,2,2]  R1628     1.1719269305467606e-01
    z[3,2,2]  R1629     6.9620794057846069e-01
    z[3,2,2]  R1630     3.2710447907447815e-01
    z[3,2,2]  R1631     5.0952249765396118e-01
    z[3,2,2]  R1632     7.6343074440956116e-02
    z[3,2,2]  R1633     6.8611919879913330e-01
    z[3,2,2]  R1634     1.4378747344017029e-01
    z[3,2,2]  R1635     -0.062874436378479
    z[3,2,2]  R1636     -2.8643596172332764e-01
    z[3,2,2]  R1637     -6.5241509675979614e-01
    z[3,2,2]  R1638     -1.8200229108333588e-01
    z[3,2,2]  R1639     -2.4465499818325043e-01
    z[3,2,2]  R1640     -2.4278061091899872e-01
    z[3,2,2]  R1641     -5.4686951637268066e-01
    z[3,2,2]  R1642     1.7173700034618378e-02
    z[3,2,2]  R1643     -7.0712512731552124e-01
    z[3,2,2]  R1644     -6.5931832790374756e-01
    z[3,2,2]  R1645     -4.0237104892730713e-01
    z[3,2,2]  R1646     -3.7199565768241882e-01
    z[3,2,2]  R1647     -1.3697220385074615e-01
    z[3,2,2]  R1648     -7.1549135446548462e-01
    z[3,2,2]  R1649     -1.8416188657283783e-01
    z[3,2,2]  R1650     -4.1858857870101929e-01
    z[3,2,2]  R1651     1.5182051062583923e-01
    z[3,2,2]  R1652     -3.4829905629158020e-01
    z[3,2,2]  R1653     -5.8139652013778687e-01
    z[3,2,2]  R1654     1.2566743791103363e-01
    z[3,2,2]  R1655     -0.649156391620636
    z[3,2,2]  R1656     3.0667799711227417e-01
    z[3,2,2]  R1657     8.7701253592967987e-02
    z[3,2,2]  R1658     5.4213011264801025e-01
    z[3,2,2]  R1659     -1.9859565794467926e-01
    z[3,2,2]  R1660     6.8247979879379272e-01
    z[3,2,2]  R1661     5.1311510801315308e-01
    z[3,2,2]  R1662     5.7735347747802734e-01
    z[3,2,2]  R1663     5.7280987501144409e-01
    z[3,2,2]  R1664     3.1305974721908569e-01
    z[3,2,2]  R1665     9.0186780691146851e-01
    z[3,2,2]  R1666     4.5689836144447327e-01
    z[3,2,2]  R1667     -3.0133244395256042e-01
    z[3,2,2]  R1668     -1.7264898121356964e-01
    z[3,2,2]  R1669     -3.2008981704711914e-01
    z[3,2,2]  R1670     -3.3835846930742264e-02
    z[3,2,2]  R1671     -8.4999807178974152e-02
    z[3,2,2]  R1672     -5.3778284788131714e-01
    z[3,2,2]  R1673     -1.6220824420452118e-01
    z[3,2,2]  R1674     4.5658446848392487e-02
    z[3,2,2]  R1675     -0.291608065366745
    z[3,2,2]  R1676     -0.0314226932823658
    z[3,2,2]  R1677     -1.0495898127555847e-01
    z[3,2,2]  R1678     9.9670603871345520e-02
    z[3,2,2]  R1679     -7.1303009986877441e-01
    z[3,2,2]  R1680     -9.3205086886882782e-02
    z[3,2,2]  R1681     1.2623761594295502e-01
    z[3,2,2]  R1682     -7.5511775910854340e-02
    z[3,2,2]  R1683     1.6558539867401123e-01
    z[3,2,2]  R1684     1.6087324917316437e-01
    z[3,2,2]  R1685     -5.3906667232513428e-01
    z[3,2,2]  R1686     1.5534909069538116e-01
    z[3,2,2]  R1687     1.7812253534793854e-01
    z[3,2,2]  R1688     -7.1083754301071167e-02
    z[3,2,2]  R1689     -3.1101605296134949e-01
    z[3,2,2]  R1690     5.8487743139266968e-01
    z[3,2,2]  R1691     -2.8012701869010925e-01
    z[3,2,2]  R1692     0.524462878704071
    z[3,2,2]  R1693     1.7696005105972290e-01
    z[3,2,2]  R1694     3.4141331911087036e-01
    z[3,2,2]  R1695     5.0322753190994263e-01
    z[3,2,2]  R1696     4.8755025863647461e-01
    z[3,2,2]  R1697     -2.0616883039474487e-01
    z[3,2,2]  R1698     3.0896782875061035e-01
    z[3,2,2]  R1699     4.5889967679977417e-01
    z[3,2,2]  R1700     8.2162946462631226e-01
    z[3,2,2]  R1701     3.1508103013038635e-01
    z[3,2,2]  R1702     -2.0668437704443932e-02
    z[3,2,2]  R1703     -4.0846887230873108e-01
    z[3,2,2]  R1704     -4.7836822271347046e-01
    z[3,2,2]  R1705     -6.8681873381137848e-04
    z[3,2,2]  R1706     -3.6278583109378815e-02
    z[3,2,2]  R1707     7.0591771602630615e-01
    z[3,2,2]  R1708     1.5450893342494965e-01
    z[3,2,2]  R1709     -3.6272511351853609e-04
    z[3,2,2]  R1710     6.5159320831298828e-01
    z[3,2,2]  R1711     5.0417190790176392e-01
    z[3,2,2]  R1712     3.4218469262123108e-01
    z[3,2,2]  R1713     2.3716755211353302e-01
    z[3,2,2]  R1714     6.0096681118011475e-01
    z[3,2,2]  R1715     -4.2711740732192993e-01
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R1618     -1
    z[3,2,3]  R1619     1
    z[3,2,3]  R1626     1.3518603146076202e-01
    z[3,2,3]  R1627     -6.0827100276947021e-01
    z[3,2,3]  R1628     -4.3505945801734924e-01
    z[3,2,3]  R1629     -1.0539470240473747e-02
    z[3,2,3]  R1630     -6.3690222799777985e-02
    z[3,2,3]  R1631     -4.0693020820617676e-01
    z[3,2,3]  R1632     -2.1456105634570122e-02
    z[3,2,3]  R1633     -4.7923552989959717e-01
    z[3,2,3]  R1634     -3.9578646421432495e-02
    z[3,2,3]  R1635     -3.6662086844444275e-01
    z[3,2,3]  R1636     3.9195086807012558e-02
    z[3,2,3]  R1637     4.0870717167854309e-01
    z[3,2,3]  R1638     1.4911645650863647e-01
    z[3,2,3]  R1639     -0.0082710487768054
    z[3,2,3]  R1640     1.2566968798637390e-01
    z[3,2,3]  R1641     -7.5368061661720276e-03
    z[3,2,3]  R1642     2.3450877051800489e-03
    z[3,2,3]  R1643     -1.7732071876525879e-01
    z[3,2,3]  R1644     -5.8723551034927368e-01
    z[3,2,3]  R1645     -6.1758917570114136e-01
    z[3,2,3]  R1646     -1.6537846624851227e-01
    z[3,2,3]  R1647     -1.5702915191650391e-01
    z[3,2,3]  R1648     -1.2456391006708145e-01
    z[3,2,3]  R1649     2.1796748042106628e-01
    z[3,2,3]  R1650     -3.2868149876594543e-01
    z[3,2,3]  R1651     -2.8656652569770813e-01
    z[3,2,3]  R1652     -3.3567818999290466e-01
    z[3,2,3]  R1653     -6.9308197498321533e-01
    z[3,2,3]  R1654     1.7923320829868317e-01
    z[3,2,3]  R1655     -4.1287642717361450e-01
    z[3,2,3]  R1656     9.3609832227230072e-02
    z[3,2,3]  R1657     -2.1035907790064812e-02
    z[3,2,3]  R1658     1.3036954402923584e-01
    z[3,2,3]  R1659     2.0052876323461533e-02
    z[3,2,3]  R1660     -0.495135635137558
    z[3,2,3]  R1661     -3.0368411540985107e-01
    z[3,2,3]  R1662     -0.511141300201416
    z[3,2,3]  R1663     -7.0996415615081787e-01
    z[3,2,3]  R1664     -6.7732381820678711e-01
    z[3,2,3]  R1665     -2.2971355915069580e-01
    z[3,2,3]  R1666     7.1147501468658447e-01
    z[3,2,3]  R1667     -7.3761200904846191e-01
    z[3,2,3]  R1668     -0.451924204826355
    z[3,2,3]  R1669     -2.0343993604183197e-01
    z[3,2,3]  R1670     -2.2310629487037659e-01
    z[3,2,3]  R1671     -2.8772500157356262e-01
    z[3,2,3]  R1672     -6.3988798856735229e-01
    z[3,2,3]  R1673     -2.6446914672851562e-01
    z[3,2,3]  R1674     -2.9471242427825928e-01
    z[3,2,3]  R1675     -3.5488110780715942e-01
    z[3,2,3]  R1676     7.0867466926574707e-01
    z[3,2,3]  R1677     1.1995280534029007e-01
    z[3,2,3]  R1678     9.1283574700355530e-02
    z[3,2,3]  R1679     -4.3391120433807373e-01
    z[3,2,3]  R1680     3.7661322951316833e-01
    z[3,2,3]  R1681     2.5445926189422607e-01
    z[3,2,3]  R1682     0.0413551852107048
    z[3,2,3]  R1683     6.5296448767185211e-02
    z[3,2,3]  R1684     1.6322822868824005e-01
    z[3,2,3]  R1685     -4.7423759102821350e-01
    z[3,2,3]  R1686     6.3237917423248291e-01
    z[3,2,3]  R1687     3.9997085928916931e-01
    z[3,2,3]  R1688     6.8104404211044312e-01
    z[3,2,3]  R1689     4.9130213260650635e-01
    z[3,2,3]  R1690     -3.3424523472785950e-01
    z[3,2,3]  R1691     2.3141415417194366e-01
    z[3,2,3]  R1692     -3.3661547303199768e-01
    z[3,2,3]  R1693     5.9688467532396317e-02
    z[3,2,3]  R1694     -8.9241966605186462e-02
    z[3,2,3]  R1695     2.6097431778907776e-01
    z[3,2,3]  R1696     5.2706265449523926e-01
    z[3,2,3]  R1697     3.2264092564582825e-01
    z[3,2,3]  R1698     1.1933559924364090e-01
    z[3,2,3]  R1699     5.2976008504629135e-02
    z[3,2,3]  R1700     -0.276328444480896
    z[3,2,3]  R1701     -5.9998266398906708e-02
    z[3,2,3]  R1702     1.9840340316295624e-01
    z[3,2,3]  R1703     -6.9231164455413818e-01
    z[3,2,3]  R1704     -3.6303135752677917e-01
    z[3,2,3]  R1705     -2.5195494294166565e-01
    z[3,2,3]  R1706     3.2401415705680847e-01
    z[3,2,3]  R1707     1.2854067981243134e-01
    z[3,2,3]  R1708     -3.8726359605789185e-01
    z[3,2,3]  R1709     -4.6152842044830322e-01
    z[3,2,3]  R1710     -6.3248798251152039e-02
    z[3,2,3]  R1711     4.4629681855440140e-02
    z[3,2,3]  R1712     -2.6927703619003296e-01
    z[3,2,3]  R1713     -6.9246530532836914e-02
    z[3,2,3]  R1714     -2.1628679335117340e-01
    z[3,2,3]  R1715     -5.7753199338912964e-01
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R1620     -1
    z[3,2,4]  R1621     1
    z[3,2,4]  R1626     -4.0334054827690125e-01
    z[3,2,4]  R1627     3.4928798675537109e-01
    z[3,2,4]  R1628     3.3656361699104309e-01
    z[3,2,4]  R1629     1.7802956700325012e-01
    z[3,2,4]  R1630     2.6296606659889221e-01
    z[3,2,4]  R1631     -3.5195663571357727e-02
    z[3,2,4]  R1632     2.0981298387050629e-01
    z[3,2,4]  R1633     -2.1187800168991089e-01
    z[3,2,4]  R1634     1.7886583507061005e-01
    z[3,2,4]  R1635     -1.1789031559601426e-03
    z[3,2,4]  R1636     -0.558672308921814
    z[3,2,4]  R1637     -1.1019662767648697e-01
    z[3,2,4]  R1638     -5.5909123271703720e-02
    z[3,2,4]  R1639     -9.2242914438247681e-01
    z[3,2,4]  R1640     5.5569779872894287e-01
    z[3,2,4]  R1641     4.8192042112350464e-01
    z[3,2,4]  R1642     -5.4806423187255859e-01
    z[3,2,4]  R1643     3.2528510689735413e-01
    z[3,2,4]  R1644     1.6369768977165222e-01
    z[3,2,4]  R1645     -3.7840676307678223e-01
    z[3,2,4]  R1646     1.8910128623247147e-02
    z[3,2,4]  R1647     -2.6657721027731895e-02
    z[3,2,4]  R1648     4.0477478504180908e-01
    z[3,2,4]  R1649     5.5097335577011108e-01
    z[3,2,4]  R1650     0.349839985370636
    z[3,2,4]  R1651     -2.0136989653110504e-01
    z[3,2,4]  R1652     4.9555456638336182e-01
    z[3,2,4]  R1653     -1.2139406055212021e-01
    z[3,2,4]  R1654     4.4311735033988953e-01
    z[3,2,4]  R1655     1.1949014663696289e-01
    z[3,2,4]  R1656     -7.1888190507888794e-01
    z[3,2,4]  R1657     -5.0630760192871094e-01
    z[3,2,4]  R1658     -4.9986669421195984e-01
    z[3,2,4]  R1659     -8.1424170732498169e-01
    z[3,2,4]  R1660     1.8985408544540405e-01
    z[3,2,4]  R1661     -4.0892388671636581e-02
    z[3,2,4]  R1662     6.8054132163524628e-02
    z[3,2,4]  R1663     8.9658878277987242e-04
    z[3,2,4]  R1664     1.2329649180173874e-02
    z[3,2,4]  R1665     -3.6802776157855988e-02
    z[3,2,4]  R1666     3.6640360951423645e-01
    z[3,2,4]  R1667     3.6034294962882996e-01
    z[3,2,4]  R1668     5.6489914655685425e-01
    z[3,2,4]  R1669     0.739863395690918
    z[3,2,4]  R1670     5.7485264539718628e-01
    z[3,2,4]  R1671     0.858572244644165
    z[3,2,4]  R1672     4.0431788563728333e-01
    z[3,2,4]  R1673     5.5548012256622314e-01
    z[3,2,4]  R1674     3.0688369274139404e-01
    z[3,2,4]  R1675     8.6194217205047607e-01
    z[3,2,4]  R1676     -2.4086178839206696e-01
    z[3,2,4]  R1677     -0.0619514137506485
    z[3,2,4]  R1678     -1.5650069713592529e-01
    z[3,2,4]  R1679     2.8335490822792053e-01
    z[3,2,4]  R1680     -1.8668599426746368e-01
    z[3,2,4]  R1681     1.1433929204940796e-01
    z[3,2,4]  R1682     3.0734360218048096e-01
    z[3,2,4]  R1683     3.4631672501564026e-01
    z[3,2,4]  R1684     4.6331921219825745e-01
    z[3,2,4]  R1685     2.0889858901500702e-01
    z[3,2,4]  R1686     -5.2693516016006470e-01
    z[3,2,4]  R1687     -3.3935031294822693e-01
    z[3,2,4]  R1688     5.5278204381465912e-02
    z[3,2,4]  R1689     -5.0832325220108032e-01
    z[3,2,4]  R1690     9.5697872340679169e-02
    z[3,2,4]  R1691     2.0208714902400970e-01
    z[3,2,4]  R1692     3.4052771329879761e-01
    z[3,2,4]  R1693     9.6334271132946014e-02
    z[3,2,4]  R1694     7.3046833276748657e-01
    z[3,2,4]  R1695     3.8761347532272339e-01
    z[3,2,4]  R1696     -5.5150383710861206e-01
    z[3,2,4]  R1697     1.8650289857760072e-03
    z[3,2,4]  R1698     -1.4399588108062744e-01
    z[3,2,4]  R1699     3.1894093751907349e-01
    z[3,2,4]  R1700     6.0998909175395966e-02
    z[3,2,4]  R1701     2.7304571866989136e-01
    z[3,2,4]  R1702     2.5782135128974915e-01
    z[3,2,4]  R1703     2.4912282824516296e-01
    z[3,2,4]  R1704     4.3123376369476318e-01
    z[3,2,4]  R1705     2.5804471969604492e-01
    z[3,2,4]  R1706     3.0102011561393738e-01
    z[3,2,4]  R1707     4.5850764960050583e-02
    z[3,2,4]  R1708     6.2477457523345947e-01
    z[3,2,4]  R1709     -6.8612575531005859e-02
    z[3,2,4]  R1710     3.1580066680908203e-01
    z[3,2,4]  R1711     4.3939542770385742e-01
    z[3,2,4]  R1712     7.5136470794677734e-01
    z[3,2,4]  R1713     5.2736049890518188e-01
    z[3,2,4]  R1714     -2.9020509123802185e-01
    z[3,2,4]  R1715     2.6936045289039612e-01
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R1622     -1
    z[3,2,5]  R1623     1
    z[3,2,5]  R1626     -3.3380375243723392e-03
    z[3,2,5]  R1627     -4.9794283509254456e-01
    z[3,2,5]  R1628     2.7872281149029732e-02
    z[3,2,5]  R1629     -5.2084422111511230e-01
    z[3,2,5]  R1630     5.1263108849525452e-02
    z[3,2,5]  R1631     -2.9249009490013123e-01
    z[3,2,5]  R1632     -5.3765302896499634e-01
    z[3,2,5]  R1633     -3.2040674239397049e-02
    z[3,2,5]  R1634     -3.8281852006912231e-01
    z[3,2,5]  R1635     -0.539277970790863
    z[3,2,5]  R1636     2.6998212933540344e-01
    z[3,2,5]  R1637     1.4770534634590149e-01
    z[3,2,5]  R1638     1.8912889063358307e-01
    z[3,2,5]  R1639     0.0660073533654213
    z[3,2,5]  R1640     3.3002045750617981e-01
    z[3,2,5]  R1641     3.6354464292526245e-01
    z[3,2,5]  R1642     5.6534707546234131e-01
    z[3,2,5]  R1643     4.8115104436874390e-03
    z[3,2,5]  R1644     7.7572362497448921e-03
    z[3,2,5]  R1645     -1.5721473097801208e-01
    z[3,2,5]  R1646     -7.6816070079803467e-01
    z[3,2,5]  R1647     -1.1064589023590088e-01
    z[3,2,5]  R1648     -3.1259015202522278e-01
    z[3,2,5]  R1649     4.6183642745018005e-01
    z[3,2,5]  R1650     9.8798334598541260e-02
    z[3,2,5]  R1651     -0.185917928814888
    z[3,2,5]  R1652     0.307997465133667
    z[3,2,5]  R1653     3.8070093840360641e-02
    z[3,2,5]  R1654     -6.6336655616760254e-01
    z[3,2,5]  R1655     -5.6838154792785645e-01
    z[3,2,5]  R1656     -2.1863847970962524e-02
    z[3,2,5]  R1657     -0.0313928946852684
    z[3,2,5]  R1658     3.3899274468421936e-01
    z[3,2,5]  R1659     7.5918912887573242e-02
    z[3,2,5]  R1660     -1.5463545918464661e-02
    z[3,2,5]  R1661     6.1474508047103882e-01
    z[3,2,5]  R1662     3.8006502389907837e-01
    z[3,2,5]  R1663     2.2136305272579193e-01
    z[3,2,5]  R1664     2.3091264069080353e-01
    z[3,2,5]  R1665     1.9786050915718079e-01
    z[3,2,5]  R1666     1.0970976948738098e-01
    z[3,2,5]  R1667     -3.9908087253570557e-01
    z[3,2,5]  R1668     -4.2348787188529968e-01
    z[3,2,5]  R1669     -4.9752873182296753e-01
    z[3,2,5]  R1670     -1.4555752277374268e-01
    z[3,2,5]  R1671     4.7893855720758438e-02
    z[3,2,5]  R1672     -2.5469270348548889e-01
    z[3,2,5]  R1673     -6.5651547908782959e-01
    z[3,2,5]  R1674     -2.5598949193954468e-01
    z[3,2,5]  R1675     -1.4976185560226440e-01
    z[3,2,5]  R1676     -6.0912001132965088e-01
    z[3,2,5]  R1677     9.3447407707571983e-03
    z[3,2,5]  R1678     -6.2571600079536438e-02
    z[3,2,5]  R1679     -4.6416290104389191e-02
    z[3,2,5]  R1680     -3.6793848872184753e-01
    z[3,2,5]  R1681     -1.3254623115062714e-01
    z[3,2,5]  R1682     4.0630754828453064e-01
    z[3,2,5]  R1683     3.9330080151557922e-01
    z[3,2,5]  R1684     2.1390035748481750e-01
    z[3,2,5]  R1685     3.5462772846221924e-01
    z[3,2,5]  R1686     4.4799691438674927e-01
    z[3,2,5]  R1687     1.1716803908348083e-01
    z[3,2,5]  R1688     1.1035675555467606e-01
    z[3,2,5]  R1689     4.8289110418409109e-04
    z[3,2,5]  R1690     -0.0670744925737381
    z[3,2,5]  R1691     3.7761366367340088e-01
    z[3,2,5]  R1692     6.7873440682888031e-02
    z[3,2,5]  R1693     4.2142614722251892e-01
    z[3,2,5]  R1694     3.0900228023529053e-01
    z[3,2,5]  R1695     3.9559951983392239e-03
    z[3,2,5]  R1696     3.2422382384538651e-02
    z[3,2,5]  R1697     7.8848125413060188e-03
    z[3,2,5]  R1698     4.6986883878707886e-01
    z[3,2,5]  R1699     6.4230072498321533e-01
    z[3,2,5]  R1700     -1.2610211968421936e-01
    z[3,2,5]  R1701     1.4766190946102142e-01
    z[3,2,5]  R1702     1.8167679011821747e-01
    z[3,2,5]  R1703     -2.7452623844146729e-01
    z[3,2,5]  R1704     -8.5259661078453064e-02
    z[3,2,5]  R1705     2.1010087430477142e-01
    z[3,2,5]  R1706     6.7935936152935028e-02
    z[3,2,5]  R1707     4.6180140227079391e-02
    z[3,2,5]  R1708     4.3076780438423157e-01
    z[3,2,5]  R1709     2.6315766572952271e-01
    z[3,2,5]  R1710     2.5518137216567993e-01
    z[3,2,5]  R1711     4.8160418868064880e-01
    z[3,2,5]  R1712     6.2356390058994293e-02
    z[3,2,5]  R1713     0.367984801530838
    z[3,2,5]  R1714     -1.4788319170475006e-01
    z[3,2,5]  R1715     1.0287480056285858e-01
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R1624     -1
    z[3,2,6]  R1625     1
    z[3,2,6]  R1626     1.0549000650644302e-01
    z[3,2,6]  R1627     4.4506066478788853e-03
    z[3,2,6]  R1628     -1.3924518227577209e-01
    z[3,2,6]  R1629     -1.4651606976985931e-01
    z[3,2,6]  R1630     -2.4712134897708893e-01
    z[3,2,6]  R1631     -3.5546213388442993e-02
    z[3,2,6]  R1632     -1.0249412804841995e-01
    z[3,2,6]  R1633     -1.7948724329471588e-01
    z[3,2,6]  R1634     -5.9537172317504883e-01
    z[3,2,6]  R1635     -5.0708043575286865e-01
    z[3,2,6]  R1636     0.264161080121994
    z[3,2,6]  R1637     -1.7609673738479614e-01
    z[3,2,6]  R1638     6.0599303245544434e-01
    z[3,2,6]  R1639     -5.4570611566305161e-02
    z[3,2,6]  R1640     4.6261945366859436e-01
    z[3,2,6]  R1641     -0.081184022128582
    z[3,2,6]  R1642     5.6252133846282959e-01
    z[3,2,6]  R1643     3.4647822380065918e-01
    z[3,2,6]  R1644     4.0271830558776855e-01
    z[3,2,6]  R1645     4.8912355303764343e-01
    z[3,2,6]  R1646     -8.0639824271202087e-02
    z[3,2,6]  R1647     -2.5323250889778137e-01
    z[3,2,6]  R1648     -1.4548771083354950e-01
    z[3,2,6]  R1649     1.6157284379005432e-01
    z[3,2,6]  R1650     3.5315132141113281e-01
    z[3,2,6]  R1651     2.0211941003799438e-01
    z[3,2,6]  R1652     -7.6526342891156673e-03
    z[3,2,6]  R1653     0.124819315969944
    z[3,2,6]  R1654     2.3658286035060883e-01
    z[3,2,6]  R1655     2.1239617466926575e-01
    z[3,2,6]  R1656     -7.6129332184791565e-02
    z[3,2,6]  R1657     -7.3365390300750732e-02
    z[3,2,6]  R1658     -3.4578087925910950e-01
    z[3,2,6]  R1659     1.5605156123638153e-01
    z[3,2,6]  R1660     2.3009985685348511e-01
    z[3,2,6]  R1661     1.5051838755607605e-01
    z[3,2,6]  R1662     8.7104015052318573e-02
    z[3,2,6]  R1663     -1.0014154762029648e-01
    z[3,2,6]  R1664     -1.4077019691467285e-01
    z[3,2,6]  R1665     -8.5763055831193924e-03
    z[3,2,6]  R1666     -9.0737998485565186e-02
    z[3,2,6]  R1667     -2.4420207738876343e-01
    z[3,2,6]  R1668     3.9023146033287048e-01
    z[3,2,6]  R1669     -9.9755868315696716e-02
    z[3,2,6]  R1670     4.2261913418769836e-01
    z[3,2,6]  R1671     -2.6162469387054443e-01
    z[3,2,6]  R1672     -1.6433786600828171e-02
    z[3,2,6]  R1673     -1.2982209026813507e-01
    z[3,2,6]  R1674     1.5139083564281464e-01
    z[3,2,6]  R1675     -6.4163416624069214e-02
    z[3,2,6]  R1676     2.1978148818016052e-01
    z[3,2,6]  R1677     -2.0590944215655327e-02
    z[3,2,6]  R1678     -7.2199642658233643e-02
    z[3,2,6]  R1679     2.1643798053264618e-01
    z[3,2,6]  R1680     -7.3277676105499268e-01
    z[3,2,6]  R1681     3.1019678711891174e-01
    z[3,2,6]  R1682     9.6868827939033508e-02
    z[3,2,6]  R1683     -1.2527799606323242e-01
    z[3,2,6]  R1684     7.4379876255989075e-02
    z[3,2,6]  R1685     -1.3619431294500828e-02
    z[3,2,6]  R1686     -7.2764731943607330e-02
    z[3,2,6]  R1687     -7.7986407279968262e-01
    z[3,2,6]  R1688     -4.7147876024246216e-01
    z[3,2,6]  R1689     3.5145735740661621e-01
    z[3,2,6]  R1690     -2.4567832052707672e-01
    z[3,2,6]  R1691     -2.3418083786964417e-01
    z[3,2,6]  R1692     -3.8220256567001343e-01
    z[3,2,6]  R1693     -4.1139709949493408e-01
    z[3,2,6]  R1694     -5.7040389627218246e-02
    z[3,2,6]  R1695     7.9919129610061646e-02
    z[3,2,6]  R1696     4.9838513135910034e-02
    z[3,2,6]  R1697     -3.7416470050811768e-01
    z[3,2,6]  R1698     6.8591696023941040e-01
    z[3,2,6]  R1699     -3.3505210280418396e-01
    z[3,2,6]  R1700     -3.5237908363342285e-01
    z[3,2,6]  R1701     4.6693280339241028e-02
    z[3,2,6]  R1702     7.7178376913070679e-01
    z[3,2,6]  R1703     3.0427795648574829e-01
    z[3,2,6]  R1704     -3.5914036631584167e-01
    z[3,2,6]  R1705     6.9722110033035278e-01
    z[3,2,6]  R1706     7.0770651102066040e-01
    z[3,2,6]  R1707     1.9272483885288239e-02
    z[3,2,6]  R1708     -1.4926255680620670e-03
    z[3,2,6]  R1709     1.0365618020296097e-01
    z[3,2,6]  R1710     3.9519476890563965e-01
    z[3,2,6]  R1711     3.1461676955223083e-01
    z[3,2,6]  R1712     -1.8477068841457367e-01
    z[3,2,6]  R1713     -1.1238960921764374e-01
    z[3,2,6]  R1714     -2.6112458109855652e-01
    z[3,2,6]  R1715     1.3324251770973206e-01
    z[3,6,0]  R29       -1
    z[3,6,0]  R56       1
    z[3,6,0]  R1716     -1
    z[3,6,0]  R1717     1
    z[3,6,0]  R1730     -5.6193226575851440e-01
    z[3,6,0]  R1731     -2.1877616643905640e-01
    z[3,6,0]  R1732     8.1439119577407837e-01
    z[3,6,0]  R1733     -4.3648043274879456e-01
    z[3,6,0]  R1734     8.5842144489288330e-01
    z[3,6,0]  R1735     6.6212922334671021e-01
    z[3,6,0]  R1736     7.5678145885467529e-01
    z[3,6,0]  R1737     -4.6959450840950012e-01
    z[3,6,0]  R1738     -1.8554012477397919e-01
    z[3,6,0]  R1739     8.1496782600879669e-02
    z[3,6,0]  R1740     4.0846642851829529e-01
    z[3,6,0]  R1741     5.4487776756286621e-01
    z[3,6,0]  R1742     2.1994680166244507e-01
    z[3,6,0]  R1743     2.4828505516052246e-01
    z[3,6,0]  R1744     3.4240600466728210e-01
    z[3,6,0]  R1745     -2.9961192607879639e-01
    z[3,6,0]  R1746     6.1994470655918121e-02
    z[3,6,0]  R1747     -4.5045062899589539e-01
    z[3,6,0]  R1748     1.7669546604156494e-01
    z[3,6,0]  R1749     -1.9386282563209534e-01
    z[3,6,0]  R1750     -3.6804085969924927e-01
    z[3,6,0]  R1751     -6.8062943220138550e-01
    z[3,6,0]  R1752     -7.5242631137371063e-02
    z[3,6,0]  R1753     5.4270535707473755e-01
    z[3,6,0]  R1754     -0.60260409116745
    z[3,6,0]  R1755     -0.841519296169281
    z[3,6,0]  R1756     -3.3021429181098938e-01
    z[3,6,0]  R1757     -1.4445284008979797e-01
    z[3,6,0]  R1758     -5.0922536849975586e-01
    z[3,6,0]  R1759     1.6006837785243988e-01
    z[3,6,0]  R1760     -5.2107390947639942e-03
    z[3,6,0]  R1761     -1.9177805632352829e-02
    z[3,6,0]  R1762     5.3346121311187744e-01
    z[3,6,0]  R1763     4.2087772488594055e-01
    z[3,6,0]  R1764     4.9826869368553162e-01
    z[3,6,0]  R1765     5.3279006481170654e-01
    z[3,6,0]  R1766     6.5640980005264282e-01
    z[3,6,0]  R1767     3.3792454004287720e-01
    z[3,6,0]  R1768     5.7616049051284790e-01
    z[3,6,0]  R1769     5.8036917448043823e-01
    z[3,6,0]  R1770     -3.4743244759738445e-03
    z[3,6,0]  R1771     -1.2308333814144135e-01
    z[3,6,0]  R1772     -3.7155374884605408e-01
    z[3,6,0]  R1773     -5.4898804426193237e-01
    z[3,6,0]  R1774     -2.5332772731781006e-01
    z[3,6,0]  R1775     -6.1840850114822388e-01
    z[3,6,0]  R1776     -6.1318671703338623e-01
    z[3,6,0]  R1777     -3.2655423879623413e-01
    z[3,6,0]  R1778     -1.0422305762767792e-01
    z[3,6,0]  R1779     -6.5365648269653320e-01
    z[3,6,0]  R1780     -3.8282939791679382e-01
    z[3,6,0]  R1781     -1.6345612704753876e-01
    z[3,6,0]  R1782     3.2546854019165039e-01
    z[3,6,0]  R1783     -5.4201591014862061e-01
    z[3,6,0]  R1784     -2.6580983400344849e-01
    z[3,6,0]  R1785     -2.0024487376213074e-01
    z[3,6,0]  R1786     -5.1235926151275635e-01
    z[3,6,0]  R1787     -6.5226331353187561e-02
    z[3,6,0]  R1788     -1.7295217514038086e-01
    z[3,6,0]  R1789     -3.3874583244323730e-01
    z[3,6,1]  R30       -1
    z[3,6,1]  R57       1
    z[3,6,1]  R1718     -1
    z[3,6,1]  R1719     1
    z[3,6,1]  R1730     1.2658137083053589e-01
    z[3,6,1]  R1731     -4.0987440943717957e-01
    z[3,6,1]  R1732     -1.7743816599249840e-02
    z[3,6,1]  R1733     1.5095029026269913e-02
    z[3,6,1]  R1734     1.3860325515270233e-01
    z[3,6,1]  R1735     0.219833105802536
    z[3,6,1]  R1736     0.278201162815094
    z[3,6,1]  R1737     3.0335025861859322e-02
    z[3,6,1]  R1738     -6.4056468009948730e-01
    z[3,6,1]  R1739     -5.5411326885223389e-01
    z[3,6,1]  R1740     5.4294317960739136e-01
    z[3,6,1]  R1741     2.1319216489791870e-01
    z[3,6,1]  R1742     7.0009982585906982e-01
    z[3,6,1]  R1743     -1.4219549298286438e-01
    z[3,6,1]  R1744     4.1987210512161255e-01
    z[3,6,1]  R1745     -4.9000686407089233e-01
    z[3,6,1]  R1746     -2.4379158020019531e-01
    z[3,6,1]  R1747     -1.9936127960681915e-01
    z[3,6,1]  R1748     1.3906867243349552e-02
    z[3,6,1]  R1749     1.0930828005075455e-01
    z[3,6,1]  R1750     -3.1919276714324951e-01
    z[3,6,1]  R1751     -6.4516997337341309e-01
    z[3,6,1]  R1752     -4.2915329337120056e-01
    z[3,6,1]  R1753     2.8473719954490662e-01
    z[3,6,1]  R1754     -3.1105524301528931e-01
    z[3,6,1]  R1755     -2.6590937376022339e-01
    z[3,6,1]  R1756     -5.6255763769149780e-01
    z[3,6,1]  R1757     -3.5914209485054016e-01
    z[3,6,1]  R1758     1.9825773313641548e-02
    z[3,6,1]  R1759     -7.7108982950448990e-03
    z[3,6,1]  R1760     -0.463029146194458
    z[3,6,1]  R1761     4.5317122340202332e-01
    z[3,6,1]  R1762     -3.9997357130050659e-01
    z[3,6,1]  R1763     1.8852078914642334e-01
    z[3,6,1]  R1764     -3.9411702752113342e-01
    z[3,6,1]  R1765     2.3744247853755951e-01
    z[3,6,1]  R1766     2.1724076569080353e-01
    z[3,6,1]  R1767     -5.6819128990173340e-01
    z[3,6,1]  R1768     2.7435201406478882e-01
    z[3,6,1]  R1769     1.6648538410663605e-01
    z[3,6,1]  R1770     -6.7764058709144592e-02
    z[3,6,1]  R1771     8.5038393735885620e-02
    z[3,6,1]  R1772     -8.6744648218154907e-01
    z[3,6,1]  R1773     -7.4145448207855225e-01
    z[3,6,1]  R1774     -8.1563413143157959e-01
    z[3,6,1]  R1775     -5.2506881952285767e-01
    z[3,6,1]  R1776     -0.619130551815033
    z[3,6,1]  R1777     -6.3107943534851074e-01
    z[3,6,1]  R1778     -6.8970000743865967e-01
    z[3,6,1]  R1779     -4.0858045220375061e-01
    z[3,6,1]  R1780     2.7977058291435242e-01
    z[3,6,1]  R1781     -3.9654040336608887e-01
    z[3,6,1]  R1782     -5.4879948496818542e-02
    z[3,6,1]  R1783     -3.6780336499214172e-01
    z[3,6,1]  R1784     5.1064151525497437e-01
    z[3,6,1]  R1785     0.16551573574543
    z[3,6,1]  R1786     1.3627509772777557e-01
    z[3,6,1]  R1787     7.3188805580139160e-01
    z[3,6,1]  R1788     6.3836479187011719e-01
    z[3,6,1]  R1789     -9.5175787806510925e-02
    z[3,6,2]  R31       -1
    z[3,6,2]  R58       1
    z[3,6,2]  R1720     -1
    z[3,6,2]  R1721     1
    z[3,6,2]  R1730     6.9000810384750366e-01
    z[3,6,2]  R1731     0.210184246301651
    z[3,6,2]  R1732     1.1719269305467606e-01
    z[3,6,2]  R1733     6.9620794057846069e-01
    z[3,6,2]  R1734     3.2710447907447815e-01
    z[3,6,2]  R1735     5.0952249765396118e-01
    z[3,6,2]  R1736     7.6343074440956116e-02
    z[3,6,2]  R1737     6.8611919879913330e-01
    z[3,6,2]  R1738     1.4378747344017029e-01
    z[3,6,2]  R1739     -0.062874436378479
    z[3,6,2]  R1740     -2.8643596172332764e-01
    z[3,6,2]  R1741     -6.5241509675979614e-01
    z[3,6,2]  R1742     -1.8200229108333588e-01
    z[3,6,2]  R1743     -2.4465499818325043e-01
    z[3,6,2]  R1744     -2.4278061091899872e-01
    z[3,6,2]  R1745     -5.4686951637268066e-01
    z[3,6,2]  R1746     1.7173700034618378e-02
    z[3,6,2]  R1747     -7.0712512731552124e-01
    z[3,6,2]  R1748     -6.5931832790374756e-01
    z[3,6,2]  R1749     -4.0237104892730713e-01
    z[3,6,2]  R1750     -3.7199565768241882e-01
    z[3,6,2]  R1751     -1.3697220385074615e-01
    z[3,6,2]  R1752     -7.1549135446548462e-01
    z[3,6,2]  R1753     -1.8416188657283783e-01
    z[3,6,2]  R1754     -4.1858857870101929e-01
    z[3,6,2]  R1755     1.5182051062583923e-01
    z[3,6,2]  R1756     -3.4829905629158020e-01
    z[3,6,2]  R1757     -5.8139652013778687e-01
    z[3,6,2]  R1758     1.2566743791103363e-01
    z[3,6,2]  R1759     -0.649156391620636
    z[3,6,2]  R1760     2.5370424985885620e-01
    z[3,6,2]  R1761     4.7708079218864441e-01
    z[3,6,2]  R1762     4.5294904708862305e-01
    z[3,6,2]  R1763     7.5022113323211670e-01
    z[3,6,2]  R1764     5.1763975620269775e-01
    z[3,6,2]  R1765     7.3303419351577759e-01
    z[3,6,2]  R1766     0.573716402053833
    z[3,6,2]  R1767     6.5565681457519531e-01
    z[3,6,2]  R1768     7.1206021308898926e-01
    z[3,6,2]  R1769     4.1576743125915527e-01
    z[3,6,2]  R1770     -0.636843204498291
    z[3,6,2]  R1771     -3.6151629686355591e-01
    z[3,6,2]  R1772     -1.4550860226154327e-01
    z[3,6,2]  R1773     -1.5195912122726440e-01
    z[3,6,2]  R1774     -2.5232285261154175e-01
    z[3,6,2]  R1775     -3.3051258325576782e-01
    z[3,6,2]  R1776     -3.2100066542625427e-01
    z[3,6,2]  R1777     -3.0456984043121338e-01
    z[3,6,2]  R1778     -5.4235816001892090e-01
    z[3,6,2]  R1779     -2.3770385980606079e-01
    z[3,6,2]  R1780     3.0719444155693054e-01
    z[3,6,2]  R1781     2.6448589563369751e-01
    z[3,6,2]  R1782     4.0804558992385864e-01
    z[3,6,2]  R1783     -4.6224242448806763e-01
    z[3,6,2]  R1784     3.7779358029365540e-01
    z[3,6,2]  R1785     2.1731008589267731e-01
    z[3,6,2]  R1786     -2.8794929385185242e-01
    z[3,6,2]  R1787     -3.4672487527132034e-02
    z[3,6,2]  R1788     2.6825872063636780e-01
    z[3,6,2]  R1789     6.0277175903320312e-01
    z[3,6,3]  R32       -1
    z[3,6,3]  R59       1
    z[3,6,3]  R1722     -1
    z[3,6,3]  R1723     1
    z[3,6,3]  R1730     1.3518603146076202e-01
    z[3,6,3]  R1731     -6.0827100276947021e-01
    z[3,6,3]  R1732     -4.3505945801734924e-01
    z[3,6,3]  R1733     -1.0539470240473747e-02
    z[3,6,3]  R1734     -6.3690222799777985e-02
    z[3,6,3]  R1735     -4.0693020820617676e-01
    z[3,6,3]  R1736     -2.1456105634570122e-02
    z[3,6,3]  R1737     -4.7923552989959717e-01
    z[3,6,3]  R1738     -3.9578646421432495e-02
    z[3,6,3]  R1739     -3.6662086844444275e-01
    z[3,6,3]  R1740     3.9195086807012558e-02
    z[3,6,3]  R1741     4.0870717167854309e-01
    z[3,6,3]  R1742     1.4911645650863647e-01
    z[3,6,3]  R1743     -0.0082710487768054
    z[3,6,3]  R1744     1.2566968798637390e-01
    z[3,6,3]  R1745     -7.5368061661720276e-03
    z[3,6,3]  R1746     2.3450877051800489e-03
    z[3,6,3]  R1747     -1.7732071876525879e-01
    z[3,6,3]  R1748     -5.8723551034927368e-01
    z[3,6,3]  R1749     -6.1758917570114136e-01
    z[3,6,3]  R1750     -1.6537846624851227e-01
    z[3,6,3]  R1751     -1.5702915191650391e-01
    z[3,6,3]  R1752     -1.2456391006708145e-01
    z[3,6,3]  R1753     2.1796748042106628e-01
    z[3,6,3]  R1754     -3.2868149876594543e-01
    z[3,6,3]  R1755     -2.8656652569770813e-01
    z[3,6,3]  R1756     -3.3567818999290466e-01
    z[3,6,3]  R1757     -6.9308197498321533e-01
    z[3,6,3]  R1758     1.7923320829868317e-01
    z[3,6,3]  R1759     -4.1287642717361450e-01
    z[3,6,3]  R1760     -1.2812557816505432e-01
    z[3,6,3]  R1761     2.7356836199760437e-01
    z[3,6,3]  R1762     -5.2921187877655029e-01
    z[3,6,3]  R1763     -3.3385384082794189e-01
    z[3,6,3]  R1764     -5.3937900066375732e-01
    z[3,6,3]  R1765     -3.0621933937072754e-01
    z[3,6,3]  R1766     -2.3727174103260040e-01
    z[3,6,3]  R1767     -3.6090376973152161e-01
    z[3,6,3]  R1768     -0.038233682513237
    z[3,6,3]  R1769     -6.1332726478576660e-01
    z[3,6,3]  R1770     3.4797564148902893e-01
    z[3,6,3]  R1771     5.8470505475997925e-01
    z[3,6,3]  R1772     2.4236537516117096e-01
    z[3,6,3]  R1773     2.3465169966220856e-01
    z[3,6,3]  R1774     2.1231047809123993e-01
    z[3,6,3]  R1775     -0.346811443567276
    z[3,6,3]  R1776     -1.6981753706932068e-01
    z[3,6,3]  R1777     -2.0098647475242615e-01
    z[3,6,3]  R1778     -1.9764246046543121e-01
    z[3,6,3]  R1779     -1.8382544815540314e-01
    z[3,6,3]  R1780     3.5857412964105606e-02
    z[3,6,3]  R1781     0.81771320104599
    z[3,6,3]  R1782     3.8813319802284241e-01
    z[3,6,3]  R1783     -1.8799242377281189e-01
    z[3,6,3]  R1784     -3.0278982594609261e-02
    z[3,6,3]  R1785     -5.5477118492126465e-01
    z[3,6,3]  R1786     -4.2916965484619141e-01
    z[3,6,3]  R1787     -3.5344421863555908e-01
    z[3,6,3]  R1788     -5.6654590368270874e-01
    z[3,6,3]  R1789     -2.5631973147392273e-01
    z[3,6,4]  R33       -1
    z[3,6,4]  R60       1
    z[3,6,4]  R1724     -1
    z[3,6,4]  R1725     1
    z[3,6,4]  R1730     -4.0334054827690125e-01
    z[3,6,4]  R1731     3.4928798675537109e-01
    z[3,6,4]  R1732     3.3656361699104309e-01
    z[3,6,4]  R1733     1.7802956700325012e-01
    z[3,6,4]  R1734     2.6296606659889221e-01
    z[3,6,4]  R1735     -3.5195663571357727e-02
    z[3,6,4]  R1736     2.0981298387050629e-01
    z[3,6,4]  R1737     -2.1187800168991089e-01
    z[3,6,4]  R1738     1.7886583507061005e-01
    z[3,6,4]  R1739     -1.1789031559601426e-03
    z[3,6,4]  R1740     -0.558672308921814
    z[3,6,4]  R1741     -1.1019662767648697e-01
    z[3,6,4]  R1742     -5.5909123271703720e-02
    z[3,6,4]  R1743     -9.2242914438247681e-01
    z[3,6,4]  R1744     5.5569779872894287e-01
    z[3,6,4]  R1745     4.8192042112350464e-01
    z[3,6,4]  R1746     -5.4806423187255859e-01
    z[3,6,4]  R1747     3.2528510689735413e-01
    z[3,6,4]  R1748     1.6369768977165222e-01
    z[3,6,4]  R1749     -3.7840676307678223e-01
    z[3,6,4]  R1750     1.8910128623247147e-02
    z[3,6,4]  R1751     -2.6657721027731895e-02
    z[3,6,4]  R1752     4.0477478504180908e-01
    z[3,6,4]  R1753     5.5097335577011108e-01
    z[3,6,4]  R1754     0.349839985370636
    z[3,6,4]  R1755     -2.0136989653110504e-01
    z[3,6,4]  R1756     4.9555456638336182e-01
    z[3,6,4]  R1757     -1.2139406055212021e-01
    z[3,6,4]  R1758     4.4311735033988953e-01
    z[3,6,4]  R1759     1.1949014663696289e-01
    z[3,6,4]  R1760     -8.3284348249435425e-01
    z[3,6,4]  R1761     -6.0675281286239624e-01
    z[3,6,4]  R1762     1.7943026125431061e-01
    z[3,6,4]  R1763     2.1165351569652557e-01
    z[3,6,4]  R1764     5.3122036159038544e-02
    z[3,6,4]  R1765     -2.7994986623525620e-02
    z[3,6,4]  R1766     6.0909830033779144e-02
    z[3,6,4]  R1767     2.0996691659092903e-02
    z[3,6,4]  R1768     2.4418279528617859e-01
    z[3,6,4]  R1769     1.3282354176044464e-01
    z[3,6,4]  R1770     -5.0129914283752441e-01
    z[3,6,4]  R1771     -4.1763642430305481e-01
    z[3,6,4]  R1772     1.1798995733261108e-01
    z[3,6,4]  R1773     -4.7457154840230942e-02
    z[3,6,4]  R1774     2.4797822535037994e-01
    z[3,6,4]  R1775     -3.3877289388328791e-03
    z[3,6,4]  R1776     2.5931772589683533e-01
    z[3,6,4]  R1777     -2.3311829194426537e-02
    z[3,6,4]  R1778     3.4339752048254013e-02
    z[3,6,4]  R1779     -1.6188608109951019e-01
    z[3,6,4]  R1780     -5.6225913763046265e-01
    z[3,6,4]  R1781     -1.6311031579971313e-01
    z[3,6,4]  R1782     -1.6476285457611084e-01
    z[3,6,4]  R1783     7.8983316197991371e-03
    z[3,6,4]  R1784     0.668416440486908
    z[3,6,4]  R1785     6.7164522409439087e-01
    z[3,6,4]  R1786     -1.8812704086303711e-01
    z[3,6,4]  R1787     5.6265187263488770e-01
    z[3,6,4]  R1788     1.8205238878726959e-01
    z[3,6,4]  R1789     6.6807526350021362e-01
    z[3,6,5]  R34       -1
    z[3,6,5]  R61       1
    z[3,6,5]  R1726     -1
    z[3,6,5]  R1727     1
    z[3,6,5]  R1730     -3.3380375243723392e-03
    z[3,6,5]  R1731     -4.9794283509254456e-01
    z[3,6,5]  R1732     2.7872281149029732e-02
    z[3,6,5]  R1733     -5.2084422111511230e-01
    z[3,6,5]  R1734     5.1263108849525452e-02
    z[3,6,5]  R1735     -2.9249009490013123e-01
    z[3,6,5]  R1736     -5.3765302896499634e-01
    z[3,6,5]  R1737     -3.2040674239397049e-02
    z[3,6,5]  R1738     -3.8281852006912231e-01
    z[3,6,5]  R1739     -0.539277970790863
    z[3,6,5]  R1740     2.6998212933540344e-01
    z[3,6,5]  R1741     1.4770534634590149e-01
    z[3,6,5]  R1742     1.8912889063358307e-01
    z[3,6,5]  R1743     0.0660073533654213
    z[3,6,5]  R1744     3.3002045750617981e-01
    z[3,6,5]  R1745     3.6354464292526245e-01
    z[3,6,5]  R1746     5.6534707546234131e-01
    z[3,6,5]  R1747     4.8115104436874390e-03
    z[3,6,5]  R1748     7.7572362497448921e-03
    z[3,6,5]  R1749     -1.5721473097801208e-01
    z[3,6,5]  R1750     -7.6816070079803467e-01
    z[3,6,5]  R1751     -1.1064589023590088e-01
    z[3,6,5]  R1752     -3.1259015202522278e-01
    z[3,6,5]  R1753     4.6183642745018005e-01
    z[3,6,5]  R1754     9.8798334598541260e-02
    z[3,6,5]  R1755     -0.185917928814888
    z[3,6,5]  R1756     0.307997465133667
    z[3,6,5]  R1757     3.8070093840360641e-02
    z[3,6,5]  R1758     -6.6336655616760254e-01
    z[3,6,5]  R1759     -5.6838154792785645e-01
    z[3,6,5]  R1760     5.0700742751359940e-02
    z[3,6,5]  R1761     -3.4988054633140564e-01
    z[3,6,5]  R1762     1.7902784049510956e-02
    z[3,6,5]  R1763     8.9013829827308655e-02
    z[3,6,5]  R1764     -0.0491558238863945
    z[3,6,5]  R1765     -1.6641260683536530e-01
    z[3,6,5]  R1766     1.7898994684219360e-01
    z[3,6,5]  R1767     -2.2681452333927155e-02
    z[3,6,5]  R1768     -2.3320766165852547e-02
    z[3,6,5]  R1769     -9.5537595450878143e-02
    z[3,6,5]  R1770     2.3141373693943024e-01
    z[3,6,5]  R1771     2.0014445483684540e-01
    z[3,6,5]  R1772     -7.4222333729267120e-02
    z[3,6,5]  R1773     -2.4428756535053253e-01
    z[3,6,5]  R1774     3.1565821170806885e-01
    z[3,6,5]  R1775     -1.4559094607830048e-01
    z[3,6,5]  R1776     -2.0341484248638153e-01
    z[3,6,5]  R1777     -4.9272051453590393e-01
    z[3,6,5]  R1778     -1.6252711415290833e-01
    z[3,6,5]  R1779     -5.1126211881637573e-01
    z[3,6,5]  R1780     5.9974884986877441e-01
    z[3,6,5]  R1781     -2.2125542163848877e-01
    z[3,6,5]  R1782     0.613357663154602
    z[3,6,5]  R1783     -5.4441195726394653e-01
    z[3,6,5]  R1784     2.1309484541416168e-01
    z[3,6,5]  R1785     3.2975459098815918e-01
    z[3,6,5]  R1786     -6.3749986886978149e-01
    z[3,6,5]  R1787     1.3013105094432831e-01
    z[3,6,5]  R1788     2.2970614954829216e-02
    z[3,6,5]  R1789     2.0947758108377457e-02
    z[3,6,6]  R35       -1
    z[3,6,6]  R62       1
    z[3,6,6]  R1728     -1
    z[3,6,6]  R1729     1
    z[3,6,6]  R1730     1.0549000650644302e-01
    z[3,6,6]  R1731     4.4506066478788853e-03
    z[3,6,6]  R1732     -1.3924518227577209e-01
    z[3,6,6]  R1733     -1.4651606976985931e-01
    z[3,6,6]  R1734     -2.4712134897708893e-01
    z[3,6,6]  R1735     -3.5546213388442993e-02
    z[3,6,6]  R1736     -1.0249412804841995e-01
    z[3,6,6]  R1737     -1.7948724329471588e-01
    z[3,6,6]  R1738     -5.9537172317504883e-01
    z[3,6,6]  R1739     -5.0708043575286865e-01
    z[3,6,6]  R1740     0.264161080121994
    z[3,6,6]  R1741     -1.7609673738479614e-01
    z[3,6,6]  R1742     6.0599303245544434e-01
    z[3,6,6]  R1743     -5.4570611566305161e-02
    z[3,6,6]  R1744     4.6261945366859436e-01
    z[3,6,6]  R1745     -0.081184022128582
    z[3,6,6]  R1746     5.6252133846282959e-01
    z[3,6,6]  R1747     3.4647822380065918e-01
    z[3,6,6]  R1748     4.0271830558776855e-01
    z[3,6,6]  R1749     4.8912355303764343e-01
    z[3,6,6]  R1750     -8.0639824271202087e-02
    z[3,6,6]  R1751     -2.5323250889778137e-01
    z[3,6,6]  R1752     -1.4548771083354950e-01
    z[3,6,6]  R1753     1.6157284379005432e-01
    z[3,6,6]  R1754     3.5315132141113281e-01
    z[3,6,6]  R1755     2.0211941003799438e-01
    z[3,6,6]  R1756     -7.6526342891156673e-03
    z[3,6,6]  R1757     0.124819315969944
    z[3,6,6]  R1758     2.3658286035060883e-01
    z[3,6,6]  R1759     2.1239617466926575e-01
    z[3,6,6]  R1760     -9.2715196311473846e-02
    z[3,6,6]  R1761     -3.5453815013170242e-02
    z[3,6,6]  R1762     -1.9415597617626190e-01
    z[3,6,6]  R1763     2.4558302760124207e-01
    z[3,6,6]  R1764     1.7966997623443604e-01
    z[3,6,6]  R1765     -1.3015929609537125e-02
    z[3,6,6]  R1766     -3.1739047169685364e-01
    z[3,6,6]  R1767     -4.3279886245727539e-02
    z[3,6,6]  R1768     -0.155271977186203
    z[3,6,6]  R1769     -2.4423734843730927e-01
    z[3,6,6]  R1770     4.0482887625694275e-01
    z[3,6,6]  R1771     -5.3904253244400024e-01
    z[3,6,6]  R1772     -1.0069804638624191e-01
    z[3,6,6]  R1773     9.3679733574390411e-02
    z[3,6,6]  R1774     2.6271790266036987e-02
    z[3,6,6]  R1775     0.301908403635025
    z[3,6,6]  R1776     -1.3290268369019032e-02
    z[3,6,6]  R1777     -3.4442096948623657e-01
    z[3,6,6]  R1778     -3.9069458842277527e-01
    z[3,6,6]  R1779     1.6704581677913666e-01
    z[3,6,6]  R1780     6.0678459703922272e-02
    z[3,6,6]  R1781     -4.3259564787149429e-02
    z[3,6,6]  R1782     4.1298347711563110e-01
    z[3,6,6]  R1783     -1.5963518619537354e-01
    z[3,6,6]  R1784     1.8098542094230652e-01
    z[3,6,6]  R1785     1.3291537761688232e-01
    z[3,6,6]  R1786     1.0008950531482697e-01
    z[3,6,6]  R1787     -2.1194621920585632e-02
    z[3,6,6]  R1788     3.6874154210090637e-01
    z[3,6,6]  R1789     -1.9895978271961212e-02
    z[6,3,0]  R29       1
    z[6,3,0]  R56       -1
    z[6,3,0]  R1790     -1
    z[6,3,0]  R1791     1
    z[6,3,0]  R1804     -5.2107390947639942e-03
    z[6,3,0]  R1805     -1.9177805632352829e-02
    z[6,3,0]  R1806     5.3346121311187744e-01
    z[6,3,0]  R1807     4.2087772488594055e-01
    z[6,3,0]  R1808     4.9826869368553162e-01
    z[6,3,0]  R1809     5.3279006481170654e-01
    z[6,3,0]  R1810     6.5640980005264282e-01
    z[6,3,0]  R1811     3.3792454004287720e-01
    z[6,3,0]  R1812     5.7616049051284790e-01
    z[6,3,0]  R1813     5.8036917448043823e-01
    z[6,3,0]  R1814     -3.4743244759738445e-03
    z[6,3,0]  R1815     -1.2308333814144135e-01
    z[6,3,0]  R1816     -3.7155374884605408e-01
    z[6,3,0]  R1817     -5.4898804426193237e-01
    z[6,3,0]  R1818     -2.5332772731781006e-01
    z[6,3,0]  R1819     -6.1840850114822388e-01
    z[6,3,0]  R1820     -6.1318671703338623e-01
    z[6,3,0]  R1821     -3.2655423879623413e-01
    z[6,3,0]  R1822     -1.0422305762767792e-01
    z[6,3,0]  R1823     -6.5365648269653320e-01
    z[6,3,0]  R1824     -3.8282939791679382e-01
    z[6,3,0]  R1825     -1.6345612704753876e-01
    z[6,3,0]  R1826     3.2546854019165039e-01
    z[6,3,0]  R1827     -5.4201591014862061e-01
    z[6,3,0]  R1828     -2.6580983400344849e-01
    z[6,3,0]  R1829     -2.0024487376213074e-01
    z[6,3,0]  R1830     -5.1235926151275635e-01
    z[6,3,0]  R1831     -6.5226331353187561e-02
    z[6,3,0]  R1832     -1.7295217514038086e-01
    z[6,3,0]  R1833     -3.3874583244323730e-01
    z[6,3,0]  R1834     -5.6193226575851440e-01
    z[6,3,0]  R1835     -2.1877616643905640e-01
    z[6,3,0]  R1836     8.1439119577407837e-01
    z[6,3,0]  R1837     -4.3648043274879456e-01
    z[6,3,0]  R1838     8.5842144489288330e-01
    z[6,3,0]  R1839     6.6212922334671021e-01
    z[6,3,0]  R1840     7.5678145885467529e-01
    z[6,3,0]  R1841     -4.6959450840950012e-01
    z[6,3,0]  R1842     -1.8554012477397919e-01
    z[6,3,0]  R1843     8.1496782600879669e-02
    z[6,3,0]  R1844     4.0846642851829529e-01
    z[6,3,0]  R1845     5.4487776756286621e-01
    z[6,3,0]  R1846     2.1994680166244507e-01
    z[6,3,0]  R1847     2.4828505516052246e-01
    z[6,3,0]  R1848     3.4240600466728210e-01
    z[6,3,0]  R1849     -2.9961192607879639e-01
    z[6,3,0]  R1850     6.1994470655918121e-02
    z[6,3,0]  R1851     -4.5045062899589539e-01
    z[6,3,0]  R1852     1.7669546604156494e-01
    z[6,3,0]  R1853     -1.9386282563209534e-01
    z[6,3,0]  R1854     -3.6804085969924927e-01
    z[6,3,0]  R1855     -6.8062943220138550e-01
    z[6,3,0]  R1856     -7.5242631137371063e-02
    z[6,3,0]  R1857     5.4270535707473755e-01
    z[6,3,0]  R1858     -0.60260409116745
    z[6,3,0]  R1859     -0.841519296169281
    z[6,3,0]  R1860     -3.3021429181098938e-01
    z[6,3,0]  R1861     -1.4445284008979797e-01
    z[6,3,0]  R1862     -5.0922536849975586e-01
    z[6,3,0]  R1863     1.6006837785243988e-01
    z[6,3,1]  R30       1
    z[6,3,1]  R57       -1
    z[6,3,1]  R1792     -1
    z[6,3,1]  R1793     1
    z[6,3,1]  R1804     -0.463029146194458
    z[6,3,1]  R1805     4.5317122340202332e-01
    z[6,3,1]  R1806     -3.9997357130050659e-01
    z[6,3,1]  R1807     1.8852078914642334e-01
    z[6,3,1]  R1808     -3.9411702752113342e-01
    z[6,3,1]  R1809     2.3744247853755951e-01
    z[6,3,1]  R1810     2.1724076569080353e-01
    z[6,3,1]  R1811     -5.6819128990173340e-01
    z[6,3,1]  R1812     2.7435201406478882e-01
    z[6,3,1]  R1813     1.6648538410663605e-01
    z[6,3,1]  R1814     -6.7764058709144592e-02
    z[6,3,1]  R1815     8.5038393735885620e-02
    z[6,3,1]  R1816     -8.6744648218154907e-01
    z[6,3,1]  R1817     -7.4145448207855225e-01
    z[6,3,1]  R1818     -8.1563413143157959e-01
    z[6,3,1]  R1819     -5.2506881952285767e-01
    z[6,3,1]  R1820     -0.619130551815033
    z[6,3,1]  R1821     -6.3107943534851074e-01
    z[6,3,1]  R1822     -6.8970000743865967e-01
    z[6,3,1]  R1823     -4.0858045220375061e-01
    z[6,3,1]  R1824     2.7977058291435242e-01
    z[6,3,1]  R1825     -3.9654040336608887e-01
    z[6,3,1]  R1826     -5.4879948496818542e-02
    z[6,3,1]  R1827     -3.6780336499214172e-01
    z[6,3,1]  R1828     5.1064151525497437e-01
    z[6,3,1]  R1829     0.16551573574543
    z[6,3,1]  R1830     1.3627509772777557e-01
    z[6,3,1]  R1831     7.3188805580139160e-01
    z[6,3,1]  R1832     6.3836479187011719e-01
    z[6,3,1]  R1833     -9.5175787806510925e-02
    z[6,3,1]  R1834     1.2658137083053589e-01
    z[6,3,1]  R1835     -4.0987440943717957e-01
    z[6,3,1]  R1836     -1.7743816599249840e-02
    z[6,3,1]  R1837     1.5095029026269913e-02
    z[6,3,1]  R1838     1.3860325515270233e-01
    z[6,3,1]  R1839     0.219833105802536
    z[6,3,1]  R1840     0.278201162815094
    z[6,3,1]  R1841     3.0335025861859322e-02
    z[6,3,1]  R1842     -6.4056468009948730e-01
    z[6,3,1]  R1843     -5.5411326885223389e-01
    z[6,3,1]  R1844     5.4294317960739136e-01
    z[6,3,1]  R1845     2.1319216489791870e-01
    z[6,3,1]  R1846     7.0009982585906982e-01
    z[6,3,1]  R1847     -1.4219549298286438e-01
    z[6,3,1]  R1848     4.1987210512161255e-01
    z[6,3,1]  R1849     -4.9000686407089233e-01
    z[6,3,1]  R1850     -2.4379158020019531e-01
    z[6,3,1]  R1851     -1.9936127960681915e-01
    z[6,3,1]  R1852     1.3906867243349552e-02
    z[6,3,1]  R1853     1.0930828005075455e-01
    z[6,3,1]  R1854     -3.1919276714324951e-01
    z[6,3,1]  R1855     -6.4516997337341309e-01
    z[6,3,1]  R1856     -4.2915329337120056e-01
    z[6,3,1]  R1857     2.8473719954490662e-01
    z[6,3,1]  R1858     -3.1105524301528931e-01
    z[6,3,1]  R1859     -2.6590937376022339e-01
    z[6,3,1]  R1860     -5.6255763769149780e-01
    z[6,3,1]  R1861     -3.5914209485054016e-01
    z[6,3,1]  R1862     1.9825773313641548e-02
    z[6,3,1]  R1863     -7.7108982950448990e-03
    z[6,3,2]  R31       1
    z[6,3,2]  R58       -1
    z[6,3,2]  R1794     -1
    z[6,3,2]  R1795     1
    z[6,3,2]  R1804     2.5370424985885620e-01
    z[6,3,2]  R1805     4.7708079218864441e-01
    z[6,3,2]  R1806     4.5294904708862305e-01
    z[6,3,2]  R1807     7.5022113323211670e-01
    z[6,3,2]  R1808     5.1763975620269775e-01
    z[6,3,2]  R1809     7.3303419351577759e-01
    z[6,3,2]  R1810     0.573716402053833
    z[6,3,2]  R1811     6.5565681457519531e-01
    z[6,3,2]  R1812     7.1206021308898926e-01
    z[6,3,2]  R1813     4.1576743125915527e-01
    z[6,3,2]  R1814     -0.636843204498291
    z[6,3,2]  R1815     -3.6151629686355591e-01
    z[6,3,2]  R1816     -1.4550860226154327e-01
    z[6,3,2]  R1817     -1.5195912122726440e-01
    z[6,3,2]  R1818     -2.5232285261154175e-01
    z[6,3,2]  R1819     -3.3051258325576782e-01
    z[6,3,2]  R1820     -3.2100066542625427e-01
    z[6,3,2]  R1821     -3.0456984043121338e-01
    z[6,3,2]  R1822     -5.4235816001892090e-01
    z[6,3,2]  R1823     -2.3770385980606079e-01
    z[6,3,2]  R1824     3.0719444155693054e-01
    z[6,3,2]  R1825     2.6448589563369751e-01
    z[6,3,2]  R1826     4.0804558992385864e-01
    z[6,3,2]  R1827     -4.6224242448806763e-01
    z[6,3,2]  R1828     3.7779358029365540e-01
    z[6,3,2]  R1829     2.1731008589267731e-01
    z[6,3,2]  R1830     -2.8794929385185242e-01
    z[6,3,2]  R1831     -3.4672487527132034e-02
    z[6,3,2]  R1832     2.6825872063636780e-01
    z[6,3,2]  R1833     6.0277175903320312e-01
    z[6,3,2]  R1834     6.9000810384750366e-01
    z[6,3,2]  R1835     0.210184246301651
    z[6,3,2]  R1836     1.1719269305467606e-01
    z[6,3,2]  R1837     6.9620794057846069e-01
    z[6,3,2]  R1838     3.2710447907447815e-01
    z[6,3,2]  R1839     5.0952249765396118e-01
    z[6,3,2]  R1840     7.6343074440956116e-02
    z[6,3,2]  R1841     6.8611919879913330e-01
    z[6,3,2]  R1842     1.4378747344017029e-01
    z[6,3,2]  R1843     -0.062874436378479
    z[6,3,2]  R1844     -2.8643596172332764e-01
    z[6,3,2]  R1845     -6.5241509675979614e-01
    z[6,3,2]  R1846     -1.8200229108333588e-01
    z[6,3,2]  R1847     -2.4465499818325043e-01
    z[6,3,2]  R1848     -2.4278061091899872e-01
    z[6,3,2]  R1849     -5.4686951637268066e-01
    z[6,3,2]  R1850     1.7173700034618378e-02
    z[6,3,2]  R1851     -7.0712512731552124e-01
    z[6,3,2]  R1852     -6.5931832790374756e-01
    z[6,3,2]  R1853     -4.0237104892730713e-01
    z[6,3,2]  R1854     -3.7199565768241882e-01
    z[6,3,2]  R1855     -1.3697220385074615e-01
    z[6,3,2]  R1856     -7.1549135446548462e-01
    z[6,3,2]  R1857     -1.8416188657283783e-01
    z[6,3,2]  R1858     -4.1858857870101929e-01
    z[6,3,2]  R1859     1.5182051062583923e-01
    z[6,3,2]  R1860     -3.4829905629158020e-01
    z[6,3,2]  R1861     -5.8139652013778687e-01
    z[6,3,2]  R1862     1.2566743791103363e-01
    z[6,3,2]  R1863     -0.649156391620636
    z[6,3,3]  R32       1
    z[6,3,3]  R59       -1
    z[6,3,3]  R1796     -1
    z[6,3,3]  R1797     1
    z[6,3,3]  R1804     -1.2812557816505432e-01
    z[6,3,3]  R1805     2.7356836199760437e-01
    z[6,3,3]  R1806     -5.2921187877655029e-01
    z[6,3,3]  R1807     -3.3385384082794189e-01
    z[6,3,3]  R1808     -5.3937900066375732e-01
    z[6,3,3]  R1809     -3.0621933937072754e-01
    z[6,3,3]  R1810     -2.3727174103260040e-01
    z[6,3,3]  R1811     -3.6090376973152161e-01
    z[6,3,3]  R1812     -0.038233682513237
    z[6,3,3]  R1813     -6.1332726478576660e-01
    z[6,3,3]  R1814     3.4797564148902893e-01
    z[6,3,3]  R1815     5.8470505475997925e-01
    z[6,3,3]  R1816     2.4236537516117096e-01
    z[6,3,3]  R1817     2.3465169966220856e-01
    z[6,3,3]  R1818     2.1231047809123993e-01
    z[6,3,3]  R1819     -0.346811443567276
    z[6,3,3]  R1820     -1.6981753706932068e-01
    z[6,3,3]  R1821     -2.0098647475242615e-01
    z[6,3,3]  R1822     -1.9764246046543121e-01
    z[6,3,3]  R1823     -1.8382544815540314e-01
    z[6,3,3]  R1824     3.5857412964105606e-02
    z[6,3,3]  R1825     0.81771320104599
    z[6,3,3]  R1826     3.8813319802284241e-01
    z[6,3,3]  R1827     -1.8799242377281189e-01
    z[6,3,3]  R1828     -3.0278982594609261e-02
    z[6,3,3]  R1829     -5.5477118492126465e-01
    z[6,3,3]  R1830     -4.2916965484619141e-01
    z[6,3,3]  R1831     -3.5344421863555908e-01
    z[6,3,3]  R1832     -5.6654590368270874e-01
    z[6,3,3]  R1833     -2.5631973147392273e-01
    z[6,3,3]  R1834     1.3518603146076202e-01
    z[6,3,3]  R1835     -6.0827100276947021e-01
    z[6,3,3]  R1836     -4.3505945801734924e-01
    z[6,3,3]  R1837     -1.0539470240473747e-02
    z[6,3,3]  R1838     -6.3690222799777985e-02
    z[6,3,3]  R1839     -4.0693020820617676e-01
    z[6,3,3]  R1840     -2.1456105634570122e-02
    z[6,3,3]  R1841     -4.7923552989959717e-01
    z[6,3,3]  R1842     -3.9578646421432495e-02
    z[6,3,3]  R1843     -3.6662086844444275e-01
    z[6,3,3]  R1844     3.9195086807012558e-02
    z[6,3,3]  R1845     4.0870717167854309e-01
    z[6,3,3]  R1846     1.4911645650863647e-01
    z[6,3,3]  R1847     -0.0082710487768054
    z[6,3,3]  R1848     1.2566968798637390e-01
    z[6,3,3]  R1849     -7.5368061661720276e-03
    z[6,3,3]  R1850     2.3450877051800489e-03
    z[6,3,3]  R1851     -1.7732071876525879e-01
    z[6,3,3]  R1852     -5.8723551034927368e-01
    z[6,3,3]  R1853     -6.1758917570114136e-01
    z[6,3,3]  R1854     -1.6537846624851227e-01
    z[6,3,3]  R1855     -1.5702915191650391e-01
    z[6,3,3]  R1856     -1.2456391006708145e-01
    z[6,3,3]  R1857     2.1796748042106628e-01
    z[6,3,3]  R1858     -3.2868149876594543e-01
    z[6,3,3]  R1859     -2.8656652569770813e-01
    z[6,3,3]  R1860     -3.3567818999290466e-01
    z[6,3,3]  R1861     -6.9308197498321533e-01
    z[6,3,3]  R1862     1.7923320829868317e-01
    z[6,3,3]  R1863     -4.1287642717361450e-01
    z[6,3,4]  R33       1
    z[6,3,4]  R60       -1
    z[6,3,4]  R1798     -1
    z[6,3,4]  R1799     1
    z[6,3,4]  R1804     -8.3284348249435425e-01
    z[6,3,4]  R1805     -6.0675281286239624e-01
    z[6,3,4]  R1806     1.7943026125431061e-01
    z[6,3,4]  R1807     2.1165351569652557e-01
    z[6,3,4]  R1808     5.3122036159038544e-02
    z[6,3,4]  R1809     -2.7994986623525620e-02
    z[6,3,4]  R1810     6.0909830033779144e-02
    z[6,3,4]  R1811     2.0996691659092903e-02
    z[6,3,4]  R1812     2.4418279528617859e-01
    z[6,3,4]  R1813     1.3282354176044464e-01
    z[6,3,4]  R1814     -5.0129914283752441e-01
    z[6,3,4]  R1815     -4.1763642430305481e-01
    z[6,3,4]  R1816     1.1798995733261108e-01
    z[6,3,4]  R1817     -4.7457154840230942e-02
    z[6,3,4]  R1818     2.4797822535037994e-01
    z[6,3,4]  R1819     -3.3877289388328791e-03
    z[6,3,4]  R1820     2.5931772589683533e-01
    z[6,3,4]  R1821     -2.3311829194426537e-02
    z[6,3,4]  R1822     3.4339752048254013e-02
    z[6,3,4]  R1823     -1.6188608109951019e-01
    z[6,3,4]  R1824     -5.6225913763046265e-01
    z[6,3,4]  R1825     -1.6311031579971313e-01
    z[6,3,4]  R1826     -1.6476285457611084e-01
    z[6,3,4]  R1827     7.8983316197991371e-03
    z[6,3,4]  R1828     0.668416440486908
    z[6,3,4]  R1829     6.7164522409439087e-01
    z[6,3,4]  R1830     -1.8812704086303711e-01
    z[6,3,4]  R1831     5.6265187263488770e-01
    z[6,3,4]  R1832     1.8205238878726959e-01
    z[6,3,4]  R1833     6.6807526350021362e-01
    z[6,3,4]  R1834     -4.0334054827690125e-01
    z[6,3,4]  R1835     3.4928798675537109e-01
    z[6,3,4]  R1836     3.3656361699104309e-01
    z[6,3,4]  R1837     1.7802956700325012e-01
    z[6,3,4]  R1838     2.6296606659889221e-01
    z[6,3,4]  R1839     -3.5195663571357727e-02
    z[6,3,4]  R1840     2.0981298387050629e-01
    z[6,3,4]  R1841     -2.1187800168991089e-01
    z[6,3,4]  R1842     1.7886583507061005e-01
    z[6,3,4]  R1843     -1.1789031559601426e-03
    z[6,3,4]  R1844     -0.558672308921814
    z[6,3,4]  R1845     -1.1019662767648697e-01
    z[6,3,4]  R1846     -5.5909123271703720e-02
    z[6,3,4]  R1847     -9.2242914438247681e-01
    z[6,3,4]  R1848     5.5569779872894287e-01
    z[6,3,4]  R1849     4.8192042112350464e-01
    z[6,3,4]  R1850     -5.4806423187255859e-01
    z[6,3,4]  R1851     3.2528510689735413e-01
    z[6,3,4]  R1852     1.6369768977165222e-01
    z[6,3,4]  R1853     -3.7840676307678223e-01
    z[6,3,4]  R1854     1.8910128623247147e-02
    z[6,3,4]  R1855     -2.6657721027731895e-02
    z[6,3,4]  R1856     4.0477478504180908e-01
    z[6,3,4]  R1857     5.5097335577011108e-01
    z[6,3,4]  R1858     0.349839985370636
    z[6,3,4]  R1859     -2.0136989653110504e-01
    z[6,3,4]  R1860     4.9555456638336182e-01
    z[6,3,4]  R1861     -1.2139406055212021e-01
    z[6,3,4]  R1862     4.4311735033988953e-01
    z[6,3,4]  R1863     1.1949014663696289e-01
    z[6,3,5]  R34       1
    z[6,3,5]  R61       -1
    z[6,3,5]  R1800     -1
    z[6,3,5]  R1801     1
    z[6,3,5]  R1804     5.0700742751359940e-02
    z[6,3,5]  R1805     -3.4988054633140564e-01
    z[6,3,5]  R1806     1.7902784049510956e-02
    z[6,3,5]  R1807     8.9013829827308655e-02
    z[6,3,5]  R1808     -0.0491558238863945
    z[6,3,5]  R1809     -1.6641260683536530e-01
    z[6,3,5]  R1810     1.7898994684219360e-01
    z[6,3,5]  R1811     -2.2681452333927155e-02
    z[6,3,5]  R1812     -2.3320766165852547e-02
    z[6,3,5]  R1813     -9.5537595450878143e-02
    z[6,3,5]  R1814     2.3141373693943024e-01
    z[6,3,5]  R1815     2.0014445483684540e-01
    z[6,3,5]  R1816     -7.4222333729267120e-02
    z[6,3,5]  R1817     -2.4428756535053253e-01
    z[6,3,5]  R1818     3.1565821170806885e-01
    z[6,3,5]  R1819     -1.4559094607830048e-01
    z[6,3,5]  R1820     -2.0341484248638153e-01
    z[6,3,5]  R1821     -4.9272051453590393e-01
    z[6,3,5]  R1822     -1.6252711415290833e-01
    z[6,3,5]  R1823     -5.1126211881637573e-01
    z[6,3,5]  R1824     5.9974884986877441e-01
    z[6,3,5]  R1825     -2.2125542163848877e-01
    z[6,3,5]  R1826     0.613357663154602
    z[6,3,5]  R1827     -5.4441195726394653e-01
    z[6,3,5]  R1828     2.1309484541416168e-01
    z[6,3,5]  R1829     3.2975459098815918e-01
    z[6,3,5]  R1830     -6.3749986886978149e-01
    z[6,3,5]  R1831     1.3013105094432831e-01
    z[6,3,5]  R1832     2.2970614954829216e-02
    z[6,3,5]  R1833     2.0947758108377457e-02
    z[6,3,5]  R1834     -3.3380375243723392e-03
    z[6,3,5]  R1835     -4.9794283509254456e-01
    z[6,3,5]  R1836     2.7872281149029732e-02
    z[6,3,5]  R1837     -5.2084422111511230e-01
    z[6,3,5]  R1838     5.1263108849525452e-02
    z[6,3,5]  R1839     -2.9249009490013123e-01
    z[6,3,5]  R1840     -5.3765302896499634e-01
    z[6,3,5]  R1841     -3.2040674239397049e-02
    z[6,3,5]  R1842     -3.8281852006912231e-01
    z[6,3,5]  R1843     -0.539277970790863
    z[6,3,5]  R1844     2.6998212933540344e-01
    z[6,3,5]  R1845     1.4770534634590149e-01
    z[6,3,5]  R1846     1.8912889063358307e-01
    z[6,3,5]  R1847     0.0660073533654213
    z[6,3,5]  R1848     3.3002045750617981e-01
    z[6,3,5]  R1849     3.6354464292526245e-01
    z[6,3,5]  R1850     5.6534707546234131e-01
    z[6,3,5]  R1851     4.8115104436874390e-03
    z[6,3,5]  R1852     7.7572362497448921e-03
    z[6,3,5]  R1853     -1.5721473097801208e-01
    z[6,3,5]  R1854     -7.6816070079803467e-01
    z[6,3,5]  R1855     -1.1064589023590088e-01
    z[6,3,5]  R1856     -3.1259015202522278e-01
    z[6,3,5]  R1857     4.6183642745018005e-01
    z[6,3,5]  R1858     9.8798334598541260e-02
    z[6,3,5]  R1859     -0.185917928814888
    z[6,3,5]  R1860     0.307997465133667
    z[6,3,5]  R1861     3.8070093840360641e-02
    z[6,3,5]  R1862     -6.6336655616760254e-01
    z[6,3,5]  R1863     -5.6838154792785645e-01
    z[6,3,6]  R35       1
    z[6,3,6]  R62       -1
    z[6,3,6]  R1802     -1
    z[6,3,6]  R1803     1
    z[6,3,6]  R1804     -9.2715196311473846e-02
    z[6,3,6]  R1805     -3.5453815013170242e-02
    z[6,3,6]  R1806     -1.9415597617626190e-01
    z[6,3,6]  R1807     2.4558302760124207e-01
    z[6,3,6]  R1808     1.7966997623443604e-01
    z[6,3,6]  R1809     -1.3015929609537125e-02
    z[6,3,6]  R1810     -3.1739047169685364e-01
    z[6,3,6]  R1811     -4.3279886245727539e-02
    z[6,3,6]  R1812     -0.155271977186203
    z[6,3,6]  R1813     -2.4423734843730927e-01
    z[6,3,6]  R1814     4.0482887625694275e-01
    z[6,3,6]  R1815     -5.3904253244400024e-01
    z[6,3,6]  R1816     -1.0069804638624191e-01
    z[6,3,6]  R1817     9.3679733574390411e-02
    z[6,3,6]  R1818     2.6271790266036987e-02
    z[6,3,6]  R1819     0.301908403635025
    z[6,3,6]  R1820     -1.3290268369019032e-02
    z[6,3,6]  R1821     -3.4442096948623657e-01
    z[6,3,6]  R1822     -3.9069458842277527e-01
    z[6,3,6]  R1823     1.6704581677913666e-01
    z[6,3,6]  R1824     6.0678459703922272e-02
    z[6,3,6]  R1825     -4.3259564787149429e-02
    z[6,3,6]  R1826     4.1298347711563110e-01
    z[6,3,6]  R1827     -1.5963518619537354e-01
    z[6,3,6]  R1828     1.8098542094230652e-01
    z[6,3,6]  R1829     1.3291537761688232e-01
    z[6,3,6]  R1830     1.0008950531482697e-01
    z[6,3,6]  R1831     -2.1194621920585632e-02
    z[6,3,6]  R1832     3.6874154210090637e-01
    z[6,3,6]  R1833     -1.9895978271961212e-02
    z[6,3,6]  R1834     1.0549000650644302e-01
    z[6,3,6]  R1835     4.4506066478788853e-03
    z[6,3,6]  R1836     -1.3924518227577209e-01
    z[6,3,6]  R1837     -1.4651606976985931e-01
    z[6,3,6]  R1838     -2.4712134897708893e-01
    z[6,3,6]  R1839     -3.5546213388442993e-02
    z[6,3,6]  R1840     -1.0249412804841995e-01
    z[6,3,6]  R1841     -1.7948724329471588e-01
    z[6,3,6]  R1842     -5.9537172317504883e-01
    z[6,3,6]  R1843     -5.0708043575286865e-01
    z[6,3,6]  R1844     0.264161080121994
    z[6,3,6]  R1845     -1.7609673738479614e-01
    z[6,3,6]  R1846     6.0599303245544434e-01
    z[6,3,6]  R1847     -5.4570611566305161e-02
    z[6,3,6]  R1848     4.6261945366859436e-01
    z[6,3,6]  R1849     -0.081184022128582
    z[6,3,6]  R1850     5.6252133846282959e-01
    z[6,3,6]  R1851     3.4647822380065918e-01
    z[6,3,6]  R1852     4.0271830558776855e-01
    z[6,3,6]  R1853     4.8912355303764343e-01
    z[6,3,6]  R1854     -8.0639824271202087e-02
    z[6,3,6]  R1855     -2.5323250889778137e-01
    z[6,3,6]  R1856     -1.4548771083354950e-01
    z[6,3,6]  R1857     1.6157284379005432e-01
    z[6,3,6]  R1858     3.5315132141113281e-01
    z[6,3,6]  R1859     2.0211941003799438e-01
    z[6,3,6]  R1860     -7.6526342891156673e-03
    z[6,3,6]  R1861     0.124819315969944
    z[6,3,6]  R1862     2.3658286035060883e-01
    z[6,3,6]  R1863     2.1239617466926575e-01
    z[3,7,0]  R29       -1
    z[3,7,0]  R65       1
    z[3,7,0]  R1864     -1
    z[3,7,0]  R1865     1
    z[3,7,0]  R1878     -5.6193226575851440e-01
    z[3,7,0]  R1879     -2.1877616643905640e-01
    z[3,7,0]  R1880     8.1439119577407837e-01
    z[3,7,0]  R1881     -4.3648043274879456e-01
    z[3,7,0]  R1882     8.5842144489288330e-01
    z[3,7,0]  R1883     6.6212922334671021e-01
    z[3,7,0]  R1884     7.5678145885467529e-01
    z[3,7,0]  R1885     -4.6959450840950012e-01
    z[3,7,0]  R1886     -1.8554012477397919e-01
    z[3,7,0]  R1887     8.1496782600879669e-02
    z[3,7,0]  R1888     4.0846642851829529e-01
    z[3,7,0]  R1889     5.4487776756286621e-01
    z[3,7,0]  R1890     2.1994680166244507e-01
    z[3,7,0]  R1891     2.4828505516052246e-01
    z[3,7,0]  R1892     3.4240600466728210e-01
    z[3,7,0]  R1893     -2.9961192607879639e-01
    z[3,7,0]  R1894     6.1994470655918121e-02
    z[3,7,0]  R1895     -4.5045062899589539e-01
    z[3,7,0]  R1896     1.7669546604156494e-01
    z[3,7,0]  R1897     -1.9386282563209534e-01
    z[3,7,0]  R1898     -3.6804085969924927e-01
    z[3,7,0]  R1899     -6.8062943220138550e-01
    z[3,7,0]  R1900     -7.5242631137371063e-02
    z[3,7,0]  R1901     5.4270535707473755e-01
    z[3,7,0]  R1902     -0.60260409116745
    z[3,7,0]  R1903     -0.841519296169281
    z[3,7,0]  R1904     -3.3021429181098938e-01
    z[3,7,0]  R1905     -1.4445284008979797e-01
    z[3,7,0]  R1906     -5.0922536849975586e-01
    z[3,7,0]  R1907     1.6006837785243988e-01
    z[3,7,0]  R1908     -3.0372151732444763e-01
    z[3,7,0]  R1909     -3.0008256435394287e-01
    z[3,7,0]  R1910     -1.9094075262546539e-01
    z[3,7,0]  R1911     -4.8980396986007690e-01
    z[3,7,0]  R1912     5.5676519870758057e-01
    z[3,7,0]  R1913     5.4785132408142090e-01
    z[3,7,0]  R1914     4.7637981176376343e-01
    z[3,7,0]  R1915     4.1669556498527527e-01
    z[3,7,0]  R1916     0.401156485080719
    z[3,7,0]  R1917     -5.4611825942993164e-01
    z[3,7,0]  R1918     -7.9487943649291992e-01
    z[3,7,0]  R1919     -8.1363278627395630e-01
    z[3,7,0]  R1920     -6.1245149374008179e-01
    z[3,7,0]  R1921     -0.700247585773468
    z[3,7,0]  R1922     3.4501597285270691e-01
    z[3,7,0]  R1923     -0.606789767742157
    z[3,7,0]  R1924     0.114809550344944
    z[3,7,0]  R1925     1.8719317018985748e-01
    z[3,7,0]  R1926     -4.5119252800941467e-01
    z[3,7,0]  R1927     -3.0796242877840996e-02
    z[3,7,0]  R1928     -7.3783248662948608e-01
    z[3,7,0]  R1929     -4.0503782033920288e-01
    z[3,7,0]  R1930     0.321079283952713
    z[3,7,0]  R1931     4.3968539685010910e-02
    z[3,7,0]  R1932     -7.1097129583358765e-01
    z[3,7,0]  R1933     -5.9146308898925781e-01
    z[3,7,0]  R1934     1.9861114025115967e-01
    z[3,7,0]  R1935     5.8389854431152344e-01
    z[3,7,0]  R1936     2.4765689671039581e-01
    z[3,7,0]  R1937     3.3355557918548584e-01
    z[3,7,0]  R1938     2.8576344251632690e-01
    z[3,7,0]  R1939     -5.9667402505874634e-01
    z[3,7,0]  R1940     3.8589265942573547e-01
    z[3,7,0]  R1941     -5.8138000965118408e-01
    z[3,7,0]  R1942     1.3199988007545471e-01
    z[3,7,0]  R1943     8.4620010852813721e-01
    z[3,7,0]  R1944     8.3288741111755371e-01
    z[3,7,0]  R1945     3.1440284848213196e-01
    z[3,7,0]  R1946     -1.6727916896343231e-01
    z[3,7,1]  R30       -1
    z[3,7,1]  R66       1
    z[3,7,1]  R1866     -1
    z[3,7,1]  R1867     1
    z[3,7,1]  R1878     1.2658137083053589e-01
    z[3,7,1]  R1879     -4.0987440943717957e-01
    z[3,7,1]  R1880     -1.7743816599249840e-02
    z[3,7,1]  R1881     1.5095029026269913e-02
    z[3,7,1]  R1882     1.3860325515270233e-01
    z[3,7,1]  R1883     0.219833105802536
    z[3,7,1]  R1884     0.278201162815094
    z[3,7,1]  R1885     3.0335025861859322e-02
    z[3,7,1]  R1886     -6.4056468009948730e-01
    z[3,7,1]  R1887     -5.5411326885223389e-01
    z[3,7,1]  R1888     5.4294317960739136e-01
    z[3,7,1]  R1889     2.1319216489791870e-01
    z[3,7,1]  R1890     7.0009982585906982e-01
    z[3,7,1]  R1891     -1.4219549298286438e-01
    z[3,7,1]  R1892     4.1987210512161255e-01
    z[3,7,1]  R1893     -4.9000686407089233e-01
    z[3,7,1]  R1894     -2.4379158020019531e-01
    z[3,7,1]  R1895     -1.9936127960681915e-01
    z[3,7,1]  R1896     1.3906867243349552e-02
    z[3,7,1]  R1897     1.0930828005075455e-01
    z[3,7,1]  R1898     -3.1919276714324951e-01
    z[3,7,1]  R1899     -6.4516997337341309e-01
    z[3,7,1]  R1900     -4.2915329337120056e-01
    z[3,7,1]  R1901     2.8473719954490662e-01
    z[3,7,1]  R1902     -3.1105524301528931e-01
    z[3,7,1]  R1903     -2.6590937376022339e-01
    z[3,7,1]  R1904     -5.6255763769149780e-01
    z[3,7,1]  R1905     -3.5914209485054016e-01
    z[3,7,1]  R1906     1.9825773313641548e-02
    z[3,7,1]  R1907     -7.7108982950448990e-03
    z[3,7,1]  R1908     5.9839583933353424e-02
    z[3,7,1]  R1909     -1.0776294022798538e-01
    z[3,7,1]  R1910     6.7972518503665924e-02
    z[3,7,1]  R1911     1.4336401224136353e-01
    z[3,7,1]  R1912     -5.6059449911117554e-01
    z[3,7,1]  R1913     1.1334766447544098e-01
    z[3,7,1]  R1914     -3.8519391417503357e-01
    z[3,7,1]  R1915     -4.1615876555442810e-01
    z[3,7,1]  R1916     0.0632009282708168
    z[3,7,1]  R1917     -2.7729475498199463e-01
    z[3,7,1]  R1918     2.7077552676200867e-01
    z[3,7,1]  R1919     6.6772729158401489e-02
    z[3,7,1]  R1920     2.6250171661376953e-01
    z[3,7,1]  R1921     -1.0952156037092209e-01
    z[3,7,1]  R1922     -3.4136629104614258e-01
    z[3,7,1]  R1923     1.3359403237700462e-02
    z[3,7,1]  R1924     -1.4204810559749603e-01
    z[3,7,1]  R1925     7.0631068944931030e-01
    z[3,7,1]  R1926     2.6673880219459534e-01
    z[3,7,1]  R1927     5.8728420734405518e-01
    z[3,7,1]  R1928     -1.0162436962127686e-01
    z[3,7,1]  R1929     1.6930936276912689e-01
    z[3,7,1]  R1930     -2.3312389850616455e-01
    z[3,7,1]  R1931     -3.2947105169296265e-01
    z[3,7,1]  R1932     4.0027368068695068e-01
    z[3,7,1]  R1933     -6.2102526426315308e-02
    z[3,7,1]  R1934     8.3066987991333008e-01
    z[3,7,1]  R1935     -1.1053048074245453e-01
    z[3,7,1]  R1936     6.7984503507614136e-01
    z[3,7,1]  R1937     6.7457187175750732e-01
    z[3,7,1]  R1938     -1.7039711773395538e-01
    z[3,7,1]  R1939     -1.3729162514209747e-01
    z[3,7,1]  R1940     2.9298362787812948e-03
    z[3,7,1]  R1941     8.2027778029441833e-02
    z[3,7,1]  R1942     7.8628820180892944e-01
    z[3,7,1]  R1943     0.228877454996109
    z[3,7,1]  R1944     1.7244207859039307e-01
    z[3,7,1]  R1945     3.3402338624000549e-01
    z[3,7,1]  R1946     -0.778550386428833
    z[3,7,2]  R31       -1
    z[3,7,2]  R67       1
    z[3,7,2]  R1868     -1
    z[3,7,2]  R1869     1
    z[3,7,2]  R1878     6.9000810384750366e-01
    z[3,7,2]  R1879     0.210184246301651
    z[3,7,2]  R1880     1.1719269305467606e-01
    z[3,7,2]  R1881     6.9620794057846069e-01
    z[3,7,2]  R1882     3.2710447907447815e-01
    z[3,7,2]  R1883     5.0952249765396118e-01
    z[3,7,2]  R1884     7.6343074440956116e-02
    z[3,7,2]  R1885     6.8611919879913330e-01
    z[3,7,2]  R1886     1.4378747344017029e-01
    z[3,7,2]  R1887     -0.062874436378479
    z[3,7,2]  R1888     -2.8643596172332764e-01
    z[3,7,2]  R1889     -6.5241509675979614e-01
    z[3,7,2]  R1890     -1.8200229108333588e-01
    z[3,7,2]  R1891     -2.4465499818325043e-01
    z[3,7,2]  R1892     -2.4278061091899872e-01
    z[3,7,2]  R1893     -5.4686951637268066e-01
    z[3,7,2]  R1894     1.7173700034618378e-02
    z[3,7,2]  R1895     -7.0712512731552124e-01
    z[3,7,2]  R1896     -6.5931832790374756e-01
    z[3,7,2]  R1897     -4.0237104892730713e-01
    z[3,7,2]  R1898     -3.7199565768241882e-01
    z[3,7,2]  R1899     -1.3697220385074615e-01
    z[3,7,2]  R1900     -7.1549135446548462e-01
    z[3,7,2]  R1901     -1.8416188657283783e-01
    z[3,7,2]  R1902     -4.1858857870101929e-01
    z[3,7,2]  R1903     1.5182051062583923e-01
    z[3,7,2]  R1904     -3.4829905629158020e-01
    z[3,7,2]  R1905     -5.8139652013778687e-01
    z[3,7,2]  R1906     1.2566743791103363e-01
    z[3,7,2]  R1907     -0.649156391620636
    z[3,7,2]  R1908     8.8125967979431152e-01
    z[3,7,2]  R1909     8.7643355131149292e-01
    z[3,7,2]  R1910     8.7768596410751343e-01
    z[3,7,2]  R1911     7.1278828382492065e-01
    z[3,7,2]  R1912     5.1686805486679077e-01
    z[3,7,2]  R1913     7.8773558139801025e-01
    z[3,7,2]  R1914     5.2271687984466553e-01
    z[3,7,2]  R1915     5.4136687517166138e-01
    z[3,7,2]  R1916     8.6033004522323608e-01
    z[3,7,2]  R1917     3.5049009323120117e-01
    z[3,7,2]  R1918     -1.5173679590225220e-01
    z[3,7,2]  R1919     -1.2127404659986496e-01
    z[3,7,2]  R1920     5.2269272506237030e-02
    z[3,7,2]  R1921     0.067268505692482
    z[3,7,2]  R1922     3.1443178653717041e-01
    z[3,7,2]  R1923     -6.9947414100170135e-02
    z[3,7,2]  R1924     4.9026903510093689e-01
    z[3,7,2]  R1925     -1.1069977283477783e-01
    z[3,7,2]  R1926     -1.5725065767765045e-01
    z[3,7,2]  R1927     -5.0107151269912720e-02
    z[3,7,2]  R1928     1.5685613453388214e-01
    z[3,7,2]  R1929     6.5976572036743164e-01
    z[3,7,2]  R1930     6.0806733369827271e-01
    z[3,7,2]  R1931     6.1673003435134888e-01
    z[3,7,2]  R1932     -2.2239057719707489e-01
    z[3,7,2]  R1933     1.4230807125568390e-01
    z[3,7,2]  R1934     3.3870470523834229e-01
    z[3,7,2]  R1935     0.274432510137558
    z[3,7,2]  R1936     2.4938605725765228e-01
    z[3,7,2]  R1937     -1.8986427783966064e-01
    z[3,7,2]  R1938     8.6477959156036377e-01
    z[3,7,2]  R1939     4.5375841856002808e-01
    z[3,7,2]  R1940     7.2029000520706177e-01
    z[3,7,2]  R1941     1.0285206884145737e-01
    z[3,7,2]  R1942     7.4434056878089905e-03
    z[3,7,2]  R1943     -2.0413251221179962e-01
    z[3,7,2]  R1944     -2.1016301214694977e-01
    z[3,7,2]  R1945     -1.7740696668624878e-01
    z[3,7,2]  R1946     -1.4455151557922363e-01
    z[3,7,3]  R32       -1
    z[3,7,3]  R68       1
    z[3,7,3]  R1870     -1
    z[3,7,3]  R1871     1
    z[3,7,3]  R1878     1.3518603146076202e-01
    z[3,7,3]  R1879     -6.0827100276947021e-01
    z[3,7,3]  R1880     -4.3505945801734924e-01
    z[3,7,3]  R1881     -1.0539470240473747e-02
    z[3,7,3]  R1882     -6.3690222799777985e-02
    z[3,7,3]  R1883     -4.0693020820617676e-01
    z[3,7,3]  R1884     -2.1456105634570122e-02
    z[3,7,3]  R1885     -4.7923552989959717e-01
    z[3,7,3]  R1886     -3.9578646421432495e-02
    z[3,7,3]  R1887     -3.6662086844444275e-01
    z[3,7,3]  R1888     3.9195086807012558e-02
    z[3,7,3]  R1889     4.0870717167854309e-01
    z[3,7,3]  R1890     1.4911645650863647e-01
    z[3,7,3]  R1891     -0.0082710487768054
    z[3,7,3]  R1892     1.2566968798637390e-01
    z[3,7,3]  R1893     -7.5368061661720276e-03
    z[3,7,3]  R1894     2.3450877051800489e-03
    z[3,7,3]  R1895     -1.7732071876525879e-01
    z[3,7,3]  R1896     -5.8723551034927368e-01
    z[3,7,3]  R1897     -6.1758917570114136e-01
    z[3,7,3]  R1898     -1.6537846624851227e-01
    z[3,7,3]  R1899     -1.5702915191650391e-01
    z[3,7,3]  R1900     -1.2456391006708145e-01
    z[3,7,3]  R1901     2.1796748042106628e-01
    z[3,7,3]  R1902     -3.2868149876594543e-01
    z[3,7,3]  R1903     -2.8656652569770813e-01
    z[3,7,3]  R1904     -3.3567818999290466e-01
    z[3,7,3]  R1905     -6.9308197498321533e-01
    z[3,7,3]  R1906     1.7923320829868317e-01
    z[3,7,3]  R1907     -4.1287642717361450e-01
    z[3,7,3]  R1908     -1.6969552636146545e-01
    z[3,7,3]  R1909     -1.1241710186004639e-01
    z[3,7,3]  R1910     -2.3333995044231415e-01
    z[3,7,3]  R1911     -2.4053138494491577e-01
    z[3,7,3]  R1912     -3.0179014801979065e-01
    z[3,7,3]  R1913     -0.180845707654953
    z[3,7,3]  R1914     -4.8619282245635986e-01
    z[3,7,3]  R1915     -5.4015350341796875e-01
    z[3,7,3]  R1916     8.8432110846042633e-02
    z[3,7,3]  R1917     -1.5006552636623383e-01
    z[3,7,3]  R1918     4.9502205848693848e-01
    z[3,7,3]  R1919     3.9076185226440430e-01
    z[3,7,3]  R1920     0.510936975479126
    z[3,7,3]  R1921     3.9284959435462952e-01
    z[3,7,3]  R1922     2.4078071117401123e-01
    z[3,7,3]  R1923     -2.4797025322914124e-01
    z[3,7,3]  R1924     2.2925460338592529e-01
    z[3,7,3]  R1925     -5.6692969799041748e-01
    z[3,7,3]  R1926     -5.0393766164779663e-01
    z[3,7,3]  R1927     -7.1790444850921631e-01
    z[3,7,3]  R1928     -2.2077558934688568e-01
    z[3,7,3]  R1929     5.5741715431213379e-01
    z[3,7,3]  R1930     -4.4713595509529114e-01
    z[3,7,3]  R1931     -8.7472721934318542e-02
    z[3,7,3]  R1932     -1.6879495233297348e-02
    z[3,7,3]  R1933     -8.6856320500373840e-02
    z[3,7,3]  R1934     1.0131967812776566e-01
    z[3,7,3]  R1935     5.2337951958179474e-02
    z[3,7,3]  R1936     0.369122713804245
    z[3,7,3]  R1937     4.4091975688934326e-01
    z[3,7,3]  R1938     -1.9173561036586761e-01
    z[3,7,3]  R1939     -0.296233594417572
    z[3,7,3]  R1940     2.7814612258225679e-03
    z[3,7,3]  R1941     -1.3853618502616882e-01
    z[3,7,3]  R1942     1.1580002307891846e-01
    z[3,7,3]  R1943     4.3408408761024475e-01
    z[3,7,3]  R1944     3.2856735587120056e-01
    z[3,7,3]  R1945     3.6119055747985840e-01
    z[3,7,3]  R1946     2.2066141664981842e-01
    z[3,7,4]  R33       -1
    z[3,7,4]  R69       1
    z[3,7,4]  R1872     -1
    z[3,7,4]  R1873     1
    z[3,7,4]  R1878     -4.0334054827690125e-01
    z[3,7,4]  R1879     3.4928798675537109e-01
    z[3,7,4]  R1880     3.3656361699104309e-01
    z[3,7,4]  R1881     1.7802956700325012e-01
    z[3,7,4]  R1882     2.6296606659889221e-01
    z[3,7,4]  R1883     -3.5195663571357727e-02
    z[3,7,4]  R1884     2.0981298387050629e-01
    z[3,7,4]  R1885     -2.1187800168991089e-01
    z[3,7,4]  R1886     1.7886583507061005e-01
    z[3,7,4]  R1887     -1.1789031559601426e-03
    z[3,7,4]  R1888     -0.558672308921814
    z[3,7,4]  R1889     -1.1019662767648697e-01
    z[3,7,4]  R1890     -5.5909123271703720e-02
    z[3,7,4]  R1891     -9.2242914438247681e-01
    z[3,7,4]  R1892     5.5569779872894287e-01
    z[3,7,4]  R1893     4.8192042112350464e-01
    z[3,7,4]  R1894     -5.4806423187255859e-01
    z[3,7,4]  R1895     3.2528510689735413e-01
    z[3,7,4]  R1896     1.6369768977165222e-01
    z[3,7,4]  R1897     -3.7840676307678223e-01
    z[3,7,4]  R1898     1.8910128623247147e-02
    z[3,7,4]  R1899     -2.6657721027731895e-02
    z[3,7,4]  R1900     4.0477478504180908e-01
    z[3,7,4]  R1901     5.5097335577011108e-01
    z[3,7,4]  R1902     0.349839985370636
    z[3,7,4]  R1903     -2.0136989653110504e-01
    z[3,7,4]  R1904     4.9555456638336182e-01
    z[3,7,4]  R1905     -1.2139406055212021e-01
    z[3,7,4]  R1906     4.4311735033988953e-01
    z[3,7,4]  R1907     1.1949014663696289e-01
    z[3,7,4]  R1908     1.1278350651264191e-01
    z[3,7,4]  R1909     0.0964094027876854
    z[3,7,4]  R1910     -3.4093859791755676e-01
    z[3,7,4]  R1911     -2.3012995719909668e-01
    z[3,7,4]  R1912     5.2285179495811462e-02
    z[3,7,4]  R1913     -6.0546919703483582e-02
    z[3,7,4]  R1914     -1.0873212665319443e-01
    z[3,7,4]  R1915     2.2681656479835510e-01
    z[3,7,4]  R1916     2.5383159518241882e-01
    z[3,7,4]  R1917     -7.2736762464046478e-02
    z[3,7,4]  R1918     3.4567296504974365e-02
    z[3,7,4]  R1919     3.1856021285057068e-01
    z[3,7,4]  R1920     1.6540652513504028e-01
    z[3,7,4]  R1921     1.2471586465835571e-01
    z[3,7,4]  R1922     2.7911895513534546e-01
    z[3,7,4]  R1923     7.0714193582534790e-01
    z[3,7,4]  R1924     3.3558797091245651e-02
    z[3,7,4]  R1925     -1.0612443834543228e-01
    z[3,7,4]  R1926     3.7346008419990540e-01
    z[3,7,4]  R1927     2.9410016536712646e-01
    z[3,7,4]  R1928     4.2312777042388916e-01
    z[3,7,4]  R1929     2.4257218837738037e-01
    z[3,7,4]  R1930     3.4185758233070374e-01
    z[3,7,4]  R1931     1.1368550360202789e-01
    z[3,7,4]  R1932     -3.2543146610260010e-01
    z[3,7,4]  R1933     -5.5780386924743652e-01
    z[3,7,4]  R1934     6.2212649732828140e-02
    z[3,7,4]  R1935     2.2808945178985596e-01
    z[3,7,4]  R1936     -2.0683406293392181e-01
    z[3,7,4]  R1937     -2.8593108057975769e-01
    z[3,7,4]  R1938     2.2274306043982506e-02
    z[3,7,4]  R1939     1.4186917245388031e-01
    z[3,7,4]  R1940     2.1276238560676575e-01
    z[3,7,4]  R1941     -7.1415370702743530e-01
    z[3,7,4]  R1942     -4.6594056487083435e-01
    z[3,7,4]  R1943     1.4941351255401969e-03
    z[3,7,4]  R1944     -0.258316308259964
    z[3,7,4]  R1945     -6.5026766061782837e-01
    z[3,7,4]  R1946     -3.6814033985137939e-01
    z[3,7,5]  R34       -1
    z[3,7,5]  R70       1
    z[3,7,5]  R1874     -1
    z[3,7,5]  R1875     1
    z[3,7,5]  R1878     -3.3380375243723392e-03
    z[3,7,5]  R1879     -4.9794283509254456e-01
    z[3,7,5]  R1880     2.7872281149029732e-02
    z[3,7,5]  R1881     -5.2084422111511230e-01
    z[3,7,5]  R1882     5.1263108849525452e-02
    z[3,7,5]  R1883     -2.9249009490013123e-01
    z[3,7,5]  R1884     -5.3765302896499634e-01
    z[3,7,5]  R1885     -3.2040674239397049e-02
    z[3,7,5]  R1886     -3.8281852006912231e-01
    z[3,7,5]  R1887     -0.539277970790863
    z[3,7,5]  R1888     2.6998212933540344e-01
    z[3,7,5]  R1889     1.4770534634590149e-01
    z[3,7,5]  R1890     1.8912889063358307e-01
    z[3,7,5]  R1891     0.0660073533654213
    z[3,7,5]  R1892     3.3002045750617981e-01
    z[3,7,5]  R1893     3.6354464292526245e-01
    z[3,7,5]  R1894     5.6534707546234131e-01
    z[3,7,5]  R1895     4.8115104436874390e-03
    z[3,7,5]  R1896     7.7572362497448921e-03
    z[3,7,5]  R1897     -1.5721473097801208e-01
    z[3,7,5]  R1898     -7.6816070079803467e-01
    z[3,7,5]  R1899     -1.1064589023590088e-01
    z[3,7,5]  R1900     -3.1259015202522278e-01
    z[3,7,5]  R1901     4.6183642745018005e-01
    z[3,7,5]  R1902     9.8798334598541260e-02
    z[3,7,5]  R1903     -0.185917928814888
    z[3,7,5]  R1904     0.307997465133667
    z[3,7,5]  R1905     3.8070093840360641e-02
    z[3,7,5]  R1906     -6.6336655616760254e-01
    z[3,7,5]  R1907     -5.6838154792785645e-01
    z[3,7,5]  R1908     -2.4292354285717010e-01
    z[3,7,5]  R1909     -8.5357002913951874e-02
    z[3,7,5]  R1910     1.1845561116933823e-01
    z[3,7,5]  R1911     -7.3580518364906311e-02
    z[3,7,5]  R1912     1.1728803068399429e-01
    z[3,7,5]  R1913     -1.0707467794418335e-01
    z[3,7,5]  R1914     1.5568982064723969e-01
    z[3,7,5]  R1915     7.0412173867225647e-02
    z[3,7,5]  R1916     -6.2022916972637177e-02
    z[3,7,5]  R1917     1.1527665704488754e-01
    z[3,7,5]  R1918     1.1195374280214310e-01
    z[3,7,5]  R1919     -0.0772845670580864
    z[3,7,5]  R1920     -4.8617967963218689e-01
    z[3,7,5]  R1921     0.549161970615387
    z[3,7,5]  R1922     6.5689951181411743e-01
    z[3,7,5]  R1923     2.4671067297458649e-01
    z[3,7,5]  R1924     7.8949761390686035e-01
    z[3,7,5]  R1925     -2.3483854532241821e-01
    z[3,7,5]  R1926     -5.4759597778320312e-01
    z[3,7,5]  R1927     1.0023871809244156e-01
    z[3,7,5]  R1928     -3.8677930831909180e-01
    z[3,7,5]  R1929     -4.4197618961334229e-02
    z[3,7,5]  R1930     1.2097232788801193e-01
    z[3,7,5]  R1931     0.698793888092041
    z[3,7,5]  R1932     3.5054400563240051e-01
    z[3,7,5]  R1933     5.4406970739364624e-01
    z[3,7,5]  R1934     1.7084047198295593e-01
    z[3,7,5]  R1935     -2.6089626550674438e-01
    z[3,7,5]  R1936     4.4805806875228882e-01
    z[3,7,5]  R1937     -2.2655102610588074e-01
    z[3,7,5]  R1938     1.8287371098995209e-01
    z[3,7,5]  R1939     2.0882815122604370e-01
    z[3,7,5]  R1940     2.4814268946647644e-01
    z[3,7,5]  R1941     1.8580763041973114e-01
    z[3,7,5]  R1942     3.4732723236083984e-01
    z[3,7,5]  R1943     0.00392861757427454
    z[3,7,5]  R1944     2.0078346133232117e-01
    z[3,7,5]  R1945     1.2518773972988129e-01
    z[3,7,5]  R1946     -3.2741820812225342e-01
    z[3,7,6]  R35       -1
    z[3,7,6]  R71       1
    z[3,7,6]  R1876     -1
    z[3,7,6]  R1877     1
    z[3,7,6]  R1878     1.0549000650644302e-01
    z[3,7,6]  R1879     4.4506066478788853e-03
    z[3,7,6]  R1880     -1.3924518227577209e-01
    z[3,7,6]  R1881     -1.4651606976985931e-01
    z[3,7,6]  R1882     -2.4712134897708893e-01
    z[3,7,6]  R1883     -3.5546213388442993e-02
    z[3,7,6]  R1884     -1.0249412804841995e-01
    z[3,7,6]  R1885     -1.7948724329471588e-01
    z[3,7,6]  R1886     -5.9537172317504883e-01
    z[3,7,6]  R1887     -5.0708043575286865e-01
    z[3,7,6]  R1888     0.264161080121994
    z[3,7,6]  R1889     -1.7609673738479614e-01
    z[3,7,6]  R1890     6.0599303245544434e-01
    z[3,7,6]  R1891     -5.4570611566305161e-02
    z[3,7,6]  R1892     4.6261945366859436e-01
    z[3,7,6]  R1893     -0.081184022128582
    z[3,7,6]  R1894     5.6252133846282959e-01
    z[3,7,6]  R1895     3.4647822380065918e-01
    z[3,7,6]  R1896     4.0271830558776855e-01
    z[3,7,6]  R1897     4.8912355303764343e-01
    z[3,7,6]  R1898     -8.0639824271202087e-02
    z[3,7,6]  R1899     -2.5323250889778137e-01
    z[3,7,6]  R1900     -1.4548771083354950e-01
    z[3,7,6]  R1901     1.6157284379005432e-01
    z[3,7,6]  R1902     3.5315132141113281e-01
    z[3,7,6]  R1903     2.0211941003799438e-01
    z[3,7,6]  R1904     -7.6526342891156673e-03
    z[3,7,6]  R1905     0.124819315969944
    z[3,7,6]  R1906     2.3658286035060883e-01
    z[3,7,6]  R1907     2.1239617466926575e-01
    z[3,7,6]  R1908     1.6439394652843475e-01
    z[3,7,6]  R1909     -3.1777936220169067e-01
    z[3,7,6]  R1910     6.2210746109485626e-02
    z[3,7,6]  R1911     3.3947363495826721e-01
    z[3,7,6]  R1912     -3.2035343348979950e-02
    z[3,7,6]  R1913     1.3655607402324677e-01
    z[3,7,6]  R1914     -2.8108641505241394e-01
    z[3,7,6]  R1915     -1.0922054201364517e-01
    z[3,7,6]  R1916     1.3716332614421844e-01
    z[3,7,6]  R1917     -0.678911030292511
    z[3,7,6]  R1918     1.1422696709632874e-01
    z[3,7,6]  R1919     2.4225464463233948e-01
    z[3,7,6]  R1920     -1.6875217854976654e-01
    z[3,7,6]  R1921     1.4720532298088074e-01
    z[3,7,6]  R1922     -3.1331443786621094e-01
    z[3,7,6]  R1923     -6.5803073346614838e-02
    z[3,7,6]  R1924     2.2200700640678406e-01
    z[3,7,6]  R1925     -2.5692167878150940e-01
    z[3,7,6]  R1926     8.5210867226123810e-02
    z[3,7,6]  R1927     1.9927003979682922e-01
    z[3,7,6]  R1928     2.0807354152202606e-01
    z[3,7,6]  R1929     2.1896330639719963e-02
    z[3,7,6]  R1930     3.7601059675216675e-01
    z[3,7,6]  R1931     1.6459560021758080e-02
    z[3,7,6]  R1932     -2.3615995049476624e-01
    z[3,7,6]  R1933     -1.0659363120794296e-01
    z[3,7,6]  R1934     0.335407018661499
    z[3,7,6]  R1935     -6.6985177993774414e-01
    z[3,7,6]  R1936     -1.8572930991649628e-01
    z[3,7,6]  R1937     -2.6486387848854065e-01
    z[3,7,6]  R1938     -2.6600521802902222e-01
    z[3,7,6]  R1939     5.1743984222412109e-01
    z[3,7,6]  R1940     4.7477385401725769e-01
    z[3,7,6]  R1941     -2.8453102707862854e-01
    z[3,7,6]  R1942     -1.1456419527530670e-01
    z[3,7,6]  R1943     3.7997469305992126e-02
    z[3,7,6]  R1944     -1.3189387321472168e-01
    z[3,7,6]  R1945     4.3488770723342896e-01
    z[3,7,6]  R1946     2.3143112659454346e-01
    z[7,3,0]  R29       1
    z[7,3,0]  R65       -1
    z[7,3,0]  R1947     -1
    z[7,3,0]  R1948     1
    z[7,3,0]  R1961     -3.0372151732444763e-01
    z[7,3,0]  R1962     -3.0008256435394287e-01
    z[7,3,0]  R1963     -1.9094075262546539e-01
    z[7,3,0]  R1964     -4.8980396986007690e-01
    z[7,3,0]  R1965     5.5676519870758057e-01
    z[7,3,0]  R1966     5.4785132408142090e-01
    z[7,3,0]  R1967     4.7637981176376343e-01
    z[7,3,0]  R1968     4.1669556498527527e-01
    z[7,3,0]  R1969     0.401156485080719
    z[7,3,0]  R1970     -5.4611825942993164e-01
    z[7,3,0]  R1971     -7.9487943649291992e-01
    z[7,3,0]  R1972     -8.1363278627395630e-01
    z[7,3,0]  R1973     -6.1245149374008179e-01
    z[7,3,0]  R1974     -0.700247585773468
    z[7,3,0]  R1975     3.4501597285270691e-01
    z[7,3,0]  R1976     -0.606789767742157
    z[7,3,0]  R1977     0.114809550344944
    z[7,3,0]  R1978     1.8719317018985748e-01
    z[7,3,0]  R1979     -4.5119252800941467e-01
    z[7,3,0]  R1980     -3.0796242877840996e-02
    z[7,3,0]  R1981     -7.3783248662948608e-01
    z[7,3,0]  R1982     -4.0503782033920288e-01
    z[7,3,0]  R1983     0.321079283952713
    z[7,3,0]  R1984     4.3968539685010910e-02
    z[7,3,0]  R1985     -7.1097129583358765e-01
    z[7,3,0]  R1986     -5.9146308898925781e-01
    z[7,3,0]  R1987     1.9861114025115967e-01
    z[7,3,0]  R1988     5.8389854431152344e-01
    z[7,3,0]  R1989     2.4765689671039581e-01
    z[7,3,0]  R1990     3.3355557918548584e-01
    z[7,3,0]  R1991     2.8576344251632690e-01
    z[7,3,0]  R1992     -5.9667402505874634e-01
    z[7,3,0]  R1993     3.8589265942573547e-01
    z[7,3,0]  R1994     -5.8138000965118408e-01
    z[7,3,0]  R1995     1.3199988007545471e-01
    z[7,3,0]  R1996     8.4620010852813721e-01
    z[7,3,0]  R1997     8.3288741111755371e-01
    z[7,3,0]  R1998     3.1440284848213196e-01
    z[7,3,0]  R1999     -1.6727916896343231e-01
    z[7,3,0]  R2000     -5.6193226575851440e-01
    z[7,3,0]  R2001     -2.1877616643905640e-01
    z[7,3,0]  R2002     8.1439119577407837e-01
    z[7,3,0]  R2003     -4.3648043274879456e-01
    z[7,3,0]  R2004     8.5842144489288330e-01
    z[7,3,0]  R2005     6.6212922334671021e-01
    z[7,3,0]  R2006     7.5678145885467529e-01
    z[7,3,0]  R2007     -4.6959450840950012e-01
    z[7,3,0]  R2008     -1.8554012477397919e-01
    z[7,3,0]  R2009     8.1496782600879669e-02
    z[7,3,0]  R2010     4.0846642851829529e-01
    z[7,3,0]  R2011     5.4487776756286621e-01
    z[7,3,0]  R2012     2.1994680166244507e-01
    z[7,3,0]  R2013     2.4828505516052246e-01
    z[7,3,0]  R2014     3.4240600466728210e-01
    z[7,3,0]  R2015     -2.9961192607879639e-01
    z[7,3,0]  R2016     6.1994470655918121e-02
    z[7,3,0]  R2017     -4.5045062899589539e-01
    z[7,3,0]  R2018     1.7669546604156494e-01
    z[7,3,0]  R2019     -1.9386282563209534e-01
    z[7,3,0]  R2020     -3.6804085969924927e-01
    z[7,3,0]  R2021     -6.8062943220138550e-01
    z[7,3,0]  R2022     -7.5242631137371063e-02
    z[7,3,0]  R2023     5.4270535707473755e-01
    z[7,3,0]  R2024     -0.60260409116745
    z[7,3,0]  R2025     -0.841519296169281
    z[7,3,0]  R2026     -3.3021429181098938e-01
    z[7,3,0]  R2027     -1.4445284008979797e-01
    z[7,3,0]  R2028     -5.0922536849975586e-01
    z[7,3,0]  R2029     1.6006837785243988e-01
    z[7,3,1]  R30       1
    z[7,3,1]  R66       -1
    z[7,3,1]  R1949     -1
    z[7,3,1]  R1950     1
    z[7,3,1]  R1961     5.9839583933353424e-02
    z[7,3,1]  R1962     -1.0776294022798538e-01
    z[7,3,1]  R1963     6.7972518503665924e-02
    z[7,3,1]  R1964     1.4336401224136353e-01
    z[7,3,1]  R1965     -5.6059449911117554e-01
    z[7,3,1]  R1966     1.1334766447544098e-01
    z[7,3,1]  R1967     -3.8519391417503357e-01
    z[7,3,1]  R1968     -4.1615876555442810e-01
    z[7,3,1]  R1969     0.0632009282708168
    z[7,3,1]  R1970     -2.7729475498199463e-01
    z[7,3,1]  R1971     2.7077552676200867e-01
    z[7,3,1]  R1972     6.6772729158401489e-02
    z[7,3,1]  R1973     2.6250171661376953e-01
    z[7,3,1]  R1974     -1.0952156037092209e-01
    z[7,3,1]  R1975     -3.4136629104614258e-01
    z[7,3,1]  R1976     1.3359403237700462e-02
    z[7,3,1]  R1977     -1.4204810559749603e-01
    z[7,3,1]  R1978     7.0631068944931030e-01
    z[7,3,1]  R1979     2.6673880219459534e-01
    z[7,3,1]  R1980     5.8728420734405518e-01
    z[7,3,1]  R1981     -1.0162436962127686e-01
    z[7,3,1]  R1982     1.6930936276912689e-01
    z[7,3,1]  R1983     -2.3312389850616455e-01
    z[7,3,1]  R1984     -3.2947105169296265e-01
    z[7,3,1]  R1985     4.0027368068695068e-01
    z[7,3,1]  R1986     -6.2102526426315308e-02
    z[7,3,1]  R1987     8.3066987991333008e-01
    z[7,3,1]  R1988     -1.1053048074245453e-01
    z[7,3,1]  R1989     6.7984503507614136e-01
    z[7,3,1]  R1990     6.7457187175750732e-01
    z[7,3,1]  R1991     -1.7039711773395538e-01
    z[7,3,1]  R1992     -1.3729162514209747e-01
    z[7,3,1]  R1993     2.9298362787812948e-03
    z[7,3,1]  R1994     8.2027778029441833e-02
    z[7,3,1]  R1995     7.8628820180892944e-01
    z[7,3,1]  R1996     0.228877454996109
    z[7,3,1]  R1997     1.7244207859039307e-01
    z[7,3,1]  R1998     3.3402338624000549e-01
    z[7,3,1]  R1999     -0.778550386428833
    z[7,3,1]  R2000     1.2658137083053589e-01
    z[7,3,1]  R2001     -4.0987440943717957e-01
    z[7,3,1]  R2002     -1.7743816599249840e-02
    z[7,3,1]  R2003     1.5095029026269913e-02
    z[7,3,1]  R2004     1.3860325515270233e-01
    z[7,3,1]  R2005     0.219833105802536
    z[7,3,1]  R2006     0.278201162815094
    z[7,3,1]  R2007     3.0335025861859322e-02
    z[7,3,1]  R2008     -6.4056468009948730e-01
    z[7,3,1]  R2009     -5.5411326885223389e-01
    z[7,3,1]  R2010     5.4294317960739136e-01
    z[7,3,1]  R2011     2.1319216489791870e-01
    z[7,3,1]  R2012     7.0009982585906982e-01
    z[7,3,1]  R2013     -1.4219549298286438e-01
    z[7,3,1]  R2014     4.1987210512161255e-01
    z[7,3,1]  R2015     -4.9000686407089233e-01
    z[7,3,1]  R2016     -2.4379158020019531e-01
    z[7,3,1]  R2017     -1.9936127960681915e-01
    z[7,3,1]  R2018     1.3906867243349552e-02
    z[7,3,1]  R2019     1.0930828005075455e-01
    z[7,3,1]  R2020     -3.1919276714324951e-01
    z[7,3,1]  R2021     -6.4516997337341309e-01
    z[7,3,1]  R2022     -4.2915329337120056e-01
    z[7,3,1]  R2023     2.8473719954490662e-01
    z[7,3,1]  R2024     -3.1105524301528931e-01
    z[7,3,1]  R2025     -2.6590937376022339e-01
    z[7,3,1]  R2026     -5.6255763769149780e-01
    z[7,3,1]  R2027     -3.5914209485054016e-01
    z[7,3,1]  R2028     1.9825773313641548e-02
    z[7,3,1]  R2029     -7.7108982950448990e-03
    z[7,3,2]  R31       1
    z[7,3,2]  R67       -1
    z[7,3,2]  R1951     -1
    z[7,3,2]  R1952     1
    z[7,3,2]  R1961     8.8125967979431152e-01
    z[7,3,2]  R1962     8.7643355131149292e-01
    z[7,3,2]  R1963     8.7768596410751343e-01
    z[7,3,2]  R1964     7.1278828382492065e-01
    z[7,3,2]  R1965     5.1686805486679077e-01
    z[7,3,2]  R1966     7.8773558139801025e-01
    z[7,3,2]  R1967     5.2271687984466553e-01
    z[7,3,2]  R1968     5.4136687517166138e-01
    z[7,3,2]  R1969     8.6033004522323608e-01
    z[7,3,2]  R1970     3.5049009323120117e-01
    z[7,3,2]  R1971     -1.5173679590225220e-01
    z[7,3,2]  R1972     -1.2127404659986496e-01
    z[7,3,2]  R1973     5.2269272506237030e-02
    z[7,3,2]  R1974     0.067268505692482
    z[7,3,2]  R1975     3.1443178653717041e-01
    z[7,3,2]  R1976     -6.9947414100170135e-02
    z[7,3,2]  R1977     4.9026903510093689e-01
    z[7,3,2]  R1978     -1.1069977283477783e-01
    z[7,3,2]  R1979     -1.5725065767765045e-01
    z[7,3,2]  R1980     -5.0107151269912720e-02
    z[7,3,2]  R1981     1.5685613453388214e-01
    z[7,3,2]  R1982     6.5976572036743164e-01
    z[7,3,2]  R1983     6.0806733369827271e-01
    z[7,3,2]  R1984     6.1673003435134888e-01
    z[7,3,2]  R1985     -2.2239057719707489e-01
    z[7,3,2]  R1986     1.4230807125568390e-01
    z[7,3,2]  R1987     3.3870470523834229e-01
    z[7,3,2]  R1988     0.274432510137558
    z[7,3,2]  R1989     2.4938605725765228e-01
    z[7,3,2]  R1990     -1.8986427783966064e-01
    z[7,3,2]  R1991     8.6477959156036377e-01
    z[7,3,2]  R1992     4.5375841856002808e-01
    z[7,3,2]  R1993     7.2029000520706177e-01
    z[7,3,2]  R1994     1.0285206884145737e-01
    z[7,3,2]  R1995     7.4434056878089905e-03
    z[7,3,2]  R1996     -2.0413251221179962e-01
    z[7,3,2]  R1997     -2.1016301214694977e-01
    z[7,3,2]  R1998     -1.7740696668624878e-01
    z[7,3,2]  R1999     -1.4455151557922363e-01
    z[7,3,2]  R2000     6.9000810384750366e-01
    z[7,3,2]  R2001     0.210184246301651
    z[7,3,2]  R2002     1.1719269305467606e-01
    z[7,3,2]  R2003     6.9620794057846069e-01
    z[7,3,2]  R2004     3.2710447907447815e-01
    z[7,3,2]  R2005     5.0952249765396118e-01
    z[7,3,2]  R2006     7.6343074440956116e-02
    z[7,3,2]  R2007     6.8611919879913330e-01
    z[7,3,2]  R2008     1.4378747344017029e-01
    z[7,3,2]  R2009     -0.062874436378479
    z[7,3,2]  R2010     -2.8643596172332764e-01
    z[7,3,2]  R2011     -6.5241509675979614e-01
    z[7,3,2]  R2012     -1.8200229108333588e-01
    z[7,3,2]  R2013     -2.4465499818325043e-01
    z[7,3,2]  R2014     -2.4278061091899872e-01
    z[7,3,2]  R2015     -5.4686951637268066e-01
    z[7,3,2]  R2016     1.7173700034618378e-02
    z[7,3,2]  R2017     -7.0712512731552124e-01
    z[7,3,2]  R2018     -6.5931832790374756e-01
    z[7,3,2]  R2019     -4.0237104892730713e-01
    z[7,3,2]  R2020     -3.7199565768241882e-01
    z[7,3,2]  R2021     -1.3697220385074615e-01
    z[7,3,2]  R2022     -7.1549135446548462e-01
    z[7,3,2]  R2023     -1.8416188657283783e-01
    z[7,3,2]  R2024     -4.1858857870101929e-01
    z[7,3,2]  R2025     1.5182051062583923e-01
    z[7,3,2]  R2026     -3.4829905629158020e-01
    z[7,3,2]  R2027     -5.8139652013778687e-01
    z[7,3,2]  R2028     1.2566743791103363e-01
    z[7,3,2]  R2029     -0.649156391620636
    z[7,3,3]  R32       1
    z[7,3,3]  R68       -1
    z[7,3,3]  R1953     -1
    z[7,3,3]  R1954     1
    z[7,3,3]  R1961     -1.6969552636146545e-01
    z[7,3,3]  R1962     -1.1241710186004639e-01
    z[7,3,3]  R1963     -2.3333995044231415e-01
    z[7,3,3]  R1964     -2.4053138494491577e-01
    z[7,3,3]  R1965     -3.0179014801979065e-01
    z[7,3,3]  R1966     -0.180845707654953
    z[7,3,3]  R1967     -4.8619282245635986e-01
    z[7,3,3]  R1968     -5.4015350341796875e-01
    z[7,3,3]  R1969     8.8432110846042633e-02
    z[7,3,3]  R1970     -1.5006552636623383e-01
    z[7,3,3]  R1971     4.9502205848693848e-01
    z[7,3,3]  R1972     3.9076185226440430e-01
    z[7,3,3]  R1973     0.510936975479126
    z[7,3,3]  R1974     3.9284959435462952e-01
    z[7,3,3]  R1975     2.4078071117401123e-01
    z[7,3,3]  R1976     -2.4797025322914124e-01
    z[7,3,3]  R1977     2.2925460338592529e-01
    z[7,3,3]  R1978     -5.6692969799041748e-01
    z[7,3,3]  R1979     -5.0393766164779663e-01
    z[7,3,3]  R1980     -7.1790444850921631e-01
    z[7,3,3]  R1981     -2.2077558934688568e-01
    z[7,3,3]  R1982     5.5741715431213379e-01
    z[7,3,3]  R1983     -4.4713595509529114e-01
    z[7,3,3]  R1984     -8.7472721934318542e-02
    z[7,3,3]  R1985     -1.6879495233297348e-02
    z[7,3,3]  R1986     -8.6856320500373840e-02
    z[7,3,3]  R1987     1.0131967812776566e-01
    z[7,3,3]  R1988     5.2337951958179474e-02
    z[7,3,3]  R1989     0.369122713804245
    z[7,3,3]  R1990     4.4091975688934326e-01
    z[7,3,3]  R1991     -1.9173561036586761e-01
    z[7,3,3]  R1992     -0.296233594417572
    z[7,3,3]  R1993     2.7814612258225679e-03
    z[7,3,3]  R1994     -1.3853618502616882e-01
    z[7,3,3]  R1995     1.1580002307891846e-01
    z[7,3,3]  R1996     4.3408408761024475e-01
    z[7,3,3]  R1997     3.2856735587120056e-01
    z[7,3,3]  R1998     3.6119055747985840e-01
    z[7,3,3]  R1999     2.2066141664981842e-01
    z[7,3,3]  R2000     1.3518603146076202e-01
    z[7,3,3]  R2001     -6.0827100276947021e-01
    z[7,3,3]  R2002     -4.3505945801734924e-01
    z[7,3,3]  R2003     -1.0539470240473747e-02
    z[7,3,3]  R2004     -6.3690222799777985e-02
    z[7,3,3]  R2005     -4.0693020820617676e-01
    z[7,3,3]  R2006     -2.1456105634570122e-02
    z[7,3,3]  R2007     -4.7923552989959717e-01
    z[7,3,3]  R2008     -3.9578646421432495e-02
    z[7,3,3]  R2009     -3.6662086844444275e-01
    z[7,3,3]  R2010     3.9195086807012558e-02
    z[7,3,3]  R2011     4.0870717167854309e-01
    z[7,3,3]  R2012     1.4911645650863647e-01
    z[7,3,3]  R2013     -0.0082710487768054
    z[7,3,3]  R2014     1.2566968798637390e-01
    z[7,3,3]  R2015     -7.5368061661720276e-03
    z[7,3,3]  R2016     2.3450877051800489e-03
    z[7,3,3]  R2017     -1.7732071876525879e-01
    z[7,3,3]  R2018     -5.8723551034927368e-01
    z[7,3,3]  R2019     -6.1758917570114136e-01
    z[7,3,3]  R2020     -1.6537846624851227e-01
    z[7,3,3]  R2021     -1.5702915191650391e-01
    z[7,3,3]  R2022     -1.2456391006708145e-01
    z[7,3,3]  R2023     2.1796748042106628e-01
    z[7,3,3]  R2024     -3.2868149876594543e-01
    z[7,3,3]  R2025     -2.8656652569770813e-01
    z[7,3,3]  R2026     -3.3567818999290466e-01
    z[7,3,3]  R2027     -6.9308197498321533e-01
    z[7,3,3]  R2028     1.7923320829868317e-01
    z[7,3,3]  R2029     -4.1287642717361450e-01
    z[7,3,4]  R33       1
    z[7,3,4]  R69       -1
    z[7,3,4]  R1955     -1
    z[7,3,4]  R1956     1
    z[7,3,4]  R1961     1.1278350651264191e-01
    z[7,3,4]  R1962     0.0964094027876854
    z[7,3,4]  R1963     -3.4093859791755676e-01
    z[7,3,4]  R1964     -2.3012995719909668e-01
    z[7,3,4]  R1965     5.2285179495811462e-02
    z[7,3,4]  R1966     -6.0546919703483582e-02
    z[7,3,4]  R1967     -1.0873212665319443e-01
    z[7,3,4]  R1968     2.2681656479835510e-01
    z[7,3,4]  R1969     2.5383159518241882e-01
    z[7,3,4]  R1970     -7.2736762464046478e-02
    z[7,3,4]  R1971     3.4567296504974365e-02
    z[7,3,4]  R1972     3.1856021285057068e-01
    z[7,3,4]  R1973     1.6540652513504028e-01
    z[7,3,4]  R1974     1.2471586465835571e-01
    z[7,3,4]  R1975     2.7911895513534546e-01
    z[7,3,4]  R1976     7.0714193582534790e-01
    z[7,3,4]  R1977     3.3558797091245651e-02
    z[7,3,4]  R1978     -1.0612443834543228e-01
    z[7,3,4]  R1979     3.7346008419990540e-01
    z[7,3,4]  R1980     2.9410016536712646e-01
    z[7,3,4]  R1981     4.2312777042388916e-01
    z[7,3,4]  R1982     2.4257218837738037e-01
    z[7,3,4]  R1983     3.4185758233070374e-01
    z[7,3,4]  R1984     1.1368550360202789e-01
    z[7,3,4]  R1985     -3.2543146610260010e-01
    z[7,3,4]  R1986     -5.5780386924743652e-01
    z[7,3,4]  R1987     6.2212649732828140e-02
    z[7,3,4]  R1988     2.2808945178985596e-01
    z[7,3,4]  R1989     -2.0683406293392181e-01
    z[7,3,4]  R1990     -2.8593108057975769e-01
    z[7,3,4]  R1991     2.2274306043982506e-02
    z[7,3,4]  R1992     1.4186917245388031e-01
    z[7,3,4]  R1993     2.1276238560676575e-01
    z[7,3,4]  R1994     -7.1415370702743530e-01
    z[7,3,4]  R1995     -4.6594056487083435e-01
    z[7,3,4]  R1996     1.4941351255401969e-03
    z[7,3,4]  R1997     -0.258316308259964
    z[7,3,4]  R1998     -6.5026766061782837e-01
    z[7,3,4]  R1999     -3.6814033985137939e-01
    z[7,3,4]  R2000     -4.0334054827690125e-01
    z[7,3,4]  R2001     3.4928798675537109e-01
    z[7,3,4]  R2002     3.3656361699104309e-01
    z[7,3,4]  R2003     1.7802956700325012e-01
    z[7,3,4]  R2004     2.6296606659889221e-01
    z[7,3,4]  R2005     -3.5195663571357727e-02
    z[7,3,4]  R2006     2.0981298387050629e-01
    z[7,3,4]  R2007     -2.1187800168991089e-01
    z[7,3,4]  R2008     1.7886583507061005e-01
    z[7,3,4]  R2009     -1.1789031559601426e-03
    z[7,3,4]  R2010     -0.558672308921814
    z[7,3,4]  R2011     -1.1019662767648697e-01
    z[7,3,4]  R2012     -5.5909123271703720e-02
    z[7,3,4]  R2013     -9.2242914438247681e-01
    z[7,3,4]  R2014     5.5569779872894287e-01
    z[7,3,4]  R2015     4.8192042112350464e-01
    z[7,3,4]  R2016     -5.4806423187255859e-01
    z[7,3,4]  R2017     3.2528510689735413e-01
    z[7,3,4]  R2018     1.6369768977165222e-01
    z[7,3,4]  R2019     -3.7840676307678223e-01
    z[7,3,4]  R2020     1.8910128623247147e-02
    z[7,3,4]  R2021     -2.6657721027731895e-02
    z[7,3,4]  R2022     4.0477478504180908e-01
    z[7,3,4]  R2023     5.5097335577011108e-01
    z[7,3,4]  R2024     0.349839985370636
    z[7,3,4]  R2025     -2.0136989653110504e-01
    z[7,3,4]  R2026     4.9555456638336182e-01
    z[7,3,4]  R2027     -1.2139406055212021e-01
    z[7,3,4]  R2028     4.4311735033988953e-01
    z[7,3,4]  R2029     1.1949014663696289e-01
    z[7,3,5]  R34       1
    z[7,3,5]  R70       -1
    z[7,3,5]  R1957     -1
    z[7,3,5]  R1958     1
    z[7,3,5]  R1961     -2.4292354285717010e-01
    z[7,3,5]  R1962     -8.5357002913951874e-02
    z[7,3,5]  R1963     1.1845561116933823e-01
    z[7,3,5]  R1964     -7.3580518364906311e-02
    z[7,3,5]  R1965     1.1728803068399429e-01
    z[7,3,5]  R1966     -1.0707467794418335e-01
    z[7,3,5]  R1967     1.5568982064723969e-01
    z[7,3,5]  R1968     7.0412173867225647e-02
    z[7,3,5]  R1969     -6.2022916972637177e-02
    z[7,3,5]  R1970     1.1527665704488754e-01
    z[7,3,5]  R1971     1.1195374280214310e-01
    z[7,3,5]  R1972     -0.0772845670580864
    z[7,3,5]  R1973     -4.8617967963218689e-01
    z[7,3,5]  R1974     0.549161970615387
    z[7,3,5]  R1975     6.5689951181411743e-01
    z[7,3,5]  R1976     2.4671067297458649e-01
    z[7,3,5]  R1977     7.8949761390686035e-01
    z[7,3,5]  R1978     -2.3483854532241821e-01
    z[7,3,5]  R1979     -5.4759597778320312e-01
    z[7,3,5]  R1980     1.0023871809244156e-01
    z[7,3,5]  R1981     -3.8677930831909180e-01
    z[7,3,5]  R1982     -4.4197618961334229e-02
    z[7,3,5]  R1983     1.2097232788801193e-01
    z[7,3,5]  R1984     0.698793888092041
    z[7,3,5]  R1985     3.5054400563240051e-01
    z[7,3,5]  R1986     5.4406970739364624e-01
    z[7,3,5]  R1987     1.7084047198295593e-01
    z[7,3,5]  R1988     -2.6089626550674438e-01
    z[7,3,5]  R1989     4.4805806875228882e-01
    z[7,3,5]  R1990     -2.2655102610588074e-01
    z[7,3,5]  R1991     1.8287371098995209e-01
    z[7,3,5]  R1992     2.0882815122604370e-01
    z[7,3,5]  R1993     2.4814268946647644e-01
    z[7,3,5]  R1994     1.8580763041973114e-01
    z[7,3,5]  R1995     3.4732723236083984e-01
    z[7,3,5]  R1996     0.00392861757427454
    z[7,3,5]  R1997     2.0078346133232117e-01
    z[7,3,5]  R1998     1.2518773972988129e-01
    z[7,3,5]  R1999     -3.2741820812225342e-01
    z[7,3,5]  R2000     -3.3380375243723392e-03
    z[7,3,5]  R2001     -4.9794283509254456e-01
    z[7,3,5]  R2002     2.7872281149029732e-02
    z[7,3,5]  R2003     -5.2084422111511230e-01
    z[7,3,5]  R2004     5.1263108849525452e-02
    z[7,3,5]  R2005     -2.9249009490013123e-01
    z[7,3,5]  R2006     -5.3765302896499634e-01
    z[7,3,5]  R2007     -3.2040674239397049e-02
    z[7,3,5]  R2008     -3.8281852006912231e-01
    z[7,3,5]  R2009     -0.539277970790863
    z[7,3,5]  R2010     2.6998212933540344e-01
    z[7,3,5]  R2011     1.4770534634590149e-01
    z[7,3,5]  R2012     1.8912889063358307e-01
    z[7,3,5]  R2013     0.0660073533654213
    z[7,3,5]  R2014     3.3002045750617981e-01
    z[7,3,5]  R2015     3.6354464292526245e-01
    z[7,3,5]  R2016     5.6534707546234131e-01
    z[7,3,5]  R2017     4.8115104436874390e-03
    z[7,3,5]  R2018     7.7572362497448921e-03
    z[7,3,5]  R2019     -1.5721473097801208e-01
    z[7,3,5]  R2020     -7.6816070079803467e-01
    z[7,3,5]  R2021     -1.1064589023590088e-01
    z[7,3,5]  R2022     -3.1259015202522278e-01
    z[7,3,5]  R2023     4.6183642745018005e-01
    z[7,3,5]  R2024     9.8798334598541260e-02
    z[7,3,5]  R2025     -0.185917928814888
    z[7,3,5]  R2026     0.307997465133667
    z[7,3,5]  R2027     3.8070093840360641e-02
    z[7,3,5]  R2028     -6.6336655616760254e-01
    z[7,3,5]  R2029     -5.6838154792785645e-01
    z[7,3,6]  R35       1
    z[7,3,6]  R71       -1
    z[7,3,6]  R1959     -1
    z[7,3,6]  R1960     1
    z[7,3,6]  R1961     1.6439394652843475e-01
    z[7,3,6]  R1962     -3.1777936220169067e-01
    z[7,3,6]  R1963     6.2210746109485626e-02
    z[7,3,6]  R1964     3.3947363495826721e-01
    z[7,3,6]  R1965     -3.2035343348979950e-02
    z[7,3,6]  R1966     1.3655607402324677e-01
    z[7,3,6]  R1967     -2.8108641505241394e-01
    z[7,3,6]  R1968     -1.0922054201364517e-01
    z[7,3,6]  R1969     1.3716332614421844e-01
    z[7,3,6]  R1970     -0.678911030292511
    z[7,3,6]  R1971     1.1422696709632874e-01
    z[7,3,6]  R1972     2.4225464463233948e-01
    z[7,3,6]  R1973     -1.6875217854976654e-01
    z[7,3,6]  R1974     1.4720532298088074e-01
    z[7,3,6]  R1975     -3.1331443786621094e-01
    z[7,3,6]  R1976     -6.5803073346614838e-02
    z[7,3,6]  R1977     2.2200700640678406e-01
    z[7,3,6]  R1978     -2.5692167878150940e-01
    z[7,3,6]  R1979     8.5210867226123810e-02
    z[7,3,6]  R1980     1.9927003979682922e-01
    z[7,3,6]  R1981     2.0807354152202606e-01
    z[7,3,6]  R1982     2.1896330639719963e-02
    z[7,3,6]  R1983     3.7601059675216675e-01
    z[7,3,6]  R1984     1.6459560021758080e-02
    z[7,3,6]  R1985     -2.3615995049476624e-01
    z[7,3,6]  R1986     -1.0659363120794296e-01
    z[7,3,6]  R1987     0.335407018661499
    z[7,3,6]  R1988     -6.6985177993774414e-01
    z[7,3,6]  R1989     -1.8572930991649628e-01
    z[7,3,6]  R1990     -2.6486387848854065e-01
    z[7,3,6]  R1991     -2.6600521802902222e-01
    z[7,3,6]  R1992     5.1743984222412109e-01
    z[7,3,6]  R1993     4.7477385401725769e-01
    z[7,3,6]  R1994     -2.8453102707862854e-01
    z[7,3,6]  R1995     -1.1456419527530670e-01
    z[7,3,6]  R1996     3.7997469305992126e-02
    z[7,3,6]  R1997     -1.3189387321472168e-01
    z[7,3,6]  R1998     4.3488770723342896e-01
    z[7,3,6]  R1999     2.3143112659454346e-01
    z[7,3,6]  R2000     1.0549000650644302e-01
    z[7,3,6]  R2001     4.4506066478788853e-03
    z[7,3,6]  R2002     -1.3924518227577209e-01
    z[7,3,6]  R2003     -1.4651606976985931e-01
    z[7,3,6]  R2004     -2.4712134897708893e-01
    z[7,3,6]  R2005     -3.5546213388442993e-02
    z[7,3,6]  R2006     -1.0249412804841995e-01
    z[7,3,6]  R2007     -1.7948724329471588e-01
    z[7,3,6]  R2008     -5.9537172317504883e-01
    z[7,3,6]  R2009     -5.0708043575286865e-01
    z[7,3,6]  R2010     0.264161080121994
    z[7,3,6]  R2011     -1.7609673738479614e-01
    z[7,3,6]  R2012     6.0599303245544434e-01
    z[7,3,6]  R2013     -5.4570611566305161e-02
    z[7,3,6]  R2014     4.6261945366859436e-01
    z[7,3,6]  R2015     -0.081184022128582
    z[7,3,6]  R2016     5.6252133846282959e-01
    z[7,3,6]  R2017     3.4647822380065918e-01
    z[7,3,6]  R2018     4.0271830558776855e-01
    z[7,3,6]  R2019     4.8912355303764343e-01
    z[7,3,6]  R2020     -8.0639824271202087e-02
    z[7,3,6]  R2021     -2.5323250889778137e-01
    z[7,3,6]  R2022     -1.4548771083354950e-01
    z[7,3,6]  R2023     1.6157284379005432e-01
    z[7,3,6]  R2024     3.5315132141113281e-01
    z[7,3,6]  R2025     2.0211941003799438e-01
    z[7,3,6]  R2026     -7.6526342891156673e-03
    z[7,3,6]  R2027     0.124819315969944
    z[7,3,6]  R2028     2.3658286035060883e-01
    z[7,3,6]  R2029     2.1239617466926575e-01
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R2074     -1
    z[4,5,0]  R2075     1
    z[4,5,0]  R2088     -7.5595939159393311e-01
    z[4,5,0]  R2089     -3.8382682204246521e-01
    z[4,5,0]  R2090     -3.0085310339927673e-01
    z[4,5,0]  R2091     -4.3898898363113403e-01
    z[4,5,0]  R2092     -5.3916312754154205e-02
    z[4,5,0]  R2093     2.0261155068874359e-01
    z[4,5,0]  R2094     -3.3357802033424377e-01
    z[4,5,0]  R2095     -4.6541181206703186e-01
    z[4,5,0]  R2096     -1.7482081055641174e-01
    z[4,5,0]  R2097     -3.2698640227317810e-01
    z[4,5,0]  R2098     -2.0467326045036316e-01
    z[4,5,0]  R2099     3.1608107686042786e-01
    z[4,5,0]  R2100     1.9089536741375923e-02
    z[4,5,0]  R2101     3.4732836484909058e-01
    z[4,5,0]  R2102     8.6776286363601685e-01
    z[4,5,0]  R2103     -6.4097873866558075e-02
    z[4,5,0]  R2104     9.2839550971984863e-01
    z[4,5,0]  R2105     8.8717746734619141e-01
    z[4,5,0]  R2106     0.766423225402832
    z[4,5,0]  R2107     8.0424225330352783e-01
    z[4,5,0]  R2108     2.6922184973955154e-02
    z[4,5,0]  R2109     -3.1197193264961243e-01
    z[4,5,0]  R2110     -4.2019522190093994e-01
    z[4,5,0]  R2111     8.5720755159854889e-02
    z[4,5,0]  R2112     -4.9759708344936371e-02
    z[4,5,0]  R2113     5.1685433834791183e-02
    z[4,5,0]  R2114     1.4829632639884949e-01
    z[4,5,0]  R2115     1.6176998615264893e-01
    z[4,5,0]  R2116     2.3579502105712891e-01
    z[4,5,0]  R2117     -1.4668072760105133e-01
    z[4,5,0]  R2118     -2.1438447292894125e-03
    z[4,5,0]  R2119     3.1725355982780457e-01
    z[4,5,0]  R2120     -1.7180384695529938e-01
    z[4,5,0]  R2121     -6.9005347788333893e-02
    z[4,5,0]  R2122     5.3096253424882889e-02
    z[4,5,0]  R2123     2.0548075437545776e-01
    z[4,5,0]  R2124     3.2522976398468018e-01
    z[4,5,0]  R2125     -5.1012493669986725e-02
    z[4,5,0]  R2126     9.2113900184631348e-01
    z[4,5,0]  R2127     5.6456762552261353e-01
    z[4,5,0]  R2128     -3.2004863023757935e-01
    z[4,5,0]  R2129     -1.2148412875831127e-02
    z[4,5,0]  R2130     -6.3843570649623871e-02
    z[4,5,0]  R2131     -5.1655262708663940e-02
    z[4,5,0]  R2132     -1.8021368980407715e-01
    z[4,5,0]  R2133     -1.5424399077892303e-01
    z[4,5,0]  R2134     1.2154664099216461e-01
    z[4,5,0]  R2135     8.8347233831882477e-02
    z[4,5,0]  R2136     -2.8340601921081543e-01
    z[4,5,0]  R2137     4.0016490221023560e-01
    z[4,5,0]  R2138     -2.0374859869480133e-01
    z[4,5,0]  R2139     -1.8331326544284821e-01
    z[4,5,0]  R2140     -2.9987642168998718e-01
    z[4,5,0]  R2141     -4.0957161784172058e-01
    z[4,5,0]  R2142     -2.1545775234699249e-01
    z[4,5,0]  R2143     -9.7865886986255646e-02
    z[4,5,0]  R2144     3.2939872145652771e-01
    z[4,5,0]  R2145     3.6172747611999512e-01
    z[4,5,0]  R2146     6.9161552190780640e-01
    z[4,5,0]  R2147     8.4867948293685913e-01
    z[4,5,0]  R2148     3.0808833241462708e-01
    z[4,5,0]  R2149     -1.6845524311065674e-01
    z[4,5,0]  R2150     -1.5884728729724884e-01
    z[4,5,0]  R2151     7.8646093606948853e-03
    z[4,5,0]  R2152     -3.8685572147369385e-01
    z[4,5,0]  R2153     -1.5796563029289246e-01
    z[4,5,0]  R2154     -1.0707242041826248e-01
    z[4,5,0]  R2155     9.2819523811340332e-01
    z[4,5,0]  R2156     9.1676068305969238e-01
    z[4,5,0]  R2157     8.5742688179016113e-01
    z[4,5,0]  R2158     1.1749872565269470e-01
    z[4,5,0]  R2159     -1.0967695713043213e-01
    z[4,5,0]  R2160     -9.1911517083644867e-02
    z[4,5,0]  R2161     -1.7805531620979309e-01
    z[4,5,0]  R2162     -2.5043404102325439e-01
    z[4,5,0]  R2163     2.8830792754888535e-02
    z[4,5,0]  R2164     -5.3877104073762894e-02
    z[4,5,0]  R2165     7.6644057035446167e-01
    z[4,5,0]  R2166     4.5327857136726379e-01
    z[4,5,0]  R2167     7.2841495275497437e-01
    z[4,5,0]  R2168     -1.5652939677238464e-01
    z[4,5,0]  R2169     -4.5320162177085876e-01
    z[4,5,0]  R2170     8.3178174495697021e-01
    z[4,5,0]  R2171     0.865403413772583
    z[4,5,0]  R2172     6.3283419609069824e-01
    z[4,5,0]  R2173     8.7871414422988892e-01
    z[4,5,0]  R2174     3.6707940697669983e-01
    z[4,5,0]  R2175     6.1472576856613159e-01
    z[4,5,0]  R2176     4.5549169182777405e-01
    z[4,5,0]  R2177     4.5406249165534973e-01
    z[4,5,0]  R2178     -2.6823753118515015e-01
    z[4,5,0]  R2179     -6.5219156444072723e-02
    z[4,5,0]  R2180     -2.8410360217094421e-01
    z[4,5,0]  R2181     -4.4057813286781311e-01
    z[4,5,0]  R2182     -1.4141286909580231e-01
    z[4,5,0]  R2183     6.6742408275604248e-01
    z[4,5,0]  R2184     7.5001978874206543e-01
    z[4,5,0]  R2185     1.8080644309520721e-01
    z[4,5,0]  R2186     4.8582616448402405e-01
    z[4,5,0]  R2187     4.6337318420410156e-01
    z[4,5,0]  R2188     -3.2918116450309753e-01
    z[4,5,0]  R2189     -5.2980142831802368e-01
    z[4,5,0]  R2190     1.3590514659881592e-01
    z[4,5,0]  R2191     1.8562240898609161e-01
    z[4,5,0]  R2192     1.7441925406455994e-01
    z[4,5,0]  R2193     -9.4519846141338348e-02
    z[4,5,0]  R2194     4.6904768794775009e-02
    z[4,5,0]  R2195     -5.8192804455757141e-02
    z[4,5,0]  R2196     1.9962343573570251e-01
    z[4,5,0]  R2197     -0.294490784406662
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R2076     -1
    z[4,5,1]  R2077     1
    z[4,5,1]  R2088     -4.0895906090736389e-01
    z[4,5,1]  R2089     -5.5129384994506836e-01
    z[4,5,1]  R2090     -5.8258968591690063e-01
    z[4,5,1]  R2091     -4.0229967236518860e-01
    z[4,5,1]  R2092     -4.1316270828247070e-01
    z[4,5,1]  R2093     -4.2161974310874939e-01
    z[4,5,1]  R2094     9.1567748785018921e-01
    z[4,5,1]  R2095     6.6368746757507324e-01
    z[4,5,1]  R2096     7.1862238645553589e-01
    z[4,5,1]  R2097     6.2939703464508057e-01
    z[4,5,1]  R2098     -3.6118716001510620e-01
    z[4,5,1]  R2099     0.643488883972168
    z[4,5,1]  R2100     0.761551558971405
    z[4,5,1]  R2101     6.5792787075042725e-01
    z[4,5,1]  R2102     -3.0341061949729919e-01
    z[4,5,1]  R2103     4.7267517447471619e-01
    z[4,5,1]  R2104     -1.5194717049598694e-01
    z[4,5,1]  R2105     -8.1752061843872070e-02
    z[4,5,1]  R2106     -3.1761386990547180e-01
    z[4,5,1]  R2107     -2.4149794876575470e-01
    z[4,5,1]  R2108     7.0063757896423340e-01
    z[4,5,1]  R2109     0.634477436542511
    z[4,5,1]  R2110     5.1053810119628906e-01
    z[4,5,1]  R2111     6.3336014747619629e-01
    z[4,5,1]  R2112     0.571498453617096
    z[4,5,1]  R2113     0.624488890171051
    z[4,5,1]  R2114     6.8535220623016357e-01
    z[4,5,1]  R2115     6.0414552688598633e-01
    z[4,5,1]  R2116     0.617192268371582
    z[4,5,1]  R2117     4.7669410705566406e-01
    z[4,5,1]  R2118     -0.521144449710846
    z[4,5,1]  R2119     8.1455355882644653e-01
    z[4,5,1]  R2120     6.6145467758178711e-01
    z[4,5,1]  R2121     6.5821504592895508e-01
    z[4,5,1]  R2122     7.6134026050567627e-01
    z[4,5,1]  R2123     6.7953163385391235e-01
    z[4,5,1]  R2124     6.7852401733398438e-01
    z[4,5,1]  R2125     -2.8339993953704834e-01
    z[4,5,1]  R2126     -1.2914204597473145e-01
    z[4,5,1]  R2127     -2.7889639139175415e-01
    z[4,5,1]  R2128     0.661384105682373
    z[4,5,1]  R2129     6.8406271934509277e-01
    z[4,5,1]  R2130     0.609142005443573
    z[4,5,1]  R2131     6.1185771226882935e-01
    z[4,5,1]  R2132     5.1991587877273560e-01
    z[4,5,1]  R2133     5.0892251729965210e-01
    z[4,5,1]  R2134     6.2008982896804810e-01
    z[4,5,1]  R2135     5.8739626407623291e-01
    z[4,5,1]  R2136     4.4208192825317383e-01
    z[4,5,1]  R2137     -7.5490063428878784e-01
    z[4,5,1]  R2138     1.1428605020046234e-01
    z[4,5,1]  R2139     -5.4980587959289551e-01
    z[4,5,1]  R2140     6.8772667646408081e-01
    z[4,5,1]  R2141     5.7774698734283447e-01
    z[4,5,1]  R2142     6.1253947019577026e-01
    z[4,5,1]  R2143     6.3415187597274780e-01
    z[4,5,1]  R2144     7.2337609529495239e-01
    z[4,5,1]  R2145     6.5873426198959351e-01
    z[4,5,1]  R2146     -3.1618535518646240e-01
    z[4,5,1]  R2147     -2.2307717800140381e-01
    z[4,5,1]  R2148     0.907846212387085
    z[4,5,1]  R2149     7.8116118907928467e-01
    z[4,5,1]  R2150     6.5968692302703857e-01
    z[4,5,1]  R2151     7.1707624197006226e-01
    z[4,5,1]  R2152     5.8574253320693970e-01
    z[4,5,1]  R2153     6.7232650518417358e-01
    z[4,5,1]  R2154     5.0570577383041382e-01
    z[4,5,1]  R2155     -2.2589710354804993e-01
    z[4,5,1]  R2156     -6.9680139422416687e-02
    z[4,5,1]  R2157     -5.0524167716503143e-02
    z[4,5,1]  R2158     -4.7879534959793091e-01
    z[4,5,1]  R2159     8.4078276157379150e-01
    z[4,5,1]  R2160     8.1807190179824829e-01
    z[4,5,1]  R2161     7.6242613792419434e-01
    z[4,5,1]  R2162     7.4268090724945068e-01
    z[4,5,1]  R2163     7.8609466552734375e-01
    z[4,5,1]  R2164     5.7589423656463623e-01
    z[4,5,1]  R2165     -2.7718749642372131e-01
    z[4,5,1]  R2166     4.0824308991432190e-01
    z[4,5,1]  R2167     1.9695796072483063e-01
    z[4,5,1]  R2168     -3.7442067265510559e-01
    z[4,5,1]  R2169     5.4200363159179688e-01
    z[4,5,1]  R2170     -3.6016467213630676e-01
    z[4,5,1]  R2171     -1.0555035620927811e-01
    z[4,5,1]  R2172     -2.8569099307060242e-01
    z[4,5,1]  R2173     7.3532074689865112e-02
    z[4,5,1]  R2174     5.3862494230270386e-01
    z[4,5,1]  R2175     5.9677477926015854e-02
    z[4,5,1]  R2176     1.7477940022945404e-01
    z[4,5,1]  R2177     2.8231540322303772e-01
    z[4,5,1]  R2178     2.4573600292205811e-01
    z[4,5,1]  R2179     3.6279591917991638e-01
    z[4,5,1]  R2180     -6.1442929506301880e-01
    z[4,5,1]  R2181     2.6527587324380875e-02
    z[4,5,1]  R2182     -3.9439103007316589e-01
    z[4,5,1]  R2183     3.2276561856269836e-01
    z[4,5,1]  R2184     4.2350569367408752e-01
    z[4,5,1]  R2185     1.2853574752807617e-01
    z[4,5,1]  R2186     5.3194683790206909e-01
    z[4,5,1]  R2187     5.1429039239883423e-01
    z[4,5,1]  R2188     3.9422520995140076e-01
    z[4,5,1]  R2189     2.7047321200370789e-01
    z[4,5,1]  R2190     -7.6316612958908081e-01
    z[4,5,1]  R2191     -7.5528490543365479e-01
    z[4,5,1]  R2192     -7.9375445842742920e-01
    z[4,5,1]  R2193     -6.4786761999130249e-01
    z[4,5,1]  R2194     -7.3607826232910156e-01
    z[4,5,1]  R2195     -7.1364831924438477e-01
    z[4,5,1]  R2196     -7.4419844150543213e-01
    z[4,5,1]  R2197     -6.3241493701934814e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R2078     -1
    z[4,5,2]  R2079     1
    z[4,5,2]  R2088     5.2927613258361816e-02
    z[4,5,2]  R2089     -3.7967246770858765e-01
    z[4,5,2]  R2090     -6.2895250320434570e-01
    z[4,5,2]  R2091     -1.4505137503147125e-01
    z[4,5,2]  R2092     -3.4477221965789795e-01
    z[4,5,2]  R2093     -2.7408489584922791e-01
    z[4,5,2]  R2094     -1.8525023758411407e-01
    z[4,5,2]  R2095     9.5642521977424622e-02
    z[4,5,2]  R2096     7.1118585765361786e-02
    z[4,5,2]  R2097     1.3777109980583191e-01
    z[4,5,2]  R2098     5.7343918085098267e-01
    z[4,5,2]  R2099     3.6670535802841187e-02
    z[4,5,2]  R2100     1.3931621611118317e-01
    z[4,5,2]  R2101     6.4815413951873779e-01
    z[4,5,2]  R2102     -7.3000110685825348e-02
    z[4,5,2]  R2103     4.9809610843658447e-01
    z[4,5,2]  R2104     2.1548955142498016e-01
    z[4,5,2]  R2105     2.7396270632743835e-01
    z[4,5,2]  R2106     -1.0538420639932156e-02
    z[4,5,2]  R2107     1.9095709919929504e-01
    z[4,5,2]  R2108     -1.3599984347820282e-01
    z[4,5,2]  R2109     6.3948506116867065e-01
    z[4,5,2]  R2110     4.0348327159881592e-01
    z[4,5,2]  R2111     -9.1357663273811340e-02
    z[4,5,2]  R2112     2.3269453644752502e-01
    z[4,5,2]  R2113     2.8954052925109863e-01
    z[4,5,2]  R2114     9.3520984053611755e-02
    z[4,5,2]  R2115     3.6777067184448242e-01
    z[4,5,2]  R2116     4.8150235414505005e-01
    z[4,5,2]  R2117     1.8627518415451050e-01
    z[4,5,2]  R2118     7.9654440283775330e-02
    z[4,5,2]  R2119     -6.9881482049822807e-03
    z[4,5,2]  R2120     0.55242520570755
    z[4,5,2]  R2121     0.517589807510376
    z[4,5,2]  R2122     0.382357656955719
    z[4,5,2]  R2123     4.3718099594116211e-01
    z[4,5,2]  R2124     1.4393419027328491e-01
    z[4,5,2]  R2125     7.7611964941024780e-01
    z[4,5,2]  R2126     1.7767506837844849e-01
    z[4,5,2]  R2127     4.2432352900505066e-01
    z[4,5,2]  R2128     4.7660058736801147e-01
    z[4,5,2]  R2129     4.2518422007560730e-01
    z[4,5,2]  R2130     7.4195876717567444e-02
    z[4,5,2]  R2131     1.4133690297603607e-01
    z[4,5,2]  R2132     5.8930929750204086e-02
    z[4,5,2]  R2133     -1.5129742026329041e-01
    z[4,5,2]  R2134     -6.9181986153125763e-02
    z[4,5,2]  R2135     4.6942636370658875e-02
    z[4,5,2]  R2136     1.3853174448013306e-01
    z[4,5,2]  R2137     4.1284161806106567e-01
    z[4,5,2]  R2138     5.5429196357727051e-01
    z[4,5,2]  R2139     3.2978755235671997e-01
    z[4,5,2]  R2140     2.8025823831558228e-01
    z[4,5,2]  R2141     2.6140713691711426e-01
    z[4,5,2]  R2142     1.5084272250533104e-02
    z[4,5,2]  R2143     -1.9392465054988861e-01
    z[4,5,2]  R2144     -9.1017229715362191e-04
    z[4,5,2]  R2145     3.2170155644416809e-01
    z[4,5,2]  R2146     1.8902434408664703e-01
    z[4,5,2]  R2147     7.8653432428836823e-02
    z[4,5,2]  R2148     1.3745307922363281e-01
    z[4,5,2]  R2149     4.8542514443397522e-01
    z[4,5,2]  R2150     2.1271798014640808e-01
    z[4,5,2]  R2151     -1.8609980121254921e-02
    z[4,5,2]  R2152     1.2843313813209534e-01
    z[4,5,2]  R2153     5.8540576696395874e-01
    z[4,5,2]  R2154     1.0369451344013214e-01
    z[4,5,2]  R2155     1.0151851177215576e-01
    z[4,5,2]  R2156     2.9004657268524170e-01
    z[4,5,2]  R2157     4.6488952636718750e-01
    z[4,5,2]  R2158     1.6060872375965118e-01
    z[4,5,2]  R2159     -1.2836912274360657e-01
    z[4,5,2]  R2160     2.7374556660652161e-01
    z[4,5,2]  R2161     1.6982159018516541e-01
    z[4,5,2]  R2162     1.8278861045837402e-01
    z[4,5,2]  R2163     4.2374005913734436e-01
    z[4,5,2]  R2164     5.0773404538631439e-02
    z[4,5,2]  R2165     7.4549637734889984e-02
    z[4,5,2]  R2166     -6.2355047464370728e-01
    z[4,5,2]  R2167     3.8519951701164246e-01
    z[4,5,2]  R2168     4.8653751611709595e-02
    z[4,5,2]  R2169     4.1227829456329346e-01
    z[4,5,2]  R2170     -1.2187819182872772e-01
    z[4,5,2]  R2171     4.1454848647117615e-01
    z[4,5,2]  R2172     3.5861104726791382e-01
    z[4,5,2]  R2173     3.0075496435165405e-01
    z[4,5,2]  R2174     -0.518540620803833
    z[4,5,2]  R2175     2.9725831747055054e-01
    z[4,5,2]  R2176     3.5120970010757446e-01
    z[4,5,2]  R2177     3.8471260666847229e-01
    z[4,5,2]  R2178     -3.1426379084587097e-01
    z[4,5,2]  R2179     -3.8013070821762085e-01
    z[4,5,2]  R2180     -2.6275274157524109e-01
    z[4,5,2]  R2181     1.3911771774291992e-01
    z[4,5,2]  R2182     -4.1727340221405029e-01
    z[4,5,2]  R2183     -2.8148925304412842e-01
    z[4,5,2]  R2184     -1.5927772223949432e-01
    z[4,5,2]  R2185     3.7788701057434082e-01
    z[4,5,2]  R2186     2.7874574065208435e-01
    z[4,5,2]  R2187     -6.0055539011955261e-02
    z[4,5,2]  R2188     6.1995659023523331e-02
    z[4,5,2]  R2189     0.241798996925354
    z[4,5,2]  R2190     0.273393839597702
    z[4,5,2]  R2191     1.4513716101646423e-01
    z[4,5,2]  R2192     2.1221699193120003e-02
    z[4,5,2]  R2193     1.7214192450046539e-01
    z[4,5,2]  R2194     2.2800672054290771e-01
    z[4,5,2]  R2195     2.6251357793807983e-01
    z[4,5,2]  R2196     1.3650007545948029e-01
    z[4,5,2]  R2197     2.9738715291023254e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R2080     -1
    z[4,5,3]  R2081     1
    z[4,5,3]  R2088     1.6001372039318085e-01
    z[4,5,3]  R2089     2.8818270564079285e-01
    z[4,5,3]  R2090     -1.6304506361484528e-01
    z[4,5,3]  R2091     3.6362621188163757e-01
    z[4,5,3]  R2092     1.2032174319028854e-01
    z[4,5,3]  R2093     1.7823085188865662e-01
    z[4,5,3]  R2094     -3.5893155727535486e-03
    z[4,5,3]  R2095     -3.8156139850616455e-01
    z[4,5,3]  R2096     6.0356277227401733e-01
    z[4,5,3]  R2097     -2.8164786100387573e-01
    z[4,5,3]  R2098     -5.4171049594879150e-01
    z[4,5,3]  R2099     1.0718328505754471e-01
    z[4,5,3]  R2100     -0.0906682088971138
    z[4,5,3]  R2101     -6.5006553195416927e-03
    z[4,5,3]  R2102     8.5837788879871368e-02
    z[4,5,3]  R2103     2.3907181620597839e-01
    z[4,5,3]  R2104     4.7946058213710785e-02
    z[4,5,3]  R2105     -3.1040126085281372e-01
    z[4,5,3]  R2106     -4.5869520306587219e-01
    z[4,5,3]  R2107     -2.3695114254951477e-01
    z[4,5,3]  R2108     -0.384262353181839
    z[4,5,3]  R2109     0.0794503390789032
    z[4,5,3]  R2110     2.3354966938495636e-01
    z[4,5,3]  R2111     -3.7225788831710815e-01
    z[4,5,3]  R2112     -0.152827650308609
    z[4,5,3]  R2113     5.2892103791236877e-02
    z[4,5,3]  R2114     4.5519590377807617e-01
    z[4,5,3]  R2115     -5.3364926576614380e-01
    z[4,5,3]  R2116     -3.1549653410911560e-01
    z[4,5,3]  R2117     -5.7637596130371094e-01
    z[4,5,3]  R2118     -4.6700218319892883e-01
    z[4,5,3]  R2119     1.2275058031082153e-01
    z[4,5,3]  R2120     2.8028586506843567e-01
    z[4,5,3]  R2121     -2.9184681177139282e-01
    z[4,5,3]  R2122     4.9547683447599411e-02
    z[4,5,3]  R2123     1.1898304522037506e-01
    z[4,5,3]  R2124     1.1744812875986099e-01
    z[4,5,3]  R2125     1.3186505995690823e-02
    z[4,5,3]  R2126     2.9272291064262390e-01
    z[4,5,3]  R2127     -3.4841954708099365e-01
    z[4,5,3]  R2128     7.4020475149154663e-02
    z[4,5,3]  R2129     -3.4547463059425354e-01
    z[4,5,3]  R2130     -2.3175922036170959e-01
    z[4,5,3]  R2131     8.8113643229007721e-02
    z[4,5,3]  R2132     1.1977697908878326e-01
    z[4,5,3]  R2133     -3.4683072566986084e-01
    z[4,5,3]  R2134     -6.3989430665969849e-01
    z[4,5,3]  R2135     -4.4078847765922546e-01
    z[4,5,3]  R2136     -3.9069369435310364e-01
    z[4,5,3]  R2137     -1.4880749583244324e-01
    z[4,5,3]  R2138     6.0058438777923584e-01
    z[4,5,3]  R2139     -4.9394312500953674e-01
    z[4,5,3]  R2140     1.3339401781558990e-01
    z[4,5,3]  R2141     -3.6142196506261826e-02
    z[4,5,3]  R2142     -8.2534685730934143e-02
    z[4,5,3]  R2143     -4.1981092095375061e-01
    z[4,5,3]  R2144     -1.6490165144205093e-02
    z[4,5,3]  R2145     -4.8603683710098267e-01
    z[4,5,3]  R2146     -4.1447019577026367e-01
    z[4,5,3]  R2147     -1.4740024507045746e-01
    z[4,5,3]  R2148     -1.9657707214355469e-01
    z[4,5,3]  R2149     1.4049349725246429e-01
    z[4,5,3]  R2150     -5.3508497774600983e-02
    z[4,5,3]  R2151     -3.9368104934692383e-01
    z[4,5,3]  R2152     -4.3956348299980164e-01
    z[4,5,3]  R2153     -7.0799507200717926e-02
    z[4,5,3]  R2154     -3.5371506214141846e-01
    z[4,5,3]  R2155     -8.1046774983406067e-02
    z[4,5,3]  R2156     5.0250524654984474e-03
    z[4,5,3]  R2157     -1.6853669285774231e-01
    z[4,5,3]  R2158     3.2198518514633179e-01
    z[4,5,3]  R2159     -3.1587982177734375e-01
    z[4,5,3]  R2160     1.2399684637784958e-01
    z[4,5,3]  R2161     0.325998991727829
    z[4,5,3]  R2162     1.2346013635396957e-01
    z[4,5,3]  R2163     1.2125533074140549e-01
    z[4,5,3]  R2164     -3.0911889672279358e-01
    z[4,5,3]  R2165     -3.4176650643348694e-01
    z[4,5,3]  R2166     3.5552024841308594e-01
    z[4,5,3]  R2167     4.6924769878387451e-01
    z[4,5,3]  R2168     -2.5024303793907166e-01
    z[4,5,3]  R2169     -3.3788588643074036e-01
    z[4,5,3]  R2170     -3.6288508772850037e-01
    z[4,5,3]  R2171     -1.9072756171226501e-01
    z[4,5,3]  R2172     -4.1188588738441467e-01
    z[4,5,3]  R2173     1.1242207884788513e-01
    z[4,5,3]  R2174     5.2938532829284668e-01
    z[4,5,3]  R2175     3.5849779844284058e-01
    z[4,5,3]  R2176     6.4723688364028931e-01
    z[4,5,3]  R2177     4.5425498485565186e-01
    z[4,5,3]  R2178     -5.9839230775833130e-01
    z[4,5,3]  R2179     -5.6734341382980347e-01
    z[4,5,3]  R2180     -5.5254191160202026e-01
    z[4,5,3]  R2181     -0.86295485496521
    z[4,5,3]  R2182     5.8465588837862015e-02
    z[4,5,3]  R2183     5.6408715248107910e-01
    z[4,5,3]  R2184     1.9337294995784760e-01
    z[4,5,3]  R2185     7.1931129693984985e-01
    z[4,5,3]  R2186     1.1560782790184021e-01
    z[4,5,3]  R2187     2.3387832939624786e-01
    z[4,5,3]  R2188     0.283197283744812
    z[4,5,3]  R2189     3.9575561881065369e-01
    z[4,5,3]  R2190     2.7132576704025269e-01
    z[4,5,3]  R2191     3.9909040927886963e-01
    z[4,5,3]  R2192     4.2910179495811462e-01
    z[4,5,3]  R2193     4.4801110029220581e-01
    z[4,5,3]  R2194     3.9648792147636414e-01
    z[4,5,3]  R2195     2.7338972687721252e-01
    z[4,5,3]  R2196     1.7293485999107361e-01
    z[4,5,3]  R2197     4.2913112044334412e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R2082     -1
    z[4,5,4]  R2083     1
    z[4,5,4]  R2088     -1.1472114175558090e-01
    z[4,5,4]  R2089     -1.1252373456954956e-01
    z[4,5,4]  R2090     -2.7165785431861877e-02
    z[4,5,4]  R2091     -4.0477615594863892e-01
    z[4,5,4]  R2092     7.2668421268463135e-01
    z[4,5,4]  R2093     6.1354964971542358e-01
    z[4,5,4]  R2094     -9.9070511758327484e-02
    z[4,5,4]  R2095     0.409146249294281
    z[4,5,4]  R2096     -6.6583938896656036e-02
    z[4,5,4]  R2097     2.5064873695373535e-01
    z[4,5,4]  R2098     1.3133677840232849e-01
    z[4,5,4]  R2099     -3.3229254186153412e-02
    z[4,5,4]  R2100     -3.2199618220329285e-01
    z[4,5,4]  R2101     1.4842495322227478e-01
    z[4,5,4]  R2102     -3.7058830261230469e-01
    z[4,5,4]  R2103     6.1142629384994507e-01
    z[4,5,4]  R2104     -2.3097884654998779e-01
    z[4,5,4]  R2105     3.4388538450002670e-02
    z[4,5,4]  R2106     -3.0489778518676758e-01
    z[4,5,4]  R2107     -0.0886390283703804
    z[4,5,4]  R2108     3.1590268015861511e-01
    z[4,5,4]  R2109     2.3376764729619026e-03
    z[4,5,4]  R2110     3.7073215842247009e-01
    z[4,5,4]  R2111     4.4369032979011536e-01
    z[4,5,4]  R2112     4.6025916934013367e-01
    z[4,5,4]  R2113     3.5726550966501236e-02
    z[4,5,4]  R2114     3.6453232169151306e-01
    z[4,5,4]  R2115     -3.4587019681930542e-01
    z[4,5,4]  R2116     -2.4863809812813997e-03
    z[4,5,4]  R2117     -5.2206773310899734e-02
    z[4,5,4]  R2118     2.4215477705001831e-01
    z[4,5,4]  R2119     1.8904080986976624e-01
    z[4,5,4]  R2120     1.5691670775413513e-01
    z[4,5,4]  R2121     5.7197425514459610e-02
    z[4,5,4]  R2122     -1.7119950056076050e-01
    z[4,5,4]  R2123     3.0332329869270325e-01
    z[4,5,4]  R2124     -1.3827908039093018e-01
    z[4,5,4]  R2125     3.6695733666419983e-01
    z[4,5,4]  R2126     -1.0033635795116425e-01
    z[4,5,4]  R2127     -3.8435709476470947e-01
    z[4,5,4]  R2128     4.3267095088958740e-01
    z[4,5,4]  R2129     -2.3215970396995544e-01
    z[4,5,4]  R2130     -3.3439084887504578e-01
    z[4,5,4]  R2131     -1.2737533450126648e-01
    z[4,5,4]  R2132     2.2421942651271820e-01
    z[4,5,4]  R2133     -3.1862971186637878e-01
    z[4,5,4]  R2134     -1.4161466062068939e-01
    z[4,5,4]  R2135     -2.0014038681983948e-01
    z[4,5,4]  R2136     -1.7013674974441528e-01
    z[4,5,4]  R2137     -2.2357928752899170e-01
    z[4,5,4]  R2138     4.8134982585906982e-01
    z[4,5,4]  R2139     3.0386200547218323e-01
    z[4,5,4]  R2140     5.6228119134902954e-01
    z[4,5,4]  R2141     2.6087793707847595e-01
    z[4,5,4]  R2142     -1.7765650525689125e-02
    z[4,5,4]  R2143     5.7998904958367348e-03
    z[4,5,4]  R2144     -1.9561885297298431e-01
    z[4,5,4]  R2145     -1.5254600346088409e-01
    z[4,5,4]  R2146     -2.3245088756084442e-01
    z[4,5,4]  R2147     -2.4510839581489563e-01
    z[4,5,4]  R2148     3.4389652311801910e-02
    z[4,5,4]  R2149     1.6696244478225708e-01
    z[4,5,4]  R2150     3.9626786112785339e-01
    z[4,5,4]  R2151     -4.9778923392295837e-02
    z[4,5,4]  R2152     1.0410825908184052e-01
    z[4,5,4]  R2153     -3.0679020285606384e-01
    z[4,5,4]  R2154     2.2262823581695557e-01
    z[4,5,4]  R2155     -0.0813310518860817
    z[4,5,4]  R2156     9.8297655582427979e-02
    z[4,5,4]  R2157     9.0512603521347046e-02
    z[4,5,4]  R2158     4.6489360928535461e-01
    z[4,5,4]  R2159     -9.3833103775978088e-02
    z[4,5,4]  R2160     4.2973878979682922e-01
    z[4,5,4]  R2161     3.6662909388542175e-01
    z[4,5,4]  R2162     5.0199198722839355e-01
    z[4,5,4]  R2163     -4.3391962535679340e-03
    z[4,5,4]  R2164     1.9471764564514160e-01
    z[4,5,4]  R2165     -2.9023903608322144e-01
    z[4,5,4]  R2166     -2.7248394489288330e-01
    z[4,5,4]  R2167     -2.4616238474845886e-01
    z[4,5,4]  R2168     2.4163340032100677e-01
    z[4,5,4]  R2169     -2.2500516474246979e-01
    z[4,5,4]  R2170     -1.0002250224351883e-01
    z[4,5,4]  R2171     -7.6770171523094177e-02
    z[4,5,4]  R2172     -2.0987370610237122e-01
    z[4,5,4]  R2173     -1.0867885500192642e-01
    z[4,5,4]  R2174     -6.6451430320739746e-02
    z[4,5,4]  R2175     -5.7496535778045654e-01
    z[4,5,4]  R2176     -4.4193667173385620e-01
    z[4,5,4]  R2177     -4.9371123313903809e-01
    z[4,5,4]  R2178     3.9711022377014160e-01
    z[4,5,4]  R2179     -2.5315082073211670e-01
    z[4,5,4]  R2180     -2.7344502508640289e-02
    z[4,5,4]  R2181     -1.8611754477024078e-01
    z[4,5,4]  R2182     -2.6278665661811829e-01
    z[4,5,4]  R2183     2.2017116844654083e-01
    z[4,5,4]  R2184     1.1359731853008270e-01
    z[4,5,4]  R2185     -1.1853111535310745e-01
    z[4,5,4]  R2186     0.072480209171772
    z[4,5,4]  R2187     5.2598720788955688e-01
    z[4,5,4]  R2188     -5.6802171468734741e-01
    z[4,5,4]  R2189     -3.4810966253280640e-01
    z[4,5,4]  R2190     -1.0453492403030396e-01
    z[4,5,4]  R2191     -1.2242580950260162e-01
    z[4,5,4]  R2192     2.1998232230544090e-02
    z[4,5,4]  R2193     -3.9168462157249451e-01
    z[4,5,4]  R2194     1.8533350527286530e-01
    z[4,5,4]  R2195     1.9919458031654358e-01
    z[4,5,4]  R2196     -9.9543638527393341e-02
    z[4,5,4]  R2197     3.2287046313285828e-02
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R2084     -1
    z[4,5,5]  R2085     1
    z[4,5,5]  R2088     3.8111633062362671e-01
    z[4,5,5]  R2089     5.5571067333221436e-01
    z[4,5,5]  R2090     1.8060798943042755e-01
    z[4,5,5]  R2091     -1.1214573681354523e-01
    z[4,5,5]  R2092     1.6730263829231262e-01
    z[4,5,5]  R2093     5.3711807727813721e-01
    z[4,5,5]  R2094     7.2642147541046143e-02
    z[4,5,5]  R2095     1.1676761507987976e-01
    z[4,5,5]  R2096     -7.5571663677692413e-02
    z[4,5,5]  R2097     1.6545480489730835e-01
    z[4,5,5]  R2098     -4.1990029811859131e-01
    z[4,5,5]  R2099     -6.0991442203521729e-01
    z[4,5,5]  R2100     -4.6201825141906738e-01
    z[4,5,5]  R2101     0.0101442476734519
    z[4,5,5]  R2102     -6.8104475736618042e-02
    z[4,5,5]  R2103     -2.8355339169502258e-01
    z[4,5,5]  R2104     -7.7083487994968891e-03
    z[4,5,5]  R2105     -1.7236265540122986e-01
    z[4,5,5]  R2106     -2.4853106588125229e-02
    z[4,5,5]  R2107     -8.7030403316020966e-02
    z[4,5,5]  R2108     -1.6514272987842560e-01
    z[4,5,5]  R2109     -2.5870227813720703e-01
    z[4,5,5]  R2110     -4.4403988122940063e-01
    z[4,5,5]  R2111     -3.7668019533157349e-01
    z[4,5,5]  R2112     -2.0139142870903015e-01
    z[4,5,5]  R2113     -7.1815311908721924e-01
    z[4,5,5]  R2114     1.2453091889619827e-01
    z[4,5,5]  R2115     -2.5025227665901184e-01
    z[4,5,5]  R2116     -3.5274305939674377e-01
    z[4,5,5]  R2117     -6.1772572994232178e-01
    z[4,5,5]  R2118     -6.2005412578582764e-01
    z[4,5,5]  R2119     -4.0256899595260620e-01
    z[4,5,5]  R2120     3.3030384778976440e-01
    z[4,5,5]  R2121     4.0965270996093750e-01
    z[4,5,5]  R2122     -4.8622965812683105e-01
    z[4,5,5]  R2123     1.9258794188499451e-01
    z[4,5,5]  R2124     1.0406956821680069e-01
    z[4,5,5]  R2125     8.2377210259437561e-02
    z[4,5,5]  R2126     -8.4257304668426514e-02
    z[4,5,5]  R2127     3.9063131809234619e-01
    z[4,5,5]  R2128     1.0816441476345062e-01
    z[4,5,5]  R2129     0.349244624376297
    z[4,5,5]  R2130     -3.9362901449203491e-01
    z[4,5,5]  R2131     -5.9012597799301147e-01
    z[4,5,5]  R2132     -7.8150975704193115e-01
    z[4,5,5]  R2133     -6.7393243312835693e-01
    z[4,5,5]  R2134     -2.3224505782127380e-01
    z[4,5,5]  R2135     -6.3647961616516113e-01
    z[4,5,5]  R2136     -6.0548824071884155e-01
    z[4,5,5]  R2137     -1.4366070926189423e-01
    z[4,5,5]  R2138     4.4098678976297379e-02
    z[4,5,5]  R2139     -4.5739594101905823e-01
    z[4,5,5]  R2140     1.4385650865733624e-02
    z[4,5,5]  R2141     -5.9956979751586914e-01
    z[4,5,5]  R2142     -6.7116081714630127e-01
    z[4,5,5]  R2143     -5.8865559101104736e-01
    z[4,5,5]  R2144     -1.8110229074954987e-01
    z[4,5,5]  R2145     -1.0773810744285583e-01
    z[4,5,5]  R2146     2.6756206154823303e-01
    z[4,5,5]  R2147     1.8646885454654694e-01
    z[4,5,5]  R2148     -5.6428488343954086e-02
    z[4,5,5]  R2149     2.0217919349670410e-01
    z[4,5,5]  R2150     -3.9791306853294373e-01
    z[4,5,5]  R2151     -5.7171505689620972e-01
    z[4,5,5]  R2152     -3.4493902325630188e-01
    z[4,5,5]  R2153     7.1420714259147644e-02
    z[4,5,5]  R2154     3.5805463790893555e-01
    z[4,5,5]  R2155     -1.9722411036491394e-01
    z[4,5,5]  R2156     -1.6521330177783966e-01
    z[4,5,5]  R2157     -5.1570698618888855e-02
    z[4,5,5]  R2158     2.0275006070733070e-02
    z[4,5,5]  R2159     -3.8745424151420593e-01
    z[4,5,5]  R2160     -1.4860782027244568e-01
    z[4,5,5]  R2161     -2.1801829338073730e-01
    z[4,5,5]  R2162     2.8767675161361694e-01
    z[4,5,5]  R2163     -4.2009210586547852e-01
    z[4,5,5]  R2164     3.5468569397926331e-01
    z[4,5,5]  R2165     2.0468638837337494e-01
    z[4,5,5]  R2166     1.5067258477210999e-01
    z[4,5,5]  R2167     -2.4595342576503754e-02
    z[4,5,5]  R2168     -8.1414008140563965e-01
    z[4,5,5]  R2169     0.0750207006931305
    z[4,5,5]  R2170     -0.131648451089859
    z[4,5,5]  R2171     1.3997261226177216e-01
    z[4,5,5]  R2172     2.8227525949478149e-01
    z[4,5,5]  R2173     1.3914388418197632e-01
    z[4,5,5]  R2174     1.4618138968944550e-01
    z[4,5,5]  R2175     -1.0838557034730911e-01
    z[4,5,5]  R2176     -1.1386824399232864e-01
    z[4,5,5]  R2177     1.1800454556941986e-01
    z[4,5,5]  R2178     -3.6672794818878174e-01
    z[4,5,5]  R2179     -5.5276203155517578e-01
    z[4,5,5]  R2180     -4.0194973349571228e-01
    z[4,5,5]  R2181     0.0419129841029644
    z[4,5,5]  R2182     -0.748490035533905
    z[4,5,5]  R2183     1.4861298725008965e-02
    z[4,5,5]  R2184     8.3549067378044128e-02
    z[4,5,5]  R2185     1.3186158239841461e-01
    z[4,5,5]  R2186     5.1337409019470215e-01
    z[4,5,5]  R2187     3.2437229156494141e-01
    z[4,5,5]  R2188     3.2740112394094467e-02
    z[4,5,5]  R2189     4.1143134236335754e-02
    z[4,5,5]  R2190     4.3569406867027283e-01
    z[4,5,5]  R2191     3.2644793391227722e-01
    z[4,5,5]  R2192     3.2438716292381287e-01
    z[4,5,5]  R2193     3.2985344529151917e-01
    z[4,5,5]  R2194     2.5985753536224365e-01
    z[4,5,5]  R2195     4.8788863420486450e-01
    z[4,5,5]  R2196     5.6804078817367554e-01
    z[4,5,5]  R2197     3.2667967677116394e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R2086     -1
    z[4,5,6]  R2087     1
    z[4,5,6]  R2088     2.7287659049034119e-01
    z[4,5,6]  R2089     -8.6940238252282143e-03
    z[4,5,6]  R2090     3.3845886588096619e-01
    z[4,5,6]  R2091     -5.6192469596862793e-01
    z[4,5,6]  R2092     3.7011390924453735e-01
    z[4,5,6]  R2093     9.6734218299388885e-02
    z[4,5,6]  R2094     2.8947748243808746e-02
    z[4,5,6]  R2095     8.4491841495037079e-02
    z[4,5,6]  R2096     -2.7116268873214722e-01
    z[4,5,6]  R2097     5.5536723136901855e-01
    z[4,5,6]  R2098     -1.0864780098199844e-01
    z[4,5,6]  R2099     -3.1635737419128418e-01
    z[4,5,6]  R2100     2.7368339896202087e-01
    z[4,5,6]  R2101     -6.4924255013465881e-02
    z[4,5,6]  R2102     1.6080971807241440e-02
    z[4,5,6]  R2103     1.1388626694679260e-01
    z[4,5,6]  R2104     -1.1335127800703049e-01
    z[4,5,6]  R2105     6.2742494046688080e-02
    z[4,5,6]  R2106     8.7315574288368225e-02
    z[4,5,6]  R2107     -4.3224021792411804e-01
    z[4,5,6]  R2108     4.6385556459426880e-01
    z[4,5,6]  R2109     1.3388817012310028e-01
    z[4,5,6]  R2110     -1.0406203567981720e-01
    z[4,5,6]  R2111     -3.2532370090484619e-01
    z[4,5,6]  R2112     -5.8396351337432861e-01
    z[4,5,6]  R2113     -6.0750752687454224e-02
    z[4,5,6]  R2114     3.7941977381706238e-01
    z[4,5,6]  R2115     -8.0928064882755280e-02
    z[4,5,6]  R2116     -3.2811298966407776e-01
    z[4,5,6]  R2117     5.3886175155639648e-03
    z[4,5,6]  R2118     -2.4670192599296570e-01
    z[4,5,6]  R2119     1.5145288407802582e-01
    z[4,5,6]  R2120     -1.2451510876417160e-01
    z[4,5,6]  R2121     1.9450066983699799e-01
    z[4,5,6]  R2122     5.6221973150968552e-02
    z[4,5,6]  R2123     4.0203872323036194e-01
    z[4,5,6]  R2124     -6.0775661468505859e-01
    z[4,5,6]  R2125     -4.1605624556541443e-01
    z[4,5,6]  R2126     -2.0083867013454437e-02
    z[4,5,6]  R2127     -4.1355829685926437e-02
    z[4,5,6]  R2128     0.169141948223114
    z[4,5,6]  R2129     -2.3644529283046722e-01
    z[4,5,6]  R2130     -5.4670977592468262e-01
    z[4,5,6]  R2131     -4.8036286234855652e-01
    z[4,5,6]  R2132     -1.3549636304378510e-01
    z[4,5,6]  R2133     1.3533039391040802e-01
    z[4,5,6]  R2134     -3.3536779880523682e-01
    z[4,5,6]  R2135     -7.4160680174827576e-02
    z[4,5,6]  R2136     3.9604222774505615e-01
    z[4,5,6]  R2137     8.2372479140758514e-02
    z[4,5,6]  R2138     -2.0938409864902496e-01
    z[4,5,6]  R2139     -9.9131613969802856e-02
    z[4,5,6]  R2140     -1.5620626509189606e-01
    z[4,5,6]  R2141     -3.5751909017562866e-02
    z[4,5,6]  R2142     3.4721937775611877e-01
    z[4,5,6]  R2143     -1.6696329414844513e-01
    z[4,5,6]  R2144     -5.4487246274948120e-01
    z[4,5,6]  R2145     2.4621315300464630e-01
    z[4,5,6]  R2146     -2.9758375883102417e-01
    z[4,5,6]  R2147     -3.2744112610816956e-01
    z[4,5,6]  R2148     -1.3781943917274475e-01
    z[4,5,6]  R2149     1.9308337569236755e-01
    z[4,5,6]  R2150     -4.1964939236640930e-01
    z[4,5,6]  R2151     -3.2751351594924927e-02
    z[4,5,6]  R2152     4.0953123569488525e-01
    z[4,5,6]  R2153     -2.7584463357925415e-01
    z[4,5,6]  R2154     -6.4742863178253174e-01
    z[4,5,6]  R2155     -1.5823251008987427e-01
    z[4,5,6]  R2156     1.8326042592525482e-01
    z[4,5,6]  R2157     8.2990802824497223e-02
    z[4,5,6]  R2158     -6.4104783535003662e-01
    z[4,5,6]  R2159     -7.6623722910881042e-02
    z[4,5,6]  R2160     -1.5886804461479187e-01
    z[4,5,6]  R2161     2.6446020603179932e-01
    z[4,5,6]  R2162     -4.7957371920347214e-02
    z[4,5,6]  R2163     1.0231915861368179e-01
    z[4,5,6]  R2164     -6.3529020547866821e-01
    z[4,5,6]  R2165     -2.9536217451095581e-01
    z[4,5,6]  R2166     -1.2536510825157166e-01
    z[4,5,6]  R2167     -2.9091672971844673e-02
    z[4,5,6]  R2168     -2.2160361707210541e-01
    z[4,5,6]  R2169     -4.0055537223815918e-01
    z[4,5,6]  R2170     -0.0674145370721817
    z[4,5,6]  R2171     7.8882798552513123e-02
    z[4,5,6]  R2172     3.0971509218215942e-01
    z[4,5,6]  R2173     2.9696798324584961e-01
    z[4,5,6]  R2174     1.4758327975869179e-02
    z[4,5,6]  R2175     2.4358795583248138e-01
    z[4,5,6]  R2176     1.0696541517972946e-01
    z[4,5,6]  R2177     3.1952759623527527e-01
    z[4,5,6]  R2178     3.4444382786750793e-01
    z[4,5,6]  R2179     -1.6767981648445129e-01
    z[4,5,6]  R2180     -0.0714760273694992
    z[4,5,6]  R2181     -6.8889975547790527e-02
    z[4,5,6]  R2182     -1.3277265429496765e-01
    z[4,5,6]  R2183     0.0651208832859993
    z[4,5,6]  R2184     -4.1888660192489624e-01
    z[4,5,6]  R2185     -5.0906103849411011e-01
    z[4,5,6]  R2186     -3.4804448485374451e-01
    z[4,5,6]  R2187     2.8391024470329285e-01
    z[4,5,6]  R2188     5.7311558723449707e-01
    z[4,5,6]  R2189     5.5515062808990479e-01
    z[4,5,6]  R2190     2.2358103096485138e-01
    z[4,5,6]  R2191     3.0527812242507935e-01
    z[4,5,6]  R2192     2.2190552949905396e-01
    z[4,5,6]  R2193     2.8065380454063416e-01
    z[4,5,6]  R2194     3.8068944215774536e-01
    z[4,5,6]  R2195     2.5680848956108093e-01
    z[4,5,6]  R2196     1.5874877572059631e-01
    z[4,5,6]  R2197     3.6465290188789368e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R2198     -1
    z[5,4,0]  R2199     1
    z[5,4,0]  R2212     -2.6823753118515015e-01
    z[5,4,0]  R2213     -6.5219156444072723e-02
    z[5,4,0]  R2214     -2.8410360217094421e-01
    z[5,4,0]  R2215     -4.4057813286781311e-01
    z[5,4,0]  R2216     -1.4141286909580231e-01
    z[5,4,0]  R2217     6.6742408275604248e-01
    z[5,4,0]  R2218     7.5001978874206543e-01
    z[5,4,0]  R2219     1.8080644309520721e-01
    z[5,4,0]  R2220     4.8582616448402405e-01
    z[5,4,0]  R2221     4.6337318420410156e-01
    z[5,4,0]  R2222     -3.2918116450309753e-01
    z[5,4,0]  R2223     -5.2980142831802368e-01
    z[5,4,0]  R2224     1.3590514659881592e-01
    z[5,4,0]  R2225     1.8562240898609161e-01
    z[5,4,0]  R2226     1.7441925406455994e-01
    z[5,4,0]  R2227     -9.4519846141338348e-02
    z[5,4,0]  R2228     4.6904768794775009e-02
    z[5,4,0]  R2229     -5.8192804455757141e-02
    z[5,4,0]  R2230     1.9962343573570251e-01
    z[5,4,0]  R2231     -0.294490784406662
    z[5,4,0]  R2232     -7.5595939159393311e-01
    z[5,4,0]  R2233     -3.8382682204246521e-01
    z[5,4,0]  R2234     -3.0085310339927673e-01
    z[5,4,0]  R2235     -4.3898898363113403e-01
    z[5,4,0]  R2236     -5.3916312754154205e-02
    z[5,4,0]  R2237     2.0261155068874359e-01
    z[5,4,0]  R2238     -3.3357802033424377e-01
    z[5,4,0]  R2239     -4.6541181206703186e-01
    z[5,4,0]  R2240     -1.7482081055641174e-01
    z[5,4,0]  R2241     -3.2698640227317810e-01
    z[5,4,0]  R2242     -2.0467326045036316e-01
    z[5,4,0]  R2243     3.1608107686042786e-01
    z[5,4,0]  R2244     1.9089536741375923e-02
    z[5,4,0]  R2245     3.4732836484909058e-01
    z[5,4,0]  R2246     8.6776286363601685e-01
    z[5,4,0]  R2247     -6.4097873866558075e-02
    z[5,4,0]  R2248     9.2839550971984863e-01
    z[5,4,0]  R2249     8.8717746734619141e-01
    z[5,4,0]  R2250     0.766423225402832
    z[5,4,0]  R2251     8.0424225330352783e-01
    z[5,4,0]  R2252     2.6922184973955154e-02
    z[5,4,0]  R2253     -3.1197193264961243e-01
    z[5,4,0]  R2254     -4.2019522190093994e-01
    z[5,4,0]  R2255     8.5720755159854889e-02
    z[5,4,0]  R2256     -4.9759708344936371e-02
    z[5,4,0]  R2257     5.1685433834791183e-02
    z[5,4,0]  R2258     1.4829632639884949e-01
    z[5,4,0]  R2259     1.6176998615264893e-01
    z[5,4,0]  R2260     2.3579502105712891e-01
    z[5,4,0]  R2261     -1.4668072760105133e-01
    z[5,4,0]  R2262     -2.1438447292894125e-03
    z[5,4,0]  R2263     3.1725355982780457e-01
    z[5,4,0]  R2264     -1.7180384695529938e-01
    z[5,4,0]  R2265     -6.9005347788333893e-02
    z[5,4,0]  R2266     5.3096253424882889e-02
    z[5,4,0]  R2267     2.0548075437545776e-01
    z[5,4,0]  R2268     3.2522976398468018e-01
    z[5,4,0]  R2269     -5.1012493669986725e-02
    z[5,4,0]  R2270     9.2113900184631348e-01
    z[5,4,0]  R2271     5.6456762552261353e-01
    z[5,4,0]  R2272     -3.2004863023757935e-01
    z[5,4,0]  R2273     -1.2148412875831127e-02
    z[5,4,0]  R2274     -6.3843570649623871e-02
    z[5,4,0]  R2275     -5.1655262708663940e-02
    z[5,4,0]  R2276     -1.8021368980407715e-01
    z[5,4,0]  R2277     -1.5424399077892303e-01
    z[5,4,0]  R2278     1.2154664099216461e-01
    z[5,4,0]  R2279     8.8347233831882477e-02
    z[5,4,0]  R2280     -2.8340601921081543e-01
    z[5,4,0]  R2281     4.0016490221023560e-01
    z[5,4,0]  R2282     -2.0374859869480133e-01
    z[5,4,0]  R2283     -1.8331326544284821e-01
    z[5,4,0]  R2284     -2.9987642168998718e-01
    z[5,4,0]  R2285     -4.0957161784172058e-01
    z[5,4,0]  R2286     -2.1545775234699249e-01
    z[5,4,0]  R2287     -9.7865886986255646e-02
    z[5,4,0]  R2288     3.2939872145652771e-01
    z[5,4,0]  R2289     3.6172747611999512e-01
    z[5,4,0]  R2290     6.9161552190780640e-01
    z[5,4,0]  R2291     8.4867948293685913e-01
    z[5,4,0]  R2292     3.0808833241462708e-01
    z[5,4,0]  R2293     -1.6845524311065674e-01
    z[5,4,0]  R2294     -1.5884728729724884e-01
    z[5,4,0]  R2295     7.8646093606948853e-03
    z[5,4,0]  R2296     -3.8685572147369385e-01
    z[5,4,0]  R2297     -1.5796563029289246e-01
    z[5,4,0]  R2298     -1.0707242041826248e-01
    z[5,4,0]  R2299     9.2819523811340332e-01
    z[5,4,0]  R2300     9.1676068305969238e-01
    z[5,4,0]  R2301     8.5742688179016113e-01
    z[5,4,0]  R2302     1.1749872565269470e-01
    z[5,4,0]  R2303     -1.0967695713043213e-01
    z[5,4,0]  R2304     -9.1911517083644867e-02
    z[5,4,0]  R2305     -1.7805531620979309e-01
    z[5,4,0]  R2306     -2.5043404102325439e-01
    z[5,4,0]  R2307     2.8830792754888535e-02
    z[5,4,0]  R2308     -5.3877104073762894e-02
    z[5,4,0]  R2309     7.6644057035446167e-01
    z[5,4,0]  R2310     4.5327857136726379e-01
    z[5,4,0]  R2311     7.2841495275497437e-01
    z[5,4,0]  R2312     -1.5652939677238464e-01
    z[5,4,0]  R2313     -4.5320162177085876e-01
    z[5,4,0]  R2314     8.3178174495697021e-01
    z[5,4,0]  R2315     0.865403413772583
    z[5,4,0]  R2316     6.3283419609069824e-01
    z[5,4,0]  R2317     8.7871414422988892e-01
    z[5,4,0]  R2318     3.6707940697669983e-01
    z[5,4,0]  R2319     6.1472576856613159e-01
    z[5,4,0]  R2320     4.5549169182777405e-01
    z[5,4,0]  R2321     4.5406249165534973e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R2200     -1
    z[5,4,1]  R2201     1
    z[5,4,1]  R2212     2.4573600292205811e-01
    z[5,4,1]  R2213     3.6279591917991638e-01
    z[5,4,1]  R2214     -6.1442929506301880e-01
    z[5,4,1]  R2215     2.6527587324380875e-02
    z[5,4,1]  R2216     -3.9439103007316589e-01
    z[5,4,1]  R2217     3.2276561856269836e-01
    z[5,4,1]  R2218     4.2350569367408752e-01
    z[5,4,1]  R2219     1.2853574752807617e-01
    z[5,4,1]  R2220     5.3194683790206909e-01
    z[5,4,1]  R2221     5.1429039239883423e-01
    z[5,4,1]  R2222     3.9422520995140076e-01
    z[5,4,1]  R2223     2.7047321200370789e-01
    z[5,4,1]  R2224     -7.6316612958908081e-01
    z[5,4,1]  R2225     -7.5528490543365479e-01
    z[5,4,1]  R2226     -7.9375445842742920e-01
    z[5,4,1]  R2227     -6.4786761999130249e-01
    z[5,4,1]  R2228     -7.3607826232910156e-01
    z[5,4,1]  R2229     -7.1364831924438477e-01
    z[5,4,1]  R2230     -7.4419844150543213e-01
    z[5,4,1]  R2231     -6.3241493701934814e-01
    z[5,4,1]  R2232     -4.0895906090736389e-01
    z[5,4,1]  R2233     -5.5129384994506836e-01
    z[5,4,1]  R2234     -5.8258968591690063e-01
    z[5,4,1]  R2235     -4.0229967236518860e-01
    z[5,4,1]  R2236     -4.1316270828247070e-01
    z[5,4,1]  R2237     -4.2161974310874939e-01
    z[5,4,1]  R2238     9.1567748785018921e-01
    z[5,4,1]  R2239     6.6368746757507324e-01
    z[5,4,1]  R2240     7.1862238645553589e-01
    z[5,4,1]  R2241     6.2939703464508057e-01
    z[5,4,1]  R2242     -3.6118716001510620e-01
    z[5,4,1]  R2243     0.643488883972168
    z[5,4,1]  R2244     0.761551558971405
    z[5,4,1]  R2245     6.5792787075042725e-01
    z[5,4,1]  R2246     -3.0341061949729919e-01
    z[5,4,1]  R2247     4.7267517447471619e-01
    z[5,4,1]  R2248     -1.5194717049598694e-01
    z[5,4,1]  R2249     -8.1752061843872070e-02
    z[5,4,1]  R2250     -3.1761386990547180e-01
    z[5,4,1]  R2251     -2.4149794876575470e-01
    z[5,4,1]  R2252     7.0063757896423340e-01
    z[5,4,1]  R2253     0.634477436542511
    z[5,4,1]  R2254     5.1053810119628906e-01
    z[5,4,1]  R2255     6.3336014747619629e-01
    z[5,4,1]  R2256     0.571498453617096
    z[5,4,1]  R2257     0.624488890171051
    z[5,4,1]  R2258     6.8535220623016357e-01
    z[5,4,1]  R2259     6.0414552688598633e-01
    z[5,4,1]  R2260     0.617192268371582
    z[5,4,1]  R2261     4.7669410705566406e-01
    z[5,4,1]  R2262     -0.521144449710846
    z[5,4,1]  R2263     8.1455355882644653e-01
    z[5,4,1]  R2264     6.6145467758178711e-01
    z[5,4,1]  R2265     6.5821504592895508e-01
    z[5,4,1]  R2266     7.6134026050567627e-01
    z[5,4,1]  R2267     6.7953163385391235e-01
    z[5,4,1]  R2268     6.7852401733398438e-01
    z[5,4,1]  R2269     -2.8339993953704834e-01
    z[5,4,1]  R2270     -1.2914204597473145e-01
    z[5,4,1]  R2271     -2.7889639139175415e-01
    z[5,4,1]  R2272     0.661384105682373
    z[5,4,1]  R2273     6.8406271934509277e-01
    z[5,4,1]  R2274     0.609142005443573
    z[5,4,1]  R2275     6.1185771226882935e-01
    z[5,4,1]  R2276     5.1991587877273560e-01
    z[5,4,1]  R2277     5.0892251729965210e-01
    z[5,4,1]  R2278     6.2008982896804810e-01
    z[5,4,1]  R2279     5.8739626407623291e-01
    z[5,4,1]  R2280     4.4208192825317383e-01
    z[5,4,1]  R2281     -7.5490063428878784e-01
    z[5,4,1]  R2282     1.1428605020046234e-01
    z[5,4,1]  R2283     -5.4980587959289551e-01
    z[5,4,1]  R2284     6.8772667646408081e-01
    z[5,4,1]  R2285     5.7774698734283447e-01
    z[5,4,1]  R2286     6.1253947019577026e-01
    z[5,4,1]  R2287     6.3415187597274780e-01
    z[5,4,1]  R2288     7.2337609529495239e-01
    z[5,4,1]  R2289     6.5873426198959351e-01
    z[5,4,1]  R2290     -3.1618535518646240e-01
    z[5,4,1]  R2291     -2.2307717800140381e-01
    z[5,4,1]  R2292     0.907846212387085
    z[5,4,1]  R2293     7.8116118907928467e-01
    z[5,4,1]  R2294     6.5968692302703857e-01
    z[5,4,1]  R2295     7.1707624197006226e-01
    z[5,4,1]  R2296     5.8574253320693970e-01
    z[5,4,1]  R2297     6.7232650518417358e-01
    z[5,4,1]  R2298     5.0570577383041382e-01
    z[5,4,1]  R2299     -2.2589710354804993e-01
    z[5,4,1]  R2300     -6.9680139422416687e-02
    z[5,4,1]  R2301     -5.0524167716503143e-02
    z[5,4,1]  R2302     -4.7879534959793091e-01
    z[5,4,1]  R2303     8.4078276157379150e-01
    z[5,4,1]  R2304     8.1807190179824829e-01
    z[5,4,1]  R2305     7.6242613792419434e-01
    z[5,4,1]  R2306     7.4268090724945068e-01
    z[5,4,1]  R2307     7.8609466552734375e-01
    z[5,4,1]  R2308     5.7589423656463623e-01
    z[5,4,1]  R2309     -2.7718749642372131e-01
    z[5,4,1]  R2310     4.0824308991432190e-01
    z[5,4,1]  R2311     1.9695796072483063e-01
    z[5,4,1]  R2312     -3.7442067265510559e-01
    z[5,4,1]  R2313     5.4200363159179688e-01
    z[5,4,1]  R2314     -3.6016467213630676e-01
    z[5,4,1]  R2315     -1.0555035620927811e-01
    z[5,4,1]  R2316     -2.8569099307060242e-01
    z[5,4,1]  R2317     7.3532074689865112e-02
    z[5,4,1]  R2318     5.3862494230270386e-01
    z[5,4,1]  R2319     5.9677477926015854e-02
    z[5,4,1]  R2320     1.7477940022945404e-01
    z[5,4,1]  R2321     2.8231540322303772e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R2202     -1
    z[5,4,2]  R2203     1
    z[5,4,2]  R2212     -3.1426379084587097e-01
    z[5,4,2]  R2213     -3.8013070821762085e-01
    z[5,4,2]  R2214     -2.6275274157524109e-01
    z[5,4,2]  R2215     1.3911771774291992e-01
    z[5,4,2]  R2216     -4.1727340221405029e-01
    z[5,4,2]  R2217     -2.8148925304412842e-01
    z[5,4,2]  R2218     -1.5927772223949432e-01
    z[5,4,2]  R2219     3.7788701057434082e-01
    z[5,4,2]  R2220     2.7874574065208435e-01
    z[5,4,2]  R2221     -6.0055539011955261e-02
    z[5,4,2]  R2222     6.1995659023523331e-02
    z[5,4,2]  R2223     0.241798996925354
    z[5,4,2]  R2224     0.273393839597702
    z[5,4,2]  R2225     1.4513716101646423e-01
    z[5,4,2]  R2226     2.1221699193120003e-02
    z[5,4,2]  R2227     1.7214192450046539e-01
    z[5,4,2]  R2228     2.2800672054290771e-01
    z[5,4,2]  R2229     2.6251357793807983e-01
    z[5,4,2]  R2230     1.3650007545948029e-01
    z[5,4,2]  R2231     2.9738715291023254e-01
    z[5,4,2]  R2232     5.2927613258361816e-02
    z[5,4,2]  R2233     -3.7967246770858765e-01
    z[5,4,2]  R2234     -6.2895250320434570e-01
    z[5,4,2]  R2235     -1.4505137503147125e-01
    z[5,4,2]  R2236     -3.4477221965789795e-01
    z[5,4,2]  R2237     -2.7408489584922791e-01
    z[5,4,2]  R2238     -1.8525023758411407e-01
    z[5,4,2]  R2239     9.5642521977424622e-02
    z[5,4,2]  R2240     7.1118585765361786e-02
    z[5,4,2]  R2241     1.3777109980583191e-01
    z[5,4,2]  R2242     5.7343918085098267e-01
    z[5,4,2]  R2243     3.6670535802841187e-02
    z[5,4,2]  R2244     1.3931621611118317e-01
    z[5,4,2]  R2245     6.4815413951873779e-01
    z[5,4,2]  R2246     -7.3000110685825348e-02
    z[5,4,2]  R2247     4.9809610843658447e-01
    z[5,4,2]  R2248     2.1548955142498016e-01
    z[5,4,2]  R2249     2.7396270632743835e-01
    z[5,4,2]  R2250     -1.0538420639932156e-02
    z[5,4,2]  R2251     1.9095709919929504e-01
    z[5,4,2]  R2252     -1.3599984347820282e-01
    z[5,4,2]  R2253     6.3948506116867065e-01
    z[5,4,2]  R2254     4.0348327159881592e-01
    z[5,4,2]  R2255     -9.1357663273811340e-02
    z[5,4,2]  R2256     2.3269453644752502e-01
    z[5,4,2]  R2257     2.8954052925109863e-01
    z[5,4,2]  R2258     9.3520984053611755e-02
    z[5,4,2]  R2259     3.6777067184448242e-01
    z[5,4,2]  R2260     4.8150235414505005e-01
    z[5,4,2]  R2261     1.8627518415451050e-01
    z[5,4,2]  R2262     7.9654440283775330e-02
    z[5,4,2]  R2263     -6.9881482049822807e-03
    z[5,4,2]  R2264     0.55242520570755
    z[5,4,2]  R2265     0.517589807510376
    z[5,4,2]  R2266     0.382357656955719
    z[5,4,2]  R2267     4.3718099594116211e-01
    z[5,4,2]  R2268     1.4393419027328491e-01
    z[5,4,2]  R2269     7.7611964941024780e-01
    z[5,4,2]  R2270     1.7767506837844849e-01
    z[5,4,2]  R2271     4.2432352900505066e-01
    z[5,4,2]  R2272     4.7660058736801147e-01
    z[5,4,2]  R2273     4.2518422007560730e-01
    z[5,4,2]  R2274     7.4195876717567444e-02
    z[5,4,2]  R2275     1.4133690297603607e-01
    z[5,4,2]  R2276     5.8930929750204086e-02
    z[5,4,2]  R2277     -1.5129742026329041e-01
    z[5,4,2]  R2278     -6.9181986153125763e-02
    z[5,4,2]  R2279     4.6942636370658875e-02
    z[5,4,2]  R2280     1.3853174448013306e-01
    z[5,4,2]  R2281     4.1284161806106567e-01
    z[5,4,2]  R2282     5.5429196357727051e-01
    z[5,4,2]  R2283     3.2978755235671997e-01
    z[5,4,2]  R2284     2.8025823831558228e-01
    z[5,4,2]  R2285     2.6140713691711426e-01
    z[5,4,2]  R2286     1.5084272250533104e-02
    z[5,4,2]  R2287     -1.9392465054988861e-01
    z[5,4,2]  R2288     -9.1017229715362191e-04
    z[5,4,2]  R2289     3.2170155644416809e-01
    z[5,4,2]  R2290     1.8902434408664703e-01
    z[5,4,2]  R2291     7.8653432428836823e-02
    z[5,4,2]  R2292     1.3745307922363281e-01
    z[5,4,2]  R2293     4.8542514443397522e-01
    z[5,4,2]  R2294     2.1271798014640808e-01
    z[5,4,2]  R2295     -1.8609980121254921e-02
    z[5,4,2]  R2296     1.2843313813209534e-01
    z[5,4,2]  R2297     5.8540576696395874e-01
    z[5,4,2]  R2298     1.0369451344013214e-01
    z[5,4,2]  R2299     1.0151851177215576e-01
    z[5,4,2]  R2300     2.9004657268524170e-01
    z[5,4,2]  R2301     4.6488952636718750e-01
    z[5,4,2]  R2302     1.6060872375965118e-01
    z[5,4,2]  R2303     -1.2836912274360657e-01
    z[5,4,2]  R2304     2.7374556660652161e-01
    z[5,4,2]  R2305     1.6982159018516541e-01
    z[5,4,2]  R2306     1.8278861045837402e-01
    z[5,4,2]  R2307     4.2374005913734436e-01
    z[5,4,2]  R2308     5.0773404538631439e-02
    z[5,4,2]  R2309     7.4549637734889984e-02
    z[5,4,2]  R2310     -6.2355047464370728e-01
    z[5,4,2]  R2311     3.8519951701164246e-01
    z[5,4,2]  R2312     4.8653751611709595e-02
    z[5,4,2]  R2313     4.1227829456329346e-01
    z[5,4,2]  R2314     -1.2187819182872772e-01
    z[5,4,2]  R2315     4.1454848647117615e-01
    z[5,4,2]  R2316     3.5861104726791382e-01
    z[5,4,2]  R2317     3.0075496435165405e-01
    z[5,4,2]  R2318     -0.518540620803833
    z[5,4,2]  R2319     2.9725831747055054e-01
    z[5,4,2]  R2320     3.5120970010757446e-01
    z[5,4,2]  R2321     3.8471260666847229e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R2204     -1
    z[5,4,3]  R2205     1
    z[5,4,3]  R2212     -5.9839230775833130e-01
    z[5,4,3]  R2213     -5.6734341382980347e-01
    z[5,4,3]  R2214     -5.5254191160202026e-01
    z[5,4,3]  R2215     -0.86295485496521
    z[5,4,3]  R2216     5.8465588837862015e-02
    z[5,4,3]  R2217     5.6408715248107910e-01
    z[5,4,3]  R2218     1.9337294995784760e-01
    z[5,4,3]  R2219     7.1931129693984985e-01
    z[5,4,3]  R2220     1.1560782790184021e-01
    z[5,4,3]  R2221     2.3387832939624786e-01
    z[5,4,3]  R2222     0.283197283744812
    z[5,4,3]  R2223     3.9575561881065369e-01
    z[5,4,3]  R2224     2.7132576704025269e-01
    z[5,4,3]  R2225     3.9909040927886963e-01
    z[5,4,3]  R2226     4.2910179495811462e-01
    z[5,4,3]  R2227     4.4801110029220581e-01
    z[5,4,3]  R2228     3.9648792147636414e-01
    z[5,4,3]  R2229     2.7338972687721252e-01
    z[5,4,3]  R2230     1.7293485999107361e-01
    z[5,4,3]  R2231     4.2913112044334412e-01
    z[5,4,3]  R2232     1.6001372039318085e-01
    z[5,4,3]  R2233     2.8818270564079285e-01
    z[5,4,3]  R2234     -1.6304506361484528e-01
    z[5,4,3]  R2235     3.6362621188163757e-01
    z[5,4,3]  R2236     1.2032174319028854e-01
    z[5,4,3]  R2237     1.7823085188865662e-01
    z[5,4,3]  R2238     -3.5893155727535486e-03
    z[5,4,3]  R2239     -3.8156139850616455e-01
    z[5,4,3]  R2240     6.0356277227401733e-01
    z[5,4,3]  R2241     -2.8164786100387573e-01
    z[5,4,3]  R2242     -5.4171049594879150e-01
    z[5,4,3]  R2243     1.0718328505754471e-01
    z[5,4,3]  R2244     -0.0906682088971138
    z[5,4,3]  R2245     -6.5006553195416927e-03
    z[5,4,3]  R2246     8.5837788879871368e-02
    z[5,4,3]  R2247     2.3907181620597839e-01
    z[5,4,3]  R2248     4.7946058213710785e-02
    z[5,4,3]  R2249     -3.1040126085281372e-01
    z[5,4,3]  R2250     -4.5869520306587219e-01
    z[5,4,3]  R2251     -2.3695114254951477e-01
    z[5,4,3]  R2252     -0.384262353181839
    z[5,4,3]  R2253     0.0794503390789032
    z[5,4,3]  R2254     2.3354966938495636e-01
    z[5,4,3]  R2255     -3.7225788831710815e-01
    z[5,4,3]  R2256     -0.152827650308609
    z[5,4,3]  R2257     5.2892103791236877e-02
    z[5,4,3]  R2258     4.5519590377807617e-01
    z[5,4,3]  R2259     -5.3364926576614380e-01
    z[5,4,3]  R2260     -3.1549653410911560e-01
    z[5,4,3]  R2261     -5.7637596130371094e-01
    z[5,4,3]  R2262     -4.6700218319892883e-01
    z[5,4,3]  R2263     1.2275058031082153e-01
    z[5,4,3]  R2264     2.8028586506843567e-01
    z[5,4,3]  R2265     -2.9184681177139282e-01
    z[5,4,3]  R2266     4.9547683447599411e-02
    z[5,4,3]  R2267     1.1898304522037506e-01
    z[5,4,3]  R2268     1.1744812875986099e-01
    z[5,4,3]  R2269     1.3186505995690823e-02
    z[5,4,3]  R2270     2.9272291064262390e-01
    z[5,4,3]  R2271     -3.4841954708099365e-01
    z[5,4,3]  R2272     7.4020475149154663e-02
    z[5,4,3]  R2273     -3.4547463059425354e-01
    z[5,4,3]  R2274     -2.3175922036170959e-01
    z[5,4,3]  R2275     8.8113643229007721e-02
    z[5,4,3]  R2276     1.1977697908878326e-01
    z[5,4,3]  R2277     -3.4683072566986084e-01
    z[5,4,3]  R2278     -6.3989430665969849e-01
    z[5,4,3]  R2279     -4.4078847765922546e-01
    z[5,4,3]  R2280     -3.9069369435310364e-01
    z[5,4,3]  R2281     -1.4880749583244324e-01
    z[5,4,3]  R2282     6.0058438777923584e-01
    z[5,4,3]  R2283     -4.9394312500953674e-01
    z[5,4,3]  R2284     1.3339401781558990e-01
    z[5,4,3]  R2285     -3.6142196506261826e-02
    z[5,4,3]  R2286     -8.2534685730934143e-02
    z[5,4,3]  R2287     -4.1981092095375061e-01
    z[5,4,3]  R2288     -1.6490165144205093e-02
    z[5,4,3]  R2289     -4.8603683710098267e-01
    z[5,4,3]  R2290     -4.1447019577026367e-01
    z[5,4,3]  R2291     -1.4740024507045746e-01
    z[5,4,3]  R2292     -1.9657707214355469e-01
    z[5,4,3]  R2293     1.4049349725246429e-01
    z[5,4,3]  R2294     -5.3508497774600983e-02
    z[5,4,3]  R2295     -3.9368104934692383e-01
    z[5,4,3]  R2296     -4.3956348299980164e-01
    z[5,4,3]  R2297     -7.0799507200717926e-02
    z[5,4,3]  R2298     -3.5371506214141846e-01
    z[5,4,3]  R2299     -8.1046774983406067e-02
    z[5,4,3]  R2300     5.0250524654984474e-03
    z[5,4,3]  R2301     -1.6853669285774231e-01
    z[5,4,3]  R2302     3.2198518514633179e-01
    z[5,4,3]  R2303     -3.1587982177734375e-01
    z[5,4,3]  R2304     1.2399684637784958e-01
    z[5,4,3]  R2305     0.325998991727829
    z[5,4,3]  R2306     1.2346013635396957e-01
    z[5,4,3]  R2307     1.2125533074140549e-01
    z[5,4,3]  R2308     -3.0911889672279358e-01
    z[5,4,3]  R2309     -3.4176650643348694e-01
    z[5,4,3]  R2310     3.5552024841308594e-01
    z[5,4,3]  R2311     4.6924769878387451e-01
    z[5,4,3]  R2312     -2.5024303793907166e-01
    z[5,4,3]  R2313     -3.3788588643074036e-01
    z[5,4,3]  R2314     -3.6288508772850037e-01
    z[5,4,3]  R2315     -1.9072756171226501e-01
    z[5,4,3]  R2316     -4.1188588738441467e-01
    z[5,4,3]  R2317     1.1242207884788513e-01
    z[5,4,3]  R2318     5.2938532829284668e-01
    z[5,4,3]  R2319     3.5849779844284058e-01
    z[5,4,3]  R2320     6.4723688364028931e-01
    z[5,4,3]  R2321     4.5425498485565186e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R2206     -1
    z[5,4,4]  R2207     1
    z[5,4,4]  R2212     3.9711022377014160e-01
    z[5,4,4]  R2213     -2.5315082073211670e-01
    z[5,4,4]  R2214     -2.7344502508640289e-02
    z[5,4,4]  R2215     -1.8611754477024078e-01
    z[5,4,4]  R2216     -2.6278665661811829e-01
    z[5,4,4]  R2217     2.2017116844654083e-01
    z[5,4,4]  R2218     1.1359731853008270e-01
    z[5,4,4]  R2219     -1.1853111535310745e-01
    z[5,4,4]  R2220     0.072480209171772
    z[5,4,4]  R2221     5.2598720788955688e-01
    z[5,4,4]  R2222     -5.6802171468734741e-01
    z[5,4,4]  R2223     -3.4810966253280640e-01
    z[5,4,4]  R2224     -1.0453492403030396e-01
    z[5,4,4]  R2225     -1.2242580950260162e-01
    z[5,4,4]  R2226     2.1998232230544090e-02
    z[5,4,4]  R2227     -3.9168462157249451e-01
    z[5,4,4]  R2228     1.8533350527286530e-01
    z[5,4,4]  R2229     1.9919458031654358e-01
    z[5,4,4]  R2230     -9.9543638527393341e-02
    z[5,4,4]  R2231     3.2287046313285828e-02
    z[5,4,4]  R2232     -1.1472114175558090e-01
    z[5,4,4]  R2233     -1.1252373456954956e-01
    z[5,4,4]  R2234     -2.7165785431861877e-02
    z[5,4,4]  R2235     -4.0477615594863892e-01
    z[5,4,4]  R2236     7.2668421268463135e-01
    z[5,4,4]  R2237     6.1354964971542358e-01
    z[5,4,4]  R2238     -9.9070511758327484e-02
    z[5,4,4]  R2239     0.409146249294281
    z[5,4,4]  R2240     -6.6583938896656036e-02
    z[5,4,4]  R2241     2.5064873695373535e-01
    z[5,4,4]  R2242     1.3133677840232849e-01
    z[5,4,4]  R2243     -3.3229254186153412e-02
    z[5,4,4]  R2244     -3.2199618220329285e-01
    z[5,4,4]  R2245     1.4842495322227478e-01
    z[5,4,4]  R2246     -3.7058830261230469e-01
    z[5,4,4]  R2247     6.1142629384994507e-01
    z[5,4,4]  R2248     -2.3097884654998779e-01
    z[5,4,4]  R2249     3.4388538450002670e-02
    z[5,4,4]  R2250     -3.0489778518676758e-01
    z[5,4,4]  R2251     -0.0886390283703804
    z[5,4,4]  R2252     3.1590268015861511e-01
    z[5,4,4]  R2253     2.3376764729619026e-03
    z[5,4,4]  R2254     3.7073215842247009e-01
    z[5,4,4]  R2255     4.4369032979011536e-01
    z[5,4,4]  R2256     4.6025916934013367e-01
    z[5,4,4]  R2257     3.5726550966501236e-02
    z[5,4,4]  R2258     3.6453232169151306e-01
    z[5,4,4]  R2259     -3.4587019681930542e-01
    z[5,4,4]  R2260     -2.4863809812813997e-03
    z[5,4,4]  R2261     -5.2206773310899734e-02
    z[5,4,4]  R2262     2.4215477705001831e-01
    z[5,4,4]  R2263     1.8904080986976624e-01
    z[5,4,4]  R2264     1.5691670775413513e-01
    z[5,4,4]  R2265     5.7197425514459610e-02
    z[5,4,4]  R2266     -1.7119950056076050e-01
    z[5,4,4]  R2267     3.0332329869270325e-01
    z[5,4,4]  R2268     -1.3827908039093018e-01
    z[5,4,4]  R2269     3.6695733666419983e-01
    z[5,4,4]  R2270     -1.0033635795116425e-01
    z[5,4,4]  R2271     -3.8435709476470947e-01
    z[5,4,4]  R2272     4.3267095088958740e-01
    z[5,4,4]  R2273     -2.3215970396995544e-01
    z[5,4,4]  R2274     -3.3439084887504578e-01
    z[5,4,4]  R2275     -1.2737533450126648e-01
    z[5,4,4]  R2276     2.2421942651271820e-01
    z[5,4,4]  R2277     -3.1862971186637878e-01
    z[5,4,4]  R2278     -1.4161466062068939e-01
    z[5,4,4]  R2279     -2.0014038681983948e-01
    z[5,4,4]  R2280     -1.7013674974441528e-01
    z[5,4,4]  R2281     -2.2357928752899170e-01
    z[5,4,4]  R2282     4.8134982585906982e-01
    z[5,4,4]  R2283     3.0386200547218323e-01
    z[5,4,4]  R2284     5.6228119134902954e-01
    z[5,4,4]  R2285     2.6087793707847595e-01
    z[5,4,4]  R2286     -1.7765650525689125e-02
    z[5,4,4]  R2287     5.7998904958367348e-03
    z[5,4,4]  R2288     -1.9561885297298431e-01
    z[5,4,4]  R2289     -1.5254600346088409e-01
    z[5,4,4]  R2290     -2.3245088756084442e-01
    z[5,4,4]  R2291     -2.4510839581489563e-01
    z[5,4,4]  R2292     3.4389652311801910e-02
    z[5,4,4]  R2293     1.6696244478225708e-01
    z[5,4,4]  R2294     3.9626786112785339e-01
    z[5,4,4]  R2295     -4.9778923392295837e-02
    z[5,4,4]  R2296     1.0410825908184052e-01
    z[5,4,4]  R2297     -3.0679020285606384e-01
    z[5,4,4]  R2298     2.2262823581695557e-01
    z[5,4,4]  R2299     -0.0813310518860817
    z[5,4,4]  R2300     9.8297655582427979e-02
    z[5,4,4]  R2301     9.0512603521347046e-02
    z[5,4,4]  R2302     4.6489360928535461e-01
    z[5,4,4]  R2303     -9.3833103775978088e-02
    z[5,4,4]  R2304     4.2973878979682922e-01
    z[5,4,4]  R2305     3.6662909388542175e-01
    z[5,4,4]  R2306     5.0199198722839355e-01
    z[5,4,4]  R2307     -4.3391962535679340e-03
    z[5,4,4]  R2308     1.9471764564514160e-01
    z[5,4,4]  R2309     -2.9023903608322144e-01
    z[5,4,4]  R2310     -2.7248394489288330e-01
    z[5,4,4]  R2311     -2.4616238474845886e-01
    z[5,4,4]  R2312     2.4163340032100677e-01
    z[5,4,4]  R2313     -2.2500516474246979e-01
    z[5,4,4]  R2314     -1.0002250224351883e-01
    z[5,4,4]  R2315     -7.6770171523094177e-02
    z[5,4,4]  R2316     -2.0987370610237122e-01
    z[5,4,4]  R2317     -1.0867885500192642e-01
    z[5,4,4]  R2318     -6.6451430320739746e-02
    z[5,4,4]  R2319     -5.7496535778045654e-01
    z[5,4,4]  R2320     -4.4193667173385620e-01
    z[5,4,4]  R2321     -4.9371123313903809e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R2208     -1
    z[5,4,5]  R2209     1
    z[5,4,5]  R2212     -3.6672794818878174e-01
    z[5,4,5]  R2213     -5.5276203155517578e-01
    z[5,4,5]  R2214     -4.0194973349571228e-01
    z[5,4,5]  R2215     0.0419129841029644
    z[5,4,5]  R2216     -0.748490035533905
    z[5,4,5]  R2217     1.4861298725008965e-02
    z[5,4,5]  R2218     8.3549067378044128e-02
    z[5,4,5]  R2219     1.3186158239841461e-01
    z[5,4,5]  R2220     5.1337409019470215e-01
    z[5,4,5]  R2221     3.2437229156494141e-01
    z[5,4,5]  R2222     3.2740112394094467e-02
    z[5,4,5]  R2223     4.1143134236335754e-02
    z[5,4,5]  R2224     4.3569406867027283e-01
    z[5,4,5]  R2225     3.2644793391227722e-01
    z[5,4,5]  R2226     3.2438716292381287e-01
    z[5,4,5]  R2227     3.2985344529151917e-01
    z[5,4,5]  R2228     2.5985753536224365e-01
    z[5,4,5]  R2229     4.8788863420486450e-01
    z[5,4,5]  R2230     5.6804078817367554e-01
    z[5,4,5]  R2231     3.2667967677116394e-01
    z[5,4,5]  R2232     3.8111633062362671e-01
    z[5,4,5]  R2233     5.5571067333221436e-01
    z[5,4,5]  R2234     1.8060798943042755e-01
    z[5,4,5]  R2235     -1.1214573681354523e-01
    z[5,4,5]  R2236     1.6730263829231262e-01
    z[5,4,5]  R2237     5.3711807727813721e-01
    z[5,4,5]  R2238     7.2642147541046143e-02
    z[5,4,5]  R2239     1.1676761507987976e-01
    z[5,4,5]  R2240     -7.5571663677692413e-02
    z[5,4,5]  R2241     1.6545480489730835e-01
    z[5,4,5]  R2242     -4.1990029811859131e-01
    z[5,4,5]  R2243     -6.0991442203521729e-01
    z[5,4,5]  R2244     -4.6201825141906738e-01
    z[5,4,5]  R2245     0.0101442476734519
    z[5,4,5]  R2246     -6.8104475736618042e-02
    z[5,4,5]  R2247     -2.8355339169502258e-01
    z[5,4,5]  R2248     -7.7083487994968891e-03
    z[5,4,5]  R2249     -1.7236265540122986e-01
    z[5,4,5]  R2250     -2.4853106588125229e-02
    z[5,4,5]  R2251     -8.7030403316020966e-02
    z[5,4,5]  R2252     -1.6514272987842560e-01
    z[5,4,5]  R2253     -2.5870227813720703e-01
    z[5,4,5]  R2254     -4.4403988122940063e-01
    z[5,4,5]  R2255     -3.7668019533157349e-01
    z[5,4,5]  R2256     -2.0139142870903015e-01
    z[5,4,5]  R2257     -7.1815311908721924e-01
    z[5,4,5]  R2258     1.2453091889619827e-01
    z[5,4,5]  R2259     -2.5025227665901184e-01
    z[5,4,5]  R2260     -3.5274305939674377e-01
    z[5,4,5]  R2261     -6.1772572994232178e-01
    z[5,4,5]  R2262     -6.2005412578582764e-01
    z[5,4,5]  R2263     -4.0256899595260620e-01
    z[5,4,5]  R2264     3.3030384778976440e-01
    z[5,4,5]  R2265     4.0965270996093750e-01
    z[5,4,5]  R2266     -4.8622965812683105e-01
    z[5,4,5]  R2267     1.9258794188499451e-01
    z[5,4,5]  R2268     1.0406956821680069e-01
    z[5,4,5]  R2269     8.2377210259437561e-02
    z[5,4,5]  R2270     -8.4257304668426514e-02
    z[5,4,5]  R2271     3.9063131809234619e-01
    z[5,4,5]  R2272     1.0816441476345062e-01
    z[5,4,5]  R2273     0.349244624376297
    z[5,4,5]  R2274     -3.9362901449203491e-01
    z[5,4,5]  R2275     -5.9012597799301147e-01
    z[5,4,5]  R2276     -7.8150975704193115e-01
    z[5,4,5]  R2277     -6.7393243312835693e-01
    z[5,4,5]  R2278     -2.3224505782127380e-01
    z[5,4,5]  R2279     -6.3647961616516113e-01
    z[5,4,5]  R2280     -6.0548824071884155e-01
    z[5,4,5]  R2281     -1.4366070926189423e-01
    z[5,4,5]  R2282     4.4098678976297379e-02
    z[5,4,5]  R2283     -4.5739594101905823e-01
    z[5,4,5]  R2284     1.4385650865733624e-02
    z[5,4,5]  R2285     -5.9956979751586914e-01
    z[5,4,5]  R2286     -6.7116081714630127e-01
    z[5,4,5]  R2287     -5.8865559101104736e-01
    z[5,4,5]  R2288     -1.8110229074954987e-01
    z[5,4,5]  R2289     -1.0773810744285583e-01
    z[5,4,5]  R2290     2.6756206154823303e-01
    z[5,4,5]  R2291     1.8646885454654694e-01
    z[5,4,5]  R2292     -5.6428488343954086e-02
    z[5,4,5]  R2293     2.0217919349670410e-01
    z[5,4,5]  R2294     -3.9791306853294373e-01
    z[5,4,5]  R2295     -5.7171505689620972e-01
    z[5,4,5]  R2296     -3.4493902325630188e-01
    z[5,4,5]  R2297     7.1420714259147644e-02
    z[5,4,5]  R2298     3.5805463790893555e-01
    z[5,4,5]  R2299     -1.9722411036491394e-01
    z[5,4,5]  R2300     -1.6521330177783966e-01
    z[5,4,5]  R2301     -5.1570698618888855e-02
    z[5,4,5]  R2302     2.0275006070733070e-02
    z[5,4,5]  R2303     -3.8745424151420593e-01
    z[5,4,5]  R2304     -1.4860782027244568e-01
    z[5,4,5]  R2305     -2.1801829338073730e-01
    z[5,4,5]  R2306     2.8767675161361694e-01
    z[5,4,5]  R2307     -4.2009210586547852e-01
    z[5,4,5]  R2308     3.5468569397926331e-01
    z[5,4,5]  R2309     2.0468638837337494e-01
    z[5,4,5]  R2310     1.5067258477210999e-01
    z[5,4,5]  R2311     -2.4595342576503754e-02
    z[5,4,5]  R2312     -8.1414008140563965e-01
    z[5,4,5]  R2313     0.0750207006931305
    z[5,4,5]  R2314     -0.131648451089859
    z[5,4,5]  R2315     1.3997261226177216e-01
    z[5,4,5]  R2316     2.8227525949478149e-01
    z[5,4,5]  R2317     1.3914388418197632e-01
    z[5,4,5]  R2318     1.4618138968944550e-01
    z[5,4,5]  R2319     -1.0838557034730911e-01
    z[5,4,5]  R2320     -1.1386824399232864e-01
    z[5,4,5]  R2321     1.1800454556941986e-01
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R2210     -1
    z[5,4,6]  R2211     1
    z[5,4,6]  R2212     3.4444382786750793e-01
    z[5,4,6]  R2213     -1.6767981648445129e-01
    z[5,4,6]  R2214     -0.0714760273694992
    z[5,4,6]  R2215     -6.8889975547790527e-02
    z[5,4,6]  R2216     -1.3277265429496765e-01
    z[5,4,6]  R2217     0.0651208832859993
    z[5,4,6]  R2218     -4.1888660192489624e-01
    z[5,4,6]  R2219     -5.0906103849411011e-01
    z[5,4,6]  R2220     -3.4804448485374451e-01
    z[5,4,6]  R2221     2.8391024470329285e-01
    z[5,4,6]  R2222     5.7311558723449707e-01
    z[5,4,6]  R2223     5.5515062808990479e-01
    z[5,4,6]  R2224     2.2358103096485138e-01
    z[5,4,6]  R2225     3.0527812242507935e-01
    z[5,4,6]  R2226     2.2190552949905396e-01
    z[5,4,6]  R2227     2.8065380454063416e-01
    z[5,4,6]  R2228     3.8068944215774536e-01
    z[5,4,6]  R2229     2.5680848956108093e-01
    z[5,4,6]  R2230     1.5874877572059631e-01
    z[5,4,6]  R2231     3.6465290188789368e-01
    z[5,4,6]  R2232     2.7287659049034119e-01
    z[5,4,6]  R2233     -8.6940238252282143e-03
    z[5,4,6]  R2234     3.3845886588096619e-01
    z[5,4,6]  R2235     -5.6192469596862793e-01
    z[5,4,6]  R2236     3.7011390924453735e-01
    z[5,4,6]  R2237     9.6734218299388885e-02
    z[5,4,6]  R2238     2.8947748243808746e-02
    z[5,4,6]  R2239     8.4491841495037079e-02
    z[5,4,6]  R2240     -2.7116268873214722e-01
    z[5,4,6]  R2241     5.5536723136901855e-01
    z[5,4,6]  R2242     -1.0864780098199844e-01
    z[5,4,6]  R2243     -3.1635737419128418e-01
    z[5,4,6]  R2244     2.7368339896202087e-01
    z[5,4,6]  R2245     -6.4924255013465881e-02
    z[5,4,6]  R2246     1.6080971807241440e-02
    z[5,4,6]  R2247     1.1388626694679260e-01
    z[5,4,6]  R2248     -1.1335127800703049e-01
    z[5,4,6]  R2249     6.2742494046688080e-02
    z[5,4,6]  R2250     8.7315574288368225e-02
    z[5,4,6]  R2251     -4.3224021792411804e-01
    z[5,4,6]  R2252     4.6385556459426880e-01
    z[5,4,6]  R2253     1.3388817012310028e-01
    z[5,4,6]  R2254     -1.0406203567981720e-01
    z[5,4,6]  R2255     -3.2532370090484619e-01
    z[5,4,6]  R2256     -5.8396351337432861e-01
    z[5,4,6]  R2257     -6.0750752687454224e-02
    z[5,4,6]  R2258     3.7941977381706238e-01
    z[5,4,6]  R2259     -8.0928064882755280e-02
    z[5,4,6]  R2260     -3.2811298966407776e-01
    z[5,4,6]  R2261     5.3886175155639648e-03
    z[5,4,6]  R2262     -2.4670192599296570e-01
    z[5,4,6]  R2263     1.5145288407802582e-01
    z[5,4,6]  R2264     -1.2451510876417160e-01
    z[5,4,6]  R2265     1.9450066983699799e-01
    z[5,4,6]  R2266     5.6221973150968552e-02
    z[5,4,6]  R2267     4.0203872323036194e-01
    z[5,4,6]  R2268     -6.0775661468505859e-01
    z[5,4,6]  R2269     -4.1605624556541443e-01
    z[5,4,6]  R2270     -2.0083867013454437e-02
    z[5,4,6]  R2271     -4.1355829685926437e-02
    z[5,4,6]  R2272     0.169141948223114
    z[5,4,6]  R2273     -2.3644529283046722e-01
    z[5,4,6]  R2274     -5.4670977592468262e-01
    z[5,4,6]  R2275     -4.8036286234855652e-01
    z[5,4,6]  R2276     -1.3549636304378510e-01
    z[5,4,6]  R2277     1.3533039391040802e-01
    z[5,4,6]  R2278     -3.3536779880523682e-01
    z[5,4,6]  R2279     -7.4160680174827576e-02
    z[5,4,6]  R2280     3.9604222774505615e-01
    z[5,4,6]  R2281     8.2372479140758514e-02
    z[5,4,6]  R2282     -2.0938409864902496e-01
    z[5,4,6]  R2283     -9.9131613969802856e-02
    z[5,4,6]  R2284     -1.5620626509189606e-01
    z[5,4,6]  R2285     -3.5751909017562866e-02
    z[5,4,6]  R2286     3.4721937775611877e-01
    z[5,4,6]  R2287     -1.6696329414844513e-01
    z[5,4,6]  R2288     -5.4487246274948120e-01
    z[5,4,6]  R2289     2.4621315300464630e-01
    z[5,4,6]  R2290     -2.9758375883102417e-01
    z[5,4,6]  R2291     -3.2744112610816956e-01
    z[5,4,6]  R2292     -1.3781943917274475e-01
    z[5,4,6]  R2293     1.9308337569236755e-01
    z[5,4,6]  R2294     -4.1964939236640930e-01
    z[5,4,6]  R2295     -3.2751351594924927e-02
    z[5,4,6]  R2296     4.0953123569488525e-01
    z[5,4,6]  R2297     -2.7584463357925415e-01
    z[5,4,6]  R2298     -6.4742863178253174e-01
    z[5,4,6]  R2299     -1.5823251008987427e-01
    z[5,4,6]  R2300     1.8326042592525482e-01
    z[5,4,6]  R2301     8.2990802824497223e-02
    z[5,4,6]  R2302     -6.4104783535003662e-01
    z[5,4,6]  R2303     -7.6623722910881042e-02
    z[5,4,6]  R2304     -1.5886804461479187e-01
    z[5,4,6]  R2305     2.6446020603179932e-01
    z[5,4,6]  R2306     -4.7957371920347214e-02
    z[5,4,6]  R2307     1.0231915861368179e-01
    z[5,4,6]  R2308     -6.3529020547866821e-01
    z[5,4,6]  R2309     -2.9536217451095581e-01
    z[5,4,6]  R2310     -1.2536510825157166e-01
    z[5,4,6]  R2311     -2.9091672971844673e-02
    z[5,4,6]  R2312     -2.2160361707210541e-01
    z[5,4,6]  R2313     -4.0055537223815918e-01
    z[5,4,6]  R2314     -0.0674145370721817
    z[5,4,6]  R2315     7.8882798552513123e-02
    z[5,4,6]  R2316     3.0971509218215942e-01
    z[5,4,6]  R2317     2.9696798324584961e-01
    z[5,4,6]  R2318     1.4758327975869179e-02
    z[5,4,6]  R2319     2.4358795583248138e-01
    z[5,4,6]  R2320     1.0696541517972946e-01
    z[5,4,6]  R2321     3.1952759623527527e-01
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R2426     -1
    z[5,6,0]  R2427     1
    z[5,6,0]  R2440     -2.6823753118515015e-01
    z[5,6,0]  R2441     -6.5219156444072723e-02
    z[5,6,0]  R2442     -2.8410360217094421e-01
    z[5,6,0]  R2443     -4.4057813286781311e-01
    z[5,6,0]  R2444     -1.4141286909580231e-01
    z[5,6,0]  R2445     6.6742408275604248e-01
    z[5,6,0]  R2446     7.5001978874206543e-01
    z[5,6,0]  R2447     1.8080644309520721e-01
    z[5,6,0]  R2448     4.8582616448402405e-01
    z[5,6,0]  R2449     4.6337318420410156e-01
    z[5,6,0]  R2450     -3.2918116450309753e-01
    z[5,6,0]  R2451     -5.2980142831802368e-01
    z[5,6,0]  R2452     1.3590514659881592e-01
    z[5,6,0]  R2453     1.8562240898609161e-01
    z[5,6,0]  R2454     1.7441925406455994e-01
    z[5,6,0]  R2455     -9.4519846141338348e-02
    z[5,6,0]  R2456     4.6904768794775009e-02
    z[5,6,0]  R2457     -5.8192804455757141e-02
    z[5,6,0]  R2458     1.9962343573570251e-01
    z[5,6,0]  R2459     -0.294490784406662
    z[5,6,0]  R2460     -5.2107390947639942e-03
    z[5,6,0]  R2461     -1.9177805632352829e-02
    z[5,6,0]  R2462     5.3346121311187744e-01
    z[5,6,0]  R2463     4.2087772488594055e-01
    z[5,6,0]  R2464     4.9826869368553162e-01
    z[5,6,0]  R2465     5.3279006481170654e-01
    z[5,6,0]  R2466     6.5640980005264282e-01
    z[5,6,0]  R2467     3.3792454004287720e-01
    z[5,6,0]  R2468     5.7616049051284790e-01
    z[5,6,0]  R2469     5.8036917448043823e-01
    z[5,6,0]  R2470     -3.4743244759738445e-03
    z[5,6,0]  R2471     -1.2308333814144135e-01
    z[5,6,0]  R2472     -3.7155374884605408e-01
    z[5,6,0]  R2473     -5.4898804426193237e-01
    z[5,6,0]  R2474     -2.5332772731781006e-01
    z[5,6,0]  R2475     -6.1840850114822388e-01
    z[5,6,0]  R2476     -6.1318671703338623e-01
    z[5,6,0]  R2477     -3.2655423879623413e-01
    z[5,6,0]  R2478     -1.0422305762767792e-01
    z[5,6,0]  R2479     -6.5365648269653320e-01
    z[5,6,0]  R2480     -3.8282939791679382e-01
    z[5,6,0]  R2481     -1.6345612704753876e-01
    z[5,6,0]  R2482     3.2546854019165039e-01
    z[5,6,0]  R2483     -5.4201591014862061e-01
    z[5,6,0]  R2484     -2.6580983400344849e-01
    z[5,6,0]  R2485     -2.0024487376213074e-01
    z[5,6,0]  R2486     -5.1235926151275635e-01
    z[5,6,0]  R2487     -6.5226331353187561e-02
    z[5,6,0]  R2488     -1.7295217514038086e-01
    z[5,6,0]  R2489     -3.3874583244323730e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R2428     -1
    z[5,6,1]  R2429     1
    z[5,6,1]  R2440     2.4573600292205811e-01
    z[5,6,1]  R2441     3.6279591917991638e-01
    z[5,6,1]  R2442     -6.1442929506301880e-01
    z[5,6,1]  R2443     2.6527587324380875e-02
    z[5,6,1]  R2444     -3.9439103007316589e-01
    z[5,6,1]  R2445     3.2276561856269836e-01
    z[5,6,1]  R2446     4.2350569367408752e-01
    z[5,6,1]  R2447     1.2853574752807617e-01
    z[5,6,1]  R2448     5.3194683790206909e-01
    z[5,6,1]  R2449     5.1429039239883423e-01
    z[5,6,1]  R2450     3.9422520995140076e-01
    z[5,6,1]  R2451     2.7047321200370789e-01
    z[5,6,1]  R2452     -7.6316612958908081e-01
    z[5,6,1]  R2453     -7.5528490543365479e-01
    z[5,6,1]  R2454     -7.9375445842742920e-01
    z[5,6,1]  R2455     -6.4786761999130249e-01
    z[5,6,1]  R2456     -7.3607826232910156e-01
    z[5,6,1]  R2457     -7.1364831924438477e-01
    z[5,6,1]  R2458     -7.4419844150543213e-01
    z[5,6,1]  R2459     -6.3241493701934814e-01
    z[5,6,1]  R2460     -0.463029146194458
    z[5,6,1]  R2461     4.5317122340202332e-01
    z[5,6,1]  R2462     -3.9997357130050659e-01
    z[5,6,1]  R2463     1.8852078914642334e-01
    z[5,6,1]  R2464     -3.9411702752113342e-01
    z[5,6,1]  R2465     2.3744247853755951e-01
    z[5,6,1]  R2466     2.1724076569080353e-01
    z[5,6,1]  R2467     -5.6819128990173340e-01
    z[5,6,1]  R2468     2.7435201406478882e-01
    z[5,6,1]  R2469     1.6648538410663605e-01
    z[5,6,1]  R2470     -6.7764058709144592e-02
    z[5,6,1]  R2471     8.5038393735885620e-02
    z[5,6,1]  R2472     -8.6744648218154907e-01
    z[5,6,1]  R2473     -7.4145448207855225e-01
    z[5,6,1]  R2474     -8.1563413143157959e-01
    z[5,6,1]  R2475     -5.2506881952285767e-01
    z[5,6,1]  R2476     -0.619130551815033
    z[5,6,1]  R2477     -6.3107943534851074e-01
    z[5,6,1]  R2478     -6.8970000743865967e-01
    z[5,6,1]  R2479     -4.0858045220375061e-01
    z[5,6,1]  R2480     2.7977058291435242e-01
    z[5,6,1]  R2481     -3.9654040336608887e-01
    z[5,6,1]  R2482     -5.4879948496818542e-02
    z[5,6,1]  R2483     -3.6780336499214172e-01
    z[5,6,1]  R2484     5.1064151525497437e-01
    z[5,6,1]  R2485     0.16551573574543
    z[5,6,1]  R2486     1.3627509772777557e-01
    z[5,6,1]  R2487     7.3188805580139160e-01
    z[5,6,1]  R2488     6.3836479187011719e-01
    z[5,6,1]  R2489     -9.5175787806510925e-02
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R2430     -1
    z[5,6,2]  R2431     1
    z[5,6,2]  R2440     -3.1426379084587097e-01
    z[5,6,2]  R2441     -3.8013070821762085e-01
    z[5,6,2]  R2442     -2.6275274157524109e-01
    z[5,6,2]  R2443     1.3911771774291992e-01
    z[5,6,2]  R2444     -4.1727340221405029e-01
    z[5,6,2]  R2445     -2.8148925304412842e-01
    z[5,6,2]  R2446     -1.5927772223949432e-01
    z[5,6,2]  R2447     3.7788701057434082e-01
    z[5,6,2]  R2448     2.7874574065208435e-01
    z[5,6,2]  R2449     -6.0055539011955261e-02
    z[5,6,2]  R2450     6.1995659023523331e-02
    z[5,6,2]  R2451     0.241798996925354
    z[5,6,2]  R2452     0.273393839597702
    z[5,6,2]  R2453     1.4513716101646423e-01
    z[5,6,2]  R2454     2.1221699193120003e-02
    z[5,6,2]  R2455     1.7214192450046539e-01
    z[5,6,2]  R2456     2.2800672054290771e-01
    z[5,6,2]  R2457     2.6251357793807983e-01
    z[5,6,2]  R2458     1.3650007545948029e-01
    z[5,6,2]  R2459     2.9738715291023254e-01
    z[5,6,2]  R2460     2.5370424985885620e-01
    z[5,6,2]  R2461     4.7708079218864441e-01
    z[5,6,2]  R2462     4.5294904708862305e-01
    z[5,6,2]  R2463     7.5022113323211670e-01
    z[5,6,2]  R2464     5.1763975620269775e-01
    z[5,6,2]  R2465     7.3303419351577759e-01
    z[5,6,2]  R2466     0.573716402053833
    z[5,6,2]  R2467     6.5565681457519531e-01
    z[5,6,2]  R2468     7.1206021308898926e-01
    z[5,6,2]  R2469     4.1576743125915527e-01
    z[5,6,2]  R2470     -0.636843204498291
    z[5,6,2]  R2471     -3.6151629686355591e-01
    z[5,6,2]  R2472     -1.4550860226154327e-01
    z[5,6,2]  R2473     -1.5195912122726440e-01
    z[5,6,2]  R2474     -2.5232285261154175e-01
    z[5,6,2]  R2475     -3.3051258325576782e-01
    z[5,6,2]  R2476     -3.2100066542625427e-01
    z[5,6,2]  R2477     -3.0456984043121338e-01
    z[5,6,2]  R2478     -5.4235816001892090e-01
    z[5,6,2]  R2479     -2.3770385980606079e-01
    z[5,6,2]  R2480     3.0719444155693054e-01
    z[5,6,2]  R2481     2.6448589563369751e-01
    z[5,6,2]  R2482     4.0804558992385864e-01
    z[5,6,2]  R2483     -4.6224242448806763e-01
    z[5,6,2]  R2484     3.7779358029365540e-01
    z[5,6,2]  R2485     2.1731008589267731e-01
    z[5,6,2]  R2486     -2.8794929385185242e-01
    z[5,6,2]  R2487     -3.4672487527132034e-02
    z[5,6,2]  R2488     2.6825872063636780e-01
    z[5,6,2]  R2489     6.0277175903320312e-01
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R2432     -1
    z[5,6,3]  R2433     1
    z[5,6,3]  R2440     -5.9839230775833130e-01
    z[5,6,3]  R2441     -5.6734341382980347e-01
    z[5,6,3]  R2442     -5.5254191160202026e-01
    z[5,6,3]  R2443     -0.86295485496521
    z[5,6,3]  R2444     5.8465588837862015e-02
    z[5,6,3]  R2445     5.6408715248107910e-01
    z[5,6,3]  R2446     1.9337294995784760e-01
    z[5,6,3]  R2447     7.1931129693984985e-01
    z[5,6,3]  R2448     1.1560782790184021e-01
    z[5,6,3]  R2449     2.3387832939624786e-01
    z[5,6,3]  R2450     0.283197283744812
    z[5,6,3]  R2451     3.9575561881065369e-01
    z[5,6,3]  R2452     2.7132576704025269e-01
    z[5,6,3]  R2453     3.9909040927886963e-01
    z[5,6,3]  R2454     4.2910179495811462e-01
    z[5,6,3]  R2455     4.4801110029220581e-01
    z[5,6,3]  R2456     3.9648792147636414e-01
    z[5,6,3]  R2457     2.7338972687721252e-01
    z[5,6,3]  R2458     1.7293485999107361e-01
    z[5,6,3]  R2459     4.2913112044334412e-01
    z[5,6,3]  R2460     -1.2812557816505432e-01
    z[5,6,3]  R2461     2.7356836199760437e-01
    z[5,6,3]  R2462     -5.2921187877655029e-01
    z[5,6,3]  R2463     -3.3385384082794189e-01
    z[5,6,3]  R2464     -5.3937900066375732e-01
    z[5,6,3]  R2465     -3.0621933937072754e-01
    z[5,6,3]  R2466     -2.3727174103260040e-01
    z[5,6,3]  R2467     -3.6090376973152161e-01
    z[5,6,3]  R2468     -0.038233682513237
    z[5,6,3]  R2469     -6.1332726478576660e-01
    z[5,6,3]  R2470     3.4797564148902893e-01
    z[5,6,3]  R2471     5.8470505475997925e-01
    z[5,6,3]  R2472     2.4236537516117096e-01
    z[5,6,3]  R2473     2.3465169966220856e-01
    z[5,6,3]  R2474     2.1231047809123993e-01
    z[5,6,3]  R2475     -0.346811443567276
    z[5,6,3]  R2476     -1.6981753706932068e-01
    z[5,6,3]  R2477     -2.0098647475242615e-01
    z[5,6,3]  R2478     -1.9764246046543121e-01
    z[5,6,3]  R2479     -1.8382544815540314e-01
    z[5,6,3]  R2480     3.5857412964105606e-02
    z[5,6,3]  R2481     0.81771320104599
    z[5,6,3]  R2482     3.8813319802284241e-01
    z[5,6,3]  R2483     -1.8799242377281189e-01
    z[5,6,3]  R2484     -3.0278982594609261e-02
    z[5,6,3]  R2485     -5.5477118492126465e-01
    z[5,6,3]  R2486     -4.2916965484619141e-01
    z[5,6,3]  R2487     -3.5344421863555908e-01
    z[5,6,3]  R2488     -5.6654590368270874e-01
    z[5,6,3]  R2489     -2.5631973147392273e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R2434     -1
    z[5,6,4]  R2435     1
    z[5,6,4]  R2440     3.9711022377014160e-01
    z[5,6,4]  R2441     -2.5315082073211670e-01
    z[5,6,4]  R2442     -2.7344502508640289e-02
    z[5,6,4]  R2443     -1.8611754477024078e-01
    z[5,6,4]  R2444     -2.6278665661811829e-01
    z[5,6,4]  R2445     2.2017116844654083e-01
    z[5,6,4]  R2446     1.1359731853008270e-01
    z[5,6,4]  R2447     -1.1853111535310745e-01
    z[5,6,4]  R2448     0.072480209171772
    z[5,6,4]  R2449     5.2598720788955688e-01
    z[5,6,4]  R2450     -5.6802171468734741e-01
    z[5,6,4]  R2451     -3.4810966253280640e-01
    z[5,6,4]  R2452     -1.0453492403030396e-01
    z[5,6,4]  R2453     -1.2242580950260162e-01
    z[5,6,4]  R2454     2.1998232230544090e-02
    z[5,6,4]  R2455     -3.9168462157249451e-01
    z[5,6,4]  R2456     1.8533350527286530e-01
    z[5,6,4]  R2457     1.9919458031654358e-01
    z[5,6,4]  R2458     -9.9543638527393341e-02
    z[5,6,4]  R2459     3.2287046313285828e-02
    z[5,6,4]  R2460     -8.3284348249435425e-01
    z[5,6,4]  R2461     -6.0675281286239624e-01
    z[5,6,4]  R2462     1.7943026125431061e-01
    z[5,6,4]  R2463     2.1165351569652557e-01
    z[5,6,4]  R2464     5.3122036159038544e-02
    z[5,6,4]  R2465     -2.7994986623525620e-02
    z[5,6,4]  R2466     6.0909830033779144e-02
    z[5,6,4]  R2467     2.0996691659092903e-02
    z[5,6,4]  R2468     2.4418279528617859e-01
    z[5,6,4]  R2469     1.3282354176044464e-01
    z[5,6,4]  R2470     -5.0129914283752441e-01
    z[5,6,4]  R2471     -4.1763642430305481e-01
    z[5,6,4]  R2472     1.1798995733261108e-01
    z[5,6,4]  R2473     -4.7457154840230942e-02
    z[5,6,4]  R2474     2.4797822535037994e-01
    z[5,6,4]  R2475     -3.3877289388328791e-03
    z[5,6,4]  R2476     2.5931772589683533e-01
    z[5,6,4]  R2477     -2.3311829194426537e-02
    z[5,6,4]  R2478     3.4339752048254013e-02
    z[5,6,4]  R2479     -1.6188608109951019e-01
    z[5,6,4]  R2480     -5.6225913763046265e-01
    z[5,6,4]  R2481     -1.6311031579971313e-01
    z[5,6,4]  R2482     -1.6476285457611084e-01
    z[5,6,4]  R2483     7.8983316197991371e-03
    z[5,6,4]  R2484     0.668416440486908
    z[5,6,4]  R2485     6.7164522409439087e-01
    z[5,6,4]  R2486     -1.8812704086303711e-01
    z[5,6,4]  R2487     5.6265187263488770e-01
    z[5,6,4]  R2488     1.8205238878726959e-01
    z[5,6,4]  R2489     6.6807526350021362e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R2436     -1
    z[5,6,5]  R2437     1
    z[5,6,5]  R2440     -3.6672794818878174e-01
    z[5,6,5]  R2441     -5.5276203155517578e-01
    z[5,6,5]  R2442     -4.0194973349571228e-01
    z[5,6,5]  R2443     0.0419129841029644
    z[5,6,5]  R2444     -0.748490035533905
    z[5,6,5]  R2445     1.4861298725008965e-02
    z[5,6,5]  R2446     8.3549067378044128e-02
    z[5,6,5]  R2447     1.3186158239841461e-01
    z[5,6,5]  R2448     5.1337409019470215e-01
    z[5,6,5]  R2449     3.2437229156494141e-01
    z[5,6,5]  R2450     3.2740112394094467e-02
    z[5,6,5]  R2451     4.1143134236335754e-02
    z[5,6,5]  R2452     4.3569406867027283e-01
    z[5,6,5]  R2453     3.2644793391227722e-01
    z[5,6,5]  R2454     3.2438716292381287e-01
    z[5,6,5]  R2455     3.2985344529151917e-01
    z[5,6,5]  R2456     2.5985753536224365e-01
    z[5,6,5]  R2457     4.8788863420486450e-01
    z[5,6,5]  R2458     5.6804078817367554e-01
    z[5,6,5]  R2459     3.2667967677116394e-01
    z[5,6,5]  R2460     5.0700742751359940e-02
    z[5,6,5]  R2461     -3.4988054633140564e-01
    z[5,6,5]  R2462     1.7902784049510956e-02
    z[5,6,5]  R2463     8.9013829827308655e-02
    z[5,6,5]  R2464     -0.0491558238863945
    z[5,6,5]  R2465     -1.6641260683536530e-01
    z[5,6,5]  R2466     1.7898994684219360e-01
    z[5,6,5]  R2467     -2.2681452333927155e-02
    z[5,6,5]  R2468     -2.3320766165852547e-02
    z[5,6,5]  R2469     -9.5537595450878143e-02
    z[5,6,5]  R2470     2.3141373693943024e-01
    z[5,6,5]  R2471     2.0014445483684540e-01
    z[5,6,5]  R2472     -7.4222333729267120e-02
    z[5,6,5]  R2473     -2.4428756535053253e-01
    z[5,6,5]  R2474     3.1565821170806885e-01
    z[5,6,5]  R2475     -1.4559094607830048e-01
    z[5,6,5]  R2476     -2.0341484248638153e-01
    z[5,6,5]  R2477     -4.9272051453590393e-01
    z[5,6,5]  R2478     -1.6252711415290833e-01
    z[5,6,5]  R2479     -5.1126211881637573e-01
    z[5,6,5]  R2480     5.9974884986877441e-01
    z[5,6,5]  R2481     -2.2125542163848877e-01
    z[5,6,5]  R2482     0.613357663154602
    z[5,6,5]  R2483     -5.4441195726394653e-01
    z[5,6,5]  R2484     2.1309484541416168e-01
    z[5,6,5]  R2485     3.2975459098815918e-01
    z[5,6,5]  R2486     -6.3749986886978149e-01
    z[5,6,5]  R2487     1.3013105094432831e-01
    z[5,6,5]  R2488     2.2970614954829216e-02
    z[5,6,5]  R2489     2.0947758108377457e-02
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R2438     -1
    z[5,6,6]  R2439     1
    z[5,6,6]  R2440     3.4444382786750793e-01
    z[5,6,6]  R2441     -1.6767981648445129e-01
    z[5,6,6]  R2442     -0.0714760273694992
    z[5,6,6]  R2443     -6.8889975547790527e-02
    z[5,6,6]  R2444     -1.3277265429496765e-01
    z[5,6,6]  R2445     0.0651208832859993
    z[5,6,6]  R2446     -4.1888660192489624e-01
    z[5,6,6]  R2447     -5.0906103849411011e-01
    z[5,6,6]  R2448     -3.4804448485374451e-01
    z[5,6,6]  R2449     2.8391024470329285e-01
    z[5,6,6]  R2450     5.7311558723449707e-01
    z[5,6,6]  R2451     5.5515062808990479e-01
    z[5,6,6]  R2452     2.2358103096485138e-01
    z[5,6,6]  R2453     3.0527812242507935e-01
    z[5,6,6]  R2454     2.2190552949905396e-01
    z[5,6,6]  R2455     2.8065380454063416e-01
    z[5,6,6]  R2456     3.8068944215774536e-01
    z[5,6,6]  R2457     2.5680848956108093e-01
    z[5,6,6]  R2458     1.5874877572059631e-01
    z[5,6,6]  R2459     3.6465290188789368e-01
    z[5,6,6]  R2460     -9.2715196311473846e-02
    z[5,6,6]  R2461     -3.5453815013170242e-02
    z[5,6,6]  R2462     -1.9415597617626190e-01
    z[5,6,6]  R2463     2.4558302760124207e-01
    z[5,6,6]  R2464     1.7966997623443604e-01
    z[5,6,6]  R2465     -1.3015929609537125e-02
    z[5,6,6]  R2466     -3.1739047169685364e-01
    z[5,6,6]  R2467     -4.3279886245727539e-02
    z[5,6,6]  R2468     -0.155271977186203
    z[5,6,6]  R2469     -2.4423734843730927e-01
    z[5,6,6]  R2470     4.0482887625694275e-01
    z[5,6,6]  R2471     -5.3904253244400024e-01
    z[5,6,6]  R2472     -1.0069804638624191e-01
    z[5,6,6]  R2473     9.3679733574390411e-02
    z[5,6,6]  R2474     2.6271790266036987e-02
    z[5,6,6]  R2475     0.301908403635025
    z[5,6,6]  R2476     -1.3290268369019032e-02
    z[5,6,6]  R2477     -3.4442096948623657e-01
    z[5,6,6]  R2478     -3.9069458842277527e-01
    z[5,6,6]  R2479     1.6704581677913666e-01
    z[5,6,6]  R2480     6.0678459703922272e-02
    z[5,6,6]  R2481     -4.3259564787149429e-02
    z[5,6,6]  R2482     4.1298347711563110e-01
    z[5,6,6]  R2483     -1.5963518619537354e-01
    z[5,6,6]  R2484     1.8098542094230652e-01
    z[5,6,6]  R2485     1.3291537761688232e-01
    z[5,6,6]  R2486     1.0008950531482697e-01
    z[5,6,6]  R2487     -2.1194621920585632e-02
    z[5,6,6]  R2488     3.6874154210090637e-01
    z[5,6,6]  R2489     -1.9895978271961212e-02
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2490     -1
    z[6,5,0]  R2491     1
    z[6,5,0]  R2504     -5.2107390947639942e-03
    z[6,5,0]  R2505     -1.9177805632352829e-02
    z[6,5,0]  R2506     5.3346121311187744e-01
    z[6,5,0]  R2507     4.2087772488594055e-01
    z[6,5,0]  R2508     4.9826869368553162e-01
    z[6,5,0]  R2509     5.3279006481170654e-01
    z[6,5,0]  R2510     6.5640980005264282e-01
    z[6,5,0]  R2511     3.3792454004287720e-01
    z[6,5,0]  R2512     5.7616049051284790e-01
    z[6,5,0]  R2513     5.8036917448043823e-01
    z[6,5,0]  R2514     -3.4743244759738445e-03
    z[6,5,0]  R2515     -1.2308333814144135e-01
    z[6,5,0]  R2516     -3.7155374884605408e-01
    z[6,5,0]  R2517     -5.4898804426193237e-01
    z[6,5,0]  R2518     -2.5332772731781006e-01
    z[6,5,0]  R2519     -6.1840850114822388e-01
    z[6,5,0]  R2520     -6.1318671703338623e-01
    z[6,5,0]  R2521     -3.2655423879623413e-01
    z[6,5,0]  R2522     -1.0422305762767792e-01
    z[6,5,0]  R2523     -6.5365648269653320e-01
    z[6,5,0]  R2524     -3.8282939791679382e-01
    z[6,5,0]  R2525     -1.6345612704753876e-01
    z[6,5,0]  R2526     3.2546854019165039e-01
    z[6,5,0]  R2527     -5.4201591014862061e-01
    z[6,5,0]  R2528     -2.6580983400344849e-01
    z[6,5,0]  R2529     -2.0024487376213074e-01
    z[6,5,0]  R2530     -5.1235926151275635e-01
    z[6,5,0]  R2531     -6.5226331353187561e-02
    z[6,5,0]  R2532     -1.7295217514038086e-01
    z[6,5,0]  R2533     -3.3874583244323730e-01
    z[6,5,0]  R2534     -2.6823753118515015e-01
    z[6,5,0]  R2535     -6.5219156444072723e-02
    z[6,5,0]  R2536     -2.8410360217094421e-01
    z[6,5,0]  R2537     -4.4057813286781311e-01
    z[6,5,0]  R2538     -1.4141286909580231e-01
    z[6,5,0]  R2539     6.6742408275604248e-01
    z[6,5,0]  R2540     7.5001978874206543e-01
    z[6,5,0]  R2541     1.8080644309520721e-01
    z[6,5,0]  R2542     4.8582616448402405e-01
    z[6,5,0]  R2543     4.6337318420410156e-01
    z[6,5,0]  R2544     -3.2918116450309753e-01
    z[6,5,0]  R2545     -5.2980142831802368e-01
    z[6,5,0]  R2546     1.3590514659881592e-01
    z[6,5,0]  R2547     1.8562240898609161e-01
    z[6,5,0]  R2548     1.7441925406455994e-01
    z[6,5,0]  R2549     -9.4519846141338348e-02
    z[6,5,0]  R2550     4.6904768794775009e-02
    z[6,5,0]  R2551     -5.8192804455757141e-02
    z[6,5,0]  R2552     1.9962343573570251e-01
    z[6,5,0]  R2553     -0.294490784406662
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2492     -1
    z[6,5,1]  R2493     1
    z[6,5,1]  R2504     -0.463029146194458
    z[6,5,1]  R2505     4.5317122340202332e-01
    z[6,5,1]  R2506     -3.9997357130050659e-01
    z[6,5,1]  R2507     1.8852078914642334e-01
    z[6,5,1]  R2508     -3.9411702752113342e-01
    z[6,5,1]  R2509     2.3744247853755951e-01
    z[6,5,1]  R2510     2.1724076569080353e-01
    z[6,5,1]  R2511     -5.6819128990173340e-01
    z[6,5,1]  R2512     2.7435201406478882e-01
    z[6,5,1]  R2513     1.6648538410663605e-01
    z[6,5,1]  R2514     -6.7764058709144592e-02
    z[6,5,1]  R2515     8.5038393735885620e-02
    z[6,5,1]  R2516     -8.6744648218154907e-01
    z[6,5,1]  R2517     -7.4145448207855225e-01
    z[6,5,1]  R2518     -8.1563413143157959e-01
    z[6,5,1]  R2519     -5.2506881952285767e-01
    z[6,5,1]  R2520     -0.619130551815033
    z[6,5,1]  R2521     -6.3107943534851074e-01
    z[6,5,1]  R2522     -6.8970000743865967e-01
    z[6,5,1]  R2523     -4.0858045220375061e-01
    z[6,5,1]  R2524     2.7977058291435242e-01
    z[6,5,1]  R2525     -3.9654040336608887e-01
    z[6,5,1]  R2526     -5.4879948496818542e-02
    z[6,5,1]  R2527     -3.6780336499214172e-01
    z[6,5,1]  R2528     5.1064151525497437e-01
    z[6,5,1]  R2529     0.16551573574543
    z[6,5,1]  R2530     1.3627509772777557e-01
    z[6,5,1]  R2531     7.3188805580139160e-01
    z[6,5,1]  R2532     6.3836479187011719e-01
    z[6,5,1]  R2533     -9.5175787806510925e-02
    z[6,5,1]  R2534     2.4573600292205811e-01
    z[6,5,1]  R2535     3.6279591917991638e-01
    z[6,5,1]  R2536     -6.1442929506301880e-01
    z[6,5,1]  R2537     2.6527587324380875e-02
    z[6,5,1]  R2538     -3.9439103007316589e-01
    z[6,5,1]  R2539     3.2276561856269836e-01
    z[6,5,1]  R2540     4.2350569367408752e-01
    z[6,5,1]  R2541     1.2853574752807617e-01
    z[6,5,1]  R2542     5.3194683790206909e-01
    z[6,5,1]  R2543     5.1429039239883423e-01
    z[6,5,1]  R2544     3.9422520995140076e-01
    z[6,5,1]  R2545     2.7047321200370789e-01
    z[6,5,1]  R2546     -7.6316612958908081e-01
    z[6,5,1]  R2547     -7.5528490543365479e-01
    z[6,5,1]  R2548     -7.9375445842742920e-01
    z[6,5,1]  R2549     -6.4786761999130249e-01
    z[6,5,1]  R2550     -7.3607826232910156e-01
    z[6,5,1]  R2551     -7.1364831924438477e-01
    z[6,5,1]  R2552     -7.4419844150543213e-01
    z[6,5,1]  R2553     -6.3241493701934814e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2494     -1
    z[6,5,2]  R2495     1
    z[6,5,2]  R2504     2.5370424985885620e-01
    z[6,5,2]  R2505     4.7708079218864441e-01
    z[6,5,2]  R2506     4.5294904708862305e-01
    z[6,5,2]  R2507     7.5022113323211670e-01
    z[6,5,2]  R2508     5.1763975620269775e-01
    z[6,5,2]  R2509     7.3303419351577759e-01
    z[6,5,2]  R2510     0.573716402053833
    z[6,5,2]  R2511     6.5565681457519531e-01
    z[6,5,2]  R2512     7.1206021308898926e-01
    z[6,5,2]  R2513     4.1576743125915527e-01
    z[6,5,2]  R2514     -0.636843204498291
    z[6,5,2]  R2515     -3.6151629686355591e-01
    z[6,5,2]  R2516     -1.4550860226154327e-01
    z[6,5,2]  R2517     -1.5195912122726440e-01
    z[6,5,2]  R2518     -2.5232285261154175e-01
    z[6,5,2]  R2519     -3.3051258325576782e-01
    z[6,5,2]  R2520     -3.2100066542625427e-01
    z[6,5,2]  R2521     -3.0456984043121338e-01
    z[6,5,2]  R2522     -5.4235816001892090e-01
    z[6,5,2]  R2523     -2.3770385980606079e-01
    z[6,5,2]  R2524     3.0719444155693054e-01
    z[6,5,2]  R2525     2.6448589563369751e-01
    z[6,5,2]  R2526     4.0804558992385864e-01
    z[6,5,2]  R2527     -4.6224242448806763e-01
    z[6,5,2]  R2528     3.7779358029365540e-01
    z[6,5,2]  R2529     2.1731008589267731e-01
    z[6,5,2]  R2530     -2.8794929385185242e-01
    z[6,5,2]  R2531     -3.4672487527132034e-02
    z[6,5,2]  R2532     2.6825872063636780e-01
    z[6,5,2]  R2533     6.0277175903320312e-01
    z[6,5,2]  R2534     -3.1426379084587097e-01
    z[6,5,2]  R2535     -3.8013070821762085e-01
    z[6,5,2]  R2536     -2.6275274157524109e-01
    z[6,5,2]  R2537     1.3911771774291992e-01
    z[6,5,2]  R2538     -4.1727340221405029e-01
    z[6,5,2]  R2539     -2.8148925304412842e-01
    z[6,5,2]  R2540     -1.5927772223949432e-01
    z[6,5,2]  R2541     3.7788701057434082e-01
    z[6,5,2]  R2542     2.7874574065208435e-01
    z[6,5,2]  R2543     -6.0055539011955261e-02
    z[6,5,2]  R2544     6.1995659023523331e-02
    z[6,5,2]  R2545     0.241798996925354
    z[6,5,2]  R2546     0.273393839597702
    z[6,5,2]  R2547     1.4513716101646423e-01
    z[6,5,2]  R2548     2.1221699193120003e-02
    z[6,5,2]  R2549     1.7214192450046539e-01
    z[6,5,2]  R2550     2.2800672054290771e-01
    z[6,5,2]  R2551     2.6251357793807983e-01
    z[6,5,2]  R2552     1.3650007545948029e-01
    z[6,5,2]  R2553     2.9738715291023254e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2496     -1
    z[6,5,3]  R2497     1
    z[6,5,3]  R2504     -1.2812557816505432e-01
    z[6,5,3]  R2505     2.7356836199760437e-01
    z[6,5,3]  R2506     -5.2921187877655029e-01
    z[6,5,3]  R2507     -3.3385384082794189e-01
    z[6,5,3]  R2508     -5.3937900066375732e-01
    z[6,5,3]  R2509     -3.0621933937072754e-01
    z[6,5,3]  R2510     -2.3727174103260040e-01
    z[6,5,3]  R2511     -3.6090376973152161e-01
    z[6,5,3]  R2512     -0.038233682513237
    z[6,5,3]  R2513     -6.1332726478576660e-01
    z[6,5,3]  R2514     3.4797564148902893e-01
    z[6,5,3]  R2515     5.8470505475997925e-01
    z[6,5,3]  R2516     2.4236537516117096e-01
    z[6,5,3]  R2517     2.3465169966220856e-01
    z[6,5,3]  R2518     2.1231047809123993e-01
    z[6,5,3]  R2519     -0.346811443567276
    z[6,5,3]  R2520     -1.6981753706932068e-01
    z[6,5,3]  R2521     -2.0098647475242615e-01
    z[6,5,3]  R2522     -1.9764246046543121e-01
    z[6,5,3]  R2523     -1.8382544815540314e-01
    z[6,5,3]  R2524     3.5857412964105606e-02
    z[6,5,3]  R2525     0.81771320104599
    z[6,5,3]  R2526     3.8813319802284241e-01
    z[6,5,3]  R2527     -1.8799242377281189e-01
    z[6,5,3]  R2528     -3.0278982594609261e-02
    z[6,5,3]  R2529     -5.5477118492126465e-01
    z[6,5,3]  R2530     -4.2916965484619141e-01
    z[6,5,3]  R2531     -3.5344421863555908e-01
    z[6,5,3]  R2532     -5.6654590368270874e-01
    z[6,5,3]  R2533     -2.5631973147392273e-01
    z[6,5,3]  R2534     -5.9839230775833130e-01
    z[6,5,3]  R2535     -5.6734341382980347e-01
    z[6,5,3]  R2536     -5.5254191160202026e-01
    z[6,5,3]  R2537     -0.86295485496521
    z[6,5,3]  R2538     5.8465588837862015e-02
    z[6,5,3]  R2539     5.6408715248107910e-01
    z[6,5,3]  R2540     1.9337294995784760e-01
    z[6,5,3]  R2541     7.1931129693984985e-01
    z[6,5,3]  R2542     1.1560782790184021e-01
    z[6,5,3]  R2543     2.3387832939624786e-01
    z[6,5,3]  R2544     0.283197283744812
    z[6,5,3]  R2545     3.9575561881065369e-01
    z[6,5,3]  R2546     2.7132576704025269e-01
    z[6,5,3]  R2547     3.9909040927886963e-01
    z[6,5,3]  R2548     4.2910179495811462e-01
    z[6,5,3]  R2549     4.4801110029220581e-01
    z[6,5,3]  R2550     3.9648792147636414e-01
    z[6,5,3]  R2551     2.7338972687721252e-01
    z[6,5,3]  R2552     1.7293485999107361e-01
    z[6,5,3]  R2553     4.2913112044334412e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2498     -1
    z[6,5,4]  R2499     1
    z[6,5,4]  R2504     -8.3284348249435425e-01
    z[6,5,4]  R2505     -6.0675281286239624e-01
    z[6,5,4]  R2506     1.7943026125431061e-01
    z[6,5,4]  R2507     2.1165351569652557e-01
    z[6,5,4]  R2508     5.3122036159038544e-02
    z[6,5,4]  R2509     -2.7994986623525620e-02
    z[6,5,4]  R2510     6.0909830033779144e-02
    z[6,5,4]  R2511     2.0996691659092903e-02
    z[6,5,4]  R2512     2.4418279528617859e-01
    z[6,5,4]  R2513     1.3282354176044464e-01
    z[6,5,4]  R2514     -5.0129914283752441e-01
    z[6,5,4]  R2515     -4.1763642430305481e-01
    z[6,5,4]  R2516     1.1798995733261108e-01
    z[6,5,4]  R2517     -4.7457154840230942e-02
    z[6,5,4]  R2518     2.4797822535037994e-01
    z[6,5,4]  R2519     -3.3877289388328791e-03
    z[6,5,4]  R2520     2.5931772589683533e-01
    z[6,5,4]  R2521     -2.3311829194426537e-02
    z[6,5,4]  R2522     3.4339752048254013e-02
    z[6,5,4]  R2523     -1.6188608109951019e-01
    z[6,5,4]  R2524     -5.6225913763046265e-01
    z[6,5,4]  R2525     -1.6311031579971313e-01
    z[6,5,4]  R2526     -1.6476285457611084e-01
    z[6,5,4]  R2527     7.8983316197991371e-03
    z[6,5,4]  R2528     0.668416440486908
    z[6,5,4]  R2529     6.7164522409439087e-01
    z[6,5,4]  R2530     -1.8812704086303711e-01
    z[6,5,4]  R2531     5.6265187263488770e-01
    z[6,5,4]  R2532     1.8205238878726959e-01
    z[6,5,4]  R2533     6.6807526350021362e-01
    z[6,5,4]  R2534     3.9711022377014160e-01
    z[6,5,4]  R2535     -2.5315082073211670e-01
    z[6,5,4]  R2536     -2.7344502508640289e-02
    z[6,5,4]  R2537     -1.8611754477024078e-01
    z[6,5,4]  R2538     -2.6278665661811829e-01
    z[6,5,4]  R2539     2.2017116844654083e-01
    z[6,5,4]  R2540     1.1359731853008270e-01
    z[6,5,4]  R2541     -1.1853111535310745e-01
    z[6,5,4]  R2542     0.072480209171772
    z[6,5,4]  R2543     5.2598720788955688e-01
    z[6,5,4]  R2544     -5.6802171468734741e-01
    z[6,5,4]  R2545     -3.4810966253280640e-01
    z[6,5,4]  R2546     -1.0453492403030396e-01
    z[6,5,4]  R2547     -1.2242580950260162e-01
    z[6,5,4]  R2548     2.1998232230544090e-02
    z[6,5,4]  R2549     -3.9168462157249451e-01
    z[6,5,4]  R2550     1.8533350527286530e-01
    z[6,5,4]  R2551     1.9919458031654358e-01
    z[6,5,4]  R2552     -9.9543638527393341e-02
    z[6,5,4]  R2553     3.2287046313285828e-02
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2500     -1
    z[6,5,5]  R2501     1
    z[6,5,5]  R2504     5.0700742751359940e-02
    z[6,5,5]  R2505     -3.4988054633140564e-01
    z[6,5,5]  R2506     1.7902784049510956e-02
    z[6,5,5]  R2507     8.9013829827308655e-02
    z[6,5,5]  R2508     -0.0491558238863945
    z[6,5,5]  R2509     -1.6641260683536530e-01
    z[6,5,5]  R2510     1.7898994684219360e-01
    z[6,5,5]  R2511     -2.2681452333927155e-02
    z[6,5,5]  R2512     -2.3320766165852547e-02
    z[6,5,5]  R2513     -9.5537595450878143e-02
    z[6,5,5]  R2514     2.3141373693943024e-01
    z[6,5,5]  R2515     2.0014445483684540e-01
    z[6,5,5]  R2516     -7.4222333729267120e-02
    z[6,5,5]  R2517     -2.4428756535053253e-01
    z[6,5,5]  R2518     3.1565821170806885e-01
    z[6,5,5]  R2519     -1.4559094607830048e-01
    z[6,5,5]  R2520     -2.0341484248638153e-01
    z[6,5,5]  R2521     -4.9272051453590393e-01
    z[6,5,5]  R2522     -1.6252711415290833e-01
    z[6,5,5]  R2523     -5.1126211881637573e-01
    z[6,5,5]  R2524     5.9974884986877441e-01
    z[6,5,5]  R2525     -2.2125542163848877e-01
    z[6,5,5]  R2526     0.613357663154602
    z[6,5,5]  R2527     -5.4441195726394653e-01
    z[6,5,5]  R2528     2.1309484541416168e-01
    z[6,5,5]  R2529     3.2975459098815918e-01
    z[6,5,5]  R2530     -6.3749986886978149e-01
    z[6,5,5]  R2531     1.3013105094432831e-01
    z[6,5,5]  R2532     2.2970614954829216e-02
    z[6,5,5]  R2533     2.0947758108377457e-02
    z[6,5,5]  R2534     -3.6672794818878174e-01
    z[6,5,5]  R2535     -5.5276203155517578e-01
    z[6,5,5]  R2536     -4.0194973349571228e-01
    z[6,5,5]  R2537     0.0419129841029644
    z[6,5,5]  R2538     -0.748490035533905
    z[6,5,5]  R2539     1.4861298725008965e-02
    z[6,5,5]  R2540     8.3549067378044128e-02
    z[6,5,5]  R2541     1.3186158239841461e-01
    z[6,5,5]  R2542     5.1337409019470215e-01
    z[6,5,5]  R2543     3.2437229156494141e-01
    z[6,5,5]  R2544     3.2740112394094467e-02
    z[6,5,5]  R2545     4.1143134236335754e-02
    z[6,5,5]  R2546     4.3569406867027283e-01
    z[6,5,5]  R2547     3.2644793391227722e-01
    z[6,5,5]  R2548     3.2438716292381287e-01
    z[6,5,5]  R2549     3.2985344529151917e-01
    z[6,5,5]  R2550     2.5985753536224365e-01
    z[6,5,5]  R2551     4.8788863420486450e-01
    z[6,5,5]  R2552     5.6804078817367554e-01
    z[6,5,5]  R2553     3.2667967677116394e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2502     -1
    z[6,5,6]  R2503     1
    z[6,5,6]  R2504     -9.2715196311473846e-02
    z[6,5,6]  R2505     -3.5453815013170242e-02
    z[6,5,6]  R2506     -1.9415597617626190e-01
    z[6,5,6]  R2507     2.4558302760124207e-01
    z[6,5,6]  R2508     1.7966997623443604e-01
    z[6,5,6]  R2509     -1.3015929609537125e-02
    z[6,5,6]  R2510     -3.1739047169685364e-01
    z[6,5,6]  R2511     -4.3279886245727539e-02
    z[6,5,6]  R2512     -0.155271977186203
    z[6,5,6]  R2513     -2.4423734843730927e-01
    z[6,5,6]  R2514     4.0482887625694275e-01
    z[6,5,6]  R2515     -5.3904253244400024e-01
    z[6,5,6]  R2516     -1.0069804638624191e-01
    z[6,5,6]  R2517     9.3679733574390411e-02
    z[6,5,6]  R2518     2.6271790266036987e-02
    z[6,5,6]  R2519     0.301908403635025
    z[6,5,6]  R2520     -1.3290268369019032e-02
    z[6,5,6]  R2521     -3.4442096948623657e-01
    z[6,5,6]  R2522     -3.9069458842277527e-01
    z[6,5,6]  R2523     1.6704581677913666e-01
    z[6,5,6]  R2524     6.0678459703922272e-02
    z[6,5,6]  R2525     -4.3259564787149429e-02
    z[6,5,6]  R2526     4.1298347711563110e-01
    z[6,5,6]  R2527     -1.5963518619537354e-01
    z[6,5,6]  R2528     1.8098542094230652e-01
    z[6,5,6]  R2529     1.3291537761688232e-01
    z[6,5,6]  R2530     1.0008950531482697e-01
    z[6,5,6]  R2531     -2.1194621920585632e-02
    z[6,5,6]  R2532     3.6874154210090637e-01
    z[6,5,6]  R2533     -1.9895978271961212e-02
    z[6,5,6]  R2534     3.4444382786750793e-01
    z[6,5,6]  R2535     -1.6767981648445129e-01
    z[6,5,6]  R2536     -0.0714760273694992
    z[6,5,6]  R2537     -6.8889975547790527e-02
    z[6,5,6]  R2538     -1.3277265429496765e-01
    z[6,5,6]  R2539     0.0651208832859993
    z[6,5,6]  R2540     -4.1888660192489624e-01
    z[6,5,6]  R2541     -5.0906103849411011e-01
    z[6,5,6]  R2542     -3.4804448485374451e-01
    z[6,5,6]  R2543     2.8391024470329285e-01
    z[6,5,6]  R2544     5.7311558723449707e-01
    z[6,5,6]  R2545     5.5515062808990479e-01
    z[6,5,6]  R2546     2.2358103096485138e-01
    z[6,5,6]  R2547     3.0527812242507935e-01
    z[6,5,6]  R2548     2.2190552949905396e-01
    z[6,5,6]  R2549     2.8065380454063416e-01
    z[6,5,6]  R2550     3.8068944215774536e-01
    z[6,5,6]  R2551     2.5680848956108093e-01
    z[6,5,6]  R2552     1.5874877572059631e-01
    z[6,5,6]  R2553     3.6465290188789368e-01
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R2554     -1
    z[6,7,0]  R2555     1
    z[6,7,0]  R2568     -5.2107390947639942e-03
    z[6,7,0]  R2569     -1.9177805632352829e-02
    z[6,7,0]  R2570     5.3346121311187744e-01
    z[6,7,0]  R2571     4.2087772488594055e-01
    z[6,7,0]  R2572     4.9826869368553162e-01
    z[6,7,0]  R2573     5.3279006481170654e-01
    z[6,7,0]  R2574     6.5640980005264282e-01
    z[6,7,0]  R2575     3.3792454004287720e-01
    z[6,7,0]  R2576     5.7616049051284790e-01
    z[6,7,0]  R2577     5.8036917448043823e-01
    z[6,7,0]  R2578     -3.4743244759738445e-03
    z[6,7,0]  R2579     -1.2308333814144135e-01
    z[6,7,0]  R2580     -3.7155374884605408e-01
    z[6,7,0]  R2581     -5.4898804426193237e-01
    z[6,7,0]  R2582     -2.5332772731781006e-01
    z[6,7,0]  R2583     -6.1840850114822388e-01
    z[6,7,0]  R2584     -6.1318671703338623e-01
    z[6,7,0]  R2585     -3.2655423879623413e-01
    z[6,7,0]  R2586     -1.0422305762767792e-01
    z[6,7,0]  R2587     -6.5365648269653320e-01
    z[6,7,0]  R2588     -3.8282939791679382e-01
    z[6,7,0]  R2589     -1.6345612704753876e-01
    z[6,7,0]  R2590     3.2546854019165039e-01
    z[6,7,0]  R2591     -5.4201591014862061e-01
    z[6,7,0]  R2592     -2.6580983400344849e-01
    z[6,7,0]  R2593     -2.0024487376213074e-01
    z[6,7,0]  R2594     -5.1235926151275635e-01
    z[6,7,0]  R2595     -6.5226331353187561e-02
    z[6,7,0]  R2596     -1.7295217514038086e-01
    z[6,7,0]  R2597     -3.3874583244323730e-01
    z[6,7,0]  R2598     -3.0372151732444763e-01
    z[6,7,0]  R2599     -3.0008256435394287e-01
    z[6,7,0]  R2600     -1.9094075262546539e-01
    z[6,7,0]  R2601     -4.8980396986007690e-01
    z[6,7,0]  R2602     5.5676519870758057e-01
    z[6,7,0]  R2603     5.4785132408142090e-01
    z[6,7,0]  R2604     4.7637981176376343e-01
    z[6,7,0]  R2605     4.1669556498527527e-01
    z[6,7,0]  R2606     0.401156485080719
    z[6,7,0]  R2607     -5.4611825942993164e-01
    z[6,7,0]  R2608     -7.9487943649291992e-01
    z[6,7,0]  R2609     -8.1363278627395630e-01
    z[6,7,0]  R2610     -6.1245149374008179e-01
    z[6,7,0]  R2611     -0.700247585773468
    z[6,7,0]  R2612     3.4501597285270691e-01
    z[6,7,0]  R2613     -0.606789767742157
    z[6,7,0]  R2614     0.114809550344944
    z[6,7,0]  R2615     1.8719317018985748e-01
    z[6,7,0]  R2616     -4.5119252800941467e-01
    z[6,7,0]  R2617     -3.0796242877840996e-02
    z[6,7,0]  R2618     -7.3783248662948608e-01
    z[6,7,0]  R2619     -4.0503782033920288e-01
    z[6,7,0]  R2620     0.321079283952713
    z[6,7,0]  R2621     4.3968539685010910e-02
    z[6,7,0]  R2622     -7.1097129583358765e-01
    z[6,7,0]  R2623     -5.9146308898925781e-01
    z[6,7,0]  R2624     1.9861114025115967e-01
    z[6,7,0]  R2625     5.8389854431152344e-01
    z[6,7,0]  R2626     2.4765689671039581e-01
    z[6,7,0]  R2627     3.3355557918548584e-01
    z[6,7,0]  R2628     2.8576344251632690e-01
    z[6,7,0]  R2629     -5.9667402505874634e-01
    z[6,7,0]  R2630     3.8589265942573547e-01
    z[6,7,0]  R2631     -5.8138000965118408e-01
    z[6,7,0]  R2632     1.3199988007545471e-01
    z[6,7,0]  R2633     8.4620010852813721e-01
    z[6,7,0]  R2634     8.3288741111755371e-01
    z[6,7,0]  R2635     3.1440284848213196e-01
    z[6,7,0]  R2636     -1.6727916896343231e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R2556     -1
    z[6,7,1]  R2557     1
    z[6,7,1]  R2568     -0.463029146194458
    z[6,7,1]  R2569     4.5317122340202332e-01
    z[6,7,1]  R2570     -3.9997357130050659e-01
    z[6,7,1]  R2571     1.8852078914642334e-01
    z[6,7,1]  R2572     -3.9411702752113342e-01
    z[6,7,1]  R2573     2.3744247853755951e-01
    z[6,7,1]  R2574     2.1724076569080353e-01
    z[6,7,1]  R2575     -5.6819128990173340e-01
    z[6,7,1]  R2576     2.7435201406478882e-01
    z[6,7,1]  R2577     1.6648538410663605e-01
    z[6,7,1]  R2578     -6.7764058709144592e-02
    z[6,7,1]  R2579     8.5038393735885620e-02
    z[6,7,1]  R2580     -8.6744648218154907e-01
    z[6,7,1]  R2581     -7.4145448207855225e-01
    z[6,7,1]  R2582     -8.1563413143157959e-01
    z[6,7,1]  R2583     -5.2506881952285767e-01
    z[6,7,1]  R2584     -0.619130551815033
    z[6,7,1]  R2585     -6.3107943534851074e-01
    z[6,7,1]  R2586     -6.8970000743865967e-01
    z[6,7,1]  R2587     -4.0858045220375061e-01
    z[6,7,1]  R2588     2.7977058291435242e-01
    z[6,7,1]  R2589     -3.9654040336608887e-01
    z[6,7,1]  R2590     -5.4879948496818542e-02
    z[6,7,1]  R2591     -3.6780336499214172e-01
    z[6,7,1]  R2592     5.1064151525497437e-01
    z[6,7,1]  R2593     0.16551573574543
    z[6,7,1]  R2594     1.3627509772777557e-01
    z[6,7,1]  R2595     7.3188805580139160e-01
    z[6,7,1]  R2596     6.3836479187011719e-01
    z[6,7,1]  R2597     -9.5175787806510925e-02
    z[6,7,1]  R2598     5.9839583933353424e-02
    z[6,7,1]  R2599     -1.0776294022798538e-01
    z[6,7,1]  R2600     6.7972518503665924e-02
    z[6,7,1]  R2601     1.4336401224136353e-01
    z[6,7,1]  R2602     -5.6059449911117554e-01
    z[6,7,1]  R2603     1.1334766447544098e-01
    z[6,7,1]  R2604     -3.8519391417503357e-01
    z[6,7,1]  R2605     -4.1615876555442810e-01
    z[6,7,1]  R2606     0.0632009282708168
    z[6,7,1]  R2607     -2.7729475498199463e-01
    z[6,7,1]  R2608     2.7077552676200867e-01
    z[6,7,1]  R2609     6.6772729158401489e-02
    z[6,7,1]  R2610     2.6250171661376953e-01
    z[6,7,1]  R2611     -1.0952156037092209e-01
    z[6,7,1]  R2612     -3.4136629104614258e-01
    z[6,7,1]  R2613     1.3359403237700462e-02
    z[6,7,1]  R2614     -1.4204810559749603e-01
    z[6,7,1]  R2615     7.0631068944931030e-01
    z[6,7,1]  R2616     2.6673880219459534e-01
    z[6,7,1]  R2617     5.8728420734405518e-01
    z[6,7,1]  R2618     -1.0162436962127686e-01
    z[6,7,1]  R2619     1.6930936276912689e-01
    z[6,7,1]  R2620     -2.3312389850616455e-01
    z[6,7,1]  R2621     -3.2947105169296265e-01
    z[6,7,1]  R2622     4.0027368068695068e-01
    z[6,7,1]  R2623     -6.2102526426315308e-02
    z[6,7,1]  R2624     8.3066987991333008e-01
    z[6,7,1]  R2625     -1.1053048074245453e-01
    z[6,7,1]  R2626     6.7984503507614136e-01
    z[6,7,1]  R2627     6.7457187175750732e-01
    z[6,7,1]  R2628     -1.7039711773395538e-01
    z[6,7,1]  R2629     -1.3729162514209747e-01
    z[6,7,1]  R2630     2.9298362787812948e-03
    z[6,7,1]  R2631     8.2027778029441833e-02
    z[6,7,1]  R2632     7.8628820180892944e-01
    z[6,7,1]  R2633     0.228877454996109
    z[6,7,1]  R2634     1.7244207859039307e-01
    z[6,7,1]  R2635     3.3402338624000549e-01
    z[6,7,1]  R2636     -0.778550386428833
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R2558     -1
    z[6,7,2]  R2559     1
    z[6,7,2]  R2568     2.5370424985885620e-01
    z[6,7,2]  R2569     4.7708079218864441e-01
    z[6,7,2]  R2570     4.5294904708862305e-01
    z[6,7,2]  R2571     7.5022113323211670e-01
    z[6,7,2]  R2572     5.1763975620269775e-01
    z[6,7,2]  R2573     7.3303419351577759e-01
    z[6,7,2]  R2574     0.573716402053833
    z[6,7,2]  R2575     6.5565681457519531e-01
    z[6,7,2]  R2576     7.1206021308898926e-01
    z[6,7,2]  R2577     4.1576743125915527e-01
    z[6,7,2]  R2578     -0.636843204498291
    z[6,7,2]  R2579     -3.6151629686355591e-01
    z[6,7,2]  R2580     -1.4550860226154327e-01
    z[6,7,2]  R2581     -1.5195912122726440e-01
    z[6,7,2]  R2582     -2.5232285261154175e-01
    z[6,7,2]  R2583     -3.3051258325576782e-01
    z[6,7,2]  R2584     -3.2100066542625427e-01
    z[6,7,2]  R2585     -3.0456984043121338e-01
    z[6,7,2]  R2586     -5.4235816001892090e-01
    z[6,7,2]  R2587     -2.3770385980606079e-01
    z[6,7,2]  R2588     3.0719444155693054e-01
    z[6,7,2]  R2589     2.6448589563369751e-01
    z[6,7,2]  R2590     4.0804558992385864e-01
    z[6,7,2]  R2591     -4.6224242448806763e-01
    z[6,7,2]  R2592     3.7779358029365540e-01
    z[6,7,2]  R2593     2.1731008589267731e-01
    z[6,7,2]  R2594     -2.8794929385185242e-01
    z[6,7,2]  R2595     -3.4672487527132034e-02
    z[6,7,2]  R2596     2.6825872063636780e-01
    z[6,7,2]  R2597     6.0277175903320312e-01
    z[6,7,2]  R2598     8.8125967979431152e-01
    z[6,7,2]  R2599     8.7643355131149292e-01
    z[6,7,2]  R2600     8.7768596410751343e-01
    z[6,7,2]  R2601     7.1278828382492065e-01
    z[6,7,2]  R2602     5.1686805486679077e-01
    z[6,7,2]  R2603     7.8773558139801025e-01
    z[6,7,2]  R2604     5.2271687984466553e-01
    z[6,7,2]  R2605     5.4136687517166138e-01
    z[6,7,2]  R2606     8.6033004522323608e-01
    z[6,7,2]  R2607     3.5049009323120117e-01
    z[6,7,2]  R2608     -1.5173679590225220e-01
    z[6,7,2]  R2609     -1.2127404659986496e-01
    z[6,7,2]  R2610     5.2269272506237030e-02
    z[6,7,2]  R2611     0.067268505692482
    z[6,7,2]  R2612     3.1443178653717041e-01
    z[6,7,2]  R2613     -6.9947414100170135e-02
    z[6,7,2]  R2614     4.9026903510093689e-01
    z[6,7,2]  R2615     -1.1069977283477783e-01
    z[6,7,2]  R2616     -1.5725065767765045e-01
    z[6,7,2]  R2617     -5.0107151269912720e-02
    z[6,7,2]  R2618     1.5685613453388214e-01
    z[6,7,2]  R2619     6.5976572036743164e-01
    z[6,7,2]  R2620     6.0806733369827271e-01
    z[6,7,2]  R2621     6.1673003435134888e-01
    z[6,7,2]  R2622     -2.2239057719707489e-01
    z[6,7,2]  R2623     1.4230807125568390e-01
    z[6,7,2]  R2624     3.3870470523834229e-01
    z[6,7,2]  R2625     0.274432510137558
    z[6,7,2]  R2626     2.4938605725765228e-01
    z[6,7,2]  R2627     -1.8986427783966064e-01
    z[6,7,2]  R2628     8.6477959156036377e-01
    z[6,7,2]  R2629     4.5375841856002808e-01
    z[6,7,2]  R2630     7.2029000520706177e-01
    z[6,7,2]  R2631     1.0285206884145737e-01
    z[6,7,2]  R2632     7.4434056878089905e-03
    z[6,7,2]  R2633     -2.0413251221179962e-01
    z[6,7,2]  R2634     -2.1016301214694977e-01
    z[6,7,2]  R2635     -1.7740696668624878e-01
    z[6,7,2]  R2636     -1.4455151557922363e-01
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R2560     -1
    z[6,7,3]  R2561     1
    z[6,7,3]  R2568     -1.2812557816505432e-01
    z[6,7,3]  R2569     2.7356836199760437e-01
    z[6,7,3]  R2570     -5.2921187877655029e-01
    z[6,7,3]  R2571     -3.3385384082794189e-01
    z[6,7,3]  R2572     -5.3937900066375732e-01
    z[6,7,3]  R2573     -3.0621933937072754e-01
    z[6,7,3]  R2574     -2.3727174103260040e-01
    z[6,7,3]  R2575     -3.6090376973152161e-01
    z[6,7,3]  R2576     -0.038233682513237
    z[6,7,3]  R2577     -6.1332726478576660e-01
    z[6,7,3]  R2578     3.4797564148902893e-01
    z[6,7,3]  R2579     5.8470505475997925e-01
    z[6,7,3]  R2580     2.4236537516117096e-01
    z[6,7,3]  R2581     2.3465169966220856e-01
    z[6,7,3]  R2582     2.1231047809123993e-01
    z[6,7,3]  R2583     -0.346811443567276
    z[6,7,3]  R2584     -1.6981753706932068e-01
    z[6,7,3]  R2585     -2.0098647475242615e-01
    z[6,7,3]  R2586     -1.9764246046543121e-01
    z[6,7,3]  R2587     -1.8382544815540314e-01
    z[6,7,3]  R2588     3.5857412964105606e-02
    z[6,7,3]  R2589     0.81771320104599
    z[6,7,3]  R2590     3.8813319802284241e-01
    z[6,7,3]  R2591     -1.8799242377281189e-01
    z[6,7,3]  R2592     -3.0278982594609261e-02
    z[6,7,3]  R2593     -5.5477118492126465e-01
    z[6,7,3]  R2594     -4.2916965484619141e-01
    z[6,7,3]  R2595     -3.5344421863555908e-01
    z[6,7,3]  R2596     -5.6654590368270874e-01
    z[6,7,3]  R2597     -2.5631973147392273e-01
    z[6,7,3]  R2598     -1.6969552636146545e-01
    z[6,7,3]  R2599     -1.1241710186004639e-01
    z[6,7,3]  R2600     -2.3333995044231415e-01
    z[6,7,3]  R2601     -2.4053138494491577e-01
    z[6,7,3]  R2602     -3.0179014801979065e-01
    z[6,7,3]  R2603     -0.180845707654953
    z[6,7,3]  R2604     -4.8619282245635986e-01
    z[6,7,3]  R2605     -5.4015350341796875e-01
    z[6,7,3]  R2606     8.8432110846042633e-02
    z[6,7,3]  R2607     -1.5006552636623383e-01
    z[6,7,3]  R2608     4.9502205848693848e-01
    z[6,7,3]  R2609     3.9076185226440430e-01
    z[6,7,3]  R2610     0.510936975479126
    z[6,7,3]  R2611     3.9284959435462952e-01
    z[6,7,3]  R2612     2.4078071117401123e-01
    z[6,7,3]  R2613     -2.4797025322914124e-01
    z[6,7,3]  R2614     2.2925460338592529e-01
    z[6,7,3]  R2615     -5.6692969799041748e-01
    z[6,7,3]  R2616     -5.0393766164779663e-01
    z[6,7,3]  R2617     -7.1790444850921631e-01
    z[6,7,3]  R2618     -2.2077558934688568e-01
    z[6,7,3]  R2619     5.5741715431213379e-01
    z[6,7,3]  R2620     -4.4713595509529114e-01
    z[6,7,3]  R2621     -8.7472721934318542e-02
    z[6,7,3]  R2622     -1.6879495233297348e-02
    z[6,7,3]  R2623     -8.6856320500373840e-02
    z[6,7,3]  R2624     1.0131967812776566e-01
    z[6,7,3]  R2625     5.2337951958179474e-02
    z[6,7,3]  R2626     0.369122713804245
    z[6,7,3]  R2627     4.4091975688934326e-01
    z[6,7,3]  R2628     -1.9173561036586761e-01
    z[6,7,3]  R2629     -0.296233594417572
    z[6,7,3]  R2630     2.7814612258225679e-03
    z[6,7,3]  R2631     -1.3853618502616882e-01
    z[6,7,3]  R2632     1.1580002307891846e-01
    z[6,7,3]  R2633     4.3408408761024475e-01
    z[6,7,3]  R2634     3.2856735587120056e-01
    z[6,7,3]  R2635     3.6119055747985840e-01
    z[6,7,3]  R2636     2.2066141664981842e-01
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R2562     -1
    z[6,7,4]  R2563     1
    z[6,7,4]  R2568     -8.3284348249435425e-01
    z[6,7,4]  R2569     -6.0675281286239624e-01
    z[6,7,4]  R2570     1.7943026125431061e-01
    z[6,7,4]  R2571     2.1165351569652557e-01
    z[6,7,4]  R2572     5.3122036159038544e-02
    z[6,7,4]  R2573     -2.7994986623525620e-02
    z[6,7,4]  R2574     6.0909830033779144e-02
    z[6,7,4]  R2575     2.0996691659092903e-02
    z[6,7,4]  R2576     2.4418279528617859e-01
    z[6,7,4]  R2577     1.3282354176044464e-01
    z[6,7,4]  R2578     -5.0129914283752441e-01
    z[6,7,4]  R2579     -4.1763642430305481e-01
    z[6,7,4]  R2580     1.1798995733261108e-01
    z[6,7,4]  R2581     -4.7457154840230942e-02
    z[6,7,4]  R2582     2.4797822535037994e-01
    z[6,7,4]  R2583     -3.3877289388328791e-03
    z[6,7,4]  R2584     2.5931772589683533e-01
    z[6,7,4]  R2585     -2.3311829194426537e-02
    z[6,7,4]  R2586     3.4339752048254013e-02
    z[6,7,4]  R2587     -1.6188608109951019e-01
    z[6,7,4]  R2588     -5.6225913763046265e-01
    z[6,7,4]  R2589     -1.6311031579971313e-01
    z[6,7,4]  R2590     -1.6476285457611084e-01
    z[6,7,4]  R2591     7.8983316197991371e-03
    z[6,7,4]  R2592     0.668416440486908
    z[6,7,4]  R2593     6.7164522409439087e-01
    z[6,7,4]  R2594     -1.8812704086303711e-01
    z[6,7,4]  R2595     5.6265187263488770e-01
    z[6,7,4]  R2596     1.8205238878726959e-01
    z[6,7,4]  R2597     6.6807526350021362e-01
    z[6,7,4]  R2598     1.1278350651264191e-01
    z[6,7,4]  R2599     0.0964094027876854
    z[6,7,4]  R2600     -3.4093859791755676e-01
    z[6,7,4]  R2601     -2.3012995719909668e-01
    z[6,7,4]  R2602     5.2285179495811462e-02
    z[6,7,4]  R2603     -6.0546919703483582e-02
    z[6,7,4]  R2604     -1.0873212665319443e-01
    z[6,7,4]  R2605     2.2681656479835510e-01
    z[6,7,4]  R2606     2.5383159518241882e-01
    z[6,7,4]  R2607     -7.2736762464046478e-02
    z[6,7,4]  R2608     3.4567296504974365e-02
    z[6,7,4]  R2609     3.1856021285057068e-01
    z[6,7,4]  R2610     1.6540652513504028e-01
    z[6,7,4]  R2611     1.2471586465835571e-01
    z[6,7,4]  R2612     2.7911895513534546e-01
    z[6,7,4]  R2613     7.0714193582534790e-01
    z[6,7,4]  R2614     3.3558797091245651e-02
    z[6,7,4]  R2615     -1.0612443834543228e-01
    z[6,7,4]  R2616     3.7346008419990540e-01
    z[6,7,4]  R2617     2.9410016536712646e-01
    z[6,7,4]  R2618     4.2312777042388916e-01
    z[6,7,4]  R2619     2.4257218837738037e-01
    z[6,7,4]  R2620     3.4185758233070374e-01
    z[6,7,4]  R2621     1.1368550360202789e-01
    z[6,7,4]  R2622     -3.2543146610260010e-01
    z[6,7,4]  R2623     -5.5780386924743652e-01
    z[6,7,4]  R2624     6.2212649732828140e-02
    z[6,7,4]  R2625     2.2808945178985596e-01
    z[6,7,4]  R2626     -2.0683406293392181e-01
    z[6,7,4]  R2627     -2.8593108057975769e-01
    z[6,7,4]  R2628     2.2274306043982506e-02
    z[6,7,4]  R2629     1.4186917245388031e-01
    z[6,7,4]  R2630     2.1276238560676575e-01
    z[6,7,4]  R2631     -7.1415370702743530e-01
    z[6,7,4]  R2632     -4.6594056487083435e-01
    z[6,7,4]  R2633     1.4941351255401969e-03
    z[6,7,4]  R2634     -0.258316308259964
    z[6,7,4]  R2635     -6.5026766061782837e-01
    z[6,7,4]  R2636     -3.6814033985137939e-01
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R2564     -1
    z[6,7,5]  R2565     1
    z[6,7,5]  R2568     5.0700742751359940e-02
    z[6,7,5]  R2569     -3.4988054633140564e-01
    z[6,7,5]  R2570     1.7902784049510956e-02
    z[6,7,5]  R2571     8.9013829827308655e-02
    z[6,7,5]  R2572     -0.0491558238863945
    z[6,7,5]  R2573     -1.6641260683536530e-01
    z[6,7,5]  R2574     1.7898994684219360e-01
    z[6,7,5]  R2575     -2.2681452333927155e-02
    z[6,7,5]  R2576     -2.3320766165852547e-02
    z[6,7,5]  R2577     -9.5537595450878143e-02
    z[6,7,5]  R2578     2.3141373693943024e-01
    z[6,7,5]  R2579     2.0014445483684540e-01
    z[6,7,5]  R2580     -7.4222333729267120e-02
    z[6,7,5]  R2581     -2.4428756535053253e-01
    z[6,7,5]  R2582     3.1565821170806885e-01
    z[6,7,5]  R2583     -1.4559094607830048e-01
    z[6,7,5]  R2584     -2.0341484248638153e-01
    z[6,7,5]  R2585     -4.9272051453590393e-01
    z[6,7,5]  R2586     -1.6252711415290833e-01
    z[6,7,5]  R2587     -5.1126211881637573e-01
    z[6,7,5]  R2588     5.9974884986877441e-01
    z[6,7,5]  R2589     -2.2125542163848877e-01
    z[6,7,5]  R2590     0.613357663154602
    z[6,7,5]  R2591     -5.4441195726394653e-01
    z[6,7,5]  R2592     2.1309484541416168e-01
    z[6,7,5]  R2593     3.2975459098815918e-01
    z[6,7,5]  R2594     -6.3749986886978149e-01
    z[6,7,5]  R2595     1.3013105094432831e-01
    z[6,7,5]  R2596     2.2970614954829216e-02
    z[6,7,5]  R2597     2.0947758108377457e-02
    z[6,7,5]  R2598     -2.4292354285717010e-01
    z[6,7,5]  R2599     -8.5357002913951874e-02
    z[6,7,5]  R2600     1.1845561116933823e-01
    z[6,7,5]  R2601     -7.3580518364906311e-02
    z[6,7,5]  R2602     1.1728803068399429e-01
    z[6,7,5]  R2603     -1.0707467794418335e-01
    z[6,7,5]  R2604     1.5568982064723969e-01
    z[6,7,5]  R2605     7.0412173867225647e-02
    z[6,7,5]  R2606     -6.2022916972637177e-02
    z[6,7,5]  R2607     1.1527665704488754e-01
    z[6,7,5]  R2608     1.1195374280214310e-01
    z[6,7,5]  R2609     -0.0772845670580864
    z[6,7,5]  R2610     -4.8617967963218689e-01
    z[6,7,5]  R2611     0.549161970615387
    z[6,7,5]  R2612     6.5689951181411743e-01
    z[6,7,5]  R2613     2.4671067297458649e-01
    z[6,7,5]  R2614     7.8949761390686035e-01
    z[6,7,5]  R2615     -2.3483854532241821e-01
    z[6,7,5]  R2616     -5.4759597778320312e-01
    z[6,7,5]  R2617     1.0023871809244156e-01
    z[6,7,5]  R2618     -3.8677930831909180e-01
    z[6,7,5]  R2619     -4.4197618961334229e-02
    z[6,7,5]  R2620     1.2097232788801193e-01
    z[6,7,5]  R2621     0.698793888092041
    z[6,7,5]  R2622     3.5054400563240051e-01
    z[6,7,5]  R2623     5.4406970739364624e-01
    z[6,7,5]  R2624     1.7084047198295593e-01
    z[6,7,5]  R2625     -2.6089626550674438e-01
    z[6,7,5]  R2626     4.4805806875228882e-01
    z[6,7,5]  R2627     -2.2655102610588074e-01
    z[6,7,5]  R2628     1.8287371098995209e-01
    z[6,7,5]  R2629     2.0882815122604370e-01
    z[6,7,5]  R2630     2.4814268946647644e-01
    z[6,7,5]  R2631     1.8580763041973114e-01
    z[6,7,5]  R2632     3.4732723236083984e-01
    z[6,7,5]  R2633     0.00392861757427454
    z[6,7,5]  R2634     2.0078346133232117e-01
    z[6,7,5]  R2635     1.2518773972988129e-01
    z[6,7,5]  R2636     -3.2741820812225342e-01
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R2566     -1
    z[6,7,6]  R2567     1
    z[6,7,6]  R2568     -9.2715196311473846e-02
    z[6,7,6]  R2569     -3.5453815013170242e-02
    z[6,7,6]  R2570     -1.9415597617626190e-01
    z[6,7,6]  R2571     2.4558302760124207e-01
    z[6,7,6]  R2572     1.7966997623443604e-01
    z[6,7,6]  R2573     -1.3015929609537125e-02
    z[6,7,6]  R2574     -3.1739047169685364e-01
    z[6,7,6]  R2575     -4.3279886245727539e-02
    z[6,7,6]  R2576     -0.155271977186203
    z[6,7,6]  R2577     -2.4423734843730927e-01
    z[6,7,6]  R2578     4.0482887625694275e-01
    z[6,7,6]  R2579     -5.3904253244400024e-01
    z[6,7,6]  R2580     -1.0069804638624191e-01
    z[6,7,6]  R2581     9.3679733574390411e-02
    z[6,7,6]  R2582     2.6271790266036987e-02
    z[6,7,6]  R2583     0.301908403635025
    z[6,7,6]  R2584     -1.3290268369019032e-02
    z[6,7,6]  R2585     -3.4442096948623657e-01
    z[6,7,6]  R2586     -3.9069458842277527e-01
    z[6,7,6]  R2587     1.6704581677913666e-01
    z[6,7,6]  R2588     6.0678459703922272e-02
    z[6,7,6]  R2589     -4.3259564787149429e-02
    z[6,7,6]  R2590     4.1298347711563110e-01
    z[6,7,6]  R2591     -1.5963518619537354e-01
    z[6,7,6]  R2592     1.8098542094230652e-01
    z[6,7,6]  R2593     1.3291537761688232e-01
    z[6,7,6]  R2594     1.0008950531482697e-01
    z[6,7,6]  R2595     -2.1194621920585632e-02
    z[6,7,6]  R2596     3.6874154210090637e-01
    z[6,7,6]  R2597     -1.9895978271961212e-02
    z[6,7,6]  R2598     1.6439394652843475e-01
    z[6,7,6]  R2599     -3.1777936220169067e-01
    z[6,7,6]  R2600     6.2210746109485626e-02
    z[6,7,6]  R2601     3.3947363495826721e-01
    z[6,7,6]  R2602     -3.2035343348979950e-02
    z[6,7,6]  R2603     1.3655607402324677e-01
    z[6,7,6]  R2604     -2.8108641505241394e-01
    z[6,7,6]  R2605     -1.0922054201364517e-01
    z[6,7,6]  R2606     1.3716332614421844e-01
    z[6,7,6]  R2607     -0.678911030292511
    z[6,7,6]  R2608     1.1422696709632874e-01
    z[6,7,6]  R2609     2.4225464463233948e-01
    z[6,7,6]  R2610     -1.6875217854976654e-01
    z[6,7,6]  R2611     1.4720532298088074e-01
    z[6,7,6]  R2612     -3.1331443786621094e-01
    z[6,7,6]  R2613     -6.5803073346614838e-02
    z[6,7,6]  R2614     2.2200700640678406e-01
    z[6,7,6]  R2615     -2.5692167878150940e-01
    z[6,7,6]  R2616     8.5210867226123810e-02
    z[6,7,6]  R2617     1.9927003979682922e-01
    z[6,7,6]  R2618     2.0807354152202606e-01
    z[6,7,6]  R2619     2.1896330639719963e-02
    z[6,7,6]  R2620     3.7601059675216675e-01
    z[6,7,6]  R2621     1.6459560021758080e-02
    z[6,7,6]  R2622     -2.3615995049476624e-01
    z[6,7,6]  R2623     -1.0659363120794296e-01
    z[6,7,6]  R2624     0.335407018661499
    z[6,7,6]  R2625     -6.6985177993774414e-01
    z[6,7,6]  R2626     -1.8572930991649628e-01
    z[6,7,6]  R2627     -2.6486387848854065e-01
    z[6,7,6]  R2628     -2.6600521802902222e-01
    z[6,7,6]  R2629     5.1743984222412109e-01
    z[6,7,6]  R2630     4.7477385401725769e-01
    z[6,7,6]  R2631     -2.8453102707862854e-01
    z[6,7,6]  R2632     -1.1456419527530670e-01
    z[6,7,6]  R2633     3.7997469305992126e-02
    z[6,7,6]  R2634     -1.3189387321472168e-01
    z[6,7,6]  R2635     4.3488770723342896e-01
    z[6,7,6]  R2636     2.3143112659454346e-01
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R2637     -1
    z[7,6,0]  R2638     1
    z[7,6,0]  R2651     -3.0372151732444763e-01
    z[7,6,0]  R2652     -3.0008256435394287e-01
    z[7,6,0]  R2653     -1.9094075262546539e-01
    z[7,6,0]  R2654     -4.8980396986007690e-01
    z[7,6,0]  R2655     5.5676519870758057e-01
    z[7,6,0]  R2656     5.4785132408142090e-01
    z[7,6,0]  R2657     4.7637981176376343e-01
    z[7,6,0]  R2658     4.1669556498527527e-01
    z[7,6,0]  R2659     0.401156485080719
    z[7,6,0]  R2660     -5.4611825942993164e-01
    z[7,6,0]  R2661     -7.9487943649291992e-01
    z[7,6,0]  R2662     -8.1363278627395630e-01
    z[7,6,0]  R2663     -6.1245149374008179e-01
    z[7,6,0]  R2664     -0.700247585773468
    z[7,6,0]  R2665     3.4501597285270691e-01
    z[7,6,0]  R2666     -0.606789767742157
    z[7,6,0]  R2667     0.114809550344944
    z[7,6,0]  R2668     1.8719317018985748e-01
    z[7,6,0]  R2669     -4.5119252800941467e-01
    z[7,6,0]  R2670     -3.0796242877840996e-02
    z[7,6,0]  R2671     -7.3783248662948608e-01
    z[7,6,0]  R2672     -4.0503782033920288e-01
    z[7,6,0]  R2673     0.321079283952713
    z[7,6,0]  R2674     4.3968539685010910e-02
    z[7,6,0]  R2675     -7.1097129583358765e-01
    z[7,6,0]  R2676     -5.9146308898925781e-01
    z[7,6,0]  R2677     1.9861114025115967e-01
    z[7,6,0]  R2678     5.8389854431152344e-01
    z[7,6,0]  R2679     2.4765689671039581e-01
    z[7,6,0]  R2680     3.3355557918548584e-01
    z[7,6,0]  R2681     2.8576344251632690e-01
    z[7,6,0]  R2682     -5.9667402505874634e-01
    z[7,6,0]  R2683     3.8589265942573547e-01
    z[7,6,0]  R2684     -5.8138000965118408e-01
    z[7,6,0]  R2685     1.3199988007545471e-01
    z[7,6,0]  R2686     8.4620010852813721e-01
    z[7,6,0]  R2687     8.3288741111755371e-01
    z[7,6,0]  R2688     3.1440284848213196e-01
    z[7,6,0]  R2689     -1.6727916896343231e-01
    z[7,6,0]  R2690     -5.2107390947639942e-03
    z[7,6,0]  R2691     -1.9177805632352829e-02
    z[7,6,0]  R2692     5.3346121311187744e-01
    z[7,6,0]  R2693     4.2087772488594055e-01
    z[7,6,0]  R2694     4.9826869368553162e-01
    z[7,6,0]  R2695     5.3279006481170654e-01
    z[7,6,0]  R2696     6.5640980005264282e-01
    z[7,6,0]  R2697     3.3792454004287720e-01
    z[7,6,0]  R2698     5.7616049051284790e-01
    z[7,6,0]  R2699     5.8036917448043823e-01
    z[7,6,0]  R2700     -3.4743244759738445e-03
    z[7,6,0]  R2701     -1.2308333814144135e-01
    z[7,6,0]  R2702     -3.7155374884605408e-01
    z[7,6,0]  R2703     -5.4898804426193237e-01
    z[7,6,0]  R2704     -2.5332772731781006e-01
    z[7,6,0]  R2705     -6.1840850114822388e-01
    z[7,6,0]  R2706     -6.1318671703338623e-01
    z[7,6,0]  R2707     -3.2655423879623413e-01
    z[7,6,0]  R2708     -1.0422305762767792e-01
    z[7,6,0]  R2709     -6.5365648269653320e-01
    z[7,6,0]  R2710     -3.8282939791679382e-01
    z[7,6,0]  R2711     -1.6345612704753876e-01
    z[7,6,0]  R2712     3.2546854019165039e-01
    z[7,6,0]  R2713     -5.4201591014862061e-01
    z[7,6,0]  R2714     -2.6580983400344849e-01
    z[7,6,0]  R2715     -2.0024487376213074e-01
    z[7,6,0]  R2716     -5.1235926151275635e-01
    z[7,6,0]  R2717     -6.5226331353187561e-02
    z[7,6,0]  R2718     -1.7295217514038086e-01
    z[7,6,0]  R2719     -3.3874583244323730e-01
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R2639     -1
    z[7,6,1]  R2640     1
    z[7,6,1]  R2651     5.9839583933353424e-02
    z[7,6,1]  R2652     -1.0776294022798538e-01
    z[7,6,1]  R2653     6.7972518503665924e-02
    z[7,6,1]  R2654     1.4336401224136353e-01
    z[7,6,1]  R2655     -5.6059449911117554e-01
    z[7,6,1]  R2656     1.1334766447544098e-01
    z[7,6,1]  R2657     -3.8519391417503357e-01
    z[7,6,1]  R2658     -4.1615876555442810e-01
    z[7,6,1]  R2659     0.0632009282708168
    z[7,6,1]  R2660     -2.7729475498199463e-01
    z[7,6,1]  R2661     2.7077552676200867e-01
    z[7,6,1]  R2662     6.6772729158401489e-02
    z[7,6,1]  R2663     2.6250171661376953e-01
    z[7,6,1]  R2664     -1.0952156037092209e-01
    z[7,6,1]  R2665     -3.4136629104614258e-01
    z[7,6,1]  R2666     1.3359403237700462e-02
    z[7,6,1]  R2667     -1.4204810559749603e-01
    z[7,6,1]  R2668     7.0631068944931030e-01
    z[7,6,1]  R2669     2.6673880219459534e-01
    z[7,6,1]  R2670     5.8728420734405518e-01
    z[7,6,1]  R2671     -1.0162436962127686e-01
    z[7,6,1]  R2672     1.6930936276912689e-01
    z[7,6,1]  R2673     -2.3312389850616455e-01
    z[7,6,1]  R2674     -3.2947105169296265e-01
    z[7,6,1]  R2675     4.0027368068695068e-01
    z[7,6,1]  R2676     -6.2102526426315308e-02
    z[7,6,1]  R2677     8.3066987991333008e-01
    z[7,6,1]  R2678     -1.1053048074245453e-01
    z[7,6,1]  R2679     6.7984503507614136e-01
    z[7,6,1]  R2680     6.7457187175750732e-01
    z[7,6,1]  R2681     -1.7039711773395538e-01
    z[7,6,1]  R2682     -1.3729162514209747e-01
    z[7,6,1]  R2683     2.9298362787812948e-03
    z[7,6,1]  R2684     8.2027778029441833e-02
    z[7,6,1]  R2685     7.8628820180892944e-01
    z[7,6,1]  R2686     0.228877454996109
    z[7,6,1]  R2687     1.7244207859039307e-01
    z[7,6,1]  R2688     3.3402338624000549e-01
    z[7,6,1]  R2689     -0.778550386428833
    z[7,6,1]  R2690     -0.463029146194458
    z[7,6,1]  R2691     4.5317122340202332e-01
    z[7,6,1]  R2692     -3.9997357130050659e-01
    z[7,6,1]  R2693     1.8852078914642334e-01
    z[7,6,1]  R2694     -3.9411702752113342e-01
    z[7,6,1]  R2695     2.3744247853755951e-01
    z[7,6,1]  R2696     2.1724076569080353e-01
    z[7,6,1]  R2697     -5.6819128990173340e-01
    z[7,6,1]  R2698     2.7435201406478882e-01
    z[7,6,1]  R2699     1.6648538410663605e-01
    z[7,6,1]  R2700     -6.7764058709144592e-02
    z[7,6,1]  R2701     8.5038393735885620e-02
    z[7,6,1]  R2702     -8.6744648218154907e-01
    z[7,6,1]  R2703     -7.4145448207855225e-01
    z[7,6,1]  R2704     -8.1563413143157959e-01
    z[7,6,1]  R2705     -5.2506881952285767e-01
    z[7,6,1]  R2706     -0.619130551815033
    z[7,6,1]  R2707     -6.3107943534851074e-01
    z[7,6,1]  R2708     -6.8970000743865967e-01
    z[7,6,1]  R2709     -4.0858045220375061e-01
    z[7,6,1]  R2710     2.7977058291435242e-01
    z[7,6,1]  R2711     -3.9654040336608887e-01
    z[7,6,1]  R2712     -5.4879948496818542e-02
    z[7,6,1]  R2713     -3.6780336499214172e-01
    z[7,6,1]  R2714     5.1064151525497437e-01
    z[7,6,1]  R2715     0.16551573574543
    z[7,6,1]  R2716     1.3627509772777557e-01
    z[7,6,1]  R2717     7.3188805580139160e-01
    z[7,6,1]  R2718     6.3836479187011719e-01
    z[7,6,1]  R2719     -9.5175787806510925e-02
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R2641     -1
    z[7,6,2]  R2642     1
    z[7,6,2]  R2651     8.8125967979431152e-01
    z[7,6,2]  R2652     8.7643355131149292e-01
    z[7,6,2]  R2653     8.7768596410751343e-01
    z[7,6,2]  R2654     7.1278828382492065e-01
    z[7,6,2]  R2655     5.1686805486679077e-01
    z[7,6,2]  R2656     7.8773558139801025e-01
    z[7,6,2]  R2657     5.2271687984466553e-01
    z[7,6,2]  R2658     5.4136687517166138e-01
    z[7,6,2]  R2659     8.6033004522323608e-01
    z[7,6,2]  R2660     3.5049009323120117e-01
    z[7,6,2]  R2661     -1.5173679590225220e-01
    z[7,6,2]  R2662     -1.2127404659986496e-01
    z[7,6,2]  R2663     5.2269272506237030e-02
    z[7,6,2]  R2664     0.067268505692482
    z[7,6,2]  R2665     3.1443178653717041e-01
    z[7,6,2]  R2666     -6.9947414100170135e-02
    z[7,6,2]  R2667     4.9026903510093689e-01
    z[7,6,2]  R2668     -1.1069977283477783e-01
    z[7,6,2]  R2669     -1.5725065767765045e-01
    z[7,6,2]  R2670     -5.0107151269912720e-02
    z[7,6,2]  R2671     1.5685613453388214e-01
    z[7,6,2]  R2672     6.5976572036743164e-01
    z[7,6,2]  R2673     6.0806733369827271e-01
    z[7,6,2]  R2674     6.1673003435134888e-01
    z[7,6,2]  R2675     -2.2239057719707489e-01
    z[7,6,2]  R2676     1.4230807125568390e-01
    z[7,6,2]  R2677     3.3870470523834229e-01
    z[7,6,2]  R2678     0.274432510137558
    z[7,6,2]  R2679     2.4938605725765228e-01
    z[7,6,2]  R2680     -1.8986427783966064e-01
    z[7,6,2]  R2681     8.6477959156036377e-01
    z[7,6,2]  R2682     4.5375841856002808e-01
    z[7,6,2]  R2683     7.2029000520706177e-01
    z[7,6,2]  R2684     1.0285206884145737e-01
    z[7,6,2]  R2685     7.4434056878089905e-03
    z[7,6,2]  R2686     -2.0413251221179962e-01
    z[7,6,2]  R2687     -2.1016301214694977e-01
    z[7,6,2]  R2688     -1.7740696668624878e-01
    z[7,6,2]  R2689     -1.4455151557922363e-01
    z[7,6,2]  R2690     2.5370424985885620e-01
    z[7,6,2]  R2691     4.7708079218864441e-01
    z[7,6,2]  R2692     4.5294904708862305e-01
    z[7,6,2]  R2693     7.5022113323211670e-01
    z[7,6,2]  R2694     5.1763975620269775e-01
    z[7,6,2]  R2695     7.3303419351577759e-01
    z[7,6,2]  R2696     0.573716402053833
    z[7,6,2]  R2697     6.5565681457519531e-01
    z[7,6,2]  R2698     7.1206021308898926e-01
    z[7,6,2]  R2699     4.1576743125915527e-01
    z[7,6,2]  R2700     -0.636843204498291
    z[7,6,2]  R2701     -3.6151629686355591e-01
    z[7,6,2]  R2702     -1.4550860226154327e-01
    z[7,6,2]  R2703     -1.5195912122726440e-01
    z[7,6,2]  R2704     -2.5232285261154175e-01
    z[7,6,2]  R2705     -3.3051258325576782e-01
    z[7,6,2]  R2706     -3.2100066542625427e-01
    z[7,6,2]  R2707     -3.0456984043121338e-01
    z[7,6,2]  R2708     -5.4235816001892090e-01
    z[7,6,2]  R2709     -2.3770385980606079e-01
    z[7,6,2]  R2710     3.0719444155693054e-01
    z[7,6,2]  R2711     2.6448589563369751e-01
    z[7,6,2]  R2712     4.0804558992385864e-01
    z[7,6,2]  R2713     -4.6224242448806763e-01
    z[7,6,2]  R2714     3.7779358029365540e-01
    z[7,6,2]  R2715     2.1731008589267731e-01
    z[7,6,2]  R2716     -2.8794929385185242e-01
    z[7,6,2]  R2717     -3.4672487527132034e-02
    z[7,6,2]  R2718     2.6825872063636780e-01
    z[7,6,2]  R2719     6.0277175903320312e-01
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R2643     -1
    z[7,6,3]  R2644     1
    z[7,6,3]  R2651     -1.6969552636146545e-01
    z[7,6,3]  R2652     -1.1241710186004639e-01
    z[7,6,3]  R2653     -2.3333995044231415e-01
    z[7,6,3]  R2654     -2.4053138494491577e-01
    z[7,6,3]  R2655     -3.0179014801979065e-01
    z[7,6,3]  R2656     -0.180845707654953
    z[7,6,3]  R2657     -4.8619282245635986e-01
    z[7,6,3]  R2658     -5.4015350341796875e-01
    z[7,6,3]  R2659     8.8432110846042633e-02
    z[7,6,3]  R2660     -1.5006552636623383e-01
    z[7,6,3]  R2661     4.9502205848693848e-01
    z[7,6,3]  R2662     3.9076185226440430e-01
    z[7,6,3]  R2663     0.510936975479126
    z[7,6,3]  R2664     3.9284959435462952e-01
    z[7,6,3]  R2665     2.4078071117401123e-01
    z[7,6,3]  R2666     -2.4797025322914124e-01
    z[7,6,3]  R2667     2.2925460338592529e-01
    z[7,6,3]  R2668     -5.6692969799041748e-01
    z[7,6,3]  R2669     -5.0393766164779663e-01
    z[7,6,3]  R2670     -7.1790444850921631e-01
    z[7,6,3]  R2671     -2.2077558934688568e-01
    z[7,6,3]  R2672     5.5741715431213379e-01
    z[7,6,3]  R2673     -4.4713595509529114e-01
    z[7,6,3]  R2674     -8.7472721934318542e-02
    z[7,6,3]  R2675     -1.6879495233297348e-02
    z[7,6,3]  R2676     -8.6856320500373840e-02
    z[7,6,3]  R2677     1.0131967812776566e-01
    z[7,6,3]  R2678     5.2337951958179474e-02
    z[7,6,3]  R2679     0.369122713804245
    z[7,6,3]  R2680     4.4091975688934326e-01
    z[7,6,3]  R2681     -1.9173561036586761e-01
    z[7,6,3]  R2682     -0.296233594417572
    z[7,6,3]  R2683     2.7814612258225679e-03
    z[7,6,3]  R2684     -1.3853618502616882e-01
    z[7,6,3]  R2685     1.1580002307891846e-01
    z[7,6,3]  R2686     4.3408408761024475e-01
    z[7,6,3]  R2687     3.2856735587120056e-01
    z[7,6,3]  R2688     3.6119055747985840e-01
    z[7,6,3]  R2689     2.2066141664981842e-01
    z[7,6,3]  R2690     -1.2812557816505432e-01
    z[7,6,3]  R2691     2.7356836199760437e-01
    z[7,6,3]  R2692     -5.2921187877655029e-01
    z[7,6,3]  R2693     -3.3385384082794189e-01
    z[7,6,3]  R2694     -5.3937900066375732e-01
    z[7,6,3]  R2695     -3.0621933937072754e-01
    z[7,6,3]  R2696     -2.3727174103260040e-01
    z[7,6,3]  R2697     -3.6090376973152161e-01
    z[7,6,3]  R2698     -0.038233682513237
    z[7,6,3]  R2699     -6.1332726478576660e-01
    z[7,6,3]  R2700     3.4797564148902893e-01
    z[7,6,3]  R2701     5.8470505475997925e-01
    z[7,6,3]  R2702     2.4236537516117096e-01
    z[7,6,3]  R2703     2.3465169966220856e-01
    z[7,6,3]  R2704     2.1231047809123993e-01
    z[7,6,3]  R2705     -0.346811443567276
    z[7,6,3]  R2706     -1.6981753706932068e-01
    z[7,6,3]  R2707     -2.0098647475242615e-01
    z[7,6,3]  R2708     -1.9764246046543121e-01
    z[7,6,3]  R2709     -1.8382544815540314e-01
    z[7,6,3]  R2710     3.5857412964105606e-02
    z[7,6,3]  R2711     0.81771320104599
    z[7,6,3]  R2712     3.8813319802284241e-01
    z[7,6,3]  R2713     -1.8799242377281189e-01
    z[7,6,3]  R2714     -3.0278982594609261e-02
    z[7,6,3]  R2715     -5.5477118492126465e-01
    z[7,6,3]  R2716     -4.2916965484619141e-01
    z[7,6,3]  R2717     -3.5344421863555908e-01
    z[7,6,3]  R2718     -5.6654590368270874e-01
    z[7,6,3]  R2719     -2.5631973147392273e-01
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R2645     -1
    z[7,6,4]  R2646     1
    z[7,6,4]  R2651     1.1278350651264191e-01
    z[7,6,4]  R2652     0.0964094027876854
    z[7,6,4]  R2653     -3.4093859791755676e-01
    z[7,6,4]  R2654     -2.3012995719909668e-01
    z[7,6,4]  R2655     5.2285179495811462e-02
    z[7,6,4]  R2656     -6.0546919703483582e-02
    z[7,6,4]  R2657     -1.0873212665319443e-01
    z[7,6,4]  R2658     2.2681656479835510e-01
    z[7,6,4]  R2659     2.5383159518241882e-01
    z[7,6,4]  R2660     -7.2736762464046478e-02
    z[7,6,4]  R2661     3.4567296504974365e-02
    z[7,6,4]  R2662     3.1856021285057068e-01
    z[7,6,4]  R2663     1.6540652513504028e-01
    z[7,6,4]  R2664     1.2471586465835571e-01
    z[7,6,4]  R2665     2.7911895513534546e-01
    z[7,6,4]  R2666     7.0714193582534790e-01
    z[7,6,4]  R2667     3.3558797091245651e-02
    z[7,6,4]  R2668     -1.0612443834543228e-01
    z[7,6,4]  R2669     3.7346008419990540e-01
    z[7,6,4]  R2670     2.9410016536712646e-01
    z[7,6,4]  R2671     4.2312777042388916e-01
    z[7,6,4]  R2672     2.4257218837738037e-01
    z[7,6,4]  R2673     3.4185758233070374e-01
    z[7,6,4]  R2674     1.1368550360202789e-01
    z[7,6,4]  R2675     -3.2543146610260010e-01
    z[7,6,4]  R2676     -5.5780386924743652e-01
    z[7,6,4]  R2677     6.2212649732828140e-02
    z[7,6,4]  R2678     2.2808945178985596e-01
    z[7,6,4]  R2679     -2.0683406293392181e-01
    z[7,6,4]  R2680     -2.8593108057975769e-01
    z[7,6,4]  R2681     2.2274306043982506e-02
    z[7,6,4]  R2682     1.4186917245388031e-01
    z[7,6,4]  R2683     2.1276238560676575e-01
    z[7,6,4]  R2684     -7.1415370702743530e-01
    z[7,6,4]  R2685     -4.6594056487083435e-01
    z[7,6,4]  R2686     1.4941351255401969e-03
    z[7,6,4]  R2687     -0.258316308259964
    z[7,6,4]  R2688     -6.5026766061782837e-01
    z[7,6,4]  R2689     -3.6814033985137939e-01
    z[7,6,4]  R2690     -8.3284348249435425e-01
    z[7,6,4]  R2691     -6.0675281286239624e-01
    z[7,6,4]  R2692     1.7943026125431061e-01
    z[7,6,4]  R2693     2.1165351569652557e-01
    z[7,6,4]  R2694     5.3122036159038544e-02
    z[7,6,4]  R2695     -2.7994986623525620e-02
    z[7,6,4]  R2696     6.0909830033779144e-02
    z[7,6,4]  R2697     2.0996691659092903e-02
    z[7,6,4]  R2698     2.4418279528617859e-01
    z[7,6,4]  R2699     1.3282354176044464e-01
    z[7,6,4]  R2700     -5.0129914283752441e-01
    z[7,6,4]  R2701     -4.1763642430305481e-01
    z[7,6,4]  R2702     1.1798995733261108e-01
    z[7,6,4]  R2703     -4.7457154840230942e-02
    z[7,6,4]  R2704     2.4797822535037994e-01
    z[7,6,4]  R2705     -3.3877289388328791e-03
    z[7,6,4]  R2706     2.5931772589683533e-01
    z[7,6,4]  R2707     -2.3311829194426537e-02
    z[7,6,4]  R2708     3.4339752048254013e-02
    z[7,6,4]  R2709     -1.6188608109951019e-01
    z[7,6,4]  R2710     -5.6225913763046265e-01
    z[7,6,4]  R2711     -1.6311031579971313e-01
    z[7,6,4]  R2712     -1.6476285457611084e-01
    z[7,6,4]  R2713     7.8983316197991371e-03
    z[7,6,4]  R2714     0.668416440486908
    z[7,6,4]  R2715     6.7164522409439087e-01
    z[7,6,4]  R2716     -1.8812704086303711e-01
    z[7,6,4]  R2717     5.6265187263488770e-01
    z[7,6,4]  R2718     1.8205238878726959e-01
    z[7,6,4]  R2719     6.6807526350021362e-01
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R2647     -1
    z[7,6,5]  R2648     1
    z[7,6,5]  R2651     -2.4292354285717010e-01
    z[7,6,5]  R2652     -8.5357002913951874e-02
    z[7,6,5]  R2653     1.1845561116933823e-01
    z[7,6,5]  R2654     -7.3580518364906311e-02
    z[7,6,5]  R2655     1.1728803068399429e-01
    z[7,6,5]  R2656     -1.0707467794418335e-01
    z[7,6,5]  R2657     1.5568982064723969e-01
    z[7,6,5]  R2658     7.0412173867225647e-02
    z[7,6,5]  R2659     -6.2022916972637177e-02
    z[7,6,5]  R2660     1.1527665704488754e-01
    z[7,6,5]  R2661     1.1195374280214310e-01
    z[7,6,5]  R2662     -0.0772845670580864
    z[7,6,5]  R2663     -4.8617967963218689e-01
    z[7,6,5]  R2664     0.549161970615387
    z[7,6,5]  R2665     6.5689951181411743e-01
    z[7,6,5]  R2666     2.4671067297458649e-01
    z[7,6,5]  R2667     7.8949761390686035e-01
    z[7,6,5]  R2668     -2.3483854532241821e-01
    z[7,6,5]  R2669     -5.4759597778320312e-01
    z[7,6,5]  R2670     1.0023871809244156e-01
    z[7,6,5]  R2671     -3.8677930831909180e-01
    z[7,6,5]  R2672     -4.4197618961334229e-02
    z[7,6,5]  R2673     1.2097232788801193e-01
    z[7,6,5]  R2674     0.698793888092041
    z[7,6,5]  R2675     3.5054400563240051e-01
    z[7,6,5]  R2676     5.4406970739364624e-01
    z[7,6,5]  R2677     1.7084047198295593e-01
    z[7,6,5]  R2678     -2.6089626550674438e-01
    z[7,6,5]  R2679     4.4805806875228882e-01
    z[7,6,5]  R2680     -2.2655102610588074e-01
    z[7,6,5]  R2681     1.8287371098995209e-01
    z[7,6,5]  R2682     2.0882815122604370e-01
    z[7,6,5]  R2683     2.4814268946647644e-01
    z[7,6,5]  R2684     1.8580763041973114e-01
    z[7,6,5]  R2685     3.4732723236083984e-01
    z[7,6,5]  R2686     0.00392861757427454
    z[7,6,5]  R2687     2.0078346133232117e-01
    z[7,6,5]  R2688     1.2518773972988129e-01
    z[7,6,5]  R2689     -3.2741820812225342e-01
    z[7,6,5]  R2690     5.0700742751359940e-02
    z[7,6,5]  R2691     -3.4988054633140564e-01
    z[7,6,5]  R2692     1.7902784049510956e-02
    z[7,6,5]  R2693     8.9013829827308655e-02
    z[7,6,5]  R2694     -0.0491558238863945
    z[7,6,5]  R2695     -1.6641260683536530e-01
    z[7,6,5]  R2696     1.7898994684219360e-01
    z[7,6,5]  R2697     -2.2681452333927155e-02
    z[7,6,5]  R2698     -2.3320766165852547e-02
    z[7,6,5]  R2699     -9.5537595450878143e-02
    z[7,6,5]  R2700     2.3141373693943024e-01
    z[7,6,5]  R2701     2.0014445483684540e-01
    z[7,6,5]  R2702     -7.4222333729267120e-02
    z[7,6,5]  R2703     -2.4428756535053253e-01
    z[7,6,5]  R2704     3.1565821170806885e-01
    z[7,6,5]  R2705     -1.4559094607830048e-01
    z[7,6,5]  R2706     -2.0341484248638153e-01
    z[7,6,5]  R2707     -4.9272051453590393e-01
    z[7,6,5]  R2708     -1.6252711415290833e-01
    z[7,6,5]  R2709     -5.1126211881637573e-01
    z[7,6,5]  R2710     5.9974884986877441e-01
    z[7,6,5]  R2711     -2.2125542163848877e-01
    z[7,6,5]  R2712     0.613357663154602
    z[7,6,5]  R2713     -5.4441195726394653e-01
    z[7,6,5]  R2714     2.1309484541416168e-01
    z[7,6,5]  R2715     3.2975459098815918e-01
    z[7,6,5]  R2716     -6.3749986886978149e-01
    z[7,6,5]  R2717     1.3013105094432831e-01
    z[7,6,5]  R2718     2.2970614954829216e-02
    z[7,6,5]  R2719     2.0947758108377457e-02
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R2649     -1
    z[7,6,6]  R2650     1
    z[7,6,6]  R2651     1.6439394652843475e-01
    z[7,6,6]  R2652     -3.1777936220169067e-01
    z[7,6,6]  R2653     6.2210746109485626e-02
    z[7,6,6]  R2654     3.3947363495826721e-01
    z[7,6,6]  R2655     -3.2035343348979950e-02
    z[7,6,6]  R2656     1.3655607402324677e-01
    z[7,6,6]  R2657     -2.8108641505241394e-01
    z[7,6,6]  R2658     -1.0922054201364517e-01
    z[7,6,6]  R2659     1.3716332614421844e-01
    z[7,6,6]  R2660     -0.678911030292511
    z[7,6,6]  R2661     1.1422696709632874e-01
    z[7,6,6]  R2662     2.4225464463233948e-01
    z[7,6,6]  R2663     -1.6875217854976654e-01
    z[7,6,6]  R2664     1.4720532298088074e-01
    z[7,6,6]  R2665     -3.1331443786621094e-01
    z[7,6,6]  R2666     -6.5803073346614838e-02
    z[7,6,6]  R2667     2.2200700640678406e-01
    z[7,6,6]  R2668     -2.5692167878150940e-01
    z[7,6,6]  R2669     8.5210867226123810e-02
    z[7,6,6]  R2670     1.9927003979682922e-01
    z[7,6,6]  R2671     2.0807354152202606e-01
    z[7,6,6]  R2672     2.1896330639719963e-02
    z[7,6,6]  R2673     3.7601059675216675e-01
    z[7,6,6]  R2674     1.6459560021758080e-02
    z[7,6,6]  R2675     -2.3615995049476624e-01
    z[7,6,6]  R2676     -1.0659363120794296e-01
    z[7,6,6]  R2677     0.335407018661499
    z[7,6,6]  R2678     -6.6985177993774414e-01
    z[7,6,6]  R2679     -1.8572930991649628e-01
    z[7,6,6]  R2680     -2.6486387848854065e-01
    z[7,6,6]  R2681     -2.6600521802902222e-01
    z[7,6,6]  R2682     5.1743984222412109e-01
    z[7,6,6]  R2683     4.7477385401725769e-01
    z[7,6,6]  R2684     -2.8453102707862854e-01
    z[7,6,6]  R2685     -1.1456419527530670e-01
    z[7,6,6]  R2686     3.7997469305992126e-02
    z[7,6,6]  R2687     -1.3189387321472168e-01
    z[7,6,6]  R2688     4.3488770723342896e-01
    z[7,6,6]  R2689     2.3143112659454346e-01
    z[7,6,6]  R2690     -9.2715196311473846e-02
    z[7,6,6]  R2691     -3.5453815013170242e-02
    z[7,6,6]  R2692     -1.9415597617626190e-01
    z[7,6,6]  R2693     2.4558302760124207e-01
    z[7,6,6]  R2694     1.7966997623443604e-01
    z[7,6,6]  R2695     -1.3015929609537125e-02
    z[7,6,6]  R2696     -3.1739047169685364e-01
    z[7,6,6]  R2697     -4.3279886245727539e-02
    z[7,6,6]  R2698     -0.155271977186203
    z[7,6,6]  R2699     -2.4423734843730927e-01
    z[7,6,6]  R2700     4.0482887625694275e-01
    z[7,6,6]  R2701     -5.3904253244400024e-01
    z[7,6,6]  R2702     -1.0069804638624191e-01
    z[7,6,6]  R2703     9.3679733574390411e-02
    z[7,6,6]  R2704     2.6271790266036987e-02
    z[7,6,6]  R2705     0.301908403635025
    z[7,6,6]  R2706     -1.3290268369019032e-02
    z[7,6,6]  R2707     -3.4442096948623657e-01
    z[7,6,6]  R2708     -3.9069458842277527e-01
    z[7,6,6]  R2709     1.6704581677913666e-01
    z[7,6,6]  R2710     6.0678459703922272e-02
    z[7,6,6]  R2711     -4.3259564787149429e-02
    z[7,6,6]  R2712     4.1298347711563110e-01
    z[7,6,6]  R2713     -1.5963518619537354e-01
    z[7,6,6]  R2714     1.8098542094230652e-01
    z[7,6,6]  R2715     1.3291537761688232e-01
    z[7,6,6]  R2716     1.0008950531482697e-01
    z[7,6,6]  R2717     -2.1194621920585632e-02
    z[7,6,6]  R2718     3.6874154210090637e-01
    z[7,6,6]  R2719     -1.9895978271961212e-02
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R72       1
    RHS1      R73       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[0,5]
 BV BND1      phi[5,0]
 BV BND1      phi[8,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,4]
 BV BND1      phi[4,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[3,6]
 BV BND1      phi[6,3]
 BV BND1      phi[3,7]
 BV BND1      phi[7,3]
 BV BND1      phi[3,9]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[8,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[7,9]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[0,5,0]
 FR BND1      z[0,5,1]
 FR BND1      z[0,5,2]
 FR BND1      z[0,5,3]
 FR BND1      z[0,5,4]
 FR BND1      z[0,5,5]
 FR BND1      z[0,5,6]
 FR BND1      z[5,0,0]
 FR BND1      z[5,0,1]
 FR BND1      z[5,0,2]
 FR BND1      z[5,0,3]
 FR BND1      z[5,0,4]
 FR BND1      z[5,0,5]
 FR BND1      z[5,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,4,0]
 FR BND1      z[1,4,1]
 FR BND1      z[1,4,2]
 FR BND1      z[1,4,3]
 FR BND1      z[1,4,4]
 FR BND1      z[1,4,5]
 FR BND1      z[1,4,6]
 FR BND1      z[4,1,0]
 FR BND1      z[4,1,1]
 FR BND1      z[4,1,2]
 FR BND1      z[4,1,3]
 FR BND1      z[4,1,4]
 FR BND1      z[4,1,5]
 FR BND1      z[4,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[3,6,0]
 FR BND1      z[3,6,1]
 FR BND1      z[3,6,2]
 FR BND1      z[3,6,3]
 FR BND1      z[3,6,4]
 FR BND1      z[3,6,5]
 FR BND1      z[3,6,6]
 FR BND1      z[6,3,0]
 FR BND1      z[6,3,1]
 FR BND1      z[6,3,2]
 FR BND1      z[6,3,3]
 FR BND1      z[6,3,4]
 FR BND1      z[6,3,5]
 FR BND1      z[6,3,6]
 FR BND1      z[3,7,0]
 FR BND1      z[3,7,1]
 FR BND1      z[3,7,2]
 FR BND1      z[3,7,3]
 FR BND1      z[3,7,4]
 FR BND1      z[3,7,5]
 FR BND1      z[3,7,6]
 FR BND1      z[7,3,0]
 FR BND1      z[7,3,1]
 FR BND1      z[7,3,2]
 FR BND1      z[7,3,3]
 FR BND1      z[7,3,4]
 FR BND1      z[7,3,5]
 FR BND1      z[7,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
ENDATA
