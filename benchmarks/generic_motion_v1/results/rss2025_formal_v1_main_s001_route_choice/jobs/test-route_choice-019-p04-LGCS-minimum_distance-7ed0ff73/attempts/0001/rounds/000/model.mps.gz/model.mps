NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 E  R64     
 L  R65     
 L  R66     
 L  R67     
 L  R68     
 L  R69     
 L  R70     
 L  R71     
 L  R72     
 L  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R65       -3.0999999046325684e+00
    phi[0,1]  R66       -3.0999999046325684e+00
    phi[0,1]  R67       -2.2400000095367432e+00
    phi[0,1]  R68       -2.2400000095367432e+00
    phi[0,1]  R69       -3.0999999046325684e+00
    phi[0,1]  R70       -3.0999999046325684e+00
    phi[0,1]  R71       -2.5699999332427979e+00
    phi[0,1]  R72       -2.5699999332427979e+00
    phi[0,1]  R73       -3.0999999046325684e+00
    phi[0,1]  R74       -3.0999999046325684e+00
    phi[0,1]  R75       -2.0899999141693115e+00
    phi[0,1]  R76       -2.0899999141693115e+00
    phi[0,1]  R77       -3.0999999046325684e+00
    phi[0,1]  R78       -3.0999999046325684e+00
    phi[0,1]  R79       2.4470300674438477e+00
    phi[0,1]  R80       1.8479690551757812e+00
    phi[0,1]  R81       2.4377064704895020e+00
    phi[0,1]  R82       7.4503618478775024e-01
    phi[0,1]  R83       1.3827391862869263e+00
    phi[0,1]  R84       6.7183303833007812e-01
    phi[0,1]  R85       -5.3660207986831665e-01
    phi[0,1]  R86       1.9023345708847046e+00
    phi[0,1]  R87       7.9030889272689819e-01
    phi[0,1]  R88       -2.6383838653564453e+00
    phi[0,1]  R89       -1.2329595088958740e+00
    phi[0,1]  R90       2.2061185538768768e-01
    phi[0,1]  R91       -4.8593136668205261e-01
    phi[0,1]  R92       -3.0783984661102295e+00
    phi[0,1]  R93       -1.4652043581008911e+00
    phi[0,1]  R94       -1.8765295743942261e+00
    phi[0,1]  R95       -2.1096611022949219e+00
    phi[0,1]  R96       -1.5016263723373413e+00
    phi[0,1]  R97       -1.2712916135787964e+00
    phi[0,1]  R98       1.1400886774063110e+00
    phi[0,1]  R99       8.2618790864944458e-01
    phi[0,1]  R100      1.1216704845428467e+00
    phi[0,1]  R101      -4.6951510012149811e-02
    phi[0,1]  R102      -8.0834156274795532e-01
    phi[0,1]  R103      7.7749651670455933e-01
    phi[0,1]  R104      -8.7887190282344818e-02
    phi[0,1]  R105      4.3098270893096924e-02
    phi[0,1]  R106      -1.1035482883453369e+00
    phi[0,1]  R107      -1.3065031170845032e-01
    phi[0,1]  R108      7.2007620334625244e-01
    phi[0,1]  R109      2.1747288703918457e+00
    phi[0,1]  R110      2.0786471366882324e+00
    phi[0,1]  R111      -1.9353659152984619e+00
    phi[0,1]  R112      9.1971206665039062e-01
    phi[0,1]  R113      1.0301942825317383e+00
    phi[0,1]  R114      -6.2900000810623169e-01
    phi[0,1]  R115      5.0100100040435791e-01
    phi[0,1]  R116      -1.0810671374201775e-02
    phi[0,1]  R117      -9.5298784971237183e-01
    phi[0,1]  R118      -1.5549490451812744e+00
    phi[0,1]  R119      4.3937343358993530e-01
    phi[0,1]  R120      -5.9945666790008545e-01
    phi[0,1]  R121      -8.1020039319992065e-01
    phi[0,1]  R122      -2.5491482019424438e-01
    phi[0,1]  R123      7.3235303163528442e-01
    phi[0,1]  R124      1.3283593654632568e+00
    phi[0,1]  R125      -5.9504532814025879e-01
    phi[0,1]  R126      -4.0018844604492188e-01
    phi[0,1]  R127      -9.0296483039855957e-01
    phi[0,1]  R128      1.3670225143432617e+00
    phi[0,1]  R129      8.6851544678211212e-02
    phi[0,1]  R130      1.9838701486587524e+00
    phi[0,1]  R131      -1.3013432025909424e+00
    phi[0,1]  R132      4.5473405718803406e-01
    phi[0,1]  R133      7.7548170089721680e-01
    phi[0,1]  R134      6.9258832931518555e-01
    phi[0,1]  R135      -1.7963836193084717e+00
    phi[0,1]  R136      1.4050097763538361e-01
    phi[0,1]  R137      7.6795279979705811e-01
    phi[0,1]  R138      -2.5440546870231628e-01
    phi[0,1]  R139      -1.2351915836334229e+00
    phi[0,1]  R140      -1.1452368497848511e+00
    phi[0,1]  R141      -1.2558503150939941e+00
    phi[0,1]  R142      -1.0335665941238403e+00
    phi[0,1]  R143      2.3198740184307098e-01
    phi[0,1]  R144      -1.4644505977630615e+00
    phi[0,1]  R145      -1.5651099681854248e+00
    phi[0,1]  R146      1.4655187726020813e-01
    phi[0,1]  R147      -3.1656816005706787e+00
    phi[0,1]  R148      2.1129317581653595e-01
    phi[0,1]  R149      -1.0441242456436157e+00
    phi[0,1]  R150      1.6581664979457855e-01
    phi[0,1]  R151      -2.2550330162048340e+00
    phi[0,1]  R152      -6.5509945154190063e-01
    phi[0,1]  R153      -8.7992382049560547e-01
    phi[0,1]  R154      -8.8125973939895630e-01
    phi[0,1]  R155      -3.1579780578613281e+00
    phi[0,1]  R156      -9.1246563196182251e-01
    phi[0,1]  R157      -1.9587436318397522e-01
    phi[0,1]  R158      -3.0397663116455078e+00
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R159      -3.0999999046325684e+00
    phi[1,0]  R160      -3.0999999046325684e+00
    phi[1,0]  R161      -2.2400000095367432e+00
    phi[1,0]  R162      -2.2400000095367432e+00
    phi[1,0]  R163      -3.0999999046325684e+00
    phi[1,0]  R164      -3.0999999046325684e+00
    phi[1,0]  R165      -2.5699999332427979e+00
    phi[1,0]  R166      -2.5699999332427979e+00
    phi[1,0]  R167      -3.0999999046325684e+00
    phi[1,0]  R168      -3.0999999046325684e+00
    phi[1,0]  R169      -2.0899999141693115e+00
    phi[1,0]  R170      -2.0899999141693115e+00
    phi[1,0]  R171      -3.0999999046325684e+00
    phi[1,0]  R172      -3.0999999046325684e+00
    phi[1,0]  R173      8.6851544678211212e-02
    phi[1,0]  R174      1.9838701486587524e+00
    phi[1,0]  R175      -1.3013432025909424e+00
    phi[1,0]  R176      4.5473405718803406e-01
    phi[1,0]  R177      7.7548170089721680e-01
    phi[1,0]  R178      6.9258832931518555e-01
    phi[1,0]  R179      -1.7963836193084717e+00
    phi[1,0]  R180      1.4050097763538361e-01
    phi[1,0]  R181      7.6795279979705811e-01
    phi[1,0]  R182      -2.5440546870231628e-01
    phi[1,0]  R183      -1.2351915836334229e+00
    phi[1,0]  R184      -1.1452368497848511e+00
    phi[1,0]  R185      -1.2558503150939941e+00
    phi[1,0]  R186      -1.0335665941238403e+00
    phi[1,0]  R187      2.3198740184307098e-01
    phi[1,0]  R188      -1.4644505977630615e+00
    phi[1,0]  R189      -1.5651099681854248e+00
    phi[1,0]  R190      1.4655187726020813e-01
    phi[1,0]  R191      -3.1656816005706787e+00
    phi[1,0]  R192      2.1129317581653595e-01
    phi[1,0]  R193      -1.0441242456436157e+00
    phi[1,0]  R194      1.6581664979457855e-01
    phi[1,0]  R195      -2.2550330162048340e+00
    phi[1,0]  R196      -6.5509945154190063e-01
    phi[1,0]  R197      -8.7992382049560547e-01
    phi[1,0]  R198      -8.8125973939895630e-01
    phi[1,0]  R199      -3.1579780578613281e+00
    phi[1,0]  R200      -9.1246563196182251e-01
    phi[1,0]  R201      -1.9587436318397522e-01
    phi[1,0]  R202      -3.0397663116455078e+00
    phi[1,0]  R203      2.4470300674438477e+00
    phi[1,0]  R204      1.8479690551757812e+00
    phi[1,0]  R205      2.4377064704895020e+00
    phi[1,0]  R206      7.4503618478775024e-01
    phi[1,0]  R207      1.3827391862869263e+00
    phi[1,0]  R208      6.7183303833007812e-01
    phi[1,0]  R209      -5.3660207986831665e-01
    phi[1,0]  R210      1.9023345708847046e+00
    phi[1,0]  R211      7.9030889272689819e-01
    phi[1,0]  R212      -2.6383838653564453e+00
    phi[1,0]  R213      -1.2329595088958740e+00
    phi[1,0]  R214      2.2061185538768768e-01
    phi[1,0]  R215      -4.8593136668205261e-01
    phi[1,0]  R216      -3.0783984661102295e+00
    phi[1,0]  R217      -1.4652043581008911e+00
    phi[1,0]  R218      -1.8765295743942261e+00
    phi[1,0]  R219      -2.1096611022949219e+00
    phi[1,0]  R220      -1.5016263723373413e+00
    phi[1,0]  R221      -1.2712916135787964e+00
    phi[1,0]  R222      1.1400886774063110e+00
    phi[1,0]  R223      8.2618790864944458e-01
    phi[1,0]  R224      1.1216704845428467e+00
    phi[1,0]  R225      -4.6951510012149811e-02
    phi[1,0]  R226      -8.0834156274795532e-01
    phi[1,0]  R227      7.7749651670455933e-01
    phi[1,0]  R228      -8.7887190282344818e-02
    phi[1,0]  R229      4.3098270893096924e-02
    phi[1,0]  R230      -1.1035482883453369e+00
    phi[1,0]  R231      -1.3065031170845032e-01
    phi[1,0]  R232      7.2007620334625244e-01
    phi[1,0]  R233      2.1747288703918457e+00
    phi[1,0]  R234      2.0786471366882324e+00
    phi[1,0]  R235      -1.9353659152984619e+00
    phi[1,0]  R236      9.1971206665039062e-01
    phi[1,0]  R237      1.0301942825317383e+00
    phi[1,0]  R238      -6.2900000810623169e-01
    phi[1,0]  R239      5.0100100040435791e-01
    phi[1,0]  R240      -1.0810671374201775e-02
    phi[1,0]  R241      -9.5298784971237183e-01
    phi[1,0]  R242      -1.5549490451812744e+00
    phi[1,0]  R243      4.3937343358993530e-01
    phi[1,0]  R244      -5.9945666790008545e-01
    phi[1,0]  R245      -8.1020039319992065e-01
    phi[1,0]  R246      -2.5491482019424438e-01
    phi[1,0]  R247      7.3235303163528442e-01
    phi[1,0]  R248      1.3283593654632568e+00
    phi[1,0]  R249      -5.9504532814025879e-01
    phi[1,0]  R250      -4.0018844604492188e-01
    phi[1,0]  R251      -9.0296483039855957e-01
    phi[1,0]  R252      1.3670225143432617e+00
    phi[0,3]  R0        1
    phi[0,3]  R1        1
    phi[0,3]  R27       -1
    phi[0,3]  R253      -3.0999999046325684e+00
    phi[0,3]  R254      -3.0999999046325684e+00
    phi[0,3]  R255      -2.2400000095367432e+00
    phi[0,3]  R256      -2.2400000095367432e+00
    phi[0,3]  R257      -3.0999999046325684e+00
    phi[0,3]  R258      -3.0999999046325684e+00
    phi[0,3]  R259      -2.5699999332427979e+00
    phi[0,3]  R260      -2.5699999332427979e+00
    phi[0,3]  R261      -3.0999999046325684e+00
    phi[0,3]  R262      -3.0999999046325684e+00
    phi[0,3]  R263      -2.0899999141693115e+00
    phi[0,3]  R264      -2.0899999141693115e+00
    phi[0,3]  R265      -3.0999999046325684e+00
    phi[0,3]  R266      -3.0999999046325684e+00
    phi[0,3]  R267      2.4470300674438477e+00
    phi[0,3]  R268      1.8479690551757812e+00
    phi[0,3]  R269      2.4377064704895020e+00
    phi[0,3]  R270      7.4503618478775024e-01
    phi[0,3]  R271      1.3827391862869263e+00
    phi[0,3]  R272      6.7183303833007812e-01
    phi[0,3]  R273      -5.3660207986831665e-01
    phi[0,3]  R274      1.9023345708847046e+00
    phi[0,3]  R275      7.9030889272689819e-01
    phi[0,3]  R276      -2.6383838653564453e+00
    phi[0,3]  R277      -1.2329595088958740e+00
    phi[0,3]  R278      2.2061185538768768e-01
    phi[0,3]  R279      -4.8593136668205261e-01
    phi[0,3]  R280      -3.0783984661102295e+00
    phi[0,3]  R281      -1.4652043581008911e+00
    phi[0,3]  R282      -1.8765295743942261e+00
    phi[0,3]  R283      -2.1096611022949219e+00
    phi[0,3]  R284      -1.5016263723373413e+00
    phi[0,3]  R285      -1.2712916135787964e+00
    phi[0,3]  R286      1.1400886774063110e+00
    phi[0,3]  R287      8.2618790864944458e-01
    phi[0,3]  R288      1.1216704845428467e+00
    phi[0,3]  R289      -4.6951510012149811e-02
    phi[0,3]  R290      -8.0834156274795532e-01
    phi[0,3]  R291      7.7749651670455933e-01
    phi[0,3]  R292      -8.7887190282344818e-02
    phi[0,3]  R293      4.3098270893096924e-02
    phi[0,3]  R294      -1.1035482883453369e+00
    phi[0,3]  R295      -1.3065031170845032e-01
    phi[0,3]  R296      7.2007620334625244e-01
    phi[0,3]  R297      2.1747288703918457e+00
    phi[0,3]  R298      2.0786471366882324e+00
    phi[0,3]  R299      -1.9353659152984619e+00
    phi[0,3]  R300      9.1971206665039062e-01
    phi[0,3]  R301      1.0301942825317383e+00
    phi[0,3]  R302      -6.2900000810623169e-01
    phi[0,3]  R303      5.0100100040435791e-01
    phi[0,3]  R304      -1.0810671374201775e-02
    phi[0,3]  R305      -9.5298784971237183e-01
    phi[0,3]  R306      -1.5549490451812744e+00
    phi[0,3]  R307      4.3937343358993530e-01
    phi[0,3]  R308      -5.9945666790008545e-01
    phi[0,3]  R309      -8.1020039319992065e-01
    phi[0,3]  R310      -2.5491482019424438e-01
    phi[0,3]  R311      7.3235303163528442e-01
    phi[0,3]  R312      1.3283593654632568e+00
    phi[0,3]  R313      -5.9504532814025879e-01
    phi[0,3]  R314      -4.0018844604492188e-01
    phi[0,3]  R315      -9.0296483039855957e-01
    phi[0,3]  R316      1.3670225143432617e+00
    phi[0,3]  R317      7.6624006032943726e-01
    phi[0,3]  R318      8.7073397636413574e-01
    phi[0,3]  R319      6.3541121780872345e-02
    phi[0,3]  R320      -1.2582535743713379e+00
    phi[0,3]  R321      -0.852837860584259
    phi[0,3]  R322      1.4180004596710205e-01
    phi[0,3]  R323      1.5976523160934448e+00
    phi[0,3]  R324      1.0674113035202026e+00
    phi[0,3]  R325      -9.8094239830970764e-02
    phi[0,3]  R326      -5.7521104812622070e-01
    phi[0,3]  R327      -1.2389801740646362e+00
    phi[0,3]  R328      6.7096692323684692e-01
    phi[0,3]  R329      -1.6095486879348755e+00
    phi[0,3]  R330      -3.0579705238342285e+00
    phi[0,3]  R331      9.6556764841079712e-01
    phi[0,3]  R332      -1.6038076579570770e-01
    phi[0,3]  R333      -4.1359135508537292e-01
    phi[0,3]  R334      -8.6468511819839478e-01
    phi[0,3]  R335      -2.1252238750457764e-01
    phi[0,3]  R336      8.6411453783512115e-02
    phi[0,3]  R337      -9.9754285812377930e-01
    phi[0,3]  R338      -3.0408966541290283e+00
    phi[0,3]  R339      4.8528519272804260e-01
    phi[0,3]  R340      -2.1842072010040283e+00
    phi[0,3]  R341      1.9598045349121094e+00
    phi[0,3]  R342      1.5360081195831299e+00
    phi[0,3]  R343      -4.7072279453277588e-01
    phi[0,3]  R344      1.7719395458698273e-01
    phi[0,3]  R345      -2.9408857226371765e-01
    phi[3,0]  R0        -1
    phi[3,0]  R27       1
    phi[3,0]  R28       1
    phi[3,0]  R346      -3.0999999046325684e+00
    phi[3,0]  R347      -3.0999999046325684e+00
    phi[3,0]  R348      -2.2400000095367432e+00
    phi[3,0]  R349      -2.2400000095367432e+00
    phi[3,0]  R350      -3.0999999046325684e+00
    phi[3,0]  R351      -3.0999999046325684e+00
    phi[3,0]  R352      -2.5699999332427979e+00
    phi[3,0]  R353      -2.5699999332427979e+00
    phi[3,0]  R354      -3.0999999046325684e+00
    phi[3,0]  R355      -3.0999999046325684e+00
    phi[3,0]  R356      -2.0899999141693115e+00
    phi[3,0]  R357      -2.0899999141693115e+00
    phi[3,0]  R358      -3.0999999046325684e+00
    phi[3,0]  R359      -3.0999999046325684e+00
    phi[3,0]  R360      7.6624006032943726e-01
    phi[3,0]  R361      8.7073397636413574e-01
    phi[3,0]  R362      6.3541121780872345e-02
    phi[3,0]  R363      -1.2582535743713379e+00
    phi[3,0]  R364      -0.852837860584259
    phi[3,0]  R365      1.4180004596710205e-01
    phi[3,0]  R366      1.5976523160934448e+00
    phi[3,0]  R367      1.0674113035202026e+00
    phi[3,0]  R368      -9.8094239830970764e-02
    phi[3,0]  R369      -5.7521104812622070e-01
    phi[3,0]  R370      -1.2389801740646362e+00
    phi[3,0]  R371      6.7096692323684692e-01
    phi[3,0]  R372      -1.6095486879348755e+00
    phi[3,0]  R373      -3.0579705238342285e+00
    phi[3,0]  R374      9.6556764841079712e-01
    phi[3,0]  R375      -1.6038076579570770e-01
    phi[3,0]  R376      -4.1359135508537292e-01
    phi[3,0]  R377      -8.6468511819839478e-01
    phi[3,0]  R378      -2.1252238750457764e-01
    phi[3,0]  R379      8.6411453783512115e-02
    phi[3,0]  R380      -9.9754285812377930e-01
    phi[3,0]  R381      -3.0408966541290283e+00
    phi[3,0]  R382      4.8528519272804260e-01
    phi[3,0]  R383      -2.1842072010040283e+00
    phi[3,0]  R384      1.9598045349121094e+00
    phi[3,0]  R385      1.5360081195831299e+00
    phi[3,0]  R386      -4.7072279453277588e-01
    phi[3,0]  R387      1.7719395458698273e-01
    phi[3,0]  R388      -2.9408857226371765e-01
    phi[3,0]  R389      2.4470300674438477e+00
    phi[3,0]  R390      1.8479690551757812e+00
    phi[3,0]  R391      2.4377064704895020e+00
    phi[3,0]  R392      7.4503618478775024e-01
    phi[3,0]  R393      1.3827391862869263e+00
    phi[3,0]  R394      6.7183303833007812e-01
    phi[3,0]  R395      -5.3660207986831665e-01
    phi[3,0]  R396      1.9023345708847046e+00
    phi[3,0]  R397      7.9030889272689819e-01
    phi[3,0]  R398      -2.6383838653564453e+00
    phi[3,0]  R399      -1.2329595088958740e+00
    phi[3,0]  R400      2.2061185538768768e-01
    phi[3,0]  R401      -4.8593136668205261e-01
    phi[3,0]  R402      -3.0783984661102295e+00
    phi[3,0]  R403      -1.4652043581008911e+00
    phi[3,0]  R404      -1.8765295743942261e+00
    phi[3,0]  R405      -2.1096611022949219e+00
    phi[3,0]  R406      -1.5016263723373413e+00
    phi[3,0]  R407      -1.2712916135787964e+00
    phi[3,0]  R408      1.1400886774063110e+00
    phi[3,0]  R409      8.2618790864944458e-01
    phi[3,0]  R410      1.1216704845428467e+00
    phi[3,0]  R411      -4.6951510012149811e-02
    phi[3,0]  R412      -8.0834156274795532e-01
    phi[3,0]  R413      7.7749651670455933e-01
    phi[3,0]  R414      -8.7887190282344818e-02
    phi[3,0]  R415      4.3098270893096924e-02
    phi[3,0]  R416      -1.1035482883453369e+00
    phi[3,0]  R417      -1.3065031170845032e-01
    phi[3,0]  R418      7.2007620334625244e-01
    phi[3,0]  R419      2.1747288703918457e+00
    phi[3,0]  R420      2.0786471366882324e+00
    phi[3,0]  R421      -1.9353659152984619e+00
    phi[3,0]  R422      9.1971206665039062e-01
    phi[3,0]  R423      1.0301942825317383e+00
    phi[3,0]  R424      -6.2900000810623169e-01
    phi[3,0]  R425      5.0100100040435791e-01
    phi[3,0]  R426      -1.0810671374201775e-02
    phi[3,0]  R427      -9.5298784971237183e-01
    phi[3,0]  R428      -1.5549490451812744e+00
    phi[3,0]  R429      4.3937343358993530e-01
    phi[3,0]  R430      -5.9945666790008545e-01
    phi[3,0]  R431      -8.1020039319992065e-01
    phi[3,0]  R432      -2.5491482019424438e-01
    phi[3,0]  R433      7.3235303163528442e-01
    phi[3,0]  R434      1.3283593654632568e+00
    phi[3,0]  R435      -5.9504532814025879e-01
    phi[3,0]  R436      -4.0018844604492188e-01
    phi[3,0]  R437      -9.0296483039855957e-01
    phi[3,0]  R438      1.3670225143432617e+00
    phi[7,0]  R0        -1
    phi[7,0]  R2        -1.3550681263039
    phi[7,0]  R3        2.0686367358790969e-01
    phi[7,0]  R4        2.9534051777112533e+00
    phi[7,0]  R5        1.5626497589467756e+00
    phi[7,0]  R6        2.8910893979909322e+00
    phi[7,0]  R7        5.7556263234235239e-01
    phi[7,0]  R8        -1.5764510220519012e-01
    phi[7,0]  R63       1
    phi[7,0]  R439      -1.7449317783286684e+00
    phi[7,0]  R440      -4.4550680309364683e+00
    phi[7,0]  R441      -2.4468636831246529e+00
    phi[7,0]  R442      -2.0331363359488335e+00
    phi[7,0]  R443      -6.0534050823438221e+00
    phi[7,0]  R444      -1.4659472692131503e-01
    phi[7,0]  R445      -4.1326496921895739e+00
    phi[7,0]  R446      -1.0073501742960222e+00
    phi[7,0]  R447      -5.9910893026235
    phi[7,0]  R448      -2.0891050664163613e-01
    phi[7,0]  R449      -2.6655625465116639e+00
    phi[7,0]  R450      -1.5144372818269591e+00
    phi[7,0]  R451      -2.9423548024273782e+00
    phi[7,0]  R452      -3.2576450068377585e+00
    phi[7,0]  R453      -4.0533951667889889e-01
    phi[7,0]  R454      -4.3187681174054493e-01
    phi[7,0]  R455      -4.4938542563049078e-01
    phi[7,0]  R456      -4.8535096682861112e-01
    phi[7,0]  R457      -4.9779951513089049e-01
    phi[7,0]  R458      -5.0374674794150831e-01
    phi[7,0]  R459      -5.3022883667873411e-01
    phi[7,0]  R460      -5.7443741097854328e-01
    phi[7,0]  R461      -6.0693829600321791e-01
    phi[7,0]  R462      -6.1033782980078222e-01
    phi[7,0]  R463      -3.6416889940545072e-01
    phi[7,0]  R464      -3.8950088655117543e-01
    phi[7,0]  R465      -4.3708343268940569e-01
    phi[7,0]  R466      -0.824077719072982
    phi[7,0]  R467      -0.835370943430506
    phi[7,0]  R468      -5.5149492673036327e-01
    phi[7,0]  R469      -5.5325586749699007e-01
    phi[7,0]  R470      -1.1310545435035393e+00
    phi[7,0]  R471      -8.7058306239672723e-01
    phi[7,0]  R472      -6.4708169826526274e-01
    phi[7,0]  R473      -5.2758863420899083e-01
    phi[7,0]  R474      -5.5604792518198121e-01
    phi[7,0]  R475      -6.4965683438400790e-01
    phi[7,0]  R476      -0.739620261205858
    phi[7,0]  R477      -7.7568374621443881e-01
    phi[7,0]  R478      -7.8125838478249132e-01
    phi[7,0]  R479      -7.8982117622510373e-01
    phi[7,0]  R480      -7.9174918153293850e-01
    phi[7,0]  R481      -8.0084182146003724e-01
    phi[7,0]  R482      -0.805323014340718
    phi[7,0]  R483      -3.8286557119172659e-01
    phi[7,0]  R484      -4.0146792100852657e-01
    phi[7,0]  R485      -4.4153077796604334e-01
    phi[7,0]  R486      -4.8064334514897067e-01
    phi[7,0]  R487      -0.493783051519606
    phi[7,0]  R488      -5.2106919275755192e-01
    phi[7,0]  R489      -0.561581346257878
    phi[7,0]  R490      -0.561924508168821
    phi[7,0]  R491      -6.4229235062722845e-01
    phi[7,0]  R492      -6.5495451340191924e-01
    phi[7,0]  R493      -3.1084508416865153e-01
    phi[7,0]  R494      -5.8597210091700469e-01
    phi[7,0]  R495      -6.1908701678386935e-01
    phi[7,0]  R496      -6.5451514675013955e-01
    phi[7,0]  R497      -6.7508300625024109e-01
    phi[7,0]  R498      -0.682157507687362
    phi[7,0]  R499      -7.8423913637908915e-01
    phi[7,0]  R500      -8.3417797862073473e-01
    phi[7,0]  R501      -8.3544215678231182e-01
    phi[7,0]  R502      -9.7305824551620157e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R503      -3.0999999046325684e+00
    phi[1,2]  R504      -3.0999999046325684e+00
    phi[1,2]  R505      -2.2400000095367432e+00
    phi[1,2]  R506      -2.2400000095367432e+00
    phi[1,2]  R507      -3.0999999046325684e+00
    phi[1,2]  R508      -3.0999999046325684e+00
    phi[1,2]  R509      -2.5699999332427979e+00
    phi[1,2]  R510      -2.5699999332427979e+00
    phi[1,2]  R511      -3.0999999046325684e+00
    phi[1,2]  R512      -3.0999999046325684e+00
    phi[1,2]  R513      -2.0899999141693115e+00
    phi[1,2]  R514      -2.0899999141693115e+00
    phi[1,2]  R515      -3.0999999046325684e+00
    phi[1,2]  R516      -3.0999999046325684e+00
    phi[1,2]  R517      8.6851544678211212e-02
    phi[1,2]  R518      1.9838701486587524e+00
    phi[1,2]  R519      -1.3013432025909424e+00
    phi[1,2]  R520      4.5473405718803406e-01
    phi[1,2]  R521      7.7548170089721680e-01
    phi[1,2]  R522      6.9258832931518555e-01
    phi[1,2]  R523      -1.7963836193084717e+00
    phi[1,2]  R524      1.4050097763538361e-01
    phi[1,2]  R525      7.6795279979705811e-01
    phi[1,2]  R526      -2.5440546870231628e-01
    phi[1,2]  R527      -1.2351915836334229e+00
    phi[1,2]  R528      -1.1452368497848511e+00
    phi[1,2]  R529      -1.2558503150939941e+00
    phi[1,2]  R530      -1.0335665941238403e+00
    phi[1,2]  R531      2.3198740184307098e-01
    phi[1,2]  R532      -1.4644505977630615e+00
    phi[1,2]  R533      -1.5651099681854248e+00
    phi[1,2]  R534      1.4655187726020813e-01
    phi[1,2]  R535      -3.1656816005706787e+00
    phi[1,2]  R536      2.1129317581653595e-01
    phi[1,2]  R537      -1.0441242456436157e+00
    phi[1,2]  R538      1.6581664979457855e-01
    phi[1,2]  R539      -2.2550330162048340e+00
    phi[1,2]  R540      -6.5509945154190063e-01
    phi[1,2]  R541      -8.7992382049560547e-01
    phi[1,2]  R542      -8.8125973939895630e-01
    phi[1,2]  R543      -3.1579780578613281e+00
    phi[1,2]  R544      -9.1246563196182251e-01
    phi[1,2]  R545      -1.9587436318397522e-01
    phi[1,2]  R546      -3.0397663116455078e+00
    phi[1,2]  R547      1.6060771942138672e+00
    phi[1,2]  R548      1.8287003040313721e+00
    phi[1,2]  R549      1.1677653789520264e+00
    phi[1,2]  R550      4.5427301526069641e-01
    phi[1,2]  R551      6.5305948257446289e-01
    phi[1,2]  R552      0.707932710647583
    phi[1,2]  R553      1.2563668489456177e+00
    phi[1,2]  R554      1.9391212463378906e+00
    phi[1,2]  R555      1.8411041498184204e+00
    phi[1,2]  R556      1.4448857307434082e+00
    phi[1,2]  R557      -1.6837440729141235e+00
    phi[1,2]  R558      -1.1147780418395996e+00
    phi[1,2]  R559      -2.1535389423370361e+00
    phi[1,2]  R560      -2.4632074832916260e+00
    phi[1,2]  R561      -2.4386303424835205e+00
    phi[1,2]  R562      -3.1069284677505493e-01
    phi[1,2]  R563      -2.1550416946411133e+00
    phi[1,2]  R564      -1.0178964138031006e+00
    phi[1,2]  R565      -1.7698980569839478e+00
    phi[1,2]  R566      -3.2427403926849365e+00
    phi[1,2]  R567      1.4479906558990479e+00
    phi[1,2]  R568      7.1615827083587646e-01
    phi[1,2]  R569      -8.5022526979446411e-01
    phi[1,2]  R570      -1.0141491144895554e-01
    phi[1,2]  R571      -3.9661136269569397e-01
    phi[1,2]  R572      -1.4362233877182007e-01
    phi[1,2]  R573      6.4183771610260010e-01
    phi[1,2]  R574      -1.1017217636108398e+00
    phi[1,2]  R575      -3.2558679580688477e-01
    phi[1,2]  R576      1.2046914100646973e+00
    phi[1,2]  R577      -1.5689424276351929e+00
    phi[1,2]  R578      -2.8515503406524658e+00
    phi[1,2]  R579      -2.4241050705313683e-02
    phi[1,2]  R580      1.1722551584243774e+00
    phi[1,2]  R581      6.6547647118568420e-02
    phi[1,2]  R582      -4.1880190372467041e-01
    phi[1,2]  R583      1.6503981351852417e+00
    phi[1,2]  R584      1.7493067979812622e+00
    phi[1,2]  R585      0.419420450925827
    phi[1,2]  R586      0.867963969707489
    phi[1,2]  R587      0.0363311693072319
    phi[1,2]  R588      -8.4838904440402985e-02
    phi[1,2]  R589      -1.3639408349990845e+00
    phi[1,2]  R590      -5.0670862197875977e-02
    phi[1,2]  R591      -1.8000050783157349e+00
    phi[1,2]  R592      -1.7321132421493530e+00
    phi[1,2]  R593      -4.8732721805572510e-01
    phi[1,2]  R594      -1.9447910785675049e+00
    phi[1,2]  R595      1.9736206531524658e+00
    phi[1,2]  R596      1.5280526876449585e-01
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R597      -3.0999999046325684e+00
    phi[2,1]  R598      -3.0999999046325684e+00
    phi[2,1]  R599      -2.2400000095367432e+00
    phi[2,1]  R600      -2.2400000095367432e+00
    phi[2,1]  R601      -3.0999999046325684e+00
    phi[2,1]  R602      -3.0999999046325684e+00
    phi[2,1]  R603      -2.5699999332427979e+00
    phi[2,1]  R604      -2.5699999332427979e+00
    phi[2,1]  R605      -3.0999999046325684e+00
    phi[2,1]  R606      -3.0999999046325684e+00
    phi[2,1]  R607      -2.0899999141693115e+00
    phi[2,1]  R608      -2.0899999141693115e+00
    phi[2,1]  R609      -3.0999999046325684e+00
    phi[2,1]  R610      -3.0999999046325684e+00
    phi[2,1]  R611      1.6060771942138672e+00
    phi[2,1]  R612      1.8287003040313721e+00
    phi[2,1]  R613      1.1677653789520264e+00
    phi[2,1]  R614      4.5427301526069641e-01
    phi[2,1]  R615      6.5305948257446289e-01
    phi[2,1]  R616      0.707932710647583
    phi[2,1]  R617      1.2563668489456177e+00
    phi[2,1]  R618      1.9391212463378906e+00
    phi[2,1]  R619      1.8411041498184204e+00
    phi[2,1]  R620      1.4448857307434082e+00
    phi[2,1]  R621      -1.6837440729141235e+00
    phi[2,1]  R622      -1.1147780418395996e+00
    phi[2,1]  R623      -2.1535389423370361e+00
    phi[2,1]  R624      -2.4632074832916260e+00
    phi[2,1]  R625      -2.4386303424835205e+00
    phi[2,1]  R626      -3.1069284677505493e-01
    phi[2,1]  R627      -2.1550416946411133e+00
    phi[2,1]  R628      -1.0178964138031006e+00
    phi[2,1]  R629      -1.7698980569839478e+00
    phi[2,1]  R630      -3.2427403926849365e+00
    phi[2,1]  R631      1.4479906558990479e+00
    phi[2,1]  R632      7.1615827083587646e-01
    phi[2,1]  R633      -8.5022526979446411e-01
    phi[2,1]  R634      -1.0141491144895554e-01
    phi[2,1]  R635      -3.9661136269569397e-01
    phi[2,1]  R636      -1.4362233877182007e-01
    phi[2,1]  R637      6.4183771610260010e-01
    phi[2,1]  R638      -1.1017217636108398e+00
    phi[2,1]  R639      -3.2558679580688477e-01
    phi[2,1]  R640      1.2046914100646973e+00
    phi[2,1]  R641      -1.5689424276351929e+00
    phi[2,1]  R642      -2.8515503406524658e+00
    phi[2,1]  R643      -2.4241050705313683e-02
    phi[2,1]  R644      1.1722551584243774e+00
    phi[2,1]  R645      6.6547647118568420e-02
    phi[2,1]  R646      -4.1880190372467041e-01
    phi[2,1]  R647      1.6503981351852417e+00
    phi[2,1]  R648      1.7493067979812622e+00
    phi[2,1]  R649      0.419420450925827
    phi[2,1]  R650      0.867963969707489
    phi[2,1]  R651      0.0363311693072319
    phi[2,1]  R652      -8.4838904440402985e-02
    phi[2,1]  R653      -1.3639408349990845e+00
    phi[2,1]  R654      -5.0670862197875977e-02
    phi[2,1]  R655      -1.8000050783157349e+00
    phi[2,1]  R656      -1.7321132421493530e+00
    phi[2,1]  R657      -4.8732721805572510e-01
    phi[2,1]  R658      -1.9447910785675049e+00
    phi[2,1]  R659      1.9736206531524658e+00
    phi[2,1]  R660      1.5280526876449585e-01
    phi[2,1]  R661      8.6851544678211212e-02
    phi[2,1]  R662      1.9838701486587524e+00
    phi[2,1]  R663      -1.3013432025909424e+00
    phi[2,1]  R664      4.5473405718803406e-01
    phi[2,1]  R665      7.7548170089721680e-01
    phi[2,1]  R666      6.9258832931518555e-01
    phi[2,1]  R667      -1.7963836193084717e+00
    phi[2,1]  R668      1.4050097763538361e-01
    phi[2,1]  R669      7.6795279979705811e-01
    phi[2,1]  R670      -2.5440546870231628e-01
    phi[2,1]  R671      -1.2351915836334229e+00
    phi[2,1]  R672      -1.1452368497848511e+00
    phi[2,1]  R673      -1.2558503150939941e+00
    phi[2,1]  R674      -1.0335665941238403e+00
    phi[2,1]  R675      2.3198740184307098e-01
    phi[2,1]  R676      -1.4644505977630615e+00
    phi[2,1]  R677      -1.5651099681854248e+00
    phi[2,1]  R678      1.4655187726020813e-01
    phi[2,1]  R679      -3.1656816005706787e+00
    phi[2,1]  R680      2.1129317581653595e-01
    phi[2,1]  R681      -1.0441242456436157e+00
    phi[2,1]  R682      1.6581664979457855e-01
    phi[2,1]  R683      -2.2550330162048340e+00
    phi[2,1]  R684      -6.5509945154190063e-01
    phi[2,1]  R685      -8.7992382049560547e-01
    phi[2,1]  R686      -8.8125973939895630e-01
    phi[2,1]  R687      -3.1579780578613281e+00
    phi[2,1]  R688      -9.1246563196182251e-01
    phi[2,1]  R689      -1.9587436318397522e-01
    phi[2,1]  R690      -3.0397663116455078e+00
    phi[1,4]  R9        1
    phi[1,4]  R10       1
    phi[1,4]  R36       -1
    phi[1,4]  R691      -3.0999999046325684e+00
    phi[1,4]  R692      -3.0999999046325684e+00
    phi[1,4]  R693      -2.2400000095367432e+00
    phi[1,4]  R694      -2.2400000095367432e+00
    phi[1,4]  R695      -3.0999999046325684e+00
    phi[1,4]  R696      -3.0999999046325684e+00
    phi[1,4]  R697      -2.5699999332427979e+00
    phi[1,4]  R698      -2.5699999332427979e+00
    phi[1,4]  R699      -3.0999999046325684e+00
    phi[1,4]  R700      -3.0999999046325684e+00
    phi[1,4]  R701      -2.0899999141693115e+00
    phi[1,4]  R702      -2.0899999141693115e+00
    phi[1,4]  R703      -3.0999999046325684e+00
    phi[1,4]  R704      -3.0999999046325684e+00
    phi[1,4]  R705      8.6851544678211212e-02
    phi[1,4]  R706      1.9838701486587524e+00
    phi[1,4]  R707      -1.3013432025909424e+00
    phi[1,4]  R708      4.5473405718803406e-01
    phi[1,4]  R709      7.7548170089721680e-01
    phi[1,4]  R710      6.9258832931518555e-01
    phi[1,4]  R711      -1.7963836193084717e+00
    phi[1,4]  R712      1.4050097763538361e-01
    phi[1,4]  R713      7.6795279979705811e-01
    phi[1,4]  R714      -2.5440546870231628e-01
    phi[1,4]  R715      -1.2351915836334229e+00
    phi[1,4]  R716      -1.1452368497848511e+00
    phi[1,4]  R717      -1.2558503150939941e+00
    phi[1,4]  R718      -1.0335665941238403e+00
    phi[1,4]  R719      2.3198740184307098e-01
    phi[1,4]  R720      -1.4644505977630615e+00
    phi[1,4]  R721      -1.5651099681854248e+00
    phi[1,4]  R722      1.4655187726020813e-01
    phi[1,4]  R723      -3.1656816005706787e+00
    phi[1,4]  R724      2.1129317581653595e-01
    phi[1,4]  R725      -1.0441242456436157e+00
    phi[1,4]  R726      1.6581664979457855e-01
    phi[1,4]  R727      -2.2550330162048340e+00
    phi[1,4]  R728      -6.5509945154190063e-01
    phi[1,4]  R729      -8.7992382049560547e-01
    phi[1,4]  R730      -8.8125973939895630e-01
    phi[1,4]  R731      -3.1579780578613281e+00
    phi[1,4]  R732      -9.1246563196182251e-01
    phi[1,4]  R733      -1.9587436318397522e-01
    phi[1,4]  R734      -3.0397663116455078e+00
    phi[1,4]  R735      -4.5784822106361389e-01
    phi[1,4]  R736      -2.9499703645706177e-01
    phi[1,4]  R737      -1.0516991615295410e+00
    phi[1,4]  R738      -2.5301668643951416e+00
    phi[1,4]  R739      1.0645778179168701e+00
    phi[1,4]  R740      -1.0650328397750854e+00
    phi[1,4]  R741      -8.1583850085735321e-02
    phi[1,4]  R742      -1.1857541799545288e+00
    phi[1,4]  R743      -2.9100706577301025e+00
    phi[1,4]  R744      -2.2868428230285645e+00
    phi[1,4]  R745      -9.1827267408370972e-01
    phi[1,4]  R746      -3.7565183639526367e-01
    phi[1,4]  R747      1.4464820921421051e-01
    phi[1,4]  R748      -0.792131781578064
    phi[1,4]  R749      -1.1212884187698364e+00
    phi[1,4]  R750      -7.6836013793945312e-01
    phi[1,4]  R751      5.0052696466445923e-01
    phi[1,4]  R752      -1.0866140127182007e+00
    phi[1,4]  R753      -3.7080189585685730e-01
    phi[1,4]  R754      -5.2885800600051880e-01
    phi[1,4]  R755      -1.9754477739334106e+00
    phi[1,4]  R756      -1.8062031269073486e-01
    phi[1,4]  R757      -7.9203057289123535e-01
    phi[1,4]  R758      -0.6389120221138
    phi[1,4]  R759      -0.89692223072052
    phi[1,4]  R760      -3.9350599050521851e-02
    phi[1,4]  R761      7.7230364084243774e-02
    phi[1,4]  R762      -1.0600973367691040e+00
    phi[1,4]  R763      -1.1978632211685181e+00
    phi[1,4]  R764      0.80079585313797
    phi[1,4]  R765      -7.3709380626678467e-01
    phi[1,4]  R766      -2.9536029696464539e-01
    phi[1,4]  R767      2.3081381618976593e-01
    phi[1,4]  R768      -1.7289516925811768e+00
    phi[1,4]  R769      7.9319781064987183e-01
    phi[1,4]  R770      -9.4018924236297607e-01
    phi[1,4]  R771      1.3797641992568970e+00
    phi[1,4]  R772      -2.3305485248565674e+00
    phi[1,4]  R773      7.7171194553375244e-01
    phi[1,4]  R774      -8.6895430088043213e-01
    phi[1,4]  R775      -9.6156805753707886e-01
    phi[1,4]  R776      -1.1809604167938232e+00
    phi[1,4]  R777      -6.4265263080596924e-01
    phi[1,4]  R778      -6.1832308769226074e-01
    phi[1,4]  R779      -9.5892304182052612e-01
    phi[1,4]  R780      2.3982904851436615e-01
    phi[1,4]  R781      4.9615317583084106e-01
    phi[1,4]  R782      1.3157655000686646e+00
    phi[1,4]  R783      -3.7837758660316467e-01
    phi[1,4]  R784      4.6028682589530945e-01
    phi[4,1]  R9        -1
    phi[4,1]  R36       1
    phi[4,1]  R37       1
    phi[4,1]  R785      -3.0999999046325684e+00
    phi[4,1]  R786      -3.0999999046325684e+00
    phi[4,1]  R787      -2.2400000095367432e+00
    phi[4,1]  R788      -2.2400000095367432e+00
    phi[4,1]  R789      -3.0999999046325684e+00
    phi[4,1]  R790      -3.0999999046325684e+00
    phi[4,1]  R791      -2.5699999332427979e+00
    phi[4,1]  R792      -2.5699999332427979e+00
    phi[4,1]  R793      -3.0999999046325684e+00
    phi[4,1]  R794      -3.0999999046325684e+00
    phi[4,1]  R795      -2.0899999141693115e+00
    phi[4,1]  R796      -2.0899999141693115e+00
    phi[4,1]  R797      -3.0999999046325684e+00
    phi[4,1]  R798      -3.0999999046325684e+00
    phi[4,1]  R799      -4.5784822106361389e-01
    phi[4,1]  R800      -2.9499703645706177e-01
    phi[4,1]  R801      -1.0516991615295410e+00
    phi[4,1]  R802      -2.5301668643951416e+00
    phi[4,1]  R803      1.0645778179168701e+00
    phi[4,1]  R804      -1.0650328397750854e+00
    phi[4,1]  R805      -8.1583850085735321e-02
    phi[4,1]  R806      -1.1857541799545288e+00
    phi[4,1]  R807      -2.9100706577301025e+00
    phi[4,1]  R808      -2.2868428230285645e+00
    phi[4,1]  R809      -9.1827267408370972e-01
    phi[4,1]  R810      -3.7565183639526367e-01
    phi[4,1]  R811      1.4464820921421051e-01
    phi[4,1]  R812      -0.792131781578064
    phi[4,1]  R813      -1.1212884187698364e+00
    phi[4,1]  R814      -7.6836013793945312e-01
    phi[4,1]  R815      5.0052696466445923e-01
    phi[4,1]  R816      -1.0866140127182007e+00
    phi[4,1]  R817      -3.7080189585685730e-01
    phi[4,1]  R818      -5.2885800600051880e-01
    phi[4,1]  R819      -1.9754477739334106e+00
    phi[4,1]  R820      -1.8062031269073486e-01
    phi[4,1]  R821      -7.9203057289123535e-01
    phi[4,1]  R822      -0.6389120221138
    phi[4,1]  R823      -0.89692223072052
    phi[4,1]  R824      -3.9350599050521851e-02
    phi[4,1]  R825      7.7230364084243774e-02
    phi[4,1]  R826      -1.0600973367691040e+00
    phi[4,1]  R827      -1.1978632211685181e+00
    phi[4,1]  R828      0.80079585313797
    phi[4,1]  R829      -7.3709380626678467e-01
    phi[4,1]  R830      -2.9536029696464539e-01
    phi[4,1]  R831      2.3081381618976593e-01
    phi[4,1]  R832      -1.7289516925811768e+00
    phi[4,1]  R833      7.9319781064987183e-01
    phi[4,1]  R834      -9.4018924236297607e-01
    phi[4,1]  R835      1.3797641992568970e+00
    phi[4,1]  R836      -2.3305485248565674e+00
    phi[4,1]  R837      7.7171194553375244e-01
    phi[4,1]  R838      -8.6895430088043213e-01
    phi[4,1]  R839      -9.6156805753707886e-01
    phi[4,1]  R840      -1.1809604167938232e+00
    phi[4,1]  R841      -6.4265263080596924e-01
    phi[4,1]  R842      -6.1832308769226074e-01
    phi[4,1]  R843      -9.5892304182052612e-01
    phi[4,1]  R844      2.3982904851436615e-01
    phi[4,1]  R845      4.9615317583084106e-01
    phi[4,1]  R846      1.3157655000686646e+00
    phi[4,1]  R847      -3.7837758660316467e-01
    phi[4,1]  R848      4.6028682589530945e-01
    phi[4,1]  R849      8.6851544678211212e-02
    phi[4,1]  R850      1.9838701486587524e+00
    phi[4,1]  R851      -1.3013432025909424e+00
    phi[4,1]  R852      4.5473405718803406e-01
    phi[4,1]  R853      7.7548170089721680e-01
    phi[4,1]  R854      6.9258832931518555e-01
    phi[4,1]  R855      -1.7963836193084717e+00
    phi[4,1]  R856      1.4050097763538361e-01
    phi[4,1]  R857      7.6795279979705811e-01
    phi[4,1]  R858      -2.5440546870231628e-01
    phi[4,1]  R859      -1.2351915836334229e+00
    phi[4,1]  R860      -1.1452368497848511e+00
    phi[4,1]  R861      -1.2558503150939941e+00
    phi[4,1]  R862      -1.0335665941238403e+00
    phi[4,1]  R863      2.3198740184307098e-01
    phi[4,1]  R864      -1.4644505977630615e+00
    phi[4,1]  R865      -1.5651099681854248e+00
    phi[4,1]  R866      1.4655187726020813e-01
    phi[4,1]  R867      -3.1656816005706787e+00
    phi[4,1]  R868      2.1129317581653595e-01
    phi[4,1]  R869      -1.0441242456436157e+00
    phi[4,1]  R870      1.6581664979457855e-01
    phi[4,1]  R871      -2.2550330162048340e+00
    phi[4,1]  R872      -6.5509945154190063e-01
    phi[4,1]  R873      -8.7992382049560547e-01
    phi[4,1]  R874      -8.8125973939895630e-01
    phi[4,1]  R875      -3.1579780578613281e+00
    phi[4,1]  R876      -9.1246563196182251e-01
    phi[4,1]  R877      -1.9587436318397522e-01
    phi[4,1]  R878      -3.0397663116455078e+00
    phi[1,5]  R9        1
    phi[1,5]  R10       1
    phi[1,5]  R45       -1
    phi[1,5]  R879      -3.0999999046325684e+00
    phi[1,5]  R880      -3.0999999046325684e+00
    phi[1,5]  R881      -2.2400000095367432e+00
    phi[1,5]  R882      -2.2400000095367432e+00
    phi[1,5]  R883      -3.0999999046325684e+00
    phi[1,5]  R884      -3.0999999046325684e+00
    phi[1,5]  R885      -2.5699999332427979e+00
    phi[1,5]  R886      -2.5699999332427979e+00
    phi[1,5]  R887      -3.0999999046325684e+00
    phi[1,5]  R888      -3.0999999046325684e+00
    phi[1,5]  R889      -2.0899999141693115e+00
    phi[1,5]  R890      -2.0899999141693115e+00
    phi[1,5]  R891      -3.0999999046325684e+00
    phi[1,5]  R892      -3.0999999046325684e+00
    phi[1,5]  R893      8.6851544678211212e-02
    phi[1,5]  R894      1.9838701486587524e+00
    phi[1,5]  R895      -1.3013432025909424e+00
    phi[1,5]  R896      4.5473405718803406e-01
    phi[1,5]  R897      7.7548170089721680e-01
    phi[1,5]  R898      6.9258832931518555e-01
    phi[1,5]  R899      -1.7963836193084717e+00
    phi[1,5]  R900      1.4050097763538361e-01
    phi[1,5]  R901      7.6795279979705811e-01
    phi[1,5]  R902      -2.5440546870231628e-01
    phi[1,5]  R903      -1.2351915836334229e+00
    phi[1,5]  R904      -1.1452368497848511e+00
    phi[1,5]  R905      -1.2558503150939941e+00
    phi[1,5]  R906      -1.0335665941238403e+00
    phi[1,5]  R907      2.3198740184307098e-01
    phi[1,5]  R908      -1.4644505977630615e+00
    phi[1,5]  R909      -1.5651099681854248e+00
    phi[1,5]  R910      1.4655187726020813e-01
    phi[1,5]  R911      -3.1656816005706787e+00
    phi[1,5]  R912      2.1129317581653595e-01
    phi[1,5]  R913      -1.0441242456436157e+00
    phi[1,5]  R914      1.6581664979457855e-01
    phi[1,5]  R915      -2.2550330162048340e+00
    phi[1,5]  R916      -6.5509945154190063e-01
    phi[1,5]  R917      -8.7992382049560547e-01
    phi[1,5]  R918      -8.8125973939895630e-01
    phi[1,5]  R919      -3.1579780578613281e+00
    phi[1,5]  R920      -9.1246563196182251e-01
    phi[1,5]  R921      -1.9587436318397522e-01
    phi[1,5]  R922      -3.0397663116455078e+00
    phi[1,5]  R923      1.8007920980453491e+00
    phi[1,5]  R924      6.4599418640136719e-01
    phi[1,5]  R925      2.2603318691253662e+00
    phi[1,5]  R926      1.7873261868953705e-01
    phi[1,5]  R927      2.2411823272705078e+00
    phi[1,5]  R928      7.2719532251358032e-01
    phi[1,5]  R929      -1.7080196142196655e+00
    phi[1,5]  R930      -2.2581880092620850e+00
    phi[1,5]  R931      -3.4046941995620728e-01
    phi[1,5]  R932      -5.4829396307468414e-02
    phi[1,5]  R933      -1.8441349267959595e+00
    phi[1,5]  R934      -2.0565166473388672e+00
    phi[1,5]  R935      -1.62327241897583
    phi[1,5]  R936      -2.4902718067169189e+00
    phi[1,5]  R937      -2.0668454170227051e+00
    phi[1,5]  R938      -0.446829229593277
    phi[1,5]  R939      -3.1041178107261658e-01
    phi[1,5]  R940      -2.4223685264587402e+00
    phi[1,5]  R941      -1.1626986414194107e-01
    phi[1,5]  R942      1.5148143470287323e-01
    phi[1,5]  R943      -9.9619424343109131e-01
    phi[1,5]  R944      -1.1306135654449463e+00
    phi[1,5]  R945      -1.1128909587860107e+00
    phi[1,5]  R946      -1.2805100679397583e+00
    phi[1,5]  R947      -2.0169441699981689e+00
    phi[1,5]  R948      -1.0042003393173218e+00
    phi[1,5]  R949      -2.0214745998382568e+00
    phi[1,5]  R950      -2.8233633041381836e+00
    phi[1,5]  R951      1.7531819641590118e-01
    phi[1,5]  R952      5.9440964460372925e-01
    phi[5,1]  R9        -1
    phi[5,1]  R45       1
    phi[5,1]  R46       1
    phi[5,1]  R953      -3.0999999046325684e+00
    phi[5,1]  R954      -3.0999999046325684e+00
    phi[5,1]  R955      -2.2400000095367432e+00
    phi[5,1]  R956      -2.2400000095367432e+00
    phi[5,1]  R957      -3.0999999046325684e+00
    phi[5,1]  R958      -3.0999999046325684e+00
    phi[5,1]  R959      -2.5699999332427979e+00
    phi[5,1]  R960      -2.5699999332427979e+00
    phi[5,1]  R961      -3.0999999046325684e+00
    phi[5,1]  R962      -3.0999999046325684e+00
    phi[5,1]  R963      -2.0899999141693115e+00
    phi[5,1]  R964      -2.0899999141693115e+00
    phi[5,1]  R965      -3.0999999046325684e+00
    phi[5,1]  R966      -3.0999999046325684e+00
    phi[5,1]  R967      1.8007920980453491e+00
    phi[5,1]  R968      6.4599418640136719e-01
    phi[5,1]  R969      2.2603318691253662e+00
    phi[5,1]  R970      1.7873261868953705e-01
    phi[5,1]  R971      2.2411823272705078e+00
    phi[5,1]  R972      7.2719532251358032e-01
    phi[5,1]  R973      -1.7080196142196655e+00
    phi[5,1]  R974      -2.2581880092620850e+00
    phi[5,1]  R975      -3.4046941995620728e-01
    phi[5,1]  R976      -5.4829396307468414e-02
    phi[5,1]  R977      -1.8441349267959595e+00
    phi[5,1]  R978      -2.0565166473388672e+00
    phi[5,1]  R979      -1.62327241897583
    phi[5,1]  R980      -2.4902718067169189e+00
    phi[5,1]  R981      -2.0668454170227051e+00
    phi[5,1]  R982      -0.446829229593277
    phi[5,1]  R983      -3.1041178107261658e-01
    phi[5,1]  R984      -2.4223685264587402e+00
    phi[5,1]  R985      -1.1626986414194107e-01
    phi[5,1]  R986      1.5148143470287323e-01
    phi[5,1]  R987      -9.9619424343109131e-01
    phi[5,1]  R988      -1.1306135654449463e+00
    phi[5,1]  R989      -1.1128909587860107e+00
    phi[5,1]  R990      -1.2805100679397583e+00
    phi[5,1]  R991      -2.0169441699981689e+00
    phi[5,1]  R992      -1.0042003393173218e+00
    phi[5,1]  R993      -2.0214745998382568e+00
    phi[5,1]  R994      -2.8233633041381836e+00
    phi[5,1]  R995      1.7531819641590118e-01
    phi[5,1]  R996      5.9440964460372925e-01
    phi[5,1]  R997      8.6851544678211212e-02
    phi[5,1]  R998      1.9838701486587524e+00
    phi[5,1]  R999      -1.3013432025909424e+00
    phi[5,1]  R1000     4.5473405718803406e-01
    phi[5,1]  R1001     7.7548170089721680e-01
    phi[5,1]  R1002     6.9258832931518555e-01
    phi[5,1]  R1003     -1.7963836193084717e+00
    phi[5,1]  R1004     1.4050097763538361e-01
    phi[5,1]  R1005     7.6795279979705811e-01
    phi[5,1]  R1006     -2.5440546870231628e-01
    phi[5,1]  R1007     -1.2351915836334229e+00
    phi[5,1]  R1008     -1.1452368497848511e+00
    phi[5,1]  R1009     -1.2558503150939941e+00
    phi[5,1]  R1010     -1.0335665941238403e+00
    phi[5,1]  R1011     2.3198740184307098e-01
    phi[5,1]  R1012     -1.4644505977630615e+00
    phi[5,1]  R1013     -1.5651099681854248e+00
    phi[5,1]  R1014     1.4655187726020813e-01
    phi[5,1]  R1015     -3.1656816005706787e+00
    phi[5,1]  R1016     2.1129317581653595e-01
    phi[5,1]  R1017     -1.0441242456436157e+00
    phi[5,1]  R1018     1.6581664979457855e-01
    phi[5,1]  R1019     -2.2550330162048340e+00
    phi[5,1]  R1020     -6.5509945154190063e-01
    phi[5,1]  R1021     -8.7992382049560547e-01
    phi[5,1]  R1022     -8.8125973939895630e-01
    phi[5,1]  R1023     -3.1579780578613281e+00
    phi[5,1]  R1024     -9.1246563196182251e-01
    phi[5,1]  R1025     -1.9587436318397522e-01
    phi[5,1]  R1026     -3.0397663116455078e+00
    phi[1,6]  R9        1
    phi[1,6]  R10       1
    phi[1,6]  R54       -1
    phi[1,6]  R1027     -3.0999999046325684e+00
    phi[1,6]  R1028     -3.0999999046325684e+00
    phi[1,6]  R1029     -2.2400000095367432e+00
    phi[1,6]  R1030     -2.2400000095367432e+00
    phi[1,6]  R1031     -3.0999999046325684e+00
    phi[1,6]  R1032     -3.0999999046325684e+00
    phi[1,6]  R1033     -2.5699999332427979e+00
    phi[1,6]  R1034     -2.5699999332427979e+00
    phi[1,6]  R1035     -3.0999999046325684e+00
    phi[1,6]  R1036     -3.0999999046325684e+00
    phi[1,6]  R1037     -2.0899999141693115e+00
    phi[1,6]  R1038     -2.0899999141693115e+00
    phi[1,6]  R1039     -3.0999999046325684e+00
    phi[1,6]  R1040     -3.0999999046325684e+00
    phi[1,6]  R1041     8.6851544678211212e-02
    phi[1,6]  R1042     1.9838701486587524e+00
    phi[1,6]  R1043     -1.3013432025909424e+00
    phi[1,6]  R1044     4.5473405718803406e-01
    phi[1,6]  R1045     7.7548170089721680e-01
    phi[1,6]  R1046     6.9258832931518555e-01
    phi[1,6]  R1047     -1.7963836193084717e+00
    phi[1,6]  R1048     1.4050097763538361e-01
    phi[1,6]  R1049     7.6795279979705811e-01
    phi[1,6]  R1050     -2.5440546870231628e-01
    phi[1,6]  R1051     -1.2351915836334229e+00
    phi[1,6]  R1052     -1.1452368497848511e+00
    phi[1,6]  R1053     -1.2558503150939941e+00
    phi[1,6]  R1054     -1.0335665941238403e+00
    phi[1,6]  R1055     2.3198740184307098e-01
    phi[1,6]  R1056     -1.4644505977630615e+00
    phi[1,6]  R1057     -1.5651099681854248e+00
    phi[1,6]  R1058     1.4655187726020813e-01
    phi[1,6]  R1059     -3.1656816005706787e+00
    phi[1,6]  R1060     2.1129317581653595e-01
    phi[1,6]  R1061     -1.0441242456436157e+00
    phi[1,6]  R1062     1.6581664979457855e-01
    phi[1,6]  R1063     -2.2550330162048340e+00
    phi[1,6]  R1064     -6.5509945154190063e-01
    phi[1,6]  R1065     -8.7992382049560547e-01
    phi[1,6]  R1066     -8.8125973939895630e-01
    phi[1,6]  R1067     -3.1579780578613281e+00
    phi[1,6]  R1068     -9.1246563196182251e-01
    phi[1,6]  R1069     -1.9587436318397522e-01
    phi[1,6]  R1070     -3.0397663116455078e+00
    phi[1,6]  R1071     1.7274820804595947e+00
    phi[1,6]  R1072     1.5270236730575562e+00
    phi[1,6]  R1073     2.1326994895935059e+00
    phi[1,6]  R1074     2.2672083377838135e+00
    phi[1,6]  R1075     -6.3488230109214783e-02
    phi[1,6]  R1076     0.908623993396759
    phi[1,6]  R1077     -2.7456244826316833e-01
    phi[1,6]  R1078     1.3411377668380737e+00
    phi[1,6]  R1079     5.5729693174362183e-01
    phi[1,6]  R1080     -2.1786594390869141e+00
    phi[1,6]  R1081     1.4492569863796234e-01
    phi[1,6]  R1082     -2.8861382007598877e+00
    phi[1,6]  R1083     -2.3819103240966797e+00
    phi[1,6]  R1084     -1.7536773681640625e+00
    phi[1,6]  R1085     -1.2884278297424316e+00
    phi[1,6]  R1086     -4.5313236117362976e-01
    phi[1,6]  R1087     -8.0924767255783081e-01
    phi[1,6]  R1088     -2.1314678192138672e+00
    phi[1,6]  R1089     0.443470299243927
    phi[1,6]  R1090     -5.5021989345550537e-01
    phi[6,1]  R9        -1
    phi[6,1]  R54       1
    phi[6,1]  R55       1
    phi[6,1]  R1091     -3.0999999046325684e+00
    phi[6,1]  R1092     -3.0999999046325684e+00
    phi[6,1]  R1093     -2.2400000095367432e+00
    phi[6,1]  R1094     -2.2400000095367432e+00
    phi[6,1]  R1095     -3.0999999046325684e+00
    phi[6,1]  R1096     -3.0999999046325684e+00
    phi[6,1]  R1097     -2.5699999332427979e+00
    phi[6,1]  R1098     -2.5699999332427979e+00
    phi[6,1]  R1099     -3.0999999046325684e+00
    phi[6,1]  R1100     -3.0999999046325684e+00
    phi[6,1]  R1101     -2.0899999141693115e+00
    phi[6,1]  R1102     -2.0899999141693115e+00
    phi[6,1]  R1103     -3.0999999046325684e+00
    phi[6,1]  R1104     -3.0999999046325684e+00
    phi[6,1]  R1105     1.7274820804595947e+00
    phi[6,1]  R1106     1.5270236730575562e+00
    phi[6,1]  R1107     2.1326994895935059e+00
    phi[6,1]  R1108     2.2672083377838135e+00
    phi[6,1]  R1109     -6.3488230109214783e-02
    phi[6,1]  R1110     0.908623993396759
    phi[6,1]  R1111     -2.7456244826316833e-01
    phi[6,1]  R1112     1.3411377668380737e+00
    phi[6,1]  R1113     5.5729693174362183e-01
    phi[6,1]  R1114     -2.1786594390869141e+00
    phi[6,1]  R1115     1.4492569863796234e-01
    phi[6,1]  R1116     -2.8861382007598877e+00
    phi[6,1]  R1117     -2.3819103240966797e+00
    phi[6,1]  R1118     -1.7536773681640625e+00
    phi[6,1]  R1119     -1.2884278297424316e+00
    phi[6,1]  R1120     -4.5313236117362976e-01
    phi[6,1]  R1121     -8.0924767255783081e-01
    phi[6,1]  R1122     -2.1314678192138672e+00
    phi[6,1]  R1123     0.443470299243927
    phi[6,1]  R1124     -5.5021989345550537e-01
    phi[6,1]  R1125     8.6851544678211212e-02
    phi[6,1]  R1126     1.9838701486587524e+00
    phi[6,1]  R1127     -1.3013432025909424e+00
    phi[6,1]  R1128     4.5473405718803406e-01
    phi[6,1]  R1129     7.7548170089721680e-01
    phi[6,1]  R1130     6.9258832931518555e-01
    phi[6,1]  R1131     -1.7963836193084717e+00
    phi[6,1]  R1132     1.4050097763538361e-01
    phi[6,1]  R1133     7.6795279979705811e-01
    phi[6,1]  R1134     -2.5440546870231628e-01
    phi[6,1]  R1135     -1.2351915836334229e+00
    phi[6,1]  R1136     -1.1452368497848511e+00
    phi[6,1]  R1137     -1.2558503150939941e+00
    phi[6,1]  R1138     -1.0335665941238403e+00
    phi[6,1]  R1139     2.3198740184307098e-01
    phi[6,1]  R1140     -1.4644505977630615e+00
    phi[6,1]  R1141     -1.5651099681854248e+00
    phi[6,1]  R1142     1.4655187726020813e-01
    phi[6,1]  R1143     -3.1656816005706787e+00
    phi[6,1]  R1144     2.1129317581653595e-01
    phi[6,1]  R1145     -1.0441242456436157e+00
    phi[6,1]  R1146     1.6581664979457855e-01
    phi[6,1]  R1147     -2.2550330162048340e+00
    phi[6,1]  R1148     -6.5509945154190063e-01
    phi[6,1]  R1149     -8.7992382049560547e-01
    phi[6,1]  R1150     -8.8125973939895630e-01
    phi[6,1]  R1151     -3.1579780578613281e+00
    phi[6,1]  R1152     -9.1246563196182251e-01
    phi[6,1]  R1153     -1.9587436318397522e-01
    phi[6,1]  R1154     -3.0397663116455078e+00
    phi[2,4]  R18       1
    phi[2,4]  R19       1
    phi[2,4]  R36       -1
    phi[2,4]  R1155     -3.0999999046325684e+00
    phi[2,4]  R1156     -3.0999999046325684e+00
    phi[2,4]  R1157     -2.2400000095367432e+00
    phi[2,4]  R1158     -2.2400000095367432e+00
    phi[2,4]  R1159     -3.0999999046325684e+00
    phi[2,4]  R1160     -3.0999999046325684e+00
    phi[2,4]  R1161     -2.5699999332427979e+00
    phi[2,4]  R1162     -2.5699999332427979e+00
    phi[2,4]  R1163     -3.0999999046325684e+00
    phi[2,4]  R1164     -3.0999999046325684e+00
    phi[2,4]  R1165     -2.0899999141693115e+00
    phi[2,4]  R1166     -2.0899999141693115e+00
    phi[2,4]  R1167     -3.0999999046325684e+00
    phi[2,4]  R1168     -3.0999999046325684e+00
    phi[2,4]  R1169     1.6060771942138672e+00
    phi[2,4]  R1170     1.8287003040313721e+00
    phi[2,4]  R1171     1.1677653789520264e+00
    phi[2,4]  R1172     4.5427301526069641e-01
    phi[2,4]  R1173     6.5305948257446289e-01
    phi[2,4]  R1174     0.707932710647583
    phi[2,4]  R1175     1.2563668489456177e+00
    phi[2,4]  R1176     1.9391212463378906e+00
    phi[2,4]  R1177     1.8411041498184204e+00
    phi[2,4]  R1178     1.4448857307434082e+00
    phi[2,4]  R1179     -1.6837440729141235e+00
    phi[2,4]  R1180     -1.1147780418395996e+00
    phi[2,4]  R1181     -2.1535389423370361e+00
    phi[2,4]  R1182     -2.4632074832916260e+00
    phi[2,4]  R1183     -2.4386303424835205e+00
    phi[2,4]  R1184     -3.1069284677505493e-01
    phi[2,4]  R1185     -2.1550416946411133e+00
    phi[2,4]  R1186     -1.0178964138031006e+00
    phi[2,4]  R1187     -1.7698980569839478e+00
    phi[2,4]  R1188     -3.2427403926849365e+00
    phi[2,4]  R1189     1.4479906558990479e+00
    phi[2,4]  R1190     7.1615827083587646e-01
    phi[2,4]  R1191     -8.5022526979446411e-01
    phi[2,4]  R1192     -1.0141491144895554e-01
    phi[2,4]  R1193     -3.9661136269569397e-01
    phi[2,4]  R1194     -1.4362233877182007e-01
    phi[2,4]  R1195     6.4183771610260010e-01
    phi[2,4]  R1196     -1.1017217636108398e+00
    phi[2,4]  R1197     -3.2558679580688477e-01
    phi[2,4]  R1198     1.2046914100646973e+00
    phi[2,4]  R1199     -1.5689424276351929e+00
    phi[2,4]  R1200     -2.8515503406524658e+00
    phi[2,4]  R1201     -2.4241050705313683e-02
    phi[2,4]  R1202     1.1722551584243774e+00
    phi[2,4]  R1203     6.6547647118568420e-02
    phi[2,4]  R1204     -4.1880190372467041e-01
    phi[2,4]  R1205     1.6503981351852417e+00
    phi[2,4]  R1206     1.7493067979812622e+00
    phi[2,4]  R1207     0.419420450925827
    phi[2,4]  R1208     0.867963969707489
    phi[2,4]  R1209     0.0363311693072319
    phi[2,4]  R1210     -8.4838904440402985e-02
    phi[2,4]  R1211     -1.3639408349990845e+00
    phi[2,4]  R1212     -5.0670862197875977e-02
    phi[2,4]  R1213     -1.8000050783157349e+00
    phi[2,4]  R1214     -1.7321132421493530e+00
    phi[2,4]  R1215     -4.8732721805572510e-01
    phi[2,4]  R1216     -1.9447910785675049e+00
    phi[2,4]  R1217     1.9736206531524658e+00
    phi[2,4]  R1218     1.5280526876449585e-01
    phi[2,4]  R1219     -4.5784822106361389e-01
    phi[2,4]  R1220     -2.9499703645706177e-01
    phi[2,4]  R1221     -1.0516991615295410e+00
    phi[2,4]  R1222     -2.5301668643951416e+00
    phi[2,4]  R1223     1.0645778179168701e+00
    phi[2,4]  R1224     -1.0650328397750854e+00
    phi[2,4]  R1225     -8.1583850085735321e-02
    phi[2,4]  R1226     -1.1857541799545288e+00
    phi[2,4]  R1227     -2.9100706577301025e+00
    phi[2,4]  R1228     -2.2868428230285645e+00
    phi[2,4]  R1229     -9.1827267408370972e-01
    phi[2,4]  R1230     -3.7565183639526367e-01
    phi[2,4]  R1231     1.4464820921421051e-01
    phi[2,4]  R1232     -0.792131781578064
    phi[2,4]  R1233     -1.1212884187698364e+00
    phi[2,4]  R1234     -7.6836013793945312e-01
    phi[2,4]  R1235     5.0052696466445923e-01
    phi[2,4]  R1236     -1.0866140127182007e+00
    phi[2,4]  R1237     -3.7080189585685730e-01
    phi[2,4]  R1238     -5.2885800600051880e-01
    phi[2,4]  R1239     -1.9754477739334106e+00
    phi[2,4]  R1240     -1.8062031269073486e-01
    phi[2,4]  R1241     -7.9203057289123535e-01
    phi[2,4]  R1242     -0.6389120221138
    phi[2,4]  R1243     -0.89692223072052
    phi[2,4]  R1244     -3.9350599050521851e-02
    phi[2,4]  R1245     7.7230364084243774e-02
    phi[2,4]  R1246     -1.0600973367691040e+00
    phi[2,4]  R1247     -1.1978632211685181e+00
    phi[2,4]  R1248     0.80079585313797
    phi[2,4]  R1249     -7.3709380626678467e-01
    phi[2,4]  R1250     -2.9536029696464539e-01
    phi[2,4]  R1251     2.3081381618976593e-01
    phi[2,4]  R1252     -1.7289516925811768e+00
    phi[2,4]  R1253     7.9319781064987183e-01
    phi[2,4]  R1254     -9.4018924236297607e-01
    phi[2,4]  R1255     1.3797641992568970e+00
    phi[2,4]  R1256     -2.3305485248565674e+00
    phi[2,4]  R1257     7.7171194553375244e-01
    phi[2,4]  R1258     -8.6895430088043213e-01
    phi[2,4]  R1259     -9.6156805753707886e-01
    phi[2,4]  R1260     -1.1809604167938232e+00
    phi[2,4]  R1261     -6.4265263080596924e-01
    phi[2,4]  R1262     -6.1832308769226074e-01
    phi[2,4]  R1263     -9.5892304182052612e-01
    phi[2,4]  R1264     2.3982904851436615e-01
    phi[2,4]  R1265     4.9615317583084106e-01
    phi[2,4]  R1266     1.3157655000686646e+00
    phi[2,4]  R1267     -3.7837758660316467e-01
    phi[2,4]  R1268     4.6028682589530945e-01
    phi[4,2]  R18       -1
    phi[4,2]  R36       1
    phi[4,2]  R37       1
    phi[4,2]  R1269     -3.0999999046325684e+00
    phi[4,2]  R1270     -3.0999999046325684e+00
    phi[4,2]  R1271     -2.2400000095367432e+00
    phi[4,2]  R1272     -2.2400000095367432e+00
    phi[4,2]  R1273     -3.0999999046325684e+00
    phi[4,2]  R1274     -3.0999999046325684e+00
    phi[4,2]  R1275     -2.5699999332427979e+00
    phi[4,2]  R1276     -2.5699999332427979e+00
    phi[4,2]  R1277     -3.0999999046325684e+00
    phi[4,2]  R1278     -3.0999999046325684e+00
    phi[4,2]  R1279     -2.0899999141693115e+00
    phi[4,2]  R1280     -2.0899999141693115e+00
    phi[4,2]  R1281     -3.0999999046325684e+00
    phi[4,2]  R1282     -3.0999999046325684e+00
    phi[4,2]  R1283     -4.5784822106361389e-01
    phi[4,2]  R1284     -2.9499703645706177e-01
    phi[4,2]  R1285     -1.0516991615295410e+00
    phi[4,2]  R1286     -2.5301668643951416e+00
    phi[4,2]  R1287     1.0645778179168701e+00
    phi[4,2]  R1288     -1.0650328397750854e+00
    phi[4,2]  R1289     -8.1583850085735321e-02
    phi[4,2]  R1290     -1.1857541799545288e+00
    phi[4,2]  R1291     -2.9100706577301025e+00
    phi[4,2]  R1292     -2.2868428230285645e+00
    phi[4,2]  R1293     -9.1827267408370972e-01
    phi[4,2]  R1294     -3.7565183639526367e-01
    phi[4,2]  R1295     1.4464820921421051e-01
    phi[4,2]  R1296     -0.792131781578064
    phi[4,2]  R1297     -1.1212884187698364e+00
    phi[4,2]  R1298     -7.6836013793945312e-01
    phi[4,2]  R1299     5.0052696466445923e-01
    phi[4,2]  R1300     -1.0866140127182007e+00
    phi[4,2]  R1301     -3.7080189585685730e-01
    phi[4,2]  R1302     -5.2885800600051880e-01
    phi[4,2]  R1303     -1.9754477739334106e+00
    phi[4,2]  R1304     -1.8062031269073486e-01
    phi[4,2]  R1305     -7.9203057289123535e-01
    phi[4,2]  R1306     -0.6389120221138
    phi[4,2]  R1307     -0.89692223072052
    phi[4,2]  R1308     -3.9350599050521851e-02
    phi[4,2]  R1309     7.7230364084243774e-02
    phi[4,2]  R1310     -1.0600973367691040e+00
    phi[4,2]  R1311     -1.1978632211685181e+00
    phi[4,2]  R1312     0.80079585313797
    phi[4,2]  R1313     -7.3709380626678467e-01
    phi[4,2]  R1314     -2.9536029696464539e-01
    phi[4,2]  R1315     2.3081381618976593e-01
    phi[4,2]  R1316     -1.7289516925811768e+00
    phi[4,2]  R1317     7.9319781064987183e-01
    phi[4,2]  R1318     -9.4018924236297607e-01
    phi[4,2]  R1319     1.3797641992568970e+00
    phi[4,2]  R1320     -2.3305485248565674e+00
    phi[4,2]  R1321     7.7171194553375244e-01
    phi[4,2]  R1322     -8.6895430088043213e-01
    phi[4,2]  R1323     -9.6156805753707886e-01
    phi[4,2]  R1324     -1.1809604167938232e+00
    phi[4,2]  R1325     -6.4265263080596924e-01
    phi[4,2]  R1326     -6.1832308769226074e-01
    phi[4,2]  R1327     -9.5892304182052612e-01
    phi[4,2]  R1328     2.3982904851436615e-01
    phi[4,2]  R1329     4.9615317583084106e-01
    phi[4,2]  R1330     1.3157655000686646e+00
    phi[4,2]  R1331     -3.7837758660316467e-01
    phi[4,2]  R1332     4.6028682589530945e-01
    phi[4,2]  R1333     1.6060771942138672e+00
    phi[4,2]  R1334     1.8287003040313721e+00
    phi[4,2]  R1335     1.1677653789520264e+00
    phi[4,2]  R1336     4.5427301526069641e-01
    phi[4,2]  R1337     6.5305948257446289e-01
    phi[4,2]  R1338     0.707932710647583
    phi[4,2]  R1339     1.2563668489456177e+00
    phi[4,2]  R1340     1.9391212463378906e+00
    phi[4,2]  R1341     1.8411041498184204e+00
    phi[4,2]  R1342     1.4448857307434082e+00
    phi[4,2]  R1343     -1.6837440729141235e+00
    phi[4,2]  R1344     -1.1147780418395996e+00
    phi[4,2]  R1345     -2.1535389423370361e+00
    phi[4,2]  R1346     -2.4632074832916260e+00
    phi[4,2]  R1347     -2.4386303424835205e+00
    phi[4,2]  R1348     -3.1069284677505493e-01
    phi[4,2]  R1349     -2.1550416946411133e+00
    phi[4,2]  R1350     -1.0178964138031006e+00
    phi[4,2]  R1351     -1.7698980569839478e+00
    phi[4,2]  R1352     -3.2427403926849365e+00
    phi[4,2]  R1353     1.4479906558990479e+00
    phi[4,2]  R1354     7.1615827083587646e-01
    phi[4,2]  R1355     -8.5022526979446411e-01
    phi[4,2]  R1356     -1.0141491144895554e-01
    phi[4,2]  R1357     -3.9661136269569397e-01
    phi[4,2]  R1358     -1.4362233877182007e-01
    phi[4,2]  R1359     6.4183771610260010e-01
    phi[4,2]  R1360     -1.1017217636108398e+00
    phi[4,2]  R1361     -3.2558679580688477e-01
    phi[4,2]  R1362     1.2046914100646973e+00
    phi[4,2]  R1363     -1.5689424276351929e+00
    phi[4,2]  R1364     -2.8515503406524658e+00
    phi[4,2]  R1365     -2.4241050705313683e-02
    phi[4,2]  R1366     1.1722551584243774e+00
    phi[4,2]  R1367     6.6547647118568420e-02
    phi[4,2]  R1368     -4.1880190372467041e-01
    phi[4,2]  R1369     1.6503981351852417e+00
    phi[4,2]  R1370     1.7493067979812622e+00
    phi[4,2]  R1371     0.419420450925827
    phi[4,2]  R1372     0.867963969707489
    phi[4,2]  R1373     0.0363311693072319
    phi[4,2]  R1374     -8.4838904440402985e-02
    phi[4,2]  R1375     -1.3639408349990845e+00
    phi[4,2]  R1376     -5.0670862197875977e-02
    phi[4,2]  R1377     -1.8000050783157349e+00
    phi[4,2]  R1378     -1.7321132421493530e+00
    phi[4,2]  R1379     -4.8732721805572510e-01
    phi[4,2]  R1380     -1.9447910785675049e+00
    phi[4,2]  R1381     1.9736206531524658e+00
    phi[4,2]  R1382     1.5280526876449585e-01
    phi[2,5]  R18       1
    phi[2,5]  R19       1
    phi[2,5]  R45       -1
    phi[2,5]  R1383     -3.0999999046325684e+00
    phi[2,5]  R1384     -3.0999999046325684e+00
    phi[2,5]  R1385     -2.2400000095367432e+00
    phi[2,5]  R1386     -2.2400000095367432e+00
    phi[2,5]  R1387     -3.0999999046325684e+00
    phi[2,5]  R1388     -3.0999999046325684e+00
    phi[2,5]  R1389     -2.5699999332427979e+00
    phi[2,5]  R1390     -2.5699999332427979e+00
    phi[2,5]  R1391     -3.0999999046325684e+00
    phi[2,5]  R1392     -3.0999999046325684e+00
    phi[2,5]  R1393     -2.0899999141693115e+00
    phi[2,5]  R1394     -2.0899999141693115e+00
    phi[2,5]  R1395     -3.0999999046325684e+00
    phi[2,5]  R1396     -3.0999999046325684e+00
    phi[2,5]  R1397     1.6060771942138672e+00
    phi[2,5]  R1398     1.8287003040313721e+00
    phi[2,5]  R1399     1.1677653789520264e+00
    phi[2,5]  R1400     4.5427301526069641e-01
    phi[2,5]  R1401     6.5305948257446289e-01
    phi[2,5]  R1402     0.707932710647583
    phi[2,5]  R1403     1.2563668489456177e+00
    phi[2,5]  R1404     1.9391212463378906e+00
    phi[2,5]  R1405     1.8411041498184204e+00
    phi[2,5]  R1406     1.4448857307434082e+00
    phi[2,5]  R1407     -1.6837440729141235e+00
    phi[2,5]  R1408     -1.1147780418395996e+00
    phi[2,5]  R1409     -2.1535389423370361e+00
    phi[2,5]  R1410     -2.4632074832916260e+00
    phi[2,5]  R1411     -2.4386303424835205e+00
    phi[2,5]  R1412     -3.1069284677505493e-01
    phi[2,5]  R1413     -2.1550416946411133e+00
    phi[2,5]  R1414     -1.0178964138031006e+00
    phi[2,5]  R1415     -1.7698980569839478e+00
    phi[2,5]  R1416     -3.2427403926849365e+00
    phi[2,5]  R1417     1.4479906558990479e+00
    phi[2,5]  R1418     7.1615827083587646e-01
    phi[2,5]  R1419     -8.5022526979446411e-01
    phi[2,5]  R1420     -1.0141491144895554e-01
    phi[2,5]  R1421     -3.9661136269569397e-01
    phi[2,5]  R1422     -1.4362233877182007e-01
    phi[2,5]  R1423     6.4183771610260010e-01
    phi[2,5]  R1424     -1.1017217636108398e+00
    phi[2,5]  R1425     -3.2558679580688477e-01
    phi[2,5]  R1426     1.2046914100646973e+00
    phi[2,5]  R1427     -1.5689424276351929e+00
    phi[2,5]  R1428     -2.8515503406524658e+00
    phi[2,5]  R1429     -2.4241050705313683e-02
    phi[2,5]  R1430     1.1722551584243774e+00
    phi[2,5]  R1431     6.6547647118568420e-02
    phi[2,5]  R1432     -4.1880190372467041e-01
    phi[2,5]  R1433     1.6503981351852417e+00
    phi[2,5]  R1434     1.7493067979812622e+00
    phi[2,5]  R1435     0.419420450925827
    phi[2,5]  R1436     0.867963969707489
    phi[2,5]  R1437     0.0363311693072319
    phi[2,5]  R1438     -8.4838904440402985e-02
    phi[2,5]  R1439     -1.3639408349990845e+00
    phi[2,5]  R1440     -5.0670862197875977e-02
    phi[2,5]  R1441     -1.8000050783157349e+00
    phi[2,5]  R1442     -1.7321132421493530e+00
    phi[2,5]  R1443     -4.8732721805572510e-01
    phi[2,5]  R1444     -1.9447910785675049e+00
    phi[2,5]  R1445     1.9736206531524658e+00
    phi[2,5]  R1446     1.5280526876449585e-01
    phi[2,5]  R1447     1.8007920980453491e+00
    phi[2,5]  R1448     6.4599418640136719e-01
    phi[2,5]  R1449     2.2603318691253662e+00
    phi[2,5]  R1450     1.7873261868953705e-01
    phi[2,5]  R1451     2.2411823272705078e+00
    phi[2,5]  R1452     7.2719532251358032e-01
    phi[2,5]  R1453     -1.7080196142196655e+00
    phi[2,5]  R1454     -2.2581880092620850e+00
    phi[2,5]  R1455     -3.4046941995620728e-01
    phi[2,5]  R1456     -5.4829396307468414e-02
    phi[2,5]  R1457     -1.8441349267959595e+00
    phi[2,5]  R1458     -2.0565166473388672e+00
    phi[2,5]  R1459     -1.62327241897583
    phi[2,5]  R1460     -2.4902718067169189e+00
    phi[2,5]  R1461     -2.0668454170227051e+00
    phi[2,5]  R1462     -0.446829229593277
    phi[2,5]  R1463     -3.1041178107261658e-01
    phi[2,5]  R1464     -2.4223685264587402e+00
    phi[2,5]  R1465     -1.1626986414194107e-01
    phi[2,5]  R1466     1.5148143470287323e-01
    phi[2,5]  R1467     -9.9619424343109131e-01
    phi[2,5]  R1468     -1.1306135654449463e+00
    phi[2,5]  R1469     -1.1128909587860107e+00
    phi[2,5]  R1470     -1.2805100679397583e+00
    phi[2,5]  R1471     -2.0169441699981689e+00
    phi[2,5]  R1472     -1.0042003393173218e+00
    phi[2,5]  R1473     -2.0214745998382568e+00
    phi[2,5]  R1474     -2.8233633041381836e+00
    phi[2,5]  R1475     1.7531819641590118e-01
    phi[2,5]  R1476     5.9440964460372925e-01
    phi[5,2]  R18       -1
    phi[5,2]  R45       1
    phi[5,2]  R46       1
    phi[5,2]  R1477     -3.0999999046325684e+00
    phi[5,2]  R1478     -3.0999999046325684e+00
    phi[5,2]  R1479     -2.2400000095367432e+00
    phi[5,2]  R1480     -2.2400000095367432e+00
    phi[5,2]  R1481     -3.0999999046325684e+00
    phi[5,2]  R1482     -3.0999999046325684e+00
    phi[5,2]  R1483     -2.5699999332427979e+00
    phi[5,2]  R1484     -2.5699999332427979e+00
    phi[5,2]  R1485     -3.0999999046325684e+00
    phi[5,2]  R1486     -3.0999999046325684e+00
    phi[5,2]  R1487     -2.0899999141693115e+00
    phi[5,2]  R1488     -2.0899999141693115e+00
    phi[5,2]  R1489     -3.0999999046325684e+00
    phi[5,2]  R1490     -3.0999999046325684e+00
    phi[5,2]  R1491     1.8007920980453491e+00
    phi[5,2]  R1492     6.4599418640136719e-01
    phi[5,2]  R1493     2.2603318691253662e+00
    phi[5,2]  R1494     1.7873261868953705e-01
    phi[5,2]  R1495     2.2411823272705078e+00
    phi[5,2]  R1496     7.2719532251358032e-01
    phi[5,2]  R1497     -1.7080196142196655e+00
    phi[5,2]  R1498     -2.2581880092620850e+00
    phi[5,2]  R1499     -3.4046941995620728e-01
    phi[5,2]  R1500     -5.4829396307468414e-02
    phi[5,2]  R1501     -1.8441349267959595e+00
    phi[5,2]  R1502     -2.0565166473388672e+00
    phi[5,2]  R1503     -1.62327241897583
    phi[5,2]  R1504     -2.4902718067169189e+00
    phi[5,2]  R1505     -2.0668454170227051e+00
    phi[5,2]  R1506     -0.446829229593277
    phi[5,2]  R1507     -3.1041178107261658e-01
    phi[5,2]  R1508     -2.4223685264587402e+00
    phi[5,2]  R1509     -1.1626986414194107e-01
    phi[5,2]  R1510     1.5148143470287323e-01
    phi[5,2]  R1511     -9.9619424343109131e-01
    phi[5,2]  R1512     -1.1306135654449463e+00
    phi[5,2]  R1513     -1.1128909587860107e+00
    phi[5,2]  R1514     -1.2805100679397583e+00
    phi[5,2]  R1515     -2.0169441699981689e+00
    phi[5,2]  R1516     -1.0042003393173218e+00
    phi[5,2]  R1517     -2.0214745998382568e+00
    phi[5,2]  R1518     -2.8233633041381836e+00
    phi[5,2]  R1519     1.7531819641590118e-01
    phi[5,2]  R1520     5.9440964460372925e-01
    phi[5,2]  R1521     1.6060771942138672e+00
    phi[5,2]  R1522     1.8287003040313721e+00
    phi[5,2]  R1523     1.1677653789520264e+00
    phi[5,2]  R1524     4.5427301526069641e-01
    phi[5,2]  R1525     6.5305948257446289e-01
    phi[5,2]  R1526     0.707932710647583
    phi[5,2]  R1527     1.2563668489456177e+00
    phi[5,2]  R1528     1.9391212463378906e+00
    phi[5,2]  R1529     1.8411041498184204e+00
    phi[5,2]  R1530     1.4448857307434082e+00
    phi[5,2]  R1531     -1.6837440729141235e+00
    phi[5,2]  R1532     -1.1147780418395996e+00
    phi[5,2]  R1533     -2.1535389423370361e+00
    phi[5,2]  R1534     -2.4632074832916260e+00
    phi[5,2]  R1535     -2.4386303424835205e+00
    phi[5,2]  R1536     -3.1069284677505493e-01
    phi[5,2]  R1537     -2.1550416946411133e+00
    phi[5,2]  R1538     -1.0178964138031006e+00
    phi[5,2]  R1539     -1.7698980569839478e+00
    phi[5,2]  R1540     -3.2427403926849365e+00
    phi[5,2]  R1541     1.4479906558990479e+00
    phi[5,2]  R1542     7.1615827083587646e-01
    phi[5,2]  R1543     -8.5022526979446411e-01
    phi[5,2]  R1544     -1.0141491144895554e-01
    phi[5,2]  R1545     -3.9661136269569397e-01
    phi[5,2]  R1546     -1.4362233877182007e-01
    phi[5,2]  R1547     6.4183771610260010e-01
    phi[5,2]  R1548     -1.1017217636108398e+00
    phi[5,2]  R1549     -3.2558679580688477e-01
    phi[5,2]  R1550     1.2046914100646973e+00
    phi[5,2]  R1551     -1.5689424276351929e+00
    phi[5,2]  R1552     -2.8515503406524658e+00
    phi[5,2]  R1553     -2.4241050705313683e-02
    phi[5,2]  R1554     1.1722551584243774e+00
    phi[5,2]  R1555     6.6547647118568420e-02
    phi[5,2]  R1556     -4.1880190372467041e-01
    phi[5,2]  R1557     1.6503981351852417e+00
    phi[5,2]  R1558     1.7493067979812622e+00
    phi[5,2]  R1559     0.419420450925827
    phi[5,2]  R1560     0.867963969707489
    phi[5,2]  R1561     0.0363311693072319
    phi[5,2]  R1562     -8.4838904440402985e-02
    phi[5,2]  R1563     -1.3639408349990845e+00
    phi[5,2]  R1564     -5.0670862197875977e-02
    phi[5,2]  R1565     -1.8000050783157349e+00
    phi[5,2]  R1566     -1.7321132421493530e+00
    phi[5,2]  R1567     -4.8732721805572510e-01
    phi[5,2]  R1568     -1.9447910785675049e+00
    phi[5,2]  R1569     1.9736206531524658e+00
    phi[5,2]  R1570     1.5280526876449585e-01
    phi[2,6]  R18       1
    phi[2,6]  R19       1
    phi[2,6]  R54       -1
    phi[2,6]  R1571     -3.0999999046325684e+00
    phi[2,6]  R1572     -3.0999999046325684e+00
    phi[2,6]  R1573     -2.2400000095367432e+00
    phi[2,6]  R1574     -2.2400000095367432e+00
    phi[2,6]  R1575     -3.0999999046325684e+00
    phi[2,6]  R1576     -3.0999999046325684e+00
    phi[2,6]  R1577     -2.5699999332427979e+00
    phi[2,6]  R1578     -2.5699999332427979e+00
    phi[2,6]  R1579     -3.0999999046325684e+00
    phi[2,6]  R1580     -3.0999999046325684e+00
    phi[2,6]  R1581     -2.0899999141693115e+00
    phi[2,6]  R1582     -2.0899999141693115e+00
    phi[2,6]  R1583     -3.0999999046325684e+00
    phi[2,6]  R1584     -3.0999999046325684e+00
    phi[2,6]  R1585     1.6060771942138672e+00
    phi[2,6]  R1586     1.8287003040313721e+00
    phi[2,6]  R1587     1.1677653789520264e+00
    phi[2,6]  R1588     4.5427301526069641e-01
    phi[2,6]  R1589     6.5305948257446289e-01
    phi[2,6]  R1590     0.707932710647583
    phi[2,6]  R1591     1.2563668489456177e+00
    phi[2,6]  R1592     1.9391212463378906e+00
    phi[2,6]  R1593     1.8411041498184204e+00
    phi[2,6]  R1594     1.4448857307434082e+00
    phi[2,6]  R1595     -1.6837440729141235e+00
    phi[2,6]  R1596     -1.1147780418395996e+00
    phi[2,6]  R1597     -2.1535389423370361e+00
    phi[2,6]  R1598     -2.4632074832916260e+00
    phi[2,6]  R1599     -2.4386303424835205e+00
    phi[2,6]  R1600     -3.1069284677505493e-01
    phi[2,6]  R1601     -2.1550416946411133e+00
    phi[2,6]  R1602     -1.0178964138031006e+00
    phi[2,6]  R1603     -1.7698980569839478e+00
    phi[2,6]  R1604     -3.2427403926849365e+00
    phi[2,6]  R1605     1.4479906558990479e+00
    phi[2,6]  R1606     7.1615827083587646e-01
    phi[2,6]  R1607     -8.5022526979446411e-01
    phi[2,6]  R1608     -1.0141491144895554e-01
    phi[2,6]  R1609     -3.9661136269569397e-01
    phi[2,6]  R1610     -1.4362233877182007e-01
    phi[2,6]  R1611     6.4183771610260010e-01
    phi[2,6]  R1612     -1.1017217636108398e+00
    phi[2,6]  R1613     -3.2558679580688477e-01
    phi[2,6]  R1614     1.2046914100646973e+00
    phi[2,6]  R1615     -1.5689424276351929e+00
    phi[2,6]  R1616     -2.8515503406524658e+00
    phi[2,6]  R1617     -2.4241050705313683e-02
    phi[2,6]  R1618     1.1722551584243774e+00
    phi[2,6]  R1619     6.6547647118568420e-02
    phi[2,6]  R1620     -4.1880190372467041e-01
    phi[2,6]  R1621     1.6503981351852417e+00
    phi[2,6]  R1622     1.7493067979812622e+00
    phi[2,6]  R1623     0.419420450925827
    phi[2,6]  R1624     0.867963969707489
    phi[2,6]  R1625     0.0363311693072319
    phi[2,6]  R1626     -8.4838904440402985e-02
    phi[2,6]  R1627     -1.3639408349990845e+00
    phi[2,6]  R1628     -5.0670862197875977e-02
    phi[2,6]  R1629     -1.8000050783157349e+00
    phi[2,6]  R1630     -1.7321132421493530e+00
    phi[2,6]  R1631     -4.8732721805572510e-01
    phi[2,6]  R1632     -1.9447910785675049e+00
    phi[2,6]  R1633     1.9736206531524658e+00
    phi[2,6]  R1634     1.5280526876449585e-01
    phi[2,6]  R1635     1.7274820804595947e+00
    phi[2,6]  R1636     1.5270236730575562e+00
    phi[2,6]  R1637     2.1326994895935059e+00
    phi[2,6]  R1638     2.2672083377838135e+00
    phi[2,6]  R1639     -6.3488230109214783e-02
    phi[2,6]  R1640     0.908623993396759
    phi[2,6]  R1641     -2.7456244826316833e-01
    phi[2,6]  R1642     1.3411377668380737e+00
    phi[2,6]  R1643     5.5729693174362183e-01
    phi[2,6]  R1644     -2.1786594390869141e+00
    phi[2,6]  R1645     1.4492569863796234e-01
    phi[2,6]  R1646     -2.8861382007598877e+00
    phi[2,6]  R1647     -2.3819103240966797e+00
    phi[2,6]  R1648     -1.7536773681640625e+00
    phi[2,6]  R1649     -1.2884278297424316e+00
    phi[2,6]  R1650     -4.5313236117362976e-01
    phi[2,6]  R1651     -8.0924767255783081e-01
    phi[2,6]  R1652     -2.1314678192138672e+00
    phi[2,6]  R1653     0.443470299243927
    phi[2,6]  R1654     -5.5021989345550537e-01
    phi[6,2]  R18       -1
    phi[6,2]  R54       1
    phi[6,2]  R55       1
    phi[6,2]  R1655     -3.0999999046325684e+00
    phi[6,2]  R1656     -3.0999999046325684e+00
    phi[6,2]  R1657     -2.2400000095367432e+00
    phi[6,2]  R1658     -2.2400000095367432e+00
    phi[6,2]  R1659     -3.0999999046325684e+00
    phi[6,2]  R1660     -3.0999999046325684e+00
    phi[6,2]  R1661     -2.5699999332427979e+00
    phi[6,2]  R1662     -2.5699999332427979e+00
    phi[6,2]  R1663     -3.0999999046325684e+00
    phi[6,2]  R1664     -3.0999999046325684e+00
    phi[6,2]  R1665     -2.0899999141693115e+00
    phi[6,2]  R1666     -2.0899999141693115e+00
    phi[6,2]  R1667     -3.0999999046325684e+00
    phi[6,2]  R1668     -3.0999999046325684e+00
    phi[6,2]  R1669     1.7274820804595947e+00
    phi[6,2]  R1670     1.5270236730575562e+00
    phi[6,2]  R1671     2.1326994895935059e+00
    phi[6,2]  R1672     2.2672083377838135e+00
    phi[6,2]  R1673     -6.3488230109214783e-02
    phi[6,2]  R1674     0.908623993396759
    phi[6,2]  R1675     -2.7456244826316833e-01
    phi[6,2]  R1676     1.3411377668380737e+00
    phi[6,2]  R1677     5.5729693174362183e-01
    phi[6,2]  R1678     -2.1786594390869141e+00
    phi[6,2]  R1679     1.4492569863796234e-01
    phi[6,2]  R1680     -2.8861382007598877e+00
    phi[6,2]  R1681     -2.3819103240966797e+00
    phi[6,2]  R1682     -1.7536773681640625e+00
    phi[6,2]  R1683     -1.2884278297424316e+00
    phi[6,2]  R1684     -4.5313236117362976e-01
    phi[6,2]  R1685     -8.0924767255783081e-01
    phi[6,2]  R1686     -2.1314678192138672e+00
    phi[6,2]  R1687     0.443470299243927
    phi[6,2]  R1688     -5.5021989345550537e-01
    phi[6,2]  R1689     1.6060771942138672e+00
    phi[6,2]  R1690     1.8287003040313721e+00
    phi[6,2]  R1691     1.1677653789520264e+00
    phi[6,2]  R1692     4.5427301526069641e-01
    phi[6,2]  R1693     6.5305948257446289e-01
    phi[6,2]  R1694     0.707932710647583
    phi[6,2]  R1695     1.2563668489456177e+00
    phi[6,2]  R1696     1.9391212463378906e+00
    phi[6,2]  R1697     1.8411041498184204e+00
    phi[6,2]  R1698     1.4448857307434082e+00
    phi[6,2]  R1699     -1.6837440729141235e+00
    phi[6,2]  R1700     -1.1147780418395996e+00
    phi[6,2]  R1701     -2.1535389423370361e+00
    phi[6,2]  R1702     -2.4632074832916260e+00
    phi[6,2]  R1703     -2.4386303424835205e+00
    phi[6,2]  R1704     -3.1069284677505493e-01
    phi[6,2]  R1705     -2.1550416946411133e+00
    phi[6,2]  R1706     -1.0178964138031006e+00
    phi[6,2]  R1707     -1.7698980569839478e+00
    phi[6,2]  R1708     -3.2427403926849365e+00
    phi[6,2]  R1709     1.4479906558990479e+00
    phi[6,2]  R1710     7.1615827083587646e-01
    phi[6,2]  R1711     -8.5022526979446411e-01
    phi[6,2]  R1712     -1.0141491144895554e-01
    phi[6,2]  R1713     -3.9661136269569397e-01
    phi[6,2]  R1714     -1.4362233877182007e-01
    phi[6,2]  R1715     6.4183771610260010e-01
    phi[6,2]  R1716     -1.1017217636108398e+00
    phi[6,2]  R1717     -3.2558679580688477e-01
    phi[6,2]  R1718     1.2046914100646973e+00
    phi[6,2]  R1719     -1.5689424276351929e+00
    phi[6,2]  R1720     -2.8515503406524658e+00
    phi[6,2]  R1721     -2.4241050705313683e-02
    phi[6,2]  R1722     1.1722551584243774e+00
    phi[6,2]  R1723     6.6547647118568420e-02
    phi[6,2]  R1724     -4.1880190372467041e-01
    phi[6,2]  R1725     1.6503981351852417e+00
    phi[6,2]  R1726     1.7493067979812622e+00
    phi[6,2]  R1727     0.419420450925827
    phi[6,2]  R1728     0.867963969707489
    phi[6,2]  R1729     0.0363311693072319
    phi[6,2]  R1730     -8.4838904440402985e-02
    phi[6,2]  R1731     -1.3639408349990845e+00
    phi[6,2]  R1732     -5.0670862197875977e-02
    phi[6,2]  R1733     -1.8000050783157349e+00
    phi[6,2]  R1734     -1.7321132421493530e+00
    phi[6,2]  R1735     -4.8732721805572510e-01
    phi[6,2]  R1736     -1.9447910785675049e+00
    phi[6,2]  R1737     1.9736206531524658e+00
    phi[6,2]  R1738     1.5280526876449585e-01
    phi[2,8]  R18       1
    phi[2,8]  R19       1
    phi[2,8]  R20       2.4873720137694155e-01
    phi[2,8]  R21       -1.7292262623421930e+00
    phi[2,8]  R22       2.7207785497190908e+00
    phi[2,8]  R23       -8.9157918352655541e-01
    phi[2,8]  R24       -1.9594099882948943e+00
    phi[2,8]  R25       -1.6241265206712572e+00
    phi[2,8]  R26       1.3997847368650440e-01
    phi[2,8]  R64       -1
    phi[2,8]  R1739     -2.8512627032556268e+00
    phi[2,8]  R1740     -3.34873710600951
    phi[2,8]  R1741     -3.9692262718789362e+00
    phi[2,8]  R1742     -5.1077374719455015e-01
    phi[2,8]  R1743     -3.7922135491347753e-01
    phi[2,8]  R1744     -5.8207784543516592e+00
    phi[2,8]  R1745     -3.4615791167693533e+00
    phi[2,8]  R1746     -1.6784207497162424e+00
    phi[2,8]  R1747     -5.0594098929274622e+00
    phi[2,8]  R1748     -1.1405899163376740e+00
    phi[2,8]  R1749     -3.7141264348405687e+00
    phi[2,8]  R1750     -4.6587339349805434e-01
    phi[2,8]  R1751     -2.9600214309460640e+00
    phi[2,8]  R1752     -3.2399783783190728e+00
    phi[2,8]  R1753     -1.4726370005863454e-01
    phi[2,8]  R1754     -2.0800312827832723e-01
    phi[2,8]  R1755     -3.1924565219548473e-01
    phi[2,8]  R1756     -0.541784435268768
    phi[2,8]  R1757     -4.3183776133014007e-01
    phi[2,8]  R1758     -8.9345221736796510e-01
    phi[2,8]  R1759     -1.1542441717188234e+00
    phi[2,8]  R1760     -8.5548286699104725e-01
    phi[2,8]  R1761     -3.8989913348385397e-01
    phi[2,8]  R1762     -3.4072482805449877e-01
    phi[2,8]  R1763     -1.7646502374890094e-01
    phi[2,8]  R1764     -2.3635607723986007e-01
    phi[2,8]  R1765     -2.3941349144360347e-01
    phi[2,8]  R1766     -2.6221531588900859e-01
    phi[2,8]  R1767     -2.9260329544221531e-01
    phi[2,8]  R1768     -3.1768816254756460e-01
    phi[2,8]  R1769     -3.4920972694958752e-01
    phi[2,8]  R1770     -3.5051799002694717e-01
    phi[2,8]  R1771     -3.5937443813963377e-01
    phi[2,8]  R1772     -3.8931515034504560e-01
    phi[2,8]  R1773     -2.2259542041435365e-01
    phi[2,8]  R1774     -2.8745454975364204e-01
    phi[2,8]  R1775     -3.3197981796495979e-01
    phi[2,8]  R1776     -6.3308807855968585e-01
    phi[2,8]  R1777     -3.5822035911871153e-01
    phi[2,8]  R1778     -3.7422981142342859e-01
    phi[2,8]  R1779     -3.7688441355792390e-01
    phi[2,8]  R1780     -3.9546712368004211e-01
    phi[2,8]  R1781     -4.0328583078921426e-01
    phi[2,8]  R1782     -4.4097912305727616e-01
    phi[2,8]  R1783     -3.0586481466900506e-01
    phi[2,8]  R1784     -3.2541930535080255e-01
    phi[2,8]  R1785     -7.6726871517494943e-01
    phi[2,8]  R1786     -5.8112791693291976e-01
    phi[2,8]  R1787     -0.345916104755945
    phi[2,8]  R1788     -3.6478233837055551e-01
    phi[2,8]  R1789     -1.0449840531593328e+00
    phi[2,8]  R1790     -6.2425783841688043e-01
    phi[2,8]  R1791     -3.7449288326061581e-01
    phi[2,8]  R1792     -4.1898743473469380e-01
    phi[2,8]  R1793     -1.4686670043336730e-01
    phi[2,8]  R1794     -2.1469885369637171e-01
    phi[2,8]  R1795     -2.2292065762726043e-01
    phi[2,8]  R1796     -2.2640300795955176e-01
    phi[2,8]  R1797     -2.2645855598901377e-01
    phi[2,8]  R1798     -2.3891327088690306e-01
    phi[2,8]  R1799     -2.6379203093887504e-01
    phi[2,8]  R1800     -0.284349489620338
    phi[2,8]  R1801     -6.8730573276511553e-01
    phi[2,8]  R1802     -3.7058904544197946e-01
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R1803     -3.0999999046325684e+00
    phi[3,4]  R1804     -3.0999999046325684e+00
    phi[3,4]  R1805     -2.2400000095367432e+00
    phi[3,4]  R1806     -2.2400000095367432e+00
    phi[3,4]  R1807     -3.0999999046325684e+00
    phi[3,4]  R1808     -3.0999999046325684e+00
    phi[3,4]  R1809     -2.5699999332427979e+00
    phi[3,4]  R1810     -2.5699999332427979e+00
    phi[3,4]  R1811     -3.0999999046325684e+00
    phi[3,4]  R1812     -3.0999999046325684e+00
    phi[3,4]  R1813     -2.0899999141693115e+00
    phi[3,4]  R1814     -2.0899999141693115e+00
    phi[3,4]  R1815     -3.0999999046325684e+00
    phi[3,4]  R1816     -3.0999999046325684e+00
    phi[3,4]  R1817     7.6624006032943726e-01
    phi[3,4]  R1818     8.7073397636413574e-01
    phi[3,4]  R1819     6.3541121780872345e-02
    phi[3,4]  R1820     -1.2582535743713379e+00
    phi[3,4]  R1821     -0.852837860584259
    phi[3,4]  R1822     1.4180004596710205e-01
    phi[3,4]  R1823     1.5976523160934448e+00
    phi[3,4]  R1824     1.0674113035202026e+00
    phi[3,4]  R1825     -9.8094239830970764e-02
    phi[3,4]  R1826     -5.7521104812622070e-01
    phi[3,4]  R1827     -1.2389801740646362e+00
    phi[3,4]  R1828     6.7096692323684692e-01
    phi[3,4]  R1829     -1.6095486879348755e+00
    phi[3,4]  R1830     -3.0579705238342285e+00
    phi[3,4]  R1831     9.6556764841079712e-01
    phi[3,4]  R1832     -1.6038076579570770e-01
    phi[3,4]  R1833     -4.1359135508537292e-01
    phi[3,4]  R1834     -8.6468511819839478e-01
    phi[3,4]  R1835     -2.1252238750457764e-01
    phi[3,4]  R1836     8.6411453783512115e-02
    phi[3,4]  R1837     -9.9754285812377930e-01
    phi[3,4]  R1838     -3.0408966541290283e+00
    phi[3,4]  R1839     4.8528519272804260e-01
    phi[3,4]  R1840     -2.1842072010040283e+00
    phi[3,4]  R1841     1.9598045349121094e+00
    phi[3,4]  R1842     1.5360081195831299e+00
    phi[3,4]  R1843     -4.7072279453277588e-01
    phi[3,4]  R1844     1.7719395458698273e-01
    phi[3,4]  R1845     -2.9408857226371765e-01
    phi[3,4]  R1846     -4.5784822106361389e-01
    phi[3,4]  R1847     -2.9499703645706177e-01
    phi[3,4]  R1848     -1.0516991615295410e+00
    phi[3,4]  R1849     -2.5301668643951416e+00
    phi[3,4]  R1850     1.0645778179168701e+00
    phi[3,4]  R1851     -1.0650328397750854e+00
    phi[3,4]  R1852     -8.1583850085735321e-02
    phi[3,4]  R1853     -1.1857541799545288e+00
    phi[3,4]  R1854     -2.9100706577301025e+00
    phi[3,4]  R1855     -2.2868428230285645e+00
    phi[3,4]  R1856     -9.1827267408370972e-01
    phi[3,4]  R1857     -3.7565183639526367e-01
    phi[3,4]  R1858     1.4464820921421051e-01
    phi[3,4]  R1859     -0.792131781578064
    phi[3,4]  R1860     -1.1212884187698364e+00
    phi[3,4]  R1861     -7.6836013793945312e-01
    phi[3,4]  R1862     5.0052696466445923e-01
    phi[3,4]  R1863     -1.0866140127182007e+00
    phi[3,4]  R1864     -3.7080189585685730e-01
    phi[3,4]  R1865     -5.2885800600051880e-01
    phi[3,4]  R1866     -1.9754477739334106e+00
    phi[3,4]  R1867     -1.8062031269073486e-01
    phi[3,4]  R1868     -7.9203057289123535e-01
    phi[3,4]  R1869     -0.6389120221138
    phi[3,4]  R1870     -0.89692223072052
    phi[3,4]  R1871     -3.9350599050521851e-02
    phi[3,4]  R1872     7.7230364084243774e-02
    phi[3,4]  R1873     -1.0600973367691040e+00
    phi[3,4]  R1874     -1.1978632211685181e+00
    phi[3,4]  R1875     0.80079585313797
    phi[3,4]  R1876     -7.3709380626678467e-01
    phi[3,4]  R1877     -2.9536029696464539e-01
    phi[3,4]  R1878     2.3081381618976593e-01
    phi[3,4]  R1879     -1.7289516925811768e+00
    phi[3,4]  R1880     7.9319781064987183e-01
    phi[3,4]  R1881     -9.4018924236297607e-01
    phi[3,4]  R1882     1.3797641992568970e+00
    phi[3,4]  R1883     -2.3305485248565674e+00
    phi[3,4]  R1884     7.7171194553375244e-01
    phi[3,4]  R1885     -8.6895430088043213e-01
    phi[3,4]  R1886     -9.6156805753707886e-01
    phi[3,4]  R1887     -1.1809604167938232e+00
    phi[3,4]  R1888     -6.4265263080596924e-01
    phi[3,4]  R1889     -6.1832308769226074e-01
    phi[3,4]  R1890     -9.5892304182052612e-01
    phi[3,4]  R1891     2.3982904851436615e-01
    phi[3,4]  R1892     4.9615317583084106e-01
    phi[3,4]  R1893     1.3157655000686646e+00
    phi[3,4]  R1894     -3.7837758660316467e-01
    phi[3,4]  R1895     4.6028682589530945e-01
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R1896     -3.0999999046325684e+00
    phi[4,3]  R1897     -3.0999999046325684e+00
    phi[4,3]  R1898     -2.2400000095367432e+00
    phi[4,3]  R1899     -2.2400000095367432e+00
    phi[4,3]  R1900     -3.0999999046325684e+00
    phi[4,3]  R1901     -3.0999999046325684e+00
    phi[4,3]  R1902     -2.5699999332427979e+00
    phi[4,3]  R1903     -2.5699999332427979e+00
    phi[4,3]  R1904     -3.0999999046325684e+00
    phi[4,3]  R1905     -3.0999999046325684e+00
    phi[4,3]  R1906     -2.0899999141693115e+00
    phi[4,3]  R1907     -2.0899999141693115e+00
    phi[4,3]  R1908     -3.0999999046325684e+00
    phi[4,3]  R1909     -3.0999999046325684e+00
    phi[4,3]  R1910     -4.5784822106361389e-01
    phi[4,3]  R1911     -2.9499703645706177e-01
    phi[4,3]  R1912     -1.0516991615295410e+00
    phi[4,3]  R1913     -2.5301668643951416e+00
    phi[4,3]  R1914     1.0645778179168701e+00
    phi[4,3]  R1915     -1.0650328397750854e+00
    phi[4,3]  R1916     -8.1583850085735321e-02
    phi[4,3]  R1917     -1.1857541799545288e+00
    phi[4,3]  R1918     -2.9100706577301025e+00
    phi[4,3]  R1919     -2.2868428230285645e+00
    phi[4,3]  R1920     -9.1827267408370972e-01
    phi[4,3]  R1921     -3.7565183639526367e-01
    phi[4,3]  R1922     1.4464820921421051e-01
    phi[4,3]  R1923     -0.792131781578064
    phi[4,3]  R1924     -1.1212884187698364e+00
    phi[4,3]  R1925     -7.6836013793945312e-01
    phi[4,3]  R1926     5.0052696466445923e-01
    phi[4,3]  R1927     -1.0866140127182007e+00
    phi[4,3]  R1928     -3.7080189585685730e-01
    phi[4,3]  R1929     -5.2885800600051880e-01
    phi[4,3]  R1930     -1.9754477739334106e+00
    phi[4,3]  R1931     -1.8062031269073486e-01
    phi[4,3]  R1932     -7.9203057289123535e-01
    phi[4,3]  R1933     -0.6389120221138
    phi[4,3]  R1934     -0.89692223072052
    phi[4,3]  R1935     -3.9350599050521851e-02
    phi[4,3]  R1936     7.7230364084243774e-02
    phi[4,3]  R1937     -1.0600973367691040e+00
    phi[4,3]  R1938     -1.1978632211685181e+00
    phi[4,3]  R1939     0.80079585313797
    phi[4,3]  R1940     -7.3709380626678467e-01
    phi[4,3]  R1941     -2.9536029696464539e-01
    phi[4,3]  R1942     2.3081381618976593e-01
    phi[4,3]  R1943     -1.7289516925811768e+00
    phi[4,3]  R1944     7.9319781064987183e-01
    phi[4,3]  R1945     -9.4018924236297607e-01
    phi[4,3]  R1946     1.3797641992568970e+00
    phi[4,3]  R1947     -2.3305485248565674e+00
    phi[4,3]  R1948     7.7171194553375244e-01
    phi[4,3]  R1949     -8.6895430088043213e-01
    phi[4,3]  R1950     -9.6156805753707886e-01
    phi[4,3]  R1951     -1.1809604167938232e+00
    phi[4,3]  R1952     -6.4265263080596924e-01
    phi[4,3]  R1953     -6.1832308769226074e-01
    phi[4,3]  R1954     -9.5892304182052612e-01
    phi[4,3]  R1955     2.3982904851436615e-01
    phi[4,3]  R1956     4.9615317583084106e-01
    phi[4,3]  R1957     1.3157655000686646e+00
    phi[4,3]  R1958     -3.7837758660316467e-01
    phi[4,3]  R1959     4.6028682589530945e-01
    phi[4,3]  R1960     7.6624006032943726e-01
    phi[4,3]  R1961     8.7073397636413574e-01
    phi[4,3]  R1962     6.3541121780872345e-02
    phi[4,3]  R1963     -1.2582535743713379e+00
    phi[4,3]  R1964     -0.852837860584259
    phi[4,3]  R1965     1.4180004596710205e-01
    phi[4,3]  R1966     1.5976523160934448e+00
    phi[4,3]  R1967     1.0674113035202026e+00
    phi[4,3]  R1968     -9.8094239830970764e-02
    phi[4,3]  R1969     -5.7521104812622070e-01
    phi[4,3]  R1970     -1.2389801740646362e+00
    phi[4,3]  R1971     6.7096692323684692e-01
    phi[4,3]  R1972     -1.6095486879348755e+00
    phi[4,3]  R1973     -3.0579705238342285e+00
    phi[4,3]  R1974     9.6556764841079712e-01
    phi[4,3]  R1975     -1.6038076579570770e-01
    phi[4,3]  R1976     -4.1359135508537292e-01
    phi[4,3]  R1977     -8.6468511819839478e-01
    phi[4,3]  R1978     -2.1252238750457764e-01
    phi[4,3]  R1979     8.6411453783512115e-02
    phi[4,3]  R1980     -9.9754285812377930e-01
    phi[4,3]  R1981     -3.0408966541290283e+00
    phi[4,3]  R1982     4.8528519272804260e-01
    phi[4,3]  R1983     -2.1842072010040283e+00
    phi[4,3]  R1984     1.9598045349121094e+00
    phi[4,3]  R1985     1.5360081195831299e+00
    phi[4,3]  R1986     -4.7072279453277588e-01
    phi[4,3]  R1987     1.7719395458698273e-01
    phi[4,3]  R1988     -2.9408857226371765e-01
    phi[7,3]  R27       -1
    phi[7,3]  R29       -1.3550681263039
    phi[7,3]  R30       2.0686367358790969e-01
    phi[7,3]  R31       2.9534051777112533e+00
    phi[7,3]  R32       1.5626497589467756e+00
    phi[7,3]  R33       2.8910893979909322e+00
    phi[7,3]  R34       5.7556263234235239e-01
    phi[7,3]  R35       -1.5764510220519012e-01
    phi[7,3]  R63       1
    phi[7,3]  R1989     -1.7449317783286684e+00
    phi[7,3]  R1990     -4.4550680309364683e+00
    phi[7,3]  R1991     -2.4468636831246529e+00
    phi[7,3]  R1992     -2.0331363359488335e+00
    phi[7,3]  R1993     -6.0534050823438221e+00
    phi[7,3]  R1994     -1.4659472692131503e-01
    phi[7,3]  R1995     -4.1326496921895739e+00
    phi[7,3]  R1996     -1.0073501742960222e+00
    phi[7,3]  R1997     -5.9910893026235
    phi[7,3]  R1998     -2.0891050664163613e-01
    phi[7,3]  R1999     -2.6655625465116639e+00
    phi[7,3]  R2000     -1.5144372818269591e+00
    phi[7,3]  R2001     -2.9423548024273782e+00
    phi[7,3]  R2002     -3.2576450068377585e+00
    phi[7,3]  R2003     -1.3362184070306604e-01
    phi[7,3]  R2004     -1.3446336432318606e-01
    phi[7,3]  R2005     -1.3890252223285066e-01
    phi[7,3]  R2006     -1.4661474759846516e-01
    phi[7,3]  R2007     -1.5516734652420550e-01
    phi[7,3]  R2008     -1.5806281209727324e-01
    phi[7,3]  R2009     -1.7293231943224807e-01
    phi[7,3]  R2010     -1.8026154657041427e-01
    phi[7,3]  R2011     -1.8896722519404152e-01
    phi[7,3]  R2012     -2.1476098974052898e-01
    phi[7,3]  R2013     -2.0223128422116754e-01
    phi[7,3]  R2014     -2.2170153754451771e-01
    phi[7,3]  R2015     -3.5918791049607424e-01
    phi[7,3]  R2016     -4.5271084823482921e-01
    phi[7,3]  R2017     -6.6843396813659228e-01
    phi[7,3]  R2018     -7.7678633182836232e-01
    phi[7,3]  R2019     -9.3538861978624255e-01
    phi[7,3]  R2020     -2.0511994924792680e+00
    phi[7,3]  R2021     -1.3851593447229087e+00
    phi[7,3]  R2022     -2.3457028483995224e+00
    phi[7,3]  R2023     -2.2812547305916309e-01
    phi[7,3]  R2024     -3.3222659116216180e-01
    phi[7,3]  R2025     -0.714304042198326
    phi[7,3]  R2026     -7.3758123382004426e-01
    phi[7,3]  R2027     -7.3943241256812708e-01
    phi[7,3]  R2028     -7.4251079751899240e-01
    phi[7,3]  R2029     -7.4314846433005088e-01
    phi[7,3]  R2030     -7.6602895254063985e-01
    phi[7,3]  R2031     -1.1948705485685813e+00
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R2032     -3.0999999046325684e+00
    phi[4,5]  R2033     -3.0999999046325684e+00
    phi[4,5]  R2034     -2.2400000095367432e+00
    phi[4,5]  R2035     -2.2400000095367432e+00
    phi[4,5]  R2036     -3.0999999046325684e+00
    phi[4,5]  R2037     -3.0999999046325684e+00
    phi[4,5]  R2038     -2.5699999332427979e+00
    phi[4,5]  R2039     -2.5699999332427979e+00
    phi[4,5]  R2040     -3.0999999046325684e+00
    phi[4,5]  R2041     -3.0999999046325684e+00
    phi[4,5]  R2042     -2.0899999141693115e+00
    phi[4,5]  R2043     -2.0899999141693115e+00
    phi[4,5]  R2044     -3.0999999046325684e+00
    phi[4,5]  R2045     -3.0999999046325684e+00
    phi[4,5]  R2046     -4.5784822106361389e-01
    phi[4,5]  R2047     -2.9499703645706177e-01
    phi[4,5]  R2048     -1.0516991615295410e+00
    phi[4,5]  R2049     -2.5301668643951416e+00
    phi[4,5]  R2050     1.0645778179168701e+00
    phi[4,5]  R2051     -1.0650328397750854e+00
    phi[4,5]  R2052     -8.1583850085735321e-02
    phi[4,5]  R2053     -1.1857541799545288e+00
    phi[4,5]  R2054     -2.9100706577301025e+00
    phi[4,5]  R2055     -2.2868428230285645e+00
    phi[4,5]  R2056     -9.1827267408370972e-01
    phi[4,5]  R2057     -3.7565183639526367e-01
    phi[4,5]  R2058     1.4464820921421051e-01
    phi[4,5]  R2059     -0.792131781578064
    phi[4,5]  R2060     -1.1212884187698364e+00
    phi[4,5]  R2061     -7.6836013793945312e-01
    phi[4,5]  R2062     5.0052696466445923e-01
    phi[4,5]  R2063     -1.0866140127182007e+00
    phi[4,5]  R2064     -3.7080189585685730e-01
    phi[4,5]  R2065     -5.2885800600051880e-01
    phi[4,5]  R2066     -1.9754477739334106e+00
    phi[4,5]  R2067     -1.8062031269073486e-01
    phi[4,5]  R2068     -7.9203057289123535e-01
    phi[4,5]  R2069     -0.6389120221138
    phi[4,5]  R2070     -0.89692223072052
    phi[4,5]  R2071     -3.9350599050521851e-02
    phi[4,5]  R2072     7.7230364084243774e-02
    phi[4,5]  R2073     -1.0600973367691040e+00
    phi[4,5]  R2074     -1.1978632211685181e+00
    phi[4,5]  R2075     0.80079585313797
    phi[4,5]  R2076     -7.3709380626678467e-01
    phi[4,5]  R2077     -2.9536029696464539e-01
    phi[4,5]  R2078     2.3081381618976593e-01
    phi[4,5]  R2079     -1.7289516925811768e+00
    phi[4,5]  R2080     7.9319781064987183e-01
    phi[4,5]  R2081     -9.4018924236297607e-01
    phi[4,5]  R2082     1.3797641992568970e+00
    phi[4,5]  R2083     -2.3305485248565674e+00
    phi[4,5]  R2084     7.7171194553375244e-01
    phi[4,5]  R2085     -8.6895430088043213e-01
    phi[4,5]  R2086     -9.6156805753707886e-01
    phi[4,5]  R2087     -1.1809604167938232e+00
    phi[4,5]  R2088     -6.4265263080596924e-01
    phi[4,5]  R2089     -6.1832308769226074e-01
    phi[4,5]  R2090     -9.5892304182052612e-01
    phi[4,5]  R2091     2.3982904851436615e-01
    phi[4,5]  R2092     4.9615317583084106e-01
    phi[4,5]  R2093     1.3157655000686646e+00
    phi[4,5]  R2094     -3.7837758660316467e-01
    phi[4,5]  R2095     4.6028682589530945e-01
    phi[4,5]  R2096     1.8007920980453491e+00
    phi[4,5]  R2097     6.4599418640136719e-01
    phi[4,5]  R2098     2.2603318691253662e+00
    phi[4,5]  R2099     1.7873261868953705e-01
    phi[4,5]  R2100     2.2411823272705078e+00
    phi[4,5]  R2101     7.2719532251358032e-01
    phi[4,5]  R2102     -1.7080196142196655e+00
    phi[4,5]  R2103     -2.2581880092620850e+00
    phi[4,5]  R2104     -3.4046941995620728e-01
    phi[4,5]  R2105     -5.4829396307468414e-02
    phi[4,5]  R2106     -1.8441349267959595e+00
    phi[4,5]  R2107     -2.0565166473388672e+00
    phi[4,5]  R2108     -1.62327241897583
    phi[4,5]  R2109     -2.4902718067169189e+00
    phi[4,5]  R2110     -2.0668454170227051e+00
    phi[4,5]  R2111     -0.446829229593277
    phi[4,5]  R2112     -3.1041178107261658e-01
    phi[4,5]  R2113     -2.4223685264587402e+00
    phi[4,5]  R2114     -1.1626986414194107e-01
    phi[4,5]  R2115     1.5148143470287323e-01
    phi[4,5]  R2116     -9.9619424343109131e-01
    phi[4,5]  R2117     -1.1306135654449463e+00
    phi[4,5]  R2118     -1.1128909587860107e+00
    phi[4,5]  R2119     -1.2805100679397583e+00
    phi[4,5]  R2120     -2.0169441699981689e+00
    phi[4,5]  R2121     -1.0042003393173218e+00
    phi[4,5]  R2122     -2.0214745998382568e+00
    phi[4,5]  R2123     -2.8233633041381836e+00
    phi[4,5]  R2124     1.7531819641590118e-01
    phi[4,5]  R2125     5.9440964460372925e-01
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R2126     -3.0999999046325684e+00
    phi[5,4]  R2127     -3.0999999046325684e+00
    phi[5,4]  R2128     -2.2400000095367432e+00
    phi[5,4]  R2129     -2.2400000095367432e+00
    phi[5,4]  R2130     -3.0999999046325684e+00
    phi[5,4]  R2131     -3.0999999046325684e+00
    phi[5,4]  R2132     -2.5699999332427979e+00
    phi[5,4]  R2133     -2.5699999332427979e+00
    phi[5,4]  R2134     -3.0999999046325684e+00
    phi[5,4]  R2135     -3.0999999046325684e+00
    phi[5,4]  R2136     -2.0899999141693115e+00
    phi[5,4]  R2137     -2.0899999141693115e+00
    phi[5,4]  R2138     -3.0999999046325684e+00
    phi[5,4]  R2139     -3.0999999046325684e+00
    phi[5,4]  R2140     1.8007920980453491e+00
    phi[5,4]  R2141     6.4599418640136719e-01
    phi[5,4]  R2142     2.2603318691253662e+00
    phi[5,4]  R2143     1.7873261868953705e-01
    phi[5,4]  R2144     2.2411823272705078e+00
    phi[5,4]  R2145     7.2719532251358032e-01
    phi[5,4]  R2146     -1.7080196142196655e+00
    phi[5,4]  R2147     -2.2581880092620850e+00
    phi[5,4]  R2148     -3.4046941995620728e-01
    phi[5,4]  R2149     -5.4829396307468414e-02
    phi[5,4]  R2150     -1.8441349267959595e+00
    phi[5,4]  R2151     -2.0565166473388672e+00
    phi[5,4]  R2152     -1.62327241897583
    phi[5,4]  R2153     -2.4902718067169189e+00
    phi[5,4]  R2154     -2.0668454170227051e+00
    phi[5,4]  R2155     -0.446829229593277
    phi[5,4]  R2156     -3.1041178107261658e-01
    phi[5,4]  R2157     -2.4223685264587402e+00
    phi[5,4]  R2158     -1.1626986414194107e-01
    phi[5,4]  R2159     1.5148143470287323e-01
    phi[5,4]  R2160     -9.9619424343109131e-01
    phi[5,4]  R2161     -1.1306135654449463e+00
    phi[5,4]  R2162     -1.1128909587860107e+00
    phi[5,4]  R2163     -1.2805100679397583e+00
    phi[5,4]  R2164     -2.0169441699981689e+00
    phi[5,4]  R2165     -1.0042003393173218e+00
    phi[5,4]  R2166     -2.0214745998382568e+00
    phi[5,4]  R2167     -2.8233633041381836e+00
    phi[5,4]  R2168     1.7531819641590118e-01
    phi[5,4]  R2169     5.9440964460372925e-01
    phi[5,4]  R2170     -4.5784822106361389e-01
    phi[5,4]  R2171     -2.9499703645706177e-01
    phi[5,4]  R2172     -1.0516991615295410e+00
    phi[5,4]  R2173     -2.5301668643951416e+00
    phi[5,4]  R2174     1.0645778179168701e+00
    phi[5,4]  R2175     -1.0650328397750854e+00
    phi[5,4]  R2176     -8.1583850085735321e-02
    phi[5,4]  R2177     -1.1857541799545288e+00
    phi[5,4]  R2178     -2.9100706577301025e+00
    phi[5,4]  R2179     -2.2868428230285645e+00
    phi[5,4]  R2180     -9.1827267408370972e-01
    phi[5,4]  R2181     -3.7565183639526367e-01
    phi[5,4]  R2182     1.4464820921421051e-01
    phi[5,4]  R2183     -0.792131781578064
    phi[5,4]  R2184     -1.1212884187698364e+00
    phi[5,4]  R2185     -7.6836013793945312e-01
    phi[5,4]  R2186     5.0052696466445923e-01
    phi[5,4]  R2187     -1.0866140127182007e+00
    phi[5,4]  R2188     -3.7080189585685730e-01
    phi[5,4]  R2189     -5.2885800600051880e-01
    phi[5,4]  R2190     -1.9754477739334106e+00
    phi[5,4]  R2191     -1.8062031269073486e-01
    phi[5,4]  R2192     -7.9203057289123535e-01
    phi[5,4]  R2193     -0.6389120221138
    phi[5,4]  R2194     -0.89692223072052
    phi[5,4]  R2195     -3.9350599050521851e-02
    phi[5,4]  R2196     7.7230364084243774e-02
    phi[5,4]  R2197     -1.0600973367691040e+00
    phi[5,4]  R2198     -1.1978632211685181e+00
    phi[5,4]  R2199     0.80079585313797
    phi[5,4]  R2200     -7.3709380626678467e-01
    phi[5,4]  R2201     -2.9536029696464539e-01
    phi[5,4]  R2202     2.3081381618976593e-01
    phi[5,4]  R2203     -1.7289516925811768e+00
    phi[5,4]  R2204     7.9319781064987183e-01
    phi[5,4]  R2205     -9.4018924236297607e-01
    phi[5,4]  R2206     1.3797641992568970e+00
    phi[5,4]  R2207     -2.3305485248565674e+00
    phi[5,4]  R2208     7.7171194553375244e-01
    phi[5,4]  R2209     -8.6895430088043213e-01
    phi[5,4]  R2210     -9.6156805753707886e-01
    phi[5,4]  R2211     -1.1809604167938232e+00
    phi[5,4]  R2212     -6.4265263080596924e-01
    phi[5,4]  R2213     -6.1832308769226074e-01
    phi[5,4]  R2214     -9.5892304182052612e-01
    phi[5,4]  R2215     2.3982904851436615e-01
    phi[5,4]  R2216     4.9615317583084106e-01
    phi[5,4]  R2217     1.3157655000686646e+00
    phi[5,4]  R2218     -3.7837758660316467e-01
    phi[5,4]  R2219     4.6028682589530945e-01
    phi[4,6]  R36       1
    phi[4,6]  R37       1
    phi[4,6]  R54       -1
    phi[4,6]  R2220     -3.0999999046325684e+00
    phi[4,6]  R2221     -3.0999999046325684e+00
    phi[4,6]  R2222     -2.2400000095367432e+00
    phi[4,6]  R2223     -2.2400000095367432e+00
    phi[4,6]  R2224     -3.0999999046325684e+00
    phi[4,6]  R2225     -3.0999999046325684e+00
    phi[4,6]  R2226     -2.5699999332427979e+00
    phi[4,6]  R2227     -2.5699999332427979e+00
    phi[4,6]  R2228     -3.0999999046325684e+00
    phi[4,6]  R2229     -3.0999999046325684e+00
    phi[4,6]  R2230     -2.0899999141693115e+00
    phi[4,6]  R2231     -2.0899999141693115e+00
    phi[4,6]  R2232     -3.0999999046325684e+00
    phi[4,6]  R2233     -3.0999999046325684e+00
    phi[4,6]  R2234     -4.5784822106361389e-01
    phi[4,6]  R2235     -2.9499703645706177e-01
    phi[4,6]  R2236     -1.0516991615295410e+00
    phi[4,6]  R2237     -2.5301668643951416e+00
    phi[4,6]  R2238     1.0645778179168701e+00
    phi[4,6]  R2239     -1.0650328397750854e+00
    phi[4,6]  R2240     -8.1583850085735321e-02
    phi[4,6]  R2241     -1.1857541799545288e+00
    phi[4,6]  R2242     -2.9100706577301025e+00
    phi[4,6]  R2243     -2.2868428230285645e+00
    phi[4,6]  R2244     -9.1827267408370972e-01
    phi[4,6]  R2245     -3.7565183639526367e-01
    phi[4,6]  R2246     1.4464820921421051e-01
    phi[4,6]  R2247     -0.792131781578064
    phi[4,6]  R2248     -1.1212884187698364e+00
    phi[4,6]  R2249     -7.6836013793945312e-01
    phi[4,6]  R2250     5.0052696466445923e-01
    phi[4,6]  R2251     -1.0866140127182007e+00
    phi[4,6]  R2252     -3.7080189585685730e-01
    phi[4,6]  R2253     -5.2885800600051880e-01
    phi[4,6]  R2254     -1.9754477739334106e+00
    phi[4,6]  R2255     -1.8062031269073486e-01
    phi[4,6]  R2256     -7.9203057289123535e-01
    phi[4,6]  R2257     -0.6389120221138
    phi[4,6]  R2258     -0.89692223072052
    phi[4,6]  R2259     -3.9350599050521851e-02
    phi[4,6]  R2260     7.7230364084243774e-02
    phi[4,6]  R2261     -1.0600973367691040e+00
    phi[4,6]  R2262     -1.1978632211685181e+00
    phi[4,6]  R2263     0.80079585313797
    phi[4,6]  R2264     -7.3709380626678467e-01
    phi[4,6]  R2265     -2.9536029696464539e-01
    phi[4,6]  R2266     2.3081381618976593e-01
    phi[4,6]  R2267     -1.7289516925811768e+00
    phi[4,6]  R2268     7.9319781064987183e-01
    phi[4,6]  R2269     -9.4018924236297607e-01
    phi[4,6]  R2270     1.3797641992568970e+00
    phi[4,6]  R2271     -2.3305485248565674e+00
    phi[4,6]  R2272     7.7171194553375244e-01
    phi[4,6]  R2273     -8.6895430088043213e-01
    phi[4,6]  R2274     -9.6156805753707886e-01
    phi[4,6]  R2275     -1.1809604167938232e+00
    phi[4,6]  R2276     -6.4265263080596924e-01
    phi[4,6]  R2277     -6.1832308769226074e-01
    phi[4,6]  R2278     -9.5892304182052612e-01
    phi[4,6]  R2279     2.3982904851436615e-01
    phi[4,6]  R2280     4.9615317583084106e-01
    phi[4,6]  R2281     1.3157655000686646e+00
    phi[4,6]  R2282     -3.7837758660316467e-01
    phi[4,6]  R2283     4.6028682589530945e-01
    phi[4,6]  R2284     1.7274820804595947e+00
    phi[4,6]  R2285     1.5270236730575562e+00
    phi[4,6]  R2286     2.1326994895935059e+00
    phi[4,6]  R2287     2.2672083377838135e+00
    phi[4,6]  R2288     -6.3488230109214783e-02
    phi[4,6]  R2289     0.908623993396759
    phi[4,6]  R2290     -2.7456244826316833e-01
    phi[4,6]  R2291     1.3411377668380737e+00
    phi[4,6]  R2292     5.5729693174362183e-01
    phi[4,6]  R2293     -2.1786594390869141e+00
    phi[4,6]  R2294     1.4492569863796234e-01
    phi[4,6]  R2295     -2.8861382007598877e+00
    phi[4,6]  R2296     -2.3819103240966797e+00
    phi[4,6]  R2297     -1.7536773681640625e+00
    phi[4,6]  R2298     -1.2884278297424316e+00
    phi[4,6]  R2299     -4.5313236117362976e-01
    phi[4,6]  R2300     -8.0924767255783081e-01
    phi[4,6]  R2301     -2.1314678192138672e+00
    phi[4,6]  R2302     0.443470299243927
    phi[4,6]  R2303     -5.5021989345550537e-01
    phi[6,4]  R36       -1
    phi[6,4]  R54       1
    phi[6,4]  R55       1
    phi[6,4]  R2304     -3.0999999046325684e+00
    phi[6,4]  R2305     -3.0999999046325684e+00
    phi[6,4]  R2306     -2.2400000095367432e+00
    phi[6,4]  R2307     -2.2400000095367432e+00
    phi[6,4]  R2308     -3.0999999046325684e+00
    phi[6,4]  R2309     -3.0999999046325684e+00
    phi[6,4]  R2310     -2.5699999332427979e+00
    phi[6,4]  R2311     -2.5699999332427979e+00
    phi[6,4]  R2312     -3.0999999046325684e+00
    phi[6,4]  R2313     -3.0999999046325684e+00
    phi[6,4]  R2314     -2.0899999141693115e+00
    phi[6,4]  R2315     -2.0899999141693115e+00
    phi[6,4]  R2316     -3.0999999046325684e+00
    phi[6,4]  R2317     -3.0999999046325684e+00
    phi[6,4]  R2318     1.7274820804595947e+00
    phi[6,4]  R2319     1.5270236730575562e+00
    phi[6,4]  R2320     2.1326994895935059e+00
    phi[6,4]  R2321     2.2672083377838135e+00
    phi[6,4]  R2322     -6.3488230109214783e-02
    phi[6,4]  R2323     0.908623993396759
    phi[6,4]  R2324     -2.7456244826316833e-01
    phi[6,4]  R2325     1.3411377668380737e+00
    phi[6,4]  R2326     5.5729693174362183e-01
    phi[6,4]  R2327     -2.1786594390869141e+00
    phi[6,4]  R2328     1.4492569863796234e-01
    phi[6,4]  R2329     -2.8861382007598877e+00
    phi[6,4]  R2330     -2.3819103240966797e+00
    phi[6,4]  R2331     -1.7536773681640625e+00
    phi[6,4]  R2332     -1.2884278297424316e+00
    phi[6,4]  R2333     -4.5313236117362976e-01
    phi[6,4]  R2334     -8.0924767255783081e-01
    phi[6,4]  R2335     -2.1314678192138672e+00
    phi[6,4]  R2336     0.443470299243927
    phi[6,4]  R2337     -5.5021989345550537e-01
    phi[6,4]  R2338     -4.5784822106361389e-01
    phi[6,4]  R2339     -2.9499703645706177e-01
    phi[6,4]  R2340     -1.0516991615295410e+00
    phi[6,4]  R2341     -2.5301668643951416e+00
    phi[6,4]  R2342     1.0645778179168701e+00
    phi[6,4]  R2343     -1.0650328397750854e+00
    phi[6,4]  R2344     -8.1583850085735321e-02
    phi[6,4]  R2345     -1.1857541799545288e+00
    phi[6,4]  R2346     -2.9100706577301025e+00
    phi[6,4]  R2347     -2.2868428230285645e+00
    phi[6,4]  R2348     -9.1827267408370972e-01
    phi[6,4]  R2349     -3.7565183639526367e-01
    phi[6,4]  R2350     1.4464820921421051e-01
    phi[6,4]  R2351     -0.792131781578064
    phi[6,4]  R2352     -1.1212884187698364e+00
    phi[6,4]  R2353     -7.6836013793945312e-01
    phi[6,4]  R2354     5.0052696466445923e-01
    phi[6,4]  R2355     -1.0866140127182007e+00
    phi[6,4]  R2356     -3.7080189585685730e-01
    phi[6,4]  R2357     -5.2885800600051880e-01
    phi[6,4]  R2358     -1.9754477739334106e+00
    phi[6,4]  R2359     -1.8062031269073486e-01
    phi[6,4]  R2360     -7.9203057289123535e-01
    phi[6,4]  R2361     -0.6389120221138
    phi[6,4]  R2362     -0.89692223072052
    phi[6,4]  R2363     -3.9350599050521851e-02
    phi[6,4]  R2364     7.7230364084243774e-02
    phi[6,4]  R2365     -1.0600973367691040e+00
    phi[6,4]  R2366     -1.1978632211685181e+00
    phi[6,4]  R2367     0.80079585313797
    phi[6,4]  R2368     -7.3709380626678467e-01
    phi[6,4]  R2369     -2.9536029696464539e-01
    phi[6,4]  R2370     2.3081381618976593e-01
    phi[6,4]  R2371     -1.7289516925811768e+00
    phi[6,4]  R2372     7.9319781064987183e-01
    phi[6,4]  R2373     -9.4018924236297607e-01
    phi[6,4]  R2374     1.3797641992568970e+00
    phi[6,4]  R2375     -2.3305485248565674e+00
    phi[6,4]  R2376     7.7171194553375244e-01
    phi[6,4]  R2377     -8.6895430088043213e-01
    phi[6,4]  R2378     -9.6156805753707886e-01
    phi[6,4]  R2379     -1.1809604167938232e+00
    phi[6,4]  R2380     -6.4265263080596924e-01
    phi[6,4]  R2381     -6.1832308769226074e-01
    phi[6,4]  R2382     -9.5892304182052612e-01
    phi[6,4]  R2383     2.3982904851436615e-01
    phi[6,4]  R2384     4.9615317583084106e-01
    phi[6,4]  R2385     1.3157655000686646e+00
    phi[6,4]  R2386     -3.7837758660316467e-01
    phi[6,4]  R2387     4.6028682589530945e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R2388     -3.0999999046325684e+00
    phi[5,6]  R2389     -3.0999999046325684e+00
    phi[5,6]  R2390     -2.2400000095367432e+00
    phi[5,6]  R2391     -2.2400000095367432e+00
    phi[5,6]  R2392     -3.0999999046325684e+00
    phi[5,6]  R2393     -3.0999999046325684e+00
    phi[5,6]  R2394     -2.5699999332427979e+00
    phi[5,6]  R2395     -2.5699999332427979e+00
    phi[5,6]  R2396     -3.0999999046325684e+00
    phi[5,6]  R2397     -3.0999999046325684e+00
    phi[5,6]  R2398     -2.0899999141693115e+00
    phi[5,6]  R2399     -2.0899999141693115e+00
    phi[5,6]  R2400     -3.0999999046325684e+00
    phi[5,6]  R2401     -3.0999999046325684e+00
    phi[5,6]  R2402     1.8007920980453491e+00
    phi[5,6]  R2403     6.4599418640136719e-01
    phi[5,6]  R2404     2.2603318691253662e+00
    phi[5,6]  R2405     1.7873261868953705e-01
    phi[5,6]  R2406     2.2411823272705078e+00
    phi[5,6]  R2407     7.2719532251358032e-01
    phi[5,6]  R2408     -1.7080196142196655e+00
    phi[5,6]  R2409     -2.2581880092620850e+00
    phi[5,6]  R2410     -3.4046941995620728e-01
    phi[5,6]  R2411     -5.4829396307468414e-02
    phi[5,6]  R2412     -1.8441349267959595e+00
    phi[5,6]  R2413     -2.0565166473388672e+00
    phi[5,6]  R2414     -1.62327241897583
    phi[5,6]  R2415     -2.4902718067169189e+00
    phi[5,6]  R2416     -2.0668454170227051e+00
    phi[5,6]  R2417     -0.446829229593277
    phi[5,6]  R2418     -3.1041178107261658e-01
    phi[5,6]  R2419     -2.4223685264587402e+00
    phi[5,6]  R2420     -1.1626986414194107e-01
    phi[5,6]  R2421     1.5148143470287323e-01
    phi[5,6]  R2422     -9.9619424343109131e-01
    phi[5,6]  R2423     -1.1306135654449463e+00
    phi[5,6]  R2424     -1.1128909587860107e+00
    phi[5,6]  R2425     -1.2805100679397583e+00
    phi[5,6]  R2426     -2.0169441699981689e+00
    phi[5,6]  R2427     -1.0042003393173218e+00
    phi[5,6]  R2428     -2.0214745998382568e+00
    phi[5,6]  R2429     -2.8233633041381836e+00
    phi[5,6]  R2430     1.7531819641590118e-01
    phi[5,6]  R2431     5.9440964460372925e-01
    phi[5,6]  R2432     1.7274820804595947e+00
    phi[5,6]  R2433     1.5270236730575562e+00
    phi[5,6]  R2434     2.1326994895935059e+00
    phi[5,6]  R2435     2.2672083377838135e+00
    phi[5,6]  R2436     -6.3488230109214783e-02
    phi[5,6]  R2437     0.908623993396759
    phi[5,6]  R2438     -2.7456244826316833e-01
    phi[5,6]  R2439     1.3411377668380737e+00
    phi[5,6]  R2440     5.5729693174362183e-01
    phi[5,6]  R2441     -2.1786594390869141e+00
    phi[5,6]  R2442     1.4492569863796234e-01
    phi[5,6]  R2443     -2.8861382007598877e+00
    phi[5,6]  R2444     -2.3819103240966797e+00
    phi[5,6]  R2445     -1.7536773681640625e+00
    phi[5,6]  R2446     -1.2884278297424316e+00
    phi[5,6]  R2447     -4.5313236117362976e-01
    phi[5,6]  R2448     -8.0924767255783081e-01
    phi[5,6]  R2449     -2.1314678192138672e+00
    phi[5,6]  R2450     0.443470299243927
    phi[5,6]  R2451     -5.5021989345550537e-01
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2452     -3.0999999046325684e+00
    phi[6,5]  R2453     -3.0999999046325684e+00
    phi[6,5]  R2454     -2.2400000095367432e+00
    phi[6,5]  R2455     -2.2400000095367432e+00
    phi[6,5]  R2456     -3.0999999046325684e+00
    phi[6,5]  R2457     -3.0999999046325684e+00
    phi[6,5]  R2458     -2.5699999332427979e+00
    phi[6,5]  R2459     -2.5699999332427979e+00
    phi[6,5]  R2460     -3.0999999046325684e+00
    phi[6,5]  R2461     -3.0999999046325684e+00
    phi[6,5]  R2462     -2.0899999141693115e+00
    phi[6,5]  R2463     -2.0899999141693115e+00
    phi[6,5]  R2464     -3.0999999046325684e+00
    phi[6,5]  R2465     -3.0999999046325684e+00
    phi[6,5]  R2466     1.7274820804595947e+00
    phi[6,5]  R2467     1.5270236730575562e+00
    phi[6,5]  R2468     2.1326994895935059e+00
    phi[6,5]  R2469     2.2672083377838135e+00
    phi[6,5]  R2470     -6.3488230109214783e-02
    phi[6,5]  R2471     0.908623993396759
    phi[6,5]  R2472     -2.7456244826316833e-01
    phi[6,5]  R2473     1.3411377668380737e+00
    phi[6,5]  R2474     5.5729693174362183e-01
    phi[6,5]  R2475     -2.1786594390869141e+00
    phi[6,5]  R2476     1.4492569863796234e-01
    phi[6,5]  R2477     -2.8861382007598877e+00
    phi[6,5]  R2478     -2.3819103240966797e+00
    phi[6,5]  R2479     -1.7536773681640625e+00
    phi[6,5]  R2480     -1.2884278297424316e+00
    phi[6,5]  R2481     -4.5313236117362976e-01
    phi[6,5]  R2482     -8.0924767255783081e-01
    phi[6,5]  R2483     -2.1314678192138672e+00
    phi[6,5]  R2484     0.443470299243927
    phi[6,5]  R2485     -5.5021989345550537e-01
    phi[6,5]  R2486     1.8007920980453491e+00
    phi[6,5]  R2487     6.4599418640136719e-01
    phi[6,5]  R2488     2.2603318691253662e+00
    phi[6,5]  R2489     1.7873261868953705e-01
    phi[6,5]  R2490     2.2411823272705078e+00
    phi[6,5]  R2491     7.2719532251358032e-01
    phi[6,5]  R2492     -1.7080196142196655e+00
    phi[6,5]  R2493     -2.2581880092620850e+00
    phi[6,5]  R2494     -3.4046941995620728e-01
    phi[6,5]  R2495     -5.4829396307468414e-02
    phi[6,5]  R2496     -1.8441349267959595e+00
    phi[6,5]  R2497     -2.0565166473388672e+00
    phi[6,5]  R2498     -1.62327241897583
    phi[6,5]  R2499     -2.4902718067169189e+00
    phi[6,5]  R2500     -2.0668454170227051e+00
    phi[6,5]  R2501     -0.446829229593277
    phi[6,5]  R2502     -3.1041178107261658e-01
    phi[6,5]  R2503     -2.4223685264587402e+00
    phi[6,5]  R2504     -1.1626986414194107e-01
    phi[6,5]  R2505     1.5148143470287323e-01
    phi[6,5]  R2506     -9.9619424343109131e-01
    phi[6,5]  R2507     -1.1306135654449463e+00
    phi[6,5]  R2508     -1.1128909587860107e+00
    phi[6,5]  R2509     -1.2805100679397583e+00
    phi[6,5]  R2510     -2.0169441699981689e+00
    phi[6,5]  R2511     -1.0042003393173218e+00
    phi[6,5]  R2512     -2.0214745998382568e+00
    phi[6,5]  R2513     -2.8233633041381836e+00
    phi[6,5]  R2514     1.7531819641590118e-01
    phi[6,5]  R2515     5.9440964460372925e-01
    phi[6,8]  R54       1
    phi[6,8]  R55       1
    phi[6,8]  R56       2.4873720137694155e-01
    phi[6,8]  R57       -1.7292262623421930e+00
    phi[6,8]  R58       2.7207785497190908e+00
    phi[6,8]  R59       -8.9157918352655541e-01
    phi[6,8]  R60       -1.9594099882948943e+00
    phi[6,8]  R61       -1.6241265206712572e+00
    phi[6,8]  R62       1.3997847368650440e-01
    phi[6,8]  R64       -1
    phi[6,8]  R2516     -2.8512627032556268e+00
    phi[6,8]  R2517     -3.34873710600951
    phi[6,8]  R2518     -3.9692262718789362e+00
    phi[6,8]  R2519     -5.1077374719455015e-01
    phi[6,8]  R2520     -3.7922135491347753e-01
    phi[6,8]  R2521     -5.8207784543516592e+00
    phi[6,8]  R2522     -3.4615791167693533e+00
    phi[6,8]  R2523     -1.6784207497162424e+00
    phi[6,8]  R2524     -5.0594098929274622e+00
    phi[6,8]  R2525     -1.1405899163376740e+00
    phi[6,8]  R2526     -3.7141264348405687e+00
    phi[6,8]  R2527     -4.6587339349805434e-01
    phi[6,8]  R2528     -2.9600214309460640e+00
    phi[6,8]  R2529     -3.2399783783190728e+00
    phi[6,8]  R2530     -5.3482655209035412e-01
    phi[6,8]  R2531     -3.0471025792094686e-01
    phi[6,8]  R2532     -0.0788628422638129
    phi[6,8]  R2533     -6.1386156753917565e-02
    phi[6,8]  R2534     -6.2846552543450590e-02
    phi[6,8]  R2535     -2.7327335441616962e-01
    phi[6,8]  R2536     -1.0304149884070535e-01
    phi[6,8]  R2537     -8.0612596344710763e-01
    phi[6,8]  R2538     -9.2597530586335330e-01
    phi[6,8]  R2539     -2.0188019427320931e+00
    phi[6,8]  R2540     -5.3290643317452480e-02
    phi[6,8]  R2541     -1.5184261289753476e-01
    phi[6,8]  R2542     -1.7428636257216512e-01
    phi[6,8]  R2543     -3.1960747590424576e-01
    phi[6,8]  R2544     -9.4352855854836426e-01
    phi[6,8]  R2545     -3.9258379007966648e-01
    phi[6,8]  R2546     -1.3976009246692687e+00
    phi[6,8]  R2547     -1.6592893618053788e+00
    phi[6,8]  R2548     -6.0151947074580514e-01
    phi[6,8]  R2549     -7.1280074441329222e-01
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R65       -1
    z[0,1,0]  R66       1
    z[0,1,0]  R79       2.8651472926139832e-01
    z[0,1,0]  R80       1.2795411050319672e-01
    z[0,1,0]  R81       -8.7496735155582428e-02
    z[0,1,0]  R82       -3.7960651516914368e-01
    z[0,1,0]  R83       -2.4253386259078979e-01
    z[0,1,0]  R84       8.3142615854740143e-02
    z[0,1,0]  R85       -6.1582762002944946e-01
    z[0,1,0]  R86       2.8442075848579407e-01
    z[0,1,0]  R87       -4.0650427341461182e-01
    z[0,1,0]  R88       -4.3040949106216431e-01
    z[0,1,0]  R89       -7.8000795841217041e-01
    z[0,1,0]  R90       4.7225859016180038e-02
    z[0,1,0]  R91       2.8592804074287415e-01
    z[0,1,0]  R92       -6.8026143312454224e-01
    z[0,1,0]  R93       -5.5497133731842041e-01
    z[0,1,0]  R94       -6.2856096029281616e-01
    z[0,1,0]  R95       -5.0041484832763672e-01
    z[0,1,0]  R96       -6.2581396102905273e-01
    z[0,1,0]  R97       -5.3726291656494141e-01
    z[0,1,0]  R98       7.4985343217849731e-01
    z[0,1,0]  R99       -1.3760386407375336e-01
    z[0,1,0]  R100      7.8818231821060181e-01
    z[0,1,0]  R101      -3.8373938202857971e-01
    z[0,1,0]  R102      -7.6504886150360107e-01
    z[0,1,0]  R103      0.883021354675293
    z[0,1,0]  R104      7.5968778133392334e-01
    z[0,1,0]  R105      8.4968453645706177e-01
    z[0,1,0]  R106      0.728162944316864
    z[0,1,0]  R107      9.3186068534851074e-01
    z[0,1,0]  R108      6.3493967056274414e-01
    z[0,1,0]  R109      2.9498443007469177e-01
    z[0,1,0]  R110      1.0823281109333038e-01
    z[0,1,0]  R111      -3.8759079575538635e-01
    z[0,1,0]  R112      -8.3277545869350433e-02
    z[0,1,0]  R113      -2.6885583996772766e-01
    z[0,1,0]  R114      -1.9437973201274872e-01
    z[0,1,0]  R115      -6.0521680116653442e-01
    z[0,1,0]  R116      0.221168652176857
    z[0,1,0]  R117      -7.8391057252883911e-01
    z[0,1,0]  R118      -6.4032828807830811e-01
    z[0,1,0]  R119      -3.9301496744155884e-01
    z[0,1,0]  R120      -1.1683456832543015e-03
    z[0,1,0]  R121      -6.9850414991378784e-01
    z[0,1,0]  R122      8.0699104070663452e-01
    z[0,1,0]  R123      5.5868566036224365e-01
    z[0,1,0]  R124      7.2400557994842529e-01
    z[0,1,0]  R125      5.9400999546051025e-01
    z[0,1,0]  R126      5.1288783550262451e-01
    z[0,1,0]  R127      8.6062455177307129e-01
    z[0,1,0]  R128      7.6770633459091187e-01
    z[0,1,0]  R129      6.1083510518074036e-02
    z[0,1,0]  R130      2.1380166709423065e-01
    z[0,1,0]  R131      -7.3983520269393921e-01
    z[0,1,0]  R132      2.5135216116905212e-01
    z[0,1,0]  R133      8.9019227027893066e-01
    z[0,1,0]  R134      8.5609972476959229e-01
    z[0,1,0]  R135      -4.3352678418159485e-02
    z[0,1,0]  R136      -2.3973140120506287e-01
    z[0,1,0]  R137      3.1451526284217834e-01
    z[0,1,0]  R138      5.4635588079690933e-02
    z[0,1,0]  R139      3.8354450464248657e-01
    z[0,1,0]  R140      3.0896863341331482e-01
    z[0,1,0]  R141      7.9854726791381836e-02
    z[0,1,0]  R142      -2.5239627808332443e-02
    z[0,1,0]  R143      2.7237203717231750e-01
    z[0,1,0]  R144      -3.5902258753776550e-01
    z[0,1,0]  R145      -2.9740709066390991e-01
    z[0,1,0]  R146      -4.5330911874771118e-02
    z[0,1,0]  R147      -3.8903504610061646e-01
    z[0,1,0]  R148      -1.7127676308155060e-01
    z[0,1,0]  R149      6.3217975199222565e-02
    z[0,1,0]  R150      -1.8302571773529053e-01
    z[0,1,0]  R151      -4.7933542728424072e-01
    z[0,1,0]  R152      3.4628391265869141e-01
    z[0,1,0]  R153      2.0839316770434380e-02
    z[0,1,0]  R154      1.1791638284921646e-01
    z[0,1,0]  R155      -5.6895387172698975e-01
    z[0,1,0]  R156      1.9080510735511780e-01
    z[0,1,0]  R157      -2.1374617516994476e-01
    z[0,1,0]  R158      -0.562109112739563
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R67       -1
    z[0,1,1]  R68       1
    z[0,1,1]  R79       1.8928368389606476e-01
    z[0,1,1]  R80       -2.1338941156864166e-01
    z[0,1,1]  R81       -3.8782188296318054e-01
    z[0,1,1]  R82       -3.3455827832221985e-01
    z[0,1,1]  R83       -1.8127226829528809e-01
    z[0,1,1]  R84       5.7150256633758545e-01
    z[0,1,1]  R85       -4.0909606218338013e-01
    z[0,1,1]  R86       3.9326825737953186e-01
    z[0,1,1]  R87       -3.2245048880577087e-01
    z[0,1,1]  R88       1.5870548784732819e-01
    z[0,1,1]  R89       1.9267785549163818e-01
    z[0,1,1]  R90       2.7879431843757629e-01
    z[0,1,1]  R91       4.3742680549621582e-01
    z[0,1,1]  R92       5.0138658285140991e-01
    z[0,1,1]  R93       2.9762953519821167e-01
    z[0,1,1]  R94       2.5165641307830811e-01
    z[0,1,1]  R95       4.4293156266212463e-01
    z[0,1,1]  R96       5.9310346841812134e-01
    z[0,1,1]  R97       3.6480927467346191e-01
    z[0,1,1]  R98       -4.7468325495719910e-01
    z[0,1,1]  R99       4.5324820280075073e-01
    z[0,1,1]  R100      4.3186369538307190e-01
    z[0,1,1]  R101      -1.9462096691131592e-01
    z[0,1,1]  R102      -3.0049049854278564e-01
    z[0,1,1]  R103      -3.4105396270751953e-01
    z[0,1,1]  R104      -4.4918251037597656e-01
    z[0,1,1]  R105      -4.4155994057655334e-01
    z[0,1,1]  R106      -0.372814804315567
    z[0,1,1]  R107      5.1849503070116043e-02
    z[0,1,1]  R108      -6.5198218822479248e-01
    z[0,1,1]  R109      9.6570156514644623e-02
    z[0,1,1]  R110      3.3297258615493774e-01
    z[0,1,1]  R111      5.8803703635931015e-02
    z[0,1,1]  R112      2.9408693313598633e-02
    z[0,1,1]  R113      -2.7275240421295166e-01
    z[0,1,1]  R114      4.1085100173950195e-01
    z[0,1,1]  R115      -4.9133521318435669e-01
    z[0,1,1]  R116      6.2088662385940552e-01
    z[0,1,1]  R117      -5.6678557395935059e-01
    z[0,1,1]  R118      -3.5645613074302673e-01
    z[0,1,1]  R119      1.5330517292022705e-01
    z[0,1,1]  R120      6.5617656707763672e-01
    z[0,1,1]  R121      -4.7061309218406677e-01
    z[0,1,1]  R122      -4.6602806448936462e-01
    z[0,1,1]  R123      -7.6760894060134888e-01
    z[0,1,1]  R124      -5.4526710510253906e-01
    z[0,1,1]  R125      -5.2219486236572266e-01
    z[0,1,1]  R126      -5.5512249469757080e-01
    z[0,1,1]  R127      -8.9052587747573853e-02
    z[0,1,1]  R128      9.1685699298977852e-03
    z[0,1,1]  R129      5.9199923276901245e-01
    z[0,1,1]  R130      -1.7263798415660858e-01
    z[0,1,1]  R131      6.1789894104003906e-01
    z[0,1,1]  R132      2.8438141942024231e-01
    z[0,1,1]  R133      -3.3239364624023438e-01
    z[0,1,1]  R134      -2.8496605157852173e-01
    z[0,1,1]  R135      3.6099424958229065e-01
    z[0,1,1]  R136      0.552646815776825
    z[0,1,1]  R137      -8.3604240417480469e-01
    z[0,1,1]  R138      4.0312197804450989e-01
    z[0,1,1]  R139      7.0076704025268555e-01
    z[0,1,1]  R140      5.3063219785690308e-01
    z[0,1,1]  R141      -1.3068813085556030e-01
    z[0,1,1]  R142      -7.0500189065933228e-01
    z[0,1,1]  R143      -0.484901487827301
    z[0,1,1]  R144      -7.5998403131961823e-02
    z[0,1,1]  R145      5.8496486395597458e-02
    z[0,1,1]  R146      -7.3956793546676636e-01
    z[0,1,1]  R147      -1.9420027732849121e-02
    z[0,1,1]  R148      -6.9828546047210693e-01
    z[0,1,1]  R149      4.2234563827514648e-01
    z[0,1,1]  R150      -2.5246351957321167e-01
    z[0,1,1]  R151      2.1436658501625061e-01
    z[0,1,1]  R152      -3.4335559606552124e-01
    z[0,1,1]  R153      4.6609568595886230e-01
    z[0,1,1]  R154      -5.4194486141204834e-01
    z[0,1,1]  R155      4.5076854526996613e-02
    z[0,1,1]  R156      -4.0479990839958191e-01
    z[0,1,1]  R157      7.3992349207401276e-02
    z[0,1,1]  R158      -5.0194181501865387e-02
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R69       -1
    z[0,1,2]  R70       1
    z[0,1,2]  R79       -9.1805821657180786e-01
    z[0,1,2]  R80       -0.821935772895813
    z[0,1,2]  R81       -8.4933263063430786e-01
    z[0,1,2]  R82       -6.5146356821060181e-01
    z[0,1,2]  R83       -8.2496714591979980e-01
    z[0,1,2]  R84       -4.8234471678733826e-01
    z[0,1,2]  R85       -4.8315051198005676e-01
    z[0,1,2]  R86       -6.1321413516998291e-01
    z[0,1,2]  R87       -4.4579333066940308e-01
    z[0,1,2]  R88       -1.8195107579231262e-01
    z[0,1,2]  R89       -4.0797176957130432e-01
    z[0,1,2]  R90       -4.8612919449806213e-01
    z[0,1,2]  R91       -4.4271695613861084e-01
    z[0,1,2]  R92       2.0488208532333374e-01
    z[0,1,2]  R93       0.0739821344614029
    z[0,1,2]  R94       -0.054900873452425
    z[0,1,2]  R95       1.4309750497341156e-01
    z[0,1,2]  R96       6.8344056606292725e-02
    z[0,1,2]  R97       5.7367127388715744e-02
    z[0,1,2]  R98       7.0916898548603058e-02
    z[0,1,2]  R99       -7.3335152864456177e-01
    z[0,1,2]  R100      -3.5523602366447449e-01
    z[0,1,2]  R101      -1.8880613148212433e-01
    z[0,1,2]  R102      -2.7876647189259529e-02
    z[0,1,2]  R103      5.2802741527557373e-02
    z[0,1,2]  R104      5.1044680178165436e-02
    z[0,1,2]  R105      -5.3460329771041870e-02
    z[0,1,2]  R106      1.0595314204692841e-01
    z[0,1,2]  R107      1.1621717363595963e-01
    z[0,1,2]  R108      1.0771667584776878e-02
    z[0,1,2]  R109      -9.1113615036010742e-01
    z[0,1,2]  R110      -7.7042216062545776e-01
    z[0,1,2]  R111      -2.3684878647327423e-01
    z[0,1,2]  R112      -4.8561313748359680e-01
    z[0,1,2]  R113      -8.5821944475173950e-01
    z[0,1,2]  R114      -5.4352372884750366e-01
    z[0,1,2]  R115      -4.0575563907623291e-01
    z[0,1,2]  R116      -4.2720615863800049e-01
    z[0,1,2]  R117      -0.0716678723692894
    z[0,1,2]  R118      4.5296527445316315e-02
    z[0,1,2]  R119      -7.2334235906600952e-01
    z[0,1,2]  R120      -1.6831138730049133e-01
    z[0,1,2]  R121      -1.8809004127979279e-01
    z[0,1,2]  R122      2.0423267781734467e-01
    z[0,1,2]  R123      1.1181588470935822e-01
    z[0,1,2]  R124      8.3945572376251221e-02
    z[0,1,2]  R125      1.3350541889667511e-01
    z[0,1,2]  R126      9.5891840755939484e-02
    z[0,1,2]  R127      1.0333411395549774e-01
    z[0,1,2]  R128      -6.6920608282089233e-02
    z[0,1,2]  R129      -2.7311458252370358e-03
    z[0,1,2]  R130      -4.7505609691143036e-02
    z[0,1,2]  R131      -1.6115337610244751e-01
    z[0,1,2]  R132      -1.4312425628304482e-02
    z[0,1,2]  R133      -7.1665213909000158e-05
    z[0,1,2]  R134      1.2088888138532639e-01
    z[0,1,2]  R135      -4.1242414154112339e-03
    z[0,1,2]  R136      -2.9520472511649132e-02
    z[0,1,2]  R137      -1.7982059717178345e-01
    z[0,1,2]  R138      8.2160130143165588e-02
    z[0,1,2]  R139      1.3549405336380005e-01
    z[0,1,2]  R140      -6.9270215928554535e-02
    z[0,1,2]  R141      -1.4978380501270294e-01
    z[0,1,2]  R142      5.1258418709039688e-02
    z[0,1,2]  R143      2.1003323793411255e-01
    z[0,1,2]  R144      1.7651681602001190e-01
    z[0,1,2]  R145      1.1088189668953419e-02
    z[0,1,2]  R146      7.0806264877319336e-02
    z[0,1,2]  R147      0.0782213807106018
    z[0,1,2]  R148      1.3924143277108669e-02
    z[0,1,2]  R149      -1.6303548216819763e-01
    z[0,1,2]  R150      -2.1536026149988174e-02
    z[0,1,2]  R151      -0.0760052353143692
    z[0,1,2]  R152      2.0098702609539032e-01
    z[0,1,2]  R153      -6.1345055699348450e-02
    z[0,1,2]  R154      -1.3458553701639175e-02
    z[0,1,2]  R155      3.7188690900802612e-01
    z[0,1,2]  R156      1.6649918258190155e-01
    z[0,1,2]  R157      6.5833173692226410e-02
    z[0,1,2]  R158      4.1337138414382935e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R71       -1
    z[0,1,3]  R72       1
    z[0,1,3]  R79       1.5316574275493622e-01
    z[0,1,3]  R80       4.1749465465545654e-01
    z[0,1,3]  R81       0.186690554022789
    z[0,1,3]  R82       3.3774030208587646e-01
    z[0,1,3]  R83       1.3193790614604950e-01
    z[0,1,3]  R84       1.9470538198947906e-01
    z[0,1,3]  R85       1.0244677215814590e-01
    z[0,1,3]  R86       1.1966568231582642e-01
    z[0,1,3]  R87       0.0622292086482048
    z[0,1,3]  R88       7.1319645643234253e-01
    z[0,1,3]  R89       2.9348948597908020e-01
    z[0,1,3]  R90       7.8819316625595093e-01
    z[0,1,3]  R91       5.9231573343276978e-01
    z[0,1,3]  R92       -3.0174779891967773e-01
    z[0,1,3]  R93       -7.2141259908676147e-01
    z[0,1,3]  R94       5.9243249893188477e-01
    z[0,1,3]  R95       -4.7260278463363647e-01
    z[0,1,3]  R96       -3.9112648367881775e-01
    z[0,1,3]  R97       -6.0366153717041016e-01
    z[0,1,3]  R98       1.7625359818339348e-02
    z[0,1,3]  R99       -1.7079292237758636e-01
    z[0,1,3]  R100      1.3907326757907867e-01
    z[0,1,3]  R101      6.0492914915084839e-01
    z[0,1,3]  R102      7.4371442198753357e-02
    z[0,1,3]  R103      -2.2594090551137924e-02
    z[0,1,3]  R104      -2.0540507137775421e-01
    z[0,1,3]  R105      -4.4240858405828476e-02
    z[0,1,3]  R106      0.419666588306427
    z[0,1,3]  R107      -8.7730005383491516e-02
    z[0,1,3]  R108      4.6109583228826523e-02
    z[0,1,3]  R109      2.3920443654060364e-01
    z[0,1,3]  R110      3.2978153228759766e-01
    z[0,1,3]  R111      8.0333340167999268e-01
    z[0,1,3]  R112      6.1041784286499023e-01
    z[0,1,3]  R113      3.6767061799764633e-02
    z[0,1,3]  R114      1.4024442434310913e-01
    z[0,1,3]  R115      1.7614370584487915e-01
    z[0,1,3]  R116      1.7516884207725525e-01
    z[0,1,3]  R117      0.0334952250123024
    z[0,1,3]  R118      5.9051042795181274e-01
    z[0,1,3]  R119      5.4493576288223267e-01
    z[0,1,3]  R120      5.3646290302276611e-01
    z[0,1,3]  R121      8.6003012955188751e-02
    z[0,1,3]  R122      -9.1377347707748413e-02
    z[0,1,3]  R123      -8.2541637122631073e-02
    z[0,1,3]  R124      3.1068651005625725e-02
    z[0,1,3]  R125      3.6152434349060059e-01
    z[0,1,3]  R126      4.2539575695991516e-01
    z[0,1,3]  R127      3.7138289213180542e-01
    z[0,1,3]  R128      -4.5978936553001404e-01
    z[0,1,3]  R129      4.5125576853752136e-01
    z[0,1,3]  R130      -6.9074326753616333e-01
    z[0,1,3]  R131      1.8896495923399925e-02
    z[0,1,3]  R132      0.397897869348526
    z[0,1,3]  R133      8.4381639957427979e-02
    z[0,1,3]  R134      3.5591584444046021e-01
    z[0,1,3]  R135      9.2086660861968994e-01
    z[0,1,3]  R136      -3.1765013933181763e-01
    z[0,1,3]  R137      1.0727182030677795e-01
    z[0,1,3]  R138      3.9924341440200806e-01
    z[0,1,3]  R139      -1.9374012947082520e-01
    z[0,1,3]  R140      -2.3194399476051331e-01
    z[0,1,3]  R141      -8.7596736848354340e-02
    z[0,1,3]  R142      3.3047983050346375e-01
    z[0,1,3]  R143      2.3281952738761902e-01
    z[0,1,3]  R144      -5.7619011402130127e-01
    z[0,1,3]  R145      -7.4140834808349609e-01
    z[0,1,3]  R146      4.0285822749137878e-01
    z[0,1,3]  R147      -2.5792804360389709e-01
    z[0,1,3]  R148      3.4212014079093933e-01
    z[0,1,3]  R149      2.5536033511161804e-01
    z[0,1,3]  R150      -1.9580744206905365e-02
    z[0,1,3]  R151      5.1058417558670044e-01
    z[0,1,3]  R152      5.7484978437423706e-01
    z[0,1,3]  R153      -2.0147246122360229e-01
    z[0,1,3]  R154      6.7178118228912354e-01
    z[0,1,3]  R155      -5.1815766096115112e-01
    z[0,1,3]  R156      6.8073445558547974e-01
    z[0,1,3]  R157      -6.5127015113830566e-01
    z[0,1,3]  R158      -2.6127964258193970e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R73       -1
    z[0,1,4]  R74       1
    z[0,1,4]  R79       -3.3535573631525040e-02
    z[0,1,4]  R80       -4.9515273422002792e-02
    z[0,1,4]  R81       -2.0375768840312958e-01
    z[0,1,4]  R82       -1.8227109313011169e-01
    z[0,1,4]  R83       -4.5663446187973022e-02
    z[0,1,4]  R84       -1.9856976345181465e-02
    z[0,1,4]  R85       9.8871342837810516e-02
    z[0,1,4]  R86       -7.6052442193031311e-02
    z[0,1,4]  R87       -1.4914900064468384e-01
    z[0,1,4]  R88       2.7532947063446045e-01
    z[0,1,4]  R89       2.2536313533782959e-01
    z[0,1,4]  R90       -1.7508116364479065e-01
    z[0,1,4]  R91       2.4778442084789276e-01
    z[0,1,4]  R92       3.5196027159690857e-01
    z[0,1,4]  R93       2.5746414065361023e-01
    z[0,1,4]  R94       -1.8810817599296570e-01
    z[0,1,4]  R95       2.8861114382743835e-01
    z[0,1,4]  R96       -7.0296205580234528e-02
    z[0,1,4]  R97       5.1523327827453613e-02
    z[0,1,4]  R98       -3.2622924447059631e-01
    z[0,1,4]  R99       3.3899492025375366e-01
    z[0,1,4]  R100      2.0529222674667835e-03
    z[0,1,4]  R101      -4.2526370286941528e-01
    z[0,1,4]  R102      -3.6457857489585876e-01
    z[0,1,4]  R103      -1.7739592492580414e-01
    z[0,1,4]  R104      2.1899169683456421e-01
    z[0,1,4]  R105      2.4537268280982971e-01
    z[0,1,4]  R106      7.0082515478134155e-02
    z[0,1,4]  R107      1.8526118993759155e-01
    z[0,1,4]  R108      -2.6621100306510925e-01
    z[0,1,4]  R109      3.3498089760541916e-02
    z[0,1,4]  R110      -2.4963997304439545e-01
    z[0,1,4]  R111      1.4572843909263611e-01
    z[0,1,4]  R112      -2.4555815756320953e-01
    z[0,1,4]  R113      2.2103634476661682e-01
    z[0,1,4]  R114      2.6744395494461060e-01
    z[0,1,4]  R115      -2.2378663718700409e-01
    z[0,1,4]  R116      8.9534647762775421e-02
    z[0,1,4]  R117      -1.6200336813926697e-01
    z[0,1,4]  R118      -3.2173395156860352e-01
    z[0,1,4]  R119      -1.8126342445611954e-02
    z[0,1,4]  R120      -0.0687897801399231
    z[0,1,4]  R121      -1.0060327500104904e-01
    z[0,1,4]  R122      1.4072653651237488e-01
    z[0,1,4]  R123      -0.217131569981575
    z[0,1,4]  R124      -3.9464724063873291e-01
    z[0,1,4]  R125      -7.1288503706455231e-02
    z[0,1,4]  R126      -0.252402663230896
    z[0,1,4]  R127      1.7273065447807312e-01
    z[0,1,4]  R128      -4.5735105872154236e-02
    z[0,1,4]  R129      -2.0377385616302490e-01
    z[0,1,4]  R130      -1.9554647803306580e-01
    z[0,1,4]  R131      -7.1302741765975952e-02
    z[0,1,4]  R132      -7.4175751209259033e-01
    z[0,1,4]  R133      -1.1411214619874954e-01
    z[0,1,4]  R134      -0.0604756623506546
    z[0,1,4]  R135      0.00889661442488432
    z[0,1,4]  R136      -7.1751803159713745e-01
    z[0,1,4]  R137      -1.9821767508983612e-01
    z[0,1,4]  R138      -7.7603662014007568e-01
    z[0,1,4]  R139      4.3331223726272583e-01
    z[0,1,4]  R140      3.2113659381866455e-01
    z[0,1,4]  R141      5.2670681476593018e-01
    z[0,1,4]  R142      -1.4285834133625031e-01
    z[0,1,4]  R143      -3.8055914640426636e-01
    z[0,1,4]  R144      3.7265902757644653e-01
    z[0,1,4]  R145      3.3615803718566895e-01
    z[0,1,4]  R146      -0.0842844620347023
    z[0,1,4]  R147      5.2886521816253662e-01
    z[0,1,4]  R148      -5.4532349109649658e-01
    z[0,1,4]  R149      3.8011528551578522e-02
    z[0,1,4]  R150      5.9980505704879761e-01
    z[0,1,4]  R151      -3.1217586994171143e-01
    z[0,1,4]  R152      -1.8894271552562714e-01
    z[0,1,4]  R153      7.1065044403076172e-01
    z[0,1,4]  R154      -1.7832717299461365e-01
    z[0,1,4]  R155      2.9451239109039307e-01
    z[0,1,4]  R156      2.1173436939716339e-01
    z[0,1,4]  R157      2.8134658932685852e-01
    z[0,1,4]  R158      2.1854051947593689e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R75       -1
    z[0,1,5]  R76       1
    z[0,1,5]  R79       9.2932768166065216e-02
    z[0,1,5]  R80       -1.8901444971561432e-01
    z[0,1,5]  R81       -2.1008993685245514e-01
    z[0,1,5]  R82       4.0209561586380005e-01
    z[0,1,5]  R83       2.2197328507900238e-01
    z[0,1,5]  R84       -1.7166697978973389e-01
    z[0,1,5]  R85       4.3754315376281738e-01
    z[0,1,5]  R86       -5.9859317541122437e-01
    z[0,1,5]  R87       -5.3073191642761230e-01
    z[0,1,5]  R88       1.7103178799152374e-01
    z[0,1,5]  R89       -2.0624138414859772e-01
    z[0,1,5]  R90       1.7194516956806183e-01
    z[0,1,5]  R91       1.0926352441310883e-01
    z[0,1,5]  R92       1.5449135005474091e-01
    z[0,1,5]  R93       -5.7839006185531616e-02
    z[0,1,5]  R94       2.7391710877418518e-01
    z[0,1,5]  R95       3.9220470190048218e-01
    z[0,1,5]  R96       -6.0699041932821274e-02
    z[0,1,5]  R97       2.8945362567901611e-01
    z[0,1,5]  R98       -2.8680872172117233e-02
    z[0,1,5]  R99       -3.0305898189544678e-01
    z[0,1,5]  R100      2.1535551548004150e-01
    z[0,1,5]  R101      -4.5871835947036743e-01
    z[0,1,5]  R102      8.2992248237133026e-02
    z[0,1,5]  R103      2.2274820506572723e-01
    z[0,1,5]  R104      3.8611114025115967e-02
    z[0,1,5]  R105      -1.0222090035676956e-01
    z[0,1,5]  R106      3.6876723170280457e-01
    z[0,1,5]  R107      -2.4792829155921936e-01
    z[0,1,5]  R108      2.7647942304611206e-01
    z[0,1,5]  R109      9.5163963735103607e-02
    z[0,1,5]  R110      4.6929683536291122e-02
    z[0,1,5]  R111      5.9022769331932068e-02
    z[0,1,5]  R112      -5.6864005327224731e-01
    z[0,1,5]  R113      7.8296266496181488e-02
    z[0,1,5]  R114      6.3668382167816162e-01
    z[0,1,5]  R115      -3.7976327538490295e-01
    z[0,1,5]  R116      5.5324655771255493e-01
    z[0,1,5]  R117      -5.7667877525091171e-02
    z[0,1,5]  R118      -0.0557275153696537
    z[0,1,5]  R119      3.4259703010320663e-02
    z[0,1,5]  R120      -4.8903831839561462e-01
    z[0,1,5]  R121      -3.9436902850866318e-02
    z[0,1,5]  R122      -1.8040984869003296e-01
    z[0,1,5]  R123      -1.4283163845539093e-01
    z[0,1,5]  R124      -1.1372285336256027e-01
    z[0,1,5]  R125      0.0759860947728157
    z[0,1,5]  R126      3.4039494395256042e-01
    z[0,1,5]  R127      -1.7409792542457581e-01
    z[0,1,5]  R128      -4.3879696726799011e-01
    z[0,1,5]  R129      -5.3726172447204590e-01
    z[0,1,5]  R130      -0.626187801361084
    z[0,1,5]  R131      -1.6882559657096863e-01
    z[0,1,5]  R132      -3.3339250087738037e-01
    z[0,1,5]  R133      3.3609855920076370e-02
    z[0,1,5]  R134      -1.6285820305347443e-01
    z[0,1,5]  R135      2.5512970983982086e-02
    z[0,1,5]  R136      1.5018879203125834e-03
    z[0,1,5]  R137      -2.9831105470657349e-01
    z[0,1,5]  R138      1.9834114611148834e-01
    z[0,1,5]  R139      3.3949002623558044e-01
    z[0,1,5]  R140      -1.5337635576725006e-01
    z[0,1,5]  R141      -2.4938280880451202e-01
    z[0,1,5]  R142      5.6400257349014282e-01
    z[0,1,5]  R143      4.6394929289817810e-01
    z[0,1,5]  R144      4.4545814394950867e-01
    z[0,1,5]  R145      4.8621088266372681e-01
    z[0,1,5]  R146      -6.7275539040565491e-02
    z[0,1,5]  R147      5.4848223924636841e-01
    z[0,1,5]  R148      -4.6977987512946129e-03
    z[0,1,5]  R149      -4.5693108439445496e-01
    z[0,1,5]  R150      -4.5982575416564941e-01
    z[0,1,5]  R151      4.6194070577621460e-01
    z[0,1,5]  R152      5.6908661127090454e-01
    z[0,1,5]  R153      -4.7468963265419006e-01
    z[0,1,5]  R154      1.0996001958847046e-01
    z[0,1,5]  R155      3.1893891096115112e-01
    z[0,1,5]  R156      3.3318656682968140e-01
    z[0,1,5]  R157      1.6710844635963440e-01
    z[0,1,5]  R158      6.1378264427185059e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R77       -1
    z[0,1,6]  R78       1
    z[0,1,6]  R79       -7.7646985650062561e-02
    z[0,1,6]  R80       2.2368364036083221e-01
    z[0,1,6]  R81       -0.00801405031234026
    z[0,1,6]  R82       -1.0292106121778488e-01
    z[0,1,6]  R83       -3.9872547984123230e-01
    z[0,1,6]  R84       -6.0501378774642944e-01
    z[0,1,6]  R85       9.0815395116806030e-02
    z[0,1,6]  R86       -9.9978566169738770e-02
    z[0,1,6]  R87       -4.7355449199676514e-01
    z[0,1,6]  R88       3.7781819701194763e-01
    z[0,1,6]  R89       9.2529594898223877e-02
    z[0,1,6]  R90       -4.7485128045082092e-02
    z[0,1,6]  R91       3.2669717073440552e-01
    z[0,1,6]  R92       7.1300998330116272e-02
    z[0,1,6]  R93       -8.8774301111698151e-02
    z[0,1,6]  R94       -0.277802973985672
    z[0,1,6]  R95       -2.6915711164474487e-01
    z[0,1,6]  R96       -3.0051326751708984e-01
    z[0,1,6]  R97       -3.5231578350067139e-01
    z[0,1,6]  R98       -3.1592342257499695e-01
    z[0,1,6]  R99       4.3523173779249191e-02
    z[0,1,6]  R100      -1.8603503704071045e-02
    z[0,1,6]  R101      -1.4835110306739807e-01
    z[0,1,6]  R102      -4.2224639654159546e-01
    z[0,1,6]  R103      1.3989524543285370e-01
    z[0,1,6]  R104      3.5618028044700623e-01
    z[0,1,6]  R105      0.0871143639087677
    z[0,1,6]  R106      5.0407934933900833e-02
    z[0,1,6]  R107      1.0933487862348557e-01
    z[0,1,6]  R108      1.4906217157840729e-01
    z[0,1,6]  R109      7.8052692115306854e-02
    z[0,1,6]  R110      -3.3254516124725342e-01
    z[0,1,6]  R111      3.4663116931915283e-01
    z[0,1,6]  R112      1.0936836712062359e-02
    z[0,1,6]  R113      2.4585144221782684e-01
    z[0,1,6]  R114      -0.0379331074655056
    z[0,1,6]  R115      -4.8347041010856628e-02
    z[0,1,6]  R116      -1.9569578766822815e-01
    z[0,1,6]  R117      -1.6855119168758392e-01
    z[0,1,6]  R118      -7.4472457170486450e-02
    z[0,1,6]  R119      -1.8850931897759438e-02
    z[0,1,6]  R120      -9.7053229808807373e-02
    z[0,1,6]  R121      -4.8596754670143127e-01
    z[0,1,6]  R122      -1.7079439759254456e-01
    z[0,1,6]  R123      -1.0855325311422348e-01
    z[0,1,6]  R124      4.2523756623268127e-02
    z[0,1,6]  R125      4.6377268433570862e-01
    z[0,1,6]  R126      0.243007093667984
    z[0,1,6]  R127      2.0650866627693176e-01
    z[0,1,6]  R128      4.8855948261916637e-03
    z[0,1,6]  R129      -3.3465293049812317e-01
    z[0,1,6]  R130      -1.2145908921957016e-01
    z[0,1,6]  R131      -1.0455239564180374e-01
    z[0,1,6]  R132      1.8991325795650482e-01
    z[0,1,6]  R133      -2.7531927824020386e-01
    z[0,1,6]  R134      1.2007252871990204e-01
    z[0,1,6]  R135      1.3806284964084625e-01
    z[0,1,6]  R136      -1.4318844676017761e-01
    z[0,1,6]  R137      1.7317837476730347e-01
    z[0,1,6]  R138      -1.6367603838443756e-01
    z[0,1,6]  R139      -5.3965445607900620e-02
    z[0,1,6]  R140      6.6160291433334351e-01
    z[0,1,6]  R141      7.7898889780044556e-01
    z[0,1,6]  R142      2.2799883782863617e-01
    z[0,1,6]  R143      -4.8196563124656677e-01
    z[0,1,6]  R144      -4.0603697299957275e-01
    z[0,1,6]  R145      9.4417795538902283e-02
    z[0,1,6]  R146      -5.2158057689666748e-01
    z[0,1,6]  R147      4.4169902801513672e-01
    z[0,1,6]  R148      -2.6157552003860474e-01
    z[0,1,6]  R149      7.1805804967880249e-01
    z[0,1,6]  R150      -5.7507455348968506e-01
    z[0,1,6]  R151      3.8336464762687683e-01
    z[0,1,6]  R152      -1.7829042673110962e-01
    z[0,1,6]  R153      -8.7246164679527283e-02
    z[0,1,6]  R154      4.4387900829315186e-01
    z[0,1,6]  R155      2.8109195828437805e-01
    z[0,1,6]  R156      -3.9085072278976440e-01
    z[0,1,6]  R157      -6.4286071062088013e-01
    z[0,1,6]  R158      -1.3372294604778290e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R159      -1
    z[1,0,0]  R160      1
    z[1,0,0]  R173      6.1083510518074036e-02
    z[1,0,0]  R174      2.1380166709423065e-01
    z[1,0,0]  R175      -7.3983520269393921e-01
    z[1,0,0]  R176      2.5135216116905212e-01
    z[1,0,0]  R177      8.9019227027893066e-01
    z[1,0,0]  R178      8.5609972476959229e-01
    z[1,0,0]  R179      -4.3352678418159485e-02
    z[1,0,0]  R180      -2.3973140120506287e-01
    z[1,0,0]  R181      3.1451526284217834e-01
    z[1,0,0]  R182      5.4635588079690933e-02
    z[1,0,0]  R183      3.8354450464248657e-01
    z[1,0,0]  R184      3.0896863341331482e-01
    z[1,0,0]  R185      7.9854726791381836e-02
    z[1,0,0]  R186      -2.5239627808332443e-02
    z[1,0,0]  R187      2.7237203717231750e-01
    z[1,0,0]  R188      -3.5902258753776550e-01
    z[1,0,0]  R189      -2.9740709066390991e-01
    z[1,0,0]  R190      -4.5330911874771118e-02
    z[1,0,0]  R191      -3.8903504610061646e-01
    z[1,0,0]  R192      -1.7127676308155060e-01
    z[1,0,0]  R193      6.3217975199222565e-02
    z[1,0,0]  R194      -1.8302571773529053e-01
    z[1,0,0]  R195      -4.7933542728424072e-01
    z[1,0,0]  R196      3.4628391265869141e-01
    z[1,0,0]  R197      2.0839316770434380e-02
    z[1,0,0]  R198      1.1791638284921646e-01
    z[1,0,0]  R199      -5.6895387172698975e-01
    z[1,0,0]  R200      1.9080510735511780e-01
    z[1,0,0]  R201      -2.1374617516994476e-01
    z[1,0,0]  R202      -0.562109112739563
    z[1,0,0]  R203      2.8651472926139832e-01
    z[1,0,0]  R204      1.2795411050319672e-01
    z[1,0,0]  R205      -8.7496735155582428e-02
    z[1,0,0]  R206      -3.7960651516914368e-01
    z[1,0,0]  R207      -2.4253386259078979e-01
    z[1,0,0]  R208      8.3142615854740143e-02
    z[1,0,0]  R209      -6.1582762002944946e-01
    z[1,0,0]  R210      2.8442075848579407e-01
    z[1,0,0]  R211      -4.0650427341461182e-01
    z[1,0,0]  R212      -4.3040949106216431e-01
    z[1,0,0]  R213      -7.8000795841217041e-01
    z[1,0,0]  R214      4.7225859016180038e-02
    z[1,0,0]  R215      2.8592804074287415e-01
    z[1,0,0]  R216      -6.8026143312454224e-01
    z[1,0,0]  R217      -5.5497133731842041e-01
    z[1,0,0]  R218      -6.2856096029281616e-01
    z[1,0,0]  R219      -5.0041484832763672e-01
    z[1,0,0]  R220      -6.2581396102905273e-01
    z[1,0,0]  R221      -5.3726291656494141e-01
    z[1,0,0]  R222      7.4985343217849731e-01
    z[1,0,0]  R223      -1.3760386407375336e-01
    z[1,0,0]  R224      7.8818231821060181e-01
    z[1,0,0]  R225      -3.8373938202857971e-01
    z[1,0,0]  R226      -7.6504886150360107e-01
    z[1,0,0]  R227      0.883021354675293
    z[1,0,0]  R228      7.5968778133392334e-01
    z[1,0,0]  R229      8.4968453645706177e-01
    z[1,0,0]  R230      0.728162944316864
    z[1,0,0]  R231      9.3186068534851074e-01
    z[1,0,0]  R232      6.3493967056274414e-01
    z[1,0,0]  R233      2.9498443007469177e-01
    z[1,0,0]  R234      1.0823281109333038e-01
    z[1,0,0]  R235      -3.8759079575538635e-01
    z[1,0,0]  R236      -8.3277545869350433e-02
    z[1,0,0]  R237      -2.6885583996772766e-01
    z[1,0,0]  R238      -1.9437973201274872e-01
    z[1,0,0]  R239      -6.0521680116653442e-01
    z[1,0,0]  R240      0.221168652176857
    z[1,0,0]  R241      -7.8391057252883911e-01
    z[1,0,0]  R242      -6.4032828807830811e-01
    z[1,0,0]  R243      -3.9301496744155884e-01
    z[1,0,0]  R244      -1.1683456832543015e-03
    z[1,0,0]  R245      -6.9850414991378784e-01
    z[1,0,0]  R246      8.0699104070663452e-01
    z[1,0,0]  R247      5.5868566036224365e-01
    z[1,0,0]  R248      7.2400557994842529e-01
    z[1,0,0]  R249      5.9400999546051025e-01
    z[1,0,0]  R250      5.1288783550262451e-01
    z[1,0,0]  R251      8.6062455177307129e-01
    z[1,0,0]  R252      7.6770633459091187e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R161      -1
    z[1,0,1]  R162      1
    z[1,0,1]  R173      5.9199923276901245e-01
    z[1,0,1]  R174      -1.7263798415660858e-01
    z[1,0,1]  R175      6.1789894104003906e-01
    z[1,0,1]  R176      2.8438141942024231e-01
    z[1,0,1]  R177      -3.3239364624023438e-01
    z[1,0,1]  R178      -2.8496605157852173e-01
    z[1,0,1]  R179      3.6099424958229065e-01
    z[1,0,1]  R180      0.552646815776825
    z[1,0,1]  R181      -8.3604240417480469e-01
    z[1,0,1]  R182      4.0312197804450989e-01
    z[1,0,1]  R183      7.0076704025268555e-01
    z[1,0,1]  R184      5.3063219785690308e-01
    z[1,0,1]  R185      -1.3068813085556030e-01
    z[1,0,1]  R186      -7.0500189065933228e-01
    z[1,0,1]  R187      -0.484901487827301
    z[1,0,1]  R188      -7.5998403131961823e-02
    z[1,0,1]  R189      5.8496486395597458e-02
    z[1,0,1]  R190      -7.3956793546676636e-01
    z[1,0,1]  R191      -1.9420027732849121e-02
    z[1,0,1]  R192      -6.9828546047210693e-01
    z[1,0,1]  R193      4.2234563827514648e-01
    z[1,0,1]  R194      -2.5246351957321167e-01
    z[1,0,1]  R195      2.1436658501625061e-01
    z[1,0,1]  R196      -3.4335559606552124e-01
    z[1,0,1]  R197      4.6609568595886230e-01
    z[1,0,1]  R198      -5.4194486141204834e-01
    z[1,0,1]  R199      4.5076854526996613e-02
    z[1,0,1]  R200      -4.0479990839958191e-01
    z[1,0,1]  R201      7.3992349207401276e-02
    z[1,0,1]  R202      -5.0194181501865387e-02
    z[1,0,1]  R203      1.8928368389606476e-01
    z[1,0,1]  R204      -2.1338941156864166e-01
    z[1,0,1]  R205      -3.8782188296318054e-01
    z[1,0,1]  R206      -3.3455827832221985e-01
    z[1,0,1]  R207      -1.8127226829528809e-01
    z[1,0,1]  R208      5.7150256633758545e-01
    z[1,0,1]  R209      -4.0909606218338013e-01
    z[1,0,1]  R210      3.9326825737953186e-01
    z[1,0,1]  R211      -3.2245048880577087e-01
    z[1,0,1]  R212      1.5870548784732819e-01
    z[1,0,1]  R213      1.9267785549163818e-01
    z[1,0,1]  R214      2.7879431843757629e-01
    z[1,0,1]  R215      4.3742680549621582e-01
    z[1,0,1]  R216      5.0138658285140991e-01
    z[1,0,1]  R217      2.9762953519821167e-01
    z[1,0,1]  R218      2.5165641307830811e-01
    z[1,0,1]  R219      4.4293156266212463e-01
    z[1,0,1]  R220      5.9310346841812134e-01
    z[1,0,1]  R221      3.6480927467346191e-01
    z[1,0,1]  R222      -4.7468325495719910e-01
    z[1,0,1]  R223      4.5324820280075073e-01
    z[1,0,1]  R224      4.3186369538307190e-01
    z[1,0,1]  R225      -1.9462096691131592e-01
    z[1,0,1]  R226      -3.0049049854278564e-01
    z[1,0,1]  R227      -3.4105396270751953e-01
    z[1,0,1]  R228      -4.4918251037597656e-01
    z[1,0,1]  R229      -4.4155994057655334e-01
    z[1,0,1]  R230      -0.372814804315567
    z[1,0,1]  R231      5.1849503070116043e-02
    z[1,0,1]  R232      -6.5198218822479248e-01
    z[1,0,1]  R233      9.6570156514644623e-02
    z[1,0,1]  R234      3.3297258615493774e-01
    z[1,0,1]  R235      5.8803703635931015e-02
    z[1,0,1]  R236      2.9408693313598633e-02
    z[1,0,1]  R237      -2.7275240421295166e-01
    z[1,0,1]  R238      4.1085100173950195e-01
    z[1,0,1]  R239      -4.9133521318435669e-01
    z[1,0,1]  R240      6.2088662385940552e-01
    z[1,0,1]  R241      -5.6678557395935059e-01
    z[1,0,1]  R242      -3.5645613074302673e-01
    z[1,0,1]  R243      1.5330517292022705e-01
    z[1,0,1]  R244      6.5617656707763672e-01
    z[1,0,1]  R245      -4.7061309218406677e-01
    z[1,0,1]  R246      -4.6602806448936462e-01
    z[1,0,1]  R247      -7.6760894060134888e-01
    z[1,0,1]  R248      -5.4526710510253906e-01
    z[1,0,1]  R249      -5.2219486236572266e-01
    z[1,0,1]  R250      -5.5512249469757080e-01
    z[1,0,1]  R251      -8.9052587747573853e-02
    z[1,0,1]  R252      9.1685699298977852e-03
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R163      -1
    z[1,0,2]  R164      1
    z[1,0,2]  R173      -2.7311458252370358e-03
    z[1,0,2]  R174      -4.7505609691143036e-02
    z[1,0,2]  R175      -1.6115337610244751e-01
    z[1,0,2]  R176      -1.4312425628304482e-02
    z[1,0,2]  R177      -7.1665213909000158e-05
    z[1,0,2]  R178      1.2088888138532639e-01
    z[1,0,2]  R179      -4.1242414154112339e-03
    z[1,0,2]  R180      -2.9520472511649132e-02
    z[1,0,2]  R181      -1.7982059717178345e-01
    z[1,0,2]  R182      8.2160130143165588e-02
    z[1,0,2]  R183      1.3549405336380005e-01
    z[1,0,2]  R184      -6.9270215928554535e-02
    z[1,0,2]  R185      -1.4978380501270294e-01
    z[1,0,2]  R186      5.1258418709039688e-02
    z[1,0,2]  R187      2.1003323793411255e-01
    z[1,0,2]  R188      1.7651681602001190e-01
    z[1,0,2]  R189      1.1088189668953419e-02
    z[1,0,2]  R190      7.0806264877319336e-02
    z[1,0,2]  R191      0.0782213807106018
    z[1,0,2]  R192      1.3924143277108669e-02
    z[1,0,2]  R193      -1.6303548216819763e-01
    z[1,0,2]  R194      -2.1536026149988174e-02
    z[1,0,2]  R195      -0.0760052353143692
    z[1,0,2]  R196      2.0098702609539032e-01
    z[1,0,2]  R197      -6.1345055699348450e-02
    z[1,0,2]  R198      -1.3458553701639175e-02
    z[1,0,2]  R199      3.7188690900802612e-01
    z[1,0,2]  R200      1.6649918258190155e-01
    z[1,0,2]  R201      6.5833173692226410e-02
    z[1,0,2]  R202      4.1337138414382935e-01
    z[1,0,2]  R203      -9.1805821657180786e-01
    z[1,0,2]  R204      -0.821935772895813
    z[1,0,2]  R205      -8.4933263063430786e-01
    z[1,0,2]  R206      -6.5146356821060181e-01
    z[1,0,2]  R207      -8.2496714591979980e-01
    z[1,0,2]  R208      -4.8234471678733826e-01
    z[1,0,2]  R209      -4.8315051198005676e-01
    z[1,0,2]  R210      -6.1321413516998291e-01
    z[1,0,2]  R211      -4.4579333066940308e-01
    z[1,0,2]  R212      -1.8195107579231262e-01
    z[1,0,2]  R213      -4.0797176957130432e-01
    z[1,0,2]  R214      -4.8612919449806213e-01
    z[1,0,2]  R215      -4.4271695613861084e-01
    z[1,0,2]  R216      2.0488208532333374e-01
    z[1,0,2]  R217      0.0739821344614029
    z[1,0,2]  R218      -0.054900873452425
    z[1,0,2]  R219      1.4309750497341156e-01
    z[1,0,2]  R220      6.8344056606292725e-02
    z[1,0,2]  R221      5.7367127388715744e-02
    z[1,0,2]  R222      7.0916898548603058e-02
    z[1,0,2]  R223      -7.3335152864456177e-01
    z[1,0,2]  R224      -3.5523602366447449e-01
    z[1,0,2]  R225      -1.8880613148212433e-01
    z[1,0,2]  R226      -2.7876647189259529e-02
    z[1,0,2]  R227      5.2802741527557373e-02
    z[1,0,2]  R228      5.1044680178165436e-02
    z[1,0,2]  R229      -5.3460329771041870e-02
    z[1,0,2]  R230      1.0595314204692841e-01
    z[1,0,2]  R231      1.1621717363595963e-01
    z[1,0,2]  R232      1.0771667584776878e-02
    z[1,0,2]  R233      -9.1113615036010742e-01
    z[1,0,2]  R234      -7.7042216062545776e-01
    z[1,0,2]  R235      -2.3684878647327423e-01
    z[1,0,2]  R236      -4.8561313748359680e-01
    z[1,0,2]  R237      -8.5821944475173950e-01
    z[1,0,2]  R238      -5.4352372884750366e-01
    z[1,0,2]  R239      -4.0575563907623291e-01
    z[1,0,2]  R240      -4.2720615863800049e-01
    z[1,0,2]  R241      -0.0716678723692894
    z[1,0,2]  R242      4.5296527445316315e-02
    z[1,0,2]  R243      -7.2334235906600952e-01
    z[1,0,2]  R244      -1.6831138730049133e-01
    z[1,0,2]  R245      -1.8809004127979279e-01
    z[1,0,2]  R246      2.0423267781734467e-01
    z[1,0,2]  R247      1.1181588470935822e-01
    z[1,0,2]  R248      8.3945572376251221e-02
    z[1,0,2]  R249      1.3350541889667511e-01
    z[1,0,2]  R250      9.5891840755939484e-02
    z[1,0,2]  R251      1.0333411395549774e-01
    z[1,0,2]  R252      -6.6920608282089233e-02
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R165      -1
    z[1,0,3]  R166      1
    z[1,0,3]  R173      4.5125576853752136e-01
    z[1,0,3]  R174      -6.9074326753616333e-01
    z[1,0,3]  R175      1.8896495923399925e-02
    z[1,0,3]  R176      0.397897869348526
    z[1,0,3]  R177      8.4381639957427979e-02
    z[1,0,3]  R178      3.5591584444046021e-01
    z[1,0,3]  R179      9.2086660861968994e-01
    z[1,0,3]  R180      -3.1765013933181763e-01
    z[1,0,3]  R181      1.0727182030677795e-01
    z[1,0,3]  R182      3.9924341440200806e-01
    z[1,0,3]  R183      -1.9374012947082520e-01
    z[1,0,3]  R184      -2.3194399476051331e-01
    z[1,0,3]  R185      -8.7596736848354340e-02
    z[1,0,3]  R186      3.3047983050346375e-01
    z[1,0,3]  R187      2.3281952738761902e-01
    z[1,0,3]  R188      -5.7619011402130127e-01
    z[1,0,3]  R189      -7.4140834808349609e-01
    z[1,0,3]  R190      4.0285822749137878e-01
    z[1,0,3]  R191      -2.5792804360389709e-01
    z[1,0,3]  R192      3.4212014079093933e-01
    z[1,0,3]  R193      2.5536033511161804e-01
    z[1,0,3]  R194      -1.9580744206905365e-02
    z[1,0,3]  R195      5.1058417558670044e-01
    z[1,0,3]  R196      5.7484978437423706e-01
    z[1,0,3]  R197      -2.0147246122360229e-01
    z[1,0,3]  R198      6.7178118228912354e-01
    z[1,0,3]  R199      -5.1815766096115112e-01
    z[1,0,3]  R200      6.8073445558547974e-01
    z[1,0,3]  R201      -6.5127015113830566e-01
    z[1,0,3]  R202      -2.6127964258193970e-01
    z[1,0,3]  R203      1.5316574275493622e-01
    z[1,0,3]  R204      4.1749465465545654e-01
    z[1,0,3]  R205      0.186690554022789
    z[1,0,3]  R206      3.3774030208587646e-01
    z[1,0,3]  R207      1.3193790614604950e-01
    z[1,0,3]  R208      1.9470538198947906e-01
    z[1,0,3]  R209      1.0244677215814590e-01
    z[1,0,3]  R210      1.1966568231582642e-01
    z[1,0,3]  R211      0.0622292086482048
    z[1,0,3]  R212      7.1319645643234253e-01
    z[1,0,3]  R213      2.9348948597908020e-01
    z[1,0,3]  R214      7.8819316625595093e-01
    z[1,0,3]  R215      5.9231573343276978e-01
    z[1,0,3]  R216      -3.0174779891967773e-01
    z[1,0,3]  R217      -7.2141259908676147e-01
    z[1,0,3]  R218      5.9243249893188477e-01
    z[1,0,3]  R219      -4.7260278463363647e-01
    z[1,0,3]  R220      -3.9112648367881775e-01
    z[1,0,3]  R221      -6.0366153717041016e-01
    z[1,0,3]  R222      1.7625359818339348e-02
    z[1,0,3]  R223      -1.7079292237758636e-01
    z[1,0,3]  R224      1.3907326757907867e-01
    z[1,0,3]  R225      6.0492914915084839e-01
    z[1,0,3]  R226      7.4371442198753357e-02
    z[1,0,3]  R227      -2.2594090551137924e-02
    z[1,0,3]  R228      -2.0540507137775421e-01
    z[1,0,3]  R229      -4.4240858405828476e-02
    z[1,0,3]  R230      0.419666588306427
    z[1,0,3]  R231      -8.7730005383491516e-02
    z[1,0,3]  R232      4.6109583228826523e-02
    z[1,0,3]  R233      2.3920443654060364e-01
    z[1,0,3]  R234      3.2978153228759766e-01
    z[1,0,3]  R235      8.0333340167999268e-01
    z[1,0,3]  R236      6.1041784286499023e-01
    z[1,0,3]  R237      3.6767061799764633e-02
    z[1,0,3]  R238      1.4024442434310913e-01
    z[1,0,3]  R239      1.7614370584487915e-01
    z[1,0,3]  R240      1.7516884207725525e-01
    z[1,0,3]  R241      0.0334952250123024
    z[1,0,3]  R242      5.9051042795181274e-01
    z[1,0,3]  R243      5.4493576288223267e-01
    z[1,0,3]  R244      5.3646290302276611e-01
    z[1,0,3]  R245      8.6003012955188751e-02
    z[1,0,3]  R246      -9.1377347707748413e-02
    z[1,0,3]  R247      -8.2541637122631073e-02
    z[1,0,3]  R248      3.1068651005625725e-02
    z[1,0,3]  R249      3.6152434349060059e-01
    z[1,0,3]  R250      4.2539575695991516e-01
    z[1,0,3]  R251      3.7138289213180542e-01
    z[1,0,3]  R252      -4.5978936553001404e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R167      -1
    z[1,0,4]  R168      1
    z[1,0,4]  R173      -2.0377385616302490e-01
    z[1,0,4]  R174      -1.9554647803306580e-01
    z[1,0,4]  R175      -7.1302741765975952e-02
    z[1,0,4]  R176      -7.4175751209259033e-01
    z[1,0,4]  R177      -1.1411214619874954e-01
    z[1,0,4]  R178      -0.0604756623506546
    z[1,0,4]  R179      0.00889661442488432
    z[1,0,4]  R180      -7.1751803159713745e-01
    z[1,0,4]  R181      -1.9821767508983612e-01
    z[1,0,4]  R182      -7.7603662014007568e-01
    z[1,0,4]  R183      4.3331223726272583e-01
    z[1,0,4]  R184      3.2113659381866455e-01
    z[1,0,4]  R185      5.2670681476593018e-01
    z[1,0,4]  R186      -1.4285834133625031e-01
    z[1,0,4]  R187      -3.8055914640426636e-01
    z[1,0,4]  R188      3.7265902757644653e-01
    z[1,0,4]  R189      3.3615803718566895e-01
    z[1,0,4]  R190      -0.0842844620347023
    z[1,0,4]  R191      5.2886521816253662e-01
    z[1,0,4]  R192      -5.4532349109649658e-01
    z[1,0,4]  R193      3.8011528551578522e-02
    z[1,0,4]  R194      5.9980505704879761e-01
    z[1,0,4]  R195      -3.1217586994171143e-01
    z[1,0,4]  R196      -1.8894271552562714e-01
    z[1,0,4]  R197      7.1065044403076172e-01
    z[1,0,4]  R198      -1.7832717299461365e-01
    z[1,0,4]  R199      2.9451239109039307e-01
    z[1,0,4]  R200      2.1173436939716339e-01
    z[1,0,4]  R201      2.8134658932685852e-01
    z[1,0,4]  R202      2.1854051947593689e-01
    z[1,0,4]  R203      -3.3535573631525040e-02
    z[1,0,4]  R204      -4.9515273422002792e-02
    z[1,0,4]  R205      -2.0375768840312958e-01
    z[1,0,4]  R206      -1.8227109313011169e-01
    z[1,0,4]  R207      -4.5663446187973022e-02
    z[1,0,4]  R208      -1.9856976345181465e-02
    z[1,0,4]  R209      9.8871342837810516e-02
    z[1,0,4]  R210      -7.6052442193031311e-02
    z[1,0,4]  R211      -1.4914900064468384e-01
    z[1,0,4]  R212      2.7532947063446045e-01
    z[1,0,4]  R213      2.2536313533782959e-01
    z[1,0,4]  R214      -1.7508116364479065e-01
    z[1,0,4]  R215      2.4778442084789276e-01
    z[1,0,4]  R216      3.5196027159690857e-01
    z[1,0,4]  R217      2.5746414065361023e-01
    z[1,0,4]  R218      -1.8810817599296570e-01
    z[1,0,4]  R219      2.8861114382743835e-01
    z[1,0,4]  R220      -7.0296205580234528e-02
    z[1,0,4]  R221      5.1523327827453613e-02
    z[1,0,4]  R222      -3.2622924447059631e-01
    z[1,0,4]  R223      3.3899492025375366e-01
    z[1,0,4]  R224      2.0529222674667835e-03
    z[1,0,4]  R225      -4.2526370286941528e-01
    z[1,0,4]  R226      -3.6457857489585876e-01
    z[1,0,4]  R227      -1.7739592492580414e-01
    z[1,0,4]  R228      2.1899169683456421e-01
    z[1,0,4]  R229      2.4537268280982971e-01
    z[1,0,4]  R230      7.0082515478134155e-02
    z[1,0,4]  R231      1.8526118993759155e-01
    z[1,0,4]  R232      -2.6621100306510925e-01
    z[1,0,4]  R233      3.3498089760541916e-02
    z[1,0,4]  R234      -2.4963997304439545e-01
    z[1,0,4]  R235      1.4572843909263611e-01
    z[1,0,4]  R236      -2.4555815756320953e-01
    z[1,0,4]  R237      2.2103634476661682e-01
    z[1,0,4]  R238      2.6744395494461060e-01
    z[1,0,4]  R239      -2.2378663718700409e-01
    z[1,0,4]  R240      8.9534647762775421e-02
    z[1,0,4]  R241      -1.6200336813926697e-01
    z[1,0,4]  R242      -3.2173395156860352e-01
    z[1,0,4]  R243      -1.8126342445611954e-02
    z[1,0,4]  R244      -0.0687897801399231
    z[1,0,4]  R245      -1.0060327500104904e-01
    z[1,0,4]  R246      1.4072653651237488e-01
    z[1,0,4]  R247      -0.217131569981575
    z[1,0,4]  R248      -3.9464724063873291e-01
    z[1,0,4]  R249      -7.1288503706455231e-02
    z[1,0,4]  R250      -0.252402663230896
    z[1,0,4]  R251      1.7273065447807312e-01
    z[1,0,4]  R252      -4.5735105872154236e-02
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R169      -1
    z[1,0,5]  R170      1
    z[1,0,5]  R173      -5.3726172447204590e-01
    z[1,0,5]  R174      -0.626187801361084
    z[1,0,5]  R175      -1.6882559657096863e-01
    z[1,0,5]  R176      -3.3339250087738037e-01
    z[1,0,5]  R177      3.3609855920076370e-02
    z[1,0,5]  R178      -1.6285820305347443e-01
    z[1,0,5]  R179      2.5512970983982086e-02
    z[1,0,5]  R180      1.5018879203125834e-03
    z[1,0,5]  R181      -2.9831105470657349e-01
    z[1,0,5]  R182      1.9834114611148834e-01
    z[1,0,5]  R183      3.3949002623558044e-01
    z[1,0,5]  R184      -1.5337635576725006e-01
    z[1,0,5]  R185      -2.4938280880451202e-01
    z[1,0,5]  R186      5.6400257349014282e-01
    z[1,0,5]  R187      4.6394929289817810e-01
    z[1,0,5]  R188      4.4545814394950867e-01
    z[1,0,5]  R189      4.8621088266372681e-01
    z[1,0,5]  R190      -6.7275539040565491e-02
    z[1,0,5]  R191      5.4848223924636841e-01
    z[1,0,5]  R192      -4.6977987512946129e-03
    z[1,0,5]  R193      -4.5693108439445496e-01
    z[1,0,5]  R194      -4.5982575416564941e-01
    z[1,0,5]  R195      4.6194070577621460e-01
    z[1,0,5]  R196      5.6908661127090454e-01
    z[1,0,5]  R197      -4.7468963265419006e-01
    z[1,0,5]  R198      1.0996001958847046e-01
    z[1,0,5]  R199      3.1893891096115112e-01
    z[1,0,5]  R200      3.3318656682968140e-01
    z[1,0,5]  R201      1.6710844635963440e-01
    z[1,0,5]  R202      6.1378264427185059e-01
    z[1,0,5]  R203      9.2932768166065216e-02
    z[1,0,5]  R204      -1.8901444971561432e-01
    z[1,0,5]  R205      -2.1008993685245514e-01
    z[1,0,5]  R206      4.0209561586380005e-01
    z[1,0,5]  R207      2.2197328507900238e-01
    z[1,0,5]  R208      -1.7166697978973389e-01
    z[1,0,5]  R209      4.3754315376281738e-01
    z[1,0,5]  R210      -5.9859317541122437e-01
    z[1,0,5]  R211      -5.3073191642761230e-01
    z[1,0,5]  R212      1.7103178799152374e-01
    z[1,0,5]  R213      -2.0624138414859772e-01
    z[1,0,5]  R214      1.7194516956806183e-01
    z[1,0,5]  R215      1.0926352441310883e-01
    z[1,0,5]  R216      1.5449135005474091e-01
    z[1,0,5]  R217      -5.7839006185531616e-02
    z[1,0,5]  R218      2.7391710877418518e-01
    z[1,0,5]  R219      3.9220470190048218e-01
    z[1,0,5]  R220      -6.0699041932821274e-02
    z[1,0,5]  R221      2.8945362567901611e-01
    z[1,0,5]  R222      -2.8680872172117233e-02
    z[1,0,5]  R223      -3.0305898189544678e-01
    z[1,0,5]  R224      2.1535551548004150e-01
    z[1,0,5]  R225      -4.5871835947036743e-01
    z[1,0,5]  R226      8.2992248237133026e-02
    z[1,0,5]  R227      2.2274820506572723e-01
    z[1,0,5]  R228      3.8611114025115967e-02
    z[1,0,5]  R229      -1.0222090035676956e-01
    z[1,0,5]  R230      3.6876723170280457e-01
    z[1,0,5]  R231      -2.4792829155921936e-01
    z[1,0,5]  R232      2.7647942304611206e-01
    z[1,0,5]  R233      9.5163963735103607e-02
    z[1,0,5]  R234      4.6929683536291122e-02
    z[1,0,5]  R235      5.9022769331932068e-02
    z[1,0,5]  R236      -5.6864005327224731e-01
    z[1,0,5]  R237      7.8296266496181488e-02
    z[1,0,5]  R238      6.3668382167816162e-01
    z[1,0,5]  R239      -3.7976327538490295e-01
    z[1,0,5]  R240      5.5324655771255493e-01
    z[1,0,5]  R241      -5.7667877525091171e-02
    z[1,0,5]  R242      -0.0557275153696537
    z[1,0,5]  R243      3.4259703010320663e-02
    z[1,0,5]  R244      -4.8903831839561462e-01
    z[1,0,5]  R245      -3.9436902850866318e-02
    z[1,0,5]  R246      -1.8040984869003296e-01
    z[1,0,5]  R247      -1.4283163845539093e-01
    z[1,0,5]  R248      -1.1372285336256027e-01
    z[1,0,5]  R249      0.0759860947728157
    z[1,0,5]  R250      3.4039494395256042e-01
    z[1,0,5]  R251      -1.7409792542457581e-01
    z[1,0,5]  R252      -4.3879696726799011e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R171      -1
    z[1,0,6]  R172      1
    z[1,0,6]  R173      -3.3465293049812317e-01
    z[1,0,6]  R174      -1.2145908921957016e-01
    z[1,0,6]  R175      -1.0455239564180374e-01
    z[1,0,6]  R176      1.8991325795650482e-01
    z[1,0,6]  R177      -2.7531927824020386e-01
    z[1,0,6]  R178      1.2007252871990204e-01
    z[1,0,6]  R179      1.3806284964084625e-01
    z[1,0,6]  R180      -1.4318844676017761e-01
    z[1,0,6]  R181      1.7317837476730347e-01
    z[1,0,6]  R182      -1.6367603838443756e-01
    z[1,0,6]  R183      -5.3965445607900620e-02
    z[1,0,6]  R184      6.6160291433334351e-01
    z[1,0,6]  R185      7.7898889780044556e-01
    z[1,0,6]  R186      2.2799883782863617e-01
    z[1,0,6]  R187      -4.8196563124656677e-01
    z[1,0,6]  R188      -4.0603697299957275e-01
    z[1,0,6]  R189      9.4417795538902283e-02
    z[1,0,6]  R190      -5.2158057689666748e-01
    z[1,0,6]  R191      4.4169902801513672e-01
    z[1,0,6]  R192      -2.6157552003860474e-01
    z[1,0,6]  R193      7.1805804967880249e-01
    z[1,0,6]  R194      -5.7507455348968506e-01
    z[1,0,6]  R195      3.8336464762687683e-01
    z[1,0,6]  R196      -1.7829042673110962e-01
    z[1,0,6]  R197      -8.7246164679527283e-02
    z[1,0,6]  R198      4.4387900829315186e-01
    z[1,0,6]  R199      2.8109195828437805e-01
    z[1,0,6]  R200      -3.9085072278976440e-01
    z[1,0,6]  R201      -6.4286071062088013e-01
    z[1,0,6]  R202      -1.3372294604778290e-01
    z[1,0,6]  R203      -7.7646985650062561e-02
    z[1,0,6]  R204      2.2368364036083221e-01
    z[1,0,6]  R205      -0.00801405031234026
    z[1,0,6]  R206      -1.0292106121778488e-01
    z[1,0,6]  R207      -3.9872547984123230e-01
    z[1,0,6]  R208      -6.0501378774642944e-01
    z[1,0,6]  R209      9.0815395116806030e-02
    z[1,0,6]  R210      -9.9978566169738770e-02
    z[1,0,6]  R211      -4.7355449199676514e-01
    z[1,0,6]  R212      3.7781819701194763e-01
    z[1,0,6]  R213      9.2529594898223877e-02
    z[1,0,6]  R214      -4.7485128045082092e-02
    z[1,0,6]  R215      3.2669717073440552e-01
    z[1,0,6]  R216      7.1300998330116272e-02
    z[1,0,6]  R217      -8.8774301111698151e-02
    z[1,0,6]  R218      -0.277802973985672
    z[1,0,6]  R219      -2.6915711164474487e-01
    z[1,0,6]  R220      -3.0051326751708984e-01
    z[1,0,6]  R221      -3.5231578350067139e-01
    z[1,0,6]  R222      -3.1592342257499695e-01
    z[1,0,6]  R223      4.3523173779249191e-02
    z[1,0,6]  R224      -1.8603503704071045e-02
    z[1,0,6]  R225      -1.4835110306739807e-01
    z[1,0,6]  R226      -4.2224639654159546e-01
    z[1,0,6]  R227      1.3989524543285370e-01
    z[1,0,6]  R228      3.5618028044700623e-01
    z[1,0,6]  R229      0.0871143639087677
    z[1,0,6]  R230      5.0407934933900833e-02
    z[1,0,6]  R231      1.0933487862348557e-01
    z[1,0,6]  R232      1.4906217157840729e-01
    z[1,0,6]  R233      7.8052692115306854e-02
    z[1,0,6]  R234      -3.3254516124725342e-01
    z[1,0,6]  R235      3.4663116931915283e-01
    z[1,0,6]  R236      1.0936836712062359e-02
    z[1,0,6]  R237      2.4585144221782684e-01
    z[1,0,6]  R238      -0.0379331074655056
    z[1,0,6]  R239      -4.8347041010856628e-02
    z[1,0,6]  R240      -1.9569578766822815e-01
    z[1,0,6]  R241      -1.6855119168758392e-01
    z[1,0,6]  R242      -7.4472457170486450e-02
    z[1,0,6]  R243      -1.8850931897759438e-02
    z[1,0,6]  R244      -9.7053229808807373e-02
    z[1,0,6]  R245      -4.8596754670143127e-01
    z[1,0,6]  R246      -1.7079439759254456e-01
    z[1,0,6]  R247      -1.0855325311422348e-01
    z[1,0,6]  R248      4.2523756623268127e-02
    z[1,0,6]  R249      4.6377268433570862e-01
    z[1,0,6]  R250      0.243007093667984
    z[1,0,6]  R251      2.0650866627693176e-01
    z[1,0,6]  R252      4.8855948261916637e-03
    z[0,3,0]  R2        -1
    z[0,3,0]  R29       1
    z[0,3,0]  R253      -1
    z[0,3,0]  R254      1
    z[0,3,0]  R267      2.8651472926139832e-01
    z[0,3,0]  R268      1.2795411050319672e-01
    z[0,3,0]  R269      -8.7496735155582428e-02
    z[0,3,0]  R270      -3.7960651516914368e-01
    z[0,3,0]  R271      -2.4253386259078979e-01
    z[0,3,0]  R272      8.3142615854740143e-02
    z[0,3,0]  R273      -6.1582762002944946e-01
    z[0,3,0]  R274      2.8442075848579407e-01
    z[0,3,0]  R275      -4.0650427341461182e-01
    z[0,3,0]  R276      -4.3040949106216431e-01
    z[0,3,0]  R277      -7.8000795841217041e-01
    z[0,3,0]  R278      4.7225859016180038e-02
    z[0,3,0]  R279      2.8592804074287415e-01
    z[0,3,0]  R280      -6.8026143312454224e-01
    z[0,3,0]  R281      -5.5497133731842041e-01
    z[0,3,0]  R282      -6.2856096029281616e-01
    z[0,3,0]  R283      -5.0041484832763672e-01
    z[0,3,0]  R284      -6.2581396102905273e-01
    z[0,3,0]  R285      -5.3726291656494141e-01
    z[0,3,0]  R286      7.4985343217849731e-01
    z[0,3,0]  R287      -1.3760386407375336e-01
    z[0,3,0]  R288      7.8818231821060181e-01
    z[0,3,0]  R289      -3.8373938202857971e-01
    z[0,3,0]  R290      -7.6504886150360107e-01
    z[0,3,0]  R291      0.883021354675293
    z[0,3,0]  R292      7.5968778133392334e-01
    z[0,3,0]  R293      8.4968453645706177e-01
    z[0,3,0]  R294      0.728162944316864
    z[0,3,0]  R295      9.3186068534851074e-01
    z[0,3,0]  R296      6.3493967056274414e-01
    z[0,3,0]  R297      2.9498443007469177e-01
    z[0,3,0]  R298      1.0823281109333038e-01
    z[0,3,0]  R299      -3.8759079575538635e-01
    z[0,3,0]  R300      -8.3277545869350433e-02
    z[0,3,0]  R301      -2.6885583996772766e-01
    z[0,3,0]  R302      -1.9437973201274872e-01
    z[0,3,0]  R303      -6.0521680116653442e-01
    z[0,3,0]  R304      0.221168652176857
    z[0,3,0]  R305      -7.8391057252883911e-01
    z[0,3,0]  R306      -6.4032828807830811e-01
    z[0,3,0]  R307      -3.9301496744155884e-01
    z[0,3,0]  R308      -1.1683456832543015e-03
    z[0,3,0]  R309      -6.9850414991378784e-01
    z[0,3,0]  R310      8.0699104070663452e-01
    z[0,3,0]  R311      5.5868566036224365e-01
    z[0,3,0]  R312      7.2400557994842529e-01
    z[0,3,0]  R313      5.9400999546051025e-01
    z[0,3,0]  R314      5.1288783550262451e-01
    z[0,3,0]  R315      8.6062455177307129e-01
    z[0,3,0]  R316      7.6770633459091187e-01
    z[0,3,0]  R317      -4.7842565923929214e-02
    z[0,3,0]  R318      1.6336145997047424e-01
    z[0,3,0]  R319      -9.9870808422565460e-02
    z[0,3,0]  R320      -1.5496462583541870e-01
    z[0,3,0]  R321      -1.9728128612041473e-01
    z[0,3,0]  R322      -8.0846935510635376e-02
    z[0,3,0]  R323      6.1693799495697021e-01
    z[0,3,0]  R324      2.0558543503284454e-01
    z[0,3,0]  R325      -4.9991199374198914e-01
    z[0,3,0]  R326      2.1772319078445435e-01
    z[0,3,0]  R327      2.0003290474414825e-01
    z[0,3,0]  R328      -7.4387617409229279e-02
    z[0,3,0]  R329      -4.1597837209701538e-01
    z[0,3,0]  R330      -7.6839077472686768e-01
    z[0,3,0]  R331      7.7399837970733643e-01
    z[0,3,0]  R332      6.8121302127838135e-01
    z[0,3,0]  R333      1.8463215231895447e-01
    z[0,3,0]  R334      -3.9293516427278519e-02
    z[0,3,0]  R335      5.3565528243780136e-02
    z[0,3,0]  R336      2.4766375124454498e-01
    z[0,3,0]  R337      -4.7654718160629272e-01
    z[0,3,0]  R338      -6.7651289701461792e-01
    z[0,3,0]  R339      7.5398230552673340e-01
    z[0,3,0]  R340      -4.8060646653175354e-01
    z[0,3,0]  R341      6.8152880668640137e-01
    z[0,3,0]  R342      5.6666636466979980e-01
    z[0,3,0]  R343      5.7580095529556274e-01
    z[0,3,0]  R344      6.0033982992172241e-01
    z[0,3,0]  R345      2.0098535716533661e-01
    z[0,3,1]  R3        -1
    z[0,3,1]  R30       1
    z[0,3,1]  R255      -1
    z[0,3,1]  R256      1
    z[0,3,1]  R267      1.8928368389606476e-01
    z[0,3,1]  R268      -2.1338941156864166e-01
    z[0,3,1]  R269      -3.8782188296318054e-01
    z[0,3,1]  R270      -3.3455827832221985e-01
    z[0,3,1]  R271      -1.8127226829528809e-01
    z[0,3,1]  R272      5.7150256633758545e-01
    z[0,3,1]  R273      -4.0909606218338013e-01
    z[0,3,1]  R274      3.9326825737953186e-01
    z[0,3,1]  R275      -3.2245048880577087e-01
    z[0,3,1]  R276      1.5870548784732819e-01
    z[0,3,1]  R277      1.9267785549163818e-01
    z[0,3,1]  R278      2.7879431843757629e-01
    z[0,3,1]  R279      4.3742680549621582e-01
    z[0,3,1]  R280      5.0138658285140991e-01
    z[0,3,1]  R281      2.9762953519821167e-01
    z[0,3,1]  R282      2.5165641307830811e-01
    z[0,3,1]  R283      4.4293156266212463e-01
    z[0,3,1]  R284      5.9310346841812134e-01
    z[0,3,1]  R285      3.6480927467346191e-01
    z[0,3,1]  R286      -4.7468325495719910e-01
    z[0,3,1]  R287      4.5324820280075073e-01
    z[0,3,1]  R288      4.3186369538307190e-01
    z[0,3,1]  R289      -1.9462096691131592e-01
    z[0,3,1]  R290      -3.0049049854278564e-01
    z[0,3,1]  R291      -3.4105396270751953e-01
    z[0,3,1]  R292      -4.4918251037597656e-01
    z[0,3,1]  R293      -4.4155994057655334e-01
    z[0,3,1]  R294      -0.372814804315567
    z[0,3,1]  R295      5.1849503070116043e-02
    z[0,3,1]  R296      -6.5198218822479248e-01
    z[0,3,1]  R297      9.6570156514644623e-02
    z[0,3,1]  R298      3.3297258615493774e-01
    z[0,3,1]  R299      5.8803703635931015e-02
    z[0,3,1]  R300      2.9408693313598633e-02
    z[0,3,1]  R301      -2.7275240421295166e-01
    z[0,3,1]  R302      4.1085100173950195e-01
    z[0,3,1]  R303      -4.9133521318435669e-01
    z[0,3,1]  R304      6.2088662385940552e-01
    z[0,3,1]  R305      -5.6678557395935059e-01
    z[0,3,1]  R306      -3.5645613074302673e-01
    z[0,3,1]  R307      1.5330517292022705e-01
    z[0,3,1]  R308      6.5617656707763672e-01
    z[0,3,1]  R309      -4.7061309218406677e-01
    z[0,3,1]  R310      -4.6602806448936462e-01
    z[0,3,1]  R311      -7.6760894060134888e-01
    z[0,3,1]  R312      -5.4526710510253906e-01
    z[0,3,1]  R313      -5.2219486236572266e-01
    z[0,3,1]  R314      -5.5512249469757080e-01
    z[0,3,1]  R315      -8.9052587747573853e-02
    z[0,3,1]  R316      9.1685699298977852e-03
    z[0,3,1]  R317      6.0475111007690430e-01
    z[0,3,1]  R318      -3.6786407232284546e-01
    z[0,3,1]  R319      3.8820084929466248e-01
    z[0,3,1]  R320      5.5196863412857056e-01
    z[0,3,1]  R321      0.595467209815979
    z[0,3,1]  R322      4.3397700786590576e-01
    z[0,3,1]  R323      4.7003057599067688e-01
    z[0,3,1]  R324      1.0072947479784489e-02
    z[0,3,1]  R325      -4.1328358650207520e-01
    z[0,3,1]  R326      6.8299764394760132e-01
    z[0,3,1]  R327      -2.1420218050479889e-01
    z[0,3,1]  R328      -6.9788807630538940e-01
    z[0,3,1]  R329      -7.2894757986068726e-01
    z[0,3,1]  R330      -3.8785722851753235e-01
    z[0,3,1]  R331      -4.9330314993858337e-01
    z[0,3,1]  R332      -0.549047589302063
    z[0,3,1]  R333      -7.3758912086486816e-01
    z[0,3,1]  R334      -6.3828259706497192e-01
    z[0,3,1]  R335      -6.0159695148468018e-01
    z[0,3,1]  R336      -0.551503598690033
    z[0,3,1]  R337      -5.4990863800048828e-01
    z[0,3,1]  R338      -1.7415808141231537e-01
    z[0,3,1]  R339      -5.0131946802139282e-01
    z[0,3,1]  R340      3.1767040491104126e-01
    z[0,3,1]  R341      -4.1771686077117920e-01
    z[0,3,1]  R342      -4.2553973197937012e-01
    z[0,3,1]  R343      -0.717606246471405
    z[0,3,1]  R344      -5.2050924301147461e-01
    z[0,3,1]  R345      1.4430856704711914e-01
    z[0,3,2]  R4        -1
    z[0,3,2]  R31       1
    z[0,3,2]  R257      -1
    z[0,3,2]  R258      1
    z[0,3,2]  R267      -9.1805821657180786e-01
    z[0,3,2]  R268      -0.821935772895813
    z[0,3,2]  R269      -8.4933263063430786e-01
    z[0,3,2]  R270      -6.5146356821060181e-01
    z[0,3,2]  R271      -8.2496714591979980e-01
    z[0,3,2]  R272      -4.8234471678733826e-01
    z[0,3,2]  R273      -4.8315051198005676e-01
    z[0,3,2]  R274      -6.1321413516998291e-01
    z[0,3,2]  R275      -4.4579333066940308e-01
    z[0,3,2]  R276      -1.8195107579231262e-01
    z[0,3,2]  R277      -4.0797176957130432e-01
    z[0,3,2]  R278      -4.8612919449806213e-01
    z[0,3,2]  R279      -4.4271695613861084e-01
    z[0,3,2]  R280      2.0488208532333374e-01
    z[0,3,2]  R281      0.0739821344614029
    z[0,3,2]  R282      -0.054900873452425
    z[0,3,2]  R283      1.4309750497341156e-01
    z[0,3,2]  R284      6.8344056606292725e-02
    z[0,3,2]  R285      5.7367127388715744e-02
    z[0,3,2]  R286      7.0916898548603058e-02
    z[0,3,2]  R287      -7.3335152864456177e-01
    z[0,3,2]  R288      -3.5523602366447449e-01
    z[0,3,2]  R289      -1.8880613148212433e-01
    z[0,3,2]  R290      -2.7876647189259529e-02
    z[0,3,2]  R291      5.2802741527557373e-02
    z[0,3,2]  R292      5.1044680178165436e-02
    z[0,3,2]  R293      -5.3460329771041870e-02
    z[0,3,2]  R294      1.0595314204692841e-01
    z[0,3,2]  R295      1.1621717363595963e-01
    z[0,3,2]  R296      1.0771667584776878e-02
    z[0,3,2]  R297      -9.1113615036010742e-01
    z[0,3,2]  R298      -7.7042216062545776e-01
    z[0,3,2]  R299      -2.3684878647327423e-01
    z[0,3,2]  R300      -4.8561313748359680e-01
    z[0,3,2]  R301      -8.5821944475173950e-01
    z[0,3,2]  R302      -5.4352372884750366e-01
    z[0,3,2]  R303      -4.0575563907623291e-01
    z[0,3,2]  R304      -4.2720615863800049e-01
    z[0,3,2]  R305      -0.0716678723692894
    z[0,3,2]  R306      4.5296527445316315e-02
    z[0,3,2]  R307      -7.2334235906600952e-01
    z[0,3,2]  R308      -1.6831138730049133e-01
    z[0,3,2]  R309      -1.8809004127979279e-01
    z[0,3,2]  R310      2.0423267781734467e-01
    z[0,3,2]  R311      1.1181588470935822e-01
    z[0,3,2]  R312      8.3945572376251221e-02
    z[0,3,2]  R313      1.3350541889667511e-01
    z[0,3,2]  R314      9.5891840755939484e-02
    z[0,3,2]  R315      1.0333411395549774e-01
    z[0,3,2]  R316      -6.6920608282089233e-02
    z[0,3,2]  R317      -1.9149206578731537e-01
    z[0,3,2]  R318      -6.1956530809402466e-01
    z[0,3,2]  R319      -1.0150258988142014e-01
    z[0,3,2]  R320      5.1067221164703369e-01
    z[0,3,2]  R321      -3.0399185419082642e-01
    z[0,3,2]  R322      -6.3550509512424469e-02
    z[0,3,2]  R323      -4.3908601999282837e-01
    z[0,3,2]  R324      -5.5459529161453247e-01
    z[0,3,2]  R325      -2.8686091303825378e-01
    z[0,3,2]  R326      0.0934213399887085
    z[0,3,2]  R327      -2.7673307061195374e-01
    z[0,3,2]  R328      -1.6257500648498535e-01
    z[0,3,2]  R329      2.0472067594528198e-01
    z[0,3,2]  R330      1.8409414589405060e-01
    z[0,3,2]  R331      1.0388576984405518e-01
    z[0,3,2]  R332      1.4887210726737976e-01
    z[0,3,2]  R333      4.9851119518280029e-02
    z[0,3,2]  R334      1.0713803023099899e-01
    z[0,3,2]  R335      2.0366646349430084e-01
    z[0,3,2]  R336      -1.4279303140938282e-02
    z[0,3,2]  R337      1.8054470419883728e-01
    z[0,3,2]  R338      -3.8066647946834564e-02
    z[0,3,2]  R339      1.5422993898391724e-01
    z[0,3,2]  R340      1.4361312985420227e-01
    z[0,3,2]  R341      4.2949758470058441e-02
    z[0,3,2]  R342      1.5921603143215179e-01
    z[0,3,2]  R343      1.7752985656261444e-01
    z[0,3,2]  R344      1.6489961743354797e-01
    z[0,3,2]  R345      3.1613722443580627e-01
    z[0,3,3]  R5        -1
    z[0,3,3]  R32       1
    z[0,3,3]  R259      -1
    z[0,3,3]  R260      1
    z[0,3,3]  R267      1.5316574275493622e-01
    z[0,3,3]  R268      4.1749465465545654e-01
    z[0,3,3]  R269      0.186690554022789
    z[0,3,3]  R270      3.3774030208587646e-01
    z[0,3,3]  R271      1.3193790614604950e-01
    z[0,3,3]  R272      1.9470538198947906e-01
    z[0,3,3]  R273      1.0244677215814590e-01
    z[0,3,3]  R274      1.1966568231582642e-01
    z[0,3,3]  R275      0.0622292086482048
    z[0,3,3]  R276      7.1319645643234253e-01
    z[0,3,3]  R277      2.9348948597908020e-01
    z[0,3,3]  R278      7.8819316625595093e-01
    z[0,3,3]  R279      5.9231573343276978e-01
    z[0,3,3]  R280      -3.0174779891967773e-01
    z[0,3,3]  R281      -7.2141259908676147e-01
    z[0,3,3]  R282      5.9243249893188477e-01
    z[0,3,3]  R283      -4.7260278463363647e-01
    z[0,3,3]  R284      -3.9112648367881775e-01
    z[0,3,3]  R285      -6.0366153717041016e-01
    z[0,3,3]  R286      1.7625359818339348e-02
    z[0,3,3]  R287      -1.7079292237758636e-01
    z[0,3,3]  R288      1.3907326757907867e-01
    z[0,3,3]  R289      6.0492914915084839e-01
    z[0,3,3]  R290      7.4371442198753357e-02
    z[0,3,3]  R291      -2.2594090551137924e-02
    z[0,3,3]  R292      -2.0540507137775421e-01
    z[0,3,3]  R293      -4.4240858405828476e-02
    z[0,3,3]  R294      0.419666588306427
    z[0,3,3]  R295      -8.7730005383491516e-02
    z[0,3,3]  R296      4.6109583228826523e-02
    z[0,3,3]  R297      2.3920443654060364e-01
    z[0,3,3]  R298      3.2978153228759766e-01
    z[0,3,3]  R299      8.0333340167999268e-01
    z[0,3,3]  R300      6.1041784286499023e-01
    z[0,3,3]  R301      3.6767061799764633e-02
    z[0,3,3]  R302      1.4024442434310913e-01
    z[0,3,3]  R303      1.7614370584487915e-01
    z[0,3,3]  R304      1.7516884207725525e-01
    z[0,3,3]  R305      0.0334952250123024
    z[0,3,3]  R306      5.9051042795181274e-01
    z[0,3,3]  R307      5.4493576288223267e-01
    z[0,3,3]  R308      5.3646290302276611e-01
    z[0,3,3]  R309      8.6003012955188751e-02
    z[0,3,3]  R310      -9.1377347707748413e-02
    z[0,3,3]  R311      -8.2541637122631073e-02
    z[0,3,3]  R312      3.1068651005625725e-02
    z[0,3,3]  R313      3.6152434349060059e-01
    z[0,3,3]  R314      4.2539575695991516e-01
    z[0,3,3]  R315      3.7138289213180542e-01
    z[0,3,3]  R316      -4.5978936553001404e-01
    z[0,3,3]  R317      5.7045191526412964e-01
    z[0,3,3]  R318      4.8253723978996277e-01
    z[0,3,3]  R319      6.8029654026031494e-01
    z[0,3,3]  R320      -1.0830656439065933e-01
    z[0,3,3]  R321      5.0035911798477173e-01
    z[0,3,3]  R322      3.2207110524177551e-01
    z[0,3,3]  R323      2.8305670619010925e-01
    z[0,3,3]  R324      2.8177937865257263e-01
    z[0,3,3]  R325      3.9799353480339050e-01
    z[0,3,3]  R326      -1.1393939703702927e-01
    z[0,3,3]  R327      3.9269354939460754e-01
    z[0,3,3]  R328      4.8071038722991943e-01
    z[0,3,3]  R329      1.0551664978265762e-01
    z[0,3,3]  R330      -3.4226432908326387e-03
    z[0,3,3]  R331      -7.2667285799980164e-02
    z[0,3,3]  R332      -4.0364658832550049e-01
    z[0,3,3]  R333      -5.4425221681594849e-01
    z[0,3,3]  R334      -7.3211288452148438e-01
    z[0,3,3]  R335      -6.5576130151748657e-01
    z[0,3,3]  R336      -7.0714837312698364e-01
    z[0,3,3]  R337      3.7765324115753174e-01
    z[0,3,3]  R338      1.9084180891513824e-01
    z[0,3,3]  R339      -3.1247639656066895e-01
    z[0,3,3]  R340      -4.6759301424026489e-01
    z[0,3,3]  R341      -2.9388004541397095e-01
    z[0,3,3]  R342      -2.9821637272834778e-01
    z[0,3,3]  R343      -2.7308362722396851e-01
    z[0,3,3]  R344      -3.5534223914146423e-01
    z[0,3,3]  R345      -7.9411095380783081e-01
    z[0,3,4]  R6        -1
    z[0,3,4]  R33       1
    z[0,3,4]  R261      -1
    z[0,3,4]  R262      1
    z[0,3,4]  R267      -3.3535573631525040e-02
    z[0,3,4]  R268      -4.9515273422002792e-02
    z[0,3,4]  R269      -2.0375768840312958e-01
    z[0,3,4]  R270      -1.8227109313011169e-01
    z[0,3,4]  R271      -4.5663446187973022e-02
    z[0,3,4]  R272      -1.9856976345181465e-02
    z[0,3,4]  R273      9.8871342837810516e-02
    z[0,3,4]  R274      -7.6052442193031311e-02
    z[0,3,4]  R275      -1.4914900064468384e-01
    z[0,3,4]  R276      2.7532947063446045e-01
    z[0,3,4]  R277      2.2536313533782959e-01
    z[0,3,4]  R278      -1.7508116364479065e-01
    z[0,3,4]  R279      2.4778442084789276e-01
    z[0,3,4]  R280      3.5196027159690857e-01
    z[0,3,4]  R281      2.5746414065361023e-01
    z[0,3,4]  R282      -1.8810817599296570e-01
    z[0,3,4]  R283      2.8861114382743835e-01
    z[0,3,4]  R284      -7.0296205580234528e-02
    z[0,3,4]  R285      5.1523327827453613e-02
    z[0,3,4]  R286      -3.2622924447059631e-01
    z[0,3,4]  R287      3.3899492025375366e-01
    z[0,3,4]  R288      2.0529222674667835e-03
    z[0,3,4]  R289      -4.2526370286941528e-01
    z[0,3,4]  R290      -3.6457857489585876e-01
    z[0,3,4]  R291      -1.7739592492580414e-01
    z[0,3,4]  R292      2.1899169683456421e-01
    z[0,3,4]  R293      2.4537268280982971e-01
    z[0,3,4]  R294      7.0082515478134155e-02
    z[0,3,4]  R295      1.8526118993759155e-01
    z[0,3,4]  R296      -2.6621100306510925e-01
    z[0,3,4]  R297      3.3498089760541916e-02
    z[0,3,4]  R298      -2.4963997304439545e-01
    z[0,3,4]  R299      1.4572843909263611e-01
    z[0,3,4]  R300      -2.4555815756320953e-01
    z[0,3,4]  R301      2.2103634476661682e-01
    z[0,3,4]  R302      2.6744395494461060e-01
    z[0,3,4]  R303      -2.2378663718700409e-01
    z[0,3,4]  R304      8.9534647762775421e-02
    z[0,3,4]  R305      -1.6200336813926697e-01
    z[0,3,4]  R306      -3.2173395156860352e-01
    z[0,3,4]  R307      -1.8126342445611954e-02
    z[0,3,4]  R308      -0.0687897801399231
    z[0,3,4]  R309      -1.0060327500104904e-01
    z[0,3,4]  R310      1.4072653651237488e-01
    z[0,3,4]  R311      -0.217131569981575
    z[0,3,4]  R312      -3.9464724063873291e-01
    z[0,3,4]  R313      -7.1288503706455231e-02
    z[0,3,4]  R314      -0.252402663230896
    z[0,3,4]  R315      1.7273065447807312e-01
    z[0,3,4]  R316      -4.5735105872154236e-02
    z[0,3,4]  R317      -5.0928759574890137e-01
    z[0,3,4]  R318      3.3467937260866165e-02
    z[0,3,4]  R319      -3.6692202091217041e-01
    z[0,3,4]  R320      -6.2733925879001617e-02
    z[0,3,4]  R321      1.3942405581474304e-01
    z[0,3,4]  R322      -2.3931907117366791e-01
    z[0,3,4]  R323      -0.0843191146850586
    z[0,3,4]  R324      -2.0380539819598198e-02
    z[0,3,4]  R325      -2.5483930110931396e-01
    z[0,3,4]  R326      1.3971160352230072e-01
    z[0,3,4]  R327      6.4389693737030029e-01
    z[0,3,4]  R328      -3.3352595567703247e-01
    z[0,3,4]  R329      9.9107161164283752e-02
    z[0,3,4]  R330      3.8357204198837280e-01
    z[0,3,4]  R331      -1.7420975863933563e-01
    z[0,3,4]  R332      1.9177092611789703e-01
    z[0,3,4]  R333      1.9314432144165039e-01
    z[0,3,4]  R334      -6.8377837538719177e-02
    z[0,3,4]  R335      -2.2632372379302979e-01
    z[0,3,4]  R336      -2.8030967712402344e-01
    z[0,3,4]  R337      -2.2098235785961151e-01
    z[0,3,4]  R338      5.4563194513320923e-01
    z[0,3,4]  R339      -0.060396958142519
    z[0,3,4]  R340      2.3633283376693726e-01
    z[0,3,4]  R341      -0.493927001953125
    z[0,3,4]  R342      -5.5003982782363892e-01
    z[0,3,4]  R343      1.9689303636550903e-01
    z[0,3,4]  R344      4.7673948109149933e-02
    z[0,3,4]  R345      -1.8436609208583832e-01
    z[0,3,5]  R7        -1
    z[0,3,5]  R34       1
    z[0,3,5]  R263      -1
    z[0,3,5]  R264      1
    z[0,3,5]  R267      9.2932768166065216e-02
    z[0,3,5]  R268      -1.8901444971561432e-01
    z[0,3,5]  R269      -2.1008993685245514e-01
    z[0,3,5]  R270      4.0209561586380005e-01
    z[0,3,5]  R271      2.2197328507900238e-01
    z[0,3,5]  R272      -1.7166697978973389e-01
    z[0,3,5]  R273      4.3754315376281738e-01
    z[0,3,5]  R274      -5.9859317541122437e-01
    z[0,3,5]  R275      -5.3073191642761230e-01
    z[0,3,5]  R276      1.7103178799152374e-01
    z[0,3,5]  R277      -2.0624138414859772e-01
    z[0,3,5]  R278      1.7194516956806183e-01
    z[0,3,5]  R279      1.0926352441310883e-01
    z[0,3,5]  R280      1.5449135005474091e-01
    z[0,3,5]  R281      -5.7839006185531616e-02
    z[0,3,5]  R282      2.7391710877418518e-01
    z[0,3,5]  R283      3.9220470190048218e-01
    z[0,3,5]  R284      -6.0699041932821274e-02
    z[0,3,5]  R285      2.8945362567901611e-01
    z[0,3,5]  R286      -2.8680872172117233e-02
    z[0,3,5]  R287      -3.0305898189544678e-01
    z[0,3,5]  R288      2.1535551548004150e-01
    z[0,3,5]  R289      -4.5871835947036743e-01
    z[0,3,5]  R290      8.2992248237133026e-02
    z[0,3,5]  R291      2.2274820506572723e-01
    z[0,3,5]  R292      3.8611114025115967e-02
    z[0,3,5]  R293      -1.0222090035676956e-01
    z[0,3,5]  R294      3.6876723170280457e-01
    z[0,3,5]  R295      -2.4792829155921936e-01
    z[0,3,5]  R296      2.7647942304611206e-01
    z[0,3,5]  R297      9.5163963735103607e-02
    z[0,3,5]  R298      4.6929683536291122e-02
    z[0,3,5]  R299      5.9022769331932068e-02
    z[0,3,5]  R300      -5.6864005327224731e-01
    z[0,3,5]  R301      7.8296266496181488e-02
    z[0,3,5]  R302      6.3668382167816162e-01
    z[0,3,5]  R303      -3.7976327538490295e-01
    z[0,3,5]  R304      5.5324655771255493e-01
    z[0,3,5]  R305      -5.7667877525091171e-02
    z[0,3,5]  R306      -0.0557275153696537
    z[0,3,5]  R307      3.4259703010320663e-02
    z[0,3,5]  R308      -4.8903831839561462e-01
    z[0,3,5]  R309      -3.9436902850866318e-02
    z[0,3,5]  R310      -1.8040984869003296e-01
    z[0,3,5]  R311      -1.4283163845539093e-01
    z[0,3,5]  R312      -1.1372285336256027e-01
    z[0,3,5]  R313      0.0759860947728157
    z[0,3,5]  R314      3.4039494395256042e-01
    z[0,3,5]  R315      -1.7409792542457581e-01
    z[0,3,5]  R316      -4.3879696726799011e-01
    z[0,3,5]  R317      8.1511437892913818e-02
    z[0,3,5]  R318      4.6914857625961304e-01
    z[0,3,5]  R319      -7.9469613730907440e-02
    z[0,3,5]  R320      -5.7158374786376953e-01
    z[0,3,5]  R321      -9.7945593297481537e-02
    z[0,3,5]  R322      -4.0284192562103271e-01
    z[0,3,5]  R323      2.1341418847441673e-02
    z[0,3,5]  R324      3.0682021379470825e-01
    z[0,3,5]  R325      3.8957217335700989e-01
    z[0,3,5]  R326      1.9616955518722534e-01
    z[0,3,5]  R327      -4.7348102927207947e-01
    z[0,3,5]  R328      -3.2203987240791321e-01
    z[0,3,5]  R329      -2.7028828859329224e-01
    z[0,3,5]  R330      6.8928644061088562e-02
    z[0,3,5]  R331      -2.3548196256160736e-01
    z[0,3,5]  R332      1.0767978429794312e-01
    z[0,3,5]  R333      -3.4833904355764389e-02
    z[0,3,5]  R334      -1.7041069269180298e-01
    z[0,3,5]  R335      2.4099244177341461e-01
    z[0,3,5]  R336      2.1224381402134895e-02
    z[0,3,5]  R337      -3.2692757248878479e-01
    z[0,3,5]  R338      2.1178103983402252e-01
    z[0,3,5]  R339      1.9609722495079041e-01
    z[0,3,5]  R340      5.3016132116317749e-01
    z[0,3,5]  R341      8.2845687866210938e-02
    z[0,3,5]  R342      2.4352923035621643e-01
    z[0,3,5]  R343      7.0529342629015446e-03
    z[0,3,5]  R344      -2.6302334666252136e-01
    z[0,3,5]  R345      2.1879564225673676e-01
    z[0,3,6]  R8        -1
    z[0,3,6]  R35       1
    z[0,3,6]  R265      -1
    z[0,3,6]  R266      1
    z[0,3,6]  R267      -7.7646985650062561e-02
    z[0,3,6]  R268      2.2368364036083221e-01
    z[0,3,6]  R269      -0.00801405031234026
    z[0,3,6]  R270      -1.0292106121778488e-01
    z[0,3,6]  R271      -3.9872547984123230e-01
    z[0,3,6]  R272      -6.0501378774642944e-01
    z[0,3,6]  R273      9.0815395116806030e-02
    z[0,3,6]  R274      -9.9978566169738770e-02
    z[0,3,6]  R275      -4.7355449199676514e-01
    z[0,3,6]  R276      3.7781819701194763e-01
    z[0,3,6]  R277      9.2529594898223877e-02
    z[0,3,6]  R278      -4.7485128045082092e-02
    z[0,3,6]  R279      3.2669717073440552e-01
    z[0,3,6]  R280      7.1300998330116272e-02
    z[0,3,6]  R281      -8.8774301111698151e-02
    z[0,3,6]  R282      -0.277802973985672
    z[0,3,6]  R283      -2.6915711164474487e-01
    z[0,3,6]  R284      -3.0051326751708984e-01
    z[0,3,6]  R285      -3.5231578350067139e-01
    z[0,3,6]  R286      -3.1592342257499695e-01
    z[0,3,6]  R287      4.3523173779249191e-02
    z[0,3,6]  R288      -1.8603503704071045e-02
    z[0,3,6]  R289      -1.4835110306739807e-01
    z[0,3,6]  R290      -4.2224639654159546e-01
    z[0,3,6]  R291      1.3989524543285370e-01
    z[0,3,6]  R292      3.5618028044700623e-01
    z[0,3,6]  R293      0.0871143639087677
    z[0,3,6]  R294      5.0407934933900833e-02
    z[0,3,6]  R295      1.0933487862348557e-01
    z[0,3,6]  R296      1.4906217157840729e-01
    z[0,3,6]  R297      7.8052692115306854e-02
    z[0,3,6]  R298      -3.3254516124725342e-01
    z[0,3,6]  R299      3.4663116931915283e-01
    z[0,3,6]  R300      1.0936836712062359e-02
    z[0,3,6]  R301      2.4585144221782684e-01
    z[0,3,6]  R302      -0.0379331074655056
    z[0,3,6]  R303      -4.8347041010856628e-02
    z[0,3,6]  R304      -1.9569578766822815e-01
    z[0,3,6]  R305      -1.6855119168758392e-01
    z[0,3,6]  R306      -7.4472457170486450e-02
    z[0,3,6]  R307      -1.8850931897759438e-02
    z[0,3,6]  R308      -9.7053229808807373e-02
    z[0,3,6]  R309      -4.8596754670143127e-01
    z[0,3,6]  R310      -1.7079439759254456e-01
    z[0,3,6]  R311      -1.0855325311422348e-01
    z[0,3,6]  R312      4.2523756623268127e-02
    z[0,3,6]  R313      4.6377268433570862e-01
    z[0,3,6]  R314      0.243007093667984
    z[0,3,6]  R315      2.0650866627693176e-01
    z[0,3,6]  R316      4.8855948261916637e-03
    z[0,3,6]  R317      -6.2325235456228256e-02
    z[0,3,6]  R318      -8.0800447613000870e-03
    z[0,3,6]  R319      4.7462871670722961e-01
    z[0,3,6]  R320      2.6106837391853333e-01
    z[0,3,6]  R321      -4.8445445299148560e-01
    z[0,3,6]  R322      -0.69123375415802
    z[0,3,6]  R323      -3.4347614645957947e-01
    z[0,3,6]  R324      -6.9000262022018433e-01
    z[0,3,6]  R325      -3.4912335872650146e-01
    z[0,3,6]  R326      6.3749450445175171e-01
    z[0,3,6]  R327      2.1101489663124084e-01
    z[0,3,6]  R328      -0.186966210603714
    z[0,3,6]  R329      3.9959362149238586e-01
    z[0,3,6]  R330      2.7085286378860474e-01
    z[0,3,6]  R331      2.3601894080638885e-01
    z[0,3,6]  R332      3.2111827284097672e-02
    z[0,3,6]  R333      -2.9096311330795288e-01
    z[0,3,6]  R334      -9.9338285624980927e-02
    z[0,3,6]  R335      2.3325771093368530e-01
    z[0,3,6]  R336      2.3498864471912384e-01
    z[0,3,6]  R337      3.7359076738357544e-01
    z[0,3,6]  R338      3.6271774768829346e-01
    z[0,3,6]  R339      -1.2907078862190247e-01
    z[0,3,6]  R340      -3.0316799879074097e-01
    z[0,3,6]  R341      -1.4830298721790314e-01
    z[0,3,6]  R342      -1.4721424877643585e-01
    z[0,3,6]  R343      0.0926625207066536
    z[0,3,6]  R344      -0.379141241312027
    z[0,3,6]  R345      -3.5547509789466858e-01
    z[3,0,0]  R2        1
    z[3,0,0]  R29       -1
    z[3,0,0]  R346      -1
    z[3,0,0]  R347      1
    z[3,0,0]  R360      -4.7842565923929214e-02
    z[3,0,0]  R361      1.6336145997047424e-01
    z[3,0,0]  R362      -9.9870808422565460e-02
    z[3,0,0]  R363      -1.5496462583541870e-01
    z[3,0,0]  R364      -1.9728128612041473e-01
    z[3,0,0]  R365      -8.0846935510635376e-02
    z[3,0,0]  R366      6.1693799495697021e-01
    z[3,0,0]  R367      2.0558543503284454e-01
    z[3,0,0]  R368      -4.9991199374198914e-01
    z[3,0,0]  R369      2.1772319078445435e-01
    z[3,0,0]  R370      2.0003290474414825e-01
    z[3,0,0]  R371      -7.4387617409229279e-02
    z[3,0,0]  R372      -4.1597837209701538e-01
    z[3,0,0]  R373      -7.6839077472686768e-01
    z[3,0,0]  R374      7.7399837970733643e-01
    z[3,0,0]  R375      6.8121302127838135e-01
    z[3,0,0]  R376      1.8463215231895447e-01
    z[3,0,0]  R377      -3.9293516427278519e-02
    z[3,0,0]  R378      5.3565528243780136e-02
    z[3,0,0]  R379      2.4766375124454498e-01
    z[3,0,0]  R380      -4.7654718160629272e-01
    z[3,0,0]  R381      -6.7651289701461792e-01
    z[3,0,0]  R382      7.5398230552673340e-01
    z[3,0,0]  R383      -4.8060646653175354e-01
    z[3,0,0]  R384      6.8152880668640137e-01
    z[3,0,0]  R385      5.6666636466979980e-01
    z[3,0,0]  R386      5.7580095529556274e-01
    z[3,0,0]  R387      6.0033982992172241e-01
    z[3,0,0]  R388      2.0098535716533661e-01
    z[3,0,0]  R389      2.8651472926139832e-01
    z[3,0,0]  R390      1.2795411050319672e-01
    z[3,0,0]  R391      -8.7496735155582428e-02
    z[3,0,0]  R392      -3.7960651516914368e-01
    z[3,0,0]  R393      -2.4253386259078979e-01
    z[3,0,0]  R394      8.3142615854740143e-02
    z[3,0,0]  R395      -6.1582762002944946e-01
    z[3,0,0]  R396      2.8442075848579407e-01
    z[3,0,0]  R397      -4.0650427341461182e-01
    z[3,0,0]  R398      -4.3040949106216431e-01
    z[3,0,0]  R399      -7.8000795841217041e-01
    z[3,0,0]  R400      4.7225859016180038e-02
    z[3,0,0]  R401      2.8592804074287415e-01
    z[3,0,0]  R402      -6.8026143312454224e-01
    z[3,0,0]  R403      -5.5497133731842041e-01
    z[3,0,0]  R404      -6.2856096029281616e-01
    z[3,0,0]  R405      -5.0041484832763672e-01
    z[3,0,0]  R406      -6.2581396102905273e-01
    z[3,0,0]  R407      -5.3726291656494141e-01
    z[3,0,0]  R408      7.4985343217849731e-01
    z[3,0,0]  R409      -1.3760386407375336e-01
    z[3,0,0]  R410      7.8818231821060181e-01
    z[3,0,0]  R411      -3.8373938202857971e-01
    z[3,0,0]  R412      -7.6504886150360107e-01
    z[3,0,0]  R413      0.883021354675293
    z[3,0,0]  R414      7.5968778133392334e-01
    z[3,0,0]  R415      8.4968453645706177e-01
    z[3,0,0]  R416      0.728162944316864
    z[3,0,0]  R417      9.3186068534851074e-01
    z[3,0,0]  R418      6.3493967056274414e-01
    z[3,0,0]  R419      2.9498443007469177e-01
    z[3,0,0]  R420      1.0823281109333038e-01
    z[3,0,0]  R421      -3.8759079575538635e-01
    z[3,0,0]  R422      -8.3277545869350433e-02
    z[3,0,0]  R423      -2.6885583996772766e-01
    z[3,0,0]  R424      -1.9437973201274872e-01
    z[3,0,0]  R425      -6.0521680116653442e-01
    z[3,0,0]  R426      0.221168652176857
    z[3,0,0]  R427      -7.8391057252883911e-01
    z[3,0,0]  R428      -6.4032828807830811e-01
    z[3,0,0]  R429      -3.9301496744155884e-01
    z[3,0,0]  R430      -1.1683456832543015e-03
    z[3,0,0]  R431      -6.9850414991378784e-01
    z[3,0,0]  R432      8.0699104070663452e-01
    z[3,0,0]  R433      5.5868566036224365e-01
    z[3,0,0]  R434      7.2400557994842529e-01
    z[3,0,0]  R435      5.9400999546051025e-01
    z[3,0,0]  R436      5.1288783550262451e-01
    z[3,0,0]  R437      8.6062455177307129e-01
    z[3,0,0]  R438      7.6770633459091187e-01
    z[3,0,1]  R3        1
    z[3,0,1]  R30       -1
    z[3,0,1]  R348      -1
    z[3,0,1]  R349      1
    z[3,0,1]  R360      6.0475111007690430e-01
    z[3,0,1]  R361      -3.6786407232284546e-01
    z[3,0,1]  R362      3.8820084929466248e-01
    z[3,0,1]  R363      5.5196863412857056e-01
    z[3,0,1]  R364      0.595467209815979
    z[3,0,1]  R365      4.3397700786590576e-01
    z[3,0,1]  R366      4.7003057599067688e-01
    z[3,0,1]  R367      1.0072947479784489e-02
    z[3,0,1]  R368      -4.1328358650207520e-01
    z[3,0,1]  R369      6.8299764394760132e-01
    z[3,0,1]  R370      -2.1420218050479889e-01
    z[3,0,1]  R371      -6.9788807630538940e-01
    z[3,0,1]  R372      -7.2894757986068726e-01
    z[3,0,1]  R373      -3.8785722851753235e-01
    z[3,0,1]  R374      -4.9330314993858337e-01
    z[3,0,1]  R375      -0.549047589302063
    z[3,0,1]  R376      -7.3758912086486816e-01
    z[3,0,1]  R377      -6.3828259706497192e-01
    z[3,0,1]  R378      -6.0159695148468018e-01
    z[3,0,1]  R379      -0.551503598690033
    z[3,0,1]  R380      -5.4990863800048828e-01
    z[3,0,1]  R381      -1.7415808141231537e-01
    z[3,0,1]  R382      -5.0131946802139282e-01
    z[3,0,1]  R383      3.1767040491104126e-01
    z[3,0,1]  R384      -4.1771686077117920e-01
    z[3,0,1]  R385      -4.2553973197937012e-01
    z[3,0,1]  R386      -0.717606246471405
    z[3,0,1]  R387      -5.2050924301147461e-01
    z[3,0,1]  R388      1.4430856704711914e-01
    z[3,0,1]  R389      1.8928368389606476e-01
    z[3,0,1]  R390      -2.1338941156864166e-01
    z[3,0,1]  R391      -3.8782188296318054e-01
    z[3,0,1]  R392      -3.3455827832221985e-01
    z[3,0,1]  R393      -1.8127226829528809e-01
    z[3,0,1]  R394      5.7150256633758545e-01
    z[3,0,1]  R395      -4.0909606218338013e-01
    z[3,0,1]  R396      3.9326825737953186e-01
    z[3,0,1]  R397      -3.2245048880577087e-01
    z[3,0,1]  R398      1.5870548784732819e-01
    z[3,0,1]  R399      1.9267785549163818e-01
    z[3,0,1]  R400      2.7879431843757629e-01
    z[3,0,1]  R401      4.3742680549621582e-01
    z[3,0,1]  R402      5.0138658285140991e-01
    z[3,0,1]  R403      2.9762953519821167e-01
    z[3,0,1]  R404      2.5165641307830811e-01
    z[3,0,1]  R405      4.4293156266212463e-01
    z[3,0,1]  R406      5.9310346841812134e-01
    z[3,0,1]  R407      3.6480927467346191e-01
    z[3,0,1]  R408      -4.7468325495719910e-01
    z[3,0,1]  R409      4.5324820280075073e-01
    z[3,0,1]  R410      4.3186369538307190e-01
    z[3,0,1]  R411      -1.9462096691131592e-01
    z[3,0,1]  R412      -3.0049049854278564e-01
    z[3,0,1]  R413      -3.4105396270751953e-01
    z[3,0,1]  R414      -4.4918251037597656e-01
    z[3,0,1]  R415      -4.4155994057655334e-01
    z[3,0,1]  R416      -0.372814804315567
    z[3,0,1]  R417      5.1849503070116043e-02
    z[3,0,1]  R418      -6.5198218822479248e-01
    z[3,0,1]  R419      9.6570156514644623e-02
    z[3,0,1]  R420      3.3297258615493774e-01
    z[3,0,1]  R421      5.8803703635931015e-02
    z[3,0,1]  R422      2.9408693313598633e-02
    z[3,0,1]  R423      -2.7275240421295166e-01
    z[3,0,1]  R424      4.1085100173950195e-01
    z[3,0,1]  R425      -4.9133521318435669e-01
    z[3,0,1]  R426      6.2088662385940552e-01
    z[3,0,1]  R427      -5.6678557395935059e-01
    z[3,0,1]  R428      -3.5645613074302673e-01
    z[3,0,1]  R429      1.5330517292022705e-01
    z[3,0,1]  R430      6.5617656707763672e-01
    z[3,0,1]  R431      -4.7061309218406677e-01
    z[3,0,1]  R432      -4.6602806448936462e-01
    z[3,0,1]  R433      -7.6760894060134888e-01
    z[3,0,1]  R434      -5.4526710510253906e-01
    z[3,0,1]  R435      -5.2219486236572266e-01
    z[3,0,1]  R436      -5.5512249469757080e-01
    z[3,0,1]  R437      -8.9052587747573853e-02
    z[3,0,1]  R438      9.1685699298977852e-03
    z[3,0,2]  R4        1
    z[3,0,2]  R31       -1
    z[3,0,2]  R350      -1
    z[3,0,2]  R351      1
    z[3,0,2]  R360      -1.9149206578731537e-01
    z[3,0,2]  R361      -6.1956530809402466e-01
    z[3,0,2]  R362      -1.0150258988142014e-01
    z[3,0,2]  R363      5.1067221164703369e-01
    z[3,0,2]  R364      -3.0399185419082642e-01
    z[3,0,2]  R365      -6.3550509512424469e-02
    z[3,0,2]  R366      -4.3908601999282837e-01
    z[3,0,2]  R367      -5.5459529161453247e-01
    z[3,0,2]  R368      -2.8686091303825378e-01
    z[3,0,2]  R369      0.0934213399887085
    z[3,0,2]  R370      -2.7673307061195374e-01
    z[3,0,2]  R371      -1.6257500648498535e-01
    z[3,0,2]  R372      2.0472067594528198e-01
    z[3,0,2]  R373      1.8409414589405060e-01
    z[3,0,2]  R374      1.0388576984405518e-01
    z[3,0,2]  R375      1.4887210726737976e-01
    z[3,0,2]  R376      4.9851119518280029e-02
    z[3,0,2]  R377      1.0713803023099899e-01
    z[3,0,2]  R378      2.0366646349430084e-01
    z[3,0,2]  R379      -1.4279303140938282e-02
    z[3,0,2]  R380      1.8054470419883728e-01
    z[3,0,2]  R381      -3.8066647946834564e-02
    z[3,0,2]  R382      1.5422993898391724e-01
    z[3,0,2]  R383      1.4361312985420227e-01
    z[3,0,2]  R384      4.2949758470058441e-02
    z[3,0,2]  R385      1.5921603143215179e-01
    z[3,0,2]  R386      1.7752985656261444e-01
    z[3,0,2]  R387      1.6489961743354797e-01
    z[3,0,2]  R388      3.1613722443580627e-01
    z[3,0,2]  R389      -9.1805821657180786e-01
    z[3,0,2]  R390      -0.821935772895813
    z[3,0,2]  R391      -8.4933263063430786e-01
    z[3,0,2]  R392      -6.5146356821060181e-01
    z[3,0,2]  R393      -8.2496714591979980e-01
    z[3,0,2]  R394      -4.8234471678733826e-01
    z[3,0,2]  R395      -4.8315051198005676e-01
    z[3,0,2]  R396      -6.1321413516998291e-01
    z[3,0,2]  R397      -4.4579333066940308e-01
    z[3,0,2]  R398      -1.8195107579231262e-01
    z[3,0,2]  R399      -4.0797176957130432e-01
    z[3,0,2]  R400      -4.8612919449806213e-01
    z[3,0,2]  R401      -4.4271695613861084e-01
    z[3,0,2]  R402      2.0488208532333374e-01
    z[3,0,2]  R403      0.0739821344614029
    z[3,0,2]  R404      -0.054900873452425
    z[3,0,2]  R405      1.4309750497341156e-01
    z[3,0,2]  R406      6.8344056606292725e-02
    z[3,0,2]  R407      5.7367127388715744e-02
    z[3,0,2]  R408      7.0916898548603058e-02
    z[3,0,2]  R409      -7.3335152864456177e-01
    z[3,0,2]  R410      -3.5523602366447449e-01
    z[3,0,2]  R411      -1.8880613148212433e-01
    z[3,0,2]  R412      -2.7876647189259529e-02
    z[3,0,2]  R413      5.2802741527557373e-02
    z[3,0,2]  R414      5.1044680178165436e-02
    z[3,0,2]  R415      -5.3460329771041870e-02
    z[3,0,2]  R416      1.0595314204692841e-01
    z[3,0,2]  R417      1.1621717363595963e-01
    z[3,0,2]  R418      1.0771667584776878e-02
    z[3,0,2]  R419      -9.1113615036010742e-01
    z[3,0,2]  R420      -7.7042216062545776e-01
    z[3,0,2]  R421      -2.3684878647327423e-01
    z[3,0,2]  R422      -4.8561313748359680e-01
    z[3,0,2]  R423      -8.5821944475173950e-01
    z[3,0,2]  R424      -5.4352372884750366e-01
    z[3,0,2]  R425      -4.0575563907623291e-01
    z[3,0,2]  R426      -4.2720615863800049e-01
    z[3,0,2]  R427      -0.0716678723692894
    z[3,0,2]  R428      4.5296527445316315e-02
    z[3,0,2]  R429      -7.2334235906600952e-01
    z[3,0,2]  R430      -1.6831138730049133e-01
    z[3,0,2]  R431      -1.8809004127979279e-01
    z[3,0,2]  R432      2.0423267781734467e-01
    z[3,0,2]  R433      1.1181588470935822e-01
    z[3,0,2]  R434      8.3945572376251221e-02
    z[3,0,2]  R435      1.3350541889667511e-01
    z[3,0,2]  R436      9.5891840755939484e-02
    z[3,0,2]  R437      1.0333411395549774e-01
    z[3,0,2]  R438      -6.6920608282089233e-02
    z[3,0,3]  R5        1
    z[3,0,3]  R32       -1
    z[3,0,3]  R352      -1
    z[3,0,3]  R353      1
    z[3,0,3]  R360      5.7045191526412964e-01
    z[3,0,3]  R361      4.8253723978996277e-01
    z[3,0,3]  R362      6.8029654026031494e-01
    z[3,0,3]  R363      -1.0830656439065933e-01
    z[3,0,3]  R364      5.0035911798477173e-01
    z[3,0,3]  R365      3.2207110524177551e-01
    z[3,0,3]  R366      2.8305670619010925e-01
    z[3,0,3]  R367      2.8177937865257263e-01
    z[3,0,3]  R368      3.9799353480339050e-01
    z[3,0,3]  R369      -1.1393939703702927e-01
    z[3,0,3]  R370      3.9269354939460754e-01
    z[3,0,3]  R371      4.8071038722991943e-01
    z[3,0,3]  R372      1.0551664978265762e-01
    z[3,0,3]  R373      -3.4226432908326387e-03
    z[3,0,3]  R374      -7.2667285799980164e-02
    z[3,0,3]  R375      -4.0364658832550049e-01
    z[3,0,3]  R376      -5.4425221681594849e-01
    z[3,0,3]  R377      -7.3211288452148438e-01
    z[3,0,3]  R378      -6.5576130151748657e-01
    z[3,0,3]  R379      -7.0714837312698364e-01
    z[3,0,3]  R380      3.7765324115753174e-01
    z[3,0,3]  R381      1.9084180891513824e-01
    z[3,0,3]  R382      -3.1247639656066895e-01
    z[3,0,3]  R383      -4.6759301424026489e-01
    z[3,0,3]  R384      -2.9388004541397095e-01
    z[3,0,3]  R385      -2.9821637272834778e-01
    z[3,0,3]  R386      -2.7308362722396851e-01
    z[3,0,3]  R387      -3.5534223914146423e-01
    z[3,0,3]  R388      -7.9411095380783081e-01
    z[3,0,3]  R389      1.5316574275493622e-01
    z[3,0,3]  R390      4.1749465465545654e-01
    z[3,0,3]  R391      0.186690554022789
    z[3,0,3]  R392      3.3774030208587646e-01
    z[3,0,3]  R393      1.3193790614604950e-01
    z[3,0,3]  R394      1.9470538198947906e-01
    z[3,0,3]  R395      1.0244677215814590e-01
    z[3,0,3]  R396      1.1966568231582642e-01
    z[3,0,3]  R397      0.0622292086482048
    z[3,0,3]  R398      7.1319645643234253e-01
    z[3,0,3]  R399      2.9348948597908020e-01
    z[3,0,3]  R400      7.8819316625595093e-01
    z[3,0,3]  R401      5.9231573343276978e-01
    z[3,0,3]  R402      -3.0174779891967773e-01
    z[3,0,3]  R403      -7.2141259908676147e-01
    z[3,0,3]  R404      5.9243249893188477e-01
    z[3,0,3]  R405      -4.7260278463363647e-01
    z[3,0,3]  R406      -3.9112648367881775e-01
    z[3,0,3]  R407      -6.0366153717041016e-01
    z[3,0,3]  R408      1.7625359818339348e-02
    z[3,0,3]  R409      -1.7079292237758636e-01
    z[3,0,3]  R410      1.3907326757907867e-01
    z[3,0,3]  R411      6.0492914915084839e-01
    z[3,0,3]  R412      7.4371442198753357e-02
    z[3,0,3]  R413      -2.2594090551137924e-02
    z[3,0,3]  R414      -2.0540507137775421e-01
    z[3,0,3]  R415      -4.4240858405828476e-02
    z[3,0,3]  R416      0.419666588306427
    z[3,0,3]  R417      -8.7730005383491516e-02
    z[3,0,3]  R418      4.6109583228826523e-02
    z[3,0,3]  R419      2.3920443654060364e-01
    z[3,0,3]  R420      3.2978153228759766e-01
    z[3,0,3]  R421      8.0333340167999268e-01
    z[3,0,3]  R422      6.1041784286499023e-01
    z[3,0,3]  R423      3.6767061799764633e-02
    z[3,0,3]  R424      1.4024442434310913e-01
    z[3,0,3]  R425      1.7614370584487915e-01
    z[3,0,3]  R426      1.7516884207725525e-01
    z[3,0,3]  R427      0.0334952250123024
    z[3,0,3]  R428      5.9051042795181274e-01
    z[3,0,3]  R429      5.4493576288223267e-01
    z[3,0,3]  R430      5.3646290302276611e-01
    z[3,0,3]  R431      8.6003012955188751e-02
    z[3,0,3]  R432      -9.1377347707748413e-02
    z[3,0,3]  R433      -8.2541637122631073e-02
    z[3,0,3]  R434      3.1068651005625725e-02
    z[3,0,3]  R435      3.6152434349060059e-01
    z[3,0,3]  R436      4.2539575695991516e-01
    z[3,0,3]  R437      3.7138289213180542e-01
    z[3,0,3]  R438      -4.5978936553001404e-01
    z[3,0,4]  R6        1
    z[3,0,4]  R33       -1
    z[3,0,4]  R354      -1
    z[3,0,4]  R355      1
    z[3,0,4]  R360      -5.0928759574890137e-01
    z[3,0,4]  R361      3.3467937260866165e-02
    z[3,0,4]  R362      -3.6692202091217041e-01
    z[3,0,4]  R363      -6.2733925879001617e-02
    z[3,0,4]  R364      1.3942405581474304e-01
    z[3,0,4]  R365      -2.3931907117366791e-01
    z[3,0,4]  R366      -0.0843191146850586
    z[3,0,4]  R367      -2.0380539819598198e-02
    z[3,0,4]  R368      -2.5483930110931396e-01
    z[3,0,4]  R369      1.3971160352230072e-01
    z[3,0,4]  R370      6.4389693737030029e-01
    z[3,0,4]  R371      -3.3352595567703247e-01
    z[3,0,4]  R372      9.9107161164283752e-02
    z[3,0,4]  R373      3.8357204198837280e-01
    z[3,0,4]  R374      -1.7420975863933563e-01
    z[3,0,4]  R375      1.9177092611789703e-01
    z[3,0,4]  R376      1.9314432144165039e-01
    z[3,0,4]  R377      -6.8377837538719177e-02
    z[3,0,4]  R378      -2.2632372379302979e-01
    z[3,0,4]  R379      -2.8030967712402344e-01
    z[3,0,4]  R380      -2.2098235785961151e-01
    z[3,0,4]  R381      5.4563194513320923e-01
    z[3,0,4]  R382      -0.060396958142519
    z[3,0,4]  R383      2.3633283376693726e-01
    z[3,0,4]  R384      -0.493927001953125
    z[3,0,4]  R385      -5.5003982782363892e-01
    z[3,0,4]  R386      1.9689303636550903e-01
    z[3,0,4]  R387      4.7673948109149933e-02
    z[3,0,4]  R388      -1.8436609208583832e-01
    z[3,0,4]  R389      -3.3535573631525040e-02
    z[3,0,4]  R390      -4.9515273422002792e-02
    z[3,0,4]  R391      -2.0375768840312958e-01
    z[3,0,4]  R392      -1.8227109313011169e-01
    z[3,0,4]  R393      -4.5663446187973022e-02
    z[3,0,4]  R394      -1.9856976345181465e-02
    z[3,0,4]  R395      9.8871342837810516e-02
    z[3,0,4]  R396      -7.6052442193031311e-02
    z[3,0,4]  R397      -1.4914900064468384e-01
    z[3,0,4]  R398      2.7532947063446045e-01
    z[3,0,4]  R399      2.2536313533782959e-01
    z[3,0,4]  R400      -1.7508116364479065e-01
    z[3,0,4]  R401      2.4778442084789276e-01
    z[3,0,4]  R402      3.5196027159690857e-01
    z[3,0,4]  R403      2.5746414065361023e-01
    z[3,0,4]  R404      -1.8810817599296570e-01
    z[3,0,4]  R405      2.8861114382743835e-01
    z[3,0,4]  R406      -7.0296205580234528e-02
    z[3,0,4]  R407      5.1523327827453613e-02
    z[3,0,4]  R408      -3.2622924447059631e-01
    z[3,0,4]  R409      3.3899492025375366e-01
    z[3,0,4]  R410      2.0529222674667835e-03
    z[3,0,4]  R411      -4.2526370286941528e-01
    z[3,0,4]  R412      -3.6457857489585876e-01
    z[3,0,4]  R413      -1.7739592492580414e-01
    z[3,0,4]  R414      2.1899169683456421e-01
    z[3,0,4]  R415      2.4537268280982971e-01
    z[3,0,4]  R416      7.0082515478134155e-02
    z[3,0,4]  R417      1.8526118993759155e-01
    z[3,0,4]  R418      -2.6621100306510925e-01
    z[3,0,4]  R419      3.3498089760541916e-02
    z[3,0,4]  R420      -2.4963997304439545e-01
    z[3,0,4]  R421      1.4572843909263611e-01
    z[3,0,4]  R422      -2.4555815756320953e-01
    z[3,0,4]  R423      2.2103634476661682e-01
    z[3,0,4]  R424      2.6744395494461060e-01
    z[3,0,4]  R425      -2.2378663718700409e-01
    z[3,0,4]  R426      8.9534647762775421e-02
    z[3,0,4]  R427      -1.6200336813926697e-01
    z[3,0,4]  R428      -3.2173395156860352e-01
    z[3,0,4]  R429      -1.8126342445611954e-02
    z[3,0,4]  R430      -0.0687897801399231
    z[3,0,4]  R431      -1.0060327500104904e-01
    z[3,0,4]  R432      1.4072653651237488e-01
    z[3,0,4]  R433      -0.217131569981575
    z[3,0,4]  R434      -3.9464724063873291e-01
    z[3,0,4]  R435      -7.1288503706455231e-02
    z[3,0,4]  R436      -0.252402663230896
    z[3,0,4]  R437      1.7273065447807312e-01
    z[3,0,4]  R438      -4.5735105872154236e-02
    z[3,0,5]  R7        1
    z[3,0,5]  R34       -1
    z[3,0,5]  R356      -1
    z[3,0,5]  R357      1
    z[3,0,5]  R360      8.1511437892913818e-02
    z[3,0,5]  R361      4.6914857625961304e-01
    z[3,0,5]  R362      -7.9469613730907440e-02
    z[3,0,5]  R363      -5.7158374786376953e-01
    z[3,0,5]  R364      -9.7945593297481537e-02
    z[3,0,5]  R365      -4.0284192562103271e-01
    z[3,0,5]  R366      2.1341418847441673e-02
    z[3,0,5]  R367      3.0682021379470825e-01
    z[3,0,5]  R368      3.8957217335700989e-01
    z[3,0,5]  R369      1.9616955518722534e-01
    z[3,0,5]  R370      -4.7348102927207947e-01
    z[3,0,5]  R371      -3.2203987240791321e-01
    z[3,0,5]  R372      -2.7028828859329224e-01
    z[3,0,5]  R373      6.8928644061088562e-02
    z[3,0,5]  R374      -2.3548196256160736e-01
    z[3,0,5]  R375      1.0767978429794312e-01
    z[3,0,5]  R376      -3.4833904355764389e-02
    z[3,0,5]  R377      -1.7041069269180298e-01
    z[3,0,5]  R378      2.4099244177341461e-01
    z[3,0,5]  R379      2.1224381402134895e-02
    z[3,0,5]  R380      -3.2692757248878479e-01
    z[3,0,5]  R381      2.1178103983402252e-01
    z[3,0,5]  R382      1.9609722495079041e-01
    z[3,0,5]  R383      5.3016132116317749e-01
    z[3,0,5]  R384      8.2845687866210938e-02
    z[3,0,5]  R385      2.4352923035621643e-01
    z[3,0,5]  R386      7.0529342629015446e-03
    z[3,0,5]  R387      -2.6302334666252136e-01
    z[3,0,5]  R388      2.1879564225673676e-01
    z[3,0,5]  R389      9.2932768166065216e-02
    z[3,0,5]  R390      -1.8901444971561432e-01
    z[3,0,5]  R391      -2.1008993685245514e-01
    z[3,0,5]  R392      4.0209561586380005e-01
    z[3,0,5]  R393      2.2197328507900238e-01
    z[3,0,5]  R394      -1.7166697978973389e-01
    z[3,0,5]  R395      4.3754315376281738e-01
    z[3,0,5]  R396      -5.9859317541122437e-01
    z[3,0,5]  R397      -5.3073191642761230e-01
    z[3,0,5]  R398      1.7103178799152374e-01
    z[3,0,5]  R399      -2.0624138414859772e-01
    z[3,0,5]  R400      1.7194516956806183e-01
    z[3,0,5]  R401      1.0926352441310883e-01
    z[3,0,5]  R402      1.5449135005474091e-01
    z[3,0,5]  R403      -5.7839006185531616e-02
    z[3,0,5]  R404      2.7391710877418518e-01
    z[3,0,5]  R405      3.9220470190048218e-01
    z[3,0,5]  R406      -6.0699041932821274e-02
    z[3,0,5]  R407      2.8945362567901611e-01
    z[3,0,5]  R408      -2.8680872172117233e-02
    z[3,0,5]  R409      -3.0305898189544678e-01
    z[3,0,5]  R410      2.1535551548004150e-01
    z[3,0,5]  R411      -4.5871835947036743e-01
    z[3,0,5]  R412      8.2992248237133026e-02
    z[3,0,5]  R413      2.2274820506572723e-01
    z[3,0,5]  R414      3.8611114025115967e-02
    z[3,0,5]  R415      -1.0222090035676956e-01
    z[3,0,5]  R416      3.6876723170280457e-01
    z[3,0,5]  R417      -2.4792829155921936e-01
    z[3,0,5]  R418      2.7647942304611206e-01
    z[3,0,5]  R419      9.5163963735103607e-02
    z[3,0,5]  R420      4.6929683536291122e-02
    z[3,0,5]  R421      5.9022769331932068e-02
    z[3,0,5]  R422      -5.6864005327224731e-01
    z[3,0,5]  R423      7.8296266496181488e-02
    z[3,0,5]  R424      6.3668382167816162e-01
    z[3,0,5]  R425      -3.7976327538490295e-01
    z[3,0,5]  R426      5.5324655771255493e-01
    z[3,0,5]  R427      -5.7667877525091171e-02
    z[3,0,5]  R428      -0.0557275153696537
    z[3,0,5]  R429      3.4259703010320663e-02
    z[3,0,5]  R430      -4.8903831839561462e-01
    z[3,0,5]  R431      -3.9436902850866318e-02
    z[3,0,5]  R432      -1.8040984869003296e-01
    z[3,0,5]  R433      -1.4283163845539093e-01
    z[3,0,5]  R434      -1.1372285336256027e-01
    z[3,0,5]  R435      0.0759860947728157
    z[3,0,5]  R436      3.4039494395256042e-01
    z[3,0,5]  R437      -1.7409792542457581e-01
    z[3,0,5]  R438      -4.3879696726799011e-01
    z[3,0,6]  R8        1
    z[3,0,6]  R35       -1
    z[3,0,6]  R358      -1
    z[3,0,6]  R359      1
    z[3,0,6]  R360      -6.2325235456228256e-02
    z[3,0,6]  R361      -8.0800447613000870e-03
    z[3,0,6]  R362      4.7462871670722961e-01
    z[3,0,6]  R363      2.6106837391853333e-01
    z[3,0,6]  R364      -4.8445445299148560e-01
    z[3,0,6]  R365      -0.69123375415802
    z[3,0,6]  R366      -3.4347614645957947e-01
    z[3,0,6]  R367      -6.9000262022018433e-01
    z[3,0,6]  R368      -3.4912335872650146e-01
    z[3,0,6]  R369      6.3749450445175171e-01
    z[3,0,6]  R370      2.1101489663124084e-01
    z[3,0,6]  R371      -0.186966210603714
    z[3,0,6]  R372      3.9959362149238586e-01
    z[3,0,6]  R373      2.7085286378860474e-01
    z[3,0,6]  R374      2.3601894080638885e-01
    z[3,0,6]  R375      3.2111827284097672e-02
    z[3,0,6]  R376      -2.9096311330795288e-01
    z[3,0,6]  R377      -9.9338285624980927e-02
    z[3,0,6]  R378      2.3325771093368530e-01
    z[3,0,6]  R379      2.3498864471912384e-01
    z[3,0,6]  R380      3.7359076738357544e-01
    z[3,0,6]  R381      3.6271774768829346e-01
    z[3,0,6]  R382      -1.2907078862190247e-01
    z[3,0,6]  R383      -3.0316799879074097e-01
    z[3,0,6]  R384      -1.4830298721790314e-01
    z[3,0,6]  R385      -1.4721424877643585e-01
    z[3,0,6]  R386      0.0926625207066536
    z[3,0,6]  R387      -0.379141241312027
    z[3,0,6]  R388      -3.5547509789466858e-01
    z[3,0,6]  R389      -7.7646985650062561e-02
    z[3,0,6]  R390      2.2368364036083221e-01
    z[3,0,6]  R391      -0.00801405031234026
    z[3,0,6]  R392      -1.0292106121778488e-01
    z[3,0,6]  R393      -3.9872547984123230e-01
    z[3,0,6]  R394      -6.0501378774642944e-01
    z[3,0,6]  R395      9.0815395116806030e-02
    z[3,0,6]  R396      -9.9978566169738770e-02
    z[3,0,6]  R397      -4.7355449199676514e-01
    z[3,0,6]  R398      3.7781819701194763e-01
    z[3,0,6]  R399      9.2529594898223877e-02
    z[3,0,6]  R400      -4.7485128045082092e-02
    z[3,0,6]  R401      3.2669717073440552e-01
    z[3,0,6]  R402      7.1300998330116272e-02
    z[3,0,6]  R403      -8.8774301111698151e-02
    z[3,0,6]  R404      -0.277802973985672
    z[3,0,6]  R405      -2.6915711164474487e-01
    z[3,0,6]  R406      -3.0051326751708984e-01
    z[3,0,6]  R407      -3.5231578350067139e-01
    z[3,0,6]  R408      -3.1592342257499695e-01
    z[3,0,6]  R409      4.3523173779249191e-02
    z[3,0,6]  R410      -1.8603503704071045e-02
    z[3,0,6]  R411      -1.4835110306739807e-01
    z[3,0,6]  R412      -4.2224639654159546e-01
    z[3,0,6]  R413      1.3989524543285370e-01
    z[3,0,6]  R414      3.5618028044700623e-01
    z[3,0,6]  R415      0.0871143639087677
    z[3,0,6]  R416      5.0407934933900833e-02
    z[3,0,6]  R417      1.0933487862348557e-01
    z[3,0,6]  R418      1.4906217157840729e-01
    z[3,0,6]  R419      7.8052692115306854e-02
    z[3,0,6]  R420      -3.3254516124725342e-01
    z[3,0,6]  R421      3.4663116931915283e-01
    z[3,0,6]  R422      1.0936836712062359e-02
    z[3,0,6]  R423      2.4585144221782684e-01
    z[3,0,6]  R424      -0.0379331074655056
    z[3,0,6]  R425      -4.8347041010856628e-02
    z[3,0,6]  R426      -1.9569578766822815e-01
    z[3,0,6]  R427      -1.6855119168758392e-01
    z[3,0,6]  R428      -7.4472457170486450e-02
    z[3,0,6]  R429      -1.8850931897759438e-02
    z[3,0,6]  R430      -9.7053229808807373e-02
    z[3,0,6]  R431      -4.8596754670143127e-01
    z[3,0,6]  R432      -1.7079439759254456e-01
    z[3,0,6]  R433      -1.0855325311422348e-01
    z[3,0,6]  R434      4.2523756623268127e-02
    z[3,0,6]  R435      4.6377268433570862e-01
    z[3,0,6]  R436      0.243007093667984
    z[3,0,6]  R437      2.0650866627693176e-01
    z[3,0,6]  R438      4.8855948261916637e-03
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R503      -1
    z[1,2,0]  R504      1
    z[1,2,0]  R517      6.1083510518074036e-02
    z[1,2,0]  R518      2.1380166709423065e-01
    z[1,2,0]  R519      -7.3983520269393921e-01
    z[1,2,0]  R520      2.5135216116905212e-01
    z[1,2,0]  R521      8.9019227027893066e-01
    z[1,2,0]  R522      8.5609972476959229e-01
    z[1,2,0]  R523      -4.3352678418159485e-02
    z[1,2,0]  R524      -2.3973140120506287e-01
    z[1,2,0]  R525      3.1451526284217834e-01
    z[1,2,0]  R526      5.4635588079690933e-02
    z[1,2,0]  R527      3.8354450464248657e-01
    z[1,2,0]  R528      3.0896863341331482e-01
    z[1,2,0]  R529      7.9854726791381836e-02
    z[1,2,0]  R530      -2.5239627808332443e-02
    z[1,2,0]  R531      2.7237203717231750e-01
    z[1,2,0]  R532      -3.5902258753776550e-01
    z[1,2,0]  R533      -2.9740709066390991e-01
    z[1,2,0]  R534      -4.5330911874771118e-02
    z[1,2,0]  R535      -3.8903504610061646e-01
    z[1,2,0]  R536      -1.7127676308155060e-01
    z[1,2,0]  R537      6.3217975199222565e-02
    z[1,2,0]  R538      -1.8302571773529053e-01
    z[1,2,0]  R539      -4.7933542728424072e-01
    z[1,2,0]  R540      3.4628391265869141e-01
    z[1,2,0]  R541      2.0839316770434380e-02
    z[1,2,0]  R542      1.1791638284921646e-01
    z[1,2,0]  R543      -5.6895387172698975e-01
    z[1,2,0]  R544      1.9080510735511780e-01
    z[1,2,0]  R545      -2.1374617516994476e-01
    z[1,2,0]  R546      -0.562109112739563
    z[1,2,0]  R547      -3.7761595845222473e-01
    z[1,2,0]  R548      -2.6884365081787109e-01
    z[1,2,0]  R549      7.9843342304229736e-01
    z[1,2,0]  R550      8.7542468309402466e-01
    z[1,2,0]  R551      8.4131413698196411e-01
    z[1,2,0]  R552      0.419920414686203
    z[1,2,0]  R553      0.285171240568161
    z[1,2,0]  R554      3.6918950080871582e-01
    z[1,2,0]  R555      6.9000291824340820e-01
    z[1,2,0]  R556      6.2999832630157471e-01
    z[1,2,0]  R557      -3.1384840607643127e-01
    z[1,2,0]  R558      -2.1706500649452209e-01
    z[1,2,0]  R559      1.7495959997177124e-01
    z[1,2,0]  R560      3.1879001855850220e-01
    z[1,2,0]  R561      2.0410983264446259e-01
    z[1,2,0]  R562      0.538845419883728
    z[1,2,0]  R563      4.7156815417110920e-03
    z[1,2,0]  R564      5.1173609495162964e-01
    z[1,2,0]  R565      3.5414862632751465e-01
    z[1,2,0]  R566      1.5112403035163879e-01
    z[1,2,0]  R567      3.5378584265708923e-01
    z[1,2,0]  R568      -7.7039031311869621e-03
    z[1,2,0]  R569      5.1625329256057739e-01
    z[1,2,0]  R570      5.4666346311569214e-01
    z[1,2,0]  R571      -2.4800196290016174e-01
    z[1,2,0]  R572      4.0988841652870178e-01
    z[1,2,0]  R573      3.5897067189216614e-01
    z[1,2,0]  R574      6.8418520689010620e-01
    z[1,2,0]  R575      5.2593183517456055e-01
    z[1,2,0]  R576      3.0959594249725342e-01
    z[1,2,0]  R577      -3.0739870667457581e-01
    z[1,2,0]  R578      -5.9899266809225082e-02
    z[1,2,0]  R579      5.0955039262771606e-01
    z[1,2,0]  R580      6.1493802070617676e-01
    z[1,2,0]  R581      0.53638756275177
    z[1,2,0]  R582      6.5523380041122437e-01
    z[1,2,0]  R583      2.7248516678810120e-01
    z[1,2,0]  R584      3.8072407245635986e-01
    z[1,2,0]  R585      8.6608707904815674e-01
    z[1,2,0]  R586      5.1091867685317993e-01
    z[1,2,0]  R587      -4.8466438055038452e-01
    z[1,2,0]  R588      -2.2906814515590668e-01
    z[1,2,0]  R589      -1.3635233044624329e-02
    z[1,2,0]  R590      9.6427626907825470e-02
    z[1,2,0]  R591      4.2372739315032959e-01
    z[1,2,0]  R592      5.4470956325531006e-01
    z[1,2,0]  R593      6.6702020168304443e-01
    z[1,2,0]  R594      5.1377475261688232e-02
    z[1,2,0]  R595      7.0297127962112427e-01
    z[1,2,0]  R596      7.1857148408889771e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R505      -1
    z[1,2,1]  R506      1
    z[1,2,1]  R517      5.9199923276901245e-01
    z[1,2,1]  R518      -1.7263798415660858e-01
    z[1,2,1]  R519      6.1789894104003906e-01
    z[1,2,1]  R520      2.8438141942024231e-01
    z[1,2,1]  R521      -3.3239364624023438e-01
    z[1,2,1]  R522      -2.8496605157852173e-01
    z[1,2,1]  R523      3.6099424958229065e-01
    z[1,2,1]  R524      0.552646815776825
    z[1,2,1]  R525      -8.3604240417480469e-01
    z[1,2,1]  R526      4.0312197804450989e-01
    z[1,2,1]  R527      7.0076704025268555e-01
    z[1,2,1]  R528      5.3063219785690308e-01
    z[1,2,1]  R529      -1.3068813085556030e-01
    z[1,2,1]  R530      -7.0500189065933228e-01
    z[1,2,1]  R531      -0.484901487827301
    z[1,2,1]  R532      -7.5998403131961823e-02
    z[1,2,1]  R533      5.8496486395597458e-02
    z[1,2,1]  R534      -7.3956793546676636e-01
    z[1,2,1]  R535      -1.9420027732849121e-02
    z[1,2,1]  R536      -6.9828546047210693e-01
    z[1,2,1]  R537      4.2234563827514648e-01
    z[1,2,1]  R538      -2.5246351957321167e-01
    z[1,2,1]  R539      2.1436658501625061e-01
    z[1,2,1]  R540      -3.4335559606552124e-01
    z[1,2,1]  R541      4.6609568595886230e-01
    z[1,2,1]  R542      -5.4194486141204834e-01
    z[1,2,1]  R543      4.5076854526996613e-02
    z[1,2,1]  R544      -4.0479990839958191e-01
    z[1,2,1]  R545      7.3992349207401276e-02
    z[1,2,1]  R546      -5.0194181501865387e-02
    z[1,2,1]  R547      3.8441542536020279e-02
    z[1,2,1]  R548      8.1759430468082428e-02
    z[1,2,1]  R549      -4.0119934082031250e-01
    z[1,2,1]  R550      -2.3960407078266144e-01
    z[1,2,1]  R551      -3.0244883894920349e-01
    z[1,2,1]  R552      -0.802794873714447
    z[1,2,1]  R553      -8.8745057582855225e-01
    z[1,2,1]  R554      -0.754834771156311
    z[1,2,1]  R555      -3.9399498701095581e-01
    z[1,2,1]  R556      8.5442259907722473e-02
    z[1,2,1]  R557      5.6618911027908325e-01
    z[1,2,1]  R558      2.3656965792179108e-01
    z[1,2,1]  R559      5.4735934734344482e-01
    z[1,2,1]  R560      4.4414228200912476e-01
    z[1,2,1]  R561      6.6778522729873657e-01
    z[1,2,1]  R562      6.4470344781875610e-01
    z[1,2,1]  R563      4.5176360011100769e-01
    z[1,2,1]  R564      3.9058855175971985e-01
    z[1,2,1]  R565      4.3951633572578430e-01
    z[1,2,1]  R566      6.5985703468322754e-01
    z[1,2,1]  R567      2.5097227096557617e-01
    z[1,2,1]  R568      0.688449501991272
    z[1,2,1]  R569      4.6634155511856079e-01
    z[1,2,1]  R570      -6.1167693138122559e-01
    z[1,2,1]  R571      -5.3506873548030853e-02
    z[1,2,1]  R572      -6.4141339063644409e-01
    z[1,2,1]  R573      -7.2092831134796143e-01
    z[1,2,1]  R574      -3.9164590835571289e-01
    z[1,2,1]  R575      -6.4713460206985474e-01
    z[1,2,1]  R576      -6.1470401287078857e-01
    z[1,2,1]  R577      8.1374222040176392e-01
    z[1,2,1]  R578      8.5356724262237549e-01
    z[1,2,1]  R579      -6.6358691453933716e-01
    z[1,2,1]  R580      -5.5984467267990112e-01
    z[1,2,1]  R581      -6.9038879871368408e-01
    z[1,2,1]  R582      -4.7251582145690918e-01
    z[1,2,1]  R583      -7.4744731187820435e-01
    z[1,2,1]  R584      -6.1545717716217041e-01
    z[1,2,1]  R585      -3.5275623202323914e-01
    z[1,2,1]  R586      -4.5408290624618530e-01
    z[1,2,1]  R587      -3.5253381729125977e-01
    z[1,2,1]  R588      8.0153006315231323e-01
    z[1,2,1]  R589      8.7071365118026733e-01
    z[1,2,1]  R590      5.4113519191741943e-01
    z[1,2,1]  R591      5.0517255067825317e-01
    z[1,2,1]  R592      0.586051881313324
    z[1,2,1]  R593      5.4306948184967041e-01
    z[1,2,1]  R594      8.1572657823562622e-01
    z[1,2,1]  R595      -3.9696505665779114e-01
    z[1,2,1]  R596      -2.6708725094795227e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R507      -1
    z[1,2,2]  R508      1
    z[1,2,2]  R517      -2.7311458252370358e-03
    z[1,2,2]  R518      -4.7505609691143036e-02
    z[1,2,2]  R519      -1.6115337610244751e-01
    z[1,2,2]  R520      -1.4312425628304482e-02
    z[1,2,2]  R521      -7.1665213909000158e-05
    z[1,2,2]  R522      1.2088888138532639e-01
    z[1,2,2]  R523      -4.1242414154112339e-03
    z[1,2,2]  R524      -2.9520472511649132e-02
    z[1,2,2]  R525      -1.7982059717178345e-01
    z[1,2,2]  R526      8.2160130143165588e-02
    z[1,2,2]  R527      1.3549405336380005e-01
    z[1,2,2]  R528      -6.9270215928554535e-02
    z[1,2,2]  R529      -1.4978380501270294e-01
    z[1,2,2]  R530      5.1258418709039688e-02
    z[1,2,2]  R531      2.1003323793411255e-01
    z[1,2,2]  R532      1.7651681602001190e-01
    z[1,2,2]  R533      1.1088189668953419e-02
    z[1,2,2]  R534      7.0806264877319336e-02
    z[1,2,2]  R535      0.0782213807106018
    z[1,2,2]  R536      1.3924143277108669e-02
    z[1,2,2]  R537      -1.6303548216819763e-01
    z[1,2,2]  R538      -2.1536026149988174e-02
    z[1,2,2]  R539      -0.0760052353143692
    z[1,2,2]  R540      2.0098702609539032e-01
    z[1,2,2]  R541      -6.1345055699348450e-02
    z[1,2,2]  R542      -1.3458553701639175e-02
    z[1,2,2]  R543      3.7188690900802612e-01
    z[1,2,2]  R544      1.6649918258190155e-01
    z[1,2,2]  R545      6.5833173692226410e-02
    z[1,2,2]  R546      4.1337138414382935e-01
    z[1,2,2]  R547      7.4965290725231171e-02
    z[1,2,2]  R548      0.681813657283783
    z[1,2,2]  R549      1.4072988927364349e-01
    z[1,2,2]  R550      1.7492705583572388e-01
    z[1,2,2]  R551      1.3756878674030304e-02
    z[1,2,2]  R552      -1.7958280444145203e-01
    z[1,2,2]  R553      -3.4977486357092857e-03
    z[1,2,2]  R554      1.0772727429866791e-01
    z[1,2,2]  R555      3.0122503638267517e-01
    z[1,2,2]  R556      5.3374260663986206e-01
    z[1,2,2]  R557      3.3036175370216370e-01
    z[1,2,2]  R558      -1.0271928459405899e-01
    z[1,2,2]  R559      3.5235092509537935e-03
    z[1,2,2]  R560      -1.6434369981288910e-01
    z[1,2,2]  R561      -3.0935943126678467e-01
    z[1,2,2]  R562      2.0727092027664185e-01
    z[1,2,2]  R563      -3.2779264450073242e-01
    z[1,2,2]  R564      2.4899050593376160e-01
    z[1,2,2]  R565      -9.0174794197082520e-02
    z[1,2,2]  R566      -1.8114100396633148e-01
    z[1,2,2]  R567      7.9812347888946533e-01
    z[1,2,2]  R568      6.2663513422012329e-01
    z[1,2,2]  R569      4.0392029285430908e-01
    z[1,2,2]  R570      -7.3203317821025848e-02
    z[1,2,2]  R571      2.7970877289772034e-01
    z[1,2,2]  R572      1.5855786204338074e-01
    z[1,2,2]  R573      2.7109023928642273e-01
    z[1,2,2]  R574      -1.7429442703723907e-01
    z[1,2,2]  R575      -5.2469903230667114e-01
    z[1,2,2]  R576      2.7236273884773254e-01
    z[1,2,2]  R577      -1.1220594495534897e-01
    z[1,2,2]  R578      -3.8480564951896667e-01
    z[1,2,2]  R579      2.0183211192488670e-02
    z[1,2,2]  R580      2.4744583293795586e-02
    z[1,2,2]  R581      -2.3151947557926178e-01
    z[1,2,2]  R582      -2.6929610967636108e-01
    z[1,2,2]  R583      3.4785324335098267e-01
    z[1,2,2]  R584      4.8382428288459778e-01
    z[1,2,2]  R585      2.1594485267996788e-02
    z[1,2,2]  R586      -2.0730255171656609e-02
    z[1,2,2]  R587      1.1036302149295807e-01
    z[1,2,2]  R588      3.5348507761955261e-01
    z[1,2,2]  R589      0.0318136028945446
    z[1,2,2]  R590      5.4831538349390030e-02
    z[1,2,2]  R591      4.4717624783515930e-02
    z[1,2,2]  R592      -1.7602179944515228e-01
    z[1,2,2]  R593      2.6207652688026428e-01
    z[1,2,2]  R594      -4.0650373697280884e-01
    z[1,2,2]  R595      4.3773704767227173e-01
    z[1,2,2]  R596      3.4073731303215027e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R509      -1
    z[1,2,3]  R510      1
    z[1,2,3]  R517      4.5125576853752136e-01
    z[1,2,3]  R518      -6.9074326753616333e-01
    z[1,2,3]  R519      1.8896495923399925e-02
    z[1,2,3]  R520      0.397897869348526
    z[1,2,3]  R521      8.4381639957427979e-02
    z[1,2,3]  R522      3.5591584444046021e-01
    z[1,2,3]  R523      9.2086660861968994e-01
    z[1,2,3]  R524      -3.1765013933181763e-01
    z[1,2,3]  R525      1.0727182030677795e-01
    z[1,2,3]  R526      3.9924341440200806e-01
    z[1,2,3]  R527      -1.9374012947082520e-01
    z[1,2,3]  R528      -2.3194399476051331e-01
    z[1,2,3]  R529      -8.7596736848354340e-02
    z[1,2,3]  R530      3.3047983050346375e-01
    z[1,2,3]  R531      2.3281952738761902e-01
    z[1,2,3]  R532      -5.7619011402130127e-01
    z[1,2,3]  R533      -7.4140834808349609e-01
    z[1,2,3]  R534      4.0285822749137878e-01
    z[1,2,3]  R535      -2.5792804360389709e-01
    z[1,2,3]  R536      3.4212014079093933e-01
    z[1,2,3]  R537      2.5536033511161804e-01
    z[1,2,3]  R538      -1.9580744206905365e-02
    z[1,2,3]  R539      5.1058417558670044e-01
    z[1,2,3]  R540      5.7484978437423706e-01
    z[1,2,3]  R541      -2.0147246122360229e-01
    z[1,2,3]  R542      6.7178118228912354e-01
    z[1,2,3]  R543      -5.1815766096115112e-01
    z[1,2,3]  R544      6.8073445558547974e-01
    z[1,2,3]  R545      -6.5127015113830566e-01
    z[1,2,3]  R546      -2.6127964258193970e-01
    z[1,2,3]  R547      -6.8057513236999512e-01
    z[1,2,3]  R548      1.2966774404048920e-01
    z[1,2,3]  R549      1.4103873074054718e-01
    z[1,2,3]  R550      2.2557689249515533e-01
    z[1,2,3]  R551      3.4696063399314880e-01
    z[1,2,3]  R552      1.0997498035430908e-01
    z[1,2,3]  R553      -1.4441721141338348e-01
    z[1,2,3]  R554      -3.9046889543533325e-01
    z[1,2,3]  R555      2.1113230288028717e-01
    z[1,2,3]  R556      -4.3737614154815674e-01
    z[1,2,3]  R557      -0.275144100189209
    z[1,2,3]  R558      3.6345925927162170e-01
    z[1,2,3]  R559      -1.2501551210880280e-01
    z[1,2,3]  R560      -4.3762576580047607e-01
    z[1,2,3]  R561      -3.6428907513618469e-01
    z[1,2,3]  R562      7.4119992554187775e-02
    z[1,2,3]  R563      -2.9075714945793152e-01
    z[1,2,3]  R564      -1.3685405254364014e-02
    z[1,2,3]  R565      -1.0349833220243454e-01
    z[1,2,3]  R566      5.0873857736587524e-01
    z[1,2,3]  R567      -3.3803546428680420e-01
    z[1,2,3]  R568      2.2532603144645691e-01
    z[1,2,3]  R569      5.0569951534271240e-01
    z[1,2,3]  R570      5.6493043899536133e-01
    z[1,2,3]  R571      -5.5822163820266724e-01
    z[1,2,3]  R572      1.5094357728958130e-01
    z[1,2,3]  R573      -6.5323412418365479e-02
    z[1,2,3]  R574      1.8714305013418198e-02
    z[1,2,3]  R575      2.0260209217667580e-02
    z[1,2,3]  R576      -4.6693214774131775e-01
    z[1,2,3]  R577      1.3155084848403931e-01
    z[1,2,3]  R578      0.0213027261197567
    z[1,2,3]  R579      -1.2451861053705215e-01
    z[1,2,3]  R580      1.3461527228355408e-01
    z[1,2,3]  R581      -3.0403189361095428e-02
    z[1,2,3]  R582      -3.1890103220939636e-01
    z[1,2,3]  R583      3.0515128374099731e-01
    z[1,2,3]  R584      -2.7336540818214417e-01
    z[1,2,3]  R585      -2.2930863499641418e-01
    z[1,2,3]  R586      -6.9702661037445068e-01
    z[1,2,3]  R587      3.9165702462196350e-01
    z[1,2,3]  R588      9.0290986001491547e-02
    z[1,2,3]  R589      1.1057351529598236e-01
    z[1,2,3]  R590      -6.4202737808227539e-01
    z[1,2,3]  R591      -2.9270380735397339e-01
    z[1,2,3]  R592      -4.7821402549743652e-01
    z[1,2,3]  R593      5.7964488863945007e-02
    z[1,2,3]  R594      -0.312037855386734
    z[1,2,3]  R595      2.0122438669204712e-01
    z[1,2,3]  R596      -1.0564703494310379e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R511      -1
    z[1,2,4]  R512      1
    z[1,2,4]  R517      -2.0377385616302490e-01
    z[1,2,4]  R518      -1.9554647803306580e-01
    z[1,2,4]  R519      -7.1302741765975952e-02
    z[1,2,4]  R520      -7.4175751209259033e-01
    z[1,2,4]  R521      -1.1411214619874954e-01
    z[1,2,4]  R522      -0.0604756623506546
    z[1,2,4]  R523      0.00889661442488432
    z[1,2,4]  R524      -7.1751803159713745e-01
    z[1,2,4]  R525      -1.9821767508983612e-01
    z[1,2,4]  R526      -7.7603662014007568e-01
    z[1,2,4]  R527      4.3331223726272583e-01
    z[1,2,4]  R528      3.2113659381866455e-01
    z[1,2,4]  R529      5.2670681476593018e-01
    z[1,2,4]  R530      -1.4285834133625031e-01
    z[1,2,4]  R531      -3.8055914640426636e-01
    z[1,2,4]  R532      3.7265902757644653e-01
    z[1,2,4]  R533      3.3615803718566895e-01
    z[1,2,4]  R534      -0.0842844620347023
    z[1,2,4]  R535      5.2886521816253662e-01
    z[1,2,4]  R536      -5.4532349109649658e-01
    z[1,2,4]  R537      3.8011528551578522e-02
    z[1,2,4]  R538      5.9980505704879761e-01
    z[1,2,4]  R539      -3.1217586994171143e-01
    z[1,2,4]  R540      -1.8894271552562714e-01
    z[1,2,4]  R541      7.1065044403076172e-01
    z[1,2,4]  R542      -1.7832717299461365e-01
    z[1,2,4]  R543      2.9451239109039307e-01
    z[1,2,4]  R544      2.1173436939716339e-01
    z[1,2,4]  R545      2.8134658932685852e-01
    z[1,2,4]  R546      2.1854051947593689e-01
    z[1,2,4]  R547      -1.1373429745435715e-01
    z[1,2,4]  R548      8.2437492907047272e-02
    z[1,2,4]  R549      -2.3470453917980194e-01
    z[1,2,4]  R550      -1.1266208440065384e-01
    z[1,2,4]  R551      -2.7110788226127625e-01
    z[1,2,4]  R552      -3.5360220074653625e-01
    z[1,2,4]  R553      -3.2983240485191345e-01
    z[1,2,4]  R554      -9.7517386078834534e-02
    z[1,2,4]  R555      -8.8615730404853821e-02
    z[1,2,4]  R556      1.9421349465847015e-01
    z[1,2,4]  R557      0.525259792804718
    z[1,2,4]  R558      4.0166336297988892e-01
    z[1,2,4]  R559      7.6657354831695557e-01
    z[1,2,4]  R560      5.4183059930801392e-01
    z[1,2,4]  R561      -1.5221124887466431e-01
    z[1,2,4]  R562      -4.2753493785858154e-01
    z[1,2,4]  R563      2.6012265682220459e-01
    z[1,2,4]  R564      -1.6520659625530243e-01
    z[1,2,4]  R565      -4.2838916182518005e-02
    z[1,2,4]  R566      7.7875934541225433e-02
    z[1,2,4]  R567      1.7025533318519592e-01
    z[1,2,4]  R568      -2.5707101821899414e-01
    z[1,2,4]  R569      1.9409327208995819e-01
    z[1,2,4]  R570      -4.1895397007465363e-02
    z[1,2,4]  R571      6.2116956710815430e-01
    z[1,2,4]  R572      2.3017503321170807e-01
    z[1,2,4]  R573      4.8447516560554504e-01
    z[1,2,4]  R574      2.1125909686088562e-01
    z[1,2,4]  R575      -1.2951073586009443e-04
    z[1,2,4]  R576      1.1897636950016022e-01
    z[1,2,4]  R577      -2.8945109248161316e-01
    z[1,2,4]  R578      -1.0832422971725464e-01
    z[1,2,4]  R579      2.0887608826160431e-01
    z[1,2,4]  R580      8.3890803158283234e-02
    z[1,2,4]  R581      3.4508371353149414e-01
    z[1,2,4]  R582      1.8232037127017975e-01
    z[1,2,4]  R583      -1.4317064546048641e-02
    z[1,2,4]  R584      -1.6430977731943130e-02
    z[1,2,4]  R585      -2.9563827440142632e-02
    z[1,2,4]  R586      1.5581177175045013e-01
    z[1,2,4]  R587      4.5532783865928650e-01
    z[1,2,4]  R588      -5.0584875047206879e-02
    z[1,2,4]  R589      1.6250425577163696e-01
    z[1,2,4]  R590      -7.6470471918582916e-02
    z[1,2,4]  R591      2.8865805268287659e-01
    z[1,2,4]  R592      1.6766466200351715e-01
    z[1,2,4]  R593      4.0400851517915726e-02
    z[1,2,4]  R594      -1.3726890087127686e-01
    z[1,2,4]  R595      -1.5371577441692352e-01
    z[1,2,4]  R596      2.8815966844558716e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R513      -1
    z[1,2,5]  R514      1
    z[1,2,5]  R517      -5.3726172447204590e-01
    z[1,2,5]  R518      -0.626187801361084
    z[1,2,5]  R519      -1.6882559657096863e-01
    z[1,2,5]  R520      -3.3339250087738037e-01
    z[1,2,5]  R521      3.3609855920076370e-02
    z[1,2,5]  R522      -1.6285820305347443e-01
    z[1,2,5]  R523      2.5512970983982086e-02
    z[1,2,5]  R524      1.5018879203125834e-03
    z[1,2,5]  R525      -2.9831105470657349e-01
    z[1,2,5]  R526      1.9834114611148834e-01
    z[1,2,5]  R527      3.3949002623558044e-01
    z[1,2,5]  R528      -1.5337635576725006e-01
    z[1,2,5]  R529      -2.4938280880451202e-01
    z[1,2,5]  R530      5.6400257349014282e-01
    z[1,2,5]  R531      4.6394929289817810e-01
    z[1,2,5]  R532      4.4545814394950867e-01
    z[1,2,5]  R533      4.8621088266372681e-01
    z[1,2,5]  R534      -6.7275539040565491e-02
    z[1,2,5]  R535      5.4848223924636841e-01
    z[1,2,5]  R536      -4.6977987512946129e-03
    z[1,2,5]  R537      -4.5693108439445496e-01
    z[1,2,5]  R538      -4.5982575416564941e-01
    z[1,2,5]  R539      4.6194070577621460e-01
    z[1,2,5]  R540      5.6908661127090454e-01
    z[1,2,5]  R541      -4.7468963265419006e-01
    z[1,2,5]  R542      1.0996001958847046e-01
    z[1,2,5]  R543      3.1893891096115112e-01
    z[1,2,5]  R544      3.3318656682968140e-01
    z[1,2,5]  R545      1.6710844635963440e-01
    z[1,2,5]  R546      6.1378264427185059e-01
    z[1,2,5]  R547      -5.6261110305786133e-01
    z[1,2,5]  R548      -4.5188632607460022e-01
    z[1,2,5]  R549      4.7491684556007385e-02
    z[1,2,5]  R550      1.0402470082044601e-01
    z[1,2,5]  R551      -6.2023870646953583e-02
    z[1,2,5]  R552      -1.0046847164630890e-02
    z[1,2,5]  R553      -2.1654093638062477e-02
    z[1,2,5]  R554      -3.4643489122390747e-01
    z[1,2,5]  R555      -3.7767979502677917e-01
    z[1,2,5]  R556      -1.7442518472671509e-01
    z[1,2,5]  R557      3.4574168920516968e-01
    z[1,2,5]  R558      -5.5439078807830811e-01
    z[1,2,5]  R559      -2.3657123744487762e-01
    z[1,2,5]  R560      2.0953471958637238e-01
    z[1,2,5]  R561      0.50971519947052
    z[1,2,5]  R562      2.0126949250698090e-01
    z[1,2,5]  R563      -8.6231883615255356e-03
    z[1,2,5]  R564      6.8229717016220093e-01
    z[1,2,5]  R565      4.6939301490783691e-01
    z[1,2,5]  R566      4.2282477021217346e-01
    z[1,2,5]  R567      6.1182837933301926e-02
    z[1,2,5]  R568      -1.1985354125499725e-01
    z[1,2,5]  R569      8.6183302104473114e-02
    z[1,2,5]  R570      2.4325927719473839e-02
    z[1,2,5]  R571      1.0157548636198044e-01
    z[1,2,5]  R572      4.8351404070854187e-01
    z[1,2,5]  R573      8.5496142506599426e-02
    z[1,2,5]  R574      4.2921945452690125e-01
    z[1,2,5]  R575      -1.6942197084426880e-01
    z[1,2,5]  R576      2.2209188342094421e-01
    z[1,2,5]  R577      -1.5760114416480064e-02
    z[1,2,5]  R578      0.0844428762793541
    z[1,2,5]  R579      2.1522009372711182e-01
    z[1,2,5]  R580      -5.1006329059600830e-01
    z[1,2,5]  R581      -2.1311371028423309e-01
    z[1,2,5]  R582      1.6942206025123596e-01
    z[1,2,5]  R583      -3.9063182473182678e-01
    z[1,2,5]  R584      2.0191356539726257e-01
    z[1,2,5]  R585      2.2902959585189819e-01
    z[1,2,5]  R586      -5.8947563171386719e-02
    z[1,2,5]  R587      -4.1749498248100281e-01
    z[1,2,5]  R588      -3.7870484590530396e-01
    z[1,2,5]  R589      -0.415229469537735
    z[1,2,5]  R590      -0.0883241817355156
    z[1,2,5]  R591      4.2321172356605530e-01
    z[1,2,5]  R592      1.6260632872581482e-01
    z[1,2,5]  R593      0.0569465234875679
    z[1,2,5]  R594      -1.6966991126537323e-01
    z[1,2,5]  R595      -3.0250322818756104e-01
    z[1,2,5]  R596      3.7471261620521545e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R515      -1
    z[1,2,6]  R516      1
    z[1,2,6]  R517      -3.3465293049812317e-01
    z[1,2,6]  R518      -1.2145908921957016e-01
    z[1,2,6]  R519      -1.0455239564180374e-01
    z[1,2,6]  R520      1.8991325795650482e-01
    z[1,2,6]  R521      -2.7531927824020386e-01
    z[1,2,6]  R522      1.2007252871990204e-01
    z[1,2,6]  R523      1.3806284964084625e-01
    z[1,2,6]  R524      -1.4318844676017761e-01
    z[1,2,6]  R525      1.7317837476730347e-01
    z[1,2,6]  R526      -1.6367603838443756e-01
    z[1,2,6]  R527      -5.3965445607900620e-02
    z[1,2,6]  R528      6.6160291433334351e-01
    z[1,2,6]  R529      7.7898889780044556e-01
    z[1,2,6]  R530      2.2799883782863617e-01
    z[1,2,6]  R531      -4.8196563124656677e-01
    z[1,2,6]  R532      -4.0603697299957275e-01
    z[1,2,6]  R533      9.4417795538902283e-02
    z[1,2,6]  R534      -5.2158057689666748e-01
    z[1,2,6]  R535      4.4169902801513672e-01
    z[1,2,6]  R536      -2.6157552003860474e-01
    z[1,2,6]  R537      7.1805804967880249e-01
    z[1,2,6]  R538      -5.7507455348968506e-01
    z[1,2,6]  R539      3.8336464762687683e-01
    z[1,2,6]  R540      -1.7829042673110962e-01
    z[1,2,6]  R541      -8.7246164679527283e-02
    z[1,2,6]  R542      4.4387900829315186e-01
    z[1,2,6]  R543      2.8109195828437805e-01
    z[1,2,6]  R544      -3.9085072278976440e-01
    z[1,2,6]  R545      -6.4286071062088013e-01
    z[1,2,6]  R546      -1.3372294604778290e-01
    z[1,2,6]  R547      -2.4012371897697449e-01
    z[1,2,6]  R548      -4.7786796092987061e-01
    z[1,2,6]  R549      -3.2327172160148621e-01
    z[1,2,6]  R550      0.266877144575119
    z[1,2,6]  R551      -5.2893865853548050e-02
    z[1,2,6]  R552      -9.8525643348693848e-02
    z[1,2,6]  R553      3.1339146196842194e-02
    z[1,2,6]  R554      1.8047126010060310e-02
    z[1,2,6]  R555      -2.8784683346748352e-01
    z[1,2,6]  R556      2.2689154744148254e-01
    z[1,2,6]  R557      -2.5508137419819832e-02
    z[1,2,6]  R558      5.3439790010452271e-01
    z[1,2,6]  R559      -1.0268667340278625e-01
    z[1,2,6]  R560      -3.8092023134231567e-01
    z[1,2,6]  R561      0.0318525955080986
    z[1,2,6]  R562      -1.4917287230491638e-01
    z[1,2,6]  R563      7.3223048448562622e-01
    z[1,2,6]  R564      -1.7481561005115509e-01
    z[1,2,6]  R565      6.6362321376800537e-01
    z[1,2,6]  R566      2.5549495220184326e-01
    z[1,2,6]  R567      -1.6688092052936554e-01
    z[1,2,6]  R568      -4.5651599764823914e-02
    z[1,2,6]  R569      2.2808927297592163e-01
    z[1,2,6]  R570      -1.2586400844156742e-02
    z[1,2,6]  R571      3.8680014014244080e-01
    z[1,2,6]  R572      -2.9306897521018982e-01
    z[1,2,6]  R573      -1.7781928181648254e-01
    z[1,2,6]  R574      0.344841331243515
    z[1,2,6]  R575      -1.3751790858805180e-02
    z[1,2,6]  R576      -0.413039892911911
    z[1,2,6]  R577      3.5972705483436584e-01
    z[1,2,6]  R578      -3.1692448258399963e-01
    z[1,2,6]  R579      4.4062426686286926e-01
    z[1,2,6]  R580      1.4996452629566193e-01
    z[1,2,6]  R581      1.2894116342067719e-01
    z[1,2,6]  R582      3.3351856470108032e-01
    z[1,2,6]  R583      -1.2531548738479614e-02
    z[1,2,6]  R584      -3.5553896427154541e-01
    z[1,2,6]  R585      1.3812610507011414e-01
    z[1,2,6]  R586      1.3690458238124847e-01
    z[1,2,6]  R587      -3.0597314238548279e-01
    z[1,2,6]  R588      -1.6123616695404053e-01
    z[1,2,6]  R589      1.7207552492618561e-01
    z[1,2,6]  R590      5.1867133378982544e-01
    z[1,2,6]  R591      4.6384155750274658e-01
    z[1,2,6]  R592      2.1356520056724548e-01
    z[1,2,6]  R593      4.2806592583656311e-01
    z[1,2,6]  R594      1.4733320474624634e-01
    z[1,2,6]  R595      -3.1754586845636368e-02
    z[1,2,6]  R596      2.4821478128433228e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R597      -1
    z[2,1,0]  R598      1
    z[2,1,0]  R611      -3.7761595845222473e-01
    z[2,1,0]  R612      -2.6884365081787109e-01
    z[2,1,0]  R613      7.9843342304229736e-01
    z[2,1,0]  R614      8.7542468309402466e-01
    z[2,1,0]  R615      8.4131413698196411e-01
    z[2,1,0]  R616      0.419920414686203
    z[2,1,0]  R617      0.285171240568161
    z[2,1,0]  R618      3.6918950080871582e-01
    z[2,1,0]  R619      6.9000291824340820e-01
    z[2,1,0]  R620      6.2999832630157471e-01
    z[2,1,0]  R621      -3.1384840607643127e-01
    z[2,1,0]  R622      -2.1706500649452209e-01
    z[2,1,0]  R623      1.7495959997177124e-01
    z[2,1,0]  R624      3.1879001855850220e-01
    z[2,1,0]  R625      2.0410983264446259e-01
    z[2,1,0]  R626      0.538845419883728
    z[2,1,0]  R627      4.7156815417110920e-03
    z[2,1,0]  R628      5.1173609495162964e-01
    z[2,1,0]  R629      3.5414862632751465e-01
    z[2,1,0]  R630      1.5112403035163879e-01
    z[2,1,0]  R631      3.5378584265708923e-01
    z[2,1,0]  R632      -7.7039031311869621e-03
    z[2,1,0]  R633      5.1625329256057739e-01
    z[2,1,0]  R634      5.4666346311569214e-01
    z[2,1,0]  R635      -2.4800196290016174e-01
    z[2,1,0]  R636      4.0988841652870178e-01
    z[2,1,0]  R637      3.5897067189216614e-01
    z[2,1,0]  R638      6.8418520689010620e-01
    z[2,1,0]  R639      5.2593183517456055e-01
    z[2,1,0]  R640      3.0959594249725342e-01
    z[2,1,0]  R641      -3.0739870667457581e-01
    z[2,1,0]  R642      -5.9899266809225082e-02
    z[2,1,0]  R643      5.0955039262771606e-01
    z[2,1,0]  R644      6.1493802070617676e-01
    z[2,1,0]  R645      0.53638756275177
    z[2,1,0]  R646      6.5523380041122437e-01
    z[2,1,0]  R647      2.7248516678810120e-01
    z[2,1,0]  R648      3.8072407245635986e-01
    z[2,1,0]  R649      8.6608707904815674e-01
    z[2,1,0]  R650      5.1091867685317993e-01
    z[2,1,0]  R651      -4.8466438055038452e-01
    z[2,1,0]  R652      -2.2906814515590668e-01
    z[2,1,0]  R653      -1.3635233044624329e-02
    z[2,1,0]  R654      9.6427626907825470e-02
    z[2,1,0]  R655      4.2372739315032959e-01
    z[2,1,0]  R656      5.4470956325531006e-01
    z[2,1,0]  R657      6.6702020168304443e-01
    z[2,1,0]  R658      5.1377475261688232e-02
    z[2,1,0]  R659      7.0297127962112427e-01
    z[2,1,0]  R660      7.1857148408889771e-01
    z[2,1,0]  R661      6.1083510518074036e-02
    z[2,1,0]  R662      2.1380166709423065e-01
    z[2,1,0]  R663      -7.3983520269393921e-01
    z[2,1,0]  R664      2.5135216116905212e-01
    z[2,1,0]  R665      8.9019227027893066e-01
    z[2,1,0]  R666      8.5609972476959229e-01
    z[2,1,0]  R667      -4.3352678418159485e-02
    z[2,1,0]  R668      -2.3973140120506287e-01
    z[2,1,0]  R669      3.1451526284217834e-01
    z[2,1,0]  R670      5.4635588079690933e-02
    z[2,1,0]  R671      3.8354450464248657e-01
    z[2,1,0]  R672      3.0896863341331482e-01
    z[2,1,0]  R673      7.9854726791381836e-02
    z[2,1,0]  R674      -2.5239627808332443e-02
    z[2,1,0]  R675      2.7237203717231750e-01
    z[2,1,0]  R676      -3.5902258753776550e-01
    z[2,1,0]  R677      -2.9740709066390991e-01
    z[2,1,0]  R678      -4.5330911874771118e-02
    z[2,1,0]  R679      -3.8903504610061646e-01
    z[2,1,0]  R680      -1.7127676308155060e-01
    z[2,1,0]  R681      6.3217975199222565e-02
    z[2,1,0]  R682      -1.8302571773529053e-01
    z[2,1,0]  R683      -4.7933542728424072e-01
    z[2,1,0]  R684      3.4628391265869141e-01
    z[2,1,0]  R685      2.0839316770434380e-02
    z[2,1,0]  R686      1.1791638284921646e-01
    z[2,1,0]  R687      -5.6895387172698975e-01
    z[2,1,0]  R688      1.9080510735511780e-01
    z[2,1,0]  R689      -2.1374617516994476e-01
    z[2,1,0]  R690      -0.562109112739563
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R599      -1
    z[2,1,1]  R600      1
    z[2,1,1]  R611      3.8441542536020279e-02
    z[2,1,1]  R612      8.1759430468082428e-02
    z[2,1,1]  R613      -4.0119934082031250e-01
    z[2,1,1]  R614      -2.3960407078266144e-01
    z[2,1,1]  R615      -3.0244883894920349e-01
    z[2,1,1]  R616      -0.802794873714447
    z[2,1,1]  R617      -8.8745057582855225e-01
    z[2,1,1]  R618      -0.754834771156311
    z[2,1,1]  R619      -3.9399498701095581e-01
    z[2,1,1]  R620      8.5442259907722473e-02
    z[2,1,1]  R621      5.6618911027908325e-01
    z[2,1,1]  R622      2.3656965792179108e-01
    z[2,1,1]  R623      5.4735934734344482e-01
    z[2,1,1]  R624      4.4414228200912476e-01
    z[2,1,1]  R625      6.6778522729873657e-01
    z[2,1,1]  R626      6.4470344781875610e-01
    z[2,1,1]  R627      4.5176360011100769e-01
    z[2,1,1]  R628      3.9058855175971985e-01
    z[2,1,1]  R629      4.3951633572578430e-01
    z[2,1,1]  R630      6.5985703468322754e-01
    z[2,1,1]  R631      2.5097227096557617e-01
    z[2,1,1]  R632      0.688449501991272
    z[2,1,1]  R633      4.6634155511856079e-01
    z[2,1,1]  R634      -6.1167693138122559e-01
    z[2,1,1]  R635      -5.3506873548030853e-02
    z[2,1,1]  R636      -6.4141339063644409e-01
    z[2,1,1]  R637      -7.2092831134796143e-01
    z[2,1,1]  R638      -3.9164590835571289e-01
    z[2,1,1]  R639      -6.4713460206985474e-01
    z[2,1,1]  R640      -6.1470401287078857e-01
    z[2,1,1]  R641      8.1374222040176392e-01
    z[2,1,1]  R642      8.5356724262237549e-01
    z[2,1,1]  R643      -6.6358691453933716e-01
    z[2,1,1]  R644      -5.5984467267990112e-01
    z[2,1,1]  R645      -6.9038879871368408e-01
    z[2,1,1]  R646      -4.7251582145690918e-01
    z[2,1,1]  R647      -7.4744731187820435e-01
    z[2,1,1]  R648      -6.1545717716217041e-01
    z[2,1,1]  R649      -3.5275623202323914e-01
    z[2,1,1]  R650      -4.5408290624618530e-01
    z[2,1,1]  R651      -3.5253381729125977e-01
    z[2,1,1]  R652      8.0153006315231323e-01
    z[2,1,1]  R653      8.7071365118026733e-01
    z[2,1,1]  R654      5.4113519191741943e-01
    z[2,1,1]  R655      5.0517255067825317e-01
    z[2,1,1]  R656      0.586051881313324
    z[2,1,1]  R657      5.4306948184967041e-01
    z[2,1,1]  R658      8.1572657823562622e-01
    z[2,1,1]  R659      -3.9696505665779114e-01
    z[2,1,1]  R660      -2.6708725094795227e-01
    z[2,1,1]  R661      5.9199923276901245e-01
    z[2,1,1]  R662      -1.7263798415660858e-01
    z[2,1,1]  R663      6.1789894104003906e-01
    z[2,1,1]  R664      2.8438141942024231e-01
    z[2,1,1]  R665      -3.3239364624023438e-01
    z[2,1,1]  R666      -2.8496605157852173e-01
    z[2,1,1]  R667      3.6099424958229065e-01
    z[2,1,1]  R668      0.552646815776825
    z[2,1,1]  R669      -8.3604240417480469e-01
    z[2,1,1]  R670      4.0312197804450989e-01
    z[2,1,1]  R671      7.0076704025268555e-01
    z[2,1,1]  R672      5.3063219785690308e-01
    z[2,1,1]  R673      -1.3068813085556030e-01
    z[2,1,1]  R674      -7.0500189065933228e-01
    z[2,1,1]  R675      -0.484901487827301
    z[2,1,1]  R676      -7.5998403131961823e-02
    z[2,1,1]  R677      5.8496486395597458e-02
    z[2,1,1]  R678      -7.3956793546676636e-01
    z[2,1,1]  R679      -1.9420027732849121e-02
    z[2,1,1]  R680      -6.9828546047210693e-01
    z[2,1,1]  R681      4.2234563827514648e-01
    z[2,1,1]  R682      -2.5246351957321167e-01
    z[2,1,1]  R683      2.1436658501625061e-01
    z[2,1,1]  R684      -3.4335559606552124e-01
    z[2,1,1]  R685      4.6609568595886230e-01
    z[2,1,1]  R686      -5.4194486141204834e-01
    z[2,1,1]  R687      4.5076854526996613e-02
    z[2,1,1]  R688      -4.0479990839958191e-01
    z[2,1,1]  R689      7.3992349207401276e-02
    z[2,1,1]  R690      -5.0194181501865387e-02
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R601      -1
    z[2,1,2]  R602      1
    z[2,1,2]  R611      7.4965290725231171e-02
    z[2,1,2]  R612      0.681813657283783
    z[2,1,2]  R613      1.4072988927364349e-01
    z[2,1,2]  R614      1.7492705583572388e-01
    z[2,1,2]  R615      1.3756878674030304e-02
    z[2,1,2]  R616      -1.7958280444145203e-01
    z[2,1,2]  R617      -3.4977486357092857e-03
    z[2,1,2]  R618      1.0772727429866791e-01
    z[2,1,2]  R619      3.0122503638267517e-01
    z[2,1,2]  R620      5.3374260663986206e-01
    z[2,1,2]  R621      3.3036175370216370e-01
    z[2,1,2]  R622      -1.0271928459405899e-01
    z[2,1,2]  R623      3.5235092509537935e-03
    z[2,1,2]  R624      -1.6434369981288910e-01
    z[2,1,2]  R625      -3.0935943126678467e-01
    z[2,1,2]  R626      2.0727092027664185e-01
    z[2,1,2]  R627      -3.2779264450073242e-01
    z[2,1,2]  R628      2.4899050593376160e-01
    z[2,1,2]  R629      -9.0174794197082520e-02
    z[2,1,2]  R630      -1.8114100396633148e-01
    z[2,1,2]  R631      7.9812347888946533e-01
    z[2,1,2]  R632      6.2663513422012329e-01
    z[2,1,2]  R633      4.0392029285430908e-01
    z[2,1,2]  R634      -7.3203317821025848e-02
    z[2,1,2]  R635      2.7970877289772034e-01
    z[2,1,2]  R636      1.5855786204338074e-01
    z[2,1,2]  R637      2.7109023928642273e-01
    z[2,1,2]  R638      -1.7429442703723907e-01
    z[2,1,2]  R639      -5.2469903230667114e-01
    z[2,1,2]  R640      2.7236273884773254e-01
    z[2,1,2]  R641      -1.1220594495534897e-01
    z[2,1,2]  R642      -3.8480564951896667e-01
    z[2,1,2]  R643      2.0183211192488670e-02
    z[2,1,2]  R644      2.4744583293795586e-02
    z[2,1,2]  R645      -2.3151947557926178e-01
    z[2,1,2]  R646      -2.6929610967636108e-01
    z[2,1,2]  R647      3.4785324335098267e-01
    z[2,1,2]  R648      4.8382428288459778e-01
    z[2,1,2]  R649      2.1594485267996788e-02
    z[2,1,2]  R650      -2.0730255171656609e-02
    z[2,1,2]  R651      1.1036302149295807e-01
    z[2,1,2]  R652      3.5348507761955261e-01
    z[2,1,2]  R653      0.0318136028945446
    z[2,1,2]  R654      5.4831538349390030e-02
    z[2,1,2]  R655      4.4717624783515930e-02
    z[2,1,2]  R656      -1.7602179944515228e-01
    z[2,1,2]  R657      2.6207652688026428e-01
    z[2,1,2]  R658      -4.0650373697280884e-01
    z[2,1,2]  R659      4.3773704767227173e-01
    z[2,1,2]  R660      3.4073731303215027e-01
    z[2,1,2]  R661      -2.7311458252370358e-03
    z[2,1,2]  R662      -4.7505609691143036e-02
    z[2,1,2]  R663      -1.6115337610244751e-01
    z[2,1,2]  R664      -1.4312425628304482e-02
    z[2,1,2]  R665      -7.1665213909000158e-05
    z[2,1,2]  R666      1.2088888138532639e-01
    z[2,1,2]  R667      -4.1242414154112339e-03
    z[2,1,2]  R668      -2.9520472511649132e-02
    z[2,1,2]  R669      -1.7982059717178345e-01
    z[2,1,2]  R670      8.2160130143165588e-02
    z[2,1,2]  R671      1.3549405336380005e-01
    z[2,1,2]  R672      -6.9270215928554535e-02
    z[2,1,2]  R673      -1.4978380501270294e-01
    z[2,1,2]  R674      5.1258418709039688e-02
    z[2,1,2]  R675      2.1003323793411255e-01
    z[2,1,2]  R676      1.7651681602001190e-01
    z[2,1,2]  R677      1.1088189668953419e-02
    z[2,1,2]  R678      7.0806264877319336e-02
    z[2,1,2]  R679      0.0782213807106018
    z[2,1,2]  R680      1.3924143277108669e-02
    z[2,1,2]  R681      -1.6303548216819763e-01
    z[2,1,2]  R682      -2.1536026149988174e-02
    z[2,1,2]  R683      -0.0760052353143692
    z[2,1,2]  R684      2.0098702609539032e-01
    z[2,1,2]  R685      -6.1345055699348450e-02
    z[2,1,2]  R686      -1.3458553701639175e-02
    z[2,1,2]  R687      3.7188690900802612e-01
    z[2,1,2]  R688      1.6649918258190155e-01
    z[2,1,2]  R689      6.5833173692226410e-02
    z[2,1,2]  R690      4.1337138414382935e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R603      -1
    z[2,1,3]  R604      1
    z[2,1,3]  R611      -6.8057513236999512e-01
    z[2,1,3]  R612      1.2966774404048920e-01
    z[2,1,3]  R613      1.4103873074054718e-01
    z[2,1,3]  R614      2.2557689249515533e-01
    z[2,1,3]  R615      3.4696063399314880e-01
    z[2,1,3]  R616      1.0997498035430908e-01
    z[2,1,3]  R617      -1.4441721141338348e-01
    z[2,1,3]  R618      -3.9046889543533325e-01
    z[2,1,3]  R619      2.1113230288028717e-01
    z[2,1,3]  R620      -4.3737614154815674e-01
    z[2,1,3]  R621      -0.275144100189209
    z[2,1,3]  R622      3.6345925927162170e-01
    z[2,1,3]  R623      -1.2501551210880280e-01
    z[2,1,3]  R624      -4.3762576580047607e-01
    z[2,1,3]  R625      -3.6428907513618469e-01
    z[2,1,3]  R626      7.4119992554187775e-02
    z[2,1,3]  R627      -2.9075714945793152e-01
    z[2,1,3]  R628      -1.3685405254364014e-02
    z[2,1,3]  R629      -1.0349833220243454e-01
    z[2,1,3]  R630      5.0873857736587524e-01
    z[2,1,3]  R631      -3.3803546428680420e-01
    z[2,1,3]  R632      2.2532603144645691e-01
    z[2,1,3]  R633      5.0569951534271240e-01
    z[2,1,3]  R634      5.6493043899536133e-01
    z[2,1,3]  R635      -5.5822163820266724e-01
    z[2,1,3]  R636      1.5094357728958130e-01
    z[2,1,3]  R637      -6.5323412418365479e-02
    z[2,1,3]  R638      1.8714305013418198e-02
    z[2,1,3]  R639      2.0260209217667580e-02
    z[2,1,3]  R640      -4.6693214774131775e-01
    z[2,1,3]  R641      1.3155084848403931e-01
    z[2,1,3]  R642      0.0213027261197567
    z[2,1,3]  R643      -1.2451861053705215e-01
    z[2,1,3]  R644      1.3461527228355408e-01
    z[2,1,3]  R645      -3.0403189361095428e-02
    z[2,1,3]  R646      -3.1890103220939636e-01
    z[2,1,3]  R647      3.0515128374099731e-01
    z[2,1,3]  R648      -2.7336540818214417e-01
    z[2,1,3]  R649      -2.2930863499641418e-01
    z[2,1,3]  R650      -6.9702661037445068e-01
    z[2,1,3]  R651      3.9165702462196350e-01
    z[2,1,3]  R652      9.0290986001491547e-02
    z[2,1,3]  R653      1.1057351529598236e-01
    z[2,1,3]  R654      -6.4202737808227539e-01
    z[2,1,3]  R655      -2.9270380735397339e-01
    z[2,1,3]  R656      -4.7821402549743652e-01
    z[2,1,3]  R657      5.7964488863945007e-02
    z[2,1,3]  R658      -0.312037855386734
    z[2,1,3]  R659      2.0122438669204712e-01
    z[2,1,3]  R660      -1.0564703494310379e-01
    z[2,1,3]  R661      4.5125576853752136e-01
    z[2,1,3]  R662      -6.9074326753616333e-01
    z[2,1,3]  R663      1.8896495923399925e-02
    z[2,1,3]  R664      0.397897869348526
    z[2,1,3]  R665      8.4381639957427979e-02
    z[2,1,3]  R666      3.5591584444046021e-01
    z[2,1,3]  R667      9.2086660861968994e-01
    z[2,1,3]  R668      -3.1765013933181763e-01
    z[2,1,3]  R669      1.0727182030677795e-01
    z[2,1,3]  R670      3.9924341440200806e-01
    z[2,1,3]  R671      -1.9374012947082520e-01
    z[2,1,3]  R672      -2.3194399476051331e-01
    z[2,1,3]  R673      -8.7596736848354340e-02
    z[2,1,3]  R674      3.3047983050346375e-01
    z[2,1,3]  R675      2.3281952738761902e-01
    z[2,1,3]  R676      -5.7619011402130127e-01
    z[2,1,3]  R677      -7.4140834808349609e-01
    z[2,1,3]  R678      4.0285822749137878e-01
    z[2,1,3]  R679      -2.5792804360389709e-01
    z[2,1,3]  R680      3.4212014079093933e-01
    z[2,1,3]  R681      2.5536033511161804e-01
    z[2,1,3]  R682      -1.9580744206905365e-02
    z[2,1,3]  R683      5.1058417558670044e-01
    z[2,1,3]  R684      5.7484978437423706e-01
    z[2,1,3]  R685      -2.0147246122360229e-01
    z[2,1,3]  R686      6.7178118228912354e-01
    z[2,1,3]  R687      -5.1815766096115112e-01
    z[2,1,3]  R688      6.8073445558547974e-01
    z[2,1,3]  R689      -6.5127015113830566e-01
    z[2,1,3]  R690      -2.6127964258193970e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R605      -1
    z[2,1,4]  R606      1
    z[2,1,4]  R611      -1.1373429745435715e-01
    z[2,1,4]  R612      8.2437492907047272e-02
    z[2,1,4]  R613      -2.3470453917980194e-01
    z[2,1,4]  R614      -1.1266208440065384e-01
    z[2,1,4]  R615      -2.7110788226127625e-01
    z[2,1,4]  R616      -3.5360220074653625e-01
    z[2,1,4]  R617      -3.2983240485191345e-01
    z[2,1,4]  R618      -9.7517386078834534e-02
    z[2,1,4]  R619      -8.8615730404853821e-02
    z[2,1,4]  R620      1.9421349465847015e-01
    z[2,1,4]  R621      0.525259792804718
    z[2,1,4]  R622      4.0166336297988892e-01
    z[2,1,4]  R623      7.6657354831695557e-01
    z[2,1,4]  R624      5.4183059930801392e-01
    z[2,1,4]  R625      -1.5221124887466431e-01
    z[2,1,4]  R626      -4.2753493785858154e-01
    z[2,1,4]  R627      2.6012265682220459e-01
    z[2,1,4]  R628      -1.6520659625530243e-01
    z[2,1,4]  R629      -4.2838916182518005e-02
    z[2,1,4]  R630      7.7875934541225433e-02
    z[2,1,4]  R631      1.7025533318519592e-01
    z[2,1,4]  R632      -2.5707101821899414e-01
    z[2,1,4]  R633      1.9409327208995819e-01
    z[2,1,4]  R634      -4.1895397007465363e-02
    z[2,1,4]  R635      6.2116956710815430e-01
    z[2,1,4]  R636      2.3017503321170807e-01
    z[2,1,4]  R637      4.8447516560554504e-01
    z[2,1,4]  R638      2.1125909686088562e-01
    z[2,1,4]  R639      -1.2951073586009443e-04
    z[2,1,4]  R640      1.1897636950016022e-01
    z[2,1,4]  R641      -2.8945109248161316e-01
    z[2,1,4]  R642      -1.0832422971725464e-01
    z[2,1,4]  R643      2.0887608826160431e-01
    z[2,1,4]  R644      8.3890803158283234e-02
    z[2,1,4]  R645      3.4508371353149414e-01
    z[2,1,4]  R646      1.8232037127017975e-01
    z[2,1,4]  R647      -1.4317064546048641e-02
    z[2,1,4]  R648      -1.6430977731943130e-02
    z[2,1,4]  R649      -2.9563827440142632e-02
    z[2,1,4]  R650      1.5581177175045013e-01
    z[2,1,4]  R651      4.5532783865928650e-01
    z[2,1,4]  R652      -5.0584875047206879e-02
    z[2,1,4]  R653      1.6250425577163696e-01
    z[2,1,4]  R654      -7.6470471918582916e-02
    z[2,1,4]  R655      2.8865805268287659e-01
    z[2,1,4]  R656      1.6766466200351715e-01
    z[2,1,4]  R657      4.0400851517915726e-02
    z[2,1,4]  R658      -1.3726890087127686e-01
    z[2,1,4]  R659      -1.5371577441692352e-01
    z[2,1,4]  R660      2.8815966844558716e-01
    z[2,1,4]  R661      -2.0377385616302490e-01
    z[2,1,4]  R662      -1.9554647803306580e-01
    z[2,1,4]  R663      -7.1302741765975952e-02
    z[2,1,4]  R664      -7.4175751209259033e-01
    z[2,1,4]  R665      -1.1411214619874954e-01
    z[2,1,4]  R666      -0.0604756623506546
    z[2,1,4]  R667      0.00889661442488432
    z[2,1,4]  R668      -7.1751803159713745e-01
    z[2,1,4]  R669      -1.9821767508983612e-01
    z[2,1,4]  R670      -7.7603662014007568e-01
    z[2,1,4]  R671      4.3331223726272583e-01
    z[2,1,4]  R672      3.2113659381866455e-01
    z[2,1,4]  R673      5.2670681476593018e-01
    z[2,1,4]  R674      -1.4285834133625031e-01
    z[2,1,4]  R675      -3.8055914640426636e-01
    z[2,1,4]  R676      3.7265902757644653e-01
    z[2,1,4]  R677      3.3615803718566895e-01
    z[2,1,4]  R678      -0.0842844620347023
    z[2,1,4]  R679      5.2886521816253662e-01
    z[2,1,4]  R680      -5.4532349109649658e-01
    z[2,1,4]  R681      3.8011528551578522e-02
    z[2,1,4]  R682      5.9980505704879761e-01
    z[2,1,4]  R683      -3.1217586994171143e-01
    z[2,1,4]  R684      -1.8894271552562714e-01
    z[2,1,4]  R685      7.1065044403076172e-01
    z[2,1,4]  R686      -1.7832717299461365e-01
    z[2,1,4]  R687      2.9451239109039307e-01
    z[2,1,4]  R688      2.1173436939716339e-01
    z[2,1,4]  R689      2.8134658932685852e-01
    z[2,1,4]  R690      2.1854051947593689e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R607      -1
    z[2,1,5]  R608      1
    z[2,1,5]  R611      -5.6261110305786133e-01
    z[2,1,5]  R612      -4.5188632607460022e-01
    z[2,1,5]  R613      4.7491684556007385e-02
    z[2,1,5]  R614      1.0402470082044601e-01
    z[2,1,5]  R615      -6.2023870646953583e-02
    z[2,1,5]  R616      -1.0046847164630890e-02
    z[2,1,5]  R617      -2.1654093638062477e-02
    z[2,1,5]  R618      -3.4643489122390747e-01
    z[2,1,5]  R619      -3.7767979502677917e-01
    z[2,1,5]  R620      -1.7442518472671509e-01
    z[2,1,5]  R621      3.4574168920516968e-01
    z[2,1,5]  R622      -5.5439078807830811e-01
    z[2,1,5]  R623      -2.3657123744487762e-01
    z[2,1,5]  R624      2.0953471958637238e-01
    z[2,1,5]  R625      0.50971519947052
    z[2,1,5]  R626      2.0126949250698090e-01
    z[2,1,5]  R627      -8.6231883615255356e-03
    z[2,1,5]  R628      6.8229717016220093e-01
    z[2,1,5]  R629      4.6939301490783691e-01
    z[2,1,5]  R630      4.2282477021217346e-01
    z[2,1,5]  R631      6.1182837933301926e-02
    z[2,1,5]  R632      -1.1985354125499725e-01
    z[2,1,5]  R633      8.6183302104473114e-02
    z[2,1,5]  R634      2.4325927719473839e-02
    z[2,1,5]  R635      1.0157548636198044e-01
    z[2,1,5]  R636      4.8351404070854187e-01
    z[2,1,5]  R637      8.5496142506599426e-02
    z[2,1,5]  R638      4.2921945452690125e-01
    z[2,1,5]  R639      -1.6942197084426880e-01
    z[2,1,5]  R640      2.2209188342094421e-01
    z[2,1,5]  R641      -1.5760114416480064e-02
    z[2,1,5]  R642      0.0844428762793541
    z[2,1,5]  R643      2.1522009372711182e-01
    z[2,1,5]  R644      -5.1006329059600830e-01
    z[2,1,5]  R645      -2.1311371028423309e-01
    z[2,1,5]  R646      1.6942206025123596e-01
    z[2,1,5]  R647      -3.9063182473182678e-01
    z[2,1,5]  R648      2.0191356539726257e-01
    z[2,1,5]  R649      2.2902959585189819e-01
    z[2,1,5]  R650      -5.8947563171386719e-02
    z[2,1,5]  R651      -4.1749498248100281e-01
    z[2,1,5]  R652      -3.7870484590530396e-01
    z[2,1,5]  R653      -0.415229469537735
    z[2,1,5]  R654      -0.0883241817355156
    z[2,1,5]  R655      4.2321172356605530e-01
    z[2,1,5]  R656      1.6260632872581482e-01
    z[2,1,5]  R657      0.0569465234875679
    z[2,1,5]  R658      -1.6966991126537323e-01
    z[2,1,5]  R659      -3.0250322818756104e-01
    z[2,1,5]  R660      3.7471261620521545e-01
    z[2,1,5]  R661      -5.3726172447204590e-01
    z[2,1,5]  R662      -0.626187801361084
    z[2,1,5]  R663      -1.6882559657096863e-01
    z[2,1,5]  R664      -3.3339250087738037e-01
    z[2,1,5]  R665      3.3609855920076370e-02
    z[2,1,5]  R666      -1.6285820305347443e-01
    z[2,1,5]  R667      2.5512970983982086e-02
    z[2,1,5]  R668      1.5018879203125834e-03
    z[2,1,5]  R669      -2.9831105470657349e-01
    z[2,1,5]  R670      1.9834114611148834e-01
    z[2,1,5]  R671      3.3949002623558044e-01
    z[2,1,5]  R672      -1.5337635576725006e-01
    z[2,1,5]  R673      -2.4938280880451202e-01
    z[2,1,5]  R674      5.6400257349014282e-01
    z[2,1,5]  R675      4.6394929289817810e-01
    z[2,1,5]  R676      4.4545814394950867e-01
    z[2,1,5]  R677      4.8621088266372681e-01
    z[2,1,5]  R678      -6.7275539040565491e-02
    z[2,1,5]  R679      5.4848223924636841e-01
    z[2,1,5]  R680      -4.6977987512946129e-03
    z[2,1,5]  R681      -4.5693108439445496e-01
    z[2,1,5]  R682      -4.5982575416564941e-01
    z[2,1,5]  R683      4.6194070577621460e-01
    z[2,1,5]  R684      5.6908661127090454e-01
    z[2,1,5]  R685      -4.7468963265419006e-01
    z[2,1,5]  R686      1.0996001958847046e-01
    z[2,1,5]  R687      3.1893891096115112e-01
    z[2,1,5]  R688      3.3318656682968140e-01
    z[2,1,5]  R689      1.6710844635963440e-01
    z[2,1,5]  R690      6.1378264427185059e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R609      -1
    z[2,1,6]  R610      1
    z[2,1,6]  R611      -2.4012371897697449e-01
    z[2,1,6]  R612      -4.7786796092987061e-01
    z[2,1,6]  R613      -3.2327172160148621e-01
    z[2,1,6]  R614      0.266877144575119
    z[2,1,6]  R615      -5.2893865853548050e-02
    z[2,1,6]  R616      -9.8525643348693848e-02
    z[2,1,6]  R617      3.1339146196842194e-02
    z[2,1,6]  R618      1.8047126010060310e-02
    z[2,1,6]  R619      -2.8784683346748352e-01
    z[2,1,6]  R620      2.2689154744148254e-01
    z[2,1,6]  R621      -2.5508137419819832e-02
    z[2,1,6]  R622      5.3439790010452271e-01
    z[2,1,6]  R623      -1.0268667340278625e-01
    z[2,1,6]  R624      -3.8092023134231567e-01
    z[2,1,6]  R625      0.0318525955080986
    z[2,1,6]  R626      -1.4917287230491638e-01
    z[2,1,6]  R627      7.3223048448562622e-01
    z[2,1,6]  R628      -1.7481561005115509e-01
    z[2,1,6]  R629      6.6362321376800537e-01
    z[2,1,6]  R630      2.5549495220184326e-01
    z[2,1,6]  R631      -1.6688092052936554e-01
    z[2,1,6]  R632      -4.5651599764823914e-02
    z[2,1,6]  R633      2.2808927297592163e-01
    z[2,1,6]  R634      -1.2586400844156742e-02
    z[2,1,6]  R635      3.8680014014244080e-01
    z[2,1,6]  R636      -2.9306897521018982e-01
    z[2,1,6]  R637      -1.7781928181648254e-01
    z[2,1,6]  R638      0.344841331243515
    z[2,1,6]  R639      -1.3751790858805180e-02
    z[2,1,6]  R640      -0.413039892911911
    z[2,1,6]  R641      3.5972705483436584e-01
    z[2,1,6]  R642      -3.1692448258399963e-01
    z[2,1,6]  R643      4.4062426686286926e-01
    z[2,1,6]  R644      1.4996452629566193e-01
    z[2,1,6]  R645      1.2894116342067719e-01
    z[2,1,6]  R646      3.3351856470108032e-01
    z[2,1,6]  R647      -1.2531548738479614e-02
    z[2,1,6]  R648      -3.5553896427154541e-01
    z[2,1,6]  R649      1.3812610507011414e-01
    z[2,1,6]  R650      1.3690458238124847e-01
    z[2,1,6]  R651      -3.0597314238548279e-01
    z[2,1,6]  R652      -1.6123616695404053e-01
    z[2,1,6]  R653      1.7207552492618561e-01
    z[2,1,6]  R654      5.1867133378982544e-01
    z[2,1,6]  R655      4.6384155750274658e-01
    z[2,1,6]  R656      2.1356520056724548e-01
    z[2,1,6]  R657      4.2806592583656311e-01
    z[2,1,6]  R658      1.4733320474624634e-01
    z[2,1,6]  R659      -3.1754586845636368e-02
    z[2,1,6]  R660      2.4821478128433228e-01
    z[2,1,6]  R661      -3.3465293049812317e-01
    z[2,1,6]  R662      -1.2145908921957016e-01
    z[2,1,6]  R663      -1.0455239564180374e-01
    z[2,1,6]  R664      1.8991325795650482e-01
    z[2,1,6]  R665      -2.7531927824020386e-01
    z[2,1,6]  R666      1.2007252871990204e-01
    z[2,1,6]  R667      1.3806284964084625e-01
    z[2,1,6]  R668      -1.4318844676017761e-01
    z[2,1,6]  R669      1.7317837476730347e-01
    z[2,1,6]  R670      -1.6367603838443756e-01
    z[2,1,6]  R671      -5.3965445607900620e-02
    z[2,1,6]  R672      6.6160291433334351e-01
    z[2,1,6]  R673      7.7898889780044556e-01
    z[2,1,6]  R674      2.2799883782863617e-01
    z[2,1,6]  R675      -4.8196563124656677e-01
    z[2,1,6]  R676      -4.0603697299957275e-01
    z[2,1,6]  R677      9.4417795538902283e-02
    z[2,1,6]  R678      -5.2158057689666748e-01
    z[2,1,6]  R679      4.4169902801513672e-01
    z[2,1,6]  R680      -2.6157552003860474e-01
    z[2,1,6]  R681      7.1805804967880249e-01
    z[2,1,6]  R682      -5.7507455348968506e-01
    z[2,1,6]  R683      3.8336464762687683e-01
    z[2,1,6]  R684      -1.7829042673110962e-01
    z[2,1,6]  R685      -8.7246164679527283e-02
    z[2,1,6]  R686      4.4387900829315186e-01
    z[2,1,6]  R687      2.8109195828437805e-01
    z[2,1,6]  R688      -3.9085072278976440e-01
    z[2,1,6]  R689      -6.4286071062088013e-01
    z[2,1,6]  R690      -1.3372294604778290e-01
    z[1,4,0]  R11       -1
    z[1,4,0]  R38       1
    z[1,4,0]  R691      -1
    z[1,4,0]  R692      1
    z[1,4,0]  R705      6.1083510518074036e-02
    z[1,4,0]  R706      2.1380166709423065e-01
    z[1,4,0]  R707      -7.3983520269393921e-01
    z[1,4,0]  R708      2.5135216116905212e-01
    z[1,4,0]  R709      8.9019227027893066e-01
    z[1,4,0]  R710      8.5609972476959229e-01
    z[1,4,0]  R711      -4.3352678418159485e-02
    z[1,4,0]  R712      -2.3973140120506287e-01
    z[1,4,0]  R713      3.1451526284217834e-01
    z[1,4,0]  R714      5.4635588079690933e-02
    z[1,4,0]  R715      3.8354450464248657e-01
    z[1,4,0]  R716      3.0896863341331482e-01
    z[1,4,0]  R717      7.9854726791381836e-02
    z[1,4,0]  R718      -2.5239627808332443e-02
    z[1,4,0]  R719      2.7237203717231750e-01
    z[1,4,0]  R720      -3.5902258753776550e-01
    z[1,4,0]  R721      -2.9740709066390991e-01
    z[1,4,0]  R722      -4.5330911874771118e-02
    z[1,4,0]  R723      -3.8903504610061646e-01
    z[1,4,0]  R724      -1.7127676308155060e-01
    z[1,4,0]  R725      6.3217975199222565e-02
    z[1,4,0]  R726      -1.8302571773529053e-01
    z[1,4,0]  R727      -4.7933542728424072e-01
    z[1,4,0]  R728      3.4628391265869141e-01
    z[1,4,0]  R729      2.0839316770434380e-02
    z[1,4,0]  R730      1.1791638284921646e-01
    z[1,4,0]  R731      -5.6895387172698975e-01
    z[1,4,0]  R732      1.9080510735511780e-01
    z[1,4,0]  R733      -2.1374617516994476e-01
    z[1,4,0]  R734      -0.562109112739563
    z[1,4,0]  R735      -2.2881361842155457e-01
    z[1,4,0]  R736      -2.3070777952671051e-01
    z[1,4,0]  R737      -5.2906799316406250e-01
    z[1,4,0]  R738      -0.536858856678009
    z[1,4,0]  R739      -1.4750261604785919e-01
    z[1,4,0]  R740      -3.4159582853317261e-01
    z[1,4,0]  R741      -4.2805242538452148e-01
    z[1,4,0]  R742      2.6663309335708618e-01
    z[1,4,0]  R743      -6.7907178401947021e-01
    z[1,4,0]  R744      -6.7647963762283325e-01
    z[1,4,0]  R745      2.4160841107368469e-01
    z[1,4,0]  R746      1.3185410201549530e-01
    z[1,4,0]  R747      -1.3201734982430935e-02
    z[1,4,0]  R748      5.5172022432088852e-02
    z[1,4,0]  R749      -2.2242331877350807e-02
    z[1,4,0]  R750      7.6204225420951843e-02
    z[1,4,0]  R751      1.2282416224479675e-01
    z[1,4,0]  R752      5.5029653012752533e-02
    z[1,4,0]  R753      1.8619391322135925e-01
    z[1,4,0]  R754      -7.5316391885280609e-03
    z[1,4,0]  R755      3.0556654557585716e-02
    z[1,4,0]  R756      5.3235888481140137e-01
    z[1,4,0]  R757      5.4403203725814819e-01
    z[1,4,0]  R758      4.4899505376815796e-01
    z[1,4,0]  R759      5.0258380174636841e-01
    z[1,4,0]  R760      6.5266287326812744e-01
    z[1,4,0]  R761      6.2692219018936157e-01
    z[1,4,0]  R762      -1.3840657472610474e-01
    z[1,4,0]  R763      -1.8528200685977936e-01
    z[1,4,0]  R764      7.7054411172866821e-01
    z[1,4,0]  R765      4.3017071485519409e-01
    z[1,4,0]  R766      7.1977972984313965e-02
    z[1,4,0]  R767      -4.0937475860118866e-02
    z[1,4,0]  R768      -3.3348676562309265e-01
    z[1,4,0]  R769      3.5101863741874695e-01
    z[1,4,0]  R770      -4.0713661909103394e-01
    z[1,4,0]  R771      7.9137533903121948e-01
    z[1,4,0]  R772      -0.54306960105896
    z[1,4,0]  R773      8.4613734483718872e-01
    z[1,4,0]  R774      -1.7747931182384491e-01
    z[1,4,0]  R775      2.9744449257850647e-01
    z[1,4,0]  R776      -3.8600695133209229e-01
    z[1,4,0]  R777      3.0390096828341484e-02
    z[1,4,0]  R778      3.7899947166442871e-01
    z[1,4,0]  R779      -1.3790874183177948e-01
    z[1,4,0]  R780      1.5185585618019104e-01
    z[1,4,0]  R781      1.9510146975517273e-01
    z[1,4,0]  R782      7.7100229263305664e-01
    z[1,4,0]  R783      1.1139265447854996e-01
    z[1,4,0]  R784      7.5476515293121338e-01
    z[1,4,1]  R12       -1
    z[1,4,1]  R39       1
    z[1,4,1]  R693      -1
    z[1,4,1]  R694      1
    z[1,4,1]  R705      5.9199923276901245e-01
    z[1,4,1]  R706      -1.7263798415660858e-01
    z[1,4,1]  R707      6.1789894104003906e-01
    z[1,4,1]  R708      2.8438141942024231e-01
    z[1,4,1]  R709      -3.3239364624023438e-01
    z[1,4,1]  R710      -2.8496605157852173e-01
    z[1,4,1]  R711      3.6099424958229065e-01
    z[1,4,1]  R712      0.552646815776825
    z[1,4,1]  R713      -8.3604240417480469e-01
    z[1,4,1]  R714      4.0312197804450989e-01
    z[1,4,1]  R715      7.0076704025268555e-01
    z[1,4,1]  R716      5.3063219785690308e-01
    z[1,4,1]  R717      -1.3068813085556030e-01
    z[1,4,1]  R718      -7.0500189065933228e-01
    z[1,4,1]  R719      -0.484901487827301
    z[1,4,1]  R720      -7.5998403131961823e-02
    z[1,4,1]  R721      5.8496486395597458e-02
    z[1,4,1]  R722      -7.3956793546676636e-01
    z[1,4,1]  R723      -1.9420027732849121e-02
    z[1,4,1]  R724      -6.9828546047210693e-01
    z[1,4,1]  R725      4.2234563827514648e-01
    z[1,4,1]  R726      -2.5246351957321167e-01
    z[1,4,1]  R727      2.1436658501625061e-01
    z[1,4,1]  R728      -3.4335559606552124e-01
    z[1,4,1]  R729      4.6609568595886230e-01
    z[1,4,1]  R730      -5.4194486141204834e-01
    z[1,4,1]  R731      4.5076854526996613e-02
    z[1,4,1]  R732      -4.0479990839958191e-01
    z[1,4,1]  R733      7.3992349207401276e-02
    z[1,4,1]  R734      -5.0194181501865387e-02
    z[1,4,1]  R735      3.7018606066703796e-01
    z[1,4,1]  R736      3.2088243961334229e-01
    z[1,4,1]  R737      -0.0853620320558548
    z[1,4,1]  R738      0.352740615606308
    z[1,4,1]  R739      9.3586467206478119e-02
    z[1,4,1]  R740      3.8938581943511963e-01
    z[1,4,1]  R741      1.1426846683025360e-01
    z[1,4,1]  R742      4.3071934580802917e-01
    z[1,4,1]  R743      4.6511983871459961e-01
    z[1,4,1]  R744      5.1966643333435059e-01
    z[1,4,1]  R745      4.5888322591781616e-01
    z[1,4,1]  R746      -8.3910757303237915e-01
    z[1,4,1]  R747      -8.6533606052398682e-01
    z[1,4,1]  R748      -0.856290876865387
    z[1,4,1]  R749      -0.831427812576294
    z[1,4,1]  R750      -8.8973259925842285e-01
    z[1,4,1]  R751      -8.9831674098968506e-01
    z[1,4,1]  R752      -8.8220846652984619e-01
    z[1,4,1]  R753      -8.9002692699432373e-01
    z[1,4,1]  R754      -7.4586510658264160e-01
    z[1,4,1]  R755      2.2671137750148773e-01
    z[1,4,1]  R756      5.6912928819656372e-01
    z[1,4,1]  R757      4.9940598011016846e-01
    z[1,4,1]  R758      5.0135904550552368e-01
    z[1,4,1]  R759      4.9811157584190369e-01
    z[1,4,1]  R760      5.1809805631637573e-01
    z[1,4,1]  R761      5.7565355300903320e-01
    z[1,4,1]  R762      4.0577733516693115e-01
    z[1,4,1]  R763      -8.1414830684661865e-01
    z[1,4,1]  R764      -2.6228375732898712e-02
    z[1,4,1]  R765      5.8665776252746582e-01
    z[1,4,1]  R766      -8.8336187601089478e-01
    z[1,4,1]  R767      -8.6680001020431519e-01
    z[1,4,1]  R768      -8.3143043518066406e-01
    z[1,4,1]  R769      -8.7545108795166016e-01
    z[1,4,1]  R770      -5.9915989637374878e-01
    z[1,4,1]  R771      -3.1522031873464584e-02
    z[1,4,1]  R772      -7.1259617805480957e-01
    z[1,4,1]  R773      -2.4191428720951080e-01
    z[1,4,1]  R774      -9.0931630134582520e-01
    z[1,4,1]  R775      6.7801761627197266e-01
    z[1,4,1]  R776      -5.3744238615036011e-01
    z[1,4,1]  R777      5.1924854516983032e-01
    z[1,4,1]  R778      7.3822093009948730e-01
    z[1,4,1]  R779      -9.6936339139938354e-01
    z[1,4,1]  R780      -8.4631758928298950e-01
    z[1,4,1]  R781      -8.1340706348419189e-01
    z[1,4,1]  R782      -1.3318565487861633e-01
    z[1,4,1]  R783      -9.3571096658706665e-01
    z[1,4,1]  R784      -3.4393274784088135e-01
    z[1,4,2]  R13       -1
    z[1,4,2]  R40       1
    z[1,4,2]  R695      -1
    z[1,4,2]  R696      1
    z[1,4,2]  R705      -2.7311458252370358e-03
    z[1,4,2]  R706      -4.7505609691143036e-02
    z[1,4,2]  R707      -1.6115337610244751e-01
    z[1,4,2]  R708      -1.4312425628304482e-02
    z[1,4,2]  R709      -7.1665213909000158e-05
    z[1,4,2]  R710      1.2088888138532639e-01
    z[1,4,2]  R711      -4.1242414154112339e-03
    z[1,4,2]  R712      -2.9520472511649132e-02
    z[1,4,2]  R713      -1.7982059717178345e-01
    z[1,4,2]  R714      8.2160130143165588e-02
    z[1,4,2]  R715      1.3549405336380005e-01
    z[1,4,2]  R716      -6.9270215928554535e-02
    z[1,4,2]  R717      -1.4978380501270294e-01
    z[1,4,2]  R718      5.1258418709039688e-02
    z[1,4,2]  R719      2.1003323793411255e-01
    z[1,4,2]  R720      1.7651681602001190e-01
    z[1,4,2]  R721      1.1088189668953419e-02
    z[1,4,2]  R722      7.0806264877319336e-02
    z[1,4,2]  R723      0.0782213807106018
    z[1,4,2]  R724      1.3924143277108669e-02
    z[1,4,2]  R725      -1.6303548216819763e-01
    z[1,4,2]  R726      -2.1536026149988174e-02
    z[1,4,2]  R727      -0.0760052353143692
    z[1,4,2]  R728      2.0098702609539032e-01
    z[1,4,2]  R729      -6.1345055699348450e-02
    z[1,4,2]  R730      -1.3458553701639175e-02
    z[1,4,2]  R731      3.7188690900802612e-01
    z[1,4,2]  R732      1.6649918258190155e-01
    z[1,4,2]  R733      6.5833173692226410e-02
    z[1,4,2]  R734      4.1337138414382935e-01
    z[1,4,2]  R735      1.9356827437877655e-01
    z[1,4,2]  R736      2.4685165286064148e-01
    z[1,4,2]  R737      6.1206500977277756e-02
    z[1,4,2]  R738      -2.0180317759513855e-01
    z[1,4,2]  R739      4.4411984086036682e-01
    z[1,4,2]  R740      -4.3181997537612915e-01
    z[1,4,2]  R741      -2.7103242278099060e-01
    z[1,4,2]  R742      -2.6697742938995361e-01
    z[1,4,2]  R743      -3.4243506193161011e-01
    z[1,4,2]  R744      -1.4939494431018829e-01
    z[1,4,2]  R745      6.4450573921203613e-01
    z[1,4,2]  R746      1.0331121087074280e-01
    z[1,4,2]  R747      2.6637923717498779e-01
    z[1,4,2]  R748      -5.4543375968933105e-02
    z[1,4,2]  R749      5.0195097923278809e-02
    z[1,4,2]  R750      6.9693282246589661e-02
    z[1,4,2]  R751      -3.0473910737782717e-03
    z[1,4,2]  R752      5.7179573923349380e-03
    z[1,4,2]  R753      1.1403743177652359e-01
    z[1,4,2]  R754      1.3642043806612492e-02
    z[1,4,2]  R755      3.7542662024497986e-01
    z[1,4,2]  R756      2.8058382868766785e-01
    z[1,4,2]  R757      1.0063945502042770e-01
    z[1,4,2]  R758      4.1253137588500977e-01
    z[1,4,2]  R759      2.2937135398387909e-01
    z[1,4,2]  R760      -1.9970403984189034e-02
    z[1,4,2]  R761      -0.0692482516169548
    z[1,4,2]  R762      5.8593684434890747e-01
    z[1,4,2]  R763      4.3814271688461304e-01
    z[1,4,2]  R764      0.30632483959198
    z[1,4,2]  R765      1.7609870433807373e-01
    z[1,4,2]  R766      -1.4286562800407410e-01
    z[1,4,2]  R767      -4.6527005732059479e-02
    z[1,4,2]  R768      -1.1773762851953506e-01
    z[1,4,2]  R769      3.0067640542984009e-01
    z[1,4,2]  R770      -2.5073844194412231e-01
    z[1,4,2]  R771      0.209524467587471
    z[1,4,2]  R772      1.4049339806661010e-03
    z[1,4,2]  R773      1.0268007963895798e-01
    z[1,4,2]  R774      -2.8969830274581909e-01
    z[1,4,2]  R775      3.6941519379615784e-01
    z[1,4,2]  R776      -4.3036320805549622e-01
    z[1,4,2]  R777      5.8853012323379517e-01
    z[1,4,2]  R778      4.5391544699668884e-02
    z[1,4,2]  R779      -2.4259122088551521e-02
    z[1,4,2]  R780      8.1423148512840271e-02
    z[1,4,2]  R781      -7.7357396483421326e-02
    z[1,4,2]  R782      2.0851007103919983e-01
    z[1,4,2]  R783      -1.8838453292846680e-01
    z[1,4,2]  R784      2.4028047919273376e-01
    z[1,4,3]  R14       -1
    z[1,4,3]  R41       1
    z[1,4,3]  R697      -1
    z[1,4,3]  R698      1
    z[1,4,3]  R705      4.5125576853752136e-01
    z[1,4,3]  R706      -6.9074326753616333e-01
    z[1,4,3]  R707      1.8896495923399925e-02
    z[1,4,3]  R708      0.397897869348526
    z[1,4,3]  R709      8.4381639957427979e-02
    z[1,4,3]  R710      3.5591584444046021e-01
    z[1,4,3]  R711      9.2086660861968994e-01
    z[1,4,3]  R712      -3.1765013933181763e-01
    z[1,4,3]  R713      1.0727182030677795e-01
    z[1,4,3]  R714      3.9924341440200806e-01
    z[1,4,3]  R715      -1.9374012947082520e-01
    z[1,4,3]  R716      -2.3194399476051331e-01
    z[1,4,3]  R717      -8.7596736848354340e-02
    z[1,4,3]  R718      3.3047983050346375e-01
    z[1,4,3]  R719      2.3281952738761902e-01
    z[1,4,3]  R720      -5.7619011402130127e-01
    z[1,4,3]  R721      -7.4140834808349609e-01
    z[1,4,3]  R722      4.0285822749137878e-01
    z[1,4,3]  R723      -2.5792804360389709e-01
    z[1,4,3]  R724      3.4212014079093933e-01
    z[1,4,3]  R725      2.5536033511161804e-01
    z[1,4,3]  R726      -1.9580744206905365e-02
    z[1,4,3]  R727      5.1058417558670044e-01
    z[1,4,3]  R728      5.7484978437423706e-01
    z[1,4,3]  R729      -2.0147246122360229e-01
    z[1,4,3]  R730      6.7178118228912354e-01
    z[1,4,3]  R731      -5.1815766096115112e-01
    z[1,4,3]  R732      6.8073445558547974e-01
    z[1,4,3]  R733      -6.5127015113830566e-01
    z[1,4,3]  R734      -2.6127964258193970e-01
    z[1,4,3]  R735      5.8835631608963013e-01
    z[1,4,3]  R736      5.7909131050109863e-01
    z[1,4,3]  R737      7.1007597446441650e-01
    z[1,4,3]  R738      5.1912295818328857e-01
    z[1,4,3]  R739      6.7351454496383667e-01
    z[1,4,3]  R740      2.3599152266979218e-01
    z[1,4,3]  R741      1.0072951018810272e-01
    z[1,4,3]  R742      2.6326471567153931e-01
    z[1,4,3]  R743      -2.1841265261173248e-01
    z[1,4,3]  R744      -4.2937964200973511e-01
    z[1,4,3]  R745      -4.6761611104011536e-01
    z[1,4,3]  R746      -4.9306672811508179e-01
    z[1,4,3]  R747      -3.1495910882949829e-01
    z[1,4,3]  R748      -3.9545559883117676e-01
    z[1,4,3]  R749      -4.3779936432838440e-01
    z[1,4,3]  R750      -1.8927714228630066e-01
    z[1,4,3]  R751      -1.6373868286609650e-01
    z[1,4,3]  R752      -2.1787050366401672e-01
    z[1,4,3]  R753      -1.5182100236415863e-01
    z[1,4,3]  R754      -6.5627634525299072e-01
    z[1,4,3]  R755      -2.7796211838722229e-01
    z[1,4,3]  R756      -4.3183439970016479e-01
    z[1,4,3]  R757      -3.4537440538406372e-01
    z[1,4,3]  R758      -0.092435322701931
    z[1,4,3]  R759      -2.7672863006591797e-01
    z[1,4,3]  R760      -4.0482899546623230e-01
    z[1,4,3]  R761      -3.9469927549362183e-01
    z[1,4,3]  R762      -5.2682596445083618e-01
    z[1,4,3]  R763      -2.8664425015449524e-01
    z[1,4,3]  R764      -4.9529033899307251e-01
    z[1,4,3]  R765      -4.2812418937683105e-01
    z[1,4,3]  R766      -3.9481440186500549e-01
    z[1,4,3]  R767      -1.8525658547878265e-01
    z[1,4,3]  R768      -2.7522468566894531e-01
    z[1,4,3]  R769      0.0848386287689209
    z[1,4,3]  R770      -4.0217173099517822e-01
    z[1,4,3]  R771      -4.1430890560150146e-01
    z[1,4,3]  R772      -3.9949494600296021e-01
    z[1,4,3]  R773      -2.5498467683792114e-01
    z[1,4,3]  R774      -3.7392899394035339e-02
    z[1,4,3]  R775      -3.3119708299636841e-01
    z[1,4,3]  R776      -2.1668106317520142e-01
    z[1,4,3]  R777      -5.1878023147583008e-01
    z[1,4,3]  R778      -5.1609623432159424e-01
    z[1,4,3]  R779      -9.2928275465965271e-02
    z[1,4,3]  R780      -3.2332196831703186e-01
    z[1,4,3]  R781      -4.1578653454780579e-01
    z[1,4,3]  R782      -5.5670082569122314e-01
    z[1,4,3]  R783      -8.2895331084728241e-02
    z[1,4,3]  R784      -1.3179579377174377e-01
    z[1,4,4]  R15       -1
    z[1,4,4]  R42       1
    z[1,4,4]  R699      -1
    z[1,4,4]  R700      1
    z[1,4,4]  R705      -2.0377385616302490e-01
    z[1,4,4]  R706      -1.9554647803306580e-01
    z[1,4,4]  R707      -7.1302741765975952e-02
    z[1,4,4]  R708      -7.4175751209259033e-01
    z[1,4,4]  R709      -1.1411214619874954e-01
    z[1,4,4]  R710      -0.0604756623506546
    z[1,4,4]  R711      0.00889661442488432
    z[1,4,4]  R712      -7.1751803159713745e-01
    z[1,4,4]  R713      -1.9821767508983612e-01
    z[1,4,4]  R714      -7.7603662014007568e-01
    z[1,4,4]  R715      4.3331223726272583e-01
    z[1,4,4]  R716      3.2113659381866455e-01
    z[1,4,4]  R717      5.2670681476593018e-01
    z[1,4,4]  R718      -1.4285834133625031e-01
    z[1,4,4]  R719      -3.8055914640426636e-01
    z[1,4,4]  R720      3.7265902757644653e-01
    z[1,4,4]  R721      3.3615803718566895e-01
    z[1,4,4]  R722      -0.0842844620347023
    z[1,4,4]  R723      5.2886521816253662e-01
    z[1,4,4]  R724      -5.4532349109649658e-01
    z[1,4,4]  R725      3.8011528551578522e-02
    z[1,4,4]  R726      5.9980505704879761e-01
    z[1,4,4]  R727      -3.1217586994171143e-01
    z[1,4,4]  R728      -1.8894271552562714e-01
    z[1,4,4]  R729      7.1065044403076172e-01
    z[1,4,4]  R730      -1.7832717299461365e-01
    z[1,4,4]  R731      2.9451239109039307e-01
    z[1,4,4]  R732      2.1173436939716339e-01
    z[1,4,4]  R733      2.8134658932685852e-01
    z[1,4,4]  R734      2.1854051947593689e-01
    z[1,4,4]  R735      0.0576406754553318
    z[1,4,4]  R736      -2.8113916516304016e-01
    z[1,4,4]  R737      1.2987929582595825e-01
    z[1,4,4]  R738      4.6343860030174255e-01
    z[1,4,4]  R739      -0.510013222694397
    z[1,4,4]  R740      -4.1461598873138428e-01
    z[1,4,4]  R741      -7.2644233703613281e-01
    z[1,4,4]  R742      0.361479789018631
    z[1,4,4]  R743      8.6656715720891953e-03
    z[1,4,4]  R744      -4.3161340057849884e-02
    z[1,4,4]  R745      3.0528002977371216e-01
    z[1,4,4]  R746      2.9022667557001114e-02
    z[1,4,4]  R747      -1.9766373932361603e-01
    z[1,4,4]  R748      2.7908211946487427e-01
    z[1,4,4]  R749      2.6561075448989868e-01
    z[1,4,4]  R750      1.1386289447546005e-01
    z[1,4,4]  R751      -1.5815052390098572e-01
    z[1,4,4]  R752      2.5039520859718323e-01
    z[1,4,4]  R753      2.3188173770904541e-01
    z[1,4,4]  R754      -8.0177605152130127e-02
    z[1,4,4]  R755      3.8502511382102966e-01
    z[1,4,4]  R756      2.4384586513042450e-01
    z[1,4,4]  R757      1.8069259822368622e-01
    z[1,4,4]  R758      3.5716065764427185e-01
    z[1,4,4]  R759      0.376345157623291
    z[1,4,4]  R760      -2.0123182237148285e-01
    z[1,4,4]  R761      -1.8087539076805115e-01
    z[1,4,4]  R762      -2.9361805319786072e-01
    z[1,4,4]  R763      1.6702005267143250e-01
    z[1,4,4]  R764      1.5417100489139557e-01
    z[1,4,4]  R765      3.9853486418724060e-01
    z[1,4,4]  R766      -1.0265780985355377e-01
    z[1,4,4]  R767      -0.439564049243927
    z[1,4,4]  R768      -5.2966731600463390e-03
    z[1,4,4]  R769      -8.4944792091846466e-02
    z[1,4,4]  R770      -3.2924994826316833e-01
    z[1,4,4]  R771      -2.7652847766876221e-01
    z[1,4,4]  R772      1.5353962779045105e-01
    z[1,4,4]  R773      0.144717276096344
    z[1,4,4]  R774      -3.5749140661209822e-03
    z[1,4,4]  R775      4.1059872508049011e-01
    z[1,4,4]  R776      -2.3432014882564545e-01
    z[1,4,4]  R777      -2.3054113984107971e-01
    z[1,4,4]  R778      9.5175974071025848e-02
    z[1,4,4]  R779      1.5428699553012848e-01
    z[1,4,4]  R780      -1.8565729260444641e-01
    z[1,4,4]  R781      -2.3748582601547241e-01
    z[1,4,4]  R782      -8.1103906035423279e-02
    z[1,4,4]  R783      1.7757375538349152e-01
    z[1,4,4]  R784      4.6526998281478882e-01
    z[1,4,5]  R16       -1
    z[1,4,5]  R43       1
    z[1,4,5]  R701      -1
    z[1,4,5]  R702      1
    z[1,4,5]  R705      -5.3726172447204590e-01
    z[1,4,5]  R706      -0.626187801361084
    z[1,4,5]  R707      -1.6882559657096863e-01
    z[1,4,5]  R708      -3.3339250087738037e-01
    z[1,4,5]  R709      3.3609855920076370e-02
    z[1,4,5]  R710      -1.6285820305347443e-01
    z[1,4,5]  R711      2.5512970983982086e-02
    z[1,4,5]  R712      1.5018879203125834e-03
    z[1,4,5]  R713      -2.9831105470657349e-01
    z[1,4,5]  R714      1.9834114611148834e-01
    z[1,4,5]  R715      3.3949002623558044e-01
    z[1,4,5]  R716      -1.5337635576725006e-01
    z[1,4,5]  R717      -2.4938280880451202e-01
    z[1,4,5]  R718      5.6400257349014282e-01
    z[1,4,5]  R719      4.6394929289817810e-01
    z[1,4,5]  R720      4.4545814394950867e-01
    z[1,4,5]  R721      4.8621088266372681e-01
    z[1,4,5]  R722      -6.7275539040565491e-02
    z[1,4,5]  R723      5.4848223924636841e-01
    z[1,4,5]  R724      -4.6977987512946129e-03
    z[1,4,5]  R725      -4.5693108439445496e-01
    z[1,4,5]  R726      -4.5982575416564941e-01
    z[1,4,5]  R727      4.6194070577621460e-01
    z[1,4,5]  R728      5.6908661127090454e-01
    z[1,4,5]  R729      -4.7468963265419006e-01
    z[1,4,5]  R730      1.0996001958847046e-01
    z[1,4,5]  R731      3.1893891096115112e-01
    z[1,4,5]  R732      3.3318656682968140e-01
    z[1,4,5]  R733      1.6710844635963440e-01
    z[1,4,5]  R734      6.1378264427185059e-01
    z[1,4,5]  R735      -2.5419354438781738e-01
    z[1,4,5]  R736      5.5253233760595322e-02
    z[1,4,5]  R737      -3.6885783076286316e-02
    z[1,4,5]  R738      -2.2479355335235596e-01
    z[1,4,5]  R739      -6.6237091086804867e-03
    z[1,4,5]  R740      -4.9201363325119019e-01
    z[1,4,5]  R741      -3.0697554349899292e-01
    z[1,4,5]  R742      -5.5386364459991455e-01
    z[1,4,5]  R743      0.341463178396225
    z[1,4,5]  R744      2.4733063578605652e-01
    z[1,4,5]  R745      -5.3956888616085052e-02
    z[1,4,5]  R746      -1.4479069411754608e-01
    z[1,4,5]  R747      2.7465509250760078e-02
    z[1,4,5]  R748      2.3230038583278656e-02
    z[1,4,5]  R749      -1.4664037525653839e-01
    z[1,4,5]  R750      -2.1142846345901489e-01
    z[1,4,5]  R751      3.5193203948438168e-03
    z[1,4,5]  R752      -2.8943467140197754e-01
    z[1,4,5]  R753      1.2393782287836075e-01
    z[1,4,5]  R754      0.0698886290192604
    z[1,4,5]  R755      -7.6179319620132446e-01
    z[1,4,5]  R756      1.6764022409915924e-01
    z[1,4,5]  R757      5.3217488527297974e-01
    z[1,4,5]  R758      4.8674359917640686e-01
    z[1,4,5]  R759      4.7387725114822388e-01
    z[1,4,5]  R760      2.3500698804855347e-01
    z[1,4,5]  R761      -4.2441502213478088e-02
    z[1,4,5]  R762      -3.1275925040245056e-01
    z[1,4,5]  R763      -1.8474724143743515e-02
    z[1,4,5]  R764      1.6109757125377655e-01
    z[1,4,5]  R765      -9.8054654896259308e-02
    z[1,4,5]  R766      -1.2702740728855133e-01
    z[1,4,5]  R767      -8.6095677688717842e-03
    z[1,4,5]  R768      -2.8188601136207581e-01
    z[1,4,5]  R769      -4.4874340295791626e-02
    z[1,4,5]  R770      3.7709128856658936e-01
    z[1,4,5]  R771      -2.0452212542295456e-02
    z[1,4,5]  R772      1.1788973212242126e-01
    z[1,4,5]  R773      -6.4595431089401245e-02
    z[1,4,5]  R774      2.1863219141960144e-01
    z[1,4,5]  R775      5.1559224724769592e-02
    z[1,4,5]  R776      2.0553177595138550e-01
    z[1,4,5]  R777      -1.7279775440692902e-01
    z[1,4,5]  R778      -1.7816193401813507e-01
    z[1,4,5]  R779      -8.2208685576915741e-02
    z[1,4,5]  R780      1.6701954603195190e-01
    z[1,4,5]  R781      -6.9015175104141235e-02
    z[1,4,5]  R782      2.7071535587310791e-02
    z[1,4,5]  R783      1.9414480030536652e-01
    z[1,4,5]  R784      3.5885747522115707e-02
    z[1,4,6]  R17       -1
    z[1,4,6]  R44       1
    z[1,4,6]  R703      -1
    z[1,4,6]  R704      1
    z[1,4,6]  R705      -3.3465293049812317e-01
    z[1,4,6]  R706      -1.2145908921957016e-01
    z[1,4,6]  R707      -1.0455239564180374e-01
    z[1,4,6]  R708      1.8991325795650482e-01
    z[1,4,6]  R709      -2.7531927824020386e-01
    z[1,4,6]  R710      1.2007252871990204e-01
    z[1,4,6]  R711      1.3806284964084625e-01
    z[1,4,6]  R712      -1.4318844676017761e-01
    z[1,4,6]  R713      1.7317837476730347e-01
    z[1,4,6]  R714      -1.6367603838443756e-01
    z[1,4,6]  R715      -5.3965445607900620e-02
    z[1,4,6]  R716      6.6160291433334351e-01
    z[1,4,6]  R717      7.7898889780044556e-01
    z[1,4,6]  R718      2.2799883782863617e-01
    z[1,4,6]  R719      -4.8196563124656677e-01
    z[1,4,6]  R720      -4.0603697299957275e-01
    z[1,4,6]  R721      9.4417795538902283e-02
    z[1,4,6]  R722      -5.2158057689666748e-01
    z[1,4,6]  R723      4.4169902801513672e-01
    z[1,4,6]  R724      -2.6157552003860474e-01
    z[1,4,6]  R725      7.1805804967880249e-01
    z[1,4,6]  R726      -5.7507455348968506e-01
    z[1,4,6]  R727      3.8336464762687683e-01
    z[1,4,6]  R728      -1.7829042673110962e-01
    z[1,4,6]  R729      -8.7246164679527283e-02
    z[1,4,6]  R730      4.4387900829315186e-01
    z[1,4,6]  R731      2.8109195828437805e-01
    z[1,4,6]  R732      -3.9085072278976440e-01
    z[1,4,6]  R733      -6.4286071062088013e-01
    z[1,4,6]  R734      -1.3372294604778290e-01
    z[1,4,6]  R735      -5.9919780492782593e-01
    z[1,4,6]  R736      6.0451114177703857e-01
    z[1,4,6]  R737      -4.3199202418327332e-01
    z[1,4,6]  R738      -1.0879322141408920e-01
    z[1,4,6]  R739      -0.241790771484375
    z[1,4,6]  R740      2.7485761046409607e-01
    z[1,4,6]  R741      -3.1329923868179321e-01
    z[1,4,6]  R742      4.0665698051452637e-01
    z[1,4,6]  R743      2.0220498740673065e-01
    z[1,4,6]  R744      -5.0999283790588379e-02
    z[1,4,6]  R745      2.9861494898796082e-02
    z[1,4,6]  R746      5.4020345211029053e-02
    z[1,4,6]  R747      -2.0257534086704254e-01
    z[1,4,6]  R748      -1.6104483604431152e-01
    z[1,4,6]  R749      -1.4829909801483154e-01
    z[1,4,6]  R750      3.2283014059066772e-01
    z[1,4,6]  R751      -3.5510218143463135e-01
    z[1,4,6]  R752      1.5719279646873474e-01
    z[1,4,6]  R753      2.6076811552047729e-01
    z[1,4,6]  R754      3.7825204432010651e-02
    z[1,4,6]  R755      2.9783040285110474e-02
    z[1,4,6]  R756      -1.9978380203247070e-01
    z[1,4,6]  R757      9.6700891852378845e-02
    z[1,4,6]  R758      -6.1911858618259430e-02
    z[1,4,6]  R759      6.2522336840629578e-02
    z[1,4,6]  R760      2.1353588998317719e-01
    z[1,4,6]  R761      -2.8371039032936096e-01
    z[1,4,6]  R762      1.0625831037759781e-01
    z[1,4,6]  R763      0.0215000007301569
    z[1,4,6]  R764      1.2924927473068237e-01
    z[1,4,6]  R765      -2.9671558737754822e-01
    z[1,4,6]  R766      1.0736639797687531e-01
    z[1,4,6]  R767      1.3117294013500214e-01
    z[1,4,6]  R768      1.6855685412883759e-01
    z[1,4,6]  R769      0.0594826303422451
    z[1,4,6]  R770      5.6614372879266739e-03
    z[1,4,6]  R771      2.8335985541343689e-01
    z[1,4,6]  R772      1.4543295837938786e-02
    z[1,4,6]  R773      3.5334545373916626e-01
    z[1,4,6]  R774      9.2243090271949768e-02
    z[1,4,6]  R775      1.8549966812133789e-01
    z[1,4,6]  R776      4.8253691196441650e-01
    z[1,4,6]  R777      1.7592176795005798e-01
    z[1,4,6]  R778      4.6619750559329987e-02
    z[1,4,6]  R779      -3.9099924266338348e-02
    z[1,4,6]  R780      2.9522067308425903e-01
    z[1,4,6]  R781      -2.4551825225353241e-01
    z[1,4,6]  R782      -1.6466338932514191e-01
    z[1,4,6]  R783      2.1250389516353607e-02
    z[1,4,6]  R784      -1.3845956325531006e-01
    z[4,1,0]  R11       1
    z[4,1,0]  R38       -1
    z[4,1,0]  R785      -1
    z[4,1,0]  R786      1
    z[4,1,0]  R799      -2.2881361842155457e-01
    z[4,1,0]  R800      -2.3070777952671051e-01
    z[4,1,0]  R801      -5.2906799316406250e-01
    z[4,1,0]  R802      -0.536858856678009
    z[4,1,0]  R803      -1.4750261604785919e-01
    z[4,1,0]  R804      -3.4159582853317261e-01
    z[4,1,0]  R805      -4.2805242538452148e-01
    z[4,1,0]  R806      2.6663309335708618e-01
    z[4,1,0]  R807      -6.7907178401947021e-01
    z[4,1,0]  R808      -6.7647963762283325e-01
    z[4,1,0]  R809      2.4160841107368469e-01
    z[4,1,0]  R810      1.3185410201549530e-01
    z[4,1,0]  R811      -1.3201734982430935e-02
    z[4,1,0]  R812      5.5172022432088852e-02
    z[4,1,0]  R813      -2.2242331877350807e-02
    z[4,1,0]  R814      7.6204225420951843e-02
    z[4,1,0]  R815      1.2282416224479675e-01
    z[4,1,0]  R816      5.5029653012752533e-02
    z[4,1,0]  R817      1.8619391322135925e-01
    z[4,1,0]  R818      -7.5316391885280609e-03
    z[4,1,0]  R819      3.0556654557585716e-02
    z[4,1,0]  R820      5.3235888481140137e-01
    z[4,1,0]  R821      5.4403203725814819e-01
    z[4,1,0]  R822      4.4899505376815796e-01
    z[4,1,0]  R823      5.0258380174636841e-01
    z[4,1,0]  R824      6.5266287326812744e-01
    z[4,1,0]  R825      6.2692219018936157e-01
    z[4,1,0]  R826      -1.3840657472610474e-01
    z[4,1,0]  R827      -1.8528200685977936e-01
    z[4,1,0]  R828      7.7054411172866821e-01
    z[4,1,0]  R829      4.3017071485519409e-01
    z[4,1,0]  R830      7.1977972984313965e-02
    z[4,1,0]  R831      -4.0937475860118866e-02
    z[4,1,0]  R832      -3.3348676562309265e-01
    z[4,1,0]  R833      3.5101863741874695e-01
    z[4,1,0]  R834      -4.0713661909103394e-01
    z[4,1,0]  R835      7.9137533903121948e-01
    z[4,1,0]  R836      -0.54306960105896
    z[4,1,0]  R837      8.4613734483718872e-01
    z[4,1,0]  R838      -1.7747931182384491e-01
    z[4,1,0]  R839      2.9744449257850647e-01
    z[4,1,0]  R840      -3.8600695133209229e-01
    z[4,1,0]  R841      3.0390096828341484e-02
    z[4,1,0]  R842      3.7899947166442871e-01
    z[4,1,0]  R843      -1.3790874183177948e-01
    z[4,1,0]  R844      1.5185585618019104e-01
    z[4,1,0]  R845      1.9510146975517273e-01
    z[4,1,0]  R846      7.7100229263305664e-01
    z[4,1,0]  R847      1.1139265447854996e-01
    z[4,1,0]  R848      7.5476515293121338e-01
    z[4,1,0]  R849      6.1083510518074036e-02
    z[4,1,0]  R850      2.1380166709423065e-01
    z[4,1,0]  R851      -7.3983520269393921e-01
    z[4,1,0]  R852      2.5135216116905212e-01
    z[4,1,0]  R853      8.9019227027893066e-01
    z[4,1,0]  R854      8.5609972476959229e-01
    z[4,1,0]  R855      -4.3352678418159485e-02
    z[4,1,0]  R856      -2.3973140120506287e-01
    z[4,1,0]  R857      3.1451526284217834e-01
    z[4,1,0]  R858      5.4635588079690933e-02
    z[4,1,0]  R859      3.8354450464248657e-01
    z[4,1,0]  R860      3.0896863341331482e-01
    z[4,1,0]  R861      7.9854726791381836e-02
    z[4,1,0]  R862      -2.5239627808332443e-02
    z[4,1,0]  R863      2.7237203717231750e-01
    z[4,1,0]  R864      -3.5902258753776550e-01
    z[4,1,0]  R865      -2.9740709066390991e-01
    z[4,1,0]  R866      -4.5330911874771118e-02
    z[4,1,0]  R867      -3.8903504610061646e-01
    z[4,1,0]  R868      -1.7127676308155060e-01
    z[4,1,0]  R869      6.3217975199222565e-02
    z[4,1,0]  R870      -1.8302571773529053e-01
    z[4,1,0]  R871      -4.7933542728424072e-01
    z[4,1,0]  R872      3.4628391265869141e-01
    z[4,1,0]  R873      2.0839316770434380e-02
    z[4,1,0]  R874      1.1791638284921646e-01
    z[4,1,0]  R875      -5.6895387172698975e-01
    z[4,1,0]  R876      1.9080510735511780e-01
    z[4,1,0]  R877      -2.1374617516994476e-01
    z[4,1,0]  R878      -0.562109112739563
    z[4,1,1]  R12       1
    z[4,1,1]  R39       -1
    z[4,1,1]  R787      -1
    z[4,1,1]  R788      1
    z[4,1,1]  R799      3.7018606066703796e-01
    z[4,1,1]  R800      3.2088243961334229e-01
    z[4,1,1]  R801      -0.0853620320558548
    z[4,1,1]  R802      0.352740615606308
    z[4,1,1]  R803      9.3586467206478119e-02
    z[4,1,1]  R804      3.8938581943511963e-01
    z[4,1,1]  R805      1.1426846683025360e-01
    z[4,1,1]  R806      4.3071934580802917e-01
    z[4,1,1]  R807      4.6511983871459961e-01
    z[4,1,1]  R808      5.1966643333435059e-01
    z[4,1,1]  R809      4.5888322591781616e-01
    z[4,1,1]  R810      -8.3910757303237915e-01
    z[4,1,1]  R811      -8.6533606052398682e-01
    z[4,1,1]  R812      -0.856290876865387
    z[4,1,1]  R813      -0.831427812576294
    z[4,1,1]  R814      -8.8973259925842285e-01
    z[4,1,1]  R815      -8.9831674098968506e-01
    z[4,1,1]  R816      -8.8220846652984619e-01
    z[4,1,1]  R817      -8.9002692699432373e-01
    z[4,1,1]  R818      -7.4586510658264160e-01
    z[4,1,1]  R819      2.2671137750148773e-01
    z[4,1,1]  R820      5.6912928819656372e-01
    z[4,1,1]  R821      4.9940598011016846e-01
    z[4,1,1]  R822      5.0135904550552368e-01
    z[4,1,1]  R823      4.9811157584190369e-01
    z[4,1,1]  R824      5.1809805631637573e-01
    z[4,1,1]  R825      5.7565355300903320e-01
    z[4,1,1]  R826      4.0577733516693115e-01
    z[4,1,1]  R827      -8.1414830684661865e-01
    z[4,1,1]  R828      -2.6228375732898712e-02
    z[4,1,1]  R829      5.8665776252746582e-01
    z[4,1,1]  R830      -8.8336187601089478e-01
    z[4,1,1]  R831      -8.6680001020431519e-01
    z[4,1,1]  R832      -8.3143043518066406e-01
    z[4,1,1]  R833      -8.7545108795166016e-01
    z[4,1,1]  R834      -5.9915989637374878e-01
    z[4,1,1]  R835      -3.1522031873464584e-02
    z[4,1,1]  R836      -7.1259617805480957e-01
    z[4,1,1]  R837      -2.4191428720951080e-01
    z[4,1,1]  R838      -9.0931630134582520e-01
    z[4,1,1]  R839      6.7801761627197266e-01
    z[4,1,1]  R840      -5.3744238615036011e-01
    z[4,1,1]  R841      5.1924854516983032e-01
    z[4,1,1]  R842      7.3822093009948730e-01
    z[4,1,1]  R843      -9.6936339139938354e-01
    z[4,1,1]  R844      -8.4631758928298950e-01
    z[4,1,1]  R845      -8.1340706348419189e-01
    z[4,1,1]  R846      -1.3318565487861633e-01
    z[4,1,1]  R847      -9.3571096658706665e-01
    z[4,1,1]  R848      -3.4393274784088135e-01
    z[4,1,1]  R849      5.9199923276901245e-01
    z[4,1,1]  R850      -1.7263798415660858e-01
    z[4,1,1]  R851      6.1789894104003906e-01
    z[4,1,1]  R852      2.8438141942024231e-01
    z[4,1,1]  R853      -3.3239364624023438e-01
    z[4,1,1]  R854      -2.8496605157852173e-01
    z[4,1,1]  R855      3.6099424958229065e-01
    z[4,1,1]  R856      0.552646815776825
    z[4,1,1]  R857      -8.3604240417480469e-01
    z[4,1,1]  R858      4.0312197804450989e-01
    z[4,1,1]  R859      7.0076704025268555e-01
    z[4,1,1]  R860      5.3063219785690308e-01
    z[4,1,1]  R861      -1.3068813085556030e-01
    z[4,1,1]  R862      -7.0500189065933228e-01
    z[4,1,1]  R863      -0.484901487827301
    z[4,1,1]  R864      -7.5998403131961823e-02
    z[4,1,1]  R865      5.8496486395597458e-02
    z[4,1,1]  R866      -7.3956793546676636e-01
    z[4,1,1]  R867      -1.9420027732849121e-02
    z[4,1,1]  R868      -6.9828546047210693e-01
    z[4,1,1]  R869      4.2234563827514648e-01
    z[4,1,1]  R870      -2.5246351957321167e-01
    z[4,1,1]  R871      2.1436658501625061e-01
    z[4,1,1]  R872      -3.4335559606552124e-01
    z[4,1,1]  R873      4.6609568595886230e-01
    z[4,1,1]  R874      -5.4194486141204834e-01
    z[4,1,1]  R875      4.5076854526996613e-02
    z[4,1,1]  R876      -4.0479990839958191e-01
    z[4,1,1]  R877      7.3992349207401276e-02
    z[4,1,1]  R878      -5.0194181501865387e-02
    z[4,1,2]  R13       1
    z[4,1,2]  R40       -1
    z[4,1,2]  R789      -1
    z[4,1,2]  R790      1
    z[4,1,2]  R799      1.9356827437877655e-01
    z[4,1,2]  R800      2.4685165286064148e-01
    z[4,1,2]  R801      6.1206500977277756e-02
    z[4,1,2]  R802      -2.0180317759513855e-01
    z[4,1,2]  R803      4.4411984086036682e-01
    z[4,1,2]  R804      -4.3181997537612915e-01
    z[4,1,2]  R805      -2.7103242278099060e-01
    z[4,1,2]  R806      -2.6697742938995361e-01
    z[4,1,2]  R807      -3.4243506193161011e-01
    z[4,1,2]  R808      -1.4939494431018829e-01
    z[4,1,2]  R809      6.4450573921203613e-01
    z[4,1,2]  R810      1.0331121087074280e-01
    z[4,1,2]  R811      2.6637923717498779e-01
    z[4,1,2]  R812      -5.4543375968933105e-02
    z[4,1,2]  R813      5.0195097923278809e-02
    z[4,1,2]  R814      6.9693282246589661e-02
    z[4,1,2]  R815      -3.0473910737782717e-03
    z[4,1,2]  R816      5.7179573923349380e-03
    z[4,1,2]  R817      1.1403743177652359e-01
    z[4,1,2]  R818      1.3642043806612492e-02
    z[4,1,2]  R819      3.7542662024497986e-01
    z[4,1,2]  R820      2.8058382868766785e-01
    z[4,1,2]  R821      1.0063945502042770e-01
    z[4,1,2]  R822      4.1253137588500977e-01
    z[4,1,2]  R823      2.2937135398387909e-01
    z[4,1,2]  R824      -1.9970403984189034e-02
    z[4,1,2]  R825      -0.0692482516169548
    z[4,1,2]  R826      5.8593684434890747e-01
    z[4,1,2]  R827      4.3814271688461304e-01
    z[4,1,2]  R828      0.30632483959198
    z[4,1,2]  R829      1.7609870433807373e-01
    z[4,1,2]  R830      -1.4286562800407410e-01
    z[4,1,2]  R831      -4.6527005732059479e-02
    z[4,1,2]  R832      -1.1773762851953506e-01
    z[4,1,2]  R833      3.0067640542984009e-01
    z[4,1,2]  R834      -2.5073844194412231e-01
    z[4,1,2]  R835      0.209524467587471
    z[4,1,2]  R836      1.4049339806661010e-03
    z[4,1,2]  R837      1.0268007963895798e-01
    z[4,1,2]  R838      -2.8969830274581909e-01
    z[4,1,2]  R839      3.6941519379615784e-01
    z[4,1,2]  R840      -4.3036320805549622e-01
    z[4,1,2]  R841      5.8853012323379517e-01
    z[4,1,2]  R842      4.5391544699668884e-02
    z[4,1,2]  R843      -2.4259122088551521e-02
    z[4,1,2]  R844      8.1423148512840271e-02
    z[4,1,2]  R845      -7.7357396483421326e-02
    z[4,1,2]  R846      2.0851007103919983e-01
    z[4,1,2]  R847      -1.8838453292846680e-01
    z[4,1,2]  R848      2.4028047919273376e-01
    z[4,1,2]  R849      -2.7311458252370358e-03
    z[4,1,2]  R850      -4.7505609691143036e-02
    z[4,1,2]  R851      -1.6115337610244751e-01
    z[4,1,2]  R852      -1.4312425628304482e-02
    z[4,1,2]  R853      -7.1665213909000158e-05
    z[4,1,2]  R854      1.2088888138532639e-01
    z[4,1,2]  R855      -4.1242414154112339e-03
    z[4,1,2]  R856      -2.9520472511649132e-02
    z[4,1,2]  R857      -1.7982059717178345e-01
    z[4,1,2]  R858      8.2160130143165588e-02
    z[4,1,2]  R859      1.3549405336380005e-01
    z[4,1,2]  R860      -6.9270215928554535e-02
    z[4,1,2]  R861      -1.4978380501270294e-01
    z[4,1,2]  R862      5.1258418709039688e-02
    z[4,1,2]  R863      2.1003323793411255e-01
    z[4,1,2]  R864      1.7651681602001190e-01
    z[4,1,2]  R865      1.1088189668953419e-02
    z[4,1,2]  R866      7.0806264877319336e-02
    z[4,1,2]  R867      0.0782213807106018
    z[4,1,2]  R868      1.3924143277108669e-02
    z[4,1,2]  R869      -1.6303548216819763e-01
    z[4,1,2]  R870      -2.1536026149988174e-02
    z[4,1,2]  R871      -0.0760052353143692
    z[4,1,2]  R872      2.0098702609539032e-01
    z[4,1,2]  R873      -6.1345055699348450e-02
    z[4,1,2]  R874      -1.3458553701639175e-02
    z[4,1,2]  R875      3.7188690900802612e-01
    z[4,1,2]  R876      1.6649918258190155e-01
    z[4,1,2]  R877      6.5833173692226410e-02
    z[4,1,2]  R878      4.1337138414382935e-01
    z[4,1,3]  R14       1
    z[4,1,3]  R41       -1
    z[4,1,3]  R791      -1
    z[4,1,3]  R792      1
    z[4,1,3]  R799      5.8835631608963013e-01
    z[4,1,3]  R800      5.7909131050109863e-01
    z[4,1,3]  R801      7.1007597446441650e-01
    z[4,1,3]  R802      5.1912295818328857e-01
    z[4,1,3]  R803      6.7351454496383667e-01
    z[4,1,3]  R804      2.3599152266979218e-01
    z[4,1,3]  R805      1.0072951018810272e-01
    z[4,1,3]  R806      2.6326471567153931e-01
    z[4,1,3]  R807      -2.1841265261173248e-01
    z[4,1,3]  R808      -4.2937964200973511e-01
    z[4,1,3]  R809      -4.6761611104011536e-01
    z[4,1,3]  R810      -4.9306672811508179e-01
    z[4,1,3]  R811      -3.1495910882949829e-01
    z[4,1,3]  R812      -3.9545559883117676e-01
    z[4,1,3]  R813      -4.3779936432838440e-01
    z[4,1,3]  R814      -1.8927714228630066e-01
    z[4,1,3]  R815      -1.6373868286609650e-01
    z[4,1,3]  R816      -2.1787050366401672e-01
    z[4,1,3]  R817      -1.5182100236415863e-01
    z[4,1,3]  R818      -6.5627634525299072e-01
    z[4,1,3]  R819      -2.7796211838722229e-01
    z[4,1,3]  R820      -4.3183439970016479e-01
    z[4,1,3]  R821      -3.4537440538406372e-01
    z[4,1,3]  R822      -0.092435322701931
    z[4,1,3]  R823      -2.7672863006591797e-01
    z[4,1,3]  R824      -4.0482899546623230e-01
    z[4,1,3]  R825      -3.9469927549362183e-01
    z[4,1,3]  R826      -5.2682596445083618e-01
    z[4,1,3]  R827      -2.8664425015449524e-01
    z[4,1,3]  R828      -4.9529033899307251e-01
    z[4,1,3]  R829      -4.2812418937683105e-01
    z[4,1,3]  R830      -3.9481440186500549e-01
    z[4,1,3]  R831      -1.8525658547878265e-01
    z[4,1,3]  R832      -2.7522468566894531e-01
    z[4,1,3]  R833      0.0848386287689209
    z[4,1,3]  R834      -4.0217173099517822e-01
    z[4,1,3]  R835      -4.1430890560150146e-01
    z[4,1,3]  R836      -3.9949494600296021e-01
    z[4,1,3]  R837      -2.5498467683792114e-01
    z[4,1,3]  R838      -3.7392899394035339e-02
    z[4,1,3]  R839      -3.3119708299636841e-01
    z[4,1,3]  R840      -2.1668106317520142e-01
    z[4,1,3]  R841      -5.1878023147583008e-01
    z[4,1,3]  R842      -5.1609623432159424e-01
    z[4,1,3]  R843      -9.2928275465965271e-02
    z[4,1,3]  R844      -3.2332196831703186e-01
    z[4,1,3]  R845      -4.1578653454780579e-01
    z[4,1,3]  R846      -5.5670082569122314e-01
    z[4,1,3]  R847      -8.2895331084728241e-02
    z[4,1,3]  R848      -1.3179579377174377e-01
    z[4,1,3]  R849      4.5125576853752136e-01
    z[4,1,3]  R850      -6.9074326753616333e-01
    z[4,1,3]  R851      1.8896495923399925e-02
    z[4,1,3]  R852      0.397897869348526
    z[4,1,3]  R853      8.4381639957427979e-02
    z[4,1,3]  R854      3.5591584444046021e-01
    z[4,1,3]  R855      9.2086660861968994e-01
    z[4,1,3]  R856      -3.1765013933181763e-01
    z[4,1,3]  R857      1.0727182030677795e-01
    z[4,1,3]  R858      3.9924341440200806e-01
    z[4,1,3]  R859      -1.9374012947082520e-01
    z[4,1,3]  R860      -2.3194399476051331e-01
    z[4,1,3]  R861      -8.7596736848354340e-02
    z[4,1,3]  R862      3.3047983050346375e-01
    z[4,1,3]  R863      2.3281952738761902e-01
    z[4,1,3]  R864      -5.7619011402130127e-01
    z[4,1,3]  R865      -7.4140834808349609e-01
    z[4,1,3]  R866      4.0285822749137878e-01
    z[4,1,3]  R867      -2.5792804360389709e-01
    z[4,1,3]  R868      3.4212014079093933e-01
    z[4,1,3]  R869      2.5536033511161804e-01
    z[4,1,3]  R870      -1.9580744206905365e-02
    z[4,1,3]  R871      5.1058417558670044e-01
    z[4,1,3]  R872      5.7484978437423706e-01
    z[4,1,3]  R873      -2.0147246122360229e-01
    z[4,1,3]  R874      6.7178118228912354e-01
    z[4,1,3]  R875      -5.1815766096115112e-01
    z[4,1,3]  R876      6.8073445558547974e-01
    z[4,1,3]  R877      -6.5127015113830566e-01
    z[4,1,3]  R878      -2.6127964258193970e-01
    z[4,1,4]  R15       1
    z[4,1,4]  R42       -1
    z[4,1,4]  R793      -1
    z[4,1,4]  R794      1
    z[4,1,4]  R799      0.0576406754553318
    z[4,1,4]  R800      -2.8113916516304016e-01
    z[4,1,4]  R801      1.2987929582595825e-01
    z[4,1,4]  R802      4.6343860030174255e-01
    z[4,1,4]  R803      -0.510013222694397
    z[4,1,4]  R804      -4.1461598873138428e-01
    z[4,1,4]  R805      -7.2644233703613281e-01
    z[4,1,4]  R806      0.361479789018631
    z[4,1,4]  R807      8.6656715720891953e-03
    z[4,1,4]  R808      -4.3161340057849884e-02
    z[4,1,4]  R809      3.0528002977371216e-01
    z[4,1,4]  R810      2.9022667557001114e-02
    z[4,1,4]  R811      -1.9766373932361603e-01
    z[4,1,4]  R812      2.7908211946487427e-01
    z[4,1,4]  R813      2.6561075448989868e-01
    z[4,1,4]  R814      1.1386289447546005e-01
    z[4,1,4]  R815      -1.5815052390098572e-01
    z[4,1,4]  R816      2.5039520859718323e-01
    z[4,1,4]  R817      2.3188173770904541e-01
    z[4,1,4]  R818      -8.0177605152130127e-02
    z[4,1,4]  R819      3.8502511382102966e-01
    z[4,1,4]  R820      2.4384586513042450e-01
    z[4,1,4]  R821      1.8069259822368622e-01
    z[4,1,4]  R822      3.5716065764427185e-01
    z[4,1,4]  R823      0.376345157623291
    z[4,1,4]  R824      -2.0123182237148285e-01
    z[4,1,4]  R825      -1.8087539076805115e-01
    z[4,1,4]  R826      -2.9361805319786072e-01
    z[4,1,4]  R827      1.6702005267143250e-01
    z[4,1,4]  R828      1.5417100489139557e-01
    z[4,1,4]  R829      3.9853486418724060e-01
    z[4,1,4]  R830      -1.0265780985355377e-01
    z[4,1,4]  R831      -0.439564049243927
    z[4,1,4]  R832      -5.2966731600463390e-03
    z[4,1,4]  R833      -8.4944792091846466e-02
    z[4,1,4]  R834      -3.2924994826316833e-01
    z[4,1,4]  R835      -2.7652847766876221e-01
    z[4,1,4]  R836      1.5353962779045105e-01
    z[4,1,4]  R837      0.144717276096344
    z[4,1,4]  R838      -3.5749140661209822e-03
    z[4,1,4]  R839      4.1059872508049011e-01
    z[4,1,4]  R840      -2.3432014882564545e-01
    z[4,1,4]  R841      -2.3054113984107971e-01
    z[4,1,4]  R842      9.5175974071025848e-02
    z[4,1,4]  R843      1.5428699553012848e-01
    z[4,1,4]  R844      -1.8565729260444641e-01
    z[4,1,4]  R845      -2.3748582601547241e-01
    z[4,1,4]  R846      -8.1103906035423279e-02
    z[4,1,4]  R847      1.7757375538349152e-01
    z[4,1,4]  R848      4.6526998281478882e-01
    z[4,1,4]  R849      -2.0377385616302490e-01
    z[4,1,4]  R850      -1.9554647803306580e-01
    z[4,1,4]  R851      -7.1302741765975952e-02
    z[4,1,4]  R852      -7.4175751209259033e-01
    z[4,1,4]  R853      -1.1411214619874954e-01
    z[4,1,4]  R854      -0.0604756623506546
    z[4,1,4]  R855      0.00889661442488432
    z[4,1,4]  R856      -7.1751803159713745e-01
    z[4,1,4]  R857      -1.9821767508983612e-01
    z[4,1,4]  R858      -7.7603662014007568e-01
    z[4,1,4]  R859      4.3331223726272583e-01
    z[4,1,4]  R860      3.2113659381866455e-01
    z[4,1,4]  R861      5.2670681476593018e-01
    z[4,1,4]  R862      -1.4285834133625031e-01
    z[4,1,4]  R863      -3.8055914640426636e-01
    z[4,1,4]  R864      3.7265902757644653e-01
    z[4,1,4]  R865      3.3615803718566895e-01
    z[4,1,4]  R866      -0.0842844620347023
    z[4,1,4]  R867      5.2886521816253662e-01
    z[4,1,4]  R868      -5.4532349109649658e-01
    z[4,1,4]  R869      3.8011528551578522e-02
    z[4,1,4]  R870      5.9980505704879761e-01
    z[4,1,4]  R871      -3.1217586994171143e-01
    z[4,1,4]  R872      -1.8894271552562714e-01
    z[4,1,4]  R873      7.1065044403076172e-01
    z[4,1,4]  R874      -1.7832717299461365e-01
    z[4,1,4]  R875      2.9451239109039307e-01
    z[4,1,4]  R876      2.1173436939716339e-01
    z[4,1,4]  R877      2.8134658932685852e-01
    z[4,1,4]  R878      2.1854051947593689e-01
    z[4,1,5]  R16       1
    z[4,1,5]  R43       -1
    z[4,1,5]  R795      -1
    z[4,1,5]  R796      1
    z[4,1,5]  R799      -2.5419354438781738e-01
    z[4,1,5]  R800      5.5253233760595322e-02
    z[4,1,5]  R801      -3.6885783076286316e-02
    z[4,1,5]  R802      -2.2479355335235596e-01
    z[4,1,5]  R803      -6.6237091086804867e-03
    z[4,1,5]  R804      -4.9201363325119019e-01
    z[4,1,5]  R805      -3.0697554349899292e-01
    z[4,1,5]  R806      -5.5386364459991455e-01
    z[4,1,5]  R807      0.341463178396225
    z[4,1,5]  R808      2.4733063578605652e-01
    z[4,1,5]  R809      -5.3956888616085052e-02
    z[4,1,5]  R810      -1.4479069411754608e-01
    z[4,1,5]  R811      2.7465509250760078e-02
    z[4,1,5]  R812      2.3230038583278656e-02
    z[4,1,5]  R813      -1.4664037525653839e-01
    z[4,1,5]  R814      -2.1142846345901489e-01
    z[4,1,5]  R815      3.5193203948438168e-03
    z[4,1,5]  R816      -2.8943467140197754e-01
    z[4,1,5]  R817      1.2393782287836075e-01
    z[4,1,5]  R818      0.0698886290192604
    z[4,1,5]  R819      -7.6179319620132446e-01
    z[4,1,5]  R820      1.6764022409915924e-01
    z[4,1,5]  R821      5.3217488527297974e-01
    z[4,1,5]  R822      4.8674359917640686e-01
    z[4,1,5]  R823      4.7387725114822388e-01
    z[4,1,5]  R824      2.3500698804855347e-01
    z[4,1,5]  R825      -4.2441502213478088e-02
    z[4,1,5]  R826      -3.1275925040245056e-01
    z[4,1,5]  R827      -1.8474724143743515e-02
    z[4,1,5]  R828      1.6109757125377655e-01
    z[4,1,5]  R829      -9.8054654896259308e-02
    z[4,1,5]  R830      -1.2702740728855133e-01
    z[4,1,5]  R831      -8.6095677688717842e-03
    z[4,1,5]  R832      -2.8188601136207581e-01
    z[4,1,5]  R833      -4.4874340295791626e-02
    z[4,1,5]  R834      3.7709128856658936e-01
    z[4,1,5]  R835      -2.0452212542295456e-02
    z[4,1,5]  R836      1.1788973212242126e-01
    z[4,1,5]  R837      -6.4595431089401245e-02
    z[4,1,5]  R838      2.1863219141960144e-01
    z[4,1,5]  R839      5.1559224724769592e-02
    z[4,1,5]  R840      2.0553177595138550e-01
    z[4,1,5]  R841      -1.7279775440692902e-01
    z[4,1,5]  R842      -1.7816193401813507e-01
    z[4,1,5]  R843      -8.2208685576915741e-02
    z[4,1,5]  R844      1.6701954603195190e-01
    z[4,1,5]  R845      -6.9015175104141235e-02
    z[4,1,5]  R846      2.7071535587310791e-02
    z[4,1,5]  R847      1.9414480030536652e-01
    z[4,1,5]  R848      3.5885747522115707e-02
    z[4,1,5]  R849      -5.3726172447204590e-01
    z[4,1,5]  R850      -0.626187801361084
    z[4,1,5]  R851      -1.6882559657096863e-01
    z[4,1,5]  R852      -3.3339250087738037e-01
    z[4,1,5]  R853      3.3609855920076370e-02
    z[4,1,5]  R854      -1.6285820305347443e-01
    z[4,1,5]  R855      2.5512970983982086e-02
    z[4,1,5]  R856      1.5018879203125834e-03
    z[4,1,5]  R857      -2.9831105470657349e-01
    z[4,1,5]  R858      1.9834114611148834e-01
    z[4,1,5]  R859      3.3949002623558044e-01
    z[4,1,5]  R860      -1.5337635576725006e-01
    z[4,1,5]  R861      -2.4938280880451202e-01
    z[4,1,5]  R862      5.6400257349014282e-01
    z[4,1,5]  R863      4.6394929289817810e-01
    z[4,1,5]  R864      4.4545814394950867e-01
    z[4,1,5]  R865      4.8621088266372681e-01
    z[4,1,5]  R866      -6.7275539040565491e-02
    z[4,1,5]  R867      5.4848223924636841e-01
    z[4,1,5]  R868      -4.6977987512946129e-03
    z[4,1,5]  R869      -4.5693108439445496e-01
    z[4,1,5]  R870      -4.5982575416564941e-01
    z[4,1,5]  R871      4.6194070577621460e-01
    z[4,1,5]  R872      5.6908661127090454e-01
    z[4,1,5]  R873      -4.7468963265419006e-01
    z[4,1,5]  R874      1.0996001958847046e-01
    z[4,1,5]  R875      3.1893891096115112e-01
    z[4,1,5]  R876      3.3318656682968140e-01
    z[4,1,5]  R877      1.6710844635963440e-01
    z[4,1,5]  R878      6.1378264427185059e-01
    z[4,1,6]  R17       1
    z[4,1,6]  R44       -1
    z[4,1,6]  R797      -1
    z[4,1,6]  R798      1
    z[4,1,6]  R799      -5.9919780492782593e-01
    z[4,1,6]  R800      6.0451114177703857e-01
    z[4,1,6]  R801      -4.3199202418327332e-01
    z[4,1,6]  R802      -1.0879322141408920e-01
    z[4,1,6]  R803      -0.241790771484375
    z[4,1,6]  R804      2.7485761046409607e-01
    z[4,1,6]  R805      -3.1329923868179321e-01
    z[4,1,6]  R806      4.0665698051452637e-01
    z[4,1,6]  R807      2.0220498740673065e-01
    z[4,1,6]  R808      -5.0999283790588379e-02
    z[4,1,6]  R809      2.9861494898796082e-02
    z[4,1,6]  R810      5.4020345211029053e-02
    z[4,1,6]  R811      -2.0257534086704254e-01
    z[4,1,6]  R812      -1.6104483604431152e-01
    z[4,1,6]  R813      -1.4829909801483154e-01
    z[4,1,6]  R814      3.2283014059066772e-01
    z[4,1,6]  R815      -3.5510218143463135e-01
    z[4,1,6]  R816      1.5719279646873474e-01
    z[4,1,6]  R817      2.6076811552047729e-01
    z[4,1,6]  R818      3.7825204432010651e-02
    z[4,1,6]  R819      2.9783040285110474e-02
    z[4,1,6]  R820      -1.9978380203247070e-01
    z[4,1,6]  R821      9.6700891852378845e-02
    z[4,1,6]  R822      -6.1911858618259430e-02
    z[4,1,6]  R823      6.2522336840629578e-02
    z[4,1,6]  R824      2.1353588998317719e-01
    z[4,1,6]  R825      -2.8371039032936096e-01
    z[4,1,6]  R826      1.0625831037759781e-01
    z[4,1,6]  R827      0.0215000007301569
    z[4,1,6]  R828      1.2924927473068237e-01
    z[4,1,6]  R829      -2.9671558737754822e-01
    z[4,1,6]  R830      1.0736639797687531e-01
    z[4,1,6]  R831      1.3117294013500214e-01
    z[4,1,6]  R832      1.6855685412883759e-01
    z[4,1,6]  R833      0.0594826303422451
    z[4,1,6]  R834      5.6614372879266739e-03
    z[4,1,6]  R835      2.8335985541343689e-01
    z[4,1,6]  R836      1.4543295837938786e-02
    z[4,1,6]  R837      3.5334545373916626e-01
    z[4,1,6]  R838      9.2243090271949768e-02
    z[4,1,6]  R839      1.8549966812133789e-01
    z[4,1,6]  R840      4.8253691196441650e-01
    z[4,1,6]  R841      1.7592176795005798e-01
    z[4,1,6]  R842      4.6619750559329987e-02
    z[4,1,6]  R843      -3.9099924266338348e-02
    z[4,1,6]  R844      2.9522067308425903e-01
    z[4,1,6]  R845      -2.4551825225353241e-01
    z[4,1,6]  R846      -1.6466338932514191e-01
    z[4,1,6]  R847      2.1250389516353607e-02
    z[4,1,6]  R848      -1.3845956325531006e-01
    z[4,1,6]  R849      -3.3465293049812317e-01
    z[4,1,6]  R850      -1.2145908921957016e-01
    z[4,1,6]  R851      -1.0455239564180374e-01
    z[4,1,6]  R852      1.8991325795650482e-01
    z[4,1,6]  R853      -2.7531927824020386e-01
    z[4,1,6]  R854      1.2007252871990204e-01
    z[4,1,6]  R855      1.3806284964084625e-01
    z[4,1,6]  R856      -1.4318844676017761e-01
    z[4,1,6]  R857      1.7317837476730347e-01
    z[4,1,6]  R858      -1.6367603838443756e-01
    z[4,1,6]  R859      -5.3965445607900620e-02
    z[4,1,6]  R860      6.6160291433334351e-01
    z[4,1,6]  R861      7.7898889780044556e-01
    z[4,1,6]  R862      2.2799883782863617e-01
    z[4,1,6]  R863      -4.8196563124656677e-01
    z[4,1,6]  R864      -4.0603697299957275e-01
    z[4,1,6]  R865      9.4417795538902283e-02
    z[4,1,6]  R866      -5.2158057689666748e-01
    z[4,1,6]  R867      4.4169902801513672e-01
    z[4,1,6]  R868      -2.6157552003860474e-01
    z[4,1,6]  R869      7.1805804967880249e-01
    z[4,1,6]  R870      -5.7507455348968506e-01
    z[4,1,6]  R871      3.8336464762687683e-01
    z[4,1,6]  R872      -1.7829042673110962e-01
    z[4,1,6]  R873      -8.7246164679527283e-02
    z[4,1,6]  R874      4.4387900829315186e-01
    z[4,1,6]  R875      2.8109195828437805e-01
    z[4,1,6]  R876      -3.9085072278976440e-01
    z[4,1,6]  R877      -6.4286071062088013e-01
    z[4,1,6]  R878      -1.3372294604778290e-01
    z[1,5,0]  R11       -1
    z[1,5,0]  R47       1
    z[1,5,0]  R879      -1
    z[1,5,0]  R880      1
    z[1,5,0]  R893      6.1083510518074036e-02
    z[1,5,0]  R894      2.1380166709423065e-01
    z[1,5,0]  R895      -7.3983520269393921e-01
    z[1,5,0]  R896      2.5135216116905212e-01
    z[1,5,0]  R897      8.9019227027893066e-01
    z[1,5,0]  R898      8.5609972476959229e-01
    z[1,5,0]  R899      -4.3352678418159485e-02
    z[1,5,0]  R900      -2.3973140120506287e-01
    z[1,5,0]  R901      3.1451526284217834e-01
    z[1,5,0]  R902      5.4635588079690933e-02
    z[1,5,0]  R903      3.8354450464248657e-01
    z[1,5,0]  R904      3.0896863341331482e-01
    z[1,5,0]  R905      7.9854726791381836e-02
    z[1,5,0]  R906      -2.5239627808332443e-02
    z[1,5,0]  R907      2.7237203717231750e-01
    z[1,5,0]  R908      -3.5902258753776550e-01
    z[1,5,0]  R909      -2.9740709066390991e-01
    z[1,5,0]  R910      -4.5330911874771118e-02
    z[1,5,0]  R911      -3.8903504610061646e-01
    z[1,5,0]  R912      -1.7127676308155060e-01
    z[1,5,0]  R913      6.3217975199222565e-02
    z[1,5,0]  R914      -1.8302571773529053e-01
    z[1,5,0]  R915      -4.7933542728424072e-01
    z[1,5,0]  R916      3.4628391265869141e-01
    z[1,5,0]  R917      2.0839316770434380e-02
    z[1,5,0]  R918      1.1791638284921646e-01
    z[1,5,0]  R919      -5.6895387172698975e-01
    z[1,5,0]  R920      1.9080510735511780e-01
    z[1,5,0]  R921      -2.1374617516994476e-01
    z[1,5,0]  R922      -0.562109112739563
    z[1,5,0]  R923      6.5863317251205444e-01
    z[1,5,0]  R924      3.5136952996253967e-01
    z[1,5,0]  R925      4.5002645254135132e-01
    z[1,5,0]  R926      -1.8709459900856018e-01
    z[1,5,0]  R927      -6.0926965670660138e-04
    z[1,5,0]  R928      5.3828325122594833e-02
    z[1,5,0]  R929      -5.7057225704193115e-01
    z[1,5,0]  R930      -9.6037723124027252e-02
    z[1,5,0]  R931      -4.0170863270759583e-01
    z[1,5,0]  R932      -4.4690504670143127e-01
    z[1,5,0]  R933      2.4390691518783569e-01
    z[1,5,0]  R934      -1.6205526888370514e-01
    z[1,5,0]  R935      -4.1034218668937683e-01
    z[1,5,0]  R936      -0.491395503282547
    z[1,5,0]  R937      -5.4686480760574341e-01
    z[1,5,0]  R938      7.1733094751834869e-02
    z[1,5,0]  R939      3.0037495493888855e-01
    z[1,5,0]  R940      1.6303683817386627e-01
    z[1,5,0]  R941      3.2199257612228394e-01
    z[1,5,0]  R942      5.4086589813232422e-01
    z[1,5,0]  R943      -9.2967316508293152e-02
    z[1,5,0]  R944      -8.6629527807235718e-01
    z[1,5,0]  R945      -8.9378046989440918e-01
    z[1,5,0]  R946      -6.3994240760803223e-01
    z[1,5,0]  R947      -7.6945525407791138e-01
    z[1,5,0]  R948      -6.9138383865356445e-01
    z[1,5,0]  R949      -3.5067155957221985e-01
    z[1,5,0]  R950      4.1472426056861877e-01
    z[1,5,0]  R951      4.9624881148338318e-01
    z[1,5,0]  R952      5.4533189535140991e-01
    z[1,5,1]  R12       -1
    z[1,5,1]  R48       1
    z[1,5,1]  R881      -1
    z[1,5,1]  R882      1
    z[1,5,1]  R893      5.9199923276901245e-01
    z[1,5,1]  R894      -1.7263798415660858e-01
    z[1,5,1]  R895      6.1789894104003906e-01
    z[1,5,1]  R896      2.8438141942024231e-01
    z[1,5,1]  R897      -3.3239364624023438e-01
    z[1,5,1]  R898      -2.8496605157852173e-01
    z[1,5,1]  R899      3.6099424958229065e-01
    z[1,5,1]  R900      0.552646815776825
    z[1,5,1]  R901      -8.3604240417480469e-01
    z[1,5,1]  R902      4.0312197804450989e-01
    z[1,5,1]  R903      7.0076704025268555e-01
    z[1,5,1]  R904      5.3063219785690308e-01
    z[1,5,1]  R905      -1.3068813085556030e-01
    z[1,5,1]  R906      -7.0500189065933228e-01
    z[1,5,1]  R907      -0.484901487827301
    z[1,5,1]  R908      -7.5998403131961823e-02
    z[1,5,1]  R909      5.8496486395597458e-02
    z[1,5,1]  R910      -7.3956793546676636e-01
    z[1,5,1]  R911      -1.9420027732849121e-02
    z[1,5,1]  R912      -6.9828546047210693e-01
    z[1,5,1]  R913      4.2234563827514648e-01
    z[1,5,1]  R914      -2.5246351957321167e-01
    z[1,5,1]  R915      2.1436658501625061e-01
    z[1,5,1]  R916      -3.4335559606552124e-01
    z[1,5,1]  R917      4.6609568595886230e-01
    z[1,5,1]  R918      -5.4194486141204834e-01
    z[1,5,1]  R919      4.5076854526996613e-02
    z[1,5,1]  R920      -4.0479990839958191e-01
    z[1,5,1]  R921      7.3992349207401276e-02
    z[1,5,1]  R922      -5.0194181501865387e-02
    z[1,5,1]  R923      3.5655662417411804e-02
    z[1,5,1]  R924      -6.8967863917350769e-02
    z[1,5,1]  R925      3.3862382173538208e-02
    z[1,5,1]  R926      1.3009256124496460e-01
    z[1,5,1]  R927      7.6676271855831146e-02
    z[1,5,1]  R928      1.8855138123035431e-01
    z[1,5,1]  R929      1.0348648577928543e-01
    z[1,5,1]  R930      1.7468252778053284e-01
    z[1,5,1]  R931      4.8111043870449066e-03
    z[1,5,1]  R932      -5.5101740360260010e-01
    z[1,5,1]  R933      3.6529025435447693e-01
    z[1,5,1]  R934      5.0101137161254883e-01
    z[1,5,1]  R935      2.3997753858566284e-01
    z[1,5,1]  R936      6.4626473188400269e-01
    z[1,5,1]  R937      -2.7780082821846008e-01
    z[1,5,1]  R938      5.2693653106689453e-01
    z[1,5,1]  R939      2.0449882745742798e-01
    z[1,5,1]  R940      2.8308564424514771e-01
    z[1,5,1]  R941      1.5430007874965668e-01
    z[1,5,1]  R942      -6.8047416210174561e-01
    z[1,5,1]  R943      7.3471927642822266e-01
    z[1,5,1]  R944      -3.5882565379142761e-01
    z[1,5,1]  R945      -1.5928235650062561e-01
    z[1,5,1]  R946      7.7059499919414520e-02
    z[1,5,1]  R947      0.0466160774230957
    z[1,5,1]  R948      -2.1337196230888367e-01
    z[1,5,1]  R949      -2.3984816670417786e-01
    z[1,5,1]  R950      3.0023759603500366e-01
    z[1,5,1]  R951      -7.8539723157882690e-01
    z[1,5,1]  R952      -6.9796615839004517e-01
    z[1,5,2]  R13       -1
    z[1,5,2]  R49       1
    z[1,5,2]  R883      -1
    z[1,5,2]  R884      1
    z[1,5,2]  R893      -2.7311458252370358e-03
    z[1,5,2]  R894      -4.7505609691143036e-02
    z[1,5,2]  R895      -1.6115337610244751e-01
    z[1,5,2]  R896      -1.4312425628304482e-02
    z[1,5,2]  R897      -7.1665213909000158e-05
    z[1,5,2]  R898      1.2088888138532639e-01
    z[1,5,2]  R899      -4.1242414154112339e-03
    z[1,5,2]  R900      -2.9520472511649132e-02
    z[1,5,2]  R901      -1.7982059717178345e-01
    z[1,5,2]  R902      8.2160130143165588e-02
    z[1,5,2]  R903      1.3549405336380005e-01
    z[1,5,2]  R904      -6.9270215928554535e-02
    z[1,5,2]  R905      -1.4978380501270294e-01
    z[1,5,2]  R906      5.1258418709039688e-02
    z[1,5,2]  R907      2.1003323793411255e-01
    z[1,5,2]  R908      1.7651681602001190e-01
    z[1,5,2]  R909      1.1088189668953419e-02
    z[1,5,2]  R910      7.0806264877319336e-02
    z[1,5,2]  R911      0.0782213807106018
    z[1,5,2]  R912      1.3924143277108669e-02
    z[1,5,2]  R913      -1.6303548216819763e-01
    z[1,5,2]  R914      -2.1536026149988174e-02
    z[1,5,2]  R915      -0.0760052353143692
    z[1,5,2]  R916      2.0098702609539032e-01
    z[1,5,2]  R917      -6.1345055699348450e-02
    z[1,5,2]  R918      -1.3458553701639175e-02
    z[1,5,2]  R919      3.7188690900802612e-01
    z[1,5,2]  R920      1.6649918258190155e-01
    z[1,5,2]  R921      6.5833173692226410e-02
    z[1,5,2]  R922      4.1337138414382935e-01
    z[1,5,2]  R923      4.9690103530883789e-01
    z[1,5,2]  R924      5.6668418645858765e-01
    z[1,5,2]  R925      0.788059413433075
    z[1,5,2]  R926      4.3211534619331360e-01
    z[1,5,2]  R927      8.6823272705078125e-01
    z[1,5,2]  R928      5.7285249233245850e-01
    z[1,5,2]  R929      -5.4072532802820206e-02
    z[1,5,2]  R930      -7.0453107357025146e-02
    z[1,5,2]  R931      -2.5815838575363159e-01
    z[1,5,2]  R932      2.3707246780395508e-01
    z[1,5,2]  R933      -3.4773632884025574e-01
    z[1,5,2]  R934      -4.4258171319961548e-01
    z[1,5,2]  R935      -2.0929503440856934e-01
    z[1,5,2]  R936      0.0709293782711029
    z[1,5,2]  R937      -6.5322893857955933e-01
    z[1,5,2]  R938      -1.1875462532043457e-01
    z[1,5,2]  R939      -3.9269593358039856e-01
    z[1,5,2]  R940      -4.7192507982254028e-01
    z[1,5,2]  R941      -3.8370156288146973e-01
    z[1,5,2]  R942      -2.9528501629829407e-01
    z[1,5,2]  R943      1.4096125960350037e-01
    z[1,5,2]  R944      -1.0095614194869995e-01
    z[1,5,2]  R945      1.3848142325878143e-01
    z[1,5,2]  R946      -3.6666259169578552e-01
    z[1,5,2]  R947      -3.1680583953857422e-01
    z[1,5,2]  R948      -0.0551447868347168
    z[1,5,2]  R949      -4.8404029011726379e-01
    z[1,5,2]  R950      -3.7091752886772156e-01
    z[1,5,2]  R951      -1.7900729179382324e-01
    z[1,5,2]  R952      -1.5813142061233521e-01
    z[1,5,3]  R14       -1
    z[1,5,3]  R50       1
    z[1,5,3]  R885      -1
    z[1,5,3]  R886      1
    z[1,5,3]  R893      4.5125576853752136e-01
    z[1,5,3]  R894      -6.9074326753616333e-01
    z[1,5,3]  R895      1.8896495923399925e-02
    z[1,5,3]  R896      0.397897869348526
    z[1,5,3]  R897      8.4381639957427979e-02
    z[1,5,3]  R898      3.5591584444046021e-01
    z[1,5,3]  R899      9.2086660861968994e-01
    z[1,5,3]  R900      -3.1765013933181763e-01
    z[1,5,3]  R901      1.0727182030677795e-01
    z[1,5,3]  R902      3.9924341440200806e-01
    z[1,5,3]  R903      -1.9374012947082520e-01
    z[1,5,3]  R904      -2.3194399476051331e-01
    z[1,5,3]  R905      -8.7596736848354340e-02
    z[1,5,3]  R906      3.3047983050346375e-01
    z[1,5,3]  R907      2.3281952738761902e-01
    z[1,5,3]  R908      -5.7619011402130127e-01
    z[1,5,3]  R909      -7.4140834808349609e-01
    z[1,5,3]  R910      4.0285822749137878e-01
    z[1,5,3]  R911      -2.5792804360389709e-01
    z[1,5,3]  R912      3.4212014079093933e-01
    z[1,5,3]  R913      2.5536033511161804e-01
    z[1,5,3]  R914      -1.9580744206905365e-02
    z[1,5,3]  R915      5.1058417558670044e-01
    z[1,5,3]  R916      5.7484978437423706e-01
    z[1,5,3]  R917      -2.0147246122360229e-01
    z[1,5,3]  R918      6.7178118228912354e-01
    z[1,5,3]  R919      -5.1815766096115112e-01
    z[1,5,3]  R920      6.8073445558547974e-01
    z[1,5,3]  R921      -6.5127015113830566e-01
    z[1,5,3]  R922      -2.6127964258193970e-01
    z[1,5,3]  R923      -5.0862443447113037e-01
    z[1,5,3]  R924      2.7938507497310638e-02
    z[1,5,3]  R925      -1.6678662598133087e-01
    z[1,5,3]  R926      1.1506868898868561e-01
    z[1,5,3]  R927      -1.8325862288475037e-01
    z[1,5,3]  R928      6.6361993551254272e-01
    z[1,5,3]  R929      0.674699068069458
    z[1,5,3]  R930      4.8612591624259949e-01
    z[1,5,3]  R931      4.2541259527206421e-01
    z[1,5,3]  R932      5.2751320600509644e-01
    z[1,5,3]  R933      -2.3076803982257843e-01
    z[1,5,3]  R934      -5.7352638244628906e-01
    z[1,5,3]  R935      -7.9003876447677612e-01
    z[1,5,3]  R936      -1.9347956776618958e-01
    z[1,5,3]  R937      1.0992675274610519e-01
    z[1,5,3]  R938      0.453823983669281
    z[1,5,3]  R939      -1.9309048354625702e-01
    z[1,5,3]  R940      1.9135428592562675e-02
    z[1,5,3]  R941      -2.6681306958198547e-01
    z[1,5,3]  R942      1.7161494493484497e-01
    z[1,5,3]  R943      4.4192460179328918e-01
    z[1,5,3]  R944      0.290324866771698
    z[1,5,3]  R945      2.8379639983177185e-01
    z[1,5,3]  R946      4.4903361797332764e-01
    z[1,5,3]  R947      4.4476497173309326e-01
    z[1,5,3]  R948      4.6124801039695740e-01
    z[1,5,3]  R949      7.2298157215118408e-01
    z[1,5,3]  R950      3.6498349905014038e-01
    z[1,5,3]  R951      0.132520392537117
    z[1,5,3]  R952      0.301140159368515
    z[1,5,4]  R15       -1
    z[1,5,4]  R51       1
    z[1,5,4]  R887      -1
    z[1,5,4]  R888      1
    z[1,5,4]  R893      -2.0377385616302490e-01
    z[1,5,4]  R894      -1.9554647803306580e-01
    z[1,5,4]  R895      -7.1302741765975952e-02
    z[1,5,4]  R896      -7.4175751209259033e-01
    z[1,5,4]  R897      -1.1411214619874954e-01
    z[1,5,4]  R898      -0.0604756623506546
    z[1,5,4]  R899      0.00889661442488432
    z[1,5,4]  R900      -7.1751803159713745e-01
    z[1,5,4]  R901      -1.9821767508983612e-01
    z[1,5,4]  R902      -7.7603662014007568e-01
    z[1,5,4]  R903      4.3331223726272583e-01
    z[1,5,4]  R904      3.2113659381866455e-01
    z[1,5,4]  R905      5.2670681476593018e-01
    z[1,5,4]  R906      -1.4285834133625031e-01
    z[1,5,4]  R907      -3.8055914640426636e-01
    z[1,5,4]  R908      3.7265902757644653e-01
    z[1,5,4]  R909      3.3615803718566895e-01
    z[1,5,4]  R910      -0.0842844620347023
    z[1,5,4]  R911      5.2886521816253662e-01
    z[1,5,4]  R912      -5.4532349109649658e-01
    z[1,5,4]  R913      3.8011528551578522e-02
    z[1,5,4]  R914      5.9980505704879761e-01
    z[1,5,4]  R915      -3.1217586994171143e-01
    z[1,5,4]  R916      -1.8894271552562714e-01
    z[1,5,4]  R917      7.1065044403076172e-01
    z[1,5,4]  R918      -1.7832717299461365e-01
    z[1,5,4]  R919      2.9451239109039307e-01
    z[1,5,4]  R920      2.1173436939716339e-01
    z[1,5,4]  R921      2.8134658932685852e-01
    z[1,5,4]  R922      2.1854051947593689e-01
    z[1,5,4]  R923      1.7950442433357239e-01
    z[1,5,4]  R924      0.481612890958786
    z[1,5,4]  R925      -6.2043469399213791e-02
    z[1,5,4]  R926      1.0086730867624283e-01
    z[1,5,4]  R927      -4.4408363103866577e-01
    z[1,5,4]  R928      -1.0774364322423935e-01
    z[1,5,4]  R929      2.2905133664608002e-01
    z[1,5,4]  R930      5.6224584579467773e-01
    z[1,5,4]  R931      -3.8214331865310669e-01
    z[1,5,4]  R932      -1.6736510396003723e-01
    z[1,5,4]  R933      6.4547348022460938e-01
    z[1,5,4]  R934      3.7332189083099365e-01
    z[1,5,4]  R935      9.3645811080932617e-02
    z[1,5,4]  R936      4.4748380780220032e-01
    z[1,5,4]  R937      -2.1066750586032867e-01
    z[1,5,4]  R938      -7.4922956526279449e-02
    z[1,5,4]  R939      -7.5536054372787476e-01
    z[1,5,4]  R940      -6.1703097820281982e-01
    z[1,5,4]  R941      -6.2668442726135254e-01
    z[1,5,4]  R942      -1.8210516870021820e-01
    z[1,5,4]  R943      1.5481740236282349e-01
    z[1,5,4]  R944      -1.2296716123819351e-01
    z[1,5,4]  R945      -1.5764136612415314e-01
    z[1,5,4]  R946      -4.7570672631263733e-01
    z[1,5,4]  R947      -2.5523534417152405e-01
    z[1,5,4]  R948      -3.7932008504867554e-01
    z[1,5,4]  R949      1.1816792190074921e-01
    z[1,5,4]  R950      -2.0104572176933289e-01
    z[1,5,4]  R951      -1.3503420352935791e-01
    z[1,5,4]  R952      -2.5660410523414612e-01
    z[1,5,5]  R16       -1
    z[1,5,5]  R52       1
    z[1,5,5]  R889      -1
    z[1,5,5]  R890      1
    z[1,5,5]  R893      -5.3726172447204590e-01
    z[1,5,5]  R894      -0.626187801361084
    z[1,5,5]  R895      -1.6882559657096863e-01
    z[1,5,5]  R896      -3.3339250087738037e-01
    z[1,5,5]  R897      3.3609855920076370e-02
    z[1,5,5]  R898      -1.6285820305347443e-01
    z[1,5,5]  R899      2.5512970983982086e-02
    z[1,5,5]  R900      1.5018879203125834e-03
    z[1,5,5]  R901      -2.9831105470657349e-01
    z[1,5,5]  R902      1.9834114611148834e-01
    z[1,5,5]  R903      3.3949002623558044e-01
    z[1,5,5]  R904      -1.5337635576725006e-01
    z[1,5,5]  R905      -2.4938280880451202e-01
    z[1,5,5]  R906      5.6400257349014282e-01
    z[1,5,5]  R907      4.6394929289817810e-01
    z[1,5,5]  R908      4.4545814394950867e-01
    z[1,5,5]  R909      4.8621088266372681e-01
    z[1,5,5]  R910      -6.7275539040565491e-02
    z[1,5,5]  R911      5.4848223924636841e-01
    z[1,5,5]  R912      -4.6977987512946129e-03
    z[1,5,5]  R913      -4.5693108439445496e-01
    z[1,5,5]  R914      -4.5982575416564941e-01
    z[1,5,5]  R915      4.6194070577621460e-01
    z[1,5,5]  R916      5.6908661127090454e-01
    z[1,5,5]  R917      -4.7468963265419006e-01
    z[1,5,5]  R918      1.0996001958847046e-01
    z[1,5,5]  R919      3.1893891096115112e-01
    z[1,5,5]  R920      3.3318656682968140e-01
    z[1,5,5]  R921      1.6710844635963440e-01
    z[1,5,5]  R922      6.1378264427185059e-01
    z[1,5,5]  R923      -1.1131719499826431e-01
    z[1,5,5]  R924      0.0637318417429924
    z[1,5,5]  R925      -1.4617668092250824e-01
    z[1,5,5]  R926      -2.9570075869560242e-01
    z[1,5,5]  R927      7.7944099903106689e-02
    z[1,5,5]  R928      1.5966452658176422e-01
    z[1,5,5]  R929      -2.1649017930030823e-01
    z[1,5,5]  R930      5.2308106422424316e-01
    z[1,5,5]  R931      -6.2786924839019775e-01
    z[1,5,5]  R932      3.3755233883857727e-01
    z[1,5,5]  R933      1.5116794407367706e-01
    z[1,5,5]  R934      -2.2197867929935455e-01
    z[1,5,5]  R935      3.1002062559127808e-01
    z[1,5,5]  R936      3.1327721476554871e-01
    z[1,5,5]  R937      3.4476521611213684e-01
    z[1,5,5]  R938      -0.646431565284729
    z[1,5,5]  R939      -3.1328245997428894e-01
    z[1,5,5]  R940      3.7758263945579529e-01
    z[1,5,5]  R941      -1.5430963039398193e-01
    z[1,5,5]  R942      1.9245516508817673e-02
    z[1,5,5]  R943      -2.2110524773597717e-01
    z[1,5,5]  R944      -1.0460570454597473e-01
    z[1,5,5]  R945      1.8717718124389648e-01
    z[1,5,5]  R946      -9.5810495316982269e-02
    z[1,5,5]  R947      2.0536902546882629e-01
    z[1,5,5]  R948      3.1169801950454712e-01
    z[1,5,5]  R949      1.9130136817693710e-02
    z[1,5,5]  R950      0.602180004119873
    z[1,5,5]  R951      1.8971244990825653e-01
    z[1,5,5]  R952      -1.2897464632987976e-01
    z[1,5,6]  R17       -1
    z[1,5,6]  R53       1
    z[1,5,6]  R891      -1
    z[1,5,6]  R892      1
    z[1,5,6]  R893      -3.3465293049812317e-01
    z[1,5,6]  R894      -1.2145908921957016e-01
    z[1,5,6]  R895      -1.0455239564180374e-01
    z[1,5,6]  R896      1.8991325795650482e-01
    z[1,5,6]  R897      -2.7531927824020386e-01
    z[1,5,6]  R898      1.2007252871990204e-01
    z[1,5,6]  R899      1.3806284964084625e-01
    z[1,5,6]  R900      -1.4318844676017761e-01
    z[1,5,6]  R901      1.7317837476730347e-01
    z[1,5,6]  R902      -1.6367603838443756e-01
    z[1,5,6]  R903      -5.3965445607900620e-02
    z[1,5,6]  R904      6.6160291433334351e-01
    z[1,5,6]  R905      7.7898889780044556e-01
    z[1,5,6]  R906      2.2799883782863617e-01
    z[1,5,6]  R907      -4.8196563124656677e-01
    z[1,5,6]  R908      -4.0603697299957275e-01
    z[1,5,6]  R909      9.4417795538902283e-02
    z[1,5,6]  R910      -5.2158057689666748e-01
    z[1,5,6]  R911      4.4169902801513672e-01
    z[1,5,6]  R912      -2.6157552003860474e-01
    z[1,5,6]  R913      7.1805804967880249e-01
    z[1,5,6]  R914      -5.7507455348968506e-01
    z[1,5,6]  R915      3.8336464762687683e-01
    z[1,5,6]  R916      -1.7829042673110962e-01
    z[1,5,6]  R917      -8.7246164679527283e-02
    z[1,5,6]  R918      4.4387900829315186e-01
    z[1,5,6]  R919      2.8109195828437805e-01
    z[1,5,6]  R920      -3.9085072278976440e-01
    z[1,5,6]  R921      -6.4286071062088013e-01
    z[1,5,6]  R922      -1.3372294604778290e-01
    z[1,5,6]  R923      1.2127758562564850e-01
    z[1,5,6]  R924      5.6023085117340088e-01
    z[1,5,6]  R925      0.349653035402298
    z[1,5,6]  R926      0.806532084941864
    z[1,5,6]  R927      5.8506507426500320e-02
    z[1,5,6]  R928      -3.9483910799026489e-01
    z[1,5,6]  R929      -0.325979620218277
    z[1,5,6]  R930      -3.5950893163681030e-01
    z[1,5,6]  R931      -2.2523787617683411e-01
    z[1,5,6]  R932      -1.4223001897335052e-01
    z[1,5,6]  R933      -4.3978440761566162e-01
    z[1,5,6]  R934      9.6285246312618256e-02
    z[1,5,6]  R935      3.4382537007331848e-02
    z[1,5,6]  R936      4.7604967840015888e-03
    z[1,5,6]  R937      -1.4741019904613495e-01
    z[1,5,6]  R938      -2.7137833833694458e-01
    z[1,5,6]  R939      8.8009208440780640e-02
    z[1,5,6]  R940      3.8328343629837036e-01
    z[1,5,6]  R941      -4.8739233613014221e-01
    z[1,5,6]  R942      -3.0698752403259277e-01
    z[1,5,6]  R943      -4.0437772870063782e-01
    z[1,5,6]  R944      1.5249388292431831e-02
    z[1,5,6]  R945      -1.2720832228660583e-01
    z[1,5,6]  R946      -1.1395805329084396e-01
    z[1,5,6]  R947      -1.6189830377697945e-02
    z[1,5,6]  R948      1.4010933041572571e-01
    z[1,5,6]  R949      2.1948866546154022e-01
    z[1,5,6]  R950      2.5303825736045837e-01
    z[1,5,6]  R951      -1.8181873857975006e-01
    z[1,5,6]  R952      -1.3147367537021637e-01
    z[5,1,0]  R11       1
    z[5,1,0]  R47       -1
    z[5,1,0]  R953      -1
    z[5,1,0]  R954      1
    z[5,1,0]  R967      6.5863317251205444e-01
    z[5,1,0]  R968      3.5136952996253967e-01
    z[5,1,0]  R969      4.5002645254135132e-01
    z[5,1,0]  R970      -1.8709459900856018e-01
    z[5,1,0]  R971      -6.0926965670660138e-04
    z[5,1,0]  R972      5.3828325122594833e-02
    z[5,1,0]  R973      -5.7057225704193115e-01
    z[5,1,0]  R974      -9.6037723124027252e-02
    z[5,1,0]  R975      -4.0170863270759583e-01
    z[5,1,0]  R976      -4.4690504670143127e-01
    z[5,1,0]  R977      2.4390691518783569e-01
    z[5,1,0]  R978      -1.6205526888370514e-01
    z[5,1,0]  R979      -4.1034218668937683e-01
    z[5,1,0]  R980      -0.491395503282547
    z[5,1,0]  R981      -5.4686480760574341e-01
    z[5,1,0]  R982      7.1733094751834869e-02
    z[5,1,0]  R983      3.0037495493888855e-01
    z[5,1,0]  R984      1.6303683817386627e-01
    z[5,1,0]  R985      3.2199257612228394e-01
    z[5,1,0]  R986      5.4086589813232422e-01
    z[5,1,0]  R987      -9.2967316508293152e-02
    z[5,1,0]  R988      -8.6629527807235718e-01
    z[5,1,0]  R989      -8.9378046989440918e-01
    z[5,1,0]  R990      -6.3994240760803223e-01
    z[5,1,0]  R991      -7.6945525407791138e-01
    z[5,1,0]  R992      -6.9138383865356445e-01
    z[5,1,0]  R993      -3.5067155957221985e-01
    z[5,1,0]  R994      4.1472426056861877e-01
    z[5,1,0]  R995      4.9624881148338318e-01
    z[5,1,0]  R996      5.4533189535140991e-01
    z[5,1,0]  R997      6.1083510518074036e-02
    z[5,1,0]  R998      2.1380166709423065e-01
    z[5,1,0]  R999      -7.3983520269393921e-01
    z[5,1,0]  R1000     2.5135216116905212e-01
    z[5,1,0]  R1001     8.9019227027893066e-01
    z[5,1,0]  R1002     8.5609972476959229e-01
    z[5,1,0]  R1003     -4.3352678418159485e-02
    z[5,1,0]  R1004     -2.3973140120506287e-01
    z[5,1,0]  R1005     3.1451526284217834e-01
    z[5,1,0]  R1006     5.4635588079690933e-02
    z[5,1,0]  R1007     3.8354450464248657e-01
    z[5,1,0]  R1008     3.0896863341331482e-01
    z[5,1,0]  R1009     7.9854726791381836e-02
    z[5,1,0]  R1010     -2.5239627808332443e-02
    z[5,1,0]  R1011     2.7237203717231750e-01
    z[5,1,0]  R1012     -3.5902258753776550e-01
    z[5,1,0]  R1013     -2.9740709066390991e-01
    z[5,1,0]  R1014     -4.5330911874771118e-02
    z[5,1,0]  R1015     -3.8903504610061646e-01
    z[5,1,0]  R1016     -1.7127676308155060e-01
    z[5,1,0]  R1017     6.3217975199222565e-02
    z[5,1,0]  R1018     -1.8302571773529053e-01
    z[5,1,0]  R1019     -4.7933542728424072e-01
    z[5,1,0]  R1020     3.4628391265869141e-01
    z[5,1,0]  R1021     2.0839316770434380e-02
    z[5,1,0]  R1022     1.1791638284921646e-01
    z[5,1,0]  R1023     -5.6895387172698975e-01
    z[5,1,0]  R1024     1.9080510735511780e-01
    z[5,1,0]  R1025     -2.1374617516994476e-01
    z[5,1,0]  R1026     -0.562109112739563
    z[5,1,1]  R12       1
    z[5,1,1]  R48       -1
    z[5,1,1]  R955      -1
    z[5,1,1]  R956      1
    z[5,1,1]  R967      3.5655662417411804e-02
    z[5,1,1]  R968      -6.8967863917350769e-02
    z[5,1,1]  R969      3.3862382173538208e-02
    z[5,1,1]  R970      1.3009256124496460e-01
    z[5,1,1]  R971      7.6676271855831146e-02
    z[5,1,1]  R972      1.8855138123035431e-01
    z[5,1,1]  R973      1.0348648577928543e-01
    z[5,1,1]  R974      1.7468252778053284e-01
    z[5,1,1]  R975      4.8111043870449066e-03
    z[5,1,1]  R976      -5.5101740360260010e-01
    z[5,1,1]  R977      3.6529025435447693e-01
    z[5,1,1]  R978      5.0101137161254883e-01
    z[5,1,1]  R979      2.3997753858566284e-01
    z[5,1,1]  R980      6.4626473188400269e-01
    z[5,1,1]  R981      -2.7780082821846008e-01
    z[5,1,1]  R982      5.2693653106689453e-01
    z[5,1,1]  R983      2.0449882745742798e-01
    z[5,1,1]  R984      2.8308564424514771e-01
    z[5,1,1]  R985      1.5430007874965668e-01
    z[5,1,1]  R986      -6.8047416210174561e-01
    z[5,1,1]  R987      7.3471927642822266e-01
    z[5,1,1]  R988      -3.5882565379142761e-01
    z[5,1,1]  R989      -1.5928235650062561e-01
    z[5,1,1]  R990      7.7059499919414520e-02
    z[5,1,1]  R991      0.0466160774230957
    z[5,1,1]  R992      -2.1337196230888367e-01
    z[5,1,1]  R993      -2.3984816670417786e-01
    z[5,1,1]  R994      3.0023759603500366e-01
    z[5,1,1]  R995      -7.8539723157882690e-01
    z[5,1,1]  R996      -6.9796615839004517e-01
    z[5,1,1]  R997      5.9199923276901245e-01
    z[5,1,1]  R998      -1.7263798415660858e-01
    z[5,1,1]  R999      6.1789894104003906e-01
    z[5,1,1]  R1000     2.8438141942024231e-01
    z[5,1,1]  R1001     -3.3239364624023438e-01
    z[5,1,1]  R1002     -2.8496605157852173e-01
    z[5,1,1]  R1003     3.6099424958229065e-01
    z[5,1,1]  R1004     0.552646815776825
    z[5,1,1]  R1005     -8.3604240417480469e-01
    z[5,1,1]  R1006     4.0312197804450989e-01
    z[5,1,1]  R1007     7.0076704025268555e-01
    z[5,1,1]  R1008     5.3063219785690308e-01
    z[5,1,1]  R1009     -1.3068813085556030e-01
    z[5,1,1]  R1010     -7.0500189065933228e-01
    z[5,1,1]  R1011     -0.484901487827301
    z[5,1,1]  R1012     -7.5998403131961823e-02
    z[5,1,1]  R1013     5.8496486395597458e-02
    z[5,1,1]  R1014     -7.3956793546676636e-01
    z[5,1,1]  R1015     -1.9420027732849121e-02
    z[5,1,1]  R1016     -6.9828546047210693e-01
    z[5,1,1]  R1017     4.2234563827514648e-01
    z[5,1,1]  R1018     -2.5246351957321167e-01
    z[5,1,1]  R1019     2.1436658501625061e-01
    z[5,1,1]  R1020     -3.4335559606552124e-01
    z[5,1,1]  R1021     4.6609568595886230e-01
    z[5,1,1]  R1022     -5.4194486141204834e-01
    z[5,1,1]  R1023     4.5076854526996613e-02
    z[5,1,1]  R1024     -4.0479990839958191e-01
    z[5,1,1]  R1025     7.3992349207401276e-02
    z[5,1,1]  R1026     -5.0194181501865387e-02
    z[5,1,2]  R13       1
    z[5,1,2]  R49       -1
    z[5,1,2]  R957      -1
    z[5,1,2]  R958      1
    z[5,1,2]  R967      4.9690103530883789e-01
    z[5,1,2]  R968      5.6668418645858765e-01
    z[5,1,2]  R969      0.788059413433075
    z[5,1,2]  R970      4.3211534619331360e-01
    z[5,1,2]  R971      8.6823272705078125e-01
    z[5,1,2]  R972      5.7285249233245850e-01
    z[5,1,2]  R973      -5.4072532802820206e-02
    z[5,1,2]  R974      -7.0453107357025146e-02
    z[5,1,2]  R975      -2.5815838575363159e-01
    z[5,1,2]  R976      2.3707246780395508e-01
    z[5,1,2]  R977      -3.4773632884025574e-01
    z[5,1,2]  R978      -4.4258171319961548e-01
    z[5,1,2]  R979      -2.0929503440856934e-01
    z[5,1,2]  R980      0.0709293782711029
    z[5,1,2]  R981      -6.5322893857955933e-01
    z[5,1,2]  R982      -1.1875462532043457e-01
    z[5,1,2]  R983      -3.9269593358039856e-01
    z[5,1,2]  R984      -4.7192507982254028e-01
    z[5,1,2]  R985      -3.8370156288146973e-01
    z[5,1,2]  R986      -2.9528501629829407e-01
    z[5,1,2]  R987      1.4096125960350037e-01
    z[5,1,2]  R988      -1.0095614194869995e-01
    z[5,1,2]  R989      1.3848142325878143e-01
    z[5,1,2]  R990      -3.6666259169578552e-01
    z[5,1,2]  R991      -3.1680583953857422e-01
    z[5,1,2]  R992      -0.0551447868347168
    z[5,1,2]  R993      -4.8404029011726379e-01
    z[5,1,2]  R994      -3.7091752886772156e-01
    z[5,1,2]  R995      -1.7900729179382324e-01
    z[5,1,2]  R996      -1.5813142061233521e-01
    z[5,1,2]  R997      -2.7311458252370358e-03
    z[5,1,2]  R998      -4.7505609691143036e-02
    z[5,1,2]  R999      -1.6115337610244751e-01
    z[5,1,2]  R1000     -1.4312425628304482e-02
    z[5,1,2]  R1001     -7.1665213909000158e-05
    z[5,1,2]  R1002     1.2088888138532639e-01
    z[5,1,2]  R1003     -4.1242414154112339e-03
    z[5,1,2]  R1004     -2.9520472511649132e-02
    z[5,1,2]  R1005     -1.7982059717178345e-01
    z[5,1,2]  R1006     8.2160130143165588e-02
    z[5,1,2]  R1007     1.3549405336380005e-01
    z[5,1,2]  R1008     -6.9270215928554535e-02
    z[5,1,2]  R1009     -1.4978380501270294e-01
    z[5,1,2]  R1010     5.1258418709039688e-02
    z[5,1,2]  R1011     2.1003323793411255e-01
    z[5,1,2]  R1012     1.7651681602001190e-01
    z[5,1,2]  R1013     1.1088189668953419e-02
    z[5,1,2]  R1014     7.0806264877319336e-02
    z[5,1,2]  R1015     0.0782213807106018
    z[5,1,2]  R1016     1.3924143277108669e-02
    z[5,1,2]  R1017     -1.6303548216819763e-01
    z[5,1,2]  R1018     -2.1536026149988174e-02
    z[5,1,2]  R1019     -0.0760052353143692
    z[5,1,2]  R1020     2.0098702609539032e-01
    z[5,1,2]  R1021     -6.1345055699348450e-02
    z[5,1,2]  R1022     -1.3458553701639175e-02
    z[5,1,2]  R1023     3.7188690900802612e-01
    z[5,1,2]  R1024     1.6649918258190155e-01
    z[5,1,2]  R1025     6.5833173692226410e-02
    z[5,1,2]  R1026     4.1337138414382935e-01
    z[5,1,3]  R14       1
    z[5,1,3]  R50       -1
    z[5,1,3]  R959      -1
    z[5,1,3]  R960      1
    z[5,1,3]  R967      -5.0862443447113037e-01
    z[5,1,3]  R968      2.7938507497310638e-02
    z[5,1,3]  R969      -1.6678662598133087e-01
    z[5,1,3]  R970      1.1506868898868561e-01
    z[5,1,3]  R971      -1.8325862288475037e-01
    z[5,1,3]  R972      6.6361993551254272e-01
    z[5,1,3]  R973      0.674699068069458
    z[5,1,3]  R974      4.8612591624259949e-01
    z[5,1,3]  R975      4.2541259527206421e-01
    z[5,1,3]  R976      5.2751320600509644e-01
    z[5,1,3]  R977      -2.3076803982257843e-01
    z[5,1,3]  R978      -5.7352638244628906e-01
    z[5,1,3]  R979      -7.9003876447677612e-01
    z[5,1,3]  R980      -1.9347956776618958e-01
    z[5,1,3]  R981      1.0992675274610519e-01
    z[5,1,3]  R982      0.453823983669281
    z[5,1,3]  R983      -1.9309048354625702e-01
    z[5,1,3]  R984      1.9135428592562675e-02
    z[5,1,3]  R985      -2.6681306958198547e-01
    z[5,1,3]  R986      1.7161494493484497e-01
    z[5,1,3]  R987      4.4192460179328918e-01
    z[5,1,3]  R988      0.290324866771698
    z[5,1,3]  R989      2.8379639983177185e-01
    z[5,1,3]  R990      4.4903361797332764e-01
    z[5,1,3]  R991      4.4476497173309326e-01
    z[5,1,3]  R992      4.6124801039695740e-01
    z[5,1,3]  R993      7.2298157215118408e-01
    z[5,1,3]  R994      3.6498349905014038e-01
    z[5,1,3]  R995      0.132520392537117
    z[5,1,3]  R996      0.301140159368515
    z[5,1,3]  R997      4.5125576853752136e-01
    z[5,1,3]  R998      -6.9074326753616333e-01
    z[5,1,3]  R999      1.8896495923399925e-02
    z[5,1,3]  R1000     0.397897869348526
    z[5,1,3]  R1001     8.4381639957427979e-02
    z[5,1,3]  R1002     3.5591584444046021e-01
    z[5,1,3]  R1003     9.2086660861968994e-01
    z[5,1,3]  R1004     -3.1765013933181763e-01
    z[5,1,3]  R1005     1.0727182030677795e-01
    z[5,1,3]  R1006     3.9924341440200806e-01
    z[5,1,3]  R1007     -1.9374012947082520e-01
    z[5,1,3]  R1008     -2.3194399476051331e-01
    z[5,1,3]  R1009     -8.7596736848354340e-02
    z[5,1,3]  R1010     3.3047983050346375e-01
    z[5,1,3]  R1011     2.3281952738761902e-01
    z[5,1,3]  R1012     -5.7619011402130127e-01
    z[5,1,3]  R1013     -7.4140834808349609e-01
    z[5,1,3]  R1014     4.0285822749137878e-01
    z[5,1,3]  R1015     -2.5792804360389709e-01
    z[5,1,3]  R1016     3.4212014079093933e-01
    z[5,1,3]  R1017     2.5536033511161804e-01
    z[5,1,3]  R1018     -1.9580744206905365e-02
    z[5,1,3]  R1019     5.1058417558670044e-01
    z[5,1,3]  R1020     5.7484978437423706e-01
    z[5,1,3]  R1021     -2.0147246122360229e-01
    z[5,1,3]  R1022     6.7178118228912354e-01
    z[5,1,3]  R1023     -5.1815766096115112e-01
    z[5,1,3]  R1024     6.8073445558547974e-01
    z[5,1,3]  R1025     -6.5127015113830566e-01
    z[5,1,3]  R1026     -2.6127964258193970e-01
    z[5,1,4]  R15       1
    z[5,1,4]  R51       -1
    z[5,1,4]  R961      -1
    z[5,1,4]  R962      1
    z[5,1,4]  R967      1.7950442433357239e-01
    z[5,1,4]  R968      0.481612890958786
    z[5,1,4]  R969      -6.2043469399213791e-02
    z[5,1,4]  R970      1.0086730867624283e-01
    z[5,1,4]  R971      -4.4408363103866577e-01
    z[5,1,4]  R972      -1.0774364322423935e-01
    z[5,1,4]  R973      2.2905133664608002e-01
    z[5,1,4]  R974      5.6224584579467773e-01
    z[5,1,4]  R975      -3.8214331865310669e-01
    z[5,1,4]  R976      -1.6736510396003723e-01
    z[5,1,4]  R977      6.4547348022460938e-01
    z[5,1,4]  R978      3.7332189083099365e-01
    z[5,1,4]  R979      9.3645811080932617e-02
    z[5,1,4]  R980      4.4748380780220032e-01
    z[5,1,4]  R981      -2.1066750586032867e-01
    z[5,1,4]  R982      -7.4922956526279449e-02
    z[5,1,4]  R983      -7.5536054372787476e-01
    z[5,1,4]  R984      -6.1703097820281982e-01
    z[5,1,4]  R985      -6.2668442726135254e-01
    z[5,1,4]  R986      -1.8210516870021820e-01
    z[5,1,4]  R987      1.5481740236282349e-01
    z[5,1,4]  R988      -1.2296716123819351e-01
    z[5,1,4]  R989      -1.5764136612415314e-01
    z[5,1,4]  R990      -4.7570672631263733e-01
    z[5,1,4]  R991      -2.5523534417152405e-01
    z[5,1,4]  R992      -3.7932008504867554e-01
    z[5,1,4]  R993      1.1816792190074921e-01
    z[5,1,4]  R994      -2.0104572176933289e-01
    z[5,1,4]  R995      -1.3503420352935791e-01
    z[5,1,4]  R996      -2.5660410523414612e-01
    z[5,1,4]  R997      -2.0377385616302490e-01
    z[5,1,4]  R998      -1.9554647803306580e-01
    z[5,1,4]  R999      -7.1302741765975952e-02
    z[5,1,4]  R1000     -7.4175751209259033e-01
    z[5,1,4]  R1001     -1.1411214619874954e-01
    z[5,1,4]  R1002     -0.0604756623506546
    z[5,1,4]  R1003     0.00889661442488432
    z[5,1,4]  R1004     -7.1751803159713745e-01
    z[5,1,4]  R1005     -1.9821767508983612e-01
    z[5,1,4]  R1006     -7.7603662014007568e-01
    z[5,1,4]  R1007     4.3331223726272583e-01
    z[5,1,4]  R1008     3.2113659381866455e-01
    z[5,1,4]  R1009     5.2670681476593018e-01
    z[5,1,4]  R1010     -1.4285834133625031e-01
    z[5,1,4]  R1011     -3.8055914640426636e-01
    z[5,1,4]  R1012     3.7265902757644653e-01
    z[5,1,4]  R1013     3.3615803718566895e-01
    z[5,1,4]  R1014     -0.0842844620347023
    z[5,1,4]  R1015     5.2886521816253662e-01
    z[5,1,4]  R1016     -5.4532349109649658e-01
    z[5,1,4]  R1017     3.8011528551578522e-02
    z[5,1,4]  R1018     5.9980505704879761e-01
    z[5,1,4]  R1019     -3.1217586994171143e-01
    z[5,1,4]  R1020     -1.8894271552562714e-01
    z[5,1,4]  R1021     7.1065044403076172e-01
    z[5,1,4]  R1022     -1.7832717299461365e-01
    z[5,1,4]  R1023     2.9451239109039307e-01
    z[5,1,4]  R1024     2.1173436939716339e-01
    z[5,1,4]  R1025     2.8134658932685852e-01
    z[5,1,4]  R1026     2.1854051947593689e-01
    z[5,1,5]  R16       1
    z[5,1,5]  R52       -1
    z[5,1,5]  R963      -1
    z[5,1,5]  R964      1
    z[5,1,5]  R967      -1.1131719499826431e-01
    z[5,1,5]  R968      0.0637318417429924
    z[5,1,5]  R969      -1.4617668092250824e-01
    z[5,1,5]  R970      -2.9570075869560242e-01
    z[5,1,5]  R971      7.7944099903106689e-02
    z[5,1,5]  R972      1.5966452658176422e-01
    z[5,1,5]  R973      -2.1649017930030823e-01
    z[5,1,5]  R974      5.2308106422424316e-01
    z[5,1,5]  R975      -6.2786924839019775e-01
    z[5,1,5]  R976      3.3755233883857727e-01
    z[5,1,5]  R977      1.5116794407367706e-01
    z[5,1,5]  R978      -2.2197867929935455e-01
    z[5,1,5]  R979      3.1002062559127808e-01
    z[5,1,5]  R980      3.1327721476554871e-01
    z[5,1,5]  R981      3.4476521611213684e-01
    z[5,1,5]  R982      -0.646431565284729
    z[5,1,5]  R983      -3.1328245997428894e-01
    z[5,1,5]  R984      3.7758263945579529e-01
    z[5,1,5]  R985      -1.5430963039398193e-01
    z[5,1,5]  R986      1.9245516508817673e-02
    z[5,1,5]  R987      -2.2110524773597717e-01
    z[5,1,5]  R988      -1.0460570454597473e-01
    z[5,1,5]  R989      1.8717718124389648e-01
    z[5,1,5]  R990      -9.5810495316982269e-02
    z[5,1,5]  R991      2.0536902546882629e-01
    z[5,1,5]  R992      3.1169801950454712e-01
    z[5,1,5]  R993      1.9130136817693710e-02
    z[5,1,5]  R994      0.602180004119873
    z[5,1,5]  R995      1.8971244990825653e-01
    z[5,1,5]  R996      -1.2897464632987976e-01
    z[5,1,5]  R997      -5.3726172447204590e-01
    z[5,1,5]  R998      -0.626187801361084
    z[5,1,5]  R999      -1.6882559657096863e-01
    z[5,1,5]  R1000     -3.3339250087738037e-01
    z[5,1,5]  R1001     3.3609855920076370e-02
    z[5,1,5]  R1002     -1.6285820305347443e-01
    z[5,1,5]  R1003     2.5512970983982086e-02
    z[5,1,5]  R1004     1.5018879203125834e-03
    z[5,1,5]  R1005     -2.9831105470657349e-01
    z[5,1,5]  R1006     1.9834114611148834e-01
    z[5,1,5]  R1007     3.3949002623558044e-01
    z[5,1,5]  R1008     -1.5337635576725006e-01
    z[5,1,5]  R1009     -2.4938280880451202e-01
    z[5,1,5]  R1010     5.6400257349014282e-01
    z[5,1,5]  R1011     4.6394929289817810e-01
    z[5,1,5]  R1012     4.4545814394950867e-01
    z[5,1,5]  R1013     4.8621088266372681e-01
    z[5,1,5]  R1014     -6.7275539040565491e-02
    z[5,1,5]  R1015     5.4848223924636841e-01
    z[5,1,5]  R1016     -4.6977987512946129e-03
    z[5,1,5]  R1017     -4.5693108439445496e-01
    z[5,1,5]  R1018     -4.5982575416564941e-01
    z[5,1,5]  R1019     4.6194070577621460e-01
    z[5,1,5]  R1020     5.6908661127090454e-01
    z[5,1,5]  R1021     -4.7468963265419006e-01
    z[5,1,5]  R1022     1.0996001958847046e-01
    z[5,1,5]  R1023     3.1893891096115112e-01
    z[5,1,5]  R1024     3.3318656682968140e-01
    z[5,1,5]  R1025     1.6710844635963440e-01
    z[5,1,5]  R1026     6.1378264427185059e-01
    z[5,1,6]  R17       1
    z[5,1,6]  R53       -1
    z[5,1,6]  R965      -1
    z[5,1,6]  R966      1
    z[5,1,6]  R967      1.2127758562564850e-01
    z[5,1,6]  R968      5.6023085117340088e-01
    z[5,1,6]  R969      0.349653035402298
    z[5,1,6]  R970      0.806532084941864
    z[5,1,6]  R971      5.8506507426500320e-02
    z[5,1,6]  R972      -3.9483910799026489e-01
    z[5,1,6]  R973      -0.325979620218277
    z[5,1,6]  R974      -3.5950893163681030e-01
    z[5,1,6]  R975      -2.2523787617683411e-01
    z[5,1,6]  R976      -1.4223001897335052e-01
    z[5,1,6]  R977      -4.3978440761566162e-01
    z[5,1,6]  R978      9.6285246312618256e-02
    z[5,1,6]  R979      3.4382537007331848e-02
    z[5,1,6]  R980      4.7604967840015888e-03
    z[5,1,6]  R981      -1.4741019904613495e-01
    z[5,1,6]  R982      -2.7137833833694458e-01
    z[5,1,6]  R983      8.8009208440780640e-02
    z[5,1,6]  R984      3.8328343629837036e-01
    z[5,1,6]  R985      -4.8739233613014221e-01
    z[5,1,6]  R986      -3.0698752403259277e-01
    z[5,1,6]  R987      -4.0437772870063782e-01
    z[5,1,6]  R988      1.5249388292431831e-02
    z[5,1,6]  R989      -1.2720832228660583e-01
    z[5,1,6]  R990      -1.1395805329084396e-01
    z[5,1,6]  R991      -1.6189830377697945e-02
    z[5,1,6]  R992      1.4010933041572571e-01
    z[5,1,6]  R993      2.1948866546154022e-01
    z[5,1,6]  R994      2.5303825736045837e-01
    z[5,1,6]  R995      -1.8181873857975006e-01
    z[5,1,6]  R996      -1.3147367537021637e-01
    z[5,1,6]  R997      -3.3465293049812317e-01
    z[5,1,6]  R998      -1.2145908921957016e-01
    z[5,1,6]  R999      -1.0455239564180374e-01
    z[5,1,6]  R1000     1.8991325795650482e-01
    z[5,1,6]  R1001     -2.7531927824020386e-01
    z[5,1,6]  R1002     1.2007252871990204e-01
    z[5,1,6]  R1003     1.3806284964084625e-01
    z[5,1,6]  R1004     -1.4318844676017761e-01
    z[5,1,6]  R1005     1.7317837476730347e-01
    z[5,1,6]  R1006     -1.6367603838443756e-01
    z[5,1,6]  R1007     -5.3965445607900620e-02
    z[5,1,6]  R1008     6.6160291433334351e-01
    z[5,1,6]  R1009     7.7898889780044556e-01
    z[5,1,6]  R1010     2.2799883782863617e-01
    z[5,1,6]  R1011     -4.8196563124656677e-01
    z[5,1,6]  R1012     -4.0603697299957275e-01
    z[5,1,6]  R1013     9.4417795538902283e-02
    z[5,1,6]  R1014     -5.2158057689666748e-01
    z[5,1,6]  R1015     4.4169902801513672e-01
    z[5,1,6]  R1016     -2.6157552003860474e-01
    z[5,1,6]  R1017     7.1805804967880249e-01
    z[5,1,6]  R1018     -5.7507455348968506e-01
    z[5,1,6]  R1019     3.8336464762687683e-01
    z[5,1,6]  R1020     -1.7829042673110962e-01
    z[5,1,6]  R1021     -8.7246164679527283e-02
    z[5,1,6]  R1022     4.4387900829315186e-01
    z[5,1,6]  R1023     2.8109195828437805e-01
    z[5,1,6]  R1024     -3.9085072278976440e-01
    z[5,1,6]  R1025     -6.4286071062088013e-01
    z[5,1,6]  R1026     -1.3372294604778290e-01
    z[1,6,0]  R11       -1
    z[1,6,0]  R56       1
    z[1,6,0]  R1027     -1
    z[1,6,0]  R1028     1
    z[1,6,0]  R1041     6.1083510518074036e-02
    z[1,6,0]  R1042     2.1380166709423065e-01
    z[1,6,0]  R1043     -7.3983520269393921e-01
    z[1,6,0]  R1044     2.5135216116905212e-01
    z[1,6,0]  R1045     8.9019227027893066e-01
    z[1,6,0]  R1046     8.5609972476959229e-01
    z[1,6,0]  R1047     -4.3352678418159485e-02
    z[1,6,0]  R1048     -2.3973140120506287e-01
    z[1,6,0]  R1049     3.1451526284217834e-01
    z[1,6,0]  R1050     5.4635588079690933e-02
    z[1,6,0]  R1051     3.8354450464248657e-01
    z[1,6,0]  R1052     3.0896863341331482e-01
    z[1,6,0]  R1053     7.9854726791381836e-02
    z[1,6,0]  R1054     -2.5239627808332443e-02
    z[1,6,0]  R1055     2.7237203717231750e-01
    z[1,6,0]  R1056     -3.5902258753776550e-01
    z[1,6,0]  R1057     -2.9740709066390991e-01
    z[1,6,0]  R1058     -4.5330911874771118e-02
    z[1,6,0]  R1059     -3.8903504610061646e-01
    z[1,6,0]  R1060     -1.7127676308155060e-01
    z[1,6,0]  R1061     6.3217975199222565e-02
    z[1,6,0]  R1062     -1.8302571773529053e-01
    z[1,6,0]  R1063     -4.7933542728424072e-01
    z[1,6,0]  R1064     3.4628391265869141e-01
    z[1,6,0]  R1065     2.0839316770434380e-02
    z[1,6,0]  R1066     1.1791638284921646e-01
    z[1,6,0]  R1067     -5.6895387172698975e-01
    z[1,6,0]  R1068     1.9080510735511780e-01
    z[1,6,0]  R1069     -2.1374617516994476e-01
    z[1,6,0]  R1070     -0.562109112739563
    z[1,6,0]  R1071     -2.4306967854499817e-01
    z[1,6,0]  R1072     2.2307108342647552e-01
    z[1,6,0]  R1073     3.4439027309417725e-01
    z[1,6,0]  R1074     -1.1825361847877502e-01
    z[1,6,0]  R1075     -3.4254449605941772e-01
    z[1,6,0]  R1076     -2.2716903686523438e-01
    z[1,6,0]  R1077     1.6046869754791260e-01
    z[1,6,0]  R1078     2.3380806669592857e-03
    z[1,6,0]  R1079     5.3210145235061646e-01
    z[1,6,0]  R1080     -0.767795979976654
    z[1,6,0]  R1081     -1.9495630264282227e-01
    z[1,6,0]  R1082     1.4105166494846344e-01
    z[1,6,0]  R1083     4.1521412134170532e-01
    z[1,6,0]  R1084     -3.4050655364990234e-01
    z[1,6,0]  R1085     -1.2337133288383484e-01
    z[1,6,0]  R1086     -8.0893546342849731e-02
    z[1,6,0]  R1087     -0.316019743680954
    z[1,6,0]  R1088     -6.1593884229660034e-01
    z[1,6,0]  R1089     3.3860269188880920e-01
    z[1,6,0]  R1090     1.6142678260803223e-01
    z[1,6,1]  R12       -1
    z[1,6,1]  R57       1
    z[1,6,1]  R1029     -1
    z[1,6,1]  R1030     1
    z[1,6,1]  R1041     5.9199923276901245e-01
    z[1,6,1]  R1042     -1.7263798415660858e-01
    z[1,6,1]  R1043     6.1789894104003906e-01
    z[1,6,1]  R1044     2.8438141942024231e-01
    z[1,6,1]  R1045     -3.3239364624023438e-01
    z[1,6,1]  R1046     -2.8496605157852173e-01
    z[1,6,1]  R1047     3.6099424958229065e-01
    z[1,6,1]  R1048     0.552646815776825
    z[1,6,1]  R1049     -8.3604240417480469e-01
    z[1,6,1]  R1050     4.0312197804450989e-01
    z[1,6,1]  R1051     7.0076704025268555e-01
    z[1,6,1]  R1052     5.3063219785690308e-01
    z[1,6,1]  R1053     -1.3068813085556030e-01
    z[1,6,1]  R1054     -7.0500189065933228e-01
    z[1,6,1]  R1055     -0.484901487827301
    z[1,6,1]  R1056     -7.5998403131961823e-02
    z[1,6,1]  R1057     5.8496486395597458e-02
    z[1,6,1]  R1058     -7.3956793546676636e-01
    z[1,6,1]  R1059     -1.9420027732849121e-02
    z[1,6,1]  R1060     -6.9828546047210693e-01
    z[1,6,1]  R1061     4.2234563827514648e-01
    z[1,6,1]  R1062     -2.5246351957321167e-01
    z[1,6,1]  R1063     2.1436658501625061e-01
    z[1,6,1]  R1064     -3.4335559606552124e-01
    z[1,6,1]  R1065     4.6609568595886230e-01
    z[1,6,1]  R1066     -5.4194486141204834e-01
    z[1,6,1]  R1067     4.5076854526996613e-02
    z[1,6,1]  R1068     -4.0479990839958191e-01
    z[1,6,1]  R1069     7.3992349207401276e-02
    z[1,6,1]  R1070     -5.0194181501865387e-02
    z[1,6,1]  R1071     5.9484001249074936e-02
    z[1,6,1]  R1072     0.0543687604367733
    z[1,6,1]  R1073     6.3366413116455078e-02
    z[1,6,1]  R1074     4.9888465553522110e-02
    z[1,6,1]  R1075     2.9684877954423428e-03
    z[1,6,1]  R1076     8.2638889551162720e-02
    z[1,6,1]  R1077     -3.6709473934024572e-03
    z[1,6,1]  R1078     -8.7194317579269409e-01
    z[1,6,1]  R1079     -4.8741912841796875e-01
    z[1,6,1]  R1080     -1.3693065941333771e-01
    z[1,6,1]  R1081     -2.3118425905704498e-01
    z[1,6,1]  R1082     0.755187451839447
    z[1,6,1]  R1083     7.3013103008270264e-01
    z[1,6,1]  R1084     6.6247063875198364e-01
    z[1,6,1]  R1085     4.9459806084632874e-01
    z[1,6,1]  R1086     4.6404811739921570e-01
    z[1,6,1]  R1087     3.1120446324348450e-01
    z[1,6,1]  R1088     3.3675163984298706e-01
    z[1,6,1]  R1089     -8.5062372684478760e-01
    z[1,6,1]  R1090     -8.1816995143890381e-01
    z[1,6,2]  R13       -1
    z[1,6,2]  R58       1
    z[1,6,2]  R1031     -1
    z[1,6,2]  R1032     1
    z[1,6,2]  R1041     -2.7311458252370358e-03
    z[1,6,2]  R1042     -4.7505609691143036e-02
    z[1,6,2]  R1043     -1.6115337610244751e-01
    z[1,6,2]  R1044     -1.4312425628304482e-02
    z[1,6,2]  R1045     -7.1665213909000158e-05
    z[1,6,2]  R1046     1.2088888138532639e-01
    z[1,6,2]  R1047     -4.1242414154112339e-03
    z[1,6,2]  R1048     -2.9520472511649132e-02
    z[1,6,2]  R1049     -1.7982059717178345e-01
    z[1,6,2]  R1050     8.2160130143165588e-02
    z[1,6,2]  R1051     1.3549405336380005e-01
    z[1,6,2]  R1052     -6.9270215928554535e-02
    z[1,6,2]  R1053     -1.4978380501270294e-01
    z[1,6,2]  R1054     5.1258418709039688e-02
    z[1,6,2]  R1055     2.1003323793411255e-01
    z[1,6,2]  R1056     1.7651681602001190e-01
    z[1,6,2]  R1057     1.1088189668953419e-02
    z[1,6,2]  R1058     7.0806264877319336e-02
    z[1,6,2]  R1059     0.0782213807106018
    z[1,6,2]  R1060     1.3924143277108669e-02
    z[1,6,2]  R1061     -1.6303548216819763e-01
    z[1,6,2]  R1062     -2.1536026149988174e-02
    z[1,6,2]  R1063     -0.0760052353143692
    z[1,6,2]  R1064     2.0098702609539032e-01
    z[1,6,2]  R1065     -6.1345055699348450e-02
    z[1,6,2]  R1066     -1.3458553701639175e-02
    z[1,6,2]  R1067     3.7188690900802612e-01
    z[1,6,2]  R1068     1.6649918258190155e-01
    z[1,6,2]  R1069     6.5833173692226410e-02
    z[1,6,2]  R1070     4.1337138414382935e-01
    z[1,6,2]  R1071     9.0363526344299316e-01
    z[1,6,2]  R1072     6.0082674026489258e-01
    z[1,6,2]  R1073     8.2879191637039185e-01
    z[1,6,2]  R1074     0.734775722026825
    z[1,6,2]  R1075     6.4357602596282959e-01
    z[1,6,2]  R1076     1.3082157075405121e-01
    z[1,6,2]  R1077     4.5716318488121033e-01
    z[1,6,2]  R1078     -1.2676886282861233e-02
    z[1,6,2]  R1079     3.1302943825721741e-02
    z[1,6,2]  R1080     -2.5597837567329407e-01
    z[1,6,2]  R1081     -4.6411642432212830e-01
    z[1,6,2]  R1082     -4.1137015819549561e-01
    z[1,6,2]  R1083     -4.1148072481155396e-01
    z[1,6,2]  R1084     -2.4406099319458008e-01
    z[1,6,2]  R1085     -8.6108408868312836e-02
    z[1,6,2]  R1086     2.5306552648544312e-01
    z[1,6,2]  R1087     1.0281375050544739e-01
    z[1,6,2]  R1088     -2.5616028904914856e-01
    z[1,6,2]  R1089     -9.8373480141162872e-02
    z[1,6,2]  R1090     -3.8059923052787781e-01
    z[1,6,3]  R14       -1
    z[1,6,3]  R59       1
    z[1,6,3]  R1033     -1
    z[1,6,3]  R1034     1
    z[1,6,3]  R1041     4.5125576853752136e-01
    z[1,6,3]  R1042     -6.9074326753616333e-01
    z[1,6,3]  R1043     1.8896495923399925e-02
    z[1,6,3]  R1044     0.397897869348526
    z[1,6,3]  R1045     8.4381639957427979e-02
    z[1,6,3]  R1046     3.5591584444046021e-01
    z[1,6,3]  R1047     9.2086660861968994e-01
    z[1,6,3]  R1048     -3.1765013933181763e-01
    z[1,6,3]  R1049     1.0727182030677795e-01
    z[1,6,3]  R1050     3.9924341440200806e-01
    z[1,6,3]  R1051     -1.9374012947082520e-01
    z[1,6,3]  R1052     -2.3194399476051331e-01
    z[1,6,3]  R1053     -8.7596736848354340e-02
    z[1,6,3]  R1054     3.3047983050346375e-01
    z[1,6,3]  R1055     2.3281952738761902e-01
    z[1,6,3]  R1056     -5.7619011402130127e-01
    z[1,6,3]  R1057     -7.4140834808349609e-01
    z[1,6,3]  R1058     4.0285822749137878e-01
    z[1,6,3]  R1059     -2.5792804360389709e-01
    z[1,6,3]  R1060     3.4212014079093933e-01
    z[1,6,3]  R1061     2.5536033511161804e-01
    z[1,6,3]  R1062     -1.9580744206905365e-02
    z[1,6,3]  R1063     5.1058417558670044e-01
    z[1,6,3]  R1064     5.7484978437423706e-01
    z[1,6,3]  R1065     -2.0147246122360229e-01
    z[1,6,3]  R1066     6.7178118228912354e-01
    z[1,6,3]  R1067     -5.1815766096115112e-01
    z[1,6,3]  R1068     6.8073445558547974e-01
    z[1,6,3]  R1069     -6.5127015113830566e-01
    z[1,6,3]  R1070     -2.6127964258193970e-01
    z[1,6,3]  R1071     -1.7220060527324677e-01
    z[1,6,3]  R1072     -4.9672982096672058e-01
    z[1,6,3]  R1073     -4.0433195233345032e-01
    z[1,6,3]  R1074     -0.330777645111084
    z[1,6,3]  R1075     -6.6862158477306366e-02
    z[1,6,3]  R1076     -8.7391048669815063e-01
    z[1,6,3]  R1077     4.3200913071632385e-01
    z[1,6,3]  R1078     0.178828626871109
    z[1,6,3]  R1079     3.6172637343406677e-01
    z[1,6,3]  R1080     -5.7961666025221348e-03
    z[1,6,3]  R1081     -1.2184821814298630e-01
    z[1,6,3]  R1082     -4.7170307487249374e-02
    z[1,6,3]  R1083     -3.9499200880527496e-02
    z[1,6,3]  R1084     2.5259786844253540e-01
    z[1,6,3]  R1085     6.0434317588806152e-01
    z[1,6,3]  R1086     5.1674425601959229e-01
    z[1,6,3]  R1087     9.4966374337673187e-02
    z[1,6,3]  R1088     9.8139166831970215e-02
    z[1,6,3]  R1089     3.6098104715347290e-01
    z[1,6,3]  R1090     -1.4106282033026218e-02
    z[1,6,4]  R15       -1
    z[1,6,4]  R60       1
    z[1,6,4]  R1035     -1
    z[1,6,4]  R1036     1
    z[1,6,4]  R1041     -2.0377385616302490e-01
    z[1,6,4]  R1042     -1.9554647803306580e-01
    z[1,6,4]  R1043     -7.1302741765975952e-02
    z[1,6,4]  R1044     -7.4175751209259033e-01
    z[1,6,4]  R1045     -1.1411214619874954e-01
    z[1,6,4]  R1046     -0.0604756623506546
    z[1,6,4]  R1047     0.00889661442488432
    z[1,6,4]  R1048     -7.1751803159713745e-01
    z[1,6,4]  R1049     -1.9821767508983612e-01
    z[1,6,4]  R1050     -7.7603662014007568e-01
    z[1,6,4]  R1051     4.3331223726272583e-01
    z[1,6,4]  R1052     3.2113659381866455e-01
    z[1,6,4]  R1053     5.2670681476593018e-01
    z[1,6,4]  R1054     -1.4285834133625031e-01
    z[1,6,4]  R1055     -3.8055914640426636e-01
    z[1,6,4]  R1056     3.7265902757644653e-01
    z[1,6,4]  R1057     3.3615803718566895e-01
    z[1,6,4]  R1058     -0.0842844620347023
    z[1,6,4]  R1059     5.2886521816253662e-01
    z[1,6,4]  R1060     -5.4532349109649658e-01
    z[1,6,4]  R1061     3.8011528551578522e-02
    z[1,6,4]  R1062     5.9980505704879761e-01
    z[1,6,4]  R1063     -3.1217586994171143e-01
    z[1,6,4]  R1064     -1.8894271552562714e-01
    z[1,6,4]  R1065     7.1065044403076172e-01
    z[1,6,4]  R1066     -1.7832717299461365e-01
    z[1,6,4]  R1067     2.9451239109039307e-01
    z[1,6,4]  R1068     2.1173436939716339e-01
    z[1,6,4]  R1069     2.8134658932685852e-01
    z[1,6,4]  R1070     2.1854051947593689e-01
    z[1,6,4]  R1071     2.1855711936950684e-01
    z[1,6,4]  R1072     3.6860066652297974e-01
    z[1,6,4]  R1073     1.1693480610847473e-01
    z[1,6,4]  R1074     2.8102025389671326e-01
    z[1,6,4]  R1075     5.4940587282180786e-01
    z[1,6,4]  R1076     9.3946486711502075e-02
    z[1,6,4]  R1077     4.8800927400588989e-01
    z[1,6,4]  R1078     -3.2916495203971863e-01
    z[1,6,4]  R1079     -4.6568018198013306e-01
    z[1,6,4]  R1080     -1.6710628569126129e-01
    z[1,6,4]  R1081     1.5868784487247467e-01
    z[1,6,4]  R1082     0.306011825799942
    z[1,6,4]  R1083     -2.2578364610671997e-01
    z[1,6,4]  R1084     -3.1393823027610779e-01
    z[1,6,4]  R1085     -3.7847158312797546e-01
    z[1,6,4]  R1086     -4.5780256390571594e-01
    z[1,6,4]  R1087     -8.1053566932678223e-01
    z[1,6,4]  R1088     -5.7097882032394409e-01
    z[1,6,4]  R1089     -1.1380314081907272e-01
    z[1,6,4]  R1090     -1.3239854574203491e-01
    z[1,6,5]  R16       -1
    z[1,6,5]  R61       1
    z[1,6,5]  R1037     -1
    z[1,6,5]  R1038     1
    z[1,6,5]  R1041     -5.3726172447204590e-01
    z[1,6,5]  R1042     -0.626187801361084
    z[1,6,5]  R1043     -1.6882559657096863e-01
    z[1,6,5]  R1044     -3.3339250087738037e-01
    z[1,6,5]  R1045     3.3609855920076370e-02
    z[1,6,5]  R1046     -1.6285820305347443e-01
    z[1,6,5]  R1047     2.5512970983982086e-02
    z[1,6,5]  R1048     1.5018879203125834e-03
    z[1,6,5]  R1049     -2.9831105470657349e-01
    z[1,6,5]  R1050     1.9834114611148834e-01
    z[1,6,5]  R1051     3.3949002623558044e-01
    z[1,6,5]  R1052     -1.5337635576725006e-01
    z[1,6,5]  R1053     -2.4938280880451202e-01
    z[1,6,5]  R1054     5.6400257349014282e-01
    z[1,6,5]  R1055     4.6394929289817810e-01
    z[1,6,5]  R1056     4.4545814394950867e-01
    z[1,6,5]  R1057     4.8621088266372681e-01
    z[1,6,5]  R1058     -6.7275539040565491e-02
    z[1,6,5]  R1059     5.4848223924636841e-01
    z[1,6,5]  R1060     -4.6977987512946129e-03
    z[1,6,5]  R1061     -4.5693108439445496e-01
    z[1,6,5]  R1062     -4.5982575416564941e-01
    z[1,6,5]  R1063     4.6194070577621460e-01
    z[1,6,5]  R1064     5.6908661127090454e-01
    z[1,6,5]  R1065     -4.7468963265419006e-01
    z[1,6,5]  R1066     1.0996001958847046e-01
    z[1,6,5]  R1067     3.1893891096115112e-01
    z[1,6,5]  R1068     3.3318656682968140e-01
    z[1,6,5]  R1069     1.6710844635963440e-01
    z[1,6,5]  R1070     6.1378264427185059e-01
    z[1,6,5]  R1071     -1.3518853485584259e-01
    z[1,6,5]  R1072     -2.8702250123023987e-01
    z[1,6,5]  R1073     8.6273632943630219e-02
    z[1,6,5]  R1074     -4.5111864805221558e-01
    z[1,6,5]  R1075     4.0043982863426208e-01
    z[1,6,5]  R1076     -2.8760471940040588e-01
    z[1,6,5]  R1077     1.2319029122591019e-01
    z[1,6,5]  R1078     -1.3998635113239288e-01
    z[1,6,5]  R1079     7.2343222796916962e-02
    z[1,6,5]  R1080     -5.0539571791887283e-02
    z[1,6,5]  R1081     -7.9557329416275024e-01
    z[1,6,5]  R1082     -9.9694781005382538e-02
    z[1,6,5]  R1083     0.257186621427536
    z[1,6,5]  R1084     -8.3370454609394073e-02
    z[1,6,5]  R1085     -3.2267215847969055e-01
    z[1,6,5]  R1086     1.8452392518520355e-01
    z[1,6,5]  R1087     3.5069581866264343e-01
    z[1,6,5]  R1088     7.1079894900321960e-02
    z[1,6,5]  R1089     8.4961839020252228e-02
    z[1,6,5]  R1090     3.3967030048370361e-01
    z[1,6,6]  R17       -1
    z[1,6,6]  R62       1
    z[1,6,6]  R1039     -1
    z[1,6,6]  R1040     1
    z[1,6,6]  R1041     -3.3465293049812317e-01
    z[1,6,6]  R1042     -1.2145908921957016e-01
    z[1,6,6]  R1043     -1.0455239564180374e-01
    z[1,6,6]  R1044     1.8991325795650482e-01
    z[1,6,6]  R1045     -2.7531927824020386e-01
    z[1,6,6]  R1046     1.2007252871990204e-01
    z[1,6,6]  R1047     1.3806284964084625e-01
    z[1,6,6]  R1048     -1.4318844676017761e-01
    z[1,6,6]  R1049     1.7317837476730347e-01
    z[1,6,6]  R1050     -1.6367603838443756e-01
    z[1,6,6]  R1051     -5.3965445607900620e-02
    z[1,6,6]  R1052     6.6160291433334351e-01
    z[1,6,6]  R1053     7.7898889780044556e-01
    z[1,6,6]  R1054     2.2799883782863617e-01
    z[1,6,6]  R1055     -4.8196563124656677e-01
    z[1,6,6]  R1056     -4.0603697299957275e-01
    z[1,6,6]  R1057     9.4417795538902283e-02
    z[1,6,6]  R1058     -5.2158057689666748e-01
    z[1,6,6]  R1059     4.4169902801513672e-01
    z[1,6,6]  R1060     -2.6157552003860474e-01
    z[1,6,6]  R1061     7.1805804967880249e-01
    z[1,6,6]  R1062     -5.7507455348968506e-01
    z[1,6,6]  R1063     3.8336464762687683e-01
    z[1,6,6]  R1064     -1.7829042673110962e-01
    z[1,6,6]  R1065     -8.7246164679527283e-02
    z[1,6,6]  R1066     4.4387900829315186e-01
    z[1,6,6]  R1067     2.8109195828437805e-01
    z[1,6,6]  R1068     -3.9085072278976440e-01
    z[1,6,6]  R1069     -6.4286071062088013e-01
    z[1,6,6]  R1070     -1.3372294604778290e-01
    z[1,6,6]  R1071     1.5851153433322906e-01
    z[1,6,6]  R1072     3.4828382730484009e-01
    z[1,6,6]  R1073     -7.6698742806911469e-02
    z[1,6,6]  R1074     -2.2745883464813232e-01
    z[1,6,6]  R1075     4.2368043214082718e-02
    z[1,6,6]  R1076     -2.6303768157958984e-01
    z[1,6,6]  R1077     5.7033085823059082e-01
    z[1,6,6]  R1078     -2.8217649459838867e-01
    z[1,6,6]  R1079     -3.5408067703247070e-01
    z[1,6,6]  R1080     5.4378491640090942e-01
    z[1,6,6]  R1081     1.4204236865043640e-01
    z[1,6,6]  R1082     3.6710157990455627e-01
    z[1,6,6]  R1083     8.0660529434680939e-02
    z[1,6,6]  R1084     -0.4650898873806
    z[1,6,6]  R1085     3.4662488102912903e-01
    z[1,6,6]  R1086     -4.5101717114448547e-01
    z[1,6,6]  R1087     -0.061142697930336
    z[1,6,6]  R1088     3.1764614582061768e-01
    z[1,6,6]  R1089     -4.0411904454231262e-02
    z[1,6,6]  R1090     1.6303151845932007e-01
    z[6,1,0]  R11       1
    z[6,1,0]  R56       -1
    z[6,1,0]  R1091     -1
    z[6,1,0]  R1092     1
    z[6,1,0]  R1105     -2.4306967854499817e-01
    z[6,1,0]  R1106     2.2307108342647552e-01
    z[6,1,0]  R1107     3.4439027309417725e-01
    z[6,1,0]  R1108     -1.1825361847877502e-01
    z[6,1,0]  R1109     -3.4254449605941772e-01
    z[6,1,0]  R1110     -2.2716903686523438e-01
    z[6,1,0]  R1111     1.6046869754791260e-01
    z[6,1,0]  R1112     2.3380806669592857e-03
    z[6,1,0]  R1113     5.3210145235061646e-01
    z[6,1,0]  R1114     -0.767795979976654
    z[6,1,0]  R1115     -1.9495630264282227e-01
    z[6,1,0]  R1116     1.4105166494846344e-01
    z[6,1,0]  R1117     4.1521412134170532e-01
    z[6,1,0]  R1118     -3.4050655364990234e-01
    z[6,1,0]  R1119     -1.2337133288383484e-01
    z[6,1,0]  R1120     -8.0893546342849731e-02
    z[6,1,0]  R1121     -0.316019743680954
    z[6,1,0]  R1122     -6.1593884229660034e-01
    z[6,1,0]  R1123     3.3860269188880920e-01
    z[6,1,0]  R1124     1.6142678260803223e-01
    z[6,1,0]  R1125     6.1083510518074036e-02
    z[6,1,0]  R1126     2.1380166709423065e-01
    z[6,1,0]  R1127     -7.3983520269393921e-01
    z[6,1,0]  R1128     2.5135216116905212e-01
    z[6,1,0]  R1129     8.9019227027893066e-01
    z[6,1,0]  R1130     8.5609972476959229e-01
    z[6,1,0]  R1131     -4.3352678418159485e-02
    z[6,1,0]  R1132     -2.3973140120506287e-01
    z[6,1,0]  R1133     3.1451526284217834e-01
    z[6,1,0]  R1134     5.4635588079690933e-02
    z[6,1,0]  R1135     3.8354450464248657e-01
    z[6,1,0]  R1136     3.0896863341331482e-01
    z[6,1,0]  R1137     7.9854726791381836e-02
    z[6,1,0]  R1138     -2.5239627808332443e-02
    z[6,1,0]  R1139     2.7237203717231750e-01
    z[6,1,0]  R1140     -3.5902258753776550e-01
    z[6,1,0]  R1141     -2.9740709066390991e-01
    z[6,1,0]  R1142     -4.5330911874771118e-02
    z[6,1,0]  R1143     -3.8903504610061646e-01
    z[6,1,0]  R1144     -1.7127676308155060e-01
    z[6,1,0]  R1145     6.3217975199222565e-02
    z[6,1,0]  R1146     -1.8302571773529053e-01
    z[6,1,0]  R1147     -4.7933542728424072e-01
    z[6,1,0]  R1148     3.4628391265869141e-01
    z[6,1,0]  R1149     2.0839316770434380e-02
    z[6,1,0]  R1150     1.1791638284921646e-01
    z[6,1,0]  R1151     -5.6895387172698975e-01
    z[6,1,0]  R1152     1.9080510735511780e-01
    z[6,1,0]  R1153     -2.1374617516994476e-01
    z[6,1,0]  R1154     -0.562109112739563
    z[6,1,1]  R12       1
    z[6,1,1]  R57       -1
    z[6,1,1]  R1093     -1
    z[6,1,1]  R1094     1
    z[6,1,1]  R1105     5.9484001249074936e-02
    z[6,1,1]  R1106     0.0543687604367733
    z[6,1,1]  R1107     6.3366413116455078e-02
    z[6,1,1]  R1108     4.9888465553522110e-02
    z[6,1,1]  R1109     2.9684877954423428e-03
    z[6,1,1]  R1110     8.2638889551162720e-02
    z[6,1,1]  R1111     -3.6709473934024572e-03
    z[6,1,1]  R1112     -8.7194317579269409e-01
    z[6,1,1]  R1113     -4.8741912841796875e-01
    z[6,1,1]  R1114     -1.3693065941333771e-01
    z[6,1,1]  R1115     -2.3118425905704498e-01
    z[6,1,1]  R1116     0.755187451839447
    z[6,1,1]  R1117     7.3013103008270264e-01
    z[6,1,1]  R1118     6.6247063875198364e-01
    z[6,1,1]  R1119     4.9459806084632874e-01
    z[6,1,1]  R1120     4.6404811739921570e-01
    z[6,1,1]  R1121     3.1120446324348450e-01
    z[6,1,1]  R1122     3.3675163984298706e-01
    z[6,1,1]  R1123     -8.5062372684478760e-01
    z[6,1,1]  R1124     -8.1816995143890381e-01
    z[6,1,1]  R1125     5.9199923276901245e-01
    z[6,1,1]  R1126     -1.7263798415660858e-01
    z[6,1,1]  R1127     6.1789894104003906e-01
    z[6,1,1]  R1128     2.8438141942024231e-01
    z[6,1,1]  R1129     -3.3239364624023438e-01
    z[6,1,1]  R1130     -2.8496605157852173e-01
    z[6,1,1]  R1131     3.6099424958229065e-01
    z[6,1,1]  R1132     0.552646815776825
    z[6,1,1]  R1133     -8.3604240417480469e-01
    z[6,1,1]  R1134     4.0312197804450989e-01
    z[6,1,1]  R1135     7.0076704025268555e-01
    z[6,1,1]  R1136     5.3063219785690308e-01
    z[6,1,1]  R1137     -1.3068813085556030e-01
    z[6,1,1]  R1138     -7.0500189065933228e-01
    z[6,1,1]  R1139     -0.484901487827301
    z[6,1,1]  R1140     -7.5998403131961823e-02
    z[6,1,1]  R1141     5.8496486395597458e-02
    z[6,1,1]  R1142     -7.3956793546676636e-01
    z[6,1,1]  R1143     -1.9420027732849121e-02
    z[6,1,1]  R1144     -6.9828546047210693e-01
    z[6,1,1]  R1145     4.2234563827514648e-01
    z[6,1,1]  R1146     -2.5246351957321167e-01
    z[6,1,1]  R1147     2.1436658501625061e-01
    z[6,1,1]  R1148     -3.4335559606552124e-01
    z[6,1,1]  R1149     4.6609568595886230e-01
    z[6,1,1]  R1150     -5.4194486141204834e-01
    z[6,1,1]  R1151     4.5076854526996613e-02
    z[6,1,1]  R1152     -4.0479990839958191e-01
    z[6,1,1]  R1153     7.3992349207401276e-02
    z[6,1,1]  R1154     -5.0194181501865387e-02
    z[6,1,2]  R13       1
    z[6,1,2]  R58       -1
    z[6,1,2]  R1095     -1
    z[6,1,2]  R1096     1
    z[6,1,2]  R1105     9.0363526344299316e-01
    z[6,1,2]  R1106     6.0082674026489258e-01
    z[6,1,2]  R1107     8.2879191637039185e-01
    z[6,1,2]  R1108     0.734775722026825
    z[6,1,2]  R1109     6.4357602596282959e-01
    z[6,1,2]  R1110     1.3082157075405121e-01
    z[6,1,2]  R1111     4.5716318488121033e-01
    z[6,1,2]  R1112     -1.2676886282861233e-02
    z[6,1,2]  R1113     3.1302943825721741e-02
    z[6,1,2]  R1114     -2.5597837567329407e-01
    z[6,1,2]  R1115     -4.6411642432212830e-01
    z[6,1,2]  R1116     -4.1137015819549561e-01
    z[6,1,2]  R1117     -4.1148072481155396e-01
    z[6,1,2]  R1118     -2.4406099319458008e-01
    z[6,1,2]  R1119     -8.6108408868312836e-02
    z[6,1,2]  R1120     2.5306552648544312e-01
    z[6,1,2]  R1121     1.0281375050544739e-01
    z[6,1,2]  R1122     -2.5616028904914856e-01
    z[6,1,2]  R1123     -9.8373480141162872e-02
    z[6,1,2]  R1124     -3.8059923052787781e-01
    z[6,1,2]  R1125     -2.7311458252370358e-03
    z[6,1,2]  R1126     -4.7505609691143036e-02
    z[6,1,2]  R1127     -1.6115337610244751e-01
    z[6,1,2]  R1128     -1.4312425628304482e-02
    z[6,1,2]  R1129     -7.1665213909000158e-05
    z[6,1,2]  R1130     1.2088888138532639e-01
    z[6,1,2]  R1131     -4.1242414154112339e-03
    z[6,1,2]  R1132     -2.9520472511649132e-02
    z[6,1,2]  R1133     -1.7982059717178345e-01
    z[6,1,2]  R1134     8.2160130143165588e-02
    z[6,1,2]  R1135     1.3549405336380005e-01
    z[6,1,2]  R1136     -6.9270215928554535e-02
    z[6,1,2]  R1137     -1.4978380501270294e-01
    z[6,1,2]  R1138     5.1258418709039688e-02
    z[6,1,2]  R1139     2.1003323793411255e-01
    z[6,1,2]  R1140     1.7651681602001190e-01
    z[6,1,2]  R1141     1.1088189668953419e-02
    z[6,1,2]  R1142     7.0806264877319336e-02
    z[6,1,2]  R1143     0.0782213807106018
    z[6,1,2]  R1144     1.3924143277108669e-02
    z[6,1,2]  R1145     -1.6303548216819763e-01
    z[6,1,2]  R1146     -2.1536026149988174e-02
    z[6,1,2]  R1147     -0.0760052353143692
    z[6,1,2]  R1148     2.0098702609539032e-01
    z[6,1,2]  R1149     -6.1345055699348450e-02
    z[6,1,2]  R1150     -1.3458553701639175e-02
    z[6,1,2]  R1151     3.7188690900802612e-01
    z[6,1,2]  R1152     1.6649918258190155e-01
    z[6,1,2]  R1153     6.5833173692226410e-02
    z[6,1,2]  R1154     4.1337138414382935e-01
    z[6,1,3]  R14       1
    z[6,1,3]  R59       -1
    z[6,1,3]  R1097     -1
    z[6,1,3]  R1098     1
    z[6,1,3]  R1105     -1.7220060527324677e-01
    z[6,1,3]  R1106     -4.9672982096672058e-01
    z[6,1,3]  R1107     -4.0433195233345032e-01
    z[6,1,3]  R1108     -0.330777645111084
    z[6,1,3]  R1109     -6.6862158477306366e-02
    z[6,1,3]  R1110     -8.7391048669815063e-01
    z[6,1,3]  R1111     4.3200913071632385e-01
    z[6,1,3]  R1112     0.178828626871109
    z[6,1,3]  R1113     3.6172637343406677e-01
    z[6,1,3]  R1114     -5.7961666025221348e-03
    z[6,1,3]  R1115     -1.2184821814298630e-01
    z[6,1,3]  R1116     -4.7170307487249374e-02
    z[6,1,3]  R1117     -3.9499200880527496e-02
    z[6,1,3]  R1118     2.5259786844253540e-01
    z[6,1,3]  R1119     6.0434317588806152e-01
    z[6,1,3]  R1120     5.1674425601959229e-01
    z[6,1,3]  R1121     9.4966374337673187e-02
    z[6,1,3]  R1122     9.8139166831970215e-02
    z[6,1,3]  R1123     3.6098104715347290e-01
    z[6,1,3]  R1124     -1.4106282033026218e-02
    z[6,1,3]  R1125     4.5125576853752136e-01
    z[6,1,3]  R1126     -6.9074326753616333e-01
    z[6,1,3]  R1127     1.8896495923399925e-02
    z[6,1,3]  R1128     0.397897869348526
    z[6,1,3]  R1129     8.4381639957427979e-02
    z[6,1,3]  R1130     3.5591584444046021e-01
    z[6,1,3]  R1131     9.2086660861968994e-01
    z[6,1,3]  R1132     -3.1765013933181763e-01
    z[6,1,3]  R1133     1.0727182030677795e-01
    z[6,1,3]  R1134     3.9924341440200806e-01
    z[6,1,3]  R1135     -1.9374012947082520e-01
    z[6,1,3]  R1136     -2.3194399476051331e-01
    z[6,1,3]  R1137     -8.7596736848354340e-02
    z[6,1,3]  R1138     3.3047983050346375e-01
    z[6,1,3]  R1139     2.3281952738761902e-01
    z[6,1,3]  R1140     -5.7619011402130127e-01
    z[6,1,3]  R1141     -7.4140834808349609e-01
    z[6,1,3]  R1142     4.0285822749137878e-01
    z[6,1,3]  R1143     -2.5792804360389709e-01
    z[6,1,3]  R1144     3.4212014079093933e-01
    z[6,1,3]  R1145     2.5536033511161804e-01
    z[6,1,3]  R1146     -1.9580744206905365e-02
    z[6,1,3]  R1147     5.1058417558670044e-01
    z[6,1,3]  R1148     5.7484978437423706e-01
    z[6,1,3]  R1149     -2.0147246122360229e-01
    z[6,1,3]  R1150     6.7178118228912354e-01
    z[6,1,3]  R1151     -5.1815766096115112e-01
    z[6,1,3]  R1152     6.8073445558547974e-01
    z[6,1,3]  R1153     -6.5127015113830566e-01
    z[6,1,3]  R1154     -2.6127964258193970e-01
    z[6,1,4]  R15       1
    z[6,1,4]  R60       -1
    z[6,1,4]  R1099     -1
    z[6,1,4]  R1100     1
    z[6,1,4]  R1105     2.1855711936950684e-01
    z[6,1,4]  R1106     3.6860066652297974e-01
    z[6,1,4]  R1107     1.1693480610847473e-01
    z[6,1,4]  R1108     2.8102025389671326e-01
    z[6,1,4]  R1109     5.4940587282180786e-01
    z[6,1,4]  R1110     9.3946486711502075e-02
    z[6,1,4]  R1111     4.8800927400588989e-01
    z[6,1,4]  R1112     -3.2916495203971863e-01
    z[6,1,4]  R1113     -4.6568018198013306e-01
    z[6,1,4]  R1114     -1.6710628569126129e-01
    z[6,1,4]  R1115     1.5868784487247467e-01
    z[6,1,4]  R1116     0.306011825799942
    z[6,1,4]  R1117     -2.2578364610671997e-01
    z[6,1,4]  R1118     -3.1393823027610779e-01
    z[6,1,4]  R1119     -3.7847158312797546e-01
    z[6,1,4]  R1120     -4.5780256390571594e-01
    z[6,1,4]  R1121     -8.1053566932678223e-01
    z[6,1,4]  R1122     -5.7097882032394409e-01
    z[6,1,4]  R1123     -1.1380314081907272e-01
    z[6,1,4]  R1124     -1.3239854574203491e-01
    z[6,1,4]  R1125     -2.0377385616302490e-01
    z[6,1,4]  R1126     -1.9554647803306580e-01
    z[6,1,4]  R1127     -7.1302741765975952e-02
    z[6,1,4]  R1128     -7.4175751209259033e-01
    z[6,1,4]  R1129     -1.1411214619874954e-01
    z[6,1,4]  R1130     -0.0604756623506546
    z[6,1,4]  R1131     0.00889661442488432
    z[6,1,4]  R1132     -7.1751803159713745e-01
    z[6,1,4]  R1133     -1.9821767508983612e-01
    z[6,1,4]  R1134     -7.7603662014007568e-01
    z[6,1,4]  R1135     4.3331223726272583e-01
    z[6,1,4]  R1136     3.2113659381866455e-01
    z[6,1,4]  R1137     5.2670681476593018e-01
    z[6,1,4]  R1138     -1.4285834133625031e-01
    z[6,1,4]  R1139     -3.8055914640426636e-01
    z[6,1,4]  R1140     3.7265902757644653e-01
    z[6,1,4]  R1141     3.3615803718566895e-01
    z[6,1,4]  R1142     -0.0842844620347023
    z[6,1,4]  R1143     5.2886521816253662e-01
    z[6,1,4]  R1144     -5.4532349109649658e-01
    z[6,1,4]  R1145     3.8011528551578522e-02
    z[6,1,4]  R1146     5.9980505704879761e-01
    z[6,1,4]  R1147     -3.1217586994171143e-01
    z[6,1,4]  R1148     -1.8894271552562714e-01
    z[6,1,4]  R1149     7.1065044403076172e-01
    z[6,1,4]  R1150     -1.7832717299461365e-01
    z[6,1,4]  R1151     2.9451239109039307e-01
    z[6,1,4]  R1152     2.1173436939716339e-01
    z[6,1,4]  R1153     2.8134658932685852e-01
    z[6,1,4]  R1154     2.1854051947593689e-01
    z[6,1,5]  R16       1
    z[6,1,5]  R61       -1
    z[6,1,5]  R1101     -1
    z[6,1,5]  R1102     1
    z[6,1,5]  R1105     -1.3518853485584259e-01
    z[6,1,5]  R1106     -2.8702250123023987e-01
    z[6,1,5]  R1107     8.6273632943630219e-02
    z[6,1,5]  R1108     -4.5111864805221558e-01
    z[6,1,5]  R1109     4.0043982863426208e-01
    z[6,1,5]  R1110     -2.8760471940040588e-01
    z[6,1,5]  R1111     1.2319029122591019e-01
    z[6,1,5]  R1112     -1.3998635113239288e-01
    z[6,1,5]  R1113     7.2343222796916962e-02
    z[6,1,5]  R1114     -5.0539571791887283e-02
    z[6,1,5]  R1115     -7.9557329416275024e-01
    z[6,1,5]  R1116     -9.9694781005382538e-02
    z[6,1,5]  R1117     0.257186621427536
    z[6,1,5]  R1118     -8.3370454609394073e-02
    z[6,1,5]  R1119     -3.2267215847969055e-01
    z[6,1,5]  R1120     1.8452392518520355e-01
    z[6,1,5]  R1121     3.5069581866264343e-01
    z[6,1,5]  R1122     7.1079894900321960e-02
    z[6,1,5]  R1123     8.4961839020252228e-02
    z[6,1,5]  R1124     3.3967030048370361e-01
    z[6,1,5]  R1125     -5.3726172447204590e-01
    z[6,1,5]  R1126     -0.626187801361084
    z[6,1,5]  R1127     -1.6882559657096863e-01
    z[6,1,5]  R1128     -3.3339250087738037e-01
    z[6,1,5]  R1129     3.3609855920076370e-02
    z[6,1,5]  R1130     -1.6285820305347443e-01
    z[6,1,5]  R1131     2.5512970983982086e-02
    z[6,1,5]  R1132     1.5018879203125834e-03
    z[6,1,5]  R1133     -2.9831105470657349e-01
    z[6,1,5]  R1134     1.9834114611148834e-01
    z[6,1,5]  R1135     3.3949002623558044e-01
    z[6,1,5]  R1136     -1.5337635576725006e-01
    z[6,1,5]  R1137     -2.4938280880451202e-01
    z[6,1,5]  R1138     5.6400257349014282e-01
    z[6,1,5]  R1139     4.6394929289817810e-01
    z[6,1,5]  R1140     4.4545814394950867e-01
    z[6,1,5]  R1141     4.8621088266372681e-01
    z[6,1,5]  R1142     -6.7275539040565491e-02
    z[6,1,5]  R1143     5.4848223924636841e-01
    z[6,1,5]  R1144     -4.6977987512946129e-03
    z[6,1,5]  R1145     -4.5693108439445496e-01
    z[6,1,5]  R1146     -4.5982575416564941e-01
    z[6,1,5]  R1147     4.6194070577621460e-01
    z[6,1,5]  R1148     5.6908661127090454e-01
    z[6,1,5]  R1149     -4.7468963265419006e-01
    z[6,1,5]  R1150     1.0996001958847046e-01
    z[6,1,5]  R1151     3.1893891096115112e-01
    z[6,1,5]  R1152     3.3318656682968140e-01
    z[6,1,5]  R1153     1.6710844635963440e-01
    z[6,1,5]  R1154     6.1378264427185059e-01
    z[6,1,6]  R17       1
    z[6,1,6]  R62       -1
    z[6,1,6]  R1103     -1
    z[6,1,6]  R1104     1
    z[6,1,6]  R1105     1.5851153433322906e-01
    z[6,1,6]  R1106     3.4828382730484009e-01
    z[6,1,6]  R1107     -7.6698742806911469e-02
    z[6,1,6]  R1108     -2.2745883464813232e-01
    z[6,1,6]  R1109     4.2368043214082718e-02
    z[6,1,6]  R1110     -2.6303768157958984e-01
    z[6,1,6]  R1111     5.7033085823059082e-01
    z[6,1,6]  R1112     -2.8217649459838867e-01
    z[6,1,6]  R1113     -3.5408067703247070e-01
    z[6,1,6]  R1114     5.4378491640090942e-01
    z[6,1,6]  R1115     1.4204236865043640e-01
    z[6,1,6]  R1116     3.6710157990455627e-01
    z[6,1,6]  R1117     8.0660529434680939e-02
    z[6,1,6]  R1118     -0.4650898873806
    z[6,1,6]  R1119     3.4662488102912903e-01
    z[6,1,6]  R1120     -4.5101717114448547e-01
    z[6,1,6]  R1121     -0.061142697930336
    z[6,1,6]  R1122     3.1764614582061768e-01
    z[6,1,6]  R1123     -4.0411904454231262e-02
    z[6,1,6]  R1124     1.6303151845932007e-01
    z[6,1,6]  R1125     -3.3465293049812317e-01
    z[6,1,6]  R1126     -1.2145908921957016e-01
    z[6,1,6]  R1127     -1.0455239564180374e-01
    z[6,1,6]  R1128     1.8991325795650482e-01
    z[6,1,6]  R1129     -2.7531927824020386e-01
    z[6,1,6]  R1130     1.2007252871990204e-01
    z[6,1,6]  R1131     1.3806284964084625e-01
    z[6,1,6]  R1132     -1.4318844676017761e-01
    z[6,1,6]  R1133     1.7317837476730347e-01
    z[6,1,6]  R1134     -1.6367603838443756e-01
    z[6,1,6]  R1135     -5.3965445607900620e-02
    z[6,1,6]  R1136     6.6160291433334351e-01
    z[6,1,6]  R1137     7.7898889780044556e-01
    z[6,1,6]  R1138     2.2799883782863617e-01
    z[6,1,6]  R1139     -4.8196563124656677e-01
    z[6,1,6]  R1140     -4.0603697299957275e-01
    z[6,1,6]  R1141     9.4417795538902283e-02
    z[6,1,6]  R1142     -5.2158057689666748e-01
    z[6,1,6]  R1143     4.4169902801513672e-01
    z[6,1,6]  R1144     -2.6157552003860474e-01
    z[6,1,6]  R1145     7.1805804967880249e-01
    z[6,1,6]  R1146     -5.7507455348968506e-01
    z[6,1,6]  R1147     3.8336464762687683e-01
    z[6,1,6]  R1148     -1.7829042673110962e-01
    z[6,1,6]  R1149     -8.7246164679527283e-02
    z[6,1,6]  R1150     4.4387900829315186e-01
    z[6,1,6]  R1151     2.8109195828437805e-01
    z[6,1,6]  R1152     -3.9085072278976440e-01
    z[6,1,6]  R1153     -6.4286071062088013e-01
    z[6,1,6]  R1154     -1.3372294604778290e-01
    z[2,4,0]  R20       -1
    z[2,4,0]  R38       1
    z[2,4,0]  R1155     -1
    z[2,4,0]  R1156     1
    z[2,4,0]  R1169     -3.7761595845222473e-01
    z[2,4,0]  R1170     -2.6884365081787109e-01
    z[2,4,0]  R1171     7.9843342304229736e-01
    z[2,4,0]  R1172     8.7542468309402466e-01
    z[2,4,0]  R1173     8.4131413698196411e-01
    z[2,4,0]  R1174     0.419920414686203
    z[2,4,0]  R1175     0.285171240568161
    z[2,4,0]  R1176     3.6918950080871582e-01
    z[2,4,0]  R1177     6.9000291824340820e-01
    z[2,4,0]  R1178     6.2999832630157471e-01
    z[2,4,0]  R1179     -3.1384840607643127e-01
    z[2,4,0]  R1180     -2.1706500649452209e-01
    z[2,4,0]  R1181     1.7495959997177124e-01
    z[2,4,0]  R1182     3.1879001855850220e-01
    z[2,4,0]  R1183     2.0410983264446259e-01
    z[2,4,0]  R1184     0.538845419883728
    z[2,4,0]  R1185     4.7156815417110920e-03
    z[2,4,0]  R1186     5.1173609495162964e-01
    z[2,4,0]  R1187     3.5414862632751465e-01
    z[2,4,0]  R1188     1.5112403035163879e-01
    z[2,4,0]  R1189     3.5378584265708923e-01
    z[2,4,0]  R1190     -7.7039031311869621e-03
    z[2,4,0]  R1191     5.1625329256057739e-01
    z[2,4,0]  R1192     5.4666346311569214e-01
    z[2,4,0]  R1193     -2.4800196290016174e-01
    z[2,4,0]  R1194     4.0988841652870178e-01
    z[2,4,0]  R1195     3.5897067189216614e-01
    z[2,4,0]  R1196     6.8418520689010620e-01
    z[2,4,0]  R1197     5.2593183517456055e-01
    z[2,4,0]  R1198     3.0959594249725342e-01
    z[2,4,0]  R1199     -3.0739870667457581e-01
    z[2,4,0]  R1200     -5.9899266809225082e-02
    z[2,4,0]  R1201     5.0955039262771606e-01
    z[2,4,0]  R1202     6.1493802070617676e-01
    z[2,4,0]  R1203     0.53638756275177
    z[2,4,0]  R1204     6.5523380041122437e-01
    z[2,4,0]  R1205     2.7248516678810120e-01
    z[2,4,0]  R1206     3.8072407245635986e-01
    z[2,4,0]  R1207     8.6608707904815674e-01
    z[2,4,0]  R1208     5.1091867685317993e-01
    z[2,4,0]  R1209     -4.8466438055038452e-01
    z[2,4,0]  R1210     -2.2906814515590668e-01
    z[2,4,0]  R1211     -1.3635233044624329e-02
    z[2,4,0]  R1212     9.6427626907825470e-02
    z[2,4,0]  R1213     4.2372739315032959e-01
    z[2,4,0]  R1214     5.4470956325531006e-01
    z[2,4,0]  R1215     6.6702020168304443e-01
    z[2,4,0]  R1216     5.1377475261688232e-02
    z[2,4,0]  R1217     7.0297127962112427e-01
    z[2,4,0]  R1218     7.1857148408889771e-01
    z[2,4,0]  R1219     -2.2881361842155457e-01
    z[2,4,0]  R1220     -2.3070777952671051e-01
    z[2,4,0]  R1221     -5.2906799316406250e-01
    z[2,4,0]  R1222     -0.536858856678009
    z[2,4,0]  R1223     -1.4750261604785919e-01
    z[2,4,0]  R1224     -3.4159582853317261e-01
    z[2,4,0]  R1225     -4.2805242538452148e-01
    z[2,4,0]  R1226     2.6663309335708618e-01
    z[2,4,0]  R1227     -6.7907178401947021e-01
    z[2,4,0]  R1228     -6.7647963762283325e-01
    z[2,4,0]  R1229     2.4160841107368469e-01
    z[2,4,0]  R1230     1.3185410201549530e-01
    z[2,4,0]  R1231     -1.3201734982430935e-02
    z[2,4,0]  R1232     5.5172022432088852e-02
    z[2,4,0]  R1233     -2.2242331877350807e-02
    z[2,4,0]  R1234     7.6204225420951843e-02
    z[2,4,0]  R1235     1.2282416224479675e-01
    z[2,4,0]  R1236     5.5029653012752533e-02
    z[2,4,0]  R1237     1.8619391322135925e-01
    z[2,4,0]  R1238     -7.5316391885280609e-03
    z[2,4,0]  R1239     3.0556654557585716e-02
    z[2,4,0]  R1240     5.3235888481140137e-01
    z[2,4,0]  R1241     5.4403203725814819e-01
    z[2,4,0]  R1242     4.4899505376815796e-01
    z[2,4,0]  R1243     5.0258380174636841e-01
    z[2,4,0]  R1244     6.5266287326812744e-01
    z[2,4,0]  R1245     6.2692219018936157e-01
    z[2,4,0]  R1246     -1.3840657472610474e-01
    z[2,4,0]  R1247     -1.8528200685977936e-01
    z[2,4,0]  R1248     7.7054411172866821e-01
    z[2,4,0]  R1249     4.3017071485519409e-01
    z[2,4,0]  R1250     7.1977972984313965e-02
    z[2,4,0]  R1251     -4.0937475860118866e-02
    z[2,4,0]  R1252     -3.3348676562309265e-01
    z[2,4,0]  R1253     3.5101863741874695e-01
    z[2,4,0]  R1254     -4.0713661909103394e-01
    z[2,4,0]  R1255     7.9137533903121948e-01
    z[2,4,0]  R1256     -0.54306960105896
    z[2,4,0]  R1257     8.4613734483718872e-01
    z[2,4,0]  R1258     -1.7747931182384491e-01
    z[2,4,0]  R1259     2.9744449257850647e-01
    z[2,4,0]  R1260     -3.8600695133209229e-01
    z[2,4,0]  R1261     3.0390096828341484e-02
    z[2,4,0]  R1262     3.7899947166442871e-01
    z[2,4,0]  R1263     -1.3790874183177948e-01
    z[2,4,0]  R1264     1.5185585618019104e-01
    z[2,4,0]  R1265     1.9510146975517273e-01
    z[2,4,0]  R1266     7.7100229263305664e-01
    z[2,4,0]  R1267     1.1139265447854996e-01
    z[2,4,0]  R1268     7.5476515293121338e-01
    z[2,4,1]  R21       -1
    z[2,4,1]  R39       1
    z[2,4,1]  R1157     -1
    z[2,4,1]  R1158     1
    z[2,4,1]  R1169     3.8441542536020279e-02
    z[2,4,1]  R1170     8.1759430468082428e-02
    z[2,4,1]  R1171     -4.0119934082031250e-01
    z[2,4,1]  R1172     -2.3960407078266144e-01
    z[2,4,1]  R1173     -3.0244883894920349e-01
    z[2,4,1]  R1174     -0.802794873714447
    z[2,4,1]  R1175     -8.8745057582855225e-01
    z[2,4,1]  R1176     -0.754834771156311
    z[2,4,1]  R1177     -3.9399498701095581e-01
    z[2,4,1]  R1178     8.5442259907722473e-02
    z[2,4,1]  R1179     5.6618911027908325e-01
    z[2,4,1]  R1180     2.3656965792179108e-01
    z[2,4,1]  R1181     5.4735934734344482e-01
    z[2,4,1]  R1182     4.4414228200912476e-01
    z[2,4,1]  R1183     6.6778522729873657e-01
    z[2,4,1]  R1184     6.4470344781875610e-01
    z[2,4,1]  R1185     4.5176360011100769e-01
    z[2,4,1]  R1186     3.9058855175971985e-01
    z[2,4,1]  R1187     4.3951633572578430e-01
    z[2,4,1]  R1188     6.5985703468322754e-01
    z[2,4,1]  R1189     2.5097227096557617e-01
    z[2,4,1]  R1190     0.688449501991272
    z[2,4,1]  R1191     4.6634155511856079e-01
    z[2,4,1]  R1192     -6.1167693138122559e-01
    z[2,4,1]  R1193     -5.3506873548030853e-02
    z[2,4,1]  R1194     -6.4141339063644409e-01
    z[2,4,1]  R1195     -7.2092831134796143e-01
    z[2,4,1]  R1196     -3.9164590835571289e-01
    z[2,4,1]  R1197     -6.4713460206985474e-01
    z[2,4,1]  R1198     -6.1470401287078857e-01
    z[2,4,1]  R1199     8.1374222040176392e-01
    z[2,4,1]  R1200     8.5356724262237549e-01
    z[2,4,1]  R1201     -6.6358691453933716e-01
    z[2,4,1]  R1202     -5.5984467267990112e-01
    z[2,4,1]  R1203     -6.9038879871368408e-01
    z[2,4,1]  R1204     -4.7251582145690918e-01
    z[2,4,1]  R1205     -7.4744731187820435e-01
    z[2,4,1]  R1206     -6.1545717716217041e-01
    z[2,4,1]  R1207     -3.5275623202323914e-01
    z[2,4,1]  R1208     -4.5408290624618530e-01
    z[2,4,1]  R1209     -3.5253381729125977e-01
    z[2,4,1]  R1210     8.0153006315231323e-01
    z[2,4,1]  R1211     8.7071365118026733e-01
    z[2,4,1]  R1212     5.4113519191741943e-01
    z[2,4,1]  R1213     5.0517255067825317e-01
    z[2,4,1]  R1214     0.586051881313324
    z[2,4,1]  R1215     5.4306948184967041e-01
    z[2,4,1]  R1216     8.1572657823562622e-01
    z[2,4,1]  R1217     -3.9696505665779114e-01
    z[2,4,1]  R1218     -2.6708725094795227e-01
    z[2,4,1]  R1219     3.7018606066703796e-01
    z[2,4,1]  R1220     3.2088243961334229e-01
    z[2,4,1]  R1221     -0.0853620320558548
    z[2,4,1]  R1222     0.352740615606308
    z[2,4,1]  R1223     9.3586467206478119e-02
    z[2,4,1]  R1224     3.8938581943511963e-01
    z[2,4,1]  R1225     1.1426846683025360e-01
    z[2,4,1]  R1226     4.3071934580802917e-01
    z[2,4,1]  R1227     4.6511983871459961e-01
    z[2,4,1]  R1228     5.1966643333435059e-01
    z[2,4,1]  R1229     4.5888322591781616e-01
    z[2,4,1]  R1230     -8.3910757303237915e-01
    z[2,4,1]  R1231     -8.6533606052398682e-01
    z[2,4,1]  R1232     -0.856290876865387
    z[2,4,1]  R1233     -0.831427812576294
    z[2,4,1]  R1234     -8.8973259925842285e-01
    z[2,4,1]  R1235     -8.9831674098968506e-01
    z[2,4,1]  R1236     -8.8220846652984619e-01
    z[2,4,1]  R1237     -8.9002692699432373e-01
    z[2,4,1]  R1238     -7.4586510658264160e-01
    z[2,4,1]  R1239     2.2671137750148773e-01
    z[2,4,1]  R1240     5.6912928819656372e-01
    z[2,4,1]  R1241     4.9940598011016846e-01
    z[2,4,1]  R1242     5.0135904550552368e-01
    z[2,4,1]  R1243     4.9811157584190369e-01
    z[2,4,1]  R1244     5.1809805631637573e-01
    z[2,4,1]  R1245     5.7565355300903320e-01
    z[2,4,1]  R1246     4.0577733516693115e-01
    z[2,4,1]  R1247     -8.1414830684661865e-01
    z[2,4,1]  R1248     -2.6228375732898712e-02
    z[2,4,1]  R1249     5.8665776252746582e-01
    z[2,4,1]  R1250     -8.8336187601089478e-01
    z[2,4,1]  R1251     -8.6680001020431519e-01
    z[2,4,1]  R1252     -8.3143043518066406e-01
    z[2,4,1]  R1253     -8.7545108795166016e-01
    z[2,4,1]  R1254     -5.9915989637374878e-01
    z[2,4,1]  R1255     -3.1522031873464584e-02
    z[2,4,1]  R1256     -7.1259617805480957e-01
    z[2,4,1]  R1257     -2.4191428720951080e-01
    z[2,4,1]  R1258     -9.0931630134582520e-01
    z[2,4,1]  R1259     6.7801761627197266e-01
    z[2,4,1]  R1260     -5.3744238615036011e-01
    z[2,4,1]  R1261     5.1924854516983032e-01
    z[2,4,1]  R1262     7.3822093009948730e-01
    z[2,4,1]  R1263     -9.6936339139938354e-01
    z[2,4,1]  R1264     -8.4631758928298950e-01
    z[2,4,1]  R1265     -8.1340706348419189e-01
    z[2,4,1]  R1266     -1.3318565487861633e-01
    z[2,4,1]  R1267     -9.3571096658706665e-01
    z[2,4,1]  R1268     -3.4393274784088135e-01
    z[2,4,2]  R22       -1
    z[2,4,2]  R40       1
    z[2,4,2]  R1159     -1
    z[2,4,2]  R1160     1
    z[2,4,2]  R1169     7.4965290725231171e-02
    z[2,4,2]  R1170     0.681813657283783
    z[2,4,2]  R1171     1.4072988927364349e-01
    z[2,4,2]  R1172     1.7492705583572388e-01
    z[2,4,2]  R1173     1.3756878674030304e-02
    z[2,4,2]  R1174     -1.7958280444145203e-01
    z[2,4,2]  R1175     -3.4977486357092857e-03
    z[2,4,2]  R1176     1.0772727429866791e-01
    z[2,4,2]  R1177     3.0122503638267517e-01
    z[2,4,2]  R1178     5.3374260663986206e-01
    z[2,4,2]  R1179     3.3036175370216370e-01
    z[2,4,2]  R1180     -1.0271928459405899e-01
    z[2,4,2]  R1181     3.5235092509537935e-03
    z[2,4,2]  R1182     -1.6434369981288910e-01
    z[2,4,2]  R1183     -3.0935943126678467e-01
    z[2,4,2]  R1184     2.0727092027664185e-01
    z[2,4,2]  R1185     -3.2779264450073242e-01
    z[2,4,2]  R1186     2.4899050593376160e-01
    z[2,4,2]  R1187     -9.0174794197082520e-02
    z[2,4,2]  R1188     -1.8114100396633148e-01
    z[2,4,2]  R1189     7.9812347888946533e-01
    z[2,4,2]  R1190     6.2663513422012329e-01
    z[2,4,2]  R1191     4.0392029285430908e-01
    z[2,4,2]  R1192     -7.3203317821025848e-02
    z[2,4,2]  R1193     2.7970877289772034e-01
    z[2,4,2]  R1194     1.5855786204338074e-01
    z[2,4,2]  R1195     2.7109023928642273e-01
    z[2,4,2]  R1196     -1.7429442703723907e-01
    z[2,4,2]  R1197     -5.2469903230667114e-01
    z[2,4,2]  R1198     2.7236273884773254e-01
    z[2,4,2]  R1199     -1.1220594495534897e-01
    z[2,4,2]  R1200     -3.8480564951896667e-01
    z[2,4,2]  R1201     2.0183211192488670e-02
    z[2,4,2]  R1202     2.4744583293795586e-02
    z[2,4,2]  R1203     -2.3151947557926178e-01
    z[2,4,2]  R1204     -2.6929610967636108e-01
    z[2,4,2]  R1205     3.4785324335098267e-01
    z[2,4,2]  R1206     4.8382428288459778e-01
    z[2,4,2]  R1207     2.1594485267996788e-02
    z[2,4,2]  R1208     -2.0730255171656609e-02
    z[2,4,2]  R1209     1.1036302149295807e-01
    z[2,4,2]  R1210     3.5348507761955261e-01
    z[2,4,2]  R1211     0.0318136028945446
    z[2,4,2]  R1212     5.4831538349390030e-02
    z[2,4,2]  R1213     4.4717624783515930e-02
    z[2,4,2]  R1214     -1.7602179944515228e-01
    z[2,4,2]  R1215     2.6207652688026428e-01
    z[2,4,2]  R1216     -4.0650373697280884e-01
    z[2,4,2]  R1217     4.3773704767227173e-01
    z[2,4,2]  R1218     3.4073731303215027e-01
    z[2,4,2]  R1219     1.9356827437877655e-01
    z[2,4,2]  R1220     2.4685165286064148e-01
    z[2,4,2]  R1221     6.1206500977277756e-02
    z[2,4,2]  R1222     -2.0180317759513855e-01
    z[2,4,2]  R1223     4.4411984086036682e-01
    z[2,4,2]  R1224     -4.3181997537612915e-01
    z[2,4,2]  R1225     -2.7103242278099060e-01
    z[2,4,2]  R1226     -2.6697742938995361e-01
    z[2,4,2]  R1227     -3.4243506193161011e-01
    z[2,4,2]  R1228     -1.4939494431018829e-01
    z[2,4,2]  R1229     6.4450573921203613e-01
    z[2,4,2]  R1230     1.0331121087074280e-01
    z[2,4,2]  R1231     2.6637923717498779e-01
    z[2,4,2]  R1232     -5.4543375968933105e-02
    z[2,4,2]  R1233     5.0195097923278809e-02
    z[2,4,2]  R1234     6.9693282246589661e-02
    z[2,4,2]  R1235     -3.0473910737782717e-03
    z[2,4,2]  R1236     5.7179573923349380e-03
    z[2,4,2]  R1237     1.1403743177652359e-01
    z[2,4,2]  R1238     1.3642043806612492e-02
    z[2,4,2]  R1239     3.7542662024497986e-01
    z[2,4,2]  R1240     2.8058382868766785e-01
    z[2,4,2]  R1241     1.0063945502042770e-01
    z[2,4,2]  R1242     4.1253137588500977e-01
    z[2,4,2]  R1243     2.2937135398387909e-01
    z[2,4,2]  R1244     -1.9970403984189034e-02
    z[2,4,2]  R1245     -0.0692482516169548
    z[2,4,2]  R1246     5.8593684434890747e-01
    z[2,4,2]  R1247     4.3814271688461304e-01
    z[2,4,2]  R1248     0.30632483959198
    z[2,4,2]  R1249     1.7609870433807373e-01
    z[2,4,2]  R1250     -1.4286562800407410e-01
    z[2,4,2]  R1251     -4.6527005732059479e-02
    z[2,4,2]  R1252     -1.1773762851953506e-01
    z[2,4,2]  R1253     3.0067640542984009e-01
    z[2,4,2]  R1254     -2.5073844194412231e-01
    z[2,4,2]  R1255     0.209524467587471
    z[2,4,2]  R1256     1.4049339806661010e-03
    z[2,4,2]  R1257     1.0268007963895798e-01
    z[2,4,2]  R1258     -2.8969830274581909e-01
    z[2,4,2]  R1259     3.6941519379615784e-01
    z[2,4,2]  R1260     -4.3036320805549622e-01
    z[2,4,2]  R1261     5.8853012323379517e-01
    z[2,4,2]  R1262     4.5391544699668884e-02
    z[2,4,2]  R1263     -2.4259122088551521e-02
    z[2,4,2]  R1264     8.1423148512840271e-02
    z[2,4,2]  R1265     -7.7357396483421326e-02
    z[2,4,2]  R1266     2.0851007103919983e-01
    z[2,4,2]  R1267     -1.8838453292846680e-01
    z[2,4,2]  R1268     2.4028047919273376e-01
    z[2,4,3]  R23       -1
    z[2,4,3]  R41       1
    z[2,4,3]  R1161     -1
    z[2,4,3]  R1162     1
    z[2,4,3]  R1169     -6.8057513236999512e-01
    z[2,4,3]  R1170     1.2966774404048920e-01
    z[2,4,3]  R1171     1.4103873074054718e-01
    z[2,4,3]  R1172     2.2557689249515533e-01
    z[2,4,3]  R1173     3.4696063399314880e-01
    z[2,4,3]  R1174     1.0997498035430908e-01
    z[2,4,3]  R1175     -1.4441721141338348e-01
    z[2,4,3]  R1176     -3.9046889543533325e-01
    z[2,4,3]  R1177     2.1113230288028717e-01
    z[2,4,3]  R1178     -4.3737614154815674e-01
    z[2,4,3]  R1179     -0.275144100189209
    z[2,4,3]  R1180     3.6345925927162170e-01
    z[2,4,3]  R1181     -1.2501551210880280e-01
    z[2,4,3]  R1182     -4.3762576580047607e-01
    z[2,4,3]  R1183     -3.6428907513618469e-01
    z[2,4,3]  R1184     7.4119992554187775e-02
    z[2,4,3]  R1185     -2.9075714945793152e-01
    z[2,4,3]  R1186     -1.3685405254364014e-02
    z[2,4,3]  R1187     -1.0349833220243454e-01
    z[2,4,3]  R1188     5.0873857736587524e-01
    z[2,4,3]  R1189     -3.3803546428680420e-01
    z[2,4,3]  R1190     2.2532603144645691e-01
    z[2,4,3]  R1191     5.0569951534271240e-01
    z[2,4,3]  R1192     5.6493043899536133e-01
    z[2,4,3]  R1193     -5.5822163820266724e-01
    z[2,4,3]  R1194     1.5094357728958130e-01
    z[2,4,3]  R1195     -6.5323412418365479e-02
    z[2,4,3]  R1196     1.8714305013418198e-02
    z[2,4,3]  R1197     2.0260209217667580e-02
    z[2,4,3]  R1198     -4.6693214774131775e-01
    z[2,4,3]  R1199     1.3155084848403931e-01
    z[2,4,3]  R1200     0.0213027261197567
    z[2,4,3]  R1201     -1.2451861053705215e-01
    z[2,4,3]  R1202     1.3461527228355408e-01
    z[2,4,3]  R1203     -3.0403189361095428e-02
    z[2,4,3]  R1204     -3.1890103220939636e-01
    z[2,4,3]  R1205     3.0515128374099731e-01
    z[2,4,3]  R1206     -2.7336540818214417e-01
    z[2,4,3]  R1207     -2.2930863499641418e-01
    z[2,4,3]  R1208     -6.9702661037445068e-01
    z[2,4,3]  R1209     3.9165702462196350e-01
    z[2,4,3]  R1210     9.0290986001491547e-02
    z[2,4,3]  R1211     1.1057351529598236e-01
    z[2,4,3]  R1212     -6.4202737808227539e-01
    z[2,4,3]  R1213     -2.9270380735397339e-01
    z[2,4,3]  R1214     -4.7821402549743652e-01
    z[2,4,3]  R1215     5.7964488863945007e-02
    z[2,4,3]  R1216     -0.312037855386734
    z[2,4,3]  R1217     2.0122438669204712e-01
    z[2,4,3]  R1218     -1.0564703494310379e-01
    z[2,4,3]  R1219     5.8835631608963013e-01
    z[2,4,3]  R1220     5.7909131050109863e-01
    z[2,4,3]  R1221     7.1007597446441650e-01
    z[2,4,3]  R1222     5.1912295818328857e-01
    z[2,4,3]  R1223     6.7351454496383667e-01
    z[2,4,3]  R1224     2.3599152266979218e-01
    z[2,4,3]  R1225     1.0072951018810272e-01
    z[2,4,3]  R1226     2.6326471567153931e-01
    z[2,4,3]  R1227     -2.1841265261173248e-01
    z[2,4,3]  R1228     -4.2937964200973511e-01
    z[2,4,3]  R1229     -4.6761611104011536e-01
    z[2,4,3]  R1230     -4.9306672811508179e-01
    z[2,4,3]  R1231     -3.1495910882949829e-01
    z[2,4,3]  R1232     -3.9545559883117676e-01
    z[2,4,3]  R1233     -4.3779936432838440e-01
    z[2,4,3]  R1234     -1.8927714228630066e-01
    z[2,4,3]  R1235     -1.6373868286609650e-01
    z[2,4,3]  R1236     -2.1787050366401672e-01
    z[2,4,3]  R1237     -1.5182100236415863e-01
    z[2,4,3]  R1238     -6.5627634525299072e-01
    z[2,4,3]  R1239     -2.7796211838722229e-01
    z[2,4,3]  R1240     -4.3183439970016479e-01
    z[2,4,3]  R1241     -3.4537440538406372e-01
    z[2,4,3]  R1242     -0.092435322701931
    z[2,4,3]  R1243     -2.7672863006591797e-01
    z[2,4,3]  R1244     -4.0482899546623230e-01
    z[2,4,3]  R1245     -3.9469927549362183e-01
    z[2,4,3]  R1246     -5.2682596445083618e-01
    z[2,4,3]  R1247     -2.8664425015449524e-01
    z[2,4,3]  R1248     -4.9529033899307251e-01
    z[2,4,3]  R1249     -4.2812418937683105e-01
    z[2,4,3]  R1250     -3.9481440186500549e-01
    z[2,4,3]  R1251     -1.8525658547878265e-01
    z[2,4,3]  R1252     -2.7522468566894531e-01
    z[2,4,3]  R1253     0.0848386287689209
    z[2,4,3]  R1254     -4.0217173099517822e-01
    z[2,4,3]  R1255     -4.1430890560150146e-01
    z[2,4,3]  R1256     -3.9949494600296021e-01
    z[2,4,3]  R1257     -2.5498467683792114e-01
    z[2,4,3]  R1258     -3.7392899394035339e-02
    z[2,4,3]  R1259     -3.3119708299636841e-01
    z[2,4,3]  R1260     -2.1668106317520142e-01
    z[2,4,3]  R1261     -5.1878023147583008e-01
    z[2,4,3]  R1262     -5.1609623432159424e-01
    z[2,4,3]  R1263     -9.2928275465965271e-02
    z[2,4,3]  R1264     -3.2332196831703186e-01
    z[2,4,3]  R1265     -4.1578653454780579e-01
    z[2,4,3]  R1266     -5.5670082569122314e-01
    z[2,4,3]  R1267     -8.2895331084728241e-02
    z[2,4,3]  R1268     -1.3179579377174377e-01
    z[2,4,4]  R24       -1
    z[2,4,4]  R42       1
    z[2,4,4]  R1163     -1
    z[2,4,4]  R1164     1
    z[2,4,4]  R1169     -1.1373429745435715e-01
    z[2,4,4]  R1170     8.2437492907047272e-02
    z[2,4,4]  R1171     -2.3470453917980194e-01
    z[2,4,4]  R1172     -1.1266208440065384e-01
    z[2,4,4]  R1173     -2.7110788226127625e-01
    z[2,4,4]  R1174     -3.5360220074653625e-01
    z[2,4,4]  R1175     -3.2983240485191345e-01
    z[2,4,4]  R1176     -9.7517386078834534e-02
    z[2,4,4]  R1177     -8.8615730404853821e-02
    z[2,4,4]  R1178     1.9421349465847015e-01
    z[2,4,4]  R1179     0.525259792804718
    z[2,4,4]  R1180     4.0166336297988892e-01
    z[2,4,4]  R1181     7.6657354831695557e-01
    z[2,4,4]  R1182     5.4183059930801392e-01
    z[2,4,4]  R1183     -1.5221124887466431e-01
    z[2,4,4]  R1184     -4.2753493785858154e-01
    z[2,4,4]  R1185     2.6012265682220459e-01
    z[2,4,4]  R1186     -1.6520659625530243e-01
    z[2,4,4]  R1187     -4.2838916182518005e-02
    z[2,4,4]  R1188     7.7875934541225433e-02
    z[2,4,4]  R1189     1.7025533318519592e-01
    z[2,4,4]  R1190     -2.5707101821899414e-01
    z[2,4,4]  R1191     1.9409327208995819e-01
    z[2,4,4]  R1192     -4.1895397007465363e-02
    z[2,4,4]  R1193     6.2116956710815430e-01
    z[2,4,4]  R1194     2.3017503321170807e-01
    z[2,4,4]  R1195     4.8447516560554504e-01
    z[2,4,4]  R1196     2.1125909686088562e-01
    z[2,4,4]  R1197     -1.2951073586009443e-04
    z[2,4,4]  R1198     1.1897636950016022e-01
    z[2,4,4]  R1199     -2.8945109248161316e-01
    z[2,4,4]  R1200     -1.0832422971725464e-01
    z[2,4,4]  R1201     2.0887608826160431e-01
    z[2,4,4]  R1202     8.3890803158283234e-02
    z[2,4,4]  R1203     3.4508371353149414e-01
    z[2,4,4]  R1204     1.8232037127017975e-01
    z[2,4,4]  R1205     -1.4317064546048641e-02
    z[2,4,4]  R1206     -1.6430977731943130e-02
    z[2,4,4]  R1207     -2.9563827440142632e-02
    z[2,4,4]  R1208     1.5581177175045013e-01
    z[2,4,4]  R1209     4.5532783865928650e-01
    z[2,4,4]  R1210     -5.0584875047206879e-02
    z[2,4,4]  R1211     1.6250425577163696e-01
    z[2,4,4]  R1212     -7.6470471918582916e-02
    z[2,4,4]  R1213     2.8865805268287659e-01
    z[2,4,4]  R1214     1.6766466200351715e-01
    z[2,4,4]  R1215     4.0400851517915726e-02
    z[2,4,4]  R1216     -1.3726890087127686e-01
    z[2,4,4]  R1217     -1.5371577441692352e-01
    z[2,4,4]  R1218     2.8815966844558716e-01
    z[2,4,4]  R1219     0.0576406754553318
    z[2,4,4]  R1220     -2.8113916516304016e-01
    z[2,4,4]  R1221     1.2987929582595825e-01
    z[2,4,4]  R1222     4.6343860030174255e-01
    z[2,4,4]  R1223     -0.510013222694397
    z[2,4,4]  R1224     -4.1461598873138428e-01
    z[2,4,4]  R1225     -7.2644233703613281e-01
    z[2,4,4]  R1226     0.361479789018631
    z[2,4,4]  R1227     8.6656715720891953e-03
    z[2,4,4]  R1228     -4.3161340057849884e-02
    z[2,4,4]  R1229     3.0528002977371216e-01
    z[2,4,4]  R1230     2.9022667557001114e-02
    z[2,4,4]  R1231     -1.9766373932361603e-01
    z[2,4,4]  R1232     2.7908211946487427e-01
    z[2,4,4]  R1233     2.6561075448989868e-01
    z[2,4,4]  R1234     1.1386289447546005e-01
    z[2,4,4]  R1235     -1.5815052390098572e-01
    z[2,4,4]  R1236     2.5039520859718323e-01
    z[2,4,4]  R1237     2.3188173770904541e-01
    z[2,4,4]  R1238     -8.0177605152130127e-02
    z[2,4,4]  R1239     3.8502511382102966e-01
    z[2,4,4]  R1240     2.4384586513042450e-01
    z[2,4,4]  R1241     1.8069259822368622e-01
    z[2,4,4]  R1242     3.5716065764427185e-01
    z[2,4,4]  R1243     0.376345157623291
    z[2,4,4]  R1244     -2.0123182237148285e-01
    z[2,4,4]  R1245     -1.8087539076805115e-01
    z[2,4,4]  R1246     -2.9361805319786072e-01
    z[2,4,4]  R1247     1.6702005267143250e-01
    z[2,4,4]  R1248     1.5417100489139557e-01
    z[2,4,4]  R1249     3.9853486418724060e-01
    z[2,4,4]  R1250     -1.0265780985355377e-01
    z[2,4,4]  R1251     -0.439564049243927
    z[2,4,4]  R1252     -5.2966731600463390e-03
    z[2,4,4]  R1253     -8.4944792091846466e-02
    z[2,4,4]  R1254     -3.2924994826316833e-01
    z[2,4,4]  R1255     -2.7652847766876221e-01
    z[2,4,4]  R1256     1.5353962779045105e-01
    z[2,4,4]  R1257     0.144717276096344
    z[2,4,4]  R1258     -3.5749140661209822e-03
    z[2,4,4]  R1259     4.1059872508049011e-01
    z[2,4,4]  R1260     -2.3432014882564545e-01
    z[2,4,4]  R1261     -2.3054113984107971e-01
    z[2,4,4]  R1262     9.5175974071025848e-02
    z[2,4,4]  R1263     1.5428699553012848e-01
    z[2,4,4]  R1264     -1.8565729260444641e-01
    z[2,4,4]  R1265     -2.3748582601547241e-01
    z[2,4,4]  R1266     -8.1103906035423279e-02
    z[2,4,4]  R1267     1.7757375538349152e-01
    z[2,4,4]  R1268     4.6526998281478882e-01
    z[2,4,5]  R25       -1
    z[2,4,5]  R43       1
    z[2,4,5]  R1165     -1
    z[2,4,5]  R1166     1
    z[2,4,5]  R1169     -5.6261110305786133e-01
    z[2,4,5]  R1170     -4.5188632607460022e-01
    z[2,4,5]  R1171     4.7491684556007385e-02
    z[2,4,5]  R1172     1.0402470082044601e-01
    z[2,4,5]  R1173     -6.2023870646953583e-02
    z[2,4,5]  R1174     -1.0046847164630890e-02
    z[2,4,5]  R1175     -2.1654093638062477e-02
    z[2,4,5]  R1176     -3.4643489122390747e-01
    z[2,4,5]  R1177     -3.7767979502677917e-01
    z[2,4,5]  R1178     -1.7442518472671509e-01
    z[2,4,5]  R1179     3.4574168920516968e-01
    z[2,4,5]  R1180     -5.5439078807830811e-01
    z[2,4,5]  R1181     -2.3657123744487762e-01
    z[2,4,5]  R1182     2.0953471958637238e-01
    z[2,4,5]  R1183     0.50971519947052
    z[2,4,5]  R1184     2.0126949250698090e-01
    z[2,4,5]  R1185     -8.6231883615255356e-03
    z[2,4,5]  R1186     6.8229717016220093e-01
    z[2,4,5]  R1187     4.6939301490783691e-01
    z[2,4,5]  R1188     4.2282477021217346e-01
    z[2,4,5]  R1189     6.1182837933301926e-02
    z[2,4,5]  R1190     -1.1985354125499725e-01
    z[2,4,5]  R1191     8.6183302104473114e-02
    z[2,4,5]  R1192     2.4325927719473839e-02
    z[2,4,5]  R1193     1.0157548636198044e-01
    z[2,4,5]  R1194     4.8351404070854187e-01
    z[2,4,5]  R1195     8.5496142506599426e-02
    z[2,4,5]  R1196     4.2921945452690125e-01
    z[2,4,5]  R1197     -1.6942197084426880e-01
    z[2,4,5]  R1198     2.2209188342094421e-01
    z[2,4,5]  R1199     -1.5760114416480064e-02
    z[2,4,5]  R1200     0.0844428762793541
    z[2,4,5]  R1201     2.1522009372711182e-01
    z[2,4,5]  R1202     -5.1006329059600830e-01
    z[2,4,5]  R1203     -2.1311371028423309e-01
    z[2,4,5]  R1204     1.6942206025123596e-01
    z[2,4,5]  R1205     -3.9063182473182678e-01
    z[2,4,5]  R1206     2.0191356539726257e-01
    z[2,4,5]  R1207     2.2902959585189819e-01
    z[2,4,5]  R1208     -5.8947563171386719e-02
    z[2,4,5]  R1209     -4.1749498248100281e-01
    z[2,4,5]  R1210     -3.7870484590530396e-01
    z[2,4,5]  R1211     -0.415229469537735
    z[2,4,5]  R1212     -0.0883241817355156
    z[2,4,5]  R1213     4.2321172356605530e-01
    z[2,4,5]  R1214     1.6260632872581482e-01
    z[2,4,5]  R1215     0.0569465234875679
    z[2,4,5]  R1216     -1.6966991126537323e-01
    z[2,4,5]  R1217     -3.0250322818756104e-01
    z[2,4,5]  R1218     3.7471261620521545e-01
    z[2,4,5]  R1219     -2.5419354438781738e-01
    z[2,4,5]  R1220     5.5253233760595322e-02
    z[2,4,5]  R1221     -3.6885783076286316e-02
    z[2,4,5]  R1222     -2.2479355335235596e-01
    z[2,4,5]  R1223     -6.6237091086804867e-03
    z[2,4,5]  R1224     -4.9201363325119019e-01
    z[2,4,5]  R1225     -3.0697554349899292e-01
    z[2,4,5]  R1226     -5.5386364459991455e-01
    z[2,4,5]  R1227     0.341463178396225
    z[2,4,5]  R1228     2.4733063578605652e-01
    z[2,4,5]  R1229     -5.3956888616085052e-02
    z[2,4,5]  R1230     -1.4479069411754608e-01
    z[2,4,5]  R1231     2.7465509250760078e-02
    z[2,4,5]  R1232     2.3230038583278656e-02
    z[2,4,5]  R1233     -1.4664037525653839e-01
    z[2,4,5]  R1234     -2.1142846345901489e-01
    z[2,4,5]  R1235     3.5193203948438168e-03
    z[2,4,5]  R1236     -2.8943467140197754e-01
    z[2,4,5]  R1237     1.2393782287836075e-01
    z[2,4,5]  R1238     0.0698886290192604
    z[2,4,5]  R1239     -7.6179319620132446e-01
    z[2,4,5]  R1240     1.6764022409915924e-01
    z[2,4,5]  R1241     5.3217488527297974e-01
    z[2,4,5]  R1242     4.8674359917640686e-01
    z[2,4,5]  R1243     4.7387725114822388e-01
    z[2,4,5]  R1244     2.3500698804855347e-01
    z[2,4,5]  R1245     -4.2441502213478088e-02
    z[2,4,5]  R1246     -3.1275925040245056e-01
    z[2,4,5]  R1247     -1.8474724143743515e-02
    z[2,4,5]  R1248     1.6109757125377655e-01
    z[2,4,5]  R1249     -9.8054654896259308e-02
    z[2,4,5]  R1250     -1.2702740728855133e-01
    z[2,4,5]  R1251     -8.6095677688717842e-03
    z[2,4,5]  R1252     -2.8188601136207581e-01
    z[2,4,5]  R1253     -4.4874340295791626e-02
    z[2,4,5]  R1254     3.7709128856658936e-01
    z[2,4,5]  R1255     -2.0452212542295456e-02
    z[2,4,5]  R1256     1.1788973212242126e-01
    z[2,4,5]  R1257     -6.4595431089401245e-02
    z[2,4,5]  R1258     2.1863219141960144e-01
    z[2,4,5]  R1259     5.1559224724769592e-02
    z[2,4,5]  R1260     2.0553177595138550e-01
    z[2,4,5]  R1261     -1.7279775440692902e-01
    z[2,4,5]  R1262     -1.7816193401813507e-01
    z[2,4,5]  R1263     -8.2208685576915741e-02
    z[2,4,5]  R1264     1.6701954603195190e-01
    z[2,4,5]  R1265     -6.9015175104141235e-02
    z[2,4,5]  R1266     2.7071535587310791e-02
    z[2,4,5]  R1267     1.9414480030536652e-01
    z[2,4,5]  R1268     3.5885747522115707e-02
    z[2,4,6]  R26       -1
    z[2,4,6]  R44       1
    z[2,4,6]  R1167     -1
    z[2,4,6]  R1168     1
    z[2,4,6]  R1169     -2.4012371897697449e-01
    z[2,4,6]  R1170     -4.7786796092987061e-01
    z[2,4,6]  R1171     -3.2327172160148621e-01
    z[2,4,6]  R1172     0.266877144575119
    z[2,4,6]  R1173     -5.2893865853548050e-02
    z[2,4,6]  R1174     -9.8525643348693848e-02
    z[2,4,6]  R1175     3.1339146196842194e-02
    z[2,4,6]  R1176     1.8047126010060310e-02
    z[2,4,6]  R1177     -2.8784683346748352e-01
    z[2,4,6]  R1178     2.2689154744148254e-01
    z[2,4,6]  R1179     -2.5508137419819832e-02
    z[2,4,6]  R1180     5.3439790010452271e-01
    z[2,4,6]  R1181     -1.0268667340278625e-01
    z[2,4,6]  R1182     -3.8092023134231567e-01
    z[2,4,6]  R1183     0.0318525955080986
    z[2,4,6]  R1184     -1.4917287230491638e-01
    z[2,4,6]  R1185     7.3223048448562622e-01
    z[2,4,6]  R1186     -1.7481561005115509e-01
    z[2,4,6]  R1187     6.6362321376800537e-01
    z[2,4,6]  R1188     2.5549495220184326e-01
    z[2,4,6]  R1189     -1.6688092052936554e-01
    z[2,4,6]  R1190     -4.5651599764823914e-02
    z[2,4,6]  R1191     2.2808927297592163e-01
    z[2,4,6]  R1192     -1.2586400844156742e-02
    z[2,4,6]  R1193     3.8680014014244080e-01
    z[2,4,6]  R1194     -2.9306897521018982e-01
    z[2,4,6]  R1195     -1.7781928181648254e-01
    z[2,4,6]  R1196     0.344841331243515
    z[2,4,6]  R1197     -1.3751790858805180e-02
    z[2,4,6]  R1198     -0.413039892911911
    z[2,4,6]  R1199     3.5972705483436584e-01
    z[2,4,6]  R1200     -3.1692448258399963e-01
    z[2,4,6]  R1201     4.4062426686286926e-01
    z[2,4,6]  R1202     1.4996452629566193e-01
    z[2,4,6]  R1203     1.2894116342067719e-01
    z[2,4,6]  R1204     3.3351856470108032e-01
    z[2,4,6]  R1205     -1.2531548738479614e-02
    z[2,4,6]  R1206     -3.5553896427154541e-01
    z[2,4,6]  R1207     1.3812610507011414e-01
    z[2,4,6]  R1208     1.3690458238124847e-01
    z[2,4,6]  R1209     -3.0597314238548279e-01
    z[2,4,6]  R1210     -1.6123616695404053e-01
    z[2,4,6]  R1211     1.7207552492618561e-01
    z[2,4,6]  R1212     5.1867133378982544e-01
    z[2,4,6]  R1213     4.6384155750274658e-01
    z[2,4,6]  R1214     2.1356520056724548e-01
    z[2,4,6]  R1215     4.2806592583656311e-01
    z[2,4,6]  R1216     1.4733320474624634e-01
    z[2,4,6]  R1217     -3.1754586845636368e-02
    z[2,4,6]  R1218     2.4821478128433228e-01
    z[2,4,6]  R1219     -5.9919780492782593e-01
    z[2,4,6]  R1220     6.0451114177703857e-01
    z[2,4,6]  R1221     -4.3199202418327332e-01
    z[2,4,6]  R1222     -1.0879322141408920e-01
    z[2,4,6]  R1223     -0.241790771484375
    z[2,4,6]  R1224     2.7485761046409607e-01
    z[2,4,6]  R1225     -3.1329923868179321e-01
    z[2,4,6]  R1226     4.0665698051452637e-01
    z[2,4,6]  R1227     2.0220498740673065e-01
    z[2,4,6]  R1228     -5.0999283790588379e-02
    z[2,4,6]  R1229     2.9861494898796082e-02
    z[2,4,6]  R1230     5.4020345211029053e-02
    z[2,4,6]  R1231     -2.0257534086704254e-01
    z[2,4,6]  R1232     -1.6104483604431152e-01
    z[2,4,6]  R1233     -1.4829909801483154e-01
    z[2,4,6]  R1234     3.2283014059066772e-01
    z[2,4,6]  R1235     -3.5510218143463135e-01
    z[2,4,6]  R1236     1.5719279646873474e-01
    z[2,4,6]  R1237     2.6076811552047729e-01
    z[2,4,6]  R1238     3.7825204432010651e-02
    z[2,4,6]  R1239     2.9783040285110474e-02
    z[2,4,6]  R1240     -1.9978380203247070e-01
    z[2,4,6]  R1241     9.6700891852378845e-02
    z[2,4,6]  R1242     -6.1911858618259430e-02
    z[2,4,6]  R1243     6.2522336840629578e-02
    z[2,4,6]  R1244     2.1353588998317719e-01
    z[2,4,6]  R1245     -2.8371039032936096e-01
    z[2,4,6]  R1246     1.0625831037759781e-01
    z[2,4,6]  R1247     0.0215000007301569
    z[2,4,6]  R1248     1.2924927473068237e-01
    z[2,4,6]  R1249     -2.9671558737754822e-01
    z[2,4,6]  R1250     1.0736639797687531e-01
    z[2,4,6]  R1251     1.3117294013500214e-01
    z[2,4,6]  R1252     1.6855685412883759e-01
    z[2,4,6]  R1253     0.0594826303422451
    z[2,4,6]  R1254     5.6614372879266739e-03
    z[2,4,6]  R1255     2.8335985541343689e-01
    z[2,4,6]  R1256     1.4543295837938786e-02
    z[2,4,6]  R1257     3.5334545373916626e-01
    z[2,4,6]  R1258     9.2243090271949768e-02
    z[2,4,6]  R1259     1.8549966812133789e-01
    z[2,4,6]  R1260     4.8253691196441650e-01
    z[2,4,6]  R1261     1.7592176795005798e-01
    z[2,4,6]  R1262     4.6619750559329987e-02
    z[2,4,6]  R1263     -3.9099924266338348e-02
    z[2,4,6]  R1264     2.9522067308425903e-01
    z[2,4,6]  R1265     -2.4551825225353241e-01
    z[2,4,6]  R1266     -1.6466338932514191e-01
    z[2,4,6]  R1267     2.1250389516353607e-02
    z[2,4,6]  R1268     -1.3845956325531006e-01
    z[4,2,0]  R20       1
    z[4,2,0]  R38       -1
    z[4,2,0]  R1269     -1
    z[4,2,0]  R1270     1
    z[4,2,0]  R1283     -2.2881361842155457e-01
    z[4,2,0]  R1284     -2.3070777952671051e-01
    z[4,2,0]  R1285     -5.2906799316406250e-01
    z[4,2,0]  R1286     -0.536858856678009
    z[4,2,0]  R1287     -1.4750261604785919e-01
    z[4,2,0]  R1288     -3.4159582853317261e-01
    z[4,2,0]  R1289     -4.2805242538452148e-01
    z[4,2,0]  R1290     2.6663309335708618e-01
    z[4,2,0]  R1291     -6.7907178401947021e-01
    z[4,2,0]  R1292     -6.7647963762283325e-01
    z[4,2,0]  R1293     2.4160841107368469e-01
    z[4,2,0]  R1294     1.3185410201549530e-01
    z[4,2,0]  R1295     -1.3201734982430935e-02
    z[4,2,0]  R1296     5.5172022432088852e-02
    z[4,2,0]  R1297     -2.2242331877350807e-02
    z[4,2,0]  R1298     7.6204225420951843e-02
    z[4,2,0]  R1299     1.2282416224479675e-01
    z[4,2,0]  R1300     5.5029653012752533e-02
    z[4,2,0]  R1301     1.8619391322135925e-01
    z[4,2,0]  R1302     -7.5316391885280609e-03
    z[4,2,0]  R1303     3.0556654557585716e-02
    z[4,2,0]  R1304     5.3235888481140137e-01
    z[4,2,0]  R1305     5.4403203725814819e-01
    z[4,2,0]  R1306     4.4899505376815796e-01
    z[4,2,0]  R1307     5.0258380174636841e-01
    z[4,2,0]  R1308     6.5266287326812744e-01
    z[4,2,0]  R1309     6.2692219018936157e-01
    z[4,2,0]  R1310     -1.3840657472610474e-01
    z[4,2,0]  R1311     -1.8528200685977936e-01
    z[4,2,0]  R1312     7.7054411172866821e-01
    z[4,2,0]  R1313     4.3017071485519409e-01
    z[4,2,0]  R1314     7.1977972984313965e-02
    z[4,2,0]  R1315     -4.0937475860118866e-02
    z[4,2,0]  R1316     -3.3348676562309265e-01
    z[4,2,0]  R1317     3.5101863741874695e-01
    z[4,2,0]  R1318     -4.0713661909103394e-01
    z[4,2,0]  R1319     7.9137533903121948e-01
    z[4,2,0]  R1320     -0.54306960105896
    z[4,2,0]  R1321     8.4613734483718872e-01
    z[4,2,0]  R1322     -1.7747931182384491e-01
    z[4,2,0]  R1323     2.9744449257850647e-01
    z[4,2,0]  R1324     -3.8600695133209229e-01
    z[4,2,0]  R1325     3.0390096828341484e-02
    z[4,2,0]  R1326     3.7899947166442871e-01
    z[4,2,0]  R1327     -1.3790874183177948e-01
    z[4,2,0]  R1328     1.5185585618019104e-01
    z[4,2,0]  R1329     1.9510146975517273e-01
    z[4,2,0]  R1330     7.7100229263305664e-01
    z[4,2,0]  R1331     1.1139265447854996e-01
    z[4,2,0]  R1332     7.5476515293121338e-01
    z[4,2,0]  R1333     -3.7761595845222473e-01
    z[4,2,0]  R1334     -2.6884365081787109e-01
    z[4,2,0]  R1335     7.9843342304229736e-01
    z[4,2,0]  R1336     8.7542468309402466e-01
    z[4,2,0]  R1337     8.4131413698196411e-01
    z[4,2,0]  R1338     0.419920414686203
    z[4,2,0]  R1339     0.285171240568161
    z[4,2,0]  R1340     3.6918950080871582e-01
    z[4,2,0]  R1341     6.9000291824340820e-01
    z[4,2,0]  R1342     6.2999832630157471e-01
    z[4,2,0]  R1343     -3.1384840607643127e-01
    z[4,2,0]  R1344     -2.1706500649452209e-01
    z[4,2,0]  R1345     1.7495959997177124e-01
    z[4,2,0]  R1346     3.1879001855850220e-01
    z[4,2,0]  R1347     2.0410983264446259e-01
    z[4,2,0]  R1348     0.538845419883728
    z[4,2,0]  R1349     4.7156815417110920e-03
    z[4,2,0]  R1350     5.1173609495162964e-01
    z[4,2,0]  R1351     3.5414862632751465e-01
    z[4,2,0]  R1352     1.5112403035163879e-01
    z[4,2,0]  R1353     3.5378584265708923e-01
    z[4,2,0]  R1354     -7.7039031311869621e-03
    z[4,2,0]  R1355     5.1625329256057739e-01
    z[4,2,0]  R1356     5.4666346311569214e-01
    z[4,2,0]  R1357     -2.4800196290016174e-01
    z[4,2,0]  R1358     4.0988841652870178e-01
    z[4,2,0]  R1359     3.5897067189216614e-01
    z[4,2,0]  R1360     6.8418520689010620e-01
    z[4,2,0]  R1361     5.2593183517456055e-01
    z[4,2,0]  R1362     3.0959594249725342e-01
    z[4,2,0]  R1363     -3.0739870667457581e-01
    z[4,2,0]  R1364     -5.9899266809225082e-02
    z[4,2,0]  R1365     5.0955039262771606e-01
    z[4,2,0]  R1366     6.1493802070617676e-01
    z[4,2,0]  R1367     0.53638756275177
    z[4,2,0]  R1368     6.5523380041122437e-01
    z[4,2,0]  R1369     2.7248516678810120e-01
    z[4,2,0]  R1370     3.8072407245635986e-01
    z[4,2,0]  R1371     8.6608707904815674e-01
    z[4,2,0]  R1372     5.1091867685317993e-01
    z[4,2,0]  R1373     -4.8466438055038452e-01
    z[4,2,0]  R1374     -2.2906814515590668e-01
    z[4,2,0]  R1375     -1.3635233044624329e-02
    z[4,2,0]  R1376     9.6427626907825470e-02
    z[4,2,0]  R1377     4.2372739315032959e-01
    z[4,2,0]  R1378     5.4470956325531006e-01
    z[4,2,0]  R1379     6.6702020168304443e-01
    z[4,2,0]  R1380     5.1377475261688232e-02
    z[4,2,0]  R1381     7.0297127962112427e-01
    z[4,2,0]  R1382     7.1857148408889771e-01
    z[4,2,1]  R21       1
    z[4,2,1]  R39       -1
    z[4,2,1]  R1271     -1
    z[4,2,1]  R1272     1
    z[4,2,1]  R1283     3.7018606066703796e-01
    z[4,2,1]  R1284     3.2088243961334229e-01
    z[4,2,1]  R1285     -0.0853620320558548
    z[4,2,1]  R1286     0.352740615606308
    z[4,2,1]  R1287     9.3586467206478119e-02
    z[4,2,1]  R1288     3.8938581943511963e-01
    z[4,2,1]  R1289     1.1426846683025360e-01
    z[4,2,1]  R1290     4.3071934580802917e-01
    z[4,2,1]  R1291     4.6511983871459961e-01
    z[4,2,1]  R1292     5.1966643333435059e-01
    z[4,2,1]  R1293     4.5888322591781616e-01
    z[4,2,1]  R1294     -8.3910757303237915e-01
    z[4,2,1]  R1295     -8.6533606052398682e-01
    z[4,2,1]  R1296     -0.856290876865387
    z[4,2,1]  R1297     -0.831427812576294
    z[4,2,1]  R1298     -8.8973259925842285e-01
    z[4,2,1]  R1299     -8.9831674098968506e-01
    z[4,2,1]  R1300     -8.8220846652984619e-01
    z[4,2,1]  R1301     -8.9002692699432373e-01
    z[4,2,1]  R1302     -7.4586510658264160e-01
    z[4,2,1]  R1303     2.2671137750148773e-01
    z[4,2,1]  R1304     5.6912928819656372e-01
    z[4,2,1]  R1305     4.9940598011016846e-01
    z[4,2,1]  R1306     5.0135904550552368e-01
    z[4,2,1]  R1307     4.9811157584190369e-01
    z[4,2,1]  R1308     5.1809805631637573e-01
    z[4,2,1]  R1309     5.7565355300903320e-01
    z[4,2,1]  R1310     4.0577733516693115e-01
    z[4,2,1]  R1311     -8.1414830684661865e-01
    z[4,2,1]  R1312     -2.6228375732898712e-02
    z[4,2,1]  R1313     5.8665776252746582e-01
    z[4,2,1]  R1314     -8.8336187601089478e-01
    z[4,2,1]  R1315     -8.6680001020431519e-01
    z[4,2,1]  R1316     -8.3143043518066406e-01
    z[4,2,1]  R1317     -8.7545108795166016e-01
    z[4,2,1]  R1318     -5.9915989637374878e-01
    z[4,2,1]  R1319     -3.1522031873464584e-02
    z[4,2,1]  R1320     -7.1259617805480957e-01
    z[4,2,1]  R1321     -2.4191428720951080e-01
    z[4,2,1]  R1322     -9.0931630134582520e-01
    z[4,2,1]  R1323     6.7801761627197266e-01
    z[4,2,1]  R1324     -5.3744238615036011e-01
    z[4,2,1]  R1325     5.1924854516983032e-01
    z[4,2,1]  R1326     7.3822093009948730e-01
    z[4,2,1]  R1327     -9.6936339139938354e-01
    z[4,2,1]  R1328     -8.4631758928298950e-01
    z[4,2,1]  R1329     -8.1340706348419189e-01
    z[4,2,1]  R1330     -1.3318565487861633e-01
    z[4,2,1]  R1331     -9.3571096658706665e-01
    z[4,2,1]  R1332     -3.4393274784088135e-01
    z[4,2,1]  R1333     3.8441542536020279e-02
    z[4,2,1]  R1334     8.1759430468082428e-02
    z[4,2,1]  R1335     -4.0119934082031250e-01
    z[4,2,1]  R1336     -2.3960407078266144e-01
    z[4,2,1]  R1337     -3.0244883894920349e-01
    z[4,2,1]  R1338     -0.802794873714447
    z[4,2,1]  R1339     -8.8745057582855225e-01
    z[4,2,1]  R1340     -0.754834771156311
    z[4,2,1]  R1341     -3.9399498701095581e-01
    z[4,2,1]  R1342     8.5442259907722473e-02
    z[4,2,1]  R1343     5.6618911027908325e-01
    z[4,2,1]  R1344     2.3656965792179108e-01
    z[4,2,1]  R1345     5.4735934734344482e-01
    z[4,2,1]  R1346     4.4414228200912476e-01
    z[4,2,1]  R1347     6.6778522729873657e-01
    z[4,2,1]  R1348     6.4470344781875610e-01
    z[4,2,1]  R1349     4.5176360011100769e-01
    z[4,2,1]  R1350     3.9058855175971985e-01
    z[4,2,1]  R1351     4.3951633572578430e-01
    z[4,2,1]  R1352     6.5985703468322754e-01
    z[4,2,1]  R1353     2.5097227096557617e-01
    z[4,2,1]  R1354     0.688449501991272
    z[4,2,1]  R1355     4.6634155511856079e-01
    z[4,2,1]  R1356     -6.1167693138122559e-01
    z[4,2,1]  R1357     -5.3506873548030853e-02
    z[4,2,1]  R1358     -6.4141339063644409e-01
    z[4,2,1]  R1359     -7.2092831134796143e-01
    z[4,2,1]  R1360     -3.9164590835571289e-01
    z[4,2,1]  R1361     -6.4713460206985474e-01
    z[4,2,1]  R1362     -6.1470401287078857e-01
    z[4,2,1]  R1363     8.1374222040176392e-01
    z[4,2,1]  R1364     8.5356724262237549e-01
    z[4,2,1]  R1365     -6.6358691453933716e-01
    z[4,2,1]  R1366     -5.5984467267990112e-01
    z[4,2,1]  R1367     -6.9038879871368408e-01
    z[4,2,1]  R1368     -4.7251582145690918e-01
    z[4,2,1]  R1369     -7.4744731187820435e-01
    z[4,2,1]  R1370     -6.1545717716217041e-01
    z[4,2,1]  R1371     -3.5275623202323914e-01
    z[4,2,1]  R1372     -4.5408290624618530e-01
    z[4,2,1]  R1373     -3.5253381729125977e-01
    z[4,2,1]  R1374     8.0153006315231323e-01
    z[4,2,1]  R1375     8.7071365118026733e-01
    z[4,2,1]  R1376     5.4113519191741943e-01
    z[4,2,1]  R1377     5.0517255067825317e-01
    z[4,2,1]  R1378     0.586051881313324
    z[4,2,1]  R1379     5.4306948184967041e-01
    z[4,2,1]  R1380     8.1572657823562622e-01
    z[4,2,1]  R1381     -3.9696505665779114e-01
    z[4,2,1]  R1382     -2.6708725094795227e-01
    z[4,2,2]  R22       1
    z[4,2,2]  R40       -1
    z[4,2,2]  R1273     -1
    z[4,2,2]  R1274     1
    z[4,2,2]  R1283     1.9356827437877655e-01
    z[4,2,2]  R1284     2.4685165286064148e-01
    z[4,2,2]  R1285     6.1206500977277756e-02
    z[4,2,2]  R1286     -2.0180317759513855e-01
    z[4,2,2]  R1287     4.4411984086036682e-01
    z[4,2,2]  R1288     -4.3181997537612915e-01
    z[4,2,2]  R1289     -2.7103242278099060e-01
    z[4,2,2]  R1290     -2.6697742938995361e-01
    z[4,2,2]  R1291     -3.4243506193161011e-01
    z[4,2,2]  R1292     -1.4939494431018829e-01
    z[4,2,2]  R1293     6.4450573921203613e-01
    z[4,2,2]  R1294     1.0331121087074280e-01
    z[4,2,2]  R1295     2.6637923717498779e-01
    z[4,2,2]  R1296     -5.4543375968933105e-02
    z[4,2,2]  R1297     5.0195097923278809e-02
    z[4,2,2]  R1298     6.9693282246589661e-02
    z[4,2,2]  R1299     -3.0473910737782717e-03
    z[4,2,2]  R1300     5.7179573923349380e-03
    z[4,2,2]  R1301     1.1403743177652359e-01
    z[4,2,2]  R1302     1.3642043806612492e-02
    z[4,2,2]  R1303     3.7542662024497986e-01
    z[4,2,2]  R1304     2.8058382868766785e-01
    z[4,2,2]  R1305     1.0063945502042770e-01
    z[4,2,2]  R1306     4.1253137588500977e-01
    z[4,2,2]  R1307     2.2937135398387909e-01
    z[4,2,2]  R1308     -1.9970403984189034e-02
    z[4,2,2]  R1309     -0.0692482516169548
    z[4,2,2]  R1310     5.8593684434890747e-01
    z[4,2,2]  R1311     4.3814271688461304e-01
    z[4,2,2]  R1312     0.30632483959198
    z[4,2,2]  R1313     1.7609870433807373e-01
    z[4,2,2]  R1314     -1.4286562800407410e-01
    z[4,2,2]  R1315     -4.6527005732059479e-02
    z[4,2,2]  R1316     -1.1773762851953506e-01
    z[4,2,2]  R1317     3.0067640542984009e-01
    z[4,2,2]  R1318     -2.5073844194412231e-01
    z[4,2,2]  R1319     0.209524467587471
    z[4,2,2]  R1320     1.4049339806661010e-03
    z[4,2,2]  R1321     1.0268007963895798e-01
    z[4,2,2]  R1322     -2.8969830274581909e-01
    z[4,2,2]  R1323     3.6941519379615784e-01
    z[4,2,2]  R1324     -4.3036320805549622e-01
    z[4,2,2]  R1325     5.8853012323379517e-01
    z[4,2,2]  R1326     4.5391544699668884e-02
    z[4,2,2]  R1327     -2.4259122088551521e-02
    z[4,2,2]  R1328     8.1423148512840271e-02
    z[4,2,2]  R1329     -7.7357396483421326e-02
    z[4,2,2]  R1330     2.0851007103919983e-01
    z[4,2,2]  R1331     -1.8838453292846680e-01
    z[4,2,2]  R1332     2.4028047919273376e-01
    z[4,2,2]  R1333     7.4965290725231171e-02
    z[4,2,2]  R1334     0.681813657283783
    z[4,2,2]  R1335     1.4072988927364349e-01
    z[4,2,2]  R1336     1.7492705583572388e-01
    z[4,2,2]  R1337     1.3756878674030304e-02
    z[4,2,2]  R1338     -1.7958280444145203e-01
    z[4,2,2]  R1339     -3.4977486357092857e-03
    z[4,2,2]  R1340     1.0772727429866791e-01
    z[4,2,2]  R1341     3.0122503638267517e-01
    z[4,2,2]  R1342     5.3374260663986206e-01
    z[4,2,2]  R1343     3.3036175370216370e-01
    z[4,2,2]  R1344     -1.0271928459405899e-01
    z[4,2,2]  R1345     3.5235092509537935e-03
    z[4,2,2]  R1346     -1.6434369981288910e-01
    z[4,2,2]  R1347     -3.0935943126678467e-01
    z[4,2,2]  R1348     2.0727092027664185e-01
    z[4,2,2]  R1349     -3.2779264450073242e-01
    z[4,2,2]  R1350     2.4899050593376160e-01
    z[4,2,2]  R1351     -9.0174794197082520e-02
    z[4,2,2]  R1352     -1.8114100396633148e-01
    z[4,2,2]  R1353     7.9812347888946533e-01
    z[4,2,2]  R1354     6.2663513422012329e-01
    z[4,2,2]  R1355     4.0392029285430908e-01
    z[4,2,2]  R1356     -7.3203317821025848e-02
    z[4,2,2]  R1357     2.7970877289772034e-01
    z[4,2,2]  R1358     1.5855786204338074e-01
    z[4,2,2]  R1359     2.7109023928642273e-01
    z[4,2,2]  R1360     -1.7429442703723907e-01
    z[4,2,2]  R1361     -5.2469903230667114e-01
    z[4,2,2]  R1362     2.7236273884773254e-01
    z[4,2,2]  R1363     -1.1220594495534897e-01
    z[4,2,2]  R1364     -3.8480564951896667e-01
    z[4,2,2]  R1365     2.0183211192488670e-02
    z[4,2,2]  R1366     2.4744583293795586e-02
    z[4,2,2]  R1367     -2.3151947557926178e-01
    z[4,2,2]  R1368     -2.6929610967636108e-01
    z[4,2,2]  R1369     3.4785324335098267e-01
    z[4,2,2]  R1370     4.8382428288459778e-01
    z[4,2,2]  R1371     2.1594485267996788e-02
    z[4,2,2]  R1372     -2.0730255171656609e-02
    z[4,2,2]  R1373     1.1036302149295807e-01
    z[4,2,2]  R1374     3.5348507761955261e-01
    z[4,2,2]  R1375     0.0318136028945446
    z[4,2,2]  R1376     5.4831538349390030e-02
    z[4,2,2]  R1377     4.4717624783515930e-02
    z[4,2,2]  R1378     -1.7602179944515228e-01
    z[4,2,2]  R1379     2.6207652688026428e-01
    z[4,2,2]  R1380     -4.0650373697280884e-01
    z[4,2,2]  R1381     4.3773704767227173e-01
    z[4,2,2]  R1382     3.4073731303215027e-01
    z[4,2,3]  R23       1
    z[4,2,3]  R41       -1
    z[4,2,3]  R1275     -1
    z[4,2,3]  R1276     1
    z[4,2,3]  R1283     5.8835631608963013e-01
    z[4,2,3]  R1284     5.7909131050109863e-01
    z[4,2,3]  R1285     7.1007597446441650e-01
    z[4,2,3]  R1286     5.1912295818328857e-01
    z[4,2,3]  R1287     6.7351454496383667e-01
    z[4,2,3]  R1288     2.3599152266979218e-01
    z[4,2,3]  R1289     1.0072951018810272e-01
    z[4,2,3]  R1290     2.6326471567153931e-01
    z[4,2,3]  R1291     -2.1841265261173248e-01
    z[4,2,3]  R1292     -4.2937964200973511e-01
    z[4,2,3]  R1293     -4.6761611104011536e-01
    z[4,2,3]  R1294     -4.9306672811508179e-01
    z[4,2,3]  R1295     -3.1495910882949829e-01
    z[4,2,3]  R1296     -3.9545559883117676e-01
    z[4,2,3]  R1297     -4.3779936432838440e-01
    z[4,2,3]  R1298     -1.8927714228630066e-01
    z[4,2,3]  R1299     -1.6373868286609650e-01
    z[4,2,3]  R1300     -2.1787050366401672e-01
    z[4,2,3]  R1301     -1.5182100236415863e-01
    z[4,2,3]  R1302     -6.5627634525299072e-01
    z[4,2,3]  R1303     -2.7796211838722229e-01
    z[4,2,3]  R1304     -4.3183439970016479e-01
    z[4,2,3]  R1305     -3.4537440538406372e-01
    z[4,2,3]  R1306     -0.092435322701931
    z[4,2,3]  R1307     -2.7672863006591797e-01
    z[4,2,3]  R1308     -4.0482899546623230e-01
    z[4,2,3]  R1309     -3.9469927549362183e-01
    z[4,2,3]  R1310     -5.2682596445083618e-01
    z[4,2,3]  R1311     -2.8664425015449524e-01
    z[4,2,3]  R1312     -4.9529033899307251e-01
    z[4,2,3]  R1313     -4.2812418937683105e-01
    z[4,2,3]  R1314     -3.9481440186500549e-01
    z[4,2,3]  R1315     -1.8525658547878265e-01
    z[4,2,3]  R1316     -2.7522468566894531e-01
    z[4,2,3]  R1317     0.0848386287689209
    z[4,2,3]  R1318     -4.0217173099517822e-01
    z[4,2,3]  R1319     -4.1430890560150146e-01
    z[4,2,3]  R1320     -3.9949494600296021e-01
    z[4,2,3]  R1321     -2.5498467683792114e-01
    z[4,2,3]  R1322     -3.7392899394035339e-02
    z[4,2,3]  R1323     -3.3119708299636841e-01
    z[4,2,3]  R1324     -2.1668106317520142e-01
    z[4,2,3]  R1325     -5.1878023147583008e-01
    z[4,2,3]  R1326     -5.1609623432159424e-01
    z[4,2,3]  R1327     -9.2928275465965271e-02
    z[4,2,3]  R1328     -3.2332196831703186e-01
    z[4,2,3]  R1329     -4.1578653454780579e-01
    z[4,2,3]  R1330     -5.5670082569122314e-01
    z[4,2,3]  R1331     -8.2895331084728241e-02
    z[4,2,3]  R1332     -1.3179579377174377e-01
    z[4,2,3]  R1333     -6.8057513236999512e-01
    z[4,2,3]  R1334     1.2966774404048920e-01
    z[4,2,3]  R1335     1.4103873074054718e-01
    z[4,2,3]  R1336     2.2557689249515533e-01
    z[4,2,3]  R1337     3.4696063399314880e-01
    z[4,2,3]  R1338     1.0997498035430908e-01
    z[4,2,3]  R1339     -1.4441721141338348e-01
    z[4,2,3]  R1340     -3.9046889543533325e-01
    z[4,2,3]  R1341     2.1113230288028717e-01
    z[4,2,3]  R1342     -4.3737614154815674e-01
    z[4,2,3]  R1343     -0.275144100189209
    z[4,2,3]  R1344     3.6345925927162170e-01
    z[4,2,3]  R1345     -1.2501551210880280e-01
    z[4,2,3]  R1346     -4.3762576580047607e-01
    z[4,2,3]  R1347     -3.6428907513618469e-01
    z[4,2,3]  R1348     7.4119992554187775e-02
    z[4,2,3]  R1349     -2.9075714945793152e-01
    z[4,2,3]  R1350     -1.3685405254364014e-02
    z[4,2,3]  R1351     -1.0349833220243454e-01
    z[4,2,3]  R1352     5.0873857736587524e-01
    z[4,2,3]  R1353     -3.3803546428680420e-01
    z[4,2,3]  R1354     2.2532603144645691e-01
    z[4,2,3]  R1355     5.0569951534271240e-01
    z[4,2,3]  R1356     5.6493043899536133e-01
    z[4,2,3]  R1357     -5.5822163820266724e-01
    z[4,2,3]  R1358     1.5094357728958130e-01
    z[4,2,3]  R1359     -6.5323412418365479e-02
    z[4,2,3]  R1360     1.8714305013418198e-02
    z[4,2,3]  R1361     2.0260209217667580e-02
    z[4,2,3]  R1362     -4.6693214774131775e-01
    z[4,2,3]  R1363     1.3155084848403931e-01
    z[4,2,3]  R1364     0.0213027261197567
    z[4,2,3]  R1365     -1.2451861053705215e-01
    z[4,2,3]  R1366     1.3461527228355408e-01
    z[4,2,3]  R1367     -3.0403189361095428e-02
    z[4,2,3]  R1368     -3.1890103220939636e-01
    z[4,2,3]  R1369     3.0515128374099731e-01
    z[4,2,3]  R1370     -2.7336540818214417e-01
    z[4,2,3]  R1371     -2.2930863499641418e-01
    z[4,2,3]  R1372     -6.9702661037445068e-01
    z[4,2,3]  R1373     3.9165702462196350e-01
    z[4,2,3]  R1374     9.0290986001491547e-02
    z[4,2,3]  R1375     1.1057351529598236e-01
    z[4,2,3]  R1376     -6.4202737808227539e-01
    z[4,2,3]  R1377     -2.9270380735397339e-01
    z[4,2,3]  R1378     -4.7821402549743652e-01
    z[4,2,3]  R1379     5.7964488863945007e-02
    z[4,2,3]  R1380     -0.312037855386734
    z[4,2,3]  R1381     2.0122438669204712e-01
    z[4,2,3]  R1382     -1.0564703494310379e-01
    z[4,2,4]  R24       1
    z[4,2,4]  R42       -1
    z[4,2,4]  R1277     -1
    z[4,2,4]  R1278     1
    z[4,2,4]  R1283     0.0576406754553318
    z[4,2,4]  R1284     -2.8113916516304016e-01
    z[4,2,4]  R1285     1.2987929582595825e-01
    z[4,2,4]  R1286     4.6343860030174255e-01
    z[4,2,4]  R1287     -0.510013222694397
    z[4,2,4]  R1288     -4.1461598873138428e-01
    z[4,2,4]  R1289     -7.2644233703613281e-01
    z[4,2,4]  R1290     0.361479789018631
    z[4,2,4]  R1291     8.6656715720891953e-03
    z[4,2,4]  R1292     -4.3161340057849884e-02
    z[4,2,4]  R1293     3.0528002977371216e-01
    z[4,2,4]  R1294     2.9022667557001114e-02
    z[4,2,4]  R1295     -1.9766373932361603e-01
    z[4,2,4]  R1296     2.7908211946487427e-01
    z[4,2,4]  R1297     2.6561075448989868e-01
    z[4,2,4]  R1298     1.1386289447546005e-01
    z[4,2,4]  R1299     -1.5815052390098572e-01
    z[4,2,4]  R1300     2.5039520859718323e-01
    z[4,2,4]  R1301     2.3188173770904541e-01
    z[4,2,4]  R1302     -8.0177605152130127e-02
    z[4,2,4]  R1303     3.8502511382102966e-01
    z[4,2,4]  R1304     2.4384586513042450e-01
    z[4,2,4]  R1305     1.8069259822368622e-01
    z[4,2,4]  R1306     3.5716065764427185e-01
    z[4,2,4]  R1307     0.376345157623291
    z[4,2,4]  R1308     -2.0123182237148285e-01
    z[4,2,4]  R1309     -1.8087539076805115e-01
    z[4,2,4]  R1310     -2.9361805319786072e-01
    z[4,2,4]  R1311     1.6702005267143250e-01
    z[4,2,4]  R1312     1.5417100489139557e-01
    z[4,2,4]  R1313     3.9853486418724060e-01
    z[4,2,4]  R1314     -1.0265780985355377e-01
    z[4,2,4]  R1315     -0.439564049243927
    z[4,2,4]  R1316     -5.2966731600463390e-03
    z[4,2,4]  R1317     -8.4944792091846466e-02
    z[4,2,4]  R1318     -3.2924994826316833e-01
    z[4,2,4]  R1319     -2.7652847766876221e-01
    z[4,2,4]  R1320     1.5353962779045105e-01
    z[4,2,4]  R1321     0.144717276096344
    z[4,2,4]  R1322     -3.5749140661209822e-03
    z[4,2,4]  R1323     4.1059872508049011e-01
    z[4,2,4]  R1324     -2.3432014882564545e-01
    z[4,2,4]  R1325     -2.3054113984107971e-01
    z[4,2,4]  R1326     9.5175974071025848e-02
    z[4,2,4]  R1327     1.5428699553012848e-01
    z[4,2,4]  R1328     -1.8565729260444641e-01
    z[4,2,4]  R1329     -2.3748582601547241e-01
    z[4,2,4]  R1330     -8.1103906035423279e-02
    z[4,2,4]  R1331     1.7757375538349152e-01
    z[4,2,4]  R1332     4.6526998281478882e-01
    z[4,2,4]  R1333     -1.1373429745435715e-01
    z[4,2,4]  R1334     8.2437492907047272e-02
    z[4,2,4]  R1335     -2.3470453917980194e-01
    z[4,2,4]  R1336     -1.1266208440065384e-01
    z[4,2,4]  R1337     -2.7110788226127625e-01
    z[4,2,4]  R1338     -3.5360220074653625e-01
    z[4,2,4]  R1339     -3.2983240485191345e-01
    z[4,2,4]  R1340     -9.7517386078834534e-02
    z[4,2,4]  R1341     -8.8615730404853821e-02
    z[4,2,4]  R1342     1.9421349465847015e-01
    z[4,2,4]  R1343     0.525259792804718
    z[4,2,4]  R1344     4.0166336297988892e-01
    z[4,2,4]  R1345     7.6657354831695557e-01
    z[4,2,4]  R1346     5.4183059930801392e-01
    z[4,2,4]  R1347     -1.5221124887466431e-01
    z[4,2,4]  R1348     -4.2753493785858154e-01
    z[4,2,4]  R1349     2.6012265682220459e-01
    z[4,2,4]  R1350     -1.6520659625530243e-01
    z[4,2,4]  R1351     -4.2838916182518005e-02
    z[4,2,4]  R1352     7.7875934541225433e-02
    z[4,2,4]  R1353     1.7025533318519592e-01
    z[4,2,4]  R1354     -2.5707101821899414e-01
    z[4,2,4]  R1355     1.9409327208995819e-01
    z[4,2,4]  R1356     -4.1895397007465363e-02
    z[4,2,4]  R1357     6.2116956710815430e-01
    z[4,2,4]  R1358     2.3017503321170807e-01
    z[4,2,4]  R1359     4.8447516560554504e-01
    z[4,2,4]  R1360     2.1125909686088562e-01
    z[4,2,4]  R1361     -1.2951073586009443e-04
    z[4,2,4]  R1362     1.1897636950016022e-01
    z[4,2,4]  R1363     -2.8945109248161316e-01
    z[4,2,4]  R1364     -1.0832422971725464e-01
    z[4,2,4]  R1365     2.0887608826160431e-01
    z[4,2,4]  R1366     8.3890803158283234e-02
    z[4,2,4]  R1367     3.4508371353149414e-01
    z[4,2,4]  R1368     1.8232037127017975e-01
    z[4,2,4]  R1369     -1.4317064546048641e-02
    z[4,2,4]  R1370     -1.6430977731943130e-02
    z[4,2,4]  R1371     -2.9563827440142632e-02
    z[4,2,4]  R1372     1.5581177175045013e-01
    z[4,2,4]  R1373     4.5532783865928650e-01
    z[4,2,4]  R1374     -5.0584875047206879e-02
    z[4,2,4]  R1375     1.6250425577163696e-01
    z[4,2,4]  R1376     -7.6470471918582916e-02
    z[4,2,4]  R1377     2.8865805268287659e-01
    z[4,2,4]  R1378     1.6766466200351715e-01
    z[4,2,4]  R1379     4.0400851517915726e-02
    z[4,2,4]  R1380     -1.3726890087127686e-01
    z[4,2,4]  R1381     -1.5371577441692352e-01
    z[4,2,4]  R1382     2.8815966844558716e-01
    z[4,2,5]  R25       1
    z[4,2,5]  R43       -1
    z[4,2,5]  R1279     -1
    z[4,2,5]  R1280     1
    z[4,2,5]  R1283     -2.5419354438781738e-01
    z[4,2,5]  R1284     5.5253233760595322e-02
    z[4,2,5]  R1285     -3.6885783076286316e-02
    z[4,2,5]  R1286     -2.2479355335235596e-01
    z[4,2,5]  R1287     -6.6237091086804867e-03
    z[4,2,5]  R1288     -4.9201363325119019e-01
    z[4,2,5]  R1289     -3.0697554349899292e-01
    z[4,2,5]  R1290     -5.5386364459991455e-01
    z[4,2,5]  R1291     0.341463178396225
    z[4,2,5]  R1292     2.4733063578605652e-01
    z[4,2,5]  R1293     -5.3956888616085052e-02
    z[4,2,5]  R1294     -1.4479069411754608e-01
    z[4,2,5]  R1295     2.7465509250760078e-02
    z[4,2,5]  R1296     2.3230038583278656e-02
    z[4,2,5]  R1297     -1.4664037525653839e-01
    z[4,2,5]  R1298     -2.1142846345901489e-01
    z[4,2,5]  R1299     3.5193203948438168e-03
    z[4,2,5]  R1300     -2.8943467140197754e-01
    z[4,2,5]  R1301     1.2393782287836075e-01
    z[4,2,5]  R1302     0.0698886290192604
    z[4,2,5]  R1303     -7.6179319620132446e-01
    z[4,2,5]  R1304     1.6764022409915924e-01
    z[4,2,5]  R1305     5.3217488527297974e-01
    z[4,2,5]  R1306     4.8674359917640686e-01
    z[4,2,5]  R1307     4.7387725114822388e-01
    z[4,2,5]  R1308     2.3500698804855347e-01
    z[4,2,5]  R1309     -4.2441502213478088e-02
    z[4,2,5]  R1310     -3.1275925040245056e-01
    z[4,2,5]  R1311     -1.8474724143743515e-02
    z[4,2,5]  R1312     1.6109757125377655e-01
    z[4,2,5]  R1313     -9.8054654896259308e-02
    z[4,2,5]  R1314     -1.2702740728855133e-01
    z[4,2,5]  R1315     -8.6095677688717842e-03
    z[4,2,5]  R1316     -2.8188601136207581e-01
    z[4,2,5]  R1317     -4.4874340295791626e-02
    z[4,2,5]  R1318     3.7709128856658936e-01
    z[4,2,5]  R1319     -2.0452212542295456e-02
    z[4,2,5]  R1320     1.1788973212242126e-01
    z[4,2,5]  R1321     -6.4595431089401245e-02
    z[4,2,5]  R1322     2.1863219141960144e-01
    z[4,2,5]  R1323     5.1559224724769592e-02
    z[4,2,5]  R1324     2.0553177595138550e-01
    z[4,2,5]  R1325     -1.7279775440692902e-01
    z[4,2,5]  R1326     -1.7816193401813507e-01
    z[4,2,5]  R1327     -8.2208685576915741e-02
    z[4,2,5]  R1328     1.6701954603195190e-01
    z[4,2,5]  R1329     -6.9015175104141235e-02
    z[4,2,5]  R1330     2.7071535587310791e-02
    z[4,2,5]  R1331     1.9414480030536652e-01
    z[4,2,5]  R1332     3.5885747522115707e-02
    z[4,2,5]  R1333     -5.6261110305786133e-01
    z[4,2,5]  R1334     -4.5188632607460022e-01
    z[4,2,5]  R1335     4.7491684556007385e-02
    z[4,2,5]  R1336     1.0402470082044601e-01
    z[4,2,5]  R1337     -6.2023870646953583e-02
    z[4,2,5]  R1338     -1.0046847164630890e-02
    z[4,2,5]  R1339     -2.1654093638062477e-02
    z[4,2,5]  R1340     -3.4643489122390747e-01
    z[4,2,5]  R1341     -3.7767979502677917e-01
    z[4,2,5]  R1342     -1.7442518472671509e-01
    z[4,2,5]  R1343     3.4574168920516968e-01
    z[4,2,5]  R1344     -5.5439078807830811e-01
    z[4,2,5]  R1345     -2.3657123744487762e-01
    z[4,2,5]  R1346     2.0953471958637238e-01
    z[4,2,5]  R1347     0.50971519947052
    z[4,2,5]  R1348     2.0126949250698090e-01
    z[4,2,5]  R1349     -8.6231883615255356e-03
    z[4,2,5]  R1350     6.8229717016220093e-01
    z[4,2,5]  R1351     4.6939301490783691e-01
    z[4,2,5]  R1352     4.2282477021217346e-01
    z[4,2,5]  R1353     6.1182837933301926e-02
    z[4,2,5]  R1354     -1.1985354125499725e-01
    z[4,2,5]  R1355     8.6183302104473114e-02
    z[4,2,5]  R1356     2.4325927719473839e-02
    z[4,2,5]  R1357     1.0157548636198044e-01
    z[4,2,5]  R1358     4.8351404070854187e-01
    z[4,2,5]  R1359     8.5496142506599426e-02
    z[4,2,5]  R1360     4.2921945452690125e-01
    z[4,2,5]  R1361     -1.6942197084426880e-01
    z[4,2,5]  R1362     2.2209188342094421e-01
    z[4,2,5]  R1363     -1.5760114416480064e-02
    z[4,2,5]  R1364     0.0844428762793541
    z[4,2,5]  R1365     2.1522009372711182e-01
    z[4,2,5]  R1366     -5.1006329059600830e-01
    z[4,2,5]  R1367     -2.1311371028423309e-01
    z[4,2,5]  R1368     1.6942206025123596e-01
    z[4,2,5]  R1369     -3.9063182473182678e-01
    z[4,2,5]  R1370     2.0191356539726257e-01
    z[4,2,5]  R1371     2.2902959585189819e-01
    z[4,2,5]  R1372     -5.8947563171386719e-02
    z[4,2,5]  R1373     -4.1749498248100281e-01
    z[4,2,5]  R1374     -3.7870484590530396e-01
    z[4,2,5]  R1375     -0.415229469537735
    z[4,2,5]  R1376     -0.0883241817355156
    z[4,2,5]  R1377     4.2321172356605530e-01
    z[4,2,5]  R1378     1.6260632872581482e-01
    z[4,2,5]  R1379     0.0569465234875679
    z[4,2,5]  R1380     -1.6966991126537323e-01
    z[4,2,5]  R1381     -3.0250322818756104e-01
    z[4,2,5]  R1382     3.7471261620521545e-01
    z[4,2,6]  R26       1
    z[4,2,6]  R44       -1
    z[4,2,6]  R1281     -1
    z[4,2,6]  R1282     1
    z[4,2,6]  R1283     -5.9919780492782593e-01
    z[4,2,6]  R1284     6.0451114177703857e-01
    z[4,2,6]  R1285     -4.3199202418327332e-01
    z[4,2,6]  R1286     -1.0879322141408920e-01
    z[4,2,6]  R1287     -0.241790771484375
    z[4,2,6]  R1288     2.7485761046409607e-01
    z[4,2,6]  R1289     -3.1329923868179321e-01
    z[4,2,6]  R1290     4.0665698051452637e-01
    z[4,2,6]  R1291     2.0220498740673065e-01
    z[4,2,6]  R1292     -5.0999283790588379e-02
    z[4,2,6]  R1293     2.9861494898796082e-02
    z[4,2,6]  R1294     5.4020345211029053e-02
    z[4,2,6]  R1295     -2.0257534086704254e-01
    z[4,2,6]  R1296     -1.6104483604431152e-01
    z[4,2,6]  R1297     -1.4829909801483154e-01
    z[4,2,6]  R1298     3.2283014059066772e-01
    z[4,2,6]  R1299     -3.5510218143463135e-01
    z[4,2,6]  R1300     1.5719279646873474e-01
    z[4,2,6]  R1301     2.6076811552047729e-01
    z[4,2,6]  R1302     3.7825204432010651e-02
    z[4,2,6]  R1303     2.9783040285110474e-02
    z[4,2,6]  R1304     -1.9978380203247070e-01
    z[4,2,6]  R1305     9.6700891852378845e-02
    z[4,2,6]  R1306     -6.1911858618259430e-02
    z[4,2,6]  R1307     6.2522336840629578e-02
    z[4,2,6]  R1308     2.1353588998317719e-01
    z[4,2,6]  R1309     -2.8371039032936096e-01
    z[4,2,6]  R1310     1.0625831037759781e-01
    z[4,2,6]  R1311     0.0215000007301569
    z[4,2,6]  R1312     1.2924927473068237e-01
    z[4,2,6]  R1313     -2.9671558737754822e-01
    z[4,2,6]  R1314     1.0736639797687531e-01
    z[4,2,6]  R1315     1.3117294013500214e-01
    z[4,2,6]  R1316     1.6855685412883759e-01
    z[4,2,6]  R1317     0.0594826303422451
    z[4,2,6]  R1318     5.6614372879266739e-03
    z[4,2,6]  R1319     2.8335985541343689e-01
    z[4,2,6]  R1320     1.4543295837938786e-02
    z[4,2,6]  R1321     3.5334545373916626e-01
    z[4,2,6]  R1322     9.2243090271949768e-02
    z[4,2,6]  R1323     1.8549966812133789e-01
    z[4,2,6]  R1324     4.8253691196441650e-01
    z[4,2,6]  R1325     1.7592176795005798e-01
    z[4,2,6]  R1326     4.6619750559329987e-02
    z[4,2,6]  R1327     -3.9099924266338348e-02
    z[4,2,6]  R1328     2.9522067308425903e-01
    z[4,2,6]  R1329     -2.4551825225353241e-01
    z[4,2,6]  R1330     -1.6466338932514191e-01
    z[4,2,6]  R1331     2.1250389516353607e-02
    z[4,2,6]  R1332     -1.3845956325531006e-01
    z[4,2,6]  R1333     -2.4012371897697449e-01
    z[4,2,6]  R1334     -4.7786796092987061e-01
    z[4,2,6]  R1335     -3.2327172160148621e-01
    z[4,2,6]  R1336     0.266877144575119
    z[4,2,6]  R1337     -5.2893865853548050e-02
    z[4,2,6]  R1338     -9.8525643348693848e-02
    z[4,2,6]  R1339     3.1339146196842194e-02
    z[4,2,6]  R1340     1.8047126010060310e-02
    z[4,2,6]  R1341     -2.8784683346748352e-01
    z[4,2,6]  R1342     2.2689154744148254e-01
    z[4,2,6]  R1343     -2.5508137419819832e-02
    z[4,2,6]  R1344     5.3439790010452271e-01
    z[4,2,6]  R1345     -1.0268667340278625e-01
    z[4,2,6]  R1346     -3.8092023134231567e-01
    z[4,2,6]  R1347     0.0318525955080986
    z[4,2,6]  R1348     -1.4917287230491638e-01
    z[4,2,6]  R1349     7.3223048448562622e-01
    z[4,2,6]  R1350     -1.7481561005115509e-01
    z[4,2,6]  R1351     6.6362321376800537e-01
    z[4,2,6]  R1352     2.5549495220184326e-01
    z[4,2,6]  R1353     -1.6688092052936554e-01
    z[4,2,6]  R1354     -4.5651599764823914e-02
    z[4,2,6]  R1355     2.2808927297592163e-01
    z[4,2,6]  R1356     -1.2586400844156742e-02
    z[4,2,6]  R1357     3.8680014014244080e-01
    z[4,2,6]  R1358     -2.9306897521018982e-01
    z[4,2,6]  R1359     -1.7781928181648254e-01
    z[4,2,6]  R1360     0.344841331243515
    z[4,2,6]  R1361     -1.3751790858805180e-02
    z[4,2,6]  R1362     -0.413039892911911
    z[4,2,6]  R1363     3.5972705483436584e-01
    z[4,2,6]  R1364     -3.1692448258399963e-01
    z[4,2,6]  R1365     4.4062426686286926e-01
    z[4,2,6]  R1366     1.4996452629566193e-01
    z[4,2,6]  R1367     1.2894116342067719e-01
    z[4,2,6]  R1368     3.3351856470108032e-01
    z[4,2,6]  R1369     -1.2531548738479614e-02
    z[4,2,6]  R1370     -3.5553896427154541e-01
    z[4,2,6]  R1371     1.3812610507011414e-01
    z[4,2,6]  R1372     1.3690458238124847e-01
    z[4,2,6]  R1373     -3.0597314238548279e-01
    z[4,2,6]  R1374     -1.6123616695404053e-01
    z[4,2,6]  R1375     1.7207552492618561e-01
    z[4,2,6]  R1376     5.1867133378982544e-01
    z[4,2,6]  R1377     4.6384155750274658e-01
    z[4,2,6]  R1378     2.1356520056724548e-01
    z[4,2,6]  R1379     4.2806592583656311e-01
    z[4,2,6]  R1380     1.4733320474624634e-01
    z[4,2,6]  R1381     -3.1754586845636368e-02
    z[4,2,6]  R1382     2.4821478128433228e-01
    z[2,5,0]  R20       -1
    z[2,5,0]  R47       1
    z[2,5,0]  R1383     -1
    z[2,5,0]  R1384     1
    z[2,5,0]  R1397     -3.7761595845222473e-01
    z[2,5,0]  R1398     -2.6884365081787109e-01
    z[2,5,0]  R1399     7.9843342304229736e-01
    z[2,5,0]  R1400     8.7542468309402466e-01
    z[2,5,0]  R1401     8.4131413698196411e-01
    z[2,5,0]  R1402     0.419920414686203
    z[2,5,0]  R1403     0.285171240568161
    z[2,5,0]  R1404     3.6918950080871582e-01
    z[2,5,0]  R1405     6.9000291824340820e-01
    z[2,5,0]  R1406     6.2999832630157471e-01
    z[2,5,0]  R1407     -3.1384840607643127e-01
    z[2,5,0]  R1408     -2.1706500649452209e-01
    z[2,5,0]  R1409     1.7495959997177124e-01
    z[2,5,0]  R1410     3.1879001855850220e-01
    z[2,5,0]  R1411     2.0410983264446259e-01
    z[2,5,0]  R1412     0.538845419883728
    z[2,5,0]  R1413     4.7156815417110920e-03
    z[2,5,0]  R1414     5.1173609495162964e-01
    z[2,5,0]  R1415     3.5414862632751465e-01
    z[2,5,0]  R1416     1.5112403035163879e-01
    z[2,5,0]  R1417     3.5378584265708923e-01
    z[2,5,0]  R1418     -7.7039031311869621e-03
    z[2,5,0]  R1419     5.1625329256057739e-01
    z[2,5,0]  R1420     5.4666346311569214e-01
    z[2,5,0]  R1421     -2.4800196290016174e-01
    z[2,5,0]  R1422     4.0988841652870178e-01
    z[2,5,0]  R1423     3.5897067189216614e-01
    z[2,5,0]  R1424     6.8418520689010620e-01
    z[2,5,0]  R1425     5.2593183517456055e-01
    z[2,5,0]  R1426     3.0959594249725342e-01
    z[2,5,0]  R1427     -3.0739870667457581e-01
    z[2,5,0]  R1428     -5.9899266809225082e-02
    z[2,5,0]  R1429     5.0955039262771606e-01
    z[2,5,0]  R1430     6.1493802070617676e-01
    z[2,5,0]  R1431     0.53638756275177
    z[2,5,0]  R1432     6.5523380041122437e-01
    z[2,5,0]  R1433     2.7248516678810120e-01
    z[2,5,0]  R1434     3.8072407245635986e-01
    z[2,5,0]  R1435     8.6608707904815674e-01
    z[2,5,0]  R1436     5.1091867685317993e-01
    z[2,5,0]  R1437     -4.8466438055038452e-01
    z[2,5,0]  R1438     -2.2906814515590668e-01
    z[2,5,0]  R1439     -1.3635233044624329e-02
    z[2,5,0]  R1440     9.6427626907825470e-02
    z[2,5,0]  R1441     4.2372739315032959e-01
    z[2,5,0]  R1442     5.4470956325531006e-01
    z[2,5,0]  R1443     6.6702020168304443e-01
    z[2,5,0]  R1444     5.1377475261688232e-02
    z[2,5,0]  R1445     7.0297127962112427e-01
    z[2,5,0]  R1446     7.1857148408889771e-01
    z[2,5,0]  R1447     6.5863317251205444e-01
    z[2,5,0]  R1448     3.5136952996253967e-01
    z[2,5,0]  R1449     4.5002645254135132e-01
    z[2,5,0]  R1450     -1.8709459900856018e-01
    z[2,5,0]  R1451     -6.0926965670660138e-04
    z[2,5,0]  R1452     5.3828325122594833e-02
    z[2,5,0]  R1453     -5.7057225704193115e-01
    z[2,5,0]  R1454     -9.6037723124027252e-02
    z[2,5,0]  R1455     -4.0170863270759583e-01
    z[2,5,0]  R1456     -4.4690504670143127e-01
    z[2,5,0]  R1457     2.4390691518783569e-01
    z[2,5,0]  R1458     -1.6205526888370514e-01
    z[2,5,0]  R1459     -4.1034218668937683e-01
    z[2,5,0]  R1460     -0.491395503282547
    z[2,5,0]  R1461     -5.4686480760574341e-01
    z[2,5,0]  R1462     7.1733094751834869e-02
    z[2,5,0]  R1463     3.0037495493888855e-01
    z[2,5,0]  R1464     1.6303683817386627e-01
    z[2,5,0]  R1465     3.2199257612228394e-01
    z[2,5,0]  R1466     5.4086589813232422e-01
    z[2,5,0]  R1467     -9.2967316508293152e-02
    z[2,5,0]  R1468     -8.6629527807235718e-01
    z[2,5,0]  R1469     -8.9378046989440918e-01
    z[2,5,0]  R1470     -6.3994240760803223e-01
    z[2,5,0]  R1471     -7.6945525407791138e-01
    z[2,5,0]  R1472     -6.9138383865356445e-01
    z[2,5,0]  R1473     -3.5067155957221985e-01
    z[2,5,0]  R1474     4.1472426056861877e-01
    z[2,5,0]  R1475     4.9624881148338318e-01
    z[2,5,0]  R1476     5.4533189535140991e-01
    z[2,5,1]  R21       -1
    z[2,5,1]  R48       1
    z[2,5,1]  R1385     -1
    z[2,5,1]  R1386     1
    z[2,5,1]  R1397     3.8441542536020279e-02
    z[2,5,1]  R1398     8.1759430468082428e-02
    z[2,5,1]  R1399     -4.0119934082031250e-01
    z[2,5,1]  R1400     -2.3960407078266144e-01
    z[2,5,1]  R1401     -3.0244883894920349e-01
    z[2,5,1]  R1402     -0.802794873714447
    z[2,5,1]  R1403     -8.8745057582855225e-01
    z[2,5,1]  R1404     -0.754834771156311
    z[2,5,1]  R1405     -3.9399498701095581e-01
    z[2,5,1]  R1406     8.5442259907722473e-02
    z[2,5,1]  R1407     5.6618911027908325e-01
    z[2,5,1]  R1408     2.3656965792179108e-01
    z[2,5,1]  R1409     5.4735934734344482e-01
    z[2,5,1]  R1410     4.4414228200912476e-01
    z[2,5,1]  R1411     6.6778522729873657e-01
    z[2,5,1]  R1412     6.4470344781875610e-01
    z[2,5,1]  R1413     4.5176360011100769e-01
    z[2,5,1]  R1414     3.9058855175971985e-01
    z[2,5,1]  R1415     4.3951633572578430e-01
    z[2,5,1]  R1416     6.5985703468322754e-01
    z[2,5,1]  R1417     2.5097227096557617e-01
    z[2,5,1]  R1418     0.688449501991272
    z[2,5,1]  R1419     4.6634155511856079e-01
    z[2,5,1]  R1420     -6.1167693138122559e-01
    z[2,5,1]  R1421     -5.3506873548030853e-02
    z[2,5,1]  R1422     -6.4141339063644409e-01
    z[2,5,1]  R1423     -7.2092831134796143e-01
    z[2,5,1]  R1424     -3.9164590835571289e-01
    z[2,5,1]  R1425     -6.4713460206985474e-01
    z[2,5,1]  R1426     -6.1470401287078857e-01
    z[2,5,1]  R1427     8.1374222040176392e-01
    z[2,5,1]  R1428     8.5356724262237549e-01
    z[2,5,1]  R1429     -6.6358691453933716e-01
    z[2,5,1]  R1430     -5.5984467267990112e-01
    z[2,5,1]  R1431     -6.9038879871368408e-01
    z[2,5,1]  R1432     -4.7251582145690918e-01
    z[2,5,1]  R1433     -7.4744731187820435e-01
    z[2,5,1]  R1434     -6.1545717716217041e-01
    z[2,5,1]  R1435     -3.5275623202323914e-01
    z[2,5,1]  R1436     -4.5408290624618530e-01
    z[2,5,1]  R1437     -3.5253381729125977e-01
    z[2,5,1]  R1438     8.0153006315231323e-01
    z[2,5,1]  R1439     8.7071365118026733e-01
    z[2,5,1]  R1440     5.4113519191741943e-01
    z[2,5,1]  R1441     5.0517255067825317e-01
    z[2,5,1]  R1442     0.586051881313324
    z[2,5,1]  R1443     5.4306948184967041e-01
    z[2,5,1]  R1444     8.1572657823562622e-01
    z[2,5,1]  R1445     -3.9696505665779114e-01
    z[2,5,1]  R1446     -2.6708725094795227e-01
    z[2,5,1]  R1447     3.5655662417411804e-02
    z[2,5,1]  R1448     -6.8967863917350769e-02
    z[2,5,1]  R1449     3.3862382173538208e-02
    z[2,5,1]  R1450     1.3009256124496460e-01
    z[2,5,1]  R1451     7.6676271855831146e-02
    z[2,5,1]  R1452     1.8855138123035431e-01
    z[2,5,1]  R1453     1.0348648577928543e-01
    z[2,5,1]  R1454     1.7468252778053284e-01
    z[2,5,1]  R1455     4.8111043870449066e-03
    z[2,5,1]  R1456     -5.5101740360260010e-01
    z[2,5,1]  R1457     3.6529025435447693e-01
    z[2,5,1]  R1458     5.0101137161254883e-01
    z[2,5,1]  R1459     2.3997753858566284e-01
    z[2,5,1]  R1460     6.4626473188400269e-01
    z[2,5,1]  R1461     -2.7780082821846008e-01
    z[2,5,1]  R1462     5.2693653106689453e-01
    z[2,5,1]  R1463     2.0449882745742798e-01
    z[2,5,1]  R1464     2.8308564424514771e-01
    z[2,5,1]  R1465     1.5430007874965668e-01
    z[2,5,1]  R1466     -6.8047416210174561e-01
    z[2,5,1]  R1467     7.3471927642822266e-01
    z[2,5,1]  R1468     -3.5882565379142761e-01
    z[2,5,1]  R1469     -1.5928235650062561e-01
    z[2,5,1]  R1470     7.7059499919414520e-02
    z[2,5,1]  R1471     0.0466160774230957
    z[2,5,1]  R1472     -2.1337196230888367e-01
    z[2,5,1]  R1473     -2.3984816670417786e-01
    z[2,5,1]  R1474     3.0023759603500366e-01
    z[2,5,1]  R1475     -7.8539723157882690e-01
    z[2,5,1]  R1476     -6.9796615839004517e-01
    z[2,5,2]  R22       -1
    z[2,5,2]  R49       1
    z[2,5,2]  R1387     -1
    z[2,5,2]  R1388     1
    z[2,5,2]  R1397     7.4965290725231171e-02
    z[2,5,2]  R1398     0.681813657283783
    z[2,5,2]  R1399     1.4072988927364349e-01
    z[2,5,2]  R1400     1.7492705583572388e-01
    z[2,5,2]  R1401     1.3756878674030304e-02
    z[2,5,2]  R1402     -1.7958280444145203e-01
    z[2,5,2]  R1403     -3.4977486357092857e-03
    z[2,5,2]  R1404     1.0772727429866791e-01
    z[2,5,2]  R1405     3.0122503638267517e-01
    z[2,5,2]  R1406     5.3374260663986206e-01
    z[2,5,2]  R1407     3.3036175370216370e-01
    z[2,5,2]  R1408     -1.0271928459405899e-01
    z[2,5,2]  R1409     3.5235092509537935e-03
    z[2,5,2]  R1410     -1.6434369981288910e-01
    z[2,5,2]  R1411     -3.0935943126678467e-01
    z[2,5,2]  R1412     2.0727092027664185e-01
    z[2,5,2]  R1413     -3.2779264450073242e-01
    z[2,5,2]  R1414     2.4899050593376160e-01
    z[2,5,2]  R1415     -9.0174794197082520e-02
    z[2,5,2]  R1416     -1.8114100396633148e-01
    z[2,5,2]  R1417     7.9812347888946533e-01
    z[2,5,2]  R1418     6.2663513422012329e-01
    z[2,5,2]  R1419     4.0392029285430908e-01
    z[2,5,2]  R1420     -7.3203317821025848e-02
    z[2,5,2]  R1421     2.7970877289772034e-01
    z[2,5,2]  R1422     1.5855786204338074e-01
    z[2,5,2]  R1423     2.7109023928642273e-01
    z[2,5,2]  R1424     -1.7429442703723907e-01
    z[2,5,2]  R1425     -5.2469903230667114e-01
    z[2,5,2]  R1426     2.7236273884773254e-01
    z[2,5,2]  R1427     -1.1220594495534897e-01
    z[2,5,2]  R1428     -3.8480564951896667e-01
    z[2,5,2]  R1429     2.0183211192488670e-02
    z[2,5,2]  R1430     2.4744583293795586e-02
    z[2,5,2]  R1431     -2.3151947557926178e-01
    z[2,5,2]  R1432     -2.6929610967636108e-01
    z[2,5,2]  R1433     3.4785324335098267e-01
    z[2,5,2]  R1434     4.8382428288459778e-01
    z[2,5,2]  R1435     2.1594485267996788e-02
    z[2,5,2]  R1436     -2.0730255171656609e-02
    z[2,5,2]  R1437     1.1036302149295807e-01
    z[2,5,2]  R1438     3.5348507761955261e-01
    z[2,5,2]  R1439     0.0318136028945446
    z[2,5,2]  R1440     5.4831538349390030e-02
    z[2,5,2]  R1441     4.4717624783515930e-02
    z[2,5,2]  R1442     -1.7602179944515228e-01
    z[2,5,2]  R1443     2.6207652688026428e-01
    z[2,5,2]  R1444     -4.0650373697280884e-01
    z[2,5,2]  R1445     4.3773704767227173e-01
    z[2,5,2]  R1446     3.4073731303215027e-01
    z[2,5,2]  R1447     4.9690103530883789e-01
    z[2,5,2]  R1448     5.6668418645858765e-01
    z[2,5,2]  R1449     0.788059413433075
    z[2,5,2]  R1450     4.3211534619331360e-01
    z[2,5,2]  R1451     8.6823272705078125e-01
    z[2,5,2]  R1452     5.7285249233245850e-01
    z[2,5,2]  R1453     -5.4072532802820206e-02
    z[2,5,2]  R1454     -7.0453107357025146e-02
    z[2,5,2]  R1455     -2.5815838575363159e-01
    z[2,5,2]  R1456     2.3707246780395508e-01
    z[2,5,2]  R1457     -3.4773632884025574e-01
    z[2,5,2]  R1458     -4.4258171319961548e-01
    z[2,5,2]  R1459     -2.0929503440856934e-01
    z[2,5,2]  R1460     0.0709293782711029
    z[2,5,2]  R1461     -6.5322893857955933e-01
    z[2,5,2]  R1462     -1.1875462532043457e-01
    z[2,5,2]  R1463     -3.9269593358039856e-01
    z[2,5,2]  R1464     -4.7192507982254028e-01
    z[2,5,2]  R1465     -3.8370156288146973e-01
    z[2,5,2]  R1466     -2.9528501629829407e-01
    z[2,5,2]  R1467     1.4096125960350037e-01
    z[2,5,2]  R1468     -1.0095614194869995e-01
    z[2,5,2]  R1469     1.3848142325878143e-01
    z[2,5,2]  R1470     -3.6666259169578552e-01
    z[2,5,2]  R1471     -3.1680583953857422e-01
    z[2,5,2]  R1472     -0.0551447868347168
    z[2,5,2]  R1473     -4.8404029011726379e-01
    z[2,5,2]  R1474     -3.7091752886772156e-01
    z[2,5,2]  R1475     -1.7900729179382324e-01
    z[2,5,2]  R1476     -1.5813142061233521e-01
    z[2,5,3]  R23       -1
    z[2,5,3]  R50       1
    z[2,5,3]  R1389     -1
    z[2,5,3]  R1390     1
    z[2,5,3]  R1397     -6.8057513236999512e-01
    z[2,5,3]  R1398     1.2966774404048920e-01
    z[2,5,3]  R1399     1.4103873074054718e-01
    z[2,5,3]  R1400     2.2557689249515533e-01
    z[2,5,3]  R1401     3.4696063399314880e-01
    z[2,5,3]  R1402     1.0997498035430908e-01
    z[2,5,3]  R1403     -1.4441721141338348e-01
    z[2,5,3]  R1404     -3.9046889543533325e-01
    z[2,5,3]  R1405     2.1113230288028717e-01
    z[2,5,3]  R1406     -4.3737614154815674e-01
    z[2,5,3]  R1407     -0.275144100189209
    z[2,5,3]  R1408     3.6345925927162170e-01
    z[2,5,3]  R1409     -1.2501551210880280e-01
    z[2,5,3]  R1410     -4.3762576580047607e-01
    z[2,5,3]  R1411     -3.6428907513618469e-01
    z[2,5,3]  R1412     7.4119992554187775e-02
    z[2,5,3]  R1413     -2.9075714945793152e-01
    z[2,5,3]  R1414     -1.3685405254364014e-02
    z[2,5,3]  R1415     -1.0349833220243454e-01
    z[2,5,3]  R1416     5.0873857736587524e-01
    z[2,5,3]  R1417     -3.3803546428680420e-01
    z[2,5,3]  R1418     2.2532603144645691e-01
    z[2,5,3]  R1419     5.0569951534271240e-01
    z[2,5,3]  R1420     5.6493043899536133e-01
    z[2,5,3]  R1421     -5.5822163820266724e-01
    z[2,5,3]  R1422     1.5094357728958130e-01
    z[2,5,3]  R1423     -6.5323412418365479e-02
    z[2,5,3]  R1424     1.8714305013418198e-02
    z[2,5,3]  R1425     2.0260209217667580e-02
    z[2,5,3]  R1426     -4.6693214774131775e-01
    z[2,5,3]  R1427     1.3155084848403931e-01
    z[2,5,3]  R1428     0.0213027261197567
    z[2,5,3]  R1429     -1.2451861053705215e-01
    z[2,5,3]  R1430     1.3461527228355408e-01
    z[2,5,3]  R1431     -3.0403189361095428e-02
    z[2,5,3]  R1432     -3.1890103220939636e-01
    z[2,5,3]  R1433     3.0515128374099731e-01
    z[2,5,3]  R1434     -2.7336540818214417e-01
    z[2,5,3]  R1435     -2.2930863499641418e-01
    z[2,5,3]  R1436     -6.9702661037445068e-01
    z[2,5,3]  R1437     3.9165702462196350e-01
    z[2,5,3]  R1438     9.0290986001491547e-02
    z[2,5,3]  R1439     1.1057351529598236e-01
    z[2,5,3]  R1440     -6.4202737808227539e-01
    z[2,5,3]  R1441     -2.9270380735397339e-01
    z[2,5,3]  R1442     -4.7821402549743652e-01
    z[2,5,3]  R1443     5.7964488863945007e-02
    z[2,5,3]  R1444     -0.312037855386734
    z[2,5,3]  R1445     2.0122438669204712e-01
    z[2,5,3]  R1446     -1.0564703494310379e-01
    z[2,5,3]  R1447     -5.0862443447113037e-01
    z[2,5,3]  R1448     2.7938507497310638e-02
    z[2,5,3]  R1449     -1.6678662598133087e-01
    z[2,5,3]  R1450     1.1506868898868561e-01
    z[2,5,3]  R1451     -1.8325862288475037e-01
    z[2,5,3]  R1452     6.6361993551254272e-01
    z[2,5,3]  R1453     0.674699068069458
    z[2,5,3]  R1454     4.8612591624259949e-01
    z[2,5,3]  R1455     4.2541259527206421e-01
    z[2,5,3]  R1456     5.2751320600509644e-01
    z[2,5,3]  R1457     -2.3076803982257843e-01
    z[2,5,3]  R1458     -5.7352638244628906e-01
    z[2,5,3]  R1459     -7.9003876447677612e-01
    z[2,5,3]  R1460     -1.9347956776618958e-01
    z[2,5,3]  R1461     1.0992675274610519e-01
    z[2,5,3]  R1462     0.453823983669281
    z[2,5,3]  R1463     -1.9309048354625702e-01
    z[2,5,3]  R1464     1.9135428592562675e-02
    z[2,5,3]  R1465     -2.6681306958198547e-01
    z[2,5,3]  R1466     1.7161494493484497e-01
    z[2,5,3]  R1467     4.4192460179328918e-01
    z[2,5,3]  R1468     0.290324866771698
    z[2,5,3]  R1469     2.8379639983177185e-01
    z[2,5,3]  R1470     4.4903361797332764e-01
    z[2,5,3]  R1471     4.4476497173309326e-01
    z[2,5,3]  R1472     4.6124801039695740e-01
    z[2,5,3]  R1473     7.2298157215118408e-01
    z[2,5,3]  R1474     3.6498349905014038e-01
    z[2,5,3]  R1475     0.132520392537117
    z[2,5,3]  R1476     0.301140159368515
    z[2,5,4]  R24       -1
    z[2,5,4]  R51       1
    z[2,5,4]  R1391     -1
    z[2,5,4]  R1392     1
    z[2,5,4]  R1397     -1.1373429745435715e-01
    z[2,5,4]  R1398     8.2437492907047272e-02
    z[2,5,4]  R1399     -2.3470453917980194e-01
    z[2,5,4]  R1400     -1.1266208440065384e-01
    z[2,5,4]  R1401     -2.7110788226127625e-01
    z[2,5,4]  R1402     -3.5360220074653625e-01
    z[2,5,4]  R1403     -3.2983240485191345e-01
    z[2,5,4]  R1404     -9.7517386078834534e-02
    z[2,5,4]  R1405     -8.8615730404853821e-02
    z[2,5,4]  R1406     1.9421349465847015e-01
    z[2,5,4]  R1407     0.525259792804718
    z[2,5,4]  R1408     4.0166336297988892e-01
    z[2,5,4]  R1409     7.6657354831695557e-01
    z[2,5,4]  R1410     5.4183059930801392e-01
    z[2,5,4]  R1411     -1.5221124887466431e-01
    z[2,5,4]  R1412     -4.2753493785858154e-01
    z[2,5,4]  R1413     2.6012265682220459e-01
    z[2,5,4]  R1414     -1.6520659625530243e-01
    z[2,5,4]  R1415     -4.2838916182518005e-02
    z[2,5,4]  R1416     7.7875934541225433e-02
    z[2,5,4]  R1417     1.7025533318519592e-01
    z[2,5,4]  R1418     -2.5707101821899414e-01
    z[2,5,4]  R1419     1.9409327208995819e-01
    z[2,5,4]  R1420     -4.1895397007465363e-02
    z[2,5,4]  R1421     6.2116956710815430e-01
    z[2,5,4]  R1422     2.3017503321170807e-01
    z[2,5,4]  R1423     4.8447516560554504e-01
    z[2,5,4]  R1424     2.1125909686088562e-01
    z[2,5,4]  R1425     -1.2951073586009443e-04
    z[2,5,4]  R1426     1.1897636950016022e-01
    z[2,5,4]  R1427     -2.8945109248161316e-01
    z[2,5,4]  R1428     -1.0832422971725464e-01
    z[2,5,4]  R1429     2.0887608826160431e-01
    z[2,5,4]  R1430     8.3890803158283234e-02
    z[2,5,4]  R1431     3.4508371353149414e-01
    z[2,5,4]  R1432     1.8232037127017975e-01
    z[2,5,4]  R1433     -1.4317064546048641e-02
    z[2,5,4]  R1434     -1.6430977731943130e-02
    z[2,5,4]  R1435     -2.9563827440142632e-02
    z[2,5,4]  R1436     1.5581177175045013e-01
    z[2,5,4]  R1437     4.5532783865928650e-01
    z[2,5,4]  R1438     -5.0584875047206879e-02
    z[2,5,4]  R1439     1.6250425577163696e-01
    z[2,5,4]  R1440     -7.6470471918582916e-02
    z[2,5,4]  R1441     2.8865805268287659e-01
    z[2,5,4]  R1442     1.6766466200351715e-01
    z[2,5,4]  R1443     4.0400851517915726e-02
    z[2,5,4]  R1444     -1.3726890087127686e-01
    z[2,5,4]  R1445     -1.5371577441692352e-01
    z[2,5,4]  R1446     2.8815966844558716e-01
    z[2,5,4]  R1447     1.7950442433357239e-01
    z[2,5,4]  R1448     0.481612890958786
    z[2,5,4]  R1449     -6.2043469399213791e-02
    z[2,5,4]  R1450     1.0086730867624283e-01
    z[2,5,4]  R1451     -4.4408363103866577e-01
    z[2,5,4]  R1452     -1.0774364322423935e-01
    z[2,5,4]  R1453     2.2905133664608002e-01
    z[2,5,4]  R1454     5.6224584579467773e-01
    z[2,5,4]  R1455     -3.8214331865310669e-01
    z[2,5,4]  R1456     -1.6736510396003723e-01
    z[2,5,4]  R1457     6.4547348022460938e-01
    z[2,5,4]  R1458     3.7332189083099365e-01
    z[2,5,4]  R1459     9.3645811080932617e-02
    z[2,5,4]  R1460     4.4748380780220032e-01
    z[2,5,4]  R1461     -2.1066750586032867e-01
    z[2,5,4]  R1462     -7.4922956526279449e-02
    z[2,5,4]  R1463     -7.5536054372787476e-01
    z[2,5,4]  R1464     -6.1703097820281982e-01
    z[2,5,4]  R1465     -6.2668442726135254e-01
    z[2,5,4]  R1466     -1.8210516870021820e-01
    z[2,5,4]  R1467     1.5481740236282349e-01
    z[2,5,4]  R1468     -1.2296716123819351e-01
    z[2,5,4]  R1469     -1.5764136612415314e-01
    z[2,5,4]  R1470     -4.7570672631263733e-01
    z[2,5,4]  R1471     -2.5523534417152405e-01
    z[2,5,4]  R1472     -3.7932008504867554e-01
    z[2,5,4]  R1473     1.1816792190074921e-01
    z[2,5,4]  R1474     -2.0104572176933289e-01
    z[2,5,4]  R1475     -1.3503420352935791e-01
    z[2,5,4]  R1476     -2.5660410523414612e-01
    z[2,5,5]  R25       -1
    z[2,5,5]  R52       1
    z[2,5,5]  R1393     -1
    z[2,5,5]  R1394     1
    z[2,5,5]  R1397     -5.6261110305786133e-01
    z[2,5,5]  R1398     -4.5188632607460022e-01
    z[2,5,5]  R1399     4.7491684556007385e-02
    z[2,5,5]  R1400     1.0402470082044601e-01
    z[2,5,5]  R1401     -6.2023870646953583e-02
    z[2,5,5]  R1402     -1.0046847164630890e-02
    z[2,5,5]  R1403     -2.1654093638062477e-02
    z[2,5,5]  R1404     -3.4643489122390747e-01
    z[2,5,5]  R1405     -3.7767979502677917e-01
    z[2,5,5]  R1406     -1.7442518472671509e-01
    z[2,5,5]  R1407     3.4574168920516968e-01
    z[2,5,5]  R1408     -5.5439078807830811e-01
    z[2,5,5]  R1409     -2.3657123744487762e-01
    z[2,5,5]  R1410     2.0953471958637238e-01
    z[2,5,5]  R1411     0.50971519947052
    z[2,5,5]  R1412     2.0126949250698090e-01
    z[2,5,5]  R1413     -8.6231883615255356e-03
    z[2,5,5]  R1414     6.8229717016220093e-01
    z[2,5,5]  R1415     4.6939301490783691e-01
    z[2,5,5]  R1416     4.2282477021217346e-01
    z[2,5,5]  R1417     6.1182837933301926e-02
    z[2,5,5]  R1418     -1.1985354125499725e-01
    z[2,5,5]  R1419     8.6183302104473114e-02
    z[2,5,5]  R1420     2.4325927719473839e-02
    z[2,5,5]  R1421     1.0157548636198044e-01
    z[2,5,5]  R1422     4.8351404070854187e-01
    z[2,5,5]  R1423     8.5496142506599426e-02
    z[2,5,5]  R1424     4.2921945452690125e-01
    z[2,5,5]  R1425     -1.6942197084426880e-01
    z[2,5,5]  R1426     2.2209188342094421e-01
    z[2,5,5]  R1427     -1.5760114416480064e-02
    z[2,5,5]  R1428     0.0844428762793541
    z[2,5,5]  R1429     2.1522009372711182e-01
    z[2,5,5]  R1430     -5.1006329059600830e-01
    z[2,5,5]  R1431     -2.1311371028423309e-01
    z[2,5,5]  R1432     1.6942206025123596e-01
    z[2,5,5]  R1433     -3.9063182473182678e-01
    z[2,5,5]  R1434     2.0191356539726257e-01
    z[2,5,5]  R1435     2.2902959585189819e-01
    z[2,5,5]  R1436     -5.8947563171386719e-02
    z[2,5,5]  R1437     -4.1749498248100281e-01
    z[2,5,5]  R1438     -3.7870484590530396e-01
    z[2,5,5]  R1439     -0.415229469537735
    z[2,5,5]  R1440     -0.0883241817355156
    z[2,5,5]  R1441     4.2321172356605530e-01
    z[2,5,5]  R1442     1.6260632872581482e-01
    z[2,5,5]  R1443     0.0569465234875679
    z[2,5,5]  R1444     -1.6966991126537323e-01
    z[2,5,5]  R1445     -3.0250322818756104e-01
    z[2,5,5]  R1446     3.7471261620521545e-01
    z[2,5,5]  R1447     -1.1131719499826431e-01
    z[2,5,5]  R1448     0.0637318417429924
    z[2,5,5]  R1449     -1.4617668092250824e-01
    z[2,5,5]  R1450     -2.9570075869560242e-01
    z[2,5,5]  R1451     7.7944099903106689e-02
    z[2,5,5]  R1452     1.5966452658176422e-01
    z[2,5,5]  R1453     -2.1649017930030823e-01
    z[2,5,5]  R1454     5.2308106422424316e-01
    z[2,5,5]  R1455     -6.2786924839019775e-01
    z[2,5,5]  R1456     3.3755233883857727e-01
    z[2,5,5]  R1457     1.5116794407367706e-01
    z[2,5,5]  R1458     -2.2197867929935455e-01
    z[2,5,5]  R1459     3.1002062559127808e-01
    z[2,5,5]  R1460     3.1327721476554871e-01
    z[2,5,5]  R1461     3.4476521611213684e-01
    z[2,5,5]  R1462     -0.646431565284729
    z[2,5,5]  R1463     -3.1328245997428894e-01
    z[2,5,5]  R1464     3.7758263945579529e-01
    z[2,5,5]  R1465     -1.5430963039398193e-01
    z[2,5,5]  R1466     1.9245516508817673e-02
    z[2,5,5]  R1467     -2.2110524773597717e-01
    z[2,5,5]  R1468     -1.0460570454597473e-01
    z[2,5,5]  R1469     1.8717718124389648e-01
    z[2,5,5]  R1470     -9.5810495316982269e-02
    z[2,5,5]  R1471     2.0536902546882629e-01
    z[2,5,5]  R1472     3.1169801950454712e-01
    z[2,5,5]  R1473     1.9130136817693710e-02
    z[2,5,5]  R1474     0.602180004119873
    z[2,5,5]  R1475     1.8971244990825653e-01
    z[2,5,5]  R1476     -1.2897464632987976e-01
    z[2,5,6]  R26       -1
    z[2,5,6]  R53       1
    z[2,5,6]  R1395     -1
    z[2,5,6]  R1396     1
    z[2,5,6]  R1397     -2.4012371897697449e-01
    z[2,5,6]  R1398     -4.7786796092987061e-01
    z[2,5,6]  R1399     -3.2327172160148621e-01
    z[2,5,6]  R1400     0.266877144575119
    z[2,5,6]  R1401     -5.2893865853548050e-02
    z[2,5,6]  R1402     -9.8525643348693848e-02
    z[2,5,6]  R1403     3.1339146196842194e-02
    z[2,5,6]  R1404     1.8047126010060310e-02
    z[2,5,6]  R1405     -2.8784683346748352e-01
    z[2,5,6]  R1406     2.2689154744148254e-01
    z[2,5,6]  R1407     -2.5508137419819832e-02
    z[2,5,6]  R1408     5.3439790010452271e-01
    z[2,5,6]  R1409     -1.0268667340278625e-01
    z[2,5,6]  R1410     -3.8092023134231567e-01
    z[2,5,6]  R1411     0.0318525955080986
    z[2,5,6]  R1412     -1.4917287230491638e-01
    z[2,5,6]  R1413     7.3223048448562622e-01
    z[2,5,6]  R1414     -1.7481561005115509e-01
    z[2,5,6]  R1415     6.6362321376800537e-01
    z[2,5,6]  R1416     2.5549495220184326e-01
    z[2,5,6]  R1417     -1.6688092052936554e-01
    z[2,5,6]  R1418     -4.5651599764823914e-02
    z[2,5,6]  R1419     2.2808927297592163e-01
    z[2,5,6]  R1420     -1.2586400844156742e-02
    z[2,5,6]  R1421     3.8680014014244080e-01
    z[2,5,6]  R1422     -2.9306897521018982e-01
    z[2,5,6]  R1423     -1.7781928181648254e-01
    z[2,5,6]  R1424     0.344841331243515
    z[2,5,6]  R1425     -1.3751790858805180e-02
    z[2,5,6]  R1426     -0.413039892911911
    z[2,5,6]  R1427     3.5972705483436584e-01
    z[2,5,6]  R1428     -3.1692448258399963e-01
    z[2,5,6]  R1429     4.4062426686286926e-01
    z[2,5,6]  R1430     1.4996452629566193e-01
    z[2,5,6]  R1431     1.2894116342067719e-01
    z[2,5,6]  R1432     3.3351856470108032e-01
    z[2,5,6]  R1433     -1.2531548738479614e-02
    z[2,5,6]  R1434     -3.5553896427154541e-01
    z[2,5,6]  R1435     1.3812610507011414e-01
    z[2,5,6]  R1436     1.3690458238124847e-01
    z[2,5,6]  R1437     -3.0597314238548279e-01
    z[2,5,6]  R1438     -1.6123616695404053e-01
    z[2,5,6]  R1439     1.7207552492618561e-01
    z[2,5,6]  R1440     5.1867133378982544e-01
    z[2,5,6]  R1441     4.6384155750274658e-01
    z[2,5,6]  R1442     2.1356520056724548e-01
    z[2,5,6]  R1443     4.2806592583656311e-01
    z[2,5,6]  R1444     1.4733320474624634e-01
    z[2,5,6]  R1445     -3.1754586845636368e-02
    z[2,5,6]  R1446     2.4821478128433228e-01
    z[2,5,6]  R1447     1.2127758562564850e-01
    z[2,5,6]  R1448     5.6023085117340088e-01
    z[2,5,6]  R1449     0.349653035402298
    z[2,5,6]  R1450     0.806532084941864
    z[2,5,6]  R1451     5.8506507426500320e-02
    z[2,5,6]  R1452     -3.9483910799026489e-01
    z[2,5,6]  R1453     -0.325979620218277
    z[2,5,6]  R1454     -3.5950893163681030e-01
    z[2,5,6]  R1455     -2.2523787617683411e-01
    z[2,5,6]  R1456     -1.4223001897335052e-01
    z[2,5,6]  R1457     -4.3978440761566162e-01
    z[2,5,6]  R1458     9.6285246312618256e-02
    z[2,5,6]  R1459     3.4382537007331848e-02
    z[2,5,6]  R1460     4.7604967840015888e-03
    z[2,5,6]  R1461     -1.4741019904613495e-01
    z[2,5,6]  R1462     -2.7137833833694458e-01
    z[2,5,6]  R1463     8.8009208440780640e-02
    z[2,5,6]  R1464     3.8328343629837036e-01
    z[2,5,6]  R1465     -4.8739233613014221e-01
    z[2,5,6]  R1466     -3.0698752403259277e-01
    z[2,5,6]  R1467     -4.0437772870063782e-01
    z[2,5,6]  R1468     1.5249388292431831e-02
    z[2,5,6]  R1469     -1.2720832228660583e-01
    z[2,5,6]  R1470     -1.1395805329084396e-01
    z[2,5,6]  R1471     -1.6189830377697945e-02
    z[2,5,6]  R1472     1.4010933041572571e-01
    z[2,5,6]  R1473     2.1948866546154022e-01
    z[2,5,6]  R1474     2.5303825736045837e-01
    z[2,5,6]  R1475     -1.8181873857975006e-01
    z[2,5,6]  R1476     -1.3147367537021637e-01
    z[5,2,0]  R20       1
    z[5,2,0]  R47       -1
    z[5,2,0]  R1477     -1
    z[5,2,0]  R1478     1
    z[5,2,0]  R1491     6.5863317251205444e-01
    z[5,2,0]  R1492     3.5136952996253967e-01
    z[5,2,0]  R1493     4.5002645254135132e-01
    z[5,2,0]  R1494     -1.8709459900856018e-01
    z[5,2,0]  R1495     -6.0926965670660138e-04
    z[5,2,0]  R1496     5.3828325122594833e-02
    z[5,2,0]  R1497     -5.7057225704193115e-01
    z[5,2,0]  R1498     -9.6037723124027252e-02
    z[5,2,0]  R1499     -4.0170863270759583e-01
    z[5,2,0]  R1500     -4.4690504670143127e-01
    z[5,2,0]  R1501     2.4390691518783569e-01
    z[5,2,0]  R1502     -1.6205526888370514e-01
    z[5,2,0]  R1503     -4.1034218668937683e-01
    z[5,2,0]  R1504     -0.491395503282547
    z[5,2,0]  R1505     -5.4686480760574341e-01
    z[5,2,0]  R1506     7.1733094751834869e-02
    z[5,2,0]  R1507     3.0037495493888855e-01
    z[5,2,0]  R1508     1.6303683817386627e-01
    z[5,2,0]  R1509     3.2199257612228394e-01
    z[5,2,0]  R1510     5.4086589813232422e-01
    z[5,2,0]  R1511     -9.2967316508293152e-02
    z[5,2,0]  R1512     -8.6629527807235718e-01
    z[5,2,0]  R1513     -8.9378046989440918e-01
    z[5,2,0]  R1514     -6.3994240760803223e-01
    z[5,2,0]  R1515     -7.6945525407791138e-01
    z[5,2,0]  R1516     -6.9138383865356445e-01
    z[5,2,0]  R1517     -3.5067155957221985e-01
    z[5,2,0]  R1518     4.1472426056861877e-01
    z[5,2,0]  R1519     4.9624881148338318e-01
    z[5,2,0]  R1520     5.4533189535140991e-01
    z[5,2,0]  R1521     -3.7761595845222473e-01
    z[5,2,0]  R1522     -2.6884365081787109e-01
    z[5,2,0]  R1523     7.9843342304229736e-01
    z[5,2,0]  R1524     8.7542468309402466e-01
    z[5,2,0]  R1525     8.4131413698196411e-01
    z[5,2,0]  R1526     0.419920414686203
    z[5,2,0]  R1527     0.285171240568161
    z[5,2,0]  R1528     3.6918950080871582e-01
    z[5,2,0]  R1529     6.9000291824340820e-01
    z[5,2,0]  R1530     6.2999832630157471e-01
    z[5,2,0]  R1531     -3.1384840607643127e-01
    z[5,2,0]  R1532     -2.1706500649452209e-01
    z[5,2,0]  R1533     1.7495959997177124e-01
    z[5,2,0]  R1534     3.1879001855850220e-01
    z[5,2,0]  R1535     2.0410983264446259e-01
    z[5,2,0]  R1536     0.538845419883728
    z[5,2,0]  R1537     4.7156815417110920e-03
    z[5,2,0]  R1538     5.1173609495162964e-01
    z[5,2,0]  R1539     3.5414862632751465e-01
    z[5,2,0]  R1540     1.5112403035163879e-01
    z[5,2,0]  R1541     3.5378584265708923e-01
    z[5,2,0]  R1542     -7.7039031311869621e-03
    z[5,2,0]  R1543     5.1625329256057739e-01
    z[5,2,0]  R1544     5.4666346311569214e-01
    z[5,2,0]  R1545     -2.4800196290016174e-01
    z[5,2,0]  R1546     4.0988841652870178e-01
    z[5,2,0]  R1547     3.5897067189216614e-01
    z[5,2,0]  R1548     6.8418520689010620e-01
    z[5,2,0]  R1549     5.2593183517456055e-01
    z[5,2,0]  R1550     3.0959594249725342e-01
    z[5,2,0]  R1551     -3.0739870667457581e-01
    z[5,2,0]  R1552     -5.9899266809225082e-02
    z[5,2,0]  R1553     5.0955039262771606e-01
    z[5,2,0]  R1554     6.1493802070617676e-01
    z[5,2,0]  R1555     0.53638756275177
    z[5,2,0]  R1556     6.5523380041122437e-01
    z[5,2,0]  R1557     2.7248516678810120e-01
    z[5,2,0]  R1558     3.8072407245635986e-01
    z[5,2,0]  R1559     8.6608707904815674e-01
    z[5,2,0]  R1560     5.1091867685317993e-01
    z[5,2,0]  R1561     -4.8466438055038452e-01
    z[5,2,0]  R1562     -2.2906814515590668e-01
    z[5,2,0]  R1563     -1.3635233044624329e-02
    z[5,2,0]  R1564     9.6427626907825470e-02
    z[5,2,0]  R1565     4.2372739315032959e-01
    z[5,2,0]  R1566     5.4470956325531006e-01
    z[5,2,0]  R1567     6.6702020168304443e-01
    z[5,2,0]  R1568     5.1377475261688232e-02
    z[5,2,0]  R1569     7.0297127962112427e-01
    z[5,2,0]  R1570     7.1857148408889771e-01
    z[5,2,1]  R21       1
    z[5,2,1]  R48       -1
    z[5,2,1]  R1479     -1
    z[5,2,1]  R1480     1
    z[5,2,1]  R1491     3.5655662417411804e-02
    z[5,2,1]  R1492     -6.8967863917350769e-02
    z[5,2,1]  R1493     3.3862382173538208e-02
    z[5,2,1]  R1494     1.3009256124496460e-01
    z[5,2,1]  R1495     7.6676271855831146e-02
    z[5,2,1]  R1496     1.8855138123035431e-01
    z[5,2,1]  R1497     1.0348648577928543e-01
    z[5,2,1]  R1498     1.7468252778053284e-01
    z[5,2,1]  R1499     4.8111043870449066e-03
    z[5,2,1]  R1500     -5.5101740360260010e-01
    z[5,2,1]  R1501     3.6529025435447693e-01
    z[5,2,1]  R1502     5.0101137161254883e-01
    z[5,2,1]  R1503     2.3997753858566284e-01
    z[5,2,1]  R1504     6.4626473188400269e-01
    z[5,2,1]  R1505     -2.7780082821846008e-01
    z[5,2,1]  R1506     5.2693653106689453e-01
    z[5,2,1]  R1507     2.0449882745742798e-01
    z[5,2,1]  R1508     2.8308564424514771e-01
    z[5,2,1]  R1509     1.5430007874965668e-01
    z[5,2,1]  R1510     -6.8047416210174561e-01
    z[5,2,1]  R1511     7.3471927642822266e-01
    z[5,2,1]  R1512     -3.5882565379142761e-01
    z[5,2,1]  R1513     -1.5928235650062561e-01
    z[5,2,1]  R1514     7.7059499919414520e-02
    z[5,2,1]  R1515     0.0466160774230957
    z[5,2,1]  R1516     -2.1337196230888367e-01
    z[5,2,1]  R1517     -2.3984816670417786e-01
    z[5,2,1]  R1518     3.0023759603500366e-01
    z[5,2,1]  R1519     -7.8539723157882690e-01
    z[5,2,1]  R1520     -6.9796615839004517e-01
    z[5,2,1]  R1521     3.8441542536020279e-02
    z[5,2,1]  R1522     8.1759430468082428e-02
    z[5,2,1]  R1523     -4.0119934082031250e-01
    z[5,2,1]  R1524     -2.3960407078266144e-01
    z[5,2,1]  R1525     -3.0244883894920349e-01
    z[5,2,1]  R1526     -0.802794873714447
    z[5,2,1]  R1527     -8.8745057582855225e-01
    z[5,2,1]  R1528     -0.754834771156311
    z[5,2,1]  R1529     -3.9399498701095581e-01
    z[5,2,1]  R1530     8.5442259907722473e-02
    z[5,2,1]  R1531     5.6618911027908325e-01
    z[5,2,1]  R1532     2.3656965792179108e-01
    z[5,2,1]  R1533     5.4735934734344482e-01
    z[5,2,1]  R1534     4.4414228200912476e-01
    z[5,2,1]  R1535     6.6778522729873657e-01
    z[5,2,1]  R1536     6.4470344781875610e-01
    z[5,2,1]  R1537     4.5176360011100769e-01
    z[5,2,1]  R1538     3.9058855175971985e-01
    z[5,2,1]  R1539     4.3951633572578430e-01
    z[5,2,1]  R1540     6.5985703468322754e-01
    z[5,2,1]  R1541     2.5097227096557617e-01
    z[5,2,1]  R1542     0.688449501991272
    z[5,2,1]  R1543     4.6634155511856079e-01
    z[5,2,1]  R1544     -6.1167693138122559e-01
    z[5,2,1]  R1545     -5.3506873548030853e-02
    z[5,2,1]  R1546     -6.4141339063644409e-01
    z[5,2,1]  R1547     -7.2092831134796143e-01
    z[5,2,1]  R1548     -3.9164590835571289e-01
    z[5,2,1]  R1549     -6.4713460206985474e-01
    z[5,2,1]  R1550     -6.1470401287078857e-01
    z[5,2,1]  R1551     8.1374222040176392e-01
    z[5,2,1]  R1552     8.5356724262237549e-01
    z[5,2,1]  R1553     -6.6358691453933716e-01
    z[5,2,1]  R1554     -5.5984467267990112e-01
    z[5,2,1]  R1555     -6.9038879871368408e-01
    z[5,2,1]  R1556     -4.7251582145690918e-01
    z[5,2,1]  R1557     -7.4744731187820435e-01
    z[5,2,1]  R1558     -6.1545717716217041e-01
    z[5,2,1]  R1559     -3.5275623202323914e-01
    z[5,2,1]  R1560     -4.5408290624618530e-01
    z[5,2,1]  R1561     -3.5253381729125977e-01
    z[5,2,1]  R1562     8.0153006315231323e-01
    z[5,2,1]  R1563     8.7071365118026733e-01
    z[5,2,1]  R1564     5.4113519191741943e-01
    z[5,2,1]  R1565     5.0517255067825317e-01
    z[5,2,1]  R1566     0.586051881313324
    z[5,2,1]  R1567     5.4306948184967041e-01
    z[5,2,1]  R1568     8.1572657823562622e-01
    z[5,2,1]  R1569     -3.9696505665779114e-01
    z[5,2,1]  R1570     -2.6708725094795227e-01
    z[5,2,2]  R22       1
    z[5,2,2]  R49       -1
    z[5,2,2]  R1481     -1
    z[5,2,2]  R1482     1
    z[5,2,2]  R1491     4.9690103530883789e-01
    z[5,2,2]  R1492     5.6668418645858765e-01
    z[5,2,2]  R1493     0.788059413433075
    z[5,2,2]  R1494     4.3211534619331360e-01
    z[5,2,2]  R1495     8.6823272705078125e-01
    z[5,2,2]  R1496     5.7285249233245850e-01
    z[5,2,2]  R1497     -5.4072532802820206e-02
    z[5,2,2]  R1498     -7.0453107357025146e-02
    z[5,2,2]  R1499     -2.5815838575363159e-01
    z[5,2,2]  R1500     2.3707246780395508e-01
    z[5,2,2]  R1501     -3.4773632884025574e-01
    z[5,2,2]  R1502     -4.4258171319961548e-01
    z[5,2,2]  R1503     -2.0929503440856934e-01
    z[5,2,2]  R1504     0.0709293782711029
    z[5,2,2]  R1505     -6.5322893857955933e-01
    z[5,2,2]  R1506     -1.1875462532043457e-01
    z[5,2,2]  R1507     -3.9269593358039856e-01
    z[5,2,2]  R1508     -4.7192507982254028e-01
    z[5,2,2]  R1509     -3.8370156288146973e-01
    z[5,2,2]  R1510     -2.9528501629829407e-01
    z[5,2,2]  R1511     1.4096125960350037e-01
    z[5,2,2]  R1512     -1.0095614194869995e-01
    z[5,2,2]  R1513     1.3848142325878143e-01
    z[5,2,2]  R1514     -3.6666259169578552e-01
    z[5,2,2]  R1515     -3.1680583953857422e-01
    z[5,2,2]  R1516     -0.0551447868347168
    z[5,2,2]  R1517     -4.8404029011726379e-01
    z[5,2,2]  R1518     -3.7091752886772156e-01
    z[5,2,2]  R1519     -1.7900729179382324e-01
    z[5,2,2]  R1520     -1.5813142061233521e-01
    z[5,2,2]  R1521     7.4965290725231171e-02
    z[5,2,2]  R1522     0.681813657283783
    z[5,2,2]  R1523     1.4072988927364349e-01
    z[5,2,2]  R1524     1.7492705583572388e-01
    z[5,2,2]  R1525     1.3756878674030304e-02
    z[5,2,2]  R1526     -1.7958280444145203e-01
    z[5,2,2]  R1527     -3.4977486357092857e-03
    z[5,2,2]  R1528     1.0772727429866791e-01
    z[5,2,2]  R1529     3.0122503638267517e-01
    z[5,2,2]  R1530     5.3374260663986206e-01
    z[5,2,2]  R1531     3.3036175370216370e-01
    z[5,2,2]  R1532     -1.0271928459405899e-01
    z[5,2,2]  R1533     3.5235092509537935e-03
    z[5,2,2]  R1534     -1.6434369981288910e-01
    z[5,2,2]  R1535     -3.0935943126678467e-01
    z[5,2,2]  R1536     2.0727092027664185e-01
    z[5,2,2]  R1537     -3.2779264450073242e-01
    z[5,2,2]  R1538     2.4899050593376160e-01
    z[5,2,2]  R1539     -9.0174794197082520e-02
    z[5,2,2]  R1540     -1.8114100396633148e-01
    z[5,2,2]  R1541     7.9812347888946533e-01
    z[5,2,2]  R1542     6.2663513422012329e-01
    z[5,2,2]  R1543     4.0392029285430908e-01
    z[5,2,2]  R1544     -7.3203317821025848e-02
    z[5,2,2]  R1545     2.7970877289772034e-01
    z[5,2,2]  R1546     1.5855786204338074e-01
    z[5,2,2]  R1547     2.7109023928642273e-01
    z[5,2,2]  R1548     -1.7429442703723907e-01
    z[5,2,2]  R1549     -5.2469903230667114e-01
    z[5,2,2]  R1550     2.7236273884773254e-01
    z[5,2,2]  R1551     -1.1220594495534897e-01
    z[5,2,2]  R1552     -3.8480564951896667e-01
    z[5,2,2]  R1553     2.0183211192488670e-02
    z[5,2,2]  R1554     2.4744583293795586e-02
    z[5,2,2]  R1555     -2.3151947557926178e-01
    z[5,2,2]  R1556     -2.6929610967636108e-01
    z[5,2,2]  R1557     3.4785324335098267e-01
    z[5,2,2]  R1558     4.8382428288459778e-01
    z[5,2,2]  R1559     2.1594485267996788e-02
    z[5,2,2]  R1560     -2.0730255171656609e-02
    z[5,2,2]  R1561     1.1036302149295807e-01
    z[5,2,2]  R1562     3.5348507761955261e-01
    z[5,2,2]  R1563     0.0318136028945446
    z[5,2,2]  R1564     5.4831538349390030e-02
    z[5,2,2]  R1565     4.4717624783515930e-02
    z[5,2,2]  R1566     -1.7602179944515228e-01
    z[5,2,2]  R1567     2.6207652688026428e-01
    z[5,2,2]  R1568     -4.0650373697280884e-01
    z[5,2,2]  R1569     4.3773704767227173e-01
    z[5,2,2]  R1570     3.4073731303215027e-01
    z[5,2,3]  R23       1
    z[5,2,3]  R50       -1
    z[5,2,3]  R1483     -1
    z[5,2,3]  R1484     1
    z[5,2,3]  R1491     -5.0862443447113037e-01
    z[5,2,3]  R1492     2.7938507497310638e-02
    z[5,2,3]  R1493     -1.6678662598133087e-01
    z[5,2,3]  R1494     1.1506868898868561e-01
    z[5,2,3]  R1495     -1.8325862288475037e-01
    z[5,2,3]  R1496     6.6361993551254272e-01
    z[5,2,3]  R1497     0.674699068069458
    z[5,2,3]  R1498     4.8612591624259949e-01
    z[5,2,3]  R1499     4.2541259527206421e-01
    z[5,2,3]  R1500     5.2751320600509644e-01
    z[5,2,3]  R1501     -2.3076803982257843e-01
    z[5,2,3]  R1502     -5.7352638244628906e-01
    z[5,2,3]  R1503     -7.9003876447677612e-01
    z[5,2,3]  R1504     -1.9347956776618958e-01
    z[5,2,3]  R1505     1.0992675274610519e-01
    z[5,2,3]  R1506     0.453823983669281
    z[5,2,3]  R1507     -1.9309048354625702e-01
    z[5,2,3]  R1508     1.9135428592562675e-02
    z[5,2,3]  R1509     -2.6681306958198547e-01
    z[5,2,3]  R1510     1.7161494493484497e-01
    z[5,2,3]  R1511     4.4192460179328918e-01
    z[5,2,3]  R1512     0.290324866771698
    z[5,2,3]  R1513     2.8379639983177185e-01
    z[5,2,3]  R1514     4.4903361797332764e-01
    z[5,2,3]  R1515     4.4476497173309326e-01
    z[5,2,3]  R1516     4.6124801039695740e-01
    z[5,2,3]  R1517     7.2298157215118408e-01
    z[5,2,3]  R1518     3.6498349905014038e-01
    z[5,2,3]  R1519     0.132520392537117
    z[5,2,3]  R1520     0.301140159368515
    z[5,2,3]  R1521     -6.8057513236999512e-01
    z[5,2,3]  R1522     1.2966774404048920e-01
    z[5,2,3]  R1523     1.4103873074054718e-01
    z[5,2,3]  R1524     2.2557689249515533e-01
    z[5,2,3]  R1525     3.4696063399314880e-01
    z[5,2,3]  R1526     1.0997498035430908e-01
    z[5,2,3]  R1527     -1.4441721141338348e-01
    z[5,2,3]  R1528     -3.9046889543533325e-01
    z[5,2,3]  R1529     2.1113230288028717e-01
    z[5,2,3]  R1530     -4.3737614154815674e-01
    z[5,2,3]  R1531     -0.275144100189209
    z[5,2,3]  R1532     3.6345925927162170e-01
    z[5,2,3]  R1533     -1.2501551210880280e-01
    z[5,2,3]  R1534     -4.3762576580047607e-01
    z[5,2,3]  R1535     -3.6428907513618469e-01
    z[5,2,3]  R1536     7.4119992554187775e-02
    z[5,2,3]  R1537     -2.9075714945793152e-01
    z[5,2,3]  R1538     -1.3685405254364014e-02
    z[5,2,3]  R1539     -1.0349833220243454e-01
    z[5,2,3]  R1540     5.0873857736587524e-01
    z[5,2,3]  R1541     -3.3803546428680420e-01
    z[5,2,3]  R1542     2.2532603144645691e-01
    z[5,2,3]  R1543     5.0569951534271240e-01
    z[5,2,3]  R1544     5.6493043899536133e-01
    z[5,2,3]  R1545     -5.5822163820266724e-01
    z[5,2,3]  R1546     1.5094357728958130e-01
    z[5,2,3]  R1547     -6.5323412418365479e-02
    z[5,2,3]  R1548     1.8714305013418198e-02
    z[5,2,3]  R1549     2.0260209217667580e-02
    z[5,2,3]  R1550     -4.6693214774131775e-01
    z[5,2,3]  R1551     1.3155084848403931e-01
    z[5,2,3]  R1552     0.0213027261197567
    z[5,2,3]  R1553     -1.2451861053705215e-01
    z[5,2,3]  R1554     1.3461527228355408e-01
    z[5,2,3]  R1555     -3.0403189361095428e-02
    z[5,2,3]  R1556     -3.1890103220939636e-01
    z[5,2,3]  R1557     3.0515128374099731e-01
    z[5,2,3]  R1558     -2.7336540818214417e-01
    z[5,2,3]  R1559     -2.2930863499641418e-01
    z[5,2,3]  R1560     -6.9702661037445068e-01
    z[5,2,3]  R1561     3.9165702462196350e-01
    z[5,2,3]  R1562     9.0290986001491547e-02
    z[5,2,3]  R1563     1.1057351529598236e-01
    z[5,2,3]  R1564     -6.4202737808227539e-01
    z[5,2,3]  R1565     -2.9270380735397339e-01
    z[5,2,3]  R1566     -4.7821402549743652e-01
    z[5,2,3]  R1567     5.7964488863945007e-02
    z[5,2,3]  R1568     -0.312037855386734
    z[5,2,3]  R1569     2.0122438669204712e-01
    z[5,2,3]  R1570     -1.0564703494310379e-01
    z[5,2,4]  R24       1
    z[5,2,4]  R51       -1
    z[5,2,4]  R1485     -1
    z[5,2,4]  R1486     1
    z[5,2,4]  R1491     1.7950442433357239e-01
    z[5,2,4]  R1492     0.481612890958786
    z[5,2,4]  R1493     -6.2043469399213791e-02
    z[5,2,4]  R1494     1.0086730867624283e-01
    z[5,2,4]  R1495     -4.4408363103866577e-01
    z[5,2,4]  R1496     -1.0774364322423935e-01
    z[5,2,4]  R1497     2.2905133664608002e-01
    z[5,2,4]  R1498     5.6224584579467773e-01
    z[5,2,4]  R1499     -3.8214331865310669e-01
    z[5,2,4]  R1500     -1.6736510396003723e-01
    z[5,2,4]  R1501     6.4547348022460938e-01
    z[5,2,4]  R1502     3.7332189083099365e-01
    z[5,2,4]  R1503     9.3645811080932617e-02
    z[5,2,4]  R1504     4.4748380780220032e-01
    z[5,2,4]  R1505     -2.1066750586032867e-01
    z[5,2,4]  R1506     -7.4922956526279449e-02
    z[5,2,4]  R1507     -7.5536054372787476e-01
    z[5,2,4]  R1508     -6.1703097820281982e-01
    z[5,2,4]  R1509     -6.2668442726135254e-01
    z[5,2,4]  R1510     -1.8210516870021820e-01
    z[5,2,4]  R1511     1.5481740236282349e-01
    z[5,2,4]  R1512     -1.2296716123819351e-01
    z[5,2,4]  R1513     -1.5764136612415314e-01
    z[5,2,4]  R1514     -4.7570672631263733e-01
    z[5,2,4]  R1515     -2.5523534417152405e-01
    z[5,2,4]  R1516     -3.7932008504867554e-01
    z[5,2,4]  R1517     1.1816792190074921e-01
    z[5,2,4]  R1518     -2.0104572176933289e-01
    z[5,2,4]  R1519     -1.3503420352935791e-01
    z[5,2,4]  R1520     -2.5660410523414612e-01
    z[5,2,4]  R1521     -1.1373429745435715e-01
    z[5,2,4]  R1522     8.2437492907047272e-02
    z[5,2,4]  R1523     -2.3470453917980194e-01
    z[5,2,4]  R1524     -1.1266208440065384e-01
    z[5,2,4]  R1525     -2.7110788226127625e-01
    z[5,2,4]  R1526     -3.5360220074653625e-01
    z[5,2,4]  R1527     -3.2983240485191345e-01
    z[5,2,4]  R1528     -9.7517386078834534e-02
    z[5,2,4]  R1529     -8.8615730404853821e-02
    z[5,2,4]  R1530     1.9421349465847015e-01
    z[5,2,4]  R1531     0.525259792804718
    z[5,2,4]  R1532     4.0166336297988892e-01
    z[5,2,4]  R1533     7.6657354831695557e-01
    z[5,2,4]  R1534     5.4183059930801392e-01
    z[5,2,4]  R1535     -1.5221124887466431e-01
    z[5,2,4]  R1536     -4.2753493785858154e-01
    z[5,2,4]  R1537     2.6012265682220459e-01
    z[5,2,4]  R1538     -1.6520659625530243e-01
    z[5,2,4]  R1539     -4.2838916182518005e-02
    z[5,2,4]  R1540     7.7875934541225433e-02
    z[5,2,4]  R1541     1.7025533318519592e-01
    z[5,2,4]  R1542     -2.5707101821899414e-01
    z[5,2,4]  R1543     1.9409327208995819e-01
    z[5,2,4]  R1544     -4.1895397007465363e-02
    z[5,2,4]  R1545     6.2116956710815430e-01
    z[5,2,4]  R1546     2.3017503321170807e-01
    z[5,2,4]  R1547     4.8447516560554504e-01
    z[5,2,4]  R1548     2.1125909686088562e-01
    z[5,2,4]  R1549     -1.2951073586009443e-04
    z[5,2,4]  R1550     1.1897636950016022e-01
    z[5,2,4]  R1551     -2.8945109248161316e-01
    z[5,2,4]  R1552     -1.0832422971725464e-01
    z[5,2,4]  R1553     2.0887608826160431e-01
    z[5,2,4]  R1554     8.3890803158283234e-02
    z[5,2,4]  R1555     3.4508371353149414e-01
    z[5,2,4]  R1556     1.8232037127017975e-01
    z[5,2,4]  R1557     -1.4317064546048641e-02
    z[5,2,4]  R1558     -1.6430977731943130e-02
    z[5,2,4]  R1559     -2.9563827440142632e-02
    z[5,2,4]  R1560     1.5581177175045013e-01
    z[5,2,4]  R1561     4.5532783865928650e-01
    z[5,2,4]  R1562     -5.0584875047206879e-02
    z[5,2,4]  R1563     1.6250425577163696e-01
    z[5,2,4]  R1564     -7.6470471918582916e-02
    z[5,2,4]  R1565     2.8865805268287659e-01
    z[5,2,4]  R1566     1.6766466200351715e-01
    z[5,2,4]  R1567     4.0400851517915726e-02
    z[5,2,4]  R1568     -1.3726890087127686e-01
    z[5,2,4]  R1569     -1.5371577441692352e-01
    z[5,2,4]  R1570     2.8815966844558716e-01
    z[5,2,5]  R25       1
    z[5,2,5]  R52       -1
    z[5,2,5]  R1487     -1
    z[5,2,5]  R1488     1
    z[5,2,5]  R1491     -1.1131719499826431e-01
    z[5,2,5]  R1492     0.0637318417429924
    z[5,2,5]  R1493     -1.4617668092250824e-01
    z[5,2,5]  R1494     -2.9570075869560242e-01
    z[5,2,5]  R1495     7.7944099903106689e-02
    z[5,2,5]  R1496     1.5966452658176422e-01
    z[5,2,5]  R1497     -2.1649017930030823e-01
    z[5,2,5]  R1498     5.2308106422424316e-01
    z[5,2,5]  R1499     -6.2786924839019775e-01
    z[5,2,5]  R1500     3.3755233883857727e-01
    z[5,2,5]  R1501     1.5116794407367706e-01
    z[5,2,5]  R1502     -2.2197867929935455e-01
    z[5,2,5]  R1503     3.1002062559127808e-01
    z[5,2,5]  R1504     3.1327721476554871e-01
    z[5,2,5]  R1505     3.4476521611213684e-01
    z[5,2,5]  R1506     -0.646431565284729
    z[5,2,5]  R1507     -3.1328245997428894e-01
    z[5,2,5]  R1508     3.7758263945579529e-01
    z[5,2,5]  R1509     -1.5430963039398193e-01
    z[5,2,5]  R1510     1.9245516508817673e-02
    z[5,2,5]  R1511     -2.2110524773597717e-01
    z[5,2,5]  R1512     -1.0460570454597473e-01
    z[5,2,5]  R1513     1.8717718124389648e-01
    z[5,2,5]  R1514     -9.5810495316982269e-02
    z[5,2,5]  R1515     2.0536902546882629e-01
    z[5,2,5]  R1516     3.1169801950454712e-01
    z[5,2,5]  R1517     1.9130136817693710e-02
    z[5,2,5]  R1518     0.602180004119873
    z[5,2,5]  R1519     1.8971244990825653e-01
    z[5,2,5]  R1520     -1.2897464632987976e-01
    z[5,2,5]  R1521     -5.6261110305786133e-01
    z[5,2,5]  R1522     -4.5188632607460022e-01
    z[5,2,5]  R1523     4.7491684556007385e-02
    z[5,2,5]  R1524     1.0402470082044601e-01
    z[5,2,5]  R1525     -6.2023870646953583e-02
    z[5,2,5]  R1526     -1.0046847164630890e-02
    z[5,2,5]  R1527     -2.1654093638062477e-02
    z[5,2,5]  R1528     -3.4643489122390747e-01
    z[5,2,5]  R1529     -3.7767979502677917e-01
    z[5,2,5]  R1530     -1.7442518472671509e-01
    z[5,2,5]  R1531     3.4574168920516968e-01
    z[5,2,5]  R1532     -5.5439078807830811e-01
    z[5,2,5]  R1533     -2.3657123744487762e-01
    z[5,2,5]  R1534     2.0953471958637238e-01
    z[5,2,5]  R1535     0.50971519947052
    z[5,2,5]  R1536     2.0126949250698090e-01
    z[5,2,5]  R1537     -8.6231883615255356e-03
    z[5,2,5]  R1538     6.8229717016220093e-01
    z[5,2,5]  R1539     4.6939301490783691e-01
    z[5,2,5]  R1540     4.2282477021217346e-01
    z[5,2,5]  R1541     6.1182837933301926e-02
    z[5,2,5]  R1542     -1.1985354125499725e-01
    z[5,2,5]  R1543     8.6183302104473114e-02
    z[5,2,5]  R1544     2.4325927719473839e-02
    z[5,2,5]  R1545     1.0157548636198044e-01
    z[5,2,5]  R1546     4.8351404070854187e-01
    z[5,2,5]  R1547     8.5496142506599426e-02
    z[5,2,5]  R1548     4.2921945452690125e-01
    z[5,2,5]  R1549     -1.6942197084426880e-01
    z[5,2,5]  R1550     2.2209188342094421e-01
    z[5,2,5]  R1551     -1.5760114416480064e-02
    z[5,2,5]  R1552     0.0844428762793541
    z[5,2,5]  R1553     2.1522009372711182e-01
    z[5,2,5]  R1554     -5.1006329059600830e-01
    z[5,2,5]  R1555     -2.1311371028423309e-01
    z[5,2,5]  R1556     1.6942206025123596e-01
    z[5,2,5]  R1557     -3.9063182473182678e-01
    z[5,2,5]  R1558     2.0191356539726257e-01
    z[5,2,5]  R1559     2.2902959585189819e-01
    z[5,2,5]  R1560     -5.8947563171386719e-02
    z[5,2,5]  R1561     -4.1749498248100281e-01
    z[5,2,5]  R1562     -3.7870484590530396e-01
    z[5,2,5]  R1563     -0.415229469537735
    z[5,2,5]  R1564     -0.0883241817355156
    z[5,2,5]  R1565     4.2321172356605530e-01
    z[5,2,5]  R1566     1.6260632872581482e-01
    z[5,2,5]  R1567     0.0569465234875679
    z[5,2,5]  R1568     -1.6966991126537323e-01
    z[5,2,5]  R1569     -3.0250322818756104e-01
    z[5,2,5]  R1570     3.7471261620521545e-01
    z[5,2,6]  R26       1
    z[5,2,6]  R53       -1
    z[5,2,6]  R1489     -1
    z[5,2,6]  R1490     1
    z[5,2,6]  R1491     1.2127758562564850e-01
    z[5,2,6]  R1492     5.6023085117340088e-01
    z[5,2,6]  R1493     0.349653035402298
    z[5,2,6]  R1494     0.806532084941864
    z[5,2,6]  R1495     5.8506507426500320e-02
    z[5,2,6]  R1496     -3.9483910799026489e-01
    z[5,2,6]  R1497     -0.325979620218277
    z[5,2,6]  R1498     -3.5950893163681030e-01
    z[5,2,6]  R1499     -2.2523787617683411e-01
    z[5,2,6]  R1500     -1.4223001897335052e-01
    z[5,2,6]  R1501     -4.3978440761566162e-01
    z[5,2,6]  R1502     9.6285246312618256e-02
    z[5,2,6]  R1503     3.4382537007331848e-02
    z[5,2,6]  R1504     4.7604967840015888e-03
    z[5,2,6]  R1505     -1.4741019904613495e-01
    z[5,2,6]  R1506     -2.7137833833694458e-01
    z[5,2,6]  R1507     8.8009208440780640e-02
    z[5,2,6]  R1508     3.8328343629837036e-01
    z[5,2,6]  R1509     -4.8739233613014221e-01
    z[5,2,6]  R1510     -3.0698752403259277e-01
    z[5,2,6]  R1511     -4.0437772870063782e-01
    z[5,2,6]  R1512     1.5249388292431831e-02
    z[5,2,6]  R1513     -1.2720832228660583e-01
    z[5,2,6]  R1514     -1.1395805329084396e-01
    z[5,2,6]  R1515     -1.6189830377697945e-02
    z[5,2,6]  R1516     1.4010933041572571e-01
    z[5,2,6]  R1517     2.1948866546154022e-01
    z[5,2,6]  R1518     2.5303825736045837e-01
    z[5,2,6]  R1519     -1.8181873857975006e-01
    z[5,2,6]  R1520     -1.3147367537021637e-01
    z[5,2,6]  R1521     -2.4012371897697449e-01
    z[5,2,6]  R1522     -4.7786796092987061e-01
    z[5,2,6]  R1523     -3.2327172160148621e-01
    z[5,2,6]  R1524     0.266877144575119
    z[5,2,6]  R1525     -5.2893865853548050e-02
    z[5,2,6]  R1526     -9.8525643348693848e-02
    z[5,2,6]  R1527     3.1339146196842194e-02
    z[5,2,6]  R1528     1.8047126010060310e-02
    z[5,2,6]  R1529     -2.8784683346748352e-01
    z[5,2,6]  R1530     2.2689154744148254e-01
    z[5,2,6]  R1531     -2.5508137419819832e-02
    z[5,2,6]  R1532     5.3439790010452271e-01
    z[5,2,6]  R1533     -1.0268667340278625e-01
    z[5,2,6]  R1534     -3.8092023134231567e-01
    z[5,2,6]  R1535     0.0318525955080986
    z[5,2,6]  R1536     -1.4917287230491638e-01
    z[5,2,6]  R1537     7.3223048448562622e-01
    z[5,2,6]  R1538     -1.7481561005115509e-01
    z[5,2,6]  R1539     6.6362321376800537e-01
    z[5,2,6]  R1540     2.5549495220184326e-01
    z[5,2,6]  R1541     -1.6688092052936554e-01
    z[5,2,6]  R1542     -4.5651599764823914e-02
    z[5,2,6]  R1543     2.2808927297592163e-01
    z[5,2,6]  R1544     -1.2586400844156742e-02
    z[5,2,6]  R1545     3.8680014014244080e-01
    z[5,2,6]  R1546     -2.9306897521018982e-01
    z[5,2,6]  R1547     -1.7781928181648254e-01
    z[5,2,6]  R1548     0.344841331243515
    z[5,2,6]  R1549     -1.3751790858805180e-02
    z[5,2,6]  R1550     -0.413039892911911
    z[5,2,6]  R1551     3.5972705483436584e-01
    z[5,2,6]  R1552     -3.1692448258399963e-01
    z[5,2,6]  R1553     4.4062426686286926e-01
    z[5,2,6]  R1554     1.4996452629566193e-01
    z[5,2,6]  R1555     1.2894116342067719e-01
    z[5,2,6]  R1556     3.3351856470108032e-01
    z[5,2,6]  R1557     -1.2531548738479614e-02
    z[5,2,6]  R1558     -3.5553896427154541e-01
    z[5,2,6]  R1559     1.3812610507011414e-01
    z[5,2,6]  R1560     1.3690458238124847e-01
    z[5,2,6]  R1561     -3.0597314238548279e-01
    z[5,2,6]  R1562     -1.6123616695404053e-01
    z[5,2,6]  R1563     1.7207552492618561e-01
    z[5,2,6]  R1564     5.1867133378982544e-01
    z[5,2,6]  R1565     4.6384155750274658e-01
    z[5,2,6]  R1566     2.1356520056724548e-01
    z[5,2,6]  R1567     4.2806592583656311e-01
    z[5,2,6]  R1568     1.4733320474624634e-01
    z[5,2,6]  R1569     -3.1754586845636368e-02
    z[5,2,6]  R1570     2.4821478128433228e-01
    z[2,6,0]  R20       -1
    z[2,6,0]  R56       1
    z[2,6,0]  R1571     -1
    z[2,6,0]  R1572     1
    z[2,6,0]  R1585     -3.7761595845222473e-01
    z[2,6,0]  R1586     -2.6884365081787109e-01
    z[2,6,0]  R1587     7.9843342304229736e-01
    z[2,6,0]  R1588     8.7542468309402466e-01
    z[2,6,0]  R1589     8.4131413698196411e-01
    z[2,6,0]  R1590     0.419920414686203
    z[2,6,0]  R1591     0.285171240568161
    z[2,6,0]  R1592     3.6918950080871582e-01
    z[2,6,0]  R1593     6.9000291824340820e-01
    z[2,6,0]  R1594     6.2999832630157471e-01
    z[2,6,0]  R1595     -3.1384840607643127e-01
    z[2,6,0]  R1596     -2.1706500649452209e-01
    z[2,6,0]  R1597     1.7495959997177124e-01
    z[2,6,0]  R1598     3.1879001855850220e-01
    z[2,6,0]  R1599     2.0410983264446259e-01
    z[2,6,0]  R1600     0.538845419883728
    z[2,6,0]  R1601     4.7156815417110920e-03
    z[2,6,0]  R1602     5.1173609495162964e-01
    z[2,6,0]  R1603     3.5414862632751465e-01
    z[2,6,0]  R1604     1.5112403035163879e-01
    z[2,6,0]  R1605     3.5378584265708923e-01
    z[2,6,0]  R1606     -7.7039031311869621e-03
    z[2,6,0]  R1607     5.1625329256057739e-01
    z[2,6,0]  R1608     5.4666346311569214e-01
    z[2,6,0]  R1609     -2.4800196290016174e-01
    z[2,6,0]  R1610     4.0988841652870178e-01
    z[2,6,0]  R1611     3.5897067189216614e-01
    z[2,6,0]  R1612     6.8418520689010620e-01
    z[2,6,0]  R1613     5.2593183517456055e-01
    z[2,6,0]  R1614     3.0959594249725342e-01
    z[2,6,0]  R1615     -3.0739870667457581e-01
    z[2,6,0]  R1616     -5.9899266809225082e-02
    z[2,6,0]  R1617     5.0955039262771606e-01
    z[2,6,0]  R1618     6.1493802070617676e-01
    z[2,6,0]  R1619     0.53638756275177
    z[2,6,0]  R1620     6.5523380041122437e-01
    z[2,6,0]  R1621     2.7248516678810120e-01
    z[2,6,0]  R1622     3.8072407245635986e-01
    z[2,6,0]  R1623     8.6608707904815674e-01
    z[2,6,0]  R1624     5.1091867685317993e-01
    z[2,6,0]  R1625     -4.8466438055038452e-01
    z[2,6,0]  R1626     -2.2906814515590668e-01
    z[2,6,0]  R1627     -1.3635233044624329e-02
    z[2,6,0]  R1628     9.6427626907825470e-02
    z[2,6,0]  R1629     4.2372739315032959e-01
    z[2,6,0]  R1630     5.4470956325531006e-01
    z[2,6,0]  R1631     6.6702020168304443e-01
    z[2,6,0]  R1632     5.1377475261688232e-02
    z[2,6,0]  R1633     7.0297127962112427e-01
    z[2,6,0]  R1634     7.1857148408889771e-01
    z[2,6,0]  R1635     -2.4306967854499817e-01
    z[2,6,0]  R1636     2.2307108342647552e-01
    z[2,6,0]  R1637     3.4439027309417725e-01
    z[2,6,0]  R1638     -1.1825361847877502e-01
    z[2,6,0]  R1639     -3.4254449605941772e-01
    z[2,6,0]  R1640     -2.2716903686523438e-01
    z[2,6,0]  R1641     1.6046869754791260e-01
    z[2,6,0]  R1642     2.3380806669592857e-03
    z[2,6,0]  R1643     5.3210145235061646e-01
    z[2,6,0]  R1644     -0.767795979976654
    z[2,6,0]  R1645     -1.9495630264282227e-01
    z[2,6,0]  R1646     1.4105166494846344e-01
    z[2,6,0]  R1647     4.1521412134170532e-01
    z[2,6,0]  R1648     -3.4050655364990234e-01
    z[2,6,0]  R1649     -1.2337133288383484e-01
    z[2,6,0]  R1650     -8.0893546342849731e-02
    z[2,6,0]  R1651     -0.316019743680954
    z[2,6,0]  R1652     -6.1593884229660034e-01
    z[2,6,0]  R1653     3.3860269188880920e-01
    z[2,6,0]  R1654     1.6142678260803223e-01
    z[2,6,1]  R21       -1
    z[2,6,1]  R57       1
    z[2,6,1]  R1573     -1
    z[2,6,1]  R1574     1
    z[2,6,1]  R1585     3.8441542536020279e-02
    z[2,6,1]  R1586     8.1759430468082428e-02
    z[2,6,1]  R1587     -4.0119934082031250e-01
    z[2,6,1]  R1588     -2.3960407078266144e-01
    z[2,6,1]  R1589     -3.0244883894920349e-01
    z[2,6,1]  R1590     -0.802794873714447
    z[2,6,1]  R1591     -8.8745057582855225e-01
    z[2,6,1]  R1592     -0.754834771156311
    z[2,6,1]  R1593     -3.9399498701095581e-01
    z[2,6,1]  R1594     8.5442259907722473e-02
    z[2,6,1]  R1595     5.6618911027908325e-01
    z[2,6,1]  R1596     2.3656965792179108e-01
    z[2,6,1]  R1597     5.4735934734344482e-01
    z[2,6,1]  R1598     4.4414228200912476e-01
    z[2,6,1]  R1599     6.6778522729873657e-01
    z[2,6,1]  R1600     6.4470344781875610e-01
    z[2,6,1]  R1601     4.5176360011100769e-01
    z[2,6,1]  R1602     3.9058855175971985e-01
    z[2,6,1]  R1603     4.3951633572578430e-01
    z[2,6,1]  R1604     6.5985703468322754e-01
    z[2,6,1]  R1605     2.5097227096557617e-01
    z[2,6,1]  R1606     0.688449501991272
    z[2,6,1]  R1607     4.6634155511856079e-01
    z[2,6,1]  R1608     -6.1167693138122559e-01
    z[2,6,1]  R1609     -5.3506873548030853e-02
    z[2,6,1]  R1610     -6.4141339063644409e-01
    z[2,6,1]  R1611     -7.2092831134796143e-01
    z[2,6,1]  R1612     -3.9164590835571289e-01
    z[2,6,1]  R1613     -6.4713460206985474e-01
    z[2,6,1]  R1614     -6.1470401287078857e-01
    z[2,6,1]  R1615     8.1374222040176392e-01
    z[2,6,1]  R1616     8.5356724262237549e-01
    z[2,6,1]  R1617     -6.6358691453933716e-01
    z[2,6,1]  R1618     -5.5984467267990112e-01
    z[2,6,1]  R1619     -6.9038879871368408e-01
    z[2,6,1]  R1620     -4.7251582145690918e-01
    z[2,6,1]  R1621     -7.4744731187820435e-01
    z[2,6,1]  R1622     -6.1545717716217041e-01
    z[2,6,1]  R1623     -3.5275623202323914e-01
    z[2,6,1]  R1624     -4.5408290624618530e-01
    z[2,6,1]  R1625     -3.5253381729125977e-01
    z[2,6,1]  R1626     8.0153006315231323e-01
    z[2,6,1]  R1627     8.7071365118026733e-01
    z[2,6,1]  R1628     5.4113519191741943e-01
    z[2,6,1]  R1629     5.0517255067825317e-01
    z[2,6,1]  R1630     0.586051881313324
    z[2,6,1]  R1631     5.4306948184967041e-01
    z[2,6,1]  R1632     8.1572657823562622e-01
    z[2,6,1]  R1633     -3.9696505665779114e-01
    z[2,6,1]  R1634     -2.6708725094795227e-01
    z[2,6,1]  R1635     5.9484001249074936e-02
    z[2,6,1]  R1636     0.0543687604367733
    z[2,6,1]  R1637     6.3366413116455078e-02
    z[2,6,1]  R1638     4.9888465553522110e-02
    z[2,6,1]  R1639     2.9684877954423428e-03
    z[2,6,1]  R1640     8.2638889551162720e-02
    z[2,6,1]  R1641     -3.6709473934024572e-03
    z[2,6,1]  R1642     -8.7194317579269409e-01
    z[2,6,1]  R1643     -4.8741912841796875e-01
    z[2,6,1]  R1644     -1.3693065941333771e-01
    z[2,6,1]  R1645     -2.3118425905704498e-01
    z[2,6,1]  R1646     0.755187451839447
    z[2,6,1]  R1647     7.3013103008270264e-01
    z[2,6,1]  R1648     6.6247063875198364e-01
    z[2,6,1]  R1649     4.9459806084632874e-01
    z[2,6,1]  R1650     4.6404811739921570e-01
    z[2,6,1]  R1651     3.1120446324348450e-01
    z[2,6,1]  R1652     3.3675163984298706e-01
    z[2,6,1]  R1653     -8.5062372684478760e-01
    z[2,6,1]  R1654     -8.1816995143890381e-01
    z[2,6,2]  R22       -1
    z[2,6,2]  R58       1
    z[2,6,2]  R1575     -1
    z[2,6,2]  R1576     1
    z[2,6,2]  R1585     7.4965290725231171e-02
    z[2,6,2]  R1586     0.681813657283783
    z[2,6,2]  R1587     1.4072988927364349e-01
    z[2,6,2]  R1588     1.7492705583572388e-01
    z[2,6,2]  R1589     1.3756878674030304e-02
    z[2,6,2]  R1590     -1.7958280444145203e-01
    z[2,6,2]  R1591     -3.4977486357092857e-03
    z[2,6,2]  R1592     1.0772727429866791e-01
    z[2,6,2]  R1593     3.0122503638267517e-01
    z[2,6,2]  R1594     5.3374260663986206e-01
    z[2,6,2]  R1595     3.3036175370216370e-01
    z[2,6,2]  R1596     -1.0271928459405899e-01
    z[2,6,2]  R1597     3.5235092509537935e-03
    z[2,6,2]  R1598     -1.6434369981288910e-01
    z[2,6,2]  R1599     -3.0935943126678467e-01
    z[2,6,2]  R1600     2.0727092027664185e-01
    z[2,6,2]  R1601     -3.2779264450073242e-01
    z[2,6,2]  R1602     2.4899050593376160e-01
    z[2,6,2]  R1603     -9.0174794197082520e-02
    z[2,6,2]  R1604     -1.8114100396633148e-01
    z[2,6,2]  R1605     7.9812347888946533e-01
    z[2,6,2]  R1606     6.2663513422012329e-01
    z[2,6,2]  R1607     4.0392029285430908e-01
    z[2,6,2]  R1608     -7.3203317821025848e-02
    z[2,6,2]  R1609     2.7970877289772034e-01
    z[2,6,2]  R1610     1.5855786204338074e-01
    z[2,6,2]  R1611     2.7109023928642273e-01
    z[2,6,2]  R1612     -1.7429442703723907e-01
    z[2,6,2]  R1613     -5.2469903230667114e-01
    z[2,6,2]  R1614     2.7236273884773254e-01
    z[2,6,2]  R1615     -1.1220594495534897e-01
    z[2,6,2]  R1616     -3.8480564951896667e-01
    z[2,6,2]  R1617     2.0183211192488670e-02
    z[2,6,2]  R1618     2.4744583293795586e-02
    z[2,6,2]  R1619     -2.3151947557926178e-01
    z[2,6,2]  R1620     -2.6929610967636108e-01
    z[2,6,2]  R1621     3.4785324335098267e-01
    z[2,6,2]  R1622     4.8382428288459778e-01
    z[2,6,2]  R1623     2.1594485267996788e-02
    z[2,6,2]  R1624     -2.0730255171656609e-02
    z[2,6,2]  R1625     1.1036302149295807e-01
    z[2,6,2]  R1626     3.5348507761955261e-01
    z[2,6,2]  R1627     0.0318136028945446
    z[2,6,2]  R1628     5.4831538349390030e-02
    z[2,6,2]  R1629     4.4717624783515930e-02
    z[2,6,2]  R1630     -1.7602179944515228e-01
    z[2,6,2]  R1631     2.6207652688026428e-01
    z[2,6,2]  R1632     -4.0650373697280884e-01
    z[2,6,2]  R1633     4.3773704767227173e-01
    z[2,6,2]  R1634     3.4073731303215027e-01
    z[2,6,2]  R1635     9.0363526344299316e-01
    z[2,6,2]  R1636     6.0082674026489258e-01
    z[2,6,2]  R1637     8.2879191637039185e-01
    z[2,6,2]  R1638     0.734775722026825
    z[2,6,2]  R1639     6.4357602596282959e-01
    z[2,6,2]  R1640     1.3082157075405121e-01
    z[2,6,2]  R1641     4.5716318488121033e-01
    z[2,6,2]  R1642     -1.2676886282861233e-02
    z[2,6,2]  R1643     3.1302943825721741e-02
    z[2,6,2]  R1644     -2.5597837567329407e-01
    z[2,6,2]  R1645     -4.6411642432212830e-01
    z[2,6,2]  R1646     -4.1137015819549561e-01
    z[2,6,2]  R1647     -4.1148072481155396e-01
    z[2,6,2]  R1648     -2.4406099319458008e-01
    z[2,6,2]  R1649     -8.6108408868312836e-02
    z[2,6,2]  R1650     2.5306552648544312e-01
    z[2,6,2]  R1651     1.0281375050544739e-01
    z[2,6,2]  R1652     -2.5616028904914856e-01
    z[2,6,2]  R1653     -9.8373480141162872e-02
    z[2,6,2]  R1654     -3.8059923052787781e-01
    z[2,6,3]  R23       -1
    z[2,6,3]  R59       1
    z[2,6,3]  R1577     -1
    z[2,6,3]  R1578     1
    z[2,6,3]  R1585     -6.8057513236999512e-01
    z[2,6,3]  R1586     1.2966774404048920e-01
    z[2,6,3]  R1587     1.4103873074054718e-01
    z[2,6,3]  R1588     2.2557689249515533e-01
    z[2,6,3]  R1589     3.4696063399314880e-01
    z[2,6,3]  R1590     1.0997498035430908e-01
    z[2,6,3]  R1591     -1.4441721141338348e-01
    z[2,6,3]  R1592     -3.9046889543533325e-01
    z[2,6,3]  R1593     2.1113230288028717e-01
    z[2,6,3]  R1594     -4.3737614154815674e-01
    z[2,6,3]  R1595     -0.275144100189209
    z[2,6,3]  R1596     3.6345925927162170e-01
    z[2,6,3]  R1597     -1.2501551210880280e-01
    z[2,6,3]  R1598     -4.3762576580047607e-01
    z[2,6,3]  R1599     -3.6428907513618469e-01
    z[2,6,3]  R1600     7.4119992554187775e-02
    z[2,6,3]  R1601     -2.9075714945793152e-01
    z[2,6,3]  R1602     -1.3685405254364014e-02
    z[2,6,3]  R1603     -1.0349833220243454e-01
    z[2,6,3]  R1604     5.0873857736587524e-01
    z[2,6,3]  R1605     -3.3803546428680420e-01
    z[2,6,3]  R1606     2.2532603144645691e-01
    z[2,6,3]  R1607     5.0569951534271240e-01
    z[2,6,3]  R1608     5.6493043899536133e-01
    z[2,6,3]  R1609     -5.5822163820266724e-01
    z[2,6,3]  R1610     1.5094357728958130e-01
    z[2,6,3]  R1611     -6.5323412418365479e-02
    z[2,6,3]  R1612     1.8714305013418198e-02
    z[2,6,3]  R1613     2.0260209217667580e-02
    z[2,6,3]  R1614     -4.6693214774131775e-01
    z[2,6,3]  R1615     1.3155084848403931e-01
    z[2,6,3]  R1616     0.0213027261197567
    z[2,6,3]  R1617     -1.2451861053705215e-01
    z[2,6,3]  R1618     1.3461527228355408e-01
    z[2,6,3]  R1619     -3.0403189361095428e-02
    z[2,6,3]  R1620     -3.1890103220939636e-01
    z[2,6,3]  R1621     3.0515128374099731e-01
    z[2,6,3]  R1622     -2.7336540818214417e-01
    z[2,6,3]  R1623     -2.2930863499641418e-01
    z[2,6,3]  R1624     -6.9702661037445068e-01
    z[2,6,3]  R1625     3.9165702462196350e-01
    z[2,6,3]  R1626     9.0290986001491547e-02
    z[2,6,3]  R1627     1.1057351529598236e-01
    z[2,6,3]  R1628     -6.4202737808227539e-01
    z[2,6,3]  R1629     -2.9270380735397339e-01
    z[2,6,3]  R1630     -4.7821402549743652e-01
    z[2,6,3]  R1631     5.7964488863945007e-02
    z[2,6,3]  R1632     -0.312037855386734
    z[2,6,3]  R1633     2.0122438669204712e-01
    z[2,6,3]  R1634     -1.0564703494310379e-01
    z[2,6,3]  R1635     -1.7220060527324677e-01
    z[2,6,3]  R1636     -4.9672982096672058e-01
    z[2,6,3]  R1637     -4.0433195233345032e-01
    z[2,6,3]  R1638     -0.330777645111084
    z[2,6,3]  R1639     -6.6862158477306366e-02
    z[2,6,3]  R1640     -8.7391048669815063e-01
    z[2,6,3]  R1641     4.3200913071632385e-01
    z[2,6,3]  R1642     0.178828626871109
    z[2,6,3]  R1643     3.6172637343406677e-01
    z[2,6,3]  R1644     -5.7961666025221348e-03
    z[2,6,3]  R1645     -1.2184821814298630e-01
    z[2,6,3]  R1646     -4.7170307487249374e-02
    z[2,6,3]  R1647     -3.9499200880527496e-02
    z[2,6,3]  R1648     2.5259786844253540e-01
    z[2,6,3]  R1649     6.0434317588806152e-01
    z[2,6,3]  R1650     5.1674425601959229e-01
    z[2,6,3]  R1651     9.4966374337673187e-02
    z[2,6,3]  R1652     9.8139166831970215e-02
    z[2,6,3]  R1653     3.6098104715347290e-01
    z[2,6,3]  R1654     -1.4106282033026218e-02
    z[2,6,4]  R24       -1
    z[2,6,4]  R60       1
    z[2,6,4]  R1579     -1
    z[2,6,4]  R1580     1
    z[2,6,4]  R1585     -1.1373429745435715e-01
    z[2,6,4]  R1586     8.2437492907047272e-02
    z[2,6,4]  R1587     -2.3470453917980194e-01
    z[2,6,4]  R1588     -1.1266208440065384e-01
    z[2,6,4]  R1589     -2.7110788226127625e-01
    z[2,6,4]  R1590     -3.5360220074653625e-01
    z[2,6,4]  R1591     -3.2983240485191345e-01
    z[2,6,4]  R1592     -9.7517386078834534e-02
    z[2,6,4]  R1593     -8.8615730404853821e-02
    z[2,6,4]  R1594     1.9421349465847015e-01
    z[2,6,4]  R1595     0.525259792804718
    z[2,6,4]  R1596     4.0166336297988892e-01
    z[2,6,4]  R1597     7.6657354831695557e-01
    z[2,6,4]  R1598     5.4183059930801392e-01
    z[2,6,4]  R1599     -1.5221124887466431e-01
    z[2,6,4]  R1600     -4.2753493785858154e-01
    z[2,6,4]  R1601     2.6012265682220459e-01
    z[2,6,4]  R1602     -1.6520659625530243e-01
    z[2,6,4]  R1603     -4.2838916182518005e-02
    z[2,6,4]  R1604     7.7875934541225433e-02
    z[2,6,4]  R1605     1.7025533318519592e-01
    z[2,6,4]  R1606     -2.5707101821899414e-01
    z[2,6,4]  R1607     1.9409327208995819e-01
    z[2,6,4]  R1608     -4.1895397007465363e-02
    z[2,6,4]  R1609     6.2116956710815430e-01
    z[2,6,4]  R1610     2.3017503321170807e-01
    z[2,6,4]  R1611     4.8447516560554504e-01
    z[2,6,4]  R1612     2.1125909686088562e-01
    z[2,6,4]  R1613     -1.2951073586009443e-04
    z[2,6,4]  R1614     1.1897636950016022e-01
    z[2,6,4]  R1615     -2.8945109248161316e-01
    z[2,6,4]  R1616     -1.0832422971725464e-01
    z[2,6,4]  R1617     2.0887608826160431e-01
    z[2,6,4]  R1618     8.3890803158283234e-02
    z[2,6,4]  R1619     3.4508371353149414e-01
    z[2,6,4]  R1620     1.8232037127017975e-01
    z[2,6,4]  R1621     -1.4317064546048641e-02
    z[2,6,4]  R1622     -1.6430977731943130e-02
    z[2,6,4]  R1623     -2.9563827440142632e-02
    z[2,6,4]  R1624     1.5581177175045013e-01
    z[2,6,4]  R1625     4.5532783865928650e-01
    z[2,6,4]  R1626     -5.0584875047206879e-02
    z[2,6,4]  R1627     1.6250425577163696e-01
    z[2,6,4]  R1628     -7.6470471918582916e-02
    z[2,6,4]  R1629     2.8865805268287659e-01
    z[2,6,4]  R1630     1.6766466200351715e-01
    z[2,6,4]  R1631     4.0400851517915726e-02
    z[2,6,4]  R1632     -1.3726890087127686e-01
    z[2,6,4]  R1633     -1.5371577441692352e-01
    z[2,6,4]  R1634     2.8815966844558716e-01
    z[2,6,4]  R1635     2.1855711936950684e-01
    z[2,6,4]  R1636     3.6860066652297974e-01
    z[2,6,4]  R1637     1.1693480610847473e-01
    z[2,6,4]  R1638     2.8102025389671326e-01
    z[2,6,4]  R1639     5.4940587282180786e-01
    z[2,6,4]  R1640     9.3946486711502075e-02
    z[2,6,4]  R1641     4.8800927400588989e-01
    z[2,6,4]  R1642     -3.2916495203971863e-01
    z[2,6,4]  R1643     -4.6568018198013306e-01
    z[2,6,4]  R1644     -1.6710628569126129e-01
    z[2,6,4]  R1645     1.5868784487247467e-01
    z[2,6,4]  R1646     0.306011825799942
    z[2,6,4]  R1647     -2.2578364610671997e-01
    z[2,6,4]  R1648     -3.1393823027610779e-01
    z[2,6,4]  R1649     -3.7847158312797546e-01
    z[2,6,4]  R1650     -4.5780256390571594e-01
    z[2,6,4]  R1651     -8.1053566932678223e-01
    z[2,6,4]  R1652     -5.7097882032394409e-01
    z[2,6,4]  R1653     -1.1380314081907272e-01
    z[2,6,4]  R1654     -1.3239854574203491e-01
    z[2,6,5]  R25       -1
    z[2,6,5]  R61       1
    z[2,6,5]  R1581     -1
    z[2,6,5]  R1582     1
    z[2,6,5]  R1585     -5.6261110305786133e-01
    z[2,6,5]  R1586     -4.5188632607460022e-01
    z[2,6,5]  R1587     4.7491684556007385e-02
    z[2,6,5]  R1588     1.0402470082044601e-01
    z[2,6,5]  R1589     -6.2023870646953583e-02
    z[2,6,5]  R1590     -1.0046847164630890e-02
    z[2,6,5]  R1591     -2.1654093638062477e-02
    z[2,6,5]  R1592     -3.4643489122390747e-01
    z[2,6,5]  R1593     -3.7767979502677917e-01
    z[2,6,5]  R1594     -1.7442518472671509e-01
    z[2,6,5]  R1595     3.4574168920516968e-01
    z[2,6,5]  R1596     -5.5439078807830811e-01
    z[2,6,5]  R1597     -2.3657123744487762e-01
    z[2,6,5]  R1598     2.0953471958637238e-01
    z[2,6,5]  R1599     0.50971519947052
    z[2,6,5]  R1600     2.0126949250698090e-01
    z[2,6,5]  R1601     -8.6231883615255356e-03
    z[2,6,5]  R1602     6.8229717016220093e-01
    z[2,6,5]  R1603     4.6939301490783691e-01
    z[2,6,5]  R1604     4.2282477021217346e-01
    z[2,6,5]  R1605     6.1182837933301926e-02
    z[2,6,5]  R1606     -1.1985354125499725e-01
    z[2,6,5]  R1607     8.6183302104473114e-02
    z[2,6,5]  R1608     2.4325927719473839e-02
    z[2,6,5]  R1609     1.0157548636198044e-01
    z[2,6,5]  R1610     4.8351404070854187e-01
    z[2,6,5]  R1611     8.5496142506599426e-02
    z[2,6,5]  R1612     4.2921945452690125e-01
    z[2,6,5]  R1613     -1.6942197084426880e-01
    z[2,6,5]  R1614     2.2209188342094421e-01
    z[2,6,5]  R1615     -1.5760114416480064e-02
    z[2,6,5]  R1616     0.0844428762793541
    z[2,6,5]  R1617     2.1522009372711182e-01
    z[2,6,5]  R1618     -5.1006329059600830e-01
    z[2,6,5]  R1619     -2.1311371028423309e-01
    z[2,6,5]  R1620     1.6942206025123596e-01
    z[2,6,5]  R1621     -3.9063182473182678e-01
    z[2,6,5]  R1622     2.0191356539726257e-01
    z[2,6,5]  R1623     2.2902959585189819e-01
    z[2,6,5]  R1624     -5.8947563171386719e-02
    z[2,6,5]  R1625     -4.1749498248100281e-01
    z[2,6,5]  R1626     -3.7870484590530396e-01
    z[2,6,5]  R1627     -0.415229469537735
    z[2,6,5]  R1628     -0.0883241817355156
    z[2,6,5]  R1629     4.2321172356605530e-01
    z[2,6,5]  R1630     1.6260632872581482e-01
    z[2,6,5]  R1631     0.0569465234875679
    z[2,6,5]  R1632     -1.6966991126537323e-01
    z[2,6,5]  R1633     -3.0250322818756104e-01
    z[2,6,5]  R1634     3.7471261620521545e-01
    z[2,6,5]  R1635     -1.3518853485584259e-01
    z[2,6,5]  R1636     -2.8702250123023987e-01
    z[2,6,5]  R1637     8.6273632943630219e-02
    z[2,6,5]  R1638     -4.5111864805221558e-01
    z[2,6,5]  R1639     4.0043982863426208e-01
    z[2,6,5]  R1640     -2.8760471940040588e-01
    z[2,6,5]  R1641     1.2319029122591019e-01
    z[2,6,5]  R1642     -1.3998635113239288e-01
    z[2,6,5]  R1643     7.2343222796916962e-02
    z[2,6,5]  R1644     -5.0539571791887283e-02
    z[2,6,5]  R1645     -7.9557329416275024e-01
    z[2,6,5]  R1646     -9.9694781005382538e-02
    z[2,6,5]  R1647     0.257186621427536
    z[2,6,5]  R1648     -8.3370454609394073e-02
    z[2,6,5]  R1649     -3.2267215847969055e-01
    z[2,6,5]  R1650     1.8452392518520355e-01
    z[2,6,5]  R1651     3.5069581866264343e-01
    z[2,6,5]  R1652     7.1079894900321960e-02
    z[2,6,5]  R1653     8.4961839020252228e-02
    z[2,6,5]  R1654     3.3967030048370361e-01
    z[2,6,6]  R26       -1
    z[2,6,6]  R62       1
    z[2,6,6]  R1583     -1
    z[2,6,6]  R1584     1
    z[2,6,6]  R1585     -2.4012371897697449e-01
    z[2,6,6]  R1586     -4.7786796092987061e-01
    z[2,6,6]  R1587     -3.2327172160148621e-01
    z[2,6,6]  R1588     0.266877144575119
    z[2,6,6]  R1589     -5.2893865853548050e-02
    z[2,6,6]  R1590     -9.8525643348693848e-02
    z[2,6,6]  R1591     3.1339146196842194e-02
    z[2,6,6]  R1592     1.8047126010060310e-02
    z[2,6,6]  R1593     -2.8784683346748352e-01
    z[2,6,6]  R1594     2.2689154744148254e-01
    z[2,6,6]  R1595     -2.5508137419819832e-02
    z[2,6,6]  R1596     5.3439790010452271e-01
    z[2,6,6]  R1597     -1.0268667340278625e-01
    z[2,6,6]  R1598     -3.8092023134231567e-01
    z[2,6,6]  R1599     0.0318525955080986
    z[2,6,6]  R1600     -1.4917287230491638e-01
    z[2,6,6]  R1601     7.3223048448562622e-01
    z[2,6,6]  R1602     -1.7481561005115509e-01
    z[2,6,6]  R1603     6.6362321376800537e-01
    z[2,6,6]  R1604     2.5549495220184326e-01
    z[2,6,6]  R1605     -1.6688092052936554e-01
    z[2,6,6]  R1606     -4.5651599764823914e-02
    z[2,6,6]  R1607     2.2808927297592163e-01
    z[2,6,6]  R1608     -1.2586400844156742e-02
    z[2,6,6]  R1609     3.8680014014244080e-01
    z[2,6,6]  R1610     -2.9306897521018982e-01
    z[2,6,6]  R1611     -1.7781928181648254e-01
    z[2,6,6]  R1612     0.344841331243515
    z[2,6,6]  R1613     -1.3751790858805180e-02
    z[2,6,6]  R1614     -0.413039892911911
    z[2,6,6]  R1615     3.5972705483436584e-01
    z[2,6,6]  R1616     -3.1692448258399963e-01
    z[2,6,6]  R1617     4.4062426686286926e-01
    z[2,6,6]  R1618     1.4996452629566193e-01
    z[2,6,6]  R1619     1.2894116342067719e-01
    z[2,6,6]  R1620     3.3351856470108032e-01
    z[2,6,6]  R1621     -1.2531548738479614e-02
    z[2,6,6]  R1622     -3.5553896427154541e-01
    z[2,6,6]  R1623     1.3812610507011414e-01
    z[2,6,6]  R1624     1.3690458238124847e-01
    z[2,6,6]  R1625     -3.0597314238548279e-01
    z[2,6,6]  R1626     -1.6123616695404053e-01
    z[2,6,6]  R1627     1.7207552492618561e-01
    z[2,6,6]  R1628     5.1867133378982544e-01
    z[2,6,6]  R1629     4.6384155750274658e-01
    z[2,6,6]  R1630     2.1356520056724548e-01
    z[2,6,6]  R1631     4.2806592583656311e-01
    z[2,6,6]  R1632     1.4733320474624634e-01
    z[2,6,6]  R1633     -3.1754586845636368e-02
    z[2,6,6]  R1634     2.4821478128433228e-01
    z[2,6,6]  R1635     1.5851153433322906e-01
    z[2,6,6]  R1636     3.4828382730484009e-01
    z[2,6,6]  R1637     -7.6698742806911469e-02
    z[2,6,6]  R1638     -2.2745883464813232e-01
    z[2,6,6]  R1639     4.2368043214082718e-02
    z[2,6,6]  R1640     -2.6303768157958984e-01
    z[2,6,6]  R1641     5.7033085823059082e-01
    z[2,6,6]  R1642     -2.8217649459838867e-01
    z[2,6,6]  R1643     -3.5408067703247070e-01
    z[2,6,6]  R1644     5.4378491640090942e-01
    z[2,6,6]  R1645     1.4204236865043640e-01
    z[2,6,6]  R1646     3.6710157990455627e-01
    z[2,6,6]  R1647     8.0660529434680939e-02
    z[2,6,6]  R1648     -0.4650898873806
    z[2,6,6]  R1649     3.4662488102912903e-01
    z[2,6,6]  R1650     -4.5101717114448547e-01
    z[2,6,6]  R1651     -0.061142697930336
    z[2,6,6]  R1652     3.1764614582061768e-01
    z[2,6,6]  R1653     -4.0411904454231262e-02
    z[2,6,6]  R1654     1.6303151845932007e-01
    z[6,2,0]  R20       1
    z[6,2,0]  R56       -1
    z[6,2,0]  R1655     -1
    z[6,2,0]  R1656     1
    z[6,2,0]  R1669     -2.4306967854499817e-01
    z[6,2,0]  R1670     2.2307108342647552e-01
    z[6,2,0]  R1671     3.4439027309417725e-01
    z[6,2,0]  R1672     -1.1825361847877502e-01
    z[6,2,0]  R1673     -3.4254449605941772e-01
    z[6,2,0]  R1674     -2.2716903686523438e-01
    z[6,2,0]  R1675     1.6046869754791260e-01
    z[6,2,0]  R1676     2.3380806669592857e-03
    z[6,2,0]  R1677     5.3210145235061646e-01
    z[6,2,0]  R1678     -0.767795979976654
    z[6,2,0]  R1679     -1.9495630264282227e-01
    z[6,2,0]  R1680     1.4105166494846344e-01
    z[6,2,0]  R1681     4.1521412134170532e-01
    z[6,2,0]  R1682     -3.4050655364990234e-01
    z[6,2,0]  R1683     -1.2337133288383484e-01
    z[6,2,0]  R1684     -8.0893546342849731e-02
    z[6,2,0]  R1685     -0.316019743680954
    z[6,2,0]  R1686     -6.1593884229660034e-01
    z[6,2,0]  R1687     3.3860269188880920e-01
    z[6,2,0]  R1688     1.6142678260803223e-01
    z[6,2,0]  R1689     -3.7761595845222473e-01
    z[6,2,0]  R1690     -2.6884365081787109e-01
    z[6,2,0]  R1691     7.9843342304229736e-01
    z[6,2,0]  R1692     8.7542468309402466e-01
    z[6,2,0]  R1693     8.4131413698196411e-01
    z[6,2,0]  R1694     0.419920414686203
    z[6,2,0]  R1695     0.285171240568161
    z[6,2,0]  R1696     3.6918950080871582e-01
    z[6,2,0]  R1697     6.9000291824340820e-01
    z[6,2,0]  R1698     6.2999832630157471e-01
    z[6,2,0]  R1699     -3.1384840607643127e-01
    z[6,2,0]  R1700     -2.1706500649452209e-01
    z[6,2,0]  R1701     1.7495959997177124e-01
    z[6,2,0]  R1702     3.1879001855850220e-01
    z[6,2,0]  R1703     2.0410983264446259e-01
    z[6,2,0]  R1704     0.538845419883728
    z[6,2,0]  R1705     4.7156815417110920e-03
    z[6,2,0]  R1706     5.1173609495162964e-01
    z[6,2,0]  R1707     3.5414862632751465e-01
    z[6,2,0]  R1708     1.5112403035163879e-01
    z[6,2,0]  R1709     3.5378584265708923e-01
    z[6,2,0]  R1710     -7.7039031311869621e-03
    z[6,2,0]  R1711     5.1625329256057739e-01
    z[6,2,0]  R1712     5.4666346311569214e-01
    z[6,2,0]  R1713     -2.4800196290016174e-01
    z[6,2,0]  R1714     4.0988841652870178e-01
    z[6,2,0]  R1715     3.5897067189216614e-01
    z[6,2,0]  R1716     6.8418520689010620e-01
    z[6,2,0]  R1717     5.2593183517456055e-01
    z[6,2,0]  R1718     3.0959594249725342e-01
    z[6,2,0]  R1719     -3.0739870667457581e-01
    z[6,2,0]  R1720     -5.9899266809225082e-02
    z[6,2,0]  R1721     5.0955039262771606e-01
    z[6,2,0]  R1722     6.1493802070617676e-01
    z[6,2,0]  R1723     0.53638756275177
    z[6,2,0]  R1724     6.5523380041122437e-01
    z[6,2,0]  R1725     2.7248516678810120e-01
    z[6,2,0]  R1726     3.8072407245635986e-01
    z[6,2,0]  R1727     8.6608707904815674e-01
    z[6,2,0]  R1728     5.1091867685317993e-01
    z[6,2,0]  R1729     -4.8466438055038452e-01
    z[6,2,0]  R1730     -2.2906814515590668e-01
    z[6,2,0]  R1731     -1.3635233044624329e-02
    z[6,2,0]  R1732     9.6427626907825470e-02
    z[6,2,0]  R1733     4.2372739315032959e-01
    z[6,2,0]  R1734     5.4470956325531006e-01
    z[6,2,0]  R1735     6.6702020168304443e-01
    z[6,2,0]  R1736     5.1377475261688232e-02
    z[6,2,0]  R1737     7.0297127962112427e-01
    z[6,2,0]  R1738     7.1857148408889771e-01
    z[6,2,1]  R21       1
    z[6,2,1]  R57       -1
    z[6,2,1]  R1657     -1
    z[6,2,1]  R1658     1
    z[6,2,1]  R1669     5.9484001249074936e-02
    z[6,2,1]  R1670     0.0543687604367733
    z[6,2,1]  R1671     6.3366413116455078e-02
    z[6,2,1]  R1672     4.9888465553522110e-02
    z[6,2,1]  R1673     2.9684877954423428e-03
    z[6,2,1]  R1674     8.2638889551162720e-02
    z[6,2,1]  R1675     -3.6709473934024572e-03
    z[6,2,1]  R1676     -8.7194317579269409e-01
    z[6,2,1]  R1677     -4.8741912841796875e-01
    z[6,2,1]  R1678     -1.3693065941333771e-01
    z[6,2,1]  R1679     -2.3118425905704498e-01
    z[6,2,1]  R1680     0.755187451839447
    z[6,2,1]  R1681     7.3013103008270264e-01
    z[6,2,1]  R1682     6.6247063875198364e-01
    z[6,2,1]  R1683     4.9459806084632874e-01
    z[6,2,1]  R1684     4.6404811739921570e-01
    z[6,2,1]  R1685     3.1120446324348450e-01
    z[6,2,1]  R1686     3.3675163984298706e-01
    z[6,2,1]  R1687     -8.5062372684478760e-01
    z[6,2,1]  R1688     -8.1816995143890381e-01
    z[6,2,1]  R1689     3.8441542536020279e-02
    z[6,2,1]  R1690     8.1759430468082428e-02
    z[6,2,1]  R1691     -4.0119934082031250e-01
    z[6,2,1]  R1692     -2.3960407078266144e-01
    z[6,2,1]  R1693     -3.0244883894920349e-01
    z[6,2,1]  R1694     -0.802794873714447
    z[6,2,1]  R1695     -8.8745057582855225e-01
    z[6,2,1]  R1696     -0.754834771156311
    z[6,2,1]  R1697     -3.9399498701095581e-01
    z[6,2,1]  R1698     8.5442259907722473e-02
    z[6,2,1]  R1699     5.6618911027908325e-01
    z[6,2,1]  R1700     2.3656965792179108e-01
    z[6,2,1]  R1701     5.4735934734344482e-01
    z[6,2,1]  R1702     4.4414228200912476e-01
    z[6,2,1]  R1703     6.6778522729873657e-01
    z[6,2,1]  R1704     6.4470344781875610e-01
    z[6,2,1]  R1705     4.5176360011100769e-01
    z[6,2,1]  R1706     3.9058855175971985e-01
    z[6,2,1]  R1707     4.3951633572578430e-01
    z[6,2,1]  R1708     6.5985703468322754e-01
    z[6,2,1]  R1709     2.5097227096557617e-01
    z[6,2,1]  R1710     0.688449501991272
    z[6,2,1]  R1711     4.6634155511856079e-01
    z[6,2,1]  R1712     -6.1167693138122559e-01
    z[6,2,1]  R1713     -5.3506873548030853e-02
    z[6,2,1]  R1714     -6.4141339063644409e-01
    z[6,2,1]  R1715     -7.2092831134796143e-01
    z[6,2,1]  R1716     -3.9164590835571289e-01
    z[6,2,1]  R1717     -6.4713460206985474e-01
    z[6,2,1]  R1718     -6.1470401287078857e-01
    z[6,2,1]  R1719     8.1374222040176392e-01
    z[6,2,1]  R1720     8.5356724262237549e-01
    z[6,2,1]  R1721     -6.6358691453933716e-01
    z[6,2,1]  R1722     -5.5984467267990112e-01
    z[6,2,1]  R1723     -6.9038879871368408e-01
    z[6,2,1]  R1724     -4.7251582145690918e-01
    z[6,2,1]  R1725     -7.4744731187820435e-01
    z[6,2,1]  R1726     -6.1545717716217041e-01
    z[6,2,1]  R1727     -3.5275623202323914e-01
    z[6,2,1]  R1728     -4.5408290624618530e-01
    z[6,2,1]  R1729     -3.5253381729125977e-01
    z[6,2,1]  R1730     8.0153006315231323e-01
    z[6,2,1]  R1731     8.7071365118026733e-01
    z[6,2,1]  R1732     5.4113519191741943e-01
    z[6,2,1]  R1733     5.0517255067825317e-01
    z[6,2,1]  R1734     0.586051881313324
    z[6,2,1]  R1735     5.4306948184967041e-01
    z[6,2,1]  R1736     8.1572657823562622e-01
    z[6,2,1]  R1737     -3.9696505665779114e-01
    z[6,2,1]  R1738     -2.6708725094795227e-01
    z[6,2,2]  R22       1
    z[6,2,2]  R58       -1
    z[6,2,2]  R1659     -1
    z[6,2,2]  R1660     1
    z[6,2,2]  R1669     9.0363526344299316e-01
    z[6,2,2]  R1670     6.0082674026489258e-01
    z[6,2,2]  R1671     8.2879191637039185e-01
    z[6,2,2]  R1672     0.734775722026825
    z[6,2,2]  R1673     6.4357602596282959e-01
    z[6,2,2]  R1674     1.3082157075405121e-01
    z[6,2,2]  R1675     4.5716318488121033e-01
    z[6,2,2]  R1676     -1.2676886282861233e-02
    z[6,2,2]  R1677     3.1302943825721741e-02
    z[6,2,2]  R1678     -2.5597837567329407e-01
    z[6,2,2]  R1679     -4.6411642432212830e-01
    z[6,2,2]  R1680     -4.1137015819549561e-01
    z[6,2,2]  R1681     -4.1148072481155396e-01
    z[6,2,2]  R1682     -2.4406099319458008e-01
    z[6,2,2]  R1683     -8.6108408868312836e-02
    z[6,2,2]  R1684     2.5306552648544312e-01
    z[6,2,2]  R1685     1.0281375050544739e-01
    z[6,2,2]  R1686     -2.5616028904914856e-01
    z[6,2,2]  R1687     -9.8373480141162872e-02
    z[6,2,2]  R1688     -3.8059923052787781e-01
    z[6,2,2]  R1689     7.4965290725231171e-02
    z[6,2,2]  R1690     0.681813657283783
    z[6,2,2]  R1691     1.4072988927364349e-01
    z[6,2,2]  R1692     1.7492705583572388e-01
    z[6,2,2]  R1693     1.3756878674030304e-02
    z[6,2,2]  R1694     -1.7958280444145203e-01
    z[6,2,2]  R1695     -3.4977486357092857e-03
    z[6,2,2]  R1696     1.0772727429866791e-01
    z[6,2,2]  R1697     3.0122503638267517e-01
    z[6,2,2]  R1698     5.3374260663986206e-01
    z[6,2,2]  R1699     3.3036175370216370e-01
    z[6,2,2]  R1700     -1.0271928459405899e-01
    z[6,2,2]  R1701     3.5235092509537935e-03
    z[6,2,2]  R1702     -1.6434369981288910e-01
    z[6,2,2]  R1703     -3.0935943126678467e-01
    z[6,2,2]  R1704     2.0727092027664185e-01
    z[6,2,2]  R1705     -3.2779264450073242e-01
    z[6,2,2]  R1706     2.4899050593376160e-01
    z[6,2,2]  R1707     -9.0174794197082520e-02
    z[6,2,2]  R1708     -1.8114100396633148e-01
    z[6,2,2]  R1709     7.9812347888946533e-01
    z[6,2,2]  R1710     6.2663513422012329e-01
    z[6,2,2]  R1711     4.0392029285430908e-01
    z[6,2,2]  R1712     -7.3203317821025848e-02
    z[6,2,2]  R1713     2.7970877289772034e-01
    z[6,2,2]  R1714     1.5855786204338074e-01
    z[6,2,2]  R1715     2.7109023928642273e-01
    z[6,2,2]  R1716     -1.7429442703723907e-01
    z[6,2,2]  R1717     -5.2469903230667114e-01
    z[6,2,2]  R1718     2.7236273884773254e-01
    z[6,2,2]  R1719     -1.1220594495534897e-01
    z[6,2,2]  R1720     -3.8480564951896667e-01
    z[6,2,2]  R1721     2.0183211192488670e-02
    z[6,2,2]  R1722     2.4744583293795586e-02
    z[6,2,2]  R1723     -2.3151947557926178e-01
    z[6,2,2]  R1724     -2.6929610967636108e-01
    z[6,2,2]  R1725     3.4785324335098267e-01
    z[6,2,2]  R1726     4.8382428288459778e-01
    z[6,2,2]  R1727     2.1594485267996788e-02
    z[6,2,2]  R1728     -2.0730255171656609e-02
    z[6,2,2]  R1729     1.1036302149295807e-01
    z[6,2,2]  R1730     3.5348507761955261e-01
    z[6,2,2]  R1731     0.0318136028945446
    z[6,2,2]  R1732     5.4831538349390030e-02
    z[6,2,2]  R1733     4.4717624783515930e-02
    z[6,2,2]  R1734     -1.7602179944515228e-01
    z[6,2,2]  R1735     2.6207652688026428e-01
    z[6,2,2]  R1736     -4.0650373697280884e-01
    z[6,2,2]  R1737     4.3773704767227173e-01
    z[6,2,2]  R1738     3.4073731303215027e-01
    z[6,2,3]  R23       1
    z[6,2,3]  R59       -1
    z[6,2,3]  R1661     -1
    z[6,2,3]  R1662     1
    z[6,2,3]  R1669     -1.7220060527324677e-01
    z[6,2,3]  R1670     -4.9672982096672058e-01
    z[6,2,3]  R1671     -4.0433195233345032e-01
    z[6,2,3]  R1672     -0.330777645111084
    z[6,2,3]  R1673     -6.6862158477306366e-02
    z[6,2,3]  R1674     -8.7391048669815063e-01
    z[6,2,3]  R1675     4.3200913071632385e-01
    z[6,2,3]  R1676     0.178828626871109
    z[6,2,3]  R1677     3.6172637343406677e-01
    z[6,2,3]  R1678     -5.7961666025221348e-03
    z[6,2,3]  R1679     -1.2184821814298630e-01
    z[6,2,3]  R1680     -4.7170307487249374e-02
    z[6,2,3]  R1681     -3.9499200880527496e-02
    z[6,2,3]  R1682     2.5259786844253540e-01
    z[6,2,3]  R1683     6.0434317588806152e-01
    z[6,2,3]  R1684     5.1674425601959229e-01
    z[6,2,3]  R1685     9.4966374337673187e-02
    z[6,2,3]  R1686     9.8139166831970215e-02
    z[6,2,3]  R1687     3.6098104715347290e-01
    z[6,2,3]  R1688     -1.4106282033026218e-02
    z[6,2,3]  R1689     -6.8057513236999512e-01
    z[6,2,3]  R1690     1.2966774404048920e-01
    z[6,2,3]  R1691     1.4103873074054718e-01
    z[6,2,3]  R1692     2.2557689249515533e-01
    z[6,2,3]  R1693     3.4696063399314880e-01
    z[6,2,3]  R1694     1.0997498035430908e-01
    z[6,2,3]  R1695     -1.4441721141338348e-01
    z[6,2,3]  R1696     -3.9046889543533325e-01
    z[6,2,3]  R1697     2.1113230288028717e-01
    z[6,2,3]  R1698     -4.3737614154815674e-01
    z[6,2,3]  R1699     -0.275144100189209
    z[6,2,3]  R1700     3.6345925927162170e-01
    z[6,2,3]  R1701     -1.2501551210880280e-01
    z[6,2,3]  R1702     -4.3762576580047607e-01
    z[6,2,3]  R1703     -3.6428907513618469e-01
    z[6,2,3]  R1704     7.4119992554187775e-02
    z[6,2,3]  R1705     -2.9075714945793152e-01
    z[6,2,3]  R1706     -1.3685405254364014e-02
    z[6,2,3]  R1707     -1.0349833220243454e-01
    z[6,2,3]  R1708     5.0873857736587524e-01
    z[6,2,3]  R1709     -3.3803546428680420e-01
    z[6,2,3]  R1710     2.2532603144645691e-01
    z[6,2,3]  R1711     5.0569951534271240e-01
    z[6,2,3]  R1712     5.6493043899536133e-01
    z[6,2,3]  R1713     -5.5822163820266724e-01
    z[6,2,3]  R1714     1.5094357728958130e-01
    z[6,2,3]  R1715     -6.5323412418365479e-02
    z[6,2,3]  R1716     1.8714305013418198e-02
    z[6,2,3]  R1717     2.0260209217667580e-02
    z[6,2,3]  R1718     -4.6693214774131775e-01
    z[6,2,3]  R1719     1.3155084848403931e-01
    z[6,2,3]  R1720     0.0213027261197567
    z[6,2,3]  R1721     -1.2451861053705215e-01
    z[6,2,3]  R1722     1.3461527228355408e-01
    z[6,2,3]  R1723     -3.0403189361095428e-02
    z[6,2,3]  R1724     -3.1890103220939636e-01
    z[6,2,3]  R1725     3.0515128374099731e-01
    z[6,2,3]  R1726     -2.7336540818214417e-01
    z[6,2,3]  R1727     -2.2930863499641418e-01
    z[6,2,3]  R1728     -6.9702661037445068e-01
    z[6,2,3]  R1729     3.9165702462196350e-01
    z[6,2,3]  R1730     9.0290986001491547e-02
    z[6,2,3]  R1731     1.1057351529598236e-01
    z[6,2,3]  R1732     -6.4202737808227539e-01
    z[6,2,3]  R1733     -2.9270380735397339e-01
    z[6,2,3]  R1734     -4.7821402549743652e-01
    z[6,2,3]  R1735     5.7964488863945007e-02
    z[6,2,3]  R1736     -0.312037855386734
    z[6,2,3]  R1737     2.0122438669204712e-01
    z[6,2,3]  R1738     -1.0564703494310379e-01
    z[6,2,4]  R24       1
    z[6,2,4]  R60       -1
    z[6,2,4]  R1663     -1
    z[6,2,4]  R1664     1
    z[6,2,4]  R1669     2.1855711936950684e-01
    z[6,2,4]  R1670     3.6860066652297974e-01
    z[6,2,4]  R1671     1.1693480610847473e-01
    z[6,2,4]  R1672     2.8102025389671326e-01
    z[6,2,4]  R1673     5.4940587282180786e-01
    z[6,2,4]  R1674     9.3946486711502075e-02
    z[6,2,4]  R1675     4.8800927400588989e-01
    z[6,2,4]  R1676     -3.2916495203971863e-01
    z[6,2,4]  R1677     -4.6568018198013306e-01
    z[6,2,4]  R1678     -1.6710628569126129e-01
    z[6,2,4]  R1679     1.5868784487247467e-01
    z[6,2,4]  R1680     0.306011825799942
    z[6,2,4]  R1681     -2.2578364610671997e-01
    z[6,2,4]  R1682     -3.1393823027610779e-01
    z[6,2,4]  R1683     -3.7847158312797546e-01
    z[6,2,4]  R1684     -4.5780256390571594e-01
    z[6,2,4]  R1685     -8.1053566932678223e-01
    z[6,2,4]  R1686     -5.7097882032394409e-01
    z[6,2,4]  R1687     -1.1380314081907272e-01
    z[6,2,4]  R1688     -1.3239854574203491e-01
    z[6,2,4]  R1689     -1.1373429745435715e-01
    z[6,2,4]  R1690     8.2437492907047272e-02
    z[6,2,4]  R1691     -2.3470453917980194e-01
    z[6,2,4]  R1692     -1.1266208440065384e-01
    z[6,2,4]  R1693     -2.7110788226127625e-01
    z[6,2,4]  R1694     -3.5360220074653625e-01
    z[6,2,4]  R1695     -3.2983240485191345e-01
    z[6,2,4]  R1696     -9.7517386078834534e-02
    z[6,2,4]  R1697     -8.8615730404853821e-02
    z[6,2,4]  R1698     1.9421349465847015e-01
    z[6,2,4]  R1699     0.525259792804718
    z[6,2,4]  R1700     4.0166336297988892e-01
    z[6,2,4]  R1701     7.6657354831695557e-01
    z[6,2,4]  R1702     5.4183059930801392e-01
    z[6,2,4]  R1703     -1.5221124887466431e-01
    z[6,2,4]  R1704     -4.2753493785858154e-01
    z[6,2,4]  R1705     2.6012265682220459e-01
    z[6,2,4]  R1706     -1.6520659625530243e-01
    z[6,2,4]  R1707     -4.2838916182518005e-02
    z[6,2,4]  R1708     7.7875934541225433e-02
    z[6,2,4]  R1709     1.7025533318519592e-01
    z[6,2,4]  R1710     -2.5707101821899414e-01
    z[6,2,4]  R1711     1.9409327208995819e-01
    z[6,2,4]  R1712     -4.1895397007465363e-02
    z[6,2,4]  R1713     6.2116956710815430e-01
    z[6,2,4]  R1714     2.3017503321170807e-01
    z[6,2,4]  R1715     4.8447516560554504e-01
    z[6,2,4]  R1716     2.1125909686088562e-01
    z[6,2,4]  R1717     -1.2951073586009443e-04
    z[6,2,4]  R1718     1.1897636950016022e-01
    z[6,2,4]  R1719     -2.8945109248161316e-01
    z[6,2,4]  R1720     -1.0832422971725464e-01
    z[6,2,4]  R1721     2.0887608826160431e-01
    z[6,2,4]  R1722     8.3890803158283234e-02
    z[6,2,4]  R1723     3.4508371353149414e-01
    z[6,2,4]  R1724     1.8232037127017975e-01
    z[6,2,4]  R1725     -1.4317064546048641e-02
    z[6,2,4]  R1726     -1.6430977731943130e-02
    z[6,2,4]  R1727     -2.9563827440142632e-02
    z[6,2,4]  R1728     1.5581177175045013e-01
    z[6,2,4]  R1729     4.5532783865928650e-01
    z[6,2,4]  R1730     -5.0584875047206879e-02
    z[6,2,4]  R1731     1.6250425577163696e-01
    z[6,2,4]  R1732     -7.6470471918582916e-02
    z[6,2,4]  R1733     2.8865805268287659e-01
    z[6,2,4]  R1734     1.6766466200351715e-01
    z[6,2,4]  R1735     4.0400851517915726e-02
    z[6,2,4]  R1736     -1.3726890087127686e-01
    z[6,2,4]  R1737     -1.5371577441692352e-01
    z[6,2,4]  R1738     2.8815966844558716e-01
    z[6,2,5]  R25       1
    z[6,2,5]  R61       -1
    z[6,2,5]  R1665     -1
    z[6,2,5]  R1666     1
    z[6,2,5]  R1669     -1.3518853485584259e-01
    z[6,2,5]  R1670     -2.8702250123023987e-01
    z[6,2,5]  R1671     8.6273632943630219e-02
    z[6,2,5]  R1672     -4.5111864805221558e-01
    z[6,2,5]  R1673     4.0043982863426208e-01
    z[6,2,5]  R1674     -2.8760471940040588e-01
    z[6,2,5]  R1675     1.2319029122591019e-01
    z[6,2,5]  R1676     -1.3998635113239288e-01
    z[6,2,5]  R1677     7.2343222796916962e-02
    z[6,2,5]  R1678     -5.0539571791887283e-02
    z[6,2,5]  R1679     -7.9557329416275024e-01
    z[6,2,5]  R1680     -9.9694781005382538e-02
    z[6,2,5]  R1681     0.257186621427536
    z[6,2,5]  R1682     -8.3370454609394073e-02
    z[6,2,5]  R1683     -3.2267215847969055e-01
    z[6,2,5]  R1684     1.8452392518520355e-01
    z[6,2,5]  R1685     3.5069581866264343e-01
    z[6,2,5]  R1686     7.1079894900321960e-02
    z[6,2,5]  R1687     8.4961839020252228e-02
    z[6,2,5]  R1688     3.3967030048370361e-01
    z[6,2,5]  R1689     -5.6261110305786133e-01
    z[6,2,5]  R1690     -4.5188632607460022e-01
    z[6,2,5]  R1691     4.7491684556007385e-02
    z[6,2,5]  R1692     1.0402470082044601e-01
    z[6,2,5]  R1693     -6.2023870646953583e-02
    z[6,2,5]  R1694     -1.0046847164630890e-02
    z[6,2,5]  R1695     -2.1654093638062477e-02
    z[6,2,5]  R1696     -3.4643489122390747e-01
    z[6,2,5]  R1697     -3.7767979502677917e-01
    z[6,2,5]  R1698     -1.7442518472671509e-01
    z[6,2,5]  R1699     3.4574168920516968e-01
    z[6,2,5]  R1700     -5.5439078807830811e-01
    z[6,2,5]  R1701     -2.3657123744487762e-01
    z[6,2,5]  R1702     2.0953471958637238e-01
    z[6,2,5]  R1703     0.50971519947052
    z[6,2,5]  R1704     2.0126949250698090e-01
    z[6,2,5]  R1705     -8.6231883615255356e-03
    z[6,2,5]  R1706     6.8229717016220093e-01
    z[6,2,5]  R1707     4.6939301490783691e-01
    z[6,2,5]  R1708     4.2282477021217346e-01
    z[6,2,5]  R1709     6.1182837933301926e-02
    z[6,2,5]  R1710     -1.1985354125499725e-01
    z[6,2,5]  R1711     8.6183302104473114e-02
    z[6,2,5]  R1712     2.4325927719473839e-02
    z[6,2,5]  R1713     1.0157548636198044e-01
    z[6,2,5]  R1714     4.8351404070854187e-01
    z[6,2,5]  R1715     8.5496142506599426e-02
    z[6,2,5]  R1716     4.2921945452690125e-01
    z[6,2,5]  R1717     -1.6942197084426880e-01
    z[6,2,5]  R1718     2.2209188342094421e-01
    z[6,2,5]  R1719     -1.5760114416480064e-02
    z[6,2,5]  R1720     0.0844428762793541
    z[6,2,5]  R1721     2.1522009372711182e-01
    z[6,2,5]  R1722     -5.1006329059600830e-01
    z[6,2,5]  R1723     -2.1311371028423309e-01
    z[6,2,5]  R1724     1.6942206025123596e-01
    z[6,2,5]  R1725     -3.9063182473182678e-01
    z[6,2,5]  R1726     2.0191356539726257e-01
    z[6,2,5]  R1727     2.2902959585189819e-01
    z[6,2,5]  R1728     -5.8947563171386719e-02
    z[6,2,5]  R1729     -4.1749498248100281e-01
    z[6,2,5]  R1730     -3.7870484590530396e-01
    z[6,2,5]  R1731     -0.415229469537735
    z[6,2,5]  R1732     -0.0883241817355156
    z[6,2,5]  R1733     4.2321172356605530e-01
    z[6,2,5]  R1734     1.6260632872581482e-01
    z[6,2,5]  R1735     0.0569465234875679
    z[6,2,5]  R1736     -1.6966991126537323e-01
    z[6,2,5]  R1737     -3.0250322818756104e-01
    z[6,2,5]  R1738     3.7471261620521545e-01
    z[6,2,6]  R26       1
    z[6,2,6]  R62       -1
    z[6,2,6]  R1667     -1
    z[6,2,6]  R1668     1
    z[6,2,6]  R1669     1.5851153433322906e-01
    z[6,2,6]  R1670     3.4828382730484009e-01
    z[6,2,6]  R1671     -7.6698742806911469e-02
    z[6,2,6]  R1672     -2.2745883464813232e-01
    z[6,2,6]  R1673     4.2368043214082718e-02
    z[6,2,6]  R1674     -2.6303768157958984e-01
    z[6,2,6]  R1675     5.7033085823059082e-01
    z[6,2,6]  R1676     -2.8217649459838867e-01
    z[6,2,6]  R1677     -3.5408067703247070e-01
    z[6,2,6]  R1678     5.4378491640090942e-01
    z[6,2,6]  R1679     1.4204236865043640e-01
    z[6,2,6]  R1680     3.6710157990455627e-01
    z[6,2,6]  R1681     8.0660529434680939e-02
    z[6,2,6]  R1682     -0.4650898873806
    z[6,2,6]  R1683     3.4662488102912903e-01
    z[6,2,6]  R1684     -4.5101717114448547e-01
    z[6,2,6]  R1685     -0.061142697930336
    z[6,2,6]  R1686     3.1764614582061768e-01
    z[6,2,6]  R1687     -4.0411904454231262e-02
    z[6,2,6]  R1688     1.6303151845932007e-01
    z[6,2,6]  R1689     -2.4012371897697449e-01
    z[6,2,6]  R1690     -4.7786796092987061e-01
    z[6,2,6]  R1691     -3.2327172160148621e-01
    z[6,2,6]  R1692     0.266877144575119
    z[6,2,6]  R1693     -5.2893865853548050e-02
    z[6,2,6]  R1694     -9.8525643348693848e-02
    z[6,2,6]  R1695     3.1339146196842194e-02
    z[6,2,6]  R1696     1.8047126010060310e-02
    z[6,2,6]  R1697     -2.8784683346748352e-01
    z[6,2,6]  R1698     2.2689154744148254e-01
    z[6,2,6]  R1699     -2.5508137419819832e-02
    z[6,2,6]  R1700     5.3439790010452271e-01
    z[6,2,6]  R1701     -1.0268667340278625e-01
    z[6,2,6]  R1702     -3.8092023134231567e-01
    z[6,2,6]  R1703     0.0318525955080986
    z[6,2,6]  R1704     -1.4917287230491638e-01
    z[6,2,6]  R1705     7.3223048448562622e-01
    z[6,2,6]  R1706     -1.7481561005115509e-01
    z[6,2,6]  R1707     6.6362321376800537e-01
    z[6,2,6]  R1708     2.5549495220184326e-01
    z[6,2,6]  R1709     -1.6688092052936554e-01
    z[6,2,6]  R1710     -4.5651599764823914e-02
    z[6,2,6]  R1711     2.2808927297592163e-01
    z[6,2,6]  R1712     -1.2586400844156742e-02
    z[6,2,6]  R1713     3.8680014014244080e-01
    z[6,2,6]  R1714     -2.9306897521018982e-01
    z[6,2,6]  R1715     -1.7781928181648254e-01
    z[6,2,6]  R1716     0.344841331243515
    z[6,2,6]  R1717     -1.3751790858805180e-02
    z[6,2,6]  R1718     -0.413039892911911
    z[6,2,6]  R1719     3.5972705483436584e-01
    z[6,2,6]  R1720     -3.1692448258399963e-01
    z[6,2,6]  R1721     4.4062426686286926e-01
    z[6,2,6]  R1722     1.4996452629566193e-01
    z[6,2,6]  R1723     1.2894116342067719e-01
    z[6,2,6]  R1724     3.3351856470108032e-01
    z[6,2,6]  R1725     -1.2531548738479614e-02
    z[6,2,6]  R1726     -3.5553896427154541e-01
    z[6,2,6]  R1727     1.3812610507011414e-01
    z[6,2,6]  R1728     1.3690458238124847e-01
    z[6,2,6]  R1729     -3.0597314238548279e-01
    z[6,2,6]  R1730     -1.6123616695404053e-01
    z[6,2,6]  R1731     1.7207552492618561e-01
    z[6,2,6]  R1732     5.1867133378982544e-01
    z[6,2,6]  R1733     4.6384155750274658e-01
    z[6,2,6]  R1734     2.1356520056724548e-01
    z[6,2,6]  R1735     4.2806592583656311e-01
    z[6,2,6]  R1736     1.4733320474624634e-01
    z[6,2,6]  R1737     -3.1754586845636368e-02
    z[6,2,6]  R1738     2.4821478128433228e-01
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R1803     -1
    z[3,4,0]  R1804     1
    z[3,4,0]  R1817     -4.7842565923929214e-02
    z[3,4,0]  R1818     1.6336145997047424e-01
    z[3,4,0]  R1819     -9.9870808422565460e-02
    z[3,4,0]  R1820     -1.5496462583541870e-01
    z[3,4,0]  R1821     -1.9728128612041473e-01
    z[3,4,0]  R1822     -8.0846935510635376e-02
    z[3,4,0]  R1823     6.1693799495697021e-01
    z[3,4,0]  R1824     2.0558543503284454e-01
    z[3,4,0]  R1825     -4.9991199374198914e-01
    z[3,4,0]  R1826     2.1772319078445435e-01
    z[3,4,0]  R1827     2.0003290474414825e-01
    z[3,4,0]  R1828     -7.4387617409229279e-02
    z[3,4,0]  R1829     -4.1597837209701538e-01
    z[3,4,0]  R1830     -7.6839077472686768e-01
    z[3,4,0]  R1831     7.7399837970733643e-01
    z[3,4,0]  R1832     6.8121302127838135e-01
    z[3,4,0]  R1833     1.8463215231895447e-01
    z[3,4,0]  R1834     -3.9293516427278519e-02
    z[3,4,0]  R1835     5.3565528243780136e-02
    z[3,4,0]  R1836     2.4766375124454498e-01
    z[3,4,0]  R1837     -4.7654718160629272e-01
    z[3,4,0]  R1838     -6.7651289701461792e-01
    z[3,4,0]  R1839     7.5398230552673340e-01
    z[3,4,0]  R1840     -4.8060646653175354e-01
    z[3,4,0]  R1841     6.8152880668640137e-01
    z[3,4,0]  R1842     5.6666636466979980e-01
    z[3,4,0]  R1843     5.7580095529556274e-01
    z[3,4,0]  R1844     6.0033982992172241e-01
    z[3,4,0]  R1845     2.0098535716533661e-01
    z[3,4,0]  R1846     -2.2881361842155457e-01
    z[3,4,0]  R1847     -2.3070777952671051e-01
    z[3,4,0]  R1848     -5.2906799316406250e-01
    z[3,4,0]  R1849     -0.536858856678009
    z[3,4,0]  R1850     -1.4750261604785919e-01
    z[3,4,0]  R1851     -3.4159582853317261e-01
    z[3,4,0]  R1852     -4.2805242538452148e-01
    z[3,4,0]  R1853     2.6663309335708618e-01
    z[3,4,0]  R1854     -6.7907178401947021e-01
    z[3,4,0]  R1855     -6.7647963762283325e-01
    z[3,4,0]  R1856     2.4160841107368469e-01
    z[3,4,0]  R1857     1.3185410201549530e-01
    z[3,4,0]  R1858     -1.3201734982430935e-02
    z[3,4,0]  R1859     5.5172022432088852e-02
    z[3,4,0]  R1860     -2.2242331877350807e-02
    z[3,4,0]  R1861     7.6204225420951843e-02
    z[3,4,0]  R1862     1.2282416224479675e-01
    z[3,4,0]  R1863     5.5029653012752533e-02
    z[3,4,0]  R1864     1.8619391322135925e-01
    z[3,4,0]  R1865     -7.5316391885280609e-03
    z[3,4,0]  R1866     3.0556654557585716e-02
    z[3,4,0]  R1867     5.3235888481140137e-01
    z[3,4,0]  R1868     5.4403203725814819e-01
    z[3,4,0]  R1869     4.4899505376815796e-01
    z[3,4,0]  R1870     5.0258380174636841e-01
    z[3,4,0]  R1871     6.5266287326812744e-01
    z[3,4,0]  R1872     6.2692219018936157e-01
    z[3,4,0]  R1873     -1.3840657472610474e-01
    z[3,4,0]  R1874     -1.8528200685977936e-01
    z[3,4,0]  R1875     7.7054411172866821e-01
    z[3,4,0]  R1876     4.3017071485519409e-01
    z[3,4,0]  R1877     7.1977972984313965e-02
    z[3,4,0]  R1878     -4.0937475860118866e-02
    z[3,4,0]  R1879     -3.3348676562309265e-01
    z[3,4,0]  R1880     3.5101863741874695e-01
    z[3,4,0]  R1881     -4.0713661909103394e-01
    z[3,4,0]  R1882     7.9137533903121948e-01
    z[3,4,0]  R1883     -0.54306960105896
    z[3,4,0]  R1884     8.4613734483718872e-01
    z[3,4,0]  R1885     -1.7747931182384491e-01
    z[3,4,0]  R1886     2.9744449257850647e-01
    z[3,4,0]  R1887     -3.8600695133209229e-01
    z[3,4,0]  R1888     3.0390096828341484e-02
    z[3,4,0]  R1889     3.7899947166442871e-01
    z[3,4,0]  R1890     -1.3790874183177948e-01
    z[3,4,0]  R1891     1.5185585618019104e-01
    z[3,4,0]  R1892     1.9510146975517273e-01
    z[3,4,0]  R1893     7.7100229263305664e-01
    z[3,4,0]  R1894     1.1139265447854996e-01
    z[3,4,0]  R1895     7.5476515293121338e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R1805     -1
    z[3,4,1]  R1806     1
    z[3,4,1]  R1817     6.0475111007690430e-01
    z[3,4,1]  R1818     -3.6786407232284546e-01
    z[3,4,1]  R1819     3.8820084929466248e-01
    z[3,4,1]  R1820     5.5196863412857056e-01
    z[3,4,1]  R1821     0.595467209815979
    z[3,4,1]  R1822     4.3397700786590576e-01
    z[3,4,1]  R1823     4.7003057599067688e-01
    z[3,4,1]  R1824     1.0072947479784489e-02
    z[3,4,1]  R1825     -4.1328358650207520e-01
    z[3,4,1]  R1826     6.8299764394760132e-01
    z[3,4,1]  R1827     -2.1420218050479889e-01
    z[3,4,1]  R1828     -6.9788807630538940e-01
    z[3,4,1]  R1829     -7.2894757986068726e-01
    z[3,4,1]  R1830     -3.8785722851753235e-01
    z[3,4,1]  R1831     -4.9330314993858337e-01
    z[3,4,1]  R1832     -0.549047589302063
    z[3,4,1]  R1833     -7.3758912086486816e-01
    z[3,4,1]  R1834     -6.3828259706497192e-01
    z[3,4,1]  R1835     -6.0159695148468018e-01
    z[3,4,1]  R1836     -0.551503598690033
    z[3,4,1]  R1837     -5.4990863800048828e-01
    z[3,4,1]  R1838     -1.7415808141231537e-01
    z[3,4,1]  R1839     -5.0131946802139282e-01
    z[3,4,1]  R1840     3.1767040491104126e-01
    z[3,4,1]  R1841     -4.1771686077117920e-01
    z[3,4,1]  R1842     -4.2553973197937012e-01
    z[3,4,1]  R1843     -0.717606246471405
    z[3,4,1]  R1844     -5.2050924301147461e-01
    z[3,4,1]  R1845     1.4430856704711914e-01
    z[3,4,1]  R1846     3.7018606066703796e-01
    z[3,4,1]  R1847     3.2088243961334229e-01
    z[3,4,1]  R1848     -0.0853620320558548
    z[3,4,1]  R1849     0.352740615606308
    z[3,4,1]  R1850     9.3586467206478119e-02
    z[3,4,1]  R1851     3.8938581943511963e-01
    z[3,4,1]  R1852     1.1426846683025360e-01
    z[3,4,1]  R1853     4.3071934580802917e-01
    z[3,4,1]  R1854     4.6511983871459961e-01
    z[3,4,1]  R1855     5.1966643333435059e-01
    z[3,4,1]  R1856     4.5888322591781616e-01
    z[3,4,1]  R1857     -8.3910757303237915e-01
    z[3,4,1]  R1858     -8.6533606052398682e-01
    z[3,4,1]  R1859     -0.856290876865387
    z[3,4,1]  R1860     -0.831427812576294
    z[3,4,1]  R1861     -8.8973259925842285e-01
    z[3,4,1]  R1862     -8.9831674098968506e-01
    z[3,4,1]  R1863     -8.8220846652984619e-01
    z[3,4,1]  R1864     -8.9002692699432373e-01
    z[3,4,1]  R1865     -7.4586510658264160e-01
    z[3,4,1]  R1866     2.2671137750148773e-01
    z[3,4,1]  R1867     5.6912928819656372e-01
    z[3,4,1]  R1868     4.9940598011016846e-01
    z[3,4,1]  R1869     5.0135904550552368e-01
    z[3,4,1]  R1870     4.9811157584190369e-01
    z[3,4,1]  R1871     5.1809805631637573e-01
    z[3,4,1]  R1872     5.7565355300903320e-01
    z[3,4,1]  R1873     4.0577733516693115e-01
    z[3,4,1]  R1874     -8.1414830684661865e-01
    z[3,4,1]  R1875     -2.6228375732898712e-02
    z[3,4,1]  R1876     5.8665776252746582e-01
    z[3,4,1]  R1877     -8.8336187601089478e-01
    z[3,4,1]  R1878     -8.6680001020431519e-01
    z[3,4,1]  R1879     -8.3143043518066406e-01
    z[3,4,1]  R1880     -8.7545108795166016e-01
    z[3,4,1]  R1881     -5.9915989637374878e-01
    z[3,4,1]  R1882     -3.1522031873464584e-02
    z[3,4,1]  R1883     -7.1259617805480957e-01
    z[3,4,1]  R1884     -2.4191428720951080e-01
    z[3,4,1]  R1885     -9.0931630134582520e-01
    z[3,4,1]  R1886     6.7801761627197266e-01
    z[3,4,1]  R1887     -5.3744238615036011e-01
    z[3,4,1]  R1888     5.1924854516983032e-01
    z[3,4,1]  R1889     7.3822093009948730e-01
    z[3,4,1]  R1890     -9.6936339139938354e-01
    z[3,4,1]  R1891     -8.4631758928298950e-01
    z[3,4,1]  R1892     -8.1340706348419189e-01
    z[3,4,1]  R1893     -1.3318565487861633e-01
    z[3,4,1]  R1894     -9.3571096658706665e-01
    z[3,4,1]  R1895     -3.4393274784088135e-01
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R1807     -1
    z[3,4,2]  R1808     1
    z[3,4,2]  R1817     -1.9149206578731537e-01
    z[3,4,2]  R1818     -6.1956530809402466e-01
    z[3,4,2]  R1819     -1.0150258988142014e-01
    z[3,4,2]  R1820     5.1067221164703369e-01
    z[3,4,2]  R1821     -3.0399185419082642e-01
    z[3,4,2]  R1822     -6.3550509512424469e-02
    z[3,4,2]  R1823     -4.3908601999282837e-01
    z[3,4,2]  R1824     -5.5459529161453247e-01
    z[3,4,2]  R1825     -2.8686091303825378e-01
    z[3,4,2]  R1826     0.0934213399887085
    z[3,4,2]  R1827     -2.7673307061195374e-01
    z[3,4,2]  R1828     -1.6257500648498535e-01
    z[3,4,2]  R1829     2.0472067594528198e-01
    z[3,4,2]  R1830     1.8409414589405060e-01
    z[3,4,2]  R1831     1.0388576984405518e-01
    z[3,4,2]  R1832     1.4887210726737976e-01
    z[3,4,2]  R1833     4.9851119518280029e-02
    z[3,4,2]  R1834     1.0713803023099899e-01
    z[3,4,2]  R1835     2.0366646349430084e-01
    z[3,4,2]  R1836     -1.4279303140938282e-02
    z[3,4,2]  R1837     1.8054470419883728e-01
    z[3,4,2]  R1838     -3.8066647946834564e-02
    z[3,4,2]  R1839     1.5422993898391724e-01
    z[3,4,2]  R1840     1.4361312985420227e-01
    z[3,4,2]  R1841     4.2949758470058441e-02
    z[3,4,2]  R1842     1.5921603143215179e-01
    z[3,4,2]  R1843     1.7752985656261444e-01
    z[3,4,2]  R1844     1.6489961743354797e-01
    z[3,4,2]  R1845     3.1613722443580627e-01
    z[3,4,2]  R1846     1.9356827437877655e-01
    z[3,4,2]  R1847     2.4685165286064148e-01
    z[3,4,2]  R1848     6.1206500977277756e-02
    z[3,4,2]  R1849     -2.0180317759513855e-01
    z[3,4,2]  R1850     4.4411984086036682e-01
    z[3,4,2]  R1851     -4.3181997537612915e-01
    z[3,4,2]  R1852     -2.7103242278099060e-01
    z[3,4,2]  R1853     -2.6697742938995361e-01
    z[3,4,2]  R1854     -3.4243506193161011e-01
    z[3,4,2]  R1855     -1.4939494431018829e-01
    z[3,4,2]  R1856     6.4450573921203613e-01
    z[3,4,2]  R1857     1.0331121087074280e-01
    z[3,4,2]  R1858     2.6637923717498779e-01
    z[3,4,2]  R1859     -5.4543375968933105e-02
    z[3,4,2]  R1860     5.0195097923278809e-02
    z[3,4,2]  R1861     6.9693282246589661e-02
    z[3,4,2]  R1862     -3.0473910737782717e-03
    z[3,4,2]  R1863     5.7179573923349380e-03
    z[3,4,2]  R1864     1.1403743177652359e-01
    z[3,4,2]  R1865     1.3642043806612492e-02
    z[3,4,2]  R1866     3.7542662024497986e-01
    z[3,4,2]  R1867     2.8058382868766785e-01
    z[3,4,2]  R1868     1.0063945502042770e-01
    z[3,4,2]  R1869     4.1253137588500977e-01
    z[3,4,2]  R1870     2.2937135398387909e-01
    z[3,4,2]  R1871     -1.9970403984189034e-02
    z[3,4,2]  R1872     -0.0692482516169548
    z[3,4,2]  R1873     5.8593684434890747e-01
    z[3,4,2]  R1874     4.3814271688461304e-01
    z[3,4,2]  R1875     0.30632483959198
    z[3,4,2]  R1876     1.7609870433807373e-01
    z[3,4,2]  R1877     -1.4286562800407410e-01
    z[3,4,2]  R1878     -4.6527005732059479e-02
    z[3,4,2]  R1879     -1.1773762851953506e-01
    z[3,4,2]  R1880     3.0067640542984009e-01
    z[3,4,2]  R1881     -2.5073844194412231e-01
    z[3,4,2]  R1882     0.209524467587471
    z[3,4,2]  R1883     1.4049339806661010e-03
    z[3,4,2]  R1884     1.0268007963895798e-01
    z[3,4,2]  R1885     -2.8969830274581909e-01
    z[3,4,2]  R1886     3.6941519379615784e-01
    z[3,4,2]  R1887     -4.3036320805549622e-01
    z[3,4,2]  R1888     5.8853012323379517e-01
    z[3,4,2]  R1889     4.5391544699668884e-02
    z[3,4,2]  R1890     -2.4259122088551521e-02
    z[3,4,2]  R1891     8.1423148512840271e-02
    z[3,4,2]  R1892     -7.7357396483421326e-02
    z[3,4,2]  R1893     2.0851007103919983e-01
    z[3,4,2]  R1894     -1.8838453292846680e-01
    z[3,4,2]  R1895     2.4028047919273376e-01
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R1809     -1
    z[3,4,3]  R1810     1
    z[3,4,3]  R1817     5.7045191526412964e-01
    z[3,4,3]  R1818     4.8253723978996277e-01
    z[3,4,3]  R1819     6.8029654026031494e-01
    z[3,4,3]  R1820     -1.0830656439065933e-01
    z[3,4,3]  R1821     5.0035911798477173e-01
    z[3,4,3]  R1822     3.2207110524177551e-01
    z[3,4,3]  R1823     2.8305670619010925e-01
    z[3,4,3]  R1824     2.8177937865257263e-01
    z[3,4,3]  R1825     3.9799353480339050e-01
    z[3,4,3]  R1826     -1.1393939703702927e-01
    z[3,4,3]  R1827     3.9269354939460754e-01
    z[3,4,3]  R1828     4.8071038722991943e-01
    z[3,4,3]  R1829     1.0551664978265762e-01
    z[3,4,3]  R1830     -3.4226432908326387e-03
    z[3,4,3]  R1831     -7.2667285799980164e-02
    z[3,4,3]  R1832     -4.0364658832550049e-01
    z[3,4,3]  R1833     -5.4425221681594849e-01
    z[3,4,3]  R1834     -7.3211288452148438e-01
    z[3,4,3]  R1835     -6.5576130151748657e-01
    z[3,4,3]  R1836     -7.0714837312698364e-01
    z[3,4,3]  R1837     3.7765324115753174e-01
    z[3,4,3]  R1838     1.9084180891513824e-01
    z[3,4,3]  R1839     -3.1247639656066895e-01
    z[3,4,3]  R1840     -4.6759301424026489e-01
    z[3,4,3]  R1841     -2.9388004541397095e-01
    z[3,4,3]  R1842     -2.9821637272834778e-01
    z[3,4,3]  R1843     -2.7308362722396851e-01
    z[3,4,3]  R1844     -3.5534223914146423e-01
    z[3,4,3]  R1845     -7.9411095380783081e-01
    z[3,4,3]  R1846     5.8835631608963013e-01
    z[3,4,3]  R1847     5.7909131050109863e-01
    z[3,4,3]  R1848     7.1007597446441650e-01
    z[3,4,3]  R1849     5.1912295818328857e-01
    z[3,4,3]  R1850     6.7351454496383667e-01
    z[3,4,3]  R1851     2.3599152266979218e-01
    z[3,4,3]  R1852     1.0072951018810272e-01
    z[3,4,3]  R1853     2.6326471567153931e-01
    z[3,4,3]  R1854     -2.1841265261173248e-01
    z[3,4,3]  R1855     -4.2937964200973511e-01
    z[3,4,3]  R1856     -4.6761611104011536e-01
    z[3,4,3]  R1857     -4.9306672811508179e-01
    z[3,4,3]  R1858     -3.1495910882949829e-01
    z[3,4,3]  R1859     -3.9545559883117676e-01
    z[3,4,3]  R1860     -4.3779936432838440e-01
    z[3,4,3]  R1861     -1.8927714228630066e-01
    z[3,4,3]  R1862     -1.6373868286609650e-01
    z[3,4,3]  R1863     -2.1787050366401672e-01
    z[3,4,3]  R1864     -1.5182100236415863e-01
    z[3,4,3]  R1865     -6.5627634525299072e-01
    z[3,4,3]  R1866     -2.7796211838722229e-01
    z[3,4,3]  R1867     -4.3183439970016479e-01
    z[3,4,3]  R1868     -3.4537440538406372e-01
    z[3,4,3]  R1869     -0.092435322701931
    z[3,4,3]  R1870     -2.7672863006591797e-01
    z[3,4,3]  R1871     -4.0482899546623230e-01
    z[3,4,3]  R1872     -3.9469927549362183e-01
    z[3,4,3]  R1873     -5.2682596445083618e-01
    z[3,4,3]  R1874     -2.8664425015449524e-01
    z[3,4,3]  R1875     -4.9529033899307251e-01
    z[3,4,3]  R1876     -4.2812418937683105e-01
    z[3,4,3]  R1877     -3.9481440186500549e-01
    z[3,4,3]  R1878     -1.8525658547878265e-01
    z[3,4,3]  R1879     -2.7522468566894531e-01
    z[3,4,3]  R1880     0.0848386287689209
    z[3,4,3]  R1881     -4.0217173099517822e-01
    z[3,4,3]  R1882     -4.1430890560150146e-01
    z[3,4,3]  R1883     -3.9949494600296021e-01
    z[3,4,3]  R1884     -2.5498467683792114e-01
    z[3,4,3]  R1885     -3.7392899394035339e-02
    z[3,4,3]  R1886     -3.3119708299636841e-01
    z[3,4,3]  R1887     -2.1668106317520142e-01
    z[3,4,3]  R1888     -5.1878023147583008e-01
    z[3,4,3]  R1889     -5.1609623432159424e-01
    z[3,4,3]  R1890     -9.2928275465965271e-02
    z[3,4,3]  R1891     -3.2332196831703186e-01
    z[3,4,3]  R1892     -4.1578653454780579e-01
    z[3,4,3]  R1893     -5.5670082569122314e-01
    z[3,4,3]  R1894     -8.2895331084728241e-02
    z[3,4,3]  R1895     -1.3179579377174377e-01
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R1811     -1
    z[3,4,4]  R1812     1
    z[3,4,4]  R1817     -5.0928759574890137e-01
    z[3,4,4]  R1818     3.3467937260866165e-02
    z[3,4,4]  R1819     -3.6692202091217041e-01
    z[3,4,4]  R1820     -6.2733925879001617e-02
    z[3,4,4]  R1821     1.3942405581474304e-01
    z[3,4,4]  R1822     -2.3931907117366791e-01
    z[3,4,4]  R1823     -0.0843191146850586
    z[3,4,4]  R1824     -2.0380539819598198e-02
    z[3,4,4]  R1825     -2.5483930110931396e-01
    z[3,4,4]  R1826     1.3971160352230072e-01
    z[3,4,4]  R1827     6.4389693737030029e-01
    z[3,4,4]  R1828     -3.3352595567703247e-01
    z[3,4,4]  R1829     9.9107161164283752e-02
    z[3,4,4]  R1830     3.8357204198837280e-01
    z[3,4,4]  R1831     -1.7420975863933563e-01
    z[3,4,4]  R1832     1.9177092611789703e-01
    z[3,4,4]  R1833     1.9314432144165039e-01
    z[3,4,4]  R1834     -6.8377837538719177e-02
    z[3,4,4]  R1835     -2.2632372379302979e-01
    z[3,4,4]  R1836     -2.8030967712402344e-01
    z[3,4,4]  R1837     -2.2098235785961151e-01
    z[3,4,4]  R1838     5.4563194513320923e-01
    z[3,4,4]  R1839     -0.060396958142519
    z[3,4,4]  R1840     2.3633283376693726e-01
    z[3,4,4]  R1841     -0.493927001953125
    z[3,4,4]  R1842     -5.5003982782363892e-01
    z[3,4,4]  R1843     1.9689303636550903e-01
    z[3,4,4]  R1844     4.7673948109149933e-02
    z[3,4,4]  R1845     -1.8436609208583832e-01
    z[3,4,4]  R1846     0.0576406754553318
    z[3,4,4]  R1847     -2.8113916516304016e-01
    z[3,4,4]  R1848     1.2987929582595825e-01
    z[3,4,4]  R1849     4.6343860030174255e-01
    z[3,4,4]  R1850     -0.510013222694397
    z[3,4,4]  R1851     -4.1461598873138428e-01
    z[3,4,4]  R1852     -7.2644233703613281e-01
    z[3,4,4]  R1853     0.361479789018631
    z[3,4,4]  R1854     8.6656715720891953e-03
    z[3,4,4]  R1855     -4.3161340057849884e-02
    z[3,4,4]  R1856     3.0528002977371216e-01
    z[3,4,4]  R1857     2.9022667557001114e-02
    z[3,4,4]  R1858     -1.9766373932361603e-01
    z[3,4,4]  R1859     2.7908211946487427e-01
    z[3,4,4]  R1860     2.6561075448989868e-01
    z[3,4,4]  R1861     1.1386289447546005e-01
    z[3,4,4]  R1862     -1.5815052390098572e-01
    z[3,4,4]  R1863     2.5039520859718323e-01
    z[3,4,4]  R1864     2.3188173770904541e-01
    z[3,4,4]  R1865     -8.0177605152130127e-02
    z[3,4,4]  R1866     3.8502511382102966e-01
    z[3,4,4]  R1867     2.4384586513042450e-01
    z[3,4,4]  R1868     1.8069259822368622e-01
    z[3,4,4]  R1869     3.5716065764427185e-01
    z[3,4,4]  R1870     0.376345157623291
    z[3,4,4]  R1871     -2.0123182237148285e-01
    z[3,4,4]  R1872     -1.8087539076805115e-01
    z[3,4,4]  R1873     -2.9361805319786072e-01
    z[3,4,4]  R1874     1.6702005267143250e-01
    z[3,4,4]  R1875     1.5417100489139557e-01
    z[3,4,4]  R1876     3.9853486418724060e-01
    z[3,4,4]  R1877     -1.0265780985355377e-01
    z[3,4,4]  R1878     -0.439564049243927
    z[3,4,4]  R1879     -5.2966731600463390e-03
    z[3,4,4]  R1880     -8.4944792091846466e-02
    z[3,4,4]  R1881     -3.2924994826316833e-01
    z[3,4,4]  R1882     -2.7652847766876221e-01
    z[3,4,4]  R1883     1.5353962779045105e-01
    z[3,4,4]  R1884     0.144717276096344
    z[3,4,4]  R1885     -3.5749140661209822e-03
    z[3,4,4]  R1886     4.1059872508049011e-01
    z[3,4,4]  R1887     -2.3432014882564545e-01
    z[3,4,4]  R1888     -2.3054113984107971e-01
    z[3,4,4]  R1889     9.5175974071025848e-02
    z[3,4,4]  R1890     1.5428699553012848e-01
    z[3,4,4]  R1891     -1.8565729260444641e-01
    z[3,4,4]  R1892     -2.3748582601547241e-01
    z[3,4,4]  R1893     -8.1103906035423279e-02
    z[3,4,4]  R1894     1.7757375538349152e-01
    z[3,4,4]  R1895     4.6526998281478882e-01
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R1813     -1
    z[3,4,5]  R1814     1
    z[3,4,5]  R1817     8.1511437892913818e-02
    z[3,4,5]  R1818     4.6914857625961304e-01
    z[3,4,5]  R1819     -7.9469613730907440e-02
    z[3,4,5]  R1820     -5.7158374786376953e-01
    z[3,4,5]  R1821     -9.7945593297481537e-02
    z[3,4,5]  R1822     -4.0284192562103271e-01
    z[3,4,5]  R1823     2.1341418847441673e-02
    z[3,4,5]  R1824     3.0682021379470825e-01
    z[3,4,5]  R1825     3.8957217335700989e-01
    z[3,4,5]  R1826     1.9616955518722534e-01
    z[3,4,5]  R1827     -4.7348102927207947e-01
    z[3,4,5]  R1828     -3.2203987240791321e-01
    z[3,4,5]  R1829     -2.7028828859329224e-01
    z[3,4,5]  R1830     6.8928644061088562e-02
    z[3,4,5]  R1831     -2.3548196256160736e-01
    z[3,4,5]  R1832     1.0767978429794312e-01
    z[3,4,5]  R1833     -3.4833904355764389e-02
    z[3,4,5]  R1834     -1.7041069269180298e-01
    z[3,4,5]  R1835     2.4099244177341461e-01
    z[3,4,5]  R1836     2.1224381402134895e-02
    z[3,4,5]  R1837     -3.2692757248878479e-01
    z[3,4,5]  R1838     2.1178103983402252e-01
    z[3,4,5]  R1839     1.9609722495079041e-01
    z[3,4,5]  R1840     5.3016132116317749e-01
    z[3,4,5]  R1841     8.2845687866210938e-02
    z[3,4,5]  R1842     2.4352923035621643e-01
    z[3,4,5]  R1843     7.0529342629015446e-03
    z[3,4,5]  R1844     -2.6302334666252136e-01
    z[3,4,5]  R1845     2.1879564225673676e-01
    z[3,4,5]  R1846     -2.5419354438781738e-01
    z[3,4,5]  R1847     5.5253233760595322e-02
    z[3,4,5]  R1848     -3.6885783076286316e-02
    z[3,4,5]  R1849     -2.2479355335235596e-01
    z[3,4,5]  R1850     -6.6237091086804867e-03
    z[3,4,5]  R1851     -4.9201363325119019e-01
    z[3,4,5]  R1852     -3.0697554349899292e-01
    z[3,4,5]  R1853     -5.5386364459991455e-01
    z[3,4,5]  R1854     0.341463178396225
    z[3,4,5]  R1855     2.4733063578605652e-01
    z[3,4,5]  R1856     -5.3956888616085052e-02
    z[3,4,5]  R1857     -1.4479069411754608e-01
    z[3,4,5]  R1858     2.7465509250760078e-02
    z[3,4,5]  R1859     2.3230038583278656e-02
    z[3,4,5]  R1860     -1.4664037525653839e-01
    z[3,4,5]  R1861     -2.1142846345901489e-01
    z[3,4,5]  R1862     3.5193203948438168e-03
    z[3,4,5]  R1863     -2.8943467140197754e-01
    z[3,4,5]  R1864     1.2393782287836075e-01
    z[3,4,5]  R1865     0.0698886290192604
    z[3,4,5]  R1866     -7.6179319620132446e-01
    z[3,4,5]  R1867     1.6764022409915924e-01
    z[3,4,5]  R1868     5.3217488527297974e-01
    z[3,4,5]  R1869     4.8674359917640686e-01
    z[3,4,5]  R1870     4.7387725114822388e-01
    z[3,4,5]  R1871     2.3500698804855347e-01
    z[3,4,5]  R1872     -4.2441502213478088e-02
    z[3,4,5]  R1873     -3.1275925040245056e-01
    z[3,4,5]  R1874     -1.8474724143743515e-02
    z[3,4,5]  R1875     1.6109757125377655e-01
    z[3,4,5]  R1876     -9.8054654896259308e-02
    z[3,4,5]  R1877     -1.2702740728855133e-01
    z[3,4,5]  R1878     -8.6095677688717842e-03
    z[3,4,5]  R1879     -2.8188601136207581e-01
    z[3,4,5]  R1880     -4.4874340295791626e-02
    z[3,4,5]  R1881     3.7709128856658936e-01
    z[3,4,5]  R1882     -2.0452212542295456e-02
    z[3,4,5]  R1883     1.1788973212242126e-01
    z[3,4,5]  R1884     -6.4595431089401245e-02
    z[3,4,5]  R1885     2.1863219141960144e-01
    z[3,4,5]  R1886     5.1559224724769592e-02
    z[3,4,5]  R1887     2.0553177595138550e-01
    z[3,4,5]  R1888     -1.7279775440692902e-01
    z[3,4,5]  R1889     -1.7816193401813507e-01
    z[3,4,5]  R1890     -8.2208685576915741e-02
    z[3,4,5]  R1891     1.6701954603195190e-01
    z[3,4,5]  R1892     -6.9015175104141235e-02
    z[3,4,5]  R1893     2.7071535587310791e-02
    z[3,4,5]  R1894     1.9414480030536652e-01
    z[3,4,5]  R1895     3.5885747522115707e-02
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R1815     -1
    z[3,4,6]  R1816     1
    z[3,4,6]  R1817     -6.2325235456228256e-02
    z[3,4,6]  R1818     -8.0800447613000870e-03
    z[3,4,6]  R1819     4.7462871670722961e-01
    z[3,4,6]  R1820     2.6106837391853333e-01
    z[3,4,6]  R1821     -4.8445445299148560e-01
    z[3,4,6]  R1822     -0.69123375415802
    z[3,4,6]  R1823     -3.4347614645957947e-01
    z[3,4,6]  R1824     -6.9000262022018433e-01
    z[3,4,6]  R1825     -3.4912335872650146e-01
    z[3,4,6]  R1826     6.3749450445175171e-01
    z[3,4,6]  R1827     2.1101489663124084e-01
    z[3,4,6]  R1828     -0.186966210603714
    z[3,4,6]  R1829     3.9959362149238586e-01
    z[3,4,6]  R1830     2.7085286378860474e-01
    z[3,4,6]  R1831     2.3601894080638885e-01
    z[3,4,6]  R1832     3.2111827284097672e-02
    z[3,4,6]  R1833     -2.9096311330795288e-01
    z[3,4,6]  R1834     -9.9338285624980927e-02
    z[3,4,6]  R1835     2.3325771093368530e-01
    z[3,4,6]  R1836     2.3498864471912384e-01
    z[3,4,6]  R1837     3.7359076738357544e-01
    z[3,4,6]  R1838     3.6271774768829346e-01
    z[3,4,6]  R1839     -1.2907078862190247e-01
    z[3,4,6]  R1840     -3.0316799879074097e-01
    z[3,4,6]  R1841     -1.4830298721790314e-01
    z[3,4,6]  R1842     -1.4721424877643585e-01
    z[3,4,6]  R1843     0.0926625207066536
    z[3,4,6]  R1844     -0.379141241312027
    z[3,4,6]  R1845     -3.5547509789466858e-01
    z[3,4,6]  R1846     -5.9919780492782593e-01
    z[3,4,6]  R1847     6.0451114177703857e-01
    z[3,4,6]  R1848     -4.3199202418327332e-01
    z[3,4,6]  R1849     -1.0879322141408920e-01
    z[3,4,6]  R1850     -0.241790771484375
    z[3,4,6]  R1851     2.7485761046409607e-01
    z[3,4,6]  R1852     -3.1329923868179321e-01
    z[3,4,6]  R1853     4.0665698051452637e-01
    z[3,4,6]  R1854     2.0220498740673065e-01
    z[3,4,6]  R1855     -5.0999283790588379e-02
    z[3,4,6]  R1856     2.9861494898796082e-02
    z[3,4,6]  R1857     5.4020345211029053e-02
    z[3,4,6]  R1858     -2.0257534086704254e-01
    z[3,4,6]  R1859     -1.6104483604431152e-01
    z[3,4,6]  R1860     -1.4829909801483154e-01
    z[3,4,6]  R1861     3.2283014059066772e-01
    z[3,4,6]  R1862     -3.5510218143463135e-01
    z[3,4,6]  R1863     1.5719279646873474e-01
    z[3,4,6]  R1864     2.6076811552047729e-01
    z[3,4,6]  R1865     3.7825204432010651e-02
    z[3,4,6]  R1866     2.9783040285110474e-02
    z[3,4,6]  R1867     -1.9978380203247070e-01
    z[3,4,6]  R1868     9.6700891852378845e-02
    z[3,4,6]  R1869     -6.1911858618259430e-02
    z[3,4,6]  R1870     6.2522336840629578e-02
    z[3,4,6]  R1871     2.1353588998317719e-01
    z[3,4,6]  R1872     -2.8371039032936096e-01
    z[3,4,6]  R1873     1.0625831037759781e-01
    z[3,4,6]  R1874     0.0215000007301569
    z[3,4,6]  R1875     1.2924927473068237e-01
    z[3,4,6]  R1876     -2.9671558737754822e-01
    z[3,4,6]  R1877     1.0736639797687531e-01
    z[3,4,6]  R1878     1.3117294013500214e-01
    z[3,4,6]  R1879     1.6855685412883759e-01
    z[3,4,6]  R1880     0.0594826303422451
    z[3,4,6]  R1881     5.6614372879266739e-03
    z[3,4,6]  R1882     2.8335985541343689e-01
    z[3,4,6]  R1883     1.4543295837938786e-02
    z[3,4,6]  R1884     3.5334545373916626e-01
    z[3,4,6]  R1885     9.2243090271949768e-02
    z[3,4,6]  R1886     1.8549966812133789e-01
    z[3,4,6]  R1887     4.8253691196441650e-01
    z[3,4,6]  R1888     1.7592176795005798e-01
    z[3,4,6]  R1889     4.6619750559329987e-02
    z[3,4,6]  R1890     -3.9099924266338348e-02
    z[3,4,6]  R1891     2.9522067308425903e-01
    z[3,4,6]  R1892     -2.4551825225353241e-01
    z[3,4,6]  R1893     -1.6466338932514191e-01
    z[3,4,6]  R1894     2.1250389516353607e-02
    z[3,4,6]  R1895     -1.3845956325531006e-01
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R1896     -1
    z[4,3,0]  R1897     1
    z[4,3,0]  R1910     -2.2881361842155457e-01
    z[4,3,0]  R1911     -2.3070777952671051e-01
    z[4,3,0]  R1912     -5.2906799316406250e-01
    z[4,3,0]  R1913     -0.536858856678009
    z[4,3,0]  R1914     -1.4750261604785919e-01
    z[4,3,0]  R1915     -3.4159582853317261e-01
    z[4,3,0]  R1916     -4.2805242538452148e-01
    z[4,3,0]  R1917     2.6663309335708618e-01
    z[4,3,0]  R1918     -6.7907178401947021e-01
    z[4,3,0]  R1919     -6.7647963762283325e-01
    z[4,3,0]  R1920     2.4160841107368469e-01
    z[4,3,0]  R1921     1.3185410201549530e-01
    z[4,3,0]  R1922     -1.3201734982430935e-02
    z[4,3,0]  R1923     5.5172022432088852e-02
    z[4,3,0]  R1924     -2.2242331877350807e-02
    z[4,3,0]  R1925     7.6204225420951843e-02
    z[4,3,0]  R1926     1.2282416224479675e-01
    z[4,3,0]  R1927     5.5029653012752533e-02
    z[4,3,0]  R1928     1.8619391322135925e-01
    z[4,3,0]  R1929     -7.5316391885280609e-03
    z[4,3,0]  R1930     3.0556654557585716e-02
    z[4,3,0]  R1931     5.3235888481140137e-01
    z[4,3,0]  R1932     5.4403203725814819e-01
    z[4,3,0]  R1933     4.4899505376815796e-01
    z[4,3,0]  R1934     5.0258380174636841e-01
    z[4,3,0]  R1935     6.5266287326812744e-01
    z[4,3,0]  R1936     6.2692219018936157e-01
    z[4,3,0]  R1937     -1.3840657472610474e-01
    z[4,3,0]  R1938     -1.8528200685977936e-01
    z[4,3,0]  R1939     7.7054411172866821e-01
    z[4,3,0]  R1940     4.3017071485519409e-01
    z[4,3,0]  R1941     7.1977972984313965e-02
    z[4,3,0]  R1942     -4.0937475860118866e-02
    z[4,3,0]  R1943     -3.3348676562309265e-01
    z[4,3,0]  R1944     3.5101863741874695e-01
    z[4,3,0]  R1945     -4.0713661909103394e-01
    z[4,3,0]  R1946     7.9137533903121948e-01
    z[4,3,0]  R1947     -0.54306960105896
    z[4,3,0]  R1948     8.4613734483718872e-01
    z[4,3,0]  R1949     -1.7747931182384491e-01
    z[4,3,0]  R1950     2.9744449257850647e-01
    z[4,3,0]  R1951     -3.8600695133209229e-01
    z[4,3,0]  R1952     3.0390096828341484e-02
    z[4,3,0]  R1953     3.7899947166442871e-01
    z[4,3,0]  R1954     -1.3790874183177948e-01
    z[4,3,0]  R1955     1.5185585618019104e-01
    z[4,3,0]  R1956     1.9510146975517273e-01
    z[4,3,0]  R1957     7.7100229263305664e-01
    z[4,3,0]  R1958     1.1139265447854996e-01
    z[4,3,0]  R1959     7.5476515293121338e-01
    z[4,3,0]  R1960     -4.7842565923929214e-02
    z[4,3,0]  R1961     1.6336145997047424e-01
    z[4,3,0]  R1962     -9.9870808422565460e-02
    z[4,3,0]  R1963     -1.5496462583541870e-01
    z[4,3,0]  R1964     -1.9728128612041473e-01
    z[4,3,0]  R1965     -8.0846935510635376e-02
    z[4,3,0]  R1966     6.1693799495697021e-01
    z[4,3,0]  R1967     2.0558543503284454e-01
    z[4,3,0]  R1968     -4.9991199374198914e-01
    z[4,3,0]  R1969     2.1772319078445435e-01
    z[4,3,0]  R1970     2.0003290474414825e-01
    z[4,3,0]  R1971     -7.4387617409229279e-02
    z[4,3,0]  R1972     -4.1597837209701538e-01
    z[4,3,0]  R1973     -7.6839077472686768e-01
    z[4,3,0]  R1974     7.7399837970733643e-01
    z[4,3,0]  R1975     6.8121302127838135e-01
    z[4,3,0]  R1976     1.8463215231895447e-01
    z[4,3,0]  R1977     -3.9293516427278519e-02
    z[4,3,0]  R1978     5.3565528243780136e-02
    z[4,3,0]  R1979     2.4766375124454498e-01
    z[4,3,0]  R1980     -4.7654718160629272e-01
    z[4,3,0]  R1981     -6.7651289701461792e-01
    z[4,3,0]  R1982     7.5398230552673340e-01
    z[4,3,0]  R1983     -4.8060646653175354e-01
    z[4,3,0]  R1984     6.8152880668640137e-01
    z[4,3,0]  R1985     5.6666636466979980e-01
    z[4,3,0]  R1986     5.7580095529556274e-01
    z[4,3,0]  R1987     6.0033982992172241e-01
    z[4,3,0]  R1988     2.0098535716533661e-01
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R1898     -1
    z[4,3,1]  R1899     1
    z[4,3,1]  R1910     3.7018606066703796e-01
    z[4,3,1]  R1911     3.2088243961334229e-01
    z[4,3,1]  R1912     -0.0853620320558548
    z[4,3,1]  R1913     0.352740615606308
    z[4,3,1]  R1914     9.3586467206478119e-02
    z[4,3,1]  R1915     3.8938581943511963e-01
    z[4,3,1]  R1916     1.1426846683025360e-01
    z[4,3,1]  R1917     4.3071934580802917e-01
    z[4,3,1]  R1918     4.6511983871459961e-01
    z[4,3,1]  R1919     5.1966643333435059e-01
    z[4,3,1]  R1920     4.5888322591781616e-01
    z[4,3,1]  R1921     -8.3910757303237915e-01
    z[4,3,1]  R1922     -8.6533606052398682e-01
    z[4,3,1]  R1923     -0.856290876865387
    z[4,3,1]  R1924     -0.831427812576294
    z[4,3,1]  R1925     -8.8973259925842285e-01
    z[4,3,1]  R1926     -8.9831674098968506e-01
    z[4,3,1]  R1927     -8.8220846652984619e-01
    z[4,3,1]  R1928     -8.9002692699432373e-01
    z[4,3,1]  R1929     -7.4586510658264160e-01
    z[4,3,1]  R1930     2.2671137750148773e-01
    z[4,3,1]  R1931     5.6912928819656372e-01
    z[4,3,1]  R1932     4.9940598011016846e-01
    z[4,3,1]  R1933     5.0135904550552368e-01
    z[4,3,1]  R1934     4.9811157584190369e-01
    z[4,3,1]  R1935     5.1809805631637573e-01
    z[4,3,1]  R1936     5.7565355300903320e-01
    z[4,3,1]  R1937     4.0577733516693115e-01
    z[4,3,1]  R1938     -8.1414830684661865e-01
    z[4,3,1]  R1939     -2.6228375732898712e-02
    z[4,3,1]  R1940     5.8665776252746582e-01
    z[4,3,1]  R1941     -8.8336187601089478e-01
    z[4,3,1]  R1942     -8.6680001020431519e-01
    z[4,3,1]  R1943     -8.3143043518066406e-01
    z[4,3,1]  R1944     -8.7545108795166016e-01
    z[4,3,1]  R1945     -5.9915989637374878e-01
    z[4,3,1]  R1946     -3.1522031873464584e-02
    z[4,3,1]  R1947     -7.1259617805480957e-01
    z[4,3,1]  R1948     -2.4191428720951080e-01
    z[4,3,1]  R1949     -9.0931630134582520e-01
    z[4,3,1]  R1950     6.7801761627197266e-01
    z[4,3,1]  R1951     -5.3744238615036011e-01
    z[4,3,1]  R1952     5.1924854516983032e-01
    z[4,3,1]  R1953     7.3822093009948730e-01
    z[4,3,1]  R1954     -9.6936339139938354e-01
    z[4,3,1]  R1955     -8.4631758928298950e-01
    z[4,3,1]  R1956     -8.1340706348419189e-01
    z[4,3,1]  R1957     -1.3318565487861633e-01
    z[4,3,1]  R1958     -9.3571096658706665e-01
    z[4,3,1]  R1959     -3.4393274784088135e-01
    z[4,3,1]  R1960     6.0475111007690430e-01
    z[4,3,1]  R1961     -3.6786407232284546e-01
    z[4,3,1]  R1962     3.8820084929466248e-01
    z[4,3,1]  R1963     5.5196863412857056e-01
    z[4,3,1]  R1964     0.595467209815979
    z[4,3,1]  R1965     4.3397700786590576e-01
    z[4,3,1]  R1966     4.7003057599067688e-01
    z[4,3,1]  R1967     1.0072947479784489e-02
    z[4,3,1]  R1968     -4.1328358650207520e-01
    z[4,3,1]  R1969     6.8299764394760132e-01
    z[4,3,1]  R1970     -2.1420218050479889e-01
    z[4,3,1]  R1971     -6.9788807630538940e-01
    z[4,3,1]  R1972     -7.2894757986068726e-01
    z[4,3,1]  R1973     -3.8785722851753235e-01
    z[4,3,1]  R1974     -4.9330314993858337e-01
    z[4,3,1]  R1975     -0.549047589302063
    z[4,3,1]  R1976     -7.3758912086486816e-01
    z[4,3,1]  R1977     -6.3828259706497192e-01
    z[4,3,1]  R1978     -6.0159695148468018e-01
    z[4,3,1]  R1979     -0.551503598690033
    z[4,3,1]  R1980     -5.4990863800048828e-01
    z[4,3,1]  R1981     -1.7415808141231537e-01
    z[4,3,1]  R1982     -5.0131946802139282e-01
    z[4,3,1]  R1983     3.1767040491104126e-01
    z[4,3,1]  R1984     -4.1771686077117920e-01
    z[4,3,1]  R1985     -4.2553973197937012e-01
    z[4,3,1]  R1986     -0.717606246471405
    z[4,3,1]  R1987     -5.2050924301147461e-01
    z[4,3,1]  R1988     1.4430856704711914e-01
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R1900     -1
    z[4,3,2]  R1901     1
    z[4,3,2]  R1910     1.9356827437877655e-01
    z[4,3,2]  R1911     2.4685165286064148e-01
    z[4,3,2]  R1912     6.1206500977277756e-02
    z[4,3,2]  R1913     -2.0180317759513855e-01
    z[4,3,2]  R1914     4.4411984086036682e-01
    z[4,3,2]  R1915     -4.3181997537612915e-01
    z[4,3,2]  R1916     -2.7103242278099060e-01
    z[4,3,2]  R1917     -2.6697742938995361e-01
    z[4,3,2]  R1918     -3.4243506193161011e-01
    z[4,3,2]  R1919     -1.4939494431018829e-01
    z[4,3,2]  R1920     6.4450573921203613e-01
    z[4,3,2]  R1921     1.0331121087074280e-01
    z[4,3,2]  R1922     2.6637923717498779e-01
    z[4,3,2]  R1923     -5.4543375968933105e-02
    z[4,3,2]  R1924     5.0195097923278809e-02
    z[4,3,2]  R1925     6.9693282246589661e-02
    z[4,3,2]  R1926     -3.0473910737782717e-03
    z[4,3,2]  R1927     5.7179573923349380e-03
    z[4,3,2]  R1928     1.1403743177652359e-01
    z[4,3,2]  R1929     1.3642043806612492e-02
    z[4,3,2]  R1930     3.7542662024497986e-01
    z[4,3,2]  R1931     2.8058382868766785e-01
    z[4,3,2]  R1932     1.0063945502042770e-01
    z[4,3,2]  R1933     4.1253137588500977e-01
    z[4,3,2]  R1934     2.2937135398387909e-01
    z[4,3,2]  R1935     -1.9970403984189034e-02
    z[4,3,2]  R1936     -0.0692482516169548
    z[4,3,2]  R1937     5.8593684434890747e-01
    z[4,3,2]  R1938     4.3814271688461304e-01
    z[4,3,2]  R1939     0.30632483959198
    z[4,3,2]  R1940     1.7609870433807373e-01
    z[4,3,2]  R1941     -1.4286562800407410e-01
    z[4,3,2]  R1942     -4.6527005732059479e-02
    z[4,3,2]  R1943     -1.1773762851953506e-01
    z[4,3,2]  R1944     3.0067640542984009e-01
    z[4,3,2]  R1945     -2.5073844194412231e-01
    z[4,3,2]  R1946     0.209524467587471
    z[4,3,2]  R1947     1.4049339806661010e-03
    z[4,3,2]  R1948     1.0268007963895798e-01
    z[4,3,2]  R1949     -2.8969830274581909e-01
    z[4,3,2]  R1950     3.6941519379615784e-01
    z[4,3,2]  R1951     -4.3036320805549622e-01
    z[4,3,2]  R1952     5.8853012323379517e-01
    z[4,3,2]  R1953     4.5391544699668884e-02
    z[4,3,2]  R1954     -2.4259122088551521e-02
    z[4,3,2]  R1955     8.1423148512840271e-02
    z[4,3,2]  R1956     -7.7357396483421326e-02
    z[4,3,2]  R1957     2.0851007103919983e-01
    z[4,3,2]  R1958     -1.8838453292846680e-01
    z[4,3,2]  R1959     2.4028047919273376e-01
    z[4,3,2]  R1960     -1.9149206578731537e-01
    z[4,3,2]  R1961     -6.1956530809402466e-01
    z[4,3,2]  R1962     -1.0150258988142014e-01
    z[4,3,2]  R1963     5.1067221164703369e-01
    z[4,3,2]  R1964     -3.0399185419082642e-01
    z[4,3,2]  R1965     -6.3550509512424469e-02
    z[4,3,2]  R1966     -4.3908601999282837e-01
    z[4,3,2]  R1967     -5.5459529161453247e-01
    z[4,3,2]  R1968     -2.8686091303825378e-01
    z[4,3,2]  R1969     0.0934213399887085
    z[4,3,2]  R1970     -2.7673307061195374e-01
    z[4,3,2]  R1971     -1.6257500648498535e-01
    z[4,3,2]  R1972     2.0472067594528198e-01
    z[4,3,2]  R1973     1.8409414589405060e-01
    z[4,3,2]  R1974     1.0388576984405518e-01
    z[4,3,2]  R1975     1.4887210726737976e-01
    z[4,3,2]  R1976     4.9851119518280029e-02
    z[4,3,2]  R1977     1.0713803023099899e-01
    z[4,3,2]  R1978     2.0366646349430084e-01
    z[4,3,2]  R1979     -1.4279303140938282e-02
    z[4,3,2]  R1980     1.8054470419883728e-01
    z[4,3,2]  R1981     -3.8066647946834564e-02
    z[4,3,2]  R1982     1.5422993898391724e-01
    z[4,3,2]  R1983     1.4361312985420227e-01
    z[4,3,2]  R1984     4.2949758470058441e-02
    z[4,3,2]  R1985     1.5921603143215179e-01
    z[4,3,2]  R1986     1.7752985656261444e-01
    z[4,3,2]  R1987     1.6489961743354797e-01
    z[4,3,2]  R1988     3.1613722443580627e-01
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R1902     -1
    z[4,3,3]  R1903     1
    z[4,3,3]  R1910     5.8835631608963013e-01
    z[4,3,3]  R1911     5.7909131050109863e-01
    z[4,3,3]  R1912     7.1007597446441650e-01
    z[4,3,3]  R1913     5.1912295818328857e-01
    z[4,3,3]  R1914     6.7351454496383667e-01
    z[4,3,3]  R1915     2.3599152266979218e-01
    z[4,3,3]  R1916     1.0072951018810272e-01
    z[4,3,3]  R1917     2.6326471567153931e-01
    z[4,3,3]  R1918     -2.1841265261173248e-01
    z[4,3,3]  R1919     -4.2937964200973511e-01
    z[4,3,3]  R1920     -4.6761611104011536e-01
    z[4,3,3]  R1921     -4.9306672811508179e-01
    z[4,3,3]  R1922     -3.1495910882949829e-01
    z[4,3,3]  R1923     -3.9545559883117676e-01
    z[4,3,3]  R1924     -4.3779936432838440e-01
    z[4,3,3]  R1925     -1.8927714228630066e-01
    z[4,3,3]  R1926     -1.6373868286609650e-01
    z[4,3,3]  R1927     -2.1787050366401672e-01
    z[4,3,3]  R1928     -1.5182100236415863e-01
    z[4,3,3]  R1929     -6.5627634525299072e-01
    z[4,3,3]  R1930     -2.7796211838722229e-01
    z[4,3,3]  R1931     -4.3183439970016479e-01
    z[4,3,3]  R1932     -3.4537440538406372e-01
    z[4,3,3]  R1933     -0.092435322701931
    z[4,3,3]  R1934     -2.7672863006591797e-01
    z[4,3,3]  R1935     -4.0482899546623230e-01
    z[4,3,3]  R1936     -3.9469927549362183e-01
    z[4,3,3]  R1937     -5.2682596445083618e-01
    z[4,3,3]  R1938     -2.8664425015449524e-01
    z[4,3,3]  R1939     -4.9529033899307251e-01
    z[4,3,3]  R1940     -4.2812418937683105e-01
    z[4,3,3]  R1941     -3.9481440186500549e-01
    z[4,3,3]  R1942     -1.8525658547878265e-01
    z[4,3,3]  R1943     -2.7522468566894531e-01
    z[4,3,3]  R1944     0.0848386287689209
    z[4,3,3]  R1945     -4.0217173099517822e-01
    z[4,3,3]  R1946     -4.1430890560150146e-01
    z[4,3,3]  R1947     -3.9949494600296021e-01
    z[4,3,3]  R1948     -2.5498467683792114e-01
    z[4,3,3]  R1949     -3.7392899394035339e-02
    z[4,3,3]  R1950     -3.3119708299636841e-01
    z[4,3,3]  R1951     -2.1668106317520142e-01
    z[4,3,3]  R1952     -5.1878023147583008e-01
    z[4,3,3]  R1953     -5.1609623432159424e-01
    z[4,3,3]  R1954     -9.2928275465965271e-02
    z[4,3,3]  R1955     -3.2332196831703186e-01
    z[4,3,3]  R1956     -4.1578653454780579e-01
    z[4,3,3]  R1957     -5.5670082569122314e-01
    z[4,3,3]  R1958     -8.2895331084728241e-02
    z[4,3,3]  R1959     -1.3179579377174377e-01
    z[4,3,3]  R1960     5.7045191526412964e-01
    z[4,3,3]  R1961     4.8253723978996277e-01
    z[4,3,3]  R1962     6.8029654026031494e-01
    z[4,3,3]  R1963     -1.0830656439065933e-01
    z[4,3,3]  R1964     5.0035911798477173e-01
    z[4,3,3]  R1965     3.2207110524177551e-01
    z[4,3,3]  R1966     2.8305670619010925e-01
    z[4,3,3]  R1967     2.8177937865257263e-01
    z[4,3,3]  R1968     3.9799353480339050e-01
    z[4,3,3]  R1969     -1.1393939703702927e-01
    z[4,3,3]  R1970     3.9269354939460754e-01
    z[4,3,3]  R1971     4.8071038722991943e-01
    z[4,3,3]  R1972     1.0551664978265762e-01
    z[4,3,3]  R1973     -3.4226432908326387e-03
    z[4,3,3]  R1974     -7.2667285799980164e-02
    z[4,3,3]  R1975     -4.0364658832550049e-01
    z[4,3,3]  R1976     -5.4425221681594849e-01
    z[4,3,3]  R1977     -7.3211288452148438e-01
    z[4,3,3]  R1978     -6.5576130151748657e-01
    z[4,3,3]  R1979     -7.0714837312698364e-01
    z[4,3,3]  R1980     3.7765324115753174e-01
    z[4,3,3]  R1981     1.9084180891513824e-01
    z[4,3,3]  R1982     -3.1247639656066895e-01
    z[4,3,3]  R1983     -4.6759301424026489e-01
    z[4,3,3]  R1984     -2.9388004541397095e-01
    z[4,3,3]  R1985     -2.9821637272834778e-01
    z[4,3,3]  R1986     -2.7308362722396851e-01
    z[4,3,3]  R1987     -3.5534223914146423e-01
    z[4,3,3]  R1988     -7.9411095380783081e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R1904     -1
    z[4,3,4]  R1905     1
    z[4,3,4]  R1910     0.0576406754553318
    z[4,3,4]  R1911     -2.8113916516304016e-01
    z[4,3,4]  R1912     1.2987929582595825e-01
    z[4,3,4]  R1913     4.6343860030174255e-01
    z[4,3,4]  R1914     -0.510013222694397
    z[4,3,4]  R1915     -4.1461598873138428e-01
    z[4,3,4]  R1916     -7.2644233703613281e-01
    z[4,3,4]  R1917     0.361479789018631
    z[4,3,4]  R1918     8.6656715720891953e-03
    z[4,3,4]  R1919     -4.3161340057849884e-02
    z[4,3,4]  R1920     3.0528002977371216e-01
    z[4,3,4]  R1921     2.9022667557001114e-02
    z[4,3,4]  R1922     -1.9766373932361603e-01
    z[4,3,4]  R1923     2.7908211946487427e-01
    z[4,3,4]  R1924     2.6561075448989868e-01
    z[4,3,4]  R1925     1.1386289447546005e-01
    z[4,3,4]  R1926     -1.5815052390098572e-01
    z[4,3,4]  R1927     2.5039520859718323e-01
    z[4,3,4]  R1928     2.3188173770904541e-01
    z[4,3,4]  R1929     -8.0177605152130127e-02
    z[4,3,4]  R1930     3.8502511382102966e-01
    z[4,3,4]  R1931     2.4384586513042450e-01
    z[4,3,4]  R1932     1.8069259822368622e-01
    z[4,3,4]  R1933     3.5716065764427185e-01
    z[4,3,4]  R1934     0.376345157623291
    z[4,3,4]  R1935     -2.0123182237148285e-01
    z[4,3,4]  R1936     -1.8087539076805115e-01
    z[4,3,4]  R1937     -2.9361805319786072e-01
    z[4,3,4]  R1938     1.6702005267143250e-01
    z[4,3,4]  R1939     1.5417100489139557e-01
    z[4,3,4]  R1940     3.9853486418724060e-01
    z[4,3,4]  R1941     -1.0265780985355377e-01
    z[4,3,4]  R1942     -0.439564049243927
    z[4,3,4]  R1943     -5.2966731600463390e-03
    z[4,3,4]  R1944     -8.4944792091846466e-02
    z[4,3,4]  R1945     -3.2924994826316833e-01
    z[4,3,4]  R1946     -2.7652847766876221e-01
    z[4,3,4]  R1947     1.5353962779045105e-01
    z[4,3,4]  R1948     0.144717276096344
    z[4,3,4]  R1949     -3.5749140661209822e-03
    z[4,3,4]  R1950     4.1059872508049011e-01
    z[4,3,4]  R1951     -2.3432014882564545e-01
    z[4,3,4]  R1952     -2.3054113984107971e-01
    z[4,3,4]  R1953     9.5175974071025848e-02
    z[4,3,4]  R1954     1.5428699553012848e-01
    z[4,3,4]  R1955     -1.8565729260444641e-01
    z[4,3,4]  R1956     -2.3748582601547241e-01
    z[4,3,4]  R1957     -8.1103906035423279e-02
    z[4,3,4]  R1958     1.7757375538349152e-01
    z[4,3,4]  R1959     4.6526998281478882e-01
    z[4,3,4]  R1960     -5.0928759574890137e-01
    z[4,3,4]  R1961     3.3467937260866165e-02
    z[4,3,4]  R1962     -3.6692202091217041e-01
    z[4,3,4]  R1963     -6.2733925879001617e-02
    z[4,3,4]  R1964     1.3942405581474304e-01
    z[4,3,4]  R1965     -2.3931907117366791e-01
    z[4,3,4]  R1966     -0.0843191146850586
    z[4,3,4]  R1967     -2.0380539819598198e-02
    z[4,3,4]  R1968     -2.5483930110931396e-01
    z[4,3,4]  R1969     1.3971160352230072e-01
    z[4,3,4]  R1970     6.4389693737030029e-01
    z[4,3,4]  R1971     -3.3352595567703247e-01
    z[4,3,4]  R1972     9.9107161164283752e-02
    z[4,3,4]  R1973     3.8357204198837280e-01
    z[4,3,4]  R1974     -1.7420975863933563e-01
    z[4,3,4]  R1975     1.9177092611789703e-01
    z[4,3,4]  R1976     1.9314432144165039e-01
    z[4,3,4]  R1977     -6.8377837538719177e-02
    z[4,3,4]  R1978     -2.2632372379302979e-01
    z[4,3,4]  R1979     -2.8030967712402344e-01
    z[4,3,4]  R1980     -2.2098235785961151e-01
    z[4,3,4]  R1981     5.4563194513320923e-01
    z[4,3,4]  R1982     -0.060396958142519
    z[4,3,4]  R1983     2.3633283376693726e-01
    z[4,3,4]  R1984     -0.493927001953125
    z[4,3,4]  R1985     -5.5003982782363892e-01
    z[4,3,4]  R1986     1.9689303636550903e-01
    z[4,3,4]  R1987     4.7673948109149933e-02
    z[4,3,4]  R1988     -1.8436609208583832e-01
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R1906     -1
    z[4,3,5]  R1907     1
    z[4,3,5]  R1910     -2.5419354438781738e-01
    z[4,3,5]  R1911     5.5253233760595322e-02
    z[4,3,5]  R1912     -3.6885783076286316e-02
    z[4,3,5]  R1913     -2.2479355335235596e-01
    z[4,3,5]  R1914     -6.6237091086804867e-03
    z[4,3,5]  R1915     -4.9201363325119019e-01
    z[4,3,5]  R1916     -3.0697554349899292e-01
    z[4,3,5]  R1917     -5.5386364459991455e-01
    z[4,3,5]  R1918     0.341463178396225
    z[4,3,5]  R1919     2.4733063578605652e-01
    z[4,3,5]  R1920     -5.3956888616085052e-02
    z[4,3,5]  R1921     -1.4479069411754608e-01
    z[4,3,5]  R1922     2.7465509250760078e-02
    z[4,3,5]  R1923     2.3230038583278656e-02
    z[4,3,5]  R1924     -1.4664037525653839e-01
    z[4,3,5]  R1925     -2.1142846345901489e-01
    z[4,3,5]  R1926     3.5193203948438168e-03
    z[4,3,5]  R1927     -2.8943467140197754e-01
    z[4,3,5]  R1928     1.2393782287836075e-01
    z[4,3,5]  R1929     0.0698886290192604
    z[4,3,5]  R1930     -7.6179319620132446e-01
    z[4,3,5]  R1931     1.6764022409915924e-01
    z[4,3,5]  R1932     5.3217488527297974e-01
    z[4,3,5]  R1933     4.8674359917640686e-01
    z[4,3,5]  R1934     4.7387725114822388e-01
    z[4,3,5]  R1935     2.3500698804855347e-01
    z[4,3,5]  R1936     -4.2441502213478088e-02
    z[4,3,5]  R1937     -3.1275925040245056e-01
    z[4,3,5]  R1938     -1.8474724143743515e-02
    z[4,3,5]  R1939     1.6109757125377655e-01
    z[4,3,5]  R1940     -9.8054654896259308e-02
    z[4,3,5]  R1941     -1.2702740728855133e-01
    z[4,3,5]  R1942     -8.6095677688717842e-03
    z[4,3,5]  R1943     -2.8188601136207581e-01
    z[4,3,5]  R1944     -4.4874340295791626e-02
    z[4,3,5]  R1945     3.7709128856658936e-01
    z[4,3,5]  R1946     -2.0452212542295456e-02
    z[4,3,5]  R1947     1.1788973212242126e-01
    z[4,3,5]  R1948     -6.4595431089401245e-02
    z[4,3,5]  R1949     2.1863219141960144e-01
    z[4,3,5]  R1950     5.1559224724769592e-02
    z[4,3,5]  R1951     2.0553177595138550e-01
    z[4,3,5]  R1952     -1.7279775440692902e-01
    z[4,3,5]  R1953     -1.7816193401813507e-01
    z[4,3,5]  R1954     -8.2208685576915741e-02
    z[4,3,5]  R1955     1.6701954603195190e-01
    z[4,3,5]  R1956     -6.9015175104141235e-02
    z[4,3,5]  R1957     2.7071535587310791e-02
    z[4,3,5]  R1958     1.9414480030536652e-01
    z[4,3,5]  R1959     3.5885747522115707e-02
    z[4,3,5]  R1960     8.1511437892913818e-02
    z[4,3,5]  R1961     4.6914857625961304e-01
    z[4,3,5]  R1962     -7.9469613730907440e-02
    z[4,3,5]  R1963     -5.7158374786376953e-01
    z[4,3,5]  R1964     -9.7945593297481537e-02
    z[4,3,5]  R1965     -4.0284192562103271e-01
    z[4,3,5]  R1966     2.1341418847441673e-02
    z[4,3,5]  R1967     3.0682021379470825e-01
    z[4,3,5]  R1968     3.8957217335700989e-01
    z[4,3,5]  R1969     1.9616955518722534e-01
    z[4,3,5]  R1970     -4.7348102927207947e-01
    z[4,3,5]  R1971     -3.2203987240791321e-01
    z[4,3,5]  R1972     -2.7028828859329224e-01
    z[4,3,5]  R1973     6.8928644061088562e-02
    z[4,3,5]  R1974     -2.3548196256160736e-01
    z[4,3,5]  R1975     1.0767978429794312e-01
    z[4,3,5]  R1976     -3.4833904355764389e-02
    z[4,3,5]  R1977     -1.7041069269180298e-01
    z[4,3,5]  R1978     2.4099244177341461e-01
    z[4,3,5]  R1979     2.1224381402134895e-02
    z[4,3,5]  R1980     -3.2692757248878479e-01
    z[4,3,5]  R1981     2.1178103983402252e-01
    z[4,3,5]  R1982     1.9609722495079041e-01
    z[4,3,5]  R1983     5.3016132116317749e-01
    z[4,3,5]  R1984     8.2845687866210938e-02
    z[4,3,5]  R1985     2.4352923035621643e-01
    z[4,3,5]  R1986     7.0529342629015446e-03
    z[4,3,5]  R1987     -2.6302334666252136e-01
    z[4,3,5]  R1988     2.1879564225673676e-01
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R1908     -1
    z[4,3,6]  R1909     1
    z[4,3,6]  R1910     -5.9919780492782593e-01
    z[4,3,6]  R1911     6.0451114177703857e-01
    z[4,3,6]  R1912     -4.3199202418327332e-01
    z[4,3,6]  R1913     -1.0879322141408920e-01
    z[4,3,6]  R1914     -0.241790771484375
    z[4,3,6]  R1915     2.7485761046409607e-01
    z[4,3,6]  R1916     -3.1329923868179321e-01
    z[4,3,6]  R1917     4.0665698051452637e-01
    z[4,3,6]  R1918     2.0220498740673065e-01
    z[4,3,6]  R1919     -5.0999283790588379e-02
    z[4,3,6]  R1920     2.9861494898796082e-02
    z[4,3,6]  R1921     5.4020345211029053e-02
    z[4,3,6]  R1922     -2.0257534086704254e-01
    z[4,3,6]  R1923     -1.6104483604431152e-01
    z[4,3,6]  R1924     -1.4829909801483154e-01
    z[4,3,6]  R1925     3.2283014059066772e-01
    z[4,3,6]  R1926     -3.5510218143463135e-01
    z[4,3,6]  R1927     1.5719279646873474e-01
    z[4,3,6]  R1928     2.6076811552047729e-01
    z[4,3,6]  R1929     3.7825204432010651e-02
    z[4,3,6]  R1930     2.9783040285110474e-02
    z[4,3,6]  R1931     -1.9978380203247070e-01
    z[4,3,6]  R1932     9.6700891852378845e-02
    z[4,3,6]  R1933     -6.1911858618259430e-02
    z[4,3,6]  R1934     6.2522336840629578e-02
    z[4,3,6]  R1935     2.1353588998317719e-01
    z[4,3,6]  R1936     -2.8371039032936096e-01
    z[4,3,6]  R1937     1.0625831037759781e-01
    z[4,3,6]  R1938     0.0215000007301569
    z[4,3,6]  R1939     1.2924927473068237e-01
    z[4,3,6]  R1940     -2.9671558737754822e-01
    z[4,3,6]  R1941     1.0736639797687531e-01
    z[4,3,6]  R1942     1.3117294013500214e-01
    z[4,3,6]  R1943     1.6855685412883759e-01
    z[4,3,6]  R1944     0.0594826303422451
    z[4,3,6]  R1945     5.6614372879266739e-03
    z[4,3,6]  R1946     2.8335985541343689e-01
    z[4,3,6]  R1947     1.4543295837938786e-02
    z[4,3,6]  R1948     3.5334545373916626e-01
    z[4,3,6]  R1949     9.2243090271949768e-02
    z[4,3,6]  R1950     1.8549966812133789e-01
    z[4,3,6]  R1951     4.8253691196441650e-01
    z[4,3,6]  R1952     1.7592176795005798e-01
    z[4,3,6]  R1953     4.6619750559329987e-02
    z[4,3,6]  R1954     -3.9099924266338348e-02
    z[4,3,6]  R1955     2.9522067308425903e-01
    z[4,3,6]  R1956     -2.4551825225353241e-01
    z[4,3,6]  R1957     -1.6466338932514191e-01
    z[4,3,6]  R1958     2.1250389516353607e-02
    z[4,3,6]  R1959     -1.3845956325531006e-01
    z[4,3,6]  R1960     -6.2325235456228256e-02
    z[4,3,6]  R1961     -8.0800447613000870e-03
    z[4,3,6]  R1962     4.7462871670722961e-01
    z[4,3,6]  R1963     2.6106837391853333e-01
    z[4,3,6]  R1964     -4.8445445299148560e-01
    z[4,3,6]  R1965     -0.69123375415802
    z[4,3,6]  R1966     -3.4347614645957947e-01
    z[4,3,6]  R1967     -6.9000262022018433e-01
    z[4,3,6]  R1968     -3.4912335872650146e-01
    z[4,3,6]  R1969     6.3749450445175171e-01
    z[4,3,6]  R1970     2.1101489663124084e-01
    z[4,3,6]  R1971     -0.186966210603714
    z[4,3,6]  R1972     3.9959362149238586e-01
    z[4,3,6]  R1973     2.7085286378860474e-01
    z[4,3,6]  R1974     2.3601894080638885e-01
    z[4,3,6]  R1975     3.2111827284097672e-02
    z[4,3,6]  R1976     -2.9096311330795288e-01
    z[4,3,6]  R1977     -9.9338285624980927e-02
    z[4,3,6]  R1978     2.3325771093368530e-01
    z[4,3,6]  R1979     2.3498864471912384e-01
    z[4,3,6]  R1980     3.7359076738357544e-01
    z[4,3,6]  R1981     3.6271774768829346e-01
    z[4,3,6]  R1982     -1.2907078862190247e-01
    z[4,3,6]  R1983     -3.0316799879074097e-01
    z[4,3,6]  R1984     -1.4830298721790314e-01
    z[4,3,6]  R1985     -1.4721424877643585e-01
    z[4,3,6]  R1986     0.0926625207066536
    z[4,3,6]  R1987     -0.379141241312027
    z[4,3,6]  R1988     -3.5547509789466858e-01
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R2032     -1
    z[4,5,0]  R2033     1
    z[4,5,0]  R2046     -2.2881361842155457e-01
    z[4,5,0]  R2047     -2.3070777952671051e-01
    z[4,5,0]  R2048     -5.2906799316406250e-01
    z[4,5,0]  R2049     -0.536858856678009
    z[4,5,0]  R2050     -1.4750261604785919e-01
    z[4,5,0]  R2051     -3.4159582853317261e-01
    z[4,5,0]  R2052     -4.2805242538452148e-01
    z[4,5,0]  R2053     2.6663309335708618e-01
    z[4,5,0]  R2054     -6.7907178401947021e-01
    z[4,5,0]  R2055     -6.7647963762283325e-01
    z[4,5,0]  R2056     2.4160841107368469e-01
    z[4,5,0]  R2057     1.3185410201549530e-01
    z[4,5,0]  R2058     -1.3201734982430935e-02
    z[4,5,0]  R2059     5.5172022432088852e-02
    z[4,5,0]  R2060     -2.2242331877350807e-02
    z[4,5,0]  R2061     7.6204225420951843e-02
    z[4,5,0]  R2062     1.2282416224479675e-01
    z[4,5,0]  R2063     5.5029653012752533e-02
    z[4,5,0]  R2064     1.8619391322135925e-01
    z[4,5,0]  R2065     -7.5316391885280609e-03
    z[4,5,0]  R2066     3.0556654557585716e-02
    z[4,5,0]  R2067     5.3235888481140137e-01
    z[4,5,0]  R2068     5.4403203725814819e-01
    z[4,5,0]  R2069     4.4899505376815796e-01
    z[4,5,0]  R2070     5.0258380174636841e-01
    z[4,5,0]  R2071     6.5266287326812744e-01
    z[4,5,0]  R2072     6.2692219018936157e-01
    z[4,5,0]  R2073     -1.3840657472610474e-01
    z[4,5,0]  R2074     -1.8528200685977936e-01
    z[4,5,0]  R2075     7.7054411172866821e-01
    z[4,5,0]  R2076     4.3017071485519409e-01
    z[4,5,0]  R2077     7.1977972984313965e-02
    z[4,5,0]  R2078     -4.0937475860118866e-02
    z[4,5,0]  R2079     -3.3348676562309265e-01
    z[4,5,0]  R2080     3.5101863741874695e-01
    z[4,5,0]  R2081     -4.0713661909103394e-01
    z[4,5,0]  R2082     7.9137533903121948e-01
    z[4,5,0]  R2083     -0.54306960105896
    z[4,5,0]  R2084     8.4613734483718872e-01
    z[4,5,0]  R2085     -1.7747931182384491e-01
    z[4,5,0]  R2086     2.9744449257850647e-01
    z[4,5,0]  R2087     -3.8600695133209229e-01
    z[4,5,0]  R2088     3.0390096828341484e-02
    z[4,5,0]  R2089     3.7899947166442871e-01
    z[4,5,0]  R2090     -1.3790874183177948e-01
    z[4,5,0]  R2091     1.5185585618019104e-01
    z[4,5,0]  R2092     1.9510146975517273e-01
    z[4,5,0]  R2093     7.7100229263305664e-01
    z[4,5,0]  R2094     1.1139265447854996e-01
    z[4,5,0]  R2095     7.5476515293121338e-01
    z[4,5,0]  R2096     6.5863317251205444e-01
    z[4,5,0]  R2097     3.5136952996253967e-01
    z[4,5,0]  R2098     4.5002645254135132e-01
    z[4,5,0]  R2099     -1.8709459900856018e-01
    z[4,5,0]  R2100     -6.0926965670660138e-04
    z[4,5,0]  R2101     5.3828325122594833e-02
    z[4,5,0]  R2102     -5.7057225704193115e-01
    z[4,5,0]  R2103     -9.6037723124027252e-02
    z[4,5,0]  R2104     -4.0170863270759583e-01
    z[4,5,0]  R2105     -4.4690504670143127e-01
    z[4,5,0]  R2106     2.4390691518783569e-01
    z[4,5,0]  R2107     -1.6205526888370514e-01
    z[4,5,0]  R2108     -4.1034218668937683e-01
    z[4,5,0]  R2109     -0.491395503282547
    z[4,5,0]  R2110     -5.4686480760574341e-01
    z[4,5,0]  R2111     7.1733094751834869e-02
    z[4,5,0]  R2112     3.0037495493888855e-01
    z[4,5,0]  R2113     1.6303683817386627e-01
    z[4,5,0]  R2114     3.2199257612228394e-01
    z[4,5,0]  R2115     5.4086589813232422e-01
    z[4,5,0]  R2116     -9.2967316508293152e-02
    z[4,5,0]  R2117     -8.6629527807235718e-01
    z[4,5,0]  R2118     -8.9378046989440918e-01
    z[4,5,0]  R2119     -6.3994240760803223e-01
    z[4,5,0]  R2120     -7.6945525407791138e-01
    z[4,5,0]  R2121     -6.9138383865356445e-01
    z[4,5,0]  R2122     -3.5067155957221985e-01
    z[4,5,0]  R2123     4.1472426056861877e-01
    z[4,5,0]  R2124     4.9624881148338318e-01
    z[4,5,0]  R2125     5.4533189535140991e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R2034     -1
    z[4,5,1]  R2035     1
    z[4,5,1]  R2046     3.7018606066703796e-01
    z[4,5,1]  R2047     3.2088243961334229e-01
    z[4,5,1]  R2048     -0.0853620320558548
    z[4,5,1]  R2049     0.352740615606308
    z[4,5,1]  R2050     9.3586467206478119e-02
    z[4,5,1]  R2051     3.8938581943511963e-01
    z[4,5,1]  R2052     1.1426846683025360e-01
    z[4,5,1]  R2053     4.3071934580802917e-01
    z[4,5,1]  R2054     4.6511983871459961e-01
    z[4,5,1]  R2055     5.1966643333435059e-01
    z[4,5,1]  R2056     4.5888322591781616e-01
    z[4,5,1]  R2057     -8.3910757303237915e-01
    z[4,5,1]  R2058     -8.6533606052398682e-01
    z[4,5,1]  R2059     -0.856290876865387
    z[4,5,1]  R2060     -0.831427812576294
    z[4,5,1]  R2061     -8.8973259925842285e-01
    z[4,5,1]  R2062     -8.9831674098968506e-01
    z[4,5,1]  R2063     -8.8220846652984619e-01
    z[4,5,1]  R2064     -8.9002692699432373e-01
    z[4,5,1]  R2065     -7.4586510658264160e-01
    z[4,5,1]  R2066     2.2671137750148773e-01
    z[4,5,1]  R2067     5.6912928819656372e-01
    z[4,5,1]  R2068     4.9940598011016846e-01
    z[4,5,1]  R2069     5.0135904550552368e-01
    z[4,5,1]  R2070     4.9811157584190369e-01
    z[4,5,1]  R2071     5.1809805631637573e-01
    z[4,5,1]  R2072     5.7565355300903320e-01
    z[4,5,1]  R2073     4.0577733516693115e-01
    z[4,5,1]  R2074     -8.1414830684661865e-01
    z[4,5,1]  R2075     -2.6228375732898712e-02
    z[4,5,1]  R2076     5.8665776252746582e-01
    z[4,5,1]  R2077     -8.8336187601089478e-01
    z[4,5,1]  R2078     -8.6680001020431519e-01
    z[4,5,1]  R2079     -8.3143043518066406e-01
    z[4,5,1]  R2080     -8.7545108795166016e-01
    z[4,5,1]  R2081     -5.9915989637374878e-01
    z[4,5,1]  R2082     -3.1522031873464584e-02
    z[4,5,1]  R2083     -7.1259617805480957e-01
    z[4,5,1]  R2084     -2.4191428720951080e-01
    z[4,5,1]  R2085     -9.0931630134582520e-01
    z[4,5,1]  R2086     6.7801761627197266e-01
    z[4,5,1]  R2087     -5.3744238615036011e-01
    z[4,5,1]  R2088     5.1924854516983032e-01
    z[4,5,1]  R2089     7.3822093009948730e-01
    z[4,5,1]  R2090     -9.6936339139938354e-01
    z[4,5,1]  R2091     -8.4631758928298950e-01
    z[4,5,1]  R2092     -8.1340706348419189e-01
    z[4,5,1]  R2093     -1.3318565487861633e-01
    z[4,5,1]  R2094     -9.3571096658706665e-01
    z[4,5,1]  R2095     -3.4393274784088135e-01
    z[4,5,1]  R2096     3.5655662417411804e-02
    z[4,5,1]  R2097     -6.8967863917350769e-02
    z[4,5,1]  R2098     3.3862382173538208e-02
    z[4,5,1]  R2099     1.3009256124496460e-01
    z[4,5,1]  R2100     7.6676271855831146e-02
    z[4,5,1]  R2101     1.8855138123035431e-01
    z[4,5,1]  R2102     1.0348648577928543e-01
    z[4,5,1]  R2103     1.7468252778053284e-01
    z[4,5,1]  R2104     4.8111043870449066e-03
    z[4,5,1]  R2105     -5.5101740360260010e-01
    z[4,5,1]  R2106     3.6529025435447693e-01
    z[4,5,1]  R2107     5.0101137161254883e-01
    z[4,5,1]  R2108     2.3997753858566284e-01
    z[4,5,1]  R2109     6.4626473188400269e-01
    z[4,5,1]  R2110     -2.7780082821846008e-01
    z[4,5,1]  R2111     5.2693653106689453e-01
    z[4,5,1]  R2112     2.0449882745742798e-01
    z[4,5,1]  R2113     2.8308564424514771e-01
    z[4,5,1]  R2114     1.5430007874965668e-01
    z[4,5,1]  R2115     -6.8047416210174561e-01
    z[4,5,1]  R2116     7.3471927642822266e-01
    z[4,5,1]  R2117     -3.5882565379142761e-01
    z[4,5,1]  R2118     -1.5928235650062561e-01
    z[4,5,1]  R2119     7.7059499919414520e-02
    z[4,5,1]  R2120     0.0466160774230957
    z[4,5,1]  R2121     -2.1337196230888367e-01
    z[4,5,1]  R2122     -2.3984816670417786e-01
    z[4,5,1]  R2123     3.0023759603500366e-01
    z[4,5,1]  R2124     -7.8539723157882690e-01
    z[4,5,1]  R2125     -6.9796615839004517e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R2036     -1
    z[4,5,2]  R2037     1
    z[4,5,2]  R2046     1.9356827437877655e-01
    z[4,5,2]  R2047     2.4685165286064148e-01
    z[4,5,2]  R2048     6.1206500977277756e-02
    z[4,5,2]  R2049     -2.0180317759513855e-01
    z[4,5,2]  R2050     4.4411984086036682e-01
    z[4,5,2]  R2051     -4.3181997537612915e-01
    z[4,5,2]  R2052     -2.7103242278099060e-01
    z[4,5,2]  R2053     -2.6697742938995361e-01
    z[4,5,2]  R2054     -3.4243506193161011e-01
    z[4,5,2]  R2055     -1.4939494431018829e-01
    z[4,5,2]  R2056     6.4450573921203613e-01
    z[4,5,2]  R2057     1.0331121087074280e-01
    z[4,5,2]  R2058     2.6637923717498779e-01
    z[4,5,2]  R2059     -5.4543375968933105e-02
    z[4,5,2]  R2060     5.0195097923278809e-02
    z[4,5,2]  R2061     6.9693282246589661e-02
    z[4,5,2]  R2062     -3.0473910737782717e-03
    z[4,5,2]  R2063     5.7179573923349380e-03
    z[4,5,2]  R2064     1.1403743177652359e-01
    z[4,5,2]  R2065     1.3642043806612492e-02
    z[4,5,2]  R2066     3.7542662024497986e-01
    z[4,5,2]  R2067     2.8058382868766785e-01
    z[4,5,2]  R2068     1.0063945502042770e-01
    z[4,5,2]  R2069     4.1253137588500977e-01
    z[4,5,2]  R2070     2.2937135398387909e-01
    z[4,5,2]  R2071     -1.9970403984189034e-02
    z[4,5,2]  R2072     -0.0692482516169548
    z[4,5,2]  R2073     5.8593684434890747e-01
    z[4,5,2]  R2074     4.3814271688461304e-01
    z[4,5,2]  R2075     0.30632483959198
    z[4,5,2]  R2076     1.7609870433807373e-01
    z[4,5,2]  R2077     -1.4286562800407410e-01
    z[4,5,2]  R2078     -4.6527005732059479e-02
    z[4,5,2]  R2079     -1.1773762851953506e-01
    z[4,5,2]  R2080     3.0067640542984009e-01
    z[4,5,2]  R2081     -2.5073844194412231e-01
    z[4,5,2]  R2082     0.209524467587471
    z[4,5,2]  R2083     1.4049339806661010e-03
    z[4,5,2]  R2084     1.0268007963895798e-01
    z[4,5,2]  R2085     -2.8969830274581909e-01
    z[4,5,2]  R2086     3.6941519379615784e-01
    z[4,5,2]  R2087     -4.3036320805549622e-01
    z[4,5,2]  R2088     5.8853012323379517e-01
    z[4,5,2]  R2089     4.5391544699668884e-02
    z[4,5,2]  R2090     -2.4259122088551521e-02
    z[4,5,2]  R2091     8.1423148512840271e-02
    z[4,5,2]  R2092     -7.7357396483421326e-02
    z[4,5,2]  R2093     2.0851007103919983e-01
    z[4,5,2]  R2094     -1.8838453292846680e-01
    z[4,5,2]  R2095     2.4028047919273376e-01
    z[4,5,2]  R2096     4.9690103530883789e-01
    z[4,5,2]  R2097     5.6668418645858765e-01
    z[4,5,2]  R2098     0.788059413433075
    z[4,5,2]  R2099     4.3211534619331360e-01
    z[4,5,2]  R2100     8.6823272705078125e-01
    z[4,5,2]  R2101     5.7285249233245850e-01
    z[4,5,2]  R2102     -5.4072532802820206e-02
    z[4,5,2]  R2103     -7.0453107357025146e-02
    z[4,5,2]  R2104     -2.5815838575363159e-01
    z[4,5,2]  R2105     2.3707246780395508e-01
    z[4,5,2]  R2106     -3.4773632884025574e-01
    z[4,5,2]  R2107     -4.4258171319961548e-01
    z[4,5,2]  R2108     -2.0929503440856934e-01
    z[4,5,2]  R2109     0.0709293782711029
    z[4,5,2]  R2110     -6.5322893857955933e-01
    z[4,5,2]  R2111     -1.1875462532043457e-01
    z[4,5,2]  R2112     -3.9269593358039856e-01
    z[4,5,2]  R2113     -4.7192507982254028e-01
    z[4,5,2]  R2114     -3.8370156288146973e-01
    z[4,5,2]  R2115     -2.9528501629829407e-01
    z[4,5,2]  R2116     1.4096125960350037e-01
    z[4,5,2]  R2117     -1.0095614194869995e-01
    z[4,5,2]  R2118     1.3848142325878143e-01
    z[4,5,2]  R2119     -3.6666259169578552e-01
    z[4,5,2]  R2120     -3.1680583953857422e-01
    z[4,5,2]  R2121     -0.0551447868347168
    z[4,5,2]  R2122     -4.8404029011726379e-01
    z[4,5,2]  R2123     -3.7091752886772156e-01
    z[4,5,2]  R2124     -1.7900729179382324e-01
    z[4,5,2]  R2125     -1.5813142061233521e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R2038     -1
    z[4,5,3]  R2039     1
    z[4,5,3]  R2046     5.8835631608963013e-01
    z[4,5,3]  R2047     5.7909131050109863e-01
    z[4,5,3]  R2048     7.1007597446441650e-01
    z[4,5,3]  R2049     5.1912295818328857e-01
    z[4,5,3]  R2050     6.7351454496383667e-01
    z[4,5,3]  R2051     2.3599152266979218e-01
    z[4,5,3]  R2052     1.0072951018810272e-01
    z[4,5,3]  R2053     2.6326471567153931e-01
    z[4,5,3]  R2054     -2.1841265261173248e-01
    z[4,5,3]  R2055     -4.2937964200973511e-01
    z[4,5,3]  R2056     -4.6761611104011536e-01
    z[4,5,3]  R2057     -4.9306672811508179e-01
    z[4,5,3]  R2058     -3.1495910882949829e-01
    z[4,5,3]  R2059     -3.9545559883117676e-01
    z[4,5,3]  R2060     -4.3779936432838440e-01
    z[4,5,3]  R2061     -1.8927714228630066e-01
    z[4,5,3]  R2062     -1.6373868286609650e-01
    z[4,5,3]  R2063     -2.1787050366401672e-01
    z[4,5,3]  R2064     -1.5182100236415863e-01
    z[4,5,3]  R2065     -6.5627634525299072e-01
    z[4,5,3]  R2066     -2.7796211838722229e-01
    z[4,5,3]  R2067     -4.3183439970016479e-01
    z[4,5,3]  R2068     -3.4537440538406372e-01
    z[4,5,3]  R2069     -0.092435322701931
    z[4,5,3]  R2070     -2.7672863006591797e-01
    z[4,5,3]  R2071     -4.0482899546623230e-01
    z[4,5,3]  R2072     -3.9469927549362183e-01
    z[4,5,3]  R2073     -5.2682596445083618e-01
    z[4,5,3]  R2074     -2.8664425015449524e-01
    z[4,5,3]  R2075     -4.9529033899307251e-01
    z[4,5,3]  R2076     -4.2812418937683105e-01
    z[4,5,3]  R2077     -3.9481440186500549e-01
    z[4,5,3]  R2078     -1.8525658547878265e-01
    z[4,5,3]  R2079     -2.7522468566894531e-01
    z[4,5,3]  R2080     0.0848386287689209
    z[4,5,3]  R2081     -4.0217173099517822e-01
    z[4,5,3]  R2082     -4.1430890560150146e-01
    z[4,5,3]  R2083     -3.9949494600296021e-01
    z[4,5,3]  R2084     -2.5498467683792114e-01
    z[4,5,3]  R2085     -3.7392899394035339e-02
    z[4,5,3]  R2086     -3.3119708299636841e-01
    z[4,5,3]  R2087     -2.1668106317520142e-01
    z[4,5,3]  R2088     -5.1878023147583008e-01
    z[4,5,3]  R2089     -5.1609623432159424e-01
    z[4,5,3]  R2090     -9.2928275465965271e-02
    z[4,5,3]  R2091     -3.2332196831703186e-01
    z[4,5,3]  R2092     -4.1578653454780579e-01
    z[4,5,3]  R2093     -5.5670082569122314e-01
    z[4,5,3]  R2094     -8.2895331084728241e-02
    z[4,5,3]  R2095     -1.3179579377174377e-01
    z[4,5,3]  R2096     -5.0862443447113037e-01
    z[4,5,3]  R2097     2.7938507497310638e-02
    z[4,5,3]  R2098     -1.6678662598133087e-01
    z[4,5,3]  R2099     1.1506868898868561e-01
    z[4,5,3]  R2100     -1.8325862288475037e-01
    z[4,5,3]  R2101     6.6361993551254272e-01
    z[4,5,3]  R2102     0.674699068069458
    z[4,5,3]  R2103     4.8612591624259949e-01
    z[4,5,3]  R2104     4.2541259527206421e-01
    z[4,5,3]  R2105     5.2751320600509644e-01
    z[4,5,3]  R2106     -2.3076803982257843e-01
    z[4,5,3]  R2107     -5.7352638244628906e-01
    z[4,5,3]  R2108     -7.9003876447677612e-01
    z[4,5,3]  R2109     -1.9347956776618958e-01
    z[4,5,3]  R2110     1.0992675274610519e-01
    z[4,5,3]  R2111     0.453823983669281
    z[4,5,3]  R2112     -1.9309048354625702e-01
    z[4,5,3]  R2113     1.9135428592562675e-02
    z[4,5,3]  R2114     -2.6681306958198547e-01
    z[4,5,3]  R2115     1.7161494493484497e-01
    z[4,5,3]  R2116     4.4192460179328918e-01
    z[4,5,3]  R2117     0.290324866771698
    z[4,5,3]  R2118     2.8379639983177185e-01
    z[4,5,3]  R2119     4.4903361797332764e-01
    z[4,5,3]  R2120     4.4476497173309326e-01
    z[4,5,3]  R2121     4.6124801039695740e-01
    z[4,5,3]  R2122     7.2298157215118408e-01
    z[4,5,3]  R2123     3.6498349905014038e-01
    z[4,5,3]  R2124     0.132520392537117
    z[4,5,3]  R2125     0.301140159368515
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R2040     -1
    z[4,5,4]  R2041     1
    z[4,5,4]  R2046     0.0576406754553318
    z[4,5,4]  R2047     -2.8113916516304016e-01
    z[4,5,4]  R2048     1.2987929582595825e-01
    z[4,5,4]  R2049     4.6343860030174255e-01
    z[4,5,4]  R2050     -0.510013222694397
    z[4,5,4]  R2051     -4.1461598873138428e-01
    z[4,5,4]  R2052     -7.2644233703613281e-01
    z[4,5,4]  R2053     0.361479789018631
    z[4,5,4]  R2054     8.6656715720891953e-03
    z[4,5,4]  R2055     -4.3161340057849884e-02
    z[4,5,4]  R2056     3.0528002977371216e-01
    z[4,5,4]  R2057     2.9022667557001114e-02
    z[4,5,4]  R2058     -1.9766373932361603e-01
    z[4,5,4]  R2059     2.7908211946487427e-01
    z[4,5,4]  R2060     2.6561075448989868e-01
    z[4,5,4]  R2061     1.1386289447546005e-01
    z[4,5,4]  R2062     -1.5815052390098572e-01
    z[4,5,4]  R2063     2.5039520859718323e-01
    z[4,5,4]  R2064     2.3188173770904541e-01
    z[4,5,4]  R2065     -8.0177605152130127e-02
    z[4,5,4]  R2066     3.8502511382102966e-01
    z[4,5,4]  R2067     2.4384586513042450e-01
    z[4,5,4]  R2068     1.8069259822368622e-01
    z[4,5,4]  R2069     3.5716065764427185e-01
    z[4,5,4]  R2070     0.376345157623291
    z[4,5,4]  R2071     -2.0123182237148285e-01
    z[4,5,4]  R2072     -1.8087539076805115e-01
    z[4,5,4]  R2073     -2.9361805319786072e-01
    z[4,5,4]  R2074     1.6702005267143250e-01
    z[4,5,4]  R2075     1.5417100489139557e-01
    z[4,5,4]  R2076     3.9853486418724060e-01
    z[4,5,4]  R2077     -1.0265780985355377e-01
    z[4,5,4]  R2078     -0.439564049243927
    z[4,5,4]  R2079     -5.2966731600463390e-03
    z[4,5,4]  R2080     -8.4944792091846466e-02
    z[4,5,4]  R2081     -3.2924994826316833e-01
    z[4,5,4]  R2082     -2.7652847766876221e-01
    z[4,5,4]  R2083     1.5353962779045105e-01
    z[4,5,4]  R2084     0.144717276096344
    z[4,5,4]  R2085     -3.5749140661209822e-03
    z[4,5,4]  R2086     4.1059872508049011e-01
    z[4,5,4]  R2087     -2.3432014882564545e-01
    z[4,5,4]  R2088     -2.3054113984107971e-01
    z[4,5,4]  R2089     9.5175974071025848e-02
    z[4,5,4]  R2090     1.5428699553012848e-01
    z[4,5,4]  R2091     -1.8565729260444641e-01
    z[4,5,4]  R2092     -2.3748582601547241e-01
    z[4,5,4]  R2093     -8.1103906035423279e-02
    z[4,5,4]  R2094     1.7757375538349152e-01
    z[4,5,4]  R2095     4.6526998281478882e-01
    z[4,5,4]  R2096     1.7950442433357239e-01
    z[4,5,4]  R2097     0.481612890958786
    z[4,5,4]  R2098     -6.2043469399213791e-02
    z[4,5,4]  R2099     1.0086730867624283e-01
    z[4,5,4]  R2100     -4.4408363103866577e-01
    z[4,5,4]  R2101     -1.0774364322423935e-01
    z[4,5,4]  R2102     2.2905133664608002e-01
    z[4,5,4]  R2103     5.6224584579467773e-01
    z[4,5,4]  R2104     -3.8214331865310669e-01
    z[4,5,4]  R2105     -1.6736510396003723e-01
    z[4,5,4]  R2106     6.4547348022460938e-01
    z[4,5,4]  R2107     3.7332189083099365e-01
    z[4,5,4]  R2108     9.3645811080932617e-02
    z[4,5,4]  R2109     4.4748380780220032e-01
    z[4,5,4]  R2110     -2.1066750586032867e-01
    z[4,5,4]  R2111     -7.4922956526279449e-02
    z[4,5,4]  R2112     -7.5536054372787476e-01
    z[4,5,4]  R2113     -6.1703097820281982e-01
    z[4,5,4]  R2114     -6.2668442726135254e-01
    z[4,5,4]  R2115     -1.8210516870021820e-01
    z[4,5,4]  R2116     1.5481740236282349e-01
    z[4,5,4]  R2117     -1.2296716123819351e-01
    z[4,5,4]  R2118     -1.5764136612415314e-01
    z[4,5,4]  R2119     -4.7570672631263733e-01
    z[4,5,4]  R2120     -2.5523534417152405e-01
    z[4,5,4]  R2121     -3.7932008504867554e-01
    z[4,5,4]  R2122     1.1816792190074921e-01
    z[4,5,4]  R2123     -2.0104572176933289e-01
    z[4,5,4]  R2124     -1.3503420352935791e-01
    z[4,5,4]  R2125     -2.5660410523414612e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R2042     -1
    z[4,5,5]  R2043     1
    z[4,5,5]  R2046     -2.5419354438781738e-01
    z[4,5,5]  R2047     5.5253233760595322e-02
    z[4,5,5]  R2048     -3.6885783076286316e-02
    z[4,5,5]  R2049     -2.2479355335235596e-01
    z[4,5,5]  R2050     -6.6237091086804867e-03
    z[4,5,5]  R2051     -4.9201363325119019e-01
    z[4,5,5]  R2052     -3.0697554349899292e-01
    z[4,5,5]  R2053     -5.5386364459991455e-01
    z[4,5,5]  R2054     0.341463178396225
    z[4,5,5]  R2055     2.4733063578605652e-01
    z[4,5,5]  R2056     -5.3956888616085052e-02
    z[4,5,5]  R2057     -1.4479069411754608e-01
    z[4,5,5]  R2058     2.7465509250760078e-02
    z[4,5,5]  R2059     2.3230038583278656e-02
    z[4,5,5]  R2060     -1.4664037525653839e-01
    z[4,5,5]  R2061     -2.1142846345901489e-01
    z[4,5,5]  R2062     3.5193203948438168e-03
    z[4,5,5]  R2063     -2.8943467140197754e-01
    z[4,5,5]  R2064     1.2393782287836075e-01
    z[4,5,5]  R2065     0.0698886290192604
    z[4,5,5]  R2066     -7.6179319620132446e-01
    z[4,5,5]  R2067     1.6764022409915924e-01
    z[4,5,5]  R2068     5.3217488527297974e-01
    z[4,5,5]  R2069     4.8674359917640686e-01
    z[4,5,5]  R2070     4.7387725114822388e-01
    z[4,5,5]  R2071     2.3500698804855347e-01
    z[4,5,5]  R2072     -4.2441502213478088e-02
    z[4,5,5]  R2073     -3.1275925040245056e-01
    z[4,5,5]  R2074     -1.8474724143743515e-02
    z[4,5,5]  R2075     1.6109757125377655e-01
    z[4,5,5]  R2076     -9.8054654896259308e-02
    z[4,5,5]  R2077     -1.2702740728855133e-01
    z[4,5,5]  R2078     -8.6095677688717842e-03
    z[4,5,5]  R2079     -2.8188601136207581e-01
    z[4,5,5]  R2080     -4.4874340295791626e-02
    z[4,5,5]  R2081     3.7709128856658936e-01
    z[4,5,5]  R2082     -2.0452212542295456e-02
    z[4,5,5]  R2083     1.1788973212242126e-01
    z[4,5,5]  R2084     -6.4595431089401245e-02
    z[4,5,5]  R2085     2.1863219141960144e-01
    z[4,5,5]  R2086     5.1559224724769592e-02
    z[4,5,5]  R2087     2.0553177595138550e-01
    z[4,5,5]  R2088     -1.7279775440692902e-01
    z[4,5,5]  R2089     -1.7816193401813507e-01
    z[4,5,5]  R2090     -8.2208685576915741e-02
    z[4,5,5]  R2091     1.6701954603195190e-01
    z[4,5,5]  R2092     -6.9015175104141235e-02
    z[4,5,5]  R2093     2.7071535587310791e-02
    z[4,5,5]  R2094     1.9414480030536652e-01
    z[4,5,5]  R2095     3.5885747522115707e-02
    z[4,5,5]  R2096     -1.1131719499826431e-01
    z[4,5,5]  R2097     0.0637318417429924
    z[4,5,5]  R2098     -1.4617668092250824e-01
    z[4,5,5]  R2099     -2.9570075869560242e-01
    z[4,5,5]  R2100     7.7944099903106689e-02
    z[4,5,5]  R2101     1.5966452658176422e-01
    z[4,5,5]  R2102     -2.1649017930030823e-01
    z[4,5,5]  R2103     5.2308106422424316e-01
    z[4,5,5]  R2104     -6.2786924839019775e-01
    z[4,5,5]  R2105     3.3755233883857727e-01
    z[4,5,5]  R2106     1.5116794407367706e-01
    z[4,5,5]  R2107     -2.2197867929935455e-01
    z[4,5,5]  R2108     3.1002062559127808e-01
    z[4,5,5]  R2109     3.1327721476554871e-01
    z[4,5,5]  R2110     3.4476521611213684e-01
    z[4,5,5]  R2111     -0.646431565284729
    z[4,5,5]  R2112     -3.1328245997428894e-01
    z[4,5,5]  R2113     3.7758263945579529e-01
    z[4,5,5]  R2114     -1.5430963039398193e-01
    z[4,5,5]  R2115     1.9245516508817673e-02
    z[4,5,5]  R2116     -2.2110524773597717e-01
    z[4,5,5]  R2117     -1.0460570454597473e-01
    z[4,5,5]  R2118     1.8717718124389648e-01
    z[4,5,5]  R2119     -9.5810495316982269e-02
    z[4,5,5]  R2120     2.0536902546882629e-01
    z[4,5,5]  R2121     3.1169801950454712e-01
    z[4,5,5]  R2122     1.9130136817693710e-02
    z[4,5,5]  R2123     0.602180004119873
    z[4,5,5]  R2124     1.8971244990825653e-01
    z[4,5,5]  R2125     -1.2897464632987976e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R2044     -1
    z[4,5,6]  R2045     1
    z[4,5,6]  R2046     -5.9919780492782593e-01
    z[4,5,6]  R2047     6.0451114177703857e-01
    z[4,5,6]  R2048     -4.3199202418327332e-01
    z[4,5,6]  R2049     -1.0879322141408920e-01
    z[4,5,6]  R2050     -0.241790771484375
    z[4,5,6]  R2051     2.7485761046409607e-01
    z[4,5,6]  R2052     -3.1329923868179321e-01
    z[4,5,6]  R2053     4.0665698051452637e-01
    z[4,5,6]  R2054     2.0220498740673065e-01
    z[4,5,6]  R2055     -5.0999283790588379e-02
    z[4,5,6]  R2056     2.9861494898796082e-02
    z[4,5,6]  R2057     5.4020345211029053e-02
    z[4,5,6]  R2058     -2.0257534086704254e-01
    z[4,5,6]  R2059     -1.6104483604431152e-01
    z[4,5,6]  R2060     -1.4829909801483154e-01
    z[4,5,6]  R2061     3.2283014059066772e-01
    z[4,5,6]  R2062     -3.5510218143463135e-01
    z[4,5,6]  R2063     1.5719279646873474e-01
    z[4,5,6]  R2064     2.6076811552047729e-01
    z[4,5,6]  R2065     3.7825204432010651e-02
    z[4,5,6]  R2066     2.9783040285110474e-02
    z[4,5,6]  R2067     -1.9978380203247070e-01
    z[4,5,6]  R2068     9.6700891852378845e-02
    z[4,5,6]  R2069     -6.1911858618259430e-02
    z[4,5,6]  R2070     6.2522336840629578e-02
    z[4,5,6]  R2071     2.1353588998317719e-01
    z[4,5,6]  R2072     -2.8371039032936096e-01
    z[4,5,6]  R2073     1.0625831037759781e-01
    z[4,5,6]  R2074     0.0215000007301569
    z[4,5,6]  R2075     1.2924927473068237e-01
    z[4,5,6]  R2076     -2.9671558737754822e-01
    z[4,5,6]  R2077     1.0736639797687531e-01
    z[4,5,6]  R2078     1.3117294013500214e-01
    z[4,5,6]  R2079     1.6855685412883759e-01
    z[4,5,6]  R2080     0.0594826303422451
    z[4,5,6]  R2081     5.6614372879266739e-03
    z[4,5,6]  R2082     2.8335985541343689e-01
    z[4,5,6]  R2083     1.4543295837938786e-02
    z[4,5,6]  R2084     3.5334545373916626e-01
    z[4,5,6]  R2085     9.2243090271949768e-02
    z[4,5,6]  R2086     1.8549966812133789e-01
    z[4,5,6]  R2087     4.8253691196441650e-01
    z[4,5,6]  R2088     1.7592176795005798e-01
    z[4,5,6]  R2089     4.6619750559329987e-02
    z[4,5,6]  R2090     -3.9099924266338348e-02
    z[4,5,6]  R2091     2.9522067308425903e-01
    z[4,5,6]  R2092     -2.4551825225353241e-01
    z[4,5,6]  R2093     -1.6466338932514191e-01
    z[4,5,6]  R2094     2.1250389516353607e-02
    z[4,5,6]  R2095     -1.3845956325531006e-01
    z[4,5,6]  R2096     1.2127758562564850e-01
    z[4,5,6]  R2097     5.6023085117340088e-01
    z[4,5,6]  R2098     0.349653035402298
    z[4,5,6]  R2099     0.806532084941864
    z[4,5,6]  R2100     5.8506507426500320e-02
    z[4,5,6]  R2101     -3.9483910799026489e-01
    z[4,5,6]  R2102     -0.325979620218277
    z[4,5,6]  R2103     -3.5950893163681030e-01
    z[4,5,6]  R2104     -2.2523787617683411e-01
    z[4,5,6]  R2105     -1.4223001897335052e-01
    z[4,5,6]  R2106     -4.3978440761566162e-01
    z[4,5,6]  R2107     9.6285246312618256e-02
    z[4,5,6]  R2108     3.4382537007331848e-02
    z[4,5,6]  R2109     4.7604967840015888e-03
    z[4,5,6]  R2110     -1.4741019904613495e-01
    z[4,5,6]  R2111     -2.7137833833694458e-01
    z[4,5,6]  R2112     8.8009208440780640e-02
    z[4,5,6]  R2113     3.8328343629837036e-01
    z[4,5,6]  R2114     -4.8739233613014221e-01
    z[4,5,6]  R2115     -3.0698752403259277e-01
    z[4,5,6]  R2116     -4.0437772870063782e-01
    z[4,5,6]  R2117     1.5249388292431831e-02
    z[4,5,6]  R2118     -1.2720832228660583e-01
    z[4,5,6]  R2119     -1.1395805329084396e-01
    z[4,5,6]  R2120     -1.6189830377697945e-02
    z[4,5,6]  R2121     1.4010933041572571e-01
    z[4,5,6]  R2122     2.1948866546154022e-01
    z[4,5,6]  R2123     2.5303825736045837e-01
    z[4,5,6]  R2124     -1.8181873857975006e-01
    z[4,5,6]  R2125     -1.3147367537021637e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R2126     -1
    z[5,4,0]  R2127     1
    z[5,4,0]  R2140     6.5863317251205444e-01
    z[5,4,0]  R2141     3.5136952996253967e-01
    z[5,4,0]  R2142     4.5002645254135132e-01
    z[5,4,0]  R2143     -1.8709459900856018e-01
    z[5,4,0]  R2144     -6.0926965670660138e-04
    z[5,4,0]  R2145     5.3828325122594833e-02
    z[5,4,0]  R2146     -5.7057225704193115e-01
    z[5,4,0]  R2147     -9.6037723124027252e-02
    z[5,4,0]  R2148     -4.0170863270759583e-01
    z[5,4,0]  R2149     -4.4690504670143127e-01
    z[5,4,0]  R2150     2.4390691518783569e-01
    z[5,4,0]  R2151     -1.6205526888370514e-01
    z[5,4,0]  R2152     -4.1034218668937683e-01
    z[5,4,0]  R2153     -0.491395503282547
    z[5,4,0]  R2154     -5.4686480760574341e-01
    z[5,4,0]  R2155     7.1733094751834869e-02
    z[5,4,0]  R2156     3.0037495493888855e-01
    z[5,4,0]  R2157     1.6303683817386627e-01
    z[5,4,0]  R2158     3.2199257612228394e-01
    z[5,4,0]  R2159     5.4086589813232422e-01
    z[5,4,0]  R2160     -9.2967316508293152e-02
    z[5,4,0]  R2161     -8.6629527807235718e-01
    z[5,4,0]  R2162     -8.9378046989440918e-01
    z[5,4,0]  R2163     -6.3994240760803223e-01
    z[5,4,0]  R2164     -7.6945525407791138e-01
    z[5,4,0]  R2165     -6.9138383865356445e-01
    z[5,4,0]  R2166     -3.5067155957221985e-01
    z[5,4,0]  R2167     4.1472426056861877e-01
    z[5,4,0]  R2168     4.9624881148338318e-01
    z[5,4,0]  R2169     5.4533189535140991e-01
    z[5,4,0]  R2170     -2.2881361842155457e-01
    z[5,4,0]  R2171     -2.3070777952671051e-01
    z[5,4,0]  R2172     -5.2906799316406250e-01
    z[5,4,0]  R2173     -0.536858856678009
    z[5,4,0]  R2174     -1.4750261604785919e-01
    z[5,4,0]  R2175     -3.4159582853317261e-01
    z[5,4,0]  R2176     -4.2805242538452148e-01
    z[5,4,0]  R2177     2.6663309335708618e-01
    z[5,4,0]  R2178     -6.7907178401947021e-01
    z[5,4,0]  R2179     -6.7647963762283325e-01
    z[5,4,0]  R2180     2.4160841107368469e-01
    z[5,4,0]  R2181     1.3185410201549530e-01
    z[5,4,0]  R2182     -1.3201734982430935e-02
    z[5,4,0]  R2183     5.5172022432088852e-02
    z[5,4,0]  R2184     -2.2242331877350807e-02
    z[5,4,0]  R2185     7.6204225420951843e-02
    z[5,4,0]  R2186     1.2282416224479675e-01
    z[5,4,0]  R2187     5.5029653012752533e-02
    z[5,4,0]  R2188     1.8619391322135925e-01
    z[5,4,0]  R2189     -7.5316391885280609e-03
    z[5,4,0]  R2190     3.0556654557585716e-02
    z[5,4,0]  R2191     5.3235888481140137e-01
    z[5,4,0]  R2192     5.4403203725814819e-01
    z[5,4,0]  R2193     4.4899505376815796e-01
    z[5,4,0]  R2194     5.0258380174636841e-01
    z[5,4,0]  R2195     6.5266287326812744e-01
    z[5,4,0]  R2196     6.2692219018936157e-01
    z[5,4,0]  R2197     -1.3840657472610474e-01
    z[5,4,0]  R2198     -1.8528200685977936e-01
    z[5,4,0]  R2199     7.7054411172866821e-01
    z[5,4,0]  R2200     4.3017071485519409e-01
    z[5,4,0]  R2201     7.1977972984313965e-02
    z[5,4,0]  R2202     -4.0937475860118866e-02
    z[5,4,0]  R2203     -3.3348676562309265e-01
    z[5,4,0]  R2204     3.5101863741874695e-01
    z[5,4,0]  R2205     -4.0713661909103394e-01
    z[5,4,0]  R2206     7.9137533903121948e-01
    z[5,4,0]  R2207     -0.54306960105896
    z[5,4,0]  R2208     8.4613734483718872e-01
    z[5,4,0]  R2209     -1.7747931182384491e-01
    z[5,4,0]  R2210     2.9744449257850647e-01
    z[5,4,0]  R2211     -3.8600695133209229e-01
    z[5,4,0]  R2212     3.0390096828341484e-02
    z[5,4,0]  R2213     3.7899947166442871e-01
    z[5,4,0]  R2214     -1.3790874183177948e-01
    z[5,4,0]  R2215     1.5185585618019104e-01
    z[5,4,0]  R2216     1.9510146975517273e-01
    z[5,4,0]  R2217     7.7100229263305664e-01
    z[5,4,0]  R2218     1.1139265447854996e-01
    z[5,4,0]  R2219     7.5476515293121338e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R2128     -1
    z[5,4,1]  R2129     1
    z[5,4,1]  R2140     3.5655662417411804e-02
    z[5,4,1]  R2141     -6.8967863917350769e-02
    z[5,4,1]  R2142     3.3862382173538208e-02
    z[5,4,1]  R2143     1.3009256124496460e-01
    z[5,4,1]  R2144     7.6676271855831146e-02
    z[5,4,1]  R2145     1.8855138123035431e-01
    z[5,4,1]  R2146     1.0348648577928543e-01
    z[5,4,1]  R2147     1.7468252778053284e-01
    z[5,4,1]  R2148     4.8111043870449066e-03
    z[5,4,1]  R2149     -5.5101740360260010e-01
    z[5,4,1]  R2150     3.6529025435447693e-01
    z[5,4,1]  R2151     5.0101137161254883e-01
    z[5,4,1]  R2152     2.3997753858566284e-01
    z[5,4,1]  R2153     6.4626473188400269e-01
    z[5,4,1]  R2154     -2.7780082821846008e-01
    z[5,4,1]  R2155     5.2693653106689453e-01
    z[5,4,1]  R2156     2.0449882745742798e-01
    z[5,4,1]  R2157     2.8308564424514771e-01
    z[5,4,1]  R2158     1.5430007874965668e-01
    z[5,4,1]  R2159     -6.8047416210174561e-01
    z[5,4,1]  R2160     7.3471927642822266e-01
    z[5,4,1]  R2161     -3.5882565379142761e-01
    z[5,4,1]  R2162     -1.5928235650062561e-01
    z[5,4,1]  R2163     7.7059499919414520e-02
    z[5,4,1]  R2164     0.0466160774230957
    z[5,4,1]  R2165     -2.1337196230888367e-01
    z[5,4,1]  R2166     -2.3984816670417786e-01
    z[5,4,1]  R2167     3.0023759603500366e-01
    z[5,4,1]  R2168     -7.8539723157882690e-01
    z[5,4,1]  R2169     -6.9796615839004517e-01
    z[5,4,1]  R2170     3.7018606066703796e-01
    z[5,4,1]  R2171     3.2088243961334229e-01
    z[5,4,1]  R2172     -0.0853620320558548
    z[5,4,1]  R2173     0.352740615606308
    z[5,4,1]  R2174     9.3586467206478119e-02
    z[5,4,1]  R2175     3.8938581943511963e-01
    z[5,4,1]  R2176     1.1426846683025360e-01
    z[5,4,1]  R2177     4.3071934580802917e-01
    z[5,4,1]  R2178     4.6511983871459961e-01
    z[5,4,1]  R2179     5.1966643333435059e-01
    z[5,4,1]  R2180     4.5888322591781616e-01
    z[5,4,1]  R2181     -8.3910757303237915e-01
    z[5,4,1]  R2182     -8.6533606052398682e-01
    z[5,4,1]  R2183     -0.856290876865387
    z[5,4,1]  R2184     -0.831427812576294
    z[5,4,1]  R2185     -8.8973259925842285e-01
    z[5,4,1]  R2186     -8.9831674098968506e-01
    z[5,4,1]  R2187     -8.8220846652984619e-01
    z[5,4,1]  R2188     -8.9002692699432373e-01
    z[5,4,1]  R2189     -7.4586510658264160e-01
    z[5,4,1]  R2190     2.2671137750148773e-01
    z[5,4,1]  R2191     5.6912928819656372e-01
    z[5,4,1]  R2192     4.9940598011016846e-01
    z[5,4,1]  R2193     5.0135904550552368e-01
    z[5,4,1]  R2194     4.9811157584190369e-01
    z[5,4,1]  R2195     5.1809805631637573e-01
    z[5,4,1]  R2196     5.7565355300903320e-01
    z[5,4,1]  R2197     4.0577733516693115e-01
    z[5,4,1]  R2198     -8.1414830684661865e-01
    z[5,4,1]  R2199     -2.6228375732898712e-02
    z[5,4,1]  R2200     5.8665776252746582e-01
    z[5,4,1]  R2201     -8.8336187601089478e-01
    z[5,4,1]  R2202     -8.6680001020431519e-01
    z[5,4,1]  R2203     -8.3143043518066406e-01
    z[5,4,1]  R2204     -8.7545108795166016e-01
    z[5,4,1]  R2205     -5.9915989637374878e-01
    z[5,4,1]  R2206     -3.1522031873464584e-02
    z[5,4,1]  R2207     -7.1259617805480957e-01
    z[5,4,1]  R2208     -2.4191428720951080e-01
    z[5,4,1]  R2209     -9.0931630134582520e-01
    z[5,4,1]  R2210     6.7801761627197266e-01
    z[5,4,1]  R2211     -5.3744238615036011e-01
    z[5,4,1]  R2212     5.1924854516983032e-01
    z[5,4,1]  R2213     7.3822093009948730e-01
    z[5,4,1]  R2214     -9.6936339139938354e-01
    z[5,4,1]  R2215     -8.4631758928298950e-01
    z[5,4,1]  R2216     -8.1340706348419189e-01
    z[5,4,1]  R2217     -1.3318565487861633e-01
    z[5,4,1]  R2218     -9.3571096658706665e-01
    z[5,4,1]  R2219     -3.4393274784088135e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R2130     -1
    z[5,4,2]  R2131     1
    z[5,4,2]  R2140     4.9690103530883789e-01
    z[5,4,2]  R2141     5.6668418645858765e-01
    z[5,4,2]  R2142     0.788059413433075
    z[5,4,2]  R2143     4.3211534619331360e-01
    z[5,4,2]  R2144     8.6823272705078125e-01
    z[5,4,2]  R2145     5.7285249233245850e-01
    z[5,4,2]  R2146     -5.4072532802820206e-02
    z[5,4,2]  R2147     -7.0453107357025146e-02
    z[5,4,2]  R2148     -2.5815838575363159e-01
    z[5,4,2]  R2149     2.3707246780395508e-01
    z[5,4,2]  R2150     -3.4773632884025574e-01
    z[5,4,2]  R2151     -4.4258171319961548e-01
    z[5,4,2]  R2152     -2.0929503440856934e-01
    z[5,4,2]  R2153     0.0709293782711029
    z[5,4,2]  R2154     -6.5322893857955933e-01
    z[5,4,2]  R2155     -1.1875462532043457e-01
    z[5,4,2]  R2156     -3.9269593358039856e-01
    z[5,4,2]  R2157     -4.7192507982254028e-01
    z[5,4,2]  R2158     -3.8370156288146973e-01
    z[5,4,2]  R2159     -2.9528501629829407e-01
    z[5,4,2]  R2160     1.4096125960350037e-01
    z[5,4,2]  R2161     -1.0095614194869995e-01
    z[5,4,2]  R2162     1.3848142325878143e-01
    z[5,4,2]  R2163     -3.6666259169578552e-01
    z[5,4,2]  R2164     -3.1680583953857422e-01
    z[5,4,2]  R2165     -0.0551447868347168
    z[5,4,2]  R2166     -4.8404029011726379e-01
    z[5,4,2]  R2167     -3.7091752886772156e-01
    z[5,4,2]  R2168     -1.7900729179382324e-01
    z[5,4,2]  R2169     -1.5813142061233521e-01
    z[5,4,2]  R2170     1.9356827437877655e-01
    z[5,4,2]  R2171     2.4685165286064148e-01
    z[5,4,2]  R2172     6.1206500977277756e-02
    z[5,4,2]  R2173     -2.0180317759513855e-01
    z[5,4,2]  R2174     4.4411984086036682e-01
    z[5,4,2]  R2175     -4.3181997537612915e-01
    z[5,4,2]  R2176     -2.7103242278099060e-01
    z[5,4,2]  R2177     -2.6697742938995361e-01
    z[5,4,2]  R2178     -3.4243506193161011e-01
    z[5,4,2]  R2179     -1.4939494431018829e-01
    z[5,4,2]  R2180     6.4450573921203613e-01
    z[5,4,2]  R2181     1.0331121087074280e-01
    z[5,4,2]  R2182     2.6637923717498779e-01
    z[5,4,2]  R2183     -5.4543375968933105e-02
    z[5,4,2]  R2184     5.0195097923278809e-02
    z[5,4,2]  R2185     6.9693282246589661e-02
    z[5,4,2]  R2186     -3.0473910737782717e-03
    z[5,4,2]  R2187     5.7179573923349380e-03
    z[5,4,2]  R2188     1.1403743177652359e-01
    z[5,4,2]  R2189     1.3642043806612492e-02
    z[5,4,2]  R2190     3.7542662024497986e-01
    z[5,4,2]  R2191     2.8058382868766785e-01
    z[5,4,2]  R2192     1.0063945502042770e-01
    z[5,4,2]  R2193     4.1253137588500977e-01
    z[5,4,2]  R2194     2.2937135398387909e-01
    z[5,4,2]  R2195     -1.9970403984189034e-02
    z[5,4,2]  R2196     -0.0692482516169548
    z[5,4,2]  R2197     5.8593684434890747e-01
    z[5,4,2]  R2198     4.3814271688461304e-01
    z[5,4,2]  R2199     0.30632483959198
    z[5,4,2]  R2200     1.7609870433807373e-01
    z[5,4,2]  R2201     -1.4286562800407410e-01
    z[5,4,2]  R2202     -4.6527005732059479e-02
    z[5,4,2]  R2203     -1.1773762851953506e-01
    z[5,4,2]  R2204     3.0067640542984009e-01
    z[5,4,2]  R2205     -2.5073844194412231e-01
    z[5,4,2]  R2206     0.209524467587471
    z[5,4,2]  R2207     1.4049339806661010e-03
    z[5,4,2]  R2208     1.0268007963895798e-01
    z[5,4,2]  R2209     -2.8969830274581909e-01
    z[5,4,2]  R2210     3.6941519379615784e-01
    z[5,4,2]  R2211     -4.3036320805549622e-01
    z[5,4,2]  R2212     5.8853012323379517e-01
    z[5,4,2]  R2213     4.5391544699668884e-02
    z[5,4,2]  R2214     -2.4259122088551521e-02
    z[5,4,2]  R2215     8.1423148512840271e-02
    z[5,4,2]  R2216     -7.7357396483421326e-02
    z[5,4,2]  R2217     2.0851007103919983e-01
    z[5,4,2]  R2218     -1.8838453292846680e-01
    z[5,4,2]  R2219     2.4028047919273376e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R2132     -1
    z[5,4,3]  R2133     1
    z[5,4,3]  R2140     -5.0862443447113037e-01
    z[5,4,3]  R2141     2.7938507497310638e-02
    z[5,4,3]  R2142     -1.6678662598133087e-01
    z[5,4,3]  R2143     1.1506868898868561e-01
    z[5,4,3]  R2144     -1.8325862288475037e-01
    z[5,4,3]  R2145     6.6361993551254272e-01
    z[5,4,3]  R2146     0.674699068069458
    z[5,4,3]  R2147     4.8612591624259949e-01
    z[5,4,3]  R2148     4.2541259527206421e-01
    z[5,4,3]  R2149     5.2751320600509644e-01
    z[5,4,3]  R2150     -2.3076803982257843e-01
    z[5,4,3]  R2151     -5.7352638244628906e-01
    z[5,4,3]  R2152     -7.9003876447677612e-01
    z[5,4,3]  R2153     -1.9347956776618958e-01
    z[5,4,3]  R2154     1.0992675274610519e-01
    z[5,4,3]  R2155     0.453823983669281
    z[5,4,3]  R2156     -1.9309048354625702e-01
    z[5,4,3]  R2157     1.9135428592562675e-02
    z[5,4,3]  R2158     -2.6681306958198547e-01
    z[5,4,3]  R2159     1.7161494493484497e-01
    z[5,4,3]  R2160     4.4192460179328918e-01
    z[5,4,3]  R2161     0.290324866771698
    z[5,4,3]  R2162     2.8379639983177185e-01
    z[5,4,3]  R2163     4.4903361797332764e-01
    z[5,4,3]  R2164     4.4476497173309326e-01
    z[5,4,3]  R2165     4.6124801039695740e-01
    z[5,4,3]  R2166     7.2298157215118408e-01
    z[5,4,3]  R2167     3.6498349905014038e-01
    z[5,4,3]  R2168     0.132520392537117
    z[5,4,3]  R2169     0.301140159368515
    z[5,4,3]  R2170     5.8835631608963013e-01
    z[5,4,3]  R2171     5.7909131050109863e-01
    z[5,4,3]  R2172     7.1007597446441650e-01
    z[5,4,3]  R2173     5.1912295818328857e-01
    z[5,4,3]  R2174     6.7351454496383667e-01
    z[5,4,3]  R2175     2.3599152266979218e-01
    z[5,4,3]  R2176     1.0072951018810272e-01
    z[5,4,3]  R2177     2.6326471567153931e-01
    z[5,4,3]  R2178     -2.1841265261173248e-01
    z[5,4,3]  R2179     -4.2937964200973511e-01
    z[5,4,3]  R2180     -4.6761611104011536e-01
    z[5,4,3]  R2181     -4.9306672811508179e-01
    z[5,4,3]  R2182     -3.1495910882949829e-01
    z[5,4,3]  R2183     -3.9545559883117676e-01
    z[5,4,3]  R2184     -4.3779936432838440e-01
    z[5,4,3]  R2185     -1.8927714228630066e-01
    z[5,4,3]  R2186     -1.6373868286609650e-01
    z[5,4,3]  R2187     -2.1787050366401672e-01
    z[5,4,3]  R2188     -1.5182100236415863e-01
    z[5,4,3]  R2189     -6.5627634525299072e-01
    z[5,4,3]  R2190     -2.7796211838722229e-01
    z[5,4,3]  R2191     -4.3183439970016479e-01
    z[5,4,3]  R2192     -3.4537440538406372e-01
    z[5,4,3]  R2193     -0.092435322701931
    z[5,4,3]  R2194     -2.7672863006591797e-01
    z[5,4,3]  R2195     -4.0482899546623230e-01
    z[5,4,3]  R2196     -3.9469927549362183e-01
    z[5,4,3]  R2197     -5.2682596445083618e-01
    z[5,4,3]  R2198     -2.8664425015449524e-01
    z[5,4,3]  R2199     -4.9529033899307251e-01
    z[5,4,3]  R2200     -4.2812418937683105e-01
    z[5,4,3]  R2201     -3.9481440186500549e-01
    z[5,4,3]  R2202     -1.8525658547878265e-01
    z[5,4,3]  R2203     -2.7522468566894531e-01
    z[5,4,3]  R2204     0.0848386287689209
    z[5,4,3]  R2205     -4.0217173099517822e-01
    z[5,4,3]  R2206     -4.1430890560150146e-01
    z[5,4,3]  R2207     -3.9949494600296021e-01
    z[5,4,3]  R2208     -2.5498467683792114e-01
    z[5,4,3]  R2209     -3.7392899394035339e-02
    z[5,4,3]  R2210     -3.3119708299636841e-01
    z[5,4,3]  R2211     -2.1668106317520142e-01
    z[5,4,3]  R2212     -5.1878023147583008e-01
    z[5,4,3]  R2213     -5.1609623432159424e-01
    z[5,4,3]  R2214     -9.2928275465965271e-02
    z[5,4,3]  R2215     -3.2332196831703186e-01
    z[5,4,3]  R2216     -4.1578653454780579e-01
    z[5,4,3]  R2217     -5.5670082569122314e-01
    z[5,4,3]  R2218     -8.2895331084728241e-02
    z[5,4,3]  R2219     -1.3179579377174377e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R2134     -1
    z[5,4,4]  R2135     1
    z[5,4,4]  R2140     1.7950442433357239e-01
    z[5,4,4]  R2141     0.481612890958786
    z[5,4,4]  R2142     -6.2043469399213791e-02
    z[5,4,4]  R2143     1.0086730867624283e-01
    z[5,4,4]  R2144     -4.4408363103866577e-01
    z[5,4,4]  R2145     -1.0774364322423935e-01
    z[5,4,4]  R2146     2.2905133664608002e-01
    z[5,4,4]  R2147     5.6224584579467773e-01
    z[5,4,4]  R2148     -3.8214331865310669e-01
    z[5,4,4]  R2149     -1.6736510396003723e-01
    z[5,4,4]  R2150     6.4547348022460938e-01
    z[5,4,4]  R2151     3.7332189083099365e-01
    z[5,4,4]  R2152     9.3645811080932617e-02
    z[5,4,4]  R2153     4.4748380780220032e-01
    z[5,4,4]  R2154     -2.1066750586032867e-01
    z[5,4,4]  R2155     -7.4922956526279449e-02
    z[5,4,4]  R2156     -7.5536054372787476e-01
    z[5,4,4]  R2157     -6.1703097820281982e-01
    z[5,4,4]  R2158     -6.2668442726135254e-01
    z[5,4,4]  R2159     -1.8210516870021820e-01
    z[5,4,4]  R2160     1.5481740236282349e-01
    z[5,4,4]  R2161     -1.2296716123819351e-01
    z[5,4,4]  R2162     -1.5764136612415314e-01
    z[5,4,4]  R2163     -4.7570672631263733e-01
    z[5,4,4]  R2164     -2.5523534417152405e-01
    z[5,4,4]  R2165     -3.7932008504867554e-01
    z[5,4,4]  R2166     1.1816792190074921e-01
    z[5,4,4]  R2167     -2.0104572176933289e-01
    z[5,4,4]  R2168     -1.3503420352935791e-01
    z[5,4,4]  R2169     -2.5660410523414612e-01
    z[5,4,4]  R2170     0.0576406754553318
    z[5,4,4]  R2171     -2.8113916516304016e-01
    z[5,4,4]  R2172     1.2987929582595825e-01
    z[5,4,4]  R2173     4.6343860030174255e-01
    z[5,4,4]  R2174     -0.510013222694397
    z[5,4,4]  R2175     -4.1461598873138428e-01
    z[5,4,4]  R2176     -7.2644233703613281e-01
    z[5,4,4]  R2177     0.361479789018631
    z[5,4,4]  R2178     8.6656715720891953e-03
    z[5,4,4]  R2179     -4.3161340057849884e-02
    z[5,4,4]  R2180     3.0528002977371216e-01
    z[5,4,4]  R2181     2.9022667557001114e-02
    z[5,4,4]  R2182     -1.9766373932361603e-01
    z[5,4,4]  R2183     2.7908211946487427e-01
    z[5,4,4]  R2184     2.6561075448989868e-01
    z[5,4,4]  R2185     1.1386289447546005e-01
    z[5,4,4]  R2186     -1.5815052390098572e-01
    z[5,4,4]  R2187     2.5039520859718323e-01
    z[5,4,4]  R2188     2.3188173770904541e-01
    z[5,4,4]  R2189     -8.0177605152130127e-02
    z[5,4,4]  R2190     3.8502511382102966e-01
    z[5,4,4]  R2191     2.4384586513042450e-01
    z[5,4,4]  R2192     1.8069259822368622e-01
    z[5,4,4]  R2193     3.5716065764427185e-01
    z[5,4,4]  R2194     0.376345157623291
    z[5,4,4]  R2195     -2.0123182237148285e-01
    z[5,4,4]  R2196     -1.8087539076805115e-01
    z[5,4,4]  R2197     -2.9361805319786072e-01
    z[5,4,4]  R2198     1.6702005267143250e-01
    z[5,4,4]  R2199     1.5417100489139557e-01
    z[5,4,4]  R2200     3.9853486418724060e-01
    z[5,4,4]  R2201     -1.0265780985355377e-01
    z[5,4,4]  R2202     -0.439564049243927
    z[5,4,4]  R2203     -5.2966731600463390e-03
    z[5,4,4]  R2204     -8.4944792091846466e-02
    z[5,4,4]  R2205     -3.2924994826316833e-01
    z[5,4,4]  R2206     -2.7652847766876221e-01
    z[5,4,4]  R2207     1.5353962779045105e-01
    z[5,4,4]  R2208     0.144717276096344
    z[5,4,4]  R2209     -3.5749140661209822e-03
    z[5,4,4]  R2210     4.1059872508049011e-01
    z[5,4,4]  R2211     -2.3432014882564545e-01
    z[5,4,4]  R2212     -2.3054113984107971e-01
    z[5,4,4]  R2213     9.5175974071025848e-02
    z[5,4,4]  R2214     1.5428699553012848e-01
    z[5,4,4]  R2215     -1.8565729260444641e-01
    z[5,4,4]  R2216     -2.3748582601547241e-01
    z[5,4,4]  R2217     -8.1103906035423279e-02
    z[5,4,4]  R2218     1.7757375538349152e-01
    z[5,4,4]  R2219     4.6526998281478882e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R2136     -1
    z[5,4,5]  R2137     1
    z[5,4,5]  R2140     -1.1131719499826431e-01
    z[5,4,5]  R2141     0.0637318417429924
    z[5,4,5]  R2142     -1.4617668092250824e-01
    z[5,4,5]  R2143     -2.9570075869560242e-01
    z[5,4,5]  R2144     7.7944099903106689e-02
    z[5,4,5]  R2145     1.5966452658176422e-01
    z[5,4,5]  R2146     -2.1649017930030823e-01
    z[5,4,5]  R2147     5.2308106422424316e-01
    z[5,4,5]  R2148     -6.2786924839019775e-01
    z[5,4,5]  R2149     3.3755233883857727e-01
    z[5,4,5]  R2150     1.5116794407367706e-01
    z[5,4,5]  R2151     -2.2197867929935455e-01
    z[5,4,5]  R2152     3.1002062559127808e-01
    z[5,4,5]  R2153     3.1327721476554871e-01
    z[5,4,5]  R2154     3.4476521611213684e-01
    z[5,4,5]  R2155     -0.646431565284729
    z[5,4,5]  R2156     -3.1328245997428894e-01
    z[5,4,5]  R2157     3.7758263945579529e-01
    z[5,4,5]  R2158     -1.5430963039398193e-01
    z[5,4,5]  R2159     1.9245516508817673e-02
    z[5,4,5]  R2160     -2.2110524773597717e-01
    z[5,4,5]  R2161     -1.0460570454597473e-01
    z[5,4,5]  R2162     1.8717718124389648e-01
    z[5,4,5]  R2163     -9.5810495316982269e-02
    z[5,4,5]  R2164     2.0536902546882629e-01
    z[5,4,5]  R2165     3.1169801950454712e-01
    z[5,4,5]  R2166     1.9130136817693710e-02
    z[5,4,5]  R2167     0.602180004119873
    z[5,4,5]  R2168     1.8971244990825653e-01
    z[5,4,5]  R2169     -1.2897464632987976e-01
    z[5,4,5]  R2170     -2.5419354438781738e-01
    z[5,4,5]  R2171     5.5253233760595322e-02
    z[5,4,5]  R2172     -3.6885783076286316e-02
    z[5,4,5]  R2173     -2.2479355335235596e-01
    z[5,4,5]  R2174     -6.6237091086804867e-03
    z[5,4,5]  R2175     -4.9201363325119019e-01
    z[5,4,5]  R2176     -3.0697554349899292e-01
    z[5,4,5]  R2177     -5.5386364459991455e-01
    z[5,4,5]  R2178     0.341463178396225
    z[5,4,5]  R2179     2.4733063578605652e-01
    z[5,4,5]  R2180     -5.3956888616085052e-02
    z[5,4,5]  R2181     -1.4479069411754608e-01
    z[5,4,5]  R2182     2.7465509250760078e-02
    z[5,4,5]  R2183     2.3230038583278656e-02
    z[5,4,5]  R2184     -1.4664037525653839e-01
    z[5,4,5]  R2185     -2.1142846345901489e-01
    z[5,4,5]  R2186     3.5193203948438168e-03
    z[5,4,5]  R2187     -2.8943467140197754e-01
    z[5,4,5]  R2188     1.2393782287836075e-01
    z[5,4,5]  R2189     0.0698886290192604
    z[5,4,5]  R2190     -7.6179319620132446e-01
    z[5,4,5]  R2191     1.6764022409915924e-01
    z[5,4,5]  R2192     5.3217488527297974e-01
    z[5,4,5]  R2193     4.8674359917640686e-01
    z[5,4,5]  R2194     4.7387725114822388e-01
    z[5,4,5]  R2195     2.3500698804855347e-01
    z[5,4,5]  R2196     -4.2441502213478088e-02
    z[5,4,5]  R2197     -3.1275925040245056e-01
    z[5,4,5]  R2198     -1.8474724143743515e-02
    z[5,4,5]  R2199     1.6109757125377655e-01
    z[5,4,5]  R2200     -9.8054654896259308e-02
    z[5,4,5]  R2201     -1.2702740728855133e-01
    z[5,4,5]  R2202     -8.6095677688717842e-03
    z[5,4,5]  R2203     -2.8188601136207581e-01
    z[5,4,5]  R2204     -4.4874340295791626e-02
    z[5,4,5]  R2205     3.7709128856658936e-01
    z[5,4,5]  R2206     -2.0452212542295456e-02
    z[5,4,5]  R2207     1.1788973212242126e-01
    z[5,4,5]  R2208     -6.4595431089401245e-02
    z[5,4,5]  R2209     2.1863219141960144e-01
    z[5,4,5]  R2210     5.1559224724769592e-02
    z[5,4,5]  R2211     2.0553177595138550e-01
    z[5,4,5]  R2212     -1.7279775440692902e-01
    z[5,4,5]  R2213     -1.7816193401813507e-01
    z[5,4,5]  R2214     -8.2208685576915741e-02
    z[5,4,5]  R2215     1.6701954603195190e-01
    z[5,4,5]  R2216     -6.9015175104141235e-02
    z[5,4,5]  R2217     2.7071535587310791e-02
    z[5,4,5]  R2218     1.9414480030536652e-01
    z[5,4,5]  R2219     3.5885747522115707e-02
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R2138     -1
    z[5,4,6]  R2139     1
    z[5,4,6]  R2140     1.2127758562564850e-01
    z[5,4,6]  R2141     5.6023085117340088e-01
    z[5,4,6]  R2142     0.349653035402298
    z[5,4,6]  R2143     0.806532084941864
    z[5,4,6]  R2144     5.8506507426500320e-02
    z[5,4,6]  R2145     -3.9483910799026489e-01
    z[5,4,6]  R2146     -0.325979620218277
    z[5,4,6]  R2147     -3.5950893163681030e-01
    z[5,4,6]  R2148     -2.2523787617683411e-01
    z[5,4,6]  R2149     -1.4223001897335052e-01
    z[5,4,6]  R2150     -4.3978440761566162e-01
    z[5,4,6]  R2151     9.6285246312618256e-02
    z[5,4,6]  R2152     3.4382537007331848e-02
    z[5,4,6]  R2153     4.7604967840015888e-03
    z[5,4,6]  R2154     -1.4741019904613495e-01
    z[5,4,6]  R2155     -2.7137833833694458e-01
    z[5,4,6]  R2156     8.8009208440780640e-02
    z[5,4,6]  R2157     3.8328343629837036e-01
    z[5,4,6]  R2158     -4.8739233613014221e-01
    z[5,4,6]  R2159     -3.0698752403259277e-01
    z[5,4,6]  R2160     -4.0437772870063782e-01
    z[5,4,6]  R2161     1.5249388292431831e-02
    z[5,4,6]  R2162     -1.2720832228660583e-01
    z[5,4,6]  R2163     -1.1395805329084396e-01
    z[5,4,6]  R2164     -1.6189830377697945e-02
    z[5,4,6]  R2165     1.4010933041572571e-01
    z[5,4,6]  R2166     2.1948866546154022e-01
    z[5,4,6]  R2167     2.5303825736045837e-01
    z[5,4,6]  R2168     -1.8181873857975006e-01
    z[5,4,6]  R2169     -1.3147367537021637e-01
    z[5,4,6]  R2170     -5.9919780492782593e-01
    z[5,4,6]  R2171     6.0451114177703857e-01
    z[5,4,6]  R2172     -4.3199202418327332e-01
    z[5,4,6]  R2173     -1.0879322141408920e-01
    z[5,4,6]  R2174     -0.241790771484375
    z[5,4,6]  R2175     2.7485761046409607e-01
    z[5,4,6]  R2176     -3.1329923868179321e-01
    z[5,4,6]  R2177     4.0665698051452637e-01
    z[5,4,6]  R2178     2.0220498740673065e-01
    z[5,4,6]  R2179     -5.0999283790588379e-02
    z[5,4,6]  R2180     2.9861494898796082e-02
    z[5,4,6]  R2181     5.4020345211029053e-02
    z[5,4,6]  R2182     -2.0257534086704254e-01
    z[5,4,6]  R2183     -1.6104483604431152e-01
    z[5,4,6]  R2184     -1.4829909801483154e-01
    z[5,4,6]  R2185     3.2283014059066772e-01
    z[5,4,6]  R2186     -3.5510218143463135e-01
    z[5,4,6]  R2187     1.5719279646873474e-01
    z[5,4,6]  R2188     2.6076811552047729e-01
    z[5,4,6]  R2189     3.7825204432010651e-02
    z[5,4,6]  R2190     2.9783040285110474e-02
    z[5,4,6]  R2191     -1.9978380203247070e-01
    z[5,4,6]  R2192     9.6700891852378845e-02
    z[5,4,6]  R2193     -6.1911858618259430e-02
    z[5,4,6]  R2194     6.2522336840629578e-02
    z[5,4,6]  R2195     2.1353588998317719e-01
    z[5,4,6]  R2196     -2.8371039032936096e-01
    z[5,4,6]  R2197     1.0625831037759781e-01
    z[5,4,6]  R2198     0.0215000007301569
    z[5,4,6]  R2199     1.2924927473068237e-01
    z[5,4,6]  R2200     -2.9671558737754822e-01
    z[5,4,6]  R2201     1.0736639797687531e-01
    z[5,4,6]  R2202     1.3117294013500214e-01
    z[5,4,6]  R2203     1.6855685412883759e-01
    z[5,4,6]  R2204     0.0594826303422451
    z[5,4,6]  R2205     5.6614372879266739e-03
    z[5,4,6]  R2206     2.8335985541343689e-01
    z[5,4,6]  R2207     1.4543295837938786e-02
    z[5,4,6]  R2208     3.5334545373916626e-01
    z[5,4,6]  R2209     9.2243090271949768e-02
    z[5,4,6]  R2210     1.8549966812133789e-01
    z[5,4,6]  R2211     4.8253691196441650e-01
    z[5,4,6]  R2212     1.7592176795005798e-01
    z[5,4,6]  R2213     4.6619750559329987e-02
    z[5,4,6]  R2214     -3.9099924266338348e-02
    z[5,4,6]  R2215     2.9522067308425903e-01
    z[5,4,6]  R2216     -2.4551825225353241e-01
    z[5,4,6]  R2217     -1.6466338932514191e-01
    z[5,4,6]  R2218     2.1250389516353607e-02
    z[5,4,6]  R2219     -1.3845956325531006e-01
    z[4,6,0]  R38       -1
    z[4,6,0]  R56       1
    z[4,6,0]  R2220     -1
    z[4,6,0]  R2221     1
    z[4,6,0]  R2234     -2.2881361842155457e-01
    z[4,6,0]  R2235     -2.3070777952671051e-01
    z[4,6,0]  R2236     -5.2906799316406250e-01
    z[4,6,0]  R2237     -0.536858856678009
    z[4,6,0]  R2238     -1.4750261604785919e-01
    z[4,6,0]  R2239     -3.4159582853317261e-01
    z[4,6,0]  R2240     -4.2805242538452148e-01
    z[4,6,0]  R2241     2.6663309335708618e-01
    z[4,6,0]  R2242     -6.7907178401947021e-01
    z[4,6,0]  R2243     -6.7647963762283325e-01
    z[4,6,0]  R2244     2.4160841107368469e-01
    z[4,6,0]  R2245     1.3185410201549530e-01
    z[4,6,0]  R2246     -1.3201734982430935e-02
    z[4,6,0]  R2247     5.5172022432088852e-02
    z[4,6,0]  R2248     -2.2242331877350807e-02
    z[4,6,0]  R2249     7.6204225420951843e-02
    z[4,6,0]  R2250     1.2282416224479675e-01
    z[4,6,0]  R2251     5.5029653012752533e-02
    z[4,6,0]  R2252     1.8619391322135925e-01
    z[4,6,0]  R2253     -7.5316391885280609e-03
    z[4,6,0]  R2254     3.0556654557585716e-02
    z[4,6,0]  R2255     5.3235888481140137e-01
    z[4,6,0]  R2256     5.4403203725814819e-01
    z[4,6,0]  R2257     4.4899505376815796e-01
    z[4,6,0]  R2258     5.0258380174636841e-01
    z[4,6,0]  R2259     6.5266287326812744e-01
    z[4,6,0]  R2260     6.2692219018936157e-01
    z[4,6,0]  R2261     -1.3840657472610474e-01
    z[4,6,0]  R2262     -1.8528200685977936e-01
    z[4,6,0]  R2263     7.7054411172866821e-01
    z[4,6,0]  R2264     4.3017071485519409e-01
    z[4,6,0]  R2265     7.1977972984313965e-02
    z[4,6,0]  R2266     -4.0937475860118866e-02
    z[4,6,0]  R2267     -3.3348676562309265e-01
    z[4,6,0]  R2268     3.5101863741874695e-01
    z[4,6,0]  R2269     -4.0713661909103394e-01
    z[4,6,0]  R2270     7.9137533903121948e-01
    z[4,6,0]  R2271     -0.54306960105896
    z[4,6,0]  R2272     8.4613734483718872e-01
    z[4,6,0]  R2273     -1.7747931182384491e-01
    z[4,6,0]  R2274     2.9744449257850647e-01
    z[4,6,0]  R2275     -3.8600695133209229e-01
    z[4,6,0]  R2276     3.0390096828341484e-02
    z[4,6,0]  R2277     3.7899947166442871e-01
    z[4,6,0]  R2278     -1.3790874183177948e-01
    z[4,6,0]  R2279     1.5185585618019104e-01
    z[4,6,0]  R2280     1.9510146975517273e-01
    z[4,6,0]  R2281     7.7100229263305664e-01
    z[4,6,0]  R2282     1.1139265447854996e-01
    z[4,6,0]  R2283     7.5476515293121338e-01
    z[4,6,0]  R2284     -2.4306967854499817e-01
    z[4,6,0]  R2285     2.2307108342647552e-01
    z[4,6,0]  R2286     3.4439027309417725e-01
    z[4,6,0]  R2287     -1.1825361847877502e-01
    z[4,6,0]  R2288     -3.4254449605941772e-01
    z[4,6,0]  R2289     -2.2716903686523438e-01
    z[4,6,0]  R2290     1.6046869754791260e-01
    z[4,6,0]  R2291     2.3380806669592857e-03
    z[4,6,0]  R2292     5.3210145235061646e-01
    z[4,6,0]  R2293     -0.767795979976654
    z[4,6,0]  R2294     -1.9495630264282227e-01
    z[4,6,0]  R2295     1.4105166494846344e-01
    z[4,6,0]  R2296     4.1521412134170532e-01
    z[4,6,0]  R2297     -3.4050655364990234e-01
    z[4,6,0]  R2298     -1.2337133288383484e-01
    z[4,6,0]  R2299     -8.0893546342849731e-02
    z[4,6,0]  R2300     -0.316019743680954
    z[4,6,0]  R2301     -6.1593884229660034e-01
    z[4,6,0]  R2302     3.3860269188880920e-01
    z[4,6,0]  R2303     1.6142678260803223e-01
    z[4,6,1]  R39       -1
    z[4,6,1]  R57       1
    z[4,6,1]  R2222     -1
    z[4,6,1]  R2223     1
    z[4,6,1]  R2234     3.7018606066703796e-01
    z[4,6,1]  R2235     3.2088243961334229e-01
    z[4,6,1]  R2236     -0.0853620320558548
    z[4,6,1]  R2237     0.352740615606308
    z[4,6,1]  R2238     9.3586467206478119e-02
    z[4,6,1]  R2239     3.8938581943511963e-01
    z[4,6,1]  R2240     1.1426846683025360e-01
    z[4,6,1]  R2241     4.3071934580802917e-01
    z[4,6,1]  R2242     4.6511983871459961e-01
    z[4,6,1]  R2243     5.1966643333435059e-01
    z[4,6,1]  R2244     4.5888322591781616e-01
    z[4,6,1]  R2245     -8.3910757303237915e-01
    z[4,6,1]  R2246     -8.6533606052398682e-01
    z[4,6,1]  R2247     -0.856290876865387
    z[4,6,1]  R2248     -0.831427812576294
    z[4,6,1]  R2249     -8.8973259925842285e-01
    z[4,6,1]  R2250     -8.9831674098968506e-01
    z[4,6,1]  R2251     -8.8220846652984619e-01
    z[4,6,1]  R2252     -8.9002692699432373e-01
    z[4,6,1]  R2253     -7.4586510658264160e-01
    z[4,6,1]  R2254     2.2671137750148773e-01
    z[4,6,1]  R2255     5.6912928819656372e-01
    z[4,6,1]  R2256     4.9940598011016846e-01
    z[4,6,1]  R2257     5.0135904550552368e-01
    z[4,6,1]  R2258     4.9811157584190369e-01
    z[4,6,1]  R2259     5.1809805631637573e-01
    z[4,6,1]  R2260     5.7565355300903320e-01
    z[4,6,1]  R2261     4.0577733516693115e-01
    z[4,6,1]  R2262     -8.1414830684661865e-01
    z[4,6,1]  R2263     -2.6228375732898712e-02
    z[4,6,1]  R2264     5.8665776252746582e-01
    z[4,6,1]  R2265     -8.8336187601089478e-01
    z[4,6,1]  R2266     -8.6680001020431519e-01
    z[4,6,1]  R2267     -8.3143043518066406e-01
    z[4,6,1]  R2268     -8.7545108795166016e-01
    z[4,6,1]  R2269     -5.9915989637374878e-01
    z[4,6,1]  R2270     -3.1522031873464584e-02
    z[4,6,1]  R2271     -7.1259617805480957e-01
    z[4,6,1]  R2272     -2.4191428720951080e-01
    z[4,6,1]  R2273     -9.0931630134582520e-01
    z[4,6,1]  R2274     6.7801761627197266e-01
    z[4,6,1]  R2275     -5.3744238615036011e-01
    z[4,6,1]  R2276     5.1924854516983032e-01
    z[4,6,1]  R2277     7.3822093009948730e-01
    z[4,6,1]  R2278     -9.6936339139938354e-01
    z[4,6,1]  R2279     -8.4631758928298950e-01
    z[4,6,1]  R2280     -8.1340706348419189e-01
    z[4,6,1]  R2281     -1.3318565487861633e-01
    z[4,6,1]  R2282     -9.3571096658706665e-01
    z[4,6,1]  R2283     -3.4393274784088135e-01
    z[4,6,1]  R2284     5.9484001249074936e-02
    z[4,6,1]  R2285     0.0543687604367733
    z[4,6,1]  R2286     6.3366413116455078e-02
    z[4,6,1]  R2287     4.9888465553522110e-02
    z[4,6,1]  R2288     2.9684877954423428e-03
    z[4,6,1]  R2289     8.2638889551162720e-02
    z[4,6,1]  R2290     -3.6709473934024572e-03
    z[4,6,1]  R2291     -8.7194317579269409e-01
    z[4,6,1]  R2292     -4.8741912841796875e-01
    z[4,6,1]  R2293     -1.3693065941333771e-01
    z[4,6,1]  R2294     -2.3118425905704498e-01
    z[4,6,1]  R2295     0.755187451839447
    z[4,6,1]  R2296     7.3013103008270264e-01
    z[4,6,1]  R2297     6.6247063875198364e-01
    z[4,6,1]  R2298     4.9459806084632874e-01
    z[4,6,1]  R2299     4.6404811739921570e-01
    z[4,6,1]  R2300     3.1120446324348450e-01
    z[4,6,1]  R2301     3.3675163984298706e-01
    z[4,6,1]  R2302     -8.5062372684478760e-01
    z[4,6,1]  R2303     -8.1816995143890381e-01
    z[4,6,2]  R40       -1
    z[4,6,2]  R58       1
    z[4,6,2]  R2224     -1
    z[4,6,2]  R2225     1
    z[4,6,2]  R2234     1.9356827437877655e-01
    z[4,6,2]  R2235     2.4685165286064148e-01
    z[4,6,2]  R2236     6.1206500977277756e-02
    z[4,6,2]  R2237     -2.0180317759513855e-01
    z[4,6,2]  R2238     4.4411984086036682e-01
    z[4,6,2]  R2239     -4.3181997537612915e-01
    z[4,6,2]  R2240     -2.7103242278099060e-01
    z[4,6,2]  R2241     -2.6697742938995361e-01
    z[4,6,2]  R2242     -3.4243506193161011e-01
    z[4,6,2]  R2243     -1.4939494431018829e-01
    z[4,6,2]  R2244     6.4450573921203613e-01
    z[4,6,2]  R2245     1.0331121087074280e-01
    z[4,6,2]  R2246     2.6637923717498779e-01
    z[4,6,2]  R2247     -5.4543375968933105e-02
    z[4,6,2]  R2248     5.0195097923278809e-02
    z[4,6,2]  R2249     6.9693282246589661e-02
    z[4,6,2]  R2250     -3.0473910737782717e-03
    z[4,6,2]  R2251     5.7179573923349380e-03
    z[4,6,2]  R2252     1.1403743177652359e-01
    z[4,6,2]  R2253     1.3642043806612492e-02
    z[4,6,2]  R2254     3.7542662024497986e-01
    z[4,6,2]  R2255     2.8058382868766785e-01
    z[4,6,2]  R2256     1.0063945502042770e-01
    z[4,6,2]  R2257     4.1253137588500977e-01
    z[4,6,2]  R2258     2.2937135398387909e-01
    z[4,6,2]  R2259     -1.9970403984189034e-02
    z[4,6,2]  R2260     -0.0692482516169548
    z[4,6,2]  R2261     5.8593684434890747e-01
    z[4,6,2]  R2262     4.3814271688461304e-01
    z[4,6,2]  R2263     0.30632483959198
    z[4,6,2]  R2264     1.7609870433807373e-01
    z[4,6,2]  R2265     -1.4286562800407410e-01
    z[4,6,2]  R2266     -4.6527005732059479e-02
    z[4,6,2]  R2267     -1.1773762851953506e-01
    z[4,6,2]  R2268     3.0067640542984009e-01
    z[4,6,2]  R2269     -2.5073844194412231e-01
    z[4,6,2]  R2270     0.209524467587471
    z[4,6,2]  R2271     1.4049339806661010e-03
    z[4,6,2]  R2272     1.0268007963895798e-01
    z[4,6,2]  R2273     -2.8969830274581909e-01
    z[4,6,2]  R2274     3.6941519379615784e-01
    z[4,6,2]  R2275     -4.3036320805549622e-01
    z[4,6,2]  R2276     5.8853012323379517e-01
    z[4,6,2]  R2277     4.5391544699668884e-02
    z[4,6,2]  R2278     -2.4259122088551521e-02
    z[4,6,2]  R2279     8.1423148512840271e-02
    z[4,6,2]  R2280     -7.7357396483421326e-02
    z[4,6,2]  R2281     2.0851007103919983e-01
    z[4,6,2]  R2282     -1.8838453292846680e-01
    z[4,6,2]  R2283     2.4028047919273376e-01
    z[4,6,2]  R2284     9.0363526344299316e-01
    z[4,6,2]  R2285     6.0082674026489258e-01
    z[4,6,2]  R2286     8.2879191637039185e-01
    z[4,6,2]  R2287     0.734775722026825
    z[4,6,2]  R2288     6.4357602596282959e-01
    z[4,6,2]  R2289     1.3082157075405121e-01
    z[4,6,2]  R2290     4.5716318488121033e-01
    z[4,6,2]  R2291     -1.2676886282861233e-02
    z[4,6,2]  R2292     3.1302943825721741e-02
    z[4,6,2]  R2293     -2.5597837567329407e-01
    z[4,6,2]  R2294     -4.6411642432212830e-01
    z[4,6,2]  R2295     -4.1137015819549561e-01
    z[4,6,2]  R2296     -4.1148072481155396e-01
    z[4,6,2]  R2297     -2.4406099319458008e-01
    z[4,6,2]  R2298     -8.6108408868312836e-02
    z[4,6,2]  R2299     2.5306552648544312e-01
    z[4,6,2]  R2300     1.0281375050544739e-01
    z[4,6,2]  R2301     -2.5616028904914856e-01
    z[4,6,2]  R2302     -9.8373480141162872e-02
    z[4,6,2]  R2303     -3.8059923052787781e-01
    z[4,6,3]  R41       -1
    z[4,6,3]  R59       1
    z[4,6,3]  R2226     -1
    z[4,6,3]  R2227     1
    z[4,6,3]  R2234     5.8835631608963013e-01
    z[4,6,3]  R2235     5.7909131050109863e-01
    z[4,6,3]  R2236     7.1007597446441650e-01
    z[4,6,3]  R2237     5.1912295818328857e-01
    z[4,6,3]  R2238     6.7351454496383667e-01
    z[4,6,3]  R2239     2.3599152266979218e-01
    z[4,6,3]  R2240     1.0072951018810272e-01
    z[4,6,3]  R2241     2.6326471567153931e-01
    z[4,6,3]  R2242     -2.1841265261173248e-01
    z[4,6,3]  R2243     -4.2937964200973511e-01
    z[4,6,3]  R2244     -4.6761611104011536e-01
    z[4,6,3]  R2245     -4.9306672811508179e-01
    z[4,6,3]  R2246     -3.1495910882949829e-01
    z[4,6,3]  R2247     -3.9545559883117676e-01
    z[4,6,3]  R2248     -4.3779936432838440e-01
    z[4,6,3]  R2249     -1.8927714228630066e-01
    z[4,6,3]  R2250     -1.6373868286609650e-01
    z[4,6,3]  R2251     -2.1787050366401672e-01
    z[4,6,3]  R2252     -1.5182100236415863e-01
    z[4,6,3]  R2253     -6.5627634525299072e-01
    z[4,6,3]  R2254     -2.7796211838722229e-01
    z[4,6,3]  R2255     -4.3183439970016479e-01
    z[4,6,3]  R2256     -3.4537440538406372e-01
    z[4,6,3]  R2257     -0.092435322701931
    z[4,6,3]  R2258     -2.7672863006591797e-01
    z[4,6,3]  R2259     -4.0482899546623230e-01
    z[4,6,3]  R2260     -3.9469927549362183e-01
    z[4,6,3]  R2261     -5.2682596445083618e-01
    z[4,6,3]  R2262     -2.8664425015449524e-01
    z[4,6,3]  R2263     -4.9529033899307251e-01
    z[4,6,3]  R2264     -4.2812418937683105e-01
    z[4,6,3]  R2265     -3.9481440186500549e-01
    z[4,6,3]  R2266     -1.8525658547878265e-01
    z[4,6,3]  R2267     -2.7522468566894531e-01
    z[4,6,3]  R2268     0.0848386287689209
    z[4,6,3]  R2269     -4.0217173099517822e-01
    z[4,6,3]  R2270     -4.1430890560150146e-01
    z[4,6,3]  R2271     -3.9949494600296021e-01
    z[4,6,3]  R2272     -2.5498467683792114e-01
    z[4,6,3]  R2273     -3.7392899394035339e-02
    z[4,6,3]  R2274     -3.3119708299636841e-01
    z[4,6,3]  R2275     -2.1668106317520142e-01
    z[4,6,3]  R2276     -5.1878023147583008e-01
    z[4,6,3]  R2277     -5.1609623432159424e-01
    z[4,6,3]  R2278     -9.2928275465965271e-02
    z[4,6,3]  R2279     -3.2332196831703186e-01
    z[4,6,3]  R2280     -4.1578653454780579e-01
    z[4,6,3]  R2281     -5.5670082569122314e-01
    z[4,6,3]  R2282     -8.2895331084728241e-02
    z[4,6,3]  R2283     -1.3179579377174377e-01
    z[4,6,3]  R2284     -1.7220060527324677e-01
    z[4,6,3]  R2285     -4.9672982096672058e-01
    z[4,6,3]  R2286     -4.0433195233345032e-01
    z[4,6,3]  R2287     -0.330777645111084
    z[4,6,3]  R2288     -6.6862158477306366e-02
    z[4,6,3]  R2289     -8.7391048669815063e-01
    z[4,6,3]  R2290     4.3200913071632385e-01
    z[4,6,3]  R2291     0.178828626871109
    z[4,6,3]  R2292     3.6172637343406677e-01
    z[4,6,3]  R2293     -5.7961666025221348e-03
    z[4,6,3]  R2294     -1.2184821814298630e-01
    z[4,6,3]  R2295     -4.7170307487249374e-02
    z[4,6,3]  R2296     -3.9499200880527496e-02
    z[4,6,3]  R2297     2.5259786844253540e-01
    z[4,6,3]  R2298     6.0434317588806152e-01
    z[4,6,3]  R2299     5.1674425601959229e-01
    z[4,6,3]  R2300     9.4966374337673187e-02
    z[4,6,3]  R2301     9.8139166831970215e-02
    z[4,6,3]  R2302     3.6098104715347290e-01
    z[4,6,3]  R2303     -1.4106282033026218e-02
    z[4,6,4]  R42       -1
    z[4,6,4]  R60       1
    z[4,6,4]  R2228     -1
    z[4,6,4]  R2229     1
    z[4,6,4]  R2234     0.0576406754553318
    z[4,6,4]  R2235     -2.8113916516304016e-01
    z[4,6,4]  R2236     1.2987929582595825e-01
    z[4,6,4]  R2237     4.6343860030174255e-01
    z[4,6,4]  R2238     -0.510013222694397
    z[4,6,4]  R2239     -4.1461598873138428e-01
    z[4,6,4]  R2240     -7.2644233703613281e-01
    z[4,6,4]  R2241     0.361479789018631
    z[4,6,4]  R2242     8.6656715720891953e-03
    z[4,6,4]  R2243     -4.3161340057849884e-02
    z[4,6,4]  R2244     3.0528002977371216e-01
    z[4,6,4]  R2245     2.9022667557001114e-02
    z[4,6,4]  R2246     -1.9766373932361603e-01
    z[4,6,4]  R2247     2.7908211946487427e-01
    z[4,6,4]  R2248     2.6561075448989868e-01
    z[4,6,4]  R2249     1.1386289447546005e-01
    z[4,6,4]  R2250     -1.5815052390098572e-01
    z[4,6,4]  R2251     2.5039520859718323e-01
    z[4,6,4]  R2252     2.3188173770904541e-01
    z[4,6,4]  R2253     -8.0177605152130127e-02
    z[4,6,4]  R2254     3.8502511382102966e-01
    z[4,6,4]  R2255     2.4384586513042450e-01
    z[4,6,4]  R2256     1.8069259822368622e-01
    z[4,6,4]  R2257     3.5716065764427185e-01
    z[4,6,4]  R2258     0.376345157623291
    z[4,6,4]  R2259     -2.0123182237148285e-01
    z[4,6,4]  R2260     -1.8087539076805115e-01
    z[4,6,4]  R2261     -2.9361805319786072e-01
    z[4,6,4]  R2262     1.6702005267143250e-01
    z[4,6,4]  R2263     1.5417100489139557e-01
    z[4,6,4]  R2264     3.9853486418724060e-01
    z[4,6,4]  R2265     -1.0265780985355377e-01
    z[4,6,4]  R2266     -0.439564049243927
    z[4,6,4]  R2267     -5.2966731600463390e-03
    z[4,6,4]  R2268     -8.4944792091846466e-02
    z[4,6,4]  R2269     -3.2924994826316833e-01
    z[4,6,4]  R2270     -2.7652847766876221e-01
    z[4,6,4]  R2271     1.5353962779045105e-01
    z[4,6,4]  R2272     0.144717276096344
    z[4,6,4]  R2273     -3.5749140661209822e-03
    z[4,6,4]  R2274     4.1059872508049011e-01
    z[4,6,4]  R2275     -2.3432014882564545e-01
    z[4,6,4]  R2276     -2.3054113984107971e-01
    z[4,6,4]  R2277     9.5175974071025848e-02
    z[4,6,4]  R2278     1.5428699553012848e-01
    z[4,6,4]  R2279     -1.8565729260444641e-01
    z[4,6,4]  R2280     -2.3748582601547241e-01
    z[4,6,4]  R2281     -8.1103906035423279e-02
    z[4,6,4]  R2282     1.7757375538349152e-01
    z[4,6,4]  R2283     4.6526998281478882e-01
    z[4,6,4]  R2284     2.1855711936950684e-01
    z[4,6,4]  R2285     3.6860066652297974e-01
    z[4,6,4]  R2286     1.1693480610847473e-01
    z[4,6,4]  R2287     2.8102025389671326e-01
    z[4,6,4]  R2288     5.4940587282180786e-01
    z[4,6,4]  R2289     9.3946486711502075e-02
    z[4,6,4]  R2290     4.8800927400588989e-01
    z[4,6,4]  R2291     -3.2916495203971863e-01
    z[4,6,4]  R2292     -4.6568018198013306e-01
    z[4,6,4]  R2293     -1.6710628569126129e-01
    z[4,6,4]  R2294     1.5868784487247467e-01
    z[4,6,4]  R2295     0.306011825799942
    z[4,6,4]  R2296     -2.2578364610671997e-01
    z[4,6,4]  R2297     -3.1393823027610779e-01
    z[4,6,4]  R2298     -3.7847158312797546e-01
    z[4,6,4]  R2299     -4.5780256390571594e-01
    z[4,6,4]  R2300     -8.1053566932678223e-01
    z[4,6,4]  R2301     -5.7097882032394409e-01
    z[4,6,4]  R2302     -1.1380314081907272e-01
    z[4,6,4]  R2303     -1.3239854574203491e-01
    z[4,6,5]  R43       -1
    z[4,6,5]  R61       1
    z[4,6,5]  R2230     -1
    z[4,6,5]  R2231     1
    z[4,6,5]  R2234     -2.5419354438781738e-01
    z[4,6,5]  R2235     5.5253233760595322e-02
    z[4,6,5]  R2236     -3.6885783076286316e-02
    z[4,6,5]  R2237     -2.2479355335235596e-01
    z[4,6,5]  R2238     -6.6237091086804867e-03
    z[4,6,5]  R2239     -4.9201363325119019e-01
    z[4,6,5]  R2240     -3.0697554349899292e-01
    z[4,6,5]  R2241     -5.5386364459991455e-01
    z[4,6,5]  R2242     0.341463178396225
    z[4,6,5]  R2243     2.4733063578605652e-01
    z[4,6,5]  R2244     -5.3956888616085052e-02
    z[4,6,5]  R2245     -1.4479069411754608e-01
    z[4,6,5]  R2246     2.7465509250760078e-02
    z[4,6,5]  R2247     2.3230038583278656e-02
    z[4,6,5]  R2248     -1.4664037525653839e-01
    z[4,6,5]  R2249     -2.1142846345901489e-01
    z[4,6,5]  R2250     3.5193203948438168e-03
    z[4,6,5]  R2251     -2.8943467140197754e-01
    z[4,6,5]  R2252     1.2393782287836075e-01
    z[4,6,5]  R2253     0.0698886290192604
    z[4,6,5]  R2254     -7.6179319620132446e-01
    z[4,6,5]  R2255     1.6764022409915924e-01
    z[4,6,5]  R2256     5.3217488527297974e-01
    z[4,6,5]  R2257     4.8674359917640686e-01
    z[4,6,5]  R2258     4.7387725114822388e-01
    z[4,6,5]  R2259     2.3500698804855347e-01
    z[4,6,5]  R2260     -4.2441502213478088e-02
    z[4,6,5]  R2261     -3.1275925040245056e-01
    z[4,6,5]  R2262     -1.8474724143743515e-02
    z[4,6,5]  R2263     1.6109757125377655e-01
    z[4,6,5]  R2264     -9.8054654896259308e-02
    z[4,6,5]  R2265     -1.2702740728855133e-01
    z[4,6,5]  R2266     -8.6095677688717842e-03
    z[4,6,5]  R2267     -2.8188601136207581e-01
    z[4,6,5]  R2268     -4.4874340295791626e-02
    z[4,6,5]  R2269     3.7709128856658936e-01
    z[4,6,5]  R2270     -2.0452212542295456e-02
    z[4,6,5]  R2271     1.1788973212242126e-01
    z[4,6,5]  R2272     -6.4595431089401245e-02
    z[4,6,5]  R2273     2.1863219141960144e-01
    z[4,6,5]  R2274     5.1559224724769592e-02
    z[4,6,5]  R2275     2.0553177595138550e-01
    z[4,6,5]  R2276     -1.7279775440692902e-01
    z[4,6,5]  R2277     -1.7816193401813507e-01
    z[4,6,5]  R2278     -8.2208685576915741e-02
    z[4,6,5]  R2279     1.6701954603195190e-01
    z[4,6,5]  R2280     -6.9015175104141235e-02
    z[4,6,5]  R2281     2.7071535587310791e-02
    z[4,6,5]  R2282     1.9414480030536652e-01
    z[4,6,5]  R2283     3.5885747522115707e-02
    z[4,6,5]  R2284     -1.3518853485584259e-01
    z[4,6,5]  R2285     -2.8702250123023987e-01
    z[4,6,5]  R2286     8.6273632943630219e-02
    z[4,6,5]  R2287     -4.5111864805221558e-01
    z[4,6,5]  R2288     4.0043982863426208e-01
    z[4,6,5]  R2289     -2.8760471940040588e-01
    z[4,6,5]  R2290     1.2319029122591019e-01
    z[4,6,5]  R2291     -1.3998635113239288e-01
    z[4,6,5]  R2292     7.2343222796916962e-02
    z[4,6,5]  R2293     -5.0539571791887283e-02
    z[4,6,5]  R2294     -7.9557329416275024e-01
    z[4,6,5]  R2295     -9.9694781005382538e-02
    z[4,6,5]  R2296     0.257186621427536
    z[4,6,5]  R2297     -8.3370454609394073e-02
    z[4,6,5]  R2298     -3.2267215847969055e-01
    z[4,6,5]  R2299     1.8452392518520355e-01
    z[4,6,5]  R2300     3.5069581866264343e-01
    z[4,6,5]  R2301     7.1079894900321960e-02
    z[4,6,5]  R2302     8.4961839020252228e-02
    z[4,6,5]  R2303     3.3967030048370361e-01
    z[4,6,6]  R44       -1
    z[4,6,6]  R62       1
    z[4,6,6]  R2232     -1
    z[4,6,6]  R2233     1
    z[4,6,6]  R2234     -5.9919780492782593e-01
    z[4,6,6]  R2235     6.0451114177703857e-01
    z[4,6,6]  R2236     -4.3199202418327332e-01
    z[4,6,6]  R2237     -1.0879322141408920e-01
    z[4,6,6]  R2238     -0.241790771484375
    z[4,6,6]  R2239     2.7485761046409607e-01
    z[4,6,6]  R2240     -3.1329923868179321e-01
    z[4,6,6]  R2241     4.0665698051452637e-01
    z[4,6,6]  R2242     2.0220498740673065e-01
    z[4,6,6]  R2243     -5.0999283790588379e-02
    z[4,6,6]  R2244     2.9861494898796082e-02
    z[4,6,6]  R2245     5.4020345211029053e-02
    z[4,6,6]  R2246     -2.0257534086704254e-01
    z[4,6,6]  R2247     -1.6104483604431152e-01
    z[4,6,6]  R2248     -1.4829909801483154e-01
    z[4,6,6]  R2249     3.2283014059066772e-01
    z[4,6,6]  R2250     -3.5510218143463135e-01
    z[4,6,6]  R2251     1.5719279646873474e-01
    z[4,6,6]  R2252     2.6076811552047729e-01
    z[4,6,6]  R2253     3.7825204432010651e-02
    z[4,6,6]  R2254     2.9783040285110474e-02
    z[4,6,6]  R2255     -1.9978380203247070e-01
    z[4,6,6]  R2256     9.6700891852378845e-02
    z[4,6,6]  R2257     -6.1911858618259430e-02
    z[4,6,6]  R2258     6.2522336840629578e-02
    z[4,6,6]  R2259     2.1353588998317719e-01
    z[4,6,6]  R2260     -2.8371039032936096e-01
    z[4,6,6]  R2261     1.0625831037759781e-01
    z[4,6,6]  R2262     0.0215000007301569
    z[4,6,6]  R2263     1.2924927473068237e-01
    z[4,6,6]  R2264     -2.9671558737754822e-01
    z[4,6,6]  R2265     1.0736639797687531e-01
    z[4,6,6]  R2266     1.3117294013500214e-01
    z[4,6,6]  R2267     1.6855685412883759e-01
    z[4,6,6]  R2268     0.0594826303422451
    z[4,6,6]  R2269     5.6614372879266739e-03
    z[4,6,6]  R2270     2.8335985541343689e-01
    z[4,6,6]  R2271     1.4543295837938786e-02
    z[4,6,6]  R2272     3.5334545373916626e-01
    z[4,6,6]  R2273     9.2243090271949768e-02
    z[4,6,6]  R2274     1.8549966812133789e-01
    z[4,6,6]  R2275     4.8253691196441650e-01
    z[4,6,6]  R2276     1.7592176795005798e-01
    z[4,6,6]  R2277     4.6619750559329987e-02
    z[4,6,6]  R2278     -3.9099924266338348e-02
    z[4,6,6]  R2279     2.9522067308425903e-01
    z[4,6,6]  R2280     -2.4551825225353241e-01
    z[4,6,6]  R2281     -1.6466338932514191e-01
    z[4,6,6]  R2282     2.1250389516353607e-02
    z[4,6,6]  R2283     -1.3845956325531006e-01
    z[4,6,6]  R2284     1.5851153433322906e-01
    z[4,6,6]  R2285     3.4828382730484009e-01
    z[4,6,6]  R2286     -7.6698742806911469e-02
    z[4,6,6]  R2287     -2.2745883464813232e-01
    z[4,6,6]  R2288     4.2368043214082718e-02
    z[4,6,6]  R2289     -2.6303768157958984e-01
    z[4,6,6]  R2290     5.7033085823059082e-01
    z[4,6,6]  R2291     -2.8217649459838867e-01
    z[4,6,6]  R2292     -3.5408067703247070e-01
    z[4,6,6]  R2293     5.4378491640090942e-01
    z[4,6,6]  R2294     1.4204236865043640e-01
    z[4,6,6]  R2295     3.6710157990455627e-01
    z[4,6,6]  R2296     8.0660529434680939e-02
    z[4,6,6]  R2297     -0.4650898873806
    z[4,6,6]  R2298     3.4662488102912903e-01
    z[4,6,6]  R2299     -4.5101717114448547e-01
    z[4,6,6]  R2300     -0.061142697930336
    z[4,6,6]  R2301     3.1764614582061768e-01
    z[4,6,6]  R2302     -4.0411904454231262e-02
    z[4,6,6]  R2303     1.6303151845932007e-01
    z[6,4,0]  R38       1
    z[6,4,0]  R56       -1
    z[6,4,0]  R2304     -1
    z[6,4,0]  R2305     1
    z[6,4,0]  R2318     -2.4306967854499817e-01
    z[6,4,0]  R2319     2.2307108342647552e-01
    z[6,4,0]  R2320     3.4439027309417725e-01
    z[6,4,0]  R2321     -1.1825361847877502e-01
    z[6,4,0]  R2322     -3.4254449605941772e-01
    z[6,4,0]  R2323     -2.2716903686523438e-01
    z[6,4,0]  R2324     1.6046869754791260e-01
    z[6,4,0]  R2325     2.3380806669592857e-03
    z[6,4,0]  R2326     5.3210145235061646e-01
    z[6,4,0]  R2327     -0.767795979976654
    z[6,4,0]  R2328     -1.9495630264282227e-01
    z[6,4,0]  R2329     1.4105166494846344e-01
    z[6,4,0]  R2330     4.1521412134170532e-01
    z[6,4,0]  R2331     -3.4050655364990234e-01
    z[6,4,0]  R2332     -1.2337133288383484e-01
    z[6,4,0]  R2333     -8.0893546342849731e-02
    z[6,4,0]  R2334     -0.316019743680954
    z[6,4,0]  R2335     -6.1593884229660034e-01
    z[6,4,0]  R2336     3.3860269188880920e-01
    z[6,4,0]  R2337     1.6142678260803223e-01
    z[6,4,0]  R2338     -2.2881361842155457e-01
    z[6,4,0]  R2339     -2.3070777952671051e-01
    z[6,4,0]  R2340     -5.2906799316406250e-01
    z[6,4,0]  R2341     -0.536858856678009
    z[6,4,0]  R2342     -1.4750261604785919e-01
    z[6,4,0]  R2343     -3.4159582853317261e-01
    z[6,4,0]  R2344     -4.2805242538452148e-01
    z[6,4,0]  R2345     2.6663309335708618e-01
    z[6,4,0]  R2346     -6.7907178401947021e-01
    z[6,4,0]  R2347     -6.7647963762283325e-01
    z[6,4,0]  R2348     2.4160841107368469e-01
    z[6,4,0]  R2349     1.3185410201549530e-01
    z[6,4,0]  R2350     -1.3201734982430935e-02
    z[6,4,0]  R2351     5.5172022432088852e-02
    z[6,4,0]  R2352     -2.2242331877350807e-02
    z[6,4,0]  R2353     7.6204225420951843e-02
    z[6,4,0]  R2354     1.2282416224479675e-01
    z[6,4,0]  R2355     5.5029653012752533e-02
    z[6,4,0]  R2356     1.8619391322135925e-01
    z[6,4,0]  R2357     -7.5316391885280609e-03
    z[6,4,0]  R2358     3.0556654557585716e-02
    z[6,4,0]  R2359     5.3235888481140137e-01
    z[6,4,0]  R2360     5.4403203725814819e-01
    z[6,4,0]  R2361     4.4899505376815796e-01
    z[6,4,0]  R2362     5.0258380174636841e-01
    z[6,4,0]  R2363     6.5266287326812744e-01
    z[6,4,0]  R2364     6.2692219018936157e-01
    z[6,4,0]  R2365     -1.3840657472610474e-01
    z[6,4,0]  R2366     -1.8528200685977936e-01
    z[6,4,0]  R2367     7.7054411172866821e-01
    z[6,4,0]  R2368     4.3017071485519409e-01
    z[6,4,0]  R2369     7.1977972984313965e-02
    z[6,4,0]  R2370     -4.0937475860118866e-02
    z[6,4,0]  R2371     -3.3348676562309265e-01
    z[6,4,0]  R2372     3.5101863741874695e-01
    z[6,4,0]  R2373     -4.0713661909103394e-01
    z[6,4,0]  R2374     7.9137533903121948e-01
    z[6,4,0]  R2375     -0.54306960105896
    z[6,4,0]  R2376     8.4613734483718872e-01
    z[6,4,0]  R2377     -1.7747931182384491e-01
    z[6,4,0]  R2378     2.9744449257850647e-01
    z[6,4,0]  R2379     -3.8600695133209229e-01
    z[6,4,0]  R2380     3.0390096828341484e-02
    z[6,4,0]  R2381     3.7899947166442871e-01
    z[6,4,0]  R2382     -1.3790874183177948e-01
    z[6,4,0]  R2383     1.5185585618019104e-01
    z[6,4,0]  R2384     1.9510146975517273e-01
    z[6,4,0]  R2385     7.7100229263305664e-01
    z[6,4,0]  R2386     1.1139265447854996e-01
    z[6,4,0]  R2387     7.5476515293121338e-01
    z[6,4,1]  R39       1
    z[6,4,1]  R57       -1
    z[6,4,1]  R2306     -1
    z[6,4,1]  R2307     1
    z[6,4,1]  R2318     5.9484001249074936e-02
    z[6,4,1]  R2319     0.0543687604367733
    z[6,4,1]  R2320     6.3366413116455078e-02
    z[6,4,1]  R2321     4.9888465553522110e-02
    z[6,4,1]  R2322     2.9684877954423428e-03
    z[6,4,1]  R2323     8.2638889551162720e-02
    z[6,4,1]  R2324     -3.6709473934024572e-03
    z[6,4,1]  R2325     -8.7194317579269409e-01
    z[6,4,1]  R2326     -4.8741912841796875e-01
    z[6,4,1]  R2327     -1.3693065941333771e-01
    z[6,4,1]  R2328     -2.3118425905704498e-01
    z[6,4,1]  R2329     0.755187451839447
    z[6,4,1]  R2330     7.3013103008270264e-01
    z[6,4,1]  R2331     6.6247063875198364e-01
    z[6,4,1]  R2332     4.9459806084632874e-01
    z[6,4,1]  R2333     4.6404811739921570e-01
    z[6,4,1]  R2334     3.1120446324348450e-01
    z[6,4,1]  R2335     3.3675163984298706e-01
    z[6,4,1]  R2336     -8.5062372684478760e-01
    z[6,4,1]  R2337     -8.1816995143890381e-01
    z[6,4,1]  R2338     3.7018606066703796e-01
    z[6,4,1]  R2339     3.2088243961334229e-01
    z[6,4,1]  R2340     -0.0853620320558548
    z[6,4,1]  R2341     0.352740615606308
    z[6,4,1]  R2342     9.3586467206478119e-02
    z[6,4,1]  R2343     3.8938581943511963e-01
    z[6,4,1]  R2344     1.1426846683025360e-01
    z[6,4,1]  R2345     4.3071934580802917e-01
    z[6,4,1]  R2346     4.6511983871459961e-01
    z[6,4,1]  R2347     5.1966643333435059e-01
    z[6,4,1]  R2348     4.5888322591781616e-01
    z[6,4,1]  R2349     -8.3910757303237915e-01
    z[6,4,1]  R2350     -8.6533606052398682e-01
    z[6,4,1]  R2351     -0.856290876865387
    z[6,4,1]  R2352     -0.831427812576294
    z[6,4,1]  R2353     -8.8973259925842285e-01
    z[6,4,1]  R2354     -8.9831674098968506e-01
    z[6,4,1]  R2355     -8.8220846652984619e-01
    z[6,4,1]  R2356     -8.9002692699432373e-01
    z[6,4,1]  R2357     -7.4586510658264160e-01
    z[6,4,1]  R2358     2.2671137750148773e-01
    z[6,4,1]  R2359     5.6912928819656372e-01
    z[6,4,1]  R2360     4.9940598011016846e-01
    z[6,4,1]  R2361     5.0135904550552368e-01
    z[6,4,1]  R2362     4.9811157584190369e-01
    z[6,4,1]  R2363     5.1809805631637573e-01
    z[6,4,1]  R2364     5.7565355300903320e-01
    z[6,4,1]  R2365     4.0577733516693115e-01
    z[6,4,1]  R2366     -8.1414830684661865e-01
    z[6,4,1]  R2367     -2.6228375732898712e-02
    z[6,4,1]  R2368     5.8665776252746582e-01
    z[6,4,1]  R2369     -8.8336187601089478e-01
    z[6,4,1]  R2370     -8.6680001020431519e-01
    z[6,4,1]  R2371     -8.3143043518066406e-01
    z[6,4,1]  R2372     -8.7545108795166016e-01
    z[6,4,1]  R2373     -5.9915989637374878e-01
    z[6,4,1]  R2374     -3.1522031873464584e-02
    z[6,4,1]  R2375     -7.1259617805480957e-01
    z[6,4,1]  R2376     -2.4191428720951080e-01
    z[6,4,1]  R2377     -9.0931630134582520e-01
    z[6,4,1]  R2378     6.7801761627197266e-01
    z[6,4,1]  R2379     -5.3744238615036011e-01
    z[6,4,1]  R2380     5.1924854516983032e-01
    z[6,4,1]  R2381     7.3822093009948730e-01
    z[6,4,1]  R2382     -9.6936339139938354e-01
    z[6,4,1]  R2383     -8.4631758928298950e-01
    z[6,4,1]  R2384     -8.1340706348419189e-01
    z[6,4,1]  R2385     -1.3318565487861633e-01
    z[6,4,1]  R2386     -9.3571096658706665e-01
    z[6,4,1]  R2387     -3.4393274784088135e-01
    z[6,4,2]  R40       1
    z[6,4,2]  R58       -1
    z[6,4,2]  R2308     -1
    z[6,4,2]  R2309     1
    z[6,4,2]  R2318     9.0363526344299316e-01
    z[6,4,2]  R2319     6.0082674026489258e-01
    z[6,4,2]  R2320     8.2879191637039185e-01
    z[6,4,2]  R2321     0.734775722026825
    z[6,4,2]  R2322     6.4357602596282959e-01
    z[6,4,2]  R2323     1.3082157075405121e-01
    z[6,4,2]  R2324     4.5716318488121033e-01
    z[6,4,2]  R2325     -1.2676886282861233e-02
    z[6,4,2]  R2326     3.1302943825721741e-02
    z[6,4,2]  R2327     -2.5597837567329407e-01
    z[6,4,2]  R2328     -4.6411642432212830e-01
    z[6,4,2]  R2329     -4.1137015819549561e-01
    z[6,4,2]  R2330     -4.1148072481155396e-01
    z[6,4,2]  R2331     -2.4406099319458008e-01
    z[6,4,2]  R2332     -8.6108408868312836e-02
    z[6,4,2]  R2333     2.5306552648544312e-01
    z[6,4,2]  R2334     1.0281375050544739e-01
    z[6,4,2]  R2335     -2.5616028904914856e-01
    z[6,4,2]  R2336     -9.8373480141162872e-02
    z[6,4,2]  R2337     -3.8059923052787781e-01
    z[6,4,2]  R2338     1.9356827437877655e-01
    z[6,4,2]  R2339     2.4685165286064148e-01
    z[6,4,2]  R2340     6.1206500977277756e-02
    z[6,4,2]  R2341     -2.0180317759513855e-01
    z[6,4,2]  R2342     4.4411984086036682e-01
    z[6,4,2]  R2343     -4.3181997537612915e-01
    z[6,4,2]  R2344     -2.7103242278099060e-01
    z[6,4,2]  R2345     -2.6697742938995361e-01
    z[6,4,2]  R2346     -3.4243506193161011e-01
    z[6,4,2]  R2347     -1.4939494431018829e-01
    z[6,4,2]  R2348     6.4450573921203613e-01
    z[6,4,2]  R2349     1.0331121087074280e-01
    z[6,4,2]  R2350     2.6637923717498779e-01
    z[6,4,2]  R2351     -5.4543375968933105e-02
    z[6,4,2]  R2352     5.0195097923278809e-02
    z[6,4,2]  R2353     6.9693282246589661e-02
    z[6,4,2]  R2354     -3.0473910737782717e-03
    z[6,4,2]  R2355     5.7179573923349380e-03
    z[6,4,2]  R2356     1.1403743177652359e-01
    z[6,4,2]  R2357     1.3642043806612492e-02
    z[6,4,2]  R2358     3.7542662024497986e-01
    z[6,4,2]  R2359     2.8058382868766785e-01
    z[6,4,2]  R2360     1.0063945502042770e-01
    z[6,4,2]  R2361     4.1253137588500977e-01
    z[6,4,2]  R2362     2.2937135398387909e-01
    z[6,4,2]  R2363     -1.9970403984189034e-02
    z[6,4,2]  R2364     -0.0692482516169548
    z[6,4,2]  R2365     5.8593684434890747e-01
    z[6,4,2]  R2366     4.3814271688461304e-01
    z[6,4,2]  R2367     0.30632483959198
    z[6,4,2]  R2368     1.7609870433807373e-01
    z[6,4,2]  R2369     -1.4286562800407410e-01
    z[6,4,2]  R2370     -4.6527005732059479e-02
    z[6,4,2]  R2371     -1.1773762851953506e-01
    z[6,4,2]  R2372     3.0067640542984009e-01
    z[6,4,2]  R2373     -2.5073844194412231e-01
    z[6,4,2]  R2374     0.209524467587471
    z[6,4,2]  R2375     1.4049339806661010e-03
    z[6,4,2]  R2376     1.0268007963895798e-01
    z[6,4,2]  R2377     -2.8969830274581909e-01
    z[6,4,2]  R2378     3.6941519379615784e-01
    z[6,4,2]  R2379     -4.3036320805549622e-01
    z[6,4,2]  R2380     5.8853012323379517e-01
    z[6,4,2]  R2381     4.5391544699668884e-02
    z[6,4,2]  R2382     -2.4259122088551521e-02
    z[6,4,2]  R2383     8.1423148512840271e-02
    z[6,4,2]  R2384     -7.7357396483421326e-02
    z[6,4,2]  R2385     2.0851007103919983e-01
    z[6,4,2]  R2386     -1.8838453292846680e-01
    z[6,4,2]  R2387     2.4028047919273376e-01
    z[6,4,3]  R41       1
    z[6,4,3]  R59       -1
    z[6,4,3]  R2310     -1
    z[6,4,3]  R2311     1
    z[6,4,3]  R2318     -1.7220060527324677e-01
    z[6,4,3]  R2319     -4.9672982096672058e-01
    z[6,4,3]  R2320     -4.0433195233345032e-01
    z[6,4,3]  R2321     -0.330777645111084
    z[6,4,3]  R2322     -6.6862158477306366e-02
    z[6,4,3]  R2323     -8.7391048669815063e-01
    z[6,4,3]  R2324     4.3200913071632385e-01
    z[6,4,3]  R2325     0.178828626871109
    z[6,4,3]  R2326     3.6172637343406677e-01
    z[6,4,3]  R2327     -5.7961666025221348e-03
    z[6,4,3]  R2328     -1.2184821814298630e-01
    z[6,4,3]  R2329     -4.7170307487249374e-02
    z[6,4,3]  R2330     -3.9499200880527496e-02
    z[6,4,3]  R2331     2.5259786844253540e-01
    z[6,4,3]  R2332     6.0434317588806152e-01
    z[6,4,3]  R2333     5.1674425601959229e-01
    z[6,4,3]  R2334     9.4966374337673187e-02
    z[6,4,3]  R2335     9.8139166831970215e-02
    z[6,4,3]  R2336     3.6098104715347290e-01
    z[6,4,3]  R2337     -1.4106282033026218e-02
    z[6,4,3]  R2338     5.8835631608963013e-01
    z[6,4,3]  R2339     5.7909131050109863e-01
    z[6,4,3]  R2340     7.1007597446441650e-01
    z[6,4,3]  R2341     5.1912295818328857e-01
    z[6,4,3]  R2342     6.7351454496383667e-01
    z[6,4,3]  R2343     2.3599152266979218e-01
    z[6,4,3]  R2344     1.0072951018810272e-01
    z[6,4,3]  R2345     2.6326471567153931e-01
    z[6,4,3]  R2346     -2.1841265261173248e-01
    z[6,4,3]  R2347     -4.2937964200973511e-01
    z[6,4,3]  R2348     -4.6761611104011536e-01
    z[6,4,3]  R2349     -4.9306672811508179e-01
    z[6,4,3]  R2350     -3.1495910882949829e-01
    z[6,4,3]  R2351     -3.9545559883117676e-01
    z[6,4,3]  R2352     -4.3779936432838440e-01
    z[6,4,3]  R2353     -1.8927714228630066e-01
    z[6,4,3]  R2354     -1.6373868286609650e-01
    z[6,4,3]  R2355     -2.1787050366401672e-01
    z[6,4,3]  R2356     -1.5182100236415863e-01
    z[6,4,3]  R2357     -6.5627634525299072e-01
    z[6,4,3]  R2358     -2.7796211838722229e-01
    z[6,4,3]  R2359     -4.3183439970016479e-01
    z[6,4,3]  R2360     -3.4537440538406372e-01
    z[6,4,3]  R2361     -0.092435322701931
    z[6,4,3]  R2362     -2.7672863006591797e-01
    z[6,4,3]  R2363     -4.0482899546623230e-01
    z[6,4,3]  R2364     -3.9469927549362183e-01
    z[6,4,3]  R2365     -5.2682596445083618e-01
    z[6,4,3]  R2366     -2.8664425015449524e-01
    z[6,4,3]  R2367     -4.9529033899307251e-01
    z[6,4,3]  R2368     -4.2812418937683105e-01
    z[6,4,3]  R2369     -3.9481440186500549e-01
    z[6,4,3]  R2370     -1.8525658547878265e-01
    z[6,4,3]  R2371     -2.7522468566894531e-01
    z[6,4,3]  R2372     0.0848386287689209
    z[6,4,3]  R2373     -4.0217173099517822e-01
    z[6,4,3]  R2374     -4.1430890560150146e-01
    z[6,4,3]  R2375     -3.9949494600296021e-01
    z[6,4,3]  R2376     -2.5498467683792114e-01
    z[6,4,3]  R2377     -3.7392899394035339e-02
    z[6,4,3]  R2378     -3.3119708299636841e-01
    z[6,4,3]  R2379     -2.1668106317520142e-01
    z[6,4,3]  R2380     -5.1878023147583008e-01
    z[6,4,3]  R2381     -5.1609623432159424e-01
    z[6,4,3]  R2382     -9.2928275465965271e-02
    z[6,4,3]  R2383     -3.2332196831703186e-01
    z[6,4,3]  R2384     -4.1578653454780579e-01
    z[6,4,3]  R2385     -5.5670082569122314e-01
    z[6,4,3]  R2386     -8.2895331084728241e-02
    z[6,4,3]  R2387     -1.3179579377174377e-01
    z[6,4,4]  R42       1
    z[6,4,4]  R60       -1
    z[6,4,4]  R2312     -1
    z[6,4,4]  R2313     1
    z[6,4,4]  R2318     2.1855711936950684e-01
    z[6,4,4]  R2319     3.6860066652297974e-01
    z[6,4,4]  R2320     1.1693480610847473e-01
    z[6,4,4]  R2321     2.8102025389671326e-01
    z[6,4,4]  R2322     5.4940587282180786e-01
    z[6,4,4]  R2323     9.3946486711502075e-02
    z[6,4,4]  R2324     4.8800927400588989e-01
    z[6,4,4]  R2325     -3.2916495203971863e-01
    z[6,4,4]  R2326     -4.6568018198013306e-01
    z[6,4,4]  R2327     -1.6710628569126129e-01
    z[6,4,4]  R2328     1.5868784487247467e-01
    z[6,4,4]  R2329     0.306011825799942
    z[6,4,4]  R2330     -2.2578364610671997e-01
    z[6,4,4]  R2331     -3.1393823027610779e-01
    z[6,4,4]  R2332     -3.7847158312797546e-01
    z[6,4,4]  R2333     -4.5780256390571594e-01
    z[6,4,4]  R2334     -8.1053566932678223e-01
    z[6,4,4]  R2335     -5.7097882032394409e-01
    z[6,4,4]  R2336     -1.1380314081907272e-01
    z[6,4,4]  R2337     -1.3239854574203491e-01
    z[6,4,4]  R2338     0.0576406754553318
    z[6,4,4]  R2339     -2.8113916516304016e-01
    z[6,4,4]  R2340     1.2987929582595825e-01
    z[6,4,4]  R2341     4.6343860030174255e-01
    z[6,4,4]  R2342     -0.510013222694397
    z[6,4,4]  R2343     -4.1461598873138428e-01
    z[6,4,4]  R2344     -7.2644233703613281e-01
    z[6,4,4]  R2345     0.361479789018631
    z[6,4,4]  R2346     8.6656715720891953e-03
    z[6,4,4]  R2347     -4.3161340057849884e-02
    z[6,4,4]  R2348     3.0528002977371216e-01
    z[6,4,4]  R2349     2.9022667557001114e-02
    z[6,4,4]  R2350     -1.9766373932361603e-01
    z[6,4,4]  R2351     2.7908211946487427e-01
    z[6,4,4]  R2352     2.6561075448989868e-01
    z[6,4,4]  R2353     1.1386289447546005e-01
    z[6,4,4]  R2354     -1.5815052390098572e-01
    z[6,4,4]  R2355     2.5039520859718323e-01
    z[6,4,4]  R2356     2.3188173770904541e-01
    z[6,4,4]  R2357     -8.0177605152130127e-02
    z[6,4,4]  R2358     3.8502511382102966e-01
    z[6,4,4]  R2359     2.4384586513042450e-01
    z[6,4,4]  R2360     1.8069259822368622e-01
    z[6,4,4]  R2361     3.5716065764427185e-01
    z[6,4,4]  R2362     0.376345157623291
    z[6,4,4]  R2363     -2.0123182237148285e-01
    z[6,4,4]  R2364     -1.8087539076805115e-01
    z[6,4,4]  R2365     -2.9361805319786072e-01
    z[6,4,4]  R2366     1.6702005267143250e-01
    z[6,4,4]  R2367     1.5417100489139557e-01
    z[6,4,4]  R2368     3.9853486418724060e-01
    z[6,4,4]  R2369     -1.0265780985355377e-01
    z[6,4,4]  R2370     -0.439564049243927
    z[6,4,4]  R2371     -5.2966731600463390e-03
    z[6,4,4]  R2372     -8.4944792091846466e-02
    z[6,4,4]  R2373     -3.2924994826316833e-01
    z[6,4,4]  R2374     -2.7652847766876221e-01
    z[6,4,4]  R2375     1.5353962779045105e-01
    z[6,4,4]  R2376     0.144717276096344
    z[6,4,4]  R2377     -3.5749140661209822e-03
    z[6,4,4]  R2378     4.1059872508049011e-01
    z[6,4,4]  R2379     -2.3432014882564545e-01
    z[6,4,4]  R2380     -2.3054113984107971e-01
    z[6,4,4]  R2381     9.5175974071025848e-02
    z[6,4,4]  R2382     1.5428699553012848e-01
    z[6,4,4]  R2383     -1.8565729260444641e-01
    z[6,4,4]  R2384     -2.3748582601547241e-01
    z[6,4,4]  R2385     -8.1103906035423279e-02
    z[6,4,4]  R2386     1.7757375538349152e-01
    z[6,4,4]  R2387     4.6526998281478882e-01
    z[6,4,5]  R43       1
    z[6,4,5]  R61       -1
    z[6,4,5]  R2314     -1
    z[6,4,5]  R2315     1
    z[6,4,5]  R2318     -1.3518853485584259e-01
    z[6,4,5]  R2319     -2.8702250123023987e-01
    z[6,4,5]  R2320     8.6273632943630219e-02
    z[6,4,5]  R2321     -4.5111864805221558e-01
    z[6,4,5]  R2322     4.0043982863426208e-01
    z[6,4,5]  R2323     -2.8760471940040588e-01
    z[6,4,5]  R2324     1.2319029122591019e-01
    z[6,4,5]  R2325     -1.3998635113239288e-01
    z[6,4,5]  R2326     7.2343222796916962e-02
    z[6,4,5]  R2327     -5.0539571791887283e-02
    z[6,4,5]  R2328     -7.9557329416275024e-01
    z[6,4,5]  R2329     -9.9694781005382538e-02
    z[6,4,5]  R2330     0.257186621427536
    z[6,4,5]  R2331     -8.3370454609394073e-02
    z[6,4,5]  R2332     -3.2267215847969055e-01
    z[6,4,5]  R2333     1.8452392518520355e-01
    z[6,4,5]  R2334     3.5069581866264343e-01
    z[6,4,5]  R2335     7.1079894900321960e-02
    z[6,4,5]  R2336     8.4961839020252228e-02
    z[6,4,5]  R2337     3.3967030048370361e-01
    z[6,4,5]  R2338     -2.5419354438781738e-01
    z[6,4,5]  R2339     5.5253233760595322e-02
    z[6,4,5]  R2340     -3.6885783076286316e-02
    z[6,4,5]  R2341     -2.2479355335235596e-01
    z[6,4,5]  R2342     -6.6237091086804867e-03
    z[6,4,5]  R2343     -4.9201363325119019e-01
    z[6,4,5]  R2344     -3.0697554349899292e-01
    z[6,4,5]  R2345     -5.5386364459991455e-01
    z[6,4,5]  R2346     0.341463178396225
    z[6,4,5]  R2347     2.4733063578605652e-01
    z[6,4,5]  R2348     -5.3956888616085052e-02
    z[6,4,5]  R2349     -1.4479069411754608e-01
    z[6,4,5]  R2350     2.7465509250760078e-02
    z[6,4,5]  R2351     2.3230038583278656e-02
    z[6,4,5]  R2352     -1.4664037525653839e-01
    z[6,4,5]  R2353     -2.1142846345901489e-01
    z[6,4,5]  R2354     3.5193203948438168e-03
    z[6,4,5]  R2355     -2.8943467140197754e-01
    z[6,4,5]  R2356     1.2393782287836075e-01
    z[6,4,5]  R2357     0.0698886290192604
    z[6,4,5]  R2358     -7.6179319620132446e-01
    z[6,4,5]  R2359     1.6764022409915924e-01
    z[6,4,5]  R2360     5.3217488527297974e-01
    z[6,4,5]  R2361     4.8674359917640686e-01
    z[6,4,5]  R2362     4.7387725114822388e-01
    z[6,4,5]  R2363     2.3500698804855347e-01
    z[6,4,5]  R2364     -4.2441502213478088e-02
    z[6,4,5]  R2365     -3.1275925040245056e-01
    z[6,4,5]  R2366     -1.8474724143743515e-02
    z[6,4,5]  R2367     1.6109757125377655e-01
    z[6,4,5]  R2368     -9.8054654896259308e-02
    z[6,4,5]  R2369     -1.2702740728855133e-01
    z[6,4,5]  R2370     -8.6095677688717842e-03
    z[6,4,5]  R2371     -2.8188601136207581e-01
    z[6,4,5]  R2372     -4.4874340295791626e-02
    z[6,4,5]  R2373     3.7709128856658936e-01
    z[6,4,5]  R2374     -2.0452212542295456e-02
    z[6,4,5]  R2375     1.1788973212242126e-01
    z[6,4,5]  R2376     -6.4595431089401245e-02
    z[6,4,5]  R2377     2.1863219141960144e-01
    z[6,4,5]  R2378     5.1559224724769592e-02
    z[6,4,5]  R2379     2.0553177595138550e-01
    z[6,4,5]  R2380     -1.7279775440692902e-01
    z[6,4,5]  R2381     -1.7816193401813507e-01
    z[6,4,5]  R2382     -8.2208685576915741e-02
    z[6,4,5]  R2383     1.6701954603195190e-01
    z[6,4,5]  R2384     -6.9015175104141235e-02
    z[6,4,5]  R2385     2.7071535587310791e-02
    z[6,4,5]  R2386     1.9414480030536652e-01
    z[6,4,5]  R2387     3.5885747522115707e-02
    z[6,4,6]  R44       1
    z[6,4,6]  R62       -1
    z[6,4,6]  R2316     -1
    z[6,4,6]  R2317     1
    z[6,4,6]  R2318     1.5851153433322906e-01
    z[6,4,6]  R2319     3.4828382730484009e-01
    z[6,4,6]  R2320     -7.6698742806911469e-02
    z[6,4,6]  R2321     -2.2745883464813232e-01
    z[6,4,6]  R2322     4.2368043214082718e-02
    z[6,4,6]  R2323     -2.6303768157958984e-01
    z[6,4,6]  R2324     5.7033085823059082e-01
    z[6,4,6]  R2325     -2.8217649459838867e-01
    z[6,4,6]  R2326     -3.5408067703247070e-01
    z[6,4,6]  R2327     5.4378491640090942e-01
    z[6,4,6]  R2328     1.4204236865043640e-01
    z[6,4,6]  R2329     3.6710157990455627e-01
    z[6,4,6]  R2330     8.0660529434680939e-02
    z[6,4,6]  R2331     -0.4650898873806
    z[6,4,6]  R2332     3.4662488102912903e-01
    z[6,4,6]  R2333     -4.5101717114448547e-01
    z[6,4,6]  R2334     -0.061142697930336
    z[6,4,6]  R2335     3.1764614582061768e-01
    z[6,4,6]  R2336     -4.0411904454231262e-02
    z[6,4,6]  R2337     1.6303151845932007e-01
    z[6,4,6]  R2338     -5.9919780492782593e-01
    z[6,4,6]  R2339     6.0451114177703857e-01
    z[6,4,6]  R2340     -4.3199202418327332e-01
    z[6,4,6]  R2341     -1.0879322141408920e-01
    z[6,4,6]  R2342     -0.241790771484375
    z[6,4,6]  R2343     2.7485761046409607e-01
    z[6,4,6]  R2344     -3.1329923868179321e-01
    z[6,4,6]  R2345     4.0665698051452637e-01
    z[6,4,6]  R2346     2.0220498740673065e-01
    z[6,4,6]  R2347     -5.0999283790588379e-02
    z[6,4,6]  R2348     2.9861494898796082e-02
    z[6,4,6]  R2349     5.4020345211029053e-02
    z[6,4,6]  R2350     -2.0257534086704254e-01
    z[6,4,6]  R2351     -1.6104483604431152e-01
    z[6,4,6]  R2352     -1.4829909801483154e-01
    z[6,4,6]  R2353     3.2283014059066772e-01
    z[6,4,6]  R2354     -3.5510218143463135e-01
    z[6,4,6]  R2355     1.5719279646873474e-01
    z[6,4,6]  R2356     2.6076811552047729e-01
    z[6,4,6]  R2357     3.7825204432010651e-02
    z[6,4,6]  R2358     2.9783040285110474e-02
    z[6,4,6]  R2359     -1.9978380203247070e-01
    z[6,4,6]  R2360     9.6700891852378845e-02
    z[6,4,6]  R2361     -6.1911858618259430e-02
    z[6,4,6]  R2362     6.2522336840629578e-02
    z[6,4,6]  R2363     2.1353588998317719e-01
    z[6,4,6]  R2364     -2.8371039032936096e-01
    z[6,4,6]  R2365     1.0625831037759781e-01
    z[6,4,6]  R2366     0.0215000007301569
    z[6,4,6]  R2367     1.2924927473068237e-01
    z[6,4,6]  R2368     -2.9671558737754822e-01
    z[6,4,6]  R2369     1.0736639797687531e-01
    z[6,4,6]  R2370     1.3117294013500214e-01
    z[6,4,6]  R2371     1.6855685412883759e-01
    z[6,4,6]  R2372     0.0594826303422451
    z[6,4,6]  R2373     5.6614372879266739e-03
    z[6,4,6]  R2374     2.8335985541343689e-01
    z[6,4,6]  R2375     1.4543295837938786e-02
    z[6,4,6]  R2376     3.5334545373916626e-01
    z[6,4,6]  R2377     9.2243090271949768e-02
    z[6,4,6]  R2378     1.8549966812133789e-01
    z[6,4,6]  R2379     4.8253691196441650e-01
    z[6,4,6]  R2380     1.7592176795005798e-01
    z[6,4,6]  R2381     4.6619750559329987e-02
    z[6,4,6]  R2382     -3.9099924266338348e-02
    z[6,4,6]  R2383     2.9522067308425903e-01
    z[6,4,6]  R2384     -2.4551825225353241e-01
    z[6,4,6]  R2385     -1.6466338932514191e-01
    z[6,4,6]  R2386     2.1250389516353607e-02
    z[6,4,6]  R2387     -1.3845956325531006e-01
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R2388     -1
    z[5,6,0]  R2389     1
    z[5,6,0]  R2402     6.5863317251205444e-01
    z[5,6,0]  R2403     3.5136952996253967e-01
    z[5,6,0]  R2404     4.5002645254135132e-01
    z[5,6,0]  R2405     -1.8709459900856018e-01
    z[5,6,0]  R2406     -6.0926965670660138e-04
    z[5,6,0]  R2407     5.3828325122594833e-02
    z[5,6,0]  R2408     -5.7057225704193115e-01
    z[5,6,0]  R2409     -9.6037723124027252e-02
    z[5,6,0]  R2410     -4.0170863270759583e-01
    z[5,6,0]  R2411     -4.4690504670143127e-01
    z[5,6,0]  R2412     2.4390691518783569e-01
    z[5,6,0]  R2413     -1.6205526888370514e-01
    z[5,6,0]  R2414     -4.1034218668937683e-01
    z[5,6,0]  R2415     -0.491395503282547
    z[5,6,0]  R2416     -5.4686480760574341e-01
    z[5,6,0]  R2417     7.1733094751834869e-02
    z[5,6,0]  R2418     3.0037495493888855e-01
    z[5,6,0]  R2419     1.6303683817386627e-01
    z[5,6,0]  R2420     3.2199257612228394e-01
    z[5,6,0]  R2421     5.4086589813232422e-01
    z[5,6,0]  R2422     -9.2967316508293152e-02
    z[5,6,0]  R2423     -8.6629527807235718e-01
    z[5,6,0]  R2424     -8.9378046989440918e-01
    z[5,6,0]  R2425     -6.3994240760803223e-01
    z[5,6,0]  R2426     -7.6945525407791138e-01
    z[5,6,0]  R2427     -6.9138383865356445e-01
    z[5,6,0]  R2428     -3.5067155957221985e-01
    z[5,6,0]  R2429     4.1472426056861877e-01
    z[5,6,0]  R2430     4.9624881148338318e-01
    z[5,6,0]  R2431     5.4533189535140991e-01
    z[5,6,0]  R2432     -2.4306967854499817e-01
    z[5,6,0]  R2433     2.2307108342647552e-01
    z[5,6,0]  R2434     3.4439027309417725e-01
    z[5,6,0]  R2435     -1.1825361847877502e-01
    z[5,6,0]  R2436     -3.4254449605941772e-01
    z[5,6,0]  R2437     -2.2716903686523438e-01
    z[5,6,0]  R2438     1.6046869754791260e-01
    z[5,6,0]  R2439     2.3380806669592857e-03
    z[5,6,0]  R2440     5.3210145235061646e-01
    z[5,6,0]  R2441     -0.767795979976654
    z[5,6,0]  R2442     -1.9495630264282227e-01
    z[5,6,0]  R2443     1.4105166494846344e-01
    z[5,6,0]  R2444     4.1521412134170532e-01
    z[5,6,0]  R2445     -3.4050655364990234e-01
    z[5,6,0]  R2446     -1.2337133288383484e-01
    z[5,6,0]  R2447     -8.0893546342849731e-02
    z[5,6,0]  R2448     -0.316019743680954
    z[5,6,0]  R2449     -6.1593884229660034e-01
    z[5,6,0]  R2450     3.3860269188880920e-01
    z[5,6,0]  R2451     1.6142678260803223e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R2390     -1
    z[5,6,1]  R2391     1
    z[5,6,1]  R2402     3.5655662417411804e-02
    z[5,6,1]  R2403     -6.8967863917350769e-02
    z[5,6,1]  R2404     3.3862382173538208e-02
    z[5,6,1]  R2405     1.3009256124496460e-01
    z[5,6,1]  R2406     7.6676271855831146e-02
    z[5,6,1]  R2407     1.8855138123035431e-01
    z[5,6,1]  R2408     1.0348648577928543e-01
    z[5,6,1]  R2409     1.7468252778053284e-01
    z[5,6,1]  R2410     4.8111043870449066e-03
    z[5,6,1]  R2411     -5.5101740360260010e-01
    z[5,6,1]  R2412     3.6529025435447693e-01
    z[5,6,1]  R2413     5.0101137161254883e-01
    z[5,6,1]  R2414     2.3997753858566284e-01
    z[5,6,1]  R2415     6.4626473188400269e-01
    z[5,6,1]  R2416     -2.7780082821846008e-01
    z[5,6,1]  R2417     5.2693653106689453e-01
    z[5,6,1]  R2418     2.0449882745742798e-01
    z[5,6,1]  R2419     2.8308564424514771e-01
    z[5,6,1]  R2420     1.5430007874965668e-01
    z[5,6,1]  R2421     -6.8047416210174561e-01
    z[5,6,1]  R2422     7.3471927642822266e-01
    z[5,6,1]  R2423     -3.5882565379142761e-01
    z[5,6,1]  R2424     -1.5928235650062561e-01
    z[5,6,1]  R2425     7.7059499919414520e-02
    z[5,6,1]  R2426     0.0466160774230957
    z[5,6,1]  R2427     -2.1337196230888367e-01
    z[5,6,1]  R2428     -2.3984816670417786e-01
    z[5,6,1]  R2429     3.0023759603500366e-01
    z[5,6,1]  R2430     -7.8539723157882690e-01
    z[5,6,1]  R2431     -6.9796615839004517e-01
    z[5,6,1]  R2432     5.9484001249074936e-02
    z[5,6,1]  R2433     0.0543687604367733
    z[5,6,1]  R2434     6.3366413116455078e-02
    z[5,6,1]  R2435     4.9888465553522110e-02
    z[5,6,1]  R2436     2.9684877954423428e-03
    z[5,6,1]  R2437     8.2638889551162720e-02
    z[5,6,1]  R2438     -3.6709473934024572e-03
    z[5,6,1]  R2439     -8.7194317579269409e-01
    z[5,6,1]  R2440     -4.8741912841796875e-01
    z[5,6,1]  R2441     -1.3693065941333771e-01
    z[5,6,1]  R2442     -2.3118425905704498e-01
    z[5,6,1]  R2443     0.755187451839447
    z[5,6,1]  R2444     7.3013103008270264e-01
    z[5,6,1]  R2445     6.6247063875198364e-01
    z[5,6,1]  R2446     4.9459806084632874e-01
    z[5,6,1]  R2447     4.6404811739921570e-01
    z[5,6,1]  R2448     3.1120446324348450e-01
    z[5,6,1]  R2449     3.3675163984298706e-01
    z[5,6,1]  R2450     -8.5062372684478760e-01
    z[5,6,1]  R2451     -8.1816995143890381e-01
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R2392     -1
    z[5,6,2]  R2393     1
    z[5,6,2]  R2402     4.9690103530883789e-01
    z[5,6,2]  R2403     5.6668418645858765e-01
    z[5,6,2]  R2404     0.788059413433075
    z[5,6,2]  R2405     4.3211534619331360e-01
    z[5,6,2]  R2406     8.6823272705078125e-01
    z[5,6,2]  R2407     5.7285249233245850e-01
    z[5,6,2]  R2408     -5.4072532802820206e-02
    z[5,6,2]  R2409     -7.0453107357025146e-02
    z[5,6,2]  R2410     -2.5815838575363159e-01
    z[5,6,2]  R2411     2.3707246780395508e-01
    z[5,6,2]  R2412     -3.4773632884025574e-01
    z[5,6,2]  R2413     -4.4258171319961548e-01
    z[5,6,2]  R2414     -2.0929503440856934e-01
    z[5,6,2]  R2415     0.0709293782711029
    z[5,6,2]  R2416     -6.5322893857955933e-01
    z[5,6,2]  R2417     -1.1875462532043457e-01
    z[5,6,2]  R2418     -3.9269593358039856e-01
    z[5,6,2]  R2419     -4.7192507982254028e-01
    z[5,6,2]  R2420     -3.8370156288146973e-01
    z[5,6,2]  R2421     -2.9528501629829407e-01
    z[5,6,2]  R2422     1.4096125960350037e-01
    z[5,6,2]  R2423     -1.0095614194869995e-01
    z[5,6,2]  R2424     1.3848142325878143e-01
    z[5,6,2]  R2425     -3.6666259169578552e-01
    z[5,6,2]  R2426     -3.1680583953857422e-01
    z[5,6,2]  R2427     -0.0551447868347168
    z[5,6,2]  R2428     -4.8404029011726379e-01
    z[5,6,2]  R2429     -3.7091752886772156e-01
    z[5,6,2]  R2430     -1.7900729179382324e-01
    z[5,6,2]  R2431     -1.5813142061233521e-01
    z[5,6,2]  R2432     9.0363526344299316e-01
    z[5,6,2]  R2433     6.0082674026489258e-01
    z[5,6,2]  R2434     8.2879191637039185e-01
    z[5,6,2]  R2435     0.734775722026825
    z[5,6,2]  R2436     6.4357602596282959e-01
    z[5,6,2]  R2437     1.3082157075405121e-01
    z[5,6,2]  R2438     4.5716318488121033e-01
    z[5,6,2]  R2439     -1.2676886282861233e-02
    z[5,6,2]  R2440     3.1302943825721741e-02
    z[5,6,2]  R2441     -2.5597837567329407e-01
    z[5,6,2]  R2442     -4.6411642432212830e-01
    z[5,6,2]  R2443     -4.1137015819549561e-01
    z[5,6,2]  R2444     -4.1148072481155396e-01
    z[5,6,2]  R2445     -2.4406099319458008e-01
    z[5,6,2]  R2446     -8.6108408868312836e-02
    z[5,6,2]  R2447     2.5306552648544312e-01
    z[5,6,2]  R2448     1.0281375050544739e-01
    z[5,6,2]  R2449     -2.5616028904914856e-01
    z[5,6,2]  R2450     -9.8373480141162872e-02
    z[5,6,2]  R2451     -3.8059923052787781e-01
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R2394     -1
    z[5,6,3]  R2395     1
    z[5,6,3]  R2402     -5.0862443447113037e-01
    z[5,6,3]  R2403     2.7938507497310638e-02
    z[5,6,3]  R2404     -1.6678662598133087e-01
    z[5,6,3]  R2405     1.1506868898868561e-01
    z[5,6,3]  R2406     -1.8325862288475037e-01
    z[5,6,3]  R2407     6.6361993551254272e-01
    z[5,6,3]  R2408     0.674699068069458
    z[5,6,3]  R2409     4.8612591624259949e-01
    z[5,6,3]  R2410     4.2541259527206421e-01
    z[5,6,3]  R2411     5.2751320600509644e-01
    z[5,6,3]  R2412     -2.3076803982257843e-01
    z[5,6,3]  R2413     -5.7352638244628906e-01
    z[5,6,3]  R2414     -7.9003876447677612e-01
    z[5,6,3]  R2415     -1.9347956776618958e-01
    z[5,6,3]  R2416     1.0992675274610519e-01
    z[5,6,3]  R2417     0.453823983669281
    z[5,6,3]  R2418     -1.9309048354625702e-01
    z[5,6,3]  R2419     1.9135428592562675e-02
    z[5,6,3]  R2420     -2.6681306958198547e-01
    z[5,6,3]  R2421     1.7161494493484497e-01
    z[5,6,3]  R2422     4.4192460179328918e-01
    z[5,6,3]  R2423     0.290324866771698
    z[5,6,3]  R2424     2.8379639983177185e-01
    z[5,6,3]  R2425     4.4903361797332764e-01
    z[5,6,3]  R2426     4.4476497173309326e-01
    z[5,6,3]  R2427     4.6124801039695740e-01
    z[5,6,3]  R2428     7.2298157215118408e-01
    z[5,6,3]  R2429     3.6498349905014038e-01
    z[5,6,3]  R2430     0.132520392537117
    z[5,6,3]  R2431     0.301140159368515
    z[5,6,3]  R2432     -1.7220060527324677e-01
    z[5,6,3]  R2433     -4.9672982096672058e-01
    z[5,6,3]  R2434     -4.0433195233345032e-01
    z[5,6,3]  R2435     -0.330777645111084
    z[5,6,3]  R2436     -6.6862158477306366e-02
    z[5,6,3]  R2437     -8.7391048669815063e-01
    z[5,6,3]  R2438     4.3200913071632385e-01
    z[5,6,3]  R2439     0.178828626871109
    z[5,6,3]  R2440     3.6172637343406677e-01
    z[5,6,3]  R2441     -5.7961666025221348e-03
    z[5,6,3]  R2442     -1.2184821814298630e-01
    z[5,6,3]  R2443     -4.7170307487249374e-02
    z[5,6,3]  R2444     -3.9499200880527496e-02
    z[5,6,3]  R2445     2.5259786844253540e-01
    z[5,6,3]  R2446     6.0434317588806152e-01
    z[5,6,3]  R2447     5.1674425601959229e-01
    z[5,6,3]  R2448     9.4966374337673187e-02
    z[5,6,3]  R2449     9.8139166831970215e-02
    z[5,6,3]  R2450     3.6098104715347290e-01
    z[5,6,3]  R2451     -1.4106282033026218e-02
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R2396     -1
    z[5,6,4]  R2397     1
    z[5,6,4]  R2402     1.7950442433357239e-01
    z[5,6,4]  R2403     0.481612890958786
    z[5,6,4]  R2404     -6.2043469399213791e-02
    z[5,6,4]  R2405     1.0086730867624283e-01
    z[5,6,4]  R2406     -4.4408363103866577e-01
    z[5,6,4]  R2407     -1.0774364322423935e-01
    z[5,6,4]  R2408     2.2905133664608002e-01
    z[5,6,4]  R2409     5.6224584579467773e-01
    z[5,6,4]  R2410     -3.8214331865310669e-01
    z[5,6,4]  R2411     -1.6736510396003723e-01
    z[5,6,4]  R2412     6.4547348022460938e-01
    z[5,6,4]  R2413     3.7332189083099365e-01
    z[5,6,4]  R2414     9.3645811080932617e-02
    z[5,6,4]  R2415     4.4748380780220032e-01
    z[5,6,4]  R2416     -2.1066750586032867e-01
    z[5,6,4]  R2417     -7.4922956526279449e-02
    z[5,6,4]  R2418     -7.5536054372787476e-01
    z[5,6,4]  R2419     -6.1703097820281982e-01
    z[5,6,4]  R2420     -6.2668442726135254e-01
    z[5,6,4]  R2421     -1.8210516870021820e-01
    z[5,6,4]  R2422     1.5481740236282349e-01
    z[5,6,4]  R2423     -1.2296716123819351e-01
    z[5,6,4]  R2424     -1.5764136612415314e-01
    z[5,6,4]  R2425     -4.7570672631263733e-01
    z[5,6,4]  R2426     -2.5523534417152405e-01
    z[5,6,4]  R2427     -3.7932008504867554e-01
    z[5,6,4]  R2428     1.1816792190074921e-01
    z[5,6,4]  R2429     -2.0104572176933289e-01
    z[5,6,4]  R2430     -1.3503420352935791e-01
    z[5,6,4]  R2431     -2.5660410523414612e-01
    z[5,6,4]  R2432     2.1855711936950684e-01
    z[5,6,4]  R2433     3.6860066652297974e-01
    z[5,6,4]  R2434     1.1693480610847473e-01
    z[5,6,4]  R2435     2.8102025389671326e-01
    z[5,6,4]  R2436     5.4940587282180786e-01
    z[5,6,4]  R2437     9.3946486711502075e-02
    z[5,6,4]  R2438     4.8800927400588989e-01
    z[5,6,4]  R2439     -3.2916495203971863e-01
    z[5,6,4]  R2440     -4.6568018198013306e-01
    z[5,6,4]  R2441     -1.6710628569126129e-01
    z[5,6,4]  R2442     1.5868784487247467e-01
    z[5,6,4]  R2443     0.306011825799942
    z[5,6,4]  R2444     -2.2578364610671997e-01
    z[5,6,4]  R2445     -3.1393823027610779e-01
    z[5,6,4]  R2446     -3.7847158312797546e-01
    z[5,6,4]  R2447     -4.5780256390571594e-01
    z[5,6,4]  R2448     -8.1053566932678223e-01
    z[5,6,4]  R2449     -5.7097882032394409e-01
    z[5,6,4]  R2450     -1.1380314081907272e-01
    z[5,6,4]  R2451     -1.3239854574203491e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R2398     -1
    z[5,6,5]  R2399     1
    z[5,6,5]  R2402     -1.1131719499826431e-01
    z[5,6,5]  R2403     0.0637318417429924
    z[5,6,5]  R2404     -1.4617668092250824e-01
    z[5,6,5]  R2405     -2.9570075869560242e-01
    z[5,6,5]  R2406     7.7944099903106689e-02
    z[5,6,5]  R2407     1.5966452658176422e-01
    z[5,6,5]  R2408     -2.1649017930030823e-01
    z[5,6,5]  R2409     5.2308106422424316e-01
    z[5,6,5]  R2410     -6.2786924839019775e-01
    z[5,6,5]  R2411     3.3755233883857727e-01
    z[5,6,5]  R2412     1.5116794407367706e-01
    z[5,6,5]  R2413     -2.2197867929935455e-01
    z[5,6,5]  R2414     3.1002062559127808e-01
    z[5,6,5]  R2415     3.1327721476554871e-01
    z[5,6,5]  R2416     3.4476521611213684e-01
    z[5,6,5]  R2417     -0.646431565284729
    z[5,6,5]  R2418     -3.1328245997428894e-01
    z[5,6,5]  R2419     3.7758263945579529e-01
    z[5,6,5]  R2420     -1.5430963039398193e-01
    z[5,6,5]  R2421     1.9245516508817673e-02
    z[5,6,5]  R2422     -2.2110524773597717e-01
    z[5,6,5]  R2423     -1.0460570454597473e-01
    z[5,6,5]  R2424     1.8717718124389648e-01
    z[5,6,5]  R2425     -9.5810495316982269e-02
    z[5,6,5]  R2426     2.0536902546882629e-01
    z[5,6,5]  R2427     3.1169801950454712e-01
    z[5,6,5]  R2428     1.9130136817693710e-02
    z[5,6,5]  R2429     0.602180004119873
    z[5,6,5]  R2430     1.8971244990825653e-01
    z[5,6,5]  R2431     -1.2897464632987976e-01
    z[5,6,5]  R2432     -1.3518853485584259e-01
    z[5,6,5]  R2433     -2.8702250123023987e-01
    z[5,6,5]  R2434     8.6273632943630219e-02
    z[5,6,5]  R2435     -4.5111864805221558e-01
    z[5,6,5]  R2436     4.0043982863426208e-01
    z[5,6,5]  R2437     -2.8760471940040588e-01
    z[5,6,5]  R2438     1.2319029122591019e-01
    z[5,6,5]  R2439     -1.3998635113239288e-01
    z[5,6,5]  R2440     7.2343222796916962e-02
    z[5,6,5]  R2441     -5.0539571791887283e-02
    z[5,6,5]  R2442     -7.9557329416275024e-01
    z[5,6,5]  R2443     -9.9694781005382538e-02
    z[5,6,5]  R2444     0.257186621427536
    z[5,6,5]  R2445     -8.3370454609394073e-02
    z[5,6,5]  R2446     -3.2267215847969055e-01
    z[5,6,5]  R2447     1.8452392518520355e-01
    z[5,6,5]  R2448     3.5069581866264343e-01
    z[5,6,5]  R2449     7.1079894900321960e-02
    z[5,6,5]  R2450     8.4961839020252228e-02
    z[5,6,5]  R2451     3.3967030048370361e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R2400     -1
    z[5,6,6]  R2401     1
    z[5,6,6]  R2402     1.2127758562564850e-01
    z[5,6,6]  R2403     5.6023085117340088e-01
    z[5,6,6]  R2404     0.349653035402298
    z[5,6,6]  R2405     0.806532084941864
    z[5,6,6]  R2406     5.8506507426500320e-02
    z[5,6,6]  R2407     -3.9483910799026489e-01
    z[5,6,6]  R2408     -0.325979620218277
    z[5,6,6]  R2409     -3.5950893163681030e-01
    z[5,6,6]  R2410     -2.2523787617683411e-01
    z[5,6,6]  R2411     -1.4223001897335052e-01
    z[5,6,6]  R2412     -4.3978440761566162e-01
    z[5,6,6]  R2413     9.6285246312618256e-02
    z[5,6,6]  R2414     3.4382537007331848e-02
    z[5,6,6]  R2415     4.7604967840015888e-03
    z[5,6,6]  R2416     -1.4741019904613495e-01
    z[5,6,6]  R2417     -2.7137833833694458e-01
    z[5,6,6]  R2418     8.8009208440780640e-02
    z[5,6,6]  R2419     3.8328343629837036e-01
    z[5,6,6]  R2420     -4.8739233613014221e-01
    z[5,6,6]  R2421     -3.0698752403259277e-01
    z[5,6,6]  R2422     -4.0437772870063782e-01
    z[5,6,6]  R2423     1.5249388292431831e-02
    z[5,6,6]  R2424     -1.2720832228660583e-01
    z[5,6,6]  R2425     -1.1395805329084396e-01
    z[5,6,6]  R2426     -1.6189830377697945e-02
    z[5,6,6]  R2427     1.4010933041572571e-01
    z[5,6,6]  R2428     2.1948866546154022e-01
    z[5,6,6]  R2429     2.5303825736045837e-01
    z[5,6,6]  R2430     -1.8181873857975006e-01
    z[5,6,6]  R2431     -1.3147367537021637e-01
    z[5,6,6]  R2432     1.5851153433322906e-01
    z[5,6,6]  R2433     3.4828382730484009e-01
    z[5,6,6]  R2434     -7.6698742806911469e-02
    z[5,6,6]  R2435     -2.2745883464813232e-01
    z[5,6,6]  R2436     4.2368043214082718e-02
    z[5,6,6]  R2437     -2.6303768157958984e-01
    z[5,6,6]  R2438     5.7033085823059082e-01
    z[5,6,6]  R2439     -2.8217649459838867e-01
    z[5,6,6]  R2440     -3.5408067703247070e-01
    z[5,6,6]  R2441     5.4378491640090942e-01
    z[5,6,6]  R2442     1.4204236865043640e-01
    z[5,6,6]  R2443     3.6710157990455627e-01
    z[5,6,6]  R2444     8.0660529434680939e-02
    z[5,6,6]  R2445     -0.4650898873806
    z[5,6,6]  R2446     3.4662488102912903e-01
    z[5,6,6]  R2447     -4.5101717114448547e-01
    z[5,6,6]  R2448     -0.061142697930336
    z[5,6,6]  R2449     3.1764614582061768e-01
    z[5,6,6]  R2450     -4.0411904454231262e-02
    z[5,6,6]  R2451     1.6303151845932007e-01
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2452     -1
    z[6,5,0]  R2453     1
    z[6,5,0]  R2466     -2.4306967854499817e-01
    z[6,5,0]  R2467     2.2307108342647552e-01
    z[6,5,0]  R2468     3.4439027309417725e-01
    z[6,5,0]  R2469     -1.1825361847877502e-01
    z[6,5,0]  R2470     -3.4254449605941772e-01
    z[6,5,0]  R2471     -2.2716903686523438e-01
    z[6,5,0]  R2472     1.6046869754791260e-01
    z[6,5,0]  R2473     2.3380806669592857e-03
    z[6,5,0]  R2474     5.3210145235061646e-01
    z[6,5,0]  R2475     -0.767795979976654
    z[6,5,0]  R2476     -1.9495630264282227e-01
    z[6,5,0]  R2477     1.4105166494846344e-01
    z[6,5,0]  R2478     4.1521412134170532e-01
    z[6,5,0]  R2479     -3.4050655364990234e-01
    z[6,5,0]  R2480     -1.2337133288383484e-01
    z[6,5,0]  R2481     -8.0893546342849731e-02
    z[6,5,0]  R2482     -0.316019743680954
    z[6,5,0]  R2483     -6.1593884229660034e-01
    z[6,5,0]  R2484     3.3860269188880920e-01
    z[6,5,0]  R2485     1.6142678260803223e-01
    z[6,5,0]  R2486     6.5863317251205444e-01
    z[6,5,0]  R2487     3.5136952996253967e-01
    z[6,5,0]  R2488     4.5002645254135132e-01
    z[6,5,0]  R2489     -1.8709459900856018e-01
    z[6,5,0]  R2490     -6.0926965670660138e-04
    z[6,5,0]  R2491     5.3828325122594833e-02
    z[6,5,0]  R2492     -5.7057225704193115e-01
    z[6,5,0]  R2493     -9.6037723124027252e-02
    z[6,5,0]  R2494     -4.0170863270759583e-01
    z[6,5,0]  R2495     -4.4690504670143127e-01
    z[6,5,0]  R2496     2.4390691518783569e-01
    z[6,5,0]  R2497     -1.6205526888370514e-01
    z[6,5,0]  R2498     -4.1034218668937683e-01
    z[6,5,0]  R2499     -0.491395503282547
    z[6,5,0]  R2500     -5.4686480760574341e-01
    z[6,5,0]  R2501     7.1733094751834869e-02
    z[6,5,0]  R2502     3.0037495493888855e-01
    z[6,5,0]  R2503     1.6303683817386627e-01
    z[6,5,0]  R2504     3.2199257612228394e-01
    z[6,5,0]  R2505     5.4086589813232422e-01
    z[6,5,0]  R2506     -9.2967316508293152e-02
    z[6,5,0]  R2507     -8.6629527807235718e-01
    z[6,5,0]  R2508     -8.9378046989440918e-01
    z[6,5,0]  R2509     -6.3994240760803223e-01
    z[6,5,0]  R2510     -7.6945525407791138e-01
    z[6,5,0]  R2511     -6.9138383865356445e-01
    z[6,5,0]  R2512     -3.5067155957221985e-01
    z[6,5,0]  R2513     4.1472426056861877e-01
    z[6,5,0]  R2514     4.9624881148338318e-01
    z[6,5,0]  R2515     5.4533189535140991e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2454     -1
    z[6,5,1]  R2455     1
    z[6,5,1]  R2466     5.9484001249074936e-02
    z[6,5,1]  R2467     0.0543687604367733
    z[6,5,1]  R2468     6.3366413116455078e-02
    z[6,5,1]  R2469     4.9888465553522110e-02
    z[6,5,1]  R2470     2.9684877954423428e-03
    z[6,5,1]  R2471     8.2638889551162720e-02
    z[6,5,1]  R2472     -3.6709473934024572e-03
    z[6,5,1]  R2473     -8.7194317579269409e-01
    z[6,5,1]  R2474     -4.8741912841796875e-01
    z[6,5,1]  R2475     -1.3693065941333771e-01
    z[6,5,1]  R2476     -2.3118425905704498e-01
    z[6,5,1]  R2477     0.755187451839447
    z[6,5,1]  R2478     7.3013103008270264e-01
    z[6,5,1]  R2479     6.6247063875198364e-01
    z[6,5,1]  R2480     4.9459806084632874e-01
    z[6,5,1]  R2481     4.6404811739921570e-01
    z[6,5,1]  R2482     3.1120446324348450e-01
    z[6,5,1]  R2483     3.3675163984298706e-01
    z[6,5,1]  R2484     -8.5062372684478760e-01
    z[6,5,1]  R2485     -8.1816995143890381e-01
    z[6,5,1]  R2486     3.5655662417411804e-02
    z[6,5,1]  R2487     -6.8967863917350769e-02
    z[6,5,1]  R2488     3.3862382173538208e-02
    z[6,5,1]  R2489     1.3009256124496460e-01
    z[6,5,1]  R2490     7.6676271855831146e-02
    z[6,5,1]  R2491     1.8855138123035431e-01
    z[6,5,1]  R2492     1.0348648577928543e-01
    z[6,5,1]  R2493     1.7468252778053284e-01
    z[6,5,1]  R2494     4.8111043870449066e-03
    z[6,5,1]  R2495     -5.5101740360260010e-01
    z[6,5,1]  R2496     3.6529025435447693e-01
    z[6,5,1]  R2497     5.0101137161254883e-01
    z[6,5,1]  R2498     2.3997753858566284e-01
    z[6,5,1]  R2499     6.4626473188400269e-01
    z[6,5,1]  R2500     -2.7780082821846008e-01
    z[6,5,1]  R2501     5.2693653106689453e-01
    z[6,5,1]  R2502     2.0449882745742798e-01
    z[6,5,1]  R2503     2.8308564424514771e-01
    z[6,5,1]  R2504     1.5430007874965668e-01
    z[6,5,1]  R2505     -6.8047416210174561e-01
    z[6,5,1]  R2506     7.3471927642822266e-01
    z[6,5,1]  R2507     -3.5882565379142761e-01
    z[6,5,1]  R2508     -1.5928235650062561e-01
    z[6,5,1]  R2509     7.7059499919414520e-02
    z[6,5,1]  R2510     0.0466160774230957
    z[6,5,1]  R2511     -2.1337196230888367e-01
    z[6,5,1]  R2512     -2.3984816670417786e-01
    z[6,5,1]  R2513     3.0023759603500366e-01
    z[6,5,1]  R2514     -7.8539723157882690e-01
    z[6,5,1]  R2515     -6.9796615839004517e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2456     -1
    z[6,5,2]  R2457     1
    z[6,5,2]  R2466     9.0363526344299316e-01
    z[6,5,2]  R2467     6.0082674026489258e-01
    z[6,5,2]  R2468     8.2879191637039185e-01
    z[6,5,2]  R2469     0.734775722026825
    z[6,5,2]  R2470     6.4357602596282959e-01
    z[6,5,2]  R2471     1.3082157075405121e-01
    z[6,5,2]  R2472     4.5716318488121033e-01
    z[6,5,2]  R2473     -1.2676886282861233e-02
    z[6,5,2]  R2474     3.1302943825721741e-02
    z[6,5,2]  R2475     -2.5597837567329407e-01
    z[6,5,2]  R2476     -4.6411642432212830e-01
    z[6,5,2]  R2477     -4.1137015819549561e-01
    z[6,5,2]  R2478     -4.1148072481155396e-01
    z[6,5,2]  R2479     -2.4406099319458008e-01
    z[6,5,2]  R2480     -8.6108408868312836e-02
    z[6,5,2]  R2481     2.5306552648544312e-01
    z[6,5,2]  R2482     1.0281375050544739e-01
    z[6,5,2]  R2483     -2.5616028904914856e-01
    z[6,5,2]  R2484     -9.8373480141162872e-02
    z[6,5,2]  R2485     -3.8059923052787781e-01
    z[6,5,2]  R2486     4.9690103530883789e-01
    z[6,5,2]  R2487     5.6668418645858765e-01
    z[6,5,2]  R2488     0.788059413433075
    z[6,5,2]  R2489     4.3211534619331360e-01
    z[6,5,2]  R2490     8.6823272705078125e-01
    z[6,5,2]  R2491     5.7285249233245850e-01
    z[6,5,2]  R2492     -5.4072532802820206e-02
    z[6,5,2]  R2493     -7.0453107357025146e-02
    z[6,5,2]  R2494     -2.5815838575363159e-01
    z[6,5,2]  R2495     2.3707246780395508e-01
    z[6,5,2]  R2496     -3.4773632884025574e-01
    z[6,5,2]  R2497     -4.4258171319961548e-01
    z[6,5,2]  R2498     -2.0929503440856934e-01
    z[6,5,2]  R2499     0.0709293782711029
    z[6,5,2]  R2500     -6.5322893857955933e-01
    z[6,5,2]  R2501     -1.1875462532043457e-01
    z[6,5,2]  R2502     -3.9269593358039856e-01
    z[6,5,2]  R2503     -4.7192507982254028e-01
    z[6,5,2]  R2504     -3.8370156288146973e-01
    z[6,5,2]  R2505     -2.9528501629829407e-01
    z[6,5,2]  R2506     1.4096125960350037e-01
    z[6,5,2]  R2507     -1.0095614194869995e-01
    z[6,5,2]  R2508     1.3848142325878143e-01
    z[6,5,2]  R2509     -3.6666259169578552e-01
    z[6,5,2]  R2510     -3.1680583953857422e-01
    z[6,5,2]  R2511     -0.0551447868347168
    z[6,5,2]  R2512     -4.8404029011726379e-01
    z[6,5,2]  R2513     -3.7091752886772156e-01
    z[6,5,2]  R2514     -1.7900729179382324e-01
    z[6,5,2]  R2515     -1.5813142061233521e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2458     -1
    z[6,5,3]  R2459     1
    z[6,5,3]  R2466     -1.7220060527324677e-01
    z[6,5,3]  R2467     -4.9672982096672058e-01
    z[6,5,3]  R2468     -4.0433195233345032e-01
    z[6,5,3]  R2469     -0.330777645111084
    z[6,5,3]  R2470     -6.6862158477306366e-02
    z[6,5,3]  R2471     -8.7391048669815063e-01
    z[6,5,3]  R2472     4.3200913071632385e-01
    z[6,5,3]  R2473     0.178828626871109
    z[6,5,3]  R2474     3.6172637343406677e-01
    z[6,5,3]  R2475     -5.7961666025221348e-03
    z[6,5,3]  R2476     -1.2184821814298630e-01
    z[6,5,3]  R2477     -4.7170307487249374e-02
    z[6,5,3]  R2478     -3.9499200880527496e-02
    z[6,5,3]  R2479     2.5259786844253540e-01
    z[6,5,3]  R2480     6.0434317588806152e-01
    z[6,5,3]  R2481     5.1674425601959229e-01
    z[6,5,3]  R2482     9.4966374337673187e-02
    z[6,5,3]  R2483     9.8139166831970215e-02
    z[6,5,3]  R2484     3.6098104715347290e-01
    z[6,5,3]  R2485     -1.4106282033026218e-02
    z[6,5,3]  R2486     -5.0862443447113037e-01
    z[6,5,3]  R2487     2.7938507497310638e-02
    z[6,5,3]  R2488     -1.6678662598133087e-01
    z[6,5,3]  R2489     1.1506868898868561e-01
    z[6,5,3]  R2490     -1.8325862288475037e-01
    z[6,5,3]  R2491     6.6361993551254272e-01
    z[6,5,3]  R2492     0.674699068069458
    z[6,5,3]  R2493     4.8612591624259949e-01
    z[6,5,3]  R2494     4.2541259527206421e-01
    z[6,5,3]  R2495     5.2751320600509644e-01
    z[6,5,3]  R2496     -2.3076803982257843e-01
    z[6,5,3]  R2497     -5.7352638244628906e-01
    z[6,5,3]  R2498     -7.9003876447677612e-01
    z[6,5,3]  R2499     -1.9347956776618958e-01
    z[6,5,3]  R2500     1.0992675274610519e-01
    z[6,5,3]  R2501     0.453823983669281
    z[6,5,3]  R2502     -1.9309048354625702e-01
    z[6,5,3]  R2503     1.9135428592562675e-02
    z[6,5,3]  R2504     -2.6681306958198547e-01
    z[6,5,3]  R2505     1.7161494493484497e-01
    z[6,5,3]  R2506     4.4192460179328918e-01
    z[6,5,3]  R2507     0.290324866771698
    z[6,5,3]  R2508     2.8379639983177185e-01
    z[6,5,3]  R2509     4.4903361797332764e-01
    z[6,5,3]  R2510     4.4476497173309326e-01
    z[6,5,3]  R2511     4.6124801039695740e-01
    z[6,5,3]  R2512     7.2298157215118408e-01
    z[6,5,3]  R2513     3.6498349905014038e-01
    z[6,5,3]  R2514     0.132520392537117
    z[6,5,3]  R2515     0.301140159368515
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2460     -1
    z[6,5,4]  R2461     1
    z[6,5,4]  R2466     2.1855711936950684e-01
    z[6,5,4]  R2467     3.6860066652297974e-01
    z[6,5,4]  R2468     1.1693480610847473e-01
    z[6,5,4]  R2469     2.8102025389671326e-01
    z[6,5,4]  R2470     5.4940587282180786e-01
    z[6,5,4]  R2471     9.3946486711502075e-02
    z[6,5,4]  R2472     4.8800927400588989e-01
    z[6,5,4]  R2473     -3.2916495203971863e-01
    z[6,5,4]  R2474     -4.6568018198013306e-01
    z[6,5,4]  R2475     -1.6710628569126129e-01
    z[6,5,4]  R2476     1.5868784487247467e-01
    z[6,5,4]  R2477     0.306011825799942
    z[6,5,4]  R2478     -2.2578364610671997e-01
    z[6,5,4]  R2479     -3.1393823027610779e-01
    z[6,5,4]  R2480     -3.7847158312797546e-01
    z[6,5,4]  R2481     -4.5780256390571594e-01
    z[6,5,4]  R2482     -8.1053566932678223e-01
    z[6,5,4]  R2483     -5.7097882032394409e-01
    z[6,5,4]  R2484     -1.1380314081907272e-01
    z[6,5,4]  R2485     -1.3239854574203491e-01
    z[6,5,4]  R2486     1.7950442433357239e-01
    z[6,5,4]  R2487     0.481612890958786
    z[6,5,4]  R2488     -6.2043469399213791e-02
    z[6,5,4]  R2489     1.0086730867624283e-01
    z[6,5,4]  R2490     -4.4408363103866577e-01
    z[6,5,4]  R2491     -1.0774364322423935e-01
    z[6,5,4]  R2492     2.2905133664608002e-01
    z[6,5,4]  R2493     5.6224584579467773e-01
    z[6,5,4]  R2494     -3.8214331865310669e-01
    z[6,5,4]  R2495     -1.6736510396003723e-01
    z[6,5,4]  R2496     6.4547348022460938e-01
    z[6,5,4]  R2497     3.7332189083099365e-01
    z[6,5,4]  R2498     9.3645811080932617e-02
    z[6,5,4]  R2499     4.4748380780220032e-01
    z[6,5,4]  R2500     -2.1066750586032867e-01
    z[6,5,4]  R2501     -7.4922956526279449e-02
    z[6,5,4]  R2502     -7.5536054372787476e-01
    z[6,5,4]  R2503     -6.1703097820281982e-01
    z[6,5,4]  R2504     -6.2668442726135254e-01
    z[6,5,4]  R2505     -1.8210516870021820e-01
    z[6,5,4]  R2506     1.5481740236282349e-01
    z[6,5,4]  R2507     -1.2296716123819351e-01
    z[6,5,4]  R2508     -1.5764136612415314e-01
    z[6,5,4]  R2509     -4.7570672631263733e-01
    z[6,5,4]  R2510     -2.5523534417152405e-01
    z[6,5,4]  R2511     -3.7932008504867554e-01
    z[6,5,4]  R2512     1.1816792190074921e-01
    z[6,5,4]  R2513     -2.0104572176933289e-01
    z[6,5,4]  R2514     -1.3503420352935791e-01
    z[6,5,4]  R2515     -2.5660410523414612e-01
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2462     -1
    z[6,5,5]  R2463     1
    z[6,5,5]  R2466     -1.3518853485584259e-01
    z[6,5,5]  R2467     -2.8702250123023987e-01
    z[6,5,5]  R2468     8.6273632943630219e-02
    z[6,5,5]  R2469     -4.5111864805221558e-01
    z[6,5,5]  R2470     4.0043982863426208e-01
    z[6,5,5]  R2471     -2.8760471940040588e-01
    z[6,5,5]  R2472     1.2319029122591019e-01
    z[6,5,5]  R2473     -1.3998635113239288e-01
    z[6,5,5]  R2474     7.2343222796916962e-02
    z[6,5,5]  R2475     -5.0539571791887283e-02
    z[6,5,5]  R2476     -7.9557329416275024e-01
    z[6,5,5]  R2477     -9.9694781005382538e-02
    z[6,5,5]  R2478     0.257186621427536
    z[6,5,5]  R2479     -8.3370454609394073e-02
    z[6,5,5]  R2480     -3.2267215847969055e-01
    z[6,5,5]  R2481     1.8452392518520355e-01
    z[6,5,5]  R2482     3.5069581866264343e-01
    z[6,5,5]  R2483     7.1079894900321960e-02
    z[6,5,5]  R2484     8.4961839020252228e-02
    z[6,5,5]  R2485     3.3967030048370361e-01
    z[6,5,5]  R2486     -1.1131719499826431e-01
    z[6,5,5]  R2487     0.0637318417429924
    z[6,5,5]  R2488     -1.4617668092250824e-01
    z[6,5,5]  R2489     -2.9570075869560242e-01
    z[6,5,5]  R2490     7.7944099903106689e-02
    z[6,5,5]  R2491     1.5966452658176422e-01
    z[6,5,5]  R2492     -2.1649017930030823e-01
    z[6,5,5]  R2493     5.2308106422424316e-01
    z[6,5,5]  R2494     -6.2786924839019775e-01
    z[6,5,5]  R2495     3.3755233883857727e-01
    z[6,5,5]  R2496     1.5116794407367706e-01
    z[6,5,5]  R2497     -2.2197867929935455e-01
    z[6,5,5]  R2498     3.1002062559127808e-01
    z[6,5,5]  R2499     3.1327721476554871e-01
    z[6,5,5]  R2500     3.4476521611213684e-01
    z[6,5,5]  R2501     -0.646431565284729
    z[6,5,5]  R2502     -3.1328245997428894e-01
    z[6,5,5]  R2503     3.7758263945579529e-01
    z[6,5,5]  R2504     -1.5430963039398193e-01
    z[6,5,5]  R2505     1.9245516508817673e-02
    z[6,5,5]  R2506     -2.2110524773597717e-01
    z[6,5,5]  R2507     -1.0460570454597473e-01
    z[6,5,5]  R2508     1.8717718124389648e-01
    z[6,5,5]  R2509     -9.5810495316982269e-02
    z[6,5,5]  R2510     2.0536902546882629e-01
    z[6,5,5]  R2511     3.1169801950454712e-01
    z[6,5,5]  R2512     1.9130136817693710e-02
    z[6,5,5]  R2513     0.602180004119873
    z[6,5,5]  R2514     1.8971244990825653e-01
    z[6,5,5]  R2515     -1.2897464632987976e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2464     -1
    z[6,5,6]  R2465     1
    z[6,5,6]  R2466     1.5851153433322906e-01
    z[6,5,6]  R2467     3.4828382730484009e-01
    z[6,5,6]  R2468     -7.6698742806911469e-02
    z[6,5,6]  R2469     -2.2745883464813232e-01
    z[6,5,6]  R2470     4.2368043214082718e-02
    z[6,5,6]  R2471     -2.6303768157958984e-01
    z[6,5,6]  R2472     5.7033085823059082e-01
    z[6,5,6]  R2473     -2.8217649459838867e-01
    z[6,5,6]  R2474     -3.5408067703247070e-01
    z[6,5,6]  R2475     5.4378491640090942e-01
    z[6,5,6]  R2476     1.4204236865043640e-01
    z[6,5,6]  R2477     3.6710157990455627e-01
    z[6,5,6]  R2478     8.0660529434680939e-02
    z[6,5,6]  R2479     -0.4650898873806
    z[6,5,6]  R2480     3.4662488102912903e-01
    z[6,5,6]  R2481     -4.5101717114448547e-01
    z[6,5,6]  R2482     -0.061142697930336
    z[6,5,6]  R2483     3.1764614582061768e-01
    z[6,5,6]  R2484     -4.0411904454231262e-02
    z[6,5,6]  R2485     1.6303151845932007e-01
    z[6,5,6]  R2486     1.2127758562564850e-01
    z[6,5,6]  R2487     5.6023085117340088e-01
    z[6,5,6]  R2488     0.349653035402298
    z[6,5,6]  R2489     0.806532084941864
    z[6,5,6]  R2490     5.8506507426500320e-02
    z[6,5,6]  R2491     -3.9483910799026489e-01
    z[6,5,6]  R2492     -0.325979620218277
    z[6,5,6]  R2493     -3.5950893163681030e-01
    z[6,5,6]  R2494     -2.2523787617683411e-01
    z[6,5,6]  R2495     -1.4223001897335052e-01
    z[6,5,6]  R2496     -4.3978440761566162e-01
    z[6,5,6]  R2497     9.6285246312618256e-02
    z[6,5,6]  R2498     3.4382537007331848e-02
    z[6,5,6]  R2499     4.7604967840015888e-03
    z[6,5,6]  R2500     -1.4741019904613495e-01
    z[6,5,6]  R2501     -2.7137833833694458e-01
    z[6,5,6]  R2502     8.8009208440780640e-02
    z[6,5,6]  R2503     3.8328343629837036e-01
    z[6,5,6]  R2504     -4.8739233613014221e-01
    z[6,5,6]  R2505     -3.0698752403259277e-01
    z[6,5,6]  R2506     -4.0437772870063782e-01
    z[6,5,6]  R2507     1.5249388292431831e-02
    z[6,5,6]  R2508     -1.2720832228660583e-01
    z[6,5,6]  R2509     -1.1395805329084396e-01
    z[6,5,6]  R2510     -1.6189830377697945e-02
    z[6,5,6]  R2511     1.4010933041572571e-01
    z[6,5,6]  R2512     2.1948866546154022e-01
    z[6,5,6]  R2513     2.5303825736045837e-01
    z[6,5,6]  R2514     -1.8181873857975006e-01
    z[6,5,6]  R2515     -1.3147367537021637e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R63       1
    RHS1      R64       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,3]
 BV BND1      phi[3,0]
 BV BND1      phi[7,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,4]
 BV BND1      phi[4,1]
 BV BND1      phi[1,5]
 BV BND1      phi[5,1]
 BV BND1      phi[1,6]
 BV BND1      phi[6,1]
 BV BND1      phi[2,4]
 BV BND1      phi[4,2]
 BV BND1      phi[2,5]
 BV BND1      phi[5,2]
 BV BND1      phi[2,6]
 BV BND1      phi[6,2]
 BV BND1      phi[2,8]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[7,3]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[4,6]
 BV BND1      phi[6,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,8]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,3,0]
 FR BND1      z[0,3,1]
 FR BND1      z[0,3,2]
 FR BND1      z[0,3,3]
 FR BND1      z[0,3,4]
 FR BND1      z[0,3,5]
 FR BND1      z[0,3,6]
 FR BND1      z[3,0,0]
 FR BND1      z[3,0,1]
 FR BND1      z[3,0,2]
 FR BND1      z[3,0,3]
 FR BND1      z[3,0,4]
 FR BND1      z[3,0,5]
 FR BND1      z[3,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,4,0]
 FR BND1      z[1,4,1]
 FR BND1      z[1,4,2]
 FR BND1      z[1,4,3]
 FR BND1      z[1,4,4]
 FR BND1      z[1,4,5]
 FR BND1      z[1,4,6]
 FR BND1      z[4,1,0]
 FR BND1      z[4,1,1]
 FR BND1      z[4,1,2]
 FR BND1      z[4,1,3]
 FR BND1      z[4,1,4]
 FR BND1      z[4,1,5]
 FR BND1      z[4,1,6]
 FR BND1      z[1,5,0]
 FR BND1      z[1,5,1]
 FR BND1      z[1,5,2]
 FR BND1      z[1,5,3]
 FR BND1      z[1,5,4]
 FR BND1      z[1,5,5]
 FR BND1      z[1,5,6]
 FR BND1      z[5,1,0]
 FR BND1      z[5,1,1]
 FR BND1      z[5,1,2]
 FR BND1      z[5,1,3]
 FR BND1      z[5,1,4]
 FR BND1      z[5,1,5]
 FR BND1      z[5,1,6]
 FR BND1      z[1,6,0]
 FR BND1      z[1,6,1]
 FR BND1      z[1,6,2]
 FR BND1      z[1,6,3]
 FR BND1      z[1,6,4]
 FR BND1      z[1,6,5]
 FR BND1      z[1,6,6]
 FR BND1      z[6,1,0]
 FR BND1      z[6,1,1]
 FR BND1      z[6,1,2]
 FR BND1      z[6,1,3]
 FR BND1      z[6,1,4]
 FR BND1      z[6,1,5]
 FR BND1      z[6,1,6]
 FR BND1      z[2,4,0]
 FR BND1      z[2,4,1]
 FR BND1      z[2,4,2]
 FR BND1      z[2,4,3]
 FR BND1      z[2,4,4]
 FR BND1      z[2,4,5]
 FR BND1      z[2,4,6]
 FR BND1      z[4,2,0]
 FR BND1      z[4,2,1]
 FR BND1      z[4,2,2]
 FR BND1      z[4,2,3]
 FR BND1      z[4,2,4]
 FR BND1      z[4,2,5]
 FR BND1      z[4,2,6]
 FR BND1      z[2,5,0]
 FR BND1      z[2,5,1]
 FR BND1      z[2,5,2]
 FR BND1      z[2,5,3]
 FR BND1      z[2,5,4]
 FR BND1      z[2,5,5]
 FR BND1      z[2,5,6]
 FR BND1      z[5,2,0]
 FR BND1      z[5,2,1]
 FR BND1      z[5,2,2]
 FR BND1      z[5,2,3]
 FR BND1      z[5,2,4]
 FR BND1      z[5,2,5]
 FR BND1      z[5,2,6]
 FR BND1      z[2,6,0]
 FR BND1      z[2,6,1]
 FR BND1      z[2,6,2]
 FR BND1      z[2,6,3]
 FR BND1      z[2,6,4]
 FR BND1      z[2,6,5]
 FR BND1      z[2,6,6]
 FR BND1      z[6,2,0]
 FR BND1      z[6,2,1]
 FR BND1      z[6,2,2]
 FR BND1      z[6,2,3]
 FR BND1      z[6,2,4]
 FR BND1      z[6,2,5]
 FR BND1      z[6,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[4,6,0]
 FR BND1      z[4,6,1]
 FR BND1      z[4,6,2]
 FR BND1      z[4,6,3]
 FR BND1      z[4,6,4]
 FR BND1      z[4,6,5]
 FR BND1      z[4,6,6]
 FR BND1      z[6,4,0]
 FR BND1      z[6,4,1]
 FR BND1      z[6,4,2]
 FR BND1      z[6,4,3]
 FR BND1      z[6,4,4]
 FR BND1      z[6,4,5]
 FR BND1      z[6,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
ENDATA
