NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 E  R64     
 L  R65     
 L  R66     
 L  R67     
 L  R68     
 L  R69     
 L  R70     
 L  R71     
 L  R72     
 L  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R65       -3.0999999046325684e+00
    phi[0,1]  R66       -3.0999999046325684e+00
    phi[0,1]  R67       -2.2400000095367432e+00
    phi[0,1]  R68       -2.2400000095367432e+00
    phi[0,1]  R69       -3.0999999046325684e+00
    phi[0,1]  R70       -3.0999999046325684e+00
    phi[0,1]  R71       -2.5699999332427979e+00
    phi[0,1]  R72       -2.5699999332427979e+00
    phi[0,1]  R73       -3.0999999046325684e+00
    phi[0,1]  R74       -3.0999999046325684e+00
    phi[0,1]  R75       -2.0899999141693115e+00
    phi[0,1]  R76       -2.0899999141693115e+00
    phi[0,1]  R77       -3.0999999046325684e+00
    phi[0,1]  R78       -3.0999999046325684e+00
    phi[0,1]  R79       -4.7820419073104858e-01
    phi[0,1]  R80       4.0053734183311462e-01
    phi[0,1]  R81       -2.6331019401550293e+00
    phi[0,1]  R82       1.2441967725753784e+00
    phi[0,1]  R83       1.6774693727493286e+00
    phi[0,1]  R84       2.3281822204589844e+00
    phi[0,1]  R85       9.3839412927627563e-01
    phi[0,1]  R86       2.4824683666229248e+00
    phi[0,1]  R87       1.5156763792037964e+00
    phi[0,1]  R88       1.4939255714416504e+00
    phi[0,1]  R89       -2.6201689243316650e+00
    phi[0,1]  R90       -2.5326535701751709e+00
    phi[0,1]  R91       -2.2652881145477295e+00
    phi[0,1]  R92       -1.8307443857192993e+00
    phi[0,1]  R93       -1.6147856712341309e+00
    phi[0,1]  R94       -1.8591246604919434e+00
    phi[0,1]  R95       -2.4186737537384033e+00
    phi[0,1]  R96       -1.3377602100372314e+00
    phi[0,1]  R97       -2.2241735458374023e+00
    phi[0,1]  R98       -1.5821095705032349e+00
    phi[0,1]  R99       -2.9848515987396240e+00
    phi[0,1]  R100      -2.4242684841156006e+00
    phi[0,1]  R101      -1.4922106266021729e+00
    phi[0,1]  R102      3.9528369903564453e-02
    phi[0,1]  R103      -1.2044646739959717e+00
    phi[0,1]  R104      -3.7773346900939941e-01
    phi[0,1]  R105      -1.4717037677764893e+00
    phi[0,1]  R106      -5.6162166595458984e-01
    phi[0,1]  R107      1.8472030758857727e-01
    phi[0,1]  R108      -8.4489631652832031e-01
    phi[0,1]  R109      2.4837329387664795e+00
    phi[0,1]  R110      1.6853909492492676e+00
    phi[0,1]  R111      3.1372466087341309e+00
    phi[0,1]  R112      1.8665249347686768e+00
    phi[0,1]  R113      9.9701762199401855e-01
    phi[0,1]  R114      2.0978093147277832e+00
    phi[0,1]  R115      2.1934351921081543e+00
    phi[0,1]  R116      -1.5832924842834473e+00
    phi[0,1]  R117      -5.1459020376205444e-01
    phi[0,1]  R118      -1.1455730199813843e+00
    phi[0,1]  R119      -1.5439590215682983e+00
    phi[0,1]  R120      -2.8168959617614746e+00
    phi[0,1]  R121      1.6582718491554260e-01
    phi[0,1]  R122      -2.7671098709106445e+00
    phi[0,1]  R123      -3.3922371864318848e+00
    phi[0,1]  R124      -2.7125294208526611e+00
    phi[0,1]  R125      -2.7979650497436523e+00
    phi[0,1]  R126      -2.3651564121246338e+00
    phi[0,1]  R127      -2.6886031627655029e+00
    phi[0,1]  R128      -2.2302947044372559e+00
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R129      -3.0999999046325684e+00
    phi[1,0]  R130      -3.0999999046325684e+00
    phi[1,0]  R131      -2.2400000095367432e+00
    phi[1,0]  R132      -2.2400000095367432e+00
    phi[1,0]  R133      -3.0999999046325684e+00
    phi[1,0]  R134      -3.0999999046325684e+00
    phi[1,0]  R135      -2.5699999332427979e+00
    phi[1,0]  R136      -2.5699999332427979e+00
    phi[1,0]  R137      -3.0999999046325684e+00
    phi[1,0]  R138      -3.0999999046325684e+00
    phi[1,0]  R139      -2.0899999141693115e+00
    phi[1,0]  R140      -2.0899999141693115e+00
    phi[1,0]  R141      -3.0999999046325684e+00
    phi[1,0]  R142      -3.0999999046325684e+00
    phi[1,0]  R143      2.4837329387664795e+00
    phi[1,0]  R144      1.6853909492492676e+00
    phi[1,0]  R145      3.1372466087341309e+00
    phi[1,0]  R146      1.8665249347686768e+00
    phi[1,0]  R147      9.9701762199401855e-01
    phi[1,0]  R148      2.0978093147277832e+00
    phi[1,0]  R149      2.1934351921081543e+00
    phi[1,0]  R150      -1.5832924842834473e+00
    phi[1,0]  R151      -5.1459020376205444e-01
    phi[1,0]  R152      -1.1455730199813843e+00
    phi[1,0]  R153      -1.5439590215682983e+00
    phi[1,0]  R154      -2.8168959617614746e+00
    phi[1,0]  R155      1.6582718491554260e-01
    phi[1,0]  R156      -2.7671098709106445e+00
    phi[1,0]  R157      -3.3922371864318848e+00
    phi[1,0]  R158      -2.7125294208526611e+00
    phi[1,0]  R159      -2.7979650497436523e+00
    phi[1,0]  R160      -2.3651564121246338e+00
    phi[1,0]  R161      -2.6886031627655029e+00
    phi[1,0]  R162      -2.2302947044372559e+00
    phi[1,0]  R163      -4.7820419073104858e-01
    phi[1,0]  R164      4.0053734183311462e-01
    phi[1,0]  R165      -2.6331019401550293e+00
    phi[1,0]  R166      1.2441967725753784e+00
    phi[1,0]  R167      1.6774693727493286e+00
    phi[1,0]  R168      2.3281822204589844e+00
    phi[1,0]  R169      9.3839412927627563e-01
    phi[1,0]  R170      2.4824683666229248e+00
    phi[1,0]  R171      1.5156763792037964e+00
    phi[1,0]  R172      1.4939255714416504e+00
    phi[1,0]  R173      -2.6201689243316650e+00
    phi[1,0]  R174      -2.5326535701751709e+00
    phi[1,0]  R175      -2.2652881145477295e+00
    phi[1,0]  R176      -1.8307443857192993e+00
    phi[1,0]  R177      -1.6147856712341309e+00
    phi[1,0]  R178      -1.8591246604919434e+00
    phi[1,0]  R179      -2.4186737537384033e+00
    phi[1,0]  R180      -1.3377602100372314e+00
    phi[1,0]  R181      -2.2241735458374023e+00
    phi[1,0]  R182      -1.5821095705032349e+00
    phi[1,0]  R183      -2.9848515987396240e+00
    phi[1,0]  R184      -2.4242684841156006e+00
    phi[1,0]  R185      -1.4922106266021729e+00
    phi[1,0]  R186      3.9528369903564453e-02
    phi[1,0]  R187      -1.2044646739959717e+00
    phi[1,0]  R188      -3.7773346900939941e-01
    phi[1,0]  R189      -1.4717037677764893e+00
    phi[1,0]  R190      -5.6162166595458984e-01
    phi[1,0]  R191      1.8472030758857727e-01
    phi[1,0]  R192      -8.4489631652832031e-01
    phi[0,3]  R0        1
    phi[0,3]  R1        1
    phi[0,3]  R27       -1
    phi[0,3]  R193      -3.0999999046325684e+00
    phi[0,3]  R194      -3.0999999046325684e+00
    phi[0,3]  R195      -2.2400000095367432e+00
    phi[0,3]  R196      -2.2400000095367432e+00
    phi[0,3]  R197      -3.0999999046325684e+00
    phi[0,3]  R198      -3.0999999046325684e+00
    phi[0,3]  R199      -2.5699999332427979e+00
    phi[0,3]  R200      -2.5699999332427979e+00
    phi[0,3]  R201      -3.0999999046325684e+00
    phi[0,3]  R202      -3.0999999046325684e+00
    phi[0,3]  R203      -2.0899999141693115e+00
    phi[0,3]  R204      -2.0899999141693115e+00
    phi[0,3]  R205      -3.0999999046325684e+00
    phi[0,3]  R206      -3.0999999046325684e+00
    phi[0,3]  R207      -4.7820419073104858e-01
    phi[0,3]  R208      4.0053734183311462e-01
    phi[0,3]  R209      -2.6331019401550293e+00
    phi[0,3]  R210      1.2441967725753784e+00
    phi[0,3]  R211      1.6774693727493286e+00
    phi[0,3]  R212      2.3281822204589844e+00
    phi[0,3]  R213      9.3839412927627563e-01
    phi[0,3]  R214      2.4824683666229248e+00
    phi[0,3]  R215      1.5156763792037964e+00
    phi[0,3]  R216      1.4939255714416504e+00
    phi[0,3]  R217      -2.6201689243316650e+00
    phi[0,3]  R218      -2.5326535701751709e+00
    phi[0,3]  R219      -2.2652881145477295e+00
    phi[0,3]  R220      -1.8307443857192993e+00
    phi[0,3]  R221      -1.6147856712341309e+00
    phi[0,3]  R222      -1.8591246604919434e+00
    phi[0,3]  R223      -2.4186737537384033e+00
    phi[0,3]  R224      -1.3377602100372314e+00
    phi[0,3]  R225      -2.2241735458374023e+00
    phi[0,3]  R226      -1.5821095705032349e+00
    phi[0,3]  R227      -2.9848515987396240e+00
    phi[0,3]  R228      -2.4242684841156006e+00
    phi[0,3]  R229      -1.4922106266021729e+00
    phi[0,3]  R230      3.9528369903564453e-02
    phi[0,3]  R231      -1.2044646739959717e+00
    phi[0,3]  R232      -3.7773346900939941e-01
    phi[0,3]  R233      -1.4717037677764893e+00
    phi[0,3]  R234      -5.6162166595458984e-01
    phi[0,3]  R235      1.8472030758857727e-01
    phi[0,3]  R236      -8.4489631652832031e-01
    phi[0,3]  R237      1.1394909620285034e+00
    phi[0,3]  R238      6.4374661445617676e-01
    phi[0,3]  R239      1.9511861801147461e+00
    phi[0,3]  R240      1.2518910169601440e+00
    phi[0,3]  R241      1.6011964082717896e+00
    phi[0,3]  R242      -1.9887217283248901e+00
    phi[0,3]  R243      0.54656982421875
    phi[0,3]  R244      1.6618834435939789e-01
    phi[0,3]  R245      6.6286253929138184e-01
    phi[0,3]  R246      2.0448982715606689e+00
    phi[0,3]  R247      -1.4534476995468140e+00
    phi[0,3]  R248      -1.7219181060791016e+00
    phi[0,3]  R249      -0.510861337184906
    phi[0,3]  R250      -0.573452353477478
    phi[0,3]  R251      -2.8334765434265137e+00
    phi[0,3]  R252      -7.3426139354705811e-01
    phi[0,3]  R253      -2.3278372287750244e+00
    phi[0,3]  R254      -1.5832860469818115e+00
    phi[0,3]  R255      -3.1779150962829590e+00
    phi[0,3]  R256      4.8815757036209106e-01
    phi[0,3]  R257      -2.2887065410614014e+00
    phi[0,3]  R258      -1.7561002969741821e+00
    phi[0,3]  R259      -2.4729170799255371e+00
    phi[0,3]  R260      1.1507622003555298e+00
    phi[0,3]  R261      -3.1201667785644531e+00
    phi[0,3]  R262      -1.6336566209793091e+00
    phi[0,3]  R263      -1.3498240709304810e+00
    phi[0,3]  R264      -1.2046080827713013e+00
    phi[0,3]  R265      -1.0881104469299316e+00
    phi[0,3]  R266      -7.1604549884796143e-01
    phi[0,3]  R267      -3.0683481693267822e+00
    phi[0,3]  R268      -1.2112450599670410e+00
    phi[0,3]  R269      -2.3587906360626221e+00
    phi[0,3]  R270      -3.7835183143615723e+00
    phi[0,3]  R271      -3.9307682514190674e+00
    phi[0,3]  R272      7.5676834583282471e-01
    phi[0,3]  R273      -3.9228883385658264e-01
    phi[0,3]  R274      1.1633410453796387e+00
    phi[0,3]  R275      3.7607144564390182e-02
    phi[0,3]  R276      4.1826650500297546e-01
    phi[0,3]  R277      -2.6692178249359131e+00
    phi[0,3]  R278      -2.0207812786102295e+00
    phi[0,3]  R279      -2.8295145034790039e+00
    phi[0,3]  R280      -2.7925615310668945e+00
    phi[0,3]  R281      -1.55397367477417
    phi[0,3]  R282      -2.8401713371276855e+00
    phi[0,3]  R283      -3.6304659843444824e+00
    phi[0,3]  R284      -1.6500231623649597e-01
    phi[0,3]  R285      -1.3065891265869141e+00
    phi[0,3]  R286      -5.1544207334518433e-01
    phi[0,3]  R287      -1.9361305236816406e+00
    phi[0,3]  R288      7.7429658174514771e-01
    phi[0,3]  R289      -3.2938530445098877e+00
    phi[0,3]  R290      9.9765557050704956e-01
    phi[0,3]  R291      -1.8263802528381348e+00
    phi[0,3]  R292      -1.3313270807266235e+00
    phi[0,3]  R293      -1.8956589698791504e+00
    phi[0,3]  R294      -1.6193647384643555e+00
    phi[0,3]  R295      -6.3351303339004517e-01
    phi[0,3]  R296      -1.8266658782958984e+00
    phi[0,3]  R297      -2.3801701068878174e+00
    phi[0,3]  R298      -2.6733088493347168e+00
    phi[0,3]  R299      -1.4359822273254395e+00
    phi[0,3]  R300      -1.7373734712600708e+00
    phi[0,3]  R301      -9.1783905029296875e-01
    phi[0,3]  R302      -6.0533422231674194e-01
    phi[0,3]  R303      -2.1545746326446533e+00
    phi[0,3]  R304      -2.96726655960083
    phi[0,3]  R305      6.8251711130142212e-01
    phi[0,3]  R306      -1.5084934234619141e-01
    phi[0,3]  R307      -2.6604828834533691e+00
    phi[0,3]  R308      -2.4222090244293213e+00
    phi[0,3]  R309      -2.5566952228546143e+00
    phi[0,3]  R310      7.0156955718994141e-01
    phi[0,3]  R311      -3.6166664958000183e-01
    phi[0,3]  R312      -8.8639140129089355e-01
    phi[0,3]  R313      -1.1624594926834106e+00
    phi[0,3]  R314      -2.2350578308105469e+00
    phi[0,3]  R315      -5.0943724811077118e-02
    phi[0,3]  R316      -3.4699410200119019e-01
    phi[0,3]  R317      -7.4235385656356812e-01
    phi[0,3]  R318      -7.9564118385314941e-01
    phi[0,3]  R319      1.1546611785888672e+00
    phi[0,3]  R320      -2.4434099197387695e+00
    phi[0,3]  R321      2.2980399429798126e-01
    phi[0,3]  R322      1.3935668393969536e-02
    phi[0,3]  R323      7.9170316457748413e-01
    phi[0,3]  R324      -6.8109005689620972e-02
    phi[0,3]  R325      3.0138674378395081e-01
    phi[0,3]  R326      -2.3395762443542480e+00
    phi[3,0]  R0        -1
    phi[3,0]  R27       1
    phi[3,0]  R28       1
    phi[3,0]  R327      -3.0999999046325684e+00
    phi[3,0]  R328      -3.0999999046325684e+00
    phi[3,0]  R329      -2.2400000095367432e+00
    phi[3,0]  R330      -2.2400000095367432e+00
    phi[3,0]  R331      -3.0999999046325684e+00
    phi[3,0]  R332      -3.0999999046325684e+00
    phi[3,0]  R333      -2.5699999332427979e+00
    phi[3,0]  R334      -2.5699999332427979e+00
    phi[3,0]  R335      -3.0999999046325684e+00
    phi[3,0]  R336      -3.0999999046325684e+00
    phi[3,0]  R337      -2.0899999141693115e+00
    phi[3,0]  R338      -2.0899999141693115e+00
    phi[3,0]  R339      -3.0999999046325684e+00
    phi[3,0]  R340      -3.0999999046325684e+00
    phi[3,0]  R341      1.1394909620285034e+00
    phi[3,0]  R342      6.4374661445617676e-01
    phi[3,0]  R343      1.9511861801147461e+00
    phi[3,0]  R344      1.2518910169601440e+00
    phi[3,0]  R345      1.6011964082717896e+00
    phi[3,0]  R346      -1.9887217283248901e+00
    phi[3,0]  R347      0.54656982421875
    phi[3,0]  R348      1.6618834435939789e-01
    phi[3,0]  R349      6.6286253929138184e-01
    phi[3,0]  R350      2.0448982715606689e+00
    phi[3,0]  R351      -1.4534476995468140e+00
    phi[3,0]  R352      -1.7219181060791016e+00
    phi[3,0]  R353      -0.510861337184906
    phi[3,0]  R354      -0.573452353477478
    phi[3,0]  R355      -2.8334765434265137e+00
    phi[3,0]  R356      -7.3426139354705811e-01
    phi[3,0]  R357      -2.3278372287750244e+00
    phi[3,0]  R358      -1.5832860469818115e+00
    phi[3,0]  R359      -3.1779150962829590e+00
    phi[3,0]  R360      4.8815757036209106e-01
    phi[3,0]  R361      -2.2887065410614014e+00
    phi[3,0]  R362      -1.7561002969741821e+00
    phi[3,0]  R363      -2.4729170799255371e+00
    phi[3,0]  R364      1.1507622003555298e+00
    phi[3,0]  R365      -3.1201667785644531e+00
    phi[3,0]  R366      -1.6336566209793091e+00
    phi[3,0]  R367      -1.3498240709304810e+00
    phi[3,0]  R368      -1.2046080827713013e+00
    phi[3,0]  R369      -1.0881104469299316e+00
    phi[3,0]  R370      -7.1604549884796143e-01
    phi[3,0]  R371      -3.0683481693267822e+00
    phi[3,0]  R372      -1.2112450599670410e+00
    phi[3,0]  R373      -2.3587906360626221e+00
    phi[3,0]  R374      -3.7835183143615723e+00
    phi[3,0]  R375      -3.9307682514190674e+00
    phi[3,0]  R376      7.5676834583282471e-01
    phi[3,0]  R377      -3.9228883385658264e-01
    phi[3,0]  R378      1.1633410453796387e+00
    phi[3,0]  R379      3.7607144564390182e-02
    phi[3,0]  R380      4.1826650500297546e-01
    phi[3,0]  R381      -2.6692178249359131e+00
    phi[3,0]  R382      -2.0207812786102295e+00
    phi[3,0]  R383      -2.8295145034790039e+00
    phi[3,0]  R384      -2.7925615310668945e+00
    phi[3,0]  R385      -1.55397367477417
    phi[3,0]  R386      -2.8401713371276855e+00
    phi[3,0]  R387      -3.6304659843444824e+00
    phi[3,0]  R388      -1.6500231623649597e-01
    phi[3,0]  R389      -1.3065891265869141e+00
    phi[3,0]  R390      -5.1544207334518433e-01
    phi[3,0]  R391      -1.9361305236816406e+00
    phi[3,0]  R392      7.7429658174514771e-01
    phi[3,0]  R393      -3.2938530445098877e+00
    phi[3,0]  R394      9.9765557050704956e-01
    phi[3,0]  R395      -1.8263802528381348e+00
    phi[3,0]  R396      -1.3313270807266235e+00
    phi[3,0]  R397      -1.8956589698791504e+00
    phi[3,0]  R398      -1.6193647384643555e+00
    phi[3,0]  R399      -6.3351303339004517e-01
    phi[3,0]  R400      -1.8266658782958984e+00
    phi[3,0]  R401      -2.3801701068878174e+00
    phi[3,0]  R402      -2.6733088493347168e+00
    phi[3,0]  R403      -1.4359822273254395e+00
    phi[3,0]  R404      -1.7373734712600708e+00
    phi[3,0]  R405      -9.1783905029296875e-01
    phi[3,0]  R406      -6.0533422231674194e-01
    phi[3,0]  R407      -2.1545746326446533e+00
    phi[3,0]  R408      -2.96726655960083
    phi[3,0]  R409      6.8251711130142212e-01
    phi[3,0]  R410      -1.5084934234619141e-01
    phi[3,0]  R411      -2.6604828834533691e+00
    phi[3,0]  R412      -2.4222090244293213e+00
    phi[3,0]  R413      -2.5566952228546143e+00
    phi[3,0]  R414      7.0156955718994141e-01
    phi[3,0]  R415      -3.6166664958000183e-01
    phi[3,0]  R416      -8.8639140129089355e-01
    phi[3,0]  R417      -1.1624594926834106e+00
    phi[3,0]  R418      -2.2350578308105469e+00
    phi[3,0]  R419      -5.0943724811077118e-02
    phi[3,0]  R420      -3.4699410200119019e-01
    phi[3,0]  R421      -7.4235385656356812e-01
    phi[3,0]  R422      -7.9564118385314941e-01
    phi[3,0]  R423      1.1546611785888672e+00
    phi[3,0]  R424      -2.4434099197387695e+00
    phi[3,0]  R425      2.2980399429798126e-01
    phi[3,0]  R426      1.3935668393969536e-02
    phi[3,0]  R427      7.9170316457748413e-01
    phi[3,0]  R428      -6.8109005689620972e-02
    phi[3,0]  R429      3.0138674378395081e-01
    phi[3,0]  R430      -2.3395762443542480e+00
    phi[3,0]  R431      -4.7820419073104858e-01
    phi[3,0]  R432      4.0053734183311462e-01
    phi[3,0]  R433      -2.6331019401550293e+00
    phi[3,0]  R434      1.2441967725753784e+00
    phi[3,0]  R435      1.6774693727493286e+00
    phi[3,0]  R436      2.3281822204589844e+00
    phi[3,0]  R437      9.3839412927627563e-01
    phi[3,0]  R438      2.4824683666229248e+00
    phi[3,0]  R439      1.5156763792037964e+00
    phi[3,0]  R440      1.4939255714416504e+00
    phi[3,0]  R441      -2.6201689243316650e+00
    phi[3,0]  R442      -2.5326535701751709e+00
    phi[3,0]  R443      -2.2652881145477295e+00
    phi[3,0]  R444      -1.8307443857192993e+00
    phi[3,0]  R445      -1.6147856712341309e+00
    phi[3,0]  R446      -1.8591246604919434e+00
    phi[3,0]  R447      -2.4186737537384033e+00
    phi[3,0]  R448      -1.3377602100372314e+00
    phi[3,0]  R449      -2.2241735458374023e+00
    phi[3,0]  R450      -1.5821095705032349e+00
    phi[3,0]  R451      -2.9848515987396240e+00
    phi[3,0]  R452      -2.4242684841156006e+00
    phi[3,0]  R453      -1.4922106266021729e+00
    phi[3,0]  R454      3.9528369903564453e-02
    phi[3,0]  R455      -1.2044646739959717e+00
    phi[3,0]  R456      -3.7773346900939941e-01
    phi[3,0]  R457      -1.4717037677764893e+00
    phi[3,0]  R458      -5.6162166595458984e-01
    phi[3,0]  R459      1.8472030758857727e-01
    phi[3,0]  R460      -8.4489631652832031e-01
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R461      -3.0999999046325684e+00
    phi[0,4]  R462      -3.0999999046325684e+00
    phi[0,4]  R463      -2.2400000095367432e+00
    phi[0,4]  R464      -2.2400000095367432e+00
    phi[0,4]  R465      -3.0999999046325684e+00
    phi[0,4]  R466      -3.0999999046325684e+00
    phi[0,4]  R467      -2.5699999332427979e+00
    phi[0,4]  R468      -2.5699999332427979e+00
    phi[0,4]  R469      -3.0999999046325684e+00
    phi[0,4]  R470      -3.0999999046325684e+00
    phi[0,4]  R471      -2.0899999141693115e+00
    phi[0,4]  R472      -2.0899999141693115e+00
    phi[0,4]  R473      -3.0999999046325684e+00
    phi[0,4]  R474      -3.0999999046325684e+00
    phi[0,4]  R475      -4.7820419073104858e-01
    phi[0,4]  R476      4.0053734183311462e-01
    phi[0,4]  R477      -2.6331019401550293e+00
    phi[0,4]  R478      1.2441967725753784e+00
    phi[0,4]  R479      1.6774693727493286e+00
    phi[0,4]  R480      2.3281822204589844e+00
    phi[0,4]  R481      9.3839412927627563e-01
    phi[0,4]  R482      2.4824683666229248e+00
    phi[0,4]  R483      1.5156763792037964e+00
    phi[0,4]  R484      1.4939255714416504e+00
    phi[0,4]  R485      -2.6201689243316650e+00
    phi[0,4]  R486      -2.5326535701751709e+00
    phi[0,4]  R487      -2.2652881145477295e+00
    phi[0,4]  R488      -1.8307443857192993e+00
    phi[0,4]  R489      -1.6147856712341309e+00
    phi[0,4]  R490      -1.8591246604919434e+00
    phi[0,4]  R491      -2.4186737537384033e+00
    phi[0,4]  R492      -1.3377602100372314e+00
    phi[0,4]  R493      -2.2241735458374023e+00
    phi[0,4]  R494      -1.5821095705032349e+00
    phi[0,4]  R495      -2.9848515987396240e+00
    phi[0,4]  R496      -2.4242684841156006e+00
    phi[0,4]  R497      -1.4922106266021729e+00
    phi[0,4]  R498      3.9528369903564453e-02
    phi[0,4]  R499      -1.2044646739959717e+00
    phi[0,4]  R500      -3.7773346900939941e-01
    phi[0,4]  R501      -1.4717037677764893e+00
    phi[0,4]  R502      -5.6162166595458984e-01
    phi[0,4]  R503      1.8472030758857727e-01
    phi[0,4]  R504      -8.4489631652832031e-01
    phi[0,4]  R505      2.1473853588104248e+00
    phi[0,4]  R506      3.5512828826904297e+00
    phi[0,4]  R507      2.3660592734813690e-02
    phi[0,4]  R508      -2.3547699451446533e+00
    phi[0,4]  R509      -1.3744689226150513e+00
    phi[0,4]  R510      -2.4668209552764893e+00
    phi[0,4]  R511      -6.8081367015838623e-01
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R512      -3.0999999046325684e+00
    phi[4,0]  R513      -3.0999999046325684e+00
    phi[4,0]  R514      -2.2400000095367432e+00
    phi[4,0]  R515      -2.2400000095367432e+00
    phi[4,0]  R516      -3.0999999046325684e+00
    phi[4,0]  R517      -3.0999999046325684e+00
    phi[4,0]  R518      -2.5699999332427979e+00
    phi[4,0]  R519      -2.5699999332427979e+00
    phi[4,0]  R520      -3.0999999046325684e+00
    phi[4,0]  R521      -3.0999999046325684e+00
    phi[4,0]  R522      -2.0899999141693115e+00
    phi[4,0]  R523      -2.0899999141693115e+00
    phi[4,0]  R524      -3.0999999046325684e+00
    phi[4,0]  R525      -3.0999999046325684e+00
    phi[4,0]  R526      2.1473853588104248e+00
    phi[4,0]  R527      3.5512828826904297e+00
    phi[4,0]  R528      2.3660592734813690e-02
    phi[4,0]  R529      -2.3547699451446533e+00
    phi[4,0]  R530      -1.3744689226150513e+00
    phi[4,0]  R531      -2.4668209552764893e+00
    phi[4,0]  R532      -6.8081367015838623e-01
    phi[4,0]  R533      -4.7820419073104858e-01
    phi[4,0]  R534      4.0053734183311462e-01
    phi[4,0]  R535      -2.6331019401550293e+00
    phi[4,0]  R536      1.2441967725753784e+00
    phi[4,0]  R537      1.6774693727493286e+00
    phi[4,0]  R538      2.3281822204589844e+00
    phi[4,0]  R539      9.3839412927627563e-01
    phi[4,0]  R540      2.4824683666229248e+00
    phi[4,0]  R541      1.5156763792037964e+00
    phi[4,0]  R542      1.4939255714416504e+00
    phi[4,0]  R543      -2.6201689243316650e+00
    phi[4,0]  R544      -2.5326535701751709e+00
    phi[4,0]  R545      -2.2652881145477295e+00
    phi[4,0]  R546      -1.8307443857192993e+00
    phi[4,0]  R547      -1.6147856712341309e+00
    phi[4,0]  R548      -1.8591246604919434e+00
    phi[4,0]  R549      -2.4186737537384033e+00
    phi[4,0]  R550      -1.3377602100372314e+00
    phi[4,0]  R551      -2.2241735458374023e+00
    phi[4,0]  R552      -1.5821095705032349e+00
    phi[4,0]  R553      -2.9848515987396240e+00
    phi[4,0]  R554      -2.4242684841156006e+00
    phi[4,0]  R555      -1.4922106266021729e+00
    phi[4,0]  R556      3.9528369903564453e-02
    phi[4,0]  R557      -1.2044646739959717e+00
    phi[4,0]  R558      -3.7773346900939941e-01
    phi[4,0]  R559      -1.4717037677764893e+00
    phi[4,0]  R560      -5.6162166595458984e-01
    phi[4,0]  R561      1.8472030758857727e-01
    phi[4,0]  R562      -8.4489631652832031e-01
    phi[7,0]  R0        -1
    phi[7,0]  R2        0.436132660285212
    phi[7,0]  R3        -6.5293115906839816e-01
    phi[7,0]  R4        1.4403253088833403e+00
    phi[7,0]  R5        -1.6897541231401312e+00
    phi[7,0]  R6        -2.19870963770369
    phi[7,0]  R7        1.0017387778479798e+00
    phi[7,0]  R8        1.6473301255492978e+00
    phi[7,0]  R63       1
    phi[7,0]  R563      -3.5361325649177804e+00
    phi[7,0]  R564      -2.6638672443473563e+00
    phi[7,0]  R565      -1.5870688504683450e+00
    phi[7,0]  R566      -2.8929311686051413e+00
    phi[7,0]  R567      -4.5403252135159082e+00
    phi[7,0]  R568      -1.6596745957492280e+00
    phi[7,0]  R569      -8.8024581010266667e-01
    phi[7,0]  R570      -4.2597540563829295e+00
    phi[7,0]  R571      -9.0129026692887848e-01
    phi[7,0]  R572      -5.2987095423362582e+00
    phi[7,0]  R573      -3.0917386920172913e+00
    phi[7,0]  R574      -1.0882611363213317e+00
    phi[7,0]  R575      -4.7473300301818657e+00
    phi[7,0]  R576      -1.4526697790832706e+00
    phi[7,0]  R577      -6.3950767609015968e-02
    phi[7,0]  R578      -8.4663747979320081e-02
    phi[7,0]  R579      -8.6217724766301629e-02
    phi[7,0]  R580      -9.3812438938966292e-02
    phi[7,0]  R581      -1.6361556482316830e-01
    phi[7,0]  R582      -5.4942171817735419e-01
    phi[7,0]  R583      -1.1217079294027230e+00
    phi[7,0]  R584      -3.9415004158443212e-01
    phi[7,0]  R585      -1.0683119508002572e+00
    phi[7,0]  R586      -3.8368902617570178e-01
    phi[7,0]  R587      -5.1968095860660624e-01
    phi[7,0]  R588      -5.2582221703121057e-01
    phi[7,0]  R589      -5.2587218609582309e-01
    phi[7,0]  R590      -5.4226503003387871e-01
    phi[7,0]  R591      -5.4241744282337612e-01
    phi[7,0]  R592      -5.4857972079272588e-01
    phi[7,0]  R593      -5.5007905433685811e-01
    phi[7,0]  R594      -5.5958484876587644e-01
    phi[7,0]  R595      -0.560737618758552
    phi[7,0]  R596      -5.6254980213795647e-01
    phi[7,0]  R597      -5.4129115360646463e-01
    phi[7,0]  R598      -5.7454291757257092e-01
    phi[7,0]  R599      -9.7242093362379045e-01
    phi[7,0]  R600      -9.7873400985166059e-01
    phi[7,0]  R601      -0.986965245187572
    phi[7,0]  R602      -9.9263960983878730e-01
    phi[7,0]  R603      -9.9725826019586261e-01
    phi[7,0]  R604      -1.0142077702146473e+00
    phi[7,0]  R605      -1.0269882317655208e+00
    phi[7,0]  R606      -1.0275123344746708e+00
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R607      -3.0999999046325684e+00
    phi[1,2]  R608      -3.0999999046325684e+00
    phi[1,2]  R609      -2.2400000095367432e+00
    phi[1,2]  R610      -2.2400000095367432e+00
    phi[1,2]  R611      -3.0999999046325684e+00
    phi[1,2]  R612      -3.0999999046325684e+00
    phi[1,2]  R613      -2.5699999332427979e+00
    phi[1,2]  R614      -2.5699999332427979e+00
    phi[1,2]  R615      -3.0999999046325684e+00
    phi[1,2]  R616      -3.0999999046325684e+00
    phi[1,2]  R617      -2.0899999141693115e+00
    phi[1,2]  R618      -2.0899999141693115e+00
    phi[1,2]  R619      -3.0999999046325684e+00
    phi[1,2]  R620      -3.0999999046325684e+00
    phi[1,2]  R621      2.4837329387664795e+00
    phi[1,2]  R622      1.6853909492492676e+00
    phi[1,2]  R623      3.1372466087341309e+00
    phi[1,2]  R624      1.8665249347686768e+00
    phi[1,2]  R625      9.9701762199401855e-01
    phi[1,2]  R626      2.0978093147277832e+00
    phi[1,2]  R627      2.1934351921081543e+00
    phi[1,2]  R628      -1.5832924842834473e+00
    phi[1,2]  R629      -5.1459020376205444e-01
    phi[1,2]  R630      -1.1455730199813843e+00
    phi[1,2]  R631      -1.5439590215682983e+00
    phi[1,2]  R632      -2.8168959617614746e+00
    phi[1,2]  R633      1.6582718491554260e-01
    phi[1,2]  R634      -2.7671098709106445e+00
    phi[1,2]  R635      -3.3922371864318848e+00
    phi[1,2]  R636      -2.7125294208526611e+00
    phi[1,2]  R637      -2.7979650497436523e+00
    phi[1,2]  R638      -2.3651564121246338e+00
    phi[1,2]  R639      -2.6886031627655029e+00
    phi[1,2]  R640      -2.2302947044372559e+00
    phi[1,2]  R641      4.1008678078651428e-01
    phi[1,2]  R642      1.4148714542388916e+00
    phi[1,2]  R643      1.7850371599197388e+00
    phi[1,2]  R644      1.3848644495010376e+00
    phi[1,2]  R645      1.5156128406524658e+00
    phi[1,2]  R646      1.1438711881637573e+00
    phi[1,2]  R647      9.2052966356277466e-01
    phi[1,2]  R648      8.0471515655517578e-01
    phi[1,2]  R649      1.4304387569427490e+00
    phi[1,2]  R650      1.8274284601211548e+00
    phi[1,2]  R651      -5.7070219516754150e-01
    phi[1,2]  R652      -1.9331947565078735e+00
    phi[1,2]  R653      -3.5328283905982971e-01
    phi[1,2]  R654      -1.2813565731048584e+00
    phi[1,2]  R655      -1.5742076635360718e+00
    phi[1,2]  R656      -1.9113100767135620e+00
    phi[1,2]  R657      -1.7583810091018677e+00
    phi[1,2]  R658      -2.9299590587615967e+00
    phi[1,2]  R659      -1.0063059329986572e+00
    phi[1,2]  R660      -2.0409960746765137e+00
    phi[1,2]  R661      -4.6057811379432678e-01
    phi[1,2]  R662      -1.0206776857376099e+00
    phi[1,2]  R663      -6.7300218343734741e-01
    phi[1,2]  R664      -1.4507640600204468e+00
    phi[1,2]  R665      -1.2415980100631714e+00
    phi[1,2]  R666      -1.9115267992019653e+00
    phi[1,2]  R667      -1.7429038286209106e+00
    phi[1,2]  R668      -1.7454320192337036e+00
    phi[1,2]  R669      -2.5490555763244629e+00
    phi[1,2]  R670      -2.0783612728118896e+00
    phi[1,2]  R671      4.2241933941841125e-01
    phi[1,2]  R672      -2.4720821380615234e+00
    phi[1,2]  R673      -5.0461190938949585e-01
    phi[1,2]  R674      -2.0483081340789795e+00
    phi[1,2]  R675      -2.4797737598419189e+00
    phi[1,2]  R676      -1.1015309095382690e+00
    phi[1,2]  R677      -2.0985169410705566e+00
    phi[1,2]  R678      -2.5460166931152344e+00
    phi[1,2]  R679      -0.892280638217926
    phi[1,2]  R680      -2.8630938529968262e+00
    phi[1,2]  R681      -1.4065010547637939e+00
    phi[1,2]  R682      -1.8193671703338623e+00
    phi[1,2]  R683      1.8174457550048828e+00
    phi[1,2]  R684      -1.7847700119018555e+00
    phi[1,2]  R685      -1.7606725692749023e+00
    phi[1,2]  R686      -9.1266989707946777e-01
    phi[1,2]  R687      -1.4007629156112671e+00
    phi[1,2]  R688      -1.2564861774444580e+00
    phi[1,2]  R689      -2.0201244354248047e+00
    phi[1,2]  R690      -1.8038753271102905e+00
    phi[1,2]  R691      6.8764573335647583e-01
    phi[1,2]  R692      -2.6196253299713135e+00
    phi[1,2]  R693      -1.4968811273574829e+00
    phi[1,2]  R694      -0.693366527557373
    phi[1,2]  R695      -1.2255749702453613e+00
    phi[1,2]  R696      -2.6455328464508057e+00
    phi[1,2]  R697      -1.5244259834289551e+00
    phi[1,2]  R698      -1.4864665269851685e+00
    phi[1,2]  R699      -2.1929373741149902e+00
    phi[1,2]  R700      -2.1977615356445312e+00
    phi[1,2]  R701      5.1336884498596191e-01
    phi[1,2]  R702      -1.9099996089935303e+00
    phi[1,2]  R703      -6.0565841197967529e-01
    phi[1,2]  R704      -1.4689265489578247e+00
    phi[1,2]  R705      2.2705259323120117e+00
    phi[1,2]  R706      -2.17315673828125
    phi[1,2]  R707      -4.2671728134155273e+00
    phi[1,2]  R708      -1.1492218971252441e+00
    phi[1,2]  R709      -3.4993736743927
    phi[1,2]  R710      -1.5138159990310669e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R711      -3.0999999046325684e+00
    phi[2,1]  R712      -3.0999999046325684e+00
    phi[2,1]  R713      -2.2400000095367432e+00
    phi[2,1]  R714      -2.2400000095367432e+00
    phi[2,1]  R715      -3.0999999046325684e+00
    phi[2,1]  R716      -3.0999999046325684e+00
    phi[2,1]  R717      -2.5699999332427979e+00
    phi[2,1]  R718      -2.5699999332427979e+00
    phi[2,1]  R719      -3.0999999046325684e+00
    phi[2,1]  R720      -3.0999999046325684e+00
    phi[2,1]  R721      -2.0899999141693115e+00
    phi[2,1]  R722      -2.0899999141693115e+00
    phi[2,1]  R723      -3.0999999046325684e+00
    phi[2,1]  R724      -3.0999999046325684e+00
    phi[2,1]  R725      4.1008678078651428e-01
    phi[2,1]  R726      1.4148714542388916e+00
    phi[2,1]  R727      1.7850371599197388e+00
    phi[2,1]  R728      1.3848644495010376e+00
    phi[2,1]  R729      1.5156128406524658e+00
    phi[2,1]  R730      1.1438711881637573e+00
    phi[2,1]  R731      9.2052966356277466e-01
    phi[2,1]  R732      8.0471515655517578e-01
    phi[2,1]  R733      1.4304387569427490e+00
    phi[2,1]  R734      1.8274284601211548e+00
    phi[2,1]  R735      -5.7070219516754150e-01
    phi[2,1]  R736      -1.9331947565078735e+00
    phi[2,1]  R737      -3.5328283905982971e-01
    phi[2,1]  R738      -1.2813565731048584e+00
    phi[2,1]  R739      -1.5742076635360718e+00
    phi[2,1]  R740      -1.9113100767135620e+00
    phi[2,1]  R741      -1.7583810091018677e+00
    phi[2,1]  R742      -2.9299590587615967e+00
    phi[2,1]  R743      -1.0063059329986572e+00
    phi[2,1]  R744      -2.0409960746765137e+00
    phi[2,1]  R745      -4.6057811379432678e-01
    phi[2,1]  R746      -1.0206776857376099e+00
    phi[2,1]  R747      -6.7300218343734741e-01
    phi[2,1]  R748      -1.4507640600204468e+00
    phi[2,1]  R749      -1.2415980100631714e+00
    phi[2,1]  R750      -1.9115267992019653e+00
    phi[2,1]  R751      -1.7429038286209106e+00
    phi[2,1]  R752      -1.7454320192337036e+00
    phi[2,1]  R753      -2.5490555763244629e+00
    phi[2,1]  R754      -2.0783612728118896e+00
    phi[2,1]  R755      4.2241933941841125e-01
    phi[2,1]  R756      -2.4720821380615234e+00
    phi[2,1]  R757      -5.0461190938949585e-01
    phi[2,1]  R758      -2.0483081340789795e+00
    phi[2,1]  R759      -2.4797737598419189e+00
    phi[2,1]  R760      -1.1015309095382690e+00
    phi[2,1]  R761      -2.0985169410705566e+00
    phi[2,1]  R762      -2.5460166931152344e+00
    phi[2,1]  R763      -0.892280638217926
    phi[2,1]  R764      -2.8630938529968262e+00
    phi[2,1]  R765      -1.4065010547637939e+00
    phi[2,1]  R766      -1.8193671703338623e+00
    phi[2,1]  R767      1.8174457550048828e+00
    phi[2,1]  R768      -1.7847700119018555e+00
    phi[2,1]  R769      -1.7606725692749023e+00
    phi[2,1]  R770      -9.1266989707946777e-01
    phi[2,1]  R771      -1.4007629156112671e+00
    phi[2,1]  R772      -1.2564861774444580e+00
    phi[2,1]  R773      -2.0201244354248047e+00
    phi[2,1]  R774      -1.8038753271102905e+00
    phi[2,1]  R775      6.8764573335647583e-01
    phi[2,1]  R776      -2.6196253299713135e+00
    phi[2,1]  R777      -1.4968811273574829e+00
    phi[2,1]  R778      -0.693366527557373
    phi[2,1]  R779      -1.2255749702453613e+00
    phi[2,1]  R780      -2.6455328464508057e+00
    phi[2,1]  R781      -1.5244259834289551e+00
    phi[2,1]  R782      -1.4864665269851685e+00
    phi[2,1]  R783      -2.1929373741149902e+00
    phi[2,1]  R784      -2.1977615356445312e+00
    phi[2,1]  R785      5.1336884498596191e-01
    phi[2,1]  R786      -1.9099996089935303e+00
    phi[2,1]  R787      -6.0565841197967529e-01
    phi[2,1]  R788      -1.4689265489578247e+00
    phi[2,1]  R789      2.2705259323120117e+00
    phi[2,1]  R790      -2.17315673828125
    phi[2,1]  R791      -4.2671728134155273e+00
    phi[2,1]  R792      -1.1492218971252441e+00
    phi[2,1]  R793      -3.4993736743927
    phi[2,1]  R794      -1.5138159990310669e+00
    phi[2,1]  R795      2.4837329387664795e+00
    phi[2,1]  R796      1.6853909492492676e+00
    phi[2,1]  R797      3.1372466087341309e+00
    phi[2,1]  R798      1.8665249347686768e+00
    phi[2,1]  R799      9.9701762199401855e-01
    phi[2,1]  R800      2.0978093147277832e+00
    phi[2,1]  R801      2.1934351921081543e+00
    phi[2,1]  R802      -1.5832924842834473e+00
    phi[2,1]  R803      -5.1459020376205444e-01
    phi[2,1]  R804      -1.1455730199813843e+00
    phi[2,1]  R805      -1.5439590215682983e+00
    phi[2,1]  R806      -2.8168959617614746e+00
    phi[2,1]  R807      1.6582718491554260e-01
    phi[2,1]  R808      -2.7671098709106445e+00
    phi[2,1]  R809      -3.3922371864318848e+00
    phi[2,1]  R810      -2.7125294208526611e+00
    phi[2,1]  R811      -2.7979650497436523e+00
    phi[2,1]  R812      -2.3651564121246338e+00
    phi[2,1]  R813      -2.6886031627655029e+00
    phi[2,1]  R814      -2.2302947044372559e+00
    phi[1,3]  R9        1
    phi[1,3]  R10       1
    phi[1,3]  R27       -1
    phi[1,3]  R815      -3.0999999046325684e+00
    phi[1,3]  R816      -3.0999999046325684e+00
    phi[1,3]  R817      -2.2400000095367432e+00
    phi[1,3]  R818      -2.2400000095367432e+00
    phi[1,3]  R819      -3.0999999046325684e+00
    phi[1,3]  R820      -3.0999999046325684e+00
    phi[1,3]  R821      -2.5699999332427979e+00
    phi[1,3]  R822      -2.5699999332427979e+00
    phi[1,3]  R823      -3.0999999046325684e+00
    phi[1,3]  R824      -3.0999999046325684e+00
    phi[1,3]  R825      -2.0899999141693115e+00
    phi[1,3]  R826      -2.0899999141693115e+00
    phi[1,3]  R827      -3.0999999046325684e+00
    phi[1,3]  R828      -3.0999999046325684e+00
    phi[1,3]  R829      2.4837329387664795e+00
    phi[1,3]  R830      1.6853909492492676e+00
    phi[1,3]  R831      3.1372466087341309e+00
    phi[1,3]  R832      1.8665249347686768e+00
    phi[1,3]  R833      9.9701762199401855e-01
    phi[1,3]  R834      2.0978093147277832e+00
    phi[1,3]  R835      2.1934351921081543e+00
    phi[1,3]  R836      -1.5832924842834473e+00
    phi[1,3]  R837      -5.1459020376205444e-01
    phi[1,3]  R838      -1.1455730199813843e+00
    phi[1,3]  R839      -1.5439590215682983e+00
    phi[1,3]  R840      -2.8168959617614746e+00
    phi[1,3]  R841      1.6582718491554260e-01
    phi[1,3]  R842      -2.7671098709106445e+00
    phi[1,3]  R843      -3.3922371864318848e+00
    phi[1,3]  R844      -2.7125294208526611e+00
    phi[1,3]  R845      -2.7979650497436523e+00
    phi[1,3]  R846      -2.3651564121246338e+00
    phi[1,3]  R847      -2.6886031627655029e+00
    phi[1,3]  R848      -2.2302947044372559e+00
    phi[1,3]  R849      1.1394909620285034e+00
    phi[1,3]  R850      6.4374661445617676e-01
    phi[1,3]  R851      1.9511861801147461e+00
    phi[1,3]  R852      1.2518910169601440e+00
    phi[1,3]  R853      1.6011964082717896e+00
    phi[1,3]  R854      -1.9887217283248901e+00
    phi[1,3]  R855      0.54656982421875
    phi[1,3]  R856      1.6618834435939789e-01
    phi[1,3]  R857      6.6286253929138184e-01
    phi[1,3]  R858      2.0448982715606689e+00
    phi[1,3]  R859      -1.4534476995468140e+00
    phi[1,3]  R860      -1.7219181060791016e+00
    phi[1,3]  R861      -0.510861337184906
    phi[1,3]  R862      -0.573452353477478
    phi[1,3]  R863      -2.8334765434265137e+00
    phi[1,3]  R864      -7.3426139354705811e-01
    phi[1,3]  R865      -2.3278372287750244e+00
    phi[1,3]  R866      -1.5832860469818115e+00
    phi[1,3]  R867      -3.1779150962829590e+00
    phi[1,3]  R868      4.8815757036209106e-01
    phi[1,3]  R869      -2.2887065410614014e+00
    phi[1,3]  R870      -1.7561002969741821e+00
    phi[1,3]  R871      -2.4729170799255371e+00
    phi[1,3]  R872      1.1507622003555298e+00
    phi[1,3]  R873      -3.1201667785644531e+00
    phi[1,3]  R874      -1.6336566209793091e+00
    phi[1,3]  R875      -1.3498240709304810e+00
    phi[1,3]  R876      -1.2046080827713013e+00
    phi[1,3]  R877      -1.0881104469299316e+00
    phi[1,3]  R878      -7.1604549884796143e-01
    phi[1,3]  R879      -3.0683481693267822e+00
    phi[1,3]  R880      -1.2112450599670410e+00
    phi[1,3]  R881      -2.3587906360626221e+00
    phi[1,3]  R882      -3.7835183143615723e+00
    phi[1,3]  R883      -3.9307682514190674e+00
    phi[1,3]  R884      7.5676834583282471e-01
    phi[1,3]  R885      -3.9228883385658264e-01
    phi[1,3]  R886      1.1633410453796387e+00
    phi[1,3]  R887      3.7607144564390182e-02
    phi[1,3]  R888      4.1826650500297546e-01
    phi[1,3]  R889      -2.6692178249359131e+00
    phi[1,3]  R890      -2.0207812786102295e+00
    phi[1,3]  R891      -2.8295145034790039e+00
    phi[1,3]  R892      -2.7925615310668945e+00
    phi[1,3]  R893      -1.55397367477417
    phi[1,3]  R894      -2.8401713371276855e+00
    phi[1,3]  R895      -3.6304659843444824e+00
    phi[1,3]  R896      -1.6500231623649597e-01
    phi[1,3]  R897      -1.3065891265869141e+00
    phi[1,3]  R898      -5.1544207334518433e-01
    phi[1,3]  R899      -1.9361305236816406e+00
    phi[1,3]  R900      7.7429658174514771e-01
    phi[1,3]  R901      -3.2938530445098877e+00
    phi[1,3]  R902      9.9765557050704956e-01
    phi[1,3]  R903      -1.8263802528381348e+00
    phi[1,3]  R904      -1.3313270807266235e+00
    phi[1,3]  R905      -1.8956589698791504e+00
    phi[1,3]  R906      -1.6193647384643555e+00
    phi[1,3]  R907      -6.3351303339004517e-01
    phi[1,3]  R908      -1.8266658782958984e+00
    phi[1,3]  R909      -2.3801701068878174e+00
    phi[1,3]  R910      -2.6733088493347168e+00
    phi[1,3]  R911      -1.4359822273254395e+00
    phi[1,3]  R912      -1.7373734712600708e+00
    phi[1,3]  R913      -9.1783905029296875e-01
    phi[1,3]  R914      -6.0533422231674194e-01
    phi[1,3]  R915      -2.1545746326446533e+00
    phi[1,3]  R916      -2.96726655960083
    phi[1,3]  R917      6.8251711130142212e-01
    phi[1,3]  R918      -1.5084934234619141e-01
    phi[1,3]  R919      -2.6604828834533691e+00
    phi[1,3]  R920      -2.4222090244293213e+00
    phi[1,3]  R921      -2.5566952228546143e+00
    phi[1,3]  R922      7.0156955718994141e-01
    phi[1,3]  R923      -3.6166664958000183e-01
    phi[1,3]  R924      -8.8639140129089355e-01
    phi[1,3]  R925      -1.1624594926834106e+00
    phi[1,3]  R926      -2.2350578308105469e+00
    phi[1,3]  R927      -5.0943724811077118e-02
    phi[1,3]  R928      -3.4699410200119019e-01
    phi[1,3]  R929      -7.4235385656356812e-01
    phi[1,3]  R930      -7.9564118385314941e-01
    phi[1,3]  R931      1.1546611785888672e+00
    phi[1,3]  R932      -2.4434099197387695e+00
    phi[1,3]  R933      2.2980399429798126e-01
    phi[1,3]  R934      1.3935668393969536e-02
    phi[1,3]  R935      7.9170316457748413e-01
    phi[1,3]  R936      -6.8109005689620972e-02
    phi[1,3]  R937      3.0138674378395081e-01
    phi[1,3]  R938      -2.3395762443542480e+00
    phi[3,1]  R9        -1
    phi[3,1]  R27       1
    phi[3,1]  R28       1
    phi[3,1]  R939      -3.0999999046325684e+00
    phi[3,1]  R940      -3.0999999046325684e+00
    phi[3,1]  R941      -2.2400000095367432e+00
    phi[3,1]  R942      -2.2400000095367432e+00
    phi[3,1]  R943      -3.0999999046325684e+00
    phi[3,1]  R944      -3.0999999046325684e+00
    phi[3,1]  R945      -2.5699999332427979e+00
    phi[3,1]  R946      -2.5699999332427979e+00
    phi[3,1]  R947      -3.0999999046325684e+00
    phi[3,1]  R948      -3.0999999046325684e+00
    phi[3,1]  R949      -2.0899999141693115e+00
    phi[3,1]  R950      -2.0899999141693115e+00
    phi[3,1]  R951      -3.0999999046325684e+00
    phi[3,1]  R952      -3.0999999046325684e+00
    phi[3,1]  R953      1.1394909620285034e+00
    phi[3,1]  R954      6.4374661445617676e-01
    phi[3,1]  R955      1.9511861801147461e+00
    phi[3,1]  R956      1.2518910169601440e+00
    phi[3,1]  R957      1.6011964082717896e+00
    phi[3,1]  R958      -1.9887217283248901e+00
    phi[3,1]  R959      0.54656982421875
    phi[3,1]  R960      1.6618834435939789e-01
    phi[3,1]  R961      6.6286253929138184e-01
    phi[3,1]  R962      2.0448982715606689e+00
    phi[3,1]  R963      -1.4534476995468140e+00
    phi[3,1]  R964      -1.7219181060791016e+00
    phi[3,1]  R965      -0.510861337184906
    phi[3,1]  R966      -0.573452353477478
    phi[3,1]  R967      -2.8334765434265137e+00
    phi[3,1]  R968      -7.3426139354705811e-01
    phi[3,1]  R969      -2.3278372287750244e+00
    phi[3,1]  R970      -1.5832860469818115e+00
    phi[3,1]  R971      -3.1779150962829590e+00
    phi[3,1]  R972      4.8815757036209106e-01
    phi[3,1]  R973      -2.2887065410614014e+00
    phi[3,1]  R974      -1.7561002969741821e+00
    phi[3,1]  R975      -2.4729170799255371e+00
    phi[3,1]  R976      1.1507622003555298e+00
    phi[3,1]  R977      -3.1201667785644531e+00
    phi[3,1]  R978      -1.6336566209793091e+00
    phi[3,1]  R979      -1.3498240709304810e+00
    phi[3,1]  R980      -1.2046080827713013e+00
    phi[3,1]  R981      -1.0881104469299316e+00
    phi[3,1]  R982      -7.1604549884796143e-01
    phi[3,1]  R983      -3.0683481693267822e+00
    phi[3,1]  R984      -1.2112450599670410e+00
    phi[3,1]  R985      -2.3587906360626221e+00
    phi[3,1]  R986      -3.7835183143615723e+00
    phi[3,1]  R987      -3.9307682514190674e+00
    phi[3,1]  R988      7.5676834583282471e-01
    phi[3,1]  R989      -3.9228883385658264e-01
    phi[3,1]  R990      1.1633410453796387e+00
    phi[3,1]  R991      3.7607144564390182e-02
    phi[3,1]  R992      4.1826650500297546e-01
    phi[3,1]  R993      -2.6692178249359131e+00
    phi[3,1]  R994      -2.0207812786102295e+00
    phi[3,1]  R995      -2.8295145034790039e+00
    phi[3,1]  R996      -2.7925615310668945e+00
    phi[3,1]  R997      -1.55397367477417
    phi[3,1]  R998      -2.8401713371276855e+00
    phi[3,1]  R999      -3.6304659843444824e+00
    phi[3,1]  R1000     -1.6500231623649597e-01
    phi[3,1]  R1001     -1.3065891265869141e+00
    phi[3,1]  R1002     -5.1544207334518433e-01
    phi[3,1]  R1003     -1.9361305236816406e+00
    phi[3,1]  R1004     7.7429658174514771e-01
    phi[3,1]  R1005     -3.2938530445098877e+00
    phi[3,1]  R1006     9.9765557050704956e-01
    phi[3,1]  R1007     -1.8263802528381348e+00
    phi[3,1]  R1008     -1.3313270807266235e+00
    phi[3,1]  R1009     -1.8956589698791504e+00
    phi[3,1]  R1010     -1.6193647384643555e+00
    phi[3,1]  R1011     -6.3351303339004517e-01
    phi[3,1]  R1012     -1.8266658782958984e+00
    phi[3,1]  R1013     -2.3801701068878174e+00
    phi[3,1]  R1014     -2.6733088493347168e+00
    phi[3,1]  R1015     -1.4359822273254395e+00
    phi[3,1]  R1016     -1.7373734712600708e+00
    phi[3,1]  R1017     -9.1783905029296875e-01
    phi[3,1]  R1018     -6.0533422231674194e-01
    phi[3,1]  R1019     -2.1545746326446533e+00
    phi[3,1]  R1020     -2.96726655960083
    phi[3,1]  R1021     6.8251711130142212e-01
    phi[3,1]  R1022     -1.5084934234619141e-01
    phi[3,1]  R1023     -2.6604828834533691e+00
    phi[3,1]  R1024     -2.4222090244293213e+00
    phi[3,1]  R1025     -2.5566952228546143e+00
    phi[3,1]  R1026     7.0156955718994141e-01
    phi[3,1]  R1027     -3.6166664958000183e-01
    phi[3,1]  R1028     -8.8639140129089355e-01
    phi[3,1]  R1029     -1.1624594926834106e+00
    phi[3,1]  R1030     -2.2350578308105469e+00
    phi[3,1]  R1031     -5.0943724811077118e-02
    phi[3,1]  R1032     -3.4699410200119019e-01
    phi[3,1]  R1033     -7.4235385656356812e-01
    phi[3,1]  R1034     -7.9564118385314941e-01
    phi[3,1]  R1035     1.1546611785888672e+00
    phi[3,1]  R1036     -2.4434099197387695e+00
    phi[3,1]  R1037     2.2980399429798126e-01
    phi[3,1]  R1038     1.3935668393969536e-02
    phi[3,1]  R1039     7.9170316457748413e-01
    phi[3,1]  R1040     -6.8109005689620972e-02
    phi[3,1]  R1041     3.0138674378395081e-01
    phi[3,1]  R1042     -2.3395762443542480e+00
    phi[3,1]  R1043     2.4837329387664795e+00
    phi[3,1]  R1044     1.6853909492492676e+00
    phi[3,1]  R1045     3.1372466087341309e+00
    phi[3,1]  R1046     1.8665249347686768e+00
    phi[3,1]  R1047     9.9701762199401855e-01
    phi[3,1]  R1048     2.0978093147277832e+00
    phi[3,1]  R1049     2.1934351921081543e+00
    phi[3,1]  R1050     -1.5832924842834473e+00
    phi[3,1]  R1051     -5.1459020376205444e-01
    phi[3,1]  R1052     -1.1455730199813843e+00
    phi[3,1]  R1053     -1.5439590215682983e+00
    phi[3,1]  R1054     -2.8168959617614746e+00
    phi[3,1]  R1055     1.6582718491554260e-01
    phi[3,1]  R1056     -2.7671098709106445e+00
    phi[3,1]  R1057     -3.3922371864318848e+00
    phi[3,1]  R1058     -2.7125294208526611e+00
    phi[3,1]  R1059     -2.7979650497436523e+00
    phi[3,1]  R1060     -2.3651564121246338e+00
    phi[3,1]  R1061     -2.6886031627655029e+00
    phi[3,1]  R1062     -2.2302947044372559e+00
    phi[1,4]  R9        1
    phi[1,4]  R10       1
    phi[1,4]  R36       -1
    phi[1,4]  R1063     -3.0999999046325684e+00
    phi[1,4]  R1064     -3.0999999046325684e+00
    phi[1,4]  R1065     -2.2400000095367432e+00
    phi[1,4]  R1066     -2.2400000095367432e+00
    phi[1,4]  R1067     -3.0999999046325684e+00
    phi[1,4]  R1068     -3.0999999046325684e+00
    phi[1,4]  R1069     -2.5699999332427979e+00
    phi[1,4]  R1070     -2.5699999332427979e+00
    phi[1,4]  R1071     -3.0999999046325684e+00
    phi[1,4]  R1072     -3.0999999046325684e+00
    phi[1,4]  R1073     -2.0899999141693115e+00
    phi[1,4]  R1074     -2.0899999141693115e+00
    phi[1,4]  R1075     -3.0999999046325684e+00
    phi[1,4]  R1076     -3.0999999046325684e+00
    phi[1,4]  R1077     2.4837329387664795e+00
    phi[1,4]  R1078     1.6853909492492676e+00
    phi[1,4]  R1079     3.1372466087341309e+00
    phi[1,4]  R1080     1.8665249347686768e+00
    phi[1,4]  R1081     9.9701762199401855e-01
    phi[1,4]  R1082     2.0978093147277832e+00
    phi[1,4]  R1083     2.1934351921081543e+00
    phi[1,4]  R1084     -1.5832924842834473e+00
    phi[1,4]  R1085     -5.1459020376205444e-01
    phi[1,4]  R1086     -1.1455730199813843e+00
    phi[1,4]  R1087     -1.5439590215682983e+00
    phi[1,4]  R1088     -2.8168959617614746e+00
    phi[1,4]  R1089     1.6582718491554260e-01
    phi[1,4]  R1090     -2.7671098709106445e+00
    phi[1,4]  R1091     -3.3922371864318848e+00
    phi[1,4]  R1092     -2.7125294208526611e+00
    phi[1,4]  R1093     -2.7979650497436523e+00
    phi[1,4]  R1094     -2.3651564121246338e+00
    phi[1,4]  R1095     -2.6886031627655029e+00
    phi[1,4]  R1096     -2.2302947044372559e+00
    phi[1,4]  R1097     2.1473853588104248e+00
    phi[1,4]  R1098     3.5512828826904297e+00
    phi[1,4]  R1099     2.3660592734813690e-02
    phi[1,4]  R1100     -2.3547699451446533e+00
    phi[1,4]  R1101     -1.3744689226150513e+00
    phi[1,4]  R1102     -2.4668209552764893e+00
    phi[1,4]  R1103     -6.8081367015838623e-01
    phi[4,1]  R9        -1
    phi[4,1]  R36       1
    phi[4,1]  R37       1
    phi[4,1]  R1104     -3.0999999046325684e+00
    phi[4,1]  R1105     -3.0999999046325684e+00
    phi[4,1]  R1106     -2.2400000095367432e+00
    phi[4,1]  R1107     -2.2400000095367432e+00
    phi[4,1]  R1108     -3.0999999046325684e+00
    phi[4,1]  R1109     -3.0999999046325684e+00
    phi[4,1]  R1110     -2.5699999332427979e+00
    phi[4,1]  R1111     -2.5699999332427979e+00
    phi[4,1]  R1112     -3.0999999046325684e+00
    phi[4,1]  R1113     -3.0999999046325684e+00
    phi[4,1]  R1114     -2.0899999141693115e+00
    phi[4,1]  R1115     -2.0899999141693115e+00
    phi[4,1]  R1116     -3.0999999046325684e+00
    phi[4,1]  R1117     -3.0999999046325684e+00
    phi[4,1]  R1118     2.1473853588104248e+00
    phi[4,1]  R1119     3.5512828826904297e+00
    phi[4,1]  R1120     2.3660592734813690e-02
    phi[4,1]  R1121     -2.3547699451446533e+00
    phi[4,1]  R1122     -1.3744689226150513e+00
    phi[4,1]  R1123     -2.4668209552764893e+00
    phi[4,1]  R1124     -6.8081367015838623e-01
    phi[4,1]  R1125     2.4837329387664795e+00
    phi[4,1]  R1126     1.6853909492492676e+00
    phi[4,1]  R1127     3.1372466087341309e+00
    phi[4,1]  R1128     1.8665249347686768e+00
    phi[4,1]  R1129     9.9701762199401855e-01
    phi[4,1]  R1130     2.0978093147277832e+00
    phi[4,1]  R1131     2.1934351921081543e+00
    phi[4,1]  R1132     -1.5832924842834473e+00
    phi[4,1]  R1133     -5.1459020376205444e-01
    phi[4,1]  R1134     -1.1455730199813843e+00
    phi[4,1]  R1135     -1.5439590215682983e+00
    phi[4,1]  R1136     -2.8168959617614746e+00
    phi[4,1]  R1137     1.6582718491554260e-01
    phi[4,1]  R1138     -2.7671098709106445e+00
    phi[4,1]  R1139     -3.3922371864318848e+00
    phi[4,1]  R1140     -2.7125294208526611e+00
    phi[4,1]  R1141     -2.7979650497436523e+00
    phi[4,1]  R1142     -2.3651564121246338e+00
    phi[4,1]  R1143     -2.6886031627655029e+00
    phi[4,1]  R1144     -2.2302947044372559e+00
    phi[2,5]  R18       1
    phi[2,5]  R19       1
    phi[2,5]  R45       -1
    phi[2,5]  R1145     -3.0999999046325684e+00
    phi[2,5]  R1146     -3.0999999046325684e+00
    phi[2,5]  R1147     -2.2400000095367432e+00
    phi[2,5]  R1148     -2.2400000095367432e+00
    phi[2,5]  R1149     -3.0999999046325684e+00
    phi[2,5]  R1150     -3.0999999046325684e+00
    phi[2,5]  R1151     -2.5699999332427979e+00
    phi[2,5]  R1152     -2.5699999332427979e+00
    phi[2,5]  R1153     -3.0999999046325684e+00
    phi[2,5]  R1154     -3.0999999046325684e+00
    phi[2,5]  R1155     -2.0899999141693115e+00
    phi[2,5]  R1156     -2.0899999141693115e+00
    phi[2,5]  R1157     -3.0999999046325684e+00
    phi[2,5]  R1158     -3.0999999046325684e+00
    phi[2,5]  R1159     4.1008678078651428e-01
    phi[2,5]  R1160     1.4148714542388916e+00
    phi[2,5]  R1161     1.7850371599197388e+00
    phi[2,5]  R1162     1.3848644495010376e+00
    phi[2,5]  R1163     1.5156128406524658e+00
    phi[2,5]  R1164     1.1438711881637573e+00
    phi[2,5]  R1165     9.2052966356277466e-01
    phi[2,5]  R1166     8.0471515655517578e-01
    phi[2,5]  R1167     1.4304387569427490e+00
    phi[2,5]  R1168     1.8274284601211548e+00
    phi[2,5]  R1169     -5.7070219516754150e-01
    phi[2,5]  R1170     -1.9331947565078735e+00
    phi[2,5]  R1171     -3.5328283905982971e-01
    phi[2,5]  R1172     -1.2813565731048584e+00
    phi[2,5]  R1173     -1.5742076635360718e+00
    phi[2,5]  R1174     -1.9113100767135620e+00
    phi[2,5]  R1175     -1.7583810091018677e+00
    phi[2,5]  R1176     -2.9299590587615967e+00
    phi[2,5]  R1177     -1.0063059329986572e+00
    phi[2,5]  R1178     -2.0409960746765137e+00
    phi[2,5]  R1179     -4.6057811379432678e-01
    phi[2,5]  R1180     -1.0206776857376099e+00
    phi[2,5]  R1181     -6.7300218343734741e-01
    phi[2,5]  R1182     -1.4507640600204468e+00
    phi[2,5]  R1183     -1.2415980100631714e+00
    phi[2,5]  R1184     -1.9115267992019653e+00
    phi[2,5]  R1185     -1.7429038286209106e+00
    phi[2,5]  R1186     -1.7454320192337036e+00
    phi[2,5]  R1187     -2.5490555763244629e+00
    phi[2,5]  R1188     -2.0783612728118896e+00
    phi[2,5]  R1189     4.2241933941841125e-01
    phi[2,5]  R1190     -2.4720821380615234e+00
    phi[2,5]  R1191     -5.0461190938949585e-01
    phi[2,5]  R1192     -2.0483081340789795e+00
    phi[2,5]  R1193     -2.4797737598419189e+00
    phi[2,5]  R1194     -1.1015309095382690e+00
    phi[2,5]  R1195     -2.0985169410705566e+00
    phi[2,5]  R1196     -2.5460166931152344e+00
    phi[2,5]  R1197     -0.892280638217926
    phi[2,5]  R1198     -2.8630938529968262e+00
    phi[2,5]  R1199     -1.4065010547637939e+00
    phi[2,5]  R1200     -1.8193671703338623e+00
    phi[2,5]  R1201     1.8174457550048828e+00
    phi[2,5]  R1202     -1.7847700119018555e+00
    phi[2,5]  R1203     -1.7606725692749023e+00
    phi[2,5]  R1204     -9.1266989707946777e-01
    phi[2,5]  R1205     -1.4007629156112671e+00
    phi[2,5]  R1206     -1.2564861774444580e+00
    phi[2,5]  R1207     -2.0201244354248047e+00
    phi[2,5]  R1208     -1.8038753271102905e+00
    phi[2,5]  R1209     6.8764573335647583e-01
    phi[2,5]  R1210     -2.6196253299713135e+00
    phi[2,5]  R1211     -1.4968811273574829e+00
    phi[2,5]  R1212     -0.693366527557373
    phi[2,5]  R1213     -1.2255749702453613e+00
    phi[2,5]  R1214     -2.6455328464508057e+00
    phi[2,5]  R1215     -1.5244259834289551e+00
    phi[2,5]  R1216     -1.4864665269851685e+00
    phi[2,5]  R1217     -2.1929373741149902e+00
    phi[2,5]  R1218     -2.1977615356445312e+00
    phi[2,5]  R1219     5.1336884498596191e-01
    phi[2,5]  R1220     -1.9099996089935303e+00
    phi[2,5]  R1221     -6.0565841197967529e-01
    phi[2,5]  R1222     -1.4689265489578247e+00
    phi[2,5]  R1223     2.2705259323120117e+00
    phi[2,5]  R1224     -2.17315673828125
    phi[2,5]  R1225     -4.2671728134155273e+00
    phi[2,5]  R1226     -1.1492218971252441e+00
    phi[2,5]  R1227     -3.4993736743927
    phi[2,5]  R1228     -1.5138159990310669e+00
    phi[2,5]  R1229     2.0547320842742920e+00
    phi[2,5]  R1230     2.3970203399658203e+00
    phi[2,5]  R1231     2.2276077270507812e+00
    phi[2,5]  R1232     8.9211237430572510e-01
    phi[2,5]  R1233     3.0067729949951172e+00
    phi[2,5]  R1234     1.3223123550415039e+00
    phi[2,5]  R1235     -1.0413227081298828e+00
    phi[2,5]  R1236     5.1109659671783447e-01
    phi[2,5]  R1237     3.6869212985038757e-01
    phi[2,5]  R1238     -6.5319442749023438e-01
    phi[2,5]  R1239     -1.2251983880996704e+00
    phi[2,5]  R1240     -1.4624639749526978e+00
    phi[2,5]  R1241     -4.8959973454475403e-01
    phi[2,5]  R1242     -1.1903020143508911e+00
    phi[2,5]  R1243     -2.4406619071960449e+00
    phi[2,5]  R1244     -1.4852993488311768e+00
    phi[2,5]  R1245     -2.2074513435363770e+00
    phi[2,5]  R1246     1.9423446059226990e-01
    phi[2,5]  R1247     -5.7512871921062469e-02
    phi[2,5]  R1248     -5.7404935359954834e-01
    phi[2,5]  R1249     2.0424113273620605e+00
    phi[2,5]  R1250     -0.0942443236708641
    phi[2,5]  R1251     -2.1507289409637451e+00
    phi[2,5]  R1252     -3.5977885127067566e-01
    phi[2,5]  R1253     -1.0748401284217834e-02
    phi[2,5]  R1254     -1.30308198928833
    phi[2,5]  R1255     -0.332306444644928
    phi[2,5]  R1256     -3.9215514063835144e-01
    phi[2,5]  R1257     -2.32279109954834
    phi[2,5]  R1258     1.3623698949813843e+00
    phi[5,2]  R18       -1
    phi[5,2]  R45       1
    phi[5,2]  R46       1
    phi[5,2]  R1259     -3.0999999046325684e+00
    phi[5,2]  R1260     -3.0999999046325684e+00
    phi[5,2]  R1261     -2.2400000095367432e+00
    phi[5,2]  R1262     -2.2400000095367432e+00
    phi[5,2]  R1263     -3.0999999046325684e+00
    phi[5,2]  R1264     -3.0999999046325684e+00
    phi[5,2]  R1265     -2.5699999332427979e+00
    phi[5,2]  R1266     -2.5699999332427979e+00
    phi[5,2]  R1267     -3.0999999046325684e+00
    phi[5,2]  R1268     -3.0999999046325684e+00
    phi[5,2]  R1269     -2.0899999141693115e+00
    phi[5,2]  R1270     -2.0899999141693115e+00
    phi[5,2]  R1271     -3.0999999046325684e+00
    phi[5,2]  R1272     -3.0999999046325684e+00
    phi[5,2]  R1273     2.0547320842742920e+00
    phi[5,2]  R1274     2.3970203399658203e+00
    phi[5,2]  R1275     2.2276077270507812e+00
    phi[5,2]  R1276     8.9211237430572510e-01
    phi[5,2]  R1277     3.0067729949951172e+00
    phi[5,2]  R1278     1.3223123550415039e+00
    phi[5,2]  R1279     -1.0413227081298828e+00
    phi[5,2]  R1280     5.1109659671783447e-01
    phi[5,2]  R1281     3.6869212985038757e-01
    phi[5,2]  R1282     -6.5319442749023438e-01
    phi[5,2]  R1283     -1.2251983880996704e+00
    phi[5,2]  R1284     -1.4624639749526978e+00
    phi[5,2]  R1285     -4.8959973454475403e-01
    phi[5,2]  R1286     -1.1903020143508911e+00
    phi[5,2]  R1287     -2.4406619071960449e+00
    phi[5,2]  R1288     -1.4852993488311768e+00
    phi[5,2]  R1289     -2.2074513435363770e+00
    phi[5,2]  R1290     1.9423446059226990e-01
    phi[5,2]  R1291     -5.7512871921062469e-02
    phi[5,2]  R1292     -5.7404935359954834e-01
    phi[5,2]  R1293     2.0424113273620605e+00
    phi[5,2]  R1294     -0.0942443236708641
    phi[5,2]  R1295     -2.1507289409637451e+00
    phi[5,2]  R1296     -3.5977885127067566e-01
    phi[5,2]  R1297     -1.0748401284217834e-02
    phi[5,2]  R1298     -1.30308198928833
    phi[5,2]  R1299     -0.332306444644928
    phi[5,2]  R1300     -3.9215514063835144e-01
    phi[5,2]  R1301     -2.32279109954834
    phi[5,2]  R1302     1.3623698949813843e+00
    phi[5,2]  R1303     4.1008678078651428e-01
    phi[5,2]  R1304     1.4148714542388916e+00
    phi[5,2]  R1305     1.7850371599197388e+00
    phi[5,2]  R1306     1.3848644495010376e+00
    phi[5,2]  R1307     1.5156128406524658e+00
    phi[5,2]  R1308     1.1438711881637573e+00
    phi[5,2]  R1309     9.2052966356277466e-01
    phi[5,2]  R1310     8.0471515655517578e-01
    phi[5,2]  R1311     1.4304387569427490e+00
    phi[5,2]  R1312     1.8274284601211548e+00
    phi[5,2]  R1313     -5.7070219516754150e-01
    phi[5,2]  R1314     -1.9331947565078735e+00
    phi[5,2]  R1315     -3.5328283905982971e-01
    phi[5,2]  R1316     -1.2813565731048584e+00
    phi[5,2]  R1317     -1.5742076635360718e+00
    phi[5,2]  R1318     -1.9113100767135620e+00
    phi[5,2]  R1319     -1.7583810091018677e+00
    phi[5,2]  R1320     -2.9299590587615967e+00
    phi[5,2]  R1321     -1.0063059329986572e+00
    phi[5,2]  R1322     -2.0409960746765137e+00
    phi[5,2]  R1323     -4.6057811379432678e-01
    phi[5,2]  R1324     -1.0206776857376099e+00
    phi[5,2]  R1325     -6.7300218343734741e-01
    phi[5,2]  R1326     -1.4507640600204468e+00
    phi[5,2]  R1327     -1.2415980100631714e+00
    phi[5,2]  R1328     -1.9115267992019653e+00
    phi[5,2]  R1329     -1.7429038286209106e+00
    phi[5,2]  R1330     -1.7454320192337036e+00
    phi[5,2]  R1331     -2.5490555763244629e+00
    phi[5,2]  R1332     -2.0783612728118896e+00
    phi[5,2]  R1333     4.2241933941841125e-01
    phi[5,2]  R1334     -2.4720821380615234e+00
    phi[5,2]  R1335     -5.0461190938949585e-01
    phi[5,2]  R1336     -2.0483081340789795e+00
    phi[5,2]  R1337     -2.4797737598419189e+00
    phi[5,2]  R1338     -1.1015309095382690e+00
    phi[5,2]  R1339     -2.0985169410705566e+00
    phi[5,2]  R1340     -2.5460166931152344e+00
    phi[5,2]  R1341     -0.892280638217926
    phi[5,2]  R1342     -2.8630938529968262e+00
    phi[5,2]  R1343     -1.4065010547637939e+00
    phi[5,2]  R1344     -1.8193671703338623e+00
    phi[5,2]  R1345     1.8174457550048828e+00
    phi[5,2]  R1346     -1.7847700119018555e+00
    phi[5,2]  R1347     -1.7606725692749023e+00
    phi[5,2]  R1348     -9.1266989707946777e-01
    phi[5,2]  R1349     -1.4007629156112671e+00
    phi[5,2]  R1350     -1.2564861774444580e+00
    phi[5,2]  R1351     -2.0201244354248047e+00
    phi[5,2]  R1352     -1.8038753271102905e+00
    phi[5,2]  R1353     6.8764573335647583e-01
    phi[5,2]  R1354     -2.6196253299713135e+00
    phi[5,2]  R1355     -1.4968811273574829e+00
    phi[5,2]  R1356     -0.693366527557373
    phi[5,2]  R1357     -1.2255749702453613e+00
    phi[5,2]  R1358     -2.6455328464508057e+00
    phi[5,2]  R1359     -1.5244259834289551e+00
    phi[5,2]  R1360     -1.4864665269851685e+00
    phi[5,2]  R1361     -2.1929373741149902e+00
    phi[5,2]  R1362     -2.1977615356445312e+00
    phi[5,2]  R1363     5.1336884498596191e-01
    phi[5,2]  R1364     -1.9099996089935303e+00
    phi[5,2]  R1365     -6.0565841197967529e-01
    phi[5,2]  R1366     -1.4689265489578247e+00
    phi[5,2]  R1367     2.2705259323120117e+00
    phi[5,2]  R1368     -2.17315673828125
    phi[5,2]  R1369     -4.2671728134155273e+00
    phi[5,2]  R1370     -1.1492218971252441e+00
    phi[5,2]  R1371     -3.4993736743927
    phi[5,2]  R1372     -1.5138159990310669e+00
    phi[2,6]  R18       1
    phi[2,6]  R19       1
    phi[2,6]  R54       -1
    phi[2,6]  R1373     -3.0999999046325684e+00
    phi[2,6]  R1374     -3.0999999046325684e+00
    phi[2,6]  R1375     -2.2400000095367432e+00
    phi[2,6]  R1376     -2.2400000095367432e+00
    phi[2,6]  R1377     -3.0999999046325684e+00
    phi[2,6]  R1378     -3.0999999046325684e+00
    phi[2,6]  R1379     -2.5699999332427979e+00
    phi[2,6]  R1380     -2.5699999332427979e+00
    phi[2,6]  R1381     -3.0999999046325684e+00
    phi[2,6]  R1382     -3.0999999046325684e+00
    phi[2,6]  R1383     -2.0899999141693115e+00
    phi[2,6]  R1384     -2.0899999141693115e+00
    phi[2,6]  R1385     -3.0999999046325684e+00
    phi[2,6]  R1386     -3.0999999046325684e+00
    phi[2,6]  R1387     4.1008678078651428e-01
    phi[2,6]  R1388     1.4148714542388916e+00
    phi[2,6]  R1389     1.7850371599197388e+00
    phi[2,6]  R1390     1.3848644495010376e+00
    phi[2,6]  R1391     1.5156128406524658e+00
    phi[2,6]  R1392     1.1438711881637573e+00
    phi[2,6]  R1393     9.2052966356277466e-01
    phi[2,6]  R1394     8.0471515655517578e-01
    phi[2,6]  R1395     1.4304387569427490e+00
    phi[2,6]  R1396     1.8274284601211548e+00
    phi[2,6]  R1397     -5.7070219516754150e-01
    phi[2,6]  R1398     -1.9331947565078735e+00
    phi[2,6]  R1399     -3.5328283905982971e-01
    phi[2,6]  R1400     -1.2813565731048584e+00
    phi[2,6]  R1401     -1.5742076635360718e+00
    phi[2,6]  R1402     -1.9113100767135620e+00
    phi[2,6]  R1403     -1.7583810091018677e+00
    phi[2,6]  R1404     -2.9299590587615967e+00
    phi[2,6]  R1405     -1.0063059329986572e+00
    phi[2,6]  R1406     -2.0409960746765137e+00
    phi[2,6]  R1407     -4.6057811379432678e-01
    phi[2,6]  R1408     -1.0206776857376099e+00
    phi[2,6]  R1409     -6.7300218343734741e-01
    phi[2,6]  R1410     -1.4507640600204468e+00
    phi[2,6]  R1411     -1.2415980100631714e+00
    phi[2,6]  R1412     -1.9115267992019653e+00
    phi[2,6]  R1413     -1.7429038286209106e+00
    phi[2,6]  R1414     -1.7454320192337036e+00
    phi[2,6]  R1415     -2.5490555763244629e+00
    phi[2,6]  R1416     -2.0783612728118896e+00
    phi[2,6]  R1417     4.2241933941841125e-01
    phi[2,6]  R1418     -2.4720821380615234e+00
    phi[2,6]  R1419     -5.0461190938949585e-01
    phi[2,6]  R1420     -2.0483081340789795e+00
    phi[2,6]  R1421     -2.4797737598419189e+00
    phi[2,6]  R1422     -1.1015309095382690e+00
    phi[2,6]  R1423     -2.0985169410705566e+00
    phi[2,6]  R1424     -2.5460166931152344e+00
    phi[2,6]  R1425     -0.892280638217926
    phi[2,6]  R1426     -2.8630938529968262e+00
    phi[2,6]  R1427     -1.4065010547637939e+00
    phi[2,6]  R1428     -1.8193671703338623e+00
    phi[2,6]  R1429     1.8174457550048828e+00
    phi[2,6]  R1430     -1.7847700119018555e+00
    phi[2,6]  R1431     -1.7606725692749023e+00
    phi[2,6]  R1432     -9.1266989707946777e-01
    phi[2,6]  R1433     -1.4007629156112671e+00
    phi[2,6]  R1434     -1.2564861774444580e+00
    phi[2,6]  R1435     -2.0201244354248047e+00
    phi[2,6]  R1436     -1.8038753271102905e+00
    phi[2,6]  R1437     6.8764573335647583e-01
    phi[2,6]  R1438     -2.6196253299713135e+00
    phi[2,6]  R1439     -1.4968811273574829e+00
    phi[2,6]  R1440     -0.693366527557373
    phi[2,6]  R1441     -1.2255749702453613e+00
    phi[2,6]  R1442     -2.6455328464508057e+00
    phi[2,6]  R1443     -1.5244259834289551e+00
    phi[2,6]  R1444     -1.4864665269851685e+00
    phi[2,6]  R1445     -2.1929373741149902e+00
    phi[2,6]  R1446     -2.1977615356445312e+00
    phi[2,6]  R1447     5.1336884498596191e-01
    phi[2,6]  R1448     -1.9099996089935303e+00
    phi[2,6]  R1449     -6.0565841197967529e-01
    phi[2,6]  R1450     -1.4689265489578247e+00
    phi[2,6]  R1451     2.2705259323120117e+00
    phi[2,6]  R1452     -2.17315673828125
    phi[2,6]  R1453     -4.2671728134155273e+00
    phi[2,6]  R1454     -1.1492218971252441e+00
    phi[2,6]  R1455     -3.4993736743927
    phi[2,6]  R1456     -1.5138159990310669e+00
    phi[2,6]  R1457     -4.4887340068817139e-01
    phi[2,6]  R1458     1.8410005569458008e+00
    phi[2,6]  R1459     1.0291942358016968e+00
    phi[2,6]  R1460     -5.7248646020889282e-01
    phi[2,6]  R1461     -3.5377240180969238e-01
    phi[2,6]  R1462     1.4618672132492065e+00
    phi[2,6]  R1463     1.5862666368484497e+00
    phi[2,6]  R1464     1.3586605787277222e+00
    phi[2,6]  R1465     1.2851508855819702e+00
    phi[2,6]  R1466     1.1690555810928345e+00
    phi[2,6]  R1467     -3.7980475425720215e+00
    phi[2,6]  R1468     -9.3184328079223633e-01
    phi[2,6]  R1469     -1.1182374954223633e+00
    phi[2,6]  R1470     -2.5062024593353271e+00
    phi[2,6]  R1471     -2.8289487361907959e+00
    phi[2,6]  R1472     -1.6770845651626587e+00
    phi[2,6]  R1473     -3.3943238258361816e+00
    phi[2,6]  R1474     -3.5236594676971436e+00
    phi[2,6]  R1475     -2.9863250255584717e+00
    phi[2,6]  R1476     -1.6350164413452148e+00
    phi[2,6]  R1477     -1.1230404376983643e+00
    phi[2,6]  R1478     -1.1939041614532471e+00
    phi[2,6]  R1479     -6.3470703363418579e-01
    phi[2,6]  R1480     -1.5893433094024658e+00
    phi[2,6]  R1481     -8.0088895559310913e-01
    phi[2,6]  R1482     -2.6468822956085205e+00
    phi[2,6]  R1483     -1.1620893478393555e+00
    phi[2,6]  R1484     -1.9369337558746338e+00
    phi[2,6]  R1485     -2.6547074317932129e+00
    phi[2,6]  R1486     -5.5746906995773315e-01
    phi[2,6]  R1487     -2.4093558788299561e+00
    phi[2,6]  R1488     9.1601449251174927e-01
    phi[2,6]  R1489     -1.2179270982742310e+00
    phi[2,6]  R1490     -2.6195199489593506e+00
    phi[2,6]  R1491     -7.4381911754608154e-01
    phi[2,6]  R1492     -1.8680911064147949e+00
    phi[2,6]  R1493     -1.7311065196990967e+00
    phi[2,6]  R1494     9.2801815271377563e-01
    phi[2,6]  R1495     -1.4915663003921509e-01
    phi[2,6]  R1496     -8.5833948105573654e-03
    phi[2,6]  R1497     -2.9609489440917969e+00
    phi[2,6]  R1498     -7.0598572492599487e-01
    phi[2,6]  R1499     -2.9948833584785461e-01
    phi[2,6]  R1500     -1.7499134540557861e+00
    phi[2,6]  R1501     -1.6728262901306152e+00
    phi[2,6]  R1502     -2.3102476596832275e+00
    phi[2,6]  R1503     -1.0701379179954529e-01
    phi[2,6]  R1504     -1.7260553836822510e+00
    phi[2,6]  R1505     -1.5358881950378418e+00
    phi[2,6]  R1506     -1.9854332208633423e+00
    phi[2,6]  R1507     -9.0941292047500610e-01
    phi[2,6]  R1508     3.0173569917678833e-02
    phi[2,6]  R1509     -1.5659482479095459e+00
    phi[2,6]  R1510     -7.9849117994308472e-01
    phi[2,6]  R1511     -1.5661815404891968e+00
    phi[2,6]  R1512     -2.4583146572113037e+00
    phi[2,6]  R1513     -2.0377678871154785e+00
    phi[2,6]  R1514     -9.1178727149963379e-01
    phi[2,6]  R1515     1.0132249593734741e+00
    phi[2,6]  R1516     3.3183494210243225e-01
    phi[2,6]  R1517     7.5110960006713867e-01
    phi[2,6]  R1518     -1.0323907136917114e+00
    phi[2,6]  R1519     -2.5941061973571777e+00
    phi[2,6]  R1520     -7.7746713161468506e-01
    phi[2,6]  R1521     -1.0238239765167236e+00
    phi[2,6]  R1522     4.7961139678955078e-01
    phi[2,6]  R1523     -1.6154683828353882e+00
    phi[2,6]  R1524     -1.7361077070236206e+00
    phi[2,6]  R1525     -1.9173234701156616e+00
    phi[2,6]  R1526     -1.4181159734725952e+00
    phi[6,2]  R18       -1
    phi[6,2]  R54       1
    phi[6,2]  R55       1
    phi[6,2]  R1527     -3.0999999046325684e+00
    phi[6,2]  R1528     -3.0999999046325684e+00
    phi[6,2]  R1529     -2.2400000095367432e+00
    phi[6,2]  R1530     -2.2400000095367432e+00
    phi[6,2]  R1531     -3.0999999046325684e+00
    phi[6,2]  R1532     -3.0999999046325684e+00
    phi[6,2]  R1533     -2.5699999332427979e+00
    phi[6,2]  R1534     -2.5699999332427979e+00
    phi[6,2]  R1535     -3.0999999046325684e+00
    phi[6,2]  R1536     -3.0999999046325684e+00
    phi[6,2]  R1537     -2.0899999141693115e+00
    phi[6,2]  R1538     -2.0899999141693115e+00
    phi[6,2]  R1539     -3.0999999046325684e+00
    phi[6,2]  R1540     -3.0999999046325684e+00
    phi[6,2]  R1541     -4.4887340068817139e-01
    phi[6,2]  R1542     1.8410005569458008e+00
    phi[6,2]  R1543     1.0291942358016968e+00
    phi[6,2]  R1544     -5.7248646020889282e-01
    phi[6,2]  R1545     -3.5377240180969238e-01
    phi[6,2]  R1546     1.4618672132492065e+00
    phi[6,2]  R1547     1.5862666368484497e+00
    phi[6,2]  R1548     1.3586605787277222e+00
    phi[6,2]  R1549     1.2851508855819702e+00
    phi[6,2]  R1550     1.1690555810928345e+00
    phi[6,2]  R1551     -3.7980475425720215e+00
    phi[6,2]  R1552     -9.3184328079223633e-01
    phi[6,2]  R1553     -1.1182374954223633e+00
    phi[6,2]  R1554     -2.5062024593353271e+00
    phi[6,2]  R1555     -2.8289487361907959e+00
    phi[6,2]  R1556     -1.6770845651626587e+00
    phi[6,2]  R1557     -3.3943238258361816e+00
    phi[6,2]  R1558     -3.5236594676971436e+00
    phi[6,2]  R1559     -2.9863250255584717e+00
    phi[6,2]  R1560     -1.6350164413452148e+00
    phi[6,2]  R1561     -1.1230404376983643e+00
    phi[6,2]  R1562     -1.1939041614532471e+00
    phi[6,2]  R1563     -6.3470703363418579e-01
    phi[6,2]  R1564     -1.5893433094024658e+00
    phi[6,2]  R1565     -8.0088895559310913e-01
    phi[6,2]  R1566     -2.6468822956085205e+00
    phi[6,2]  R1567     -1.1620893478393555e+00
    phi[6,2]  R1568     -1.9369337558746338e+00
    phi[6,2]  R1569     -2.6547074317932129e+00
    phi[6,2]  R1570     -5.5746906995773315e-01
    phi[6,2]  R1571     -2.4093558788299561e+00
    phi[6,2]  R1572     9.1601449251174927e-01
    phi[6,2]  R1573     -1.2179270982742310e+00
    phi[6,2]  R1574     -2.6195199489593506e+00
    phi[6,2]  R1575     -7.4381911754608154e-01
    phi[6,2]  R1576     -1.8680911064147949e+00
    phi[6,2]  R1577     -1.7311065196990967e+00
    phi[6,2]  R1578     9.2801815271377563e-01
    phi[6,2]  R1579     -1.4915663003921509e-01
    phi[6,2]  R1580     -8.5833948105573654e-03
    phi[6,2]  R1581     -2.9609489440917969e+00
    phi[6,2]  R1582     -7.0598572492599487e-01
    phi[6,2]  R1583     -2.9948833584785461e-01
    phi[6,2]  R1584     -1.7499134540557861e+00
    phi[6,2]  R1585     -1.6728262901306152e+00
    phi[6,2]  R1586     -2.3102476596832275e+00
    phi[6,2]  R1587     -1.0701379179954529e-01
    phi[6,2]  R1588     -1.7260553836822510e+00
    phi[6,2]  R1589     -1.5358881950378418e+00
    phi[6,2]  R1590     -1.9854332208633423e+00
    phi[6,2]  R1591     -9.0941292047500610e-01
    phi[6,2]  R1592     3.0173569917678833e-02
    phi[6,2]  R1593     -1.5659482479095459e+00
    phi[6,2]  R1594     -7.9849117994308472e-01
    phi[6,2]  R1595     -1.5661815404891968e+00
    phi[6,2]  R1596     -2.4583146572113037e+00
    phi[6,2]  R1597     -2.0377678871154785e+00
    phi[6,2]  R1598     -9.1178727149963379e-01
    phi[6,2]  R1599     1.0132249593734741e+00
    phi[6,2]  R1600     3.3183494210243225e-01
    phi[6,2]  R1601     7.5110960006713867e-01
    phi[6,2]  R1602     -1.0323907136917114e+00
    phi[6,2]  R1603     -2.5941061973571777e+00
    phi[6,2]  R1604     -7.7746713161468506e-01
    phi[6,2]  R1605     -1.0238239765167236e+00
    phi[6,2]  R1606     4.7961139678955078e-01
    phi[6,2]  R1607     -1.6154683828353882e+00
    phi[6,2]  R1608     -1.7361077070236206e+00
    phi[6,2]  R1609     -1.9173234701156616e+00
    phi[6,2]  R1610     -1.4181159734725952e+00
    phi[6,2]  R1611     4.1008678078651428e-01
    phi[6,2]  R1612     1.4148714542388916e+00
    phi[6,2]  R1613     1.7850371599197388e+00
    phi[6,2]  R1614     1.3848644495010376e+00
    phi[6,2]  R1615     1.5156128406524658e+00
    phi[6,2]  R1616     1.1438711881637573e+00
    phi[6,2]  R1617     9.2052966356277466e-01
    phi[6,2]  R1618     8.0471515655517578e-01
    phi[6,2]  R1619     1.4304387569427490e+00
    phi[6,2]  R1620     1.8274284601211548e+00
    phi[6,2]  R1621     -5.7070219516754150e-01
    phi[6,2]  R1622     -1.9331947565078735e+00
    phi[6,2]  R1623     -3.5328283905982971e-01
    phi[6,2]  R1624     -1.2813565731048584e+00
    phi[6,2]  R1625     -1.5742076635360718e+00
    phi[6,2]  R1626     -1.9113100767135620e+00
    phi[6,2]  R1627     -1.7583810091018677e+00
    phi[6,2]  R1628     -2.9299590587615967e+00
    phi[6,2]  R1629     -1.0063059329986572e+00
    phi[6,2]  R1630     -2.0409960746765137e+00
    phi[6,2]  R1631     -4.6057811379432678e-01
    phi[6,2]  R1632     -1.0206776857376099e+00
    phi[6,2]  R1633     -6.7300218343734741e-01
    phi[6,2]  R1634     -1.4507640600204468e+00
    phi[6,2]  R1635     -1.2415980100631714e+00
    phi[6,2]  R1636     -1.9115267992019653e+00
    phi[6,2]  R1637     -1.7429038286209106e+00
    phi[6,2]  R1638     -1.7454320192337036e+00
    phi[6,2]  R1639     -2.5490555763244629e+00
    phi[6,2]  R1640     -2.0783612728118896e+00
    phi[6,2]  R1641     4.2241933941841125e-01
    phi[6,2]  R1642     -2.4720821380615234e+00
    phi[6,2]  R1643     -5.0461190938949585e-01
    phi[6,2]  R1644     -2.0483081340789795e+00
    phi[6,2]  R1645     -2.4797737598419189e+00
    phi[6,2]  R1646     -1.1015309095382690e+00
    phi[6,2]  R1647     -2.0985169410705566e+00
    phi[6,2]  R1648     -2.5460166931152344e+00
    phi[6,2]  R1649     -0.892280638217926
    phi[6,2]  R1650     -2.8630938529968262e+00
    phi[6,2]  R1651     -1.4065010547637939e+00
    phi[6,2]  R1652     -1.8193671703338623e+00
    phi[6,2]  R1653     1.8174457550048828e+00
    phi[6,2]  R1654     -1.7847700119018555e+00
    phi[6,2]  R1655     -1.7606725692749023e+00
    phi[6,2]  R1656     -9.1266989707946777e-01
    phi[6,2]  R1657     -1.4007629156112671e+00
    phi[6,2]  R1658     -1.2564861774444580e+00
    phi[6,2]  R1659     -2.0201244354248047e+00
    phi[6,2]  R1660     -1.8038753271102905e+00
    phi[6,2]  R1661     6.8764573335647583e-01
    phi[6,2]  R1662     -2.6196253299713135e+00
    phi[6,2]  R1663     -1.4968811273574829e+00
    phi[6,2]  R1664     -0.693366527557373
    phi[6,2]  R1665     -1.2255749702453613e+00
    phi[6,2]  R1666     -2.6455328464508057e+00
    phi[6,2]  R1667     -1.5244259834289551e+00
    phi[6,2]  R1668     -1.4864665269851685e+00
    phi[6,2]  R1669     -2.1929373741149902e+00
    phi[6,2]  R1670     -2.1977615356445312e+00
    phi[6,2]  R1671     5.1336884498596191e-01
    phi[6,2]  R1672     -1.9099996089935303e+00
    phi[6,2]  R1673     -6.0565841197967529e-01
    phi[6,2]  R1674     -1.4689265489578247e+00
    phi[6,2]  R1675     2.2705259323120117e+00
    phi[6,2]  R1676     -2.17315673828125
    phi[6,2]  R1677     -4.2671728134155273e+00
    phi[6,2]  R1678     -1.1492218971252441e+00
    phi[6,2]  R1679     -3.4993736743927
    phi[6,2]  R1680     -1.5138159990310669e+00
    phi[2,8]  R18       1
    phi[2,8]  R19       1
    phi[2,8]  R20       1.3628997693946137e+00
    phi[2,8]  R21       1.01924182184423
    phi[2,8]  R22       2.1038569914873366e+00
    phi[2,8]  R23       4.7779016334331015e-02
    phi[2,8]  R24       1.6636994450194549e+00
    phi[2,8]  R25       -1.2054864416783269e+00
    phi[2,8]  R26       2.0638702292383542e+00
    phi[2,8]  R64       -1
    phi[2,8]  R1681     -1.7371001352379547e+00
    phi[2,8]  R1682     -4.4628996740271818e+00
    phi[2,8]  R1683     -1.2207581876925131e+00
    phi[2,8]  R1684     -3.2592418313809732e+00
    phi[2,8]  R1685     -9.9614291314523173e-01
    phi[2,8]  R1686     -5.2038568961199054e+00
    phi[2,8]  R1687     -2.5222209169084668e+00
    phi[2,8]  R1688     -2.6177789495771289e+00
    phi[2,8]  R1689     -1.4363004596131135e+00
    phi[2,8]  R1690     -4.7636993496520237e+00
    phi[2,8]  R1691     -3.2954863558476384e+00
    phi[2,8]  R1692     -8.8451347249098466e-01
    phi[2,8]  R1693     -1.0361296753942142e+00
    phi[2,8]  R1694     -5.1638701338709225e+00
    phi[2,8]  R1695     -4.3102326528296742e-01
    phi[2,8]  R1696     -8.0659062314714269e-01
    phi[2,8]  R1697     -4.3173829873396485e-01
    phi[2,8]  R1698     -0.43848171779136
    phi[2,8]  R1699     -4.3907317903102649e-01
    phi[2,8]  R1700     -0.441143822948014
    phi[2,8]  R1701     -4.4637367000892425e-01
    phi[2,8]  R1702     -9.0157963800867225e-01
    phi[2,8]  R1703     -0.578795621757898
    phi[2,8]  R1704     -4.6352204438206135e-01
    phi[2,8]  R1705     -7.1957962322572033e-01
    phi[2,8]  R1706     -6.4054218822421127e-01
    phi[2,8]  R1707     -6.4108596710281263e-01
    phi[2,8]  R1708     -7.5107721602273614e-01
    phi[2,8]  R1709     -6.9291820096022594e-01
    phi[2,8]  R1710     -6.5891158094830926e-01
    phi[2,8]  R1711     -6.8616279931332214e-01
    phi[2,8]  R1712     -6.8633716150803936e-01
    phi[2,8]  R1713     -6.8766717080424566e-01
    phi[2,8]  R1714     -6.9430290329878486e-01
    phi[2,8]  R1715     -0.524191667546039
    phi[2,8]  R1716     -0.558458139154351
    phi[2,8]  R1717     -5.5955584237254485e-01
    phi[2,8]  R1718     -5.6572396881127052e-01
    phi[2,8]  R1719     -0.568202220327767
    phi[2,8]  R1720     -5.7933123299847011e-01
    phi[2,8]  R1721     -0.583065226129527
    phi[2,8]  R1722     -5.9017750273526914e-01
    phi[2,8]  R1723     -5.9887611254725548e-01
    phi[2,8]  R1724     -6.0708340852515663e-01
    phi[2,8]  R1725     -4.8486209442494443e-01
    phi[2,8]  R1726     -6.2292379524349917e-01
    phi[2,8]  R1727     -5.7741866303259981e-01
    phi[2,8]  R1728     -0.916844957262501
    phi[2,8]  R1729     -1.5945743139933994e+00
    phi[2,8]  R1730     -6.2341038765593826e-01
    phi[2,8]  R1731     -6.4809177432439391e-01
    phi[2,8]  R1732     -6.6358930821104112e-01
    phi[2,8]  R1733     -6.9340596950077638e-01
    phi[2,8]  R1734     -1.2659378054453982e+00
    phi[2,8]  R1735     -5.5805656211418675e-01
    phi[2,8]  R1736     -2.3032840844040718e+00
    phi[2,8]  R1737     -7.0533789284857429e-01
    phi[2,8]  R1738     -9.8467156907780240e-01
    phi[2,8]  R1739     -1.5340547485911480e+00
    phi[2,8]  R1740     -7.9384143921350381e-01
    phi[2,8]  R1741     -1.2925499359289556e+00
    phi[2,8]  R1742     -1.8873642032966309e+00
    phi[2,8]  R1743     -8.4096175024228348e-01
    phi[2,8]  R1744     -8.5062326380595477e-01
    phi[2,8]  R1745     -1.9926885198014732e+00
    phi[2,8]  R1746     -1.2264504308506714e+00
    phi[2,8]  R1747     -5.9852866340942190e-01
    phi[2,8]  R1748     -0.654761271261076
    phi[2,8]  R1749     -1.4126681251346247e+00
    phi[2,8]  R1750     -6.6876219887382282e-01
    phi[2,8]  R1751     -2.3407827320903651e+00
    phi[2,8]  R1752     -6.7492391373763272e-01
    phi[2,8]  R1753     -7.0016007999473073e-01
    phi[2,8]  R1754     -2.2344810435842097e+00
    phi[2,8]  R1755     -4.9337088582017707e-01
    phi[2,8]  R1756     -5.4861389938120109e-01
    phi[2,8]  R1757     -6.0591356147107334e-01
    phi[2,8]  R1758     -6.4049067085528777e-01
    phi[2,8]  R1759     -7.3063800747933438e-01
    phi[2,8]  R1760     -2.48074369279103
    phi[2,8]  R1761     -1.7663114977009338e+00
    phi[2,8]  R1762     -2.1728815392521708e+00
    phi[2,8]  R1763     -1.2372642038208608e+00
    phi[2,8]  R1764     -2.0408120171973279e+00
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R1765     -3.0999999046325684e+00
    phi[3,4]  R1766     -3.0999999046325684e+00
    phi[3,4]  R1767     -2.2400000095367432e+00
    phi[3,4]  R1768     -2.2400000095367432e+00
    phi[3,4]  R1769     -3.0999999046325684e+00
    phi[3,4]  R1770     -3.0999999046325684e+00
    phi[3,4]  R1771     -2.5699999332427979e+00
    phi[3,4]  R1772     -2.5699999332427979e+00
    phi[3,4]  R1773     -3.0999999046325684e+00
    phi[3,4]  R1774     -3.0999999046325684e+00
    phi[3,4]  R1775     -2.0899999141693115e+00
    phi[3,4]  R1776     -2.0899999141693115e+00
    phi[3,4]  R1777     -3.0999999046325684e+00
    phi[3,4]  R1778     -3.0999999046325684e+00
    phi[3,4]  R1779     1.1394909620285034e+00
    phi[3,4]  R1780     6.4374661445617676e-01
    phi[3,4]  R1781     1.9511861801147461e+00
    phi[3,4]  R1782     1.2518910169601440e+00
    phi[3,4]  R1783     1.6011964082717896e+00
    phi[3,4]  R1784     -1.9887217283248901e+00
    phi[3,4]  R1785     0.54656982421875
    phi[3,4]  R1786     1.6618834435939789e-01
    phi[3,4]  R1787     6.6286253929138184e-01
    phi[3,4]  R1788     2.0448982715606689e+00
    phi[3,4]  R1789     -1.4534476995468140e+00
    phi[3,4]  R1790     -1.7219181060791016e+00
    phi[3,4]  R1791     -0.510861337184906
    phi[3,4]  R1792     -0.573452353477478
    phi[3,4]  R1793     -2.8334765434265137e+00
    phi[3,4]  R1794     -7.3426139354705811e-01
    phi[3,4]  R1795     -2.3278372287750244e+00
    phi[3,4]  R1796     -1.5832860469818115e+00
    phi[3,4]  R1797     -3.1779150962829590e+00
    phi[3,4]  R1798     4.8815757036209106e-01
    phi[3,4]  R1799     -2.2887065410614014e+00
    phi[3,4]  R1800     -1.7561002969741821e+00
    phi[3,4]  R1801     -2.4729170799255371e+00
    phi[3,4]  R1802     1.1507622003555298e+00
    phi[3,4]  R1803     -3.1201667785644531e+00
    phi[3,4]  R1804     -1.6336566209793091e+00
    phi[3,4]  R1805     -1.3498240709304810e+00
    phi[3,4]  R1806     -1.2046080827713013e+00
    phi[3,4]  R1807     -1.0881104469299316e+00
    phi[3,4]  R1808     -7.1604549884796143e-01
    phi[3,4]  R1809     -3.0683481693267822e+00
    phi[3,4]  R1810     -1.2112450599670410e+00
    phi[3,4]  R1811     -2.3587906360626221e+00
    phi[3,4]  R1812     -3.7835183143615723e+00
    phi[3,4]  R1813     -3.9307682514190674e+00
    phi[3,4]  R1814     7.5676834583282471e-01
    phi[3,4]  R1815     -3.9228883385658264e-01
    phi[3,4]  R1816     1.1633410453796387e+00
    phi[3,4]  R1817     3.7607144564390182e-02
    phi[3,4]  R1818     4.1826650500297546e-01
    phi[3,4]  R1819     -2.6692178249359131e+00
    phi[3,4]  R1820     -2.0207812786102295e+00
    phi[3,4]  R1821     -2.8295145034790039e+00
    phi[3,4]  R1822     -2.7925615310668945e+00
    phi[3,4]  R1823     -1.55397367477417
    phi[3,4]  R1824     -2.8401713371276855e+00
    phi[3,4]  R1825     -3.6304659843444824e+00
    phi[3,4]  R1826     -1.6500231623649597e-01
    phi[3,4]  R1827     -1.3065891265869141e+00
    phi[3,4]  R1828     -5.1544207334518433e-01
    phi[3,4]  R1829     -1.9361305236816406e+00
    phi[3,4]  R1830     7.7429658174514771e-01
    phi[3,4]  R1831     -3.2938530445098877e+00
    phi[3,4]  R1832     9.9765557050704956e-01
    phi[3,4]  R1833     -1.8263802528381348e+00
    phi[3,4]  R1834     -1.3313270807266235e+00
    phi[3,4]  R1835     -1.8956589698791504e+00
    phi[3,4]  R1836     -1.6193647384643555e+00
    phi[3,4]  R1837     -6.3351303339004517e-01
    phi[3,4]  R1838     -1.8266658782958984e+00
    phi[3,4]  R1839     -2.3801701068878174e+00
    phi[3,4]  R1840     -2.6733088493347168e+00
    phi[3,4]  R1841     -1.4359822273254395e+00
    phi[3,4]  R1842     -1.7373734712600708e+00
    phi[3,4]  R1843     -9.1783905029296875e-01
    phi[3,4]  R1844     -6.0533422231674194e-01
    phi[3,4]  R1845     -2.1545746326446533e+00
    phi[3,4]  R1846     -2.96726655960083
    phi[3,4]  R1847     6.8251711130142212e-01
    phi[3,4]  R1848     -1.5084934234619141e-01
    phi[3,4]  R1849     -2.6604828834533691e+00
    phi[3,4]  R1850     -2.4222090244293213e+00
    phi[3,4]  R1851     -2.5566952228546143e+00
    phi[3,4]  R1852     7.0156955718994141e-01
    phi[3,4]  R1853     -3.6166664958000183e-01
    phi[3,4]  R1854     -8.8639140129089355e-01
    phi[3,4]  R1855     -1.1624594926834106e+00
    phi[3,4]  R1856     -2.2350578308105469e+00
    phi[3,4]  R1857     -5.0943724811077118e-02
    phi[3,4]  R1858     -3.4699410200119019e-01
    phi[3,4]  R1859     -7.4235385656356812e-01
    phi[3,4]  R1860     -7.9564118385314941e-01
    phi[3,4]  R1861     1.1546611785888672e+00
    phi[3,4]  R1862     -2.4434099197387695e+00
    phi[3,4]  R1863     2.2980399429798126e-01
    phi[3,4]  R1864     1.3935668393969536e-02
    phi[3,4]  R1865     7.9170316457748413e-01
    phi[3,4]  R1866     -6.8109005689620972e-02
    phi[3,4]  R1867     3.0138674378395081e-01
    phi[3,4]  R1868     -2.3395762443542480e+00
    phi[3,4]  R1869     2.1473853588104248e+00
    phi[3,4]  R1870     3.5512828826904297e+00
    phi[3,4]  R1871     2.3660592734813690e-02
    phi[3,4]  R1872     -2.3547699451446533e+00
    phi[3,4]  R1873     -1.3744689226150513e+00
    phi[3,4]  R1874     -2.4668209552764893e+00
    phi[3,4]  R1875     -6.8081367015838623e-01
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R1876     -3.0999999046325684e+00
    phi[4,3]  R1877     -3.0999999046325684e+00
    phi[4,3]  R1878     -2.2400000095367432e+00
    phi[4,3]  R1879     -2.2400000095367432e+00
    phi[4,3]  R1880     -3.0999999046325684e+00
    phi[4,3]  R1881     -3.0999999046325684e+00
    phi[4,3]  R1882     -2.5699999332427979e+00
    phi[4,3]  R1883     -2.5699999332427979e+00
    phi[4,3]  R1884     -3.0999999046325684e+00
    phi[4,3]  R1885     -3.0999999046325684e+00
    phi[4,3]  R1886     -2.0899999141693115e+00
    phi[4,3]  R1887     -2.0899999141693115e+00
    phi[4,3]  R1888     -3.0999999046325684e+00
    phi[4,3]  R1889     -3.0999999046325684e+00
    phi[4,3]  R1890     2.1473853588104248e+00
    phi[4,3]  R1891     3.5512828826904297e+00
    phi[4,3]  R1892     2.3660592734813690e-02
    phi[4,3]  R1893     -2.3547699451446533e+00
    phi[4,3]  R1894     -1.3744689226150513e+00
    phi[4,3]  R1895     -2.4668209552764893e+00
    phi[4,3]  R1896     -6.8081367015838623e-01
    phi[4,3]  R1897     1.1394909620285034e+00
    phi[4,3]  R1898     6.4374661445617676e-01
    phi[4,3]  R1899     1.9511861801147461e+00
    phi[4,3]  R1900     1.2518910169601440e+00
    phi[4,3]  R1901     1.6011964082717896e+00
    phi[4,3]  R1902     -1.9887217283248901e+00
    phi[4,3]  R1903     0.54656982421875
    phi[4,3]  R1904     1.6618834435939789e-01
    phi[4,3]  R1905     6.6286253929138184e-01
    phi[4,3]  R1906     2.0448982715606689e+00
    phi[4,3]  R1907     -1.4534476995468140e+00
    phi[4,3]  R1908     -1.7219181060791016e+00
    phi[4,3]  R1909     -0.510861337184906
    phi[4,3]  R1910     -0.573452353477478
    phi[4,3]  R1911     -2.8334765434265137e+00
    phi[4,3]  R1912     -7.3426139354705811e-01
    phi[4,3]  R1913     -2.3278372287750244e+00
    phi[4,3]  R1914     -1.5832860469818115e+00
    phi[4,3]  R1915     -3.1779150962829590e+00
    phi[4,3]  R1916     4.8815757036209106e-01
    phi[4,3]  R1917     -2.2887065410614014e+00
    phi[4,3]  R1918     -1.7561002969741821e+00
    phi[4,3]  R1919     -2.4729170799255371e+00
    phi[4,3]  R1920     1.1507622003555298e+00
    phi[4,3]  R1921     -3.1201667785644531e+00
    phi[4,3]  R1922     -1.6336566209793091e+00
    phi[4,3]  R1923     -1.3498240709304810e+00
    phi[4,3]  R1924     -1.2046080827713013e+00
    phi[4,3]  R1925     -1.0881104469299316e+00
    phi[4,3]  R1926     -7.1604549884796143e-01
    phi[4,3]  R1927     -3.0683481693267822e+00
    phi[4,3]  R1928     -1.2112450599670410e+00
    phi[4,3]  R1929     -2.3587906360626221e+00
    phi[4,3]  R1930     -3.7835183143615723e+00
    phi[4,3]  R1931     -3.9307682514190674e+00
    phi[4,3]  R1932     7.5676834583282471e-01
    phi[4,3]  R1933     -3.9228883385658264e-01
    phi[4,3]  R1934     1.1633410453796387e+00
    phi[4,3]  R1935     3.7607144564390182e-02
    phi[4,3]  R1936     4.1826650500297546e-01
    phi[4,3]  R1937     -2.6692178249359131e+00
    phi[4,3]  R1938     -2.0207812786102295e+00
    phi[4,3]  R1939     -2.8295145034790039e+00
    phi[4,3]  R1940     -2.7925615310668945e+00
    phi[4,3]  R1941     -1.55397367477417
    phi[4,3]  R1942     -2.8401713371276855e+00
    phi[4,3]  R1943     -3.6304659843444824e+00
    phi[4,3]  R1944     -1.6500231623649597e-01
    phi[4,3]  R1945     -1.3065891265869141e+00
    phi[4,3]  R1946     -5.1544207334518433e-01
    phi[4,3]  R1947     -1.9361305236816406e+00
    phi[4,3]  R1948     7.7429658174514771e-01
    phi[4,3]  R1949     -3.2938530445098877e+00
    phi[4,3]  R1950     9.9765557050704956e-01
    phi[4,3]  R1951     -1.8263802528381348e+00
    phi[4,3]  R1952     -1.3313270807266235e+00
    phi[4,3]  R1953     -1.8956589698791504e+00
    phi[4,3]  R1954     -1.6193647384643555e+00
    phi[4,3]  R1955     -6.3351303339004517e-01
    phi[4,3]  R1956     -1.8266658782958984e+00
    phi[4,3]  R1957     -2.3801701068878174e+00
    phi[4,3]  R1958     -2.6733088493347168e+00
    phi[4,3]  R1959     -1.4359822273254395e+00
    phi[4,3]  R1960     -1.7373734712600708e+00
    phi[4,3]  R1961     -9.1783905029296875e-01
    phi[4,3]  R1962     -6.0533422231674194e-01
    phi[4,3]  R1963     -2.1545746326446533e+00
    phi[4,3]  R1964     -2.96726655960083
    phi[4,3]  R1965     6.8251711130142212e-01
    phi[4,3]  R1966     -1.5084934234619141e-01
    phi[4,3]  R1967     -2.6604828834533691e+00
    phi[4,3]  R1968     -2.4222090244293213e+00
    phi[4,3]  R1969     -2.5566952228546143e+00
    phi[4,3]  R1970     7.0156955718994141e-01
    phi[4,3]  R1971     -3.6166664958000183e-01
    phi[4,3]  R1972     -8.8639140129089355e-01
    phi[4,3]  R1973     -1.1624594926834106e+00
    phi[4,3]  R1974     -2.2350578308105469e+00
    phi[4,3]  R1975     -5.0943724811077118e-02
    phi[4,3]  R1976     -3.4699410200119019e-01
    phi[4,3]  R1977     -7.4235385656356812e-01
    phi[4,3]  R1978     -7.9564118385314941e-01
    phi[4,3]  R1979     1.1546611785888672e+00
    phi[4,3]  R1980     -2.4434099197387695e+00
    phi[4,3]  R1981     2.2980399429798126e-01
    phi[4,3]  R1982     1.3935668393969536e-02
    phi[4,3]  R1983     7.9170316457748413e-01
    phi[4,3]  R1984     -6.8109005689620972e-02
    phi[4,3]  R1985     3.0138674378395081e-01
    phi[4,3]  R1986     -2.3395762443542480e+00
    phi[7,3]  R27       -1
    phi[7,3]  R29       0.436132660285212
    phi[7,3]  R30       -6.5293115906839816e-01
    phi[7,3]  R31       1.4403253088833403e+00
    phi[7,3]  R32       -1.6897541231401312e+00
    phi[7,3]  R33       -2.19870963770369
    phi[7,3]  R34       1.0017387778479798e+00
    phi[7,3]  R35       1.6473301255492978e+00
    phi[7,3]  R63       1
    phi[7,3]  R1987     -3.5361325649177804e+00
    phi[7,3]  R1988     -2.6638672443473563e+00
    phi[7,3]  R1989     -1.5870688504683450e+00
    phi[7,3]  R1990     -2.8929311686051413e+00
    phi[7,3]  R1991     -4.5403252135159082e+00
    phi[7,3]  R1992     -1.6596745957492280e+00
    phi[7,3]  R1993     -8.8024581010266667e-01
    phi[7,3]  R1994     -4.2597540563829295e+00
    phi[7,3]  R1995     -9.0129026692887848e-01
    phi[7,3]  R1996     -5.2987095423362582e+00
    phi[7,3]  R1997     -3.0917386920172913e+00
    phi[7,3]  R1998     -1.0882611363213317e+00
    phi[7,3]  R1999     -4.7473300301818657e+00
    phi[7,3]  R2000     -1.4526697790832706e+00
    phi[7,3]  R2001     -5.8336014263731606e-01
    phi[7,3]  R2002     -5.8940412107843176e-01
    phi[7,3]  R2003     -6.0673277305660633e-01
    phi[7,3]  R2004     -6.1331330846073717e-01
    phi[7,3]  R2005     -6.2519170928273571e-01
    phi[7,3]  R2006     -6.2753100747599833e-01
    phi[7,3]  R2007     -6.2888970061339666e-01
    phi[7,3]  R2008     -6.2915598538969875e-01
    phi[7,3]  R2009     -0.629174993868507
    phi[7,3]  R2010     -6.3232343358467968e-01
    phi[7,3]  R2011     -6.0978577772727383e-01
    phi[7,3]  R2012     -6.2859886872919035e-01
    phi[7,3]  R2013     -6.3508886320883540e-01
    phi[7,3]  R2014     -6.3904576198466678e-01
    phi[7,3]  R2015     -6.4785985477924868e-01
    phi[7,3]  R2016     -6.5648816613756589e-01
    phi[7,3]  R2017     -6.6021943939756533e-01
    phi[7,3]  R2018     -6.6153176322663410e-01
    phi[7,3]  R2019     -6.6954301134806382e-01
    phi[7,3]  R2020     -6.7184404301694189e-01
    phi[7,3]  R2021     -6.0668147319034471e-01
    phi[7,3]  R2022     -0.673463372989229
    phi[7,3]  R2023     -6.9331866656790808e-01
    phi[7,3]  R2024     -1.5259673377383720e+00
    phi[7,3]  R2025     -7.4165891181655752e-01
    phi[7,3]  R2026     -7.4945640735578056e-01
    phi[7,3]  R2027     -7.5242547231700385e-01
    phi[7,3]  R2028     -7.5413285951417119e-01
    phi[7,3]  R2029     -0.754644557321114
    phi[7,3]  R2030     -7.5828457000445371e-01
    phi[7,3]  R2031     -6.1923902750840787e-01
    phi[7,3]  R2032     -6.2700385404311176e-01
    phi[7,3]  R2033     -6.5328671104286240e-01
    phi[7,3]  R2034     -6.6350993350737619e-01
    phi[7,3]  R2035     -6.7722855240830437e-01
    phi[7,3]  R2036     -1.9471781855415995e+00
    phi[7,3]  R2037     -6.8931063704239082e-01
    phi[7,3]  R2038     -1.7556099056775385e+00
    phi[7,3]  R2039     -7.2914322809226384e-01
    phi[7,3]  R2040     -7.4956777678077291e-01
    phi[7,3]  R2041     -0.536243718242321
    phi[7,3]  R2042     -5.9730993072569794e-01
    phi[7,3]  R2043     -6.0125122023393418e-01
    phi[7,3]  R2044     -6.1129675803754191e-01
    phi[7,3]  R2045     -6.3520440969192771e-01
    phi[7,3]  R2046     -6.7079950628612828e-01
    phi[7,3]  R2047     -6.7119698679182882e-01
    phi[7,3]  R2048     -7.1519637314013018e-01
    phi[7,3]  R2049     -7.2565821639587136e-01
    phi[7,3]  R2050     -7.3704749400088754e-01
    phi[7,3]  R2051     -5.4467371318878532e-01
    phi[7,3]  R2052     -0.576204272791101
    phi[7,3]  R2053     -5.9082251743795888e-01
    phi[7,3]  R2054     -5.9785562540877968e-01
    phi[7,3]  R2055     -6.2098007531733268e-01
    phi[7,3]  R2056     -6.2216635452987590e-01
    phi[7,3]  R2057     -6.3292671245509435e-01
    phi[7,3]  R2058     -6.6246190874408772e-01
    phi[7,3]  R2059     -6.8904444843005064e-01
    phi[7,3]  R2060     -7.0536617525749667e-01
    phi[7,3]  R2061     -0.576180287475589
    phi[7,3]  R2062     -5.8778149912510491e-01
    phi[7,3]  R2063     -6.5380474257403232e-01
    phi[7,3]  R2064     -6.7298711412712109e-01
    phi[7,3]  R2065     -7.0554854862362293e-01
    phi[7,3]  R2066     -7.0782364883657034e-01
    phi[7,3]  R2067     -7.1419811528164789e-01
    phi[7,3]  R2068     -0.722765060073645
    phi[7,3]  R2069     -7.2543811636634015e-01
    phi[7,3]  R2070     -0.95772560096612
    phi[7,3]  R2071     -0.518608637498474
    phi[7,3]  R2072     -5.7657255104203342e-01
    phi[7,3]  R2073     -1.2391692755981008e+00
    phi[7,3]  R2074     -6.6404225468731881e-01
    phi[7,3]  R2075     -0.702312776228807
    phi[7,3]  R2076     -7.2555062978490570e-01
    phi[7,3]  R2077     -7.4075283881403475e-01
    phi[7,3]  R2078     -7.4234891161859440e-01
    phi[7,3]  R2079     -7.4402282302277911e-01
    phi[7,3]  R2080     -7.5164899198699331e-01
    phi[7,3]  R2081     -3.4663757619439639e-01
    phi[7,3]  R2082     -6.4943263045336175e-01
    phi[7,3]  R2083     -6.5017406479656570e-01
    phi[7,3]  R2084     -6.5581427306993589e-01
    phi[7,3]  R2085     -6.6088506883397358e-01
    phi[7,3]  R2086     -6.6395724018301594e-01
    phi[7,3]  R2087     -9.3353030951442317e-01
    phi[7,3]  R2088     -1.9111609520289563e+00
    phi[7,3]  R2089     -7.1205034904344355e-01
    phi[7,3]  R2090     -7.5737213080649290e-01
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R2091     -3.0999999046325684e+00
    phi[4,5]  R2092     -3.0999999046325684e+00
    phi[4,5]  R2093     -2.2400000095367432e+00
    phi[4,5]  R2094     -2.2400000095367432e+00
    phi[4,5]  R2095     -3.0999999046325684e+00
    phi[4,5]  R2096     -3.0999999046325684e+00
    phi[4,5]  R2097     -2.5699999332427979e+00
    phi[4,5]  R2098     -2.5699999332427979e+00
    phi[4,5]  R2099     -3.0999999046325684e+00
    phi[4,5]  R2100     -3.0999999046325684e+00
    phi[4,5]  R2101     -2.0899999141693115e+00
    phi[4,5]  R2102     -2.0899999141693115e+00
    phi[4,5]  R2103     -3.0999999046325684e+00
    phi[4,5]  R2104     -3.0999999046325684e+00
    phi[4,5]  R2105     2.1473853588104248e+00
    phi[4,5]  R2106     3.5512828826904297e+00
    phi[4,5]  R2107     2.3660592734813690e-02
    phi[4,5]  R2108     -2.3547699451446533e+00
    phi[4,5]  R2109     -1.3744689226150513e+00
    phi[4,5]  R2110     -2.4668209552764893e+00
    phi[4,5]  R2111     -6.8081367015838623e-01
    phi[4,5]  R2112     2.0547320842742920e+00
    phi[4,5]  R2113     2.3970203399658203e+00
    phi[4,5]  R2114     2.2276077270507812e+00
    phi[4,5]  R2115     8.9211237430572510e-01
    phi[4,5]  R2116     3.0067729949951172e+00
    phi[4,5]  R2117     1.3223123550415039e+00
    phi[4,5]  R2118     -1.0413227081298828e+00
    phi[4,5]  R2119     5.1109659671783447e-01
    phi[4,5]  R2120     3.6869212985038757e-01
    phi[4,5]  R2121     -6.5319442749023438e-01
    phi[4,5]  R2122     -1.2251983880996704e+00
    phi[4,5]  R2123     -1.4624639749526978e+00
    phi[4,5]  R2124     -4.8959973454475403e-01
    phi[4,5]  R2125     -1.1903020143508911e+00
    phi[4,5]  R2126     -2.4406619071960449e+00
    phi[4,5]  R2127     -1.4852993488311768e+00
    phi[4,5]  R2128     -2.2074513435363770e+00
    phi[4,5]  R2129     1.9423446059226990e-01
    phi[4,5]  R2130     -5.7512871921062469e-02
    phi[4,5]  R2131     -5.7404935359954834e-01
    phi[4,5]  R2132     2.0424113273620605e+00
    phi[4,5]  R2133     -0.0942443236708641
    phi[4,5]  R2134     -2.1507289409637451e+00
    phi[4,5]  R2135     -3.5977885127067566e-01
    phi[4,5]  R2136     -1.0748401284217834e-02
    phi[4,5]  R2137     -1.30308198928833
    phi[4,5]  R2138     -0.332306444644928
    phi[4,5]  R2139     -3.9215514063835144e-01
    phi[4,5]  R2140     -2.32279109954834
    phi[4,5]  R2141     1.3623698949813843e+00
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R2142     -3.0999999046325684e+00
    phi[5,4]  R2143     -3.0999999046325684e+00
    phi[5,4]  R2144     -2.2400000095367432e+00
    phi[5,4]  R2145     -2.2400000095367432e+00
    phi[5,4]  R2146     -3.0999999046325684e+00
    phi[5,4]  R2147     -3.0999999046325684e+00
    phi[5,4]  R2148     -2.5699999332427979e+00
    phi[5,4]  R2149     -2.5699999332427979e+00
    phi[5,4]  R2150     -3.0999999046325684e+00
    phi[5,4]  R2151     -3.0999999046325684e+00
    phi[5,4]  R2152     -2.0899999141693115e+00
    phi[5,4]  R2153     -2.0899999141693115e+00
    phi[5,4]  R2154     -3.0999999046325684e+00
    phi[5,4]  R2155     -3.0999999046325684e+00
    phi[5,4]  R2156     2.0547320842742920e+00
    phi[5,4]  R2157     2.3970203399658203e+00
    phi[5,4]  R2158     2.2276077270507812e+00
    phi[5,4]  R2159     8.9211237430572510e-01
    phi[5,4]  R2160     3.0067729949951172e+00
    phi[5,4]  R2161     1.3223123550415039e+00
    phi[5,4]  R2162     -1.0413227081298828e+00
    phi[5,4]  R2163     5.1109659671783447e-01
    phi[5,4]  R2164     3.6869212985038757e-01
    phi[5,4]  R2165     -6.5319442749023438e-01
    phi[5,4]  R2166     -1.2251983880996704e+00
    phi[5,4]  R2167     -1.4624639749526978e+00
    phi[5,4]  R2168     -4.8959973454475403e-01
    phi[5,4]  R2169     -1.1903020143508911e+00
    phi[5,4]  R2170     -2.4406619071960449e+00
    phi[5,4]  R2171     -1.4852993488311768e+00
    phi[5,4]  R2172     -2.2074513435363770e+00
    phi[5,4]  R2173     1.9423446059226990e-01
    phi[5,4]  R2174     -5.7512871921062469e-02
    phi[5,4]  R2175     -5.7404935359954834e-01
    phi[5,4]  R2176     2.0424113273620605e+00
    phi[5,4]  R2177     -0.0942443236708641
    phi[5,4]  R2178     -2.1507289409637451e+00
    phi[5,4]  R2179     -3.5977885127067566e-01
    phi[5,4]  R2180     -1.0748401284217834e-02
    phi[5,4]  R2181     -1.30308198928833
    phi[5,4]  R2182     -0.332306444644928
    phi[5,4]  R2183     -3.9215514063835144e-01
    phi[5,4]  R2184     -2.32279109954834
    phi[5,4]  R2185     1.3623698949813843e+00
    phi[5,4]  R2186     2.1473853588104248e+00
    phi[5,4]  R2187     3.5512828826904297e+00
    phi[5,4]  R2188     2.3660592734813690e-02
    phi[5,4]  R2189     -2.3547699451446533e+00
    phi[5,4]  R2190     -1.3744689226150513e+00
    phi[5,4]  R2191     -2.4668209552764893e+00
    phi[5,4]  R2192     -6.8081367015838623e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R2193     -3.0999999046325684e+00
    phi[5,6]  R2194     -3.0999999046325684e+00
    phi[5,6]  R2195     -2.2400000095367432e+00
    phi[5,6]  R2196     -2.2400000095367432e+00
    phi[5,6]  R2197     -3.0999999046325684e+00
    phi[5,6]  R2198     -3.0999999046325684e+00
    phi[5,6]  R2199     -2.5699999332427979e+00
    phi[5,6]  R2200     -2.5699999332427979e+00
    phi[5,6]  R2201     -3.0999999046325684e+00
    phi[5,6]  R2202     -3.0999999046325684e+00
    phi[5,6]  R2203     -2.0899999141693115e+00
    phi[5,6]  R2204     -2.0899999141693115e+00
    phi[5,6]  R2205     -3.0999999046325684e+00
    phi[5,6]  R2206     -3.0999999046325684e+00
    phi[5,6]  R2207     2.0547320842742920e+00
    phi[5,6]  R2208     2.3970203399658203e+00
    phi[5,6]  R2209     2.2276077270507812e+00
    phi[5,6]  R2210     8.9211237430572510e-01
    phi[5,6]  R2211     3.0067729949951172e+00
    phi[5,6]  R2212     1.3223123550415039e+00
    phi[5,6]  R2213     -1.0413227081298828e+00
    phi[5,6]  R2214     5.1109659671783447e-01
    phi[5,6]  R2215     3.6869212985038757e-01
    phi[5,6]  R2216     -6.5319442749023438e-01
    phi[5,6]  R2217     -1.2251983880996704e+00
    phi[5,6]  R2218     -1.4624639749526978e+00
    phi[5,6]  R2219     -4.8959973454475403e-01
    phi[5,6]  R2220     -1.1903020143508911e+00
    phi[5,6]  R2221     -2.4406619071960449e+00
    phi[5,6]  R2222     -1.4852993488311768e+00
    phi[5,6]  R2223     -2.2074513435363770e+00
    phi[5,6]  R2224     1.9423446059226990e-01
    phi[5,6]  R2225     -5.7512871921062469e-02
    phi[5,6]  R2226     -5.7404935359954834e-01
    phi[5,6]  R2227     2.0424113273620605e+00
    phi[5,6]  R2228     -0.0942443236708641
    phi[5,6]  R2229     -2.1507289409637451e+00
    phi[5,6]  R2230     -3.5977885127067566e-01
    phi[5,6]  R2231     -1.0748401284217834e-02
    phi[5,6]  R2232     -1.30308198928833
    phi[5,6]  R2233     -0.332306444644928
    phi[5,6]  R2234     -3.9215514063835144e-01
    phi[5,6]  R2235     -2.32279109954834
    phi[5,6]  R2236     1.3623698949813843e+00
    phi[5,6]  R2237     -4.4887340068817139e-01
    phi[5,6]  R2238     1.8410005569458008e+00
    phi[5,6]  R2239     1.0291942358016968e+00
    phi[5,6]  R2240     -5.7248646020889282e-01
    phi[5,6]  R2241     -3.5377240180969238e-01
    phi[5,6]  R2242     1.4618672132492065e+00
    phi[5,6]  R2243     1.5862666368484497e+00
    phi[5,6]  R2244     1.3586605787277222e+00
    phi[5,6]  R2245     1.2851508855819702e+00
    phi[5,6]  R2246     1.1690555810928345e+00
    phi[5,6]  R2247     -3.7980475425720215e+00
    phi[5,6]  R2248     -9.3184328079223633e-01
    phi[5,6]  R2249     -1.1182374954223633e+00
    phi[5,6]  R2250     -2.5062024593353271e+00
    phi[5,6]  R2251     -2.8289487361907959e+00
    phi[5,6]  R2252     -1.6770845651626587e+00
    phi[5,6]  R2253     -3.3943238258361816e+00
    phi[5,6]  R2254     -3.5236594676971436e+00
    phi[5,6]  R2255     -2.9863250255584717e+00
    phi[5,6]  R2256     -1.6350164413452148e+00
    phi[5,6]  R2257     -1.1230404376983643e+00
    phi[5,6]  R2258     -1.1939041614532471e+00
    phi[5,6]  R2259     -6.3470703363418579e-01
    phi[5,6]  R2260     -1.5893433094024658e+00
    phi[5,6]  R2261     -8.0088895559310913e-01
    phi[5,6]  R2262     -2.6468822956085205e+00
    phi[5,6]  R2263     -1.1620893478393555e+00
    phi[5,6]  R2264     -1.9369337558746338e+00
    phi[5,6]  R2265     -2.6547074317932129e+00
    phi[5,6]  R2266     -5.5746906995773315e-01
    phi[5,6]  R2267     -2.4093558788299561e+00
    phi[5,6]  R2268     9.1601449251174927e-01
    phi[5,6]  R2269     -1.2179270982742310e+00
    phi[5,6]  R2270     -2.6195199489593506e+00
    phi[5,6]  R2271     -7.4381911754608154e-01
    phi[5,6]  R2272     -1.8680911064147949e+00
    phi[5,6]  R2273     -1.7311065196990967e+00
    phi[5,6]  R2274     9.2801815271377563e-01
    phi[5,6]  R2275     -1.4915663003921509e-01
    phi[5,6]  R2276     -8.5833948105573654e-03
    phi[5,6]  R2277     -2.9609489440917969e+00
    phi[5,6]  R2278     -7.0598572492599487e-01
    phi[5,6]  R2279     -2.9948833584785461e-01
    phi[5,6]  R2280     -1.7499134540557861e+00
    phi[5,6]  R2281     -1.6728262901306152e+00
    phi[5,6]  R2282     -2.3102476596832275e+00
    phi[5,6]  R2283     -1.0701379179954529e-01
    phi[5,6]  R2284     -1.7260553836822510e+00
    phi[5,6]  R2285     -1.5358881950378418e+00
    phi[5,6]  R2286     -1.9854332208633423e+00
    phi[5,6]  R2287     -9.0941292047500610e-01
    phi[5,6]  R2288     3.0173569917678833e-02
    phi[5,6]  R2289     -1.5659482479095459e+00
    phi[5,6]  R2290     -7.9849117994308472e-01
    phi[5,6]  R2291     -1.5661815404891968e+00
    phi[5,6]  R2292     -2.4583146572113037e+00
    phi[5,6]  R2293     -2.0377678871154785e+00
    phi[5,6]  R2294     -9.1178727149963379e-01
    phi[5,6]  R2295     1.0132249593734741e+00
    phi[5,6]  R2296     3.3183494210243225e-01
    phi[5,6]  R2297     7.5110960006713867e-01
    phi[5,6]  R2298     -1.0323907136917114e+00
    phi[5,6]  R2299     -2.5941061973571777e+00
    phi[5,6]  R2300     -7.7746713161468506e-01
    phi[5,6]  R2301     -1.0238239765167236e+00
    phi[5,6]  R2302     4.7961139678955078e-01
    phi[5,6]  R2303     -1.6154683828353882e+00
    phi[5,6]  R2304     -1.7361077070236206e+00
    phi[5,6]  R2305     -1.9173234701156616e+00
    phi[5,6]  R2306     -1.4181159734725952e+00
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2307     -3.0999999046325684e+00
    phi[6,5]  R2308     -3.0999999046325684e+00
    phi[6,5]  R2309     -2.2400000095367432e+00
    phi[6,5]  R2310     -2.2400000095367432e+00
    phi[6,5]  R2311     -3.0999999046325684e+00
    phi[6,5]  R2312     -3.0999999046325684e+00
    phi[6,5]  R2313     -2.5699999332427979e+00
    phi[6,5]  R2314     -2.5699999332427979e+00
    phi[6,5]  R2315     -3.0999999046325684e+00
    phi[6,5]  R2316     -3.0999999046325684e+00
    phi[6,5]  R2317     -2.0899999141693115e+00
    phi[6,5]  R2318     -2.0899999141693115e+00
    phi[6,5]  R2319     -3.0999999046325684e+00
    phi[6,5]  R2320     -3.0999999046325684e+00
    phi[6,5]  R2321     -4.4887340068817139e-01
    phi[6,5]  R2322     1.8410005569458008e+00
    phi[6,5]  R2323     1.0291942358016968e+00
    phi[6,5]  R2324     -5.7248646020889282e-01
    phi[6,5]  R2325     -3.5377240180969238e-01
    phi[6,5]  R2326     1.4618672132492065e+00
    phi[6,5]  R2327     1.5862666368484497e+00
    phi[6,5]  R2328     1.3586605787277222e+00
    phi[6,5]  R2329     1.2851508855819702e+00
    phi[6,5]  R2330     1.1690555810928345e+00
    phi[6,5]  R2331     -3.7980475425720215e+00
    phi[6,5]  R2332     -9.3184328079223633e-01
    phi[6,5]  R2333     -1.1182374954223633e+00
    phi[6,5]  R2334     -2.5062024593353271e+00
    phi[6,5]  R2335     -2.8289487361907959e+00
    phi[6,5]  R2336     -1.6770845651626587e+00
    phi[6,5]  R2337     -3.3943238258361816e+00
    phi[6,5]  R2338     -3.5236594676971436e+00
    phi[6,5]  R2339     -2.9863250255584717e+00
    phi[6,5]  R2340     -1.6350164413452148e+00
    phi[6,5]  R2341     -1.1230404376983643e+00
    phi[6,5]  R2342     -1.1939041614532471e+00
    phi[6,5]  R2343     -6.3470703363418579e-01
    phi[6,5]  R2344     -1.5893433094024658e+00
    phi[6,5]  R2345     -8.0088895559310913e-01
    phi[6,5]  R2346     -2.6468822956085205e+00
    phi[6,5]  R2347     -1.1620893478393555e+00
    phi[6,5]  R2348     -1.9369337558746338e+00
    phi[6,5]  R2349     -2.6547074317932129e+00
    phi[6,5]  R2350     -5.5746906995773315e-01
    phi[6,5]  R2351     -2.4093558788299561e+00
    phi[6,5]  R2352     9.1601449251174927e-01
    phi[6,5]  R2353     -1.2179270982742310e+00
    phi[6,5]  R2354     -2.6195199489593506e+00
    phi[6,5]  R2355     -7.4381911754608154e-01
    phi[6,5]  R2356     -1.8680911064147949e+00
    phi[6,5]  R2357     -1.7311065196990967e+00
    phi[6,5]  R2358     9.2801815271377563e-01
    phi[6,5]  R2359     -1.4915663003921509e-01
    phi[6,5]  R2360     -8.5833948105573654e-03
    phi[6,5]  R2361     -2.9609489440917969e+00
    phi[6,5]  R2362     -7.0598572492599487e-01
    phi[6,5]  R2363     -2.9948833584785461e-01
    phi[6,5]  R2364     -1.7499134540557861e+00
    phi[6,5]  R2365     -1.6728262901306152e+00
    phi[6,5]  R2366     -2.3102476596832275e+00
    phi[6,5]  R2367     -1.0701379179954529e-01
    phi[6,5]  R2368     -1.7260553836822510e+00
    phi[6,5]  R2369     -1.5358881950378418e+00
    phi[6,5]  R2370     -1.9854332208633423e+00
    phi[6,5]  R2371     -9.0941292047500610e-01
    phi[6,5]  R2372     3.0173569917678833e-02
    phi[6,5]  R2373     -1.5659482479095459e+00
    phi[6,5]  R2374     -7.9849117994308472e-01
    phi[6,5]  R2375     -1.5661815404891968e+00
    phi[6,5]  R2376     -2.4583146572113037e+00
    phi[6,5]  R2377     -2.0377678871154785e+00
    phi[6,5]  R2378     -9.1178727149963379e-01
    phi[6,5]  R2379     1.0132249593734741e+00
    phi[6,5]  R2380     3.3183494210243225e-01
    phi[6,5]  R2381     7.5110960006713867e-01
    phi[6,5]  R2382     -1.0323907136917114e+00
    phi[6,5]  R2383     -2.5941061973571777e+00
    phi[6,5]  R2384     -7.7746713161468506e-01
    phi[6,5]  R2385     -1.0238239765167236e+00
    phi[6,5]  R2386     4.7961139678955078e-01
    phi[6,5]  R2387     -1.6154683828353882e+00
    phi[6,5]  R2388     -1.7361077070236206e+00
    phi[6,5]  R2389     -1.9173234701156616e+00
    phi[6,5]  R2390     -1.4181159734725952e+00
    phi[6,5]  R2391     2.0547320842742920e+00
    phi[6,5]  R2392     2.3970203399658203e+00
    phi[6,5]  R2393     2.2276077270507812e+00
    phi[6,5]  R2394     8.9211237430572510e-01
    phi[6,5]  R2395     3.0067729949951172e+00
    phi[6,5]  R2396     1.3223123550415039e+00
    phi[6,5]  R2397     -1.0413227081298828e+00
    phi[6,5]  R2398     5.1109659671783447e-01
    phi[6,5]  R2399     3.6869212985038757e-01
    phi[6,5]  R2400     -6.5319442749023438e-01
    phi[6,5]  R2401     -1.2251983880996704e+00
    phi[6,5]  R2402     -1.4624639749526978e+00
    phi[6,5]  R2403     -4.8959973454475403e-01
    phi[6,5]  R2404     -1.1903020143508911e+00
    phi[6,5]  R2405     -2.4406619071960449e+00
    phi[6,5]  R2406     -1.4852993488311768e+00
    phi[6,5]  R2407     -2.2074513435363770e+00
    phi[6,5]  R2408     1.9423446059226990e-01
    phi[6,5]  R2409     -5.7512871921062469e-02
    phi[6,5]  R2410     -5.7404935359954834e-01
    phi[6,5]  R2411     2.0424113273620605e+00
    phi[6,5]  R2412     -0.0942443236708641
    phi[6,5]  R2413     -2.1507289409637451e+00
    phi[6,5]  R2414     -3.5977885127067566e-01
    phi[6,5]  R2415     -1.0748401284217834e-02
    phi[6,5]  R2416     -1.30308198928833
    phi[6,5]  R2417     -0.332306444644928
    phi[6,5]  R2418     -3.9215514063835144e-01
    phi[6,5]  R2419     -2.32279109954834
    phi[6,5]  R2420     1.3623698949813843e+00
    phi[6,8]  R54       1
    phi[6,8]  R55       1
    phi[6,8]  R56       1.3628997693946137e+00
    phi[6,8]  R57       1.01924182184423
    phi[6,8]  R58       2.1038569914873366e+00
    phi[6,8]  R59       4.7779016334331015e-02
    phi[6,8]  R60       1.6636994450194549e+00
    phi[6,8]  R61       -1.2054864416783269e+00
    phi[6,8]  R62       2.0638702292383542e+00
    phi[6,8]  R64       -1
    phi[6,8]  R2421     -1.7371001352379547e+00
    phi[6,8]  R2422     -4.4628996740271818e+00
    phi[6,8]  R2423     -1.2207581876925131e+00
    phi[6,8]  R2424     -3.2592418313809732e+00
    phi[6,8]  R2425     -9.9614291314523173e-01
    phi[6,8]  R2426     -5.2038568961199054e+00
    phi[6,8]  R2427     -2.5222209169084668e+00
    phi[6,8]  R2428     -2.6177789495771289e+00
    phi[6,8]  R2429     -1.4363004596131135e+00
    phi[6,8]  R2430     -4.7636993496520237e+00
    phi[6,8]  R2431     -3.2954863558476384e+00
    phi[6,8]  R2432     -8.8451347249098466e-01
    phi[6,8]  R2433     -1.0361296753942142e+00
    phi[6,8]  R2434     -5.1638701338709225e+00
    phi[6,8]  R2435     -2.8709423451469840e-01
    phi[6,8]  R2436     -4.8184196214548569e-01
    phi[6,8]  R2437     -4.2353398251008012e-01
    phi[6,8]  R2438     -0.988426128564071
    phi[6,8]  R2439     -6.8213851248703838e-01
    phi[6,8]  R2440     -4.2862008029790744e-01
    phi[6,8]  R2441     -4.3303278606457019e-01
    phi[6,8]  R2442     -4.3761784094048939e-01
    phi[6,8]  R2443     -4.4002859992521159e-01
    phi[6,8]  R2444     -4.5099585389658503e-01
    phi[6,8]  R2445     -5.7351906021237120e-01
    phi[6,8]  R2446     -6.3325469300671844e-01
    phi[6,8]  R2447     -8.3856553005141232e-01
    phi[6,8]  R2448     -7.1040028610607253e-01
    phi[6,8]  R2449     -7.4748654145037108e-01
    phi[6,8]  R2450     -0.923391903513859
    phi[6,8]  R2451     -7.8175349131752547e-01
    phi[6,8]  R2452     -0.794265480974135
    phi[6,8]  R2453     -8.1235401584870059e-01
    phi[6,8]  R2454     -8.2593081963202386e-01
    phi[6,8]  R2455     -4.9456690050107677e-01
    phi[6,8]  R2456     -6.0513373209829824e-01
    phi[6,8]  R2457     -6.5582062498605065e-01
    phi[6,8]  R2458     -6.5912363273409258e-01
    phi[6,8]  R2459     -8.9316781767590347e-01
    phi[6,8]  R2460     -0.741338195466736
    phi[6,8]  R2461     -9.0779031715170466e-01
    phi[6,8]  R2462     -8.1355056441897511e-01
    phi[6,8]  R2463     -9.1620962772807490e-01
    phi[6,8]  R2464     -9.6965472371884009e-01
    phi[6,8]  R2465     -0.879327937422977
    phi[6,8]  R2466     -9.9007830653861628e-01
    phi[6,8]  R2467     -8.0568683546953523e-01
    phi[6,8]  R2468     -0.80576858542562
    phi[6,8]  R2469     -8.8458226271005191e-01
    phi[6,8]  R2470     -8.8795488528294930e-01
    phi[6,8]  R2471     -9.0855450906761681e-01
    phi[6,8]  R2472     -1.5468755434305970e+00
    phi[6,8]  R2473     -1.0470456968564545e+00
    phi[6,8]  R2474     -1.0845607673333471e+00
    phi[6,8]  R2475     -3.4516718045852679e-01
    phi[6,8]  R2476     -5.1112039980380242e-01
    phi[6,8]  R2477     -1.1343990173966036e+00
    phi[6,8]  R2478     -5.3725145810036823e-01
    phi[6,8]  R2479     -6.5449214456094484e-01
    phi[6,8]  R2480     -6.6714868885748890e-01
    phi[6,8]  R2481     -7.2924953775183732e-01
    phi[6,8]  R2482     -0.741841958976073
    phi[6,8]  R2483     -7.5420859806019847e-01
    phi[6,8]  R2484     -7.7463744089057163e-01
    phi[6,8]  R2485     -3.9862290203498985e-01
    phi[6,8]  R2486     -1.3459679615922191e+00
    phi[6,8]  R2487     -6.4158236330410667e-01
    phi[6,8]  R2488     -6.5273515046343411e-01
    phi[6,8]  R2489     -6.6907615327611580e-01
    phi[6,8]  R2490     -6.6981570410901625e-01
    phi[6,8]  R2491     -1.0746736879706482e+00
    phi[6,8]  R2492     -7.3649252915313379e-01
    phi[6,8]  R2493     -1.3097729587791997e+00
    phi[6,8]  R2494     -1.7801008926275270e+00
    phi[6,8]  R2495     -4.1733709610727376e-01
    phi[6,8]  R2496     -5.2702111325459489e-01
    phi[6,8]  R2497     -5.9304090002864873e-01
    phi[6,8]  R2498     -7.1579079663008183e-01
    phi[6,8]  R2499     -7.2842588767093774e-01
    phi[6,8]  R2500     -1.0925672964509219e+00
    phi[6,8]  R2501     -2.7017052629090967e+00
    phi[6,8]  R2502     -2.6360192114568917e+00
    phi[6,8]  R2503     -2.5089453160387465e+00
    phi[6,8]  R2504     -1.6003785420351608e+00
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R65       -1
    z[0,1,0]  R66       1
    z[0,1,0]  R79       -5.9820300340652466e-01
    z[0,1,0]  R80       2.6752209290862083e-02
    z[0,1,0]  R81       1.4091794192790985e-01
    z[0,1,0]  R82       1.2610922753810883e-01
    z[0,1,0]  R83       0.0849047303199768
    z[0,1,0]  R84       -3.2846769690513611e-01
    z[0,1,0]  R85       -2.1867901086807251e-01
    z[0,1,0]  R86       -5.2526682615280151e-01
    z[0,1,0]  R87       -3.5961836576461792e-01
    z[0,1,0]  R88       -4.2806681990623474e-01
    z[0,1,0]  R89       3.1716111302375793e-01
    z[0,1,0]  R90       4.8540952801704407e-01
    z[0,1,0]  R91       5.8673745393753052e-01
    z[0,1,0]  R92       1.8371842801570892e-01
    z[0,1,0]  R93       5.2187836170196533e-01
    z[0,1,0]  R94       1.9484703242778778e-01
    z[0,1,0]  R95       1.0001332312822342e-01
    z[0,1,0]  R96       6.5880334377288818e-01
    z[0,1,0]  R97       6.1596816778182983e-01
    z[0,1,0]  R98       3.1987023353576660e-01
    z[0,1,0]  R99       0.0441134050488472
    z[0,1,0]  R100      1.6030104458332062e-01
    z[0,1,0]  R101      5.2771796472370625e-03
    z[0,1,0]  R102      -5.4457515478134155e-02
    z[0,1,0]  R103      -7.4533924460411072e-02
    z[0,1,0]  R104      -4.4968039728701115e-03
    z[0,1,0]  R105      -2.6329222321510315e-01
    z[0,1,0]  R106      2.0365172624588013e-01
    z[0,1,0]  R107      2.1670965850353241e-01
    z[0,1,0]  R108      2.1826069802045822e-02
    z[0,1,0]  R109      -0.077597476541996
    z[0,1,0]  R110      2.6397129893302917e-01
    z[0,1,0]  R111      -7.9583726823329926e-02
    z[0,1,0]  R112      2.7869397774338722e-02
    z[0,1,0]  R113      -2.1747012436389923e-01
    z[0,1,0]  R114      2.2852631285786629e-02
    z[0,1,0]  R115      1.7220035195350647e-01
    z[0,1,0]  R116      2.2474895417690277e-01
    z[0,1,0]  R117      -3.9130559563636780e-01
    z[0,1,0]  R118      -4.8110938072204590e-01
    z[0,1,0]  R119      3.1633594632148743e-01
    z[0,1,0]  R120      6.5092794829979539e-04
    z[0,1,0]  R121      3.6189493536949158e-01
    z[0,1,0]  R122      -2.3062512278556824e-01
    z[0,1,0]  R123      1.5377096831798553e-01
    z[0,1,0]  R124      -1.4678399264812469e-01
    z[0,1,0]  R125      -1.1018574982881546e-01
    z[0,1,0]  R126      -7.4105983972549438e-01
    z[0,1,0]  R127      -3.4644496440887451e-01
    z[0,1,0]  R128      -3.0616229772567749e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R67       -1
    z[0,1,1]  R68       1
    z[0,1,1]  R79       -0.657133936882019
    z[0,1,1]  R80       -6.5364474058151245e-01
    z[0,1,1]  R81       -7.6764965057373047e-01
    z[0,1,1]  R82       -4.7385737299919128e-01
    z[0,1,1]  R83       -4.8659288883209229e-01
    z[0,1,1]  R84       -7.9586714506149292e-02
    z[0,1,1]  R85       2.1789185702800751e-02
    z[0,1,1]  R86       0.321778267621994
    z[0,1,1]  R87       3.7625849246978760e-01
    z[0,1,1]  R88       5.0493443012237549e-01
    z[0,1,1]  R89       3.8211745023727417e-01
    z[0,1,1]  R90       4.1849234700202942e-01
    z[0,1,1]  R91       2.7541452646255493e-01
    z[0,1,1]  R92       3.8110509514808655e-01
    z[0,1,1]  R93       4.8911538720130920e-01
    z[0,1,1]  R94       1.9841021299362183e-01
    z[0,1,1]  R95       3.5478931665420532e-01
    z[0,1,1]  R96       4.7508573532104492e-01
    z[0,1,1]  R97       2.5571373105049133e-01
    z[0,1,1]  R98       2.9233837127685547e-01
    z[0,1,1]  R99       3.6666190624237061e-01
    z[0,1,1]  R100      1.2949857115745544e-01
    z[0,1,1]  R101      8.6312222480773926e-01
    z[0,1,1]  R102      9.2125928401947021e-01
    z[0,1,1]  R103      0.932815670967102
    z[0,1,1]  R104      8.9273869991302490e-01
    z[0,1,1]  R105      8.7298315763473511e-01
    z[0,1,1]  R106      8.4679442644119263e-01
    z[0,1,1]  R107      0.881366491317749
    z[0,1,1]  R108      8.6403840780258179e-01
    z[0,1,1]  R109      3.6245518922805786e-01
    z[0,1,1]  R110      -2.0048640668392181e-01
    z[0,1,1]  R111      3.8528078794479370e-01
    z[0,1,1]  R112      3.3962216973304749e-01
    z[0,1,1]  R113      -2.6412123441696167e-01
    z[0,1,1]  R114      -2.6405319571495056e-01
    z[0,1,1]  R115      -3.0863621830940247e-01
    z[0,1,1]  R116      -9.1000741720199585e-01
    z[0,1,1]  R117      -5.7779359817504883e-01
    z[0,1,1]  R118      -7.2239577770233154e-01
    z[0,1,1]  R119      -1.3021700084209442e-01
    z[0,1,1]  R120      -1.8559944629669189e-01
    z[0,1,1]  R121      -3.5733491182327271e-02
    z[0,1,1]  R122      2.3735000193119049e-01
    z[0,1,1]  R123      2.7018073201179504e-01
    z[0,1,1]  R124      3.2937890291213989e-01
    z[0,1,1]  R125      1.8331421911716461e-01
    z[0,1,1]  R126      3.8572159409523010e-01
    z[0,1,1]  R127      5.4935926198959351e-01
    z[0,1,1]  R128      5.8083051443099976e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R69       -1
    z[0,1,2]  R70       1
    z[0,1,2]  R79       -1.0295970737934113e-01
    z[0,1,2]  R80       -6.9366976618766785e-02
    z[0,1,2]  R81       7.8065022826194763e-02
    z[0,1,2]  R82       6.2996618449687958e-02
    z[0,1,2]  R83       -1.2328308075666428e-01
    z[0,1,2]  R84       -3.9146584272384644e-01
    z[0,1,2]  R85       -0.574528157711029
    z[0,1,2]  R86       -3.1612914800643921e-01
    z[0,1,2]  R87       -5.1629710197448730e-01
    z[0,1,2]  R88       -0.302365243434906
    z[0,1,2]  R89       0.594750165939331
    z[0,1,2]  R90       5.0521409511566162e-01
    z[0,1,2]  R91       6.2362527847290039e-01
    z[0,1,2]  R92       0.571182370185852
    z[0,1,2]  R93       4.4035613536834717e-01
    z[0,1,2]  R94       7.8499752283096313e-01
    z[0,1,2]  R95       6.2672156095504761e-01
    z[0,1,2]  R96       4.7743234038352966e-01
    z[0,1,2]  R97       6.9996118545532227e-01
    z[0,1,2]  R98       3.8069990277290344e-01
    z[0,1,2]  R99       1.1524409800767899e-01
    z[0,1,2]  R100      9.0653824806213379e-01
    z[0,1,2]  R101      3.5717067122459412e-01
    z[0,1,2]  R102      4.4943377375602722e-02
    z[0,1,2]  R103      1.0355886816978455e-01
    z[0,1,2]  R104      0.0952523723244667
    z[0,1,2]  R105      2.0626203715801239e-01
    z[0,1,2]  R106      1.7021517455577850e-01
    z[0,1,2]  R107      1.0912785679101944e-01
    z[0,1,2]  R108      1.3099455833435059e-01
    z[0,1,2]  R109      -2.4280132353305817e-01
    z[0,1,2]  R110      -3.8911259174346924e-01
    z[0,1,2]  R111      3.3616498112678528e-01
    z[0,1,2]  R112      1.9201441109180450e-01
    z[0,1,2]  R113      -0.211082324385643
    z[0,1,2]  R114      5.0174808502197266e-01
    z[0,1,2]  R115      9.4765760004520416e-02
    z[0,1,2]  R116      -1.2549269199371338e-01
    z[0,1,2]  R117      5.6650322675704956e-01
    z[0,1,2]  R118      2.4162469804286957e-01
    z[0,1,2]  R119      1.5392532944679260e-01
    z[0,1,2]  R120      -1.1897242814302444e-01
    z[0,1,2]  R121      0.45625039935112
    z[0,1,2]  R122      -1.4246310293674469e-01
    z[0,1,2]  R123      1.6092897951602936e-01
    z[0,1,2]  R124      2.2043561935424805e-01
    z[0,1,2]  R125      1.3189366459846497e-01
    z[0,1,2]  R126      -3.7291178107261658e-01
    z[0,1,2]  R127      -5.5576390027999878e-01
    z[0,1,2]  R128      -5.5670505762100220e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R71       -1
    z[0,1,3]  R72       1
    z[0,1,3]  R79       -8.3205364644527435e-02
    z[0,1,3]  R80       -9.7979776561260223e-02
    z[0,1,3]  R81       -1.7353199422359467e-01
    z[0,1,3]  R82       -1.8601258099079132e-01
    z[0,1,3]  R83       3.3038654923439026e-01
    z[0,1,3]  R84       7.3983728885650635e-01
    z[0,1,3]  R85       6.1978113651275635e-01
    z[0,1,3]  R86       5.2550071477890015e-01
    z[0,1,3]  R87       3.7971699237823486e-01
    z[0,1,3]  R88       6.7948889732360840e-01
    z[0,1,3]  R89       -3.8932007551193237e-01
    z[0,1,3]  R90       -3.4803071618080139e-01
    z[0,1,3]  R91       -2.2948299348354340e-01
    z[0,1,3]  R92       -3.1289437413215637e-01
    z[0,1,3]  R93       -0.391677588224411
    z[0,1,3]  R94       -7.3276035487651825e-02
    z[0,1,3]  R95       -3.8164338469505310e-01
    z[0,1,3]  R96       -1.2850166857242584e-01
    z[0,1,3]  R97       -2.4046956002712250e-01
    z[0,1,3]  R98       -4.5718687772750854e-01
    z[0,1,3]  R99       -7.4527716636657715e-01
    z[0,1,3]  R100      -2.4984714388847351e-01
    z[0,1,3]  R101      -3.7330493330955505e-02
    z[0,1,3]  R102      -2.2512030601501465e-01
    z[0,1,3]  R103      -2.2528481483459473e-01
    z[0,1,3]  R104      -2.2371117770671844e-01
    z[0,1,3]  R105      -2.6315337419509888e-01
    z[0,1,3]  R106      -1.7843115329742432e-01
    z[0,1,3]  R107      -1.7954248934984207e-02
    z[0,1,3]  R108      -1.1924888193607330e-01
    z[0,1,3]  R109      6.9761854410171509e-01
    z[0,1,3]  R110      7.0579981803894043e-01
    z[0,1,3]  R111      7.0265442132949829e-01
    z[0,1,3]  R112      8.3274716138839722e-01
    z[0,1,3]  R113      8.3575522899627686e-01
    z[0,1,3]  R114      6.8083167076110840e-01
    z[0,1,3]  R115      4.4157034158706665e-01
    z[0,1,3]  R116      -1.1593621969223022e-01
    z[0,1,3]  R117      -0.0922110453248024
    z[0,1,3]  R118      -0.0977182611823082
    z[0,1,3]  R119      -8.8844668865203857e-01
    z[0,1,3]  R120      -7.7384406328201294e-01
    z[0,1,3]  R121      -5.3013539314270020e-01
    z[0,1,3]  R122      -4.3950146436691284e-01
    z[0,1,3]  R123      -3.7368568778038025e-01
    z[0,1,3]  R124      -4.1142952442169189e-01
    z[0,1,3]  R125      -3.6310148239135742e-01
    z[0,1,3]  R126      -2.4321369826793671e-01
    z[0,1,3]  R127      -2.4231983721256256e-01
    z[0,1,3]  R128      -2.5232541561126709e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R73       -1
    z[0,1,4]  R74       1
    z[0,1,4]  R79       -2.9927557706832886e-01
    z[0,1,4]  R80       -1.4534645713865757e-02
    z[0,1,4]  R81       -2.4281892180442810e-01
    z[0,1,4]  R82       3.9431157708168030e-01
    z[0,1,4]  R83       7.5061666965484619e-01
    z[0,1,4]  R84       1.5398919582366943e-01
    z[0,1,4]  R85       1.2913782894611359e-01
    z[0,1,4]  R86       2.4086086452007294e-01
    z[0,1,4]  R87       2.9865931719541550e-02
    z[0,1,4]  R88       -0.0674920454621315
    z[0,1,4]  R89       -3.2286904752254486e-02
    z[0,1,4]  R90       -1.5856406092643738e-01
    z[0,1,4]  R91       -1.2010575085878372e-01
    z[0,1,4]  R92       2.7923974394798279e-01
    z[0,1,4]  R93       3.3129815012216568e-02
    z[0,1,4]  R94       0.0536414310336113
    z[0,1,4]  R95       -1.6545827686786652e-01
    z[0,1,4]  R96       1.6787317395210266e-01
    z[0,1,4]  R97       -3.8327416405081749e-03
    z[0,1,4]  R98       4.7427740693092346e-01
    z[0,1,4]  R99       -2.8334513306617737e-01
    z[0,1,4]  R100      -1.2642596662044525e-01
    z[0,1,4]  R101      -2.0384061336517334e-01
    z[0,1,4]  R102      1.3957025110721588e-01
    z[0,1,4]  R103      -1.3012272119522095e-01
    z[0,1,4]  R104      0.284850537776947
    z[0,1,4]  R105      -0.086112841963768
    z[0,1,4]  R106      7.7297821640968323e-02
    z[0,1,4]  R107      8.5844539105892181e-02
    z[0,1,4]  R108      -2.8101390600204468e-01
    z[0,1,4]  R109      3.9406582713127136e-01
    z[0,1,4]  R110      4.5046284794807434e-01
    z[0,1,4]  R111      0.486801415681839
    z[0,1,4]  R112      -2.4763226509094238e-01
    z[0,1,4]  R113      -1.4636451005935669e-01
    z[0,1,4]  R114      4.3101231567561626e-03
    z[0,1,4]  R115      4.7685602307319641e-01
    z[0,1,4]  R116      -4.4916570186614990e-03
    z[0,1,4]  R117      -3.2263353466987610e-01
    z[0,1,4]  R118      -2.9715770483016968e-01
    z[0,1,4]  R119      1.1608657240867615e-01
    z[0,1,4]  R120      -4.9887317419052124e-01
    z[0,1,4]  R121      5.0323802232742310e-01
    z[0,1,4]  R122      -0.346293181180954
    z[0,1,4]  R123      -4.7331359982490540e-01
    z[0,1,4]  R124      -3.8748362660408020e-01
    z[0,1,4]  R125      -5.0233131647109985e-01
    z[0,1,4]  R126      -1.5805552899837494e-01
    z[0,1,4]  R127      -0.0805695503950119
    z[0,1,4]  R128      -2.3558795452117920e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R75       -1
    z[0,1,5]  R76       1
    z[0,1,5]  R79       -3.1696575880050659e-01
    z[0,1,5]  R80       1.7433136701583862e-01
    z[0,1,5]  R81       2.4230352044105530e-01
    z[0,1,5]  R82       -6.6690450906753540e-01
    z[0,1,5]  R83       -1.5532267093658447e-01
    z[0,1,5]  R84       -3.6824661493301392e-01
    z[0,1,5]  R85       -3.3464384078979492e-01
    z[0,1,5]  R86       -4.2328894138336182e-01
    z[0,1,5]  R87       -5.5316913127899170e-01
    z[0,1,5]  R88       6.3855066895484924e-02
    z[0,1,5]  R89       4.9023386836051941e-01
    z[0,1,5]  R90       4.3290632963180542e-01
    z[0,1,5]  R91       3.2704770565032959e-01
    z[0,1,5]  R92       5.5597817897796631e-01
    z[0,1,5]  R93       3.0266985297203064e-01
    z[0,1,5]  R94       0.515321671962738
    z[0,1,5]  R95       5.0135707855224609e-01
    z[0,1,5]  R96       2.6005271077156067e-01
    z[0,1,5]  R97       -2.8759138658642769e-03
    z[0,1,5]  R98       4.3018421530723572e-01
    z[0,1,5]  R99       4.5271337032318115e-01
    z[0,1,5]  R100      1.5657339990139008e-01
    z[0,1,5]  R101      -2.3221021890640259e-01
    z[0,1,5]  R102      -1.5560670197010040e-01
    z[0,1,5]  R103      -1.7040944099426270e-01
    z[0,1,5]  R104      -1.8913638591766357e-01
    z[0,1,5]  R105      -9.9175393581390381e-02
    z[0,1,5]  R106      -4.1674140095710754e-01
    z[0,1,5]  R107      -0.295710951089859
    z[0,1,5]  R108      -3.2845476269721985e-01
    z[0,1,5]  R109      -3.6901223659515381e-01
    z[0,1,5]  R110      -1.1600410193204880e-01
    z[0,1,5]  R111      3.2378707081079483e-02
    z[0,1,5]  R112      -2.1641814708709717e-01
    z[0,1,5]  R113      -2.5121828913688660e-01
    z[0,1,5]  R114      -4.3281629681587219e-01
    z[0,1,5]  R115      -6.6607022285461426e-01
    z[0,1,5]  R116      2.8251004219055176e-01
    z[0,1,5]  R117      -2.8031954169273376e-01
    z[0,1,5]  R118      -1.6167476773262024e-01
    z[0,1,5]  R119      -8.3953499794006348e-02
    z[0,1,5]  R120      -3.1239360570907593e-01
    z[0,1,5]  R121      2.3754407465457916e-01
    z[0,1,5]  R122      7.4026662111282349e-01
    z[0,1,5]  R123      6.6615206003189087e-01
    z[0,1,5]  R124      6.8987190723419189e-01
    z[0,1,5]  R125      7.4313873052597046e-01
    z[0,1,5]  R126      2.6337283849716187e-01
    z[0,1,5]  R127      3.8477602601051331e-01
    z[0,1,5]  R128      2.8918406367301941e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R77       -1
    z[0,1,6]  R78       1
    z[0,1,6]  R79       -5.2641708403825760e-02
    z[0,1,6]  R80       -7.2596031427383423e-01
    z[0,1,6]  R81       4.8680245876312256e-01
    z[0,1,6]  R82       -3.4748116135597229e-01
    z[0,1,6]  R83       2.1003337204456329e-01
    z[0,1,6]  R84       -1.6078585386276245e-01
    z[0,1,6]  R85       3.2989460229873657e-01
    z[0,1,6]  R86       -8.5307411849498749e-02
    z[0,1,6]  R87       -1.0709116607904434e-01
    z[0,1,6]  R88       6.1182132922112942e-03
    z[0,1,6]  R89       8.2008644938468933e-02
    z[0,1,6]  R90       -1.8016591668128967e-02
    z[0,1,6]  R91       -1.3011348247528076e-01
    z[0,1,6]  R92       0.0988316610455513
    z[0,1,6]  R93       -2.1994952857494354e-01
    z[0,1,6]  R94       -1.8067541718482971e-01
    z[0,1,6]  R95       -2.1669082343578339e-01
    z[0,1,6]  R96       2.9461972881108522e-03
    z[0,1,6]  R97       8.6019881069660187e-02
    z[0,1,6]  R98       2.1970807015895844e-01
    z[0,1,6]  R99       9.8284952342510223e-02
    z[0,1,6]  R100      -1.8110708892345428e-01
    z[0,1,6]  R101      1.7480035126209259e-01
    z[0,1,6]  R102      -2.2786696255207062e-01
    z[0,1,6]  R103      1.2980991601943970e-01
    z[0,1,6]  R104      1.6421090066432953e-01
    z[0,1,6]  R105      1.9882810115814209e-01
    z[0,1,6]  R106      3.1714759767055511e-02
    z[0,1,6]  R107      -2.6302960515022278e-01
    z[0,1,6]  R108      -1.8635952472686768e-01
    z[0,1,6]  R109      1.5975877642631531e-01
    z[0,1,6]  R110      1.5552735328674316e-01
    z[0,1,6]  R111      -2.1702274680137634e-02
    z[0,1,6]  R112      -2.1303531527519226e-01
    z[0,1,6]  R113      2.3531040549278259e-01
    z[0,1,6]  R114      -1.6468851268291473e-01
    z[0,1,6]  R115      9.1937407851219177e-03
    z[0,1,6]  R116      1.1114278435707092e-01
    z[0,1,6]  R117      3.0565917491912842e-02
    z[0,1,6]  R118      2.5358486175537109e-01
    z[0,1,6]  R119      -2.2230693697929382e-01
    z[0,1,6]  R120      -7.8097254037857056e-02
    z[0,1,6]  R121      -0.262433797121048
    z[0,1,6]  R122      0.0954258143901825
    z[0,1,6]  R123      2.6463833451271057e-01
    z[0,1,6]  R124      1.6134175658226013e-01
    z[0,1,6]  R125      -2.0603444427251816e-02
    z[0,1,6]  R126      9.7397871315479279e-02
    z[0,1,6]  R127      -2.3673607409000397e-01
    z[0,1,6]  R128      2.3702910542488098e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R129      -1
    z[1,0,0]  R130      1
    z[1,0,0]  R143      -0.077597476541996
    z[1,0,0]  R144      2.6397129893302917e-01
    z[1,0,0]  R145      -7.9583726823329926e-02
    z[1,0,0]  R146      2.7869397774338722e-02
    z[1,0,0]  R147      -2.1747012436389923e-01
    z[1,0,0]  R148      2.2852631285786629e-02
    z[1,0,0]  R149      1.7220035195350647e-01
    z[1,0,0]  R150      2.2474895417690277e-01
    z[1,0,0]  R151      -3.9130559563636780e-01
    z[1,0,0]  R152      -4.8110938072204590e-01
    z[1,0,0]  R153      3.1633594632148743e-01
    z[1,0,0]  R154      6.5092794829979539e-04
    z[1,0,0]  R155      3.6189493536949158e-01
    z[1,0,0]  R156      -2.3062512278556824e-01
    z[1,0,0]  R157      1.5377096831798553e-01
    z[1,0,0]  R158      -1.4678399264812469e-01
    z[1,0,0]  R159      -1.1018574982881546e-01
    z[1,0,0]  R160      -7.4105983972549438e-01
    z[1,0,0]  R161      -3.4644496440887451e-01
    z[1,0,0]  R162      -3.0616229772567749e-01
    z[1,0,0]  R163      -5.9820300340652466e-01
    z[1,0,0]  R164      2.6752209290862083e-02
    z[1,0,0]  R165      1.4091794192790985e-01
    z[1,0,0]  R166      1.2610922753810883e-01
    z[1,0,0]  R167      0.0849047303199768
    z[1,0,0]  R168      -3.2846769690513611e-01
    z[1,0,0]  R169      -2.1867901086807251e-01
    z[1,0,0]  R170      -5.2526682615280151e-01
    z[1,0,0]  R171      -3.5961836576461792e-01
    z[1,0,0]  R172      -4.2806681990623474e-01
    z[1,0,0]  R173      3.1716111302375793e-01
    z[1,0,0]  R174      4.8540952801704407e-01
    z[1,0,0]  R175      5.8673745393753052e-01
    z[1,0,0]  R176      1.8371842801570892e-01
    z[1,0,0]  R177      5.2187836170196533e-01
    z[1,0,0]  R178      1.9484703242778778e-01
    z[1,0,0]  R179      1.0001332312822342e-01
    z[1,0,0]  R180      6.5880334377288818e-01
    z[1,0,0]  R181      6.1596816778182983e-01
    z[1,0,0]  R182      3.1987023353576660e-01
    z[1,0,0]  R183      0.0441134050488472
    z[1,0,0]  R184      1.6030104458332062e-01
    z[1,0,0]  R185      5.2771796472370625e-03
    z[1,0,0]  R186      -5.4457515478134155e-02
    z[1,0,0]  R187      -7.4533924460411072e-02
    z[1,0,0]  R188      -4.4968039728701115e-03
    z[1,0,0]  R189      -2.6329222321510315e-01
    z[1,0,0]  R190      2.0365172624588013e-01
    z[1,0,0]  R191      2.1670965850353241e-01
    z[1,0,0]  R192      2.1826069802045822e-02
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R131      -1
    z[1,0,1]  R132      1
    z[1,0,1]  R143      3.6245518922805786e-01
    z[1,0,1]  R144      -2.0048640668392181e-01
    z[1,0,1]  R145      3.8528078794479370e-01
    z[1,0,1]  R146      3.3962216973304749e-01
    z[1,0,1]  R147      -2.6412123441696167e-01
    z[1,0,1]  R148      -2.6405319571495056e-01
    z[1,0,1]  R149      -3.0863621830940247e-01
    z[1,0,1]  R150      -9.1000741720199585e-01
    z[1,0,1]  R151      -5.7779359817504883e-01
    z[1,0,1]  R152      -7.2239577770233154e-01
    z[1,0,1]  R153      -1.3021700084209442e-01
    z[1,0,1]  R154      -1.8559944629669189e-01
    z[1,0,1]  R155      -3.5733491182327271e-02
    z[1,0,1]  R156      2.3735000193119049e-01
    z[1,0,1]  R157      2.7018073201179504e-01
    z[1,0,1]  R158      3.2937890291213989e-01
    z[1,0,1]  R159      1.8331421911716461e-01
    z[1,0,1]  R160      3.8572159409523010e-01
    z[1,0,1]  R161      5.4935926198959351e-01
    z[1,0,1]  R162      5.8083051443099976e-01
    z[1,0,1]  R163      -0.657133936882019
    z[1,0,1]  R164      -6.5364474058151245e-01
    z[1,0,1]  R165      -7.6764965057373047e-01
    z[1,0,1]  R166      -4.7385737299919128e-01
    z[1,0,1]  R167      -4.8659288883209229e-01
    z[1,0,1]  R168      -7.9586714506149292e-02
    z[1,0,1]  R169      2.1789185702800751e-02
    z[1,0,1]  R170      0.321778267621994
    z[1,0,1]  R171      3.7625849246978760e-01
    z[1,0,1]  R172      5.0493443012237549e-01
    z[1,0,1]  R173      3.8211745023727417e-01
    z[1,0,1]  R174      4.1849234700202942e-01
    z[1,0,1]  R175      2.7541452646255493e-01
    z[1,0,1]  R176      3.8110509514808655e-01
    z[1,0,1]  R177      4.8911538720130920e-01
    z[1,0,1]  R178      1.9841021299362183e-01
    z[1,0,1]  R179      3.5478931665420532e-01
    z[1,0,1]  R180      4.7508573532104492e-01
    z[1,0,1]  R181      2.5571373105049133e-01
    z[1,0,1]  R182      2.9233837127685547e-01
    z[1,0,1]  R183      3.6666190624237061e-01
    z[1,0,1]  R184      1.2949857115745544e-01
    z[1,0,1]  R185      8.6312222480773926e-01
    z[1,0,1]  R186      9.2125928401947021e-01
    z[1,0,1]  R187      0.932815670967102
    z[1,0,1]  R188      8.9273869991302490e-01
    z[1,0,1]  R189      8.7298315763473511e-01
    z[1,0,1]  R190      8.4679442644119263e-01
    z[1,0,1]  R191      0.881366491317749
    z[1,0,1]  R192      8.6403840780258179e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R133      -1
    z[1,0,2]  R134      1
    z[1,0,2]  R143      -2.4280132353305817e-01
    z[1,0,2]  R144      -3.8911259174346924e-01
    z[1,0,2]  R145      3.3616498112678528e-01
    z[1,0,2]  R146      1.9201441109180450e-01
    z[1,0,2]  R147      -0.211082324385643
    z[1,0,2]  R148      5.0174808502197266e-01
    z[1,0,2]  R149      9.4765760004520416e-02
    z[1,0,2]  R150      -1.2549269199371338e-01
    z[1,0,2]  R151      5.6650322675704956e-01
    z[1,0,2]  R152      2.4162469804286957e-01
    z[1,0,2]  R153      1.5392532944679260e-01
    z[1,0,2]  R154      -1.1897242814302444e-01
    z[1,0,2]  R155      0.45625039935112
    z[1,0,2]  R156      -1.4246310293674469e-01
    z[1,0,2]  R157      1.6092897951602936e-01
    z[1,0,2]  R158      2.2043561935424805e-01
    z[1,0,2]  R159      1.3189366459846497e-01
    z[1,0,2]  R160      -3.7291178107261658e-01
    z[1,0,2]  R161      -5.5576390027999878e-01
    z[1,0,2]  R162      -5.5670505762100220e-01
    z[1,0,2]  R163      -1.0295970737934113e-01
    z[1,0,2]  R164      -6.9366976618766785e-02
    z[1,0,2]  R165      7.8065022826194763e-02
    z[1,0,2]  R166      6.2996618449687958e-02
    z[1,0,2]  R167      -1.2328308075666428e-01
    z[1,0,2]  R168      -3.9146584272384644e-01
    z[1,0,2]  R169      -0.574528157711029
    z[1,0,2]  R170      -3.1612914800643921e-01
    z[1,0,2]  R171      -5.1629710197448730e-01
    z[1,0,2]  R172      -0.302365243434906
    z[1,0,2]  R173      0.594750165939331
    z[1,0,2]  R174      5.0521409511566162e-01
    z[1,0,2]  R175      6.2362527847290039e-01
    z[1,0,2]  R176      0.571182370185852
    z[1,0,2]  R177      4.4035613536834717e-01
    z[1,0,2]  R178      7.8499752283096313e-01
    z[1,0,2]  R179      6.2672156095504761e-01
    z[1,0,2]  R180      4.7743234038352966e-01
    z[1,0,2]  R181      6.9996118545532227e-01
    z[1,0,2]  R182      3.8069990277290344e-01
    z[1,0,2]  R183      1.1524409800767899e-01
    z[1,0,2]  R184      9.0653824806213379e-01
    z[1,0,2]  R185      3.5717067122459412e-01
    z[1,0,2]  R186      4.4943377375602722e-02
    z[1,0,2]  R187      1.0355886816978455e-01
    z[1,0,2]  R188      0.0952523723244667
    z[1,0,2]  R189      2.0626203715801239e-01
    z[1,0,2]  R190      1.7021517455577850e-01
    z[1,0,2]  R191      1.0912785679101944e-01
    z[1,0,2]  R192      1.3099455833435059e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R135      -1
    z[1,0,3]  R136      1
    z[1,0,3]  R143      6.9761854410171509e-01
    z[1,0,3]  R144      7.0579981803894043e-01
    z[1,0,3]  R145      7.0265442132949829e-01
    z[1,0,3]  R146      8.3274716138839722e-01
    z[1,0,3]  R147      8.3575522899627686e-01
    z[1,0,3]  R148      6.8083167076110840e-01
    z[1,0,3]  R149      4.4157034158706665e-01
    z[1,0,3]  R150      -1.1593621969223022e-01
    z[1,0,3]  R151      -0.0922110453248024
    z[1,0,3]  R152      -0.0977182611823082
    z[1,0,3]  R153      -8.8844668865203857e-01
    z[1,0,3]  R154      -7.7384406328201294e-01
    z[1,0,3]  R155      -5.3013539314270020e-01
    z[1,0,3]  R156      -4.3950146436691284e-01
    z[1,0,3]  R157      -3.7368568778038025e-01
    z[1,0,3]  R158      -4.1142952442169189e-01
    z[1,0,3]  R159      -3.6310148239135742e-01
    z[1,0,3]  R160      -2.4321369826793671e-01
    z[1,0,3]  R161      -2.4231983721256256e-01
    z[1,0,3]  R162      -2.5232541561126709e-01
    z[1,0,3]  R163      -8.3205364644527435e-02
    z[1,0,3]  R164      -9.7979776561260223e-02
    z[1,0,3]  R165      -1.7353199422359467e-01
    z[1,0,3]  R166      -1.8601258099079132e-01
    z[1,0,3]  R167      3.3038654923439026e-01
    z[1,0,3]  R168      7.3983728885650635e-01
    z[1,0,3]  R169      6.1978113651275635e-01
    z[1,0,3]  R170      5.2550071477890015e-01
    z[1,0,3]  R171      3.7971699237823486e-01
    z[1,0,3]  R172      6.7948889732360840e-01
    z[1,0,3]  R173      -3.8932007551193237e-01
    z[1,0,3]  R174      -3.4803071618080139e-01
    z[1,0,3]  R175      -2.2948299348354340e-01
    z[1,0,3]  R176      -3.1289437413215637e-01
    z[1,0,3]  R177      -0.391677588224411
    z[1,0,3]  R178      -7.3276035487651825e-02
    z[1,0,3]  R179      -3.8164338469505310e-01
    z[1,0,3]  R180      -1.2850166857242584e-01
    z[1,0,3]  R181      -2.4046956002712250e-01
    z[1,0,3]  R182      -4.5718687772750854e-01
    z[1,0,3]  R183      -7.4527716636657715e-01
    z[1,0,3]  R184      -2.4984714388847351e-01
    z[1,0,3]  R185      -3.7330493330955505e-02
    z[1,0,3]  R186      -2.2512030601501465e-01
    z[1,0,3]  R187      -2.2528481483459473e-01
    z[1,0,3]  R188      -2.2371117770671844e-01
    z[1,0,3]  R189      -2.6315337419509888e-01
    z[1,0,3]  R190      -1.7843115329742432e-01
    z[1,0,3]  R191      -1.7954248934984207e-02
    z[1,0,3]  R192      -1.1924888193607330e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R137      -1
    z[1,0,4]  R138      1
    z[1,0,4]  R143      3.9406582713127136e-01
    z[1,0,4]  R144      4.5046284794807434e-01
    z[1,0,4]  R145      0.486801415681839
    z[1,0,4]  R146      -2.4763226509094238e-01
    z[1,0,4]  R147      -1.4636451005935669e-01
    z[1,0,4]  R148      4.3101231567561626e-03
    z[1,0,4]  R149      4.7685602307319641e-01
    z[1,0,4]  R150      -4.4916570186614990e-03
    z[1,0,4]  R151      -3.2263353466987610e-01
    z[1,0,4]  R152      -2.9715770483016968e-01
    z[1,0,4]  R153      1.1608657240867615e-01
    z[1,0,4]  R154      -4.9887317419052124e-01
    z[1,0,4]  R155      5.0323802232742310e-01
    z[1,0,4]  R156      -0.346293181180954
    z[1,0,4]  R157      -4.7331359982490540e-01
    z[1,0,4]  R158      -3.8748362660408020e-01
    z[1,0,4]  R159      -5.0233131647109985e-01
    z[1,0,4]  R160      -1.5805552899837494e-01
    z[1,0,4]  R161      -0.0805695503950119
    z[1,0,4]  R162      -2.3558795452117920e-01
    z[1,0,4]  R163      -2.9927557706832886e-01
    z[1,0,4]  R164      -1.4534645713865757e-02
    z[1,0,4]  R165      -2.4281892180442810e-01
    z[1,0,4]  R166      3.9431157708168030e-01
    z[1,0,4]  R167      7.5061666965484619e-01
    z[1,0,4]  R168      1.5398919582366943e-01
    z[1,0,4]  R169      1.2913782894611359e-01
    z[1,0,4]  R170      2.4086086452007294e-01
    z[1,0,4]  R171      2.9865931719541550e-02
    z[1,0,4]  R172      -0.0674920454621315
    z[1,0,4]  R173      -3.2286904752254486e-02
    z[1,0,4]  R174      -1.5856406092643738e-01
    z[1,0,4]  R175      -1.2010575085878372e-01
    z[1,0,4]  R176      2.7923974394798279e-01
    z[1,0,4]  R177      3.3129815012216568e-02
    z[1,0,4]  R178      0.0536414310336113
    z[1,0,4]  R179      -1.6545827686786652e-01
    z[1,0,4]  R180      1.6787317395210266e-01
    z[1,0,4]  R181      -3.8327416405081749e-03
    z[1,0,4]  R182      4.7427740693092346e-01
    z[1,0,4]  R183      -2.8334513306617737e-01
    z[1,0,4]  R184      -1.2642596662044525e-01
    z[1,0,4]  R185      -2.0384061336517334e-01
    z[1,0,4]  R186      1.3957025110721588e-01
    z[1,0,4]  R187      -1.3012272119522095e-01
    z[1,0,4]  R188      0.284850537776947
    z[1,0,4]  R189      -0.086112841963768
    z[1,0,4]  R190      7.7297821640968323e-02
    z[1,0,4]  R191      8.5844539105892181e-02
    z[1,0,4]  R192      -2.8101390600204468e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R139      -1
    z[1,0,5]  R140      1
    z[1,0,5]  R143      -3.6901223659515381e-01
    z[1,0,5]  R144      -1.1600410193204880e-01
    z[1,0,5]  R145      3.2378707081079483e-02
    z[1,0,5]  R146      -2.1641814708709717e-01
    z[1,0,5]  R147      -2.5121828913688660e-01
    z[1,0,5]  R148      -4.3281629681587219e-01
    z[1,0,5]  R149      -6.6607022285461426e-01
    z[1,0,5]  R150      2.8251004219055176e-01
    z[1,0,5]  R151      -2.8031954169273376e-01
    z[1,0,5]  R152      -1.6167476773262024e-01
    z[1,0,5]  R153      -8.3953499794006348e-02
    z[1,0,5]  R154      -3.1239360570907593e-01
    z[1,0,5]  R155      2.3754407465457916e-01
    z[1,0,5]  R156      7.4026662111282349e-01
    z[1,0,5]  R157      6.6615206003189087e-01
    z[1,0,5]  R158      6.8987190723419189e-01
    z[1,0,5]  R159      7.4313873052597046e-01
    z[1,0,5]  R160      2.6337283849716187e-01
    z[1,0,5]  R161      3.8477602601051331e-01
    z[1,0,5]  R162      2.8918406367301941e-01
    z[1,0,5]  R163      -3.1696575880050659e-01
    z[1,0,5]  R164      1.7433136701583862e-01
    z[1,0,5]  R165      2.4230352044105530e-01
    z[1,0,5]  R166      -6.6690450906753540e-01
    z[1,0,5]  R167      -1.5532267093658447e-01
    z[1,0,5]  R168      -3.6824661493301392e-01
    z[1,0,5]  R169      -3.3464384078979492e-01
    z[1,0,5]  R170      -4.2328894138336182e-01
    z[1,0,5]  R171      -5.5316913127899170e-01
    z[1,0,5]  R172      6.3855066895484924e-02
    z[1,0,5]  R173      4.9023386836051941e-01
    z[1,0,5]  R174      4.3290632963180542e-01
    z[1,0,5]  R175      3.2704770565032959e-01
    z[1,0,5]  R176      5.5597817897796631e-01
    z[1,0,5]  R177      3.0266985297203064e-01
    z[1,0,5]  R178      0.515321671962738
    z[1,0,5]  R179      5.0135707855224609e-01
    z[1,0,5]  R180      2.6005271077156067e-01
    z[1,0,5]  R181      -2.8759138658642769e-03
    z[1,0,5]  R182      4.3018421530723572e-01
    z[1,0,5]  R183      4.5271337032318115e-01
    z[1,0,5]  R184      1.5657339990139008e-01
    z[1,0,5]  R185      -2.3221021890640259e-01
    z[1,0,5]  R186      -1.5560670197010040e-01
    z[1,0,5]  R187      -1.7040944099426270e-01
    z[1,0,5]  R188      -1.8913638591766357e-01
    z[1,0,5]  R189      -9.9175393581390381e-02
    z[1,0,5]  R190      -4.1674140095710754e-01
    z[1,0,5]  R191      -0.295710951089859
    z[1,0,5]  R192      -3.2845476269721985e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R141      -1
    z[1,0,6]  R142      1
    z[1,0,6]  R143      1.5975877642631531e-01
    z[1,0,6]  R144      1.5552735328674316e-01
    z[1,0,6]  R145      -2.1702274680137634e-02
    z[1,0,6]  R146      -2.1303531527519226e-01
    z[1,0,6]  R147      2.3531040549278259e-01
    z[1,0,6]  R148      -1.6468851268291473e-01
    z[1,0,6]  R149      9.1937407851219177e-03
    z[1,0,6]  R150      1.1114278435707092e-01
    z[1,0,6]  R151      3.0565917491912842e-02
    z[1,0,6]  R152      2.5358486175537109e-01
    z[1,0,6]  R153      -2.2230693697929382e-01
    z[1,0,6]  R154      -7.8097254037857056e-02
    z[1,0,6]  R155      -0.262433797121048
    z[1,0,6]  R156      0.0954258143901825
    z[1,0,6]  R157      2.6463833451271057e-01
    z[1,0,6]  R158      1.6134175658226013e-01
    z[1,0,6]  R159      -2.0603444427251816e-02
    z[1,0,6]  R160      9.7397871315479279e-02
    z[1,0,6]  R161      -2.3673607409000397e-01
    z[1,0,6]  R162      2.3702910542488098e-01
    z[1,0,6]  R163      -5.2641708403825760e-02
    z[1,0,6]  R164      -7.2596031427383423e-01
    z[1,0,6]  R165      4.8680245876312256e-01
    z[1,0,6]  R166      -3.4748116135597229e-01
    z[1,0,6]  R167      2.1003337204456329e-01
    z[1,0,6]  R168      -1.6078585386276245e-01
    z[1,0,6]  R169      3.2989460229873657e-01
    z[1,0,6]  R170      -8.5307411849498749e-02
    z[1,0,6]  R171      -1.0709116607904434e-01
    z[1,0,6]  R172      6.1182132922112942e-03
    z[1,0,6]  R173      8.2008644938468933e-02
    z[1,0,6]  R174      -1.8016591668128967e-02
    z[1,0,6]  R175      -1.3011348247528076e-01
    z[1,0,6]  R176      0.0988316610455513
    z[1,0,6]  R177      -2.1994952857494354e-01
    z[1,0,6]  R178      -1.8067541718482971e-01
    z[1,0,6]  R179      -2.1669082343578339e-01
    z[1,0,6]  R180      2.9461972881108522e-03
    z[1,0,6]  R181      8.6019881069660187e-02
    z[1,0,6]  R182      2.1970807015895844e-01
    z[1,0,6]  R183      9.8284952342510223e-02
    z[1,0,6]  R184      -1.8110708892345428e-01
    z[1,0,6]  R185      1.7480035126209259e-01
    z[1,0,6]  R186      -2.2786696255207062e-01
    z[1,0,6]  R187      1.2980991601943970e-01
    z[1,0,6]  R188      1.6421090066432953e-01
    z[1,0,6]  R189      1.9882810115814209e-01
    z[1,0,6]  R190      3.1714759767055511e-02
    z[1,0,6]  R191      -2.6302960515022278e-01
    z[1,0,6]  R192      -1.8635952472686768e-01
    z[0,3,0]  R2        -1
    z[0,3,0]  R29       1
    z[0,3,0]  R193      -1
    z[0,3,0]  R194      1
    z[0,3,0]  R207      -5.9820300340652466e-01
    z[0,3,0]  R208      2.6752209290862083e-02
    z[0,3,0]  R209      1.4091794192790985e-01
    z[0,3,0]  R210      1.2610922753810883e-01
    z[0,3,0]  R211      0.0849047303199768
    z[0,3,0]  R212      -3.2846769690513611e-01
    z[0,3,0]  R213      -2.1867901086807251e-01
    z[0,3,0]  R214      -5.2526682615280151e-01
    z[0,3,0]  R215      -3.5961836576461792e-01
    z[0,3,0]  R216      -4.2806681990623474e-01
    z[0,3,0]  R217      3.1716111302375793e-01
    z[0,3,0]  R218      4.8540952801704407e-01
    z[0,3,0]  R219      5.8673745393753052e-01
    z[0,3,0]  R220      1.8371842801570892e-01
    z[0,3,0]  R221      5.2187836170196533e-01
    z[0,3,0]  R222      1.9484703242778778e-01
    z[0,3,0]  R223      1.0001332312822342e-01
    z[0,3,0]  R224      6.5880334377288818e-01
    z[0,3,0]  R225      6.1596816778182983e-01
    z[0,3,0]  R226      3.1987023353576660e-01
    z[0,3,0]  R227      0.0441134050488472
    z[0,3,0]  R228      1.6030104458332062e-01
    z[0,3,0]  R229      5.2771796472370625e-03
    z[0,3,0]  R230      -5.4457515478134155e-02
    z[0,3,0]  R231      -7.4533924460411072e-02
    z[0,3,0]  R232      -4.4968039728701115e-03
    z[0,3,0]  R233      -2.6329222321510315e-01
    z[0,3,0]  R234      2.0365172624588013e-01
    z[0,3,0]  R235      2.1670965850353241e-01
    z[0,3,0]  R236      2.1826069802045822e-02
    z[0,3,0]  R237      -7.3149889707565308e-01
    z[0,3,0]  R238      -4.6494984626770020e-01
    z[0,3,0]  R239      -5.5307424068450928e-01
    z[0,3,0]  R240      -6.4098256826400757e-01
    z[0,3,0]  R241      -4.6843826770782471e-01
    z[0,3,0]  R242      6.9115829467773438e-01
    z[0,3,0]  R243      -7.4154675006866455e-01
    z[0,3,0]  R244      -7.4062174558639526e-01
    z[0,3,0]  R245      -6.4864701032638550e-01
    z[0,3,0]  R246      -4.9817335605621338e-01
    z[0,3,0]  R247      2.0759922266006470e-01
    z[0,3,0]  R248      7.5057804584503174e-01
    z[0,3,0]  R249      -5.5326479673385620e-01
    z[0,3,0]  R250      -4.6926024556159973e-01
    z[0,3,0]  R251      3.9492759108543396e-01
    z[0,3,0]  R252      3.6992263793945312e-01
    z[0,3,0]  R253      2.0820197463035583e-01
    z[0,3,0]  R254      4.7991272062063217e-02
    z[0,3,0]  R255      1.1325430870056152e-01
    z[0,3,0]  R256      -5.5136060714721680e-01
    z[0,3,0]  R257      1.4380007982254028e-01
    z[0,3,0]  R258      3.2474073767662048e-01
    z[0,3,0]  R259      4.8364314436912537e-01
    z[0,3,0]  R260      -1.2364013493061066e-01
    z[0,3,0]  R261      2.0443318784236908e-01
    z[0,3,0]  R262      2.6790171861648560e-01
    z[0,3,0]  R263      1.7849633097648621e-01
    z[0,3,0]  R264      -0.0982329249382019
    z[0,3,0]  R265      1.9996878504753113e-01
    z[0,3,0]  R266      1.4755828678607941e-01
    z[0,3,0]  R267      1.6651113331317902e-01
    z[0,3,0]  R268      3.1945732235908508e-01
    z[0,3,0]  R269      1.4911076426506042e-01
    z[0,3,0]  R270      2.7498263120651245e-01
    z[0,3,0]  R271      3.6940187215805054e-01
    z[0,3,0]  R272      -4.3450483679771423e-01
    z[0,3,0]  R273      3.5477286577224731e-01
    z[0,3,0]  R274      -2.5958001613616943e-01
    z[0,3,0]  R275      5.5322623252868652e-01
    z[0,3,0]  R276      -6.8578487634658813e-01
    z[0,3,0]  R277      4.1563576459884644e-01
    z[0,3,0]  R278      6.5622836351394653e-01
    z[0,3,0]  R279      3.5397329926490784e-01
    z[0,3,0]  R280      5.3247994184494019e-01
    z[0,3,0]  R281      -1.4392016828060150e-01
    z[0,3,0]  R282      6.9569003582000732e-01
    z[0,3,0]  R283      1.2768420577049255e-01
    z[0,3,0]  R284      2.3055291175842285e-01
    z[0,3,0]  R285      0.437958300113678
    z[0,3,0]  R286      4.4579499959945679e-01
    z[0,3,0]  R287      6.4987319707870483e-01
    z[0,3,0]  R288      -4.2804482579231262e-01
    z[0,3,0]  R289      2.9841953516006470e-01
    z[0,3,0]  R290      -7.1220767498016357e-01
    z[0,3,0]  R291      1.4320926368236542e-01
    z[0,3,0]  R292      5.1414996385574341e-01
    z[0,3,0]  R293      4.6924032270908356e-02
    z[0,3,0]  R294      7.6293818652629852e-02
    z[0,3,0]  R295      3.7339481711387634e-01
    z[0,3,0]  R296      -2.5049021840095520e-01
    z[0,3,0]  R297      4.3164721131324768e-01
    z[0,3,0]  R298      5.1107597351074219e-01
    z[0,3,0]  R299      4.9693781137466431e-01
    z[0,3,0]  R300      3.2298576831817627e-01
    z[0,3,0]  R301      6.4064615964889526e-01
    z[0,3,0]  R302      -7.0324313640594482e-01
    z[0,3,0]  R303      1.7100089788436890e-01
    z[0,3,0]  R304      -2.4214620888233185e-01
    z[0,3,0]  R305      -3.0630099773406982e-01
    z[0,3,0]  R306      -4.8566347360610962e-01
    z[0,3,0]  R307      3.9700803160667419e-01
    z[0,3,0]  R308      3.1685985624790192e-02
    z[0,3,0]  R309      6.9347220659255981e-01
    z[0,3,0]  R310      -5.7144099473953247e-01
    z[0,3,0]  R311      5.4736936092376709e-01
    z[0,3,0]  R312      -5.0030130147933960e-01
    z[0,3,0]  R313      -1.4278750121593475e-01
    z[0,3,0]  R314      -4.9214673042297363e-01
    z[0,3,0]  R315      -3.1458348035812378e-02
    z[0,3,0]  R316      -2.7843341231346130e-01
    z[0,3,0]  R317      -6.0938209295272827e-01
    z[0,3,0]  R318      3.6866092681884766e-01
    z[0,3,0]  R319      -5.1106846332550049e-01
    z[0,3,0]  R320      5.4783982038497925e-01
    z[0,3,0]  R321      -4.9239164590835571e-01
    z[0,3,0]  R322      3.8289362192153931e-01
    z[0,3,0]  R323      -4.2543691396713257e-01
    z[0,3,0]  R324      -1.9382968544960022e-01
    z[0,3,0]  R325      -4.3683847784996033e-01
    z[0,3,0]  R326      -2.7887448668479919e-01
    z[0,3,1]  R3        -1
    z[0,3,1]  R30       1
    z[0,3,1]  R195      -1
    z[0,3,1]  R196      1
    z[0,3,1]  R207      -0.657133936882019
    z[0,3,1]  R208      -6.5364474058151245e-01
    z[0,3,1]  R209      -7.6764965057373047e-01
    z[0,3,1]  R210      -4.7385737299919128e-01
    z[0,3,1]  R211      -4.8659288883209229e-01
    z[0,3,1]  R212      -7.9586714506149292e-02
    z[0,3,1]  R213      2.1789185702800751e-02
    z[0,3,1]  R214      0.321778267621994
    z[0,3,1]  R215      3.7625849246978760e-01
    z[0,3,1]  R216      5.0493443012237549e-01
    z[0,3,1]  R217      3.8211745023727417e-01
    z[0,3,1]  R218      4.1849234700202942e-01
    z[0,3,1]  R219      2.7541452646255493e-01
    z[0,3,1]  R220      3.8110509514808655e-01
    z[0,3,1]  R221      4.8911538720130920e-01
    z[0,3,1]  R222      1.9841021299362183e-01
    z[0,3,1]  R223      3.5478931665420532e-01
    z[0,3,1]  R224      4.7508573532104492e-01
    z[0,3,1]  R225      2.5571373105049133e-01
    z[0,3,1]  R226      2.9233837127685547e-01
    z[0,3,1]  R227      3.6666190624237061e-01
    z[0,3,1]  R228      1.2949857115745544e-01
    z[0,3,1]  R229      8.6312222480773926e-01
    z[0,3,1]  R230      9.2125928401947021e-01
    z[0,3,1]  R231      0.932815670967102
    z[0,3,1]  R232      8.9273869991302490e-01
    z[0,3,1]  R233      8.7298315763473511e-01
    z[0,3,1]  R234      8.4679442644119263e-01
    z[0,3,1]  R235      0.881366491317749
    z[0,3,1]  R236      8.6403840780258179e-01
    z[0,3,1]  R237      -2.2296635806560516e-01
    z[0,3,1]  R238      -4.3592748045921326e-01
    z[0,3,1]  R239      -2.8077259659767151e-01
    z[0,3,1]  R240      -3.1925195455551147e-01
    z[0,3,1]  R241      -3.2749226689338684e-01
    z[0,3,1]  R242      -7.6501101255416870e-02
    z[0,3,1]  R243      -3.2344156503677368e-01
    z[0,3,1]  R244      -0.530152440071106
    z[0,3,1]  R245      -2.4570703506469727e-01
    z[0,3,1]  R246      -2.5414341688156128e-01
    z[0,3,1]  R247      7.3943096399307251e-01
    z[0,3,1]  R248      1.1804948002099991e-01
    z[0,3,1]  R249      7.8791356086730957e-01
    z[0,3,1]  R250      8.4700977802276611e-01
    z[0,3,1]  R251      4.1214641928672791e-01
    z[0,3,1]  R252      6.3256627321243286e-01
    z[0,3,1]  R253      2.4967686831951141e-01
    z[0,3,1]  R254      4.2082428932189941e-01
    z[0,3,1]  R255      2.5530877709388733e-01
    z[0,3,1]  R256      7.4511927366256714e-01
    z[0,3,1]  R257      -2.8681892156600952e-01
    z[0,3,1]  R258      -1.8626321852207184e-01
    z[0,3,1]  R259      -3.1145927309989929e-01
    z[0,3,1]  R260      3.9020884037017822e-01
    z[0,3,1]  R261      -3.5172438621520996e-01
    z[0,3,1]  R262      -0.818288266658783
    z[0,3,1]  R263      -8.1852716207504272e-01
    z[0,3,1]  R264      -7.9543876647949219e-01
    z[0,3,1]  R265      -0.739153265953064
    z[0,3,1]  R266      -8.0173850059509277e-01
    z[0,3,1]  R267      2.1644264459609985e-01
    z[0,3,1]  R268      2.5637015700340271e-01
    z[0,3,1]  R269      1.3758948445320129e-01
    z[0,3,1]  R270      -2.0281149446964264e-01
    z[0,3,1]  R271      -2.7382951974868774e-01
    z[0,3,1]  R272      3.3426719903945923e-01
    z[0,3,1]  R273      3.0472838878631592e-01
    z[0,3,1]  R274      2.2483146190643311e-01
    z[0,3,1]  R275      3.8899382948875427e-01
    z[0,3,1]  R276      3.7241196632385254e-01
    z[0,3,1]  R277      -0.104210764169693
    z[0,3,1]  R278      3.5648781061172485e-01
    z[0,3,1]  R279      -1.7990475893020630e-01
    z[0,3,1]  R280      3.1396555900573730e-01
    z[0,3,1]  R281      1.3082636892795563e-01
    z[0,3,1]  R282      -1.2762185931205750e-01
    z[0,3,1]  R283      1.8831813707947731e-02
    z[0,3,1]  R284      6.2494814395904541e-01
    z[0,3,1]  R285      2.4925498664379120e-01
    z[0,3,1]  R286      3.7488889694213867e-01
    z[0,3,1]  R287      2.4902611970901489e-01
    z[0,3,1]  R288      3.6701738834381104e-01
    z[0,3,1]  R289      -2.0082278177142143e-02
    z[0,3,1]  R290      6.5392822027206421e-01
    z[0,3,1]  R291      -1.8960449844598770e-02
    z[0,3,1]  R292      -0.465471476316452
    z[0,3,1]  R293      2.8015002608299255e-01
    z[0,3,1]  R294      8.0995447933673859e-02
    z[0,3,1]  R295      2.8088155388832092e-01
    z[0,3,1]  R296      -2.1294054388999939e-01
    z[0,3,1]  R297      3.1275704503059387e-01
    z[0,3,1]  R298      -2.3235730826854706e-01
    z[0,3,1]  R299      4.5602791011333466e-02
    z[0,3,1]  R300      2.3990756273269653e-01
    z[0,3,1]  R301      4.3577298521995544e-01
    z[0,3,1]  R302      -4.4554811716079712e-01
    z[0,3,1]  R303      0.307367742061615
    z[0,3,1]  R304      -3.9569985866546631e-01
    z[0,3,1]  R305      -3.2336461544036865e-01
    z[0,3,1]  R306      -1.7215554416179657e-01
    z[0,3,1]  R307      3.6054009199142456e-01
    z[0,3,1]  R308      3.6119109392166138e-01
    z[0,3,1]  R309      -2.3140546679496765e-01
    z[0,3,1]  R310      -4.6828567981719971e-01
    z[0,3,1]  R311      6.0571485757827759e-01
    z[0,3,1]  R312      -2.0369865000247955e-01
    z[0,3,1]  R313      3.2805186510086060e-01
    z[0,3,1]  R314      -7.6862359046936035e-01
    z[0,3,1]  R315      -2.4225763976573944e-01
    z[0,3,1]  R316      -7.9465228319168091e-01
    z[0,3,1]  R317      2.3313266038894653e-01
    z[0,3,1]  R318      -1.5226179733872414e-02
    z[0,3,1]  R319      -1.2230127304792404e-01
    z[0,3,1]  R320      1.9350171089172363e-01
    z[0,3,1]  R321      -4.2640250921249390e-01
    z[0,3,1]  R322      6.2665677070617676e-01
    z[0,3,1]  R323      -2.2087098658084869e-01
    z[0,3,1]  R324      3.4668478369712830e-01
    z[0,3,1]  R325      -7.0672088861465454e-01
    z[0,3,1]  R326      -8.5525280237197876e-01
    z[0,3,2]  R4        -1
    z[0,3,2]  R31       1
    z[0,3,2]  R197      -1
    z[0,3,2]  R198      1
    z[0,3,2]  R207      -1.0295970737934113e-01
    z[0,3,2]  R208      -6.9366976618766785e-02
    z[0,3,2]  R209      7.8065022826194763e-02
    z[0,3,2]  R210      6.2996618449687958e-02
    z[0,3,2]  R211      -1.2328308075666428e-01
    z[0,3,2]  R212      -3.9146584272384644e-01
    z[0,3,2]  R213      -0.574528157711029
    z[0,3,2]  R214      -3.1612914800643921e-01
    z[0,3,2]  R215      -5.1629710197448730e-01
    z[0,3,2]  R216      -0.302365243434906
    z[0,3,2]  R217      0.594750165939331
    z[0,3,2]  R218      5.0521409511566162e-01
    z[0,3,2]  R219      6.2362527847290039e-01
    z[0,3,2]  R220      0.571182370185852
    z[0,3,2]  R221      4.4035613536834717e-01
    z[0,3,2]  R222      7.8499752283096313e-01
    z[0,3,2]  R223      6.2672156095504761e-01
    z[0,3,2]  R224      4.7743234038352966e-01
    z[0,3,2]  R225      6.9996118545532227e-01
    z[0,3,2]  R226      3.8069990277290344e-01
    z[0,3,2]  R227      1.1524409800767899e-01
    z[0,3,2]  R228      9.0653824806213379e-01
    z[0,3,2]  R229      3.5717067122459412e-01
    z[0,3,2]  R230      4.4943377375602722e-02
    z[0,3,2]  R231      1.0355886816978455e-01
    z[0,3,2]  R232      0.0952523723244667
    z[0,3,2]  R233      2.0626203715801239e-01
    z[0,3,2]  R234      1.7021517455577850e-01
    z[0,3,2]  R235      1.0912785679101944e-01
    z[0,3,2]  R236      1.3099455833435059e-01
    z[0,3,2]  R237      -0.495866984128952
    z[0,3,2]  R238      -2.7213424444198608e-01
    z[0,3,2]  R239      -4.5838269591331482e-01
    z[0,3,2]  R240      -1.9348157942295074e-01
    z[0,3,2]  R241      -2.4002535641193390e-01
    z[0,3,2]  R242      4.5512345433235168e-01
    z[0,3,2]  R243      -5.1767438650131226e-01
    z[0,3,2]  R244      -1.0964465141296387e-01
    z[0,3,2]  R245      -5.0401580333709717e-01
    z[0,3,2]  R246      -5.6539905071258545e-01
    z[0,3,2]  R247      5.5173772573471069e-01
    z[0,3,2]  R248      5.5275803804397583e-01
    z[0,3,2]  R249      5.4552298039197922e-02
    z[0,3,2]  R250      1.4933989942073822e-01
    z[0,3,2]  R251      5.3784090280532837e-01
    z[0,3,2]  R252      0.512365460395813
    z[0,3,2]  R253      0.704929530620575
    z[0,3,2]  R254      5.2729690074920654e-01
    z[0,3,2]  R255      7.4078536033630371e-01
    z[0,3,2]  R256      -0.0430370569229126
    z[0,3,2]  R257      4.1135424375534058e-01
    z[0,3,2]  R258      2.5374436378479004e-01
    z[0,3,2]  R259      2.1532240509986877e-01
    z[0,3,2]  R260      -5.2365595102310181e-01
    z[0,3,2]  R261      2.4641571938991547e-01
    z[0,3,2]  R262      -2.0875306427478790e-01
    z[0,3,2]  R263      -1.6267299652099609e-01
    z[0,3,2]  R264      -4.1821032762527466e-01
    z[0,3,2]  R265      -2.5715437531471252e-01
    z[0,3,2]  R266      -1.4770062267780304e-01
    z[0,3,2]  R267      7.1830958127975464e-01
    z[0,3,2]  R268      4.5473849773406982e-01
    z[0,3,2]  R269      4.6605947613716125e-01
    z[0,3,2]  R270      3.6716330051422119e-01
    z[0,3,2]  R271      3.0969995260238647e-01
    z[0,3,2]  R272      -6.9029003381729126e-01
    z[0,3,2]  R273      3.0808454751968384e-01
    z[0,3,2]  R274      -5.3008008003234863e-01
    z[0,3,2]  R275      4.1050696372985840e-01
    z[0,3,2]  R276      -1.5325441956520081e-01
    z[0,3,2]  R277      4.5818847417831421e-01
    z[0,3,2]  R278      4.3385028839111328e-01
    z[0,3,2]  R279      2.0720952749252319e-01
    z[0,3,2]  R280      6.1554181575775146e-01
    z[0,3,2]  R281      -1.8043044209480286e-01
    z[0,3,2]  R282      5.0926405191421509e-01
    z[0,3,2]  R283      0.601693332195282
    z[0,3,2]  R284      3.4847456216812134e-01
    z[0,3,2]  R285      1.5690174698829651e-01
    z[0,3,2]  R286      2.4623838067054749e-01
    z[0,3,2]  R287      4.4899916648864746e-01
    z[0,3,2]  R288      -2.7870857715606689e-01
    z[0,3,2]  R289      8.3460563421249390e-01
    z[0,3,2]  R290      -1.3503019511699677e-01
    z[0,3,2]  R291      0.885668933391571
    z[0,3,2]  R292      4.7445856034755707e-02
    z[0,3,2]  R293      7.3200774192810059e-01
    z[0,3,2]  R294      2.9898330569267273e-01
    z[0,3,2]  R295      4.1195716708898544e-02
    z[0,3,2]  R296      1.0171540081501007e-01
    z[0,3,2]  R297      0.672829806804657
    z[0,3,2]  R298      3.6227068305015564e-01
    z[0,3,2]  R299      3.1364640593528748e-01
    z[0,3,2]  R300      4.2406827211380005e-01
    z[0,3,2]  R301      4.3404987454414368e-01
    z[0,3,2]  R302      -6.8644896149635315e-02
    z[0,3,2]  R303      0.256710946559906
    z[0,3,2]  R304      -1.0159547626972198e-01
    z[0,3,2]  R305      -5.5583781003952026e-01
    z[0,3,2]  R306      -4.9035421013832092e-01
    z[0,3,2]  R307      6.7314106225967407e-01
    z[0,3,2]  R308      4.7472253441810608e-01
    z[0,3,2]  R309      1.0133743286132812e-01
    z[0,3,2]  R310      2.0631836354732513e-01
    z[0,3,2]  R311      5.0050681829452515e-01
    z[0,3,2]  R312      -2.1060007810592651e-01
    z[0,3,2]  R313      6.1223471164703369e-01
    z[0,3,2]  R314      5.7189010083675385e-02
    z[0,3,2]  R315      2.2347699105739594e-01
    z[0,3,2]  R316      -1.4080753922462463e-01
    z[0,3,2]  R317      -2.3597948253154755e-01
    z[0,3,2]  R318      5.6909757852554321e-01
    z[0,3,2]  R319      -4.2687880992889404e-01
    z[0,3,2]  R320      4.4247588515281677e-01
    z[0,3,2]  R321      -3.9816579222679138e-01
    z[0,3,2]  R322      4.3460118770599365e-01
    z[0,3,2]  R323      -6.5257710218429565e-01
    z[0,3,2]  R324      -4.8077547550201416e-01
    z[0,3,2]  R325      -1.4383430778980255e-01
    z[0,3,2]  R326      3.4261253476142883e-01
    z[0,3,3]  R5        -1
    z[0,3,3]  R32       1
    z[0,3,3]  R199      -1
    z[0,3,3]  R200      1
    z[0,3,3]  R207      -8.3205364644527435e-02
    z[0,3,3]  R208      -9.7979776561260223e-02
    z[0,3,3]  R209      -1.7353199422359467e-01
    z[0,3,3]  R210      -1.8601258099079132e-01
    z[0,3,3]  R211      3.3038654923439026e-01
    z[0,3,3]  R212      7.3983728885650635e-01
    z[0,3,3]  R213      6.1978113651275635e-01
    z[0,3,3]  R214      5.2550071477890015e-01
    z[0,3,3]  R215      3.7971699237823486e-01
    z[0,3,3]  R216      6.7948889732360840e-01
    z[0,3,3]  R217      -3.8932007551193237e-01
    z[0,3,3]  R218      -3.4803071618080139e-01
    z[0,3,3]  R219      -2.2948299348354340e-01
    z[0,3,3]  R220      -3.1289437413215637e-01
    z[0,3,3]  R221      -0.391677588224411
    z[0,3,3]  R222      -7.3276035487651825e-02
    z[0,3,3]  R223      -3.8164338469505310e-01
    z[0,3,3]  R224      -1.2850166857242584e-01
    z[0,3,3]  R225      -2.4046956002712250e-01
    z[0,3,3]  R226      -4.5718687772750854e-01
    z[0,3,3]  R227      -7.4527716636657715e-01
    z[0,3,3]  R228      -2.4984714388847351e-01
    z[0,3,3]  R229      -3.7330493330955505e-02
    z[0,3,3]  R230      -2.2512030601501465e-01
    z[0,3,3]  R231      -2.2528481483459473e-01
    z[0,3,3]  R232      -2.2371117770671844e-01
    z[0,3,3]  R233      -2.6315337419509888e-01
    z[0,3,3]  R234      -1.7843115329742432e-01
    z[0,3,3]  R235      -1.7954248934984207e-02
    z[0,3,3]  R236      -1.1924888193607330e-01
    z[0,3,3]  R237      3.7420988082885742e-01
    z[0,3,3]  R238      6.7907691001892090e-01
    z[0,3,3]  R239      4.3427556753158569e-01
    z[0,3,3]  R240      5.0297158956527710e-01
    z[0,3,3]  R241      6.7577290534973145e-01
    z[0,3,3]  R242      -2.4416683614253998e-01
    z[0,3,3]  R243      1.3043354451656342e-01
    z[0,3,3]  R244      2.3145893216133118e-01
    z[0,3,3]  R245      3.4173694252967834e-01
    z[0,3,3]  R246      3.4725794196128845e-01
    z[0,3,3]  R247      -3.9352294057607651e-02
    z[0,3,3]  R248      -2.0397897064685822e-01
    z[0,3,3]  R249      1.7381841316819191e-02
    z[0,3,3]  R250      -1.0820031911134720e-01
    z[0,3,3]  R251      -2.0943066477775574e-01
    z[0,3,3]  R252      -2.5197410583496094e-01
    z[0,3,3]  R253      2.8585383668541908e-02
    z[0,3,3]  R254      -3.0092450976371765e-01
    z[0,3,3]  R255      -4.6742090582847595e-01
    z[0,3,3]  R256      -3.0300248414278030e-02
    z[0,3,3]  R257      -6.7259013652801514e-01
    z[0,3,3]  R258      -5.8234238624572754e-01
    z[0,3,3]  R259      -4.4266286492347717e-01
    z[0,3,3]  R260      6.7975777387619019e-01
    z[0,3,3]  R261      -5.2452695369720459e-01
    z[0,3,3]  R262      -1.4348666369915009e-01
    z[0,3,3]  R263      -8.2589067518711090e-02
    z[0,3,3]  R264      -2.4972349405288696e-01
    z[0,3,3]  R265      -1.6817671060562134e-01
    z[0,3,3]  R266      -2.3673868179321289e-01
    z[0,3,3]  R267      -6.9535695016384125e-02
    z[0,3,3]  R268      -2.5063166022300720e-01
    z[0,3,3]  R269      -2.6369345188140869e-01
    z[0,3,3]  R270      -3.9013007283210754e-01
    z[0,3,3]  R271      -3.8972941040992737e-01
    z[0,3,3]  R272      2.8705161809921265e-01
    z[0,3,3]  R273      7.6106287539005280e-02
    z[0,3,3]  R274      5.8734875917434692e-01
    z[0,3,3]  R275      4.8898744583129883e-01
    z[0,3,3]  R276      -4.2992007732391357e-01
    z[0,3,3]  R277      -4.4301679730415344e-01
    z[0,3,3]  R278      -1.8483416736125946e-01
    z[0,3,3]  R279      -0.665672242641449
    z[0,3,3]  R280      -4.3565583229064941e-01
    z[0,3,3]  R281      -4.9580168724060059e-01
    z[0,3,3]  R282      1.5340850688517094e-02
    z[0,3,3]  R283      -2.3656207323074341e-01
    z[0,3,3]  R284      4.2897865176200867e-01
    z[0,3,3]  R285      2.7163015678524971e-02
    z[0,3,3]  R286      -1.9019616767764091e-02
    z[0,3,3]  R287      -3.0038860440254211e-01
    z[0,3,3]  R288      -0.324074387550354
    z[0,3,3]  R289      -1.2518766522407532e-01
    z[0,3,3]  R290      7.3851294815540314e-02
    z[0,3,3]  R291      -2.6993727311491966e-02
    z[0,3,3]  R292      -2.3950931429862976e-01
    z[0,3,3]  R293      -8.0155604518949986e-04
    z[0,3,3]  R294      -6.5887951850891113e-01
    z[0,3,3]  R295      -2.7802556753158569e-01
    z[0,3,3]  R296      -9.0073829889297485e-01
    z[0,3,3]  R297      -3.9974990487098694e-01
    z[0,3,3]  R298      -7.0483297109603882e-01
    z[0,3,3]  R299      -0.636849045753479
    z[0,3,3]  R300      1.4090560376644135e-01
    z[0,3,3]  R301      4.3926298618316650e-01
    z[0,3,3]  R302      1.7935261130332947e-01
    z[0,3,3]  R303      -4.4287670403718948e-02
    z[0,3,3]  R304      -1.9506633281707764e-01
    z[0,3,3]  R305      4.2763477563858032e-01
    z[0,3,3]  R306      2.4731636047363281e-01
    z[0,3,3]  R307      -4.1987213492393494e-01
    z[0,3,3]  R308      -5.4470568895339966e-01
    z[0,3,3]  R309      -2.0091973245143890e-01
    z[0,3,3]  R310      5.7016885280609131e-01
    z[0,3,3]  R311      1.8288058042526245e-01
    z[0,3,3]  R312      5.7683402299880981e-01
    z[0,3,3]  R313      9.9328316748142242e-02
    z[0,3,3]  R314      -2.7665802836418152e-01
    z[0,3,3]  R315      -2.5349313020706177e-01
    z[0,3,3]  R316      -3.3209922909736633e-01
    z[0,3,3]  R317      -5.1900601387023926e-01
    z[0,3,3]  R318      -3.1045249104499817e-01
    z[0,3,3]  R319      3.1423109769821167e-01
    z[0,3,3]  R320      2.1137748658657074e-01
    z[0,3,3]  R321      2.8813469409942627e-01
    z[0,3,3]  R322      4.5024354010820389e-02
    z[0,3,3]  R323      5.6768339872360229e-01
    z[0,3,3]  R324      5.4710513353347778e-01
    z[0,3,3]  R325      2.6591575145721436e-01
    z[0,3,3]  R326      -1.4462395012378693e-01
    z[0,3,4]  R6        -1
    z[0,3,4]  R33       1
    z[0,3,4]  R201      -1
    z[0,3,4]  R202      1
    z[0,3,4]  R207      -2.9927557706832886e-01
    z[0,3,4]  R208      -1.4534645713865757e-02
    z[0,3,4]  R209      -2.4281892180442810e-01
    z[0,3,4]  R210      3.9431157708168030e-01
    z[0,3,4]  R211      7.5061666965484619e-01
    z[0,3,4]  R212      1.5398919582366943e-01
    z[0,3,4]  R213      1.2913782894611359e-01
    z[0,3,4]  R214      2.4086086452007294e-01
    z[0,3,4]  R215      2.9865931719541550e-02
    z[0,3,4]  R216      -0.0674920454621315
    z[0,3,4]  R217      -3.2286904752254486e-02
    z[0,3,4]  R218      -1.5856406092643738e-01
    z[0,3,4]  R219      -1.2010575085878372e-01
    z[0,3,4]  R220      2.7923974394798279e-01
    z[0,3,4]  R221      3.3129815012216568e-02
    z[0,3,4]  R222      0.0536414310336113
    z[0,3,4]  R223      -1.6545827686786652e-01
    z[0,3,4]  R224      1.6787317395210266e-01
    z[0,3,4]  R225      -3.8327416405081749e-03
    z[0,3,4]  R226      4.7427740693092346e-01
    z[0,3,4]  R227      -2.8334513306617737e-01
    z[0,3,4]  R228      -1.2642596662044525e-01
    z[0,3,4]  R229      -2.0384061336517334e-01
    z[0,3,4]  R230      1.3957025110721588e-01
    z[0,3,4]  R231      -1.3012272119522095e-01
    z[0,3,4]  R232      0.284850537776947
    z[0,3,4]  R233      -0.086112841963768
    z[0,3,4]  R234      7.7297821640968323e-02
    z[0,3,4]  R235      8.5844539105892181e-02
    z[0,3,4]  R236      -2.8101390600204468e-01
    z[0,3,4]  R237      -4.6652253717184067e-02
    z[0,3,4]  R238      -2.4003187194466591e-02
    z[0,3,4]  R239      4.5995318889617920e-01
    z[0,3,4]  R240      2.9704380035400391e-01
    z[0,3,4]  R241      2.0661835372447968e-01
    z[0,3,4]  R242      -2.1915614604949951e-01
    z[0,3,4]  R243      1.3381545245647430e-01
    z[0,3,4]  R244      -1.3279208540916443e-01
    z[0,3,4]  R245      -1.2246138602495193e-01
    z[0,3,4]  R246      3.7044730782508850e-01
    z[0,3,4]  R247      0.0644272193312645
    z[0,3,4]  R248      1.7407299578189850e-01
    z[0,3,4]  R249      -1.0715722292661667e-01
    z[0,3,4]  R250      -1.4778789877891541e-01
    z[0,3,4]  R251      -1.4112314581871033e-01
    z[0,3,4]  R252      2.2384163737297058e-01
    z[0,3,4]  R253      1.7793895304203033e-01
    z[0,3,4]  R254      4.4721037149429321e-01
    z[0,3,4]  R255      -0.0606394037604332
    z[0,3,4]  R256      1.2662783265113831e-01
    z[0,3,4]  R257      1.7410339415073395e-01
    z[0,3,4]  R258      3.4294697642326355e-01
    z[0,3,4]  R259      0.0515059269964695
    z[0,3,4]  R260      -3.0618287622928619e-02
    z[0,3,4]  R261      1.1818935722112656e-01
    z[0,3,4]  R262      -2.5935724377632141e-01
    z[0,3,4]  R263      -7.0793621242046356e-02
    z[0,3,4]  R264      -2.3014941811561584e-01
    z[0,3,4]  R265      -2.3294666409492493e-01
    z[0,3,4]  R266      2.0637065172195435e-01
    z[0,3,4]  R267      -4.1234114766120911e-01
    z[0,3,4]  R268      4.6587803959846497e-01
    z[0,3,4]  R269      0.31876340508461
    z[0,3,4]  R270      -1.3341650366783142e-01
    z[0,3,4]  R271      -4.1229271888732910e-01
    z[0,3,4]  R272      2.4737310409545898e-01
    z[0,3,4]  R273      0.0967501625418663
    z[0,3,4]  R274      4.6853196620941162e-01
    z[0,3,4]  R275      3.2393902540206909e-01
    z[0,3,4]  R276      1.9697868824005127e-01
    z[0,3,4]  R277      2.0611914992332458e-01
    z[0,3,4]  R278      -2.7662146091461182e-01
    z[0,3,4]  R279      -2.1774184703826904e-01
    z[0,3,4]  R280      -1.7755937576293945e-01
    z[0,3,4]  R281      -6.5851235389709473e-01
    z[0,3,4]  R282      -6.3356764614582062e-02
    z[0,3,4]  R283      -9.6845224499702454e-02
    z[0,3,4]  R284      2.3995047807693481e-01
    z[0,3,4]  R285      -1.2424138188362122e-01
    z[0,3,4]  R286      1.5257167816162109e-01
    z[0,3,4]  R287      -8.3643466234207153e-02
    z[0,3,4]  R288      -1.0962177067995071e-01
    z[0,3,4]  R289      -3.1764388084411621e-01
    z[0,3,4]  R290      1.7952004075050354e-01
    z[0,3,4]  R291      3.9193700999021530e-02
    z[0,3,4]  R292      1.7649734020233154e-01
    z[0,3,4]  R293      0.24935382604599
    z[0,3,4]  R294      8.4604196250438690e-02
    z[0,3,4]  R295      -2.7523839473724365e-01
    z[0,3,4]  R296      2.5690355896949768e-01
    z[0,3,4]  R297      1.5428103506565094e-01
    z[0,3,4]  R298      1.6195248812437057e-02
    z[0,3,4]  R299      8.7646394968032837e-02
    z[0,3,4]  R300      2.2998262941837311e-01
    z[0,3,4]  R301      -8.0991901457309723e-02
    z[0,3,4]  R302      1.5155556797981262e-01
    z[0,3,4]  R303      -6.2881387770175934e-02
    z[0,3,4]  R304      -1.9795902073383331e-01
    z[0,3,4]  R305      -2.9808852076530457e-01
    z[0,3,4]  R306      -2.7864545583724976e-01
    z[0,3,4]  R307      -5.4691050201654434e-02
    z[0,3,4]  R308      -1.0489811003208160e-01
    z[0,3,4]  R309      -2.9336953163146973e-01
    z[0,3,4]  R310      2.2056722640991211e-01
    z[0,3,4]  R311      9.9898435175418854e-02
    z[0,3,4]  R312      -4.8859912157058716e-01
    z[0,3,4]  R313      3.5315670073032379e-02
    z[0,3,4]  R314      -2.1309521794319153e-01
    z[0,3,4]  R315      8.6106121540069580e-01
    z[0,3,4]  R316      3.3534392714500427e-01
    z[0,3,4]  R317      -3.8835567235946655e-01
    z[0,3,4]  R318      5.3314459323883057e-01
    z[0,3,4]  R319      -2.9568953439593315e-02
    z[0,3,4]  R320      -1.4985139667987823e-01
    z[0,3,4]  R321      0.320017009973526
    z[0,3,4]  R322      3.4514892101287842e-01
    z[0,3,4]  R323      -1.2468189746141434e-01
    z[0,3,4]  R324      3.4777253866195679e-02
    z[0,3,4]  R325      0.360971599817276
    z[0,3,4]  R326      -1.2381967157125473e-01
    z[0,3,5]  R7        -1
    z[0,3,5]  R34       1
    z[0,3,5]  R203      -1
    z[0,3,5]  R204      1
    z[0,3,5]  R207      -3.1696575880050659e-01
    z[0,3,5]  R208      1.7433136701583862e-01
    z[0,3,5]  R209      2.4230352044105530e-01
    z[0,3,5]  R210      -6.6690450906753540e-01
    z[0,3,5]  R211      -1.5532267093658447e-01
    z[0,3,5]  R212      -3.6824661493301392e-01
    z[0,3,5]  R213      -3.3464384078979492e-01
    z[0,3,5]  R214      -4.2328894138336182e-01
    z[0,3,5]  R215      -5.5316913127899170e-01
    z[0,3,5]  R216      6.3855066895484924e-02
    z[0,3,5]  R217      4.9023386836051941e-01
    z[0,3,5]  R218      4.3290632963180542e-01
    z[0,3,5]  R219      3.2704770565032959e-01
    z[0,3,5]  R220      5.5597817897796631e-01
    z[0,3,5]  R221      3.0266985297203064e-01
    z[0,3,5]  R222      0.515321671962738
    z[0,3,5]  R223      5.0135707855224609e-01
    z[0,3,5]  R224      2.6005271077156067e-01
    z[0,3,5]  R225      -2.8759138658642769e-03
    z[0,3,5]  R226      4.3018421530723572e-01
    z[0,3,5]  R227      4.5271337032318115e-01
    z[0,3,5]  R228      1.5657339990139008e-01
    z[0,3,5]  R229      -2.3221021890640259e-01
    z[0,3,5]  R230      -1.5560670197010040e-01
    z[0,3,5]  R231      -1.7040944099426270e-01
    z[0,3,5]  R232      -1.8913638591766357e-01
    z[0,3,5]  R233      -9.9175393581390381e-02
    z[0,3,5]  R234      -4.1674140095710754e-01
    z[0,3,5]  R235      -0.295710951089859
    z[0,3,5]  R236      -3.2845476269721985e-01
    z[0,3,5]  R237      -4.4074233621358871e-02
    z[0,3,5]  R238      -1.4495445787906647e-01
    z[0,3,5]  R239      -6.9058477878570557e-02
    z[0,3,5]  R240      -2.8482276201248169e-01
    z[0,3,5]  R241      1.8145045638084412e-01
    z[0,3,5]  R242      1.5429614484310150e-01
    z[0,3,5]  R243      -1.0010101646184921e-01
    z[0,3,5]  R244      -1.0949768126010895e-01
    z[0,3,5]  R245      -3.4235006570816040e-01
    z[0,3,5]  R246      1.0637746751308441e-01
    z[0,3,5]  R247      2.8287851810455322e-01
    z[0,3,5]  R248      2.0069922506809235e-01
    z[0,3,5]  R249      2.3118227720260620e-01
    z[0,3,5]  R250      -0.075913205742836
    z[0,3,5]  R251      0.535001814365387
    z[0,3,5]  R252      1.0893454402685165e-01
    z[0,3,5]  R253      2.9696938395500183e-01
    z[0,3,5]  R254      4.0769883990287781e-01
    z[0,3,5]  R255      -4.6716742217540741e-03
    z[0,3,5]  R256      2.5278747081756592e-01
    z[0,3,5]  R257      4.4447210431098938e-01
    z[0,3,5]  R258      5.4762428998947144e-01
    z[0,3,5]  R259      6.3761627674102783e-01
    z[0,3,5]  R260      -2.6111018657684326e-01
    z[0,3,5]  R261      6.4481425285339355e-01
    z[0,3,5]  R262      -3.5370582342147827e-01
    z[0,3,5]  R263      -4.5468306541442871e-01
    z[0,3,5]  R264      -0.252608984708786
    z[0,3,5]  R265      -5.0605303049087524e-01
    z[0,3,5]  R266      -4.5991146564483643e-01
    z[0,3,5]  R267      4.8409852385520935e-01
    z[0,3,5]  R268      0.587566614151001
    z[0,3,5]  R269      6.3206166028976440e-01
    z[0,3,5]  R270      5.8540689945220947e-01
    z[0,3,5]  R271      5.7594513893127441e-01
    z[0,3,5]  R272      -2.8168687224388123e-01
    z[0,3,5]  R273      5.8635663986206055e-01
    z[0,3,5]  R274      -1.1911985278129578e-01
    z[0,3,5]  R275      1.7296472191810608e-01
    z[0,3,5]  R276      -2.8461429476737976e-01
    z[0,3,5]  R277      5.6511014699935913e-01
    z[0,3,5]  R278      2.6678198575973511e-01
    z[0,3,5]  R279      4.8890298604965210e-01
    z[0,3,5]  R280      -0.0569256953895092
    z[0,3,5]  R281      -2.1289469301700592e-01
    z[0,3,5]  R282      2.3178681731224060e-01
    z[0,3,5]  R283      3.6339035630226135e-01
    z[0,3,5]  R284      4.3757492303848267e-01
    z[0,3,5]  R285      7.4298632144927979e-01
    z[0,3,5]  R286      5.8118617534637451e-01
    z[0,3,5]  R287      3.7851619720458984e-01
    z[0,3,5]  R288      -2.1907933056354523e-01
    z[0,3,5]  R289      2.9881912469863892e-01
    z[0,3,5]  R290      1.2832273729145527e-02
    z[0,3,5]  R291      3.4379380941390991e-01
    z[0,3,5]  R292      5.8337718248367310e-01
    z[0,3,5]  R293      5.1027429103851318e-01
    z[0,3,5]  R294      4.4948694109916687e-01
    z[0,3,5]  R295      1.1982368677854538e-01
    z[0,3,5]  R296      -0.0586259625852108
    z[0,3,5]  R297      6.0723256319761276e-02
    z[0,3,5]  R298      2.1167193353176117e-01
    z[0,3,5]  R299      5.9822231531143188e-02
    z[0,3,5]  R300      6.9899767637252808e-01
    z[0,3,5]  R301      1.0365897417068481e-01
    z[0,3,5]  R302      4.8748105764389038e-01
    z[0,3,5]  R303      8.9537531137466431e-01
    z[0,3,5]  R304      6.8468856811523438e-01
    z[0,3,5]  R305      -4.6031859517097473e-01
    z[0,3,5]  R306      -5.5460166931152344e-01
    z[0,3,5]  R307      2.7098900079727173e-01
    z[0,3,5]  R308      5.4674917459487915e-01
    z[0,3,5]  R309      -5.4734289646148682e-01
    z[0,3,5]  R310      4.1980616748332977e-02
    z[0,3,5]  R311      -1.3455897569656372e-01
    z[0,3,5]  R312      0.287685364484787
    z[0,3,5]  R313      6.1171799898147583e-01
    z[0,3,5]  R314      -1.0330747067928314e-01
    z[0,3,5]  R315      -1.2625804543495178e-01
    z[0,3,5]  R316      -1.2806738913059235e-01
    z[0,3,5]  R317      -2.3561830818653107e-01
    z[0,3,5]  R318      2.7680492401123047e-01
    z[0,3,5]  R319      -6.6292285919189453e-01
    z[0,3,5]  R320      5.4928410053253174e-01
    z[0,3,5]  R321      4.1932541131973267e-01
    z[0,3,5]  R322      0.254957914352417
    z[0,3,5]  R323      -7.9919271171092987e-02
    z[0,3,5]  R324      -4.2730411887168884e-01
    z[0,3,5]  R325      2.8728953003883362e-01
    z[0,3,5]  R326      1.8982259929180145e-01
    z[0,3,6]  R8        -1
    z[0,3,6]  R35       1
    z[0,3,6]  R205      -1
    z[0,3,6]  R206      1
    z[0,3,6]  R207      -5.2641708403825760e-02
    z[0,3,6]  R208      -7.2596031427383423e-01
    z[0,3,6]  R209      4.8680245876312256e-01
    z[0,3,6]  R210      -3.4748116135597229e-01
    z[0,3,6]  R211      2.1003337204456329e-01
    z[0,3,6]  R212      -1.6078585386276245e-01
    z[0,3,6]  R213      3.2989460229873657e-01
    z[0,3,6]  R214      -8.5307411849498749e-02
    z[0,3,6]  R215      -1.0709116607904434e-01
    z[0,3,6]  R216      6.1182132922112942e-03
    z[0,3,6]  R217      8.2008644938468933e-02
    z[0,3,6]  R218      -1.8016591668128967e-02
    z[0,3,6]  R219      -1.3011348247528076e-01
    z[0,3,6]  R220      0.0988316610455513
    z[0,3,6]  R221      -2.1994952857494354e-01
    z[0,3,6]  R222      -1.8067541718482971e-01
    z[0,3,6]  R223      -2.1669082343578339e-01
    z[0,3,6]  R224      2.9461972881108522e-03
    z[0,3,6]  R225      8.6019881069660187e-02
    z[0,3,6]  R226      2.1970807015895844e-01
    z[0,3,6]  R227      9.8284952342510223e-02
    z[0,3,6]  R228      -1.8110708892345428e-01
    z[0,3,6]  R229      1.7480035126209259e-01
    z[0,3,6]  R230      -2.2786696255207062e-01
    z[0,3,6]  R231      1.2980991601943970e-01
    z[0,3,6]  R232      1.6421090066432953e-01
    z[0,3,6]  R233      1.9882810115814209e-01
    z[0,3,6]  R234      3.1714759767055511e-02
    z[0,3,6]  R235      -2.6302960515022278e-01
    z[0,3,6]  R236      -1.8635952472686768e-01
    z[0,3,6]  R237      -1.5861645340919495e-01
    z[0,3,6]  R238      1.9234988093376160e-01
    z[0,3,6]  R239      -1.5485175885260105e-02
    z[0,3,6]  R240      1.6566525399684906e-01
    z[0,3,6]  R241      -2.8882148861885071e-01
    z[0,3,6]  R242      -4.2173019051551819e-01
    z[0,3,6]  R243      1.8046455085277557e-01
    z[0,3,6]  R244      -2.7422466874122620e-01
    z[0,3,6]  R245      1.2597066164016724e-01
    z[0,3,6]  R246      -3.1372427940368652e-01
    z[0,3,6]  R247      1.4145767688751221e-01
    z[0,3,6]  R248      -7.0472881197929382e-02
    z[0,3,6]  R249      6.9888085126876831e-02
    z[0,3,6]  R250      2.7485650032758713e-02
    z[0,3,6]  R251      1.8679074943065643e-01
    z[0,3,6]  R252      -2.7392706274986267e-01
    z[0,3,6]  R253      5.2603948116302490e-01
    z[0,3,6]  R254      2.9290032386779785e-01
    z[0,3,6]  R255      3.8864722847938538e-01
    z[0,3,6]  R256      -2.4102360010147095e-01
    z[0,3,6]  R257      -2.1817234158515930e-01
    z[0,3,6]  R258      -1.9706779718399048e-01
    z[0,3,6]  R259      -1.3251727819442749e-01
    z[0,3,6]  R260      -1.6446286439895630e-01
    z[0,3,6]  R261      2.6247581839561462e-01
    z[0,3,6]  R262      4.5745734125375748e-02
    z[0,3,6]  R263      2.3047868907451630e-01
    z[0,3,6]  R264      -5.9881657361984253e-02
    z[0,3,6]  R265      -9.4336703419685364e-02
    z[0,3,6]  R266      5.8939591050148010e-02
    z[0,3,6]  R267      -1.5689672902226448e-02
    z[0,3,6]  R268      -1.8470782786607742e-02
    z[0,3,6]  R269      4.1349419951438904e-01
    z[0,3,6]  R270      4.8553115129470825e-01
    z[0,3,6]  R271      1.9763223826885223e-01
    z[0,3,6]  R272      5.5701290257275105e-03
    z[0,3,6]  R273      -0.57218337059021
    z[0,3,6]  R274      1.4964535832405090e-01
    z[0,3,6]  R275      1.2106354348361492e-02
    z[0,3,6]  R276      -2.5076735019683838e-01
    z[0,3,6]  R277      2.1989084780216217e-01
    z[0,3,6]  R278      -2.6869857311248779e-01
    z[0,3,6]  R279      -2.6428046822547913e-01
    z[0,3,6]  R280      1.2014728784561157e-01
    z[0,3,6]  R281      -4.5258617401123047e-01
    z[0,3,6]  R282      4.2708730697631836e-01
    z[0,3,6]  R283      6.5108686685562134e-01
    z[0,3,6]  R284      0.0421893447637558
    z[0,3,6]  R285      -3.9146393537521362e-01
    z[0,3,6]  R286      -4.8854342103004456e-01
    z[0,3,6]  R287      -2.7119457721710205e-01
    z[0,3,6]  R288      -6.6284263134002686e-01
    z[0,3,6]  R289      9.0074427425861359e-02
    z[0,3,6]  R290      -9.5177195966243744e-02
    z[0,3,6]  R291      -2.7251252532005310e-01
    z[0,3,6]  R292      -2.9646283388137817e-01
    z[0,3,6]  R293      2.4682195484638214e-01
    z[0,3,6]  R294      -5.0488543510437012e-01
    z[0,3,6]  R295      -7.8267019987106323e-01
    z[0,3,6]  R296      2.8267474845051765e-02
    z[0,3,6]  R297      0.275452196598053
    z[0,3,6]  R298      -1.0823348909616470e-01
    z[0,3,6]  R299      -0.485553115606308
    z[0,3,6]  R300      3.1136220693588257e-01
    z[0,3,6]  R301      3.1912293285131454e-02
    z[0,3,6]  R302      9.7209677100181580e-02
    z[0,3,6]  R303      5.2639592438936234e-02
    z[0,3,6]  R304      4.7794154286384583e-01
    z[0,3,6]  R305      -9.5068022608757019e-02
    z[0,3,6]  R306      2.1829910576343536e-01
    z[0,3,6]  R307      8.0980263650417328e-02
    z[0,3,6]  R308      -1.9113582372665405e-01
    z[0,3,6]  R309      1.7105533182621002e-01
    z[0,3,6]  R310      -1.8997816741466522e-01
    z[0,3,6]  R311      -1.4648582041263580e-01
    z[0,3,6]  R312      9.8100811243057251e-02
    z[0,3,6]  R313      -3.3444008231163025e-01
    z[0,3,6]  R314      1.7640037834644318e-01
    z[0,3,6]  R315      2.6220846176147461e-01
    z[0,3,6]  R316      -1.7896692454814911e-01
    z[0,3,6]  R317      -2.0715422928333282e-01
    z[0,3,6]  R318      -2.8764620423316956e-01
    z[0,3,6]  R319      0.0504353865981102
    z[0,3,6]  R320      3.1272175908088684e-01
    z[0,3,6]  R321      2.3649330437183380e-01
    z[0,3,6]  R322      -2.9267209768295288e-01
    z[0,3,6]  R323      1.2861740775406361e-02
    z[0,3,6]  R324      3.5773232579231262e-01
    z[0,3,6]  R325      -7.4043780565261841e-02
    z[0,3,6]  R326      -3.3289868384599686e-02
    z[3,0,0]  R2        1
    z[3,0,0]  R29       -1
    z[3,0,0]  R327      -1
    z[3,0,0]  R328      1
    z[3,0,0]  R341      -7.3149889707565308e-01
    z[3,0,0]  R342      -4.6494984626770020e-01
    z[3,0,0]  R343      -5.5307424068450928e-01
    z[3,0,0]  R344      -6.4098256826400757e-01
    z[3,0,0]  R345      -4.6843826770782471e-01
    z[3,0,0]  R346      6.9115829467773438e-01
    z[3,0,0]  R347      -7.4154675006866455e-01
    z[3,0,0]  R348      -7.4062174558639526e-01
    z[3,0,0]  R349      -6.4864701032638550e-01
    z[3,0,0]  R350      -4.9817335605621338e-01
    z[3,0,0]  R351      2.0759922266006470e-01
    z[3,0,0]  R352      7.5057804584503174e-01
    z[3,0,0]  R353      -5.5326479673385620e-01
    z[3,0,0]  R354      -4.6926024556159973e-01
    z[3,0,0]  R355      3.9492759108543396e-01
    z[3,0,0]  R356      3.6992263793945312e-01
    z[3,0,0]  R357      2.0820197463035583e-01
    z[3,0,0]  R358      4.7991272062063217e-02
    z[3,0,0]  R359      1.1325430870056152e-01
    z[3,0,0]  R360      -5.5136060714721680e-01
    z[3,0,0]  R361      1.4380007982254028e-01
    z[3,0,0]  R362      3.2474073767662048e-01
    z[3,0,0]  R363      4.8364314436912537e-01
    z[3,0,0]  R364      -1.2364013493061066e-01
    z[3,0,0]  R365      2.0443318784236908e-01
    z[3,0,0]  R366      2.6790171861648560e-01
    z[3,0,0]  R367      1.7849633097648621e-01
    z[3,0,0]  R368      -0.0982329249382019
    z[3,0,0]  R369      1.9996878504753113e-01
    z[3,0,0]  R370      1.4755828678607941e-01
    z[3,0,0]  R371      1.6651113331317902e-01
    z[3,0,0]  R372      3.1945732235908508e-01
    z[3,0,0]  R373      1.4911076426506042e-01
    z[3,0,0]  R374      2.7498263120651245e-01
    z[3,0,0]  R375      3.6940187215805054e-01
    z[3,0,0]  R376      -4.3450483679771423e-01
    z[3,0,0]  R377      3.5477286577224731e-01
    z[3,0,0]  R378      -2.5958001613616943e-01
    z[3,0,0]  R379      5.5322623252868652e-01
    z[3,0,0]  R380      -6.8578487634658813e-01
    z[3,0,0]  R381      4.1563576459884644e-01
    z[3,0,0]  R382      6.5622836351394653e-01
    z[3,0,0]  R383      3.5397329926490784e-01
    z[3,0,0]  R384      5.3247994184494019e-01
    z[3,0,0]  R385      -1.4392016828060150e-01
    z[3,0,0]  R386      6.9569003582000732e-01
    z[3,0,0]  R387      1.2768420577049255e-01
    z[3,0,0]  R388      2.3055291175842285e-01
    z[3,0,0]  R389      0.437958300113678
    z[3,0,0]  R390      4.4579499959945679e-01
    z[3,0,0]  R391      6.4987319707870483e-01
    z[3,0,0]  R392      -4.2804482579231262e-01
    z[3,0,0]  R393      2.9841953516006470e-01
    z[3,0,0]  R394      -7.1220767498016357e-01
    z[3,0,0]  R395      1.4320926368236542e-01
    z[3,0,0]  R396      5.1414996385574341e-01
    z[3,0,0]  R397      4.6924032270908356e-02
    z[3,0,0]  R398      7.6293818652629852e-02
    z[3,0,0]  R399      3.7339481711387634e-01
    z[3,0,0]  R400      -2.5049021840095520e-01
    z[3,0,0]  R401      4.3164721131324768e-01
    z[3,0,0]  R402      5.1107597351074219e-01
    z[3,0,0]  R403      4.9693781137466431e-01
    z[3,0,0]  R404      3.2298576831817627e-01
    z[3,0,0]  R405      6.4064615964889526e-01
    z[3,0,0]  R406      -7.0324313640594482e-01
    z[3,0,0]  R407      1.7100089788436890e-01
    z[3,0,0]  R408      -2.4214620888233185e-01
    z[3,0,0]  R409      -3.0630099773406982e-01
    z[3,0,0]  R410      -4.8566347360610962e-01
    z[3,0,0]  R411      3.9700803160667419e-01
    z[3,0,0]  R412      3.1685985624790192e-02
    z[3,0,0]  R413      6.9347220659255981e-01
    z[3,0,0]  R414      -5.7144099473953247e-01
    z[3,0,0]  R415      5.4736936092376709e-01
    z[3,0,0]  R416      -5.0030130147933960e-01
    z[3,0,0]  R417      -1.4278750121593475e-01
    z[3,0,0]  R418      -4.9214673042297363e-01
    z[3,0,0]  R419      -3.1458348035812378e-02
    z[3,0,0]  R420      -2.7843341231346130e-01
    z[3,0,0]  R421      -6.0938209295272827e-01
    z[3,0,0]  R422      3.6866092681884766e-01
    z[3,0,0]  R423      -5.1106846332550049e-01
    z[3,0,0]  R424      5.4783982038497925e-01
    z[3,0,0]  R425      -4.9239164590835571e-01
    z[3,0,0]  R426      3.8289362192153931e-01
    z[3,0,0]  R427      -4.2543691396713257e-01
    z[3,0,0]  R428      -1.9382968544960022e-01
    z[3,0,0]  R429      -4.3683847784996033e-01
    z[3,0,0]  R430      -2.7887448668479919e-01
    z[3,0,0]  R431      -5.9820300340652466e-01
    z[3,0,0]  R432      2.6752209290862083e-02
    z[3,0,0]  R433      1.4091794192790985e-01
    z[3,0,0]  R434      1.2610922753810883e-01
    z[3,0,0]  R435      0.0849047303199768
    z[3,0,0]  R436      -3.2846769690513611e-01
    z[3,0,0]  R437      -2.1867901086807251e-01
    z[3,0,0]  R438      -5.2526682615280151e-01
    z[3,0,0]  R439      -3.5961836576461792e-01
    z[3,0,0]  R440      -4.2806681990623474e-01
    z[3,0,0]  R441      3.1716111302375793e-01
    z[3,0,0]  R442      4.8540952801704407e-01
    z[3,0,0]  R443      5.8673745393753052e-01
    z[3,0,0]  R444      1.8371842801570892e-01
    z[3,0,0]  R445      5.2187836170196533e-01
    z[3,0,0]  R446      1.9484703242778778e-01
    z[3,0,0]  R447      1.0001332312822342e-01
    z[3,0,0]  R448      6.5880334377288818e-01
    z[3,0,0]  R449      6.1596816778182983e-01
    z[3,0,0]  R450      3.1987023353576660e-01
    z[3,0,0]  R451      0.0441134050488472
    z[3,0,0]  R452      1.6030104458332062e-01
    z[3,0,0]  R453      5.2771796472370625e-03
    z[3,0,0]  R454      -5.4457515478134155e-02
    z[3,0,0]  R455      -7.4533924460411072e-02
    z[3,0,0]  R456      -4.4968039728701115e-03
    z[3,0,0]  R457      -2.6329222321510315e-01
    z[3,0,0]  R458      2.0365172624588013e-01
    z[3,0,0]  R459      2.1670965850353241e-01
    z[3,0,0]  R460      2.1826069802045822e-02
    z[3,0,1]  R3        1
    z[3,0,1]  R30       -1
    z[3,0,1]  R329      -1
    z[3,0,1]  R330      1
    z[3,0,1]  R341      -2.2296635806560516e-01
    z[3,0,1]  R342      -4.3592748045921326e-01
    z[3,0,1]  R343      -2.8077259659767151e-01
    z[3,0,1]  R344      -3.1925195455551147e-01
    z[3,0,1]  R345      -3.2749226689338684e-01
    z[3,0,1]  R346      -7.6501101255416870e-02
    z[3,0,1]  R347      -3.2344156503677368e-01
    z[3,0,1]  R348      -0.530152440071106
    z[3,0,1]  R349      -2.4570703506469727e-01
    z[3,0,1]  R350      -2.5414341688156128e-01
    z[3,0,1]  R351      7.3943096399307251e-01
    z[3,0,1]  R352      1.1804948002099991e-01
    z[3,0,1]  R353      7.8791356086730957e-01
    z[3,0,1]  R354      8.4700977802276611e-01
    z[3,0,1]  R355      4.1214641928672791e-01
    z[3,0,1]  R356      6.3256627321243286e-01
    z[3,0,1]  R357      2.4967686831951141e-01
    z[3,0,1]  R358      4.2082428932189941e-01
    z[3,0,1]  R359      2.5530877709388733e-01
    z[3,0,1]  R360      7.4511927366256714e-01
    z[3,0,1]  R361      -2.8681892156600952e-01
    z[3,0,1]  R362      -1.8626321852207184e-01
    z[3,0,1]  R363      -3.1145927309989929e-01
    z[3,0,1]  R364      3.9020884037017822e-01
    z[3,0,1]  R365      -3.5172438621520996e-01
    z[3,0,1]  R366      -0.818288266658783
    z[3,0,1]  R367      -8.1852716207504272e-01
    z[3,0,1]  R368      -7.9543876647949219e-01
    z[3,0,1]  R369      -0.739153265953064
    z[3,0,1]  R370      -8.0173850059509277e-01
    z[3,0,1]  R371      2.1644264459609985e-01
    z[3,0,1]  R372      2.5637015700340271e-01
    z[3,0,1]  R373      1.3758948445320129e-01
    z[3,0,1]  R374      -2.0281149446964264e-01
    z[3,0,1]  R375      -2.7382951974868774e-01
    z[3,0,1]  R376      3.3426719903945923e-01
    z[3,0,1]  R377      3.0472838878631592e-01
    z[3,0,1]  R378      2.2483146190643311e-01
    z[3,0,1]  R379      3.8899382948875427e-01
    z[3,0,1]  R380      3.7241196632385254e-01
    z[3,0,1]  R381      -0.104210764169693
    z[3,0,1]  R382      3.5648781061172485e-01
    z[3,0,1]  R383      -1.7990475893020630e-01
    z[3,0,1]  R384      3.1396555900573730e-01
    z[3,0,1]  R385      1.3082636892795563e-01
    z[3,0,1]  R386      -1.2762185931205750e-01
    z[3,0,1]  R387      1.8831813707947731e-02
    z[3,0,1]  R388      6.2494814395904541e-01
    z[3,0,1]  R389      2.4925498664379120e-01
    z[3,0,1]  R390      3.7488889694213867e-01
    z[3,0,1]  R391      2.4902611970901489e-01
    z[3,0,1]  R392      3.6701738834381104e-01
    z[3,0,1]  R393      -2.0082278177142143e-02
    z[3,0,1]  R394      6.5392822027206421e-01
    z[3,0,1]  R395      -1.8960449844598770e-02
    z[3,0,1]  R396      -0.465471476316452
    z[3,0,1]  R397      2.8015002608299255e-01
    z[3,0,1]  R398      8.0995447933673859e-02
    z[3,0,1]  R399      2.8088155388832092e-01
    z[3,0,1]  R400      -2.1294054388999939e-01
    z[3,0,1]  R401      3.1275704503059387e-01
    z[3,0,1]  R402      -2.3235730826854706e-01
    z[3,0,1]  R403      4.5602791011333466e-02
    z[3,0,1]  R404      2.3990756273269653e-01
    z[3,0,1]  R405      4.3577298521995544e-01
    z[3,0,1]  R406      -4.4554811716079712e-01
    z[3,0,1]  R407      0.307367742061615
    z[3,0,1]  R408      -3.9569985866546631e-01
    z[3,0,1]  R409      -3.2336461544036865e-01
    z[3,0,1]  R410      -1.7215554416179657e-01
    z[3,0,1]  R411      3.6054009199142456e-01
    z[3,0,1]  R412      3.6119109392166138e-01
    z[3,0,1]  R413      -2.3140546679496765e-01
    z[3,0,1]  R414      -4.6828567981719971e-01
    z[3,0,1]  R415      6.0571485757827759e-01
    z[3,0,1]  R416      -2.0369865000247955e-01
    z[3,0,1]  R417      3.2805186510086060e-01
    z[3,0,1]  R418      -7.6862359046936035e-01
    z[3,0,1]  R419      -2.4225763976573944e-01
    z[3,0,1]  R420      -7.9465228319168091e-01
    z[3,0,1]  R421      2.3313266038894653e-01
    z[3,0,1]  R422      -1.5226179733872414e-02
    z[3,0,1]  R423      -1.2230127304792404e-01
    z[3,0,1]  R424      1.9350171089172363e-01
    z[3,0,1]  R425      -4.2640250921249390e-01
    z[3,0,1]  R426      6.2665677070617676e-01
    z[3,0,1]  R427      -2.2087098658084869e-01
    z[3,0,1]  R428      3.4668478369712830e-01
    z[3,0,1]  R429      -7.0672088861465454e-01
    z[3,0,1]  R430      -8.5525280237197876e-01
    z[3,0,1]  R431      -0.657133936882019
    z[3,0,1]  R432      -6.5364474058151245e-01
    z[3,0,1]  R433      -7.6764965057373047e-01
    z[3,0,1]  R434      -4.7385737299919128e-01
    z[3,0,1]  R435      -4.8659288883209229e-01
    z[3,0,1]  R436      -7.9586714506149292e-02
    z[3,0,1]  R437      2.1789185702800751e-02
    z[3,0,1]  R438      0.321778267621994
    z[3,0,1]  R439      3.7625849246978760e-01
    z[3,0,1]  R440      5.0493443012237549e-01
    z[3,0,1]  R441      3.8211745023727417e-01
    z[3,0,1]  R442      4.1849234700202942e-01
    z[3,0,1]  R443      2.7541452646255493e-01
    z[3,0,1]  R444      3.8110509514808655e-01
    z[3,0,1]  R445      4.8911538720130920e-01
    z[3,0,1]  R446      1.9841021299362183e-01
    z[3,0,1]  R447      3.5478931665420532e-01
    z[3,0,1]  R448      4.7508573532104492e-01
    z[3,0,1]  R449      2.5571373105049133e-01
    z[3,0,1]  R450      2.9233837127685547e-01
    z[3,0,1]  R451      3.6666190624237061e-01
    z[3,0,1]  R452      1.2949857115745544e-01
    z[3,0,1]  R453      8.6312222480773926e-01
    z[3,0,1]  R454      9.2125928401947021e-01
    z[3,0,1]  R455      0.932815670967102
    z[3,0,1]  R456      8.9273869991302490e-01
    z[3,0,1]  R457      8.7298315763473511e-01
    z[3,0,1]  R458      8.4679442644119263e-01
    z[3,0,1]  R459      0.881366491317749
    z[3,0,1]  R460      8.6403840780258179e-01
    z[3,0,2]  R4        1
    z[3,0,2]  R31       -1
    z[3,0,2]  R331      -1
    z[3,0,2]  R332      1
    z[3,0,2]  R341      -0.495866984128952
    z[3,0,2]  R342      -2.7213424444198608e-01
    z[3,0,2]  R343      -4.5838269591331482e-01
    z[3,0,2]  R344      -1.9348157942295074e-01
    z[3,0,2]  R345      -2.4002535641193390e-01
    z[3,0,2]  R346      4.5512345433235168e-01
    z[3,0,2]  R347      -5.1767438650131226e-01
    z[3,0,2]  R348      -1.0964465141296387e-01
    z[3,0,2]  R349      -5.0401580333709717e-01
    z[3,0,2]  R350      -5.6539905071258545e-01
    z[3,0,2]  R351      5.5173772573471069e-01
    z[3,0,2]  R352      5.5275803804397583e-01
    z[3,0,2]  R353      5.4552298039197922e-02
    z[3,0,2]  R354      1.4933989942073822e-01
    z[3,0,2]  R355      5.3784090280532837e-01
    z[3,0,2]  R356      0.512365460395813
    z[3,0,2]  R357      0.704929530620575
    z[3,0,2]  R358      5.2729690074920654e-01
    z[3,0,2]  R359      7.4078536033630371e-01
    z[3,0,2]  R360      -0.0430370569229126
    z[3,0,2]  R361      4.1135424375534058e-01
    z[3,0,2]  R362      2.5374436378479004e-01
    z[3,0,2]  R363      2.1532240509986877e-01
    z[3,0,2]  R364      -5.2365595102310181e-01
    z[3,0,2]  R365      2.4641571938991547e-01
    z[3,0,2]  R366      -2.0875306427478790e-01
    z[3,0,2]  R367      -1.6267299652099609e-01
    z[3,0,2]  R368      -4.1821032762527466e-01
    z[3,0,2]  R369      -2.5715437531471252e-01
    z[3,0,2]  R370      -1.4770062267780304e-01
    z[3,0,2]  R371      7.1830958127975464e-01
    z[3,0,2]  R372      4.5473849773406982e-01
    z[3,0,2]  R373      4.6605947613716125e-01
    z[3,0,2]  R374      3.6716330051422119e-01
    z[3,0,2]  R375      3.0969995260238647e-01
    z[3,0,2]  R376      -6.9029003381729126e-01
    z[3,0,2]  R377      3.0808454751968384e-01
    z[3,0,2]  R378      -5.3008008003234863e-01
    z[3,0,2]  R379      4.1050696372985840e-01
    z[3,0,2]  R380      -1.5325441956520081e-01
    z[3,0,2]  R381      4.5818847417831421e-01
    z[3,0,2]  R382      4.3385028839111328e-01
    z[3,0,2]  R383      2.0720952749252319e-01
    z[3,0,2]  R384      6.1554181575775146e-01
    z[3,0,2]  R385      -1.8043044209480286e-01
    z[3,0,2]  R386      5.0926405191421509e-01
    z[3,0,2]  R387      0.601693332195282
    z[3,0,2]  R388      3.4847456216812134e-01
    z[3,0,2]  R389      1.5690174698829651e-01
    z[3,0,2]  R390      2.4623838067054749e-01
    z[3,0,2]  R391      4.4899916648864746e-01
    z[3,0,2]  R392      -2.7870857715606689e-01
    z[3,0,2]  R393      8.3460563421249390e-01
    z[3,0,2]  R394      -1.3503019511699677e-01
    z[3,0,2]  R395      0.885668933391571
    z[3,0,2]  R396      4.7445856034755707e-02
    z[3,0,2]  R397      7.3200774192810059e-01
    z[3,0,2]  R398      2.9898330569267273e-01
    z[3,0,2]  R399      4.1195716708898544e-02
    z[3,0,2]  R400      1.0171540081501007e-01
    z[3,0,2]  R401      0.672829806804657
    z[3,0,2]  R402      3.6227068305015564e-01
    z[3,0,2]  R403      3.1364640593528748e-01
    z[3,0,2]  R404      4.2406827211380005e-01
    z[3,0,2]  R405      4.3404987454414368e-01
    z[3,0,2]  R406      -6.8644896149635315e-02
    z[3,0,2]  R407      0.256710946559906
    z[3,0,2]  R408      -1.0159547626972198e-01
    z[3,0,2]  R409      -5.5583781003952026e-01
    z[3,0,2]  R410      -4.9035421013832092e-01
    z[3,0,2]  R411      6.7314106225967407e-01
    z[3,0,2]  R412      4.7472253441810608e-01
    z[3,0,2]  R413      1.0133743286132812e-01
    z[3,0,2]  R414      2.0631836354732513e-01
    z[3,0,2]  R415      5.0050681829452515e-01
    z[3,0,2]  R416      -2.1060007810592651e-01
    z[3,0,2]  R417      6.1223471164703369e-01
    z[3,0,2]  R418      5.7189010083675385e-02
    z[3,0,2]  R419      2.2347699105739594e-01
    z[3,0,2]  R420      -1.4080753922462463e-01
    z[3,0,2]  R421      -2.3597948253154755e-01
    z[3,0,2]  R422      5.6909757852554321e-01
    z[3,0,2]  R423      -4.2687880992889404e-01
    z[3,0,2]  R424      4.4247588515281677e-01
    z[3,0,2]  R425      -3.9816579222679138e-01
    z[3,0,2]  R426      4.3460118770599365e-01
    z[3,0,2]  R427      -6.5257710218429565e-01
    z[3,0,2]  R428      -4.8077547550201416e-01
    z[3,0,2]  R429      -1.4383430778980255e-01
    z[3,0,2]  R430      3.4261253476142883e-01
    z[3,0,2]  R431      -1.0295970737934113e-01
    z[3,0,2]  R432      -6.9366976618766785e-02
    z[3,0,2]  R433      7.8065022826194763e-02
    z[3,0,2]  R434      6.2996618449687958e-02
    z[3,0,2]  R435      -1.2328308075666428e-01
    z[3,0,2]  R436      -3.9146584272384644e-01
    z[3,0,2]  R437      -0.574528157711029
    z[3,0,2]  R438      -3.1612914800643921e-01
    z[3,0,2]  R439      -5.1629710197448730e-01
    z[3,0,2]  R440      -0.302365243434906
    z[3,0,2]  R441      0.594750165939331
    z[3,0,2]  R442      5.0521409511566162e-01
    z[3,0,2]  R443      6.2362527847290039e-01
    z[3,0,2]  R444      0.571182370185852
    z[3,0,2]  R445      4.4035613536834717e-01
    z[3,0,2]  R446      7.8499752283096313e-01
    z[3,0,2]  R447      6.2672156095504761e-01
    z[3,0,2]  R448      4.7743234038352966e-01
    z[3,0,2]  R449      6.9996118545532227e-01
    z[3,0,2]  R450      3.8069990277290344e-01
    z[3,0,2]  R451      1.1524409800767899e-01
    z[3,0,2]  R452      9.0653824806213379e-01
    z[3,0,2]  R453      3.5717067122459412e-01
    z[3,0,2]  R454      4.4943377375602722e-02
    z[3,0,2]  R455      1.0355886816978455e-01
    z[3,0,2]  R456      0.0952523723244667
    z[3,0,2]  R457      2.0626203715801239e-01
    z[3,0,2]  R458      1.7021517455577850e-01
    z[3,0,2]  R459      1.0912785679101944e-01
    z[3,0,2]  R460      1.3099455833435059e-01
    z[3,0,3]  R5        1
    z[3,0,3]  R32       -1
    z[3,0,3]  R333      -1
    z[3,0,3]  R334      1
    z[3,0,3]  R341      3.7420988082885742e-01
    z[3,0,3]  R342      6.7907691001892090e-01
    z[3,0,3]  R343      4.3427556753158569e-01
    z[3,0,3]  R344      5.0297158956527710e-01
    z[3,0,3]  R345      6.7577290534973145e-01
    z[3,0,3]  R346      -2.4416683614253998e-01
    z[3,0,3]  R347      1.3043354451656342e-01
    z[3,0,3]  R348      2.3145893216133118e-01
    z[3,0,3]  R349      3.4173694252967834e-01
    z[3,0,3]  R350      3.4725794196128845e-01
    z[3,0,3]  R351      -3.9352294057607651e-02
    z[3,0,3]  R352      -2.0397897064685822e-01
    z[3,0,3]  R353      1.7381841316819191e-02
    z[3,0,3]  R354      -1.0820031911134720e-01
    z[3,0,3]  R355      -2.0943066477775574e-01
    z[3,0,3]  R356      -2.5197410583496094e-01
    z[3,0,3]  R357      2.8585383668541908e-02
    z[3,0,3]  R358      -3.0092450976371765e-01
    z[3,0,3]  R359      -4.6742090582847595e-01
    z[3,0,3]  R360      -3.0300248414278030e-02
    z[3,0,3]  R361      -6.7259013652801514e-01
    z[3,0,3]  R362      -5.8234238624572754e-01
    z[3,0,3]  R363      -4.4266286492347717e-01
    z[3,0,3]  R364      6.7975777387619019e-01
    z[3,0,3]  R365      -5.2452695369720459e-01
    z[3,0,3]  R366      -1.4348666369915009e-01
    z[3,0,3]  R367      -8.2589067518711090e-02
    z[3,0,3]  R368      -2.4972349405288696e-01
    z[3,0,3]  R369      -1.6817671060562134e-01
    z[3,0,3]  R370      -2.3673868179321289e-01
    z[3,0,3]  R371      -6.9535695016384125e-02
    z[3,0,3]  R372      -2.5063166022300720e-01
    z[3,0,3]  R373      -2.6369345188140869e-01
    z[3,0,3]  R374      -3.9013007283210754e-01
    z[3,0,3]  R375      -3.8972941040992737e-01
    z[3,0,3]  R376      2.8705161809921265e-01
    z[3,0,3]  R377      7.6106287539005280e-02
    z[3,0,3]  R378      5.8734875917434692e-01
    z[3,0,3]  R379      4.8898744583129883e-01
    z[3,0,3]  R380      -4.2992007732391357e-01
    z[3,0,3]  R381      -4.4301679730415344e-01
    z[3,0,3]  R382      -1.8483416736125946e-01
    z[3,0,3]  R383      -0.665672242641449
    z[3,0,3]  R384      -4.3565583229064941e-01
    z[3,0,3]  R385      -4.9580168724060059e-01
    z[3,0,3]  R386      1.5340850688517094e-02
    z[3,0,3]  R387      -2.3656207323074341e-01
    z[3,0,3]  R388      4.2897865176200867e-01
    z[3,0,3]  R389      2.7163015678524971e-02
    z[3,0,3]  R390      -1.9019616767764091e-02
    z[3,0,3]  R391      -3.0038860440254211e-01
    z[3,0,3]  R392      -0.324074387550354
    z[3,0,3]  R393      -1.2518766522407532e-01
    z[3,0,3]  R394      7.3851294815540314e-02
    z[3,0,3]  R395      -2.6993727311491966e-02
    z[3,0,3]  R396      -2.3950931429862976e-01
    z[3,0,3]  R397      -8.0155604518949986e-04
    z[3,0,3]  R398      -6.5887951850891113e-01
    z[3,0,3]  R399      -2.7802556753158569e-01
    z[3,0,3]  R400      -9.0073829889297485e-01
    z[3,0,3]  R401      -3.9974990487098694e-01
    z[3,0,3]  R402      -7.0483297109603882e-01
    z[3,0,3]  R403      -0.636849045753479
    z[3,0,3]  R404      1.4090560376644135e-01
    z[3,0,3]  R405      4.3926298618316650e-01
    z[3,0,3]  R406      1.7935261130332947e-01
    z[3,0,3]  R407      -4.4287670403718948e-02
    z[3,0,3]  R408      -1.9506633281707764e-01
    z[3,0,3]  R409      4.2763477563858032e-01
    z[3,0,3]  R410      2.4731636047363281e-01
    z[3,0,3]  R411      -4.1987213492393494e-01
    z[3,0,3]  R412      -5.4470568895339966e-01
    z[3,0,3]  R413      -2.0091973245143890e-01
    z[3,0,3]  R414      5.7016885280609131e-01
    z[3,0,3]  R415      1.8288058042526245e-01
    z[3,0,3]  R416      5.7683402299880981e-01
    z[3,0,3]  R417      9.9328316748142242e-02
    z[3,0,3]  R418      -2.7665802836418152e-01
    z[3,0,3]  R419      -2.5349313020706177e-01
    z[3,0,3]  R420      -3.3209922909736633e-01
    z[3,0,3]  R421      -5.1900601387023926e-01
    z[3,0,3]  R422      -3.1045249104499817e-01
    z[3,0,3]  R423      3.1423109769821167e-01
    z[3,0,3]  R424      2.1137748658657074e-01
    z[3,0,3]  R425      2.8813469409942627e-01
    z[3,0,3]  R426      4.5024354010820389e-02
    z[3,0,3]  R427      5.6768339872360229e-01
    z[3,0,3]  R428      5.4710513353347778e-01
    z[3,0,3]  R429      2.6591575145721436e-01
    z[3,0,3]  R430      -1.4462395012378693e-01
    z[3,0,3]  R431      -8.3205364644527435e-02
    z[3,0,3]  R432      -9.7979776561260223e-02
    z[3,0,3]  R433      -1.7353199422359467e-01
    z[3,0,3]  R434      -1.8601258099079132e-01
    z[3,0,3]  R435      3.3038654923439026e-01
    z[3,0,3]  R436      7.3983728885650635e-01
    z[3,0,3]  R437      6.1978113651275635e-01
    z[3,0,3]  R438      5.2550071477890015e-01
    z[3,0,3]  R439      3.7971699237823486e-01
    z[3,0,3]  R440      6.7948889732360840e-01
    z[3,0,3]  R441      -3.8932007551193237e-01
    z[3,0,3]  R442      -3.4803071618080139e-01
    z[3,0,3]  R443      -2.2948299348354340e-01
    z[3,0,3]  R444      -3.1289437413215637e-01
    z[3,0,3]  R445      -0.391677588224411
    z[3,0,3]  R446      -7.3276035487651825e-02
    z[3,0,3]  R447      -3.8164338469505310e-01
    z[3,0,3]  R448      -1.2850166857242584e-01
    z[3,0,3]  R449      -2.4046956002712250e-01
    z[3,0,3]  R450      -4.5718687772750854e-01
    z[3,0,3]  R451      -7.4527716636657715e-01
    z[3,0,3]  R452      -2.4984714388847351e-01
    z[3,0,3]  R453      -3.7330493330955505e-02
    z[3,0,3]  R454      -2.2512030601501465e-01
    z[3,0,3]  R455      -2.2528481483459473e-01
    z[3,0,3]  R456      -2.2371117770671844e-01
    z[3,0,3]  R457      -2.6315337419509888e-01
    z[3,0,3]  R458      -1.7843115329742432e-01
    z[3,0,3]  R459      -1.7954248934984207e-02
    z[3,0,3]  R460      -1.1924888193607330e-01
    z[3,0,4]  R6        1
    z[3,0,4]  R33       -1
    z[3,0,4]  R335      -1
    z[3,0,4]  R336      1
    z[3,0,4]  R341      -4.6652253717184067e-02
    z[3,0,4]  R342      -2.4003187194466591e-02
    z[3,0,4]  R343      4.5995318889617920e-01
    z[3,0,4]  R344      2.9704380035400391e-01
    z[3,0,4]  R345      2.0661835372447968e-01
    z[3,0,4]  R346      -2.1915614604949951e-01
    z[3,0,4]  R347      1.3381545245647430e-01
    z[3,0,4]  R348      -1.3279208540916443e-01
    z[3,0,4]  R349      -1.2246138602495193e-01
    z[3,0,4]  R350      3.7044730782508850e-01
    z[3,0,4]  R351      0.0644272193312645
    z[3,0,4]  R352      1.7407299578189850e-01
    z[3,0,4]  R353      -1.0715722292661667e-01
    z[3,0,4]  R354      -1.4778789877891541e-01
    z[3,0,4]  R355      -1.4112314581871033e-01
    z[3,0,4]  R356      2.2384163737297058e-01
    z[3,0,4]  R357      1.7793895304203033e-01
    z[3,0,4]  R358      4.4721037149429321e-01
    z[3,0,4]  R359      -0.0606394037604332
    z[3,0,4]  R360      1.2662783265113831e-01
    z[3,0,4]  R361      1.7410339415073395e-01
    z[3,0,4]  R362      3.4294697642326355e-01
    z[3,0,4]  R363      0.0515059269964695
    z[3,0,4]  R364      -3.0618287622928619e-02
    z[3,0,4]  R365      1.1818935722112656e-01
    z[3,0,4]  R366      -2.5935724377632141e-01
    z[3,0,4]  R367      -7.0793621242046356e-02
    z[3,0,4]  R368      -2.3014941811561584e-01
    z[3,0,4]  R369      -2.3294666409492493e-01
    z[3,0,4]  R370      2.0637065172195435e-01
    z[3,0,4]  R371      -4.1234114766120911e-01
    z[3,0,4]  R372      4.6587803959846497e-01
    z[3,0,4]  R373      0.31876340508461
    z[3,0,4]  R374      -1.3341650366783142e-01
    z[3,0,4]  R375      -4.1229271888732910e-01
    z[3,0,4]  R376      2.4737310409545898e-01
    z[3,0,4]  R377      0.0967501625418663
    z[3,0,4]  R378      4.6853196620941162e-01
    z[3,0,4]  R379      3.2393902540206909e-01
    z[3,0,4]  R380      1.9697868824005127e-01
    z[3,0,4]  R381      2.0611914992332458e-01
    z[3,0,4]  R382      -2.7662146091461182e-01
    z[3,0,4]  R383      -2.1774184703826904e-01
    z[3,0,4]  R384      -1.7755937576293945e-01
    z[3,0,4]  R385      -6.5851235389709473e-01
    z[3,0,4]  R386      -6.3356764614582062e-02
    z[3,0,4]  R387      -9.6845224499702454e-02
    z[3,0,4]  R388      2.3995047807693481e-01
    z[3,0,4]  R389      -1.2424138188362122e-01
    z[3,0,4]  R390      1.5257167816162109e-01
    z[3,0,4]  R391      -8.3643466234207153e-02
    z[3,0,4]  R392      -1.0962177067995071e-01
    z[3,0,4]  R393      -3.1764388084411621e-01
    z[3,0,4]  R394      1.7952004075050354e-01
    z[3,0,4]  R395      3.9193700999021530e-02
    z[3,0,4]  R396      1.7649734020233154e-01
    z[3,0,4]  R397      0.24935382604599
    z[3,0,4]  R398      8.4604196250438690e-02
    z[3,0,4]  R399      -2.7523839473724365e-01
    z[3,0,4]  R400      2.5690355896949768e-01
    z[3,0,4]  R401      1.5428103506565094e-01
    z[3,0,4]  R402      1.6195248812437057e-02
    z[3,0,4]  R403      8.7646394968032837e-02
    z[3,0,4]  R404      2.2998262941837311e-01
    z[3,0,4]  R405      -8.0991901457309723e-02
    z[3,0,4]  R406      1.5155556797981262e-01
    z[3,0,4]  R407      -6.2881387770175934e-02
    z[3,0,4]  R408      -1.9795902073383331e-01
    z[3,0,4]  R409      -2.9808852076530457e-01
    z[3,0,4]  R410      -2.7864545583724976e-01
    z[3,0,4]  R411      -5.4691050201654434e-02
    z[3,0,4]  R412      -1.0489811003208160e-01
    z[3,0,4]  R413      -2.9336953163146973e-01
    z[3,0,4]  R414      2.2056722640991211e-01
    z[3,0,4]  R415      9.9898435175418854e-02
    z[3,0,4]  R416      -4.8859912157058716e-01
    z[3,0,4]  R417      3.5315670073032379e-02
    z[3,0,4]  R418      -2.1309521794319153e-01
    z[3,0,4]  R419      8.6106121540069580e-01
    z[3,0,4]  R420      3.3534392714500427e-01
    z[3,0,4]  R421      -3.8835567235946655e-01
    z[3,0,4]  R422      5.3314459323883057e-01
    z[3,0,4]  R423      -2.9568953439593315e-02
    z[3,0,4]  R424      -1.4985139667987823e-01
    z[3,0,4]  R425      0.320017009973526
    z[3,0,4]  R426      3.4514892101287842e-01
    z[3,0,4]  R427      -1.2468189746141434e-01
    z[3,0,4]  R428      3.4777253866195679e-02
    z[3,0,4]  R429      0.360971599817276
    z[3,0,4]  R430      -1.2381967157125473e-01
    z[3,0,4]  R431      -2.9927557706832886e-01
    z[3,0,4]  R432      -1.4534645713865757e-02
    z[3,0,4]  R433      -2.4281892180442810e-01
    z[3,0,4]  R434      3.9431157708168030e-01
    z[3,0,4]  R435      7.5061666965484619e-01
    z[3,0,4]  R436      1.5398919582366943e-01
    z[3,0,4]  R437      1.2913782894611359e-01
    z[3,0,4]  R438      2.4086086452007294e-01
    z[3,0,4]  R439      2.9865931719541550e-02
    z[3,0,4]  R440      -0.0674920454621315
    z[3,0,4]  R441      -3.2286904752254486e-02
    z[3,0,4]  R442      -1.5856406092643738e-01
    z[3,0,4]  R443      -1.2010575085878372e-01
    z[3,0,4]  R444      2.7923974394798279e-01
    z[3,0,4]  R445      3.3129815012216568e-02
    z[3,0,4]  R446      0.0536414310336113
    z[3,0,4]  R447      -1.6545827686786652e-01
    z[3,0,4]  R448      1.6787317395210266e-01
    z[3,0,4]  R449      -3.8327416405081749e-03
    z[3,0,4]  R450      4.7427740693092346e-01
    z[3,0,4]  R451      -2.8334513306617737e-01
    z[3,0,4]  R452      -1.2642596662044525e-01
    z[3,0,4]  R453      -2.0384061336517334e-01
    z[3,0,4]  R454      1.3957025110721588e-01
    z[3,0,4]  R455      -1.3012272119522095e-01
    z[3,0,4]  R456      0.284850537776947
    z[3,0,4]  R457      -0.086112841963768
    z[3,0,4]  R458      7.7297821640968323e-02
    z[3,0,4]  R459      8.5844539105892181e-02
    z[3,0,4]  R460      -2.8101390600204468e-01
    z[3,0,5]  R7        1
    z[3,0,5]  R34       -1
    z[3,0,5]  R337      -1
    z[3,0,5]  R338      1
    z[3,0,5]  R341      -4.4074233621358871e-02
    z[3,0,5]  R342      -1.4495445787906647e-01
    z[3,0,5]  R343      -6.9058477878570557e-02
    z[3,0,5]  R344      -2.8482276201248169e-01
    z[3,0,5]  R345      1.8145045638084412e-01
    z[3,0,5]  R346      1.5429614484310150e-01
    z[3,0,5]  R347      -1.0010101646184921e-01
    z[3,0,5]  R348      -1.0949768126010895e-01
    z[3,0,5]  R349      -3.4235006570816040e-01
    z[3,0,5]  R350      1.0637746751308441e-01
    z[3,0,5]  R351      2.8287851810455322e-01
    z[3,0,5]  R352      2.0069922506809235e-01
    z[3,0,5]  R353      2.3118227720260620e-01
    z[3,0,5]  R354      -0.075913205742836
    z[3,0,5]  R355      0.535001814365387
    z[3,0,5]  R356      1.0893454402685165e-01
    z[3,0,5]  R357      2.9696938395500183e-01
    z[3,0,5]  R358      4.0769883990287781e-01
    z[3,0,5]  R359      -4.6716742217540741e-03
    z[3,0,5]  R360      2.5278747081756592e-01
    z[3,0,5]  R361      4.4447210431098938e-01
    z[3,0,5]  R362      5.4762428998947144e-01
    z[3,0,5]  R363      6.3761627674102783e-01
    z[3,0,5]  R364      -2.6111018657684326e-01
    z[3,0,5]  R365      6.4481425285339355e-01
    z[3,0,5]  R366      -3.5370582342147827e-01
    z[3,0,5]  R367      -4.5468306541442871e-01
    z[3,0,5]  R368      -0.252608984708786
    z[3,0,5]  R369      -5.0605303049087524e-01
    z[3,0,5]  R370      -4.5991146564483643e-01
    z[3,0,5]  R371      4.8409852385520935e-01
    z[3,0,5]  R372      0.587566614151001
    z[3,0,5]  R373      6.3206166028976440e-01
    z[3,0,5]  R374      5.8540689945220947e-01
    z[3,0,5]  R375      5.7594513893127441e-01
    z[3,0,5]  R376      -2.8168687224388123e-01
    z[3,0,5]  R377      5.8635663986206055e-01
    z[3,0,5]  R378      -1.1911985278129578e-01
    z[3,0,5]  R379      1.7296472191810608e-01
    z[3,0,5]  R380      -2.8461429476737976e-01
    z[3,0,5]  R381      5.6511014699935913e-01
    z[3,0,5]  R382      2.6678198575973511e-01
    z[3,0,5]  R383      4.8890298604965210e-01
    z[3,0,5]  R384      -0.0569256953895092
    z[3,0,5]  R385      -2.1289469301700592e-01
    z[3,0,5]  R386      2.3178681731224060e-01
    z[3,0,5]  R387      3.6339035630226135e-01
    z[3,0,5]  R388      4.3757492303848267e-01
    z[3,0,5]  R389      7.4298632144927979e-01
    z[3,0,5]  R390      5.8118617534637451e-01
    z[3,0,5]  R391      3.7851619720458984e-01
    z[3,0,5]  R392      -2.1907933056354523e-01
    z[3,0,5]  R393      2.9881912469863892e-01
    z[3,0,5]  R394      1.2832273729145527e-02
    z[3,0,5]  R395      3.4379380941390991e-01
    z[3,0,5]  R396      5.8337718248367310e-01
    z[3,0,5]  R397      5.1027429103851318e-01
    z[3,0,5]  R398      4.4948694109916687e-01
    z[3,0,5]  R399      1.1982368677854538e-01
    z[3,0,5]  R400      -0.0586259625852108
    z[3,0,5]  R401      6.0723256319761276e-02
    z[3,0,5]  R402      2.1167193353176117e-01
    z[3,0,5]  R403      5.9822231531143188e-02
    z[3,0,5]  R404      6.9899767637252808e-01
    z[3,0,5]  R405      1.0365897417068481e-01
    z[3,0,5]  R406      4.8748105764389038e-01
    z[3,0,5]  R407      8.9537531137466431e-01
    z[3,0,5]  R408      6.8468856811523438e-01
    z[3,0,5]  R409      -4.6031859517097473e-01
    z[3,0,5]  R410      -5.5460166931152344e-01
    z[3,0,5]  R411      2.7098900079727173e-01
    z[3,0,5]  R412      5.4674917459487915e-01
    z[3,0,5]  R413      -5.4734289646148682e-01
    z[3,0,5]  R414      4.1980616748332977e-02
    z[3,0,5]  R415      -1.3455897569656372e-01
    z[3,0,5]  R416      0.287685364484787
    z[3,0,5]  R417      6.1171799898147583e-01
    z[3,0,5]  R418      -1.0330747067928314e-01
    z[3,0,5]  R419      -1.2625804543495178e-01
    z[3,0,5]  R420      -1.2806738913059235e-01
    z[3,0,5]  R421      -2.3561830818653107e-01
    z[3,0,5]  R422      2.7680492401123047e-01
    z[3,0,5]  R423      -6.6292285919189453e-01
    z[3,0,5]  R424      5.4928410053253174e-01
    z[3,0,5]  R425      4.1932541131973267e-01
    z[3,0,5]  R426      0.254957914352417
    z[3,0,5]  R427      -7.9919271171092987e-02
    z[3,0,5]  R428      -4.2730411887168884e-01
    z[3,0,5]  R429      2.8728953003883362e-01
    z[3,0,5]  R430      1.8982259929180145e-01
    z[3,0,5]  R431      -3.1696575880050659e-01
    z[3,0,5]  R432      1.7433136701583862e-01
    z[3,0,5]  R433      2.4230352044105530e-01
    z[3,0,5]  R434      -6.6690450906753540e-01
    z[3,0,5]  R435      -1.5532267093658447e-01
    z[3,0,5]  R436      -3.6824661493301392e-01
    z[3,0,5]  R437      -3.3464384078979492e-01
    z[3,0,5]  R438      -4.2328894138336182e-01
    z[3,0,5]  R439      -5.5316913127899170e-01
    z[3,0,5]  R440      6.3855066895484924e-02
    z[3,0,5]  R441      4.9023386836051941e-01
    z[3,0,5]  R442      4.3290632963180542e-01
    z[3,0,5]  R443      3.2704770565032959e-01
    z[3,0,5]  R444      5.5597817897796631e-01
    z[3,0,5]  R445      3.0266985297203064e-01
    z[3,0,5]  R446      0.515321671962738
    z[3,0,5]  R447      5.0135707855224609e-01
    z[3,0,5]  R448      2.6005271077156067e-01
    z[3,0,5]  R449      -2.8759138658642769e-03
    z[3,0,5]  R450      4.3018421530723572e-01
    z[3,0,5]  R451      4.5271337032318115e-01
    z[3,0,5]  R452      1.5657339990139008e-01
    z[3,0,5]  R453      -2.3221021890640259e-01
    z[3,0,5]  R454      -1.5560670197010040e-01
    z[3,0,5]  R455      -1.7040944099426270e-01
    z[3,0,5]  R456      -1.8913638591766357e-01
    z[3,0,5]  R457      -9.9175393581390381e-02
    z[3,0,5]  R458      -4.1674140095710754e-01
    z[3,0,5]  R459      -0.295710951089859
    z[3,0,5]  R460      -3.2845476269721985e-01
    z[3,0,6]  R8        1
    z[3,0,6]  R35       -1
    z[3,0,6]  R339      -1
    z[3,0,6]  R340      1
    z[3,0,6]  R341      -1.5861645340919495e-01
    z[3,0,6]  R342      1.9234988093376160e-01
    z[3,0,6]  R343      -1.5485175885260105e-02
    z[3,0,6]  R344      1.6566525399684906e-01
    z[3,0,6]  R345      -2.8882148861885071e-01
    z[3,0,6]  R346      -4.2173019051551819e-01
    z[3,0,6]  R347      1.8046455085277557e-01
    z[3,0,6]  R348      -2.7422466874122620e-01
    z[3,0,6]  R349      1.2597066164016724e-01
    z[3,0,6]  R350      -3.1372427940368652e-01
    z[3,0,6]  R351      1.4145767688751221e-01
    z[3,0,6]  R352      -7.0472881197929382e-02
    z[3,0,6]  R353      6.9888085126876831e-02
    z[3,0,6]  R354      2.7485650032758713e-02
    z[3,0,6]  R355      1.8679074943065643e-01
    z[3,0,6]  R356      -2.7392706274986267e-01
    z[3,0,6]  R357      5.2603948116302490e-01
    z[3,0,6]  R358      2.9290032386779785e-01
    z[3,0,6]  R359      3.8864722847938538e-01
    z[3,0,6]  R360      -2.4102360010147095e-01
    z[3,0,6]  R361      -2.1817234158515930e-01
    z[3,0,6]  R362      -1.9706779718399048e-01
    z[3,0,6]  R363      -1.3251727819442749e-01
    z[3,0,6]  R364      -1.6446286439895630e-01
    z[3,0,6]  R365      2.6247581839561462e-01
    z[3,0,6]  R366      4.5745734125375748e-02
    z[3,0,6]  R367      2.3047868907451630e-01
    z[3,0,6]  R368      -5.9881657361984253e-02
    z[3,0,6]  R369      -9.4336703419685364e-02
    z[3,0,6]  R370      5.8939591050148010e-02
    z[3,0,6]  R371      -1.5689672902226448e-02
    z[3,0,6]  R372      -1.8470782786607742e-02
    z[3,0,6]  R373      4.1349419951438904e-01
    z[3,0,6]  R374      4.8553115129470825e-01
    z[3,0,6]  R375      1.9763223826885223e-01
    z[3,0,6]  R376      5.5701290257275105e-03
    z[3,0,6]  R377      -0.57218337059021
    z[3,0,6]  R378      1.4964535832405090e-01
    z[3,0,6]  R379      1.2106354348361492e-02
    z[3,0,6]  R380      -2.5076735019683838e-01
    z[3,0,6]  R381      2.1989084780216217e-01
    z[3,0,6]  R382      -2.6869857311248779e-01
    z[3,0,6]  R383      -2.6428046822547913e-01
    z[3,0,6]  R384      1.2014728784561157e-01
    z[3,0,6]  R385      -4.5258617401123047e-01
    z[3,0,6]  R386      4.2708730697631836e-01
    z[3,0,6]  R387      6.5108686685562134e-01
    z[3,0,6]  R388      0.0421893447637558
    z[3,0,6]  R389      -3.9146393537521362e-01
    z[3,0,6]  R390      -4.8854342103004456e-01
    z[3,0,6]  R391      -2.7119457721710205e-01
    z[3,0,6]  R392      -6.6284263134002686e-01
    z[3,0,6]  R393      9.0074427425861359e-02
    z[3,0,6]  R394      -9.5177195966243744e-02
    z[3,0,6]  R395      -2.7251252532005310e-01
    z[3,0,6]  R396      -2.9646283388137817e-01
    z[3,0,6]  R397      2.4682195484638214e-01
    z[3,0,6]  R398      -5.0488543510437012e-01
    z[3,0,6]  R399      -7.8267019987106323e-01
    z[3,0,6]  R400      2.8267474845051765e-02
    z[3,0,6]  R401      0.275452196598053
    z[3,0,6]  R402      -1.0823348909616470e-01
    z[3,0,6]  R403      -0.485553115606308
    z[3,0,6]  R404      3.1136220693588257e-01
    z[3,0,6]  R405      3.1912293285131454e-02
    z[3,0,6]  R406      9.7209677100181580e-02
    z[3,0,6]  R407      5.2639592438936234e-02
    z[3,0,6]  R408      4.7794154286384583e-01
    z[3,0,6]  R409      -9.5068022608757019e-02
    z[3,0,6]  R410      2.1829910576343536e-01
    z[3,0,6]  R411      8.0980263650417328e-02
    z[3,0,6]  R412      -1.9113582372665405e-01
    z[3,0,6]  R413      1.7105533182621002e-01
    z[3,0,6]  R414      -1.8997816741466522e-01
    z[3,0,6]  R415      -1.4648582041263580e-01
    z[3,0,6]  R416      9.8100811243057251e-02
    z[3,0,6]  R417      -3.3444008231163025e-01
    z[3,0,6]  R418      1.7640037834644318e-01
    z[3,0,6]  R419      2.6220846176147461e-01
    z[3,0,6]  R420      -1.7896692454814911e-01
    z[3,0,6]  R421      -2.0715422928333282e-01
    z[3,0,6]  R422      -2.8764620423316956e-01
    z[3,0,6]  R423      0.0504353865981102
    z[3,0,6]  R424      3.1272175908088684e-01
    z[3,0,6]  R425      2.3649330437183380e-01
    z[3,0,6]  R426      -2.9267209768295288e-01
    z[3,0,6]  R427      1.2861740775406361e-02
    z[3,0,6]  R428      3.5773232579231262e-01
    z[3,0,6]  R429      -7.4043780565261841e-02
    z[3,0,6]  R430      -3.3289868384599686e-02
    z[3,0,6]  R431      -5.2641708403825760e-02
    z[3,0,6]  R432      -7.2596031427383423e-01
    z[3,0,6]  R433      4.8680245876312256e-01
    z[3,0,6]  R434      -3.4748116135597229e-01
    z[3,0,6]  R435      2.1003337204456329e-01
    z[3,0,6]  R436      -1.6078585386276245e-01
    z[3,0,6]  R437      3.2989460229873657e-01
    z[3,0,6]  R438      -8.5307411849498749e-02
    z[3,0,6]  R439      -1.0709116607904434e-01
    z[3,0,6]  R440      6.1182132922112942e-03
    z[3,0,6]  R441      8.2008644938468933e-02
    z[3,0,6]  R442      -1.8016591668128967e-02
    z[3,0,6]  R443      -1.3011348247528076e-01
    z[3,0,6]  R444      0.0988316610455513
    z[3,0,6]  R445      -2.1994952857494354e-01
    z[3,0,6]  R446      -1.8067541718482971e-01
    z[3,0,6]  R447      -2.1669082343578339e-01
    z[3,0,6]  R448      2.9461972881108522e-03
    z[3,0,6]  R449      8.6019881069660187e-02
    z[3,0,6]  R450      2.1970807015895844e-01
    z[3,0,6]  R451      9.8284952342510223e-02
    z[3,0,6]  R452      -1.8110708892345428e-01
    z[3,0,6]  R453      1.7480035126209259e-01
    z[3,0,6]  R454      -2.2786696255207062e-01
    z[3,0,6]  R455      1.2980991601943970e-01
    z[3,0,6]  R456      1.6421090066432953e-01
    z[3,0,6]  R457      1.9882810115814209e-01
    z[3,0,6]  R458      3.1714759767055511e-02
    z[3,0,6]  R459      -2.6302960515022278e-01
    z[3,0,6]  R460      -1.8635952472686768e-01
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R461      -1
    z[0,4,0]  R462      1
    z[0,4,0]  R475      -5.9820300340652466e-01
    z[0,4,0]  R476      2.6752209290862083e-02
    z[0,4,0]  R477      1.4091794192790985e-01
    z[0,4,0]  R478      1.2610922753810883e-01
    z[0,4,0]  R479      0.0849047303199768
    z[0,4,0]  R480      -3.2846769690513611e-01
    z[0,4,0]  R481      -2.1867901086807251e-01
    z[0,4,0]  R482      -5.2526682615280151e-01
    z[0,4,0]  R483      -3.5961836576461792e-01
    z[0,4,0]  R484      -4.2806681990623474e-01
    z[0,4,0]  R485      3.1716111302375793e-01
    z[0,4,0]  R486      4.8540952801704407e-01
    z[0,4,0]  R487      5.8673745393753052e-01
    z[0,4,0]  R488      1.8371842801570892e-01
    z[0,4,0]  R489      5.2187836170196533e-01
    z[0,4,0]  R490      1.9484703242778778e-01
    z[0,4,0]  R491      1.0001332312822342e-01
    z[0,4,0]  R492      6.5880334377288818e-01
    z[0,4,0]  R493      6.1596816778182983e-01
    z[0,4,0]  R494      3.1987023353576660e-01
    z[0,4,0]  R495      0.0441134050488472
    z[0,4,0]  R496      1.6030104458332062e-01
    z[0,4,0]  R497      5.2771796472370625e-03
    z[0,4,0]  R498      -5.4457515478134155e-02
    z[0,4,0]  R499      -7.4533924460411072e-02
    z[0,4,0]  R500      -4.4968039728701115e-03
    z[0,4,0]  R501      -2.6329222321510315e-01
    z[0,4,0]  R502      2.0365172624588013e-01
    z[0,4,0]  R503      2.1670965850353241e-01
    z[0,4,0]  R504      2.1826069802045822e-02
    z[0,4,0]  R505      2.1349316835403442e-01
    z[0,4,0]  R506      -4.5517912507057190e-01
    z[0,4,0]  R507      6.5998509526252747e-02
    z[0,4,0]  R508      2.2978940978646278e-02
    z[0,4,0]  R509      -2.9317969083786011e-01
    z[0,4,0]  R510      -9.3563318252563477e-02
    z[0,4,0]  R511      4.4083085656166077e-01
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R463      -1
    z[0,4,1]  R464      1
    z[0,4,1]  R475      -0.657133936882019
    z[0,4,1]  R476      -6.5364474058151245e-01
    z[0,4,1]  R477      -7.6764965057373047e-01
    z[0,4,1]  R478      -4.7385737299919128e-01
    z[0,4,1]  R479      -4.8659288883209229e-01
    z[0,4,1]  R480      -7.9586714506149292e-02
    z[0,4,1]  R481      2.1789185702800751e-02
    z[0,4,1]  R482      0.321778267621994
    z[0,4,1]  R483      3.7625849246978760e-01
    z[0,4,1]  R484      5.0493443012237549e-01
    z[0,4,1]  R485      3.8211745023727417e-01
    z[0,4,1]  R486      4.1849234700202942e-01
    z[0,4,1]  R487      2.7541452646255493e-01
    z[0,4,1]  R488      3.8110509514808655e-01
    z[0,4,1]  R489      4.8911538720130920e-01
    z[0,4,1]  R490      1.9841021299362183e-01
    z[0,4,1]  R491      3.5478931665420532e-01
    z[0,4,1]  R492      4.7508573532104492e-01
    z[0,4,1]  R493      2.5571373105049133e-01
    z[0,4,1]  R494      2.9233837127685547e-01
    z[0,4,1]  R495      3.6666190624237061e-01
    z[0,4,1]  R496      1.2949857115745544e-01
    z[0,4,1]  R497      8.6312222480773926e-01
    z[0,4,1]  R498      9.2125928401947021e-01
    z[0,4,1]  R499      0.932815670967102
    z[0,4,1]  R500      8.9273869991302490e-01
    z[0,4,1]  R501      8.7298315763473511e-01
    z[0,4,1]  R502      8.4679442644119263e-01
    z[0,4,1]  R503      0.881366491317749
    z[0,4,1]  R504      8.6403840780258179e-01
    z[0,4,1]  R505      -3.4159576892852783e-01
    z[0,4,1]  R506      4.4207116961479187e-01
    z[0,4,1]  R507      -3.6425170302391052e-01
    z[0,4,1]  R508      5.7959675788879395e-02
    z[0,4,1]  R509      -1.8813608912751079e-03
    z[0,4,1]  R510      5.2941292524337769e-02
    z[0,4,1]  R511      -1.3303664326667786e-01
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R465      -1
    z[0,4,2]  R466      1
    z[0,4,2]  R475      -1.0295970737934113e-01
    z[0,4,2]  R476      -6.9366976618766785e-02
    z[0,4,2]  R477      7.8065022826194763e-02
    z[0,4,2]  R478      6.2996618449687958e-02
    z[0,4,2]  R479      -1.2328308075666428e-01
    z[0,4,2]  R480      -3.9146584272384644e-01
    z[0,4,2]  R481      -0.574528157711029
    z[0,4,2]  R482      -3.1612914800643921e-01
    z[0,4,2]  R483      -5.1629710197448730e-01
    z[0,4,2]  R484      -0.302365243434906
    z[0,4,2]  R485      0.594750165939331
    z[0,4,2]  R486      5.0521409511566162e-01
    z[0,4,2]  R487      6.2362527847290039e-01
    z[0,4,2]  R488      0.571182370185852
    z[0,4,2]  R489      4.4035613536834717e-01
    z[0,4,2]  R490      7.8499752283096313e-01
    z[0,4,2]  R491      6.2672156095504761e-01
    z[0,4,2]  R492      4.7743234038352966e-01
    z[0,4,2]  R493      6.9996118545532227e-01
    z[0,4,2]  R494      3.8069990277290344e-01
    z[0,4,2]  R495      1.1524409800767899e-01
    z[0,4,2]  R496      9.0653824806213379e-01
    z[0,4,2]  R497      3.5717067122459412e-01
    z[0,4,2]  R498      4.4943377375602722e-02
    z[0,4,2]  R499      1.0355886816978455e-01
    z[0,4,2]  R500      0.0952523723244667
    z[0,4,2]  R501      2.0626203715801239e-01
    z[0,4,2]  R502      1.7021517455577850e-01
    z[0,4,2]  R503      1.0912785679101944e-01
    z[0,4,2]  R504      1.3099455833435059e-01
    z[0,4,2]  R505      -3.7890592217445374e-01
    z[0,4,2]  R506      4.2208835482597351e-01
    z[0,4,2]  R507      7.1080386638641357e-01
    z[0,4,2]  R508      -3.9535153657197952e-02
    z[0,4,2]  R509      -1.6089507937431335e-01
    z[0,4,2]  R510      1.5210928022861481e-01
    z[0,4,2]  R511      6.8489299155771732e-03
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R467      -1
    z[0,4,3]  R468      1
    z[0,4,3]  R475      -8.3205364644527435e-02
    z[0,4,3]  R476      -9.7979776561260223e-02
    z[0,4,3]  R477      -1.7353199422359467e-01
    z[0,4,3]  R478      -1.8601258099079132e-01
    z[0,4,3]  R479      3.3038654923439026e-01
    z[0,4,3]  R480      7.3983728885650635e-01
    z[0,4,3]  R481      6.1978113651275635e-01
    z[0,4,3]  R482      5.2550071477890015e-01
    z[0,4,3]  R483      3.7971699237823486e-01
    z[0,4,3]  R484      6.7948889732360840e-01
    z[0,4,3]  R485      -3.8932007551193237e-01
    z[0,4,3]  R486      -3.4803071618080139e-01
    z[0,4,3]  R487      -2.2948299348354340e-01
    z[0,4,3]  R488      -3.1289437413215637e-01
    z[0,4,3]  R489      -0.391677588224411
    z[0,4,3]  R490      -7.3276035487651825e-02
    z[0,4,3]  R491      -3.8164338469505310e-01
    z[0,4,3]  R492      -1.2850166857242584e-01
    z[0,4,3]  R493      -2.4046956002712250e-01
    z[0,4,3]  R494      -4.5718687772750854e-01
    z[0,4,3]  R495      -7.4527716636657715e-01
    z[0,4,3]  R496      -2.4984714388847351e-01
    z[0,4,3]  R497      -3.7330493330955505e-02
    z[0,4,3]  R498      -2.2512030601501465e-01
    z[0,4,3]  R499      -2.2528481483459473e-01
    z[0,4,3]  R500      -2.2371117770671844e-01
    z[0,4,3]  R501      -2.6315337419509888e-01
    z[0,4,3]  R502      -1.7843115329742432e-01
    z[0,4,3]  R503      -1.7954248934984207e-02
    z[0,4,3]  R504      -1.1924888193607330e-01
    z[0,4,3]  R505      7.4422317743301392e-01
    z[0,4,3]  R506      2.4902540445327759e-01
    z[0,4,3]  R507      6.2218014150857925e-02
    z[0,4,3]  R508      2.1696844696998596e-01
    z[0,4,3]  R509      -6.5100783109664917e-01
    z[0,4,3]  R510      -8.7795192003250122e-01
    z[0,4,3]  R511      -4.7661110758781433e-01
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R469      -1
    z[0,4,4]  R470      1
    z[0,4,4]  R475      -2.9927557706832886e-01
    z[0,4,4]  R476      -1.4534645713865757e-02
    z[0,4,4]  R477      -2.4281892180442810e-01
    z[0,4,4]  R478      3.9431157708168030e-01
    z[0,4,4]  R479      7.5061666965484619e-01
    z[0,4,4]  R480      1.5398919582366943e-01
    z[0,4,4]  R481      1.2913782894611359e-01
    z[0,4,4]  R482      2.4086086452007294e-01
    z[0,4,4]  R483      2.9865931719541550e-02
    z[0,4,4]  R484      -0.0674920454621315
    z[0,4,4]  R485      -3.2286904752254486e-02
    z[0,4,4]  R486      -1.5856406092643738e-01
    z[0,4,4]  R487      -1.2010575085878372e-01
    z[0,4,4]  R488      2.7923974394798279e-01
    z[0,4,4]  R489      3.3129815012216568e-02
    z[0,4,4]  R490      0.0536414310336113
    z[0,4,4]  R491      -1.6545827686786652e-01
    z[0,4,4]  R492      1.6787317395210266e-01
    z[0,4,4]  R493      -3.8327416405081749e-03
    z[0,4,4]  R494      4.7427740693092346e-01
    z[0,4,4]  R495      -2.8334513306617737e-01
    z[0,4,4]  R496      -1.2642596662044525e-01
    z[0,4,4]  R497      -2.0384061336517334e-01
    z[0,4,4]  R498      1.3957025110721588e-01
    z[0,4,4]  R499      -1.3012272119522095e-01
    z[0,4,4]  R500      0.284850537776947
    z[0,4,4]  R501      -0.086112841963768
    z[0,4,4]  R502      7.7297821640968323e-02
    z[0,4,4]  R503      8.5844539105892181e-02
    z[0,4,4]  R504      -2.8101390600204468e-01
    z[0,4,4]  R505      3.2042428851127625e-01
    z[0,4,4]  R506      3.3340302109718323e-01
    z[0,4,4]  R507      8.4792442619800568e-02
    z[0,4,4]  R508      -9.2411078512668610e-02
    z[0,4,4]  R509      3.4073132276535034e-01
    z[0,4,4]  R510      -3.8112181425094604e-01
    z[0,4,4]  R511      -1.6519330441951752e-01
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R471      -1
    z[0,4,5]  R472      1
    z[0,4,5]  R475      -3.1696575880050659e-01
    z[0,4,5]  R476      1.7433136701583862e-01
    z[0,4,5]  R477      2.4230352044105530e-01
    z[0,4,5]  R478      -6.6690450906753540e-01
    z[0,4,5]  R479      -1.5532267093658447e-01
    z[0,4,5]  R480      -3.6824661493301392e-01
    z[0,4,5]  R481      -3.3464384078979492e-01
    z[0,4,5]  R482      -4.2328894138336182e-01
    z[0,4,5]  R483      -5.5316913127899170e-01
    z[0,4,5]  R484      6.3855066895484924e-02
    z[0,4,5]  R485      4.9023386836051941e-01
    z[0,4,5]  R486      4.3290632963180542e-01
    z[0,4,5]  R487      3.2704770565032959e-01
    z[0,4,5]  R488      5.5597817897796631e-01
    z[0,4,5]  R489      3.0266985297203064e-01
    z[0,4,5]  R490      0.515321671962738
    z[0,4,5]  R491      5.0135707855224609e-01
    z[0,4,5]  R492      2.6005271077156067e-01
    z[0,4,5]  R493      -2.8759138658642769e-03
    z[0,4,5]  R494      4.3018421530723572e-01
    z[0,4,5]  R495      4.5271337032318115e-01
    z[0,4,5]  R496      1.5657339990139008e-01
    z[0,4,5]  R497      -2.3221021890640259e-01
    z[0,4,5]  R498      -1.5560670197010040e-01
    z[0,4,5]  R499      -1.7040944099426270e-01
    z[0,4,5]  R500      -1.8913638591766357e-01
    z[0,4,5]  R501      -9.9175393581390381e-02
    z[0,4,5]  R502      -4.1674140095710754e-01
    z[0,4,5]  R503      -0.295710951089859
    z[0,4,5]  R504      -3.2845476269721985e-01
    z[0,4,5]  R505      -1.8587963283061981e-01
    z[0,4,5]  R506      -1.5794233977794647e-01
    z[0,4,5]  R507      -3.5428476333618164e-01
    z[0,4,5]  R508      0.590069055557251
    z[0,4,5]  R509      5.8619880676269531e-01
    z[0,4,5]  R510      -2.1884655952453613e-01
    z[0,4,5]  R511      2.6538777351379395e-01
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R473      -1
    z[0,4,6]  R474      1
    z[0,4,6]  R475      -5.2641708403825760e-02
    z[0,4,6]  R476      -7.2596031427383423e-01
    z[0,4,6]  R477      4.8680245876312256e-01
    z[0,4,6]  R478      -3.4748116135597229e-01
    z[0,4,6]  R479      2.1003337204456329e-01
    z[0,4,6]  R480      -1.6078585386276245e-01
    z[0,4,6]  R481      3.2989460229873657e-01
    z[0,4,6]  R482      -8.5307411849498749e-02
    z[0,4,6]  R483      -1.0709116607904434e-01
    z[0,4,6]  R484      6.1182132922112942e-03
    z[0,4,6]  R485      8.2008644938468933e-02
    z[0,4,6]  R486      -1.8016591668128967e-02
    z[0,4,6]  R487      -1.3011348247528076e-01
    z[0,4,6]  R488      0.0988316610455513
    z[0,4,6]  R489      -2.1994952857494354e-01
    z[0,4,6]  R490      -1.8067541718482971e-01
    z[0,4,6]  R491      -2.1669082343578339e-01
    z[0,4,6]  R492      2.9461972881108522e-03
    z[0,4,6]  R493      8.6019881069660187e-02
    z[0,4,6]  R494      2.1970807015895844e-01
    z[0,4,6]  R495      9.8284952342510223e-02
    z[0,4,6]  R496      -1.8110708892345428e-01
    z[0,4,6]  R497      1.7480035126209259e-01
    z[0,4,6]  R498      -2.2786696255207062e-01
    z[0,4,6]  R499      1.2980991601943970e-01
    z[0,4,6]  R500      1.6421090066432953e-01
    z[0,4,6]  R501      1.9882810115814209e-01
    z[0,4,6]  R502      3.1714759767055511e-02
    z[0,4,6]  R503      -2.6302960515022278e-01
    z[0,4,6]  R504      -1.8635952472686768e-01
    z[0,4,6]  R505      -5.5428370833396912e-02
    z[0,4,6]  R506      -4.7022271156311035e-01
    z[0,4,6]  R507      4.7025975584983826e-01
    z[0,4,6]  R508      0.768604576587677
    z[0,4,6]  R509      6.7947648465633392e-02
    z[0,4,6]  R510      3.6858968436717987e-02
    z[0,4,6]  R511      -0.680474042892456
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R512      -1
    z[4,0,0]  R513      1
    z[4,0,0]  R526      2.1349316835403442e-01
    z[4,0,0]  R527      -4.5517912507057190e-01
    z[4,0,0]  R528      6.5998509526252747e-02
    z[4,0,0]  R529      2.2978940978646278e-02
    z[4,0,0]  R530      -2.9317969083786011e-01
    z[4,0,0]  R531      -9.3563318252563477e-02
    z[4,0,0]  R532      4.4083085656166077e-01
    z[4,0,0]  R533      -5.9820300340652466e-01
    z[4,0,0]  R534      2.6752209290862083e-02
    z[4,0,0]  R535      1.4091794192790985e-01
    z[4,0,0]  R536      1.2610922753810883e-01
    z[4,0,0]  R537      0.0849047303199768
    z[4,0,0]  R538      -3.2846769690513611e-01
    z[4,0,0]  R539      -2.1867901086807251e-01
    z[4,0,0]  R540      -5.2526682615280151e-01
    z[4,0,0]  R541      -3.5961836576461792e-01
    z[4,0,0]  R542      -4.2806681990623474e-01
    z[4,0,0]  R543      3.1716111302375793e-01
    z[4,0,0]  R544      4.8540952801704407e-01
    z[4,0,0]  R545      5.8673745393753052e-01
    z[4,0,0]  R546      1.8371842801570892e-01
    z[4,0,0]  R547      5.2187836170196533e-01
    z[4,0,0]  R548      1.9484703242778778e-01
    z[4,0,0]  R549      1.0001332312822342e-01
    z[4,0,0]  R550      6.5880334377288818e-01
    z[4,0,0]  R551      6.1596816778182983e-01
    z[4,0,0]  R552      3.1987023353576660e-01
    z[4,0,0]  R553      0.0441134050488472
    z[4,0,0]  R554      1.6030104458332062e-01
    z[4,0,0]  R555      5.2771796472370625e-03
    z[4,0,0]  R556      -5.4457515478134155e-02
    z[4,0,0]  R557      -7.4533924460411072e-02
    z[4,0,0]  R558      -4.4968039728701115e-03
    z[4,0,0]  R559      -2.6329222321510315e-01
    z[4,0,0]  R560      2.0365172624588013e-01
    z[4,0,0]  R561      2.1670965850353241e-01
    z[4,0,0]  R562      2.1826069802045822e-02
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R514      -1
    z[4,0,1]  R515      1
    z[4,0,1]  R526      -3.4159576892852783e-01
    z[4,0,1]  R527      4.4207116961479187e-01
    z[4,0,1]  R528      -3.6425170302391052e-01
    z[4,0,1]  R529      5.7959675788879395e-02
    z[4,0,1]  R530      -1.8813608912751079e-03
    z[4,0,1]  R531      5.2941292524337769e-02
    z[4,0,1]  R532      -1.3303664326667786e-01
    z[4,0,1]  R533      -0.657133936882019
    z[4,0,1]  R534      -6.5364474058151245e-01
    z[4,0,1]  R535      -7.6764965057373047e-01
    z[4,0,1]  R536      -4.7385737299919128e-01
    z[4,0,1]  R537      -4.8659288883209229e-01
    z[4,0,1]  R538      -7.9586714506149292e-02
    z[4,0,1]  R539      2.1789185702800751e-02
    z[4,0,1]  R540      0.321778267621994
    z[4,0,1]  R541      3.7625849246978760e-01
    z[4,0,1]  R542      5.0493443012237549e-01
    z[4,0,1]  R543      3.8211745023727417e-01
    z[4,0,1]  R544      4.1849234700202942e-01
    z[4,0,1]  R545      2.7541452646255493e-01
    z[4,0,1]  R546      3.8110509514808655e-01
    z[4,0,1]  R547      4.8911538720130920e-01
    z[4,0,1]  R548      1.9841021299362183e-01
    z[4,0,1]  R549      3.5478931665420532e-01
    z[4,0,1]  R550      4.7508573532104492e-01
    z[4,0,1]  R551      2.5571373105049133e-01
    z[4,0,1]  R552      2.9233837127685547e-01
    z[4,0,1]  R553      3.6666190624237061e-01
    z[4,0,1]  R554      1.2949857115745544e-01
    z[4,0,1]  R555      8.6312222480773926e-01
    z[4,0,1]  R556      9.2125928401947021e-01
    z[4,0,1]  R557      0.932815670967102
    z[4,0,1]  R558      8.9273869991302490e-01
    z[4,0,1]  R559      8.7298315763473511e-01
    z[4,0,1]  R560      8.4679442644119263e-01
    z[4,0,1]  R561      0.881366491317749
    z[4,0,1]  R562      8.6403840780258179e-01
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R516      -1
    z[4,0,2]  R517      1
    z[4,0,2]  R526      -3.7890592217445374e-01
    z[4,0,2]  R527      4.2208835482597351e-01
    z[4,0,2]  R528      7.1080386638641357e-01
    z[4,0,2]  R529      -3.9535153657197952e-02
    z[4,0,2]  R530      -1.6089507937431335e-01
    z[4,0,2]  R531      1.5210928022861481e-01
    z[4,0,2]  R532      6.8489299155771732e-03
    z[4,0,2]  R533      -1.0295970737934113e-01
    z[4,0,2]  R534      -6.9366976618766785e-02
    z[4,0,2]  R535      7.8065022826194763e-02
    z[4,0,2]  R536      6.2996618449687958e-02
    z[4,0,2]  R537      -1.2328308075666428e-01
    z[4,0,2]  R538      -3.9146584272384644e-01
    z[4,0,2]  R539      -0.574528157711029
    z[4,0,2]  R540      -3.1612914800643921e-01
    z[4,0,2]  R541      -5.1629710197448730e-01
    z[4,0,2]  R542      -0.302365243434906
    z[4,0,2]  R543      0.594750165939331
    z[4,0,2]  R544      5.0521409511566162e-01
    z[4,0,2]  R545      6.2362527847290039e-01
    z[4,0,2]  R546      0.571182370185852
    z[4,0,2]  R547      4.4035613536834717e-01
    z[4,0,2]  R548      7.8499752283096313e-01
    z[4,0,2]  R549      6.2672156095504761e-01
    z[4,0,2]  R550      4.7743234038352966e-01
    z[4,0,2]  R551      6.9996118545532227e-01
    z[4,0,2]  R552      3.8069990277290344e-01
    z[4,0,2]  R553      1.1524409800767899e-01
    z[4,0,2]  R554      9.0653824806213379e-01
    z[4,0,2]  R555      3.5717067122459412e-01
    z[4,0,2]  R556      4.4943377375602722e-02
    z[4,0,2]  R557      1.0355886816978455e-01
    z[4,0,2]  R558      0.0952523723244667
    z[4,0,2]  R559      2.0626203715801239e-01
    z[4,0,2]  R560      1.7021517455577850e-01
    z[4,0,2]  R561      1.0912785679101944e-01
    z[4,0,2]  R562      1.3099455833435059e-01
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R518      -1
    z[4,0,3]  R519      1
    z[4,0,3]  R526      7.4422317743301392e-01
    z[4,0,3]  R527      2.4902540445327759e-01
    z[4,0,3]  R528      6.2218014150857925e-02
    z[4,0,3]  R529      2.1696844696998596e-01
    z[4,0,3]  R530      -6.5100783109664917e-01
    z[4,0,3]  R531      -8.7795192003250122e-01
    z[4,0,3]  R532      -4.7661110758781433e-01
    z[4,0,3]  R533      -8.3205364644527435e-02
    z[4,0,3]  R534      -9.7979776561260223e-02
    z[4,0,3]  R535      -1.7353199422359467e-01
    z[4,0,3]  R536      -1.8601258099079132e-01
    z[4,0,3]  R537      3.3038654923439026e-01
    z[4,0,3]  R538      7.3983728885650635e-01
    z[4,0,3]  R539      6.1978113651275635e-01
    z[4,0,3]  R540      5.2550071477890015e-01
    z[4,0,3]  R541      3.7971699237823486e-01
    z[4,0,3]  R542      6.7948889732360840e-01
    z[4,0,3]  R543      -3.8932007551193237e-01
    z[4,0,3]  R544      -3.4803071618080139e-01
    z[4,0,3]  R545      -2.2948299348354340e-01
    z[4,0,3]  R546      -3.1289437413215637e-01
    z[4,0,3]  R547      -0.391677588224411
    z[4,0,3]  R548      -7.3276035487651825e-02
    z[4,0,3]  R549      -3.8164338469505310e-01
    z[4,0,3]  R550      -1.2850166857242584e-01
    z[4,0,3]  R551      -2.4046956002712250e-01
    z[4,0,3]  R552      -4.5718687772750854e-01
    z[4,0,3]  R553      -7.4527716636657715e-01
    z[4,0,3]  R554      -2.4984714388847351e-01
    z[4,0,3]  R555      -3.7330493330955505e-02
    z[4,0,3]  R556      -2.2512030601501465e-01
    z[4,0,3]  R557      -2.2528481483459473e-01
    z[4,0,3]  R558      -2.2371117770671844e-01
    z[4,0,3]  R559      -2.6315337419509888e-01
    z[4,0,3]  R560      -1.7843115329742432e-01
    z[4,0,3]  R561      -1.7954248934984207e-02
    z[4,0,3]  R562      -1.1924888193607330e-01
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R520      -1
    z[4,0,4]  R521      1
    z[4,0,4]  R526      3.2042428851127625e-01
    z[4,0,4]  R527      3.3340302109718323e-01
    z[4,0,4]  R528      8.4792442619800568e-02
    z[4,0,4]  R529      -9.2411078512668610e-02
    z[4,0,4]  R530      3.4073132276535034e-01
    z[4,0,4]  R531      -3.8112181425094604e-01
    z[4,0,4]  R532      -1.6519330441951752e-01
    z[4,0,4]  R533      -2.9927557706832886e-01
    z[4,0,4]  R534      -1.4534645713865757e-02
    z[4,0,4]  R535      -2.4281892180442810e-01
    z[4,0,4]  R536      3.9431157708168030e-01
    z[4,0,4]  R537      7.5061666965484619e-01
    z[4,0,4]  R538      1.5398919582366943e-01
    z[4,0,4]  R539      1.2913782894611359e-01
    z[4,0,4]  R540      2.4086086452007294e-01
    z[4,0,4]  R541      2.9865931719541550e-02
    z[4,0,4]  R542      -0.0674920454621315
    z[4,0,4]  R543      -3.2286904752254486e-02
    z[4,0,4]  R544      -1.5856406092643738e-01
    z[4,0,4]  R545      -1.2010575085878372e-01
    z[4,0,4]  R546      2.7923974394798279e-01
    z[4,0,4]  R547      3.3129815012216568e-02
    z[4,0,4]  R548      0.0536414310336113
    z[4,0,4]  R549      -1.6545827686786652e-01
    z[4,0,4]  R550      1.6787317395210266e-01
    z[4,0,4]  R551      -3.8327416405081749e-03
    z[4,0,4]  R552      4.7427740693092346e-01
    z[4,0,4]  R553      -2.8334513306617737e-01
    z[4,0,4]  R554      -1.2642596662044525e-01
    z[4,0,4]  R555      -2.0384061336517334e-01
    z[4,0,4]  R556      1.3957025110721588e-01
    z[4,0,4]  R557      -1.3012272119522095e-01
    z[4,0,4]  R558      0.284850537776947
    z[4,0,4]  R559      -0.086112841963768
    z[4,0,4]  R560      7.7297821640968323e-02
    z[4,0,4]  R561      8.5844539105892181e-02
    z[4,0,4]  R562      -2.8101390600204468e-01
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R522      -1
    z[4,0,5]  R523      1
    z[4,0,5]  R526      -1.8587963283061981e-01
    z[4,0,5]  R527      -1.5794233977794647e-01
    z[4,0,5]  R528      -3.5428476333618164e-01
    z[4,0,5]  R529      0.590069055557251
    z[4,0,5]  R530      5.8619880676269531e-01
    z[4,0,5]  R531      -2.1884655952453613e-01
    z[4,0,5]  R532      2.6538777351379395e-01
    z[4,0,5]  R533      -3.1696575880050659e-01
    z[4,0,5]  R534      1.7433136701583862e-01
    z[4,0,5]  R535      2.4230352044105530e-01
    z[4,0,5]  R536      -6.6690450906753540e-01
    z[4,0,5]  R537      -1.5532267093658447e-01
    z[4,0,5]  R538      -3.6824661493301392e-01
    z[4,0,5]  R539      -3.3464384078979492e-01
    z[4,0,5]  R540      -4.2328894138336182e-01
    z[4,0,5]  R541      -5.5316913127899170e-01
    z[4,0,5]  R542      6.3855066895484924e-02
    z[4,0,5]  R543      4.9023386836051941e-01
    z[4,0,5]  R544      4.3290632963180542e-01
    z[4,0,5]  R545      3.2704770565032959e-01
    z[4,0,5]  R546      5.5597817897796631e-01
    z[4,0,5]  R547      3.0266985297203064e-01
    z[4,0,5]  R548      0.515321671962738
    z[4,0,5]  R549      5.0135707855224609e-01
    z[4,0,5]  R550      2.6005271077156067e-01
    z[4,0,5]  R551      -2.8759138658642769e-03
    z[4,0,5]  R552      4.3018421530723572e-01
    z[4,0,5]  R553      4.5271337032318115e-01
    z[4,0,5]  R554      1.5657339990139008e-01
    z[4,0,5]  R555      -2.3221021890640259e-01
    z[4,0,5]  R556      -1.5560670197010040e-01
    z[4,0,5]  R557      -1.7040944099426270e-01
    z[4,0,5]  R558      -1.8913638591766357e-01
    z[4,0,5]  R559      -9.9175393581390381e-02
    z[4,0,5]  R560      -4.1674140095710754e-01
    z[4,0,5]  R561      -0.295710951089859
    z[4,0,5]  R562      -3.2845476269721985e-01
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R524      -1
    z[4,0,6]  R525      1
    z[4,0,6]  R526      -5.5428370833396912e-02
    z[4,0,6]  R527      -4.7022271156311035e-01
    z[4,0,6]  R528      4.7025975584983826e-01
    z[4,0,6]  R529      0.768604576587677
    z[4,0,6]  R530      6.7947648465633392e-02
    z[4,0,6]  R531      3.6858968436717987e-02
    z[4,0,6]  R532      -0.680474042892456
    z[4,0,6]  R533      -5.2641708403825760e-02
    z[4,0,6]  R534      -7.2596031427383423e-01
    z[4,0,6]  R535      4.8680245876312256e-01
    z[4,0,6]  R536      -3.4748116135597229e-01
    z[4,0,6]  R537      2.1003337204456329e-01
    z[4,0,6]  R538      -1.6078585386276245e-01
    z[4,0,6]  R539      3.2989460229873657e-01
    z[4,0,6]  R540      -8.5307411849498749e-02
    z[4,0,6]  R541      -1.0709116607904434e-01
    z[4,0,6]  R542      6.1182132922112942e-03
    z[4,0,6]  R543      8.2008644938468933e-02
    z[4,0,6]  R544      -1.8016591668128967e-02
    z[4,0,6]  R545      -1.3011348247528076e-01
    z[4,0,6]  R546      0.0988316610455513
    z[4,0,6]  R547      -2.1994952857494354e-01
    z[4,0,6]  R548      -1.8067541718482971e-01
    z[4,0,6]  R549      -2.1669082343578339e-01
    z[4,0,6]  R550      2.9461972881108522e-03
    z[4,0,6]  R551      8.6019881069660187e-02
    z[4,0,6]  R552      2.1970807015895844e-01
    z[4,0,6]  R553      9.8284952342510223e-02
    z[4,0,6]  R554      -1.8110708892345428e-01
    z[4,0,6]  R555      1.7480035126209259e-01
    z[4,0,6]  R556      -2.2786696255207062e-01
    z[4,0,6]  R557      1.2980991601943970e-01
    z[4,0,6]  R558      1.6421090066432953e-01
    z[4,0,6]  R559      1.9882810115814209e-01
    z[4,0,6]  R560      3.1714759767055511e-02
    z[4,0,6]  R561      -2.6302960515022278e-01
    z[4,0,6]  R562      -1.8635952472686768e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R607      -1
    z[1,2,0]  R608      1
    z[1,2,0]  R621      -0.077597476541996
    z[1,2,0]  R622      2.6397129893302917e-01
    z[1,2,0]  R623      -7.9583726823329926e-02
    z[1,2,0]  R624      2.7869397774338722e-02
    z[1,2,0]  R625      -2.1747012436389923e-01
    z[1,2,0]  R626      2.2852631285786629e-02
    z[1,2,0]  R627      1.7220035195350647e-01
    z[1,2,0]  R628      2.2474895417690277e-01
    z[1,2,0]  R629      -3.9130559563636780e-01
    z[1,2,0]  R630      -4.8110938072204590e-01
    z[1,2,0]  R631      3.1633594632148743e-01
    z[1,2,0]  R632      6.5092794829979539e-04
    z[1,2,0]  R633      3.6189493536949158e-01
    z[1,2,0]  R634      -2.3062512278556824e-01
    z[1,2,0]  R635      1.5377096831798553e-01
    z[1,2,0]  R636      -1.4678399264812469e-01
    z[1,2,0]  R637      -1.1018574982881546e-01
    z[1,2,0]  R638      -7.4105983972549438e-01
    z[1,2,0]  R639      -3.4644496440887451e-01
    z[1,2,0]  R640      -3.0616229772567749e-01
    z[1,2,0]  R641      8.8604754209518433e-01
    z[1,2,0]  R642      1.4583480358123779e-01
    z[1,2,0]  R643      7.9103827476501465e-01
    z[1,2,0]  R644      8.7183523178100586e-01
    z[1,2,0]  R645      0.828798770904541
    z[1,2,0]  R646      8.3446949720382690e-01
    z[1,2,0]  R647      8.2140040397644043e-01
    z[1,2,0]  R648      3.2014328241348267e-01
    z[1,2,0]  R649      -5.8035325258970261e-02
    z[1,2,0]  R650      7.2002267837524414e-01
    z[1,2,0]  R651      -3.5881298780441284e-01
    z[1,2,0]  R652      -4.7988590598106384e-01
    z[1,2,0]  R653      -1.5419688820838928e-01
    z[1,2,0]  R654      -7.5405031442642212e-01
    z[1,2,0]  R655      -6.8363982439041138e-01
    z[1,2,0]  R656      -4.0264037251472473e-01
    z[1,2,0]  R657      -0.772131085395813
    z[1,2,0]  R658      -7.4872213602066040e-01
    z[1,2,0]  R659      -2.5317719578742981e-01
    z[1,2,0]  R660      -7.6686137914657593e-01
    z[1,2,0]  R661      4.8272699117660522e-02
    z[1,2,0]  R662      -2.3450122773647308e-01
    z[1,2,0]  R663      4.4383369386196136e-02
    z[1,2,0]  R664      -1.6060508787631989e-01
    z[1,2,0]  R665      3.9612289518117905e-02
    z[1,2,0]  R666      -9.2905491590499878e-02
    z[1,2,0]  R667      -7.7253989875316620e-02
    z[1,2,0]  R668      -4.0585073828697205e-01
    z[1,2,0]  R669      3.5294704139232635e-02
    z[1,2,0]  R670      -1.3486324250698090e-01
    z[1,2,0]  R671      1.8007567524909973e-01
    z[1,2,0]  R672      1.6546323604416102e-04
    z[1,2,0]  R673      2.5776728987693787e-01
    z[1,2,0]  R674      -4.1691058874130249e-01
    z[1,2,0]  R675      -2.6028215885162354e-01
    z[1,2,0]  R676      6.9311964511871338e-01
    z[1,2,0]  R677      -4.1471680998802185e-01
    z[1,2,0]  R678      -5.6344783306121826e-01
    z[1,2,0]  R679      -4.9564579129219055e-01
    z[1,2,0]  R680      -1.3505442440509796e-01
    z[1,2,0]  R681      -0.564138650894165
    z[1,2,0]  R682      3.5655394196510315e-01
    z[1,2,0]  R683      1.7037992179393768e-01
    z[1,2,0]  R684      -1.5335051715373993e-01
    z[1,2,0]  R685      -3.0667927861213684e-01
    z[1,2,0]  R686      -2.1232496201992035e-01
    z[1,2,0]  R687      8.5173296928405762e-01
    z[1,2,0]  R688      8.8291460275650024e-01
    z[1,2,0]  R689      0.199258491396904
    z[1,2,0]  R690      -1.7429096996784210e-01
    z[1,2,0]  R691      2.3610081523656845e-02
    z[1,2,0]  R692      -3.2982969284057617e-01
    z[1,2,0]  R693      6.9847536087036133e-01
    z[1,2,0]  R694      -4.6365892887115479e-01
    z[1,2,0]  R695      1.2046752125024796e-01
    z[1,2,0]  R696      -0.527647852897644
    z[1,2,0]  R697      2.2033995389938354e-01
    z[1,2,0]  R698      2.4991865456104279e-01
    z[1,2,0]  R699      -0.868701696395874
    z[1,2,0]  R700      -2.1660651266574860e-01
    z[1,2,0]  R701      8.6552582681179047e-02
    z[1,2,0]  R702      -2.6703274250030518e-01
    z[1,2,0]  R703      -4.2324659228324890e-01
    z[1,2,0]  R704      2.0893737673759460e-01
    z[1,2,0]  R705      2.3474301397800446e-01
    z[1,2,0]  R706      3.7857976555824280e-01
    z[1,2,0]  R707      -3.1002092361450195e-01
    z[1,2,0]  R708      1.0676967352628708e-01
    z[1,2,0]  R709      -0.282500684261322
    z[1,2,0]  R710      1.3480694591999054e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R609      -1
    z[1,2,1]  R610      1
    z[1,2,1]  R621      3.6245518922805786e-01
    z[1,2,1]  R622      -2.0048640668392181e-01
    z[1,2,1]  R623      3.8528078794479370e-01
    z[1,2,1]  R624      3.3962216973304749e-01
    z[1,2,1]  R625      -2.6412123441696167e-01
    z[1,2,1]  R626      -2.6405319571495056e-01
    z[1,2,1]  R627      -3.0863621830940247e-01
    z[1,2,1]  R628      -9.1000741720199585e-01
    z[1,2,1]  R629      -5.7779359817504883e-01
    z[1,2,1]  R630      -7.2239577770233154e-01
    z[1,2,1]  R631      -1.3021700084209442e-01
    z[1,2,1]  R632      -1.8559944629669189e-01
    z[1,2,1]  R633      -3.5733491182327271e-02
    z[1,2,1]  R634      2.3735000193119049e-01
    z[1,2,1]  R635      2.7018073201179504e-01
    z[1,2,1]  R636      3.2937890291213989e-01
    z[1,2,1]  R637      1.8331421911716461e-01
    z[1,2,1]  R638      3.8572159409523010e-01
    z[1,2,1]  R639      5.4935926198959351e-01
    z[1,2,1]  R640      5.8083051443099976e-01
    z[1,2,1]  R641      -2.0820298790931702e-01
    z[1,2,1]  R642      -2.4536137282848358e-01
    z[1,2,1]  R643      -1.8139237165451050e-01
    z[1,2,1]  R644      -6.7742630839347839e-02
    z[1,2,1]  R645      2.2924799472093582e-02
    z[1,2,1]  R646      -1.3303156197071075e-01
    z[1,2,1]  R647      -1.2285141646862030e-01
    z[1,2,1]  R648      -1.8322411179542542e-01
    z[1,2,1]  R649      -2.3186931014060974e-01
    z[1,2,1]  R650      -1.5166489779949188e-01
    z[1,2,1]  R651      7.7723509073257446e-01
    z[1,2,1]  R652      6.2624263763427734e-01
    z[1,2,1]  R653      8.9889067411422729e-01
    z[1,2,1]  R654      4.2762383818626404e-01
    z[1,2,1]  R655      3.5715842247009277e-01
    z[1,2,1]  R656      0.71956866979599
    z[1,2,1]  R657      0.166547030210495
    z[1,2,1]  R658      1.8764916062355042e-01
    z[1,2,1]  R659      8.6886739730834961e-01
    z[1,2,1]  R660      2.7385982871055603e-01
    z[1,2,1]  R661      -9.1263711452484131e-01
    z[1,2,1]  R662      -8.6090552806854248e-01
    z[1,2,1]  R663      -7.9708242416381836e-01
    z[1,2,1]  R664      -7.9676896333694458e-01
    z[1,2,1]  R665      -8.3311569690704346e-01
    z[1,2,1]  R666      -8.7095212936401367e-01
    z[1,2,1]  R667      -0.763202428817749
    z[1,2,1]  R668      -7.7917784452438354e-01
    z[1,2,1]  R669      -0.824566125869751
    z[1,2,1]  R670      -6.9372671842575073e-01
    z[1,2,1]  R671      -0.659796953201294
    z[1,2,1]  R672      -4.9183964729309082e-01
    z[1,2,1]  R673      -5.3227448463439941e-01
    z[1,2,1]  R674      -1.8455389142036438e-01
    z[1,2,1]  R675      -2.4131046235561371e-01
    z[1,2,1]  R676      -5.4709357023239136e-01
    z[1,2,1]  R677      -5.6468397378921509e-01
    z[1,2,1]  R678      5.1037472486495972e-01
    z[1,2,1]  R679      -0.705713152885437
    z[1,2,1]  R680      1.6149090230464935e-01
    z[1,2,1]  R681      -4.5664042234420776e-01
    z[1,2,1]  R682      -3.6807930469512939e-01
    z[1,2,1]  R683      -2.4916736781597137e-01
    z[1,2,1]  R684      3.8674041628837585e-01
    z[1,2,1]  R685      0.219456747174263
    z[1,2,1]  R686      4.7260022163391113e-01
    z[1,2,1]  R687      -2.6977792382240295e-01
    z[1,2,1]  R688      -1.5420758724212646e-01
    z[1,2,1]  R689      6.4654910564422607e-01
    z[1,2,1]  R690      4.7253987193107605e-01
    z[1,2,1]  R691      1.4519819058477879e-02
    z[1,2,1]  R692      -5.6691801548004150e-01
    z[1,2,1]  R693      -4.2047610878944397e-01
    z[1,2,1]  R694      7.2132611274719238e-01
    z[1,2,1]  R695      -4.8361968994140625e-01
    z[1,2,1]  R696      2.6444411277770996e-01
    z[1,2,1]  R697      -9.6356995403766632e-02
    z[1,2,1]  R698      -5.6525218486785889e-01
    z[1,2,1]  R699      2.6983615756034851e-01
    z[1,2,1]  R700      -2.4216964840888977e-01
    z[1,2,1]  R701      -7.1035593748092651e-01
    z[1,2,1]  R702      -6.9905835390090942e-01
    z[1,2,1]  R703      7.4038130044937134e-01
    z[1,2,1]  R704      -4.5106706023216248e-01
    z[1,2,1]  R705      3.1020686030387878e-01
    z[1,2,1]  R706      1.9607998430728912e-01
    z[1,2,1]  R707      2.8569355607032776e-02
    z[1,2,1]  R708      -0.0813002958893776
    z[1,2,1]  R709      -3.0414137244224548e-01
    z[1,2,1]  R710      1.0632056742906570e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R611      -1
    z[1,2,2]  R612      1
    z[1,2,2]  R621      -2.4280132353305817e-01
    z[1,2,2]  R622      -3.8911259174346924e-01
    z[1,2,2]  R623      3.3616498112678528e-01
    z[1,2,2]  R624      1.9201441109180450e-01
    z[1,2,2]  R625      -0.211082324385643
    z[1,2,2]  R626      5.0174808502197266e-01
    z[1,2,2]  R627      9.4765760004520416e-02
    z[1,2,2]  R628      -1.2549269199371338e-01
    z[1,2,2]  R629      5.6650322675704956e-01
    z[1,2,2]  R630      2.4162469804286957e-01
    z[1,2,2]  R631      1.5392532944679260e-01
    z[1,2,2]  R632      -1.1897242814302444e-01
    z[1,2,2]  R633      0.45625039935112
    z[1,2,2]  R634      -1.4246310293674469e-01
    z[1,2,2]  R635      1.6092897951602936e-01
    z[1,2,2]  R636      2.2043561935424805e-01
    z[1,2,2]  R637      1.3189366459846497e-01
    z[1,2,2]  R638      -3.7291178107261658e-01
    z[1,2,2]  R639      -5.5576390027999878e-01
    z[1,2,2]  R640      -5.5670505762100220e-01
    z[1,2,2]  R641      0.0910937711596489
    z[1,2,2]  R642      8.6018282175064087e-01
    z[1,2,2]  R643      4.2260631918907166e-01
    z[1,2,2]  R644      -4.1567340493202209e-02
    z[1,2,2]  R645      3.7105602025985718e-01
    z[1,2,2]  R646      4.1188856959342957e-01
    z[1,2,2]  R647      -0.0768071785569191
    z[1,2,2]  R648      9.0562599897384644e-01
    z[1,2,2]  R649      9.0104812383651733e-01
    z[1,2,2]  R650      -0.0647159144282341
    z[1,2,2]  R651      -2.9394480586051941e-01
    z[1,2,2]  R652      -3.2875162363052368e-01
    z[1,2,2]  R653      -3.6022484302520752e-01
    z[1,2,2]  R654      -2.7992677688598633e-01
    z[1,2,2]  R655      -4.0945509076118469e-01
    z[1,2,2]  R656      -3.1449410319328308e-01
    z[1,2,2]  R657      -2.1376132965087891e-01
    z[1,2,2]  R658      -4.1909557580947876e-01
    z[1,2,2]  R659      -1.9536575675010681e-01
    z[1,2,2]  R660      -1.6567899286746979e-01
    z[1,2,2]  R661      2.1565565839409828e-02
    z[1,2,2]  R662      1.8663156032562256e-01
    z[1,2,2]  R663      1.1444225907325745e-01
    z[1,2,2]  R664      1.7330738902091980e-01
    z[1,2,2]  R665      1.9123714417219162e-02
    z[1,2,2]  R666      2.7071169018745422e-01
    z[1,2,2]  R667      5.5021595209836960e-02
    z[1,2,2]  R668      -8.9638732373714447e-02
    z[1,2,2]  R669      -1.2983185052871704e-01
    z[1,2,2]  R670      0.456155925989151
    z[1,2,2]  R671      6.8963599205017090e-01
    z[1,2,2]  R672      3.6888051033020020e-01
    z[1,2,2]  R673      4.8535147309303284e-01
    z[1,2,2]  R674      5.2804708480834961e-01
    z[1,2,2]  R675      5.0944548845291138e-01
    z[1,2,2]  R676      -3.9497545361518860e-01
    z[1,2,2]  R677      2.5180166959762573e-01
    z[1,2,2]  R678      -2.9711747169494629e-01
    z[1,2,2]  R679      3.3206200599670410e-01
    z[1,2,2]  R680      -8.2156014442443848e-01
    z[1,2,2]  R681      5.9368723630905151e-01
    z[1,2,2]  R682      3.6254769563674927e-01
    z[1,2,2]  R683      0.542304515838623
    z[1,2,2]  R684      -6.8246215581893921e-01
    z[1,2,2]  R685      -6.6549074649810791e-01
    z[1,2,2]  R686      -6.3054847717285156e-01
    z[1,2,2]  R687      -2.1745751798152924e-01
    z[1,2,2]  R688      -7.5013250112533569e-02
    z[1,2,2]  R689      -5.2669900655746460e-01
    z[1,2,2]  R690      -4.9416157603263855e-01
    z[1,2,2]  R691      7.6543998718261719e-01
    z[1,2,2]  R692      3.4518721699714661e-01
    z[1,2,2]  R693      -5.2202981710433960e-01
    z[1,2,2]  R694      -0.376355916261673
    z[1,2,2]  R695      1.5767641365528107e-01
    z[1,2,2]  R696      -7.2714775800704956e-01
    z[1,2,2]  R697      4.8233687877655029e-01
    z[1,2,2]  R698      3.7854695320129395e-01
    z[1,2,2]  R699      -6.1420563608407974e-02
    z[1,2,2]  R700      3.6835893988609314e-01
    z[1,2,2]  R701      5.4648733139038086e-01
    z[1,2,2]  R702      4.1992199420928955e-01
    z[1,2,2]  R703      -0.415484219789505
    z[1,2,2]  R704      5.0685596466064453e-01
    z[1,2,2]  R705      4.7984153032302856e-01
    z[1,2,2]  R706      -4.0168985724449158e-01
    z[1,2,2]  R707      -0.302696168422699
    z[1,2,2]  R708      -1.9866585731506348e-01
    z[1,2,2]  R709      -5.0169765949249268e-01
    z[1,2,2]  R710      -2.9586029052734375e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R613      -1
    z[1,2,3]  R614      1
    z[1,2,3]  R621      6.9761854410171509e-01
    z[1,2,3]  R622      7.0579981803894043e-01
    z[1,2,3]  R623      7.0265442132949829e-01
    z[1,2,3]  R624      8.3274716138839722e-01
    z[1,2,3]  R625      8.3575522899627686e-01
    z[1,2,3]  R626      6.8083167076110840e-01
    z[1,2,3]  R627      4.4157034158706665e-01
    z[1,2,3]  R628      -1.1593621969223022e-01
    z[1,2,3]  R629      -0.0922110453248024
    z[1,2,3]  R630      -0.0977182611823082
    z[1,2,3]  R631      -8.8844668865203857e-01
    z[1,2,3]  R632      -7.7384406328201294e-01
    z[1,2,3]  R633      -5.3013539314270020e-01
    z[1,2,3]  R634      -4.3950146436691284e-01
    z[1,2,3]  R635      -3.7368568778038025e-01
    z[1,2,3]  R636      -4.1142952442169189e-01
    z[1,2,3]  R637      -3.6310148239135742e-01
    z[1,2,3]  R638      -2.4321369826793671e-01
    z[1,2,3]  R639      -2.4231983721256256e-01
    z[1,2,3]  R640      -2.5232541561126709e-01
    z[1,2,3]  R641      3.6288830637931824e-01
    z[1,2,3]  R642      2.6031108573079109e-02
    z[1,2,3]  R643      3.5282278060913086e-01
    z[1,2,3]  R644      3.7063917517662048e-01
    z[1,2,3]  R645      3.4668728709220886e-01
    z[1,2,3]  R646      0.280091255903244
    z[1,2,3]  R647      3.0276027321815491e-01
    z[1,2,3]  R648      -0.0650770291686058
    z[1,2,3]  R649      1.5361729077994823e-02
    z[1,2,3]  R650      3.7681087851524353e-01
    z[1,2,3]  R651      -1.1669117212295532e-01
    z[1,2,3]  R652      -2.6099857687950134e-01
    z[1,2,3]  R653      -1.2423708289861679e-01
    z[1,2,3]  R654      -1.9255127012729645e-01
    z[1,2,3]  R655      -1.3361001014709473e-01
    z[1,2,3]  R656      -3.3215454220771790e-01
    z[1,2,3]  R657      -1.3045512139797211e-01
    z[1,2,3]  R658      -3.0237317085266113e-01
    z[1,2,3]  R659      -1.8618687987327576e-01
    z[1,2,3]  R660      -2.9385924339294434e-01
    z[1,2,3]  R661      1.7202377319335938e-01
    z[1,2,3]  R662      3.0013132095336914e-01
    z[1,2,3]  R663      3.1678459048271179e-01
    z[1,2,3]  R664      5.1525235176086426e-01
    z[1,2,3]  R665      1.6616627573966980e-02
    z[1,2,3]  R666      -2.5784291326999664e-02
    z[1,2,3]  R667      2.7257108688354492e-01
    z[1,2,3]  R668      3.2830587029457092e-01
    z[1,2,3]  R669      1.7882893979549408e-01
    z[1,2,3]  R670      -7.8448191285133362e-02
    z[1,2,3]  R671      2.0064114034175873e-01
    z[1,2,3]  R672      -1.5162938833236694e-01
    z[1,2,3]  R673      -7.9044135054573417e-04
    z[1,2,3]  R674      -2.9002451896667480e-01
    z[1,2,3]  R675      -6.2565606832504272e-01
    z[1,2,3]  R676      0.141846165060997
    z[1,2,3]  R677      -1.3586845993995667e-01
    z[1,2,3]  R678      -2.4493041634559631e-01
    z[1,2,3]  R679      8.6284153163433075e-02
    z[1,2,3]  R680      -3.9184951782226562e-01
    z[1,2,3]  R681      -1.4163862168788910e-01
    z[1,2,3]  R682      -6.7420870065689087e-01
    z[1,2,3]  R683      3.4459149837493896e-01
    z[1,2,3]  R684      -1.3506361842155457e-01
    z[1,2,3]  R685      -4.0715873241424561e-01
    z[1,2,3]  R686      -1.5841390192508698e-01
    z[1,2,3]  R687      -4.7076758928596973e-03
    z[1,2,3]  R688      -2.6557031273841858e-01
    z[1,2,3]  R689      -1.9811186194419861e-01
    z[1,2,3]  R690      -1.9661815464496613e-01
    z[1,2,3]  R691      -5.2235692739486694e-01
    z[1,2,3]  R692      -4.6523699164390564e-01
    z[1,2,3]  R693      1.6508273780345917e-01
    z[1,2,3]  R694      -1.6416238248348236e-01
    z[1,2,3]  R695      -2.9310640692710876e-01
    z[1,2,3]  R696      -2.4496681988239288e-01
    z[1,2,3]  R697      -8.1528216600418091e-01
    z[1,2,3]  R698      -7.7290818095207214e-02
    z[1,2,3]  R699      -2.4361704289913177e-01
    z[1,2,3]  R700      -6.9557827711105347e-01
    z[1,2,3]  R701      2.0319934189319611e-01
    z[1,2,3]  R702      -6.2119122594594955e-03
    z[1,2,3]  R703      -1.5458916127681732e-01
    z[1,2,3]  R704      -9.3709513545036316e-02
    z[1,2,3]  R705      2.6010328531265259e-01
    z[1,2,3]  R706      -7.3046904802322388e-01
    z[1,2,3]  R707      -6.6346544027328491e-01
    z[1,2,3]  R708      -6.2754082679748535e-01
    z[1,2,3]  R709      -1.7004366219043732e-01
    z[1,2,3]  R710      -0.610435426235199
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R615      -1
    z[1,2,4]  R616      1
    z[1,2,4]  R621      3.9406582713127136e-01
    z[1,2,4]  R622      4.5046284794807434e-01
    z[1,2,4]  R623      0.486801415681839
    z[1,2,4]  R624      -2.4763226509094238e-01
    z[1,2,4]  R625      -1.4636451005935669e-01
    z[1,2,4]  R626      4.3101231567561626e-03
    z[1,2,4]  R627      4.7685602307319641e-01
    z[1,2,4]  R628      -4.4916570186614990e-03
    z[1,2,4]  R629      -3.2263353466987610e-01
    z[1,2,4]  R630      -2.9715770483016968e-01
    z[1,2,4]  R631      1.1608657240867615e-01
    z[1,2,4]  R632      -4.9887317419052124e-01
    z[1,2,4]  R633      5.0323802232742310e-01
    z[1,2,4]  R634      -0.346293181180954
    z[1,2,4]  R635      -4.7331359982490540e-01
    z[1,2,4]  R636      -3.8748362660408020e-01
    z[1,2,4]  R637      -5.0233131647109985e-01
    z[1,2,4]  R638      -1.5805552899837494e-01
    z[1,2,4]  R639      -0.0805695503950119
    z[1,2,4]  R640      -2.3558795452117920e-01
    z[1,2,4]  R641      -1.0050161927938461e-01
    z[1,2,4]  R642      1.0758806765079498e-01
    z[1,2,4]  R643      1.4761133491992950e-01
    z[1,2,4]  R644      2.3139512538909912e-01
    z[1,2,4]  R645      1.8747209012508392e-01
    z[1,2,4]  R646      0.0691203773021698
    z[1,2,4]  R647      3.6277133226394653e-01
    z[1,2,4]  R648      -9.3559734523296356e-02
    z[1,2,4]  R649      3.5093545913696289e-01
    z[1,2,4]  R650      2.8707376122474670e-01
    z[1,2,4]  R651      -2.1543622016906738e-01
    z[1,2,4]  R652      -1.2187865376472473e-01
    z[1,2,4]  R653      3.2665453851222992e-02
    z[1,2,4]  R654      -6.5461009740829468e-02
    z[1,2,4]  R655      -2.3137234151363373e-01
    z[1,2,4]  R656      1.4333372004330158e-02
    z[1,2,4]  R657      -3.0005258321762085e-01
    z[1,2,4]  R658      -1.8443909287452698e-01
    z[1,2,4]  R659      -2.4288322031497955e-01
    z[1,2,4]  R660      -1.9801400601863861e-02
    z[1,2,4]  R661      2.8166922926902771e-01
    z[1,2,4]  R662      1.3172371685504913e-01
    z[1,2,4]  R663      4.6188560128211975e-01
    z[1,2,4]  R664      4.0505036711692810e-02
    z[1,2,4]  R665      0.454078733921051
    z[1,2,4]  R666      -2.6080831885337830e-02
    z[1,2,4]  R667      2.5098109245300293e-01
    z[1,2,4]  R668      3.0422726273536682e-01
    z[1,2,4]  R669      4.6035513281822205e-02
    z[1,2,4]  R670      -2.6826274394989014e-01
    z[1,2,4]  R671      -8.3375498652458191e-02
    z[1,2,4]  R672      -3.6722859740257263e-01
    z[1,2,4]  R673      2.6221892237663269e-01
    z[1,2,4]  R674      -4.3608167767524719e-01
    z[1,2,4]  R675      -2.8397905826568604e-01
    z[1,2,4]  R676      1.5624053776264191e-01
    z[1,2,4]  R677      3.8545615971088409e-02
    z[1,2,4]  R678      -0.513958215713501
    z[1,2,4]  R679      -5.2396561950445175e-02
    z[1,2,4]  R680      -1.1542411148548126e-01
    z[1,2,4]  R681      -7.3523811995983124e-02
    z[1,2,4]  R682      -1.7473040521144867e-01
    z[1,2,4]  R683      3.3437156677246094e-01
    z[1,2,4]  R684      -3.5563436150550842e-01
    z[1,2,4]  R685      2.3139014840126038e-01
    z[1,2,4]  R686      5.3134876489639282e-01
    z[1,2,4]  R687      -3.8897490501403809e-01
    z[1,2,4]  R688      -2.6186376810073853e-01
    z[1,2,4]  R689      -1.6237211227416992e-01
    z[1,2,4]  R690      -2.4907091632485390e-02
    z[1,2,4]  R691      1.4272421598434448e-01
    z[1,2,4]  R692      -3.6843821406364441e-02
    z[1,2,4]  R693      -1.8145012855529785e-01
    z[1,2,4]  R694      7.4807085096836090e-02
    z[1,2,4]  R695      2.5480762124061584e-01
    z[1,2,4]  R696      -3.4952532500028610e-02
    z[1,2,4]  R697      5.3019434213638306e-02
    z[1,2,4]  R698      5.8762248605489731e-02
    z[1,2,4]  R699      -3.1292009353637695e-01
    z[1,2,4]  R700      -3.2390853762626648e-01
    z[1,2,4]  R701      1.4266617596149445e-01
    z[1,2,4]  R702      -4.0367400646209717e-01
    z[1,2,4]  R703      1.3523253798484802e-01
    z[1,2,4]  R704      -8.8543213903903961e-02
    z[1,2,4]  R705      0.548109233379364
    z[1,2,4]  R706      -1.6275113821029663e-01
    z[1,2,4]  R707      -5.6561392545700073e-01
    z[1,2,4]  R708      0.707699716091156
    z[1,2,4]  R709      -6.4364886283874512e-01
    z[1,2,4]  R710      5.1550066471099854e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R617      -1
    z[1,2,5]  R618      1
    z[1,2,5]  R621      -3.6901223659515381e-01
    z[1,2,5]  R622      -1.1600410193204880e-01
    z[1,2,5]  R623      3.2378707081079483e-02
    z[1,2,5]  R624      -2.1641814708709717e-01
    z[1,2,5]  R625      -2.5121828913688660e-01
    z[1,2,5]  R626      -4.3281629681587219e-01
    z[1,2,5]  R627      -6.6607022285461426e-01
    z[1,2,5]  R628      2.8251004219055176e-01
    z[1,2,5]  R629      -2.8031954169273376e-01
    z[1,2,5]  R630      -1.6167476773262024e-01
    z[1,2,5]  R631      -8.3953499794006348e-02
    z[1,2,5]  R632      -3.1239360570907593e-01
    z[1,2,5]  R633      2.3754407465457916e-01
    z[1,2,5]  R634      7.4026662111282349e-01
    z[1,2,5]  R635      6.6615206003189087e-01
    z[1,2,5]  R636      6.8987190723419189e-01
    z[1,2,5]  R637      7.4313873052597046e-01
    z[1,2,5]  R638      2.6337283849716187e-01
    z[1,2,5]  R639      3.8477602601051331e-01
    z[1,2,5]  R640      2.8918406367301941e-01
    z[1,2,5]  R641      -0.0635211244225502
    z[1,2,5]  R642      2.7736338973045349e-01
    z[1,2,5]  R643      5.5521562695503235e-02
    z[1,2,5]  R644      2.7796175330877304e-02
    z[1,2,5]  R645      1.1223144084215164e-01
    z[1,2,5]  R646      3.6337185651063919e-02
    z[1,2,5]  R647      -2.2626908123493195e-01
    z[1,2,5]  R648      1.7067806422710419e-01
    z[1,2,5]  R649      -1.7152380198240280e-02
    z[1,2,5]  R650      -3.4348621964454651e-01
    z[1,2,5]  R651      -1.9725652039051056e-01
    z[1,2,5]  R652      4.2617791891098022e-01
    z[1,2,5]  R653      1.1352778412401676e-02
    z[1,2,5]  R654      -2.4518366903066635e-02
    z[1,2,5]  R655      -2.9133906960487366e-01
    z[1,2,5]  R656      2.1445275843143463e-01
    z[1,2,5]  R657      -4.6159449219703674e-01
    z[1,2,5]  R658      -2.2193560004234314e-01
    z[1,2,5]  R659      -1.8358242511749268e-01
    z[1,2,5]  R660      -3.6293134093284607e-01
    z[1,2,5]  R661      5.5039305239915848e-02
    z[1,2,5]  R662      -2.3360683023929596e-01
    z[1,2,5]  R663      -4.2297882027924061e-03
    z[1,2,5]  R664      -0.0718153715133667
    z[1,2,5]  R665      2.5768172740936279e-01
    z[1,2,5]  R666      3.3670762181282043e-01
    z[1,2,5]  R667      5.1106613874435425e-01
    z[1,2,5]  R668      -8.0461136996746063e-02
    z[1,2,5]  R669      4.8210576176643372e-01
    z[1,2,5]  R670      1.6107335686683655e-01
    z[1,2,5]  R671      8.1095799803733826e-02
    z[1,2,5]  R672      5.4160147905349731e-01
    z[1,2,5]  R673      5.2025479078292847e-01
    z[1,2,5]  R674      4.8227846622467041e-01
    z[1,2,5]  R675      7.5342416763305664e-02
    z[1,2,5]  R676      1.1733891814947128e-01
    z[1,2,5]  R677      6.5021711587905884e-01
    z[1,2,5]  R678      -3.7025246769189835e-02
    z[1,2,5]  R679      1.1696664243936539e-01
    z[1,2,5]  R680      -3.3673125505447388e-01
    z[1,2,5]  R681      1.8170122802257538e-01
    z[1,2,5]  R682      3.1329768896102905e-01
    z[1,2,5]  R683      -6.1849659681320190e-01
    z[1,2,5]  R684      -3.5491830110549927e-01
    z[1,2,5]  R685      -9.0146347880363464e-02
    z[1,2,5]  R686      1.0209847241640091e-01
    z[1,2,5]  R687      0.00407183775678277
    z[1,2,5]  R688      1.4406004548072815e-01
    z[1,2,5]  R689      -0.131404310464859
    z[1,2,5]  R690      -5.6364381313323975e-01
    z[1,2,5]  R691      -2.3281066119670868e-01
    z[1,2,5]  R692      4.1498345136642456e-01
    z[1,2,5]  R693      4.9292922019958496e-02
    z[1,2,5]  R694      -2.8681412339210510e-01
    z[1,2,5]  R695      6.9784134626388550e-01
    z[1,2,5]  R696      -2.2815065085887909e-01
    z[1,2,5]  R697      2.4691013619303703e-02
    z[1,2,5]  R698      5.2079174667596817e-02
    z[1,2,5]  R699      -1.0465037077665329e-01
    z[1,2,5]  R700      2.4978755414485931e-01
    z[1,2,5]  R701      2.5284758210182190e-01
    z[1,2,5]  R702      3.1188917160034180e-01
    z[1,2,5]  R703      1.3883448205888271e-02
    z[1,2,5]  R704      1.3978092372417450e-01
    z[1,2,5]  R705      -4.9397191405296326e-01
    z[1,2,5]  R706      -1.7135277390480042e-01
    z[1,2,5]  R707      1.8202652037143707e-01
    z[1,2,5]  R708      1.2054627388715744e-01
    z[1,2,5]  R709      -3.5846689343452454e-01
    z[1,2,5]  R710      -4.3303996324539185e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R619      -1
    z[1,2,6]  R620      1
    z[1,2,6]  R621      1.5975877642631531e-01
    z[1,2,6]  R622      1.5552735328674316e-01
    z[1,2,6]  R623      -2.1702274680137634e-02
    z[1,2,6]  R624      -2.1303531527519226e-01
    z[1,2,6]  R625      2.3531040549278259e-01
    z[1,2,6]  R626      -1.6468851268291473e-01
    z[1,2,6]  R627      9.1937407851219177e-03
    z[1,2,6]  R628      1.1114278435707092e-01
    z[1,2,6]  R629      3.0565917491912842e-02
    z[1,2,6]  R630      2.5358486175537109e-01
    z[1,2,6]  R631      -2.2230693697929382e-01
    z[1,2,6]  R632      -7.8097254037857056e-02
    z[1,2,6]  R633      -0.262433797121048
    z[1,2,6]  R634      0.0954258143901825
    z[1,2,6]  R635      2.6463833451271057e-01
    z[1,2,6]  R636      1.6134175658226013e-01
    z[1,2,6]  R637      -2.0603444427251816e-02
    z[1,2,6]  R638      9.7397871315479279e-02
    z[1,2,6]  R639      -2.3673607409000397e-01
    z[1,2,6]  R640      2.3702910542488098e-01
    z[1,2,6]  R641      -1.3209688663482666e-01
    z[1,2,6]  R642      2.9905205965042114e-01
    z[1,2,6]  R643      1.1577330529689789e-01
    z[1,2,6]  R644      2.0468689501285553e-01
    z[1,2,6]  R645      -8.3370774984359741e-02
    z[1,2,6]  R646      -1.7821887135505676e-01
    z[1,2,6]  R647      -1.7275738716125488e-01
    z[1,2,6]  R648      -4.0734943002462387e-02
    z[1,2,6]  R649      -8.5410818457603455e-02
    z[1,2,6]  R650      3.3465859293937683e-01
    z[1,2,6]  R651      2.8603413701057434e-01
    z[1,2,6]  R652      6.9640494883060455e-02
    z[1,2,6]  R653      1.4773635566234589e-01
    z[1,2,6]  R654      3.5808464884757996e-01
    z[1,2,6]  R655      0.284882128238678
    z[1,2,6]  R656      -0.254308819770813
    z[1,2,6]  R657      1.0130243003368378e-01
    z[1,2,6]  R658      -2.3207536339759827e-01
    z[1,2,6]  R659      -1.2426828593015671e-01
    z[1,2,6]  R660      -3.0167952179908752e-01
    z[1,2,6]  R661      2.2877737879753113e-01
    z[1,2,6]  R662      -8.3770573139190674e-02
    z[1,2,6]  R663      -1.8943063914775848e-01
    z[1,2,6]  R664      -1.9247531890869141e-01
    z[1,2,6]  R665      -1.7640799283981323e-01
    z[1,2,6]  R666      -2.1168164908885956e-01
    z[1,2,6]  R667      -1.0025624185800552e-01
    z[1,2,6]  R668      -1.1540773510932922e-01
    z[1,2,6]  R669      -1.8831816315650940e-01
    z[1,2,6]  R670      -4.3406596779823303e-01
    z[1,2,6]  R671      5.3462035953998566e-02
    z[1,2,6]  R672      -4.1332840919494629e-01
    z[1,2,6]  R673      -2.7431643009185791e-01
    z[1,2,6]  R674      -8.0111749470233917e-02
    z[1,2,6]  R675      -3.6975890398025513e-01
    z[1,2,6]  R676      -7.7255196869373322e-02
    z[1,2,6]  R677      -5.4858896881341934e-02
    z[1,2,6]  R678      -9.0832240879535675e-02
    z[1,2,6]  R679      3.4952464699745178e-01
    z[1,2,6]  R680      -2.1520432084798813e-02
    z[1,2,6]  R681      -2.4955970048904419e-01
    z[1,2,6]  R682      1.5067370235919952e-01
    z[1,2,6]  R683      4.1308920830488205e-02
    z[1,2,6]  R684      3.0079236626625061e-01
    z[1,2,6]  R685      4.3296954035758972e-01
    z[1,2,6]  R686      1.2698552012443542e-01
    z[1,2,6]  R687      5.6059543043375015e-02
    z[1,2,6]  R688      1.7663882672786713e-01
    z[1,2,6]  R689      -4.2658916115760803e-01
    z[1,2,6]  R690      -3.8099822402000427e-01
    z[1,2,6]  R691      2.5672060251235962e-01
    z[1,2,6]  R692      -0.246268168091774
    z[1,2,6]  R693      1.4512288384139538e-02
    z[1,2,6]  R694      9.0870611369609833e-02
    z[1,2,6]  R695      2.9818934202194214e-01
    z[1,2,6]  R696      -9.8133519291877747e-02
    z[1,2,6]  R697      -2.0349709689617157e-01
    z[1,2,6]  R698      -6.8014246225357056e-01
    z[1,2,6]  R699      -2.3519890382885933e-02
    z[1,2,6]  R700      0.328035831451416
    z[1,2,6]  R701      2.5234752893447876e-01
    z[1,2,6]  R702      -5.8398038148880005e-02
    z[1,2,6]  R703      2.4019230902194977e-01
    z[1,2,6]  R704      -6.7810076475143433e-01
    z[1,2,6]  R705      -7.9585418105125427e-02
    z[1,2,6]  R706      2.5969287753105164e-01
    z[1,2,6]  R707      -1.3493178784847260e-01
    z[1,2,6]  R708      1.8260501325130463e-01
    z[1,2,6]  R709      6.5527461469173431e-02
    z[1,2,6]  R710      -2.3894280195236206e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R711      -1
    z[2,1,0]  R712      1
    z[2,1,0]  R725      8.8604754209518433e-01
    z[2,1,0]  R726      1.4583480358123779e-01
    z[2,1,0]  R727      7.9103827476501465e-01
    z[2,1,0]  R728      8.7183523178100586e-01
    z[2,1,0]  R729      0.828798770904541
    z[2,1,0]  R730      8.3446949720382690e-01
    z[2,1,0]  R731      8.2140040397644043e-01
    z[2,1,0]  R732      3.2014328241348267e-01
    z[2,1,0]  R733      -5.8035325258970261e-02
    z[2,1,0]  R734      7.2002267837524414e-01
    z[2,1,0]  R735      -3.5881298780441284e-01
    z[2,1,0]  R736      -4.7988590598106384e-01
    z[2,1,0]  R737      -1.5419688820838928e-01
    z[2,1,0]  R738      -7.5405031442642212e-01
    z[2,1,0]  R739      -6.8363982439041138e-01
    z[2,1,0]  R740      -4.0264037251472473e-01
    z[2,1,0]  R741      -0.772131085395813
    z[2,1,0]  R742      -7.4872213602066040e-01
    z[2,1,0]  R743      -2.5317719578742981e-01
    z[2,1,0]  R744      -7.6686137914657593e-01
    z[2,1,0]  R745      4.8272699117660522e-02
    z[2,1,0]  R746      -2.3450122773647308e-01
    z[2,1,0]  R747      4.4383369386196136e-02
    z[2,1,0]  R748      -1.6060508787631989e-01
    z[2,1,0]  R749      3.9612289518117905e-02
    z[2,1,0]  R750      -9.2905491590499878e-02
    z[2,1,0]  R751      -7.7253989875316620e-02
    z[2,1,0]  R752      -4.0585073828697205e-01
    z[2,1,0]  R753      3.5294704139232635e-02
    z[2,1,0]  R754      -1.3486324250698090e-01
    z[2,1,0]  R755      1.8007567524909973e-01
    z[2,1,0]  R756      1.6546323604416102e-04
    z[2,1,0]  R757      2.5776728987693787e-01
    z[2,1,0]  R758      -4.1691058874130249e-01
    z[2,1,0]  R759      -2.6028215885162354e-01
    z[2,1,0]  R760      6.9311964511871338e-01
    z[2,1,0]  R761      -4.1471680998802185e-01
    z[2,1,0]  R762      -5.6344783306121826e-01
    z[2,1,0]  R763      -4.9564579129219055e-01
    z[2,1,0]  R764      -1.3505442440509796e-01
    z[2,1,0]  R765      -0.564138650894165
    z[2,1,0]  R766      3.5655394196510315e-01
    z[2,1,0]  R767      1.7037992179393768e-01
    z[2,1,0]  R768      -1.5335051715373993e-01
    z[2,1,0]  R769      -3.0667927861213684e-01
    z[2,1,0]  R770      -2.1232496201992035e-01
    z[2,1,0]  R771      8.5173296928405762e-01
    z[2,1,0]  R772      8.8291460275650024e-01
    z[2,1,0]  R773      0.199258491396904
    z[2,1,0]  R774      -1.7429096996784210e-01
    z[2,1,0]  R775      2.3610081523656845e-02
    z[2,1,0]  R776      -3.2982969284057617e-01
    z[2,1,0]  R777      6.9847536087036133e-01
    z[2,1,0]  R778      -4.6365892887115479e-01
    z[2,1,0]  R779      1.2046752125024796e-01
    z[2,1,0]  R780      -0.527647852897644
    z[2,1,0]  R781      2.2033995389938354e-01
    z[2,1,0]  R782      2.4991865456104279e-01
    z[2,1,0]  R783      -0.868701696395874
    z[2,1,0]  R784      -2.1660651266574860e-01
    z[2,1,0]  R785      8.6552582681179047e-02
    z[2,1,0]  R786      -2.6703274250030518e-01
    z[2,1,0]  R787      -4.2324659228324890e-01
    z[2,1,0]  R788      2.0893737673759460e-01
    z[2,1,0]  R789      2.3474301397800446e-01
    z[2,1,0]  R790      3.7857976555824280e-01
    z[2,1,0]  R791      -3.1002092361450195e-01
    z[2,1,0]  R792      1.0676967352628708e-01
    z[2,1,0]  R793      -0.282500684261322
    z[2,1,0]  R794      1.3480694591999054e-01
    z[2,1,0]  R795      -0.077597476541996
    z[2,1,0]  R796      2.6397129893302917e-01
    z[2,1,0]  R797      -7.9583726823329926e-02
    z[2,1,0]  R798      2.7869397774338722e-02
    z[2,1,0]  R799      -2.1747012436389923e-01
    z[2,1,0]  R800      2.2852631285786629e-02
    z[2,1,0]  R801      1.7220035195350647e-01
    z[2,1,0]  R802      2.2474895417690277e-01
    z[2,1,0]  R803      -3.9130559563636780e-01
    z[2,1,0]  R804      -4.8110938072204590e-01
    z[2,1,0]  R805      3.1633594632148743e-01
    z[2,1,0]  R806      6.5092794829979539e-04
    z[2,1,0]  R807      3.6189493536949158e-01
    z[2,1,0]  R808      -2.3062512278556824e-01
    z[2,1,0]  R809      1.5377096831798553e-01
    z[2,1,0]  R810      -1.4678399264812469e-01
    z[2,1,0]  R811      -1.1018574982881546e-01
    z[2,1,0]  R812      -7.4105983972549438e-01
    z[2,1,0]  R813      -3.4644496440887451e-01
    z[2,1,0]  R814      -3.0616229772567749e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R713      -1
    z[2,1,1]  R714      1
    z[2,1,1]  R725      -2.0820298790931702e-01
    z[2,1,1]  R726      -2.4536137282848358e-01
    z[2,1,1]  R727      -1.8139237165451050e-01
    z[2,1,1]  R728      -6.7742630839347839e-02
    z[2,1,1]  R729      2.2924799472093582e-02
    z[2,1,1]  R730      -1.3303156197071075e-01
    z[2,1,1]  R731      -1.2285141646862030e-01
    z[2,1,1]  R732      -1.8322411179542542e-01
    z[2,1,1]  R733      -2.3186931014060974e-01
    z[2,1,1]  R734      -1.5166489779949188e-01
    z[2,1,1]  R735      7.7723509073257446e-01
    z[2,1,1]  R736      6.2624263763427734e-01
    z[2,1,1]  R737      8.9889067411422729e-01
    z[2,1,1]  R738      4.2762383818626404e-01
    z[2,1,1]  R739      3.5715842247009277e-01
    z[2,1,1]  R740      0.71956866979599
    z[2,1,1]  R741      0.166547030210495
    z[2,1,1]  R742      1.8764916062355042e-01
    z[2,1,1]  R743      8.6886739730834961e-01
    z[2,1,1]  R744      2.7385982871055603e-01
    z[2,1,1]  R745      -9.1263711452484131e-01
    z[2,1,1]  R746      -8.6090552806854248e-01
    z[2,1,1]  R747      -7.9708242416381836e-01
    z[2,1,1]  R748      -7.9676896333694458e-01
    z[2,1,1]  R749      -8.3311569690704346e-01
    z[2,1,1]  R750      -8.7095212936401367e-01
    z[2,1,1]  R751      -0.763202428817749
    z[2,1,1]  R752      -7.7917784452438354e-01
    z[2,1,1]  R753      -0.824566125869751
    z[2,1,1]  R754      -6.9372671842575073e-01
    z[2,1,1]  R755      -0.659796953201294
    z[2,1,1]  R756      -4.9183964729309082e-01
    z[2,1,1]  R757      -5.3227448463439941e-01
    z[2,1,1]  R758      -1.8455389142036438e-01
    z[2,1,1]  R759      -2.4131046235561371e-01
    z[2,1,1]  R760      -5.4709357023239136e-01
    z[2,1,1]  R761      -5.6468397378921509e-01
    z[2,1,1]  R762      5.1037472486495972e-01
    z[2,1,1]  R763      -0.705713152885437
    z[2,1,1]  R764      1.6149090230464935e-01
    z[2,1,1]  R765      -4.5664042234420776e-01
    z[2,1,1]  R766      -3.6807930469512939e-01
    z[2,1,1]  R767      -2.4916736781597137e-01
    z[2,1,1]  R768      3.8674041628837585e-01
    z[2,1,1]  R769      0.219456747174263
    z[2,1,1]  R770      4.7260022163391113e-01
    z[2,1,1]  R771      -2.6977792382240295e-01
    z[2,1,1]  R772      -1.5420758724212646e-01
    z[2,1,1]  R773      6.4654910564422607e-01
    z[2,1,1]  R774      4.7253987193107605e-01
    z[2,1,1]  R775      1.4519819058477879e-02
    z[2,1,1]  R776      -5.6691801548004150e-01
    z[2,1,1]  R777      -4.2047610878944397e-01
    z[2,1,1]  R778      7.2132611274719238e-01
    z[2,1,1]  R779      -4.8361968994140625e-01
    z[2,1,1]  R780      2.6444411277770996e-01
    z[2,1,1]  R781      -9.6356995403766632e-02
    z[2,1,1]  R782      -5.6525218486785889e-01
    z[2,1,1]  R783      2.6983615756034851e-01
    z[2,1,1]  R784      -2.4216964840888977e-01
    z[2,1,1]  R785      -7.1035593748092651e-01
    z[2,1,1]  R786      -6.9905835390090942e-01
    z[2,1,1]  R787      7.4038130044937134e-01
    z[2,1,1]  R788      -4.5106706023216248e-01
    z[2,1,1]  R789      3.1020686030387878e-01
    z[2,1,1]  R790      1.9607998430728912e-01
    z[2,1,1]  R791      2.8569355607032776e-02
    z[2,1,1]  R792      -0.0813002958893776
    z[2,1,1]  R793      -3.0414137244224548e-01
    z[2,1,1]  R794      1.0632056742906570e-01
    z[2,1,1]  R795      3.6245518922805786e-01
    z[2,1,1]  R796      -2.0048640668392181e-01
    z[2,1,1]  R797      3.8528078794479370e-01
    z[2,1,1]  R798      3.3962216973304749e-01
    z[2,1,1]  R799      -2.6412123441696167e-01
    z[2,1,1]  R800      -2.6405319571495056e-01
    z[2,1,1]  R801      -3.0863621830940247e-01
    z[2,1,1]  R802      -9.1000741720199585e-01
    z[2,1,1]  R803      -5.7779359817504883e-01
    z[2,1,1]  R804      -7.2239577770233154e-01
    z[2,1,1]  R805      -1.3021700084209442e-01
    z[2,1,1]  R806      -1.8559944629669189e-01
    z[2,1,1]  R807      -3.5733491182327271e-02
    z[2,1,1]  R808      2.3735000193119049e-01
    z[2,1,1]  R809      2.7018073201179504e-01
    z[2,1,1]  R810      3.2937890291213989e-01
    z[2,1,1]  R811      1.8331421911716461e-01
    z[2,1,1]  R812      3.8572159409523010e-01
    z[2,1,1]  R813      5.4935926198959351e-01
    z[2,1,1]  R814      5.8083051443099976e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R715      -1
    z[2,1,2]  R716      1
    z[2,1,2]  R725      0.0910937711596489
    z[2,1,2]  R726      8.6018282175064087e-01
    z[2,1,2]  R727      4.2260631918907166e-01
    z[2,1,2]  R728      -4.1567340493202209e-02
    z[2,1,2]  R729      3.7105602025985718e-01
    z[2,1,2]  R730      4.1188856959342957e-01
    z[2,1,2]  R731      -0.0768071785569191
    z[2,1,2]  R732      9.0562599897384644e-01
    z[2,1,2]  R733      9.0104812383651733e-01
    z[2,1,2]  R734      -0.0647159144282341
    z[2,1,2]  R735      -2.9394480586051941e-01
    z[2,1,2]  R736      -3.2875162363052368e-01
    z[2,1,2]  R737      -3.6022484302520752e-01
    z[2,1,2]  R738      -2.7992677688598633e-01
    z[2,1,2]  R739      -4.0945509076118469e-01
    z[2,1,2]  R740      -3.1449410319328308e-01
    z[2,1,2]  R741      -2.1376132965087891e-01
    z[2,1,2]  R742      -4.1909557580947876e-01
    z[2,1,2]  R743      -1.9536575675010681e-01
    z[2,1,2]  R744      -1.6567899286746979e-01
    z[2,1,2]  R745      2.1565565839409828e-02
    z[2,1,2]  R746      1.8663156032562256e-01
    z[2,1,2]  R747      1.1444225907325745e-01
    z[2,1,2]  R748      1.7330738902091980e-01
    z[2,1,2]  R749      1.9123714417219162e-02
    z[2,1,2]  R750      2.7071169018745422e-01
    z[2,1,2]  R751      5.5021595209836960e-02
    z[2,1,2]  R752      -8.9638732373714447e-02
    z[2,1,2]  R753      -1.2983185052871704e-01
    z[2,1,2]  R754      0.456155925989151
    z[2,1,2]  R755      6.8963599205017090e-01
    z[2,1,2]  R756      3.6888051033020020e-01
    z[2,1,2]  R757      4.8535147309303284e-01
    z[2,1,2]  R758      5.2804708480834961e-01
    z[2,1,2]  R759      5.0944548845291138e-01
    z[2,1,2]  R760      -3.9497545361518860e-01
    z[2,1,2]  R761      2.5180166959762573e-01
    z[2,1,2]  R762      -2.9711747169494629e-01
    z[2,1,2]  R763      3.3206200599670410e-01
    z[2,1,2]  R764      -8.2156014442443848e-01
    z[2,1,2]  R765      5.9368723630905151e-01
    z[2,1,2]  R766      3.6254769563674927e-01
    z[2,1,2]  R767      0.542304515838623
    z[2,1,2]  R768      -6.8246215581893921e-01
    z[2,1,2]  R769      -6.6549074649810791e-01
    z[2,1,2]  R770      -6.3054847717285156e-01
    z[2,1,2]  R771      -2.1745751798152924e-01
    z[2,1,2]  R772      -7.5013250112533569e-02
    z[2,1,2]  R773      -5.2669900655746460e-01
    z[2,1,2]  R774      -4.9416157603263855e-01
    z[2,1,2]  R775      7.6543998718261719e-01
    z[2,1,2]  R776      3.4518721699714661e-01
    z[2,1,2]  R777      -5.2202981710433960e-01
    z[2,1,2]  R778      -0.376355916261673
    z[2,1,2]  R779      1.5767641365528107e-01
    z[2,1,2]  R780      -7.2714775800704956e-01
    z[2,1,2]  R781      4.8233687877655029e-01
    z[2,1,2]  R782      3.7854695320129395e-01
    z[2,1,2]  R783      -6.1420563608407974e-02
    z[2,1,2]  R784      3.6835893988609314e-01
    z[2,1,2]  R785      5.4648733139038086e-01
    z[2,1,2]  R786      4.1992199420928955e-01
    z[2,1,2]  R787      -0.415484219789505
    z[2,1,2]  R788      5.0685596466064453e-01
    z[2,1,2]  R789      4.7984153032302856e-01
    z[2,1,2]  R790      -4.0168985724449158e-01
    z[2,1,2]  R791      -0.302696168422699
    z[2,1,2]  R792      -1.9866585731506348e-01
    z[2,1,2]  R793      -5.0169765949249268e-01
    z[2,1,2]  R794      -2.9586029052734375e-01
    z[2,1,2]  R795      -2.4280132353305817e-01
    z[2,1,2]  R796      -3.8911259174346924e-01
    z[2,1,2]  R797      3.3616498112678528e-01
    z[2,1,2]  R798      1.9201441109180450e-01
    z[2,1,2]  R799      -0.211082324385643
    z[2,1,2]  R800      5.0174808502197266e-01
    z[2,1,2]  R801      9.4765760004520416e-02
    z[2,1,2]  R802      -1.2549269199371338e-01
    z[2,1,2]  R803      5.6650322675704956e-01
    z[2,1,2]  R804      2.4162469804286957e-01
    z[2,1,2]  R805      1.5392532944679260e-01
    z[2,1,2]  R806      -1.1897242814302444e-01
    z[2,1,2]  R807      0.45625039935112
    z[2,1,2]  R808      -1.4246310293674469e-01
    z[2,1,2]  R809      1.6092897951602936e-01
    z[2,1,2]  R810      2.2043561935424805e-01
    z[2,1,2]  R811      1.3189366459846497e-01
    z[2,1,2]  R812      -3.7291178107261658e-01
    z[2,1,2]  R813      -5.5576390027999878e-01
    z[2,1,2]  R814      -5.5670505762100220e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R717      -1
    z[2,1,3]  R718      1
    z[2,1,3]  R725      3.6288830637931824e-01
    z[2,1,3]  R726      2.6031108573079109e-02
    z[2,1,3]  R727      3.5282278060913086e-01
    z[2,1,3]  R728      3.7063917517662048e-01
    z[2,1,3]  R729      3.4668728709220886e-01
    z[2,1,3]  R730      0.280091255903244
    z[2,1,3]  R731      3.0276027321815491e-01
    z[2,1,3]  R732      -0.0650770291686058
    z[2,1,3]  R733      1.5361729077994823e-02
    z[2,1,3]  R734      3.7681087851524353e-01
    z[2,1,3]  R735      -1.1669117212295532e-01
    z[2,1,3]  R736      -2.6099857687950134e-01
    z[2,1,3]  R737      -1.2423708289861679e-01
    z[2,1,3]  R738      -1.9255127012729645e-01
    z[2,1,3]  R739      -1.3361001014709473e-01
    z[2,1,3]  R740      -3.3215454220771790e-01
    z[2,1,3]  R741      -1.3045512139797211e-01
    z[2,1,3]  R742      -3.0237317085266113e-01
    z[2,1,3]  R743      -1.8618687987327576e-01
    z[2,1,3]  R744      -2.9385924339294434e-01
    z[2,1,3]  R745      1.7202377319335938e-01
    z[2,1,3]  R746      3.0013132095336914e-01
    z[2,1,3]  R747      3.1678459048271179e-01
    z[2,1,3]  R748      5.1525235176086426e-01
    z[2,1,3]  R749      1.6616627573966980e-02
    z[2,1,3]  R750      -2.5784291326999664e-02
    z[2,1,3]  R751      2.7257108688354492e-01
    z[2,1,3]  R752      3.2830587029457092e-01
    z[2,1,3]  R753      1.7882893979549408e-01
    z[2,1,3]  R754      -7.8448191285133362e-02
    z[2,1,3]  R755      2.0064114034175873e-01
    z[2,1,3]  R756      -1.5162938833236694e-01
    z[2,1,3]  R757      -7.9044135054573417e-04
    z[2,1,3]  R758      -2.9002451896667480e-01
    z[2,1,3]  R759      -6.2565606832504272e-01
    z[2,1,3]  R760      0.141846165060997
    z[2,1,3]  R761      -1.3586845993995667e-01
    z[2,1,3]  R762      -2.4493041634559631e-01
    z[2,1,3]  R763      8.6284153163433075e-02
    z[2,1,3]  R764      -3.9184951782226562e-01
    z[2,1,3]  R765      -1.4163862168788910e-01
    z[2,1,3]  R766      -6.7420870065689087e-01
    z[2,1,3]  R767      3.4459149837493896e-01
    z[2,1,3]  R768      -1.3506361842155457e-01
    z[2,1,3]  R769      -4.0715873241424561e-01
    z[2,1,3]  R770      -1.5841390192508698e-01
    z[2,1,3]  R771      -4.7076758928596973e-03
    z[2,1,3]  R772      -2.6557031273841858e-01
    z[2,1,3]  R773      -1.9811186194419861e-01
    z[2,1,3]  R774      -1.9661815464496613e-01
    z[2,1,3]  R775      -5.2235692739486694e-01
    z[2,1,3]  R776      -4.6523699164390564e-01
    z[2,1,3]  R777      1.6508273780345917e-01
    z[2,1,3]  R778      -1.6416238248348236e-01
    z[2,1,3]  R779      -2.9310640692710876e-01
    z[2,1,3]  R780      -2.4496681988239288e-01
    z[2,1,3]  R781      -8.1528216600418091e-01
    z[2,1,3]  R782      -7.7290818095207214e-02
    z[2,1,3]  R783      -2.4361704289913177e-01
    z[2,1,3]  R784      -6.9557827711105347e-01
    z[2,1,3]  R785      2.0319934189319611e-01
    z[2,1,3]  R786      -6.2119122594594955e-03
    z[2,1,3]  R787      -1.5458916127681732e-01
    z[2,1,3]  R788      -9.3709513545036316e-02
    z[2,1,3]  R789      2.6010328531265259e-01
    z[2,1,3]  R790      -7.3046904802322388e-01
    z[2,1,3]  R791      -6.6346544027328491e-01
    z[2,1,3]  R792      -6.2754082679748535e-01
    z[2,1,3]  R793      -1.7004366219043732e-01
    z[2,1,3]  R794      -0.610435426235199
    z[2,1,3]  R795      6.9761854410171509e-01
    z[2,1,3]  R796      7.0579981803894043e-01
    z[2,1,3]  R797      7.0265442132949829e-01
    z[2,1,3]  R798      8.3274716138839722e-01
    z[2,1,3]  R799      8.3575522899627686e-01
    z[2,1,3]  R800      6.8083167076110840e-01
    z[2,1,3]  R801      4.4157034158706665e-01
    z[2,1,3]  R802      -1.1593621969223022e-01
    z[2,1,3]  R803      -0.0922110453248024
    z[2,1,3]  R804      -0.0977182611823082
    z[2,1,3]  R805      -8.8844668865203857e-01
    z[2,1,3]  R806      -7.7384406328201294e-01
    z[2,1,3]  R807      -5.3013539314270020e-01
    z[2,1,3]  R808      -4.3950146436691284e-01
    z[2,1,3]  R809      -3.7368568778038025e-01
    z[2,1,3]  R810      -4.1142952442169189e-01
    z[2,1,3]  R811      -3.6310148239135742e-01
    z[2,1,3]  R812      -2.4321369826793671e-01
    z[2,1,3]  R813      -2.4231983721256256e-01
    z[2,1,3]  R814      -2.5232541561126709e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R719      -1
    z[2,1,4]  R720      1
    z[2,1,4]  R725      -1.0050161927938461e-01
    z[2,1,4]  R726      1.0758806765079498e-01
    z[2,1,4]  R727      1.4761133491992950e-01
    z[2,1,4]  R728      2.3139512538909912e-01
    z[2,1,4]  R729      1.8747209012508392e-01
    z[2,1,4]  R730      0.0691203773021698
    z[2,1,4]  R731      3.6277133226394653e-01
    z[2,1,4]  R732      -9.3559734523296356e-02
    z[2,1,4]  R733      3.5093545913696289e-01
    z[2,1,4]  R734      2.8707376122474670e-01
    z[2,1,4]  R735      -2.1543622016906738e-01
    z[2,1,4]  R736      -1.2187865376472473e-01
    z[2,1,4]  R737      3.2665453851222992e-02
    z[2,1,4]  R738      -6.5461009740829468e-02
    z[2,1,4]  R739      -2.3137234151363373e-01
    z[2,1,4]  R740      1.4333372004330158e-02
    z[2,1,4]  R741      -3.0005258321762085e-01
    z[2,1,4]  R742      -1.8443909287452698e-01
    z[2,1,4]  R743      -2.4288322031497955e-01
    z[2,1,4]  R744      -1.9801400601863861e-02
    z[2,1,4]  R745      2.8166922926902771e-01
    z[2,1,4]  R746      1.3172371685504913e-01
    z[2,1,4]  R747      4.6188560128211975e-01
    z[2,1,4]  R748      4.0505036711692810e-02
    z[2,1,4]  R749      0.454078733921051
    z[2,1,4]  R750      -2.6080831885337830e-02
    z[2,1,4]  R751      2.5098109245300293e-01
    z[2,1,4]  R752      3.0422726273536682e-01
    z[2,1,4]  R753      4.6035513281822205e-02
    z[2,1,4]  R754      -2.6826274394989014e-01
    z[2,1,4]  R755      -8.3375498652458191e-02
    z[2,1,4]  R756      -3.6722859740257263e-01
    z[2,1,4]  R757      2.6221892237663269e-01
    z[2,1,4]  R758      -4.3608167767524719e-01
    z[2,1,4]  R759      -2.8397905826568604e-01
    z[2,1,4]  R760      1.5624053776264191e-01
    z[2,1,4]  R761      3.8545615971088409e-02
    z[2,1,4]  R762      -0.513958215713501
    z[2,1,4]  R763      -5.2396561950445175e-02
    z[2,1,4]  R764      -1.1542411148548126e-01
    z[2,1,4]  R765      -7.3523811995983124e-02
    z[2,1,4]  R766      -1.7473040521144867e-01
    z[2,1,4]  R767      3.3437156677246094e-01
    z[2,1,4]  R768      -3.5563436150550842e-01
    z[2,1,4]  R769      2.3139014840126038e-01
    z[2,1,4]  R770      5.3134876489639282e-01
    z[2,1,4]  R771      -3.8897490501403809e-01
    z[2,1,4]  R772      -2.6186376810073853e-01
    z[2,1,4]  R773      -1.6237211227416992e-01
    z[2,1,4]  R774      -2.4907091632485390e-02
    z[2,1,4]  R775      1.4272421598434448e-01
    z[2,1,4]  R776      -3.6843821406364441e-02
    z[2,1,4]  R777      -1.8145012855529785e-01
    z[2,1,4]  R778      7.4807085096836090e-02
    z[2,1,4]  R779      2.5480762124061584e-01
    z[2,1,4]  R780      -3.4952532500028610e-02
    z[2,1,4]  R781      5.3019434213638306e-02
    z[2,1,4]  R782      5.8762248605489731e-02
    z[2,1,4]  R783      -3.1292009353637695e-01
    z[2,1,4]  R784      -3.2390853762626648e-01
    z[2,1,4]  R785      1.4266617596149445e-01
    z[2,1,4]  R786      -4.0367400646209717e-01
    z[2,1,4]  R787      1.3523253798484802e-01
    z[2,1,4]  R788      -8.8543213903903961e-02
    z[2,1,4]  R789      0.548109233379364
    z[2,1,4]  R790      -1.6275113821029663e-01
    z[2,1,4]  R791      -5.6561392545700073e-01
    z[2,1,4]  R792      0.707699716091156
    z[2,1,4]  R793      -6.4364886283874512e-01
    z[2,1,4]  R794      5.1550066471099854e-01
    z[2,1,4]  R795      3.9406582713127136e-01
    z[2,1,4]  R796      4.5046284794807434e-01
    z[2,1,4]  R797      0.486801415681839
    z[2,1,4]  R798      -2.4763226509094238e-01
    z[2,1,4]  R799      -1.4636451005935669e-01
    z[2,1,4]  R800      4.3101231567561626e-03
    z[2,1,4]  R801      4.7685602307319641e-01
    z[2,1,4]  R802      -4.4916570186614990e-03
    z[2,1,4]  R803      -3.2263353466987610e-01
    z[2,1,4]  R804      -2.9715770483016968e-01
    z[2,1,4]  R805      1.1608657240867615e-01
    z[2,1,4]  R806      -4.9887317419052124e-01
    z[2,1,4]  R807      5.0323802232742310e-01
    z[2,1,4]  R808      -0.346293181180954
    z[2,1,4]  R809      -4.7331359982490540e-01
    z[2,1,4]  R810      -3.8748362660408020e-01
    z[2,1,4]  R811      -5.0233131647109985e-01
    z[2,1,4]  R812      -1.5805552899837494e-01
    z[2,1,4]  R813      -0.0805695503950119
    z[2,1,4]  R814      -2.3558795452117920e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R721      -1
    z[2,1,5]  R722      1
    z[2,1,5]  R725      -0.0635211244225502
    z[2,1,5]  R726      2.7736338973045349e-01
    z[2,1,5]  R727      5.5521562695503235e-02
    z[2,1,5]  R728      2.7796175330877304e-02
    z[2,1,5]  R729      1.1223144084215164e-01
    z[2,1,5]  R730      3.6337185651063919e-02
    z[2,1,5]  R731      -2.2626908123493195e-01
    z[2,1,5]  R732      1.7067806422710419e-01
    z[2,1,5]  R733      -1.7152380198240280e-02
    z[2,1,5]  R734      -3.4348621964454651e-01
    z[2,1,5]  R735      -1.9725652039051056e-01
    z[2,1,5]  R736      4.2617791891098022e-01
    z[2,1,5]  R737      1.1352778412401676e-02
    z[2,1,5]  R738      -2.4518366903066635e-02
    z[2,1,5]  R739      -2.9133906960487366e-01
    z[2,1,5]  R740      2.1445275843143463e-01
    z[2,1,5]  R741      -4.6159449219703674e-01
    z[2,1,5]  R742      -2.2193560004234314e-01
    z[2,1,5]  R743      -1.8358242511749268e-01
    z[2,1,5]  R744      -3.6293134093284607e-01
    z[2,1,5]  R745      5.5039305239915848e-02
    z[2,1,5]  R746      -2.3360683023929596e-01
    z[2,1,5]  R747      -4.2297882027924061e-03
    z[2,1,5]  R748      -0.0718153715133667
    z[2,1,5]  R749      2.5768172740936279e-01
    z[2,1,5]  R750      3.3670762181282043e-01
    z[2,1,5]  R751      5.1106613874435425e-01
    z[2,1,5]  R752      -8.0461136996746063e-02
    z[2,1,5]  R753      4.8210576176643372e-01
    z[2,1,5]  R754      1.6107335686683655e-01
    z[2,1,5]  R755      8.1095799803733826e-02
    z[2,1,5]  R756      5.4160147905349731e-01
    z[2,1,5]  R757      5.2025479078292847e-01
    z[2,1,5]  R758      4.8227846622467041e-01
    z[2,1,5]  R759      7.5342416763305664e-02
    z[2,1,5]  R760      1.1733891814947128e-01
    z[2,1,5]  R761      6.5021711587905884e-01
    z[2,1,5]  R762      -3.7025246769189835e-02
    z[2,1,5]  R763      1.1696664243936539e-01
    z[2,1,5]  R764      -3.3673125505447388e-01
    z[2,1,5]  R765      1.8170122802257538e-01
    z[2,1,5]  R766      3.1329768896102905e-01
    z[2,1,5]  R767      -6.1849659681320190e-01
    z[2,1,5]  R768      -3.5491830110549927e-01
    z[2,1,5]  R769      -9.0146347880363464e-02
    z[2,1,5]  R770      1.0209847241640091e-01
    z[2,1,5]  R771      0.00407183775678277
    z[2,1,5]  R772      1.4406004548072815e-01
    z[2,1,5]  R773      -0.131404310464859
    z[2,1,5]  R774      -5.6364381313323975e-01
    z[2,1,5]  R775      -2.3281066119670868e-01
    z[2,1,5]  R776      4.1498345136642456e-01
    z[2,1,5]  R777      4.9292922019958496e-02
    z[2,1,5]  R778      -2.8681412339210510e-01
    z[2,1,5]  R779      6.9784134626388550e-01
    z[2,1,5]  R780      -2.2815065085887909e-01
    z[2,1,5]  R781      2.4691013619303703e-02
    z[2,1,5]  R782      5.2079174667596817e-02
    z[2,1,5]  R783      -1.0465037077665329e-01
    z[2,1,5]  R784      2.4978755414485931e-01
    z[2,1,5]  R785      2.5284758210182190e-01
    z[2,1,5]  R786      3.1188917160034180e-01
    z[2,1,5]  R787      1.3883448205888271e-02
    z[2,1,5]  R788      1.3978092372417450e-01
    z[2,1,5]  R789      -4.9397191405296326e-01
    z[2,1,5]  R790      -1.7135277390480042e-01
    z[2,1,5]  R791      1.8202652037143707e-01
    z[2,1,5]  R792      1.2054627388715744e-01
    z[2,1,5]  R793      -3.5846689343452454e-01
    z[2,1,5]  R794      -4.3303996324539185e-01
    z[2,1,5]  R795      -3.6901223659515381e-01
    z[2,1,5]  R796      -1.1600410193204880e-01
    z[2,1,5]  R797      3.2378707081079483e-02
    z[2,1,5]  R798      -2.1641814708709717e-01
    z[2,1,5]  R799      -2.5121828913688660e-01
    z[2,1,5]  R800      -4.3281629681587219e-01
    z[2,1,5]  R801      -6.6607022285461426e-01
    z[2,1,5]  R802      2.8251004219055176e-01
    z[2,1,5]  R803      -2.8031954169273376e-01
    z[2,1,5]  R804      -1.6167476773262024e-01
    z[2,1,5]  R805      -8.3953499794006348e-02
    z[2,1,5]  R806      -3.1239360570907593e-01
    z[2,1,5]  R807      2.3754407465457916e-01
    z[2,1,5]  R808      7.4026662111282349e-01
    z[2,1,5]  R809      6.6615206003189087e-01
    z[2,1,5]  R810      6.8987190723419189e-01
    z[2,1,5]  R811      7.4313873052597046e-01
    z[2,1,5]  R812      2.6337283849716187e-01
    z[2,1,5]  R813      3.8477602601051331e-01
    z[2,1,5]  R814      2.8918406367301941e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R723      -1
    z[2,1,6]  R724      1
    z[2,1,6]  R725      -1.3209688663482666e-01
    z[2,1,6]  R726      2.9905205965042114e-01
    z[2,1,6]  R727      1.1577330529689789e-01
    z[2,1,6]  R728      2.0468689501285553e-01
    z[2,1,6]  R729      -8.3370774984359741e-02
    z[2,1,6]  R730      -1.7821887135505676e-01
    z[2,1,6]  R731      -1.7275738716125488e-01
    z[2,1,6]  R732      -4.0734943002462387e-02
    z[2,1,6]  R733      -8.5410818457603455e-02
    z[2,1,6]  R734      3.3465859293937683e-01
    z[2,1,6]  R735      2.8603413701057434e-01
    z[2,1,6]  R736      6.9640494883060455e-02
    z[2,1,6]  R737      1.4773635566234589e-01
    z[2,1,6]  R738      3.5808464884757996e-01
    z[2,1,6]  R739      0.284882128238678
    z[2,1,6]  R740      -0.254308819770813
    z[2,1,6]  R741      1.0130243003368378e-01
    z[2,1,6]  R742      -2.3207536339759827e-01
    z[2,1,6]  R743      -1.2426828593015671e-01
    z[2,1,6]  R744      -3.0167952179908752e-01
    z[2,1,6]  R745      2.2877737879753113e-01
    z[2,1,6]  R746      -8.3770573139190674e-02
    z[2,1,6]  R747      -1.8943063914775848e-01
    z[2,1,6]  R748      -1.9247531890869141e-01
    z[2,1,6]  R749      -1.7640799283981323e-01
    z[2,1,6]  R750      -2.1168164908885956e-01
    z[2,1,6]  R751      -1.0025624185800552e-01
    z[2,1,6]  R752      -1.1540773510932922e-01
    z[2,1,6]  R753      -1.8831816315650940e-01
    z[2,1,6]  R754      -4.3406596779823303e-01
    z[2,1,6]  R755      5.3462035953998566e-02
    z[2,1,6]  R756      -4.1332840919494629e-01
    z[2,1,6]  R757      -2.7431643009185791e-01
    z[2,1,6]  R758      -8.0111749470233917e-02
    z[2,1,6]  R759      -3.6975890398025513e-01
    z[2,1,6]  R760      -7.7255196869373322e-02
    z[2,1,6]  R761      -5.4858896881341934e-02
    z[2,1,6]  R762      -9.0832240879535675e-02
    z[2,1,6]  R763      3.4952464699745178e-01
    z[2,1,6]  R764      -2.1520432084798813e-02
    z[2,1,6]  R765      -2.4955970048904419e-01
    z[2,1,6]  R766      1.5067370235919952e-01
    z[2,1,6]  R767      4.1308920830488205e-02
    z[2,1,6]  R768      3.0079236626625061e-01
    z[2,1,6]  R769      4.3296954035758972e-01
    z[2,1,6]  R770      1.2698552012443542e-01
    z[2,1,6]  R771      5.6059543043375015e-02
    z[2,1,6]  R772      1.7663882672786713e-01
    z[2,1,6]  R773      -4.2658916115760803e-01
    z[2,1,6]  R774      -3.8099822402000427e-01
    z[2,1,6]  R775      2.5672060251235962e-01
    z[2,1,6]  R776      -0.246268168091774
    z[2,1,6]  R777      1.4512288384139538e-02
    z[2,1,6]  R778      9.0870611369609833e-02
    z[2,1,6]  R779      2.9818934202194214e-01
    z[2,1,6]  R780      -9.8133519291877747e-02
    z[2,1,6]  R781      -2.0349709689617157e-01
    z[2,1,6]  R782      -6.8014246225357056e-01
    z[2,1,6]  R783      -2.3519890382885933e-02
    z[2,1,6]  R784      0.328035831451416
    z[2,1,6]  R785      2.5234752893447876e-01
    z[2,1,6]  R786      -5.8398038148880005e-02
    z[2,1,6]  R787      2.4019230902194977e-01
    z[2,1,6]  R788      -6.7810076475143433e-01
    z[2,1,6]  R789      -7.9585418105125427e-02
    z[2,1,6]  R790      2.5969287753105164e-01
    z[2,1,6]  R791      -1.3493178784847260e-01
    z[2,1,6]  R792      1.8260501325130463e-01
    z[2,1,6]  R793      6.5527461469173431e-02
    z[2,1,6]  R794      -2.3894280195236206e-01
    z[2,1,6]  R795      1.5975877642631531e-01
    z[2,1,6]  R796      1.5552735328674316e-01
    z[2,1,6]  R797      -2.1702274680137634e-02
    z[2,1,6]  R798      -2.1303531527519226e-01
    z[2,1,6]  R799      2.3531040549278259e-01
    z[2,1,6]  R800      -1.6468851268291473e-01
    z[2,1,6]  R801      9.1937407851219177e-03
    z[2,1,6]  R802      1.1114278435707092e-01
    z[2,1,6]  R803      3.0565917491912842e-02
    z[2,1,6]  R804      2.5358486175537109e-01
    z[2,1,6]  R805      -2.2230693697929382e-01
    z[2,1,6]  R806      -7.8097254037857056e-02
    z[2,1,6]  R807      -0.262433797121048
    z[2,1,6]  R808      0.0954258143901825
    z[2,1,6]  R809      2.6463833451271057e-01
    z[2,1,6]  R810      1.6134175658226013e-01
    z[2,1,6]  R811      -2.0603444427251816e-02
    z[2,1,6]  R812      9.7397871315479279e-02
    z[2,1,6]  R813      -2.3673607409000397e-01
    z[2,1,6]  R814      2.3702910542488098e-01
    z[1,3,0]  R11       -1
    z[1,3,0]  R29       1
    z[1,3,0]  R815      -1
    z[1,3,0]  R816      1
    z[1,3,0]  R829      -0.077597476541996
    z[1,3,0]  R830      2.6397129893302917e-01
    z[1,3,0]  R831      -7.9583726823329926e-02
    z[1,3,0]  R832      2.7869397774338722e-02
    z[1,3,0]  R833      -2.1747012436389923e-01
    z[1,3,0]  R834      2.2852631285786629e-02
    z[1,3,0]  R835      1.7220035195350647e-01
    z[1,3,0]  R836      2.2474895417690277e-01
    z[1,3,0]  R837      -3.9130559563636780e-01
    z[1,3,0]  R838      -4.8110938072204590e-01
    z[1,3,0]  R839      3.1633594632148743e-01
    z[1,3,0]  R840      6.5092794829979539e-04
    z[1,3,0]  R841      3.6189493536949158e-01
    z[1,3,0]  R842      -2.3062512278556824e-01
    z[1,3,0]  R843      1.5377096831798553e-01
    z[1,3,0]  R844      -1.4678399264812469e-01
    z[1,3,0]  R845      -1.1018574982881546e-01
    z[1,3,0]  R846      -7.4105983972549438e-01
    z[1,3,0]  R847      -3.4644496440887451e-01
    z[1,3,0]  R848      -3.0616229772567749e-01
    z[1,3,0]  R849      -7.3149889707565308e-01
    z[1,3,0]  R850      -4.6494984626770020e-01
    z[1,3,0]  R851      -5.5307424068450928e-01
    z[1,3,0]  R852      -6.4098256826400757e-01
    z[1,3,0]  R853      -4.6843826770782471e-01
    z[1,3,0]  R854      6.9115829467773438e-01
    z[1,3,0]  R855      -7.4154675006866455e-01
    z[1,3,0]  R856      -7.4062174558639526e-01
    z[1,3,0]  R857      -6.4864701032638550e-01
    z[1,3,0]  R858      -4.9817335605621338e-01
    z[1,3,0]  R859      2.0759922266006470e-01
    z[1,3,0]  R860      7.5057804584503174e-01
    z[1,3,0]  R861      -5.5326479673385620e-01
    z[1,3,0]  R862      -4.6926024556159973e-01
    z[1,3,0]  R863      3.9492759108543396e-01
    z[1,3,0]  R864      3.6992263793945312e-01
    z[1,3,0]  R865      2.0820197463035583e-01
    z[1,3,0]  R866      4.7991272062063217e-02
    z[1,3,0]  R867      1.1325430870056152e-01
    z[1,3,0]  R868      -5.5136060714721680e-01
    z[1,3,0]  R869      1.4380007982254028e-01
    z[1,3,0]  R870      3.2474073767662048e-01
    z[1,3,0]  R871      4.8364314436912537e-01
    z[1,3,0]  R872      -1.2364013493061066e-01
    z[1,3,0]  R873      2.0443318784236908e-01
    z[1,3,0]  R874      2.6790171861648560e-01
    z[1,3,0]  R875      1.7849633097648621e-01
    z[1,3,0]  R876      -0.0982329249382019
    z[1,3,0]  R877      1.9996878504753113e-01
    z[1,3,0]  R878      1.4755828678607941e-01
    z[1,3,0]  R879      1.6651113331317902e-01
    z[1,3,0]  R880      3.1945732235908508e-01
    z[1,3,0]  R881      1.4911076426506042e-01
    z[1,3,0]  R882      2.7498263120651245e-01
    z[1,3,0]  R883      3.6940187215805054e-01
    z[1,3,0]  R884      -4.3450483679771423e-01
    z[1,3,0]  R885      3.5477286577224731e-01
    z[1,3,0]  R886      -2.5958001613616943e-01
    z[1,3,0]  R887      5.5322623252868652e-01
    z[1,3,0]  R888      -6.8578487634658813e-01
    z[1,3,0]  R889      4.1563576459884644e-01
    z[1,3,0]  R890      6.5622836351394653e-01
    z[1,3,0]  R891      3.5397329926490784e-01
    z[1,3,0]  R892      5.3247994184494019e-01
    z[1,3,0]  R893      -1.4392016828060150e-01
    z[1,3,0]  R894      6.9569003582000732e-01
    z[1,3,0]  R895      1.2768420577049255e-01
    z[1,3,0]  R896      2.3055291175842285e-01
    z[1,3,0]  R897      0.437958300113678
    z[1,3,0]  R898      4.4579499959945679e-01
    z[1,3,0]  R899      6.4987319707870483e-01
    z[1,3,0]  R900      -4.2804482579231262e-01
    z[1,3,0]  R901      2.9841953516006470e-01
    z[1,3,0]  R902      -7.1220767498016357e-01
    z[1,3,0]  R903      1.4320926368236542e-01
    z[1,3,0]  R904      5.1414996385574341e-01
    z[1,3,0]  R905      4.6924032270908356e-02
    z[1,3,0]  R906      7.6293818652629852e-02
    z[1,3,0]  R907      3.7339481711387634e-01
    z[1,3,0]  R908      -2.5049021840095520e-01
    z[1,3,0]  R909      4.3164721131324768e-01
    z[1,3,0]  R910      5.1107597351074219e-01
    z[1,3,0]  R911      4.9693781137466431e-01
    z[1,3,0]  R912      3.2298576831817627e-01
    z[1,3,0]  R913      6.4064615964889526e-01
    z[1,3,0]  R914      -7.0324313640594482e-01
    z[1,3,0]  R915      1.7100089788436890e-01
    z[1,3,0]  R916      -2.4214620888233185e-01
    z[1,3,0]  R917      -3.0630099773406982e-01
    z[1,3,0]  R918      -4.8566347360610962e-01
    z[1,3,0]  R919      3.9700803160667419e-01
    z[1,3,0]  R920      3.1685985624790192e-02
    z[1,3,0]  R921      6.9347220659255981e-01
    z[1,3,0]  R922      -5.7144099473953247e-01
    z[1,3,0]  R923      5.4736936092376709e-01
    z[1,3,0]  R924      -5.0030130147933960e-01
    z[1,3,0]  R925      -1.4278750121593475e-01
    z[1,3,0]  R926      -4.9214673042297363e-01
    z[1,3,0]  R927      -3.1458348035812378e-02
    z[1,3,0]  R928      -2.7843341231346130e-01
    z[1,3,0]  R929      -6.0938209295272827e-01
    z[1,3,0]  R930      3.6866092681884766e-01
    z[1,3,0]  R931      -5.1106846332550049e-01
    z[1,3,0]  R932      5.4783982038497925e-01
    z[1,3,0]  R933      -4.9239164590835571e-01
    z[1,3,0]  R934      3.8289362192153931e-01
    z[1,3,0]  R935      -4.2543691396713257e-01
    z[1,3,0]  R936      -1.9382968544960022e-01
    z[1,3,0]  R937      -4.3683847784996033e-01
    z[1,3,0]  R938      -2.7887448668479919e-01
    z[1,3,1]  R12       -1
    z[1,3,1]  R30       1
    z[1,3,1]  R817      -1
    z[1,3,1]  R818      1
    z[1,3,1]  R829      3.6245518922805786e-01
    z[1,3,1]  R830      -2.0048640668392181e-01
    z[1,3,1]  R831      3.8528078794479370e-01
    z[1,3,1]  R832      3.3962216973304749e-01
    z[1,3,1]  R833      -2.6412123441696167e-01
    z[1,3,1]  R834      -2.6405319571495056e-01
    z[1,3,1]  R835      -3.0863621830940247e-01
    z[1,3,1]  R836      -9.1000741720199585e-01
    z[1,3,1]  R837      -5.7779359817504883e-01
    z[1,3,1]  R838      -7.2239577770233154e-01
    z[1,3,1]  R839      -1.3021700084209442e-01
    z[1,3,1]  R840      -1.8559944629669189e-01
    z[1,3,1]  R841      -3.5733491182327271e-02
    z[1,3,1]  R842      2.3735000193119049e-01
    z[1,3,1]  R843      2.7018073201179504e-01
    z[1,3,1]  R844      3.2937890291213989e-01
    z[1,3,1]  R845      1.8331421911716461e-01
    z[1,3,1]  R846      3.8572159409523010e-01
    z[1,3,1]  R847      5.4935926198959351e-01
    z[1,3,1]  R848      5.8083051443099976e-01
    z[1,3,1]  R849      -2.2296635806560516e-01
    z[1,3,1]  R850      -4.3592748045921326e-01
    z[1,3,1]  R851      -2.8077259659767151e-01
    z[1,3,1]  R852      -3.1925195455551147e-01
    z[1,3,1]  R853      -3.2749226689338684e-01
    z[1,3,1]  R854      -7.6501101255416870e-02
    z[1,3,1]  R855      -3.2344156503677368e-01
    z[1,3,1]  R856      -0.530152440071106
    z[1,3,1]  R857      -2.4570703506469727e-01
    z[1,3,1]  R858      -2.5414341688156128e-01
    z[1,3,1]  R859      7.3943096399307251e-01
    z[1,3,1]  R860      1.1804948002099991e-01
    z[1,3,1]  R861      7.8791356086730957e-01
    z[1,3,1]  R862      8.4700977802276611e-01
    z[1,3,1]  R863      4.1214641928672791e-01
    z[1,3,1]  R864      6.3256627321243286e-01
    z[1,3,1]  R865      2.4967686831951141e-01
    z[1,3,1]  R866      4.2082428932189941e-01
    z[1,3,1]  R867      2.5530877709388733e-01
    z[1,3,1]  R868      7.4511927366256714e-01
    z[1,3,1]  R869      -2.8681892156600952e-01
    z[1,3,1]  R870      -1.8626321852207184e-01
    z[1,3,1]  R871      -3.1145927309989929e-01
    z[1,3,1]  R872      3.9020884037017822e-01
    z[1,3,1]  R873      -3.5172438621520996e-01
    z[1,3,1]  R874      -0.818288266658783
    z[1,3,1]  R875      -8.1852716207504272e-01
    z[1,3,1]  R876      -7.9543876647949219e-01
    z[1,3,1]  R877      -0.739153265953064
    z[1,3,1]  R878      -8.0173850059509277e-01
    z[1,3,1]  R879      2.1644264459609985e-01
    z[1,3,1]  R880      2.5637015700340271e-01
    z[1,3,1]  R881      1.3758948445320129e-01
    z[1,3,1]  R882      -2.0281149446964264e-01
    z[1,3,1]  R883      -2.7382951974868774e-01
    z[1,3,1]  R884      3.3426719903945923e-01
    z[1,3,1]  R885      3.0472838878631592e-01
    z[1,3,1]  R886      2.2483146190643311e-01
    z[1,3,1]  R887      3.8899382948875427e-01
    z[1,3,1]  R888      3.7241196632385254e-01
    z[1,3,1]  R889      -0.104210764169693
    z[1,3,1]  R890      3.5648781061172485e-01
    z[1,3,1]  R891      -1.7990475893020630e-01
    z[1,3,1]  R892      3.1396555900573730e-01
    z[1,3,1]  R893      1.3082636892795563e-01
    z[1,3,1]  R894      -1.2762185931205750e-01
    z[1,3,1]  R895      1.8831813707947731e-02
    z[1,3,1]  R896      6.2494814395904541e-01
    z[1,3,1]  R897      2.4925498664379120e-01
    z[1,3,1]  R898      3.7488889694213867e-01
    z[1,3,1]  R899      2.4902611970901489e-01
    z[1,3,1]  R900      3.6701738834381104e-01
    z[1,3,1]  R901      -2.0082278177142143e-02
    z[1,3,1]  R902      6.5392822027206421e-01
    z[1,3,1]  R903      -1.8960449844598770e-02
    z[1,3,1]  R904      -0.465471476316452
    z[1,3,1]  R905      2.8015002608299255e-01
    z[1,3,1]  R906      8.0995447933673859e-02
    z[1,3,1]  R907      2.8088155388832092e-01
    z[1,3,1]  R908      -2.1294054388999939e-01
    z[1,3,1]  R909      3.1275704503059387e-01
    z[1,3,1]  R910      -2.3235730826854706e-01
    z[1,3,1]  R911      4.5602791011333466e-02
    z[1,3,1]  R912      2.3990756273269653e-01
    z[1,3,1]  R913      4.3577298521995544e-01
    z[1,3,1]  R914      -4.4554811716079712e-01
    z[1,3,1]  R915      0.307367742061615
    z[1,3,1]  R916      -3.9569985866546631e-01
    z[1,3,1]  R917      -3.2336461544036865e-01
    z[1,3,1]  R918      -1.7215554416179657e-01
    z[1,3,1]  R919      3.6054009199142456e-01
    z[1,3,1]  R920      3.6119109392166138e-01
    z[1,3,1]  R921      -2.3140546679496765e-01
    z[1,3,1]  R922      -4.6828567981719971e-01
    z[1,3,1]  R923      6.0571485757827759e-01
    z[1,3,1]  R924      -2.0369865000247955e-01
    z[1,3,1]  R925      3.2805186510086060e-01
    z[1,3,1]  R926      -7.6862359046936035e-01
    z[1,3,1]  R927      -2.4225763976573944e-01
    z[1,3,1]  R928      -7.9465228319168091e-01
    z[1,3,1]  R929      2.3313266038894653e-01
    z[1,3,1]  R930      -1.5226179733872414e-02
    z[1,3,1]  R931      -1.2230127304792404e-01
    z[1,3,1]  R932      1.9350171089172363e-01
    z[1,3,1]  R933      -4.2640250921249390e-01
    z[1,3,1]  R934      6.2665677070617676e-01
    z[1,3,1]  R935      -2.2087098658084869e-01
    z[1,3,1]  R936      3.4668478369712830e-01
    z[1,3,1]  R937      -7.0672088861465454e-01
    z[1,3,1]  R938      -8.5525280237197876e-01
    z[1,3,2]  R13       -1
    z[1,3,2]  R31       1
    z[1,3,2]  R819      -1
    z[1,3,2]  R820      1
    z[1,3,2]  R829      -2.4280132353305817e-01
    z[1,3,2]  R830      -3.8911259174346924e-01
    z[1,3,2]  R831      3.3616498112678528e-01
    z[1,3,2]  R832      1.9201441109180450e-01
    z[1,3,2]  R833      -0.211082324385643
    z[1,3,2]  R834      5.0174808502197266e-01
    z[1,3,2]  R835      9.4765760004520416e-02
    z[1,3,2]  R836      -1.2549269199371338e-01
    z[1,3,2]  R837      5.6650322675704956e-01
    z[1,3,2]  R838      2.4162469804286957e-01
    z[1,3,2]  R839      1.5392532944679260e-01
    z[1,3,2]  R840      -1.1897242814302444e-01
    z[1,3,2]  R841      0.45625039935112
    z[1,3,2]  R842      -1.4246310293674469e-01
    z[1,3,2]  R843      1.6092897951602936e-01
    z[1,3,2]  R844      2.2043561935424805e-01
    z[1,3,2]  R845      1.3189366459846497e-01
    z[1,3,2]  R846      -3.7291178107261658e-01
    z[1,3,2]  R847      -5.5576390027999878e-01
    z[1,3,2]  R848      -5.5670505762100220e-01
    z[1,3,2]  R849      -0.495866984128952
    z[1,3,2]  R850      -2.7213424444198608e-01
    z[1,3,2]  R851      -4.5838269591331482e-01
    z[1,3,2]  R852      -1.9348157942295074e-01
    z[1,3,2]  R853      -2.4002535641193390e-01
    z[1,3,2]  R854      4.5512345433235168e-01
    z[1,3,2]  R855      -5.1767438650131226e-01
    z[1,3,2]  R856      -1.0964465141296387e-01
    z[1,3,2]  R857      -5.0401580333709717e-01
    z[1,3,2]  R858      -5.6539905071258545e-01
    z[1,3,2]  R859      5.5173772573471069e-01
    z[1,3,2]  R860      5.5275803804397583e-01
    z[1,3,2]  R861      5.4552298039197922e-02
    z[1,3,2]  R862      1.4933989942073822e-01
    z[1,3,2]  R863      5.3784090280532837e-01
    z[1,3,2]  R864      0.512365460395813
    z[1,3,2]  R865      0.704929530620575
    z[1,3,2]  R866      5.2729690074920654e-01
    z[1,3,2]  R867      7.4078536033630371e-01
    z[1,3,2]  R868      -0.0430370569229126
    z[1,3,2]  R869      4.1135424375534058e-01
    z[1,3,2]  R870      2.5374436378479004e-01
    z[1,3,2]  R871      2.1532240509986877e-01
    z[1,3,2]  R872      -5.2365595102310181e-01
    z[1,3,2]  R873      2.4641571938991547e-01
    z[1,3,2]  R874      -2.0875306427478790e-01
    z[1,3,2]  R875      -1.6267299652099609e-01
    z[1,3,2]  R876      -4.1821032762527466e-01
    z[1,3,2]  R877      -2.5715437531471252e-01
    z[1,3,2]  R878      -1.4770062267780304e-01
    z[1,3,2]  R879      7.1830958127975464e-01
    z[1,3,2]  R880      4.5473849773406982e-01
    z[1,3,2]  R881      4.6605947613716125e-01
    z[1,3,2]  R882      3.6716330051422119e-01
    z[1,3,2]  R883      3.0969995260238647e-01
    z[1,3,2]  R884      -6.9029003381729126e-01
    z[1,3,2]  R885      3.0808454751968384e-01
    z[1,3,2]  R886      -5.3008008003234863e-01
    z[1,3,2]  R887      4.1050696372985840e-01
    z[1,3,2]  R888      -1.5325441956520081e-01
    z[1,3,2]  R889      4.5818847417831421e-01
    z[1,3,2]  R890      4.3385028839111328e-01
    z[1,3,2]  R891      2.0720952749252319e-01
    z[1,3,2]  R892      6.1554181575775146e-01
    z[1,3,2]  R893      -1.8043044209480286e-01
    z[1,3,2]  R894      5.0926405191421509e-01
    z[1,3,2]  R895      0.601693332195282
    z[1,3,2]  R896      3.4847456216812134e-01
    z[1,3,2]  R897      1.5690174698829651e-01
    z[1,3,2]  R898      2.4623838067054749e-01
    z[1,3,2]  R899      4.4899916648864746e-01
    z[1,3,2]  R900      -2.7870857715606689e-01
    z[1,3,2]  R901      8.3460563421249390e-01
    z[1,3,2]  R902      -1.3503019511699677e-01
    z[1,3,2]  R903      0.885668933391571
    z[1,3,2]  R904      4.7445856034755707e-02
    z[1,3,2]  R905      7.3200774192810059e-01
    z[1,3,2]  R906      2.9898330569267273e-01
    z[1,3,2]  R907      4.1195716708898544e-02
    z[1,3,2]  R908      1.0171540081501007e-01
    z[1,3,2]  R909      0.672829806804657
    z[1,3,2]  R910      3.6227068305015564e-01
    z[1,3,2]  R911      3.1364640593528748e-01
    z[1,3,2]  R912      4.2406827211380005e-01
    z[1,3,2]  R913      4.3404987454414368e-01
    z[1,3,2]  R914      -6.8644896149635315e-02
    z[1,3,2]  R915      0.256710946559906
    z[1,3,2]  R916      -1.0159547626972198e-01
    z[1,3,2]  R917      -5.5583781003952026e-01
    z[1,3,2]  R918      -4.9035421013832092e-01
    z[1,3,2]  R919      6.7314106225967407e-01
    z[1,3,2]  R920      4.7472253441810608e-01
    z[1,3,2]  R921      1.0133743286132812e-01
    z[1,3,2]  R922      2.0631836354732513e-01
    z[1,3,2]  R923      5.0050681829452515e-01
    z[1,3,2]  R924      -2.1060007810592651e-01
    z[1,3,2]  R925      6.1223471164703369e-01
    z[1,3,2]  R926      5.7189010083675385e-02
    z[1,3,2]  R927      2.2347699105739594e-01
    z[1,3,2]  R928      -1.4080753922462463e-01
    z[1,3,2]  R929      -2.3597948253154755e-01
    z[1,3,2]  R930      5.6909757852554321e-01
    z[1,3,2]  R931      -4.2687880992889404e-01
    z[1,3,2]  R932      4.4247588515281677e-01
    z[1,3,2]  R933      -3.9816579222679138e-01
    z[1,3,2]  R934      4.3460118770599365e-01
    z[1,3,2]  R935      -6.5257710218429565e-01
    z[1,3,2]  R936      -4.8077547550201416e-01
    z[1,3,2]  R937      -1.4383430778980255e-01
    z[1,3,2]  R938      3.4261253476142883e-01
    z[1,3,3]  R14       -1
    z[1,3,3]  R32       1
    z[1,3,3]  R821      -1
    z[1,3,3]  R822      1
    z[1,3,3]  R829      6.9761854410171509e-01
    z[1,3,3]  R830      7.0579981803894043e-01
    z[1,3,3]  R831      7.0265442132949829e-01
    z[1,3,3]  R832      8.3274716138839722e-01
    z[1,3,3]  R833      8.3575522899627686e-01
    z[1,3,3]  R834      6.8083167076110840e-01
    z[1,3,3]  R835      4.4157034158706665e-01
    z[1,3,3]  R836      -1.1593621969223022e-01
    z[1,3,3]  R837      -0.0922110453248024
    z[1,3,3]  R838      -0.0977182611823082
    z[1,3,3]  R839      -8.8844668865203857e-01
    z[1,3,3]  R840      -7.7384406328201294e-01
    z[1,3,3]  R841      -5.3013539314270020e-01
    z[1,3,3]  R842      -4.3950146436691284e-01
    z[1,3,3]  R843      -3.7368568778038025e-01
    z[1,3,3]  R844      -4.1142952442169189e-01
    z[1,3,3]  R845      -3.6310148239135742e-01
    z[1,3,3]  R846      -2.4321369826793671e-01
    z[1,3,3]  R847      -2.4231983721256256e-01
    z[1,3,3]  R848      -2.5232541561126709e-01
    z[1,3,3]  R849      3.7420988082885742e-01
    z[1,3,3]  R850      6.7907691001892090e-01
    z[1,3,3]  R851      4.3427556753158569e-01
    z[1,3,3]  R852      5.0297158956527710e-01
    z[1,3,3]  R853      6.7577290534973145e-01
    z[1,3,3]  R854      -2.4416683614253998e-01
    z[1,3,3]  R855      1.3043354451656342e-01
    z[1,3,3]  R856      2.3145893216133118e-01
    z[1,3,3]  R857      3.4173694252967834e-01
    z[1,3,3]  R858      3.4725794196128845e-01
    z[1,3,3]  R859      -3.9352294057607651e-02
    z[1,3,3]  R860      -2.0397897064685822e-01
    z[1,3,3]  R861      1.7381841316819191e-02
    z[1,3,3]  R862      -1.0820031911134720e-01
    z[1,3,3]  R863      -2.0943066477775574e-01
    z[1,3,3]  R864      -2.5197410583496094e-01
    z[1,3,3]  R865      2.8585383668541908e-02
    z[1,3,3]  R866      -3.0092450976371765e-01
    z[1,3,3]  R867      -4.6742090582847595e-01
    z[1,3,3]  R868      -3.0300248414278030e-02
    z[1,3,3]  R869      -6.7259013652801514e-01
    z[1,3,3]  R870      -5.8234238624572754e-01
    z[1,3,3]  R871      -4.4266286492347717e-01
    z[1,3,3]  R872      6.7975777387619019e-01
    z[1,3,3]  R873      -5.2452695369720459e-01
    z[1,3,3]  R874      -1.4348666369915009e-01
    z[1,3,3]  R875      -8.2589067518711090e-02
    z[1,3,3]  R876      -2.4972349405288696e-01
    z[1,3,3]  R877      -1.6817671060562134e-01
    z[1,3,3]  R878      -2.3673868179321289e-01
    z[1,3,3]  R879      -6.9535695016384125e-02
    z[1,3,3]  R880      -2.5063166022300720e-01
    z[1,3,3]  R881      -2.6369345188140869e-01
    z[1,3,3]  R882      -3.9013007283210754e-01
    z[1,3,3]  R883      -3.8972941040992737e-01
    z[1,3,3]  R884      2.8705161809921265e-01
    z[1,3,3]  R885      7.6106287539005280e-02
    z[1,3,3]  R886      5.8734875917434692e-01
    z[1,3,3]  R887      4.8898744583129883e-01
    z[1,3,3]  R888      -4.2992007732391357e-01
    z[1,3,3]  R889      -4.4301679730415344e-01
    z[1,3,3]  R890      -1.8483416736125946e-01
    z[1,3,3]  R891      -0.665672242641449
    z[1,3,3]  R892      -4.3565583229064941e-01
    z[1,3,3]  R893      -4.9580168724060059e-01
    z[1,3,3]  R894      1.5340850688517094e-02
    z[1,3,3]  R895      -2.3656207323074341e-01
    z[1,3,3]  R896      4.2897865176200867e-01
    z[1,3,3]  R897      2.7163015678524971e-02
    z[1,3,3]  R898      -1.9019616767764091e-02
    z[1,3,3]  R899      -3.0038860440254211e-01
    z[1,3,3]  R900      -0.324074387550354
    z[1,3,3]  R901      -1.2518766522407532e-01
    z[1,3,3]  R902      7.3851294815540314e-02
    z[1,3,3]  R903      -2.6993727311491966e-02
    z[1,3,3]  R904      -2.3950931429862976e-01
    z[1,3,3]  R905      -8.0155604518949986e-04
    z[1,3,3]  R906      -6.5887951850891113e-01
    z[1,3,3]  R907      -2.7802556753158569e-01
    z[1,3,3]  R908      -9.0073829889297485e-01
    z[1,3,3]  R909      -3.9974990487098694e-01
    z[1,3,3]  R910      -7.0483297109603882e-01
    z[1,3,3]  R911      -0.636849045753479
    z[1,3,3]  R912      1.4090560376644135e-01
    z[1,3,3]  R913      4.3926298618316650e-01
    z[1,3,3]  R914      1.7935261130332947e-01
    z[1,3,3]  R915      -4.4287670403718948e-02
    z[1,3,3]  R916      -1.9506633281707764e-01
    z[1,3,3]  R917      4.2763477563858032e-01
    z[1,3,3]  R918      2.4731636047363281e-01
    z[1,3,3]  R919      -4.1987213492393494e-01
    z[1,3,3]  R920      -5.4470568895339966e-01
    z[1,3,3]  R921      -2.0091973245143890e-01
    z[1,3,3]  R922      5.7016885280609131e-01
    z[1,3,3]  R923      1.8288058042526245e-01
    z[1,3,3]  R924      5.7683402299880981e-01
    z[1,3,3]  R925      9.9328316748142242e-02
    z[1,3,3]  R926      -2.7665802836418152e-01
    z[1,3,3]  R927      -2.5349313020706177e-01
    z[1,3,3]  R928      -3.3209922909736633e-01
    z[1,3,3]  R929      -5.1900601387023926e-01
    z[1,3,3]  R930      -3.1045249104499817e-01
    z[1,3,3]  R931      3.1423109769821167e-01
    z[1,3,3]  R932      2.1137748658657074e-01
    z[1,3,3]  R933      2.8813469409942627e-01
    z[1,3,3]  R934      4.5024354010820389e-02
    z[1,3,3]  R935      5.6768339872360229e-01
    z[1,3,3]  R936      5.4710513353347778e-01
    z[1,3,3]  R937      2.6591575145721436e-01
    z[1,3,3]  R938      -1.4462395012378693e-01
    z[1,3,4]  R15       -1
    z[1,3,4]  R33       1
    z[1,3,4]  R823      -1
    z[1,3,4]  R824      1
    z[1,3,4]  R829      3.9406582713127136e-01
    z[1,3,4]  R830      4.5046284794807434e-01
    z[1,3,4]  R831      0.486801415681839
    z[1,3,4]  R832      -2.4763226509094238e-01
    z[1,3,4]  R833      -1.4636451005935669e-01
    z[1,3,4]  R834      4.3101231567561626e-03
    z[1,3,4]  R835      4.7685602307319641e-01
    z[1,3,4]  R836      -4.4916570186614990e-03
    z[1,3,4]  R837      -3.2263353466987610e-01
    z[1,3,4]  R838      -2.9715770483016968e-01
    z[1,3,4]  R839      1.1608657240867615e-01
    z[1,3,4]  R840      -4.9887317419052124e-01
    z[1,3,4]  R841      5.0323802232742310e-01
    z[1,3,4]  R842      -0.346293181180954
    z[1,3,4]  R843      -4.7331359982490540e-01
    z[1,3,4]  R844      -3.8748362660408020e-01
    z[1,3,4]  R845      -5.0233131647109985e-01
    z[1,3,4]  R846      -1.5805552899837494e-01
    z[1,3,4]  R847      -0.0805695503950119
    z[1,3,4]  R848      -2.3558795452117920e-01
    z[1,3,4]  R849      -4.6652253717184067e-02
    z[1,3,4]  R850      -2.4003187194466591e-02
    z[1,3,4]  R851      4.5995318889617920e-01
    z[1,3,4]  R852      2.9704380035400391e-01
    z[1,3,4]  R853      2.0661835372447968e-01
    z[1,3,4]  R854      -2.1915614604949951e-01
    z[1,3,4]  R855      1.3381545245647430e-01
    z[1,3,4]  R856      -1.3279208540916443e-01
    z[1,3,4]  R857      -1.2246138602495193e-01
    z[1,3,4]  R858      3.7044730782508850e-01
    z[1,3,4]  R859      0.0644272193312645
    z[1,3,4]  R860      1.7407299578189850e-01
    z[1,3,4]  R861      -1.0715722292661667e-01
    z[1,3,4]  R862      -1.4778789877891541e-01
    z[1,3,4]  R863      -1.4112314581871033e-01
    z[1,3,4]  R864      2.2384163737297058e-01
    z[1,3,4]  R865      1.7793895304203033e-01
    z[1,3,4]  R866      4.4721037149429321e-01
    z[1,3,4]  R867      -0.0606394037604332
    z[1,3,4]  R868      1.2662783265113831e-01
    z[1,3,4]  R869      1.7410339415073395e-01
    z[1,3,4]  R870      3.4294697642326355e-01
    z[1,3,4]  R871      0.0515059269964695
    z[1,3,4]  R872      -3.0618287622928619e-02
    z[1,3,4]  R873      1.1818935722112656e-01
    z[1,3,4]  R874      -2.5935724377632141e-01
    z[1,3,4]  R875      -7.0793621242046356e-02
    z[1,3,4]  R876      -2.3014941811561584e-01
    z[1,3,4]  R877      -2.3294666409492493e-01
    z[1,3,4]  R878      2.0637065172195435e-01
    z[1,3,4]  R879      -4.1234114766120911e-01
    z[1,3,4]  R880      4.6587803959846497e-01
    z[1,3,4]  R881      0.31876340508461
    z[1,3,4]  R882      -1.3341650366783142e-01
    z[1,3,4]  R883      -4.1229271888732910e-01
    z[1,3,4]  R884      2.4737310409545898e-01
    z[1,3,4]  R885      0.0967501625418663
    z[1,3,4]  R886      4.6853196620941162e-01
    z[1,3,4]  R887      3.2393902540206909e-01
    z[1,3,4]  R888      1.9697868824005127e-01
    z[1,3,4]  R889      2.0611914992332458e-01
    z[1,3,4]  R890      -2.7662146091461182e-01
    z[1,3,4]  R891      -2.1774184703826904e-01
    z[1,3,4]  R892      -1.7755937576293945e-01
    z[1,3,4]  R893      -6.5851235389709473e-01
    z[1,3,4]  R894      -6.3356764614582062e-02
    z[1,3,4]  R895      -9.6845224499702454e-02
    z[1,3,4]  R896      2.3995047807693481e-01
    z[1,3,4]  R897      -1.2424138188362122e-01
    z[1,3,4]  R898      1.5257167816162109e-01
    z[1,3,4]  R899      -8.3643466234207153e-02
    z[1,3,4]  R900      -1.0962177067995071e-01
    z[1,3,4]  R901      -3.1764388084411621e-01
    z[1,3,4]  R902      1.7952004075050354e-01
    z[1,3,4]  R903      3.9193700999021530e-02
    z[1,3,4]  R904      1.7649734020233154e-01
    z[1,3,4]  R905      0.24935382604599
    z[1,3,4]  R906      8.4604196250438690e-02
    z[1,3,4]  R907      -2.7523839473724365e-01
    z[1,3,4]  R908      2.5690355896949768e-01
    z[1,3,4]  R909      1.5428103506565094e-01
    z[1,3,4]  R910      1.6195248812437057e-02
    z[1,3,4]  R911      8.7646394968032837e-02
    z[1,3,4]  R912      2.2998262941837311e-01
    z[1,3,4]  R913      -8.0991901457309723e-02
    z[1,3,4]  R914      1.5155556797981262e-01
    z[1,3,4]  R915      -6.2881387770175934e-02
    z[1,3,4]  R916      -1.9795902073383331e-01
    z[1,3,4]  R917      -2.9808852076530457e-01
    z[1,3,4]  R918      -2.7864545583724976e-01
    z[1,3,4]  R919      -5.4691050201654434e-02
    z[1,3,4]  R920      -1.0489811003208160e-01
    z[1,3,4]  R921      -2.9336953163146973e-01
    z[1,3,4]  R922      2.2056722640991211e-01
    z[1,3,4]  R923      9.9898435175418854e-02
    z[1,3,4]  R924      -4.8859912157058716e-01
    z[1,3,4]  R925      3.5315670073032379e-02
    z[1,3,4]  R926      -2.1309521794319153e-01
    z[1,3,4]  R927      8.6106121540069580e-01
    z[1,3,4]  R928      3.3534392714500427e-01
    z[1,3,4]  R929      -3.8835567235946655e-01
    z[1,3,4]  R930      5.3314459323883057e-01
    z[1,3,4]  R931      -2.9568953439593315e-02
    z[1,3,4]  R932      -1.4985139667987823e-01
    z[1,3,4]  R933      0.320017009973526
    z[1,3,4]  R934      3.4514892101287842e-01
    z[1,3,4]  R935      -1.2468189746141434e-01
    z[1,3,4]  R936      3.4777253866195679e-02
    z[1,3,4]  R937      0.360971599817276
    z[1,3,4]  R938      -1.2381967157125473e-01
    z[1,3,5]  R16       -1
    z[1,3,5]  R34       1
    z[1,3,5]  R825      -1
    z[1,3,5]  R826      1
    z[1,3,5]  R829      -3.6901223659515381e-01
    z[1,3,5]  R830      -1.1600410193204880e-01
    z[1,3,5]  R831      3.2378707081079483e-02
    z[1,3,5]  R832      -2.1641814708709717e-01
    z[1,3,5]  R833      -2.5121828913688660e-01
    z[1,3,5]  R834      -4.3281629681587219e-01
    z[1,3,5]  R835      -6.6607022285461426e-01
    z[1,3,5]  R836      2.8251004219055176e-01
    z[1,3,5]  R837      -2.8031954169273376e-01
    z[1,3,5]  R838      -1.6167476773262024e-01
    z[1,3,5]  R839      -8.3953499794006348e-02
    z[1,3,5]  R840      -3.1239360570907593e-01
    z[1,3,5]  R841      2.3754407465457916e-01
    z[1,3,5]  R842      7.4026662111282349e-01
    z[1,3,5]  R843      6.6615206003189087e-01
    z[1,3,5]  R844      6.8987190723419189e-01
    z[1,3,5]  R845      7.4313873052597046e-01
    z[1,3,5]  R846      2.6337283849716187e-01
    z[1,3,5]  R847      3.8477602601051331e-01
    z[1,3,5]  R848      2.8918406367301941e-01
    z[1,3,5]  R849      -4.4074233621358871e-02
    z[1,3,5]  R850      -1.4495445787906647e-01
    z[1,3,5]  R851      -6.9058477878570557e-02
    z[1,3,5]  R852      -2.8482276201248169e-01
    z[1,3,5]  R853      1.8145045638084412e-01
    z[1,3,5]  R854      1.5429614484310150e-01
    z[1,3,5]  R855      -1.0010101646184921e-01
    z[1,3,5]  R856      -1.0949768126010895e-01
    z[1,3,5]  R857      -3.4235006570816040e-01
    z[1,3,5]  R858      1.0637746751308441e-01
    z[1,3,5]  R859      2.8287851810455322e-01
    z[1,3,5]  R860      2.0069922506809235e-01
    z[1,3,5]  R861      2.3118227720260620e-01
    z[1,3,5]  R862      -0.075913205742836
    z[1,3,5]  R863      0.535001814365387
    z[1,3,5]  R864      1.0893454402685165e-01
    z[1,3,5]  R865      2.9696938395500183e-01
    z[1,3,5]  R866      4.0769883990287781e-01
    z[1,3,5]  R867      -4.6716742217540741e-03
    z[1,3,5]  R868      2.5278747081756592e-01
    z[1,3,5]  R869      4.4447210431098938e-01
    z[1,3,5]  R870      5.4762428998947144e-01
    z[1,3,5]  R871      6.3761627674102783e-01
    z[1,3,5]  R872      -2.6111018657684326e-01
    z[1,3,5]  R873      6.4481425285339355e-01
    z[1,3,5]  R874      -3.5370582342147827e-01
    z[1,3,5]  R875      -4.5468306541442871e-01
    z[1,3,5]  R876      -0.252608984708786
    z[1,3,5]  R877      -5.0605303049087524e-01
    z[1,3,5]  R878      -4.5991146564483643e-01
    z[1,3,5]  R879      4.8409852385520935e-01
    z[1,3,5]  R880      0.587566614151001
    z[1,3,5]  R881      6.3206166028976440e-01
    z[1,3,5]  R882      5.8540689945220947e-01
    z[1,3,5]  R883      5.7594513893127441e-01
    z[1,3,5]  R884      -2.8168687224388123e-01
    z[1,3,5]  R885      5.8635663986206055e-01
    z[1,3,5]  R886      -1.1911985278129578e-01
    z[1,3,5]  R887      1.7296472191810608e-01
    z[1,3,5]  R888      -2.8461429476737976e-01
    z[1,3,5]  R889      5.6511014699935913e-01
    z[1,3,5]  R890      2.6678198575973511e-01
    z[1,3,5]  R891      4.8890298604965210e-01
    z[1,3,5]  R892      -0.0569256953895092
    z[1,3,5]  R893      -2.1289469301700592e-01
    z[1,3,5]  R894      2.3178681731224060e-01
    z[1,3,5]  R895      3.6339035630226135e-01
    z[1,3,5]  R896      4.3757492303848267e-01
    z[1,3,5]  R897      7.4298632144927979e-01
    z[1,3,5]  R898      5.8118617534637451e-01
    z[1,3,5]  R899      3.7851619720458984e-01
    z[1,3,5]  R900      -2.1907933056354523e-01
    z[1,3,5]  R901      2.9881912469863892e-01
    z[1,3,5]  R902      1.2832273729145527e-02
    z[1,3,5]  R903      3.4379380941390991e-01
    z[1,3,5]  R904      5.8337718248367310e-01
    z[1,3,5]  R905      5.1027429103851318e-01
    z[1,3,5]  R906      4.4948694109916687e-01
    z[1,3,5]  R907      1.1982368677854538e-01
    z[1,3,5]  R908      -0.0586259625852108
    z[1,3,5]  R909      6.0723256319761276e-02
    z[1,3,5]  R910      2.1167193353176117e-01
    z[1,3,5]  R911      5.9822231531143188e-02
    z[1,3,5]  R912      6.9899767637252808e-01
    z[1,3,5]  R913      1.0365897417068481e-01
    z[1,3,5]  R914      4.8748105764389038e-01
    z[1,3,5]  R915      8.9537531137466431e-01
    z[1,3,5]  R916      6.8468856811523438e-01
    z[1,3,5]  R917      -4.6031859517097473e-01
    z[1,3,5]  R918      -5.5460166931152344e-01
    z[1,3,5]  R919      2.7098900079727173e-01
    z[1,3,5]  R920      5.4674917459487915e-01
    z[1,3,5]  R921      -5.4734289646148682e-01
    z[1,3,5]  R922      4.1980616748332977e-02
    z[1,3,5]  R923      -1.3455897569656372e-01
    z[1,3,5]  R924      0.287685364484787
    z[1,3,5]  R925      6.1171799898147583e-01
    z[1,3,5]  R926      -1.0330747067928314e-01
    z[1,3,5]  R927      -1.2625804543495178e-01
    z[1,3,5]  R928      -1.2806738913059235e-01
    z[1,3,5]  R929      -2.3561830818653107e-01
    z[1,3,5]  R930      2.7680492401123047e-01
    z[1,3,5]  R931      -6.6292285919189453e-01
    z[1,3,5]  R932      5.4928410053253174e-01
    z[1,3,5]  R933      4.1932541131973267e-01
    z[1,3,5]  R934      0.254957914352417
    z[1,3,5]  R935      -7.9919271171092987e-02
    z[1,3,5]  R936      -4.2730411887168884e-01
    z[1,3,5]  R937      2.8728953003883362e-01
    z[1,3,5]  R938      1.8982259929180145e-01
    z[1,3,6]  R17       -1
    z[1,3,6]  R35       1
    z[1,3,6]  R827      -1
    z[1,3,6]  R828      1
    z[1,3,6]  R829      1.5975877642631531e-01
    z[1,3,6]  R830      1.5552735328674316e-01
    z[1,3,6]  R831      -2.1702274680137634e-02
    z[1,3,6]  R832      -2.1303531527519226e-01
    z[1,3,6]  R833      2.3531040549278259e-01
    z[1,3,6]  R834      -1.6468851268291473e-01
    z[1,3,6]  R835      9.1937407851219177e-03
    z[1,3,6]  R836      1.1114278435707092e-01
    z[1,3,6]  R837      3.0565917491912842e-02
    z[1,3,6]  R838      2.5358486175537109e-01
    z[1,3,6]  R839      -2.2230693697929382e-01
    z[1,3,6]  R840      -7.8097254037857056e-02
    z[1,3,6]  R841      -0.262433797121048
    z[1,3,6]  R842      0.0954258143901825
    z[1,3,6]  R843      2.6463833451271057e-01
    z[1,3,6]  R844      1.6134175658226013e-01
    z[1,3,6]  R845      -2.0603444427251816e-02
    z[1,3,6]  R846      9.7397871315479279e-02
    z[1,3,6]  R847      -2.3673607409000397e-01
    z[1,3,6]  R848      2.3702910542488098e-01
    z[1,3,6]  R849      -1.5861645340919495e-01
    z[1,3,6]  R850      1.9234988093376160e-01
    z[1,3,6]  R851      -1.5485175885260105e-02
    z[1,3,6]  R852      1.6566525399684906e-01
    z[1,3,6]  R853      -2.8882148861885071e-01
    z[1,3,6]  R854      -4.2173019051551819e-01
    z[1,3,6]  R855      1.8046455085277557e-01
    z[1,3,6]  R856      -2.7422466874122620e-01
    z[1,3,6]  R857      1.2597066164016724e-01
    z[1,3,6]  R858      -3.1372427940368652e-01
    z[1,3,6]  R859      1.4145767688751221e-01
    z[1,3,6]  R860      -7.0472881197929382e-02
    z[1,3,6]  R861      6.9888085126876831e-02
    z[1,3,6]  R862      2.7485650032758713e-02
    z[1,3,6]  R863      1.8679074943065643e-01
    z[1,3,6]  R864      -2.7392706274986267e-01
    z[1,3,6]  R865      5.2603948116302490e-01
    z[1,3,6]  R866      2.9290032386779785e-01
    z[1,3,6]  R867      3.8864722847938538e-01
    z[1,3,6]  R868      -2.4102360010147095e-01
    z[1,3,6]  R869      -2.1817234158515930e-01
    z[1,3,6]  R870      -1.9706779718399048e-01
    z[1,3,6]  R871      -1.3251727819442749e-01
    z[1,3,6]  R872      -1.6446286439895630e-01
    z[1,3,6]  R873      2.6247581839561462e-01
    z[1,3,6]  R874      4.5745734125375748e-02
    z[1,3,6]  R875      2.3047868907451630e-01
    z[1,3,6]  R876      -5.9881657361984253e-02
    z[1,3,6]  R877      -9.4336703419685364e-02
    z[1,3,6]  R878      5.8939591050148010e-02
    z[1,3,6]  R879      -1.5689672902226448e-02
    z[1,3,6]  R880      -1.8470782786607742e-02
    z[1,3,6]  R881      4.1349419951438904e-01
    z[1,3,6]  R882      4.8553115129470825e-01
    z[1,3,6]  R883      1.9763223826885223e-01
    z[1,3,6]  R884      5.5701290257275105e-03
    z[1,3,6]  R885      -0.57218337059021
    z[1,3,6]  R886      1.4964535832405090e-01
    z[1,3,6]  R887      1.2106354348361492e-02
    z[1,3,6]  R888      -2.5076735019683838e-01
    z[1,3,6]  R889      2.1989084780216217e-01
    z[1,3,6]  R890      -2.6869857311248779e-01
    z[1,3,6]  R891      -2.6428046822547913e-01
    z[1,3,6]  R892      1.2014728784561157e-01
    z[1,3,6]  R893      -4.5258617401123047e-01
    z[1,3,6]  R894      4.2708730697631836e-01
    z[1,3,6]  R895      6.5108686685562134e-01
    z[1,3,6]  R896      0.0421893447637558
    z[1,3,6]  R897      -3.9146393537521362e-01
    z[1,3,6]  R898      -4.8854342103004456e-01
    z[1,3,6]  R899      -2.7119457721710205e-01
    z[1,3,6]  R900      -6.6284263134002686e-01
    z[1,3,6]  R901      9.0074427425861359e-02
    z[1,3,6]  R902      -9.5177195966243744e-02
    z[1,3,6]  R903      -2.7251252532005310e-01
    z[1,3,6]  R904      -2.9646283388137817e-01
    z[1,3,6]  R905      2.4682195484638214e-01
    z[1,3,6]  R906      -5.0488543510437012e-01
    z[1,3,6]  R907      -7.8267019987106323e-01
    z[1,3,6]  R908      2.8267474845051765e-02
    z[1,3,6]  R909      0.275452196598053
    z[1,3,6]  R910      -1.0823348909616470e-01
    z[1,3,6]  R911      -0.485553115606308
    z[1,3,6]  R912      3.1136220693588257e-01
    z[1,3,6]  R913      3.1912293285131454e-02
    z[1,3,6]  R914      9.7209677100181580e-02
    z[1,3,6]  R915      5.2639592438936234e-02
    z[1,3,6]  R916      4.7794154286384583e-01
    z[1,3,6]  R917      -9.5068022608757019e-02
    z[1,3,6]  R918      2.1829910576343536e-01
    z[1,3,6]  R919      8.0980263650417328e-02
    z[1,3,6]  R920      -1.9113582372665405e-01
    z[1,3,6]  R921      1.7105533182621002e-01
    z[1,3,6]  R922      -1.8997816741466522e-01
    z[1,3,6]  R923      -1.4648582041263580e-01
    z[1,3,6]  R924      9.8100811243057251e-02
    z[1,3,6]  R925      -3.3444008231163025e-01
    z[1,3,6]  R926      1.7640037834644318e-01
    z[1,3,6]  R927      2.6220846176147461e-01
    z[1,3,6]  R928      -1.7896692454814911e-01
    z[1,3,6]  R929      -2.0715422928333282e-01
    z[1,3,6]  R930      -2.8764620423316956e-01
    z[1,3,6]  R931      0.0504353865981102
    z[1,3,6]  R932      3.1272175908088684e-01
    z[1,3,6]  R933      2.3649330437183380e-01
    z[1,3,6]  R934      -2.9267209768295288e-01
    z[1,3,6]  R935      1.2861740775406361e-02
    z[1,3,6]  R936      3.5773232579231262e-01
    z[1,3,6]  R937      -7.4043780565261841e-02
    z[1,3,6]  R938      -3.3289868384599686e-02
    z[3,1,0]  R11       1
    z[3,1,0]  R29       -1
    z[3,1,0]  R939      -1
    z[3,1,0]  R940      1
    z[3,1,0]  R953      -7.3149889707565308e-01
    z[3,1,0]  R954      -4.6494984626770020e-01
    z[3,1,0]  R955      -5.5307424068450928e-01
    z[3,1,0]  R956      -6.4098256826400757e-01
    z[3,1,0]  R957      -4.6843826770782471e-01
    z[3,1,0]  R958      6.9115829467773438e-01
    z[3,1,0]  R959      -7.4154675006866455e-01
    z[3,1,0]  R960      -7.4062174558639526e-01
    z[3,1,0]  R961      -6.4864701032638550e-01
    z[3,1,0]  R962      -4.9817335605621338e-01
    z[3,1,0]  R963      2.0759922266006470e-01
    z[3,1,0]  R964      7.5057804584503174e-01
    z[3,1,0]  R965      -5.5326479673385620e-01
    z[3,1,0]  R966      -4.6926024556159973e-01
    z[3,1,0]  R967      3.9492759108543396e-01
    z[3,1,0]  R968      3.6992263793945312e-01
    z[3,1,0]  R969      2.0820197463035583e-01
    z[3,1,0]  R970      4.7991272062063217e-02
    z[3,1,0]  R971      1.1325430870056152e-01
    z[3,1,0]  R972      -5.5136060714721680e-01
    z[3,1,0]  R973      1.4380007982254028e-01
    z[3,1,0]  R974      3.2474073767662048e-01
    z[3,1,0]  R975      4.8364314436912537e-01
    z[3,1,0]  R976      -1.2364013493061066e-01
    z[3,1,0]  R977      2.0443318784236908e-01
    z[3,1,0]  R978      2.6790171861648560e-01
    z[3,1,0]  R979      1.7849633097648621e-01
    z[3,1,0]  R980      -0.0982329249382019
    z[3,1,0]  R981      1.9996878504753113e-01
    z[3,1,0]  R982      1.4755828678607941e-01
    z[3,1,0]  R983      1.6651113331317902e-01
    z[3,1,0]  R984      3.1945732235908508e-01
    z[3,1,0]  R985      1.4911076426506042e-01
    z[3,1,0]  R986      2.7498263120651245e-01
    z[3,1,0]  R987      3.6940187215805054e-01
    z[3,1,0]  R988      -4.3450483679771423e-01
    z[3,1,0]  R989      3.5477286577224731e-01
    z[3,1,0]  R990      -2.5958001613616943e-01
    z[3,1,0]  R991      5.5322623252868652e-01
    z[3,1,0]  R992      -6.8578487634658813e-01
    z[3,1,0]  R993      4.1563576459884644e-01
    z[3,1,0]  R994      6.5622836351394653e-01
    z[3,1,0]  R995      3.5397329926490784e-01
    z[3,1,0]  R996      5.3247994184494019e-01
    z[3,1,0]  R997      -1.4392016828060150e-01
    z[3,1,0]  R998      6.9569003582000732e-01
    z[3,1,0]  R999      1.2768420577049255e-01
    z[3,1,0]  R1000     2.3055291175842285e-01
    z[3,1,0]  R1001     0.437958300113678
    z[3,1,0]  R1002     4.4579499959945679e-01
    z[3,1,0]  R1003     6.4987319707870483e-01
    z[3,1,0]  R1004     -4.2804482579231262e-01
    z[3,1,0]  R1005     2.9841953516006470e-01
    z[3,1,0]  R1006     -7.1220767498016357e-01
    z[3,1,0]  R1007     1.4320926368236542e-01
    z[3,1,0]  R1008     5.1414996385574341e-01
    z[3,1,0]  R1009     4.6924032270908356e-02
    z[3,1,0]  R1010     7.6293818652629852e-02
    z[3,1,0]  R1011     3.7339481711387634e-01
    z[3,1,0]  R1012     -2.5049021840095520e-01
    z[3,1,0]  R1013     4.3164721131324768e-01
    z[3,1,0]  R1014     5.1107597351074219e-01
    z[3,1,0]  R1015     4.9693781137466431e-01
    z[3,1,0]  R1016     3.2298576831817627e-01
    z[3,1,0]  R1017     6.4064615964889526e-01
    z[3,1,0]  R1018     -7.0324313640594482e-01
    z[3,1,0]  R1019     1.7100089788436890e-01
    z[3,1,0]  R1020     -2.4214620888233185e-01
    z[3,1,0]  R1021     -3.0630099773406982e-01
    z[3,1,0]  R1022     -4.8566347360610962e-01
    z[3,1,0]  R1023     3.9700803160667419e-01
    z[3,1,0]  R1024     3.1685985624790192e-02
    z[3,1,0]  R1025     6.9347220659255981e-01
    z[3,1,0]  R1026     -5.7144099473953247e-01
    z[3,1,0]  R1027     5.4736936092376709e-01
    z[3,1,0]  R1028     -5.0030130147933960e-01
    z[3,1,0]  R1029     -1.4278750121593475e-01
    z[3,1,0]  R1030     -4.9214673042297363e-01
    z[3,1,0]  R1031     -3.1458348035812378e-02
    z[3,1,0]  R1032     -2.7843341231346130e-01
    z[3,1,0]  R1033     -6.0938209295272827e-01
    z[3,1,0]  R1034     3.6866092681884766e-01
    z[3,1,0]  R1035     -5.1106846332550049e-01
    z[3,1,0]  R1036     5.4783982038497925e-01
    z[3,1,0]  R1037     -4.9239164590835571e-01
    z[3,1,0]  R1038     3.8289362192153931e-01
    z[3,1,0]  R1039     -4.2543691396713257e-01
    z[3,1,0]  R1040     -1.9382968544960022e-01
    z[3,1,0]  R1041     -4.3683847784996033e-01
    z[3,1,0]  R1042     -2.7887448668479919e-01
    z[3,1,0]  R1043     -0.077597476541996
    z[3,1,0]  R1044     2.6397129893302917e-01
    z[3,1,0]  R1045     -7.9583726823329926e-02
    z[3,1,0]  R1046     2.7869397774338722e-02
    z[3,1,0]  R1047     -2.1747012436389923e-01
    z[3,1,0]  R1048     2.2852631285786629e-02
    z[3,1,0]  R1049     1.7220035195350647e-01
    z[3,1,0]  R1050     2.2474895417690277e-01
    z[3,1,0]  R1051     -3.9130559563636780e-01
    z[3,1,0]  R1052     -4.8110938072204590e-01
    z[3,1,0]  R1053     3.1633594632148743e-01
    z[3,1,0]  R1054     6.5092794829979539e-04
    z[3,1,0]  R1055     3.6189493536949158e-01
    z[3,1,0]  R1056     -2.3062512278556824e-01
    z[3,1,0]  R1057     1.5377096831798553e-01
    z[3,1,0]  R1058     -1.4678399264812469e-01
    z[3,1,0]  R1059     -1.1018574982881546e-01
    z[3,1,0]  R1060     -7.4105983972549438e-01
    z[3,1,0]  R1061     -3.4644496440887451e-01
    z[3,1,0]  R1062     -3.0616229772567749e-01
    z[3,1,1]  R12       1
    z[3,1,1]  R30       -1
    z[3,1,1]  R941      -1
    z[3,1,1]  R942      1
    z[3,1,1]  R953      -2.2296635806560516e-01
    z[3,1,1]  R954      -4.3592748045921326e-01
    z[3,1,1]  R955      -2.8077259659767151e-01
    z[3,1,1]  R956      -3.1925195455551147e-01
    z[3,1,1]  R957      -3.2749226689338684e-01
    z[3,1,1]  R958      -7.6501101255416870e-02
    z[3,1,1]  R959      -3.2344156503677368e-01
    z[3,1,1]  R960      -0.530152440071106
    z[3,1,1]  R961      -2.4570703506469727e-01
    z[3,1,1]  R962      -2.5414341688156128e-01
    z[3,1,1]  R963      7.3943096399307251e-01
    z[3,1,1]  R964      1.1804948002099991e-01
    z[3,1,1]  R965      7.8791356086730957e-01
    z[3,1,1]  R966      8.4700977802276611e-01
    z[3,1,1]  R967      4.1214641928672791e-01
    z[3,1,1]  R968      6.3256627321243286e-01
    z[3,1,1]  R969      2.4967686831951141e-01
    z[3,1,1]  R970      4.2082428932189941e-01
    z[3,1,1]  R971      2.5530877709388733e-01
    z[3,1,1]  R972      7.4511927366256714e-01
    z[3,1,1]  R973      -2.8681892156600952e-01
    z[3,1,1]  R974      -1.8626321852207184e-01
    z[3,1,1]  R975      -3.1145927309989929e-01
    z[3,1,1]  R976      3.9020884037017822e-01
    z[3,1,1]  R977      -3.5172438621520996e-01
    z[3,1,1]  R978      -0.818288266658783
    z[3,1,1]  R979      -8.1852716207504272e-01
    z[3,1,1]  R980      -7.9543876647949219e-01
    z[3,1,1]  R981      -0.739153265953064
    z[3,1,1]  R982      -8.0173850059509277e-01
    z[3,1,1]  R983      2.1644264459609985e-01
    z[3,1,1]  R984      2.5637015700340271e-01
    z[3,1,1]  R985      1.3758948445320129e-01
    z[3,1,1]  R986      -2.0281149446964264e-01
    z[3,1,1]  R987      -2.7382951974868774e-01
    z[3,1,1]  R988      3.3426719903945923e-01
    z[3,1,1]  R989      3.0472838878631592e-01
    z[3,1,1]  R990      2.2483146190643311e-01
    z[3,1,1]  R991      3.8899382948875427e-01
    z[3,1,1]  R992      3.7241196632385254e-01
    z[3,1,1]  R993      -0.104210764169693
    z[3,1,1]  R994      3.5648781061172485e-01
    z[3,1,1]  R995      -1.7990475893020630e-01
    z[3,1,1]  R996      3.1396555900573730e-01
    z[3,1,1]  R997      1.3082636892795563e-01
    z[3,1,1]  R998      -1.2762185931205750e-01
    z[3,1,1]  R999      1.8831813707947731e-02
    z[3,1,1]  R1000     6.2494814395904541e-01
    z[3,1,1]  R1001     2.4925498664379120e-01
    z[3,1,1]  R1002     3.7488889694213867e-01
    z[3,1,1]  R1003     2.4902611970901489e-01
    z[3,1,1]  R1004     3.6701738834381104e-01
    z[3,1,1]  R1005     -2.0082278177142143e-02
    z[3,1,1]  R1006     6.5392822027206421e-01
    z[3,1,1]  R1007     -1.8960449844598770e-02
    z[3,1,1]  R1008     -0.465471476316452
    z[3,1,1]  R1009     2.8015002608299255e-01
    z[3,1,1]  R1010     8.0995447933673859e-02
    z[3,1,1]  R1011     2.8088155388832092e-01
    z[3,1,1]  R1012     -2.1294054388999939e-01
    z[3,1,1]  R1013     3.1275704503059387e-01
    z[3,1,1]  R1014     -2.3235730826854706e-01
    z[3,1,1]  R1015     4.5602791011333466e-02
    z[3,1,1]  R1016     2.3990756273269653e-01
    z[3,1,1]  R1017     4.3577298521995544e-01
    z[3,1,1]  R1018     -4.4554811716079712e-01
    z[3,1,1]  R1019     0.307367742061615
    z[3,1,1]  R1020     -3.9569985866546631e-01
    z[3,1,1]  R1021     -3.2336461544036865e-01
    z[3,1,1]  R1022     -1.7215554416179657e-01
    z[3,1,1]  R1023     3.6054009199142456e-01
    z[3,1,1]  R1024     3.6119109392166138e-01
    z[3,1,1]  R1025     -2.3140546679496765e-01
    z[3,1,1]  R1026     -4.6828567981719971e-01
    z[3,1,1]  R1027     6.0571485757827759e-01
    z[3,1,1]  R1028     -2.0369865000247955e-01
    z[3,1,1]  R1029     3.2805186510086060e-01
    z[3,1,1]  R1030     -7.6862359046936035e-01
    z[3,1,1]  R1031     -2.4225763976573944e-01
    z[3,1,1]  R1032     -7.9465228319168091e-01
    z[3,1,1]  R1033     2.3313266038894653e-01
    z[3,1,1]  R1034     -1.5226179733872414e-02
    z[3,1,1]  R1035     -1.2230127304792404e-01
    z[3,1,1]  R1036     1.9350171089172363e-01
    z[3,1,1]  R1037     -4.2640250921249390e-01
    z[3,1,1]  R1038     6.2665677070617676e-01
    z[3,1,1]  R1039     -2.2087098658084869e-01
    z[3,1,1]  R1040     3.4668478369712830e-01
    z[3,1,1]  R1041     -7.0672088861465454e-01
    z[3,1,1]  R1042     -8.5525280237197876e-01
    z[3,1,1]  R1043     3.6245518922805786e-01
    z[3,1,1]  R1044     -2.0048640668392181e-01
    z[3,1,1]  R1045     3.8528078794479370e-01
    z[3,1,1]  R1046     3.3962216973304749e-01
    z[3,1,1]  R1047     -2.6412123441696167e-01
    z[3,1,1]  R1048     -2.6405319571495056e-01
    z[3,1,1]  R1049     -3.0863621830940247e-01
    z[3,1,1]  R1050     -9.1000741720199585e-01
    z[3,1,1]  R1051     -5.7779359817504883e-01
    z[3,1,1]  R1052     -7.2239577770233154e-01
    z[3,1,1]  R1053     -1.3021700084209442e-01
    z[3,1,1]  R1054     -1.8559944629669189e-01
    z[3,1,1]  R1055     -3.5733491182327271e-02
    z[3,1,1]  R1056     2.3735000193119049e-01
    z[3,1,1]  R1057     2.7018073201179504e-01
    z[3,1,1]  R1058     3.2937890291213989e-01
    z[3,1,1]  R1059     1.8331421911716461e-01
    z[3,1,1]  R1060     3.8572159409523010e-01
    z[3,1,1]  R1061     5.4935926198959351e-01
    z[3,1,1]  R1062     5.8083051443099976e-01
    z[3,1,2]  R13       1
    z[3,1,2]  R31       -1
    z[3,1,2]  R943      -1
    z[3,1,2]  R944      1
    z[3,1,2]  R953      -0.495866984128952
    z[3,1,2]  R954      -2.7213424444198608e-01
    z[3,1,2]  R955      -4.5838269591331482e-01
    z[3,1,2]  R956      -1.9348157942295074e-01
    z[3,1,2]  R957      -2.4002535641193390e-01
    z[3,1,2]  R958      4.5512345433235168e-01
    z[3,1,2]  R959      -5.1767438650131226e-01
    z[3,1,2]  R960      -1.0964465141296387e-01
    z[3,1,2]  R961      -5.0401580333709717e-01
    z[3,1,2]  R962      -5.6539905071258545e-01
    z[3,1,2]  R963      5.5173772573471069e-01
    z[3,1,2]  R964      5.5275803804397583e-01
    z[3,1,2]  R965      5.4552298039197922e-02
    z[3,1,2]  R966      1.4933989942073822e-01
    z[3,1,2]  R967      5.3784090280532837e-01
    z[3,1,2]  R968      0.512365460395813
    z[3,1,2]  R969      0.704929530620575
    z[3,1,2]  R970      5.2729690074920654e-01
    z[3,1,2]  R971      7.4078536033630371e-01
    z[3,1,2]  R972      -0.0430370569229126
    z[3,1,2]  R973      4.1135424375534058e-01
    z[3,1,2]  R974      2.5374436378479004e-01
    z[3,1,2]  R975      2.1532240509986877e-01
    z[3,1,2]  R976      -5.2365595102310181e-01
    z[3,1,2]  R977      2.4641571938991547e-01
    z[3,1,2]  R978      -2.0875306427478790e-01
    z[3,1,2]  R979      -1.6267299652099609e-01
    z[3,1,2]  R980      -4.1821032762527466e-01
    z[3,1,2]  R981      -2.5715437531471252e-01
    z[3,1,2]  R982      -1.4770062267780304e-01
    z[3,1,2]  R983      7.1830958127975464e-01
    z[3,1,2]  R984      4.5473849773406982e-01
    z[3,1,2]  R985      4.6605947613716125e-01
    z[3,1,2]  R986      3.6716330051422119e-01
    z[3,1,2]  R987      3.0969995260238647e-01
    z[3,1,2]  R988      -6.9029003381729126e-01
    z[3,1,2]  R989      3.0808454751968384e-01
    z[3,1,2]  R990      -5.3008008003234863e-01
    z[3,1,2]  R991      4.1050696372985840e-01
    z[3,1,2]  R992      -1.5325441956520081e-01
    z[3,1,2]  R993      4.5818847417831421e-01
    z[3,1,2]  R994      4.3385028839111328e-01
    z[3,1,2]  R995      2.0720952749252319e-01
    z[3,1,2]  R996      6.1554181575775146e-01
    z[3,1,2]  R997      -1.8043044209480286e-01
    z[3,1,2]  R998      5.0926405191421509e-01
    z[3,1,2]  R999      0.601693332195282
    z[3,1,2]  R1000     3.4847456216812134e-01
    z[3,1,2]  R1001     1.5690174698829651e-01
    z[3,1,2]  R1002     2.4623838067054749e-01
    z[3,1,2]  R1003     4.4899916648864746e-01
    z[3,1,2]  R1004     -2.7870857715606689e-01
    z[3,1,2]  R1005     8.3460563421249390e-01
    z[3,1,2]  R1006     -1.3503019511699677e-01
    z[3,1,2]  R1007     0.885668933391571
    z[3,1,2]  R1008     4.7445856034755707e-02
    z[3,1,2]  R1009     7.3200774192810059e-01
    z[3,1,2]  R1010     2.9898330569267273e-01
    z[3,1,2]  R1011     4.1195716708898544e-02
    z[3,1,2]  R1012     1.0171540081501007e-01
    z[3,1,2]  R1013     0.672829806804657
    z[3,1,2]  R1014     3.6227068305015564e-01
    z[3,1,2]  R1015     3.1364640593528748e-01
    z[3,1,2]  R1016     4.2406827211380005e-01
    z[3,1,2]  R1017     4.3404987454414368e-01
    z[3,1,2]  R1018     -6.8644896149635315e-02
    z[3,1,2]  R1019     0.256710946559906
    z[3,1,2]  R1020     -1.0159547626972198e-01
    z[3,1,2]  R1021     -5.5583781003952026e-01
    z[3,1,2]  R1022     -4.9035421013832092e-01
    z[3,1,2]  R1023     6.7314106225967407e-01
    z[3,1,2]  R1024     4.7472253441810608e-01
    z[3,1,2]  R1025     1.0133743286132812e-01
    z[3,1,2]  R1026     2.0631836354732513e-01
    z[3,1,2]  R1027     5.0050681829452515e-01
    z[3,1,2]  R1028     -2.1060007810592651e-01
    z[3,1,2]  R1029     6.1223471164703369e-01
    z[3,1,2]  R1030     5.7189010083675385e-02
    z[3,1,2]  R1031     2.2347699105739594e-01
    z[3,1,2]  R1032     -1.4080753922462463e-01
    z[3,1,2]  R1033     -2.3597948253154755e-01
    z[3,1,2]  R1034     5.6909757852554321e-01
    z[3,1,2]  R1035     -4.2687880992889404e-01
    z[3,1,2]  R1036     4.4247588515281677e-01
    z[3,1,2]  R1037     -3.9816579222679138e-01
    z[3,1,2]  R1038     4.3460118770599365e-01
    z[3,1,2]  R1039     -6.5257710218429565e-01
    z[3,1,2]  R1040     -4.8077547550201416e-01
    z[3,1,2]  R1041     -1.4383430778980255e-01
    z[3,1,2]  R1042     3.4261253476142883e-01
    z[3,1,2]  R1043     -2.4280132353305817e-01
    z[3,1,2]  R1044     -3.8911259174346924e-01
    z[3,1,2]  R1045     3.3616498112678528e-01
    z[3,1,2]  R1046     1.9201441109180450e-01
    z[3,1,2]  R1047     -0.211082324385643
    z[3,1,2]  R1048     5.0174808502197266e-01
    z[3,1,2]  R1049     9.4765760004520416e-02
    z[3,1,2]  R1050     -1.2549269199371338e-01
    z[3,1,2]  R1051     5.6650322675704956e-01
    z[3,1,2]  R1052     2.4162469804286957e-01
    z[3,1,2]  R1053     1.5392532944679260e-01
    z[3,1,2]  R1054     -1.1897242814302444e-01
    z[3,1,2]  R1055     0.45625039935112
    z[3,1,2]  R1056     -1.4246310293674469e-01
    z[3,1,2]  R1057     1.6092897951602936e-01
    z[3,1,2]  R1058     2.2043561935424805e-01
    z[3,1,2]  R1059     1.3189366459846497e-01
    z[3,1,2]  R1060     -3.7291178107261658e-01
    z[3,1,2]  R1061     -5.5576390027999878e-01
    z[3,1,2]  R1062     -5.5670505762100220e-01
    z[3,1,3]  R14       1
    z[3,1,3]  R32       -1
    z[3,1,3]  R945      -1
    z[3,1,3]  R946      1
    z[3,1,3]  R953      3.7420988082885742e-01
    z[3,1,3]  R954      6.7907691001892090e-01
    z[3,1,3]  R955      4.3427556753158569e-01
    z[3,1,3]  R956      5.0297158956527710e-01
    z[3,1,3]  R957      6.7577290534973145e-01
    z[3,1,3]  R958      -2.4416683614253998e-01
    z[3,1,3]  R959      1.3043354451656342e-01
    z[3,1,3]  R960      2.3145893216133118e-01
    z[3,1,3]  R961      3.4173694252967834e-01
    z[3,1,3]  R962      3.4725794196128845e-01
    z[3,1,3]  R963      -3.9352294057607651e-02
    z[3,1,3]  R964      -2.0397897064685822e-01
    z[3,1,3]  R965      1.7381841316819191e-02
    z[3,1,3]  R966      -1.0820031911134720e-01
    z[3,1,3]  R967      -2.0943066477775574e-01
    z[3,1,3]  R968      -2.5197410583496094e-01
    z[3,1,3]  R969      2.8585383668541908e-02
    z[3,1,3]  R970      -3.0092450976371765e-01
    z[3,1,3]  R971      -4.6742090582847595e-01
    z[3,1,3]  R972      -3.0300248414278030e-02
    z[3,1,3]  R973      -6.7259013652801514e-01
    z[3,1,3]  R974      -5.8234238624572754e-01
    z[3,1,3]  R975      -4.4266286492347717e-01
    z[3,1,3]  R976      6.7975777387619019e-01
    z[3,1,3]  R977      -5.2452695369720459e-01
    z[3,1,3]  R978      -1.4348666369915009e-01
    z[3,1,3]  R979      -8.2589067518711090e-02
    z[3,1,3]  R980      -2.4972349405288696e-01
    z[3,1,3]  R981      -1.6817671060562134e-01
    z[3,1,3]  R982      -2.3673868179321289e-01
    z[3,1,3]  R983      -6.9535695016384125e-02
    z[3,1,3]  R984      -2.5063166022300720e-01
    z[3,1,3]  R985      -2.6369345188140869e-01
    z[3,1,3]  R986      -3.9013007283210754e-01
    z[3,1,3]  R987      -3.8972941040992737e-01
    z[3,1,3]  R988      2.8705161809921265e-01
    z[3,1,3]  R989      7.6106287539005280e-02
    z[3,1,3]  R990      5.8734875917434692e-01
    z[3,1,3]  R991      4.8898744583129883e-01
    z[3,1,3]  R992      -4.2992007732391357e-01
    z[3,1,3]  R993      -4.4301679730415344e-01
    z[3,1,3]  R994      -1.8483416736125946e-01
    z[3,1,3]  R995      -0.665672242641449
    z[3,1,3]  R996      -4.3565583229064941e-01
    z[3,1,3]  R997      -4.9580168724060059e-01
    z[3,1,3]  R998      1.5340850688517094e-02
    z[3,1,3]  R999      -2.3656207323074341e-01
    z[3,1,3]  R1000     4.2897865176200867e-01
    z[3,1,3]  R1001     2.7163015678524971e-02
    z[3,1,3]  R1002     -1.9019616767764091e-02
    z[3,1,3]  R1003     -3.0038860440254211e-01
    z[3,1,3]  R1004     -0.324074387550354
    z[3,1,3]  R1005     -1.2518766522407532e-01
    z[3,1,3]  R1006     7.3851294815540314e-02
    z[3,1,3]  R1007     -2.6993727311491966e-02
    z[3,1,3]  R1008     -2.3950931429862976e-01
    z[3,1,3]  R1009     -8.0155604518949986e-04
    z[3,1,3]  R1010     -6.5887951850891113e-01
    z[3,1,3]  R1011     -2.7802556753158569e-01
    z[3,1,3]  R1012     -9.0073829889297485e-01
    z[3,1,3]  R1013     -3.9974990487098694e-01
    z[3,1,3]  R1014     -7.0483297109603882e-01
    z[3,1,3]  R1015     -0.636849045753479
    z[3,1,3]  R1016     1.4090560376644135e-01
    z[3,1,3]  R1017     4.3926298618316650e-01
    z[3,1,3]  R1018     1.7935261130332947e-01
    z[3,1,3]  R1019     -4.4287670403718948e-02
    z[3,1,3]  R1020     -1.9506633281707764e-01
    z[3,1,3]  R1021     4.2763477563858032e-01
    z[3,1,3]  R1022     2.4731636047363281e-01
    z[3,1,3]  R1023     -4.1987213492393494e-01
    z[3,1,3]  R1024     -5.4470568895339966e-01
    z[3,1,3]  R1025     -2.0091973245143890e-01
    z[3,1,3]  R1026     5.7016885280609131e-01
    z[3,1,3]  R1027     1.8288058042526245e-01
    z[3,1,3]  R1028     5.7683402299880981e-01
    z[3,1,3]  R1029     9.9328316748142242e-02
    z[3,1,3]  R1030     -2.7665802836418152e-01
    z[3,1,3]  R1031     -2.5349313020706177e-01
    z[3,1,3]  R1032     -3.3209922909736633e-01
    z[3,1,3]  R1033     -5.1900601387023926e-01
    z[3,1,3]  R1034     -3.1045249104499817e-01
    z[3,1,3]  R1035     3.1423109769821167e-01
    z[3,1,3]  R1036     2.1137748658657074e-01
    z[3,1,3]  R1037     2.8813469409942627e-01
    z[3,1,3]  R1038     4.5024354010820389e-02
    z[3,1,3]  R1039     5.6768339872360229e-01
    z[3,1,3]  R1040     5.4710513353347778e-01
    z[3,1,3]  R1041     2.6591575145721436e-01
    z[3,1,3]  R1042     -1.4462395012378693e-01
    z[3,1,3]  R1043     6.9761854410171509e-01
    z[3,1,3]  R1044     7.0579981803894043e-01
    z[3,1,3]  R1045     7.0265442132949829e-01
    z[3,1,3]  R1046     8.3274716138839722e-01
    z[3,1,3]  R1047     8.3575522899627686e-01
    z[3,1,3]  R1048     6.8083167076110840e-01
    z[3,1,3]  R1049     4.4157034158706665e-01
    z[3,1,3]  R1050     -1.1593621969223022e-01
    z[3,1,3]  R1051     -0.0922110453248024
    z[3,1,3]  R1052     -0.0977182611823082
    z[3,1,3]  R1053     -8.8844668865203857e-01
    z[3,1,3]  R1054     -7.7384406328201294e-01
    z[3,1,3]  R1055     -5.3013539314270020e-01
    z[3,1,3]  R1056     -4.3950146436691284e-01
    z[3,1,3]  R1057     -3.7368568778038025e-01
    z[3,1,3]  R1058     -4.1142952442169189e-01
    z[3,1,3]  R1059     -3.6310148239135742e-01
    z[3,1,3]  R1060     -2.4321369826793671e-01
    z[3,1,3]  R1061     -2.4231983721256256e-01
    z[3,1,3]  R1062     -2.5232541561126709e-01
    z[3,1,4]  R15       1
    z[3,1,4]  R33       -1
    z[3,1,4]  R947      -1
    z[3,1,4]  R948      1
    z[3,1,4]  R953      -4.6652253717184067e-02
    z[3,1,4]  R954      -2.4003187194466591e-02
    z[3,1,4]  R955      4.5995318889617920e-01
    z[3,1,4]  R956      2.9704380035400391e-01
    z[3,1,4]  R957      2.0661835372447968e-01
    z[3,1,4]  R958      -2.1915614604949951e-01
    z[3,1,4]  R959      1.3381545245647430e-01
    z[3,1,4]  R960      -1.3279208540916443e-01
    z[3,1,4]  R961      -1.2246138602495193e-01
    z[3,1,4]  R962      3.7044730782508850e-01
    z[3,1,4]  R963      0.0644272193312645
    z[3,1,4]  R964      1.7407299578189850e-01
    z[3,1,4]  R965      -1.0715722292661667e-01
    z[3,1,4]  R966      -1.4778789877891541e-01
    z[3,1,4]  R967      -1.4112314581871033e-01
    z[3,1,4]  R968      2.2384163737297058e-01
    z[3,1,4]  R969      1.7793895304203033e-01
    z[3,1,4]  R970      4.4721037149429321e-01
    z[3,1,4]  R971      -0.0606394037604332
    z[3,1,4]  R972      1.2662783265113831e-01
    z[3,1,4]  R973      1.7410339415073395e-01
    z[3,1,4]  R974      3.4294697642326355e-01
    z[3,1,4]  R975      0.0515059269964695
    z[3,1,4]  R976      -3.0618287622928619e-02
    z[3,1,4]  R977      1.1818935722112656e-01
    z[3,1,4]  R978      -2.5935724377632141e-01
    z[3,1,4]  R979      -7.0793621242046356e-02
    z[3,1,4]  R980      -2.3014941811561584e-01
    z[3,1,4]  R981      -2.3294666409492493e-01
    z[3,1,4]  R982      2.0637065172195435e-01
    z[3,1,4]  R983      -4.1234114766120911e-01
    z[3,1,4]  R984      4.6587803959846497e-01
    z[3,1,4]  R985      0.31876340508461
    z[3,1,4]  R986      -1.3341650366783142e-01
    z[3,1,4]  R987      -4.1229271888732910e-01
    z[3,1,4]  R988      2.4737310409545898e-01
    z[3,1,4]  R989      0.0967501625418663
    z[3,1,4]  R990      4.6853196620941162e-01
    z[3,1,4]  R991      3.2393902540206909e-01
    z[3,1,4]  R992      1.9697868824005127e-01
    z[3,1,4]  R993      2.0611914992332458e-01
    z[3,1,4]  R994      -2.7662146091461182e-01
    z[3,1,4]  R995      -2.1774184703826904e-01
    z[3,1,4]  R996      -1.7755937576293945e-01
    z[3,1,4]  R997      -6.5851235389709473e-01
    z[3,1,4]  R998      -6.3356764614582062e-02
    z[3,1,4]  R999      -9.6845224499702454e-02
    z[3,1,4]  R1000     2.3995047807693481e-01
    z[3,1,4]  R1001     -1.2424138188362122e-01
    z[3,1,4]  R1002     1.5257167816162109e-01
    z[3,1,4]  R1003     -8.3643466234207153e-02
    z[3,1,4]  R1004     -1.0962177067995071e-01
    z[3,1,4]  R1005     -3.1764388084411621e-01
    z[3,1,4]  R1006     1.7952004075050354e-01
    z[3,1,4]  R1007     3.9193700999021530e-02
    z[3,1,4]  R1008     1.7649734020233154e-01
    z[3,1,4]  R1009     0.24935382604599
    z[3,1,4]  R1010     8.4604196250438690e-02
    z[3,1,4]  R1011     -2.7523839473724365e-01
    z[3,1,4]  R1012     2.5690355896949768e-01
    z[3,1,4]  R1013     1.5428103506565094e-01
    z[3,1,4]  R1014     1.6195248812437057e-02
    z[3,1,4]  R1015     8.7646394968032837e-02
    z[3,1,4]  R1016     2.2998262941837311e-01
    z[3,1,4]  R1017     -8.0991901457309723e-02
    z[3,1,4]  R1018     1.5155556797981262e-01
    z[3,1,4]  R1019     -6.2881387770175934e-02
    z[3,1,4]  R1020     -1.9795902073383331e-01
    z[3,1,4]  R1021     -2.9808852076530457e-01
    z[3,1,4]  R1022     -2.7864545583724976e-01
    z[3,1,4]  R1023     -5.4691050201654434e-02
    z[3,1,4]  R1024     -1.0489811003208160e-01
    z[3,1,4]  R1025     -2.9336953163146973e-01
    z[3,1,4]  R1026     2.2056722640991211e-01
    z[3,1,4]  R1027     9.9898435175418854e-02
    z[3,1,4]  R1028     -4.8859912157058716e-01
    z[3,1,4]  R1029     3.5315670073032379e-02
    z[3,1,4]  R1030     -2.1309521794319153e-01
    z[3,1,4]  R1031     8.6106121540069580e-01
    z[3,1,4]  R1032     3.3534392714500427e-01
    z[3,1,4]  R1033     -3.8835567235946655e-01
    z[3,1,4]  R1034     5.3314459323883057e-01
    z[3,1,4]  R1035     -2.9568953439593315e-02
    z[3,1,4]  R1036     -1.4985139667987823e-01
    z[3,1,4]  R1037     0.320017009973526
    z[3,1,4]  R1038     3.4514892101287842e-01
    z[3,1,4]  R1039     -1.2468189746141434e-01
    z[3,1,4]  R1040     3.4777253866195679e-02
    z[3,1,4]  R1041     0.360971599817276
    z[3,1,4]  R1042     -1.2381967157125473e-01
    z[3,1,4]  R1043     3.9406582713127136e-01
    z[3,1,4]  R1044     4.5046284794807434e-01
    z[3,1,4]  R1045     0.486801415681839
    z[3,1,4]  R1046     -2.4763226509094238e-01
    z[3,1,4]  R1047     -1.4636451005935669e-01
    z[3,1,4]  R1048     4.3101231567561626e-03
    z[3,1,4]  R1049     4.7685602307319641e-01
    z[3,1,4]  R1050     -4.4916570186614990e-03
    z[3,1,4]  R1051     -3.2263353466987610e-01
    z[3,1,4]  R1052     -2.9715770483016968e-01
    z[3,1,4]  R1053     1.1608657240867615e-01
    z[3,1,4]  R1054     -4.9887317419052124e-01
    z[3,1,4]  R1055     5.0323802232742310e-01
    z[3,1,4]  R1056     -0.346293181180954
    z[3,1,4]  R1057     -4.7331359982490540e-01
    z[3,1,4]  R1058     -3.8748362660408020e-01
    z[3,1,4]  R1059     -5.0233131647109985e-01
    z[3,1,4]  R1060     -1.5805552899837494e-01
    z[3,1,4]  R1061     -0.0805695503950119
    z[3,1,4]  R1062     -2.3558795452117920e-01
    z[3,1,5]  R16       1
    z[3,1,5]  R34       -1
    z[3,1,5]  R949      -1
    z[3,1,5]  R950      1
    z[3,1,5]  R953      -4.4074233621358871e-02
    z[3,1,5]  R954      -1.4495445787906647e-01
    z[3,1,5]  R955      -6.9058477878570557e-02
    z[3,1,5]  R956      -2.8482276201248169e-01
    z[3,1,5]  R957      1.8145045638084412e-01
    z[3,1,5]  R958      1.5429614484310150e-01
    z[3,1,5]  R959      -1.0010101646184921e-01
    z[3,1,5]  R960      -1.0949768126010895e-01
    z[3,1,5]  R961      -3.4235006570816040e-01
    z[3,1,5]  R962      1.0637746751308441e-01
    z[3,1,5]  R963      2.8287851810455322e-01
    z[3,1,5]  R964      2.0069922506809235e-01
    z[3,1,5]  R965      2.3118227720260620e-01
    z[3,1,5]  R966      -0.075913205742836
    z[3,1,5]  R967      0.535001814365387
    z[3,1,5]  R968      1.0893454402685165e-01
    z[3,1,5]  R969      2.9696938395500183e-01
    z[3,1,5]  R970      4.0769883990287781e-01
    z[3,1,5]  R971      -4.6716742217540741e-03
    z[3,1,5]  R972      2.5278747081756592e-01
    z[3,1,5]  R973      4.4447210431098938e-01
    z[3,1,5]  R974      5.4762428998947144e-01
    z[3,1,5]  R975      6.3761627674102783e-01
    z[3,1,5]  R976      -2.6111018657684326e-01
    z[3,1,5]  R977      6.4481425285339355e-01
    z[3,1,5]  R978      -3.5370582342147827e-01
    z[3,1,5]  R979      -4.5468306541442871e-01
    z[3,1,5]  R980      -0.252608984708786
    z[3,1,5]  R981      -5.0605303049087524e-01
    z[3,1,5]  R982      -4.5991146564483643e-01
    z[3,1,5]  R983      4.8409852385520935e-01
    z[3,1,5]  R984      0.587566614151001
    z[3,1,5]  R985      6.3206166028976440e-01
    z[3,1,5]  R986      5.8540689945220947e-01
    z[3,1,5]  R987      5.7594513893127441e-01
    z[3,1,5]  R988      -2.8168687224388123e-01
    z[3,1,5]  R989      5.8635663986206055e-01
    z[3,1,5]  R990      -1.1911985278129578e-01
    z[3,1,5]  R991      1.7296472191810608e-01
    z[3,1,5]  R992      -2.8461429476737976e-01
    z[3,1,5]  R993      5.6511014699935913e-01
    z[3,1,5]  R994      2.6678198575973511e-01
    z[3,1,5]  R995      4.8890298604965210e-01
    z[3,1,5]  R996      -0.0569256953895092
    z[3,1,5]  R997      -2.1289469301700592e-01
    z[3,1,5]  R998      2.3178681731224060e-01
    z[3,1,5]  R999      3.6339035630226135e-01
    z[3,1,5]  R1000     4.3757492303848267e-01
    z[3,1,5]  R1001     7.4298632144927979e-01
    z[3,1,5]  R1002     5.8118617534637451e-01
    z[3,1,5]  R1003     3.7851619720458984e-01
    z[3,1,5]  R1004     -2.1907933056354523e-01
    z[3,1,5]  R1005     2.9881912469863892e-01
    z[3,1,5]  R1006     1.2832273729145527e-02
    z[3,1,5]  R1007     3.4379380941390991e-01
    z[3,1,5]  R1008     5.8337718248367310e-01
    z[3,1,5]  R1009     5.1027429103851318e-01
    z[3,1,5]  R1010     4.4948694109916687e-01
    z[3,1,5]  R1011     1.1982368677854538e-01
    z[3,1,5]  R1012     -0.0586259625852108
    z[3,1,5]  R1013     6.0723256319761276e-02
    z[3,1,5]  R1014     2.1167193353176117e-01
    z[3,1,5]  R1015     5.9822231531143188e-02
    z[3,1,5]  R1016     6.9899767637252808e-01
    z[3,1,5]  R1017     1.0365897417068481e-01
    z[3,1,5]  R1018     4.8748105764389038e-01
    z[3,1,5]  R1019     8.9537531137466431e-01
    z[3,1,5]  R1020     6.8468856811523438e-01
    z[3,1,5]  R1021     -4.6031859517097473e-01
    z[3,1,5]  R1022     -5.5460166931152344e-01
    z[3,1,5]  R1023     2.7098900079727173e-01
    z[3,1,5]  R1024     5.4674917459487915e-01
    z[3,1,5]  R1025     -5.4734289646148682e-01
    z[3,1,5]  R1026     4.1980616748332977e-02
    z[3,1,5]  R1027     -1.3455897569656372e-01
    z[3,1,5]  R1028     0.287685364484787
    z[3,1,5]  R1029     6.1171799898147583e-01
    z[3,1,5]  R1030     -1.0330747067928314e-01
    z[3,1,5]  R1031     -1.2625804543495178e-01
    z[3,1,5]  R1032     -1.2806738913059235e-01
    z[3,1,5]  R1033     -2.3561830818653107e-01
    z[3,1,5]  R1034     2.7680492401123047e-01
    z[3,1,5]  R1035     -6.6292285919189453e-01
    z[3,1,5]  R1036     5.4928410053253174e-01
    z[3,1,5]  R1037     4.1932541131973267e-01
    z[3,1,5]  R1038     0.254957914352417
    z[3,1,5]  R1039     -7.9919271171092987e-02
    z[3,1,5]  R1040     -4.2730411887168884e-01
    z[3,1,5]  R1041     2.8728953003883362e-01
    z[3,1,5]  R1042     1.8982259929180145e-01
    z[3,1,5]  R1043     -3.6901223659515381e-01
    z[3,1,5]  R1044     -1.1600410193204880e-01
    z[3,1,5]  R1045     3.2378707081079483e-02
    z[3,1,5]  R1046     -2.1641814708709717e-01
    z[3,1,5]  R1047     -2.5121828913688660e-01
    z[3,1,5]  R1048     -4.3281629681587219e-01
    z[3,1,5]  R1049     -6.6607022285461426e-01
    z[3,1,5]  R1050     2.8251004219055176e-01
    z[3,1,5]  R1051     -2.8031954169273376e-01
    z[3,1,5]  R1052     -1.6167476773262024e-01
    z[3,1,5]  R1053     -8.3953499794006348e-02
    z[3,1,5]  R1054     -3.1239360570907593e-01
    z[3,1,5]  R1055     2.3754407465457916e-01
    z[3,1,5]  R1056     7.4026662111282349e-01
    z[3,1,5]  R1057     6.6615206003189087e-01
    z[3,1,5]  R1058     6.8987190723419189e-01
    z[3,1,5]  R1059     7.4313873052597046e-01
    z[3,1,5]  R1060     2.6337283849716187e-01
    z[3,1,5]  R1061     3.8477602601051331e-01
    z[3,1,5]  R1062     2.8918406367301941e-01
    z[3,1,6]  R17       1
    z[3,1,6]  R35       -1
    z[3,1,6]  R951      -1
    z[3,1,6]  R952      1
    z[3,1,6]  R953      -1.5861645340919495e-01
    z[3,1,6]  R954      1.9234988093376160e-01
    z[3,1,6]  R955      -1.5485175885260105e-02
    z[3,1,6]  R956      1.6566525399684906e-01
    z[3,1,6]  R957      -2.8882148861885071e-01
    z[3,1,6]  R958      -4.2173019051551819e-01
    z[3,1,6]  R959      1.8046455085277557e-01
    z[3,1,6]  R960      -2.7422466874122620e-01
    z[3,1,6]  R961      1.2597066164016724e-01
    z[3,1,6]  R962      -3.1372427940368652e-01
    z[3,1,6]  R963      1.4145767688751221e-01
    z[3,1,6]  R964      -7.0472881197929382e-02
    z[3,1,6]  R965      6.9888085126876831e-02
    z[3,1,6]  R966      2.7485650032758713e-02
    z[3,1,6]  R967      1.8679074943065643e-01
    z[3,1,6]  R968      -2.7392706274986267e-01
    z[3,1,6]  R969      5.2603948116302490e-01
    z[3,1,6]  R970      2.9290032386779785e-01
    z[3,1,6]  R971      3.8864722847938538e-01
    z[3,1,6]  R972      -2.4102360010147095e-01
    z[3,1,6]  R973      -2.1817234158515930e-01
    z[3,1,6]  R974      -1.9706779718399048e-01
    z[3,1,6]  R975      -1.3251727819442749e-01
    z[3,1,6]  R976      -1.6446286439895630e-01
    z[3,1,6]  R977      2.6247581839561462e-01
    z[3,1,6]  R978      4.5745734125375748e-02
    z[3,1,6]  R979      2.3047868907451630e-01
    z[3,1,6]  R980      -5.9881657361984253e-02
    z[3,1,6]  R981      -9.4336703419685364e-02
    z[3,1,6]  R982      5.8939591050148010e-02
    z[3,1,6]  R983      -1.5689672902226448e-02
    z[3,1,6]  R984      -1.8470782786607742e-02
    z[3,1,6]  R985      4.1349419951438904e-01
    z[3,1,6]  R986      4.8553115129470825e-01
    z[3,1,6]  R987      1.9763223826885223e-01
    z[3,1,6]  R988      5.5701290257275105e-03
    z[3,1,6]  R989      -0.57218337059021
    z[3,1,6]  R990      1.4964535832405090e-01
    z[3,1,6]  R991      1.2106354348361492e-02
    z[3,1,6]  R992      -2.5076735019683838e-01
    z[3,1,6]  R993      2.1989084780216217e-01
    z[3,1,6]  R994      -2.6869857311248779e-01
    z[3,1,6]  R995      -2.6428046822547913e-01
    z[3,1,6]  R996      1.2014728784561157e-01
    z[3,1,6]  R997      -4.5258617401123047e-01
    z[3,1,6]  R998      4.2708730697631836e-01
    z[3,1,6]  R999      6.5108686685562134e-01
    z[3,1,6]  R1000     0.0421893447637558
    z[3,1,6]  R1001     -3.9146393537521362e-01
    z[3,1,6]  R1002     -4.8854342103004456e-01
    z[3,1,6]  R1003     -2.7119457721710205e-01
    z[3,1,6]  R1004     -6.6284263134002686e-01
    z[3,1,6]  R1005     9.0074427425861359e-02
    z[3,1,6]  R1006     -9.5177195966243744e-02
    z[3,1,6]  R1007     -2.7251252532005310e-01
    z[3,1,6]  R1008     -2.9646283388137817e-01
    z[3,1,6]  R1009     2.4682195484638214e-01
    z[3,1,6]  R1010     -5.0488543510437012e-01
    z[3,1,6]  R1011     -7.8267019987106323e-01
    z[3,1,6]  R1012     2.8267474845051765e-02
    z[3,1,6]  R1013     0.275452196598053
    z[3,1,6]  R1014     -1.0823348909616470e-01
    z[3,1,6]  R1015     -0.485553115606308
    z[3,1,6]  R1016     3.1136220693588257e-01
    z[3,1,6]  R1017     3.1912293285131454e-02
    z[3,1,6]  R1018     9.7209677100181580e-02
    z[3,1,6]  R1019     5.2639592438936234e-02
    z[3,1,6]  R1020     4.7794154286384583e-01
    z[3,1,6]  R1021     -9.5068022608757019e-02
    z[3,1,6]  R1022     2.1829910576343536e-01
    z[3,1,6]  R1023     8.0980263650417328e-02
    z[3,1,6]  R1024     -1.9113582372665405e-01
    z[3,1,6]  R1025     1.7105533182621002e-01
    z[3,1,6]  R1026     -1.8997816741466522e-01
    z[3,1,6]  R1027     -1.4648582041263580e-01
    z[3,1,6]  R1028     9.8100811243057251e-02
    z[3,1,6]  R1029     -3.3444008231163025e-01
    z[3,1,6]  R1030     1.7640037834644318e-01
    z[3,1,6]  R1031     2.6220846176147461e-01
    z[3,1,6]  R1032     -1.7896692454814911e-01
    z[3,1,6]  R1033     -2.0715422928333282e-01
    z[3,1,6]  R1034     -2.8764620423316956e-01
    z[3,1,6]  R1035     0.0504353865981102
    z[3,1,6]  R1036     3.1272175908088684e-01
    z[3,1,6]  R1037     2.3649330437183380e-01
    z[3,1,6]  R1038     -2.9267209768295288e-01
    z[3,1,6]  R1039     1.2861740775406361e-02
    z[3,1,6]  R1040     3.5773232579231262e-01
    z[3,1,6]  R1041     -7.4043780565261841e-02
    z[3,1,6]  R1042     -3.3289868384599686e-02
    z[3,1,6]  R1043     1.5975877642631531e-01
    z[3,1,6]  R1044     1.5552735328674316e-01
    z[3,1,6]  R1045     -2.1702274680137634e-02
    z[3,1,6]  R1046     -2.1303531527519226e-01
    z[3,1,6]  R1047     2.3531040549278259e-01
    z[3,1,6]  R1048     -1.6468851268291473e-01
    z[3,1,6]  R1049     9.1937407851219177e-03
    z[3,1,6]  R1050     1.1114278435707092e-01
    z[3,1,6]  R1051     3.0565917491912842e-02
    z[3,1,6]  R1052     2.5358486175537109e-01
    z[3,1,6]  R1053     -2.2230693697929382e-01
    z[3,1,6]  R1054     -7.8097254037857056e-02
    z[3,1,6]  R1055     -0.262433797121048
    z[3,1,6]  R1056     0.0954258143901825
    z[3,1,6]  R1057     2.6463833451271057e-01
    z[3,1,6]  R1058     1.6134175658226013e-01
    z[3,1,6]  R1059     -2.0603444427251816e-02
    z[3,1,6]  R1060     9.7397871315479279e-02
    z[3,1,6]  R1061     -2.3673607409000397e-01
    z[3,1,6]  R1062     2.3702910542488098e-01
    z[1,4,0]  R11       -1
    z[1,4,0]  R38       1
    z[1,4,0]  R1063     -1
    z[1,4,0]  R1064     1
    z[1,4,0]  R1077     -0.077597476541996
    z[1,4,0]  R1078     2.6397129893302917e-01
    z[1,4,0]  R1079     -7.9583726823329926e-02
    z[1,4,0]  R1080     2.7869397774338722e-02
    z[1,4,0]  R1081     -2.1747012436389923e-01
    z[1,4,0]  R1082     2.2852631285786629e-02
    z[1,4,0]  R1083     1.7220035195350647e-01
    z[1,4,0]  R1084     2.2474895417690277e-01
    z[1,4,0]  R1085     -3.9130559563636780e-01
    z[1,4,0]  R1086     -4.8110938072204590e-01
    z[1,4,0]  R1087     3.1633594632148743e-01
    z[1,4,0]  R1088     6.5092794829979539e-04
    z[1,4,0]  R1089     3.6189493536949158e-01
    z[1,4,0]  R1090     -2.3062512278556824e-01
    z[1,4,0]  R1091     1.5377096831798553e-01
    z[1,4,0]  R1092     -1.4678399264812469e-01
    z[1,4,0]  R1093     -1.1018574982881546e-01
    z[1,4,0]  R1094     -7.4105983972549438e-01
    z[1,4,0]  R1095     -3.4644496440887451e-01
    z[1,4,0]  R1096     -3.0616229772567749e-01
    z[1,4,0]  R1097     2.1349316835403442e-01
    z[1,4,0]  R1098     -4.5517912507057190e-01
    z[1,4,0]  R1099     6.5998509526252747e-02
    z[1,4,0]  R1100     2.2978940978646278e-02
    z[1,4,0]  R1101     -2.9317969083786011e-01
    z[1,4,0]  R1102     -9.3563318252563477e-02
    z[1,4,0]  R1103     4.4083085656166077e-01
    z[1,4,1]  R12       -1
    z[1,4,1]  R39       1
    z[1,4,1]  R1065     -1
    z[1,4,1]  R1066     1
    z[1,4,1]  R1077     3.6245518922805786e-01
    z[1,4,1]  R1078     -2.0048640668392181e-01
    z[1,4,1]  R1079     3.8528078794479370e-01
    z[1,4,1]  R1080     3.3962216973304749e-01
    z[1,4,1]  R1081     -2.6412123441696167e-01
    z[1,4,1]  R1082     -2.6405319571495056e-01
    z[1,4,1]  R1083     -3.0863621830940247e-01
    z[1,4,1]  R1084     -9.1000741720199585e-01
    z[1,4,1]  R1085     -5.7779359817504883e-01
    z[1,4,1]  R1086     -7.2239577770233154e-01
    z[1,4,1]  R1087     -1.3021700084209442e-01
    z[1,4,1]  R1088     -1.8559944629669189e-01
    z[1,4,1]  R1089     -3.5733491182327271e-02
    z[1,4,1]  R1090     2.3735000193119049e-01
    z[1,4,1]  R1091     2.7018073201179504e-01
    z[1,4,1]  R1092     3.2937890291213989e-01
    z[1,4,1]  R1093     1.8331421911716461e-01
    z[1,4,1]  R1094     3.8572159409523010e-01
    z[1,4,1]  R1095     5.4935926198959351e-01
    z[1,4,1]  R1096     5.8083051443099976e-01
    z[1,4,1]  R1097     -3.4159576892852783e-01
    z[1,4,1]  R1098     4.4207116961479187e-01
    z[1,4,1]  R1099     -3.6425170302391052e-01
    z[1,4,1]  R1100     5.7959675788879395e-02
    z[1,4,1]  R1101     -1.8813608912751079e-03
    z[1,4,1]  R1102     5.2941292524337769e-02
    z[1,4,1]  R1103     -1.3303664326667786e-01
    z[1,4,2]  R13       -1
    z[1,4,2]  R40       1
    z[1,4,2]  R1067     -1
    z[1,4,2]  R1068     1
    z[1,4,2]  R1077     -2.4280132353305817e-01
    z[1,4,2]  R1078     -3.8911259174346924e-01
    z[1,4,2]  R1079     3.3616498112678528e-01
    z[1,4,2]  R1080     1.9201441109180450e-01
    z[1,4,2]  R1081     -0.211082324385643
    z[1,4,2]  R1082     5.0174808502197266e-01
    z[1,4,2]  R1083     9.4765760004520416e-02
    z[1,4,2]  R1084     -1.2549269199371338e-01
    z[1,4,2]  R1085     5.6650322675704956e-01
    z[1,4,2]  R1086     2.4162469804286957e-01
    z[1,4,2]  R1087     1.5392532944679260e-01
    z[1,4,2]  R1088     -1.1897242814302444e-01
    z[1,4,2]  R1089     0.45625039935112
    z[1,4,2]  R1090     -1.4246310293674469e-01
    z[1,4,2]  R1091     1.6092897951602936e-01
    z[1,4,2]  R1092     2.2043561935424805e-01
    z[1,4,2]  R1093     1.3189366459846497e-01
    z[1,4,2]  R1094     -3.7291178107261658e-01
    z[1,4,2]  R1095     -5.5576390027999878e-01
    z[1,4,2]  R1096     -5.5670505762100220e-01
    z[1,4,2]  R1097     -3.7890592217445374e-01
    z[1,4,2]  R1098     4.2208835482597351e-01
    z[1,4,2]  R1099     7.1080386638641357e-01
    z[1,4,2]  R1100     -3.9535153657197952e-02
    z[1,4,2]  R1101     -1.6089507937431335e-01
    z[1,4,2]  R1102     1.5210928022861481e-01
    z[1,4,2]  R1103     6.8489299155771732e-03
    z[1,4,3]  R14       -1
    z[1,4,3]  R41       1
    z[1,4,3]  R1069     -1
    z[1,4,3]  R1070     1
    z[1,4,3]  R1077     6.9761854410171509e-01
    z[1,4,3]  R1078     7.0579981803894043e-01
    z[1,4,3]  R1079     7.0265442132949829e-01
    z[1,4,3]  R1080     8.3274716138839722e-01
    z[1,4,3]  R1081     8.3575522899627686e-01
    z[1,4,3]  R1082     6.8083167076110840e-01
    z[1,4,3]  R1083     4.4157034158706665e-01
    z[1,4,3]  R1084     -1.1593621969223022e-01
    z[1,4,3]  R1085     -0.0922110453248024
    z[1,4,3]  R1086     -0.0977182611823082
    z[1,4,3]  R1087     -8.8844668865203857e-01
    z[1,4,3]  R1088     -7.7384406328201294e-01
    z[1,4,3]  R1089     -5.3013539314270020e-01
    z[1,4,3]  R1090     -4.3950146436691284e-01
    z[1,4,3]  R1091     -3.7368568778038025e-01
    z[1,4,3]  R1092     -4.1142952442169189e-01
    z[1,4,3]  R1093     -3.6310148239135742e-01
    z[1,4,3]  R1094     -2.4321369826793671e-01
    z[1,4,3]  R1095     -2.4231983721256256e-01
    z[1,4,3]  R1096     -2.5232541561126709e-01
    z[1,4,3]  R1097     7.4422317743301392e-01
    z[1,4,3]  R1098     2.4902540445327759e-01
    z[1,4,3]  R1099     6.2218014150857925e-02
    z[1,4,3]  R1100     2.1696844696998596e-01
    z[1,4,3]  R1101     -6.5100783109664917e-01
    z[1,4,3]  R1102     -8.7795192003250122e-01
    z[1,4,3]  R1103     -4.7661110758781433e-01
    z[1,4,4]  R15       -1
    z[1,4,4]  R42       1
    z[1,4,4]  R1071     -1
    z[1,4,4]  R1072     1
    z[1,4,4]  R1077     3.9406582713127136e-01
    z[1,4,4]  R1078     4.5046284794807434e-01
    z[1,4,4]  R1079     0.486801415681839
    z[1,4,4]  R1080     -2.4763226509094238e-01
    z[1,4,4]  R1081     -1.4636451005935669e-01
    z[1,4,4]  R1082     4.3101231567561626e-03
    z[1,4,4]  R1083     4.7685602307319641e-01
    z[1,4,4]  R1084     -4.4916570186614990e-03
    z[1,4,4]  R1085     -3.2263353466987610e-01
    z[1,4,4]  R1086     -2.9715770483016968e-01
    z[1,4,4]  R1087     1.1608657240867615e-01
    z[1,4,4]  R1088     -4.9887317419052124e-01
    z[1,4,4]  R1089     5.0323802232742310e-01
    z[1,4,4]  R1090     -0.346293181180954
    z[1,4,4]  R1091     -4.7331359982490540e-01
    z[1,4,4]  R1092     -3.8748362660408020e-01
    z[1,4,4]  R1093     -5.0233131647109985e-01
    z[1,4,4]  R1094     -1.5805552899837494e-01
    z[1,4,4]  R1095     -0.0805695503950119
    z[1,4,4]  R1096     -2.3558795452117920e-01
    z[1,4,4]  R1097     3.2042428851127625e-01
    z[1,4,4]  R1098     3.3340302109718323e-01
    z[1,4,4]  R1099     8.4792442619800568e-02
    z[1,4,4]  R1100     -9.2411078512668610e-02
    z[1,4,4]  R1101     3.4073132276535034e-01
    z[1,4,4]  R1102     -3.8112181425094604e-01
    z[1,4,4]  R1103     -1.6519330441951752e-01
    z[1,4,5]  R16       -1
    z[1,4,5]  R43       1
    z[1,4,5]  R1073     -1
    z[1,4,5]  R1074     1
    z[1,4,5]  R1077     -3.6901223659515381e-01
    z[1,4,5]  R1078     -1.1600410193204880e-01
    z[1,4,5]  R1079     3.2378707081079483e-02
    z[1,4,5]  R1080     -2.1641814708709717e-01
    z[1,4,5]  R1081     -2.5121828913688660e-01
    z[1,4,5]  R1082     -4.3281629681587219e-01
    z[1,4,5]  R1083     -6.6607022285461426e-01
    z[1,4,5]  R1084     2.8251004219055176e-01
    z[1,4,5]  R1085     -2.8031954169273376e-01
    z[1,4,5]  R1086     -1.6167476773262024e-01
    z[1,4,5]  R1087     -8.3953499794006348e-02
    z[1,4,5]  R1088     -3.1239360570907593e-01
    z[1,4,5]  R1089     2.3754407465457916e-01
    z[1,4,5]  R1090     7.4026662111282349e-01
    z[1,4,5]  R1091     6.6615206003189087e-01
    z[1,4,5]  R1092     6.8987190723419189e-01
    z[1,4,5]  R1093     7.4313873052597046e-01
    z[1,4,5]  R1094     2.6337283849716187e-01
    z[1,4,5]  R1095     3.8477602601051331e-01
    z[1,4,5]  R1096     2.8918406367301941e-01
    z[1,4,5]  R1097     -1.8587963283061981e-01
    z[1,4,5]  R1098     -1.5794233977794647e-01
    z[1,4,5]  R1099     -3.5428476333618164e-01
    z[1,4,5]  R1100     0.590069055557251
    z[1,4,5]  R1101     5.8619880676269531e-01
    z[1,4,5]  R1102     -2.1884655952453613e-01
    z[1,4,5]  R1103     2.6538777351379395e-01
    z[1,4,6]  R17       -1
    z[1,4,6]  R44       1
    z[1,4,6]  R1075     -1
    z[1,4,6]  R1076     1
    z[1,4,6]  R1077     1.5975877642631531e-01
    z[1,4,6]  R1078     1.5552735328674316e-01
    z[1,4,6]  R1079     -2.1702274680137634e-02
    z[1,4,6]  R1080     -2.1303531527519226e-01
    z[1,4,6]  R1081     2.3531040549278259e-01
    z[1,4,6]  R1082     -1.6468851268291473e-01
    z[1,4,6]  R1083     9.1937407851219177e-03
    z[1,4,6]  R1084     1.1114278435707092e-01
    z[1,4,6]  R1085     3.0565917491912842e-02
    z[1,4,6]  R1086     2.5358486175537109e-01
    z[1,4,6]  R1087     -2.2230693697929382e-01
    z[1,4,6]  R1088     -7.8097254037857056e-02
    z[1,4,6]  R1089     -0.262433797121048
    z[1,4,6]  R1090     0.0954258143901825
    z[1,4,6]  R1091     2.6463833451271057e-01
    z[1,4,6]  R1092     1.6134175658226013e-01
    z[1,4,6]  R1093     -2.0603444427251816e-02
    z[1,4,6]  R1094     9.7397871315479279e-02
    z[1,4,6]  R1095     -2.3673607409000397e-01
    z[1,4,6]  R1096     2.3702910542488098e-01
    z[1,4,6]  R1097     -5.5428370833396912e-02
    z[1,4,6]  R1098     -4.7022271156311035e-01
    z[1,4,6]  R1099     4.7025975584983826e-01
    z[1,4,6]  R1100     0.768604576587677
    z[1,4,6]  R1101     6.7947648465633392e-02
    z[1,4,6]  R1102     3.6858968436717987e-02
    z[1,4,6]  R1103     -0.680474042892456
    z[4,1,0]  R11       1
    z[4,1,0]  R38       -1
    z[4,1,0]  R1104     -1
    z[4,1,0]  R1105     1
    z[4,1,0]  R1118     2.1349316835403442e-01
    z[4,1,0]  R1119     -4.5517912507057190e-01
    z[4,1,0]  R1120     6.5998509526252747e-02
    z[4,1,0]  R1121     2.2978940978646278e-02
    z[4,1,0]  R1122     -2.9317969083786011e-01
    z[4,1,0]  R1123     -9.3563318252563477e-02
    z[4,1,0]  R1124     4.4083085656166077e-01
    z[4,1,0]  R1125     -0.077597476541996
    z[4,1,0]  R1126     2.6397129893302917e-01
    z[4,1,0]  R1127     -7.9583726823329926e-02
    z[4,1,0]  R1128     2.7869397774338722e-02
    z[4,1,0]  R1129     -2.1747012436389923e-01
    z[4,1,0]  R1130     2.2852631285786629e-02
    z[4,1,0]  R1131     1.7220035195350647e-01
    z[4,1,0]  R1132     2.2474895417690277e-01
    z[4,1,0]  R1133     -3.9130559563636780e-01
    z[4,1,0]  R1134     -4.8110938072204590e-01
    z[4,1,0]  R1135     3.1633594632148743e-01
    z[4,1,0]  R1136     6.5092794829979539e-04
    z[4,1,0]  R1137     3.6189493536949158e-01
    z[4,1,0]  R1138     -2.3062512278556824e-01
    z[4,1,0]  R1139     1.5377096831798553e-01
    z[4,1,0]  R1140     -1.4678399264812469e-01
    z[4,1,0]  R1141     -1.1018574982881546e-01
    z[4,1,0]  R1142     -7.4105983972549438e-01
    z[4,1,0]  R1143     -3.4644496440887451e-01
    z[4,1,0]  R1144     -3.0616229772567749e-01
    z[4,1,1]  R12       1
    z[4,1,1]  R39       -1
    z[4,1,1]  R1106     -1
    z[4,1,1]  R1107     1
    z[4,1,1]  R1118     -3.4159576892852783e-01
    z[4,1,1]  R1119     4.4207116961479187e-01
    z[4,1,1]  R1120     -3.6425170302391052e-01
    z[4,1,1]  R1121     5.7959675788879395e-02
    z[4,1,1]  R1122     -1.8813608912751079e-03
    z[4,1,1]  R1123     5.2941292524337769e-02
    z[4,1,1]  R1124     -1.3303664326667786e-01
    z[4,1,1]  R1125     3.6245518922805786e-01
    z[4,1,1]  R1126     -2.0048640668392181e-01
    z[4,1,1]  R1127     3.8528078794479370e-01
    z[4,1,1]  R1128     3.3962216973304749e-01
    z[4,1,1]  R1129     -2.6412123441696167e-01
    z[4,1,1]  R1130     -2.6405319571495056e-01
    z[4,1,1]  R1131     -3.0863621830940247e-01
    z[4,1,1]  R1132     -9.1000741720199585e-01
    z[4,1,1]  R1133     -5.7779359817504883e-01
    z[4,1,1]  R1134     -7.2239577770233154e-01
    z[4,1,1]  R1135     -1.3021700084209442e-01
    z[4,1,1]  R1136     -1.8559944629669189e-01
    z[4,1,1]  R1137     -3.5733491182327271e-02
    z[4,1,1]  R1138     2.3735000193119049e-01
    z[4,1,1]  R1139     2.7018073201179504e-01
    z[4,1,1]  R1140     3.2937890291213989e-01
    z[4,1,1]  R1141     1.8331421911716461e-01
    z[4,1,1]  R1142     3.8572159409523010e-01
    z[4,1,1]  R1143     5.4935926198959351e-01
    z[4,1,1]  R1144     5.8083051443099976e-01
    z[4,1,2]  R13       1
    z[4,1,2]  R40       -1
    z[4,1,2]  R1108     -1
    z[4,1,2]  R1109     1
    z[4,1,2]  R1118     -3.7890592217445374e-01
    z[4,1,2]  R1119     4.2208835482597351e-01
    z[4,1,2]  R1120     7.1080386638641357e-01
    z[4,1,2]  R1121     -3.9535153657197952e-02
    z[4,1,2]  R1122     -1.6089507937431335e-01
    z[4,1,2]  R1123     1.5210928022861481e-01
    z[4,1,2]  R1124     6.8489299155771732e-03
    z[4,1,2]  R1125     -2.4280132353305817e-01
    z[4,1,2]  R1126     -3.8911259174346924e-01
    z[4,1,2]  R1127     3.3616498112678528e-01
    z[4,1,2]  R1128     1.9201441109180450e-01
    z[4,1,2]  R1129     -0.211082324385643
    z[4,1,2]  R1130     5.0174808502197266e-01
    z[4,1,2]  R1131     9.4765760004520416e-02
    z[4,1,2]  R1132     -1.2549269199371338e-01
    z[4,1,2]  R1133     5.6650322675704956e-01
    z[4,1,2]  R1134     2.4162469804286957e-01
    z[4,1,2]  R1135     1.5392532944679260e-01
    z[4,1,2]  R1136     -1.1897242814302444e-01
    z[4,1,2]  R1137     0.45625039935112
    z[4,1,2]  R1138     -1.4246310293674469e-01
    z[4,1,2]  R1139     1.6092897951602936e-01
    z[4,1,2]  R1140     2.2043561935424805e-01
    z[4,1,2]  R1141     1.3189366459846497e-01
    z[4,1,2]  R1142     -3.7291178107261658e-01
    z[4,1,2]  R1143     -5.5576390027999878e-01
    z[4,1,2]  R1144     -5.5670505762100220e-01
    z[4,1,3]  R14       1
    z[4,1,3]  R41       -1
    z[4,1,3]  R1110     -1
    z[4,1,3]  R1111     1
    z[4,1,3]  R1118     7.4422317743301392e-01
    z[4,1,3]  R1119     2.4902540445327759e-01
    z[4,1,3]  R1120     6.2218014150857925e-02
    z[4,1,3]  R1121     2.1696844696998596e-01
    z[4,1,3]  R1122     -6.5100783109664917e-01
    z[4,1,3]  R1123     -8.7795192003250122e-01
    z[4,1,3]  R1124     -4.7661110758781433e-01
    z[4,1,3]  R1125     6.9761854410171509e-01
    z[4,1,3]  R1126     7.0579981803894043e-01
    z[4,1,3]  R1127     7.0265442132949829e-01
    z[4,1,3]  R1128     8.3274716138839722e-01
    z[4,1,3]  R1129     8.3575522899627686e-01
    z[4,1,3]  R1130     6.8083167076110840e-01
    z[4,1,3]  R1131     4.4157034158706665e-01
    z[4,1,3]  R1132     -1.1593621969223022e-01
    z[4,1,3]  R1133     -0.0922110453248024
    z[4,1,3]  R1134     -0.0977182611823082
    z[4,1,3]  R1135     -8.8844668865203857e-01
    z[4,1,3]  R1136     -7.7384406328201294e-01
    z[4,1,3]  R1137     -5.3013539314270020e-01
    z[4,1,3]  R1138     -4.3950146436691284e-01
    z[4,1,3]  R1139     -3.7368568778038025e-01
    z[4,1,3]  R1140     -4.1142952442169189e-01
    z[4,1,3]  R1141     -3.6310148239135742e-01
    z[4,1,3]  R1142     -2.4321369826793671e-01
    z[4,1,3]  R1143     -2.4231983721256256e-01
    z[4,1,3]  R1144     -2.5232541561126709e-01
    z[4,1,4]  R15       1
    z[4,1,4]  R42       -1
    z[4,1,4]  R1112     -1
    z[4,1,4]  R1113     1
    z[4,1,4]  R1118     3.2042428851127625e-01
    z[4,1,4]  R1119     3.3340302109718323e-01
    z[4,1,4]  R1120     8.4792442619800568e-02
    z[4,1,4]  R1121     -9.2411078512668610e-02
    z[4,1,4]  R1122     3.4073132276535034e-01
    z[4,1,4]  R1123     -3.8112181425094604e-01
    z[4,1,4]  R1124     -1.6519330441951752e-01
    z[4,1,4]  R1125     3.9406582713127136e-01
    z[4,1,4]  R1126     4.5046284794807434e-01
    z[4,1,4]  R1127     0.486801415681839
    z[4,1,4]  R1128     -2.4763226509094238e-01
    z[4,1,4]  R1129     -1.4636451005935669e-01
    z[4,1,4]  R1130     4.3101231567561626e-03
    z[4,1,4]  R1131     4.7685602307319641e-01
    z[4,1,4]  R1132     -4.4916570186614990e-03
    z[4,1,4]  R1133     -3.2263353466987610e-01
    z[4,1,4]  R1134     -2.9715770483016968e-01
    z[4,1,4]  R1135     1.1608657240867615e-01
    z[4,1,4]  R1136     -4.9887317419052124e-01
    z[4,1,4]  R1137     5.0323802232742310e-01
    z[4,1,4]  R1138     -0.346293181180954
    z[4,1,4]  R1139     -4.7331359982490540e-01
    z[4,1,4]  R1140     -3.8748362660408020e-01
    z[4,1,4]  R1141     -5.0233131647109985e-01
    z[4,1,4]  R1142     -1.5805552899837494e-01
    z[4,1,4]  R1143     -0.0805695503950119
    z[4,1,4]  R1144     -2.3558795452117920e-01
    z[4,1,5]  R16       1
    z[4,1,5]  R43       -1
    z[4,1,5]  R1114     -1
    z[4,1,5]  R1115     1
    z[4,1,5]  R1118     -1.8587963283061981e-01
    z[4,1,5]  R1119     -1.5794233977794647e-01
    z[4,1,5]  R1120     -3.5428476333618164e-01
    z[4,1,5]  R1121     0.590069055557251
    z[4,1,5]  R1122     5.8619880676269531e-01
    z[4,1,5]  R1123     -2.1884655952453613e-01
    z[4,1,5]  R1124     2.6538777351379395e-01
    z[4,1,5]  R1125     -3.6901223659515381e-01
    z[4,1,5]  R1126     -1.1600410193204880e-01
    z[4,1,5]  R1127     3.2378707081079483e-02
    z[4,1,5]  R1128     -2.1641814708709717e-01
    z[4,1,5]  R1129     -2.5121828913688660e-01
    z[4,1,5]  R1130     -4.3281629681587219e-01
    z[4,1,5]  R1131     -6.6607022285461426e-01
    z[4,1,5]  R1132     2.8251004219055176e-01
    z[4,1,5]  R1133     -2.8031954169273376e-01
    z[4,1,5]  R1134     -1.6167476773262024e-01
    z[4,1,5]  R1135     -8.3953499794006348e-02
    z[4,1,5]  R1136     -3.1239360570907593e-01
    z[4,1,5]  R1137     2.3754407465457916e-01
    z[4,1,5]  R1138     7.4026662111282349e-01
    z[4,1,5]  R1139     6.6615206003189087e-01
    z[4,1,5]  R1140     6.8987190723419189e-01
    z[4,1,5]  R1141     7.4313873052597046e-01
    z[4,1,5]  R1142     2.6337283849716187e-01
    z[4,1,5]  R1143     3.8477602601051331e-01
    z[4,1,5]  R1144     2.8918406367301941e-01
    z[4,1,6]  R17       1
    z[4,1,6]  R44       -1
    z[4,1,6]  R1116     -1
    z[4,1,6]  R1117     1
    z[4,1,6]  R1118     -5.5428370833396912e-02
    z[4,1,6]  R1119     -4.7022271156311035e-01
    z[4,1,6]  R1120     4.7025975584983826e-01
    z[4,1,6]  R1121     0.768604576587677
    z[4,1,6]  R1122     6.7947648465633392e-02
    z[4,1,6]  R1123     3.6858968436717987e-02
    z[4,1,6]  R1124     -0.680474042892456
    z[4,1,6]  R1125     1.5975877642631531e-01
    z[4,1,6]  R1126     1.5552735328674316e-01
    z[4,1,6]  R1127     -2.1702274680137634e-02
    z[4,1,6]  R1128     -2.1303531527519226e-01
    z[4,1,6]  R1129     2.3531040549278259e-01
    z[4,1,6]  R1130     -1.6468851268291473e-01
    z[4,1,6]  R1131     9.1937407851219177e-03
    z[4,1,6]  R1132     1.1114278435707092e-01
    z[4,1,6]  R1133     3.0565917491912842e-02
    z[4,1,6]  R1134     2.5358486175537109e-01
    z[4,1,6]  R1135     -2.2230693697929382e-01
    z[4,1,6]  R1136     -7.8097254037857056e-02
    z[4,1,6]  R1137     -0.262433797121048
    z[4,1,6]  R1138     0.0954258143901825
    z[4,1,6]  R1139     2.6463833451271057e-01
    z[4,1,6]  R1140     1.6134175658226013e-01
    z[4,1,6]  R1141     -2.0603444427251816e-02
    z[4,1,6]  R1142     9.7397871315479279e-02
    z[4,1,6]  R1143     -2.3673607409000397e-01
    z[4,1,6]  R1144     2.3702910542488098e-01
    z[2,5,0]  R20       -1
    z[2,5,0]  R47       1
    z[2,5,0]  R1145     -1
    z[2,5,0]  R1146     1
    z[2,5,0]  R1159     8.8604754209518433e-01
    z[2,5,0]  R1160     1.4583480358123779e-01
    z[2,5,0]  R1161     7.9103827476501465e-01
    z[2,5,0]  R1162     8.7183523178100586e-01
    z[2,5,0]  R1163     0.828798770904541
    z[2,5,0]  R1164     8.3446949720382690e-01
    z[2,5,0]  R1165     8.2140040397644043e-01
    z[2,5,0]  R1166     3.2014328241348267e-01
    z[2,5,0]  R1167     -5.8035325258970261e-02
    z[2,5,0]  R1168     7.2002267837524414e-01
    z[2,5,0]  R1169     -3.5881298780441284e-01
    z[2,5,0]  R1170     -4.7988590598106384e-01
    z[2,5,0]  R1171     -1.5419688820838928e-01
    z[2,5,0]  R1172     -7.5405031442642212e-01
    z[2,5,0]  R1173     -6.8363982439041138e-01
    z[2,5,0]  R1174     -4.0264037251472473e-01
    z[2,5,0]  R1175     -0.772131085395813
    z[2,5,0]  R1176     -7.4872213602066040e-01
    z[2,5,0]  R1177     -2.5317719578742981e-01
    z[2,5,0]  R1178     -7.6686137914657593e-01
    z[2,5,0]  R1179     4.8272699117660522e-02
    z[2,5,0]  R1180     -2.3450122773647308e-01
    z[2,5,0]  R1181     4.4383369386196136e-02
    z[2,5,0]  R1182     -1.6060508787631989e-01
    z[2,5,0]  R1183     3.9612289518117905e-02
    z[2,5,0]  R1184     -9.2905491590499878e-02
    z[2,5,0]  R1185     -7.7253989875316620e-02
    z[2,5,0]  R1186     -4.0585073828697205e-01
    z[2,5,0]  R1187     3.5294704139232635e-02
    z[2,5,0]  R1188     -1.3486324250698090e-01
    z[2,5,0]  R1189     1.8007567524909973e-01
    z[2,5,0]  R1190     1.6546323604416102e-04
    z[2,5,0]  R1191     2.5776728987693787e-01
    z[2,5,0]  R1192     -4.1691058874130249e-01
    z[2,5,0]  R1193     -2.6028215885162354e-01
    z[2,5,0]  R1194     6.9311964511871338e-01
    z[2,5,0]  R1195     -4.1471680998802185e-01
    z[2,5,0]  R1196     -5.6344783306121826e-01
    z[2,5,0]  R1197     -4.9564579129219055e-01
    z[2,5,0]  R1198     -1.3505442440509796e-01
    z[2,5,0]  R1199     -0.564138650894165
    z[2,5,0]  R1200     3.5655394196510315e-01
    z[2,5,0]  R1201     1.7037992179393768e-01
    z[2,5,0]  R1202     -1.5335051715373993e-01
    z[2,5,0]  R1203     -3.0667927861213684e-01
    z[2,5,0]  R1204     -2.1232496201992035e-01
    z[2,5,0]  R1205     8.5173296928405762e-01
    z[2,5,0]  R1206     8.8291460275650024e-01
    z[2,5,0]  R1207     0.199258491396904
    z[2,5,0]  R1208     -1.7429096996784210e-01
    z[2,5,0]  R1209     2.3610081523656845e-02
    z[2,5,0]  R1210     -3.2982969284057617e-01
    z[2,5,0]  R1211     6.9847536087036133e-01
    z[2,5,0]  R1212     -4.6365892887115479e-01
    z[2,5,0]  R1213     1.2046752125024796e-01
    z[2,5,0]  R1214     -0.527647852897644
    z[2,5,0]  R1215     2.2033995389938354e-01
    z[2,5,0]  R1216     2.4991865456104279e-01
    z[2,5,0]  R1217     -0.868701696395874
    z[2,5,0]  R1218     -2.1660651266574860e-01
    z[2,5,0]  R1219     8.6552582681179047e-02
    z[2,5,0]  R1220     -2.6703274250030518e-01
    z[2,5,0]  R1221     -4.2324659228324890e-01
    z[2,5,0]  R1222     2.0893737673759460e-01
    z[2,5,0]  R1223     2.3474301397800446e-01
    z[2,5,0]  R1224     3.7857976555824280e-01
    z[2,5,0]  R1225     -3.1002092361450195e-01
    z[2,5,0]  R1226     1.0676967352628708e-01
    z[2,5,0]  R1227     -0.282500684261322
    z[2,5,0]  R1228     1.3480694591999054e-01
    z[2,5,0]  R1229     6.3620336353778839e-02
    z[2,5,0]  R1230     3.7411540746688843e-01
    z[2,5,0]  R1231     0.309985488653183
    z[2,5,0]  R1232     2.2376090288162231e-01
    z[2,5,0]  R1233     1.9197373092174530e-01
    z[2,5,0]  R1234     5.7358872890472412e-01
    z[2,5,0]  R1235     -5.3023308515548706e-01
    z[2,5,0]  R1236     1.0566161572933197e-01
    z[2,5,0]  R1237     4.4696331024169922e-01
    z[2,5,0]  R1238     5.0492811203002930e-01
    z[2,5,0]  R1239     5.1830720901489258e-01
    z[2,5,0]  R1240     2.6020705699920654e-01
    z[2,5,0]  R1241     2.9869771003723145e-01
    z[2,5,0]  R1242     4.1372036933898926e-01
    z[2,5,0]  R1243     2.6807132363319397e-01
    z[2,5,0]  R1244     4.8167598247528076e-01
    z[2,5,0]  R1245     3.8679200410842896e-01
    z[2,5,0]  R1246     -6.5046213567256927e-02
    z[2,5,0]  R1247     -1.6289213672280312e-02
    z[2,5,0]  R1248     -4.6963214874267578e-01
    z[2,5,0]  R1249     7.6995509862899780e-01
    z[2,5,0]  R1250     4.8069155216217041e-01
    z[2,5,0]  R1251     -1.7894135415554047e-01
    z[2,5,0]  R1252     -1.6504043340682983e-01
    z[2,5,0]  R1253     -1.3117472827434540e-01
    z[2,5,0]  R1254     8.0199085175991058e-02
    z[2,5,0]  R1255     -0.0911993533372879
    z[2,5,0]  R1256     -1.5107788145542145e-01
    z[2,5,0]  R1257     -2.3619601130485535e-01
    z[2,5,0]  R1258     3.3547326922416687e-01
    z[2,5,1]  R21       -1
    z[2,5,1]  R48       1
    z[2,5,1]  R1147     -1
    z[2,5,1]  R1148     1
    z[2,5,1]  R1159     -2.0820298790931702e-01
    z[2,5,1]  R1160     -2.4536137282848358e-01
    z[2,5,1]  R1161     -1.8139237165451050e-01
    z[2,5,1]  R1162     -6.7742630839347839e-02
    z[2,5,1]  R1163     2.2924799472093582e-02
    z[2,5,1]  R1164     -1.3303156197071075e-01
    z[2,5,1]  R1165     -1.2285141646862030e-01
    z[2,5,1]  R1166     -1.8322411179542542e-01
    z[2,5,1]  R1167     -2.3186931014060974e-01
    z[2,5,1]  R1168     -1.5166489779949188e-01
    z[2,5,1]  R1169     7.7723509073257446e-01
    z[2,5,1]  R1170     6.2624263763427734e-01
    z[2,5,1]  R1171     8.9889067411422729e-01
    z[2,5,1]  R1172     4.2762383818626404e-01
    z[2,5,1]  R1173     3.5715842247009277e-01
    z[2,5,1]  R1174     0.71956866979599
    z[2,5,1]  R1175     0.166547030210495
    z[2,5,1]  R1176     1.8764916062355042e-01
    z[2,5,1]  R1177     8.6886739730834961e-01
    z[2,5,1]  R1178     2.7385982871055603e-01
    z[2,5,1]  R1179     -9.1263711452484131e-01
    z[2,5,1]  R1180     -8.6090552806854248e-01
    z[2,5,1]  R1181     -7.9708242416381836e-01
    z[2,5,1]  R1182     -7.9676896333694458e-01
    z[2,5,1]  R1183     -8.3311569690704346e-01
    z[2,5,1]  R1184     -8.7095212936401367e-01
    z[2,5,1]  R1185     -0.763202428817749
    z[2,5,1]  R1186     -7.7917784452438354e-01
    z[2,5,1]  R1187     -0.824566125869751
    z[2,5,1]  R1188     -6.9372671842575073e-01
    z[2,5,1]  R1189     -0.659796953201294
    z[2,5,1]  R1190     -4.9183964729309082e-01
    z[2,5,1]  R1191     -5.3227448463439941e-01
    z[2,5,1]  R1192     -1.8455389142036438e-01
    z[2,5,1]  R1193     -2.4131046235561371e-01
    z[2,5,1]  R1194     -5.4709357023239136e-01
    z[2,5,1]  R1195     -5.6468397378921509e-01
    z[2,5,1]  R1196     5.1037472486495972e-01
    z[2,5,1]  R1197     -0.705713152885437
    z[2,5,1]  R1198     1.6149090230464935e-01
    z[2,5,1]  R1199     -4.5664042234420776e-01
    z[2,5,1]  R1200     -3.6807930469512939e-01
    z[2,5,1]  R1201     -2.4916736781597137e-01
    z[2,5,1]  R1202     3.8674041628837585e-01
    z[2,5,1]  R1203     0.219456747174263
    z[2,5,1]  R1204     4.7260022163391113e-01
    z[2,5,1]  R1205     -2.6977792382240295e-01
    z[2,5,1]  R1206     -1.5420758724212646e-01
    z[2,5,1]  R1207     6.4654910564422607e-01
    z[2,5,1]  R1208     4.7253987193107605e-01
    z[2,5,1]  R1209     1.4519819058477879e-02
    z[2,5,1]  R1210     -5.6691801548004150e-01
    z[2,5,1]  R1211     -4.2047610878944397e-01
    z[2,5,1]  R1212     7.2132611274719238e-01
    z[2,5,1]  R1213     -4.8361968994140625e-01
    z[2,5,1]  R1214     2.6444411277770996e-01
    z[2,5,1]  R1215     -9.6356995403766632e-02
    z[2,5,1]  R1216     -5.6525218486785889e-01
    z[2,5,1]  R1217     2.6983615756034851e-01
    z[2,5,1]  R1218     -2.4216964840888977e-01
    z[2,5,1]  R1219     -7.1035593748092651e-01
    z[2,5,1]  R1220     -6.9905835390090942e-01
    z[2,5,1]  R1221     7.4038130044937134e-01
    z[2,5,1]  R1222     -4.5106706023216248e-01
    z[2,5,1]  R1223     3.1020686030387878e-01
    z[2,5,1]  R1224     1.9607998430728912e-01
    z[2,5,1]  R1225     2.8569355607032776e-02
    z[2,5,1]  R1226     -0.0813002958893776
    z[2,5,1]  R1227     -3.0414137244224548e-01
    z[2,5,1]  R1228     1.0632056742906570e-01
    z[2,5,1]  R1229     2.1285678446292877e-01
    z[2,5,1]  R1230     -2.0423457026481628e-01
    z[2,5,1]  R1231     1.9847913086414337e-01
    z[2,5,1]  R1232     -2.6865140534937382e-03
    z[2,5,1]  R1233     1.7888420820236206e-01
    z[2,5,1]  R1234     2.1807121112942696e-02
    z[2,5,1]  R1235     1.6930523561313748e-03
    z[2,5,1]  R1236     5.4403698444366455e-01
    z[2,5,1]  R1237     8.5394734144210815e-01
    z[2,5,1]  R1238     5.2414888143539429e-01
    z[2,5,1]  R1239     -4.4503325223922729e-01
    z[2,5,1]  R1240     -5.0822061300277710e-01
    z[2,5,1]  R1241     -2.2731699049472809e-02
    z[2,5,1]  R1242     1.3671897351741791e-01
    z[2,5,1]  R1243     6.8114958703517914e-02
    z[2,5,1]  R1244     -1.7794659733772278e-01
    z[2,5,1]  R1245     -4.3558841943740845e-01
    z[2,5,1]  R1246     -0.775583803653717
    z[2,5,1]  R1247     -6.7599415779113770e-01
    z[2,5,1]  R1248     -7.6074421405792236e-01
    z[2,5,1]  R1249     3.2440826296806335e-01
    z[2,5,1]  R1250     3.7659278512001038e-01
    z[2,5,1]  R1251     -2.2676189243793488e-01
    z[2,5,1]  R1252     -1.5134532749652863e-01
    z[2,5,1]  R1253     4.4075556099414825e-02
    z[2,5,1]  R1254     -7.0459681749343872e-01
    z[2,5,1]  R1255     -4.2690876871347427e-02
    z[2,5,1]  R1256     -7.1568185091018677e-01
    z[2,5,1]  R1257     -2.0943626761436462e-01
    z[2,5,1]  R1258     8.2062435150146484e-01
    z[2,5,2]  R22       -1
    z[2,5,2]  R49       1
    z[2,5,2]  R1149     -1
    z[2,5,2]  R1150     1
    z[2,5,2]  R1159     0.0910937711596489
    z[2,5,2]  R1160     8.6018282175064087e-01
    z[2,5,2]  R1161     4.2260631918907166e-01
    z[2,5,2]  R1162     -4.1567340493202209e-02
    z[2,5,2]  R1163     3.7105602025985718e-01
    z[2,5,2]  R1164     4.1188856959342957e-01
    z[2,5,2]  R1165     -0.0768071785569191
    z[2,5,2]  R1166     9.0562599897384644e-01
    z[2,5,2]  R1167     9.0104812383651733e-01
    z[2,5,2]  R1168     -0.0647159144282341
    z[2,5,2]  R1169     -2.9394480586051941e-01
    z[2,5,2]  R1170     -3.2875162363052368e-01
    z[2,5,2]  R1171     -3.6022484302520752e-01
    z[2,5,2]  R1172     -2.7992677688598633e-01
    z[2,5,2]  R1173     -4.0945509076118469e-01
    z[2,5,2]  R1174     -3.1449410319328308e-01
    z[2,5,2]  R1175     -2.1376132965087891e-01
    z[2,5,2]  R1176     -4.1909557580947876e-01
    z[2,5,2]  R1177     -1.9536575675010681e-01
    z[2,5,2]  R1178     -1.6567899286746979e-01
    z[2,5,2]  R1179     2.1565565839409828e-02
    z[2,5,2]  R1180     1.8663156032562256e-01
    z[2,5,2]  R1181     1.1444225907325745e-01
    z[2,5,2]  R1182     1.7330738902091980e-01
    z[2,5,2]  R1183     1.9123714417219162e-02
    z[2,5,2]  R1184     2.7071169018745422e-01
    z[2,5,2]  R1185     5.5021595209836960e-02
    z[2,5,2]  R1186     -8.9638732373714447e-02
    z[2,5,2]  R1187     -1.2983185052871704e-01
    z[2,5,2]  R1188     0.456155925989151
    z[2,5,2]  R1189     6.8963599205017090e-01
    z[2,5,2]  R1190     3.6888051033020020e-01
    z[2,5,2]  R1191     4.8535147309303284e-01
    z[2,5,2]  R1192     5.2804708480834961e-01
    z[2,5,2]  R1193     5.0944548845291138e-01
    z[2,5,2]  R1194     -3.9497545361518860e-01
    z[2,5,2]  R1195     2.5180166959762573e-01
    z[2,5,2]  R1196     -2.9711747169494629e-01
    z[2,5,2]  R1197     3.3206200599670410e-01
    z[2,5,2]  R1198     -8.2156014442443848e-01
    z[2,5,2]  R1199     5.9368723630905151e-01
    z[2,5,2]  R1200     3.6254769563674927e-01
    z[2,5,2]  R1201     0.542304515838623
    z[2,5,2]  R1202     -6.8246215581893921e-01
    z[2,5,2]  R1203     -6.6549074649810791e-01
    z[2,5,2]  R1204     -6.3054847717285156e-01
    z[2,5,2]  R1205     -2.1745751798152924e-01
    z[2,5,2]  R1206     -7.5013250112533569e-02
    z[2,5,2]  R1207     -5.2669900655746460e-01
    z[2,5,2]  R1208     -4.9416157603263855e-01
    z[2,5,2]  R1209     7.6543998718261719e-01
    z[2,5,2]  R1210     3.4518721699714661e-01
    z[2,5,2]  R1211     -5.2202981710433960e-01
    z[2,5,2]  R1212     -0.376355916261673
    z[2,5,2]  R1213     1.5767641365528107e-01
    z[2,5,2]  R1214     -7.2714775800704956e-01
    z[2,5,2]  R1215     4.8233687877655029e-01
    z[2,5,2]  R1216     3.7854695320129395e-01
    z[2,5,2]  R1217     -6.1420563608407974e-02
    z[2,5,2]  R1218     3.6835893988609314e-01
    z[2,5,2]  R1219     5.4648733139038086e-01
    z[2,5,2]  R1220     4.1992199420928955e-01
    z[2,5,2]  R1221     -0.415484219789505
    z[2,5,2]  R1222     5.0685596466064453e-01
    z[2,5,2]  R1223     4.7984153032302856e-01
    z[2,5,2]  R1224     -4.0168985724449158e-01
    z[2,5,2]  R1225     -0.302696168422699
    z[2,5,2]  R1226     -1.9866585731506348e-01
    z[2,5,2]  R1227     -5.0169765949249268e-01
    z[2,5,2]  R1228     -2.9586029052734375e-01
    z[2,5,2]  R1229     0.376784086227417
    z[2,5,2]  R1230     3.3700317144393921e-01
    z[2,5,2]  R1231     0.441354900598526
    z[2,5,2]  R1232     -2.8998634219169617e-01
    z[2,5,2]  R1233     3.4507983922958374e-01
    z[2,5,2]  R1234     -4.0886303782463074e-01
    z[2,5,2]  R1235     4.8193186521530151e-01
    z[2,5,2]  R1236     3.1942182779312134e-01
    z[2,5,2]  R1237     -1.6876170411705971e-02
    z[2,5,2]  R1238     -3.4552210569381714e-01
    z[2,5,2]  R1239     2.6598111726343632e-03
    z[2,5,2]  R1240     -2.0064075291156769e-01
    z[2,5,2]  R1241     -8.2659468054771423e-02
    z[2,5,2]  R1242     3.5662662982940674e-01
    z[2,5,2]  R1243     -2.9090091586112976e-01
    z[2,5,2]  R1244     -2.6795518398284912e-01
    z[2,5,2]  R1245     4.9454793334007263e-01
    z[2,5,2]  R1246     4.2323939502239227e-02
    z[2,5,2]  R1247     2.4845432490110397e-02
    z[2,5,2]  R1248     -6.6998414695262909e-02
    z[2,5,2]  R1249     2.8627347946166992e-01
    z[2,5,2]  R1250     -2.3177672922611237e-01
    z[2,5,2]  R1251     2.3166167736053467e-01
    z[2,5,2]  R1252     2.1681115031242371e-01
    z[2,5,2]  R1253     -3.7851881235837936e-02
    z[2,5,2]  R1254     0.0953143835067749
    z[2,5,2]  R1255     4.1084265708923340e-01
    z[2,5,2]  R1256     3.4106969833374023e-01
    z[2,5,2]  R1257     5.6632423400878906e-01
    z[2,5,2]  R1258     -1.4988601207733154e-01
    z[2,5,3]  R23       -1
    z[2,5,3]  R50       1
    z[2,5,3]  R1151     -1
    z[2,5,3]  R1152     1
    z[2,5,3]  R1159     3.6288830637931824e-01
    z[2,5,3]  R1160     2.6031108573079109e-02
    z[2,5,3]  R1161     3.5282278060913086e-01
    z[2,5,3]  R1162     3.7063917517662048e-01
    z[2,5,3]  R1163     3.4668728709220886e-01
    z[2,5,3]  R1164     0.280091255903244
    z[2,5,3]  R1165     3.0276027321815491e-01
    z[2,5,3]  R1166     -0.0650770291686058
    z[2,5,3]  R1167     1.5361729077994823e-02
    z[2,5,3]  R1168     3.7681087851524353e-01
    z[2,5,3]  R1169     -1.1669117212295532e-01
    z[2,5,3]  R1170     -2.6099857687950134e-01
    z[2,5,3]  R1171     -1.2423708289861679e-01
    z[2,5,3]  R1172     -1.9255127012729645e-01
    z[2,5,3]  R1173     -1.3361001014709473e-01
    z[2,5,3]  R1174     -3.3215454220771790e-01
    z[2,5,3]  R1175     -1.3045512139797211e-01
    z[2,5,3]  R1176     -3.0237317085266113e-01
    z[2,5,3]  R1177     -1.8618687987327576e-01
    z[2,5,3]  R1178     -2.9385924339294434e-01
    z[2,5,3]  R1179     1.7202377319335938e-01
    z[2,5,3]  R1180     3.0013132095336914e-01
    z[2,5,3]  R1181     3.1678459048271179e-01
    z[2,5,3]  R1182     5.1525235176086426e-01
    z[2,5,3]  R1183     1.6616627573966980e-02
    z[2,5,3]  R1184     -2.5784291326999664e-02
    z[2,5,3]  R1185     2.7257108688354492e-01
    z[2,5,3]  R1186     3.2830587029457092e-01
    z[2,5,3]  R1187     1.7882893979549408e-01
    z[2,5,3]  R1188     -7.8448191285133362e-02
    z[2,5,3]  R1189     2.0064114034175873e-01
    z[2,5,3]  R1190     -1.5162938833236694e-01
    z[2,5,3]  R1191     -7.9044135054573417e-04
    z[2,5,3]  R1192     -2.9002451896667480e-01
    z[2,5,3]  R1193     -6.2565606832504272e-01
    z[2,5,3]  R1194     0.141846165060997
    z[2,5,3]  R1195     -1.3586845993995667e-01
    z[2,5,3]  R1196     -2.4493041634559631e-01
    z[2,5,3]  R1197     8.6284153163433075e-02
    z[2,5,3]  R1198     -3.9184951782226562e-01
    z[2,5,3]  R1199     -1.4163862168788910e-01
    z[2,5,3]  R1200     -6.7420870065689087e-01
    z[2,5,3]  R1201     3.4459149837493896e-01
    z[2,5,3]  R1202     -1.3506361842155457e-01
    z[2,5,3]  R1203     -4.0715873241424561e-01
    z[2,5,3]  R1204     -1.5841390192508698e-01
    z[2,5,3]  R1205     -4.7076758928596973e-03
    z[2,5,3]  R1206     -2.6557031273841858e-01
    z[2,5,3]  R1207     -1.9811186194419861e-01
    z[2,5,3]  R1208     -1.9661815464496613e-01
    z[2,5,3]  R1209     -5.2235692739486694e-01
    z[2,5,3]  R1210     -4.6523699164390564e-01
    z[2,5,3]  R1211     1.6508273780345917e-01
    z[2,5,3]  R1212     -1.6416238248348236e-01
    z[2,5,3]  R1213     -2.9310640692710876e-01
    z[2,5,3]  R1214     -2.4496681988239288e-01
    z[2,5,3]  R1215     -8.1528216600418091e-01
    z[2,5,3]  R1216     -7.7290818095207214e-02
    z[2,5,3]  R1217     -2.4361704289913177e-01
    z[2,5,3]  R1218     -6.9557827711105347e-01
    z[2,5,3]  R1219     2.0319934189319611e-01
    z[2,5,3]  R1220     -6.2119122594594955e-03
    z[2,5,3]  R1221     -1.5458916127681732e-01
    z[2,5,3]  R1222     -9.3709513545036316e-02
    z[2,5,3]  R1223     2.6010328531265259e-01
    z[2,5,3]  R1224     -7.3046904802322388e-01
    z[2,5,3]  R1225     -6.6346544027328491e-01
    z[2,5,3]  R1226     -6.2754082679748535e-01
    z[2,5,3]  R1227     -1.7004366219043732e-01
    z[2,5,3]  R1228     -0.610435426235199
    z[2,5,3]  R1229     8.3240544795989990e-01
    z[2,5,3]  R1230     8.0293715000152588e-01
    z[2,5,3]  R1231     6.8090802431106567e-01
    z[2,5,3]  R1232     8.0558454990386963e-01
    z[2,5,3]  R1233     5.7945418357849121e-01
    z[2,5,3]  R1234     0.56508868932724
    z[2,5,3]  R1235     -5.6946748495101929e-01
    z[2,5,3]  R1236     -3.4010595083236694e-01
    z[2,5,3]  R1237     -9.2337392270565033e-02
    z[2,5,3]  R1238     -5.4880219697952271e-01
    z[2,5,3]  R1239     -6.8824869394302368e-01
    z[2,5,3]  R1240     -6.2659960985183716e-01
    z[2,5,3]  R1241     -8.8128763437271118e-01
    z[2,5,3]  R1242     -6.7467993497848511e-01
    z[2,5,3]  R1243     -6.4485955238342285e-01
    z[2,5,3]  R1244     -4.6592471003532410e-01
    z[2,5,3]  R1245     -0.272337943315506
    z[2,5,3]  R1246     -2.8358227014541626e-01
    z[2,5,3]  R1247     -2.9915022850036621e-01
    z[2,5,3]  R1248     1.7128208652138710e-02
    z[2,5,3]  R1249     2.4524433910846710e-01
    z[2,5,3]  R1250     5.5213207006454468e-01
    z[2,5,3]  R1251     -8.9250606298446655e-01
    z[2,5,3]  R1252     -8.3397108316421509e-01
    z[2,5,3]  R1253     0.740169107913971
    z[2,5,3]  R1254     -4.4767311215400696e-01
    z[2,5,3]  R1255     -7.2580933570861816e-01
    z[2,5,3]  R1256     -4.7706350684165955e-01
    z[2,5,3]  R1257     -0.359017938375473
    z[2,5,3]  R1258     1.7761951684951782e-01
    z[2,5,4]  R24       -1
    z[2,5,4]  R51       1
    z[2,5,4]  R1153     -1
    z[2,5,4]  R1154     1
    z[2,5,4]  R1159     -1.0050161927938461e-01
    z[2,5,4]  R1160     1.0758806765079498e-01
    z[2,5,4]  R1161     1.4761133491992950e-01
    z[2,5,4]  R1162     2.3139512538909912e-01
    z[2,5,4]  R1163     1.8747209012508392e-01
    z[2,5,4]  R1164     0.0691203773021698
    z[2,5,4]  R1165     3.6277133226394653e-01
    z[2,5,4]  R1166     -9.3559734523296356e-02
    z[2,5,4]  R1167     3.5093545913696289e-01
    z[2,5,4]  R1168     2.8707376122474670e-01
    z[2,5,4]  R1169     -2.1543622016906738e-01
    z[2,5,4]  R1170     -1.2187865376472473e-01
    z[2,5,4]  R1171     3.2665453851222992e-02
    z[2,5,4]  R1172     -6.5461009740829468e-02
    z[2,5,4]  R1173     -2.3137234151363373e-01
    z[2,5,4]  R1174     1.4333372004330158e-02
    z[2,5,4]  R1175     -3.0005258321762085e-01
    z[2,5,4]  R1176     -1.8443909287452698e-01
    z[2,5,4]  R1177     -2.4288322031497955e-01
    z[2,5,4]  R1178     -1.9801400601863861e-02
    z[2,5,4]  R1179     2.8166922926902771e-01
    z[2,5,4]  R1180     1.3172371685504913e-01
    z[2,5,4]  R1181     4.6188560128211975e-01
    z[2,5,4]  R1182     4.0505036711692810e-02
    z[2,5,4]  R1183     0.454078733921051
    z[2,5,4]  R1184     -2.6080831885337830e-02
    z[2,5,4]  R1185     2.5098109245300293e-01
    z[2,5,4]  R1186     3.0422726273536682e-01
    z[2,5,4]  R1187     4.6035513281822205e-02
    z[2,5,4]  R1188     -2.6826274394989014e-01
    z[2,5,4]  R1189     -8.3375498652458191e-02
    z[2,5,4]  R1190     -3.6722859740257263e-01
    z[2,5,4]  R1191     2.6221892237663269e-01
    z[2,5,4]  R1192     -4.3608167767524719e-01
    z[2,5,4]  R1193     -2.8397905826568604e-01
    z[2,5,4]  R1194     1.5624053776264191e-01
    z[2,5,4]  R1195     3.8545615971088409e-02
    z[2,5,4]  R1196     -0.513958215713501
    z[2,5,4]  R1197     -5.2396561950445175e-02
    z[2,5,4]  R1198     -1.1542411148548126e-01
    z[2,5,4]  R1199     -7.3523811995983124e-02
    z[2,5,4]  R1200     -1.7473040521144867e-01
    z[2,5,4]  R1201     3.3437156677246094e-01
    z[2,5,4]  R1202     -3.5563436150550842e-01
    z[2,5,4]  R1203     2.3139014840126038e-01
    z[2,5,4]  R1204     5.3134876489639282e-01
    z[2,5,4]  R1205     -3.8897490501403809e-01
    z[2,5,4]  R1206     -2.6186376810073853e-01
    z[2,5,4]  R1207     -1.6237211227416992e-01
    z[2,5,4]  R1208     -2.4907091632485390e-02
    z[2,5,4]  R1209     1.4272421598434448e-01
    z[2,5,4]  R1210     -3.6843821406364441e-02
    z[2,5,4]  R1211     -1.8145012855529785e-01
    z[2,5,4]  R1212     7.4807085096836090e-02
    z[2,5,4]  R1213     2.5480762124061584e-01
    z[2,5,4]  R1214     -3.4952532500028610e-02
    z[2,5,4]  R1215     5.3019434213638306e-02
    z[2,5,4]  R1216     5.8762248605489731e-02
    z[2,5,4]  R1217     -3.1292009353637695e-01
    z[2,5,4]  R1218     -3.2390853762626648e-01
    z[2,5,4]  R1219     1.4266617596149445e-01
    z[2,5,4]  R1220     -4.0367400646209717e-01
    z[2,5,4]  R1221     1.3523253798484802e-01
    z[2,5,4]  R1222     -8.8543213903903961e-02
    z[2,5,4]  R1223     0.548109233379364
    z[2,5,4]  R1224     -1.6275113821029663e-01
    z[2,5,4]  R1225     -5.6561392545700073e-01
    z[2,5,4]  R1226     0.707699716091156
    z[2,5,4]  R1227     -6.4364886283874512e-01
    z[2,5,4]  R1228     5.1550066471099854e-01
    z[2,5,4]  R1229     2.1972514688968658e-01
    z[2,5,4]  R1230     2.1765190362930298e-01
    z[2,5,4]  R1231     4.0931142866611481e-02
    z[2,5,4]  R1232     2.1041837334632874e-01
    z[2,5,4]  R1233     2.9918965697288513e-01
    z[2,5,4]  R1234     1.8380618095397949e-01
    z[2,5,4]  R1235     -3.5623095463961363e-03
    z[2,5,4]  R1236     -3.0863493680953979e-01
    z[2,5,4]  R1237     6.2925219535827637e-02
    z[2,5,4]  R1238     1.8007060885429382e-01
    z[2,5,4]  R1239     2.4389740824699402e-01
    z[2,5,4]  R1240     4.0803790092468262e-01
    z[2,5,4]  R1241     2.2968213260173798e-01
    z[2,5,4]  R1242     2.7753636240959167e-01
    z[2,5,4]  R1243     2.0736928284168243e-01
    z[2,5,4]  R1244     7.0982277393341064e-02
    z[2,5,4]  R1245     3.4071475267410278e-02
    z[2,5,4]  R1246     4.9427163600921631e-01
    z[2,5,4]  R1247     3.9076145738363266e-02
    z[2,5,4]  R1248     2.3187184333801270e-01
    z[2,5,4]  R1249     1.3753369450569153e-01
    z[2,5,4]  R1250     -4.3718385696411133e-01
    z[2,5,4]  R1251     -1.0097002238035202e-01
    z[2,5,4]  R1252     4.4751915335655212e-01
    z[2,5,4]  R1253     -5.9085196256637573e-01
    z[2,5,4]  R1254     2.4820290505886078e-02
    z[2,5,4]  R1255     2.6861295104026794e-01
    z[2,5,4]  R1256     1.6392327845096588e-01
    z[2,5,4]  R1257     4.8956326209008694e-03
    z[2,5,4]  R1258     2.2232106328010559e-01
    z[2,5,5]  R25       -1
    z[2,5,5]  R52       1
    z[2,5,5]  R1155     -1
    z[2,5,5]  R1156     1
    z[2,5,5]  R1159     -0.0635211244225502
    z[2,5,5]  R1160     2.7736338973045349e-01
    z[2,5,5]  R1161     5.5521562695503235e-02
    z[2,5,5]  R1162     2.7796175330877304e-02
    z[2,5,5]  R1163     1.1223144084215164e-01
    z[2,5,5]  R1164     3.6337185651063919e-02
    z[2,5,5]  R1165     -2.2626908123493195e-01
    z[2,5,5]  R1166     1.7067806422710419e-01
    z[2,5,5]  R1167     -1.7152380198240280e-02
    z[2,5,5]  R1168     -3.4348621964454651e-01
    z[2,5,5]  R1169     -1.9725652039051056e-01
    z[2,5,5]  R1170     4.2617791891098022e-01
    z[2,5,5]  R1171     1.1352778412401676e-02
    z[2,5,5]  R1172     -2.4518366903066635e-02
    z[2,5,5]  R1173     -2.9133906960487366e-01
    z[2,5,5]  R1174     2.1445275843143463e-01
    z[2,5,5]  R1175     -4.6159449219703674e-01
    z[2,5,5]  R1176     -2.2193560004234314e-01
    z[2,5,5]  R1177     -1.8358242511749268e-01
    z[2,5,5]  R1178     -3.6293134093284607e-01
    z[2,5,5]  R1179     5.5039305239915848e-02
    z[2,5,5]  R1180     -2.3360683023929596e-01
    z[2,5,5]  R1181     -4.2297882027924061e-03
    z[2,5,5]  R1182     -0.0718153715133667
    z[2,5,5]  R1183     2.5768172740936279e-01
    z[2,5,5]  R1184     3.3670762181282043e-01
    z[2,5,5]  R1185     5.1106613874435425e-01
    z[2,5,5]  R1186     -8.0461136996746063e-02
    z[2,5,5]  R1187     4.8210576176643372e-01
    z[2,5,5]  R1188     1.6107335686683655e-01
    z[2,5,5]  R1189     8.1095799803733826e-02
    z[2,5,5]  R1190     5.4160147905349731e-01
    z[2,5,5]  R1191     5.2025479078292847e-01
    z[2,5,5]  R1192     4.8227846622467041e-01
    z[2,5,5]  R1193     7.5342416763305664e-02
    z[2,5,5]  R1194     1.1733891814947128e-01
    z[2,5,5]  R1195     6.5021711587905884e-01
    z[2,5,5]  R1196     -3.7025246769189835e-02
    z[2,5,5]  R1197     1.1696664243936539e-01
    z[2,5,5]  R1198     -3.3673125505447388e-01
    z[2,5,5]  R1199     1.8170122802257538e-01
    z[2,5,5]  R1200     3.1329768896102905e-01
    z[2,5,5]  R1201     -6.1849659681320190e-01
    z[2,5,5]  R1202     -3.5491830110549927e-01
    z[2,5,5]  R1203     -9.0146347880363464e-02
    z[2,5,5]  R1204     1.0209847241640091e-01
    z[2,5,5]  R1205     0.00407183775678277
    z[2,5,5]  R1206     1.4406004548072815e-01
    z[2,5,5]  R1207     -0.131404310464859
    z[2,5,5]  R1208     -5.6364381313323975e-01
    z[2,5,5]  R1209     -2.3281066119670868e-01
    z[2,5,5]  R1210     4.1498345136642456e-01
    z[2,5,5]  R1211     4.9292922019958496e-02
    z[2,5,5]  R1212     -2.8681412339210510e-01
    z[2,5,5]  R1213     6.9784134626388550e-01
    z[2,5,5]  R1214     -2.2815065085887909e-01
    z[2,5,5]  R1215     2.4691013619303703e-02
    z[2,5,5]  R1216     5.2079174667596817e-02
    z[2,5,5]  R1217     -1.0465037077665329e-01
    z[2,5,5]  R1218     2.4978755414485931e-01
    z[2,5,5]  R1219     2.5284758210182190e-01
    z[2,5,5]  R1220     3.1188917160034180e-01
    z[2,5,5]  R1221     1.3883448205888271e-02
    z[2,5,5]  R1222     1.3978092372417450e-01
    z[2,5,5]  R1223     -4.9397191405296326e-01
    z[2,5,5]  R1224     -1.7135277390480042e-01
    z[2,5,5]  R1225     1.8202652037143707e-01
    z[2,5,5]  R1226     1.2054627388715744e-01
    z[2,5,5]  R1227     -3.5846689343452454e-01
    z[2,5,5]  R1228     -4.3303996324539185e-01
    z[2,5,5]  R1229     2.1065457165241241e-01
    z[2,5,5]  R1230     -7.7650360763072968e-02
    z[2,5,5]  R1231     -4.2856833338737488e-01
    z[2,5,5]  R1232     1.0852876305580139e-01
    z[2,5,5]  R1233     -6.0421347618103027e-01
    z[2,5,5]  R1234     -3.2600095868110657e-01
    z[2,5,5]  R1235     0.366743803024292
    z[2,5,5]  R1236     -0.512775719165802
    z[2,5,5]  R1237     2.3371849954128265e-01
    z[2,5,5]  R1238     0.126520574092865
    z[2,5,5]  R1239     -5.0567211583256721e-03
    z[2,5,5]  R1240     2.1239832043647766e-01
    z[2,5,5]  R1241     -1.4609448611736298e-01
    z[2,5,5]  R1242     2.6021143794059753e-01
    z[2,5,5]  R1243     4.4713470339775085e-01
    z[2,5,5]  R1244     0.583529531955719
    z[2,5,5]  R1245     0.211939737200737
    z[2,5,5]  R1246     -2.4932612478733063e-01
    z[2,5,5]  R1247     -6.5293574333190918e-01
    z[2,5,5]  R1248     -2.3178772628307343e-01
    z[2,5,5]  R1249     2.1061576902866364e-02
    z[2,5,5]  R1250     2.0756955444812775e-01
    z[2,5,5]  R1251     1.8175454437732697e-01
    z[2,5,5]  R1252     7.4833102524280548e-02
    z[2,5,5]  R1253     -2.8705310821533203e-01
    z[2,5,5]  R1254     3.4221136569976807e-01
    z[2,5,5]  R1255     -3.9896681904792786e-01
    z[2,5,5]  R1256     -3.4685872495174408e-02
    z[2,5,5]  R1257     4.9487265944480896e-01
    z[2,5,5]  R1258     -1.7112414538860321e-01
    z[2,5,6]  R26       -1
    z[2,5,6]  R53       1
    z[2,5,6]  R1157     -1
    z[2,5,6]  R1158     1
    z[2,5,6]  R1159     -1.3209688663482666e-01
    z[2,5,6]  R1160     2.9905205965042114e-01
    z[2,5,6]  R1161     1.1577330529689789e-01
    z[2,5,6]  R1162     2.0468689501285553e-01
    z[2,5,6]  R1163     -8.3370774984359741e-02
    z[2,5,6]  R1164     -1.7821887135505676e-01
    z[2,5,6]  R1165     -1.7275738716125488e-01
    z[2,5,6]  R1166     -4.0734943002462387e-02
    z[2,5,6]  R1167     -8.5410818457603455e-02
    z[2,5,6]  R1168     3.3465859293937683e-01
    z[2,5,6]  R1169     2.8603413701057434e-01
    z[2,5,6]  R1170     6.9640494883060455e-02
    z[2,5,6]  R1171     1.4773635566234589e-01
    z[2,5,6]  R1172     3.5808464884757996e-01
    z[2,5,6]  R1173     0.284882128238678
    z[2,5,6]  R1174     -0.254308819770813
    z[2,5,6]  R1175     1.0130243003368378e-01
    z[2,5,6]  R1176     -2.3207536339759827e-01
    z[2,5,6]  R1177     -1.2426828593015671e-01
    z[2,5,6]  R1178     -3.0167952179908752e-01
    z[2,5,6]  R1179     2.2877737879753113e-01
    z[2,5,6]  R1180     -8.3770573139190674e-02
    z[2,5,6]  R1181     -1.8943063914775848e-01
    z[2,5,6]  R1182     -1.9247531890869141e-01
    z[2,5,6]  R1183     -1.7640799283981323e-01
    z[2,5,6]  R1184     -2.1168164908885956e-01
    z[2,5,6]  R1185     -1.0025624185800552e-01
    z[2,5,6]  R1186     -1.1540773510932922e-01
    z[2,5,6]  R1187     -1.8831816315650940e-01
    z[2,5,6]  R1188     -4.3406596779823303e-01
    z[2,5,6]  R1189     5.3462035953998566e-02
    z[2,5,6]  R1190     -4.1332840919494629e-01
    z[2,5,6]  R1191     -2.7431643009185791e-01
    z[2,5,6]  R1192     -8.0111749470233917e-02
    z[2,5,6]  R1193     -3.6975890398025513e-01
    z[2,5,6]  R1194     -7.7255196869373322e-02
    z[2,5,6]  R1195     -5.4858896881341934e-02
    z[2,5,6]  R1196     -9.0832240879535675e-02
    z[2,5,6]  R1197     3.4952464699745178e-01
    z[2,5,6]  R1198     -2.1520432084798813e-02
    z[2,5,6]  R1199     -2.4955970048904419e-01
    z[2,5,6]  R1200     1.5067370235919952e-01
    z[2,5,6]  R1201     4.1308920830488205e-02
    z[2,5,6]  R1202     3.0079236626625061e-01
    z[2,5,6]  R1203     4.3296954035758972e-01
    z[2,5,6]  R1204     1.2698552012443542e-01
    z[2,5,6]  R1205     5.6059543043375015e-02
    z[2,5,6]  R1206     1.7663882672786713e-01
    z[2,5,6]  R1207     -4.2658916115760803e-01
    z[2,5,6]  R1208     -3.8099822402000427e-01
    z[2,5,6]  R1209     2.5672060251235962e-01
    z[2,5,6]  R1210     -0.246268168091774
    z[2,5,6]  R1211     1.4512288384139538e-02
    z[2,5,6]  R1212     9.0870611369609833e-02
    z[2,5,6]  R1213     2.9818934202194214e-01
    z[2,5,6]  R1214     -9.8133519291877747e-02
    z[2,5,6]  R1215     -2.0349709689617157e-01
    z[2,5,6]  R1216     -6.8014246225357056e-01
    z[2,5,6]  R1217     -2.3519890382885933e-02
    z[2,5,6]  R1218     0.328035831451416
    z[2,5,6]  R1219     2.5234752893447876e-01
    z[2,5,6]  R1220     -5.8398038148880005e-02
    z[2,5,6]  R1221     2.4019230902194977e-01
    z[2,5,6]  R1222     -6.7810076475143433e-01
    z[2,5,6]  R1223     -7.9585418105125427e-02
    z[2,5,6]  R1224     2.5969287753105164e-01
    z[2,5,6]  R1225     -1.3493178784847260e-01
    z[2,5,6]  R1226     1.8260501325130463e-01
    z[2,5,6]  R1227     6.5527461469173431e-02
    z[2,5,6]  R1228     -2.3894280195236206e-01
    z[2,5,6]  R1229     1.5206854045391083e-01
    z[2,5,6]  R1230     -0.0815151035785675
    z[2,5,6]  R1231     1.4401021599769592e-01
    z[2,5,6]  R1232     4.0101242065429688e-01
    z[2,5,6]  R1233     1.4734651148319244e-01
    z[2,5,6]  R1234     2.0967794954776764e-01
    z[2,5,6]  R1235     -1.6668763756752014e-01
    z[2,5,6]  R1236     -3.4199798107147217e-01
    z[2,5,6]  R1237     -6.0024131089448929e-02
    z[2,5,6]  R1238     -3.6240525543689728e-02
    z[2,5,6]  R1239     9.9132414907217026e-03
    z[2,5,6]  R1240     1.7179162800312042e-01
    z[2,5,6]  R1241     -2.2948840260505676e-01
    z[2,5,6]  R1242     2.8815174102783203e-01
    z[2,5,6]  R1243     4.2438122630119324e-01
    z[2,5,6]  R1244     -0.319205641746521
    z[2,5,6]  R1245     5.4390239715576172e-01
    z[2,5,6]  R1246     7.4569158256053925e-02
    z[2,5,6]  R1247     -1.5750029683113098e-01
    z[2,5,6]  R1248     0.297391414642334
    z[2,5,6]  R1249     -3.7479585409164429e-01
    z[2,5,6]  R1250     -1.8527930974960327e-01
    z[2,5,6]  R1251     -1.5197099745273590e-01
    z[2,5,6]  R1252     -3.8313020020723343e-02
    z[2,5,6]  R1253     -7.8656310215592384e-03
    z[2,5,6]  R1254     -4.1217800974845886e-01
    z[2,5,6]  R1255     2.5088205933570862e-01
    z[2,5,6]  R1256     -3.0493089556694031e-01
    z[2,5,6]  R1257     4.5366075634956360e-01
    z[2,5,6]  R1258     2.8514704108238220e-01
    z[5,2,0]  R20       1
    z[5,2,0]  R47       -1
    z[5,2,0]  R1259     -1
    z[5,2,0]  R1260     1
    z[5,2,0]  R1273     6.3620336353778839e-02
    z[5,2,0]  R1274     3.7411540746688843e-01
    z[5,2,0]  R1275     0.309985488653183
    z[5,2,0]  R1276     2.2376090288162231e-01
    z[5,2,0]  R1277     1.9197373092174530e-01
    z[5,2,0]  R1278     5.7358872890472412e-01
    z[5,2,0]  R1279     -5.3023308515548706e-01
    z[5,2,0]  R1280     1.0566161572933197e-01
    z[5,2,0]  R1281     4.4696331024169922e-01
    z[5,2,0]  R1282     5.0492811203002930e-01
    z[5,2,0]  R1283     5.1830720901489258e-01
    z[5,2,0]  R1284     2.6020705699920654e-01
    z[5,2,0]  R1285     2.9869771003723145e-01
    z[5,2,0]  R1286     4.1372036933898926e-01
    z[5,2,0]  R1287     2.6807132363319397e-01
    z[5,2,0]  R1288     4.8167598247528076e-01
    z[5,2,0]  R1289     3.8679200410842896e-01
    z[5,2,0]  R1290     -6.5046213567256927e-02
    z[5,2,0]  R1291     -1.6289213672280312e-02
    z[5,2,0]  R1292     -4.6963214874267578e-01
    z[5,2,0]  R1293     7.6995509862899780e-01
    z[5,2,0]  R1294     4.8069155216217041e-01
    z[5,2,0]  R1295     -1.7894135415554047e-01
    z[5,2,0]  R1296     -1.6504043340682983e-01
    z[5,2,0]  R1297     -1.3117472827434540e-01
    z[5,2,0]  R1298     8.0199085175991058e-02
    z[5,2,0]  R1299     -0.0911993533372879
    z[5,2,0]  R1300     -1.5107788145542145e-01
    z[5,2,0]  R1301     -2.3619601130485535e-01
    z[5,2,0]  R1302     3.3547326922416687e-01
    z[5,2,0]  R1303     8.8604754209518433e-01
    z[5,2,0]  R1304     1.4583480358123779e-01
    z[5,2,0]  R1305     7.9103827476501465e-01
    z[5,2,0]  R1306     8.7183523178100586e-01
    z[5,2,0]  R1307     0.828798770904541
    z[5,2,0]  R1308     8.3446949720382690e-01
    z[5,2,0]  R1309     8.2140040397644043e-01
    z[5,2,0]  R1310     3.2014328241348267e-01
    z[5,2,0]  R1311     -5.8035325258970261e-02
    z[5,2,0]  R1312     7.2002267837524414e-01
    z[5,2,0]  R1313     -3.5881298780441284e-01
    z[5,2,0]  R1314     -4.7988590598106384e-01
    z[5,2,0]  R1315     -1.5419688820838928e-01
    z[5,2,0]  R1316     -7.5405031442642212e-01
    z[5,2,0]  R1317     -6.8363982439041138e-01
    z[5,2,0]  R1318     -4.0264037251472473e-01
    z[5,2,0]  R1319     -0.772131085395813
    z[5,2,0]  R1320     -7.4872213602066040e-01
    z[5,2,0]  R1321     -2.5317719578742981e-01
    z[5,2,0]  R1322     -7.6686137914657593e-01
    z[5,2,0]  R1323     4.8272699117660522e-02
    z[5,2,0]  R1324     -2.3450122773647308e-01
    z[5,2,0]  R1325     4.4383369386196136e-02
    z[5,2,0]  R1326     -1.6060508787631989e-01
    z[5,2,0]  R1327     3.9612289518117905e-02
    z[5,2,0]  R1328     -9.2905491590499878e-02
    z[5,2,0]  R1329     -7.7253989875316620e-02
    z[5,2,0]  R1330     -4.0585073828697205e-01
    z[5,2,0]  R1331     3.5294704139232635e-02
    z[5,2,0]  R1332     -1.3486324250698090e-01
    z[5,2,0]  R1333     1.8007567524909973e-01
    z[5,2,0]  R1334     1.6546323604416102e-04
    z[5,2,0]  R1335     2.5776728987693787e-01
    z[5,2,0]  R1336     -4.1691058874130249e-01
    z[5,2,0]  R1337     -2.6028215885162354e-01
    z[5,2,0]  R1338     6.9311964511871338e-01
    z[5,2,0]  R1339     -4.1471680998802185e-01
    z[5,2,0]  R1340     -5.6344783306121826e-01
    z[5,2,0]  R1341     -4.9564579129219055e-01
    z[5,2,0]  R1342     -1.3505442440509796e-01
    z[5,2,0]  R1343     -0.564138650894165
    z[5,2,0]  R1344     3.5655394196510315e-01
    z[5,2,0]  R1345     1.7037992179393768e-01
    z[5,2,0]  R1346     -1.5335051715373993e-01
    z[5,2,0]  R1347     -3.0667927861213684e-01
    z[5,2,0]  R1348     -2.1232496201992035e-01
    z[5,2,0]  R1349     8.5173296928405762e-01
    z[5,2,0]  R1350     8.8291460275650024e-01
    z[5,2,0]  R1351     0.199258491396904
    z[5,2,0]  R1352     -1.7429096996784210e-01
    z[5,2,0]  R1353     2.3610081523656845e-02
    z[5,2,0]  R1354     -3.2982969284057617e-01
    z[5,2,0]  R1355     6.9847536087036133e-01
    z[5,2,0]  R1356     -4.6365892887115479e-01
    z[5,2,0]  R1357     1.2046752125024796e-01
    z[5,2,0]  R1358     -0.527647852897644
    z[5,2,0]  R1359     2.2033995389938354e-01
    z[5,2,0]  R1360     2.4991865456104279e-01
    z[5,2,0]  R1361     -0.868701696395874
    z[5,2,0]  R1362     -2.1660651266574860e-01
    z[5,2,0]  R1363     8.6552582681179047e-02
    z[5,2,0]  R1364     -2.6703274250030518e-01
    z[5,2,0]  R1365     -4.2324659228324890e-01
    z[5,2,0]  R1366     2.0893737673759460e-01
    z[5,2,0]  R1367     2.3474301397800446e-01
    z[5,2,0]  R1368     3.7857976555824280e-01
    z[5,2,0]  R1369     -3.1002092361450195e-01
    z[5,2,0]  R1370     1.0676967352628708e-01
    z[5,2,0]  R1371     -0.282500684261322
    z[5,2,0]  R1372     1.3480694591999054e-01
    z[5,2,1]  R21       1
    z[5,2,1]  R48       -1
    z[5,2,1]  R1261     -1
    z[5,2,1]  R1262     1
    z[5,2,1]  R1273     2.1285678446292877e-01
    z[5,2,1]  R1274     -2.0423457026481628e-01
    z[5,2,1]  R1275     1.9847913086414337e-01
    z[5,2,1]  R1276     -2.6865140534937382e-03
    z[5,2,1]  R1277     1.7888420820236206e-01
    z[5,2,1]  R1278     2.1807121112942696e-02
    z[5,2,1]  R1279     1.6930523561313748e-03
    z[5,2,1]  R1280     5.4403698444366455e-01
    z[5,2,1]  R1281     8.5394734144210815e-01
    z[5,2,1]  R1282     5.2414888143539429e-01
    z[5,2,1]  R1283     -4.4503325223922729e-01
    z[5,2,1]  R1284     -5.0822061300277710e-01
    z[5,2,1]  R1285     -2.2731699049472809e-02
    z[5,2,1]  R1286     1.3671897351741791e-01
    z[5,2,1]  R1287     6.8114958703517914e-02
    z[5,2,1]  R1288     -1.7794659733772278e-01
    z[5,2,1]  R1289     -4.3558841943740845e-01
    z[5,2,1]  R1290     -0.775583803653717
    z[5,2,1]  R1291     -6.7599415779113770e-01
    z[5,2,1]  R1292     -7.6074421405792236e-01
    z[5,2,1]  R1293     3.2440826296806335e-01
    z[5,2,1]  R1294     3.7659278512001038e-01
    z[5,2,1]  R1295     -2.2676189243793488e-01
    z[5,2,1]  R1296     -1.5134532749652863e-01
    z[5,2,1]  R1297     4.4075556099414825e-02
    z[5,2,1]  R1298     -7.0459681749343872e-01
    z[5,2,1]  R1299     -4.2690876871347427e-02
    z[5,2,1]  R1300     -7.1568185091018677e-01
    z[5,2,1]  R1301     -2.0943626761436462e-01
    z[5,2,1]  R1302     8.2062435150146484e-01
    z[5,2,1]  R1303     -2.0820298790931702e-01
    z[5,2,1]  R1304     -2.4536137282848358e-01
    z[5,2,1]  R1305     -1.8139237165451050e-01
    z[5,2,1]  R1306     -6.7742630839347839e-02
    z[5,2,1]  R1307     2.2924799472093582e-02
    z[5,2,1]  R1308     -1.3303156197071075e-01
    z[5,2,1]  R1309     -1.2285141646862030e-01
    z[5,2,1]  R1310     -1.8322411179542542e-01
    z[5,2,1]  R1311     -2.3186931014060974e-01
    z[5,2,1]  R1312     -1.5166489779949188e-01
    z[5,2,1]  R1313     7.7723509073257446e-01
    z[5,2,1]  R1314     6.2624263763427734e-01
    z[5,2,1]  R1315     8.9889067411422729e-01
    z[5,2,1]  R1316     4.2762383818626404e-01
    z[5,2,1]  R1317     3.5715842247009277e-01
    z[5,2,1]  R1318     0.71956866979599
    z[5,2,1]  R1319     0.166547030210495
    z[5,2,1]  R1320     1.8764916062355042e-01
    z[5,2,1]  R1321     8.6886739730834961e-01
    z[5,2,1]  R1322     2.7385982871055603e-01
    z[5,2,1]  R1323     -9.1263711452484131e-01
    z[5,2,1]  R1324     -8.6090552806854248e-01
    z[5,2,1]  R1325     -7.9708242416381836e-01
    z[5,2,1]  R1326     -7.9676896333694458e-01
    z[5,2,1]  R1327     -8.3311569690704346e-01
    z[5,2,1]  R1328     -8.7095212936401367e-01
    z[5,2,1]  R1329     -0.763202428817749
    z[5,2,1]  R1330     -7.7917784452438354e-01
    z[5,2,1]  R1331     -0.824566125869751
    z[5,2,1]  R1332     -6.9372671842575073e-01
    z[5,2,1]  R1333     -0.659796953201294
    z[5,2,1]  R1334     -4.9183964729309082e-01
    z[5,2,1]  R1335     -5.3227448463439941e-01
    z[5,2,1]  R1336     -1.8455389142036438e-01
    z[5,2,1]  R1337     -2.4131046235561371e-01
    z[5,2,1]  R1338     -5.4709357023239136e-01
    z[5,2,1]  R1339     -5.6468397378921509e-01
    z[5,2,1]  R1340     5.1037472486495972e-01
    z[5,2,1]  R1341     -0.705713152885437
    z[5,2,1]  R1342     1.6149090230464935e-01
    z[5,2,1]  R1343     -4.5664042234420776e-01
    z[5,2,1]  R1344     -3.6807930469512939e-01
    z[5,2,1]  R1345     -2.4916736781597137e-01
    z[5,2,1]  R1346     3.8674041628837585e-01
    z[5,2,1]  R1347     0.219456747174263
    z[5,2,1]  R1348     4.7260022163391113e-01
    z[5,2,1]  R1349     -2.6977792382240295e-01
    z[5,2,1]  R1350     -1.5420758724212646e-01
    z[5,2,1]  R1351     6.4654910564422607e-01
    z[5,2,1]  R1352     4.7253987193107605e-01
    z[5,2,1]  R1353     1.4519819058477879e-02
    z[5,2,1]  R1354     -5.6691801548004150e-01
    z[5,2,1]  R1355     -4.2047610878944397e-01
    z[5,2,1]  R1356     7.2132611274719238e-01
    z[5,2,1]  R1357     -4.8361968994140625e-01
    z[5,2,1]  R1358     2.6444411277770996e-01
    z[5,2,1]  R1359     -9.6356995403766632e-02
    z[5,2,1]  R1360     -5.6525218486785889e-01
    z[5,2,1]  R1361     2.6983615756034851e-01
    z[5,2,1]  R1362     -2.4216964840888977e-01
    z[5,2,1]  R1363     -7.1035593748092651e-01
    z[5,2,1]  R1364     -6.9905835390090942e-01
    z[5,2,1]  R1365     7.4038130044937134e-01
    z[5,2,1]  R1366     -4.5106706023216248e-01
    z[5,2,1]  R1367     3.1020686030387878e-01
    z[5,2,1]  R1368     1.9607998430728912e-01
    z[5,2,1]  R1369     2.8569355607032776e-02
    z[5,2,1]  R1370     -0.0813002958893776
    z[5,2,1]  R1371     -3.0414137244224548e-01
    z[5,2,1]  R1372     1.0632056742906570e-01
    z[5,2,2]  R22       1
    z[5,2,2]  R49       -1
    z[5,2,2]  R1263     -1
    z[5,2,2]  R1264     1
    z[5,2,2]  R1273     0.376784086227417
    z[5,2,2]  R1274     3.3700317144393921e-01
    z[5,2,2]  R1275     0.441354900598526
    z[5,2,2]  R1276     -2.8998634219169617e-01
    z[5,2,2]  R1277     3.4507983922958374e-01
    z[5,2,2]  R1278     -4.0886303782463074e-01
    z[5,2,2]  R1279     4.8193186521530151e-01
    z[5,2,2]  R1280     3.1942182779312134e-01
    z[5,2,2]  R1281     -1.6876170411705971e-02
    z[5,2,2]  R1282     -3.4552210569381714e-01
    z[5,2,2]  R1283     2.6598111726343632e-03
    z[5,2,2]  R1284     -2.0064075291156769e-01
    z[5,2,2]  R1285     -8.2659468054771423e-02
    z[5,2,2]  R1286     3.5662662982940674e-01
    z[5,2,2]  R1287     -2.9090091586112976e-01
    z[5,2,2]  R1288     -2.6795518398284912e-01
    z[5,2,2]  R1289     4.9454793334007263e-01
    z[5,2,2]  R1290     4.2323939502239227e-02
    z[5,2,2]  R1291     2.4845432490110397e-02
    z[5,2,2]  R1292     -6.6998414695262909e-02
    z[5,2,2]  R1293     2.8627347946166992e-01
    z[5,2,2]  R1294     -2.3177672922611237e-01
    z[5,2,2]  R1295     2.3166167736053467e-01
    z[5,2,2]  R1296     2.1681115031242371e-01
    z[5,2,2]  R1297     -3.7851881235837936e-02
    z[5,2,2]  R1298     0.0953143835067749
    z[5,2,2]  R1299     4.1084265708923340e-01
    z[5,2,2]  R1300     3.4106969833374023e-01
    z[5,2,2]  R1301     5.6632423400878906e-01
    z[5,2,2]  R1302     -1.4988601207733154e-01
    z[5,2,2]  R1303     0.0910937711596489
    z[5,2,2]  R1304     8.6018282175064087e-01
    z[5,2,2]  R1305     4.2260631918907166e-01
    z[5,2,2]  R1306     -4.1567340493202209e-02
    z[5,2,2]  R1307     3.7105602025985718e-01
    z[5,2,2]  R1308     4.1188856959342957e-01
    z[5,2,2]  R1309     -0.0768071785569191
    z[5,2,2]  R1310     9.0562599897384644e-01
    z[5,2,2]  R1311     9.0104812383651733e-01
    z[5,2,2]  R1312     -0.0647159144282341
    z[5,2,2]  R1313     -2.9394480586051941e-01
    z[5,2,2]  R1314     -3.2875162363052368e-01
    z[5,2,2]  R1315     -3.6022484302520752e-01
    z[5,2,2]  R1316     -2.7992677688598633e-01
    z[5,2,2]  R1317     -4.0945509076118469e-01
    z[5,2,2]  R1318     -3.1449410319328308e-01
    z[5,2,2]  R1319     -2.1376132965087891e-01
    z[5,2,2]  R1320     -4.1909557580947876e-01
    z[5,2,2]  R1321     -1.9536575675010681e-01
    z[5,2,2]  R1322     -1.6567899286746979e-01
    z[5,2,2]  R1323     2.1565565839409828e-02
    z[5,2,2]  R1324     1.8663156032562256e-01
    z[5,2,2]  R1325     1.1444225907325745e-01
    z[5,2,2]  R1326     1.7330738902091980e-01
    z[5,2,2]  R1327     1.9123714417219162e-02
    z[5,2,2]  R1328     2.7071169018745422e-01
    z[5,2,2]  R1329     5.5021595209836960e-02
    z[5,2,2]  R1330     -8.9638732373714447e-02
    z[5,2,2]  R1331     -1.2983185052871704e-01
    z[5,2,2]  R1332     0.456155925989151
    z[5,2,2]  R1333     6.8963599205017090e-01
    z[5,2,2]  R1334     3.6888051033020020e-01
    z[5,2,2]  R1335     4.8535147309303284e-01
    z[5,2,2]  R1336     5.2804708480834961e-01
    z[5,2,2]  R1337     5.0944548845291138e-01
    z[5,2,2]  R1338     -3.9497545361518860e-01
    z[5,2,2]  R1339     2.5180166959762573e-01
    z[5,2,2]  R1340     -2.9711747169494629e-01
    z[5,2,2]  R1341     3.3206200599670410e-01
    z[5,2,2]  R1342     -8.2156014442443848e-01
    z[5,2,2]  R1343     5.9368723630905151e-01
    z[5,2,2]  R1344     3.6254769563674927e-01
    z[5,2,2]  R1345     0.542304515838623
    z[5,2,2]  R1346     -6.8246215581893921e-01
    z[5,2,2]  R1347     -6.6549074649810791e-01
    z[5,2,2]  R1348     -6.3054847717285156e-01
    z[5,2,2]  R1349     -2.1745751798152924e-01
    z[5,2,2]  R1350     -7.5013250112533569e-02
    z[5,2,2]  R1351     -5.2669900655746460e-01
    z[5,2,2]  R1352     -4.9416157603263855e-01
    z[5,2,2]  R1353     7.6543998718261719e-01
    z[5,2,2]  R1354     3.4518721699714661e-01
    z[5,2,2]  R1355     -5.2202981710433960e-01
    z[5,2,2]  R1356     -0.376355916261673
    z[5,2,2]  R1357     1.5767641365528107e-01
    z[5,2,2]  R1358     -7.2714775800704956e-01
    z[5,2,2]  R1359     4.8233687877655029e-01
    z[5,2,2]  R1360     3.7854695320129395e-01
    z[5,2,2]  R1361     -6.1420563608407974e-02
    z[5,2,2]  R1362     3.6835893988609314e-01
    z[5,2,2]  R1363     5.4648733139038086e-01
    z[5,2,2]  R1364     4.1992199420928955e-01
    z[5,2,2]  R1365     -0.415484219789505
    z[5,2,2]  R1366     5.0685596466064453e-01
    z[5,2,2]  R1367     4.7984153032302856e-01
    z[5,2,2]  R1368     -4.0168985724449158e-01
    z[5,2,2]  R1369     -0.302696168422699
    z[5,2,2]  R1370     -1.9866585731506348e-01
    z[5,2,2]  R1371     -5.0169765949249268e-01
    z[5,2,2]  R1372     -2.9586029052734375e-01
    z[5,2,3]  R23       1
    z[5,2,3]  R50       -1
    z[5,2,3]  R1265     -1
    z[5,2,3]  R1266     1
    z[5,2,3]  R1273     8.3240544795989990e-01
    z[5,2,3]  R1274     8.0293715000152588e-01
    z[5,2,3]  R1275     6.8090802431106567e-01
    z[5,2,3]  R1276     8.0558454990386963e-01
    z[5,2,3]  R1277     5.7945418357849121e-01
    z[5,2,3]  R1278     0.56508868932724
    z[5,2,3]  R1279     -5.6946748495101929e-01
    z[5,2,3]  R1280     -3.4010595083236694e-01
    z[5,2,3]  R1281     -9.2337392270565033e-02
    z[5,2,3]  R1282     -5.4880219697952271e-01
    z[5,2,3]  R1283     -6.8824869394302368e-01
    z[5,2,3]  R1284     -6.2659960985183716e-01
    z[5,2,3]  R1285     -8.8128763437271118e-01
    z[5,2,3]  R1286     -6.7467993497848511e-01
    z[5,2,3]  R1287     -6.4485955238342285e-01
    z[5,2,3]  R1288     -4.6592471003532410e-01
    z[5,2,3]  R1289     -0.272337943315506
    z[5,2,3]  R1290     -2.8358227014541626e-01
    z[5,2,3]  R1291     -2.9915022850036621e-01
    z[5,2,3]  R1292     1.7128208652138710e-02
    z[5,2,3]  R1293     2.4524433910846710e-01
    z[5,2,3]  R1294     5.5213207006454468e-01
    z[5,2,3]  R1295     -8.9250606298446655e-01
    z[5,2,3]  R1296     -8.3397108316421509e-01
    z[5,2,3]  R1297     0.740169107913971
    z[5,2,3]  R1298     -4.4767311215400696e-01
    z[5,2,3]  R1299     -7.2580933570861816e-01
    z[5,2,3]  R1300     -4.7706350684165955e-01
    z[5,2,3]  R1301     -0.359017938375473
    z[5,2,3]  R1302     1.7761951684951782e-01
    z[5,2,3]  R1303     3.6288830637931824e-01
    z[5,2,3]  R1304     2.6031108573079109e-02
    z[5,2,3]  R1305     3.5282278060913086e-01
    z[5,2,3]  R1306     3.7063917517662048e-01
    z[5,2,3]  R1307     3.4668728709220886e-01
    z[5,2,3]  R1308     0.280091255903244
    z[5,2,3]  R1309     3.0276027321815491e-01
    z[5,2,3]  R1310     -0.0650770291686058
    z[5,2,3]  R1311     1.5361729077994823e-02
    z[5,2,3]  R1312     3.7681087851524353e-01
    z[5,2,3]  R1313     -1.1669117212295532e-01
    z[5,2,3]  R1314     -2.6099857687950134e-01
    z[5,2,3]  R1315     -1.2423708289861679e-01
    z[5,2,3]  R1316     -1.9255127012729645e-01
    z[5,2,3]  R1317     -1.3361001014709473e-01
    z[5,2,3]  R1318     -3.3215454220771790e-01
    z[5,2,3]  R1319     -1.3045512139797211e-01
    z[5,2,3]  R1320     -3.0237317085266113e-01
    z[5,2,3]  R1321     -1.8618687987327576e-01
    z[5,2,3]  R1322     -2.9385924339294434e-01
    z[5,2,3]  R1323     1.7202377319335938e-01
    z[5,2,3]  R1324     3.0013132095336914e-01
    z[5,2,3]  R1325     3.1678459048271179e-01
    z[5,2,3]  R1326     5.1525235176086426e-01
    z[5,2,3]  R1327     1.6616627573966980e-02
    z[5,2,3]  R1328     -2.5784291326999664e-02
    z[5,2,3]  R1329     2.7257108688354492e-01
    z[5,2,3]  R1330     3.2830587029457092e-01
    z[5,2,3]  R1331     1.7882893979549408e-01
    z[5,2,3]  R1332     -7.8448191285133362e-02
    z[5,2,3]  R1333     2.0064114034175873e-01
    z[5,2,3]  R1334     -1.5162938833236694e-01
    z[5,2,3]  R1335     -7.9044135054573417e-04
    z[5,2,3]  R1336     -2.9002451896667480e-01
    z[5,2,3]  R1337     -6.2565606832504272e-01
    z[5,2,3]  R1338     0.141846165060997
    z[5,2,3]  R1339     -1.3586845993995667e-01
    z[5,2,3]  R1340     -2.4493041634559631e-01
    z[5,2,3]  R1341     8.6284153163433075e-02
    z[5,2,3]  R1342     -3.9184951782226562e-01
    z[5,2,3]  R1343     -1.4163862168788910e-01
    z[5,2,3]  R1344     -6.7420870065689087e-01
    z[5,2,3]  R1345     3.4459149837493896e-01
    z[5,2,3]  R1346     -1.3506361842155457e-01
    z[5,2,3]  R1347     -4.0715873241424561e-01
    z[5,2,3]  R1348     -1.5841390192508698e-01
    z[5,2,3]  R1349     -4.7076758928596973e-03
    z[5,2,3]  R1350     -2.6557031273841858e-01
    z[5,2,3]  R1351     -1.9811186194419861e-01
    z[5,2,3]  R1352     -1.9661815464496613e-01
    z[5,2,3]  R1353     -5.2235692739486694e-01
    z[5,2,3]  R1354     -4.6523699164390564e-01
    z[5,2,3]  R1355     1.6508273780345917e-01
    z[5,2,3]  R1356     -1.6416238248348236e-01
    z[5,2,3]  R1357     -2.9310640692710876e-01
    z[5,2,3]  R1358     -2.4496681988239288e-01
    z[5,2,3]  R1359     -8.1528216600418091e-01
    z[5,2,3]  R1360     -7.7290818095207214e-02
    z[5,2,3]  R1361     -2.4361704289913177e-01
    z[5,2,3]  R1362     -6.9557827711105347e-01
    z[5,2,3]  R1363     2.0319934189319611e-01
    z[5,2,3]  R1364     -6.2119122594594955e-03
    z[5,2,3]  R1365     -1.5458916127681732e-01
    z[5,2,3]  R1366     -9.3709513545036316e-02
    z[5,2,3]  R1367     2.6010328531265259e-01
    z[5,2,3]  R1368     -7.3046904802322388e-01
    z[5,2,3]  R1369     -6.6346544027328491e-01
    z[5,2,3]  R1370     -6.2754082679748535e-01
    z[5,2,3]  R1371     -1.7004366219043732e-01
    z[5,2,3]  R1372     -0.610435426235199
    z[5,2,4]  R24       1
    z[5,2,4]  R51       -1
    z[5,2,4]  R1267     -1
    z[5,2,4]  R1268     1
    z[5,2,4]  R1273     2.1972514688968658e-01
    z[5,2,4]  R1274     2.1765190362930298e-01
    z[5,2,4]  R1275     4.0931142866611481e-02
    z[5,2,4]  R1276     2.1041837334632874e-01
    z[5,2,4]  R1277     2.9918965697288513e-01
    z[5,2,4]  R1278     1.8380618095397949e-01
    z[5,2,4]  R1279     -3.5623095463961363e-03
    z[5,2,4]  R1280     -3.0863493680953979e-01
    z[5,2,4]  R1281     6.2925219535827637e-02
    z[5,2,4]  R1282     1.8007060885429382e-01
    z[5,2,4]  R1283     2.4389740824699402e-01
    z[5,2,4]  R1284     4.0803790092468262e-01
    z[5,2,4]  R1285     2.2968213260173798e-01
    z[5,2,4]  R1286     2.7753636240959167e-01
    z[5,2,4]  R1287     2.0736928284168243e-01
    z[5,2,4]  R1288     7.0982277393341064e-02
    z[5,2,4]  R1289     3.4071475267410278e-02
    z[5,2,4]  R1290     4.9427163600921631e-01
    z[5,2,4]  R1291     3.9076145738363266e-02
    z[5,2,4]  R1292     2.3187184333801270e-01
    z[5,2,4]  R1293     1.3753369450569153e-01
    z[5,2,4]  R1294     -4.3718385696411133e-01
    z[5,2,4]  R1295     -1.0097002238035202e-01
    z[5,2,4]  R1296     4.4751915335655212e-01
    z[5,2,4]  R1297     -5.9085196256637573e-01
    z[5,2,4]  R1298     2.4820290505886078e-02
    z[5,2,4]  R1299     2.6861295104026794e-01
    z[5,2,4]  R1300     1.6392327845096588e-01
    z[5,2,4]  R1301     4.8956326209008694e-03
    z[5,2,4]  R1302     2.2232106328010559e-01
    z[5,2,4]  R1303     -1.0050161927938461e-01
    z[5,2,4]  R1304     1.0758806765079498e-01
    z[5,2,4]  R1305     1.4761133491992950e-01
    z[5,2,4]  R1306     2.3139512538909912e-01
    z[5,2,4]  R1307     1.8747209012508392e-01
    z[5,2,4]  R1308     0.0691203773021698
    z[5,2,4]  R1309     3.6277133226394653e-01
    z[5,2,4]  R1310     -9.3559734523296356e-02
    z[5,2,4]  R1311     3.5093545913696289e-01
    z[5,2,4]  R1312     2.8707376122474670e-01
    z[5,2,4]  R1313     -2.1543622016906738e-01
    z[5,2,4]  R1314     -1.2187865376472473e-01
    z[5,2,4]  R1315     3.2665453851222992e-02
    z[5,2,4]  R1316     -6.5461009740829468e-02
    z[5,2,4]  R1317     -2.3137234151363373e-01
    z[5,2,4]  R1318     1.4333372004330158e-02
    z[5,2,4]  R1319     -3.0005258321762085e-01
    z[5,2,4]  R1320     -1.8443909287452698e-01
    z[5,2,4]  R1321     -2.4288322031497955e-01
    z[5,2,4]  R1322     -1.9801400601863861e-02
    z[5,2,4]  R1323     2.8166922926902771e-01
    z[5,2,4]  R1324     1.3172371685504913e-01
    z[5,2,4]  R1325     4.6188560128211975e-01
    z[5,2,4]  R1326     4.0505036711692810e-02
    z[5,2,4]  R1327     0.454078733921051
    z[5,2,4]  R1328     -2.6080831885337830e-02
    z[5,2,4]  R1329     2.5098109245300293e-01
    z[5,2,4]  R1330     3.0422726273536682e-01
    z[5,2,4]  R1331     4.6035513281822205e-02
    z[5,2,4]  R1332     -2.6826274394989014e-01
    z[5,2,4]  R1333     -8.3375498652458191e-02
    z[5,2,4]  R1334     -3.6722859740257263e-01
    z[5,2,4]  R1335     2.6221892237663269e-01
    z[5,2,4]  R1336     -4.3608167767524719e-01
    z[5,2,4]  R1337     -2.8397905826568604e-01
    z[5,2,4]  R1338     1.5624053776264191e-01
    z[5,2,4]  R1339     3.8545615971088409e-02
    z[5,2,4]  R1340     -0.513958215713501
    z[5,2,4]  R1341     -5.2396561950445175e-02
    z[5,2,4]  R1342     -1.1542411148548126e-01
    z[5,2,4]  R1343     -7.3523811995983124e-02
    z[5,2,4]  R1344     -1.7473040521144867e-01
    z[5,2,4]  R1345     3.3437156677246094e-01
    z[5,2,4]  R1346     -3.5563436150550842e-01
    z[5,2,4]  R1347     2.3139014840126038e-01
    z[5,2,4]  R1348     5.3134876489639282e-01
    z[5,2,4]  R1349     -3.8897490501403809e-01
    z[5,2,4]  R1350     -2.6186376810073853e-01
    z[5,2,4]  R1351     -1.6237211227416992e-01
    z[5,2,4]  R1352     -2.4907091632485390e-02
    z[5,2,4]  R1353     1.4272421598434448e-01
    z[5,2,4]  R1354     -3.6843821406364441e-02
    z[5,2,4]  R1355     -1.8145012855529785e-01
    z[5,2,4]  R1356     7.4807085096836090e-02
    z[5,2,4]  R1357     2.5480762124061584e-01
    z[5,2,4]  R1358     -3.4952532500028610e-02
    z[5,2,4]  R1359     5.3019434213638306e-02
    z[5,2,4]  R1360     5.8762248605489731e-02
    z[5,2,4]  R1361     -3.1292009353637695e-01
    z[5,2,4]  R1362     -3.2390853762626648e-01
    z[5,2,4]  R1363     1.4266617596149445e-01
    z[5,2,4]  R1364     -4.0367400646209717e-01
    z[5,2,4]  R1365     1.3523253798484802e-01
    z[5,2,4]  R1366     -8.8543213903903961e-02
    z[5,2,4]  R1367     0.548109233379364
    z[5,2,4]  R1368     -1.6275113821029663e-01
    z[5,2,4]  R1369     -5.6561392545700073e-01
    z[5,2,4]  R1370     0.707699716091156
    z[5,2,4]  R1371     -6.4364886283874512e-01
    z[5,2,4]  R1372     5.1550066471099854e-01
    z[5,2,5]  R25       1
    z[5,2,5]  R52       -1
    z[5,2,5]  R1269     -1
    z[5,2,5]  R1270     1
    z[5,2,5]  R1273     2.1065457165241241e-01
    z[5,2,5]  R1274     -7.7650360763072968e-02
    z[5,2,5]  R1275     -4.2856833338737488e-01
    z[5,2,5]  R1276     1.0852876305580139e-01
    z[5,2,5]  R1277     -6.0421347618103027e-01
    z[5,2,5]  R1278     -3.2600095868110657e-01
    z[5,2,5]  R1279     0.366743803024292
    z[5,2,5]  R1280     -0.512775719165802
    z[5,2,5]  R1281     2.3371849954128265e-01
    z[5,2,5]  R1282     0.126520574092865
    z[5,2,5]  R1283     -5.0567211583256721e-03
    z[5,2,5]  R1284     2.1239832043647766e-01
    z[5,2,5]  R1285     -1.4609448611736298e-01
    z[5,2,5]  R1286     2.6021143794059753e-01
    z[5,2,5]  R1287     4.4713470339775085e-01
    z[5,2,5]  R1288     0.583529531955719
    z[5,2,5]  R1289     0.211939737200737
    z[5,2,5]  R1290     -2.4932612478733063e-01
    z[5,2,5]  R1291     -6.5293574333190918e-01
    z[5,2,5]  R1292     -2.3178772628307343e-01
    z[5,2,5]  R1293     2.1061576902866364e-02
    z[5,2,5]  R1294     2.0756955444812775e-01
    z[5,2,5]  R1295     1.8175454437732697e-01
    z[5,2,5]  R1296     7.4833102524280548e-02
    z[5,2,5]  R1297     -2.8705310821533203e-01
    z[5,2,5]  R1298     3.4221136569976807e-01
    z[5,2,5]  R1299     -3.9896681904792786e-01
    z[5,2,5]  R1300     -3.4685872495174408e-02
    z[5,2,5]  R1301     4.9487265944480896e-01
    z[5,2,5]  R1302     -1.7112414538860321e-01
    z[5,2,5]  R1303     -0.0635211244225502
    z[5,2,5]  R1304     2.7736338973045349e-01
    z[5,2,5]  R1305     5.5521562695503235e-02
    z[5,2,5]  R1306     2.7796175330877304e-02
    z[5,2,5]  R1307     1.1223144084215164e-01
    z[5,2,5]  R1308     3.6337185651063919e-02
    z[5,2,5]  R1309     -2.2626908123493195e-01
    z[5,2,5]  R1310     1.7067806422710419e-01
    z[5,2,5]  R1311     -1.7152380198240280e-02
    z[5,2,5]  R1312     -3.4348621964454651e-01
    z[5,2,5]  R1313     -1.9725652039051056e-01
    z[5,2,5]  R1314     4.2617791891098022e-01
    z[5,2,5]  R1315     1.1352778412401676e-02
    z[5,2,5]  R1316     -2.4518366903066635e-02
    z[5,2,5]  R1317     -2.9133906960487366e-01
    z[5,2,5]  R1318     2.1445275843143463e-01
    z[5,2,5]  R1319     -4.6159449219703674e-01
    z[5,2,5]  R1320     -2.2193560004234314e-01
    z[5,2,5]  R1321     -1.8358242511749268e-01
    z[5,2,5]  R1322     -3.6293134093284607e-01
    z[5,2,5]  R1323     5.5039305239915848e-02
    z[5,2,5]  R1324     -2.3360683023929596e-01
    z[5,2,5]  R1325     -4.2297882027924061e-03
    z[5,2,5]  R1326     -0.0718153715133667
    z[5,2,5]  R1327     2.5768172740936279e-01
    z[5,2,5]  R1328     3.3670762181282043e-01
    z[5,2,5]  R1329     5.1106613874435425e-01
    z[5,2,5]  R1330     -8.0461136996746063e-02
    z[5,2,5]  R1331     4.8210576176643372e-01
    z[5,2,5]  R1332     1.6107335686683655e-01
    z[5,2,5]  R1333     8.1095799803733826e-02
    z[5,2,5]  R1334     5.4160147905349731e-01
    z[5,2,5]  R1335     5.2025479078292847e-01
    z[5,2,5]  R1336     4.8227846622467041e-01
    z[5,2,5]  R1337     7.5342416763305664e-02
    z[5,2,5]  R1338     1.1733891814947128e-01
    z[5,2,5]  R1339     6.5021711587905884e-01
    z[5,2,5]  R1340     -3.7025246769189835e-02
    z[5,2,5]  R1341     1.1696664243936539e-01
    z[5,2,5]  R1342     -3.3673125505447388e-01
    z[5,2,5]  R1343     1.8170122802257538e-01
    z[5,2,5]  R1344     3.1329768896102905e-01
    z[5,2,5]  R1345     -6.1849659681320190e-01
    z[5,2,5]  R1346     -3.5491830110549927e-01
    z[5,2,5]  R1347     -9.0146347880363464e-02
    z[5,2,5]  R1348     1.0209847241640091e-01
    z[5,2,5]  R1349     0.00407183775678277
    z[5,2,5]  R1350     1.4406004548072815e-01
    z[5,2,5]  R1351     -0.131404310464859
    z[5,2,5]  R1352     -5.6364381313323975e-01
    z[5,2,5]  R1353     -2.3281066119670868e-01
    z[5,2,5]  R1354     4.1498345136642456e-01
    z[5,2,5]  R1355     4.9292922019958496e-02
    z[5,2,5]  R1356     -2.8681412339210510e-01
    z[5,2,5]  R1357     6.9784134626388550e-01
    z[5,2,5]  R1358     -2.2815065085887909e-01
    z[5,2,5]  R1359     2.4691013619303703e-02
    z[5,2,5]  R1360     5.2079174667596817e-02
    z[5,2,5]  R1361     -1.0465037077665329e-01
    z[5,2,5]  R1362     2.4978755414485931e-01
    z[5,2,5]  R1363     2.5284758210182190e-01
    z[5,2,5]  R1364     3.1188917160034180e-01
    z[5,2,5]  R1365     1.3883448205888271e-02
    z[5,2,5]  R1366     1.3978092372417450e-01
    z[5,2,5]  R1367     -4.9397191405296326e-01
    z[5,2,5]  R1368     -1.7135277390480042e-01
    z[5,2,5]  R1369     1.8202652037143707e-01
    z[5,2,5]  R1370     1.2054627388715744e-01
    z[5,2,5]  R1371     -3.5846689343452454e-01
    z[5,2,5]  R1372     -4.3303996324539185e-01
    z[5,2,6]  R26       1
    z[5,2,6]  R53       -1
    z[5,2,6]  R1271     -1
    z[5,2,6]  R1272     1
    z[5,2,6]  R1273     1.5206854045391083e-01
    z[5,2,6]  R1274     -0.0815151035785675
    z[5,2,6]  R1275     1.4401021599769592e-01
    z[5,2,6]  R1276     4.0101242065429688e-01
    z[5,2,6]  R1277     1.4734651148319244e-01
    z[5,2,6]  R1278     2.0967794954776764e-01
    z[5,2,6]  R1279     -1.6668763756752014e-01
    z[5,2,6]  R1280     -3.4199798107147217e-01
    z[5,2,6]  R1281     -6.0024131089448929e-02
    z[5,2,6]  R1282     -3.6240525543689728e-02
    z[5,2,6]  R1283     9.9132414907217026e-03
    z[5,2,6]  R1284     1.7179162800312042e-01
    z[5,2,6]  R1285     -2.2948840260505676e-01
    z[5,2,6]  R1286     2.8815174102783203e-01
    z[5,2,6]  R1287     4.2438122630119324e-01
    z[5,2,6]  R1288     -0.319205641746521
    z[5,2,6]  R1289     5.4390239715576172e-01
    z[5,2,6]  R1290     7.4569158256053925e-02
    z[5,2,6]  R1291     -1.5750029683113098e-01
    z[5,2,6]  R1292     0.297391414642334
    z[5,2,6]  R1293     -3.7479585409164429e-01
    z[5,2,6]  R1294     -1.8527930974960327e-01
    z[5,2,6]  R1295     -1.5197099745273590e-01
    z[5,2,6]  R1296     -3.8313020020723343e-02
    z[5,2,6]  R1297     -7.8656310215592384e-03
    z[5,2,6]  R1298     -4.1217800974845886e-01
    z[5,2,6]  R1299     2.5088205933570862e-01
    z[5,2,6]  R1300     -3.0493089556694031e-01
    z[5,2,6]  R1301     4.5366075634956360e-01
    z[5,2,6]  R1302     2.8514704108238220e-01
    z[5,2,6]  R1303     -1.3209688663482666e-01
    z[5,2,6]  R1304     2.9905205965042114e-01
    z[5,2,6]  R1305     1.1577330529689789e-01
    z[5,2,6]  R1306     2.0468689501285553e-01
    z[5,2,6]  R1307     -8.3370774984359741e-02
    z[5,2,6]  R1308     -1.7821887135505676e-01
    z[5,2,6]  R1309     -1.7275738716125488e-01
    z[5,2,6]  R1310     -4.0734943002462387e-02
    z[5,2,6]  R1311     -8.5410818457603455e-02
    z[5,2,6]  R1312     3.3465859293937683e-01
    z[5,2,6]  R1313     2.8603413701057434e-01
    z[5,2,6]  R1314     6.9640494883060455e-02
    z[5,2,6]  R1315     1.4773635566234589e-01
    z[5,2,6]  R1316     3.5808464884757996e-01
    z[5,2,6]  R1317     0.284882128238678
    z[5,2,6]  R1318     -0.254308819770813
    z[5,2,6]  R1319     1.0130243003368378e-01
    z[5,2,6]  R1320     -2.3207536339759827e-01
    z[5,2,6]  R1321     -1.2426828593015671e-01
    z[5,2,6]  R1322     -3.0167952179908752e-01
    z[5,2,6]  R1323     2.2877737879753113e-01
    z[5,2,6]  R1324     -8.3770573139190674e-02
    z[5,2,6]  R1325     -1.8943063914775848e-01
    z[5,2,6]  R1326     -1.9247531890869141e-01
    z[5,2,6]  R1327     -1.7640799283981323e-01
    z[5,2,6]  R1328     -2.1168164908885956e-01
    z[5,2,6]  R1329     -1.0025624185800552e-01
    z[5,2,6]  R1330     -1.1540773510932922e-01
    z[5,2,6]  R1331     -1.8831816315650940e-01
    z[5,2,6]  R1332     -4.3406596779823303e-01
    z[5,2,6]  R1333     5.3462035953998566e-02
    z[5,2,6]  R1334     -4.1332840919494629e-01
    z[5,2,6]  R1335     -2.7431643009185791e-01
    z[5,2,6]  R1336     -8.0111749470233917e-02
    z[5,2,6]  R1337     -3.6975890398025513e-01
    z[5,2,6]  R1338     -7.7255196869373322e-02
    z[5,2,6]  R1339     -5.4858896881341934e-02
    z[5,2,6]  R1340     -9.0832240879535675e-02
    z[5,2,6]  R1341     3.4952464699745178e-01
    z[5,2,6]  R1342     -2.1520432084798813e-02
    z[5,2,6]  R1343     -2.4955970048904419e-01
    z[5,2,6]  R1344     1.5067370235919952e-01
    z[5,2,6]  R1345     4.1308920830488205e-02
    z[5,2,6]  R1346     3.0079236626625061e-01
    z[5,2,6]  R1347     4.3296954035758972e-01
    z[5,2,6]  R1348     1.2698552012443542e-01
    z[5,2,6]  R1349     5.6059543043375015e-02
    z[5,2,6]  R1350     1.7663882672786713e-01
    z[5,2,6]  R1351     -4.2658916115760803e-01
    z[5,2,6]  R1352     -3.8099822402000427e-01
    z[5,2,6]  R1353     2.5672060251235962e-01
    z[5,2,6]  R1354     -0.246268168091774
    z[5,2,6]  R1355     1.4512288384139538e-02
    z[5,2,6]  R1356     9.0870611369609833e-02
    z[5,2,6]  R1357     2.9818934202194214e-01
    z[5,2,6]  R1358     -9.8133519291877747e-02
    z[5,2,6]  R1359     -2.0349709689617157e-01
    z[5,2,6]  R1360     -6.8014246225357056e-01
    z[5,2,6]  R1361     -2.3519890382885933e-02
    z[5,2,6]  R1362     0.328035831451416
    z[5,2,6]  R1363     2.5234752893447876e-01
    z[5,2,6]  R1364     -5.8398038148880005e-02
    z[5,2,6]  R1365     2.4019230902194977e-01
    z[5,2,6]  R1366     -6.7810076475143433e-01
    z[5,2,6]  R1367     -7.9585418105125427e-02
    z[5,2,6]  R1368     2.5969287753105164e-01
    z[5,2,6]  R1369     -1.3493178784847260e-01
    z[5,2,6]  R1370     1.8260501325130463e-01
    z[5,2,6]  R1371     6.5527461469173431e-02
    z[5,2,6]  R1372     -2.3894280195236206e-01
    z[2,6,0]  R20       -1
    z[2,6,0]  R56       1
    z[2,6,0]  R1373     -1
    z[2,6,0]  R1374     1
    z[2,6,0]  R1387     8.8604754209518433e-01
    z[2,6,0]  R1388     1.4583480358123779e-01
    z[2,6,0]  R1389     7.9103827476501465e-01
    z[2,6,0]  R1390     8.7183523178100586e-01
    z[2,6,0]  R1391     0.828798770904541
    z[2,6,0]  R1392     8.3446949720382690e-01
    z[2,6,0]  R1393     8.2140040397644043e-01
    z[2,6,0]  R1394     3.2014328241348267e-01
    z[2,6,0]  R1395     -5.8035325258970261e-02
    z[2,6,0]  R1396     7.2002267837524414e-01
    z[2,6,0]  R1397     -3.5881298780441284e-01
    z[2,6,0]  R1398     -4.7988590598106384e-01
    z[2,6,0]  R1399     -1.5419688820838928e-01
    z[2,6,0]  R1400     -7.5405031442642212e-01
    z[2,6,0]  R1401     -6.8363982439041138e-01
    z[2,6,0]  R1402     -4.0264037251472473e-01
    z[2,6,0]  R1403     -0.772131085395813
    z[2,6,0]  R1404     -7.4872213602066040e-01
    z[2,6,0]  R1405     -2.5317719578742981e-01
    z[2,6,0]  R1406     -7.6686137914657593e-01
    z[2,6,0]  R1407     4.8272699117660522e-02
    z[2,6,0]  R1408     -2.3450122773647308e-01
    z[2,6,0]  R1409     4.4383369386196136e-02
    z[2,6,0]  R1410     -1.6060508787631989e-01
    z[2,6,0]  R1411     3.9612289518117905e-02
    z[2,6,0]  R1412     -9.2905491590499878e-02
    z[2,6,0]  R1413     -7.7253989875316620e-02
    z[2,6,0]  R1414     -4.0585073828697205e-01
    z[2,6,0]  R1415     3.5294704139232635e-02
    z[2,6,0]  R1416     -1.3486324250698090e-01
    z[2,6,0]  R1417     1.8007567524909973e-01
    z[2,6,0]  R1418     1.6546323604416102e-04
    z[2,6,0]  R1419     2.5776728987693787e-01
    z[2,6,0]  R1420     -4.1691058874130249e-01
    z[2,6,0]  R1421     -2.6028215885162354e-01
    z[2,6,0]  R1422     6.9311964511871338e-01
    z[2,6,0]  R1423     -4.1471680998802185e-01
    z[2,6,0]  R1424     -5.6344783306121826e-01
    z[2,6,0]  R1425     -4.9564579129219055e-01
    z[2,6,0]  R1426     -1.3505442440509796e-01
    z[2,6,0]  R1427     -0.564138650894165
    z[2,6,0]  R1428     3.5655394196510315e-01
    z[2,6,0]  R1429     1.7037992179393768e-01
    z[2,6,0]  R1430     -1.5335051715373993e-01
    z[2,6,0]  R1431     -3.0667927861213684e-01
    z[2,6,0]  R1432     -2.1232496201992035e-01
    z[2,6,0]  R1433     8.5173296928405762e-01
    z[2,6,0]  R1434     8.8291460275650024e-01
    z[2,6,0]  R1435     0.199258491396904
    z[2,6,0]  R1436     -1.7429096996784210e-01
    z[2,6,0]  R1437     2.3610081523656845e-02
    z[2,6,0]  R1438     -3.2982969284057617e-01
    z[2,6,0]  R1439     6.9847536087036133e-01
    z[2,6,0]  R1440     -4.6365892887115479e-01
    z[2,6,0]  R1441     1.2046752125024796e-01
    z[2,6,0]  R1442     -0.527647852897644
    z[2,6,0]  R1443     2.2033995389938354e-01
    z[2,6,0]  R1444     2.4991865456104279e-01
    z[2,6,0]  R1445     -0.868701696395874
    z[2,6,0]  R1446     -2.1660651266574860e-01
    z[2,6,0]  R1447     8.6552582681179047e-02
    z[2,6,0]  R1448     -2.6703274250030518e-01
    z[2,6,0]  R1449     -4.2324659228324890e-01
    z[2,6,0]  R1450     2.0893737673759460e-01
    z[2,6,0]  R1451     2.3474301397800446e-01
    z[2,6,0]  R1452     3.7857976555824280e-01
    z[2,6,0]  R1453     -3.1002092361450195e-01
    z[2,6,0]  R1454     1.0676967352628708e-01
    z[2,6,0]  R1455     -0.282500684261322
    z[2,6,0]  R1456     1.3480694591999054e-01
    z[2,6,0]  R1457     -5.2197545766830444e-01
    z[2,6,0]  R1458     -1.6462321579456329e-01
    z[2,6,0]  R1459     -1.6076698899269104e-01
    z[2,6,0]  R1460     -3.8243892788887024e-01
    z[2,6,0]  R1461     -1.0251833498477936e-01
    z[2,6,0]  R1462     9.1036915779113770e-01
    z[2,6,0]  R1463     8.9052850008010864e-01
    z[2,6,0]  R1464     7.8248989582061768e-01
    z[2,6,0]  R1465     6.7351412773132324e-01
    z[2,6,0]  R1466     8.4913635253906250e-01
    z[2,6,0]  R1467     -6.7606532573699951e-01
    z[2,6,0]  R1468     -2.2798025608062744e-01
    z[2,6,0]  R1469     4.7485885024070740e-01
    z[2,6,0]  R1470     -7.7141416072845459e-01
    z[2,6,0]  R1471     -3.1777629256248474e-01
    z[2,6,0]  R1472     1.9203804433345795e-01
    z[2,6,0]  R1473     0.0636850968003273
    z[2,6,0]  R1474     -1.9665436446666718e-01
    z[2,6,0]  R1475     8.7079554796218872e-03
    z[2,6,0]  R1476     -2.1306616067886353e-01
    z[2,6,0]  R1477     -5.2853122353553772e-02
    z[2,6,0]  R1478     2.9397246241569519e-01
    z[2,6,0]  R1479     0.219319149851799
    z[2,6,0]  R1480     3.9431083202362061e-01
    z[2,6,0]  R1481     -5.3770607709884644e-01
    z[2,6,0]  R1482     -0.549445629119873
    z[2,6,0]  R1483     -4.8566406965255737e-01
    z[2,6,0]  R1484     -5.0109875202178955e-01
    z[2,6,0]  R1485     4.9492076039314270e-01
    z[2,6,0]  R1486     6.7345392704010010e-01
    z[2,6,0]  R1487     -6.5735715627670288e-01
    z[2,6,0]  R1488     7.0079976320266724e-01
    z[2,6,0]  R1489     6.0476040840148926e-01
    z[2,6,0]  R1490     0.443428635597229
    z[2,6,0]  R1491     1.5491665899753571e-01
    z[2,6,0]  R1492     4.6872106194496155e-01
    z[2,6,0]  R1493     3.4745091199874878e-01
    z[2,6,0]  R1494     6.8955379724502563e-01
    z[2,6,0]  R1495     -4.6143087744712830e-01
    z[2,6,0]  R1496     5.3690975904464722e-01
    z[2,6,0]  R1497     -7.0697891712188721e-01
    z[2,6,0]  R1498     1.1184625327587128e-01
    z[2,6,0]  R1499     -5.5554300546646118e-01
    z[2,6,0]  R1500     -8.5844683647155762e-01
    z[2,6,0]  R1501     2.3760078847408295e-01
    z[2,6,0]  R1502     3.0090087652206421e-01
    z[2,6,0]  R1503     5.4956245422363281e-01
    z[2,6,0]  R1504     -1.3233710825443268e-01
    z[2,6,0]  R1505     1.7166146636009216e-01
    z[2,6,0]  R1506     4.6342480182647705e-01
    z[2,6,0]  R1507     1.8599800765514374e-02
    z[2,6,0]  R1508     0.588977038860321
    z[2,6,0]  R1509     1.8756064772605896e-01
    z[2,6,0]  R1510     8.9630484580993652e-02
    z[2,6,0]  R1511     -1.5797346830368042e-01
    z[2,6,0]  R1512     6.1854708194732666e-01
    z[2,6,0]  R1513     3.3072385191917419e-01
    z[2,6,0]  R1514     -3.1328000128269196e-02
    z[2,6,0]  R1515     7.6487630605697632e-02
    z[2,6,0]  R1516     3.5481783747673035e-01
    z[2,6,0]  R1517     -5.1282113790512085e-01
    z[2,6,0]  R1518     -7.3605132102966309e-01
    z[2,6,0]  R1519     7.8114360570907593e-02
    z[2,6,0]  R1520     4.9200615286827087e-01
    z[2,6,0]  R1521     6.2441922724246979e-02
    z[2,6,0]  R1522     8.6419032886624336e-03
    z[2,6,0]  R1523     -3.9424884319305420e-01
    z[2,6,0]  R1524     -3.1746748089790344e-01
    z[2,6,0]  R1525     -4.0277183055877686e-01
    z[2,6,0]  R1526     3.1345593929290771e-01
    z[2,6,1]  R21       -1
    z[2,6,1]  R57       1
    z[2,6,1]  R1375     -1
    z[2,6,1]  R1376     1
    z[2,6,1]  R1387     -2.0820298790931702e-01
    z[2,6,1]  R1388     -2.4536137282848358e-01
    z[2,6,1]  R1389     -1.8139237165451050e-01
    z[2,6,1]  R1390     -6.7742630839347839e-02
    z[2,6,1]  R1391     2.2924799472093582e-02
    z[2,6,1]  R1392     -1.3303156197071075e-01
    z[2,6,1]  R1393     -1.2285141646862030e-01
    z[2,6,1]  R1394     -1.8322411179542542e-01
    z[2,6,1]  R1395     -2.3186931014060974e-01
    z[2,6,1]  R1396     -1.5166489779949188e-01
    z[2,6,1]  R1397     7.7723509073257446e-01
    z[2,6,1]  R1398     6.2624263763427734e-01
    z[2,6,1]  R1399     8.9889067411422729e-01
    z[2,6,1]  R1400     4.2762383818626404e-01
    z[2,6,1]  R1401     3.5715842247009277e-01
    z[2,6,1]  R1402     0.71956866979599
    z[2,6,1]  R1403     0.166547030210495
    z[2,6,1]  R1404     1.8764916062355042e-01
    z[2,6,1]  R1405     8.6886739730834961e-01
    z[2,6,1]  R1406     2.7385982871055603e-01
    z[2,6,1]  R1407     -9.1263711452484131e-01
    z[2,6,1]  R1408     -8.6090552806854248e-01
    z[2,6,1]  R1409     -7.9708242416381836e-01
    z[2,6,1]  R1410     -7.9676896333694458e-01
    z[2,6,1]  R1411     -8.3311569690704346e-01
    z[2,6,1]  R1412     -8.7095212936401367e-01
    z[2,6,1]  R1413     -0.763202428817749
    z[2,6,1]  R1414     -7.7917784452438354e-01
    z[2,6,1]  R1415     -0.824566125869751
    z[2,6,1]  R1416     -6.9372671842575073e-01
    z[2,6,1]  R1417     -0.659796953201294
    z[2,6,1]  R1418     -4.9183964729309082e-01
    z[2,6,1]  R1419     -5.3227448463439941e-01
    z[2,6,1]  R1420     -1.8455389142036438e-01
    z[2,6,1]  R1421     -2.4131046235561371e-01
    z[2,6,1]  R1422     -5.4709357023239136e-01
    z[2,6,1]  R1423     -5.6468397378921509e-01
    z[2,6,1]  R1424     5.1037472486495972e-01
    z[2,6,1]  R1425     -0.705713152885437
    z[2,6,1]  R1426     1.6149090230464935e-01
    z[2,6,1]  R1427     -4.5664042234420776e-01
    z[2,6,1]  R1428     -3.6807930469512939e-01
    z[2,6,1]  R1429     -2.4916736781597137e-01
    z[2,6,1]  R1430     3.8674041628837585e-01
    z[2,6,1]  R1431     0.219456747174263
    z[2,6,1]  R1432     4.7260022163391113e-01
    z[2,6,1]  R1433     -2.6977792382240295e-01
    z[2,6,1]  R1434     -1.5420758724212646e-01
    z[2,6,1]  R1435     6.4654910564422607e-01
    z[2,6,1]  R1436     4.7253987193107605e-01
    z[2,6,1]  R1437     1.4519819058477879e-02
    z[2,6,1]  R1438     -5.6691801548004150e-01
    z[2,6,1]  R1439     -4.2047610878944397e-01
    z[2,6,1]  R1440     7.2132611274719238e-01
    z[2,6,1]  R1441     -4.8361968994140625e-01
    z[2,6,1]  R1442     2.6444411277770996e-01
    z[2,6,1]  R1443     -9.6356995403766632e-02
    z[2,6,1]  R1444     -5.6525218486785889e-01
    z[2,6,1]  R1445     2.6983615756034851e-01
    z[2,6,1]  R1446     -2.4216964840888977e-01
    z[2,6,1]  R1447     -7.1035593748092651e-01
    z[2,6,1]  R1448     -6.9905835390090942e-01
    z[2,6,1]  R1449     7.4038130044937134e-01
    z[2,6,1]  R1450     -4.5106706023216248e-01
    z[2,6,1]  R1451     3.1020686030387878e-01
    z[2,6,1]  R1452     1.9607998430728912e-01
    z[2,6,1]  R1453     2.8569355607032776e-02
    z[2,6,1]  R1454     -0.0813002958893776
    z[2,6,1]  R1455     -3.0414137244224548e-01
    z[2,6,1]  R1456     1.0632056742906570e-01
    z[2,6,1]  R1457     -3.2811793684959412e-01
    z[2,6,1]  R1458     -3.2577949762344360e-01
    z[2,6,1]  R1459     -2.3336495459079742e-01
    z[2,6,1]  R1460     -5.3701114654541016e-01
    z[2,6,1]  R1461     -4.4717708230018616e-01
    z[2,6,1]  R1462     0.0356532521545887
    z[2,6,1]  R1463     -1.8908347189426422e-01
    z[2,6,1]  R1464     2.1818211302161217e-02
    z[2,6,1]  R1465     -2.2090595960617065e-01
    z[2,6,1]  R1466     -1.9661180675029755e-01
    z[2,6,1]  R1467     -1.0527092218399048e-01
    z[2,6,1]  R1468     -6.9276988506317139e-01
    z[2,6,1]  R1469     3.3125367015600204e-02
    z[2,6,1]  R1470     1.1375380307435989e-01
    z[2,6,1]  R1471     -5.4619574546813965e-01
    z[2,6,1]  R1472     2.7200818061828613e-01
    z[2,6,1]  R1473     -7.2978264093399048e-01
    z[2,6,1]  R1474     -6.5107178688049316e-01
    z[2,6,1]  R1475     -1.5670144930481911e-02
    z[2,6,1]  R1476     -6.8149912357330322e-01
    z[2,6,1]  R1477     -1.3495287299156189e-01
    z[2,6,1]  R1478     -8.0948662757873535e-01
    z[2,6,1]  R1479     -7.0741057395935059e-01
    z[2,6,1]  R1480     -8.3427554368972778e-01
    z[2,6,1]  R1481     -1.5183715522289276e-01
    z[2,6,1]  R1482     -8.6842171847820282e-02
    z[2,6,1]  R1483     -1.7410792410373688e-01
    z[2,6,1]  R1484     -2.6296639442443848e-01
    z[2,6,1]  R1485     -2.4480876326560974e-01
    z[2,6,1]  R1486     -3.5698909312486649e-02
    z[2,6,1]  R1487     -2.2902448475360870e-01
    z[2,6,1]  R1488     3.6682537198066711e-01
    z[2,6,1]  R1489     8.2808077335357666e-02
    z[2,6,1]  R1490     -1.9834369421005249e-01
    z[2,6,1]  R1491     -8.6241155862808228e-01
    z[2,6,1]  R1492     1.6020224988460541e-01
    z[2,6,1]  R1493     -0.084617480635643
    z[2,6,1]  R1494     1.7293068766593933e-01
    z[2,6,1]  R1495     1.3825920224189758e-01
    z[2,6,1]  R1496     4.1986593604087830e-01
    z[2,6,1]  R1497     -5.4223853349685669e-01
    z[2,6,1]  R1498     -7.8635834157466888e-02
    z[2,6,1]  R1499     -3.4241041541099548e-01
    z[2,6,1]  R1500     1.8217015266418457e-01
    z[2,6,1]  R1501     -8.9206188917160034e-01
    z[2,6,1]  R1502     -7.3266369104385376e-01
    z[2,6,1]  R1503     3.1029051542282104e-01
    z[2,6,1]  R1504     -7.3007690906524658e-01
    z[2,6,1]  R1505     -6.3801366090774536e-01
    z[2,6,1]  R1506     -2.4115969240665436e-01
    z[2,6,1]  R1507     -2.7241986244916916e-02
    z[2,6,1]  R1508     1.2814275920391083e-01
    z[2,6,1]  R1509     -6.4726972579956055e-01
    z[2,6,1]  R1510     -8.4598058462142944e-01
    z[2,6,1]  R1511     -6.4722114801406860e-01
    z[2,6,1]  R1512     -3.2419040799140930e-01
    z[2,6,1]  R1513     5.7426650077104568e-02
    z[2,6,1]  R1514     -4.7238388657569885e-01
    z[2,6,1]  R1515     2.6329854130744934e-01
    z[2,6,1]  R1516     8.4887528419494629e-01
    z[2,6,1]  R1517     -9.0420819818973541e-02
    z[2,6,1]  R1518     -9.8409861326217651e-02
    z[2,6,1]  R1519     -8.7990230321884155e-01
    z[2,6,1]  R1520     1.8412467092275620e-02
    z[2,6,1]  R1521     -5.4374831914901733e-01
    z[2,6,1]  R1522     2.5878661870956421e-01
    z[2,6,1]  R1523     6.9609928131103516e-01
    z[2,6,1]  R1524     7.1002978086471558e-01
    z[2,6,1]  R1525     6.3367408514022827e-01
    z[2,6,1]  R1526     8.3913958072662354e-01
    z[2,6,2]  R22       -1
    z[2,6,2]  R58       1
    z[2,6,2]  R1377     -1
    z[2,6,2]  R1378     1
    z[2,6,2]  R1387     0.0910937711596489
    z[2,6,2]  R1388     8.6018282175064087e-01
    z[2,6,2]  R1389     4.2260631918907166e-01
    z[2,6,2]  R1390     -4.1567340493202209e-02
    z[2,6,2]  R1391     3.7105602025985718e-01
    z[2,6,2]  R1392     4.1188856959342957e-01
    z[2,6,2]  R1393     -0.0768071785569191
    z[2,6,2]  R1394     9.0562599897384644e-01
    z[2,6,2]  R1395     9.0104812383651733e-01
    z[2,6,2]  R1396     -0.0647159144282341
    z[2,6,2]  R1397     -2.9394480586051941e-01
    z[2,6,2]  R1398     -3.2875162363052368e-01
    z[2,6,2]  R1399     -3.6022484302520752e-01
    z[2,6,2]  R1400     -2.7992677688598633e-01
    z[2,6,2]  R1401     -4.0945509076118469e-01
    z[2,6,2]  R1402     -3.1449410319328308e-01
    z[2,6,2]  R1403     -2.1376132965087891e-01
    z[2,6,2]  R1404     -4.1909557580947876e-01
    z[2,6,2]  R1405     -1.9536575675010681e-01
    z[2,6,2]  R1406     -1.6567899286746979e-01
    z[2,6,2]  R1407     2.1565565839409828e-02
    z[2,6,2]  R1408     1.8663156032562256e-01
    z[2,6,2]  R1409     1.1444225907325745e-01
    z[2,6,2]  R1410     1.7330738902091980e-01
    z[2,6,2]  R1411     1.9123714417219162e-02
    z[2,6,2]  R1412     2.7071169018745422e-01
    z[2,6,2]  R1413     5.5021595209836960e-02
    z[2,6,2]  R1414     -8.9638732373714447e-02
    z[2,6,2]  R1415     -1.2983185052871704e-01
    z[2,6,2]  R1416     0.456155925989151
    z[2,6,2]  R1417     6.8963599205017090e-01
    z[2,6,2]  R1418     3.6888051033020020e-01
    z[2,6,2]  R1419     4.8535147309303284e-01
    z[2,6,2]  R1420     5.2804708480834961e-01
    z[2,6,2]  R1421     5.0944548845291138e-01
    z[2,6,2]  R1422     -3.9497545361518860e-01
    z[2,6,2]  R1423     2.5180166959762573e-01
    z[2,6,2]  R1424     -2.9711747169494629e-01
    z[2,6,2]  R1425     3.3206200599670410e-01
    z[2,6,2]  R1426     -8.2156014442443848e-01
    z[2,6,2]  R1427     5.9368723630905151e-01
    z[2,6,2]  R1428     3.6254769563674927e-01
    z[2,6,2]  R1429     0.542304515838623
    z[2,6,2]  R1430     -6.8246215581893921e-01
    z[2,6,2]  R1431     -6.6549074649810791e-01
    z[2,6,2]  R1432     -6.3054847717285156e-01
    z[2,6,2]  R1433     -2.1745751798152924e-01
    z[2,6,2]  R1434     -7.5013250112533569e-02
    z[2,6,2]  R1435     -5.2669900655746460e-01
    z[2,6,2]  R1436     -4.9416157603263855e-01
    z[2,6,2]  R1437     7.6543998718261719e-01
    z[2,6,2]  R1438     3.4518721699714661e-01
    z[2,6,2]  R1439     -5.2202981710433960e-01
    z[2,6,2]  R1440     -0.376355916261673
    z[2,6,2]  R1441     1.5767641365528107e-01
    z[2,6,2]  R1442     -7.2714775800704956e-01
    z[2,6,2]  R1443     4.8233687877655029e-01
    z[2,6,2]  R1444     3.7854695320129395e-01
    z[2,6,2]  R1445     -6.1420563608407974e-02
    z[2,6,2]  R1446     3.6835893988609314e-01
    z[2,6,2]  R1447     5.4648733139038086e-01
    z[2,6,2]  R1448     4.1992199420928955e-01
    z[2,6,2]  R1449     -0.415484219789505
    z[2,6,2]  R1450     5.0685596466064453e-01
    z[2,6,2]  R1451     4.7984153032302856e-01
    z[2,6,2]  R1452     -4.0168985724449158e-01
    z[2,6,2]  R1453     -0.302696168422699
    z[2,6,2]  R1454     -1.9866585731506348e-01
    z[2,6,2]  R1455     -5.0169765949249268e-01
    z[2,6,2]  R1456     -2.9586029052734375e-01
    z[2,6,2]  R1457     4.9247068166732788e-01
    z[2,6,2]  R1458     0.702812671661377
    z[2,6,2]  R1459     7.4170178174972534e-01
    z[2,6,2]  R1460     9.4406723976135254e-02
    z[2,6,2]  R1461     2.1973843872547150e-01
    z[2,6,2]  R1462     1.1154337227344513e-01
    z[2,6,2]  R1463     6.8829543888568878e-02
    z[2,6,2]  R1464     2.6227712631225586e-01
    z[2,6,2]  R1465     4.1704177856445312e-01
    z[2,6,2]  R1466     0.0787450522184372
    z[2,6,2]  R1467     -2.8018802404403687e-01
    z[2,6,2]  R1468     -1.8012490868568420e-01
    z[2,6,2]  R1469     5.7031378149986267e-02
    z[2,6,2]  R1470     -3.2692289352416992e-01
    z[2,6,2]  R1471     -2.9781109094619751e-01
    z[2,6,2]  R1472     1.8366594612598419e-01
    z[2,6,2]  R1473     -0.234488382935524
    z[2,6,2]  R1474     -2.7368941903114319e-01
    z[2,6,2]  R1475     -1.5721577405929565e-01
    z[2,6,2]  R1476     -7.8069724142551422e-02
    z[2,6,2]  R1477     4.0266913175582886e-01
    z[2,6,2]  R1478     3.4896153211593628e-01
    z[2,6,2]  R1479     6.5445274114608765e-02
    z[2,6,2]  R1480     -1.3660962879657745e-01
    z[2,6,2]  R1481     -2.1415871381759644e-01
    z[2,6,2]  R1482     -2.9749071598052979e-01
    z[2,6,2]  R1483     -3.1292143464088440e-01
    z[2,6,2]  R1484     -4.0407484769821167e-01
    z[2,6,2]  R1485     -2.4016296863555908e-01
    z[2,6,2]  R1486     -1.2989491224288940e-01
    z[2,6,2]  R1487     -3.2716563344001770e-01
    z[2,6,2]  R1488     2.5489461421966553e-01
    z[2,6,2]  R1489     -5.1718336343765259e-01
    z[2,6,2]  R1490     -6.7347055673599243e-01
    z[2,6,2]  R1491     -1.0436603426933289e-01
    z[2,6,2]  R1492     -3.2193490862846375e-01
    z[2,6,2]  R1493     -0.389515221118927
    z[2,6,2]  R1494     -0.0582720972597599
    z[2,6,2]  R1495     1.8238976597785950e-01
    z[2,6,2]  R1496     1.2936817109584808e-01
    z[2,6,2]  R1497     -1.4872124791145325e-01
    z[2,6,2]  R1498     2.0290501415729523e-01
    z[2,6,2]  R1499     -7.2191491723060608e-02
    z[2,6,2]  R1500     7.4390321969985962e-02
    z[2,6,2]  R1501     -8.6434474214911461e-03
    z[2,6,2]  R1502     -2.8759497404098511e-01
    z[2,6,2]  R1503     1.6714119911193848e-01
    z[2,6,2]  R1504     -5.2721619606018066e-01
    z[2,6,2]  R1505     -1.3237448036670685e-01
    z[2,6,2]  R1506     -6.3532269001007080e-01
    z[2,6,2]  R1507     4.0951010584831238e-01
    z[2,6,2]  R1508     -3.0285583809018135e-02
    z[2,6,2]  R1509     -2.8604707121849060e-01
    z[2,6,2]  R1510     -7.4590439908206463e-03
    z[2,6,2]  R1511     -7.6503805816173553e-02
    z[2,6,2]  R1512     -2.6078349351882935e-01
    z[2,6,2]  R1513     -1.5917524695396423e-01
    z[2,6,2]  R1514     -2.2744590044021606e-01
    z[2,6,2]  R1515     2.4288256466388702e-01
    z[2,6,2]  R1516     1.7767339944839478e-02
    z[2,6,2]  R1517     7.7531868219375610e-01
    z[2,6,2]  R1518     1.4420564472675323e-01
    z[2,6,2]  R1519     -0.339753121137619
    z[2,6,2]  R1520     -6.8565420806407928e-02
    z[2,6,2]  R1521     -4.5177906751632690e-01
    z[2,6,2]  R1522     1.1948562413454056e-01
    z[2,6,2]  R1523     -2.4445956945419312e-01
    z[2,6,2]  R1524     -2.9381096363067627e-01
    z[2,6,2]  R1525     -2.6035633683204651e-01
    z[2,6,2]  R1526     -1.3560469448566437e-01
    z[2,6,3]  R23       -1
    z[2,6,3]  R59       1
    z[2,6,3]  R1379     -1
    z[2,6,3]  R1380     1
    z[2,6,3]  R1387     3.6288830637931824e-01
    z[2,6,3]  R1388     2.6031108573079109e-02
    z[2,6,3]  R1389     3.5282278060913086e-01
    z[2,6,3]  R1390     3.7063917517662048e-01
    z[2,6,3]  R1391     3.4668728709220886e-01
    z[2,6,3]  R1392     0.280091255903244
    z[2,6,3]  R1393     3.0276027321815491e-01
    z[2,6,3]  R1394     -0.0650770291686058
    z[2,6,3]  R1395     1.5361729077994823e-02
    z[2,6,3]  R1396     3.7681087851524353e-01
    z[2,6,3]  R1397     -1.1669117212295532e-01
    z[2,6,3]  R1398     -2.6099857687950134e-01
    z[2,6,3]  R1399     -1.2423708289861679e-01
    z[2,6,3]  R1400     -1.9255127012729645e-01
    z[2,6,3]  R1401     -1.3361001014709473e-01
    z[2,6,3]  R1402     -3.3215454220771790e-01
    z[2,6,3]  R1403     -1.3045512139797211e-01
    z[2,6,3]  R1404     -3.0237317085266113e-01
    z[2,6,3]  R1405     -1.8618687987327576e-01
    z[2,6,3]  R1406     -2.9385924339294434e-01
    z[2,6,3]  R1407     1.7202377319335938e-01
    z[2,6,3]  R1408     3.0013132095336914e-01
    z[2,6,3]  R1409     3.1678459048271179e-01
    z[2,6,3]  R1410     5.1525235176086426e-01
    z[2,6,3]  R1411     1.6616627573966980e-02
    z[2,6,3]  R1412     -2.5784291326999664e-02
    z[2,6,3]  R1413     2.7257108688354492e-01
    z[2,6,3]  R1414     3.2830587029457092e-01
    z[2,6,3]  R1415     1.7882893979549408e-01
    z[2,6,3]  R1416     -7.8448191285133362e-02
    z[2,6,3]  R1417     2.0064114034175873e-01
    z[2,6,3]  R1418     -1.5162938833236694e-01
    z[2,6,3]  R1419     -7.9044135054573417e-04
    z[2,6,3]  R1420     -2.9002451896667480e-01
    z[2,6,3]  R1421     -6.2565606832504272e-01
    z[2,6,3]  R1422     0.141846165060997
    z[2,6,3]  R1423     -1.3586845993995667e-01
    z[2,6,3]  R1424     -2.4493041634559631e-01
    z[2,6,3]  R1425     8.6284153163433075e-02
    z[2,6,3]  R1426     -3.9184951782226562e-01
    z[2,6,3]  R1427     -1.4163862168788910e-01
    z[2,6,3]  R1428     -6.7420870065689087e-01
    z[2,6,3]  R1429     3.4459149837493896e-01
    z[2,6,3]  R1430     -1.3506361842155457e-01
    z[2,6,3]  R1431     -4.0715873241424561e-01
    z[2,6,3]  R1432     -1.5841390192508698e-01
    z[2,6,3]  R1433     -4.7076758928596973e-03
    z[2,6,3]  R1434     -2.6557031273841858e-01
    z[2,6,3]  R1435     -1.9811186194419861e-01
    z[2,6,3]  R1436     -1.9661815464496613e-01
    z[2,6,3]  R1437     -5.2235692739486694e-01
    z[2,6,3]  R1438     -4.6523699164390564e-01
    z[2,6,3]  R1439     1.6508273780345917e-01
    z[2,6,3]  R1440     -1.6416238248348236e-01
    z[2,6,3]  R1441     -2.9310640692710876e-01
    z[2,6,3]  R1442     -2.4496681988239288e-01
    z[2,6,3]  R1443     -8.1528216600418091e-01
    z[2,6,3]  R1444     -7.7290818095207214e-02
    z[2,6,3]  R1445     -2.4361704289913177e-01
    z[2,6,3]  R1446     -6.9557827711105347e-01
    z[2,6,3]  R1447     2.0319934189319611e-01
    z[2,6,3]  R1448     -6.2119122594594955e-03
    z[2,6,3]  R1449     -1.5458916127681732e-01
    z[2,6,3]  R1450     -9.3709513545036316e-02
    z[2,6,3]  R1451     2.6010328531265259e-01
    z[2,6,3]  R1452     -7.3046904802322388e-01
    z[2,6,3]  R1453     -6.6346544027328491e-01
    z[2,6,3]  R1454     -6.2754082679748535e-01
    z[2,6,3]  R1455     -1.7004366219043732e-01
    z[2,6,3]  R1456     -0.610435426235199
    z[2,6,3]  R1457     -2.7742058038711548e-01
    z[2,6,3]  R1458     -2.8037565946578979e-01
    z[2,6,3]  R1459     -5.1362150907516479e-01
    z[2,6,3]  R1460     -2.9821822047233582e-01
    z[2,6,3]  R1461     -4.2441949248313904e-01
    z[2,6,3]  R1462     3.2711493968963623e-01
    z[2,6,3]  R1463     1.3262446224689484e-01
    z[2,6,3]  R1464     5.3580540418624878e-01
    z[2,6,3]  R1465     5.4123628139495850e-01
    z[2,6,3]  R1466     2.9771557450294495e-01
    z[2,6,3]  R1467     -8.4155023097991943e-02
    z[2,6,3]  R1468     5.4116624593734741e-01
    z[2,6,3]  R1469     -6.9419378042221069e-01
    z[2,6,3]  R1470     4.6975526213645935e-01
    z[2,6,3]  R1471     6.6987228393554688e-01
    z[2,6,3]  R1472     -5.3416329622268677e-01
    z[2,6,3]  R1473     1.8474790453910828e-01
    z[2,6,3]  R1474     5.1658838987350464e-01
    z[2,6,3]  R1475     -5.5820119380950928e-01
    z[2,6,3]  R1476     6.4539723098278046e-02
    z[2,6,3]  R1477     -3.7743154168128967e-01
    z[2,6,3]  R1478     9.7281597554683685e-02
    z[2,6,3]  R1479     0.356892853975296
    z[2,6,3]  R1480     -1.4545871317386627e-01
    z[2,6,3]  R1481     4.8349192738533020e-01
    z[2,6,3]  R1482     4.4699767231941223e-01
    z[2,6,3]  R1483     3.7286359071731567e-01
    z[2,6,3]  R1484     2.3481087386608124e-01
    z[2,6,3]  R1485     -1.5259023755788803e-02
    z[2,6,3]  R1486     -5.4600322246551514e-01
    z[2,6,3]  R1487     -0.187056303024292
    z[2,6,3]  R1488     -3.7157908082008362e-01
    z[2,6,3]  R1489     1.8274098634719849e-01
    z[2,6,3]  R1490     4.1281515359878540e-01
    z[2,6,3]  R1491     -2.9662927985191345e-01
    z[2,6,3]  R1492     4.4106256961822510e-01
    z[2,6,3]  R1493     5.0108444690704346e-01
    z[2,6,3]  R1494     -3.9847409725189209e-01
    z[2,6,3]  R1495     7.2100222110748291e-01
    z[2,6,3]  R1496     -4.0396827459335327e-01
    z[2,6,3]  R1497     -2.8399446606636047e-01
    z[2,6,3]  R1498     -7.1887111663818359e-01
    z[2,6,3]  R1499     2.4760019034147263e-02
    z[2,6,3]  R1500     2.3305064439773560e-01
    z[2,6,3]  R1501     -1.5973395109176636e-01
    z[2,6,3]  R1502     3.9475908875465393e-01
    z[2,6,3]  R1503     -5.1230156421661377e-01
    z[2,6,3]  R1504     1.2086557596921921e-01
    z[2,6,3]  R1505     -4.4497188180685043e-02
    z[2,6,3]  R1506     3.5757806897163391e-01
    z[2,6,3]  R1507     -7.2074049711227417e-01
    z[2,6,3]  R1508     -7.3832678794860840e-01
    z[2,6,3]  R1509     6.1979812383651733e-01
    z[2,6,3]  R1510     1.5685656666755676e-01
    z[2,6,3]  R1511     4.2695918679237366e-01
    z[2,6,3]  R1512     7.6710104942321777e-02
    z[2,6,3]  R1513     -6.6808730363845825e-01
    z[2,6,3]  R1514     6.7740833759307861e-01
    z[2,6,3]  R1515     5.4901689291000366e-01
    z[2,6,3]  R1516     4.8863638192415237e-02
    z[2,6,3]  R1517     0.0647546723484993
    z[2,6,3]  R1518     3.7845405936241150e-01
    z[2,6,3]  R1519     2.2013500332832336e-01
    z[2,6,3]  R1520     4.9892172217369080e-01
    z[2,6,3]  R1521     4.7018688917160034e-01
    z[2,6,3]  R1522     0.410070538520813
    z[2,6,3]  R1523     -6.3829235732555389e-02
    z[2,6,3]  R1524     -1.7630833387374878e-01
    z[2,6,3]  R1525     4.5861587859690189e-03
    z[2,6,3]  R1526     -3.7304491270333529e-03
    z[2,6,4]  R24       -1
    z[2,6,4]  R60       1
    z[2,6,4]  R1381     -1
    z[2,6,4]  R1382     1
    z[2,6,4]  R1387     -1.0050161927938461e-01
    z[2,6,4]  R1388     1.0758806765079498e-01
    z[2,6,4]  R1389     1.4761133491992950e-01
    z[2,6,4]  R1390     2.3139512538909912e-01
    z[2,6,4]  R1391     1.8747209012508392e-01
    z[2,6,4]  R1392     0.0691203773021698
    z[2,6,4]  R1393     3.6277133226394653e-01
    z[2,6,4]  R1394     -9.3559734523296356e-02
    z[2,6,4]  R1395     3.5093545913696289e-01
    z[2,6,4]  R1396     2.8707376122474670e-01
    z[2,6,4]  R1397     -2.1543622016906738e-01
    z[2,6,4]  R1398     -1.2187865376472473e-01
    z[2,6,4]  R1399     3.2665453851222992e-02
    z[2,6,4]  R1400     -6.5461009740829468e-02
    z[2,6,4]  R1401     -2.3137234151363373e-01
    z[2,6,4]  R1402     1.4333372004330158e-02
    z[2,6,4]  R1403     -3.0005258321762085e-01
    z[2,6,4]  R1404     -1.8443909287452698e-01
    z[2,6,4]  R1405     -2.4288322031497955e-01
    z[2,6,4]  R1406     -1.9801400601863861e-02
    z[2,6,4]  R1407     2.8166922926902771e-01
    z[2,6,4]  R1408     1.3172371685504913e-01
    z[2,6,4]  R1409     4.6188560128211975e-01
    z[2,6,4]  R1410     4.0505036711692810e-02
    z[2,6,4]  R1411     0.454078733921051
    z[2,6,4]  R1412     -2.6080831885337830e-02
    z[2,6,4]  R1413     2.5098109245300293e-01
    z[2,6,4]  R1414     3.0422726273536682e-01
    z[2,6,4]  R1415     4.6035513281822205e-02
    z[2,6,4]  R1416     -2.6826274394989014e-01
    z[2,6,4]  R1417     -8.3375498652458191e-02
    z[2,6,4]  R1418     -3.6722859740257263e-01
    z[2,6,4]  R1419     2.6221892237663269e-01
    z[2,6,4]  R1420     -4.3608167767524719e-01
    z[2,6,4]  R1421     -2.8397905826568604e-01
    z[2,6,4]  R1422     1.5624053776264191e-01
    z[2,6,4]  R1423     3.8545615971088409e-02
    z[2,6,4]  R1424     -0.513958215713501
    z[2,6,4]  R1425     -5.2396561950445175e-02
    z[2,6,4]  R1426     -1.1542411148548126e-01
    z[2,6,4]  R1427     -7.3523811995983124e-02
    z[2,6,4]  R1428     -1.7473040521144867e-01
    z[2,6,4]  R1429     3.3437156677246094e-01
    z[2,6,4]  R1430     -3.5563436150550842e-01
    z[2,6,4]  R1431     2.3139014840126038e-01
    z[2,6,4]  R1432     5.3134876489639282e-01
    z[2,6,4]  R1433     -3.8897490501403809e-01
    z[2,6,4]  R1434     -2.6186376810073853e-01
    z[2,6,4]  R1435     -1.6237211227416992e-01
    z[2,6,4]  R1436     -2.4907091632485390e-02
    z[2,6,4]  R1437     1.4272421598434448e-01
    z[2,6,4]  R1438     -3.6843821406364441e-02
    z[2,6,4]  R1439     -1.8145012855529785e-01
    z[2,6,4]  R1440     7.4807085096836090e-02
    z[2,6,4]  R1441     2.5480762124061584e-01
    z[2,6,4]  R1442     -3.4952532500028610e-02
    z[2,6,4]  R1443     5.3019434213638306e-02
    z[2,6,4]  R1444     5.8762248605489731e-02
    z[2,6,4]  R1445     -3.1292009353637695e-01
    z[2,6,4]  R1446     -3.2390853762626648e-01
    z[2,6,4]  R1447     1.4266617596149445e-01
    z[2,6,4]  R1448     -4.0367400646209717e-01
    z[2,6,4]  R1449     1.3523253798484802e-01
    z[2,6,4]  R1450     -8.8543213903903961e-02
    z[2,6,4]  R1451     0.548109233379364
    z[2,6,4]  R1452     -1.6275113821029663e-01
    z[2,6,4]  R1453     -5.6561392545700073e-01
    z[2,6,4]  R1454     0.707699716091156
    z[2,6,4]  R1455     -6.4364886283874512e-01
    z[2,6,4]  R1456     5.1550066471099854e-01
    z[2,6,4]  R1457     4.0481418371200562e-01
    z[2,6,4]  R1458     3.9839386940002441e-01
    z[2,6,4]  R1459     -1.6639856994152069e-01
    z[2,6,4]  R1460     9.5849029719829559e-02
    z[2,6,4]  R1461     -4.1597512364387512e-01
    z[2,6,4]  R1462     6.7030824720859528e-02
    z[2,6,4]  R1463     3.7161818146705627e-01
    z[2,6,4]  R1464     -4.6529185026884079e-02
    z[2,6,4]  R1465     1.0484294593334198e-01
    z[2,6,4]  R1466     -1.6625995934009552e-01
    z[2,6,4]  R1467     -5.6820398569107056e-01
    z[2,6,4]  R1468     1.4509199559688568e-01
    z[2,6,4]  R1469     8.3327546715736389e-02
    z[2,6,4]  R1470     -1.7739489674568176e-01
    z[2,6,4]  R1471     2.8146801516413689e-02
    z[2,6,4]  R1472     -4.1535660624504089e-01
    z[2,6,4]  R1473     -1.7123721539974213e-01
    z[2,6,4]  R1474     -2.6038581132888794e-01
    z[2,6,4]  R1475     -7.7424091100692749e-01
    z[2,6,4]  R1476     1.5645760297775269e-01
    z[2,6,4]  R1477     -1.5829947590827942e-01
    z[2,6,4]  R1478     -2.3500072956085205e-01
    z[2,6,4]  R1479     -1.0128770023584366e-01
    z[2,6,4]  R1480     1.7276737093925476e-01
    z[2,6,4]  R1481     -6.6476412117481232e-02
    z[2,6,4]  R1482     2.5431957840919495e-01
    z[2,6,4]  R1483     4.5903018116950989e-01
    z[2,6,4]  R1484     2.9766404628753662e-01
    z[2,6,4]  R1485     -7.2542661428451538e-01
    z[2,6,4]  R1486     -3.3482801914215088e-01
    z[2,6,4]  R1487     -1.7309391498565674e-01
    z[2,6,4]  R1488     -2.6661536097526550e-01
    z[2,6,4]  R1489     -4.2092934250831604e-02
    z[2,6,4]  R1490     1.3217866420745850e-02
    z[2,6,4]  R1491     1.6486215591430664e-01
    z[2,6,4]  R1492     -4.3455618619918823e-01
    z[2,6,4]  R1493     9.9729880690574646e-02
    z[2,6,4]  R1494     3.0060487985610962e-01
    z[2,6,4]  R1495     3.0572512745857239e-01
    z[2,6,4]  R1496     -1.7164923250675201e-01
    z[2,6,4]  R1497     -2.9328927397727966e-01
    z[2,6,4]  R1498     -2.0201927423477173e-01
    z[2,6,4]  R1499     2.6930558681488037e-01
    z[2,6,4]  R1500     -2.7637007832527161e-01
    z[2,6,4]  R1501     -7.8308053314685822e-02
    z[2,6,4]  R1502     -3.3211063127964735e-03
    z[2,6,4]  R1503     -5.3320741653442383e-01
    z[2,6,4]  R1504     3.1884846091270447e-01
    z[2,6,4]  R1505     4.1901889443397522e-01
    z[2,6,4]  R1506     -1.1754878610372543e-01
    z[2,6,4]  R1507     -3.0466960743069649e-02
    z[2,6,4]  R1508     -3.0039094388484955e-02
    z[2,6,4]  R1509     2.0017163455486298e-01
    z[2,6,4]  R1510     -2.5645527243614197e-01
    z[2,6,4]  R1511     1.2100024521350861e-01
    z[2,6,4]  R1512     -5.6869655847549438e-01
    z[2,6,4]  R1513     -5.0403380393981934e-01
    z[2,6,4]  R1514     3.6500537395477295e-01
    z[2,6,4]  R1515     7.4338656663894653e-01
    z[2,6,4]  R1516     9.8925612866878510e-02
    z[2,6,4]  R1517     0.0436648391187191
    z[2,6,4]  R1518     -3.2527992129325867e-01
    z[2,6,4]  R1519     1.8321208655834198e-02
    z[2,6,4]  R1520     -7.7423781156539917e-02
    z[2,6,4]  R1521     4.7782388329505920e-01
    z[2,6,4]  R1522     7.5266337394714355e-01
    z[2,6,4]  R1523     4.6986865997314453e-01
    z[2,6,4]  R1524     4.0833294391632080e-01
    z[2,6,4]  R1525     6.0647827386856079e-01
    z[2,6,4]  R1526     -0.0374169796705246
    z[2,6,5]  R25       -1
    z[2,6,5]  R61       1
    z[2,6,5]  R1383     -1
    z[2,6,5]  R1384     1
    z[2,6,5]  R1387     -0.0635211244225502
    z[2,6,5]  R1388     2.7736338973045349e-01
    z[2,6,5]  R1389     5.5521562695503235e-02
    z[2,6,5]  R1390     2.7796175330877304e-02
    z[2,6,5]  R1391     1.1223144084215164e-01
    z[2,6,5]  R1392     3.6337185651063919e-02
    z[2,6,5]  R1393     -2.2626908123493195e-01
    z[2,6,5]  R1394     1.7067806422710419e-01
    z[2,6,5]  R1395     -1.7152380198240280e-02
    z[2,6,5]  R1396     -3.4348621964454651e-01
    z[2,6,5]  R1397     -1.9725652039051056e-01
    z[2,6,5]  R1398     4.2617791891098022e-01
    z[2,6,5]  R1399     1.1352778412401676e-02
    z[2,6,5]  R1400     -2.4518366903066635e-02
    z[2,6,5]  R1401     -2.9133906960487366e-01
    z[2,6,5]  R1402     2.1445275843143463e-01
    z[2,6,5]  R1403     -4.6159449219703674e-01
    z[2,6,5]  R1404     -2.2193560004234314e-01
    z[2,6,5]  R1405     -1.8358242511749268e-01
    z[2,6,5]  R1406     -3.6293134093284607e-01
    z[2,6,5]  R1407     5.5039305239915848e-02
    z[2,6,5]  R1408     -2.3360683023929596e-01
    z[2,6,5]  R1409     -4.2297882027924061e-03
    z[2,6,5]  R1410     -0.0718153715133667
    z[2,6,5]  R1411     2.5768172740936279e-01
    z[2,6,5]  R1412     3.3670762181282043e-01
    z[2,6,5]  R1413     5.1106613874435425e-01
    z[2,6,5]  R1414     -8.0461136996746063e-02
    z[2,6,5]  R1415     4.8210576176643372e-01
    z[2,6,5]  R1416     1.6107335686683655e-01
    z[2,6,5]  R1417     8.1095799803733826e-02
    z[2,6,5]  R1418     5.4160147905349731e-01
    z[2,6,5]  R1419     5.2025479078292847e-01
    z[2,6,5]  R1420     4.8227846622467041e-01
    z[2,6,5]  R1421     7.5342416763305664e-02
    z[2,6,5]  R1422     1.1733891814947128e-01
    z[2,6,5]  R1423     6.5021711587905884e-01
    z[2,6,5]  R1424     -3.7025246769189835e-02
    z[2,6,5]  R1425     1.1696664243936539e-01
    z[2,6,5]  R1426     -3.3673125505447388e-01
    z[2,6,5]  R1427     1.8170122802257538e-01
    z[2,6,5]  R1428     3.1329768896102905e-01
    z[2,6,5]  R1429     -6.1849659681320190e-01
    z[2,6,5]  R1430     -3.5491830110549927e-01
    z[2,6,5]  R1431     -9.0146347880363464e-02
    z[2,6,5]  R1432     1.0209847241640091e-01
    z[2,6,5]  R1433     0.00407183775678277
    z[2,6,5]  R1434     1.4406004548072815e-01
    z[2,6,5]  R1435     -0.131404310464859
    z[2,6,5]  R1436     -5.6364381313323975e-01
    z[2,6,5]  R1437     -2.3281066119670868e-01
    z[2,6,5]  R1438     4.1498345136642456e-01
    z[2,6,5]  R1439     4.9292922019958496e-02
    z[2,6,5]  R1440     -2.8681412339210510e-01
    z[2,6,5]  R1441     6.9784134626388550e-01
    z[2,6,5]  R1442     -2.2815065085887909e-01
    z[2,6,5]  R1443     2.4691013619303703e-02
    z[2,6,5]  R1444     5.2079174667596817e-02
    z[2,6,5]  R1445     -1.0465037077665329e-01
    z[2,6,5]  R1446     2.4978755414485931e-01
    z[2,6,5]  R1447     2.5284758210182190e-01
    z[2,6,5]  R1448     3.1188917160034180e-01
    z[2,6,5]  R1449     1.3883448205888271e-02
    z[2,6,5]  R1450     1.3978092372417450e-01
    z[2,6,5]  R1451     -4.9397191405296326e-01
    z[2,6,5]  R1452     -1.7135277390480042e-01
    z[2,6,5]  R1453     1.8202652037143707e-01
    z[2,6,5]  R1454     1.2054627388715744e-01
    z[2,6,5]  R1455     -3.5846689343452454e-01
    z[2,6,5]  R1456     -4.3303996324539185e-01
    z[2,6,5]  R1457     4.6200446784496307e-02
    z[2,6,5]  R1458     -3.2395878434181213e-01
    z[2,6,5]  R1459     -1.9174182415008545e-01
    z[2,6,5]  R1460     1.7392399907112122e-01
    z[2,6,5]  R1461     8.3180814981460571e-02
    z[2,6,5]  R1462     -2.1449053287506104e-01
    z[2,6,5]  R1463     -0.0829191505908966
    z[2,6,5]  R1464     -1.7085450887680054e-01
    z[2,6,5]  R1465     -1.1061628162860870e-01
    z[2,6,5]  R1466     -2.7213558554649353e-01
    z[2,6,5]  R1467     3.2752615213394165e-01
    z[2,6,5]  R1468     -1.4564536511898041e-01
    z[2,6,5]  R1469     4.1196745634078979e-01
    z[2,6,5]  R1470     -1.7366786301136017e-01
    z[2,6,5]  R1471     2.5525094941258430e-02
    z[2,6,5]  R1472     6.2203764915466309e-01
    z[2,6,5]  R1473     -2.0899586379528046e-02
    z[2,6,5]  R1474     2.6637572050094604e-01
    z[2,6,5]  R1475     2.1918068826198578e-01
    z[2,6,5]  R1476     5.6586670875549316e-01
    z[2,6,5]  R1477     8.0578976869583130e-01
    z[2,6,5]  R1478     2.4711459875106812e-01
    z[2,6,5]  R1479     3.5473334789276123e-01
    z[2,6,5]  R1480     2.8026465326547623e-02
    z[2,6,5]  R1481     -3.0216455459594727e-01
    z[2,6,5]  R1482     5.7322263717651367e-01
    z[2,6,5]  R1483     -5.2819156646728516e-01
    z[2,6,5]  R1484     -5.5967479944229126e-01
    z[2,6,5]  R1485     3.3223131299018860e-01
    z[2,6,5]  R1486     -3.4338703751564026e-01
    z[2,6,5]  R1487     -5.8321750164031982e-01
    z[2,6,5]  R1488     9.8476916551589966e-02
    z[2,6,5]  R1489     5.2435958385467529e-01
    z[2,6,5]  R1490     6.7721761763095856e-02
    z[2,6,5]  R1491     -1.1546940356492996e-01
    z[2,6,5]  R1492     5.0735199451446533e-01
    z[2,6,5]  R1493     6.6885393857955933e-01
    z[2,6,5]  R1494     -4.3443045020103455e-01
    z[2,6,5]  R1495     1.5414324402809143e-01
    z[2,6,5]  R1496     -4.8195183277130127e-01
    z[2,6,5]  R1497     1.1835431680083275e-02
    z[2,6,5]  R1498     -4.5284175872802734e-01
    z[2,6,5]  R1499     -4.7734016180038452e-01
    z[2,6,5]  R1500     -2.7671229839324951e-01
    z[2,6,5]  R1501     -2.1821725368499756e-01
    z[2,6,5]  R1502     -3.1726114451885223e-02
    z[2,6,5]  R1503     -1.6012926399707794e-01
    z[2,6,5]  R1504     -1.9084455072879791e-01
    z[2,6,5]  R1505     6.0645347833633423e-01
    z[2,6,5]  R1506     3.8415738940238953e-01
    z[2,6,5]  R1507     1.4342612028121948e-01
    z[2,6,5]  R1508     2.0735330879688263e-02
    z[2,6,5]  R1509     -7.9888299107551575e-02
    z[2,6,5]  R1510     -2.3513761162757874e-01
    z[2,6,5]  R1511     5.2991282939910889e-01
    z[2,6,5]  R1512     1.6018478572368622e-01
    z[2,6,5]  R1513     3.8978680968284607e-01
    z[2,6,5]  R1514     2.6671606302261353e-01
    z[2,6,5]  R1515     -1.0598716139793396e-01
    z[2,6,5]  R1516     -3.7167635560035706e-01
    z[2,6,5]  R1517     2.3366133868694305e-01
    z[2,6,5]  R1518     4.1823066771030426e-02
    z[2,6,5]  R1519     1.7425103485584259e-01
    z[2,6,5]  R1520     0.68763667345047
    z[2,6,5]  R1521     8.5995271801948547e-02
    z[2,6,5]  R1522     -3.1345623731613159e-01
    z[2,6,5]  R1523     -1.0351142287254333e-01
    z[2,6,5]  R1524     -3.2312858104705811e-01
    z[2,6,5]  R1525     -2.4630669504404068e-02
    z[2,6,5]  R1526     -0.083391934633255
    z[2,6,6]  R26       -1
    z[2,6,6]  R62       1
    z[2,6,6]  R1385     -1
    z[2,6,6]  R1386     1
    z[2,6,6]  R1387     -1.3209688663482666e-01
    z[2,6,6]  R1388     2.9905205965042114e-01
    z[2,6,6]  R1389     1.1577330529689789e-01
    z[2,6,6]  R1390     2.0468689501285553e-01
    z[2,6,6]  R1391     -8.3370774984359741e-02
    z[2,6,6]  R1392     -1.7821887135505676e-01
    z[2,6,6]  R1393     -1.7275738716125488e-01
    z[2,6,6]  R1394     -4.0734943002462387e-02
    z[2,6,6]  R1395     -8.5410818457603455e-02
    z[2,6,6]  R1396     3.3465859293937683e-01
    z[2,6,6]  R1397     2.8603413701057434e-01
    z[2,6,6]  R1398     6.9640494883060455e-02
    z[2,6,6]  R1399     1.4773635566234589e-01
    z[2,6,6]  R1400     3.5808464884757996e-01
    z[2,6,6]  R1401     0.284882128238678
    z[2,6,6]  R1402     -0.254308819770813
    z[2,6,6]  R1403     1.0130243003368378e-01
    z[2,6,6]  R1404     -2.3207536339759827e-01
    z[2,6,6]  R1405     -1.2426828593015671e-01
    z[2,6,6]  R1406     -3.0167952179908752e-01
    z[2,6,6]  R1407     2.2877737879753113e-01
    z[2,6,6]  R1408     -8.3770573139190674e-02
    z[2,6,6]  R1409     -1.8943063914775848e-01
    z[2,6,6]  R1410     -1.9247531890869141e-01
    z[2,6,6]  R1411     -1.7640799283981323e-01
    z[2,6,6]  R1412     -2.1168164908885956e-01
    z[2,6,6]  R1413     -1.0025624185800552e-01
    z[2,6,6]  R1414     -1.1540773510932922e-01
    z[2,6,6]  R1415     -1.8831816315650940e-01
    z[2,6,6]  R1416     -4.3406596779823303e-01
    z[2,6,6]  R1417     5.3462035953998566e-02
    z[2,6,6]  R1418     -4.1332840919494629e-01
    z[2,6,6]  R1419     -2.7431643009185791e-01
    z[2,6,6]  R1420     -8.0111749470233917e-02
    z[2,6,6]  R1421     -3.6975890398025513e-01
    z[2,6,6]  R1422     -7.7255196869373322e-02
    z[2,6,6]  R1423     -5.4858896881341934e-02
    z[2,6,6]  R1424     -9.0832240879535675e-02
    z[2,6,6]  R1425     3.4952464699745178e-01
    z[2,6,6]  R1426     -2.1520432084798813e-02
    z[2,6,6]  R1427     -2.4955970048904419e-01
    z[2,6,6]  R1428     1.5067370235919952e-01
    z[2,6,6]  R1429     4.1308920830488205e-02
    z[2,6,6]  R1430     3.0079236626625061e-01
    z[2,6,6]  R1431     4.3296954035758972e-01
    z[2,6,6]  R1432     1.2698552012443542e-01
    z[2,6,6]  R1433     5.6059543043375015e-02
    z[2,6,6]  R1434     1.7663882672786713e-01
    z[2,6,6]  R1435     -4.2658916115760803e-01
    z[2,6,6]  R1436     -3.8099822402000427e-01
    z[2,6,6]  R1437     2.5672060251235962e-01
    z[2,6,6]  R1438     -0.246268168091774
    z[2,6,6]  R1439     1.4512288384139538e-02
    z[2,6,6]  R1440     9.0870611369609833e-02
    z[2,6,6]  R1441     2.9818934202194214e-01
    z[2,6,6]  R1442     -9.8133519291877747e-02
    z[2,6,6]  R1443     -2.0349709689617157e-01
    z[2,6,6]  R1444     -6.8014246225357056e-01
    z[2,6,6]  R1445     -2.3519890382885933e-02
    z[2,6,6]  R1446     0.328035831451416
    z[2,6,6]  R1447     2.5234752893447876e-01
    z[2,6,6]  R1448     -5.8398038148880005e-02
    z[2,6,6]  R1449     2.4019230902194977e-01
    z[2,6,6]  R1450     -6.7810076475143433e-01
    z[2,6,6]  R1451     -7.9585418105125427e-02
    z[2,6,6]  R1452     2.5969287753105164e-01
    z[2,6,6]  R1453     -1.3493178784847260e-01
    z[2,6,6]  R1454     1.8260501325130463e-01
    z[2,6,6]  R1455     6.5527461469173431e-02
    z[2,6,6]  R1456     -2.3894280195236206e-01
    z[2,6,6]  R1457     -3.6658096313476562e-01
    z[2,6,6]  R1458     1.7476810514926910e-01
    z[2,6,6]  R1459     2.0325586199760437e-01
    z[2,6,6]  R1460     6.5427523851394653e-01
    z[2,6,6]  R1461     6.1737453937530518e-01
    z[2,6,6]  R1462     -3.3815188799053431e-03
    z[2,6,6]  R1463     6.2483124434947968e-02
    z[2,6,6]  R1464     7.9416425433009863e-04
    z[2,6,6]  R1465     -8.6548924446105957e-02
    z[2,6,6]  R1466     2.0922663807868958e-01
    z[2,6,6]  R1467     -1.2703187763690948e-01
    z[2,6,6]  R1468     3.1705644726753235e-01
    z[2,6,6]  R1469     -3.3405613899230957e-01
    z[2,6,6]  R1470     -5.2935749292373657e-02
    z[2,6,6]  R1471     -2.4864497780799866e-01
    z[2,6,6]  R1472     -1.0304037481546402e-01
    z[2,6,6]  R1473     -0.586929202079773
    z[2,6,6]  R1474     -2.3855029046535492e-01
    z[2,6,6]  R1475     -1.2603218853473663e-01
    z[2,6,6]  R1476     3.6771920323371887e-01
    z[2,6,6]  R1477     -6.4364443533122540e-03
    z[2,6,6]  R1478     -1.0383991152048111e-01
    z[2,6,6]  R1479     4.2862436175346375e-01
    z[2,6,6]  R1480     -2.7937209606170654e-01
    z[2,6,6]  R1481     5.5898725986480713e-01
    z[2,6,6]  R1482     -9.4855777919292450e-02
    z[2,6,6]  R1483     -8.4704279899597168e-02
    z[2,6,6]  R1484     -0.243918776512146
    z[2,6,6]  R1485     -2.4282565340399742e-02
    z[2,6,6]  R1486     -1.2988287024199963e-02
    z[2,6,6]  R1487     -5.7427138090133667e-02
    z[2,6,6]  R1488     3.0082389712333679e-01
    z[2,6,6]  R1489     2.2318141162395477e-01
    z[2,6,6]  R1490     -3.6781916022300720e-01
    z[2,6,6]  R1491     3.0471837520599365e-01
    z[2,6,6]  R1492     1.0105646401643753e-01
    z[2,6,6]  R1493     1.0953678190708160e-01
    z[2,6,6]  R1494     2.3095515370368958e-01
    z[2,6,6]  R1495     3.1245455145835876e-01
    z[2,6,6]  R1496     -3.0622386932373047e-01
    z[2,6,6]  R1497     -1.3125742971897125e-01
    z[2,6,6]  R1498     -4.2128765583038330e-01
    z[2,6,6]  R1499     5.1761299371719360e-01
    z[2,6,6]  R1500     -1.3071468472480774e-01
    z[2,6,6]  R1501     -2.6159289479255676e-01
    z[2,6,6]  R1502     -3.6482807993888855e-01
    z[2,6,6]  R1503     -0.0368843711912632
    z[2,6,6]  R1504     1.3719749450683594e-01
    z[2,6,6]  R1505     -2.4601262062788010e-02
    z[2,6,6]  R1506     1.8489943444728851e-01
    z[2,6,6]  R1507     -5.3874599933624268e-01
    z[2,6,6]  R1508     2.9884710907936096e-01
    z[2,6,6]  R1509     -1.8286459147930145e-01
    z[2,6,6]  R1510     3.6133715510368347e-01
    z[2,6,6]  R1511     2.6935780048370361e-01
    z[2,6,6]  R1512     -2.9888576269149780e-01
    z[2,6,6]  R1513     9.8299145698547363e-02
    z[2,6,6]  R1514     2.4676294624805450e-01
    z[2,6,6]  R1515     2.3561794310808182e-02
    z[2,6,6]  R1516     5.3684383630752563e-02
    z[2,6,6]  R1517     0.258886456489563
    z[2,6,6]  R1518     4.2067226767539978e-01
    z[2,6,6]  R1519     -1.5836445987224579e-01
    z[2,6,6]  R1520     1.5851882100105286e-01
    z[2,6,6]  R1521     1.9886673986911774e-01
    z[2,6,6]  R1522     -2.9285359382629395e-01
    z[2,6,6]  R1523     2.5433811545372009e-01
    z[2,6,6]  R1524     8.0715097486972809e-02
    z[2,6,6]  R1525     1.7133943038061261e-03
    z[2,6,6]  R1526     -4.1331994533538818e-01
    z[6,2,0]  R20       1
    z[6,2,0]  R56       -1
    z[6,2,0]  R1527     -1
    z[6,2,0]  R1528     1
    z[6,2,0]  R1541     -5.2197545766830444e-01
    z[6,2,0]  R1542     -1.6462321579456329e-01
    z[6,2,0]  R1543     -1.6076698899269104e-01
    z[6,2,0]  R1544     -3.8243892788887024e-01
    z[6,2,0]  R1545     -1.0251833498477936e-01
    z[6,2,0]  R1546     9.1036915779113770e-01
    z[6,2,0]  R1547     8.9052850008010864e-01
    z[6,2,0]  R1548     7.8248989582061768e-01
    z[6,2,0]  R1549     6.7351412773132324e-01
    z[6,2,0]  R1550     8.4913635253906250e-01
    z[6,2,0]  R1551     -6.7606532573699951e-01
    z[6,2,0]  R1552     -2.2798025608062744e-01
    z[6,2,0]  R1553     4.7485885024070740e-01
    z[6,2,0]  R1554     -7.7141416072845459e-01
    z[6,2,0]  R1555     -3.1777629256248474e-01
    z[6,2,0]  R1556     1.9203804433345795e-01
    z[6,2,0]  R1557     0.0636850968003273
    z[6,2,0]  R1558     -1.9665436446666718e-01
    z[6,2,0]  R1559     8.7079554796218872e-03
    z[6,2,0]  R1560     -2.1306616067886353e-01
    z[6,2,0]  R1561     -5.2853122353553772e-02
    z[6,2,0]  R1562     2.9397246241569519e-01
    z[6,2,0]  R1563     0.219319149851799
    z[6,2,0]  R1564     3.9431083202362061e-01
    z[6,2,0]  R1565     -5.3770607709884644e-01
    z[6,2,0]  R1566     -0.549445629119873
    z[6,2,0]  R1567     -4.8566406965255737e-01
    z[6,2,0]  R1568     -5.0109875202178955e-01
    z[6,2,0]  R1569     4.9492076039314270e-01
    z[6,2,0]  R1570     6.7345392704010010e-01
    z[6,2,0]  R1571     -6.5735715627670288e-01
    z[6,2,0]  R1572     7.0079976320266724e-01
    z[6,2,0]  R1573     6.0476040840148926e-01
    z[6,2,0]  R1574     0.443428635597229
    z[6,2,0]  R1575     1.5491665899753571e-01
    z[6,2,0]  R1576     4.6872106194496155e-01
    z[6,2,0]  R1577     3.4745091199874878e-01
    z[6,2,0]  R1578     6.8955379724502563e-01
    z[6,2,0]  R1579     -4.6143087744712830e-01
    z[6,2,0]  R1580     5.3690975904464722e-01
    z[6,2,0]  R1581     -7.0697891712188721e-01
    z[6,2,0]  R1582     1.1184625327587128e-01
    z[6,2,0]  R1583     -5.5554300546646118e-01
    z[6,2,0]  R1584     -8.5844683647155762e-01
    z[6,2,0]  R1585     2.3760078847408295e-01
    z[6,2,0]  R1586     3.0090087652206421e-01
    z[6,2,0]  R1587     5.4956245422363281e-01
    z[6,2,0]  R1588     -1.3233710825443268e-01
    z[6,2,0]  R1589     1.7166146636009216e-01
    z[6,2,0]  R1590     4.6342480182647705e-01
    z[6,2,0]  R1591     1.8599800765514374e-02
    z[6,2,0]  R1592     0.588977038860321
    z[6,2,0]  R1593     1.8756064772605896e-01
    z[6,2,0]  R1594     8.9630484580993652e-02
    z[6,2,0]  R1595     -1.5797346830368042e-01
    z[6,2,0]  R1596     6.1854708194732666e-01
    z[6,2,0]  R1597     3.3072385191917419e-01
    z[6,2,0]  R1598     -3.1328000128269196e-02
    z[6,2,0]  R1599     7.6487630605697632e-02
    z[6,2,0]  R1600     3.5481783747673035e-01
    z[6,2,0]  R1601     -5.1282113790512085e-01
    z[6,2,0]  R1602     -7.3605132102966309e-01
    z[6,2,0]  R1603     7.8114360570907593e-02
    z[6,2,0]  R1604     4.9200615286827087e-01
    z[6,2,0]  R1605     6.2441922724246979e-02
    z[6,2,0]  R1606     8.6419032886624336e-03
    z[6,2,0]  R1607     -3.9424884319305420e-01
    z[6,2,0]  R1608     -3.1746748089790344e-01
    z[6,2,0]  R1609     -4.0277183055877686e-01
    z[6,2,0]  R1610     3.1345593929290771e-01
    z[6,2,0]  R1611     8.8604754209518433e-01
    z[6,2,0]  R1612     1.4583480358123779e-01
    z[6,2,0]  R1613     7.9103827476501465e-01
    z[6,2,0]  R1614     8.7183523178100586e-01
    z[6,2,0]  R1615     0.828798770904541
    z[6,2,0]  R1616     8.3446949720382690e-01
    z[6,2,0]  R1617     8.2140040397644043e-01
    z[6,2,0]  R1618     3.2014328241348267e-01
    z[6,2,0]  R1619     -5.8035325258970261e-02
    z[6,2,0]  R1620     7.2002267837524414e-01
    z[6,2,0]  R1621     -3.5881298780441284e-01
    z[6,2,0]  R1622     -4.7988590598106384e-01
    z[6,2,0]  R1623     -1.5419688820838928e-01
    z[6,2,0]  R1624     -7.5405031442642212e-01
    z[6,2,0]  R1625     -6.8363982439041138e-01
    z[6,2,0]  R1626     -4.0264037251472473e-01
    z[6,2,0]  R1627     -0.772131085395813
    z[6,2,0]  R1628     -7.4872213602066040e-01
    z[6,2,0]  R1629     -2.5317719578742981e-01
    z[6,2,0]  R1630     -7.6686137914657593e-01
    z[6,2,0]  R1631     4.8272699117660522e-02
    z[6,2,0]  R1632     -2.3450122773647308e-01
    z[6,2,0]  R1633     4.4383369386196136e-02
    z[6,2,0]  R1634     -1.6060508787631989e-01
    z[6,2,0]  R1635     3.9612289518117905e-02
    z[6,2,0]  R1636     -9.2905491590499878e-02
    z[6,2,0]  R1637     -7.7253989875316620e-02
    z[6,2,0]  R1638     -4.0585073828697205e-01
    z[6,2,0]  R1639     3.5294704139232635e-02
    z[6,2,0]  R1640     -1.3486324250698090e-01
    z[6,2,0]  R1641     1.8007567524909973e-01
    z[6,2,0]  R1642     1.6546323604416102e-04
    z[6,2,0]  R1643     2.5776728987693787e-01
    z[6,2,0]  R1644     -4.1691058874130249e-01
    z[6,2,0]  R1645     -2.6028215885162354e-01
    z[6,2,0]  R1646     6.9311964511871338e-01
    z[6,2,0]  R1647     -4.1471680998802185e-01
    z[6,2,0]  R1648     -5.6344783306121826e-01
    z[6,2,0]  R1649     -4.9564579129219055e-01
    z[6,2,0]  R1650     -1.3505442440509796e-01
    z[6,2,0]  R1651     -0.564138650894165
    z[6,2,0]  R1652     3.5655394196510315e-01
    z[6,2,0]  R1653     1.7037992179393768e-01
    z[6,2,0]  R1654     -1.5335051715373993e-01
    z[6,2,0]  R1655     -3.0667927861213684e-01
    z[6,2,0]  R1656     -2.1232496201992035e-01
    z[6,2,0]  R1657     8.5173296928405762e-01
    z[6,2,0]  R1658     8.8291460275650024e-01
    z[6,2,0]  R1659     0.199258491396904
    z[6,2,0]  R1660     -1.7429096996784210e-01
    z[6,2,0]  R1661     2.3610081523656845e-02
    z[6,2,0]  R1662     -3.2982969284057617e-01
    z[6,2,0]  R1663     6.9847536087036133e-01
    z[6,2,0]  R1664     -4.6365892887115479e-01
    z[6,2,0]  R1665     1.2046752125024796e-01
    z[6,2,0]  R1666     -0.527647852897644
    z[6,2,0]  R1667     2.2033995389938354e-01
    z[6,2,0]  R1668     2.4991865456104279e-01
    z[6,2,0]  R1669     -0.868701696395874
    z[6,2,0]  R1670     -2.1660651266574860e-01
    z[6,2,0]  R1671     8.6552582681179047e-02
    z[6,2,0]  R1672     -2.6703274250030518e-01
    z[6,2,0]  R1673     -4.2324659228324890e-01
    z[6,2,0]  R1674     2.0893737673759460e-01
    z[6,2,0]  R1675     2.3474301397800446e-01
    z[6,2,0]  R1676     3.7857976555824280e-01
    z[6,2,0]  R1677     -3.1002092361450195e-01
    z[6,2,0]  R1678     1.0676967352628708e-01
    z[6,2,0]  R1679     -0.282500684261322
    z[6,2,0]  R1680     1.3480694591999054e-01
    z[6,2,1]  R21       1
    z[6,2,1]  R57       -1
    z[6,2,1]  R1529     -1
    z[6,2,1]  R1530     1
    z[6,2,1]  R1541     -3.2811793684959412e-01
    z[6,2,1]  R1542     -3.2577949762344360e-01
    z[6,2,1]  R1543     -2.3336495459079742e-01
    z[6,2,1]  R1544     -5.3701114654541016e-01
    z[6,2,1]  R1545     -4.4717708230018616e-01
    z[6,2,1]  R1546     0.0356532521545887
    z[6,2,1]  R1547     -1.8908347189426422e-01
    z[6,2,1]  R1548     2.1818211302161217e-02
    z[6,2,1]  R1549     -2.2090595960617065e-01
    z[6,2,1]  R1550     -1.9661180675029755e-01
    z[6,2,1]  R1551     -1.0527092218399048e-01
    z[6,2,1]  R1552     -6.9276988506317139e-01
    z[6,2,1]  R1553     3.3125367015600204e-02
    z[6,2,1]  R1554     1.1375380307435989e-01
    z[6,2,1]  R1555     -5.4619574546813965e-01
    z[6,2,1]  R1556     2.7200818061828613e-01
    z[6,2,1]  R1557     -7.2978264093399048e-01
    z[6,2,1]  R1558     -6.5107178688049316e-01
    z[6,2,1]  R1559     -1.5670144930481911e-02
    z[6,2,1]  R1560     -6.8149912357330322e-01
    z[6,2,1]  R1561     -1.3495287299156189e-01
    z[6,2,1]  R1562     -8.0948662757873535e-01
    z[6,2,1]  R1563     -7.0741057395935059e-01
    z[6,2,1]  R1564     -8.3427554368972778e-01
    z[6,2,1]  R1565     -1.5183715522289276e-01
    z[6,2,1]  R1566     -8.6842171847820282e-02
    z[6,2,1]  R1567     -1.7410792410373688e-01
    z[6,2,1]  R1568     -2.6296639442443848e-01
    z[6,2,1]  R1569     -2.4480876326560974e-01
    z[6,2,1]  R1570     -3.5698909312486649e-02
    z[6,2,1]  R1571     -2.2902448475360870e-01
    z[6,2,1]  R1572     3.6682537198066711e-01
    z[6,2,1]  R1573     8.2808077335357666e-02
    z[6,2,1]  R1574     -1.9834369421005249e-01
    z[6,2,1]  R1575     -8.6241155862808228e-01
    z[6,2,1]  R1576     1.6020224988460541e-01
    z[6,2,1]  R1577     -0.084617480635643
    z[6,2,1]  R1578     1.7293068766593933e-01
    z[6,2,1]  R1579     1.3825920224189758e-01
    z[6,2,1]  R1580     4.1986593604087830e-01
    z[6,2,1]  R1581     -5.4223853349685669e-01
    z[6,2,1]  R1582     -7.8635834157466888e-02
    z[6,2,1]  R1583     -3.4241041541099548e-01
    z[6,2,1]  R1584     1.8217015266418457e-01
    z[6,2,1]  R1585     -8.9206188917160034e-01
    z[6,2,1]  R1586     -7.3266369104385376e-01
    z[6,2,1]  R1587     3.1029051542282104e-01
    z[6,2,1]  R1588     -7.3007690906524658e-01
    z[6,2,1]  R1589     -6.3801366090774536e-01
    z[6,2,1]  R1590     -2.4115969240665436e-01
    z[6,2,1]  R1591     -2.7241986244916916e-02
    z[6,2,1]  R1592     1.2814275920391083e-01
    z[6,2,1]  R1593     -6.4726972579956055e-01
    z[6,2,1]  R1594     -8.4598058462142944e-01
    z[6,2,1]  R1595     -6.4722114801406860e-01
    z[6,2,1]  R1596     -3.2419040799140930e-01
    z[6,2,1]  R1597     5.7426650077104568e-02
    z[6,2,1]  R1598     -4.7238388657569885e-01
    z[6,2,1]  R1599     2.6329854130744934e-01
    z[6,2,1]  R1600     8.4887528419494629e-01
    z[6,2,1]  R1601     -9.0420819818973541e-02
    z[6,2,1]  R1602     -9.8409861326217651e-02
    z[6,2,1]  R1603     -8.7990230321884155e-01
    z[6,2,1]  R1604     1.8412467092275620e-02
    z[6,2,1]  R1605     -5.4374831914901733e-01
    z[6,2,1]  R1606     2.5878661870956421e-01
    z[6,2,1]  R1607     6.9609928131103516e-01
    z[6,2,1]  R1608     7.1002978086471558e-01
    z[6,2,1]  R1609     6.3367408514022827e-01
    z[6,2,1]  R1610     8.3913958072662354e-01
    z[6,2,1]  R1611     -2.0820298790931702e-01
    z[6,2,1]  R1612     -2.4536137282848358e-01
    z[6,2,1]  R1613     -1.8139237165451050e-01
    z[6,2,1]  R1614     -6.7742630839347839e-02
    z[6,2,1]  R1615     2.2924799472093582e-02
    z[6,2,1]  R1616     -1.3303156197071075e-01
    z[6,2,1]  R1617     -1.2285141646862030e-01
    z[6,2,1]  R1618     -1.8322411179542542e-01
    z[6,2,1]  R1619     -2.3186931014060974e-01
    z[6,2,1]  R1620     -1.5166489779949188e-01
    z[6,2,1]  R1621     7.7723509073257446e-01
    z[6,2,1]  R1622     6.2624263763427734e-01
    z[6,2,1]  R1623     8.9889067411422729e-01
    z[6,2,1]  R1624     4.2762383818626404e-01
    z[6,2,1]  R1625     3.5715842247009277e-01
    z[6,2,1]  R1626     0.71956866979599
    z[6,2,1]  R1627     0.166547030210495
    z[6,2,1]  R1628     1.8764916062355042e-01
    z[6,2,1]  R1629     8.6886739730834961e-01
    z[6,2,1]  R1630     2.7385982871055603e-01
    z[6,2,1]  R1631     -9.1263711452484131e-01
    z[6,2,1]  R1632     -8.6090552806854248e-01
    z[6,2,1]  R1633     -7.9708242416381836e-01
    z[6,2,1]  R1634     -7.9676896333694458e-01
    z[6,2,1]  R1635     -8.3311569690704346e-01
    z[6,2,1]  R1636     -8.7095212936401367e-01
    z[6,2,1]  R1637     -0.763202428817749
    z[6,2,1]  R1638     -7.7917784452438354e-01
    z[6,2,1]  R1639     -0.824566125869751
    z[6,2,1]  R1640     -6.9372671842575073e-01
    z[6,2,1]  R1641     -0.659796953201294
    z[6,2,1]  R1642     -4.9183964729309082e-01
    z[6,2,1]  R1643     -5.3227448463439941e-01
    z[6,2,1]  R1644     -1.8455389142036438e-01
    z[6,2,1]  R1645     -2.4131046235561371e-01
    z[6,2,1]  R1646     -5.4709357023239136e-01
    z[6,2,1]  R1647     -5.6468397378921509e-01
    z[6,2,1]  R1648     5.1037472486495972e-01
    z[6,2,1]  R1649     -0.705713152885437
    z[6,2,1]  R1650     1.6149090230464935e-01
    z[6,2,1]  R1651     -4.5664042234420776e-01
    z[6,2,1]  R1652     -3.6807930469512939e-01
    z[6,2,1]  R1653     -2.4916736781597137e-01
    z[6,2,1]  R1654     3.8674041628837585e-01
    z[6,2,1]  R1655     0.219456747174263
    z[6,2,1]  R1656     4.7260022163391113e-01
    z[6,2,1]  R1657     -2.6977792382240295e-01
    z[6,2,1]  R1658     -1.5420758724212646e-01
    z[6,2,1]  R1659     6.4654910564422607e-01
    z[6,2,1]  R1660     4.7253987193107605e-01
    z[6,2,1]  R1661     1.4519819058477879e-02
    z[6,2,1]  R1662     -5.6691801548004150e-01
    z[6,2,1]  R1663     -4.2047610878944397e-01
    z[6,2,1]  R1664     7.2132611274719238e-01
    z[6,2,1]  R1665     -4.8361968994140625e-01
    z[6,2,1]  R1666     2.6444411277770996e-01
    z[6,2,1]  R1667     -9.6356995403766632e-02
    z[6,2,1]  R1668     -5.6525218486785889e-01
    z[6,2,1]  R1669     2.6983615756034851e-01
    z[6,2,1]  R1670     -2.4216964840888977e-01
    z[6,2,1]  R1671     -7.1035593748092651e-01
    z[6,2,1]  R1672     -6.9905835390090942e-01
    z[6,2,1]  R1673     7.4038130044937134e-01
    z[6,2,1]  R1674     -4.5106706023216248e-01
    z[6,2,1]  R1675     3.1020686030387878e-01
    z[6,2,1]  R1676     1.9607998430728912e-01
    z[6,2,1]  R1677     2.8569355607032776e-02
    z[6,2,1]  R1678     -0.0813002958893776
    z[6,2,1]  R1679     -3.0414137244224548e-01
    z[6,2,1]  R1680     1.0632056742906570e-01
    z[6,2,2]  R22       1
    z[6,2,2]  R58       -1
    z[6,2,2]  R1531     -1
    z[6,2,2]  R1532     1
    z[6,2,2]  R1541     4.9247068166732788e-01
    z[6,2,2]  R1542     0.702812671661377
    z[6,2,2]  R1543     7.4170178174972534e-01
    z[6,2,2]  R1544     9.4406723976135254e-02
    z[6,2,2]  R1545     2.1973843872547150e-01
    z[6,2,2]  R1546     1.1154337227344513e-01
    z[6,2,2]  R1547     6.8829543888568878e-02
    z[6,2,2]  R1548     2.6227712631225586e-01
    z[6,2,2]  R1549     4.1704177856445312e-01
    z[6,2,2]  R1550     0.0787450522184372
    z[6,2,2]  R1551     -2.8018802404403687e-01
    z[6,2,2]  R1552     -1.8012490868568420e-01
    z[6,2,2]  R1553     5.7031378149986267e-02
    z[6,2,2]  R1554     -3.2692289352416992e-01
    z[6,2,2]  R1555     -2.9781109094619751e-01
    z[6,2,2]  R1556     1.8366594612598419e-01
    z[6,2,2]  R1557     -0.234488382935524
    z[6,2,2]  R1558     -2.7368941903114319e-01
    z[6,2,2]  R1559     -1.5721577405929565e-01
    z[6,2,2]  R1560     -7.8069724142551422e-02
    z[6,2,2]  R1561     4.0266913175582886e-01
    z[6,2,2]  R1562     3.4896153211593628e-01
    z[6,2,2]  R1563     6.5445274114608765e-02
    z[6,2,2]  R1564     -1.3660962879657745e-01
    z[6,2,2]  R1565     -2.1415871381759644e-01
    z[6,2,2]  R1566     -2.9749071598052979e-01
    z[6,2,2]  R1567     -3.1292143464088440e-01
    z[6,2,2]  R1568     -4.0407484769821167e-01
    z[6,2,2]  R1569     -2.4016296863555908e-01
    z[6,2,2]  R1570     -1.2989491224288940e-01
    z[6,2,2]  R1571     -3.2716563344001770e-01
    z[6,2,2]  R1572     2.5489461421966553e-01
    z[6,2,2]  R1573     -5.1718336343765259e-01
    z[6,2,2]  R1574     -6.7347055673599243e-01
    z[6,2,2]  R1575     -1.0436603426933289e-01
    z[6,2,2]  R1576     -3.2193490862846375e-01
    z[6,2,2]  R1577     -0.389515221118927
    z[6,2,2]  R1578     -0.0582720972597599
    z[6,2,2]  R1579     1.8238976597785950e-01
    z[6,2,2]  R1580     1.2936817109584808e-01
    z[6,2,2]  R1581     -1.4872124791145325e-01
    z[6,2,2]  R1582     2.0290501415729523e-01
    z[6,2,2]  R1583     -7.2191491723060608e-02
    z[6,2,2]  R1584     7.4390321969985962e-02
    z[6,2,2]  R1585     -8.6434474214911461e-03
    z[6,2,2]  R1586     -2.8759497404098511e-01
    z[6,2,2]  R1587     1.6714119911193848e-01
    z[6,2,2]  R1588     -5.2721619606018066e-01
    z[6,2,2]  R1589     -1.3237448036670685e-01
    z[6,2,2]  R1590     -6.3532269001007080e-01
    z[6,2,2]  R1591     4.0951010584831238e-01
    z[6,2,2]  R1592     -3.0285583809018135e-02
    z[6,2,2]  R1593     -2.8604707121849060e-01
    z[6,2,2]  R1594     -7.4590439908206463e-03
    z[6,2,2]  R1595     -7.6503805816173553e-02
    z[6,2,2]  R1596     -2.6078349351882935e-01
    z[6,2,2]  R1597     -1.5917524695396423e-01
    z[6,2,2]  R1598     -2.2744590044021606e-01
    z[6,2,2]  R1599     2.4288256466388702e-01
    z[6,2,2]  R1600     1.7767339944839478e-02
    z[6,2,2]  R1601     7.7531868219375610e-01
    z[6,2,2]  R1602     1.4420564472675323e-01
    z[6,2,2]  R1603     -0.339753121137619
    z[6,2,2]  R1604     -6.8565420806407928e-02
    z[6,2,2]  R1605     -4.5177906751632690e-01
    z[6,2,2]  R1606     1.1948562413454056e-01
    z[6,2,2]  R1607     -2.4445956945419312e-01
    z[6,2,2]  R1608     -2.9381096363067627e-01
    z[6,2,2]  R1609     -2.6035633683204651e-01
    z[6,2,2]  R1610     -1.3560469448566437e-01
    z[6,2,2]  R1611     0.0910937711596489
    z[6,2,2]  R1612     8.6018282175064087e-01
    z[6,2,2]  R1613     4.2260631918907166e-01
    z[6,2,2]  R1614     -4.1567340493202209e-02
    z[6,2,2]  R1615     3.7105602025985718e-01
    z[6,2,2]  R1616     4.1188856959342957e-01
    z[6,2,2]  R1617     -0.0768071785569191
    z[6,2,2]  R1618     9.0562599897384644e-01
    z[6,2,2]  R1619     9.0104812383651733e-01
    z[6,2,2]  R1620     -0.0647159144282341
    z[6,2,2]  R1621     -2.9394480586051941e-01
    z[6,2,2]  R1622     -3.2875162363052368e-01
    z[6,2,2]  R1623     -3.6022484302520752e-01
    z[6,2,2]  R1624     -2.7992677688598633e-01
    z[6,2,2]  R1625     -4.0945509076118469e-01
    z[6,2,2]  R1626     -3.1449410319328308e-01
    z[6,2,2]  R1627     -2.1376132965087891e-01
    z[6,2,2]  R1628     -4.1909557580947876e-01
    z[6,2,2]  R1629     -1.9536575675010681e-01
    z[6,2,2]  R1630     -1.6567899286746979e-01
    z[6,2,2]  R1631     2.1565565839409828e-02
    z[6,2,2]  R1632     1.8663156032562256e-01
    z[6,2,2]  R1633     1.1444225907325745e-01
    z[6,2,2]  R1634     1.7330738902091980e-01
    z[6,2,2]  R1635     1.9123714417219162e-02
    z[6,2,2]  R1636     2.7071169018745422e-01
    z[6,2,2]  R1637     5.5021595209836960e-02
    z[6,2,2]  R1638     -8.9638732373714447e-02
    z[6,2,2]  R1639     -1.2983185052871704e-01
    z[6,2,2]  R1640     0.456155925989151
    z[6,2,2]  R1641     6.8963599205017090e-01
    z[6,2,2]  R1642     3.6888051033020020e-01
    z[6,2,2]  R1643     4.8535147309303284e-01
    z[6,2,2]  R1644     5.2804708480834961e-01
    z[6,2,2]  R1645     5.0944548845291138e-01
    z[6,2,2]  R1646     -3.9497545361518860e-01
    z[6,2,2]  R1647     2.5180166959762573e-01
    z[6,2,2]  R1648     -2.9711747169494629e-01
    z[6,2,2]  R1649     3.3206200599670410e-01
    z[6,2,2]  R1650     -8.2156014442443848e-01
    z[6,2,2]  R1651     5.9368723630905151e-01
    z[6,2,2]  R1652     3.6254769563674927e-01
    z[6,2,2]  R1653     0.542304515838623
    z[6,2,2]  R1654     -6.8246215581893921e-01
    z[6,2,2]  R1655     -6.6549074649810791e-01
    z[6,2,2]  R1656     -6.3054847717285156e-01
    z[6,2,2]  R1657     -2.1745751798152924e-01
    z[6,2,2]  R1658     -7.5013250112533569e-02
    z[6,2,2]  R1659     -5.2669900655746460e-01
    z[6,2,2]  R1660     -4.9416157603263855e-01
    z[6,2,2]  R1661     7.6543998718261719e-01
    z[6,2,2]  R1662     3.4518721699714661e-01
    z[6,2,2]  R1663     -5.2202981710433960e-01
    z[6,2,2]  R1664     -0.376355916261673
    z[6,2,2]  R1665     1.5767641365528107e-01
    z[6,2,2]  R1666     -7.2714775800704956e-01
    z[6,2,2]  R1667     4.8233687877655029e-01
    z[6,2,2]  R1668     3.7854695320129395e-01
    z[6,2,2]  R1669     -6.1420563608407974e-02
    z[6,2,2]  R1670     3.6835893988609314e-01
    z[6,2,2]  R1671     5.4648733139038086e-01
    z[6,2,2]  R1672     4.1992199420928955e-01
    z[6,2,2]  R1673     -0.415484219789505
    z[6,2,2]  R1674     5.0685596466064453e-01
    z[6,2,2]  R1675     4.7984153032302856e-01
    z[6,2,2]  R1676     -4.0168985724449158e-01
    z[6,2,2]  R1677     -0.302696168422699
    z[6,2,2]  R1678     -1.9866585731506348e-01
    z[6,2,2]  R1679     -5.0169765949249268e-01
    z[6,2,2]  R1680     -2.9586029052734375e-01
    z[6,2,3]  R23       1
    z[6,2,3]  R59       -1
    z[6,2,3]  R1533     -1
    z[6,2,3]  R1534     1
    z[6,2,3]  R1541     -2.7742058038711548e-01
    z[6,2,3]  R1542     -2.8037565946578979e-01
    z[6,2,3]  R1543     -5.1362150907516479e-01
    z[6,2,3]  R1544     -2.9821822047233582e-01
    z[6,2,3]  R1545     -4.2441949248313904e-01
    z[6,2,3]  R1546     3.2711493968963623e-01
    z[6,2,3]  R1547     1.3262446224689484e-01
    z[6,2,3]  R1548     5.3580540418624878e-01
    z[6,2,3]  R1549     5.4123628139495850e-01
    z[6,2,3]  R1550     2.9771557450294495e-01
    z[6,2,3]  R1551     -8.4155023097991943e-02
    z[6,2,3]  R1552     5.4116624593734741e-01
    z[6,2,3]  R1553     -6.9419378042221069e-01
    z[6,2,3]  R1554     4.6975526213645935e-01
    z[6,2,3]  R1555     6.6987228393554688e-01
    z[6,2,3]  R1556     -5.3416329622268677e-01
    z[6,2,3]  R1557     1.8474790453910828e-01
    z[6,2,3]  R1558     5.1658838987350464e-01
    z[6,2,3]  R1559     -5.5820119380950928e-01
    z[6,2,3]  R1560     6.4539723098278046e-02
    z[6,2,3]  R1561     -3.7743154168128967e-01
    z[6,2,3]  R1562     9.7281597554683685e-02
    z[6,2,3]  R1563     0.356892853975296
    z[6,2,3]  R1564     -1.4545871317386627e-01
    z[6,2,3]  R1565     4.8349192738533020e-01
    z[6,2,3]  R1566     4.4699767231941223e-01
    z[6,2,3]  R1567     3.7286359071731567e-01
    z[6,2,3]  R1568     2.3481087386608124e-01
    z[6,2,3]  R1569     -1.5259023755788803e-02
    z[6,2,3]  R1570     -5.4600322246551514e-01
    z[6,2,3]  R1571     -0.187056303024292
    z[6,2,3]  R1572     -3.7157908082008362e-01
    z[6,2,3]  R1573     1.8274098634719849e-01
    z[6,2,3]  R1574     4.1281515359878540e-01
    z[6,2,3]  R1575     -2.9662927985191345e-01
    z[6,2,3]  R1576     4.4106256961822510e-01
    z[6,2,3]  R1577     5.0108444690704346e-01
    z[6,2,3]  R1578     -3.9847409725189209e-01
    z[6,2,3]  R1579     7.2100222110748291e-01
    z[6,2,3]  R1580     -4.0396827459335327e-01
    z[6,2,3]  R1581     -2.8399446606636047e-01
    z[6,2,3]  R1582     -7.1887111663818359e-01
    z[6,2,3]  R1583     2.4760019034147263e-02
    z[6,2,3]  R1584     2.3305064439773560e-01
    z[6,2,3]  R1585     -1.5973395109176636e-01
    z[6,2,3]  R1586     3.9475908875465393e-01
    z[6,2,3]  R1587     -5.1230156421661377e-01
    z[6,2,3]  R1588     1.2086557596921921e-01
    z[6,2,3]  R1589     -4.4497188180685043e-02
    z[6,2,3]  R1590     3.5757806897163391e-01
    z[6,2,3]  R1591     -7.2074049711227417e-01
    z[6,2,3]  R1592     -7.3832678794860840e-01
    z[6,2,3]  R1593     6.1979812383651733e-01
    z[6,2,3]  R1594     1.5685656666755676e-01
    z[6,2,3]  R1595     4.2695918679237366e-01
    z[6,2,3]  R1596     7.6710104942321777e-02
    z[6,2,3]  R1597     -6.6808730363845825e-01
    z[6,2,3]  R1598     6.7740833759307861e-01
    z[6,2,3]  R1599     5.4901689291000366e-01
    z[6,2,3]  R1600     4.8863638192415237e-02
    z[6,2,3]  R1601     0.0647546723484993
    z[6,2,3]  R1602     3.7845405936241150e-01
    z[6,2,3]  R1603     2.2013500332832336e-01
    z[6,2,3]  R1604     4.9892172217369080e-01
    z[6,2,3]  R1605     4.7018688917160034e-01
    z[6,2,3]  R1606     0.410070538520813
    z[6,2,3]  R1607     -6.3829235732555389e-02
    z[6,2,3]  R1608     -1.7630833387374878e-01
    z[6,2,3]  R1609     4.5861587859690189e-03
    z[6,2,3]  R1610     -3.7304491270333529e-03
    z[6,2,3]  R1611     3.6288830637931824e-01
    z[6,2,3]  R1612     2.6031108573079109e-02
    z[6,2,3]  R1613     3.5282278060913086e-01
    z[6,2,3]  R1614     3.7063917517662048e-01
    z[6,2,3]  R1615     3.4668728709220886e-01
    z[6,2,3]  R1616     0.280091255903244
    z[6,2,3]  R1617     3.0276027321815491e-01
    z[6,2,3]  R1618     -0.0650770291686058
    z[6,2,3]  R1619     1.5361729077994823e-02
    z[6,2,3]  R1620     3.7681087851524353e-01
    z[6,2,3]  R1621     -1.1669117212295532e-01
    z[6,2,3]  R1622     -2.6099857687950134e-01
    z[6,2,3]  R1623     -1.2423708289861679e-01
    z[6,2,3]  R1624     -1.9255127012729645e-01
    z[6,2,3]  R1625     -1.3361001014709473e-01
    z[6,2,3]  R1626     -3.3215454220771790e-01
    z[6,2,3]  R1627     -1.3045512139797211e-01
    z[6,2,3]  R1628     -3.0237317085266113e-01
    z[6,2,3]  R1629     -1.8618687987327576e-01
    z[6,2,3]  R1630     -2.9385924339294434e-01
    z[6,2,3]  R1631     1.7202377319335938e-01
    z[6,2,3]  R1632     3.0013132095336914e-01
    z[6,2,3]  R1633     3.1678459048271179e-01
    z[6,2,3]  R1634     5.1525235176086426e-01
    z[6,2,3]  R1635     1.6616627573966980e-02
    z[6,2,3]  R1636     -2.5784291326999664e-02
    z[6,2,3]  R1637     2.7257108688354492e-01
    z[6,2,3]  R1638     3.2830587029457092e-01
    z[6,2,3]  R1639     1.7882893979549408e-01
    z[6,2,3]  R1640     -7.8448191285133362e-02
    z[6,2,3]  R1641     2.0064114034175873e-01
    z[6,2,3]  R1642     -1.5162938833236694e-01
    z[6,2,3]  R1643     -7.9044135054573417e-04
    z[6,2,3]  R1644     -2.9002451896667480e-01
    z[6,2,3]  R1645     -6.2565606832504272e-01
    z[6,2,3]  R1646     0.141846165060997
    z[6,2,3]  R1647     -1.3586845993995667e-01
    z[6,2,3]  R1648     -2.4493041634559631e-01
    z[6,2,3]  R1649     8.6284153163433075e-02
    z[6,2,3]  R1650     -3.9184951782226562e-01
    z[6,2,3]  R1651     -1.4163862168788910e-01
    z[6,2,3]  R1652     -6.7420870065689087e-01
    z[6,2,3]  R1653     3.4459149837493896e-01
    z[6,2,3]  R1654     -1.3506361842155457e-01
    z[6,2,3]  R1655     -4.0715873241424561e-01
    z[6,2,3]  R1656     -1.5841390192508698e-01
    z[6,2,3]  R1657     -4.7076758928596973e-03
    z[6,2,3]  R1658     -2.6557031273841858e-01
    z[6,2,3]  R1659     -1.9811186194419861e-01
    z[6,2,3]  R1660     -1.9661815464496613e-01
    z[6,2,3]  R1661     -5.2235692739486694e-01
    z[6,2,3]  R1662     -4.6523699164390564e-01
    z[6,2,3]  R1663     1.6508273780345917e-01
    z[6,2,3]  R1664     -1.6416238248348236e-01
    z[6,2,3]  R1665     -2.9310640692710876e-01
    z[6,2,3]  R1666     -2.4496681988239288e-01
    z[6,2,3]  R1667     -8.1528216600418091e-01
    z[6,2,3]  R1668     -7.7290818095207214e-02
    z[6,2,3]  R1669     -2.4361704289913177e-01
    z[6,2,3]  R1670     -6.9557827711105347e-01
    z[6,2,3]  R1671     2.0319934189319611e-01
    z[6,2,3]  R1672     -6.2119122594594955e-03
    z[6,2,3]  R1673     -1.5458916127681732e-01
    z[6,2,3]  R1674     -9.3709513545036316e-02
    z[6,2,3]  R1675     2.6010328531265259e-01
    z[6,2,3]  R1676     -7.3046904802322388e-01
    z[6,2,3]  R1677     -6.6346544027328491e-01
    z[6,2,3]  R1678     -6.2754082679748535e-01
    z[6,2,3]  R1679     -1.7004366219043732e-01
    z[6,2,3]  R1680     -0.610435426235199
    z[6,2,4]  R24       1
    z[6,2,4]  R60       -1
    z[6,2,4]  R1535     -1
    z[6,2,4]  R1536     1
    z[6,2,4]  R1541     4.0481418371200562e-01
    z[6,2,4]  R1542     3.9839386940002441e-01
    z[6,2,4]  R1543     -1.6639856994152069e-01
    z[6,2,4]  R1544     9.5849029719829559e-02
    z[6,2,4]  R1545     -4.1597512364387512e-01
    z[6,2,4]  R1546     6.7030824720859528e-02
    z[6,2,4]  R1547     3.7161818146705627e-01
    z[6,2,4]  R1548     -4.6529185026884079e-02
    z[6,2,4]  R1549     1.0484294593334198e-01
    z[6,2,4]  R1550     -1.6625995934009552e-01
    z[6,2,4]  R1551     -5.6820398569107056e-01
    z[6,2,4]  R1552     1.4509199559688568e-01
    z[6,2,4]  R1553     8.3327546715736389e-02
    z[6,2,4]  R1554     -1.7739489674568176e-01
    z[6,2,4]  R1555     2.8146801516413689e-02
    z[6,2,4]  R1556     -4.1535660624504089e-01
    z[6,2,4]  R1557     -1.7123721539974213e-01
    z[6,2,4]  R1558     -2.6038581132888794e-01
    z[6,2,4]  R1559     -7.7424091100692749e-01
    z[6,2,4]  R1560     1.5645760297775269e-01
    z[6,2,4]  R1561     -1.5829947590827942e-01
    z[6,2,4]  R1562     -2.3500072956085205e-01
    z[6,2,4]  R1563     -1.0128770023584366e-01
    z[6,2,4]  R1564     1.7276737093925476e-01
    z[6,2,4]  R1565     -6.6476412117481232e-02
    z[6,2,4]  R1566     2.5431957840919495e-01
    z[6,2,4]  R1567     4.5903018116950989e-01
    z[6,2,4]  R1568     2.9766404628753662e-01
    z[6,2,4]  R1569     -7.2542661428451538e-01
    z[6,2,4]  R1570     -3.3482801914215088e-01
    z[6,2,4]  R1571     -1.7309391498565674e-01
    z[6,2,4]  R1572     -2.6661536097526550e-01
    z[6,2,4]  R1573     -4.2092934250831604e-02
    z[6,2,4]  R1574     1.3217866420745850e-02
    z[6,2,4]  R1575     1.6486215591430664e-01
    z[6,2,4]  R1576     -4.3455618619918823e-01
    z[6,2,4]  R1577     9.9729880690574646e-02
    z[6,2,4]  R1578     3.0060487985610962e-01
    z[6,2,4]  R1579     3.0572512745857239e-01
    z[6,2,4]  R1580     -1.7164923250675201e-01
    z[6,2,4]  R1581     -2.9328927397727966e-01
    z[6,2,4]  R1582     -2.0201927423477173e-01
    z[6,2,4]  R1583     2.6930558681488037e-01
    z[6,2,4]  R1584     -2.7637007832527161e-01
    z[6,2,4]  R1585     -7.8308053314685822e-02
    z[6,2,4]  R1586     -3.3211063127964735e-03
    z[6,2,4]  R1587     -5.3320741653442383e-01
    z[6,2,4]  R1588     3.1884846091270447e-01
    z[6,2,4]  R1589     4.1901889443397522e-01
    z[6,2,4]  R1590     -1.1754878610372543e-01
    z[6,2,4]  R1591     -3.0466960743069649e-02
    z[6,2,4]  R1592     -3.0039094388484955e-02
    z[6,2,4]  R1593     2.0017163455486298e-01
    z[6,2,4]  R1594     -2.5645527243614197e-01
    z[6,2,4]  R1595     1.2100024521350861e-01
    z[6,2,4]  R1596     -5.6869655847549438e-01
    z[6,2,4]  R1597     -5.0403380393981934e-01
    z[6,2,4]  R1598     3.6500537395477295e-01
    z[6,2,4]  R1599     7.4338656663894653e-01
    z[6,2,4]  R1600     9.8925612866878510e-02
    z[6,2,4]  R1601     0.0436648391187191
    z[6,2,4]  R1602     -3.2527992129325867e-01
    z[6,2,4]  R1603     1.8321208655834198e-02
    z[6,2,4]  R1604     -7.7423781156539917e-02
    z[6,2,4]  R1605     4.7782388329505920e-01
    z[6,2,4]  R1606     7.5266337394714355e-01
    z[6,2,4]  R1607     4.6986865997314453e-01
    z[6,2,4]  R1608     4.0833294391632080e-01
    z[6,2,4]  R1609     6.0647827386856079e-01
    z[6,2,4]  R1610     -0.0374169796705246
    z[6,2,4]  R1611     -1.0050161927938461e-01
    z[6,2,4]  R1612     1.0758806765079498e-01
    z[6,2,4]  R1613     1.4761133491992950e-01
    z[6,2,4]  R1614     2.3139512538909912e-01
    z[6,2,4]  R1615     1.8747209012508392e-01
    z[6,2,4]  R1616     0.0691203773021698
    z[6,2,4]  R1617     3.6277133226394653e-01
    z[6,2,4]  R1618     -9.3559734523296356e-02
    z[6,2,4]  R1619     3.5093545913696289e-01
    z[6,2,4]  R1620     2.8707376122474670e-01
    z[6,2,4]  R1621     -2.1543622016906738e-01
    z[6,2,4]  R1622     -1.2187865376472473e-01
    z[6,2,4]  R1623     3.2665453851222992e-02
    z[6,2,4]  R1624     -6.5461009740829468e-02
    z[6,2,4]  R1625     -2.3137234151363373e-01
    z[6,2,4]  R1626     1.4333372004330158e-02
    z[6,2,4]  R1627     -3.0005258321762085e-01
    z[6,2,4]  R1628     -1.8443909287452698e-01
    z[6,2,4]  R1629     -2.4288322031497955e-01
    z[6,2,4]  R1630     -1.9801400601863861e-02
    z[6,2,4]  R1631     2.8166922926902771e-01
    z[6,2,4]  R1632     1.3172371685504913e-01
    z[6,2,4]  R1633     4.6188560128211975e-01
    z[6,2,4]  R1634     4.0505036711692810e-02
    z[6,2,4]  R1635     0.454078733921051
    z[6,2,4]  R1636     -2.6080831885337830e-02
    z[6,2,4]  R1637     2.5098109245300293e-01
    z[6,2,4]  R1638     3.0422726273536682e-01
    z[6,2,4]  R1639     4.6035513281822205e-02
    z[6,2,4]  R1640     -2.6826274394989014e-01
    z[6,2,4]  R1641     -8.3375498652458191e-02
    z[6,2,4]  R1642     -3.6722859740257263e-01
    z[6,2,4]  R1643     2.6221892237663269e-01
    z[6,2,4]  R1644     -4.3608167767524719e-01
    z[6,2,4]  R1645     -2.8397905826568604e-01
    z[6,2,4]  R1646     1.5624053776264191e-01
    z[6,2,4]  R1647     3.8545615971088409e-02
    z[6,2,4]  R1648     -0.513958215713501
    z[6,2,4]  R1649     -5.2396561950445175e-02
    z[6,2,4]  R1650     -1.1542411148548126e-01
    z[6,2,4]  R1651     -7.3523811995983124e-02
    z[6,2,4]  R1652     -1.7473040521144867e-01
    z[6,2,4]  R1653     3.3437156677246094e-01
    z[6,2,4]  R1654     -3.5563436150550842e-01
    z[6,2,4]  R1655     2.3139014840126038e-01
    z[6,2,4]  R1656     5.3134876489639282e-01
    z[6,2,4]  R1657     -3.8897490501403809e-01
    z[6,2,4]  R1658     -2.6186376810073853e-01
    z[6,2,4]  R1659     -1.6237211227416992e-01
    z[6,2,4]  R1660     -2.4907091632485390e-02
    z[6,2,4]  R1661     1.4272421598434448e-01
    z[6,2,4]  R1662     -3.6843821406364441e-02
    z[6,2,4]  R1663     -1.8145012855529785e-01
    z[6,2,4]  R1664     7.4807085096836090e-02
    z[6,2,4]  R1665     2.5480762124061584e-01
    z[6,2,4]  R1666     -3.4952532500028610e-02
    z[6,2,4]  R1667     5.3019434213638306e-02
    z[6,2,4]  R1668     5.8762248605489731e-02
    z[6,2,4]  R1669     -3.1292009353637695e-01
    z[6,2,4]  R1670     -3.2390853762626648e-01
    z[6,2,4]  R1671     1.4266617596149445e-01
    z[6,2,4]  R1672     -4.0367400646209717e-01
    z[6,2,4]  R1673     1.3523253798484802e-01
    z[6,2,4]  R1674     -8.8543213903903961e-02
    z[6,2,4]  R1675     0.548109233379364
    z[6,2,4]  R1676     -1.6275113821029663e-01
    z[6,2,4]  R1677     -5.6561392545700073e-01
    z[6,2,4]  R1678     0.707699716091156
    z[6,2,4]  R1679     -6.4364886283874512e-01
    z[6,2,4]  R1680     5.1550066471099854e-01
    z[6,2,5]  R25       1
    z[6,2,5]  R61       -1
    z[6,2,5]  R1537     -1
    z[6,2,5]  R1538     1
    z[6,2,5]  R1541     4.6200446784496307e-02
    z[6,2,5]  R1542     -3.2395878434181213e-01
    z[6,2,5]  R1543     -1.9174182415008545e-01
    z[6,2,5]  R1544     1.7392399907112122e-01
    z[6,2,5]  R1545     8.3180814981460571e-02
    z[6,2,5]  R1546     -2.1449053287506104e-01
    z[6,2,5]  R1547     -0.0829191505908966
    z[6,2,5]  R1548     -1.7085450887680054e-01
    z[6,2,5]  R1549     -1.1061628162860870e-01
    z[6,2,5]  R1550     -2.7213558554649353e-01
    z[6,2,5]  R1551     3.2752615213394165e-01
    z[6,2,5]  R1552     -1.4564536511898041e-01
    z[6,2,5]  R1553     4.1196745634078979e-01
    z[6,2,5]  R1554     -1.7366786301136017e-01
    z[6,2,5]  R1555     2.5525094941258430e-02
    z[6,2,5]  R1556     6.2203764915466309e-01
    z[6,2,5]  R1557     -2.0899586379528046e-02
    z[6,2,5]  R1558     2.6637572050094604e-01
    z[6,2,5]  R1559     2.1918068826198578e-01
    z[6,2,5]  R1560     5.6586670875549316e-01
    z[6,2,5]  R1561     8.0578976869583130e-01
    z[6,2,5]  R1562     2.4711459875106812e-01
    z[6,2,5]  R1563     3.5473334789276123e-01
    z[6,2,5]  R1564     2.8026465326547623e-02
    z[6,2,5]  R1565     -3.0216455459594727e-01
    z[6,2,5]  R1566     5.7322263717651367e-01
    z[6,2,5]  R1567     -5.2819156646728516e-01
    z[6,2,5]  R1568     -5.5967479944229126e-01
    z[6,2,5]  R1569     3.3223131299018860e-01
    z[6,2,5]  R1570     -3.4338703751564026e-01
    z[6,2,5]  R1571     -5.8321750164031982e-01
    z[6,2,5]  R1572     9.8476916551589966e-02
    z[6,2,5]  R1573     5.2435958385467529e-01
    z[6,2,5]  R1574     6.7721761763095856e-02
    z[6,2,5]  R1575     -1.1546940356492996e-01
    z[6,2,5]  R1576     5.0735199451446533e-01
    z[6,2,5]  R1577     6.6885393857955933e-01
    z[6,2,5]  R1578     -4.3443045020103455e-01
    z[6,2,5]  R1579     1.5414324402809143e-01
    z[6,2,5]  R1580     -4.8195183277130127e-01
    z[6,2,5]  R1581     1.1835431680083275e-02
    z[6,2,5]  R1582     -4.5284175872802734e-01
    z[6,2,5]  R1583     -4.7734016180038452e-01
    z[6,2,5]  R1584     -2.7671229839324951e-01
    z[6,2,5]  R1585     -2.1821725368499756e-01
    z[6,2,5]  R1586     -3.1726114451885223e-02
    z[6,2,5]  R1587     -1.6012926399707794e-01
    z[6,2,5]  R1588     -1.9084455072879791e-01
    z[6,2,5]  R1589     6.0645347833633423e-01
    z[6,2,5]  R1590     3.8415738940238953e-01
    z[6,2,5]  R1591     1.4342612028121948e-01
    z[6,2,5]  R1592     2.0735330879688263e-02
    z[6,2,5]  R1593     -7.9888299107551575e-02
    z[6,2,5]  R1594     -2.3513761162757874e-01
    z[6,2,5]  R1595     5.2991282939910889e-01
    z[6,2,5]  R1596     1.6018478572368622e-01
    z[6,2,5]  R1597     3.8978680968284607e-01
    z[6,2,5]  R1598     2.6671606302261353e-01
    z[6,2,5]  R1599     -1.0598716139793396e-01
    z[6,2,5]  R1600     -3.7167635560035706e-01
    z[6,2,5]  R1601     2.3366133868694305e-01
    z[6,2,5]  R1602     4.1823066771030426e-02
    z[6,2,5]  R1603     1.7425103485584259e-01
    z[6,2,5]  R1604     0.68763667345047
    z[6,2,5]  R1605     8.5995271801948547e-02
    z[6,2,5]  R1606     -3.1345623731613159e-01
    z[6,2,5]  R1607     -1.0351142287254333e-01
    z[6,2,5]  R1608     -3.2312858104705811e-01
    z[6,2,5]  R1609     -2.4630669504404068e-02
    z[6,2,5]  R1610     -0.083391934633255
    z[6,2,5]  R1611     -0.0635211244225502
    z[6,2,5]  R1612     2.7736338973045349e-01
    z[6,2,5]  R1613     5.5521562695503235e-02
    z[6,2,5]  R1614     2.7796175330877304e-02
    z[6,2,5]  R1615     1.1223144084215164e-01
    z[6,2,5]  R1616     3.6337185651063919e-02
    z[6,2,5]  R1617     -2.2626908123493195e-01
    z[6,2,5]  R1618     1.7067806422710419e-01
    z[6,2,5]  R1619     -1.7152380198240280e-02
    z[6,2,5]  R1620     -3.4348621964454651e-01
    z[6,2,5]  R1621     -1.9725652039051056e-01
    z[6,2,5]  R1622     4.2617791891098022e-01
    z[6,2,5]  R1623     1.1352778412401676e-02
    z[6,2,5]  R1624     -2.4518366903066635e-02
    z[6,2,5]  R1625     -2.9133906960487366e-01
    z[6,2,5]  R1626     2.1445275843143463e-01
    z[6,2,5]  R1627     -4.6159449219703674e-01
    z[6,2,5]  R1628     -2.2193560004234314e-01
    z[6,2,5]  R1629     -1.8358242511749268e-01
    z[6,2,5]  R1630     -3.6293134093284607e-01
    z[6,2,5]  R1631     5.5039305239915848e-02
    z[6,2,5]  R1632     -2.3360683023929596e-01
    z[6,2,5]  R1633     -4.2297882027924061e-03
    z[6,2,5]  R1634     -0.0718153715133667
    z[6,2,5]  R1635     2.5768172740936279e-01
    z[6,2,5]  R1636     3.3670762181282043e-01
    z[6,2,5]  R1637     5.1106613874435425e-01
    z[6,2,5]  R1638     -8.0461136996746063e-02
    z[6,2,5]  R1639     4.8210576176643372e-01
    z[6,2,5]  R1640     1.6107335686683655e-01
    z[6,2,5]  R1641     8.1095799803733826e-02
    z[6,2,5]  R1642     5.4160147905349731e-01
    z[6,2,5]  R1643     5.2025479078292847e-01
    z[6,2,5]  R1644     4.8227846622467041e-01
    z[6,2,5]  R1645     7.5342416763305664e-02
    z[6,2,5]  R1646     1.1733891814947128e-01
    z[6,2,5]  R1647     6.5021711587905884e-01
    z[6,2,5]  R1648     -3.7025246769189835e-02
    z[6,2,5]  R1649     1.1696664243936539e-01
    z[6,2,5]  R1650     -3.3673125505447388e-01
    z[6,2,5]  R1651     1.8170122802257538e-01
    z[6,2,5]  R1652     3.1329768896102905e-01
    z[6,2,5]  R1653     -6.1849659681320190e-01
    z[6,2,5]  R1654     -3.5491830110549927e-01
    z[6,2,5]  R1655     -9.0146347880363464e-02
    z[6,2,5]  R1656     1.0209847241640091e-01
    z[6,2,5]  R1657     0.00407183775678277
    z[6,2,5]  R1658     1.4406004548072815e-01
    z[6,2,5]  R1659     -0.131404310464859
    z[6,2,5]  R1660     -5.6364381313323975e-01
    z[6,2,5]  R1661     -2.3281066119670868e-01
    z[6,2,5]  R1662     4.1498345136642456e-01
    z[6,2,5]  R1663     4.9292922019958496e-02
    z[6,2,5]  R1664     -2.8681412339210510e-01
    z[6,2,5]  R1665     6.9784134626388550e-01
    z[6,2,5]  R1666     -2.2815065085887909e-01
    z[6,2,5]  R1667     2.4691013619303703e-02
    z[6,2,5]  R1668     5.2079174667596817e-02
    z[6,2,5]  R1669     -1.0465037077665329e-01
    z[6,2,5]  R1670     2.4978755414485931e-01
    z[6,2,5]  R1671     2.5284758210182190e-01
    z[6,2,5]  R1672     3.1188917160034180e-01
    z[6,2,5]  R1673     1.3883448205888271e-02
    z[6,2,5]  R1674     1.3978092372417450e-01
    z[6,2,5]  R1675     -4.9397191405296326e-01
    z[6,2,5]  R1676     -1.7135277390480042e-01
    z[6,2,5]  R1677     1.8202652037143707e-01
    z[6,2,5]  R1678     1.2054627388715744e-01
    z[6,2,5]  R1679     -3.5846689343452454e-01
    z[6,2,5]  R1680     -4.3303996324539185e-01
    z[6,2,6]  R26       1
    z[6,2,6]  R62       -1
    z[6,2,6]  R1539     -1
    z[6,2,6]  R1540     1
    z[6,2,6]  R1541     -3.6658096313476562e-01
    z[6,2,6]  R1542     1.7476810514926910e-01
    z[6,2,6]  R1543     2.0325586199760437e-01
    z[6,2,6]  R1544     6.5427523851394653e-01
    z[6,2,6]  R1545     6.1737453937530518e-01
    z[6,2,6]  R1546     -3.3815188799053431e-03
    z[6,2,6]  R1547     6.2483124434947968e-02
    z[6,2,6]  R1548     7.9416425433009863e-04
    z[6,2,6]  R1549     -8.6548924446105957e-02
    z[6,2,6]  R1550     2.0922663807868958e-01
    z[6,2,6]  R1551     -1.2703187763690948e-01
    z[6,2,6]  R1552     3.1705644726753235e-01
    z[6,2,6]  R1553     -3.3405613899230957e-01
    z[6,2,6]  R1554     -5.2935749292373657e-02
    z[6,2,6]  R1555     -2.4864497780799866e-01
    z[6,2,6]  R1556     -1.0304037481546402e-01
    z[6,2,6]  R1557     -0.586929202079773
    z[6,2,6]  R1558     -2.3855029046535492e-01
    z[6,2,6]  R1559     -1.2603218853473663e-01
    z[6,2,6]  R1560     3.6771920323371887e-01
    z[6,2,6]  R1561     -6.4364443533122540e-03
    z[6,2,6]  R1562     -1.0383991152048111e-01
    z[6,2,6]  R1563     4.2862436175346375e-01
    z[6,2,6]  R1564     -2.7937209606170654e-01
    z[6,2,6]  R1565     5.5898725986480713e-01
    z[6,2,6]  R1566     -9.4855777919292450e-02
    z[6,2,6]  R1567     -8.4704279899597168e-02
    z[6,2,6]  R1568     -0.243918776512146
    z[6,2,6]  R1569     -2.4282565340399742e-02
    z[6,2,6]  R1570     -1.2988287024199963e-02
    z[6,2,6]  R1571     -5.7427138090133667e-02
    z[6,2,6]  R1572     3.0082389712333679e-01
    z[6,2,6]  R1573     2.2318141162395477e-01
    z[6,2,6]  R1574     -3.6781916022300720e-01
    z[6,2,6]  R1575     3.0471837520599365e-01
    z[6,2,6]  R1576     1.0105646401643753e-01
    z[6,2,6]  R1577     1.0953678190708160e-01
    z[6,2,6]  R1578     2.3095515370368958e-01
    z[6,2,6]  R1579     3.1245455145835876e-01
    z[6,2,6]  R1580     -3.0622386932373047e-01
    z[6,2,6]  R1581     -1.3125742971897125e-01
    z[6,2,6]  R1582     -4.2128765583038330e-01
    z[6,2,6]  R1583     5.1761299371719360e-01
    z[6,2,6]  R1584     -1.3071468472480774e-01
    z[6,2,6]  R1585     -2.6159289479255676e-01
    z[6,2,6]  R1586     -3.6482807993888855e-01
    z[6,2,6]  R1587     -0.0368843711912632
    z[6,2,6]  R1588     1.3719749450683594e-01
    z[6,2,6]  R1589     -2.4601262062788010e-02
    z[6,2,6]  R1590     1.8489943444728851e-01
    z[6,2,6]  R1591     -5.3874599933624268e-01
    z[6,2,6]  R1592     2.9884710907936096e-01
    z[6,2,6]  R1593     -1.8286459147930145e-01
    z[6,2,6]  R1594     3.6133715510368347e-01
    z[6,2,6]  R1595     2.6935780048370361e-01
    z[6,2,6]  R1596     -2.9888576269149780e-01
    z[6,2,6]  R1597     9.8299145698547363e-02
    z[6,2,6]  R1598     2.4676294624805450e-01
    z[6,2,6]  R1599     2.3561794310808182e-02
    z[6,2,6]  R1600     5.3684383630752563e-02
    z[6,2,6]  R1601     0.258886456489563
    z[6,2,6]  R1602     4.2067226767539978e-01
    z[6,2,6]  R1603     -1.5836445987224579e-01
    z[6,2,6]  R1604     1.5851882100105286e-01
    z[6,2,6]  R1605     1.9886673986911774e-01
    z[6,2,6]  R1606     -2.9285359382629395e-01
    z[6,2,6]  R1607     2.5433811545372009e-01
    z[6,2,6]  R1608     8.0715097486972809e-02
    z[6,2,6]  R1609     1.7133943038061261e-03
    z[6,2,6]  R1610     -4.1331994533538818e-01
    z[6,2,6]  R1611     -1.3209688663482666e-01
    z[6,2,6]  R1612     2.9905205965042114e-01
    z[6,2,6]  R1613     1.1577330529689789e-01
    z[6,2,6]  R1614     2.0468689501285553e-01
    z[6,2,6]  R1615     -8.3370774984359741e-02
    z[6,2,6]  R1616     -1.7821887135505676e-01
    z[6,2,6]  R1617     -1.7275738716125488e-01
    z[6,2,6]  R1618     -4.0734943002462387e-02
    z[6,2,6]  R1619     -8.5410818457603455e-02
    z[6,2,6]  R1620     3.3465859293937683e-01
    z[6,2,6]  R1621     2.8603413701057434e-01
    z[6,2,6]  R1622     6.9640494883060455e-02
    z[6,2,6]  R1623     1.4773635566234589e-01
    z[6,2,6]  R1624     3.5808464884757996e-01
    z[6,2,6]  R1625     0.284882128238678
    z[6,2,6]  R1626     -0.254308819770813
    z[6,2,6]  R1627     1.0130243003368378e-01
    z[6,2,6]  R1628     -2.3207536339759827e-01
    z[6,2,6]  R1629     -1.2426828593015671e-01
    z[6,2,6]  R1630     -3.0167952179908752e-01
    z[6,2,6]  R1631     2.2877737879753113e-01
    z[6,2,6]  R1632     -8.3770573139190674e-02
    z[6,2,6]  R1633     -1.8943063914775848e-01
    z[6,2,6]  R1634     -1.9247531890869141e-01
    z[6,2,6]  R1635     -1.7640799283981323e-01
    z[6,2,6]  R1636     -2.1168164908885956e-01
    z[6,2,6]  R1637     -1.0025624185800552e-01
    z[6,2,6]  R1638     -1.1540773510932922e-01
    z[6,2,6]  R1639     -1.8831816315650940e-01
    z[6,2,6]  R1640     -4.3406596779823303e-01
    z[6,2,6]  R1641     5.3462035953998566e-02
    z[6,2,6]  R1642     -4.1332840919494629e-01
    z[6,2,6]  R1643     -2.7431643009185791e-01
    z[6,2,6]  R1644     -8.0111749470233917e-02
    z[6,2,6]  R1645     -3.6975890398025513e-01
    z[6,2,6]  R1646     -7.7255196869373322e-02
    z[6,2,6]  R1647     -5.4858896881341934e-02
    z[6,2,6]  R1648     -9.0832240879535675e-02
    z[6,2,6]  R1649     3.4952464699745178e-01
    z[6,2,6]  R1650     -2.1520432084798813e-02
    z[6,2,6]  R1651     -2.4955970048904419e-01
    z[6,2,6]  R1652     1.5067370235919952e-01
    z[6,2,6]  R1653     4.1308920830488205e-02
    z[6,2,6]  R1654     3.0079236626625061e-01
    z[6,2,6]  R1655     4.3296954035758972e-01
    z[6,2,6]  R1656     1.2698552012443542e-01
    z[6,2,6]  R1657     5.6059543043375015e-02
    z[6,2,6]  R1658     1.7663882672786713e-01
    z[6,2,6]  R1659     -4.2658916115760803e-01
    z[6,2,6]  R1660     -3.8099822402000427e-01
    z[6,2,6]  R1661     2.5672060251235962e-01
    z[6,2,6]  R1662     -0.246268168091774
    z[6,2,6]  R1663     1.4512288384139538e-02
    z[6,2,6]  R1664     9.0870611369609833e-02
    z[6,2,6]  R1665     2.9818934202194214e-01
    z[6,2,6]  R1666     -9.8133519291877747e-02
    z[6,2,6]  R1667     -2.0349709689617157e-01
    z[6,2,6]  R1668     -6.8014246225357056e-01
    z[6,2,6]  R1669     -2.3519890382885933e-02
    z[6,2,6]  R1670     0.328035831451416
    z[6,2,6]  R1671     2.5234752893447876e-01
    z[6,2,6]  R1672     -5.8398038148880005e-02
    z[6,2,6]  R1673     2.4019230902194977e-01
    z[6,2,6]  R1674     -6.7810076475143433e-01
    z[6,2,6]  R1675     -7.9585418105125427e-02
    z[6,2,6]  R1676     2.5969287753105164e-01
    z[6,2,6]  R1677     -1.3493178784847260e-01
    z[6,2,6]  R1678     1.8260501325130463e-01
    z[6,2,6]  R1679     6.5527461469173431e-02
    z[6,2,6]  R1680     -2.3894280195236206e-01
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R1765     -1
    z[3,4,0]  R1766     1
    z[3,4,0]  R1779     -7.3149889707565308e-01
    z[3,4,0]  R1780     -4.6494984626770020e-01
    z[3,4,0]  R1781     -5.5307424068450928e-01
    z[3,4,0]  R1782     -6.4098256826400757e-01
    z[3,4,0]  R1783     -4.6843826770782471e-01
    z[3,4,0]  R1784     6.9115829467773438e-01
    z[3,4,0]  R1785     -7.4154675006866455e-01
    z[3,4,0]  R1786     -7.4062174558639526e-01
    z[3,4,0]  R1787     -6.4864701032638550e-01
    z[3,4,0]  R1788     -4.9817335605621338e-01
    z[3,4,0]  R1789     2.0759922266006470e-01
    z[3,4,0]  R1790     7.5057804584503174e-01
    z[3,4,0]  R1791     -5.5326479673385620e-01
    z[3,4,0]  R1792     -4.6926024556159973e-01
    z[3,4,0]  R1793     3.9492759108543396e-01
    z[3,4,0]  R1794     3.6992263793945312e-01
    z[3,4,0]  R1795     2.0820197463035583e-01
    z[3,4,0]  R1796     4.7991272062063217e-02
    z[3,4,0]  R1797     1.1325430870056152e-01
    z[3,4,0]  R1798     -5.5136060714721680e-01
    z[3,4,0]  R1799     1.4380007982254028e-01
    z[3,4,0]  R1800     3.2474073767662048e-01
    z[3,4,0]  R1801     4.8364314436912537e-01
    z[3,4,0]  R1802     -1.2364013493061066e-01
    z[3,4,0]  R1803     2.0443318784236908e-01
    z[3,4,0]  R1804     2.6790171861648560e-01
    z[3,4,0]  R1805     1.7849633097648621e-01
    z[3,4,0]  R1806     -0.0982329249382019
    z[3,4,0]  R1807     1.9996878504753113e-01
    z[3,4,0]  R1808     1.4755828678607941e-01
    z[3,4,0]  R1809     1.6651113331317902e-01
    z[3,4,0]  R1810     3.1945732235908508e-01
    z[3,4,0]  R1811     1.4911076426506042e-01
    z[3,4,0]  R1812     2.7498263120651245e-01
    z[3,4,0]  R1813     3.6940187215805054e-01
    z[3,4,0]  R1814     -4.3450483679771423e-01
    z[3,4,0]  R1815     3.5477286577224731e-01
    z[3,4,0]  R1816     -2.5958001613616943e-01
    z[3,4,0]  R1817     5.5322623252868652e-01
    z[3,4,0]  R1818     -6.8578487634658813e-01
    z[3,4,0]  R1819     4.1563576459884644e-01
    z[3,4,0]  R1820     6.5622836351394653e-01
    z[3,4,0]  R1821     3.5397329926490784e-01
    z[3,4,0]  R1822     5.3247994184494019e-01
    z[3,4,0]  R1823     -1.4392016828060150e-01
    z[3,4,0]  R1824     6.9569003582000732e-01
    z[3,4,0]  R1825     1.2768420577049255e-01
    z[3,4,0]  R1826     2.3055291175842285e-01
    z[3,4,0]  R1827     0.437958300113678
    z[3,4,0]  R1828     4.4579499959945679e-01
    z[3,4,0]  R1829     6.4987319707870483e-01
    z[3,4,0]  R1830     -4.2804482579231262e-01
    z[3,4,0]  R1831     2.9841953516006470e-01
    z[3,4,0]  R1832     -7.1220767498016357e-01
    z[3,4,0]  R1833     1.4320926368236542e-01
    z[3,4,0]  R1834     5.1414996385574341e-01
    z[3,4,0]  R1835     4.6924032270908356e-02
    z[3,4,0]  R1836     7.6293818652629852e-02
    z[3,4,0]  R1837     3.7339481711387634e-01
    z[3,4,0]  R1838     -2.5049021840095520e-01
    z[3,4,0]  R1839     4.3164721131324768e-01
    z[3,4,0]  R1840     5.1107597351074219e-01
    z[3,4,0]  R1841     4.9693781137466431e-01
    z[3,4,0]  R1842     3.2298576831817627e-01
    z[3,4,0]  R1843     6.4064615964889526e-01
    z[3,4,0]  R1844     -7.0324313640594482e-01
    z[3,4,0]  R1845     1.7100089788436890e-01
    z[3,4,0]  R1846     -2.4214620888233185e-01
    z[3,4,0]  R1847     -3.0630099773406982e-01
    z[3,4,0]  R1848     -4.8566347360610962e-01
    z[3,4,0]  R1849     3.9700803160667419e-01
    z[3,4,0]  R1850     3.1685985624790192e-02
    z[3,4,0]  R1851     6.9347220659255981e-01
    z[3,4,0]  R1852     -5.7144099473953247e-01
    z[3,4,0]  R1853     5.4736936092376709e-01
    z[3,4,0]  R1854     -5.0030130147933960e-01
    z[3,4,0]  R1855     -1.4278750121593475e-01
    z[3,4,0]  R1856     -4.9214673042297363e-01
    z[3,4,0]  R1857     -3.1458348035812378e-02
    z[3,4,0]  R1858     -2.7843341231346130e-01
    z[3,4,0]  R1859     -6.0938209295272827e-01
    z[3,4,0]  R1860     3.6866092681884766e-01
    z[3,4,0]  R1861     -5.1106846332550049e-01
    z[3,4,0]  R1862     5.4783982038497925e-01
    z[3,4,0]  R1863     -4.9239164590835571e-01
    z[3,4,0]  R1864     3.8289362192153931e-01
    z[3,4,0]  R1865     -4.2543691396713257e-01
    z[3,4,0]  R1866     -1.9382968544960022e-01
    z[3,4,0]  R1867     -4.3683847784996033e-01
    z[3,4,0]  R1868     -2.7887448668479919e-01
    z[3,4,0]  R1869     2.1349316835403442e-01
    z[3,4,0]  R1870     -4.5517912507057190e-01
    z[3,4,0]  R1871     6.5998509526252747e-02
    z[3,4,0]  R1872     2.2978940978646278e-02
    z[3,4,0]  R1873     -2.9317969083786011e-01
    z[3,4,0]  R1874     -9.3563318252563477e-02
    z[3,4,0]  R1875     4.4083085656166077e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R1767     -1
    z[3,4,1]  R1768     1
    z[3,4,1]  R1779     -2.2296635806560516e-01
    z[3,4,1]  R1780     -4.3592748045921326e-01
    z[3,4,1]  R1781     -2.8077259659767151e-01
    z[3,4,1]  R1782     -3.1925195455551147e-01
    z[3,4,1]  R1783     -3.2749226689338684e-01
    z[3,4,1]  R1784     -7.6501101255416870e-02
    z[3,4,1]  R1785     -3.2344156503677368e-01
    z[3,4,1]  R1786     -0.530152440071106
    z[3,4,1]  R1787     -2.4570703506469727e-01
    z[3,4,1]  R1788     -2.5414341688156128e-01
    z[3,4,1]  R1789     7.3943096399307251e-01
    z[3,4,1]  R1790     1.1804948002099991e-01
    z[3,4,1]  R1791     7.8791356086730957e-01
    z[3,4,1]  R1792     8.4700977802276611e-01
    z[3,4,1]  R1793     4.1214641928672791e-01
    z[3,4,1]  R1794     6.3256627321243286e-01
    z[3,4,1]  R1795     2.4967686831951141e-01
    z[3,4,1]  R1796     4.2082428932189941e-01
    z[3,4,1]  R1797     2.5530877709388733e-01
    z[3,4,1]  R1798     7.4511927366256714e-01
    z[3,4,1]  R1799     -2.8681892156600952e-01
    z[3,4,1]  R1800     -1.8626321852207184e-01
    z[3,4,1]  R1801     -3.1145927309989929e-01
    z[3,4,1]  R1802     3.9020884037017822e-01
    z[3,4,1]  R1803     -3.5172438621520996e-01
    z[3,4,1]  R1804     -0.818288266658783
    z[3,4,1]  R1805     -8.1852716207504272e-01
    z[3,4,1]  R1806     -7.9543876647949219e-01
    z[3,4,1]  R1807     -0.739153265953064
    z[3,4,1]  R1808     -8.0173850059509277e-01
    z[3,4,1]  R1809     2.1644264459609985e-01
    z[3,4,1]  R1810     2.5637015700340271e-01
    z[3,4,1]  R1811     1.3758948445320129e-01
    z[3,4,1]  R1812     -2.0281149446964264e-01
    z[3,4,1]  R1813     -2.7382951974868774e-01
    z[3,4,1]  R1814     3.3426719903945923e-01
    z[3,4,1]  R1815     3.0472838878631592e-01
    z[3,4,1]  R1816     2.2483146190643311e-01
    z[3,4,1]  R1817     3.8899382948875427e-01
    z[3,4,1]  R1818     3.7241196632385254e-01
    z[3,4,1]  R1819     -0.104210764169693
    z[3,4,1]  R1820     3.5648781061172485e-01
    z[3,4,1]  R1821     -1.7990475893020630e-01
    z[3,4,1]  R1822     3.1396555900573730e-01
    z[3,4,1]  R1823     1.3082636892795563e-01
    z[3,4,1]  R1824     -1.2762185931205750e-01
    z[3,4,1]  R1825     1.8831813707947731e-02
    z[3,4,1]  R1826     6.2494814395904541e-01
    z[3,4,1]  R1827     2.4925498664379120e-01
    z[3,4,1]  R1828     3.7488889694213867e-01
    z[3,4,1]  R1829     2.4902611970901489e-01
    z[3,4,1]  R1830     3.6701738834381104e-01
    z[3,4,1]  R1831     -2.0082278177142143e-02
    z[3,4,1]  R1832     6.5392822027206421e-01
    z[3,4,1]  R1833     -1.8960449844598770e-02
    z[3,4,1]  R1834     -0.465471476316452
    z[3,4,1]  R1835     2.8015002608299255e-01
    z[3,4,1]  R1836     8.0995447933673859e-02
    z[3,4,1]  R1837     2.8088155388832092e-01
    z[3,4,1]  R1838     -2.1294054388999939e-01
    z[3,4,1]  R1839     3.1275704503059387e-01
    z[3,4,1]  R1840     -2.3235730826854706e-01
    z[3,4,1]  R1841     4.5602791011333466e-02
    z[3,4,1]  R1842     2.3990756273269653e-01
    z[3,4,1]  R1843     4.3577298521995544e-01
    z[3,4,1]  R1844     -4.4554811716079712e-01
    z[3,4,1]  R1845     0.307367742061615
    z[3,4,1]  R1846     -3.9569985866546631e-01
    z[3,4,1]  R1847     -3.2336461544036865e-01
    z[3,4,1]  R1848     -1.7215554416179657e-01
    z[3,4,1]  R1849     3.6054009199142456e-01
    z[3,4,1]  R1850     3.6119109392166138e-01
    z[3,4,1]  R1851     -2.3140546679496765e-01
    z[3,4,1]  R1852     -4.6828567981719971e-01
    z[3,4,1]  R1853     6.0571485757827759e-01
    z[3,4,1]  R1854     -2.0369865000247955e-01
    z[3,4,1]  R1855     3.2805186510086060e-01
    z[3,4,1]  R1856     -7.6862359046936035e-01
    z[3,4,1]  R1857     -2.4225763976573944e-01
    z[3,4,1]  R1858     -7.9465228319168091e-01
    z[3,4,1]  R1859     2.3313266038894653e-01
    z[3,4,1]  R1860     -1.5226179733872414e-02
    z[3,4,1]  R1861     -1.2230127304792404e-01
    z[3,4,1]  R1862     1.9350171089172363e-01
    z[3,4,1]  R1863     -4.2640250921249390e-01
    z[3,4,1]  R1864     6.2665677070617676e-01
    z[3,4,1]  R1865     -2.2087098658084869e-01
    z[3,4,1]  R1866     3.4668478369712830e-01
    z[3,4,1]  R1867     -7.0672088861465454e-01
    z[3,4,1]  R1868     -8.5525280237197876e-01
    z[3,4,1]  R1869     -3.4159576892852783e-01
    z[3,4,1]  R1870     4.4207116961479187e-01
    z[3,4,1]  R1871     -3.6425170302391052e-01
    z[3,4,1]  R1872     5.7959675788879395e-02
    z[3,4,1]  R1873     -1.8813608912751079e-03
    z[3,4,1]  R1874     5.2941292524337769e-02
    z[3,4,1]  R1875     -1.3303664326667786e-01
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R1769     -1
    z[3,4,2]  R1770     1
    z[3,4,2]  R1779     -0.495866984128952
    z[3,4,2]  R1780     -2.7213424444198608e-01
    z[3,4,2]  R1781     -4.5838269591331482e-01
    z[3,4,2]  R1782     -1.9348157942295074e-01
    z[3,4,2]  R1783     -2.4002535641193390e-01
    z[3,4,2]  R1784     4.5512345433235168e-01
    z[3,4,2]  R1785     -5.1767438650131226e-01
    z[3,4,2]  R1786     -1.0964465141296387e-01
    z[3,4,2]  R1787     -5.0401580333709717e-01
    z[3,4,2]  R1788     -5.6539905071258545e-01
    z[3,4,2]  R1789     5.5173772573471069e-01
    z[3,4,2]  R1790     5.5275803804397583e-01
    z[3,4,2]  R1791     5.4552298039197922e-02
    z[3,4,2]  R1792     1.4933989942073822e-01
    z[3,4,2]  R1793     5.3784090280532837e-01
    z[3,4,2]  R1794     0.512365460395813
    z[3,4,2]  R1795     0.704929530620575
    z[3,4,2]  R1796     5.2729690074920654e-01
    z[3,4,2]  R1797     7.4078536033630371e-01
    z[3,4,2]  R1798     -0.0430370569229126
    z[3,4,2]  R1799     4.1135424375534058e-01
    z[3,4,2]  R1800     2.5374436378479004e-01
    z[3,4,2]  R1801     2.1532240509986877e-01
    z[3,4,2]  R1802     -5.2365595102310181e-01
    z[3,4,2]  R1803     2.4641571938991547e-01
    z[3,4,2]  R1804     -2.0875306427478790e-01
    z[3,4,2]  R1805     -1.6267299652099609e-01
    z[3,4,2]  R1806     -4.1821032762527466e-01
    z[3,4,2]  R1807     -2.5715437531471252e-01
    z[3,4,2]  R1808     -1.4770062267780304e-01
    z[3,4,2]  R1809     7.1830958127975464e-01
    z[3,4,2]  R1810     4.5473849773406982e-01
    z[3,4,2]  R1811     4.6605947613716125e-01
    z[3,4,2]  R1812     3.6716330051422119e-01
    z[3,4,2]  R1813     3.0969995260238647e-01
    z[3,4,2]  R1814     -6.9029003381729126e-01
    z[3,4,2]  R1815     3.0808454751968384e-01
    z[3,4,2]  R1816     -5.3008008003234863e-01
    z[3,4,2]  R1817     4.1050696372985840e-01
    z[3,4,2]  R1818     -1.5325441956520081e-01
    z[3,4,2]  R1819     4.5818847417831421e-01
    z[3,4,2]  R1820     4.3385028839111328e-01
    z[3,4,2]  R1821     2.0720952749252319e-01
    z[3,4,2]  R1822     6.1554181575775146e-01
    z[3,4,2]  R1823     -1.8043044209480286e-01
    z[3,4,2]  R1824     5.0926405191421509e-01
    z[3,4,2]  R1825     0.601693332195282
    z[3,4,2]  R1826     3.4847456216812134e-01
    z[3,4,2]  R1827     1.5690174698829651e-01
    z[3,4,2]  R1828     2.4623838067054749e-01
    z[3,4,2]  R1829     4.4899916648864746e-01
    z[3,4,2]  R1830     -2.7870857715606689e-01
    z[3,4,2]  R1831     8.3460563421249390e-01
    z[3,4,2]  R1832     -1.3503019511699677e-01
    z[3,4,2]  R1833     0.885668933391571
    z[3,4,2]  R1834     4.7445856034755707e-02
    z[3,4,2]  R1835     7.3200774192810059e-01
    z[3,4,2]  R1836     2.9898330569267273e-01
    z[3,4,2]  R1837     4.1195716708898544e-02
    z[3,4,2]  R1838     1.0171540081501007e-01
    z[3,4,2]  R1839     0.672829806804657
    z[3,4,2]  R1840     3.6227068305015564e-01
    z[3,4,2]  R1841     3.1364640593528748e-01
    z[3,4,2]  R1842     4.2406827211380005e-01
    z[3,4,2]  R1843     4.3404987454414368e-01
    z[3,4,2]  R1844     -6.8644896149635315e-02
    z[3,4,2]  R1845     0.256710946559906
    z[3,4,2]  R1846     -1.0159547626972198e-01
    z[3,4,2]  R1847     -5.5583781003952026e-01
    z[3,4,2]  R1848     -4.9035421013832092e-01
    z[3,4,2]  R1849     6.7314106225967407e-01
    z[3,4,2]  R1850     4.7472253441810608e-01
    z[3,4,2]  R1851     1.0133743286132812e-01
    z[3,4,2]  R1852     2.0631836354732513e-01
    z[3,4,2]  R1853     5.0050681829452515e-01
    z[3,4,2]  R1854     -2.1060007810592651e-01
    z[3,4,2]  R1855     6.1223471164703369e-01
    z[3,4,2]  R1856     5.7189010083675385e-02
    z[3,4,2]  R1857     2.2347699105739594e-01
    z[3,4,2]  R1858     -1.4080753922462463e-01
    z[3,4,2]  R1859     -2.3597948253154755e-01
    z[3,4,2]  R1860     5.6909757852554321e-01
    z[3,4,2]  R1861     -4.2687880992889404e-01
    z[3,4,2]  R1862     4.4247588515281677e-01
    z[3,4,2]  R1863     -3.9816579222679138e-01
    z[3,4,2]  R1864     4.3460118770599365e-01
    z[3,4,2]  R1865     -6.5257710218429565e-01
    z[3,4,2]  R1866     -4.8077547550201416e-01
    z[3,4,2]  R1867     -1.4383430778980255e-01
    z[3,4,2]  R1868     3.4261253476142883e-01
    z[3,4,2]  R1869     -3.7890592217445374e-01
    z[3,4,2]  R1870     4.2208835482597351e-01
    z[3,4,2]  R1871     7.1080386638641357e-01
    z[3,4,2]  R1872     -3.9535153657197952e-02
    z[3,4,2]  R1873     -1.6089507937431335e-01
    z[3,4,2]  R1874     1.5210928022861481e-01
    z[3,4,2]  R1875     6.8489299155771732e-03
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R1771     -1
    z[3,4,3]  R1772     1
    z[3,4,3]  R1779     3.7420988082885742e-01
    z[3,4,3]  R1780     6.7907691001892090e-01
    z[3,4,3]  R1781     4.3427556753158569e-01
    z[3,4,3]  R1782     5.0297158956527710e-01
    z[3,4,3]  R1783     6.7577290534973145e-01
    z[3,4,3]  R1784     -2.4416683614253998e-01
    z[3,4,3]  R1785     1.3043354451656342e-01
    z[3,4,3]  R1786     2.3145893216133118e-01
    z[3,4,3]  R1787     3.4173694252967834e-01
    z[3,4,3]  R1788     3.4725794196128845e-01
    z[3,4,3]  R1789     -3.9352294057607651e-02
    z[3,4,3]  R1790     -2.0397897064685822e-01
    z[3,4,3]  R1791     1.7381841316819191e-02
    z[3,4,3]  R1792     -1.0820031911134720e-01
    z[3,4,3]  R1793     -2.0943066477775574e-01
    z[3,4,3]  R1794     -2.5197410583496094e-01
    z[3,4,3]  R1795     2.8585383668541908e-02
    z[3,4,3]  R1796     -3.0092450976371765e-01
    z[3,4,3]  R1797     -4.6742090582847595e-01
    z[3,4,3]  R1798     -3.0300248414278030e-02
    z[3,4,3]  R1799     -6.7259013652801514e-01
    z[3,4,3]  R1800     -5.8234238624572754e-01
    z[3,4,3]  R1801     -4.4266286492347717e-01
    z[3,4,3]  R1802     6.7975777387619019e-01
    z[3,4,3]  R1803     -5.2452695369720459e-01
    z[3,4,3]  R1804     -1.4348666369915009e-01
    z[3,4,3]  R1805     -8.2589067518711090e-02
    z[3,4,3]  R1806     -2.4972349405288696e-01
    z[3,4,3]  R1807     -1.6817671060562134e-01
    z[3,4,3]  R1808     -2.3673868179321289e-01
    z[3,4,3]  R1809     -6.9535695016384125e-02
    z[3,4,3]  R1810     -2.5063166022300720e-01
    z[3,4,3]  R1811     -2.6369345188140869e-01
    z[3,4,3]  R1812     -3.9013007283210754e-01
    z[3,4,3]  R1813     -3.8972941040992737e-01
    z[3,4,3]  R1814     2.8705161809921265e-01
    z[3,4,3]  R1815     7.6106287539005280e-02
    z[3,4,3]  R1816     5.8734875917434692e-01
    z[3,4,3]  R1817     4.8898744583129883e-01
    z[3,4,3]  R1818     -4.2992007732391357e-01
    z[3,4,3]  R1819     -4.4301679730415344e-01
    z[3,4,3]  R1820     -1.8483416736125946e-01
    z[3,4,3]  R1821     -0.665672242641449
    z[3,4,3]  R1822     -4.3565583229064941e-01
    z[3,4,3]  R1823     -4.9580168724060059e-01
    z[3,4,3]  R1824     1.5340850688517094e-02
    z[3,4,3]  R1825     -2.3656207323074341e-01
    z[3,4,3]  R1826     4.2897865176200867e-01
    z[3,4,3]  R1827     2.7163015678524971e-02
    z[3,4,3]  R1828     -1.9019616767764091e-02
    z[3,4,3]  R1829     -3.0038860440254211e-01
    z[3,4,3]  R1830     -0.324074387550354
    z[3,4,3]  R1831     -1.2518766522407532e-01
    z[3,4,3]  R1832     7.3851294815540314e-02
    z[3,4,3]  R1833     -2.6993727311491966e-02
    z[3,4,3]  R1834     -2.3950931429862976e-01
    z[3,4,3]  R1835     -8.0155604518949986e-04
    z[3,4,3]  R1836     -6.5887951850891113e-01
    z[3,4,3]  R1837     -2.7802556753158569e-01
    z[3,4,3]  R1838     -9.0073829889297485e-01
    z[3,4,3]  R1839     -3.9974990487098694e-01
    z[3,4,3]  R1840     -7.0483297109603882e-01
    z[3,4,3]  R1841     -0.636849045753479
    z[3,4,3]  R1842     1.4090560376644135e-01
    z[3,4,3]  R1843     4.3926298618316650e-01
    z[3,4,3]  R1844     1.7935261130332947e-01
    z[3,4,3]  R1845     -4.4287670403718948e-02
    z[3,4,3]  R1846     -1.9506633281707764e-01
    z[3,4,3]  R1847     4.2763477563858032e-01
    z[3,4,3]  R1848     2.4731636047363281e-01
    z[3,4,3]  R1849     -4.1987213492393494e-01
    z[3,4,3]  R1850     -5.4470568895339966e-01
    z[3,4,3]  R1851     -2.0091973245143890e-01
    z[3,4,3]  R1852     5.7016885280609131e-01
    z[3,4,3]  R1853     1.8288058042526245e-01
    z[3,4,3]  R1854     5.7683402299880981e-01
    z[3,4,3]  R1855     9.9328316748142242e-02
    z[3,4,3]  R1856     -2.7665802836418152e-01
    z[3,4,3]  R1857     -2.5349313020706177e-01
    z[3,4,3]  R1858     -3.3209922909736633e-01
    z[3,4,3]  R1859     -5.1900601387023926e-01
    z[3,4,3]  R1860     -3.1045249104499817e-01
    z[3,4,3]  R1861     3.1423109769821167e-01
    z[3,4,3]  R1862     2.1137748658657074e-01
    z[3,4,3]  R1863     2.8813469409942627e-01
    z[3,4,3]  R1864     4.5024354010820389e-02
    z[3,4,3]  R1865     5.6768339872360229e-01
    z[3,4,3]  R1866     5.4710513353347778e-01
    z[3,4,3]  R1867     2.6591575145721436e-01
    z[3,4,3]  R1868     -1.4462395012378693e-01
    z[3,4,3]  R1869     7.4422317743301392e-01
    z[3,4,3]  R1870     2.4902540445327759e-01
    z[3,4,3]  R1871     6.2218014150857925e-02
    z[3,4,3]  R1872     2.1696844696998596e-01
    z[3,4,3]  R1873     -6.5100783109664917e-01
    z[3,4,3]  R1874     -8.7795192003250122e-01
    z[3,4,3]  R1875     -4.7661110758781433e-01
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R1773     -1
    z[3,4,4]  R1774     1
    z[3,4,4]  R1779     -4.6652253717184067e-02
    z[3,4,4]  R1780     -2.4003187194466591e-02
    z[3,4,4]  R1781     4.5995318889617920e-01
    z[3,4,4]  R1782     2.9704380035400391e-01
    z[3,4,4]  R1783     2.0661835372447968e-01
    z[3,4,4]  R1784     -2.1915614604949951e-01
    z[3,4,4]  R1785     1.3381545245647430e-01
    z[3,4,4]  R1786     -1.3279208540916443e-01
    z[3,4,4]  R1787     -1.2246138602495193e-01
    z[3,4,4]  R1788     3.7044730782508850e-01
    z[3,4,4]  R1789     0.0644272193312645
    z[3,4,4]  R1790     1.7407299578189850e-01
    z[3,4,4]  R1791     -1.0715722292661667e-01
    z[3,4,4]  R1792     -1.4778789877891541e-01
    z[3,4,4]  R1793     -1.4112314581871033e-01
    z[3,4,4]  R1794     2.2384163737297058e-01
    z[3,4,4]  R1795     1.7793895304203033e-01
    z[3,4,4]  R1796     4.4721037149429321e-01
    z[3,4,4]  R1797     -0.0606394037604332
    z[3,4,4]  R1798     1.2662783265113831e-01
    z[3,4,4]  R1799     1.7410339415073395e-01
    z[3,4,4]  R1800     3.4294697642326355e-01
    z[3,4,4]  R1801     0.0515059269964695
    z[3,4,4]  R1802     -3.0618287622928619e-02
    z[3,4,4]  R1803     1.1818935722112656e-01
    z[3,4,4]  R1804     -2.5935724377632141e-01
    z[3,4,4]  R1805     -7.0793621242046356e-02
    z[3,4,4]  R1806     -2.3014941811561584e-01
    z[3,4,4]  R1807     -2.3294666409492493e-01
    z[3,4,4]  R1808     2.0637065172195435e-01
    z[3,4,4]  R1809     -4.1234114766120911e-01
    z[3,4,4]  R1810     4.6587803959846497e-01
    z[3,4,4]  R1811     0.31876340508461
    z[3,4,4]  R1812     -1.3341650366783142e-01
    z[3,4,4]  R1813     -4.1229271888732910e-01
    z[3,4,4]  R1814     2.4737310409545898e-01
    z[3,4,4]  R1815     0.0967501625418663
    z[3,4,4]  R1816     4.6853196620941162e-01
    z[3,4,4]  R1817     3.2393902540206909e-01
    z[3,4,4]  R1818     1.9697868824005127e-01
    z[3,4,4]  R1819     2.0611914992332458e-01
    z[3,4,4]  R1820     -2.7662146091461182e-01
    z[3,4,4]  R1821     -2.1774184703826904e-01
    z[3,4,4]  R1822     -1.7755937576293945e-01
    z[3,4,4]  R1823     -6.5851235389709473e-01
    z[3,4,4]  R1824     -6.3356764614582062e-02
    z[3,4,4]  R1825     -9.6845224499702454e-02
    z[3,4,4]  R1826     2.3995047807693481e-01
    z[3,4,4]  R1827     -1.2424138188362122e-01
    z[3,4,4]  R1828     1.5257167816162109e-01
    z[3,4,4]  R1829     -8.3643466234207153e-02
    z[3,4,4]  R1830     -1.0962177067995071e-01
    z[3,4,4]  R1831     -3.1764388084411621e-01
    z[3,4,4]  R1832     1.7952004075050354e-01
    z[3,4,4]  R1833     3.9193700999021530e-02
    z[3,4,4]  R1834     1.7649734020233154e-01
    z[3,4,4]  R1835     0.24935382604599
    z[3,4,4]  R1836     8.4604196250438690e-02
    z[3,4,4]  R1837     -2.7523839473724365e-01
    z[3,4,4]  R1838     2.5690355896949768e-01
    z[3,4,4]  R1839     1.5428103506565094e-01
    z[3,4,4]  R1840     1.6195248812437057e-02
    z[3,4,4]  R1841     8.7646394968032837e-02
    z[3,4,4]  R1842     2.2998262941837311e-01
    z[3,4,4]  R1843     -8.0991901457309723e-02
    z[3,4,4]  R1844     1.5155556797981262e-01
    z[3,4,4]  R1845     -6.2881387770175934e-02
    z[3,4,4]  R1846     -1.9795902073383331e-01
    z[3,4,4]  R1847     -2.9808852076530457e-01
    z[3,4,4]  R1848     -2.7864545583724976e-01
    z[3,4,4]  R1849     -5.4691050201654434e-02
    z[3,4,4]  R1850     -1.0489811003208160e-01
    z[3,4,4]  R1851     -2.9336953163146973e-01
    z[3,4,4]  R1852     2.2056722640991211e-01
    z[3,4,4]  R1853     9.9898435175418854e-02
    z[3,4,4]  R1854     -4.8859912157058716e-01
    z[3,4,4]  R1855     3.5315670073032379e-02
    z[3,4,4]  R1856     -2.1309521794319153e-01
    z[3,4,4]  R1857     8.6106121540069580e-01
    z[3,4,4]  R1858     3.3534392714500427e-01
    z[3,4,4]  R1859     -3.8835567235946655e-01
    z[3,4,4]  R1860     5.3314459323883057e-01
    z[3,4,4]  R1861     -2.9568953439593315e-02
    z[3,4,4]  R1862     -1.4985139667987823e-01
    z[3,4,4]  R1863     0.320017009973526
    z[3,4,4]  R1864     3.4514892101287842e-01
    z[3,4,4]  R1865     -1.2468189746141434e-01
    z[3,4,4]  R1866     3.4777253866195679e-02
    z[3,4,4]  R1867     0.360971599817276
    z[3,4,4]  R1868     -1.2381967157125473e-01
    z[3,4,4]  R1869     3.2042428851127625e-01
    z[3,4,4]  R1870     3.3340302109718323e-01
    z[3,4,4]  R1871     8.4792442619800568e-02
    z[3,4,4]  R1872     -9.2411078512668610e-02
    z[3,4,4]  R1873     3.4073132276535034e-01
    z[3,4,4]  R1874     -3.8112181425094604e-01
    z[3,4,4]  R1875     -1.6519330441951752e-01
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R1775     -1
    z[3,4,5]  R1776     1
    z[3,4,5]  R1779     -4.4074233621358871e-02
    z[3,4,5]  R1780     -1.4495445787906647e-01
    z[3,4,5]  R1781     -6.9058477878570557e-02
    z[3,4,5]  R1782     -2.8482276201248169e-01
    z[3,4,5]  R1783     1.8145045638084412e-01
    z[3,4,5]  R1784     1.5429614484310150e-01
    z[3,4,5]  R1785     -1.0010101646184921e-01
    z[3,4,5]  R1786     -1.0949768126010895e-01
    z[3,4,5]  R1787     -3.4235006570816040e-01
    z[3,4,5]  R1788     1.0637746751308441e-01
    z[3,4,5]  R1789     2.8287851810455322e-01
    z[3,4,5]  R1790     2.0069922506809235e-01
    z[3,4,5]  R1791     2.3118227720260620e-01
    z[3,4,5]  R1792     -0.075913205742836
    z[3,4,5]  R1793     0.535001814365387
    z[3,4,5]  R1794     1.0893454402685165e-01
    z[3,4,5]  R1795     2.9696938395500183e-01
    z[3,4,5]  R1796     4.0769883990287781e-01
    z[3,4,5]  R1797     -4.6716742217540741e-03
    z[3,4,5]  R1798     2.5278747081756592e-01
    z[3,4,5]  R1799     4.4447210431098938e-01
    z[3,4,5]  R1800     5.4762428998947144e-01
    z[3,4,5]  R1801     6.3761627674102783e-01
    z[3,4,5]  R1802     -2.6111018657684326e-01
    z[3,4,5]  R1803     6.4481425285339355e-01
    z[3,4,5]  R1804     -3.5370582342147827e-01
    z[3,4,5]  R1805     -4.5468306541442871e-01
    z[3,4,5]  R1806     -0.252608984708786
    z[3,4,5]  R1807     -5.0605303049087524e-01
    z[3,4,5]  R1808     -4.5991146564483643e-01
    z[3,4,5]  R1809     4.8409852385520935e-01
    z[3,4,5]  R1810     0.587566614151001
    z[3,4,5]  R1811     6.3206166028976440e-01
    z[3,4,5]  R1812     5.8540689945220947e-01
    z[3,4,5]  R1813     5.7594513893127441e-01
    z[3,4,5]  R1814     -2.8168687224388123e-01
    z[3,4,5]  R1815     5.8635663986206055e-01
    z[3,4,5]  R1816     -1.1911985278129578e-01
    z[3,4,5]  R1817     1.7296472191810608e-01
    z[3,4,5]  R1818     -2.8461429476737976e-01
    z[3,4,5]  R1819     5.6511014699935913e-01
    z[3,4,5]  R1820     2.6678198575973511e-01
    z[3,4,5]  R1821     4.8890298604965210e-01
    z[3,4,5]  R1822     -0.0569256953895092
    z[3,4,5]  R1823     -2.1289469301700592e-01
    z[3,4,5]  R1824     2.3178681731224060e-01
    z[3,4,5]  R1825     3.6339035630226135e-01
    z[3,4,5]  R1826     4.3757492303848267e-01
    z[3,4,5]  R1827     7.4298632144927979e-01
    z[3,4,5]  R1828     5.8118617534637451e-01
    z[3,4,5]  R1829     3.7851619720458984e-01
    z[3,4,5]  R1830     -2.1907933056354523e-01
    z[3,4,5]  R1831     2.9881912469863892e-01
    z[3,4,5]  R1832     1.2832273729145527e-02
    z[3,4,5]  R1833     3.4379380941390991e-01
    z[3,4,5]  R1834     5.8337718248367310e-01
    z[3,4,5]  R1835     5.1027429103851318e-01
    z[3,4,5]  R1836     4.4948694109916687e-01
    z[3,4,5]  R1837     1.1982368677854538e-01
    z[3,4,5]  R1838     -0.0586259625852108
    z[3,4,5]  R1839     6.0723256319761276e-02
    z[3,4,5]  R1840     2.1167193353176117e-01
    z[3,4,5]  R1841     5.9822231531143188e-02
    z[3,4,5]  R1842     6.9899767637252808e-01
    z[3,4,5]  R1843     1.0365897417068481e-01
    z[3,4,5]  R1844     4.8748105764389038e-01
    z[3,4,5]  R1845     8.9537531137466431e-01
    z[3,4,5]  R1846     6.8468856811523438e-01
    z[3,4,5]  R1847     -4.6031859517097473e-01
    z[3,4,5]  R1848     -5.5460166931152344e-01
    z[3,4,5]  R1849     2.7098900079727173e-01
    z[3,4,5]  R1850     5.4674917459487915e-01
    z[3,4,5]  R1851     -5.4734289646148682e-01
    z[3,4,5]  R1852     4.1980616748332977e-02
    z[3,4,5]  R1853     -1.3455897569656372e-01
    z[3,4,5]  R1854     0.287685364484787
    z[3,4,5]  R1855     6.1171799898147583e-01
    z[3,4,5]  R1856     -1.0330747067928314e-01
    z[3,4,5]  R1857     -1.2625804543495178e-01
    z[3,4,5]  R1858     -1.2806738913059235e-01
    z[3,4,5]  R1859     -2.3561830818653107e-01
    z[3,4,5]  R1860     2.7680492401123047e-01
    z[3,4,5]  R1861     -6.6292285919189453e-01
    z[3,4,5]  R1862     5.4928410053253174e-01
    z[3,4,5]  R1863     4.1932541131973267e-01
    z[3,4,5]  R1864     0.254957914352417
    z[3,4,5]  R1865     -7.9919271171092987e-02
    z[3,4,5]  R1866     -4.2730411887168884e-01
    z[3,4,5]  R1867     2.8728953003883362e-01
    z[3,4,5]  R1868     1.8982259929180145e-01
    z[3,4,5]  R1869     -1.8587963283061981e-01
    z[3,4,5]  R1870     -1.5794233977794647e-01
    z[3,4,5]  R1871     -3.5428476333618164e-01
    z[3,4,5]  R1872     0.590069055557251
    z[3,4,5]  R1873     5.8619880676269531e-01
    z[3,4,5]  R1874     -2.1884655952453613e-01
    z[3,4,5]  R1875     2.6538777351379395e-01
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R1777     -1
    z[3,4,6]  R1778     1
    z[3,4,6]  R1779     -1.5861645340919495e-01
    z[3,4,6]  R1780     1.9234988093376160e-01
    z[3,4,6]  R1781     -1.5485175885260105e-02
    z[3,4,6]  R1782     1.6566525399684906e-01
    z[3,4,6]  R1783     -2.8882148861885071e-01
    z[3,4,6]  R1784     -4.2173019051551819e-01
    z[3,4,6]  R1785     1.8046455085277557e-01
    z[3,4,6]  R1786     -2.7422466874122620e-01
    z[3,4,6]  R1787     1.2597066164016724e-01
    z[3,4,6]  R1788     -3.1372427940368652e-01
    z[3,4,6]  R1789     1.4145767688751221e-01
    z[3,4,6]  R1790     -7.0472881197929382e-02
    z[3,4,6]  R1791     6.9888085126876831e-02
    z[3,4,6]  R1792     2.7485650032758713e-02
    z[3,4,6]  R1793     1.8679074943065643e-01
    z[3,4,6]  R1794     -2.7392706274986267e-01
    z[3,4,6]  R1795     5.2603948116302490e-01
    z[3,4,6]  R1796     2.9290032386779785e-01
    z[3,4,6]  R1797     3.8864722847938538e-01
    z[3,4,6]  R1798     -2.4102360010147095e-01
    z[3,4,6]  R1799     -2.1817234158515930e-01
    z[3,4,6]  R1800     -1.9706779718399048e-01
    z[3,4,6]  R1801     -1.3251727819442749e-01
    z[3,4,6]  R1802     -1.6446286439895630e-01
    z[3,4,6]  R1803     2.6247581839561462e-01
    z[3,4,6]  R1804     4.5745734125375748e-02
    z[3,4,6]  R1805     2.3047868907451630e-01
    z[3,4,6]  R1806     -5.9881657361984253e-02
    z[3,4,6]  R1807     -9.4336703419685364e-02
    z[3,4,6]  R1808     5.8939591050148010e-02
    z[3,4,6]  R1809     -1.5689672902226448e-02
    z[3,4,6]  R1810     -1.8470782786607742e-02
    z[3,4,6]  R1811     4.1349419951438904e-01
    z[3,4,6]  R1812     4.8553115129470825e-01
    z[3,4,6]  R1813     1.9763223826885223e-01
    z[3,4,6]  R1814     5.5701290257275105e-03
    z[3,4,6]  R1815     -0.57218337059021
    z[3,4,6]  R1816     1.4964535832405090e-01
    z[3,4,6]  R1817     1.2106354348361492e-02
    z[3,4,6]  R1818     -2.5076735019683838e-01
    z[3,4,6]  R1819     2.1989084780216217e-01
    z[3,4,6]  R1820     -2.6869857311248779e-01
    z[3,4,6]  R1821     -2.6428046822547913e-01
    z[3,4,6]  R1822     1.2014728784561157e-01
    z[3,4,6]  R1823     -4.5258617401123047e-01
    z[3,4,6]  R1824     4.2708730697631836e-01
    z[3,4,6]  R1825     6.5108686685562134e-01
    z[3,4,6]  R1826     0.0421893447637558
    z[3,4,6]  R1827     -3.9146393537521362e-01
    z[3,4,6]  R1828     -4.8854342103004456e-01
    z[3,4,6]  R1829     -2.7119457721710205e-01
    z[3,4,6]  R1830     -6.6284263134002686e-01
    z[3,4,6]  R1831     9.0074427425861359e-02
    z[3,4,6]  R1832     -9.5177195966243744e-02
    z[3,4,6]  R1833     -2.7251252532005310e-01
    z[3,4,6]  R1834     -2.9646283388137817e-01
    z[3,4,6]  R1835     2.4682195484638214e-01
    z[3,4,6]  R1836     -5.0488543510437012e-01
    z[3,4,6]  R1837     -7.8267019987106323e-01
    z[3,4,6]  R1838     2.8267474845051765e-02
    z[3,4,6]  R1839     0.275452196598053
    z[3,4,6]  R1840     -1.0823348909616470e-01
    z[3,4,6]  R1841     -0.485553115606308
    z[3,4,6]  R1842     3.1136220693588257e-01
    z[3,4,6]  R1843     3.1912293285131454e-02
    z[3,4,6]  R1844     9.7209677100181580e-02
    z[3,4,6]  R1845     5.2639592438936234e-02
    z[3,4,6]  R1846     4.7794154286384583e-01
    z[3,4,6]  R1847     -9.5068022608757019e-02
    z[3,4,6]  R1848     2.1829910576343536e-01
    z[3,4,6]  R1849     8.0980263650417328e-02
    z[3,4,6]  R1850     -1.9113582372665405e-01
    z[3,4,6]  R1851     1.7105533182621002e-01
    z[3,4,6]  R1852     -1.8997816741466522e-01
    z[3,4,6]  R1853     -1.4648582041263580e-01
    z[3,4,6]  R1854     9.8100811243057251e-02
    z[3,4,6]  R1855     -3.3444008231163025e-01
    z[3,4,6]  R1856     1.7640037834644318e-01
    z[3,4,6]  R1857     2.6220846176147461e-01
    z[3,4,6]  R1858     -1.7896692454814911e-01
    z[3,4,6]  R1859     -2.0715422928333282e-01
    z[3,4,6]  R1860     -2.8764620423316956e-01
    z[3,4,6]  R1861     0.0504353865981102
    z[3,4,6]  R1862     3.1272175908088684e-01
    z[3,4,6]  R1863     2.3649330437183380e-01
    z[3,4,6]  R1864     -2.9267209768295288e-01
    z[3,4,6]  R1865     1.2861740775406361e-02
    z[3,4,6]  R1866     3.5773232579231262e-01
    z[3,4,6]  R1867     -7.4043780565261841e-02
    z[3,4,6]  R1868     -3.3289868384599686e-02
    z[3,4,6]  R1869     -5.5428370833396912e-02
    z[3,4,6]  R1870     -4.7022271156311035e-01
    z[3,4,6]  R1871     4.7025975584983826e-01
    z[3,4,6]  R1872     0.768604576587677
    z[3,4,6]  R1873     6.7947648465633392e-02
    z[3,4,6]  R1874     3.6858968436717987e-02
    z[3,4,6]  R1875     -0.680474042892456
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R1876     -1
    z[4,3,0]  R1877     1
    z[4,3,0]  R1890     2.1349316835403442e-01
    z[4,3,0]  R1891     -4.5517912507057190e-01
    z[4,3,0]  R1892     6.5998509526252747e-02
    z[4,3,0]  R1893     2.2978940978646278e-02
    z[4,3,0]  R1894     -2.9317969083786011e-01
    z[4,3,0]  R1895     -9.3563318252563477e-02
    z[4,3,0]  R1896     4.4083085656166077e-01
    z[4,3,0]  R1897     -7.3149889707565308e-01
    z[4,3,0]  R1898     -4.6494984626770020e-01
    z[4,3,0]  R1899     -5.5307424068450928e-01
    z[4,3,0]  R1900     -6.4098256826400757e-01
    z[4,3,0]  R1901     -4.6843826770782471e-01
    z[4,3,0]  R1902     6.9115829467773438e-01
    z[4,3,0]  R1903     -7.4154675006866455e-01
    z[4,3,0]  R1904     -7.4062174558639526e-01
    z[4,3,0]  R1905     -6.4864701032638550e-01
    z[4,3,0]  R1906     -4.9817335605621338e-01
    z[4,3,0]  R1907     2.0759922266006470e-01
    z[4,3,0]  R1908     7.5057804584503174e-01
    z[4,3,0]  R1909     -5.5326479673385620e-01
    z[4,3,0]  R1910     -4.6926024556159973e-01
    z[4,3,0]  R1911     3.9492759108543396e-01
    z[4,3,0]  R1912     3.6992263793945312e-01
    z[4,3,0]  R1913     2.0820197463035583e-01
    z[4,3,0]  R1914     4.7991272062063217e-02
    z[4,3,0]  R1915     1.1325430870056152e-01
    z[4,3,0]  R1916     -5.5136060714721680e-01
    z[4,3,0]  R1917     1.4380007982254028e-01
    z[4,3,0]  R1918     3.2474073767662048e-01
    z[4,3,0]  R1919     4.8364314436912537e-01
    z[4,3,0]  R1920     -1.2364013493061066e-01
    z[4,3,0]  R1921     2.0443318784236908e-01
    z[4,3,0]  R1922     2.6790171861648560e-01
    z[4,3,0]  R1923     1.7849633097648621e-01
    z[4,3,0]  R1924     -0.0982329249382019
    z[4,3,0]  R1925     1.9996878504753113e-01
    z[4,3,0]  R1926     1.4755828678607941e-01
    z[4,3,0]  R1927     1.6651113331317902e-01
    z[4,3,0]  R1928     3.1945732235908508e-01
    z[4,3,0]  R1929     1.4911076426506042e-01
    z[4,3,0]  R1930     2.7498263120651245e-01
    z[4,3,0]  R1931     3.6940187215805054e-01
    z[4,3,0]  R1932     -4.3450483679771423e-01
    z[4,3,0]  R1933     3.5477286577224731e-01
    z[4,3,0]  R1934     -2.5958001613616943e-01
    z[4,3,0]  R1935     5.5322623252868652e-01
    z[4,3,0]  R1936     -6.8578487634658813e-01
    z[4,3,0]  R1937     4.1563576459884644e-01
    z[4,3,0]  R1938     6.5622836351394653e-01
    z[4,3,0]  R1939     3.5397329926490784e-01
    z[4,3,0]  R1940     5.3247994184494019e-01
    z[4,3,0]  R1941     -1.4392016828060150e-01
    z[4,3,0]  R1942     6.9569003582000732e-01
    z[4,3,0]  R1943     1.2768420577049255e-01
    z[4,3,0]  R1944     2.3055291175842285e-01
    z[4,3,0]  R1945     0.437958300113678
    z[4,3,0]  R1946     4.4579499959945679e-01
    z[4,3,0]  R1947     6.4987319707870483e-01
    z[4,3,0]  R1948     -4.2804482579231262e-01
    z[4,3,0]  R1949     2.9841953516006470e-01
    z[4,3,0]  R1950     -7.1220767498016357e-01
    z[4,3,0]  R1951     1.4320926368236542e-01
    z[4,3,0]  R1952     5.1414996385574341e-01
    z[4,3,0]  R1953     4.6924032270908356e-02
    z[4,3,0]  R1954     7.6293818652629852e-02
    z[4,3,0]  R1955     3.7339481711387634e-01
    z[4,3,0]  R1956     -2.5049021840095520e-01
    z[4,3,0]  R1957     4.3164721131324768e-01
    z[4,3,0]  R1958     5.1107597351074219e-01
    z[4,3,0]  R1959     4.9693781137466431e-01
    z[4,3,0]  R1960     3.2298576831817627e-01
    z[4,3,0]  R1961     6.4064615964889526e-01
    z[4,3,0]  R1962     -7.0324313640594482e-01
    z[4,3,0]  R1963     1.7100089788436890e-01
    z[4,3,0]  R1964     -2.4214620888233185e-01
    z[4,3,0]  R1965     -3.0630099773406982e-01
    z[4,3,0]  R1966     -4.8566347360610962e-01
    z[4,3,0]  R1967     3.9700803160667419e-01
    z[4,3,0]  R1968     3.1685985624790192e-02
    z[4,3,0]  R1969     6.9347220659255981e-01
    z[4,3,0]  R1970     -5.7144099473953247e-01
    z[4,3,0]  R1971     5.4736936092376709e-01
    z[4,3,0]  R1972     -5.0030130147933960e-01
    z[4,3,0]  R1973     -1.4278750121593475e-01
    z[4,3,0]  R1974     -4.9214673042297363e-01
    z[4,3,0]  R1975     -3.1458348035812378e-02
    z[4,3,0]  R1976     -2.7843341231346130e-01
    z[4,3,0]  R1977     -6.0938209295272827e-01
    z[4,3,0]  R1978     3.6866092681884766e-01
    z[4,3,0]  R1979     -5.1106846332550049e-01
    z[4,3,0]  R1980     5.4783982038497925e-01
    z[4,3,0]  R1981     -4.9239164590835571e-01
    z[4,3,0]  R1982     3.8289362192153931e-01
    z[4,3,0]  R1983     -4.2543691396713257e-01
    z[4,3,0]  R1984     -1.9382968544960022e-01
    z[4,3,0]  R1985     -4.3683847784996033e-01
    z[4,3,0]  R1986     -2.7887448668479919e-01
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R1878     -1
    z[4,3,1]  R1879     1
    z[4,3,1]  R1890     -3.4159576892852783e-01
    z[4,3,1]  R1891     4.4207116961479187e-01
    z[4,3,1]  R1892     -3.6425170302391052e-01
    z[4,3,1]  R1893     5.7959675788879395e-02
    z[4,3,1]  R1894     -1.8813608912751079e-03
    z[4,3,1]  R1895     5.2941292524337769e-02
    z[4,3,1]  R1896     -1.3303664326667786e-01
    z[4,3,1]  R1897     -2.2296635806560516e-01
    z[4,3,1]  R1898     -4.3592748045921326e-01
    z[4,3,1]  R1899     -2.8077259659767151e-01
    z[4,3,1]  R1900     -3.1925195455551147e-01
    z[4,3,1]  R1901     -3.2749226689338684e-01
    z[4,3,1]  R1902     -7.6501101255416870e-02
    z[4,3,1]  R1903     -3.2344156503677368e-01
    z[4,3,1]  R1904     -0.530152440071106
    z[4,3,1]  R1905     -2.4570703506469727e-01
    z[4,3,1]  R1906     -2.5414341688156128e-01
    z[4,3,1]  R1907     7.3943096399307251e-01
    z[4,3,1]  R1908     1.1804948002099991e-01
    z[4,3,1]  R1909     7.8791356086730957e-01
    z[4,3,1]  R1910     8.4700977802276611e-01
    z[4,3,1]  R1911     4.1214641928672791e-01
    z[4,3,1]  R1912     6.3256627321243286e-01
    z[4,3,1]  R1913     2.4967686831951141e-01
    z[4,3,1]  R1914     4.2082428932189941e-01
    z[4,3,1]  R1915     2.5530877709388733e-01
    z[4,3,1]  R1916     7.4511927366256714e-01
    z[4,3,1]  R1917     -2.8681892156600952e-01
    z[4,3,1]  R1918     -1.8626321852207184e-01
    z[4,3,1]  R1919     -3.1145927309989929e-01
    z[4,3,1]  R1920     3.9020884037017822e-01
    z[4,3,1]  R1921     -3.5172438621520996e-01
    z[4,3,1]  R1922     -0.818288266658783
    z[4,3,1]  R1923     -8.1852716207504272e-01
    z[4,3,1]  R1924     -7.9543876647949219e-01
    z[4,3,1]  R1925     -0.739153265953064
    z[4,3,1]  R1926     -8.0173850059509277e-01
    z[4,3,1]  R1927     2.1644264459609985e-01
    z[4,3,1]  R1928     2.5637015700340271e-01
    z[4,3,1]  R1929     1.3758948445320129e-01
    z[4,3,1]  R1930     -2.0281149446964264e-01
    z[4,3,1]  R1931     -2.7382951974868774e-01
    z[4,3,1]  R1932     3.3426719903945923e-01
    z[4,3,1]  R1933     3.0472838878631592e-01
    z[4,3,1]  R1934     2.2483146190643311e-01
    z[4,3,1]  R1935     3.8899382948875427e-01
    z[4,3,1]  R1936     3.7241196632385254e-01
    z[4,3,1]  R1937     -0.104210764169693
    z[4,3,1]  R1938     3.5648781061172485e-01
    z[4,3,1]  R1939     -1.7990475893020630e-01
    z[4,3,1]  R1940     3.1396555900573730e-01
    z[4,3,1]  R1941     1.3082636892795563e-01
    z[4,3,1]  R1942     -1.2762185931205750e-01
    z[4,3,1]  R1943     1.8831813707947731e-02
    z[4,3,1]  R1944     6.2494814395904541e-01
    z[4,3,1]  R1945     2.4925498664379120e-01
    z[4,3,1]  R1946     3.7488889694213867e-01
    z[4,3,1]  R1947     2.4902611970901489e-01
    z[4,3,1]  R1948     3.6701738834381104e-01
    z[4,3,1]  R1949     -2.0082278177142143e-02
    z[4,3,1]  R1950     6.5392822027206421e-01
    z[4,3,1]  R1951     -1.8960449844598770e-02
    z[4,3,1]  R1952     -0.465471476316452
    z[4,3,1]  R1953     2.8015002608299255e-01
    z[4,3,1]  R1954     8.0995447933673859e-02
    z[4,3,1]  R1955     2.8088155388832092e-01
    z[4,3,1]  R1956     -2.1294054388999939e-01
    z[4,3,1]  R1957     3.1275704503059387e-01
    z[4,3,1]  R1958     -2.3235730826854706e-01
    z[4,3,1]  R1959     4.5602791011333466e-02
    z[4,3,1]  R1960     2.3990756273269653e-01
    z[4,3,1]  R1961     4.3577298521995544e-01
    z[4,3,1]  R1962     -4.4554811716079712e-01
    z[4,3,1]  R1963     0.307367742061615
    z[4,3,1]  R1964     -3.9569985866546631e-01
    z[4,3,1]  R1965     -3.2336461544036865e-01
    z[4,3,1]  R1966     -1.7215554416179657e-01
    z[4,3,1]  R1967     3.6054009199142456e-01
    z[4,3,1]  R1968     3.6119109392166138e-01
    z[4,3,1]  R1969     -2.3140546679496765e-01
    z[4,3,1]  R1970     -4.6828567981719971e-01
    z[4,3,1]  R1971     6.0571485757827759e-01
    z[4,3,1]  R1972     -2.0369865000247955e-01
    z[4,3,1]  R1973     3.2805186510086060e-01
    z[4,3,1]  R1974     -7.6862359046936035e-01
    z[4,3,1]  R1975     -2.4225763976573944e-01
    z[4,3,1]  R1976     -7.9465228319168091e-01
    z[4,3,1]  R1977     2.3313266038894653e-01
    z[4,3,1]  R1978     -1.5226179733872414e-02
    z[4,3,1]  R1979     -1.2230127304792404e-01
    z[4,3,1]  R1980     1.9350171089172363e-01
    z[4,3,1]  R1981     -4.2640250921249390e-01
    z[4,3,1]  R1982     6.2665677070617676e-01
    z[4,3,1]  R1983     -2.2087098658084869e-01
    z[4,3,1]  R1984     3.4668478369712830e-01
    z[4,3,1]  R1985     -7.0672088861465454e-01
    z[4,3,1]  R1986     -8.5525280237197876e-01
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R1880     -1
    z[4,3,2]  R1881     1
    z[4,3,2]  R1890     -3.7890592217445374e-01
    z[4,3,2]  R1891     4.2208835482597351e-01
    z[4,3,2]  R1892     7.1080386638641357e-01
    z[4,3,2]  R1893     -3.9535153657197952e-02
    z[4,3,2]  R1894     -1.6089507937431335e-01
    z[4,3,2]  R1895     1.5210928022861481e-01
    z[4,3,2]  R1896     6.8489299155771732e-03
    z[4,3,2]  R1897     -0.495866984128952
    z[4,3,2]  R1898     -2.7213424444198608e-01
    z[4,3,2]  R1899     -4.5838269591331482e-01
    z[4,3,2]  R1900     -1.9348157942295074e-01
    z[4,3,2]  R1901     -2.4002535641193390e-01
    z[4,3,2]  R1902     4.5512345433235168e-01
    z[4,3,2]  R1903     -5.1767438650131226e-01
    z[4,3,2]  R1904     -1.0964465141296387e-01
    z[4,3,2]  R1905     -5.0401580333709717e-01
    z[4,3,2]  R1906     -5.6539905071258545e-01
    z[4,3,2]  R1907     5.5173772573471069e-01
    z[4,3,2]  R1908     5.5275803804397583e-01
    z[4,3,2]  R1909     5.4552298039197922e-02
    z[4,3,2]  R1910     1.4933989942073822e-01
    z[4,3,2]  R1911     5.3784090280532837e-01
    z[4,3,2]  R1912     0.512365460395813
    z[4,3,2]  R1913     0.704929530620575
    z[4,3,2]  R1914     5.2729690074920654e-01
    z[4,3,2]  R1915     7.4078536033630371e-01
    z[4,3,2]  R1916     -0.0430370569229126
    z[4,3,2]  R1917     4.1135424375534058e-01
    z[4,3,2]  R1918     2.5374436378479004e-01
    z[4,3,2]  R1919     2.1532240509986877e-01
    z[4,3,2]  R1920     -5.2365595102310181e-01
    z[4,3,2]  R1921     2.4641571938991547e-01
    z[4,3,2]  R1922     -2.0875306427478790e-01
    z[4,3,2]  R1923     -1.6267299652099609e-01
    z[4,3,2]  R1924     -4.1821032762527466e-01
    z[4,3,2]  R1925     -2.5715437531471252e-01
    z[4,3,2]  R1926     -1.4770062267780304e-01
    z[4,3,2]  R1927     7.1830958127975464e-01
    z[4,3,2]  R1928     4.5473849773406982e-01
    z[4,3,2]  R1929     4.6605947613716125e-01
    z[4,3,2]  R1930     3.6716330051422119e-01
    z[4,3,2]  R1931     3.0969995260238647e-01
    z[4,3,2]  R1932     -6.9029003381729126e-01
    z[4,3,2]  R1933     3.0808454751968384e-01
    z[4,3,2]  R1934     -5.3008008003234863e-01
    z[4,3,2]  R1935     4.1050696372985840e-01
    z[4,3,2]  R1936     -1.5325441956520081e-01
    z[4,3,2]  R1937     4.5818847417831421e-01
    z[4,3,2]  R1938     4.3385028839111328e-01
    z[4,3,2]  R1939     2.0720952749252319e-01
    z[4,3,2]  R1940     6.1554181575775146e-01
    z[4,3,2]  R1941     -1.8043044209480286e-01
    z[4,3,2]  R1942     5.0926405191421509e-01
    z[4,3,2]  R1943     0.601693332195282
    z[4,3,2]  R1944     3.4847456216812134e-01
    z[4,3,2]  R1945     1.5690174698829651e-01
    z[4,3,2]  R1946     2.4623838067054749e-01
    z[4,3,2]  R1947     4.4899916648864746e-01
    z[4,3,2]  R1948     -2.7870857715606689e-01
    z[4,3,2]  R1949     8.3460563421249390e-01
    z[4,3,2]  R1950     -1.3503019511699677e-01
    z[4,3,2]  R1951     0.885668933391571
    z[4,3,2]  R1952     4.7445856034755707e-02
    z[4,3,2]  R1953     7.3200774192810059e-01
    z[4,3,2]  R1954     2.9898330569267273e-01
    z[4,3,2]  R1955     4.1195716708898544e-02
    z[4,3,2]  R1956     1.0171540081501007e-01
    z[4,3,2]  R1957     0.672829806804657
    z[4,3,2]  R1958     3.6227068305015564e-01
    z[4,3,2]  R1959     3.1364640593528748e-01
    z[4,3,2]  R1960     4.2406827211380005e-01
    z[4,3,2]  R1961     4.3404987454414368e-01
    z[4,3,2]  R1962     -6.8644896149635315e-02
    z[4,3,2]  R1963     0.256710946559906
    z[4,3,2]  R1964     -1.0159547626972198e-01
    z[4,3,2]  R1965     -5.5583781003952026e-01
    z[4,3,2]  R1966     -4.9035421013832092e-01
    z[4,3,2]  R1967     6.7314106225967407e-01
    z[4,3,2]  R1968     4.7472253441810608e-01
    z[4,3,2]  R1969     1.0133743286132812e-01
    z[4,3,2]  R1970     2.0631836354732513e-01
    z[4,3,2]  R1971     5.0050681829452515e-01
    z[4,3,2]  R1972     -2.1060007810592651e-01
    z[4,3,2]  R1973     6.1223471164703369e-01
    z[4,3,2]  R1974     5.7189010083675385e-02
    z[4,3,2]  R1975     2.2347699105739594e-01
    z[4,3,2]  R1976     -1.4080753922462463e-01
    z[4,3,2]  R1977     -2.3597948253154755e-01
    z[4,3,2]  R1978     5.6909757852554321e-01
    z[4,3,2]  R1979     -4.2687880992889404e-01
    z[4,3,2]  R1980     4.4247588515281677e-01
    z[4,3,2]  R1981     -3.9816579222679138e-01
    z[4,3,2]  R1982     4.3460118770599365e-01
    z[4,3,2]  R1983     -6.5257710218429565e-01
    z[4,3,2]  R1984     -4.8077547550201416e-01
    z[4,3,2]  R1985     -1.4383430778980255e-01
    z[4,3,2]  R1986     3.4261253476142883e-01
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R1882     -1
    z[4,3,3]  R1883     1
    z[4,3,3]  R1890     7.4422317743301392e-01
    z[4,3,3]  R1891     2.4902540445327759e-01
    z[4,3,3]  R1892     6.2218014150857925e-02
    z[4,3,3]  R1893     2.1696844696998596e-01
    z[4,3,3]  R1894     -6.5100783109664917e-01
    z[4,3,3]  R1895     -8.7795192003250122e-01
    z[4,3,3]  R1896     -4.7661110758781433e-01
    z[4,3,3]  R1897     3.7420988082885742e-01
    z[4,3,3]  R1898     6.7907691001892090e-01
    z[4,3,3]  R1899     4.3427556753158569e-01
    z[4,3,3]  R1900     5.0297158956527710e-01
    z[4,3,3]  R1901     6.7577290534973145e-01
    z[4,3,3]  R1902     -2.4416683614253998e-01
    z[4,3,3]  R1903     1.3043354451656342e-01
    z[4,3,3]  R1904     2.3145893216133118e-01
    z[4,3,3]  R1905     3.4173694252967834e-01
    z[4,3,3]  R1906     3.4725794196128845e-01
    z[4,3,3]  R1907     -3.9352294057607651e-02
    z[4,3,3]  R1908     -2.0397897064685822e-01
    z[4,3,3]  R1909     1.7381841316819191e-02
    z[4,3,3]  R1910     -1.0820031911134720e-01
    z[4,3,3]  R1911     -2.0943066477775574e-01
    z[4,3,3]  R1912     -2.5197410583496094e-01
    z[4,3,3]  R1913     2.8585383668541908e-02
    z[4,3,3]  R1914     -3.0092450976371765e-01
    z[4,3,3]  R1915     -4.6742090582847595e-01
    z[4,3,3]  R1916     -3.0300248414278030e-02
    z[4,3,3]  R1917     -6.7259013652801514e-01
    z[4,3,3]  R1918     -5.8234238624572754e-01
    z[4,3,3]  R1919     -4.4266286492347717e-01
    z[4,3,3]  R1920     6.7975777387619019e-01
    z[4,3,3]  R1921     -5.2452695369720459e-01
    z[4,3,3]  R1922     -1.4348666369915009e-01
    z[4,3,3]  R1923     -8.2589067518711090e-02
    z[4,3,3]  R1924     -2.4972349405288696e-01
    z[4,3,3]  R1925     -1.6817671060562134e-01
    z[4,3,3]  R1926     -2.3673868179321289e-01
    z[4,3,3]  R1927     -6.9535695016384125e-02
    z[4,3,3]  R1928     -2.5063166022300720e-01
    z[4,3,3]  R1929     -2.6369345188140869e-01
    z[4,3,3]  R1930     -3.9013007283210754e-01
    z[4,3,3]  R1931     -3.8972941040992737e-01
    z[4,3,3]  R1932     2.8705161809921265e-01
    z[4,3,3]  R1933     7.6106287539005280e-02
    z[4,3,3]  R1934     5.8734875917434692e-01
    z[4,3,3]  R1935     4.8898744583129883e-01
    z[4,3,3]  R1936     -4.2992007732391357e-01
    z[4,3,3]  R1937     -4.4301679730415344e-01
    z[4,3,3]  R1938     -1.8483416736125946e-01
    z[4,3,3]  R1939     -0.665672242641449
    z[4,3,3]  R1940     -4.3565583229064941e-01
    z[4,3,3]  R1941     -4.9580168724060059e-01
    z[4,3,3]  R1942     1.5340850688517094e-02
    z[4,3,3]  R1943     -2.3656207323074341e-01
    z[4,3,3]  R1944     4.2897865176200867e-01
    z[4,3,3]  R1945     2.7163015678524971e-02
    z[4,3,3]  R1946     -1.9019616767764091e-02
    z[4,3,3]  R1947     -3.0038860440254211e-01
    z[4,3,3]  R1948     -0.324074387550354
    z[4,3,3]  R1949     -1.2518766522407532e-01
    z[4,3,3]  R1950     7.3851294815540314e-02
    z[4,3,3]  R1951     -2.6993727311491966e-02
    z[4,3,3]  R1952     -2.3950931429862976e-01
    z[4,3,3]  R1953     -8.0155604518949986e-04
    z[4,3,3]  R1954     -6.5887951850891113e-01
    z[4,3,3]  R1955     -2.7802556753158569e-01
    z[4,3,3]  R1956     -9.0073829889297485e-01
    z[4,3,3]  R1957     -3.9974990487098694e-01
    z[4,3,3]  R1958     -7.0483297109603882e-01
    z[4,3,3]  R1959     -0.636849045753479
    z[4,3,3]  R1960     1.4090560376644135e-01
    z[4,3,3]  R1961     4.3926298618316650e-01
    z[4,3,3]  R1962     1.7935261130332947e-01
    z[4,3,3]  R1963     -4.4287670403718948e-02
    z[4,3,3]  R1964     -1.9506633281707764e-01
    z[4,3,3]  R1965     4.2763477563858032e-01
    z[4,3,3]  R1966     2.4731636047363281e-01
    z[4,3,3]  R1967     -4.1987213492393494e-01
    z[4,3,3]  R1968     -5.4470568895339966e-01
    z[4,3,3]  R1969     -2.0091973245143890e-01
    z[4,3,3]  R1970     5.7016885280609131e-01
    z[4,3,3]  R1971     1.8288058042526245e-01
    z[4,3,3]  R1972     5.7683402299880981e-01
    z[4,3,3]  R1973     9.9328316748142242e-02
    z[4,3,3]  R1974     -2.7665802836418152e-01
    z[4,3,3]  R1975     -2.5349313020706177e-01
    z[4,3,3]  R1976     -3.3209922909736633e-01
    z[4,3,3]  R1977     -5.1900601387023926e-01
    z[4,3,3]  R1978     -3.1045249104499817e-01
    z[4,3,3]  R1979     3.1423109769821167e-01
    z[4,3,3]  R1980     2.1137748658657074e-01
    z[4,3,3]  R1981     2.8813469409942627e-01
    z[4,3,3]  R1982     4.5024354010820389e-02
    z[4,3,3]  R1983     5.6768339872360229e-01
    z[4,3,3]  R1984     5.4710513353347778e-01
    z[4,3,3]  R1985     2.6591575145721436e-01
    z[4,3,3]  R1986     -1.4462395012378693e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R1884     -1
    z[4,3,4]  R1885     1
    z[4,3,4]  R1890     3.2042428851127625e-01
    z[4,3,4]  R1891     3.3340302109718323e-01
    z[4,3,4]  R1892     8.4792442619800568e-02
    z[4,3,4]  R1893     -9.2411078512668610e-02
    z[4,3,4]  R1894     3.4073132276535034e-01
    z[4,3,4]  R1895     -3.8112181425094604e-01
    z[4,3,4]  R1896     -1.6519330441951752e-01
    z[4,3,4]  R1897     -4.6652253717184067e-02
    z[4,3,4]  R1898     -2.4003187194466591e-02
    z[4,3,4]  R1899     4.5995318889617920e-01
    z[4,3,4]  R1900     2.9704380035400391e-01
    z[4,3,4]  R1901     2.0661835372447968e-01
    z[4,3,4]  R1902     -2.1915614604949951e-01
    z[4,3,4]  R1903     1.3381545245647430e-01
    z[4,3,4]  R1904     -1.3279208540916443e-01
    z[4,3,4]  R1905     -1.2246138602495193e-01
    z[4,3,4]  R1906     3.7044730782508850e-01
    z[4,3,4]  R1907     0.0644272193312645
    z[4,3,4]  R1908     1.7407299578189850e-01
    z[4,3,4]  R1909     -1.0715722292661667e-01
    z[4,3,4]  R1910     -1.4778789877891541e-01
    z[4,3,4]  R1911     -1.4112314581871033e-01
    z[4,3,4]  R1912     2.2384163737297058e-01
    z[4,3,4]  R1913     1.7793895304203033e-01
    z[4,3,4]  R1914     4.4721037149429321e-01
    z[4,3,4]  R1915     -0.0606394037604332
    z[4,3,4]  R1916     1.2662783265113831e-01
    z[4,3,4]  R1917     1.7410339415073395e-01
    z[4,3,4]  R1918     3.4294697642326355e-01
    z[4,3,4]  R1919     0.0515059269964695
    z[4,3,4]  R1920     -3.0618287622928619e-02
    z[4,3,4]  R1921     1.1818935722112656e-01
    z[4,3,4]  R1922     -2.5935724377632141e-01
    z[4,3,4]  R1923     -7.0793621242046356e-02
    z[4,3,4]  R1924     -2.3014941811561584e-01
    z[4,3,4]  R1925     -2.3294666409492493e-01
    z[4,3,4]  R1926     2.0637065172195435e-01
    z[4,3,4]  R1927     -4.1234114766120911e-01
    z[4,3,4]  R1928     4.6587803959846497e-01
    z[4,3,4]  R1929     0.31876340508461
    z[4,3,4]  R1930     -1.3341650366783142e-01
    z[4,3,4]  R1931     -4.1229271888732910e-01
    z[4,3,4]  R1932     2.4737310409545898e-01
    z[4,3,4]  R1933     0.0967501625418663
    z[4,3,4]  R1934     4.6853196620941162e-01
    z[4,3,4]  R1935     3.2393902540206909e-01
    z[4,3,4]  R1936     1.9697868824005127e-01
    z[4,3,4]  R1937     2.0611914992332458e-01
    z[4,3,4]  R1938     -2.7662146091461182e-01
    z[4,3,4]  R1939     -2.1774184703826904e-01
    z[4,3,4]  R1940     -1.7755937576293945e-01
    z[4,3,4]  R1941     -6.5851235389709473e-01
    z[4,3,4]  R1942     -6.3356764614582062e-02
    z[4,3,4]  R1943     -9.6845224499702454e-02
    z[4,3,4]  R1944     2.3995047807693481e-01
    z[4,3,4]  R1945     -1.2424138188362122e-01
    z[4,3,4]  R1946     1.5257167816162109e-01
    z[4,3,4]  R1947     -8.3643466234207153e-02
    z[4,3,4]  R1948     -1.0962177067995071e-01
    z[4,3,4]  R1949     -3.1764388084411621e-01
    z[4,3,4]  R1950     1.7952004075050354e-01
    z[4,3,4]  R1951     3.9193700999021530e-02
    z[4,3,4]  R1952     1.7649734020233154e-01
    z[4,3,4]  R1953     0.24935382604599
    z[4,3,4]  R1954     8.4604196250438690e-02
    z[4,3,4]  R1955     -2.7523839473724365e-01
    z[4,3,4]  R1956     2.5690355896949768e-01
    z[4,3,4]  R1957     1.5428103506565094e-01
    z[4,3,4]  R1958     1.6195248812437057e-02
    z[4,3,4]  R1959     8.7646394968032837e-02
    z[4,3,4]  R1960     2.2998262941837311e-01
    z[4,3,4]  R1961     -8.0991901457309723e-02
    z[4,3,4]  R1962     1.5155556797981262e-01
    z[4,3,4]  R1963     -6.2881387770175934e-02
    z[4,3,4]  R1964     -1.9795902073383331e-01
    z[4,3,4]  R1965     -2.9808852076530457e-01
    z[4,3,4]  R1966     -2.7864545583724976e-01
    z[4,3,4]  R1967     -5.4691050201654434e-02
    z[4,3,4]  R1968     -1.0489811003208160e-01
    z[4,3,4]  R1969     -2.9336953163146973e-01
    z[4,3,4]  R1970     2.2056722640991211e-01
    z[4,3,4]  R1971     9.9898435175418854e-02
    z[4,3,4]  R1972     -4.8859912157058716e-01
    z[4,3,4]  R1973     3.5315670073032379e-02
    z[4,3,4]  R1974     -2.1309521794319153e-01
    z[4,3,4]  R1975     8.6106121540069580e-01
    z[4,3,4]  R1976     3.3534392714500427e-01
    z[4,3,4]  R1977     -3.8835567235946655e-01
    z[4,3,4]  R1978     5.3314459323883057e-01
    z[4,3,4]  R1979     -2.9568953439593315e-02
    z[4,3,4]  R1980     -1.4985139667987823e-01
    z[4,3,4]  R1981     0.320017009973526
    z[4,3,4]  R1982     3.4514892101287842e-01
    z[4,3,4]  R1983     -1.2468189746141434e-01
    z[4,3,4]  R1984     3.4777253866195679e-02
    z[4,3,4]  R1985     0.360971599817276
    z[4,3,4]  R1986     -1.2381967157125473e-01
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R1886     -1
    z[4,3,5]  R1887     1
    z[4,3,5]  R1890     -1.8587963283061981e-01
    z[4,3,5]  R1891     -1.5794233977794647e-01
    z[4,3,5]  R1892     -3.5428476333618164e-01
    z[4,3,5]  R1893     0.590069055557251
    z[4,3,5]  R1894     5.8619880676269531e-01
    z[4,3,5]  R1895     -2.1884655952453613e-01
    z[4,3,5]  R1896     2.6538777351379395e-01
    z[4,3,5]  R1897     -4.4074233621358871e-02
    z[4,3,5]  R1898     -1.4495445787906647e-01
    z[4,3,5]  R1899     -6.9058477878570557e-02
    z[4,3,5]  R1900     -2.8482276201248169e-01
    z[4,3,5]  R1901     1.8145045638084412e-01
    z[4,3,5]  R1902     1.5429614484310150e-01
    z[4,3,5]  R1903     -1.0010101646184921e-01
    z[4,3,5]  R1904     -1.0949768126010895e-01
    z[4,3,5]  R1905     -3.4235006570816040e-01
    z[4,3,5]  R1906     1.0637746751308441e-01
    z[4,3,5]  R1907     2.8287851810455322e-01
    z[4,3,5]  R1908     2.0069922506809235e-01
    z[4,3,5]  R1909     2.3118227720260620e-01
    z[4,3,5]  R1910     -0.075913205742836
    z[4,3,5]  R1911     0.535001814365387
    z[4,3,5]  R1912     1.0893454402685165e-01
    z[4,3,5]  R1913     2.9696938395500183e-01
    z[4,3,5]  R1914     4.0769883990287781e-01
    z[4,3,5]  R1915     -4.6716742217540741e-03
    z[4,3,5]  R1916     2.5278747081756592e-01
    z[4,3,5]  R1917     4.4447210431098938e-01
    z[4,3,5]  R1918     5.4762428998947144e-01
    z[4,3,5]  R1919     6.3761627674102783e-01
    z[4,3,5]  R1920     -2.6111018657684326e-01
    z[4,3,5]  R1921     6.4481425285339355e-01
    z[4,3,5]  R1922     -3.5370582342147827e-01
    z[4,3,5]  R1923     -4.5468306541442871e-01
    z[4,3,5]  R1924     -0.252608984708786
    z[4,3,5]  R1925     -5.0605303049087524e-01
    z[4,3,5]  R1926     -4.5991146564483643e-01
    z[4,3,5]  R1927     4.8409852385520935e-01
    z[4,3,5]  R1928     0.587566614151001
    z[4,3,5]  R1929     6.3206166028976440e-01
    z[4,3,5]  R1930     5.8540689945220947e-01
    z[4,3,5]  R1931     5.7594513893127441e-01
    z[4,3,5]  R1932     -2.8168687224388123e-01
    z[4,3,5]  R1933     5.8635663986206055e-01
    z[4,3,5]  R1934     -1.1911985278129578e-01
    z[4,3,5]  R1935     1.7296472191810608e-01
    z[4,3,5]  R1936     -2.8461429476737976e-01
    z[4,3,5]  R1937     5.6511014699935913e-01
    z[4,3,5]  R1938     2.6678198575973511e-01
    z[4,3,5]  R1939     4.8890298604965210e-01
    z[4,3,5]  R1940     -0.0569256953895092
    z[4,3,5]  R1941     -2.1289469301700592e-01
    z[4,3,5]  R1942     2.3178681731224060e-01
    z[4,3,5]  R1943     3.6339035630226135e-01
    z[4,3,5]  R1944     4.3757492303848267e-01
    z[4,3,5]  R1945     7.4298632144927979e-01
    z[4,3,5]  R1946     5.8118617534637451e-01
    z[4,3,5]  R1947     3.7851619720458984e-01
    z[4,3,5]  R1948     -2.1907933056354523e-01
    z[4,3,5]  R1949     2.9881912469863892e-01
    z[4,3,5]  R1950     1.2832273729145527e-02
    z[4,3,5]  R1951     3.4379380941390991e-01
    z[4,3,5]  R1952     5.8337718248367310e-01
    z[4,3,5]  R1953     5.1027429103851318e-01
    z[4,3,5]  R1954     4.4948694109916687e-01
    z[4,3,5]  R1955     1.1982368677854538e-01
    z[4,3,5]  R1956     -0.0586259625852108
    z[4,3,5]  R1957     6.0723256319761276e-02
    z[4,3,5]  R1958     2.1167193353176117e-01
    z[4,3,5]  R1959     5.9822231531143188e-02
    z[4,3,5]  R1960     6.9899767637252808e-01
    z[4,3,5]  R1961     1.0365897417068481e-01
    z[4,3,5]  R1962     4.8748105764389038e-01
    z[4,3,5]  R1963     8.9537531137466431e-01
    z[4,3,5]  R1964     6.8468856811523438e-01
    z[4,3,5]  R1965     -4.6031859517097473e-01
    z[4,3,5]  R1966     -5.5460166931152344e-01
    z[4,3,5]  R1967     2.7098900079727173e-01
    z[4,3,5]  R1968     5.4674917459487915e-01
    z[4,3,5]  R1969     -5.4734289646148682e-01
    z[4,3,5]  R1970     4.1980616748332977e-02
    z[4,3,5]  R1971     -1.3455897569656372e-01
    z[4,3,5]  R1972     0.287685364484787
    z[4,3,5]  R1973     6.1171799898147583e-01
    z[4,3,5]  R1974     -1.0330747067928314e-01
    z[4,3,5]  R1975     -1.2625804543495178e-01
    z[4,3,5]  R1976     -1.2806738913059235e-01
    z[4,3,5]  R1977     -2.3561830818653107e-01
    z[4,3,5]  R1978     2.7680492401123047e-01
    z[4,3,5]  R1979     -6.6292285919189453e-01
    z[4,3,5]  R1980     5.4928410053253174e-01
    z[4,3,5]  R1981     4.1932541131973267e-01
    z[4,3,5]  R1982     0.254957914352417
    z[4,3,5]  R1983     -7.9919271171092987e-02
    z[4,3,5]  R1984     -4.2730411887168884e-01
    z[4,3,5]  R1985     2.8728953003883362e-01
    z[4,3,5]  R1986     1.8982259929180145e-01
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R1888     -1
    z[4,3,6]  R1889     1
    z[4,3,6]  R1890     -5.5428370833396912e-02
    z[4,3,6]  R1891     -4.7022271156311035e-01
    z[4,3,6]  R1892     4.7025975584983826e-01
    z[4,3,6]  R1893     0.768604576587677
    z[4,3,6]  R1894     6.7947648465633392e-02
    z[4,3,6]  R1895     3.6858968436717987e-02
    z[4,3,6]  R1896     -0.680474042892456
    z[4,3,6]  R1897     -1.5861645340919495e-01
    z[4,3,6]  R1898     1.9234988093376160e-01
    z[4,3,6]  R1899     -1.5485175885260105e-02
    z[4,3,6]  R1900     1.6566525399684906e-01
    z[4,3,6]  R1901     -2.8882148861885071e-01
    z[4,3,6]  R1902     -4.2173019051551819e-01
    z[4,3,6]  R1903     1.8046455085277557e-01
    z[4,3,6]  R1904     -2.7422466874122620e-01
    z[4,3,6]  R1905     1.2597066164016724e-01
    z[4,3,6]  R1906     -3.1372427940368652e-01
    z[4,3,6]  R1907     1.4145767688751221e-01
    z[4,3,6]  R1908     -7.0472881197929382e-02
    z[4,3,6]  R1909     6.9888085126876831e-02
    z[4,3,6]  R1910     2.7485650032758713e-02
    z[4,3,6]  R1911     1.8679074943065643e-01
    z[4,3,6]  R1912     -2.7392706274986267e-01
    z[4,3,6]  R1913     5.2603948116302490e-01
    z[4,3,6]  R1914     2.9290032386779785e-01
    z[4,3,6]  R1915     3.8864722847938538e-01
    z[4,3,6]  R1916     -2.4102360010147095e-01
    z[4,3,6]  R1917     -2.1817234158515930e-01
    z[4,3,6]  R1918     -1.9706779718399048e-01
    z[4,3,6]  R1919     -1.3251727819442749e-01
    z[4,3,6]  R1920     -1.6446286439895630e-01
    z[4,3,6]  R1921     2.6247581839561462e-01
    z[4,3,6]  R1922     4.5745734125375748e-02
    z[4,3,6]  R1923     2.3047868907451630e-01
    z[4,3,6]  R1924     -5.9881657361984253e-02
    z[4,3,6]  R1925     -9.4336703419685364e-02
    z[4,3,6]  R1926     5.8939591050148010e-02
    z[4,3,6]  R1927     -1.5689672902226448e-02
    z[4,3,6]  R1928     -1.8470782786607742e-02
    z[4,3,6]  R1929     4.1349419951438904e-01
    z[4,3,6]  R1930     4.8553115129470825e-01
    z[4,3,6]  R1931     1.9763223826885223e-01
    z[4,3,6]  R1932     5.5701290257275105e-03
    z[4,3,6]  R1933     -0.57218337059021
    z[4,3,6]  R1934     1.4964535832405090e-01
    z[4,3,6]  R1935     1.2106354348361492e-02
    z[4,3,6]  R1936     -2.5076735019683838e-01
    z[4,3,6]  R1937     2.1989084780216217e-01
    z[4,3,6]  R1938     -2.6869857311248779e-01
    z[4,3,6]  R1939     -2.6428046822547913e-01
    z[4,3,6]  R1940     1.2014728784561157e-01
    z[4,3,6]  R1941     -4.5258617401123047e-01
    z[4,3,6]  R1942     4.2708730697631836e-01
    z[4,3,6]  R1943     6.5108686685562134e-01
    z[4,3,6]  R1944     0.0421893447637558
    z[4,3,6]  R1945     -3.9146393537521362e-01
    z[4,3,6]  R1946     -4.8854342103004456e-01
    z[4,3,6]  R1947     -2.7119457721710205e-01
    z[4,3,6]  R1948     -6.6284263134002686e-01
    z[4,3,6]  R1949     9.0074427425861359e-02
    z[4,3,6]  R1950     -9.5177195966243744e-02
    z[4,3,6]  R1951     -2.7251252532005310e-01
    z[4,3,6]  R1952     -2.9646283388137817e-01
    z[4,3,6]  R1953     2.4682195484638214e-01
    z[4,3,6]  R1954     -5.0488543510437012e-01
    z[4,3,6]  R1955     -7.8267019987106323e-01
    z[4,3,6]  R1956     2.8267474845051765e-02
    z[4,3,6]  R1957     0.275452196598053
    z[4,3,6]  R1958     -1.0823348909616470e-01
    z[4,3,6]  R1959     -0.485553115606308
    z[4,3,6]  R1960     3.1136220693588257e-01
    z[4,3,6]  R1961     3.1912293285131454e-02
    z[4,3,6]  R1962     9.7209677100181580e-02
    z[4,3,6]  R1963     5.2639592438936234e-02
    z[4,3,6]  R1964     4.7794154286384583e-01
    z[4,3,6]  R1965     -9.5068022608757019e-02
    z[4,3,6]  R1966     2.1829910576343536e-01
    z[4,3,6]  R1967     8.0980263650417328e-02
    z[4,3,6]  R1968     -1.9113582372665405e-01
    z[4,3,6]  R1969     1.7105533182621002e-01
    z[4,3,6]  R1970     -1.8997816741466522e-01
    z[4,3,6]  R1971     -1.4648582041263580e-01
    z[4,3,6]  R1972     9.8100811243057251e-02
    z[4,3,6]  R1973     -3.3444008231163025e-01
    z[4,3,6]  R1974     1.7640037834644318e-01
    z[4,3,6]  R1975     2.6220846176147461e-01
    z[4,3,6]  R1976     -1.7896692454814911e-01
    z[4,3,6]  R1977     -2.0715422928333282e-01
    z[4,3,6]  R1978     -2.8764620423316956e-01
    z[4,3,6]  R1979     0.0504353865981102
    z[4,3,6]  R1980     3.1272175908088684e-01
    z[4,3,6]  R1981     2.3649330437183380e-01
    z[4,3,6]  R1982     -2.9267209768295288e-01
    z[4,3,6]  R1983     1.2861740775406361e-02
    z[4,3,6]  R1984     3.5773232579231262e-01
    z[4,3,6]  R1985     -7.4043780565261841e-02
    z[4,3,6]  R1986     -3.3289868384599686e-02
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R2091     -1
    z[4,5,0]  R2092     1
    z[4,5,0]  R2105     2.1349316835403442e-01
    z[4,5,0]  R2106     -4.5517912507057190e-01
    z[4,5,0]  R2107     6.5998509526252747e-02
    z[4,5,0]  R2108     2.2978940978646278e-02
    z[4,5,0]  R2109     -2.9317969083786011e-01
    z[4,5,0]  R2110     -9.3563318252563477e-02
    z[4,5,0]  R2111     4.4083085656166077e-01
    z[4,5,0]  R2112     6.3620336353778839e-02
    z[4,5,0]  R2113     3.7411540746688843e-01
    z[4,5,0]  R2114     0.309985488653183
    z[4,5,0]  R2115     2.2376090288162231e-01
    z[4,5,0]  R2116     1.9197373092174530e-01
    z[4,5,0]  R2117     5.7358872890472412e-01
    z[4,5,0]  R2118     -5.3023308515548706e-01
    z[4,5,0]  R2119     1.0566161572933197e-01
    z[4,5,0]  R2120     4.4696331024169922e-01
    z[4,5,0]  R2121     5.0492811203002930e-01
    z[4,5,0]  R2122     5.1830720901489258e-01
    z[4,5,0]  R2123     2.6020705699920654e-01
    z[4,5,0]  R2124     2.9869771003723145e-01
    z[4,5,0]  R2125     4.1372036933898926e-01
    z[4,5,0]  R2126     2.6807132363319397e-01
    z[4,5,0]  R2127     4.8167598247528076e-01
    z[4,5,0]  R2128     3.8679200410842896e-01
    z[4,5,0]  R2129     -6.5046213567256927e-02
    z[4,5,0]  R2130     -1.6289213672280312e-02
    z[4,5,0]  R2131     -4.6963214874267578e-01
    z[4,5,0]  R2132     7.6995509862899780e-01
    z[4,5,0]  R2133     4.8069155216217041e-01
    z[4,5,0]  R2134     -1.7894135415554047e-01
    z[4,5,0]  R2135     -1.6504043340682983e-01
    z[4,5,0]  R2136     -1.3117472827434540e-01
    z[4,5,0]  R2137     8.0199085175991058e-02
    z[4,5,0]  R2138     -0.0911993533372879
    z[4,5,0]  R2139     -1.5107788145542145e-01
    z[4,5,0]  R2140     -2.3619601130485535e-01
    z[4,5,0]  R2141     3.3547326922416687e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R2093     -1
    z[4,5,1]  R2094     1
    z[4,5,1]  R2105     -3.4159576892852783e-01
    z[4,5,1]  R2106     4.4207116961479187e-01
    z[4,5,1]  R2107     -3.6425170302391052e-01
    z[4,5,1]  R2108     5.7959675788879395e-02
    z[4,5,1]  R2109     -1.8813608912751079e-03
    z[4,5,1]  R2110     5.2941292524337769e-02
    z[4,5,1]  R2111     -1.3303664326667786e-01
    z[4,5,1]  R2112     2.1285678446292877e-01
    z[4,5,1]  R2113     -2.0423457026481628e-01
    z[4,5,1]  R2114     1.9847913086414337e-01
    z[4,5,1]  R2115     -2.6865140534937382e-03
    z[4,5,1]  R2116     1.7888420820236206e-01
    z[4,5,1]  R2117     2.1807121112942696e-02
    z[4,5,1]  R2118     1.6930523561313748e-03
    z[4,5,1]  R2119     5.4403698444366455e-01
    z[4,5,1]  R2120     8.5394734144210815e-01
    z[4,5,1]  R2121     5.2414888143539429e-01
    z[4,5,1]  R2122     -4.4503325223922729e-01
    z[4,5,1]  R2123     -5.0822061300277710e-01
    z[4,5,1]  R2124     -2.2731699049472809e-02
    z[4,5,1]  R2125     1.3671897351741791e-01
    z[4,5,1]  R2126     6.8114958703517914e-02
    z[4,5,1]  R2127     -1.7794659733772278e-01
    z[4,5,1]  R2128     -4.3558841943740845e-01
    z[4,5,1]  R2129     -0.775583803653717
    z[4,5,1]  R2130     -6.7599415779113770e-01
    z[4,5,1]  R2131     -7.6074421405792236e-01
    z[4,5,1]  R2132     3.2440826296806335e-01
    z[4,5,1]  R2133     3.7659278512001038e-01
    z[4,5,1]  R2134     -2.2676189243793488e-01
    z[4,5,1]  R2135     -1.5134532749652863e-01
    z[4,5,1]  R2136     4.4075556099414825e-02
    z[4,5,1]  R2137     -7.0459681749343872e-01
    z[4,5,1]  R2138     -4.2690876871347427e-02
    z[4,5,1]  R2139     -7.1568185091018677e-01
    z[4,5,1]  R2140     -2.0943626761436462e-01
    z[4,5,1]  R2141     8.2062435150146484e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R2095     -1
    z[4,5,2]  R2096     1
    z[4,5,2]  R2105     -3.7890592217445374e-01
    z[4,5,2]  R2106     4.2208835482597351e-01
    z[4,5,2]  R2107     7.1080386638641357e-01
    z[4,5,2]  R2108     -3.9535153657197952e-02
    z[4,5,2]  R2109     -1.6089507937431335e-01
    z[4,5,2]  R2110     1.5210928022861481e-01
    z[4,5,2]  R2111     6.8489299155771732e-03
    z[4,5,2]  R2112     0.376784086227417
    z[4,5,2]  R2113     3.3700317144393921e-01
    z[4,5,2]  R2114     0.441354900598526
    z[4,5,2]  R2115     -2.8998634219169617e-01
    z[4,5,2]  R2116     3.4507983922958374e-01
    z[4,5,2]  R2117     -4.0886303782463074e-01
    z[4,5,2]  R2118     4.8193186521530151e-01
    z[4,5,2]  R2119     3.1942182779312134e-01
    z[4,5,2]  R2120     -1.6876170411705971e-02
    z[4,5,2]  R2121     -3.4552210569381714e-01
    z[4,5,2]  R2122     2.6598111726343632e-03
    z[4,5,2]  R2123     -2.0064075291156769e-01
    z[4,5,2]  R2124     -8.2659468054771423e-02
    z[4,5,2]  R2125     3.5662662982940674e-01
    z[4,5,2]  R2126     -2.9090091586112976e-01
    z[4,5,2]  R2127     -2.6795518398284912e-01
    z[4,5,2]  R2128     4.9454793334007263e-01
    z[4,5,2]  R2129     4.2323939502239227e-02
    z[4,5,2]  R2130     2.4845432490110397e-02
    z[4,5,2]  R2131     -6.6998414695262909e-02
    z[4,5,2]  R2132     2.8627347946166992e-01
    z[4,5,2]  R2133     -2.3177672922611237e-01
    z[4,5,2]  R2134     2.3166167736053467e-01
    z[4,5,2]  R2135     2.1681115031242371e-01
    z[4,5,2]  R2136     -3.7851881235837936e-02
    z[4,5,2]  R2137     0.0953143835067749
    z[4,5,2]  R2138     4.1084265708923340e-01
    z[4,5,2]  R2139     3.4106969833374023e-01
    z[4,5,2]  R2140     5.6632423400878906e-01
    z[4,5,2]  R2141     -1.4988601207733154e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R2097     -1
    z[4,5,3]  R2098     1
    z[4,5,3]  R2105     7.4422317743301392e-01
    z[4,5,3]  R2106     2.4902540445327759e-01
    z[4,5,3]  R2107     6.2218014150857925e-02
    z[4,5,3]  R2108     2.1696844696998596e-01
    z[4,5,3]  R2109     -6.5100783109664917e-01
    z[4,5,3]  R2110     -8.7795192003250122e-01
    z[4,5,3]  R2111     -4.7661110758781433e-01
    z[4,5,3]  R2112     8.3240544795989990e-01
    z[4,5,3]  R2113     8.0293715000152588e-01
    z[4,5,3]  R2114     6.8090802431106567e-01
    z[4,5,3]  R2115     8.0558454990386963e-01
    z[4,5,3]  R2116     5.7945418357849121e-01
    z[4,5,3]  R2117     0.56508868932724
    z[4,5,3]  R2118     -5.6946748495101929e-01
    z[4,5,3]  R2119     -3.4010595083236694e-01
    z[4,5,3]  R2120     -9.2337392270565033e-02
    z[4,5,3]  R2121     -5.4880219697952271e-01
    z[4,5,3]  R2122     -6.8824869394302368e-01
    z[4,5,3]  R2123     -6.2659960985183716e-01
    z[4,5,3]  R2124     -8.8128763437271118e-01
    z[4,5,3]  R2125     -6.7467993497848511e-01
    z[4,5,3]  R2126     -6.4485955238342285e-01
    z[4,5,3]  R2127     -4.6592471003532410e-01
    z[4,5,3]  R2128     -0.272337943315506
    z[4,5,3]  R2129     -2.8358227014541626e-01
    z[4,5,3]  R2130     -2.9915022850036621e-01
    z[4,5,3]  R2131     1.7128208652138710e-02
    z[4,5,3]  R2132     2.4524433910846710e-01
    z[4,5,3]  R2133     5.5213207006454468e-01
    z[4,5,3]  R2134     -8.9250606298446655e-01
    z[4,5,3]  R2135     -8.3397108316421509e-01
    z[4,5,3]  R2136     0.740169107913971
    z[4,5,3]  R2137     -4.4767311215400696e-01
    z[4,5,3]  R2138     -7.2580933570861816e-01
    z[4,5,3]  R2139     -4.7706350684165955e-01
    z[4,5,3]  R2140     -0.359017938375473
    z[4,5,3]  R2141     1.7761951684951782e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R2099     -1
    z[4,5,4]  R2100     1
    z[4,5,4]  R2105     3.2042428851127625e-01
    z[4,5,4]  R2106     3.3340302109718323e-01
    z[4,5,4]  R2107     8.4792442619800568e-02
    z[4,5,4]  R2108     -9.2411078512668610e-02
    z[4,5,4]  R2109     3.4073132276535034e-01
    z[4,5,4]  R2110     -3.8112181425094604e-01
    z[4,5,4]  R2111     -1.6519330441951752e-01
    z[4,5,4]  R2112     2.1972514688968658e-01
    z[4,5,4]  R2113     2.1765190362930298e-01
    z[4,5,4]  R2114     4.0931142866611481e-02
    z[4,5,4]  R2115     2.1041837334632874e-01
    z[4,5,4]  R2116     2.9918965697288513e-01
    z[4,5,4]  R2117     1.8380618095397949e-01
    z[4,5,4]  R2118     -3.5623095463961363e-03
    z[4,5,4]  R2119     -3.0863493680953979e-01
    z[4,5,4]  R2120     6.2925219535827637e-02
    z[4,5,4]  R2121     1.8007060885429382e-01
    z[4,5,4]  R2122     2.4389740824699402e-01
    z[4,5,4]  R2123     4.0803790092468262e-01
    z[4,5,4]  R2124     2.2968213260173798e-01
    z[4,5,4]  R2125     2.7753636240959167e-01
    z[4,5,4]  R2126     2.0736928284168243e-01
    z[4,5,4]  R2127     7.0982277393341064e-02
    z[4,5,4]  R2128     3.4071475267410278e-02
    z[4,5,4]  R2129     4.9427163600921631e-01
    z[4,5,4]  R2130     3.9076145738363266e-02
    z[4,5,4]  R2131     2.3187184333801270e-01
    z[4,5,4]  R2132     1.3753369450569153e-01
    z[4,5,4]  R2133     -4.3718385696411133e-01
    z[4,5,4]  R2134     -1.0097002238035202e-01
    z[4,5,4]  R2135     4.4751915335655212e-01
    z[4,5,4]  R2136     -5.9085196256637573e-01
    z[4,5,4]  R2137     2.4820290505886078e-02
    z[4,5,4]  R2138     2.6861295104026794e-01
    z[4,5,4]  R2139     1.6392327845096588e-01
    z[4,5,4]  R2140     4.8956326209008694e-03
    z[4,5,4]  R2141     2.2232106328010559e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R2101     -1
    z[4,5,5]  R2102     1
    z[4,5,5]  R2105     -1.8587963283061981e-01
    z[4,5,5]  R2106     -1.5794233977794647e-01
    z[4,5,5]  R2107     -3.5428476333618164e-01
    z[4,5,5]  R2108     0.590069055557251
    z[4,5,5]  R2109     5.8619880676269531e-01
    z[4,5,5]  R2110     -2.1884655952453613e-01
    z[4,5,5]  R2111     2.6538777351379395e-01
    z[4,5,5]  R2112     2.1065457165241241e-01
    z[4,5,5]  R2113     -7.7650360763072968e-02
    z[4,5,5]  R2114     -4.2856833338737488e-01
    z[4,5,5]  R2115     1.0852876305580139e-01
    z[4,5,5]  R2116     -6.0421347618103027e-01
    z[4,5,5]  R2117     -3.2600095868110657e-01
    z[4,5,5]  R2118     0.366743803024292
    z[4,5,5]  R2119     -0.512775719165802
    z[4,5,5]  R2120     2.3371849954128265e-01
    z[4,5,5]  R2121     0.126520574092865
    z[4,5,5]  R2122     -5.0567211583256721e-03
    z[4,5,5]  R2123     2.1239832043647766e-01
    z[4,5,5]  R2124     -1.4609448611736298e-01
    z[4,5,5]  R2125     2.6021143794059753e-01
    z[4,5,5]  R2126     4.4713470339775085e-01
    z[4,5,5]  R2127     0.583529531955719
    z[4,5,5]  R2128     0.211939737200737
    z[4,5,5]  R2129     -2.4932612478733063e-01
    z[4,5,5]  R2130     -6.5293574333190918e-01
    z[4,5,5]  R2131     -2.3178772628307343e-01
    z[4,5,5]  R2132     2.1061576902866364e-02
    z[4,5,5]  R2133     2.0756955444812775e-01
    z[4,5,5]  R2134     1.8175454437732697e-01
    z[4,5,5]  R2135     7.4833102524280548e-02
    z[4,5,5]  R2136     -2.8705310821533203e-01
    z[4,5,5]  R2137     3.4221136569976807e-01
    z[4,5,5]  R2138     -3.9896681904792786e-01
    z[4,5,5]  R2139     -3.4685872495174408e-02
    z[4,5,5]  R2140     4.9487265944480896e-01
    z[4,5,5]  R2141     -1.7112414538860321e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R2103     -1
    z[4,5,6]  R2104     1
    z[4,5,6]  R2105     -5.5428370833396912e-02
    z[4,5,6]  R2106     -4.7022271156311035e-01
    z[4,5,6]  R2107     4.7025975584983826e-01
    z[4,5,6]  R2108     0.768604576587677
    z[4,5,6]  R2109     6.7947648465633392e-02
    z[4,5,6]  R2110     3.6858968436717987e-02
    z[4,5,6]  R2111     -0.680474042892456
    z[4,5,6]  R2112     1.5206854045391083e-01
    z[4,5,6]  R2113     -0.0815151035785675
    z[4,5,6]  R2114     1.4401021599769592e-01
    z[4,5,6]  R2115     4.0101242065429688e-01
    z[4,5,6]  R2116     1.4734651148319244e-01
    z[4,5,6]  R2117     2.0967794954776764e-01
    z[4,5,6]  R2118     -1.6668763756752014e-01
    z[4,5,6]  R2119     -3.4199798107147217e-01
    z[4,5,6]  R2120     -6.0024131089448929e-02
    z[4,5,6]  R2121     -3.6240525543689728e-02
    z[4,5,6]  R2122     9.9132414907217026e-03
    z[4,5,6]  R2123     1.7179162800312042e-01
    z[4,5,6]  R2124     -2.2948840260505676e-01
    z[4,5,6]  R2125     2.8815174102783203e-01
    z[4,5,6]  R2126     4.2438122630119324e-01
    z[4,5,6]  R2127     -0.319205641746521
    z[4,5,6]  R2128     5.4390239715576172e-01
    z[4,5,6]  R2129     7.4569158256053925e-02
    z[4,5,6]  R2130     -1.5750029683113098e-01
    z[4,5,6]  R2131     0.297391414642334
    z[4,5,6]  R2132     -3.7479585409164429e-01
    z[4,5,6]  R2133     -1.8527930974960327e-01
    z[4,5,6]  R2134     -1.5197099745273590e-01
    z[4,5,6]  R2135     -3.8313020020723343e-02
    z[4,5,6]  R2136     -7.8656310215592384e-03
    z[4,5,6]  R2137     -4.1217800974845886e-01
    z[4,5,6]  R2138     2.5088205933570862e-01
    z[4,5,6]  R2139     -3.0493089556694031e-01
    z[4,5,6]  R2140     4.5366075634956360e-01
    z[4,5,6]  R2141     2.8514704108238220e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R2142     -1
    z[5,4,0]  R2143     1
    z[5,4,0]  R2156     6.3620336353778839e-02
    z[5,4,0]  R2157     3.7411540746688843e-01
    z[5,4,0]  R2158     0.309985488653183
    z[5,4,0]  R2159     2.2376090288162231e-01
    z[5,4,0]  R2160     1.9197373092174530e-01
    z[5,4,0]  R2161     5.7358872890472412e-01
    z[5,4,0]  R2162     -5.3023308515548706e-01
    z[5,4,0]  R2163     1.0566161572933197e-01
    z[5,4,0]  R2164     4.4696331024169922e-01
    z[5,4,0]  R2165     5.0492811203002930e-01
    z[5,4,0]  R2166     5.1830720901489258e-01
    z[5,4,0]  R2167     2.6020705699920654e-01
    z[5,4,0]  R2168     2.9869771003723145e-01
    z[5,4,0]  R2169     4.1372036933898926e-01
    z[5,4,0]  R2170     2.6807132363319397e-01
    z[5,4,0]  R2171     4.8167598247528076e-01
    z[5,4,0]  R2172     3.8679200410842896e-01
    z[5,4,0]  R2173     -6.5046213567256927e-02
    z[5,4,0]  R2174     -1.6289213672280312e-02
    z[5,4,0]  R2175     -4.6963214874267578e-01
    z[5,4,0]  R2176     7.6995509862899780e-01
    z[5,4,0]  R2177     4.8069155216217041e-01
    z[5,4,0]  R2178     -1.7894135415554047e-01
    z[5,4,0]  R2179     -1.6504043340682983e-01
    z[5,4,0]  R2180     -1.3117472827434540e-01
    z[5,4,0]  R2181     8.0199085175991058e-02
    z[5,4,0]  R2182     -0.0911993533372879
    z[5,4,0]  R2183     -1.5107788145542145e-01
    z[5,4,0]  R2184     -2.3619601130485535e-01
    z[5,4,0]  R2185     3.3547326922416687e-01
    z[5,4,0]  R2186     2.1349316835403442e-01
    z[5,4,0]  R2187     -4.5517912507057190e-01
    z[5,4,0]  R2188     6.5998509526252747e-02
    z[5,4,0]  R2189     2.2978940978646278e-02
    z[5,4,0]  R2190     -2.9317969083786011e-01
    z[5,4,0]  R2191     -9.3563318252563477e-02
    z[5,4,0]  R2192     4.4083085656166077e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R2144     -1
    z[5,4,1]  R2145     1
    z[5,4,1]  R2156     2.1285678446292877e-01
    z[5,4,1]  R2157     -2.0423457026481628e-01
    z[5,4,1]  R2158     1.9847913086414337e-01
    z[5,4,1]  R2159     -2.6865140534937382e-03
    z[5,4,1]  R2160     1.7888420820236206e-01
    z[5,4,1]  R2161     2.1807121112942696e-02
    z[5,4,1]  R2162     1.6930523561313748e-03
    z[5,4,1]  R2163     5.4403698444366455e-01
    z[5,4,1]  R2164     8.5394734144210815e-01
    z[5,4,1]  R2165     5.2414888143539429e-01
    z[5,4,1]  R2166     -4.4503325223922729e-01
    z[5,4,1]  R2167     -5.0822061300277710e-01
    z[5,4,1]  R2168     -2.2731699049472809e-02
    z[5,4,1]  R2169     1.3671897351741791e-01
    z[5,4,1]  R2170     6.8114958703517914e-02
    z[5,4,1]  R2171     -1.7794659733772278e-01
    z[5,4,1]  R2172     -4.3558841943740845e-01
    z[5,4,1]  R2173     -0.775583803653717
    z[5,4,1]  R2174     -6.7599415779113770e-01
    z[5,4,1]  R2175     -7.6074421405792236e-01
    z[5,4,1]  R2176     3.2440826296806335e-01
    z[5,4,1]  R2177     3.7659278512001038e-01
    z[5,4,1]  R2178     -2.2676189243793488e-01
    z[5,4,1]  R2179     -1.5134532749652863e-01
    z[5,4,1]  R2180     4.4075556099414825e-02
    z[5,4,1]  R2181     -7.0459681749343872e-01
    z[5,4,1]  R2182     -4.2690876871347427e-02
    z[5,4,1]  R2183     -7.1568185091018677e-01
    z[5,4,1]  R2184     -2.0943626761436462e-01
    z[5,4,1]  R2185     8.2062435150146484e-01
    z[5,4,1]  R2186     -3.4159576892852783e-01
    z[5,4,1]  R2187     4.4207116961479187e-01
    z[5,4,1]  R2188     -3.6425170302391052e-01
    z[5,4,1]  R2189     5.7959675788879395e-02
    z[5,4,1]  R2190     -1.8813608912751079e-03
    z[5,4,1]  R2191     5.2941292524337769e-02
    z[5,4,1]  R2192     -1.3303664326667786e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R2146     -1
    z[5,4,2]  R2147     1
    z[5,4,2]  R2156     0.376784086227417
    z[5,4,2]  R2157     3.3700317144393921e-01
    z[5,4,2]  R2158     0.441354900598526
    z[5,4,2]  R2159     -2.8998634219169617e-01
    z[5,4,2]  R2160     3.4507983922958374e-01
    z[5,4,2]  R2161     -4.0886303782463074e-01
    z[5,4,2]  R2162     4.8193186521530151e-01
    z[5,4,2]  R2163     3.1942182779312134e-01
    z[5,4,2]  R2164     -1.6876170411705971e-02
    z[5,4,2]  R2165     -3.4552210569381714e-01
    z[5,4,2]  R2166     2.6598111726343632e-03
    z[5,4,2]  R2167     -2.0064075291156769e-01
    z[5,4,2]  R2168     -8.2659468054771423e-02
    z[5,4,2]  R2169     3.5662662982940674e-01
    z[5,4,2]  R2170     -2.9090091586112976e-01
    z[5,4,2]  R2171     -2.6795518398284912e-01
    z[5,4,2]  R2172     4.9454793334007263e-01
    z[5,4,2]  R2173     4.2323939502239227e-02
    z[5,4,2]  R2174     2.4845432490110397e-02
    z[5,4,2]  R2175     -6.6998414695262909e-02
    z[5,4,2]  R2176     2.8627347946166992e-01
    z[5,4,2]  R2177     -2.3177672922611237e-01
    z[5,4,2]  R2178     2.3166167736053467e-01
    z[5,4,2]  R2179     2.1681115031242371e-01
    z[5,4,2]  R2180     -3.7851881235837936e-02
    z[5,4,2]  R2181     0.0953143835067749
    z[5,4,2]  R2182     4.1084265708923340e-01
    z[5,4,2]  R2183     3.4106969833374023e-01
    z[5,4,2]  R2184     5.6632423400878906e-01
    z[5,4,2]  R2185     -1.4988601207733154e-01
    z[5,4,2]  R2186     -3.7890592217445374e-01
    z[5,4,2]  R2187     4.2208835482597351e-01
    z[5,4,2]  R2188     7.1080386638641357e-01
    z[5,4,2]  R2189     -3.9535153657197952e-02
    z[5,4,2]  R2190     -1.6089507937431335e-01
    z[5,4,2]  R2191     1.5210928022861481e-01
    z[5,4,2]  R2192     6.8489299155771732e-03
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R2148     -1
    z[5,4,3]  R2149     1
    z[5,4,3]  R2156     8.3240544795989990e-01
    z[5,4,3]  R2157     8.0293715000152588e-01
    z[5,4,3]  R2158     6.8090802431106567e-01
    z[5,4,3]  R2159     8.0558454990386963e-01
    z[5,4,3]  R2160     5.7945418357849121e-01
    z[5,4,3]  R2161     0.56508868932724
    z[5,4,3]  R2162     -5.6946748495101929e-01
    z[5,4,3]  R2163     -3.4010595083236694e-01
    z[5,4,3]  R2164     -9.2337392270565033e-02
    z[5,4,3]  R2165     -5.4880219697952271e-01
    z[5,4,3]  R2166     -6.8824869394302368e-01
    z[5,4,3]  R2167     -6.2659960985183716e-01
    z[5,4,3]  R2168     -8.8128763437271118e-01
    z[5,4,3]  R2169     -6.7467993497848511e-01
    z[5,4,3]  R2170     -6.4485955238342285e-01
    z[5,4,3]  R2171     -4.6592471003532410e-01
    z[5,4,3]  R2172     -0.272337943315506
    z[5,4,3]  R2173     -2.8358227014541626e-01
    z[5,4,3]  R2174     -2.9915022850036621e-01
    z[5,4,3]  R2175     1.7128208652138710e-02
    z[5,4,3]  R2176     2.4524433910846710e-01
    z[5,4,3]  R2177     5.5213207006454468e-01
    z[5,4,3]  R2178     -8.9250606298446655e-01
    z[5,4,3]  R2179     -8.3397108316421509e-01
    z[5,4,3]  R2180     0.740169107913971
    z[5,4,3]  R2181     -4.4767311215400696e-01
    z[5,4,3]  R2182     -7.2580933570861816e-01
    z[5,4,3]  R2183     -4.7706350684165955e-01
    z[5,4,3]  R2184     -0.359017938375473
    z[5,4,3]  R2185     1.7761951684951782e-01
    z[5,4,3]  R2186     7.4422317743301392e-01
    z[5,4,3]  R2187     2.4902540445327759e-01
    z[5,4,3]  R2188     6.2218014150857925e-02
    z[5,4,3]  R2189     2.1696844696998596e-01
    z[5,4,3]  R2190     -6.5100783109664917e-01
    z[5,4,3]  R2191     -8.7795192003250122e-01
    z[5,4,3]  R2192     -4.7661110758781433e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R2150     -1
    z[5,4,4]  R2151     1
    z[5,4,4]  R2156     2.1972514688968658e-01
    z[5,4,4]  R2157     2.1765190362930298e-01
    z[5,4,4]  R2158     4.0931142866611481e-02
    z[5,4,4]  R2159     2.1041837334632874e-01
    z[5,4,4]  R2160     2.9918965697288513e-01
    z[5,4,4]  R2161     1.8380618095397949e-01
    z[5,4,4]  R2162     -3.5623095463961363e-03
    z[5,4,4]  R2163     -3.0863493680953979e-01
    z[5,4,4]  R2164     6.2925219535827637e-02
    z[5,4,4]  R2165     1.8007060885429382e-01
    z[5,4,4]  R2166     2.4389740824699402e-01
    z[5,4,4]  R2167     4.0803790092468262e-01
    z[5,4,4]  R2168     2.2968213260173798e-01
    z[5,4,4]  R2169     2.7753636240959167e-01
    z[5,4,4]  R2170     2.0736928284168243e-01
    z[5,4,4]  R2171     7.0982277393341064e-02
    z[5,4,4]  R2172     3.4071475267410278e-02
    z[5,4,4]  R2173     4.9427163600921631e-01
    z[5,4,4]  R2174     3.9076145738363266e-02
    z[5,4,4]  R2175     2.3187184333801270e-01
    z[5,4,4]  R2176     1.3753369450569153e-01
    z[5,4,4]  R2177     -4.3718385696411133e-01
    z[5,4,4]  R2178     -1.0097002238035202e-01
    z[5,4,4]  R2179     4.4751915335655212e-01
    z[5,4,4]  R2180     -5.9085196256637573e-01
    z[5,4,4]  R2181     2.4820290505886078e-02
    z[5,4,4]  R2182     2.6861295104026794e-01
    z[5,4,4]  R2183     1.6392327845096588e-01
    z[5,4,4]  R2184     4.8956326209008694e-03
    z[5,4,4]  R2185     2.2232106328010559e-01
    z[5,4,4]  R2186     3.2042428851127625e-01
    z[5,4,4]  R2187     3.3340302109718323e-01
    z[5,4,4]  R2188     8.4792442619800568e-02
    z[5,4,4]  R2189     -9.2411078512668610e-02
    z[5,4,4]  R2190     3.4073132276535034e-01
    z[5,4,4]  R2191     -3.8112181425094604e-01
    z[5,4,4]  R2192     -1.6519330441951752e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R2152     -1
    z[5,4,5]  R2153     1
    z[5,4,5]  R2156     2.1065457165241241e-01
    z[5,4,5]  R2157     -7.7650360763072968e-02
    z[5,4,5]  R2158     -4.2856833338737488e-01
    z[5,4,5]  R2159     1.0852876305580139e-01
    z[5,4,5]  R2160     -6.0421347618103027e-01
    z[5,4,5]  R2161     -3.2600095868110657e-01
    z[5,4,5]  R2162     0.366743803024292
    z[5,4,5]  R2163     -0.512775719165802
    z[5,4,5]  R2164     2.3371849954128265e-01
    z[5,4,5]  R2165     0.126520574092865
    z[5,4,5]  R2166     -5.0567211583256721e-03
    z[5,4,5]  R2167     2.1239832043647766e-01
    z[5,4,5]  R2168     -1.4609448611736298e-01
    z[5,4,5]  R2169     2.6021143794059753e-01
    z[5,4,5]  R2170     4.4713470339775085e-01
    z[5,4,5]  R2171     0.583529531955719
    z[5,4,5]  R2172     0.211939737200737
    z[5,4,5]  R2173     -2.4932612478733063e-01
    z[5,4,5]  R2174     -6.5293574333190918e-01
    z[5,4,5]  R2175     -2.3178772628307343e-01
    z[5,4,5]  R2176     2.1061576902866364e-02
    z[5,4,5]  R2177     2.0756955444812775e-01
    z[5,4,5]  R2178     1.8175454437732697e-01
    z[5,4,5]  R2179     7.4833102524280548e-02
    z[5,4,5]  R2180     -2.8705310821533203e-01
    z[5,4,5]  R2181     3.4221136569976807e-01
    z[5,4,5]  R2182     -3.9896681904792786e-01
    z[5,4,5]  R2183     -3.4685872495174408e-02
    z[5,4,5]  R2184     4.9487265944480896e-01
    z[5,4,5]  R2185     -1.7112414538860321e-01
    z[5,4,5]  R2186     -1.8587963283061981e-01
    z[5,4,5]  R2187     -1.5794233977794647e-01
    z[5,4,5]  R2188     -3.5428476333618164e-01
    z[5,4,5]  R2189     0.590069055557251
    z[5,4,5]  R2190     5.8619880676269531e-01
    z[5,4,5]  R2191     -2.1884655952453613e-01
    z[5,4,5]  R2192     2.6538777351379395e-01
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R2154     -1
    z[5,4,6]  R2155     1
    z[5,4,6]  R2156     1.5206854045391083e-01
    z[5,4,6]  R2157     -0.0815151035785675
    z[5,4,6]  R2158     1.4401021599769592e-01
    z[5,4,6]  R2159     4.0101242065429688e-01
    z[5,4,6]  R2160     1.4734651148319244e-01
    z[5,4,6]  R2161     2.0967794954776764e-01
    z[5,4,6]  R2162     -1.6668763756752014e-01
    z[5,4,6]  R2163     -3.4199798107147217e-01
    z[5,4,6]  R2164     -6.0024131089448929e-02
    z[5,4,6]  R2165     -3.6240525543689728e-02
    z[5,4,6]  R2166     9.9132414907217026e-03
    z[5,4,6]  R2167     1.7179162800312042e-01
    z[5,4,6]  R2168     -2.2948840260505676e-01
    z[5,4,6]  R2169     2.8815174102783203e-01
    z[5,4,6]  R2170     4.2438122630119324e-01
    z[5,4,6]  R2171     -0.319205641746521
    z[5,4,6]  R2172     5.4390239715576172e-01
    z[5,4,6]  R2173     7.4569158256053925e-02
    z[5,4,6]  R2174     -1.5750029683113098e-01
    z[5,4,6]  R2175     0.297391414642334
    z[5,4,6]  R2176     -3.7479585409164429e-01
    z[5,4,6]  R2177     -1.8527930974960327e-01
    z[5,4,6]  R2178     -1.5197099745273590e-01
    z[5,4,6]  R2179     -3.8313020020723343e-02
    z[5,4,6]  R2180     -7.8656310215592384e-03
    z[5,4,6]  R2181     -4.1217800974845886e-01
    z[5,4,6]  R2182     2.5088205933570862e-01
    z[5,4,6]  R2183     -3.0493089556694031e-01
    z[5,4,6]  R2184     4.5366075634956360e-01
    z[5,4,6]  R2185     2.8514704108238220e-01
    z[5,4,6]  R2186     -5.5428370833396912e-02
    z[5,4,6]  R2187     -4.7022271156311035e-01
    z[5,4,6]  R2188     4.7025975584983826e-01
    z[5,4,6]  R2189     0.768604576587677
    z[5,4,6]  R2190     6.7947648465633392e-02
    z[5,4,6]  R2191     3.6858968436717987e-02
    z[5,4,6]  R2192     -0.680474042892456
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R2193     -1
    z[5,6,0]  R2194     1
    z[5,6,0]  R2207     6.3620336353778839e-02
    z[5,6,0]  R2208     3.7411540746688843e-01
    z[5,6,0]  R2209     0.309985488653183
    z[5,6,0]  R2210     2.2376090288162231e-01
    z[5,6,0]  R2211     1.9197373092174530e-01
    z[5,6,0]  R2212     5.7358872890472412e-01
    z[5,6,0]  R2213     -5.3023308515548706e-01
    z[5,6,0]  R2214     1.0566161572933197e-01
    z[5,6,0]  R2215     4.4696331024169922e-01
    z[5,6,0]  R2216     5.0492811203002930e-01
    z[5,6,0]  R2217     5.1830720901489258e-01
    z[5,6,0]  R2218     2.6020705699920654e-01
    z[5,6,0]  R2219     2.9869771003723145e-01
    z[5,6,0]  R2220     4.1372036933898926e-01
    z[5,6,0]  R2221     2.6807132363319397e-01
    z[5,6,0]  R2222     4.8167598247528076e-01
    z[5,6,0]  R2223     3.8679200410842896e-01
    z[5,6,0]  R2224     -6.5046213567256927e-02
    z[5,6,0]  R2225     -1.6289213672280312e-02
    z[5,6,0]  R2226     -4.6963214874267578e-01
    z[5,6,0]  R2227     7.6995509862899780e-01
    z[5,6,0]  R2228     4.8069155216217041e-01
    z[5,6,0]  R2229     -1.7894135415554047e-01
    z[5,6,0]  R2230     -1.6504043340682983e-01
    z[5,6,0]  R2231     -1.3117472827434540e-01
    z[5,6,0]  R2232     8.0199085175991058e-02
    z[5,6,0]  R2233     -0.0911993533372879
    z[5,6,0]  R2234     -1.5107788145542145e-01
    z[5,6,0]  R2235     -2.3619601130485535e-01
    z[5,6,0]  R2236     3.3547326922416687e-01
    z[5,6,0]  R2237     -5.2197545766830444e-01
    z[5,6,0]  R2238     -1.6462321579456329e-01
    z[5,6,0]  R2239     -1.6076698899269104e-01
    z[5,6,0]  R2240     -3.8243892788887024e-01
    z[5,6,0]  R2241     -1.0251833498477936e-01
    z[5,6,0]  R2242     9.1036915779113770e-01
    z[5,6,0]  R2243     8.9052850008010864e-01
    z[5,6,0]  R2244     7.8248989582061768e-01
    z[5,6,0]  R2245     6.7351412773132324e-01
    z[5,6,0]  R2246     8.4913635253906250e-01
    z[5,6,0]  R2247     -6.7606532573699951e-01
    z[5,6,0]  R2248     -2.2798025608062744e-01
    z[5,6,0]  R2249     4.7485885024070740e-01
    z[5,6,0]  R2250     -7.7141416072845459e-01
    z[5,6,0]  R2251     -3.1777629256248474e-01
    z[5,6,0]  R2252     1.9203804433345795e-01
    z[5,6,0]  R2253     0.0636850968003273
    z[5,6,0]  R2254     -1.9665436446666718e-01
    z[5,6,0]  R2255     8.7079554796218872e-03
    z[5,6,0]  R2256     -2.1306616067886353e-01
    z[5,6,0]  R2257     -5.2853122353553772e-02
    z[5,6,0]  R2258     2.9397246241569519e-01
    z[5,6,0]  R2259     0.219319149851799
    z[5,6,0]  R2260     3.9431083202362061e-01
    z[5,6,0]  R2261     -5.3770607709884644e-01
    z[5,6,0]  R2262     -0.549445629119873
    z[5,6,0]  R2263     -4.8566406965255737e-01
    z[5,6,0]  R2264     -5.0109875202178955e-01
    z[5,6,0]  R2265     4.9492076039314270e-01
    z[5,6,0]  R2266     6.7345392704010010e-01
    z[5,6,0]  R2267     -6.5735715627670288e-01
    z[5,6,0]  R2268     7.0079976320266724e-01
    z[5,6,0]  R2269     6.0476040840148926e-01
    z[5,6,0]  R2270     0.443428635597229
    z[5,6,0]  R2271     1.5491665899753571e-01
    z[5,6,0]  R2272     4.6872106194496155e-01
    z[5,6,0]  R2273     3.4745091199874878e-01
    z[5,6,0]  R2274     6.8955379724502563e-01
    z[5,6,0]  R2275     -4.6143087744712830e-01
    z[5,6,0]  R2276     5.3690975904464722e-01
    z[5,6,0]  R2277     -7.0697891712188721e-01
    z[5,6,0]  R2278     1.1184625327587128e-01
    z[5,6,0]  R2279     -5.5554300546646118e-01
    z[5,6,0]  R2280     -8.5844683647155762e-01
    z[5,6,0]  R2281     2.3760078847408295e-01
    z[5,6,0]  R2282     3.0090087652206421e-01
    z[5,6,0]  R2283     5.4956245422363281e-01
    z[5,6,0]  R2284     -1.3233710825443268e-01
    z[5,6,0]  R2285     1.7166146636009216e-01
    z[5,6,0]  R2286     4.6342480182647705e-01
    z[5,6,0]  R2287     1.8599800765514374e-02
    z[5,6,0]  R2288     0.588977038860321
    z[5,6,0]  R2289     1.8756064772605896e-01
    z[5,6,0]  R2290     8.9630484580993652e-02
    z[5,6,0]  R2291     -1.5797346830368042e-01
    z[5,6,0]  R2292     6.1854708194732666e-01
    z[5,6,0]  R2293     3.3072385191917419e-01
    z[5,6,0]  R2294     -3.1328000128269196e-02
    z[5,6,0]  R2295     7.6487630605697632e-02
    z[5,6,0]  R2296     3.5481783747673035e-01
    z[5,6,0]  R2297     -5.1282113790512085e-01
    z[5,6,0]  R2298     -7.3605132102966309e-01
    z[5,6,0]  R2299     7.8114360570907593e-02
    z[5,6,0]  R2300     4.9200615286827087e-01
    z[5,6,0]  R2301     6.2441922724246979e-02
    z[5,6,0]  R2302     8.6419032886624336e-03
    z[5,6,0]  R2303     -3.9424884319305420e-01
    z[5,6,0]  R2304     -3.1746748089790344e-01
    z[5,6,0]  R2305     -4.0277183055877686e-01
    z[5,6,0]  R2306     3.1345593929290771e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R2195     -1
    z[5,6,1]  R2196     1
    z[5,6,1]  R2207     2.1285678446292877e-01
    z[5,6,1]  R2208     -2.0423457026481628e-01
    z[5,6,1]  R2209     1.9847913086414337e-01
    z[5,6,1]  R2210     -2.6865140534937382e-03
    z[5,6,1]  R2211     1.7888420820236206e-01
    z[5,6,1]  R2212     2.1807121112942696e-02
    z[5,6,1]  R2213     1.6930523561313748e-03
    z[5,6,1]  R2214     5.4403698444366455e-01
    z[5,6,1]  R2215     8.5394734144210815e-01
    z[5,6,1]  R2216     5.2414888143539429e-01
    z[5,6,1]  R2217     -4.4503325223922729e-01
    z[5,6,1]  R2218     -5.0822061300277710e-01
    z[5,6,1]  R2219     -2.2731699049472809e-02
    z[5,6,1]  R2220     1.3671897351741791e-01
    z[5,6,1]  R2221     6.8114958703517914e-02
    z[5,6,1]  R2222     -1.7794659733772278e-01
    z[5,6,1]  R2223     -4.3558841943740845e-01
    z[5,6,1]  R2224     -0.775583803653717
    z[5,6,1]  R2225     -6.7599415779113770e-01
    z[5,6,1]  R2226     -7.6074421405792236e-01
    z[5,6,1]  R2227     3.2440826296806335e-01
    z[5,6,1]  R2228     3.7659278512001038e-01
    z[5,6,1]  R2229     -2.2676189243793488e-01
    z[5,6,1]  R2230     -1.5134532749652863e-01
    z[5,6,1]  R2231     4.4075556099414825e-02
    z[5,6,1]  R2232     -7.0459681749343872e-01
    z[5,6,1]  R2233     -4.2690876871347427e-02
    z[5,6,1]  R2234     -7.1568185091018677e-01
    z[5,6,1]  R2235     -2.0943626761436462e-01
    z[5,6,1]  R2236     8.2062435150146484e-01
    z[5,6,1]  R2237     -3.2811793684959412e-01
    z[5,6,1]  R2238     -3.2577949762344360e-01
    z[5,6,1]  R2239     -2.3336495459079742e-01
    z[5,6,1]  R2240     -5.3701114654541016e-01
    z[5,6,1]  R2241     -4.4717708230018616e-01
    z[5,6,1]  R2242     0.0356532521545887
    z[5,6,1]  R2243     -1.8908347189426422e-01
    z[5,6,1]  R2244     2.1818211302161217e-02
    z[5,6,1]  R2245     -2.2090595960617065e-01
    z[5,6,1]  R2246     -1.9661180675029755e-01
    z[5,6,1]  R2247     -1.0527092218399048e-01
    z[5,6,1]  R2248     -6.9276988506317139e-01
    z[5,6,1]  R2249     3.3125367015600204e-02
    z[5,6,1]  R2250     1.1375380307435989e-01
    z[5,6,1]  R2251     -5.4619574546813965e-01
    z[5,6,1]  R2252     2.7200818061828613e-01
    z[5,6,1]  R2253     -7.2978264093399048e-01
    z[5,6,1]  R2254     -6.5107178688049316e-01
    z[5,6,1]  R2255     -1.5670144930481911e-02
    z[5,6,1]  R2256     -6.8149912357330322e-01
    z[5,6,1]  R2257     -1.3495287299156189e-01
    z[5,6,1]  R2258     -8.0948662757873535e-01
    z[5,6,1]  R2259     -7.0741057395935059e-01
    z[5,6,1]  R2260     -8.3427554368972778e-01
    z[5,6,1]  R2261     -1.5183715522289276e-01
    z[5,6,1]  R2262     -8.6842171847820282e-02
    z[5,6,1]  R2263     -1.7410792410373688e-01
    z[5,6,1]  R2264     -2.6296639442443848e-01
    z[5,6,1]  R2265     -2.4480876326560974e-01
    z[5,6,1]  R2266     -3.5698909312486649e-02
    z[5,6,1]  R2267     -2.2902448475360870e-01
    z[5,6,1]  R2268     3.6682537198066711e-01
    z[5,6,1]  R2269     8.2808077335357666e-02
    z[5,6,1]  R2270     -1.9834369421005249e-01
    z[5,6,1]  R2271     -8.6241155862808228e-01
    z[5,6,1]  R2272     1.6020224988460541e-01
    z[5,6,1]  R2273     -0.084617480635643
    z[5,6,1]  R2274     1.7293068766593933e-01
    z[5,6,1]  R2275     1.3825920224189758e-01
    z[5,6,1]  R2276     4.1986593604087830e-01
    z[5,6,1]  R2277     -5.4223853349685669e-01
    z[5,6,1]  R2278     -7.8635834157466888e-02
    z[5,6,1]  R2279     -3.4241041541099548e-01
    z[5,6,1]  R2280     1.8217015266418457e-01
    z[5,6,1]  R2281     -8.9206188917160034e-01
    z[5,6,1]  R2282     -7.3266369104385376e-01
    z[5,6,1]  R2283     3.1029051542282104e-01
    z[5,6,1]  R2284     -7.3007690906524658e-01
    z[5,6,1]  R2285     -6.3801366090774536e-01
    z[5,6,1]  R2286     -2.4115969240665436e-01
    z[5,6,1]  R2287     -2.7241986244916916e-02
    z[5,6,1]  R2288     1.2814275920391083e-01
    z[5,6,1]  R2289     -6.4726972579956055e-01
    z[5,6,1]  R2290     -8.4598058462142944e-01
    z[5,6,1]  R2291     -6.4722114801406860e-01
    z[5,6,1]  R2292     -3.2419040799140930e-01
    z[5,6,1]  R2293     5.7426650077104568e-02
    z[5,6,1]  R2294     -4.7238388657569885e-01
    z[5,6,1]  R2295     2.6329854130744934e-01
    z[5,6,1]  R2296     8.4887528419494629e-01
    z[5,6,1]  R2297     -9.0420819818973541e-02
    z[5,6,1]  R2298     -9.8409861326217651e-02
    z[5,6,1]  R2299     -8.7990230321884155e-01
    z[5,6,1]  R2300     1.8412467092275620e-02
    z[5,6,1]  R2301     -5.4374831914901733e-01
    z[5,6,1]  R2302     2.5878661870956421e-01
    z[5,6,1]  R2303     6.9609928131103516e-01
    z[5,6,1]  R2304     7.1002978086471558e-01
    z[5,6,1]  R2305     6.3367408514022827e-01
    z[5,6,1]  R2306     8.3913958072662354e-01
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R2197     -1
    z[5,6,2]  R2198     1
    z[5,6,2]  R2207     0.376784086227417
    z[5,6,2]  R2208     3.3700317144393921e-01
    z[5,6,2]  R2209     0.441354900598526
    z[5,6,2]  R2210     -2.8998634219169617e-01
    z[5,6,2]  R2211     3.4507983922958374e-01
    z[5,6,2]  R2212     -4.0886303782463074e-01
    z[5,6,2]  R2213     4.8193186521530151e-01
    z[5,6,2]  R2214     3.1942182779312134e-01
    z[5,6,2]  R2215     -1.6876170411705971e-02
    z[5,6,2]  R2216     -3.4552210569381714e-01
    z[5,6,2]  R2217     2.6598111726343632e-03
    z[5,6,2]  R2218     -2.0064075291156769e-01
    z[5,6,2]  R2219     -8.2659468054771423e-02
    z[5,6,2]  R2220     3.5662662982940674e-01
    z[5,6,2]  R2221     -2.9090091586112976e-01
    z[5,6,2]  R2222     -2.6795518398284912e-01
    z[5,6,2]  R2223     4.9454793334007263e-01
    z[5,6,2]  R2224     4.2323939502239227e-02
    z[5,6,2]  R2225     2.4845432490110397e-02
    z[5,6,2]  R2226     -6.6998414695262909e-02
    z[5,6,2]  R2227     2.8627347946166992e-01
    z[5,6,2]  R2228     -2.3177672922611237e-01
    z[5,6,2]  R2229     2.3166167736053467e-01
    z[5,6,2]  R2230     2.1681115031242371e-01
    z[5,6,2]  R2231     -3.7851881235837936e-02
    z[5,6,2]  R2232     0.0953143835067749
    z[5,6,2]  R2233     4.1084265708923340e-01
    z[5,6,2]  R2234     3.4106969833374023e-01
    z[5,6,2]  R2235     5.6632423400878906e-01
    z[5,6,2]  R2236     -1.4988601207733154e-01
    z[5,6,2]  R2237     4.9247068166732788e-01
    z[5,6,2]  R2238     0.702812671661377
    z[5,6,2]  R2239     7.4170178174972534e-01
    z[5,6,2]  R2240     9.4406723976135254e-02
    z[5,6,2]  R2241     2.1973843872547150e-01
    z[5,6,2]  R2242     1.1154337227344513e-01
    z[5,6,2]  R2243     6.8829543888568878e-02
    z[5,6,2]  R2244     2.6227712631225586e-01
    z[5,6,2]  R2245     4.1704177856445312e-01
    z[5,6,2]  R2246     0.0787450522184372
    z[5,6,2]  R2247     -2.8018802404403687e-01
    z[5,6,2]  R2248     -1.8012490868568420e-01
    z[5,6,2]  R2249     5.7031378149986267e-02
    z[5,6,2]  R2250     -3.2692289352416992e-01
    z[5,6,2]  R2251     -2.9781109094619751e-01
    z[5,6,2]  R2252     1.8366594612598419e-01
    z[5,6,2]  R2253     -0.234488382935524
    z[5,6,2]  R2254     -2.7368941903114319e-01
    z[5,6,2]  R2255     -1.5721577405929565e-01
    z[5,6,2]  R2256     -7.8069724142551422e-02
    z[5,6,2]  R2257     4.0266913175582886e-01
    z[5,6,2]  R2258     3.4896153211593628e-01
    z[5,6,2]  R2259     6.5445274114608765e-02
    z[5,6,2]  R2260     -1.3660962879657745e-01
    z[5,6,2]  R2261     -2.1415871381759644e-01
    z[5,6,2]  R2262     -2.9749071598052979e-01
    z[5,6,2]  R2263     -3.1292143464088440e-01
    z[5,6,2]  R2264     -4.0407484769821167e-01
    z[5,6,2]  R2265     -2.4016296863555908e-01
    z[5,6,2]  R2266     -1.2989491224288940e-01
    z[5,6,2]  R2267     -3.2716563344001770e-01
    z[5,6,2]  R2268     2.5489461421966553e-01
    z[5,6,2]  R2269     -5.1718336343765259e-01
    z[5,6,2]  R2270     -6.7347055673599243e-01
    z[5,6,2]  R2271     -1.0436603426933289e-01
    z[5,6,2]  R2272     -3.2193490862846375e-01
    z[5,6,2]  R2273     -0.389515221118927
    z[5,6,2]  R2274     -0.0582720972597599
    z[5,6,2]  R2275     1.8238976597785950e-01
    z[5,6,2]  R2276     1.2936817109584808e-01
    z[5,6,2]  R2277     -1.4872124791145325e-01
    z[5,6,2]  R2278     2.0290501415729523e-01
    z[5,6,2]  R2279     -7.2191491723060608e-02
    z[5,6,2]  R2280     7.4390321969985962e-02
    z[5,6,2]  R2281     -8.6434474214911461e-03
    z[5,6,2]  R2282     -2.8759497404098511e-01
    z[5,6,2]  R2283     1.6714119911193848e-01
    z[5,6,2]  R2284     -5.2721619606018066e-01
    z[5,6,2]  R2285     -1.3237448036670685e-01
    z[5,6,2]  R2286     -6.3532269001007080e-01
    z[5,6,2]  R2287     4.0951010584831238e-01
    z[5,6,2]  R2288     -3.0285583809018135e-02
    z[5,6,2]  R2289     -2.8604707121849060e-01
    z[5,6,2]  R2290     -7.4590439908206463e-03
    z[5,6,2]  R2291     -7.6503805816173553e-02
    z[5,6,2]  R2292     -2.6078349351882935e-01
    z[5,6,2]  R2293     -1.5917524695396423e-01
    z[5,6,2]  R2294     -2.2744590044021606e-01
    z[5,6,2]  R2295     2.4288256466388702e-01
    z[5,6,2]  R2296     1.7767339944839478e-02
    z[5,6,2]  R2297     7.7531868219375610e-01
    z[5,6,2]  R2298     1.4420564472675323e-01
    z[5,6,2]  R2299     -0.339753121137619
    z[5,6,2]  R2300     -6.8565420806407928e-02
    z[5,6,2]  R2301     -4.5177906751632690e-01
    z[5,6,2]  R2302     1.1948562413454056e-01
    z[5,6,2]  R2303     -2.4445956945419312e-01
    z[5,6,2]  R2304     -2.9381096363067627e-01
    z[5,6,2]  R2305     -2.6035633683204651e-01
    z[5,6,2]  R2306     -1.3560469448566437e-01
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R2199     -1
    z[5,6,3]  R2200     1
    z[5,6,3]  R2207     8.3240544795989990e-01
    z[5,6,3]  R2208     8.0293715000152588e-01
    z[5,6,3]  R2209     6.8090802431106567e-01
    z[5,6,3]  R2210     8.0558454990386963e-01
    z[5,6,3]  R2211     5.7945418357849121e-01
    z[5,6,3]  R2212     0.56508868932724
    z[5,6,3]  R2213     -5.6946748495101929e-01
    z[5,6,3]  R2214     -3.4010595083236694e-01
    z[5,6,3]  R2215     -9.2337392270565033e-02
    z[5,6,3]  R2216     -5.4880219697952271e-01
    z[5,6,3]  R2217     -6.8824869394302368e-01
    z[5,6,3]  R2218     -6.2659960985183716e-01
    z[5,6,3]  R2219     -8.8128763437271118e-01
    z[5,6,3]  R2220     -6.7467993497848511e-01
    z[5,6,3]  R2221     -6.4485955238342285e-01
    z[5,6,3]  R2222     -4.6592471003532410e-01
    z[5,6,3]  R2223     -0.272337943315506
    z[5,6,3]  R2224     -2.8358227014541626e-01
    z[5,6,3]  R2225     -2.9915022850036621e-01
    z[5,6,3]  R2226     1.7128208652138710e-02
    z[5,6,3]  R2227     2.4524433910846710e-01
    z[5,6,3]  R2228     5.5213207006454468e-01
    z[5,6,3]  R2229     -8.9250606298446655e-01
    z[5,6,3]  R2230     -8.3397108316421509e-01
    z[5,6,3]  R2231     0.740169107913971
    z[5,6,3]  R2232     -4.4767311215400696e-01
    z[5,6,3]  R2233     -7.2580933570861816e-01
    z[5,6,3]  R2234     -4.7706350684165955e-01
    z[5,6,3]  R2235     -0.359017938375473
    z[5,6,3]  R2236     1.7761951684951782e-01
    z[5,6,3]  R2237     -2.7742058038711548e-01
    z[5,6,3]  R2238     -2.8037565946578979e-01
    z[5,6,3]  R2239     -5.1362150907516479e-01
    z[5,6,3]  R2240     -2.9821822047233582e-01
    z[5,6,3]  R2241     -4.2441949248313904e-01
    z[5,6,3]  R2242     3.2711493968963623e-01
    z[5,6,3]  R2243     1.3262446224689484e-01
    z[5,6,3]  R2244     5.3580540418624878e-01
    z[5,6,3]  R2245     5.4123628139495850e-01
    z[5,6,3]  R2246     2.9771557450294495e-01
    z[5,6,3]  R2247     -8.4155023097991943e-02
    z[5,6,3]  R2248     5.4116624593734741e-01
    z[5,6,3]  R2249     -6.9419378042221069e-01
    z[5,6,3]  R2250     4.6975526213645935e-01
    z[5,6,3]  R2251     6.6987228393554688e-01
    z[5,6,3]  R2252     -5.3416329622268677e-01
    z[5,6,3]  R2253     1.8474790453910828e-01
    z[5,6,3]  R2254     5.1658838987350464e-01
    z[5,6,3]  R2255     -5.5820119380950928e-01
    z[5,6,3]  R2256     6.4539723098278046e-02
    z[5,6,3]  R2257     -3.7743154168128967e-01
    z[5,6,3]  R2258     9.7281597554683685e-02
    z[5,6,3]  R2259     0.356892853975296
    z[5,6,3]  R2260     -1.4545871317386627e-01
    z[5,6,3]  R2261     4.8349192738533020e-01
    z[5,6,3]  R2262     4.4699767231941223e-01
    z[5,6,3]  R2263     3.7286359071731567e-01
    z[5,6,3]  R2264     2.3481087386608124e-01
    z[5,6,3]  R2265     -1.5259023755788803e-02
    z[5,6,3]  R2266     -5.4600322246551514e-01
    z[5,6,3]  R2267     -0.187056303024292
    z[5,6,3]  R2268     -3.7157908082008362e-01
    z[5,6,3]  R2269     1.8274098634719849e-01
    z[5,6,3]  R2270     4.1281515359878540e-01
    z[5,6,3]  R2271     -2.9662927985191345e-01
    z[5,6,3]  R2272     4.4106256961822510e-01
    z[5,6,3]  R2273     5.0108444690704346e-01
    z[5,6,3]  R2274     -3.9847409725189209e-01
    z[5,6,3]  R2275     7.2100222110748291e-01
    z[5,6,3]  R2276     -4.0396827459335327e-01
    z[5,6,3]  R2277     -2.8399446606636047e-01
    z[5,6,3]  R2278     -7.1887111663818359e-01
    z[5,6,3]  R2279     2.4760019034147263e-02
    z[5,6,3]  R2280     2.3305064439773560e-01
    z[5,6,3]  R2281     -1.5973395109176636e-01
    z[5,6,3]  R2282     3.9475908875465393e-01
    z[5,6,3]  R2283     -5.1230156421661377e-01
    z[5,6,3]  R2284     1.2086557596921921e-01
    z[5,6,3]  R2285     -4.4497188180685043e-02
    z[5,6,3]  R2286     3.5757806897163391e-01
    z[5,6,3]  R2287     -7.2074049711227417e-01
    z[5,6,3]  R2288     -7.3832678794860840e-01
    z[5,6,3]  R2289     6.1979812383651733e-01
    z[5,6,3]  R2290     1.5685656666755676e-01
    z[5,6,3]  R2291     4.2695918679237366e-01
    z[5,6,3]  R2292     7.6710104942321777e-02
    z[5,6,3]  R2293     -6.6808730363845825e-01
    z[5,6,3]  R2294     6.7740833759307861e-01
    z[5,6,3]  R2295     5.4901689291000366e-01
    z[5,6,3]  R2296     4.8863638192415237e-02
    z[5,6,3]  R2297     0.0647546723484993
    z[5,6,3]  R2298     3.7845405936241150e-01
    z[5,6,3]  R2299     2.2013500332832336e-01
    z[5,6,3]  R2300     4.9892172217369080e-01
    z[5,6,3]  R2301     4.7018688917160034e-01
    z[5,6,3]  R2302     0.410070538520813
    z[5,6,3]  R2303     -6.3829235732555389e-02
    z[5,6,3]  R2304     -1.7630833387374878e-01
    z[5,6,3]  R2305     4.5861587859690189e-03
    z[5,6,3]  R2306     -3.7304491270333529e-03
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R2201     -1
    z[5,6,4]  R2202     1
    z[5,6,4]  R2207     2.1972514688968658e-01
    z[5,6,4]  R2208     2.1765190362930298e-01
    z[5,6,4]  R2209     4.0931142866611481e-02
    z[5,6,4]  R2210     2.1041837334632874e-01
    z[5,6,4]  R2211     2.9918965697288513e-01
    z[5,6,4]  R2212     1.8380618095397949e-01
    z[5,6,4]  R2213     -3.5623095463961363e-03
    z[5,6,4]  R2214     -3.0863493680953979e-01
    z[5,6,4]  R2215     6.2925219535827637e-02
    z[5,6,4]  R2216     1.8007060885429382e-01
    z[5,6,4]  R2217     2.4389740824699402e-01
    z[5,6,4]  R2218     4.0803790092468262e-01
    z[5,6,4]  R2219     2.2968213260173798e-01
    z[5,6,4]  R2220     2.7753636240959167e-01
    z[5,6,4]  R2221     2.0736928284168243e-01
    z[5,6,4]  R2222     7.0982277393341064e-02
    z[5,6,4]  R2223     3.4071475267410278e-02
    z[5,6,4]  R2224     4.9427163600921631e-01
    z[5,6,4]  R2225     3.9076145738363266e-02
    z[5,6,4]  R2226     2.3187184333801270e-01
    z[5,6,4]  R2227     1.3753369450569153e-01
    z[5,6,4]  R2228     -4.3718385696411133e-01
    z[5,6,4]  R2229     -1.0097002238035202e-01
    z[5,6,4]  R2230     4.4751915335655212e-01
    z[5,6,4]  R2231     -5.9085196256637573e-01
    z[5,6,4]  R2232     2.4820290505886078e-02
    z[5,6,4]  R2233     2.6861295104026794e-01
    z[5,6,4]  R2234     1.6392327845096588e-01
    z[5,6,4]  R2235     4.8956326209008694e-03
    z[5,6,4]  R2236     2.2232106328010559e-01
    z[5,6,4]  R2237     4.0481418371200562e-01
    z[5,6,4]  R2238     3.9839386940002441e-01
    z[5,6,4]  R2239     -1.6639856994152069e-01
    z[5,6,4]  R2240     9.5849029719829559e-02
    z[5,6,4]  R2241     -4.1597512364387512e-01
    z[5,6,4]  R2242     6.7030824720859528e-02
    z[5,6,4]  R2243     3.7161818146705627e-01
    z[5,6,4]  R2244     -4.6529185026884079e-02
    z[5,6,4]  R2245     1.0484294593334198e-01
    z[5,6,4]  R2246     -1.6625995934009552e-01
    z[5,6,4]  R2247     -5.6820398569107056e-01
    z[5,6,4]  R2248     1.4509199559688568e-01
    z[5,6,4]  R2249     8.3327546715736389e-02
    z[5,6,4]  R2250     -1.7739489674568176e-01
    z[5,6,4]  R2251     2.8146801516413689e-02
    z[5,6,4]  R2252     -4.1535660624504089e-01
    z[5,6,4]  R2253     -1.7123721539974213e-01
    z[5,6,4]  R2254     -2.6038581132888794e-01
    z[5,6,4]  R2255     -7.7424091100692749e-01
    z[5,6,4]  R2256     1.5645760297775269e-01
    z[5,6,4]  R2257     -1.5829947590827942e-01
    z[5,6,4]  R2258     -2.3500072956085205e-01
    z[5,6,4]  R2259     -1.0128770023584366e-01
    z[5,6,4]  R2260     1.7276737093925476e-01
    z[5,6,4]  R2261     -6.6476412117481232e-02
    z[5,6,4]  R2262     2.5431957840919495e-01
    z[5,6,4]  R2263     4.5903018116950989e-01
    z[5,6,4]  R2264     2.9766404628753662e-01
    z[5,6,4]  R2265     -7.2542661428451538e-01
    z[5,6,4]  R2266     -3.3482801914215088e-01
    z[5,6,4]  R2267     -1.7309391498565674e-01
    z[5,6,4]  R2268     -2.6661536097526550e-01
    z[5,6,4]  R2269     -4.2092934250831604e-02
    z[5,6,4]  R2270     1.3217866420745850e-02
    z[5,6,4]  R2271     1.6486215591430664e-01
    z[5,6,4]  R2272     -4.3455618619918823e-01
    z[5,6,4]  R2273     9.9729880690574646e-02
    z[5,6,4]  R2274     3.0060487985610962e-01
    z[5,6,4]  R2275     3.0572512745857239e-01
    z[5,6,4]  R2276     -1.7164923250675201e-01
    z[5,6,4]  R2277     -2.9328927397727966e-01
    z[5,6,4]  R2278     -2.0201927423477173e-01
    z[5,6,4]  R2279     2.6930558681488037e-01
    z[5,6,4]  R2280     -2.7637007832527161e-01
    z[5,6,4]  R2281     -7.8308053314685822e-02
    z[5,6,4]  R2282     -3.3211063127964735e-03
    z[5,6,4]  R2283     -5.3320741653442383e-01
    z[5,6,4]  R2284     3.1884846091270447e-01
    z[5,6,4]  R2285     4.1901889443397522e-01
    z[5,6,4]  R2286     -1.1754878610372543e-01
    z[5,6,4]  R2287     -3.0466960743069649e-02
    z[5,6,4]  R2288     -3.0039094388484955e-02
    z[5,6,4]  R2289     2.0017163455486298e-01
    z[5,6,4]  R2290     -2.5645527243614197e-01
    z[5,6,4]  R2291     1.2100024521350861e-01
    z[5,6,4]  R2292     -5.6869655847549438e-01
    z[5,6,4]  R2293     -5.0403380393981934e-01
    z[5,6,4]  R2294     3.6500537395477295e-01
    z[5,6,4]  R2295     7.4338656663894653e-01
    z[5,6,4]  R2296     9.8925612866878510e-02
    z[5,6,4]  R2297     0.0436648391187191
    z[5,6,4]  R2298     -3.2527992129325867e-01
    z[5,6,4]  R2299     1.8321208655834198e-02
    z[5,6,4]  R2300     -7.7423781156539917e-02
    z[5,6,4]  R2301     4.7782388329505920e-01
    z[5,6,4]  R2302     7.5266337394714355e-01
    z[5,6,4]  R2303     4.6986865997314453e-01
    z[5,6,4]  R2304     4.0833294391632080e-01
    z[5,6,4]  R2305     6.0647827386856079e-01
    z[5,6,4]  R2306     -0.0374169796705246
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R2203     -1
    z[5,6,5]  R2204     1
    z[5,6,5]  R2207     2.1065457165241241e-01
    z[5,6,5]  R2208     -7.7650360763072968e-02
    z[5,6,5]  R2209     -4.2856833338737488e-01
    z[5,6,5]  R2210     1.0852876305580139e-01
    z[5,6,5]  R2211     -6.0421347618103027e-01
    z[5,6,5]  R2212     -3.2600095868110657e-01
    z[5,6,5]  R2213     0.366743803024292
    z[5,6,5]  R2214     -0.512775719165802
    z[5,6,5]  R2215     2.3371849954128265e-01
    z[5,6,5]  R2216     0.126520574092865
    z[5,6,5]  R2217     -5.0567211583256721e-03
    z[5,6,5]  R2218     2.1239832043647766e-01
    z[5,6,5]  R2219     -1.4609448611736298e-01
    z[5,6,5]  R2220     2.6021143794059753e-01
    z[5,6,5]  R2221     4.4713470339775085e-01
    z[5,6,5]  R2222     0.583529531955719
    z[5,6,5]  R2223     0.211939737200737
    z[5,6,5]  R2224     -2.4932612478733063e-01
    z[5,6,5]  R2225     -6.5293574333190918e-01
    z[5,6,5]  R2226     -2.3178772628307343e-01
    z[5,6,5]  R2227     2.1061576902866364e-02
    z[5,6,5]  R2228     2.0756955444812775e-01
    z[5,6,5]  R2229     1.8175454437732697e-01
    z[5,6,5]  R2230     7.4833102524280548e-02
    z[5,6,5]  R2231     -2.8705310821533203e-01
    z[5,6,5]  R2232     3.4221136569976807e-01
    z[5,6,5]  R2233     -3.9896681904792786e-01
    z[5,6,5]  R2234     -3.4685872495174408e-02
    z[5,6,5]  R2235     4.9487265944480896e-01
    z[5,6,5]  R2236     -1.7112414538860321e-01
    z[5,6,5]  R2237     4.6200446784496307e-02
    z[5,6,5]  R2238     -3.2395878434181213e-01
    z[5,6,5]  R2239     -1.9174182415008545e-01
    z[5,6,5]  R2240     1.7392399907112122e-01
    z[5,6,5]  R2241     8.3180814981460571e-02
    z[5,6,5]  R2242     -2.1449053287506104e-01
    z[5,6,5]  R2243     -0.0829191505908966
    z[5,6,5]  R2244     -1.7085450887680054e-01
    z[5,6,5]  R2245     -1.1061628162860870e-01
    z[5,6,5]  R2246     -2.7213558554649353e-01
    z[5,6,5]  R2247     3.2752615213394165e-01
    z[5,6,5]  R2248     -1.4564536511898041e-01
    z[5,6,5]  R2249     4.1196745634078979e-01
    z[5,6,5]  R2250     -1.7366786301136017e-01
    z[5,6,5]  R2251     2.5525094941258430e-02
    z[5,6,5]  R2252     6.2203764915466309e-01
    z[5,6,5]  R2253     -2.0899586379528046e-02
    z[5,6,5]  R2254     2.6637572050094604e-01
    z[5,6,5]  R2255     2.1918068826198578e-01
    z[5,6,5]  R2256     5.6586670875549316e-01
    z[5,6,5]  R2257     8.0578976869583130e-01
    z[5,6,5]  R2258     2.4711459875106812e-01
    z[5,6,5]  R2259     3.5473334789276123e-01
    z[5,6,5]  R2260     2.8026465326547623e-02
    z[5,6,5]  R2261     -3.0216455459594727e-01
    z[5,6,5]  R2262     5.7322263717651367e-01
    z[5,6,5]  R2263     -5.2819156646728516e-01
    z[5,6,5]  R2264     -5.5967479944229126e-01
    z[5,6,5]  R2265     3.3223131299018860e-01
    z[5,6,5]  R2266     -3.4338703751564026e-01
    z[5,6,5]  R2267     -5.8321750164031982e-01
    z[5,6,5]  R2268     9.8476916551589966e-02
    z[5,6,5]  R2269     5.2435958385467529e-01
    z[5,6,5]  R2270     6.7721761763095856e-02
    z[5,6,5]  R2271     -1.1546940356492996e-01
    z[5,6,5]  R2272     5.0735199451446533e-01
    z[5,6,5]  R2273     6.6885393857955933e-01
    z[5,6,5]  R2274     -4.3443045020103455e-01
    z[5,6,5]  R2275     1.5414324402809143e-01
    z[5,6,5]  R2276     -4.8195183277130127e-01
    z[5,6,5]  R2277     1.1835431680083275e-02
    z[5,6,5]  R2278     -4.5284175872802734e-01
    z[5,6,5]  R2279     -4.7734016180038452e-01
    z[5,6,5]  R2280     -2.7671229839324951e-01
    z[5,6,5]  R2281     -2.1821725368499756e-01
    z[5,6,5]  R2282     -3.1726114451885223e-02
    z[5,6,5]  R2283     -1.6012926399707794e-01
    z[5,6,5]  R2284     -1.9084455072879791e-01
    z[5,6,5]  R2285     6.0645347833633423e-01
    z[5,6,5]  R2286     3.8415738940238953e-01
    z[5,6,5]  R2287     1.4342612028121948e-01
    z[5,6,5]  R2288     2.0735330879688263e-02
    z[5,6,5]  R2289     -7.9888299107551575e-02
    z[5,6,5]  R2290     -2.3513761162757874e-01
    z[5,6,5]  R2291     5.2991282939910889e-01
    z[5,6,5]  R2292     1.6018478572368622e-01
    z[5,6,5]  R2293     3.8978680968284607e-01
    z[5,6,5]  R2294     2.6671606302261353e-01
    z[5,6,5]  R2295     -1.0598716139793396e-01
    z[5,6,5]  R2296     -3.7167635560035706e-01
    z[5,6,5]  R2297     2.3366133868694305e-01
    z[5,6,5]  R2298     4.1823066771030426e-02
    z[5,6,5]  R2299     1.7425103485584259e-01
    z[5,6,5]  R2300     0.68763667345047
    z[5,6,5]  R2301     8.5995271801948547e-02
    z[5,6,5]  R2302     -3.1345623731613159e-01
    z[5,6,5]  R2303     -1.0351142287254333e-01
    z[5,6,5]  R2304     -3.2312858104705811e-01
    z[5,6,5]  R2305     -2.4630669504404068e-02
    z[5,6,5]  R2306     -0.083391934633255
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R2205     -1
    z[5,6,6]  R2206     1
    z[5,6,6]  R2207     1.5206854045391083e-01
    z[5,6,6]  R2208     -0.0815151035785675
    z[5,6,6]  R2209     1.4401021599769592e-01
    z[5,6,6]  R2210     4.0101242065429688e-01
    z[5,6,6]  R2211     1.4734651148319244e-01
    z[5,6,6]  R2212     2.0967794954776764e-01
    z[5,6,6]  R2213     -1.6668763756752014e-01
    z[5,6,6]  R2214     -3.4199798107147217e-01
    z[5,6,6]  R2215     -6.0024131089448929e-02
    z[5,6,6]  R2216     -3.6240525543689728e-02
    z[5,6,6]  R2217     9.9132414907217026e-03
    z[5,6,6]  R2218     1.7179162800312042e-01
    z[5,6,6]  R2219     -2.2948840260505676e-01
    z[5,6,6]  R2220     2.8815174102783203e-01
    z[5,6,6]  R2221     4.2438122630119324e-01
    z[5,6,6]  R2222     -0.319205641746521
    z[5,6,6]  R2223     5.4390239715576172e-01
    z[5,6,6]  R2224     7.4569158256053925e-02
    z[5,6,6]  R2225     -1.5750029683113098e-01
    z[5,6,6]  R2226     0.297391414642334
    z[5,6,6]  R2227     -3.7479585409164429e-01
    z[5,6,6]  R2228     -1.8527930974960327e-01
    z[5,6,6]  R2229     -1.5197099745273590e-01
    z[5,6,6]  R2230     -3.8313020020723343e-02
    z[5,6,6]  R2231     -7.8656310215592384e-03
    z[5,6,6]  R2232     -4.1217800974845886e-01
    z[5,6,6]  R2233     2.5088205933570862e-01
    z[5,6,6]  R2234     -3.0493089556694031e-01
    z[5,6,6]  R2235     4.5366075634956360e-01
    z[5,6,6]  R2236     2.8514704108238220e-01
    z[5,6,6]  R2237     -3.6658096313476562e-01
    z[5,6,6]  R2238     1.7476810514926910e-01
    z[5,6,6]  R2239     2.0325586199760437e-01
    z[5,6,6]  R2240     6.5427523851394653e-01
    z[5,6,6]  R2241     6.1737453937530518e-01
    z[5,6,6]  R2242     -3.3815188799053431e-03
    z[5,6,6]  R2243     6.2483124434947968e-02
    z[5,6,6]  R2244     7.9416425433009863e-04
    z[5,6,6]  R2245     -8.6548924446105957e-02
    z[5,6,6]  R2246     2.0922663807868958e-01
    z[5,6,6]  R2247     -1.2703187763690948e-01
    z[5,6,6]  R2248     3.1705644726753235e-01
    z[5,6,6]  R2249     -3.3405613899230957e-01
    z[5,6,6]  R2250     -5.2935749292373657e-02
    z[5,6,6]  R2251     -2.4864497780799866e-01
    z[5,6,6]  R2252     -1.0304037481546402e-01
    z[5,6,6]  R2253     -0.586929202079773
    z[5,6,6]  R2254     -2.3855029046535492e-01
    z[5,6,6]  R2255     -1.2603218853473663e-01
    z[5,6,6]  R2256     3.6771920323371887e-01
    z[5,6,6]  R2257     -6.4364443533122540e-03
    z[5,6,6]  R2258     -1.0383991152048111e-01
    z[5,6,6]  R2259     4.2862436175346375e-01
    z[5,6,6]  R2260     -2.7937209606170654e-01
    z[5,6,6]  R2261     5.5898725986480713e-01
    z[5,6,6]  R2262     -9.4855777919292450e-02
    z[5,6,6]  R2263     -8.4704279899597168e-02
    z[5,6,6]  R2264     -0.243918776512146
    z[5,6,6]  R2265     -2.4282565340399742e-02
    z[5,6,6]  R2266     -1.2988287024199963e-02
    z[5,6,6]  R2267     -5.7427138090133667e-02
    z[5,6,6]  R2268     3.0082389712333679e-01
    z[5,6,6]  R2269     2.2318141162395477e-01
    z[5,6,6]  R2270     -3.6781916022300720e-01
    z[5,6,6]  R2271     3.0471837520599365e-01
    z[5,6,6]  R2272     1.0105646401643753e-01
    z[5,6,6]  R2273     1.0953678190708160e-01
    z[5,6,6]  R2274     2.3095515370368958e-01
    z[5,6,6]  R2275     3.1245455145835876e-01
    z[5,6,6]  R2276     -3.0622386932373047e-01
    z[5,6,6]  R2277     -1.3125742971897125e-01
    z[5,6,6]  R2278     -4.2128765583038330e-01
    z[5,6,6]  R2279     5.1761299371719360e-01
    z[5,6,6]  R2280     -1.3071468472480774e-01
    z[5,6,6]  R2281     -2.6159289479255676e-01
    z[5,6,6]  R2282     -3.6482807993888855e-01
    z[5,6,6]  R2283     -0.0368843711912632
    z[5,6,6]  R2284     1.3719749450683594e-01
    z[5,6,6]  R2285     -2.4601262062788010e-02
    z[5,6,6]  R2286     1.8489943444728851e-01
    z[5,6,6]  R2287     -5.3874599933624268e-01
    z[5,6,6]  R2288     2.9884710907936096e-01
    z[5,6,6]  R2289     -1.8286459147930145e-01
    z[5,6,6]  R2290     3.6133715510368347e-01
    z[5,6,6]  R2291     2.6935780048370361e-01
    z[5,6,6]  R2292     -2.9888576269149780e-01
    z[5,6,6]  R2293     9.8299145698547363e-02
    z[5,6,6]  R2294     2.4676294624805450e-01
    z[5,6,6]  R2295     2.3561794310808182e-02
    z[5,6,6]  R2296     5.3684383630752563e-02
    z[5,6,6]  R2297     0.258886456489563
    z[5,6,6]  R2298     4.2067226767539978e-01
    z[5,6,6]  R2299     -1.5836445987224579e-01
    z[5,6,6]  R2300     1.5851882100105286e-01
    z[5,6,6]  R2301     1.9886673986911774e-01
    z[5,6,6]  R2302     -2.9285359382629395e-01
    z[5,6,6]  R2303     2.5433811545372009e-01
    z[5,6,6]  R2304     8.0715097486972809e-02
    z[5,6,6]  R2305     1.7133943038061261e-03
    z[5,6,6]  R2306     -4.1331994533538818e-01
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2307     -1
    z[6,5,0]  R2308     1
    z[6,5,0]  R2321     -5.2197545766830444e-01
    z[6,5,0]  R2322     -1.6462321579456329e-01
    z[6,5,0]  R2323     -1.6076698899269104e-01
    z[6,5,0]  R2324     -3.8243892788887024e-01
    z[6,5,0]  R2325     -1.0251833498477936e-01
    z[6,5,0]  R2326     9.1036915779113770e-01
    z[6,5,0]  R2327     8.9052850008010864e-01
    z[6,5,0]  R2328     7.8248989582061768e-01
    z[6,5,0]  R2329     6.7351412773132324e-01
    z[6,5,0]  R2330     8.4913635253906250e-01
    z[6,5,0]  R2331     -6.7606532573699951e-01
    z[6,5,0]  R2332     -2.2798025608062744e-01
    z[6,5,0]  R2333     4.7485885024070740e-01
    z[6,5,0]  R2334     -7.7141416072845459e-01
    z[6,5,0]  R2335     -3.1777629256248474e-01
    z[6,5,0]  R2336     1.9203804433345795e-01
    z[6,5,0]  R2337     0.0636850968003273
    z[6,5,0]  R2338     -1.9665436446666718e-01
    z[6,5,0]  R2339     8.7079554796218872e-03
    z[6,5,0]  R2340     -2.1306616067886353e-01
    z[6,5,0]  R2341     -5.2853122353553772e-02
    z[6,5,0]  R2342     2.9397246241569519e-01
    z[6,5,0]  R2343     0.219319149851799
    z[6,5,0]  R2344     3.9431083202362061e-01
    z[6,5,0]  R2345     -5.3770607709884644e-01
    z[6,5,0]  R2346     -0.549445629119873
    z[6,5,0]  R2347     -4.8566406965255737e-01
    z[6,5,0]  R2348     -5.0109875202178955e-01
    z[6,5,0]  R2349     4.9492076039314270e-01
    z[6,5,0]  R2350     6.7345392704010010e-01
    z[6,5,0]  R2351     -6.5735715627670288e-01
    z[6,5,0]  R2352     7.0079976320266724e-01
    z[6,5,0]  R2353     6.0476040840148926e-01
    z[6,5,0]  R2354     0.443428635597229
    z[6,5,0]  R2355     1.5491665899753571e-01
    z[6,5,0]  R2356     4.6872106194496155e-01
    z[6,5,0]  R2357     3.4745091199874878e-01
    z[6,5,0]  R2358     6.8955379724502563e-01
    z[6,5,0]  R2359     -4.6143087744712830e-01
    z[6,5,0]  R2360     5.3690975904464722e-01
    z[6,5,0]  R2361     -7.0697891712188721e-01
    z[6,5,0]  R2362     1.1184625327587128e-01
    z[6,5,0]  R2363     -5.5554300546646118e-01
    z[6,5,0]  R2364     -8.5844683647155762e-01
    z[6,5,0]  R2365     2.3760078847408295e-01
    z[6,5,0]  R2366     3.0090087652206421e-01
    z[6,5,0]  R2367     5.4956245422363281e-01
    z[6,5,0]  R2368     -1.3233710825443268e-01
    z[6,5,0]  R2369     1.7166146636009216e-01
    z[6,5,0]  R2370     4.6342480182647705e-01
    z[6,5,0]  R2371     1.8599800765514374e-02
    z[6,5,0]  R2372     0.588977038860321
    z[6,5,0]  R2373     1.8756064772605896e-01
    z[6,5,0]  R2374     8.9630484580993652e-02
    z[6,5,0]  R2375     -1.5797346830368042e-01
    z[6,5,0]  R2376     6.1854708194732666e-01
    z[6,5,0]  R2377     3.3072385191917419e-01
    z[6,5,0]  R2378     -3.1328000128269196e-02
    z[6,5,0]  R2379     7.6487630605697632e-02
    z[6,5,0]  R2380     3.5481783747673035e-01
    z[6,5,0]  R2381     -5.1282113790512085e-01
    z[6,5,0]  R2382     -7.3605132102966309e-01
    z[6,5,0]  R2383     7.8114360570907593e-02
    z[6,5,0]  R2384     4.9200615286827087e-01
    z[6,5,0]  R2385     6.2441922724246979e-02
    z[6,5,0]  R2386     8.6419032886624336e-03
    z[6,5,0]  R2387     -3.9424884319305420e-01
    z[6,5,0]  R2388     -3.1746748089790344e-01
    z[6,5,0]  R2389     -4.0277183055877686e-01
    z[6,5,0]  R2390     3.1345593929290771e-01
    z[6,5,0]  R2391     6.3620336353778839e-02
    z[6,5,0]  R2392     3.7411540746688843e-01
    z[6,5,0]  R2393     0.309985488653183
    z[6,5,0]  R2394     2.2376090288162231e-01
    z[6,5,0]  R2395     1.9197373092174530e-01
    z[6,5,0]  R2396     5.7358872890472412e-01
    z[6,5,0]  R2397     -5.3023308515548706e-01
    z[6,5,0]  R2398     1.0566161572933197e-01
    z[6,5,0]  R2399     4.4696331024169922e-01
    z[6,5,0]  R2400     5.0492811203002930e-01
    z[6,5,0]  R2401     5.1830720901489258e-01
    z[6,5,0]  R2402     2.6020705699920654e-01
    z[6,5,0]  R2403     2.9869771003723145e-01
    z[6,5,0]  R2404     4.1372036933898926e-01
    z[6,5,0]  R2405     2.6807132363319397e-01
    z[6,5,0]  R2406     4.8167598247528076e-01
    z[6,5,0]  R2407     3.8679200410842896e-01
    z[6,5,0]  R2408     -6.5046213567256927e-02
    z[6,5,0]  R2409     -1.6289213672280312e-02
    z[6,5,0]  R2410     -4.6963214874267578e-01
    z[6,5,0]  R2411     7.6995509862899780e-01
    z[6,5,0]  R2412     4.8069155216217041e-01
    z[6,5,0]  R2413     -1.7894135415554047e-01
    z[6,5,0]  R2414     -1.6504043340682983e-01
    z[6,5,0]  R2415     -1.3117472827434540e-01
    z[6,5,0]  R2416     8.0199085175991058e-02
    z[6,5,0]  R2417     -0.0911993533372879
    z[6,5,0]  R2418     -1.5107788145542145e-01
    z[6,5,0]  R2419     -2.3619601130485535e-01
    z[6,5,0]  R2420     3.3547326922416687e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2309     -1
    z[6,5,1]  R2310     1
    z[6,5,1]  R2321     -3.2811793684959412e-01
    z[6,5,1]  R2322     -3.2577949762344360e-01
    z[6,5,1]  R2323     -2.3336495459079742e-01
    z[6,5,1]  R2324     -5.3701114654541016e-01
    z[6,5,1]  R2325     -4.4717708230018616e-01
    z[6,5,1]  R2326     0.0356532521545887
    z[6,5,1]  R2327     -1.8908347189426422e-01
    z[6,5,1]  R2328     2.1818211302161217e-02
    z[6,5,1]  R2329     -2.2090595960617065e-01
    z[6,5,1]  R2330     -1.9661180675029755e-01
    z[6,5,1]  R2331     -1.0527092218399048e-01
    z[6,5,1]  R2332     -6.9276988506317139e-01
    z[6,5,1]  R2333     3.3125367015600204e-02
    z[6,5,1]  R2334     1.1375380307435989e-01
    z[6,5,1]  R2335     -5.4619574546813965e-01
    z[6,5,1]  R2336     2.7200818061828613e-01
    z[6,5,1]  R2337     -7.2978264093399048e-01
    z[6,5,1]  R2338     -6.5107178688049316e-01
    z[6,5,1]  R2339     -1.5670144930481911e-02
    z[6,5,1]  R2340     -6.8149912357330322e-01
    z[6,5,1]  R2341     -1.3495287299156189e-01
    z[6,5,1]  R2342     -8.0948662757873535e-01
    z[6,5,1]  R2343     -7.0741057395935059e-01
    z[6,5,1]  R2344     -8.3427554368972778e-01
    z[6,5,1]  R2345     -1.5183715522289276e-01
    z[6,5,1]  R2346     -8.6842171847820282e-02
    z[6,5,1]  R2347     -1.7410792410373688e-01
    z[6,5,1]  R2348     -2.6296639442443848e-01
    z[6,5,1]  R2349     -2.4480876326560974e-01
    z[6,5,1]  R2350     -3.5698909312486649e-02
    z[6,5,1]  R2351     -2.2902448475360870e-01
    z[6,5,1]  R2352     3.6682537198066711e-01
    z[6,5,1]  R2353     8.2808077335357666e-02
    z[6,5,1]  R2354     -1.9834369421005249e-01
    z[6,5,1]  R2355     -8.6241155862808228e-01
    z[6,5,1]  R2356     1.6020224988460541e-01
    z[6,5,1]  R2357     -0.084617480635643
    z[6,5,1]  R2358     1.7293068766593933e-01
    z[6,5,1]  R2359     1.3825920224189758e-01
    z[6,5,1]  R2360     4.1986593604087830e-01
    z[6,5,1]  R2361     -5.4223853349685669e-01
    z[6,5,1]  R2362     -7.8635834157466888e-02
    z[6,5,1]  R2363     -3.4241041541099548e-01
    z[6,5,1]  R2364     1.8217015266418457e-01
    z[6,5,1]  R2365     -8.9206188917160034e-01
    z[6,5,1]  R2366     -7.3266369104385376e-01
    z[6,5,1]  R2367     3.1029051542282104e-01
    z[6,5,1]  R2368     -7.3007690906524658e-01
    z[6,5,1]  R2369     -6.3801366090774536e-01
    z[6,5,1]  R2370     -2.4115969240665436e-01
    z[6,5,1]  R2371     -2.7241986244916916e-02
    z[6,5,1]  R2372     1.2814275920391083e-01
    z[6,5,1]  R2373     -6.4726972579956055e-01
    z[6,5,1]  R2374     -8.4598058462142944e-01
    z[6,5,1]  R2375     -6.4722114801406860e-01
    z[6,5,1]  R2376     -3.2419040799140930e-01
    z[6,5,1]  R2377     5.7426650077104568e-02
    z[6,5,1]  R2378     -4.7238388657569885e-01
    z[6,5,1]  R2379     2.6329854130744934e-01
    z[6,5,1]  R2380     8.4887528419494629e-01
    z[6,5,1]  R2381     -9.0420819818973541e-02
    z[6,5,1]  R2382     -9.8409861326217651e-02
    z[6,5,1]  R2383     -8.7990230321884155e-01
    z[6,5,1]  R2384     1.8412467092275620e-02
    z[6,5,1]  R2385     -5.4374831914901733e-01
    z[6,5,1]  R2386     2.5878661870956421e-01
    z[6,5,1]  R2387     6.9609928131103516e-01
    z[6,5,1]  R2388     7.1002978086471558e-01
    z[6,5,1]  R2389     6.3367408514022827e-01
    z[6,5,1]  R2390     8.3913958072662354e-01
    z[6,5,1]  R2391     2.1285678446292877e-01
    z[6,5,1]  R2392     -2.0423457026481628e-01
    z[6,5,1]  R2393     1.9847913086414337e-01
    z[6,5,1]  R2394     -2.6865140534937382e-03
    z[6,5,1]  R2395     1.7888420820236206e-01
    z[6,5,1]  R2396     2.1807121112942696e-02
    z[6,5,1]  R2397     1.6930523561313748e-03
    z[6,5,1]  R2398     5.4403698444366455e-01
    z[6,5,1]  R2399     8.5394734144210815e-01
    z[6,5,1]  R2400     5.2414888143539429e-01
    z[6,5,1]  R2401     -4.4503325223922729e-01
    z[6,5,1]  R2402     -5.0822061300277710e-01
    z[6,5,1]  R2403     -2.2731699049472809e-02
    z[6,5,1]  R2404     1.3671897351741791e-01
    z[6,5,1]  R2405     6.8114958703517914e-02
    z[6,5,1]  R2406     -1.7794659733772278e-01
    z[6,5,1]  R2407     -4.3558841943740845e-01
    z[6,5,1]  R2408     -0.775583803653717
    z[6,5,1]  R2409     -6.7599415779113770e-01
    z[6,5,1]  R2410     -7.6074421405792236e-01
    z[6,5,1]  R2411     3.2440826296806335e-01
    z[6,5,1]  R2412     3.7659278512001038e-01
    z[6,5,1]  R2413     -2.2676189243793488e-01
    z[6,5,1]  R2414     -1.5134532749652863e-01
    z[6,5,1]  R2415     4.4075556099414825e-02
    z[6,5,1]  R2416     -7.0459681749343872e-01
    z[6,5,1]  R2417     -4.2690876871347427e-02
    z[6,5,1]  R2418     -7.1568185091018677e-01
    z[6,5,1]  R2419     -2.0943626761436462e-01
    z[6,5,1]  R2420     8.2062435150146484e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2311     -1
    z[6,5,2]  R2312     1
    z[6,5,2]  R2321     4.9247068166732788e-01
    z[6,5,2]  R2322     0.702812671661377
    z[6,5,2]  R2323     7.4170178174972534e-01
    z[6,5,2]  R2324     9.4406723976135254e-02
    z[6,5,2]  R2325     2.1973843872547150e-01
    z[6,5,2]  R2326     1.1154337227344513e-01
    z[6,5,2]  R2327     6.8829543888568878e-02
    z[6,5,2]  R2328     2.6227712631225586e-01
    z[6,5,2]  R2329     4.1704177856445312e-01
    z[6,5,2]  R2330     0.0787450522184372
    z[6,5,2]  R2331     -2.8018802404403687e-01
    z[6,5,2]  R2332     -1.8012490868568420e-01
    z[6,5,2]  R2333     5.7031378149986267e-02
    z[6,5,2]  R2334     -3.2692289352416992e-01
    z[6,5,2]  R2335     -2.9781109094619751e-01
    z[6,5,2]  R2336     1.8366594612598419e-01
    z[6,5,2]  R2337     -0.234488382935524
    z[6,5,2]  R2338     -2.7368941903114319e-01
    z[6,5,2]  R2339     -1.5721577405929565e-01
    z[6,5,2]  R2340     -7.8069724142551422e-02
    z[6,5,2]  R2341     4.0266913175582886e-01
    z[6,5,2]  R2342     3.4896153211593628e-01
    z[6,5,2]  R2343     6.5445274114608765e-02
    z[6,5,2]  R2344     -1.3660962879657745e-01
    z[6,5,2]  R2345     -2.1415871381759644e-01
    z[6,5,2]  R2346     -2.9749071598052979e-01
    z[6,5,2]  R2347     -3.1292143464088440e-01
    z[6,5,2]  R2348     -4.0407484769821167e-01
    z[6,5,2]  R2349     -2.4016296863555908e-01
    z[6,5,2]  R2350     -1.2989491224288940e-01
    z[6,5,2]  R2351     -3.2716563344001770e-01
    z[6,5,2]  R2352     2.5489461421966553e-01
    z[6,5,2]  R2353     -5.1718336343765259e-01
    z[6,5,2]  R2354     -6.7347055673599243e-01
    z[6,5,2]  R2355     -1.0436603426933289e-01
    z[6,5,2]  R2356     -3.2193490862846375e-01
    z[6,5,2]  R2357     -0.389515221118927
    z[6,5,2]  R2358     -0.0582720972597599
    z[6,5,2]  R2359     1.8238976597785950e-01
    z[6,5,2]  R2360     1.2936817109584808e-01
    z[6,5,2]  R2361     -1.4872124791145325e-01
    z[6,5,2]  R2362     2.0290501415729523e-01
    z[6,5,2]  R2363     -7.2191491723060608e-02
    z[6,5,2]  R2364     7.4390321969985962e-02
    z[6,5,2]  R2365     -8.6434474214911461e-03
    z[6,5,2]  R2366     -2.8759497404098511e-01
    z[6,5,2]  R2367     1.6714119911193848e-01
    z[6,5,2]  R2368     -5.2721619606018066e-01
    z[6,5,2]  R2369     -1.3237448036670685e-01
    z[6,5,2]  R2370     -6.3532269001007080e-01
    z[6,5,2]  R2371     4.0951010584831238e-01
    z[6,5,2]  R2372     -3.0285583809018135e-02
    z[6,5,2]  R2373     -2.8604707121849060e-01
    z[6,5,2]  R2374     -7.4590439908206463e-03
    z[6,5,2]  R2375     -7.6503805816173553e-02
    z[6,5,2]  R2376     -2.6078349351882935e-01
    z[6,5,2]  R2377     -1.5917524695396423e-01
    z[6,5,2]  R2378     -2.2744590044021606e-01
    z[6,5,2]  R2379     2.4288256466388702e-01
    z[6,5,2]  R2380     1.7767339944839478e-02
    z[6,5,2]  R2381     7.7531868219375610e-01
    z[6,5,2]  R2382     1.4420564472675323e-01
    z[6,5,2]  R2383     -0.339753121137619
    z[6,5,2]  R2384     -6.8565420806407928e-02
    z[6,5,2]  R2385     -4.5177906751632690e-01
    z[6,5,2]  R2386     1.1948562413454056e-01
    z[6,5,2]  R2387     -2.4445956945419312e-01
    z[6,5,2]  R2388     -2.9381096363067627e-01
    z[6,5,2]  R2389     -2.6035633683204651e-01
    z[6,5,2]  R2390     -1.3560469448566437e-01
    z[6,5,2]  R2391     0.376784086227417
    z[6,5,2]  R2392     3.3700317144393921e-01
    z[6,5,2]  R2393     0.441354900598526
    z[6,5,2]  R2394     -2.8998634219169617e-01
    z[6,5,2]  R2395     3.4507983922958374e-01
    z[6,5,2]  R2396     -4.0886303782463074e-01
    z[6,5,2]  R2397     4.8193186521530151e-01
    z[6,5,2]  R2398     3.1942182779312134e-01
    z[6,5,2]  R2399     -1.6876170411705971e-02
    z[6,5,2]  R2400     -3.4552210569381714e-01
    z[6,5,2]  R2401     2.6598111726343632e-03
    z[6,5,2]  R2402     -2.0064075291156769e-01
    z[6,5,2]  R2403     -8.2659468054771423e-02
    z[6,5,2]  R2404     3.5662662982940674e-01
    z[6,5,2]  R2405     -2.9090091586112976e-01
    z[6,5,2]  R2406     -2.6795518398284912e-01
    z[6,5,2]  R2407     4.9454793334007263e-01
    z[6,5,2]  R2408     4.2323939502239227e-02
    z[6,5,2]  R2409     2.4845432490110397e-02
    z[6,5,2]  R2410     -6.6998414695262909e-02
    z[6,5,2]  R2411     2.8627347946166992e-01
    z[6,5,2]  R2412     -2.3177672922611237e-01
    z[6,5,2]  R2413     2.3166167736053467e-01
    z[6,5,2]  R2414     2.1681115031242371e-01
    z[6,5,2]  R2415     -3.7851881235837936e-02
    z[6,5,2]  R2416     0.0953143835067749
    z[6,5,2]  R2417     4.1084265708923340e-01
    z[6,5,2]  R2418     3.4106969833374023e-01
    z[6,5,2]  R2419     5.6632423400878906e-01
    z[6,5,2]  R2420     -1.4988601207733154e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2313     -1
    z[6,5,3]  R2314     1
    z[6,5,3]  R2321     -2.7742058038711548e-01
    z[6,5,3]  R2322     -2.8037565946578979e-01
    z[6,5,3]  R2323     -5.1362150907516479e-01
    z[6,5,3]  R2324     -2.9821822047233582e-01
    z[6,5,3]  R2325     -4.2441949248313904e-01
    z[6,5,3]  R2326     3.2711493968963623e-01
    z[6,5,3]  R2327     1.3262446224689484e-01
    z[6,5,3]  R2328     5.3580540418624878e-01
    z[6,5,3]  R2329     5.4123628139495850e-01
    z[6,5,3]  R2330     2.9771557450294495e-01
    z[6,5,3]  R2331     -8.4155023097991943e-02
    z[6,5,3]  R2332     5.4116624593734741e-01
    z[6,5,3]  R2333     -6.9419378042221069e-01
    z[6,5,3]  R2334     4.6975526213645935e-01
    z[6,5,3]  R2335     6.6987228393554688e-01
    z[6,5,3]  R2336     -5.3416329622268677e-01
    z[6,5,3]  R2337     1.8474790453910828e-01
    z[6,5,3]  R2338     5.1658838987350464e-01
    z[6,5,3]  R2339     -5.5820119380950928e-01
    z[6,5,3]  R2340     6.4539723098278046e-02
    z[6,5,3]  R2341     -3.7743154168128967e-01
    z[6,5,3]  R2342     9.7281597554683685e-02
    z[6,5,3]  R2343     0.356892853975296
    z[6,5,3]  R2344     -1.4545871317386627e-01
    z[6,5,3]  R2345     4.8349192738533020e-01
    z[6,5,3]  R2346     4.4699767231941223e-01
    z[6,5,3]  R2347     3.7286359071731567e-01
    z[6,5,3]  R2348     2.3481087386608124e-01
    z[6,5,3]  R2349     -1.5259023755788803e-02
    z[6,5,3]  R2350     -5.4600322246551514e-01
    z[6,5,3]  R2351     -0.187056303024292
    z[6,5,3]  R2352     -3.7157908082008362e-01
    z[6,5,3]  R2353     1.8274098634719849e-01
    z[6,5,3]  R2354     4.1281515359878540e-01
    z[6,5,3]  R2355     -2.9662927985191345e-01
    z[6,5,3]  R2356     4.4106256961822510e-01
    z[6,5,3]  R2357     5.0108444690704346e-01
    z[6,5,3]  R2358     -3.9847409725189209e-01
    z[6,5,3]  R2359     7.2100222110748291e-01
    z[6,5,3]  R2360     -4.0396827459335327e-01
    z[6,5,3]  R2361     -2.8399446606636047e-01
    z[6,5,3]  R2362     -7.1887111663818359e-01
    z[6,5,3]  R2363     2.4760019034147263e-02
    z[6,5,3]  R2364     2.3305064439773560e-01
    z[6,5,3]  R2365     -1.5973395109176636e-01
    z[6,5,3]  R2366     3.9475908875465393e-01
    z[6,5,3]  R2367     -5.1230156421661377e-01
    z[6,5,3]  R2368     1.2086557596921921e-01
    z[6,5,3]  R2369     -4.4497188180685043e-02
    z[6,5,3]  R2370     3.5757806897163391e-01
    z[6,5,3]  R2371     -7.2074049711227417e-01
    z[6,5,3]  R2372     -7.3832678794860840e-01
    z[6,5,3]  R2373     6.1979812383651733e-01
    z[6,5,3]  R2374     1.5685656666755676e-01
    z[6,5,3]  R2375     4.2695918679237366e-01
    z[6,5,3]  R2376     7.6710104942321777e-02
    z[6,5,3]  R2377     -6.6808730363845825e-01
    z[6,5,3]  R2378     6.7740833759307861e-01
    z[6,5,3]  R2379     5.4901689291000366e-01
    z[6,5,3]  R2380     4.8863638192415237e-02
    z[6,5,3]  R2381     0.0647546723484993
    z[6,5,3]  R2382     3.7845405936241150e-01
    z[6,5,3]  R2383     2.2013500332832336e-01
    z[6,5,3]  R2384     4.9892172217369080e-01
    z[6,5,3]  R2385     4.7018688917160034e-01
    z[6,5,3]  R2386     0.410070538520813
    z[6,5,3]  R2387     -6.3829235732555389e-02
    z[6,5,3]  R2388     -1.7630833387374878e-01
    z[6,5,3]  R2389     4.5861587859690189e-03
    z[6,5,3]  R2390     -3.7304491270333529e-03
    z[6,5,3]  R2391     8.3240544795989990e-01
    z[6,5,3]  R2392     8.0293715000152588e-01
    z[6,5,3]  R2393     6.8090802431106567e-01
    z[6,5,3]  R2394     8.0558454990386963e-01
    z[6,5,3]  R2395     5.7945418357849121e-01
    z[6,5,3]  R2396     0.56508868932724
    z[6,5,3]  R2397     -5.6946748495101929e-01
    z[6,5,3]  R2398     -3.4010595083236694e-01
    z[6,5,3]  R2399     -9.2337392270565033e-02
    z[6,5,3]  R2400     -5.4880219697952271e-01
    z[6,5,3]  R2401     -6.8824869394302368e-01
    z[6,5,3]  R2402     -6.2659960985183716e-01
    z[6,5,3]  R2403     -8.8128763437271118e-01
    z[6,5,3]  R2404     -6.7467993497848511e-01
    z[6,5,3]  R2405     -6.4485955238342285e-01
    z[6,5,3]  R2406     -4.6592471003532410e-01
    z[6,5,3]  R2407     -0.272337943315506
    z[6,5,3]  R2408     -2.8358227014541626e-01
    z[6,5,3]  R2409     -2.9915022850036621e-01
    z[6,5,3]  R2410     1.7128208652138710e-02
    z[6,5,3]  R2411     2.4524433910846710e-01
    z[6,5,3]  R2412     5.5213207006454468e-01
    z[6,5,3]  R2413     -8.9250606298446655e-01
    z[6,5,3]  R2414     -8.3397108316421509e-01
    z[6,5,3]  R2415     0.740169107913971
    z[6,5,3]  R2416     -4.4767311215400696e-01
    z[6,5,3]  R2417     -7.2580933570861816e-01
    z[6,5,3]  R2418     -4.7706350684165955e-01
    z[6,5,3]  R2419     -0.359017938375473
    z[6,5,3]  R2420     1.7761951684951782e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2315     -1
    z[6,5,4]  R2316     1
    z[6,5,4]  R2321     4.0481418371200562e-01
    z[6,5,4]  R2322     3.9839386940002441e-01
    z[6,5,4]  R2323     -1.6639856994152069e-01
    z[6,5,4]  R2324     9.5849029719829559e-02
    z[6,5,4]  R2325     -4.1597512364387512e-01
    z[6,5,4]  R2326     6.7030824720859528e-02
    z[6,5,4]  R2327     3.7161818146705627e-01
    z[6,5,4]  R2328     -4.6529185026884079e-02
    z[6,5,4]  R2329     1.0484294593334198e-01
    z[6,5,4]  R2330     -1.6625995934009552e-01
    z[6,5,4]  R2331     -5.6820398569107056e-01
    z[6,5,4]  R2332     1.4509199559688568e-01
    z[6,5,4]  R2333     8.3327546715736389e-02
    z[6,5,4]  R2334     -1.7739489674568176e-01
    z[6,5,4]  R2335     2.8146801516413689e-02
    z[6,5,4]  R2336     -4.1535660624504089e-01
    z[6,5,4]  R2337     -1.7123721539974213e-01
    z[6,5,4]  R2338     -2.6038581132888794e-01
    z[6,5,4]  R2339     -7.7424091100692749e-01
    z[6,5,4]  R2340     1.5645760297775269e-01
    z[6,5,4]  R2341     -1.5829947590827942e-01
    z[6,5,4]  R2342     -2.3500072956085205e-01
    z[6,5,4]  R2343     -1.0128770023584366e-01
    z[6,5,4]  R2344     1.7276737093925476e-01
    z[6,5,4]  R2345     -6.6476412117481232e-02
    z[6,5,4]  R2346     2.5431957840919495e-01
    z[6,5,4]  R2347     4.5903018116950989e-01
    z[6,5,4]  R2348     2.9766404628753662e-01
    z[6,5,4]  R2349     -7.2542661428451538e-01
    z[6,5,4]  R2350     -3.3482801914215088e-01
    z[6,5,4]  R2351     -1.7309391498565674e-01
    z[6,5,4]  R2352     -2.6661536097526550e-01
    z[6,5,4]  R2353     -4.2092934250831604e-02
    z[6,5,4]  R2354     1.3217866420745850e-02
    z[6,5,4]  R2355     1.6486215591430664e-01
    z[6,5,4]  R2356     -4.3455618619918823e-01
    z[6,5,4]  R2357     9.9729880690574646e-02
    z[6,5,4]  R2358     3.0060487985610962e-01
    z[6,5,4]  R2359     3.0572512745857239e-01
    z[6,5,4]  R2360     -1.7164923250675201e-01
    z[6,5,4]  R2361     -2.9328927397727966e-01
    z[6,5,4]  R2362     -2.0201927423477173e-01
    z[6,5,4]  R2363     2.6930558681488037e-01
    z[6,5,4]  R2364     -2.7637007832527161e-01
    z[6,5,4]  R2365     -7.8308053314685822e-02
    z[6,5,4]  R2366     -3.3211063127964735e-03
    z[6,5,4]  R2367     -5.3320741653442383e-01
    z[6,5,4]  R2368     3.1884846091270447e-01
    z[6,5,4]  R2369     4.1901889443397522e-01
    z[6,5,4]  R2370     -1.1754878610372543e-01
    z[6,5,4]  R2371     -3.0466960743069649e-02
    z[6,5,4]  R2372     -3.0039094388484955e-02
    z[6,5,4]  R2373     2.0017163455486298e-01
    z[6,5,4]  R2374     -2.5645527243614197e-01
    z[6,5,4]  R2375     1.2100024521350861e-01
    z[6,5,4]  R2376     -5.6869655847549438e-01
    z[6,5,4]  R2377     -5.0403380393981934e-01
    z[6,5,4]  R2378     3.6500537395477295e-01
    z[6,5,4]  R2379     7.4338656663894653e-01
    z[6,5,4]  R2380     9.8925612866878510e-02
    z[6,5,4]  R2381     0.0436648391187191
    z[6,5,4]  R2382     -3.2527992129325867e-01
    z[6,5,4]  R2383     1.8321208655834198e-02
    z[6,5,4]  R2384     -7.7423781156539917e-02
    z[6,5,4]  R2385     4.7782388329505920e-01
    z[6,5,4]  R2386     7.5266337394714355e-01
    z[6,5,4]  R2387     4.6986865997314453e-01
    z[6,5,4]  R2388     4.0833294391632080e-01
    z[6,5,4]  R2389     6.0647827386856079e-01
    z[6,5,4]  R2390     -0.0374169796705246
    z[6,5,4]  R2391     2.1972514688968658e-01
    z[6,5,4]  R2392     2.1765190362930298e-01
    z[6,5,4]  R2393     4.0931142866611481e-02
    z[6,5,4]  R2394     2.1041837334632874e-01
    z[6,5,4]  R2395     2.9918965697288513e-01
    z[6,5,4]  R2396     1.8380618095397949e-01
    z[6,5,4]  R2397     -3.5623095463961363e-03
    z[6,5,4]  R2398     -3.0863493680953979e-01
    z[6,5,4]  R2399     6.2925219535827637e-02
    z[6,5,4]  R2400     1.8007060885429382e-01
    z[6,5,4]  R2401     2.4389740824699402e-01
    z[6,5,4]  R2402     4.0803790092468262e-01
    z[6,5,4]  R2403     2.2968213260173798e-01
    z[6,5,4]  R2404     2.7753636240959167e-01
    z[6,5,4]  R2405     2.0736928284168243e-01
    z[6,5,4]  R2406     7.0982277393341064e-02
    z[6,5,4]  R2407     3.4071475267410278e-02
    z[6,5,4]  R2408     4.9427163600921631e-01
    z[6,5,4]  R2409     3.9076145738363266e-02
    z[6,5,4]  R2410     2.3187184333801270e-01
    z[6,5,4]  R2411     1.3753369450569153e-01
    z[6,5,4]  R2412     -4.3718385696411133e-01
    z[6,5,4]  R2413     -1.0097002238035202e-01
    z[6,5,4]  R2414     4.4751915335655212e-01
    z[6,5,4]  R2415     -5.9085196256637573e-01
    z[6,5,4]  R2416     2.4820290505886078e-02
    z[6,5,4]  R2417     2.6861295104026794e-01
    z[6,5,4]  R2418     1.6392327845096588e-01
    z[6,5,4]  R2419     4.8956326209008694e-03
    z[6,5,4]  R2420     2.2232106328010559e-01
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2317     -1
    z[6,5,5]  R2318     1
    z[6,5,5]  R2321     4.6200446784496307e-02
    z[6,5,5]  R2322     -3.2395878434181213e-01
    z[6,5,5]  R2323     -1.9174182415008545e-01
    z[6,5,5]  R2324     1.7392399907112122e-01
    z[6,5,5]  R2325     8.3180814981460571e-02
    z[6,5,5]  R2326     -2.1449053287506104e-01
    z[6,5,5]  R2327     -0.0829191505908966
    z[6,5,5]  R2328     -1.7085450887680054e-01
    z[6,5,5]  R2329     -1.1061628162860870e-01
    z[6,5,5]  R2330     -2.7213558554649353e-01
    z[6,5,5]  R2331     3.2752615213394165e-01
    z[6,5,5]  R2332     -1.4564536511898041e-01
    z[6,5,5]  R2333     4.1196745634078979e-01
    z[6,5,5]  R2334     -1.7366786301136017e-01
    z[6,5,5]  R2335     2.5525094941258430e-02
    z[6,5,5]  R2336     6.2203764915466309e-01
    z[6,5,5]  R2337     -2.0899586379528046e-02
    z[6,5,5]  R2338     2.6637572050094604e-01
    z[6,5,5]  R2339     2.1918068826198578e-01
    z[6,5,5]  R2340     5.6586670875549316e-01
    z[6,5,5]  R2341     8.0578976869583130e-01
    z[6,5,5]  R2342     2.4711459875106812e-01
    z[6,5,5]  R2343     3.5473334789276123e-01
    z[6,5,5]  R2344     2.8026465326547623e-02
    z[6,5,5]  R2345     -3.0216455459594727e-01
    z[6,5,5]  R2346     5.7322263717651367e-01
    z[6,5,5]  R2347     -5.2819156646728516e-01
    z[6,5,5]  R2348     -5.5967479944229126e-01
    z[6,5,5]  R2349     3.3223131299018860e-01
    z[6,5,5]  R2350     -3.4338703751564026e-01
    z[6,5,5]  R2351     -5.8321750164031982e-01
    z[6,5,5]  R2352     9.8476916551589966e-02
    z[6,5,5]  R2353     5.2435958385467529e-01
    z[6,5,5]  R2354     6.7721761763095856e-02
    z[6,5,5]  R2355     -1.1546940356492996e-01
    z[6,5,5]  R2356     5.0735199451446533e-01
    z[6,5,5]  R2357     6.6885393857955933e-01
    z[6,5,5]  R2358     -4.3443045020103455e-01
    z[6,5,5]  R2359     1.5414324402809143e-01
    z[6,5,5]  R2360     -4.8195183277130127e-01
    z[6,5,5]  R2361     1.1835431680083275e-02
    z[6,5,5]  R2362     -4.5284175872802734e-01
    z[6,5,5]  R2363     -4.7734016180038452e-01
    z[6,5,5]  R2364     -2.7671229839324951e-01
    z[6,5,5]  R2365     -2.1821725368499756e-01
    z[6,5,5]  R2366     -3.1726114451885223e-02
    z[6,5,5]  R2367     -1.6012926399707794e-01
    z[6,5,5]  R2368     -1.9084455072879791e-01
    z[6,5,5]  R2369     6.0645347833633423e-01
    z[6,5,5]  R2370     3.8415738940238953e-01
    z[6,5,5]  R2371     1.4342612028121948e-01
    z[6,5,5]  R2372     2.0735330879688263e-02
    z[6,5,5]  R2373     -7.9888299107551575e-02
    z[6,5,5]  R2374     -2.3513761162757874e-01
    z[6,5,5]  R2375     5.2991282939910889e-01
    z[6,5,5]  R2376     1.6018478572368622e-01
    z[6,5,5]  R2377     3.8978680968284607e-01
    z[6,5,5]  R2378     2.6671606302261353e-01
    z[6,5,5]  R2379     -1.0598716139793396e-01
    z[6,5,5]  R2380     -3.7167635560035706e-01
    z[6,5,5]  R2381     2.3366133868694305e-01
    z[6,5,5]  R2382     4.1823066771030426e-02
    z[6,5,5]  R2383     1.7425103485584259e-01
    z[6,5,5]  R2384     0.68763667345047
    z[6,5,5]  R2385     8.5995271801948547e-02
    z[6,5,5]  R2386     -3.1345623731613159e-01
    z[6,5,5]  R2387     -1.0351142287254333e-01
    z[6,5,5]  R2388     -3.2312858104705811e-01
    z[6,5,5]  R2389     -2.4630669504404068e-02
    z[6,5,5]  R2390     -0.083391934633255
    z[6,5,5]  R2391     2.1065457165241241e-01
    z[6,5,5]  R2392     -7.7650360763072968e-02
    z[6,5,5]  R2393     -4.2856833338737488e-01
    z[6,5,5]  R2394     1.0852876305580139e-01
    z[6,5,5]  R2395     -6.0421347618103027e-01
    z[6,5,5]  R2396     -3.2600095868110657e-01
    z[6,5,5]  R2397     0.366743803024292
    z[6,5,5]  R2398     -0.512775719165802
    z[6,5,5]  R2399     2.3371849954128265e-01
    z[6,5,5]  R2400     0.126520574092865
    z[6,5,5]  R2401     -5.0567211583256721e-03
    z[6,5,5]  R2402     2.1239832043647766e-01
    z[6,5,5]  R2403     -1.4609448611736298e-01
    z[6,5,5]  R2404     2.6021143794059753e-01
    z[6,5,5]  R2405     4.4713470339775085e-01
    z[6,5,5]  R2406     0.583529531955719
    z[6,5,5]  R2407     0.211939737200737
    z[6,5,5]  R2408     -2.4932612478733063e-01
    z[6,5,5]  R2409     -6.5293574333190918e-01
    z[6,5,5]  R2410     -2.3178772628307343e-01
    z[6,5,5]  R2411     2.1061576902866364e-02
    z[6,5,5]  R2412     2.0756955444812775e-01
    z[6,5,5]  R2413     1.8175454437732697e-01
    z[6,5,5]  R2414     7.4833102524280548e-02
    z[6,5,5]  R2415     -2.8705310821533203e-01
    z[6,5,5]  R2416     3.4221136569976807e-01
    z[6,5,5]  R2417     -3.9896681904792786e-01
    z[6,5,5]  R2418     -3.4685872495174408e-02
    z[6,5,5]  R2419     4.9487265944480896e-01
    z[6,5,5]  R2420     -1.7112414538860321e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2319     -1
    z[6,5,6]  R2320     1
    z[6,5,6]  R2321     -3.6658096313476562e-01
    z[6,5,6]  R2322     1.7476810514926910e-01
    z[6,5,6]  R2323     2.0325586199760437e-01
    z[6,5,6]  R2324     6.5427523851394653e-01
    z[6,5,6]  R2325     6.1737453937530518e-01
    z[6,5,6]  R2326     -3.3815188799053431e-03
    z[6,5,6]  R2327     6.2483124434947968e-02
    z[6,5,6]  R2328     7.9416425433009863e-04
    z[6,5,6]  R2329     -8.6548924446105957e-02
    z[6,5,6]  R2330     2.0922663807868958e-01
    z[6,5,6]  R2331     -1.2703187763690948e-01
    z[6,5,6]  R2332     3.1705644726753235e-01
    z[6,5,6]  R2333     -3.3405613899230957e-01
    z[6,5,6]  R2334     -5.2935749292373657e-02
    z[6,5,6]  R2335     -2.4864497780799866e-01
    z[6,5,6]  R2336     -1.0304037481546402e-01
    z[6,5,6]  R2337     -0.586929202079773
    z[6,5,6]  R2338     -2.3855029046535492e-01
    z[6,5,6]  R2339     -1.2603218853473663e-01
    z[6,5,6]  R2340     3.6771920323371887e-01
    z[6,5,6]  R2341     -6.4364443533122540e-03
    z[6,5,6]  R2342     -1.0383991152048111e-01
    z[6,5,6]  R2343     4.2862436175346375e-01
    z[6,5,6]  R2344     -2.7937209606170654e-01
    z[6,5,6]  R2345     5.5898725986480713e-01
    z[6,5,6]  R2346     -9.4855777919292450e-02
    z[6,5,6]  R2347     -8.4704279899597168e-02
    z[6,5,6]  R2348     -0.243918776512146
    z[6,5,6]  R2349     -2.4282565340399742e-02
    z[6,5,6]  R2350     -1.2988287024199963e-02
    z[6,5,6]  R2351     -5.7427138090133667e-02
    z[6,5,6]  R2352     3.0082389712333679e-01
    z[6,5,6]  R2353     2.2318141162395477e-01
    z[6,5,6]  R2354     -3.6781916022300720e-01
    z[6,5,6]  R2355     3.0471837520599365e-01
    z[6,5,6]  R2356     1.0105646401643753e-01
    z[6,5,6]  R2357     1.0953678190708160e-01
    z[6,5,6]  R2358     2.3095515370368958e-01
    z[6,5,6]  R2359     3.1245455145835876e-01
    z[6,5,6]  R2360     -3.0622386932373047e-01
    z[6,5,6]  R2361     -1.3125742971897125e-01
    z[6,5,6]  R2362     -4.2128765583038330e-01
    z[6,5,6]  R2363     5.1761299371719360e-01
    z[6,5,6]  R2364     -1.3071468472480774e-01
    z[6,5,6]  R2365     -2.6159289479255676e-01
    z[6,5,6]  R2366     -3.6482807993888855e-01
    z[6,5,6]  R2367     -0.0368843711912632
    z[6,5,6]  R2368     1.3719749450683594e-01
    z[6,5,6]  R2369     -2.4601262062788010e-02
    z[6,5,6]  R2370     1.8489943444728851e-01
    z[6,5,6]  R2371     -5.3874599933624268e-01
    z[6,5,6]  R2372     2.9884710907936096e-01
    z[6,5,6]  R2373     -1.8286459147930145e-01
    z[6,5,6]  R2374     3.6133715510368347e-01
    z[6,5,6]  R2375     2.6935780048370361e-01
    z[6,5,6]  R2376     -2.9888576269149780e-01
    z[6,5,6]  R2377     9.8299145698547363e-02
    z[6,5,6]  R2378     2.4676294624805450e-01
    z[6,5,6]  R2379     2.3561794310808182e-02
    z[6,5,6]  R2380     5.3684383630752563e-02
    z[6,5,6]  R2381     0.258886456489563
    z[6,5,6]  R2382     4.2067226767539978e-01
    z[6,5,6]  R2383     -1.5836445987224579e-01
    z[6,5,6]  R2384     1.5851882100105286e-01
    z[6,5,6]  R2385     1.9886673986911774e-01
    z[6,5,6]  R2386     -2.9285359382629395e-01
    z[6,5,6]  R2387     2.5433811545372009e-01
    z[6,5,6]  R2388     8.0715097486972809e-02
    z[6,5,6]  R2389     1.7133943038061261e-03
    z[6,5,6]  R2390     -4.1331994533538818e-01
    z[6,5,6]  R2391     1.5206854045391083e-01
    z[6,5,6]  R2392     -0.0815151035785675
    z[6,5,6]  R2393     1.4401021599769592e-01
    z[6,5,6]  R2394     4.0101242065429688e-01
    z[6,5,6]  R2395     1.4734651148319244e-01
    z[6,5,6]  R2396     2.0967794954776764e-01
    z[6,5,6]  R2397     -1.6668763756752014e-01
    z[6,5,6]  R2398     -3.4199798107147217e-01
    z[6,5,6]  R2399     -6.0024131089448929e-02
    z[6,5,6]  R2400     -3.6240525543689728e-02
    z[6,5,6]  R2401     9.9132414907217026e-03
    z[6,5,6]  R2402     1.7179162800312042e-01
    z[6,5,6]  R2403     -2.2948840260505676e-01
    z[6,5,6]  R2404     2.8815174102783203e-01
    z[6,5,6]  R2405     4.2438122630119324e-01
    z[6,5,6]  R2406     -0.319205641746521
    z[6,5,6]  R2407     5.4390239715576172e-01
    z[6,5,6]  R2408     7.4569158256053925e-02
    z[6,5,6]  R2409     -1.5750029683113098e-01
    z[6,5,6]  R2410     0.297391414642334
    z[6,5,6]  R2411     -3.7479585409164429e-01
    z[6,5,6]  R2412     -1.8527930974960327e-01
    z[6,5,6]  R2413     -1.5197099745273590e-01
    z[6,5,6]  R2414     -3.8313020020723343e-02
    z[6,5,6]  R2415     -7.8656310215592384e-03
    z[6,5,6]  R2416     -4.1217800974845886e-01
    z[6,5,6]  R2417     2.5088205933570862e-01
    z[6,5,6]  R2418     -3.0493089556694031e-01
    z[6,5,6]  R2419     4.5366075634956360e-01
    z[6,5,6]  R2420     2.8514704108238220e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R63       1
    RHS1      R64       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,3]
 BV BND1      phi[3,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[7,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,3]
 BV BND1      phi[3,1]
 BV BND1      phi[1,4]
 BV BND1      phi[4,1]
 BV BND1      phi[2,5]
 BV BND1      phi[5,2]
 BV BND1      phi[2,6]
 BV BND1      phi[6,2]
 BV BND1      phi[2,8]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[7,3]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,8]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,3,0]
 FR BND1      z[0,3,1]
 FR BND1      z[0,3,2]
 FR BND1      z[0,3,3]
 FR BND1      z[0,3,4]
 FR BND1      z[0,3,5]
 FR BND1      z[0,3,6]
 FR BND1      z[3,0,0]
 FR BND1      z[3,0,1]
 FR BND1      z[3,0,2]
 FR BND1      z[3,0,3]
 FR BND1      z[3,0,4]
 FR BND1      z[3,0,5]
 FR BND1      z[3,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,3,0]
 FR BND1      z[1,3,1]
 FR BND1      z[1,3,2]
 FR BND1      z[1,3,3]
 FR BND1      z[1,3,4]
 FR BND1      z[1,3,5]
 FR BND1      z[1,3,6]
 FR BND1      z[3,1,0]
 FR BND1      z[3,1,1]
 FR BND1      z[3,1,2]
 FR BND1      z[3,1,3]
 FR BND1      z[3,1,4]
 FR BND1      z[3,1,5]
 FR BND1      z[3,1,6]
 FR BND1      z[1,4,0]
 FR BND1      z[1,4,1]
 FR BND1      z[1,4,2]
 FR BND1      z[1,4,3]
 FR BND1      z[1,4,4]
 FR BND1      z[1,4,5]
 FR BND1      z[1,4,6]
 FR BND1      z[4,1,0]
 FR BND1      z[4,1,1]
 FR BND1      z[4,1,2]
 FR BND1      z[4,1,3]
 FR BND1      z[4,1,4]
 FR BND1      z[4,1,5]
 FR BND1      z[4,1,6]
 FR BND1      z[2,5,0]
 FR BND1      z[2,5,1]
 FR BND1      z[2,5,2]
 FR BND1      z[2,5,3]
 FR BND1      z[2,5,4]
 FR BND1      z[2,5,5]
 FR BND1      z[2,5,6]
 FR BND1      z[5,2,0]
 FR BND1      z[5,2,1]
 FR BND1      z[5,2,2]
 FR BND1      z[5,2,3]
 FR BND1      z[5,2,4]
 FR BND1      z[5,2,5]
 FR BND1      z[5,2,6]
 FR BND1      z[2,6,0]
 FR BND1      z[2,6,1]
 FR BND1      z[2,6,2]
 FR BND1      z[2,6,3]
 FR BND1      z[2,6,4]
 FR BND1      z[2,6,5]
 FR BND1      z[2,6,6]
 FR BND1      z[6,2,0]
 FR BND1      z[6,2,1]
 FR BND1      z[6,2,2]
 FR BND1      z[6,2,3]
 FR BND1      z[6,2,4]
 FR BND1      z[6,2,5]
 FR BND1      z[6,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
ENDATA
