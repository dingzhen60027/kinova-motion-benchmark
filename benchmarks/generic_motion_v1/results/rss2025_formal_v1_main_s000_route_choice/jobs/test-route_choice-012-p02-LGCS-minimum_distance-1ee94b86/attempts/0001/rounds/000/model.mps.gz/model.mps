NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 L  R73     
 E  R74     
 E  R75     
 E  R76     
 E  R77     
 E  R78     
 E  R79     
 E  R80     
 E  R81     
 L  R82     
 E  R83     
 E  R84     
 E  R85     
 E  R86     
 E  R87     
 E  R88     
 E  R89     
 E  R90     
 E  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  R2670   
 L  R2671   
 L  R2672   
 L  R2673   
 L  R2674   
 L  R2675   
 L  R2676   
 L  R2677   
 L  R2678   
 L  R2679   
 L  R2680   
 L  R2681   
 L  R2682   
 L  R2683   
 L  R2684   
 L  R2685   
 L  R2686   
 L  R2687   
 L  R2688   
 L  R2689   
 L  R2690   
 L  R2691   
 L  R2692   
 L  R2693   
 L  R2694   
 L  R2695   
 L  R2696   
 L  R2697   
 L  R2698   
 L  R2699   
 L  R2700   
 L  R2701   
 L  R2702   
 L  R2703   
 L  R2704   
 L  R2705   
 L  R2706   
 L  R2707   
 L  R2708   
 L  R2709   
 L  R2710   
 L  R2711   
 L  R2712   
 L  R2713   
 L  R2714   
 L  R2715   
 L  R2716   
 L  R2717   
 L  R2718   
 L  R2719   
 L  R2720   
 L  R2721   
 L  R2722   
 L  R2723   
 L  R2724   
 L  R2725   
 L  R2726   
 L  R2727   
 L  R2728   
 L  R2729   
 L  R2730   
 L  R2731   
 L  R2732   
 L  R2733   
 L  R2734   
 L  R2735   
 L  R2736   
 L  R2737   
 L  R2738   
 L  R2739   
 L  R2740   
 L  R2741   
 L  R2742   
 L  R2743   
 L  R2744   
 L  R2745   
 L  R2746   
 L  R2747   
 L  R2748   
 L  R2749   
 L  R2750   
 L  R2751   
 L  R2752   
 L  R2753   
 L  R2754   
 L  R2755   
 L  R2756   
 L  R2757   
 L  R2758   
 L  R2759   
 L  R2760   
 L  R2761   
 L  R2762   
 L  R2763   
 L  R2764   
 L  R2765   
 L  R2766   
 L  R2767   
 L  R2768   
 L  R2769   
 L  R2770   
 L  R2771   
 L  R2772   
 L  R2773   
 L  R2774   
 L  R2775   
 L  R2776   
 L  R2777   
 L  R2778   
 L  R2779   
 L  R2780   
 L  R2781   
 L  R2782   
 L  R2783   
 L  R2784   
 L  R2785   
 L  R2786   
 L  R2787   
 L  R2788   
 L  R2789   
 L  R2790   
 L  R2791   
 L  R2792   
 L  R2793   
 L  R2794   
 L  R2795   
 L  R2796   
 L  R2797   
 L  R2798   
 L  R2799   
 L  R2800   
 L  R2801   
 L  R2802   
 L  R2803   
 L  R2804   
 L  R2805   
 L  R2806   
 L  R2807   
 L  R2808   
 L  R2809   
 L  R2810   
 L  R2811   
 L  R2812   
 L  R2813   
 L  R2814   
 L  R2815   
 L  R2816   
 L  R2817   
 L  R2818   
 L  R2819   
 L  R2820   
 L  R2821   
 L  R2822   
 L  R2823   
 L  R2824   
 L  R2825   
 L  R2826   
 L  R2827   
 L  R2828   
 L  R2829   
 L  R2830   
 L  R2831   
 L  R2832   
 L  R2833   
 L  R2834   
 L  R2835   
 L  R2836   
 L  R2837   
 L  R2838   
 L  R2839   
 L  R2840   
 L  R2841   
 L  R2842   
 L  R2843   
 L  R2844   
 L  R2845   
 L  R2846   
 L  R2847   
 L  R2848   
 L  R2849   
 L  R2850   
 L  R2851   
 L  R2852   
 L  R2853   
 L  R2854   
 L  R2855   
 L  R2856   
 L  R2857   
 L  R2858   
 L  R2859   
 L  R2860   
 L  R2861   
 L  R2862   
 L  R2863   
 L  R2864   
 L  R2865   
 L  R2866   
 L  R2867   
 L  R2868   
 L  R2869   
 L  R2870   
 L  R2871   
 L  R2872   
 L  R2873   
 L  R2874   
 L  R2875   
 L  R2876   
 L  R2877   
 L  R2878   
 L  R2879   
 L  R2880   
 L  R2881   
 L  R2882   
 L  R2883   
 L  R2884   
 L  R2885   
 L  R2886   
 L  R2887   
 L  R2888   
 L  R2889   
 L  R2890   
 L  R2891   
 L  R2892   
 L  R2893   
 L  R2894   
 L  R2895   
 L  R2896   
 L  R2897   
 L  R2898   
 L  R2899   
 L  R2900   
 L  R2901   
 L  R2902   
 L  R2903   
 L  R2904   
 L  R2905   
 L  R2906   
 L  R2907   
 L  R2908   
 L  R2909   
 L  R2910   
 L  R2911   
 L  R2912   
 L  R2913   
 L  R2914   
 L  R2915   
 L  R2916   
 L  R2917   
 L  R2918   
 L  R2919   
 L  R2920   
 L  R2921   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
 L  qc8     
 L  qc9     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R92       -3.0999999046325684e+00
    phi[0,1]  R93       -3.0999999046325684e+00
    phi[0,1]  R94       -2.2400000095367432e+00
    phi[0,1]  R95       -2.2400000095367432e+00
    phi[0,1]  R96       -3.0999999046325684e+00
    phi[0,1]  R97       -3.0999999046325684e+00
    phi[0,1]  R98       -2.5699999332427979e+00
    phi[0,1]  R99       -2.5699999332427979e+00
    phi[0,1]  R100      -3.0999999046325684e+00
    phi[0,1]  R101      -3.0999999046325684e+00
    phi[0,1]  R102      -2.0899999141693115e+00
    phi[0,1]  R103      -2.0899999141693115e+00
    phi[0,1]  R104      -3.0999999046325684e+00
    phi[0,1]  R105      -3.0999999046325684e+00
    phi[0,1]  R106      1.0797257423400879e+00
    phi[0,1]  R107      6.3344722986221313e-01
    phi[0,1]  R108      5.9080737829208374e-01
    phi[0,1]  R109      -1.5650317072868347e-01
    phi[0,1]  R110      -2.6829770207405090e-01
    phi[0,1]  R111      5.1237565279006958e-01
    phi[0,1]  R112      -3.7068206071853638e-01
    phi[0,1]  R113      4.3123243376612663e-03
    phi[0,1]  R114      -1.6819505691528320e+00
    phi[0,1]  R115      -4.1993622779846191e+00
    phi[0,1]  R116      8.8205826282501221e-01
    phi[0,1]  R117      -1.2949604988098145e+00
    phi[0,1]  R118      -1.8349642753601074e+00
    phi[0,1]  R119      -2.9036455154418945e+00
    phi[0,1]  R120      -2.7917604446411133e+00
    phi[0,1]  R121      -2.5091719627380371e+00
    phi[0,1]  R122      -2.5441958904266357e+00
    phi[0,1]  R123      -2.4597651958465576e+00
    phi[0,1]  R124      -2.64709210395813
    phi[0,1]  R125      -1.7853454351425171e+00
    phi[0,1]  R126      -2.5117757320404053e+00
    phi[0,1]  R127      -2.1580712795257568e+00
    phi[0,1]  R128      -2.2173295021057129e+00
    phi[0,1]  R129      -1.9359955787658691e+00
    phi[0,1]  R130      -2.5564358234405518e+00
    phi[0,1]  R131      -2.7794890403747559e+00
    phi[0,1]  R132      -2.77880597114563
    phi[0,1]  R133      -2.8069519996643066e+00
    phi[0,1]  R134      -1.8117659091949463e+00
    phi[0,1]  R135      -1.7249106168746948e+00
    phi[0,1]  R136      7.2112566232681274e-01
    phi[0,1]  R137      5.5092120170593262e-01
    phi[0,1]  R138      -1.0089961290359497e+00
    phi[0,1]  R139      -4.0616638958454132e-02
    phi[0,1]  R140      -1.2341398000717163e+00
    phi[0,1]  R141      -3.9332154393196106e-01
    phi[0,1]  R142      -3.2326176762580872e-01
    phi[0,1]  R143      -9.6449935436248779e-01
    phi[0,1]  R144      -0.416527658700943
    phi[0,1]  R145      -1.1485550403594971e+00
    phi[0,1]  R146      -1.3766080141067505e+00
    phi[0,1]  R147      -1.8996930122375488e+00
    phi[0,1]  R148      -1.0420613288879395e+00
    phi[0,1]  R149      -2.2673461437225342e+00
    phi[0,1]  R150      -1.7994740009307861e+00
    phi[0,1]  R151      0.1059565320611
    phi[0,1]  R152      -1.8579677343368530e+00
    phi[0,1]  R153      -1.6181721687316895e+00
    phi[0,1]  R154      2.8924499638378620e-03
    phi[0,1]  R155      -1.5287053585052490e+00
    phi[0,1]  R156      -2.0701112747192383e+00
    phi[0,1]  R157      3.4832516312599182e-01
    phi[0,1]  R158      6.8583297729492188e-01
    phi[0,1]  R159      8.6141246557235718e-01
    phi[0,1]  R160      9.0437716245651245e-01
    phi[0,1]  R161      -1.8925645351409912e+00
    phi[0,1]  R162      -1.7445719242095947e+00
    phi[0,1]  R163      -1.9598306417465210e+00
    phi[0,1]  R164      -2.2204709053039551e+00
    phi[0,1]  R165      -1.8093652725219727e+00
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R166      -3.0999999046325684e+00
    phi[1,0]  R167      -3.0999999046325684e+00
    phi[1,0]  R168      -2.2400000095367432e+00
    phi[1,0]  R169      -2.2400000095367432e+00
    phi[1,0]  R170      -3.0999999046325684e+00
    phi[1,0]  R171      -3.0999999046325684e+00
    phi[1,0]  R172      -2.5699999332427979e+00
    phi[1,0]  R173      -2.5699999332427979e+00
    phi[1,0]  R174      -3.0999999046325684e+00
    phi[1,0]  R175      -3.0999999046325684e+00
    phi[1,0]  R176      -2.0899999141693115e+00
    phi[1,0]  R177      -2.0899999141693115e+00
    phi[1,0]  R178      -3.0999999046325684e+00
    phi[1,0]  R179      -3.0999999046325684e+00
    phi[1,0]  R180      7.2112566232681274e-01
    phi[1,0]  R181      5.5092120170593262e-01
    phi[1,0]  R182      -1.0089961290359497e+00
    phi[1,0]  R183      -4.0616638958454132e-02
    phi[1,0]  R184      -1.2341398000717163e+00
    phi[1,0]  R185      -3.9332154393196106e-01
    phi[1,0]  R186      -3.2326176762580872e-01
    phi[1,0]  R187      -9.6449935436248779e-01
    phi[1,0]  R188      -0.416527658700943
    phi[1,0]  R189      -1.1485550403594971e+00
    phi[1,0]  R190      -1.3766080141067505e+00
    phi[1,0]  R191      -1.8996930122375488e+00
    phi[1,0]  R192      -1.0420613288879395e+00
    phi[1,0]  R193      -2.2673461437225342e+00
    phi[1,0]  R194      -1.7994740009307861e+00
    phi[1,0]  R195      0.1059565320611
    phi[1,0]  R196      -1.8579677343368530e+00
    phi[1,0]  R197      -1.6181721687316895e+00
    phi[1,0]  R198      2.8924499638378620e-03
    phi[1,0]  R199      -1.5287053585052490e+00
    phi[1,0]  R200      -2.0701112747192383e+00
    phi[1,0]  R201      3.4832516312599182e-01
    phi[1,0]  R202      6.8583297729492188e-01
    phi[1,0]  R203      8.6141246557235718e-01
    phi[1,0]  R204      9.0437716245651245e-01
    phi[1,0]  R205      -1.8925645351409912e+00
    phi[1,0]  R206      -1.7445719242095947e+00
    phi[1,0]  R207      -1.9598306417465210e+00
    phi[1,0]  R208      -2.2204709053039551e+00
    phi[1,0]  R209      -1.8093652725219727e+00
    phi[1,0]  R210      1.0797257423400879e+00
    phi[1,0]  R211      6.3344722986221313e-01
    phi[1,0]  R212      5.9080737829208374e-01
    phi[1,0]  R213      -1.5650317072868347e-01
    phi[1,0]  R214      -2.6829770207405090e-01
    phi[1,0]  R215      5.1237565279006958e-01
    phi[1,0]  R216      -3.7068206071853638e-01
    phi[1,0]  R217      4.3123243376612663e-03
    phi[1,0]  R218      -1.6819505691528320e+00
    phi[1,0]  R219      -4.1993622779846191e+00
    phi[1,0]  R220      8.8205826282501221e-01
    phi[1,0]  R221      -1.2949604988098145e+00
    phi[1,0]  R222      -1.8349642753601074e+00
    phi[1,0]  R223      -2.9036455154418945e+00
    phi[1,0]  R224      -2.7917604446411133e+00
    phi[1,0]  R225      -2.5091719627380371e+00
    phi[1,0]  R226      -2.5441958904266357e+00
    phi[1,0]  R227      -2.4597651958465576e+00
    phi[1,0]  R228      -2.64709210395813
    phi[1,0]  R229      -1.7853454351425171e+00
    phi[1,0]  R230      -2.5117757320404053e+00
    phi[1,0]  R231      -2.1580712795257568e+00
    phi[1,0]  R232      -2.2173295021057129e+00
    phi[1,0]  R233      -1.9359955787658691e+00
    phi[1,0]  R234      -2.5564358234405518e+00
    phi[1,0]  R235      -2.7794890403747559e+00
    phi[1,0]  R236      -2.77880597114563
    phi[1,0]  R237      -2.8069519996643066e+00
    phi[1,0]  R238      -1.8117659091949463e+00
    phi[1,0]  R239      -1.7249106168746948e+00
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R240      -3.0999999046325684e+00
    phi[0,4]  R241      -3.0999999046325684e+00
    phi[0,4]  R242      -2.2400000095367432e+00
    phi[0,4]  R243      -2.2400000095367432e+00
    phi[0,4]  R244      -3.0999999046325684e+00
    phi[0,4]  R245      -3.0999999046325684e+00
    phi[0,4]  R246      -2.5699999332427979e+00
    phi[0,4]  R247      -2.5699999332427979e+00
    phi[0,4]  R248      -3.0999999046325684e+00
    phi[0,4]  R249      -3.0999999046325684e+00
    phi[0,4]  R250      -2.0899999141693115e+00
    phi[0,4]  R251      -2.0899999141693115e+00
    phi[0,4]  R252      -3.0999999046325684e+00
    phi[0,4]  R253      -3.0999999046325684e+00
    phi[0,4]  R254      1.0797257423400879e+00
    phi[0,4]  R255      6.3344722986221313e-01
    phi[0,4]  R256      5.9080737829208374e-01
    phi[0,4]  R257      -1.5650317072868347e-01
    phi[0,4]  R258      -2.6829770207405090e-01
    phi[0,4]  R259      5.1237565279006958e-01
    phi[0,4]  R260      -3.7068206071853638e-01
    phi[0,4]  R261      4.3123243376612663e-03
    phi[0,4]  R262      -1.6819505691528320e+00
    phi[0,4]  R263      -4.1993622779846191e+00
    phi[0,4]  R264      8.8205826282501221e-01
    phi[0,4]  R265      -1.2949604988098145e+00
    phi[0,4]  R266      -1.8349642753601074e+00
    phi[0,4]  R267      -2.9036455154418945e+00
    phi[0,4]  R268      -2.7917604446411133e+00
    phi[0,4]  R269      -2.5091719627380371e+00
    phi[0,4]  R270      -2.5441958904266357e+00
    phi[0,4]  R271      -2.4597651958465576e+00
    phi[0,4]  R272      -2.64709210395813
    phi[0,4]  R273      -1.7853454351425171e+00
    phi[0,4]  R274      -2.5117757320404053e+00
    phi[0,4]  R275      -2.1580712795257568e+00
    phi[0,4]  R276      -2.2173295021057129e+00
    phi[0,4]  R277      -1.9359955787658691e+00
    phi[0,4]  R278      -2.5564358234405518e+00
    phi[0,4]  R279      -2.7794890403747559e+00
    phi[0,4]  R280      -2.77880597114563
    phi[0,4]  R281      -2.8069519996643066e+00
    phi[0,4]  R282      -1.8117659091949463e+00
    phi[0,4]  R283      -1.7249106168746948e+00
    phi[0,4]  R284      2.1510252952575684e+00
    phi[0,4]  R285      2.3087661266326904e+00
    phi[0,4]  R286      2.2344079017639160e+00
    phi[0,4]  R287      2.8701600432395935e-01
    phi[0,4]  R288      1.0162551403045654e+00
    phi[0,4]  R289      3.2342278957366943e-01
    phi[0,4]  R290      2.3311109542846680e+00
    phi[0,4]  R291      1.8067256212234497e+00
    phi[0,4]  R292      6.3994789123535156e-01
    phi[0,4]  R293      -1.1829671859741211e+00
    phi[0,4]  R294      -1.8085280656814575e+00
    phi[0,4]  R295      2.3737442493438721e-01
    phi[0,4]  R296      -5.9441798925399780e-01
    phi[0,4]  R297      -3.0016872882843018e+00
    phi[0,4]  R298      -2.3230199813842773e+00
    phi[0,4]  R299      -3.0763864517211914e+00
    phi[0,4]  R300      -1.8486472368240356e+00
    phi[0,4]  R301      -1.5698767900466919e+00
    phi[0,4]  R302      -2.3516178131103516e+00
    phi[0,4]  R303      -1.8654581308364868e+00
    phi[0,4]  R304      -2.8284637928009033e+00
    phi[0,4]  R305      -5.9689563512802124e-01
    phi[0,4]  R306      -2.7439630031585693e-01
    phi[0,4]  R307      -1.0399266481399536e+00
    phi[0,4]  R308      -8.6047953367233276e-01
    phi[0,4]  R309      4.3197140097618103e-01
    phi[0,4]  R310      -5.1382535696029663e-01
    phi[0,4]  R311      -0.839576005935669
    phi[0,4]  R312      -1.6632450819015503e+00
    phi[0,4]  R313      -0.605674684047699
    phi[0,4]  R314      -1.0773233175277710e+00
    phi[0,4]  R315      -2.6992473602294922e+00
    phi[0,4]  R316      -3.5784826278686523e+00
    phi[0,4]  R317      -3.5639214515686035e+00
    phi[0,4]  R318      -1.6140263080596924e+00
    phi[0,4]  R319      -2.8677439689636230e+00
    phi[0,4]  R320      -1.7228866815567017e+00
    phi[0,4]  R321      6.8052403628826141e-02
    phi[0,4]  R322      -3.3058822154998779e+00
    phi[0,4]  R323      -1.5509938001632690e+00
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R324      -3.0999999046325684e+00
    phi[4,0]  R325      -3.0999999046325684e+00
    phi[4,0]  R326      -2.2400000095367432e+00
    phi[4,0]  R327      -2.2400000095367432e+00
    phi[4,0]  R328      -3.0999999046325684e+00
    phi[4,0]  R329      -3.0999999046325684e+00
    phi[4,0]  R330      -2.5699999332427979e+00
    phi[4,0]  R331      -2.5699999332427979e+00
    phi[4,0]  R332      -3.0999999046325684e+00
    phi[4,0]  R333      -3.0999999046325684e+00
    phi[4,0]  R334      -2.0899999141693115e+00
    phi[4,0]  R335      -2.0899999141693115e+00
    phi[4,0]  R336      -3.0999999046325684e+00
    phi[4,0]  R337      -3.0999999046325684e+00
    phi[4,0]  R338      2.1510252952575684e+00
    phi[4,0]  R339      2.3087661266326904e+00
    phi[4,0]  R340      2.2344079017639160e+00
    phi[4,0]  R341      2.8701600432395935e-01
    phi[4,0]  R342      1.0162551403045654e+00
    phi[4,0]  R343      3.2342278957366943e-01
    phi[4,0]  R344      2.3311109542846680e+00
    phi[4,0]  R345      1.8067256212234497e+00
    phi[4,0]  R346      6.3994789123535156e-01
    phi[4,0]  R347      -1.1829671859741211e+00
    phi[4,0]  R348      -1.8085280656814575e+00
    phi[4,0]  R349      2.3737442493438721e-01
    phi[4,0]  R350      -5.9441798925399780e-01
    phi[4,0]  R351      -3.0016872882843018e+00
    phi[4,0]  R352      -2.3230199813842773e+00
    phi[4,0]  R353      -3.0763864517211914e+00
    phi[4,0]  R354      -1.8486472368240356e+00
    phi[4,0]  R355      -1.5698767900466919e+00
    phi[4,0]  R356      -2.3516178131103516e+00
    phi[4,0]  R357      -1.8654581308364868e+00
    phi[4,0]  R358      -2.8284637928009033e+00
    phi[4,0]  R359      -5.9689563512802124e-01
    phi[4,0]  R360      -2.7439630031585693e-01
    phi[4,0]  R361      -1.0399266481399536e+00
    phi[4,0]  R362      -8.6047953367233276e-01
    phi[4,0]  R363      4.3197140097618103e-01
    phi[4,0]  R364      -5.1382535696029663e-01
    phi[4,0]  R365      -0.839576005935669
    phi[4,0]  R366      -1.6632450819015503e+00
    phi[4,0]  R367      -0.605674684047699
    phi[4,0]  R368      -1.0773233175277710e+00
    phi[4,0]  R369      -2.6992473602294922e+00
    phi[4,0]  R370      -3.5784826278686523e+00
    phi[4,0]  R371      -3.5639214515686035e+00
    phi[4,0]  R372      -1.6140263080596924e+00
    phi[4,0]  R373      -2.8677439689636230e+00
    phi[4,0]  R374      -1.7228866815567017e+00
    phi[4,0]  R375      6.8052403628826141e-02
    phi[4,0]  R376      -3.3058822154998779e+00
    phi[4,0]  R377      -1.5509938001632690e+00
    phi[4,0]  R378      1.0797257423400879e+00
    phi[4,0]  R379      6.3344722986221313e-01
    phi[4,0]  R380      5.9080737829208374e-01
    phi[4,0]  R381      -1.5650317072868347e-01
    phi[4,0]  R382      -2.6829770207405090e-01
    phi[4,0]  R383      5.1237565279006958e-01
    phi[4,0]  R384      -3.7068206071853638e-01
    phi[4,0]  R385      4.3123243376612663e-03
    phi[4,0]  R386      -1.6819505691528320e+00
    phi[4,0]  R387      -4.1993622779846191e+00
    phi[4,0]  R388      8.8205826282501221e-01
    phi[4,0]  R389      -1.2949604988098145e+00
    phi[4,0]  R390      -1.8349642753601074e+00
    phi[4,0]  R391      -2.9036455154418945e+00
    phi[4,0]  R392      -2.7917604446411133e+00
    phi[4,0]  R393      -2.5091719627380371e+00
    phi[4,0]  R394      -2.5441958904266357e+00
    phi[4,0]  R395      -2.4597651958465576e+00
    phi[4,0]  R396      -2.64709210395813
    phi[4,0]  R397      -1.7853454351425171e+00
    phi[4,0]  R398      -2.5117757320404053e+00
    phi[4,0]  R399      -2.1580712795257568e+00
    phi[4,0]  R400      -2.2173295021057129e+00
    phi[4,0]  R401      -1.9359955787658691e+00
    phi[4,0]  R402      -2.5564358234405518e+00
    phi[4,0]  R403      -2.7794890403747559e+00
    phi[4,0]  R404      -2.77880597114563
    phi[4,0]  R405      -2.8069519996643066e+00
    phi[4,0]  R406      -1.8117659091949463e+00
    phi[4,0]  R407      -1.7249106168746948e+00
    phi[0,5]  R0        1
    phi[0,5]  R1        1
    phi[0,5]  R45       -1
    phi[0,5]  R408      -3.0999999046325684e+00
    phi[0,5]  R409      -3.0999999046325684e+00
    phi[0,5]  R410      -2.2400000095367432e+00
    phi[0,5]  R411      -2.2400000095367432e+00
    phi[0,5]  R412      -3.0999999046325684e+00
    phi[0,5]  R413      -3.0999999046325684e+00
    phi[0,5]  R414      -2.5699999332427979e+00
    phi[0,5]  R415      -2.5699999332427979e+00
    phi[0,5]  R416      -3.0999999046325684e+00
    phi[0,5]  R417      -3.0999999046325684e+00
    phi[0,5]  R418      -2.0899999141693115e+00
    phi[0,5]  R419      -2.0899999141693115e+00
    phi[0,5]  R420      -3.0999999046325684e+00
    phi[0,5]  R421      -3.0999999046325684e+00
    phi[0,5]  R422      1.0797257423400879e+00
    phi[0,5]  R423      6.3344722986221313e-01
    phi[0,5]  R424      5.9080737829208374e-01
    phi[0,5]  R425      -1.5650317072868347e-01
    phi[0,5]  R426      -2.6829770207405090e-01
    phi[0,5]  R427      5.1237565279006958e-01
    phi[0,5]  R428      -3.7068206071853638e-01
    phi[0,5]  R429      4.3123243376612663e-03
    phi[0,5]  R430      -1.6819505691528320e+00
    phi[0,5]  R431      -4.1993622779846191e+00
    phi[0,5]  R432      8.8205826282501221e-01
    phi[0,5]  R433      -1.2949604988098145e+00
    phi[0,5]  R434      -1.8349642753601074e+00
    phi[0,5]  R435      -2.9036455154418945e+00
    phi[0,5]  R436      -2.7917604446411133e+00
    phi[0,5]  R437      -2.5091719627380371e+00
    phi[0,5]  R438      -2.5441958904266357e+00
    phi[0,5]  R439      -2.4597651958465576e+00
    phi[0,5]  R440      -2.64709210395813
    phi[0,5]  R441      -1.7853454351425171e+00
    phi[0,5]  R442      -2.5117757320404053e+00
    phi[0,5]  R443      -2.1580712795257568e+00
    phi[0,5]  R444      -2.2173295021057129e+00
    phi[0,5]  R445      -1.9359955787658691e+00
    phi[0,5]  R446      -2.5564358234405518e+00
    phi[0,5]  R447      -2.7794890403747559e+00
    phi[0,5]  R448      -2.77880597114563
    phi[0,5]  R449      -2.8069519996643066e+00
    phi[0,5]  R450      -1.8117659091949463e+00
    phi[0,5]  R451      -1.7249106168746948e+00
    phi[0,5]  R452      2.6721320152282715e+00
    phi[0,5]  R453      1.0542553663253784e+00
    phi[0,5]  R454      -4.3973669409751892e-02
    phi[0,5]  R455      -0.872677743434906
    phi[0,5]  R456      2.6223728433251381e-02
    phi[0,5]  R457      -5.9467816352844238e-01
    phi[0,5]  R458      5.4028433561325073e-01
    phi[0,5]  R459      -8.8324892520904541e-01
    phi[0,5]  R460      -7.8803908824920654e-01
    phi[0,5]  R461      -7.7637147903442383e-01
    phi[0,5]  R462      -1.0009427070617676e+00
    phi[0,5]  R463      -1.0461862087249756e+00
    phi[0,5]  R464      -0.0729677602648735
    phi[0,5]  R465      3.6292821168899536e-01
    phi[0,5]  R466      -2.3945782184600830e+00
    phi[0,5]  R467      -5.5078589916229248e-01
    phi[0,5]  R468      -2.7807874679565430e+00
    phi[0,5]  R469      -1.2810522317886353e+00
    phi[0,5]  R470      -1.0457861423492432e+00
    phi[0,5]  R471      -1.1360139846801758e+00
    phi[0,5]  R472      -1.5627011060714722e+00
    phi[0,5]  R473      -1.6247810125350952e+00
    phi[0,5]  R474      -1.6776736974716187e+00
    phi[0,5]  R475      -0.384996235370636
    phi[0,5]  R476      -2.3753604292869568e-01
    phi[0,5]  R477      -2.3957488536834717e+00
    phi[0,5]  R478      -1.5398020744323730e+00
    phi[5,0]  R0        -1
    phi[5,0]  R45       1
    phi[5,0]  R46       1
    phi[5,0]  R479      -3.0999999046325684e+00
    phi[5,0]  R480      -3.0999999046325684e+00
    phi[5,0]  R481      -2.2400000095367432e+00
    phi[5,0]  R482      -2.2400000095367432e+00
    phi[5,0]  R483      -3.0999999046325684e+00
    phi[5,0]  R484      -3.0999999046325684e+00
    phi[5,0]  R485      -2.5699999332427979e+00
    phi[5,0]  R486      -2.5699999332427979e+00
    phi[5,0]  R487      -3.0999999046325684e+00
    phi[5,0]  R488      -3.0999999046325684e+00
    phi[5,0]  R489      -2.0899999141693115e+00
    phi[5,0]  R490      -2.0899999141693115e+00
    phi[5,0]  R491      -3.0999999046325684e+00
    phi[5,0]  R492      -3.0999999046325684e+00
    phi[5,0]  R493      2.6721320152282715e+00
    phi[5,0]  R494      1.0542553663253784e+00
    phi[5,0]  R495      -4.3973669409751892e-02
    phi[5,0]  R496      -0.872677743434906
    phi[5,0]  R497      2.6223728433251381e-02
    phi[5,0]  R498      -5.9467816352844238e-01
    phi[5,0]  R499      5.4028433561325073e-01
    phi[5,0]  R500      -8.8324892520904541e-01
    phi[5,0]  R501      -7.8803908824920654e-01
    phi[5,0]  R502      -7.7637147903442383e-01
    phi[5,0]  R503      -1.0009427070617676e+00
    phi[5,0]  R504      -1.0461862087249756e+00
    phi[5,0]  R505      -0.0729677602648735
    phi[5,0]  R506      3.6292821168899536e-01
    phi[5,0]  R507      -2.3945782184600830e+00
    phi[5,0]  R508      -5.5078589916229248e-01
    phi[5,0]  R509      -2.7807874679565430e+00
    phi[5,0]  R510      -1.2810522317886353e+00
    phi[5,0]  R511      -1.0457861423492432e+00
    phi[5,0]  R512      -1.1360139846801758e+00
    phi[5,0]  R513      -1.5627011060714722e+00
    phi[5,0]  R514      -1.6247810125350952e+00
    phi[5,0]  R515      -1.6776736974716187e+00
    phi[5,0]  R516      -0.384996235370636
    phi[5,0]  R517      -2.3753604292869568e-01
    phi[5,0]  R518      -2.3957488536834717e+00
    phi[5,0]  R519      -1.5398020744323730e+00
    phi[5,0]  R520      1.0797257423400879e+00
    phi[5,0]  R521      6.3344722986221313e-01
    phi[5,0]  R522      5.9080737829208374e-01
    phi[5,0]  R523      -1.5650317072868347e-01
    phi[5,0]  R524      -2.6829770207405090e-01
    phi[5,0]  R525      5.1237565279006958e-01
    phi[5,0]  R526      -3.7068206071853638e-01
    phi[5,0]  R527      4.3123243376612663e-03
    phi[5,0]  R528      -1.6819505691528320e+00
    phi[5,0]  R529      -4.1993622779846191e+00
    phi[5,0]  R530      8.8205826282501221e-01
    phi[5,0]  R531      -1.2949604988098145e+00
    phi[5,0]  R532      -1.8349642753601074e+00
    phi[5,0]  R533      -2.9036455154418945e+00
    phi[5,0]  R534      -2.7917604446411133e+00
    phi[5,0]  R535      -2.5091719627380371e+00
    phi[5,0]  R536      -2.5441958904266357e+00
    phi[5,0]  R537      -2.4597651958465576e+00
    phi[5,0]  R538      -2.64709210395813
    phi[5,0]  R539      -1.7853454351425171e+00
    phi[5,0]  R540      -2.5117757320404053e+00
    phi[5,0]  R541      -2.1580712795257568e+00
    phi[5,0]  R542      -2.2173295021057129e+00
    phi[5,0]  R543      -1.9359955787658691e+00
    phi[5,0]  R544      -2.5564358234405518e+00
    phi[5,0]  R545      -2.7794890403747559e+00
    phi[5,0]  R546      -2.77880597114563
    phi[5,0]  R547      -2.8069519996643066e+00
    phi[5,0]  R548      -1.8117659091949463e+00
    phi[5,0]  R549      -1.7249106168746948e+00
    phi[10,0]  R0        -1
    phi[10,0]  R2        1.3583139362724279e+00
    phi[10,0]  R3        -6.2928327239970128e-01
    phi[10,0]  R4        2.5603210539907253e+00
    phi[10,0]  R5        1.6105845164723394e+00
    phi[10,0]  R6        -4.2848871274391742e-01
    phi[10,0]  R7        -1.7433816108660944e+00
    phi[10,0]  R8        1.0768066673331931e+00
    phi[10,0]  R90       1
    phi[10,0]  R550      -4.4583138409049958e+00
    phi[10,0]  R551      -1.7416859683601404e+00
    phi[10,0]  R552      -1.6107167371370419e+00
    phi[10,0]  R553      -2.8692832819364442e+00
    phi[10,0]  R554      -5.6603209586232932e+00
    phi[10,0]  R555      -5.3967885064184307e-01
    phi[10,0]  R556      -4.1805844497151377e+00
    phi[10,0]  R557      -9.5941541677045850e-01
    phi[10,0]  R558      -2.6715111918886509e+00
    phi[10,0]  R559      -3.5284886173764858e+00
    phi[10,0]  R560      -3.4661830330321708e-01
    phi[10,0]  R561      -3.8333815250354060e+00
    phi[10,0]  R562      -4.1768065719657610e+00
    phi[10,0]  R563      -2.0231932372993753e+00
    phi[10,0]  R564      -1.6376266146700402e-05
    phi[10,0]  R565      -2.2358792184618448e-02
    phi[10,0]  R566      -2.6178596581759916e-02
    phi[10,0]  R567      -2.4887840008681286e-01
    phi[10,0]  R568      -2.0114143524402581e+00
    phi[10,0]  R569      -1.2718463796748667e+00
    phi[10,0]  R570      -1.0827635974072090e+00
    phi[10,0]  R571      -2.2136269090891512e+00
    phi[10,0]  R572      -1.7598717898423892e+00
    phi[10,0]  R573      -2.2223795538390911e+00
    phi[10,0]  R574      -5.6843360836102308e-02
    phi[10,0]  R575      -6.2164057417433805e-02
    phi[10,0]  R576      -2.0032770650530609e+00
    phi[10,0]  R577      -1.0533616806327808e+00
    phi[10,0]  R578      -7.3909182448726263e-01
    phi[10,0]  R579      -7.4039218525336437e-01
    phi[10,0]  R580      -0.746394981456302
    phi[10,0]  R581      -7.5428267404738025e-01
    phi[10,0]  R582      -0.756762180382538
    phi[10,0]  R583      -7.9184789734444561e-01
    phi[10,0]  R584      -0.722649227806285
    phi[10,0]  R585      -8.3954131063722315e-01
    phi[10,0]  R586      -8.4890530461574842e-01
    phi[10,0]  R587      -8.5391697649712039e-01
    phi[10,0]  R588      -0.869236570959147
    phi[10,0]  R589      -8.7151561188375015e-01
    phi[10,0]  R590      -0.87908502310144
    phi[10,0]  R591      -8.8199621976091613e-01
    phi[10,0]  R592      -8.8990528365892207e-01
    phi[10,0]  R593      -9.0250437306956721e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R594      -3.0999999046325684e+00
    phi[1,2]  R595      -3.0999999046325684e+00
    phi[1,2]  R596      -2.2400000095367432e+00
    phi[1,2]  R597      -2.2400000095367432e+00
    phi[1,2]  R598      -3.0999999046325684e+00
    phi[1,2]  R599      -3.0999999046325684e+00
    phi[1,2]  R600      -2.5699999332427979e+00
    phi[1,2]  R601      -2.5699999332427979e+00
    phi[1,2]  R602      -3.0999999046325684e+00
    phi[1,2]  R603      -3.0999999046325684e+00
    phi[1,2]  R604      -2.0899999141693115e+00
    phi[1,2]  R605      -2.0899999141693115e+00
    phi[1,2]  R606      -3.0999999046325684e+00
    phi[1,2]  R607      -3.0999999046325684e+00
    phi[1,2]  R608      7.2112566232681274e-01
    phi[1,2]  R609      5.5092120170593262e-01
    phi[1,2]  R610      -1.0089961290359497e+00
    phi[1,2]  R611      -4.0616638958454132e-02
    phi[1,2]  R612      -1.2341398000717163e+00
    phi[1,2]  R613      -3.9332154393196106e-01
    phi[1,2]  R614      -3.2326176762580872e-01
    phi[1,2]  R615      -9.6449935436248779e-01
    phi[1,2]  R616      -0.416527658700943
    phi[1,2]  R617      -1.1485550403594971e+00
    phi[1,2]  R618      -1.3766080141067505e+00
    phi[1,2]  R619      -1.8996930122375488e+00
    phi[1,2]  R620      -1.0420613288879395e+00
    phi[1,2]  R621      -2.2673461437225342e+00
    phi[1,2]  R622      -1.7994740009307861e+00
    phi[1,2]  R623      0.1059565320611
    phi[1,2]  R624      -1.8579677343368530e+00
    phi[1,2]  R625      -1.6181721687316895e+00
    phi[1,2]  R626      2.8924499638378620e-03
    phi[1,2]  R627      -1.5287053585052490e+00
    phi[1,2]  R628      -2.0701112747192383e+00
    phi[1,2]  R629      3.4832516312599182e-01
    phi[1,2]  R630      6.8583297729492188e-01
    phi[1,2]  R631      8.6141246557235718e-01
    phi[1,2]  R632      9.0437716245651245e-01
    phi[1,2]  R633      -1.8925645351409912e+00
    phi[1,2]  R634      -1.7445719242095947e+00
    phi[1,2]  R635      -1.9598306417465210e+00
    phi[1,2]  R636      -2.2204709053039551e+00
    phi[1,2]  R637      -1.8093652725219727e+00
    phi[1,2]  R638      -1.0539060831069946e+00
    phi[1,2]  R639      1.0972964763641357e+00
    phi[1,2]  R640      -5.1101803779602051e-01
    phi[1,2]  R641      0.704910397529602
    phi[1,2]  R642      1.2428203821182251e+00
    phi[1,2]  R643      -9.7667455673217773e-01
    phi[1,2]  R644      2.3235200345516205e-01
    phi[1,2]  R645      -3.0786231160163879e-01
    phi[1,2]  R646      -0.526995837688446
    phi[1,2]  R647      3.6671388149261475e-01
    phi[1,2]  R648      -1.1494132280349731e+00
    phi[1,2]  R649      -1.3793284893035889e+00
    phi[1,2]  R650      1.8774956464767456e-01
    phi[1,2]  R651      -1.3378996849060059e+00
    phi[1,2]  R652      5.2432018518447876e-01
    phi[1,2]  R653      -3.2511866092681885e-01
    phi[1,2]  R654      -3.5755831003189087e-01
    phi[1,2]  R655      -1.3752126693725586e+00
    phi[1,2]  R656      -0.793183445930481
    phi[1,2]  R657      -2.0157096385955811e+00
    phi[1,2]  R658      -9.4874471426010132e-01
    phi[1,2]  R659      -8.9863473176956177e-01
    phi[1,2]  R660      -1.1757690906524658e+00
    phi[1,2]  R661      -1.0567289590835571e+00
    phi[1,2]  R662      -1.1576052904129028e+00
    phi[1,2]  R663      1.8765942752361298e-01
    phi[1,2]  R664      3.8110092282295227e-02
    phi[1,2]  R665      2.0229671150445938e-02
    phi[1,2]  R666      -1.1624418497085571e+00
    phi[1,2]  R667      -6.9024479389190674e-01
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R668      -3.0999999046325684e+00
    phi[2,1]  R669      -3.0999999046325684e+00
    phi[2,1]  R670      -2.2400000095367432e+00
    phi[2,1]  R671      -2.2400000095367432e+00
    phi[2,1]  R672      -3.0999999046325684e+00
    phi[2,1]  R673      -3.0999999046325684e+00
    phi[2,1]  R674      -2.5699999332427979e+00
    phi[2,1]  R675      -2.5699999332427979e+00
    phi[2,1]  R676      -3.0999999046325684e+00
    phi[2,1]  R677      -3.0999999046325684e+00
    phi[2,1]  R678      -2.0899999141693115e+00
    phi[2,1]  R679      -2.0899999141693115e+00
    phi[2,1]  R680      -3.0999999046325684e+00
    phi[2,1]  R681      -3.0999999046325684e+00
    phi[2,1]  R682      -1.0539060831069946e+00
    phi[2,1]  R683      1.0972964763641357e+00
    phi[2,1]  R684      -5.1101803779602051e-01
    phi[2,1]  R685      0.704910397529602
    phi[2,1]  R686      1.2428203821182251e+00
    phi[2,1]  R687      -9.7667455673217773e-01
    phi[2,1]  R688      2.3235200345516205e-01
    phi[2,1]  R689      -3.0786231160163879e-01
    phi[2,1]  R690      -0.526995837688446
    phi[2,1]  R691      3.6671388149261475e-01
    phi[2,1]  R692      -1.1494132280349731e+00
    phi[2,1]  R693      -1.3793284893035889e+00
    phi[2,1]  R694      1.8774956464767456e-01
    phi[2,1]  R695      -1.3378996849060059e+00
    phi[2,1]  R696      5.2432018518447876e-01
    phi[2,1]  R697      -3.2511866092681885e-01
    phi[2,1]  R698      -3.5755831003189087e-01
    phi[2,1]  R699      -1.3752126693725586e+00
    phi[2,1]  R700      -0.793183445930481
    phi[2,1]  R701      -2.0157096385955811e+00
    phi[2,1]  R702      -9.4874471426010132e-01
    phi[2,1]  R703      -8.9863473176956177e-01
    phi[2,1]  R704      -1.1757690906524658e+00
    phi[2,1]  R705      -1.0567289590835571e+00
    phi[2,1]  R706      -1.1576052904129028e+00
    phi[2,1]  R707      1.8765942752361298e-01
    phi[2,1]  R708      3.8110092282295227e-02
    phi[2,1]  R709      2.0229671150445938e-02
    phi[2,1]  R710      -1.1624418497085571e+00
    phi[2,1]  R711      -6.9024479389190674e-01
    phi[2,1]  R712      7.2112566232681274e-01
    phi[2,1]  R713      5.5092120170593262e-01
    phi[2,1]  R714      -1.0089961290359497e+00
    phi[2,1]  R715      -4.0616638958454132e-02
    phi[2,1]  R716      -1.2341398000717163e+00
    phi[2,1]  R717      -3.9332154393196106e-01
    phi[2,1]  R718      -3.2326176762580872e-01
    phi[2,1]  R719      -9.6449935436248779e-01
    phi[2,1]  R720      -0.416527658700943
    phi[2,1]  R721      -1.1485550403594971e+00
    phi[2,1]  R722      -1.3766080141067505e+00
    phi[2,1]  R723      -1.8996930122375488e+00
    phi[2,1]  R724      -1.0420613288879395e+00
    phi[2,1]  R725      -2.2673461437225342e+00
    phi[2,1]  R726      -1.7994740009307861e+00
    phi[2,1]  R727      0.1059565320611
    phi[2,1]  R728      -1.8579677343368530e+00
    phi[2,1]  R729      -1.6181721687316895e+00
    phi[2,1]  R730      2.8924499638378620e-03
    phi[2,1]  R731      -1.5287053585052490e+00
    phi[2,1]  R732      -2.0701112747192383e+00
    phi[2,1]  R733      3.4832516312599182e-01
    phi[2,1]  R734      6.8583297729492188e-01
    phi[2,1]  R735      8.6141246557235718e-01
    phi[2,1]  R736      9.0437716245651245e-01
    phi[2,1]  R737      -1.8925645351409912e+00
    phi[2,1]  R738      -1.7445719242095947e+00
    phi[2,1]  R739      -1.9598306417465210e+00
    phi[2,1]  R740      -2.2204709053039551e+00
    phi[2,1]  R741      -1.8093652725219727e+00
    phi[1,3]  R9        1
    phi[1,3]  R10       1
    phi[1,3]  R27       -1
    phi[1,3]  R742      -3.0999999046325684e+00
    phi[1,3]  R743      -3.0999999046325684e+00
    phi[1,3]  R744      -2.2400000095367432e+00
    phi[1,3]  R745      -2.2400000095367432e+00
    phi[1,3]  R746      -3.0999999046325684e+00
    phi[1,3]  R747      -3.0999999046325684e+00
    phi[1,3]  R748      -2.5699999332427979e+00
    phi[1,3]  R749      -2.5699999332427979e+00
    phi[1,3]  R750      -3.0999999046325684e+00
    phi[1,3]  R751      -3.0999999046325684e+00
    phi[1,3]  R752      -2.0899999141693115e+00
    phi[1,3]  R753      -2.0899999141693115e+00
    phi[1,3]  R754      -3.0999999046325684e+00
    phi[1,3]  R755      -3.0999999046325684e+00
    phi[1,3]  R756      7.2112566232681274e-01
    phi[1,3]  R757      5.5092120170593262e-01
    phi[1,3]  R758      -1.0089961290359497e+00
    phi[1,3]  R759      -4.0616638958454132e-02
    phi[1,3]  R760      -1.2341398000717163e+00
    phi[1,3]  R761      -3.9332154393196106e-01
    phi[1,3]  R762      -3.2326176762580872e-01
    phi[1,3]  R763      -9.6449935436248779e-01
    phi[1,3]  R764      -0.416527658700943
    phi[1,3]  R765      -1.1485550403594971e+00
    phi[1,3]  R766      -1.3766080141067505e+00
    phi[1,3]  R767      -1.8996930122375488e+00
    phi[1,3]  R768      -1.0420613288879395e+00
    phi[1,3]  R769      -2.2673461437225342e+00
    phi[1,3]  R770      -1.7994740009307861e+00
    phi[1,3]  R771      0.1059565320611
    phi[1,3]  R772      -1.8579677343368530e+00
    phi[1,3]  R773      -1.6181721687316895e+00
    phi[1,3]  R774      2.8924499638378620e-03
    phi[1,3]  R775      -1.5287053585052490e+00
    phi[1,3]  R776      -2.0701112747192383e+00
    phi[1,3]  R777      3.4832516312599182e-01
    phi[1,3]  R778      6.8583297729492188e-01
    phi[1,3]  R779      8.6141246557235718e-01
    phi[1,3]  R780      9.0437716245651245e-01
    phi[1,3]  R781      -1.8925645351409912e+00
    phi[1,3]  R782      -1.7445719242095947e+00
    phi[1,3]  R783      -1.9598306417465210e+00
    phi[1,3]  R784      -2.2204709053039551e+00
    phi[1,3]  R785      -1.8093652725219727e+00
    phi[1,3]  R786      2.1436505317687988e+00
    phi[1,3]  R787      1.6100840568542480e+00
    phi[1,3]  R788      -1.0875804424285889e+00
    phi[1,3]  R789      1.1442118883132935e+00
    phi[1,3]  R790      -9.6155720949172974e-01
    phi[1,3]  R791      -6.5286040306091309e-01
    phi[1,3]  R792      -6.2591218948364258e-01
    phi[1,3]  R793      1.6896090507507324e+00
    phi[1,3]  R794      1.9442853927612305e+00
    phi[1,3]  R795      2.3402440547943115e+00
    phi[1,3]  R796      -2.4749696254730225e+00
    phi[1,3]  R797      -1.0959521532058716e+00
    phi[1,3]  R798      -6.1637240648269653e-01
    phi[1,3]  R799      4.8767730593681335e-02
    phi[1,3]  R800      -2.7620315551757812e-01
    phi[1,3]  R801      -2.0260610580444336e+00
    phi[1,3]  R802      -1.9823112487792969e+00
    phi[1,3]  R803      -1.2064330577850342e+00
    phi[1,3]  R804      -1.9459155797958374e+00
    phi[1,3]  R805      4.5174804329872131e-01
    phi[1,3]  R806      -2.6594111919403076e+00
    phi[1,3]  R807      2.2779607772827148e-01
    phi[1,3]  R808      -1.5295785665512085e+00
    phi[1,3]  R809      -1.7565019130706787e+00
    phi[1,3]  R810      -2.5908222198486328e+00
    phi[1,3]  R811      -3.6230936050415039e+00
    phi[1,3]  R812      -1.5000482797622681e+00
    phi[1,3]  R813      -1.4969484806060791e+00
    phi[1,3]  R814      5.2858543395996094e-01
    phi[1,3]  R815      9.7126847505569458e-01
    phi[1,3]  R816      1.4517569541931152e-01
    phi[1,3]  R817      1.9753774404525757e+00
    phi[1,3]  R818      3.1934371590614319e-01
    phi[1,3]  R819      -4.1376194953918457e+00
    phi[1,3]  R820      1.6841137409210205e+00
    phi[1,3]  R821      1.7315447330474854e+00
    phi[1,3]  R822      -2.2248901426792145e-01
    phi[1,3]  R823      7.1061290800571442e-02
    phi[1,3]  R824      4.4981652498245239e-01
    phi[1,3]  R825      5.5983960628509521e-01
    phi[3,1]  R9        -1
    phi[3,1]  R27       1
    phi[3,1]  R28       1
    phi[3,1]  R826      -3.0999999046325684e+00
    phi[3,1]  R827      -3.0999999046325684e+00
    phi[3,1]  R828      -2.2400000095367432e+00
    phi[3,1]  R829      -2.2400000095367432e+00
    phi[3,1]  R830      -3.0999999046325684e+00
    phi[3,1]  R831      -3.0999999046325684e+00
    phi[3,1]  R832      -2.5699999332427979e+00
    phi[3,1]  R833      -2.5699999332427979e+00
    phi[3,1]  R834      -3.0999999046325684e+00
    phi[3,1]  R835      -3.0999999046325684e+00
    phi[3,1]  R836      -2.0899999141693115e+00
    phi[3,1]  R837      -2.0899999141693115e+00
    phi[3,1]  R838      -3.0999999046325684e+00
    phi[3,1]  R839      -3.0999999046325684e+00
    phi[3,1]  R840      2.1436505317687988e+00
    phi[3,1]  R841      1.6100840568542480e+00
    phi[3,1]  R842      -1.0875804424285889e+00
    phi[3,1]  R843      1.1442118883132935e+00
    phi[3,1]  R844      -9.6155720949172974e-01
    phi[3,1]  R845      -6.5286040306091309e-01
    phi[3,1]  R846      -6.2591218948364258e-01
    phi[3,1]  R847      1.6896090507507324e+00
    phi[3,1]  R848      1.9442853927612305e+00
    phi[3,1]  R849      2.3402440547943115e+00
    phi[3,1]  R850      -2.4749696254730225e+00
    phi[3,1]  R851      -1.0959521532058716e+00
    phi[3,1]  R852      -6.1637240648269653e-01
    phi[3,1]  R853      4.8767730593681335e-02
    phi[3,1]  R854      -2.7620315551757812e-01
    phi[3,1]  R855      -2.0260610580444336e+00
    phi[3,1]  R856      -1.9823112487792969e+00
    phi[3,1]  R857      -1.2064330577850342e+00
    phi[3,1]  R858      -1.9459155797958374e+00
    phi[3,1]  R859      4.5174804329872131e-01
    phi[3,1]  R860      -2.6594111919403076e+00
    phi[3,1]  R861      2.2779607772827148e-01
    phi[3,1]  R862      -1.5295785665512085e+00
    phi[3,1]  R863      -1.7565019130706787e+00
    phi[3,1]  R864      -2.5908222198486328e+00
    phi[3,1]  R865      -3.6230936050415039e+00
    phi[3,1]  R866      -1.5000482797622681e+00
    phi[3,1]  R867      -1.4969484806060791e+00
    phi[3,1]  R868      5.2858543395996094e-01
    phi[3,1]  R869      9.7126847505569458e-01
    phi[3,1]  R870      1.4517569541931152e-01
    phi[3,1]  R871      1.9753774404525757e+00
    phi[3,1]  R872      3.1934371590614319e-01
    phi[3,1]  R873      -4.1376194953918457e+00
    phi[3,1]  R874      1.6841137409210205e+00
    phi[3,1]  R875      1.7315447330474854e+00
    phi[3,1]  R876      -2.2248901426792145e-01
    phi[3,1]  R877      7.1061290800571442e-02
    phi[3,1]  R878      4.4981652498245239e-01
    phi[3,1]  R879      5.5983960628509521e-01
    phi[3,1]  R880      7.2112566232681274e-01
    phi[3,1]  R881      5.5092120170593262e-01
    phi[3,1]  R882      -1.0089961290359497e+00
    phi[3,1]  R883      -4.0616638958454132e-02
    phi[3,1]  R884      -1.2341398000717163e+00
    phi[3,1]  R885      -3.9332154393196106e-01
    phi[3,1]  R886      -3.2326176762580872e-01
    phi[3,1]  R887      -9.6449935436248779e-01
    phi[3,1]  R888      -0.416527658700943
    phi[3,1]  R889      -1.1485550403594971e+00
    phi[3,1]  R890      -1.3766080141067505e+00
    phi[3,1]  R891      -1.8996930122375488e+00
    phi[3,1]  R892      -1.0420613288879395e+00
    phi[3,1]  R893      -2.2673461437225342e+00
    phi[3,1]  R894      -1.7994740009307861e+00
    phi[3,1]  R895      0.1059565320611
    phi[3,1]  R896      -1.8579677343368530e+00
    phi[3,1]  R897      -1.6181721687316895e+00
    phi[3,1]  R898      2.8924499638378620e-03
    phi[3,1]  R899      -1.5287053585052490e+00
    phi[3,1]  R900      -2.0701112747192383e+00
    phi[3,1]  R901      3.4832516312599182e-01
    phi[3,1]  R902      6.8583297729492188e-01
    phi[3,1]  R903      8.6141246557235718e-01
    phi[3,1]  R904      9.0437716245651245e-01
    phi[3,1]  R905      -1.8925645351409912e+00
    phi[3,1]  R906      -1.7445719242095947e+00
    phi[3,1]  R907      -1.9598306417465210e+00
    phi[3,1]  R908      -2.2204709053039551e+00
    phi[3,1]  R909      -1.8093652725219727e+00
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R910      -3.0999999046325684e+00
    phi[2,3]  R911      -3.0999999046325684e+00
    phi[2,3]  R912      -2.2400000095367432e+00
    phi[2,3]  R913      -2.2400000095367432e+00
    phi[2,3]  R914      -3.0999999046325684e+00
    phi[2,3]  R915      -3.0999999046325684e+00
    phi[2,3]  R916      -2.5699999332427979e+00
    phi[2,3]  R917      -2.5699999332427979e+00
    phi[2,3]  R918      -3.0999999046325684e+00
    phi[2,3]  R919      -3.0999999046325684e+00
    phi[2,3]  R920      -2.0899999141693115e+00
    phi[2,3]  R921      -2.0899999141693115e+00
    phi[2,3]  R922      -3.0999999046325684e+00
    phi[2,3]  R923      -3.0999999046325684e+00
    phi[2,3]  R924      -1.0539060831069946e+00
    phi[2,3]  R925      1.0972964763641357e+00
    phi[2,3]  R926      -5.1101803779602051e-01
    phi[2,3]  R927      0.704910397529602
    phi[2,3]  R928      1.2428203821182251e+00
    phi[2,3]  R929      -9.7667455673217773e-01
    phi[2,3]  R930      2.3235200345516205e-01
    phi[2,3]  R931      -3.0786231160163879e-01
    phi[2,3]  R932      -0.526995837688446
    phi[2,3]  R933      3.6671388149261475e-01
    phi[2,3]  R934      -1.1494132280349731e+00
    phi[2,3]  R935      -1.3793284893035889e+00
    phi[2,3]  R936      1.8774956464767456e-01
    phi[2,3]  R937      -1.3378996849060059e+00
    phi[2,3]  R938      5.2432018518447876e-01
    phi[2,3]  R939      -3.2511866092681885e-01
    phi[2,3]  R940      -3.5755831003189087e-01
    phi[2,3]  R941      -1.3752126693725586e+00
    phi[2,3]  R942      -0.793183445930481
    phi[2,3]  R943      -2.0157096385955811e+00
    phi[2,3]  R944      -9.4874471426010132e-01
    phi[2,3]  R945      -8.9863473176956177e-01
    phi[2,3]  R946      -1.1757690906524658e+00
    phi[2,3]  R947      -1.0567289590835571e+00
    phi[2,3]  R948      -1.1576052904129028e+00
    phi[2,3]  R949      1.8765942752361298e-01
    phi[2,3]  R950      3.8110092282295227e-02
    phi[2,3]  R951      2.0229671150445938e-02
    phi[2,3]  R952      -1.1624418497085571e+00
    phi[2,3]  R953      -6.9024479389190674e-01
    phi[2,3]  R954      2.1436505317687988e+00
    phi[2,3]  R955      1.6100840568542480e+00
    phi[2,3]  R956      -1.0875804424285889e+00
    phi[2,3]  R957      1.1442118883132935e+00
    phi[2,3]  R958      -9.6155720949172974e-01
    phi[2,3]  R959      -6.5286040306091309e-01
    phi[2,3]  R960      -6.2591218948364258e-01
    phi[2,3]  R961      1.6896090507507324e+00
    phi[2,3]  R962      1.9442853927612305e+00
    phi[2,3]  R963      2.3402440547943115e+00
    phi[2,3]  R964      -2.4749696254730225e+00
    phi[2,3]  R965      -1.0959521532058716e+00
    phi[2,3]  R966      -6.1637240648269653e-01
    phi[2,3]  R967      4.8767730593681335e-02
    phi[2,3]  R968      -2.7620315551757812e-01
    phi[2,3]  R969      -2.0260610580444336e+00
    phi[2,3]  R970      -1.9823112487792969e+00
    phi[2,3]  R971      -1.2064330577850342e+00
    phi[2,3]  R972      -1.9459155797958374e+00
    phi[2,3]  R973      4.5174804329872131e-01
    phi[2,3]  R974      -2.6594111919403076e+00
    phi[2,3]  R975      2.2779607772827148e-01
    phi[2,3]  R976      -1.5295785665512085e+00
    phi[2,3]  R977      -1.7565019130706787e+00
    phi[2,3]  R978      -2.5908222198486328e+00
    phi[2,3]  R979      -3.6230936050415039e+00
    phi[2,3]  R980      -1.5000482797622681e+00
    phi[2,3]  R981      -1.4969484806060791e+00
    phi[2,3]  R982      5.2858543395996094e-01
    phi[2,3]  R983      9.7126847505569458e-01
    phi[2,3]  R984      1.4517569541931152e-01
    phi[2,3]  R985      1.9753774404525757e+00
    phi[2,3]  R986      3.1934371590614319e-01
    phi[2,3]  R987      -4.1376194953918457e+00
    phi[2,3]  R988      1.6841137409210205e+00
    phi[2,3]  R989      1.7315447330474854e+00
    phi[2,3]  R990      -2.2248901426792145e-01
    phi[2,3]  R991      7.1061290800571442e-02
    phi[2,3]  R992      4.4981652498245239e-01
    phi[2,3]  R993      5.5983960628509521e-01
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R994      -3.0999999046325684e+00
    phi[3,2]  R995      -3.0999999046325684e+00
    phi[3,2]  R996      -2.2400000095367432e+00
    phi[3,2]  R997      -2.2400000095367432e+00
    phi[3,2]  R998      -3.0999999046325684e+00
    phi[3,2]  R999      -3.0999999046325684e+00
    phi[3,2]  R1000     -2.5699999332427979e+00
    phi[3,2]  R1001     -2.5699999332427979e+00
    phi[3,2]  R1002     -3.0999999046325684e+00
    phi[3,2]  R1003     -3.0999999046325684e+00
    phi[3,2]  R1004     -2.0899999141693115e+00
    phi[3,2]  R1005     -2.0899999141693115e+00
    phi[3,2]  R1006     -3.0999999046325684e+00
    phi[3,2]  R1007     -3.0999999046325684e+00
    phi[3,2]  R1008     2.1436505317687988e+00
    phi[3,2]  R1009     1.6100840568542480e+00
    phi[3,2]  R1010     -1.0875804424285889e+00
    phi[3,2]  R1011     1.1442118883132935e+00
    phi[3,2]  R1012     -9.6155720949172974e-01
    phi[3,2]  R1013     -6.5286040306091309e-01
    phi[3,2]  R1014     -6.2591218948364258e-01
    phi[3,2]  R1015     1.6896090507507324e+00
    phi[3,2]  R1016     1.9442853927612305e+00
    phi[3,2]  R1017     2.3402440547943115e+00
    phi[3,2]  R1018     -2.4749696254730225e+00
    phi[3,2]  R1019     -1.0959521532058716e+00
    phi[3,2]  R1020     -6.1637240648269653e-01
    phi[3,2]  R1021     4.8767730593681335e-02
    phi[3,2]  R1022     -2.7620315551757812e-01
    phi[3,2]  R1023     -2.0260610580444336e+00
    phi[3,2]  R1024     -1.9823112487792969e+00
    phi[3,2]  R1025     -1.2064330577850342e+00
    phi[3,2]  R1026     -1.9459155797958374e+00
    phi[3,2]  R1027     4.5174804329872131e-01
    phi[3,2]  R1028     -2.6594111919403076e+00
    phi[3,2]  R1029     2.2779607772827148e-01
    phi[3,2]  R1030     -1.5295785665512085e+00
    phi[3,2]  R1031     -1.7565019130706787e+00
    phi[3,2]  R1032     -2.5908222198486328e+00
    phi[3,2]  R1033     -3.6230936050415039e+00
    phi[3,2]  R1034     -1.5000482797622681e+00
    phi[3,2]  R1035     -1.4969484806060791e+00
    phi[3,2]  R1036     5.2858543395996094e-01
    phi[3,2]  R1037     9.7126847505569458e-01
    phi[3,2]  R1038     1.4517569541931152e-01
    phi[3,2]  R1039     1.9753774404525757e+00
    phi[3,2]  R1040     3.1934371590614319e-01
    phi[3,2]  R1041     -4.1376194953918457e+00
    phi[3,2]  R1042     1.6841137409210205e+00
    phi[3,2]  R1043     1.7315447330474854e+00
    phi[3,2]  R1044     -2.2248901426792145e-01
    phi[3,2]  R1045     7.1061290800571442e-02
    phi[3,2]  R1046     4.4981652498245239e-01
    phi[3,2]  R1047     5.5983960628509521e-01
    phi[3,2]  R1048     -1.0539060831069946e+00
    phi[3,2]  R1049     1.0972964763641357e+00
    phi[3,2]  R1050     -5.1101803779602051e-01
    phi[3,2]  R1051     0.704910397529602
    phi[3,2]  R1052     1.2428203821182251e+00
    phi[3,2]  R1053     -9.7667455673217773e-01
    phi[3,2]  R1054     2.3235200345516205e-01
    phi[3,2]  R1055     -3.0786231160163879e-01
    phi[3,2]  R1056     -0.526995837688446
    phi[3,2]  R1057     3.6671388149261475e-01
    phi[3,2]  R1058     -1.1494132280349731e+00
    phi[3,2]  R1059     -1.3793284893035889e+00
    phi[3,2]  R1060     1.8774956464767456e-01
    phi[3,2]  R1061     -1.3378996849060059e+00
    phi[3,2]  R1062     5.2432018518447876e-01
    phi[3,2]  R1063     -3.2511866092681885e-01
    phi[3,2]  R1064     -3.5755831003189087e-01
    phi[3,2]  R1065     -1.3752126693725586e+00
    phi[3,2]  R1066     -0.793183445930481
    phi[3,2]  R1067     -2.0157096385955811e+00
    phi[3,2]  R1068     -9.4874471426010132e-01
    phi[3,2]  R1069     -8.9863473176956177e-01
    phi[3,2]  R1070     -1.1757690906524658e+00
    phi[3,2]  R1071     -1.0567289590835571e+00
    phi[3,2]  R1072     -1.1576052904129028e+00
    phi[3,2]  R1073     1.8765942752361298e-01
    phi[3,2]  R1074     3.8110092282295227e-02
    phi[3,2]  R1075     2.0229671150445938e-02
    phi[3,2]  R1076     -1.1624418497085571e+00
    phi[3,2]  R1077     -6.9024479389190674e-01
    phi[2,7]  R18       1
    phi[2,7]  R19       1
    phi[2,7]  R63       -1
    phi[2,7]  R1078     -3.0999999046325684e+00
    phi[2,7]  R1079     -3.0999999046325684e+00
    phi[2,7]  R1080     -2.2400000095367432e+00
    phi[2,7]  R1081     -2.2400000095367432e+00
    phi[2,7]  R1082     -3.0999999046325684e+00
    phi[2,7]  R1083     -3.0999999046325684e+00
    phi[2,7]  R1084     -2.5699999332427979e+00
    phi[2,7]  R1085     -2.5699999332427979e+00
    phi[2,7]  R1086     -3.0999999046325684e+00
    phi[2,7]  R1087     -3.0999999046325684e+00
    phi[2,7]  R1088     -2.0899999141693115e+00
    phi[2,7]  R1089     -2.0899999141693115e+00
    phi[2,7]  R1090     -3.0999999046325684e+00
    phi[2,7]  R1091     -3.0999999046325684e+00
    phi[2,7]  R1092     -1.0539060831069946e+00
    phi[2,7]  R1093     1.0972964763641357e+00
    phi[2,7]  R1094     -5.1101803779602051e-01
    phi[2,7]  R1095     0.704910397529602
    phi[2,7]  R1096     1.2428203821182251e+00
    phi[2,7]  R1097     -9.7667455673217773e-01
    phi[2,7]  R1098     2.3235200345516205e-01
    phi[2,7]  R1099     -3.0786231160163879e-01
    phi[2,7]  R1100     -0.526995837688446
    phi[2,7]  R1101     3.6671388149261475e-01
    phi[2,7]  R1102     -1.1494132280349731e+00
    phi[2,7]  R1103     -1.3793284893035889e+00
    phi[2,7]  R1104     1.8774956464767456e-01
    phi[2,7]  R1105     -1.3378996849060059e+00
    phi[2,7]  R1106     5.2432018518447876e-01
    phi[2,7]  R1107     -3.2511866092681885e-01
    phi[2,7]  R1108     -3.5755831003189087e-01
    phi[2,7]  R1109     -1.3752126693725586e+00
    phi[2,7]  R1110     -0.793183445930481
    phi[2,7]  R1111     -2.0157096385955811e+00
    phi[2,7]  R1112     -9.4874471426010132e-01
    phi[2,7]  R1113     -8.9863473176956177e-01
    phi[2,7]  R1114     -1.1757690906524658e+00
    phi[2,7]  R1115     -1.0567289590835571e+00
    phi[2,7]  R1116     -1.1576052904129028e+00
    phi[2,7]  R1117     1.8765942752361298e-01
    phi[2,7]  R1118     3.8110092282295227e-02
    phi[2,7]  R1119     2.0229671150445938e-02
    phi[2,7]  R1120     -1.1624418497085571e+00
    phi[2,7]  R1121     -6.9024479389190674e-01
    phi[2,7]  R1122     1.0296105146408081e+00
    phi[2,7]  R1123     0.716434121131897
    phi[2,7]  R1124     7.6938903331756592e-01
    phi[2,7]  R1125     1.7903488874435425e-01
    phi[2,7]  R1126     6.9300276041030884e-01
    phi[2,7]  R1127     5.7272320985794067e-01
    phi[2,7]  R1128     2.2373457252979279e-01
    phi[2,7]  R1129     3.3593982458114624e-01
    phi[2,7]  R1130     1.4850615262985229e+00
    phi[2,7]  R1131     -3.7475198507308960e-01
    phi[2,7]  R1132     -1.1414517164230347e+00
    phi[2,7]  R1133     -1.7636418342590332e+00
    phi[2,7]  R1134     -1.5199061632156372e+00
    phi[2,7]  R1135     -1.3761081695556641e+00
    phi[2,7]  R1136     -9.6923089027404785e-01
    phi[2,7]  R1137     -1.0672049522399902e+00
    phi[2,7]  R1138     -1.1324710845947266e+00
    phi[2,7]  R1139     -2.0737657546997070e+00
    phi[2,7]  R1140     -1.8743268251419067e+00
    phi[2,7]  R1141     -2.5117764472961426e+00
    phi[2,7]  R1142     -5.4955464601516724e-01
    phi[2,7]  R1143     -6.4221578836441040e-01
    phi[2,7]  R1144     -1.1734766960144043e+00
    phi[2,7]  R1145     -4.7339788079261780e-01
    phi[2,7]  R1146     -1.2235152721405029e+00
    phi[2,7]  R1147     -1.2154632806777954e+00
    phi[2,7]  R1148     -9.1887158155441284e-01
    phi[2,7]  R1149     -5.7003825902938843e-02
    phi[2,7]  R1150     1.5268816053867340e-01
    phi[2,7]  R1151     -1.9405554533004761e+00
    phi[2,7]  R1152     5.3824096918106079e-01
    phi[2,7]  R1153     -4.1388472914695740e-01
    phi[2,7]  R1154     7.1118336915969849e-01
    phi[2,7]  R1155     -1.7621688842773438e+00
    phi[2,7]  R1156     -1.1822800636291504e+00
    phi[2,7]  R1157     -3.0333730578422546e-01
    phi[2,7]  R1158     1.2183914333581924e-01
    phi[2,7]  R1159     -2.4926054477691650e+00
    phi[2,7]  R1160     -1.4653894901275635e+00
    phi[2,7]  R1161     -2.7052896022796631e+00
    phi[2,7]  R1162     -1.1254521608352661e+00
    phi[2,7]  R1163     -1.0036932229995728e+00
    phi[2,7]  R1164     4.6034210920333862e-01
    phi[2,7]  R1165     0.247628316283226
    phi[2,7]  R1166     -1.8546807765960693e-01
    phi[2,7]  R1167     -2.6060185432434082e+00
    phi[2,7]  R1168     7.1393772959709167e-02
    phi[2,7]  R1169     -2.9703862667083740e+00
    phi[2,7]  R1170     -2.5672531127929688e+00
    phi[2,7]  R1171     -1.2115645408630371e+00
    phi[7,2]  R18       -1
    phi[7,2]  R63       1
    phi[7,2]  R64       1
    phi[7,2]  R1172     -3.0999999046325684e+00
    phi[7,2]  R1173     -3.0999999046325684e+00
    phi[7,2]  R1174     -2.2400000095367432e+00
    phi[7,2]  R1175     -2.2400000095367432e+00
    phi[7,2]  R1176     -3.0999999046325684e+00
    phi[7,2]  R1177     -3.0999999046325684e+00
    phi[7,2]  R1178     -2.5699999332427979e+00
    phi[7,2]  R1179     -2.5699999332427979e+00
    phi[7,2]  R1180     -3.0999999046325684e+00
    phi[7,2]  R1181     -3.0999999046325684e+00
    phi[7,2]  R1182     -2.0899999141693115e+00
    phi[7,2]  R1183     -2.0899999141693115e+00
    phi[7,2]  R1184     -3.0999999046325684e+00
    phi[7,2]  R1185     -3.0999999046325684e+00
    phi[7,2]  R1186     1.0296105146408081e+00
    phi[7,2]  R1187     0.716434121131897
    phi[7,2]  R1188     7.6938903331756592e-01
    phi[7,2]  R1189     1.7903488874435425e-01
    phi[7,2]  R1190     6.9300276041030884e-01
    phi[7,2]  R1191     5.7272320985794067e-01
    phi[7,2]  R1192     2.2373457252979279e-01
    phi[7,2]  R1193     3.3593982458114624e-01
    phi[7,2]  R1194     1.4850615262985229e+00
    phi[7,2]  R1195     -3.7475198507308960e-01
    phi[7,2]  R1196     -1.1414517164230347e+00
    phi[7,2]  R1197     -1.7636418342590332e+00
    phi[7,2]  R1198     -1.5199061632156372e+00
    phi[7,2]  R1199     -1.3761081695556641e+00
    phi[7,2]  R1200     -9.6923089027404785e-01
    phi[7,2]  R1201     -1.0672049522399902e+00
    phi[7,2]  R1202     -1.1324710845947266e+00
    phi[7,2]  R1203     -2.0737657546997070e+00
    phi[7,2]  R1204     -1.8743268251419067e+00
    phi[7,2]  R1205     -2.5117764472961426e+00
    phi[7,2]  R1206     -5.4955464601516724e-01
    phi[7,2]  R1207     -6.4221578836441040e-01
    phi[7,2]  R1208     -1.1734766960144043e+00
    phi[7,2]  R1209     -4.7339788079261780e-01
    phi[7,2]  R1210     -1.2235152721405029e+00
    phi[7,2]  R1211     -1.2154632806777954e+00
    phi[7,2]  R1212     -9.1887158155441284e-01
    phi[7,2]  R1213     -5.7003825902938843e-02
    phi[7,2]  R1214     1.5268816053867340e-01
    phi[7,2]  R1215     -1.9405554533004761e+00
    phi[7,2]  R1216     5.3824096918106079e-01
    phi[7,2]  R1217     -4.1388472914695740e-01
    phi[7,2]  R1218     7.1118336915969849e-01
    phi[7,2]  R1219     -1.7621688842773438e+00
    phi[7,2]  R1220     -1.1822800636291504e+00
    phi[7,2]  R1221     -3.0333730578422546e-01
    phi[7,2]  R1222     1.2183914333581924e-01
    phi[7,2]  R1223     -2.4926054477691650e+00
    phi[7,2]  R1224     -1.4653894901275635e+00
    phi[7,2]  R1225     -2.7052896022796631e+00
    phi[7,2]  R1226     -1.1254521608352661e+00
    phi[7,2]  R1227     -1.0036932229995728e+00
    phi[7,2]  R1228     4.6034210920333862e-01
    phi[7,2]  R1229     0.247628316283226
    phi[7,2]  R1230     -1.8546807765960693e-01
    phi[7,2]  R1231     -2.6060185432434082e+00
    phi[7,2]  R1232     7.1393772959709167e-02
    phi[7,2]  R1233     -2.9703862667083740e+00
    phi[7,2]  R1234     -2.5672531127929688e+00
    phi[7,2]  R1235     -1.2115645408630371e+00
    phi[7,2]  R1236     -1.0539060831069946e+00
    phi[7,2]  R1237     1.0972964763641357e+00
    phi[7,2]  R1238     -5.1101803779602051e-01
    phi[7,2]  R1239     0.704910397529602
    phi[7,2]  R1240     1.2428203821182251e+00
    phi[7,2]  R1241     -9.7667455673217773e-01
    phi[7,2]  R1242     2.3235200345516205e-01
    phi[7,2]  R1243     -3.0786231160163879e-01
    phi[7,2]  R1244     -0.526995837688446
    phi[7,2]  R1245     3.6671388149261475e-01
    phi[7,2]  R1246     -1.1494132280349731e+00
    phi[7,2]  R1247     -1.3793284893035889e+00
    phi[7,2]  R1248     1.8774956464767456e-01
    phi[7,2]  R1249     -1.3378996849060059e+00
    phi[7,2]  R1250     5.2432018518447876e-01
    phi[7,2]  R1251     -3.2511866092681885e-01
    phi[7,2]  R1252     -3.5755831003189087e-01
    phi[7,2]  R1253     -1.3752126693725586e+00
    phi[7,2]  R1254     -0.793183445930481
    phi[7,2]  R1255     -2.0157096385955811e+00
    phi[7,2]  R1256     -9.4874471426010132e-01
    phi[7,2]  R1257     -8.9863473176956177e-01
    phi[7,2]  R1258     -1.1757690906524658e+00
    phi[7,2]  R1259     -1.0567289590835571e+00
    phi[7,2]  R1260     -1.1576052904129028e+00
    phi[7,2]  R1261     1.8765942752361298e-01
    phi[7,2]  R1262     3.8110092282295227e-02
    phi[7,2]  R1263     2.0229671150445938e-02
    phi[7,2]  R1264     -1.1624418497085571e+00
    phi[7,2]  R1265     -6.9024479389190674e-01
    phi[3,8]  R27       1
    phi[3,8]  R28       1
    phi[3,8]  R72       -1
    phi[3,8]  R1266     -3.0999999046325684e+00
    phi[3,8]  R1267     -3.0999999046325684e+00
    phi[3,8]  R1268     -2.2400000095367432e+00
    phi[3,8]  R1269     -2.2400000095367432e+00
    phi[3,8]  R1270     -3.0999999046325684e+00
    phi[3,8]  R1271     -3.0999999046325684e+00
    phi[3,8]  R1272     -2.5699999332427979e+00
    phi[3,8]  R1273     -2.5699999332427979e+00
    phi[3,8]  R1274     -3.0999999046325684e+00
    phi[3,8]  R1275     -3.0999999046325684e+00
    phi[3,8]  R1276     -2.0899999141693115e+00
    phi[3,8]  R1277     -2.0899999141693115e+00
    phi[3,8]  R1278     -3.0999999046325684e+00
    phi[3,8]  R1279     -3.0999999046325684e+00
    phi[3,8]  R1280     2.1436505317687988e+00
    phi[3,8]  R1281     1.6100840568542480e+00
    phi[3,8]  R1282     -1.0875804424285889e+00
    phi[3,8]  R1283     1.1442118883132935e+00
    phi[3,8]  R1284     -9.6155720949172974e-01
    phi[3,8]  R1285     -6.5286040306091309e-01
    phi[3,8]  R1286     -6.2591218948364258e-01
    phi[3,8]  R1287     1.6896090507507324e+00
    phi[3,8]  R1288     1.9442853927612305e+00
    phi[3,8]  R1289     2.3402440547943115e+00
    phi[3,8]  R1290     -2.4749696254730225e+00
    phi[3,8]  R1291     -1.0959521532058716e+00
    phi[3,8]  R1292     -6.1637240648269653e-01
    phi[3,8]  R1293     4.8767730593681335e-02
    phi[3,8]  R1294     -2.7620315551757812e-01
    phi[3,8]  R1295     -2.0260610580444336e+00
    phi[3,8]  R1296     -1.9823112487792969e+00
    phi[3,8]  R1297     -1.2064330577850342e+00
    phi[3,8]  R1298     -1.9459155797958374e+00
    phi[3,8]  R1299     4.5174804329872131e-01
    phi[3,8]  R1300     -2.6594111919403076e+00
    phi[3,8]  R1301     2.2779607772827148e-01
    phi[3,8]  R1302     -1.5295785665512085e+00
    phi[3,8]  R1303     -1.7565019130706787e+00
    phi[3,8]  R1304     -2.5908222198486328e+00
    phi[3,8]  R1305     -3.6230936050415039e+00
    phi[3,8]  R1306     -1.5000482797622681e+00
    phi[3,8]  R1307     -1.4969484806060791e+00
    phi[3,8]  R1308     5.2858543395996094e-01
    phi[3,8]  R1309     9.7126847505569458e-01
    phi[3,8]  R1310     1.4517569541931152e-01
    phi[3,8]  R1311     1.9753774404525757e+00
    phi[3,8]  R1312     3.1934371590614319e-01
    phi[3,8]  R1313     -4.1376194953918457e+00
    phi[3,8]  R1314     1.6841137409210205e+00
    phi[3,8]  R1315     1.7315447330474854e+00
    phi[3,8]  R1316     -2.2248901426792145e-01
    phi[3,8]  R1317     7.1061290800571442e-02
    phi[3,8]  R1318     4.4981652498245239e-01
    phi[3,8]  R1319     5.5983960628509521e-01
    phi[3,8]  R1320     -2.8466144204139709e-01
    phi[3,8]  R1321     1.7102469205856323e+00
    phi[3,8]  R1322     2.3981254100799561e+00
    phi[3,8]  R1323     2.2306964397430420e+00
    phi[3,8]  R1324     2.1604392528533936e+00
    phi[3,8]  R1325     1.3745080232620239e+00
    phi[3,8]  R1326     2.1568846702575684e+00
    phi[3,8]  R1327     1.8707808256149292e+00
    phi[3,8]  R1328     2.4816939830780029e+00
    phi[3,8]  R1329     2.1964952945709229e+00
    phi[3,8]  R1330     -1.3136184215545654e+00
    phi[3,8]  R1331     -1.8565570116043091e+00
    phi[3,8]  R1332     -1.5606383085250854e+00
    phi[3,8]  R1333     -2.1174800395965576e+00
    phi[3,8]  R1334     -1.4715760946273804e+00
    phi[3,8]  R1335     -1.4021667242050171e+00
    phi[3,8]  R1336     -2.3559811115264893e+00
    phi[3,8]  R1337     -1.0835347175598145e+00
    phi[3,8]  R1338     -2.1485517024993896e+00
    phi[3,8]  R1339     -2.0187778472900391e+00
    phi[3,8]  R1340     9.2508578300476074e-01
    phi[3,8]  R1341     5.5983662605285645e-01
    phi[3,8]  R1342     0.846215546131134
    phi[3,8]  R1343     1.9068424701690674e+00
    phi[3,8]  R1344     -7.5234943628311157e-01
    phi[3,8]  R1345     -4.0609243512153625e-01
    phi[3,8]  R1346     3.8269951939582825e-01
    phi[3,8]  R1347     -7.1839398145675659e-01
    phi[3,8]  R1348     -1.0407881736755371e+00
    phi[3,8]  R1349     -1.5586100816726685e+00
    phi[3,8]  R1350     7.0732039213180542e-01
    phi[3,8]  R1351     2.2568330764770508e+00
    phi[3,8]  R1352     5.8885502815246582e-01
    phi[3,8]  R1353     1.0612531565129757e-02
    phi[3,8]  R1354     1.0577993392944336e+00
    phi[3,8]  R1355     8.2408094406127930e-01
    phi[3,8]  R1356     -6.2420296669006348e-01
    phi[3,8]  R1357     -4.3171414732933044e-01
    phi[3,8]  R1358     -3.6625301837921143e-01
    phi[3,8]  R1359     -1.7514756321907043e-01
    phi[3,8]  R1360     2.0341942310333252e+00
    phi[3,8]  R1361     0.253650039434433
    phi[3,8]  R1362     0.345493346452713
    phi[3,8]  R1363     -5.7241266965866089e-01
    phi[3,8]  R1364     -3.8763836026191711e-01
    phi[3,8]  R1365     1.1232388019561768e+00
    phi[3,8]  R1366     -1.7671980857849121e+00
    phi[3,8]  R1367     -6.6737359762191772e-01
    phi[3,8]  R1368     -8.0058199167251587e-01
    phi[3,8]  R1369     -1.9614350795745850e-01
    phi[8,3]  R27       -1
    phi[8,3]  R72       1
    phi[8,3]  R73       1
    phi[8,3]  R1370     -3.0999999046325684e+00
    phi[8,3]  R1371     -3.0999999046325684e+00
    phi[8,3]  R1372     -2.2400000095367432e+00
    phi[8,3]  R1373     -2.2400000095367432e+00
    phi[8,3]  R1374     -3.0999999046325684e+00
    phi[8,3]  R1375     -3.0999999046325684e+00
    phi[8,3]  R1376     -2.5699999332427979e+00
    phi[8,3]  R1377     -2.5699999332427979e+00
    phi[8,3]  R1378     -3.0999999046325684e+00
    phi[8,3]  R1379     -3.0999999046325684e+00
    phi[8,3]  R1380     -2.0899999141693115e+00
    phi[8,3]  R1381     -2.0899999141693115e+00
    phi[8,3]  R1382     -3.0999999046325684e+00
    phi[8,3]  R1383     -3.0999999046325684e+00
    phi[8,3]  R1384     -2.8466144204139709e-01
    phi[8,3]  R1385     1.7102469205856323e+00
    phi[8,3]  R1386     2.3981254100799561e+00
    phi[8,3]  R1387     2.2306964397430420e+00
    phi[8,3]  R1388     2.1604392528533936e+00
    phi[8,3]  R1389     1.3745080232620239e+00
    phi[8,3]  R1390     2.1568846702575684e+00
    phi[8,3]  R1391     1.8707808256149292e+00
    phi[8,3]  R1392     2.4816939830780029e+00
    phi[8,3]  R1393     2.1964952945709229e+00
    phi[8,3]  R1394     -1.3136184215545654e+00
    phi[8,3]  R1395     -1.8565570116043091e+00
    phi[8,3]  R1396     -1.5606383085250854e+00
    phi[8,3]  R1397     -2.1174800395965576e+00
    phi[8,3]  R1398     -1.4715760946273804e+00
    phi[8,3]  R1399     -1.4021667242050171e+00
    phi[8,3]  R1400     -2.3559811115264893e+00
    phi[8,3]  R1401     -1.0835347175598145e+00
    phi[8,3]  R1402     -2.1485517024993896e+00
    phi[8,3]  R1403     -2.0187778472900391e+00
    phi[8,3]  R1404     9.2508578300476074e-01
    phi[8,3]  R1405     5.5983662605285645e-01
    phi[8,3]  R1406     0.846215546131134
    phi[8,3]  R1407     1.9068424701690674e+00
    phi[8,3]  R1408     -7.5234943628311157e-01
    phi[8,3]  R1409     -4.0609243512153625e-01
    phi[8,3]  R1410     3.8269951939582825e-01
    phi[8,3]  R1411     -7.1839398145675659e-01
    phi[8,3]  R1412     -1.0407881736755371e+00
    phi[8,3]  R1413     -1.5586100816726685e+00
    phi[8,3]  R1414     7.0732039213180542e-01
    phi[8,3]  R1415     2.2568330764770508e+00
    phi[8,3]  R1416     5.8885502815246582e-01
    phi[8,3]  R1417     1.0612531565129757e-02
    phi[8,3]  R1418     1.0577993392944336e+00
    phi[8,3]  R1419     8.2408094406127930e-01
    phi[8,3]  R1420     -6.2420296669006348e-01
    phi[8,3]  R1421     -4.3171414732933044e-01
    phi[8,3]  R1422     -3.6625301837921143e-01
    phi[8,3]  R1423     -1.7514756321907043e-01
    phi[8,3]  R1424     2.0341942310333252e+00
    phi[8,3]  R1425     0.253650039434433
    phi[8,3]  R1426     0.345493346452713
    phi[8,3]  R1427     -5.7241266965866089e-01
    phi[8,3]  R1428     -3.8763836026191711e-01
    phi[8,3]  R1429     1.1232388019561768e+00
    phi[8,3]  R1430     -1.7671980857849121e+00
    phi[8,3]  R1431     -6.6737359762191772e-01
    phi[8,3]  R1432     -8.0058199167251587e-01
    phi[8,3]  R1433     -1.9614350795745850e-01
    phi[8,3]  R1434     2.1436505317687988e+00
    phi[8,3]  R1435     1.6100840568542480e+00
    phi[8,3]  R1436     -1.0875804424285889e+00
    phi[8,3]  R1437     1.1442118883132935e+00
    phi[8,3]  R1438     -9.6155720949172974e-01
    phi[8,3]  R1439     -6.5286040306091309e-01
    phi[8,3]  R1440     -6.2591218948364258e-01
    phi[8,3]  R1441     1.6896090507507324e+00
    phi[8,3]  R1442     1.9442853927612305e+00
    phi[8,3]  R1443     2.3402440547943115e+00
    phi[8,3]  R1444     -2.4749696254730225e+00
    phi[8,3]  R1445     -1.0959521532058716e+00
    phi[8,3]  R1446     -6.1637240648269653e-01
    phi[8,3]  R1447     4.8767730593681335e-02
    phi[8,3]  R1448     -2.7620315551757812e-01
    phi[8,3]  R1449     -2.0260610580444336e+00
    phi[8,3]  R1450     -1.9823112487792969e+00
    phi[8,3]  R1451     -1.2064330577850342e+00
    phi[8,3]  R1452     -1.9459155797958374e+00
    phi[8,3]  R1453     4.5174804329872131e-01
    phi[8,3]  R1454     -2.6594111919403076e+00
    phi[8,3]  R1455     2.2779607772827148e-01
    phi[8,3]  R1456     -1.5295785665512085e+00
    phi[8,3]  R1457     -1.7565019130706787e+00
    phi[8,3]  R1458     -2.5908222198486328e+00
    phi[8,3]  R1459     -3.6230936050415039e+00
    phi[8,3]  R1460     -1.5000482797622681e+00
    phi[8,3]  R1461     -1.4969484806060791e+00
    phi[8,3]  R1462     5.2858543395996094e-01
    phi[8,3]  R1463     9.7126847505569458e-01
    phi[8,3]  R1464     1.4517569541931152e-01
    phi[8,3]  R1465     1.9753774404525757e+00
    phi[8,3]  R1466     3.1934371590614319e-01
    phi[8,3]  R1467     -4.1376194953918457e+00
    phi[8,3]  R1468     1.6841137409210205e+00
    phi[8,3]  R1469     1.7315447330474854e+00
    phi[8,3]  R1470     -2.2248901426792145e-01
    phi[8,3]  R1471     7.1061290800571442e-02
    phi[8,3]  R1472     4.4981652498245239e-01
    phi[8,3]  R1473     5.5983960628509521e-01
    phi[3,9]  R27       1
    phi[3,9]  R28       1
    phi[3,9]  R81       -1
    phi[3,9]  R1474     -3.0999999046325684e+00
    phi[3,9]  R1475     -3.0999999046325684e+00
    phi[3,9]  R1476     -2.2400000095367432e+00
    phi[3,9]  R1477     -2.2400000095367432e+00
    phi[3,9]  R1478     -3.0999999046325684e+00
    phi[3,9]  R1479     -3.0999999046325684e+00
    phi[3,9]  R1480     -2.5699999332427979e+00
    phi[3,9]  R1481     -2.5699999332427979e+00
    phi[3,9]  R1482     -3.0999999046325684e+00
    phi[3,9]  R1483     -3.0999999046325684e+00
    phi[3,9]  R1484     -2.0899999141693115e+00
    phi[3,9]  R1485     -2.0899999141693115e+00
    phi[3,9]  R1486     -3.0999999046325684e+00
    phi[3,9]  R1487     -3.0999999046325684e+00
    phi[3,9]  R1488     2.1436505317687988e+00
    phi[3,9]  R1489     1.6100840568542480e+00
    phi[3,9]  R1490     -1.0875804424285889e+00
    phi[3,9]  R1491     1.1442118883132935e+00
    phi[3,9]  R1492     -9.6155720949172974e-01
    phi[3,9]  R1493     -6.5286040306091309e-01
    phi[3,9]  R1494     -6.2591218948364258e-01
    phi[3,9]  R1495     1.6896090507507324e+00
    phi[3,9]  R1496     1.9442853927612305e+00
    phi[3,9]  R1497     2.3402440547943115e+00
    phi[3,9]  R1498     -2.4749696254730225e+00
    phi[3,9]  R1499     -1.0959521532058716e+00
    phi[3,9]  R1500     -6.1637240648269653e-01
    phi[3,9]  R1501     4.8767730593681335e-02
    phi[3,9]  R1502     -2.7620315551757812e-01
    phi[3,9]  R1503     -2.0260610580444336e+00
    phi[3,9]  R1504     -1.9823112487792969e+00
    phi[3,9]  R1505     -1.2064330577850342e+00
    phi[3,9]  R1506     -1.9459155797958374e+00
    phi[3,9]  R1507     4.5174804329872131e-01
    phi[3,9]  R1508     -2.6594111919403076e+00
    phi[3,9]  R1509     2.2779607772827148e-01
    phi[3,9]  R1510     -1.5295785665512085e+00
    phi[3,9]  R1511     -1.7565019130706787e+00
    phi[3,9]  R1512     -2.5908222198486328e+00
    phi[3,9]  R1513     -3.6230936050415039e+00
    phi[3,9]  R1514     -1.5000482797622681e+00
    phi[3,9]  R1515     -1.4969484806060791e+00
    phi[3,9]  R1516     5.2858543395996094e-01
    phi[3,9]  R1517     9.7126847505569458e-01
    phi[3,9]  R1518     1.4517569541931152e-01
    phi[3,9]  R1519     1.9753774404525757e+00
    phi[3,9]  R1520     3.1934371590614319e-01
    phi[3,9]  R1521     -4.1376194953918457e+00
    phi[3,9]  R1522     1.6841137409210205e+00
    phi[3,9]  R1523     1.7315447330474854e+00
    phi[3,9]  R1524     -2.2248901426792145e-01
    phi[3,9]  R1525     7.1061290800571442e-02
    phi[3,9]  R1526     4.4981652498245239e-01
    phi[3,9]  R1527     5.5983960628509521e-01
    phi[3,9]  R1528     1.2974705696105957e+00
    phi[3,9]  R1529     2.8136305809020996e+00
    phi[3,9]  R1530     2.4402472972869873e+00
    phi[3,9]  R1531     1.4134865999221802e+00
    phi[3,9]  R1532     2.9779784679412842e+00
    phi[3,9]  R1533     2.12259578704834
    phi[3,9]  R1534     2.0830962657928467e+00
    phi[3,9]  R1535     0.381216436624527
    phi[3,9]  R1536     -1.1279854774475098e+00
    phi[3,9]  R1537     2.8544723987579346e+00
    phi[3,9]  R1538     0.992236316204071
    phi[3,9]  R1539     1.4208384752273560e+00
    phi[3,9]  R1540     1.6217888593673706e+00
    phi[3,9]  R1541     -2.4773682653903961e-01
    phi[3,9]  R1542     -2.7843410968780518e+00
    phi[3,9]  R1543     3.4216722846031189e-01
    phi[3,9]  R1544     1.0818901062011719e+00
    phi[3,9]  R1545     1.1143224239349365e+00
    phi[3,9]  R1546     -2.4066436290740967e+00
    phi[3,9]  R1547     -2.1806011199951172e+00
    phi[3,9]  R1548     -5.0406432151794434e-01
    phi[3,9]  R1549     -1.0526057481765747e+00
    phi[3,9]  R1550     -2.3937902450561523e+00
    phi[3,9]  R1551     -3.8485014438629150e-01
    phi[3,9]  R1552     -2.1062018871307373e+00
    phi[3,9]  R1553     -2.5661602020263672e+00
    phi[3,9]  R1554     0.0856981873512268
    phi[3,9]  R1555     -8.5020077228546143e-01
    phi[3,9]  R1556     -3.2826871871948242e+00
    phi[3,9]  R1557     -1.6602747440338135e+00
    phi[3,9]  R1558     -1.2312514781951904e+00
    phi[3,9]  R1559     -2.9388968944549561e+00
    phi[3,9]  R1560     6.1100125312805176e-01
    phi[3,9]  R1561     -2.7819211483001709e+00
    phi[3,9]  R1562     -3.3829560875892639e-01
    phi[3,9]  R1563     -9.8158240318298340e-01
    phi[3,9]  R1564     -1.2275003194808960e+00
    phi[3,9]  R1565     -2.0876631736755371e+00
    phi[3,9]  R1566     -2.7935233116149902e+00
    phi[3,9]  R1567     -1.4639621973037720e+00
    phi[3,9]  R1568     -2.8015465736389160e+00
    phi[3,9]  R1569     -1.9519008398056030e+00
    phi[3,9]  R1570     6.1406806111335754e-02
    phi[3,9]  R1571     -3.5257210731506348e+00
    phi[3,9]  R1572     -7.6007091999053955e-01
    phi[3,9]  R1573     -9.0748593211174011e-02
    phi[3,9]  R1574     1.3239935636520386e+00
    phi[3,9]  R1575     1.8796644210815430e+00
    phi[3,9]  R1576     1.4418530464172363e+00
    phi[3,9]  R1577     3.1636413931846619e-01
    phi[9,3]  R27       -1
    phi[9,3]  R81       1
    phi[9,3]  R82       1
    phi[9,3]  R1578     -3.0999999046325684e+00
    phi[9,3]  R1579     -3.0999999046325684e+00
    phi[9,3]  R1580     -2.2400000095367432e+00
    phi[9,3]  R1581     -2.2400000095367432e+00
    phi[9,3]  R1582     -3.0999999046325684e+00
    phi[9,3]  R1583     -3.0999999046325684e+00
    phi[9,3]  R1584     -2.5699999332427979e+00
    phi[9,3]  R1585     -2.5699999332427979e+00
    phi[9,3]  R1586     -3.0999999046325684e+00
    phi[9,3]  R1587     -3.0999999046325684e+00
    phi[9,3]  R1588     -2.0899999141693115e+00
    phi[9,3]  R1589     -2.0899999141693115e+00
    phi[9,3]  R1590     -3.0999999046325684e+00
    phi[9,3]  R1591     -3.0999999046325684e+00
    phi[9,3]  R1592     1.2974705696105957e+00
    phi[9,3]  R1593     2.8136305809020996e+00
    phi[9,3]  R1594     2.4402472972869873e+00
    phi[9,3]  R1595     1.4134865999221802e+00
    phi[9,3]  R1596     2.9779784679412842e+00
    phi[9,3]  R1597     2.12259578704834
    phi[9,3]  R1598     2.0830962657928467e+00
    phi[9,3]  R1599     0.381216436624527
    phi[9,3]  R1600     -1.1279854774475098e+00
    phi[9,3]  R1601     2.8544723987579346e+00
    phi[9,3]  R1602     0.992236316204071
    phi[9,3]  R1603     1.4208384752273560e+00
    phi[9,3]  R1604     1.6217888593673706e+00
    phi[9,3]  R1605     -2.4773682653903961e-01
    phi[9,3]  R1606     -2.7843410968780518e+00
    phi[9,3]  R1607     3.4216722846031189e-01
    phi[9,3]  R1608     1.0818901062011719e+00
    phi[9,3]  R1609     1.1143224239349365e+00
    phi[9,3]  R1610     -2.4066436290740967e+00
    phi[9,3]  R1611     -2.1806011199951172e+00
    phi[9,3]  R1612     -5.0406432151794434e-01
    phi[9,3]  R1613     -1.0526057481765747e+00
    phi[9,3]  R1614     -2.3937902450561523e+00
    phi[9,3]  R1615     -3.8485014438629150e-01
    phi[9,3]  R1616     -2.1062018871307373e+00
    phi[9,3]  R1617     -2.5661602020263672e+00
    phi[9,3]  R1618     0.0856981873512268
    phi[9,3]  R1619     -8.5020077228546143e-01
    phi[9,3]  R1620     -3.2826871871948242e+00
    phi[9,3]  R1621     -1.6602747440338135e+00
    phi[9,3]  R1622     -1.2312514781951904e+00
    phi[9,3]  R1623     -2.9388968944549561e+00
    phi[9,3]  R1624     6.1100125312805176e-01
    phi[9,3]  R1625     -2.7819211483001709e+00
    phi[9,3]  R1626     -3.3829560875892639e-01
    phi[9,3]  R1627     -9.8158240318298340e-01
    phi[9,3]  R1628     -1.2275003194808960e+00
    phi[9,3]  R1629     -2.0876631736755371e+00
    phi[9,3]  R1630     -2.7935233116149902e+00
    phi[9,3]  R1631     -1.4639621973037720e+00
    phi[9,3]  R1632     -2.8015465736389160e+00
    phi[9,3]  R1633     -1.9519008398056030e+00
    phi[9,3]  R1634     6.1406806111335754e-02
    phi[9,3]  R1635     -3.5257210731506348e+00
    phi[9,3]  R1636     -7.6007091999053955e-01
    phi[9,3]  R1637     -9.0748593211174011e-02
    phi[9,3]  R1638     1.3239935636520386e+00
    phi[9,3]  R1639     1.8796644210815430e+00
    phi[9,3]  R1640     1.4418530464172363e+00
    phi[9,3]  R1641     3.1636413931846619e-01
    phi[9,3]  R1642     2.1436505317687988e+00
    phi[9,3]  R1643     1.6100840568542480e+00
    phi[9,3]  R1644     -1.0875804424285889e+00
    phi[9,3]  R1645     1.1442118883132935e+00
    phi[9,3]  R1646     -9.6155720949172974e-01
    phi[9,3]  R1647     -6.5286040306091309e-01
    phi[9,3]  R1648     -6.2591218948364258e-01
    phi[9,3]  R1649     1.6896090507507324e+00
    phi[9,3]  R1650     1.9442853927612305e+00
    phi[9,3]  R1651     2.3402440547943115e+00
    phi[9,3]  R1652     -2.4749696254730225e+00
    phi[9,3]  R1653     -1.0959521532058716e+00
    phi[9,3]  R1654     -6.1637240648269653e-01
    phi[9,3]  R1655     4.8767730593681335e-02
    phi[9,3]  R1656     -2.7620315551757812e-01
    phi[9,3]  R1657     -2.0260610580444336e+00
    phi[9,3]  R1658     -1.9823112487792969e+00
    phi[9,3]  R1659     -1.2064330577850342e+00
    phi[9,3]  R1660     -1.9459155797958374e+00
    phi[9,3]  R1661     4.5174804329872131e-01
    phi[9,3]  R1662     -2.6594111919403076e+00
    phi[9,3]  R1663     2.2779607772827148e-01
    phi[9,3]  R1664     -1.5295785665512085e+00
    phi[9,3]  R1665     -1.7565019130706787e+00
    phi[9,3]  R1666     -2.5908222198486328e+00
    phi[9,3]  R1667     -3.6230936050415039e+00
    phi[9,3]  R1668     -1.5000482797622681e+00
    phi[9,3]  R1669     -1.4969484806060791e+00
    phi[9,3]  R1670     5.2858543395996094e-01
    phi[9,3]  R1671     9.7126847505569458e-01
    phi[9,3]  R1672     1.4517569541931152e-01
    phi[9,3]  R1673     1.9753774404525757e+00
    phi[9,3]  R1674     3.1934371590614319e-01
    phi[9,3]  R1675     -4.1376194953918457e+00
    phi[9,3]  R1676     1.6841137409210205e+00
    phi[9,3]  R1677     1.7315447330474854e+00
    phi[9,3]  R1678     -2.2248901426792145e-01
    phi[9,3]  R1679     7.1061290800571442e-02
    phi[9,3]  R1680     4.4981652498245239e-01
    phi[9,3]  R1681     5.5983960628509521e-01
    phi[3,11]  R27       1
    phi[3,11]  R28       1
    phi[3,11]  R29       1.5585360373754518e+00
    phi[3,11]  R30       -1.8418607432008236e+00
    phi[3,11]  R31       2.9731190103331193e+00
    phi[3,11]  R32       -1.5386497507623225e+00
    phi[3,11]  R33       -2.0330937445236263e+00
    phi[3,11]  R34       -1.5002020878785847e+00
    phi[3,11]  R35       1.1042864016893368e+00
    phi[3,11]  R91       -1
    phi[3,11]  R1682     -1.5414638672571166e+00
    phi[3,11]  R1683     -4.6585359420080206e+00
    phi[3,11]  R1684     -4.0818607527375672e+00
    phi[3,11]  R1685     -3.9813926633591956e-01
    phi[3,11]  R1686     -1.2688089429944904e-01
    phi[3,11]  R1687     -6.0731189149656881e+00
    phi[3,11]  R1688     -4.1086496840051208e+00
    phi[3,11]  R1689     -1.0313501824804754e+00
    phi[3,11]  R1690     -5.1330936491561943e+00
    phi[3,11]  R1691     -1.0669061601089420e+00
    phi[3,11]  R1692     -3.5902020020478962e+00
    phi[3,11]  R1693     -5.8979782629072686e-01
    phi[3,11]  R1694     -1.9957135029432316e+00
    phi[3,11]  R1695     -4.2042863063219054e+00
    phi[3,11]  R1696     -1.6288641929783765e-01
    phi[3,11]  R1697     -1.6802448789547775e-01
    phi[3,11]  R1698     -1.8248932447829058e-01
    phi[3,11]  R1699     -2.0007782295263477e-01
    phi[3,11]  R1700     -2.0216634422862734e-01
    phi[3,11]  R1701     -2.1453330309711505e-01
    phi[3,11]  R1702     -2.4071210666587406e-01
    phi[3,11]  R1703     -2.5256732393123604e-01
    phi[3,11]  R1704     -8.3946479651689421e-01
    phi[3,11]  R1705     -7.5725706323279818e-01
    phi[3,11]  R1706     -2.7337662581720190e-01
    phi[3,11]  R1707     -2.8009956790492740e-01
    phi[3,11]  R1708     -3.9889498998711370e-01
    phi[3,11]  R1709     -4.0724027147284558e-01
    phi[3,11]  R1710     -4.4310357904167236e-01
    phi[3,11]  R1711     -4.4382847580531015e-01
    phi[3,11]  R1712     -4.4488292349713943e-01
    phi[3,11]  R1713     -4.6458226185703944e-01
    phi[3,11]  R1714     -4.7589736134753480e-01
    phi[3,11]  R1715     -4.8178440455377369e-01
    phi[3,11]  R1716     -2.3697543704729718e-01
    phi[3,11]  R1717     -0.284328275691884
    phi[3,11]  R1718     -2.8462777713794640e-01
    phi[3,11]  R1719     -4.4092692784827170e-01
    phi[3,11]  R1720     -0.458046445769281
    phi[3,11]  R1721     -4.6831524907795741e-01
    phi[3,11]  R1722     -0.494282846131338
    phi[3,11]  R1723     -5.1836895531975169e-01
    phi[3,11]  R1724     -5.5387596146718088e-01
    phi[3,11]  R1725     -5.6945178343861347e-01
    phi[3,11]  R1726     -2.8441088091005096e-01
    phi[3,11]  R1727     -3.9600424470392781e-01
    phi[3,11]  R1728     -4.3650773718058244e-01
    phi[3,11]  R1729     -5.5893747974085928e-01
    phi[3,11]  R1730     -1.1966338121893094e+00
    phi[3,11]  R1731     -8.8825065503923240e-01
    phi[3,11]  R1732     -1.0390337077797069e+00
    phi[3,11]  R1733     -6.5101541313817979e-01
    phi[3,11]  R1734     -6.5748258516754321e-01
    phi[3,11]  R1735     -1.2876187627714053e+00
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R1736     -3.0999999046325684e+00
    phi[4,5]  R1737     -3.0999999046325684e+00
    phi[4,5]  R1738     -2.2400000095367432e+00
    phi[4,5]  R1739     -2.2400000095367432e+00
    phi[4,5]  R1740     -3.0999999046325684e+00
    phi[4,5]  R1741     -3.0999999046325684e+00
    phi[4,5]  R1742     -2.5699999332427979e+00
    phi[4,5]  R1743     -2.5699999332427979e+00
    phi[4,5]  R1744     -3.0999999046325684e+00
    phi[4,5]  R1745     -3.0999999046325684e+00
    phi[4,5]  R1746     -2.0899999141693115e+00
    phi[4,5]  R1747     -2.0899999141693115e+00
    phi[4,5]  R1748     -3.0999999046325684e+00
    phi[4,5]  R1749     -3.0999999046325684e+00
    phi[4,5]  R1750     2.1510252952575684e+00
    phi[4,5]  R1751     2.3087661266326904e+00
    phi[4,5]  R1752     2.2344079017639160e+00
    phi[4,5]  R1753     2.8701600432395935e-01
    phi[4,5]  R1754     1.0162551403045654e+00
    phi[4,5]  R1755     3.2342278957366943e-01
    phi[4,5]  R1756     2.3311109542846680e+00
    phi[4,5]  R1757     1.8067256212234497e+00
    phi[4,5]  R1758     6.3994789123535156e-01
    phi[4,5]  R1759     -1.1829671859741211e+00
    phi[4,5]  R1760     -1.8085280656814575e+00
    phi[4,5]  R1761     2.3737442493438721e-01
    phi[4,5]  R1762     -5.9441798925399780e-01
    phi[4,5]  R1763     -3.0016872882843018e+00
    phi[4,5]  R1764     -2.3230199813842773e+00
    phi[4,5]  R1765     -3.0763864517211914e+00
    phi[4,5]  R1766     -1.8486472368240356e+00
    phi[4,5]  R1767     -1.5698767900466919e+00
    phi[4,5]  R1768     -2.3516178131103516e+00
    phi[4,5]  R1769     -1.8654581308364868e+00
    phi[4,5]  R1770     -2.8284637928009033e+00
    phi[4,5]  R1771     -5.9689563512802124e-01
    phi[4,5]  R1772     -2.7439630031585693e-01
    phi[4,5]  R1773     -1.0399266481399536e+00
    phi[4,5]  R1774     -8.6047953367233276e-01
    phi[4,5]  R1775     4.3197140097618103e-01
    phi[4,5]  R1776     -5.1382535696029663e-01
    phi[4,5]  R1777     -0.839576005935669
    phi[4,5]  R1778     -1.6632450819015503e+00
    phi[4,5]  R1779     -0.605674684047699
    phi[4,5]  R1780     -1.0773233175277710e+00
    phi[4,5]  R1781     -2.6992473602294922e+00
    phi[4,5]  R1782     -3.5784826278686523e+00
    phi[4,5]  R1783     -3.5639214515686035e+00
    phi[4,5]  R1784     -1.6140263080596924e+00
    phi[4,5]  R1785     -2.8677439689636230e+00
    phi[4,5]  R1786     -1.7228866815567017e+00
    phi[4,5]  R1787     6.8052403628826141e-02
    phi[4,5]  R1788     -3.3058822154998779e+00
    phi[4,5]  R1789     -1.5509938001632690e+00
    phi[4,5]  R1790     2.6721320152282715e+00
    phi[4,5]  R1791     1.0542553663253784e+00
    phi[4,5]  R1792     -4.3973669409751892e-02
    phi[4,5]  R1793     -0.872677743434906
    phi[4,5]  R1794     2.6223728433251381e-02
    phi[4,5]  R1795     -5.9467816352844238e-01
    phi[4,5]  R1796     5.4028433561325073e-01
    phi[4,5]  R1797     -8.8324892520904541e-01
    phi[4,5]  R1798     -7.8803908824920654e-01
    phi[4,5]  R1799     -7.7637147903442383e-01
    phi[4,5]  R1800     -1.0009427070617676e+00
    phi[4,5]  R1801     -1.0461862087249756e+00
    phi[4,5]  R1802     -0.0729677602648735
    phi[4,5]  R1803     3.6292821168899536e-01
    phi[4,5]  R1804     -2.3945782184600830e+00
    phi[4,5]  R1805     -5.5078589916229248e-01
    phi[4,5]  R1806     -2.7807874679565430e+00
    phi[4,5]  R1807     -1.2810522317886353e+00
    phi[4,5]  R1808     -1.0457861423492432e+00
    phi[4,5]  R1809     -1.1360139846801758e+00
    phi[4,5]  R1810     -1.5627011060714722e+00
    phi[4,5]  R1811     -1.6247810125350952e+00
    phi[4,5]  R1812     -1.6776736974716187e+00
    phi[4,5]  R1813     -0.384996235370636
    phi[4,5]  R1814     -2.3753604292869568e-01
    phi[4,5]  R1815     -2.3957488536834717e+00
    phi[4,5]  R1816     -1.5398020744323730e+00
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R1817     -3.0999999046325684e+00
    phi[5,4]  R1818     -3.0999999046325684e+00
    phi[5,4]  R1819     -2.2400000095367432e+00
    phi[5,4]  R1820     -2.2400000095367432e+00
    phi[5,4]  R1821     -3.0999999046325684e+00
    phi[5,4]  R1822     -3.0999999046325684e+00
    phi[5,4]  R1823     -2.5699999332427979e+00
    phi[5,4]  R1824     -2.5699999332427979e+00
    phi[5,4]  R1825     -3.0999999046325684e+00
    phi[5,4]  R1826     -3.0999999046325684e+00
    phi[5,4]  R1827     -2.0899999141693115e+00
    phi[5,4]  R1828     -2.0899999141693115e+00
    phi[5,4]  R1829     -3.0999999046325684e+00
    phi[5,4]  R1830     -3.0999999046325684e+00
    phi[5,4]  R1831     2.6721320152282715e+00
    phi[5,4]  R1832     1.0542553663253784e+00
    phi[5,4]  R1833     -4.3973669409751892e-02
    phi[5,4]  R1834     -0.872677743434906
    phi[5,4]  R1835     2.6223728433251381e-02
    phi[5,4]  R1836     -5.9467816352844238e-01
    phi[5,4]  R1837     5.4028433561325073e-01
    phi[5,4]  R1838     -8.8324892520904541e-01
    phi[5,4]  R1839     -7.8803908824920654e-01
    phi[5,4]  R1840     -7.7637147903442383e-01
    phi[5,4]  R1841     -1.0009427070617676e+00
    phi[5,4]  R1842     -1.0461862087249756e+00
    phi[5,4]  R1843     -0.0729677602648735
    phi[5,4]  R1844     3.6292821168899536e-01
    phi[5,4]  R1845     -2.3945782184600830e+00
    phi[5,4]  R1846     -5.5078589916229248e-01
    phi[5,4]  R1847     -2.7807874679565430e+00
    phi[5,4]  R1848     -1.2810522317886353e+00
    phi[5,4]  R1849     -1.0457861423492432e+00
    phi[5,4]  R1850     -1.1360139846801758e+00
    phi[5,4]  R1851     -1.5627011060714722e+00
    phi[5,4]  R1852     -1.6247810125350952e+00
    phi[5,4]  R1853     -1.6776736974716187e+00
    phi[5,4]  R1854     -0.384996235370636
    phi[5,4]  R1855     -2.3753604292869568e-01
    phi[5,4]  R1856     -2.3957488536834717e+00
    phi[5,4]  R1857     -1.5398020744323730e+00
    phi[5,4]  R1858     2.1510252952575684e+00
    phi[5,4]  R1859     2.3087661266326904e+00
    phi[5,4]  R1860     2.2344079017639160e+00
    phi[5,4]  R1861     2.8701600432395935e-01
    phi[5,4]  R1862     1.0162551403045654e+00
    phi[5,4]  R1863     3.2342278957366943e-01
    phi[5,4]  R1864     2.3311109542846680e+00
    phi[5,4]  R1865     1.8067256212234497e+00
    phi[5,4]  R1866     6.3994789123535156e-01
    phi[5,4]  R1867     -1.1829671859741211e+00
    phi[5,4]  R1868     -1.8085280656814575e+00
    phi[5,4]  R1869     2.3737442493438721e-01
    phi[5,4]  R1870     -5.9441798925399780e-01
    phi[5,4]  R1871     -3.0016872882843018e+00
    phi[5,4]  R1872     -2.3230199813842773e+00
    phi[5,4]  R1873     -3.0763864517211914e+00
    phi[5,4]  R1874     -1.8486472368240356e+00
    phi[5,4]  R1875     -1.5698767900466919e+00
    phi[5,4]  R1876     -2.3516178131103516e+00
    phi[5,4]  R1877     -1.8654581308364868e+00
    phi[5,4]  R1878     -2.8284637928009033e+00
    phi[5,4]  R1879     -5.9689563512802124e-01
    phi[5,4]  R1880     -2.7439630031585693e-01
    phi[5,4]  R1881     -1.0399266481399536e+00
    phi[5,4]  R1882     -8.6047953367233276e-01
    phi[5,4]  R1883     4.3197140097618103e-01
    phi[5,4]  R1884     -5.1382535696029663e-01
    phi[5,4]  R1885     -0.839576005935669
    phi[5,4]  R1886     -1.6632450819015503e+00
    phi[5,4]  R1887     -0.605674684047699
    phi[5,4]  R1888     -1.0773233175277710e+00
    phi[5,4]  R1889     -2.6992473602294922e+00
    phi[5,4]  R1890     -3.5784826278686523e+00
    phi[5,4]  R1891     -3.5639214515686035e+00
    phi[5,4]  R1892     -1.6140263080596924e+00
    phi[5,4]  R1893     -2.8677439689636230e+00
    phi[5,4]  R1894     -1.7228866815567017e+00
    phi[5,4]  R1895     6.8052403628826141e-02
    phi[5,4]  R1896     -3.3058822154998779e+00
    phi[5,4]  R1897     -1.5509938001632690e+00
    phi[10,4]  R36       -1
    phi[10,4]  R38       1.3583139362724279e+00
    phi[10,4]  R39       -6.2928327239970128e-01
    phi[10,4]  R40       2.5603210539907253e+00
    phi[10,4]  R41       1.6105845164723394e+00
    phi[10,4]  R42       -4.2848871274391742e-01
    phi[10,4]  R43       -1.7433816108660944e+00
    phi[10,4]  R44       1.0768066673331931e+00
    phi[10,4]  R90       1
    phi[10,4]  R1898     -4.4583138409049958e+00
    phi[10,4]  R1899     -1.7416859683601404e+00
    phi[10,4]  R1900     -1.6107167371370419e+00
    phi[10,4]  R1901     -2.8692832819364442e+00
    phi[10,4]  R1902     -5.6603209586232932e+00
    phi[10,4]  R1903     -5.3967885064184307e-01
    phi[10,4]  R1904     -4.1805844497151377e+00
    phi[10,4]  R1905     -9.5941541677045850e-01
    phi[10,4]  R1906     -2.6715111918886509e+00
    phi[10,4]  R1907     -3.5284886173764858e+00
    phi[10,4]  R1908     -3.4661830330321708e-01
    phi[10,4]  R1909     -3.8333815250354060e+00
    phi[10,4]  R1910     -4.1768065719657610e+00
    phi[10,4]  R1911     -2.0231932372993753e+00
    phi[10,4]  R1912     -1.7355986562195413e-01
    phi[10,4]  R1913     -1.8780647353304047e-01
    phi[10,4]  R1914     -4.3213044716759130e-01
    phi[10,4]  R1915     -4.6513032163784629e-01
    phi[10,4]  R1916     -2.6420685764504248e-01
    phi[10,4]  R1917     -7.2832530184845967e-01
    phi[10,4]  R1918     -2.2801309913414425e-01
    phi[10,4]  R1919     -9.5351832065077025e-01
    phi[10,4]  R1920     -9.6404695260008966e-01
    phi[10,4]  R1921     -1.0666906152050422e+00
    phi[10,4]  R1922     -7.5523277725556581e-01
    phi[10,4]  R1923     -8.8416765436704181e-01
    phi[10,4]  R1924     -8.8618837376771054e-01
    phi[10,4]  R1925     -0.949783771835865
    phi[10,4]  R1926     -9.5980513588589789e-01
    phi[10,4]  R1927     -9.6542140874696525e-01
    phi[10,4]  R1928     -9.7750411082672217e-01
    phi[10,4]  R1929     -9.7895069552889036e-01
    phi[10,4]  R1930     -9.8321937174990626e-01
    phi[10,4]  R1931     -0.984470253738979
    phi[10,4]  R1932     -1.0070791985055618e+00
    phi[10,4]  R1933     -1.3527980606434973e+00
    phi[10,4]  R1934     -1.3076023718281868e+00
    phi[10,4]  R1935     -1.5301620983217363e+00
    phi[10,4]  R1936     -1.3443258241896627e+00
    phi[10,4]  R1937     -1.1901692683109544e+00
    phi[10,4]  R1938     -1.3041213936693890e+00
    phi[10,4]  R1939     -1.3162113443987735e+00
    phi[10,4]  R1940     -1.6313647989303557e+00
    phi[10,4]  R1941     -1.4355902311859419e+00
    phi[10,4]  R1942     -9.9260638953842417e-01
    phi[10,4]  R1943     -1.0457132163836762e+00
    phi[10,4]  R1944     -1.0522870146649219e+00
    phi[10,4]  R1945     -1.0669425124122895e+00
    phi[10,4]  R1946     -1.0773963142576204e+00
    phi[10,4]  R1947     -1.2141523224197350e+00
    phi[10,4]  R1948     -1.1390817003247289e+00
    phi[10,4]  R1949     -1.1705535848803301e+00
    phi[10,4]  R1950     -1.1741621838331651e+00
    phi[10,4]  R1951     -1.1783884419165096e+00
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R1952     -3.0999999046325684e+00
    phi[5,6]  R1953     -3.0999999046325684e+00
    phi[5,6]  R1954     -2.2400000095367432e+00
    phi[5,6]  R1955     -2.2400000095367432e+00
    phi[5,6]  R1956     -3.0999999046325684e+00
    phi[5,6]  R1957     -3.0999999046325684e+00
    phi[5,6]  R1958     -2.5699999332427979e+00
    phi[5,6]  R1959     -2.5699999332427979e+00
    phi[5,6]  R1960     -3.0999999046325684e+00
    phi[5,6]  R1961     -3.0999999046325684e+00
    phi[5,6]  R1962     -2.0899999141693115e+00
    phi[5,6]  R1963     -2.0899999141693115e+00
    phi[5,6]  R1964     -3.0999999046325684e+00
    phi[5,6]  R1965     -3.0999999046325684e+00
    phi[5,6]  R1966     2.6721320152282715e+00
    phi[5,6]  R1967     1.0542553663253784e+00
    phi[5,6]  R1968     -4.3973669409751892e-02
    phi[5,6]  R1969     -0.872677743434906
    phi[5,6]  R1970     2.6223728433251381e-02
    phi[5,6]  R1971     -5.9467816352844238e-01
    phi[5,6]  R1972     5.4028433561325073e-01
    phi[5,6]  R1973     -8.8324892520904541e-01
    phi[5,6]  R1974     -7.8803908824920654e-01
    phi[5,6]  R1975     -7.7637147903442383e-01
    phi[5,6]  R1976     -1.0009427070617676e+00
    phi[5,6]  R1977     -1.0461862087249756e+00
    phi[5,6]  R1978     -0.0729677602648735
    phi[5,6]  R1979     3.6292821168899536e-01
    phi[5,6]  R1980     -2.3945782184600830e+00
    phi[5,6]  R1981     -5.5078589916229248e-01
    phi[5,6]  R1982     -2.7807874679565430e+00
    phi[5,6]  R1983     -1.2810522317886353e+00
    phi[5,6]  R1984     -1.0457861423492432e+00
    phi[5,6]  R1985     -1.1360139846801758e+00
    phi[5,6]  R1986     -1.5627011060714722e+00
    phi[5,6]  R1987     -1.6247810125350952e+00
    phi[5,6]  R1988     -1.6776736974716187e+00
    phi[5,6]  R1989     -0.384996235370636
    phi[5,6]  R1990     -2.3753604292869568e-01
    phi[5,6]  R1991     -2.3957488536834717e+00
    phi[5,6]  R1992     -1.5398020744323730e+00
    phi[5,6]  R1993     -7.2663968801498413e-01
    phi[5,6]  R1994     -6.9553798437118530e-01
    phi[5,6]  R1995     7.8017985820770264e-01
    phi[5,6]  R1996     1.7534032464027405e-01
    phi[5,6]  R1997     4.1677209734916687e-01
    phi[5,6]  R1998     -2.6433876156806946e-01
    phi[5,6]  R1999     4.1416662931442261e-01
    phi[5,6]  R2000     7.9849791526794434e-01
    phi[5,6]  R2001     7.0265412330627441e-01
    phi[5,6]  R2002     -1.6660397052764893e+00
    phi[5,6]  R2003     -2.4984288215637207e+00
    phi[5,6]  R2004     -1.0784169435501099e+00
    phi[5,6]  R2005     -1.7382930517196655e+00
    phi[5,6]  R2006     -2.12066388130188
    phi[5,6]  R2007     -1.9051384925842285e+00
    phi[5,6]  R2008     -1.6140198707580566e+00
    phi[5,6]  R2009     -1.5744251012802124e+00
    phi[5,6]  R2010     -1.6850818395614624e+00
    phi[5,6]  R2011     3.1611672043800354e-01
    phi[5,6]  R2012     -1.8763074874877930e+00
    phi[5,6]  R2013     -1.6148170232772827e+00
    phi[5,6]  R2014     -1.7313879728317261e+00
    phi[5,6]  R2015     -7.5225436687469482e-01
    phi[5,6]  R2016     9.3377113342285156e-02
    phi[5,6]  R2017     -1.5984860062599182e-01
    phi[5,6]  R2018     -1.0631966590881348e+00
    phi[5,6]  R2019     -1.9236198663711548e+00
    phi[5,6]  R2020     -7.4860060214996338e-01
    phi[5,6]  R2021     -5.6298476457595825e-01
    phi[5,6]  R2022     -8.0460518598556519e-01
    phi[5,6]  R2023     2.0940455794334412e-01
    phi[5,6]  R2024     4.4166380167007446e-01
    phi[5,6]  R2025     -8.2428365945816040e-01
    phi[5,6]  R2026     -3.5844457149505615e-01
    phi[5,6]  R2027     -9.8664581775665283e-01
    phi[5,6]  R2028     -7.3049712181091309e-01
    phi[5,6]  R2029     -2.5130471587181091e-01
    phi[5,6]  R2030     -9.5221620798110962e-01
    phi[5,6]  R2031     -6.7736035585403442e-01
    phi[5,6]  R2032     -1.1614668369293213e+00
    phi[5,6]  R2033     3.1517696380615234e-01
    phi[5,6]  R2034     3.2856479287147522e-01
    phi[5,6]  R2035     -4.9011099338531494e-01
    phi[5,6]  R2036     -1.4613561630249023e+00
    phi[5,6]  R2037     -1.4466005563735962e+00
    phi[5,6]  R2038     -4.0588015317916870e-01
    phi[5,6]  R2039     -1.0979411602020264e+00
    phi[5,6]  R2040     -1.0142062902450562e+00
    phi[5,6]  R2041     -1.2547245025634766e+00
    phi[5,6]  R2042     -1.1315020322799683e+00
    phi[5,6]  R2043     -1.6097209453582764e+00
    phi[5,6]  R2044     9.2580340802669525e-02
    phi[5,6]  R2045     -6.2552243471145630e-01
    phi[5,6]  R2046     -3.7262561917304993e-01
    phi[5,6]  R2047     -1.3038902282714844e+00
    phi[5,6]  R2048     -1.3885991275310516e-01
    phi[5,6]  R2049     -0.553806722164154
    phi[5,6]  R2050     -1.0306549072265625e+00
    phi[5,6]  R2051     -1.7528320550918579e+00
    phi[5,6]  R2052     -1.6220990419387817e+00
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2053     -3.0999999046325684e+00
    phi[6,5]  R2054     -3.0999999046325684e+00
    phi[6,5]  R2055     -2.2400000095367432e+00
    phi[6,5]  R2056     -2.2400000095367432e+00
    phi[6,5]  R2057     -3.0999999046325684e+00
    phi[6,5]  R2058     -3.0999999046325684e+00
    phi[6,5]  R2059     -2.5699999332427979e+00
    phi[6,5]  R2060     -2.5699999332427979e+00
    phi[6,5]  R2061     -3.0999999046325684e+00
    phi[6,5]  R2062     -3.0999999046325684e+00
    phi[6,5]  R2063     -2.0899999141693115e+00
    phi[6,5]  R2064     -2.0899999141693115e+00
    phi[6,5]  R2065     -3.0999999046325684e+00
    phi[6,5]  R2066     -3.0999999046325684e+00
    phi[6,5]  R2067     -7.2663968801498413e-01
    phi[6,5]  R2068     -6.9553798437118530e-01
    phi[6,5]  R2069     7.8017985820770264e-01
    phi[6,5]  R2070     1.7534032464027405e-01
    phi[6,5]  R2071     4.1677209734916687e-01
    phi[6,5]  R2072     -2.6433876156806946e-01
    phi[6,5]  R2073     4.1416662931442261e-01
    phi[6,5]  R2074     7.9849791526794434e-01
    phi[6,5]  R2075     7.0265412330627441e-01
    phi[6,5]  R2076     -1.6660397052764893e+00
    phi[6,5]  R2077     -2.4984288215637207e+00
    phi[6,5]  R2078     -1.0784169435501099e+00
    phi[6,5]  R2079     -1.7382930517196655e+00
    phi[6,5]  R2080     -2.12066388130188
    phi[6,5]  R2081     -1.9051384925842285e+00
    phi[6,5]  R2082     -1.6140198707580566e+00
    phi[6,5]  R2083     -1.5744251012802124e+00
    phi[6,5]  R2084     -1.6850818395614624e+00
    phi[6,5]  R2085     3.1611672043800354e-01
    phi[6,5]  R2086     -1.8763074874877930e+00
    phi[6,5]  R2087     -1.6148170232772827e+00
    phi[6,5]  R2088     -1.7313879728317261e+00
    phi[6,5]  R2089     -7.5225436687469482e-01
    phi[6,5]  R2090     9.3377113342285156e-02
    phi[6,5]  R2091     -1.5984860062599182e-01
    phi[6,5]  R2092     -1.0631966590881348e+00
    phi[6,5]  R2093     -1.9236198663711548e+00
    phi[6,5]  R2094     -7.4860060214996338e-01
    phi[6,5]  R2095     -5.6298476457595825e-01
    phi[6,5]  R2096     -8.0460518598556519e-01
    phi[6,5]  R2097     2.0940455794334412e-01
    phi[6,5]  R2098     4.4166380167007446e-01
    phi[6,5]  R2099     -8.2428365945816040e-01
    phi[6,5]  R2100     -3.5844457149505615e-01
    phi[6,5]  R2101     -9.8664581775665283e-01
    phi[6,5]  R2102     -7.3049712181091309e-01
    phi[6,5]  R2103     -2.5130471587181091e-01
    phi[6,5]  R2104     -9.5221620798110962e-01
    phi[6,5]  R2105     -6.7736035585403442e-01
    phi[6,5]  R2106     -1.1614668369293213e+00
    phi[6,5]  R2107     3.1517696380615234e-01
    phi[6,5]  R2108     3.2856479287147522e-01
    phi[6,5]  R2109     -4.9011099338531494e-01
    phi[6,5]  R2110     -1.4613561630249023e+00
    phi[6,5]  R2111     -1.4466005563735962e+00
    phi[6,5]  R2112     -4.0588015317916870e-01
    phi[6,5]  R2113     -1.0979411602020264e+00
    phi[6,5]  R2114     -1.0142062902450562e+00
    phi[6,5]  R2115     -1.2547245025634766e+00
    phi[6,5]  R2116     -1.1315020322799683e+00
    phi[6,5]  R2117     -1.6097209453582764e+00
    phi[6,5]  R2118     9.2580340802669525e-02
    phi[6,5]  R2119     -6.2552243471145630e-01
    phi[6,5]  R2120     -3.7262561917304993e-01
    phi[6,5]  R2121     -1.3038902282714844e+00
    phi[6,5]  R2122     -1.3885991275310516e-01
    phi[6,5]  R2123     -0.553806722164154
    phi[6,5]  R2124     -1.0306549072265625e+00
    phi[6,5]  R2125     -1.7528320550918579e+00
    phi[6,5]  R2126     -1.6220990419387817e+00
    phi[6,5]  R2127     2.6721320152282715e+00
    phi[6,5]  R2128     1.0542553663253784e+00
    phi[6,5]  R2129     -4.3973669409751892e-02
    phi[6,5]  R2130     -0.872677743434906
    phi[6,5]  R2131     2.6223728433251381e-02
    phi[6,5]  R2132     -5.9467816352844238e-01
    phi[6,5]  R2133     5.4028433561325073e-01
    phi[6,5]  R2134     -8.8324892520904541e-01
    phi[6,5]  R2135     -7.8803908824920654e-01
    phi[6,5]  R2136     -7.7637147903442383e-01
    phi[6,5]  R2137     -1.0009427070617676e+00
    phi[6,5]  R2138     -1.0461862087249756e+00
    phi[6,5]  R2139     -0.0729677602648735
    phi[6,5]  R2140     3.6292821168899536e-01
    phi[6,5]  R2141     -2.3945782184600830e+00
    phi[6,5]  R2142     -5.5078589916229248e-01
    phi[6,5]  R2143     -2.7807874679565430e+00
    phi[6,5]  R2144     -1.2810522317886353e+00
    phi[6,5]  R2145     -1.0457861423492432e+00
    phi[6,5]  R2146     -1.1360139846801758e+00
    phi[6,5]  R2147     -1.5627011060714722e+00
    phi[6,5]  R2148     -1.6247810125350952e+00
    phi[6,5]  R2149     -1.6776736974716187e+00
    phi[6,5]  R2150     -0.384996235370636
    phi[6,5]  R2151     -2.3753604292869568e-01
    phi[6,5]  R2152     -2.3957488536834717e+00
    phi[6,5]  R2153     -1.5398020744323730e+00
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R2154     -3.0999999046325684e+00
    phi[6,7]  R2155     -3.0999999046325684e+00
    phi[6,7]  R2156     -2.2400000095367432e+00
    phi[6,7]  R2157     -2.2400000095367432e+00
    phi[6,7]  R2158     -3.0999999046325684e+00
    phi[6,7]  R2159     -3.0999999046325684e+00
    phi[6,7]  R2160     -2.5699999332427979e+00
    phi[6,7]  R2161     -2.5699999332427979e+00
    phi[6,7]  R2162     -3.0999999046325684e+00
    phi[6,7]  R2163     -3.0999999046325684e+00
    phi[6,7]  R2164     -2.0899999141693115e+00
    phi[6,7]  R2165     -2.0899999141693115e+00
    phi[6,7]  R2166     -3.0999999046325684e+00
    phi[6,7]  R2167     -3.0999999046325684e+00
    phi[6,7]  R2168     -7.2663968801498413e-01
    phi[6,7]  R2169     -6.9553798437118530e-01
    phi[6,7]  R2170     7.8017985820770264e-01
    phi[6,7]  R2171     1.7534032464027405e-01
    phi[6,7]  R2172     4.1677209734916687e-01
    phi[6,7]  R2173     -2.6433876156806946e-01
    phi[6,7]  R2174     4.1416662931442261e-01
    phi[6,7]  R2175     7.9849791526794434e-01
    phi[6,7]  R2176     7.0265412330627441e-01
    phi[6,7]  R2177     -1.6660397052764893e+00
    phi[6,7]  R2178     -2.4984288215637207e+00
    phi[6,7]  R2179     -1.0784169435501099e+00
    phi[6,7]  R2180     -1.7382930517196655e+00
    phi[6,7]  R2181     -2.12066388130188
    phi[6,7]  R2182     -1.9051384925842285e+00
    phi[6,7]  R2183     -1.6140198707580566e+00
    phi[6,7]  R2184     -1.5744251012802124e+00
    phi[6,7]  R2185     -1.6850818395614624e+00
    phi[6,7]  R2186     3.1611672043800354e-01
    phi[6,7]  R2187     -1.8763074874877930e+00
    phi[6,7]  R2188     -1.6148170232772827e+00
    phi[6,7]  R2189     -1.7313879728317261e+00
    phi[6,7]  R2190     -7.5225436687469482e-01
    phi[6,7]  R2191     9.3377113342285156e-02
    phi[6,7]  R2192     -1.5984860062599182e-01
    phi[6,7]  R2193     -1.0631966590881348e+00
    phi[6,7]  R2194     -1.9236198663711548e+00
    phi[6,7]  R2195     -7.4860060214996338e-01
    phi[6,7]  R2196     -5.6298476457595825e-01
    phi[6,7]  R2197     -8.0460518598556519e-01
    phi[6,7]  R2198     2.0940455794334412e-01
    phi[6,7]  R2199     4.4166380167007446e-01
    phi[6,7]  R2200     -8.2428365945816040e-01
    phi[6,7]  R2201     -3.5844457149505615e-01
    phi[6,7]  R2202     -9.8664581775665283e-01
    phi[6,7]  R2203     -7.3049712181091309e-01
    phi[6,7]  R2204     -2.5130471587181091e-01
    phi[6,7]  R2205     -9.5221620798110962e-01
    phi[6,7]  R2206     -6.7736035585403442e-01
    phi[6,7]  R2207     -1.1614668369293213e+00
    phi[6,7]  R2208     3.1517696380615234e-01
    phi[6,7]  R2209     3.2856479287147522e-01
    phi[6,7]  R2210     -4.9011099338531494e-01
    phi[6,7]  R2211     -1.4613561630249023e+00
    phi[6,7]  R2212     -1.4466005563735962e+00
    phi[6,7]  R2213     -4.0588015317916870e-01
    phi[6,7]  R2214     -1.0979411602020264e+00
    phi[6,7]  R2215     -1.0142062902450562e+00
    phi[6,7]  R2216     -1.2547245025634766e+00
    phi[6,7]  R2217     -1.1315020322799683e+00
    phi[6,7]  R2218     -1.6097209453582764e+00
    phi[6,7]  R2219     9.2580340802669525e-02
    phi[6,7]  R2220     -6.2552243471145630e-01
    phi[6,7]  R2221     -3.7262561917304993e-01
    phi[6,7]  R2222     -1.3038902282714844e+00
    phi[6,7]  R2223     -1.3885991275310516e-01
    phi[6,7]  R2224     -0.553806722164154
    phi[6,7]  R2225     -1.0306549072265625e+00
    phi[6,7]  R2226     -1.7528320550918579e+00
    phi[6,7]  R2227     -1.6220990419387817e+00
    phi[6,7]  R2228     1.0296105146408081e+00
    phi[6,7]  R2229     0.716434121131897
    phi[6,7]  R2230     7.6938903331756592e-01
    phi[6,7]  R2231     1.7903488874435425e-01
    phi[6,7]  R2232     6.9300276041030884e-01
    phi[6,7]  R2233     5.7272320985794067e-01
    phi[6,7]  R2234     2.2373457252979279e-01
    phi[6,7]  R2235     3.3593982458114624e-01
    phi[6,7]  R2236     1.4850615262985229e+00
    phi[6,7]  R2237     -3.7475198507308960e-01
    phi[6,7]  R2238     -1.1414517164230347e+00
    phi[6,7]  R2239     -1.7636418342590332e+00
    phi[6,7]  R2240     -1.5199061632156372e+00
    phi[6,7]  R2241     -1.3761081695556641e+00
    phi[6,7]  R2242     -9.6923089027404785e-01
    phi[6,7]  R2243     -1.0672049522399902e+00
    phi[6,7]  R2244     -1.1324710845947266e+00
    phi[6,7]  R2245     -2.0737657546997070e+00
    phi[6,7]  R2246     -1.8743268251419067e+00
    phi[6,7]  R2247     -2.5117764472961426e+00
    phi[6,7]  R2248     -5.4955464601516724e-01
    phi[6,7]  R2249     -6.4221578836441040e-01
    phi[6,7]  R2250     -1.1734766960144043e+00
    phi[6,7]  R2251     -4.7339788079261780e-01
    phi[6,7]  R2252     -1.2235152721405029e+00
    phi[6,7]  R2253     -1.2154632806777954e+00
    phi[6,7]  R2254     -9.1887158155441284e-01
    phi[6,7]  R2255     -5.7003825902938843e-02
    phi[6,7]  R2256     1.5268816053867340e-01
    phi[6,7]  R2257     -1.9405554533004761e+00
    phi[6,7]  R2258     5.3824096918106079e-01
    phi[6,7]  R2259     -4.1388472914695740e-01
    phi[6,7]  R2260     7.1118336915969849e-01
    phi[6,7]  R2261     -1.7621688842773438e+00
    phi[6,7]  R2262     -1.1822800636291504e+00
    phi[6,7]  R2263     -3.0333730578422546e-01
    phi[6,7]  R2264     1.2183914333581924e-01
    phi[6,7]  R2265     -2.4926054477691650e+00
    phi[6,7]  R2266     -1.4653894901275635e+00
    phi[6,7]  R2267     -2.7052896022796631e+00
    phi[6,7]  R2268     -1.1254521608352661e+00
    phi[6,7]  R2269     -1.0036932229995728e+00
    phi[6,7]  R2270     4.6034210920333862e-01
    phi[6,7]  R2271     0.247628316283226
    phi[6,7]  R2272     -1.8546807765960693e-01
    phi[6,7]  R2273     -2.6060185432434082e+00
    phi[6,7]  R2274     7.1393772959709167e-02
    phi[6,7]  R2275     -2.9703862667083740e+00
    phi[6,7]  R2276     -2.5672531127929688e+00
    phi[6,7]  R2277     -1.2115645408630371e+00
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R2278     -3.0999999046325684e+00
    phi[7,6]  R2279     -3.0999999046325684e+00
    phi[7,6]  R2280     -2.2400000095367432e+00
    phi[7,6]  R2281     -2.2400000095367432e+00
    phi[7,6]  R2282     -3.0999999046325684e+00
    phi[7,6]  R2283     -3.0999999046325684e+00
    phi[7,6]  R2284     -2.5699999332427979e+00
    phi[7,6]  R2285     -2.5699999332427979e+00
    phi[7,6]  R2286     -3.0999999046325684e+00
    phi[7,6]  R2287     -3.0999999046325684e+00
    phi[7,6]  R2288     -2.0899999141693115e+00
    phi[7,6]  R2289     -2.0899999141693115e+00
    phi[7,6]  R2290     -3.0999999046325684e+00
    phi[7,6]  R2291     -3.0999999046325684e+00
    phi[7,6]  R2292     1.0296105146408081e+00
    phi[7,6]  R2293     0.716434121131897
    phi[7,6]  R2294     7.6938903331756592e-01
    phi[7,6]  R2295     1.7903488874435425e-01
    phi[7,6]  R2296     6.9300276041030884e-01
    phi[7,6]  R2297     5.7272320985794067e-01
    phi[7,6]  R2298     2.2373457252979279e-01
    phi[7,6]  R2299     3.3593982458114624e-01
    phi[7,6]  R2300     1.4850615262985229e+00
    phi[7,6]  R2301     -3.7475198507308960e-01
    phi[7,6]  R2302     -1.1414517164230347e+00
    phi[7,6]  R2303     -1.7636418342590332e+00
    phi[7,6]  R2304     -1.5199061632156372e+00
    phi[7,6]  R2305     -1.3761081695556641e+00
    phi[7,6]  R2306     -9.6923089027404785e-01
    phi[7,6]  R2307     -1.0672049522399902e+00
    phi[7,6]  R2308     -1.1324710845947266e+00
    phi[7,6]  R2309     -2.0737657546997070e+00
    phi[7,6]  R2310     -1.8743268251419067e+00
    phi[7,6]  R2311     -2.5117764472961426e+00
    phi[7,6]  R2312     -5.4955464601516724e-01
    phi[7,6]  R2313     -6.4221578836441040e-01
    phi[7,6]  R2314     -1.1734766960144043e+00
    phi[7,6]  R2315     -4.7339788079261780e-01
    phi[7,6]  R2316     -1.2235152721405029e+00
    phi[7,6]  R2317     -1.2154632806777954e+00
    phi[7,6]  R2318     -9.1887158155441284e-01
    phi[7,6]  R2319     -5.7003825902938843e-02
    phi[7,6]  R2320     1.5268816053867340e-01
    phi[7,6]  R2321     -1.9405554533004761e+00
    phi[7,6]  R2322     5.3824096918106079e-01
    phi[7,6]  R2323     -4.1388472914695740e-01
    phi[7,6]  R2324     7.1118336915969849e-01
    phi[7,6]  R2325     -1.7621688842773438e+00
    phi[7,6]  R2326     -1.1822800636291504e+00
    phi[7,6]  R2327     -3.0333730578422546e-01
    phi[7,6]  R2328     1.2183914333581924e-01
    phi[7,6]  R2329     -2.4926054477691650e+00
    phi[7,6]  R2330     -1.4653894901275635e+00
    phi[7,6]  R2331     -2.7052896022796631e+00
    phi[7,6]  R2332     -1.1254521608352661e+00
    phi[7,6]  R2333     -1.0036932229995728e+00
    phi[7,6]  R2334     4.6034210920333862e-01
    phi[7,6]  R2335     0.247628316283226
    phi[7,6]  R2336     -1.8546807765960693e-01
    phi[7,6]  R2337     -2.6060185432434082e+00
    phi[7,6]  R2338     7.1393772959709167e-02
    phi[7,6]  R2339     -2.9703862667083740e+00
    phi[7,6]  R2340     -2.5672531127929688e+00
    phi[7,6]  R2341     -1.2115645408630371e+00
    phi[7,6]  R2342     -7.2663968801498413e-01
    phi[7,6]  R2343     -6.9553798437118530e-01
    phi[7,6]  R2344     7.8017985820770264e-01
    phi[7,6]  R2345     1.7534032464027405e-01
    phi[7,6]  R2346     4.1677209734916687e-01
    phi[7,6]  R2347     -2.6433876156806946e-01
    phi[7,6]  R2348     4.1416662931442261e-01
    phi[7,6]  R2349     7.9849791526794434e-01
    phi[7,6]  R2350     7.0265412330627441e-01
    phi[7,6]  R2351     -1.6660397052764893e+00
    phi[7,6]  R2352     -2.4984288215637207e+00
    phi[7,6]  R2353     -1.0784169435501099e+00
    phi[7,6]  R2354     -1.7382930517196655e+00
    phi[7,6]  R2355     -2.12066388130188
    phi[7,6]  R2356     -1.9051384925842285e+00
    phi[7,6]  R2357     -1.6140198707580566e+00
    phi[7,6]  R2358     -1.5744251012802124e+00
    phi[7,6]  R2359     -1.6850818395614624e+00
    phi[7,6]  R2360     3.1611672043800354e-01
    phi[7,6]  R2361     -1.8763074874877930e+00
    phi[7,6]  R2362     -1.6148170232772827e+00
    phi[7,6]  R2363     -1.7313879728317261e+00
    phi[7,6]  R2364     -7.5225436687469482e-01
    phi[7,6]  R2365     9.3377113342285156e-02
    phi[7,6]  R2366     -1.5984860062599182e-01
    phi[7,6]  R2367     -1.0631966590881348e+00
    phi[7,6]  R2368     -1.9236198663711548e+00
    phi[7,6]  R2369     -7.4860060214996338e-01
    phi[7,6]  R2370     -5.6298476457595825e-01
    phi[7,6]  R2371     -8.0460518598556519e-01
    phi[7,6]  R2372     2.0940455794334412e-01
    phi[7,6]  R2373     4.4166380167007446e-01
    phi[7,6]  R2374     -8.2428365945816040e-01
    phi[7,6]  R2375     -3.5844457149505615e-01
    phi[7,6]  R2376     -9.8664581775665283e-01
    phi[7,6]  R2377     -7.3049712181091309e-01
    phi[7,6]  R2378     -2.5130471587181091e-01
    phi[7,6]  R2379     -9.5221620798110962e-01
    phi[7,6]  R2380     -6.7736035585403442e-01
    phi[7,6]  R2381     -1.1614668369293213e+00
    phi[7,6]  R2382     3.1517696380615234e-01
    phi[7,6]  R2383     3.2856479287147522e-01
    phi[7,6]  R2384     -4.9011099338531494e-01
    phi[7,6]  R2385     -1.4613561630249023e+00
    phi[7,6]  R2386     -1.4466005563735962e+00
    phi[7,6]  R2387     -4.0588015317916870e-01
    phi[7,6]  R2388     -1.0979411602020264e+00
    phi[7,6]  R2389     -1.0142062902450562e+00
    phi[7,6]  R2390     -1.2547245025634766e+00
    phi[7,6]  R2391     -1.1315020322799683e+00
    phi[7,6]  R2392     -1.6097209453582764e+00
    phi[7,6]  R2393     9.2580340802669525e-02
    phi[7,6]  R2394     -6.2552243471145630e-01
    phi[7,6]  R2395     -3.7262561917304993e-01
    phi[7,6]  R2396     -1.3038902282714844e+00
    phi[7,6]  R2397     -1.3885991275310516e-01
    phi[7,6]  R2398     -0.553806722164154
    phi[7,6]  R2399     -1.0306549072265625e+00
    phi[7,6]  R2400     -1.7528320550918579e+00
    phi[7,6]  R2401     -1.6220990419387817e+00
    phi[7,8]  R63       1
    phi[7,8]  R64       1
    phi[7,8]  R72       -1
    phi[7,8]  R2402     -3.0999999046325684e+00
    phi[7,8]  R2403     -3.0999999046325684e+00
    phi[7,8]  R2404     -2.2400000095367432e+00
    phi[7,8]  R2405     -2.2400000095367432e+00
    phi[7,8]  R2406     -3.0999999046325684e+00
    phi[7,8]  R2407     -3.0999999046325684e+00
    phi[7,8]  R2408     -2.5699999332427979e+00
    phi[7,8]  R2409     -2.5699999332427979e+00
    phi[7,8]  R2410     -3.0999999046325684e+00
    phi[7,8]  R2411     -3.0999999046325684e+00
    phi[7,8]  R2412     -2.0899999141693115e+00
    phi[7,8]  R2413     -2.0899999141693115e+00
    phi[7,8]  R2414     -3.0999999046325684e+00
    phi[7,8]  R2415     -3.0999999046325684e+00
    phi[7,8]  R2416     1.0296105146408081e+00
    phi[7,8]  R2417     0.716434121131897
    phi[7,8]  R2418     7.6938903331756592e-01
    phi[7,8]  R2419     1.7903488874435425e-01
    phi[7,8]  R2420     6.9300276041030884e-01
    phi[7,8]  R2421     5.7272320985794067e-01
    phi[7,8]  R2422     2.2373457252979279e-01
    phi[7,8]  R2423     3.3593982458114624e-01
    phi[7,8]  R2424     1.4850615262985229e+00
    phi[7,8]  R2425     -3.7475198507308960e-01
    phi[7,8]  R2426     -1.1414517164230347e+00
    phi[7,8]  R2427     -1.7636418342590332e+00
    phi[7,8]  R2428     -1.5199061632156372e+00
    phi[7,8]  R2429     -1.3761081695556641e+00
    phi[7,8]  R2430     -9.6923089027404785e-01
    phi[7,8]  R2431     -1.0672049522399902e+00
    phi[7,8]  R2432     -1.1324710845947266e+00
    phi[7,8]  R2433     -2.0737657546997070e+00
    phi[7,8]  R2434     -1.8743268251419067e+00
    phi[7,8]  R2435     -2.5117764472961426e+00
    phi[7,8]  R2436     -5.4955464601516724e-01
    phi[7,8]  R2437     -6.4221578836441040e-01
    phi[7,8]  R2438     -1.1734766960144043e+00
    phi[7,8]  R2439     -4.7339788079261780e-01
    phi[7,8]  R2440     -1.2235152721405029e+00
    phi[7,8]  R2441     -1.2154632806777954e+00
    phi[7,8]  R2442     -9.1887158155441284e-01
    phi[7,8]  R2443     -5.7003825902938843e-02
    phi[7,8]  R2444     1.5268816053867340e-01
    phi[7,8]  R2445     -1.9405554533004761e+00
    phi[7,8]  R2446     5.3824096918106079e-01
    phi[7,8]  R2447     -4.1388472914695740e-01
    phi[7,8]  R2448     7.1118336915969849e-01
    phi[7,8]  R2449     -1.7621688842773438e+00
    phi[7,8]  R2450     -1.1822800636291504e+00
    phi[7,8]  R2451     -3.0333730578422546e-01
    phi[7,8]  R2452     1.2183914333581924e-01
    phi[7,8]  R2453     -2.4926054477691650e+00
    phi[7,8]  R2454     -1.4653894901275635e+00
    phi[7,8]  R2455     -2.7052896022796631e+00
    phi[7,8]  R2456     -1.1254521608352661e+00
    phi[7,8]  R2457     -1.0036932229995728e+00
    phi[7,8]  R2458     4.6034210920333862e-01
    phi[7,8]  R2459     0.247628316283226
    phi[7,8]  R2460     -1.8546807765960693e-01
    phi[7,8]  R2461     -2.6060185432434082e+00
    phi[7,8]  R2462     7.1393772959709167e-02
    phi[7,8]  R2463     -2.9703862667083740e+00
    phi[7,8]  R2464     -2.5672531127929688e+00
    phi[7,8]  R2465     -1.2115645408630371e+00
    phi[7,8]  R2466     -2.8466144204139709e-01
    phi[7,8]  R2467     1.7102469205856323e+00
    phi[7,8]  R2468     2.3981254100799561e+00
    phi[7,8]  R2469     2.2306964397430420e+00
    phi[7,8]  R2470     2.1604392528533936e+00
    phi[7,8]  R2471     1.3745080232620239e+00
    phi[7,8]  R2472     2.1568846702575684e+00
    phi[7,8]  R2473     1.8707808256149292e+00
    phi[7,8]  R2474     2.4816939830780029e+00
    phi[7,8]  R2475     2.1964952945709229e+00
    phi[7,8]  R2476     -1.3136184215545654e+00
    phi[7,8]  R2477     -1.8565570116043091e+00
    phi[7,8]  R2478     -1.5606383085250854e+00
    phi[7,8]  R2479     -2.1174800395965576e+00
    phi[7,8]  R2480     -1.4715760946273804e+00
    phi[7,8]  R2481     -1.4021667242050171e+00
    phi[7,8]  R2482     -2.3559811115264893e+00
    phi[7,8]  R2483     -1.0835347175598145e+00
    phi[7,8]  R2484     -2.1485517024993896e+00
    phi[7,8]  R2485     -2.0187778472900391e+00
    phi[7,8]  R2486     9.2508578300476074e-01
    phi[7,8]  R2487     5.5983662605285645e-01
    phi[7,8]  R2488     0.846215546131134
    phi[7,8]  R2489     1.9068424701690674e+00
    phi[7,8]  R2490     -7.5234943628311157e-01
    phi[7,8]  R2491     -4.0609243512153625e-01
    phi[7,8]  R2492     3.8269951939582825e-01
    phi[7,8]  R2493     -7.1839398145675659e-01
    phi[7,8]  R2494     -1.0407881736755371e+00
    phi[7,8]  R2495     -1.5586100816726685e+00
    phi[7,8]  R2496     7.0732039213180542e-01
    phi[7,8]  R2497     2.2568330764770508e+00
    phi[7,8]  R2498     5.8885502815246582e-01
    phi[7,8]  R2499     1.0612531565129757e-02
    phi[7,8]  R2500     1.0577993392944336e+00
    phi[7,8]  R2501     8.2408094406127930e-01
    phi[7,8]  R2502     -6.2420296669006348e-01
    phi[7,8]  R2503     -4.3171414732933044e-01
    phi[7,8]  R2504     -3.6625301837921143e-01
    phi[7,8]  R2505     -1.7514756321907043e-01
    phi[7,8]  R2506     2.0341942310333252e+00
    phi[7,8]  R2507     0.253650039434433
    phi[7,8]  R2508     0.345493346452713
    phi[7,8]  R2509     -5.7241266965866089e-01
    phi[7,8]  R2510     -3.8763836026191711e-01
    phi[7,8]  R2511     1.1232388019561768e+00
    phi[7,8]  R2512     -1.7671980857849121e+00
    phi[7,8]  R2513     -6.6737359762191772e-01
    phi[7,8]  R2514     -8.0058199167251587e-01
    phi[7,8]  R2515     -1.9614350795745850e-01
    phi[8,7]  R63       -1
    phi[8,7]  R72       1
    phi[8,7]  R73       1
    phi[8,7]  R2516     -3.0999999046325684e+00
    phi[8,7]  R2517     -3.0999999046325684e+00
    phi[8,7]  R2518     -2.2400000095367432e+00
    phi[8,7]  R2519     -2.2400000095367432e+00
    phi[8,7]  R2520     -3.0999999046325684e+00
    phi[8,7]  R2521     -3.0999999046325684e+00
    phi[8,7]  R2522     -2.5699999332427979e+00
    phi[8,7]  R2523     -2.5699999332427979e+00
    phi[8,7]  R2524     -3.0999999046325684e+00
    phi[8,7]  R2525     -3.0999999046325684e+00
    phi[8,7]  R2526     -2.0899999141693115e+00
    phi[8,7]  R2527     -2.0899999141693115e+00
    phi[8,7]  R2528     -3.0999999046325684e+00
    phi[8,7]  R2529     -3.0999999046325684e+00
    phi[8,7]  R2530     -2.8466144204139709e-01
    phi[8,7]  R2531     1.7102469205856323e+00
    phi[8,7]  R2532     2.3981254100799561e+00
    phi[8,7]  R2533     2.2306964397430420e+00
    phi[8,7]  R2534     2.1604392528533936e+00
    phi[8,7]  R2535     1.3745080232620239e+00
    phi[8,7]  R2536     2.1568846702575684e+00
    phi[8,7]  R2537     1.8707808256149292e+00
    phi[8,7]  R2538     2.4816939830780029e+00
    phi[8,7]  R2539     2.1964952945709229e+00
    phi[8,7]  R2540     -1.3136184215545654e+00
    phi[8,7]  R2541     -1.8565570116043091e+00
    phi[8,7]  R2542     -1.5606383085250854e+00
    phi[8,7]  R2543     -2.1174800395965576e+00
    phi[8,7]  R2544     -1.4715760946273804e+00
    phi[8,7]  R2545     -1.4021667242050171e+00
    phi[8,7]  R2546     -2.3559811115264893e+00
    phi[8,7]  R2547     -1.0835347175598145e+00
    phi[8,7]  R2548     -2.1485517024993896e+00
    phi[8,7]  R2549     -2.0187778472900391e+00
    phi[8,7]  R2550     9.2508578300476074e-01
    phi[8,7]  R2551     5.5983662605285645e-01
    phi[8,7]  R2552     0.846215546131134
    phi[8,7]  R2553     1.9068424701690674e+00
    phi[8,7]  R2554     -7.5234943628311157e-01
    phi[8,7]  R2555     -4.0609243512153625e-01
    phi[8,7]  R2556     3.8269951939582825e-01
    phi[8,7]  R2557     -7.1839398145675659e-01
    phi[8,7]  R2558     -1.0407881736755371e+00
    phi[8,7]  R2559     -1.5586100816726685e+00
    phi[8,7]  R2560     7.0732039213180542e-01
    phi[8,7]  R2561     2.2568330764770508e+00
    phi[8,7]  R2562     5.8885502815246582e-01
    phi[8,7]  R2563     1.0612531565129757e-02
    phi[8,7]  R2564     1.0577993392944336e+00
    phi[8,7]  R2565     8.2408094406127930e-01
    phi[8,7]  R2566     -6.2420296669006348e-01
    phi[8,7]  R2567     -4.3171414732933044e-01
    phi[8,7]  R2568     -3.6625301837921143e-01
    phi[8,7]  R2569     -1.7514756321907043e-01
    phi[8,7]  R2570     2.0341942310333252e+00
    phi[8,7]  R2571     0.253650039434433
    phi[8,7]  R2572     0.345493346452713
    phi[8,7]  R2573     -5.7241266965866089e-01
    phi[8,7]  R2574     -3.8763836026191711e-01
    phi[8,7]  R2575     1.1232388019561768e+00
    phi[8,7]  R2576     -1.7671980857849121e+00
    phi[8,7]  R2577     -6.6737359762191772e-01
    phi[8,7]  R2578     -8.0058199167251587e-01
    phi[8,7]  R2579     -1.9614350795745850e-01
    phi[8,7]  R2580     1.0296105146408081e+00
    phi[8,7]  R2581     0.716434121131897
    phi[8,7]  R2582     7.6938903331756592e-01
    phi[8,7]  R2583     1.7903488874435425e-01
    phi[8,7]  R2584     6.9300276041030884e-01
    phi[8,7]  R2585     5.7272320985794067e-01
    phi[8,7]  R2586     2.2373457252979279e-01
    phi[8,7]  R2587     3.3593982458114624e-01
    phi[8,7]  R2588     1.4850615262985229e+00
    phi[8,7]  R2589     -3.7475198507308960e-01
    phi[8,7]  R2590     -1.1414517164230347e+00
    phi[8,7]  R2591     -1.7636418342590332e+00
    phi[8,7]  R2592     -1.5199061632156372e+00
    phi[8,7]  R2593     -1.3761081695556641e+00
    phi[8,7]  R2594     -9.6923089027404785e-01
    phi[8,7]  R2595     -1.0672049522399902e+00
    phi[8,7]  R2596     -1.1324710845947266e+00
    phi[8,7]  R2597     -2.0737657546997070e+00
    phi[8,7]  R2598     -1.8743268251419067e+00
    phi[8,7]  R2599     -2.5117764472961426e+00
    phi[8,7]  R2600     -5.4955464601516724e-01
    phi[8,7]  R2601     -6.4221578836441040e-01
    phi[8,7]  R2602     -1.1734766960144043e+00
    phi[8,7]  R2603     -4.7339788079261780e-01
    phi[8,7]  R2604     -1.2235152721405029e+00
    phi[8,7]  R2605     -1.2154632806777954e+00
    phi[8,7]  R2606     -9.1887158155441284e-01
    phi[8,7]  R2607     -5.7003825902938843e-02
    phi[8,7]  R2608     1.5268816053867340e-01
    phi[8,7]  R2609     -1.9405554533004761e+00
    phi[8,7]  R2610     5.3824096918106079e-01
    phi[8,7]  R2611     -4.1388472914695740e-01
    phi[8,7]  R2612     7.1118336915969849e-01
    phi[8,7]  R2613     -1.7621688842773438e+00
    phi[8,7]  R2614     -1.1822800636291504e+00
    phi[8,7]  R2615     -3.0333730578422546e-01
    phi[8,7]  R2616     1.2183914333581924e-01
    phi[8,7]  R2617     -2.4926054477691650e+00
    phi[8,7]  R2618     -1.4653894901275635e+00
    phi[8,7]  R2619     -2.7052896022796631e+00
    phi[8,7]  R2620     -1.1254521608352661e+00
    phi[8,7]  R2621     -1.0036932229995728e+00
    phi[8,7]  R2622     4.6034210920333862e-01
    phi[8,7]  R2623     0.247628316283226
    phi[8,7]  R2624     -1.8546807765960693e-01
    phi[8,7]  R2625     -2.6060185432434082e+00
    phi[8,7]  R2626     7.1393772959709167e-02
    phi[8,7]  R2627     -2.9703862667083740e+00
    phi[8,7]  R2628     -2.5672531127929688e+00
    phi[8,7]  R2629     -1.2115645408630371e+00
    phi[8,9]  R72       1
    phi[8,9]  R73       1
    phi[8,9]  R81       -1
    phi[8,9]  R2630     -3.0999999046325684e+00
    phi[8,9]  R2631     -3.0999999046325684e+00
    phi[8,9]  R2632     -2.2400000095367432e+00
    phi[8,9]  R2633     -2.2400000095367432e+00
    phi[8,9]  R2634     -3.0999999046325684e+00
    phi[8,9]  R2635     -3.0999999046325684e+00
    phi[8,9]  R2636     -2.5699999332427979e+00
    phi[8,9]  R2637     -2.5699999332427979e+00
    phi[8,9]  R2638     -3.0999999046325684e+00
    phi[8,9]  R2639     -3.0999999046325684e+00
    phi[8,9]  R2640     -2.0899999141693115e+00
    phi[8,9]  R2641     -2.0899999141693115e+00
    phi[8,9]  R2642     -3.0999999046325684e+00
    phi[8,9]  R2643     -3.0999999046325684e+00
    phi[8,9]  R2644     -2.8466144204139709e-01
    phi[8,9]  R2645     1.7102469205856323e+00
    phi[8,9]  R2646     2.3981254100799561e+00
    phi[8,9]  R2647     2.2306964397430420e+00
    phi[8,9]  R2648     2.1604392528533936e+00
    phi[8,9]  R2649     1.3745080232620239e+00
    phi[8,9]  R2650     2.1568846702575684e+00
    phi[8,9]  R2651     1.8707808256149292e+00
    phi[8,9]  R2652     2.4816939830780029e+00
    phi[8,9]  R2653     2.1964952945709229e+00
    phi[8,9]  R2654     -1.3136184215545654e+00
    phi[8,9]  R2655     -1.8565570116043091e+00
    phi[8,9]  R2656     -1.5606383085250854e+00
    phi[8,9]  R2657     -2.1174800395965576e+00
    phi[8,9]  R2658     -1.4715760946273804e+00
    phi[8,9]  R2659     -1.4021667242050171e+00
    phi[8,9]  R2660     -2.3559811115264893e+00
    phi[8,9]  R2661     -1.0835347175598145e+00
    phi[8,9]  R2662     -2.1485517024993896e+00
    phi[8,9]  R2663     -2.0187778472900391e+00
    phi[8,9]  R2664     9.2508578300476074e-01
    phi[8,9]  R2665     5.5983662605285645e-01
    phi[8,9]  R2666     0.846215546131134
    phi[8,9]  R2667     1.9068424701690674e+00
    phi[8,9]  R2668     -7.5234943628311157e-01
    phi[8,9]  R2669     -4.0609243512153625e-01
    phi[8,9]  R2670     3.8269951939582825e-01
    phi[8,9]  R2671     -7.1839398145675659e-01
    phi[8,9]  R2672     -1.0407881736755371e+00
    phi[8,9]  R2673     -1.5586100816726685e+00
    phi[8,9]  R2674     7.0732039213180542e-01
    phi[8,9]  R2675     2.2568330764770508e+00
    phi[8,9]  R2676     5.8885502815246582e-01
    phi[8,9]  R2677     1.0612531565129757e-02
    phi[8,9]  R2678     1.0577993392944336e+00
    phi[8,9]  R2679     8.2408094406127930e-01
    phi[8,9]  R2680     -6.2420296669006348e-01
    phi[8,9]  R2681     -4.3171414732933044e-01
    phi[8,9]  R2682     -3.6625301837921143e-01
    phi[8,9]  R2683     -1.7514756321907043e-01
    phi[8,9]  R2684     2.0341942310333252e+00
    phi[8,9]  R2685     0.253650039434433
    phi[8,9]  R2686     0.345493346452713
    phi[8,9]  R2687     -5.7241266965866089e-01
    phi[8,9]  R2688     -3.8763836026191711e-01
    phi[8,9]  R2689     1.1232388019561768e+00
    phi[8,9]  R2690     -1.7671980857849121e+00
    phi[8,9]  R2691     -6.6737359762191772e-01
    phi[8,9]  R2692     -8.0058199167251587e-01
    phi[8,9]  R2693     -1.9614350795745850e-01
    phi[8,9]  R2694     1.2974705696105957e+00
    phi[8,9]  R2695     2.8136305809020996e+00
    phi[8,9]  R2696     2.4402472972869873e+00
    phi[8,9]  R2697     1.4134865999221802e+00
    phi[8,9]  R2698     2.9779784679412842e+00
    phi[8,9]  R2699     2.12259578704834
    phi[8,9]  R2700     2.0830962657928467e+00
    phi[8,9]  R2701     0.381216436624527
    phi[8,9]  R2702     -1.1279854774475098e+00
    phi[8,9]  R2703     2.8544723987579346e+00
    phi[8,9]  R2704     0.992236316204071
    phi[8,9]  R2705     1.4208384752273560e+00
    phi[8,9]  R2706     1.6217888593673706e+00
    phi[8,9]  R2707     -2.4773682653903961e-01
    phi[8,9]  R2708     -2.7843410968780518e+00
    phi[8,9]  R2709     3.4216722846031189e-01
    phi[8,9]  R2710     1.0818901062011719e+00
    phi[8,9]  R2711     1.1143224239349365e+00
    phi[8,9]  R2712     -2.4066436290740967e+00
    phi[8,9]  R2713     -2.1806011199951172e+00
    phi[8,9]  R2714     -5.0406432151794434e-01
    phi[8,9]  R2715     -1.0526057481765747e+00
    phi[8,9]  R2716     -2.3937902450561523e+00
    phi[8,9]  R2717     -3.8485014438629150e-01
    phi[8,9]  R2718     -2.1062018871307373e+00
    phi[8,9]  R2719     -2.5661602020263672e+00
    phi[8,9]  R2720     0.0856981873512268
    phi[8,9]  R2721     -8.5020077228546143e-01
    phi[8,9]  R2722     -3.2826871871948242e+00
    phi[8,9]  R2723     -1.6602747440338135e+00
    phi[8,9]  R2724     -1.2312514781951904e+00
    phi[8,9]  R2725     -2.9388968944549561e+00
    phi[8,9]  R2726     6.1100125312805176e-01
    phi[8,9]  R2727     -2.7819211483001709e+00
    phi[8,9]  R2728     -3.3829560875892639e-01
    phi[8,9]  R2729     -9.8158240318298340e-01
    phi[8,9]  R2730     -1.2275003194808960e+00
    phi[8,9]  R2731     -2.0876631736755371e+00
    phi[8,9]  R2732     -2.7935233116149902e+00
    phi[8,9]  R2733     -1.4639621973037720e+00
    phi[8,9]  R2734     -2.8015465736389160e+00
    phi[8,9]  R2735     -1.9519008398056030e+00
    phi[8,9]  R2736     6.1406806111335754e-02
    phi[8,9]  R2737     -3.5257210731506348e+00
    phi[8,9]  R2738     -7.6007091999053955e-01
    phi[8,9]  R2739     -9.0748593211174011e-02
    phi[8,9]  R2740     1.3239935636520386e+00
    phi[8,9]  R2741     1.8796644210815430e+00
    phi[8,9]  R2742     1.4418530464172363e+00
    phi[8,9]  R2743     3.1636413931846619e-01
    phi[9,8]  R72       -1
    phi[9,8]  R81       1
    phi[9,8]  R82       1
    phi[9,8]  R2744     -3.0999999046325684e+00
    phi[9,8]  R2745     -3.0999999046325684e+00
    phi[9,8]  R2746     -2.2400000095367432e+00
    phi[9,8]  R2747     -2.2400000095367432e+00
    phi[9,8]  R2748     -3.0999999046325684e+00
    phi[9,8]  R2749     -3.0999999046325684e+00
    phi[9,8]  R2750     -2.5699999332427979e+00
    phi[9,8]  R2751     -2.5699999332427979e+00
    phi[9,8]  R2752     -3.0999999046325684e+00
    phi[9,8]  R2753     -3.0999999046325684e+00
    phi[9,8]  R2754     -2.0899999141693115e+00
    phi[9,8]  R2755     -2.0899999141693115e+00
    phi[9,8]  R2756     -3.0999999046325684e+00
    phi[9,8]  R2757     -3.0999999046325684e+00
    phi[9,8]  R2758     1.2974705696105957e+00
    phi[9,8]  R2759     2.8136305809020996e+00
    phi[9,8]  R2760     2.4402472972869873e+00
    phi[9,8]  R2761     1.4134865999221802e+00
    phi[9,8]  R2762     2.9779784679412842e+00
    phi[9,8]  R2763     2.12259578704834
    phi[9,8]  R2764     2.0830962657928467e+00
    phi[9,8]  R2765     0.381216436624527
    phi[9,8]  R2766     -1.1279854774475098e+00
    phi[9,8]  R2767     2.8544723987579346e+00
    phi[9,8]  R2768     0.992236316204071
    phi[9,8]  R2769     1.4208384752273560e+00
    phi[9,8]  R2770     1.6217888593673706e+00
    phi[9,8]  R2771     -2.4773682653903961e-01
    phi[9,8]  R2772     -2.7843410968780518e+00
    phi[9,8]  R2773     3.4216722846031189e-01
    phi[9,8]  R2774     1.0818901062011719e+00
    phi[9,8]  R2775     1.1143224239349365e+00
    phi[9,8]  R2776     -2.4066436290740967e+00
    phi[9,8]  R2777     -2.1806011199951172e+00
    phi[9,8]  R2778     -5.0406432151794434e-01
    phi[9,8]  R2779     -1.0526057481765747e+00
    phi[9,8]  R2780     -2.3937902450561523e+00
    phi[9,8]  R2781     -3.8485014438629150e-01
    phi[9,8]  R2782     -2.1062018871307373e+00
    phi[9,8]  R2783     -2.5661602020263672e+00
    phi[9,8]  R2784     0.0856981873512268
    phi[9,8]  R2785     -8.5020077228546143e-01
    phi[9,8]  R2786     -3.2826871871948242e+00
    phi[9,8]  R2787     -1.6602747440338135e+00
    phi[9,8]  R2788     -1.2312514781951904e+00
    phi[9,8]  R2789     -2.9388968944549561e+00
    phi[9,8]  R2790     6.1100125312805176e-01
    phi[9,8]  R2791     -2.7819211483001709e+00
    phi[9,8]  R2792     -3.3829560875892639e-01
    phi[9,8]  R2793     -9.8158240318298340e-01
    phi[9,8]  R2794     -1.2275003194808960e+00
    phi[9,8]  R2795     -2.0876631736755371e+00
    phi[9,8]  R2796     -2.7935233116149902e+00
    phi[9,8]  R2797     -1.4639621973037720e+00
    phi[9,8]  R2798     -2.8015465736389160e+00
    phi[9,8]  R2799     -1.9519008398056030e+00
    phi[9,8]  R2800     6.1406806111335754e-02
    phi[9,8]  R2801     -3.5257210731506348e+00
    phi[9,8]  R2802     -7.6007091999053955e-01
    phi[9,8]  R2803     -9.0748593211174011e-02
    phi[9,8]  R2804     1.3239935636520386e+00
    phi[9,8]  R2805     1.8796644210815430e+00
    phi[9,8]  R2806     1.4418530464172363e+00
    phi[9,8]  R2807     3.1636413931846619e-01
    phi[9,8]  R2808     -2.8466144204139709e-01
    phi[9,8]  R2809     1.7102469205856323e+00
    phi[9,8]  R2810     2.3981254100799561e+00
    phi[9,8]  R2811     2.2306964397430420e+00
    phi[9,8]  R2812     2.1604392528533936e+00
    phi[9,8]  R2813     1.3745080232620239e+00
    phi[9,8]  R2814     2.1568846702575684e+00
    phi[9,8]  R2815     1.8707808256149292e+00
    phi[9,8]  R2816     2.4816939830780029e+00
    phi[9,8]  R2817     2.1964952945709229e+00
    phi[9,8]  R2818     -1.3136184215545654e+00
    phi[9,8]  R2819     -1.8565570116043091e+00
    phi[9,8]  R2820     -1.5606383085250854e+00
    phi[9,8]  R2821     -2.1174800395965576e+00
    phi[9,8]  R2822     -1.4715760946273804e+00
    phi[9,8]  R2823     -1.4021667242050171e+00
    phi[9,8]  R2824     -2.3559811115264893e+00
    phi[9,8]  R2825     -1.0835347175598145e+00
    phi[9,8]  R2826     -2.1485517024993896e+00
    phi[9,8]  R2827     -2.0187778472900391e+00
    phi[9,8]  R2828     9.2508578300476074e-01
    phi[9,8]  R2829     5.5983662605285645e-01
    phi[9,8]  R2830     0.846215546131134
    phi[9,8]  R2831     1.9068424701690674e+00
    phi[9,8]  R2832     -7.5234943628311157e-01
    phi[9,8]  R2833     -4.0609243512153625e-01
    phi[9,8]  R2834     3.8269951939582825e-01
    phi[9,8]  R2835     -7.1839398145675659e-01
    phi[9,8]  R2836     -1.0407881736755371e+00
    phi[9,8]  R2837     -1.5586100816726685e+00
    phi[9,8]  R2838     7.0732039213180542e-01
    phi[9,8]  R2839     2.2568330764770508e+00
    phi[9,8]  R2840     5.8885502815246582e-01
    phi[9,8]  R2841     1.0612531565129757e-02
    phi[9,8]  R2842     1.0577993392944336e+00
    phi[9,8]  R2843     8.2408094406127930e-01
    phi[9,8]  R2844     -6.2420296669006348e-01
    phi[9,8]  R2845     -4.3171414732933044e-01
    phi[9,8]  R2846     -3.6625301837921143e-01
    phi[9,8]  R2847     -1.7514756321907043e-01
    phi[9,8]  R2848     2.0341942310333252e+00
    phi[9,8]  R2849     0.253650039434433
    phi[9,8]  R2850     0.345493346452713
    phi[9,8]  R2851     -5.7241266965866089e-01
    phi[9,8]  R2852     -3.8763836026191711e-01
    phi[9,8]  R2853     1.1232388019561768e+00
    phi[9,8]  R2854     -1.7671980857849121e+00
    phi[9,8]  R2855     -6.6737359762191772e-01
    phi[9,8]  R2856     -8.0058199167251587e-01
    phi[9,8]  R2857     -1.9614350795745850e-01
    phi[9,11]  R81       1
    phi[9,11]  R82       1
    phi[9,11]  R83       1.5585360373754518e+00
    phi[9,11]  R84       -1.8418607432008236e+00
    phi[9,11]  R85       2.9731190103331193e+00
    phi[9,11]  R86       -1.5386497507623225e+00
    phi[9,11]  R87       -2.0330937445236263e+00
    phi[9,11]  R88       -1.5002020878785847e+00
    phi[9,11]  R89       1.1042864016893368e+00
    phi[9,11]  R91       -1
    phi[9,11]  R2858     -1.5414638672571166e+00
    phi[9,11]  R2859     -4.6585359420080206e+00
    phi[9,11]  R2860     -4.0818607527375672e+00
    phi[9,11]  R2861     -3.9813926633591956e-01
    phi[9,11]  R2862     -1.2688089429944904e-01
    phi[9,11]  R2863     -6.0731189149656881e+00
    phi[9,11]  R2864     -4.1086496840051208e+00
    phi[9,11]  R2865     -1.0313501824804754e+00
    phi[9,11]  R2866     -5.1330936491561943e+00
    phi[9,11]  R2867     -1.0669061601089420e+00
    phi[9,11]  R2868     -3.5902020020478962e+00
    phi[9,11]  R2869     -5.8979782629072686e-01
    phi[9,11]  R2870     -1.9957135029432316e+00
    phi[9,11]  R2871     -4.2042863063219054e+00
    phi[9,11]  R2872     -1.8540387892852506e-01
    phi[9,11]  R2873     -1.9583179641427417e-01
    phi[9,11]  R2874     -1.9832350229816198e-01
    phi[9,11]  R2875     -2.1043257550993877e-01
    phi[9,11]  R2876     -2.1450946336201238e-01
    phi[9,11]  R2877     -2.1556842879546378e-01
    phi[9,11]  R2878     -2.1594922864976951e-01
    phi[9,11]  R2879     -2.1992356642185173e-01
    phi[9,11]  R2880     -2.2326770904882076e-01
    phi[9,11]  R2881     -2.2527437971291331e-01
    phi[9,11]  R2882     -3.5743776498157631e-01
    phi[9,11]  R2883     -3.6171730121501078e-01
    phi[9,11]  R2884     -3.6753263540907954e-01
    phi[9,11]  R2885     -3.7057821987762574e-01
    phi[9,11]  R2886     -3.7469005429534707e-01
    phi[9,11]  R2887     -3.7560737950662215e-01
    phi[9,11]  R2888     -3.7670745145423212e-01
    phi[9,11]  R2889     -3.7889339794060484e-01
    phi[9,11]  R2890     -4.9696415893817658e-01
    phi[9,11]  R2891     -5.5068073325113920e-01
    phi[9,11]  R2892     -1.5221710621046164e-01
    phi[9,11]  R2893     -2.2335954696584170e-01
    phi[9,11]  R2894     -2.3070087951963592e-01
    phi[9,11]  R2895     -2.3363440879480035e-01
    phi[9,11]  R2896     -2.9001384826293819e-01
    phi[9,11]  R2897     -3.2658902449875704e-01
    phi[9,11]  R2898     -3.4680753101045791e-01
    phi[9,11]  R2899     -3.4909953376467229e-01
    phi[9,11]  R2900     -3.6226099596474892e-01
    phi[9,11]  R2901     -3.7856661560512128e-01
    phi[9,11]  R2902     -3.5391412263834954e-01
    phi[9,11]  R2903     -3.8214128930621127e-01
    phi[9,11]  R2904     -3.8432796201944286e-01
    phi[9,11]  R2905     -3.8687153173270250e-01
    phi[9,11]  R2906     -4.0166502705239815e-01
    phi[9,11]  R2907     -4.1472185550537721e-01
    phi[9,11]  R2908     -4.1900455141890103e-01
    phi[9,11]  R2909     -4.4123516472431068e-01
    phi[9,11]  R2910     -4.4329469085376250e-01
    phi[9,11]  R2911     -4.6630781469649718e-01
    phi[9,11]  R2912     -3.1679742324292048e-01
    phi[9,11]  R2913     -3.2645976931391529e-01
    phi[9,11]  R2914     -3.6430471562020855e-01
    phi[9,11]  R2915     -4.0406625186887180e-01
    phi[9,11]  R2916     -4.0708529868704718e-01
    phi[9,11]  R2917     -4.1450523860400873e-01
    phi[9,11]  R2918     -1.6903739999217060e+00
    phi[9,11]  R2919     -1.3234058262331421e+00
    phi[9,11]  R2920     -1.6647720301550160e+00
    phi[9,11]  R2921     -1.6814716473047495e+00
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R92       -1
    z[0,1,0]  R93       1
    z[0,1,0]  R106      -6.2454563379287720e-01
    z[0,1,0]  R107      -2.1516275405883789e-01
    z[0,1,0]  R108      -1.8671810626983643e-01
    z[0,1,0]  R109      2.7230393886566162e-01
    z[0,1,0]  R110      9.3057401478290558e-02
    z[0,1,0]  R111      -2.2906453907489777e-01
    z[0,1,0]  R112      2.9664814472198486e-01
    z[0,1,0]  R113      -1.0600391775369644e-01
    z[0,1,0]  R114      3.6410665512084961e-01
    z[0,1,0]  R115      6.1475169658660889e-01
    z[0,1,0]  R116      -5.8016985654830933e-01
    z[0,1,0]  R117      -3.5037016868591309e-01
    z[0,1,0]  R118      7.7599966526031494e-01
    z[0,1,0]  R119      0.85499507188797
    z[0,1,0]  R120      5.3688251972198486e-01
    z[0,1,0]  R121      6.2329494953155518e-01
    z[0,1,0]  R122      5.6046378612518311e-01
    z[0,1,0]  R123      5.1575177907943726e-01
    z[0,1,0]  R124      5.4513669013977051e-01
    z[0,1,0]  R125      6.9494730234146118e-01
    z[0,1,0]  R126      4.9062415957450867e-01
    z[0,1,0]  R127      9.5356649160385132e-01
    z[0,1,0]  R128      9.5592629909515381e-01
    z[0,1,0]  R129      0.921034038066864
    z[0,1,0]  R130      9.3095201253890991e-01
    z[0,1,0]  R131      9.5449793338775635e-01
    z[0,1,0]  R132      9.4706481695175171e-01
    z[0,1,0]  R133      0.962475597858429
    z[0,1,0]  R134      8.9228081703186035e-01
    z[0,1,0]  R135      8.8256591558456421e-01
    z[0,1,0]  R136      -5.2701896429061890e-01
    z[0,1,0]  R137      -6.6022956371307373e-01
    z[0,1,0]  R138      -3.9918488264083862e-01
    z[0,1,0]  R139      -6.3080924749374390e-01
    z[0,1,0]  R140      -3.8641642779111862e-02
    z[0,1,0]  R141      3.2748532295227051e-01
    z[0,1,0]  R142      -1.4281715452671051e-01
    z[0,1,0]  R143      2.8115930035710335e-02
    z[0,1,0]  R144      4.8787724971771240e-01
    z[0,1,0]  R145      5.6838440895080566e-01
    z[0,1,0]  R146      7.6037323474884033e-01
    z[0,1,0]  R147      7.3263001441955566e-01
    z[0,1,0]  R148      2.6938274502754211e-01
    z[0,1,0]  R149      3.2836100459098816e-01
    z[0,1,0]  R150      1.5567120909690857e-01
    z[0,1,0]  R151      -2.7634192258119583e-02
    z[0,1,0]  R152      4.6901926398277283e-01
    z[0,1,0]  R153      4.5823833346366882e-01
    z[0,1,0]  R154      4.7913977503776550e-01
    z[0,1,0]  R155      8.2334536314010620e-01
    z[0,1,0]  R156      4.3914899230003357e-01
    z[0,1,0]  R157      4.6952396631240845e-01
    z[0,1,0]  R158      2.1861717104911804e-01
    z[0,1,0]  R159      9.2060841619968414e-02
    z[0,1,0]  R160      7.0782944560050964e-02
    z[0,1,0]  R161      7.9928863048553467e-01
    z[0,1,0]  R162      7.1500462293624878e-01
    z[0,1,0]  R163      6.0705816745758057e-01
    z[0,1,0]  R164      6.2082648277282715e-01
    z[0,1,0]  R165      0.608687698841095
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R94       -1
    z[0,1,1]  R95       1
    z[0,1,1]  R106      -1.2198417633771896e-01
    z[0,1,1]  R107      9.1458439826965332e-02
    z[0,1,1]  R108      0.375693142414093
    z[0,1,1]  R109      -0.092345230281353
    z[0,1,1]  R110      -8.6846321821212769e-02
    z[0,1,1]  R111      -2.9356257990002632e-02
    z[0,1,1]  R112      -7.7912271022796631e-02
    z[0,1,1]  R113      -1.3169866800308228e-01
    z[0,1,1]  R114      7.2579711675643921e-01
    z[0,1,1]  R115      -0.264365553855896
    z[0,1,1]  R116      3.0741026997566223e-01
    z[0,1,1]  R117      -0.687488317489624
    z[0,1,1]  R118      8.6378656327724457e-02
    z[0,1,1]  R119      -2.0779383182525635e-01
    z[0,1,1]  R120      -5.7429629564285278e-01
    z[0,1,1]  R121      -3.0606836080551147e-01
    z[0,1,1]  R122      -5.4516541957855225e-01
    z[0,1,1]  R123      -0.578826367855072
    z[0,1,1]  R124      -0.551854133605957
    z[0,1,1]  R125      2.8960263729095459e-01
    z[0,1,1]  R126      -0.589694619178772
    z[0,1,1]  R127      1.0760664939880371e-01
    z[0,1,1]  R128      1.0262688994407654e-01
    z[0,1,1]  R129      1.9474224746227264e-01
    z[0,1,1]  R130      6.3625440001487732e-02
    z[0,1,1]  R131      -1.7975641787052155e-01
    z[0,1,1]  R132      -2.1268384158611298e-01
    z[0,1,1]  R133      -1.3325746357440948e-01
    z[0,1,1]  R134      7.3412582278251648e-02
    z[0,1,1]  R135      7.2798162698745728e-02
    z[0,1,1]  R136      -3.0860024690628052e-01
    z[0,1,1]  R137      -2.4361915886402130e-01
    z[0,1,1]  R138      -5.7640874385833740e-01
    z[0,1,1]  R139      -2.1130049228668213e-01
    z[0,1,1]  R140      -4.1637763381004333e-01
    z[0,1,1]  R141      -7.1816705167293549e-02
    z[0,1,1]  R142      -3.7463283538818359e-01
    z[0,1,1]  R143      7.9631936550140381e-01
    z[0,1,1]  R144      7.0636117458343506e-01
    z[0,1,1]  R145      6.2154012918472290e-01
    z[0,1,1]  R146      -2.7536764740943909e-01
    z[0,1,1]  R147      -3.1946226954460144e-01
    z[0,1,1]  R148      -3.0051156878471375e-01
    z[0,1,1]  R149      -4.9794375896453857e-01
    z[0,1,1]  R150      -4.8590126633644104e-01
    z[0,1,1]  R151      6.0431933403015137e-01
    z[0,1,1]  R152      0.425344854593277
    z[0,1,1]  R153      4.1581568121910095e-01
    z[0,1,1]  R154      5.9549266099929810e-01
    z[0,1,1]  R155      2.9417762160301208e-01
    z[0,1,1]  R156      -7.5883507728576660e-01
    z[0,1,1]  R157      6.8023461103439331e-01
    z[0,1,1]  R158      5.3482437133789062e-01
    z[0,1,1]  R159      5.6130027770996094e-01
    z[0,1,1]  R160      6.7508327960968018e-01
    z[0,1,1]  R161      2.8388798236846924e-01
    z[0,1,1]  R162      2.8720188140869141e-01
    z[0,1,1]  R163      1.7600784078240395e-02
    z[0,1,1]  R164      3.5477582365274429e-02
    z[0,1,1]  R165      2.3356939852237701e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R96       -1
    z[0,1,2]  R97       1
    z[0,1,2]  R106      -7.2457477450370789e-02
    z[0,1,2]  R107      2.5599226355552673e-01
    z[0,1,2]  R108      5.4143011569976807e-02
    z[0,1,2]  R109      3.1159085035324097e-01
    z[0,1,2]  R110      -2.4613864719867706e-01
    z[0,1,2]  R111      -2.4763885140419006e-01
    z[0,1,2]  R112      -2.2933542728424072e-01
    z[0,1,2]  R113      -2.2622874379158020e-01
    z[0,1,2]  R114      -1.3985931873321533e-01
    z[0,1,2]  R115      -1.9673401117324829e-01
    z[0,1,2]  R116      -3.4152418375015259e-01
    z[0,1,2]  R117      3.8262628018856049e-02
    z[0,1,2]  R118      -4.7878921031951904e-01
    z[0,1,2]  R119      -1.9449584186077118e-01
    z[0,1,2]  R120      1.7855939269065857e-01
    z[0,1,2]  R121      -7.1354568004608154e-02
    z[0,1,2]  R122      2.3346179723739624e-01
    z[0,1,2]  R123      3.4155708551406860e-01
    z[0,1,2]  R124      1.7298434674739838e-01
    z[0,1,2]  R125      -3.8438954949378967e-01
    z[0,1,2]  R126      2.6380854845046997e-01
    z[0,1,2]  R127      -8.6100853979587555e-02
    z[0,1,2]  R128      3.0835436191409826e-03
    z[0,1,2]  R129      -9.6009127795696259e-02
    z[0,1,2]  R130      -8.5328713059425354e-02
    z[0,1,2]  R131      4.4295042753219604e-02
    z[0,1,2]  R132      6.7133486270904541e-02
    z[0,1,2]  R133      -8.4393061697483063e-03
    z[0,1,2]  R134      -8.7759876623749733e-03
    z[0,1,2]  R135      6.8029031157493591e-02
    z[0,1,2]  R136      -7.3367103934288025e-02
    z[0,1,2]  R137      3.4189385175704956e-01
    z[0,1,2]  R138      -4.3580028414726257e-01
    z[0,1,2]  R139      -2.1349430084228516e-01
    z[0,1,2]  R140      -5.0967878103256226e-01
    z[0,1,2]  R141      0.538462221622467
    z[0,1,2]  R142      6.6521264612674713e-02
    z[0,1,2]  R143      -4.6898941509425640e-03
    z[0,1,2]  R144      1.2886713445186615e-01
    z[0,1,2]  R145      -0.078705795109272
    z[0,1,2]  R146      -1.4823172986507416e-01
    z[0,1,2]  R147      -4.1306626051664352e-02
    z[0,1,2]  R148      7.7481961250305176e-01
    z[0,1,2]  R149      2.3591910302639008e-01
    z[0,1,2]  R150      1.7579600214958191e-01
    z[0,1,2]  R151      -7.0705376565456390e-02
    z[0,1,2]  R152      -0.272341251373291
    z[0,1,2]  R153      -1.0895549505949020e-01
    z[0,1,2]  R154      2.1447060629725456e-02
    z[0,1,2]  R155      -0.137451633810997
    z[0,1,2]  R156      0.104074627161026
    z[0,1,2]  R157      1.7202684283256531e-01
    z[0,1,2]  R158      4.6460142731666565e-01
    z[0,1,2]  R159      7.0214158296585083e-01
    z[0,1,2]  R160      5.3557169437408447e-01
    z[0,1,2]  R161      -2.0220211148262024e-01
    z[0,1,2]  R162      -1.4364443719387054e-01
    z[0,1,2]  R163      -1.1826439946889877e-01
    z[0,1,2]  R164      -2.1277801692485809e-01
    z[0,1,2]  R165      -4.3242448568344116e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R98       -1
    z[0,1,3]  R99       1
    z[0,1,3]  R106      2.4540820717811584e-01
    z[0,1,3]  R107      2.5026738643646240e-01
    z[0,1,3]  R108      3.3378362655639648e-01
    z[0,1,3]  R109      -8.8093864917755127e-01
    z[0,1,3]  R110      -7.1590358018875122e-01
    z[0,1,3]  R111      -0.777795135974884
    z[0,1,3]  R112      -6.5661495923995972e-01
    z[0,1,3]  R113      -8.0041807889938354e-01
    z[0,1,3]  R114      4.3620150536298752e-02
    z[0,1,3]  R115      6.4261603355407715e-01
    z[0,1,3]  R116      -1.7590735852718353e-01
    z[0,1,3]  R117      6.1712156981229782e-02
    z[0,1,3]  R118      2.2831702232360840e-01
    z[0,1,3]  R119      3.3436343073844910e-01
    z[0,1,3]  R120      4.7726336121559143e-01
    z[0,1,3]  R121      6.6573393344879150e-01
    z[0,1,3]  R122      2.4211759865283966e-01
    z[0,1,3]  R123      2.2682611644268036e-01
    z[0,1,3]  R124      1.1412691324949265e-01
    z[0,1,3]  R125      4.5430281758308411e-01
    z[0,1,3]  R126      1.4275726675987244e-01
    z[0,1,3]  R127      7.7638953924179077e-02
    z[0,1,3]  R128      1.5241716802120209e-01
    z[0,1,3]  R129      2.5958317518234253e-01
    z[0,1,3]  R130      2.6987347006797791e-01
    z[0,1,3]  R131      2.0211806893348694e-01
    z[0,1,3]  R132      1.8949033319950104e-01
    z[0,1,3]  R133      1.6944111883640289e-01
    z[0,1,3]  R134      3.4730784595012665e-02
    z[0,1,3]  R135      0.0716017633676529
    z[0,1,3]  R136      -7.2126221656799316e-01
    z[0,1,3]  R137      -3.7648153305053711e-01
    z[0,1,3]  R138      0.108011893928051
    z[0,1,3]  R139      1.1943751573562622e-01
    z[0,1,3]  R140      -1.5580879151821136e-01
    z[0,1,3]  R141      -3.8042029738426208e-01
    z[0,1,3]  R142      3.7178599834442139e-01
    z[0,1,3]  R143      1.7014692723751068e-01
    z[0,1,3]  R144      1.1572734266519547e-01
    z[0,1,3]  R145      4.5022162795066833e-01
    z[0,1,3]  R146      -2.4338285624980927e-01
    z[0,1,3]  R147      5.6788083165884018e-02
    z[0,1,3]  R148      8.5707187652587891e-02
    z[0,1,3]  R149      7.1806603670120239e-01
    z[0,1,3]  R150      0.564498245716095
    z[0,1,3]  R151      8.1387780606746674e-02
    z[0,1,3]  R152      -3.8180518895387650e-02
    z[0,1,3]  R153      -3.8070392608642578e-01
    z[0,1,3]  R154      -3.9326062798500061e-01
    z[0,1,3]  R155      3.1312260031700134e-01
    z[0,1,3]  R156      1.9833179190754890e-02
    z[0,1,3]  R157      -3.5487979650497437e-02
    z[0,1,3]  R158      -2.7073004841804504e-01
    z[0,1,3]  R159      -9.8129108548164368e-02
    z[0,1,3]  R160      1.0215727984905243e-01
    z[0,1,3]  R161      4.4515532255172729e-01
    z[0,1,3]  R162      4.6612039208412170e-01
    z[0,1,3]  R163      6.9420111179351807e-01
    z[0,1,3]  R164      7.0787101984024048e-01
    z[0,1,3]  R165      5.2529454231262207e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R100      -1
    z[0,1,4]  R101      1
    z[0,1,4]  R106      -1.1821195483207703e-01
    z[0,1,4]  R107      0.591735303401947
    z[0,1,4]  R108      -2.9410383105278015e-01
    z[0,1,4]  R109      3.7483379244804382e-02
    z[0,1,4]  R110      4.0477314591407776e-01
    z[0,1,4]  R111      4.4546425342559814e-01
    z[0,1,4]  R112      5.2349936962127686e-01
    z[0,1,4]  R113      -2.2779973223805428e-02
    z[0,1,4]  R114      4.1214677691459656e-01
    z[0,1,4]  R115      1.6850122809410095e-01
    z[0,1,4]  R116      7.0217676460742950e-02
    z[0,1,4]  R117      1.6411077976226807e-01
    z[0,1,4]  R118      -1.9140003621578217e-01
    z[0,1,4]  R119      -1.6736832261085510e-01
    z[0,1,4]  R120      -2.9139450192451477e-01
    z[0,1,4]  R121      5.8200877159833908e-02
    z[0,1,4]  R122      -4.4286602735519409e-01
    z[0,1,4]  R123      -3.1714653968811035e-01
    z[0,1,4]  R124      -5.7771116495132446e-01
    z[0,1,4]  R125      -4.7654006630182266e-02
    z[0,1,4]  R126      -5.2831107378005981e-01
    z[0,1,4]  R127      -2.0501524209976196e-01
    z[0,1,4]  R128      1.9915629923343658e-01
    z[0,1,4]  R129      -2.8473852202296257e-02
    z[0,1,4]  R130      2.1903726737946272e-03
    z[0,1,4]  R131      -1.1289543658494949e-01
    z[0,1,4]  R132      1.2465568631887436e-01
    z[0,1,4]  R133      5.7221110910177231e-02
    z[0,1,4]  R134      0.257347047328949
    z[0,1,4]  R135      1.5537488460540771e-01
    z[0,1,4]  R136      1.8563615158200264e-02
    z[0,1,4]  R137      4.8742804676294327e-02
    z[0,1,4]  R138      2.1600225567817688e-01
    z[0,1,4]  R139      -6.3330513238906860e-01
    z[0,1,4]  R140      -6.1474514007568359e-01
    z[0,1,4]  R141      6.2007820606231689e-01
    z[0,1,4]  R142      1.1409016698598862e-01
    z[0,1,4]  R143      2.7734309434890747e-01
    z[0,1,4]  R144      -2.7945801615715027e-01
    z[0,1,4]  R145      -1.0434918105602264e-01
    z[0,1,4]  R146      -0.00574418343603611
    z[0,1,4]  R147      -2.4857813119888306e-01
    z[0,1,4]  R148      -4.4940817356109619e-01
    z[0,1,4]  R149      -3.0068006366491318e-02
    z[0,1,4]  R150      1.5575060248374939e-01
    z[0,1,4]  R151      -2.9704365134239197e-01
    z[0,1,4]  R152      4.6199128031730652e-01
    z[0,1,4]  R153      5.6697374582290649e-01
    z[0,1,4]  R154      1.7257489264011383e-01
    z[0,1,4]  R155      3.1518572568893433e-01
    z[0,1,4]  R156      0.251932293176651
    z[0,1,4]  R157      -3.6011943221092224e-01
    z[0,1,4]  R158      4.5508152246475220e-01
    z[0,1,4]  R159      1.9532330334186554e-01
    z[0,1,4]  R160      1.0214227437973022e-01
    z[0,1,4]  R161      1.1158791929483414e-01
    z[0,1,4]  R162      3.6181509494781494e-01
    z[0,1,4]  R163      1.6459262371063232e-01
    z[0,1,4]  R164      6.1250500380992889e-02
    z[0,1,4]  R165      -0.228758305311203
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R102      -1
    z[0,1,5]  R103      1
    z[0,1,5]  R106      5.8409845829010010e-01
    z[0,1,5]  R107      2.4263417720794678e-01
    z[0,1,5]  R108      4.6235557645559311e-02
    z[0,1,5]  R109      -1.5295599400997162e-01
    z[0,1,5]  R110      -2.7444693446159363e-01
    z[0,1,5]  R111      -2.3713716864585876e-01
    z[0,1,5]  R112      -2.0201796293258667e-01
    z[0,1,5]  R113      -1.4302644133567810e-01
    z[0,1,5]  R114      3.7544753402471542e-02
    z[0,1,5]  R115      -1.6571731865406036e-01
    z[0,1,5]  R116      -6.3504314422607422e-01
    z[0,1,5]  R117      -6.0359042882919312e-01
    z[0,1,5]  R118      2.6212185621261597e-01
    z[0,1,5]  R119      -2.0011414587497711e-01
    z[0,1,5]  R120      1.8095028400421143e-01
    z[0,1,5]  R121      1.8670941889286041e-01
    z[0,1,5]  R122      2.8173556923866272e-01
    z[0,1,5]  R123      3.2619115710258484e-01
    z[0,1,5]  R124      1.0473755002021790e-01
    z[0,1,5]  R125      -1.0862807929515839e-01
    z[0,1,5]  R126      2.0497329533100128e-01
    z[0,1,5]  R127      3.5855319350957870e-02
    z[0,1,5]  R128      -4.4855102896690369e-02
    z[0,1,5]  R129      1.7670363187789917e-01
    z[0,1,5]  R130      -2.0046514272689819e-01
    z[0,1,5]  R131      1.2309648096561432e-02
    z[0,1,5]  R132      -5.4346998222172260e-03
    z[0,1,5]  R133      -1.4700774848461151e-01
    z[0,1,5]  R134      0.254652202129364
    z[0,1,5]  R135      4.0324357151985168e-01
    z[0,1,5]  R136      3.4723851829767227e-02
    z[0,1,5]  R137      -3.2207381725311279e-01
    z[0,1,5]  R138      -4.2285212874412537e-01
    z[0,1,5]  R139      -2.9673242568969727e-01
    z[0,1,5]  R140      -1.4082315564155579e-01
    z[0,1,5]  R141      -2.5233942270278931e-01
    z[0,1,5]  R142      8.2357627153396606e-01
    z[0,1,5]  R143      -5.0738650560379028e-01
    z[0,1,5]  R144      -2.7238273620605469e-01
    z[0,1,5]  R145      -2.3493853211402893e-01
    z[0,1,5]  R146      5.1415461301803589e-01
    z[0,1,5]  R147      1.5697108209133148e-01
    z[0,1,5]  R148      9.9229268729686737e-02
    z[0,1,5]  R149      5.0024546682834625e-02
    z[0,1,5]  R150      2.0019714534282684e-01
    z[0,1,5]  R151      4.6729168295860291e-01
    z[0,1,5]  R152      0.555384635925293
    z[0,1,5]  R153      2.6711070537567139e-01
    z[0,1,5]  R154      -3.8205191493034363e-02
    z[0,1,5]  R155      1.2230596691370010e-01
    z[0,1,5]  R156      9.9092327058315277e-02
    z[0,1,5]  R157      3.7132516503334045e-01
    z[0,1,5]  R158      2.4346999824047089e-01
    z[0,1,5]  R159      3.6300173401832581e-01
    z[0,1,5]  R160      3.1244638562202454e-01
    z[0,1,5]  R161      -1.0658074170351028e-01
    z[0,1,5]  R162      -1.8484708666801453e-01
    z[0,1,5]  R163      2.6160871982574463e-01
    z[0,1,5]  R164      4.0985457599163055e-02
    z[0,1,5]  R165      2.9875887557864189e-02
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R104      -1
    z[0,1,6]  R105      1
    z[0,1,6]  R106      4.1766279935836792e-01
    z[0,1,6]  R107      -6.3886815309524536e-01
    z[0,1,6]  R108      -7.8804391622543335e-01
    z[0,1,6]  R109      -1.3921412825584412e-01
    z[0,1,6]  R110      -4.1416588425636292e-01
    z[0,1,6]  R111      1.6032749414443970e-01
    z[0,1,6]  R112      3.2761093974113464e-01
    z[0,1,6]  R113      -5.0852197408676147e-01
    z[0,1,6]  R114      3.8458669185638428e-01
    z[0,1,6]  R115      2.1136872470378876e-01
    z[0,1,6]  R116      1.1449547111988068e-01
    z[0,1,6]  R117      8.9856550097465515e-02
    z[0,1,6]  R118      6.0445945709943771e-02
    z[0,1,6]  R119      9.0110331773757935e-02
    z[0,1,6]  R120      -6.7995168268680573e-02
    z[0,1,6]  R121      1.7687472701072693e-01
    z[0,1,6]  R122      6.6615156829357147e-03
    z[0,1,6]  R123      -1.5448690950870514e-01
    z[0,1,6]  R124      1.0302581638097763e-01
    z[0,1,6]  R125      2.5487509369850159e-01
    z[0,1,6]  R126      -2.1142115816473961e-02
    z[0,1,6]  R127      1.4957828819751740e-01
    z[0,1,6]  R128      -1.0371533036231995e-01
    z[0,1,6]  R129      7.1663707494735718e-02
    z[0,1,6]  R130      -0.0947442501783371
    z[0,1,6]  R131      3.0178219079971313e-02
    z[0,1,6]  R132      4.3031446635723114e-02
    z[0,1,6]  R133      4.7075446695089340e-02
    z[0,1,6]  R134      2.5707420706748962e-01
    z[0,1,6]  R135      1.3883855938911438e-01
    z[0,1,6]  R136      3.1601378321647644e-01
    z[0,1,6]  R137      -3.7417837977409363e-01
    z[0,1,6]  R138      2.8522792458534241e-01
    z[0,1,6]  R139      0.0919843465089798
    z[0,1,6]  R140      -3.7860912084579468e-01
    z[0,1,6]  R141      6.9010592997074127e-02
    z[0,1,6]  R142      7.2863809764385223e-02
    z[0,1,6]  R143      4.1865069419145584e-02
    z[0,1,6]  R144      -2.8414955735206604e-01
    z[0,1,6]  R145      -0.125092551112175
    z[0,1,6]  R146      2.0233482122421265e-02
    z[0,1,6]  R147      5.1945644617080688e-01
    z[0,1,6]  R148      1.3274191319942474e-01
    z[0,1,6]  R149      -2.6371926069259644e-01
    z[0,1,6]  R150      -5.7075989246368408e-01
    z[0,1,6]  R151      5.6197410821914673e-01
    z[0,1,6]  R152      -3.9840653538703918e-02
    z[0,1,6]  R153      -2.5980910658836365e-01
    z[0,1,6]  R154      4.7901767492294312e-01
    z[0,1,6]  R155      6.5745405852794647e-02
    z[0,1,6]  R156      -3.8314926624298096e-01
    z[0,1,6]  R157      1.3567297160625458e-01
    z[0,1,6]  R158      3.3263084292411804e-01
    z[0,1,6]  R159      -6.2555171549320221e-02
    z[0,1,6]  R160      3.6595532298088074e-01
    z[0,1,6]  R161      -1.3298501074314117e-01
    z[0,1,6]  R162      5.7471200823783875e-02
    z[0,1,6]  R163      -1.9934695959091187e-01
    z[0,1,6]  R164      -2.4804943799972534e-01
    z[0,1,6]  R165      2.4247968196868896e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R166      -1
    z[1,0,0]  R167      1
    z[1,0,0]  R180      -5.2701896429061890e-01
    z[1,0,0]  R181      -6.6022956371307373e-01
    z[1,0,0]  R182      -3.9918488264083862e-01
    z[1,0,0]  R183      -6.3080924749374390e-01
    z[1,0,0]  R184      -3.8641642779111862e-02
    z[1,0,0]  R185      3.2748532295227051e-01
    z[1,0,0]  R186      -1.4281715452671051e-01
    z[1,0,0]  R187      2.8115930035710335e-02
    z[1,0,0]  R188      4.8787724971771240e-01
    z[1,0,0]  R189      5.6838440895080566e-01
    z[1,0,0]  R190      7.6037323474884033e-01
    z[1,0,0]  R191      7.3263001441955566e-01
    z[1,0,0]  R192      2.6938274502754211e-01
    z[1,0,0]  R193      3.2836100459098816e-01
    z[1,0,0]  R194      1.5567120909690857e-01
    z[1,0,0]  R195      -2.7634192258119583e-02
    z[1,0,0]  R196      4.6901926398277283e-01
    z[1,0,0]  R197      4.5823833346366882e-01
    z[1,0,0]  R198      4.7913977503776550e-01
    z[1,0,0]  R199      8.2334536314010620e-01
    z[1,0,0]  R200      4.3914899230003357e-01
    z[1,0,0]  R201      4.6952396631240845e-01
    z[1,0,0]  R202      2.1861717104911804e-01
    z[1,0,0]  R203      9.2060841619968414e-02
    z[1,0,0]  R204      7.0782944560050964e-02
    z[1,0,0]  R205      7.9928863048553467e-01
    z[1,0,0]  R206      7.1500462293624878e-01
    z[1,0,0]  R207      6.0705816745758057e-01
    z[1,0,0]  R208      6.2082648277282715e-01
    z[1,0,0]  R209      0.608687698841095
    z[1,0,0]  R210      -6.2454563379287720e-01
    z[1,0,0]  R211      -2.1516275405883789e-01
    z[1,0,0]  R212      -1.8671810626983643e-01
    z[1,0,0]  R213      2.7230393886566162e-01
    z[1,0,0]  R214      9.3057401478290558e-02
    z[1,0,0]  R215      -2.2906453907489777e-01
    z[1,0,0]  R216      2.9664814472198486e-01
    z[1,0,0]  R217      -1.0600391775369644e-01
    z[1,0,0]  R218      3.6410665512084961e-01
    z[1,0,0]  R219      6.1475169658660889e-01
    z[1,0,0]  R220      -5.8016985654830933e-01
    z[1,0,0]  R221      -3.5037016868591309e-01
    z[1,0,0]  R222      7.7599966526031494e-01
    z[1,0,0]  R223      0.85499507188797
    z[1,0,0]  R224      5.3688251972198486e-01
    z[1,0,0]  R225      6.2329494953155518e-01
    z[1,0,0]  R226      5.6046378612518311e-01
    z[1,0,0]  R227      5.1575177907943726e-01
    z[1,0,0]  R228      5.4513669013977051e-01
    z[1,0,0]  R229      6.9494730234146118e-01
    z[1,0,0]  R230      4.9062415957450867e-01
    z[1,0,0]  R231      9.5356649160385132e-01
    z[1,0,0]  R232      9.5592629909515381e-01
    z[1,0,0]  R233      0.921034038066864
    z[1,0,0]  R234      9.3095201253890991e-01
    z[1,0,0]  R235      9.5449793338775635e-01
    z[1,0,0]  R236      9.4706481695175171e-01
    z[1,0,0]  R237      0.962475597858429
    z[1,0,0]  R238      8.9228081703186035e-01
    z[1,0,0]  R239      8.8256591558456421e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R168      -1
    z[1,0,1]  R169      1
    z[1,0,1]  R180      -3.0860024690628052e-01
    z[1,0,1]  R181      -2.4361915886402130e-01
    z[1,0,1]  R182      -5.7640874385833740e-01
    z[1,0,1]  R183      -2.1130049228668213e-01
    z[1,0,1]  R184      -4.1637763381004333e-01
    z[1,0,1]  R185      -7.1816705167293549e-02
    z[1,0,1]  R186      -3.7463283538818359e-01
    z[1,0,1]  R187      7.9631936550140381e-01
    z[1,0,1]  R188      7.0636117458343506e-01
    z[1,0,1]  R189      6.2154012918472290e-01
    z[1,0,1]  R190      -2.7536764740943909e-01
    z[1,0,1]  R191      -3.1946226954460144e-01
    z[1,0,1]  R192      -3.0051156878471375e-01
    z[1,0,1]  R193      -4.9794375896453857e-01
    z[1,0,1]  R194      -4.8590126633644104e-01
    z[1,0,1]  R195      6.0431933403015137e-01
    z[1,0,1]  R196      0.425344854593277
    z[1,0,1]  R197      4.1581568121910095e-01
    z[1,0,1]  R198      5.9549266099929810e-01
    z[1,0,1]  R199      2.9417762160301208e-01
    z[1,0,1]  R200      -7.5883507728576660e-01
    z[1,0,1]  R201      6.8023461103439331e-01
    z[1,0,1]  R202      5.3482437133789062e-01
    z[1,0,1]  R203      5.6130027770996094e-01
    z[1,0,1]  R204      6.7508327960968018e-01
    z[1,0,1]  R205      2.8388798236846924e-01
    z[1,0,1]  R206      2.8720188140869141e-01
    z[1,0,1]  R207      1.7600784078240395e-02
    z[1,0,1]  R208      3.5477582365274429e-02
    z[1,0,1]  R209      2.3356939852237701e-01
    z[1,0,1]  R210      -1.2198417633771896e-01
    z[1,0,1]  R211      9.1458439826965332e-02
    z[1,0,1]  R212      0.375693142414093
    z[1,0,1]  R213      -0.092345230281353
    z[1,0,1]  R214      -8.6846321821212769e-02
    z[1,0,1]  R215      -2.9356257990002632e-02
    z[1,0,1]  R216      -7.7912271022796631e-02
    z[1,0,1]  R217      -1.3169866800308228e-01
    z[1,0,1]  R218      7.2579711675643921e-01
    z[1,0,1]  R219      -0.264365553855896
    z[1,0,1]  R220      3.0741026997566223e-01
    z[1,0,1]  R221      -0.687488317489624
    z[1,0,1]  R222      8.6378656327724457e-02
    z[1,0,1]  R223      -2.0779383182525635e-01
    z[1,0,1]  R224      -5.7429629564285278e-01
    z[1,0,1]  R225      -3.0606836080551147e-01
    z[1,0,1]  R226      -5.4516541957855225e-01
    z[1,0,1]  R227      -0.578826367855072
    z[1,0,1]  R228      -0.551854133605957
    z[1,0,1]  R229      2.8960263729095459e-01
    z[1,0,1]  R230      -0.589694619178772
    z[1,0,1]  R231      1.0760664939880371e-01
    z[1,0,1]  R232      1.0262688994407654e-01
    z[1,0,1]  R233      1.9474224746227264e-01
    z[1,0,1]  R234      6.3625440001487732e-02
    z[1,0,1]  R235      -1.7975641787052155e-01
    z[1,0,1]  R236      -2.1268384158611298e-01
    z[1,0,1]  R237      -1.3325746357440948e-01
    z[1,0,1]  R238      7.3412582278251648e-02
    z[1,0,1]  R239      7.2798162698745728e-02
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R170      -1
    z[1,0,2]  R171      1
    z[1,0,2]  R180      -7.3367103934288025e-02
    z[1,0,2]  R181      3.4189385175704956e-01
    z[1,0,2]  R182      -4.3580028414726257e-01
    z[1,0,2]  R183      -2.1349430084228516e-01
    z[1,0,2]  R184      -5.0967878103256226e-01
    z[1,0,2]  R185      0.538462221622467
    z[1,0,2]  R186      6.6521264612674713e-02
    z[1,0,2]  R187      -4.6898941509425640e-03
    z[1,0,2]  R188      1.2886713445186615e-01
    z[1,0,2]  R189      -0.078705795109272
    z[1,0,2]  R190      -1.4823172986507416e-01
    z[1,0,2]  R191      -4.1306626051664352e-02
    z[1,0,2]  R192      7.7481961250305176e-01
    z[1,0,2]  R193      2.3591910302639008e-01
    z[1,0,2]  R194      1.7579600214958191e-01
    z[1,0,2]  R195      -7.0705376565456390e-02
    z[1,0,2]  R196      -0.272341251373291
    z[1,0,2]  R197      -1.0895549505949020e-01
    z[1,0,2]  R198      2.1447060629725456e-02
    z[1,0,2]  R199      -0.137451633810997
    z[1,0,2]  R200      0.104074627161026
    z[1,0,2]  R201      1.7202684283256531e-01
    z[1,0,2]  R202      4.6460142731666565e-01
    z[1,0,2]  R203      7.0214158296585083e-01
    z[1,0,2]  R204      5.3557169437408447e-01
    z[1,0,2]  R205      -2.0220211148262024e-01
    z[1,0,2]  R206      -1.4364443719387054e-01
    z[1,0,2]  R207      -1.1826439946889877e-01
    z[1,0,2]  R208      -2.1277801692485809e-01
    z[1,0,2]  R209      -4.3242448568344116e-01
    z[1,0,2]  R210      -7.2457477450370789e-02
    z[1,0,2]  R211      2.5599226355552673e-01
    z[1,0,2]  R212      5.4143011569976807e-02
    z[1,0,2]  R213      3.1159085035324097e-01
    z[1,0,2]  R214      -2.4613864719867706e-01
    z[1,0,2]  R215      -2.4763885140419006e-01
    z[1,0,2]  R216      -2.2933542728424072e-01
    z[1,0,2]  R217      -2.2622874379158020e-01
    z[1,0,2]  R218      -1.3985931873321533e-01
    z[1,0,2]  R219      -1.9673401117324829e-01
    z[1,0,2]  R220      -3.4152418375015259e-01
    z[1,0,2]  R221      3.8262628018856049e-02
    z[1,0,2]  R222      -4.7878921031951904e-01
    z[1,0,2]  R223      -1.9449584186077118e-01
    z[1,0,2]  R224      1.7855939269065857e-01
    z[1,0,2]  R225      -7.1354568004608154e-02
    z[1,0,2]  R226      2.3346179723739624e-01
    z[1,0,2]  R227      3.4155708551406860e-01
    z[1,0,2]  R228      1.7298434674739838e-01
    z[1,0,2]  R229      -3.8438954949378967e-01
    z[1,0,2]  R230      2.6380854845046997e-01
    z[1,0,2]  R231      -8.6100853979587555e-02
    z[1,0,2]  R232      3.0835436191409826e-03
    z[1,0,2]  R233      -9.6009127795696259e-02
    z[1,0,2]  R234      -8.5328713059425354e-02
    z[1,0,2]  R235      4.4295042753219604e-02
    z[1,0,2]  R236      6.7133486270904541e-02
    z[1,0,2]  R237      -8.4393061697483063e-03
    z[1,0,2]  R238      -8.7759876623749733e-03
    z[1,0,2]  R239      6.8029031157493591e-02
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R172      -1
    z[1,0,3]  R173      1
    z[1,0,3]  R180      -7.2126221656799316e-01
    z[1,0,3]  R181      -3.7648153305053711e-01
    z[1,0,3]  R182      0.108011893928051
    z[1,0,3]  R183      1.1943751573562622e-01
    z[1,0,3]  R184      -1.5580879151821136e-01
    z[1,0,3]  R185      -3.8042029738426208e-01
    z[1,0,3]  R186      3.7178599834442139e-01
    z[1,0,3]  R187      1.7014692723751068e-01
    z[1,0,3]  R188      1.1572734266519547e-01
    z[1,0,3]  R189      4.5022162795066833e-01
    z[1,0,3]  R190      -2.4338285624980927e-01
    z[1,0,3]  R191      5.6788083165884018e-02
    z[1,0,3]  R192      8.5707187652587891e-02
    z[1,0,3]  R193      7.1806603670120239e-01
    z[1,0,3]  R194      0.564498245716095
    z[1,0,3]  R195      8.1387780606746674e-02
    z[1,0,3]  R196      -3.8180518895387650e-02
    z[1,0,3]  R197      -3.8070392608642578e-01
    z[1,0,3]  R198      -3.9326062798500061e-01
    z[1,0,3]  R199      3.1312260031700134e-01
    z[1,0,3]  R200      1.9833179190754890e-02
    z[1,0,3]  R201      -3.5487979650497437e-02
    z[1,0,3]  R202      -2.7073004841804504e-01
    z[1,0,3]  R203      -9.8129108548164368e-02
    z[1,0,3]  R204      1.0215727984905243e-01
    z[1,0,3]  R205      4.4515532255172729e-01
    z[1,0,3]  R206      4.6612039208412170e-01
    z[1,0,3]  R207      6.9420111179351807e-01
    z[1,0,3]  R208      7.0787101984024048e-01
    z[1,0,3]  R209      5.2529454231262207e-01
    z[1,0,3]  R210      2.4540820717811584e-01
    z[1,0,3]  R211      2.5026738643646240e-01
    z[1,0,3]  R212      3.3378362655639648e-01
    z[1,0,3]  R213      -8.8093864917755127e-01
    z[1,0,3]  R214      -7.1590358018875122e-01
    z[1,0,3]  R215      -0.777795135974884
    z[1,0,3]  R216      -6.5661495923995972e-01
    z[1,0,3]  R217      -8.0041807889938354e-01
    z[1,0,3]  R218      4.3620150536298752e-02
    z[1,0,3]  R219      6.4261603355407715e-01
    z[1,0,3]  R220      -1.7590735852718353e-01
    z[1,0,3]  R221      6.1712156981229782e-02
    z[1,0,3]  R222      2.2831702232360840e-01
    z[1,0,3]  R223      3.3436343073844910e-01
    z[1,0,3]  R224      4.7726336121559143e-01
    z[1,0,3]  R225      6.6573393344879150e-01
    z[1,0,3]  R226      2.4211759865283966e-01
    z[1,0,3]  R227      2.2682611644268036e-01
    z[1,0,3]  R228      1.1412691324949265e-01
    z[1,0,3]  R229      4.5430281758308411e-01
    z[1,0,3]  R230      1.4275726675987244e-01
    z[1,0,3]  R231      7.7638953924179077e-02
    z[1,0,3]  R232      1.5241716802120209e-01
    z[1,0,3]  R233      2.5958317518234253e-01
    z[1,0,3]  R234      2.6987347006797791e-01
    z[1,0,3]  R235      2.0211806893348694e-01
    z[1,0,3]  R236      1.8949033319950104e-01
    z[1,0,3]  R237      1.6944111883640289e-01
    z[1,0,3]  R238      3.4730784595012665e-02
    z[1,0,3]  R239      0.0716017633676529
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R174      -1
    z[1,0,4]  R175      1
    z[1,0,4]  R180      1.8563615158200264e-02
    z[1,0,4]  R181      4.8742804676294327e-02
    z[1,0,4]  R182      2.1600225567817688e-01
    z[1,0,4]  R183      -6.3330513238906860e-01
    z[1,0,4]  R184      -6.1474514007568359e-01
    z[1,0,4]  R185      6.2007820606231689e-01
    z[1,0,4]  R186      1.1409016698598862e-01
    z[1,0,4]  R187      2.7734309434890747e-01
    z[1,0,4]  R188      -2.7945801615715027e-01
    z[1,0,4]  R189      -1.0434918105602264e-01
    z[1,0,4]  R190      -0.00574418343603611
    z[1,0,4]  R191      -2.4857813119888306e-01
    z[1,0,4]  R192      -4.4940817356109619e-01
    z[1,0,4]  R193      -3.0068006366491318e-02
    z[1,0,4]  R194      1.5575060248374939e-01
    z[1,0,4]  R195      -2.9704365134239197e-01
    z[1,0,4]  R196      4.6199128031730652e-01
    z[1,0,4]  R197      5.6697374582290649e-01
    z[1,0,4]  R198      1.7257489264011383e-01
    z[1,0,4]  R199      3.1518572568893433e-01
    z[1,0,4]  R200      0.251932293176651
    z[1,0,4]  R201      -3.6011943221092224e-01
    z[1,0,4]  R202      4.5508152246475220e-01
    z[1,0,4]  R203      1.9532330334186554e-01
    z[1,0,4]  R204      1.0214227437973022e-01
    z[1,0,4]  R205      1.1158791929483414e-01
    z[1,0,4]  R206      3.6181509494781494e-01
    z[1,0,4]  R207      1.6459262371063232e-01
    z[1,0,4]  R208      6.1250500380992889e-02
    z[1,0,4]  R209      -0.228758305311203
    z[1,0,4]  R210      -1.1821195483207703e-01
    z[1,0,4]  R211      0.591735303401947
    z[1,0,4]  R212      -2.9410383105278015e-01
    z[1,0,4]  R213      3.7483379244804382e-02
    z[1,0,4]  R214      4.0477314591407776e-01
    z[1,0,4]  R215      4.4546425342559814e-01
    z[1,0,4]  R216      5.2349936962127686e-01
    z[1,0,4]  R217      -2.2779973223805428e-02
    z[1,0,4]  R218      4.1214677691459656e-01
    z[1,0,4]  R219      1.6850122809410095e-01
    z[1,0,4]  R220      7.0217676460742950e-02
    z[1,0,4]  R221      1.6411077976226807e-01
    z[1,0,4]  R222      -1.9140003621578217e-01
    z[1,0,4]  R223      -1.6736832261085510e-01
    z[1,0,4]  R224      -2.9139450192451477e-01
    z[1,0,4]  R225      5.8200877159833908e-02
    z[1,0,4]  R226      -4.4286602735519409e-01
    z[1,0,4]  R227      -3.1714653968811035e-01
    z[1,0,4]  R228      -5.7771116495132446e-01
    z[1,0,4]  R229      -4.7654006630182266e-02
    z[1,0,4]  R230      -5.2831107378005981e-01
    z[1,0,4]  R231      -2.0501524209976196e-01
    z[1,0,4]  R232      1.9915629923343658e-01
    z[1,0,4]  R233      -2.8473852202296257e-02
    z[1,0,4]  R234      2.1903726737946272e-03
    z[1,0,4]  R235      -1.1289543658494949e-01
    z[1,0,4]  R236      1.2465568631887436e-01
    z[1,0,4]  R237      5.7221110910177231e-02
    z[1,0,4]  R238      0.257347047328949
    z[1,0,4]  R239      1.5537488460540771e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R176      -1
    z[1,0,5]  R177      1
    z[1,0,5]  R180      3.4723851829767227e-02
    z[1,0,5]  R181      -3.2207381725311279e-01
    z[1,0,5]  R182      -4.2285212874412537e-01
    z[1,0,5]  R183      -2.9673242568969727e-01
    z[1,0,5]  R184      -1.4082315564155579e-01
    z[1,0,5]  R185      -2.5233942270278931e-01
    z[1,0,5]  R186      8.2357627153396606e-01
    z[1,0,5]  R187      -5.0738650560379028e-01
    z[1,0,5]  R188      -2.7238273620605469e-01
    z[1,0,5]  R189      -2.3493853211402893e-01
    z[1,0,5]  R190      5.1415461301803589e-01
    z[1,0,5]  R191      1.5697108209133148e-01
    z[1,0,5]  R192      9.9229268729686737e-02
    z[1,0,5]  R193      5.0024546682834625e-02
    z[1,0,5]  R194      2.0019714534282684e-01
    z[1,0,5]  R195      4.6729168295860291e-01
    z[1,0,5]  R196      0.555384635925293
    z[1,0,5]  R197      2.6711070537567139e-01
    z[1,0,5]  R198      -3.8205191493034363e-02
    z[1,0,5]  R199      1.2230596691370010e-01
    z[1,0,5]  R200      9.9092327058315277e-02
    z[1,0,5]  R201      3.7132516503334045e-01
    z[1,0,5]  R202      2.4346999824047089e-01
    z[1,0,5]  R203      3.6300173401832581e-01
    z[1,0,5]  R204      3.1244638562202454e-01
    z[1,0,5]  R205      -1.0658074170351028e-01
    z[1,0,5]  R206      -1.8484708666801453e-01
    z[1,0,5]  R207      2.6160871982574463e-01
    z[1,0,5]  R208      4.0985457599163055e-02
    z[1,0,5]  R209      2.9875887557864189e-02
    z[1,0,5]  R210      5.8409845829010010e-01
    z[1,0,5]  R211      2.4263417720794678e-01
    z[1,0,5]  R212      4.6235557645559311e-02
    z[1,0,5]  R213      -1.5295599400997162e-01
    z[1,0,5]  R214      -2.7444693446159363e-01
    z[1,0,5]  R215      -2.3713716864585876e-01
    z[1,0,5]  R216      -2.0201796293258667e-01
    z[1,0,5]  R217      -1.4302644133567810e-01
    z[1,0,5]  R218      3.7544753402471542e-02
    z[1,0,5]  R219      -1.6571731865406036e-01
    z[1,0,5]  R220      -6.3504314422607422e-01
    z[1,0,5]  R221      -6.0359042882919312e-01
    z[1,0,5]  R222      2.6212185621261597e-01
    z[1,0,5]  R223      -2.0011414587497711e-01
    z[1,0,5]  R224      1.8095028400421143e-01
    z[1,0,5]  R225      1.8670941889286041e-01
    z[1,0,5]  R226      2.8173556923866272e-01
    z[1,0,5]  R227      3.2619115710258484e-01
    z[1,0,5]  R228      1.0473755002021790e-01
    z[1,0,5]  R229      -1.0862807929515839e-01
    z[1,0,5]  R230      2.0497329533100128e-01
    z[1,0,5]  R231      3.5855319350957870e-02
    z[1,0,5]  R232      -4.4855102896690369e-02
    z[1,0,5]  R233      1.7670363187789917e-01
    z[1,0,5]  R234      -2.0046514272689819e-01
    z[1,0,5]  R235      1.2309648096561432e-02
    z[1,0,5]  R236      -5.4346998222172260e-03
    z[1,0,5]  R237      -1.4700774848461151e-01
    z[1,0,5]  R238      0.254652202129364
    z[1,0,5]  R239      4.0324357151985168e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R178      -1
    z[1,0,6]  R179      1
    z[1,0,6]  R180      3.1601378321647644e-01
    z[1,0,6]  R181      -3.7417837977409363e-01
    z[1,0,6]  R182      2.8522792458534241e-01
    z[1,0,6]  R183      0.0919843465089798
    z[1,0,6]  R184      -3.7860912084579468e-01
    z[1,0,6]  R185      6.9010592997074127e-02
    z[1,0,6]  R186      7.2863809764385223e-02
    z[1,0,6]  R187      4.1865069419145584e-02
    z[1,0,6]  R188      -2.8414955735206604e-01
    z[1,0,6]  R189      -0.125092551112175
    z[1,0,6]  R190      2.0233482122421265e-02
    z[1,0,6]  R191      5.1945644617080688e-01
    z[1,0,6]  R192      1.3274191319942474e-01
    z[1,0,6]  R193      -2.6371926069259644e-01
    z[1,0,6]  R194      -5.7075989246368408e-01
    z[1,0,6]  R195      5.6197410821914673e-01
    z[1,0,6]  R196      -3.9840653538703918e-02
    z[1,0,6]  R197      -2.5980910658836365e-01
    z[1,0,6]  R198      4.7901767492294312e-01
    z[1,0,6]  R199      6.5745405852794647e-02
    z[1,0,6]  R200      -3.8314926624298096e-01
    z[1,0,6]  R201      1.3567297160625458e-01
    z[1,0,6]  R202      3.3263084292411804e-01
    z[1,0,6]  R203      -6.2555171549320221e-02
    z[1,0,6]  R204      3.6595532298088074e-01
    z[1,0,6]  R205      -1.3298501074314117e-01
    z[1,0,6]  R206      5.7471200823783875e-02
    z[1,0,6]  R207      -1.9934695959091187e-01
    z[1,0,6]  R208      -2.4804943799972534e-01
    z[1,0,6]  R209      2.4247968196868896e-01
    z[1,0,6]  R210      4.1766279935836792e-01
    z[1,0,6]  R211      -6.3886815309524536e-01
    z[1,0,6]  R212      -7.8804391622543335e-01
    z[1,0,6]  R213      -1.3921412825584412e-01
    z[1,0,6]  R214      -4.1416588425636292e-01
    z[1,0,6]  R215      1.6032749414443970e-01
    z[1,0,6]  R216      3.2761093974113464e-01
    z[1,0,6]  R217      -5.0852197408676147e-01
    z[1,0,6]  R218      3.8458669185638428e-01
    z[1,0,6]  R219      2.1136872470378876e-01
    z[1,0,6]  R220      1.1449547111988068e-01
    z[1,0,6]  R221      8.9856550097465515e-02
    z[1,0,6]  R222      6.0445945709943771e-02
    z[1,0,6]  R223      9.0110331773757935e-02
    z[1,0,6]  R224      -6.7995168268680573e-02
    z[1,0,6]  R225      1.7687472701072693e-01
    z[1,0,6]  R226      6.6615156829357147e-03
    z[1,0,6]  R227      -1.5448690950870514e-01
    z[1,0,6]  R228      1.0302581638097763e-01
    z[1,0,6]  R229      2.5487509369850159e-01
    z[1,0,6]  R230      -2.1142115816473961e-02
    z[1,0,6]  R231      1.4957828819751740e-01
    z[1,0,6]  R232      -1.0371533036231995e-01
    z[1,0,6]  R233      7.1663707494735718e-02
    z[1,0,6]  R234      -0.0947442501783371
    z[1,0,6]  R235      3.0178219079971313e-02
    z[1,0,6]  R236      4.3031446635723114e-02
    z[1,0,6]  R237      4.7075446695089340e-02
    z[1,0,6]  R238      2.5707420706748962e-01
    z[1,0,6]  R239      1.3883855938911438e-01
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R240      -1
    z[0,4,0]  R241      1
    z[0,4,0]  R254      -6.2454563379287720e-01
    z[0,4,0]  R255      -2.1516275405883789e-01
    z[0,4,0]  R256      -1.8671810626983643e-01
    z[0,4,0]  R257      2.7230393886566162e-01
    z[0,4,0]  R258      9.3057401478290558e-02
    z[0,4,0]  R259      -2.2906453907489777e-01
    z[0,4,0]  R260      2.9664814472198486e-01
    z[0,4,0]  R261      -1.0600391775369644e-01
    z[0,4,0]  R262      3.6410665512084961e-01
    z[0,4,0]  R263      6.1475169658660889e-01
    z[0,4,0]  R264      -5.8016985654830933e-01
    z[0,4,0]  R265      -3.5037016868591309e-01
    z[0,4,0]  R266      7.7599966526031494e-01
    z[0,4,0]  R267      0.85499507188797
    z[0,4,0]  R268      5.3688251972198486e-01
    z[0,4,0]  R269      6.2329494953155518e-01
    z[0,4,0]  R270      5.6046378612518311e-01
    z[0,4,0]  R271      5.1575177907943726e-01
    z[0,4,0]  R272      5.4513669013977051e-01
    z[0,4,0]  R273      6.9494730234146118e-01
    z[0,4,0]  R274      4.9062415957450867e-01
    z[0,4,0]  R275      9.5356649160385132e-01
    z[0,4,0]  R276      9.5592629909515381e-01
    z[0,4,0]  R277      0.921034038066864
    z[0,4,0]  R278      9.3095201253890991e-01
    z[0,4,0]  R279      9.5449793338775635e-01
    z[0,4,0]  R280      9.4706481695175171e-01
    z[0,4,0]  R281      0.962475597858429
    z[0,4,0]  R282      8.9228081703186035e-01
    z[0,4,0]  R283      8.8256591558456421e-01
    z[0,4,0]  R284      -5.7972317934036255e-01
    z[0,4,0]  R285      -7.6502150297164917e-01
    z[0,4,0]  R286      -7.1177893877029419e-01
    z[0,4,0]  R287      -7.0715343952178955e-01
    z[0,4,0]  R288      -5.0080770254135132e-01
    z[0,4,0]  R289      -7.7686232328414917e-01
    z[0,4,0]  R290      -4.0485724806785583e-01
    z[0,4,0]  R291      -7.1330323815345764e-02
    z[0,4,0]  R292      -2.0989847183227539e-01
    z[0,4,0]  R293      4.5504495501518250e-01
    z[0,4,0]  R294      2.0747885107994080e-01
    z[0,4,0]  R295      -4.9686175584793091e-01
    z[0,4,0]  R296      5.3532477468252182e-02
    z[0,4,0]  R297      8.8198864459991455e-01
    z[0,4,0]  R298      8.8591843843460083e-01
    z[0,4,0]  R299      8.7120288610458374e-01
    z[0,4,0]  R300      4.3611773848533630e-01
    z[0,4,0]  R301      3.5592919588088989e-01
    z[0,4,0]  R302      0.86301189661026
    z[0,4,0]  R303      8.7381732463836670e-01
    z[0,4,0]  R304      5.0713205337524414e-01
    z[0,4,0]  R305      -3.0775934457778931e-01
    z[0,4,0]  R306      -1.3161900639533997e-01
    z[0,4,0]  R307      -1.0995452851057053e-01
    z[0,4,0]  R308      -1.9690018892288208e-01
    z[0,4,0]  R309      -1.0541586577892303e-01
    z[0,4,0]  R310      -9.6146740019321442e-02
    z[0,4,0]  R311      7.6432503759860992e-02
    z[0,4,0]  R312      -1.5052518248558044e-01
    z[0,4,0]  R313      -0.0409589558839798
    z[0,4,0]  R314      4.5085424184799194e-01
    z[0,4,0]  R315      0.948215126991272
    z[0,4,0]  R316      4.6942993998527527e-01
    z[0,4,0]  R317      6.2622010707855225e-01
    z[0,4,0]  R318      6.5410810708999634e-01
    z[0,4,0]  R319      5.8166539669036865e-01
    z[0,4,0]  R320      6.3407623767852783e-01
    z[0,4,0]  R321      4.1721984744071960e-01
    z[0,4,0]  R322      8.5299199819564819e-01
    z[0,4,0]  R323      6.1620497703552246e-01
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R242      -1
    z[0,4,1]  R243      1
    z[0,4,1]  R254      -1.2198417633771896e-01
    z[0,4,1]  R255      9.1458439826965332e-02
    z[0,4,1]  R256      0.375693142414093
    z[0,4,1]  R257      -0.092345230281353
    z[0,4,1]  R258      -8.6846321821212769e-02
    z[0,4,1]  R259      -2.9356257990002632e-02
    z[0,4,1]  R260      -7.7912271022796631e-02
    z[0,4,1]  R261      -1.3169866800308228e-01
    z[0,4,1]  R262      7.2579711675643921e-01
    z[0,4,1]  R263      -0.264365553855896
    z[0,4,1]  R264      3.0741026997566223e-01
    z[0,4,1]  R265      -0.687488317489624
    z[0,4,1]  R266      8.6378656327724457e-02
    z[0,4,1]  R267      -2.0779383182525635e-01
    z[0,4,1]  R268      -5.7429629564285278e-01
    z[0,4,1]  R269      -3.0606836080551147e-01
    z[0,4,1]  R270      -5.4516541957855225e-01
    z[0,4,1]  R271      -0.578826367855072
    z[0,4,1]  R272      -0.551854133605957
    z[0,4,1]  R273      2.8960263729095459e-01
    z[0,4,1]  R274      -0.589694619178772
    z[0,4,1]  R275      1.0760664939880371e-01
    z[0,4,1]  R276      1.0262688994407654e-01
    z[0,4,1]  R277      1.9474224746227264e-01
    z[0,4,1]  R278      6.3625440001487732e-02
    z[0,4,1]  R279      -1.7975641787052155e-01
    z[0,4,1]  R280      -2.1268384158611298e-01
    z[0,4,1]  R281      -1.3325746357440948e-01
    z[0,4,1]  R282      7.3412582278251648e-02
    z[0,4,1]  R283      7.2798162698745728e-02
    z[0,4,1]  R284      -2.7955442667007446e-01
    z[0,4,1]  R285      -3.3829516172409058e-01
    z[0,4,1]  R286      -8.5102990269660950e-02
    z[0,4,1]  R287      -0.592068076133728
    z[0,4,1]  R288      -3.8465267419815063e-01
    z[0,4,1]  R289      -1.9518250226974487e-01
    z[0,4,1]  R290      -2.2412414848804474e-01
    z[0,4,1]  R291      3.2590541243553162e-01
    z[0,4,1]  R292      -5.7407461106777191e-02
    z[0,4,1]  R293      -4.4644474983215332e-01
    z[0,4,1]  R294      -8.5024875402450562e-01
    z[0,4,1]  R295      8.8031284511089325e-02
    z[0,4,1]  R296      -5.8409631252288818e-01
    z[0,4,1]  R297      -3.9237055182456970e-01
    z[0,4,1]  R298      -3.1708675622940063e-01
    z[0,4,1]  R299      -3.9633682370185852e-01
    z[0,4,1]  R300      -6.8332219123840332e-01
    z[0,4,1]  R301      -4.9160975217819214e-01
    z[0,4,1]  R302      -3.3863878250122070e-01
    z[0,4,1]  R303      -2.8951865434646606e-01
    z[0,4,1]  R304      -6.7540162801742554e-01
    z[0,4,1]  R305      9.2551183700561523e-01
    z[0,4,1]  R306      9.6815145015716553e-01
    z[0,4,1]  R307      9.6989828348159790e-01
    z[0,4,1]  R308      9.1882050037384033e-01
    z[0,4,1]  R309      9.4148808717727661e-01
    z[0,4,1]  R310      0.953998327255249
    z[0,4,1]  R311      9.8180347681045532e-01
    z[0,4,1]  R312      0.920976459980011
    z[0,4,1]  R313      9.7002464532852173e-01
    z[0,4,1]  R314      -3.8136070966720581e-01
    z[0,4,1]  R315      -6.7426353693008423e-02
    z[0,4,1]  R316      -6.6137647628784180e-01
    z[0,4,1]  R317      2.0332412421703339e-01
    z[0,4,1]  R318      -2.2642524540424347e-01
    z[0,4,1]  R319      3.0499300360679626e-01
    z[0,4,1]  R320      -1.1251514405012131e-01
    z[0,4,1]  R321      5.1701503992080688e-01
    z[0,4,1]  R322      1.4222370088100433e-01
    z[0,4,1]  R323      -3.2608166337013245e-01
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R244      -1
    z[0,4,2]  R245      1
    z[0,4,2]  R254      -7.2457477450370789e-02
    z[0,4,2]  R255      2.5599226355552673e-01
    z[0,4,2]  R256      5.4143011569976807e-02
    z[0,4,2]  R257      3.1159085035324097e-01
    z[0,4,2]  R258      -2.4613864719867706e-01
    z[0,4,2]  R259      -2.4763885140419006e-01
    z[0,4,2]  R260      -2.2933542728424072e-01
    z[0,4,2]  R261      -2.2622874379158020e-01
    z[0,4,2]  R262      -1.3985931873321533e-01
    z[0,4,2]  R263      -1.9673401117324829e-01
    z[0,4,2]  R264      -3.4152418375015259e-01
    z[0,4,2]  R265      3.8262628018856049e-02
    z[0,4,2]  R266      -4.7878921031951904e-01
    z[0,4,2]  R267      -1.9449584186077118e-01
    z[0,4,2]  R268      1.7855939269065857e-01
    z[0,4,2]  R269      -7.1354568004608154e-02
    z[0,4,2]  R270      2.3346179723739624e-01
    z[0,4,2]  R271      3.4155708551406860e-01
    z[0,4,2]  R272      1.7298434674739838e-01
    z[0,4,2]  R273      -3.8438954949378967e-01
    z[0,4,2]  R274      2.6380854845046997e-01
    z[0,4,2]  R275      -8.6100853979587555e-02
    z[0,4,2]  R276      3.0835436191409826e-03
    z[0,4,2]  R277      -9.6009127795696259e-02
    z[0,4,2]  R278      -8.5328713059425354e-02
    z[0,4,2]  R279      4.4295042753219604e-02
    z[0,4,2]  R280      6.7133486270904541e-02
    z[0,4,2]  R281      -8.4393061697483063e-03
    z[0,4,2]  R282      -8.7759876623749733e-03
    z[0,4,2]  R283      6.8029031157493591e-02
    z[0,4,2]  R284      -1.7431795597076416e-01
    z[0,4,2]  R285      -2.6106369495391846e-01
    z[0,4,2]  R286      -4.4017231464385986e-01
    z[0,4,2]  R287      -4.7031562775373459e-02
    z[0,4,2]  R288      -1.5521739423274994e-01
    z[0,4,2]  R289      -3.0772429704666138e-01
    z[0,4,2]  R290      -8.2980763912200928e-01
    z[0,4,2]  R291      -5.1815962791442871e-01
    z[0,4,2]  R292      -3.4970918297767639e-01
    z[0,4,2]  R293      -1.2851508334279060e-02
    z[0,4,2]  R294      -0.064329132437706
    z[0,4,2]  R295      -2.6872813701629639e-01
    z[0,4,2]  R296      -1.1712085455656052e-01
    z[0,4,2]  R297      5.8494519442319870e-02
    z[0,4,2]  R298      -7.0008113980293274e-02
    z[0,4,2]  R299      6.9923967123031616e-02
    z[0,4,2]  R300      -1.6761665046215057e-01
    z[0,4,2]  R301      -1.7568540573120117e-01
    z[0,4,2]  R302      -3.3721212297677994e-02
    z[0,4,2]  R303      -2.4386551976203918e-01
    z[0,4,2]  R304      3.9617738127708435e-01
    z[0,4,2]  R305      1.8921536207199097e-01
    z[0,4,2]  R306      -9.0488076210021973e-02
    z[0,4,2]  R307      -3.3312514424324036e-02
    z[0,4,2]  R308      1.2171571701765060e-01
    z[0,4,2]  R309      -2.3459148406982422e-01
    z[0,4,2]  R310      7.2983093559741974e-02
    z[0,4,2]  R311      1.1208556592464447e-01
    z[0,4,2]  R312      1.4783999323844910e-01
    z[0,4,2]  R313      -0.0674082413315773
    z[0,4,2]  R314      -1.7220650613307953e-01
    z[0,4,2]  R315      2.4402961134910583e-01
    z[0,4,2]  R316      3.4998139739036560e-01
    z[0,4,2]  R317      3.4280881285667419e-01
    z[0,4,2]  R318      3.6785191297531128e-01
    z[0,4,2]  R319      2.2790899872779846e-01
    z[0,4,2]  R320      3.0890521407127380e-01
    z[0,4,2]  R321      -4.8213177919387817e-01
    z[0,4,2]  R322      1.6244347393512726e-01
    z[0,4,2]  R323      1.2620979547500610e-01
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R246      -1
    z[0,4,3]  R247      1
    z[0,4,3]  R254      2.4540820717811584e-01
    z[0,4,3]  R255      2.5026738643646240e-01
    z[0,4,3]  R256      3.3378362655639648e-01
    z[0,4,3]  R257      -8.8093864917755127e-01
    z[0,4,3]  R258      -7.1590358018875122e-01
    z[0,4,3]  R259      -0.777795135974884
    z[0,4,3]  R260      -6.5661495923995972e-01
    z[0,4,3]  R261      -8.0041807889938354e-01
    z[0,4,3]  R262      4.3620150536298752e-02
    z[0,4,3]  R263      6.4261603355407715e-01
    z[0,4,3]  R264      -1.7590735852718353e-01
    z[0,4,3]  R265      6.1712156981229782e-02
    z[0,4,3]  R266      2.2831702232360840e-01
    z[0,4,3]  R267      3.3436343073844910e-01
    z[0,4,3]  R268      4.7726336121559143e-01
    z[0,4,3]  R269      6.6573393344879150e-01
    z[0,4,3]  R270      2.4211759865283966e-01
    z[0,4,3]  R271      2.2682611644268036e-01
    z[0,4,3]  R272      1.1412691324949265e-01
    z[0,4,3]  R273      4.5430281758308411e-01
    z[0,4,3]  R274      1.4275726675987244e-01
    z[0,4,3]  R275      7.7638953924179077e-02
    z[0,4,3]  R276      1.5241716802120209e-01
    z[0,4,3]  R277      2.5958317518234253e-01
    z[0,4,3]  R278      2.6987347006797791e-01
    z[0,4,3]  R279      2.0211806893348694e-01
    z[0,4,3]  R280      1.8949033319950104e-01
    z[0,4,3]  R281      1.6944111883640289e-01
    z[0,4,3]  R282      3.4730784595012665e-02
    z[0,4,3]  R283      0.0716017633676529
    z[0,4,3]  R284      0.00803461018949747
    z[0,4,3]  R285      -3.0085292458534241e-01
    z[0,4,3]  R286      -2.5804473087191582e-02
    z[0,4,3]  R287      1.1786479502916336e-01
    z[0,4,3]  R288      -9.9384687840938568e-02
    z[0,4,3]  R289      8.4044739603996277e-02
    z[0,4,3]  R290      -1.6016146540641785e-01
    z[0,4,3]  R291      4.8659469932317734e-02
    z[0,4,3]  R292      2.2356024384498596e-01
    z[0,4,3]  R293      7.8668624162673950e-02
    z[0,4,3]  R294      2.5957694649696350e-01
    z[0,4,3]  R295      0.396978497505188
    z[0,4,3]  R296      2.1976348757743835e-01
    z[0,4,3]  R297      1.8401291966438293e-01
    z[0,4,3]  R298      0.0713120549917221
    z[0,4,3]  R299      1.6418716311454773e-01
    z[0,4,3]  R300      1.6098621487617493e-01
    z[0,4,3]  R301      3.1258836388587952e-01
    z[0,4,3]  R302      -6.4314864575862885e-02
    z[0,4,3]  R303      -2.0116370916366577e-01
    z[0,4,3]  R304      1.2760446965694427e-01
    z[0,4,3]  R305      -3.3711224794387817e-02
    z[0,4,3]  R306      -1.4838449656963348e-01
    z[0,4,3]  R307      1.4235946536064148e-01
    z[0,4,3]  R308      -1.6547230188734829e-04
    z[0,4,3]  R309      -1.0569803416728973e-01
    z[0,4,3]  R310      -2.0552964508533478e-01
    z[0,4,3]  R311      -9.1635994613170624e-02
    z[0,4,3]  R312      3.3478941768407822e-02
    z[0,4,3]  R313      1.0103969275951385e-01
    z[0,4,3]  R314      4.3513849377632141e-01
    z[0,4,3]  R315      1.8716195598244667e-02
    z[0,4,3]  R316      4.1821590065956116e-01
    z[0,4,3]  R317      3.3363819122314453e-01
    z[0,4,3]  R318      -3.4760600328445435e-01
    z[0,4,3]  R319      2.4602463841438293e-01
    z[0,4,3]  R320      -3.1204387545585632e-01
    z[0,4,3]  R321      1.8816350400447845e-01
    z[0,4,3]  R322      1.6779004037380219e-01
    z[0,4,3]  R323      -0.586354672908783
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R248      -1
    z[0,4,4]  R249      1
    z[0,4,4]  R254      -1.1821195483207703e-01
    z[0,4,4]  R255      0.591735303401947
    z[0,4,4]  R256      -2.9410383105278015e-01
    z[0,4,4]  R257      3.7483379244804382e-02
    z[0,4,4]  R258      4.0477314591407776e-01
    z[0,4,4]  R259      4.4546425342559814e-01
    z[0,4,4]  R260      5.2349936962127686e-01
    z[0,4,4]  R261      -2.2779973223805428e-02
    z[0,4,4]  R262      4.1214677691459656e-01
    z[0,4,4]  R263      1.6850122809410095e-01
    z[0,4,4]  R264      7.0217676460742950e-02
    z[0,4,4]  R265      1.6411077976226807e-01
    z[0,4,4]  R266      -1.9140003621578217e-01
    z[0,4,4]  R267      -1.6736832261085510e-01
    z[0,4,4]  R268      -2.9139450192451477e-01
    z[0,4,4]  R269      5.8200877159833908e-02
    z[0,4,4]  R270      -4.4286602735519409e-01
    z[0,4,4]  R271      -3.1714653968811035e-01
    z[0,4,4]  R272      -5.7771116495132446e-01
    z[0,4,4]  R273      -4.7654006630182266e-02
    z[0,4,4]  R274      -5.2831107378005981e-01
    z[0,4,4]  R275      -2.0501524209976196e-01
    z[0,4,4]  R276      1.9915629923343658e-01
    z[0,4,4]  R277      -2.8473852202296257e-02
    z[0,4,4]  R278      2.1903726737946272e-03
    z[0,4,4]  R279      -1.1289543658494949e-01
    z[0,4,4]  R280      1.2465568631887436e-01
    z[0,4,4]  R281      5.7221110910177231e-02
    z[0,4,4]  R282      0.257347047328949
    z[0,4,4]  R283      1.5537488460540771e-01
    z[0,4,4]  R284      4.1871714591979980e-01
    z[0,4,4]  R285      9.4915606081485748e-02
    z[0,4,4]  R286      6.2939259223639965e-03
    z[0,4,4]  R287      1.9346331059932709e-01
    z[0,4,4]  R288      7.2424495220184326e-01
    z[0,4,4]  R289      2.2348937392234802e-01
    z[0,4,4]  R290      1.6697567701339722e-01
    z[0,4,4]  R291      -0.338199257850647
    z[0,4,4]  R292      -6.8334378302097321e-02
    z[0,4,4]  R293      -5.3270375728607178e-01
    z[0,4,4]  R294      -3.9284810423851013e-01
    z[0,4,4]  R295      -3.8132596015930176e-01
    z[0,4,4]  R296      -5.3212392330169678e-01
    z[0,4,4]  R297      2.1966744214296341e-02
    z[0,4,4]  R298      0.299346387386322
    z[0,4,4]  R299      7.1223303675651550e-02
    z[0,4,4]  R300      -0.164293110370636
    z[0,4,4]  R301      -5.6559962034225464e-01
    z[0,4,4]  R302      -1.1556020379066467e-01
    z[0,4,4]  R303      -7.6886273920536041e-02
    z[0,4,4]  R304      0.273183673620224
    z[0,4,4]  R305      -4.2394332587718964e-02
    z[0,4,4]  R306      -7.9268120229244232e-02
    z[0,4,4]  R307      1.0167615860700607e-01
    z[0,4,4]  R308      2.5087258219718933e-01
    z[0,4,4]  R309      1.3830369710922241e-01
    z[0,4,4]  R310      1.6467517614364624e-01
    z[0,4,4]  R311      5.8026801794767380e-02
    z[0,4,4]  R312      -2.1456320583820343e-01
    z[0,4,4]  R313      -1.4798012375831604e-01
    z[0,4,4]  R314      -3.0146420001983643e-01
    z[0,4,4]  R315      1.8179299309849739e-02
    z[0,4,4]  R316      1.8484836816787720e-01
    z[0,4,4]  R317      -5.3182154893875122e-01
    z[0,4,4]  R318      -2.0608678460121155e-01
    z[0,4,4]  R319      -6.4921277761459351e-01
    z[0,4,4]  R320      -3.2309678196907043e-01
    z[0,4,4]  R321      4.6985435485839844e-01
    z[0,4,4]  R322      -3.9330765604972839e-01
    z[0,4,4]  R323      -1.2006111443042755e-01
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R250      -1
    z[0,4,5]  R251      1
    z[0,4,5]  R254      5.8409845829010010e-01
    z[0,4,5]  R255      2.4263417720794678e-01
    z[0,4,5]  R256      4.6235557645559311e-02
    z[0,4,5]  R257      -1.5295599400997162e-01
    z[0,4,5]  R258      -2.7444693446159363e-01
    z[0,4,5]  R259      -2.3713716864585876e-01
    z[0,4,5]  R260      -2.0201796293258667e-01
    z[0,4,5]  R261      -1.4302644133567810e-01
    z[0,4,5]  R262      3.7544753402471542e-02
    z[0,4,5]  R263      -1.6571731865406036e-01
    z[0,4,5]  R264      -6.3504314422607422e-01
    z[0,4,5]  R265      -6.0359042882919312e-01
    z[0,4,5]  R266      2.6212185621261597e-01
    z[0,4,5]  R267      -2.0011414587497711e-01
    z[0,4,5]  R268      1.8095028400421143e-01
    z[0,4,5]  R269      1.8670941889286041e-01
    z[0,4,5]  R270      2.8173556923866272e-01
    z[0,4,5]  R271      3.2619115710258484e-01
    z[0,4,5]  R272      1.0473755002021790e-01
    z[0,4,5]  R273      -1.0862807929515839e-01
    z[0,4,5]  R274      2.0497329533100128e-01
    z[0,4,5]  R275      3.5855319350957870e-02
    z[0,4,5]  R276      -4.4855102896690369e-02
    z[0,4,5]  R277      1.7670363187789917e-01
    z[0,4,5]  R278      -2.0046514272689819e-01
    z[0,4,5]  R279      1.2309648096561432e-02
    z[0,4,5]  R280      -5.4346998222172260e-03
    z[0,4,5]  R281      -1.4700774848461151e-01
    z[0,4,5]  R282      0.254652202129364
    z[0,4,5]  R283      4.0324357151985168e-01
    z[0,4,5]  R284      6.1594814062118530e-01
    z[0,4,5]  R285      3.4515982866287231e-01
    z[0,4,5]  R286      4.8304164409637451e-01
    z[0,4,5]  R287      2.2061470150947571e-01
    z[0,4,5]  R288      9.7828663885593414e-02
    z[0,4,5]  R289      -8.4887266159057617e-02
    z[0,4,5]  R290      -4.8635739833116531e-02
    z[0,4,5]  R291      4.2728230357170105e-01
    z[0,4,5]  R292      -5.5917110294103622e-02
    z[0,4,5]  R293      3.9927709102630615e-01
    z[0,4,5]  R294      7.5558818876743317e-02
    z[0,4,5]  R295      -8.2117930054664612e-02
    z[0,4,5]  R296      2.8621256351470947e-01
    z[0,4,5]  R297      -1.5120024979114532e-01
    z[0,4,5]  R298      -1.2469217181205750e-02
    z[0,4,5]  R299      -1.8735386431217194e-02
    z[0,4,5]  R300      0.290080726146698
    z[0,4,5]  R301      3.9185795187950134e-01
    z[0,4,5]  R302      -2.3198728263378143e-01
    z[0,4,5]  R303      -1.4727722108364105e-01
    z[0,4,5]  R304      1.8493895232677460e-01
    z[0,4,5]  R305      0.0797443687915802
    z[0,4,5]  R306      -8.5617087781429291e-02
    z[0,4,5]  R307      -2.1199978888034821e-02
    z[0,4,5]  R308      -1.6147939860820770e-01
    z[0,4,5]  R309      -4.3890342116355896e-02
    z[0,4,5]  R310      -7.2078585624694824e-02
    z[0,4,5]  R311      6.7185126245021820e-02
    z[0,4,5]  R312      -1.6084041446447372e-02
    z[0,4,5]  R313      1.4139804244041443e-01
    z[0,4,5]  R314      5.5951970815658569e-01
    z[0,4,5]  R315      1.8991412222385406e-01
    z[0,4,5]  R316      6.1547566205263138e-02
    z[0,4,5]  R317      -1.7291270196437836e-01
    z[0,4,5]  R318      4.1396132111549377e-01
    z[0,4,5]  R319      1.6705366969108582e-01
    z[0,4,5]  R320      5.2193057537078857e-01
    z[0,4,5]  R321      2.5096088647842407e-01
    z[0,4,5]  R322      0.00862759631127119
    z[0,4,5]  R323      2.3625065386295319e-01
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R252      -1
    z[0,4,6]  R253      1
    z[0,4,6]  R254      4.1766279935836792e-01
    z[0,4,6]  R255      -6.3886815309524536e-01
    z[0,4,6]  R256      -7.8804391622543335e-01
    z[0,4,6]  R257      -1.3921412825584412e-01
    z[0,4,6]  R258      -4.1416588425636292e-01
    z[0,4,6]  R259      1.6032749414443970e-01
    z[0,4,6]  R260      3.2761093974113464e-01
    z[0,4,6]  R261      -5.0852197408676147e-01
    z[0,4,6]  R262      3.8458669185638428e-01
    z[0,4,6]  R263      2.1136872470378876e-01
    z[0,4,6]  R264      1.1449547111988068e-01
    z[0,4,6]  R265      8.9856550097465515e-02
    z[0,4,6]  R266      6.0445945709943771e-02
    z[0,4,6]  R267      9.0110331773757935e-02
    z[0,4,6]  R268      -6.7995168268680573e-02
    z[0,4,6]  R269      1.7687472701072693e-01
    z[0,4,6]  R270      6.6615156829357147e-03
    z[0,4,6]  R271      -1.5448690950870514e-01
    z[0,4,6]  R272      1.0302581638097763e-01
    z[0,4,6]  R273      2.5487509369850159e-01
    z[0,4,6]  R274      -2.1142115816473961e-02
    z[0,4,6]  R275      1.4957828819751740e-01
    z[0,4,6]  R276      -1.0371533036231995e-01
    z[0,4,6]  R277      7.1663707494735718e-02
    z[0,4,6]  R278      -0.0947442501783371
    z[0,4,6]  R279      3.0178219079971313e-02
    z[0,4,6]  R280      4.3031446635723114e-02
    z[0,4,6]  R281      4.7075446695089340e-02
    z[0,4,6]  R282      2.5707420706748962e-01
    z[0,4,6]  R283      1.3883855938911438e-01
    z[0,4,6]  R284      -2.4554328992962837e-02
    z[0,4,6]  R285      1.1613485217094421e-01
    z[0,4,6]  R286      2.4154061079025269e-01
    z[0,4,6]  R287      2.1722437441349030e-01
    z[0,4,6]  R288      1.8210685253143311e-01
    z[0,4,6]  R289      4.4662925601005554e-01
    z[0,4,6]  R290      2.0342156291007996e-01
    z[0,4,6]  R291      -5.6647288799285889e-01
    z[0,4,6]  R292      -8.7896245718002319e-01
    z[0,4,6]  R293      -3.7956789135932922e-01
    z[0,4,6]  R294      -0.0497247539460659
    z[0,4,6]  R295      -6.0284274816513062e-01
    z[0,4,6]  R296      -4.7841307520866394e-01
    z[0,4,6]  R297      -8.6688280105590820e-02
    z[0,4,6]  R298      1.2187813967466354e-01
    z[0,4,6]  R299      2.1599070727825165e-01
    z[0,4,6]  R300      4.2156991362571716e-01
    z[0,4,6]  R301      1.7205193638801575e-01
    z[0,4,6]  R302      -2.6093757152557373e-01
    z[0,4,6]  R303      1.5837593376636505e-01
    z[0,4,6]  R304      -6.7665509879589081e-02
    z[0,4,6]  R305      -6.0138396918773651e-02
    z[0,4,6]  R306      3.9237238466739655e-02
    z[0,4,6]  R307      1.2265367805957794e-01
    z[0,4,6]  R308      -1.1476953327655792e-01
    z[0,4,6]  R309      -1.2340287119150162e-01
    z[0,4,6]  R310      2.7581827715039253e-02
    z[0,4,6]  R311      3.7131506949663162e-02
    z[0,4,6]  R312      2.4468530714511871e-01
    z[0,4,6]  R313      2.7021160349249840e-02
    z[0,4,6]  R314      -1.6837711632251740e-01
    z[0,4,6]  R315      0.0065696956589818
    z[0,4,6]  R316      8.2873530685901642e-02
    z[0,4,6]  R317      -0.157931387424469
    z[0,4,6]  R318      -2.2559596598148346e-01
    z[0,4,6]  R319      8.2399837672710419e-02
    z[0,4,6]  R320      1.2526282668113708e-01
    z[0,4,6]  R321      8.3797954022884369e-02
    z[0,4,6]  R322      2.0705102384090424e-01
    z[0,4,6]  R323      2.8981450200080872e-01
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R324      -1
    z[4,0,0]  R325      1
    z[4,0,0]  R338      -5.7972317934036255e-01
    z[4,0,0]  R339      -7.6502150297164917e-01
    z[4,0,0]  R340      -7.1177893877029419e-01
    z[4,0,0]  R341      -7.0715343952178955e-01
    z[4,0,0]  R342      -5.0080770254135132e-01
    z[4,0,0]  R343      -7.7686232328414917e-01
    z[4,0,0]  R344      -4.0485724806785583e-01
    z[4,0,0]  R345      -7.1330323815345764e-02
    z[4,0,0]  R346      -2.0989847183227539e-01
    z[4,0,0]  R347      4.5504495501518250e-01
    z[4,0,0]  R348      2.0747885107994080e-01
    z[4,0,0]  R349      -4.9686175584793091e-01
    z[4,0,0]  R350      5.3532477468252182e-02
    z[4,0,0]  R351      8.8198864459991455e-01
    z[4,0,0]  R352      8.8591843843460083e-01
    z[4,0,0]  R353      8.7120288610458374e-01
    z[4,0,0]  R354      4.3611773848533630e-01
    z[4,0,0]  R355      3.5592919588088989e-01
    z[4,0,0]  R356      0.86301189661026
    z[4,0,0]  R357      8.7381732463836670e-01
    z[4,0,0]  R358      5.0713205337524414e-01
    z[4,0,0]  R359      -3.0775934457778931e-01
    z[4,0,0]  R360      -1.3161900639533997e-01
    z[4,0,0]  R361      -1.0995452851057053e-01
    z[4,0,0]  R362      -1.9690018892288208e-01
    z[4,0,0]  R363      -1.0541586577892303e-01
    z[4,0,0]  R364      -9.6146740019321442e-02
    z[4,0,0]  R365      7.6432503759860992e-02
    z[4,0,0]  R366      -1.5052518248558044e-01
    z[4,0,0]  R367      -0.0409589558839798
    z[4,0,0]  R368      4.5085424184799194e-01
    z[4,0,0]  R369      0.948215126991272
    z[4,0,0]  R370      4.6942993998527527e-01
    z[4,0,0]  R371      6.2622010707855225e-01
    z[4,0,0]  R372      6.5410810708999634e-01
    z[4,0,0]  R373      5.8166539669036865e-01
    z[4,0,0]  R374      6.3407623767852783e-01
    z[4,0,0]  R375      4.1721984744071960e-01
    z[4,0,0]  R376      8.5299199819564819e-01
    z[4,0,0]  R377      6.1620497703552246e-01
    z[4,0,0]  R378      -6.2454563379287720e-01
    z[4,0,0]  R379      -2.1516275405883789e-01
    z[4,0,0]  R380      -1.8671810626983643e-01
    z[4,0,0]  R381      2.7230393886566162e-01
    z[4,0,0]  R382      9.3057401478290558e-02
    z[4,0,0]  R383      -2.2906453907489777e-01
    z[4,0,0]  R384      2.9664814472198486e-01
    z[4,0,0]  R385      -1.0600391775369644e-01
    z[4,0,0]  R386      3.6410665512084961e-01
    z[4,0,0]  R387      6.1475169658660889e-01
    z[4,0,0]  R388      -5.8016985654830933e-01
    z[4,0,0]  R389      -3.5037016868591309e-01
    z[4,0,0]  R390      7.7599966526031494e-01
    z[4,0,0]  R391      0.85499507188797
    z[4,0,0]  R392      5.3688251972198486e-01
    z[4,0,0]  R393      6.2329494953155518e-01
    z[4,0,0]  R394      5.6046378612518311e-01
    z[4,0,0]  R395      5.1575177907943726e-01
    z[4,0,0]  R396      5.4513669013977051e-01
    z[4,0,0]  R397      6.9494730234146118e-01
    z[4,0,0]  R398      4.9062415957450867e-01
    z[4,0,0]  R399      9.5356649160385132e-01
    z[4,0,0]  R400      9.5592629909515381e-01
    z[4,0,0]  R401      0.921034038066864
    z[4,0,0]  R402      9.3095201253890991e-01
    z[4,0,0]  R403      9.5449793338775635e-01
    z[4,0,0]  R404      9.4706481695175171e-01
    z[4,0,0]  R405      0.962475597858429
    z[4,0,0]  R406      8.9228081703186035e-01
    z[4,0,0]  R407      8.8256591558456421e-01
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R326      -1
    z[4,0,1]  R327      1
    z[4,0,1]  R338      -2.7955442667007446e-01
    z[4,0,1]  R339      -3.3829516172409058e-01
    z[4,0,1]  R340      -8.5102990269660950e-02
    z[4,0,1]  R341      -0.592068076133728
    z[4,0,1]  R342      -3.8465267419815063e-01
    z[4,0,1]  R343      -1.9518250226974487e-01
    z[4,0,1]  R344      -2.2412414848804474e-01
    z[4,0,1]  R345      3.2590541243553162e-01
    z[4,0,1]  R346      -5.7407461106777191e-02
    z[4,0,1]  R347      -4.4644474983215332e-01
    z[4,0,1]  R348      -8.5024875402450562e-01
    z[4,0,1]  R349      8.8031284511089325e-02
    z[4,0,1]  R350      -5.8409631252288818e-01
    z[4,0,1]  R351      -3.9237055182456970e-01
    z[4,0,1]  R352      -3.1708675622940063e-01
    z[4,0,1]  R353      -3.9633682370185852e-01
    z[4,0,1]  R354      -6.8332219123840332e-01
    z[4,0,1]  R355      -4.9160975217819214e-01
    z[4,0,1]  R356      -3.3863878250122070e-01
    z[4,0,1]  R357      -2.8951865434646606e-01
    z[4,0,1]  R358      -6.7540162801742554e-01
    z[4,0,1]  R359      9.2551183700561523e-01
    z[4,0,1]  R360      9.6815145015716553e-01
    z[4,0,1]  R361      9.6989828348159790e-01
    z[4,0,1]  R362      9.1882050037384033e-01
    z[4,0,1]  R363      9.4148808717727661e-01
    z[4,0,1]  R364      0.953998327255249
    z[4,0,1]  R365      9.8180347681045532e-01
    z[4,0,1]  R366      0.920976459980011
    z[4,0,1]  R367      9.7002464532852173e-01
    z[4,0,1]  R368      -3.8136070966720581e-01
    z[4,0,1]  R369      -6.7426353693008423e-02
    z[4,0,1]  R370      -6.6137647628784180e-01
    z[4,0,1]  R371      2.0332412421703339e-01
    z[4,0,1]  R372      -2.2642524540424347e-01
    z[4,0,1]  R373      3.0499300360679626e-01
    z[4,0,1]  R374      -1.1251514405012131e-01
    z[4,0,1]  R375      5.1701503992080688e-01
    z[4,0,1]  R376      1.4222370088100433e-01
    z[4,0,1]  R377      -3.2608166337013245e-01
    z[4,0,1]  R378      -1.2198417633771896e-01
    z[4,0,1]  R379      9.1458439826965332e-02
    z[4,0,1]  R380      0.375693142414093
    z[4,0,1]  R381      -0.092345230281353
    z[4,0,1]  R382      -8.6846321821212769e-02
    z[4,0,1]  R383      -2.9356257990002632e-02
    z[4,0,1]  R384      -7.7912271022796631e-02
    z[4,0,1]  R385      -1.3169866800308228e-01
    z[4,0,1]  R386      7.2579711675643921e-01
    z[4,0,1]  R387      -0.264365553855896
    z[4,0,1]  R388      3.0741026997566223e-01
    z[4,0,1]  R389      -0.687488317489624
    z[4,0,1]  R390      8.6378656327724457e-02
    z[4,0,1]  R391      -2.0779383182525635e-01
    z[4,0,1]  R392      -5.7429629564285278e-01
    z[4,0,1]  R393      -3.0606836080551147e-01
    z[4,0,1]  R394      -5.4516541957855225e-01
    z[4,0,1]  R395      -0.578826367855072
    z[4,0,1]  R396      -0.551854133605957
    z[4,0,1]  R397      2.8960263729095459e-01
    z[4,0,1]  R398      -0.589694619178772
    z[4,0,1]  R399      1.0760664939880371e-01
    z[4,0,1]  R400      1.0262688994407654e-01
    z[4,0,1]  R401      1.9474224746227264e-01
    z[4,0,1]  R402      6.3625440001487732e-02
    z[4,0,1]  R403      -1.7975641787052155e-01
    z[4,0,1]  R404      -2.1268384158611298e-01
    z[4,0,1]  R405      -1.3325746357440948e-01
    z[4,0,1]  R406      7.3412582278251648e-02
    z[4,0,1]  R407      7.2798162698745728e-02
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R328      -1
    z[4,0,2]  R329      1
    z[4,0,2]  R338      -1.7431795597076416e-01
    z[4,0,2]  R339      -2.6106369495391846e-01
    z[4,0,2]  R340      -4.4017231464385986e-01
    z[4,0,2]  R341      -4.7031562775373459e-02
    z[4,0,2]  R342      -1.5521739423274994e-01
    z[4,0,2]  R343      -3.0772429704666138e-01
    z[4,0,2]  R344      -8.2980763912200928e-01
    z[4,0,2]  R345      -5.1815962791442871e-01
    z[4,0,2]  R346      -3.4970918297767639e-01
    z[4,0,2]  R347      -1.2851508334279060e-02
    z[4,0,2]  R348      -0.064329132437706
    z[4,0,2]  R349      -2.6872813701629639e-01
    z[4,0,2]  R350      -1.1712085455656052e-01
    z[4,0,2]  R351      5.8494519442319870e-02
    z[4,0,2]  R352      -7.0008113980293274e-02
    z[4,0,2]  R353      6.9923967123031616e-02
    z[4,0,2]  R354      -1.6761665046215057e-01
    z[4,0,2]  R355      -1.7568540573120117e-01
    z[4,0,2]  R356      -3.3721212297677994e-02
    z[4,0,2]  R357      -2.4386551976203918e-01
    z[4,0,2]  R358      3.9617738127708435e-01
    z[4,0,2]  R359      1.8921536207199097e-01
    z[4,0,2]  R360      -9.0488076210021973e-02
    z[4,0,2]  R361      -3.3312514424324036e-02
    z[4,0,2]  R362      1.2171571701765060e-01
    z[4,0,2]  R363      -2.3459148406982422e-01
    z[4,0,2]  R364      7.2983093559741974e-02
    z[4,0,2]  R365      1.1208556592464447e-01
    z[4,0,2]  R366      1.4783999323844910e-01
    z[4,0,2]  R367      -0.0674082413315773
    z[4,0,2]  R368      -1.7220650613307953e-01
    z[4,0,2]  R369      2.4402961134910583e-01
    z[4,0,2]  R370      3.4998139739036560e-01
    z[4,0,2]  R371      3.4280881285667419e-01
    z[4,0,2]  R372      3.6785191297531128e-01
    z[4,0,2]  R373      2.2790899872779846e-01
    z[4,0,2]  R374      3.0890521407127380e-01
    z[4,0,2]  R375      -4.8213177919387817e-01
    z[4,0,2]  R376      1.6244347393512726e-01
    z[4,0,2]  R377      1.2620979547500610e-01
    z[4,0,2]  R378      -7.2457477450370789e-02
    z[4,0,2]  R379      2.5599226355552673e-01
    z[4,0,2]  R380      5.4143011569976807e-02
    z[4,0,2]  R381      3.1159085035324097e-01
    z[4,0,2]  R382      -2.4613864719867706e-01
    z[4,0,2]  R383      -2.4763885140419006e-01
    z[4,0,2]  R384      -2.2933542728424072e-01
    z[4,0,2]  R385      -2.2622874379158020e-01
    z[4,0,2]  R386      -1.3985931873321533e-01
    z[4,0,2]  R387      -1.9673401117324829e-01
    z[4,0,2]  R388      -3.4152418375015259e-01
    z[4,0,2]  R389      3.8262628018856049e-02
    z[4,0,2]  R390      -4.7878921031951904e-01
    z[4,0,2]  R391      -1.9449584186077118e-01
    z[4,0,2]  R392      1.7855939269065857e-01
    z[4,0,2]  R393      -7.1354568004608154e-02
    z[4,0,2]  R394      2.3346179723739624e-01
    z[4,0,2]  R395      3.4155708551406860e-01
    z[4,0,2]  R396      1.7298434674739838e-01
    z[4,0,2]  R397      -3.8438954949378967e-01
    z[4,0,2]  R398      2.6380854845046997e-01
    z[4,0,2]  R399      -8.6100853979587555e-02
    z[4,0,2]  R400      3.0835436191409826e-03
    z[4,0,2]  R401      -9.6009127795696259e-02
    z[4,0,2]  R402      -8.5328713059425354e-02
    z[4,0,2]  R403      4.4295042753219604e-02
    z[4,0,2]  R404      6.7133486270904541e-02
    z[4,0,2]  R405      -8.4393061697483063e-03
    z[4,0,2]  R406      -8.7759876623749733e-03
    z[4,0,2]  R407      6.8029031157493591e-02
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R330      -1
    z[4,0,3]  R331      1
    z[4,0,3]  R338      0.00803461018949747
    z[4,0,3]  R339      -3.0085292458534241e-01
    z[4,0,3]  R340      -2.5804473087191582e-02
    z[4,0,3]  R341      1.1786479502916336e-01
    z[4,0,3]  R342      -9.9384687840938568e-02
    z[4,0,3]  R343      8.4044739603996277e-02
    z[4,0,3]  R344      -1.6016146540641785e-01
    z[4,0,3]  R345      4.8659469932317734e-02
    z[4,0,3]  R346      2.2356024384498596e-01
    z[4,0,3]  R347      7.8668624162673950e-02
    z[4,0,3]  R348      2.5957694649696350e-01
    z[4,0,3]  R349      0.396978497505188
    z[4,0,3]  R350      2.1976348757743835e-01
    z[4,0,3]  R351      1.8401291966438293e-01
    z[4,0,3]  R352      0.0713120549917221
    z[4,0,3]  R353      1.6418716311454773e-01
    z[4,0,3]  R354      1.6098621487617493e-01
    z[4,0,3]  R355      3.1258836388587952e-01
    z[4,0,3]  R356      -6.4314864575862885e-02
    z[4,0,3]  R357      -2.0116370916366577e-01
    z[4,0,3]  R358      1.2760446965694427e-01
    z[4,0,3]  R359      -3.3711224794387817e-02
    z[4,0,3]  R360      -1.4838449656963348e-01
    z[4,0,3]  R361      1.4235946536064148e-01
    z[4,0,3]  R362      -1.6547230188734829e-04
    z[4,0,3]  R363      -1.0569803416728973e-01
    z[4,0,3]  R364      -2.0552964508533478e-01
    z[4,0,3]  R365      -9.1635994613170624e-02
    z[4,0,3]  R366      3.3478941768407822e-02
    z[4,0,3]  R367      1.0103969275951385e-01
    z[4,0,3]  R368      4.3513849377632141e-01
    z[4,0,3]  R369      1.8716195598244667e-02
    z[4,0,3]  R370      4.1821590065956116e-01
    z[4,0,3]  R371      3.3363819122314453e-01
    z[4,0,3]  R372      -3.4760600328445435e-01
    z[4,0,3]  R373      2.4602463841438293e-01
    z[4,0,3]  R374      -3.1204387545585632e-01
    z[4,0,3]  R375      1.8816350400447845e-01
    z[4,0,3]  R376      1.6779004037380219e-01
    z[4,0,3]  R377      -0.586354672908783
    z[4,0,3]  R378      2.4540820717811584e-01
    z[4,0,3]  R379      2.5026738643646240e-01
    z[4,0,3]  R380      3.3378362655639648e-01
    z[4,0,3]  R381      -8.8093864917755127e-01
    z[4,0,3]  R382      -7.1590358018875122e-01
    z[4,0,3]  R383      -0.777795135974884
    z[4,0,3]  R384      -6.5661495923995972e-01
    z[4,0,3]  R385      -8.0041807889938354e-01
    z[4,0,3]  R386      4.3620150536298752e-02
    z[4,0,3]  R387      6.4261603355407715e-01
    z[4,0,3]  R388      -1.7590735852718353e-01
    z[4,0,3]  R389      6.1712156981229782e-02
    z[4,0,3]  R390      2.2831702232360840e-01
    z[4,0,3]  R391      3.3436343073844910e-01
    z[4,0,3]  R392      4.7726336121559143e-01
    z[4,0,3]  R393      6.6573393344879150e-01
    z[4,0,3]  R394      2.4211759865283966e-01
    z[4,0,3]  R395      2.2682611644268036e-01
    z[4,0,3]  R396      1.1412691324949265e-01
    z[4,0,3]  R397      4.5430281758308411e-01
    z[4,0,3]  R398      1.4275726675987244e-01
    z[4,0,3]  R399      7.7638953924179077e-02
    z[4,0,3]  R400      1.5241716802120209e-01
    z[4,0,3]  R401      2.5958317518234253e-01
    z[4,0,3]  R402      2.6987347006797791e-01
    z[4,0,3]  R403      2.0211806893348694e-01
    z[4,0,3]  R404      1.8949033319950104e-01
    z[4,0,3]  R405      1.6944111883640289e-01
    z[4,0,3]  R406      3.4730784595012665e-02
    z[4,0,3]  R407      0.0716017633676529
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R332      -1
    z[4,0,4]  R333      1
    z[4,0,4]  R338      4.1871714591979980e-01
    z[4,0,4]  R339      9.4915606081485748e-02
    z[4,0,4]  R340      6.2939259223639965e-03
    z[4,0,4]  R341      1.9346331059932709e-01
    z[4,0,4]  R342      7.2424495220184326e-01
    z[4,0,4]  R343      2.2348937392234802e-01
    z[4,0,4]  R344      1.6697567701339722e-01
    z[4,0,4]  R345      -0.338199257850647
    z[4,0,4]  R346      -6.8334378302097321e-02
    z[4,0,4]  R347      -5.3270375728607178e-01
    z[4,0,4]  R348      -3.9284810423851013e-01
    z[4,0,4]  R349      -3.8132596015930176e-01
    z[4,0,4]  R350      -5.3212392330169678e-01
    z[4,0,4]  R351      2.1966744214296341e-02
    z[4,0,4]  R352      0.299346387386322
    z[4,0,4]  R353      7.1223303675651550e-02
    z[4,0,4]  R354      -0.164293110370636
    z[4,0,4]  R355      -5.6559962034225464e-01
    z[4,0,4]  R356      -1.1556020379066467e-01
    z[4,0,4]  R357      -7.6886273920536041e-02
    z[4,0,4]  R358      0.273183673620224
    z[4,0,4]  R359      -4.2394332587718964e-02
    z[4,0,4]  R360      -7.9268120229244232e-02
    z[4,0,4]  R361      1.0167615860700607e-01
    z[4,0,4]  R362      2.5087258219718933e-01
    z[4,0,4]  R363      1.3830369710922241e-01
    z[4,0,4]  R364      1.6467517614364624e-01
    z[4,0,4]  R365      5.8026801794767380e-02
    z[4,0,4]  R366      -2.1456320583820343e-01
    z[4,0,4]  R367      -1.4798012375831604e-01
    z[4,0,4]  R368      -3.0146420001983643e-01
    z[4,0,4]  R369      1.8179299309849739e-02
    z[4,0,4]  R370      1.8484836816787720e-01
    z[4,0,4]  R371      -5.3182154893875122e-01
    z[4,0,4]  R372      -2.0608678460121155e-01
    z[4,0,4]  R373      -6.4921277761459351e-01
    z[4,0,4]  R374      -3.2309678196907043e-01
    z[4,0,4]  R375      4.6985435485839844e-01
    z[4,0,4]  R376      -3.9330765604972839e-01
    z[4,0,4]  R377      -1.2006111443042755e-01
    z[4,0,4]  R378      -1.1821195483207703e-01
    z[4,0,4]  R379      0.591735303401947
    z[4,0,4]  R380      -2.9410383105278015e-01
    z[4,0,4]  R381      3.7483379244804382e-02
    z[4,0,4]  R382      4.0477314591407776e-01
    z[4,0,4]  R383      4.4546425342559814e-01
    z[4,0,4]  R384      5.2349936962127686e-01
    z[4,0,4]  R385      -2.2779973223805428e-02
    z[4,0,4]  R386      4.1214677691459656e-01
    z[4,0,4]  R387      1.6850122809410095e-01
    z[4,0,4]  R388      7.0217676460742950e-02
    z[4,0,4]  R389      1.6411077976226807e-01
    z[4,0,4]  R390      -1.9140003621578217e-01
    z[4,0,4]  R391      -1.6736832261085510e-01
    z[4,0,4]  R392      -2.9139450192451477e-01
    z[4,0,4]  R393      5.8200877159833908e-02
    z[4,0,4]  R394      -4.4286602735519409e-01
    z[4,0,4]  R395      -3.1714653968811035e-01
    z[4,0,4]  R396      -5.7771116495132446e-01
    z[4,0,4]  R397      -4.7654006630182266e-02
    z[4,0,4]  R398      -5.2831107378005981e-01
    z[4,0,4]  R399      -2.0501524209976196e-01
    z[4,0,4]  R400      1.9915629923343658e-01
    z[4,0,4]  R401      -2.8473852202296257e-02
    z[4,0,4]  R402      2.1903726737946272e-03
    z[4,0,4]  R403      -1.1289543658494949e-01
    z[4,0,4]  R404      1.2465568631887436e-01
    z[4,0,4]  R405      5.7221110910177231e-02
    z[4,0,4]  R406      0.257347047328949
    z[4,0,4]  R407      1.5537488460540771e-01
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R334      -1
    z[4,0,5]  R335      1
    z[4,0,5]  R338      6.1594814062118530e-01
    z[4,0,5]  R339      3.4515982866287231e-01
    z[4,0,5]  R340      4.8304164409637451e-01
    z[4,0,5]  R341      2.2061470150947571e-01
    z[4,0,5]  R342      9.7828663885593414e-02
    z[4,0,5]  R343      -8.4887266159057617e-02
    z[4,0,5]  R344      -4.8635739833116531e-02
    z[4,0,5]  R345      4.2728230357170105e-01
    z[4,0,5]  R346      -5.5917110294103622e-02
    z[4,0,5]  R347      3.9927709102630615e-01
    z[4,0,5]  R348      7.5558818876743317e-02
    z[4,0,5]  R349      -8.2117930054664612e-02
    z[4,0,5]  R350      2.8621256351470947e-01
    z[4,0,5]  R351      -1.5120024979114532e-01
    z[4,0,5]  R352      -1.2469217181205750e-02
    z[4,0,5]  R353      -1.8735386431217194e-02
    z[4,0,5]  R354      0.290080726146698
    z[4,0,5]  R355      3.9185795187950134e-01
    z[4,0,5]  R356      -2.3198728263378143e-01
    z[4,0,5]  R357      -1.4727722108364105e-01
    z[4,0,5]  R358      1.8493895232677460e-01
    z[4,0,5]  R359      0.0797443687915802
    z[4,0,5]  R360      -8.5617087781429291e-02
    z[4,0,5]  R361      -2.1199978888034821e-02
    z[4,0,5]  R362      -1.6147939860820770e-01
    z[4,0,5]  R363      -4.3890342116355896e-02
    z[4,0,5]  R364      -7.2078585624694824e-02
    z[4,0,5]  R365      6.7185126245021820e-02
    z[4,0,5]  R366      -1.6084041446447372e-02
    z[4,0,5]  R367      1.4139804244041443e-01
    z[4,0,5]  R368      5.5951970815658569e-01
    z[4,0,5]  R369      1.8991412222385406e-01
    z[4,0,5]  R370      6.1547566205263138e-02
    z[4,0,5]  R371      -1.7291270196437836e-01
    z[4,0,5]  R372      4.1396132111549377e-01
    z[4,0,5]  R373      1.6705366969108582e-01
    z[4,0,5]  R374      5.2193057537078857e-01
    z[4,0,5]  R375      2.5096088647842407e-01
    z[4,0,5]  R376      0.00862759631127119
    z[4,0,5]  R377      2.3625065386295319e-01
    z[4,0,5]  R378      5.8409845829010010e-01
    z[4,0,5]  R379      2.4263417720794678e-01
    z[4,0,5]  R380      4.6235557645559311e-02
    z[4,0,5]  R381      -1.5295599400997162e-01
    z[4,0,5]  R382      -2.7444693446159363e-01
    z[4,0,5]  R383      -2.3713716864585876e-01
    z[4,0,5]  R384      -2.0201796293258667e-01
    z[4,0,5]  R385      -1.4302644133567810e-01
    z[4,0,5]  R386      3.7544753402471542e-02
    z[4,0,5]  R387      -1.6571731865406036e-01
    z[4,0,5]  R388      -6.3504314422607422e-01
    z[4,0,5]  R389      -6.0359042882919312e-01
    z[4,0,5]  R390      2.6212185621261597e-01
    z[4,0,5]  R391      -2.0011414587497711e-01
    z[4,0,5]  R392      1.8095028400421143e-01
    z[4,0,5]  R393      1.8670941889286041e-01
    z[4,0,5]  R394      2.8173556923866272e-01
    z[4,0,5]  R395      3.2619115710258484e-01
    z[4,0,5]  R396      1.0473755002021790e-01
    z[4,0,5]  R397      -1.0862807929515839e-01
    z[4,0,5]  R398      2.0497329533100128e-01
    z[4,0,5]  R399      3.5855319350957870e-02
    z[4,0,5]  R400      -4.4855102896690369e-02
    z[4,0,5]  R401      1.7670363187789917e-01
    z[4,0,5]  R402      -2.0046514272689819e-01
    z[4,0,5]  R403      1.2309648096561432e-02
    z[4,0,5]  R404      -5.4346998222172260e-03
    z[4,0,5]  R405      -1.4700774848461151e-01
    z[4,0,5]  R406      0.254652202129364
    z[4,0,5]  R407      4.0324357151985168e-01
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R336      -1
    z[4,0,6]  R337      1
    z[4,0,6]  R338      -2.4554328992962837e-02
    z[4,0,6]  R339      1.1613485217094421e-01
    z[4,0,6]  R340      2.4154061079025269e-01
    z[4,0,6]  R341      2.1722437441349030e-01
    z[4,0,6]  R342      1.8210685253143311e-01
    z[4,0,6]  R343      4.4662925601005554e-01
    z[4,0,6]  R344      2.0342156291007996e-01
    z[4,0,6]  R345      -5.6647288799285889e-01
    z[4,0,6]  R346      -8.7896245718002319e-01
    z[4,0,6]  R347      -3.7956789135932922e-01
    z[4,0,6]  R348      -0.0497247539460659
    z[4,0,6]  R349      -6.0284274816513062e-01
    z[4,0,6]  R350      -4.7841307520866394e-01
    z[4,0,6]  R351      -8.6688280105590820e-02
    z[4,0,6]  R352      1.2187813967466354e-01
    z[4,0,6]  R353      2.1599070727825165e-01
    z[4,0,6]  R354      4.2156991362571716e-01
    z[4,0,6]  R355      1.7205193638801575e-01
    z[4,0,6]  R356      -2.6093757152557373e-01
    z[4,0,6]  R357      1.5837593376636505e-01
    z[4,0,6]  R358      -6.7665509879589081e-02
    z[4,0,6]  R359      -6.0138396918773651e-02
    z[4,0,6]  R360      3.9237238466739655e-02
    z[4,0,6]  R361      1.2265367805957794e-01
    z[4,0,6]  R362      -1.1476953327655792e-01
    z[4,0,6]  R363      -1.2340287119150162e-01
    z[4,0,6]  R364      2.7581827715039253e-02
    z[4,0,6]  R365      3.7131506949663162e-02
    z[4,0,6]  R366      2.4468530714511871e-01
    z[4,0,6]  R367      2.7021160349249840e-02
    z[4,0,6]  R368      -1.6837711632251740e-01
    z[4,0,6]  R369      0.0065696956589818
    z[4,0,6]  R370      8.2873530685901642e-02
    z[4,0,6]  R371      -0.157931387424469
    z[4,0,6]  R372      -2.2559596598148346e-01
    z[4,0,6]  R373      8.2399837672710419e-02
    z[4,0,6]  R374      1.2526282668113708e-01
    z[4,0,6]  R375      8.3797954022884369e-02
    z[4,0,6]  R376      2.0705102384090424e-01
    z[4,0,6]  R377      2.8981450200080872e-01
    z[4,0,6]  R378      4.1766279935836792e-01
    z[4,0,6]  R379      -6.3886815309524536e-01
    z[4,0,6]  R380      -7.8804391622543335e-01
    z[4,0,6]  R381      -1.3921412825584412e-01
    z[4,0,6]  R382      -4.1416588425636292e-01
    z[4,0,6]  R383      1.6032749414443970e-01
    z[4,0,6]  R384      3.2761093974113464e-01
    z[4,0,6]  R385      -5.0852197408676147e-01
    z[4,0,6]  R386      3.8458669185638428e-01
    z[4,0,6]  R387      2.1136872470378876e-01
    z[4,0,6]  R388      1.1449547111988068e-01
    z[4,0,6]  R389      8.9856550097465515e-02
    z[4,0,6]  R390      6.0445945709943771e-02
    z[4,0,6]  R391      9.0110331773757935e-02
    z[4,0,6]  R392      -6.7995168268680573e-02
    z[4,0,6]  R393      1.7687472701072693e-01
    z[4,0,6]  R394      6.6615156829357147e-03
    z[4,0,6]  R395      -1.5448690950870514e-01
    z[4,0,6]  R396      1.0302581638097763e-01
    z[4,0,6]  R397      2.5487509369850159e-01
    z[4,0,6]  R398      -2.1142115816473961e-02
    z[4,0,6]  R399      1.4957828819751740e-01
    z[4,0,6]  R400      -1.0371533036231995e-01
    z[4,0,6]  R401      7.1663707494735718e-02
    z[4,0,6]  R402      -0.0947442501783371
    z[4,0,6]  R403      3.0178219079971313e-02
    z[4,0,6]  R404      4.3031446635723114e-02
    z[4,0,6]  R405      4.7075446695089340e-02
    z[4,0,6]  R406      2.5707420706748962e-01
    z[4,0,6]  R407      1.3883855938911438e-01
    z[0,5,0]  R2        -1
    z[0,5,0]  R47       1
    z[0,5,0]  R408      -1
    z[0,5,0]  R409      1
    z[0,5,0]  R422      -6.2454563379287720e-01
    z[0,5,0]  R423      -2.1516275405883789e-01
    z[0,5,0]  R424      -1.8671810626983643e-01
    z[0,5,0]  R425      2.7230393886566162e-01
    z[0,5,0]  R426      9.3057401478290558e-02
    z[0,5,0]  R427      -2.2906453907489777e-01
    z[0,5,0]  R428      2.9664814472198486e-01
    z[0,5,0]  R429      -1.0600391775369644e-01
    z[0,5,0]  R430      3.6410665512084961e-01
    z[0,5,0]  R431      6.1475169658660889e-01
    z[0,5,0]  R432      -5.8016985654830933e-01
    z[0,5,0]  R433      -3.5037016868591309e-01
    z[0,5,0]  R434      7.7599966526031494e-01
    z[0,5,0]  R435      0.85499507188797
    z[0,5,0]  R436      5.3688251972198486e-01
    z[0,5,0]  R437      6.2329494953155518e-01
    z[0,5,0]  R438      5.6046378612518311e-01
    z[0,5,0]  R439      5.1575177907943726e-01
    z[0,5,0]  R440      5.4513669013977051e-01
    z[0,5,0]  R441      6.9494730234146118e-01
    z[0,5,0]  R442      4.9062415957450867e-01
    z[0,5,0]  R443      9.5356649160385132e-01
    z[0,5,0]  R444      9.5592629909515381e-01
    z[0,5,0]  R445      0.921034038066864
    z[0,5,0]  R446      9.3095201253890991e-01
    z[0,5,0]  R447      9.5449793338775635e-01
    z[0,5,0]  R448      9.4706481695175171e-01
    z[0,5,0]  R449      0.962475597858429
    z[0,5,0]  R450      8.9228081703186035e-01
    z[0,5,0]  R451      8.8256591558456421e-01
    z[0,5,0]  R452      1.1186915449798107e-02
    z[0,5,0]  R453      -4.8215375281870365e-03
    z[0,5,0]  R454      -3.1158182024955750e-01
    z[0,5,0]  R455      -4.5451480150222778e-01
    z[0,5,0]  R456      -6.3648438453674316e-01
    z[0,5,0]  R457      -5.5495697259902954e-01
    z[0,5,0]  R458      -9.0682422742247581e-03
    z[0,5,0]  R459      1.0719141364097595e-01
    z[0,5,0]  R460      3.4995445609092712e-01
    z[0,5,0]  R461      -3.2522717118263245e-01
    z[0,5,0]  R462      -5.2713447809219360e-01
    z[0,5,0]  R463      1.8959281966090202e-02
    z[0,5,0]  R464      2.4771073460578918e-01
    z[0,5,0]  R465      -6.5029990673065186e-01
    z[0,5,0]  R466      1.4037866890430450e-01
    z[0,5,0]  R467      1.8609800934791565e-01
    z[0,5,0]  R468      -0.00932371336966753
    z[0,5,0]  R469      6.1752386391162872e-02
    z[0,5,0]  R470      -9.8541423678398132e-02
    z[0,5,0]  R471      2.8609317541122437e-01
    z[0,5,0]  R472      8.6865060031414032e-02
    z[0,5,0]  R473      -2.8792256116867065e-01
    z[0,5,0]  R474      -3.8555711507797241e-02
    z[0,5,0]  R475      1.6615432500839233e-01
    z[0,5,0]  R476      -3.5495206713676453e-02
    z[0,5,0]  R477      4.3524277210235596e-01
    z[0,5,0]  R478      2.6447480916976929e-01
    z[0,5,1]  R3        -1
    z[0,5,1]  R48       1
    z[0,5,1]  R410      -1
    z[0,5,1]  R411      1
    z[0,5,1]  R422      -1.2198417633771896e-01
    z[0,5,1]  R423      9.1458439826965332e-02
    z[0,5,1]  R424      0.375693142414093
    z[0,5,1]  R425      -0.092345230281353
    z[0,5,1]  R426      -8.6846321821212769e-02
    z[0,5,1]  R427      -2.9356257990002632e-02
    z[0,5,1]  R428      -7.7912271022796631e-02
    z[0,5,1]  R429      -1.3169866800308228e-01
    z[0,5,1]  R430      7.2579711675643921e-01
    z[0,5,1]  R431      -0.264365553855896
    z[0,5,1]  R432      3.0741026997566223e-01
    z[0,5,1]  R433      -0.687488317489624
    z[0,5,1]  R434      8.6378656327724457e-02
    z[0,5,1]  R435      -2.0779383182525635e-01
    z[0,5,1]  R436      -5.7429629564285278e-01
    z[0,5,1]  R437      -3.0606836080551147e-01
    z[0,5,1]  R438      -5.4516541957855225e-01
    z[0,5,1]  R439      -0.578826367855072
    z[0,5,1]  R440      -0.551854133605957
    z[0,5,1]  R441      2.8960263729095459e-01
    z[0,5,1]  R442      -0.589694619178772
    z[0,5,1]  R443      1.0760664939880371e-01
    z[0,5,1]  R444      1.0262688994407654e-01
    z[0,5,1]  R445      1.9474224746227264e-01
    z[0,5,1]  R446      6.3625440001487732e-02
    z[0,5,1]  R447      -1.7975641787052155e-01
    z[0,5,1]  R448      -2.1268384158611298e-01
    z[0,5,1]  R449      -1.3325746357440948e-01
    z[0,5,1]  R450      7.3412582278251648e-02
    z[0,5,1]  R451      7.2798162698745728e-02
    z[0,5,1]  R452      -2.8183379769325256e-01
    z[0,5,1]  R453      -4.3488350510597229e-01
    z[0,5,1]  R454      4.9660235643386841e-01
    z[0,5,1]  R455      6.6657382249832153e-01
    z[0,5,1]  R456      3.3694645762443542e-01
    z[0,5,1]  R457      6.0095584392547607e-01
    z[0,5,1]  R458      8.8974541425704956e-01
    z[0,5,1]  R459      0.454041987657547
    z[0,5,1]  R460      8.6570811271667480e-01
    z[0,5,1]  R461      6.2760341167449951e-01
    z[0,5,1]  R462      -5.5866867303848267e-01
    z[0,5,1]  R463      -5.9417122602462769e-01
    z[0,5,1]  R464      -7.2897613048553467e-01
    z[0,5,1]  R465      0.0097170639783144
    z[0,5,1]  R466      7.5981557369232178e-01
    z[0,5,1]  R467      7.6729327440261841e-01
    z[0,5,1]  R468      7.8068637847900391e-01
    z[0,5,1]  R469      5.2841019630432129e-01
    z[0,5,1]  R470      7.7418565750122070e-01
    z[0,5,1]  R471      8.0917710065841675e-01
    z[0,5,1]  R472      8.6591434478759766e-01
    z[0,5,1]  R473      7.7511388063430786e-01
    z[0,5,1]  R474      7.3167085647583008e-01
    z[0,5,1]  R475      6.2748539447784424e-01
    z[0,5,1]  R476      8.4570759534835815e-01
    z[0,5,1]  R477      5.8977931737899780e-01
    z[0,5,1]  R478      6.4801257848739624e-01
    z[0,5,2]  R4        -1
    z[0,5,2]  R49       1
    z[0,5,2]  R412      -1
    z[0,5,2]  R413      1
    z[0,5,2]  R422      -7.2457477450370789e-02
    z[0,5,2]  R423      2.5599226355552673e-01
    z[0,5,2]  R424      5.4143011569976807e-02
    z[0,5,2]  R425      3.1159085035324097e-01
    z[0,5,2]  R426      -2.4613864719867706e-01
    z[0,5,2]  R427      -2.4763885140419006e-01
    z[0,5,2]  R428      -2.2933542728424072e-01
    z[0,5,2]  R429      -2.2622874379158020e-01
    z[0,5,2]  R430      -1.3985931873321533e-01
    z[0,5,2]  R431      -1.9673401117324829e-01
    z[0,5,2]  R432      -3.4152418375015259e-01
    z[0,5,2]  R433      3.8262628018856049e-02
    z[0,5,2]  R434      -4.7878921031951904e-01
    z[0,5,2]  R435      -1.9449584186077118e-01
    z[0,5,2]  R436      1.7855939269065857e-01
    z[0,5,2]  R437      -7.1354568004608154e-02
    z[0,5,2]  R438      2.3346179723739624e-01
    z[0,5,2]  R439      3.4155708551406860e-01
    z[0,5,2]  R440      1.7298434674739838e-01
    z[0,5,2]  R441      -3.8438954949378967e-01
    z[0,5,2]  R442      2.6380854845046997e-01
    z[0,5,2]  R443      -8.6100853979587555e-02
    z[0,5,2]  R444      3.0835436191409826e-03
    z[0,5,2]  R445      -9.6009127795696259e-02
    z[0,5,2]  R446      -8.5328713059425354e-02
    z[0,5,2]  R447      4.4295042753219604e-02
    z[0,5,2]  R448      6.7133486270904541e-02
    z[0,5,2]  R449      -8.4393061697483063e-03
    z[0,5,2]  R450      -8.7759876623749733e-03
    z[0,5,2]  R451      6.8029031157493591e-02
    z[0,5,2]  R452      -2.1567940711975098e-01
    z[0,5,2]  R453      1.3756586611270905e-01
    z[0,5,2]  R454      -6.0235446691513062e-01
    z[0,5,2]  R455      -1.3066259026527405e-01
    z[0,5,2]  R456      -5.2772867679595947e-01
    z[0,5,2]  R457      -1.9353452324867249e-01
    z[0,5,2]  R458      -0.0511116087436676
    z[0,5,2]  R459      -5.7751423120498657e-01
    z[0,5,2]  R460      2.8160056471824646e-01
    z[0,5,2]  R461      4.2929247021675110e-01
    z[0,5,2]  R462      -2.3929375410079956e-01
    z[0,5,2]  R463      4.3117862194776535e-02
    z[0,5,2]  R464      -4.9465906620025635e-01
    z[0,5,2]  R465      2.2865265607833862e-01
    z[0,5,2]  R466      0.264136403799057
    z[0,5,2]  R467      -3.5222183912992477e-02
    z[0,5,2]  R468      3.0547997355461121e-01
    z[0,5,2]  R469      -3.2193638384342194e-02
    z[0,5,2]  R470      4.7409462928771973e-01
    z[0,5,2]  R471      -1.0327765345573425e-01
    z[0,5,2]  R472      6.5677843987941742e-02
    z[0,5,2]  R473      4.6928778290748596e-01
    z[0,5,2]  R474      3.7477472424507141e-01
    z[0,5,2]  R475      -1.6672912240028381e-01
    z[0,5,2]  R476      3.1196582317352295e-01
    z[0,5,2]  R477      -0.039963249117136
    z[0,5,2]  R478      5.4550009965896606e-01
    z[0,5,3]  R5        -1
    z[0,5,3]  R50       1
    z[0,5,3]  R414      -1
    z[0,5,3]  R415      1
    z[0,5,3]  R422      2.4540820717811584e-01
    z[0,5,3]  R423      2.5026738643646240e-01
    z[0,5,3]  R424      3.3378362655639648e-01
    z[0,5,3]  R425      -8.8093864917755127e-01
    z[0,5,3]  R426      -7.1590358018875122e-01
    z[0,5,3]  R427      -0.777795135974884
    z[0,5,3]  R428      -6.5661495923995972e-01
    z[0,5,3]  R429      -8.0041807889938354e-01
    z[0,5,3]  R430      4.3620150536298752e-02
    z[0,5,3]  R431      6.4261603355407715e-01
    z[0,5,3]  R432      -1.7590735852718353e-01
    z[0,5,3]  R433      6.1712156981229782e-02
    z[0,5,3]  R434      2.2831702232360840e-01
    z[0,5,3]  R435      3.3436343073844910e-01
    z[0,5,3]  R436      4.7726336121559143e-01
    z[0,5,3]  R437      6.6573393344879150e-01
    z[0,5,3]  R438      2.4211759865283966e-01
    z[0,5,3]  R439      2.2682611644268036e-01
    z[0,5,3]  R440      1.1412691324949265e-01
    z[0,5,3]  R441      4.5430281758308411e-01
    z[0,5,3]  R442      1.4275726675987244e-01
    z[0,5,3]  R443      7.7638953924179077e-02
    z[0,5,3]  R444      1.5241716802120209e-01
    z[0,5,3]  R445      2.5958317518234253e-01
    z[0,5,3]  R446      2.6987347006797791e-01
    z[0,5,3]  R447      2.0211806893348694e-01
    z[0,5,3]  R448      1.8949033319950104e-01
    z[0,5,3]  R449      1.6944111883640289e-01
    z[0,5,3]  R450      3.4730784595012665e-02
    z[0,5,3]  R451      0.0716017633676529
    z[0,5,3]  R452      -4.2259678244590759e-02
    z[0,5,3]  R453      -2.0097452402114868e-01
    z[0,5,3]  R454      1.9554542005062103e-01
    z[0,5,3]  R455      1.7396594583988190e-01
    z[0,5,3]  R456      8.2013376057147980e-02
    z[0,5,3]  R457      2.1507333219051361e-01
    z[0,5,3]  R458      -3.3189707994461060e-01
    z[0,5,3]  R459      -6.3638072460889816e-03
    z[0,5,3]  R460      -1.6793160140514374e-01
    z[0,5,3]  R461      1.8136581778526306e-01
    z[0,5,3]  R462      4.6828565001487732e-01
    z[0,5,3]  R463      4.3812346458435059e-01
    z[0,5,3]  R464      -1.2449848465621471e-02
    z[0,5,3]  R465      -0.594612181186676
    z[0,5,3]  R466      5.2426481246948242e-01
    z[0,5,3]  R467      -1.9637893140316010e-01
    z[0,5,3]  R468      3.5327067971229553e-01
    z[0,5,3]  R469      -4.8578137159347534e-01
    z[0,5,3]  R470      -3.4470051527023315e-01
    z[0,5,3]  R471      4.2890289425849915e-01
    z[0,5,3]  R472      0.469659686088562
    z[0,5,3]  R473      -1.1294345557689667e-01
    z[0,5,3]  R474      -1.6868086159229279e-01
    z[0,5,3]  R475      -3.0988928675651550e-01
    z[0,5,3]  R476      -3.2227909564971924e-01
    z[0,5,3]  R477      0.128465473651886
    z[0,5,3]  R478      -1.9517371058464050e-01
    z[0,5,4]  R6        -1
    z[0,5,4]  R51       1
    z[0,5,4]  R416      -1
    z[0,5,4]  R417      1
    z[0,5,4]  R422      -1.1821195483207703e-01
    z[0,5,4]  R423      0.591735303401947
    z[0,5,4]  R424      -2.9410383105278015e-01
    z[0,5,4]  R425      3.7483379244804382e-02
    z[0,5,4]  R426      4.0477314591407776e-01
    z[0,5,4]  R427      4.4546425342559814e-01
    z[0,5,4]  R428      5.2349936962127686e-01
    z[0,5,4]  R429      -2.2779973223805428e-02
    z[0,5,4]  R430      4.1214677691459656e-01
    z[0,5,4]  R431      1.6850122809410095e-01
    z[0,5,4]  R432      7.0217676460742950e-02
    z[0,5,4]  R433      1.6411077976226807e-01
    z[0,5,4]  R434      -1.9140003621578217e-01
    z[0,5,4]  R435      -1.6736832261085510e-01
    z[0,5,4]  R436      -2.9139450192451477e-01
    z[0,5,4]  R437      5.8200877159833908e-02
    z[0,5,4]  R438      -4.4286602735519409e-01
    z[0,5,4]  R439      -3.1714653968811035e-01
    z[0,5,4]  R440      -5.7771116495132446e-01
    z[0,5,4]  R441      -4.7654006630182266e-02
    z[0,5,4]  R442      -5.2831107378005981e-01
    z[0,5,4]  R443      -2.0501524209976196e-01
    z[0,5,4]  R444      1.9915629923343658e-01
    z[0,5,4]  R445      -2.8473852202296257e-02
    z[0,5,4]  R446      2.1903726737946272e-03
    z[0,5,4]  R447      -1.1289543658494949e-01
    z[0,5,4]  R448      1.2465568631887436e-01
    z[0,5,4]  R449      5.7221110910177231e-02
    z[0,5,4]  R450      0.257347047328949
    z[0,5,4]  R451      1.5537488460540771e-01
    z[0,5,4]  R452      0.509081244468689
    z[0,5,4]  R453      -3.8225552439689636e-01
    z[0,5,4]  R454      -4.0255087614059448e-01
    z[0,5,4]  R455      -3.5617059469223022e-01
    z[0,5,4]  R456      -1.9378559291362762e-01
    z[0,5,4]  R457      2.9812633991241455e-01
    z[0,5,4]  R458      -7.5686089694499969e-03
    z[0,5,4]  R459      -4.6676734089851379e-01
    z[0,5,4]  R460      4.2089998722076416e-02
    z[0,5,4]  R461      3.8982751965522766e-01
    z[0,5,4]  R462      -2.0247953012585640e-02
    z[0,5,4]  R463      -2.1993450820446014e-01
    z[0,5,4]  R464      -1.3251057267189026e-01
    z[0,5,4]  R465      2.2747045755386353e-01
    z[0,5,4]  R466      -1.0758624225854874e-01
    z[0,5,4]  R467      3.9782109856605530e-01
    z[0,5,4]  R468      -2.3097884654998779e-01
    z[0,5,4]  R469      -1.7669111490249634e-01
    z[0,5,4]  R470      -9.3540467321872711e-02
    z[0,5,4]  R471      1.7631421983242035e-01
    z[0,5,4]  R472      6.2692828476428986e-02
    z[0,5,4]  R473      0.00487328227609396
    z[0,5,4]  R474      -3.2241308689117432e-01
    z[0,5,4]  R475      5.9660151600837708e-02
    z[0,5,4]  R476      2.8520748019218445e-01
    z[0,5,4]  R477      -3.2254624366760254e-01
    z[0,5,4]  R478      -3.8146528601646423e-01
    z[0,5,5]  R7        -1
    z[0,5,5]  R52       1
    z[0,5,5]  R418      -1
    z[0,5,5]  R419      1
    z[0,5,5]  R422      5.8409845829010010e-01
    z[0,5,5]  R423      2.4263417720794678e-01
    z[0,5,5]  R424      4.6235557645559311e-02
    z[0,5,5]  R425      -1.5295599400997162e-01
    z[0,5,5]  R426      -2.7444693446159363e-01
    z[0,5,5]  R427      -2.3713716864585876e-01
    z[0,5,5]  R428      -2.0201796293258667e-01
    z[0,5,5]  R429      -1.4302644133567810e-01
    z[0,5,5]  R430      3.7544753402471542e-02
    z[0,5,5]  R431      -1.6571731865406036e-01
    z[0,5,5]  R432      -6.3504314422607422e-01
    z[0,5,5]  R433      -6.0359042882919312e-01
    z[0,5,5]  R434      2.6212185621261597e-01
    z[0,5,5]  R435      -2.0011414587497711e-01
    z[0,5,5]  R436      1.8095028400421143e-01
    z[0,5,5]  R437      1.8670941889286041e-01
    z[0,5,5]  R438      2.8173556923866272e-01
    z[0,5,5]  R439      3.2619115710258484e-01
    z[0,5,5]  R440      1.0473755002021790e-01
    z[0,5,5]  R441      -1.0862807929515839e-01
    z[0,5,5]  R442      2.0497329533100128e-01
    z[0,5,5]  R443      3.5855319350957870e-02
    z[0,5,5]  R444      -4.4855102896690369e-02
    z[0,5,5]  R445      1.7670363187789917e-01
    z[0,5,5]  R446      -2.0046514272689819e-01
    z[0,5,5]  R447      1.2309648096561432e-02
    z[0,5,5]  R448      -5.4346998222172260e-03
    z[0,5,5]  R449      -1.4700774848461151e-01
    z[0,5,5]  R450      0.254652202129364
    z[0,5,5]  R451      4.0324357151985168e-01
    z[0,5,5]  R452      7.1578228473663330e-01
    z[0,5,5]  R453      7.7692353725433350e-01
    z[0,5,5]  R454      -9.6755344420671463e-03
    z[0,5,5]  R455      -1.6764727234840393e-01
    z[0,5,5]  R456      1.6329331696033478e-01
    z[0,5,5]  R457      -8.9326046407222748e-02
    z[0,5,5]  R458      3.9545886218547821e-02
    z[0,5,5]  R459      -0.0925360694527626
    z[0,5,5]  R460      -4.2166151106357574e-02
    z[0,5,5]  R461      -2.3908782750368118e-02
    z[0,5,5]  R462      -1.8317978084087372e-01
    z[0,5,5]  R463      -3.0318453907966614e-01
    z[0,5,5]  R464      -3.7554496526718140e-01
    z[0,5,5]  R465      -1.3667531311511993e-01
    z[0,5,5]  R466      -1.8587402999401093e-01
    z[0,5,5]  R467      -0.41797935962677
    z[0,5,5]  R468      -2.8581684827804565e-01
    z[0,5,5]  R469      -5.4287356138229370e-01
    z[0,5,5]  R470      2.1530104801058769e-02
    z[0,5,5]  R471      1.1809369176626205e-01
    z[0,5,5]  R472      -1.6922626644372940e-02
    z[0,5,5]  R473      -2.3602357506752014e-01
    z[0,5,5]  R474      1.8345052376389503e-02
    z[0,5,5]  R475      2.6451872661709785e-02
    z[0,5,5]  R476      -2.1056348457932472e-02
    z[0,5,5]  R477      -5.8092761039733887e-01
    z[0,5,5]  R478      -3.7081623449921608e-03
    z[0,5,6]  R8        -1
    z[0,5,6]  R53       1
    z[0,5,6]  R420      -1
    z[0,5,6]  R421      1
    z[0,5,6]  R422      4.1766279935836792e-01
    z[0,5,6]  R423      -6.3886815309524536e-01
    z[0,5,6]  R424      -7.8804391622543335e-01
    z[0,5,6]  R425      -1.3921412825584412e-01
    z[0,5,6]  R426      -4.1416588425636292e-01
    z[0,5,6]  R427      1.6032749414443970e-01
    z[0,5,6]  R428      3.2761093974113464e-01
    z[0,5,6]  R429      -5.0852197408676147e-01
    z[0,5,6]  R430      3.8458669185638428e-01
    z[0,5,6]  R431      2.1136872470378876e-01
    z[0,5,6]  R432      1.1449547111988068e-01
    z[0,5,6]  R433      8.9856550097465515e-02
    z[0,5,6]  R434      6.0445945709943771e-02
    z[0,5,6]  R435      9.0110331773757935e-02
    z[0,5,6]  R436      -6.7995168268680573e-02
    z[0,5,6]  R437      1.7687472701072693e-01
    z[0,5,6]  R438      6.6615156829357147e-03
    z[0,5,6]  R439      -1.5448690950870514e-01
    z[0,5,6]  R440      1.0302581638097763e-01
    z[0,5,6]  R441      2.5487509369850159e-01
    z[0,5,6]  R442      -2.1142115816473961e-02
    z[0,5,6]  R443      1.4957828819751740e-01
    z[0,5,6]  R444      -1.0371533036231995e-01
    z[0,5,6]  R445      7.1663707494735718e-02
    z[0,5,6]  R446      -0.0947442501783371
    z[0,5,6]  R447      3.0178219079971313e-02
    z[0,5,6]  R448      4.3031446635723114e-02
    z[0,5,6]  R449      4.7075446695089340e-02
    z[0,5,6]  R450      2.5707420706748962e-01
    z[0,5,6]  R451      1.3883855938911438e-01
    z[0,5,6]  R452      -3.1722703576087952e-01
    z[0,5,6]  R453      0.0425274521112442
    z[0,5,6]  R454      -3.0511155724525452e-01
    z[0,5,6]  R455      -3.8313925266265869e-01
    z[0,5,6]  R456      3.6319881677627563e-01
    z[0,5,6]  R457      0.387690931558609
    z[0,5,6]  R458      -3.0640125274658203e-01
    z[0,5,6]  R459      0.471548467874527
    z[0,5,6]  R460      -1.3050666451454163e-01
    z[0,5,6]  R461      -3.6141178011894226e-01
    z[0,5,6]  R462      3.1543749570846558e-01
    z[0,5,6]  R463      -5.5901497602462769e-01
    z[0,5,6]  R464      6.1622675508260727e-02
    z[0,5,6]  R465      3.1740683317184448e-01
    z[0,5,6]  R466      -1.1058255285024643e-01
    z[0,5,6]  R467      6.2087923288345337e-02
    z[0,5,6]  R468      1.9308309257030487e-01
    z[0,5,6]  R469      3.9245107769966125e-01
    z[0,5,6]  R470      1.9526550173759460e-01
    z[0,5,6]  R471      1.5403334796428680e-01
    z[0,5,6]  R472      1.1634574830532074e-01
    z[0,5,6]  R473      1.6607512533664703e-01
    z[0,5,6]  R474      4.3586143851280212e-01
    z[0,5,6]  R475      6.7124205827713013e-01
    z[0,5,6]  R476      2.3354444652795792e-02
    z[0,5,6]  R477      0.0557732991874218
    z[0,5,6]  R478      -1.7011800408363342e-01
    z[5,0,0]  R2        1
    z[5,0,0]  R47       -1
    z[5,0,0]  R479      -1
    z[5,0,0]  R480      1
    z[5,0,0]  R493      1.1186915449798107e-02
    z[5,0,0]  R494      -4.8215375281870365e-03
    z[5,0,0]  R495      -3.1158182024955750e-01
    z[5,0,0]  R496      -4.5451480150222778e-01
    z[5,0,0]  R497      -6.3648438453674316e-01
    z[5,0,0]  R498      -5.5495697259902954e-01
    z[5,0,0]  R499      -9.0682422742247581e-03
    z[5,0,0]  R500      1.0719141364097595e-01
    z[5,0,0]  R501      3.4995445609092712e-01
    z[5,0,0]  R502      -3.2522717118263245e-01
    z[5,0,0]  R503      -5.2713447809219360e-01
    z[5,0,0]  R504      1.8959281966090202e-02
    z[5,0,0]  R505      2.4771073460578918e-01
    z[5,0,0]  R506      -6.5029990673065186e-01
    z[5,0,0]  R507      1.4037866890430450e-01
    z[5,0,0]  R508      1.8609800934791565e-01
    z[5,0,0]  R509      -0.00932371336966753
    z[5,0,0]  R510      6.1752386391162872e-02
    z[5,0,0]  R511      -9.8541423678398132e-02
    z[5,0,0]  R512      2.8609317541122437e-01
    z[5,0,0]  R513      8.6865060031414032e-02
    z[5,0,0]  R514      -2.8792256116867065e-01
    z[5,0,0]  R515      -3.8555711507797241e-02
    z[5,0,0]  R516      1.6615432500839233e-01
    z[5,0,0]  R517      -3.5495206713676453e-02
    z[5,0,0]  R518      4.3524277210235596e-01
    z[5,0,0]  R519      2.6447480916976929e-01
    z[5,0,0]  R520      -6.2454563379287720e-01
    z[5,0,0]  R521      -2.1516275405883789e-01
    z[5,0,0]  R522      -1.8671810626983643e-01
    z[5,0,0]  R523      2.7230393886566162e-01
    z[5,0,0]  R524      9.3057401478290558e-02
    z[5,0,0]  R525      -2.2906453907489777e-01
    z[5,0,0]  R526      2.9664814472198486e-01
    z[5,0,0]  R527      -1.0600391775369644e-01
    z[5,0,0]  R528      3.6410665512084961e-01
    z[5,0,0]  R529      6.1475169658660889e-01
    z[5,0,0]  R530      -5.8016985654830933e-01
    z[5,0,0]  R531      -3.5037016868591309e-01
    z[5,0,0]  R532      7.7599966526031494e-01
    z[5,0,0]  R533      0.85499507188797
    z[5,0,0]  R534      5.3688251972198486e-01
    z[5,0,0]  R535      6.2329494953155518e-01
    z[5,0,0]  R536      5.6046378612518311e-01
    z[5,0,0]  R537      5.1575177907943726e-01
    z[5,0,0]  R538      5.4513669013977051e-01
    z[5,0,0]  R539      6.9494730234146118e-01
    z[5,0,0]  R540      4.9062415957450867e-01
    z[5,0,0]  R541      9.5356649160385132e-01
    z[5,0,0]  R542      9.5592629909515381e-01
    z[5,0,0]  R543      0.921034038066864
    z[5,0,0]  R544      9.3095201253890991e-01
    z[5,0,0]  R545      9.5449793338775635e-01
    z[5,0,0]  R546      9.4706481695175171e-01
    z[5,0,0]  R547      0.962475597858429
    z[5,0,0]  R548      8.9228081703186035e-01
    z[5,0,0]  R549      8.8256591558456421e-01
    z[5,0,1]  R3        1
    z[5,0,1]  R48       -1
    z[5,0,1]  R481      -1
    z[5,0,1]  R482      1
    z[5,0,1]  R493      -2.8183379769325256e-01
    z[5,0,1]  R494      -4.3488350510597229e-01
    z[5,0,1]  R495      4.9660235643386841e-01
    z[5,0,1]  R496      6.6657382249832153e-01
    z[5,0,1]  R497      3.3694645762443542e-01
    z[5,0,1]  R498      6.0095584392547607e-01
    z[5,0,1]  R499      8.8974541425704956e-01
    z[5,0,1]  R500      0.454041987657547
    z[5,0,1]  R501      8.6570811271667480e-01
    z[5,0,1]  R502      6.2760341167449951e-01
    z[5,0,1]  R503      -5.5866867303848267e-01
    z[5,0,1]  R504      -5.9417122602462769e-01
    z[5,0,1]  R505      -7.2897613048553467e-01
    z[5,0,1]  R506      0.0097170639783144
    z[5,0,1]  R507      7.5981557369232178e-01
    z[5,0,1]  R508      7.6729327440261841e-01
    z[5,0,1]  R509      7.8068637847900391e-01
    z[5,0,1]  R510      5.2841019630432129e-01
    z[5,0,1]  R511      7.7418565750122070e-01
    z[5,0,1]  R512      8.0917710065841675e-01
    z[5,0,1]  R513      8.6591434478759766e-01
    z[5,0,1]  R514      7.7511388063430786e-01
    z[5,0,1]  R515      7.3167085647583008e-01
    z[5,0,1]  R516      6.2748539447784424e-01
    z[5,0,1]  R517      8.4570759534835815e-01
    z[5,0,1]  R518      5.8977931737899780e-01
    z[5,0,1]  R519      6.4801257848739624e-01
    z[5,0,1]  R520      -1.2198417633771896e-01
    z[5,0,1]  R521      9.1458439826965332e-02
    z[5,0,1]  R522      0.375693142414093
    z[5,0,1]  R523      -0.092345230281353
    z[5,0,1]  R524      -8.6846321821212769e-02
    z[5,0,1]  R525      -2.9356257990002632e-02
    z[5,0,1]  R526      -7.7912271022796631e-02
    z[5,0,1]  R527      -1.3169866800308228e-01
    z[5,0,1]  R528      7.2579711675643921e-01
    z[5,0,1]  R529      -0.264365553855896
    z[5,0,1]  R530      3.0741026997566223e-01
    z[5,0,1]  R531      -0.687488317489624
    z[5,0,1]  R532      8.6378656327724457e-02
    z[5,0,1]  R533      -2.0779383182525635e-01
    z[5,0,1]  R534      -5.7429629564285278e-01
    z[5,0,1]  R535      -3.0606836080551147e-01
    z[5,0,1]  R536      -5.4516541957855225e-01
    z[5,0,1]  R537      -0.578826367855072
    z[5,0,1]  R538      -0.551854133605957
    z[5,0,1]  R539      2.8960263729095459e-01
    z[5,0,1]  R540      -0.589694619178772
    z[5,0,1]  R541      1.0760664939880371e-01
    z[5,0,1]  R542      1.0262688994407654e-01
    z[5,0,1]  R543      1.9474224746227264e-01
    z[5,0,1]  R544      6.3625440001487732e-02
    z[5,0,1]  R545      -1.7975641787052155e-01
    z[5,0,1]  R546      -2.1268384158611298e-01
    z[5,0,1]  R547      -1.3325746357440948e-01
    z[5,0,1]  R548      7.3412582278251648e-02
    z[5,0,1]  R549      7.2798162698745728e-02
    z[5,0,2]  R4        1
    z[5,0,2]  R49       -1
    z[5,0,2]  R483      -1
    z[5,0,2]  R484      1
    z[5,0,2]  R493      -2.1567940711975098e-01
    z[5,0,2]  R494      1.3756586611270905e-01
    z[5,0,2]  R495      -6.0235446691513062e-01
    z[5,0,2]  R496      -1.3066259026527405e-01
    z[5,0,2]  R497      -5.2772867679595947e-01
    z[5,0,2]  R498      -1.9353452324867249e-01
    z[5,0,2]  R499      -0.0511116087436676
    z[5,0,2]  R500      -5.7751423120498657e-01
    z[5,0,2]  R501      2.8160056471824646e-01
    z[5,0,2]  R502      4.2929247021675110e-01
    z[5,0,2]  R503      -2.3929375410079956e-01
    z[5,0,2]  R504      4.3117862194776535e-02
    z[5,0,2]  R505      -4.9465906620025635e-01
    z[5,0,2]  R506      2.2865265607833862e-01
    z[5,0,2]  R507      0.264136403799057
    z[5,0,2]  R508      -3.5222183912992477e-02
    z[5,0,2]  R509      3.0547997355461121e-01
    z[5,0,2]  R510      -3.2193638384342194e-02
    z[5,0,2]  R511      4.7409462928771973e-01
    z[5,0,2]  R512      -1.0327765345573425e-01
    z[5,0,2]  R513      6.5677843987941742e-02
    z[5,0,2]  R514      4.6928778290748596e-01
    z[5,0,2]  R515      3.7477472424507141e-01
    z[5,0,2]  R516      -1.6672912240028381e-01
    z[5,0,2]  R517      3.1196582317352295e-01
    z[5,0,2]  R518      -0.039963249117136
    z[5,0,2]  R519      5.4550009965896606e-01
    z[5,0,2]  R520      -7.2457477450370789e-02
    z[5,0,2]  R521      2.5599226355552673e-01
    z[5,0,2]  R522      5.4143011569976807e-02
    z[5,0,2]  R523      3.1159085035324097e-01
    z[5,0,2]  R524      -2.4613864719867706e-01
    z[5,0,2]  R525      -2.4763885140419006e-01
    z[5,0,2]  R526      -2.2933542728424072e-01
    z[5,0,2]  R527      -2.2622874379158020e-01
    z[5,0,2]  R528      -1.3985931873321533e-01
    z[5,0,2]  R529      -1.9673401117324829e-01
    z[5,0,2]  R530      -3.4152418375015259e-01
    z[5,0,2]  R531      3.8262628018856049e-02
    z[5,0,2]  R532      -4.7878921031951904e-01
    z[5,0,2]  R533      -1.9449584186077118e-01
    z[5,0,2]  R534      1.7855939269065857e-01
    z[5,0,2]  R535      -7.1354568004608154e-02
    z[5,0,2]  R536      2.3346179723739624e-01
    z[5,0,2]  R537      3.4155708551406860e-01
    z[5,0,2]  R538      1.7298434674739838e-01
    z[5,0,2]  R539      -3.8438954949378967e-01
    z[5,0,2]  R540      2.6380854845046997e-01
    z[5,0,2]  R541      -8.6100853979587555e-02
    z[5,0,2]  R542      3.0835436191409826e-03
    z[5,0,2]  R543      -9.6009127795696259e-02
    z[5,0,2]  R544      -8.5328713059425354e-02
    z[5,0,2]  R545      4.4295042753219604e-02
    z[5,0,2]  R546      6.7133486270904541e-02
    z[5,0,2]  R547      -8.4393061697483063e-03
    z[5,0,2]  R548      -8.7759876623749733e-03
    z[5,0,2]  R549      6.8029031157493591e-02
    z[5,0,3]  R5        1
    z[5,0,3]  R50       -1
    z[5,0,3]  R485      -1
    z[5,0,3]  R486      1
    z[5,0,3]  R493      -4.2259678244590759e-02
    z[5,0,3]  R494      -2.0097452402114868e-01
    z[5,0,3]  R495      1.9554542005062103e-01
    z[5,0,3]  R496      1.7396594583988190e-01
    z[5,0,3]  R497      8.2013376057147980e-02
    z[5,0,3]  R498      2.1507333219051361e-01
    z[5,0,3]  R499      -3.3189707994461060e-01
    z[5,0,3]  R500      -6.3638072460889816e-03
    z[5,0,3]  R501      -1.6793160140514374e-01
    z[5,0,3]  R502      1.8136581778526306e-01
    z[5,0,3]  R503      4.6828565001487732e-01
    z[5,0,3]  R504      4.3812346458435059e-01
    z[5,0,3]  R505      -1.2449848465621471e-02
    z[5,0,3]  R506      -0.594612181186676
    z[5,0,3]  R507      5.2426481246948242e-01
    z[5,0,3]  R508      -1.9637893140316010e-01
    z[5,0,3]  R509      3.5327067971229553e-01
    z[5,0,3]  R510      -4.8578137159347534e-01
    z[5,0,3]  R511      -3.4470051527023315e-01
    z[5,0,3]  R512      4.2890289425849915e-01
    z[5,0,3]  R513      0.469659686088562
    z[5,0,3]  R514      -1.1294345557689667e-01
    z[5,0,3]  R515      -1.6868086159229279e-01
    z[5,0,3]  R516      -3.0988928675651550e-01
    z[5,0,3]  R517      -3.2227909564971924e-01
    z[5,0,3]  R518      0.128465473651886
    z[5,0,3]  R519      -1.9517371058464050e-01
    z[5,0,3]  R520      2.4540820717811584e-01
    z[5,0,3]  R521      2.5026738643646240e-01
    z[5,0,3]  R522      3.3378362655639648e-01
    z[5,0,3]  R523      -8.8093864917755127e-01
    z[5,0,3]  R524      -7.1590358018875122e-01
    z[5,0,3]  R525      -0.777795135974884
    z[5,0,3]  R526      -6.5661495923995972e-01
    z[5,0,3]  R527      -8.0041807889938354e-01
    z[5,0,3]  R528      4.3620150536298752e-02
    z[5,0,3]  R529      6.4261603355407715e-01
    z[5,0,3]  R530      -1.7590735852718353e-01
    z[5,0,3]  R531      6.1712156981229782e-02
    z[5,0,3]  R532      2.2831702232360840e-01
    z[5,0,3]  R533      3.3436343073844910e-01
    z[5,0,3]  R534      4.7726336121559143e-01
    z[5,0,3]  R535      6.6573393344879150e-01
    z[5,0,3]  R536      2.4211759865283966e-01
    z[5,0,3]  R537      2.2682611644268036e-01
    z[5,0,3]  R538      1.1412691324949265e-01
    z[5,0,3]  R539      4.5430281758308411e-01
    z[5,0,3]  R540      1.4275726675987244e-01
    z[5,0,3]  R541      7.7638953924179077e-02
    z[5,0,3]  R542      1.5241716802120209e-01
    z[5,0,3]  R543      2.5958317518234253e-01
    z[5,0,3]  R544      2.6987347006797791e-01
    z[5,0,3]  R545      2.0211806893348694e-01
    z[5,0,3]  R546      1.8949033319950104e-01
    z[5,0,3]  R547      1.6944111883640289e-01
    z[5,0,3]  R548      3.4730784595012665e-02
    z[5,0,3]  R549      0.0716017633676529
    z[5,0,4]  R6        1
    z[5,0,4]  R51       -1
    z[5,0,4]  R487      -1
    z[5,0,4]  R488      1
    z[5,0,4]  R493      0.509081244468689
    z[5,0,4]  R494      -3.8225552439689636e-01
    z[5,0,4]  R495      -4.0255087614059448e-01
    z[5,0,4]  R496      -3.5617059469223022e-01
    z[5,0,4]  R497      -1.9378559291362762e-01
    z[5,0,4]  R498      2.9812633991241455e-01
    z[5,0,4]  R499      -7.5686089694499969e-03
    z[5,0,4]  R500      -4.6676734089851379e-01
    z[5,0,4]  R501      4.2089998722076416e-02
    z[5,0,4]  R502      3.8982751965522766e-01
    z[5,0,4]  R503      -2.0247953012585640e-02
    z[5,0,4]  R504      -2.1993450820446014e-01
    z[5,0,4]  R505      -1.3251057267189026e-01
    z[5,0,4]  R506      2.2747045755386353e-01
    z[5,0,4]  R507      -1.0758624225854874e-01
    z[5,0,4]  R508      3.9782109856605530e-01
    z[5,0,4]  R509      -2.3097884654998779e-01
    z[5,0,4]  R510      -1.7669111490249634e-01
    z[5,0,4]  R511      -9.3540467321872711e-02
    z[5,0,4]  R512      1.7631421983242035e-01
    z[5,0,4]  R513      6.2692828476428986e-02
    z[5,0,4]  R514      0.00487328227609396
    z[5,0,4]  R515      -3.2241308689117432e-01
    z[5,0,4]  R516      5.9660151600837708e-02
    z[5,0,4]  R517      2.8520748019218445e-01
    z[5,0,4]  R518      -3.2254624366760254e-01
    z[5,0,4]  R519      -3.8146528601646423e-01
    z[5,0,4]  R520      -1.1821195483207703e-01
    z[5,0,4]  R521      0.591735303401947
    z[5,0,4]  R522      -2.9410383105278015e-01
    z[5,0,4]  R523      3.7483379244804382e-02
    z[5,0,4]  R524      4.0477314591407776e-01
    z[5,0,4]  R525      4.4546425342559814e-01
    z[5,0,4]  R526      5.2349936962127686e-01
    z[5,0,4]  R527      -2.2779973223805428e-02
    z[5,0,4]  R528      4.1214677691459656e-01
    z[5,0,4]  R529      1.6850122809410095e-01
    z[5,0,4]  R530      7.0217676460742950e-02
    z[5,0,4]  R531      1.6411077976226807e-01
    z[5,0,4]  R532      -1.9140003621578217e-01
    z[5,0,4]  R533      -1.6736832261085510e-01
    z[5,0,4]  R534      -2.9139450192451477e-01
    z[5,0,4]  R535      5.8200877159833908e-02
    z[5,0,4]  R536      -4.4286602735519409e-01
    z[5,0,4]  R537      -3.1714653968811035e-01
    z[5,0,4]  R538      -5.7771116495132446e-01
    z[5,0,4]  R539      -4.7654006630182266e-02
    z[5,0,4]  R540      -5.2831107378005981e-01
    z[5,0,4]  R541      -2.0501524209976196e-01
    z[5,0,4]  R542      1.9915629923343658e-01
    z[5,0,4]  R543      -2.8473852202296257e-02
    z[5,0,4]  R544      2.1903726737946272e-03
    z[5,0,4]  R545      -1.1289543658494949e-01
    z[5,0,4]  R546      1.2465568631887436e-01
    z[5,0,4]  R547      5.7221110910177231e-02
    z[5,0,4]  R548      0.257347047328949
    z[5,0,4]  R549      1.5537488460540771e-01
    z[5,0,5]  R7        1
    z[5,0,5]  R52       -1
    z[5,0,5]  R489      -1
    z[5,0,5]  R490      1
    z[5,0,5]  R493      7.1578228473663330e-01
    z[5,0,5]  R494      7.7692353725433350e-01
    z[5,0,5]  R495      -9.6755344420671463e-03
    z[5,0,5]  R496      -1.6764727234840393e-01
    z[5,0,5]  R497      1.6329331696033478e-01
    z[5,0,5]  R498      -8.9326046407222748e-02
    z[5,0,5]  R499      3.9545886218547821e-02
    z[5,0,5]  R500      -0.0925360694527626
    z[5,0,5]  R501      -4.2166151106357574e-02
    z[5,0,5]  R502      -2.3908782750368118e-02
    z[5,0,5]  R503      -1.8317978084087372e-01
    z[5,0,5]  R504      -3.0318453907966614e-01
    z[5,0,5]  R505      -3.7554496526718140e-01
    z[5,0,5]  R506      -1.3667531311511993e-01
    z[5,0,5]  R507      -1.8587402999401093e-01
    z[5,0,5]  R508      -0.41797935962677
    z[5,0,5]  R509      -2.8581684827804565e-01
    z[5,0,5]  R510      -5.4287356138229370e-01
    z[5,0,5]  R511      2.1530104801058769e-02
    z[5,0,5]  R512      1.1809369176626205e-01
    z[5,0,5]  R513      -1.6922626644372940e-02
    z[5,0,5]  R514      -2.3602357506752014e-01
    z[5,0,5]  R515      1.8345052376389503e-02
    z[5,0,5]  R516      2.6451872661709785e-02
    z[5,0,5]  R517      -2.1056348457932472e-02
    z[5,0,5]  R518      -5.8092761039733887e-01
    z[5,0,5]  R519      -3.7081623449921608e-03
    z[5,0,5]  R520      5.8409845829010010e-01
    z[5,0,5]  R521      2.4263417720794678e-01
    z[5,0,5]  R522      4.6235557645559311e-02
    z[5,0,5]  R523      -1.5295599400997162e-01
    z[5,0,5]  R524      -2.7444693446159363e-01
    z[5,0,5]  R525      -2.3713716864585876e-01
    z[5,0,5]  R526      -2.0201796293258667e-01
    z[5,0,5]  R527      -1.4302644133567810e-01
    z[5,0,5]  R528      3.7544753402471542e-02
    z[5,0,5]  R529      -1.6571731865406036e-01
    z[5,0,5]  R530      -6.3504314422607422e-01
    z[5,0,5]  R531      -6.0359042882919312e-01
    z[5,0,5]  R532      2.6212185621261597e-01
    z[5,0,5]  R533      -2.0011414587497711e-01
    z[5,0,5]  R534      1.8095028400421143e-01
    z[5,0,5]  R535      1.8670941889286041e-01
    z[5,0,5]  R536      2.8173556923866272e-01
    z[5,0,5]  R537      3.2619115710258484e-01
    z[5,0,5]  R538      1.0473755002021790e-01
    z[5,0,5]  R539      -1.0862807929515839e-01
    z[5,0,5]  R540      2.0497329533100128e-01
    z[5,0,5]  R541      3.5855319350957870e-02
    z[5,0,5]  R542      -4.4855102896690369e-02
    z[5,0,5]  R543      1.7670363187789917e-01
    z[5,0,5]  R544      -2.0046514272689819e-01
    z[5,0,5]  R545      1.2309648096561432e-02
    z[5,0,5]  R546      -5.4346998222172260e-03
    z[5,0,5]  R547      -1.4700774848461151e-01
    z[5,0,5]  R548      0.254652202129364
    z[5,0,5]  R549      4.0324357151985168e-01
    z[5,0,6]  R8        1
    z[5,0,6]  R53       -1
    z[5,0,6]  R491      -1
    z[5,0,6]  R492      1
    z[5,0,6]  R493      -3.1722703576087952e-01
    z[5,0,6]  R494      0.0425274521112442
    z[5,0,6]  R495      -3.0511155724525452e-01
    z[5,0,6]  R496      -3.8313925266265869e-01
    z[5,0,6]  R497      3.6319881677627563e-01
    z[5,0,6]  R498      0.387690931558609
    z[5,0,6]  R499      -3.0640125274658203e-01
    z[5,0,6]  R500      0.471548467874527
    z[5,0,6]  R501      -1.3050666451454163e-01
    z[5,0,6]  R502      -3.6141178011894226e-01
    z[5,0,6]  R503      3.1543749570846558e-01
    z[5,0,6]  R504      -5.5901497602462769e-01
    z[5,0,6]  R505      6.1622675508260727e-02
    z[5,0,6]  R506      3.1740683317184448e-01
    z[5,0,6]  R507      -1.1058255285024643e-01
    z[5,0,6]  R508      6.2087923288345337e-02
    z[5,0,6]  R509      1.9308309257030487e-01
    z[5,0,6]  R510      3.9245107769966125e-01
    z[5,0,6]  R511      1.9526550173759460e-01
    z[5,0,6]  R512      1.5403334796428680e-01
    z[5,0,6]  R513      1.1634574830532074e-01
    z[5,0,6]  R514      1.6607512533664703e-01
    z[5,0,6]  R515      4.3586143851280212e-01
    z[5,0,6]  R516      6.7124205827713013e-01
    z[5,0,6]  R517      2.3354444652795792e-02
    z[5,0,6]  R518      0.0557732991874218
    z[5,0,6]  R519      -1.7011800408363342e-01
    z[5,0,6]  R520      4.1766279935836792e-01
    z[5,0,6]  R521      -6.3886815309524536e-01
    z[5,0,6]  R522      -7.8804391622543335e-01
    z[5,0,6]  R523      -1.3921412825584412e-01
    z[5,0,6]  R524      -4.1416588425636292e-01
    z[5,0,6]  R525      1.6032749414443970e-01
    z[5,0,6]  R526      3.2761093974113464e-01
    z[5,0,6]  R527      -5.0852197408676147e-01
    z[5,0,6]  R528      3.8458669185638428e-01
    z[5,0,6]  R529      2.1136872470378876e-01
    z[5,0,6]  R530      1.1449547111988068e-01
    z[5,0,6]  R531      8.9856550097465515e-02
    z[5,0,6]  R532      6.0445945709943771e-02
    z[5,0,6]  R533      9.0110331773757935e-02
    z[5,0,6]  R534      -6.7995168268680573e-02
    z[5,0,6]  R535      1.7687472701072693e-01
    z[5,0,6]  R536      6.6615156829357147e-03
    z[5,0,6]  R537      -1.5448690950870514e-01
    z[5,0,6]  R538      1.0302581638097763e-01
    z[5,0,6]  R539      2.5487509369850159e-01
    z[5,0,6]  R540      -2.1142115816473961e-02
    z[5,0,6]  R541      1.4957828819751740e-01
    z[5,0,6]  R542      -1.0371533036231995e-01
    z[5,0,6]  R543      7.1663707494735718e-02
    z[5,0,6]  R544      -0.0947442501783371
    z[5,0,6]  R545      3.0178219079971313e-02
    z[5,0,6]  R546      4.3031446635723114e-02
    z[5,0,6]  R547      4.7075446695089340e-02
    z[5,0,6]  R548      2.5707420706748962e-01
    z[5,0,6]  R549      1.3883855938911438e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R594      -1
    z[1,2,0]  R595      1
    z[1,2,0]  R608      -5.2701896429061890e-01
    z[1,2,0]  R609      -6.6022956371307373e-01
    z[1,2,0]  R610      -3.9918488264083862e-01
    z[1,2,0]  R611      -6.3080924749374390e-01
    z[1,2,0]  R612      -3.8641642779111862e-02
    z[1,2,0]  R613      3.2748532295227051e-01
    z[1,2,0]  R614      -1.4281715452671051e-01
    z[1,2,0]  R615      2.8115930035710335e-02
    z[1,2,0]  R616      4.8787724971771240e-01
    z[1,2,0]  R617      5.6838440895080566e-01
    z[1,2,0]  R618      7.6037323474884033e-01
    z[1,2,0]  R619      7.3263001441955566e-01
    z[1,2,0]  R620      2.6938274502754211e-01
    z[1,2,0]  R621      3.2836100459098816e-01
    z[1,2,0]  R622      1.5567120909690857e-01
    z[1,2,0]  R623      -2.7634192258119583e-02
    z[1,2,0]  R624      4.6901926398277283e-01
    z[1,2,0]  R625      4.5823833346366882e-01
    z[1,2,0]  R626      4.7913977503776550e-01
    z[1,2,0]  R627      8.2334536314010620e-01
    z[1,2,0]  R628      4.3914899230003357e-01
    z[1,2,0]  R629      4.6952396631240845e-01
    z[1,2,0]  R630      2.1861717104911804e-01
    z[1,2,0]  R631      9.2060841619968414e-02
    z[1,2,0]  R632      7.0782944560050964e-02
    z[1,2,0]  R633      7.9928863048553467e-01
    z[1,2,0]  R634      7.1500462293624878e-01
    z[1,2,0]  R635      6.0705816745758057e-01
    z[1,2,0]  R636      6.2082648277282715e-01
    z[1,2,0]  R637      0.608687698841095
    z[1,2,0]  R638      4.1082128882408142e-01
    z[1,2,0]  R639      2.3075322806835175e-01
    z[1,2,0]  R640      3.0020439624786377e-01
    z[1,2,0]  R641      3.1325316429138184e-01
    z[1,2,0]  R642      7.0484243333339691e-02
    z[1,2,0]  R643      -8.2420426607131958e-01
    z[1,2,0]  R644      -1.9736020267009735e-01
    z[1,2,0]  R645      -2.5785785913467407e-01
    z[1,2,0]  R646      -3.7281751632690430e-01
    z[1,2,0]  R647      3.5973957180976868e-01
    z[1,2,0]  R648      -2.0364120602607727e-01
    z[1,2,0]  R649      -7.1394693851470947e-01
    z[1,2,0]  R650      -3.3235621452331543e-01
    z[1,2,0]  R651      -8.0002641677856445e-01
    z[1,2,0]  R652      -5.6969982385635376e-01
    z[1,2,0]  R653      1.5661850571632385e-01
    z[1,2,0]  R654      -3.7715968489646912e-01
    z[1,2,0]  R655      2.8012451529502869e-01
    z[1,2,0]  R656      6.4431659877300262e-02
    z[1,2,0]  R657      1.2779888510704041e-01
    z[1,2,0]  R658      -9.8439827561378479e-02
    z[1,2,0]  R659      -8.0734395980834961e-01
    z[1,2,0]  R660      -3.7942594289779663e-01
    z[1,2,0]  R661      1.3505963981151581e-01
    z[1,2,0]  R662      -2.6683938503265381e-01
    z[1,2,0]  R663      9.1274734586477280e-03
    z[1,2,0]  R664      -2.8737941384315491e-01
    z[1,2,0]  R665      2.9615676403045654e-01
    z[1,2,0]  R666      3.5876259207725525e-02
    z[1,2,0]  R667      -6.0228276997804642e-02
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R596      -1
    z[1,2,1]  R597      1
    z[1,2,1]  R608      -3.0860024690628052e-01
    z[1,2,1]  R609      -2.4361915886402130e-01
    z[1,2,1]  R610      -5.7640874385833740e-01
    z[1,2,1]  R611      -2.1130049228668213e-01
    z[1,2,1]  R612      -4.1637763381004333e-01
    z[1,2,1]  R613      -7.1816705167293549e-02
    z[1,2,1]  R614      -3.7463283538818359e-01
    z[1,2,1]  R615      7.9631936550140381e-01
    z[1,2,1]  R616      7.0636117458343506e-01
    z[1,2,1]  R617      6.2154012918472290e-01
    z[1,2,1]  R618      -2.7536764740943909e-01
    z[1,2,1]  R619      -3.1946226954460144e-01
    z[1,2,1]  R620      -3.0051156878471375e-01
    z[1,2,1]  R621      -4.9794375896453857e-01
    z[1,2,1]  R622      -4.8590126633644104e-01
    z[1,2,1]  R623      6.0431933403015137e-01
    z[1,2,1]  R624      0.425344854593277
    z[1,2,1]  R625      4.1581568121910095e-01
    z[1,2,1]  R626      5.9549266099929810e-01
    z[1,2,1]  R627      2.9417762160301208e-01
    z[1,2,1]  R628      -7.5883507728576660e-01
    z[1,2,1]  R629      6.8023461103439331e-01
    z[1,2,1]  R630      5.3482437133789062e-01
    z[1,2,1]  R631      5.6130027770996094e-01
    z[1,2,1]  R632      6.7508327960968018e-01
    z[1,2,1]  R633      2.8388798236846924e-01
    z[1,2,1]  R634      2.8720188140869141e-01
    z[1,2,1]  R635      1.7600784078240395e-02
    z[1,2,1]  R636      3.5477582365274429e-02
    z[1,2,1]  R637      2.3356939852237701e-01
    z[1,2,1]  R638      4.1129791736602783e-01
    z[1,2,1]  R639      4.2444208264350891e-01
    z[1,2,1]  R640      5.1897394657135010e-01
    z[1,2,1]  R641      4.0083104372024536e-01
    z[1,2,1]  R642      3.3503478765487671e-01
    z[1,2,1]  R643      -9.4895556569099426e-02
    z[1,2,1]  R644      -6.8664211034774780e-01
    z[1,2,1]  R645      -0.662268877029419
    z[1,2,1]  R646      -7.2935426235198975e-01
    z[1,2,1]  R647      -8.5722547769546509e-01
    z[1,2,1]  R648      3.4180215001106262e-01
    z[1,2,1]  R649      -7.9283893108367920e-02
    z[1,2,1]  R650      -0.656761646270752
    z[1,2,1]  R651      -8.5472755134105682e-02
    z[1,2,1]  R652      -2.9222324490547180e-01
    z[1,2,1]  R653      -0.798236072063446
    z[1,2,1]  R654      -6.6360962390899658e-01
    z[1,2,1]  R655      -0.776215136051178
    z[1,2,1]  R656      -6.1289650201797485e-01
    z[1,2,1]  R657      -7.3274105787277222e-01
    z[1,2,1]  R658      1.6262401640415192e-01
    z[1,2,1]  R659      -3.2446837425231934e-01
    z[1,2,1]  R660      -6.4932662248611450e-01
    z[1,2,1]  R661      -7.8822964429855347e-01
    z[1,2,1]  R662      -6.6239368915557861e-01
    z[1,2,1]  R663      -6.8379777669906616e-01
    z[1,2,1]  R664      -9.2993378639221191e-01
    z[1,2,1]  R665      -8.1093680858612061e-01
    z[1,2,1]  R666      -8.6881810426712036e-01
    z[1,2,1]  R667      -9.3162292242050171e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R598      -1
    z[1,2,2]  R599      1
    z[1,2,2]  R608      -7.3367103934288025e-02
    z[1,2,2]  R609      3.4189385175704956e-01
    z[1,2,2]  R610      -4.3580028414726257e-01
    z[1,2,2]  R611      -2.1349430084228516e-01
    z[1,2,2]  R612      -5.0967878103256226e-01
    z[1,2,2]  R613      0.538462221622467
    z[1,2,2]  R614      6.6521264612674713e-02
    z[1,2,2]  R615      -4.6898941509425640e-03
    z[1,2,2]  R616      1.2886713445186615e-01
    z[1,2,2]  R617      -0.078705795109272
    z[1,2,2]  R618      -1.4823172986507416e-01
    z[1,2,2]  R619      -4.1306626051664352e-02
    z[1,2,2]  R620      7.7481961250305176e-01
    z[1,2,2]  R621      2.3591910302639008e-01
    z[1,2,2]  R622      1.7579600214958191e-01
    z[1,2,2]  R623      -7.0705376565456390e-02
    z[1,2,2]  R624      -0.272341251373291
    z[1,2,2]  R625      -1.0895549505949020e-01
    z[1,2,2]  R626      2.1447060629725456e-02
    z[1,2,2]  R627      -0.137451633810997
    z[1,2,2]  R628      0.104074627161026
    z[1,2,2]  R629      1.7202684283256531e-01
    z[1,2,2]  R630      4.6460142731666565e-01
    z[1,2,2]  R631      7.0214158296585083e-01
    z[1,2,2]  R632      5.3557169437408447e-01
    z[1,2,2]  R633      -2.0220211148262024e-01
    z[1,2,2]  R634      -1.4364443719387054e-01
    z[1,2,2]  R635      -1.1826439946889877e-01
    z[1,2,2]  R636      -2.1277801692485809e-01
    z[1,2,2]  R637      -4.3242448568344116e-01
    z[1,2,2]  R638      -5.0281691364943981e-03
    z[1,2,2]  R639      3.9302808046340942e-01
    z[1,2,2]  R640      1.3175579905509949e-01
    z[1,2,2]  R641      2.2822003066539764e-01
    z[1,2,2]  R642      2.6929777860641479e-01
    z[1,2,2]  R643      -2.3216364905238152e-02
    z[1,2,2]  R644      1.1330621689558029e-01
    z[1,2,2]  R645      3.2696780562400818e-01
    z[1,2,2]  R646      1.3560181856155396e-01
    z[1,2,2]  R647      1.5116095542907715e-01
    z[1,2,2]  R648      -4.2924135923385620e-01
    z[1,2,2]  R649      3.9347419142723083e-01
    z[1,2,2]  R650      1.5058565139770508e-01
    z[1,2,2]  R651      2.9819962382316589e-01
    z[1,2,2]  R652      0.632092297077179
    z[1,2,2]  R653      3.8131404668092728e-02
    z[1,2,2]  R654      -6.9550216197967529e-02
    z[1,2,2]  R655      -3.7918922305107117e-01
    z[1,2,2]  R656      3.9668749086558819e-03
    z[1,2,2]  R657      -4.9010598659515381e-01
    z[1,2,2]  R658      -5.9355926513671875e-01
    z[1,2,2]  R659      1.6943012177944183e-01
    z[1,2,2]  R660      -2.0457480847835541e-01
    z[1,2,2]  R661      -1.8478755652904510e-01
    z[1,2,2]  R662      -2.4520482122898102e-01
    z[1,2,2]  R663      1.4782798290252686e-01
    z[1,2,2]  R664      1.2678916752338409e-01
    z[1,2,2]  R665      2.1323013305664062e-01
    z[1,2,2]  R666      -1.0945250838994980e-01
    z[1,2,2]  R667      -2.0598389208316803e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R600      -1
    z[1,2,3]  R601      1
    z[1,2,3]  R608      -7.2126221656799316e-01
    z[1,2,3]  R609      -3.7648153305053711e-01
    z[1,2,3]  R610      0.108011893928051
    z[1,2,3]  R611      1.1943751573562622e-01
    z[1,2,3]  R612      -1.5580879151821136e-01
    z[1,2,3]  R613      -3.8042029738426208e-01
    z[1,2,3]  R614      3.7178599834442139e-01
    z[1,2,3]  R615      1.7014692723751068e-01
    z[1,2,3]  R616      1.1572734266519547e-01
    z[1,2,3]  R617      4.5022162795066833e-01
    z[1,2,3]  R618      -2.4338285624980927e-01
    z[1,2,3]  R619      5.6788083165884018e-02
    z[1,2,3]  R620      8.5707187652587891e-02
    z[1,2,3]  R621      7.1806603670120239e-01
    z[1,2,3]  R622      0.564498245716095
    z[1,2,3]  R623      8.1387780606746674e-02
    z[1,2,3]  R624      -3.8180518895387650e-02
    z[1,2,3]  R625      -3.8070392608642578e-01
    z[1,2,3]  R626      -3.9326062798500061e-01
    z[1,2,3]  R627      3.1312260031700134e-01
    z[1,2,3]  R628      1.9833179190754890e-02
    z[1,2,3]  R629      -3.5487979650497437e-02
    z[1,2,3]  R630      -2.7073004841804504e-01
    z[1,2,3]  R631      -9.8129108548164368e-02
    z[1,2,3]  R632      1.0215727984905243e-01
    z[1,2,3]  R633      4.4515532255172729e-01
    z[1,2,3]  R634      4.6612039208412170e-01
    z[1,2,3]  R635      6.9420111179351807e-01
    z[1,2,3]  R636      7.0787101984024048e-01
    z[1,2,3]  R637      5.2529454231262207e-01
    z[1,2,3]  R638      6.2967991828918457e-01
    z[1,2,3]  R639      4.2992448806762695e-01
    z[1,2,3]  R640      -3.1996479630470276e-01
    z[1,2,3]  R641      -6.8285381793975830e-01
    z[1,2,3]  R642      -4.3336641788482666e-01
    z[1,2,3]  R643      -3.1596380472183228e-01
    z[1,2,3]  R644      3.7232673168182373e-01
    z[1,2,3]  R645      4.9252521991729736e-01
    z[1,2,3]  R646      3.8690242171287537e-01
    z[1,2,3]  R647      9.1316811740398407e-02
    z[1,2,3]  R648      2.4188812077045441e-01
    z[1,2,3]  R649      2.2152094542980194e-01
    z[1,2,3]  R650      6.0156309604644775e-01
    z[1,2,3]  R651      8.1735335290431976e-02
    z[1,2,3]  R652      1.6186475753784180e-02
    z[1,2,3]  R653      3.8005319237709045e-01
    z[1,2,3]  R654      4.4550243020057678e-01
    z[1,2,3]  R655      3.5873657464981079e-01
    z[1,2,3]  R656      6.7233246564865112e-01
    z[1,2,3]  R657      4.4264367222785950e-01
    z[1,2,3]  R658      2.1618527173995972e-01
    z[1,2,3]  R659      -0.0953526645898819
    z[1,2,3]  R660      5.7371973991394043e-01
    z[1,2,3]  R661      4.2816025018692017e-01
    z[1,2,3]  R662      0.508263349533081
    z[1,2,3]  R663      6.0387039184570312e-01
    z[1,2,3]  R664      1.8024496734142303e-01
    z[1,2,3]  R665      3.6991345882415771e-01
    z[1,2,3]  R666      2.5764605402946472e-01
    z[1,2,3]  R667      8.3447188138961792e-02
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R602      -1
    z[1,2,4]  R603      1
    z[1,2,4]  R608      1.8563615158200264e-02
    z[1,2,4]  R609      4.8742804676294327e-02
    z[1,2,4]  R610      2.1600225567817688e-01
    z[1,2,4]  R611      -6.3330513238906860e-01
    z[1,2,4]  R612      -6.1474514007568359e-01
    z[1,2,4]  R613      6.2007820606231689e-01
    z[1,2,4]  R614      1.1409016698598862e-01
    z[1,2,4]  R615      2.7734309434890747e-01
    z[1,2,4]  R616      -2.7945801615715027e-01
    z[1,2,4]  R617      -1.0434918105602264e-01
    z[1,2,4]  R618      -0.00574418343603611
    z[1,2,4]  R619      -2.4857813119888306e-01
    z[1,2,4]  R620      -4.4940817356109619e-01
    z[1,2,4]  R621      -3.0068006366491318e-02
    z[1,2,4]  R622      1.5575060248374939e-01
    z[1,2,4]  R623      -2.9704365134239197e-01
    z[1,2,4]  R624      4.6199128031730652e-01
    z[1,2,4]  R625      5.6697374582290649e-01
    z[1,2,4]  R626      1.7257489264011383e-01
    z[1,2,4]  R627      3.1518572568893433e-01
    z[1,2,4]  R628      0.251932293176651
    z[1,2,4]  R629      -3.6011943221092224e-01
    z[1,2,4]  R630      4.5508152246475220e-01
    z[1,2,4]  R631      1.9532330334186554e-01
    z[1,2,4]  R632      1.0214227437973022e-01
    z[1,2,4]  R633      1.1158791929483414e-01
    z[1,2,4]  R634      3.6181509494781494e-01
    z[1,2,4]  R635      1.6459262371063232e-01
    z[1,2,4]  R636      6.1250500380992889e-02
    z[1,2,4]  R637      -0.228758305311203
    z[1,2,4]  R638      1.3164044916629791e-01
    z[1,2,4]  R639      2.1666148304939270e-01
    z[1,2,4]  R640      0.144708052277565
    z[1,2,4]  R641      4.3102821707725525e-01
    z[1,2,4]  R642      -7.0655143260955811e-01
    z[1,2,4]  R643      -1.3440373539924622e-01
    z[1,2,4]  R644      -4.0865597128868103e-01
    z[1,2,4]  R645      3.2016980648040771e-01
    z[1,2,4]  R646      -1.4649938791990280e-02
    z[1,2,4]  R647      1.4581990242004395e-01
    z[1,2,4]  R648      -1.7378675937652588e-01
    z[1,2,4]  R649      0.144618958234787
    z[1,2,4]  R650      -8.2724452018737793e-02
    z[1,2,4]  R651      2.6303216814994812e-01
    z[1,2,4]  R652      -1.1931933462619781e-01
    z[1,2,4]  R653      3.5996192693710327e-01
    z[1,2,4]  R654      9.8586179316043854e-02
    z[1,2,4]  R655      7.0899382233619690e-02
    z[1,2,4]  R656      0.139943465590477
    z[1,2,4]  R657      2.8142226859927177e-02
    z[1,2,4]  R658      -4.9839276075363159e-01
    z[1,2,4]  R659      2.7118235826492310e-01
    z[1,2,4]  R660      -1.1143181473016739e-02
    z[1,2,4]  R661      -2.5423717498779297e-01
    z[1,2,4]  R662      -3.1971356272697449e-01
    z[1,2,4]  R663      -1.6451187431812286e-01
    z[1,2,4]  R664      4.0888965129852295e-02
    z[1,2,4]  R665      -0.165586456656456
    z[1,2,4]  R666      3.2327935099601746e-01
    z[1,2,4]  R667      -2.5632831454277039e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R604      -1
    z[1,2,5]  R605      1
    z[1,2,5]  R608      3.4723851829767227e-02
    z[1,2,5]  R609      -3.2207381725311279e-01
    z[1,2,5]  R610      -4.2285212874412537e-01
    z[1,2,5]  R611      -2.9673242568969727e-01
    z[1,2,5]  R612      -1.4082315564155579e-01
    z[1,2,5]  R613      -2.5233942270278931e-01
    z[1,2,5]  R614      8.2357627153396606e-01
    z[1,2,5]  R615      -5.0738650560379028e-01
    z[1,2,5]  R616      -2.7238273620605469e-01
    z[1,2,5]  R617      -2.3493853211402893e-01
    z[1,2,5]  R618      5.1415461301803589e-01
    z[1,2,5]  R619      1.5697108209133148e-01
    z[1,2,5]  R620      9.9229268729686737e-02
    z[1,2,5]  R621      5.0024546682834625e-02
    z[1,2,5]  R622      2.0019714534282684e-01
    z[1,2,5]  R623      4.6729168295860291e-01
    z[1,2,5]  R624      0.555384635925293
    z[1,2,5]  R625      2.6711070537567139e-01
    z[1,2,5]  R626      -3.8205191493034363e-02
    z[1,2,5]  R627      1.2230596691370010e-01
    z[1,2,5]  R628      9.9092327058315277e-02
    z[1,2,5]  R629      3.7132516503334045e-01
    z[1,2,5]  R630      2.4346999824047089e-01
    z[1,2,5]  R631      3.6300173401832581e-01
    z[1,2,5]  R632      3.1244638562202454e-01
    z[1,2,5]  R633      -1.0658074170351028e-01
    z[1,2,5]  R634      -1.8484708666801453e-01
    z[1,2,5]  R635      2.6160871982574463e-01
    z[1,2,5]  R636      4.0985457599163055e-02
    z[1,2,5]  R637      2.9875887557864189e-02
    z[1,2,5]  R638      4.1973805427551270e-01
    z[1,2,5]  R639      4.1488382220268250e-01
    z[1,2,5]  R640      -4.5210793614387512e-01
    z[1,2,5]  R641      -1.6175678372383118e-01
    z[1,2,5]  R642      -2.9067766666412354e-01
    z[1,2,5]  R643      3.1963995099067688e-01
    z[1,2,5]  R644      4.1255286335945129e-01
    z[1,2,5]  R645      0.0674590989947319
    z[1,2,5]  R646      -3.3464255928993225e-01
    z[1,2,5]  R647      -9.9096536636352539e-02
    z[1,2,5]  R648      -6.7073583602905273e-01
    z[1,2,5]  R649      1.1968901753425598e-01
    z[1,2,5]  R650      2.2094377782195807e-03
    z[1,2,5]  R651      -2.8939110040664673e-01
    z[1,2,5]  R652      3.8329422473907471e-01
    z[1,2,5]  R653      9.4530224800109863e-02
    z[1,2,5]  R654      2.8302699327468872e-01
    z[1,2,5]  R655      1.8131180107593536e-01
    z[1,2,5]  R656      -3.8422411680221558e-01
    z[1,2,5]  R657      -2.2456111386418343e-02
    z[1,2,5]  R658      -1.0661100596189499e-01
    z[1,2,5]  R659      3.2412678003311157e-01
    z[1,2,5]  R660      2.5091582536697388e-01
    z[1,2,5]  R661      1.4982797205448151e-01
    z[1,2,5]  R662      0.229428231716156
    z[1,2,5]  R663      -0.286403626203537
    z[1,2,5]  R664      -2.8573716059327126e-02
    z[1,2,5]  R665      -2.8184045106172562e-02
    z[1,2,5]  R666      -2.0938961207866669e-01
    z[1,2,5]  R667      -8.0055460333824158e-02
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R606      -1
    z[1,2,6]  R607      1
    z[1,2,6]  R608      3.1601378321647644e-01
    z[1,2,6]  R609      -3.7417837977409363e-01
    z[1,2,6]  R610      2.8522792458534241e-01
    z[1,2,6]  R611      0.0919843465089798
    z[1,2,6]  R612      -3.7860912084579468e-01
    z[1,2,6]  R613      6.9010592997074127e-02
    z[1,2,6]  R614      7.2863809764385223e-02
    z[1,2,6]  R615      4.1865069419145584e-02
    z[1,2,6]  R616      -2.8414955735206604e-01
    z[1,2,6]  R617      -0.125092551112175
    z[1,2,6]  R618      2.0233482122421265e-02
    z[1,2,6]  R619      5.1945644617080688e-01
    z[1,2,6]  R620      1.3274191319942474e-01
    z[1,2,6]  R621      -2.6371926069259644e-01
    z[1,2,6]  R622      -5.7075989246368408e-01
    z[1,2,6]  R623      5.6197410821914673e-01
    z[1,2,6]  R624      -3.9840653538703918e-02
    z[1,2,6]  R625      -2.5980910658836365e-01
    z[1,2,6]  R626      4.7901767492294312e-01
    z[1,2,6]  R627      6.5745405852794647e-02
    z[1,2,6]  R628      -3.8314926624298096e-01
    z[1,2,6]  R629      1.3567297160625458e-01
    z[1,2,6]  R630      3.3263084292411804e-01
    z[1,2,6]  R631      -6.2555171549320221e-02
    z[1,2,6]  R632      3.6595532298088074e-01
    z[1,2,6]  R633      -1.3298501074314117e-01
    z[1,2,6]  R634      5.7471200823783875e-02
    z[1,2,6]  R635      -1.9934695959091187e-01
    z[1,2,6]  R636      -2.4804943799972534e-01
    z[1,2,6]  R637      2.4247968196868896e-01
    z[1,2,6]  R638      -2.6838135719299316e-01
    z[1,2,6]  R639      4.5631670951843262e-01
    z[1,2,6]  R640      -5.4356628656387329e-01
    z[1,2,6]  R641      1.0432038456201553e-01
    z[1,2,6]  R642      -1.9684359431266785e-01
    z[1,2,6]  R643      3.0178797245025635e-01
    z[1,2,6]  R644      3.0108574777841568e-02
    z[1,2,6]  R645      -1.9585911929607391e-01
    z[1,2,6]  R646      -2.2083434462547302e-01
    z[1,2,6]  R647      2.7107185125350952e-01
    z[1,2,6]  R648      3.4475368261337280e-01
    z[1,2,6]  R649      -4.9483355879783630e-01
    z[1,2,6]  R650      2.5845885276794434e-01
    z[1,2,6]  R651      -3.2266917824745178e-01
    z[1,2,6]  R652      -1.7056754231452942e-01
    z[1,2,6]  R653      2.3213557898998260e-01
    z[1,2,6]  R654      0.352476567029953
    z[1,2,6]  R655      9.2968977987766266e-02
    z[1,2,6]  R656      0.0307808555662632
    z[1,2,6]  R657      -9.6563078463077545e-02
    z[1,2,6]  R658      5.5231606960296631e-01
    z[1,2,6]  R659      1.6284777224063873e-01
    z[1,2,6]  R660      1.7968676984310150e-02
    z[1,2,6]  R661      -2.3643250763416290e-01
    z[1,2,6]  R662      -1.2930619716644287e-01
    z[1,2,6]  R663      1.9165965914726257e-01
    z[1,2,6]  R664      3.9800401777029037e-02
    z[1,2,6]  R665      -2.1013411879539490e-01
    z[1,2,6]  R666      -1.3097006082534790e-01
    z[1,2,6]  R667      -8.3338119089603424e-02
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R668      -1
    z[2,1,0]  R669      1
    z[2,1,0]  R682      4.1082128882408142e-01
    z[2,1,0]  R683      2.3075322806835175e-01
    z[2,1,0]  R684      3.0020439624786377e-01
    z[2,1,0]  R685      3.1325316429138184e-01
    z[2,1,0]  R686      7.0484243333339691e-02
    z[2,1,0]  R687      -8.2420426607131958e-01
    z[2,1,0]  R688      -1.9736020267009735e-01
    z[2,1,0]  R689      -2.5785785913467407e-01
    z[2,1,0]  R690      -3.7281751632690430e-01
    z[2,1,0]  R691      3.5973957180976868e-01
    z[2,1,0]  R692      -2.0364120602607727e-01
    z[2,1,0]  R693      -7.1394693851470947e-01
    z[2,1,0]  R694      -3.3235621452331543e-01
    z[2,1,0]  R695      -8.0002641677856445e-01
    z[2,1,0]  R696      -5.6969982385635376e-01
    z[2,1,0]  R697      1.5661850571632385e-01
    z[2,1,0]  R698      -3.7715968489646912e-01
    z[2,1,0]  R699      2.8012451529502869e-01
    z[2,1,0]  R700      6.4431659877300262e-02
    z[2,1,0]  R701      1.2779888510704041e-01
    z[2,1,0]  R702      -9.8439827561378479e-02
    z[2,1,0]  R703      -8.0734395980834961e-01
    z[2,1,0]  R704      -3.7942594289779663e-01
    z[2,1,0]  R705      1.3505963981151581e-01
    z[2,1,0]  R706      -2.6683938503265381e-01
    z[2,1,0]  R707      9.1274734586477280e-03
    z[2,1,0]  R708      -2.8737941384315491e-01
    z[2,1,0]  R709      2.9615676403045654e-01
    z[2,1,0]  R710      3.5876259207725525e-02
    z[2,1,0]  R711      -6.0228276997804642e-02
    z[2,1,0]  R712      -5.2701896429061890e-01
    z[2,1,0]  R713      -6.6022956371307373e-01
    z[2,1,0]  R714      -3.9918488264083862e-01
    z[2,1,0]  R715      -6.3080924749374390e-01
    z[2,1,0]  R716      -3.8641642779111862e-02
    z[2,1,0]  R717      3.2748532295227051e-01
    z[2,1,0]  R718      -1.4281715452671051e-01
    z[2,1,0]  R719      2.8115930035710335e-02
    z[2,1,0]  R720      4.8787724971771240e-01
    z[2,1,0]  R721      5.6838440895080566e-01
    z[2,1,0]  R722      7.6037323474884033e-01
    z[2,1,0]  R723      7.3263001441955566e-01
    z[2,1,0]  R724      2.6938274502754211e-01
    z[2,1,0]  R725      3.2836100459098816e-01
    z[2,1,0]  R726      1.5567120909690857e-01
    z[2,1,0]  R727      -2.7634192258119583e-02
    z[2,1,0]  R728      4.6901926398277283e-01
    z[2,1,0]  R729      4.5823833346366882e-01
    z[2,1,0]  R730      4.7913977503776550e-01
    z[2,1,0]  R731      8.2334536314010620e-01
    z[2,1,0]  R732      4.3914899230003357e-01
    z[2,1,0]  R733      4.6952396631240845e-01
    z[2,1,0]  R734      2.1861717104911804e-01
    z[2,1,0]  R735      9.2060841619968414e-02
    z[2,1,0]  R736      7.0782944560050964e-02
    z[2,1,0]  R737      7.9928863048553467e-01
    z[2,1,0]  R738      7.1500462293624878e-01
    z[2,1,0]  R739      6.0705816745758057e-01
    z[2,1,0]  R740      6.2082648277282715e-01
    z[2,1,0]  R741      0.608687698841095
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R670      -1
    z[2,1,1]  R671      1
    z[2,1,1]  R682      4.1129791736602783e-01
    z[2,1,1]  R683      4.2444208264350891e-01
    z[2,1,1]  R684      5.1897394657135010e-01
    z[2,1,1]  R685      4.0083104372024536e-01
    z[2,1,1]  R686      3.3503478765487671e-01
    z[2,1,1]  R687      -9.4895556569099426e-02
    z[2,1,1]  R688      -6.8664211034774780e-01
    z[2,1,1]  R689      -0.662268877029419
    z[2,1,1]  R690      -7.2935426235198975e-01
    z[2,1,1]  R691      -8.5722547769546509e-01
    z[2,1,1]  R692      3.4180215001106262e-01
    z[2,1,1]  R693      -7.9283893108367920e-02
    z[2,1,1]  R694      -0.656761646270752
    z[2,1,1]  R695      -8.5472755134105682e-02
    z[2,1,1]  R696      -2.9222324490547180e-01
    z[2,1,1]  R697      -0.798236072063446
    z[2,1,1]  R698      -6.6360962390899658e-01
    z[2,1,1]  R699      -0.776215136051178
    z[2,1,1]  R700      -6.1289650201797485e-01
    z[2,1,1]  R701      -7.3274105787277222e-01
    z[2,1,1]  R702      1.6262401640415192e-01
    z[2,1,1]  R703      -3.2446837425231934e-01
    z[2,1,1]  R704      -6.4932662248611450e-01
    z[2,1,1]  R705      -7.8822964429855347e-01
    z[2,1,1]  R706      -6.6239368915557861e-01
    z[2,1,1]  R707      -6.8379777669906616e-01
    z[2,1,1]  R708      -9.2993378639221191e-01
    z[2,1,1]  R709      -8.1093680858612061e-01
    z[2,1,1]  R710      -8.6881810426712036e-01
    z[2,1,1]  R711      -9.3162292242050171e-01
    z[2,1,1]  R712      -3.0860024690628052e-01
    z[2,1,1]  R713      -2.4361915886402130e-01
    z[2,1,1]  R714      -5.7640874385833740e-01
    z[2,1,1]  R715      -2.1130049228668213e-01
    z[2,1,1]  R716      -4.1637763381004333e-01
    z[2,1,1]  R717      -7.1816705167293549e-02
    z[2,1,1]  R718      -3.7463283538818359e-01
    z[2,1,1]  R719      7.9631936550140381e-01
    z[2,1,1]  R720      7.0636117458343506e-01
    z[2,1,1]  R721      6.2154012918472290e-01
    z[2,1,1]  R722      -2.7536764740943909e-01
    z[2,1,1]  R723      -3.1946226954460144e-01
    z[2,1,1]  R724      -3.0051156878471375e-01
    z[2,1,1]  R725      -4.9794375896453857e-01
    z[2,1,1]  R726      -4.8590126633644104e-01
    z[2,1,1]  R727      6.0431933403015137e-01
    z[2,1,1]  R728      0.425344854593277
    z[2,1,1]  R729      4.1581568121910095e-01
    z[2,1,1]  R730      5.9549266099929810e-01
    z[2,1,1]  R731      2.9417762160301208e-01
    z[2,1,1]  R732      -7.5883507728576660e-01
    z[2,1,1]  R733      6.8023461103439331e-01
    z[2,1,1]  R734      5.3482437133789062e-01
    z[2,1,1]  R735      5.6130027770996094e-01
    z[2,1,1]  R736      6.7508327960968018e-01
    z[2,1,1]  R737      2.8388798236846924e-01
    z[2,1,1]  R738      2.8720188140869141e-01
    z[2,1,1]  R739      1.7600784078240395e-02
    z[2,1,1]  R740      3.5477582365274429e-02
    z[2,1,1]  R741      2.3356939852237701e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R672      -1
    z[2,1,2]  R673      1
    z[2,1,2]  R682      -5.0281691364943981e-03
    z[2,1,2]  R683      3.9302808046340942e-01
    z[2,1,2]  R684      1.3175579905509949e-01
    z[2,1,2]  R685      2.2822003066539764e-01
    z[2,1,2]  R686      2.6929777860641479e-01
    z[2,1,2]  R687      -2.3216364905238152e-02
    z[2,1,2]  R688      1.1330621689558029e-01
    z[2,1,2]  R689      3.2696780562400818e-01
    z[2,1,2]  R690      1.3560181856155396e-01
    z[2,1,2]  R691      1.5116095542907715e-01
    z[2,1,2]  R692      -4.2924135923385620e-01
    z[2,1,2]  R693      3.9347419142723083e-01
    z[2,1,2]  R694      1.5058565139770508e-01
    z[2,1,2]  R695      2.9819962382316589e-01
    z[2,1,2]  R696      0.632092297077179
    z[2,1,2]  R697      3.8131404668092728e-02
    z[2,1,2]  R698      -6.9550216197967529e-02
    z[2,1,2]  R699      -3.7918922305107117e-01
    z[2,1,2]  R700      3.9668749086558819e-03
    z[2,1,2]  R701      -4.9010598659515381e-01
    z[2,1,2]  R702      -5.9355926513671875e-01
    z[2,1,2]  R703      1.6943012177944183e-01
    z[2,1,2]  R704      -2.0457480847835541e-01
    z[2,1,2]  R705      -1.8478755652904510e-01
    z[2,1,2]  R706      -2.4520482122898102e-01
    z[2,1,2]  R707      1.4782798290252686e-01
    z[2,1,2]  R708      1.2678916752338409e-01
    z[2,1,2]  R709      2.1323013305664062e-01
    z[2,1,2]  R710      -1.0945250838994980e-01
    z[2,1,2]  R711      -2.0598389208316803e-01
    z[2,1,2]  R712      -7.3367103934288025e-02
    z[2,1,2]  R713      3.4189385175704956e-01
    z[2,1,2]  R714      -4.3580028414726257e-01
    z[2,1,2]  R715      -2.1349430084228516e-01
    z[2,1,2]  R716      -5.0967878103256226e-01
    z[2,1,2]  R717      0.538462221622467
    z[2,1,2]  R718      6.6521264612674713e-02
    z[2,1,2]  R719      -4.6898941509425640e-03
    z[2,1,2]  R720      1.2886713445186615e-01
    z[2,1,2]  R721      -0.078705795109272
    z[2,1,2]  R722      -1.4823172986507416e-01
    z[2,1,2]  R723      -4.1306626051664352e-02
    z[2,1,2]  R724      7.7481961250305176e-01
    z[2,1,2]  R725      2.3591910302639008e-01
    z[2,1,2]  R726      1.7579600214958191e-01
    z[2,1,2]  R727      -7.0705376565456390e-02
    z[2,1,2]  R728      -0.272341251373291
    z[2,1,2]  R729      -1.0895549505949020e-01
    z[2,1,2]  R730      2.1447060629725456e-02
    z[2,1,2]  R731      -0.137451633810997
    z[2,1,2]  R732      0.104074627161026
    z[2,1,2]  R733      1.7202684283256531e-01
    z[2,1,2]  R734      4.6460142731666565e-01
    z[2,1,2]  R735      7.0214158296585083e-01
    z[2,1,2]  R736      5.3557169437408447e-01
    z[2,1,2]  R737      -2.0220211148262024e-01
    z[2,1,2]  R738      -1.4364443719387054e-01
    z[2,1,2]  R739      -1.1826439946889877e-01
    z[2,1,2]  R740      -2.1277801692485809e-01
    z[2,1,2]  R741      -4.3242448568344116e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R674      -1
    z[2,1,3]  R675      1
    z[2,1,3]  R682      6.2967991828918457e-01
    z[2,1,3]  R683      4.2992448806762695e-01
    z[2,1,3]  R684      -3.1996479630470276e-01
    z[2,1,3]  R685      -6.8285381793975830e-01
    z[2,1,3]  R686      -4.3336641788482666e-01
    z[2,1,3]  R687      -3.1596380472183228e-01
    z[2,1,3]  R688      3.7232673168182373e-01
    z[2,1,3]  R689      4.9252521991729736e-01
    z[2,1,3]  R690      3.8690242171287537e-01
    z[2,1,3]  R691      9.1316811740398407e-02
    z[2,1,3]  R692      2.4188812077045441e-01
    z[2,1,3]  R693      2.2152094542980194e-01
    z[2,1,3]  R694      6.0156309604644775e-01
    z[2,1,3]  R695      8.1735335290431976e-02
    z[2,1,3]  R696      1.6186475753784180e-02
    z[2,1,3]  R697      3.8005319237709045e-01
    z[2,1,3]  R698      4.4550243020057678e-01
    z[2,1,3]  R699      3.5873657464981079e-01
    z[2,1,3]  R700      6.7233246564865112e-01
    z[2,1,3]  R701      4.4264367222785950e-01
    z[2,1,3]  R702      2.1618527173995972e-01
    z[2,1,3]  R703      -0.0953526645898819
    z[2,1,3]  R704      5.7371973991394043e-01
    z[2,1,3]  R705      4.2816025018692017e-01
    z[2,1,3]  R706      0.508263349533081
    z[2,1,3]  R707      6.0387039184570312e-01
    z[2,1,3]  R708      1.8024496734142303e-01
    z[2,1,3]  R709      3.6991345882415771e-01
    z[2,1,3]  R710      2.5764605402946472e-01
    z[2,1,3]  R711      8.3447188138961792e-02
    z[2,1,3]  R712      -7.2126221656799316e-01
    z[2,1,3]  R713      -3.7648153305053711e-01
    z[2,1,3]  R714      0.108011893928051
    z[2,1,3]  R715      1.1943751573562622e-01
    z[2,1,3]  R716      -1.5580879151821136e-01
    z[2,1,3]  R717      -3.8042029738426208e-01
    z[2,1,3]  R718      3.7178599834442139e-01
    z[2,1,3]  R719      1.7014692723751068e-01
    z[2,1,3]  R720      1.1572734266519547e-01
    z[2,1,3]  R721      4.5022162795066833e-01
    z[2,1,3]  R722      -2.4338285624980927e-01
    z[2,1,3]  R723      5.6788083165884018e-02
    z[2,1,3]  R724      8.5707187652587891e-02
    z[2,1,3]  R725      7.1806603670120239e-01
    z[2,1,3]  R726      0.564498245716095
    z[2,1,3]  R727      8.1387780606746674e-02
    z[2,1,3]  R728      -3.8180518895387650e-02
    z[2,1,3]  R729      -3.8070392608642578e-01
    z[2,1,3]  R730      -3.9326062798500061e-01
    z[2,1,3]  R731      3.1312260031700134e-01
    z[2,1,3]  R732      1.9833179190754890e-02
    z[2,1,3]  R733      -3.5487979650497437e-02
    z[2,1,3]  R734      -2.7073004841804504e-01
    z[2,1,3]  R735      -9.8129108548164368e-02
    z[2,1,3]  R736      1.0215727984905243e-01
    z[2,1,3]  R737      4.4515532255172729e-01
    z[2,1,3]  R738      4.6612039208412170e-01
    z[2,1,3]  R739      6.9420111179351807e-01
    z[2,1,3]  R740      7.0787101984024048e-01
    z[2,1,3]  R741      5.2529454231262207e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R676      -1
    z[2,1,4]  R677      1
    z[2,1,4]  R682      1.3164044916629791e-01
    z[2,1,4]  R683      2.1666148304939270e-01
    z[2,1,4]  R684      0.144708052277565
    z[2,1,4]  R685      4.3102821707725525e-01
    z[2,1,4]  R686      -7.0655143260955811e-01
    z[2,1,4]  R687      -1.3440373539924622e-01
    z[2,1,4]  R688      -4.0865597128868103e-01
    z[2,1,4]  R689      3.2016980648040771e-01
    z[2,1,4]  R690      -1.4649938791990280e-02
    z[2,1,4]  R691      1.4581990242004395e-01
    z[2,1,4]  R692      -1.7378675937652588e-01
    z[2,1,4]  R693      0.144618958234787
    z[2,1,4]  R694      -8.2724452018737793e-02
    z[2,1,4]  R695      2.6303216814994812e-01
    z[2,1,4]  R696      -1.1931933462619781e-01
    z[2,1,4]  R697      3.5996192693710327e-01
    z[2,1,4]  R698      9.8586179316043854e-02
    z[2,1,4]  R699      7.0899382233619690e-02
    z[2,1,4]  R700      0.139943465590477
    z[2,1,4]  R701      2.8142226859927177e-02
    z[2,1,4]  R702      -4.9839276075363159e-01
    z[2,1,4]  R703      2.7118235826492310e-01
    z[2,1,4]  R704      -1.1143181473016739e-02
    z[2,1,4]  R705      -2.5423717498779297e-01
    z[2,1,4]  R706      -3.1971356272697449e-01
    z[2,1,4]  R707      -1.6451187431812286e-01
    z[2,1,4]  R708      4.0888965129852295e-02
    z[2,1,4]  R709      -0.165586456656456
    z[2,1,4]  R710      3.2327935099601746e-01
    z[2,1,4]  R711      -2.5632831454277039e-01
    z[2,1,4]  R712      1.8563615158200264e-02
    z[2,1,4]  R713      4.8742804676294327e-02
    z[2,1,4]  R714      2.1600225567817688e-01
    z[2,1,4]  R715      -6.3330513238906860e-01
    z[2,1,4]  R716      -6.1474514007568359e-01
    z[2,1,4]  R717      6.2007820606231689e-01
    z[2,1,4]  R718      1.1409016698598862e-01
    z[2,1,4]  R719      2.7734309434890747e-01
    z[2,1,4]  R720      -2.7945801615715027e-01
    z[2,1,4]  R721      -1.0434918105602264e-01
    z[2,1,4]  R722      -0.00574418343603611
    z[2,1,4]  R723      -2.4857813119888306e-01
    z[2,1,4]  R724      -4.4940817356109619e-01
    z[2,1,4]  R725      -3.0068006366491318e-02
    z[2,1,4]  R726      1.5575060248374939e-01
    z[2,1,4]  R727      -2.9704365134239197e-01
    z[2,1,4]  R728      4.6199128031730652e-01
    z[2,1,4]  R729      5.6697374582290649e-01
    z[2,1,4]  R730      1.7257489264011383e-01
    z[2,1,4]  R731      3.1518572568893433e-01
    z[2,1,4]  R732      0.251932293176651
    z[2,1,4]  R733      -3.6011943221092224e-01
    z[2,1,4]  R734      4.5508152246475220e-01
    z[2,1,4]  R735      1.9532330334186554e-01
    z[2,1,4]  R736      1.0214227437973022e-01
    z[2,1,4]  R737      1.1158791929483414e-01
    z[2,1,4]  R738      3.6181509494781494e-01
    z[2,1,4]  R739      1.6459262371063232e-01
    z[2,1,4]  R740      6.1250500380992889e-02
    z[2,1,4]  R741      -0.228758305311203
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R678      -1
    z[2,1,5]  R679      1
    z[2,1,5]  R682      4.1973805427551270e-01
    z[2,1,5]  R683      4.1488382220268250e-01
    z[2,1,5]  R684      -4.5210793614387512e-01
    z[2,1,5]  R685      -1.6175678372383118e-01
    z[2,1,5]  R686      -2.9067766666412354e-01
    z[2,1,5]  R687      3.1963995099067688e-01
    z[2,1,5]  R688      4.1255286335945129e-01
    z[2,1,5]  R689      0.0674590989947319
    z[2,1,5]  R690      -3.3464255928993225e-01
    z[2,1,5]  R691      -9.9096536636352539e-02
    z[2,1,5]  R692      -6.7073583602905273e-01
    z[2,1,5]  R693      1.1968901753425598e-01
    z[2,1,5]  R694      2.2094377782195807e-03
    z[2,1,5]  R695      -2.8939110040664673e-01
    z[2,1,5]  R696      3.8329422473907471e-01
    z[2,1,5]  R697      9.4530224800109863e-02
    z[2,1,5]  R698      2.8302699327468872e-01
    z[2,1,5]  R699      1.8131180107593536e-01
    z[2,1,5]  R700      -3.8422411680221558e-01
    z[2,1,5]  R701      -2.2456111386418343e-02
    z[2,1,5]  R702      -1.0661100596189499e-01
    z[2,1,5]  R703      3.2412678003311157e-01
    z[2,1,5]  R704      2.5091582536697388e-01
    z[2,1,5]  R705      1.4982797205448151e-01
    z[2,1,5]  R706      0.229428231716156
    z[2,1,5]  R707      -0.286403626203537
    z[2,1,5]  R708      -2.8573716059327126e-02
    z[2,1,5]  R709      -2.8184045106172562e-02
    z[2,1,5]  R710      -2.0938961207866669e-01
    z[2,1,5]  R711      -8.0055460333824158e-02
    z[2,1,5]  R712      3.4723851829767227e-02
    z[2,1,5]  R713      -3.2207381725311279e-01
    z[2,1,5]  R714      -4.2285212874412537e-01
    z[2,1,5]  R715      -2.9673242568969727e-01
    z[2,1,5]  R716      -1.4082315564155579e-01
    z[2,1,5]  R717      -2.5233942270278931e-01
    z[2,1,5]  R718      8.2357627153396606e-01
    z[2,1,5]  R719      -5.0738650560379028e-01
    z[2,1,5]  R720      -2.7238273620605469e-01
    z[2,1,5]  R721      -2.3493853211402893e-01
    z[2,1,5]  R722      5.1415461301803589e-01
    z[2,1,5]  R723      1.5697108209133148e-01
    z[2,1,5]  R724      9.9229268729686737e-02
    z[2,1,5]  R725      5.0024546682834625e-02
    z[2,1,5]  R726      2.0019714534282684e-01
    z[2,1,5]  R727      4.6729168295860291e-01
    z[2,1,5]  R728      0.555384635925293
    z[2,1,5]  R729      2.6711070537567139e-01
    z[2,1,5]  R730      -3.8205191493034363e-02
    z[2,1,5]  R731      1.2230596691370010e-01
    z[2,1,5]  R732      9.9092327058315277e-02
    z[2,1,5]  R733      3.7132516503334045e-01
    z[2,1,5]  R734      2.4346999824047089e-01
    z[2,1,5]  R735      3.6300173401832581e-01
    z[2,1,5]  R736      3.1244638562202454e-01
    z[2,1,5]  R737      -1.0658074170351028e-01
    z[2,1,5]  R738      -1.8484708666801453e-01
    z[2,1,5]  R739      2.6160871982574463e-01
    z[2,1,5]  R740      4.0985457599163055e-02
    z[2,1,5]  R741      2.9875887557864189e-02
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R680      -1
    z[2,1,6]  R681      1
    z[2,1,6]  R682      -2.6838135719299316e-01
    z[2,1,6]  R683      4.5631670951843262e-01
    z[2,1,6]  R684      -5.4356628656387329e-01
    z[2,1,6]  R685      1.0432038456201553e-01
    z[2,1,6]  R686      -1.9684359431266785e-01
    z[2,1,6]  R687      3.0178797245025635e-01
    z[2,1,6]  R688      3.0108574777841568e-02
    z[2,1,6]  R689      -1.9585911929607391e-01
    z[2,1,6]  R690      -2.2083434462547302e-01
    z[2,1,6]  R691      2.7107185125350952e-01
    z[2,1,6]  R692      3.4475368261337280e-01
    z[2,1,6]  R693      -4.9483355879783630e-01
    z[2,1,6]  R694      2.5845885276794434e-01
    z[2,1,6]  R695      -3.2266917824745178e-01
    z[2,1,6]  R696      -1.7056754231452942e-01
    z[2,1,6]  R697      2.3213557898998260e-01
    z[2,1,6]  R698      0.352476567029953
    z[2,1,6]  R699      9.2968977987766266e-02
    z[2,1,6]  R700      0.0307808555662632
    z[2,1,6]  R701      -9.6563078463077545e-02
    z[2,1,6]  R702      5.5231606960296631e-01
    z[2,1,6]  R703      1.6284777224063873e-01
    z[2,1,6]  R704      1.7968676984310150e-02
    z[2,1,6]  R705      -2.3643250763416290e-01
    z[2,1,6]  R706      -1.2930619716644287e-01
    z[2,1,6]  R707      1.9165965914726257e-01
    z[2,1,6]  R708      3.9800401777029037e-02
    z[2,1,6]  R709      -2.1013411879539490e-01
    z[2,1,6]  R710      -1.3097006082534790e-01
    z[2,1,6]  R711      -8.3338119089603424e-02
    z[2,1,6]  R712      3.1601378321647644e-01
    z[2,1,6]  R713      -3.7417837977409363e-01
    z[2,1,6]  R714      2.8522792458534241e-01
    z[2,1,6]  R715      0.0919843465089798
    z[2,1,6]  R716      -3.7860912084579468e-01
    z[2,1,6]  R717      6.9010592997074127e-02
    z[2,1,6]  R718      7.2863809764385223e-02
    z[2,1,6]  R719      4.1865069419145584e-02
    z[2,1,6]  R720      -2.8414955735206604e-01
    z[2,1,6]  R721      -0.125092551112175
    z[2,1,6]  R722      2.0233482122421265e-02
    z[2,1,6]  R723      5.1945644617080688e-01
    z[2,1,6]  R724      1.3274191319942474e-01
    z[2,1,6]  R725      -2.6371926069259644e-01
    z[2,1,6]  R726      -5.7075989246368408e-01
    z[2,1,6]  R727      5.6197410821914673e-01
    z[2,1,6]  R728      -3.9840653538703918e-02
    z[2,1,6]  R729      -2.5980910658836365e-01
    z[2,1,6]  R730      4.7901767492294312e-01
    z[2,1,6]  R731      6.5745405852794647e-02
    z[2,1,6]  R732      -3.8314926624298096e-01
    z[2,1,6]  R733      1.3567297160625458e-01
    z[2,1,6]  R734      3.3263084292411804e-01
    z[2,1,6]  R735      -6.2555171549320221e-02
    z[2,1,6]  R736      3.6595532298088074e-01
    z[2,1,6]  R737      -1.3298501074314117e-01
    z[2,1,6]  R738      5.7471200823783875e-02
    z[2,1,6]  R739      -1.9934695959091187e-01
    z[2,1,6]  R740      -2.4804943799972534e-01
    z[2,1,6]  R741      2.4247968196868896e-01
    z[1,3,0]  R11       -1
    z[1,3,0]  R29       1
    z[1,3,0]  R742      -1
    z[1,3,0]  R743      1
    z[1,3,0]  R756      -5.2701896429061890e-01
    z[1,3,0]  R757      -6.6022956371307373e-01
    z[1,3,0]  R758      -3.9918488264083862e-01
    z[1,3,0]  R759      -6.3080924749374390e-01
    z[1,3,0]  R760      -3.8641642779111862e-02
    z[1,3,0]  R761      3.2748532295227051e-01
    z[1,3,0]  R762      -1.4281715452671051e-01
    z[1,3,0]  R763      2.8115930035710335e-02
    z[1,3,0]  R764      4.8787724971771240e-01
    z[1,3,0]  R765      5.6838440895080566e-01
    z[1,3,0]  R766      7.6037323474884033e-01
    z[1,3,0]  R767      7.3263001441955566e-01
    z[1,3,0]  R768      2.6938274502754211e-01
    z[1,3,0]  R769      3.2836100459098816e-01
    z[1,3,0]  R770      1.5567120909690857e-01
    z[1,3,0]  R771      -2.7634192258119583e-02
    z[1,3,0]  R772      4.6901926398277283e-01
    z[1,3,0]  R773      4.5823833346366882e-01
    z[1,3,0]  R774      4.7913977503776550e-01
    z[1,3,0]  R775      8.2334536314010620e-01
    z[1,3,0]  R776      4.3914899230003357e-01
    z[1,3,0]  R777      4.6952396631240845e-01
    z[1,3,0]  R778      2.1861717104911804e-01
    z[1,3,0]  R779      9.2060841619968414e-02
    z[1,3,0]  R780      7.0782944560050964e-02
    z[1,3,0]  R781      7.9928863048553467e-01
    z[1,3,0]  R782      7.1500462293624878e-01
    z[1,3,0]  R783      6.0705816745758057e-01
    z[1,3,0]  R784      6.2082648277282715e-01
    z[1,3,0]  R785      0.608687698841095
    z[1,3,0]  R786      -4.6925377845764160e-01
    z[1,3,0]  R787      -0.33150514960289
    z[1,3,0]  R788      -5.9620642662048340e-01
    z[1,3,0]  R789      -5.3413516283035278e-01
    z[1,3,0]  R790      -6.8876588344573975e-01
    z[1,3,0]  R791      -6.0696613788604736e-01
    z[1,3,0]  R792      -8.4953486919403076e-01
    z[1,3,0]  R793      -3.9942458271980286e-01
    z[1,3,0]  R794      9.1994702816009521e-01
    z[1,3,0]  R795      8.8811534643173218e-01
    z[1,3,0]  R796      -7.2577923536300659e-01
    z[1,3,0]  R797      -0.519461452960968
    z[1,3,0]  R798      4.1029435396194458e-01
    z[1,3,0]  R799      -1.9557641819119453e-02
    z[1,3,0]  R800      4.4595736265182495e-01
    z[1,3,0]  R801      6.6566020250320435e-02
    z[1,3,0]  R802      3.9135344326496124e-02
    z[1,3,0]  R803      3.4614410996437073e-01
    z[1,3,0]  R804      2.3814016953110695e-02
    z[1,3,0]  R805      7.9699587821960449e-01
    z[1,3,0]  R806      -6.4133369922637939e-01
    z[1,3,0]  R807      -5.4724627733230591e-01
    z[1,3,0]  R808      -0.620279848575592
    z[1,3,0]  R809      3.0767804384231567e-01
    z[1,3,0]  R810      3.8189122080802917e-01
    z[1,3,0]  R811      -9.4968140125274658e-02
    z[1,3,0]  R812      6.8948942422866821e-01
    z[1,3,0]  R813      -6.1649329960346222e-02
    z[1,3,0]  R814      4.1818743944168091e-01
    z[1,3,0]  R815      9.6550965309143066e-01
    z[1,3,0]  R816      -2.5130379199981689e-01
    z[1,3,0]  R817      2.6442989706993103e-01
    z[1,3,0]  R818      5.3732526302337646e-01
    z[1,3,0]  R819      -2.8376492857933044e-01
    z[1,3,0]  R820      9.0092593431472778e-01
    z[1,3,0]  R821      8.6789494752883911e-01
    z[1,3,0]  R822      8.5806202888488770e-01
    z[1,3,0]  R823      8.2225483655929565e-01
    z[1,3,0]  R824      0.821610689163208
    z[1,3,0]  R825      8.3646327257156372e-01
    z[1,3,1]  R12       -1
    z[1,3,1]  R30       1
    z[1,3,1]  R744      -1
    z[1,3,1]  R745      1
    z[1,3,1]  R756      -3.0860024690628052e-01
    z[1,3,1]  R757      -2.4361915886402130e-01
    z[1,3,1]  R758      -5.7640874385833740e-01
    z[1,3,1]  R759      -2.1130049228668213e-01
    z[1,3,1]  R760      -4.1637763381004333e-01
    z[1,3,1]  R761      -7.1816705167293549e-02
    z[1,3,1]  R762      -3.7463283538818359e-01
    z[1,3,1]  R763      7.9631936550140381e-01
    z[1,3,1]  R764      7.0636117458343506e-01
    z[1,3,1]  R765      6.2154012918472290e-01
    z[1,3,1]  R766      -2.7536764740943909e-01
    z[1,3,1]  R767      -3.1946226954460144e-01
    z[1,3,1]  R768      -3.0051156878471375e-01
    z[1,3,1]  R769      -4.9794375896453857e-01
    z[1,3,1]  R770      -4.8590126633644104e-01
    z[1,3,1]  R771      6.0431933403015137e-01
    z[1,3,1]  R772      0.425344854593277
    z[1,3,1]  R773      4.1581568121910095e-01
    z[1,3,1]  R774      5.9549266099929810e-01
    z[1,3,1]  R775      2.9417762160301208e-01
    z[1,3,1]  R776      -7.5883507728576660e-01
    z[1,3,1]  R777      6.8023461103439331e-01
    z[1,3,1]  R778      5.3482437133789062e-01
    z[1,3,1]  R779      5.6130027770996094e-01
    z[1,3,1]  R780      6.7508327960968018e-01
    z[1,3,1]  R781      2.8388798236846924e-01
    z[1,3,1]  R782      2.8720188140869141e-01
    z[1,3,1]  R783      1.7600784078240395e-02
    z[1,3,1]  R784      3.5477582365274429e-02
    z[1,3,1]  R785      2.3356939852237701e-01
    z[1,3,1]  R786      -3.1371474266052246e-01
    z[1,3,1]  R787      3.2901279628276825e-02
    z[1,3,1]  R788      1.6907972097396851e-01
    z[1,3,1]  R789      9.1157384216785431e-02
    z[1,3,1]  R790      -2.7442991733551025e-01
    z[1,3,1]  R791      4.0999788790941238e-02
    z[1,3,1]  R792      1.7802091315388680e-02
    z[1,3,1]  R793      -4.6836573630571365e-02
    z[1,3,1]  R794      -1.0292798280715942e-01
    z[1,3,1]  R795      -9.5199182629585266e-02
    z[1,3,1]  R796      1.2362776324152946e-02
    z[1,3,1]  R797      3.5043430328369141e-01
    z[1,3,1]  R798      6.5007501840591431e-01
    z[1,3,1]  R799      7.1344602108001709e-01
    z[1,3,1]  R800      0.801207423210144
    z[1,3,1]  R801      5.6806391477584839e-01
    z[1,3,1]  R802      5.5044001340866089e-01
    z[1,3,1]  R803      0.766588568687439
    z[1,3,1]  R804      7.7620851993560791e-01
    z[1,3,1]  R805      4.8600149154663086e-01
    z[1,3,1]  R806      0.492839515209198
    z[1,3,1]  R807      4.1238497942686081e-02
    z[1,3,1]  R808      1.3178735971450806e-01
    z[1,3,1]  R809      0.550700306892395
    z[1,3,1]  R810      5.7686352729797363e-01
    z[1,3,1]  R811      5.3804230690002441e-01
    z[1,3,1]  R812      5.2287822961807251e-01
    z[1,3,1]  R813      6.5635836124420166e-01
    z[1,3,1]  R814      4.2095881700515747e-01
    z[1,3,1]  R815      -1.2013946473598480e-01
    z[1,3,1]  R816      7.3735463619232178e-01
    z[1,3,1]  R817      6.0515117645263672e-01
    z[1,3,1]  R818      5.4157292842864990e-01
    z[1,3,1]  R819      4.7969511151313782e-01
    z[1,3,1]  R820      3.0161522328853607e-02
    z[1,3,1]  R821      -1.3235937058925629e-01
    z[1,3,1]  R822      4.7759800218045712e-03
    z[1,3,1]  R823      -1.7067900300025940e-01
    z[1,3,1]  R824      -2.6218351721763611e-01
    z[1,3,1]  R825      -1.3294726610183716e-01
    z[1,3,2]  R13       -1
    z[1,3,2]  R31       1
    z[1,3,2]  R746      -1
    z[1,3,2]  R747      1
    z[1,3,2]  R756      -7.3367103934288025e-02
    z[1,3,2]  R757      3.4189385175704956e-01
    z[1,3,2]  R758      -4.3580028414726257e-01
    z[1,3,2]  R759      -2.1349430084228516e-01
    z[1,3,2]  R760      -5.0967878103256226e-01
    z[1,3,2]  R761      0.538462221622467
    z[1,3,2]  R762      6.6521264612674713e-02
    z[1,3,2]  R763      -4.6898941509425640e-03
    z[1,3,2]  R764      1.2886713445186615e-01
    z[1,3,2]  R765      -0.078705795109272
    z[1,3,2]  R766      -1.4823172986507416e-01
    z[1,3,2]  R767      -4.1306626051664352e-02
    z[1,3,2]  R768      7.7481961250305176e-01
    z[1,3,2]  R769      2.3591910302639008e-01
    z[1,3,2]  R770      1.7579600214958191e-01
    z[1,3,2]  R771      -7.0705376565456390e-02
    z[1,3,2]  R772      -0.272341251373291
    z[1,3,2]  R773      -1.0895549505949020e-01
    z[1,3,2]  R774      2.1447060629725456e-02
    z[1,3,2]  R775      -0.137451633810997
    z[1,3,2]  R776      0.104074627161026
    z[1,3,2]  R777      1.7202684283256531e-01
    z[1,3,2]  R778      4.6460142731666565e-01
    z[1,3,2]  R779      7.0214158296585083e-01
    z[1,3,2]  R780      5.3557169437408447e-01
    z[1,3,2]  R781      -2.0220211148262024e-01
    z[1,3,2]  R782      -1.4364443719387054e-01
    z[1,3,2]  R783      -1.1826439946889877e-01
    z[1,3,2]  R784      -2.1277801692485809e-01
    z[1,3,2]  R785      -4.3242448568344116e-01
    z[1,3,2]  R786      7.7526587247848511e-01
    z[1,3,2]  R787      8.9516741037368774e-01
    z[1,3,2]  R788      3.5201448202133179e-01
    z[1,3,2]  R789      5.7556211948394775e-01
    z[1,3,2]  R790      2.4388627707958221e-01
    z[1,3,2]  R791      1.9422550499439240e-01
    z[1,3,2]  R792      2.5933519005775452e-01
    z[1,3,2]  R793      0.202837273478508
    z[1,3,2]  R794      3.2138973474502563e-01
    z[1,3,2]  R795      4.2020189762115479e-01
    z[1,3,2]  R796      -2.8708580136299133e-01
    z[1,3,2]  R797      -4.6171575784683228e-02
    z[1,3,2]  R798      -2.1103249490261078e-01
    z[1,3,2]  R799      4.2556360363960266e-02
    z[1,3,2]  R800      -3.3406227827072144e-02
    z[1,3,2]  R801      -0.0990736186504364
    z[1,3,2]  R802      1.3600957393646240e-01
    z[1,3,2]  R803      1.1976634850725532e-03
    z[1,3,2]  R804      0.0696486309170723
    z[1,3,2]  R805      3.0957534909248352e-01
    z[1,3,2]  R806      -1.2485025823116302e-01
    z[1,3,2]  R807      -1.3977298513054848e-02
    z[1,3,2]  R808      -0.208160862326622
    z[1,3,2]  R809      8.8788039982318878e-02
    z[1,3,2]  R810      -2.0874983072280884e-01
    z[1,3,2]  R811      -7.1404181420803070e-02
    z[1,3,2]  R812      -1.0149326175451279e-02
    z[1,3,2]  R813      -2.1710006892681122e-01
    z[1,3,2]  R814      3.2241743803024292e-01
    z[1,3,2]  R815      -5.0627548247575760e-02
    z[1,3,2]  R816      4.3066430091857910e-01
    z[1,3,2]  R817      5.7679611444473267e-01
    z[1,3,2]  R818      3.7671455740928650e-01
    z[1,3,2]  R819      -1.7360439896583557e-01
    z[1,3,2]  R820      1.0191214829683304e-01
    z[1,3,2]  R821      1.2821683287620544e-01
    z[1,3,2]  R822      -4.9768432974815369e-02
    z[1,3,2]  R823      7.4249237775802612e-02
    z[1,3,2]  R824      1.3735768198966980e-01
    z[1,3,2]  R825      -1.8188828229904175e-01
    z[1,3,3]  R14       -1
    z[1,3,3]  R32       1
    z[1,3,3]  R748      -1
    z[1,3,3]  R749      1
    z[1,3,3]  R756      -7.2126221656799316e-01
    z[1,3,3]  R757      -3.7648153305053711e-01
    z[1,3,3]  R758      0.108011893928051
    z[1,3,3]  R759      1.1943751573562622e-01
    z[1,3,3]  R760      -1.5580879151821136e-01
    z[1,3,3]  R761      -3.8042029738426208e-01
    z[1,3,3]  R762      3.7178599834442139e-01
    z[1,3,3]  R763      1.7014692723751068e-01
    z[1,3,3]  R764      1.1572734266519547e-01
    z[1,3,3]  R765      4.5022162795066833e-01
    z[1,3,3]  R766      -2.4338285624980927e-01
    z[1,3,3]  R767      5.6788083165884018e-02
    z[1,3,3]  R768      8.5707187652587891e-02
    z[1,3,3]  R769      7.1806603670120239e-01
    z[1,3,3]  R770      0.564498245716095
    z[1,3,3]  R771      8.1387780606746674e-02
    z[1,3,3]  R772      -3.8180518895387650e-02
    z[1,3,3]  R773      -3.8070392608642578e-01
    z[1,3,3]  R774      -3.9326062798500061e-01
    z[1,3,3]  R775      3.1312260031700134e-01
    z[1,3,3]  R776      1.9833179190754890e-02
    z[1,3,3]  R777      -3.5487979650497437e-02
    z[1,3,3]  R778      -2.7073004841804504e-01
    z[1,3,3]  R779      -9.8129108548164368e-02
    z[1,3,3]  R780      1.0215727984905243e-01
    z[1,3,3]  R781      4.4515532255172729e-01
    z[1,3,3]  R782      4.6612039208412170e-01
    z[1,3,3]  R783      6.9420111179351807e-01
    z[1,3,3]  R784      7.0787101984024048e-01
    z[1,3,3]  R785      5.2529454231262207e-01
    z[1,3,3]  R786      0.07901581376791
    z[1,3,3]  R787      0.14643594622612
    z[1,3,3]  R788      1.8404580652713776e-01
    z[1,3,3]  R789      -4.8148915171623230e-01
    z[1,3,3]  R790      -2.5568547844886780e-01
    z[1,3,3]  R791      1.2257728725671768e-01
    z[1,3,3]  R792      -2.2818391025066376e-01
    z[1,3,3]  R793      -3.1830493360757828e-02
    z[1,3,3]  R794      8.9937351644039154e-02
    z[1,3,3]  R795      -1.0073759406805038e-01
    z[1,3,3]  R796      1.3321955502033234e-01
    z[1,3,3]  R797      6.0039076954126358e-02
    z[1,3,3]  R798      -9.3716740608215332e-02
    z[1,3,3]  R799      4.2428936809301376e-02
    z[1,3,3]  R800      -3.1878617405891418e-01
    z[1,3,3]  R801      -6.2994378805160522e-01
    z[1,3,3]  R802      9.8014205694198608e-02
    z[1,3,3]  R803      -1.7204432189464569e-01
    z[1,3,3]  R804      -1.6432275995612144e-02
    z[1,3,3]  R805      5.1976222544908524e-02
    z[1,3,3]  R806      -1.6308794915676117e-01
    z[1,3,3]  R807      2.9764357209205627e-01
    z[1,3,3]  R808      -5.3639984130859375e-01
    z[1,3,3]  R809      -1.9266603887081146e-01
    z[1,3,3]  R810      0.067952461540699
    z[1,3,3]  R811      -1.9458861649036407e-01
    z[1,3,3]  R812      3.9981618523597717e-01
    z[1,3,3]  R813      -5.7392424345016479e-01
    z[1,3,3]  R814      1.0243978351354599e-01
    z[1,3,3]  R815      -1.8930040299892426e-02
    z[1,3,3]  R816      -3.2287371158599854e-01
    z[1,3,3]  R817      -1.6707479953765869e-01
    z[1,3,3]  R818      2.4766427278518677e-01
    z[1,3,3]  R819      7.4058908224105835e-01
    z[1,3,3]  R820      -2.1980394423007965e-01
    z[1,3,3]  R821      1.7972676083445549e-02
    z[1,3,3]  R822      -2.1149446070194244e-01
    z[1,3,3]  R823      -6.3981473445892334e-02
    z[1,3,3]  R824      1.6020385921001434e-01
    z[1,3,3]  R825      -4.2409861087799072e-01
    z[1,3,4]  R15       -1
    z[1,3,4]  R33       1
    z[1,3,4]  R750      -1
    z[1,3,4]  R751      1
    z[1,3,4]  R756      1.8563615158200264e-02
    z[1,3,4]  R757      4.8742804676294327e-02
    z[1,3,4]  R758      2.1600225567817688e-01
    z[1,3,4]  R759      -6.3330513238906860e-01
    z[1,3,4]  R760      -6.1474514007568359e-01
    z[1,3,4]  R761      6.2007820606231689e-01
    z[1,3,4]  R762      1.1409016698598862e-01
    z[1,3,4]  R763      2.7734309434890747e-01
    z[1,3,4]  R764      -2.7945801615715027e-01
    z[1,3,4]  R765      -1.0434918105602264e-01
    z[1,3,4]  R766      -0.00574418343603611
    z[1,3,4]  R767      -2.4857813119888306e-01
    z[1,3,4]  R768      -4.4940817356109619e-01
    z[1,3,4]  R769      -3.0068006366491318e-02
    z[1,3,4]  R770      1.5575060248374939e-01
    z[1,3,4]  R771      -2.9704365134239197e-01
    z[1,3,4]  R772      4.6199128031730652e-01
    z[1,3,4]  R773      5.6697374582290649e-01
    z[1,3,4]  R774      1.7257489264011383e-01
    z[1,3,4]  R775      3.1518572568893433e-01
    z[1,3,4]  R776      0.251932293176651
    z[1,3,4]  R777      -3.6011943221092224e-01
    z[1,3,4]  R778      4.5508152246475220e-01
    z[1,3,4]  R779      1.9532330334186554e-01
    z[1,3,4]  R780      1.0214227437973022e-01
    z[1,3,4]  R781      1.1158791929483414e-01
    z[1,3,4]  R782      3.6181509494781494e-01
    z[1,3,4]  R783      1.6459262371063232e-01
    z[1,3,4]  R784      6.1250500380992889e-02
    z[1,3,4]  R785      -0.228758305311203
    z[1,3,4]  R786      -1.5118260681629181e-01
    z[1,3,4]  R787      -1.2110810726881027e-01
    z[1,3,4]  R788      3.0696511268615723e-01
    z[1,3,4]  R789      9.3824982643127441e-02
    z[1,3,4]  R790      5.6252223253250122e-01
    z[1,3,4]  R791      4.5384871959686279e-01
    z[1,3,4]  R792      3.0659487843513489e-01
    z[1,3,4]  R793      -2.3273593187332153e-01
    z[1,3,4]  R794      -1.6773466765880585e-01
    z[1,3,4]  R795      -1.9281828776001930e-02
    z[1,3,4]  R796      -3.8209676742553711e-01
    z[1,3,4]  R797      -6.9468045234680176e-01
    z[1,3,4]  R798      -1.7974703013896942e-01
    z[1,3,4]  R799      -2.7379241585731506e-01
    z[1,3,4]  R800      -6.6507525742053986e-02
    z[1,3,4]  R801      2.2297158837318420e-01
    z[1,3,4]  R802      -2.7357056736946106e-01
    z[1,3,4]  R803      2.1131275594234467e-01
    z[1,3,4]  R804      -2.1221134066581726e-01
    z[1,3,4]  R805      3.5109922289848328e-02
    z[1,3,4]  R806      -0.242910698056221
    z[1,3,4]  R807      -6.4958351850509644e-01
    z[1,3,4]  R808      -8.3872549235820770e-02
    z[1,3,4]  R809      2.5922521948814392e-01
    z[1,3,4]  R810      5.6454139947891235e-01
    z[1,3,4]  R811      7.3291277885437012e-01
    z[1,3,4]  R812      1.1814720183610916e-01
    z[1,3,4]  R813      2.6722148060798645e-01
    z[1,3,4]  R814      3.0719587206840515e-01
    z[1,3,4]  R815      -5.8366615325212479e-02
    z[1,3,4]  R816      -2.9494842886924744e-01
    z[1,3,4]  R817      -1.6150401532649994e-01
    z[1,3,4]  R818      -1.4807645976543427e-01
    z[1,3,4]  R819      1.3833388686180115e-01
    z[1,3,4]  R820      -1.4137434959411621e-01
    z[1,3,4]  R821      8.2156389951705933e-02
    z[1,3,4]  R822      2.8801393508911133e-01
    z[1,3,4]  R823      4.7589689493179321e-01
    z[1,3,4]  R824      3.6816483736038208e-01
    z[1,3,4]  R825      1.2181729823350906e-01
    z[1,3,5]  R16       -1
    z[1,3,5]  R34       1
    z[1,3,5]  R752      -1
    z[1,3,5]  R753      1
    z[1,3,5]  R756      3.4723851829767227e-02
    z[1,3,5]  R757      -3.2207381725311279e-01
    z[1,3,5]  R758      -4.2285212874412537e-01
    z[1,3,5]  R759      -2.9673242568969727e-01
    z[1,3,5]  R760      -1.4082315564155579e-01
    z[1,3,5]  R761      -2.5233942270278931e-01
    z[1,3,5]  R762      8.2357627153396606e-01
    z[1,3,5]  R763      -5.0738650560379028e-01
    z[1,3,5]  R764      -2.7238273620605469e-01
    z[1,3,5]  R765      -2.3493853211402893e-01
    z[1,3,5]  R766      5.1415461301803589e-01
    z[1,3,5]  R767      1.5697108209133148e-01
    z[1,3,5]  R768      9.9229268729686737e-02
    z[1,3,5]  R769      5.0024546682834625e-02
    z[1,3,5]  R770      2.0019714534282684e-01
    z[1,3,5]  R771      4.6729168295860291e-01
    z[1,3,5]  R772      0.555384635925293
    z[1,3,5]  R773      2.6711070537567139e-01
    z[1,3,5]  R774      -3.8205191493034363e-02
    z[1,3,5]  R775      1.2230596691370010e-01
    z[1,3,5]  R776      9.9092327058315277e-02
    z[1,3,5]  R777      3.7132516503334045e-01
    z[1,3,5]  R778      2.4346999824047089e-01
    z[1,3,5]  R779      3.6300173401832581e-01
    z[1,3,5]  R780      3.1244638562202454e-01
    z[1,3,5]  R781      -1.0658074170351028e-01
    z[1,3,5]  R782      -1.8484708666801453e-01
    z[1,3,5]  R783      2.6160871982574463e-01
    z[1,3,5]  R784      4.0985457599163055e-02
    z[1,3,5]  R785      2.9875887557864189e-02
    z[1,3,5]  R786      1.4710752665996552e-01
    z[1,3,5]  R787      5.5916242301464081e-02
    z[1,3,5]  R788      -4.3696433305740356e-01
    z[1,3,5]  R789      1.7973285913467407e-01
    z[1,3,5]  R790      5.2761003375053406e-02
    z[1,3,5]  R791      -4.1906601190567017e-01
    z[1,3,5]  R792      -2.1328464150428772e-01
    z[1,3,5]  R793      -3.1065386533737183e-01
    z[1,3,5]  R794      -3.6468520760536194e-02
    z[1,3,5]  R795      2.5497859343886375e-02
    z[1,3,5]  R796      4.7373014688491821e-01
    z[1,3,5]  R797      3.4413686394691467e-01
    z[1,3,5]  R798      1.0588242113590240e-01
    z[1,3,5]  R799      -5.6741183996200562e-01
    z[1,3,5]  R800      -1.9991537928581238e-01
    z[1,3,5]  R801      4.0387919545173645e-01
    z[1,3,5]  R802      4.9634307622909546e-01
    z[1,3,5]  R803      -3.8713118433952332e-01
    z[1,3,5]  R804      6.3142009079456329e-02
    z[1,3,5]  R805      -3.2969031017273664e-03
    z[1,3,5]  R806      3.0698272585868835e-01
    z[1,3,5]  R807      -1.0310070216655731e-01
    z[1,3,5]  R808      4.5047125220298767e-01
    z[1,3,5]  R809      6.7605400085449219e-01
    z[1,3,5]  R810      1.3374383747577667e-01
    z[1,3,5]  R811      3.3290737867355347e-01
    z[1,3,5]  R812      -0.0471990704536438
    z[1,3,5]  R813      -2.4472513794898987e-01
    z[1,3,5]  R814      -2.2847951948642731e-01
    z[1,3,5]  R815      1.9362162053585052e-01
    z[1,3,5]  R816      1.2813235819339752e-01
    z[1,3,5]  R817      -2.9364410042762756e-01
    z[1,3,5]  R818      3.1093168258666992e-01
    z[1,3,5]  R819      2.8522640466690063e-01
    z[1,3,5]  R820      -2.9728201031684875e-01
    z[1,3,5]  R821      -3.9887115359306335e-01
    z[1,3,5]  R822      -1.6919489204883575e-01
    z[1,3,5]  R823      -2.6922725141048431e-02
    z[1,3,5]  R824      -1.3203187286853790e-01
    z[1,3,5]  R825      -1.9959259033203125e-01
    z[1,3,6]  R17       -1
    z[1,3,6]  R35       1
    z[1,3,6]  R754      -1
    z[1,3,6]  R755      1
    z[1,3,6]  R756      3.1601378321647644e-01
    z[1,3,6]  R757      -3.7417837977409363e-01
    z[1,3,6]  R758      2.8522792458534241e-01
    z[1,3,6]  R759      0.0919843465089798
    z[1,3,6]  R760      -3.7860912084579468e-01
    z[1,3,6]  R761      6.9010592997074127e-02
    z[1,3,6]  R762      7.2863809764385223e-02
    z[1,3,6]  R763      4.1865069419145584e-02
    z[1,3,6]  R764      -2.8414955735206604e-01
    z[1,3,6]  R765      -0.125092551112175
    z[1,3,6]  R766      2.0233482122421265e-02
    z[1,3,6]  R767      5.1945644617080688e-01
    z[1,3,6]  R768      1.3274191319942474e-01
    z[1,3,6]  R769      -2.6371926069259644e-01
    z[1,3,6]  R770      -5.7075989246368408e-01
    z[1,3,6]  R771      5.6197410821914673e-01
    z[1,3,6]  R772      -3.9840653538703918e-02
    z[1,3,6]  R773      -2.5980910658836365e-01
    z[1,3,6]  R774      4.7901767492294312e-01
    z[1,3,6]  R775      6.5745405852794647e-02
    z[1,3,6]  R776      -3.8314926624298096e-01
    z[1,3,6]  R777      1.3567297160625458e-01
    z[1,3,6]  R778      3.3263084292411804e-01
    z[1,3,6]  R779      -6.2555171549320221e-02
    z[1,3,6]  R780      3.6595532298088074e-01
    z[1,3,6]  R781      -1.3298501074314117e-01
    z[1,3,6]  R782      5.7471200823783875e-02
    z[1,3,6]  R783      -1.9934695959091187e-01
    z[1,3,6]  R784      -2.4804943799972534e-01
    z[1,3,6]  R785      2.4247968196868896e-01
    z[1,3,6]  R786      1.7206548154354095e-01
    z[1,3,6]  R787      -2.2013604640960693e-01
    z[1,3,6]  R788      -4.1592967510223389e-01
    z[1,3,6]  R789      3.1965491175651550e-01
    z[1,3,6]  R790      -7.8862540423870087e-02
    z[1,3,6]  R791      4.4223007559776306e-01
    z[1,3,6]  R792      1.3842076063156128e-01
    z[1,3,6]  R793      8.0339181423187256e-01
    z[1,3,6]  R794      -4.7521837055683136e-02
    z[1,3,6]  R795      1.2020229548215866e-01
    z[1,3,6]  R796      -5.0076227635145187e-02
    z[1,3,6]  R797      -2.4653879925608635e-02
    z[1,3,6]  R798      5.5876958370208740e-01
    z[1,3,6]  R799      3.0013734102249146e-01
    z[1,3,6]  R800      1.0981138795614243e-01
    z[1,3,6]  R801      -2.3106880486011505e-01
    z[1,3,6]  R802      -5.8837193250656128e-01
    z[1,3,6]  R803      -2.6153776049613953e-01
    z[1,3,6]  R804      -5.8548414707183838e-01
    z[1,3,6]  R805      -1.6975912451744080e-01
    z[1,3,6]  R806      -3.8777709007263184e-01
    z[1,3,6]  R807      4.2124241590499878e-01
    z[1,3,6]  R808      2.3847469687461853e-01
    z[1,3,6]  R809      1.8114395439624786e-01
    z[1,3,6]  R810      3.6959323287010193e-01
    z[1,3,6]  R811      -1.0266353935003281e-01
    z[1,3,6]  R812      -2.7397081255912781e-01
    z[1,3,6]  R813      2.3994588851928711e-01
    z[1,3,6]  R814      6.2200784683227539e-01
    z[1,3,6]  R815      9.7674198448657990e-02
    z[1,3,6]  R816      -4.7831791453063488e-03
    z[1,3,6]  R817      3.0158025026321411e-01
    z[1,3,6]  R818      3.1003820896148682e-01
    z[1,3,6]  R819      1.0133621096611023e-01
    z[1,3,6]  R820      1.4268645644187927e-01
    z[1,3,6]  R821      2.1593706309795380e-01
    z[1,3,6]  R822      -3.2391491532325745e-01
    z[1,3,6]  R823      -2.4074141681194305e-01
    z[1,3,6]  R824      -2.4229244887828827e-01
    z[1,3,6]  R825      1.2261576205492020e-01
    z[3,1,0]  R11       1
    z[3,1,0]  R29       -1
    z[3,1,0]  R826      -1
    z[3,1,0]  R827      1
    z[3,1,0]  R840      -4.6925377845764160e-01
    z[3,1,0]  R841      -0.33150514960289
    z[3,1,0]  R842      -5.9620642662048340e-01
    z[3,1,0]  R843      -5.3413516283035278e-01
    z[3,1,0]  R844      -6.8876588344573975e-01
    z[3,1,0]  R845      -6.0696613788604736e-01
    z[3,1,0]  R846      -8.4953486919403076e-01
    z[3,1,0]  R847      -3.9942458271980286e-01
    z[3,1,0]  R848      9.1994702816009521e-01
    z[3,1,0]  R849      8.8811534643173218e-01
    z[3,1,0]  R850      -7.2577923536300659e-01
    z[3,1,0]  R851      -0.519461452960968
    z[3,1,0]  R852      4.1029435396194458e-01
    z[3,1,0]  R853      -1.9557641819119453e-02
    z[3,1,0]  R854      4.4595736265182495e-01
    z[3,1,0]  R855      6.6566020250320435e-02
    z[3,1,0]  R856      3.9135344326496124e-02
    z[3,1,0]  R857      3.4614410996437073e-01
    z[3,1,0]  R858      2.3814016953110695e-02
    z[3,1,0]  R859      7.9699587821960449e-01
    z[3,1,0]  R860      -6.4133369922637939e-01
    z[3,1,0]  R861      -5.4724627733230591e-01
    z[3,1,0]  R862      -0.620279848575592
    z[3,1,0]  R863      3.0767804384231567e-01
    z[3,1,0]  R864      3.8189122080802917e-01
    z[3,1,0]  R865      -9.4968140125274658e-02
    z[3,1,0]  R866      6.8948942422866821e-01
    z[3,1,0]  R867      -6.1649329960346222e-02
    z[3,1,0]  R868      4.1818743944168091e-01
    z[3,1,0]  R869      9.6550965309143066e-01
    z[3,1,0]  R870      -2.5130379199981689e-01
    z[3,1,0]  R871      2.6442989706993103e-01
    z[3,1,0]  R872      5.3732526302337646e-01
    z[3,1,0]  R873      -2.8376492857933044e-01
    z[3,1,0]  R874      9.0092593431472778e-01
    z[3,1,0]  R875      8.6789494752883911e-01
    z[3,1,0]  R876      8.5806202888488770e-01
    z[3,1,0]  R877      8.2225483655929565e-01
    z[3,1,0]  R878      0.821610689163208
    z[3,1,0]  R879      8.3646327257156372e-01
    z[3,1,0]  R880      -5.2701896429061890e-01
    z[3,1,0]  R881      -6.6022956371307373e-01
    z[3,1,0]  R882      -3.9918488264083862e-01
    z[3,1,0]  R883      -6.3080924749374390e-01
    z[3,1,0]  R884      -3.8641642779111862e-02
    z[3,1,0]  R885      3.2748532295227051e-01
    z[3,1,0]  R886      -1.4281715452671051e-01
    z[3,1,0]  R887      2.8115930035710335e-02
    z[3,1,0]  R888      4.8787724971771240e-01
    z[3,1,0]  R889      5.6838440895080566e-01
    z[3,1,0]  R890      7.6037323474884033e-01
    z[3,1,0]  R891      7.3263001441955566e-01
    z[3,1,0]  R892      2.6938274502754211e-01
    z[3,1,0]  R893      3.2836100459098816e-01
    z[3,1,0]  R894      1.5567120909690857e-01
    z[3,1,0]  R895      -2.7634192258119583e-02
    z[3,1,0]  R896      4.6901926398277283e-01
    z[3,1,0]  R897      4.5823833346366882e-01
    z[3,1,0]  R898      4.7913977503776550e-01
    z[3,1,0]  R899      8.2334536314010620e-01
    z[3,1,0]  R900      4.3914899230003357e-01
    z[3,1,0]  R901      4.6952396631240845e-01
    z[3,1,0]  R902      2.1861717104911804e-01
    z[3,1,0]  R903      9.2060841619968414e-02
    z[3,1,0]  R904      7.0782944560050964e-02
    z[3,1,0]  R905      7.9928863048553467e-01
    z[3,1,0]  R906      7.1500462293624878e-01
    z[3,1,0]  R907      6.0705816745758057e-01
    z[3,1,0]  R908      6.2082648277282715e-01
    z[3,1,0]  R909      0.608687698841095
    z[3,1,1]  R12       1
    z[3,1,1]  R30       -1
    z[3,1,1]  R828      -1
    z[3,1,1]  R829      1
    z[3,1,1]  R840      -3.1371474266052246e-01
    z[3,1,1]  R841      3.2901279628276825e-02
    z[3,1,1]  R842      1.6907972097396851e-01
    z[3,1,1]  R843      9.1157384216785431e-02
    z[3,1,1]  R844      -2.7442991733551025e-01
    z[3,1,1]  R845      4.0999788790941238e-02
    z[3,1,1]  R846      1.7802091315388680e-02
    z[3,1,1]  R847      -4.6836573630571365e-02
    z[3,1,1]  R848      -1.0292798280715942e-01
    z[3,1,1]  R849      -9.5199182629585266e-02
    z[3,1,1]  R850      1.2362776324152946e-02
    z[3,1,1]  R851      3.5043430328369141e-01
    z[3,1,1]  R852      6.5007501840591431e-01
    z[3,1,1]  R853      7.1344602108001709e-01
    z[3,1,1]  R854      0.801207423210144
    z[3,1,1]  R855      5.6806391477584839e-01
    z[3,1,1]  R856      5.5044001340866089e-01
    z[3,1,1]  R857      0.766588568687439
    z[3,1,1]  R858      7.7620851993560791e-01
    z[3,1,1]  R859      4.8600149154663086e-01
    z[3,1,1]  R860      0.492839515209198
    z[3,1,1]  R861      4.1238497942686081e-02
    z[3,1,1]  R862      1.3178735971450806e-01
    z[3,1,1]  R863      0.550700306892395
    z[3,1,1]  R864      5.7686352729797363e-01
    z[3,1,1]  R865      5.3804230690002441e-01
    z[3,1,1]  R866      5.2287822961807251e-01
    z[3,1,1]  R867      6.5635836124420166e-01
    z[3,1,1]  R868      4.2095881700515747e-01
    z[3,1,1]  R869      -1.2013946473598480e-01
    z[3,1,1]  R870      7.3735463619232178e-01
    z[3,1,1]  R871      6.0515117645263672e-01
    z[3,1,1]  R872      5.4157292842864990e-01
    z[3,1,1]  R873      4.7969511151313782e-01
    z[3,1,1]  R874      3.0161522328853607e-02
    z[3,1,1]  R875      -1.3235937058925629e-01
    z[3,1,1]  R876      4.7759800218045712e-03
    z[3,1,1]  R877      -1.7067900300025940e-01
    z[3,1,1]  R878      -2.6218351721763611e-01
    z[3,1,1]  R879      -1.3294726610183716e-01
    z[3,1,1]  R880      -3.0860024690628052e-01
    z[3,1,1]  R881      -2.4361915886402130e-01
    z[3,1,1]  R882      -5.7640874385833740e-01
    z[3,1,1]  R883      -2.1130049228668213e-01
    z[3,1,1]  R884      -4.1637763381004333e-01
    z[3,1,1]  R885      -7.1816705167293549e-02
    z[3,1,1]  R886      -3.7463283538818359e-01
    z[3,1,1]  R887      7.9631936550140381e-01
    z[3,1,1]  R888      7.0636117458343506e-01
    z[3,1,1]  R889      6.2154012918472290e-01
    z[3,1,1]  R890      -2.7536764740943909e-01
    z[3,1,1]  R891      -3.1946226954460144e-01
    z[3,1,1]  R892      -3.0051156878471375e-01
    z[3,1,1]  R893      -4.9794375896453857e-01
    z[3,1,1]  R894      -4.8590126633644104e-01
    z[3,1,1]  R895      6.0431933403015137e-01
    z[3,1,1]  R896      0.425344854593277
    z[3,1,1]  R897      4.1581568121910095e-01
    z[3,1,1]  R898      5.9549266099929810e-01
    z[3,1,1]  R899      2.9417762160301208e-01
    z[3,1,1]  R900      -7.5883507728576660e-01
    z[3,1,1]  R901      6.8023461103439331e-01
    z[3,1,1]  R902      5.3482437133789062e-01
    z[3,1,1]  R903      5.6130027770996094e-01
    z[3,1,1]  R904      6.7508327960968018e-01
    z[3,1,1]  R905      2.8388798236846924e-01
    z[3,1,1]  R906      2.8720188140869141e-01
    z[3,1,1]  R907      1.7600784078240395e-02
    z[3,1,1]  R908      3.5477582365274429e-02
    z[3,1,1]  R909      2.3356939852237701e-01
    z[3,1,2]  R13       1
    z[3,1,2]  R31       -1
    z[3,1,2]  R830      -1
    z[3,1,2]  R831      1
    z[3,1,2]  R840      7.7526587247848511e-01
    z[3,1,2]  R841      8.9516741037368774e-01
    z[3,1,2]  R842      3.5201448202133179e-01
    z[3,1,2]  R843      5.7556211948394775e-01
    z[3,1,2]  R844      2.4388627707958221e-01
    z[3,1,2]  R845      1.9422550499439240e-01
    z[3,1,2]  R846      2.5933519005775452e-01
    z[3,1,2]  R847      0.202837273478508
    z[3,1,2]  R848      3.2138973474502563e-01
    z[3,1,2]  R849      4.2020189762115479e-01
    z[3,1,2]  R850      -2.8708580136299133e-01
    z[3,1,2]  R851      -4.6171575784683228e-02
    z[3,1,2]  R852      -2.1103249490261078e-01
    z[3,1,2]  R853      4.2556360363960266e-02
    z[3,1,2]  R854      -3.3406227827072144e-02
    z[3,1,2]  R855      -0.0990736186504364
    z[3,1,2]  R856      1.3600957393646240e-01
    z[3,1,2]  R857      1.1976634850725532e-03
    z[3,1,2]  R858      0.0696486309170723
    z[3,1,2]  R859      3.0957534909248352e-01
    z[3,1,2]  R860      -1.2485025823116302e-01
    z[3,1,2]  R861      -1.3977298513054848e-02
    z[3,1,2]  R862      -0.208160862326622
    z[3,1,2]  R863      8.8788039982318878e-02
    z[3,1,2]  R864      -2.0874983072280884e-01
    z[3,1,2]  R865      -7.1404181420803070e-02
    z[3,1,2]  R866      -1.0149326175451279e-02
    z[3,1,2]  R867      -2.1710006892681122e-01
    z[3,1,2]  R868      3.2241743803024292e-01
    z[3,1,2]  R869      -5.0627548247575760e-02
    z[3,1,2]  R870      4.3066430091857910e-01
    z[3,1,2]  R871      5.7679611444473267e-01
    z[3,1,2]  R872      3.7671455740928650e-01
    z[3,1,2]  R873      -1.7360439896583557e-01
    z[3,1,2]  R874      1.0191214829683304e-01
    z[3,1,2]  R875      1.2821683287620544e-01
    z[3,1,2]  R876      -4.9768432974815369e-02
    z[3,1,2]  R877      7.4249237775802612e-02
    z[3,1,2]  R878      1.3735768198966980e-01
    z[3,1,2]  R879      -1.8188828229904175e-01
    z[3,1,2]  R880      -7.3367103934288025e-02
    z[3,1,2]  R881      3.4189385175704956e-01
    z[3,1,2]  R882      -4.3580028414726257e-01
    z[3,1,2]  R883      -2.1349430084228516e-01
    z[3,1,2]  R884      -5.0967878103256226e-01
    z[3,1,2]  R885      0.538462221622467
    z[3,1,2]  R886      6.6521264612674713e-02
    z[3,1,2]  R887      -4.6898941509425640e-03
    z[3,1,2]  R888      1.2886713445186615e-01
    z[3,1,2]  R889      -0.078705795109272
    z[3,1,2]  R890      -1.4823172986507416e-01
    z[3,1,2]  R891      -4.1306626051664352e-02
    z[3,1,2]  R892      7.7481961250305176e-01
    z[3,1,2]  R893      2.3591910302639008e-01
    z[3,1,2]  R894      1.7579600214958191e-01
    z[3,1,2]  R895      -7.0705376565456390e-02
    z[3,1,2]  R896      -0.272341251373291
    z[3,1,2]  R897      -1.0895549505949020e-01
    z[3,1,2]  R898      2.1447060629725456e-02
    z[3,1,2]  R899      -0.137451633810997
    z[3,1,2]  R900      0.104074627161026
    z[3,1,2]  R901      1.7202684283256531e-01
    z[3,1,2]  R902      4.6460142731666565e-01
    z[3,1,2]  R903      7.0214158296585083e-01
    z[3,1,2]  R904      5.3557169437408447e-01
    z[3,1,2]  R905      -2.0220211148262024e-01
    z[3,1,2]  R906      -1.4364443719387054e-01
    z[3,1,2]  R907      -1.1826439946889877e-01
    z[3,1,2]  R908      -2.1277801692485809e-01
    z[3,1,2]  R909      -4.3242448568344116e-01
    z[3,1,3]  R14       1
    z[3,1,3]  R32       -1
    z[3,1,3]  R832      -1
    z[3,1,3]  R833      1
    z[3,1,3]  R840      0.07901581376791
    z[3,1,3]  R841      0.14643594622612
    z[3,1,3]  R842      1.8404580652713776e-01
    z[3,1,3]  R843      -4.8148915171623230e-01
    z[3,1,3]  R844      -2.5568547844886780e-01
    z[3,1,3]  R845      1.2257728725671768e-01
    z[3,1,3]  R846      -2.2818391025066376e-01
    z[3,1,3]  R847      -3.1830493360757828e-02
    z[3,1,3]  R848      8.9937351644039154e-02
    z[3,1,3]  R849      -1.0073759406805038e-01
    z[3,1,3]  R850      1.3321955502033234e-01
    z[3,1,3]  R851      6.0039076954126358e-02
    z[3,1,3]  R852      -9.3716740608215332e-02
    z[3,1,3]  R853      4.2428936809301376e-02
    z[3,1,3]  R854      -3.1878617405891418e-01
    z[3,1,3]  R855      -6.2994378805160522e-01
    z[3,1,3]  R856      9.8014205694198608e-02
    z[3,1,3]  R857      -1.7204432189464569e-01
    z[3,1,3]  R858      -1.6432275995612144e-02
    z[3,1,3]  R859      5.1976222544908524e-02
    z[3,1,3]  R860      -1.6308794915676117e-01
    z[3,1,3]  R861      2.9764357209205627e-01
    z[3,1,3]  R862      -5.3639984130859375e-01
    z[3,1,3]  R863      -1.9266603887081146e-01
    z[3,1,3]  R864      0.067952461540699
    z[3,1,3]  R865      -1.9458861649036407e-01
    z[3,1,3]  R866      3.9981618523597717e-01
    z[3,1,3]  R867      -5.7392424345016479e-01
    z[3,1,3]  R868      1.0243978351354599e-01
    z[3,1,3]  R869      -1.8930040299892426e-02
    z[3,1,3]  R870      -3.2287371158599854e-01
    z[3,1,3]  R871      -1.6707479953765869e-01
    z[3,1,3]  R872      2.4766427278518677e-01
    z[3,1,3]  R873      7.4058908224105835e-01
    z[3,1,3]  R874      -2.1980394423007965e-01
    z[3,1,3]  R875      1.7972676083445549e-02
    z[3,1,3]  R876      -2.1149446070194244e-01
    z[3,1,3]  R877      -6.3981473445892334e-02
    z[3,1,3]  R878      1.6020385921001434e-01
    z[3,1,3]  R879      -4.2409861087799072e-01
    z[3,1,3]  R880      -7.2126221656799316e-01
    z[3,1,3]  R881      -3.7648153305053711e-01
    z[3,1,3]  R882      0.108011893928051
    z[3,1,3]  R883      1.1943751573562622e-01
    z[3,1,3]  R884      -1.5580879151821136e-01
    z[3,1,3]  R885      -3.8042029738426208e-01
    z[3,1,3]  R886      3.7178599834442139e-01
    z[3,1,3]  R887      1.7014692723751068e-01
    z[3,1,3]  R888      1.1572734266519547e-01
    z[3,1,3]  R889      4.5022162795066833e-01
    z[3,1,3]  R890      -2.4338285624980927e-01
    z[3,1,3]  R891      5.6788083165884018e-02
    z[3,1,3]  R892      8.5707187652587891e-02
    z[3,1,3]  R893      7.1806603670120239e-01
    z[3,1,3]  R894      0.564498245716095
    z[3,1,3]  R895      8.1387780606746674e-02
    z[3,1,3]  R896      -3.8180518895387650e-02
    z[3,1,3]  R897      -3.8070392608642578e-01
    z[3,1,3]  R898      -3.9326062798500061e-01
    z[3,1,3]  R899      3.1312260031700134e-01
    z[3,1,3]  R900      1.9833179190754890e-02
    z[3,1,3]  R901      -3.5487979650497437e-02
    z[3,1,3]  R902      -2.7073004841804504e-01
    z[3,1,3]  R903      -9.8129108548164368e-02
    z[3,1,3]  R904      1.0215727984905243e-01
    z[3,1,3]  R905      4.4515532255172729e-01
    z[3,1,3]  R906      4.6612039208412170e-01
    z[3,1,3]  R907      6.9420111179351807e-01
    z[3,1,3]  R908      7.0787101984024048e-01
    z[3,1,3]  R909      5.2529454231262207e-01
    z[3,1,4]  R15       1
    z[3,1,4]  R33       -1
    z[3,1,4]  R834      -1
    z[3,1,4]  R835      1
    z[3,1,4]  R840      -1.5118260681629181e-01
    z[3,1,4]  R841      -1.2110810726881027e-01
    z[3,1,4]  R842      3.0696511268615723e-01
    z[3,1,4]  R843      9.3824982643127441e-02
    z[3,1,4]  R844      5.6252223253250122e-01
    z[3,1,4]  R845      4.5384871959686279e-01
    z[3,1,4]  R846      3.0659487843513489e-01
    z[3,1,4]  R847      -2.3273593187332153e-01
    z[3,1,4]  R848      -1.6773466765880585e-01
    z[3,1,4]  R849      -1.9281828776001930e-02
    z[3,1,4]  R850      -3.8209676742553711e-01
    z[3,1,4]  R851      -6.9468045234680176e-01
    z[3,1,4]  R852      -1.7974703013896942e-01
    z[3,1,4]  R853      -2.7379241585731506e-01
    z[3,1,4]  R854      -6.6507525742053986e-02
    z[3,1,4]  R855      2.2297158837318420e-01
    z[3,1,4]  R856      -2.7357056736946106e-01
    z[3,1,4]  R857      2.1131275594234467e-01
    z[3,1,4]  R858      -2.1221134066581726e-01
    z[3,1,4]  R859      3.5109922289848328e-02
    z[3,1,4]  R860      -0.242910698056221
    z[3,1,4]  R861      -6.4958351850509644e-01
    z[3,1,4]  R862      -8.3872549235820770e-02
    z[3,1,4]  R863      2.5922521948814392e-01
    z[3,1,4]  R864      5.6454139947891235e-01
    z[3,1,4]  R865      7.3291277885437012e-01
    z[3,1,4]  R866      1.1814720183610916e-01
    z[3,1,4]  R867      2.6722148060798645e-01
    z[3,1,4]  R868      3.0719587206840515e-01
    z[3,1,4]  R869      -5.8366615325212479e-02
    z[3,1,4]  R870      -2.9494842886924744e-01
    z[3,1,4]  R871      -1.6150401532649994e-01
    z[3,1,4]  R872      -1.4807645976543427e-01
    z[3,1,4]  R873      1.3833388686180115e-01
    z[3,1,4]  R874      -1.4137434959411621e-01
    z[3,1,4]  R875      8.2156389951705933e-02
    z[3,1,4]  R876      2.8801393508911133e-01
    z[3,1,4]  R877      4.7589689493179321e-01
    z[3,1,4]  R878      3.6816483736038208e-01
    z[3,1,4]  R879      1.2181729823350906e-01
    z[3,1,4]  R880      1.8563615158200264e-02
    z[3,1,4]  R881      4.8742804676294327e-02
    z[3,1,4]  R882      2.1600225567817688e-01
    z[3,1,4]  R883      -6.3330513238906860e-01
    z[3,1,4]  R884      -6.1474514007568359e-01
    z[3,1,4]  R885      6.2007820606231689e-01
    z[3,1,4]  R886      1.1409016698598862e-01
    z[3,1,4]  R887      2.7734309434890747e-01
    z[3,1,4]  R888      -2.7945801615715027e-01
    z[3,1,4]  R889      -1.0434918105602264e-01
    z[3,1,4]  R890      -0.00574418343603611
    z[3,1,4]  R891      -2.4857813119888306e-01
    z[3,1,4]  R892      -4.4940817356109619e-01
    z[3,1,4]  R893      -3.0068006366491318e-02
    z[3,1,4]  R894      1.5575060248374939e-01
    z[3,1,4]  R895      -2.9704365134239197e-01
    z[3,1,4]  R896      4.6199128031730652e-01
    z[3,1,4]  R897      5.6697374582290649e-01
    z[3,1,4]  R898      1.7257489264011383e-01
    z[3,1,4]  R899      3.1518572568893433e-01
    z[3,1,4]  R900      0.251932293176651
    z[3,1,4]  R901      -3.6011943221092224e-01
    z[3,1,4]  R902      4.5508152246475220e-01
    z[3,1,4]  R903      1.9532330334186554e-01
    z[3,1,4]  R904      1.0214227437973022e-01
    z[3,1,4]  R905      1.1158791929483414e-01
    z[3,1,4]  R906      3.6181509494781494e-01
    z[3,1,4]  R907      1.6459262371063232e-01
    z[3,1,4]  R908      6.1250500380992889e-02
    z[3,1,4]  R909      -0.228758305311203
    z[3,1,5]  R16       1
    z[3,1,5]  R34       -1
    z[3,1,5]  R836      -1
    z[3,1,5]  R837      1
    z[3,1,5]  R840      1.4710752665996552e-01
    z[3,1,5]  R841      5.5916242301464081e-02
    z[3,1,5]  R842      -4.3696433305740356e-01
    z[3,1,5]  R843      1.7973285913467407e-01
    z[3,1,5]  R844      5.2761003375053406e-02
    z[3,1,5]  R845      -4.1906601190567017e-01
    z[3,1,5]  R846      -2.1328464150428772e-01
    z[3,1,5]  R847      -3.1065386533737183e-01
    z[3,1,5]  R848      -3.6468520760536194e-02
    z[3,1,5]  R849      2.5497859343886375e-02
    z[3,1,5]  R850      4.7373014688491821e-01
    z[3,1,5]  R851      3.4413686394691467e-01
    z[3,1,5]  R852      1.0588242113590240e-01
    z[3,1,5]  R853      -5.6741183996200562e-01
    z[3,1,5]  R854      -1.9991537928581238e-01
    z[3,1,5]  R855      4.0387919545173645e-01
    z[3,1,5]  R856      4.9634307622909546e-01
    z[3,1,5]  R857      -3.8713118433952332e-01
    z[3,1,5]  R858      6.3142009079456329e-02
    z[3,1,5]  R859      -3.2969031017273664e-03
    z[3,1,5]  R860      3.0698272585868835e-01
    z[3,1,5]  R861      -1.0310070216655731e-01
    z[3,1,5]  R862      4.5047125220298767e-01
    z[3,1,5]  R863      6.7605400085449219e-01
    z[3,1,5]  R864      1.3374383747577667e-01
    z[3,1,5]  R865      3.3290737867355347e-01
    z[3,1,5]  R866      -0.0471990704536438
    z[3,1,5]  R867      -2.4472513794898987e-01
    z[3,1,5]  R868      -2.2847951948642731e-01
    z[3,1,5]  R869      1.9362162053585052e-01
    z[3,1,5]  R870      1.2813235819339752e-01
    z[3,1,5]  R871      -2.9364410042762756e-01
    z[3,1,5]  R872      3.1093168258666992e-01
    z[3,1,5]  R873      2.8522640466690063e-01
    z[3,1,5]  R874      -2.9728201031684875e-01
    z[3,1,5]  R875      -3.9887115359306335e-01
    z[3,1,5]  R876      -1.6919489204883575e-01
    z[3,1,5]  R877      -2.6922725141048431e-02
    z[3,1,5]  R878      -1.3203187286853790e-01
    z[3,1,5]  R879      -1.9959259033203125e-01
    z[3,1,5]  R880      3.4723851829767227e-02
    z[3,1,5]  R881      -3.2207381725311279e-01
    z[3,1,5]  R882      -4.2285212874412537e-01
    z[3,1,5]  R883      -2.9673242568969727e-01
    z[3,1,5]  R884      -1.4082315564155579e-01
    z[3,1,5]  R885      -2.5233942270278931e-01
    z[3,1,5]  R886      8.2357627153396606e-01
    z[3,1,5]  R887      -5.0738650560379028e-01
    z[3,1,5]  R888      -2.7238273620605469e-01
    z[3,1,5]  R889      -2.3493853211402893e-01
    z[3,1,5]  R890      5.1415461301803589e-01
    z[3,1,5]  R891      1.5697108209133148e-01
    z[3,1,5]  R892      9.9229268729686737e-02
    z[3,1,5]  R893      5.0024546682834625e-02
    z[3,1,5]  R894      2.0019714534282684e-01
    z[3,1,5]  R895      4.6729168295860291e-01
    z[3,1,5]  R896      0.555384635925293
    z[3,1,5]  R897      2.6711070537567139e-01
    z[3,1,5]  R898      -3.8205191493034363e-02
    z[3,1,5]  R899      1.2230596691370010e-01
    z[3,1,5]  R900      9.9092327058315277e-02
    z[3,1,5]  R901      3.7132516503334045e-01
    z[3,1,5]  R902      2.4346999824047089e-01
    z[3,1,5]  R903      3.6300173401832581e-01
    z[3,1,5]  R904      3.1244638562202454e-01
    z[3,1,5]  R905      -1.0658074170351028e-01
    z[3,1,5]  R906      -1.8484708666801453e-01
    z[3,1,5]  R907      2.6160871982574463e-01
    z[3,1,5]  R908      4.0985457599163055e-02
    z[3,1,5]  R909      2.9875887557864189e-02
    z[3,1,6]  R17       1
    z[3,1,6]  R35       -1
    z[3,1,6]  R838      -1
    z[3,1,6]  R839      1
    z[3,1,6]  R840      1.7206548154354095e-01
    z[3,1,6]  R841      -2.2013604640960693e-01
    z[3,1,6]  R842      -4.1592967510223389e-01
    z[3,1,6]  R843      3.1965491175651550e-01
    z[3,1,6]  R844      -7.8862540423870087e-02
    z[3,1,6]  R845      4.4223007559776306e-01
    z[3,1,6]  R846      1.3842076063156128e-01
    z[3,1,6]  R847      8.0339181423187256e-01
    z[3,1,6]  R848      -4.7521837055683136e-02
    z[3,1,6]  R849      1.2020229548215866e-01
    z[3,1,6]  R850      -5.0076227635145187e-02
    z[3,1,6]  R851      -2.4653879925608635e-02
    z[3,1,6]  R852      5.5876958370208740e-01
    z[3,1,6]  R853      3.0013734102249146e-01
    z[3,1,6]  R854      1.0981138795614243e-01
    z[3,1,6]  R855      -2.3106880486011505e-01
    z[3,1,6]  R856      -5.8837193250656128e-01
    z[3,1,6]  R857      -2.6153776049613953e-01
    z[3,1,6]  R858      -5.8548414707183838e-01
    z[3,1,6]  R859      -1.6975912451744080e-01
    z[3,1,6]  R860      -3.8777709007263184e-01
    z[3,1,6]  R861      4.2124241590499878e-01
    z[3,1,6]  R862      2.3847469687461853e-01
    z[3,1,6]  R863      1.8114395439624786e-01
    z[3,1,6]  R864      3.6959323287010193e-01
    z[3,1,6]  R865      -1.0266353935003281e-01
    z[3,1,6]  R866      -2.7397081255912781e-01
    z[3,1,6]  R867      2.3994588851928711e-01
    z[3,1,6]  R868      6.2200784683227539e-01
    z[3,1,6]  R869      9.7674198448657990e-02
    z[3,1,6]  R870      -4.7831791453063488e-03
    z[3,1,6]  R871      3.0158025026321411e-01
    z[3,1,6]  R872      3.1003820896148682e-01
    z[3,1,6]  R873      1.0133621096611023e-01
    z[3,1,6]  R874      1.4268645644187927e-01
    z[3,1,6]  R875      2.1593706309795380e-01
    z[3,1,6]  R876      -3.2391491532325745e-01
    z[3,1,6]  R877      -2.4074141681194305e-01
    z[3,1,6]  R878      -2.4229244887828827e-01
    z[3,1,6]  R879      1.2261576205492020e-01
    z[3,1,6]  R880      3.1601378321647644e-01
    z[3,1,6]  R881      -3.7417837977409363e-01
    z[3,1,6]  R882      2.8522792458534241e-01
    z[3,1,6]  R883      0.0919843465089798
    z[3,1,6]  R884      -3.7860912084579468e-01
    z[3,1,6]  R885      6.9010592997074127e-02
    z[3,1,6]  R886      7.2863809764385223e-02
    z[3,1,6]  R887      4.1865069419145584e-02
    z[3,1,6]  R888      -2.8414955735206604e-01
    z[3,1,6]  R889      -0.125092551112175
    z[3,1,6]  R890      2.0233482122421265e-02
    z[3,1,6]  R891      5.1945644617080688e-01
    z[3,1,6]  R892      1.3274191319942474e-01
    z[3,1,6]  R893      -2.6371926069259644e-01
    z[3,1,6]  R894      -5.7075989246368408e-01
    z[3,1,6]  R895      5.6197410821914673e-01
    z[3,1,6]  R896      -3.9840653538703918e-02
    z[3,1,6]  R897      -2.5980910658836365e-01
    z[3,1,6]  R898      4.7901767492294312e-01
    z[3,1,6]  R899      6.5745405852794647e-02
    z[3,1,6]  R900      -3.8314926624298096e-01
    z[3,1,6]  R901      1.3567297160625458e-01
    z[3,1,6]  R902      3.3263084292411804e-01
    z[3,1,6]  R903      -6.2555171549320221e-02
    z[3,1,6]  R904      3.6595532298088074e-01
    z[3,1,6]  R905      -1.3298501074314117e-01
    z[3,1,6]  R906      5.7471200823783875e-02
    z[3,1,6]  R907      -1.9934695959091187e-01
    z[3,1,6]  R908      -2.4804943799972534e-01
    z[3,1,6]  R909      2.4247968196868896e-01
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R910      -1
    z[2,3,0]  R911      1
    z[2,3,0]  R924      4.1082128882408142e-01
    z[2,3,0]  R925      2.3075322806835175e-01
    z[2,3,0]  R926      3.0020439624786377e-01
    z[2,3,0]  R927      3.1325316429138184e-01
    z[2,3,0]  R928      7.0484243333339691e-02
    z[2,3,0]  R929      -8.2420426607131958e-01
    z[2,3,0]  R930      -1.9736020267009735e-01
    z[2,3,0]  R931      -2.5785785913467407e-01
    z[2,3,0]  R932      -3.7281751632690430e-01
    z[2,3,0]  R933      3.5973957180976868e-01
    z[2,3,0]  R934      -2.0364120602607727e-01
    z[2,3,0]  R935      -7.1394693851470947e-01
    z[2,3,0]  R936      -3.3235621452331543e-01
    z[2,3,0]  R937      -8.0002641677856445e-01
    z[2,3,0]  R938      -5.6969982385635376e-01
    z[2,3,0]  R939      1.5661850571632385e-01
    z[2,3,0]  R940      -3.7715968489646912e-01
    z[2,3,0]  R941      2.8012451529502869e-01
    z[2,3,0]  R942      6.4431659877300262e-02
    z[2,3,0]  R943      1.2779888510704041e-01
    z[2,3,0]  R944      -9.8439827561378479e-02
    z[2,3,0]  R945      -8.0734395980834961e-01
    z[2,3,0]  R946      -3.7942594289779663e-01
    z[2,3,0]  R947      1.3505963981151581e-01
    z[2,3,0]  R948      -2.6683938503265381e-01
    z[2,3,0]  R949      9.1274734586477280e-03
    z[2,3,0]  R950      -2.8737941384315491e-01
    z[2,3,0]  R951      2.9615676403045654e-01
    z[2,3,0]  R952      3.5876259207725525e-02
    z[2,3,0]  R953      -6.0228276997804642e-02
    z[2,3,0]  R954      -4.6925377845764160e-01
    z[2,3,0]  R955      -0.33150514960289
    z[2,3,0]  R956      -5.9620642662048340e-01
    z[2,3,0]  R957      -5.3413516283035278e-01
    z[2,3,0]  R958      -6.8876588344573975e-01
    z[2,3,0]  R959      -6.0696613788604736e-01
    z[2,3,0]  R960      -8.4953486919403076e-01
    z[2,3,0]  R961      -3.9942458271980286e-01
    z[2,3,0]  R962      9.1994702816009521e-01
    z[2,3,0]  R963      8.8811534643173218e-01
    z[2,3,0]  R964      -7.2577923536300659e-01
    z[2,3,0]  R965      -0.519461452960968
    z[2,3,0]  R966      4.1029435396194458e-01
    z[2,3,0]  R967      -1.9557641819119453e-02
    z[2,3,0]  R968      4.4595736265182495e-01
    z[2,3,0]  R969      6.6566020250320435e-02
    z[2,3,0]  R970      3.9135344326496124e-02
    z[2,3,0]  R971      3.4614410996437073e-01
    z[2,3,0]  R972      2.3814016953110695e-02
    z[2,3,0]  R973      7.9699587821960449e-01
    z[2,3,0]  R974      -6.4133369922637939e-01
    z[2,3,0]  R975      -5.4724627733230591e-01
    z[2,3,0]  R976      -0.620279848575592
    z[2,3,0]  R977      3.0767804384231567e-01
    z[2,3,0]  R978      3.8189122080802917e-01
    z[2,3,0]  R979      -9.4968140125274658e-02
    z[2,3,0]  R980      6.8948942422866821e-01
    z[2,3,0]  R981      -6.1649329960346222e-02
    z[2,3,0]  R982      4.1818743944168091e-01
    z[2,3,0]  R983      9.6550965309143066e-01
    z[2,3,0]  R984      -2.5130379199981689e-01
    z[2,3,0]  R985      2.6442989706993103e-01
    z[2,3,0]  R986      5.3732526302337646e-01
    z[2,3,0]  R987      -2.8376492857933044e-01
    z[2,3,0]  R988      9.0092593431472778e-01
    z[2,3,0]  R989      8.6789494752883911e-01
    z[2,3,0]  R990      8.5806202888488770e-01
    z[2,3,0]  R991      8.2225483655929565e-01
    z[2,3,0]  R992      0.821610689163208
    z[2,3,0]  R993      8.3646327257156372e-01
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R912      -1
    z[2,3,1]  R913      1
    z[2,3,1]  R924      4.1129791736602783e-01
    z[2,3,1]  R925      4.2444208264350891e-01
    z[2,3,1]  R926      5.1897394657135010e-01
    z[2,3,1]  R927      4.0083104372024536e-01
    z[2,3,1]  R928      3.3503478765487671e-01
    z[2,3,1]  R929      -9.4895556569099426e-02
    z[2,3,1]  R930      -6.8664211034774780e-01
    z[2,3,1]  R931      -0.662268877029419
    z[2,3,1]  R932      -7.2935426235198975e-01
    z[2,3,1]  R933      -8.5722547769546509e-01
    z[2,3,1]  R934      3.4180215001106262e-01
    z[2,3,1]  R935      -7.9283893108367920e-02
    z[2,3,1]  R936      -0.656761646270752
    z[2,3,1]  R937      -8.5472755134105682e-02
    z[2,3,1]  R938      -2.9222324490547180e-01
    z[2,3,1]  R939      -0.798236072063446
    z[2,3,1]  R940      -6.6360962390899658e-01
    z[2,3,1]  R941      -0.776215136051178
    z[2,3,1]  R942      -6.1289650201797485e-01
    z[2,3,1]  R943      -7.3274105787277222e-01
    z[2,3,1]  R944      1.6262401640415192e-01
    z[2,3,1]  R945      -3.2446837425231934e-01
    z[2,3,1]  R946      -6.4932662248611450e-01
    z[2,3,1]  R947      -7.8822964429855347e-01
    z[2,3,1]  R948      -6.6239368915557861e-01
    z[2,3,1]  R949      -6.8379777669906616e-01
    z[2,3,1]  R950      -9.2993378639221191e-01
    z[2,3,1]  R951      -8.1093680858612061e-01
    z[2,3,1]  R952      -8.6881810426712036e-01
    z[2,3,1]  R953      -9.3162292242050171e-01
    z[2,3,1]  R954      -3.1371474266052246e-01
    z[2,3,1]  R955      3.2901279628276825e-02
    z[2,3,1]  R956      1.6907972097396851e-01
    z[2,3,1]  R957      9.1157384216785431e-02
    z[2,3,1]  R958      -2.7442991733551025e-01
    z[2,3,1]  R959      4.0999788790941238e-02
    z[2,3,1]  R960      1.7802091315388680e-02
    z[2,3,1]  R961      -4.6836573630571365e-02
    z[2,3,1]  R962      -1.0292798280715942e-01
    z[2,3,1]  R963      -9.5199182629585266e-02
    z[2,3,1]  R964      1.2362776324152946e-02
    z[2,3,1]  R965      3.5043430328369141e-01
    z[2,3,1]  R966      6.5007501840591431e-01
    z[2,3,1]  R967      7.1344602108001709e-01
    z[2,3,1]  R968      0.801207423210144
    z[2,3,1]  R969      5.6806391477584839e-01
    z[2,3,1]  R970      5.5044001340866089e-01
    z[2,3,1]  R971      0.766588568687439
    z[2,3,1]  R972      7.7620851993560791e-01
    z[2,3,1]  R973      4.8600149154663086e-01
    z[2,3,1]  R974      0.492839515209198
    z[2,3,1]  R975      4.1238497942686081e-02
    z[2,3,1]  R976      1.3178735971450806e-01
    z[2,3,1]  R977      0.550700306892395
    z[2,3,1]  R978      5.7686352729797363e-01
    z[2,3,1]  R979      5.3804230690002441e-01
    z[2,3,1]  R980      5.2287822961807251e-01
    z[2,3,1]  R981      6.5635836124420166e-01
    z[2,3,1]  R982      4.2095881700515747e-01
    z[2,3,1]  R983      -1.2013946473598480e-01
    z[2,3,1]  R984      7.3735463619232178e-01
    z[2,3,1]  R985      6.0515117645263672e-01
    z[2,3,1]  R986      5.4157292842864990e-01
    z[2,3,1]  R987      4.7969511151313782e-01
    z[2,3,1]  R988      3.0161522328853607e-02
    z[2,3,1]  R989      -1.3235937058925629e-01
    z[2,3,1]  R990      4.7759800218045712e-03
    z[2,3,1]  R991      -1.7067900300025940e-01
    z[2,3,1]  R992      -2.6218351721763611e-01
    z[2,3,1]  R993      -1.3294726610183716e-01
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R914      -1
    z[2,3,2]  R915      1
    z[2,3,2]  R924      -5.0281691364943981e-03
    z[2,3,2]  R925      3.9302808046340942e-01
    z[2,3,2]  R926      1.3175579905509949e-01
    z[2,3,2]  R927      2.2822003066539764e-01
    z[2,3,2]  R928      2.6929777860641479e-01
    z[2,3,2]  R929      -2.3216364905238152e-02
    z[2,3,2]  R930      1.1330621689558029e-01
    z[2,3,2]  R931      3.2696780562400818e-01
    z[2,3,2]  R932      1.3560181856155396e-01
    z[2,3,2]  R933      1.5116095542907715e-01
    z[2,3,2]  R934      -4.2924135923385620e-01
    z[2,3,2]  R935      3.9347419142723083e-01
    z[2,3,2]  R936      1.5058565139770508e-01
    z[2,3,2]  R937      2.9819962382316589e-01
    z[2,3,2]  R938      0.632092297077179
    z[2,3,2]  R939      3.8131404668092728e-02
    z[2,3,2]  R940      -6.9550216197967529e-02
    z[2,3,2]  R941      -3.7918922305107117e-01
    z[2,3,2]  R942      3.9668749086558819e-03
    z[2,3,2]  R943      -4.9010598659515381e-01
    z[2,3,2]  R944      -5.9355926513671875e-01
    z[2,3,2]  R945      1.6943012177944183e-01
    z[2,3,2]  R946      -2.0457480847835541e-01
    z[2,3,2]  R947      -1.8478755652904510e-01
    z[2,3,2]  R948      -2.4520482122898102e-01
    z[2,3,2]  R949      1.4782798290252686e-01
    z[2,3,2]  R950      1.2678916752338409e-01
    z[2,3,2]  R951      2.1323013305664062e-01
    z[2,3,2]  R952      -1.0945250838994980e-01
    z[2,3,2]  R953      -2.0598389208316803e-01
    z[2,3,2]  R954      7.7526587247848511e-01
    z[2,3,2]  R955      8.9516741037368774e-01
    z[2,3,2]  R956      3.5201448202133179e-01
    z[2,3,2]  R957      5.7556211948394775e-01
    z[2,3,2]  R958      2.4388627707958221e-01
    z[2,3,2]  R959      1.9422550499439240e-01
    z[2,3,2]  R960      2.5933519005775452e-01
    z[2,3,2]  R961      0.202837273478508
    z[2,3,2]  R962      3.2138973474502563e-01
    z[2,3,2]  R963      4.2020189762115479e-01
    z[2,3,2]  R964      -2.8708580136299133e-01
    z[2,3,2]  R965      -4.6171575784683228e-02
    z[2,3,2]  R966      -2.1103249490261078e-01
    z[2,3,2]  R967      4.2556360363960266e-02
    z[2,3,2]  R968      -3.3406227827072144e-02
    z[2,3,2]  R969      -0.0990736186504364
    z[2,3,2]  R970      1.3600957393646240e-01
    z[2,3,2]  R971      1.1976634850725532e-03
    z[2,3,2]  R972      0.0696486309170723
    z[2,3,2]  R973      3.0957534909248352e-01
    z[2,3,2]  R974      -1.2485025823116302e-01
    z[2,3,2]  R975      -1.3977298513054848e-02
    z[2,3,2]  R976      -0.208160862326622
    z[2,3,2]  R977      8.8788039982318878e-02
    z[2,3,2]  R978      -2.0874983072280884e-01
    z[2,3,2]  R979      -7.1404181420803070e-02
    z[2,3,2]  R980      -1.0149326175451279e-02
    z[2,3,2]  R981      -2.1710006892681122e-01
    z[2,3,2]  R982      3.2241743803024292e-01
    z[2,3,2]  R983      -5.0627548247575760e-02
    z[2,3,2]  R984      4.3066430091857910e-01
    z[2,3,2]  R985      5.7679611444473267e-01
    z[2,3,2]  R986      3.7671455740928650e-01
    z[2,3,2]  R987      -1.7360439896583557e-01
    z[2,3,2]  R988      1.0191214829683304e-01
    z[2,3,2]  R989      1.2821683287620544e-01
    z[2,3,2]  R990      -4.9768432974815369e-02
    z[2,3,2]  R991      7.4249237775802612e-02
    z[2,3,2]  R992      1.3735768198966980e-01
    z[2,3,2]  R993      -1.8188828229904175e-01
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R916      -1
    z[2,3,3]  R917      1
    z[2,3,3]  R924      6.2967991828918457e-01
    z[2,3,3]  R925      4.2992448806762695e-01
    z[2,3,3]  R926      -3.1996479630470276e-01
    z[2,3,3]  R927      -6.8285381793975830e-01
    z[2,3,3]  R928      -4.3336641788482666e-01
    z[2,3,3]  R929      -3.1596380472183228e-01
    z[2,3,3]  R930      3.7232673168182373e-01
    z[2,3,3]  R931      4.9252521991729736e-01
    z[2,3,3]  R932      3.8690242171287537e-01
    z[2,3,3]  R933      9.1316811740398407e-02
    z[2,3,3]  R934      2.4188812077045441e-01
    z[2,3,3]  R935      2.2152094542980194e-01
    z[2,3,3]  R936      6.0156309604644775e-01
    z[2,3,3]  R937      8.1735335290431976e-02
    z[2,3,3]  R938      1.6186475753784180e-02
    z[2,3,3]  R939      3.8005319237709045e-01
    z[2,3,3]  R940      4.4550243020057678e-01
    z[2,3,3]  R941      3.5873657464981079e-01
    z[2,3,3]  R942      6.7233246564865112e-01
    z[2,3,3]  R943      4.4264367222785950e-01
    z[2,3,3]  R944      2.1618527173995972e-01
    z[2,3,3]  R945      -0.0953526645898819
    z[2,3,3]  R946      5.7371973991394043e-01
    z[2,3,3]  R947      4.2816025018692017e-01
    z[2,3,3]  R948      0.508263349533081
    z[2,3,3]  R949      6.0387039184570312e-01
    z[2,3,3]  R950      1.8024496734142303e-01
    z[2,3,3]  R951      3.6991345882415771e-01
    z[2,3,3]  R952      2.5764605402946472e-01
    z[2,3,3]  R953      8.3447188138961792e-02
    z[2,3,3]  R954      0.07901581376791
    z[2,3,3]  R955      0.14643594622612
    z[2,3,3]  R956      1.8404580652713776e-01
    z[2,3,3]  R957      -4.8148915171623230e-01
    z[2,3,3]  R958      -2.5568547844886780e-01
    z[2,3,3]  R959      1.2257728725671768e-01
    z[2,3,3]  R960      -2.2818391025066376e-01
    z[2,3,3]  R961      -3.1830493360757828e-02
    z[2,3,3]  R962      8.9937351644039154e-02
    z[2,3,3]  R963      -1.0073759406805038e-01
    z[2,3,3]  R964      1.3321955502033234e-01
    z[2,3,3]  R965      6.0039076954126358e-02
    z[2,3,3]  R966      -9.3716740608215332e-02
    z[2,3,3]  R967      4.2428936809301376e-02
    z[2,3,3]  R968      -3.1878617405891418e-01
    z[2,3,3]  R969      -6.2994378805160522e-01
    z[2,3,3]  R970      9.8014205694198608e-02
    z[2,3,3]  R971      -1.7204432189464569e-01
    z[2,3,3]  R972      -1.6432275995612144e-02
    z[2,3,3]  R973      5.1976222544908524e-02
    z[2,3,3]  R974      -1.6308794915676117e-01
    z[2,3,3]  R975      2.9764357209205627e-01
    z[2,3,3]  R976      -5.3639984130859375e-01
    z[2,3,3]  R977      -1.9266603887081146e-01
    z[2,3,3]  R978      0.067952461540699
    z[2,3,3]  R979      -1.9458861649036407e-01
    z[2,3,3]  R980      3.9981618523597717e-01
    z[2,3,3]  R981      -5.7392424345016479e-01
    z[2,3,3]  R982      1.0243978351354599e-01
    z[2,3,3]  R983      -1.8930040299892426e-02
    z[2,3,3]  R984      -3.2287371158599854e-01
    z[2,3,3]  R985      -1.6707479953765869e-01
    z[2,3,3]  R986      2.4766427278518677e-01
    z[2,3,3]  R987      7.4058908224105835e-01
    z[2,3,3]  R988      -2.1980394423007965e-01
    z[2,3,3]  R989      1.7972676083445549e-02
    z[2,3,3]  R990      -2.1149446070194244e-01
    z[2,3,3]  R991      -6.3981473445892334e-02
    z[2,3,3]  R992      1.6020385921001434e-01
    z[2,3,3]  R993      -4.2409861087799072e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R918      -1
    z[2,3,4]  R919      1
    z[2,3,4]  R924      1.3164044916629791e-01
    z[2,3,4]  R925      2.1666148304939270e-01
    z[2,3,4]  R926      0.144708052277565
    z[2,3,4]  R927      4.3102821707725525e-01
    z[2,3,4]  R928      -7.0655143260955811e-01
    z[2,3,4]  R929      -1.3440373539924622e-01
    z[2,3,4]  R930      -4.0865597128868103e-01
    z[2,3,4]  R931      3.2016980648040771e-01
    z[2,3,4]  R932      -1.4649938791990280e-02
    z[2,3,4]  R933      1.4581990242004395e-01
    z[2,3,4]  R934      -1.7378675937652588e-01
    z[2,3,4]  R935      0.144618958234787
    z[2,3,4]  R936      -8.2724452018737793e-02
    z[2,3,4]  R937      2.6303216814994812e-01
    z[2,3,4]  R938      -1.1931933462619781e-01
    z[2,3,4]  R939      3.5996192693710327e-01
    z[2,3,4]  R940      9.8586179316043854e-02
    z[2,3,4]  R941      7.0899382233619690e-02
    z[2,3,4]  R942      0.139943465590477
    z[2,3,4]  R943      2.8142226859927177e-02
    z[2,3,4]  R944      -4.9839276075363159e-01
    z[2,3,4]  R945      2.7118235826492310e-01
    z[2,3,4]  R946      -1.1143181473016739e-02
    z[2,3,4]  R947      -2.5423717498779297e-01
    z[2,3,4]  R948      -3.1971356272697449e-01
    z[2,3,4]  R949      -1.6451187431812286e-01
    z[2,3,4]  R950      4.0888965129852295e-02
    z[2,3,4]  R951      -0.165586456656456
    z[2,3,4]  R952      3.2327935099601746e-01
    z[2,3,4]  R953      -2.5632831454277039e-01
    z[2,3,4]  R954      -1.5118260681629181e-01
    z[2,3,4]  R955      -1.2110810726881027e-01
    z[2,3,4]  R956      3.0696511268615723e-01
    z[2,3,4]  R957      9.3824982643127441e-02
    z[2,3,4]  R958      5.6252223253250122e-01
    z[2,3,4]  R959      4.5384871959686279e-01
    z[2,3,4]  R960      3.0659487843513489e-01
    z[2,3,4]  R961      -2.3273593187332153e-01
    z[2,3,4]  R962      -1.6773466765880585e-01
    z[2,3,4]  R963      -1.9281828776001930e-02
    z[2,3,4]  R964      -3.8209676742553711e-01
    z[2,3,4]  R965      -6.9468045234680176e-01
    z[2,3,4]  R966      -1.7974703013896942e-01
    z[2,3,4]  R967      -2.7379241585731506e-01
    z[2,3,4]  R968      -6.6507525742053986e-02
    z[2,3,4]  R969      2.2297158837318420e-01
    z[2,3,4]  R970      -2.7357056736946106e-01
    z[2,3,4]  R971      2.1131275594234467e-01
    z[2,3,4]  R972      -2.1221134066581726e-01
    z[2,3,4]  R973      3.5109922289848328e-02
    z[2,3,4]  R974      -0.242910698056221
    z[2,3,4]  R975      -6.4958351850509644e-01
    z[2,3,4]  R976      -8.3872549235820770e-02
    z[2,3,4]  R977      2.5922521948814392e-01
    z[2,3,4]  R978      5.6454139947891235e-01
    z[2,3,4]  R979      7.3291277885437012e-01
    z[2,3,4]  R980      1.1814720183610916e-01
    z[2,3,4]  R981      2.6722148060798645e-01
    z[2,3,4]  R982      3.0719587206840515e-01
    z[2,3,4]  R983      -5.8366615325212479e-02
    z[2,3,4]  R984      -2.9494842886924744e-01
    z[2,3,4]  R985      -1.6150401532649994e-01
    z[2,3,4]  R986      -1.4807645976543427e-01
    z[2,3,4]  R987      1.3833388686180115e-01
    z[2,3,4]  R988      -1.4137434959411621e-01
    z[2,3,4]  R989      8.2156389951705933e-02
    z[2,3,4]  R990      2.8801393508911133e-01
    z[2,3,4]  R991      4.7589689493179321e-01
    z[2,3,4]  R992      3.6816483736038208e-01
    z[2,3,4]  R993      1.2181729823350906e-01
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R920      -1
    z[2,3,5]  R921      1
    z[2,3,5]  R924      4.1973805427551270e-01
    z[2,3,5]  R925      4.1488382220268250e-01
    z[2,3,5]  R926      -4.5210793614387512e-01
    z[2,3,5]  R927      -1.6175678372383118e-01
    z[2,3,5]  R928      -2.9067766666412354e-01
    z[2,3,5]  R929      3.1963995099067688e-01
    z[2,3,5]  R930      4.1255286335945129e-01
    z[2,3,5]  R931      0.0674590989947319
    z[2,3,5]  R932      -3.3464255928993225e-01
    z[2,3,5]  R933      -9.9096536636352539e-02
    z[2,3,5]  R934      -6.7073583602905273e-01
    z[2,3,5]  R935      1.1968901753425598e-01
    z[2,3,5]  R936      2.2094377782195807e-03
    z[2,3,5]  R937      -2.8939110040664673e-01
    z[2,3,5]  R938      3.8329422473907471e-01
    z[2,3,5]  R939      9.4530224800109863e-02
    z[2,3,5]  R940      2.8302699327468872e-01
    z[2,3,5]  R941      1.8131180107593536e-01
    z[2,3,5]  R942      -3.8422411680221558e-01
    z[2,3,5]  R943      -2.2456111386418343e-02
    z[2,3,5]  R944      -1.0661100596189499e-01
    z[2,3,5]  R945      3.2412678003311157e-01
    z[2,3,5]  R946      2.5091582536697388e-01
    z[2,3,5]  R947      1.4982797205448151e-01
    z[2,3,5]  R948      0.229428231716156
    z[2,3,5]  R949      -0.286403626203537
    z[2,3,5]  R950      -2.8573716059327126e-02
    z[2,3,5]  R951      -2.8184045106172562e-02
    z[2,3,5]  R952      -2.0938961207866669e-01
    z[2,3,5]  R953      -8.0055460333824158e-02
    z[2,3,5]  R954      1.4710752665996552e-01
    z[2,3,5]  R955      5.5916242301464081e-02
    z[2,3,5]  R956      -4.3696433305740356e-01
    z[2,3,5]  R957      1.7973285913467407e-01
    z[2,3,5]  R958      5.2761003375053406e-02
    z[2,3,5]  R959      -4.1906601190567017e-01
    z[2,3,5]  R960      -2.1328464150428772e-01
    z[2,3,5]  R961      -3.1065386533737183e-01
    z[2,3,5]  R962      -3.6468520760536194e-02
    z[2,3,5]  R963      2.5497859343886375e-02
    z[2,3,5]  R964      4.7373014688491821e-01
    z[2,3,5]  R965      3.4413686394691467e-01
    z[2,3,5]  R966      1.0588242113590240e-01
    z[2,3,5]  R967      -5.6741183996200562e-01
    z[2,3,5]  R968      -1.9991537928581238e-01
    z[2,3,5]  R969      4.0387919545173645e-01
    z[2,3,5]  R970      4.9634307622909546e-01
    z[2,3,5]  R971      -3.8713118433952332e-01
    z[2,3,5]  R972      6.3142009079456329e-02
    z[2,3,5]  R973      -3.2969031017273664e-03
    z[2,3,5]  R974      3.0698272585868835e-01
    z[2,3,5]  R975      -1.0310070216655731e-01
    z[2,3,5]  R976      4.5047125220298767e-01
    z[2,3,5]  R977      6.7605400085449219e-01
    z[2,3,5]  R978      1.3374383747577667e-01
    z[2,3,5]  R979      3.3290737867355347e-01
    z[2,3,5]  R980      -0.0471990704536438
    z[2,3,5]  R981      -2.4472513794898987e-01
    z[2,3,5]  R982      -2.2847951948642731e-01
    z[2,3,5]  R983      1.9362162053585052e-01
    z[2,3,5]  R984      1.2813235819339752e-01
    z[2,3,5]  R985      -2.9364410042762756e-01
    z[2,3,5]  R986      3.1093168258666992e-01
    z[2,3,5]  R987      2.8522640466690063e-01
    z[2,3,5]  R988      -2.9728201031684875e-01
    z[2,3,5]  R989      -3.9887115359306335e-01
    z[2,3,5]  R990      -1.6919489204883575e-01
    z[2,3,5]  R991      -2.6922725141048431e-02
    z[2,3,5]  R992      -1.3203187286853790e-01
    z[2,3,5]  R993      -1.9959259033203125e-01
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R922      -1
    z[2,3,6]  R923      1
    z[2,3,6]  R924      -2.6838135719299316e-01
    z[2,3,6]  R925      4.5631670951843262e-01
    z[2,3,6]  R926      -5.4356628656387329e-01
    z[2,3,6]  R927      1.0432038456201553e-01
    z[2,3,6]  R928      -1.9684359431266785e-01
    z[2,3,6]  R929      3.0178797245025635e-01
    z[2,3,6]  R930      3.0108574777841568e-02
    z[2,3,6]  R931      -1.9585911929607391e-01
    z[2,3,6]  R932      -2.2083434462547302e-01
    z[2,3,6]  R933      2.7107185125350952e-01
    z[2,3,6]  R934      3.4475368261337280e-01
    z[2,3,6]  R935      -4.9483355879783630e-01
    z[2,3,6]  R936      2.5845885276794434e-01
    z[2,3,6]  R937      -3.2266917824745178e-01
    z[2,3,6]  R938      -1.7056754231452942e-01
    z[2,3,6]  R939      2.3213557898998260e-01
    z[2,3,6]  R940      0.352476567029953
    z[2,3,6]  R941      9.2968977987766266e-02
    z[2,3,6]  R942      0.0307808555662632
    z[2,3,6]  R943      -9.6563078463077545e-02
    z[2,3,6]  R944      5.5231606960296631e-01
    z[2,3,6]  R945      1.6284777224063873e-01
    z[2,3,6]  R946      1.7968676984310150e-02
    z[2,3,6]  R947      -2.3643250763416290e-01
    z[2,3,6]  R948      -1.2930619716644287e-01
    z[2,3,6]  R949      1.9165965914726257e-01
    z[2,3,6]  R950      3.9800401777029037e-02
    z[2,3,6]  R951      -2.1013411879539490e-01
    z[2,3,6]  R952      -1.3097006082534790e-01
    z[2,3,6]  R953      -8.3338119089603424e-02
    z[2,3,6]  R954      1.7206548154354095e-01
    z[2,3,6]  R955      -2.2013604640960693e-01
    z[2,3,6]  R956      -4.1592967510223389e-01
    z[2,3,6]  R957      3.1965491175651550e-01
    z[2,3,6]  R958      -7.8862540423870087e-02
    z[2,3,6]  R959      4.4223007559776306e-01
    z[2,3,6]  R960      1.3842076063156128e-01
    z[2,3,6]  R961      8.0339181423187256e-01
    z[2,3,6]  R962      -4.7521837055683136e-02
    z[2,3,6]  R963      1.2020229548215866e-01
    z[2,3,6]  R964      -5.0076227635145187e-02
    z[2,3,6]  R965      -2.4653879925608635e-02
    z[2,3,6]  R966      5.5876958370208740e-01
    z[2,3,6]  R967      3.0013734102249146e-01
    z[2,3,6]  R968      1.0981138795614243e-01
    z[2,3,6]  R969      -2.3106880486011505e-01
    z[2,3,6]  R970      -5.8837193250656128e-01
    z[2,3,6]  R971      -2.6153776049613953e-01
    z[2,3,6]  R972      -5.8548414707183838e-01
    z[2,3,6]  R973      -1.6975912451744080e-01
    z[2,3,6]  R974      -3.8777709007263184e-01
    z[2,3,6]  R975      4.2124241590499878e-01
    z[2,3,6]  R976      2.3847469687461853e-01
    z[2,3,6]  R977      1.8114395439624786e-01
    z[2,3,6]  R978      3.6959323287010193e-01
    z[2,3,6]  R979      -1.0266353935003281e-01
    z[2,3,6]  R980      -2.7397081255912781e-01
    z[2,3,6]  R981      2.3994588851928711e-01
    z[2,3,6]  R982      6.2200784683227539e-01
    z[2,3,6]  R983      9.7674198448657990e-02
    z[2,3,6]  R984      -4.7831791453063488e-03
    z[2,3,6]  R985      3.0158025026321411e-01
    z[2,3,6]  R986      3.1003820896148682e-01
    z[2,3,6]  R987      1.0133621096611023e-01
    z[2,3,6]  R988      1.4268645644187927e-01
    z[2,3,6]  R989      2.1593706309795380e-01
    z[2,3,6]  R990      -3.2391491532325745e-01
    z[2,3,6]  R991      -2.4074141681194305e-01
    z[2,3,6]  R992      -2.4229244887828827e-01
    z[2,3,6]  R993      1.2261576205492020e-01
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R994      -1
    z[3,2,0]  R995      1
    z[3,2,0]  R1008     -4.6925377845764160e-01
    z[3,2,0]  R1009     -0.33150514960289
    z[3,2,0]  R1010     -5.9620642662048340e-01
    z[3,2,0]  R1011     -5.3413516283035278e-01
    z[3,2,0]  R1012     -6.8876588344573975e-01
    z[3,2,0]  R1013     -6.0696613788604736e-01
    z[3,2,0]  R1014     -8.4953486919403076e-01
    z[3,2,0]  R1015     -3.9942458271980286e-01
    z[3,2,0]  R1016     9.1994702816009521e-01
    z[3,2,0]  R1017     8.8811534643173218e-01
    z[3,2,0]  R1018     -7.2577923536300659e-01
    z[3,2,0]  R1019     -0.519461452960968
    z[3,2,0]  R1020     4.1029435396194458e-01
    z[3,2,0]  R1021     -1.9557641819119453e-02
    z[3,2,0]  R1022     4.4595736265182495e-01
    z[3,2,0]  R1023     6.6566020250320435e-02
    z[3,2,0]  R1024     3.9135344326496124e-02
    z[3,2,0]  R1025     3.4614410996437073e-01
    z[3,2,0]  R1026     2.3814016953110695e-02
    z[3,2,0]  R1027     7.9699587821960449e-01
    z[3,2,0]  R1028     -6.4133369922637939e-01
    z[3,2,0]  R1029     -5.4724627733230591e-01
    z[3,2,0]  R1030     -0.620279848575592
    z[3,2,0]  R1031     3.0767804384231567e-01
    z[3,2,0]  R1032     3.8189122080802917e-01
    z[3,2,0]  R1033     -9.4968140125274658e-02
    z[3,2,0]  R1034     6.8948942422866821e-01
    z[3,2,0]  R1035     -6.1649329960346222e-02
    z[3,2,0]  R1036     4.1818743944168091e-01
    z[3,2,0]  R1037     9.6550965309143066e-01
    z[3,2,0]  R1038     -2.5130379199981689e-01
    z[3,2,0]  R1039     2.6442989706993103e-01
    z[3,2,0]  R1040     5.3732526302337646e-01
    z[3,2,0]  R1041     -2.8376492857933044e-01
    z[3,2,0]  R1042     9.0092593431472778e-01
    z[3,2,0]  R1043     8.6789494752883911e-01
    z[3,2,0]  R1044     8.5806202888488770e-01
    z[3,2,0]  R1045     8.2225483655929565e-01
    z[3,2,0]  R1046     0.821610689163208
    z[3,2,0]  R1047     8.3646327257156372e-01
    z[3,2,0]  R1048     4.1082128882408142e-01
    z[3,2,0]  R1049     2.3075322806835175e-01
    z[3,2,0]  R1050     3.0020439624786377e-01
    z[3,2,0]  R1051     3.1325316429138184e-01
    z[3,2,0]  R1052     7.0484243333339691e-02
    z[3,2,0]  R1053     -8.2420426607131958e-01
    z[3,2,0]  R1054     -1.9736020267009735e-01
    z[3,2,0]  R1055     -2.5785785913467407e-01
    z[3,2,0]  R1056     -3.7281751632690430e-01
    z[3,2,0]  R1057     3.5973957180976868e-01
    z[3,2,0]  R1058     -2.0364120602607727e-01
    z[3,2,0]  R1059     -7.1394693851470947e-01
    z[3,2,0]  R1060     -3.3235621452331543e-01
    z[3,2,0]  R1061     -8.0002641677856445e-01
    z[3,2,0]  R1062     -5.6969982385635376e-01
    z[3,2,0]  R1063     1.5661850571632385e-01
    z[3,2,0]  R1064     -3.7715968489646912e-01
    z[3,2,0]  R1065     2.8012451529502869e-01
    z[3,2,0]  R1066     6.4431659877300262e-02
    z[3,2,0]  R1067     1.2779888510704041e-01
    z[3,2,0]  R1068     -9.8439827561378479e-02
    z[3,2,0]  R1069     -8.0734395980834961e-01
    z[3,2,0]  R1070     -3.7942594289779663e-01
    z[3,2,0]  R1071     1.3505963981151581e-01
    z[3,2,0]  R1072     -2.6683938503265381e-01
    z[3,2,0]  R1073     9.1274734586477280e-03
    z[3,2,0]  R1074     -2.8737941384315491e-01
    z[3,2,0]  R1075     2.9615676403045654e-01
    z[3,2,0]  R1076     3.5876259207725525e-02
    z[3,2,0]  R1077     -6.0228276997804642e-02
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R996      -1
    z[3,2,1]  R997      1
    z[3,2,1]  R1008     -3.1371474266052246e-01
    z[3,2,1]  R1009     3.2901279628276825e-02
    z[3,2,1]  R1010     1.6907972097396851e-01
    z[3,2,1]  R1011     9.1157384216785431e-02
    z[3,2,1]  R1012     -2.7442991733551025e-01
    z[3,2,1]  R1013     4.0999788790941238e-02
    z[3,2,1]  R1014     1.7802091315388680e-02
    z[3,2,1]  R1015     -4.6836573630571365e-02
    z[3,2,1]  R1016     -1.0292798280715942e-01
    z[3,2,1]  R1017     -9.5199182629585266e-02
    z[3,2,1]  R1018     1.2362776324152946e-02
    z[3,2,1]  R1019     3.5043430328369141e-01
    z[3,2,1]  R1020     6.5007501840591431e-01
    z[3,2,1]  R1021     7.1344602108001709e-01
    z[3,2,1]  R1022     0.801207423210144
    z[3,2,1]  R1023     5.6806391477584839e-01
    z[3,2,1]  R1024     5.5044001340866089e-01
    z[3,2,1]  R1025     0.766588568687439
    z[3,2,1]  R1026     7.7620851993560791e-01
    z[3,2,1]  R1027     4.8600149154663086e-01
    z[3,2,1]  R1028     0.492839515209198
    z[3,2,1]  R1029     4.1238497942686081e-02
    z[3,2,1]  R1030     1.3178735971450806e-01
    z[3,2,1]  R1031     0.550700306892395
    z[3,2,1]  R1032     5.7686352729797363e-01
    z[3,2,1]  R1033     5.3804230690002441e-01
    z[3,2,1]  R1034     5.2287822961807251e-01
    z[3,2,1]  R1035     6.5635836124420166e-01
    z[3,2,1]  R1036     4.2095881700515747e-01
    z[3,2,1]  R1037     -1.2013946473598480e-01
    z[3,2,1]  R1038     7.3735463619232178e-01
    z[3,2,1]  R1039     6.0515117645263672e-01
    z[3,2,1]  R1040     5.4157292842864990e-01
    z[3,2,1]  R1041     4.7969511151313782e-01
    z[3,2,1]  R1042     3.0161522328853607e-02
    z[3,2,1]  R1043     -1.3235937058925629e-01
    z[3,2,1]  R1044     4.7759800218045712e-03
    z[3,2,1]  R1045     -1.7067900300025940e-01
    z[3,2,1]  R1046     -2.6218351721763611e-01
    z[3,2,1]  R1047     -1.3294726610183716e-01
    z[3,2,1]  R1048     4.1129791736602783e-01
    z[3,2,1]  R1049     4.2444208264350891e-01
    z[3,2,1]  R1050     5.1897394657135010e-01
    z[3,2,1]  R1051     4.0083104372024536e-01
    z[3,2,1]  R1052     3.3503478765487671e-01
    z[3,2,1]  R1053     -9.4895556569099426e-02
    z[3,2,1]  R1054     -6.8664211034774780e-01
    z[3,2,1]  R1055     -0.662268877029419
    z[3,2,1]  R1056     -7.2935426235198975e-01
    z[3,2,1]  R1057     -8.5722547769546509e-01
    z[3,2,1]  R1058     3.4180215001106262e-01
    z[3,2,1]  R1059     -7.9283893108367920e-02
    z[3,2,1]  R1060     -0.656761646270752
    z[3,2,1]  R1061     -8.5472755134105682e-02
    z[3,2,1]  R1062     -2.9222324490547180e-01
    z[3,2,1]  R1063     -0.798236072063446
    z[3,2,1]  R1064     -6.6360962390899658e-01
    z[3,2,1]  R1065     -0.776215136051178
    z[3,2,1]  R1066     -6.1289650201797485e-01
    z[3,2,1]  R1067     -7.3274105787277222e-01
    z[3,2,1]  R1068     1.6262401640415192e-01
    z[3,2,1]  R1069     -3.2446837425231934e-01
    z[3,2,1]  R1070     -6.4932662248611450e-01
    z[3,2,1]  R1071     -7.8822964429855347e-01
    z[3,2,1]  R1072     -6.6239368915557861e-01
    z[3,2,1]  R1073     -6.8379777669906616e-01
    z[3,2,1]  R1074     -9.2993378639221191e-01
    z[3,2,1]  R1075     -8.1093680858612061e-01
    z[3,2,1]  R1076     -8.6881810426712036e-01
    z[3,2,1]  R1077     -9.3162292242050171e-01
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R998      -1
    z[3,2,2]  R999      1
    z[3,2,2]  R1008     7.7526587247848511e-01
    z[3,2,2]  R1009     8.9516741037368774e-01
    z[3,2,2]  R1010     3.5201448202133179e-01
    z[3,2,2]  R1011     5.7556211948394775e-01
    z[3,2,2]  R1012     2.4388627707958221e-01
    z[3,2,2]  R1013     1.9422550499439240e-01
    z[3,2,2]  R1014     2.5933519005775452e-01
    z[3,2,2]  R1015     0.202837273478508
    z[3,2,2]  R1016     3.2138973474502563e-01
    z[3,2,2]  R1017     4.2020189762115479e-01
    z[3,2,2]  R1018     -2.8708580136299133e-01
    z[3,2,2]  R1019     -4.6171575784683228e-02
    z[3,2,2]  R1020     -2.1103249490261078e-01
    z[3,2,2]  R1021     4.2556360363960266e-02
    z[3,2,2]  R1022     -3.3406227827072144e-02
    z[3,2,2]  R1023     -0.0990736186504364
    z[3,2,2]  R1024     1.3600957393646240e-01
    z[3,2,2]  R1025     1.1976634850725532e-03
    z[3,2,2]  R1026     0.0696486309170723
    z[3,2,2]  R1027     3.0957534909248352e-01
    z[3,2,2]  R1028     -1.2485025823116302e-01
    z[3,2,2]  R1029     -1.3977298513054848e-02
    z[3,2,2]  R1030     -0.208160862326622
    z[3,2,2]  R1031     8.8788039982318878e-02
    z[3,2,2]  R1032     -2.0874983072280884e-01
    z[3,2,2]  R1033     -7.1404181420803070e-02
    z[3,2,2]  R1034     -1.0149326175451279e-02
    z[3,2,2]  R1035     -2.1710006892681122e-01
    z[3,2,2]  R1036     3.2241743803024292e-01
    z[3,2,2]  R1037     -5.0627548247575760e-02
    z[3,2,2]  R1038     4.3066430091857910e-01
    z[3,2,2]  R1039     5.7679611444473267e-01
    z[3,2,2]  R1040     3.7671455740928650e-01
    z[3,2,2]  R1041     -1.7360439896583557e-01
    z[3,2,2]  R1042     1.0191214829683304e-01
    z[3,2,2]  R1043     1.2821683287620544e-01
    z[3,2,2]  R1044     -4.9768432974815369e-02
    z[3,2,2]  R1045     7.4249237775802612e-02
    z[3,2,2]  R1046     1.3735768198966980e-01
    z[3,2,2]  R1047     -1.8188828229904175e-01
    z[3,2,2]  R1048     -5.0281691364943981e-03
    z[3,2,2]  R1049     3.9302808046340942e-01
    z[3,2,2]  R1050     1.3175579905509949e-01
    z[3,2,2]  R1051     2.2822003066539764e-01
    z[3,2,2]  R1052     2.6929777860641479e-01
    z[3,2,2]  R1053     -2.3216364905238152e-02
    z[3,2,2]  R1054     1.1330621689558029e-01
    z[3,2,2]  R1055     3.2696780562400818e-01
    z[3,2,2]  R1056     1.3560181856155396e-01
    z[3,2,2]  R1057     1.5116095542907715e-01
    z[3,2,2]  R1058     -4.2924135923385620e-01
    z[3,2,2]  R1059     3.9347419142723083e-01
    z[3,2,2]  R1060     1.5058565139770508e-01
    z[3,2,2]  R1061     2.9819962382316589e-01
    z[3,2,2]  R1062     0.632092297077179
    z[3,2,2]  R1063     3.8131404668092728e-02
    z[3,2,2]  R1064     -6.9550216197967529e-02
    z[3,2,2]  R1065     -3.7918922305107117e-01
    z[3,2,2]  R1066     3.9668749086558819e-03
    z[3,2,2]  R1067     -4.9010598659515381e-01
    z[3,2,2]  R1068     -5.9355926513671875e-01
    z[3,2,2]  R1069     1.6943012177944183e-01
    z[3,2,2]  R1070     -2.0457480847835541e-01
    z[3,2,2]  R1071     -1.8478755652904510e-01
    z[3,2,2]  R1072     -2.4520482122898102e-01
    z[3,2,2]  R1073     1.4782798290252686e-01
    z[3,2,2]  R1074     1.2678916752338409e-01
    z[3,2,2]  R1075     2.1323013305664062e-01
    z[3,2,2]  R1076     -1.0945250838994980e-01
    z[3,2,2]  R1077     -2.0598389208316803e-01
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R1000     -1
    z[3,2,3]  R1001     1
    z[3,2,3]  R1008     0.07901581376791
    z[3,2,3]  R1009     0.14643594622612
    z[3,2,3]  R1010     1.8404580652713776e-01
    z[3,2,3]  R1011     -4.8148915171623230e-01
    z[3,2,3]  R1012     -2.5568547844886780e-01
    z[3,2,3]  R1013     1.2257728725671768e-01
    z[3,2,3]  R1014     -2.2818391025066376e-01
    z[3,2,3]  R1015     -3.1830493360757828e-02
    z[3,2,3]  R1016     8.9937351644039154e-02
    z[3,2,3]  R1017     -1.0073759406805038e-01
    z[3,2,3]  R1018     1.3321955502033234e-01
    z[3,2,3]  R1019     6.0039076954126358e-02
    z[3,2,3]  R1020     -9.3716740608215332e-02
    z[3,2,3]  R1021     4.2428936809301376e-02
    z[3,2,3]  R1022     -3.1878617405891418e-01
    z[3,2,3]  R1023     -6.2994378805160522e-01
    z[3,2,3]  R1024     9.8014205694198608e-02
    z[3,2,3]  R1025     -1.7204432189464569e-01
    z[3,2,3]  R1026     -1.6432275995612144e-02
    z[3,2,3]  R1027     5.1976222544908524e-02
    z[3,2,3]  R1028     -1.6308794915676117e-01
    z[3,2,3]  R1029     2.9764357209205627e-01
    z[3,2,3]  R1030     -5.3639984130859375e-01
    z[3,2,3]  R1031     -1.9266603887081146e-01
    z[3,2,3]  R1032     0.067952461540699
    z[3,2,3]  R1033     -1.9458861649036407e-01
    z[3,2,3]  R1034     3.9981618523597717e-01
    z[3,2,3]  R1035     -5.7392424345016479e-01
    z[3,2,3]  R1036     1.0243978351354599e-01
    z[3,2,3]  R1037     -1.8930040299892426e-02
    z[3,2,3]  R1038     -3.2287371158599854e-01
    z[3,2,3]  R1039     -1.6707479953765869e-01
    z[3,2,3]  R1040     2.4766427278518677e-01
    z[3,2,3]  R1041     7.4058908224105835e-01
    z[3,2,3]  R1042     -2.1980394423007965e-01
    z[3,2,3]  R1043     1.7972676083445549e-02
    z[3,2,3]  R1044     -2.1149446070194244e-01
    z[3,2,3]  R1045     -6.3981473445892334e-02
    z[3,2,3]  R1046     1.6020385921001434e-01
    z[3,2,3]  R1047     -4.2409861087799072e-01
    z[3,2,3]  R1048     6.2967991828918457e-01
    z[3,2,3]  R1049     4.2992448806762695e-01
    z[3,2,3]  R1050     -3.1996479630470276e-01
    z[3,2,3]  R1051     -6.8285381793975830e-01
    z[3,2,3]  R1052     -4.3336641788482666e-01
    z[3,2,3]  R1053     -3.1596380472183228e-01
    z[3,2,3]  R1054     3.7232673168182373e-01
    z[3,2,3]  R1055     4.9252521991729736e-01
    z[3,2,3]  R1056     3.8690242171287537e-01
    z[3,2,3]  R1057     9.1316811740398407e-02
    z[3,2,3]  R1058     2.4188812077045441e-01
    z[3,2,3]  R1059     2.2152094542980194e-01
    z[3,2,3]  R1060     6.0156309604644775e-01
    z[3,2,3]  R1061     8.1735335290431976e-02
    z[3,2,3]  R1062     1.6186475753784180e-02
    z[3,2,3]  R1063     3.8005319237709045e-01
    z[3,2,3]  R1064     4.4550243020057678e-01
    z[3,2,3]  R1065     3.5873657464981079e-01
    z[3,2,3]  R1066     6.7233246564865112e-01
    z[3,2,3]  R1067     4.4264367222785950e-01
    z[3,2,3]  R1068     2.1618527173995972e-01
    z[3,2,3]  R1069     -0.0953526645898819
    z[3,2,3]  R1070     5.7371973991394043e-01
    z[3,2,3]  R1071     4.2816025018692017e-01
    z[3,2,3]  R1072     0.508263349533081
    z[3,2,3]  R1073     6.0387039184570312e-01
    z[3,2,3]  R1074     1.8024496734142303e-01
    z[3,2,3]  R1075     3.6991345882415771e-01
    z[3,2,3]  R1076     2.5764605402946472e-01
    z[3,2,3]  R1077     8.3447188138961792e-02
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R1002     -1
    z[3,2,4]  R1003     1
    z[3,2,4]  R1008     -1.5118260681629181e-01
    z[3,2,4]  R1009     -1.2110810726881027e-01
    z[3,2,4]  R1010     3.0696511268615723e-01
    z[3,2,4]  R1011     9.3824982643127441e-02
    z[3,2,4]  R1012     5.6252223253250122e-01
    z[3,2,4]  R1013     4.5384871959686279e-01
    z[3,2,4]  R1014     3.0659487843513489e-01
    z[3,2,4]  R1015     -2.3273593187332153e-01
    z[3,2,4]  R1016     -1.6773466765880585e-01
    z[3,2,4]  R1017     -1.9281828776001930e-02
    z[3,2,4]  R1018     -3.8209676742553711e-01
    z[3,2,4]  R1019     -6.9468045234680176e-01
    z[3,2,4]  R1020     -1.7974703013896942e-01
    z[3,2,4]  R1021     -2.7379241585731506e-01
    z[3,2,4]  R1022     -6.6507525742053986e-02
    z[3,2,4]  R1023     2.2297158837318420e-01
    z[3,2,4]  R1024     -2.7357056736946106e-01
    z[3,2,4]  R1025     2.1131275594234467e-01
    z[3,2,4]  R1026     -2.1221134066581726e-01
    z[3,2,4]  R1027     3.5109922289848328e-02
    z[3,2,4]  R1028     -0.242910698056221
    z[3,2,4]  R1029     -6.4958351850509644e-01
    z[3,2,4]  R1030     -8.3872549235820770e-02
    z[3,2,4]  R1031     2.5922521948814392e-01
    z[3,2,4]  R1032     5.6454139947891235e-01
    z[3,2,4]  R1033     7.3291277885437012e-01
    z[3,2,4]  R1034     1.1814720183610916e-01
    z[3,2,4]  R1035     2.6722148060798645e-01
    z[3,2,4]  R1036     3.0719587206840515e-01
    z[3,2,4]  R1037     -5.8366615325212479e-02
    z[3,2,4]  R1038     -2.9494842886924744e-01
    z[3,2,4]  R1039     -1.6150401532649994e-01
    z[3,2,4]  R1040     -1.4807645976543427e-01
    z[3,2,4]  R1041     1.3833388686180115e-01
    z[3,2,4]  R1042     -1.4137434959411621e-01
    z[3,2,4]  R1043     8.2156389951705933e-02
    z[3,2,4]  R1044     2.8801393508911133e-01
    z[3,2,4]  R1045     4.7589689493179321e-01
    z[3,2,4]  R1046     3.6816483736038208e-01
    z[3,2,4]  R1047     1.2181729823350906e-01
    z[3,2,4]  R1048     1.3164044916629791e-01
    z[3,2,4]  R1049     2.1666148304939270e-01
    z[3,2,4]  R1050     0.144708052277565
    z[3,2,4]  R1051     4.3102821707725525e-01
    z[3,2,4]  R1052     -7.0655143260955811e-01
    z[3,2,4]  R1053     -1.3440373539924622e-01
    z[3,2,4]  R1054     -4.0865597128868103e-01
    z[3,2,4]  R1055     3.2016980648040771e-01
    z[3,2,4]  R1056     -1.4649938791990280e-02
    z[3,2,4]  R1057     1.4581990242004395e-01
    z[3,2,4]  R1058     -1.7378675937652588e-01
    z[3,2,4]  R1059     0.144618958234787
    z[3,2,4]  R1060     -8.2724452018737793e-02
    z[3,2,4]  R1061     2.6303216814994812e-01
    z[3,2,4]  R1062     -1.1931933462619781e-01
    z[3,2,4]  R1063     3.5996192693710327e-01
    z[3,2,4]  R1064     9.8586179316043854e-02
    z[3,2,4]  R1065     7.0899382233619690e-02
    z[3,2,4]  R1066     0.139943465590477
    z[3,2,4]  R1067     2.8142226859927177e-02
    z[3,2,4]  R1068     -4.9839276075363159e-01
    z[3,2,4]  R1069     2.7118235826492310e-01
    z[3,2,4]  R1070     -1.1143181473016739e-02
    z[3,2,4]  R1071     -2.5423717498779297e-01
    z[3,2,4]  R1072     -3.1971356272697449e-01
    z[3,2,4]  R1073     -1.6451187431812286e-01
    z[3,2,4]  R1074     4.0888965129852295e-02
    z[3,2,4]  R1075     -0.165586456656456
    z[3,2,4]  R1076     3.2327935099601746e-01
    z[3,2,4]  R1077     -2.5632831454277039e-01
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R1004     -1
    z[3,2,5]  R1005     1
    z[3,2,5]  R1008     1.4710752665996552e-01
    z[3,2,5]  R1009     5.5916242301464081e-02
    z[3,2,5]  R1010     -4.3696433305740356e-01
    z[3,2,5]  R1011     1.7973285913467407e-01
    z[3,2,5]  R1012     5.2761003375053406e-02
    z[3,2,5]  R1013     -4.1906601190567017e-01
    z[3,2,5]  R1014     -2.1328464150428772e-01
    z[3,2,5]  R1015     -3.1065386533737183e-01
    z[3,2,5]  R1016     -3.6468520760536194e-02
    z[3,2,5]  R1017     2.5497859343886375e-02
    z[3,2,5]  R1018     4.7373014688491821e-01
    z[3,2,5]  R1019     3.4413686394691467e-01
    z[3,2,5]  R1020     1.0588242113590240e-01
    z[3,2,5]  R1021     -5.6741183996200562e-01
    z[3,2,5]  R1022     -1.9991537928581238e-01
    z[3,2,5]  R1023     4.0387919545173645e-01
    z[3,2,5]  R1024     4.9634307622909546e-01
    z[3,2,5]  R1025     -3.8713118433952332e-01
    z[3,2,5]  R1026     6.3142009079456329e-02
    z[3,2,5]  R1027     -3.2969031017273664e-03
    z[3,2,5]  R1028     3.0698272585868835e-01
    z[3,2,5]  R1029     -1.0310070216655731e-01
    z[3,2,5]  R1030     4.5047125220298767e-01
    z[3,2,5]  R1031     6.7605400085449219e-01
    z[3,2,5]  R1032     1.3374383747577667e-01
    z[3,2,5]  R1033     3.3290737867355347e-01
    z[3,2,5]  R1034     -0.0471990704536438
    z[3,2,5]  R1035     -2.4472513794898987e-01
    z[3,2,5]  R1036     -2.2847951948642731e-01
    z[3,2,5]  R1037     1.9362162053585052e-01
    z[3,2,5]  R1038     1.2813235819339752e-01
    z[3,2,5]  R1039     -2.9364410042762756e-01
    z[3,2,5]  R1040     3.1093168258666992e-01
    z[3,2,5]  R1041     2.8522640466690063e-01
    z[3,2,5]  R1042     -2.9728201031684875e-01
    z[3,2,5]  R1043     -3.9887115359306335e-01
    z[3,2,5]  R1044     -1.6919489204883575e-01
    z[3,2,5]  R1045     -2.6922725141048431e-02
    z[3,2,5]  R1046     -1.3203187286853790e-01
    z[3,2,5]  R1047     -1.9959259033203125e-01
    z[3,2,5]  R1048     4.1973805427551270e-01
    z[3,2,5]  R1049     4.1488382220268250e-01
    z[3,2,5]  R1050     -4.5210793614387512e-01
    z[3,2,5]  R1051     -1.6175678372383118e-01
    z[3,2,5]  R1052     -2.9067766666412354e-01
    z[3,2,5]  R1053     3.1963995099067688e-01
    z[3,2,5]  R1054     4.1255286335945129e-01
    z[3,2,5]  R1055     0.0674590989947319
    z[3,2,5]  R1056     -3.3464255928993225e-01
    z[3,2,5]  R1057     -9.9096536636352539e-02
    z[3,2,5]  R1058     -6.7073583602905273e-01
    z[3,2,5]  R1059     1.1968901753425598e-01
    z[3,2,5]  R1060     2.2094377782195807e-03
    z[3,2,5]  R1061     -2.8939110040664673e-01
    z[3,2,5]  R1062     3.8329422473907471e-01
    z[3,2,5]  R1063     9.4530224800109863e-02
    z[3,2,5]  R1064     2.8302699327468872e-01
    z[3,2,5]  R1065     1.8131180107593536e-01
    z[3,2,5]  R1066     -3.8422411680221558e-01
    z[3,2,5]  R1067     -2.2456111386418343e-02
    z[3,2,5]  R1068     -1.0661100596189499e-01
    z[3,2,5]  R1069     3.2412678003311157e-01
    z[3,2,5]  R1070     2.5091582536697388e-01
    z[3,2,5]  R1071     1.4982797205448151e-01
    z[3,2,5]  R1072     0.229428231716156
    z[3,2,5]  R1073     -0.286403626203537
    z[3,2,5]  R1074     -2.8573716059327126e-02
    z[3,2,5]  R1075     -2.8184045106172562e-02
    z[3,2,5]  R1076     -2.0938961207866669e-01
    z[3,2,5]  R1077     -8.0055460333824158e-02
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R1006     -1
    z[3,2,6]  R1007     1
    z[3,2,6]  R1008     1.7206548154354095e-01
    z[3,2,6]  R1009     -2.2013604640960693e-01
    z[3,2,6]  R1010     -4.1592967510223389e-01
    z[3,2,6]  R1011     3.1965491175651550e-01
    z[3,2,6]  R1012     -7.8862540423870087e-02
    z[3,2,6]  R1013     4.4223007559776306e-01
    z[3,2,6]  R1014     1.3842076063156128e-01
    z[3,2,6]  R1015     8.0339181423187256e-01
    z[3,2,6]  R1016     -4.7521837055683136e-02
    z[3,2,6]  R1017     1.2020229548215866e-01
    z[3,2,6]  R1018     -5.0076227635145187e-02
    z[3,2,6]  R1019     -2.4653879925608635e-02
    z[3,2,6]  R1020     5.5876958370208740e-01
    z[3,2,6]  R1021     3.0013734102249146e-01
    z[3,2,6]  R1022     1.0981138795614243e-01
    z[3,2,6]  R1023     -2.3106880486011505e-01
    z[3,2,6]  R1024     -5.8837193250656128e-01
    z[3,2,6]  R1025     -2.6153776049613953e-01
    z[3,2,6]  R1026     -5.8548414707183838e-01
    z[3,2,6]  R1027     -1.6975912451744080e-01
    z[3,2,6]  R1028     -3.8777709007263184e-01
    z[3,2,6]  R1029     4.2124241590499878e-01
    z[3,2,6]  R1030     2.3847469687461853e-01
    z[3,2,6]  R1031     1.8114395439624786e-01
    z[3,2,6]  R1032     3.6959323287010193e-01
    z[3,2,6]  R1033     -1.0266353935003281e-01
    z[3,2,6]  R1034     -2.7397081255912781e-01
    z[3,2,6]  R1035     2.3994588851928711e-01
    z[3,2,6]  R1036     6.2200784683227539e-01
    z[3,2,6]  R1037     9.7674198448657990e-02
    z[3,2,6]  R1038     -4.7831791453063488e-03
    z[3,2,6]  R1039     3.0158025026321411e-01
    z[3,2,6]  R1040     3.1003820896148682e-01
    z[3,2,6]  R1041     1.0133621096611023e-01
    z[3,2,6]  R1042     1.4268645644187927e-01
    z[3,2,6]  R1043     2.1593706309795380e-01
    z[3,2,6]  R1044     -3.2391491532325745e-01
    z[3,2,6]  R1045     -2.4074141681194305e-01
    z[3,2,6]  R1046     -2.4229244887828827e-01
    z[3,2,6]  R1047     1.2261576205492020e-01
    z[3,2,6]  R1048     -2.6838135719299316e-01
    z[3,2,6]  R1049     4.5631670951843262e-01
    z[3,2,6]  R1050     -5.4356628656387329e-01
    z[3,2,6]  R1051     1.0432038456201553e-01
    z[3,2,6]  R1052     -1.9684359431266785e-01
    z[3,2,6]  R1053     3.0178797245025635e-01
    z[3,2,6]  R1054     3.0108574777841568e-02
    z[3,2,6]  R1055     -1.9585911929607391e-01
    z[3,2,6]  R1056     -2.2083434462547302e-01
    z[3,2,6]  R1057     2.7107185125350952e-01
    z[3,2,6]  R1058     3.4475368261337280e-01
    z[3,2,6]  R1059     -4.9483355879783630e-01
    z[3,2,6]  R1060     2.5845885276794434e-01
    z[3,2,6]  R1061     -3.2266917824745178e-01
    z[3,2,6]  R1062     -1.7056754231452942e-01
    z[3,2,6]  R1063     2.3213557898998260e-01
    z[3,2,6]  R1064     0.352476567029953
    z[3,2,6]  R1065     9.2968977987766266e-02
    z[3,2,6]  R1066     0.0307808555662632
    z[3,2,6]  R1067     -9.6563078463077545e-02
    z[3,2,6]  R1068     5.5231606960296631e-01
    z[3,2,6]  R1069     1.6284777224063873e-01
    z[3,2,6]  R1070     1.7968676984310150e-02
    z[3,2,6]  R1071     -2.3643250763416290e-01
    z[3,2,6]  R1072     -1.2930619716644287e-01
    z[3,2,6]  R1073     1.9165965914726257e-01
    z[3,2,6]  R1074     3.9800401777029037e-02
    z[3,2,6]  R1075     -2.1013411879539490e-01
    z[3,2,6]  R1076     -1.3097006082534790e-01
    z[3,2,6]  R1077     -8.3338119089603424e-02
    z[2,7,0]  R20       -1
    z[2,7,0]  R65       1
    z[2,7,0]  R1078     -1
    z[2,7,0]  R1079     1
    z[2,7,0]  R1092     4.1082128882408142e-01
    z[2,7,0]  R1093     2.3075322806835175e-01
    z[2,7,0]  R1094     3.0020439624786377e-01
    z[2,7,0]  R1095     3.1325316429138184e-01
    z[2,7,0]  R1096     7.0484243333339691e-02
    z[2,7,0]  R1097     -8.2420426607131958e-01
    z[2,7,0]  R1098     -1.9736020267009735e-01
    z[2,7,0]  R1099     -2.5785785913467407e-01
    z[2,7,0]  R1100     -3.7281751632690430e-01
    z[2,7,0]  R1101     3.5973957180976868e-01
    z[2,7,0]  R1102     -2.0364120602607727e-01
    z[2,7,0]  R1103     -7.1394693851470947e-01
    z[2,7,0]  R1104     -3.3235621452331543e-01
    z[2,7,0]  R1105     -8.0002641677856445e-01
    z[2,7,0]  R1106     -5.6969982385635376e-01
    z[2,7,0]  R1107     1.5661850571632385e-01
    z[2,7,0]  R1108     -3.7715968489646912e-01
    z[2,7,0]  R1109     2.8012451529502869e-01
    z[2,7,0]  R1110     6.4431659877300262e-02
    z[2,7,0]  R1111     1.2779888510704041e-01
    z[2,7,0]  R1112     -9.8439827561378479e-02
    z[2,7,0]  R1113     -8.0734395980834961e-01
    z[2,7,0]  R1114     -3.7942594289779663e-01
    z[2,7,0]  R1115     1.3505963981151581e-01
    z[2,7,0]  R1116     -2.6683938503265381e-01
    z[2,7,0]  R1117     9.1274734586477280e-03
    z[2,7,0]  R1118     -2.8737941384315491e-01
    z[2,7,0]  R1119     2.9615676403045654e-01
    z[2,7,0]  R1120     3.5876259207725525e-02
    z[2,7,0]  R1121     -6.0228276997804642e-02
    z[2,7,0]  R1122     6.2022256851196289e-01
    z[2,7,0]  R1123     6.1659902334213257e-01
    z[2,7,0]  R1124     2.9703339934349060e-01
    z[2,7,0]  R1125     5.4968541860580444e-01
    z[2,7,0]  R1126     6.3667088747024536e-01
    z[2,7,0]  R1127     0.882612943649292
    z[2,7,0]  R1128     -1.4130641520023346e-01
    z[2,7,0]  R1129     8.2938581705093384e-01
    z[2,7,0]  R1130     7.5897300243377686e-01
    z[2,7,0]  R1131     4.2012134194374084e-01
    z[2,7,0]  R1132     -4.9780672788619995e-01
    z[2,7,0]  R1133     -0.572464108467102
    z[2,7,0]  R1134     -4.3742641806602478e-01
    z[2,7,0]  R1135     -3.2142275571823120e-01
    z[2,7,0]  R1136     -1.9069717824459076e-01
    z[2,7,0]  R1137     -3.6926296353340149e-01
    z[2,7,0]  R1138     -2.0503515005111694e-01
    z[2,7,0]  R1139     -0.310046523809433
    z[2,7,0]  R1140     -4.1690936684608459e-01
    z[2,7,0]  R1141     -3.7215346097946167e-01
    z[2,7,0]  R1142     -3.3932819962501526e-01
    z[2,7,0]  R1143     -3.5454162955284119e-01
    z[2,7,0]  R1144     -4.4399699568748474e-01
    z[2,7,0]  R1145     -2.4433828890323639e-01
    z[2,7,0]  R1146     -3.5885170102119446e-01
    z[2,7,0]  R1147     -3.3633485436439514e-01
    z[2,7,0]  R1148     -2.3008981347084045e-01
    z[2,7,0]  R1149     -7.2591103613376617e-02
    z[2,7,0]  R1150     -1.1461601406335831e-01
    z[2,7,0]  R1151     -4.6189066767692566e-01
    z[2,7,0]  R1152     7.5222015380859375e-01
    z[2,7,0]  R1153     -1.1398845165967941e-01
    z[2,7,0]  R1154     9.3784838914871216e-02
    z[2,7,0]  R1155     -2.6202374696731567e-01
    z[2,7,0]  R1156     5.2261631935834885e-02
    z[2,7,0]  R1157     -6.1903566122055054e-02
    z[2,7,0]  R1158     -4.6527091413736343e-02
    z[2,7,0]  R1159     -3.9346495270729065e-01
    z[2,7,0]  R1160     -2.1216526627540588e-01
    z[2,7,0]  R1161     -0.501543402671814
    z[2,7,0]  R1162     -4.9204930663108826e-02
    z[2,7,0]  R1163     -1.2464704364538193e-01
    z[2,7,0]  R1164     2.2177331149578094e-01
    z[2,7,0]  R1165     -4.3282747268676758e-02
    z[2,7,0]  R1166     -3.5235892981290817e-02
    z[2,7,0]  R1167     2.0288916304707527e-02
    z[2,7,0]  R1168     -2.7766540646553040e-01
    z[2,7,0]  R1169     -3.0240246653556824e-01
    z[2,7,0]  R1170     -2.4311359226703644e-01
    z[2,7,0]  R1171     2.4615408480167389e-01
    z[2,7,1]  R21       -1
    z[2,7,1]  R66       1
    z[2,7,1]  R1080     -1
    z[2,7,1]  R1081     1
    z[2,7,1]  R1092     4.1129791736602783e-01
    z[2,7,1]  R1093     4.2444208264350891e-01
    z[2,7,1]  R1094     5.1897394657135010e-01
    z[2,7,1]  R1095     4.0083104372024536e-01
    z[2,7,1]  R1096     3.3503478765487671e-01
    z[2,7,1]  R1097     -9.4895556569099426e-02
    z[2,7,1]  R1098     -6.8664211034774780e-01
    z[2,7,1]  R1099     -0.662268877029419
    z[2,7,1]  R1100     -7.2935426235198975e-01
    z[2,7,1]  R1101     -8.5722547769546509e-01
    z[2,7,1]  R1102     3.4180215001106262e-01
    z[2,7,1]  R1103     -7.9283893108367920e-02
    z[2,7,1]  R1104     -0.656761646270752
    z[2,7,1]  R1105     -8.5472755134105682e-02
    z[2,7,1]  R1106     -2.9222324490547180e-01
    z[2,7,1]  R1107     -0.798236072063446
    z[2,7,1]  R1108     -6.6360962390899658e-01
    z[2,7,1]  R1109     -0.776215136051178
    z[2,7,1]  R1110     -6.1289650201797485e-01
    z[2,7,1]  R1111     -7.3274105787277222e-01
    z[2,7,1]  R1112     1.6262401640415192e-01
    z[2,7,1]  R1113     -3.2446837425231934e-01
    z[2,7,1]  R1114     -6.4932662248611450e-01
    z[2,7,1]  R1115     -7.8822964429855347e-01
    z[2,7,1]  R1116     -6.6239368915557861e-01
    z[2,7,1]  R1117     -6.8379777669906616e-01
    z[2,7,1]  R1118     -9.2993378639221191e-01
    z[2,7,1]  R1119     -8.1093680858612061e-01
    z[2,7,1]  R1120     -8.6881810426712036e-01
    z[2,7,1]  R1121     -9.3162292242050171e-01
    z[2,7,1]  R1122     -5.7872150093317032e-02
    z[2,7,1]  R1123     -5.1282203197479248e-01
    z[2,7,1]  R1124     0.0262064840644598
    z[2,7,1]  R1125     3.6335122585296631e-01
    z[2,7,1]  R1126     -1.6931580007076263e-01
    z[2,7,1]  R1127     -0.329165518283844
    z[2,7,1]  R1128     -0.0679888054728508
    z[2,7,1]  R1129     -2.3425427079200745e-01
    z[2,7,1]  R1130     -2.3805886507034302e-01
    z[2,7,1]  R1131     -4.3429568409919739e-01
    z[2,7,1]  R1132     -8.1585150957107544e-01
    z[2,7,1]  R1133     -0.80653977394104
    z[2,7,1]  R1134     -7.6596271991729736e-01
    z[2,7,1]  R1135     -7.6712471246719360e-01
    z[2,7,1]  R1136     -7.3575627803802490e-01
    z[2,7,1]  R1137     -6.4961183071136475e-01
    z[2,7,1]  R1138     -7.3032897710800171e-01
    z[2,7,1]  R1139     -6.7524188756942749e-01
    z[2,7,1]  R1140     -6.3695675134658813e-01
    z[2,7,1]  R1141     -7.0628565549850464e-01
    z[2,7,1]  R1142     8.0494111776351929e-01
    z[2,7,1]  R1143     7.4577414989471436e-01
    z[2,7,1]  R1144     6.8204289674758911e-01
    z[2,7,1]  R1145     8.3312731981277466e-01
    z[2,7,1]  R1146     0.872372567653656
    z[2,7,1]  R1147     0.892861545085907
    z[2,7,1]  R1148     8.3846324682235718e-01
    z[2,7,1]  R1149     8.3353638648986816e-01
    z[2,7,1]  R1150     8.3021491765975952e-01
    z[2,7,1]  R1151     8.0449211597442627e-01
    z[2,7,1]  R1152     1.4912796206772327e-02
    z[2,7,1]  R1153     -1.4350967109203339e-01
    z[2,7,1]  R1154     0.515442430973053
    z[2,7,1]  R1155     -7.1135634183883667e-01
    z[2,7,1]  R1156     7.3089694976806641e-01
    z[2,7,1]  R1157     7.0023673772811890e-01
    z[2,7,1]  R1158     7.3360109329223633e-01
    z[2,7,1]  R1159     3.8575199246406555e-01
    z[2,7,1]  R1160     6.1126559972763062e-01
    z[2,7,1]  R1161     3.4472337365150452e-01
    z[2,7,1]  R1162     -8.0631360411643982e-02
    z[2,7,1]  R1163     2.0715110003948212e-01
    z[2,7,1]  R1164     7.0760160684585571e-01
    z[2,7,1]  R1165     8.5351544618606567e-01
    z[2,7,1]  R1166     -7.6736605167388916e-01
    z[2,7,1]  R1167     -7.7822124958038330e-01
    z[2,7,1]  R1168     4.3269225955009460e-01
    z[2,7,1]  R1169     2.9408836364746094e-01
    z[2,7,1]  R1170     4.7195664048194885e-01
    z[2,7,1]  R1171     6.2477678060531616e-01
    z[2,7,2]  R22       -1
    z[2,7,2]  R67       1
    z[2,7,2]  R1082     -1
    z[2,7,2]  R1083     1
    z[2,7,2]  R1092     -5.0281691364943981e-03
    z[2,7,2]  R1093     3.9302808046340942e-01
    z[2,7,2]  R1094     1.3175579905509949e-01
    z[2,7,2]  R1095     2.2822003066539764e-01
    z[2,7,2]  R1096     2.6929777860641479e-01
    z[2,7,2]  R1097     -2.3216364905238152e-02
    z[2,7,2]  R1098     1.1330621689558029e-01
    z[2,7,2]  R1099     3.2696780562400818e-01
    z[2,7,2]  R1100     1.3560181856155396e-01
    z[2,7,2]  R1101     1.5116095542907715e-01
    z[2,7,2]  R1102     -4.2924135923385620e-01
    z[2,7,2]  R1103     3.9347419142723083e-01
    z[2,7,2]  R1104     1.5058565139770508e-01
    z[2,7,2]  R1105     2.9819962382316589e-01
    z[2,7,2]  R1106     0.632092297077179
    z[2,7,2]  R1107     3.8131404668092728e-02
    z[2,7,2]  R1108     -6.9550216197967529e-02
    z[2,7,2]  R1109     -3.7918922305107117e-01
    z[2,7,2]  R1110     3.9668749086558819e-03
    z[2,7,2]  R1111     -4.9010598659515381e-01
    z[2,7,2]  R1112     -5.9355926513671875e-01
    z[2,7,2]  R1113     1.6943012177944183e-01
    z[2,7,2]  R1114     -2.0457480847835541e-01
    z[2,7,2]  R1115     -1.8478755652904510e-01
    z[2,7,2]  R1116     -2.4520482122898102e-01
    z[2,7,2]  R1117     1.4782798290252686e-01
    z[2,7,2]  R1118     1.2678916752338409e-01
    z[2,7,2]  R1119     2.1323013305664062e-01
    z[2,7,2]  R1120     -1.0945250838994980e-01
    z[2,7,2]  R1121     -2.0598389208316803e-01
    z[2,7,2]  R1122     4.7265261411666870e-01
    z[2,7,2]  R1123     1.7059187591075897e-01
    z[2,7,2]  R1124     2.7126777172088623e-01
    z[2,7,2]  R1125     1.5518426895141602e-01
    z[2,7,2]  R1126     1.0871021449565887e-01
    z[2,7,2]  R1127     -6.2821321189403534e-02
    z[2,7,2]  R1128     6.1464405059814453e-01
    z[2,7,2]  R1129     -3.1405130028724670e-01
    z[2,7,2]  R1130     1.7545676231384277e-01
    z[2,7,2]  R1131     -8.9660741388797760e-02
    z[2,7,2]  R1132     8.6172811686992645e-02
    z[2,7,2]  R1133     -6.2457986176013947e-02
    z[2,7,2]  R1134     2.3516632616519928e-01
    z[2,7,2]  R1135     -7.1627877652645111e-02
    z[2,7,2]  R1136     2.6620075106620789e-02
    z[2,7,2]  R1137     2.4896752834320068e-01
    z[2,7,2]  R1138     7.0647731423377991e-02
    z[2,7,2]  R1139     -4.3897065520286560e-01
    z[2,7,2]  R1140     -2.5264355540275574e-01
    z[2,7,2]  R1141     -3.8364082574844360e-01
    z[2,7,2]  R1142     3.7506440281867981e-01
    z[2,7,2]  R1143     4.0297257900238037e-01
    z[2,7,2]  R1144     2.5528374314308167e-01
    z[2,7,2]  R1145     1.5336585044860840e-01
    z[2,7,2]  R1146     1.8986490368843079e-01
    z[2,7,2]  R1147     9.0302256867289543e-03
    z[2,7,2]  R1148     2.9375827312469482e-01
    z[2,7,2]  R1149     3.5538288950920105e-01
    z[2,7,2]  R1150     4.1185724735260010e-01
    z[2,7,2]  R1151     -7.0786923170089722e-02
    z[2,7,2]  R1152     -2.2646564990282059e-02
    z[2,7,2]  R1153     4.0609481930732727e-01
    z[2,7,2]  R1154     5.4534208774566650e-01
    z[2,7,2]  R1155     -2.2798979282379150e-01
    z[2,7,2]  R1156     -2.6518395543098450e-01
    z[2,7,2]  R1157     5.8104771375656128e-01
    z[2,7,2]  R1158     0.125529944896698
    z[2,7,2]  R1159     -1.5523053705692291e-01
    z[2,7,2]  R1160     -7.1677933447062969e-03
    z[2,7,2]  R1161     -1.0918294638395309e-01
    z[2,7,2]  R1162     0.0843895822763443
    z[2,7,2]  R1163     1.9237776100635529e-01
    z[2,7,2]  R1164     3.7106525897979736e-01
    z[2,7,2]  R1165     2.9694685339927673e-01
    z[2,7,2]  R1166     4.4253346323966980e-01
    z[2,7,2]  R1167     -2.8792685270309448e-01
    z[2,7,2]  R1168     7.1017062664031982e-01
    z[2,7,2]  R1169     -3.3727708458900452e-01
    z[2,7,2]  R1170     -3.5415071249008179e-01
    z[2,7,2]  R1171     -3.4223309159278870e-01
    z[2,7,3]  R23       -1
    z[2,7,3]  R68       1
    z[2,7,3]  R1084     -1
    z[2,7,3]  R1085     1
    z[2,7,3]  R1092     6.2967991828918457e-01
    z[2,7,3]  R1093     4.2992448806762695e-01
    z[2,7,3]  R1094     -3.1996479630470276e-01
    z[2,7,3]  R1095     -6.8285381793975830e-01
    z[2,7,3]  R1096     -4.3336641788482666e-01
    z[2,7,3]  R1097     -3.1596380472183228e-01
    z[2,7,3]  R1098     3.7232673168182373e-01
    z[2,7,3]  R1099     4.9252521991729736e-01
    z[2,7,3]  R1100     3.8690242171287537e-01
    z[2,7,3]  R1101     9.1316811740398407e-02
    z[2,7,3]  R1102     2.4188812077045441e-01
    z[2,7,3]  R1103     2.2152094542980194e-01
    z[2,7,3]  R1104     6.0156309604644775e-01
    z[2,7,3]  R1105     8.1735335290431976e-02
    z[2,7,3]  R1106     1.6186475753784180e-02
    z[2,7,3]  R1107     3.8005319237709045e-01
    z[2,7,3]  R1108     4.4550243020057678e-01
    z[2,7,3]  R1109     3.5873657464981079e-01
    z[2,7,3]  R1110     6.7233246564865112e-01
    z[2,7,3]  R1111     4.4264367222785950e-01
    z[2,7,3]  R1112     2.1618527173995972e-01
    z[2,7,3]  R1113     -0.0953526645898819
    z[2,7,3]  R1114     5.7371973991394043e-01
    z[2,7,3]  R1115     4.2816025018692017e-01
    z[2,7,3]  R1116     0.508263349533081
    z[2,7,3]  R1117     6.0387039184570312e-01
    z[2,7,3]  R1118     1.8024496734142303e-01
    z[2,7,3]  R1119     3.6991345882415771e-01
    z[2,7,3]  R1120     2.5764605402946472e-01
    z[2,7,3]  R1121     8.3447188138961792e-02
    z[2,7,3]  R1122     0.564596951007843
    z[2,7,3]  R1123     5.1371496915817261e-01
    z[2,7,3]  R1124     6.0861396789550781e-01
    z[2,7,3]  R1125     6.4744567871093750e-01
    z[2,7,3]  R1126     5.3467601537704468e-01
    z[2,7,3]  R1127     2.5986871123313904e-01
    z[2,7,3]  R1128     6.7782843112945557e-01
    z[2,7,3]  R1129     2.3131449520587921e-01
    z[2,7,3]  R1130     1.5036433935165405e-01
    z[2,7,3]  R1131     0.316175639629364
    z[2,7,3]  R1132     -1.6702687740325928e-01
    z[2,7,3]  R1133     -2.5385264307260513e-02
    z[2,7,3]  R1134     0.131901815533638
    z[2,7,3]  R1135     -4.6181580424308777e-01
    z[2,7,3]  R1136     -5.9974139928817749e-01
    z[2,7,3]  R1137     -1.7495591938495636e-01
    z[2,7,3]  R1138     -2.9178082942962646e-01
    z[2,7,3]  R1139     -2.7795532345771790e-01
    z[2,7,3]  R1140     -4.1714288294315338e-02
    z[2,7,3]  R1141     4.8548586666584015e-02
    z[2,7,3]  R1142     -1.4104346930980682e-01
    z[2,7,3]  R1143     -3.3874134533107281e-03
    z[2,7,3]  R1144     2.5828611850738525e-01
    z[2,7,3]  R1145     -1.5882736444473267e-01
    z[2,7,3]  R1146     -0.0272738728672266
    z[2,7,3]  R1147     -8.0274511128664017e-03
    z[2,7,3]  R1148     -1.7618638277053833e-01
    z[2,7,3]  R1149     3.0444784089922905e-02
    z[2,7,3]  R1150     -2.2624140977859497e-01
    z[2,7,3]  R1151     1.8799732625484467e-01
    z[2,7,3]  R1152     5.5978453159332275e-01
    z[2,7,3]  R1153     5.4143774509429932e-01
    z[2,7,3]  R1154     3.4446281194686890e-01
    z[2,7,3]  R1155     -4.4442677497863770e-01
    z[2,7,3]  R1156     4.7526496648788452e-01
    z[2,7,3]  R1157     2.1938085556030273e-01
    z[2,7,3]  R1158     5.9873424470424652e-03
    z[2,7,3]  R1159     5.9109628200531006e-01
    z[2,7,3]  R1160     2.5889626145362854e-01
    z[2,7,3]  R1161     7.3483932018280029e-01
    z[2,7,3]  R1162     9.8674345016479492e-01
    z[2,7,3]  R1163     9.4138717651367188e-01
    z[2,7,3]  R1164     4.4672787189483643e-01
    z[2,7,3]  R1165     1.3829560577869415e-01
    z[2,7,3]  R1166     -3.0289649963378906e-01
    z[2,7,3]  R1167     1.8216690421104431e-01
    z[2,7,3]  R1168     1.1730867624282837e-01
    z[2,7,3]  R1169     -7.7046173810958862e-01
    z[2,7,3]  R1170     -6.0686582326889038e-01
    z[2,7,3]  R1171     -6.3158321380615234e-01
    z[2,7,4]  R24       -1
    z[2,7,4]  R69       1
    z[2,7,4]  R1086     -1
    z[2,7,4]  R1087     1
    z[2,7,4]  R1092     1.3164044916629791e-01
    z[2,7,4]  R1093     2.1666148304939270e-01
    z[2,7,4]  R1094     0.144708052277565
    z[2,7,4]  R1095     4.3102821707725525e-01
    z[2,7,4]  R1096     -7.0655143260955811e-01
    z[2,7,4]  R1097     -1.3440373539924622e-01
    z[2,7,4]  R1098     -4.0865597128868103e-01
    z[2,7,4]  R1099     3.2016980648040771e-01
    z[2,7,4]  R1100     -1.4649938791990280e-02
    z[2,7,4]  R1101     1.4581990242004395e-01
    z[2,7,4]  R1102     -1.7378675937652588e-01
    z[2,7,4]  R1103     0.144618958234787
    z[2,7,4]  R1104     -8.2724452018737793e-02
    z[2,7,4]  R1105     2.6303216814994812e-01
    z[2,7,4]  R1106     -1.1931933462619781e-01
    z[2,7,4]  R1107     3.5996192693710327e-01
    z[2,7,4]  R1108     9.8586179316043854e-02
    z[2,7,4]  R1109     7.0899382233619690e-02
    z[2,7,4]  R1110     0.139943465590477
    z[2,7,4]  R1111     2.8142226859927177e-02
    z[2,7,4]  R1112     -4.9839276075363159e-01
    z[2,7,4]  R1113     2.7118235826492310e-01
    z[2,7,4]  R1114     -1.1143181473016739e-02
    z[2,7,4]  R1115     -2.5423717498779297e-01
    z[2,7,4]  R1116     -3.1971356272697449e-01
    z[2,7,4]  R1117     -1.6451187431812286e-01
    z[2,7,4]  R1118     4.0888965129852295e-02
    z[2,7,4]  R1119     -0.165586456656456
    z[2,7,4]  R1120     3.2327935099601746e-01
    z[2,7,4]  R1121     -2.5632831454277039e-01
    z[2,7,4]  R1122     2.0796653628349304e-01
    z[2,7,4]  R1123     -8.3512617275118828e-03
    z[2,7,4]  R1124     -3.1630811095237732e-01
    z[2,7,4]  R1125     2.0905961096286774e-01
    z[2,7,4]  R1126     -6.8013528361916542e-03
    z[2,7,4]  R1127     1.6189047694206238e-01
    z[2,7,4]  R1128     -1.0302327573299408e-01
    z[2,7,4]  R1129     -1.0839579254388809e-01
    z[2,7,4]  R1130     -1.7145258188247681e-01
    z[2,7,4]  R1131     1.2915735132992268e-02
    z[2,7,4]  R1132     -1.1437698453664780e-01
    z[2,7,4]  R1133     -9.7949914634227753e-02
    z[2,7,4]  R1134     2.2429913282394409e-01
    z[2,7,4]  R1135     1.3347357511520386e-01
    z[2,7,4]  R1136     1.7241925001144409e-01
    z[2,7,4]  R1137     2.1686582267284393e-01
    z[2,7,4]  R1138     2.4941425025463104e-01
    z[2,7,4]  R1139     -3.8916151970624924e-03
    z[2,7,4]  R1140     -8.5312649607658386e-02
    z[2,7,4]  R1141     8.5909456014633179e-02
    z[2,7,4]  R1142     1.0042832791805267e-01
    z[2,7,4]  R1143     8.7373502552509308e-02
    z[2,7,4]  R1144     -3.3058132976293564e-02
    z[2,7,4]  R1145     -1.4715763926506042e-01
    z[2,7,4]  R1146     8.5299901664257050e-02
    z[2,7,4]  R1147     -7.5718536972999573e-02
    z[2,7,4]  R1148     2.3704622685909271e-01
    z[2,7,4]  R1149     2.5284444913268089e-02
    z[2,7,4]  R1150     5.5912379175424576e-03
    z[2,7,4]  R1151     -2.6069596409797668e-01
    z[2,7,4]  R1152     -0.0194578655064106
    z[2,7,4]  R1153     -3.4772194921970367e-02
    z[2,7,4]  R1154     -2.1263534203171730e-02
    z[2,7,4]  R1155     1.5456782281398773e-01
    z[2,7,4]  R1156     -2.1729257702827454e-01
    z[2,7,4]  R1157     3.4007257223129272e-01
    z[2,7,4]  R1158     -3.5109040141105652e-01
    z[2,7,4]  R1159     -3.9541909098625183e-01
    z[2,7,4]  R1160     -6.8843239545822144e-01
    z[2,7,4]  R1161     -5.4593872278928757e-02
    z[2,7,4]  R1162     -5.5340502411127090e-02
    z[2,7,4]  R1163     -1.2876252643764019e-02
    z[2,7,4]  R1164     1.7861260101199150e-02
    z[2,7,4]  R1165     -1.6747438907623291e-01
    z[2,7,4]  R1166     3.1184649467468262e-01
    z[2,7,4]  R1167     4.8171025514602661e-01
    z[2,7,4]  R1168     4.5708559453487396e-02
    z[2,7,4]  R1169     2.9470726847648621e-01
    z[2,7,4]  R1170     1.7241300642490387e-01
    z[2,7,4]  R1171     -1.6473142430186272e-02
    z[2,7,5]  R25       -1
    z[2,7,5]  R70       1
    z[2,7,5]  R1088     -1
    z[2,7,5]  R1089     1
    z[2,7,5]  R1092     4.1973805427551270e-01
    z[2,7,5]  R1093     4.1488382220268250e-01
    z[2,7,5]  R1094     -4.5210793614387512e-01
    z[2,7,5]  R1095     -1.6175678372383118e-01
    z[2,7,5]  R1096     -2.9067766666412354e-01
    z[2,7,5]  R1097     3.1963995099067688e-01
    z[2,7,5]  R1098     4.1255286335945129e-01
    z[2,7,5]  R1099     0.0674590989947319
    z[2,7,5]  R1100     -3.3464255928993225e-01
    z[2,7,5]  R1101     -9.9096536636352539e-02
    z[2,7,5]  R1102     -6.7073583602905273e-01
    z[2,7,5]  R1103     1.1968901753425598e-01
    z[2,7,5]  R1104     2.2094377782195807e-03
    z[2,7,5]  R1105     -2.8939110040664673e-01
    z[2,7,5]  R1106     3.8329422473907471e-01
    z[2,7,5]  R1107     9.4530224800109863e-02
    z[2,7,5]  R1108     2.8302699327468872e-01
    z[2,7,5]  R1109     1.8131180107593536e-01
    z[2,7,5]  R1110     -3.8422411680221558e-01
    z[2,7,5]  R1111     -2.2456111386418343e-02
    z[2,7,5]  R1112     -1.0661100596189499e-01
    z[2,7,5]  R1113     3.2412678003311157e-01
    z[2,7,5]  R1114     2.5091582536697388e-01
    z[2,7,5]  R1115     1.4982797205448151e-01
    z[2,7,5]  R1116     0.229428231716156
    z[2,7,5]  R1117     -0.286403626203537
    z[2,7,5]  R1118     -2.8573716059327126e-02
    z[2,7,5]  R1119     -2.8184045106172562e-02
    z[2,7,5]  R1120     -2.0938961207866669e-01
    z[2,7,5]  R1121     -8.0055460333824158e-02
    z[2,7,5]  R1122     1.0952552407979965e-01
    z[2,7,5]  R1123     -3.2058542128652334e-03
    z[2,7,5]  R1124     4.8141273856163025e-01
    z[2,7,5]  R1125     -0.0998157262802124
    z[2,7,5]  R1126     -2.8701263666152954e-01
    z[2,7,5]  R1127     -4.3160140514373779e-02
    z[2,7,5]  R1128     1.8473663926124573e-01
    z[2,7,5]  R1129     2.9781460762023926e-01
    z[2,7,5]  R1130     3.5354730486869812e-01
    z[2,7,5]  R1131     5.2908492088317871e-01
    z[2,7,5]  R1132     1.3210134208202362e-01
    z[2,7,5]  R1133     0.0831405371427536
    z[2,7,5]  R1134     -2.7633768320083618e-01
    z[2,7,5]  R1135     -2.6825129985809326e-01
    z[2,7,5]  R1136     -1.6878819093108177e-02
    z[2,7,5]  R1137     -5.1529240608215332e-01
    z[2,7,5]  R1138     -5.1640772819519043e-01
    z[2,7,5]  R1139     -4.1512230038642883e-01
    z[2,7,5]  R1140     -4.7670522332191467e-01
    z[2,7,5]  R1141     -4.1783046722412109e-01
    z[2,7,5]  R1142     1.6127510368824005e-01
    z[2,7,5]  R1143     2.6250478625297546e-01
    z[2,7,5]  R1144     3.3466845750808716e-01
    z[2,7,5]  R1145     4.1617873311042786e-01
    z[2,7,5]  R1146     1.8237130343914032e-01
    z[2,7,5]  R1147     2.0769244432449341e-01
    z[2,7,5]  R1148     0.0785713791847229
    z[2,7,5]  R1149     -2.3665902018547058e-01
    z[2,7,5]  R1150     -8.6512090638279915e-03
    z[2,7,5]  R1151     -1.6749377548694611e-01
    z[2,7,5]  R1152     3.0255937576293945e-01
    z[2,7,5]  R1153     6.2148499488830566e-01
    z[2,7,5]  R1154     -1.7706012725830078e-01
    z[2,7,5]  R1155     -2.0281611010432243e-02
    z[2,7,5]  R1156     2.8980734944343567e-01
    z[2,7,5]  R1157     -6.6166333854198456e-02
    z[2,7,5]  R1158     3.4562689065933228e-01
    z[2,7,5]  R1159     0.0786033347249031
    z[2,7,5]  R1160     -1.0985479503870010e-01
    z[2,7,5]  R1161     -2.1916307508945465e-01
    z[2,7,5]  R1162     -1.7077222466468811e-02
    z[2,7,5]  R1163     -1.3364957273006439e-01
    z[2,7,5]  R1164     -1.6446934640407562e-01
    z[2,7,5]  R1165     3.2586103677749634e-01
    z[2,7,5]  R1166     -1.9349161535501480e-02
    z[2,7,5]  R1167     -2.0564547181129456e-01
    z[2,7,5]  R1168     4.5173144340515137e-01
    z[2,7,5]  R1169     1.2901437282562256e-01
    z[2,7,5]  R1170     -2.5292432308197021e-01
    z[2,7,5]  R1171     -1.4887933433055878e-01
    z[2,7,6]  R26       -1
    z[2,7,6]  R71       1
    z[2,7,6]  R1090     -1
    z[2,7,6]  R1091     1
    z[2,7,6]  R1092     -2.6838135719299316e-01
    z[2,7,6]  R1093     4.5631670951843262e-01
    z[2,7,6]  R1094     -5.4356628656387329e-01
    z[2,7,6]  R1095     1.0432038456201553e-01
    z[2,7,6]  R1096     -1.9684359431266785e-01
    z[2,7,6]  R1097     3.0178797245025635e-01
    z[2,7,6]  R1098     3.0108574777841568e-02
    z[2,7,6]  R1099     -1.9585911929607391e-01
    z[2,7,6]  R1100     -2.2083434462547302e-01
    z[2,7,6]  R1101     2.7107185125350952e-01
    z[2,7,6]  R1102     3.4475368261337280e-01
    z[2,7,6]  R1103     -4.9483355879783630e-01
    z[2,7,6]  R1104     2.5845885276794434e-01
    z[2,7,6]  R1105     -3.2266917824745178e-01
    z[2,7,6]  R1106     -1.7056754231452942e-01
    z[2,7,6]  R1107     2.3213557898998260e-01
    z[2,7,6]  R1108     0.352476567029953
    z[2,7,6]  R1109     9.2968977987766266e-02
    z[2,7,6]  R1110     0.0307808555662632
    z[2,7,6]  R1111     -9.6563078463077545e-02
    z[2,7,6]  R1112     5.5231606960296631e-01
    z[2,7,6]  R1113     1.6284777224063873e-01
    z[2,7,6]  R1114     1.7968676984310150e-02
    z[2,7,6]  R1115     -2.3643250763416290e-01
    z[2,7,6]  R1116     -1.2930619716644287e-01
    z[2,7,6]  R1117     1.9165965914726257e-01
    z[2,7,6]  R1118     3.9800401777029037e-02
    z[2,7,6]  R1119     -2.1013411879539490e-01
    z[2,7,6]  R1120     -1.3097006082534790e-01
    z[2,7,6]  R1121     -8.3338119089603424e-02
    z[2,7,6]  R1122     1.2065856903791428e-01
    z[2,7,6]  R1123     -2.5245729088783264e-01
    z[2,7,6]  R1124     -3.6780178546905518e-01
    z[2,7,6]  R1125     2.6245898008346558e-01
    z[2,7,6]  R1126     -0.431118905544281
    z[2,7,6]  R1127     1.1443287134170532e-01
    z[2,7,6]  R1128     -3.0566301941871643e-01
    z[2,7,6]  R1129     6.8310797214508057e-02
    z[2,7,6]  R1130     -3.9937660098075867e-01
    z[2,7,6]  R1131     4.9677121639251709e-01
    z[2,7,6]  R1132     -1.4393849670886993e-01
    z[2,7,6]  R1133     2.6950417086482048e-02
    z[2,7,6]  R1134     1.5028476715087891e-01
    z[2,7,6]  R1135     5.3693549707531929e-03
    z[2,7,6]  R1136     -1.7856544256210327e-01
    z[2,7,6]  R1137     -1.9104431569576263e-01
    z[2,7,6]  R1138     -0.0746225118637085
    z[2,7,6]  R1139     -7.4989609420299530e-02
    z[2,7,6]  R1140     -3.4695494174957275e-01
    z[2,7,6]  R1141     1.7652879655361176e-01
    z[2,7,6]  R1142     2.0065940916538239e-01
    z[2,7,6]  R1143     2.8138899803161621e-01
    z[2,7,6]  R1144     3.0447763204574585e-01
    z[2,7,6]  R1145     5.0895728170871735e-02
    z[2,7,6]  R1146     -1.8128305673599243e-01
    z[2,7,6]  R1147     2.0164723694324493e-01
    z[2,7,6]  R1148     -2.5364974141120911e-01
    z[2,7,6]  R1149     -3.4070074558258057e-01
    z[2,7,6]  R1150     -2.7692726254463196e-01
    z[2,7,6]  R1151     5.5489383637905121e-02
    z[2,7,6]  R1152     1.6778001189231873e-01
    z[2,7,6]  R1153     3.4769383072853088e-01
    z[2,7,6]  R1154     -5.2694267034530640e-01
    z[2,7,6]  R1155     3.8925391435623169e-01
    z[2,7,6]  R1156     1.8882460892200470e-01
    z[2,7,6]  R1157     -8.0523900687694550e-03
    z[2,7,6]  R1158     -4.4849586486816406e-01
    z[2,7,6]  R1159     4.0044292807579041e-01
    z[2,7,6]  R1160     -1.6809058189392090e-01
    z[2,7,6]  R1161     1.6339325904846191e-01
    z[2,7,6]  R1162     8.3301074802875519e-02
    z[2,7,6]  R1163     1.7445525154471397e-02
    z[2,7,6]  R1164     -2.9239067435264587e-01
    z[2,7,6]  R1165     -1.6763594746589661e-01
    z[2,7,6]  R1166     0.157171830534935
    z[2,7,6]  R1167     5.9484452009201050e-02
    z[2,7,6]  R1168     1.0688801854848862e-01
    z[2,7,6]  R1169     -1.0583240538835526e-01
    z[2,7,6]  R1170     3.6158952116966248e-01
    z[2,7,6]  R1171     -1.0297979414463043e-01
    z[7,2,0]  R20       1
    z[7,2,0]  R65       -1
    z[7,2,0]  R1172     -1
    z[7,2,0]  R1173     1
    z[7,2,0]  R1186     6.2022256851196289e-01
    z[7,2,0]  R1187     6.1659902334213257e-01
    z[7,2,0]  R1188     2.9703339934349060e-01
    z[7,2,0]  R1189     5.4968541860580444e-01
    z[7,2,0]  R1190     6.3667088747024536e-01
    z[7,2,0]  R1191     0.882612943649292
    z[7,2,0]  R1192     -1.4130641520023346e-01
    z[7,2,0]  R1193     8.2938581705093384e-01
    z[7,2,0]  R1194     7.5897300243377686e-01
    z[7,2,0]  R1195     4.2012134194374084e-01
    z[7,2,0]  R1196     -4.9780672788619995e-01
    z[7,2,0]  R1197     -0.572464108467102
    z[7,2,0]  R1198     -4.3742641806602478e-01
    z[7,2,0]  R1199     -3.2142275571823120e-01
    z[7,2,0]  R1200     -1.9069717824459076e-01
    z[7,2,0]  R1201     -3.6926296353340149e-01
    z[7,2,0]  R1202     -2.0503515005111694e-01
    z[7,2,0]  R1203     -0.310046523809433
    z[7,2,0]  R1204     -4.1690936684608459e-01
    z[7,2,0]  R1205     -3.7215346097946167e-01
    z[7,2,0]  R1206     -3.3932819962501526e-01
    z[7,2,0]  R1207     -3.5454162955284119e-01
    z[7,2,0]  R1208     -4.4399699568748474e-01
    z[7,2,0]  R1209     -2.4433828890323639e-01
    z[7,2,0]  R1210     -3.5885170102119446e-01
    z[7,2,0]  R1211     -3.3633485436439514e-01
    z[7,2,0]  R1212     -2.3008981347084045e-01
    z[7,2,0]  R1213     -7.2591103613376617e-02
    z[7,2,0]  R1214     -1.1461601406335831e-01
    z[7,2,0]  R1215     -4.6189066767692566e-01
    z[7,2,0]  R1216     7.5222015380859375e-01
    z[7,2,0]  R1217     -1.1398845165967941e-01
    z[7,2,0]  R1218     9.3784838914871216e-02
    z[7,2,0]  R1219     -2.6202374696731567e-01
    z[7,2,0]  R1220     5.2261631935834885e-02
    z[7,2,0]  R1221     -6.1903566122055054e-02
    z[7,2,0]  R1222     -4.6527091413736343e-02
    z[7,2,0]  R1223     -3.9346495270729065e-01
    z[7,2,0]  R1224     -2.1216526627540588e-01
    z[7,2,0]  R1225     -0.501543402671814
    z[7,2,0]  R1226     -4.9204930663108826e-02
    z[7,2,0]  R1227     -1.2464704364538193e-01
    z[7,2,0]  R1228     2.2177331149578094e-01
    z[7,2,0]  R1229     -4.3282747268676758e-02
    z[7,2,0]  R1230     -3.5235892981290817e-02
    z[7,2,0]  R1231     2.0288916304707527e-02
    z[7,2,0]  R1232     -2.7766540646553040e-01
    z[7,2,0]  R1233     -3.0240246653556824e-01
    z[7,2,0]  R1234     -2.4311359226703644e-01
    z[7,2,0]  R1235     2.4615408480167389e-01
    z[7,2,0]  R1236     4.1082128882408142e-01
    z[7,2,0]  R1237     2.3075322806835175e-01
    z[7,2,0]  R1238     3.0020439624786377e-01
    z[7,2,0]  R1239     3.1325316429138184e-01
    z[7,2,0]  R1240     7.0484243333339691e-02
    z[7,2,0]  R1241     -8.2420426607131958e-01
    z[7,2,0]  R1242     -1.9736020267009735e-01
    z[7,2,0]  R1243     -2.5785785913467407e-01
    z[7,2,0]  R1244     -3.7281751632690430e-01
    z[7,2,0]  R1245     3.5973957180976868e-01
    z[7,2,0]  R1246     -2.0364120602607727e-01
    z[7,2,0]  R1247     -7.1394693851470947e-01
    z[7,2,0]  R1248     -3.3235621452331543e-01
    z[7,2,0]  R1249     -8.0002641677856445e-01
    z[7,2,0]  R1250     -5.6969982385635376e-01
    z[7,2,0]  R1251     1.5661850571632385e-01
    z[7,2,0]  R1252     -3.7715968489646912e-01
    z[7,2,0]  R1253     2.8012451529502869e-01
    z[7,2,0]  R1254     6.4431659877300262e-02
    z[7,2,0]  R1255     1.2779888510704041e-01
    z[7,2,0]  R1256     -9.8439827561378479e-02
    z[7,2,0]  R1257     -8.0734395980834961e-01
    z[7,2,0]  R1258     -3.7942594289779663e-01
    z[7,2,0]  R1259     1.3505963981151581e-01
    z[7,2,0]  R1260     -2.6683938503265381e-01
    z[7,2,0]  R1261     9.1274734586477280e-03
    z[7,2,0]  R1262     -2.8737941384315491e-01
    z[7,2,0]  R1263     2.9615676403045654e-01
    z[7,2,0]  R1264     3.5876259207725525e-02
    z[7,2,0]  R1265     -6.0228276997804642e-02
    z[7,2,1]  R21       1
    z[7,2,1]  R66       -1
    z[7,2,1]  R1174     -1
    z[7,2,1]  R1175     1
    z[7,2,1]  R1186     -5.7872150093317032e-02
    z[7,2,1]  R1187     -5.1282203197479248e-01
    z[7,2,1]  R1188     0.0262064840644598
    z[7,2,1]  R1189     3.6335122585296631e-01
    z[7,2,1]  R1190     -1.6931580007076263e-01
    z[7,2,1]  R1191     -0.329165518283844
    z[7,2,1]  R1192     -0.0679888054728508
    z[7,2,1]  R1193     -2.3425427079200745e-01
    z[7,2,1]  R1194     -2.3805886507034302e-01
    z[7,2,1]  R1195     -4.3429568409919739e-01
    z[7,2,1]  R1196     -8.1585150957107544e-01
    z[7,2,1]  R1197     -0.80653977394104
    z[7,2,1]  R1198     -7.6596271991729736e-01
    z[7,2,1]  R1199     -7.6712471246719360e-01
    z[7,2,1]  R1200     -7.3575627803802490e-01
    z[7,2,1]  R1201     -6.4961183071136475e-01
    z[7,2,1]  R1202     -7.3032897710800171e-01
    z[7,2,1]  R1203     -6.7524188756942749e-01
    z[7,2,1]  R1204     -6.3695675134658813e-01
    z[7,2,1]  R1205     -7.0628565549850464e-01
    z[7,2,1]  R1206     8.0494111776351929e-01
    z[7,2,1]  R1207     7.4577414989471436e-01
    z[7,2,1]  R1208     6.8204289674758911e-01
    z[7,2,1]  R1209     8.3312731981277466e-01
    z[7,2,1]  R1210     0.872372567653656
    z[7,2,1]  R1211     0.892861545085907
    z[7,2,1]  R1212     8.3846324682235718e-01
    z[7,2,1]  R1213     8.3353638648986816e-01
    z[7,2,1]  R1214     8.3021491765975952e-01
    z[7,2,1]  R1215     8.0449211597442627e-01
    z[7,2,1]  R1216     1.4912796206772327e-02
    z[7,2,1]  R1217     -1.4350967109203339e-01
    z[7,2,1]  R1218     0.515442430973053
    z[7,2,1]  R1219     -7.1135634183883667e-01
    z[7,2,1]  R1220     7.3089694976806641e-01
    z[7,2,1]  R1221     7.0023673772811890e-01
    z[7,2,1]  R1222     7.3360109329223633e-01
    z[7,2,1]  R1223     3.8575199246406555e-01
    z[7,2,1]  R1224     6.1126559972763062e-01
    z[7,2,1]  R1225     3.4472337365150452e-01
    z[7,2,1]  R1226     -8.0631360411643982e-02
    z[7,2,1]  R1227     2.0715110003948212e-01
    z[7,2,1]  R1228     7.0760160684585571e-01
    z[7,2,1]  R1229     8.5351544618606567e-01
    z[7,2,1]  R1230     -7.6736605167388916e-01
    z[7,2,1]  R1231     -7.7822124958038330e-01
    z[7,2,1]  R1232     4.3269225955009460e-01
    z[7,2,1]  R1233     2.9408836364746094e-01
    z[7,2,1]  R1234     4.7195664048194885e-01
    z[7,2,1]  R1235     6.2477678060531616e-01
    z[7,2,1]  R1236     4.1129791736602783e-01
    z[7,2,1]  R1237     4.2444208264350891e-01
    z[7,2,1]  R1238     5.1897394657135010e-01
    z[7,2,1]  R1239     4.0083104372024536e-01
    z[7,2,1]  R1240     3.3503478765487671e-01
    z[7,2,1]  R1241     -9.4895556569099426e-02
    z[7,2,1]  R1242     -6.8664211034774780e-01
    z[7,2,1]  R1243     -0.662268877029419
    z[7,2,1]  R1244     -7.2935426235198975e-01
    z[7,2,1]  R1245     -8.5722547769546509e-01
    z[7,2,1]  R1246     3.4180215001106262e-01
    z[7,2,1]  R1247     -7.9283893108367920e-02
    z[7,2,1]  R1248     -0.656761646270752
    z[7,2,1]  R1249     -8.5472755134105682e-02
    z[7,2,1]  R1250     -2.9222324490547180e-01
    z[7,2,1]  R1251     -0.798236072063446
    z[7,2,1]  R1252     -6.6360962390899658e-01
    z[7,2,1]  R1253     -0.776215136051178
    z[7,2,1]  R1254     -6.1289650201797485e-01
    z[7,2,1]  R1255     -7.3274105787277222e-01
    z[7,2,1]  R1256     1.6262401640415192e-01
    z[7,2,1]  R1257     -3.2446837425231934e-01
    z[7,2,1]  R1258     -6.4932662248611450e-01
    z[7,2,1]  R1259     -7.8822964429855347e-01
    z[7,2,1]  R1260     -6.6239368915557861e-01
    z[7,2,1]  R1261     -6.8379777669906616e-01
    z[7,2,1]  R1262     -9.2993378639221191e-01
    z[7,2,1]  R1263     -8.1093680858612061e-01
    z[7,2,1]  R1264     -8.6881810426712036e-01
    z[7,2,1]  R1265     -9.3162292242050171e-01
    z[7,2,2]  R22       1
    z[7,2,2]  R67       -1
    z[7,2,2]  R1176     -1
    z[7,2,2]  R1177     1
    z[7,2,2]  R1186     4.7265261411666870e-01
    z[7,2,2]  R1187     1.7059187591075897e-01
    z[7,2,2]  R1188     2.7126777172088623e-01
    z[7,2,2]  R1189     1.5518426895141602e-01
    z[7,2,2]  R1190     1.0871021449565887e-01
    z[7,2,2]  R1191     -6.2821321189403534e-02
    z[7,2,2]  R1192     6.1464405059814453e-01
    z[7,2,2]  R1193     -3.1405130028724670e-01
    z[7,2,2]  R1194     1.7545676231384277e-01
    z[7,2,2]  R1195     -8.9660741388797760e-02
    z[7,2,2]  R1196     8.6172811686992645e-02
    z[7,2,2]  R1197     -6.2457986176013947e-02
    z[7,2,2]  R1198     2.3516632616519928e-01
    z[7,2,2]  R1199     -7.1627877652645111e-02
    z[7,2,2]  R1200     2.6620075106620789e-02
    z[7,2,2]  R1201     2.4896752834320068e-01
    z[7,2,2]  R1202     7.0647731423377991e-02
    z[7,2,2]  R1203     -4.3897065520286560e-01
    z[7,2,2]  R1204     -2.5264355540275574e-01
    z[7,2,2]  R1205     -3.8364082574844360e-01
    z[7,2,2]  R1206     3.7506440281867981e-01
    z[7,2,2]  R1207     4.0297257900238037e-01
    z[7,2,2]  R1208     2.5528374314308167e-01
    z[7,2,2]  R1209     1.5336585044860840e-01
    z[7,2,2]  R1210     1.8986490368843079e-01
    z[7,2,2]  R1211     9.0302256867289543e-03
    z[7,2,2]  R1212     2.9375827312469482e-01
    z[7,2,2]  R1213     3.5538288950920105e-01
    z[7,2,2]  R1214     4.1185724735260010e-01
    z[7,2,2]  R1215     -7.0786923170089722e-02
    z[7,2,2]  R1216     -2.2646564990282059e-02
    z[7,2,2]  R1217     4.0609481930732727e-01
    z[7,2,2]  R1218     5.4534208774566650e-01
    z[7,2,2]  R1219     -2.2798979282379150e-01
    z[7,2,2]  R1220     -2.6518395543098450e-01
    z[7,2,2]  R1221     5.8104771375656128e-01
    z[7,2,2]  R1222     0.125529944896698
    z[7,2,2]  R1223     -1.5523053705692291e-01
    z[7,2,2]  R1224     -7.1677933447062969e-03
    z[7,2,2]  R1225     -1.0918294638395309e-01
    z[7,2,2]  R1226     0.0843895822763443
    z[7,2,2]  R1227     1.9237776100635529e-01
    z[7,2,2]  R1228     3.7106525897979736e-01
    z[7,2,2]  R1229     2.9694685339927673e-01
    z[7,2,2]  R1230     4.4253346323966980e-01
    z[7,2,2]  R1231     -2.8792685270309448e-01
    z[7,2,2]  R1232     7.1017062664031982e-01
    z[7,2,2]  R1233     -3.3727708458900452e-01
    z[7,2,2]  R1234     -3.5415071249008179e-01
    z[7,2,2]  R1235     -3.4223309159278870e-01
    z[7,2,2]  R1236     -5.0281691364943981e-03
    z[7,2,2]  R1237     3.9302808046340942e-01
    z[7,2,2]  R1238     1.3175579905509949e-01
    z[7,2,2]  R1239     2.2822003066539764e-01
    z[7,2,2]  R1240     2.6929777860641479e-01
    z[7,2,2]  R1241     -2.3216364905238152e-02
    z[7,2,2]  R1242     1.1330621689558029e-01
    z[7,2,2]  R1243     3.2696780562400818e-01
    z[7,2,2]  R1244     1.3560181856155396e-01
    z[7,2,2]  R1245     1.5116095542907715e-01
    z[7,2,2]  R1246     -4.2924135923385620e-01
    z[7,2,2]  R1247     3.9347419142723083e-01
    z[7,2,2]  R1248     1.5058565139770508e-01
    z[7,2,2]  R1249     2.9819962382316589e-01
    z[7,2,2]  R1250     0.632092297077179
    z[7,2,2]  R1251     3.8131404668092728e-02
    z[7,2,2]  R1252     -6.9550216197967529e-02
    z[7,2,2]  R1253     -3.7918922305107117e-01
    z[7,2,2]  R1254     3.9668749086558819e-03
    z[7,2,2]  R1255     -4.9010598659515381e-01
    z[7,2,2]  R1256     -5.9355926513671875e-01
    z[7,2,2]  R1257     1.6943012177944183e-01
    z[7,2,2]  R1258     -2.0457480847835541e-01
    z[7,2,2]  R1259     -1.8478755652904510e-01
    z[7,2,2]  R1260     -2.4520482122898102e-01
    z[7,2,2]  R1261     1.4782798290252686e-01
    z[7,2,2]  R1262     1.2678916752338409e-01
    z[7,2,2]  R1263     2.1323013305664062e-01
    z[7,2,2]  R1264     -1.0945250838994980e-01
    z[7,2,2]  R1265     -2.0598389208316803e-01
    z[7,2,3]  R23       1
    z[7,2,3]  R68       -1
    z[7,2,3]  R1178     -1
    z[7,2,3]  R1179     1
    z[7,2,3]  R1186     0.564596951007843
    z[7,2,3]  R1187     5.1371496915817261e-01
    z[7,2,3]  R1188     6.0861396789550781e-01
    z[7,2,3]  R1189     6.4744567871093750e-01
    z[7,2,3]  R1190     5.3467601537704468e-01
    z[7,2,3]  R1191     2.5986871123313904e-01
    z[7,2,3]  R1192     6.7782843112945557e-01
    z[7,2,3]  R1193     2.3131449520587921e-01
    z[7,2,3]  R1194     1.5036433935165405e-01
    z[7,2,3]  R1195     0.316175639629364
    z[7,2,3]  R1196     -1.6702687740325928e-01
    z[7,2,3]  R1197     -2.5385264307260513e-02
    z[7,2,3]  R1198     0.131901815533638
    z[7,2,3]  R1199     -4.6181580424308777e-01
    z[7,2,3]  R1200     -5.9974139928817749e-01
    z[7,2,3]  R1201     -1.7495591938495636e-01
    z[7,2,3]  R1202     -2.9178082942962646e-01
    z[7,2,3]  R1203     -2.7795532345771790e-01
    z[7,2,3]  R1204     -4.1714288294315338e-02
    z[7,2,3]  R1205     4.8548586666584015e-02
    z[7,2,3]  R1206     -1.4104346930980682e-01
    z[7,2,3]  R1207     -3.3874134533107281e-03
    z[7,2,3]  R1208     2.5828611850738525e-01
    z[7,2,3]  R1209     -1.5882736444473267e-01
    z[7,2,3]  R1210     -0.0272738728672266
    z[7,2,3]  R1211     -8.0274511128664017e-03
    z[7,2,3]  R1212     -1.7618638277053833e-01
    z[7,2,3]  R1213     3.0444784089922905e-02
    z[7,2,3]  R1214     -2.2624140977859497e-01
    z[7,2,3]  R1215     1.8799732625484467e-01
    z[7,2,3]  R1216     5.5978453159332275e-01
    z[7,2,3]  R1217     5.4143774509429932e-01
    z[7,2,3]  R1218     3.4446281194686890e-01
    z[7,2,3]  R1219     -4.4442677497863770e-01
    z[7,2,3]  R1220     4.7526496648788452e-01
    z[7,2,3]  R1221     2.1938085556030273e-01
    z[7,2,3]  R1222     5.9873424470424652e-03
    z[7,2,3]  R1223     5.9109628200531006e-01
    z[7,2,3]  R1224     2.5889626145362854e-01
    z[7,2,3]  R1225     7.3483932018280029e-01
    z[7,2,3]  R1226     9.8674345016479492e-01
    z[7,2,3]  R1227     9.4138717651367188e-01
    z[7,2,3]  R1228     4.4672787189483643e-01
    z[7,2,3]  R1229     1.3829560577869415e-01
    z[7,2,3]  R1230     -3.0289649963378906e-01
    z[7,2,3]  R1231     1.8216690421104431e-01
    z[7,2,3]  R1232     1.1730867624282837e-01
    z[7,2,3]  R1233     -7.7046173810958862e-01
    z[7,2,3]  R1234     -6.0686582326889038e-01
    z[7,2,3]  R1235     -6.3158321380615234e-01
    z[7,2,3]  R1236     6.2967991828918457e-01
    z[7,2,3]  R1237     4.2992448806762695e-01
    z[7,2,3]  R1238     -3.1996479630470276e-01
    z[7,2,3]  R1239     -6.8285381793975830e-01
    z[7,2,3]  R1240     -4.3336641788482666e-01
    z[7,2,3]  R1241     -3.1596380472183228e-01
    z[7,2,3]  R1242     3.7232673168182373e-01
    z[7,2,3]  R1243     4.9252521991729736e-01
    z[7,2,3]  R1244     3.8690242171287537e-01
    z[7,2,3]  R1245     9.1316811740398407e-02
    z[7,2,3]  R1246     2.4188812077045441e-01
    z[7,2,3]  R1247     2.2152094542980194e-01
    z[7,2,3]  R1248     6.0156309604644775e-01
    z[7,2,3]  R1249     8.1735335290431976e-02
    z[7,2,3]  R1250     1.6186475753784180e-02
    z[7,2,3]  R1251     3.8005319237709045e-01
    z[7,2,3]  R1252     4.4550243020057678e-01
    z[7,2,3]  R1253     3.5873657464981079e-01
    z[7,2,3]  R1254     6.7233246564865112e-01
    z[7,2,3]  R1255     4.4264367222785950e-01
    z[7,2,3]  R1256     2.1618527173995972e-01
    z[7,2,3]  R1257     -0.0953526645898819
    z[7,2,3]  R1258     5.7371973991394043e-01
    z[7,2,3]  R1259     4.2816025018692017e-01
    z[7,2,3]  R1260     0.508263349533081
    z[7,2,3]  R1261     6.0387039184570312e-01
    z[7,2,3]  R1262     1.8024496734142303e-01
    z[7,2,3]  R1263     3.6991345882415771e-01
    z[7,2,3]  R1264     2.5764605402946472e-01
    z[7,2,3]  R1265     8.3447188138961792e-02
    z[7,2,4]  R24       1
    z[7,2,4]  R69       -1
    z[7,2,4]  R1180     -1
    z[7,2,4]  R1181     1
    z[7,2,4]  R1186     2.0796653628349304e-01
    z[7,2,4]  R1187     -8.3512617275118828e-03
    z[7,2,4]  R1188     -3.1630811095237732e-01
    z[7,2,4]  R1189     2.0905961096286774e-01
    z[7,2,4]  R1190     -6.8013528361916542e-03
    z[7,2,4]  R1191     1.6189047694206238e-01
    z[7,2,4]  R1192     -1.0302327573299408e-01
    z[7,2,4]  R1193     -1.0839579254388809e-01
    z[7,2,4]  R1194     -1.7145258188247681e-01
    z[7,2,4]  R1195     1.2915735132992268e-02
    z[7,2,4]  R1196     -1.1437698453664780e-01
    z[7,2,4]  R1197     -9.7949914634227753e-02
    z[7,2,4]  R1198     2.2429913282394409e-01
    z[7,2,4]  R1199     1.3347357511520386e-01
    z[7,2,4]  R1200     1.7241925001144409e-01
    z[7,2,4]  R1201     2.1686582267284393e-01
    z[7,2,4]  R1202     2.4941425025463104e-01
    z[7,2,4]  R1203     -3.8916151970624924e-03
    z[7,2,4]  R1204     -8.5312649607658386e-02
    z[7,2,4]  R1205     8.5909456014633179e-02
    z[7,2,4]  R1206     1.0042832791805267e-01
    z[7,2,4]  R1207     8.7373502552509308e-02
    z[7,2,4]  R1208     -3.3058132976293564e-02
    z[7,2,4]  R1209     -1.4715763926506042e-01
    z[7,2,4]  R1210     8.5299901664257050e-02
    z[7,2,4]  R1211     -7.5718536972999573e-02
    z[7,2,4]  R1212     2.3704622685909271e-01
    z[7,2,4]  R1213     2.5284444913268089e-02
    z[7,2,4]  R1214     5.5912379175424576e-03
    z[7,2,4]  R1215     -2.6069596409797668e-01
    z[7,2,4]  R1216     -0.0194578655064106
    z[7,2,4]  R1217     -3.4772194921970367e-02
    z[7,2,4]  R1218     -2.1263534203171730e-02
    z[7,2,4]  R1219     1.5456782281398773e-01
    z[7,2,4]  R1220     -2.1729257702827454e-01
    z[7,2,4]  R1221     3.4007257223129272e-01
    z[7,2,4]  R1222     -3.5109040141105652e-01
    z[7,2,4]  R1223     -3.9541909098625183e-01
    z[7,2,4]  R1224     -6.8843239545822144e-01
    z[7,2,4]  R1225     -5.4593872278928757e-02
    z[7,2,4]  R1226     -5.5340502411127090e-02
    z[7,2,4]  R1227     -1.2876252643764019e-02
    z[7,2,4]  R1228     1.7861260101199150e-02
    z[7,2,4]  R1229     -1.6747438907623291e-01
    z[7,2,4]  R1230     3.1184649467468262e-01
    z[7,2,4]  R1231     4.8171025514602661e-01
    z[7,2,4]  R1232     4.5708559453487396e-02
    z[7,2,4]  R1233     2.9470726847648621e-01
    z[7,2,4]  R1234     1.7241300642490387e-01
    z[7,2,4]  R1235     -1.6473142430186272e-02
    z[7,2,4]  R1236     1.3164044916629791e-01
    z[7,2,4]  R1237     2.1666148304939270e-01
    z[7,2,4]  R1238     0.144708052277565
    z[7,2,4]  R1239     4.3102821707725525e-01
    z[7,2,4]  R1240     -7.0655143260955811e-01
    z[7,2,4]  R1241     -1.3440373539924622e-01
    z[7,2,4]  R1242     -4.0865597128868103e-01
    z[7,2,4]  R1243     3.2016980648040771e-01
    z[7,2,4]  R1244     -1.4649938791990280e-02
    z[7,2,4]  R1245     1.4581990242004395e-01
    z[7,2,4]  R1246     -1.7378675937652588e-01
    z[7,2,4]  R1247     0.144618958234787
    z[7,2,4]  R1248     -8.2724452018737793e-02
    z[7,2,4]  R1249     2.6303216814994812e-01
    z[7,2,4]  R1250     -1.1931933462619781e-01
    z[7,2,4]  R1251     3.5996192693710327e-01
    z[7,2,4]  R1252     9.8586179316043854e-02
    z[7,2,4]  R1253     7.0899382233619690e-02
    z[7,2,4]  R1254     0.139943465590477
    z[7,2,4]  R1255     2.8142226859927177e-02
    z[7,2,4]  R1256     -4.9839276075363159e-01
    z[7,2,4]  R1257     2.7118235826492310e-01
    z[7,2,4]  R1258     -1.1143181473016739e-02
    z[7,2,4]  R1259     -2.5423717498779297e-01
    z[7,2,4]  R1260     -3.1971356272697449e-01
    z[7,2,4]  R1261     -1.6451187431812286e-01
    z[7,2,4]  R1262     4.0888965129852295e-02
    z[7,2,4]  R1263     -0.165586456656456
    z[7,2,4]  R1264     3.2327935099601746e-01
    z[7,2,4]  R1265     -2.5632831454277039e-01
    z[7,2,5]  R25       1
    z[7,2,5]  R70       -1
    z[7,2,5]  R1182     -1
    z[7,2,5]  R1183     1
    z[7,2,5]  R1186     1.0952552407979965e-01
    z[7,2,5]  R1187     -3.2058542128652334e-03
    z[7,2,5]  R1188     4.8141273856163025e-01
    z[7,2,5]  R1189     -0.0998157262802124
    z[7,2,5]  R1190     -2.8701263666152954e-01
    z[7,2,5]  R1191     -4.3160140514373779e-02
    z[7,2,5]  R1192     1.8473663926124573e-01
    z[7,2,5]  R1193     2.9781460762023926e-01
    z[7,2,5]  R1194     3.5354730486869812e-01
    z[7,2,5]  R1195     5.2908492088317871e-01
    z[7,2,5]  R1196     1.3210134208202362e-01
    z[7,2,5]  R1197     0.0831405371427536
    z[7,2,5]  R1198     -2.7633768320083618e-01
    z[7,2,5]  R1199     -2.6825129985809326e-01
    z[7,2,5]  R1200     -1.6878819093108177e-02
    z[7,2,5]  R1201     -5.1529240608215332e-01
    z[7,2,5]  R1202     -5.1640772819519043e-01
    z[7,2,5]  R1203     -4.1512230038642883e-01
    z[7,2,5]  R1204     -4.7670522332191467e-01
    z[7,2,5]  R1205     -4.1783046722412109e-01
    z[7,2,5]  R1206     1.6127510368824005e-01
    z[7,2,5]  R1207     2.6250478625297546e-01
    z[7,2,5]  R1208     3.3466845750808716e-01
    z[7,2,5]  R1209     4.1617873311042786e-01
    z[7,2,5]  R1210     1.8237130343914032e-01
    z[7,2,5]  R1211     2.0769244432449341e-01
    z[7,2,5]  R1212     0.0785713791847229
    z[7,2,5]  R1213     -2.3665902018547058e-01
    z[7,2,5]  R1214     -8.6512090638279915e-03
    z[7,2,5]  R1215     -1.6749377548694611e-01
    z[7,2,5]  R1216     3.0255937576293945e-01
    z[7,2,5]  R1217     6.2148499488830566e-01
    z[7,2,5]  R1218     -1.7706012725830078e-01
    z[7,2,5]  R1219     -2.0281611010432243e-02
    z[7,2,5]  R1220     2.8980734944343567e-01
    z[7,2,5]  R1221     -6.6166333854198456e-02
    z[7,2,5]  R1222     3.4562689065933228e-01
    z[7,2,5]  R1223     0.0786033347249031
    z[7,2,5]  R1224     -1.0985479503870010e-01
    z[7,2,5]  R1225     -2.1916307508945465e-01
    z[7,2,5]  R1226     -1.7077222466468811e-02
    z[7,2,5]  R1227     -1.3364957273006439e-01
    z[7,2,5]  R1228     -1.6446934640407562e-01
    z[7,2,5]  R1229     3.2586103677749634e-01
    z[7,2,5]  R1230     -1.9349161535501480e-02
    z[7,2,5]  R1231     -2.0564547181129456e-01
    z[7,2,5]  R1232     4.5173144340515137e-01
    z[7,2,5]  R1233     1.2901437282562256e-01
    z[7,2,5]  R1234     -2.5292432308197021e-01
    z[7,2,5]  R1235     -1.4887933433055878e-01
    z[7,2,5]  R1236     4.1973805427551270e-01
    z[7,2,5]  R1237     4.1488382220268250e-01
    z[7,2,5]  R1238     -4.5210793614387512e-01
    z[7,2,5]  R1239     -1.6175678372383118e-01
    z[7,2,5]  R1240     -2.9067766666412354e-01
    z[7,2,5]  R1241     3.1963995099067688e-01
    z[7,2,5]  R1242     4.1255286335945129e-01
    z[7,2,5]  R1243     0.0674590989947319
    z[7,2,5]  R1244     -3.3464255928993225e-01
    z[7,2,5]  R1245     -9.9096536636352539e-02
    z[7,2,5]  R1246     -6.7073583602905273e-01
    z[7,2,5]  R1247     1.1968901753425598e-01
    z[7,2,5]  R1248     2.2094377782195807e-03
    z[7,2,5]  R1249     -2.8939110040664673e-01
    z[7,2,5]  R1250     3.8329422473907471e-01
    z[7,2,5]  R1251     9.4530224800109863e-02
    z[7,2,5]  R1252     2.8302699327468872e-01
    z[7,2,5]  R1253     1.8131180107593536e-01
    z[7,2,5]  R1254     -3.8422411680221558e-01
    z[7,2,5]  R1255     -2.2456111386418343e-02
    z[7,2,5]  R1256     -1.0661100596189499e-01
    z[7,2,5]  R1257     3.2412678003311157e-01
    z[7,2,5]  R1258     2.5091582536697388e-01
    z[7,2,5]  R1259     1.4982797205448151e-01
    z[7,2,5]  R1260     0.229428231716156
    z[7,2,5]  R1261     -0.286403626203537
    z[7,2,5]  R1262     -2.8573716059327126e-02
    z[7,2,5]  R1263     -2.8184045106172562e-02
    z[7,2,5]  R1264     -2.0938961207866669e-01
    z[7,2,5]  R1265     -8.0055460333824158e-02
    z[7,2,6]  R26       1
    z[7,2,6]  R71       -1
    z[7,2,6]  R1184     -1
    z[7,2,6]  R1185     1
    z[7,2,6]  R1186     1.2065856903791428e-01
    z[7,2,6]  R1187     -2.5245729088783264e-01
    z[7,2,6]  R1188     -3.6780178546905518e-01
    z[7,2,6]  R1189     2.6245898008346558e-01
    z[7,2,6]  R1190     -0.431118905544281
    z[7,2,6]  R1191     1.1443287134170532e-01
    z[7,2,6]  R1192     -3.0566301941871643e-01
    z[7,2,6]  R1193     6.8310797214508057e-02
    z[7,2,6]  R1194     -3.9937660098075867e-01
    z[7,2,6]  R1195     4.9677121639251709e-01
    z[7,2,6]  R1196     -1.4393849670886993e-01
    z[7,2,6]  R1197     2.6950417086482048e-02
    z[7,2,6]  R1198     1.5028476715087891e-01
    z[7,2,6]  R1199     5.3693549707531929e-03
    z[7,2,6]  R1200     -1.7856544256210327e-01
    z[7,2,6]  R1201     -1.9104431569576263e-01
    z[7,2,6]  R1202     -0.0746225118637085
    z[7,2,6]  R1203     -7.4989609420299530e-02
    z[7,2,6]  R1204     -3.4695494174957275e-01
    z[7,2,6]  R1205     1.7652879655361176e-01
    z[7,2,6]  R1206     2.0065940916538239e-01
    z[7,2,6]  R1207     2.8138899803161621e-01
    z[7,2,6]  R1208     3.0447763204574585e-01
    z[7,2,6]  R1209     5.0895728170871735e-02
    z[7,2,6]  R1210     -1.8128305673599243e-01
    z[7,2,6]  R1211     2.0164723694324493e-01
    z[7,2,6]  R1212     -2.5364974141120911e-01
    z[7,2,6]  R1213     -3.4070074558258057e-01
    z[7,2,6]  R1214     -2.7692726254463196e-01
    z[7,2,6]  R1215     5.5489383637905121e-02
    z[7,2,6]  R1216     1.6778001189231873e-01
    z[7,2,6]  R1217     3.4769383072853088e-01
    z[7,2,6]  R1218     -5.2694267034530640e-01
    z[7,2,6]  R1219     3.8925391435623169e-01
    z[7,2,6]  R1220     1.8882460892200470e-01
    z[7,2,6]  R1221     -8.0523900687694550e-03
    z[7,2,6]  R1222     -4.4849586486816406e-01
    z[7,2,6]  R1223     4.0044292807579041e-01
    z[7,2,6]  R1224     -1.6809058189392090e-01
    z[7,2,6]  R1225     1.6339325904846191e-01
    z[7,2,6]  R1226     8.3301074802875519e-02
    z[7,2,6]  R1227     1.7445525154471397e-02
    z[7,2,6]  R1228     -2.9239067435264587e-01
    z[7,2,6]  R1229     -1.6763594746589661e-01
    z[7,2,6]  R1230     0.157171830534935
    z[7,2,6]  R1231     5.9484452009201050e-02
    z[7,2,6]  R1232     1.0688801854848862e-01
    z[7,2,6]  R1233     -1.0583240538835526e-01
    z[7,2,6]  R1234     3.6158952116966248e-01
    z[7,2,6]  R1235     -1.0297979414463043e-01
    z[7,2,6]  R1236     -2.6838135719299316e-01
    z[7,2,6]  R1237     4.5631670951843262e-01
    z[7,2,6]  R1238     -5.4356628656387329e-01
    z[7,2,6]  R1239     1.0432038456201553e-01
    z[7,2,6]  R1240     -1.9684359431266785e-01
    z[7,2,6]  R1241     3.0178797245025635e-01
    z[7,2,6]  R1242     3.0108574777841568e-02
    z[7,2,6]  R1243     -1.9585911929607391e-01
    z[7,2,6]  R1244     -2.2083434462547302e-01
    z[7,2,6]  R1245     2.7107185125350952e-01
    z[7,2,6]  R1246     3.4475368261337280e-01
    z[7,2,6]  R1247     -4.9483355879783630e-01
    z[7,2,6]  R1248     2.5845885276794434e-01
    z[7,2,6]  R1249     -3.2266917824745178e-01
    z[7,2,6]  R1250     -1.7056754231452942e-01
    z[7,2,6]  R1251     2.3213557898998260e-01
    z[7,2,6]  R1252     0.352476567029953
    z[7,2,6]  R1253     9.2968977987766266e-02
    z[7,2,6]  R1254     0.0307808555662632
    z[7,2,6]  R1255     -9.6563078463077545e-02
    z[7,2,6]  R1256     5.5231606960296631e-01
    z[7,2,6]  R1257     1.6284777224063873e-01
    z[7,2,6]  R1258     1.7968676984310150e-02
    z[7,2,6]  R1259     -2.3643250763416290e-01
    z[7,2,6]  R1260     -1.2930619716644287e-01
    z[7,2,6]  R1261     1.9165965914726257e-01
    z[7,2,6]  R1262     3.9800401777029037e-02
    z[7,2,6]  R1263     -2.1013411879539490e-01
    z[7,2,6]  R1264     -1.3097006082534790e-01
    z[7,2,6]  R1265     -8.3338119089603424e-02
    z[3,8,0]  R29       -1
    z[3,8,0]  R74       1
    z[3,8,0]  R1266     -1
    z[3,8,0]  R1267     1
    z[3,8,0]  R1280     -4.6925377845764160e-01
    z[3,8,0]  R1281     -0.33150514960289
    z[3,8,0]  R1282     -5.9620642662048340e-01
    z[3,8,0]  R1283     -5.3413516283035278e-01
    z[3,8,0]  R1284     -6.8876588344573975e-01
    z[3,8,0]  R1285     -6.0696613788604736e-01
    z[3,8,0]  R1286     -8.4953486919403076e-01
    z[3,8,0]  R1287     -3.9942458271980286e-01
    z[3,8,0]  R1288     9.1994702816009521e-01
    z[3,8,0]  R1289     8.8811534643173218e-01
    z[3,8,0]  R1290     -7.2577923536300659e-01
    z[3,8,0]  R1291     -0.519461452960968
    z[3,8,0]  R1292     4.1029435396194458e-01
    z[3,8,0]  R1293     -1.9557641819119453e-02
    z[3,8,0]  R1294     4.4595736265182495e-01
    z[3,8,0]  R1295     6.6566020250320435e-02
    z[3,8,0]  R1296     3.9135344326496124e-02
    z[3,8,0]  R1297     3.4614410996437073e-01
    z[3,8,0]  R1298     2.3814016953110695e-02
    z[3,8,0]  R1299     7.9699587821960449e-01
    z[3,8,0]  R1300     -6.4133369922637939e-01
    z[3,8,0]  R1301     -5.4724627733230591e-01
    z[3,8,0]  R1302     -0.620279848575592
    z[3,8,0]  R1303     3.0767804384231567e-01
    z[3,8,0]  R1304     3.8189122080802917e-01
    z[3,8,0]  R1305     -9.4968140125274658e-02
    z[3,8,0]  R1306     6.8948942422866821e-01
    z[3,8,0]  R1307     -6.1649329960346222e-02
    z[3,8,0]  R1308     4.1818743944168091e-01
    z[3,8,0]  R1309     9.6550965309143066e-01
    z[3,8,0]  R1310     -2.5130379199981689e-01
    z[3,8,0]  R1311     2.6442989706993103e-01
    z[3,8,0]  R1312     5.3732526302337646e-01
    z[3,8,0]  R1313     -2.8376492857933044e-01
    z[3,8,0]  R1314     9.0092593431472778e-01
    z[3,8,0]  R1315     8.6789494752883911e-01
    z[3,8,0]  R1316     8.5806202888488770e-01
    z[3,8,0]  R1317     8.2225483655929565e-01
    z[3,8,0]  R1318     0.821610689163208
    z[3,8,0]  R1319     8.3646327257156372e-01
    z[3,8,0]  R1320     7.5349879264831543e-01
    z[3,8,0]  R1321     0.307144433259964
    z[3,8,0]  R1322     2.5218990445137024e-01
    z[3,8,0]  R1323     1.7160646617412567e-02
    z[3,8,0]  R1324     4.0592528879642487e-02
    z[3,8,0]  R1325     7.5310325622558594e-01
    z[3,8,0]  R1326     0.409322589635849
    z[3,8,0]  R1327     1.8494494259357452e-01
    z[3,8,0]  R1328     2.6719310879707336e-01
    z[3,8,0]  R1329     4.4634243845939636e-01
    z[3,8,0]  R1330     -3.0533054471015930e-01
    z[3,8,0]  R1331     -1.7112727463245392e-01
    z[3,8,0]  R1332     -3.9704239368438721e-01
    z[3,8,0]  R1333     -1.7034025490283966e-01
    z[3,8,0]  R1334     -1.6297745704650879e-01
    z[3,8,0]  R1335     -1.6063745319843292e-01
    z[3,8,0]  R1336     -1.8528106808662415e-01
    z[3,8,0]  R1337     -2.2841534018516541e-01
    z[3,8,0]  R1338     -2.7883759140968323e-01
    z[3,8,0]  R1339     -6.5518236160278320e-01
    z[3,8,0]  R1340     5.8571350574493408e-01
    z[3,8,0]  R1341     2.8354993462562561e-01
    z[3,8,0]  R1342     5.8395421504974365e-01
    z[3,8,0]  R1343     5.2461272478103638e-01
    z[3,8,0]  R1344     -5.0638926029205322e-01
    z[3,8,0]  R1345     4.8312941193580627e-01
    z[3,8,0]  R1346     6.8348360061645508e-01
    z[3,8,0]  R1347     4.1684523224830627e-01
    z[3,8,0]  R1348     -4.5816802978515625e-01
    z[3,8,0]  R1349     -0.49376380443573
    z[3,8,0]  R1350     6.7443841695785522e-01
    z[3,8,0]  R1351     7.0656412839889526e-01
    z[3,8,0]  R1352     -2.4325503408908844e-01
    z[3,8,0]  R1353     3.9420586079359055e-02
    z[3,8,0]  R1354     4.8067179322242737e-01
    z[3,8,0]  R1355     4.1502940654754639e-01
    z[3,8,0]  R1356     3.1739464402198792e-01
    z[3,8,0]  R1357     -4.0888100862503052e-01
    z[3,8,0]  R1358     3.8763949275016785e-01
    z[3,8,0]  R1359     -1.2355958670377731e-01
    z[3,8,0]  R1360     4.4388791918754578e-01
    z[3,8,0]  R1361     0.376607209444046
    z[3,8,0]  R1362     -3.8632029294967651e-01
    z[3,8,0]  R1363     -2.6457989215850830e-01
    z[3,8,0]  R1364     2.8549227118492126e-01
    z[3,8,0]  R1365     4.7952511906623840e-01
    z[3,8,0]  R1366     -6.6012746095657349e-01
    z[3,8,0]  R1367     -4.7437986731529236e-01
    z[3,8,0]  R1368     -4.8283296823501587e-01
    z[3,8,0]  R1369     6.6481798887252808e-01
    z[3,8,1]  R30       -1
    z[3,8,1]  R75       1
    z[3,8,1]  R1268     -1
    z[3,8,1]  R1269     1
    z[3,8,1]  R1280     -3.1371474266052246e-01
    z[3,8,1]  R1281     3.2901279628276825e-02
    z[3,8,1]  R1282     1.6907972097396851e-01
    z[3,8,1]  R1283     9.1157384216785431e-02
    z[3,8,1]  R1284     -2.7442991733551025e-01
    z[3,8,1]  R1285     4.0999788790941238e-02
    z[3,8,1]  R1286     1.7802091315388680e-02
    z[3,8,1]  R1287     -4.6836573630571365e-02
    z[3,8,1]  R1288     -1.0292798280715942e-01
    z[3,8,1]  R1289     -9.5199182629585266e-02
    z[3,8,1]  R1290     1.2362776324152946e-02
    z[3,8,1]  R1291     3.5043430328369141e-01
    z[3,8,1]  R1292     6.5007501840591431e-01
    z[3,8,1]  R1293     7.1344602108001709e-01
    z[3,8,1]  R1294     0.801207423210144
    z[3,8,1]  R1295     5.6806391477584839e-01
    z[3,8,1]  R1296     5.5044001340866089e-01
    z[3,8,1]  R1297     0.766588568687439
    z[3,8,1]  R1298     7.7620851993560791e-01
    z[3,8,1]  R1299     4.8600149154663086e-01
    z[3,8,1]  R1300     0.492839515209198
    z[3,8,1]  R1301     4.1238497942686081e-02
    z[3,8,1]  R1302     1.3178735971450806e-01
    z[3,8,1]  R1303     0.550700306892395
    z[3,8,1]  R1304     5.7686352729797363e-01
    z[3,8,1]  R1305     5.3804230690002441e-01
    z[3,8,1]  R1306     5.2287822961807251e-01
    z[3,8,1]  R1307     6.5635836124420166e-01
    z[3,8,1]  R1308     4.2095881700515747e-01
    z[3,8,1]  R1309     -1.2013946473598480e-01
    z[3,8,1]  R1310     7.3735463619232178e-01
    z[3,8,1]  R1311     6.0515117645263672e-01
    z[3,8,1]  R1312     5.4157292842864990e-01
    z[3,8,1]  R1313     4.7969511151313782e-01
    z[3,8,1]  R1314     3.0161522328853607e-02
    z[3,8,1]  R1315     -1.3235937058925629e-01
    z[3,8,1]  R1316     4.7759800218045712e-03
    z[3,8,1]  R1317     -1.7067900300025940e-01
    z[3,8,1]  R1318     -2.6218351721763611e-01
    z[3,8,1]  R1319     -1.3294726610183716e-01
    z[3,8,1]  R1320     5.3390890359878540e-01
    z[3,8,1]  R1321     -1.1291924118995667e-01
    z[3,8,1]  R1322     9.5239475369453430e-02
    z[3,8,1]  R1323     3.3926531672477722e-01
    z[3,8,1]  R1324     4.6290901303291321e-01
    z[3,8,1]  R1325     4.4603973627090454e-01
    z[3,8,1]  R1326     -3.7558069825172424e-01
    z[3,8,1]  R1327     -2.9839560389518738e-01
    z[3,8,1]  R1328     3.7120589613914490e-01
    z[3,8,1]  R1329     -2.6726689934730530e-01
    z[3,8,1]  R1330     -9.0453439950942993e-01
    z[3,8,1]  R1331     -9.1103643178939819e-01
    z[3,8,1]  R1332     -0.866890549659729
    z[3,8,1]  R1333     -9.0055418014526367e-01
    z[3,8,1]  R1334     -8.8076150417327881e-01
    z[3,8,1]  R1335     -8.8842248916625977e-01
    z[3,8,1]  R1336     -8.7182438373565674e-01
    z[3,8,1]  R1337     -0.855061948299408
    z[3,8,1]  R1338     -8.2966303825378418e-01
    z[3,8,1]  R1339     -7.3643636703491211e-01
    z[3,8,1]  R1340     -2.8715163469314575e-01
    z[3,8,1]  R1341     -1.7557007074356079e-01
    z[3,8,1]  R1342     -5.1222376525402069e-02
    z[3,8,1]  R1343     1.0439503192901611e-01
    z[3,8,1]  R1344     6.6497230529785156e-01
    z[3,8,1]  R1345     -7.8976178169250488e-01
    z[3,8,1]  R1346     -0.595569372177124
    z[3,8,1]  R1347     4.4834807515144348e-01
    z[3,8,1]  R1348     7.5294440984725952e-01
    z[3,8,1]  R1349     0.756111741065979
    z[3,8,1]  R1350     4.8174926638603210e-01
    z[3,8,1]  R1351     -2.0700308680534363e-01
    z[3,8,1]  R1352     3.3629408478736877e-01
    z[3,8,1]  R1353     -3.3663976192474365e-01
    z[3,8,1]  R1354     -1.3645662367343903e-01
    z[3,8,1]  R1355     4.5533582568168640e-01
    z[3,8,1]  R1356     -5.2777826786041260e-01
    z[3,8,1]  R1357     8.2022237777709961e-01
    z[3,8,1]  R1358     -5.9745508432388306e-01
    z[3,8,1]  R1359     -6.4928692579269409e-01
    z[3,8,1]  R1360     -4.7594240307807922e-01
    z[3,8,1]  R1361     -2.1905189752578735e-01
    z[3,8,1]  R1362     3.1492364406585693e-01
    z[3,8,1]  R1363     3.3113875985145569e-01
    z[3,8,1]  R1364     -7.1422350406646729e-01
    z[3,8,1]  R1365     -5.2346724271774292e-01
    z[3,8,1]  R1366     6.4730447530746460e-01
    z[3,8,1]  R1367     5.1535248756408691e-01
    z[3,8,1]  R1368     5.5950152873992920e-01
    z[3,8,1]  R1369     -4.5236143469810486e-01
    z[3,8,2]  R31       -1
    z[3,8,2]  R76       1
    z[3,8,2]  R1270     -1
    z[3,8,2]  R1271     1
    z[3,8,2]  R1280     7.7526587247848511e-01
    z[3,8,2]  R1281     8.9516741037368774e-01
    z[3,8,2]  R1282     3.5201448202133179e-01
    z[3,8,2]  R1283     5.7556211948394775e-01
    z[3,8,2]  R1284     2.4388627707958221e-01
    z[3,8,2]  R1285     1.9422550499439240e-01
    z[3,8,2]  R1286     2.5933519005775452e-01
    z[3,8,2]  R1287     0.202837273478508
    z[3,8,2]  R1288     3.2138973474502563e-01
    z[3,8,2]  R1289     4.2020189762115479e-01
    z[3,8,2]  R1290     -2.8708580136299133e-01
    z[3,8,2]  R1291     -4.6171575784683228e-02
    z[3,8,2]  R1292     -2.1103249490261078e-01
    z[3,8,2]  R1293     4.2556360363960266e-02
    z[3,8,2]  R1294     -3.3406227827072144e-02
    z[3,8,2]  R1295     -0.0990736186504364
    z[3,8,2]  R1296     1.3600957393646240e-01
    z[3,8,2]  R1297     1.1976634850725532e-03
    z[3,8,2]  R1298     0.0696486309170723
    z[3,8,2]  R1299     3.0957534909248352e-01
    z[3,8,2]  R1300     -1.2485025823116302e-01
    z[3,8,2]  R1301     -1.3977298513054848e-02
    z[3,8,2]  R1302     -0.208160862326622
    z[3,8,2]  R1303     8.8788039982318878e-02
    z[3,8,2]  R1304     -2.0874983072280884e-01
    z[3,8,2]  R1305     -7.1404181420803070e-02
    z[3,8,2]  R1306     -1.0149326175451279e-02
    z[3,8,2]  R1307     -2.1710006892681122e-01
    z[3,8,2]  R1308     3.2241743803024292e-01
    z[3,8,2]  R1309     -5.0627548247575760e-02
    z[3,8,2]  R1310     4.3066430091857910e-01
    z[3,8,2]  R1311     5.7679611444473267e-01
    z[3,8,2]  R1312     3.7671455740928650e-01
    z[3,8,2]  R1313     -1.7360439896583557e-01
    z[3,8,2]  R1314     1.0191214829683304e-01
    z[3,8,2]  R1315     1.2821683287620544e-01
    z[3,8,2]  R1316     -4.9768432974815369e-02
    z[3,8,2]  R1317     7.4249237775802612e-02
    z[3,8,2]  R1318     1.3735768198966980e-01
    z[3,8,2]  R1319     -1.8188828229904175e-01
    z[3,8,2]  R1320     -4.5283399522304535e-02
    z[3,8,2]  R1321     3.3473870158195496e-01
    z[3,8,2]  R1322     5.7471507787704468e-01
    z[3,8,2]  R1323     5.6111335754394531e-01
    z[3,8,2]  R1324     6.4216136932373047e-01
    z[3,8,2]  R1325     5.1232177764177322e-02
    z[3,8,2]  R1326     2.9302367568016052e-01
    z[3,8,2]  R1327     3.7862551212310791e-01
    z[3,8,2]  R1328     5.2351778745651245e-01
    z[3,8,2]  R1329     1.1340779066085815e-01
    z[3,8,2]  R1330     -3.4694414585828781e-02
    z[3,8,2]  R1331     -2.3301114141941071e-01
    z[3,8,2]  R1332     -5.4809297434985638e-03
    z[3,8,2]  R1333     -1.3062655925750732e-01
    z[3,8,2]  R1334     -3.1449711322784424e-01
    z[3,8,2]  R1335     -1.4832252264022827e-01
    z[3,8,2]  R1336     -1.4843389391899109e-01
    z[3,8,2]  R1337     -0.200262188911438
    z[3,8,2]  R1338     -2.0472073554992676e-01
    z[3,8,2]  R1339     2.5710277259349823e-02
    z[3,8,2]  R1340     4.2051258683204651e-01
    z[3,8,2]  R1341     5.9493917226791382e-01
    z[3,8,2]  R1342     2.7369165420532227e-01
    z[3,8,2]  R1343     7.1624934673309326e-01
    z[3,8,2]  R1344     4.4915539026260376e-01
    z[3,8,2]  R1345     1.2079031206667423e-02
    z[3,8,2]  R1346     -0.0837479680776596
    z[3,8,2]  R1347     -9.6484325826168060e-02
    z[3,8,2]  R1348     0.119090735912323
    z[3,8,2]  R1349     1.2360082007944584e-02
    z[3,8,2]  R1350     -0.00766489002853632
    z[3,8,2]  R1351     5.0639349222183228e-01
    z[3,8,2]  R1352     8.1966572999954224e-01
    z[3,8,2]  R1353     6.4619135856628418e-01
    z[3,8,2]  R1354     -2.9444175306707621e-03
    z[3,8,2]  R1355     6.7845833301544189e-01
    z[3,8,2]  R1356     1.3194097578525543e-01
    z[3,8,2]  R1357     1.8230533599853516e-01
    z[3,8,2]  R1358     0.210468590259552
    z[3,8,2]  R1359     5.4060208797454834e-01
    z[3,8,2]  R1360     3.1908458471298218e-01
    z[3,8,2]  R1361     3.0309337377548218e-01
    z[3,8,2]  R1362     7.4047005176544189e-01
    z[3,8,2]  R1363     5.6868463754653931e-01
    z[3,8,2]  R1364     2.9122796654701233e-01
    z[3,8,2]  R1365     5.1562881469726562e-01
    z[3,8,2]  R1366     1.3450199365615845e-01
    z[3,8,2]  R1367     1.6099503636360168e-01
    z[3,8,2]  R1368     -6.8838261067867279e-02
    z[3,8,2]  R1369     -4.3100094795227051e-01
    z[3,8,3]  R32       -1
    z[3,8,3]  R77       1
    z[3,8,3]  R1272     -1
    z[3,8,3]  R1273     1
    z[3,8,3]  R1280     0.07901581376791
    z[3,8,3]  R1281     0.14643594622612
    z[3,8,3]  R1282     1.8404580652713776e-01
    z[3,8,3]  R1283     -4.8148915171623230e-01
    z[3,8,3]  R1284     -2.5568547844886780e-01
    z[3,8,3]  R1285     1.2257728725671768e-01
    z[3,8,3]  R1286     -2.2818391025066376e-01
    z[3,8,3]  R1287     -3.1830493360757828e-02
    z[3,8,3]  R1288     8.9937351644039154e-02
    z[3,8,3]  R1289     -1.0073759406805038e-01
    z[3,8,3]  R1290     1.3321955502033234e-01
    z[3,8,3]  R1291     6.0039076954126358e-02
    z[3,8,3]  R1292     -9.3716740608215332e-02
    z[3,8,3]  R1293     4.2428936809301376e-02
    z[3,8,3]  R1294     -3.1878617405891418e-01
    z[3,8,3]  R1295     -6.2994378805160522e-01
    z[3,8,3]  R1296     9.8014205694198608e-02
    z[3,8,3]  R1297     -1.7204432189464569e-01
    z[3,8,3]  R1298     -1.6432275995612144e-02
    z[3,8,3]  R1299     5.1976222544908524e-02
    z[3,8,3]  R1300     -1.6308794915676117e-01
    z[3,8,3]  R1301     2.9764357209205627e-01
    z[3,8,3]  R1302     -5.3639984130859375e-01
    z[3,8,3]  R1303     -1.9266603887081146e-01
    z[3,8,3]  R1304     0.067952461540699
    z[3,8,3]  R1305     -1.9458861649036407e-01
    z[3,8,3]  R1306     3.9981618523597717e-01
    z[3,8,3]  R1307     -5.7392424345016479e-01
    z[3,8,3]  R1308     1.0243978351354599e-01
    z[3,8,3]  R1309     -1.8930040299892426e-02
    z[3,8,3]  R1310     -3.2287371158599854e-01
    z[3,8,3]  R1311     -1.6707479953765869e-01
    z[3,8,3]  R1312     2.4766427278518677e-01
    z[3,8,3]  R1313     7.4058908224105835e-01
    z[3,8,3]  R1314     -2.1980394423007965e-01
    z[3,8,3]  R1315     1.7972676083445549e-02
    z[3,8,3]  R1316     -2.1149446070194244e-01
    z[3,8,3]  R1317     -6.3981473445892334e-02
    z[3,8,3]  R1318     1.6020385921001434e-01
    z[3,8,3]  R1319     -4.2409861087799072e-01
    z[3,8,3]  R1320     2.9557514190673828e-01
    z[3,8,3]  R1321     0.511228084564209
    z[3,8,3]  R1322     3.1941589713096619e-01
    z[3,8,3]  R1323     1.8191672861576080e-01
    z[3,8,3]  R1324     2.5957101583480835e-01
    z[3,8,3]  R1325     -1.8496680259704590e-01
    z[3,8,3]  R1326     2.1793392300605774e-01
    z[3,8,3]  R1327     2.8237605094909668e-01
    z[3,8,3]  R1328     3.6248272657394409e-01
    z[3,8,3]  R1329     1.5013046562671661e-01
    z[3,8,3]  R1330     -2.2524642944335938e-01
    z[3,8,3]  R1331     1.7526608705520630e-01
    z[3,8,3]  R1332     -1.3580419123172760e-01
    z[3,8,3]  R1333     1.3678257167339325e-01
    z[3,8,3]  R1334     -3.9878997951745987e-02
    z[3,8,3]  R1335     1.4355589635670185e-02
    z[3,8,3]  R1336     2.3384894430637360e-01
    z[3,8,3]  R1337     -3.0689659714698792e-01
    z[3,8,3]  R1338     -2.2202888131141663e-01
    z[3,8,3]  R1339     0.027417017146945
    z[3,8,3]  R1340     3.6058798432350159e-01
    z[3,8,3]  R1341     6.0836231708526611e-01
    z[3,8,3]  R1342     4.7131389379501343e-01
    z[3,8,3]  R1343     0.214554101228714
    z[3,8,3]  R1344     1.1563784629106522e-01
    z[3,8,3]  R1345     2.9142510890960693e-01
    z[3,8,3]  R1346     -1.1412892490625381e-02
    z[3,8,3]  R1347     -3.6228007078170776e-01
    z[3,8,3]  R1348     -3.9543735980987549e-01
    z[3,8,3]  R1349     -1.8169339001178741e-01
    z[3,8,3]  R1350     -4.5411369204521179e-01
    z[3,8,3]  R1351     3.3606874942779541e-01
    z[3,8,3]  R1352     2.1002674102783203e-01
    z[3,8,3]  R1353     5.6889343261718750e-01
    z[3,8,3]  R1354     4.3332943320274353e-01
    z[3,8,3]  R1355     3.4539647400379181e-02
    z[3,8,3]  R1356     3.5232019424438477e-01
    z[3,8,3]  R1357     4.5969886705279350e-03
    z[3,8,3]  R1358     1.3093477487564087e-01
    z[3,8,3]  R1359     2.0541979372501373e-01
    z[3,8,3]  R1360     3.0937123298645020e-01
    z[3,8,3]  R1361     4.8632130026817322e-01
    z[3,8,3]  R1362     2.3699489235877991e-01
    z[3,8,3]  R1363     6.1725121736526489e-01
    z[3,8,3]  R1364     3.8626599311828613e-01
    z[3,8,3]  R1365     -1.5872826799750328e-02
    z[3,8,3]  R1366     -2.7297082543373108e-01
    z[3,8,3]  R1367     -3.3678501844406128e-01
    z[3,8,3]  R1368     -3.4425669908523560e-01
    z[3,8,3]  R1369     -5.6831665337085724e-02
    z[3,8,4]  R33       -1
    z[3,8,4]  R78       1
    z[3,8,4]  R1274     -1
    z[3,8,4]  R1275     1
    z[3,8,4]  R1280     -1.5118260681629181e-01
    z[3,8,4]  R1281     -1.2110810726881027e-01
    z[3,8,4]  R1282     3.0696511268615723e-01
    z[3,8,4]  R1283     9.3824982643127441e-02
    z[3,8,4]  R1284     5.6252223253250122e-01
    z[3,8,4]  R1285     4.5384871959686279e-01
    z[3,8,4]  R1286     3.0659487843513489e-01
    z[3,8,4]  R1287     -2.3273593187332153e-01
    z[3,8,4]  R1288     -1.6773466765880585e-01
    z[3,8,4]  R1289     -1.9281828776001930e-02
    z[3,8,4]  R1290     -3.8209676742553711e-01
    z[3,8,4]  R1291     -6.9468045234680176e-01
    z[3,8,4]  R1292     -1.7974703013896942e-01
    z[3,8,4]  R1293     -2.7379241585731506e-01
    z[3,8,4]  R1294     -6.6507525742053986e-02
    z[3,8,4]  R1295     2.2297158837318420e-01
    z[3,8,4]  R1296     -2.7357056736946106e-01
    z[3,8,4]  R1297     2.1131275594234467e-01
    z[3,8,4]  R1298     -2.1221134066581726e-01
    z[3,8,4]  R1299     3.5109922289848328e-02
    z[3,8,4]  R1300     -0.242910698056221
    z[3,8,4]  R1301     -6.4958351850509644e-01
    z[3,8,4]  R1302     -8.3872549235820770e-02
    z[3,8,4]  R1303     2.5922521948814392e-01
    z[3,8,4]  R1304     5.6454139947891235e-01
    z[3,8,4]  R1305     7.3291277885437012e-01
    z[3,8,4]  R1306     1.1814720183610916e-01
    z[3,8,4]  R1307     2.6722148060798645e-01
    z[3,8,4]  R1308     3.0719587206840515e-01
    z[3,8,4]  R1309     -5.8366615325212479e-02
    z[3,8,4]  R1310     -2.9494842886924744e-01
    z[3,8,4]  R1311     -1.6150401532649994e-01
    z[3,8,4]  R1312     -1.4807645976543427e-01
    z[3,8,4]  R1313     1.3833388686180115e-01
    z[3,8,4]  R1314     -1.4137434959411621e-01
    z[3,8,4]  R1315     8.2156389951705933e-02
    z[3,8,4]  R1316     2.8801393508911133e-01
    z[3,8,4]  R1317     4.7589689493179321e-01
    z[3,8,4]  R1318     3.6816483736038208e-01
    z[3,8,4]  R1319     1.2181729823350906e-01
    z[3,8,4]  R1320     1.4715710654854774e-02
    z[3,8,4]  R1321     -4.6450448036193848e-01
    z[3,8,4]  R1322     -5.1308578252792358e-01
    z[3,8,4]  R1323     -6.5982139110565186e-01
    z[3,8,4]  R1324     -4.9314025044441223e-01
    z[3,8,4]  R1325     4.0272939950227737e-03
    z[3,8,4]  R1326     -6.1621171236038208e-01
    z[3,8,4]  R1327     -6.7005592584609985e-01
    z[3,8,4]  R1328     -6.1298555135726929e-01
    z[3,8,4]  R1329     -7.7415800094604492e-01
    z[3,8,4]  R1330     9.8041877150535583e-02
    z[3,8,4]  R1331     0.0976729765534401
    z[3,8,4]  R1332     5.9816960245370865e-02
    z[3,8,4]  R1333     3.2650753855705261e-01
    z[3,8,4]  R1334     -5.2045132964849472e-02
    z[3,8,4]  R1335     9.0918548405170441e-02
    z[3,8,4]  R1336     3.1808158755302429e-01
    z[3,8,4]  R1337     -1.0641106218099594e-01
    z[3,8,4]  R1338     2.3723126947879791e-01
    z[3,8,4]  R1339     5.1848553121089935e-03
    z[3,8,4]  R1340     0.232549786567688
    z[3,8,4]  R1341     2.1865151822566986e-01
    z[3,8,4]  R1342     1.2797074019908905e-01
    z[3,8,4]  R1343     1.5356892347335815e-01
    z[3,8,4]  R1344     4.4284559786319733e-02
    z[3,8,4]  R1345     1.8996295332908630e-01
    z[3,8,4]  R1346     6.6601976752281189e-02
    z[3,8,4]  R1347     -1.3420465588569641e-01
    z[3,8,4]  R1348     4.3489160016179085e-03
    z[3,8,4]  R1349     1.7702130600810051e-02
    z[3,8,4]  R1350     -1.3463121652603149e-01
    z[3,8,4]  R1351     -1.4478822052478790e-01
    z[3,8,4]  R1352     1.0083559900522232e-01
    z[3,8,4]  R1353     2.5494772195816040e-01
    z[3,8,4]  R1354     -5.0143241882324219e-01
    z[3,8,4]  R1355     6.1852414160966873e-02
    z[3,8,4]  R1356     3.2360956072807312e-01
    z[3,8,4]  R1357     -2.4408391118049622e-01
    z[3,8,4]  R1358     4.0664246678352356e-01
    z[3,8,4]  R1359     5.5780843831598759e-03
    z[3,8,4]  R1360     -5.4525423049926758e-01
    z[3,8,4]  R1361     2.4329267442226410e-01
    z[3,8,4]  R1362     -4.4477835297584534e-02
    z[3,8,4]  R1363     2.0227548480033875e-01
    z[3,8,4]  R1364     3.0241009593009949e-01
    z[3,8,4]  R1365     1.7804567515850067e-01
    z[3,8,4]  R1366     9.8191395401954651e-02
    z[3,8,4]  R1367     -0.257386714220047
    z[3,8,4]  R1368     -4.1155639290809631e-01
    z[3,8,4]  R1369     -1.6819517314434052e-01
    z[3,8,5]  R34       -1
    z[3,8,5]  R79       1
    z[3,8,5]  R1276     -1
    z[3,8,5]  R1277     1
    z[3,8,5]  R1280     1.4710752665996552e-01
    z[3,8,5]  R1281     5.5916242301464081e-02
    z[3,8,5]  R1282     -4.3696433305740356e-01
    z[3,8,5]  R1283     1.7973285913467407e-01
    z[3,8,5]  R1284     5.2761003375053406e-02
    z[3,8,5]  R1285     -4.1906601190567017e-01
    z[3,8,5]  R1286     -2.1328464150428772e-01
    z[3,8,5]  R1287     -3.1065386533737183e-01
    z[3,8,5]  R1288     -3.6468520760536194e-02
    z[3,8,5]  R1289     2.5497859343886375e-02
    z[3,8,5]  R1290     4.7373014688491821e-01
    z[3,8,5]  R1291     3.4413686394691467e-01
    z[3,8,5]  R1292     1.0588242113590240e-01
    z[3,8,5]  R1293     -5.6741183996200562e-01
    z[3,8,5]  R1294     -1.9991537928581238e-01
    z[3,8,5]  R1295     4.0387919545173645e-01
    z[3,8,5]  R1296     4.9634307622909546e-01
    z[3,8,5]  R1297     -3.8713118433952332e-01
    z[3,8,5]  R1298     6.3142009079456329e-02
    z[3,8,5]  R1299     -3.2969031017273664e-03
    z[3,8,5]  R1300     3.0698272585868835e-01
    z[3,8,5]  R1301     -1.0310070216655731e-01
    z[3,8,5]  R1302     4.5047125220298767e-01
    z[3,8,5]  R1303     6.7605400085449219e-01
    z[3,8,5]  R1304     1.3374383747577667e-01
    z[3,8,5]  R1305     3.3290737867355347e-01
    z[3,8,5]  R1306     -0.0471990704536438
    z[3,8,5]  R1307     -2.4472513794898987e-01
    z[3,8,5]  R1308     -2.2847951948642731e-01
    z[3,8,5]  R1309     1.9362162053585052e-01
    z[3,8,5]  R1310     1.2813235819339752e-01
    z[3,8,5]  R1311     -2.9364410042762756e-01
    z[3,8,5]  R1312     3.1093168258666992e-01
    z[3,8,5]  R1313     2.8522640466690063e-01
    z[3,8,5]  R1314     -2.9728201031684875e-01
    z[3,8,5]  R1315     -3.9887115359306335e-01
    z[3,8,5]  R1316     -1.6919489204883575e-01
    z[3,8,5]  R1317     -2.6922725141048431e-02
    z[3,8,5]  R1318     -1.3203187286853790e-01
    z[3,8,5]  R1319     -1.9959259033203125e-01
    z[3,8,5]  R1320     -2.2283443808555603e-01
    z[3,8,5]  R1321     -4.2021080851554871e-01
    z[3,8,5]  R1322     -2.4339118599891663e-01
    z[3,8,5]  R1323     1.6859647631645203e-01
    z[3,8,5]  R1324     -8.5380002856254578e-02
    z[3,8,5]  R1325     -2.5385084748268127e-01
    z[3,8,5]  R1326     1.5152811072766781e-02
    z[3,8,5]  R1327     0.334398090839386
    z[3,8,5]  R1328     5.7299923151731491e-02
    z[3,8,5]  R1329     1.1835353076457977e-01
    z[3,8,5]  R1330     -1.6442918777465820e-01
    z[3,8,5]  R1331     -1.0862501710653305e-01
    z[3,8,5]  R1332     4.9955964088439941e-02
    z[3,8,5]  R1333     -1.2794810533523560e-01
    z[3,8,5]  R1334     -2.8526043891906738e-01
    z[3,8,5]  R1335     -3.8474711775779724e-01
    z[3,8,5]  R1336     1.3758680224418640e-01
    z[3,8,5]  R1337     2.8761990368366241e-02
    z[3,8,5]  R1338     2.3101963102817535e-01
    z[3,8,5]  R1339     1.3659349083900452e-01
    z[3,8,5]  R1340     -5.3563795983791351e-02
    z[3,8,5]  R1341     -1.1258027702569962e-01
    z[3,8,5]  R1342     -3.9664259552955627e-01
    z[3,8,5]  R1343     -3.5026380419731140e-01
    z[3,8,5]  R1344     2.3329722881317139e-01
    z[3,8,5]  R1345     -1.4275322854518890e-01
    z[3,8,5]  R1346     -3.8245955109596252e-01
    z[3,8,5]  R1347     6.7891335487365723e-01
    z[3,8,5]  R1348     0.228000208735466
    z[3,8,5]  R1349     2.6723757386207581e-01
    z[3,8,5]  R1350     2.5089517235755920e-01
    z[3,8,5]  R1351     -5.5038008838891983e-02
    z[3,8,5]  R1352     -1.2910473346710205e-01
    z[3,8,5]  R1353     -2.3100826144218445e-01
    z[3,8,5]  R1354     2.5525811314582825e-01
    z[3,8,5]  R1355     3.9080002903938293e-01
    z[3,8,5]  R1356     -5.7665330171585083e-01
    z[3,8,5]  R1357     1.8812340497970581e-01
    z[3,8,5]  R1358     -0.451568603515625
    z[3,8,5]  R1359     4.5929422974586487e-01
    z[3,8,5]  R1360     2.4407865107059479e-01
    z[3,8,5]  R1361     -6.4954203367233276e-01
    z[3,8,5]  R1362     -2.0454682409763336e-02
    z[3,8,5]  R1363     -1.6836887598037720e-01
    z[3,8,5]  R1364     -2.3943383991718292e-01
    z[3,8,5]  R1365     -2.2156395018100739e-01
    z[3,8,5]  R1366     1.6375060379505157e-01
    z[3,8,5]  R1367     5.4560887813568115e-01
    z[3,8,5]  R1368     2.3006257414817810e-01
    z[3,8,5]  R1369     8.1063613295555115e-02
    z[3,8,6]  R35       -1
    z[3,8,6]  R80       1
    z[3,8,6]  R1278     -1
    z[3,8,6]  R1279     1
    z[3,8,6]  R1280     1.7206548154354095e-01
    z[3,8,6]  R1281     -2.2013604640960693e-01
    z[3,8,6]  R1282     -4.1592967510223389e-01
    z[3,8,6]  R1283     3.1965491175651550e-01
    z[3,8,6]  R1284     -7.8862540423870087e-02
    z[3,8,6]  R1285     4.4223007559776306e-01
    z[3,8,6]  R1286     1.3842076063156128e-01
    z[3,8,6]  R1287     8.0339181423187256e-01
    z[3,8,6]  R1288     -4.7521837055683136e-02
    z[3,8,6]  R1289     1.2020229548215866e-01
    z[3,8,6]  R1290     -5.0076227635145187e-02
    z[3,8,6]  R1291     -2.4653879925608635e-02
    z[3,8,6]  R1292     5.5876958370208740e-01
    z[3,8,6]  R1293     3.0013734102249146e-01
    z[3,8,6]  R1294     1.0981138795614243e-01
    z[3,8,6]  R1295     -2.3106880486011505e-01
    z[3,8,6]  R1296     -5.8837193250656128e-01
    z[3,8,6]  R1297     -2.6153776049613953e-01
    z[3,8,6]  R1298     -5.8548414707183838e-01
    z[3,8,6]  R1299     -1.6975912451744080e-01
    z[3,8,6]  R1300     -3.8777709007263184e-01
    z[3,8,6]  R1301     4.2124241590499878e-01
    z[3,8,6]  R1302     2.3847469687461853e-01
    z[3,8,6]  R1303     1.8114395439624786e-01
    z[3,8,6]  R1304     3.6959323287010193e-01
    z[3,8,6]  R1305     -1.0266353935003281e-01
    z[3,8,6]  R1306     -2.7397081255912781e-01
    z[3,8,6]  R1307     2.3994588851928711e-01
    z[3,8,6]  R1308     6.2200784683227539e-01
    z[3,8,6]  R1309     9.7674198448657990e-02
    z[3,8,6]  R1310     -4.7831791453063488e-03
    z[3,8,6]  R1311     3.0158025026321411e-01
    z[3,8,6]  R1312     3.1003820896148682e-01
    z[3,8,6]  R1313     1.0133621096611023e-01
    z[3,8,6]  R1314     1.4268645644187927e-01
    z[3,8,6]  R1315     2.1593706309795380e-01
    z[3,8,6]  R1316     -3.2391491532325745e-01
    z[3,8,6]  R1317     -2.4074141681194305e-01
    z[3,8,6]  R1318     -2.4229244887828827e-01
    z[3,8,6]  R1319     1.2261576205492020e-01
    z[3,8,6]  R1320     -8.8847614824771881e-02
    z[3,8,6]  R1321     -3.5660311579704285e-01
    z[3,8,6]  R1322     -4.1534259915351868e-01
    z[3,8,6]  R1323     -2.6995116472244263e-01
    z[3,8,6]  R1324     -2.3203879594802856e-01
    z[3,8,6]  R1325     3.6412918567657471e-01
    z[3,8,6]  R1326     -4.2200666666030884e-01
    z[3,8,6]  R1327     -3.0473735928535461e-01
    z[3,8,6]  R1328     0.0794663280248642
    z[3,8,6]  R1329     -2.8393331170082092e-01
    z[3,8,6]  R1330     1.3920005876570940e-03
    z[3,8,6]  R1331     1.8540833890438080e-01
    z[3,8,6]  R1332     -2.5751054286956787e-01
    z[3,8,6]  R1333     3.5152930766344070e-02
    z[3,8,6]  R1334     1.1452741920948029e-01
    z[3,8,6]  R1335     7.9993076622486115e-02
    z[3,8,6]  R1336     9.3643620610237122e-02
    z[3,8,6]  R1337     2.6505556702613831e-01
    z[3,8,6]  R1338     1.8180431425571442e-01
    z[3,8,6]  R1339     9.1106317937374115e-02
    z[3,8,6]  R1340     4.5899960398674011e-01
    z[3,8,6]  R1341     3.2285347580909729e-01
    z[3,8,6]  R1342     4.3084564805030823e-01
    z[3,8,6]  R1343     9.2565260827541351e-02
    z[3,8,6]  R1344     1.7285913228988647e-01
    z[3,8,6]  R1345     3.6376565694808960e-02
    z[3,8,6]  R1346     -1.4245083928108215e-01
    z[3,8,6]  R1347     -7.5721487402915955e-02
    z[3,8,6]  R1348     2.4506205692887306e-02
    z[3,8,6]  R1349     2.8213104605674744e-01
    z[3,8,6]  R1350     -1.6030804812908173e-01
    z[3,8,6]  R1351     2.5406202673912048e-01
    z[3,8,6]  R1352     -2.9143482446670532e-01
    z[3,8,6]  R1353     -1.5985479950904846e-01
    z[3,8,6]  R1354     4.9594348669052124e-01
    z[3,8,6]  R1355     -4.8691403120756149e-02
    z[3,8,6]  R1356     -2.0474494993686676e-01
    z[3,8,6]  R1357     0.178403839468956
    z[3,8,6]  R1358     -2.4913826584815979e-01
    z[3,8,6]  R1359     1.3315147161483765e-01
    z[3,8,6]  R1360     -1.4845924079418182e-01
    z[3,8,6]  R1361     -2.6704590767621994e-02
    z[3,8,6]  R1362     -3.8042172789573669e-01
    z[3,8,6]  R1363     2.1605546772480011e-01
    z[3,8,6]  R1364     -1.5994818508625031e-01
    z[3,8,6]  R1365     -3.8616311550140381e-01
    z[3,8,6]  R1366     -1.2715712189674377e-01
    z[3,8,6]  R1367     -7.8070342540740967e-02
    z[3,8,6]  R1368     -0.329046368598938
    z[3,8,6]  R1369     3.5990753769874573e-01
    z[8,3,0]  R29       1
    z[8,3,0]  R74       -1
    z[8,3,0]  R1370     -1
    z[8,3,0]  R1371     1
    z[8,3,0]  R1384     7.5349879264831543e-01
    z[8,3,0]  R1385     0.307144433259964
    z[8,3,0]  R1386     2.5218990445137024e-01
    z[8,3,0]  R1387     1.7160646617412567e-02
    z[8,3,0]  R1388     4.0592528879642487e-02
    z[8,3,0]  R1389     7.5310325622558594e-01
    z[8,3,0]  R1390     0.409322589635849
    z[8,3,0]  R1391     1.8494494259357452e-01
    z[8,3,0]  R1392     2.6719310879707336e-01
    z[8,3,0]  R1393     4.4634243845939636e-01
    z[8,3,0]  R1394     -3.0533054471015930e-01
    z[8,3,0]  R1395     -1.7112727463245392e-01
    z[8,3,0]  R1396     -3.9704239368438721e-01
    z[8,3,0]  R1397     -1.7034025490283966e-01
    z[8,3,0]  R1398     -1.6297745704650879e-01
    z[8,3,0]  R1399     -1.6063745319843292e-01
    z[8,3,0]  R1400     -1.8528106808662415e-01
    z[8,3,0]  R1401     -2.2841534018516541e-01
    z[8,3,0]  R1402     -2.7883759140968323e-01
    z[8,3,0]  R1403     -6.5518236160278320e-01
    z[8,3,0]  R1404     5.8571350574493408e-01
    z[8,3,0]  R1405     2.8354993462562561e-01
    z[8,3,0]  R1406     5.8395421504974365e-01
    z[8,3,0]  R1407     5.2461272478103638e-01
    z[8,3,0]  R1408     -5.0638926029205322e-01
    z[8,3,0]  R1409     4.8312941193580627e-01
    z[8,3,0]  R1410     6.8348360061645508e-01
    z[8,3,0]  R1411     4.1684523224830627e-01
    z[8,3,0]  R1412     -4.5816802978515625e-01
    z[8,3,0]  R1413     -0.49376380443573
    z[8,3,0]  R1414     6.7443841695785522e-01
    z[8,3,0]  R1415     7.0656412839889526e-01
    z[8,3,0]  R1416     -2.4325503408908844e-01
    z[8,3,0]  R1417     3.9420586079359055e-02
    z[8,3,0]  R1418     4.8067179322242737e-01
    z[8,3,0]  R1419     4.1502940654754639e-01
    z[8,3,0]  R1420     3.1739464402198792e-01
    z[8,3,0]  R1421     -4.0888100862503052e-01
    z[8,3,0]  R1422     3.8763949275016785e-01
    z[8,3,0]  R1423     -1.2355958670377731e-01
    z[8,3,0]  R1424     4.4388791918754578e-01
    z[8,3,0]  R1425     0.376607209444046
    z[8,3,0]  R1426     -3.8632029294967651e-01
    z[8,3,0]  R1427     -2.6457989215850830e-01
    z[8,3,0]  R1428     2.8549227118492126e-01
    z[8,3,0]  R1429     4.7952511906623840e-01
    z[8,3,0]  R1430     -6.6012746095657349e-01
    z[8,3,0]  R1431     -4.7437986731529236e-01
    z[8,3,0]  R1432     -4.8283296823501587e-01
    z[8,3,0]  R1433     6.6481798887252808e-01
    z[8,3,0]  R1434     -4.6925377845764160e-01
    z[8,3,0]  R1435     -0.33150514960289
    z[8,3,0]  R1436     -5.9620642662048340e-01
    z[8,3,0]  R1437     -5.3413516283035278e-01
    z[8,3,0]  R1438     -6.8876588344573975e-01
    z[8,3,0]  R1439     -6.0696613788604736e-01
    z[8,3,0]  R1440     -8.4953486919403076e-01
    z[8,3,0]  R1441     -3.9942458271980286e-01
    z[8,3,0]  R1442     9.1994702816009521e-01
    z[8,3,0]  R1443     8.8811534643173218e-01
    z[8,3,0]  R1444     -7.2577923536300659e-01
    z[8,3,0]  R1445     -0.519461452960968
    z[8,3,0]  R1446     4.1029435396194458e-01
    z[8,3,0]  R1447     -1.9557641819119453e-02
    z[8,3,0]  R1448     4.4595736265182495e-01
    z[8,3,0]  R1449     6.6566020250320435e-02
    z[8,3,0]  R1450     3.9135344326496124e-02
    z[8,3,0]  R1451     3.4614410996437073e-01
    z[8,3,0]  R1452     2.3814016953110695e-02
    z[8,3,0]  R1453     7.9699587821960449e-01
    z[8,3,0]  R1454     -6.4133369922637939e-01
    z[8,3,0]  R1455     -5.4724627733230591e-01
    z[8,3,0]  R1456     -0.620279848575592
    z[8,3,0]  R1457     3.0767804384231567e-01
    z[8,3,0]  R1458     3.8189122080802917e-01
    z[8,3,0]  R1459     -9.4968140125274658e-02
    z[8,3,0]  R1460     6.8948942422866821e-01
    z[8,3,0]  R1461     -6.1649329960346222e-02
    z[8,3,0]  R1462     4.1818743944168091e-01
    z[8,3,0]  R1463     9.6550965309143066e-01
    z[8,3,0]  R1464     -2.5130379199981689e-01
    z[8,3,0]  R1465     2.6442989706993103e-01
    z[8,3,0]  R1466     5.3732526302337646e-01
    z[8,3,0]  R1467     -2.8376492857933044e-01
    z[8,3,0]  R1468     9.0092593431472778e-01
    z[8,3,0]  R1469     8.6789494752883911e-01
    z[8,3,0]  R1470     8.5806202888488770e-01
    z[8,3,0]  R1471     8.2225483655929565e-01
    z[8,3,0]  R1472     0.821610689163208
    z[8,3,0]  R1473     8.3646327257156372e-01
    z[8,3,1]  R30       1
    z[8,3,1]  R75       -1
    z[8,3,1]  R1372     -1
    z[8,3,1]  R1373     1
    z[8,3,1]  R1384     5.3390890359878540e-01
    z[8,3,1]  R1385     -1.1291924118995667e-01
    z[8,3,1]  R1386     9.5239475369453430e-02
    z[8,3,1]  R1387     3.3926531672477722e-01
    z[8,3,1]  R1388     4.6290901303291321e-01
    z[8,3,1]  R1389     4.4603973627090454e-01
    z[8,3,1]  R1390     -3.7558069825172424e-01
    z[8,3,1]  R1391     -2.9839560389518738e-01
    z[8,3,1]  R1392     3.7120589613914490e-01
    z[8,3,1]  R1393     -2.6726689934730530e-01
    z[8,3,1]  R1394     -9.0453439950942993e-01
    z[8,3,1]  R1395     -9.1103643178939819e-01
    z[8,3,1]  R1396     -0.866890549659729
    z[8,3,1]  R1397     -9.0055418014526367e-01
    z[8,3,1]  R1398     -8.8076150417327881e-01
    z[8,3,1]  R1399     -8.8842248916625977e-01
    z[8,3,1]  R1400     -8.7182438373565674e-01
    z[8,3,1]  R1401     -0.855061948299408
    z[8,3,1]  R1402     -8.2966303825378418e-01
    z[8,3,1]  R1403     -7.3643636703491211e-01
    z[8,3,1]  R1404     -2.8715163469314575e-01
    z[8,3,1]  R1405     -1.7557007074356079e-01
    z[8,3,1]  R1406     -5.1222376525402069e-02
    z[8,3,1]  R1407     1.0439503192901611e-01
    z[8,3,1]  R1408     6.6497230529785156e-01
    z[8,3,1]  R1409     -7.8976178169250488e-01
    z[8,3,1]  R1410     -0.595569372177124
    z[8,3,1]  R1411     4.4834807515144348e-01
    z[8,3,1]  R1412     7.5294440984725952e-01
    z[8,3,1]  R1413     0.756111741065979
    z[8,3,1]  R1414     4.8174926638603210e-01
    z[8,3,1]  R1415     -2.0700308680534363e-01
    z[8,3,1]  R1416     3.3629408478736877e-01
    z[8,3,1]  R1417     -3.3663976192474365e-01
    z[8,3,1]  R1418     -1.3645662367343903e-01
    z[8,3,1]  R1419     4.5533582568168640e-01
    z[8,3,1]  R1420     -5.2777826786041260e-01
    z[8,3,1]  R1421     8.2022237777709961e-01
    z[8,3,1]  R1422     -5.9745508432388306e-01
    z[8,3,1]  R1423     -6.4928692579269409e-01
    z[8,3,1]  R1424     -4.7594240307807922e-01
    z[8,3,1]  R1425     -2.1905189752578735e-01
    z[8,3,1]  R1426     3.1492364406585693e-01
    z[8,3,1]  R1427     3.3113875985145569e-01
    z[8,3,1]  R1428     -7.1422350406646729e-01
    z[8,3,1]  R1429     -5.2346724271774292e-01
    z[8,3,1]  R1430     6.4730447530746460e-01
    z[8,3,1]  R1431     5.1535248756408691e-01
    z[8,3,1]  R1432     5.5950152873992920e-01
    z[8,3,1]  R1433     -4.5236143469810486e-01
    z[8,3,1]  R1434     -3.1371474266052246e-01
    z[8,3,1]  R1435     3.2901279628276825e-02
    z[8,3,1]  R1436     1.6907972097396851e-01
    z[8,3,1]  R1437     9.1157384216785431e-02
    z[8,3,1]  R1438     -2.7442991733551025e-01
    z[8,3,1]  R1439     4.0999788790941238e-02
    z[8,3,1]  R1440     1.7802091315388680e-02
    z[8,3,1]  R1441     -4.6836573630571365e-02
    z[8,3,1]  R1442     -1.0292798280715942e-01
    z[8,3,1]  R1443     -9.5199182629585266e-02
    z[8,3,1]  R1444     1.2362776324152946e-02
    z[8,3,1]  R1445     3.5043430328369141e-01
    z[8,3,1]  R1446     6.5007501840591431e-01
    z[8,3,1]  R1447     7.1344602108001709e-01
    z[8,3,1]  R1448     0.801207423210144
    z[8,3,1]  R1449     5.6806391477584839e-01
    z[8,3,1]  R1450     5.5044001340866089e-01
    z[8,3,1]  R1451     0.766588568687439
    z[8,3,1]  R1452     7.7620851993560791e-01
    z[8,3,1]  R1453     4.8600149154663086e-01
    z[8,3,1]  R1454     0.492839515209198
    z[8,3,1]  R1455     4.1238497942686081e-02
    z[8,3,1]  R1456     1.3178735971450806e-01
    z[8,3,1]  R1457     0.550700306892395
    z[8,3,1]  R1458     5.7686352729797363e-01
    z[8,3,1]  R1459     5.3804230690002441e-01
    z[8,3,1]  R1460     5.2287822961807251e-01
    z[8,3,1]  R1461     6.5635836124420166e-01
    z[8,3,1]  R1462     4.2095881700515747e-01
    z[8,3,1]  R1463     -1.2013946473598480e-01
    z[8,3,1]  R1464     7.3735463619232178e-01
    z[8,3,1]  R1465     6.0515117645263672e-01
    z[8,3,1]  R1466     5.4157292842864990e-01
    z[8,3,1]  R1467     4.7969511151313782e-01
    z[8,3,1]  R1468     3.0161522328853607e-02
    z[8,3,1]  R1469     -1.3235937058925629e-01
    z[8,3,1]  R1470     4.7759800218045712e-03
    z[8,3,1]  R1471     -1.7067900300025940e-01
    z[8,3,1]  R1472     -2.6218351721763611e-01
    z[8,3,1]  R1473     -1.3294726610183716e-01
    z[8,3,2]  R31       1
    z[8,3,2]  R76       -1
    z[8,3,2]  R1374     -1
    z[8,3,2]  R1375     1
    z[8,3,2]  R1384     -4.5283399522304535e-02
    z[8,3,2]  R1385     3.3473870158195496e-01
    z[8,3,2]  R1386     5.7471507787704468e-01
    z[8,3,2]  R1387     5.6111335754394531e-01
    z[8,3,2]  R1388     6.4216136932373047e-01
    z[8,3,2]  R1389     5.1232177764177322e-02
    z[8,3,2]  R1390     2.9302367568016052e-01
    z[8,3,2]  R1391     3.7862551212310791e-01
    z[8,3,2]  R1392     5.2351778745651245e-01
    z[8,3,2]  R1393     1.1340779066085815e-01
    z[8,3,2]  R1394     -3.4694414585828781e-02
    z[8,3,2]  R1395     -2.3301114141941071e-01
    z[8,3,2]  R1396     -5.4809297434985638e-03
    z[8,3,2]  R1397     -1.3062655925750732e-01
    z[8,3,2]  R1398     -3.1449711322784424e-01
    z[8,3,2]  R1399     -1.4832252264022827e-01
    z[8,3,2]  R1400     -1.4843389391899109e-01
    z[8,3,2]  R1401     -0.200262188911438
    z[8,3,2]  R1402     -2.0472073554992676e-01
    z[8,3,2]  R1403     2.5710277259349823e-02
    z[8,3,2]  R1404     4.2051258683204651e-01
    z[8,3,2]  R1405     5.9493917226791382e-01
    z[8,3,2]  R1406     2.7369165420532227e-01
    z[8,3,2]  R1407     7.1624934673309326e-01
    z[8,3,2]  R1408     4.4915539026260376e-01
    z[8,3,2]  R1409     1.2079031206667423e-02
    z[8,3,2]  R1410     -0.0837479680776596
    z[8,3,2]  R1411     -9.6484325826168060e-02
    z[8,3,2]  R1412     0.119090735912323
    z[8,3,2]  R1413     1.2360082007944584e-02
    z[8,3,2]  R1414     -0.00766489002853632
    z[8,3,2]  R1415     5.0639349222183228e-01
    z[8,3,2]  R1416     8.1966572999954224e-01
    z[8,3,2]  R1417     6.4619135856628418e-01
    z[8,3,2]  R1418     -2.9444175306707621e-03
    z[8,3,2]  R1419     6.7845833301544189e-01
    z[8,3,2]  R1420     1.3194097578525543e-01
    z[8,3,2]  R1421     1.8230533599853516e-01
    z[8,3,2]  R1422     0.210468590259552
    z[8,3,2]  R1423     5.4060208797454834e-01
    z[8,3,2]  R1424     3.1908458471298218e-01
    z[8,3,2]  R1425     3.0309337377548218e-01
    z[8,3,2]  R1426     7.4047005176544189e-01
    z[8,3,2]  R1427     5.6868463754653931e-01
    z[8,3,2]  R1428     2.9122796654701233e-01
    z[8,3,2]  R1429     5.1562881469726562e-01
    z[8,3,2]  R1430     1.3450199365615845e-01
    z[8,3,2]  R1431     1.6099503636360168e-01
    z[8,3,2]  R1432     -6.8838261067867279e-02
    z[8,3,2]  R1433     -4.3100094795227051e-01
    z[8,3,2]  R1434     7.7526587247848511e-01
    z[8,3,2]  R1435     8.9516741037368774e-01
    z[8,3,2]  R1436     3.5201448202133179e-01
    z[8,3,2]  R1437     5.7556211948394775e-01
    z[8,3,2]  R1438     2.4388627707958221e-01
    z[8,3,2]  R1439     1.9422550499439240e-01
    z[8,3,2]  R1440     2.5933519005775452e-01
    z[8,3,2]  R1441     0.202837273478508
    z[8,3,2]  R1442     3.2138973474502563e-01
    z[8,3,2]  R1443     4.2020189762115479e-01
    z[8,3,2]  R1444     -2.8708580136299133e-01
    z[8,3,2]  R1445     -4.6171575784683228e-02
    z[8,3,2]  R1446     -2.1103249490261078e-01
    z[8,3,2]  R1447     4.2556360363960266e-02
    z[8,3,2]  R1448     -3.3406227827072144e-02
    z[8,3,2]  R1449     -0.0990736186504364
    z[8,3,2]  R1450     1.3600957393646240e-01
    z[8,3,2]  R1451     1.1976634850725532e-03
    z[8,3,2]  R1452     0.0696486309170723
    z[8,3,2]  R1453     3.0957534909248352e-01
    z[8,3,2]  R1454     -1.2485025823116302e-01
    z[8,3,2]  R1455     -1.3977298513054848e-02
    z[8,3,2]  R1456     -0.208160862326622
    z[8,3,2]  R1457     8.8788039982318878e-02
    z[8,3,2]  R1458     -2.0874983072280884e-01
    z[8,3,2]  R1459     -7.1404181420803070e-02
    z[8,3,2]  R1460     -1.0149326175451279e-02
    z[8,3,2]  R1461     -2.1710006892681122e-01
    z[8,3,2]  R1462     3.2241743803024292e-01
    z[8,3,2]  R1463     -5.0627548247575760e-02
    z[8,3,2]  R1464     4.3066430091857910e-01
    z[8,3,2]  R1465     5.7679611444473267e-01
    z[8,3,2]  R1466     3.7671455740928650e-01
    z[8,3,2]  R1467     -1.7360439896583557e-01
    z[8,3,2]  R1468     1.0191214829683304e-01
    z[8,3,2]  R1469     1.2821683287620544e-01
    z[8,3,2]  R1470     -4.9768432974815369e-02
    z[8,3,2]  R1471     7.4249237775802612e-02
    z[8,3,2]  R1472     1.3735768198966980e-01
    z[8,3,2]  R1473     -1.8188828229904175e-01
    z[8,3,3]  R32       1
    z[8,3,3]  R77       -1
    z[8,3,3]  R1376     -1
    z[8,3,3]  R1377     1
    z[8,3,3]  R1384     2.9557514190673828e-01
    z[8,3,3]  R1385     0.511228084564209
    z[8,3,3]  R1386     3.1941589713096619e-01
    z[8,3,3]  R1387     1.8191672861576080e-01
    z[8,3,3]  R1388     2.5957101583480835e-01
    z[8,3,3]  R1389     -1.8496680259704590e-01
    z[8,3,3]  R1390     2.1793392300605774e-01
    z[8,3,3]  R1391     2.8237605094909668e-01
    z[8,3,3]  R1392     3.6248272657394409e-01
    z[8,3,3]  R1393     1.5013046562671661e-01
    z[8,3,3]  R1394     -2.2524642944335938e-01
    z[8,3,3]  R1395     1.7526608705520630e-01
    z[8,3,3]  R1396     -1.3580419123172760e-01
    z[8,3,3]  R1397     1.3678257167339325e-01
    z[8,3,3]  R1398     -3.9878997951745987e-02
    z[8,3,3]  R1399     1.4355589635670185e-02
    z[8,3,3]  R1400     2.3384894430637360e-01
    z[8,3,3]  R1401     -3.0689659714698792e-01
    z[8,3,3]  R1402     -2.2202888131141663e-01
    z[8,3,3]  R1403     0.027417017146945
    z[8,3,3]  R1404     3.6058798432350159e-01
    z[8,3,3]  R1405     6.0836231708526611e-01
    z[8,3,3]  R1406     4.7131389379501343e-01
    z[8,3,3]  R1407     0.214554101228714
    z[8,3,3]  R1408     1.1563784629106522e-01
    z[8,3,3]  R1409     2.9142510890960693e-01
    z[8,3,3]  R1410     -1.1412892490625381e-02
    z[8,3,3]  R1411     -3.6228007078170776e-01
    z[8,3,3]  R1412     -3.9543735980987549e-01
    z[8,3,3]  R1413     -1.8169339001178741e-01
    z[8,3,3]  R1414     -4.5411369204521179e-01
    z[8,3,3]  R1415     3.3606874942779541e-01
    z[8,3,3]  R1416     2.1002674102783203e-01
    z[8,3,3]  R1417     5.6889343261718750e-01
    z[8,3,3]  R1418     4.3332943320274353e-01
    z[8,3,3]  R1419     3.4539647400379181e-02
    z[8,3,3]  R1420     3.5232019424438477e-01
    z[8,3,3]  R1421     4.5969886705279350e-03
    z[8,3,3]  R1422     1.3093477487564087e-01
    z[8,3,3]  R1423     2.0541979372501373e-01
    z[8,3,3]  R1424     3.0937123298645020e-01
    z[8,3,3]  R1425     4.8632130026817322e-01
    z[8,3,3]  R1426     2.3699489235877991e-01
    z[8,3,3]  R1427     6.1725121736526489e-01
    z[8,3,3]  R1428     3.8626599311828613e-01
    z[8,3,3]  R1429     -1.5872826799750328e-02
    z[8,3,3]  R1430     -2.7297082543373108e-01
    z[8,3,3]  R1431     -3.3678501844406128e-01
    z[8,3,3]  R1432     -3.4425669908523560e-01
    z[8,3,3]  R1433     -5.6831665337085724e-02
    z[8,3,3]  R1434     0.07901581376791
    z[8,3,3]  R1435     0.14643594622612
    z[8,3,3]  R1436     1.8404580652713776e-01
    z[8,3,3]  R1437     -4.8148915171623230e-01
    z[8,3,3]  R1438     -2.5568547844886780e-01
    z[8,3,3]  R1439     1.2257728725671768e-01
    z[8,3,3]  R1440     -2.2818391025066376e-01
    z[8,3,3]  R1441     -3.1830493360757828e-02
    z[8,3,3]  R1442     8.9937351644039154e-02
    z[8,3,3]  R1443     -1.0073759406805038e-01
    z[8,3,3]  R1444     1.3321955502033234e-01
    z[8,3,3]  R1445     6.0039076954126358e-02
    z[8,3,3]  R1446     -9.3716740608215332e-02
    z[8,3,3]  R1447     4.2428936809301376e-02
    z[8,3,3]  R1448     -3.1878617405891418e-01
    z[8,3,3]  R1449     -6.2994378805160522e-01
    z[8,3,3]  R1450     9.8014205694198608e-02
    z[8,3,3]  R1451     -1.7204432189464569e-01
    z[8,3,3]  R1452     -1.6432275995612144e-02
    z[8,3,3]  R1453     5.1976222544908524e-02
    z[8,3,3]  R1454     -1.6308794915676117e-01
    z[8,3,3]  R1455     2.9764357209205627e-01
    z[8,3,3]  R1456     -5.3639984130859375e-01
    z[8,3,3]  R1457     -1.9266603887081146e-01
    z[8,3,3]  R1458     0.067952461540699
    z[8,3,3]  R1459     -1.9458861649036407e-01
    z[8,3,3]  R1460     3.9981618523597717e-01
    z[8,3,3]  R1461     -5.7392424345016479e-01
    z[8,3,3]  R1462     1.0243978351354599e-01
    z[8,3,3]  R1463     -1.8930040299892426e-02
    z[8,3,3]  R1464     -3.2287371158599854e-01
    z[8,3,3]  R1465     -1.6707479953765869e-01
    z[8,3,3]  R1466     2.4766427278518677e-01
    z[8,3,3]  R1467     7.4058908224105835e-01
    z[8,3,3]  R1468     -2.1980394423007965e-01
    z[8,3,3]  R1469     1.7972676083445549e-02
    z[8,3,3]  R1470     -2.1149446070194244e-01
    z[8,3,3]  R1471     -6.3981473445892334e-02
    z[8,3,3]  R1472     1.6020385921001434e-01
    z[8,3,3]  R1473     -4.2409861087799072e-01
    z[8,3,4]  R33       1
    z[8,3,4]  R78       -1
    z[8,3,4]  R1378     -1
    z[8,3,4]  R1379     1
    z[8,3,4]  R1384     1.4715710654854774e-02
    z[8,3,4]  R1385     -4.6450448036193848e-01
    z[8,3,4]  R1386     -5.1308578252792358e-01
    z[8,3,4]  R1387     -6.5982139110565186e-01
    z[8,3,4]  R1388     -4.9314025044441223e-01
    z[8,3,4]  R1389     4.0272939950227737e-03
    z[8,3,4]  R1390     -6.1621171236038208e-01
    z[8,3,4]  R1391     -6.7005592584609985e-01
    z[8,3,4]  R1392     -6.1298555135726929e-01
    z[8,3,4]  R1393     -7.7415800094604492e-01
    z[8,3,4]  R1394     9.8041877150535583e-02
    z[8,3,4]  R1395     0.0976729765534401
    z[8,3,4]  R1396     5.9816960245370865e-02
    z[8,3,4]  R1397     3.2650753855705261e-01
    z[8,3,4]  R1398     -5.2045132964849472e-02
    z[8,3,4]  R1399     9.0918548405170441e-02
    z[8,3,4]  R1400     3.1808158755302429e-01
    z[8,3,4]  R1401     -1.0641106218099594e-01
    z[8,3,4]  R1402     2.3723126947879791e-01
    z[8,3,4]  R1403     5.1848553121089935e-03
    z[8,3,4]  R1404     0.232549786567688
    z[8,3,4]  R1405     2.1865151822566986e-01
    z[8,3,4]  R1406     1.2797074019908905e-01
    z[8,3,4]  R1407     1.5356892347335815e-01
    z[8,3,4]  R1408     4.4284559786319733e-02
    z[8,3,4]  R1409     1.8996295332908630e-01
    z[8,3,4]  R1410     6.6601976752281189e-02
    z[8,3,4]  R1411     -1.3420465588569641e-01
    z[8,3,4]  R1412     4.3489160016179085e-03
    z[8,3,4]  R1413     1.7702130600810051e-02
    z[8,3,4]  R1414     -1.3463121652603149e-01
    z[8,3,4]  R1415     -1.4478822052478790e-01
    z[8,3,4]  R1416     1.0083559900522232e-01
    z[8,3,4]  R1417     2.5494772195816040e-01
    z[8,3,4]  R1418     -5.0143241882324219e-01
    z[8,3,4]  R1419     6.1852414160966873e-02
    z[8,3,4]  R1420     3.2360956072807312e-01
    z[8,3,4]  R1421     -2.4408391118049622e-01
    z[8,3,4]  R1422     4.0664246678352356e-01
    z[8,3,4]  R1423     5.5780843831598759e-03
    z[8,3,4]  R1424     -5.4525423049926758e-01
    z[8,3,4]  R1425     2.4329267442226410e-01
    z[8,3,4]  R1426     -4.4477835297584534e-02
    z[8,3,4]  R1427     2.0227548480033875e-01
    z[8,3,4]  R1428     3.0241009593009949e-01
    z[8,3,4]  R1429     1.7804567515850067e-01
    z[8,3,4]  R1430     9.8191395401954651e-02
    z[8,3,4]  R1431     -0.257386714220047
    z[8,3,4]  R1432     -4.1155639290809631e-01
    z[8,3,4]  R1433     -1.6819517314434052e-01
    z[8,3,4]  R1434     -1.5118260681629181e-01
    z[8,3,4]  R1435     -1.2110810726881027e-01
    z[8,3,4]  R1436     3.0696511268615723e-01
    z[8,3,4]  R1437     9.3824982643127441e-02
    z[8,3,4]  R1438     5.6252223253250122e-01
    z[8,3,4]  R1439     4.5384871959686279e-01
    z[8,3,4]  R1440     3.0659487843513489e-01
    z[8,3,4]  R1441     -2.3273593187332153e-01
    z[8,3,4]  R1442     -1.6773466765880585e-01
    z[8,3,4]  R1443     -1.9281828776001930e-02
    z[8,3,4]  R1444     -3.8209676742553711e-01
    z[8,3,4]  R1445     -6.9468045234680176e-01
    z[8,3,4]  R1446     -1.7974703013896942e-01
    z[8,3,4]  R1447     -2.7379241585731506e-01
    z[8,3,4]  R1448     -6.6507525742053986e-02
    z[8,3,4]  R1449     2.2297158837318420e-01
    z[8,3,4]  R1450     -2.7357056736946106e-01
    z[8,3,4]  R1451     2.1131275594234467e-01
    z[8,3,4]  R1452     -2.1221134066581726e-01
    z[8,3,4]  R1453     3.5109922289848328e-02
    z[8,3,4]  R1454     -0.242910698056221
    z[8,3,4]  R1455     -6.4958351850509644e-01
    z[8,3,4]  R1456     -8.3872549235820770e-02
    z[8,3,4]  R1457     2.5922521948814392e-01
    z[8,3,4]  R1458     5.6454139947891235e-01
    z[8,3,4]  R1459     7.3291277885437012e-01
    z[8,3,4]  R1460     1.1814720183610916e-01
    z[8,3,4]  R1461     2.6722148060798645e-01
    z[8,3,4]  R1462     3.0719587206840515e-01
    z[8,3,4]  R1463     -5.8366615325212479e-02
    z[8,3,4]  R1464     -2.9494842886924744e-01
    z[8,3,4]  R1465     -1.6150401532649994e-01
    z[8,3,4]  R1466     -1.4807645976543427e-01
    z[8,3,4]  R1467     1.3833388686180115e-01
    z[8,3,4]  R1468     -1.4137434959411621e-01
    z[8,3,4]  R1469     8.2156389951705933e-02
    z[8,3,4]  R1470     2.8801393508911133e-01
    z[8,3,4]  R1471     4.7589689493179321e-01
    z[8,3,4]  R1472     3.6816483736038208e-01
    z[8,3,4]  R1473     1.2181729823350906e-01
    z[8,3,5]  R34       1
    z[8,3,5]  R79       -1
    z[8,3,5]  R1380     -1
    z[8,3,5]  R1381     1
    z[8,3,5]  R1384     -2.2283443808555603e-01
    z[8,3,5]  R1385     -4.2021080851554871e-01
    z[8,3,5]  R1386     -2.4339118599891663e-01
    z[8,3,5]  R1387     1.6859647631645203e-01
    z[8,3,5]  R1388     -8.5380002856254578e-02
    z[8,3,5]  R1389     -2.5385084748268127e-01
    z[8,3,5]  R1390     1.5152811072766781e-02
    z[8,3,5]  R1391     0.334398090839386
    z[8,3,5]  R1392     5.7299923151731491e-02
    z[8,3,5]  R1393     1.1835353076457977e-01
    z[8,3,5]  R1394     -1.6442918777465820e-01
    z[8,3,5]  R1395     -1.0862501710653305e-01
    z[8,3,5]  R1396     4.9955964088439941e-02
    z[8,3,5]  R1397     -1.2794810533523560e-01
    z[8,3,5]  R1398     -2.8526043891906738e-01
    z[8,3,5]  R1399     -3.8474711775779724e-01
    z[8,3,5]  R1400     1.3758680224418640e-01
    z[8,3,5]  R1401     2.8761990368366241e-02
    z[8,3,5]  R1402     2.3101963102817535e-01
    z[8,3,5]  R1403     1.3659349083900452e-01
    z[8,3,5]  R1404     -5.3563795983791351e-02
    z[8,3,5]  R1405     -1.1258027702569962e-01
    z[8,3,5]  R1406     -3.9664259552955627e-01
    z[8,3,5]  R1407     -3.5026380419731140e-01
    z[8,3,5]  R1408     2.3329722881317139e-01
    z[8,3,5]  R1409     -1.4275322854518890e-01
    z[8,3,5]  R1410     -3.8245955109596252e-01
    z[8,3,5]  R1411     6.7891335487365723e-01
    z[8,3,5]  R1412     0.228000208735466
    z[8,3,5]  R1413     2.6723757386207581e-01
    z[8,3,5]  R1414     2.5089517235755920e-01
    z[8,3,5]  R1415     -5.5038008838891983e-02
    z[8,3,5]  R1416     -1.2910473346710205e-01
    z[8,3,5]  R1417     -2.3100826144218445e-01
    z[8,3,5]  R1418     2.5525811314582825e-01
    z[8,3,5]  R1419     3.9080002903938293e-01
    z[8,3,5]  R1420     -5.7665330171585083e-01
    z[8,3,5]  R1421     1.8812340497970581e-01
    z[8,3,5]  R1422     -0.451568603515625
    z[8,3,5]  R1423     4.5929422974586487e-01
    z[8,3,5]  R1424     2.4407865107059479e-01
    z[8,3,5]  R1425     -6.4954203367233276e-01
    z[8,3,5]  R1426     -2.0454682409763336e-02
    z[8,3,5]  R1427     -1.6836887598037720e-01
    z[8,3,5]  R1428     -2.3943383991718292e-01
    z[8,3,5]  R1429     -2.2156395018100739e-01
    z[8,3,5]  R1430     1.6375060379505157e-01
    z[8,3,5]  R1431     5.4560887813568115e-01
    z[8,3,5]  R1432     2.3006257414817810e-01
    z[8,3,5]  R1433     8.1063613295555115e-02
    z[8,3,5]  R1434     1.4710752665996552e-01
    z[8,3,5]  R1435     5.5916242301464081e-02
    z[8,3,5]  R1436     -4.3696433305740356e-01
    z[8,3,5]  R1437     1.7973285913467407e-01
    z[8,3,5]  R1438     5.2761003375053406e-02
    z[8,3,5]  R1439     -4.1906601190567017e-01
    z[8,3,5]  R1440     -2.1328464150428772e-01
    z[8,3,5]  R1441     -3.1065386533737183e-01
    z[8,3,5]  R1442     -3.6468520760536194e-02
    z[8,3,5]  R1443     2.5497859343886375e-02
    z[8,3,5]  R1444     4.7373014688491821e-01
    z[8,3,5]  R1445     3.4413686394691467e-01
    z[8,3,5]  R1446     1.0588242113590240e-01
    z[8,3,5]  R1447     -5.6741183996200562e-01
    z[8,3,5]  R1448     -1.9991537928581238e-01
    z[8,3,5]  R1449     4.0387919545173645e-01
    z[8,3,5]  R1450     4.9634307622909546e-01
    z[8,3,5]  R1451     -3.8713118433952332e-01
    z[8,3,5]  R1452     6.3142009079456329e-02
    z[8,3,5]  R1453     -3.2969031017273664e-03
    z[8,3,5]  R1454     3.0698272585868835e-01
    z[8,3,5]  R1455     -1.0310070216655731e-01
    z[8,3,5]  R1456     4.5047125220298767e-01
    z[8,3,5]  R1457     6.7605400085449219e-01
    z[8,3,5]  R1458     1.3374383747577667e-01
    z[8,3,5]  R1459     3.3290737867355347e-01
    z[8,3,5]  R1460     -0.0471990704536438
    z[8,3,5]  R1461     -2.4472513794898987e-01
    z[8,3,5]  R1462     -2.2847951948642731e-01
    z[8,3,5]  R1463     1.9362162053585052e-01
    z[8,3,5]  R1464     1.2813235819339752e-01
    z[8,3,5]  R1465     -2.9364410042762756e-01
    z[8,3,5]  R1466     3.1093168258666992e-01
    z[8,3,5]  R1467     2.8522640466690063e-01
    z[8,3,5]  R1468     -2.9728201031684875e-01
    z[8,3,5]  R1469     -3.9887115359306335e-01
    z[8,3,5]  R1470     -1.6919489204883575e-01
    z[8,3,5]  R1471     -2.6922725141048431e-02
    z[8,3,5]  R1472     -1.3203187286853790e-01
    z[8,3,5]  R1473     -1.9959259033203125e-01
    z[8,3,6]  R35       1
    z[8,3,6]  R80       -1
    z[8,3,6]  R1382     -1
    z[8,3,6]  R1383     1
    z[8,3,6]  R1384     -8.8847614824771881e-02
    z[8,3,6]  R1385     -3.5660311579704285e-01
    z[8,3,6]  R1386     -4.1534259915351868e-01
    z[8,3,6]  R1387     -2.6995116472244263e-01
    z[8,3,6]  R1388     -2.3203879594802856e-01
    z[8,3,6]  R1389     3.6412918567657471e-01
    z[8,3,6]  R1390     -4.2200666666030884e-01
    z[8,3,6]  R1391     -3.0473735928535461e-01
    z[8,3,6]  R1392     0.0794663280248642
    z[8,3,6]  R1393     -2.8393331170082092e-01
    z[8,3,6]  R1394     1.3920005876570940e-03
    z[8,3,6]  R1395     1.8540833890438080e-01
    z[8,3,6]  R1396     -2.5751054286956787e-01
    z[8,3,6]  R1397     3.5152930766344070e-02
    z[8,3,6]  R1398     1.1452741920948029e-01
    z[8,3,6]  R1399     7.9993076622486115e-02
    z[8,3,6]  R1400     9.3643620610237122e-02
    z[8,3,6]  R1401     2.6505556702613831e-01
    z[8,3,6]  R1402     1.8180431425571442e-01
    z[8,3,6]  R1403     9.1106317937374115e-02
    z[8,3,6]  R1404     4.5899960398674011e-01
    z[8,3,6]  R1405     3.2285347580909729e-01
    z[8,3,6]  R1406     4.3084564805030823e-01
    z[8,3,6]  R1407     9.2565260827541351e-02
    z[8,3,6]  R1408     1.7285913228988647e-01
    z[8,3,6]  R1409     3.6376565694808960e-02
    z[8,3,6]  R1410     -1.4245083928108215e-01
    z[8,3,6]  R1411     -7.5721487402915955e-02
    z[8,3,6]  R1412     2.4506205692887306e-02
    z[8,3,6]  R1413     2.8213104605674744e-01
    z[8,3,6]  R1414     -1.6030804812908173e-01
    z[8,3,6]  R1415     2.5406202673912048e-01
    z[8,3,6]  R1416     -2.9143482446670532e-01
    z[8,3,6]  R1417     -1.5985479950904846e-01
    z[8,3,6]  R1418     4.9594348669052124e-01
    z[8,3,6]  R1419     -4.8691403120756149e-02
    z[8,3,6]  R1420     -2.0474494993686676e-01
    z[8,3,6]  R1421     0.178403839468956
    z[8,3,6]  R1422     -2.4913826584815979e-01
    z[8,3,6]  R1423     1.3315147161483765e-01
    z[8,3,6]  R1424     -1.4845924079418182e-01
    z[8,3,6]  R1425     -2.6704590767621994e-02
    z[8,3,6]  R1426     -3.8042172789573669e-01
    z[8,3,6]  R1427     2.1605546772480011e-01
    z[8,3,6]  R1428     -1.5994818508625031e-01
    z[8,3,6]  R1429     -3.8616311550140381e-01
    z[8,3,6]  R1430     -1.2715712189674377e-01
    z[8,3,6]  R1431     -7.8070342540740967e-02
    z[8,3,6]  R1432     -0.329046368598938
    z[8,3,6]  R1433     3.5990753769874573e-01
    z[8,3,6]  R1434     1.7206548154354095e-01
    z[8,3,6]  R1435     -2.2013604640960693e-01
    z[8,3,6]  R1436     -4.1592967510223389e-01
    z[8,3,6]  R1437     3.1965491175651550e-01
    z[8,3,6]  R1438     -7.8862540423870087e-02
    z[8,3,6]  R1439     4.4223007559776306e-01
    z[8,3,6]  R1440     1.3842076063156128e-01
    z[8,3,6]  R1441     8.0339181423187256e-01
    z[8,3,6]  R1442     -4.7521837055683136e-02
    z[8,3,6]  R1443     1.2020229548215866e-01
    z[8,3,6]  R1444     -5.0076227635145187e-02
    z[8,3,6]  R1445     -2.4653879925608635e-02
    z[8,3,6]  R1446     5.5876958370208740e-01
    z[8,3,6]  R1447     3.0013734102249146e-01
    z[8,3,6]  R1448     1.0981138795614243e-01
    z[8,3,6]  R1449     -2.3106880486011505e-01
    z[8,3,6]  R1450     -5.8837193250656128e-01
    z[8,3,6]  R1451     -2.6153776049613953e-01
    z[8,3,6]  R1452     -5.8548414707183838e-01
    z[8,3,6]  R1453     -1.6975912451744080e-01
    z[8,3,6]  R1454     -3.8777709007263184e-01
    z[8,3,6]  R1455     4.2124241590499878e-01
    z[8,3,6]  R1456     2.3847469687461853e-01
    z[8,3,6]  R1457     1.8114395439624786e-01
    z[8,3,6]  R1458     3.6959323287010193e-01
    z[8,3,6]  R1459     -1.0266353935003281e-01
    z[8,3,6]  R1460     -2.7397081255912781e-01
    z[8,3,6]  R1461     2.3994588851928711e-01
    z[8,3,6]  R1462     6.2200784683227539e-01
    z[8,3,6]  R1463     9.7674198448657990e-02
    z[8,3,6]  R1464     -4.7831791453063488e-03
    z[8,3,6]  R1465     3.0158025026321411e-01
    z[8,3,6]  R1466     3.1003820896148682e-01
    z[8,3,6]  R1467     1.0133621096611023e-01
    z[8,3,6]  R1468     1.4268645644187927e-01
    z[8,3,6]  R1469     2.1593706309795380e-01
    z[8,3,6]  R1470     -3.2391491532325745e-01
    z[8,3,6]  R1471     -2.4074141681194305e-01
    z[8,3,6]  R1472     -2.4229244887828827e-01
    z[8,3,6]  R1473     1.2261576205492020e-01
    z[3,9,0]  R29       -1
    z[3,9,0]  R83       1
    z[3,9,0]  R1474     -1
    z[3,9,0]  R1475     1
    z[3,9,0]  R1488     -4.6925377845764160e-01
    z[3,9,0]  R1489     -0.33150514960289
    z[3,9,0]  R1490     -5.9620642662048340e-01
    z[3,9,0]  R1491     -5.3413516283035278e-01
    z[3,9,0]  R1492     -6.8876588344573975e-01
    z[3,9,0]  R1493     -6.0696613788604736e-01
    z[3,9,0]  R1494     -8.4953486919403076e-01
    z[3,9,0]  R1495     -3.9942458271980286e-01
    z[3,9,0]  R1496     9.1994702816009521e-01
    z[3,9,0]  R1497     8.8811534643173218e-01
    z[3,9,0]  R1498     -7.2577923536300659e-01
    z[3,9,0]  R1499     -0.519461452960968
    z[3,9,0]  R1500     4.1029435396194458e-01
    z[3,9,0]  R1501     -1.9557641819119453e-02
    z[3,9,0]  R1502     4.4595736265182495e-01
    z[3,9,0]  R1503     6.6566020250320435e-02
    z[3,9,0]  R1504     3.9135344326496124e-02
    z[3,9,0]  R1505     3.4614410996437073e-01
    z[3,9,0]  R1506     2.3814016953110695e-02
    z[3,9,0]  R1507     7.9699587821960449e-01
    z[3,9,0]  R1508     -6.4133369922637939e-01
    z[3,9,0]  R1509     -5.4724627733230591e-01
    z[3,9,0]  R1510     -0.620279848575592
    z[3,9,0]  R1511     3.0767804384231567e-01
    z[3,9,0]  R1512     3.8189122080802917e-01
    z[3,9,0]  R1513     -9.4968140125274658e-02
    z[3,9,0]  R1514     6.8948942422866821e-01
    z[3,9,0]  R1515     -6.1649329960346222e-02
    z[3,9,0]  R1516     4.1818743944168091e-01
    z[3,9,0]  R1517     9.6550965309143066e-01
    z[3,9,0]  R1518     -2.5130379199981689e-01
    z[3,9,0]  R1519     2.6442989706993103e-01
    z[3,9,0]  R1520     5.3732526302337646e-01
    z[3,9,0]  R1521     -2.8376492857933044e-01
    z[3,9,0]  R1522     9.0092593431472778e-01
    z[3,9,0]  R1523     8.6789494752883911e-01
    z[3,9,0]  R1524     8.5806202888488770e-01
    z[3,9,0]  R1525     8.2225483655929565e-01
    z[3,9,0]  R1526     0.821610689163208
    z[3,9,0]  R1527     8.3646327257156372e-01
    z[3,9,0]  R1528     -4.7083017230033875e-01
    z[3,9,0]  R1529     -2.9554355144500732e-01
    z[3,9,0]  R1530     -4.5847481489181519e-01
    z[3,9,0]  R1531     -3.4898281097412109e-01
    z[3,9,0]  R1532     -3.4378483891487122e-01
    z[3,9,0]  R1533     -4.1573926806449890e-01
    z[3,9,0]  R1534     -3.2152774930000305e-01
    z[3,9,0]  R1535     -2.9459995031356812e-01
    z[3,9,0]  R1536     -4.6038252115249634e-01
    z[3,9,0]  R1537     -3.3345550298690796e-01
    z[3,9,0]  R1538     9.6774977445602417e-01
    z[3,9,0]  R1539     9.2610377073287964e-01
    z[3,9,0]  R1540     9.3839341402053833e-01
    z[3,9,0]  R1541     0.913361668586731
    z[3,9,0]  R1542     -5.5221021175384521e-01
    z[3,9,0]  R1543     9.2324179410934448e-01
    z[3,9,0]  R1544     8.7861239910125732e-01
    z[3,9,0]  R1545     8.6381405591964722e-01
    z[3,9,0]  R1546     -5.0134289264678955e-01
    z[3,9,0]  R1547     2.2638149559497833e-01
    z[3,9,0]  R1548     -9.0156745910644531e-01
    z[3,9,0]  R1549     -6.7771470546722412e-01
    z[3,9,0]  R1550     -0.654639482498169
    z[3,9,0]  R1551     -4.5600414276123047e-01
    z[3,9,0]  R1552     -5.2531290054321289e-01
    z[3,9,0]  R1553     -1.3764478266239166e-01
    z[3,9,0]  R1554     1.3541062362492085e-02
    z[3,9,0]  R1555     -4.0826670825481415e-02
    z[3,9,0]  R1556     -3.0490857362747192e-01
    z[3,9,0]  R1557     4.8627230525016785e-01
    z[3,9,0]  R1558     -1.3738344609737396e-01
    z[3,9,0]  R1559     1.5904630720615387e-01
    z[3,9,0]  R1560     2.5986087322235107e-01
    z[3,9,0]  R1561     0.145345538854599
    z[3,9,0]  R1562     2.4203133583068848e-01
    z[3,9,0]  R1563     5.2579408884048462e-01
    z[3,9,0]  R1564     3.9317697286605835e-01
    z[3,9,0]  R1565     4.3037596344947815e-01
    z[3,9,0]  R1566     2.6960945129394531e-01
    z[3,9,0]  R1567     0.500088095664978
    z[3,9,0]  R1568     8.1707149744033813e-02
    z[3,9,0]  R1569     2.7697938680648804e-01
    z[3,9,0]  R1570     3.6197766661643982e-01
    z[3,9,0]  R1571     7.8655153512954712e-02
    z[3,9,0]  R1572     4.1394266486167908e-01
    z[3,9,0]  R1573     3.3076366782188416e-01
    z[3,9,0]  R1574     3.3056697249412537e-01
    z[3,9,0]  R1575     2.4081142246723175e-01
    z[3,9,0]  R1576     3.9070203900337219e-01
    z[3,9,0]  R1577     3.9883446693420410e-01
    z[3,9,1]  R30       -1
    z[3,9,1]  R84       1
    z[3,9,1]  R1476     -1
    z[3,9,1]  R1477     1
    z[3,9,1]  R1488     -3.1371474266052246e-01
    z[3,9,1]  R1489     3.2901279628276825e-02
    z[3,9,1]  R1490     1.6907972097396851e-01
    z[3,9,1]  R1491     9.1157384216785431e-02
    z[3,9,1]  R1492     -2.7442991733551025e-01
    z[3,9,1]  R1493     4.0999788790941238e-02
    z[3,9,1]  R1494     1.7802091315388680e-02
    z[3,9,1]  R1495     -4.6836573630571365e-02
    z[3,9,1]  R1496     -1.0292798280715942e-01
    z[3,9,1]  R1497     -9.5199182629585266e-02
    z[3,9,1]  R1498     1.2362776324152946e-02
    z[3,9,1]  R1499     3.5043430328369141e-01
    z[3,9,1]  R1500     6.5007501840591431e-01
    z[3,9,1]  R1501     7.1344602108001709e-01
    z[3,9,1]  R1502     0.801207423210144
    z[3,9,1]  R1503     5.6806391477584839e-01
    z[3,9,1]  R1504     5.5044001340866089e-01
    z[3,9,1]  R1505     0.766588568687439
    z[3,9,1]  R1506     7.7620851993560791e-01
    z[3,9,1]  R1507     4.8600149154663086e-01
    z[3,9,1]  R1508     0.492839515209198
    z[3,9,1]  R1509     4.1238497942686081e-02
    z[3,9,1]  R1510     1.3178735971450806e-01
    z[3,9,1]  R1511     0.550700306892395
    z[3,9,1]  R1512     5.7686352729797363e-01
    z[3,9,1]  R1513     5.3804230690002441e-01
    z[3,9,1]  R1514     5.2287822961807251e-01
    z[3,9,1]  R1515     6.5635836124420166e-01
    z[3,9,1]  R1516     4.2095881700515747e-01
    z[3,9,1]  R1517     -1.2013946473598480e-01
    z[3,9,1]  R1518     7.3735463619232178e-01
    z[3,9,1]  R1519     6.0515117645263672e-01
    z[3,9,1]  R1520     5.4157292842864990e-01
    z[3,9,1]  R1521     4.7969511151313782e-01
    z[3,9,1]  R1522     3.0161522328853607e-02
    z[3,9,1]  R1523     -1.3235937058925629e-01
    z[3,9,1]  R1524     4.7759800218045712e-03
    z[3,9,1]  R1525     -1.7067900300025940e-01
    z[3,9,1]  R1526     -2.6218351721763611e-01
    z[3,9,1]  R1527     -1.3294726610183716e-01
    z[3,9,1]  R1528     3.2166350632905960e-02
    z[3,9,1]  R1529     0.0396723710000515
    z[3,9,1]  R1530     8.4040112793445587e-02
    z[3,9,1]  R1531     -8.3546109497547150e-02
    z[3,9,1]  R1532     -1.7947475612163544e-01
    z[3,9,1]  R1533     -4.4269564747810364e-01
    z[3,9,1]  R1534     -3.2941896468400955e-02
    z[3,9,1]  R1535     3.1364038586616516e-01
    z[3,9,1]  R1536     7.9319693148136139e-02
    z[3,9,1]  R1537     -2.8139597177505493e-01
    z[3,9,1]  R1538     2.0339037477970123e-01
    z[3,9,1]  R1539     2.5800153613090515e-01
    z[3,9,1]  R1540     1.5622794628143311e-01
    z[3,9,1]  R1541     2.4087810516357422e-01
    z[3,9,1]  R1542     2.5549891591072083e-01
    z[3,9,1]  R1543     1.9792918860912323e-01
    z[3,9,1]  R1544     2.9791086912155151e-01
    z[3,9,1]  R1545     2.5721102952957153e-01
    z[3,9,1]  R1546     -1.3574388623237610e-01
    z[3,9,1]  R1547     4.6913331747055054e-01
    z[3,9,1]  R1548     -1.8754141032695770e-01
    z[3,9,1]  R1549     0.230122908949852
    z[3,9,1]  R1550     1.6657446324825287e-01
    z[3,9,1]  R1551     1.3152468204498291e-01
    z[3,9,1]  R1552     4.8701906204223633e-01
    z[3,9,1]  R1553     0.788979172706604
    z[3,9,1]  R1554     6.9596582651138306e-01
    z[3,9,1]  R1555     7.3576313257217407e-01
    z[3,9,1]  R1556     7.1478289365768433e-01
    z[3,9,1]  R1557     6.8016147613525391e-01
    z[3,9,1]  R1558     6.5989780426025391e-01
    z[3,9,1]  R1559     6.5643984079360962e-01
    z[3,9,1]  R1560     6.2312871217727661e-01
    z[3,9,1]  R1561     6.6643327474594116e-01
    z[3,9,1]  R1562     5.7647407054901123e-01
    z[3,9,1]  R1563     6.2587428092956543e-01
    z[3,9,1]  R1564     5.4993522167205811e-01
    z[3,9,1]  R1565     6.0498905181884766e-01
    z[3,9,1]  R1566     5.7798069715499878e-01
    z[3,9,1]  R1567     6.0623961687088013e-01
    z[3,9,1]  R1568     8.1107234954833984e-01
    z[3,9,1]  R1569     7.5782066583633423e-01
    z[3,9,1]  R1570     6.4041876792907715e-01
    z[3,9,1]  R1571     6.3288372755050659e-01
    z[3,9,1]  R1572     5.7941132783889771e-01
    z[3,9,1]  R1573     5.8373361825942993e-01
    z[3,9,1]  R1574     -0.658723771572113
    z[3,9,1]  R1575     -4.7224420309066772e-01
    z[3,9,1]  R1576     -7.5151330232620239e-01
    z[3,9,1]  R1577     -7.0992028713226318e-01
    z[3,9,2]  R31       -1
    z[3,9,2]  R85       1
    z[3,9,2]  R1478     -1
    z[3,9,2]  R1479     1
    z[3,9,2]  R1488     7.7526587247848511e-01
    z[3,9,2]  R1489     8.9516741037368774e-01
    z[3,9,2]  R1490     3.5201448202133179e-01
    z[3,9,2]  R1491     5.7556211948394775e-01
    z[3,9,2]  R1492     2.4388627707958221e-01
    z[3,9,2]  R1493     1.9422550499439240e-01
    z[3,9,2]  R1494     2.5933519005775452e-01
    z[3,9,2]  R1495     0.202837273478508
    z[3,9,2]  R1496     3.2138973474502563e-01
    z[3,9,2]  R1497     4.2020189762115479e-01
    z[3,9,2]  R1498     -2.8708580136299133e-01
    z[3,9,2]  R1499     -4.6171575784683228e-02
    z[3,9,2]  R1500     -2.1103249490261078e-01
    z[3,9,2]  R1501     4.2556360363960266e-02
    z[3,9,2]  R1502     -3.3406227827072144e-02
    z[3,9,2]  R1503     -0.0990736186504364
    z[3,9,2]  R1504     1.3600957393646240e-01
    z[3,9,2]  R1505     1.1976634850725532e-03
    z[3,9,2]  R1506     0.0696486309170723
    z[3,9,2]  R1507     3.0957534909248352e-01
    z[3,9,2]  R1508     -1.2485025823116302e-01
    z[3,9,2]  R1509     -1.3977298513054848e-02
    z[3,9,2]  R1510     -0.208160862326622
    z[3,9,2]  R1511     8.8788039982318878e-02
    z[3,9,2]  R1512     -2.0874983072280884e-01
    z[3,9,2]  R1513     -7.1404181420803070e-02
    z[3,9,2]  R1514     -1.0149326175451279e-02
    z[3,9,2]  R1515     -2.1710006892681122e-01
    z[3,9,2]  R1516     3.2241743803024292e-01
    z[3,9,2]  R1517     -5.0627548247575760e-02
    z[3,9,2]  R1518     4.3066430091857910e-01
    z[3,9,2]  R1519     5.7679611444473267e-01
    z[3,9,2]  R1520     3.7671455740928650e-01
    z[3,9,2]  R1521     -1.7360439896583557e-01
    z[3,9,2]  R1522     1.0191214829683304e-01
    z[3,9,2]  R1523     1.2821683287620544e-01
    z[3,9,2]  R1524     -4.9768432974815369e-02
    z[3,9,2]  R1525     7.4249237775802612e-02
    z[3,9,2]  R1526     1.3735768198966980e-01
    z[3,9,2]  R1527     -1.8188828229904175e-01
    z[3,9,2]  R1528     7.4854022264480591e-01
    z[3,9,2]  R1529     7.7322673797607422e-01
    z[3,9,2]  R1530     5.5614316463470459e-01
    z[3,9,2]  R1531     7.4131155014038086e-01
    z[3,9,2]  R1532     6.0885030031204224e-01
    z[3,9,2]  R1533     5.5249720811843872e-01
    z[3,9,2]  R1534     9.0784209966659546e-01
    z[3,9,2]  R1535     6.7819595336914062e-01
    z[3,9,2]  R1536     2.7134335041046143e-01
    z[3,9,2]  R1537     4.2744603753089905e-01
    z[3,9,2]  R1538     5.1857554353773594e-03
    z[3,9,2]  R1539     1.6024602949619293e-01
    z[3,9,2]  R1540     1.8079839646816254e-01
    z[3,9,2]  R1541     -0.00484444061294198
    z[3,9,2]  R1542     -4.9005034379661083e-03
    z[3,9,2]  R1543     -1.6564095392823219e-02
    z[3,9,2]  R1544     1.6810914874076843e-01
    z[3,9,2]  R1545     2.9709663987159729e-01
    z[3,9,2]  R1546     -1.4267097413539886e-01
    z[3,9,2]  R1547     8.9215926826000214e-02
    z[3,9,2]  R1548     1.6153568029403687e-01
    z[3,9,2]  R1549     -1.7516578733921051e-01
    z[3,9,2]  R1550     1.5358678996562958e-01
    z[3,9,2]  R1551     3.4399747848510742e-01
    z[3,9,2]  R1552     2.5514939427375793e-01
    z[3,9,2]  R1553     -2.8482022881507874e-01
    z[3,9,2]  R1554     1.5267622470855713e-01
    z[3,9,2]  R1555     -9.4846390187740326e-02
    z[3,9,2]  R1556     -0.0899360403418541
    z[3,9,2]  R1557     -3.1053539365530014e-02
    z[3,9,2]  R1558     3.2477059960365295e-01
    z[3,9,2]  R1559     -2.5495512410998344e-02
    z[3,9,2]  R1560     1.2463396787643433e-01
    z[3,9,2]  R1561     -2.3540388047695160e-01
    z[3,9,2]  R1562     2.9795238375663757e-01
    z[3,9,2]  R1563     -1.3816735148429871e-01
    z[3,9,2]  R1564     4.4385454058647156e-01
    z[3,9,2]  R1565     -2.2756014764308929e-01
    z[3,9,2]  R1566     3.6119814962148666e-02
    z[3,9,2]  R1567     1.2279379367828369e-01
    z[3,9,2]  R1568     -2.8874114155769348e-01
    z[3,9,2]  R1569     -4.0515437722206116e-02
    z[3,9,2]  R1570     2.6859748363494873e-01
    z[3,9,2]  R1571     -1.2695711851119995e-01
    z[3,9,2]  R1572     4.6635717153549194e-01
    z[3,9,2]  R1573     3.3958196640014648e-01
    z[3,9,2]  R1574     3.8723897933959961e-01
    z[3,9,2]  R1575     3.9988216757774353e-01
    z[3,9,2]  R1576     7.4228219687938690e-02
    z[3,9,2]  R1577     1.4176069200038910e-01
    z[3,9,3]  R32       -1
    z[3,9,3]  R86       1
    z[3,9,3]  R1480     -1
    z[3,9,3]  R1481     1
    z[3,9,3]  R1488     0.07901581376791
    z[3,9,3]  R1489     0.14643594622612
    z[3,9,3]  R1490     1.8404580652713776e-01
    z[3,9,3]  R1491     -4.8148915171623230e-01
    z[3,9,3]  R1492     -2.5568547844886780e-01
    z[3,9,3]  R1493     1.2257728725671768e-01
    z[3,9,3]  R1494     -2.2818391025066376e-01
    z[3,9,3]  R1495     -3.1830493360757828e-02
    z[3,9,3]  R1496     8.9937351644039154e-02
    z[3,9,3]  R1497     -1.0073759406805038e-01
    z[3,9,3]  R1498     1.3321955502033234e-01
    z[3,9,3]  R1499     6.0039076954126358e-02
    z[3,9,3]  R1500     -9.3716740608215332e-02
    z[3,9,3]  R1501     4.2428936809301376e-02
    z[3,9,3]  R1502     -3.1878617405891418e-01
    z[3,9,3]  R1503     -6.2994378805160522e-01
    z[3,9,3]  R1504     9.8014205694198608e-02
    z[3,9,3]  R1505     -1.7204432189464569e-01
    z[3,9,3]  R1506     -1.6432275995612144e-02
    z[3,9,3]  R1507     5.1976222544908524e-02
    z[3,9,3]  R1508     -1.6308794915676117e-01
    z[3,9,3]  R1509     2.9764357209205627e-01
    z[3,9,3]  R1510     -5.3639984130859375e-01
    z[3,9,3]  R1511     -1.9266603887081146e-01
    z[3,9,3]  R1512     0.067952461540699
    z[3,9,3]  R1513     -1.9458861649036407e-01
    z[3,9,3]  R1514     3.9981618523597717e-01
    z[3,9,3]  R1515     -5.7392424345016479e-01
    z[3,9,3]  R1516     1.0243978351354599e-01
    z[3,9,3]  R1517     -1.8930040299892426e-02
    z[3,9,3]  R1518     -3.2287371158599854e-01
    z[3,9,3]  R1519     -1.6707479953765869e-01
    z[3,9,3]  R1520     2.4766427278518677e-01
    z[3,9,3]  R1521     7.4058908224105835e-01
    z[3,9,3]  R1522     -2.1980394423007965e-01
    z[3,9,3]  R1523     1.7972676083445549e-02
    z[3,9,3]  R1524     -2.1149446070194244e-01
    z[3,9,3]  R1525     -6.3981473445892334e-02
    z[3,9,3]  R1526     1.6020385921001434e-01
    z[3,9,3]  R1527     -4.2409861087799072e-01
    z[3,9,3]  R1528     -1.8052347004413605e-01
    z[3,9,3]  R1529     5.3283762186765671e-02
    z[3,9,3]  R1530     -4.3473982810974121e-01
    z[3,9,3]  R1531     2.1651349961757660e-01
    z[3,9,3]  R1532     -4.9789324402809143e-01
    z[3,9,3]  R1533     1.2577231228351593e-01
    z[3,9,3]  R1534     1.9749045372009277e-01
    z[3,9,3]  R1535     2.5030982494354248e-01
    z[3,9,3]  R1536     3.9309477806091309e-01
    z[3,9,3]  R1537     -4.4370139949023724e-03
    z[3,9,3]  R1538     -8.5052363574504852e-02
    z[3,9,3]  R1539     -1.7347997426986694e-01
    z[3,9,3]  R1540     1.3206608593463898e-01
    z[3,9,3]  R1541     1.8585222959518433e-01
    z[3,9,3]  R1542     -6.2713988125324249e-02
    z[3,9,3]  R1543     -0.0458403155207634
    z[3,9,3]  R1544     1.0051049292087555e-01
    z[3,9,3]  R1545     4.5493662357330322e-02
    z[3,9,3]  R1546     6.7066222429275513e-01
    z[3,9,3]  R1547     -3.6637911200523376e-01
    z[3,9,3]  R1548     1.6711705923080444e-01
    z[3,9,3]  R1549     -6.0624879598617554e-01
    z[3,9,3]  R1550     1.7043847590684891e-02
    z[3,9,3]  R1551     -1.6985219717025757e-01
    z[3,9,3]  R1552     3.2322707772254944e-01
    z[3,9,3]  R1553     -3.3934235572814941e-01
    z[3,9,3]  R1554     -6.7457742989063263e-02
    z[3,9,3]  R1555     2.3494258522987366e-01
    z[3,9,3]  R1556     3.4122428297996521e-01
    z[3,9,3]  R1557     4.2916625738143921e-01
    z[3,9,3]  R1558     -1.7377541959285736e-01
    z[3,9,3]  R1559     2.0292323082685471e-02
    z[3,9,3]  R1560     -4.3427139520645142e-01
    z[3,9,3]  R1561     -3.8042291998863220e-01
    z[3,9,3]  R1562     -5.1961505413055420e-01
    z[3,9,3]  R1563     1.4480647444725037e-01
    z[3,9,3]  R1564     8.0680213868618011e-02
    z[3,9,3]  R1565     4.9613124132156372e-01
    z[3,9,3]  R1566     4.5380535721778870e-01
    z[3,9,3]  R1567     1.2200967222452164e-01
    z[3,9,3]  R1568     -3.4977838397026062e-01
    z[3,9,3]  R1569     -2.0434801280498505e-01
    z[3,9,3]  R1570     -5.1644808053970337e-01
    z[3,9,3]  R1571     -1.8804410472512245e-02
    z[3,9,3]  R1572     3.9058357477188110e-01
    z[3,9,3]  R1573     4.0062817931175232e-01
    z[3,9,3]  R1574     3.0354353785514832e-01
    z[3,9,3]  R1575     4.3460509181022644e-01
    z[3,9,3]  R1576     1.4760607481002808e-01
    z[3,9,3]  R1577     3.7209221720695496e-01
    z[3,9,4]  R33       -1
    z[3,9,4]  R87       1
    z[3,9,4]  R1482     -1
    z[3,9,4]  R1483     1
    z[3,9,4]  R1488     -1.5118260681629181e-01
    z[3,9,4]  R1489     -1.2110810726881027e-01
    z[3,9,4]  R1490     3.0696511268615723e-01
    z[3,9,4]  R1491     9.3824982643127441e-02
    z[3,9,4]  R1492     5.6252223253250122e-01
    z[3,9,4]  R1493     4.5384871959686279e-01
    z[3,9,4]  R1494     3.0659487843513489e-01
    z[3,9,4]  R1495     -2.3273593187332153e-01
    z[3,9,4]  R1496     -1.6773466765880585e-01
    z[3,9,4]  R1497     -1.9281828776001930e-02
    z[3,9,4]  R1498     -3.8209676742553711e-01
    z[3,9,4]  R1499     -6.9468045234680176e-01
    z[3,9,4]  R1500     -1.7974703013896942e-01
    z[3,9,4]  R1501     -2.7379241585731506e-01
    z[3,9,4]  R1502     -6.6507525742053986e-02
    z[3,9,4]  R1503     2.2297158837318420e-01
    z[3,9,4]  R1504     -2.7357056736946106e-01
    z[3,9,4]  R1505     2.1131275594234467e-01
    z[3,9,4]  R1506     -2.1221134066581726e-01
    z[3,9,4]  R1507     3.5109922289848328e-02
    z[3,9,4]  R1508     -0.242910698056221
    z[3,9,4]  R1509     -6.4958351850509644e-01
    z[3,9,4]  R1510     -8.3872549235820770e-02
    z[3,9,4]  R1511     2.5922521948814392e-01
    z[3,9,4]  R1512     5.6454139947891235e-01
    z[3,9,4]  R1513     7.3291277885437012e-01
    z[3,9,4]  R1514     1.1814720183610916e-01
    z[3,9,4]  R1515     2.6722148060798645e-01
    z[3,9,4]  R1516     3.0719587206840515e-01
    z[3,9,4]  R1517     -5.8366615325212479e-02
    z[3,9,4]  R1518     -2.9494842886924744e-01
    z[3,9,4]  R1519     -1.6150401532649994e-01
    z[3,9,4]  R1520     -1.4807645976543427e-01
    z[3,9,4]  R1521     1.3833388686180115e-01
    z[3,9,4]  R1522     -1.4137434959411621e-01
    z[3,9,4]  R1523     8.2156389951705933e-02
    z[3,9,4]  R1524     2.8801393508911133e-01
    z[3,9,4]  R1525     4.7589689493179321e-01
    z[3,9,4]  R1526     3.6816483736038208e-01
    z[3,9,4]  R1527     1.2181729823350906e-01
    z[3,9,4]  R1528     1.5794004499912262e-01
    z[3,9,4]  R1529     -0.287248820066452
    z[3,9,4]  R1530     -4.6690490841865540e-01
    z[3,9,4]  R1531     -3.5223785042762756e-01
    z[3,9,4]  R1532     -3.3591628074645996e-01
    z[3,9,4]  R1533     -5.2343004941940308e-01
    z[3,9,4]  R1534     -1.2184038013219833e-01
    z[3,9,4]  R1535     -8.3195351064205170e-02
    z[3,9,4]  R1536     4.4558685272932053e-02
    z[3,9,4]  R1537     -6.4415490627288818e-01
    z[3,9,4]  R1538     -3.8812708109617233e-02
    z[3,9,4]  R1539     7.4055716395378113e-03
    z[3,9,4]  R1540     -1.5727436542510986e-01
    z[3,9,4]  R1541     4.6703465282917023e-02
    z[3,9,4]  R1542     5.7107192277908325e-01
    z[3,9,4]  R1543     -3.9166450500488281e-02
    z[3,9,4]  R1544     6.7736767232418060e-02
    z[3,9,4]  R1545     8.7502032518386841e-02
    z[3,9,4]  R1546     -1.7671035602688789e-02
    z[3,9,4]  R1547     5.8958941698074341e-01
    z[3,9,4]  R1548     1.9108204171061516e-02
    z[3,9,4]  R1549     1.2698955833911896e-01
    z[3,9,4]  R1550     -3.3748939633369446e-02
    z[3,9,4]  R1551     -3.2901132106781006e-01
    z[3,9,4]  R1552     -6.1276316642761230e-02
    z[3,9,4]  R1553     -5.1297068595886230e-02
    z[3,9,4]  R1554     -2.2719316184520721e-01
    z[3,9,4]  R1555     -2.5636243820190430e-01
    z[3,9,4]  R1556     3.4080383181571960e-01
    z[3,9,4]  R1557     -8.4892563521862030e-02
    z[3,9,4]  R1558     5.3927540779113770e-01
    z[3,9,4]  R1559     5.7670968770980835e-01
    z[3,9,4]  R1560     1.1724369972944260e-01
    z[3,9,4]  R1561     5.1187109947204590e-01
    z[3,9,4]  R1562     4.8995384573936462e-01
    z[3,9,4]  R1563     -4.4858568906784058e-01
    z[3,9,4]  R1564     4.0596362948417664e-01
    z[3,9,4]  R1565     -2.9080381616950035e-02
    z[3,9,4]  R1566     2.3985201492905617e-02
    z[3,9,4]  R1567     5.3897273540496826e-01
    z[3,9,4]  R1568     2.5838559865951538e-01
    z[3,9,4]  R1569     9.1996602714061737e-02
    z[3,9,4]  R1570     1.8558706343173981e-01
    z[3,9,4]  R1571     6.3261657953262329e-01
    z[3,9,4]  R1572     3.5041567683219910e-01
    z[3,9,4]  R1573     -3.8997948169708252e-01
    z[3,9,4]  R1574     -2.3826885968446732e-02
    z[3,9,4]  R1575     -1.9107882678508759e-01
    z[3,9,4]  R1576     -2.1714706718921661e-01
    z[3,9,4]  R1577     -1.2603472173213959e-01
    z[3,9,5]  R34       -1
    z[3,9,5]  R88       1
    z[3,9,5]  R1484     -1
    z[3,9,5]  R1485     1
    z[3,9,5]  R1488     1.4710752665996552e-01
    z[3,9,5]  R1489     5.5916242301464081e-02
    z[3,9,5]  R1490     -4.3696433305740356e-01
    z[3,9,5]  R1491     1.7973285913467407e-01
    z[3,9,5]  R1492     5.2761003375053406e-02
    z[3,9,5]  R1493     -4.1906601190567017e-01
    z[3,9,5]  R1494     -2.1328464150428772e-01
    z[3,9,5]  R1495     -3.1065386533737183e-01
    z[3,9,5]  R1496     -3.6468520760536194e-02
    z[3,9,5]  R1497     2.5497859343886375e-02
    z[3,9,5]  R1498     4.7373014688491821e-01
    z[3,9,5]  R1499     3.4413686394691467e-01
    z[3,9,5]  R1500     1.0588242113590240e-01
    z[3,9,5]  R1501     -5.6741183996200562e-01
    z[3,9,5]  R1502     -1.9991537928581238e-01
    z[3,9,5]  R1503     4.0387919545173645e-01
    z[3,9,5]  R1504     4.9634307622909546e-01
    z[3,9,5]  R1505     -3.8713118433952332e-01
    z[3,9,5]  R1506     6.3142009079456329e-02
    z[3,9,5]  R1507     -3.2969031017273664e-03
    z[3,9,5]  R1508     3.0698272585868835e-01
    z[3,9,5]  R1509     -1.0310070216655731e-01
    z[3,9,5]  R1510     4.5047125220298767e-01
    z[3,9,5]  R1511     6.7605400085449219e-01
    z[3,9,5]  R1512     1.3374383747577667e-01
    z[3,9,5]  R1513     3.3290737867355347e-01
    z[3,9,5]  R1514     -0.0471990704536438
    z[3,9,5]  R1515     -2.4472513794898987e-01
    z[3,9,5]  R1516     -2.2847951948642731e-01
    z[3,9,5]  R1517     1.9362162053585052e-01
    z[3,9,5]  R1518     1.2813235819339752e-01
    z[3,9,5]  R1519     -2.9364410042762756e-01
    z[3,9,5]  R1520     3.1093168258666992e-01
    z[3,9,5]  R1521     2.8522640466690063e-01
    z[3,9,5]  R1522     -2.9728201031684875e-01
    z[3,9,5]  R1523     -3.9887115359306335e-01
    z[3,9,5]  R1524     -1.6919489204883575e-01
    z[3,9,5]  R1525     -2.6922725141048431e-02
    z[3,9,5]  R1526     -1.3203187286853790e-01
    z[3,9,5]  R1527     -1.9959259033203125e-01
    z[3,9,5]  R1528     -2.7535766363143921e-01
    z[3,9,5]  R1529     -4.7670555114746094e-01
    z[3,9,5]  R1530     3.0889594927430153e-02
    z[3,9,5]  R1531     1.0734009742736816e-01
    z[3,9,5]  R1532     -2.5883340835571289e-01
    z[3,9,5]  R1533     1.1961440742015839e-01
    z[3,9,5]  R1534     3.0453236773610115e-02
    z[3,9,5]  R1535     -2.4219313263893127e-01
    z[3,9,5]  R1536     -3.7171486020088196e-01
    z[3,9,5]  R1537     -4.3663722276687622e-01
    z[3,9,5]  R1538     7.2335839271545410e-02
    z[3,9,5]  R1539     -1.1631545424461365e-01
    z[3,9,5]  R1540     -1.3624674081802368e-01
    z[3,9,5]  R1541     2.5760984420776367e-01
    z[3,9,5]  R1542     3.2423117756843567e-01
    z[3,9,5]  R1543     7.3119446635246277e-02
    z[3,9,5]  R1544     -6.3303269445896149e-02
    z[3,9,5]  R1545     1.8382611870765686e-01
    z[3,9,5]  R1546     2.8376647830009460e-01
    z[3,9,5]  R1547     1.5907536447048187e-01
    z[3,9,5]  R1548     -1.4546471834182739e-01
    z[3,9,5]  R1549     -2.4275135993957520e-01
    z[3,9,5]  R1550     6.1934083700180054e-01
    z[3,9,5]  R1551     2.7800858020782471e-01
    z[3,9,5]  R1552     5.0388675928115845e-01
    z[3,9,5]  R1553     -5.6846532970666885e-02
    z[3,9,5]  R1554     3.6254499107599258e-02
    z[3,9,5]  R1555     -3.7607285380363464e-01
    z[3,9,5]  R1556     5.0147105008363724e-02
    z[3,9,5]  R1557     -9.4526156783103943e-02
    z[3,9,5]  R1558     -2.3553647100925446e-02
    z[3,9,5]  R1559     3.8908076286315918e-01
    z[3,9,5]  R1560     -5.6547969579696655e-01
    z[3,9,5]  R1561     2.4374131858348846e-01
    z[3,9,5]  R1562     3.1710278242826462e-02
    z[3,9,5]  R1563     1.4875052869319916e-01
    z[3,9,5]  R1564     3.3772411942481995e-01
    z[3,9,5]  R1565     1.4556702971458435e-01
    z[3,9,5]  R1566     6.0349458456039429e-01
    z[3,9,5]  R1567     -2.3410108685493469e-01
    z[3,9,5]  R1568     2.3875202238559723e-01
    z[3,9,5]  R1569     0.532198429107666
    z[3,9,5]  R1570     -8.8648170232772827e-02
    z[3,9,5]  R1571     -1.3305827043950558e-02
    z[3,9,5]  R1572     -3.9736879989504814e-03
    z[3,9,5]  R1573     0.3140889108181
    z[3,9,5]  R1574     -4.4955092668533325e-01
    z[3,9,5]  R1575     -5.2958631515502930e-01
    z[3,9,5]  R1576     -4.5618087053298950e-01
    z[3,9,5]  R1577     -2.2290091216564178e-01
    z[3,9,6]  R35       -1
    z[3,9,6]  R89       1
    z[3,9,6]  R1486     -1
    z[3,9,6]  R1487     1
    z[3,9,6]  R1488     1.7206548154354095e-01
    z[3,9,6]  R1489     -2.2013604640960693e-01
    z[3,9,6]  R1490     -4.1592967510223389e-01
    z[3,9,6]  R1491     3.1965491175651550e-01
    z[3,9,6]  R1492     -7.8862540423870087e-02
    z[3,9,6]  R1493     4.4223007559776306e-01
    z[3,9,6]  R1494     1.3842076063156128e-01
    z[3,9,6]  R1495     8.0339181423187256e-01
    z[3,9,6]  R1496     -4.7521837055683136e-02
    z[3,9,6]  R1497     1.2020229548215866e-01
    z[3,9,6]  R1498     -5.0076227635145187e-02
    z[3,9,6]  R1499     -2.4653879925608635e-02
    z[3,9,6]  R1500     5.5876958370208740e-01
    z[3,9,6]  R1501     3.0013734102249146e-01
    z[3,9,6]  R1502     1.0981138795614243e-01
    z[3,9,6]  R1503     -2.3106880486011505e-01
    z[3,9,6]  R1504     -5.8837193250656128e-01
    z[3,9,6]  R1505     -2.6153776049613953e-01
    z[3,9,6]  R1506     -5.8548414707183838e-01
    z[3,9,6]  R1507     -1.6975912451744080e-01
    z[3,9,6]  R1508     -3.8777709007263184e-01
    z[3,9,6]  R1509     4.2124241590499878e-01
    z[3,9,6]  R1510     2.3847469687461853e-01
    z[3,9,6]  R1511     1.8114395439624786e-01
    z[3,9,6]  R1512     3.6959323287010193e-01
    z[3,9,6]  R1513     -1.0266353935003281e-01
    z[3,9,6]  R1514     -2.7397081255912781e-01
    z[3,9,6]  R1515     2.3994588851928711e-01
    z[3,9,6]  R1516     6.2200784683227539e-01
    z[3,9,6]  R1517     9.7674198448657990e-02
    z[3,9,6]  R1518     -4.7831791453063488e-03
    z[3,9,6]  R1519     3.0158025026321411e-01
    z[3,9,6]  R1520     3.1003820896148682e-01
    z[3,9,6]  R1521     1.0133621096611023e-01
    z[3,9,6]  R1522     1.4268645644187927e-01
    z[3,9,6]  R1523     2.1593706309795380e-01
    z[3,9,6]  R1524     -3.2391491532325745e-01
    z[3,9,6]  R1525     -2.4074141681194305e-01
    z[3,9,6]  R1526     -2.4229244887828827e-01
    z[3,9,6]  R1527     1.2261576205492020e-01
    z[3,9,6]  R1528     -0.289164662361145
    z[3,9,6]  R1529     2.4522738531231880e-02
    z[3,9,6]  R1530     2.5590965151786804e-01
    z[3,9,6]  R1531     -3.7311750650405884e-01
    z[3,9,6]  R1532     -2.2620756924152374e-01
    z[3,9,6]  R1533     -1.4772605895996094e-01
    z[3,9,6]  R1534     0.128773495554924
    z[3,9,6]  R1535     -4.7608497738838196e-01
    z[3,9,6]  R1536     -6.4299941062927246e-01
    z[3,9,6]  R1537     -1.4596696197986603e-01
    z[3,9,6]  R1538     8.9961051940917969e-02
    z[3,9,6]  R1539     -8.0054707825183868e-02
    z[3,9,6]  R1540     -3.9782442152500153e-02
    z[3,9,6]  R1541     -6.8114414811134338e-02
    z[3,9,6]  R1542     4.4111007452011108e-01
    z[3,9,6]  R1543     -3.1494843959808350e-01
    z[3,9,6]  R1544     3.0385980010032654e-01
    z[3,9,6]  R1545     2.3639582097530365e-01
    z[3,9,6]  R1546     4.2337965965270996e-01
    z[3,9,6]  R1547     -4.6211636066436768e-01
    z[3,9,6]  R1548     2.7650898694992065e-01
    z[3,9,6]  R1549     1.2029550969600677e-01
    z[3,9,6]  R1550     -0.367557555437088
    z[3,9,6]  R1551     -6.6486102342605591e-01
    z[3,9,6]  R1552     2.4418263137340546e-01
    z[3,9,6]  R1553     -3.9550852775573730e-01
    z[3,9,6]  R1554     6.5928483009338379e-01
    z[3,9,6]  R1555     4.3085891008377075e-01
    z[3,9,6]  R1556     3.9106476306915283e-01
    z[3,9,6]  R1557     -3.1564164161682129e-01
    z[3,9,6]  R1558     3.4440398216247559e-01
    z[3,9,6]  R1559     2.4238672852516174e-01
    z[3,9,6]  R1560     8.0896958708763123e-02
    z[3,9,6]  R1561     1.1481685936450958e-01
    z[3,9,6]  R1562     9.6243396401405334e-02
    z[3,9,6]  R1563     -2.6154699921607971e-01
    z[3,9,6]  R1564     -2.4617652595043182e-01
    z[3,9,6]  R1565     3.5888656973838806e-01
    z[3,9,6]  R1566     -1.4568477869033813e-01
    z[3,9,6]  R1567     -8.4414698183536530e-02
    z[3,9,6]  R1568     7.7482990920543671e-02
    z[3,9,6]  R1569     1.1786509305238724e-01
    z[3,9,6]  R1570     -2.7869653701782227e-01
    z[3,9,6]  R1571     -4.2002275586128235e-01
    z[3,9,6]  R1572     -9.0852063149213791e-03
    z[3,9,6]  R1573     1.5262927114963531e-01
    z[3,9,6]  R1574     -1.0978161543607712e-01
    z[3,9,6]  R1575     2.3072727024555206e-01
    z[3,9,6]  R1576     -5.3429072722792625e-03
    z[3,9,6]  R1577     -3.3589568734169006e-01
    z[9,3,0]  R29       1
    z[9,3,0]  R83       -1
    z[9,3,0]  R1578     -1
    z[9,3,0]  R1579     1
    z[9,3,0]  R1592     -4.7083017230033875e-01
    z[9,3,0]  R1593     -2.9554355144500732e-01
    z[9,3,0]  R1594     -4.5847481489181519e-01
    z[9,3,0]  R1595     -3.4898281097412109e-01
    z[9,3,0]  R1596     -3.4378483891487122e-01
    z[9,3,0]  R1597     -4.1573926806449890e-01
    z[9,3,0]  R1598     -3.2152774930000305e-01
    z[9,3,0]  R1599     -2.9459995031356812e-01
    z[9,3,0]  R1600     -4.6038252115249634e-01
    z[9,3,0]  R1601     -3.3345550298690796e-01
    z[9,3,0]  R1602     9.6774977445602417e-01
    z[9,3,0]  R1603     9.2610377073287964e-01
    z[9,3,0]  R1604     9.3839341402053833e-01
    z[9,3,0]  R1605     0.913361668586731
    z[9,3,0]  R1606     -5.5221021175384521e-01
    z[9,3,0]  R1607     9.2324179410934448e-01
    z[9,3,0]  R1608     8.7861239910125732e-01
    z[9,3,0]  R1609     8.6381405591964722e-01
    z[9,3,0]  R1610     -5.0134289264678955e-01
    z[9,3,0]  R1611     2.2638149559497833e-01
    z[9,3,0]  R1612     -9.0156745910644531e-01
    z[9,3,0]  R1613     -6.7771470546722412e-01
    z[9,3,0]  R1614     -0.654639482498169
    z[9,3,0]  R1615     -4.5600414276123047e-01
    z[9,3,0]  R1616     -5.2531290054321289e-01
    z[9,3,0]  R1617     -1.3764478266239166e-01
    z[9,3,0]  R1618     1.3541062362492085e-02
    z[9,3,0]  R1619     -4.0826670825481415e-02
    z[9,3,0]  R1620     -3.0490857362747192e-01
    z[9,3,0]  R1621     4.8627230525016785e-01
    z[9,3,0]  R1622     -1.3738344609737396e-01
    z[9,3,0]  R1623     1.5904630720615387e-01
    z[9,3,0]  R1624     2.5986087322235107e-01
    z[9,3,0]  R1625     0.145345538854599
    z[9,3,0]  R1626     2.4203133583068848e-01
    z[9,3,0]  R1627     5.2579408884048462e-01
    z[9,3,0]  R1628     3.9317697286605835e-01
    z[9,3,0]  R1629     4.3037596344947815e-01
    z[9,3,0]  R1630     2.6960945129394531e-01
    z[9,3,0]  R1631     0.500088095664978
    z[9,3,0]  R1632     8.1707149744033813e-02
    z[9,3,0]  R1633     2.7697938680648804e-01
    z[9,3,0]  R1634     3.6197766661643982e-01
    z[9,3,0]  R1635     7.8655153512954712e-02
    z[9,3,0]  R1636     4.1394266486167908e-01
    z[9,3,0]  R1637     3.3076366782188416e-01
    z[9,3,0]  R1638     3.3056697249412537e-01
    z[9,3,0]  R1639     2.4081142246723175e-01
    z[9,3,0]  R1640     3.9070203900337219e-01
    z[9,3,0]  R1641     3.9883446693420410e-01
    z[9,3,0]  R1642     -4.6925377845764160e-01
    z[9,3,0]  R1643     -0.33150514960289
    z[9,3,0]  R1644     -5.9620642662048340e-01
    z[9,3,0]  R1645     -5.3413516283035278e-01
    z[9,3,0]  R1646     -6.8876588344573975e-01
    z[9,3,0]  R1647     -6.0696613788604736e-01
    z[9,3,0]  R1648     -8.4953486919403076e-01
    z[9,3,0]  R1649     -3.9942458271980286e-01
    z[9,3,0]  R1650     9.1994702816009521e-01
    z[9,3,0]  R1651     8.8811534643173218e-01
    z[9,3,0]  R1652     -7.2577923536300659e-01
    z[9,3,0]  R1653     -0.519461452960968
    z[9,3,0]  R1654     4.1029435396194458e-01
    z[9,3,0]  R1655     -1.9557641819119453e-02
    z[9,3,0]  R1656     4.4595736265182495e-01
    z[9,3,0]  R1657     6.6566020250320435e-02
    z[9,3,0]  R1658     3.9135344326496124e-02
    z[9,3,0]  R1659     3.4614410996437073e-01
    z[9,3,0]  R1660     2.3814016953110695e-02
    z[9,3,0]  R1661     7.9699587821960449e-01
    z[9,3,0]  R1662     -6.4133369922637939e-01
    z[9,3,0]  R1663     -5.4724627733230591e-01
    z[9,3,0]  R1664     -0.620279848575592
    z[9,3,0]  R1665     3.0767804384231567e-01
    z[9,3,0]  R1666     3.8189122080802917e-01
    z[9,3,0]  R1667     -9.4968140125274658e-02
    z[9,3,0]  R1668     6.8948942422866821e-01
    z[9,3,0]  R1669     -6.1649329960346222e-02
    z[9,3,0]  R1670     4.1818743944168091e-01
    z[9,3,0]  R1671     9.6550965309143066e-01
    z[9,3,0]  R1672     -2.5130379199981689e-01
    z[9,3,0]  R1673     2.6442989706993103e-01
    z[9,3,0]  R1674     5.3732526302337646e-01
    z[9,3,0]  R1675     -2.8376492857933044e-01
    z[9,3,0]  R1676     9.0092593431472778e-01
    z[9,3,0]  R1677     8.6789494752883911e-01
    z[9,3,0]  R1678     8.5806202888488770e-01
    z[9,3,0]  R1679     8.2225483655929565e-01
    z[9,3,0]  R1680     0.821610689163208
    z[9,3,0]  R1681     8.3646327257156372e-01
    z[9,3,1]  R30       1
    z[9,3,1]  R84       -1
    z[9,3,1]  R1580     -1
    z[9,3,1]  R1581     1
    z[9,3,1]  R1592     3.2166350632905960e-02
    z[9,3,1]  R1593     0.0396723710000515
    z[9,3,1]  R1594     8.4040112793445587e-02
    z[9,3,1]  R1595     -8.3546109497547150e-02
    z[9,3,1]  R1596     -1.7947475612163544e-01
    z[9,3,1]  R1597     -4.4269564747810364e-01
    z[9,3,1]  R1598     -3.2941896468400955e-02
    z[9,3,1]  R1599     3.1364038586616516e-01
    z[9,3,1]  R1600     7.9319693148136139e-02
    z[9,3,1]  R1601     -2.8139597177505493e-01
    z[9,3,1]  R1602     2.0339037477970123e-01
    z[9,3,1]  R1603     2.5800153613090515e-01
    z[9,3,1]  R1604     1.5622794628143311e-01
    z[9,3,1]  R1605     2.4087810516357422e-01
    z[9,3,1]  R1606     2.5549891591072083e-01
    z[9,3,1]  R1607     1.9792918860912323e-01
    z[9,3,1]  R1608     2.9791086912155151e-01
    z[9,3,1]  R1609     2.5721102952957153e-01
    z[9,3,1]  R1610     -1.3574388623237610e-01
    z[9,3,1]  R1611     4.6913331747055054e-01
    z[9,3,1]  R1612     -1.8754141032695770e-01
    z[9,3,1]  R1613     0.230122908949852
    z[9,3,1]  R1614     1.6657446324825287e-01
    z[9,3,1]  R1615     1.3152468204498291e-01
    z[9,3,1]  R1616     4.8701906204223633e-01
    z[9,3,1]  R1617     0.788979172706604
    z[9,3,1]  R1618     6.9596582651138306e-01
    z[9,3,1]  R1619     7.3576313257217407e-01
    z[9,3,1]  R1620     7.1478289365768433e-01
    z[9,3,1]  R1621     6.8016147613525391e-01
    z[9,3,1]  R1622     6.5989780426025391e-01
    z[9,3,1]  R1623     6.5643984079360962e-01
    z[9,3,1]  R1624     6.2312871217727661e-01
    z[9,3,1]  R1625     6.6643327474594116e-01
    z[9,3,1]  R1626     5.7647407054901123e-01
    z[9,3,1]  R1627     6.2587428092956543e-01
    z[9,3,1]  R1628     5.4993522167205811e-01
    z[9,3,1]  R1629     6.0498905181884766e-01
    z[9,3,1]  R1630     5.7798069715499878e-01
    z[9,3,1]  R1631     6.0623961687088013e-01
    z[9,3,1]  R1632     8.1107234954833984e-01
    z[9,3,1]  R1633     7.5782066583633423e-01
    z[9,3,1]  R1634     6.4041876792907715e-01
    z[9,3,1]  R1635     6.3288372755050659e-01
    z[9,3,1]  R1636     5.7941132783889771e-01
    z[9,3,1]  R1637     5.8373361825942993e-01
    z[9,3,1]  R1638     -0.658723771572113
    z[9,3,1]  R1639     -4.7224420309066772e-01
    z[9,3,1]  R1640     -7.5151330232620239e-01
    z[9,3,1]  R1641     -7.0992028713226318e-01
    z[9,3,1]  R1642     -3.1371474266052246e-01
    z[9,3,1]  R1643     3.2901279628276825e-02
    z[9,3,1]  R1644     1.6907972097396851e-01
    z[9,3,1]  R1645     9.1157384216785431e-02
    z[9,3,1]  R1646     -2.7442991733551025e-01
    z[9,3,1]  R1647     4.0999788790941238e-02
    z[9,3,1]  R1648     1.7802091315388680e-02
    z[9,3,1]  R1649     -4.6836573630571365e-02
    z[9,3,1]  R1650     -1.0292798280715942e-01
    z[9,3,1]  R1651     -9.5199182629585266e-02
    z[9,3,1]  R1652     1.2362776324152946e-02
    z[9,3,1]  R1653     3.5043430328369141e-01
    z[9,3,1]  R1654     6.5007501840591431e-01
    z[9,3,1]  R1655     7.1344602108001709e-01
    z[9,3,1]  R1656     0.801207423210144
    z[9,3,1]  R1657     5.6806391477584839e-01
    z[9,3,1]  R1658     5.5044001340866089e-01
    z[9,3,1]  R1659     0.766588568687439
    z[9,3,1]  R1660     7.7620851993560791e-01
    z[9,3,1]  R1661     4.8600149154663086e-01
    z[9,3,1]  R1662     0.492839515209198
    z[9,3,1]  R1663     4.1238497942686081e-02
    z[9,3,1]  R1664     1.3178735971450806e-01
    z[9,3,1]  R1665     0.550700306892395
    z[9,3,1]  R1666     5.7686352729797363e-01
    z[9,3,1]  R1667     5.3804230690002441e-01
    z[9,3,1]  R1668     5.2287822961807251e-01
    z[9,3,1]  R1669     6.5635836124420166e-01
    z[9,3,1]  R1670     4.2095881700515747e-01
    z[9,3,1]  R1671     -1.2013946473598480e-01
    z[9,3,1]  R1672     7.3735463619232178e-01
    z[9,3,1]  R1673     6.0515117645263672e-01
    z[9,3,1]  R1674     5.4157292842864990e-01
    z[9,3,1]  R1675     4.7969511151313782e-01
    z[9,3,1]  R1676     3.0161522328853607e-02
    z[9,3,1]  R1677     -1.3235937058925629e-01
    z[9,3,1]  R1678     4.7759800218045712e-03
    z[9,3,1]  R1679     -1.7067900300025940e-01
    z[9,3,1]  R1680     -2.6218351721763611e-01
    z[9,3,1]  R1681     -1.3294726610183716e-01
    z[9,3,2]  R31       1
    z[9,3,2]  R85       -1
    z[9,3,2]  R1582     -1
    z[9,3,2]  R1583     1
    z[9,3,2]  R1592     7.4854022264480591e-01
    z[9,3,2]  R1593     7.7322673797607422e-01
    z[9,3,2]  R1594     5.5614316463470459e-01
    z[9,3,2]  R1595     7.4131155014038086e-01
    z[9,3,2]  R1596     6.0885030031204224e-01
    z[9,3,2]  R1597     5.5249720811843872e-01
    z[9,3,2]  R1598     9.0784209966659546e-01
    z[9,3,2]  R1599     6.7819595336914062e-01
    z[9,3,2]  R1600     2.7134335041046143e-01
    z[9,3,2]  R1601     4.2744603753089905e-01
    z[9,3,2]  R1602     5.1857554353773594e-03
    z[9,3,2]  R1603     1.6024602949619293e-01
    z[9,3,2]  R1604     1.8079839646816254e-01
    z[9,3,2]  R1605     -0.00484444061294198
    z[9,3,2]  R1606     -4.9005034379661083e-03
    z[9,3,2]  R1607     -1.6564095392823219e-02
    z[9,3,2]  R1608     1.6810914874076843e-01
    z[9,3,2]  R1609     2.9709663987159729e-01
    z[9,3,2]  R1610     -1.4267097413539886e-01
    z[9,3,2]  R1611     8.9215926826000214e-02
    z[9,3,2]  R1612     1.6153568029403687e-01
    z[9,3,2]  R1613     -1.7516578733921051e-01
    z[9,3,2]  R1614     1.5358678996562958e-01
    z[9,3,2]  R1615     3.4399747848510742e-01
    z[9,3,2]  R1616     2.5514939427375793e-01
    z[9,3,2]  R1617     -2.8482022881507874e-01
    z[9,3,2]  R1618     1.5267622470855713e-01
    z[9,3,2]  R1619     -9.4846390187740326e-02
    z[9,3,2]  R1620     -0.0899360403418541
    z[9,3,2]  R1621     -3.1053539365530014e-02
    z[9,3,2]  R1622     3.2477059960365295e-01
    z[9,3,2]  R1623     -2.5495512410998344e-02
    z[9,3,2]  R1624     1.2463396787643433e-01
    z[9,3,2]  R1625     -2.3540388047695160e-01
    z[9,3,2]  R1626     2.9795238375663757e-01
    z[9,3,2]  R1627     -1.3816735148429871e-01
    z[9,3,2]  R1628     4.4385454058647156e-01
    z[9,3,2]  R1629     -2.2756014764308929e-01
    z[9,3,2]  R1630     3.6119814962148666e-02
    z[9,3,2]  R1631     1.2279379367828369e-01
    z[9,3,2]  R1632     -2.8874114155769348e-01
    z[9,3,2]  R1633     -4.0515437722206116e-02
    z[9,3,2]  R1634     2.6859748363494873e-01
    z[9,3,2]  R1635     -1.2695711851119995e-01
    z[9,3,2]  R1636     4.6635717153549194e-01
    z[9,3,2]  R1637     3.3958196640014648e-01
    z[9,3,2]  R1638     3.8723897933959961e-01
    z[9,3,2]  R1639     3.9988216757774353e-01
    z[9,3,2]  R1640     7.4228219687938690e-02
    z[9,3,2]  R1641     1.4176069200038910e-01
    z[9,3,2]  R1642     7.7526587247848511e-01
    z[9,3,2]  R1643     8.9516741037368774e-01
    z[9,3,2]  R1644     3.5201448202133179e-01
    z[9,3,2]  R1645     5.7556211948394775e-01
    z[9,3,2]  R1646     2.4388627707958221e-01
    z[9,3,2]  R1647     1.9422550499439240e-01
    z[9,3,2]  R1648     2.5933519005775452e-01
    z[9,3,2]  R1649     0.202837273478508
    z[9,3,2]  R1650     3.2138973474502563e-01
    z[9,3,2]  R1651     4.2020189762115479e-01
    z[9,3,2]  R1652     -2.8708580136299133e-01
    z[9,3,2]  R1653     -4.6171575784683228e-02
    z[9,3,2]  R1654     -2.1103249490261078e-01
    z[9,3,2]  R1655     4.2556360363960266e-02
    z[9,3,2]  R1656     -3.3406227827072144e-02
    z[9,3,2]  R1657     -0.0990736186504364
    z[9,3,2]  R1658     1.3600957393646240e-01
    z[9,3,2]  R1659     1.1976634850725532e-03
    z[9,3,2]  R1660     0.0696486309170723
    z[9,3,2]  R1661     3.0957534909248352e-01
    z[9,3,2]  R1662     -1.2485025823116302e-01
    z[9,3,2]  R1663     -1.3977298513054848e-02
    z[9,3,2]  R1664     -0.208160862326622
    z[9,3,2]  R1665     8.8788039982318878e-02
    z[9,3,2]  R1666     -2.0874983072280884e-01
    z[9,3,2]  R1667     -7.1404181420803070e-02
    z[9,3,2]  R1668     -1.0149326175451279e-02
    z[9,3,2]  R1669     -2.1710006892681122e-01
    z[9,3,2]  R1670     3.2241743803024292e-01
    z[9,3,2]  R1671     -5.0627548247575760e-02
    z[9,3,2]  R1672     4.3066430091857910e-01
    z[9,3,2]  R1673     5.7679611444473267e-01
    z[9,3,2]  R1674     3.7671455740928650e-01
    z[9,3,2]  R1675     -1.7360439896583557e-01
    z[9,3,2]  R1676     1.0191214829683304e-01
    z[9,3,2]  R1677     1.2821683287620544e-01
    z[9,3,2]  R1678     -4.9768432974815369e-02
    z[9,3,2]  R1679     7.4249237775802612e-02
    z[9,3,2]  R1680     1.3735768198966980e-01
    z[9,3,2]  R1681     -1.8188828229904175e-01
    z[9,3,3]  R32       1
    z[9,3,3]  R86       -1
    z[9,3,3]  R1584     -1
    z[9,3,3]  R1585     1
    z[9,3,3]  R1592     -1.8052347004413605e-01
    z[9,3,3]  R1593     5.3283762186765671e-02
    z[9,3,3]  R1594     -4.3473982810974121e-01
    z[9,3,3]  R1595     2.1651349961757660e-01
    z[9,3,3]  R1596     -4.9789324402809143e-01
    z[9,3,3]  R1597     1.2577231228351593e-01
    z[9,3,3]  R1598     1.9749045372009277e-01
    z[9,3,3]  R1599     2.5030982494354248e-01
    z[9,3,3]  R1600     3.9309477806091309e-01
    z[9,3,3]  R1601     -4.4370139949023724e-03
    z[9,3,3]  R1602     -8.5052363574504852e-02
    z[9,3,3]  R1603     -1.7347997426986694e-01
    z[9,3,3]  R1604     1.3206608593463898e-01
    z[9,3,3]  R1605     1.8585222959518433e-01
    z[9,3,3]  R1606     -6.2713988125324249e-02
    z[9,3,3]  R1607     -0.0458403155207634
    z[9,3,3]  R1608     1.0051049292087555e-01
    z[9,3,3]  R1609     4.5493662357330322e-02
    z[9,3,3]  R1610     6.7066222429275513e-01
    z[9,3,3]  R1611     -3.6637911200523376e-01
    z[9,3,3]  R1612     1.6711705923080444e-01
    z[9,3,3]  R1613     -6.0624879598617554e-01
    z[9,3,3]  R1614     1.7043847590684891e-02
    z[9,3,3]  R1615     -1.6985219717025757e-01
    z[9,3,3]  R1616     3.2322707772254944e-01
    z[9,3,3]  R1617     -3.3934235572814941e-01
    z[9,3,3]  R1618     -6.7457742989063263e-02
    z[9,3,3]  R1619     2.3494258522987366e-01
    z[9,3,3]  R1620     3.4122428297996521e-01
    z[9,3,3]  R1621     4.2916625738143921e-01
    z[9,3,3]  R1622     -1.7377541959285736e-01
    z[9,3,3]  R1623     2.0292323082685471e-02
    z[9,3,3]  R1624     -4.3427139520645142e-01
    z[9,3,3]  R1625     -3.8042291998863220e-01
    z[9,3,3]  R1626     -5.1961505413055420e-01
    z[9,3,3]  R1627     1.4480647444725037e-01
    z[9,3,3]  R1628     8.0680213868618011e-02
    z[9,3,3]  R1629     4.9613124132156372e-01
    z[9,3,3]  R1630     4.5380535721778870e-01
    z[9,3,3]  R1631     1.2200967222452164e-01
    z[9,3,3]  R1632     -3.4977838397026062e-01
    z[9,3,3]  R1633     -2.0434801280498505e-01
    z[9,3,3]  R1634     -5.1644808053970337e-01
    z[9,3,3]  R1635     -1.8804410472512245e-02
    z[9,3,3]  R1636     3.9058357477188110e-01
    z[9,3,3]  R1637     4.0062817931175232e-01
    z[9,3,3]  R1638     3.0354353785514832e-01
    z[9,3,3]  R1639     4.3460509181022644e-01
    z[9,3,3]  R1640     1.4760607481002808e-01
    z[9,3,3]  R1641     3.7209221720695496e-01
    z[9,3,3]  R1642     0.07901581376791
    z[9,3,3]  R1643     0.14643594622612
    z[9,3,3]  R1644     1.8404580652713776e-01
    z[9,3,3]  R1645     -4.8148915171623230e-01
    z[9,3,3]  R1646     -2.5568547844886780e-01
    z[9,3,3]  R1647     1.2257728725671768e-01
    z[9,3,3]  R1648     -2.2818391025066376e-01
    z[9,3,3]  R1649     -3.1830493360757828e-02
    z[9,3,3]  R1650     8.9937351644039154e-02
    z[9,3,3]  R1651     -1.0073759406805038e-01
    z[9,3,3]  R1652     1.3321955502033234e-01
    z[9,3,3]  R1653     6.0039076954126358e-02
    z[9,3,3]  R1654     -9.3716740608215332e-02
    z[9,3,3]  R1655     4.2428936809301376e-02
    z[9,3,3]  R1656     -3.1878617405891418e-01
    z[9,3,3]  R1657     -6.2994378805160522e-01
    z[9,3,3]  R1658     9.8014205694198608e-02
    z[9,3,3]  R1659     -1.7204432189464569e-01
    z[9,3,3]  R1660     -1.6432275995612144e-02
    z[9,3,3]  R1661     5.1976222544908524e-02
    z[9,3,3]  R1662     -1.6308794915676117e-01
    z[9,3,3]  R1663     2.9764357209205627e-01
    z[9,3,3]  R1664     -5.3639984130859375e-01
    z[9,3,3]  R1665     -1.9266603887081146e-01
    z[9,3,3]  R1666     0.067952461540699
    z[9,3,3]  R1667     -1.9458861649036407e-01
    z[9,3,3]  R1668     3.9981618523597717e-01
    z[9,3,3]  R1669     -5.7392424345016479e-01
    z[9,3,3]  R1670     1.0243978351354599e-01
    z[9,3,3]  R1671     -1.8930040299892426e-02
    z[9,3,3]  R1672     -3.2287371158599854e-01
    z[9,3,3]  R1673     -1.6707479953765869e-01
    z[9,3,3]  R1674     2.4766427278518677e-01
    z[9,3,3]  R1675     7.4058908224105835e-01
    z[9,3,3]  R1676     -2.1980394423007965e-01
    z[9,3,3]  R1677     1.7972676083445549e-02
    z[9,3,3]  R1678     -2.1149446070194244e-01
    z[9,3,3]  R1679     -6.3981473445892334e-02
    z[9,3,3]  R1680     1.6020385921001434e-01
    z[9,3,3]  R1681     -4.2409861087799072e-01
    z[9,3,4]  R33       1
    z[9,3,4]  R87       -1
    z[9,3,4]  R1586     -1
    z[9,3,4]  R1587     1
    z[9,3,4]  R1592     1.5794004499912262e-01
    z[9,3,4]  R1593     -0.287248820066452
    z[9,3,4]  R1594     -4.6690490841865540e-01
    z[9,3,4]  R1595     -3.5223785042762756e-01
    z[9,3,4]  R1596     -3.3591628074645996e-01
    z[9,3,4]  R1597     -5.2343004941940308e-01
    z[9,3,4]  R1598     -1.2184038013219833e-01
    z[9,3,4]  R1599     -8.3195351064205170e-02
    z[9,3,4]  R1600     4.4558685272932053e-02
    z[9,3,4]  R1601     -6.4415490627288818e-01
    z[9,3,4]  R1602     -3.8812708109617233e-02
    z[9,3,4]  R1603     7.4055716395378113e-03
    z[9,3,4]  R1604     -1.5727436542510986e-01
    z[9,3,4]  R1605     4.6703465282917023e-02
    z[9,3,4]  R1606     5.7107192277908325e-01
    z[9,3,4]  R1607     -3.9166450500488281e-02
    z[9,3,4]  R1608     6.7736767232418060e-02
    z[9,3,4]  R1609     8.7502032518386841e-02
    z[9,3,4]  R1610     -1.7671035602688789e-02
    z[9,3,4]  R1611     5.8958941698074341e-01
    z[9,3,4]  R1612     1.9108204171061516e-02
    z[9,3,4]  R1613     1.2698955833911896e-01
    z[9,3,4]  R1614     -3.3748939633369446e-02
    z[9,3,4]  R1615     -3.2901132106781006e-01
    z[9,3,4]  R1616     -6.1276316642761230e-02
    z[9,3,4]  R1617     -5.1297068595886230e-02
    z[9,3,4]  R1618     -2.2719316184520721e-01
    z[9,3,4]  R1619     -2.5636243820190430e-01
    z[9,3,4]  R1620     3.4080383181571960e-01
    z[9,3,4]  R1621     -8.4892563521862030e-02
    z[9,3,4]  R1622     5.3927540779113770e-01
    z[9,3,4]  R1623     5.7670968770980835e-01
    z[9,3,4]  R1624     1.1724369972944260e-01
    z[9,3,4]  R1625     5.1187109947204590e-01
    z[9,3,4]  R1626     4.8995384573936462e-01
    z[9,3,4]  R1627     -4.4858568906784058e-01
    z[9,3,4]  R1628     4.0596362948417664e-01
    z[9,3,4]  R1629     -2.9080381616950035e-02
    z[9,3,4]  R1630     2.3985201492905617e-02
    z[9,3,4]  R1631     5.3897273540496826e-01
    z[9,3,4]  R1632     2.5838559865951538e-01
    z[9,3,4]  R1633     9.1996602714061737e-02
    z[9,3,4]  R1634     1.8558706343173981e-01
    z[9,3,4]  R1635     6.3261657953262329e-01
    z[9,3,4]  R1636     3.5041567683219910e-01
    z[9,3,4]  R1637     -3.8997948169708252e-01
    z[9,3,4]  R1638     -2.3826885968446732e-02
    z[9,3,4]  R1639     -1.9107882678508759e-01
    z[9,3,4]  R1640     -2.1714706718921661e-01
    z[9,3,4]  R1641     -1.2603472173213959e-01
    z[9,3,4]  R1642     -1.5118260681629181e-01
    z[9,3,4]  R1643     -1.2110810726881027e-01
    z[9,3,4]  R1644     3.0696511268615723e-01
    z[9,3,4]  R1645     9.3824982643127441e-02
    z[9,3,4]  R1646     5.6252223253250122e-01
    z[9,3,4]  R1647     4.5384871959686279e-01
    z[9,3,4]  R1648     3.0659487843513489e-01
    z[9,3,4]  R1649     -2.3273593187332153e-01
    z[9,3,4]  R1650     -1.6773466765880585e-01
    z[9,3,4]  R1651     -1.9281828776001930e-02
    z[9,3,4]  R1652     -3.8209676742553711e-01
    z[9,3,4]  R1653     -6.9468045234680176e-01
    z[9,3,4]  R1654     -1.7974703013896942e-01
    z[9,3,4]  R1655     -2.7379241585731506e-01
    z[9,3,4]  R1656     -6.6507525742053986e-02
    z[9,3,4]  R1657     2.2297158837318420e-01
    z[9,3,4]  R1658     -2.7357056736946106e-01
    z[9,3,4]  R1659     2.1131275594234467e-01
    z[9,3,4]  R1660     -2.1221134066581726e-01
    z[9,3,4]  R1661     3.5109922289848328e-02
    z[9,3,4]  R1662     -0.242910698056221
    z[9,3,4]  R1663     -6.4958351850509644e-01
    z[9,3,4]  R1664     -8.3872549235820770e-02
    z[9,3,4]  R1665     2.5922521948814392e-01
    z[9,3,4]  R1666     5.6454139947891235e-01
    z[9,3,4]  R1667     7.3291277885437012e-01
    z[9,3,4]  R1668     1.1814720183610916e-01
    z[9,3,4]  R1669     2.6722148060798645e-01
    z[9,3,4]  R1670     3.0719587206840515e-01
    z[9,3,4]  R1671     -5.8366615325212479e-02
    z[9,3,4]  R1672     -2.9494842886924744e-01
    z[9,3,4]  R1673     -1.6150401532649994e-01
    z[9,3,4]  R1674     -1.4807645976543427e-01
    z[9,3,4]  R1675     1.3833388686180115e-01
    z[9,3,4]  R1676     -1.4137434959411621e-01
    z[9,3,4]  R1677     8.2156389951705933e-02
    z[9,3,4]  R1678     2.8801393508911133e-01
    z[9,3,4]  R1679     4.7589689493179321e-01
    z[9,3,4]  R1680     3.6816483736038208e-01
    z[9,3,4]  R1681     1.2181729823350906e-01
    z[9,3,5]  R34       1
    z[9,3,5]  R88       -1
    z[9,3,5]  R1588     -1
    z[9,3,5]  R1589     1
    z[9,3,5]  R1592     -2.7535766363143921e-01
    z[9,3,5]  R1593     -4.7670555114746094e-01
    z[9,3,5]  R1594     3.0889594927430153e-02
    z[9,3,5]  R1595     1.0734009742736816e-01
    z[9,3,5]  R1596     -2.5883340835571289e-01
    z[9,3,5]  R1597     1.1961440742015839e-01
    z[9,3,5]  R1598     3.0453236773610115e-02
    z[9,3,5]  R1599     -2.4219313263893127e-01
    z[9,3,5]  R1600     -3.7171486020088196e-01
    z[9,3,5]  R1601     -4.3663722276687622e-01
    z[9,3,5]  R1602     7.2335839271545410e-02
    z[9,3,5]  R1603     -1.1631545424461365e-01
    z[9,3,5]  R1604     -1.3624674081802368e-01
    z[9,3,5]  R1605     2.5760984420776367e-01
    z[9,3,5]  R1606     3.2423117756843567e-01
    z[9,3,5]  R1607     7.3119446635246277e-02
    z[9,3,5]  R1608     -6.3303269445896149e-02
    z[9,3,5]  R1609     1.8382611870765686e-01
    z[9,3,5]  R1610     2.8376647830009460e-01
    z[9,3,5]  R1611     1.5907536447048187e-01
    z[9,3,5]  R1612     -1.4546471834182739e-01
    z[9,3,5]  R1613     -2.4275135993957520e-01
    z[9,3,5]  R1614     6.1934083700180054e-01
    z[9,3,5]  R1615     2.7800858020782471e-01
    z[9,3,5]  R1616     5.0388675928115845e-01
    z[9,3,5]  R1617     -5.6846532970666885e-02
    z[9,3,5]  R1618     3.6254499107599258e-02
    z[9,3,5]  R1619     -3.7607285380363464e-01
    z[9,3,5]  R1620     5.0147105008363724e-02
    z[9,3,5]  R1621     -9.4526156783103943e-02
    z[9,3,5]  R1622     -2.3553647100925446e-02
    z[9,3,5]  R1623     3.8908076286315918e-01
    z[9,3,5]  R1624     -5.6547969579696655e-01
    z[9,3,5]  R1625     2.4374131858348846e-01
    z[9,3,5]  R1626     3.1710278242826462e-02
    z[9,3,5]  R1627     1.4875052869319916e-01
    z[9,3,5]  R1628     3.3772411942481995e-01
    z[9,3,5]  R1629     1.4556702971458435e-01
    z[9,3,5]  R1630     6.0349458456039429e-01
    z[9,3,5]  R1631     -2.3410108685493469e-01
    z[9,3,5]  R1632     2.3875202238559723e-01
    z[9,3,5]  R1633     0.532198429107666
    z[9,3,5]  R1634     -8.8648170232772827e-02
    z[9,3,5]  R1635     -1.3305827043950558e-02
    z[9,3,5]  R1636     -3.9736879989504814e-03
    z[9,3,5]  R1637     0.3140889108181
    z[9,3,5]  R1638     -4.4955092668533325e-01
    z[9,3,5]  R1639     -5.2958631515502930e-01
    z[9,3,5]  R1640     -4.5618087053298950e-01
    z[9,3,5]  R1641     -2.2290091216564178e-01
    z[9,3,5]  R1642     1.4710752665996552e-01
    z[9,3,5]  R1643     5.5916242301464081e-02
    z[9,3,5]  R1644     -4.3696433305740356e-01
    z[9,3,5]  R1645     1.7973285913467407e-01
    z[9,3,5]  R1646     5.2761003375053406e-02
    z[9,3,5]  R1647     -4.1906601190567017e-01
    z[9,3,5]  R1648     -2.1328464150428772e-01
    z[9,3,5]  R1649     -3.1065386533737183e-01
    z[9,3,5]  R1650     -3.6468520760536194e-02
    z[9,3,5]  R1651     2.5497859343886375e-02
    z[9,3,5]  R1652     4.7373014688491821e-01
    z[9,3,5]  R1653     3.4413686394691467e-01
    z[9,3,5]  R1654     1.0588242113590240e-01
    z[9,3,5]  R1655     -5.6741183996200562e-01
    z[9,3,5]  R1656     -1.9991537928581238e-01
    z[9,3,5]  R1657     4.0387919545173645e-01
    z[9,3,5]  R1658     4.9634307622909546e-01
    z[9,3,5]  R1659     -3.8713118433952332e-01
    z[9,3,5]  R1660     6.3142009079456329e-02
    z[9,3,5]  R1661     -3.2969031017273664e-03
    z[9,3,5]  R1662     3.0698272585868835e-01
    z[9,3,5]  R1663     -1.0310070216655731e-01
    z[9,3,5]  R1664     4.5047125220298767e-01
    z[9,3,5]  R1665     6.7605400085449219e-01
    z[9,3,5]  R1666     1.3374383747577667e-01
    z[9,3,5]  R1667     3.3290737867355347e-01
    z[9,3,5]  R1668     -0.0471990704536438
    z[9,3,5]  R1669     -2.4472513794898987e-01
    z[9,3,5]  R1670     -2.2847951948642731e-01
    z[9,3,5]  R1671     1.9362162053585052e-01
    z[9,3,5]  R1672     1.2813235819339752e-01
    z[9,3,5]  R1673     -2.9364410042762756e-01
    z[9,3,5]  R1674     3.1093168258666992e-01
    z[9,3,5]  R1675     2.8522640466690063e-01
    z[9,3,5]  R1676     -2.9728201031684875e-01
    z[9,3,5]  R1677     -3.9887115359306335e-01
    z[9,3,5]  R1678     -1.6919489204883575e-01
    z[9,3,5]  R1679     -2.6922725141048431e-02
    z[9,3,5]  R1680     -1.3203187286853790e-01
    z[9,3,5]  R1681     -1.9959259033203125e-01
    z[9,3,6]  R35       1
    z[9,3,6]  R89       -1
    z[9,3,6]  R1590     -1
    z[9,3,6]  R1591     1
    z[9,3,6]  R1592     -0.289164662361145
    z[9,3,6]  R1593     2.4522738531231880e-02
    z[9,3,6]  R1594     2.5590965151786804e-01
    z[9,3,6]  R1595     -3.7311750650405884e-01
    z[9,3,6]  R1596     -2.2620756924152374e-01
    z[9,3,6]  R1597     -1.4772605895996094e-01
    z[9,3,6]  R1598     0.128773495554924
    z[9,3,6]  R1599     -4.7608497738838196e-01
    z[9,3,6]  R1600     -6.4299941062927246e-01
    z[9,3,6]  R1601     -1.4596696197986603e-01
    z[9,3,6]  R1602     8.9961051940917969e-02
    z[9,3,6]  R1603     -8.0054707825183868e-02
    z[9,3,6]  R1604     -3.9782442152500153e-02
    z[9,3,6]  R1605     -6.8114414811134338e-02
    z[9,3,6]  R1606     4.4111007452011108e-01
    z[9,3,6]  R1607     -3.1494843959808350e-01
    z[9,3,6]  R1608     3.0385980010032654e-01
    z[9,3,6]  R1609     2.3639582097530365e-01
    z[9,3,6]  R1610     4.2337965965270996e-01
    z[9,3,6]  R1611     -4.6211636066436768e-01
    z[9,3,6]  R1612     2.7650898694992065e-01
    z[9,3,6]  R1613     1.2029550969600677e-01
    z[9,3,6]  R1614     -0.367557555437088
    z[9,3,6]  R1615     -6.6486102342605591e-01
    z[9,3,6]  R1616     2.4418263137340546e-01
    z[9,3,6]  R1617     -3.9550852775573730e-01
    z[9,3,6]  R1618     6.5928483009338379e-01
    z[9,3,6]  R1619     4.3085891008377075e-01
    z[9,3,6]  R1620     3.9106476306915283e-01
    z[9,3,6]  R1621     -3.1564164161682129e-01
    z[9,3,6]  R1622     3.4440398216247559e-01
    z[9,3,6]  R1623     2.4238672852516174e-01
    z[9,3,6]  R1624     8.0896958708763123e-02
    z[9,3,6]  R1625     1.1481685936450958e-01
    z[9,3,6]  R1626     9.6243396401405334e-02
    z[9,3,6]  R1627     -2.6154699921607971e-01
    z[9,3,6]  R1628     -2.4617652595043182e-01
    z[9,3,6]  R1629     3.5888656973838806e-01
    z[9,3,6]  R1630     -1.4568477869033813e-01
    z[9,3,6]  R1631     -8.4414698183536530e-02
    z[9,3,6]  R1632     7.7482990920543671e-02
    z[9,3,6]  R1633     1.1786509305238724e-01
    z[9,3,6]  R1634     -2.7869653701782227e-01
    z[9,3,6]  R1635     -4.2002275586128235e-01
    z[9,3,6]  R1636     -9.0852063149213791e-03
    z[9,3,6]  R1637     1.5262927114963531e-01
    z[9,3,6]  R1638     -1.0978161543607712e-01
    z[9,3,6]  R1639     2.3072727024555206e-01
    z[9,3,6]  R1640     -5.3429072722792625e-03
    z[9,3,6]  R1641     -3.3589568734169006e-01
    z[9,3,6]  R1642     1.7206548154354095e-01
    z[9,3,6]  R1643     -2.2013604640960693e-01
    z[9,3,6]  R1644     -4.1592967510223389e-01
    z[9,3,6]  R1645     3.1965491175651550e-01
    z[9,3,6]  R1646     -7.8862540423870087e-02
    z[9,3,6]  R1647     4.4223007559776306e-01
    z[9,3,6]  R1648     1.3842076063156128e-01
    z[9,3,6]  R1649     8.0339181423187256e-01
    z[9,3,6]  R1650     -4.7521837055683136e-02
    z[9,3,6]  R1651     1.2020229548215866e-01
    z[9,3,6]  R1652     -5.0076227635145187e-02
    z[9,3,6]  R1653     -2.4653879925608635e-02
    z[9,3,6]  R1654     5.5876958370208740e-01
    z[9,3,6]  R1655     3.0013734102249146e-01
    z[9,3,6]  R1656     1.0981138795614243e-01
    z[9,3,6]  R1657     -2.3106880486011505e-01
    z[9,3,6]  R1658     -5.8837193250656128e-01
    z[9,3,6]  R1659     -2.6153776049613953e-01
    z[9,3,6]  R1660     -5.8548414707183838e-01
    z[9,3,6]  R1661     -1.6975912451744080e-01
    z[9,3,6]  R1662     -3.8777709007263184e-01
    z[9,3,6]  R1663     4.2124241590499878e-01
    z[9,3,6]  R1664     2.3847469687461853e-01
    z[9,3,6]  R1665     1.8114395439624786e-01
    z[9,3,6]  R1666     3.6959323287010193e-01
    z[9,3,6]  R1667     -1.0266353935003281e-01
    z[9,3,6]  R1668     -2.7397081255912781e-01
    z[9,3,6]  R1669     2.3994588851928711e-01
    z[9,3,6]  R1670     6.2200784683227539e-01
    z[9,3,6]  R1671     9.7674198448657990e-02
    z[9,3,6]  R1672     -4.7831791453063488e-03
    z[9,3,6]  R1673     3.0158025026321411e-01
    z[9,3,6]  R1674     3.1003820896148682e-01
    z[9,3,6]  R1675     1.0133621096611023e-01
    z[9,3,6]  R1676     1.4268645644187927e-01
    z[9,3,6]  R1677     2.1593706309795380e-01
    z[9,3,6]  R1678     -3.2391491532325745e-01
    z[9,3,6]  R1679     -2.4074141681194305e-01
    z[9,3,6]  R1680     -2.4229244887828827e-01
    z[9,3,6]  R1681     1.2261576205492020e-01
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R1736     -1
    z[4,5,0]  R1737     1
    z[4,5,0]  R1750     -5.7972317934036255e-01
    z[4,5,0]  R1751     -7.6502150297164917e-01
    z[4,5,0]  R1752     -7.1177893877029419e-01
    z[4,5,0]  R1753     -7.0715343952178955e-01
    z[4,5,0]  R1754     -5.0080770254135132e-01
    z[4,5,0]  R1755     -7.7686232328414917e-01
    z[4,5,0]  R1756     -4.0485724806785583e-01
    z[4,5,0]  R1757     -7.1330323815345764e-02
    z[4,5,0]  R1758     -2.0989847183227539e-01
    z[4,5,0]  R1759     4.5504495501518250e-01
    z[4,5,0]  R1760     2.0747885107994080e-01
    z[4,5,0]  R1761     -4.9686175584793091e-01
    z[4,5,0]  R1762     5.3532477468252182e-02
    z[4,5,0]  R1763     8.8198864459991455e-01
    z[4,5,0]  R1764     8.8591843843460083e-01
    z[4,5,0]  R1765     8.7120288610458374e-01
    z[4,5,0]  R1766     4.3611773848533630e-01
    z[4,5,0]  R1767     3.5592919588088989e-01
    z[4,5,0]  R1768     0.86301189661026
    z[4,5,0]  R1769     8.7381732463836670e-01
    z[4,5,0]  R1770     5.0713205337524414e-01
    z[4,5,0]  R1771     -3.0775934457778931e-01
    z[4,5,0]  R1772     -1.3161900639533997e-01
    z[4,5,0]  R1773     -1.0995452851057053e-01
    z[4,5,0]  R1774     -1.9690018892288208e-01
    z[4,5,0]  R1775     -1.0541586577892303e-01
    z[4,5,0]  R1776     -9.6146740019321442e-02
    z[4,5,0]  R1777     7.6432503759860992e-02
    z[4,5,0]  R1778     -1.5052518248558044e-01
    z[4,5,0]  R1779     -0.0409589558839798
    z[4,5,0]  R1780     4.5085424184799194e-01
    z[4,5,0]  R1781     0.948215126991272
    z[4,5,0]  R1782     4.6942993998527527e-01
    z[4,5,0]  R1783     6.2622010707855225e-01
    z[4,5,0]  R1784     6.5410810708999634e-01
    z[4,5,0]  R1785     5.8166539669036865e-01
    z[4,5,0]  R1786     6.3407623767852783e-01
    z[4,5,0]  R1787     4.1721984744071960e-01
    z[4,5,0]  R1788     8.5299199819564819e-01
    z[4,5,0]  R1789     6.1620497703552246e-01
    z[4,5,0]  R1790     1.1186915449798107e-02
    z[4,5,0]  R1791     -4.8215375281870365e-03
    z[4,5,0]  R1792     -3.1158182024955750e-01
    z[4,5,0]  R1793     -4.5451480150222778e-01
    z[4,5,0]  R1794     -6.3648438453674316e-01
    z[4,5,0]  R1795     -5.5495697259902954e-01
    z[4,5,0]  R1796     -9.0682422742247581e-03
    z[4,5,0]  R1797     1.0719141364097595e-01
    z[4,5,0]  R1798     3.4995445609092712e-01
    z[4,5,0]  R1799     -3.2522717118263245e-01
    z[4,5,0]  R1800     -5.2713447809219360e-01
    z[4,5,0]  R1801     1.8959281966090202e-02
    z[4,5,0]  R1802     2.4771073460578918e-01
    z[4,5,0]  R1803     -6.5029990673065186e-01
    z[4,5,0]  R1804     1.4037866890430450e-01
    z[4,5,0]  R1805     1.8609800934791565e-01
    z[4,5,0]  R1806     -0.00932371336966753
    z[4,5,0]  R1807     6.1752386391162872e-02
    z[4,5,0]  R1808     -9.8541423678398132e-02
    z[4,5,0]  R1809     2.8609317541122437e-01
    z[4,5,0]  R1810     8.6865060031414032e-02
    z[4,5,0]  R1811     -2.8792256116867065e-01
    z[4,5,0]  R1812     -3.8555711507797241e-02
    z[4,5,0]  R1813     1.6615432500839233e-01
    z[4,5,0]  R1814     -3.5495206713676453e-02
    z[4,5,0]  R1815     4.3524277210235596e-01
    z[4,5,0]  R1816     2.6447480916976929e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R1738     -1
    z[4,5,1]  R1739     1
    z[4,5,1]  R1750     -2.7955442667007446e-01
    z[4,5,1]  R1751     -3.3829516172409058e-01
    z[4,5,1]  R1752     -8.5102990269660950e-02
    z[4,5,1]  R1753     -0.592068076133728
    z[4,5,1]  R1754     -3.8465267419815063e-01
    z[4,5,1]  R1755     -1.9518250226974487e-01
    z[4,5,1]  R1756     -2.2412414848804474e-01
    z[4,5,1]  R1757     3.2590541243553162e-01
    z[4,5,1]  R1758     -5.7407461106777191e-02
    z[4,5,1]  R1759     -4.4644474983215332e-01
    z[4,5,1]  R1760     -8.5024875402450562e-01
    z[4,5,1]  R1761     8.8031284511089325e-02
    z[4,5,1]  R1762     -5.8409631252288818e-01
    z[4,5,1]  R1763     -3.9237055182456970e-01
    z[4,5,1]  R1764     -3.1708675622940063e-01
    z[4,5,1]  R1765     -3.9633682370185852e-01
    z[4,5,1]  R1766     -6.8332219123840332e-01
    z[4,5,1]  R1767     -4.9160975217819214e-01
    z[4,5,1]  R1768     -3.3863878250122070e-01
    z[4,5,1]  R1769     -2.8951865434646606e-01
    z[4,5,1]  R1770     -6.7540162801742554e-01
    z[4,5,1]  R1771     9.2551183700561523e-01
    z[4,5,1]  R1772     9.6815145015716553e-01
    z[4,5,1]  R1773     9.6989828348159790e-01
    z[4,5,1]  R1774     9.1882050037384033e-01
    z[4,5,1]  R1775     9.4148808717727661e-01
    z[4,5,1]  R1776     0.953998327255249
    z[4,5,1]  R1777     9.8180347681045532e-01
    z[4,5,1]  R1778     0.920976459980011
    z[4,5,1]  R1779     9.7002464532852173e-01
    z[4,5,1]  R1780     -3.8136070966720581e-01
    z[4,5,1]  R1781     -6.7426353693008423e-02
    z[4,5,1]  R1782     -6.6137647628784180e-01
    z[4,5,1]  R1783     2.0332412421703339e-01
    z[4,5,1]  R1784     -2.2642524540424347e-01
    z[4,5,1]  R1785     3.0499300360679626e-01
    z[4,5,1]  R1786     -1.1251514405012131e-01
    z[4,5,1]  R1787     5.1701503992080688e-01
    z[4,5,1]  R1788     1.4222370088100433e-01
    z[4,5,1]  R1789     -3.2608166337013245e-01
    z[4,5,1]  R1790     -2.8183379769325256e-01
    z[4,5,1]  R1791     -4.3488350510597229e-01
    z[4,5,1]  R1792     4.9660235643386841e-01
    z[4,5,1]  R1793     6.6657382249832153e-01
    z[4,5,1]  R1794     3.3694645762443542e-01
    z[4,5,1]  R1795     6.0095584392547607e-01
    z[4,5,1]  R1796     8.8974541425704956e-01
    z[4,5,1]  R1797     0.454041987657547
    z[4,5,1]  R1798     8.6570811271667480e-01
    z[4,5,1]  R1799     6.2760341167449951e-01
    z[4,5,1]  R1800     -5.5866867303848267e-01
    z[4,5,1]  R1801     -5.9417122602462769e-01
    z[4,5,1]  R1802     -7.2897613048553467e-01
    z[4,5,1]  R1803     0.0097170639783144
    z[4,5,1]  R1804     7.5981557369232178e-01
    z[4,5,1]  R1805     7.6729327440261841e-01
    z[4,5,1]  R1806     7.8068637847900391e-01
    z[4,5,1]  R1807     5.2841019630432129e-01
    z[4,5,1]  R1808     7.7418565750122070e-01
    z[4,5,1]  R1809     8.0917710065841675e-01
    z[4,5,1]  R1810     8.6591434478759766e-01
    z[4,5,1]  R1811     7.7511388063430786e-01
    z[4,5,1]  R1812     7.3167085647583008e-01
    z[4,5,1]  R1813     6.2748539447784424e-01
    z[4,5,1]  R1814     8.4570759534835815e-01
    z[4,5,1]  R1815     5.8977931737899780e-01
    z[4,5,1]  R1816     6.4801257848739624e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R1740     -1
    z[4,5,2]  R1741     1
    z[4,5,2]  R1750     -1.7431795597076416e-01
    z[4,5,2]  R1751     -2.6106369495391846e-01
    z[4,5,2]  R1752     -4.4017231464385986e-01
    z[4,5,2]  R1753     -4.7031562775373459e-02
    z[4,5,2]  R1754     -1.5521739423274994e-01
    z[4,5,2]  R1755     -3.0772429704666138e-01
    z[4,5,2]  R1756     -8.2980763912200928e-01
    z[4,5,2]  R1757     -5.1815962791442871e-01
    z[4,5,2]  R1758     -3.4970918297767639e-01
    z[4,5,2]  R1759     -1.2851508334279060e-02
    z[4,5,2]  R1760     -0.064329132437706
    z[4,5,2]  R1761     -2.6872813701629639e-01
    z[4,5,2]  R1762     -1.1712085455656052e-01
    z[4,5,2]  R1763     5.8494519442319870e-02
    z[4,5,2]  R1764     -7.0008113980293274e-02
    z[4,5,2]  R1765     6.9923967123031616e-02
    z[4,5,2]  R1766     -1.6761665046215057e-01
    z[4,5,2]  R1767     -1.7568540573120117e-01
    z[4,5,2]  R1768     -3.3721212297677994e-02
    z[4,5,2]  R1769     -2.4386551976203918e-01
    z[4,5,2]  R1770     3.9617738127708435e-01
    z[4,5,2]  R1771     1.8921536207199097e-01
    z[4,5,2]  R1772     -9.0488076210021973e-02
    z[4,5,2]  R1773     -3.3312514424324036e-02
    z[4,5,2]  R1774     1.2171571701765060e-01
    z[4,5,2]  R1775     -2.3459148406982422e-01
    z[4,5,2]  R1776     7.2983093559741974e-02
    z[4,5,2]  R1777     1.1208556592464447e-01
    z[4,5,2]  R1778     1.4783999323844910e-01
    z[4,5,2]  R1779     -0.0674082413315773
    z[4,5,2]  R1780     -1.7220650613307953e-01
    z[4,5,2]  R1781     2.4402961134910583e-01
    z[4,5,2]  R1782     3.4998139739036560e-01
    z[4,5,2]  R1783     3.4280881285667419e-01
    z[4,5,2]  R1784     3.6785191297531128e-01
    z[4,5,2]  R1785     2.2790899872779846e-01
    z[4,5,2]  R1786     3.0890521407127380e-01
    z[4,5,2]  R1787     -4.8213177919387817e-01
    z[4,5,2]  R1788     1.6244347393512726e-01
    z[4,5,2]  R1789     1.2620979547500610e-01
    z[4,5,2]  R1790     -2.1567940711975098e-01
    z[4,5,2]  R1791     1.3756586611270905e-01
    z[4,5,2]  R1792     -6.0235446691513062e-01
    z[4,5,2]  R1793     -1.3066259026527405e-01
    z[4,5,2]  R1794     -5.2772867679595947e-01
    z[4,5,2]  R1795     -1.9353452324867249e-01
    z[4,5,2]  R1796     -0.0511116087436676
    z[4,5,2]  R1797     -5.7751423120498657e-01
    z[4,5,2]  R1798     2.8160056471824646e-01
    z[4,5,2]  R1799     4.2929247021675110e-01
    z[4,5,2]  R1800     -2.3929375410079956e-01
    z[4,5,2]  R1801     4.3117862194776535e-02
    z[4,5,2]  R1802     -4.9465906620025635e-01
    z[4,5,2]  R1803     2.2865265607833862e-01
    z[4,5,2]  R1804     0.264136403799057
    z[4,5,2]  R1805     -3.5222183912992477e-02
    z[4,5,2]  R1806     3.0547997355461121e-01
    z[4,5,2]  R1807     -3.2193638384342194e-02
    z[4,5,2]  R1808     4.7409462928771973e-01
    z[4,5,2]  R1809     -1.0327765345573425e-01
    z[4,5,2]  R1810     6.5677843987941742e-02
    z[4,5,2]  R1811     4.6928778290748596e-01
    z[4,5,2]  R1812     3.7477472424507141e-01
    z[4,5,2]  R1813     -1.6672912240028381e-01
    z[4,5,2]  R1814     3.1196582317352295e-01
    z[4,5,2]  R1815     -0.039963249117136
    z[4,5,2]  R1816     5.4550009965896606e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R1742     -1
    z[4,5,3]  R1743     1
    z[4,5,3]  R1750     0.00803461018949747
    z[4,5,3]  R1751     -3.0085292458534241e-01
    z[4,5,3]  R1752     -2.5804473087191582e-02
    z[4,5,3]  R1753     1.1786479502916336e-01
    z[4,5,3]  R1754     -9.9384687840938568e-02
    z[4,5,3]  R1755     8.4044739603996277e-02
    z[4,5,3]  R1756     -1.6016146540641785e-01
    z[4,5,3]  R1757     4.8659469932317734e-02
    z[4,5,3]  R1758     2.2356024384498596e-01
    z[4,5,3]  R1759     7.8668624162673950e-02
    z[4,5,3]  R1760     2.5957694649696350e-01
    z[4,5,3]  R1761     0.396978497505188
    z[4,5,3]  R1762     2.1976348757743835e-01
    z[4,5,3]  R1763     1.8401291966438293e-01
    z[4,5,3]  R1764     0.0713120549917221
    z[4,5,3]  R1765     1.6418716311454773e-01
    z[4,5,3]  R1766     1.6098621487617493e-01
    z[4,5,3]  R1767     3.1258836388587952e-01
    z[4,5,3]  R1768     -6.4314864575862885e-02
    z[4,5,3]  R1769     -2.0116370916366577e-01
    z[4,5,3]  R1770     1.2760446965694427e-01
    z[4,5,3]  R1771     -3.3711224794387817e-02
    z[4,5,3]  R1772     -1.4838449656963348e-01
    z[4,5,3]  R1773     1.4235946536064148e-01
    z[4,5,3]  R1774     -1.6547230188734829e-04
    z[4,5,3]  R1775     -1.0569803416728973e-01
    z[4,5,3]  R1776     -2.0552964508533478e-01
    z[4,5,3]  R1777     -9.1635994613170624e-02
    z[4,5,3]  R1778     3.3478941768407822e-02
    z[4,5,3]  R1779     1.0103969275951385e-01
    z[4,5,3]  R1780     4.3513849377632141e-01
    z[4,5,3]  R1781     1.8716195598244667e-02
    z[4,5,3]  R1782     4.1821590065956116e-01
    z[4,5,3]  R1783     3.3363819122314453e-01
    z[4,5,3]  R1784     -3.4760600328445435e-01
    z[4,5,3]  R1785     2.4602463841438293e-01
    z[4,5,3]  R1786     -3.1204387545585632e-01
    z[4,5,3]  R1787     1.8816350400447845e-01
    z[4,5,3]  R1788     1.6779004037380219e-01
    z[4,5,3]  R1789     -0.586354672908783
    z[4,5,3]  R1790     -4.2259678244590759e-02
    z[4,5,3]  R1791     -2.0097452402114868e-01
    z[4,5,3]  R1792     1.9554542005062103e-01
    z[4,5,3]  R1793     1.7396594583988190e-01
    z[4,5,3]  R1794     8.2013376057147980e-02
    z[4,5,3]  R1795     2.1507333219051361e-01
    z[4,5,3]  R1796     -3.3189707994461060e-01
    z[4,5,3]  R1797     -6.3638072460889816e-03
    z[4,5,3]  R1798     -1.6793160140514374e-01
    z[4,5,3]  R1799     1.8136581778526306e-01
    z[4,5,3]  R1800     4.6828565001487732e-01
    z[4,5,3]  R1801     4.3812346458435059e-01
    z[4,5,3]  R1802     -1.2449848465621471e-02
    z[4,5,3]  R1803     -0.594612181186676
    z[4,5,3]  R1804     5.2426481246948242e-01
    z[4,5,3]  R1805     -1.9637893140316010e-01
    z[4,5,3]  R1806     3.5327067971229553e-01
    z[4,5,3]  R1807     -4.8578137159347534e-01
    z[4,5,3]  R1808     -3.4470051527023315e-01
    z[4,5,3]  R1809     4.2890289425849915e-01
    z[4,5,3]  R1810     0.469659686088562
    z[4,5,3]  R1811     -1.1294345557689667e-01
    z[4,5,3]  R1812     -1.6868086159229279e-01
    z[4,5,3]  R1813     -3.0988928675651550e-01
    z[4,5,3]  R1814     -3.2227909564971924e-01
    z[4,5,3]  R1815     0.128465473651886
    z[4,5,3]  R1816     -1.9517371058464050e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R1744     -1
    z[4,5,4]  R1745     1
    z[4,5,4]  R1750     4.1871714591979980e-01
    z[4,5,4]  R1751     9.4915606081485748e-02
    z[4,5,4]  R1752     6.2939259223639965e-03
    z[4,5,4]  R1753     1.9346331059932709e-01
    z[4,5,4]  R1754     7.2424495220184326e-01
    z[4,5,4]  R1755     2.2348937392234802e-01
    z[4,5,4]  R1756     1.6697567701339722e-01
    z[4,5,4]  R1757     -0.338199257850647
    z[4,5,4]  R1758     -6.8334378302097321e-02
    z[4,5,4]  R1759     -5.3270375728607178e-01
    z[4,5,4]  R1760     -3.9284810423851013e-01
    z[4,5,4]  R1761     -3.8132596015930176e-01
    z[4,5,4]  R1762     -5.3212392330169678e-01
    z[4,5,4]  R1763     2.1966744214296341e-02
    z[4,5,4]  R1764     0.299346387386322
    z[4,5,4]  R1765     7.1223303675651550e-02
    z[4,5,4]  R1766     -0.164293110370636
    z[4,5,4]  R1767     -5.6559962034225464e-01
    z[4,5,4]  R1768     -1.1556020379066467e-01
    z[4,5,4]  R1769     -7.6886273920536041e-02
    z[4,5,4]  R1770     0.273183673620224
    z[4,5,4]  R1771     -4.2394332587718964e-02
    z[4,5,4]  R1772     -7.9268120229244232e-02
    z[4,5,4]  R1773     1.0167615860700607e-01
    z[4,5,4]  R1774     2.5087258219718933e-01
    z[4,5,4]  R1775     1.3830369710922241e-01
    z[4,5,4]  R1776     1.6467517614364624e-01
    z[4,5,4]  R1777     5.8026801794767380e-02
    z[4,5,4]  R1778     -2.1456320583820343e-01
    z[4,5,4]  R1779     -1.4798012375831604e-01
    z[4,5,4]  R1780     -3.0146420001983643e-01
    z[4,5,4]  R1781     1.8179299309849739e-02
    z[4,5,4]  R1782     1.8484836816787720e-01
    z[4,5,4]  R1783     -5.3182154893875122e-01
    z[4,5,4]  R1784     -2.0608678460121155e-01
    z[4,5,4]  R1785     -6.4921277761459351e-01
    z[4,5,4]  R1786     -3.2309678196907043e-01
    z[4,5,4]  R1787     4.6985435485839844e-01
    z[4,5,4]  R1788     -3.9330765604972839e-01
    z[4,5,4]  R1789     -1.2006111443042755e-01
    z[4,5,4]  R1790     0.509081244468689
    z[4,5,4]  R1791     -3.8225552439689636e-01
    z[4,5,4]  R1792     -4.0255087614059448e-01
    z[4,5,4]  R1793     -3.5617059469223022e-01
    z[4,5,4]  R1794     -1.9378559291362762e-01
    z[4,5,4]  R1795     2.9812633991241455e-01
    z[4,5,4]  R1796     -7.5686089694499969e-03
    z[4,5,4]  R1797     -4.6676734089851379e-01
    z[4,5,4]  R1798     4.2089998722076416e-02
    z[4,5,4]  R1799     3.8982751965522766e-01
    z[4,5,4]  R1800     -2.0247953012585640e-02
    z[4,5,4]  R1801     -2.1993450820446014e-01
    z[4,5,4]  R1802     -1.3251057267189026e-01
    z[4,5,4]  R1803     2.2747045755386353e-01
    z[4,5,4]  R1804     -1.0758624225854874e-01
    z[4,5,4]  R1805     3.9782109856605530e-01
    z[4,5,4]  R1806     -2.3097884654998779e-01
    z[4,5,4]  R1807     -1.7669111490249634e-01
    z[4,5,4]  R1808     -9.3540467321872711e-02
    z[4,5,4]  R1809     1.7631421983242035e-01
    z[4,5,4]  R1810     6.2692828476428986e-02
    z[4,5,4]  R1811     0.00487328227609396
    z[4,5,4]  R1812     -3.2241308689117432e-01
    z[4,5,4]  R1813     5.9660151600837708e-02
    z[4,5,4]  R1814     2.8520748019218445e-01
    z[4,5,4]  R1815     -3.2254624366760254e-01
    z[4,5,4]  R1816     -3.8146528601646423e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R1746     -1
    z[4,5,5]  R1747     1
    z[4,5,5]  R1750     6.1594814062118530e-01
    z[4,5,5]  R1751     3.4515982866287231e-01
    z[4,5,5]  R1752     4.8304164409637451e-01
    z[4,5,5]  R1753     2.2061470150947571e-01
    z[4,5,5]  R1754     9.7828663885593414e-02
    z[4,5,5]  R1755     -8.4887266159057617e-02
    z[4,5,5]  R1756     -4.8635739833116531e-02
    z[4,5,5]  R1757     4.2728230357170105e-01
    z[4,5,5]  R1758     -5.5917110294103622e-02
    z[4,5,5]  R1759     3.9927709102630615e-01
    z[4,5,5]  R1760     7.5558818876743317e-02
    z[4,5,5]  R1761     -8.2117930054664612e-02
    z[4,5,5]  R1762     2.8621256351470947e-01
    z[4,5,5]  R1763     -1.5120024979114532e-01
    z[4,5,5]  R1764     -1.2469217181205750e-02
    z[4,5,5]  R1765     -1.8735386431217194e-02
    z[4,5,5]  R1766     0.290080726146698
    z[4,5,5]  R1767     3.9185795187950134e-01
    z[4,5,5]  R1768     -2.3198728263378143e-01
    z[4,5,5]  R1769     -1.4727722108364105e-01
    z[4,5,5]  R1770     1.8493895232677460e-01
    z[4,5,5]  R1771     0.0797443687915802
    z[4,5,5]  R1772     -8.5617087781429291e-02
    z[4,5,5]  R1773     -2.1199978888034821e-02
    z[4,5,5]  R1774     -1.6147939860820770e-01
    z[4,5,5]  R1775     -4.3890342116355896e-02
    z[4,5,5]  R1776     -7.2078585624694824e-02
    z[4,5,5]  R1777     6.7185126245021820e-02
    z[4,5,5]  R1778     -1.6084041446447372e-02
    z[4,5,5]  R1779     1.4139804244041443e-01
    z[4,5,5]  R1780     5.5951970815658569e-01
    z[4,5,5]  R1781     1.8991412222385406e-01
    z[4,5,5]  R1782     6.1547566205263138e-02
    z[4,5,5]  R1783     -1.7291270196437836e-01
    z[4,5,5]  R1784     4.1396132111549377e-01
    z[4,5,5]  R1785     1.6705366969108582e-01
    z[4,5,5]  R1786     5.2193057537078857e-01
    z[4,5,5]  R1787     2.5096088647842407e-01
    z[4,5,5]  R1788     0.00862759631127119
    z[4,5,5]  R1789     2.3625065386295319e-01
    z[4,5,5]  R1790     7.1578228473663330e-01
    z[4,5,5]  R1791     7.7692353725433350e-01
    z[4,5,5]  R1792     -9.6755344420671463e-03
    z[4,5,5]  R1793     -1.6764727234840393e-01
    z[4,5,5]  R1794     1.6329331696033478e-01
    z[4,5,5]  R1795     -8.9326046407222748e-02
    z[4,5,5]  R1796     3.9545886218547821e-02
    z[4,5,5]  R1797     -0.0925360694527626
    z[4,5,5]  R1798     -4.2166151106357574e-02
    z[4,5,5]  R1799     -2.3908782750368118e-02
    z[4,5,5]  R1800     -1.8317978084087372e-01
    z[4,5,5]  R1801     -3.0318453907966614e-01
    z[4,5,5]  R1802     -3.7554496526718140e-01
    z[4,5,5]  R1803     -1.3667531311511993e-01
    z[4,5,5]  R1804     -1.8587402999401093e-01
    z[4,5,5]  R1805     -0.41797935962677
    z[4,5,5]  R1806     -2.8581684827804565e-01
    z[4,5,5]  R1807     -5.4287356138229370e-01
    z[4,5,5]  R1808     2.1530104801058769e-02
    z[4,5,5]  R1809     1.1809369176626205e-01
    z[4,5,5]  R1810     -1.6922626644372940e-02
    z[4,5,5]  R1811     -2.3602357506752014e-01
    z[4,5,5]  R1812     1.8345052376389503e-02
    z[4,5,5]  R1813     2.6451872661709785e-02
    z[4,5,5]  R1814     -2.1056348457932472e-02
    z[4,5,5]  R1815     -5.8092761039733887e-01
    z[4,5,5]  R1816     -3.7081623449921608e-03
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R1748     -1
    z[4,5,6]  R1749     1
    z[4,5,6]  R1750     -2.4554328992962837e-02
    z[4,5,6]  R1751     1.1613485217094421e-01
    z[4,5,6]  R1752     2.4154061079025269e-01
    z[4,5,6]  R1753     2.1722437441349030e-01
    z[4,5,6]  R1754     1.8210685253143311e-01
    z[4,5,6]  R1755     4.4662925601005554e-01
    z[4,5,6]  R1756     2.0342156291007996e-01
    z[4,5,6]  R1757     -5.6647288799285889e-01
    z[4,5,6]  R1758     -8.7896245718002319e-01
    z[4,5,6]  R1759     -3.7956789135932922e-01
    z[4,5,6]  R1760     -0.0497247539460659
    z[4,5,6]  R1761     -6.0284274816513062e-01
    z[4,5,6]  R1762     -4.7841307520866394e-01
    z[4,5,6]  R1763     -8.6688280105590820e-02
    z[4,5,6]  R1764     1.2187813967466354e-01
    z[4,5,6]  R1765     2.1599070727825165e-01
    z[4,5,6]  R1766     4.2156991362571716e-01
    z[4,5,6]  R1767     1.7205193638801575e-01
    z[4,5,6]  R1768     -2.6093757152557373e-01
    z[4,5,6]  R1769     1.5837593376636505e-01
    z[4,5,6]  R1770     -6.7665509879589081e-02
    z[4,5,6]  R1771     -6.0138396918773651e-02
    z[4,5,6]  R1772     3.9237238466739655e-02
    z[4,5,6]  R1773     1.2265367805957794e-01
    z[4,5,6]  R1774     -1.1476953327655792e-01
    z[4,5,6]  R1775     -1.2340287119150162e-01
    z[4,5,6]  R1776     2.7581827715039253e-02
    z[4,5,6]  R1777     3.7131506949663162e-02
    z[4,5,6]  R1778     2.4468530714511871e-01
    z[4,5,6]  R1779     2.7021160349249840e-02
    z[4,5,6]  R1780     -1.6837711632251740e-01
    z[4,5,6]  R1781     0.0065696956589818
    z[4,5,6]  R1782     8.2873530685901642e-02
    z[4,5,6]  R1783     -0.157931387424469
    z[4,5,6]  R1784     -2.2559596598148346e-01
    z[4,5,6]  R1785     8.2399837672710419e-02
    z[4,5,6]  R1786     1.2526282668113708e-01
    z[4,5,6]  R1787     8.3797954022884369e-02
    z[4,5,6]  R1788     2.0705102384090424e-01
    z[4,5,6]  R1789     2.8981450200080872e-01
    z[4,5,6]  R1790     -3.1722703576087952e-01
    z[4,5,6]  R1791     0.0425274521112442
    z[4,5,6]  R1792     -3.0511155724525452e-01
    z[4,5,6]  R1793     -3.8313925266265869e-01
    z[4,5,6]  R1794     3.6319881677627563e-01
    z[4,5,6]  R1795     0.387690931558609
    z[4,5,6]  R1796     -3.0640125274658203e-01
    z[4,5,6]  R1797     0.471548467874527
    z[4,5,6]  R1798     -1.3050666451454163e-01
    z[4,5,6]  R1799     -3.6141178011894226e-01
    z[4,5,6]  R1800     3.1543749570846558e-01
    z[4,5,6]  R1801     -5.5901497602462769e-01
    z[4,5,6]  R1802     6.1622675508260727e-02
    z[4,5,6]  R1803     3.1740683317184448e-01
    z[4,5,6]  R1804     -1.1058255285024643e-01
    z[4,5,6]  R1805     6.2087923288345337e-02
    z[4,5,6]  R1806     1.9308309257030487e-01
    z[4,5,6]  R1807     3.9245107769966125e-01
    z[4,5,6]  R1808     1.9526550173759460e-01
    z[4,5,6]  R1809     1.5403334796428680e-01
    z[4,5,6]  R1810     1.1634574830532074e-01
    z[4,5,6]  R1811     1.6607512533664703e-01
    z[4,5,6]  R1812     4.3586143851280212e-01
    z[4,5,6]  R1813     6.7124205827713013e-01
    z[4,5,6]  R1814     2.3354444652795792e-02
    z[4,5,6]  R1815     0.0557732991874218
    z[4,5,6]  R1816     -1.7011800408363342e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R1817     -1
    z[5,4,0]  R1818     1
    z[5,4,0]  R1831     1.1186915449798107e-02
    z[5,4,0]  R1832     -4.8215375281870365e-03
    z[5,4,0]  R1833     -3.1158182024955750e-01
    z[5,4,0]  R1834     -4.5451480150222778e-01
    z[5,4,0]  R1835     -6.3648438453674316e-01
    z[5,4,0]  R1836     -5.5495697259902954e-01
    z[5,4,0]  R1837     -9.0682422742247581e-03
    z[5,4,0]  R1838     1.0719141364097595e-01
    z[5,4,0]  R1839     3.4995445609092712e-01
    z[5,4,0]  R1840     -3.2522717118263245e-01
    z[5,4,0]  R1841     -5.2713447809219360e-01
    z[5,4,0]  R1842     1.8959281966090202e-02
    z[5,4,0]  R1843     2.4771073460578918e-01
    z[5,4,0]  R1844     -6.5029990673065186e-01
    z[5,4,0]  R1845     1.4037866890430450e-01
    z[5,4,0]  R1846     1.8609800934791565e-01
    z[5,4,0]  R1847     -0.00932371336966753
    z[5,4,0]  R1848     6.1752386391162872e-02
    z[5,4,0]  R1849     -9.8541423678398132e-02
    z[5,4,0]  R1850     2.8609317541122437e-01
    z[5,4,0]  R1851     8.6865060031414032e-02
    z[5,4,0]  R1852     -2.8792256116867065e-01
    z[5,4,0]  R1853     -3.8555711507797241e-02
    z[5,4,0]  R1854     1.6615432500839233e-01
    z[5,4,0]  R1855     -3.5495206713676453e-02
    z[5,4,0]  R1856     4.3524277210235596e-01
    z[5,4,0]  R1857     2.6447480916976929e-01
    z[5,4,0]  R1858     -5.7972317934036255e-01
    z[5,4,0]  R1859     -7.6502150297164917e-01
    z[5,4,0]  R1860     -7.1177893877029419e-01
    z[5,4,0]  R1861     -7.0715343952178955e-01
    z[5,4,0]  R1862     -5.0080770254135132e-01
    z[5,4,0]  R1863     -7.7686232328414917e-01
    z[5,4,0]  R1864     -4.0485724806785583e-01
    z[5,4,0]  R1865     -7.1330323815345764e-02
    z[5,4,0]  R1866     -2.0989847183227539e-01
    z[5,4,0]  R1867     4.5504495501518250e-01
    z[5,4,0]  R1868     2.0747885107994080e-01
    z[5,4,0]  R1869     -4.9686175584793091e-01
    z[5,4,0]  R1870     5.3532477468252182e-02
    z[5,4,0]  R1871     8.8198864459991455e-01
    z[5,4,0]  R1872     8.8591843843460083e-01
    z[5,4,0]  R1873     8.7120288610458374e-01
    z[5,4,0]  R1874     4.3611773848533630e-01
    z[5,4,0]  R1875     3.5592919588088989e-01
    z[5,4,0]  R1876     0.86301189661026
    z[5,4,0]  R1877     8.7381732463836670e-01
    z[5,4,0]  R1878     5.0713205337524414e-01
    z[5,4,0]  R1879     -3.0775934457778931e-01
    z[5,4,0]  R1880     -1.3161900639533997e-01
    z[5,4,0]  R1881     -1.0995452851057053e-01
    z[5,4,0]  R1882     -1.9690018892288208e-01
    z[5,4,0]  R1883     -1.0541586577892303e-01
    z[5,4,0]  R1884     -9.6146740019321442e-02
    z[5,4,0]  R1885     7.6432503759860992e-02
    z[5,4,0]  R1886     -1.5052518248558044e-01
    z[5,4,0]  R1887     -0.0409589558839798
    z[5,4,0]  R1888     4.5085424184799194e-01
    z[5,4,0]  R1889     0.948215126991272
    z[5,4,0]  R1890     4.6942993998527527e-01
    z[5,4,0]  R1891     6.2622010707855225e-01
    z[5,4,0]  R1892     6.5410810708999634e-01
    z[5,4,0]  R1893     5.8166539669036865e-01
    z[5,4,0]  R1894     6.3407623767852783e-01
    z[5,4,0]  R1895     4.1721984744071960e-01
    z[5,4,0]  R1896     8.5299199819564819e-01
    z[5,4,0]  R1897     6.1620497703552246e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R1819     -1
    z[5,4,1]  R1820     1
    z[5,4,1]  R1831     -2.8183379769325256e-01
    z[5,4,1]  R1832     -4.3488350510597229e-01
    z[5,4,1]  R1833     4.9660235643386841e-01
    z[5,4,1]  R1834     6.6657382249832153e-01
    z[5,4,1]  R1835     3.3694645762443542e-01
    z[5,4,1]  R1836     6.0095584392547607e-01
    z[5,4,1]  R1837     8.8974541425704956e-01
    z[5,4,1]  R1838     0.454041987657547
    z[5,4,1]  R1839     8.6570811271667480e-01
    z[5,4,1]  R1840     6.2760341167449951e-01
    z[5,4,1]  R1841     -5.5866867303848267e-01
    z[5,4,1]  R1842     -5.9417122602462769e-01
    z[5,4,1]  R1843     -7.2897613048553467e-01
    z[5,4,1]  R1844     0.0097170639783144
    z[5,4,1]  R1845     7.5981557369232178e-01
    z[5,4,1]  R1846     7.6729327440261841e-01
    z[5,4,1]  R1847     7.8068637847900391e-01
    z[5,4,1]  R1848     5.2841019630432129e-01
    z[5,4,1]  R1849     7.7418565750122070e-01
    z[5,4,1]  R1850     8.0917710065841675e-01
    z[5,4,1]  R1851     8.6591434478759766e-01
    z[5,4,1]  R1852     7.7511388063430786e-01
    z[5,4,1]  R1853     7.3167085647583008e-01
    z[5,4,1]  R1854     6.2748539447784424e-01
    z[5,4,1]  R1855     8.4570759534835815e-01
    z[5,4,1]  R1856     5.8977931737899780e-01
    z[5,4,1]  R1857     6.4801257848739624e-01
    z[5,4,1]  R1858     -2.7955442667007446e-01
    z[5,4,1]  R1859     -3.3829516172409058e-01
    z[5,4,1]  R1860     -8.5102990269660950e-02
    z[5,4,1]  R1861     -0.592068076133728
    z[5,4,1]  R1862     -3.8465267419815063e-01
    z[5,4,1]  R1863     -1.9518250226974487e-01
    z[5,4,1]  R1864     -2.2412414848804474e-01
    z[5,4,1]  R1865     3.2590541243553162e-01
    z[5,4,1]  R1866     -5.7407461106777191e-02
    z[5,4,1]  R1867     -4.4644474983215332e-01
    z[5,4,1]  R1868     -8.5024875402450562e-01
    z[5,4,1]  R1869     8.8031284511089325e-02
    z[5,4,1]  R1870     -5.8409631252288818e-01
    z[5,4,1]  R1871     -3.9237055182456970e-01
    z[5,4,1]  R1872     -3.1708675622940063e-01
    z[5,4,1]  R1873     -3.9633682370185852e-01
    z[5,4,1]  R1874     -6.8332219123840332e-01
    z[5,4,1]  R1875     -4.9160975217819214e-01
    z[5,4,1]  R1876     -3.3863878250122070e-01
    z[5,4,1]  R1877     -2.8951865434646606e-01
    z[5,4,1]  R1878     -6.7540162801742554e-01
    z[5,4,1]  R1879     9.2551183700561523e-01
    z[5,4,1]  R1880     9.6815145015716553e-01
    z[5,4,1]  R1881     9.6989828348159790e-01
    z[5,4,1]  R1882     9.1882050037384033e-01
    z[5,4,1]  R1883     9.4148808717727661e-01
    z[5,4,1]  R1884     0.953998327255249
    z[5,4,1]  R1885     9.8180347681045532e-01
    z[5,4,1]  R1886     0.920976459980011
    z[5,4,1]  R1887     9.7002464532852173e-01
    z[5,4,1]  R1888     -3.8136070966720581e-01
    z[5,4,1]  R1889     -6.7426353693008423e-02
    z[5,4,1]  R1890     -6.6137647628784180e-01
    z[5,4,1]  R1891     2.0332412421703339e-01
    z[5,4,1]  R1892     -2.2642524540424347e-01
    z[5,4,1]  R1893     3.0499300360679626e-01
    z[5,4,1]  R1894     -1.1251514405012131e-01
    z[5,4,1]  R1895     5.1701503992080688e-01
    z[5,4,1]  R1896     1.4222370088100433e-01
    z[5,4,1]  R1897     -3.2608166337013245e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R1821     -1
    z[5,4,2]  R1822     1
    z[5,4,2]  R1831     -2.1567940711975098e-01
    z[5,4,2]  R1832     1.3756586611270905e-01
    z[5,4,2]  R1833     -6.0235446691513062e-01
    z[5,4,2]  R1834     -1.3066259026527405e-01
    z[5,4,2]  R1835     -5.2772867679595947e-01
    z[5,4,2]  R1836     -1.9353452324867249e-01
    z[5,4,2]  R1837     -0.0511116087436676
    z[5,4,2]  R1838     -5.7751423120498657e-01
    z[5,4,2]  R1839     2.8160056471824646e-01
    z[5,4,2]  R1840     4.2929247021675110e-01
    z[5,4,2]  R1841     -2.3929375410079956e-01
    z[5,4,2]  R1842     4.3117862194776535e-02
    z[5,4,2]  R1843     -4.9465906620025635e-01
    z[5,4,2]  R1844     2.2865265607833862e-01
    z[5,4,2]  R1845     0.264136403799057
    z[5,4,2]  R1846     -3.5222183912992477e-02
    z[5,4,2]  R1847     3.0547997355461121e-01
    z[5,4,2]  R1848     -3.2193638384342194e-02
    z[5,4,2]  R1849     4.7409462928771973e-01
    z[5,4,2]  R1850     -1.0327765345573425e-01
    z[5,4,2]  R1851     6.5677843987941742e-02
    z[5,4,2]  R1852     4.6928778290748596e-01
    z[5,4,2]  R1853     3.7477472424507141e-01
    z[5,4,2]  R1854     -1.6672912240028381e-01
    z[5,4,2]  R1855     3.1196582317352295e-01
    z[5,4,2]  R1856     -0.039963249117136
    z[5,4,2]  R1857     5.4550009965896606e-01
    z[5,4,2]  R1858     -1.7431795597076416e-01
    z[5,4,2]  R1859     -2.6106369495391846e-01
    z[5,4,2]  R1860     -4.4017231464385986e-01
    z[5,4,2]  R1861     -4.7031562775373459e-02
    z[5,4,2]  R1862     -1.5521739423274994e-01
    z[5,4,2]  R1863     -3.0772429704666138e-01
    z[5,4,2]  R1864     -8.2980763912200928e-01
    z[5,4,2]  R1865     -5.1815962791442871e-01
    z[5,4,2]  R1866     -3.4970918297767639e-01
    z[5,4,2]  R1867     -1.2851508334279060e-02
    z[5,4,2]  R1868     -0.064329132437706
    z[5,4,2]  R1869     -2.6872813701629639e-01
    z[5,4,2]  R1870     -1.1712085455656052e-01
    z[5,4,2]  R1871     5.8494519442319870e-02
    z[5,4,2]  R1872     -7.0008113980293274e-02
    z[5,4,2]  R1873     6.9923967123031616e-02
    z[5,4,2]  R1874     -1.6761665046215057e-01
    z[5,4,2]  R1875     -1.7568540573120117e-01
    z[5,4,2]  R1876     -3.3721212297677994e-02
    z[5,4,2]  R1877     -2.4386551976203918e-01
    z[5,4,2]  R1878     3.9617738127708435e-01
    z[5,4,2]  R1879     1.8921536207199097e-01
    z[5,4,2]  R1880     -9.0488076210021973e-02
    z[5,4,2]  R1881     -3.3312514424324036e-02
    z[5,4,2]  R1882     1.2171571701765060e-01
    z[5,4,2]  R1883     -2.3459148406982422e-01
    z[5,4,2]  R1884     7.2983093559741974e-02
    z[5,4,2]  R1885     1.1208556592464447e-01
    z[5,4,2]  R1886     1.4783999323844910e-01
    z[5,4,2]  R1887     -0.0674082413315773
    z[5,4,2]  R1888     -1.7220650613307953e-01
    z[5,4,2]  R1889     2.4402961134910583e-01
    z[5,4,2]  R1890     3.4998139739036560e-01
    z[5,4,2]  R1891     3.4280881285667419e-01
    z[5,4,2]  R1892     3.6785191297531128e-01
    z[5,4,2]  R1893     2.2790899872779846e-01
    z[5,4,2]  R1894     3.0890521407127380e-01
    z[5,4,2]  R1895     -4.8213177919387817e-01
    z[5,4,2]  R1896     1.6244347393512726e-01
    z[5,4,2]  R1897     1.2620979547500610e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R1823     -1
    z[5,4,3]  R1824     1
    z[5,4,3]  R1831     -4.2259678244590759e-02
    z[5,4,3]  R1832     -2.0097452402114868e-01
    z[5,4,3]  R1833     1.9554542005062103e-01
    z[5,4,3]  R1834     1.7396594583988190e-01
    z[5,4,3]  R1835     8.2013376057147980e-02
    z[5,4,3]  R1836     2.1507333219051361e-01
    z[5,4,3]  R1837     -3.3189707994461060e-01
    z[5,4,3]  R1838     -6.3638072460889816e-03
    z[5,4,3]  R1839     -1.6793160140514374e-01
    z[5,4,3]  R1840     1.8136581778526306e-01
    z[5,4,3]  R1841     4.6828565001487732e-01
    z[5,4,3]  R1842     4.3812346458435059e-01
    z[5,4,3]  R1843     -1.2449848465621471e-02
    z[5,4,3]  R1844     -0.594612181186676
    z[5,4,3]  R1845     5.2426481246948242e-01
    z[5,4,3]  R1846     -1.9637893140316010e-01
    z[5,4,3]  R1847     3.5327067971229553e-01
    z[5,4,3]  R1848     -4.8578137159347534e-01
    z[5,4,3]  R1849     -3.4470051527023315e-01
    z[5,4,3]  R1850     4.2890289425849915e-01
    z[5,4,3]  R1851     0.469659686088562
    z[5,4,3]  R1852     -1.1294345557689667e-01
    z[5,4,3]  R1853     -1.6868086159229279e-01
    z[5,4,3]  R1854     -3.0988928675651550e-01
    z[5,4,3]  R1855     -3.2227909564971924e-01
    z[5,4,3]  R1856     0.128465473651886
    z[5,4,3]  R1857     -1.9517371058464050e-01
    z[5,4,3]  R1858     0.00803461018949747
    z[5,4,3]  R1859     -3.0085292458534241e-01
    z[5,4,3]  R1860     -2.5804473087191582e-02
    z[5,4,3]  R1861     1.1786479502916336e-01
    z[5,4,3]  R1862     -9.9384687840938568e-02
    z[5,4,3]  R1863     8.4044739603996277e-02
    z[5,4,3]  R1864     -1.6016146540641785e-01
    z[5,4,3]  R1865     4.8659469932317734e-02
    z[5,4,3]  R1866     2.2356024384498596e-01
    z[5,4,3]  R1867     7.8668624162673950e-02
    z[5,4,3]  R1868     2.5957694649696350e-01
    z[5,4,3]  R1869     0.396978497505188
    z[5,4,3]  R1870     2.1976348757743835e-01
    z[5,4,3]  R1871     1.8401291966438293e-01
    z[5,4,3]  R1872     0.0713120549917221
    z[5,4,3]  R1873     1.6418716311454773e-01
    z[5,4,3]  R1874     1.6098621487617493e-01
    z[5,4,3]  R1875     3.1258836388587952e-01
    z[5,4,3]  R1876     -6.4314864575862885e-02
    z[5,4,3]  R1877     -2.0116370916366577e-01
    z[5,4,3]  R1878     1.2760446965694427e-01
    z[5,4,3]  R1879     -3.3711224794387817e-02
    z[5,4,3]  R1880     -1.4838449656963348e-01
    z[5,4,3]  R1881     1.4235946536064148e-01
    z[5,4,3]  R1882     -1.6547230188734829e-04
    z[5,4,3]  R1883     -1.0569803416728973e-01
    z[5,4,3]  R1884     -2.0552964508533478e-01
    z[5,4,3]  R1885     -9.1635994613170624e-02
    z[5,4,3]  R1886     3.3478941768407822e-02
    z[5,4,3]  R1887     1.0103969275951385e-01
    z[5,4,3]  R1888     4.3513849377632141e-01
    z[5,4,3]  R1889     1.8716195598244667e-02
    z[5,4,3]  R1890     4.1821590065956116e-01
    z[5,4,3]  R1891     3.3363819122314453e-01
    z[5,4,3]  R1892     -3.4760600328445435e-01
    z[5,4,3]  R1893     2.4602463841438293e-01
    z[5,4,3]  R1894     -3.1204387545585632e-01
    z[5,4,3]  R1895     1.8816350400447845e-01
    z[5,4,3]  R1896     1.6779004037380219e-01
    z[5,4,3]  R1897     -0.586354672908783
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R1825     -1
    z[5,4,4]  R1826     1
    z[5,4,4]  R1831     0.509081244468689
    z[5,4,4]  R1832     -3.8225552439689636e-01
    z[5,4,4]  R1833     -4.0255087614059448e-01
    z[5,4,4]  R1834     -3.5617059469223022e-01
    z[5,4,4]  R1835     -1.9378559291362762e-01
    z[5,4,4]  R1836     2.9812633991241455e-01
    z[5,4,4]  R1837     -7.5686089694499969e-03
    z[5,4,4]  R1838     -4.6676734089851379e-01
    z[5,4,4]  R1839     4.2089998722076416e-02
    z[5,4,4]  R1840     3.8982751965522766e-01
    z[5,4,4]  R1841     -2.0247953012585640e-02
    z[5,4,4]  R1842     -2.1993450820446014e-01
    z[5,4,4]  R1843     -1.3251057267189026e-01
    z[5,4,4]  R1844     2.2747045755386353e-01
    z[5,4,4]  R1845     -1.0758624225854874e-01
    z[5,4,4]  R1846     3.9782109856605530e-01
    z[5,4,4]  R1847     -2.3097884654998779e-01
    z[5,4,4]  R1848     -1.7669111490249634e-01
    z[5,4,4]  R1849     -9.3540467321872711e-02
    z[5,4,4]  R1850     1.7631421983242035e-01
    z[5,4,4]  R1851     6.2692828476428986e-02
    z[5,4,4]  R1852     0.00487328227609396
    z[5,4,4]  R1853     -3.2241308689117432e-01
    z[5,4,4]  R1854     5.9660151600837708e-02
    z[5,4,4]  R1855     2.8520748019218445e-01
    z[5,4,4]  R1856     -3.2254624366760254e-01
    z[5,4,4]  R1857     -3.8146528601646423e-01
    z[5,4,4]  R1858     4.1871714591979980e-01
    z[5,4,4]  R1859     9.4915606081485748e-02
    z[5,4,4]  R1860     6.2939259223639965e-03
    z[5,4,4]  R1861     1.9346331059932709e-01
    z[5,4,4]  R1862     7.2424495220184326e-01
    z[5,4,4]  R1863     2.2348937392234802e-01
    z[5,4,4]  R1864     1.6697567701339722e-01
    z[5,4,4]  R1865     -0.338199257850647
    z[5,4,4]  R1866     -6.8334378302097321e-02
    z[5,4,4]  R1867     -5.3270375728607178e-01
    z[5,4,4]  R1868     -3.9284810423851013e-01
    z[5,4,4]  R1869     -3.8132596015930176e-01
    z[5,4,4]  R1870     -5.3212392330169678e-01
    z[5,4,4]  R1871     2.1966744214296341e-02
    z[5,4,4]  R1872     0.299346387386322
    z[5,4,4]  R1873     7.1223303675651550e-02
    z[5,4,4]  R1874     -0.164293110370636
    z[5,4,4]  R1875     -5.6559962034225464e-01
    z[5,4,4]  R1876     -1.1556020379066467e-01
    z[5,4,4]  R1877     -7.6886273920536041e-02
    z[5,4,4]  R1878     0.273183673620224
    z[5,4,4]  R1879     -4.2394332587718964e-02
    z[5,4,4]  R1880     -7.9268120229244232e-02
    z[5,4,4]  R1881     1.0167615860700607e-01
    z[5,4,4]  R1882     2.5087258219718933e-01
    z[5,4,4]  R1883     1.3830369710922241e-01
    z[5,4,4]  R1884     1.6467517614364624e-01
    z[5,4,4]  R1885     5.8026801794767380e-02
    z[5,4,4]  R1886     -2.1456320583820343e-01
    z[5,4,4]  R1887     -1.4798012375831604e-01
    z[5,4,4]  R1888     -3.0146420001983643e-01
    z[5,4,4]  R1889     1.8179299309849739e-02
    z[5,4,4]  R1890     1.8484836816787720e-01
    z[5,4,4]  R1891     -5.3182154893875122e-01
    z[5,4,4]  R1892     -2.0608678460121155e-01
    z[5,4,4]  R1893     -6.4921277761459351e-01
    z[5,4,4]  R1894     -3.2309678196907043e-01
    z[5,4,4]  R1895     4.6985435485839844e-01
    z[5,4,4]  R1896     -3.9330765604972839e-01
    z[5,4,4]  R1897     -1.2006111443042755e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R1827     -1
    z[5,4,5]  R1828     1
    z[5,4,5]  R1831     7.1578228473663330e-01
    z[5,4,5]  R1832     7.7692353725433350e-01
    z[5,4,5]  R1833     -9.6755344420671463e-03
    z[5,4,5]  R1834     -1.6764727234840393e-01
    z[5,4,5]  R1835     1.6329331696033478e-01
    z[5,4,5]  R1836     -8.9326046407222748e-02
    z[5,4,5]  R1837     3.9545886218547821e-02
    z[5,4,5]  R1838     -0.0925360694527626
    z[5,4,5]  R1839     -4.2166151106357574e-02
    z[5,4,5]  R1840     -2.3908782750368118e-02
    z[5,4,5]  R1841     -1.8317978084087372e-01
    z[5,4,5]  R1842     -3.0318453907966614e-01
    z[5,4,5]  R1843     -3.7554496526718140e-01
    z[5,4,5]  R1844     -1.3667531311511993e-01
    z[5,4,5]  R1845     -1.8587402999401093e-01
    z[5,4,5]  R1846     -0.41797935962677
    z[5,4,5]  R1847     -2.8581684827804565e-01
    z[5,4,5]  R1848     -5.4287356138229370e-01
    z[5,4,5]  R1849     2.1530104801058769e-02
    z[5,4,5]  R1850     1.1809369176626205e-01
    z[5,4,5]  R1851     -1.6922626644372940e-02
    z[5,4,5]  R1852     -2.3602357506752014e-01
    z[5,4,5]  R1853     1.8345052376389503e-02
    z[5,4,5]  R1854     2.6451872661709785e-02
    z[5,4,5]  R1855     -2.1056348457932472e-02
    z[5,4,5]  R1856     -5.8092761039733887e-01
    z[5,4,5]  R1857     -3.7081623449921608e-03
    z[5,4,5]  R1858     6.1594814062118530e-01
    z[5,4,5]  R1859     3.4515982866287231e-01
    z[5,4,5]  R1860     4.8304164409637451e-01
    z[5,4,5]  R1861     2.2061470150947571e-01
    z[5,4,5]  R1862     9.7828663885593414e-02
    z[5,4,5]  R1863     -8.4887266159057617e-02
    z[5,4,5]  R1864     -4.8635739833116531e-02
    z[5,4,5]  R1865     4.2728230357170105e-01
    z[5,4,5]  R1866     -5.5917110294103622e-02
    z[5,4,5]  R1867     3.9927709102630615e-01
    z[5,4,5]  R1868     7.5558818876743317e-02
    z[5,4,5]  R1869     -8.2117930054664612e-02
    z[5,4,5]  R1870     2.8621256351470947e-01
    z[5,4,5]  R1871     -1.5120024979114532e-01
    z[5,4,5]  R1872     -1.2469217181205750e-02
    z[5,4,5]  R1873     -1.8735386431217194e-02
    z[5,4,5]  R1874     0.290080726146698
    z[5,4,5]  R1875     3.9185795187950134e-01
    z[5,4,5]  R1876     -2.3198728263378143e-01
    z[5,4,5]  R1877     -1.4727722108364105e-01
    z[5,4,5]  R1878     1.8493895232677460e-01
    z[5,4,5]  R1879     0.0797443687915802
    z[5,4,5]  R1880     -8.5617087781429291e-02
    z[5,4,5]  R1881     -2.1199978888034821e-02
    z[5,4,5]  R1882     -1.6147939860820770e-01
    z[5,4,5]  R1883     -4.3890342116355896e-02
    z[5,4,5]  R1884     -7.2078585624694824e-02
    z[5,4,5]  R1885     6.7185126245021820e-02
    z[5,4,5]  R1886     -1.6084041446447372e-02
    z[5,4,5]  R1887     1.4139804244041443e-01
    z[5,4,5]  R1888     5.5951970815658569e-01
    z[5,4,5]  R1889     1.8991412222385406e-01
    z[5,4,5]  R1890     6.1547566205263138e-02
    z[5,4,5]  R1891     -1.7291270196437836e-01
    z[5,4,5]  R1892     4.1396132111549377e-01
    z[5,4,5]  R1893     1.6705366969108582e-01
    z[5,4,5]  R1894     5.2193057537078857e-01
    z[5,4,5]  R1895     2.5096088647842407e-01
    z[5,4,5]  R1896     0.00862759631127119
    z[5,4,5]  R1897     2.3625065386295319e-01
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R1829     -1
    z[5,4,6]  R1830     1
    z[5,4,6]  R1831     -3.1722703576087952e-01
    z[5,4,6]  R1832     0.0425274521112442
    z[5,4,6]  R1833     -3.0511155724525452e-01
    z[5,4,6]  R1834     -3.8313925266265869e-01
    z[5,4,6]  R1835     3.6319881677627563e-01
    z[5,4,6]  R1836     0.387690931558609
    z[5,4,6]  R1837     -3.0640125274658203e-01
    z[5,4,6]  R1838     0.471548467874527
    z[5,4,6]  R1839     -1.3050666451454163e-01
    z[5,4,6]  R1840     -3.6141178011894226e-01
    z[5,4,6]  R1841     3.1543749570846558e-01
    z[5,4,6]  R1842     -5.5901497602462769e-01
    z[5,4,6]  R1843     6.1622675508260727e-02
    z[5,4,6]  R1844     3.1740683317184448e-01
    z[5,4,6]  R1845     -1.1058255285024643e-01
    z[5,4,6]  R1846     6.2087923288345337e-02
    z[5,4,6]  R1847     1.9308309257030487e-01
    z[5,4,6]  R1848     3.9245107769966125e-01
    z[5,4,6]  R1849     1.9526550173759460e-01
    z[5,4,6]  R1850     1.5403334796428680e-01
    z[5,4,6]  R1851     1.1634574830532074e-01
    z[5,4,6]  R1852     1.6607512533664703e-01
    z[5,4,6]  R1853     4.3586143851280212e-01
    z[5,4,6]  R1854     6.7124205827713013e-01
    z[5,4,6]  R1855     2.3354444652795792e-02
    z[5,4,6]  R1856     0.0557732991874218
    z[5,4,6]  R1857     -1.7011800408363342e-01
    z[5,4,6]  R1858     -2.4554328992962837e-02
    z[5,4,6]  R1859     1.1613485217094421e-01
    z[5,4,6]  R1860     2.4154061079025269e-01
    z[5,4,6]  R1861     2.1722437441349030e-01
    z[5,4,6]  R1862     1.8210685253143311e-01
    z[5,4,6]  R1863     4.4662925601005554e-01
    z[5,4,6]  R1864     2.0342156291007996e-01
    z[5,4,6]  R1865     -5.6647288799285889e-01
    z[5,4,6]  R1866     -8.7896245718002319e-01
    z[5,4,6]  R1867     -3.7956789135932922e-01
    z[5,4,6]  R1868     -0.0497247539460659
    z[5,4,6]  R1869     -6.0284274816513062e-01
    z[5,4,6]  R1870     -4.7841307520866394e-01
    z[5,4,6]  R1871     -8.6688280105590820e-02
    z[5,4,6]  R1872     1.2187813967466354e-01
    z[5,4,6]  R1873     2.1599070727825165e-01
    z[5,4,6]  R1874     4.2156991362571716e-01
    z[5,4,6]  R1875     1.7205193638801575e-01
    z[5,4,6]  R1876     -2.6093757152557373e-01
    z[5,4,6]  R1877     1.5837593376636505e-01
    z[5,4,6]  R1878     -6.7665509879589081e-02
    z[5,4,6]  R1879     -6.0138396918773651e-02
    z[5,4,6]  R1880     3.9237238466739655e-02
    z[5,4,6]  R1881     1.2265367805957794e-01
    z[5,4,6]  R1882     -1.1476953327655792e-01
    z[5,4,6]  R1883     -1.2340287119150162e-01
    z[5,4,6]  R1884     2.7581827715039253e-02
    z[5,4,6]  R1885     3.7131506949663162e-02
    z[5,4,6]  R1886     2.4468530714511871e-01
    z[5,4,6]  R1887     2.7021160349249840e-02
    z[5,4,6]  R1888     -1.6837711632251740e-01
    z[5,4,6]  R1889     0.0065696956589818
    z[5,4,6]  R1890     8.2873530685901642e-02
    z[5,4,6]  R1891     -0.157931387424469
    z[5,4,6]  R1892     -2.2559596598148346e-01
    z[5,4,6]  R1893     8.2399837672710419e-02
    z[5,4,6]  R1894     1.2526282668113708e-01
    z[5,4,6]  R1895     8.3797954022884369e-02
    z[5,4,6]  R1896     2.0705102384090424e-01
    z[5,4,6]  R1897     2.8981450200080872e-01
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R1952     -1
    z[5,6,0]  R1953     1
    z[5,6,0]  R1966     1.1186915449798107e-02
    z[5,6,0]  R1967     -4.8215375281870365e-03
    z[5,6,0]  R1968     -3.1158182024955750e-01
    z[5,6,0]  R1969     -4.5451480150222778e-01
    z[5,6,0]  R1970     -6.3648438453674316e-01
    z[5,6,0]  R1971     -5.5495697259902954e-01
    z[5,6,0]  R1972     -9.0682422742247581e-03
    z[5,6,0]  R1973     1.0719141364097595e-01
    z[5,6,0]  R1974     3.4995445609092712e-01
    z[5,6,0]  R1975     -3.2522717118263245e-01
    z[5,6,0]  R1976     -5.2713447809219360e-01
    z[5,6,0]  R1977     1.8959281966090202e-02
    z[5,6,0]  R1978     2.4771073460578918e-01
    z[5,6,0]  R1979     -6.5029990673065186e-01
    z[5,6,0]  R1980     1.4037866890430450e-01
    z[5,6,0]  R1981     1.8609800934791565e-01
    z[5,6,0]  R1982     -0.00932371336966753
    z[5,6,0]  R1983     6.1752386391162872e-02
    z[5,6,0]  R1984     -9.8541423678398132e-02
    z[5,6,0]  R1985     2.8609317541122437e-01
    z[5,6,0]  R1986     8.6865060031414032e-02
    z[5,6,0]  R1987     -2.8792256116867065e-01
    z[5,6,0]  R1988     -3.8555711507797241e-02
    z[5,6,0]  R1989     1.6615432500839233e-01
    z[5,6,0]  R1990     -3.5495206713676453e-02
    z[5,6,0]  R1991     4.3524277210235596e-01
    z[5,6,0]  R1992     2.6447480916976929e-01
    z[5,6,0]  R1993     -1.8632820248603821e-01
    z[5,6,0]  R1994     -4.7465452551841736e-01
    z[5,6,0]  R1995     4.3792444467544556e-01
    z[5,6,0]  R1996     3.8235524296760559e-01
    z[5,6,0]  R1997     3.7346342206001282e-01
    z[5,6,0]  R1998     6.3119995594024658e-01
    z[5,6,0]  R1999     3.2929986715316772e-01
    z[5,6,0]  R2000     1.5928198397159576e-01
    z[5,6,0]  R2001     6.0713529586791992e-01
    z[5,6,0]  R2002     3.4094351530075073e-01
    z[5,6,0]  R2003     -0.58119797706604
    z[5,6,0]  R2004     3.0131638050079346e-02
    z[5,6,0]  R2005     -1.4204809069633484e-01
    z[5,6,0]  R2006     -6.5065003931522369e-02
    z[5,6,0]  R2007     -3.1800848245620728e-01
    z[5,6,0]  R2008     -4.2569833993911743e-01
    z[5,6,0]  R2009     -3.5634589195251465e-01
    z[5,6,0]  R2010     3.0663952231407166e-01
    z[5,6,0]  R2011     2.5091221928596497e-01
    z[5,6,0]  R2012     -5.2162152528762817e-01
    z[5,6,0]  R2013     -3.3429333567619324e-01
    z[5,6,0]  R2014     -2.3331068456172943e-01
    z[5,6,0]  R2015     3.7231542170047760e-02
    z[5,6,0]  R2016     2.4421063065528870e-01
    z[5,6,0]  R2017     4.2844238877296448e-01
    z[5,6,0]  R2018     5.3521293401718140e-01
    z[5,6,0]  R2019     3.9225590229034424e-01
    z[5,6,0]  R2020     5.9769493341445923e-01
    z[5,6,0]  R2021     4.0260460972785950e-01
    z[5,6,0]  R2022     -1.4065428078174591e-01
    z[5,6,0]  R2023     2.9243695735931396e-01
    z[5,6,0]  R2024     7.3771692812442780e-02
    z[5,6,0]  R2025     2.5312933325767517e-01
    z[5,6,0]  R2026     6.3629776239395142e-01
    z[5,6,0]  R2027     0.184300035238266
    z[5,6,0]  R2028     -1.8647179007530212e-01
    z[5,6,0]  R2029     3.7628549337387085e-01
    z[5,6,0]  R2030     2.8730541467666626e-01
    z[5,6,0]  R2031     8.5978329181671143e-02
    z[5,6,0]  R2032     0.509591281414032
    z[5,6,0]  R2033     -5.9725429862737656e-02
    z[5,6,0]  R2034     3.3289736509323120e-01
    z[5,6,0]  R2035     0.533287525177002
    z[5,6,0]  R2036     -6.6896595060825348e-02
    z[5,6,0]  R2037     3.0792000889778137e-01
    z[5,6,0]  R2038     2.2734439373016357e-01
    z[5,6,0]  R2039     6.3056498765945435e-01
    z[5,6,0]  R2040     -1.6158511862158775e-02
    z[5,6,0]  R2041     6.9024398922920227e-02
    z[5,6,0]  R2042     3.2530412077903748e-01
    z[5,6,0]  R2043     -1.7556053400039673e-01
    z[5,6,0]  R2044     4.3240612745285034e-01
    z[5,6,0]  R2045     -3.0810329318046570e-01
    z[5,6,0]  R2046     -9.9450044333934784e-02
    z[5,6,0]  R2047     2.9956212639808655e-01
    z[5,6,0]  R2048     4.4328609108924866e-01
    z[5,6,0]  R2049     -2.0548477768898010e-02
    z[5,6,0]  R2050     -5.0517898797988892e-01
    z[5,6,0]  R2051     -3.6625093221664429e-01
    z[5,6,0]  R2052     -2.4710388481616974e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R1954     -1
    z[5,6,1]  R1955     1
    z[5,6,1]  R1966     -2.8183379769325256e-01
    z[5,6,1]  R1967     -4.3488350510597229e-01
    z[5,6,1]  R1968     4.9660235643386841e-01
    z[5,6,1]  R1969     6.6657382249832153e-01
    z[5,6,1]  R1970     3.3694645762443542e-01
    z[5,6,1]  R1971     6.0095584392547607e-01
    z[5,6,1]  R1972     8.8974541425704956e-01
    z[5,6,1]  R1973     0.454041987657547
    z[5,6,1]  R1974     8.6570811271667480e-01
    z[5,6,1]  R1975     6.2760341167449951e-01
    z[5,6,1]  R1976     -5.5866867303848267e-01
    z[5,6,1]  R1977     -5.9417122602462769e-01
    z[5,6,1]  R1978     -7.2897613048553467e-01
    z[5,6,1]  R1979     0.0097170639783144
    z[5,6,1]  R1980     7.5981557369232178e-01
    z[5,6,1]  R1981     7.6729327440261841e-01
    z[5,6,1]  R1982     7.8068637847900391e-01
    z[5,6,1]  R1983     5.2841019630432129e-01
    z[5,6,1]  R1984     7.7418565750122070e-01
    z[5,6,1]  R1985     8.0917710065841675e-01
    z[5,6,1]  R1986     8.6591434478759766e-01
    z[5,6,1]  R1987     7.7511388063430786e-01
    z[5,6,1]  R1988     7.3167085647583008e-01
    z[5,6,1]  R1989     6.2748539447784424e-01
    z[5,6,1]  R1990     8.4570759534835815e-01
    z[5,6,1]  R1991     5.8977931737899780e-01
    z[5,6,1]  R1992     6.4801257848739624e-01
    z[5,6,1]  R1993     6.1064338684082031e-01
    z[5,6,1]  R1994     6.2450957298278809e-01
    z[5,6,1]  R1995     5.7998287677764893e-01
    z[5,6,1]  R1996     4.0597015619277954e-01
    z[5,6,1]  R1997     6.3167077302932739e-01
    z[5,6,1]  R1998     -0.530769944190979
    z[5,6,1]  R1999     -8.4959131479263306e-01
    z[5,6,1]  R2000     3.1109875440597534e-01
    z[5,6,1]  R2001     -5.5505788326263428e-01
    z[5,6,1]  R2002     7.6115798950195312e-01
    z[5,6,1]  R2003     6.7412899807095528e-03
    z[5,6,1]  R2004     -4.3777039647102356e-01
    z[5,6,1]  R2005     -1.1569716967642307e-02
    z[5,6,1]  R2006     5.7042874395847321e-03
    z[5,6,1]  R2007     -1.0769910365343094e-01
    z[5,6,1]  R2008     -0.089664988219738
    z[5,6,1]  R2009     -4.7049908898770809e-03
    z[5,6,1]  R2010     -7.8689880669116974e-02
    z[5,6,1]  R2011     5.3881829977035522e-01
    z[5,6,1]  R2012     -7.2857844829559326e-01
    z[5,6,1]  R2013     2.4562025070190430e-01
    z[5,6,1]  R2014     3.5549721121788025e-01
    z[5,6,1]  R2015     7.6754844188690186e-01
    z[5,6,1]  R2016     7.3900038003921509e-01
    z[5,6,1]  R2017     0.700786292552948
    z[5,6,1]  R2018     1.5757998824119568e-01
    z[5,6,1]  R2019     -6.3820332288742065e-01
    z[5,6,1]  R2020     -7.3525291681289673e-01
    z[5,6,1]  R2021     1.3339456915855408e-01
    z[5,6,1]  R2022     5.8279263973236084e-01
    z[5,6,1]  R2023     7.5469082593917847e-01
    z[5,6,1]  R2024     7.2485476732254028e-01
    z[5,6,1]  R2025     0.859340250492096
    z[5,6,1]  R2026     -3.5345073789358139e-02
    z[5,6,1]  R2027     -3.5264518857002258e-01
    z[5,6,1]  R2028     -6.0123950242996216e-01
    z[5,6,1]  R2029     -2.7305385470390320e-01
    z[5,6,1]  R2030     -0.696918249130249
    z[5,6,1]  R2031     -5.3487861156463623e-01
    z[5,6,1]  R2032     -5.9835082292556763e-01
    z[5,6,1]  R2033     7.0404177904129028e-01
    z[5,6,1]  R2034     1.4636141061782837e-01
    z[5,6,1]  R2035     3.5103011131286621e-01
    z[5,6,1]  R2036     -3.7472493946552277e-02
    z[5,6,1]  R2037     -5.2194631099700928e-01
    z[5,6,1]  R2038     -6.3355344533920288e-01
    z[5,6,1]  R2039     -4.7664853930473328e-01
    z[5,6,1]  R2040     -5.6076383590698242e-01
    z[5,6,1]  R2041     -7.4455153942108154e-01
    z[5,6,1]  R2042     -7.7789926528930664e-01
    z[5,6,1]  R2043     -2.2095529362559319e-02
    z[5,6,1]  R2044     -7.4164569377899170e-01
    z[5,6,1]  R2045     7.3182427883148193e-01
    z[5,6,1]  R2046     6.3839703798294067e-01
    z[5,6,1]  R2047     -0.833806574344635
    z[5,6,1]  R2048     -4.0060380101203918e-01
    z[5,6,1]  R2049     -7.9504323005676270e-01
    z[5,6,1]  R2050     -0.525545597076416
    z[5,6,1]  R2051     -5.5992990732192993e-01
    z[5,6,1]  R2052     -0.585119366645813
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R1956     -1
    z[5,6,2]  R1957     1
    z[5,6,2]  R1966     -2.1567940711975098e-01
    z[5,6,2]  R1967     1.3756586611270905e-01
    z[5,6,2]  R1968     -6.0235446691513062e-01
    z[5,6,2]  R1969     -1.3066259026527405e-01
    z[5,6,2]  R1970     -5.2772867679595947e-01
    z[5,6,2]  R1971     -1.9353452324867249e-01
    z[5,6,2]  R1972     -0.0511116087436676
    z[5,6,2]  R1973     -5.7751423120498657e-01
    z[5,6,2]  R1974     2.8160056471824646e-01
    z[5,6,2]  R1975     4.2929247021675110e-01
    z[5,6,2]  R1976     -2.3929375410079956e-01
    z[5,6,2]  R1977     4.3117862194776535e-02
    z[5,6,2]  R1978     -4.9465906620025635e-01
    z[5,6,2]  R1979     2.2865265607833862e-01
    z[5,6,2]  R1980     0.264136403799057
    z[5,6,2]  R1981     -3.5222183912992477e-02
    z[5,6,2]  R1982     3.0547997355461121e-01
    z[5,6,2]  R1983     -3.2193638384342194e-02
    z[5,6,2]  R1984     4.7409462928771973e-01
    z[5,6,2]  R1985     -1.0327765345573425e-01
    z[5,6,2]  R1986     6.5677843987941742e-02
    z[5,6,2]  R1987     4.6928778290748596e-01
    z[5,6,2]  R1988     3.7477472424507141e-01
    z[5,6,2]  R1989     -1.6672912240028381e-01
    z[5,6,2]  R1990     3.1196582317352295e-01
    z[5,6,2]  R1991     -0.039963249117136
    z[5,6,2]  R1992     5.4550009965896606e-01
    z[5,6,2]  R1993     -0.332560658454895
    z[5,6,2]  R1994     5.3895749151706696e-02
    z[5,6,2]  R1995     -0.286003977060318
    z[5,6,2]  R1996     -3.4214845299720764e-01
    z[5,6,2]  R1997     -1.1339093744754791e-01
    z[5,6,2]  R1998     4.0346592664718628e-01
    z[5,6,2]  R1999     1.7034868896007538e-01
    z[5,6,2]  R2000     -2.1381275728344917e-02
    z[5,6,2]  R2001     2.2181870043277740e-01
    z[5,6,2]  R2002     4.7923141717910767e-01
    z[5,6,2]  R2003     -6.5385691821575165e-02
    z[5,6,2]  R2004     -1.6888666152954102e-01
    z[5,6,2]  R2005     -2.2791191935539246e-02
    z[5,6,2]  R2006     -2.2853022813796997e-01
    z[5,6,2]  R2007     -7.1053137071430683e-03
    z[5,6,2]  R2008     1.4190416038036346e-01
    z[5,6,2]  R2009     1.5632751584053040e-01
    z[5,6,2]  R2010     -5.2995961904525757e-01
    z[5,6,2]  R2011     -3.7402606103569269e-03
    z[5,6,2]  R2012     -4.1265211999416351e-02
    z[5,6,2]  R2013     -2.1572384238243103e-01
    z[5,6,2]  R2014     -2.1186050772666931e-01
    z[5,6,2]  R2015     -1.3898000121116638e-01
    z[5,6,2]  R2016     -1.4530846476554871e-01
    z[5,6,2]  R2017     -3.7960830330848694e-01
    z[5,6,2]  R2018     -6.3927090167999268e-01
    z[5,6,2]  R2019     4.3904027342796326e-01
    z[5,6,2]  R2020     -3.5784412175416946e-02
    z[5,6,2]  R2021     -3.6239191889762878e-01
    z[5,6,2]  R2022     2.3358710110187531e-02
    z[5,6,2]  R2023     -2.5001293420791626e-01
    z[5,6,2]  R2024     2.6127649471163750e-02
    z[5,6,2]  R2025     1.0452125966548920e-01
    z[5,6,2]  R2026     -4.8448723554611206e-01
    z[5,6,2]  R2027     -0.420459121465683
    z[5,6,2]  R2028     7.3230654001235962e-01
    z[5,6,2]  R2029     5.0593322515487671e-01
    z[5,6,2]  R2030     2.6776370406150818e-01
    z[5,6,2]  R2031     6.8941169977188110e-01
    z[5,6,2]  R2032     2.4605287611484528e-01
    z[5,6,2]  R2033     3.3118776977062225e-02
    z[5,6,2]  R2034     -3.0750176310539246e-01
    z[5,6,2]  R2035     -5.9830981492996216e-01
    z[5,6,2]  R2036     -2.7669641375541687e-01
    z[5,6,2]  R2037     7.7833157777786255e-01
    z[5,6,2]  R2038     4.6662944555282593e-01
    z[5,6,2]  R2039     2.5457486510276794e-01
    z[5,6,2]  R2040     5.6163430213928223e-01
    z[5,6,2]  R2041     4.7519233822822571e-01
    z[5,6,2]  R2042     9.7652181982994080e-02
    z[5,6,2]  R2043     -2.4107088148593903e-01
    z[5,6,2]  R2044     2.7117297053337097e-01
    z[5,6,2]  R2045     1.0942734032869339e-01
    z[5,6,2]  R2046     2.2474190592765808e-01
    z[5,6,2]  R2047     2.4390894174575806e-01
    z[5,6,2]  R2048     3.5541704297065735e-01
    z[5,6,2]  R2049     3.6890363693237305e-01
    z[5,6,2]  R2050     3.4448531270027161e-01
    z[5,6,2]  R2051     -5.2785462141036987e-01
    z[5,6,2]  R2052     -5.2000045776367188e-01
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R1958     -1
    z[5,6,3]  R1959     1
    z[5,6,3]  R1966     -4.2259678244590759e-02
    z[5,6,3]  R1967     -2.0097452402114868e-01
    z[5,6,3]  R1968     1.9554542005062103e-01
    z[5,6,3]  R1969     1.7396594583988190e-01
    z[5,6,3]  R1970     8.2013376057147980e-02
    z[5,6,3]  R1971     2.1507333219051361e-01
    z[5,6,3]  R1972     -3.3189707994461060e-01
    z[5,6,3]  R1973     -6.3638072460889816e-03
    z[5,6,3]  R1974     -1.6793160140514374e-01
    z[5,6,3]  R1975     1.8136581778526306e-01
    z[5,6,3]  R1976     4.6828565001487732e-01
    z[5,6,3]  R1977     4.3812346458435059e-01
    z[5,6,3]  R1978     -1.2449848465621471e-02
    z[5,6,3]  R1979     -0.594612181186676
    z[5,6,3]  R1980     5.2426481246948242e-01
    z[5,6,3]  R1981     -1.9637893140316010e-01
    z[5,6,3]  R1982     3.5327067971229553e-01
    z[5,6,3]  R1983     -4.8578137159347534e-01
    z[5,6,3]  R1984     -3.4470051527023315e-01
    z[5,6,3]  R1985     4.2890289425849915e-01
    z[5,6,3]  R1986     0.469659686088562
    z[5,6,3]  R1987     -1.1294345557689667e-01
    z[5,6,3]  R1988     -1.6868086159229279e-01
    z[5,6,3]  R1989     -3.0988928675651550e-01
    z[5,6,3]  R1990     -3.2227909564971924e-01
    z[5,6,3]  R1991     0.128465473651886
    z[5,6,3]  R1992     -1.9517371058464050e-01
    z[5,6,3]  R1993     3.5337468981742859e-01
    z[5,6,3]  R1994     4.3186199665069580e-01
    z[5,6,3]  R1995     1.8458463251590729e-01
    z[5,6,3]  R1996     2.2620768845081329e-01
    z[5,6,3]  R1997     1.8109650909900665e-01
    z[5,6,3]  R1998     -2.5153917074203491e-01
    z[5,6,3]  R1999     -1.2930953502655029e-01
    z[5,6,3]  R2000     3.0619335174560547e-01
    z[5,6,3]  R2001     -3.3659148216247559e-01
    z[5,6,3]  R2002     -3.5887490957975388e-02
    z[5,6,3]  R2003     3.4116572141647339e-01
    z[5,6,3]  R2004     8.2048797607421875e-01
    z[5,6,3]  R2005     4.4180014729499817e-01
    z[5,6,3]  R2006     4.1915854811668396e-01
    z[5,6,3]  R2007     4.9153622984886169e-01
    z[5,6,3]  R2008     4.2627230286598206e-01
    z[5,6,3]  R2009     4.0830591320991516e-01
    z[5,6,3]  R2010     6.4769697189331055e-01
    z[5,6,3]  R2011     -7.5049948692321777e-01
    z[5,6,3]  R2012     2.2613897919654846e-02
    z[5,6,3]  R2013     7.7779656648635864e-01
    z[5,6,3]  R2014     6.5645754337310791e-01
    z[5,6,3]  R2015     -3.5414823889732361e-01
    z[5,6,3]  R2016     -5.1127409934997559e-01
    z[5,6,3]  R2017     -2.2181639075279236e-01
    z[5,6,3]  R2018     2.6468244194984436e-01
    z[5,6,3]  R2019     4.1745647788047791e-01
    z[5,6,3]  R2020     1.5547877550125122e-01
    z[5,6,3]  R2021     4.1459989547729492e-01
    z[5,6,3]  R2022     -3.7872564792633057e-01
    z[5,6,3]  R2023     2.4027393758296967e-01
    z[5,6,3]  R2024     1.0182113945484161e-01
    z[5,6,3]  R2025     -2.2627657651901245e-01
    z[5,6,3]  R2026     4.8898467421531677e-01
    z[5,6,3]  R2027     6.5773159265518188e-01
    z[5,6,3]  R2028     -1.5517678111791611e-02
    z[5,6,3]  R2029     2.0188668370246887e-01
    z[5,6,3]  R2030     -1.9222943484783173e-01
    z[5,6,3]  R2031     -3.4604352712631226e-01
    z[5,6,3]  R2032     0.0963834673166275
    z[5,6,3]  R2033     3.7108927965164185e-01
    z[5,6,3]  R2034     6.3011771440505981e-01
    z[5,6,3]  R2035     2.7485069632530212e-01
    z[5,6,3]  R2036     5.0760430097579956e-01
    z[5,6,3]  R2037     1.0954966396093369e-01
    z[5,6,3]  R2038     -5.5873099714517593e-02
    z[5,6,3]  R2039     1.5161101520061493e-01
    z[5,6,3]  R2040     -8.6972750723361969e-02
    z[5,6,3]  R2041     0.0417293980717659
    z[5,6,3]  R2042     -2.2500304877758026e-01
    z[5,6,3]  R2043     5.8091831207275391e-01
    z[5,6,3]  R2044     1.0255575180053711e-01
    z[5,6,3]  R2045     -4.7698262333869934e-01
    z[5,6,3]  R2046     -2.8177621960639954e-01
    z[5,6,3]  R2047     -1.8471600487828255e-02
    z[5,6,3]  R2048     8.3505949005484581e-03
    z[5,6,3]  R2049     1.7427420616149902e-01
    z[5,6,3]  R2050     -3.5285431146621704e-01
    z[5,6,3]  R2051     -0.129202738404274
    z[5,6,3]  R2052     -1.6438604891300201e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R1960     -1
    z[5,6,4]  R1961     1
    z[5,6,4]  R1966     0.509081244468689
    z[5,6,4]  R1967     -3.8225552439689636e-01
    z[5,6,4]  R1968     -4.0255087614059448e-01
    z[5,6,4]  R1969     -3.5617059469223022e-01
    z[5,6,4]  R1970     -1.9378559291362762e-01
    z[5,6,4]  R1971     2.9812633991241455e-01
    z[5,6,4]  R1972     -7.5686089694499969e-03
    z[5,6,4]  R1973     -4.6676734089851379e-01
    z[5,6,4]  R1974     4.2089998722076416e-02
    z[5,6,4]  R1975     3.8982751965522766e-01
    z[5,6,4]  R1976     -2.0247953012585640e-02
    z[5,6,4]  R1977     -2.1993450820446014e-01
    z[5,6,4]  R1978     -1.3251057267189026e-01
    z[5,6,4]  R1979     2.2747045755386353e-01
    z[5,6,4]  R1980     -1.0758624225854874e-01
    z[5,6,4]  R1981     3.9782109856605530e-01
    z[5,6,4]  R1982     -2.3097884654998779e-01
    z[5,6,4]  R1983     -1.7669111490249634e-01
    z[5,6,4]  R1984     -9.3540467321872711e-02
    z[5,6,4]  R1985     1.7631421983242035e-01
    z[5,6,4]  R1986     6.2692828476428986e-02
    z[5,6,4]  R1987     0.00487328227609396
    z[5,6,4]  R1988     -3.2241308689117432e-01
    z[5,6,4]  R1989     5.9660151600837708e-02
    z[5,6,4]  R1990     2.8520748019218445e-01
    z[5,6,4]  R1991     -3.2254624366760254e-01
    z[5,6,4]  R1992     -3.8146528601646423e-01
    z[5,6,4]  R1993     -3.4659796953201294e-01
    z[5,6,4]  R1994     3.3483055233955383e-01
    z[5,6,4]  R1995     3.1140258908271790e-01
    z[5,6,4]  R1996     -3.9982533454895020e-01
    z[5,6,4]  R1997     4.1108959913253784e-01
    z[5,6,4]  R1998     -0.195590078830719
    z[5,6,4]  R1999     9.4385646283626556e-02
    z[5,6,4]  R2000     3.3273950219154358e-02
    z[5,6,4]  R2001     9.0568356215953827e-02
    z[5,6,4]  R2002     -2.3985737934708595e-02
    z[5,6,4]  R2003     -3.5591992735862732e-01
    z[5,6,4]  R2004     2.5977367162704468e-01
    z[5,6,4]  R2005     2.9617208242416382e-01
    z[5,6,4]  R2006     -1.1050403863191605e-01
    z[5,6,4]  R2007     -3.1300392746925354e-01
    z[5,6,4]  R2008     -2.9831424355506897e-01
    z[5,6,4]  R2009     -0.078194260597229
    z[5,6,4]  R2010     1.1277345009148121e-02
    z[5,6,4]  R2011     1.0195134673267603e-03
    z[5,6,4]  R2012     -3.1593844294548035e-01
    z[5,6,4]  R2013     -2.6771211624145508e-01
    z[5,6,4]  R2014     -2.4543073028326035e-02
    z[5,6,4]  R2015     -8.8862076401710510e-02
    z[5,6,4]  R2016     4.9440383911132812e-02
    z[5,6,4]  R2017     8.7021633982658386e-02
    z[5,6,4]  R2018     -4.5874398201704025e-02
    z[5,6,4]  R2019     -2.4660360813140869e-01
    z[5,6,4]  R2020     -2.5803777575492859e-01
    z[5,6,4]  R2021     0.629653811454773
    z[5,6,4]  R2022     -0.547412633895874
    z[5,6,4]  R2023     4.6226152777671814e-01
    z[5,6,4]  R2024     1.1981938965618610e-02
    z[5,6,4]  R2025     -2.6193103194236755e-01
    z[5,6,4]  R2026     3.0385696887969971e-01
    z[5,6,4]  R2027     1.1363150179386139e-01
    z[5,6,4]  R2028     1.7030476033687592e-01
    z[5,6,4]  R2029     5.3682446479797363e-02
    z[5,6,4]  R2030     2.6475310325622559e-01
    z[5,6,4]  R2031     0.278982013463974
    z[5,6,4]  R2032     4.0647217631340027e-01
    z[5,6,4]  R2033     4.2472994327545166e-01
    z[5,6,4]  R2034     1.4618931710720062e-01
    z[5,6,4]  R2035     -3.5961541533470154e-01
    z[5,6,4]  R2036     4.2954066395759583e-01
    z[5,6,4]  R2037     3.2832890748977661e-02
    z[5,6,4]  R2038     5.0434535741806030e-01
    z[5,6,4]  R2039     2.0872655510902405e-01
    z[5,6,4]  R2040     -1.1626593023538589e-01
    z[5,6,4]  R2041     3.2564330101013184e-01
    z[5,6,4]  R2042     -4.9502965062856674e-02
    z[5,6,4]  R2043     3.9730608463287354e-01
    z[5,6,4]  R2044     3.4764197468757629e-01
    z[5,6,4]  R2045     -2.4281549453735352e-01
    z[5,6,4]  R2046     1.3374213874340057e-01
    z[5,6,4]  R2047     6.1575431376695633e-02
    z[5,6,4]  R2048     3.3057440072298050e-02
    z[5,6,4]  R2049     -2.0564597100019455e-02
    z[5,6,4]  R2050     4.4731184840202332e-01
    z[5,6,4]  R2051     2.1267350018024445e-01
    z[5,6,4]  R2052     4.2725142836570740e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R1962     -1
    z[5,6,5]  R1963     1
    z[5,6,5]  R1966     7.1578228473663330e-01
    z[5,6,5]  R1967     7.7692353725433350e-01
    z[5,6,5]  R1968     -9.6755344420671463e-03
    z[5,6,5]  R1969     -1.6764727234840393e-01
    z[5,6,5]  R1970     1.6329331696033478e-01
    z[5,6,5]  R1971     -8.9326046407222748e-02
    z[5,6,5]  R1972     3.9545886218547821e-02
    z[5,6,5]  R1973     -0.0925360694527626
    z[5,6,5]  R1974     -4.2166151106357574e-02
    z[5,6,5]  R1975     -2.3908782750368118e-02
    z[5,6,5]  R1976     -1.8317978084087372e-01
    z[5,6,5]  R1977     -3.0318453907966614e-01
    z[5,6,5]  R1978     -3.7554496526718140e-01
    z[5,6,5]  R1979     -1.3667531311511993e-01
    z[5,6,5]  R1980     -1.8587402999401093e-01
    z[5,6,5]  R1981     -0.41797935962677
    z[5,6,5]  R1982     -2.8581684827804565e-01
    z[5,6,5]  R1983     -5.4287356138229370e-01
    z[5,6,5]  R1984     2.1530104801058769e-02
    z[5,6,5]  R1985     1.1809369176626205e-01
    z[5,6,5]  R1986     -1.6922626644372940e-02
    z[5,6,5]  R1987     -2.3602357506752014e-01
    z[5,6,5]  R1988     1.8345052376389503e-02
    z[5,6,5]  R1989     2.6451872661709785e-02
    z[5,6,5]  R1990     -2.1056348457932472e-02
    z[5,6,5]  R1991     -5.8092761039733887e-01
    z[5,6,5]  R1992     -3.7081623449921608e-03
    z[5,6,5]  R1993     -1.4472095668315887e-01
    z[5,6,5]  R1994     -1.3573783636093140e-01
    z[5,6,5]  R1995     0.191695436835289
    z[5,6,5]  R1996     5.9391713142395020e-01
    z[5,6,5]  R1997     4.5820543169975281e-01
    z[5,6,5]  R1998     2.2333097457885742e-01
    z[5,6,5]  R1999     1.2142891436815262e-01
    z[5,6,5]  R2000     7.5343793630599976e-01
    z[5,6,5]  R2001     3.8874158263206482e-01
    z[5,6,5]  R2002     -6.8857200443744659e-02
    z[5,6,5]  R2003     -4.2567139863967896e-01
    z[5,6,5]  R2004     1.5580528974533081e-01
    z[5,6,5]  R2005     -8.0725483596324921e-02
    z[5,6,5]  R2006     -1.4516647160053253e-01
    z[5,6,5]  R2007     2.8524610400199890e-01
    z[5,6,5]  R2008     4.3287283182144165e-01
    z[5,6,5]  R2009     3.8777789473533630e-01
    z[5,6,5]  R2010     -1.9387087225914001e-01
    z[5,6,5]  R2011     -2.7268588542938232e-01
    z[5,6,5]  R2012     0.217215433716774
    z[5,6,5]  R2013     1.8363347649574280e-01
    z[5,6,5]  R2014     1.2184689752757549e-02
    z[5,6,5]  R2015     -3.3728274703025818e-01
    z[5,6,5]  R2016     -3.2855114340782166e-01
    z[5,6,5]  R2017     -3.5278502106666565e-01
    z[5,6,5]  R2018     -0.41490638256073
    z[5,6,5]  R2019     1.0233254730701447e-01
    z[5,6,5]  R2020     5.6271735578775406e-02
    z[5,6,5]  R2021     -3.4656643867492676e-01
    z[5,6,5]  R2022     1.4203636348247528e-01
    z[5,6,5]  R2023     2.9624342918395996e-02
    z[5,6,5]  R2024     6.7647522687911987e-01
    z[5,6,5]  R2025     4.8723358660936356e-02
    z[5,6,5]  R2026     4.7669883817434311e-02
    z[5,6,5]  R2027     -2.8615808486938477e-01
    z[5,6,5]  R2028     1.4482316374778748e-01
    z[5,6,5]  R2029     6.9450116157531738e-01
    z[5,6,5]  R2030     -2.7214035391807556e-01
    z[5,6,5]  R2031     -7.5684398412704468e-02
    z[5,6,5]  R2032     -2.3218944668769836e-01
    z[5,6,5]  R2033     3.9754796028137207e-01
    z[5,6,5]  R2034     4.6906667947769165e-01
    z[5,6,5]  R2035     1.2018888443708420e-01
    z[5,6,5]  R2036     -6.8617528676986694e-01
    z[5,6,5]  R2037     1.1358385533094406e-01
    z[5,6,5]  R2038     5.2496343851089478e-02
    z[5,6,5]  R2039     1.1583501845598221e-01
    z[5,6,5]  R2040     3.5132703185081482e-01
    z[5,6,5]  R2041     -3.2511469721794128e-01
    z[5,6,5]  R2042     -4.2049628496170044e-01
    z[5,6,5]  R2043     -6.4440411329269409e-01
    z[5,6,5]  R2044     2.2377158701419830e-01
    z[5,6,5]  R2045     -2.4916891753673553e-01
    z[5,6,5]  R2046     2.4966686964035034e-01
    z[5,6,5]  R2047     -0.355245441198349
    z[5,6,5]  R2048     6.3282638788223267e-01
    z[5,6,5]  R2049     4.2506182193756104e-01
    z[5,6,5]  R2050     -1.5773360431194305e-01
    z[5,6,5]  R2051     -6.0122217983007431e-02
    z[5,6,5]  R2052     3.1174570322036743e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R1964     -1
    z[5,6,6]  R1965     1
    z[5,6,6]  R1966     -3.1722703576087952e-01
    z[5,6,6]  R1967     0.0425274521112442
    z[5,6,6]  R1968     -3.0511155724525452e-01
    z[5,6,6]  R1969     -3.8313925266265869e-01
    z[5,6,6]  R1970     3.6319881677627563e-01
    z[5,6,6]  R1971     0.387690931558609
    z[5,6,6]  R1972     -3.0640125274658203e-01
    z[5,6,6]  R1973     0.471548467874527
    z[5,6,6]  R1974     -1.3050666451454163e-01
    z[5,6,6]  R1975     -3.6141178011894226e-01
    z[5,6,6]  R1976     3.1543749570846558e-01
    z[5,6,6]  R1977     -5.5901497602462769e-01
    z[5,6,6]  R1978     6.1622675508260727e-02
    z[5,6,6]  R1979     3.1740683317184448e-01
    z[5,6,6]  R1980     -1.1058255285024643e-01
    z[5,6,6]  R1981     6.2087923288345337e-02
    z[5,6,6]  R1982     1.9308309257030487e-01
    z[5,6,6]  R1983     3.9245107769966125e-01
    z[5,6,6]  R1984     1.9526550173759460e-01
    z[5,6,6]  R1985     1.5403334796428680e-01
    z[5,6,6]  R1986     1.1634574830532074e-01
    z[5,6,6]  R1987     1.6607512533664703e-01
    z[5,6,6]  R1988     4.3586143851280212e-01
    z[5,6,6]  R1989     6.7124205827713013e-01
    z[5,6,6]  R1990     2.3354444652795792e-02
    z[5,6,6]  R1991     0.0557732991874218
    z[5,6,6]  R1992     -1.7011800408363342e-01
    z[5,6,6]  R1993     -4.6459862589836121e-01
    z[5,6,6]  R1994     -2.5445064902305603e-01
    z[5,6,6]  R1995     -4.7143781185150146e-01
    z[5,6,6]  R1996     -9.0329416096210480e-02
    z[5,6,6]  R1997     1.9213742017745972e-01
    z[5,6,6]  R1998     -7.5371921062469482e-02
    z[5,6,6]  R1999     -3.1680127978324890e-01
    z[5,6,6]  R2000     -4.6352922916412354e-01
    z[5,6,6]  R2001     3.8438599556684494e-02
    z[5,6,6]  R2002     0.261014848947525
    z[5,6,6]  R2003     4.8334154486656189e-01
    z[5,6,6]  R2004     1.1818795651197433e-01
    z[5,6,6]  R2005     8.3051025867462158e-01
    z[5,6,6]  R2006     8.5704708099365234e-01
    z[5,6,6]  R2007     0.682844340801239
    z[5,6,6]  R2008     5.7665061950683594e-01
    z[5,6,6]  R2009     7.2481536865234375e-01
    z[5,6,6]  R2010     4.0211758017539978e-01
    z[5,6,6]  R2011     -9.5372155308723450e-02
    z[5,6,6]  R2012     2.1879369020462036e-01
    z[5,6,6]  R2013     2.6650199294090271e-01
    z[5,6,6]  R2014     5.8533376455307007e-01
    z[5,6,6]  R2015     3.7827339768409729e-01
    z[5,6,6]  R2016     -3.6520313471555710e-02
    z[5,6,6]  R2017     -0.000860060506965965
    z[5,6,6]  R2018     1.8904957175254822e-01
    z[5,6,6]  R2019     2.2808564826846123e-02
    z[5,6,6]  R2020     -8.3424195647239685e-02
    z[5,6,6]  R2021     1.7950646579265594e-02
    z[5,6,6]  R2022     4.2042294144630432e-01
    z[5,6,6]  R2023     -1.0060324519872665e-01
    z[5,6,6]  R2024     1.8184538930654526e-02
    z[5,6,6]  R2025     2.5367733836174011e-01
    z[5,6,6]  R2026     1.5950077772140503e-01
    z[5,6,6]  R2027     -3.7078243494033813e-01
    z[5,6,6]  R2028     -1.3133244216442108e-01
    z[5,6,6]  R2029     -4.3709173798561096e-02
    z[5,6,6]  R2030     0.423032283782959
    z[5,6,6]  R2031     1.6708987951278687e-01
    z[5,6,6]  R2032     3.0549925565719604e-01
    z[5,6,6]  R2033     -1.5334303677082062e-01
    z[5,6,6]  R2034     -3.6709284782409668e-01
    z[5,6,6]  R2035     1.2286590039730072e-01
    z[5,6,6]  R2036     -6.7497797310352325e-02
    z[5,6,6]  R2037     3.1256254762411118e-02
    z[5,6,6]  R2038     2.6256346702575684e-01
    z[5,6,6]  R2039     4.8001569509506226e-01
    z[5,6,6]  R2040     4.7469669580459595e-01
    z[5,6,6]  R2041     3.9829116314649582e-02
    z[5,6,6]  R2042     2.2275516390800476e-01
    z[5,6,6]  R2043     -4.2748800478875637e-04
    z[5,6,6]  R2044     -8.9473381638526917e-02
    z[5,6,6]  R2045     9.4732828438282013e-02
    z[5,6,6]  R2046     6.1027163267135620e-01
    z[5,6,6]  R2047     1.5876251459121704e-01
    z[5,6,6]  R2048     3.3920636773109436e-01
    z[5,6,6]  R2049     1.4114594459533691e-01
    z[5,6,6]  R2050     2.1262085065245628e-02
    z[5,6,6]  R2051     -4.5625671744346619e-01
    z[5,6,6]  R2052     -1.3936492800712585e-01
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2053     -1
    z[6,5,0]  R2054     1
    z[6,5,0]  R2067     -1.8632820248603821e-01
    z[6,5,0]  R2068     -4.7465452551841736e-01
    z[6,5,0]  R2069     4.3792444467544556e-01
    z[6,5,0]  R2070     3.8235524296760559e-01
    z[6,5,0]  R2071     3.7346342206001282e-01
    z[6,5,0]  R2072     6.3119995594024658e-01
    z[6,5,0]  R2073     3.2929986715316772e-01
    z[6,5,0]  R2074     1.5928198397159576e-01
    z[6,5,0]  R2075     6.0713529586791992e-01
    z[6,5,0]  R2076     3.4094351530075073e-01
    z[6,5,0]  R2077     -0.58119797706604
    z[6,5,0]  R2078     3.0131638050079346e-02
    z[6,5,0]  R2079     -1.4204809069633484e-01
    z[6,5,0]  R2080     -6.5065003931522369e-02
    z[6,5,0]  R2081     -3.1800848245620728e-01
    z[6,5,0]  R2082     -4.2569833993911743e-01
    z[6,5,0]  R2083     -3.5634589195251465e-01
    z[6,5,0]  R2084     3.0663952231407166e-01
    z[6,5,0]  R2085     2.5091221928596497e-01
    z[6,5,0]  R2086     -5.2162152528762817e-01
    z[6,5,0]  R2087     -3.3429333567619324e-01
    z[6,5,0]  R2088     -2.3331068456172943e-01
    z[6,5,0]  R2089     3.7231542170047760e-02
    z[6,5,0]  R2090     2.4421063065528870e-01
    z[6,5,0]  R2091     4.2844238877296448e-01
    z[6,5,0]  R2092     5.3521293401718140e-01
    z[6,5,0]  R2093     3.9225590229034424e-01
    z[6,5,0]  R2094     5.9769493341445923e-01
    z[6,5,0]  R2095     4.0260460972785950e-01
    z[6,5,0]  R2096     -1.4065428078174591e-01
    z[6,5,0]  R2097     2.9243695735931396e-01
    z[6,5,0]  R2098     7.3771692812442780e-02
    z[6,5,0]  R2099     2.5312933325767517e-01
    z[6,5,0]  R2100     6.3629776239395142e-01
    z[6,5,0]  R2101     0.184300035238266
    z[6,5,0]  R2102     -1.8647179007530212e-01
    z[6,5,0]  R2103     3.7628549337387085e-01
    z[6,5,0]  R2104     2.8730541467666626e-01
    z[6,5,0]  R2105     8.5978329181671143e-02
    z[6,5,0]  R2106     0.509591281414032
    z[6,5,0]  R2107     -5.9725429862737656e-02
    z[6,5,0]  R2108     3.3289736509323120e-01
    z[6,5,0]  R2109     0.533287525177002
    z[6,5,0]  R2110     -6.6896595060825348e-02
    z[6,5,0]  R2111     3.0792000889778137e-01
    z[6,5,0]  R2112     2.2734439373016357e-01
    z[6,5,0]  R2113     6.3056498765945435e-01
    z[6,5,0]  R2114     -1.6158511862158775e-02
    z[6,5,0]  R2115     6.9024398922920227e-02
    z[6,5,0]  R2116     3.2530412077903748e-01
    z[6,5,0]  R2117     -1.7556053400039673e-01
    z[6,5,0]  R2118     4.3240612745285034e-01
    z[6,5,0]  R2119     -3.0810329318046570e-01
    z[6,5,0]  R2120     -9.9450044333934784e-02
    z[6,5,0]  R2121     2.9956212639808655e-01
    z[6,5,0]  R2122     4.4328609108924866e-01
    z[6,5,0]  R2123     -2.0548477768898010e-02
    z[6,5,0]  R2124     -5.0517898797988892e-01
    z[6,5,0]  R2125     -3.6625093221664429e-01
    z[6,5,0]  R2126     -2.4710388481616974e-01
    z[6,5,0]  R2127     1.1186915449798107e-02
    z[6,5,0]  R2128     -4.8215375281870365e-03
    z[6,5,0]  R2129     -3.1158182024955750e-01
    z[6,5,0]  R2130     -4.5451480150222778e-01
    z[6,5,0]  R2131     -6.3648438453674316e-01
    z[6,5,0]  R2132     -5.5495697259902954e-01
    z[6,5,0]  R2133     -9.0682422742247581e-03
    z[6,5,0]  R2134     1.0719141364097595e-01
    z[6,5,0]  R2135     3.4995445609092712e-01
    z[6,5,0]  R2136     -3.2522717118263245e-01
    z[6,5,0]  R2137     -5.2713447809219360e-01
    z[6,5,0]  R2138     1.8959281966090202e-02
    z[6,5,0]  R2139     2.4771073460578918e-01
    z[6,5,0]  R2140     -6.5029990673065186e-01
    z[6,5,0]  R2141     1.4037866890430450e-01
    z[6,5,0]  R2142     1.8609800934791565e-01
    z[6,5,0]  R2143     -0.00932371336966753
    z[6,5,0]  R2144     6.1752386391162872e-02
    z[6,5,0]  R2145     -9.8541423678398132e-02
    z[6,5,0]  R2146     2.8609317541122437e-01
    z[6,5,0]  R2147     8.6865060031414032e-02
    z[6,5,0]  R2148     -2.8792256116867065e-01
    z[6,5,0]  R2149     -3.8555711507797241e-02
    z[6,5,0]  R2150     1.6615432500839233e-01
    z[6,5,0]  R2151     -3.5495206713676453e-02
    z[6,5,0]  R2152     4.3524277210235596e-01
    z[6,5,0]  R2153     2.6447480916976929e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2055     -1
    z[6,5,1]  R2056     1
    z[6,5,1]  R2067     6.1064338684082031e-01
    z[6,5,1]  R2068     6.2450957298278809e-01
    z[6,5,1]  R2069     5.7998287677764893e-01
    z[6,5,1]  R2070     4.0597015619277954e-01
    z[6,5,1]  R2071     6.3167077302932739e-01
    z[6,5,1]  R2072     -0.530769944190979
    z[6,5,1]  R2073     -8.4959131479263306e-01
    z[6,5,1]  R2074     3.1109875440597534e-01
    z[6,5,1]  R2075     -5.5505788326263428e-01
    z[6,5,1]  R2076     7.6115798950195312e-01
    z[6,5,1]  R2077     6.7412899807095528e-03
    z[6,5,1]  R2078     -4.3777039647102356e-01
    z[6,5,1]  R2079     -1.1569716967642307e-02
    z[6,5,1]  R2080     5.7042874395847321e-03
    z[6,5,1]  R2081     -1.0769910365343094e-01
    z[6,5,1]  R2082     -0.089664988219738
    z[6,5,1]  R2083     -4.7049908898770809e-03
    z[6,5,1]  R2084     -7.8689880669116974e-02
    z[6,5,1]  R2085     5.3881829977035522e-01
    z[6,5,1]  R2086     -7.2857844829559326e-01
    z[6,5,1]  R2087     2.4562025070190430e-01
    z[6,5,1]  R2088     3.5549721121788025e-01
    z[6,5,1]  R2089     7.6754844188690186e-01
    z[6,5,1]  R2090     7.3900038003921509e-01
    z[6,5,1]  R2091     0.700786292552948
    z[6,5,1]  R2092     1.5757998824119568e-01
    z[6,5,1]  R2093     -6.3820332288742065e-01
    z[6,5,1]  R2094     -7.3525291681289673e-01
    z[6,5,1]  R2095     1.3339456915855408e-01
    z[6,5,1]  R2096     5.8279263973236084e-01
    z[6,5,1]  R2097     7.5469082593917847e-01
    z[6,5,1]  R2098     7.2485476732254028e-01
    z[6,5,1]  R2099     0.859340250492096
    z[6,5,1]  R2100     -3.5345073789358139e-02
    z[6,5,1]  R2101     -3.5264518857002258e-01
    z[6,5,1]  R2102     -6.0123950242996216e-01
    z[6,5,1]  R2103     -2.7305385470390320e-01
    z[6,5,1]  R2104     -0.696918249130249
    z[6,5,1]  R2105     -5.3487861156463623e-01
    z[6,5,1]  R2106     -5.9835082292556763e-01
    z[6,5,1]  R2107     7.0404177904129028e-01
    z[6,5,1]  R2108     1.4636141061782837e-01
    z[6,5,1]  R2109     3.5103011131286621e-01
    z[6,5,1]  R2110     -3.7472493946552277e-02
    z[6,5,1]  R2111     -5.2194631099700928e-01
    z[6,5,1]  R2112     -6.3355344533920288e-01
    z[6,5,1]  R2113     -4.7664853930473328e-01
    z[6,5,1]  R2114     -5.6076383590698242e-01
    z[6,5,1]  R2115     -7.4455153942108154e-01
    z[6,5,1]  R2116     -7.7789926528930664e-01
    z[6,5,1]  R2117     -2.2095529362559319e-02
    z[6,5,1]  R2118     -7.4164569377899170e-01
    z[6,5,1]  R2119     7.3182427883148193e-01
    z[6,5,1]  R2120     6.3839703798294067e-01
    z[6,5,1]  R2121     -0.833806574344635
    z[6,5,1]  R2122     -4.0060380101203918e-01
    z[6,5,1]  R2123     -7.9504323005676270e-01
    z[6,5,1]  R2124     -0.525545597076416
    z[6,5,1]  R2125     -5.5992990732192993e-01
    z[6,5,1]  R2126     -0.585119366645813
    z[6,5,1]  R2127     -2.8183379769325256e-01
    z[6,5,1]  R2128     -4.3488350510597229e-01
    z[6,5,1]  R2129     4.9660235643386841e-01
    z[6,5,1]  R2130     6.6657382249832153e-01
    z[6,5,1]  R2131     3.3694645762443542e-01
    z[6,5,1]  R2132     6.0095584392547607e-01
    z[6,5,1]  R2133     8.8974541425704956e-01
    z[6,5,1]  R2134     0.454041987657547
    z[6,5,1]  R2135     8.6570811271667480e-01
    z[6,5,1]  R2136     6.2760341167449951e-01
    z[6,5,1]  R2137     -5.5866867303848267e-01
    z[6,5,1]  R2138     -5.9417122602462769e-01
    z[6,5,1]  R2139     -7.2897613048553467e-01
    z[6,5,1]  R2140     0.0097170639783144
    z[6,5,1]  R2141     7.5981557369232178e-01
    z[6,5,1]  R2142     7.6729327440261841e-01
    z[6,5,1]  R2143     7.8068637847900391e-01
    z[6,5,1]  R2144     5.2841019630432129e-01
    z[6,5,1]  R2145     7.7418565750122070e-01
    z[6,5,1]  R2146     8.0917710065841675e-01
    z[6,5,1]  R2147     8.6591434478759766e-01
    z[6,5,1]  R2148     7.7511388063430786e-01
    z[6,5,1]  R2149     7.3167085647583008e-01
    z[6,5,1]  R2150     6.2748539447784424e-01
    z[6,5,1]  R2151     8.4570759534835815e-01
    z[6,5,1]  R2152     5.8977931737899780e-01
    z[6,5,1]  R2153     6.4801257848739624e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2057     -1
    z[6,5,2]  R2058     1
    z[6,5,2]  R2067     -0.332560658454895
    z[6,5,2]  R2068     5.3895749151706696e-02
    z[6,5,2]  R2069     -0.286003977060318
    z[6,5,2]  R2070     -3.4214845299720764e-01
    z[6,5,2]  R2071     -1.1339093744754791e-01
    z[6,5,2]  R2072     4.0346592664718628e-01
    z[6,5,2]  R2073     1.7034868896007538e-01
    z[6,5,2]  R2074     -2.1381275728344917e-02
    z[6,5,2]  R2075     2.2181870043277740e-01
    z[6,5,2]  R2076     4.7923141717910767e-01
    z[6,5,2]  R2077     -6.5385691821575165e-02
    z[6,5,2]  R2078     -1.6888666152954102e-01
    z[6,5,2]  R2079     -2.2791191935539246e-02
    z[6,5,2]  R2080     -2.2853022813796997e-01
    z[6,5,2]  R2081     -7.1053137071430683e-03
    z[6,5,2]  R2082     1.4190416038036346e-01
    z[6,5,2]  R2083     1.5632751584053040e-01
    z[6,5,2]  R2084     -5.2995961904525757e-01
    z[6,5,2]  R2085     -3.7402606103569269e-03
    z[6,5,2]  R2086     -4.1265211999416351e-02
    z[6,5,2]  R2087     -2.1572384238243103e-01
    z[6,5,2]  R2088     -2.1186050772666931e-01
    z[6,5,2]  R2089     -1.3898000121116638e-01
    z[6,5,2]  R2090     -1.4530846476554871e-01
    z[6,5,2]  R2091     -3.7960830330848694e-01
    z[6,5,2]  R2092     -6.3927090167999268e-01
    z[6,5,2]  R2093     4.3904027342796326e-01
    z[6,5,2]  R2094     -3.5784412175416946e-02
    z[6,5,2]  R2095     -3.6239191889762878e-01
    z[6,5,2]  R2096     2.3358710110187531e-02
    z[6,5,2]  R2097     -2.5001293420791626e-01
    z[6,5,2]  R2098     2.6127649471163750e-02
    z[6,5,2]  R2099     1.0452125966548920e-01
    z[6,5,2]  R2100     -4.8448723554611206e-01
    z[6,5,2]  R2101     -0.420459121465683
    z[6,5,2]  R2102     7.3230654001235962e-01
    z[6,5,2]  R2103     5.0593322515487671e-01
    z[6,5,2]  R2104     2.6776370406150818e-01
    z[6,5,2]  R2105     6.8941169977188110e-01
    z[6,5,2]  R2106     2.4605287611484528e-01
    z[6,5,2]  R2107     3.3118776977062225e-02
    z[6,5,2]  R2108     -3.0750176310539246e-01
    z[6,5,2]  R2109     -5.9830981492996216e-01
    z[6,5,2]  R2110     -2.7669641375541687e-01
    z[6,5,2]  R2111     7.7833157777786255e-01
    z[6,5,2]  R2112     4.6662944555282593e-01
    z[6,5,2]  R2113     2.5457486510276794e-01
    z[6,5,2]  R2114     5.6163430213928223e-01
    z[6,5,2]  R2115     4.7519233822822571e-01
    z[6,5,2]  R2116     9.7652181982994080e-02
    z[6,5,2]  R2117     -2.4107088148593903e-01
    z[6,5,2]  R2118     2.7117297053337097e-01
    z[6,5,2]  R2119     1.0942734032869339e-01
    z[6,5,2]  R2120     2.2474190592765808e-01
    z[6,5,2]  R2121     2.4390894174575806e-01
    z[6,5,2]  R2122     3.5541704297065735e-01
    z[6,5,2]  R2123     3.6890363693237305e-01
    z[6,5,2]  R2124     3.4448531270027161e-01
    z[6,5,2]  R2125     -5.2785462141036987e-01
    z[6,5,2]  R2126     -5.2000045776367188e-01
    z[6,5,2]  R2127     -2.1567940711975098e-01
    z[6,5,2]  R2128     1.3756586611270905e-01
    z[6,5,2]  R2129     -6.0235446691513062e-01
    z[6,5,2]  R2130     -1.3066259026527405e-01
    z[6,5,2]  R2131     -5.2772867679595947e-01
    z[6,5,2]  R2132     -1.9353452324867249e-01
    z[6,5,2]  R2133     -0.0511116087436676
    z[6,5,2]  R2134     -5.7751423120498657e-01
    z[6,5,2]  R2135     2.8160056471824646e-01
    z[6,5,2]  R2136     4.2929247021675110e-01
    z[6,5,2]  R2137     -2.3929375410079956e-01
    z[6,5,2]  R2138     4.3117862194776535e-02
    z[6,5,2]  R2139     -4.9465906620025635e-01
    z[6,5,2]  R2140     2.2865265607833862e-01
    z[6,5,2]  R2141     0.264136403799057
    z[6,5,2]  R2142     -3.5222183912992477e-02
    z[6,5,2]  R2143     3.0547997355461121e-01
    z[6,5,2]  R2144     -3.2193638384342194e-02
    z[6,5,2]  R2145     4.7409462928771973e-01
    z[6,5,2]  R2146     -1.0327765345573425e-01
    z[6,5,2]  R2147     6.5677843987941742e-02
    z[6,5,2]  R2148     4.6928778290748596e-01
    z[6,5,2]  R2149     3.7477472424507141e-01
    z[6,5,2]  R2150     -1.6672912240028381e-01
    z[6,5,2]  R2151     3.1196582317352295e-01
    z[6,5,2]  R2152     -0.039963249117136
    z[6,5,2]  R2153     5.4550009965896606e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2059     -1
    z[6,5,3]  R2060     1
    z[6,5,3]  R2067     3.5337468981742859e-01
    z[6,5,3]  R2068     4.3186199665069580e-01
    z[6,5,3]  R2069     1.8458463251590729e-01
    z[6,5,3]  R2070     2.2620768845081329e-01
    z[6,5,3]  R2071     1.8109650909900665e-01
    z[6,5,3]  R2072     -2.5153917074203491e-01
    z[6,5,3]  R2073     -1.2930953502655029e-01
    z[6,5,3]  R2074     3.0619335174560547e-01
    z[6,5,3]  R2075     -3.3659148216247559e-01
    z[6,5,3]  R2076     -3.5887490957975388e-02
    z[6,5,3]  R2077     3.4116572141647339e-01
    z[6,5,3]  R2078     8.2048797607421875e-01
    z[6,5,3]  R2079     4.4180014729499817e-01
    z[6,5,3]  R2080     4.1915854811668396e-01
    z[6,5,3]  R2081     4.9153622984886169e-01
    z[6,5,3]  R2082     4.2627230286598206e-01
    z[6,5,3]  R2083     4.0830591320991516e-01
    z[6,5,3]  R2084     6.4769697189331055e-01
    z[6,5,3]  R2085     -7.5049948692321777e-01
    z[6,5,3]  R2086     2.2613897919654846e-02
    z[6,5,3]  R2087     7.7779656648635864e-01
    z[6,5,3]  R2088     6.5645754337310791e-01
    z[6,5,3]  R2089     -3.5414823889732361e-01
    z[6,5,3]  R2090     -5.1127409934997559e-01
    z[6,5,3]  R2091     -2.2181639075279236e-01
    z[6,5,3]  R2092     2.6468244194984436e-01
    z[6,5,3]  R2093     4.1745647788047791e-01
    z[6,5,3]  R2094     1.5547877550125122e-01
    z[6,5,3]  R2095     4.1459989547729492e-01
    z[6,5,3]  R2096     -3.7872564792633057e-01
    z[6,5,3]  R2097     2.4027393758296967e-01
    z[6,5,3]  R2098     1.0182113945484161e-01
    z[6,5,3]  R2099     -2.2627657651901245e-01
    z[6,5,3]  R2100     4.8898467421531677e-01
    z[6,5,3]  R2101     6.5773159265518188e-01
    z[6,5,3]  R2102     -1.5517678111791611e-02
    z[6,5,3]  R2103     2.0188668370246887e-01
    z[6,5,3]  R2104     -1.9222943484783173e-01
    z[6,5,3]  R2105     -3.4604352712631226e-01
    z[6,5,3]  R2106     0.0963834673166275
    z[6,5,3]  R2107     3.7108927965164185e-01
    z[6,5,3]  R2108     6.3011771440505981e-01
    z[6,5,3]  R2109     2.7485069632530212e-01
    z[6,5,3]  R2110     5.0760430097579956e-01
    z[6,5,3]  R2111     1.0954966396093369e-01
    z[6,5,3]  R2112     -5.5873099714517593e-02
    z[6,5,3]  R2113     1.5161101520061493e-01
    z[6,5,3]  R2114     -8.6972750723361969e-02
    z[6,5,3]  R2115     0.0417293980717659
    z[6,5,3]  R2116     -2.2500304877758026e-01
    z[6,5,3]  R2117     5.8091831207275391e-01
    z[6,5,3]  R2118     1.0255575180053711e-01
    z[6,5,3]  R2119     -4.7698262333869934e-01
    z[6,5,3]  R2120     -2.8177621960639954e-01
    z[6,5,3]  R2121     -1.8471600487828255e-02
    z[6,5,3]  R2122     8.3505949005484581e-03
    z[6,5,3]  R2123     1.7427420616149902e-01
    z[6,5,3]  R2124     -3.5285431146621704e-01
    z[6,5,3]  R2125     -0.129202738404274
    z[6,5,3]  R2126     -1.6438604891300201e-01
    z[6,5,3]  R2127     -4.2259678244590759e-02
    z[6,5,3]  R2128     -2.0097452402114868e-01
    z[6,5,3]  R2129     1.9554542005062103e-01
    z[6,5,3]  R2130     1.7396594583988190e-01
    z[6,5,3]  R2131     8.2013376057147980e-02
    z[6,5,3]  R2132     2.1507333219051361e-01
    z[6,5,3]  R2133     -3.3189707994461060e-01
    z[6,5,3]  R2134     -6.3638072460889816e-03
    z[6,5,3]  R2135     -1.6793160140514374e-01
    z[6,5,3]  R2136     1.8136581778526306e-01
    z[6,5,3]  R2137     4.6828565001487732e-01
    z[6,5,3]  R2138     4.3812346458435059e-01
    z[6,5,3]  R2139     -1.2449848465621471e-02
    z[6,5,3]  R2140     -0.594612181186676
    z[6,5,3]  R2141     5.2426481246948242e-01
    z[6,5,3]  R2142     -1.9637893140316010e-01
    z[6,5,3]  R2143     3.5327067971229553e-01
    z[6,5,3]  R2144     -4.8578137159347534e-01
    z[6,5,3]  R2145     -3.4470051527023315e-01
    z[6,5,3]  R2146     4.2890289425849915e-01
    z[6,5,3]  R2147     0.469659686088562
    z[6,5,3]  R2148     -1.1294345557689667e-01
    z[6,5,3]  R2149     -1.6868086159229279e-01
    z[6,5,3]  R2150     -3.0988928675651550e-01
    z[6,5,3]  R2151     -3.2227909564971924e-01
    z[6,5,3]  R2152     0.128465473651886
    z[6,5,3]  R2153     -1.9517371058464050e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2061     -1
    z[6,5,4]  R2062     1
    z[6,5,4]  R2067     -3.4659796953201294e-01
    z[6,5,4]  R2068     3.3483055233955383e-01
    z[6,5,4]  R2069     3.1140258908271790e-01
    z[6,5,4]  R2070     -3.9982533454895020e-01
    z[6,5,4]  R2071     4.1108959913253784e-01
    z[6,5,4]  R2072     -0.195590078830719
    z[6,5,4]  R2073     9.4385646283626556e-02
    z[6,5,4]  R2074     3.3273950219154358e-02
    z[6,5,4]  R2075     9.0568356215953827e-02
    z[6,5,4]  R2076     -2.3985737934708595e-02
    z[6,5,4]  R2077     -3.5591992735862732e-01
    z[6,5,4]  R2078     2.5977367162704468e-01
    z[6,5,4]  R2079     2.9617208242416382e-01
    z[6,5,4]  R2080     -1.1050403863191605e-01
    z[6,5,4]  R2081     -3.1300392746925354e-01
    z[6,5,4]  R2082     -2.9831424355506897e-01
    z[6,5,4]  R2083     -0.078194260597229
    z[6,5,4]  R2084     1.1277345009148121e-02
    z[6,5,4]  R2085     1.0195134673267603e-03
    z[6,5,4]  R2086     -3.1593844294548035e-01
    z[6,5,4]  R2087     -2.6771211624145508e-01
    z[6,5,4]  R2088     -2.4543073028326035e-02
    z[6,5,4]  R2089     -8.8862076401710510e-02
    z[6,5,4]  R2090     4.9440383911132812e-02
    z[6,5,4]  R2091     8.7021633982658386e-02
    z[6,5,4]  R2092     -4.5874398201704025e-02
    z[6,5,4]  R2093     -2.4660360813140869e-01
    z[6,5,4]  R2094     -2.5803777575492859e-01
    z[6,5,4]  R2095     0.629653811454773
    z[6,5,4]  R2096     -0.547412633895874
    z[6,5,4]  R2097     4.6226152777671814e-01
    z[6,5,4]  R2098     1.1981938965618610e-02
    z[6,5,4]  R2099     -2.6193103194236755e-01
    z[6,5,4]  R2100     3.0385696887969971e-01
    z[6,5,4]  R2101     1.1363150179386139e-01
    z[6,5,4]  R2102     1.7030476033687592e-01
    z[6,5,4]  R2103     5.3682446479797363e-02
    z[6,5,4]  R2104     2.6475310325622559e-01
    z[6,5,4]  R2105     0.278982013463974
    z[6,5,4]  R2106     4.0647217631340027e-01
    z[6,5,4]  R2107     4.2472994327545166e-01
    z[6,5,4]  R2108     1.4618931710720062e-01
    z[6,5,4]  R2109     -3.5961541533470154e-01
    z[6,5,4]  R2110     4.2954066395759583e-01
    z[6,5,4]  R2111     3.2832890748977661e-02
    z[6,5,4]  R2112     5.0434535741806030e-01
    z[6,5,4]  R2113     2.0872655510902405e-01
    z[6,5,4]  R2114     -1.1626593023538589e-01
    z[6,5,4]  R2115     3.2564330101013184e-01
    z[6,5,4]  R2116     -4.9502965062856674e-02
    z[6,5,4]  R2117     3.9730608463287354e-01
    z[6,5,4]  R2118     3.4764197468757629e-01
    z[6,5,4]  R2119     -2.4281549453735352e-01
    z[6,5,4]  R2120     1.3374213874340057e-01
    z[6,5,4]  R2121     6.1575431376695633e-02
    z[6,5,4]  R2122     3.3057440072298050e-02
    z[6,5,4]  R2123     -2.0564597100019455e-02
    z[6,5,4]  R2124     4.4731184840202332e-01
    z[6,5,4]  R2125     2.1267350018024445e-01
    z[6,5,4]  R2126     4.2725142836570740e-01
    z[6,5,4]  R2127     0.509081244468689
    z[6,5,4]  R2128     -3.8225552439689636e-01
    z[6,5,4]  R2129     -4.0255087614059448e-01
    z[6,5,4]  R2130     -3.5617059469223022e-01
    z[6,5,4]  R2131     -1.9378559291362762e-01
    z[6,5,4]  R2132     2.9812633991241455e-01
    z[6,5,4]  R2133     -7.5686089694499969e-03
    z[6,5,4]  R2134     -4.6676734089851379e-01
    z[6,5,4]  R2135     4.2089998722076416e-02
    z[6,5,4]  R2136     3.8982751965522766e-01
    z[6,5,4]  R2137     -2.0247953012585640e-02
    z[6,5,4]  R2138     -2.1993450820446014e-01
    z[6,5,4]  R2139     -1.3251057267189026e-01
    z[6,5,4]  R2140     2.2747045755386353e-01
    z[6,5,4]  R2141     -1.0758624225854874e-01
    z[6,5,4]  R2142     3.9782109856605530e-01
    z[6,5,4]  R2143     -2.3097884654998779e-01
    z[6,5,4]  R2144     -1.7669111490249634e-01
    z[6,5,4]  R2145     -9.3540467321872711e-02
    z[6,5,4]  R2146     1.7631421983242035e-01
    z[6,5,4]  R2147     6.2692828476428986e-02
    z[6,5,4]  R2148     0.00487328227609396
    z[6,5,4]  R2149     -3.2241308689117432e-01
    z[6,5,4]  R2150     5.9660151600837708e-02
    z[6,5,4]  R2151     2.8520748019218445e-01
    z[6,5,4]  R2152     -3.2254624366760254e-01
    z[6,5,4]  R2153     -3.8146528601646423e-01
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2063     -1
    z[6,5,5]  R2064     1
    z[6,5,5]  R2067     -1.4472095668315887e-01
    z[6,5,5]  R2068     -1.3573783636093140e-01
    z[6,5,5]  R2069     0.191695436835289
    z[6,5,5]  R2070     5.9391713142395020e-01
    z[6,5,5]  R2071     4.5820543169975281e-01
    z[6,5,5]  R2072     2.2333097457885742e-01
    z[6,5,5]  R2073     1.2142891436815262e-01
    z[6,5,5]  R2074     7.5343793630599976e-01
    z[6,5,5]  R2075     3.8874158263206482e-01
    z[6,5,5]  R2076     -6.8857200443744659e-02
    z[6,5,5]  R2077     -4.2567139863967896e-01
    z[6,5,5]  R2078     1.5580528974533081e-01
    z[6,5,5]  R2079     -8.0725483596324921e-02
    z[6,5,5]  R2080     -1.4516647160053253e-01
    z[6,5,5]  R2081     2.8524610400199890e-01
    z[6,5,5]  R2082     4.3287283182144165e-01
    z[6,5,5]  R2083     3.8777789473533630e-01
    z[6,5,5]  R2084     -1.9387087225914001e-01
    z[6,5,5]  R2085     -2.7268588542938232e-01
    z[6,5,5]  R2086     0.217215433716774
    z[6,5,5]  R2087     1.8363347649574280e-01
    z[6,5,5]  R2088     1.2184689752757549e-02
    z[6,5,5]  R2089     -3.3728274703025818e-01
    z[6,5,5]  R2090     -3.2855114340782166e-01
    z[6,5,5]  R2091     -3.5278502106666565e-01
    z[6,5,5]  R2092     -0.41490638256073
    z[6,5,5]  R2093     1.0233254730701447e-01
    z[6,5,5]  R2094     5.6271735578775406e-02
    z[6,5,5]  R2095     -3.4656643867492676e-01
    z[6,5,5]  R2096     1.4203636348247528e-01
    z[6,5,5]  R2097     2.9624342918395996e-02
    z[6,5,5]  R2098     6.7647522687911987e-01
    z[6,5,5]  R2099     4.8723358660936356e-02
    z[6,5,5]  R2100     4.7669883817434311e-02
    z[6,5,5]  R2101     -2.8615808486938477e-01
    z[6,5,5]  R2102     1.4482316374778748e-01
    z[6,5,5]  R2103     6.9450116157531738e-01
    z[6,5,5]  R2104     -2.7214035391807556e-01
    z[6,5,5]  R2105     -7.5684398412704468e-02
    z[6,5,5]  R2106     -2.3218944668769836e-01
    z[6,5,5]  R2107     3.9754796028137207e-01
    z[6,5,5]  R2108     4.6906667947769165e-01
    z[6,5,5]  R2109     1.2018888443708420e-01
    z[6,5,5]  R2110     -6.8617528676986694e-01
    z[6,5,5]  R2111     1.1358385533094406e-01
    z[6,5,5]  R2112     5.2496343851089478e-02
    z[6,5,5]  R2113     1.1583501845598221e-01
    z[6,5,5]  R2114     3.5132703185081482e-01
    z[6,5,5]  R2115     -3.2511469721794128e-01
    z[6,5,5]  R2116     -4.2049628496170044e-01
    z[6,5,5]  R2117     -6.4440411329269409e-01
    z[6,5,5]  R2118     2.2377158701419830e-01
    z[6,5,5]  R2119     -2.4916891753673553e-01
    z[6,5,5]  R2120     2.4966686964035034e-01
    z[6,5,5]  R2121     -0.355245441198349
    z[6,5,5]  R2122     6.3282638788223267e-01
    z[6,5,5]  R2123     4.2506182193756104e-01
    z[6,5,5]  R2124     -1.5773360431194305e-01
    z[6,5,5]  R2125     -6.0122217983007431e-02
    z[6,5,5]  R2126     3.1174570322036743e-01
    z[6,5,5]  R2127     7.1578228473663330e-01
    z[6,5,5]  R2128     7.7692353725433350e-01
    z[6,5,5]  R2129     -9.6755344420671463e-03
    z[6,5,5]  R2130     -1.6764727234840393e-01
    z[6,5,5]  R2131     1.6329331696033478e-01
    z[6,5,5]  R2132     -8.9326046407222748e-02
    z[6,5,5]  R2133     3.9545886218547821e-02
    z[6,5,5]  R2134     -0.0925360694527626
    z[6,5,5]  R2135     -4.2166151106357574e-02
    z[6,5,5]  R2136     -2.3908782750368118e-02
    z[6,5,5]  R2137     -1.8317978084087372e-01
    z[6,5,5]  R2138     -3.0318453907966614e-01
    z[6,5,5]  R2139     -3.7554496526718140e-01
    z[6,5,5]  R2140     -1.3667531311511993e-01
    z[6,5,5]  R2141     -1.8587402999401093e-01
    z[6,5,5]  R2142     -0.41797935962677
    z[6,5,5]  R2143     -2.8581684827804565e-01
    z[6,5,5]  R2144     -5.4287356138229370e-01
    z[6,5,5]  R2145     2.1530104801058769e-02
    z[6,5,5]  R2146     1.1809369176626205e-01
    z[6,5,5]  R2147     -1.6922626644372940e-02
    z[6,5,5]  R2148     -2.3602357506752014e-01
    z[6,5,5]  R2149     1.8345052376389503e-02
    z[6,5,5]  R2150     2.6451872661709785e-02
    z[6,5,5]  R2151     -2.1056348457932472e-02
    z[6,5,5]  R2152     -5.8092761039733887e-01
    z[6,5,5]  R2153     -3.7081623449921608e-03
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2065     -1
    z[6,5,6]  R2066     1
    z[6,5,6]  R2067     -4.6459862589836121e-01
    z[6,5,6]  R2068     -2.5445064902305603e-01
    z[6,5,6]  R2069     -4.7143781185150146e-01
    z[6,5,6]  R2070     -9.0329416096210480e-02
    z[6,5,6]  R2071     1.9213742017745972e-01
    z[6,5,6]  R2072     -7.5371921062469482e-02
    z[6,5,6]  R2073     -3.1680127978324890e-01
    z[6,5,6]  R2074     -4.6352922916412354e-01
    z[6,5,6]  R2075     3.8438599556684494e-02
    z[6,5,6]  R2076     0.261014848947525
    z[6,5,6]  R2077     4.8334154486656189e-01
    z[6,5,6]  R2078     1.1818795651197433e-01
    z[6,5,6]  R2079     8.3051025867462158e-01
    z[6,5,6]  R2080     8.5704708099365234e-01
    z[6,5,6]  R2081     0.682844340801239
    z[6,5,6]  R2082     5.7665061950683594e-01
    z[6,5,6]  R2083     7.2481536865234375e-01
    z[6,5,6]  R2084     4.0211758017539978e-01
    z[6,5,6]  R2085     -9.5372155308723450e-02
    z[6,5,6]  R2086     2.1879369020462036e-01
    z[6,5,6]  R2087     2.6650199294090271e-01
    z[6,5,6]  R2088     5.8533376455307007e-01
    z[6,5,6]  R2089     3.7827339768409729e-01
    z[6,5,6]  R2090     -3.6520313471555710e-02
    z[6,5,6]  R2091     -0.000860060506965965
    z[6,5,6]  R2092     1.8904957175254822e-01
    z[6,5,6]  R2093     2.2808564826846123e-02
    z[6,5,6]  R2094     -8.3424195647239685e-02
    z[6,5,6]  R2095     1.7950646579265594e-02
    z[6,5,6]  R2096     4.2042294144630432e-01
    z[6,5,6]  R2097     -1.0060324519872665e-01
    z[6,5,6]  R2098     1.8184538930654526e-02
    z[6,5,6]  R2099     2.5367733836174011e-01
    z[6,5,6]  R2100     1.5950077772140503e-01
    z[6,5,6]  R2101     -3.7078243494033813e-01
    z[6,5,6]  R2102     -1.3133244216442108e-01
    z[6,5,6]  R2103     -4.3709173798561096e-02
    z[6,5,6]  R2104     0.423032283782959
    z[6,5,6]  R2105     1.6708987951278687e-01
    z[6,5,6]  R2106     3.0549925565719604e-01
    z[6,5,6]  R2107     -1.5334303677082062e-01
    z[6,5,6]  R2108     -3.6709284782409668e-01
    z[6,5,6]  R2109     1.2286590039730072e-01
    z[6,5,6]  R2110     -6.7497797310352325e-02
    z[6,5,6]  R2111     3.1256254762411118e-02
    z[6,5,6]  R2112     2.6256346702575684e-01
    z[6,5,6]  R2113     4.8001569509506226e-01
    z[6,5,6]  R2114     4.7469669580459595e-01
    z[6,5,6]  R2115     3.9829116314649582e-02
    z[6,5,6]  R2116     2.2275516390800476e-01
    z[6,5,6]  R2117     -4.2748800478875637e-04
    z[6,5,6]  R2118     -8.9473381638526917e-02
    z[6,5,6]  R2119     9.4732828438282013e-02
    z[6,5,6]  R2120     6.1027163267135620e-01
    z[6,5,6]  R2121     1.5876251459121704e-01
    z[6,5,6]  R2122     3.3920636773109436e-01
    z[6,5,6]  R2123     1.4114594459533691e-01
    z[6,5,6]  R2124     2.1262085065245628e-02
    z[6,5,6]  R2125     -4.5625671744346619e-01
    z[6,5,6]  R2126     -1.3936492800712585e-01
    z[6,5,6]  R2127     -3.1722703576087952e-01
    z[6,5,6]  R2128     0.0425274521112442
    z[6,5,6]  R2129     -3.0511155724525452e-01
    z[6,5,6]  R2130     -3.8313925266265869e-01
    z[6,5,6]  R2131     3.6319881677627563e-01
    z[6,5,6]  R2132     0.387690931558609
    z[6,5,6]  R2133     -3.0640125274658203e-01
    z[6,5,6]  R2134     0.471548467874527
    z[6,5,6]  R2135     -1.3050666451454163e-01
    z[6,5,6]  R2136     -3.6141178011894226e-01
    z[6,5,6]  R2137     3.1543749570846558e-01
    z[6,5,6]  R2138     -5.5901497602462769e-01
    z[6,5,6]  R2139     6.1622675508260727e-02
    z[6,5,6]  R2140     3.1740683317184448e-01
    z[6,5,6]  R2141     -1.1058255285024643e-01
    z[6,5,6]  R2142     6.2087923288345337e-02
    z[6,5,6]  R2143     1.9308309257030487e-01
    z[6,5,6]  R2144     3.9245107769966125e-01
    z[6,5,6]  R2145     1.9526550173759460e-01
    z[6,5,6]  R2146     1.5403334796428680e-01
    z[6,5,6]  R2147     1.1634574830532074e-01
    z[6,5,6]  R2148     1.6607512533664703e-01
    z[6,5,6]  R2149     4.3586143851280212e-01
    z[6,5,6]  R2150     6.7124205827713013e-01
    z[6,5,6]  R2151     2.3354444652795792e-02
    z[6,5,6]  R2152     0.0557732991874218
    z[6,5,6]  R2153     -1.7011800408363342e-01
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R2154     -1
    z[6,7,0]  R2155     1
    z[6,7,0]  R2168     -1.8632820248603821e-01
    z[6,7,0]  R2169     -4.7465452551841736e-01
    z[6,7,0]  R2170     4.3792444467544556e-01
    z[6,7,0]  R2171     3.8235524296760559e-01
    z[6,7,0]  R2172     3.7346342206001282e-01
    z[6,7,0]  R2173     6.3119995594024658e-01
    z[6,7,0]  R2174     3.2929986715316772e-01
    z[6,7,0]  R2175     1.5928198397159576e-01
    z[6,7,0]  R2176     6.0713529586791992e-01
    z[6,7,0]  R2177     3.4094351530075073e-01
    z[6,7,0]  R2178     -0.58119797706604
    z[6,7,0]  R2179     3.0131638050079346e-02
    z[6,7,0]  R2180     -1.4204809069633484e-01
    z[6,7,0]  R2181     -6.5065003931522369e-02
    z[6,7,0]  R2182     -3.1800848245620728e-01
    z[6,7,0]  R2183     -4.2569833993911743e-01
    z[6,7,0]  R2184     -3.5634589195251465e-01
    z[6,7,0]  R2185     3.0663952231407166e-01
    z[6,7,0]  R2186     2.5091221928596497e-01
    z[6,7,0]  R2187     -5.2162152528762817e-01
    z[6,7,0]  R2188     -3.3429333567619324e-01
    z[6,7,0]  R2189     -2.3331068456172943e-01
    z[6,7,0]  R2190     3.7231542170047760e-02
    z[6,7,0]  R2191     2.4421063065528870e-01
    z[6,7,0]  R2192     4.2844238877296448e-01
    z[6,7,0]  R2193     5.3521293401718140e-01
    z[6,7,0]  R2194     3.9225590229034424e-01
    z[6,7,0]  R2195     5.9769493341445923e-01
    z[6,7,0]  R2196     4.0260460972785950e-01
    z[6,7,0]  R2197     -1.4065428078174591e-01
    z[6,7,0]  R2198     2.9243695735931396e-01
    z[6,7,0]  R2199     7.3771692812442780e-02
    z[6,7,0]  R2200     2.5312933325767517e-01
    z[6,7,0]  R2201     6.3629776239395142e-01
    z[6,7,0]  R2202     0.184300035238266
    z[6,7,0]  R2203     -1.8647179007530212e-01
    z[6,7,0]  R2204     3.7628549337387085e-01
    z[6,7,0]  R2205     2.8730541467666626e-01
    z[6,7,0]  R2206     8.5978329181671143e-02
    z[6,7,0]  R2207     0.509591281414032
    z[6,7,0]  R2208     -5.9725429862737656e-02
    z[6,7,0]  R2209     3.3289736509323120e-01
    z[6,7,0]  R2210     0.533287525177002
    z[6,7,0]  R2211     -6.6896595060825348e-02
    z[6,7,0]  R2212     3.0792000889778137e-01
    z[6,7,0]  R2213     2.2734439373016357e-01
    z[6,7,0]  R2214     6.3056498765945435e-01
    z[6,7,0]  R2215     -1.6158511862158775e-02
    z[6,7,0]  R2216     6.9024398922920227e-02
    z[6,7,0]  R2217     3.2530412077903748e-01
    z[6,7,0]  R2218     -1.7556053400039673e-01
    z[6,7,0]  R2219     4.3240612745285034e-01
    z[6,7,0]  R2220     -3.0810329318046570e-01
    z[6,7,0]  R2221     -9.9450044333934784e-02
    z[6,7,0]  R2222     2.9956212639808655e-01
    z[6,7,0]  R2223     4.4328609108924866e-01
    z[6,7,0]  R2224     -2.0548477768898010e-02
    z[6,7,0]  R2225     -5.0517898797988892e-01
    z[6,7,0]  R2226     -3.6625093221664429e-01
    z[6,7,0]  R2227     -2.4710388481616974e-01
    z[6,7,0]  R2228     6.2022256851196289e-01
    z[6,7,0]  R2229     6.1659902334213257e-01
    z[6,7,0]  R2230     2.9703339934349060e-01
    z[6,7,0]  R2231     5.4968541860580444e-01
    z[6,7,0]  R2232     6.3667088747024536e-01
    z[6,7,0]  R2233     0.882612943649292
    z[6,7,0]  R2234     -1.4130641520023346e-01
    z[6,7,0]  R2235     8.2938581705093384e-01
    z[6,7,0]  R2236     7.5897300243377686e-01
    z[6,7,0]  R2237     4.2012134194374084e-01
    z[6,7,0]  R2238     -4.9780672788619995e-01
    z[6,7,0]  R2239     -0.572464108467102
    z[6,7,0]  R2240     -4.3742641806602478e-01
    z[6,7,0]  R2241     -3.2142275571823120e-01
    z[6,7,0]  R2242     -1.9069717824459076e-01
    z[6,7,0]  R2243     -3.6926296353340149e-01
    z[6,7,0]  R2244     -2.0503515005111694e-01
    z[6,7,0]  R2245     -0.310046523809433
    z[6,7,0]  R2246     -4.1690936684608459e-01
    z[6,7,0]  R2247     -3.7215346097946167e-01
    z[6,7,0]  R2248     -3.3932819962501526e-01
    z[6,7,0]  R2249     -3.5454162955284119e-01
    z[6,7,0]  R2250     -4.4399699568748474e-01
    z[6,7,0]  R2251     -2.4433828890323639e-01
    z[6,7,0]  R2252     -3.5885170102119446e-01
    z[6,7,0]  R2253     -3.3633485436439514e-01
    z[6,7,0]  R2254     -2.3008981347084045e-01
    z[6,7,0]  R2255     -7.2591103613376617e-02
    z[6,7,0]  R2256     -1.1461601406335831e-01
    z[6,7,0]  R2257     -4.6189066767692566e-01
    z[6,7,0]  R2258     7.5222015380859375e-01
    z[6,7,0]  R2259     -1.1398845165967941e-01
    z[6,7,0]  R2260     9.3784838914871216e-02
    z[6,7,0]  R2261     -2.6202374696731567e-01
    z[6,7,0]  R2262     5.2261631935834885e-02
    z[6,7,0]  R2263     -6.1903566122055054e-02
    z[6,7,0]  R2264     -4.6527091413736343e-02
    z[6,7,0]  R2265     -3.9346495270729065e-01
    z[6,7,0]  R2266     -2.1216526627540588e-01
    z[6,7,0]  R2267     -0.501543402671814
    z[6,7,0]  R2268     -4.9204930663108826e-02
    z[6,7,0]  R2269     -1.2464704364538193e-01
    z[6,7,0]  R2270     2.2177331149578094e-01
    z[6,7,0]  R2271     -4.3282747268676758e-02
    z[6,7,0]  R2272     -3.5235892981290817e-02
    z[6,7,0]  R2273     2.0288916304707527e-02
    z[6,7,0]  R2274     -2.7766540646553040e-01
    z[6,7,0]  R2275     -3.0240246653556824e-01
    z[6,7,0]  R2276     -2.4311359226703644e-01
    z[6,7,0]  R2277     2.4615408480167389e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R2156     -1
    z[6,7,1]  R2157     1
    z[6,7,1]  R2168     6.1064338684082031e-01
    z[6,7,1]  R2169     6.2450957298278809e-01
    z[6,7,1]  R2170     5.7998287677764893e-01
    z[6,7,1]  R2171     4.0597015619277954e-01
    z[6,7,1]  R2172     6.3167077302932739e-01
    z[6,7,1]  R2173     -0.530769944190979
    z[6,7,1]  R2174     -8.4959131479263306e-01
    z[6,7,1]  R2175     3.1109875440597534e-01
    z[6,7,1]  R2176     -5.5505788326263428e-01
    z[6,7,1]  R2177     7.6115798950195312e-01
    z[6,7,1]  R2178     6.7412899807095528e-03
    z[6,7,1]  R2179     -4.3777039647102356e-01
    z[6,7,1]  R2180     -1.1569716967642307e-02
    z[6,7,1]  R2181     5.7042874395847321e-03
    z[6,7,1]  R2182     -1.0769910365343094e-01
    z[6,7,1]  R2183     -0.089664988219738
    z[6,7,1]  R2184     -4.7049908898770809e-03
    z[6,7,1]  R2185     -7.8689880669116974e-02
    z[6,7,1]  R2186     5.3881829977035522e-01
    z[6,7,1]  R2187     -7.2857844829559326e-01
    z[6,7,1]  R2188     2.4562025070190430e-01
    z[6,7,1]  R2189     3.5549721121788025e-01
    z[6,7,1]  R2190     7.6754844188690186e-01
    z[6,7,1]  R2191     7.3900038003921509e-01
    z[6,7,1]  R2192     0.700786292552948
    z[6,7,1]  R2193     1.5757998824119568e-01
    z[6,7,1]  R2194     -6.3820332288742065e-01
    z[6,7,1]  R2195     -7.3525291681289673e-01
    z[6,7,1]  R2196     1.3339456915855408e-01
    z[6,7,1]  R2197     5.8279263973236084e-01
    z[6,7,1]  R2198     7.5469082593917847e-01
    z[6,7,1]  R2199     7.2485476732254028e-01
    z[6,7,1]  R2200     0.859340250492096
    z[6,7,1]  R2201     -3.5345073789358139e-02
    z[6,7,1]  R2202     -3.5264518857002258e-01
    z[6,7,1]  R2203     -6.0123950242996216e-01
    z[6,7,1]  R2204     -2.7305385470390320e-01
    z[6,7,1]  R2205     -0.696918249130249
    z[6,7,1]  R2206     -5.3487861156463623e-01
    z[6,7,1]  R2207     -5.9835082292556763e-01
    z[6,7,1]  R2208     7.0404177904129028e-01
    z[6,7,1]  R2209     1.4636141061782837e-01
    z[6,7,1]  R2210     3.5103011131286621e-01
    z[6,7,1]  R2211     -3.7472493946552277e-02
    z[6,7,1]  R2212     -5.2194631099700928e-01
    z[6,7,1]  R2213     -6.3355344533920288e-01
    z[6,7,1]  R2214     -4.7664853930473328e-01
    z[6,7,1]  R2215     -5.6076383590698242e-01
    z[6,7,1]  R2216     -7.4455153942108154e-01
    z[6,7,1]  R2217     -7.7789926528930664e-01
    z[6,7,1]  R2218     -2.2095529362559319e-02
    z[6,7,1]  R2219     -7.4164569377899170e-01
    z[6,7,1]  R2220     7.3182427883148193e-01
    z[6,7,1]  R2221     6.3839703798294067e-01
    z[6,7,1]  R2222     -0.833806574344635
    z[6,7,1]  R2223     -4.0060380101203918e-01
    z[6,7,1]  R2224     -7.9504323005676270e-01
    z[6,7,1]  R2225     -0.525545597076416
    z[6,7,1]  R2226     -5.5992990732192993e-01
    z[6,7,1]  R2227     -0.585119366645813
    z[6,7,1]  R2228     -5.7872150093317032e-02
    z[6,7,1]  R2229     -5.1282203197479248e-01
    z[6,7,1]  R2230     0.0262064840644598
    z[6,7,1]  R2231     3.6335122585296631e-01
    z[6,7,1]  R2232     -1.6931580007076263e-01
    z[6,7,1]  R2233     -0.329165518283844
    z[6,7,1]  R2234     -0.0679888054728508
    z[6,7,1]  R2235     -2.3425427079200745e-01
    z[6,7,1]  R2236     -2.3805886507034302e-01
    z[6,7,1]  R2237     -4.3429568409919739e-01
    z[6,7,1]  R2238     -8.1585150957107544e-01
    z[6,7,1]  R2239     -0.80653977394104
    z[6,7,1]  R2240     -7.6596271991729736e-01
    z[6,7,1]  R2241     -7.6712471246719360e-01
    z[6,7,1]  R2242     -7.3575627803802490e-01
    z[6,7,1]  R2243     -6.4961183071136475e-01
    z[6,7,1]  R2244     -7.3032897710800171e-01
    z[6,7,1]  R2245     -6.7524188756942749e-01
    z[6,7,1]  R2246     -6.3695675134658813e-01
    z[6,7,1]  R2247     -7.0628565549850464e-01
    z[6,7,1]  R2248     8.0494111776351929e-01
    z[6,7,1]  R2249     7.4577414989471436e-01
    z[6,7,1]  R2250     6.8204289674758911e-01
    z[6,7,1]  R2251     8.3312731981277466e-01
    z[6,7,1]  R2252     0.872372567653656
    z[6,7,1]  R2253     0.892861545085907
    z[6,7,1]  R2254     8.3846324682235718e-01
    z[6,7,1]  R2255     8.3353638648986816e-01
    z[6,7,1]  R2256     8.3021491765975952e-01
    z[6,7,1]  R2257     8.0449211597442627e-01
    z[6,7,1]  R2258     1.4912796206772327e-02
    z[6,7,1]  R2259     -1.4350967109203339e-01
    z[6,7,1]  R2260     0.515442430973053
    z[6,7,1]  R2261     -7.1135634183883667e-01
    z[6,7,1]  R2262     7.3089694976806641e-01
    z[6,7,1]  R2263     7.0023673772811890e-01
    z[6,7,1]  R2264     7.3360109329223633e-01
    z[6,7,1]  R2265     3.8575199246406555e-01
    z[6,7,1]  R2266     6.1126559972763062e-01
    z[6,7,1]  R2267     3.4472337365150452e-01
    z[6,7,1]  R2268     -8.0631360411643982e-02
    z[6,7,1]  R2269     2.0715110003948212e-01
    z[6,7,1]  R2270     7.0760160684585571e-01
    z[6,7,1]  R2271     8.5351544618606567e-01
    z[6,7,1]  R2272     -7.6736605167388916e-01
    z[6,7,1]  R2273     -7.7822124958038330e-01
    z[6,7,1]  R2274     4.3269225955009460e-01
    z[6,7,1]  R2275     2.9408836364746094e-01
    z[6,7,1]  R2276     4.7195664048194885e-01
    z[6,7,1]  R2277     6.2477678060531616e-01
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R2158     -1
    z[6,7,2]  R2159     1
    z[6,7,2]  R2168     -0.332560658454895
    z[6,7,2]  R2169     5.3895749151706696e-02
    z[6,7,2]  R2170     -0.286003977060318
    z[6,7,2]  R2171     -3.4214845299720764e-01
    z[6,7,2]  R2172     -1.1339093744754791e-01
    z[6,7,2]  R2173     4.0346592664718628e-01
    z[6,7,2]  R2174     1.7034868896007538e-01
    z[6,7,2]  R2175     -2.1381275728344917e-02
    z[6,7,2]  R2176     2.2181870043277740e-01
    z[6,7,2]  R2177     4.7923141717910767e-01
    z[6,7,2]  R2178     -6.5385691821575165e-02
    z[6,7,2]  R2179     -1.6888666152954102e-01
    z[6,7,2]  R2180     -2.2791191935539246e-02
    z[6,7,2]  R2181     -2.2853022813796997e-01
    z[6,7,2]  R2182     -7.1053137071430683e-03
    z[6,7,2]  R2183     1.4190416038036346e-01
    z[6,7,2]  R2184     1.5632751584053040e-01
    z[6,7,2]  R2185     -5.2995961904525757e-01
    z[6,7,2]  R2186     -3.7402606103569269e-03
    z[6,7,2]  R2187     -4.1265211999416351e-02
    z[6,7,2]  R2188     -2.1572384238243103e-01
    z[6,7,2]  R2189     -2.1186050772666931e-01
    z[6,7,2]  R2190     -1.3898000121116638e-01
    z[6,7,2]  R2191     -1.4530846476554871e-01
    z[6,7,2]  R2192     -3.7960830330848694e-01
    z[6,7,2]  R2193     -6.3927090167999268e-01
    z[6,7,2]  R2194     4.3904027342796326e-01
    z[6,7,2]  R2195     -3.5784412175416946e-02
    z[6,7,2]  R2196     -3.6239191889762878e-01
    z[6,7,2]  R2197     2.3358710110187531e-02
    z[6,7,2]  R2198     -2.5001293420791626e-01
    z[6,7,2]  R2199     2.6127649471163750e-02
    z[6,7,2]  R2200     1.0452125966548920e-01
    z[6,7,2]  R2201     -4.8448723554611206e-01
    z[6,7,2]  R2202     -0.420459121465683
    z[6,7,2]  R2203     7.3230654001235962e-01
    z[6,7,2]  R2204     5.0593322515487671e-01
    z[6,7,2]  R2205     2.6776370406150818e-01
    z[6,7,2]  R2206     6.8941169977188110e-01
    z[6,7,2]  R2207     2.4605287611484528e-01
    z[6,7,2]  R2208     3.3118776977062225e-02
    z[6,7,2]  R2209     -3.0750176310539246e-01
    z[6,7,2]  R2210     -5.9830981492996216e-01
    z[6,7,2]  R2211     -2.7669641375541687e-01
    z[6,7,2]  R2212     7.7833157777786255e-01
    z[6,7,2]  R2213     4.6662944555282593e-01
    z[6,7,2]  R2214     2.5457486510276794e-01
    z[6,7,2]  R2215     5.6163430213928223e-01
    z[6,7,2]  R2216     4.7519233822822571e-01
    z[6,7,2]  R2217     9.7652181982994080e-02
    z[6,7,2]  R2218     -2.4107088148593903e-01
    z[6,7,2]  R2219     2.7117297053337097e-01
    z[6,7,2]  R2220     1.0942734032869339e-01
    z[6,7,2]  R2221     2.2474190592765808e-01
    z[6,7,2]  R2222     2.4390894174575806e-01
    z[6,7,2]  R2223     3.5541704297065735e-01
    z[6,7,2]  R2224     3.6890363693237305e-01
    z[6,7,2]  R2225     3.4448531270027161e-01
    z[6,7,2]  R2226     -5.2785462141036987e-01
    z[6,7,2]  R2227     -5.2000045776367188e-01
    z[6,7,2]  R2228     4.7265261411666870e-01
    z[6,7,2]  R2229     1.7059187591075897e-01
    z[6,7,2]  R2230     2.7126777172088623e-01
    z[6,7,2]  R2231     1.5518426895141602e-01
    z[6,7,2]  R2232     1.0871021449565887e-01
    z[6,7,2]  R2233     -6.2821321189403534e-02
    z[6,7,2]  R2234     6.1464405059814453e-01
    z[6,7,2]  R2235     -3.1405130028724670e-01
    z[6,7,2]  R2236     1.7545676231384277e-01
    z[6,7,2]  R2237     -8.9660741388797760e-02
    z[6,7,2]  R2238     8.6172811686992645e-02
    z[6,7,2]  R2239     -6.2457986176013947e-02
    z[6,7,2]  R2240     2.3516632616519928e-01
    z[6,7,2]  R2241     -7.1627877652645111e-02
    z[6,7,2]  R2242     2.6620075106620789e-02
    z[6,7,2]  R2243     2.4896752834320068e-01
    z[6,7,2]  R2244     7.0647731423377991e-02
    z[6,7,2]  R2245     -4.3897065520286560e-01
    z[6,7,2]  R2246     -2.5264355540275574e-01
    z[6,7,2]  R2247     -3.8364082574844360e-01
    z[6,7,2]  R2248     3.7506440281867981e-01
    z[6,7,2]  R2249     4.0297257900238037e-01
    z[6,7,2]  R2250     2.5528374314308167e-01
    z[6,7,2]  R2251     1.5336585044860840e-01
    z[6,7,2]  R2252     1.8986490368843079e-01
    z[6,7,2]  R2253     9.0302256867289543e-03
    z[6,7,2]  R2254     2.9375827312469482e-01
    z[6,7,2]  R2255     3.5538288950920105e-01
    z[6,7,2]  R2256     4.1185724735260010e-01
    z[6,7,2]  R2257     -7.0786923170089722e-02
    z[6,7,2]  R2258     -2.2646564990282059e-02
    z[6,7,2]  R2259     4.0609481930732727e-01
    z[6,7,2]  R2260     5.4534208774566650e-01
    z[6,7,2]  R2261     -2.2798979282379150e-01
    z[6,7,2]  R2262     -2.6518395543098450e-01
    z[6,7,2]  R2263     5.8104771375656128e-01
    z[6,7,2]  R2264     0.125529944896698
    z[6,7,2]  R2265     -1.5523053705692291e-01
    z[6,7,2]  R2266     -7.1677933447062969e-03
    z[6,7,2]  R2267     -1.0918294638395309e-01
    z[6,7,2]  R2268     0.0843895822763443
    z[6,7,2]  R2269     1.9237776100635529e-01
    z[6,7,2]  R2270     3.7106525897979736e-01
    z[6,7,2]  R2271     2.9694685339927673e-01
    z[6,7,2]  R2272     4.4253346323966980e-01
    z[6,7,2]  R2273     -2.8792685270309448e-01
    z[6,7,2]  R2274     7.1017062664031982e-01
    z[6,7,2]  R2275     -3.3727708458900452e-01
    z[6,7,2]  R2276     -3.5415071249008179e-01
    z[6,7,2]  R2277     -3.4223309159278870e-01
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R2160     -1
    z[6,7,3]  R2161     1
    z[6,7,3]  R2168     3.5337468981742859e-01
    z[6,7,3]  R2169     4.3186199665069580e-01
    z[6,7,3]  R2170     1.8458463251590729e-01
    z[6,7,3]  R2171     2.2620768845081329e-01
    z[6,7,3]  R2172     1.8109650909900665e-01
    z[6,7,3]  R2173     -2.5153917074203491e-01
    z[6,7,3]  R2174     -1.2930953502655029e-01
    z[6,7,3]  R2175     3.0619335174560547e-01
    z[6,7,3]  R2176     -3.3659148216247559e-01
    z[6,7,3]  R2177     -3.5887490957975388e-02
    z[6,7,3]  R2178     3.4116572141647339e-01
    z[6,7,3]  R2179     8.2048797607421875e-01
    z[6,7,3]  R2180     4.4180014729499817e-01
    z[6,7,3]  R2181     4.1915854811668396e-01
    z[6,7,3]  R2182     4.9153622984886169e-01
    z[6,7,3]  R2183     4.2627230286598206e-01
    z[6,7,3]  R2184     4.0830591320991516e-01
    z[6,7,3]  R2185     6.4769697189331055e-01
    z[6,7,3]  R2186     -7.5049948692321777e-01
    z[6,7,3]  R2187     2.2613897919654846e-02
    z[6,7,3]  R2188     7.7779656648635864e-01
    z[6,7,3]  R2189     6.5645754337310791e-01
    z[6,7,3]  R2190     -3.5414823889732361e-01
    z[6,7,3]  R2191     -5.1127409934997559e-01
    z[6,7,3]  R2192     -2.2181639075279236e-01
    z[6,7,3]  R2193     2.6468244194984436e-01
    z[6,7,3]  R2194     4.1745647788047791e-01
    z[6,7,3]  R2195     1.5547877550125122e-01
    z[6,7,3]  R2196     4.1459989547729492e-01
    z[6,7,3]  R2197     -3.7872564792633057e-01
    z[6,7,3]  R2198     2.4027393758296967e-01
    z[6,7,3]  R2199     1.0182113945484161e-01
    z[6,7,3]  R2200     -2.2627657651901245e-01
    z[6,7,3]  R2201     4.8898467421531677e-01
    z[6,7,3]  R2202     6.5773159265518188e-01
    z[6,7,3]  R2203     -1.5517678111791611e-02
    z[6,7,3]  R2204     2.0188668370246887e-01
    z[6,7,3]  R2205     -1.9222943484783173e-01
    z[6,7,3]  R2206     -3.4604352712631226e-01
    z[6,7,3]  R2207     0.0963834673166275
    z[6,7,3]  R2208     3.7108927965164185e-01
    z[6,7,3]  R2209     6.3011771440505981e-01
    z[6,7,3]  R2210     2.7485069632530212e-01
    z[6,7,3]  R2211     5.0760430097579956e-01
    z[6,7,3]  R2212     1.0954966396093369e-01
    z[6,7,3]  R2213     -5.5873099714517593e-02
    z[6,7,3]  R2214     1.5161101520061493e-01
    z[6,7,3]  R2215     -8.6972750723361969e-02
    z[6,7,3]  R2216     0.0417293980717659
    z[6,7,3]  R2217     -2.2500304877758026e-01
    z[6,7,3]  R2218     5.8091831207275391e-01
    z[6,7,3]  R2219     1.0255575180053711e-01
    z[6,7,3]  R2220     -4.7698262333869934e-01
    z[6,7,3]  R2221     -2.8177621960639954e-01
    z[6,7,3]  R2222     -1.8471600487828255e-02
    z[6,7,3]  R2223     8.3505949005484581e-03
    z[6,7,3]  R2224     1.7427420616149902e-01
    z[6,7,3]  R2225     -3.5285431146621704e-01
    z[6,7,3]  R2226     -0.129202738404274
    z[6,7,3]  R2227     -1.6438604891300201e-01
    z[6,7,3]  R2228     0.564596951007843
    z[6,7,3]  R2229     5.1371496915817261e-01
    z[6,7,3]  R2230     6.0861396789550781e-01
    z[6,7,3]  R2231     6.4744567871093750e-01
    z[6,7,3]  R2232     5.3467601537704468e-01
    z[6,7,3]  R2233     2.5986871123313904e-01
    z[6,7,3]  R2234     6.7782843112945557e-01
    z[6,7,3]  R2235     2.3131449520587921e-01
    z[6,7,3]  R2236     1.5036433935165405e-01
    z[6,7,3]  R2237     0.316175639629364
    z[6,7,3]  R2238     -1.6702687740325928e-01
    z[6,7,3]  R2239     -2.5385264307260513e-02
    z[6,7,3]  R2240     0.131901815533638
    z[6,7,3]  R2241     -4.6181580424308777e-01
    z[6,7,3]  R2242     -5.9974139928817749e-01
    z[6,7,3]  R2243     -1.7495591938495636e-01
    z[6,7,3]  R2244     -2.9178082942962646e-01
    z[6,7,3]  R2245     -2.7795532345771790e-01
    z[6,7,3]  R2246     -4.1714288294315338e-02
    z[6,7,3]  R2247     4.8548586666584015e-02
    z[6,7,3]  R2248     -1.4104346930980682e-01
    z[6,7,3]  R2249     -3.3874134533107281e-03
    z[6,7,3]  R2250     2.5828611850738525e-01
    z[6,7,3]  R2251     -1.5882736444473267e-01
    z[6,7,3]  R2252     -0.0272738728672266
    z[6,7,3]  R2253     -8.0274511128664017e-03
    z[6,7,3]  R2254     -1.7618638277053833e-01
    z[6,7,3]  R2255     3.0444784089922905e-02
    z[6,7,3]  R2256     -2.2624140977859497e-01
    z[6,7,3]  R2257     1.8799732625484467e-01
    z[6,7,3]  R2258     5.5978453159332275e-01
    z[6,7,3]  R2259     5.4143774509429932e-01
    z[6,7,3]  R2260     3.4446281194686890e-01
    z[6,7,3]  R2261     -4.4442677497863770e-01
    z[6,7,3]  R2262     4.7526496648788452e-01
    z[6,7,3]  R2263     2.1938085556030273e-01
    z[6,7,3]  R2264     5.9873424470424652e-03
    z[6,7,3]  R2265     5.9109628200531006e-01
    z[6,7,3]  R2266     2.5889626145362854e-01
    z[6,7,3]  R2267     7.3483932018280029e-01
    z[6,7,3]  R2268     9.8674345016479492e-01
    z[6,7,3]  R2269     9.4138717651367188e-01
    z[6,7,3]  R2270     4.4672787189483643e-01
    z[6,7,3]  R2271     1.3829560577869415e-01
    z[6,7,3]  R2272     -3.0289649963378906e-01
    z[6,7,3]  R2273     1.8216690421104431e-01
    z[6,7,3]  R2274     1.1730867624282837e-01
    z[6,7,3]  R2275     -7.7046173810958862e-01
    z[6,7,3]  R2276     -6.0686582326889038e-01
    z[6,7,3]  R2277     -6.3158321380615234e-01
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R2162     -1
    z[6,7,4]  R2163     1
    z[6,7,4]  R2168     -3.4659796953201294e-01
    z[6,7,4]  R2169     3.3483055233955383e-01
    z[6,7,4]  R2170     3.1140258908271790e-01
    z[6,7,4]  R2171     -3.9982533454895020e-01
    z[6,7,4]  R2172     4.1108959913253784e-01
    z[6,7,4]  R2173     -0.195590078830719
    z[6,7,4]  R2174     9.4385646283626556e-02
    z[6,7,4]  R2175     3.3273950219154358e-02
    z[6,7,4]  R2176     9.0568356215953827e-02
    z[6,7,4]  R2177     -2.3985737934708595e-02
    z[6,7,4]  R2178     -3.5591992735862732e-01
    z[6,7,4]  R2179     2.5977367162704468e-01
    z[6,7,4]  R2180     2.9617208242416382e-01
    z[6,7,4]  R2181     -1.1050403863191605e-01
    z[6,7,4]  R2182     -3.1300392746925354e-01
    z[6,7,4]  R2183     -2.9831424355506897e-01
    z[6,7,4]  R2184     -0.078194260597229
    z[6,7,4]  R2185     1.1277345009148121e-02
    z[6,7,4]  R2186     1.0195134673267603e-03
    z[6,7,4]  R2187     -3.1593844294548035e-01
    z[6,7,4]  R2188     -2.6771211624145508e-01
    z[6,7,4]  R2189     -2.4543073028326035e-02
    z[6,7,4]  R2190     -8.8862076401710510e-02
    z[6,7,4]  R2191     4.9440383911132812e-02
    z[6,7,4]  R2192     8.7021633982658386e-02
    z[6,7,4]  R2193     -4.5874398201704025e-02
    z[6,7,4]  R2194     -2.4660360813140869e-01
    z[6,7,4]  R2195     -2.5803777575492859e-01
    z[6,7,4]  R2196     0.629653811454773
    z[6,7,4]  R2197     -0.547412633895874
    z[6,7,4]  R2198     4.6226152777671814e-01
    z[6,7,4]  R2199     1.1981938965618610e-02
    z[6,7,4]  R2200     -2.6193103194236755e-01
    z[6,7,4]  R2201     3.0385696887969971e-01
    z[6,7,4]  R2202     1.1363150179386139e-01
    z[6,7,4]  R2203     1.7030476033687592e-01
    z[6,7,4]  R2204     5.3682446479797363e-02
    z[6,7,4]  R2205     2.6475310325622559e-01
    z[6,7,4]  R2206     0.278982013463974
    z[6,7,4]  R2207     4.0647217631340027e-01
    z[6,7,4]  R2208     4.2472994327545166e-01
    z[6,7,4]  R2209     1.4618931710720062e-01
    z[6,7,4]  R2210     -3.5961541533470154e-01
    z[6,7,4]  R2211     4.2954066395759583e-01
    z[6,7,4]  R2212     3.2832890748977661e-02
    z[6,7,4]  R2213     5.0434535741806030e-01
    z[6,7,4]  R2214     2.0872655510902405e-01
    z[6,7,4]  R2215     -1.1626593023538589e-01
    z[6,7,4]  R2216     3.2564330101013184e-01
    z[6,7,4]  R2217     -4.9502965062856674e-02
    z[6,7,4]  R2218     3.9730608463287354e-01
    z[6,7,4]  R2219     3.4764197468757629e-01
    z[6,7,4]  R2220     -2.4281549453735352e-01
    z[6,7,4]  R2221     1.3374213874340057e-01
    z[6,7,4]  R2222     6.1575431376695633e-02
    z[6,7,4]  R2223     3.3057440072298050e-02
    z[6,7,4]  R2224     -2.0564597100019455e-02
    z[6,7,4]  R2225     4.4731184840202332e-01
    z[6,7,4]  R2226     2.1267350018024445e-01
    z[6,7,4]  R2227     4.2725142836570740e-01
    z[6,7,4]  R2228     2.0796653628349304e-01
    z[6,7,4]  R2229     -8.3512617275118828e-03
    z[6,7,4]  R2230     -3.1630811095237732e-01
    z[6,7,4]  R2231     2.0905961096286774e-01
    z[6,7,4]  R2232     -6.8013528361916542e-03
    z[6,7,4]  R2233     1.6189047694206238e-01
    z[6,7,4]  R2234     -1.0302327573299408e-01
    z[6,7,4]  R2235     -1.0839579254388809e-01
    z[6,7,4]  R2236     -1.7145258188247681e-01
    z[6,7,4]  R2237     1.2915735132992268e-02
    z[6,7,4]  R2238     -1.1437698453664780e-01
    z[6,7,4]  R2239     -9.7949914634227753e-02
    z[6,7,4]  R2240     2.2429913282394409e-01
    z[6,7,4]  R2241     1.3347357511520386e-01
    z[6,7,4]  R2242     1.7241925001144409e-01
    z[6,7,4]  R2243     2.1686582267284393e-01
    z[6,7,4]  R2244     2.4941425025463104e-01
    z[6,7,4]  R2245     -3.8916151970624924e-03
    z[6,7,4]  R2246     -8.5312649607658386e-02
    z[6,7,4]  R2247     8.5909456014633179e-02
    z[6,7,4]  R2248     1.0042832791805267e-01
    z[6,7,4]  R2249     8.7373502552509308e-02
    z[6,7,4]  R2250     -3.3058132976293564e-02
    z[6,7,4]  R2251     -1.4715763926506042e-01
    z[6,7,4]  R2252     8.5299901664257050e-02
    z[6,7,4]  R2253     -7.5718536972999573e-02
    z[6,7,4]  R2254     2.3704622685909271e-01
    z[6,7,4]  R2255     2.5284444913268089e-02
    z[6,7,4]  R2256     5.5912379175424576e-03
    z[6,7,4]  R2257     -2.6069596409797668e-01
    z[6,7,4]  R2258     -0.0194578655064106
    z[6,7,4]  R2259     -3.4772194921970367e-02
    z[6,7,4]  R2260     -2.1263534203171730e-02
    z[6,7,4]  R2261     1.5456782281398773e-01
    z[6,7,4]  R2262     -2.1729257702827454e-01
    z[6,7,4]  R2263     3.4007257223129272e-01
    z[6,7,4]  R2264     -3.5109040141105652e-01
    z[6,7,4]  R2265     -3.9541909098625183e-01
    z[6,7,4]  R2266     -6.8843239545822144e-01
    z[6,7,4]  R2267     -5.4593872278928757e-02
    z[6,7,4]  R2268     -5.5340502411127090e-02
    z[6,7,4]  R2269     -1.2876252643764019e-02
    z[6,7,4]  R2270     1.7861260101199150e-02
    z[6,7,4]  R2271     -1.6747438907623291e-01
    z[6,7,4]  R2272     3.1184649467468262e-01
    z[6,7,4]  R2273     4.8171025514602661e-01
    z[6,7,4]  R2274     4.5708559453487396e-02
    z[6,7,4]  R2275     2.9470726847648621e-01
    z[6,7,4]  R2276     1.7241300642490387e-01
    z[6,7,4]  R2277     -1.6473142430186272e-02
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R2164     -1
    z[6,7,5]  R2165     1
    z[6,7,5]  R2168     -1.4472095668315887e-01
    z[6,7,5]  R2169     -1.3573783636093140e-01
    z[6,7,5]  R2170     0.191695436835289
    z[6,7,5]  R2171     5.9391713142395020e-01
    z[6,7,5]  R2172     4.5820543169975281e-01
    z[6,7,5]  R2173     2.2333097457885742e-01
    z[6,7,5]  R2174     1.2142891436815262e-01
    z[6,7,5]  R2175     7.5343793630599976e-01
    z[6,7,5]  R2176     3.8874158263206482e-01
    z[6,7,5]  R2177     -6.8857200443744659e-02
    z[6,7,5]  R2178     -4.2567139863967896e-01
    z[6,7,5]  R2179     1.5580528974533081e-01
    z[6,7,5]  R2180     -8.0725483596324921e-02
    z[6,7,5]  R2181     -1.4516647160053253e-01
    z[6,7,5]  R2182     2.8524610400199890e-01
    z[6,7,5]  R2183     4.3287283182144165e-01
    z[6,7,5]  R2184     3.8777789473533630e-01
    z[6,7,5]  R2185     -1.9387087225914001e-01
    z[6,7,5]  R2186     -2.7268588542938232e-01
    z[6,7,5]  R2187     0.217215433716774
    z[6,7,5]  R2188     1.8363347649574280e-01
    z[6,7,5]  R2189     1.2184689752757549e-02
    z[6,7,5]  R2190     -3.3728274703025818e-01
    z[6,7,5]  R2191     -3.2855114340782166e-01
    z[6,7,5]  R2192     -3.5278502106666565e-01
    z[6,7,5]  R2193     -0.41490638256073
    z[6,7,5]  R2194     1.0233254730701447e-01
    z[6,7,5]  R2195     5.6271735578775406e-02
    z[6,7,5]  R2196     -3.4656643867492676e-01
    z[6,7,5]  R2197     1.4203636348247528e-01
    z[6,7,5]  R2198     2.9624342918395996e-02
    z[6,7,5]  R2199     6.7647522687911987e-01
    z[6,7,5]  R2200     4.8723358660936356e-02
    z[6,7,5]  R2201     4.7669883817434311e-02
    z[6,7,5]  R2202     -2.8615808486938477e-01
    z[6,7,5]  R2203     1.4482316374778748e-01
    z[6,7,5]  R2204     6.9450116157531738e-01
    z[6,7,5]  R2205     -2.7214035391807556e-01
    z[6,7,5]  R2206     -7.5684398412704468e-02
    z[6,7,5]  R2207     -2.3218944668769836e-01
    z[6,7,5]  R2208     3.9754796028137207e-01
    z[6,7,5]  R2209     4.6906667947769165e-01
    z[6,7,5]  R2210     1.2018888443708420e-01
    z[6,7,5]  R2211     -6.8617528676986694e-01
    z[6,7,5]  R2212     1.1358385533094406e-01
    z[6,7,5]  R2213     5.2496343851089478e-02
    z[6,7,5]  R2214     1.1583501845598221e-01
    z[6,7,5]  R2215     3.5132703185081482e-01
    z[6,7,5]  R2216     -3.2511469721794128e-01
    z[6,7,5]  R2217     -4.2049628496170044e-01
    z[6,7,5]  R2218     -6.4440411329269409e-01
    z[6,7,5]  R2219     2.2377158701419830e-01
    z[6,7,5]  R2220     -2.4916891753673553e-01
    z[6,7,5]  R2221     2.4966686964035034e-01
    z[6,7,5]  R2222     -0.355245441198349
    z[6,7,5]  R2223     6.3282638788223267e-01
    z[6,7,5]  R2224     4.2506182193756104e-01
    z[6,7,5]  R2225     -1.5773360431194305e-01
    z[6,7,5]  R2226     -6.0122217983007431e-02
    z[6,7,5]  R2227     3.1174570322036743e-01
    z[6,7,5]  R2228     1.0952552407979965e-01
    z[6,7,5]  R2229     -3.2058542128652334e-03
    z[6,7,5]  R2230     4.8141273856163025e-01
    z[6,7,5]  R2231     -0.0998157262802124
    z[6,7,5]  R2232     -2.8701263666152954e-01
    z[6,7,5]  R2233     -4.3160140514373779e-02
    z[6,7,5]  R2234     1.8473663926124573e-01
    z[6,7,5]  R2235     2.9781460762023926e-01
    z[6,7,5]  R2236     3.5354730486869812e-01
    z[6,7,5]  R2237     5.2908492088317871e-01
    z[6,7,5]  R2238     1.3210134208202362e-01
    z[6,7,5]  R2239     0.0831405371427536
    z[6,7,5]  R2240     -2.7633768320083618e-01
    z[6,7,5]  R2241     -2.6825129985809326e-01
    z[6,7,5]  R2242     -1.6878819093108177e-02
    z[6,7,5]  R2243     -5.1529240608215332e-01
    z[6,7,5]  R2244     -5.1640772819519043e-01
    z[6,7,5]  R2245     -4.1512230038642883e-01
    z[6,7,5]  R2246     -4.7670522332191467e-01
    z[6,7,5]  R2247     -4.1783046722412109e-01
    z[6,7,5]  R2248     1.6127510368824005e-01
    z[6,7,5]  R2249     2.6250478625297546e-01
    z[6,7,5]  R2250     3.3466845750808716e-01
    z[6,7,5]  R2251     4.1617873311042786e-01
    z[6,7,5]  R2252     1.8237130343914032e-01
    z[6,7,5]  R2253     2.0769244432449341e-01
    z[6,7,5]  R2254     0.0785713791847229
    z[6,7,5]  R2255     -2.3665902018547058e-01
    z[6,7,5]  R2256     -8.6512090638279915e-03
    z[6,7,5]  R2257     -1.6749377548694611e-01
    z[6,7,5]  R2258     3.0255937576293945e-01
    z[6,7,5]  R2259     6.2148499488830566e-01
    z[6,7,5]  R2260     -1.7706012725830078e-01
    z[6,7,5]  R2261     -2.0281611010432243e-02
    z[6,7,5]  R2262     2.8980734944343567e-01
    z[6,7,5]  R2263     -6.6166333854198456e-02
    z[6,7,5]  R2264     3.4562689065933228e-01
    z[6,7,5]  R2265     0.0786033347249031
    z[6,7,5]  R2266     -1.0985479503870010e-01
    z[6,7,5]  R2267     -2.1916307508945465e-01
    z[6,7,5]  R2268     -1.7077222466468811e-02
    z[6,7,5]  R2269     -1.3364957273006439e-01
    z[6,7,5]  R2270     -1.6446934640407562e-01
    z[6,7,5]  R2271     3.2586103677749634e-01
    z[6,7,5]  R2272     -1.9349161535501480e-02
    z[6,7,5]  R2273     -2.0564547181129456e-01
    z[6,7,5]  R2274     4.5173144340515137e-01
    z[6,7,5]  R2275     1.2901437282562256e-01
    z[6,7,5]  R2276     -2.5292432308197021e-01
    z[6,7,5]  R2277     -1.4887933433055878e-01
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R2166     -1
    z[6,7,6]  R2167     1
    z[6,7,6]  R2168     -4.6459862589836121e-01
    z[6,7,6]  R2169     -2.5445064902305603e-01
    z[6,7,6]  R2170     -4.7143781185150146e-01
    z[6,7,6]  R2171     -9.0329416096210480e-02
    z[6,7,6]  R2172     1.9213742017745972e-01
    z[6,7,6]  R2173     -7.5371921062469482e-02
    z[6,7,6]  R2174     -3.1680127978324890e-01
    z[6,7,6]  R2175     -4.6352922916412354e-01
    z[6,7,6]  R2176     3.8438599556684494e-02
    z[6,7,6]  R2177     0.261014848947525
    z[6,7,6]  R2178     4.8334154486656189e-01
    z[6,7,6]  R2179     1.1818795651197433e-01
    z[6,7,6]  R2180     8.3051025867462158e-01
    z[6,7,6]  R2181     8.5704708099365234e-01
    z[6,7,6]  R2182     0.682844340801239
    z[6,7,6]  R2183     5.7665061950683594e-01
    z[6,7,6]  R2184     7.2481536865234375e-01
    z[6,7,6]  R2185     4.0211758017539978e-01
    z[6,7,6]  R2186     -9.5372155308723450e-02
    z[6,7,6]  R2187     2.1879369020462036e-01
    z[6,7,6]  R2188     2.6650199294090271e-01
    z[6,7,6]  R2189     5.8533376455307007e-01
    z[6,7,6]  R2190     3.7827339768409729e-01
    z[6,7,6]  R2191     -3.6520313471555710e-02
    z[6,7,6]  R2192     -0.000860060506965965
    z[6,7,6]  R2193     1.8904957175254822e-01
    z[6,7,6]  R2194     2.2808564826846123e-02
    z[6,7,6]  R2195     -8.3424195647239685e-02
    z[6,7,6]  R2196     1.7950646579265594e-02
    z[6,7,6]  R2197     4.2042294144630432e-01
    z[6,7,6]  R2198     -1.0060324519872665e-01
    z[6,7,6]  R2199     1.8184538930654526e-02
    z[6,7,6]  R2200     2.5367733836174011e-01
    z[6,7,6]  R2201     1.5950077772140503e-01
    z[6,7,6]  R2202     -3.7078243494033813e-01
    z[6,7,6]  R2203     -1.3133244216442108e-01
    z[6,7,6]  R2204     -4.3709173798561096e-02
    z[6,7,6]  R2205     0.423032283782959
    z[6,7,6]  R2206     1.6708987951278687e-01
    z[6,7,6]  R2207     3.0549925565719604e-01
    z[6,7,6]  R2208     -1.5334303677082062e-01
    z[6,7,6]  R2209     -3.6709284782409668e-01
    z[6,7,6]  R2210     1.2286590039730072e-01
    z[6,7,6]  R2211     -6.7497797310352325e-02
    z[6,7,6]  R2212     3.1256254762411118e-02
    z[6,7,6]  R2213     2.6256346702575684e-01
    z[6,7,6]  R2214     4.8001569509506226e-01
    z[6,7,6]  R2215     4.7469669580459595e-01
    z[6,7,6]  R2216     3.9829116314649582e-02
    z[6,7,6]  R2217     2.2275516390800476e-01
    z[6,7,6]  R2218     -4.2748800478875637e-04
    z[6,7,6]  R2219     -8.9473381638526917e-02
    z[6,7,6]  R2220     9.4732828438282013e-02
    z[6,7,6]  R2221     6.1027163267135620e-01
    z[6,7,6]  R2222     1.5876251459121704e-01
    z[6,7,6]  R2223     3.3920636773109436e-01
    z[6,7,6]  R2224     1.4114594459533691e-01
    z[6,7,6]  R2225     2.1262085065245628e-02
    z[6,7,6]  R2226     -4.5625671744346619e-01
    z[6,7,6]  R2227     -1.3936492800712585e-01
    z[6,7,6]  R2228     1.2065856903791428e-01
    z[6,7,6]  R2229     -2.5245729088783264e-01
    z[6,7,6]  R2230     -3.6780178546905518e-01
    z[6,7,6]  R2231     2.6245898008346558e-01
    z[6,7,6]  R2232     -0.431118905544281
    z[6,7,6]  R2233     1.1443287134170532e-01
    z[6,7,6]  R2234     -3.0566301941871643e-01
    z[6,7,6]  R2235     6.8310797214508057e-02
    z[6,7,6]  R2236     -3.9937660098075867e-01
    z[6,7,6]  R2237     4.9677121639251709e-01
    z[6,7,6]  R2238     -1.4393849670886993e-01
    z[6,7,6]  R2239     2.6950417086482048e-02
    z[6,7,6]  R2240     1.5028476715087891e-01
    z[6,7,6]  R2241     5.3693549707531929e-03
    z[6,7,6]  R2242     -1.7856544256210327e-01
    z[6,7,6]  R2243     -1.9104431569576263e-01
    z[6,7,6]  R2244     -0.0746225118637085
    z[6,7,6]  R2245     -7.4989609420299530e-02
    z[6,7,6]  R2246     -3.4695494174957275e-01
    z[6,7,6]  R2247     1.7652879655361176e-01
    z[6,7,6]  R2248     2.0065940916538239e-01
    z[6,7,6]  R2249     2.8138899803161621e-01
    z[6,7,6]  R2250     3.0447763204574585e-01
    z[6,7,6]  R2251     5.0895728170871735e-02
    z[6,7,6]  R2252     -1.8128305673599243e-01
    z[6,7,6]  R2253     2.0164723694324493e-01
    z[6,7,6]  R2254     -2.5364974141120911e-01
    z[6,7,6]  R2255     -3.4070074558258057e-01
    z[6,7,6]  R2256     -2.7692726254463196e-01
    z[6,7,6]  R2257     5.5489383637905121e-02
    z[6,7,6]  R2258     1.6778001189231873e-01
    z[6,7,6]  R2259     3.4769383072853088e-01
    z[6,7,6]  R2260     -5.2694267034530640e-01
    z[6,7,6]  R2261     3.8925391435623169e-01
    z[6,7,6]  R2262     1.8882460892200470e-01
    z[6,7,6]  R2263     -8.0523900687694550e-03
    z[6,7,6]  R2264     -4.4849586486816406e-01
    z[6,7,6]  R2265     4.0044292807579041e-01
    z[6,7,6]  R2266     -1.6809058189392090e-01
    z[6,7,6]  R2267     1.6339325904846191e-01
    z[6,7,6]  R2268     8.3301074802875519e-02
    z[6,7,6]  R2269     1.7445525154471397e-02
    z[6,7,6]  R2270     -2.9239067435264587e-01
    z[6,7,6]  R2271     -1.6763594746589661e-01
    z[6,7,6]  R2272     0.157171830534935
    z[6,7,6]  R2273     5.9484452009201050e-02
    z[6,7,6]  R2274     1.0688801854848862e-01
    z[6,7,6]  R2275     -1.0583240538835526e-01
    z[6,7,6]  R2276     3.6158952116966248e-01
    z[6,7,6]  R2277     -1.0297979414463043e-01
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R2278     -1
    z[7,6,0]  R2279     1
    z[7,6,0]  R2292     6.2022256851196289e-01
    z[7,6,0]  R2293     6.1659902334213257e-01
    z[7,6,0]  R2294     2.9703339934349060e-01
    z[7,6,0]  R2295     5.4968541860580444e-01
    z[7,6,0]  R2296     6.3667088747024536e-01
    z[7,6,0]  R2297     0.882612943649292
    z[7,6,0]  R2298     -1.4130641520023346e-01
    z[7,6,0]  R2299     8.2938581705093384e-01
    z[7,6,0]  R2300     7.5897300243377686e-01
    z[7,6,0]  R2301     4.2012134194374084e-01
    z[7,6,0]  R2302     -4.9780672788619995e-01
    z[7,6,0]  R2303     -0.572464108467102
    z[7,6,0]  R2304     -4.3742641806602478e-01
    z[7,6,0]  R2305     -3.2142275571823120e-01
    z[7,6,0]  R2306     -1.9069717824459076e-01
    z[7,6,0]  R2307     -3.6926296353340149e-01
    z[7,6,0]  R2308     -2.0503515005111694e-01
    z[7,6,0]  R2309     -0.310046523809433
    z[7,6,0]  R2310     -4.1690936684608459e-01
    z[7,6,0]  R2311     -3.7215346097946167e-01
    z[7,6,0]  R2312     -3.3932819962501526e-01
    z[7,6,0]  R2313     -3.5454162955284119e-01
    z[7,6,0]  R2314     -4.4399699568748474e-01
    z[7,6,0]  R2315     -2.4433828890323639e-01
    z[7,6,0]  R2316     -3.5885170102119446e-01
    z[7,6,0]  R2317     -3.3633485436439514e-01
    z[7,6,0]  R2318     -2.3008981347084045e-01
    z[7,6,0]  R2319     -7.2591103613376617e-02
    z[7,6,0]  R2320     -1.1461601406335831e-01
    z[7,6,0]  R2321     -4.6189066767692566e-01
    z[7,6,0]  R2322     7.5222015380859375e-01
    z[7,6,0]  R2323     -1.1398845165967941e-01
    z[7,6,0]  R2324     9.3784838914871216e-02
    z[7,6,0]  R2325     -2.6202374696731567e-01
    z[7,6,0]  R2326     5.2261631935834885e-02
    z[7,6,0]  R2327     -6.1903566122055054e-02
    z[7,6,0]  R2328     -4.6527091413736343e-02
    z[7,6,0]  R2329     -3.9346495270729065e-01
    z[7,6,0]  R2330     -2.1216526627540588e-01
    z[7,6,0]  R2331     -0.501543402671814
    z[7,6,0]  R2332     -4.9204930663108826e-02
    z[7,6,0]  R2333     -1.2464704364538193e-01
    z[7,6,0]  R2334     2.2177331149578094e-01
    z[7,6,0]  R2335     -4.3282747268676758e-02
    z[7,6,0]  R2336     -3.5235892981290817e-02
    z[7,6,0]  R2337     2.0288916304707527e-02
    z[7,6,0]  R2338     -2.7766540646553040e-01
    z[7,6,0]  R2339     -3.0240246653556824e-01
    z[7,6,0]  R2340     -2.4311359226703644e-01
    z[7,6,0]  R2341     2.4615408480167389e-01
    z[7,6,0]  R2342     -1.8632820248603821e-01
    z[7,6,0]  R2343     -4.7465452551841736e-01
    z[7,6,0]  R2344     4.3792444467544556e-01
    z[7,6,0]  R2345     3.8235524296760559e-01
    z[7,6,0]  R2346     3.7346342206001282e-01
    z[7,6,0]  R2347     6.3119995594024658e-01
    z[7,6,0]  R2348     3.2929986715316772e-01
    z[7,6,0]  R2349     1.5928198397159576e-01
    z[7,6,0]  R2350     6.0713529586791992e-01
    z[7,6,0]  R2351     3.4094351530075073e-01
    z[7,6,0]  R2352     -0.58119797706604
    z[7,6,0]  R2353     3.0131638050079346e-02
    z[7,6,0]  R2354     -1.4204809069633484e-01
    z[7,6,0]  R2355     -6.5065003931522369e-02
    z[7,6,0]  R2356     -3.1800848245620728e-01
    z[7,6,0]  R2357     -4.2569833993911743e-01
    z[7,6,0]  R2358     -3.5634589195251465e-01
    z[7,6,0]  R2359     3.0663952231407166e-01
    z[7,6,0]  R2360     2.5091221928596497e-01
    z[7,6,0]  R2361     -5.2162152528762817e-01
    z[7,6,0]  R2362     -3.3429333567619324e-01
    z[7,6,0]  R2363     -2.3331068456172943e-01
    z[7,6,0]  R2364     3.7231542170047760e-02
    z[7,6,0]  R2365     2.4421063065528870e-01
    z[7,6,0]  R2366     4.2844238877296448e-01
    z[7,6,0]  R2367     5.3521293401718140e-01
    z[7,6,0]  R2368     3.9225590229034424e-01
    z[7,6,0]  R2369     5.9769493341445923e-01
    z[7,6,0]  R2370     4.0260460972785950e-01
    z[7,6,0]  R2371     -1.4065428078174591e-01
    z[7,6,0]  R2372     2.9243695735931396e-01
    z[7,6,0]  R2373     7.3771692812442780e-02
    z[7,6,0]  R2374     2.5312933325767517e-01
    z[7,6,0]  R2375     6.3629776239395142e-01
    z[7,6,0]  R2376     0.184300035238266
    z[7,6,0]  R2377     -1.8647179007530212e-01
    z[7,6,0]  R2378     3.7628549337387085e-01
    z[7,6,0]  R2379     2.8730541467666626e-01
    z[7,6,0]  R2380     8.5978329181671143e-02
    z[7,6,0]  R2381     0.509591281414032
    z[7,6,0]  R2382     -5.9725429862737656e-02
    z[7,6,0]  R2383     3.3289736509323120e-01
    z[7,6,0]  R2384     0.533287525177002
    z[7,6,0]  R2385     -6.6896595060825348e-02
    z[7,6,0]  R2386     3.0792000889778137e-01
    z[7,6,0]  R2387     2.2734439373016357e-01
    z[7,6,0]  R2388     6.3056498765945435e-01
    z[7,6,0]  R2389     -1.6158511862158775e-02
    z[7,6,0]  R2390     6.9024398922920227e-02
    z[7,6,0]  R2391     3.2530412077903748e-01
    z[7,6,0]  R2392     -1.7556053400039673e-01
    z[7,6,0]  R2393     4.3240612745285034e-01
    z[7,6,0]  R2394     -3.0810329318046570e-01
    z[7,6,0]  R2395     -9.9450044333934784e-02
    z[7,6,0]  R2396     2.9956212639808655e-01
    z[7,6,0]  R2397     4.4328609108924866e-01
    z[7,6,0]  R2398     -2.0548477768898010e-02
    z[7,6,0]  R2399     -5.0517898797988892e-01
    z[7,6,0]  R2400     -3.6625093221664429e-01
    z[7,6,0]  R2401     -2.4710388481616974e-01
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R2280     -1
    z[7,6,1]  R2281     1
    z[7,6,1]  R2292     -5.7872150093317032e-02
    z[7,6,1]  R2293     -5.1282203197479248e-01
    z[7,6,1]  R2294     0.0262064840644598
    z[7,6,1]  R2295     3.6335122585296631e-01
    z[7,6,1]  R2296     -1.6931580007076263e-01
    z[7,6,1]  R2297     -0.329165518283844
    z[7,6,1]  R2298     -0.0679888054728508
    z[7,6,1]  R2299     -2.3425427079200745e-01
    z[7,6,1]  R2300     -2.3805886507034302e-01
    z[7,6,1]  R2301     -4.3429568409919739e-01
    z[7,6,1]  R2302     -8.1585150957107544e-01
    z[7,6,1]  R2303     -0.80653977394104
    z[7,6,1]  R2304     -7.6596271991729736e-01
    z[7,6,1]  R2305     -7.6712471246719360e-01
    z[7,6,1]  R2306     -7.3575627803802490e-01
    z[7,6,1]  R2307     -6.4961183071136475e-01
    z[7,6,1]  R2308     -7.3032897710800171e-01
    z[7,6,1]  R2309     -6.7524188756942749e-01
    z[7,6,1]  R2310     -6.3695675134658813e-01
    z[7,6,1]  R2311     -7.0628565549850464e-01
    z[7,6,1]  R2312     8.0494111776351929e-01
    z[7,6,1]  R2313     7.4577414989471436e-01
    z[7,6,1]  R2314     6.8204289674758911e-01
    z[7,6,1]  R2315     8.3312731981277466e-01
    z[7,6,1]  R2316     0.872372567653656
    z[7,6,1]  R2317     0.892861545085907
    z[7,6,1]  R2318     8.3846324682235718e-01
    z[7,6,1]  R2319     8.3353638648986816e-01
    z[7,6,1]  R2320     8.3021491765975952e-01
    z[7,6,1]  R2321     8.0449211597442627e-01
    z[7,6,1]  R2322     1.4912796206772327e-02
    z[7,6,1]  R2323     -1.4350967109203339e-01
    z[7,6,1]  R2324     0.515442430973053
    z[7,6,1]  R2325     -7.1135634183883667e-01
    z[7,6,1]  R2326     7.3089694976806641e-01
    z[7,6,1]  R2327     7.0023673772811890e-01
    z[7,6,1]  R2328     7.3360109329223633e-01
    z[7,6,1]  R2329     3.8575199246406555e-01
    z[7,6,1]  R2330     6.1126559972763062e-01
    z[7,6,1]  R2331     3.4472337365150452e-01
    z[7,6,1]  R2332     -8.0631360411643982e-02
    z[7,6,1]  R2333     2.0715110003948212e-01
    z[7,6,1]  R2334     7.0760160684585571e-01
    z[7,6,1]  R2335     8.5351544618606567e-01
    z[7,6,1]  R2336     -7.6736605167388916e-01
    z[7,6,1]  R2337     -7.7822124958038330e-01
    z[7,6,1]  R2338     4.3269225955009460e-01
    z[7,6,1]  R2339     2.9408836364746094e-01
    z[7,6,1]  R2340     4.7195664048194885e-01
    z[7,6,1]  R2341     6.2477678060531616e-01
    z[7,6,1]  R2342     6.1064338684082031e-01
    z[7,6,1]  R2343     6.2450957298278809e-01
    z[7,6,1]  R2344     5.7998287677764893e-01
    z[7,6,1]  R2345     4.0597015619277954e-01
    z[7,6,1]  R2346     6.3167077302932739e-01
    z[7,6,1]  R2347     -0.530769944190979
    z[7,6,1]  R2348     -8.4959131479263306e-01
    z[7,6,1]  R2349     3.1109875440597534e-01
    z[7,6,1]  R2350     -5.5505788326263428e-01
    z[7,6,1]  R2351     7.6115798950195312e-01
    z[7,6,1]  R2352     6.7412899807095528e-03
    z[7,6,1]  R2353     -4.3777039647102356e-01
    z[7,6,1]  R2354     -1.1569716967642307e-02
    z[7,6,1]  R2355     5.7042874395847321e-03
    z[7,6,1]  R2356     -1.0769910365343094e-01
    z[7,6,1]  R2357     -0.089664988219738
    z[7,6,1]  R2358     -4.7049908898770809e-03
    z[7,6,1]  R2359     -7.8689880669116974e-02
    z[7,6,1]  R2360     5.3881829977035522e-01
    z[7,6,1]  R2361     -7.2857844829559326e-01
    z[7,6,1]  R2362     2.4562025070190430e-01
    z[7,6,1]  R2363     3.5549721121788025e-01
    z[7,6,1]  R2364     7.6754844188690186e-01
    z[7,6,1]  R2365     7.3900038003921509e-01
    z[7,6,1]  R2366     0.700786292552948
    z[7,6,1]  R2367     1.5757998824119568e-01
    z[7,6,1]  R2368     -6.3820332288742065e-01
    z[7,6,1]  R2369     -7.3525291681289673e-01
    z[7,6,1]  R2370     1.3339456915855408e-01
    z[7,6,1]  R2371     5.8279263973236084e-01
    z[7,6,1]  R2372     7.5469082593917847e-01
    z[7,6,1]  R2373     7.2485476732254028e-01
    z[7,6,1]  R2374     0.859340250492096
    z[7,6,1]  R2375     -3.5345073789358139e-02
    z[7,6,1]  R2376     -3.5264518857002258e-01
    z[7,6,1]  R2377     -6.0123950242996216e-01
    z[7,6,1]  R2378     -2.7305385470390320e-01
    z[7,6,1]  R2379     -0.696918249130249
    z[7,6,1]  R2380     -5.3487861156463623e-01
    z[7,6,1]  R2381     -5.9835082292556763e-01
    z[7,6,1]  R2382     7.0404177904129028e-01
    z[7,6,1]  R2383     1.4636141061782837e-01
    z[7,6,1]  R2384     3.5103011131286621e-01
    z[7,6,1]  R2385     -3.7472493946552277e-02
    z[7,6,1]  R2386     -5.2194631099700928e-01
    z[7,6,1]  R2387     -6.3355344533920288e-01
    z[7,6,1]  R2388     -4.7664853930473328e-01
    z[7,6,1]  R2389     -5.6076383590698242e-01
    z[7,6,1]  R2390     -7.4455153942108154e-01
    z[7,6,1]  R2391     -7.7789926528930664e-01
    z[7,6,1]  R2392     -2.2095529362559319e-02
    z[7,6,1]  R2393     -7.4164569377899170e-01
    z[7,6,1]  R2394     7.3182427883148193e-01
    z[7,6,1]  R2395     6.3839703798294067e-01
    z[7,6,1]  R2396     -0.833806574344635
    z[7,6,1]  R2397     -4.0060380101203918e-01
    z[7,6,1]  R2398     -7.9504323005676270e-01
    z[7,6,1]  R2399     -0.525545597076416
    z[7,6,1]  R2400     -5.5992990732192993e-01
    z[7,6,1]  R2401     -0.585119366645813
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R2282     -1
    z[7,6,2]  R2283     1
    z[7,6,2]  R2292     4.7265261411666870e-01
    z[7,6,2]  R2293     1.7059187591075897e-01
    z[7,6,2]  R2294     2.7126777172088623e-01
    z[7,6,2]  R2295     1.5518426895141602e-01
    z[7,6,2]  R2296     1.0871021449565887e-01
    z[7,6,2]  R2297     -6.2821321189403534e-02
    z[7,6,2]  R2298     6.1464405059814453e-01
    z[7,6,2]  R2299     -3.1405130028724670e-01
    z[7,6,2]  R2300     1.7545676231384277e-01
    z[7,6,2]  R2301     -8.9660741388797760e-02
    z[7,6,2]  R2302     8.6172811686992645e-02
    z[7,6,2]  R2303     -6.2457986176013947e-02
    z[7,6,2]  R2304     2.3516632616519928e-01
    z[7,6,2]  R2305     -7.1627877652645111e-02
    z[7,6,2]  R2306     2.6620075106620789e-02
    z[7,6,2]  R2307     2.4896752834320068e-01
    z[7,6,2]  R2308     7.0647731423377991e-02
    z[7,6,2]  R2309     -4.3897065520286560e-01
    z[7,6,2]  R2310     -2.5264355540275574e-01
    z[7,6,2]  R2311     -3.8364082574844360e-01
    z[7,6,2]  R2312     3.7506440281867981e-01
    z[7,6,2]  R2313     4.0297257900238037e-01
    z[7,6,2]  R2314     2.5528374314308167e-01
    z[7,6,2]  R2315     1.5336585044860840e-01
    z[7,6,2]  R2316     1.8986490368843079e-01
    z[7,6,2]  R2317     9.0302256867289543e-03
    z[7,6,2]  R2318     2.9375827312469482e-01
    z[7,6,2]  R2319     3.5538288950920105e-01
    z[7,6,2]  R2320     4.1185724735260010e-01
    z[7,6,2]  R2321     -7.0786923170089722e-02
    z[7,6,2]  R2322     -2.2646564990282059e-02
    z[7,6,2]  R2323     4.0609481930732727e-01
    z[7,6,2]  R2324     5.4534208774566650e-01
    z[7,6,2]  R2325     -2.2798979282379150e-01
    z[7,6,2]  R2326     -2.6518395543098450e-01
    z[7,6,2]  R2327     5.8104771375656128e-01
    z[7,6,2]  R2328     0.125529944896698
    z[7,6,2]  R2329     -1.5523053705692291e-01
    z[7,6,2]  R2330     -7.1677933447062969e-03
    z[7,6,2]  R2331     -1.0918294638395309e-01
    z[7,6,2]  R2332     0.0843895822763443
    z[7,6,2]  R2333     1.9237776100635529e-01
    z[7,6,2]  R2334     3.7106525897979736e-01
    z[7,6,2]  R2335     2.9694685339927673e-01
    z[7,6,2]  R2336     4.4253346323966980e-01
    z[7,6,2]  R2337     -2.8792685270309448e-01
    z[7,6,2]  R2338     7.1017062664031982e-01
    z[7,6,2]  R2339     -3.3727708458900452e-01
    z[7,6,2]  R2340     -3.5415071249008179e-01
    z[7,6,2]  R2341     -3.4223309159278870e-01
    z[7,6,2]  R2342     -0.332560658454895
    z[7,6,2]  R2343     5.3895749151706696e-02
    z[7,6,2]  R2344     -0.286003977060318
    z[7,6,2]  R2345     -3.4214845299720764e-01
    z[7,6,2]  R2346     -1.1339093744754791e-01
    z[7,6,2]  R2347     4.0346592664718628e-01
    z[7,6,2]  R2348     1.7034868896007538e-01
    z[7,6,2]  R2349     -2.1381275728344917e-02
    z[7,6,2]  R2350     2.2181870043277740e-01
    z[7,6,2]  R2351     4.7923141717910767e-01
    z[7,6,2]  R2352     -6.5385691821575165e-02
    z[7,6,2]  R2353     -1.6888666152954102e-01
    z[7,6,2]  R2354     -2.2791191935539246e-02
    z[7,6,2]  R2355     -2.2853022813796997e-01
    z[7,6,2]  R2356     -7.1053137071430683e-03
    z[7,6,2]  R2357     1.4190416038036346e-01
    z[7,6,2]  R2358     1.5632751584053040e-01
    z[7,6,2]  R2359     -5.2995961904525757e-01
    z[7,6,2]  R2360     -3.7402606103569269e-03
    z[7,6,2]  R2361     -4.1265211999416351e-02
    z[7,6,2]  R2362     -2.1572384238243103e-01
    z[7,6,2]  R2363     -2.1186050772666931e-01
    z[7,6,2]  R2364     -1.3898000121116638e-01
    z[7,6,2]  R2365     -1.4530846476554871e-01
    z[7,6,2]  R2366     -3.7960830330848694e-01
    z[7,6,2]  R2367     -6.3927090167999268e-01
    z[7,6,2]  R2368     4.3904027342796326e-01
    z[7,6,2]  R2369     -3.5784412175416946e-02
    z[7,6,2]  R2370     -3.6239191889762878e-01
    z[7,6,2]  R2371     2.3358710110187531e-02
    z[7,6,2]  R2372     -2.5001293420791626e-01
    z[7,6,2]  R2373     2.6127649471163750e-02
    z[7,6,2]  R2374     1.0452125966548920e-01
    z[7,6,2]  R2375     -4.8448723554611206e-01
    z[7,6,2]  R2376     -0.420459121465683
    z[7,6,2]  R2377     7.3230654001235962e-01
    z[7,6,2]  R2378     5.0593322515487671e-01
    z[7,6,2]  R2379     2.6776370406150818e-01
    z[7,6,2]  R2380     6.8941169977188110e-01
    z[7,6,2]  R2381     2.4605287611484528e-01
    z[7,6,2]  R2382     3.3118776977062225e-02
    z[7,6,2]  R2383     -3.0750176310539246e-01
    z[7,6,2]  R2384     -5.9830981492996216e-01
    z[7,6,2]  R2385     -2.7669641375541687e-01
    z[7,6,2]  R2386     7.7833157777786255e-01
    z[7,6,2]  R2387     4.6662944555282593e-01
    z[7,6,2]  R2388     2.5457486510276794e-01
    z[7,6,2]  R2389     5.6163430213928223e-01
    z[7,6,2]  R2390     4.7519233822822571e-01
    z[7,6,2]  R2391     9.7652181982994080e-02
    z[7,6,2]  R2392     -2.4107088148593903e-01
    z[7,6,2]  R2393     2.7117297053337097e-01
    z[7,6,2]  R2394     1.0942734032869339e-01
    z[7,6,2]  R2395     2.2474190592765808e-01
    z[7,6,2]  R2396     2.4390894174575806e-01
    z[7,6,2]  R2397     3.5541704297065735e-01
    z[7,6,2]  R2398     3.6890363693237305e-01
    z[7,6,2]  R2399     3.4448531270027161e-01
    z[7,6,2]  R2400     -5.2785462141036987e-01
    z[7,6,2]  R2401     -5.2000045776367188e-01
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R2284     -1
    z[7,6,3]  R2285     1
    z[7,6,3]  R2292     0.564596951007843
    z[7,6,3]  R2293     5.1371496915817261e-01
    z[7,6,3]  R2294     6.0861396789550781e-01
    z[7,6,3]  R2295     6.4744567871093750e-01
    z[7,6,3]  R2296     5.3467601537704468e-01
    z[7,6,3]  R2297     2.5986871123313904e-01
    z[7,6,3]  R2298     6.7782843112945557e-01
    z[7,6,3]  R2299     2.3131449520587921e-01
    z[7,6,3]  R2300     1.5036433935165405e-01
    z[7,6,3]  R2301     0.316175639629364
    z[7,6,3]  R2302     -1.6702687740325928e-01
    z[7,6,3]  R2303     -2.5385264307260513e-02
    z[7,6,3]  R2304     0.131901815533638
    z[7,6,3]  R2305     -4.6181580424308777e-01
    z[7,6,3]  R2306     -5.9974139928817749e-01
    z[7,6,3]  R2307     -1.7495591938495636e-01
    z[7,6,3]  R2308     -2.9178082942962646e-01
    z[7,6,3]  R2309     -2.7795532345771790e-01
    z[7,6,3]  R2310     -4.1714288294315338e-02
    z[7,6,3]  R2311     4.8548586666584015e-02
    z[7,6,3]  R2312     -1.4104346930980682e-01
    z[7,6,3]  R2313     -3.3874134533107281e-03
    z[7,6,3]  R2314     2.5828611850738525e-01
    z[7,6,3]  R2315     -1.5882736444473267e-01
    z[7,6,3]  R2316     -0.0272738728672266
    z[7,6,3]  R2317     -8.0274511128664017e-03
    z[7,6,3]  R2318     -1.7618638277053833e-01
    z[7,6,3]  R2319     3.0444784089922905e-02
    z[7,6,3]  R2320     -2.2624140977859497e-01
    z[7,6,3]  R2321     1.8799732625484467e-01
    z[7,6,3]  R2322     5.5978453159332275e-01
    z[7,6,3]  R2323     5.4143774509429932e-01
    z[7,6,3]  R2324     3.4446281194686890e-01
    z[7,6,3]  R2325     -4.4442677497863770e-01
    z[7,6,3]  R2326     4.7526496648788452e-01
    z[7,6,3]  R2327     2.1938085556030273e-01
    z[7,6,3]  R2328     5.9873424470424652e-03
    z[7,6,3]  R2329     5.9109628200531006e-01
    z[7,6,3]  R2330     2.5889626145362854e-01
    z[7,6,3]  R2331     7.3483932018280029e-01
    z[7,6,3]  R2332     9.8674345016479492e-01
    z[7,6,3]  R2333     9.4138717651367188e-01
    z[7,6,3]  R2334     4.4672787189483643e-01
    z[7,6,3]  R2335     1.3829560577869415e-01
    z[7,6,3]  R2336     -3.0289649963378906e-01
    z[7,6,3]  R2337     1.8216690421104431e-01
    z[7,6,3]  R2338     1.1730867624282837e-01
    z[7,6,3]  R2339     -7.7046173810958862e-01
    z[7,6,3]  R2340     -6.0686582326889038e-01
    z[7,6,3]  R2341     -6.3158321380615234e-01
    z[7,6,3]  R2342     3.5337468981742859e-01
    z[7,6,3]  R2343     4.3186199665069580e-01
    z[7,6,3]  R2344     1.8458463251590729e-01
    z[7,6,3]  R2345     2.2620768845081329e-01
    z[7,6,3]  R2346     1.8109650909900665e-01
    z[7,6,3]  R2347     -2.5153917074203491e-01
    z[7,6,3]  R2348     -1.2930953502655029e-01
    z[7,6,3]  R2349     3.0619335174560547e-01
    z[7,6,3]  R2350     -3.3659148216247559e-01
    z[7,6,3]  R2351     -3.5887490957975388e-02
    z[7,6,3]  R2352     3.4116572141647339e-01
    z[7,6,3]  R2353     8.2048797607421875e-01
    z[7,6,3]  R2354     4.4180014729499817e-01
    z[7,6,3]  R2355     4.1915854811668396e-01
    z[7,6,3]  R2356     4.9153622984886169e-01
    z[7,6,3]  R2357     4.2627230286598206e-01
    z[7,6,3]  R2358     4.0830591320991516e-01
    z[7,6,3]  R2359     6.4769697189331055e-01
    z[7,6,3]  R2360     -7.5049948692321777e-01
    z[7,6,3]  R2361     2.2613897919654846e-02
    z[7,6,3]  R2362     7.7779656648635864e-01
    z[7,6,3]  R2363     6.5645754337310791e-01
    z[7,6,3]  R2364     -3.5414823889732361e-01
    z[7,6,3]  R2365     -5.1127409934997559e-01
    z[7,6,3]  R2366     -2.2181639075279236e-01
    z[7,6,3]  R2367     2.6468244194984436e-01
    z[7,6,3]  R2368     4.1745647788047791e-01
    z[7,6,3]  R2369     1.5547877550125122e-01
    z[7,6,3]  R2370     4.1459989547729492e-01
    z[7,6,3]  R2371     -3.7872564792633057e-01
    z[7,6,3]  R2372     2.4027393758296967e-01
    z[7,6,3]  R2373     1.0182113945484161e-01
    z[7,6,3]  R2374     -2.2627657651901245e-01
    z[7,6,3]  R2375     4.8898467421531677e-01
    z[7,6,3]  R2376     6.5773159265518188e-01
    z[7,6,3]  R2377     -1.5517678111791611e-02
    z[7,6,3]  R2378     2.0188668370246887e-01
    z[7,6,3]  R2379     -1.9222943484783173e-01
    z[7,6,3]  R2380     -3.4604352712631226e-01
    z[7,6,3]  R2381     0.0963834673166275
    z[7,6,3]  R2382     3.7108927965164185e-01
    z[7,6,3]  R2383     6.3011771440505981e-01
    z[7,6,3]  R2384     2.7485069632530212e-01
    z[7,6,3]  R2385     5.0760430097579956e-01
    z[7,6,3]  R2386     1.0954966396093369e-01
    z[7,6,3]  R2387     -5.5873099714517593e-02
    z[7,6,3]  R2388     1.5161101520061493e-01
    z[7,6,3]  R2389     -8.6972750723361969e-02
    z[7,6,3]  R2390     0.0417293980717659
    z[7,6,3]  R2391     -2.2500304877758026e-01
    z[7,6,3]  R2392     5.8091831207275391e-01
    z[7,6,3]  R2393     1.0255575180053711e-01
    z[7,6,3]  R2394     -4.7698262333869934e-01
    z[7,6,3]  R2395     -2.8177621960639954e-01
    z[7,6,3]  R2396     -1.8471600487828255e-02
    z[7,6,3]  R2397     8.3505949005484581e-03
    z[7,6,3]  R2398     1.7427420616149902e-01
    z[7,6,3]  R2399     -3.5285431146621704e-01
    z[7,6,3]  R2400     -0.129202738404274
    z[7,6,3]  R2401     -1.6438604891300201e-01
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R2286     -1
    z[7,6,4]  R2287     1
    z[7,6,4]  R2292     2.0796653628349304e-01
    z[7,6,4]  R2293     -8.3512617275118828e-03
    z[7,6,4]  R2294     -3.1630811095237732e-01
    z[7,6,4]  R2295     2.0905961096286774e-01
    z[7,6,4]  R2296     -6.8013528361916542e-03
    z[7,6,4]  R2297     1.6189047694206238e-01
    z[7,6,4]  R2298     -1.0302327573299408e-01
    z[7,6,4]  R2299     -1.0839579254388809e-01
    z[7,6,4]  R2300     -1.7145258188247681e-01
    z[7,6,4]  R2301     1.2915735132992268e-02
    z[7,6,4]  R2302     -1.1437698453664780e-01
    z[7,6,4]  R2303     -9.7949914634227753e-02
    z[7,6,4]  R2304     2.2429913282394409e-01
    z[7,6,4]  R2305     1.3347357511520386e-01
    z[7,6,4]  R2306     1.7241925001144409e-01
    z[7,6,4]  R2307     2.1686582267284393e-01
    z[7,6,4]  R2308     2.4941425025463104e-01
    z[7,6,4]  R2309     -3.8916151970624924e-03
    z[7,6,4]  R2310     -8.5312649607658386e-02
    z[7,6,4]  R2311     8.5909456014633179e-02
    z[7,6,4]  R2312     1.0042832791805267e-01
    z[7,6,4]  R2313     8.7373502552509308e-02
    z[7,6,4]  R2314     -3.3058132976293564e-02
    z[7,6,4]  R2315     -1.4715763926506042e-01
    z[7,6,4]  R2316     8.5299901664257050e-02
    z[7,6,4]  R2317     -7.5718536972999573e-02
    z[7,6,4]  R2318     2.3704622685909271e-01
    z[7,6,4]  R2319     2.5284444913268089e-02
    z[7,6,4]  R2320     5.5912379175424576e-03
    z[7,6,4]  R2321     -2.6069596409797668e-01
    z[7,6,4]  R2322     -0.0194578655064106
    z[7,6,4]  R2323     -3.4772194921970367e-02
    z[7,6,4]  R2324     -2.1263534203171730e-02
    z[7,6,4]  R2325     1.5456782281398773e-01
    z[7,6,4]  R2326     -2.1729257702827454e-01
    z[7,6,4]  R2327     3.4007257223129272e-01
    z[7,6,4]  R2328     -3.5109040141105652e-01
    z[7,6,4]  R2329     -3.9541909098625183e-01
    z[7,6,4]  R2330     -6.8843239545822144e-01
    z[7,6,4]  R2331     -5.4593872278928757e-02
    z[7,6,4]  R2332     -5.5340502411127090e-02
    z[7,6,4]  R2333     -1.2876252643764019e-02
    z[7,6,4]  R2334     1.7861260101199150e-02
    z[7,6,4]  R2335     -1.6747438907623291e-01
    z[7,6,4]  R2336     3.1184649467468262e-01
    z[7,6,4]  R2337     4.8171025514602661e-01
    z[7,6,4]  R2338     4.5708559453487396e-02
    z[7,6,4]  R2339     2.9470726847648621e-01
    z[7,6,4]  R2340     1.7241300642490387e-01
    z[7,6,4]  R2341     -1.6473142430186272e-02
    z[7,6,4]  R2342     -3.4659796953201294e-01
    z[7,6,4]  R2343     3.3483055233955383e-01
    z[7,6,4]  R2344     3.1140258908271790e-01
    z[7,6,4]  R2345     -3.9982533454895020e-01
    z[7,6,4]  R2346     4.1108959913253784e-01
    z[7,6,4]  R2347     -0.195590078830719
    z[7,6,4]  R2348     9.4385646283626556e-02
    z[7,6,4]  R2349     3.3273950219154358e-02
    z[7,6,4]  R2350     9.0568356215953827e-02
    z[7,6,4]  R2351     -2.3985737934708595e-02
    z[7,6,4]  R2352     -3.5591992735862732e-01
    z[7,6,4]  R2353     2.5977367162704468e-01
    z[7,6,4]  R2354     2.9617208242416382e-01
    z[7,6,4]  R2355     -1.1050403863191605e-01
    z[7,6,4]  R2356     -3.1300392746925354e-01
    z[7,6,4]  R2357     -2.9831424355506897e-01
    z[7,6,4]  R2358     -0.078194260597229
    z[7,6,4]  R2359     1.1277345009148121e-02
    z[7,6,4]  R2360     1.0195134673267603e-03
    z[7,6,4]  R2361     -3.1593844294548035e-01
    z[7,6,4]  R2362     -2.6771211624145508e-01
    z[7,6,4]  R2363     -2.4543073028326035e-02
    z[7,6,4]  R2364     -8.8862076401710510e-02
    z[7,6,4]  R2365     4.9440383911132812e-02
    z[7,6,4]  R2366     8.7021633982658386e-02
    z[7,6,4]  R2367     -4.5874398201704025e-02
    z[7,6,4]  R2368     -2.4660360813140869e-01
    z[7,6,4]  R2369     -2.5803777575492859e-01
    z[7,6,4]  R2370     0.629653811454773
    z[7,6,4]  R2371     -0.547412633895874
    z[7,6,4]  R2372     4.6226152777671814e-01
    z[7,6,4]  R2373     1.1981938965618610e-02
    z[7,6,4]  R2374     -2.6193103194236755e-01
    z[7,6,4]  R2375     3.0385696887969971e-01
    z[7,6,4]  R2376     1.1363150179386139e-01
    z[7,6,4]  R2377     1.7030476033687592e-01
    z[7,6,4]  R2378     5.3682446479797363e-02
    z[7,6,4]  R2379     2.6475310325622559e-01
    z[7,6,4]  R2380     0.278982013463974
    z[7,6,4]  R2381     4.0647217631340027e-01
    z[7,6,4]  R2382     4.2472994327545166e-01
    z[7,6,4]  R2383     1.4618931710720062e-01
    z[7,6,4]  R2384     -3.5961541533470154e-01
    z[7,6,4]  R2385     4.2954066395759583e-01
    z[7,6,4]  R2386     3.2832890748977661e-02
    z[7,6,4]  R2387     5.0434535741806030e-01
    z[7,6,4]  R2388     2.0872655510902405e-01
    z[7,6,4]  R2389     -1.1626593023538589e-01
    z[7,6,4]  R2390     3.2564330101013184e-01
    z[7,6,4]  R2391     -4.9502965062856674e-02
    z[7,6,4]  R2392     3.9730608463287354e-01
    z[7,6,4]  R2393     3.4764197468757629e-01
    z[7,6,4]  R2394     -2.4281549453735352e-01
    z[7,6,4]  R2395     1.3374213874340057e-01
    z[7,6,4]  R2396     6.1575431376695633e-02
    z[7,6,4]  R2397     3.3057440072298050e-02
    z[7,6,4]  R2398     -2.0564597100019455e-02
    z[7,6,4]  R2399     4.4731184840202332e-01
    z[7,6,4]  R2400     2.1267350018024445e-01
    z[7,6,4]  R2401     4.2725142836570740e-01
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R2288     -1
    z[7,6,5]  R2289     1
    z[7,6,5]  R2292     1.0952552407979965e-01
    z[7,6,5]  R2293     -3.2058542128652334e-03
    z[7,6,5]  R2294     4.8141273856163025e-01
    z[7,6,5]  R2295     -0.0998157262802124
    z[7,6,5]  R2296     -2.8701263666152954e-01
    z[7,6,5]  R2297     -4.3160140514373779e-02
    z[7,6,5]  R2298     1.8473663926124573e-01
    z[7,6,5]  R2299     2.9781460762023926e-01
    z[7,6,5]  R2300     3.5354730486869812e-01
    z[7,6,5]  R2301     5.2908492088317871e-01
    z[7,6,5]  R2302     1.3210134208202362e-01
    z[7,6,5]  R2303     0.0831405371427536
    z[7,6,5]  R2304     -2.7633768320083618e-01
    z[7,6,5]  R2305     -2.6825129985809326e-01
    z[7,6,5]  R2306     -1.6878819093108177e-02
    z[7,6,5]  R2307     -5.1529240608215332e-01
    z[7,6,5]  R2308     -5.1640772819519043e-01
    z[7,6,5]  R2309     -4.1512230038642883e-01
    z[7,6,5]  R2310     -4.7670522332191467e-01
    z[7,6,5]  R2311     -4.1783046722412109e-01
    z[7,6,5]  R2312     1.6127510368824005e-01
    z[7,6,5]  R2313     2.6250478625297546e-01
    z[7,6,5]  R2314     3.3466845750808716e-01
    z[7,6,5]  R2315     4.1617873311042786e-01
    z[7,6,5]  R2316     1.8237130343914032e-01
    z[7,6,5]  R2317     2.0769244432449341e-01
    z[7,6,5]  R2318     0.0785713791847229
    z[7,6,5]  R2319     -2.3665902018547058e-01
    z[7,6,5]  R2320     -8.6512090638279915e-03
    z[7,6,5]  R2321     -1.6749377548694611e-01
    z[7,6,5]  R2322     3.0255937576293945e-01
    z[7,6,5]  R2323     6.2148499488830566e-01
    z[7,6,5]  R2324     -1.7706012725830078e-01
    z[7,6,5]  R2325     -2.0281611010432243e-02
    z[7,6,5]  R2326     2.8980734944343567e-01
    z[7,6,5]  R2327     -6.6166333854198456e-02
    z[7,6,5]  R2328     3.4562689065933228e-01
    z[7,6,5]  R2329     0.0786033347249031
    z[7,6,5]  R2330     -1.0985479503870010e-01
    z[7,6,5]  R2331     -2.1916307508945465e-01
    z[7,6,5]  R2332     -1.7077222466468811e-02
    z[7,6,5]  R2333     -1.3364957273006439e-01
    z[7,6,5]  R2334     -1.6446934640407562e-01
    z[7,6,5]  R2335     3.2586103677749634e-01
    z[7,6,5]  R2336     -1.9349161535501480e-02
    z[7,6,5]  R2337     -2.0564547181129456e-01
    z[7,6,5]  R2338     4.5173144340515137e-01
    z[7,6,5]  R2339     1.2901437282562256e-01
    z[7,6,5]  R2340     -2.5292432308197021e-01
    z[7,6,5]  R2341     -1.4887933433055878e-01
    z[7,6,5]  R2342     -1.4472095668315887e-01
    z[7,6,5]  R2343     -1.3573783636093140e-01
    z[7,6,5]  R2344     0.191695436835289
    z[7,6,5]  R2345     5.9391713142395020e-01
    z[7,6,5]  R2346     4.5820543169975281e-01
    z[7,6,5]  R2347     2.2333097457885742e-01
    z[7,6,5]  R2348     1.2142891436815262e-01
    z[7,6,5]  R2349     7.5343793630599976e-01
    z[7,6,5]  R2350     3.8874158263206482e-01
    z[7,6,5]  R2351     -6.8857200443744659e-02
    z[7,6,5]  R2352     -4.2567139863967896e-01
    z[7,6,5]  R2353     1.5580528974533081e-01
    z[7,6,5]  R2354     -8.0725483596324921e-02
    z[7,6,5]  R2355     -1.4516647160053253e-01
    z[7,6,5]  R2356     2.8524610400199890e-01
    z[7,6,5]  R2357     4.3287283182144165e-01
    z[7,6,5]  R2358     3.8777789473533630e-01
    z[7,6,5]  R2359     -1.9387087225914001e-01
    z[7,6,5]  R2360     -2.7268588542938232e-01
    z[7,6,5]  R2361     0.217215433716774
    z[7,6,5]  R2362     1.8363347649574280e-01
    z[7,6,5]  R2363     1.2184689752757549e-02
    z[7,6,5]  R2364     -3.3728274703025818e-01
    z[7,6,5]  R2365     -3.2855114340782166e-01
    z[7,6,5]  R2366     -3.5278502106666565e-01
    z[7,6,5]  R2367     -0.41490638256073
    z[7,6,5]  R2368     1.0233254730701447e-01
    z[7,6,5]  R2369     5.6271735578775406e-02
    z[7,6,5]  R2370     -3.4656643867492676e-01
    z[7,6,5]  R2371     1.4203636348247528e-01
    z[7,6,5]  R2372     2.9624342918395996e-02
    z[7,6,5]  R2373     6.7647522687911987e-01
    z[7,6,5]  R2374     4.8723358660936356e-02
    z[7,6,5]  R2375     4.7669883817434311e-02
    z[7,6,5]  R2376     -2.8615808486938477e-01
    z[7,6,5]  R2377     1.4482316374778748e-01
    z[7,6,5]  R2378     6.9450116157531738e-01
    z[7,6,5]  R2379     -2.7214035391807556e-01
    z[7,6,5]  R2380     -7.5684398412704468e-02
    z[7,6,5]  R2381     -2.3218944668769836e-01
    z[7,6,5]  R2382     3.9754796028137207e-01
    z[7,6,5]  R2383     4.6906667947769165e-01
    z[7,6,5]  R2384     1.2018888443708420e-01
    z[7,6,5]  R2385     -6.8617528676986694e-01
    z[7,6,5]  R2386     1.1358385533094406e-01
    z[7,6,5]  R2387     5.2496343851089478e-02
    z[7,6,5]  R2388     1.1583501845598221e-01
    z[7,6,5]  R2389     3.5132703185081482e-01
    z[7,6,5]  R2390     -3.2511469721794128e-01
    z[7,6,5]  R2391     -4.2049628496170044e-01
    z[7,6,5]  R2392     -6.4440411329269409e-01
    z[7,6,5]  R2393     2.2377158701419830e-01
    z[7,6,5]  R2394     -2.4916891753673553e-01
    z[7,6,5]  R2395     2.4966686964035034e-01
    z[7,6,5]  R2396     -0.355245441198349
    z[7,6,5]  R2397     6.3282638788223267e-01
    z[7,6,5]  R2398     4.2506182193756104e-01
    z[7,6,5]  R2399     -1.5773360431194305e-01
    z[7,6,5]  R2400     -6.0122217983007431e-02
    z[7,6,5]  R2401     3.1174570322036743e-01
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R2290     -1
    z[7,6,6]  R2291     1
    z[7,6,6]  R2292     1.2065856903791428e-01
    z[7,6,6]  R2293     -2.5245729088783264e-01
    z[7,6,6]  R2294     -3.6780178546905518e-01
    z[7,6,6]  R2295     2.6245898008346558e-01
    z[7,6,6]  R2296     -0.431118905544281
    z[7,6,6]  R2297     1.1443287134170532e-01
    z[7,6,6]  R2298     -3.0566301941871643e-01
    z[7,6,6]  R2299     6.8310797214508057e-02
    z[7,6,6]  R2300     -3.9937660098075867e-01
    z[7,6,6]  R2301     4.9677121639251709e-01
    z[7,6,6]  R2302     -1.4393849670886993e-01
    z[7,6,6]  R2303     2.6950417086482048e-02
    z[7,6,6]  R2304     1.5028476715087891e-01
    z[7,6,6]  R2305     5.3693549707531929e-03
    z[7,6,6]  R2306     -1.7856544256210327e-01
    z[7,6,6]  R2307     -1.9104431569576263e-01
    z[7,6,6]  R2308     -0.0746225118637085
    z[7,6,6]  R2309     -7.4989609420299530e-02
    z[7,6,6]  R2310     -3.4695494174957275e-01
    z[7,6,6]  R2311     1.7652879655361176e-01
    z[7,6,6]  R2312     2.0065940916538239e-01
    z[7,6,6]  R2313     2.8138899803161621e-01
    z[7,6,6]  R2314     3.0447763204574585e-01
    z[7,6,6]  R2315     5.0895728170871735e-02
    z[7,6,6]  R2316     -1.8128305673599243e-01
    z[7,6,6]  R2317     2.0164723694324493e-01
    z[7,6,6]  R2318     -2.5364974141120911e-01
    z[7,6,6]  R2319     -3.4070074558258057e-01
    z[7,6,6]  R2320     -2.7692726254463196e-01
    z[7,6,6]  R2321     5.5489383637905121e-02
    z[7,6,6]  R2322     1.6778001189231873e-01
    z[7,6,6]  R2323     3.4769383072853088e-01
    z[7,6,6]  R2324     -5.2694267034530640e-01
    z[7,6,6]  R2325     3.8925391435623169e-01
    z[7,6,6]  R2326     1.8882460892200470e-01
    z[7,6,6]  R2327     -8.0523900687694550e-03
    z[7,6,6]  R2328     -4.4849586486816406e-01
    z[7,6,6]  R2329     4.0044292807579041e-01
    z[7,6,6]  R2330     -1.6809058189392090e-01
    z[7,6,6]  R2331     1.6339325904846191e-01
    z[7,6,6]  R2332     8.3301074802875519e-02
    z[7,6,6]  R2333     1.7445525154471397e-02
    z[7,6,6]  R2334     -2.9239067435264587e-01
    z[7,6,6]  R2335     -1.6763594746589661e-01
    z[7,6,6]  R2336     0.157171830534935
    z[7,6,6]  R2337     5.9484452009201050e-02
    z[7,6,6]  R2338     1.0688801854848862e-01
    z[7,6,6]  R2339     -1.0583240538835526e-01
    z[7,6,6]  R2340     3.6158952116966248e-01
    z[7,6,6]  R2341     -1.0297979414463043e-01
    z[7,6,6]  R2342     -4.6459862589836121e-01
    z[7,6,6]  R2343     -2.5445064902305603e-01
    z[7,6,6]  R2344     -4.7143781185150146e-01
    z[7,6,6]  R2345     -9.0329416096210480e-02
    z[7,6,6]  R2346     1.9213742017745972e-01
    z[7,6,6]  R2347     -7.5371921062469482e-02
    z[7,6,6]  R2348     -3.1680127978324890e-01
    z[7,6,6]  R2349     -4.6352922916412354e-01
    z[7,6,6]  R2350     3.8438599556684494e-02
    z[7,6,6]  R2351     0.261014848947525
    z[7,6,6]  R2352     4.8334154486656189e-01
    z[7,6,6]  R2353     1.1818795651197433e-01
    z[7,6,6]  R2354     8.3051025867462158e-01
    z[7,6,6]  R2355     8.5704708099365234e-01
    z[7,6,6]  R2356     0.682844340801239
    z[7,6,6]  R2357     5.7665061950683594e-01
    z[7,6,6]  R2358     7.2481536865234375e-01
    z[7,6,6]  R2359     4.0211758017539978e-01
    z[7,6,6]  R2360     -9.5372155308723450e-02
    z[7,6,6]  R2361     2.1879369020462036e-01
    z[7,6,6]  R2362     2.6650199294090271e-01
    z[7,6,6]  R2363     5.8533376455307007e-01
    z[7,6,6]  R2364     3.7827339768409729e-01
    z[7,6,6]  R2365     -3.6520313471555710e-02
    z[7,6,6]  R2366     -0.000860060506965965
    z[7,6,6]  R2367     1.8904957175254822e-01
    z[7,6,6]  R2368     2.2808564826846123e-02
    z[7,6,6]  R2369     -8.3424195647239685e-02
    z[7,6,6]  R2370     1.7950646579265594e-02
    z[7,6,6]  R2371     4.2042294144630432e-01
    z[7,6,6]  R2372     -1.0060324519872665e-01
    z[7,6,6]  R2373     1.8184538930654526e-02
    z[7,6,6]  R2374     2.5367733836174011e-01
    z[7,6,6]  R2375     1.5950077772140503e-01
    z[7,6,6]  R2376     -3.7078243494033813e-01
    z[7,6,6]  R2377     -1.3133244216442108e-01
    z[7,6,6]  R2378     -4.3709173798561096e-02
    z[7,6,6]  R2379     0.423032283782959
    z[7,6,6]  R2380     1.6708987951278687e-01
    z[7,6,6]  R2381     3.0549925565719604e-01
    z[7,6,6]  R2382     -1.5334303677082062e-01
    z[7,6,6]  R2383     -3.6709284782409668e-01
    z[7,6,6]  R2384     1.2286590039730072e-01
    z[7,6,6]  R2385     -6.7497797310352325e-02
    z[7,6,6]  R2386     3.1256254762411118e-02
    z[7,6,6]  R2387     2.6256346702575684e-01
    z[7,6,6]  R2388     4.8001569509506226e-01
    z[7,6,6]  R2389     4.7469669580459595e-01
    z[7,6,6]  R2390     3.9829116314649582e-02
    z[7,6,6]  R2391     2.2275516390800476e-01
    z[7,6,6]  R2392     -4.2748800478875637e-04
    z[7,6,6]  R2393     -8.9473381638526917e-02
    z[7,6,6]  R2394     9.4732828438282013e-02
    z[7,6,6]  R2395     6.1027163267135620e-01
    z[7,6,6]  R2396     1.5876251459121704e-01
    z[7,6,6]  R2397     3.3920636773109436e-01
    z[7,6,6]  R2398     1.4114594459533691e-01
    z[7,6,6]  R2399     2.1262085065245628e-02
    z[7,6,6]  R2400     -4.5625671744346619e-01
    z[7,6,6]  R2401     -1.3936492800712585e-01
    z[7,8,0]  R65       -1
    z[7,8,0]  R74       1
    z[7,8,0]  R2402     -1
    z[7,8,0]  R2403     1
    z[7,8,0]  R2416     6.2022256851196289e-01
    z[7,8,0]  R2417     6.1659902334213257e-01
    z[7,8,0]  R2418     2.9703339934349060e-01
    z[7,8,0]  R2419     5.4968541860580444e-01
    z[7,8,0]  R2420     6.3667088747024536e-01
    z[7,8,0]  R2421     0.882612943649292
    z[7,8,0]  R2422     -1.4130641520023346e-01
    z[7,8,0]  R2423     8.2938581705093384e-01
    z[7,8,0]  R2424     7.5897300243377686e-01
    z[7,8,0]  R2425     4.2012134194374084e-01
    z[7,8,0]  R2426     -4.9780672788619995e-01
    z[7,8,0]  R2427     -0.572464108467102
    z[7,8,0]  R2428     -4.3742641806602478e-01
    z[7,8,0]  R2429     -3.2142275571823120e-01
    z[7,8,0]  R2430     -1.9069717824459076e-01
    z[7,8,0]  R2431     -3.6926296353340149e-01
    z[7,8,0]  R2432     -2.0503515005111694e-01
    z[7,8,0]  R2433     -0.310046523809433
    z[7,8,0]  R2434     -4.1690936684608459e-01
    z[7,8,0]  R2435     -3.7215346097946167e-01
    z[7,8,0]  R2436     -3.3932819962501526e-01
    z[7,8,0]  R2437     -3.5454162955284119e-01
    z[7,8,0]  R2438     -4.4399699568748474e-01
    z[7,8,0]  R2439     -2.4433828890323639e-01
    z[7,8,0]  R2440     -3.5885170102119446e-01
    z[7,8,0]  R2441     -3.3633485436439514e-01
    z[7,8,0]  R2442     -2.3008981347084045e-01
    z[7,8,0]  R2443     -7.2591103613376617e-02
    z[7,8,0]  R2444     -1.1461601406335831e-01
    z[7,8,0]  R2445     -4.6189066767692566e-01
    z[7,8,0]  R2446     7.5222015380859375e-01
    z[7,8,0]  R2447     -1.1398845165967941e-01
    z[7,8,0]  R2448     9.3784838914871216e-02
    z[7,8,0]  R2449     -2.6202374696731567e-01
    z[7,8,0]  R2450     5.2261631935834885e-02
    z[7,8,0]  R2451     -6.1903566122055054e-02
    z[7,8,0]  R2452     -4.6527091413736343e-02
    z[7,8,0]  R2453     -3.9346495270729065e-01
    z[7,8,0]  R2454     -2.1216526627540588e-01
    z[7,8,0]  R2455     -0.501543402671814
    z[7,8,0]  R2456     -4.9204930663108826e-02
    z[7,8,0]  R2457     -1.2464704364538193e-01
    z[7,8,0]  R2458     2.2177331149578094e-01
    z[7,8,0]  R2459     -4.3282747268676758e-02
    z[7,8,0]  R2460     -3.5235892981290817e-02
    z[7,8,0]  R2461     2.0288916304707527e-02
    z[7,8,0]  R2462     -2.7766540646553040e-01
    z[7,8,0]  R2463     -3.0240246653556824e-01
    z[7,8,0]  R2464     -2.4311359226703644e-01
    z[7,8,0]  R2465     2.4615408480167389e-01
    z[7,8,0]  R2466     7.5349879264831543e-01
    z[7,8,0]  R2467     0.307144433259964
    z[7,8,0]  R2468     2.5218990445137024e-01
    z[7,8,0]  R2469     1.7160646617412567e-02
    z[7,8,0]  R2470     4.0592528879642487e-02
    z[7,8,0]  R2471     7.5310325622558594e-01
    z[7,8,0]  R2472     0.409322589635849
    z[7,8,0]  R2473     1.8494494259357452e-01
    z[7,8,0]  R2474     2.6719310879707336e-01
    z[7,8,0]  R2475     4.4634243845939636e-01
    z[7,8,0]  R2476     -3.0533054471015930e-01
    z[7,8,0]  R2477     -1.7112727463245392e-01
    z[7,8,0]  R2478     -3.9704239368438721e-01
    z[7,8,0]  R2479     -1.7034025490283966e-01
    z[7,8,0]  R2480     -1.6297745704650879e-01
    z[7,8,0]  R2481     -1.6063745319843292e-01
    z[7,8,0]  R2482     -1.8528106808662415e-01
    z[7,8,0]  R2483     -2.2841534018516541e-01
    z[7,8,0]  R2484     -2.7883759140968323e-01
    z[7,8,0]  R2485     -6.5518236160278320e-01
    z[7,8,0]  R2486     5.8571350574493408e-01
    z[7,8,0]  R2487     2.8354993462562561e-01
    z[7,8,0]  R2488     5.8395421504974365e-01
    z[7,8,0]  R2489     5.2461272478103638e-01
    z[7,8,0]  R2490     -5.0638926029205322e-01
    z[7,8,0]  R2491     4.8312941193580627e-01
    z[7,8,0]  R2492     6.8348360061645508e-01
    z[7,8,0]  R2493     4.1684523224830627e-01
    z[7,8,0]  R2494     -4.5816802978515625e-01
    z[7,8,0]  R2495     -0.49376380443573
    z[7,8,0]  R2496     6.7443841695785522e-01
    z[7,8,0]  R2497     7.0656412839889526e-01
    z[7,8,0]  R2498     -2.4325503408908844e-01
    z[7,8,0]  R2499     3.9420586079359055e-02
    z[7,8,0]  R2500     4.8067179322242737e-01
    z[7,8,0]  R2501     4.1502940654754639e-01
    z[7,8,0]  R2502     3.1739464402198792e-01
    z[7,8,0]  R2503     -4.0888100862503052e-01
    z[7,8,0]  R2504     3.8763949275016785e-01
    z[7,8,0]  R2505     -1.2355958670377731e-01
    z[7,8,0]  R2506     4.4388791918754578e-01
    z[7,8,0]  R2507     0.376607209444046
    z[7,8,0]  R2508     -3.8632029294967651e-01
    z[7,8,0]  R2509     -2.6457989215850830e-01
    z[7,8,0]  R2510     2.8549227118492126e-01
    z[7,8,0]  R2511     4.7952511906623840e-01
    z[7,8,0]  R2512     -6.6012746095657349e-01
    z[7,8,0]  R2513     -4.7437986731529236e-01
    z[7,8,0]  R2514     -4.8283296823501587e-01
    z[7,8,0]  R2515     6.6481798887252808e-01
    z[7,8,1]  R66       -1
    z[7,8,1]  R75       1
    z[7,8,1]  R2404     -1
    z[7,8,1]  R2405     1
    z[7,8,1]  R2416     -5.7872150093317032e-02
    z[7,8,1]  R2417     -5.1282203197479248e-01
    z[7,8,1]  R2418     0.0262064840644598
    z[7,8,1]  R2419     3.6335122585296631e-01
    z[7,8,1]  R2420     -1.6931580007076263e-01
    z[7,8,1]  R2421     -0.329165518283844
    z[7,8,1]  R2422     -0.0679888054728508
    z[7,8,1]  R2423     -2.3425427079200745e-01
    z[7,8,1]  R2424     -2.3805886507034302e-01
    z[7,8,1]  R2425     -4.3429568409919739e-01
    z[7,8,1]  R2426     -8.1585150957107544e-01
    z[7,8,1]  R2427     -0.80653977394104
    z[7,8,1]  R2428     -7.6596271991729736e-01
    z[7,8,1]  R2429     -7.6712471246719360e-01
    z[7,8,1]  R2430     -7.3575627803802490e-01
    z[7,8,1]  R2431     -6.4961183071136475e-01
    z[7,8,1]  R2432     -7.3032897710800171e-01
    z[7,8,1]  R2433     -6.7524188756942749e-01
    z[7,8,1]  R2434     -6.3695675134658813e-01
    z[7,8,1]  R2435     -7.0628565549850464e-01
    z[7,8,1]  R2436     8.0494111776351929e-01
    z[7,8,1]  R2437     7.4577414989471436e-01
    z[7,8,1]  R2438     6.8204289674758911e-01
    z[7,8,1]  R2439     8.3312731981277466e-01
    z[7,8,1]  R2440     0.872372567653656
    z[7,8,1]  R2441     0.892861545085907
    z[7,8,1]  R2442     8.3846324682235718e-01
    z[7,8,1]  R2443     8.3353638648986816e-01
    z[7,8,1]  R2444     8.3021491765975952e-01
    z[7,8,1]  R2445     8.0449211597442627e-01
    z[7,8,1]  R2446     1.4912796206772327e-02
    z[7,8,1]  R2447     -1.4350967109203339e-01
    z[7,8,1]  R2448     0.515442430973053
    z[7,8,1]  R2449     -7.1135634183883667e-01
    z[7,8,1]  R2450     7.3089694976806641e-01
    z[7,8,1]  R2451     7.0023673772811890e-01
    z[7,8,1]  R2452     7.3360109329223633e-01
    z[7,8,1]  R2453     3.8575199246406555e-01
    z[7,8,1]  R2454     6.1126559972763062e-01
    z[7,8,1]  R2455     3.4472337365150452e-01
    z[7,8,1]  R2456     -8.0631360411643982e-02
    z[7,8,1]  R2457     2.0715110003948212e-01
    z[7,8,1]  R2458     7.0760160684585571e-01
    z[7,8,1]  R2459     8.5351544618606567e-01
    z[7,8,1]  R2460     -7.6736605167388916e-01
    z[7,8,1]  R2461     -7.7822124958038330e-01
    z[7,8,1]  R2462     4.3269225955009460e-01
    z[7,8,1]  R2463     2.9408836364746094e-01
    z[7,8,1]  R2464     4.7195664048194885e-01
    z[7,8,1]  R2465     6.2477678060531616e-01
    z[7,8,1]  R2466     5.3390890359878540e-01
    z[7,8,1]  R2467     -1.1291924118995667e-01
    z[7,8,1]  R2468     9.5239475369453430e-02
    z[7,8,1]  R2469     3.3926531672477722e-01
    z[7,8,1]  R2470     4.6290901303291321e-01
    z[7,8,1]  R2471     4.4603973627090454e-01
    z[7,8,1]  R2472     -3.7558069825172424e-01
    z[7,8,1]  R2473     -2.9839560389518738e-01
    z[7,8,1]  R2474     3.7120589613914490e-01
    z[7,8,1]  R2475     -2.6726689934730530e-01
    z[7,8,1]  R2476     -9.0453439950942993e-01
    z[7,8,1]  R2477     -9.1103643178939819e-01
    z[7,8,1]  R2478     -0.866890549659729
    z[7,8,1]  R2479     -9.0055418014526367e-01
    z[7,8,1]  R2480     -8.8076150417327881e-01
    z[7,8,1]  R2481     -8.8842248916625977e-01
    z[7,8,1]  R2482     -8.7182438373565674e-01
    z[7,8,1]  R2483     -0.855061948299408
    z[7,8,1]  R2484     -8.2966303825378418e-01
    z[7,8,1]  R2485     -7.3643636703491211e-01
    z[7,8,1]  R2486     -2.8715163469314575e-01
    z[7,8,1]  R2487     -1.7557007074356079e-01
    z[7,8,1]  R2488     -5.1222376525402069e-02
    z[7,8,1]  R2489     1.0439503192901611e-01
    z[7,8,1]  R2490     6.6497230529785156e-01
    z[7,8,1]  R2491     -7.8976178169250488e-01
    z[7,8,1]  R2492     -0.595569372177124
    z[7,8,1]  R2493     4.4834807515144348e-01
    z[7,8,1]  R2494     7.5294440984725952e-01
    z[7,8,1]  R2495     0.756111741065979
    z[7,8,1]  R2496     4.8174926638603210e-01
    z[7,8,1]  R2497     -2.0700308680534363e-01
    z[7,8,1]  R2498     3.3629408478736877e-01
    z[7,8,1]  R2499     -3.3663976192474365e-01
    z[7,8,1]  R2500     -1.3645662367343903e-01
    z[7,8,1]  R2501     4.5533582568168640e-01
    z[7,8,1]  R2502     -5.2777826786041260e-01
    z[7,8,1]  R2503     8.2022237777709961e-01
    z[7,8,1]  R2504     -5.9745508432388306e-01
    z[7,8,1]  R2505     -6.4928692579269409e-01
    z[7,8,1]  R2506     -4.7594240307807922e-01
    z[7,8,1]  R2507     -2.1905189752578735e-01
    z[7,8,1]  R2508     3.1492364406585693e-01
    z[7,8,1]  R2509     3.3113875985145569e-01
    z[7,8,1]  R2510     -7.1422350406646729e-01
    z[7,8,1]  R2511     -5.2346724271774292e-01
    z[7,8,1]  R2512     6.4730447530746460e-01
    z[7,8,1]  R2513     5.1535248756408691e-01
    z[7,8,1]  R2514     5.5950152873992920e-01
    z[7,8,1]  R2515     -4.5236143469810486e-01
    z[7,8,2]  R67       -1
    z[7,8,2]  R76       1
    z[7,8,2]  R2406     -1
    z[7,8,2]  R2407     1
    z[7,8,2]  R2416     4.7265261411666870e-01
    z[7,8,2]  R2417     1.7059187591075897e-01
    z[7,8,2]  R2418     2.7126777172088623e-01
    z[7,8,2]  R2419     1.5518426895141602e-01
    z[7,8,2]  R2420     1.0871021449565887e-01
    z[7,8,2]  R2421     -6.2821321189403534e-02
    z[7,8,2]  R2422     6.1464405059814453e-01
    z[7,8,2]  R2423     -3.1405130028724670e-01
    z[7,8,2]  R2424     1.7545676231384277e-01
    z[7,8,2]  R2425     -8.9660741388797760e-02
    z[7,8,2]  R2426     8.6172811686992645e-02
    z[7,8,2]  R2427     -6.2457986176013947e-02
    z[7,8,2]  R2428     2.3516632616519928e-01
    z[7,8,2]  R2429     -7.1627877652645111e-02
    z[7,8,2]  R2430     2.6620075106620789e-02
    z[7,8,2]  R2431     2.4896752834320068e-01
    z[7,8,2]  R2432     7.0647731423377991e-02
    z[7,8,2]  R2433     -4.3897065520286560e-01
    z[7,8,2]  R2434     -2.5264355540275574e-01
    z[7,8,2]  R2435     -3.8364082574844360e-01
    z[7,8,2]  R2436     3.7506440281867981e-01
    z[7,8,2]  R2437     4.0297257900238037e-01
    z[7,8,2]  R2438     2.5528374314308167e-01
    z[7,8,2]  R2439     1.5336585044860840e-01
    z[7,8,2]  R2440     1.8986490368843079e-01
    z[7,8,2]  R2441     9.0302256867289543e-03
    z[7,8,2]  R2442     2.9375827312469482e-01
    z[7,8,2]  R2443     3.5538288950920105e-01
    z[7,8,2]  R2444     4.1185724735260010e-01
    z[7,8,2]  R2445     -7.0786923170089722e-02
    z[7,8,2]  R2446     -2.2646564990282059e-02
    z[7,8,2]  R2447     4.0609481930732727e-01
    z[7,8,2]  R2448     5.4534208774566650e-01
    z[7,8,2]  R2449     -2.2798979282379150e-01
    z[7,8,2]  R2450     -2.6518395543098450e-01
    z[7,8,2]  R2451     5.8104771375656128e-01
    z[7,8,2]  R2452     0.125529944896698
    z[7,8,2]  R2453     -1.5523053705692291e-01
    z[7,8,2]  R2454     -7.1677933447062969e-03
    z[7,8,2]  R2455     -1.0918294638395309e-01
    z[7,8,2]  R2456     0.0843895822763443
    z[7,8,2]  R2457     1.9237776100635529e-01
    z[7,8,2]  R2458     3.7106525897979736e-01
    z[7,8,2]  R2459     2.9694685339927673e-01
    z[7,8,2]  R2460     4.4253346323966980e-01
    z[7,8,2]  R2461     -2.8792685270309448e-01
    z[7,8,2]  R2462     7.1017062664031982e-01
    z[7,8,2]  R2463     -3.3727708458900452e-01
    z[7,8,2]  R2464     -3.5415071249008179e-01
    z[7,8,2]  R2465     -3.4223309159278870e-01
    z[7,8,2]  R2466     -4.5283399522304535e-02
    z[7,8,2]  R2467     3.3473870158195496e-01
    z[7,8,2]  R2468     5.7471507787704468e-01
    z[7,8,2]  R2469     5.6111335754394531e-01
    z[7,8,2]  R2470     6.4216136932373047e-01
    z[7,8,2]  R2471     5.1232177764177322e-02
    z[7,8,2]  R2472     2.9302367568016052e-01
    z[7,8,2]  R2473     3.7862551212310791e-01
    z[7,8,2]  R2474     5.2351778745651245e-01
    z[7,8,2]  R2475     1.1340779066085815e-01
    z[7,8,2]  R2476     -3.4694414585828781e-02
    z[7,8,2]  R2477     -2.3301114141941071e-01
    z[7,8,2]  R2478     -5.4809297434985638e-03
    z[7,8,2]  R2479     -1.3062655925750732e-01
    z[7,8,2]  R2480     -3.1449711322784424e-01
    z[7,8,2]  R2481     -1.4832252264022827e-01
    z[7,8,2]  R2482     -1.4843389391899109e-01
    z[7,8,2]  R2483     -0.200262188911438
    z[7,8,2]  R2484     -2.0472073554992676e-01
    z[7,8,2]  R2485     2.5710277259349823e-02
    z[7,8,2]  R2486     4.2051258683204651e-01
    z[7,8,2]  R2487     5.9493917226791382e-01
    z[7,8,2]  R2488     2.7369165420532227e-01
    z[7,8,2]  R2489     7.1624934673309326e-01
    z[7,8,2]  R2490     4.4915539026260376e-01
    z[7,8,2]  R2491     1.2079031206667423e-02
    z[7,8,2]  R2492     -0.0837479680776596
    z[7,8,2]  R2493     -9.6484325826168060e-02
    z[7,8,2]  R2494     0.119090735912323
    z[7,8,2]  R2495     1.2360082007944584e-02
    z[7,8,2]  R2496     -0.00766489002853632
    z[7,8,2]  R2497     5.0639349222183228e-01
    z[7,8,2]  R2498     8.1966572999954224e-01
    z[7,8,2]  R2499     6.4619135856628418e-01
    z[7,8,2]  R2500     -2.9444175306707621e-03
    z[7,8,2]  R2501     6.7845833301544189e-01
    z[7,8,2]  R2502     1.3194097578525543e-01
    z[7,8,2]  R2503     1.8230533599853516e-01
    z[7,8,2]  R2504     0.210468590259552
    z[7,8,2]  R2505     5.4060208797454834e-01
    z[7,8,2]  R2506     3.1908458471298218e-01
    z[7,8,2]  R2507     3.0309337377548218e-01
    z[7,8,2]  R2508     7.4047005176544189e-01
    z[7,8,2]  R2509     5.6868463754653931e-01
    z[7,8,2]  R2510     2.9122796654701233e-01
    z[7,8,2]  R2511     5.1562881469726562e-01
    z[7,8,2]  R2512     1.3450199365615845e-01
    z[7,8,2]  R2513     1.6099503636360168e-01
    z[7,8,2]  R2514     -6.8838261067867279e-02
    z[7,8,2]  R2515     -4.3100094795227051e-01
    z[7,8,3]  R68       -1
    z[7,8,3]  R77       1
    z[7,8,3]  R2408     -1
    z[7,8,3]  R2409     1
    z[7,8,3]  R2416     0.564596951007843
    z[7,8,3]  R2417     5.1371496915817261e-01
    z[7,8,3]  R2418     6.0861396789550781e-01
    z[7,8,3]  R2419     6.4744567871093750e-01
    z[7,8,3]  R2420     5.3467601537704468e-01
    z[7,8,3]  R2421     2.5986871123313904e-01
    z[7,8,3]  R2422     6.7782843112945557e-01
    z[7,8,3]  R2423     2.3131449520587921e-01
    z[7,8,3]  R2424     1.5036433935165405e-01
    z[7,8,3]  R2425     0.316175639629364
    z[7,8,3]  R2426     -1.6702687740325928e-01
    z[7,8,3]  R2427     -2.5385264307260513e-02
    z[7,8,3]  R2428     0.131901815533638
    z[7,8,3]  R2429     -4.6181580424308777e-01
    z[7,8,3]  R2430     -5.9974139928817749e-01
    z[7,8,3]  R2431     -1.7495591938495636e-01
    z[7,8,3]  R2432     -2.9178082942962646e-01
    z[7,8,3]  R2433     -2.7795532345771790e-01
    z[7,8,3]  R2434     -4.1714288294315338e-02
    z[7,8,3]  R2435     4.8548586666584015e-02
    z[7,8,3]  R2436     -1.4104346930980682e-01
    z[7,8,3]  R2437     -3.3874134533107281e-03
    z[7,8,3]  R2438     2.5828611850738525e-01
    z[7,8,3]  R2439     -1.5882736444473267e-01
    z[7,8,3]  R2440     -0.0272738728672266
    z[7,8,3]  R2441     -8.0274511128664017e-03
    z[7,8,3]  R2442     -1.7618638277053833e-01
    z[7,8,3]  R2443     3.0444784089922905e-02
    z[7,8,3]  R2444     -2.2624140977859497e-01
    z[7,8,3]  R2445     1.8799732625484467e-01
    z[7,8,3]  R2446     5.5978453159332275e-01
    z[7,8,3]  R2447     5.4143774509429932e-01
    z[7,8,3]  R2448     3.4446281194686890e-01
    z[7,8,3]  R2449     -4.4442677497863770e-01
    z[7,8,3]  R2450     4.7526496648788452e-01
    z[7,8,3]  R2451     2.1938085556030273e-01
    z[7,8,3]  R2452     5.9873424470424652e-03
    z[7,8,3]  R2453     5.9109628200531006e-01
    z[7,8,3]  R2454     2.5889626145362854e-01
    z[7,8,3]  R2455     7.3483932018280029e-01
    z[7,8,3]  R2456     9.8674345016479492e-01
    z[7,8,3]  R2457     9.4138717651367188e-01
    z[7,8,3]  R2458     4.4672787189483643e-01
    z[7,8,3]  R2459     1.3829560577869415e-01
    z[7,8,3]  R2460     -3.0289649963378906e-01
    z[7,8,3]  R2461     1.8216690421104431e-01
    z[7,8,3]  R2462     1.1730867624282837e-01
    z[7,8,3]  R2463     -7.7046173810958862e-01
    z[7,8,3]  R2464     -6.0686582326889038e-01
    z[7,8,3]  R2465     -6.3158321380615234e-01
    z[7,8,3]  R2466     2.9557514190673828e-01
    z[7,8,3]  R2467     0.511228084564209
    z[7,8,3]  R2468     3.1941589713096619e-01
    z[7,8,3]  R2469     1.8191672861576080e-01
    z[7,8,3]  R2470     2.5957101583480835e-01
    z[7,8,3]  R2471     -1.8496680259704590e-01
    z[7,8,3]  R2472     2.1793392300605774e-01
    z[7,8,3]  R2473     2.8237605094909668e-01
    z[7,8,3]  R2474     3.6248272657394409e-01
    z[7,8,3]  R2475     1.5013046562671661e-01
    z[7,8,3]  R2476     -2.2524642944335938e-01
    z[7,8,3]  R2477     1.7526608705520630e-01
    z[7,8,3]  R2478     -1.3580419123172760e-01
    z[7,8,3]  R2479     1.3678257167339325e-01
    z[7,8,3]  R2480     -3.9878997951745987e-02
    z[7,8,3]  R2481     1.4355589635670185e-02
    z[7,8,3]  R2482     2.3384894430637360e-01
    z[7,8,3]  R2483     -3.0689659714698792e-01
    z[7,8,3]  R2484     -2.2202888131141663e-01
    z[7,8,3]  R2485     0.027417017146945
    z[7,8,3]  R2486     3.6058798432350159e-01
    z[7,8,3]  R2487     6.0836231708526611e-01
    z[7,8,3]  R2488     4.7131389379501343e-01
    z[7,8,3]  R2489     0.214554101228714
    z[7,8,3]  R2490     1.1563784629106522e-01
    z[7,8,3]  R2491     2.9142510890960693e-01
    z[7,8,3]  R2492     -1.1412892490625381e-02
    z[7,8,3]  R2493     -3.6228007078170776e-01
    z[7,8,3]  R2494     -3.9543735980987549e-01
    z[7,8,3]  R2495     -1.8169339001178741e-01
    z[7,8,3]  R2496     -4.5411369204521179e-01
    z[7,8,3]  R2497     3.3606874942779541e-01
    z[7,8,3]  R2498     2.1002674102783203e-01
    z[7,8,3]  R2499     5.6889343261718750e-01
    z[7,8,3]  R2500     4.3332943320274353e-01
    z[7,8,3]  R2501     3.4539647400379181e-02
    z[7,8,3]  R2502     3.5232019424438477e-01
    z[7,8,3]  R2503     4.5969886705279350e-03
    z[7,8,3]  R2504     1.3093477487564087e-01
    z[7,8,3]  R2505     2.0541979372501373e-01
    z[7,8,3]  R2506     3.0937123298645020e-01
    z[7,8,3]  R2507     4.8632130026817322e-01
    z[7,8,3]  R2508     2.3699489235877991e-01
    z[7,8,3]  R2509     6.1725121736526489e-01
    z[7,8,3]  R2510     3.8626599311828613e-01
    z[7,8,3]  R2511     -1.5872826799750328e-02
    z[7,8,3]  R2512     -2.7297082543373108e-01
    z[7,8,3]  R2513     -3.3678501844406128e-01
    z[7,8,3]  R2514     -3.4425669908523560e-01
    z[7,8,3]  R2515     -5.6831665337085724e-02
    z[7,8,4]  R69       -1
    z[7,8,4]  R78       1
    z[7,8,4]  R2410     -1
    z[7,8,4]  R2411     1
    z[7,8,4]  R2416     2.0796653628349304e-01
    z[7,8,4]  R2417     -8.3512617275118828e-03
    z[7,8,4]  R2418     -3.1630811095237732e-01
    z[7,8,4]  R2419     2.0905961096286774e-01
    z[7,8,4]  R2420     -6.8013528361916542e-03
    z[7,8,4]  R2421     1.6189047694206238e-01
    z[7,8,4]  R2422     -1.0302327573299408e-01
    z[7,8,4]  R2423     -1.0839579254388809e-01
    z[7,8,4]  R2424     -1.7145258188247681e-01
    z[7,8,4]  R2425     1.2915735132992268e-02
    z[7,8,4]  R2426     -1.1437698453664780e-01
    z[7,8,4]  R2427     -9.7949914634227753e-02
    z[7,8,4]  R2428     2.2429913282394409e-01
    z[7,8,4]  R2429     1.3347357511520386e-01
    z[7,8,4]  R2430     1.7241925001144409e-01
    z[7,8,4]  R2431     2.1686582267284393e-01
    z[7,8,4]  R2432     2.4941425025463104e-01
    z[7,8,4]  R2433     -3.8916151970624924e-03
    z[7,8,4]  R2434     -8.5312649607658386e-02
    z[7,8,4]  R2435     8.5909456014633179e-02
    z[7,8,4]  R2436     1.0042832791805267e-01
    z[7,8,4]  R2437     8.7373502552509308e-02
    z[7,8,4]  R2438     -3.3058132976293564e-02
    z[7,8,4]  R2439     -1.4715763926506042e-01
    z[7,8,4]  R2440     8.5299901664257050e-02
    z[7,8,4]  R2441     -7.5718536972999573e-02
    z[7,8,4]  R2442     2.3704622685909271e-01
    z[7,8,4]  R2443     2.5284444913268089e-02
    z[7,8,4]  R2444     5.5912379175424576e-03
    z[7,8,4]  R2445     -2.6069596409797668e-01
    z[7,8,4]  R2446     -0.0194578655064106
    z[7,8,4]  R2447     -3.4772194921970367e-02
    z[7,8,4]  R2448     -2.1263534203171730e-02
    z[7,8,4]  R2449     1.5456782281398773e-01
    z[7,8,4]  R2450     -2.1729257702827454e-01
    z[7,8,4]  R2451     3.4007257223129272e-01
    z[7,8,4]  R2452     -3.5109040141105652e-01
    z[7,8,4]  R2453     -3.9541909098625183e-01
    z[7,8,4]  R2454     -6.8843239545822144e-01
    z[7,8,4]  R2455     -5.4593872278928757e-02
    z[7,8,4]  R2456     -5.5340502411127090e-02
    z[7,8,4]  R2457     -1.2876252643764019e-02
    z[7,8,4]  R2458     1.7861260101199150e-02
    z[7,8,4]  R2459     -1.6747438907623291e-01
    z[7,8,4]  R2460     3.1184649467468262e-01
    z[7,8,4]  R2461     4.8171025514602661e-01
    z[7,8,4]  R2462     4.5708559453487396e-02
    z[7,8,4]  R2463     2.9470726847648621e-01
    z[7,8,4]  R2464     1.7241300642490387e-01
    z[7,8,4]  R2465     -1.6473142430186272e-02
    z[7,8,4]  R2466     1.4715710654854774e-02
    z[7,8,4]  R2467     -4.6450448036193848e-01
    z[7,8,4]  R2468     -5.1308578252792358e-01
    z[7,8,4]  R2469     -6.5982139110565186e-01
    z[7,8,4]  R2470     -4.9314025044441223e-01
    z[7,8,4]  R2471     4.0272939950227737e-03
    z[7,8,4]  R2472     -6.1621171236038208e-01
    z[7,8,4]  R2473     -6.7005592584609985e-01
    z[7,8,4]  R2474     -6.1298555135726929e-01
    z[7,8,4]  R2475     -7.7415800094604492e-01
    z[7,8,4]  R2476     9.8041877150535583e-02
    z[7,8,4]  R2477     0.0976729765534401
    z[7,8,4]  R2478     5.9816960245370865e-02
    z[7,8,4]  R2479     3.2650753855705261e-01
    z[7,8,4]  R2480     -5.2045132964849472e-02
    z[7,8,4]  R2481     9.0918548405170441e-02
    z[7,8,4]  R2482     3.1808158755302429e-01
    z[7,8,4]  R2483     -1.0641106218099594e-01
    z[7,8,4]  R2484     2.3723126947879791e-01
    z[7,8,4]  R2485     5.1848553121089935e-03
    z[7,8,4]  R2486     0.232549786567688
    z[7,8,4]  R2487     2.1865151822566986e-01
    z[7,8,4]  R2488     1.2797074019908905e-01
    z[7,8,4]  R2489     1.5356892347335815e-01
    z[7,8,4]  R2490     4.4284559786319733e-02
    z[7,8,4]  R2491     1.8996295332908630e-01
    z[7,8,4]  R2492     6.6601976752281189e-02
    z[7,8,4]  R2493     -1.3420465588569641e-01
    z[7,8,4]  R2494     4.3489160016179085e-03
    z[7,8,4]  R2495     1.7702130600810051e-02
    z[7,8,4]  R2496     -1.3463121652603149e-01
    z[7,8,4]  R2497     -1.4478822052478790e-01
    z[7,8,4]  R2498     1.0083559900522232e-01
    z[7,8,4]  R2499     2.5494772195816040e-01
    z[7,8,4]  R2500     -5.0143241882324219e-01
    z[7,8,4]  R2501     6.1852414160966873e-02
    z[7,8,4]  R2502     3.2360956072807312e-01
    z[7,8,4]  R2503     -2.4408391118049622e-01
    z[7,8,4]  R2504     4.0664246678352356e-01
    z[7,8,4]  R2505     5.5780843831598759e-03
    z[7,8,4]  R2506     -5.4525423049926758e-01
    z[7,8,4]  R2507     2.4329267442226410e-01
    z[7,8,4]  R2508     -4.4477835297584534e-02
    z[7,8,4]  R2509     2.0227548480033875e-01
    z[7,8,4]  R2510     3.0241009593009949e-01
    z[7,8,4]  R2511     1.7804567515850067e-01
    z[7,8,4]  R2512     9.8191395401954651e-02
    z[7,8,4]  R2513     -0.257386714220047
    z[7,8,4]  R2514     -4.1155639290809631e-01
    z[7,8,4]  R2515     -1.6819517314434052e-01
    z[7,8,5]  R70       -1
    z[7,8,5]  R79       1
    z[7,8,5]  R2412     -1
    z[7,8,5]  R2413     1
    z[7,8,5]  R2416     1.0952552407979965e-01
    z[7,8,5]  R2417     -3.2058542128652334e-03
    z[7,8,5]  R2418     4.8141273856163025e-01
    z[7,8,5]  R2419     -0.0998157262802124
    z[7,8,5]  R2420     -2.8701263666152954e-01
    z[7,8,5]  R2421     -4.3160140514373779e-02
    z[7,8,5]  R2422     1.8473663926124573e-01
    z[7,8,5]  R2423     2.9781460762023926e-01
    z[7,8,5]  R2424     3.5354730486869812e-01
    z[7,8,5]  R2425     5.2908492088317871e-01
    z[7,8,5]  R2426     1.3210134208202362e-01
    z[7,8,5]  R2427     0.0831405371427536
    z[7,8,5]  R2428     -2.7633768320083618e-01
    z[7,8,5]  R2429     -2.6825129985809326e-01
    z[7,8,5]  R2430     -1.6878819093108177e-02
    z[7,8,5]  R2431     -5.1529240608215332e-01
    z[7,8,5]  R2432     -5.1640772819519043e-01
    z[7,8,5]  R2433     -4.1512230038642883e-01
    z[7,8,5]  R2434     -4.7670522332191467e-01
    z[7,8,5]  R2435     -4.1783046722412109e-01
    z[7,8,5]  R2436     1.6127510368824005e-01
    z[7,8,5]  R2437     2.6250478625297546e-01
    z[7,8,5]  R2438     3.3466845750808716e-01
    z[7,8,5]  R2439     4.1617873311042786e-01
    z[7,8,5]  R2440     1.8237130343914032e-01
    z[7,8,5]  R2441     2.0769244432449341e-01
    z[7,8,5]  R2442     0.0785713791847229
    z[7,8,5]  R2443     -2.3665902018547058e-01
    z[7,8,5]  R2444     -8.6512090638279915e-03
    z[7,8,5]  R2445     -1.6749377548694611e-01
    z[7,8,5]  R2446     3.0255937576293945e-01
    z[7,8,5]  R2447     6.2148499488830566e-01
    z[7,8,5]  R2448     -1.7706012725830078e-01
    z[7,8,5]  R2449     -2.0281611010432243e-02
    z[7,8,5]  R2450     2.8980734944343567e-01
    z[7,8,5]  R2451     -6.6166333854198456e-02
    z[7,8,5]  R2452     3.4562689065933228e-01
    z[7,8,5]  R2453     0.0786033347249031
    z[7,8,5]  R2454     -1.0985479503870010e-01
    z[7,8,5]  R2455     -2.1916307508945465e-01
    z[7,8,5]  R2456     -1.7077222466468811e-02
    z[7,8,5]  R2457     -1.3364957273006439e-01
    z[7,8,5]  R2458     -1.6446934640407562e-01
    z[7,8,5]  R2459     3.2586103677749634e-01
    z[7,8,5]  R2460     -1.9349161535501480e-02
    z[7,8,5]  R2461     -2.0564547181129456e-01
    z[7,8,5]  R2462     4.5173144340515137e-01
    z[7,8,5]  R2463     1.2901437282562256e-01
    z[7,8,5]  R2464     -2.5292432308197021e-01
    z[7,8,5]  R2465     -1.4887933433055878e-01
    z[7,8,5]  R2466     -2.2283443808555603e-01
    z[7,8,5]  R2467     -4.2021080851554871e-01
    z[7,8,5]  R2468     -2.4339118599891663e-01
    z[7,8,5]  R2469     1.6859647631645203e-01
    z[7,8,5]  R2470     -8.5380002856254578e-02
    z[7,8,5]  R2471     -2.5385084748268127e-01
    z[7,8,5]  R2472     1.5152811072766781e-02
    z[7,8,5]  R2473     0.334398090839386
    z[7,8,5]  R2474     5.7299923151731491e-02
    z[7,8,5]  R2475     1.1835353076457977e-01
    z[7,8,5]  R2476     -1.6442918777465820e-01
    z[7,8,5]  R2477     -1.0862501710653305e-01
    z[7,8,5]  R2478     4.9955964088439941e-02
    z[7,8,5]  R2479     -1.2794810533523560e-01
    z[7,8,5]  R2480     -2.8526043891906738e-01
    z[7,8,5]  R2481     -3.8474711775779724e-01
    z[7,8,5]  R2482     1.3758680224418640e-01
    z[7,8,5]  R2483     2.8761990368366241e-02
    z[7,8,5]  R2484     2.3101963102817535e-01
    z[7,8,5]  R2485     1.3659349083900452e-01
    z[7,8,5]  R2486     -5.3563795983791351e-02
    z[7,8,5]  R2487     -1.1258027702569962e-01
    z[7,8,5]  R2488     -3.9664259552955627e-01
    z[7,8,5]  R2489     -3.5026380419731140e-01
    z[7,8,5]  R2490     2.3329722881317139e-01
    z[7,8,5]  R2491     -1.4275322854518890e-01
    z[7,8,5]  R2492     -3.8245955109596252e-01
    z[7,8,5]  R2493     6.7891335487365723e-01
    z[7,8,5]  R2494     0.228000208735466
    z[7,8,5]  R2495     2.6723757386207581e-01
    z[7,8,5]  R2496     2.5089517235755920e-01
    z[7,8,5]  R2497     -5.5038008838891983e-02
    z[7,8,5]  R2498     -1.2910473346710205e-01
    z[7,8,5]  R2499     -2.3100826144218445e-01
    z[7,8,5]  R2500     2.5525811314582825e-01
    z[7,8,5]  R2501     3.9080002903938293e-01
    z[7,8,5]  R2502     -5.7665330171585083e-01
    z[7,8,5]  R2503     1.8812340497970581e-01
    z[7,8,5]  R2504     -0.451568603515625
    z[7,8,5]  R2505     4.5929422974586487e-01
    z[7,8,5]  R2506     2.4407865107059479e-01
    z[7,8,5]  R2507     -6.4954203367233276e-01
    z[7,8,5]  R2508     -2.0454682409763336e-02
    z[7,8,5]  R2509     -1.6836887598037720e-01
    z[7,8,5]  R2510     -2.3943383991718292e-01
    z[7,8,5]  R2511     -2.2156395018100739e-01
    z[7,8,5]  R2512     1.6375060379505157e-01
    z[7,8,5]  R2513     5.4560887813568115e-01
    z[7,8,5]  R2514     2.3006257414817810e-01
    z[7,8,5]  R2515     8.1063613295555115e-02
    z[7,8,6]  R71       -1
    z[7,8,6]  R80       1
    z[7,8,6]  R2414     -1
    z[7,8,6]  R2415     1
    z[7,8,6]  R2416     1.2065856903791428e-01
    z[7,8,6]  R2417     -2.5245729088783264e-01
    z[7,8,6]  R2418     -3.6780178546905518e-01
    z[7,8,6]  R2419     2.6245898008346558e-01
    z[7,8,6]  R2420     -0.431118905544281
    z[7,8,6]  R2421     1.1443287134170532e-01
    z[7,8,6]  R2422     -3.0566301941871643e-01
    z[7,8,6]  R2423     6.8310797214508057e-02
    z[7,8,6]  R2424     -3.9937660098075867e-01
    z[7,8,6]  R2425     4.9677121639251709e-01
    z[7,8,6]  R2426     -1.4393849670886993e-01
    z[7,8,6]  R2427     2.6950417086482048e-02
    z[7,8,6]  R2428     1.5028476715087891e-01
    z[7,8,6]  R2429     5.3693549707531929e-03
    z[7,8,6]  R2430     -1.7856544256210327e-01
    z[7,8,6]  R2431     -1.9104431569576263e-01
    z[7,8,6]  R2432     -0.0746225118637085
    z[7,8,6]  R2433     -7.4989609420299530e-02
    z[7,8,6]  R2434     -3.4695494174957275e-01
    z[7,8,6]  R2435     1.7652879655361176e-01
    z[7,8,6]  R2436     2.0065940916538239e-01
    z[7,8,6]  R2437     2.8138899803161621e-01
    z[7,8,6]  R2438     3.0447763204574585e-01
    z[7,8,6]  R2439     5.0895728170871735e-02
    z[7,8,6]  R2440     -1.8128305673599243e-01
    z[7,8,6]  R2441     2.0164723694324493e-01
    z[7,8,6]  R2442     -2.5364974141120911e-01
    z[7,8,6]  R2443     -3.4070074558258057e-01
    z[7,8,6]  R2444     -2.7692726254463196e-01
    z[7,8,6]  R2445     5.5489383637905121e-02
    z[7,8,6]  R2446     1.6778001189231873e-01
    z[7,8,6]  R2447     3.4769383072853088e-01
    z[7,8,6]  R2448     -5.2694267034530640e-01
    z[7,8,6]  R2449     3.8925391435623169e-01
    z[7,8,6]  R2450     1.8882460892200470e-01
    z[7,8,6]  R2451     -8.0523900687694550e-03
    z[7,8,6]  R2452     -4.4849586486816406e-01
    z[7,8,6]  R2453     4.0044292807579041e-01
    z[7,8,6]  R2454     -1.6809058189392090e-01
    z[7,8,6]  R2455     1.6339325904846191e-01
    z[7,8,6]  R2456     8.3301074802875519e-02
    z[7,8,6]  R2457     1.7445525154471397e-02
    z[7,8,6]  R2458     -2.9239067435264587e-01
    z[7,8,6]  R2459     -1.6763594746589661e-01
    z[7,8,6]  R2460     0.157171830534935
    z[7,8,6]  R2461     5.9484452009201050e-02
    z[7,8,6]  R2462     1.0688801854848862e-01
    z[7,8,6]  R2463     -1.0583240538835526e-01
    z[7,8,6]  R2464     3.6158952116966248e-01
    z[7,8,6]  R2465     -1.0297979414463043e-01
    z[7,8,6]  R2466     -8.8847614824771881e-02
    z[7,8,6]  R2467     -3.5660311579704285e-01
    z[7,8,6]  R2468     -4.1534259915351868e-01
    z[7,8,6]  R2469     -2.6995116472244263e-01
    z[7,8,6]  R2470     -2.3203879594802856e-01
    z[7,8,6]  R2471     3.6412918567657471e-01
    z[7,8,6]  R2472     -4.2200666666030884e-01
    z[7,8,6]  R2473     -3.0473735928535461e-01
    z[7,8,6]  R2474     0.0794663280248642
    z[7,8,6]  R2475     -2.8393331170082092e-01
    z[7,8,6]  R2476     1.3920005876570940e-03
    z[7,8,6]  R2477     1.8540833890438080e-01
    z[7,8,6]  R2478     -2.5751054286956787e-01
    z[7,8,6]  R2479     3.5152930766344070e-02
    z[7,8,6]  R2480     1.1452741920948029e-01
    z[7,8,6]  R2481     7.9993076622486115e-02
    z[7,8,6]  R2482     9.3643620610237122e-02
    z[7,8,6]  R2483     2.6505556702613831e-01
    z[7,8,6]  R2484     1.8180431425571442e-01
    z[7,8,6]  R2485     9.1106317937374115e-02
    z[7,8,6]  R2486     4.5899960398674011e-01
    z[7,8,6]  R2487     3.2285347580909729e-01
    z[7,8,6]  R2488     4.3084564805030823e-01
    z[7,8,6]  R2489     9.2565260827541351e-02
    z[7,8,6]  R2490     1.7285913228988647e-01
    z[7,8,6]  R2491     3.6376565694808960e-02
    z[7,8,6]  R2492     -1.4245083928108215e-01
    z[7,8,6]  R2493     -7.5721487402915955e-02
    z[7,8,6]  R2494     2.4506205692887306e-02
    z[7,8,6]  R2495     2.8213104605674744e-01
    z[7,8,6]  R2496     -1.6030804812908173e-01
    z[7,8,6]  R2497     2.5406202673912048e-01
    z[7,8,6]  R2498     -2.9143482446670532e-01
    z[7,8,6]  R2499     -1.5985479950904846e-01
    z[7,8,6]  R2500     4.9594348669052124e-01
    z[7,8,6]  R2501     -4.8691403120756149e-02
    z[7,8,6]  R2502     -2.0474494993686676e-01
    z[7,8,6]  R2503     0.178403839468956
    z[7,8,6]  R2504     -2.4913826584815979e-01
    z[7,8,6]  R2505     1.3315147161483765e-01
    z[7,8,6]  R2506     -1.4845924079418182e-01
    z[7,8,6]  R2507     -2.6704590767621994e-02
    z[7,8,6]  R2508     -3.8042172789573669e-01
    z[7,8,6]  R2509     2.1605546772480011e-01
    z[7,8,6]  R2510     -1.5994818508625031e-01
    z[7,8,6]  R2511     -3.8616311550140381e-01
    z[7,8,6]  R2512     -1.2715712189674377e-01
    z[7,8,6]  R2513     -7.8070342540740967e-02
    z[7,8,6]  R2514     -0.329046368598938
    z[7,8,6]  R2515     3.5990753769874573e-01
    z[8,7,0]  R65       1
    z[8,7,0]  R74       -1
    z[8,7,0]  R2516     -1
    z[8,7,0]  R2517     1
    z[8,7,0]  R2530     7.5349879264831543e-01
    z[8,7,0]  R2531     0.307144433259964
    z[8,7,0]  R2532     2.5218990445137024e-01
    z[8,7,0]  R2533     1.7160646617412567e-02
    z[8,7,0]  R2534     4.0592528879642487e-02
    z[8,7,0]  R2535     7.5310325622558594e-01
    z[8,7,0]  R2536     0.409322589635849
    z[8,7,0]  R2537     1.8494494259357452e-01
    z[8,7,0]  R2538     2.6719310879707336e-01
    z[8,7,0]  R2539     4.4634243845939636e-01
    z[8,7,0]  R2540     -3.0533054471015930e-01
    z[8,7,0]  R2541     -1.7112727463245392e-01
    z[8,7,0]  R2542     -3.9704239368438721e-01
    z[8,7,0]  R2543     -1.7034025490283966e-01
    z[8,7,0]  R2544     -1.6297745704650879e-01
    z[8,7,0]  R2545     -1.6063745319843292e-01
    z[8,7,0]  R2546     -1.8528106808662415e-01
    z[8,7,0]  R2547     -2.2841534018516541e-01
    z[8,7,0]  R2548     -2.7883759140968323e-01
    z[8,7,0]  R2549     -6.5518236160278320e-01
    z[8,7,0]  R2550     5.8571350574493408e-01
    z[8,7,0]  R2551     2.8354993462562561e-01
    z[8,7,0]  R2552     5.8395421504974365e-01
    z[8,7,0]  R2553     5.2461272478103638e-01
    z[8,7,0]  R2554     -5.0638926029205322e-01
    z[8,7,0]  R2555     4.8312941193580627e-01
    z[8,7,0]  R2556     6.8348360061645508e-01
    z[8,7,0]  R2557     4.1684523224830627e-01
    z[8,7,0]  R2558     -4.5816802978515625e-01
    z[8,7,0]  R2559     -0.49376380443573
    z[8,7,0]  R2560     6.7443841695785522e-01
    z[8,7,0]  R2561     7.0656412839889526e-01
    z[8,7,0]  R2562     -2.4325503408908844e-01
    z[8,7,0]  R2563     3.9420586079359055e-02
    z[8,7,0]  R2564     4.8067179322242737e-01
    z[8,7,0]  R2565     4.1502940654754639e-01
    z[8,7,0]  R2566     3.1739464402198792e-01
    z[8,7,0]  R2567     -4.0888100862503052e-01
    z[8,7,0]  R2568     3.8763949275016785e-01
    z[8,7,0]  R2569     -1.2355958670377731e-01
    z[8,7,0]  R2570     4.4388791918754578e-01
    z[8,7,0]  R2571     0.376607209444046
    z[8,7,0]  R2572     -3.8632029294967651e-01
    z[8,7,0]  R2573     -2.6457989215850830e-01
    z[8,7,0]  R2574     2.8549227118492126e-01
    z[8,7,0]  R2575     4.7952511906623840e-01
    z[8,7,0]  R2576     -6.6012746095657349e-01
    z[8,7,0]  R2577     -4.7437986731529236e-01
    z[8,7,0]  R2578     -4.8283296823501587e-01
    z[8,7,0]  R2579     6.6481798887252808e-01
    z[8,7,0]  R2580     6.2022256851196289e-01
    z[8,7,0]  R2581     6.1659902334213257e-01
    z[8,7,0]  R2582     2.9703339934349060e-01
    z[8,7,0]  R2583     5.4968541860580444e-01
    z[8,7,0]  R2584     6.3667088747024536e-01
    z[8,7,0]  R2585     0.882612943649292
    z[8,7,0]  R2586     -1.4130641520023346e-01
    z[8,7,0]  R2587     8.2938581705093384e-01
    z[8,7,0]  R2588     7.5897300243377686e-01
    z[8,7,0]  R2589     4.2012134194374084e-01
    z[8,7,0]  R2590     -4.9780672788619995e-01
    z[8,7,0]  R2591     -0.572464108467102
    z[8,7,0]  R2592     -4.3742641806602478e-01
    z[8,7,0]  R2593     -3.2142275571823120e-01
    z[8,7,0]  R2594     -1.9069717824459076e-01
    z[8,7,0]  R2595     -3.6926296353340149e-01
    z[8,7,0]  R2596     -2.0503515005111694e-01
    z[8,7,0]  R2597     -0.310046523809433
    z[8,7,0]  R2598     -4.1690936684608459e-01
    z[8,7,0]  R2599     -3.7215346097946167e-01
    z[8,7,0]  R2600     -3.3932819962501526e-01
    z[8,7,0]  R2601     -3.5454162955284119e-01
    z[8,7,0]  R2602     -4.4399699568748474e-01
    z[8,7,0]  R2603     -2.4433828890323639e-01
    z[8,7,0]  R2604     -3.5885170102119446e-01
    z[8,7,0]  R2605     -3.3633485436439514e-01
    z[8,7,0]  R2606     -2.3008981347084045e-01
    z[8,7,0]  R2607     -7.2591103613376617e-02
    z[8,7,0]  R2608     -1.1461601406335831e-01
    z[8,7,0]  R2609     -4.6189066767692566e-01
    z[8,7,0]  R2610     7.5222015380859375e-01
    z[8,7,0]  R2611     -1.1398845165967941e-01
    z[8,7,0]  R2612     9.3784838914871216e-02
    z[8,7,0]  R2613     -2.6202374696731567e-01
    z[8,7,0]  R2614     5.2261631935834885e-02
    z[8,7,0]  R2615     -6.1903566122055054e-02
    z[8,7,0]  R2616     -4.6527091413736343e-02
    z[8,7,0]  R2617     -3.9346495270729065e-01
    z[8,7,0]  R2618     -2.1216526627540588e-01
    z[8,7,0]  R2619     -0.501543402671814
    z[8,7,0]  R2620     -4.9204930663108826e-02
    z[8,7,0]  R2621     -1.2464704364538193e-01
    z[8,7,0]  R2622     2.2177331149578094e-01
    z[8,7,0]  R2623     -4.3282747268676758e-02
    z[8,7,0]  R2624     -3.5235892981290817e-02
    z[8,7,0]  R2625     2.0288916304707527e-02
    z[8,7,0]  R2626     -2.7766540646553040e-01
    z[8,7,0]  R2627     -3.0240246653556824e-01
    z[8,7,0]  R2628     -2.4311359226703644e-01
    z[8,7,0]  R2629     2.4615408480167389e-01
    z[8,7,1]  R66       1
    z[8,7,1]  R75       -1
    z[8,7,1]  R2518     -1
    z[8,7,1]  R2519     1
    z[8,7,1]  R2530     5.3390890359878540e-01
    z[8,7,1]  R2531     -1.1291924118995667e-01
    z[8,7,1]  R2532     9.5239475369453430e-02
    z[8,7,1]  R2533     3.3926531672477722e-01
    z[8,7,1]  R2534     4.6290901303291321e-01
    z[8,7,1]  R2535     4.4603973627090454e-01
    z[8,7,1]  R2536     -3.7558069825172424e-01
    z[8,7,1]  R2537     -2.9839560389518738e-01
    z[8,7,1]  R2538     3.7120589613914490e-01
    z[8,7,1]  R2539     -2.6726689934730530e-01
    z[8,7,1]  R2540     -9.0453439950942993e-01
    z[8,7,1]  R2541     -9.1103643178939819e-01
    z[8,7,1]  R2542     -0.866890549659729
    z[8,7,1]  R2543     -9.0055418014526367e-01
    z[8,7,1]  R2544     -8.8076150417327881e-01
    z[8,7,1]  R2545     -8.8842248916625977e-01
    z[8,7,1]  R2546     -8.7182438373565674e-01
    z[8,7,1]  R2547     -0.855061948299408
    z[8,7,1]  R2548     -8.2966303825378418e-01
    z[8,7,1]  R2549     -7.3643636703491211e-01
    z[8,7,1]  R2550     -2.8715163469314575e-01
    z[8,7,1]  R2551     -1.7557007074356079e-01
    z[8,7,1]  R2552     -5.1222376525402069e-02
    z[8,7,1]  R2553     1.0439503192901611e-01
    z[8,7,1]  R2554     6.6497230529785156e-01
    z[8,7,1]  R2555     -7.8976178169250488e-01
    z[8,7,1]  R2556     -0.595569372177124
    z[8,7,1]  R2557     4.4834807515144348e-01
    z[8,7,1]  R2558     7.5294440984725952e-01
    z[8,7,1]  R2559     0.756111741065979
    z[8,7,1]  R2560     4.8174926638603210e-01
    z[8,7,1]  R2561     -2.0700308680534363e-01
    z[8,7,1]  R2562     3.3629408478736877e-01
    z[8,7,1]  R2563     -3.3663976192474365e-01
    z[8,7,1]  R2564     -1.3645662367343903e-01
    z[8,7,1]  R2565     4.5533582568168640e-01
    z[8,7,1]  R2566     -5.2777826786041260e-01
    z[8,7,1]  R2567     8.2022237777709961e-01
    z[8,7,1]  R2568     -5.9745508432388306e-01
    z[8,7,1]  R2569     -6.4928692579269409e-01
    z[8,7,1]  R2570     -4.7594240307807922e-01
    z[8,7,1]  R2571     -2.1905189752578735e-01
    z[8,7,1]  R2572     3.1492364406585693e-01
    z[8,7,1]  R2573     3.3113875985145569e-01
    z[8,7,1]  R2574     -7.1422350406646729e-01
    z[8,7,1]  R2575     -5.2346724271774292e-01
    z[8,7,1]  R2576     6.4730447530746460e-01
    z[8,7,1]  R2577     5.1535248756408691e-01
    z[8,7,1]  R2578     5.5950152873992920e-01
    z[8,7,1]  R2579     -4.5236143469810486e-01
    z[8,7,1]  R2580     -5.7872150093317032e-02
    z[8,7,1]  R2581     -5.1282203197479248e-01
    z[8,7,1]  R2582     0.0262064840644598
    z[8,7,1]  R2583     3.6335122585296631e-01
    z[8,7,1]  R2584     -1.6931580007076263e-01
    z[8,7,1]  R2585     -0.329165518283844
    z[8,7,1]  R2586     -0.0679888054728508
    z[8,7,1]  R2587     -2.3425427079200745e-01
    z[8,7,1]  R2588     -2.3805886507034302e-01
    z[8,7,1]  R2589     -4.3429568409919739e-01
    z[8,7,1]  R2590     -8.1585150957107544e-01
    z[8,7,1]  R2591     -0.80653977394104
    z[8,7,1]  R2592     -7.6596271991729736e-01
    z[8,7,1]  R2593     -7.6712471246719360e-01
    z[8,7,1]  R2594     -7.3575627803802490e-01
    z[8,7,1]  R2595     -6.4961183071136475e-01
    z[8,7,1]  R2596     -7.3032897710800171e-01
    z[8,7,1]  R2597     -6.7524188756942749e-01
    z[8,7,1]  R2598     -6.3695675134658813e-01
    z[8,7,1]  R2599     -7.0628565549850464e-01
    z[8,7,1]  R2600     8.0494111776351929e-01
    z[8,7,1]  R2601     7.4577414989471436e-01
    z[8,7,1]  R2602     6.8204289674758911e-01
    z[8,7,1]  R2603     8.3312731981277466e-01
    z[8,7,1]  R2604     0.872372567653656
    z[8,7,1]  R2605     0.892861545085907
    z[8,7,1]  R2606     8.3846324682235718e-01
    z[8,7,1]  R2607     8.3353638648986816e-01
    z[8,7,1]  R2608     8.3021491765975952e-01
    z[8,7,1]  R2609     8.0449211597442627e-01
    z[8,7,1]  R2610     1.4912796206772327e-02
    z[8,7,1]  R2611     -1.4350967109203339e-01
    z[8,7,1]  R2612     0.515442430973053
    z[8,7,1]  R2613     -7.1135634183883667e-01
    z[8,7,1]  R2614     7.3089694976806641e-01
    z[8,7,1]  R2615     7.0023673772811890e-01
    z[8,7,1]  R2616     7.3360109329223633e-01
    z[8,7,1]  R2617     3.8575199246406555e-01
    z[8,7,1]  R2618     6.1126559972763062e-01
    z[8,7,1]  R2619     3.4472337365150452e-01
    z[8,7,1]  R2620     -8.0631360411643982e-02
    z[8,7,1]  R2621     2.0715110003948212e-01
    z[8,7,1]  R2622     7.0760160684585571e-01
    z[8,7,1]  R2623     8.5351544618606567e-01
    z[8,7,1]  R2624     -7.6736605167388916e-01
    z[8,7,1]  R2625     -7.7822124958038330e-01
    z[8,7,1]  R2626     4.3269225955009460e-01
    z[8,7,1]  R2627     2.9408836364746094e-01
    z[8,7,1]  R2628     4.7195664048194885e-01
    z[8,7,1]  R2629     6.2477678060531616e-01
    z[8,7,2]  R67       1
    z[8,7,2]  R76       -1
    z[8,7,2]  R2520     -1
    z[8,7,2]  R2521     1
    z[8,7,2]  R2530     -4.5283399522304535e-02
    z[8,7,2]  R2531     3.3473870158195496e-01
    z[8,7,2]  R2532     5.7471507787704468e-01
    z[8,7,2]  R2533     5.6111335754394531e-01
    z[8,7,2]  R2534     6.4216136932373047e-01
    z[8,7,2]  R2535     5.1232177764177322e-02
    z[8,7,2]  R2536     2.9302367568016052e-01
    z[8,7,2]  R2537     3.7862551212310791e-01
    z[8,7,2]  R2538     5.2351778745651245e-01
    z[8,7,2]  R2539     1.1340779066085815e-01
    z[8,7,2]  R2540     -3.4694414585828781e-02
    z[8,7,2]  R2541     -2.3301114141941071e-01
    z[8,7,2]  R2542     -5.4809297434985638e-03
    z[8,7,2]  R2543     -1.3062655925750732e-01
    z[8,7,2]  R2544     -3.1449711322784424e-01
    z[8,7,2]  R2545     -1.4832252264022827e-01
    z[8,7,2]  R2546     -1.4843389391899109e-01
    z[8,7,2]  R2547     -0.200262188911438
    z[8,7,2]  R2548     -2.0472073554992676e-01
    z[8,7,2]  R2549     2.5710277259349823e-02
    z[8,7,2]  R2550     4.2051258683204651e-01
    z[8,7,2]  R2551     5.9493917226791382e-01
    z[8,7,2]  R2552     2.7369165420532227e-01
    z[8,7,2]  R2553     7.1624934673309326e-01
    z[8,7,2]  R2554     4.4915539026260376e-01
    z[8,7,2]  R2555     1.2079031206667423e-02
    z[8,7,2]  R2556     -0.0837479680776596
    z[8,7,2]  R2557     -9.6484325826168060e-02
    z[8,7,2]  R2558     0.119090735912323
    z[8,7,2]  R2559     1.2360082007944584e-02
    z[8,7,2]  R2560     -0.00766489002853632
    z[8,7,2]  R2561     5.0639349222183228e-01
    z[8,7,2]  R2562     8.1966572999954224e-01
    z[8,7,2]  R2563     6.4619135856628418e-01
    z[8,7,2]  R2564     -2.9444175306707621e-03
    z[8,7,2]  R2565     6.7845833301544189e-01
    z[8,7,2]  R2566     1.3194097578525543e-01
    z[8,7,2]  R2567     1.8230533599853516e-01
    z[8,7,2]  R2568     0.210468590259552
    z[8,7,2]  R2569     5.4060208797454834e-01
    z[8,7,2]  R2570     3.1908458471298218e-01
    z[8,7,2]  R2571     3.0309337377548218e-01
    z[8,7,2]  R2572     7.4047005176544189e-01
    z[8,7,2]  R2573     5.6868463754653931e-01
    z[8,7,2]  R2574     2.9122796654701233e-01
    z[8,7,2]  R2575     5.1562881469726562e-01
    z[8,7,2]  R2576     1.3450199365615845e-01
    z[8,7,2]  R2577     1.6099503636360168e-01
    z[8,7,2]  R2578     -6.8838261067867279e-02
    z[8,7,2]  R2579     -4.3100094795227051e-01
    z[8,7,2]  R2580     4.7265261411666870e-01
    z[8,7,2]  R2581     1.7059187591075897e-01
    z[8,7,2]  R2582     2.7126777172088623e-01
    z[8,7,2]  R2583     1.5518426895141602e-01
    z[8,7,2]  R2584     1.0871021449565887e-01
    z[8,7,2]  R2585     -6.2821321189403534e-02
    z[8,7,2]  R2586     6.1464405059814453e-01
    z[8,7,2]  R2587     -3.1405130028724670e-01
    z[8,7,2]  R2588     1.7545676231384277e-01
    z[8,7,2]  R2589     -8.9660741388797760e-02
    z[8,7,2]  R2590     8.6172811686992645e-02
    z[8,7,2]  R2591     -6.2457986176013947e-02
    z[8,7,2]  R2592     2.3516632616519928e-01
    z[8,7,2]  R2593     -7.1627877652645111e-02
    z[8,7,2]  R2594     2.6620075106620789e-02
    z[8,7,2]  R2595     2.4896752834320068e-01
    z[8,7,2]  R2596     7.0647731423377991e-02
    z[8,7,2]  R2597     -4.3897065520286560e-01
    z[8,7,2]  R2598     -2.5264355540275574e-01
    z[8,7,2]  R2599     -3.8364082574844360e-01
    z[8,7,2]  R2600     3.7506440281867981e-01
    z[8,7,2]  R2601     4.0297257900238037e-01
    z[8,7,2]  R2602     2.5528374314308167e-01
    z[8,7,2]  R2603     1.5336585044860840e-01
    z[8,7,2]  R2604     1.8986490368843079e-01
    z[8,7,2]  R2605     9.0302256867289543e-03
    z[8,7,2]  R2606     2.9375827312469482e-01
    z[8,7,2]  R2607     3.5538288950920105e-01
    z[8,7,2]  R2608     4.1185724735260010e-01
    z[8,7,2]  R2609     -7.0786923170089722e-02
    z[8,7,2]  R2610     -2.2646564990282059e-02
    z[8,7,2]  R2611     4.0609481930732727e-01
    z[8,7,2]  R2612     5.4534208774566650e-01
    z[8,7,2]  R2613     -2.2798979282379150e-01
    z[8,7,2]  R2614     -2.6518395543098450e-01
    z[8,7,2]  R2615     5.8104771375656128e-01
    z[8,7,2]  R2616     0.125529944896698
    z[8,7,2]  R2617     -1.5523053705692291e-01
    z[8,7,2]  R2618     -7.1677933447062969e-03
    z[8,7,2]  R2619     -1.0918294638395309e-01
    z[8,7,2]  R2620     0.0843895822763443
    z[8,7,2]  R2621     1.9237776100635529e-01
    z[8,7,2]  R2622     3.7106525897979736e-01
    z[8,7,2]  R2623     2.9694685339927673e-01
    z[8,7,2]  R2624     4.4253346323966980e-01
    z[8,7,2]  R2625     -2.8792685270309448e-01
    z[8,7,2]  R2626     7.1017062664031982e-01
    z[8,7,2]  R2627     -3.3727708458900452e-01
    z[8,7,2]  R2628     -3.5415071249008179e-01
    z[8,7,2]  R2629     -3.4223309159278870e-01
    z[8,7,3]  R68       1
    z[8,7,3]  R77       -1
    z[8,7,3]  R2522     -1
    z[8,7,3]  R2523     1
    z[8,7,3]  R2530     2.9557514190673828e-01
    z[8,7,3]  R2531     0.511228084564209
    z[8,7,3]  R2532     3.1941589713096619e-01
    z[8,7,3]  R2533     1.8191672861576080e-01
    z[8,7,3]  R2534     2.5957101583480835e-01
    z[8,7,3]  R2535     -1.8496680259704590e-01
    z[8,7,3]  R2536     2.1793392300605774e-01
    z[8,7,3]  R2537     2.8237605094909668e-01
    z[8,7,3]  R2538     3.6248272657394409e-01
    z[8,7,3]  R2539     1.5013046562671661e-01
    z[8,7,3]  R2540     -2.2524642944335938e-01
    z[8,7,3]  R2541     1.7526608705520630e-01
    z[8,7,3]  R2542     -1.3580419123172760e-01
    z[8,7,3]  R2543     1.3678257167339325e-01
    z[8,7,3]  R2544     -3.9878997951745987e-02
    z[8,7,3]  R2545     1.4355589635670185e-02
    z[8,7,3]  R2546     2.3384894430637360e-01
    z[8,7,3]  R2547     -3.0689659714698792e-01
    z[8,7,3]  R2548     -2.2202888131141663e-01
    z[8,7,3]  R2549     0.027417017146945
    z[8,7,3]  R2550     3.6058798432350159e-01
    z[8,7,3]  R2551     6.0836231708526611e-01
    z[8,7,3]  R2552     4.7131389379501343e-01
    z[8,7,3]  R2553     0.214554101228714
    z[8,7,3]  R2554     1.1563784629106522e-01
    z[8,7,3]  R2555     2.9142510890960693e-01
    z[8,7,3]  R2556     -1.1412892490625381e-02
    z[8,7,3]  R2557     -3.6228007078170776e-01
    z[8,7,3]  R2558     -3.9543735980987549e-01
    z[8,7,3]  R2559     -1.8169339001178741e-01
    z[8,7,3]  R2560     -4.5411369204521179e-01
    z[8,7,3]  R2561     3.3606874942779541e-01
    z[8,7,3]  R2562     2.1002674102783203e-01
    z[8,7,3]  R2563     5.6889343261718750e-01
    z[8,7,3]  R2564     4.3332943320274353e-01
    z[8,7,3]  R2565     3.4539647400379181e-02
    z[8,7,3]  R2566     3.5232019424438477e-01
    z[8,7,3]  R2567     4.5969886705279350e-03
    z[8,7,3]  R2568     1.3093477487564087e-01
    z[8,7,3]  R2569     2.0541979372501373e-01
    z[8,7,3]  R2570     3.0937123298645020e-01
    z[8,7,3]  R2571     4.8632130026817322e-01
    z[8,7,3]  R2572     2.3699489235877991e-01
    z[8,7,3]  R2573     6.1725121736526489e-01
    z[8,7,3]  R2574     3.8626599311828613e-01
    z[8,7,3]  R2575     -1.5872826799750328e-02
    z[8,7,3]  R2576     -2.7297082543373108e-01
    z[8,7,3]  R2577     -3.3678501844406128e-01
    z[8,7,3]  R2578     -3.4425669908523560e-01
    z[8,7,3]  R2579     -5.6831665337085724e-02
    z[8,7,3]  R2580     0.564596951007843
    z[8,7,3]  R2581     5.1371496915817261e-01
    z[8,7,3]  R2582     6.0861396789550781e-01
    z[8,7,3]  R2583     6.4744567871093750e-01
    z[8,7,3]  R2584     5.3467601537704468e-01
    z[8,7,3]  R2585     2.5986871123313904e-01
    z[8,7,3]  R2586     6.7782843112945557e-01
    z[8,7,3]  R2587     2.3131449520587921e-01
    z[8,7,3]  R2588     1.5036433935165405e-01
    z[8,7,3]  R2589     0.316175639629364
    z[8,7,3]  R2590     -1.6702687740325928e-01
    z[8,7,3]  R2591     -2.5385264307260513e-02
    z[8,7,3]  R2592     0.131901815533638
    z[8,7,3]  R2593     -4.6181580424308777e-01
    z[8,7,3]  R2594     -5.9974139928817749e-01
    z[8,7,3]  R2595     -1.7495591938495636e-01
    z[8,7,3]  R2596     -2.9178082942962646e-01
    z[8,7,3]  R2597     -2.7795532345771790e-01
    z[8,7,3]  R2598     -4.1714288294315338e-02
    z[8,7,3]  R2599     4.8548586666584015e-02
    z[8,7,3]  R2600     -1.4104346930980682e-01
    z[8,7,3]  R2601     -3.3874134533107281e-03
    z[8,7,3]  R2602     2.5828611850738525e-01
    z[8,7,3]  R2603     -1.5882736444473267e-01
    z[8,7,3]  R2604     -0.0272738728672266
    z[8,7,3]  R2605     -8.0274511128664017e-03
    z[8,7,3]  R2606     -1.7618638277053833e-01
    z[8,7,3]  R2607     3.0444784089922905e-02
    z[8,7,3]  R2608     -2.2624140977859497e-01
    z[8,7,3]  R2609     1.8799732625484467e-01
    z[8,7,3]  R2610     5.5978453159332275e-01
    z[8,7,3]  R2611     5.4143774509429932e-01
    z[8,7,3]  R2612     3.4446281194686890e-01
    z[8,7,3]  R2613     -4.4442677497863770e-01
    z[8,7,3]  R2614     4.7526496648788452e-01
    z[8,7,3]  R2615     2.1938085556030273e-01
    z[8,7,3]  R2616     5.9873424470424652e-03
    z[8,7,3]  R2617     5.9109628200531006e-01
    z[8,7,3]  R2618     2.5889626145362854e-01
    z[8,7,3]  R2619     7.3483932018280029e-01
    z[8,7,3]  R2620     9.8674345016479492e-01
    z[8,7,3]  R2621     9.4138717651367188e-01
    z[8,7,3]  R2622     4.4672787189483643e-01
    z[8,7,3]  R2623     1.3829560577869415e-01
    z[8,7,3]  R2624     -3.0289649963378906e-01
    z[8,7,3]  R2625     1.8216690421104431e-01
    z[8,7,3]  R2626     1.1730867624282837e-01
    z[8,7,3]  R2627     -7.7046173810958862e-01
    z[8,7,3]  R2628     -6.0686582326889038e-01
    z[8,7,3]  R2629     -6.3158321380615234e-01
    z[8,7,4]  R69       1
    z[8,7,4]  R78       -1
    z[8,7,4]  R2524     -1
    z[8,7,4]  R2525     1
    z[8,7,4]  R2530     1.4715710654854774e-02
    z[8,7,4]  R2531     -4.6450448036193848e-01
    z[8,7,4]  R2532     -5.1308578252792358e-01
    z[8,7,4]  R2533     -6.5982139110565186e-01
    z[8,7,4]  R2534     -4.9314025044441223e-01
    z[8,7,4]  R2535     4.0272939950227737e-03
    z[8,7,4]  R2536     -6.1621171236038208e-01
    z[8,7,4]  R2537     -6.7005592584609985e-01
    z[8,7,4]  R2538     -6.1298555135726929e-01
    z[8,7,4]  R2539     -7.7415800094604492e-01
    z[8,7,4]  R2540     9.8041877150535583e-02
    z[8,7,4]  R2541     0.0976729765534401
    z[8,7,4]  R2542     5.9816960245370865e-02
    z[8,7,4]  R2543     3.2650753855705261e-01
    z[8,7,4]  R2544     -5.2045132964849472e-02
    z[8,7,4]  R2545     9.0918548405170441e-02
    z[8,7,4]  R2546     3.1808158755302429e-01
    z[8,7,4]  R2547     -1.0641106218099594e-01
    z[8,7,4]  R2548     2.3723126947879791e-01
    z[8,7,4]  R2549     5.1848553121089935e-03
    z[8,7,4]  R2550     0.232549786567688
    z[8,7,4]  R2551     2.1865151822566986e-01
    z[8,7,4]  R2552     1.2797074019908905e-01
    z[8,7,4]  R2553     1.5356892347335815e-01
    z[8,7,4]  R2554     4.4284559786319733e-02
    z[8,7,4]  R2555     1.8996295332908630e-01
    z[8,7,4]  R2556     6.6601976752281189e-02
    z[8,7,4]  R2557     -1.3420465588569641e-01
    z[8,7,4]  R2558     4.3489160016179085e-03
    z[8,7,4]  R2559     1.7702130600810051e-02
    z[8,7,4]  R2560     -1.3463121652603149e-01
    z[8,7,4]  R2561     -1.4478822052478790e-01
    z[8,7,4]  R2562     1.0083559900522232e-01
    z[8,7,4]  R2563     2.5494772195816040e-01
    z[8,7,4]  R2564     -5.0143241882324219e-01
    z[8,7,4]  R2565     6.1852414160966873e-02
    z[8,7,4]  R2566     3.2360956072807312e-01
    z[8,7,4]  R2567     -2.4408391118049622e-01
    z[8,7,4]  R2568     4.0664246678352356e-01
    z[8,7,4]  R2569     5.5780843831598759e-03
    z[8,7,4]  R2570     -5.4525423049926758e-01
    z[8,7,4]  R2571     2.4329267442226410e-01
    z[8,7,4]  R2572     -4.4477835297584534e-02
    z[8,7,4]  R2573     2.0227548480033875e-01
    z[8,7,4]  R2574     3.0241009593009949e-01
    z[8,7,4]  R2575     1.7804567515850067e-01
    z[8,7,4]  R2576     9.8191395401954651e-02
    z[8,7,4]  R2577     -0.257386714220047
    z[8,7,4]  R2578     -4.1155639290809631e-01
    z[8,7,4]  R2579     -1.6819517314434052e-01
    z[8,7,4]  R2580     2.0796653628349304e-01
    z[8,7,4]  R2581     -8.3512617275118828e-03
    z[8,7,4]  R2582     -3.1630811095237732e-01
    z[8,7,4]  R2583     2.0905961096286774e-01
    z[8,7,4]  R2584     -6.8013528361916542e-03
    z[8,7,4]  R2585     1.6189047694206238e-01
    z[8,7,4]  R2586     -1.0302327573299408e-01
    z[8,7,4]  R2587     -1.0839579254388809e-01
    z[8,7,4]  R2588     -1.7145258188247681e-01
    z[8,7,4]  R2589     1.2915735132992268e-02
    z[8,7,4]  R2590     -1.1437698453664780e-01
    z[8,7,4]  R2591     -9.7949914634227753e-02
    z[8,7,4]  R2592     2.2429913282394409e-01
    z[8,7,4]  R2593     1.3347357511520386e-01
    z[8,7,4]  R2594     1.7241925001144409e-01
    z[8,7,4]  R2595     2.1686582267284393e-01
    z[8,7,4]  R2596     2.4941425025463104e-01
    z[8,7,4]  R2597     -3.8916151970624924e-03
    z[8,7,4]  R2598     -8.5312649607658386e-02
    z[8,7,4]  R2599     8.5909456014633179e-02
    z[8,7,4]  R2600     1.0042832791805267e-01
    z[8,7,4]  R2601     8.7373502552509308e-02
    z[8,7,4]  R2602     -3.3058132976293564e-02
    z[8,7,4]  R2603     -1.4715763926506042e-01
    z[8,7,4]  R2604     8.5299901664257050e-02
    z[8,7,4]  R2605     -7.5718536972999573e-02
    z[8,7,4]  R2606     2.3704622685909271e-01
    z[8,7,4]  R2607     2.5284444913268089e-02
    z[8,7,4]  R2608     5.5912379175424576e-03
    z[8,7,4]  R2609     -2.6069596409797668e-01
    z[8,7,4]  R2610     -0.0194578655064106
    z[8,7,4]  R2611     -3.4772194921970367e-02
    z[8,7,4]  R2612     -2.1263534203171730e-02
    z[8,7,4]  R2613     1.5456782281398773e-01
    z[8,7,4]  R2614     -2.1729257702827454e-01
    z[8,7,4]  R2615     3.4007257223129272e-01
    z[8,7,4]  R2616     -3.5109040141105652e-01
    z[8,7,4]  R2617     -3.9541909098625183e-01
    z[8,7,4]  R2618     -6.8843239545822144e-01
    z[8,7,4]  R2619     -5.4593872278928757e-02
    z[8,7,4]  R2620     -5.5340502411127090e-02
    z[8,7,4]  R2621     -1.2876252643764019e-02
    z[8,7,4]  R2622     1.7861260101199150e-02
    z[8,7,4]  R2623     -1.6747438907623291e-01
    z[8,7,4]  R2624     3.1184649467468262e-01
    z[8,7,4]  R2625     4.8171025514602661e-01
    z[8,7,4]  R2626     4.5708559453487396e-02
    z[8,7,4]  R2627     2.9470726847648621e-01
    z[8,7,4]  R2628     1.7241300642490387e-01
    z[8,7,4]  R2629     -1.6473142430186272e-02
    z[8,7,5]  R70       1
    z[8,7,5]  R79       -1
    z[8,7,5]  R2526     -1
    z[8,7,5]  R2527     1
    z[8,7,5]  R2530     -2.2283443808555603e-01
    z[8,7,5]  R2531     -4.2021080851554871e-01
    z[8,7,5]  R2532     -2.4339118599891663e-01
    z[8,7,5]  R2533     1.6859647631645203e-01
    z[8,7,5]  R2534     -8.5380002856254578e-02
    z[8,7,5]  R2535     -2.5385084748268127e-01
    z[8,7,5]  R2536     1.5152811072766781e-02
    z[8,7,5]  R2537     0.334398090839386
    z[8,7,5]  R2538     5.7299923151731491e-02
    z[8,7,5]  R2539     1.1835353076457977e-01
    z[8,7,5]  R2540     -1.6442918777465820e-01
    z[8,7,5]  R2541     -1.0862501710653305e-01
    z[8,7,5]  R2542     4.9955964088439941e-02
    z[8,7,5]  R2543     -1.2794810533523560e-01
    z[8,7,5]  R2544     -2.8526043891906738e-01
    z[8,7,5]  R2545     -3.8474711775779724e-01
    z[8,7,5]  R2546     1.3758680224418640e-01
    z[8,7,5]  R2547     2.8761990368366241e-02
    z[8,7,5]  R2548     2.3101963102817535e-01
    z[8,7,5]  R2549     1.3659349083900452e-01
    z[8,7,5]  R2550     -5.3563795983791351e-02
    z[8,7,5]  R2551     -1.1258027702569962e-01
    z[8,7,5]  R2552     -3.9664259552955627e-01
    z[8,7,5]  R2553     -3.5026380419731140e-01
    z[8,7,5]  R2554     2.3329722881317139e-01
    z[8,7,5]  R2555     -1.4275322854518890e-01
    z[8,7,5]  R2556     -3.8245955109596252e-01
    z[8,7,5]  R2557     6.7891335487365723e-01
    z[8,7,5]  R2558     0.228000208735466
    z[8,7,5]  R2559     2.6723757386207581e-01
    z[8,7,5]  R2560     2.5089517235755920e-01
    z[8,7,5]  R2561     -5.5038008838891983e-02
    z[8,7,5]  R2562     -1.2910473346710205e-01
    z[8,7,5]  R2563     -2.3100826144218445e-01
    z[8,7,5]  R2564     2.5525811314582825e-01
    z[8,7,5]  R2565     3.9080002903938293e-01
    z[8,7,5]  R2566     -5.7665330171585083e-01
    z[8,7,5]  R2567     1.8812340497970581e-01
    z[8,7,5]  R2568     -0.451568603515625
    z[8,7,5]  R2569     4.5929422974586487e-01
    z[8,7,5]  R2570     2.4407865107059479e-01
    z[8,7,5]  R2571     -6.4954203367233276e-01
    z[8,7,5]  R2572     -2.0454682409763336e-02
    z[8,7,5]  R2573     -1.6836887598037720e-01
    z[8,7,5]  R2574     -2.3943383991718292e-01
    z[8,7,5]  R2575     -2.2156395018100739e-01
    z[8,7,5]  R2576     1.6375060379505157e-01
    z[8,7,5]  R2577     5.4560887813568115e-01
    z[8,7,5]  R2578     2.3006257414817810e-01
    z[8,7,5]  R2579     8.1063613295555115e-02
    z[8,7,5]  R2580     1.0952552407979965e-01
    z[8,7,5]  R2581     -3.2058542128652334e-03
    z[8,7,5]  R2582     4.8141273856163025e-01
    z[8,7,5]  R2583     -0.0998157262802124
    z[8,7,5]  R2584     -2.8701263666152954e-01
    z[8,7,5]  R2585     -4.3160140514373779e-02
    z[8,7,5]  R2586     1.8473663926124573e-01
    z[8,7,5]  R2587     2.9781460762023926e-01
    z[8,7,5]  R2588     3.5354730486869812e-01
    z[8,7,5]  R2589     5.2908492088317871e-01
    z[8,7,5]  R2590     1.3210134208202362e-01
    z[8,7,5]  R2591     0.0831405371427536
    z[8,7,5]  R2592     -2.7633768320083618e-01
    z[8,7,5]  R2593     -2.6825129985809326e-01
    z[8,7,5]  R2594     -1.6878819093108177e-02
    z[8,7,5]  R2595     -5.1529240608215332e-01
    z[8,7,5]  R2596     -5.1640772819519043e-01
    z[8,7,5]  R2597     -4.1512230038642883e-01
    z[8,7,5]  R2598     -4.7670522332191467e-01
    z[8,7,5]  R2599     -4.1783046722412109e-01
    z[8,7,5]  R2600     1.6127510368824005e-01
    z[8,7,5]  R2601     2.6250478625297546e-01
    z[8,7,5]  R2602     3.3466845750808716e-01
    z[8,7,5]  R2603     4.1617873311042786e-01
    z[8,7,5]  R2604     1.8237130343914032e-01
    z[8,7,5]  R2605     2.0769244432449341e-01
    z[8,7,5]  R2606     0.0785713791847229
    z[8,7,5]  R2607     -2.3665902018547058e-01
    z[8,7,5]  R2608     -8.6512090638279915e-03
    z[8,7,5]  R2609     -1.6749377548694611e-01
    z[8,7,5]  R2610     3.0255937576293945e-01
    z[8,7,5]  R2611     6.2148499488830566e-01
    z[8,7,5]  R2612     -1.7706012725830078e-01
    z[8,7,5]  R2613     -2.0281611010432243e-02
    z[8,7,5]  R2614     2.8980734944343567e-01
    z[8,7,5]  R2615     -6.6166333854198456e-02
    z[8,7,5]  R2616     3.4562689065933228e-01
    z[8,7,5]  R2617     0.0786033347249031
    z[8,7,5]  R2618     -1.0985479503870010e-01
    z[8,7,5]  R2619     -2.1916307508945465e-01
    z[8,7,5]  R2620     -1.7077222466468811e-02
    z[8,7,5]  R2621     -1.3364957273006439e-01
    z[8,7,5]  R2622     -1.6446934640407562e-01
    z[8,7,5]  R2623     3.2586103677749634e-01
    z[8,7,5]  R2624     -1.9349161535501480e-02
    z[8,7,5]  R2625     -2.0564547181129456e-01
    z[8,7,5]  R2626     4.5173144340515137e-01
    z[8,7,5]  R2627     1.2901437282562256e-01
    z[8,7,5]  R2628     -2.5292432308197021e-01
    z[8,7,5]  R2629     -1.4887933433055878e-01
    z[8,7,6]  R71       1
    z[8,7,6]  R80       -1
    z[8,7,6]  R2528     -1
    z[8,7,6]  R2529     1
    z[8,7,6]  R2530     -8.8847614824771881e-02
    z[8,7,6]  R2531     -3.5660311579704285e-01
    z[8,7,6]  R2532     -4.1534259915351868e-01
    z[8,7,6]  R2533     -2.6995116472244263e-01
    z[8,7,6]  R2534     -2.3203879594802856e-01
    z[8,7,6]  R2535     3.6412918567657471e-01
    z[8,7,6]  R2536     -4.2200666666030884e-01
    z[8,7,6]  R2537     -3.0473735928535461e-01
    z[8,7,6]  R2538     0.0794663280248642
    z[8,7,6]  R2539     -2.8393331170082092e-01
    z[8,7,6]  R2540     1.3920005876570940e-03
    z[8,7,6]  R2541     1.8540833890438080e-01
    z[8,7,6]  R2542     -2.5751054286956787e-01
    z[8,7,6]  R2543     3.5152930766344070e-02
    z[8,7,6]  R2544     1.1452741920948029e-01
    z[8,7,6]  R2545     7.9993076622486115e-02
    z[8,7,6]  R2546     9.3643620610237122e-02
    z[8,7,6]  R2547     2.6505556702613831e-01
    z[8,7,6]  R2548     1.8180431425571442e-01
    z[8,7,6]  R2549     9.1106317937374115e-02
    z[8,7,6]  R2550     4.5899960398674011e-01
    z[8,7,6]  R2551     3.2285347580909729e-01
    z[8,7,6]  R2552     4.3084564805030823e-01
    z[8,7,6]  R2553     9.2565260827541351e-02
    z[8,7,6]  R2554     1.7285913228988647e-01
    z[8,7,6]  R2555     3.6376565694808960e-02
    z[8,7,6]  R2556     -1.4245083928108215e-01
    z[8,7,6]  R2557     -7.5721487402915955e-02
    z[8,7,6]  R2558     2.4506205692887306e-02
    z[8,7,6]  R2559     2.8213104605674744e-01
    z[8,7,6]  R2560     -1.6030804812908173e-01
    z[8,7,6]  R2561     2.5406202673912048e-01
    z[8,7,6]  R2562     -2.9143482446670532e-01
    z[8,7,6]  R2563     -1.5985479950904846e-01
    z[8,7,6]  R2564     4.9594348669052124e-01
    z[8,7,6]  R2565     -4.8691403120756149e-02
    z[8,7,6]  R2566     -2.0474494993686676e-01
    z[8,7,6]  R2567     0.178403839468956
    z[8,7,6]  R2568     -2.4913826584815979e-01
    z[8,7,6]  R2569     1.3315147161483765e-01
    z[8,7,6]  R2570     -1.4845924079418182e-01
    z[8,7,6]  R2571     -2.6704590767621994e-02
    z[8,7,6]  R2572     -3.8042172789573669e-01
    z[8,7,6]  R2573     2.1605546772480011e-01
    z[8,7,6]  R2574     -1.5994818508625031e-01
    z[8,7,6]  R2575     -3.8616311550140381e-01
    z[8,7,6]  R2576     -1.2715712189674377e-01
    z[8,7,6]  R2577     -7.8070342540740967e-02
    z[8,7,6]  R2578     -0.329046368598938
    z[8,7,6]  R2579     3.5990753769874573e-01
    z[8,7,6]  R2580     1.2065856903791428e-01
    z[8,7,6]  R2581     -2.5245729088783264e-01
    z[8,7,6]  R2582     -3.6780178546905518e-01
    z[8,7,6]  R2583     2.6245898008346558e-01
    z[8,7,6]  R2584     -0.431118905544281
    z[8,7,6]  R2585     1.1443287134170532e-01
    z[8,7,6]  R2586     -3.0566301941871643e-01
    z[8,7,6]  R2587     6.8310797214508057e-02
    z[8,7,6]  R2588     -3.9937660098075867e-01
    z[8,7,6]  R2589     4.9677121639251709e-01
    z[8,7,6]  R2590     -1.4393849670886993e-01
    z[8,7,6]  R2591     2.6950417086482048e-02
    z[8,7,6]  R2592     1.5028476715087891e-01
    z[8,7,6]  R2593     5.3693549707531929e-03
    z[8,7,6]  R2594     -1.7856544256210327e-01
    z[8,7,6]  R2595     -1.9104431569576263e-01
    z[8,7,6]  R2596     -0.0746225118637085
    z[8,7,6]  R2597     -7.4989609420299530e-02
    z[8,7,6]  R2598     -3.4695494174957275e-01
    z[8,7,6]  R2599     1.7652879655361176e-01
    z[8,7,6]  R2600     2.0065940916538239e-01
    z[8,7,6]  R2601     2.8138899803161621e-01
    z[8,7,6]  R2602     3.0447763204574585e-01
    z[8,7,6]  R2603     5.0895728170871735e-02
    z[8,7,6]  R2604     -1.8128305673599243e-01
    z[8,7,6]  R2605     2.0164723694324493e-01
    z[8,7,6]  R2606     -2.5364974141120911e-01
    z[8,7,6]  R2607     -3.4070074558258057e-01
    z[8,7,6]  R2608     -2.7692726254463196e-01
    z[8,7,6]  R2609     5.5489383637905121e-02
    z[8,7,6]  R2610     1.6778001189231873e-01
    z[8,7,6]  R2611     3.4769383072853088e-01
    z[8,7,6]  R2612     -5.2694267034530640e-01
    z[8,7,6]  R2613     3.8925391435623169e-01
    z[8,7,6]  R2614     1.8882460892200470e-01
    z[8,7,6]  R2615     -8.0523900687694550e-03
    z[8,7,6]  R2616     -4.4849586486816406e-01
    z[8,7,6]  R2617     4.0044292807579041e-01
    z[8,7,6]  R2618     -1.6809058189392090e-01
    z[8,7,6]  R2619     1.6339325904846191e-01
    z[8,7,6]  R2620     8.3301074802875519e-02
    z[8,7,6]  R2621     1.7445525154471397e-02
    z[8,7,6]  R2622     -2.9239067435264587e-01
    z[8,7,6]  R2623     -1.6763594746589661e-01
    z[8,7,6]  R2624     0.157171830534935
    z[8,7,6]  R2625     5.9484452009201050e-02
    z[8,7,6]  R2626     1.0688801854848862e-01
    z[8,7,6]  R2627     -1.0583240538835526e-01
    z[8,7,6]  R2628     3.6158952116966248e-01
    z[8,7,6]  R2629     -1.0297979414463043e-01
    z[8,9,0]  R74       -1
    z[8,9,0]  R83       1
    z[8,9,0]  R2630     -1
    z[8,9,0]  R2631     1
    z[8,9,0]  R2644     7.5349879264831543e-01
    z[8,9,0]  R2645     0.307144433259964
    z[8,9,0]  R2646     2.5218990445137024e-01
    z[8,9,0]  R2647     1.7160646617412567e-02
    z[8,9,0]  R2648     4.0592528879642487e-02
    z[8,9,0]  R2649     7.5310325622558594e-01
    z[8,9,0]  R2650     0.409322589635849
    z[8,9,0]  R2651     1.8494494259357452e-01
    z[8,9,0]  R2652     2.6719310879707336e-01
    z[8,9,0]  R2653     4.4634243845939636e-01
    z[8,9,0]  R2654     -3.0533054471015930e-01
    z[8,9,0]  R2655     -1.7112727463245392e-01
    z[8,9,0]  R2656     -3.9704239368438721e-01
    z[8,9,0]  R2657     -1.7034025490283966e-01
    z[8,9,0]  R2658     -1.6297745704650879e-01
    z[8,9,0]  R2659     -1.6063745319843292e-01
    z[8,9,0]  R2660     -1.8528106808662415e-01
    z[8,9,0]  R2661     -2.2841534018516541e-01
    z[8,9,0]  R2662     -2.7883759140968323e-01
    z[8,9,0]  R2663     -6.5518236160278320e-01
    z[8,9,0]  R2664     5.8571350574493408e-01
    z[8,9,0]  R2665     2.8354993462562561e-01
    z[8,9,0]  R2666     5.8395421504974365e-01
    z[8,9,0]  R2667     5.2461272478103638e-01
    z[8,9,0]  R2668     -5.0638926029205322e-01
    z[8,9,0]  R2669     4.8312941193580627e-01
    z[8,9,0]  R2670     6.8348360061645508e-01
    z[8,9,0]  R2671     4.1684523224830627e-01
    z[8,9,0]  R2672     -4.5816802978515625e-01
    z[8,9,0]  R2673     -0.49376380443573
    z[8,9,0]  R2674     6.7443841695785522e-01
    z[8,9,0]  R2675     7.0656412839889526e-01
    z[8,9,0]  R2676     -2.4325503408908844e-01
    z[8,9,0]  R2677     3.9420586079359055e-02
    z[8,9,0]  R2678     4.8067179322242737e-01
    z[8,9,0]  R2679     4.1502940654754639e-01
    z[8,9,0]  R2680     3.1739464402198792e-01
    z[8,9,0]  R2681     -4.0888100862503052e-01
    z[8,9,0]  R2682     3.8763949275016785e-01
    z[8,9,0]  R2683     -1.2355958670377731e-01
    z[8,9,0]  R2684     4.4388791918754578e-01
    z[8,9,0]  R2685     0.376607209444046
    z[8,9,0]  R2686     -3.8632029294967651e-01
    z[8,9,0]  R2687     -2.6457989215850830e-01
    z[8,9,0]  R2688     2.8549227118492126e-01
    z[8,9,0]  R2689     4.7952511906623840e-01
    z[8,9,0]  R2690     -6.6012746095657349e-01
    z[8,9,0]  R2691     -4.7437986731529236e-01
    z[8,9,0]  R2692     -4.8283296823501587e-01
    z[8,9,0]  R2693     6.6481798887252808e-01
    z[8,9,0]  R2694     -4.7083017230033875e-01
    z[8,9,0]  R2695     -2.9554355144500732e-01
    z[8,9,0]  R2696     -4.5847481489181519e-01
    z[8,9,0]  R2697     -3.4898281097412109e-01
    z[8,9,0]  R2698     -3.4378483891487122e-01
    z[8,9,0]  R2699     -4.1573926806449890e-01
    z[8,9,0]  R2700     -3.2152774930000305e-01
    z[8,9,0]  R2701     -2.9459995031356812e-01
    z[8,9,0]  R2702     -4.6038252115249634e-01
    z[8,9,0]  R2703     -3.3345550298690796e-01
    z[8,9,0]  R2704     9.6774977445602417e-01
    z[8,9,0]  R2705     9.2610377073287964e-01
    z[8,9,0]  R2706     9.3839341402053833e-01
    z[8,9,0]  R2707     0.913361668586731
    z[8,9,0]  R2708     -5.5221021175384521e-01
    z[8,9,0]  R2709     9.2324179410934448e-01
    z[8,9,0]  R2710     8.7861239910125732e-01
    z[8,9,0]  R2711     8.6381405591964722e-01
    z[8,9,0]  R2712     -5.0134289264678955e-01
    z[8,9,0]  R2713     2.2638149559497833e-01
    z[8,9,0]  R2714     -9.0156745910644531e-01
    z[8,9,0]  R2715     -6.7771470546722412e-01
    z[8,9,0]  R2716     -0.654639482498169
    z[8,9,0]  R2717     -4.5600414276123047e-01
    z[8,9,0]  R2718     -5.2531290054321289e-01
    z[8,9,0]  R2719     -1.3764478266239166e-01
    z[8,9,0]  R2720     1.3541062362492085e-02
    z[8,9,0]  R2721     -4.0826670825481415e-02
    z[8,9,0]  R2722     -3.0490857362747192e-01
    z[8,9,0]  R2723     4.8627230525016785e-01
    z[8,9,0]  R2724     -1.3738344609737396e-01
    z[8,9,0]  R2725     1.5904630720615387e-01
    z[8,9,0]  R2726     2.5986087322235107e-01
    z[8,9,0]  R2727     0.145345538854599
    z[8,9,0]  R2728     2.4203133583068848e-01
    z[8,9,0]  R2729     5.2579408884048462e-01
    z[8,9,0]  R2730     3.9317697286605835e-01
    z[8,9,0]  R2731     4.3037596344947815e-01
    z[8,9,0]  R2732     2.6960945129394531e-01
    z[8,9,0]  R2733     0.500088095664978
    z[8,9,0]  R2734     8.1707149744033813e-02
    z[8,9,0]  R2735     2.7697938680648804e-01
    z[8,9,0]  R2736     3.6197766661643982e-01
    z[8,9,0]  R2737     7.8655153512954712e-02
    z[8,9,0]  R2738     4.1394266486167908e-01
    z[8,9,0]  R2739     3.3076366782188416e-01
    z[8,9,0]  R2740     3.3056697249412537e-01
    z[8,9,0]  R2741     2.4081142246723175e-01
    z[8,9,0]  R2742     3.9070203900337219e-01
    z[8,9,0]  R2743     3.9883446693420410e-01
    z[8,9,1]  R75       -1
    z[8,9,1]  R84       1
    z[8,9,1]  R2632     -1
    z[8,9,1]  R2633     1
    z[8,9,1]  R2644     5.3390890359878540e-01
    z[8,9,1]  R2645     -1.1291924118995667e-01
    z[8,9,1]  R2646     9.5239475369453430e-02
    z[8,9,1]  R2647     3.3926531672477722e-01
    z[8,9,1]  R2648     4.6290901303291321e-01
    z[8,9,1]  R2649     4.4603973627090454e-01
    z[8,9,1]  R2650     -3.7558069825172424e-01
    z[8,9,1]  R2651     -2.9839560389518738e-01
    z[8,9,1]  R2652     3.7120589613914490e-01
    z[8,9,1]  R2653     -2.6726689934730530e-01
    z[8,9,1]  R2654     -9.0453439950942993e-01
    z[8,9,1]  R2655     -9.1103643178939819e-01
    z[8,9,1]  R2656     -0.866890549659729
    z[8,9,1]  R2657     -9.0055418014526367e-01
    z[8,9,1]  R2658     -8.8076150417327881e-01
    z[8,9,1]  R2659     -8.8842248916625977e-01
    z[8,9,1]  R2660     -8.7182438373565674e-01
    z[8,9,1]  R2661     -0.855061948299408
    z[8,9,1]  R2662     -8.2966303825378418e-01
    z[8,9,1]  R2663     -7.3643636703491211e-01
    z[8,9,1]  R2664     -2.8715163469314575e-01
    z[8,9,1]  R2665     -1.7557007074356079e-01
    z[8,9,1]  R2666     -5.1222376525402069e-02
    z[8,9,1]  R2667     1.0439503192901611e-01
    z[8,9,1]  R2668     6.6497230529785156e-01
    z[8,9,1]  R2669     -7.8976178169250488e-01
    z[8,9,1]  R2670     -0.595569372177124
    z[8,9,1]  R2671     4.4834807515144348e-01
    z[8,9,1]  R2672     7.5294440984725952e-01
    z[8,9,1]  R2673     0.756111741065979
    z[8,9,1]  R2674     4.8174926638603210e-01
    z[8,9,1]  R2675     -2.0700308680534363e-01
    z[8,9,1]  R2676     3.3629408478736877e-01
    z[8,9,1]  R2677     -3.3663976192474365e-01
    z[8,9,1]  R2678     -1.3645662367343903e-01
    z[8,9,1]  R2679     4.5533582568168640e-01
    z[8,9,1]  R2680     -5.2777826786041260e-01
    z[8,9,1]  R2681     8.2022237777709961e-01
    z[8,9,1]  R2682     -5.9745508432388306e-01
    z[8,9,1]  R2683     -6.4928692579269409e-01
    z[8,9,1]  R2684     -4.7594240307807922e-01
    z[8,9,1]  R2685     -2.1905189752578735e-01
    z[8,9,1]  R2686     3.1492364406585693e-01
    z[8,9,1]  R2687     3.3113875985145569e-01
    z[8,9,1]  R2688     -7.1422350406646729e-01
    z[8,9,1]  R2689     -5.2346724271774292e-01
    z[8,9,1]  R2690     6.4730447530746460e-01
    z[8,9,1]  R2691     5.1535248756408691e-01
    z[8,9,1]  R2692     5.5950152873992920e-01
    z[8,9,1]  R2693     -4.5236143469810486e-01
    z[8,9,1]  R2694     3.2166350632905960e-02
    z[8,9,1]  R2695     0.0396723710000515
    z[8,9,1]  R2696     8.4040112793445587e-02
    z[8,9,1]  R2697     -8.3546109497547150e-02
    z[8,9,1]  R2698     -1.7947475612163544e-01
    z[8,9,1]  R2699     -4.4269564747810364e-01
    z[8,9,1]  R2700     -3.2941896468400955e-02
    z[8,9,1]  R2701     3.1364038586616516e-01
    z[8,9,1]  R2702     7.9319693148136139e-02
    z[8,9,1]  R2703     -2.8139597177505493e-01
    z[8,9,1]  R2704     2.0339037477970123e-01
    z[8,9,1]  R2705     2.5800153613090515e-01
    z[8,9,1]  R2706     1.5622794628143311e-01
    z[8,9,1]  R2707     2.4087810516357422e-01
    z[8,9,1]  R2708     2.5549891591072083e-01
    z[8,9,1]  R2709     1.9792918860912323e-01
    z[8,9,1]  R2710     2.9791086912155151e-01
    z[8,9,1]  R2711     2.5721102952957153e-01
    z[8,9,1]  R2712     -1.3574388623237610e-01
    z[8,9,1]  R2713     4.6913331747055054e-01
    z[8,9,1]  R2714     -1.8754141032695770e-01
    z[8,9,1]  R2715     0.230122908949852
    z[8,9,1]  R2716     1.6657446324825287e-01
    z[8,9,1]  R2717     1.3152468204498291e-01
    z[8,9,1]  R2718     4.8701906204223633e-01
    z[8,9,1]  R2719     0.788979172706604
    z[8,9,1]  R2720     6.9596582651138306e-01
    z[8,9,1]  R2721     7.3576313257217407e-01
    z[8,9,1]  R2722     7.1478289365768433e-01
    z[8,9,1]  R2723     6.8016147613525391e-01
    z[8,9,1]  R2724     6.5989780426025391e-01
    z[8,9,1]  R2725     6.5643984079360962e-01
    z[8,9,1]  R2726     6.2312871217727661e-01
    z[8,9,1]  R2727     6.6643327474594116e-01
    z[8,9,1]  R2728     5.7647407054901123e-01
    z[8,9,1]  R2729     6.2587428092956543e-01
    z[8,9,1]  R2730     5.4993522167205811e-01
    z[8,9,1]  R2731     6.0498905181884766e-01
    z[8,9,1]  R2732     5.7798069715499878e-01
    z[8,9,1]  R2733     6.0623961687088013e-01
    z[8,9,1]  R2734     8.1107234954833984e-01
    z[8,9,1]  R2735     7.5782066583633423e-01
    z[8,9,1]  R2736     6.4041876792907715e-01
    z[8,9,1]  R2737     6.3288372755050659e-01
    z[8,9,1]  R2738     5.7941132783889771e-01
    z[8,9,1]  R2739     5.8373361825942993e-01
    z[8,9,1]  R2740     -0.658723771572113
    z[8,9,1]  R2741     -4.7224420309066772e-01
    z[8,9,1]  R2742     -7.5151330232620239e-01
    z[8,9,1]  R2743     -7.0992028713226318e-01
    z[8,9,2]  R76       -1
    z[8,9,2]  R85       1
    z[8,9,2]  R2634     -1
    z[8,9,2]  R2635     1
    z[8,9,2]  R2644     -4.5283399522304535e-02
    z[8,9,2]  R2645     3.3473870158195496e-01
    z[8,9,2]  R2646     5.7471507787704468e-01
    z[8,9,2]  R2647     5.6111335754394531e-01
    z[8,9,2]  R2648     6.4216136932373047e-01
    z[8,9,2]  R2649     5.1232177764177322e-02
    z[8,9,2]  R2650     2.9302367568016052e-01
    z[8,9,2]  R2651     3.7862551212310791e-01
    z[8,9,2]  R2652     5.2351778745651245e-01
    z[8,9,2]  R2653     1.1340779066085815e-01
    z[8,9,2]  R2654     -3.4694414585828781e-02
    z[8,9,2]  R2655     -2.3301114141941071e-01
    z[8,9,2]  R2656     -5.4809297434985638e-03
    z[8,9,2]  R2657     -1.3062655925750732e-01
    z[8,9,2]  R2658     -3.1449711322784424e-01
    z[8,9,2]  R2659     -1.4832252264022827e-01
    z[8,9,2]  R2660     -1.4843389391899109e-01
    z[8,9,2]  R2661     -0.200262188911438
    z[8,9,2]  R2662     -2.0472073554992676e-01
    z[8,9,2]  R2663     2.5710277259349823e-02
    z[8,9,2]  R2664     4.2051258683204651e-01
    z[8,9,2]  R2665     5.9493917226791382e-01
    z[8,9,2]  R2666     2.7369165420532227e-01
    z[8,9,2]  R2667     7.1624934673309326e-01
    z[8,9,2]  R2668     4.4915539026260376e-01
    z[8,9,2]  R2669     1.2079031206667423e-02
    z[8,9,2]  R2670     -0.0837479680776596
    z[8,9,2]  R2671     -9.6484325826168060e-02
    z[8,9,2]  R2672     0.119090735912323
    z[8,9,2]  R2673     1.2360082007944584e-02
    z[8,9,2]  R2674     -0.00766489002853632
    z[8,9,2]  R2675     5.0639349222183228e-01
    z[8,9,2]  R2676     8.1966572999954224e-01
    z[8,9,2]  R2677     6.4619135856628418e-01
    z[8,9,2]  R2678     -2.9444175306707621e-03
    z[8,9,2]  R2679     6.7845833301544189e-01
    z[8,9,2]  R2680     1.3194097578525543e-01
    z[8,9,2]  R2681     1.8230533599853516e-01
    z[8,9,2]  R2682     0.210468590259552
    z[8,9,2]  R2683     5.4060208797454834e-01
    z[8,9,2]  R2684     3.1908458471298218e-01
    z[8,9,2]  R2685     3.0309337377548218e-01
    z[8,9,2]  R2686     7.4047005176544189e-01
    z[8,9,2]  R2687     5.6868463754653931e-01
    z[8,9,2]  R2688     2.9122796654701233e-01
    z[8,9,2]  R2689     5.1562881469726562e-01
    z[8,9,2]  R2690     1.3450199365615845e-01
    z[8,9,2]  R2691     1.6099503636360168e-01
    z[8,9,2]  R2692     -6.8838261067867279e-02
    z[8,9,2]  R2693     -4.3100094795227051e-01
    z[8,9,2]  R2694     7.4854022264480591e-01
    z[8,9,2]  R2695     7.7322673797607422e-01
    z[8,9,2]  R2696     5.5614316463470459e-01
    z[8,9,2]  R2697     7.4131155014038086e-01
    z[8,9,2]  R2698     6.0885030031204224e-01
    z[8,9,2]  R2699     5.5249720811843872e-01
    z[8,9,2]  R2700     9.0784209966659546e-01
    z[8,9,2]  R2701     6.7819595336914062e-01
    z[8,9,2]  R2702     2.7134335041046143e-01
    z[8,9,2]  R2703     4.2744603753089905e-01
    z[8,9,2]  R2704     5.1857554353773594e-03
    z[8,9,2]  R2705     1.6024602949619293e-01
    z[8,9,2]  R2706     1.8079839646816254e-01
    z[8,9,2]  R2707     -0.00484444061294198
    z[8,9,2]  R2708     -4.9005034379661083e-03
    z[8,9,2]  R2709     -1.6564095392823219e-02
    z[8,9,2]  R2710     1.6810914874076843e-01
    z[8,9,2]  R2711     2.9709663987159729e-01
    z[8,9,2]  R2712     -1.4267097413539886e-01
    z[8,9,2]  R2713     8.9215926826000214e-02
    z[8,9,2]  R2714     1.6153568029403687e-01
    z[8,9,2]  R2715     -1.7516578733921051e-01
    z[8,9,2]  R2716     1.5358678996562958e-01
    z[8,9,2]  R2717     3.4399747848510742e-01
    z[8,9,2]  R2718     2.5514939427375793e-01
    z[8,9,2]  R2719     -2.8482022881507874e-01
    z[8,9,2]  R2720     1.5267622470855713e-01
    z[8,9,2]  R2721     -9.4846390187740326e-02
    z[8,9,2]  R2722     -0.0899360403418541
    z[8,9,2]  R2723     -3.1053539365530014e-02
    z[8,9,2]  R2724     3.2477059960365295e-01
    z[8,9,2]  R2725     -2.5495512410998344e-02
    z[8,9,2]  R2726     1.2463396787643433e-01
    z[8,9,2]  R2727     -2.3540388047695160e-01
    z[8,9,2]  R2728     2.9795238375663757e-01
    z[8,9,2]  R2729     -1.3816735148429871e-01
    z[8,9,2]  R2730     4.4385454058647156e-01
    z[8,9,2]  R2731     -2.2756014764308929e-01
    z[8,9,2]  R2732     3.6119814962148666e-02
    z[8,9,2]  R2733     1.2279379367828369e-01
    z[8,9,2]  R2734     -2.8874114155769348e-01
    z[8,9,2]  R2735     -4.0515437722206116e-02
    z[8,9,2]  R2736     2.6859748363494873e-01
    z[8,9,2]  R2737     -1.2695711851119995e-01
    z[8,9,2]  R2738     4.6635717153549194e-01
    z[8,9,2]  R2739     3.3958196640014648e-01
    z[8,9,2]  R2740     3.8723897933959961e-01
    z[8,9,2]  R2741     3.9988216757774353e-01
    z[8,9,2]  R2742     7.4228219687938690e-02
    z[8,9,2]  R2743     1.4176069200038910e-01
    z[8,9,3]  R77       -1
    z[8,9,3]  R86       1
    z[8,9,3]  R2636     -1
    z[8,9,3]  R2637     1
    z[8,9,3]  R2644     2.9557514190673828e-01
    z[8,9,3]  R2645     0.511228084564209
    z[8,9,3]  R2646     3.1941589713096619e-01
    z[8,9,3]  R2647     1.8191672861576080e-01
    z[8,9,3]  R2648     2.5957101583480835e-01
    z[8,9,3]  R2649     -1.8496680259704590e-01
    z[8,9,3]  R2650     2.1793392300605774e-01
    z[8,9,3]  R2651     2.8237605094909668e-01
    z[8,9,3]  R2652     3.6248272657394409e-01
    z[8,9,3]  R2653     1.5013046562671661e-01
    z[8,9,3]  R2654     -2.2524642944335938e-01
    z[8,9,3]  R2655     1.7526608705520630e-01
    z[8,9,3]  R2656     -1.3580419123172760e-01
    z[8,9,3]  R2657     1.3678257167339325e-01
    z[8,9,3]  R2658     -3.9878997951745987e-02
    z[8,9,3]  R2659     1.4355589635670185e-02
    z[8,9,3]  R2660     2.3384894430637360e-01
    z[8,9,3]  R2661     -3.0689659714698792e-01
    z[8,9,3]  R2662     -2.2202888131141663e-01
    z[8,9,3]  R2663     0.027417017146945
    z[8,9,3]  R2664     3.6058798432350159e-01
    z[8,9,3]  R2665     6.0836231708526611e-01
    z[8,9,3]  R2666     4.7131389379501343e-01
    z[8,9,3]  R2667     0.214554101228714
    z[8,9,3]  R2668     1.1563784629106522e-01
    z[8,9,3]  R2669     2.9142510890960693e-01
    z[8,9,3]  R2670     -1.1412892490625381e-02
    z[8,9,3]  R2671     -3.6228007078170776e-01
    z[8,9,3]  R2672     -3.9543735980987549e-01
    z[8,9,3]  R2673     -1.8169339001178741e-01
    z[8,9,3]  R2674     -4.5411369204521179e-01
    z[8,9,3]  R2675     3.3606874942779541e-01
    z[8,9,3]  R2676     2.1002674102783203e-01
    z[8,9,3]  R2677     5.6889343261718750e-01
    z[8,9,3]  R2678     4.3332943320274353e-01
    z[8,9,3]  R2679     3.4539647400379181e-02
    z[8,9,3]  R2680     3.5232019424438477e-01
    z[8,9,3]  R2681     4.5969886705279350e-03
    z[8,9,3]  R2682     1.3093477487564087e-01
    z[8,9,3]  R2683     2.0541979372501373e-01
    z[8,9,3]  R2684     3.0937123298645020e-01
    z[8,9,3]  R2685     4.8632130026817322e-01
    z[8,9,3]  R2686     2.3699489235877991e-01
    z[8,9,3]  R2687     6.1725121736526489e-01
    z[8,9,3]  R2688     3.8626599311828613e-01
    z[8,9,3]  R2689     -1.5872826799750328e-02
    z[8,9,3]  R2690     -2.7297082543373108e-01
    z[8,9,3]  R2691     -3.3678501844406128e-01
    z[8,9,3]  R2692     -3.4425669908523560e-01
    z[8,9,3]  R2693     -5.6831665337085724e-02
    z[8,9,3]  R2694     -1.8052347004413605e-01
    z[8,9,3]  R2695     5.3283762186765671e-02
    z[8,9,3]  R2696     -4.3473982810974121e-01
    z[8,9,3]  R2697     2.1651349961757660e-01
    z[8,9,3]  R2698     -4.9789324402809143e-01
    z[8,9,3]  R2699     1.2577231228351593e-01
    z[8,9,3]  R2700     1.9749045372009277e-01
    z[8,9,3]  R2701     2.5030982494354248e-01
    z[8,9,3]  R2702     3.9309477806091309e-01
    z[8,9,3]  R2703     -4.4370139949023724e-03
    z[8,9,3]  R2704     -8.5052363574504852e-02
    z[8,9,3]  R2705     -1.7347997426986694e-01
    z[8,9,3]  R2706     1.3206608593463898e-01
    z[8,9,3]  R2707     1.8585222959518433e-01
    z[8,9,3]  R2708     -6.2713988125324249e-02
    z[8,9,3]  R2709     -0.0458403155207634
    z[8,9,3]  R2710     1.0051049292087555e-01
    z[8,9,3]  R2711     4.5493662357330322e-02
    z[8,9,3]  R2712     6.7066222429275513e-01
    z[8,9,3]  R2713     -3.6637911200523376e-01
    z[8,9,3]  R2714     1.6711705923080444e-01
    z[8,9,3]  R2715     -6.0624879598617554e-01
    z[8,9,3]  R2716     1.7043847590684891e-02
    z[8,9,3]  R2717     -1.6985219717025757e-01
    z[8,9,3]  R2718     3.2322707772254944e-01
    z[8,9,3]  R2719     -3.3934235572814941e-01
    z[8,9,3]  R2720     -6.7457742989063263e-02
    z[8,9,3]  R2721     2.3494258522987366e-01
    z[8,9,3]  R2722     3.4122428297996521e-01
    z[8,9,3]  R2723     4.2916625738143921e-01
    z[8,9,3]  R2724     -1.7377541959285736e-01
    z[8,9,3]  R2725     2.0292323082685471e-02
    z[8,9,3]  R2726     -4.3427139520645142e-01
    z[8,9,3]  R2727     -3.8042291998863220e-01
    z[8,9,3]  R2728     -5.1961505413055420e-01
    z[8,9,3]  R2729     1.4480647444725037e-01
    z[8,9,3]  R2730     8.0680213868618011e-02
    z[8,9,3]  R2731     4.9613124132156372e-01
    z[8,9,3]  R2732     4.5380535721778870e-01
    z[8,9,3]  R2733     1.2200967222452164e-01
    z[8,9,3]  R2734     -3.4977838397026062e-01
    z[8,9,3]  R2735     -2.0434801280498505e-01
    z[8,9,3]  R2736     -5.1644808053970337e-01
    z[8,9,3]  R2737     -1.8804410472512245e-02
    z[8,9,3]  R2738     3.9058357477188110e-01
    z[8,9,3]  R2739     4.0062817931175232e-01
    z[8,9,3]  R2740     3.0354353785514832e-01
    z[8,9,3]  R2741     4.3460509181022644e-01
    z[8,9,3]  R2742     1.4760607481002808e-01
    z[8,9,3]  R2743     3.7209221720695496e-01
    z[8,9,4]  R78       -1
    z[8,9,4]  R87       1
    z[8,9,4]  R2638     -1
    z[8,9,4]  R2639     1
    z[8,9,4]  R2644     1.4715710654854774e-02
    z[8,9,4]  R2645     -4.6450448036193848e-01
    z[8,9,4]  R2646     -5.1308578252792358e-01
    z[8,9,4]  R2647     -6.5982139110565186e-01
    z[8,9,4]  R2648     -4.9314025044441223e-01
    z[8,9,4]  R2649     4.0272939950227737e-03
    z[8,9,4]  R2650     -6.1621171236038208e-01
    z[8,9,4]  R2651     -6.7005592584609985e-01
    z[8,9,4]  R2652     -6.1298555135726929e-01
    z[8,9,4]  R2653     -7.7415800094604492e-01
    z[8,9,4]  R2654     9.8041877150535583e-02
    z[8,9,4]  R2655     0.0976729765534401
    z[8,9,4]  R2656     5.9816960245370865e-02
    z[8,9,4]  R2657     3.2650753855705261e-01
    z[8,9,4]  R2658     -5.2045132964849472e-02
    z[8,9,4]  R2659     9.0918548405170441e-02
    z[8,9,4]  R2660     3.1808158755302429e-01
    z[8,9,4]  R2661     -1.0641106218099594e-01
    z[8,9,4]  R2662     2.3723126947879791e-01
    z[8,9,4]  R2663     5.1848553121089935e-03
    z[8,9,4]  R2664     0.232549786567688
    z[8,9,4]  R2665     2.1865151822566986e-01
    z[8,9,4]  R2666     1.2797074019908905e-01
    z[8,9,4]  R2667     1.5356892347335815e-01
    z[8,9,4]  R2668     4.4284559786319733e-02
    z[8,9,4]  R2669     1.8996295332908630e-01
    z[8,9,4]  R2670     6.6601976752281189e-02
    z[8,9,4]  R2671     -1.3420465588569641e-01
    z[8,9,4]  R2672     4.3489160016179085e-03
    z[8,9,4]  R2673     1.7702130600810051e-02
    z[8,9,4]  R2674     -1.3463121652603149e-01
    z[8,9,4]  R2675     -1.4478822052478790e-01
    z[8,9,4]  R2676     1.0083559900522232e-01
    z[8,9,4]  R2677     2.5494772195816040e-01
    z[8,9,4]  R2678     -5.0143241882324219e-01
    z[8,9,4]  R2679     6.1852414160966873e-02
    z[8,9,4]  R2680     3.2360956072807312e-01
    z[8,9,4]  R2681     -2.4408391118049622e-01
    z[8,9,4]  R2682     4.0664246678352356e-01
    z[8,9,4]  R2683     5.5780843831598759e-03
    z[8,9,4]  R2684     -5.4525423049926758e-01
    z[8,9,4]  R2685     2.4329267442226410e-01
    z[8,9,4]  R2686     -4.4477835297584534e-02
    z[8,9,4]  R2687     2.0227548480033875e-01
    z[8,9,4]  R2688     3.0241009593009949e-01
    z[8,9,4]  R2689     1.7804567515850067e-01
    z[8,9,4]  R2690     9.8191395401954651e-02
    z[8,9,4]  R2691     -0.257386714220047
    z[8,9,4]  R2692     -4.1155639290809631e-01
    z[8,9,4]  R2693     -1.6819517314434052e-01
    z[8,9,4]  R2694     1.5794004499912262e-01
    z[8,9,4]  R2695     -0.287248820066452
    z[8,9,4]  R2696     -4.6690490841865540e-01
    z[8,9,4]  R2697     -3.5223785042762756e-01
    z[8,9,4]  R2698     -3.3591628074645996e-01
    z[8,9,4]  R2699     -5.2343004941940308e-01
    z[8,9,4]  R2700     -1.2184038013219833e-01
    z[8,9,4]  R2701     -8.3195351064205170e-02
    z[8,9,4]  R2702     4.4558685272932053e-02
    z[8,9,4]  R2703     -6.4415490627288818e-01
    z[8,9,4]  R2704     -3.8812708109617233e-02
    z[8,9,4]  R2705     7.4055716395378113e-03
    z[8,9,4]  R2706     -1.5727436542510986e-01
    z[8,9,4]  R2707     4.6703465282917023e-02
    z[8,9,4]  R2708     5.7107192277908325e-01
    z[8,9,4]  R2709     -3.9166450500488281e-02
    z[8,9,4]  R2710     6.7736767232418060e-02
    z[8,9,4]  R2711     8.7502032518386841e-02
    z[8,9,4]  R2712     -1.7671035602688789e-02
    z[8,9,4]  R2713     5.8958941698074341e-01
    z[8,9,4]  R2714     1.9108204171061516e-02
    z[8,9,4]  R2715     1.2698955833911896e-01
    z[8,9,4]  R2716     -3.3748939633369446e-02
    z[8,9,4]  R2717     -3.2901132106781006e-01
    z[8,9,4]  R2718     -6.1276316642761230e-02
    z[8,9,4]  R2719     -5.1297068595886230e-02
    z[8,9,4]  R2720     -2.2719316184520721e-01
    z[8,9,4]  R2721     -2.5636243820190430e-01
    z[8,9,4]  R2722     3.4080383181571960e-01
    z[8,9,4]  R2723     -8.4892563521862030e-02
    z[8,9,4]  R2724     5.3927540779113770e-01
    z[8,9,4]  R2725     5.7670968770980835e-01
    z[8,9,4]  R2726     1.1724369972944260e-01
    z[8,9,4]  R2727     5.1187109947204590e-01
    z[8,9,4]  R2728     4.8995384573936462e-01
    z[8,9,4]  R2729     -4.4858568906784058e-01
    z[8,9,4]  R2730     4.0596362948417664e-01
    z[8,9,4]  R2731     -2.9080381616950035e-02
    z[8,9,4]  R2732     2.3985201492905617e-02
    z[8,9,4]  R2733     5.3897273540496826e-01
    z[8,9,4]  R2734     2.5838559865951538e-01
    z[8,9,4]  R2735     9.1996602714061737e-02
    z[8,9,4]  R2736     1.8558706343173981e-01
    z[8,9,4]  R2737     6.3261657953262329e-01
    z[8,9,4]  R2738     3.5041567683219910e-01
    z[8,9,4]  R2739     -3.8997948169708252e-01
    z[8,9,4]  R2740     -2.3826885968446732e-02
    z[8,9,4]  R2741     -1.9107882678508759e-01
    z[8,9,4]  R2742     -2.1714706718921661e-01
    z[8,9,4]  R2743     -1.2603472173213959e-01
    z[8,9,5]  R79       -1
    z[8,9,5]  R88       1
    z[8,9,5]  R2640     -1
    z[8,9,5]  R2641     1
    z[8,9,5]  R2644     -2.2283443808555603e-01
    z[8,9,5]  R2645     -4.2021080851554871e-01
    z[8,9,5]  R2646     -2.4339118599891663e-01
    z[8,9,5]  R2647     1.6859647631645203e-01
    z[8,9,5]  R2648     -8.5380002856254578e-02
    z[8,9,5]  R2649     -2.5385084748268127e-01
    z[8,9,5]  R2650     1.5152811072766781e-02
    z[8,9,5]  R2651     0.334398090839386
    z[8,9,5]  R2652     5.7299923151731491e-02
    z[8,9,5]  R2653     1.1835353076457977e-01
    z[8,9,5]  R2654     -1.6442918777465820e-01
    z[8,9,5]  R2655     -1.0862501710653305e-01
    z[8,9,5]  R2656     4.9955964088439941e-02
    z[8,9,5]  R2657     -1.2794810533523560e-01
    z[8,9,5]  R2658     -2.8526043891906738e-01
    z[8,9,5]  R2659     -3.8474711775779724e-01
    z[8,9,5]  R2660     1.3758680224418640e-01
    z[8,9,5]  R2661     2.8761990368366241e-02
    z[8,9,5]  R2662     2.3101963102817535e-01
    z[8,9,5]  R2663     1.3659349083900452e-01
    z[8,9,5]  R2664     -5.3563795983791351e-02
    z[8,9,5]  R2665     -1.1258027702569962e-01
    z[8,9,5]  R2666     -3.9664259552955627e-01
    z[8,9,5]  R2667     -3.5026380419731140e-01
    z[8,9,5]  R2668     2.3329722881317139e-01
    z[8,9,5]  R2669     -1.4275322854518890e-01
    z[8,9,5]  R2670     -3.8245955109596252e-01
    z[8,9,5]  R2671     6.7891335487365723e-01
    z[8,9,5]  R2672     0.228000208735466
    z[8,9,5]  R2673     2.6723757386207581e-01
    z[8,9,5]  R2674     2.5089517235755920e-01
    z[8,9,5]  R2675     -5.5038008838891983e-02
    z[8,9,5]  R2676     -1.2910473346710205e-01
    z[8,9,5]  R2677     -2.3100826144218445e-01
    z[8,9,5]  R2678     2.5525811314582825e-01
    z[8,9,5]  R2679     3.9080002903938293e-01
    z[8,9,5]  R2680     -5.7665330171585083e-01
    z[8,9,5]  R2681     1.8812340497970581e-01
    z[8,9,5]  R2682     -0.451568603515625
    z[8,9,5]  R2683     4.5929422974586487e-01
    z[8,9,5]  R2684     2.4407865107059479e-01
    z[8,9,5]  R2685     -6.4954203367233276e-01
    z[8,9,5]  R2686     -2.0454682409763336e-02
    z[8,9,5]  R2687     -1.6836887598037720e-01
    z[8,9,5]  R2688     -2.3943383991718292e-01
    z[8,9,5]  R2689     -2.2156395018100739e-01
    z[8,9,5]  R2690     1.6375060379505157e-01
    z[8,9,5]  R2691     5.4560887813568115e-01
    z[8,9,5]  R2692     2.3006257414817810e-01
    z[8,9,5]  R2693     8.1063613295555115e-02
    z[8,9,5]  R2694     -2.7535766363143921e-01
    z[8,9,5]  R2695     -4.7670555114746094e-01
    z[8,9,5]  R2696     3.0889594927430153e-02
    z[8,9,5]  R2697     1.0734009742736816e-01
    z[8,9,5]  R2698     -2.5883340835571289e-01
    z[8,9,5]  R2699     1.1961440742015839e-01
    z[8,9,5]  R2700     3.0453236773610115e-02
    z[8,9,5]  R2701     -2.4219313263893127e-01
    z[8,9,5]  R2702     -3.7171486020088196e-01
    z[8,9,5]  R2703     -4.3663722276687622e-01
    z[8,9,5]  R2704     7.2335839271545410e-02
    z[8,9,5]  R2705     -1.1631545424461365e-01
    z[8,9,5]  R2706     -1.3624674081802368e-01
    z[8,9,5]  R2707     2.5760984420776367e-01
    z[8,9,5]  R2708     3.2423117756843567e-01
    z[8,9,5]  R2709     7.3119446635246277e-02
    z[8,9,5]  R2710     -6.3303269445896149e-02
    z[8,9,5]  R2711     1.8382611870765686e-01
    z[8,9,5]  R2712     2.8376647830009460e-01
    z[8,9,5]  R2713     1.5907536447048187e-01
    z[8,9,5]  R2714     -1.4546471834182739e-01
    z[8,9,5]  R2715     -2.4275135993957520e-01
    z[8,9,5]  R2716     6.1934083700180054e-01
    z[8,9,5]  R2717     2.7800858020782471e-01
    z[8,9,5]  R2718     5.0388675928115845e-01
    z[8,9,5]  R2719     -5.6846532970666885e-02
    z[8,9,5]  R2720     3.6254499107599258e-02
    z[8,9,5]  R2721     -3.7607285380363464e-01
    z[8,9,5]  R2722     5.0147105008363724e-02
    z[8,9,5]  R2723     -9.4526156783103943e-02
    z[8,9,5]  R2724     -2.3553647100925446e-02
    z[8,9,5]  R2725     3.8908076286315918e-01
    z[8,9,5]  R2726     -5.6547969579696655e-01
    z[8,9,5]  R2727     2.4374131858348846e-01
    z[8,9,5]  R2728     3.1710278242826462e-02
    z[8,9,5]  R2729     1.4875052869319916e-01
    z[8,9,5]  R2730     3.3772411942481995e-01
    z[8,9,5]  R2731     1.4556702971458435e-01
    z[8,9,5]  R2732     6.0349458456039429e-01
    z[8,9,5]  R2733     -2.3410108685493469e-01
    z[8,9,5]  R2734     2.3875202238559723e-01
    z[8,9,5]  R2735     0.532198429107666
    z[8,9,5]  R2736     -8.8648170232772827e-02
    z[8,9,5]  R2737     -1.3305827043950558e-02
    z[8,9,5]  R2738     -3.9736879989504814e-03
    z[8,9,5]  R2739     0.3140889108181
    z[8,9,5]  R2740     -4.4955092668533325e-01
    z[8,9,5]  R2741     -5.2958631515502930e-01
    z[8,9,5]  R2742     -4.5618087053298950e-01
    z[8,9,5]  R2743     -2.2290091216564178e-01
    z[8,9,6]  R80       -1
    z[8,9,6]  R89       1
    z[8,9,6]  R2642     -1
    z[8,9,6]  R2643     1
    z[8,9,6]  R2644     -8.8847614824771881e-02
    z[8,9,6]  R2645     -3.5660311579704285e-01
    z[8,9,6]  R2646     -4.1534259915351868e-01
    z[8,9,6]  R2647     -2.6995116472244263e-01
    z[8,9,6]  R2648     -2.3203879594802856e-01
    z[8,9,6]  R2649     3.6412918567657471e-01
    z[8,9,6]  R2650     -4.2200666666030884e-01
    z[8,9,6]  R2651     -3.0473735928535461e-01
    z[8,9,6]  R2652     0.0794663280248642
    z[8,9,6]  R2653     -2.8393331170082092e-01
    z[8,9,6]  R2654     1.3920005876570940e-03
    z[8,9,6]  R2655     1.8540833890438080e-01
    z[8,9,6]  R2656     -2.5751054286956787e-01
    z[8,9,6]  R2657     3.5152930766344070e-02
    z[8,9,6]  R2658     1.1452741920948029e-01
    z[8,9,6]  R2659     7.9993076622486115e-02
    z[8,9,6]  R2660     9.3643620610237122e-02
    z[8,9,6]  R2661     2.6505556702613831e-01
    z[8,9,6]  R2662     1.8180431425571442e-01
    z[8,9,6]  R2663     9.1106317937374115e-02
    z[8,9,6]  R2664     4.5899960398674011e-01
    z[8,9,6]  R2665     3.2285347580909729e-01
    z[8,9,6]  R2666     4.3084564805030823e-01
    z[8,9,6]  R2667     9.2565260827541351e-02
    z[8,9,6]  R2668     1.7285913228988647e-01
    z[8,9,6]  R2669     3.6376565694808960e-02
    z[8,9,6]  R2670     -1.4245083928108215e-01
    z[8,9,6]  R2671     -7.5721487402915955e-02
    z[8,9,6]  R2672     2.4506205692887306e-02
    z[8,9,6]  R2673     2.8213104605674744e-01
    z[8,9,6]  R2674     -1.6030804812908173e-01
    z[8,9,6]  R2675     2.5406202673912048e-01
    z[8,9,6]  R2676     -2.9143482446670532e-01
    z[8,9,6]  R2677     -1.5985479950904846e-01
    z[8,9,6]  R2678     4.9594348669052124e-01
    z[8,9,6]  R2679     -4.8691403120756149e-02
    z[8,9,6]  R2680     -2.0474494993686676e-01
    z[8,9,6]  R2681     0.178403839468956
    z[8,9,6]  R2682     -2.4913826584815979e-01
    z[8,9,6]  R2683     1.3315147161483765e-01
    z[8,9,6]  R2684     -1.4845924079418182e-01
    z[8,9,6]  R2685     -2.6704590767621994e-02
    z[8,9,6]  R2686     -3.8042172789573669e-01
    z[8,9,6]  R2687     2.1605546772480011e-01
    z[8,9,6]  R2688     -1.5994818508625031e-01
    z[8,9,6]  R2689     -3.8616311550140381e-01
    z[8,9,6]  R2690     -1.2715712189674377e-01
    z[8,9,6]  R2691     -7.8070342540740967e-02
    z[8,9,6]  R2692     -0.329046368598938
    z[8,9,6]  R2693     3.5990753769874573e-01
    z[8,9,6]  R2694     -0.289164662361145
    z[8,9,6]  R2695     2.4522738531231880e-02
    z[8,9,6]  R2696     2.5590965151786804e-01
    z[8,9,6]  R2697     -3.7311750650405884e-01
    z[8,9,6]  R2698     -2.2620756924152374e-01
    z[8,9,6]  R2699     -1.4772605895996094e-01
    z[8,9,6]  R2700     0.128773495554924
    z[8,9,6]  R2701     -4.7608497738838196e-01
    z[8,9,6]  R2702     -6.4299941062927246e-01
    z[8,9,6]  R2703     -1.4596696197986603e-01
    z[8,9,6]  R2704     8.9961051940917969e-02
    z[8,9,6]  R2705     -8.0054707825183868e-02
    z[8,9,6]  R2706     -3.9782442152500153e-02
    z[8,9,6]  R2707     -6.8114414811134338e-02
    z[8,9,6]  R2708     4.4111007452011108e-01
    z[8,9,6]  R2709     -3.1494843959808350e-01
    z[8,9,6]  R2710     3.0385980010032654e-01
    z[8,9,6]  R2711     2.3639582097530365e-01
    z[8,9,6]  R2712     4.2337965965270996e-01
    z[8,9,6]  R2713     -4.6211636066436768e-01
    z[8,9,6]  R2714     2.7650898694992065e-01
    z[8,9,6]  R2715     1.2029550969600677e-01
    z[8,9,6]  R2716     -0.367557555437088
    z[8,9,6]  R2717     -6.6486102342605591e-01
    z[8,9,6]  R2718     2.4418263137340546e-01
    z[8,9,6]  R2719     -3.9550852775573730e-01
    z[8,9,6]  R2720     6.5928483009338379e-01
    z[8,9,6]  R2721     4.3085891008377075e-01
    z[8,9,6]  R2722     3.9106476306915283e-01
    z[8,9,6]  R2723     -3.1564164161682129e-01
    z[8,9,6]  R2724     3.4440398216247559e-01
    z[8,9,6]  R2725     2.4238672852516174e-01
    z[8,9,6]  R2726     8.0896958708763123e-02
    z[8,9,6]  R2727     1.1481685936450958e-01
    z[8,9,6]  R2728     9.6243396401405334e-02
    z[8,9,6]  R2729     -2.6154699921607971e-01
    z[8,9,6]  R2730     -2.4617652595043182e-01
    z[8,9,6]  R2731     3.5888656973838806e-01
    z[8,9,6]  R2732     -1.4568477869033813e-01
    z[8,9,6]  R2733     -8.4414698183536530e-02
    z[8,9,6]  R2734     7.7482990920543671e-02
    z[8,9,6]  R2735     1.1786509305238724e-01
    z[8,9,6]  R2736     -2.7869653701782227e-01
    z[8,9,6]  R2737     -4.2002275586128235e-01
    z[8,9,6]  R2738     -9.0852063149213791e-03
    z[8,9,6]  R2739     1.5262927114963531e-01
    z[8,9,6]  R2740     -1.0978161543607712e-01
    z[8,9,6]  R2741     2.3072727024555206e-01
    z[8,9,6]  R2742     -5.3429072722792625e-03
    z[8,9,6]  R2743     -3.3589568734169006e-01
    z[9,8,0]  R74       1
    z[9,8,0]  R83       -1
    z[9,8,0]  R2744     -1
    z[9,8,0]  R2745     1
    z[9,8,0]  R2758     -4.7083017230033875e-01
    z[9,8,0]  R2759     -2.9554355144500732e-01
    z[9,8,0]  R2760     -4.5847481489181519e-01
    z[9,8,0]  R2761     -3.4898281097412109e-01
    z[9,8,0]  R2762     -3.4378483891487122e-01
    z[9,8,0]  R2763     -4.1573926806449890e-01
    z[9,8,0]  R2764     -3.2152774930000305e-01
    z[9,8,0]  R2765     -2.9459995031356812e-01
    z[9,8,0]  R2766     -4.6038252115249634e-01
    z[9,8,0]  R2767     -3.3345550298690796e-01
    z[9,8,0]  R2768     9.6774977445602417e-01
    z[9,8,0]  R2769     9.2610377073287964e-01
    z[9,8,0]  R2770     9.3839341402053833e-01
    z[9,8,0]  R2771     0.913361668586731
    z[9,8,0]  R2772     -5.5221021175384521e-01
    z[9,8,0]  R2773     9.2324179410934448e-01
    z[9,8,0]  R2774     8.7861239910125732e-01
    z[9,8,0]  R2775     8.6381405591964722e-01
    z[9,8,0]  R2776     -5.0134289264678955e-01
    z[9,8,0]  R2777     2.2638149559497833e-01
    z[9,8,0]  R2778     -9.0156745910644531e-01
    z[9,8,0]  R2779     -6.7771470546722412e-01
    z[9,8,0]  R2780     -0.654639482498169
    z[9,8,0]  R2781     -4.5600414276123047e-01
    z[9,8,0]  R2782     -5.2531290054321289e-01
    z[9,8,0]  R2783     -1.3764478266239166e-01
    z[9,8,0]  R2784     1.3541062362492085e-02
    z[9,8,0]  R2785     -4.0826670825481415e-02
    z[9,8,0]  R2786     -3.0490857362747192e-01
    z[9,8,0]  R2787     4.8627230525016785e-01
    z[9,8,0]  R2788     -1.3738344609737396e-01
    z[9,8,0]  R2789     1.5904630720615387e-01
    z[9,8,0]  R2790     2.5986087322235107e-01
    z[9,8,0]  R2791     0.145345538854599
    z[9,8,0]  R2792     2.4203133583068848e-01
    z[9,8,0]  R2793     5.2579408884048462e-01
    z[9,8,0]  R2794     3.9317697286605835e-01
    z[9,8,0]  R2795     4.3037596344947815e-01
    z[9,8,0]  R2796     2.6960945129394531e-01
    z[9,8,0]  R2797     0.500088095664978
    z[9,8,0]  R2798     8.1707149744033813e-02
    z[9,8,0]  R2799     2.7697938680648804e-01
    z[9,8,0]  R2800     3.6197766661643982e-01
    z[9,8,0]  R2801     7.8655153512954712e-02
    z[9,8,0]  R2802     4.1394266486167908e-01
    z[9,8,0]  R2803     3.3076366782188416e-01
    z[9,8,0]  R2804     3.3056697249412537e-01
    z[9,8,0]  R2805     2.4081142246723175e-01
    z[9,8,0]  R2806     3.9070203900337219e-01
    z[9,8,0]  R2807     3.9883446693420410e-01
    z[9,8,0]  R2808     7.5349879264831543e-01
    z[9,8,0]  R2809     0.307144433259964
    z[9,8,0]  R2810     2.5218990445137024e-01
    z[9,8,0]  R2811     1.7160646617412567e-02
    z[9,8,0]  R2812     4.0592528879642487e-02
    z[9,8,0]  R2813     7.5310325622558594e-01
    z[9,8,0]  R2814     0.409322589635849
    z[9,8,0]  R2815     1.8494494259357452e-01
    z[9,8,0]  R2816     2.6719310879707336e-01
    z[9,8,0]  R2817     4.4634243845939636e-01
    z[9,8,0]  R2818     -3.0533054471015930e-01
    z[9,8,0]  R2819     -1.7112727463245392e-01
    z[9,8,0]  R2820     -3.9704239368438721e-01
    z[9,8,0]  R2821     -1.7034025490283966e-01
    z[9,8,0]  R2822     -1.6297745704650879e-01
    z[9,8,0]  R2823     -1.6063745319843292e-01
    z[9,8,0]  R2824     -1.8528106808662415e-01
    z[9,8,0]  R2825     -2.2841534018516541e-01
    z[9,8,0]  R2826     -2.7883759140968323e-01
    z[9,8,0]  R2827     -6.5518236160278320e-01
    z[9,8,0]  R2828     5.8571350574493408e-01
    z[9,8,0]  R2829     2.8354993462562561e-01
    z[9,8,0]  R2830     5.8395421504974365e-01
    z[9,8,0]  R2831     5.2461272478103638e-01
    z[9,8,0]  R2832     -5.0638926029205322e-01
    z[9,8,0]  R2833     4.8312941193580627e-01
    z[9,8,0]  R2834     6.8348360061645508e-01
    z[9,8,0]  R2835     4.1684523224830627e-01
    z[9,8,0]  R2836     -4.5816802978515625e-01
    z[9,8,0]  R2837     -0.49376380443573
    z[9,8,0]  R2838     6.7443841695785522e-01
    z[9,8,0]  R2839     7.0656412839889526e-01
    z[9,8,0]  R2840     -2.4325503408908844e-01
    z[9,8,0]  R2841     3.9420586079359055e-02
    z[9,8,0]  R2842     4.8067179322242737e-01
    z[9,8,0]  R2843     4.1502940654754639e-01
    z[9,8,0]  R2844     3.1739464402198792e-01
    z[9,8,0]  R2845     -4.0888100862503052e-01
    z[9,8,0]  R2846     3.8763949275016785e-01
    z[9,8,0]  R2847     -1.2355958670377731e-01
    z[9,8,0]  R2848     4.4388791918754578e-01
    z[9,8,0]  R2849     0.376607209444046
    z[9,8,0]  R2850     -3.8632029294967651e-01
    z[9,8,0]  R2851     -2.6457989215850830e-01
    z[9,8,0]  R2852     2.8549227118492126e-01
    z[9,8,0]  R2853     4.7952511906623840e-01
    z[9,8,0]  R2854     -6.6012746095657349e-01
    z[9,8,0]  R2855     -4.7437986731529236e-01
    z[9,8,0]  R2856     -4.8283296823501587e-01
    z[9,8,0]  R2857     6.6481798887252808e-01
    z[9,8,1]  R75       1
    z[9,8,1]  R84       -1
    z[9,8,1]  R2746     -1
    z[9,8,1]  R2747     1
    z[9,8,1]  R2758     3.2166350632905960e-02
    z[9,8,1]  R2759     0.0396723710000515
    z[9,8,1]  R2760     8.4040112793445587e-02
    z[9,8,1]  R2761     -8.3546109497547150e-02
    z[9,8,1]  R2762     -1.7947475612163544e-01
    z[9,8,1]  R2763     -4.4269564747810364e-01
    z[9,8,1]  R2764     -3.2941896468400955e-02
    z[9,8,1]  R2765     3.1364038586616516e-01
    z[9,8,1]  R2766     7.9319693148136139e-02
    z[9,8,1]  R2767     -2.8139597177505493e-01
    z[9,8,1]  R2768     2.0339037477970123e-01
    z[9,8,1]  R2769     2.5800153613090515e-01
    z[9,8,1]  R2770     1.5622794628143311e-01
    z[9,8,1]  R2771     2.4087810516357422e-01
    z[9,8,1]  R2772     2.5549891591072083e-01
    z[9,8,1]  R2773     1.9792918860912323e-01
    z[9,8,1]  R2774     2.9791086912155151e-01
    z[9,8,1]  R2775     2.5721102952957153e-01
    z[9,8,1]  R2776     -1.3574388623237610e-01
    z[9,8,1]  R2777     4.6913331747055054e-01
    z[9,8,1]  R2778     -1.8754141032695770e-01
    z[9,8,1]  R2779     0.230122908949852
    z[9,8,1]  R2780     1.6657446324825287e-01
    z[9,8,1]  R2781     1.3152468204498291e-01
    z[9,8,1]  R2782     4.8701906204223633e-01
    z[9,8,1]  R2783     0.788979172706604
    z[9,8,1]  R2784     6.9596582651138306e-01
    z[9,8,1]  R2785     7.3576313257217407e-01
    z[9,8,1]  R2786     7.1478289365768433e-01
    z[9,8,1]  R2787     6.8016147613525391e-01
    z[9,8,1]  R2788     6.5989780426025391e-01
    z[9,8,1]  R2789     6.5643984079360962e-01
    z[9,8,1]  R2790     6.2312871217727661e-01
    z[9,8,1]  R2791     6.6643327474594116e-01
    z[9,8,1]  R2792     5.7647407054901123e-01
    z[9,8,1]  R2793     6.2587428092956543e-01
    z[9,8,1]  R2794     5.4993522167205811e-01
    z[9,8,1]  R2795     6.0498905181884766e-01
    z[9,8,1]  R2796     5.7798069715499878e-01
    z[9,8,1]  R2797     6.0623961687088013e-01
    z[9,8,1]  R2798     8.1107234954833984e-01
    z[9,8,1]  R2799     7.5782066583633423e-01
    z[9,8,1]  R2800     6.4041876792907715e-01
    z[9,8,1]  R2801     6.3288372755050659e-01
    z[9,8,1]  R2802     5.7941132783889771e-01
    z[9,8,1]  R2803     5.8373361825942993e-01
    z[9,8,1]  R2804     -0.658723771572113
    z[9,8,1]  R2805     -4.7224420309066772e-01
    z[9,8,1]  R2806     -7.5151330232620239e-01
    z[9,8,1]  R2807     -7.0992028713226318e-01
    z[9,8,1]  R2808     5.3390890359878540e-01
    z[9,8,1]  R2809     -1.1291924118995667e-01
    z[9,8,1]  R2810     9.5239475369453430e-02
    z[9,8,1]  R2811     3.3926531672477722e-01
    z[9,8,1]  R2812     4.6290901303291321e-01
    z[9,8,1]  R2813     4.4603973627090454e-01
    z[9,8,1]  R2814     -3.7558069825172424e-01
    z[9,8,1]  R2815     -2.9839560389518738e-01
    z[9,8,1]  R2816     3.7120589613914490e-01
    z[9,8,1]  R2817     -2.6726689934730530e-01
    z[9,8,1]  R2818     -9.0453439950942993e-01
    z[9,8,1]  R2819     -9.1103643178939819e-01
    z[9,8,1]  R2820     -0.866890549659729
    z[9,8,1]  R2821     -9.0055418014526367e-01
    z[9,8,1]  R2822     -8.8076150417327881e-01
    z[9,8,1]  R2823     -8.8842248916625977e-01
    z[9,8,1]  R2824     -8.7182438373565674e-01
    z[9,8,1]  R2825     -0.855061948299408
    z[9,8,1]  R2826     -8.2966303825378418e-01
    z[9,8,1]  R2827     -7.3643636703491211e-01
    z[9,8,1]  R2828     -2.8715163469314575e-01
    z[9,8,1]  R2829     -1.7557007074356079e-01
    z[9,8,1]  R2830     -5.1222376525402069e-02
    z[9,8,1]  R2831     1.0439503192901611e-01
    z[9,8,1]  R2832     6.6497230529785156e-01
    z[9,8,1]  R2833     -7.8976178169250488e-01
    z[9,8,1]  R2834     -0.595569372177124
    z[9,8,1]  R2835     4.4834807515144348e-01
    z[9,8,1]  R2836     7.5294440984725952e-01
    z[9,8,1]  R2837     0.756111741065979
    z[9,8,1]  R2838     4.8174926638603210e-01
    z[9,8,1]  R2839     -2.0700308680534363e-01
    z[9,8,1]  R2840     3.3629408478736877e-01
    z[9,8,1]  R2841     -3.3663976192474365e-01
    z[9,8,1]  R2842     -1.3645662367343903e-01
    z[9,8,1]  R2843     4.5533582568168640e-01
    z[9,8,1]  R2844     -5.2777826786041260e-01
    z[9,8,1]  R2845     8.2022237777709961e-01
    z[9,8,1]  R2846     -5.9745508432388306e-01
    z[9,8,1]  R2847     -6.4928692579269409e-01
    z[9,8,1]  R2848     -4.7594240307807922e-01
    z[9,8,1]  R2849     -2.1905189752578735e-01
    z[9,8,1]  R2850     3.1492364406585693e-01
    z[9,8,1]  R2851     3.3113875985145569e-01
    z[9,8,1]  R2852     -7.1422350406646729e-01
    z[9,8,1]  R2853     -5.2346724271774292e-01
    z[9,8,1]  R2854     6.4730447530746460e-01
    z[9,8,1]  R2855     5.1535248756408691e-01
    z[9,8,1]  R2856     5.5950152873992920e-01
    z[9,8,1]  R2857     -4.5236143469810486e-01
    z[9,8,2]  R76       1
    z[9,8,2]  R85       -1
    z[9,8,2]  R2748     -1
    z[9,8,2]  R2749     1
    z[9,8,2]  R2758     7.4854022264480591e-01
    z[9,8,2]  R2759     7.7322673797607422e-01
    z[9,8,2]  R2760     5.5614316463470459e-01
    z[9,8,2]  R2761     7.4131155014038086e-01
    z[9,8,2]  R2762     6.0885030031204224e-01
    z[9,8,2]  R2763     5.5249720811843872e-01
    z[9,8,2]  R2764     9.0784209966659546e-01
    z[9,8,2]  R2765     6.7819595336914062e-01
    z[9,8,2]  R2766     2.7134335041046143e-01
    z[9,8,2]  R2767     4.2744603753089905e-01
    z[9,8,2]  R2768     5.1857554353773594e-03
    z[9,8,2]  R2769     1.6024602949619293e-01
    z[9,8,2]  R2770     1.8079839646816254e-01
    z[9,8,2]  R2771     -0.00484444061294198
    z[9,8,2]  R2772     -4.9005034379661083e-03
    z[9,8,2]  R2773     -1.6564095392823219e-02
    z[9,8,2]  R2774     1.6810914874076843e-01
    z[9,8,2]  R2775     2.9709663987159729e-01
    z[9,8,2]  R2776     -1.4267097413539886e-01
    z[9,8,2]  R2777     8.9215926826000214e-02
    z[9,8,2]  R2778     1.6153568029403687e-01
    z[9,8,2]  R2779     -1.7516578733921051e-01
    z[9,8,2]  R2780     1.5358678996562958e-01
    z[9,8,2]  R2781     3.4399747848510742e-01
    z[9,8,2]  R2782     2.5514939427375793e-01
    z[9,8,2]  R2783     -2.8482022881507874e-01
    z[9,8,2]  R2784     1.5267622470855713e-01
    z[9,8,2]  R2785     -9.4846390187740326e-02
    z[9,8,2]  R2786     -0.0899360403418541
    z[9,8,2]  R2787     -3.1053539365530014e-02
    z[9,8,2]  R2788     3.2477059960365295e-01
    z[9,8,2]  R2789     -2.5495512410998344e-02
    z[9,8,2]  R2790     1.2463396787643433e-01
    z[9,8,2]  R2791     -2.3540388047695160e-01
    z[9,8,2]  R2792     2.9795238375663757e-01
    z[9,8,2]  R2793     -1.3816735148429871e-01
    z[9,8,2]  R2794     4.4385454058647156e-01
    z[9,8,2]  R2795     -2.2756014764308929e-01
    z[9,8,2]  R2796     3.6119814962148666e-02
    z[9,8,2]  R2797     1.2279379367828369e-01
    z[9,8,2]  R2798     -2.8874114155769348e-01
    z[9,8,2]  R2799     -4.0515437722206116e-02
    z[9,8,2]  R2800     2.6859748363494873e-01
    z[9,8,2]  R2801     -1.2695711851119995e-01
    z[9,8,2]  R2802     4.6635717153549194e-01
    z[9,8,2]  R2803     3.3958196640014648e-01
    z[9,8,2]  R2804     3.8723897933959961e-01
    z[9,8,2]  R2805     3.9988216757774353e-01
    z[9,8,2]  R2806     7.4228219687938690e-02
    z[9,8,2]  R2807     1.4176069200038910e-01
    z[9,8,2]  R2808     -4.5283399522304535e-02
    z[9,8,2]  R2809     3.3473870158195496e-01
    z[9,8,2]  R2810     5.7471507787704468e-01
    z[9,8,2]  R2811     5.6111335754394531e-01
    z[9,8,2]  R2812     6.4216136932373047e-01
    z[9,8,2]  R2813     5.1232177764177322e-02
    z[9,8,2]  R2814     2.9302367568016052e-01
    z[9,8,2]  R2815     3.7862551212310791e-01
    z[9,8,2]  R2816     5.2351778745651245e-01
    z[9,8,2]  R2817     1.1340779066085815e-01
    z[9,8,2]  R2818     -3.4694414585828781e-02
    z[9,8,2]  R2819     -2.3301114141941071e-01
    z[9,8,2]  R2820     -5.4809297434985638e-03
    z[9,8,2]  R2821     -1.3062655925750732e-01
    z[9,8,2]  R2822     -3.1449711322784424e-01
    z[9,8,2]  R2823     -1.4832252264022827e-01
    z[9,8,2]  R2824     -1.4843389391899109e-01
    z[9,8,2]  R2825     -0.200262188911438
    z[9,8,2]  R2826     -2.0472073554992676e-01
    z[9,8,2]  R2827     2.5710277259349823e-02
    z[9,8,2]  R2828     4.2051258683204651e-01
    z[9,8,2]  R2829     5.9493917226791382e-01
    z[9,8,2]  R2830     2.7369165420532227e-01
    z[9,8,2]  R2831     7.1624934673309326e-01
    z[9,8,2]  R2832     4.4915539026260376e-01
    z[9,8,2]  R2833     1.2079031206667423e-02
    z[9,8,2]  R2834     -0.0837479680776596
    z[9,8,2]  R2835     -9.6484325826168060e-02
    z[9,8,2]  R2836     0.119090735912323
    z[9,8,2]  R2837     1.2360082007944584e-02
    z[9,8,2]  R2838     -0.00766489002853632
    z[9,8,2]  R2839     5.0639349222183228e-01
    z[9,8,2]  R2840     8.1966572999954224e-01
    z[9,8,2]  R2841     6.4619135856628418e-01
    z[9,8,2]  R2842     -2.9444175306707621e-03
    z[9,8,2]  R2843     6.7845833301544189e-01
    z[9,8,2]  R2844     1.3194097578525543e-01
    z[9,8,2]  R2845     1.8230533599853516e-01
    z[9,8,2]  R2846     0.210468590259552
    z[9,8,2]  R2847     5.4060208797454834e-01
    z[9,8,2]  R2848     3.1908458471298218e-01
    z[9,8,2]  R2849     3.0309337377548218e-01
    z[9,8,2]  R2850     7.4047005176544189e-01
    z[9,8,2]  R2851     5.6868463754653931e-01
    z[9,8,2]  R2852     2.9122796654701233e-01
    z[9,8,2]  R2853     5.1562881469726562e-01
    z[9,8,2]  R2854     1.3450199365615845e-01
    z[9,8,2]  R2855     1.6099503636360168e-01
    z[9,8,2]  R2856     -6.8838261067867279e-02
    z[9,8,2]  R2857     -4.3100094795227051e-01
    z[9,8,3]  R77       1
    z[9,8,3]  R86       -1
    z[9,8,3]  R2750     -1
    z[9,8,3]  R2751     1
    z[9,8,3]  R2758     -1.8052347004413605e-01
    z[9,8,3]  R2759     5.3283762186765671e-02
    z[9,8,3]  R2760     -4.3473982810974121e-01
    z[9,8,3]  R2761     2.1651349961757660e-01
    z[9,8,3]  R2762     -4.9789324402809143e-01
    z[9,8,3]  R2763     1.2577231228351593e-01
    z[9,8,3]  R2764     1.9749045372009277e-01
    z[9,8,3]  R2765     2.5030982494354248e-01
    z[9,8,3]  R2766     3.9309477806091309e-01
    z[9,8,3]  R2767     -4.4370139949023724e-03
    z[9,8,3]  R2768     -8.5052363574504852e-02
    z[9,8,3]  R2769     -1.7347997426986694e-01
    z[9,8,3]  R2770     1.3206608593463898e-01
    z[9,8,3]  R2771     1.8585222959518433e-01
    z[9,8,3]  R2772     -6.2713988125324249e-02
    z[9,8,3]  R2773     -0.0458403155207634
    z[9,8,3]  R2774     1.0051049292087555e-01
    z[9,8,3]  R2775     4.5493662357330322e-02
    z[9,8,3]  R2776     6.7066222429275513e-01
    z[9,8,3]  R2777     -3.6637911200523376e-01
    z[9,8,3]  R2778     1.6711705923080444e-01
    z[9,8,3]  R2779     -6.0624879598617554e-01
    z[9,8,3]  R2780     1.7043847590684891e-02
    z[9,8,3]  R2781     -1.6985219717025757e-01
    z[9,8,3]  R2782     3.2322707772254944e-01
    z[9,8,3]  R2783     -3.3934235572814941e-01
    z[9,8,3]  R2784     -6.7457742989063263e-02
    z[9,8,3]  R2785     2.3494258522987366e-01
    z[9,8,3]  R2786     3.4122428297996521e-01
    z[9,8,3]  R2787     4.2916625738143921e-01
    z[9,8,3]  R2788     -1.7377541959285736e-01
    z[9,8,3]  R2789     2.0292323082685471e-02
    z[9,8,3]  R2790     -4.3427139520645142e-01
    z[9,8,3]  R2791     -3.8042291998863220e-01
    z[9,8,3]  R2792     -5.1961505413055420e-01
    z[9,8,3]  R2793     1.4480647444725037e-01
    z[9,8,3]  R2794     8.0680213868618011e-02
    z[9,8,3]  R2795     4.9613124132156372e-01
    z[9,8,3]  R2796     4.5380535721778870e-01
    z[9,8,3]  R2797     1.2200967222452164e-01
    z[9,8,3]  R2798     -3.4977838397026062e-01
    z[9,8,3]  R2799     -2.0434801280498505e-01
    z[9,8,3]  R2800     -5.1644808053970337e-01
    z[9,8,3]  R2801     -1.8804410472512245e-02
    z[9,8,3]  R2802     3.9058357477188110e-01
    z[9,8,3]  R2803     4.0062817931175232e-01
    z[9,8,3]  R2804     3.0354353785514832e-01
    z[9,8,3]  R2805     4.3460509181022644e-01
    z[9,8,3]  R2806     1.4760607481002808e-01
    z[9,8,3]  R2807     3.7209221720695496e-01
    z[9,8,3]  R2808     2.9557514190673828e-01
    z[9,8,3]  R2809     0.511228084564209
    z[9,8,3]  R2810     3.1941589713096619e-01
    z[9,8,3]  R2811     1.8191672861576080e-01
    z[9,8,3]  R2812     2.5957101583480835e-01
    z[9,8,3]  R2813     -1.8496680259704590e-01
    z[9,8,3]  R2814     2.1793392300605774e-01
    z[9,8,3]  R2815     2.8237605094909668e-01
    z[9,8,3]  R2816     3.6248272657394409e-01
    z[9,8,3]  R2817     1.5013046562671661e-01
    z[9,8,3]  R2818     -2.2524642944335938e-01
    z[9,8,3]  R2819     1.7526608705520630e-01
    z[9,8,3]  R2820     -1.3580419123172760e-01
    z[9,8,3]  R2821     1.3678257167339325e-01
    z[9,8,3]  R2822     -3.9878997951745987e-02
    z[9,8,3]  R2823     1.4355589635670185e-02
    z[9,8,3]  R2824     2.3384894430637360e-01
    z[9,8,3]  R2825     -3.0689659714698792e-01
    z[9,8,3]  R2826     -2.2202888131141663e-01
    z[9,8,3]  R2827     0.027417017146945
    z[9,8,3]  R2828     3.6058798432350159e-01
    z[9,8,3]  R2829     6.0836231708526611e-01
    z[9,8,3]  R2830     4.7131389379501343e-01
    z[9,8,3]  R2831     0.214554101228714
    z[9,8,3]  R2832     1.1563784629106522e-01
    z[9,8,3]  R2833     2.9142510890960693e-01
    z[9,8,3]  R2834     -1.1412892490625381e-02
    z[9,8,3]  R2835     -3.6228007078170776e-01
    z[9,8,3]  R2836     -3.9543735980987549e-01
    z[9,8,3]  R2837     -1.8169339001178741e-01
    z[9,8,3]  R2838     -4.5411369204521179e-01
    z[9,8,3]  R2839     3.3606874942779541e-01
    z[9,8,3]  R2840     2.1002674102783203e-01
    z[9,8,3]  R2841     5.6889343261718750e-01
    z[9,8,3]  R2842     4.3332943320274353e-01
    z[9,8,3]  R2843     3.4539647400379181e-02
    z[9,8,3]  R2844     3.5232019424438477e-01
    z[9,8,3]  R2845     4.5969886705279350e-03
    z[9,8,3]  R2846     1.3093477487564087e-01
    z[9,8,3]  R2847     2.0541979372501373e-01
    z[9,8,3]  R2848     3.0937123298645020e-01
    z[9,8,3]  R2849     4.8632130026817322e-01
    z[9,8,3]  R2850     2.3699489235877991e-01
    z[9,8,3]  R2851     6.1725121736526489e-01
    z[9,8,3]  R2852     3.8626599311828613e-01
    z[9,8,3]  R2853     -1.5872826799750328e-02
    z[9,8,3]  R2854     -2.7297082543373108e-01
    z[9,8,3]  R2855     -3.3678501844406128e-01
    z[9,8,3]  R2856     -3.4425669908523560e-01
    z[9,8,3]  R2857     -5.6831665337085724e-02
    z[9,8,4]  R78       1
    z[9,8,4]  R87       -1
    z[9,8,4]  R2752     -1
    z[9,8,4]  R2753     1
    z[9,8,4]  R2758     1.5794004499912262e-01
    z[9,8,4]  R2759     -0.287248820066452
    z[9,8,4]  R2760     -4.6690490841865540e-01
    z[9,8,4]  R2761     -3.5223785042762756e-01
    z[9,8,4]  R2762     -3.3591628074645996e-01
    z[9,8,4]  R2763     -5.2343004941940308e-01
    z[9,8,4]  R2764     -1.2184038013219833e-01
    z[9,8,4]  R2765     -8.3195351064205170e-02
    z[9,8,4]  R2766     4.4558685272932053e-02
    z[9,8,4]  R2767     -6.4415490627288818e-01
    z[9,8,4]  R2768     -3.8812708109617233e-02
    z[9,8,4]  R2769     7.4055716395378113e-03
    z[9,8,4]  R2770     -1.5727436542510986e-01
    z[9,8,4]  R2771     4.6703465282917023e-02
    z[9,8,4]  R2772     5.7107192277908325e-01
    z[9,8,4]  R2773     -3.9166450500488281e-02
    z[9,8,4]  R2774     6.7736767232418060e-02
    z[9,8,4]  R2775     8.7502032518386841e-02
    z[9,8,4]  R2776     -1.7671035602688789e-02
    z[9,8,4]  R2777     5.8958941698074341e-01
    z[9,8,4]  R2778     1.9108204171061516e-02
    z[9,8,4]  R2779     1.2698955833911896e-01
    z[9,8,4]  R2780     -3.3748939633369446e-02
    z[9,8,4]  R2781     -3.2901132106781006e-01
    z[9,8,4]  R2782     -6.1276316642761230e-02
    z[9,8,4]  R2783     -5.1297068595886230e-02
    z[9,8,4]  R2784     -2.2719316184520721e-01
    z[9,8,4]  R2785     -2.5636243820190430e-01
    z[9,8,4]  R2786     3.4080383181571960e-01
    z[9,8,4]  R2787     -8.4892563521862030e-02
    z[9,8,4]  R2788     5.3927540779113770e-01
    z[9,8,4]  R2789     5.7670968770980835e-01
    z[9,8,4]  R2790     1.1724369972944260e-01
    z[9,8,4]  R2791     5.1187109947204590e-01
    z[9,8,4]  R2792     4.8995384573936462e-01
    z[9,8,4]  R2793     -4.4858568906784058e-01
    z[9,8,4]  R2794     4.0596362948417664e-01
    z[9,8,4]  R2795     -2.9080381616950035e-02
    z[9,8,4]  R2796     2.3985201492905617e-02
    z[9,8,4]  R2797     5.3897273540496826e-01
    z[9,8,4]  R2798     2.5838559865951538e-01
    z[9,8,4]  R2799     9.1996602714061737e-02
    z[9,8,4]  R2800     1.8558706343173981e-01
    z[9,8,4]  R2801     6.3261657953262329e-01
    z[9,8,4]  R2802     3.5041567683219910e-01
    z[9,8,4]  R2803     -3.8997948169708252e-01
    z[9,8,4]  R2804     -2.3826885968446732e-02
    z[9,8,4]  R2805     -1.9107882678508759e-01
    z[9,8,4]  R2806     -2.1714706718921661e-01
    z[9,8,4]  R2807     -1.2603472173213959e-01
    z[9,8,4]  R2808     1.4715710654854774e-02
    z[9,8,4]  R2809     -4.6450448036193848e-01
    z[9,8,4]  R2810     -5.1308578252792358e-01
    z[9,8,4]  R2811     -6.5982139110565186e-01
    z[9,8,4]  R2812     -4.9314025044441223e-01
    z[9,8,4]  R2813     4.0272939950227737e-03
    z[9,8,4]  R2814     -6.1621171236038208e-01
    z[9,8,4]  R2815     -6.7005592584609985e-01
    z[9,8,4]  R2816     -6.1298555135726929e-01
    z[9,8,4]  R2817     -7.7415800094604492e-01
    z[9,8,4]  R2818     9.8041877150535583e-02
    z[9,8,4]  R2819     0.0976729765534401
    z[9,8,4]  R2820     5.9816960245370865e-02
    z[9,8,4]  R2821     3.2650753855705261e-01
    z[9,8,4]  R2822     -5.2045132964849472e-02
    z[9,8,4]  R2823     9.0918548405170441e-02
    z[9,8,4]  R2824     3.1808158755302429e-01
    z[9,8,4]  R2825     -1.0641106218099594e-01
    z[9,8,4]  R2826     2.3723126947879791e-01
    z[9,8,4]  R2827     5.1848553121089935e-03
    z[9,8,4]  R2828     0.232549786567688
    z[9,8,4]  R2829     2.1865151822566986e-01
    z[9,8,4]  R2830     1.2797074019908905e-01
    z[9,8,4]  R2831     1.5356892347335815e-01
    z[9,8,4]  R2832     4.4284559786319733e-02
    z[9,8,4]  R2833     1.8996295332908630e-01
    z[9,8,4]  R2834     6.6601976752281189e-02
    z[9,8,4]  R2835     -1.3420465588569641e-01
    z[9,8,4]  R2836     4.3489160016179085e-03
    z[9,8,4]  R2837     1.7702130600810051e-02
    z[9,8,4]  R2838     -1.3463121652603149e-01
    z[9,8,4]  R2839     -1.4478822052478790e-01
    z[9,8,4]  R2840     1.0083559900522232e-01
    z[9,8,4]  R2841     2.5494772195816040e-01
    z[9,8,4]  R2842     -5.0143241882324219e-01
    z[9,8,4]  R2843     6.1852414160966873e-02
    z[9,8,4]  R2844     3.2360956072807312e-01
    z[9,8,4]  R2845     -2.4408391118049622e-01
    z[9,8,4]  R2846     4.0664246678352356e-01
    z[9,8,4]  R2847     5.5780843831598759e-03
    z[9,8,4]  R2848     -5.4525423049926758e-01
    z[9,8,4]  R2849     2.4329267442226410e-01
    z[9,8,4]  R2850     -4.4477835297584534e-02
    z[9,8,4]  R2851     2.0227548480033875e-01
    z[9,8,4]  R2852     3.0241009593009949e-01
    z[9,8,4]  R2853     1.7804567515850067e-01
    z[9,8,4]  R2854     9.8191395401954651e-02
    z[9,8,4]  R2855     -0.257386714220047
    z[9,8,4]  R2856     -4.1155639290809631e-01
    z[9,8,4]  R2857     -1.6819517314434052e-01
    z[9,8,5]  R79       1
    z[9,8,5]  R88       -1
    z[9,8,5]  R2754     -1
    z[9,8,5]  R2755     1
    z[9,8,5]  R2758     -2.7535766363143921e-01
    z[9,8,5]  R2759     -4.7670555114746094e-01
    z[9,8,5]  R2760     3.0889594927430153e-02
    z[9,8,5]  R2761     1.0734009742736816e-01
    z[9,8,5]  R2762     -2.5883340835571289e-01
    z[9,8,5]  R2763     1.1961440742015839e-01
    z[9,8,5]  R2764     3.0453236773610115e-02
    z[9,8,5]  R2765     -2.4219313263893127e-01
    z[9,8,5]  R2766     -3.7171486020088196e-01
    z[9,8,5]  R2767     -4.3663722276687622e-01
    z[9,8,5]  R2768     7.2335839271545410e-02
    z[9,8,5]  R2769     -1.1631545424461365e-01
    z[9,8,5]  R2770     -1.3624674081802368e-01
    z[9,8,5]  R2771     2.5760984420776367e-01
    z[9,8,5]  R2772     3.2423117756843567e-01
    z[9,8,5]  R2773     7.3119446635246277e-02
    z[9,8,5]  R2774     -6.3303269445896149e-02
    z[9,8,5]  R2775     1.8382611870765686e-01
    z[9,8,5]  R2776     2.8376647830009460e-01
    z[9,8,5]  R2777     1.5907536447048187e-01
    z[9,8,5]  R2778     -1.4546471834182739e-01
    z[9,8,5]  R2779     -2.4275135993957520e-01
    z[9,8,5]  R2780     6.1934083700180054e-01
    z[9,8,5]  R2781     2.7800858020782471e-01
    z[9,8,5]  R2782     5.0388675928115845e-01
    z[9,8,5]  R2783     -5.6846532970666885e-02
    z[9,8,5]  R2784     3.6254499107599258e-02
    z[9,8,5]  R2785     -3.7607285380363464e-01
    z[9,8,5]  R2786     5.0147105008363724e-02
    z[9,8,5]  R2787     -9.4526156783103943e-02
    z[9,8,5]  R2788     -2.3553647100925446e-02
    z[9,8,5]  R2789     3.8908076286315918e-01
    z[9,8,5]  R2790     -5.6547969579696655e-01
    z[9,8,5]  R2791     2.4374131858348846e-01
    z[9,8,5]  R2792     3.1710278242826462e-02
    z[9,8,5]  R2793     1.4875052869319916e-01
    z[9,8,5]  R2794     3.3772411942481995e-01
    z[9,8,5]  R2795     1.4556702971458435e-01
    z[9,8,5]  R2796     6.0349458456039429e-01
    z[9,8,5]  R2797     -2.3410108685493469e-01
    z[9,8,5]  R2798     2.3875202238559723e-01
    z[9,8,5]  R2799     0.532198429107666
    z[9,8,5]  R2800     -8.8648170232772827e-02
    z[9,8,5]  R2801     -1.3305827043950558e-02
    z[9,8,5]  R2802     -3.9736879989504814e-03
    z[9,8,5]  R2803     0.3140889108181
    z[9,8,5]  R2804     -4.4955092668533325e-01
    z[9,8,5]  R2805     -5.2958631515502930e-01
    z[9,8,5]  R2806     -4.5618087053298950e-01
    z[9,8,5]  R2807     -2.2290091216564178e-01
    z[9,8,5]  R2808     -2.2283443808555603e-01
    z[9,8,5]  R2809     -4.2021080851554871e-01
    z[9,8,5]  R2810     -2.4339118599891663e-01
    z[9,8,5]  R2811     1.6859647631645203e-01
    z[9,8,5]  R2812     -8.5380002856254578e-02
    z[9,8,5]  R2813     -2.5385084748268127e-01
    z[9,8,5]  R2814     1.5152811072766781e-02
    z[9,8,5]  R2815     0.334398090839386
    z[9,8,5]  R2816     5.7299923151731491e-02
    z[9,8,5]  R2817     1.1835353076457977e-01
    z[9,8,5]  R2818     -1.6442918777465820e-01
    z[9,8,5]  R2819     -1.0862501710653305e-01
    z[9,8,5]  R2820     4.9955964088439941e-02
    z[9,8,5]  R2821     -1.2794810533523560e-01
    z[9,8,5]  R2822     -2.8526043891906738e-01
    z[9,8,5]  R2823     -3.8474711775779724e-01
    z[9,8,5]  R2824     1.3758680224418640e-01
    z[9,8,5]  R2825     2.8761990368366241e-02
    z[9,8,5]  R2826     2.3101963102817535e-01
    z[9,8,5]  R2827     1.3659349083900452e-01
    z[9,8,5]  R2828     -5.3563795983791351e-02
    z[9,8,5]  R2829     -1.1258027702569962e-01
    z[9,8,5]  R2830     -3.9664259552955627e-01
    z[9,8,5]  R2831     -3.5026380419731140e-01
    z[9,8,5]  R2832     2.3329722881317139e-01
    z[9,8,5]  R2833     -1.4275322854518890e-01
    z[9,8,5]  R2834     -3.8245955109596252e-01
    z[9,8,5]  R2835     6.7891335487365723e-01
    z[9,8,5]  R2836     0.228000208735466
    z[9,8,5]  R2837     2.6723757386207581e-01
    z[9,8,5]  R2838     2.5089517235755920e-01
    z[9,8,5]  R2839     -5.5038008838891983e-02
    z[9,8,5]  R2840     -1.2910473346710205e-01
    z[9,8,5]  R2841     -2.3100826144218445e-01
    z[9,8,5]  R2842     2.5525811314582825e-01
    z[9,8,5]  R2843     3.9080002903938293e-01
    z[9,8,5]  R2844     -5.7665330171585083e-01
    z[9,8,5]  R2845     1.8812340497970581e-01
    z[9,8,5]  R2846     -0.451568603515625
    z[9,8,5]  R2847     4.5929422974586487e-01
    z[9,8,5]  R2848     2.4407865107059479e-01
    z[9,8,5]  R2849     -6.4954203367233276e-01
    z[9,8,5]  R2850     -2.0454682409763336e-02
    z[9,8,5]  R2851     -1.6836887598037720e-01
    z[9,8,5]  R2852     -2.3943383991718292e-01
    z[9,8,5]  R2853     -2.2156395018100739e-01
    z[9,8,5]  R2854     1.6375060379505157e-01
    z[9,8,5]  R2855     5.4560887813568115e-01
    z[9,8,5]  R2856     2.3006257414817810e-01
    z[9,8,5]  R2857     8.1063613295555115e-02
    z[9,8,6]  R80       1
    z[9,8,6]  R89       -1
    z[9,8,6]  R2756     -1
    z[9,8,6]  R2757     1
    z[9,8,6]  R2758     -0.289164662361145
    z[9,8,6]  R2759     2.4522738531231880e-02
    z[9,8,6]  R2760     2.5590965151786804e-01
    z[9,8,6]  R2761     -3.7311750650405884e-01
    z[9,8,6]  R2762     -2.2620756924152374e-01
    z[9,8,6]  R2763     -1.4772605895996094e-01
    z[9,8,6]  R2764     0.128773495554924
    z[9,8,6]  R2765     -4.7608497738838196e-01
    z[9,8,6]  R2766     -6.4299941062927246e-01
    z[9,8,6]  R2767     -1.4596696197986603e-01
    z[9,8,6]  R2768     8.9961051940917969e-02
    z[9,8,6]  R2769     -8.0054707825183868e-02
    z[9,8,6]  R2770     -3.9782442152500153e-02
    z[9,8,6]  R2771     -6.8114414811134338e-02
    z[9,8,6]  R2772     4.4111007452011108e-01
    z[9,8,6]  R2773     -3.1494843959808350e-01
    z[9,8,6]  R2774     3.0385980010032654e-01
    z[9,8,6]  R2775     2.3639582097530365e-01
    z[9,8,6]  R2776     4.2337965965270996e-01
    z[9,8,6]  R2777     -4.6211636066436768e-01
    z[9,8,6]  R2778     2.7650898694992065e-01
    z[9,8,6]  R2779     1.2029550969600677e-01
    z[9,8,6]  R2780     -0.367557555437088
    z[9,8,6]  R2781     -6.6486102342605591e-01
    z[9,8,6]  R2782     2.4418263137340546e-01
    z[9,8,6]  R2783     -3.9550852775573730e-01
    z[9,8,6]  R2784     6.5928483009338379e-01
    z[9,8,6]  R2785     4.3085891008377075e-01
    z[9,8,6]  R2786     3.9106476306915283e-01
    z[9,8,6]  R2787     -3.1564164161682129e-01
    z[9,8,6]  R2788     3.4440398216247559e-01
    z[9,8,6]  R2789     2.4238672852516174e-01
    z[9,8,6]  R2790     8.0896958708763123e-02
    z[9,8,6]  R2791     1.1481685936450958e-01
    z[9,8,6]  R2792     9.6243396401405334e-02
    z[9,8,6]  R2793     -2.6154699921607971e-01
    z[9,8,6]  R2794     -2.4617652595043182e-01
    z[9,8,6]  R2795     3.5888656973838806e-01
    z[9,8,6]  R2796     -1.4568477869033813e-01
    z[9,8,6]  R2797     -8.4414698183536530e-02
    z[9,8,6]  R2798     7.7482990920543671e-02
    z[9,8,6]  R2799     1.1786509305238724e-01
    z[9,8,6]  R2800     -2.7869653701782227e-01
    z[9,8,6]  R2801     -4.2002275586128235e-01
    z[9,8,6]  R2802     -9.0852063149213791e-03
    z[9,8,6]  R2803     1.5262927114963531e-01
    z[9,8,6]  R2804     -1.0978161543607712e-01
    z[9,8,6]  R2805     2.3072727024555206e-01
    z[9,8,6]  R2806     -5.3429072722792625e-03
    z[9,8,6]  R2807     -3.3589568734169006e-01
    z[9,8,6]  R2808     -8.8847614824771881e-02
    z[9,8,6]  R2809     -3.5660311579704285e-01
    z[9,8,6]  R2810     -4.1534259915351868e-01
    z[9,8,6]  R2811     -2.6995116472244263e-01
    z[9,8,6]  R2812     -2.3203879594802856e-01
    z[9,8,6]  R2813     3.6412918567657471e-01
    z[9,8,6]  R2814     -4.2200666666030884e-01
    z[9,8,6]  R2815     -3.0473735928535461e-01
    z[9,8,6]  R2816     0.0794663280248642
    z[9,8,6]  R2817     -2.8393331170082092e-01
    z[9,8,6]  R2818     1.3920005876570940e-03
    z[9,8,6]  R2819     1.8540833890438080e-01
    z[9,8,6]  R2820     -2.5751054286956787e-01
    z[9,8,6]  R2821     3.5152930766344070e-02
    z[9,8,6]  R2822     1.1452741920948029e-01
    z[9,8,6]  R2823     7.9993076622486115e-02
    z[9,8,6]  R2824     9.3643620610237122e-02
    z[9,8,6]  R2825     2.6505556702613831e-01
    z[9,8,6]  R2826     1.8180431425571442e-01
    z[9,8,6]  R2827     9.1106317937374115e-02
    z[9,8,6]  R2828     4.5899960398674011e-01
    z[9,8,6]  R2829     3.2285347580909729e-01
    z[9,8,6]  R2830     4.3084564805030823e-01
    z[9,8,6]  R2831     9.2565260827541351e-02
    z[9,8,6]  R2832     1.7285913228988647e-01
    z[9,8,6]  R2833     3.6376565694808960e-02
    z[9,8,6]  R2834     -1.4245083928108215e-01
    z[9,8,6]  R2835     -7.5721487402915955e-02
    z[9,8,6]  R2836     2.4506205692887306e-02
    z[9,8,6]  R2837     2.8213104605674744e-01
    z[9,8,6]  R2838     -1.6030804812908173e-01
    z[9,8,6]  R2839     2.5406202673912048e-01
    z[9,8,6]  R2840     -2.9143482446670532e-01
    z[9,8,6]  R2841     -1.5985479950904846e-01
    z[9,8,6]  R2842     4.9594348669052124e-01
    z[9,8,6]  R2843     -4.8691403120756149e-02
    z[9,8,6]  R2844     -2.0474494993686676e-01
    z[9,8,6]  R2845     0.178403839468956
    z[9,8,6]  R2846     -2.4913826584815979e-01
    z[9,8,6]  R2847     1.3315147161483765e-01
    z[9,8,6]  R2848     -1.4845924079418182e-01
    z[9,8,6]  R2849     -2.6704590767621994e-02
    z[9,8,6]  R2850     -3.8042172789573669e-01
    z[9,8,6]  R2851     2.1605546772480011e-01
    z[9,8,6]  R2852     -1.5994818508625031e-01
    z[9,8,6]  R2853     -3.8616311550140381e-01
    z[9,8,6]  R2854     -1.2715712189674377e-01
    z[9,8,6]  R2855     -7.8070342540740967e-02
    z[9,8,6]  R2856     -0.329046368598938
    z[9,8,6]  R2857     3.5990753769874573e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    length[8]  OBJ       1
    length[9]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
    delta[8,0]  R74       1
    delta[8,1]  R75       1
    delta[8,2]  R76       1
    delta[8,3]  R77       1
    delta[8,4]  R78       1
    delta[8,5]  R79       1
    delta[8,6]  R80       1
    delta[9,0]  R83       1
    delta[9,1]  R84       1
    delta[9,2]  R85       1
    delta[9,3]  R86       1
    delta[9,4]  R87       1
    delta[9,5]  R88       1
    delta[9,6]  R89       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R73       1
    RHS1      R82       1
    RHS1      R90       1
    RHS1      R91       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[0,5]
 BV BND1      phi[5,0]
 BV BND1      phi[10,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,3]
 BV BND1      phi[3,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[2,7]
 BV BND1      phi[7,2]
 BV BND1      phi[3,8]
 BV BND1      phi[8,3]
 BV BND1      phi[3,9]
 BV BND1      phi[9,3]
 BV BND1      phi[3,11]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[10,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[7,8]
 BV BND1      phi[8,7]
 BV BND1      phi[8,9]
 BV BND1      phi[9,8]
 BV BND1      phi[9,11]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[0,5,0]
 FR BND1      z[0,5,1]
 FR BND1      z[0,5,2]
 FR BND1      z[0,5,3]
 FR BND1      z[0,5,4]
 FR BND1      z[0,5,5]
 FR BND1      z[0,5,6]
 FR BND1      z[5,0,0]
 FR BND1      z[5,0,1]
 FR BND1      z[5,0,2]
 FR BND1      z[5,0,3]
 FR BND1      z[5,0,4]
 FR BND1      z[5,0,5]
 FR BND1      z[5,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,3,0]
 FR BND1      z[1,3,1]
 FR BND1      z[1,3,2]
 FR BND1      z[1,3,3]
 FR BND1      z[1,3,4]
 FR BND1      z[1,3,5]
 FR BND1      z[1,3,6]
 FR BND1      z[3,1,0]
 FR BND1      z[3,1,1]
 FR BND1      z[3,1,2]
 FR BND1      z[3,1,3]
 FR BND1      z[3,1,4]
 FR BND1      z[3,1,5]
 FR BND1      z[3,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[2,7,0]
 FR BND1      z[2,7,1]
 FR BND1      z[2,7,2]
 FR BND1      z[2,7,3]
 FR BND1      z[2,7,4]
 FR BND1      z[2,7,5]
 FR BND1      z[2,7,6]
 FR BND1      z[7,2,0]
 FR BND1      z[7,2,1]
 FR BND1      z[7,2,2]
 FR BND1      z[7,2,3]
 FR BND1      z[7,2,4]
 FR BND1      z[7,2,5]
 FR BND1      z[7,2,6]
 FR BND1      z[3,8,0]
 FR BND1      z[3,8,1]
 FR BND1      z[3,8,2]
 FR BND1      z[3,8,3]
 FR BND1      z[3,8,4]
 FR BND1      z[3,8,5]
 FR BND1      z[3,8,6]
 FR BND1      z[8,3,0]
 FR BND1      z[8,3,1]
 FR BND1      z[8,3,2]
 FR BND1      z[8,3,3]
 FR BND1      z[8,3,4]
 FR BND1      z[8,3,5]
 FR BND1      z[8,3,6]
 FR BND1      z[3,9,0]
 FR BND1      z[3,9,1]
 FR BND1      z[3,9,2]
 FR BND1      z[3,9,3]
 FR BND1      z[3,9,4]
 FR BND1      z[3,9,5]
 FR BND1      z[3,9,6]
 FR BND1      z[9,3,0]
 FR BND1      z[9,3,1]
 FR BND1      z[9,3,2]
 FR BND1      z[9,3,3]
 FR BND1      z[9,3,4]
 FR BND1      z[9,3,5]
 FR BND1      z[9,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      z[7,8,0]
 FR BND1      z[7,8,1]
 FR BND1      z[7,8,2]
 FR BND1      z[7,8,3]
 FR BND1      z[7,8,4]
 FR BND1      z[7,8,5]
 FR BND1      z[7,8,6]
 FR BND1      z[8,7,0]
 FR BND1      z[8,7,1]
 FR BND1      z[8,7,2]
 FR BND1      z[8,7,3]
 FR BND1      z[8,7,4]
 FR BND1      z[8,7,5]
 FR BND1      z[8,7,6]
 FR BND1      z[8,9,0]
 FR BND1      z[8,9,1]
 FR BND1      z[8,9,2]
 FR BND1      z[8,9,3]
 FR BND1      z[8,9,4]
 FR BND1      z[8,9,5]
 FR BND1      z[8,9,6]
 FR BND1      z[9,8,0]
 FR BND1      z[9,8,1]
 FR BND1      z[9,8,2]
 FR BND1      z[9,8,3]
 FR BND1      z[9,8,4]
 FR BND1      z[9,8,5]
 FR BND1      z[9,8,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
 FR BND1      delta[8,0]
 FR BND1      delta[8,1]
 FR BND1      delta[8,2]
 FR BND1      delta[8,3]
 FR BND1      delta[8,4]
 FR BND1      delta[8,5]
 FR BND1      delta[8,6]
 FR BND1      delta[9,0]
 FR BND1      delta[9,1]
 FR BND1      delta[9,2]
 FR BND1      delta[9,3]
 FR BND1      delta[9,4]
 FR BND1      delta[9,5]
 FR BND1      delta[9,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
QCMATRIX   qc8     
    length[8]  length[8]  -1
    delta[8,0]  delta[8,0]  1
    delta[8,1]  delta[8,1]  1
    delta[8,2]  delta[8,2]  1
    delta[8,3]  delta[8,3]  1
    delta[8,4]  delta[8,4]  1
    delta[8,5]  delta[8,5]  1
    delta[8,6]  delta[8,6]  1
QCMATRIX   qc9     
    length[9]  length[9]  -1
    delta[9,0]  delta[9,0]  1
    delta[9,1]  delta[9,1]  1
    delta[9,2]  delta[9,2]  1
    delta[9,3]  delta[9,3]  1
    delta[9,4]  delta[9,4]  1
    delta[9,5]  delta[9,5]  1
    delta[9,6]  delta[9,6]  1
ENDATA
