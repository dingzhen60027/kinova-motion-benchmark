NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 L  R73     
 E  R74     
 E  R75     
 E  R76     
 E  R77     
 E  R78     
 E  R79     
 E  R80     
 E  R81     
 L  R82     
 E  R83     
 E  R84     
 E  R85     
 E  R86     
 E  R87     
 E  R88     
 E  R89     
 E  R90     
 E  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
 L  qc8     
 L  qc9     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R92       -3.0999999046325684e+00
    phi[0,1]  R93       -3.0999999046325684e+00
    phi[0,1]  R94       -2.2400000095367432e+00
    phi[0,1]  R95       -2.2400000095367432e+00
    phi[0,1]  R96       -3.0999999046325684e+00
    phi[0,1]  R97       -3.0999999046325684e+00
    phi[0,1]  R98       -2.5699999332427979e+00
    phi[0,1]  R99       -2.5699999332427979e+00
    phi[0,1]  R100      -3.0999999046325684e+00
    phi[0,1]  R101      -3.0999999046325684e+00
    phi[0,1]  R102      -2.0899999141693115e+00
    phi[0,1]  R103      -2.0899999141693115e+00
    phi[0,1]  R104      -3.0999999046325684e+00
    phi[0,1]  R105      -3.0999999046325684e+00
    phi[0,1]  R106      1.9033046960830688e+00
    phi[0,1]  R107      1.4548109769821167e+00
    phi[0,1]  R108      8.3560341596603394e-01
    phi[0,1]  R109      1.8546886444091797e+00
    phi[0,1]  R110      -2.3408320546150208e-01
    phi[0,1]  R111      1.2651536464691162e+00
    phi[0,1]  R112      1.4013719558715820e-01
    phi[0,1]  R113      -8.9904159307479858e-01
    phi[0,1]  R114      3.9833462238311768e-01
    phi[0,1]  R115      8.2459098100662231e-01
    phi[0,1]  R116      -1.6912150382995605e+00
    phi[0,1]  R117      -1.6698158979415894e+00
    phi[0,1]  R118      -2.3897404968738556e-01
    phi[0,1]  R119      -1.0291640758514404e+00
    phi[0,1]  R120      -1.8030766248703003e+00
    phi[0,1]  R121      -1.7209169864654541e+00
    phi[0,1]  R122      -7.3829573392868042e-01
    phi[0,1]  R123      -7.9642450809478760e-01
    phi[0,1]  R124      -9.4345831871032715e-01
    phi[0,1]  R125      -1.4872291088104248e+00
    phi[0,1]  R126      -7.6452058553695679e-01
    phi[0,1]  R127      -2.5872340798377991e-01
    phi[0,1]  R128      4.1274213790893555e-01
    phi[0,1]  R129      -9.2371547222137451e-01
    phi[0,1]  R130      -1.7595784664154053e+00
    phi[0,1]  R131      -1.7720032930374146e+00
    phi[0,1]  R132      -2.8588857650756836e+00
    phi[0,1]  R133      -2.2926146984100342e+00
    phi[0,1]  R134      -1.7651401758193970e+00
    phi[0,1]  R135      -2.3026256561279297e+00
    phi[0,1]  R136      1.9058945775032043e-01
    phi[0,1]  R137      4.8903301358222961e-01
    phi[0,1]  R138      -0.795713484287262
    phi[0,1]  R139      1.6593933105468750e-01
    phi[0,1]  R140      -1.2644197940826416e+00
    phi[0,1]  R141      -0.456186443567276
    phi[0,1]  R142      -1.3580697774887085e+00
    phi[0,1]  R143      -9.5558124780654907e-01
    phi[0,1]  R144      3.9044272154569626e-02
    phi[0,1]  R145      -0.0509040504693985
    phi[0,1]  R146      -7.3835188150405884e-01
    phi[0,1]  R147      -1.3567718267440796e+00
    phi[0,1]  R148      -1.1599880456924438e+00
    phi[0,1]  R149      4.7649955749511719e-01
    phi[0,1]  R150      -1.2779865264892578e+00
    phi[0,1]  R151      -3.4315392374992371e-01
    phi[0,1]  R152      -2.7055428028106689e+00
    phi[0,1]  R153      -2.1489152908325195e+00
    phi[0,1]  R154      -2.4154279232025146e+00
    phi[0,1]  R155      -2.1296317577362061e+00
    phi[0,1]  R156      1.1319623142480850e-01
    phi[0,1]  R157      4.5273500680923462e-01
    phi[0,1]  R158      -6.2290906906127930e-01
    phi[0,1]  R159      -2.3396170139312744e+00
    phi[0,1]  R160      -2.0414905548095703e+00
    phi[0,1]  R161      -1.77381432056427
    phi[0,1]  R162      -2.3263442516326904e+00
    phi[0,1]  R163      -2.5793282985687256e+00
    phi[0,1]  R164      -2.0328917503356934e+00
    phi[0,1]  R165      -2.3577213287353516e+00
    phi[0,1]  R166      2.8255476951599121e+00
    phi[0,1]  R167      1.6376597881317139e+00
    phi[0,1]  R168      1.8143465518951416e+00
    phi[0,1]  R169      2.4132685661315918e+00
    phi[0,1]  R170      -7.1099773049354553e-03
    phi[0,1]  R171      1.6474001407623291e+00
    phi[0,1]  R172      2.2077915668487549e+00
    phi[0,1]  R173      1.2585031986236572e+00
    phi[0,1]  R174      -7.2309367358684540e-02
    phi[0,1]  R175      1.0739465951919556e+00
    phi[0,1]  R176      -2.0979249477386475e+00
    phi[0,1]  R177      -3.1385366916656494e+00
    phi[0,1]  R178      -1.9412380456924438e+00
    phi[0,1]  R179      -7.4871027469635010e-01
    phi[0,1]  R180      -1.4233150482177734e+00
    phi[0,1]  R181      -1.5494239330291748e+00
    phi[0,1]  R182      -1.0974055528640747e+00
    phi[0,1]  R183      -2.2212355136871338e+00
    phi[0,1]  R184      -1.8337839841842651e-01
    phi[0,1]  R185      -2.7482404708862305e+00
    phi[0,1]  R186      9.2860013246536255e-02
    phi[0,1]  R187      -4.3843439221382141e-01
    phi[0,1]  R188      1.0260148048400879e+00
    phi[0,1]  R189      0.585195779800415
    phi[0,1]  R190      -1.2960445880889893e+00
    phi[0,1]  R191      -1.3854575157165527e+00
    phi[0,1]  R192      -2.6658253669738770e+00
    phi[0,1]  R193      -3.5919804573059082e+00
    phi[0,1]  R194      -3.8461086750030518e+00
    phi[0,1]  R195      -3.9638943672180176e+00
    phi[0,1]  R196      -1.2134146690368652e+00
    phi[0,1]  R197      -2.2867355346679688e+00
    phi[0,1]  R198      -1.8318042755126953e+00
    phi[0,1]  R199      -2.0809781551361084e+00
    phi[0,1]  R200      -3.8119897842407227e+00
    phi[0,1]  R201      -1.9319554567337036e+00
    phi[0,1]  R202      -2.7798180580139160e+00
    phi[0,1]  R203      -1.0887020826339722e+00
    phi[0,1]  R204      -3.9325242042541504e+00
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R205      -3.0999999046325684e+00
    phi[1,0]  R206      -3.0999999046325684e+00
    phi[1,0]  R207      -2.2400000095367432e+00
    phi[1,0]  R208      -2.2400000095367432e+00
    phi[1,0]  R209      -3.0999999046325684e+00
    phi[1,0]  R210      -3.0999999046325684e+00
    phi[1,0]  R211      -2.5699999332427979e+00
    phi[1,0]  R212      -2.5699999332427979e+00
    phi[1,0]  R213      -3.0999999046325684e+00
    phi[1,0]  R214      -3.0999999046325684e+00
    phi[1,0]  R215      -2.0899999141693115e+00
    phi[1,0]  R216      -2.0899999141693115e+00
    phi[1,0]  R217      -3.0999999046325684e+00
    phi[1,0]  R218      -3.0999999046325684e+00
    phi[1,0]  R219      2.8255476951599121e+00
    phi[1,0]  R220      1.6376597881317139e+00
    phi[1,0]  R221      1.8143465518951416e+00
    phi[1,0]  R222      2.4132685661315918e+00
    phi[1,0]  R223      -7.1099773049354553e-03
    phi[1,0]  R224      1.6474001407623291e+00
    phi[1,0]  R225      2.2077915668487549e+00
    phi[1,0]  R226      1.2585031986236572e+00
    phi[1,0]  R227      -7.2309367358684540e-02
    phi[1,0]  R228      1.0739465951919556e+00
    phi[1,0]  R229      -2.0979249477386475e+00
    phi[1,0]  R230      -3.1385366916656494e+00
    phi[1,0]  R231      -1.9412380456924438e+00
    phi[1,0]  R232      -7.4871027469635010e-01
    phi[1,0]  R233      -1.4233150482177734e+00
    phi[1,0]  R234      -1.5494239330291748e+00
    phi[1,0]  R235      -1.0974055528640747e+00
    phi[1,0]  R236      -2.2212355136871338e+00
    phi[1,0]  R237      -1.8337839841842651e-01
    phi[1,0]  R238      -2.7482404708862305e+00
    phi[1,0]  R239      9.2860013246536255e-02
    phi[1,0]  R240      -4.3843439221382141e-01
    phi[1,0]  R241      1.0260148048400879e+00
    phi[1,0]  R242      0.585195779800415
    phi[1,0]  R243      -1.2960445880889893e+00
    phi[1,0]  R244      -1.3854575157165527e+00
    phi[1,0]  R245      -2.6658253669738770e+00
    phi[1,0]  R246      -3.5919804573059082e+00
    phi[1,0]  R247      -3.8461086750030518e+00
    phi[1,0]  R248      -3.9638943672180176e+00
    phi[1,0]  R249      -1.2134146690368652e+00
    phi[1,0]  R250      -2.2867355346679688e+00
    phi[1,0]  R251      -1.8318042755126953e+00
    phi[1,0]  R252      -2.0809781551361084e+00
    phi[1,0]  R253      -3.8119897842407227e+00
    phi[1,0]  R254      -1.9319554567337036e+00
    phi[1,0]  R255      -2.7798180580139160e+00
    phi[1,0]  R256      -1.0887020826339722e+00
    phi[1,0]  R257      -3.9325242042541504e+00
    phi[1,0]  R258      1.9033046960830688e+00
    phi[1,0]  R259      1.4548109769821167e+00
    phi[1,0]  R260      8.3560341596603394e-01
    phi[1,0]  R261      1.8546886444091797e+00
    phi[1,0]  R262      -2.3408320546150208e-01
    phi[1,0]  R263      1.2651536464691162e+00
    phi[1,0]  R264      1.4013719558715820e-01
    phi[1,0]  R265      -8.9904159307479858e-01
    phi[1,0]  R266      3.9833462238311768e-01
    phi[1,0]  R267      8.2459098100662231e-01
    phi[1,0]  R268      -1.6912150382995605e+00
    phi[1,0]  R269      -1.6698158979415894e+00
    phi[1,0]  R270      -2.3897404968738556e-01
    phi[1,0]  R271      -1.0291640758514404e+00
    phi[1,0]  R272      -1.8030766248703003e+00
    phi[1,0]  R273      -1.7209169864654541e+00
    phi[1,0]  R274      -7.3829573392868042e-01
    phi[1,0]  R275      -7.9642450809478760e-01
    phi[1,0]  R276      -9.4345831871032715e-01
    phi[1,0]  R277      -1.4872291088104248e+00
    phi[1,0]  R278      -7.6452058553695679e-01
    phi[1,0]  R279      -2.5872340798377991e-01
    phi[1,0]  R280      4.1274213790893555e-01
    phi[1,0]  R281      -9.2371547222137451e-01
    phi[1,0]  R282      -1.7595784664154053e+00
    phi[1,0]  R283      -1.7720032930374146e+00
    phi[1,0]  R284      -2.8588857650756836e+00
    phi[1,0]  R285      -2.2926146984100342e+00
    phi[1,0]  R286      -1.7651401758193970e+00
    phi[1,0]  R287      -2.3026256561279297e+00
    phi[1,0]  R288      1.9058945775032043e-01
    phi[1,0]  R289      4.8903301358222961e-01
    phi[1,0]  R290      -0.795713484287262
    phi[1,0]  R291      1.6593933105468750e-01
    phi[1,0]  R292      -1.2644197940826416e+00
    phi[1,0]  R293      -0.456186443567276
    phi[1,0]  R294      -1.3580697774887085e+00
    phi[1,0]  R295      -9.5558124780654907e-01
    phi[1,0]  R296      3.9044272154569626e-02
    phi[1,0]  R297      -0.0509040504693985
    phi[1,0]  R298      -7.3835188150405884e-01
    phi[1,0]  R299      -1.3567718267440796e+00
    phi[1,0]  R300      -1.1599880456924438e+00
    phi[1,0]  R301      4.7649955749511719e-01
    phi[1,0]  R302      -1.2779865264892578e+00
    phi[1,0]  R303      -3.4315392374992371e-01
    phi[1,0]  R304      -2.7055428028106689e+00
    phi[1,0]  R305      -2.1489152908325195e+00
    phi[1,0]  R306      -2.4154279232025146e+00
    phi[1,0]  R307      -2.1296317577362061e+00
    phi[1,0]  R308      1.1319623142480850e-01
    phi[1,0]  R309      4.5273500680923462e-01
    phi[1,0]  R310      -6.2290906906127930e-01
    phi[1,0]  R311      -2.3396170139312744e+00
    phi[1,0]  R312      -2.0414905548095703e+00
    phi[1,0]  R313      -1.77381432056427
    phi[1,0]  R314      -2.3263442516326904e+00
    phi[1,0]  R315      -2.5793282985687256e+00
    phi[1,0]  R316      -2.0328917503356934e+00
    phi[1,0]  R317      -2.3577213287353516e+00
    phi[0,6]  R0        1
    phi[0,6]  R1        1
    phi[0,6]  R54       -1
    phi[0,6]  R318      -3.0999999046325684e+00
    phi[0,6]  R319      -3.0999999046325684e+00
    phi[0,6]  R320      -2.2400000095367432e+00
    phi[0,6]  R321      -2.2400000095367432e+00
    phi[0,6]  R322      -3.0999999046325684e+00
    phi[0,6]  R323      -3.0999999046325684e+00
    phi[0,6]  R324      -2.5699999332427979e+00
    phi[0,6]  R325      -2.5699999332427979e+00
    phi[0,6]  R326      -3.0999999046325684e+00
    phi[0,6]  R327      -3.0999999046325684e+00
    phi[0,6]  R328      -2.0899999141693115e+00
    phi[0,6]  R329      -2.0899999141693115e+00
    phi[0,6]  R330      -3.0999999046325684e+00
    phi[0,6]  R331      -3.0999999046325684e+00
    phi[0,6]  R332      1.9033046960830688e+00
    phi[0,6]  R333      1.4548109769821167e+00
    phi[0,6]  R334      8.3560341596603394e-01
    phi[0,6]  R335      1.8546886444091797e+00
    phi[0,6]  R336      -2.3408320546150208e-01
    phi[0,6]  R337      1.2651536464691162e+00
    phi[0,6]  R338      1.4013719558715820e-01
    phi[0,6]  R339      -8.9904159307479858e-01
    phi[0,6]  R340      3.9833462238311768e-01
    phi[0,6]  R341      8.2459098100662231e-01
    phi[0,6]  R342      -1.6912150382995605e+00
    phi[0,6]  R343      -1.6698158979415894e+00
    phi[0,6]  R344      -2.3897404968738556e-01
    phi[0,6]  R345      -1.0291640758514404e+00
    phi[0,6]  R346      -1.8030766248703003e+00
    phi[0,6]  R347      -1.7209169864654541e+00
    phi[0,6]  R348      -7.3829573392868042e-01
    phi[0,6]  R349      -7.9642450809478760e-01
    phi[0,6]  R350      -9.4345831871032715e-01
    phi[0,6]  R351      -1.4872291088104248e+00
    phi[0,6]  R352      -7.6452058553695679e-01
    phi[0,6]  R353      -2.5872340798377991e-01
    phi[0,6]  R354      4.1274213790893555e-01
    phi[0,6]  R355      -9.2371547222137451e-01
    phi[0,6]  R356      -1.7595784664154053e+00
    phi[0,6]  R357      -1.7720032930374146e+00
    phi[0,6]  R358      -2.8588857650756836e+00
    phi[0,6]  R359      -2.2926146984100342e+00
    phi[0,6]  R360      -1.7651401758193970e+00
    phi[0,6]  R361      -2.3026256561279297e+00
    phi[0,6]  R362      1.9058945775032043e-01
    phi[0,6]  R363      4.8903301358222961e-01
    phi[0,6]  R364      -0.795713484287262
    phi[0,6]  R365      1.6593933105468750e-01
    phi[0,6]  R366      -1.2644197940826416e+00
    phi[0,6]  R367      -0.456186443567276
    phi[0,6]  R368      -1.3580697774887085e+00
    phi[0,6]  R369      -9.5558124780654907e-01
    phi[0,6]  R370      3.9044272154569626e-02
    phi[0,6]  R371      -0.0509040504693985
    phi[0,6]  R372      -7.3835188150405884e-01
    phi[0,6]  R373      -1.3567718267440796e+00
    phi[0,6]  R374      -1.1599880456924438e+00
    phi[0,6]  R375      4.7649955749511719e-01
    phi[0,6]  R376      -1.2779865264892578e+00
    phi[0,6]  R377      -3.4315392374992371e-01
    phi[0,6]  R378      -2.7055428028106689e+00
    phi[0,6]  R379      -2.1489152908325195e+00
    phi[0,6]  R380      -2.4154279232025146e+00
    phi[0,6]  R381      -2.1296317577362061e+00
    phi[0,6]  R382      1.1319623142480850e-01
    phi[0,6]  R383      4.5273500680923462e-01
    phi[0,6]  R384      -6.2290906906127930e-01
    phi[0,6]  R385      -2.3396170139312744e+00
    phi[0,6]  R386      -2.0414905548095703e+00
    phi[0,6]  R387      -1.77381432056427
    phi[0,6]  R388      -2.3263442516326904e+00
    phi[0,6]  R389      -2.5793282985687256e+00
    phi[0,6]  R390      -2.0328917503356934e+00
    phi[0,6]  R391      -2.3577213287353516e+00
    phi[0,6]  R392      3.7983101606369019e-01
    phi[0,6]  R393      -3.0747294425964355e-01
    phi[0,6]  R394      6.5695822238922119e-01
    phi[0,6]  R395      1.1710835695266724e+00
    phi[0,6]  R396      -1.1038111448287964e+00
    phi[0,6]  R397      -1.1836371421813965e+00
    phi[0,6]  R398      0.763956606388092
    phi[0,6]  R399      -9.4967238605022430e-02
    phi[0,6]  R400      -7.8172397613525391e-01
    phi[0,6]  R401      1.6476583480834961e-01
    phi[0,6]  R402      -1.1412296295166016e+00
    phi[0,6]  R403      -1.0948590040206909e+00
    phi[0,6]  R404      -1.3350919485092163e+00
    phi[0,6]  R405      -1.3391478061676025e+00
    phi[0,6]  R406      -1.3376376628875732e+00
    phi[0,6]  R407      -9.2074757814407349e-01
    phi[0,6]  R408      -1.0352207422256470e+00
    phi[0,6]  R409      -2.4766404926776886e-01
    phi[0,6]  R410      -1.4737188816070557e+00
    phi[0,6]  R411      -1.4579967260360718e+00
    phi[0,6]  R412      -5.6584900617599487e-01
    phi[0,6]  R413      7.6322577893733978e-02
    phi[0,6]  R414      2.2841393947601318e-01
    phi[0,6]  R415      -3.4058177471160889e-01
    phi[0,6]  R416      -9.9476790428161621e-01
    phi[0,6]  R417      1.6030801832675934e-01
    phi[0,6]  R418      -2.8927816078066826e-02
    phi[0,6]  R419      -3.3171486854553223e-01
    phi[0,6]  R420      -1.1878687143325806e+00
    phi[0,6]  R421      -9.7641396522521973e-01
    phi[0,6]  R422      -5.2197760343551636e-01
    phi[0,6]  R423      -3.8505084812641144e-02
    phi[0,6]  R424      -6.9030916690826416e-01
    phi[0,6]  R425      2.0333202183246613e-01
    phi[0,6]  R426      9.5211789011955261e-02
    phi[0,6]  R427      -7.2704887390136719e-01
    phi[0,6]  R428      6.1675316095352173e-01
    phi[0,6]  R429      -1.7321071028709412e-01
    phi[0,6]  R430      -8.3599549531936646e-01
    phi[0,6]  R431      4.0012747049331665e-01
    phi[6,0]  R0        -1
    phi[6,0]  R54       1
    phi[6,0]  R55       1
    phi[6,0]  R432      -3.0999999046325684e+00
    phi[6,0]  R433      -3.0999999046325684e+00
    phi[6,0]  R434      -2.2400000095367432e+00
    phi[6,0]  R435      -2.2400000095367432e+00
    phi[6,0]  R436      -3.0999999046325684e+00
    phi[6,0]  R437      -3.0999999046325684e+00
    phi[6,0]  R438      -2.5699999332427979e+00
    phi[6,0]  R439      -2.5699999332427979e+00
    phi[6,0]  R440      -3.0999999046325684e+00
    phi[6,0]  R441      -3.0999999046325684e+00
    phi[6,0]  R442      -2.0899999141693115e+00
    phi[6,0]  R443      -2.0899999141693115e+00
    phi[6,0]  R444      -3.0999999046325684e+00
    phi[6,0]  R445      -3.0999999046325684e+00
    phi[6,0]  R446      3.7983101606369019e-01
    phi[6,0]  R447      -3.0747294425964355e-01
    phi[6,0]  R448      6.5695822238922119e-01
    phi[6,0]  R449      1.1710835695266724e+00
    phi[6,0]  R450      -1.1038111448287964e+00
    phi[6,0]  R451      -1.1836371421813965e+00
    phi[6,0]  R452      0.763956606388092
    phi[6,0]  R453      -9.4967238605022430e-02
    phi[6,0]  R454      -7.8172397613525391e-01
    phi[6,0]  R455      1.6476583480834961e-01
    phi[6,0]  R456      -1.1412296295166016e+00
    phi[6,0]  R457      -1.0948590040206909e+00
    phi[6,0]  R458      -1.3350919485092163e+00
    phi[6,0]  R459      -1.3391478061676025e+00
    phi[6,0]  R460      -1.3376376628875732e+00
    phi[6,0]  R461      -9.2074757814407349e-01
    phi[6,0]  R462      -1.0352207422256470e+00
    phi[6,0]  R463      -2.4766404926776886e-01
    phi[6,0]  R464      -1.4737188816070557e+00
    phi[6,0]  R465      -1.4579967260360718e+00
    phi[6,0]  R466      -5.6584900617599487e-01
    phi[6,0]  R467      7.6322577893733978e-02
    phi[6,0]  R468      2.2841393947601318e-01
    phi[6,0]  R469      -3.4058177471160889e-01
    phi[6,0]  R470      -9.9476790428161621e-01
    phi[6,0]  R471      1.6030801832675934e-01
    phi[6,0]  R472      -2.8927816078066826e-02
    phi[6,0]  R473      -3.3171486854553223e-01
    phi[6,0]  R474      -1.1878687143325806e+00
    phi[6,0]  R475      -9.7641396522521973e-01
    phi[6,0]  R476      -5.2197760343551636e-01
    phi[6,0]  R477      -3.8505084812641144e-02
    phi[6,0]  R478      -6.9030916690826416e-01
    phi[6,0]  R479      2.0333202183246613e-01
    phi[6,0]  R480      9.5211789011955261e-02
    phi[6,0]  R481      -7.2704887390136719e-01
    phi[6,0]  R482      6.1675316095352173e-01
    phi[6,0]  R483      -1.7321071028709412e-01
    phi[6,0]  R484      -8.3599549531936646e-01
    phi[6,0]  R485      4.0012747049331665e-01
    phi[6,0]  R486      1.9033046960830688e+00
    phi[6,0]  R487      1.4548109769821167e+00
    phi[6,0]  R488      8.3560341596603394e-01
    phi[6,0]  R489      1.8546886444091797e+00
    phi[6,0]  R490      -2.3408320546150208e-01
    phi[6,0]  R491      1.2651536464691162e+00
    phi[6,0]  R492      1.4013719558715820e-01
    phi[6,0]  R493      -8.9904159307479858e-01
    phi[6,0]  R494      3.9833462238311768e-01
    phi[6,0]  R495      8.2459098100662231e-01
    phi[6,0]  R496      -1.6912150382995605e+00
    phi[6,0]  R497      -1.6698158979415894e+00
    phi[6,0]  R498      -2.3897404968738556e-01
    phi[6,0]  R499      -1.0291640758514404e+00
    phi[6,0]  R500      -1.8030766248703003e+00
    phi[6,0]  R501      -1.7209169864654541e+00
    phi[6,0]  R502      -7.3829573392868042e-01
    phi[6,0]  R503      -7.9642450809478760e-01
    phi[6,0]  R504      -9.4345831871032715e-01
    phi[6,0]  R505      -1.4872291088104248e+00
    phi[6,0]  R506      -7.6452058553695679e-01
    phi[6,0]  R507      -2.5872340798377991e-01
    phi[6,0]  R508      4.1274213790893555e-01
    phi[6,0]  R509      -9.2371547222137451e-01
    phi[6,0]  R510      -1.7595784664154053e+00
    phi[6,0]  R511      -1.7720032930374146e+00
    phi[6,0]  R512      -2.8588857650756836e+00
    phi[6,0]  R513      -2.2926146984100342e+00
    phi[6,0]  R514      -1.7651401758193970e+00
    phi[6,0]  R515      -2.3026256561279297e+00
    phi[6,0]  R516      1.9058945775032043e-01
    phi[6,0]  R517      4.8903301358222961e-01
    phi[6,0]  R518      -0.795713484287262
    phi[6,0]  R519      1.6593933105468750e-01
    phi[6,0]  R520      -1.2644197940826416e+00
    phi[6,0]  R521      -0.456186443567276
    phi[6,0]  R522      -1.3580697774887085e+00
    phi[6,0]  R523      -9.5558124780654907e-01
    phi[6,0]  R524      3.9044272154569626e-02
    phi[6,0]  R525      -0.0509040504693985
    phi[6,0]  R526      -7.3835188150405884e-01
    phi[6,0]  R527      -1.3567718267440796e+00
    phi[6,0]  R528      -1.1599880456924438e+00
    phi[6,0]  R529      4.7649955749511719e-01
    phi[6,0]  R530      -1.2779865264892578e+00
    phi[6,0]  R531      -3.4315392374992371e-01
    phi[6,0]  R532      -2.7055428028106689e+00
    phi[6,0]  R533      -2.1489152908325195e+00
    phi[6,0]  R534      -2.4154279232025146e+00
    phi[6,0]  R535      -2.1296317577362061e+00
    phi[6,0]  R536      1.1319623142480850e-01
    phi[6,0]  R537      4.5273500680923462e-01
    phi[6,0]  R538      -6.2290906906127930e-01
    phi[6,0]  R539      -2.3396170139312744e+00
    phi[6,0]  R540      -2.0414905548095703e+00
    phi[6,0]  R541      -1.77381432056427
    phi[6,0]  R542      -2.3263442516326904e+00
    phi[6,0]  R543      -2.5793282985687256e+00
    phi[6,0]  R544      -2.0328917503356934e+00
    phi[6,0]  R545      -2.3577213287353516e+00
    phi[10,0]  R0        -1
    phi[10,0]  R2        -1.3662186085443053e+00
    phi[10,0]  R3        1.7399764913263560e-02
    phi[10,0]  R4        -6.4662269535883610e-01
    phi[10,0]  R5        -1.4391404286847327e+00
    phi[10,0]  R6        7.1012939330827551e-01
    phi[10,0]  R7        3.6219531726647070e-01
    phi[10,0]  R8        2.0850263072532003e+00
    phi[10,0]  R90       1
    phi[10,0]  R546      -1.7337812960882630e+00
    phi[10,0]  R547      -4.4662185131768739e+00
    phi[10,0]  R548      -2.2573997744500067e+00
    phi[10,0]  R549      -2.2226002446234796e+00
    phi[10,0]  R550      -2.4533772092737323e+00
    phi[10,0]  R551      -3.7466225999914045e+00
    phi[10,0]  R552      -1.1308595045580652e+00
    phi[10,0]  R553      -4.00914036192753
    phi[10,0]  R554      -3.8101292979408439e+00
    phi[10,0]  R555      -2.3898705113242928e+00
    phi[10,0]  R556      -2.4521952314357822e+00
    phi[10,0]  R557      -1.7278045969028408e+00
    phi[10,0]  R558      -5.1850262118857682e+00
    phi[10,0]  R559      -1.0149735973793681e+00
    phi[10,0]  R560      -1.8221772648974843e-01
    phi[10,0]  R561      -1.8884717019499631e-01
    phi[10,0]  R562      -1.8944334653476025e-01
    phi[10,0]  R563      -1.9350077113445563e-01
    phi[10,0]  R564      -2.1517234114517949e+00
    phi[10,0]  R565      -1.9758738376513030e-01
    phi[10,0]  R566      -1.9841675583172164e-01
    phi[10,0]  R567      -2.6708072198110258e+00
    phi[10,0]  R568      -2.2025671309094275e-01
    phi[10,0]  R569      -2.7856910556220882e-01
    phi[10,0]  R570      -3.7898369920378427e-01
    phi[10,0]  R571      -3.8078034705518982e-01
    phi[10,0]  R572      -3.8609450550235036e-01
    phi[10,0]  R573      -3.8826529497835183e-01
    phi[10,0]  R574      -3.8850368189099793e-01
    phi[10,0]  R575      -3.9518393100336757e-01
    phi[10,0]  R576      -4.0139035955267610e-01
    phi[10,0]  R577      -0.401541810740199
    phi[10,0]  R578      -4.0189097490687786e-01
    phi[10,0]  R579      -4.0284519336469238e-01
    phi[10,0]  R580      -0.519895488620165
    phi[10,0]  R581      -5.7701480227953017e-01
    phi[10,0]  R582      -5.8843189581903665e-01
    phi[10,0]  R583      -6.0531507740119539e-01
    phi[10,0]  R584      -6.1439172131927622e-01
    phi[10,0]  R585      -6.2482986533159113e-01
    phi[10,0]  R586      -6.3904447588481261e-01
    phi[10,0]  R587      -6.4053004618565468e-01
    phi[10,0]  R588      -6.4431459134267111e-01
    phi[10,0]  R589      -6.4622720026662828e-01
    phi[10,0]  R590      -4.3442258365207254e-01
    phi[10,0]  R591      -4.6021431584030792e-01
    phi[10,0]  R592      -4.7157772203037573e-01
    phi[10,0]  R593      -4.7923766023220526e-01
    phi[10,0]  R594      -4.8393714332664284e-01
    phi[10,0]  R595      -4.9139791365816188e-01
    phi[10,0]  R596      -0.519212911385149
    phi[10,0]  R597      -5.1975468619154885e-01
    phi[10,0]  R598      -0.525627352442348
    phi[10,0]  R599      -5.3553276415506135e-01
    phi[10,0]  R600      -4.2618784796964648e-01
    phi[10,0]  R601      -4.4450534182218027e-01
    phi[10,0]  R602      -4.6492704782583361e-01
    phi[10,0]  R603      -4.9416261598910705e-01
    phi[10,0]  R604      -4.9539317265029104e-01
    phi[10,0]  R605      -0.514728895685267
    phi[10,0]  R606      -5.5292096111948208e-01
    phi[10,0]  R607      -5.9547574346886312e-01
    phi[10,0]  R608      -6.2372375072900543e-01
    phi[10,0]  R609      -6.3238332570756306e-01
    phi[10,0]  R610      -4.1229751011778537e-01
    phi[10,0]  R611      -4.3270318389070672e-01
    phi[10,0]  R612      -4.9071884783110808e-01
    phi[10,0]  R613      -5.8747328009805422e-01
    phi[10,0]  R614      -6.0409372672235473e-01
    phi[10,0]  R615      -6.6836290228800133e-01
    phi[10,0]  R616      -6.8267710977372920e-01
    phi[10,0]  R617      -8.6404140727668977e-01
    phi[10,0]  R618      -8.7817844885995555e-01
    phi[10,0]  R619      -9.0301887168873818e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R620      -3.0999999046325684e+00
    phi[1,2]  R621      -3.0999999046325684e+00
    phi[1,2]  R622      -2.2400000095367432e+00
    phi[1,2]  R623      -2.2400000095367432e+00
    phi[1,2]  R624      -3.0999999046325684e+00
    phi[1,2]  R625      -3.0999999046325684e+00
    phi[1,2]  R626      -2.5699999332427979e+00
    phi[1,2]  R627      -2.5699999332427979e+00
    phi[1,2]  R628      -3.0999999046325684e+00
    phi[1,2]  R629      -3.0999999046325684e+00
    phi[1,2]  R630      -2.0899999141693115e+00
    phi[1,2]  R631      -2.0899999141693115e+00
    phi[1,2]  R632      -3.0999999046325684e+00
    phi[1,2]  R633      -3.0999999046325684e+00
    phi[1,2]  R634      2.8255476951599121e+00
    phi[1,2]  R635      1.6376597881317139e+00
    phi[1,2]  R636      1.8143465518951416e+00
    phi[1,2]  R637      2.4132685661315918e+00
    phi[1,2]  R638      -7.1099773049354553e-03
    phi[1,2]  R639      1.6474001407623291e+00
    phi[1,2]  R640      2.2077915668487549e+00
    phi[1,2]  R641      1.2585031986236572e+00
    phi[1,2]  R642      -7.2309367358684540e-02
    phi[1,2]  R643      1.0739465951919556e+00
    phi[1,2]  R644      -2.0979249477386475e+00
    phi[1,2]  R645      -3.1385366916656494e+00
    phi[1,2]  R646      -1.9412380456924438e+00
    phi[1,2]  R647      -7.4871027469635010e-01
    phi[1,2]  R648      -1.4233150482177734e+00
    phi[1,2]  R649      -1.5494239330291748e+00
    phi[1,2]  R650      -1.0974055528640747e+00
    phi[1,2]  R651      -2.2212355136871338e+00
    phi[1,2]  R652      -1.8337839841842651e-01
    phi[1,2]  R653      -2.7482404708862305e+00
    phi[1,2]  R654      9.2860013246536255e-02
    phi[1,2]  R655      -4.3843439221382141e-01
    phi[1,2]  R656      1.0260148048400879e+00
    phi[1,2]  R657      0.585195779800415
    phi[1,2]  R658      -1.2960445880889893e+00
    phi[1,2]  R659      -1.3854575157165527e+00
    phi[1,2]  R660      -2.6658253669738770e+00
    phi[1,2]  R661      -3.5919804573059082e+00
    phi[1,2]  R662      -3.8461086750030518e+00
    phi[1,2]  R663      -3.9638943672180176e+00
    phi[1,2]  R664      -1.2134146690368652e+00
    phi[1,2]  R665      -2.2867355346679688e+00
    phi[1,2]  R666      -1.8318042755126953e+00
    phi[1,2]  R667      -2.0809781551361084e+00
    phi[1,2]  R668      -3.8119897842407227e+00
    phi[1,2]  R669      -1.9319554567337036e+00
    phi[1,2]  R670      -2.7798180580139160e+00
    phi[1,2]  R671      -1.0887020826339722e+00
    phi[1,2]  R672      -3.9325242042541504e+00
    phi[1,2]  R673      2.4659178256988525e+00
    phi[1,2]  R674      3.3490865230560303e+00
    phi[1,2]  R675      2.4996743202209473e+00
    phi[1,2]  R676      2.5079476833343506e+00
    phi[1,2]  R677      1.29396653175354
    phi[1,2]  R678      2.78867506980896
    phi[1,2]  R679      1.9115095138549805e+00
    phi[1,2]  R680      2.0590593814849854e+00
    phi[1,2]  R681      2.8269140720367432e+00
    phi[1,2]  R682      -2.0077536106109619e+00
    phi[1,2]  R683      -2.0533299446105957e+00
    phi[1,2]  R684      -1.9196538925170898e+00
    phi[1,2]  R685      -1.9923603534698486e+00
    phi[1,2]  R686      -1.9211567640304565e+00
    phi[1,2]  R687      -1.8253394365310669e+00
    phi[1,2]  R688      -2.2157876491546631e+00
    phi[1,2]  R689      -1.5762580633163452e+00
    phi[1,2]  R690      -2.4873320758342743e-01
    phi[1,2]  R691      -2.8461503982543945e+00
    phi[1,2]  R692      -7.6862621307373047e-01
    phi[1,2]  R693      -6.4954203367233276e-01
    phi[1,2]  R694      -3.4282701015472412e+00
    phi[1,2]  R695      -3.9427180290222168e+00
    phi[1,2]  R696      -4.2678065299987793e+00
    phi[1,2]  R697      -3.0079858303070068e+00
    phi[1,2]  R698      -3.0631160736083984e+00
    phi[1,2]  R699      -1.46782648563385
    phi[1,2]  R700      -3.0336687564849854e+00
    phi[1,2]  R701      -3.8640193939208984e+00
    phi[1,2]  R702      -3.2943956851959229e+00
    phi[1,2]  R703      -1.1611177921295166e+00
    phi[1,2]  R704      -5.7986313104629517e-01
    phi[1,2]  R705      -1.9690148830413818e+00
    phi[1,2]  R706      -8.2362568378448486e-01
    phi[1,2]  R707      -6.1290186643600464e-01
    phi[1,2]  R708      -4.0394032001495361e-01
    phi[1,2]  R709      -1.3289914131164551e+00
    phi[1,2]  R710      -8.8191002607345581e-01
    phi[1,2]  R711      -1.0642046928405762e+00
    phi[1,2]  R712      -3.0060732364654541e+00
    phi[1,2]  R713      -1.0136628150939941e+00
    phi[1,2]  R714      -5.7547622919082642e-01
    phi[1,2]  R715      -2.0504245758056641e+00
    phi[1,2]  R716      -3.5017967224121094e+00
    phi[1,2]  R717      8.2845389842987061e-01
    phi[1,2]  R718      -3.8474166393280029e+00
    phi[1,2]  R719      -2.5357415676116943e+00
    phi[1,2]  R720      -4.0705734491348267e-01
    phi[1,2]  R721      -5.5479627847671509e-01
    phi[1,2]  R722      -1.3401981592178345e+00
    phi[1,2]  R723      2.2928394377231598e-01
    phi[1,2]  R724      -1.3102151155471802e+00
    phi[1,2]  R725      -2.6002879142761230e+00
    phi[1,2]  R726      -1.1289610862731934e+00
    phi[1,2]  R727      -4.5500600337982178e-01
    phi[1,2]  R728      1.2885019779205322e+00
    phi[1,2]  R729      1.6775111854076385e-01
    phi[1,2]  R730      -8.9445686340332031e-01
    phi[1,2]  R731      -0.572439968585968
    phi[1,2]  R732      -4.0689194202423096e-01
    phi[1,2]  R733      -5.3437036275863647e-01
    phi[1,2]  R734      -3.1713981628417969e+00
    phi[1,2]  R735      -1.8277709484100342e+00
    phi[1,2]  R736      -2.3546919822692871e+00
    phi[1,2]  R737      0.659534215927124
    phi[1,2]  R738      -1.1701400279998779e+00
    phi[1,2]  R739      6.1644750833511353e-01
    phi[1,2]  R740      -1.9318168163299561e+00
    phi[1,2]  R741      -3.9235424995422363e+00
    phi[1,2]  R742      -1.4194416999816895e+00
    phi[1,2]  R743      -1.4656705856323242e+00
    phi[1,2]  R744      -1.6552976369857788e+00
    phi[1,2]  R745      5.2774280309677124e-01
    phi[1,2]  R746      -1.5542395114898682e+00
    phi[1,2]  R747      -1.0921399593353271e+00
    phi[1,2]  R748      -1.8403857946395874e+00
    phi[1,2]  R749      5.6455695629119873e-01
    phi[1,2]  R750      -5.8117306232452393e-01
    phi[1,2]  R751      -1.3469942808151245e+00
    phi[1,2]  R752      -1.0223016738891602e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R753      -3.0999999046325684e+00
    phi[2,1]  R754      -3.0999999046325684e+00
    phi[2,1]  R755      -2.2400000095367432e+00
    phi[2,1]  R756      -2.2400000095367432e+00
    phi[2,1]  R757      -3.0999999046325684e+00
    phi[2,1]  R758      -3.0999999046325684e+00
    phi[2,1]  R759      -2.5699999332427979e+00
    phi[2,1]  R760      -2.5699999332427979e+00
    phi[2,1]  R761      -3.0999999046325684e+00
    phi[2,1]  R762      -3.0999999046325684e+00
    phi[2,1]  R763      -2.0899999141693115e+00
    phi[2,1]  R764      -2.0899999141693115e+00
    phi[2,1]  R765      -3.0999999046325684e+00
    phi[2,1]  R766      -3.0999999046325684e+00
    phi[2,1]  R767      2.4659178256988525e+00
    phi[2,1]  R768      3.3490865230560303e+00
    phi[2,1]  R769      2.4996743202209473e+00
    phi[2,1]  R770      2.5079476833343506e+00
    phi[2,1]  R771      1.29396653175354
    phi[2,1]  R772      2.78867506980896
    phi[2,1]  R773      1.9115095138549805e+00
    phi[2,1]  R774      2.0590593814849854e+00
    phi[2,1]  R775      2.8269140720367432e+00
    phi[2,1]  R776      -2.0077536106109619e+00
    phi[2,1]  R777      -2.0533299446105957e+00
    phi[2,1]  R778      -1.9196538925170898e+00
    phi[2,1]  R779      -1.9923603534698486e+00
    phi[2,1]  R780      -1.9211567640304565e+00
    phi[2,1]  R781      -1.8253394365310669e+00
    phi[2,1]  R782      -2.2157876491546631e+00
    phi[2,1]  R783      -1.5762580633163452e+00
    phi[2,1]  R784      -2.4873320758342743e-01
    phi[2,1]  R785      -2.8461503982543945e+00
    phi[2,1]  R786      -7.6862621307373047e-01
    phi[2,1]  R787      -6.4954203367233276e-01
    phi[2,1]  R788      -3.4282701015472412e+00
    phi[2,1]  R789      -3.9427180290222168e+00
    phi[2,1]  R790      -4.2678065299987793e+00
    phi[2,1]  R791      -3.0079858303070068e+00
    phi[2,1]  R792      -3.0631160736083984e+00
    phi[2,1]  R793      -1.46782648563385
    phi[2,1]  R794      -3.0336687564849854e+00
    phi[2,1]  R795      -3.8640193939208984e+00
    phi[2,1]  R796      -3.2943956851959229e+00
    phi[2,1]  R797      -1.1611177921295166e+00
    phi[2,1]  R798      -5.7986313104629517e-01
    phi[2,1]  R799      -1.9690148830413818e+00
    phi[2,1]  R800      -8.2362568378448486e-01
    phi[2,1]  R801      -6.1290186643600464e-01
    phi[2,1]  R802      -4.0394032001495361e-01
    phi[2,1]  R803      -1.3289914131164551e+00
    phi[2,1]  R804      -8.8191002607345581e-01
    phi[2,1]  R805      -1.0642046928405762e+00
    phi[2,1]  R806      -3.0060732364654541e+00
    phi[2,1]  R807      -1.0136628150939941e+00
    phi[2,1]  R808      -5.7547622919082642e-01
    phi[2,1]  R809      -2.0504245758056641e+00
    phi[2,1]  R810      -3.5017967224121094e+00
    phi[2,1]  R811      8.2845389842987061e-01
    phi[2,1]  R812      -3.8474166393280029e+00
    phi[2,1]  R813      -2.5357415676116943e+00
    phi[2,1]  R814      -4.0705734491348267e-01
    phi[2,1]  R815      -5.5479627847671509e-01
    phi[2,1]  R816      -1.3401981592178345e+00
    phi[2,1]  R817      2.2928394377231598e-01
    phi[2,1]  R818      -1.3102151155471802e+00
    phi[2,1]  R819      -2.6002879142761230e+00
    phi[2,1]  R820      -1.1289610862731934e+00
    phi[2,1]  R821      -4.5500600337982178e-01
    phi[2,1]  R822      1.2885019779205322e+00
    phi[2,1]  R823      1.6775111854076385e-01
    phi[2,1]  R824      -8.9445686340332031e-01
    phi[2,1]  R825      -0.572439968585968
    phi[2,1]  R826      -4.0689194202423096e-01
    phi[2,1]  R827      -5.3437036275863647e-01
    phi[2,1]  R828      -3.1713981628417969e+00
    phi[2,1]  R829      -1.8277709484100342e+00
    phi[2,1]  R830      -2.3546919822692871e+00
    phi[2,1]  R831      0.659534215927124
    phi[2,1]  R832      -1.1701400279998779e+00
    phi[2,1]  R833      6.1644750833511353e-01
    phi[2,1]  R834      -1.9318168163299561e+00
    phi[2,1]  R835      -3.9235424995422363e+00
    phi[2,1]  R836      -1.4194416999816895e+00
    phi[2,1]  R837      -1.4656705856323242e+00
    phi[2,1]  R838      -1.6552976369857788e+00
    phi[2,1]  R839      5.2774280309677124e-01
    phi[2,1]  R840      -1.5542395114898682e+00
    phi[2,1]  R841      -1.0921399593353271e+00
    phi[2,1]  R842      -1.8403857946395874e+00
    phi[2,1]  R843      5.6455695629119873e-01
    phi[2,1]  R844      -5.8117306232452393e-01
    phi[2,1]  R845      -1.3469942808151245e+00
    phi[2,1]  R846      -1.0223016738891602e+00
    phi[2,1]  R847      2.8255476951599121e+00
    phi[2,1]  R848      1.6376597881317139e+00
    phi[2,1]  R849      1.8143465518951416e+00
    phi[2,1]  R850      2.4132685661315918e+00
    phi[2,1]  R851      -7.1099773049354553e-03
    phi[2,1]  R852      1.6474001407623291e+00
    phi[2,1]  R853      2.2077915668487549e+00
    phi[2,1]  R854      1.2585031986236572e+00
    phi[2,1]  R855      -7.2309367358684540e-02
    phi[2,1]  R856      1.0739465951919556e+00
    phi[2,1]  R857      -2.0979249477386475e+00
    phi[2,1]  R858      -3.1385366916656494e+00
    phi[2,1]  R859      -1.9412380456924438e+00
    phi[2,1]  R860      -7.4871027469635010e-01
    phi[2,1]  R861      -1.4233150482177734e+00
    phi[2,1]  R862      -1.5494239330291748e+00
    phi[2,1]  R863      -1.0974055528640747e+00
    phi[2,1]  R864      -2.2212355136871338e+00
    phi[2,1]  R865      -1.8337839841842651e-01
    phi[2,1]  R866      -2.7482404708862305e+00
    phi[2,1]  R867      9.2860013246536255e-02
    phi[2,1]  R868      -4.3843439221382141e-01
    phi[2,1]  R869      1.0260148048400879e+00
    phi[2,1]  R870      0.585195779800415
    phi[2,1]  R871      -1.2960445880889893e+00
    phi[2,1]  R872      -1.3854575157165527e+00
    phi[2,1]  R873      -2.6658253669738770e+00
    phi[2,1]  R874      -3.5919804573059082e+00
    phi[2,1]  R875      -3.8461086750030518e+00
    phi[2,1]  R876      -3.9638943672180176e+00
    phi[2,1]  R877      -1.2134146690368652e+00
    phi[2,1]  R878      -2.2867355346679688e+00
    phi[2,1]  R879      -1.8318042755126953e+00
    phi[2,1]  R880      -2.0809781551361084e+00
    phi[2,1]  R881      -3.8119897842407227e+00
    phi[2,1]  R882      -1.9319554567337036e+00
    phi[2,1]  R883      -2.7798180580139160e+00
    phi[2,1]  R884      -1.0887020826339722e+00
    phi[2,1]  R885      -3.9325242042541504e+00
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R886      -3.0999999046325684e+00
    phi[2,3]  R887      -3.0999999046325684e+00
    phi[2,3]  R888      -2.2400000095367432e+00
    phi[2,3]  R889      -2.2400000095367432e+00
    phi[2,3]  R890      -3.0999999046325684e+00
    phi[2,3]  R891      -3.0999999046325684e+00
    phi[2,3]  R892      -2.5699999332427979e+00
    phi[2,3]  R893      -2.5699999332427979e+00
    phi[2,3]  R894      -3.0999999046325684e+00
    phi[2,3]  R895      -3.0999999046325684e+00
    phi[2,3]  R896      -2.0899999141693115e+00
    phi[2,3]  R897      -2.0899999141693115e+00
    phi[2,3]  R898      -3.0999999046325684e+00
    phi[2,3]  R899      -3.0999999046325684e+00
    phi[2,3]  R900      2.4659178256988525e+00
    phi[2,3]  R901      3.3490865230560303e+00
    phi[2,3]  R902      2.4996743202209473e+00
    phi[2,3]  R903      2.5079476833343506e+00
    phi[2,3]  R904      1.29396653175354
    phi[2,3]  R905      2.78867506980896
    phi[2,3]  R906      1.9115095138549805e+00
    phi[2,3]  R907      2.0590593814849854e+00
    phi[2,3]  R908      2.8269140720367432e+00
    phi[2,3]  R909      -2.0077536106109619e+00
    phi[2,3]  R910      -2.0533299446105957e+00
    phi[2,3]  R911      -1.9196538925170898e+00
    phi[2,3]  R912      -1.9923603534698486e+00
    phi[2,3]  R913      -1.9211567640304565e+00
    phi[2,3]  R914      -1.8253394365310669e+00
    phi[2,3]  R915      -2.2157876491546631e+00
    phi[2,3]  R916      -1.5762580633163452e+00
    phi[2,3]  R917      -2.4873320758342743e-01
    phi[2,3]  R918      -2.8461503982543945e+00
    phi[2,3]  R919      -7.6862621307373047e-01
    phi[2,3]  R920      -6.4954203367233276e-01
    phi[2,3]  R921      -3.4282701015472412e+00
    phi[2,3]  R922      -3.9427180290222168e+00
    phi[2,3]  R923      -4.2678065299987793e+00
    phi[2,3]  R924      -3.0079858303070068e+00
    phi[2,3]  R925      -3.0631160736083984e+00
    phi[2,3]  R926      -1.46782648563385
    phi[2,3]  R927      -3.0336687564849854e+00
    phi[2,3]  R928      -3.8640193939208984e+00
    phi[2,3]  R929      -3.2943956851959229e+00
    phi[2,3]  R930      -1.1611177921295166e+00
    phi[2,3]  R931      -5.7986313104629517e-01
    phi[2,3]  R932      -1.9690148830413818e+00
    phi[2,3]  R933      -8.2362568378448486e-01
    phi[2,3]  R934      -6.1290186643600464e-01
    phi[2,3]  R935      -4.0394032001495361e-01
    phi[2,3]  R936      -1.3289914131164551e+00
    phi[2,3]  R937      -8.8191002607345581e-01
    phi[2,3]  R938      -1.0642046928405762e+00
    phi[2,3]  R939      -3.0060732364654541e+00
    phi[2,3]  R940      -1.0136628150939941e+00
    phi[2,3]  R941      -5.7547622919082642e-01
    phi[2,3]  R942      -2.0504245758056641e+00
    phi[2,3]  R943      -3.5017967224121094e+00
    phi[2,3]  R944      8.2845389842987061e-01
    phi[2,3]  R945      -3.8474166393280029e+00
    phi[2,3]  R946      -2.5357415676116943e+00
    phi[2,3]  R947      -4.0705734491348267e-01
    phi[2,3]  R948      -5.5479627847671509e-01
    phi[2,3]  R949      -1.3401981592178345e+00
    phi[2,3]  R950      2.2928394377231598e-01
    phi[2,3]  R951      -1.3102151155471802e+00
    phi[2,3]  R952      -2.6002879142761230e+00
    phi[2,3]  R953      -1.1289610862731934e+00
    phi[2,3]  R954      -4.5500600337982178e-01
    phi[2,3]  R955      1.2885019779205322e+00
    phi[2,3]  R956      1.6775111854076385e-01
    phi[2,3]  R957      -8.9445686340332031e-01
    phi[2,3]  R958      -0.572439968585968
    phi[2,3]  R959      -4.0689194202423096e-01
    phi[2,3]  R960      -5.3437036275863647e-01
    phi[2,3]  R961      -3.1713981628417969e+00
    phi[2,3]  R962      -1.8277709484100342e+00
    phi[2,3]  R963      -2.3546919822692871e+00
    phi[2,3]  R964      0.659534215927124
    phi[2,3]  R965      -1.1701400279998779e+00
    phi[2,3]  R966      6.1644750833511353e-01
    phi[2,3]  R967      -1.9318168163299561e+00
    phi[2,3]  R968      -3.9235424995422363e+00
    phi[2,3]  R969      -1.4194416999816895e+00
    phi[2,3]  R970      -1.4656705856323242e+00
    phi[2,3]  R971      -1.6552976369857788e+00
    phi[2,3]  R972      5.2774280309677124e-01
    phi[2,3]  R973      -1.5542395114898682e+00
    phi[2,3]  R974      -1.0921399593353271e+00
    phi[2,3]  R975      -1.8403857946395874e+00
    phi[2,3]  R976      5.6455695629119873e-01
    phi[2,3]  R977      -5.8117306232452393e-01
    phi[2,3]  R978      -1.3469942808151245e+00
    phi[2,3]  R979      -1.0223016738891602e+00
    phi[2,3]  R980      3.3472101688385010e+00
    phi[2,3]  R981      1.3084985017776489e+00
    phi[2,3]  R982      2.0079648494720459e+00
    phi[2,3]  R983      8.1774353981018066e-01
    phi[2,3]  R984      -0.475978821516037
    phi[2,3]  R985      1.4620501995086670e+00
    phi[2,3]  R986      1.6063314676284790e+00
    phi[2,3]  R987      1.0907442569732666e+00
    phi[2,3]  R988      -2.9691624641418457e-01
    phi[2,3]  R989      0.71807861328125
    phi[2,3]  R990      -1.0853511095046997e+00
    phi[2,3]  R991      -1.0113013982772827e+00
    phi[2,3]  R992      -1.0803729295730591e+00
    phi[2,3]  R993      -2.2517018318176270e+00
    phi[2,3]  R994      -0.941821813583374
    phi[2,3]  R995      -1.7487556934356689e+00
    phi[2,3]  R996      -1.3687537908554077e+00
    phi[2,3]  R997      -1.9885156154632568e+00
    phi[2,3]  R998      -1.2804843187332153e+00
    phi[2,3]  R999      -2.6465651988983154e+00
    phi[2,3]  R1000     5.8292299509048462e-01
    phi[2,3]  R1001     1.0333803892135620e+00
    phi[2,3]  R1002     1.6533536911010742e+00
    phi[2,3]  R1003     3.3055528998374939e-01
    phi[2,3]  R1004     -8.4623742103576660e-01
    phi[2,3]  R1005     1.7898873984813690e-01
    phi[2,3]  R1006     -7.7188891172409058e-01
    phi[2,3]  R1007     1.1617679595947266e+00
    phi[2,3]  R1008     -8.1293195486068726e-01
    phi[2,3]  R1009     1.2716345489025116e-01
    phi[2,3]  R1010     7.3049122095108032e-01
    phi[2,3]  R1011     -0.580988347530365
    phi[2,3]  R1012     3.6772155761718750e-01
    phi[2,3]  R1013     -1.5389579534530640e+00
    phi[2,3]  R1014     -3.1108215451240540e-01
    phi[2,3]  R1015     -2.14025616645813
    phi[2,3]  R1016     7.9058343172073364e-01
    phi[2,3]  R1017     3.8353833556175232e-01
    phi[2,3]  R1018     6.7698067426681519e-01
    phi[2,3]  R1019     1.5233312845230103e+00
    phi[2,3]  R1020     -2.0604968070983887e+00
    phi[2,3]  R1021     -7.1972668170928955e-01
    phi[2,3]  R1022     1.7803077697753906e+00
    phi[2,3]  R1023     -2.9981181621551514e+00
    phi[2,3]  R1024     -2.6410202980041504e+00
    phi[2,3]  R1025     -7.5139951705932617e-01
    phi[2,3]  R1026     -2.1478869915008545e+00
    phi[2,3]  R1027     -3.0063352584838867e+00
    phi[2,3]  R1028     -3.3105671405792236e+00
    phi[2,3]  R1029     -2.0319457054138184e+00
    phi[2,3]  R1030     -1.5181496143341064e+00
    phi[2,3]  R1031     5.9606772661209106e-01
    phi[2,3]  R1032     1.7837435007095337e+00
    phi[2,3]  R1033     8.2801789045333862e-01
    phi[2,3]  R1034     -5.6969958543777466e-01
    phi[2,3]  R1035     -3.82307767868042
    phi[2,3]  R1036     -3.5161182880401611e+00
    phi[2,3]  R1037     -4.2280626296997070e+00
    phi[2,3]  R1038     -4.5355324745178223e+00
    phi[2,3]  R1039     -3.6421120166778564e+00
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R1040     -3.0999999046325684e+00
    phi[3,2]  R1041     -3.0999999046325684e+00
    phi[3,2]  R1042     -2.2400000095367432e+00
    phi[3,2]  R1043     -2.2400000095367432e+00
    phi[3,2]  R1044     -3.0999999046325684e+00
    phi[3,2]  R1045     -3.0999999046325684e+00
    phi[3,2]  R1046     -2.5699999332427979e+00
    phi[3,2]  R1047     -2.5699999332427979e+00
    phi[3,2]  R1048     -3.0999999046325684e+00
    phi[3,2]  R1049     -3.0999999046325684e+00
    phi[3,2]  R1050     -2.0899999141693115e+00
    phi[3,2]  R1051     -2.0899999141693115e+00
    phi[3,2]  R1052     -3.0999999046325684e+00
    phi[3,2]  R1053     -3.0999999046325684e+00
    phi[3,2]  R1054     3.3472101688385010e+00
    phi[3,2]  R1055     1.3084985017776489e+00
    phi[3,2]  R1056     2.0079648494720459e+00
    phi[3,2]  R1057     8.1774353981018066e-01
    phi[3,2]  R1058     -0.475978821516037
    phi[3,2]  R1059     1.4620501995086670e+00
    phi[3,2]  R1060     1.6063314676284790e+00
    phi[3,2]  R1061     1.0907442569732666e+00
    phi[3,2]  R1062     -2.9691624641418457e-01
    phi[3,2]  R1063     0.71807861328125
    phi[3,2]  R1064     -1.0853511095046997e+00
    phi[3,2]  R1065     -1.0113013982772827e+00
    phi[3,2]  R1066     -1.0803729295730591e+00
    phi[3,2]  R1067     -2.2517018318176270e+00
    phi[3,2]  R1068     -0.941821813583374
    phi[3,2]  R1069     -1.7487556934356689e+00
    phi[3,2]  R1070     -1.3687537908554077e+00
    phi[3,2]  R1071     -1.9885156154632568e+00
    phi[3,2]  R1072     -1.2804843187332153e+00
    phi[3,2]  R1073     -2.6465651988983154e+00
    phi[3,2]  R1074     5.8292299509048462e-01
    phi[3,2]  R1075     1.0333803892135620e+00
    phi[3,2]  R1076     1.6533536911010742e+00
    phi[3,2]  R1077     3.3055528998374939e-01
    phi[3,2]  R1078     -8.4623742103576660e-01
    phi[3,2]  R1079     1.7898873984813690e-01
    phi[3,2]  R1080     -7.7188891172409058e-01
    phi[3,2]  R1081     1.1617679595947266e+00
    phi[3,2]  R1082     -8.1293195486068726e-01
    phi[3,2]  R1083     1.2716345489025116e-01
    phi[3,2]  R1084     7.3049122095108032e-01
    phi[3,2]  R1085     -0.580988347530365
    phi[3,2]  R1086     3.6772155761718750e-01
    phi[3,2]  R1087     -1.5389579534530640e+00
    phi[3,2]  R1088     -3.1108215451240540e-01
    phi[3,2]  R1089     -2.14025616645813
    phi[3,2]  R1090     7.9058343172073364e-01
    phi[3,2]  R1091     3.8353833556175232e-01
    phi[3,2]  R1092     6.7698067426681519e-01
    phi[3,2]  R1093     1.5233312845230103e+00
    phi[3,2]  R1094     -2.0604968070983887e+00
    phi[3,2]  R1095     -7.1972668170928955e-01
    phi[3,2]  R1096     1.7803077697753906e+00
    phi[3,2]  R1097     -2.9981181621551514e+00
    phi[3,2]  R1098     -2.6410202980041504e+00
    phi[3,2]  R1099     -7.5139951705932617e-01
    phi[3,2]  R1100     -2.1478869915008545e+00
    phi[3,2]  R1101     -3.0063352584838867e+00
    phi[3,2]  R1102     -3.3105671405792236e+00
    phi[3,2]  R1103     -2.0319457054138184e+00
    phi[3,2]  R1104     -1.5181496143341064e+00
    phi[3,2]  R1105     5.9606772661209106e-01
    phi[3,2]  R1106     1.7837435007095337e+00
    phi[3,2]  R1107     8.2801789045333862e-01
    phi[3,2]  R1108     -5.6969958543777466e-01
    phi[3,2]  R1109     -3.82307767868042
    phi[3,2]  R1110     -3.5161182880401611e+00
    phi[3,2]  R1111     -4.2280626296997070e+00
    phi[3,2]  R1112     -4.5355324745178223e+00
    phi[3,2]  R1113     -3.6421120166778564e+00
    phi[3,2]  R1114     2.4659178256988525e+00
    phi[3,2]  R1115     3.3490865230560303e+00
    phi[3,2]  R1116     2.4996743202209473e+00
    phi[3,2]  R1117     2.5079476833343506e+00
    phi[3,2]  R1118     1.29396653175354
    phi[3,2]  R1119     2.78867506980896
    phi[3,2]  R1120     1.9115095138549805e+00
    phi[3,2]  R1121     2.0590593814849854e+00
    phi[3,2]  R1122     2.8269140720367432e+00
    phi[3,2]  R1123     -2.0077536106109619e+00
    phi[3,2]  R1124     -2.0533299446105957e+00
    phi[3,2]  R1125     -1.9196538925170898e+00
    phi[3,2]  R1126     -1.9923603534698486e+00
    phi[3,2]  R1127     -1.9211567640304565e+00
    phi[3,2]  R1128     -1.8253394365310669e+00
    phi[3,2]  R1129     -2.2157876491546631e+00
    phi[3,2]  R1130     -1.5762580633163452e+00
    phi[3,2]  R1131     -2.4873320758342743e-01
    phi[3,2]  R1132     -2.8461503982543945e+00
    phi[3,2]  R1133     -7.6862621307373047e-01
    phi[3,2]  R1134     -6.4954203367233276e-01
    phi[3,2]  R1135     -3.4282701015472412e+00
    phi[3,2]  R1136     -3.9427180290222168e+00
    phi[3,2]  R1137     -4.2678065299987793e+00
    phi[3,2]  R1138     -3.0079858303070068e+00
    phi[3,2]  R1139     -3.0631160736083984e+00
    phi[3,2]  R1140     -1.46782648563385
    phi[3,2]  R1141     -3.0336687564849854e+00
    phi[3,2]  R1142     -3.8640193939208984e+00
    phi[3,2]  R1143     -3.2943956851959229e+00
    phi[3,2]  R1144     -1.1611177921295166e+00
    phi[3,2]  R1145     -5.7986313104629517e-01
    phi[3,2]  R1146     -1.9690148830413818e+00
    phi[3,2]  R1147     -8.2362568378448486e-01
    phi[3,2]  R1148     -6.1290186643600464e-01
    phi[3,2]  R1149     -4.0394032001495361e-01
    phi[3,2]  R1150     -1.3289914131164551e+00
    phi[3,2]  R1151     -8.8191002607345581e-01
    phi[3,2]  R1152     -1.0642046928405762e+00
    phi[3,2]  R1153     -3.0060732364654541e+00
    phi[3,2]  R1154     -1.0136628150939941e+00
    phi[3,2]  R1155     -5.7547622919082642e-01
    phi[3,2]  R1156     -2.0504245758056641e+00
    phi[3,2]  R1157     -3.5017967224121094e+00
    phi[3,2]  R1158     8.2845389842987061e-01
    phi[3,2]  R1159     -3.8474166393280029e+00
    phi[3,2]  R1160     -2.5357415676116943e+00
    phi[3,2]  R1161     -4.0705734491348267e-01
    phi[3,2]  R1162     -5.5479627847671509e-01
    phi[3,2]  R1163     -1.3401981592178345e+00
    phi[3,2]  R1164     2.2928394377231598e-01
    phi[3,2]  R1165     -1.3102151155471802e+00
    phi[3,2]  R1166     -2.6002879142761230e+00
    phi[3,2]  R1167     -1.1289610862731934e+00
    phi[3,2]  R1168     -4.5500600337982178e-01
    phi[3,2]  R1169     1.2885019779205322e+00
    phi[3,2]  R1170     1.6775111854076385e-01
    phi[3,2]  R1171     -8.9445686340332031e-01
    phi[3,2]  R1172     -0.572439968585968
    phi[3,2]  R1173     -4.0689194202423096e-01
    phi[3,2]  R1174     -5.3437036275863647e-01
    phi[3,2]  R1175     -3.1713981628417969e+00
    phi[3,2]  R1176     -1.8277709484100342e+00
    phi[3,2]  R1177     -2.3546919822692871e+00
    phi[3,2]  R1178     0.659534215927124
    phi[3,2]  R1179     -1.1701400279998779e+00
    phi[3,2]  R1180     6.1644750833511353e-01
    phi[3,2]  R1181     -1.9318168163299561e+00
    phi[3,2]  R1182     -3.9235424995422363e+00
    phi[3,2]  R1183     -1.4194416999816895e+00
    phi[3,2]  R1184     -1.4656705856323242e+00
    phi[3,2]  R1185     -1.6552976369857788e+00
    phi[3,2]  R1186     5.2774280309677124e-01
    phi[3,2]  R1187     -1.5542395114898682e+00
    phi[3,2]  R1188     -1.0921399593353271e+00
    phi[3,2]  R1189     -1.8403857946395874e+00
    phi[3,2]  R1190     5.6455695629119873e-01
    phi[3,2]  R1191     -5.8117306232452393e-01
    phi[3,2]  R1192     -1.3469942808151245e+00
    phi[3,2]  R1193     -1.0223016738891602e+00
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R1194     -3.0999999046325684e+00
    phi[3,4]  R1195     -3.0999999046325684e+00
    phi[3,4]  R1196     -2.2400000095367432e+00
    phi[3,4]  R1197     -2.2400000095367432e+00
    phi[3,4]  R1198     -3.0999999046325684e+00
    phi[3,4]  R1199     -3.0999999046325684e+00
    phi[3,4]  R1200     -2.5699999332427979e+00
    phi[3,4]  R1201     -2.5699999332427979e+00
    phi[3,4]  R1202     -3.0999999046325684e+00
    phi[3,4]  R1203     -3.0999999046325684e+00
    phi[3,4]  R1204     -2.0899999141693115e+00
    phi[3,4]  R1205     -2.0899999141693115e+00
    phi[3,4]  R1206     -3.0999999046325684e+00
    phi[3,4]  R1207     -3.0999999046325684e+00
    phi[3,4]  R1208     3.3472101688385010e+00
    phi[3,4]  R1209     1.3084985017776489e+00
    phi[3,4]  R1210     2.0079648494720459e+00
    phi[3,4]  R1211     8.1774353981018066e-01
    phi[3,4]  R1212     -0.475978821516037
    phi[3,4]  R1213     1.4620501995086670e+00
    phi[3,4]  R1214     1.6063314676284790e+00
    phi[3,4]  R1215     1.0907442569732666e+00
    phi[3,4]  R1216     -2.9691624641418457e-01
    phi[3,4]  R1217     0.71807861328125
    phi[3,4]  R1218     -1.0853511095046997e+00
    phi[3,4]  R1219     -1.0113013982772827e+00
    phi[3,4]  R1220     -1.0803729295730591e+00
    phi[3,4]  R1221     -2.2517018318176270e+00
    phi[3,4]  R1222     -0.941821813583374
    phi[3,4]  R1223     -1.7487556934356689e+00
    phi[3,4]  R1224     -1.3687537908554077e+00
    phi[3,4]  R1225     -1.9885156154632568e+00
    phi[3,4]  R1226     -1.2804843187332153e+00
    phi[3,4]  R1227     -2.6465651988983154e+00
    phi[3,4]  R1228     5.8292299509048462e-01
    phi[3,4]  R1229     1.0333803892135620e+00
    phi[3,4]  R1230     1.6533536911010742e+00
    phi[3,4]  R1231     3.3055528998374939e-01
    phi[3,4]  R1232     -8.4623742103576660e-01
    phi[3,4]  R1233     1.7898873984813690e-01
    phi[3,4]  R1234     -7.7188891172409058e-01
    phi[3,4]  R1235     1.1617679595947266e+00
    phi[3,4]  R1236     -8.1293195486068726e-01
    phi[3,4]  R1237     1.2716345489025116e-01
    phi[3,4]  R1238     7.3049122095108032e-01
    phi[3,4]  R1239     -0.580988347530365
    phi[3,4]  R1240     3.6772155761718750e-01
    phi[3,4]  R1241     -1.5389579534530640e+00
    phi[3,4]  R1242     -3.1108215451240540e-01
    phi[3,4]  R1243     -2.14025616645813
    phi[3,4]  R1244     7.9058343172073364e-01
    phi[3,4]  R1245     3.8353833556175232e-01
    phi[3,4]  R1246     6.7698067426681519e-01
    phi[3,4]  R1247     1.5233312845230103e+00
    phi[3,4]  R1248     -2.0604968070983887e+00
    phi[3,4]  R1249     -7.1972668170928955e-01
    phi[3,4]  R1250     1.7803077697753906e+00
    phi[3,4]  R1251     -2.9981181621551514e+00
    phi[3,4]  R1252     -2.6410202980041504e+00
    phi[3,4]  R1253     -7.5139951705932617e-01
    phi[3,4]  R1254     -2.1478869915008545e+00
    phi[3,4]  R1255     -3.0063352584838867e+00
    phi[3,4]  R1256     -3.3105671405792236e+00
    phi[3,4]  R1257     -2.0319457054138184e+00
    phi[3,4]  R1258     -1.5181496143341064e+00
    phi[3,4]  R1259     5.9606772661209106e-01
    phi[3,4]  R1260     1.7837435007095337e+00
    phi[3,4]  R1261     8.2801789045333862e-01
    phi[3,4]  R1262     -5.6969958543777466e-01
    phi[3,4]  R1263     -3.82307767868042
    phi[3,4]  R1264     -3.5161182880401611e+00
    phi[3,4]  R1265     -4.2280626296997070e+00
    phi[3,4]  R1266     -4.5355324745178223e+00
    phi[3,4]  R1267     -3.6421120166778564e+00
    phi[3,4]  R1268     2.4554170668125153e-01
    phi[3,4]  R1269     2.0015807151794434e+00
    phi[3,4]  R1270     2.7209651470184326e-01
    phi[3,4]  R1271     9.1127502918243408e-01
    phi[3,4]  R1272     2.6279065012931824e-01
    phi[3,4]  R1273     1.8250066041946411e+00
    phi[3,4]  R1274     2.3525445461273193e+00
    phi[3,4]  R1275     -1.6637399196624756e+00
    phi[3,4]  R1276     1.6145361661911011e+00
    phi[3,4]  R1277     1.8228259086608887e+00
    phi[3,4]  R1278     -3.1709613800048828e+00
    phi[3,4]  R1279     -1.9620960950851440e+00
    phi[3,4]  R1280     -2.4418601989746094e+00
    phi[3,4]  R1281     -1.7502965927124023e+00
    phi[3,4]  R1282     -2.3642110824584961e+00
    phi[3,4]  R1283     1.8210785090923309e-01
    phi[3,4]  R1284     -1.7012616395950317e+00
    phi[3,4]  R1285     -1.3297581672668457e+00
    phi[3,4]  R1286     -1.4885883331298828e+00
    phi[3,4]  R1287     -6.2500774860382080e-01
    phi[3,4]  R1288     -1.1465466022491455e+00
    phi[3,4]  R1289     -3.0107921361923218e-01
    phi[3,4]  R1290     -3.3391624689102173e-01
    phi[3,4]  R1291     -5.0472670793533325e-01
    phi[3,4]  R1292     -5.0474262237548828e-01
    phi[3,4]  R1293     -9.4780218601226807e-01
    phi[3,4]  R1294     -8.0716520547866821e-02
    phi[3,4]  R1295     8.9250475168228149e-01
    phi[3,4]  R1296     -8.1894034147262573e-01
    phi[3,4]  R1297     -8.7835514545440674e-01
    phi[3,4]  R1298     -1.4548428058624268e+00
    phi[3,4]  R1299     -1.1421382427215576e-01
    phi[3,4]  R1300     -0.00703435018658638
    phi[3,4]  R1301     -1.0831748247146606e+00
    phi[3,4]  R1302     -1.3969817161560059e+00
    phi[3,4]  R1303     1.0149409770965576e+00
    phi[3,4]  R1304     -2.08876633644104
    phi[3,4]  R1305     2.0022043585777283e-01
    phi[3,4]  R1306     8.3592301607131958e-01
    phi[3,4]  R1307     3.3752602338790894e-01
    phi[3,4]  R1308     -2.7087352275848389e+00
    phi[3,4]  R1309     -1.6288059949874878e-01
    phi[3,4]  R1310     -2.1067297458648682e+00
    phi[3,4]  R1311     7.2264093160629272e-01
    phi[3,4]  R1312     2.1823601722717285e+00
    phi[3,4]  R1313     0.365295946598053
    phi[3,4]  R1314     2.2231190204620361e+00
    phi[3,4]  R1315     1.8392943143844604e+00
    phi[3,4]  R1316     1.3159852027893066e+00
    phi[3,4]  R1317     2.2020010948181152e+00
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R1318     -3.0999999046325684e+00
    phi[4,3]  R1319     -3.0999999046325684e+00
    phi[4,3]  R1320     -2.2400000095367432e+00
    phi[4,3]  R1321     -2.2400000095367432e+00
    phi[4,3]  R1322     -3.0999999046325684e+00
    phi[4,3]  R1323     -3.0999999046325684e+00
    phi[4,3]  R1324     -2.5699999332427979e+00
    phi[4,3]  R1325     -2.5699999332427979e+00
    phi[4,3]  R1326     -3.0999999046325684e+00
    phi[4,3]  R1327     -3.0999999046325684e+00
    phi[4,3]  R1328     -2.0899999141693115e+00
    phi[4,3]  R1329     -2.0899999141693115e+00
    phi[4,3]  R1330     -3.0999999046325684e+00
    phi[4,3]  R1331     -3.0999999046325684e+00
    phi[4,3]  R1332     2.4554170668125153e-01
    phi[4,3]  R1333     2.0015807151794434e+00
    phi[4,3]  R1334     2.7209651470184326e-01
    phi[4,3]  R1335     9.1127502918243408e-01
    phi[4,3]  R1336     2.6279065012931824e-01
    phi[4,3]  R1337     1.8250066041946411e+00
    phi[4,3]  R1338     2.3525445461273193e+00
    phi[4,3]  R1339     -1.6637399196624756e+00
    phi[4,3]  R1340     1.6145361661911011e+00
    phi[4,3]  R1341     1.8228259086608887e+00
    phi[4,3]  R1342     -3.1709613800048828e+00
    phi[4,3]  R1343     -1.9620960950851440e+00
    phi[4,3]  R1344     -2.4418601989746094e+00
    phi[4,3]  R1345     -1.7502965927124023e+00
    phi[4,3]  R1346     -2.3642110824584961e+00
    phi[4,3]  R1347     1.8210785090923309e-01
    phi[4,3]  R1348     -1.7012616395950317e+00
    phi[4,3]  R1349     -1.3297581672668457e+00
    phi[4,3]  R1350     -1.4885883331298828e+00
    phi[4,3]  R1351     -6.2500774860382080e-01
    phi[4,3]  R1352     -1.1465466022491455e+00
    phi[4,3]  R1353     -3.0107921361923218e-01
    phi[4,3]  R1354     -3.3391624689102173e-01
    phi[4,3]  R1355     -5.0472670793533325e-01
    phi[4,3]  R1356     -5.0474262237548828e-01
    phi[4,3]  R1357     -9.4780218601226807e-01
    phi[4,3]  R1358     -8.0716520547866821e-02
    phi[4,3]  R1359     8.9250475168228149e-01
    phi[4,3]  R1360     -8.1894034147262573e-01
    phi[4,3]  R1361     -8.7835514545440674e-01
    phi[4,3]  R1362     -1.4548428058624268e+00
    phi[4,3]  R1363     -1.1421382427215576e-01
    phi[4,3]  R1364     -0.00703435018658638
    phi[4,3]  R1365     -1.0831748247146606e+00
    phi[4,3]  R1366     -1.3969817161560059e+00
    phi[4,3]  R1367     1.0149409770965576e+00
    phi[4,3]  R1368     -2.08876633644104
    phi[4,3]  R1369     2.0022043585777283e-01
    phi[4,3]  R1370     8.3592301607131958e-01
    phi[4,3]  R1371     3.3752602338790894e-01
    phi[4,3]  R1372     -2.7087352275848389e+00
    phi[4,3]  R1373     -1.6288059949874878e-01
    phi[4,3]  R1374     -2.1067297458648682e+00
    phi[4,3]  R1375     7.2264093160629272e-01
    phi[4,3]  R1376     2.1823601722717285e+00
    phi[4,3]  R1377     0.365295946598053
    phi[4,3]  R1378     2.2231190204620361e+00
    phi[4,3]  R1379     1.8392943143844604e+00
    phi[4,3]  R1380     1.3159852027893066e+00
    phi[4,3]  R1381     2.2020010948181152e+00
    phi[4,3]  R1382     3.3472101688385010e+00
    phi[4,3]  R1383     1.3084985017776489e+00
    phi[4,3]  R1384     2.0079648494720459e+00
    phi[4,3]  R1385     8.1774353981018066e-01
    phi[4,3]  R1386     -0.475978821516037
    phi[4,3]  R1387     1.4620501995086670e+00
    phi[4,3]  R1388     1.6063314676284790e+00
    phi[4,3]  R1389     1.0907442569732666e+00
    phi[4,3]  R1390     -2.9691624641418457e-01
    phi[4,3]  R1391     0.71807861328125
    phi[4,3]  R1392     -1.0853511095046997e+00
    phi[4,3]  R1393     -1.0113013982772827e+00
    phi[4,3]  R1394     -1.0803729295730591e+00
    phi[4,3]  R1395     -2.2517018318176270e+00
    phi[4,3]  R1396     -0.941821813583374
    phi[4,3]  R1397     -1.7487556934356689e+00
    phi[4,3]  R1398     -1.3687537908554077e+00
    phi[4,3]  R1399     -1.9885156154632568e+00
    phi[4,3]  R1400     -1.2804843187332153e+00
    phi[4,3]  R1401     -2.6465651988983154e+00
    phi[4,3]  R1402     5.8292299509048462e-01
    phi[4,3]  R1403     1.0333803892135620e+00
    phi[4,3]  R1404     1.6533536911010742e+00
    phi[4,3]  R1405     3.3055528998374939e-01
    phi[4,3]  R1406     -8.4623742103576660e-01
    phi[4,3]  R1407     1.7898873984813690e-01
    phi[4,3]  R1408     -7.7188891172409058e-01
    phi[4,3]  R1409     1.1617679595947266e+00
    phi[4,3]  R1410     -8.1293195486068726e-01
    phi[4,3]  R1411     1.2716345489025116e-01
    phi[4,3]  R1412     7.3049122095108032e-01
    phi[4,3]  R1413     -0.580988347530365
    phi[4,3]  R1414     3.6772155761718750e-01
    phi[4,3]  R1415     -1.5389579534530640e+00
    phi[4,3]  R1416     -3.1108215451240540e-01
    phi[4,3]  R1417     -2.14025616645813
    phi[4,3]  R1418     7.9058343172073364e-01
    phi[4,3]  R1419     3.8353833556175232e-01
    phi[4,3]  R1420     6.7698067426681519e-01
    phi[4,3]  R1421     1.5233312845230103e+00
    phi[4,3]  R1422     -2.0604968070983887e+00
    phi[4,3]  R1423     -7.1972668170928955e-01
    phi[4,3]  R1424     1.7803077697753906e+00
    phi[4,3]  R1425     -2.9981181621551514e+00
    phi[4,3]  R1426     -2.6410202980041504e+00
    phi[4,3]  R1427     -7.5139951705932617e-01
    phi[4,3]  R1428     -2.1478869915008545e+00
    phi[4,3]  R1429     -3.0063352584838867e+00
    phi[4,3]  R1430     -3.3105671405792236e+00
    phi[4,3]  R1431     -2.0319457054138184e+00
    phi[4,3]  R1432     -1.5181496143341064e+00
    phi[4,3]  R1433     5.9606772661209106e-01
    phi[4,3]  R1434     1.7837435007095337e+00
    phi[4,3]  R1435     8.2801789045333862e-01
    phi[4,3]  R1436     -5.6969958543777466e-01
    phi[4,3]  R1437     -3.82307767868042
    phi[4,3]  R1438     -3.5161182880401611e+00
    phi[4,3]  R1439     -4.2280626296997070e+00
    phi[4,3]  R1440     -4.5355324745178223e+00
    phi[4,3]  R1441     -3.6421120166778564e+00
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R1442     -3.0999999046325684e+00
    phi[4,5]  R1443     -3.0999999046325684e+00
    phi[4,5]  R1444     -2.2400000095367432e+00
    phi[4,5]  R1445     -2.2400000095367432e+00
    phi[4,5]  R1446     -3.0999999046325684e+00
    phi[4,5]  R1447     -3.0999999046325684e+00
    phi[4,5]  R1448     -2.5699999332427979e+00
    phi[4,5]  R1449     -2.5699999332427979e+00
    phi[4,5]  R1450     -3.0999999046325684e+00
    phi[4,5]  R1451     -3.0999999046325684e+00
    phi[4,5]  R1452     -2.0899999141693115e+00
    phi[4,5]  R1453     -2.0899999141693115e+00
    phi[4,5]  R1454     -3.0999999046325684e+00
    phi[4,5]  R1455     -3.0999999046325684e+00
    phi[4,5]  R1456     2.4554170668125153e-01
    phi[4,5]  R1457     2.0015807151794434e+00
    phi[4,5]  R1458     2.7209651470184326e-01
    phi[4,5]  R1459     9.1127502918243408e-01
    phi[4,5]  R1460     2.6279065012931824e-01
    phi[4,5]  R1461     1.8250066041946411e+00
    phi[4,5]  R1462     2.3525445461273193e+00
    phi[4,5]  R1463     -1.6637399196624756e+00
    phi[4,5]  R1464     1.6145361661911011e+00
    phi[4,5]  R1465     1.8228259086608887e+00
    phi[4,5]  R1466     -3.1709613800048828e+00
    phi[4,5]  R1467     -1.9620960950851440e+00
    phi[4,5]  R1468     -2.4418601989746094e+00
    phi[4,5]  R1469     -1.7502965927124023e+00
    phi[4,5]  R1470     -2.3642110824584961e+00
    phi[4,5]  R1471     1.8210785090923309e-01
    phi[4,5]  R1472     -1.7012616395950317e+00
    phi[4,5]  R1473     -1.3297581672668457e+00
    phi[4,5]  R1474     -1.4885883331298828e+00
    phi[4,5]  R1475     -6.2500774860382080e-01
    phi[4,5]  R1476     -1.1465466022491455e+00
    phi[4,5]  R1477     -3.0107921361923218e-01
    phi[4,5]  R1478     -3.3391624689102173e-01
    phi[4,5]  R1479     -5.0472670793533325e-01
    phi[4,5]  R1480     -5.0474262237548828e-01
    phi[4,5]  R1481     -9.4780218601226807e-01
    phi[4,5]  R1482     -8.0716520547866821e-02
    phi[4,5]  R1483     8.9250475168228149e-01
    phi[4,5]  R1484     -8.1894034147262573e-01
    phi[4,5]  R1485     -8.7835514545440674e-01
    phi[4,5]  R1486     -1.4548428058624268e+00
    phi[4,5]  R1487     -1.1421382427215576e-01
    phi[4,5]  R1488     -0.00703435018658638
    phi[4,5]  R1489     -1.0831748247146606e+00
    phi[4,5]  R1490     -1.3969817161560059e+00
    phi[4,5]  R1491     1.0149409770965576e+00
    phi[4,5]  R1492     -2.08876633644104
    phi[4,5]  R1493     2.0022043585777283e-01
    phi[4,5]  R1494     8.3592301607131958e-01
    phi[4,5]  R1495     3.3752602338790894e-01
    phi[4,5]  R1496     -2.7087352275848389e+00
    phi[4,5]  R1497     -1.6288059949874878e-01
    phi[4,5]  R1498     -2.1067297458648682e+00
    phi[4,5]  R1499     7.2264093160629272e-01
    phi[4,5]  R1500     2.1823601722717285e+00
    phi[4,5]  R1501     0.365295946598053
    phi[4,5]  R1502     2.2231190204620361e+00
    phi[4,5]  R1503     1.8392943143844604e+00
    phi[4,5]  R1504     1.3159852027893066e+00
    phi[4,5]  R1505     2.2020010948181152e+00
    phi[4,5]  R1506     1.4089076519012451e+00
    phi[4,5]  R1507     5.0157934427261353e-01
    phi[4,5]  R1508     0.856260359287262
    phi[4,5]  R1509     -1.7058482170104980e+00
    phi[4,5]  R1510     1.4688451290130615e+00
    phi[4,5]  R1511     1.9081563949584961e+00
    phi[4,5]  R1512     1.6497502326965332e+00
    phi[4,5]  R1513     -1.2351997941732407e-01
    phi[4,5]  R1514     9.9750292301177979e-01
    phi[4,5]  R1515     1.8146909475326538e+00
    phi[4,5]  R1516     -2.26825213432312
    phi[4,5]  R1517     -3.0364022254943848e+00
    phi[4,5]  R1518     -1.4993966817855835e+00
    phi[4,5]  R1519     -6.7183154821395874e-01
    phi[4,5]  R1520     -8.2764267921447754e-01
    phi[4,5]  R1521     -1.3072822988033295e-01
    phi[4,5]  R1522     -1.4210142195224762e-01
    phi[4,5]  R1523     -6.3594490289688110e-01
    phi[4,5]  R1524     -4.8353064060211182e-01
    phi[4,5]  R1525     1.5891817808151245e+00
    phi[4,5]  R1526     -1.4965319633483887e+00
    phi[4,5]  R1527     -4.5388080179691315e-02
    phi[4,5]  R1528     -1.1536408662796021e+00
    phi[4,5]  R1529     -1.0147856473922729e+00
    phi[4,5]  R1530     3.1286403536796570e-01
    phi[4,5]  R1531     1.1194306612014771e+00
    phi[4,5]  R1532     8.9113295078277588e-01
    phi[4,5]  R1533     4.8250004649162292e-02
    phi[4,5]  R1534     1.1917916536331177e+00
    phi[4,5]  R1535     2.3246276378631592e-01
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R1536     -3.0999999046325684e+00
    phi[5,4]  R1537     -3.0999999046325684e+00
    phi[5,4]  R1538     -2.2400000095367432e+00
    phi[5,4]  R1539     -2.2400000095367432e+00
    phi[5,4]  R1540     -3.0999999046325684e+00
    phi[5,4]  R1541     -3.0999999046325684e+00
    phi[5,4]  R1542     -2.5699999332427979e+00
    phi[5,4]  R1543     -2.5699999332427979e+00
    phi[5,4]  R1544     -3.0999999046325684e+00
    phi[5,4]  R1545     -3.0999999046325684e+00
    phi[5,4]  R1546     -2.0899999141693115e+00
    phi[5,4]  R1547     -2.0899999141693115e+00
    phi[5,4]  R1548     -3.0999999046325684e+00
    phi[5,4]  R1549     -3.0999999046325684e+00
    phi[5,4]  R1550     1.4089076519012451e+00
    phi[5,4]  R1551     5.0157934427261353e-01
    phi[5,4]  R1552     0.856260359287262
    phi[5,4]  R1553     -1.7058482170104980e+00
    phi[5,4]  R1554     1.4688451290130615e+00
    phi[5,4]  R1555     1.9081563949584961e+00
    phi[5,4]  R1556     1.6497502326965332e+00
    phi[5,4]  R1557     -1.2351997941732407e-01
    phi[5,4]  R1558     9.9750292301177979e-01
    phi[5,4]  R1559     1.8146909475326538e+00
    phi[5,4]  R1560     -2.26825213432312
    phi[5,4]  R1561     -3.0364022254943848e+00
    phi[5,4]  R1562     -1.4993966817855835e+00
    phi[5,4]  R1563     -6.7183154821395874e-01
    phi[5,4]  R1564     -8.2764267921447754e-01
    phi[5,4]  R1565     -1.3072822988033295e-01
    phi[5,4]  R1566     -1.4210142195224762e-01
    phi[5,4]  R1567     -6.3594490289688110e-01
    phi[5,4]  R1568     -4.8353064060211182e-01
    phi[5,4]  R1569     1.5891817808151245e+00
    phi[5,4]  R1570     -1.4965319633483887e+00
    phi[5,4]  R1571     -4.5388080179691315e-02
    phi[5,4]  R1572     -1.1536408662796021e+00
    phi[5,4]  R1573     -1.0147856473922729e+00
    phi[5,4]  R1574     3.1286403536796570e-01
    phi[5,4]  R1575     1.1194306612014771e+00
    phi[5,4]  R1576     8.9113295078277588e-01
    phi[5,4]  R1577     4.8250004649162292e-02
    phi[5,4]  R1578     1.1917916536331177e+00
    phi[5,4]  R1579     2.3246276378631592e-01
    phi[5,4]  R1580     2.4554170668125153e-01
    phi[5,4]  R1581     2.0015807151794434e+00
    phi[5,4]  R1582     2.7209651470184326e-01
    phi[5,4]  R1583     9.1127502918243408e-01
    phi[5,4]  R1584     2.6279065012931824e-01
    phi[5,4]  R1585     1.8250066041946411e+00
    phi[5,4]  R1586     2.3525445461273193e+00
    phi[5,4]  R1587     -1.6637399196624756e+00
    phi[5,4]  R1588     1.6145361661911011e+00
    phi[5,4]  R1589     1.8228259086608887e+00
    phi[5,4]  R1590     -3.1709613800048828e+00
    phi[5,4]  R1591     -1.9620960950851440e+00
    phi[5,4]  R1592     -2.4418601989746094e+00
    phi[5,4]  R1593     -1.7502965927124023e+00
    phi[5,4]  R1594     -2.3642110824584961e+00
    phi[5,4]  R1595     1.8210785090923309e-01
    phi[5,4]  R1596     -1.7012616395950317e+00
    phi[5,4]  R1597     -1.3297581672668457e+00
    phi[5,4]  R1598     -1.4885883331298828e+00
    phi[5,4]  R1599     -6.2500774860382080e-01
    phi[5,4]  R1600     -1.1465466022491455e+00
    phi[5,4]  R1601     -3.0107921361923218e-01
    phi[5,4]  R1602     -3.3391624689102173e-01
    phi[5,4]  R1603     -5.0472670793533325e-01
    phi[5,4]  R1604     -5.0474262237548828e-01
    phi[5,4]  R1605     -9.4780218601226807e-01
    phi[5,4]  R1606     -8.0716520547866821e-02
    phi[5,4]  R1607     8.9250475168228149e-01
    phi[5,4]  R1608     -8.1894034147262573e-01
    phi[5,4]  R1609     -8.7835514545440674e-01
    phi[5,4]  R1610     -1.4548428058624268e+00
    phi[5,4]  R1611     -1.1421382427215576e-01
    phi[5,4]  R1612     -0.00703435018658638
    phi[5,4]  R1613     -1.0831748247146606e+00
    phi[5,4]  R1614     -1.3969817161560059e+00
    phi[5,4]  R1615     1.0149409770965576e+00
    phi[5,4]  R1616     -2.08876633644104
    phi[5,4]  R1617     2.0022043585777283e-01
    phi[5,4]  R1618     8.3592301607131958e-01
    phi[5,4]  R1619     3.3752602338790894e-01
    phi[5,4]  R1620     -2.7087352275848389e+00
    phi[5,4]  R1621     -1.6288059949874878e-01
    phi[5,4]  R1622     -2.1067297458648682e+00
    phi[5,4]  R1623     7.2264093160629272e-01
    phi[5,4]  R1624     2.1823601722717285e+00
    phi[5,4]  R1625     0.365295946598053
    phi[5,4]  R1626     2.2231190204620361e+00
    phi[5,4]  R1627     1.8392943143844604e+00
    phi[5,4]  R1628     1.3159852027893066e+00
    phi[5,4]  R1629     2.2020010948181152e+00
    phi[5,9]  R45       1
    phi[5,9]  R46       1
    phi[5,9]  R81       -1
    phi[5,9]  R1630     -3.0999999046325684e+00
    phi[5,9]  R1631     -3.0999999046325684e+00
    phi[5,9]  R1632     -2.2400000095367432e+00
    phi[5,9]  R1633     -2.2400000095367432e+00
    phi[5,9]  R1634     -3.0999999046325684e+00
    phi[5,9]  R1635     -3.0999999046325684e+00
    phi[5,9]  R1636     -2.5699999332427979e+00
    phi[5,9]  R1637     -2.5699999332427979e+00
    phi[5,9]  R1638     -3.0999999046325684e+00
    phi[5,9]  R1639     -3.0999999046325684e+00
    phi[5,9]  R1640     -2.0899999141693115e+00
    phi[5,9]  R1641     -2.0899999141693115e+00
    phi[5,9]  R1642     -3.0999999046325684e+00
    phi[5,9]  R1643     -3.0999999046325684e+00
    phi[5,9]  R1644     1.4089076519012451e+00
    phi[5,9]  R1645     5.0157934427261353e-01
    phi[5,9]  R1646     0.856260359287262
    phi[5,9]  R1647     -1.7058482170104980e+00
    phi[5,9]  R1648     1.4688451290130615e+00
    phi[5,9]  R1649     1.9081563949584961e+00
    phi[5,9]  R1650     1.6497502326965332e+00
    phi[5,9]  R1651     -1.2351997941732407e-01
    phi[5,9]  R1652     9.9750292301177979e-01
    phi[5,9]  R1653     1.8146909475326538e+00
    phi[5,9]  R1654     -2.26825213432312
    phi[5,9]  R1655     -3.0364022254943848e+00
    phi[5,9]  R1656     -1.4993966817855835e+00
    phi[5,9]  R1657     -6.7183154821395874e-01
    phi[5,9]  R1658     -8.2764267921447754e-01
    phi[5,9]  R1659     -1.3072822988033295e-01
    phi[5,9]  R1660     -1.4210142195224762e-01
    phi[5,9]  R1661     -6.3594490289688110e-01
    phi[5,9]  R1662     -4.8353064060211182e-01
    phi[5,9]  R1663     1.5891817808151245e+00
    phi[5,9]  R1664     -1.4965319633483887e+00
    phi[5,9]  R1665     -4.5388080179691315e-02
    phi[5,9]  R1666     -1.1536408662796021e+00
    phi[5,9]  R1667     -1.0147856473922729e+00
    phi[5,9]  R1668     3.1286403536796570e-01
    phi[5,9]  R1669     1.1194306612014771e+00
    phi[5,9]  R1670     8.9113295078277588e-01
    phi[5,9]  R1671     4.8250004649162292e-02
    phi[5,9]  R1672     1.1917916536331177e+00
    phi[5,9]  R1673     2.3246276378631592e-01
    phi[5,9]  R1674     1.2838883399963379e+00
    phi[5,9]  R1675     1.9955589771270752e+00
    phi[5,9]  R1676     2.4638538360595703e+00
    phi[5,9]  R1677     2.8913104534149170e+00
    phi[5,9]  R1678     2.9838672280311584e-01
    phi[5,9]  R1679     2.1370922029018402e-01
    phi[5,9]  R1680     -2.2526422142982483e-01
    phi[5,9]  R1681     -1.6878713369369507e+00
    phi[5,9]  R1682     -1.9175196886062622e+00
    phi[5,9]  R1683     8.3669376373291016e-01
    phi[5,9]  R1684     4.1067838668823242e-01
    phi[5,9]  R1685     -1.8640686571598053e-01
    phi[5,9]  R1686     -2.4801020622253418e+00
    phi[5,9]  R1687     -3.0751810073852539e+00
    phi[5,9]  R1688     -2.3866758346557617e+00
    phi[5,9]  R1689     -1.5824452638626099e+00
    phi[5,9]  R1690     -1.9570163488388062e+00
    phi[5,9]  R1691     -2.8287987709045410e+00
    phi[5,9]  R1692     -1.3459985256195068e+00
    phi[5,9]  R1693     -2.7070415019989014e+00
    phi[5,9]  R1694     -1.3946158885955811e+00
    phi[5,9]  R1695     -2.8389842510223389e+00
    phi[5,9]  R1696     -3.2928414344787598e+00
    phi[5,9]  R1697     -2.5906293392181396e+00
    phi[5,9]  R1698     -2.7061665058135986e+00
    phi[9,5]  R45       -1
    phi[9,5]  R81       1
    phi[9,5]  R82       1
    phi[9,5]  R1699     -3.0999999046325684e+00
    phi[9,5]  R1700     -3.0999999046325684e+00
    phi[9,5]  R1701     -2.2400000095367432e+00
    phi[9,5]  R1702     -2.2400000095367432e+00
    phi[9,5]  R1703     -3.0999999046325684e+00
    phi[9,5]  R1704     -3.0999999046325684e+00
    phi[9,5]  R1705     -2.5699999332427979e+00
    phi[9,5]  R1706     -2.5699999332427979e+00
    phi[9,5]  R1707     -3.0999999046325684e+00
    phi[9,5]  R1708     -3.0999999046325684e+00
    phi[9,5]  R1709     -2.0899999141693115e+00
    phi[9,5]  R1710     -2.0899999141693115e+00
    phi[9,5]  R1711     -3.0999999046325684e+00
    phi[9,5]  R1712     -3.0999999046325684e+00
    phi[9,5]  R1713     1.2838883399963379e+00
    phi[9,5]  R1714     1.9955589771270752e+00
    phi[9,5]  R1715     2.4638538360595703e+00
    phi[9,5]  R1716     2.8913104534149170e+00
    phi[9,5]  R1717     2.9838672280311584e-01
    phi[9,5]  R1718     2.1370922029018402e-01
    phi[9,5]  R1719     -2.2526422142982483e-01
    phi[9,5]  R1720     -1.6878713369369507e+00
    phi[9,5]  R1721     -1.9175196886062622e+00
    phi[9,5]  R1722     8.3669376373291016e-01
    phi[9,5]  R1723     4.1067838668823242e-01
    phi[9,5]  R1724     -1.8640686571598053e-01
    phi[9,5]  R1725     -2.4801020622253418e+00
    phi[9,5]  R1726     -3.0751810073852539e+00
    phi[9,5]  R1727     -2.3866758346557617e+00
    phi[9,5]  R1728     -1.5824452638626099e+00
    phi[9,5]  R1729     -1.9570163488388062e+00
    phi[9,5]  R1730     -2.8287987709045410e+00
    phi[9,5]  R1731     -1.3459985256195068e+00
    phi[9,5]  R1732     -2.7070415019989014e+00
    phi[9,5]  R1733     -1.3946158885955811e+00
    phi[9,5]  R1734     -2.8389842510223389e+00
    phi[9,5]  R1735     -3.2928414344787598e+00
    phi[9,5]  R1736     -2.5906293392181396e+00
    phi[9,5]  R1737     -2.7061665058135986e+00
    phi[9,5]  R1738     1.4089076519012451e+00
    phi[9,5]  R1739     5.0157934427261353e-01
    phi[9,5]  R1740     0.856260359287262
    phi[9,5]  R1741     -1.7058482170104980e+00
    phi[9,5]  R1742     1.4688451290130615e+00
    phi[9,5]  R1743     1.9081563949584961e+00
    phi[9,5]  R1744     1.6497502326965332e+00
    phi[9,5]  R1745     -1.2351997941732407e-01
    phi[9,5]  R1746     9.9750292301177979e-01
    phi[9,5]  R1747     1.8146909475326538e+00
    phi[9,5]  R1748     -2.26825213432312
    phi[9,5]  R1749     -3.0364022254943848e+00
    phi[9,5]  R1750     -1.4993966817855835e+00
    phi[9,5]  R1751     -6.7183154821395874e-01
    phi[9,5]  R1752     -8.2764267921447754e-01
    phi[9,5]  R1753     -1.3072822988033295e-01
    phi[9,5]  R1754     -1.4210142195224762e-01
    phi[9,5]  R1755     -6.3594490289688110e-01
    phi[9,5]  R1756     -4.8353064060211182e-01
    phi[9,5]  R1757     1.5891817808151245e+00
    phi[9,5]  R1758     -1.4965319633483887e+00
    phi[9,5]  R1759     -4.5388080179691315e-02
    phi[9,5]  R1760     -1.1536408662796021e+00
    phi[9,5]  R1761     -1.0147856473922729e+00
    phi[9,5]  R1762     3.1286403536796570e-01
    phi[9,5]  R1763     1.1194306612014771e+00
    phi[9,5]  R1764     8.9113295078277588e-01
    phi[9,5]  R1765     4.8250004649162292e-02
    phi[9,5]  R1766     1.1917916536331177e+00
    phi[9,5]  R1767     2.3246276378631592e-01
    phi[5,11]  R45       1
    phi[5,11]  R46       1
    phi[5,11]  R47       3.0859786346867457e-01
    phi[5,11]  R48       -1.3267881320084234e+00
    phi[5,11]  R49       1.5193867570988120e+00
    phi[5,11]  R50       -3.2639590037716371e-01
    phi[5,11]  R51       1.5392165380217271e+00
    phi[5,11]  R52       -1.6226623347846192e+00
    phi[5,11]  R53       1.3995949929412517e+00
    phi[5,11]  R91       -1
    phi[5,11]  R1768     -2.7914020411638938e+00
    phi[5,11]  R1769     -3.4085977681012429e+00
    phi[5,11]  R1770     -3.5667881415451665e+00
    phi[5,11]  R1771     -9.1321187752831978e-01
    phi[5,11]  R1772     -1.5806131475337564e+00
    phi[5,11]  R1773     -4.61938666173138
    phi[5,11]  R1774     -2.8963958336199616e+00
    phi[5,11]  R1775     -2.2436040328656341e+00
    phi[5,11]  R1776     -1.5607833666108413e+00
    phi[5,11]  R1777     -4.6392164426542957e+00
    phi[5,11]  R1778     -3.7126622489539307e+00
    phi[5,11]  R1779     -4.6733757938469234e-01
    phi[5,11]  R1780     -1.7004049116913167e+00
    phi[5,11]  R1781     -4.49959489757382
    phi[5,11]  R1782     -2.4053825509499638e-01
    phi[5,11]  R1783     -4.5857871613615986e-02
    phi[5,11]  R1784     -6.5753309524060555e-01
    phi[5,11]  R1785     -1.0176190546814041e+00
    phi[5,11]  R1786     -4.9938841366813014e-01
    phi[5,11]  R1787     -4.7923691305776561e-02
    phi[5,11]  R1788     -4.9815080180571236e-02
    phi[5,11]  R1789     -5.8539670735634708e-02
    phi[5,11]  R1790     -5.8856097977276312e-02
    phi[5,11]  R1791     -7.0676348046598214e-01
    phi[5,11]  R1792     -4.6310731365102087e-01
    phi[5,11]  R1793     -2.1362438361278713e-02
    phi[5,11]  R1794     -6.0993541261459061e-02
    phi[5,11]  R1795     -3.5838620084418588e-01
    phi[5,11]  R1796     -7.1978998047661280e-02
    phi[5,11]  R1797     -1.0021839986611897e-01
    phi[5,11]  R1798     -1.1542893198418724e-01
    phi[5,11]  R1799     -1.2877505529867916e-01
    phi[5,11]  R1800     -1.6746621703726927e-01
    phi[5,11]  R1801     -1.9160646979768625e-01
    phi[5,11]  R1802     -0.763766841708778
    phi[5,11]  R1803     -1.4288804351774931e-02
    phi[5,11]  R1804     -2.5656834397033590e-02
    phi[5,11]  R1805     -2.6423781260698775e-02
    phi[5,11]  R1806     -0.0664141496367992
    phi[5,11]  R1807     -1.0087588311024098e-01
    phi[5,11]  R1808     -1.0702681010512483e-01
    phi[5,11]  R1809     -1.0904477476307697e-01
    phi[5,11]  R1810     -1.2287628971174880e-01
    phi[5,11]  R1811     -1.3704821237210585e-01
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R1812     -3.0999999046325684e+00
    phi[6,7]  R1813     -3.0999999046325684e+00
    phi[6,7]  R1814     -2.2400000095367432e+00
    phi[6,7]  R1815     -2.2400000095367432e+00
    phi[6,7]  R1816     -3.0999999046325684e+00
    phi[6,7]  R1817     -3.0999999046325684e+00
    phi[6,7]  R1818     -2.5699999332427979e+00
    phi[6,7]  R1819     -2.5699999332427979e+00
    phi[6,7]  R1820     -3.0999999046325684e+00
    phi[6,7]  R1821     -3.0999999046325684e+00
    phi[6,7]  R1822     -2.0899999141693115e+00
    phi[6,7]  R1823     -2.0899999141693115e+00
    phi[6,7]  R1824     -3.0999999046325684e+00
    phi[6,7]  R1825     -3.0999999046325684e+00
    phi[6,7]  R1826     3.7983101606369019e-01
    phi[6,7]  R1827     -3.0747294425964355e-01
    phi[6,7]  R1828     6.5695822238922119e-01
    phi[6,7]  R1829     1.1710835695266724e+00
    phi[6,7]  R1830     -1.1038111448287964e+00
    phi[6,7]  R1831     -1.1836371421813965e+00
    phi[6,7]  R1832     0.763956606388092
    phi[6,7]  R1833     -9.4967238605022430e-02
    phi[6,7]  R1834     -7.8172397613525391e-01
    phi[6,7]  R1835     1.6476583480834961e-01
    phi[6,7]  R1836     -1.1412296295166016e+00
    phi[6,7]  R1837     -1.0948590040206909e+00
    phi[6,7]  R1838     -1.3350919485092163e+00
    phi[6,7]  R1839     -1.3391478061676025e+00
    phi[6,7]  R1840     -1.3376376628875732e+00
    phi[6,7]  R1841     -9.2074757814407349e-01
    phi[6,7]  R1842     -1.0352207422256470e+00
    phi[6,7]  R1843     -2.4766404926776886e-01
    phi[6,7]  R1844     -1.4737188816070557e+00
    phi[6,7]  R1845     -1.4579967260360718e+00
    phi[6,7]  R1846     -5.6584900617599487e-01
    phi[6,7]  R1847     7.6322577893733978e-02
    phi[6,7]  R1848     2.2841393947601318e-01
    phi[6,7]  R1849     -3.4058177471160889e-01
    phi[6,7]  R1850     -9.9476790428161621e-01
    phi[6,7]  R1851     1.6030801832675934e-01
    phi[6,7]  R1852     -2.8927816078066826e-02
    phi[6,7]  R1853     -3.3171486854553223e-01
    phi[6,7]  R1854     -1.1878687143325806e+00
    phi[6,7]  R1855     -9.7641396522521973e-01
    phi[6,7]  R1856     -5.2197760343551636e-01
    phi[6,7]  R1857     -3.8505084812641144e-02
    phi[6,7]  R1858     -6.9030916690826416e-01
    phi[6,7]  R1859     2.0333202183246613e-01
    phi[6,7]  R1860     9.5211789011955261e-02
    phi[6,7]  R1861     -7.2704887390136719e-01
    phi[6,7]  R1862     6.1675316095352173e-01
    phi[6,7]  R1863     -1.7321071028709412e-01
    phi[6,7]  R1864     -8.3599549531936646e-01
    phi[6,7]  R1865     4.0012747049331665e-01
    phi[6,7]  R1866     5.6198436021804810e-01
    phi[6,7]  R1867     -8.2427644729614258e-01
    phi[6,7]  R1868     -3.2499530911445618e-01
    phi[6,7]  R1869     -2.6353514194488525e-01
    phi[6,7]  R1870     9.3139922618865967e-01
    phi[6,7]  R1871     3.5948014259338379e-01
    phi[6,7]  R1872     -0.955192506313324
    phi[6,7]  R1873     -0.307110071182251
    phi[6,7]  R1874     5.0707712769508362e-02
    phi[6,7]  R1875     -7.5300693511962891e-01
    phi[6,7]  R1876     3.0359643697738647e-01
    phi[6,7]  R1877     1.6924470663070679e-01
    phi[6,7]  R1878     2.8592443466186523e-01
    phi[6,7]  R1879     -2.6396626234054565e-01
    phi[6,7]  R1880     -2.4929363727569580e+00
    phi[6,7]  R1881     -6.5929234027862549e-02
    phi[6,7]  R1882     9.9114489555358887e-01
    phi[6,7]  R1883     -6.0865050554275513e-01
    phi[6,7]  R1884     4.9015176296234131e-01
    phi[6,7]  R1885     -5.9932100772857666e-01
    phi[6,7]  R1886     -1.3739583492279053e+00
    phi[6,7]  R1887     -2.1892635822296143e+00
    phi[6,7]  R1888     -1.9274233579635620e+00
    phi[6,7]  R1889     -1.2248547077178955e+00
    phi[6,7]  R1890     -1.2862651348114014e+00
    phi[6,7]  R1891     -1.5805560350418091e+00
    phi[6,7]  R1892     -2.3422415256500244e+00
    phi[6,7]  R1893     -0.31435427069664
    phi[6,7]  R1894     -4.0504133701324463e-01
    phi[6,7]  R1895     -8.2430303096771240e-01
    phi[6,7]  R1896     -7.7555274963378906e-01
    phi[6,7]  R1897     -1.8867025375366211e+00
    phi[6,7]  R1898     -1.1800177097320557e+00
    phi[6,7]  R1899     -1.4688655138015747e+00
    phi[6,7]  R1900     -1.7244472503662109e+00
    phi[6,7]  R1901     -2.2192187309265137e+00
    phi[6,7]  R1902     -3.0467216968536377e+00
    phi[6,7]  R1903     -1.4497781991958618e+00
    phi[6,7]  R1904     -2.2772746086120605e+00
    phi[6,7]  R1905     -2.1594746112823486e+00
    phi[6,7]  R1906     -1.1020239591598511e+00
    phi[6,7]  R1907     -1.9125962257385254e+00
    phi[6,7]  R1908     -2.3267960548400879e+00
    phi[6,7]  R1909     -1.6860114336013794e+00
    phi[6,7]  R1910     -2.0324714183807373e+00
    phi[6,7]  R1911     -2.7791550159454346e+00
    phi[6,7]  R1912     -2.0850756168365479e+00
    phi[6,7]  R1913     -1.4509686231613159e+00
    phi[6,7]  R1914     -8.0248057842254639e-01
    phi[6,7]  R1915     -2.7869641780853271e+00
    phi[6,7]  R1916     -2.7643742561340332e+00
    phi[6,7]  R1917     -1.3069069385528564e+00
    phi[6,7]  R1918     -2.0885956287384033e+00
    phi[6,7]  R1919     -1.6555836200714111e+00
    phi[6,7]  R1920     -1.7919402122497559e+00
    phi[6,7]  R1921     -6.3498944044113159e-01
    phi[6,7]  R1922     -7.3582255840301514e-01
    phi[6,7]  R1923     -3.9465361833572388e-01
    phi[6,7]  R1924     -3.3760879039764404e+00
    phi[6,7]  R1925     -6.0313361883163452e-01
    phi[6,7]  R1926     4.1627940535545349e-01
    phi[6,7]  R1927     -2.6833035945892334e+00
    phi[6,7]  R1928     -1.0759689807891846e+00
    phi[6,7]  R1929     -2.1541502475738525e+00
    phi[6,7]  R1930     -2.3699092864990234e+00
    phi[6,7]  R1931     -7.4833959341049194e-01
    phi[6,7]  R1932     -1.3880273103713989e+00
    phi[6,7]  R1933     -2.0127103328704834e+00
    phi[6,7]  R1934     -1.7158116102218628e+00
    phi[6,7]  R1935     -1.84722101688385
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R1936     -3.0999999046325684e+00
    phi[7,6]  R1937     -3.0999999046325684e+00
    phi[7,6]  R1938     -2.2400000095367432e+00
    phi[7,6]  R1939     -2.2400000095367432e+00
    phi[7,6]  R1940     -3.0999999046325684e+00
    phi[7,6]  R1941     -3.0999999046325684e+00
    phi[7,6]  R1942     -2.5699999332427979e+00
    phi[7,6]  R1943     -2.5699999332427979e+00
    phi[7,6]  R1944     -3.0999999046325684e+00
    phi[7,6]  R1945     -3.0999999046325684e+00
    phi[7,6]  R1946     -2.0899999141693115e+00
    phi[7,6]  R1947     -2.0899999141693115e+00
    phi[7,6]  R1948     -3.0999999046325684e+00
    phi[7,6]  R1949     -3.0999999046325684e+00
    phi[7,6]  R1950     5.6198436021804810e-01
    phi[7,6]  R1951     -8.2427644729614258e-01
    phi[7,6]  R1952     -3.2499530911445618e-01
    phi[7,6]  R1953     -2.6353514194488525e-01
    phi[7,6]  R1954     9.3139922618865967e-01
    phi[7,6]  R1955     3.5948014259338379e-01
    phi[7,6]  R1956     -0.955192506313324
    phi[7,6]  R1957     -0.307110071182251
    phi[7,6]  R1958     5.0707712769508362e-02
    phi[7,6]  R1959     -7.5300693511962891e-01
    phi[7,6]  R1960     3.0359643697738647e-01
    phi[7,6]  R1961     1.6924470663070679e-01
    phi[7,6]  R1962     2.8592443466186523e-01
    phi[7,6]  R1963     -2.6396626234054565e-01
    phi[7,6]  R1964     -2.4929363727569580e+00
    phi[7,6]  R1965     -6.5929234027862549e-02
    phi[7,6]  R1966     9.9114489555358887e-01
    phi[7,6]  R1967     -6.0865050554275513e-01
    phi[7,6]  R1968     4.9015176296234131e-01
    phi[7,6]  R1969     -5.9932100772857666e-01
    phi[7,6]  R1970     -1.3739583492279053e+00
    phi[7,6]  R1971     -2.1892635822296143e+00
    phi[7,6]  R1972     -1.9274233579635620e+00
    phi[7,6]  R1973     -1.2248547077178955e+00
    phi[7,6]  R1974     -1.2862651348114014e+00
    phi[7,6]  R1975     -1.5805560350418091e+00
    phi[7,6]  R1976     -2.3422415256500244e+00
    phi[7,6]  R1977     -0.31435427069664
    phi[7,6]  R1978     -4.0504133701324463e-01
    phi[7,6]  R1979     -8.2430303096771240e-01
    phi[7,6]  R1980     -7.7555274963378906e-01
    phi[7,6]  R1981     -1.8867025375366211e+00
    phi[7,6]  R1982     -1.1800177097320557e+00
    phi[7,6]  R1983     -1.4688655138015747e+00
    phi[7,6]  R1984     -1.7244472503662109e+00
    phi[7,6]  R1985     -2.2192187309265137e+00
    phi[7,6]  R1986     -3.0467216968536377e+00
    phi[7,6]  R1987     -1.4497781991958618e+00
    phi[7,6]  R1988     -2.2772746086120605e+00
    phi[7,6]  R1989     -2.1594746112823486e+00
    phi[7,6]  R1990     -1.1020239591598511e+00
    phi[7,6]  R1991     -1.9125962257385254e+00
    phi[7,6]  R1992     -2.3267960548400879e+00
    phi[7,6]  R1993     -1.6860114336013794e+00
    phi[7,6]  R1994     -2.0324714183807373e+00
    phi[7,6]  R1995     -2.7791550159454346e+00
    phi[7,6]  R1996     -2.0850756168365479e+00
    phi[7,6]  R1997     -1.4509686231613159e+00
    phi[7,6]  R1998     -8.0248057842254639e-01
    phi[7,6]  R1999     -2.7869641780853271e+00
    phi[7,6]  R2000     -2.7643742561340332e+00
    phi[7,6]  R2001     -1.3069069385528564e+00
    phi[7,6]  R2002     -2.0885956287384033e+00
    phi[7,6]  R2003     -1.6555836200714111e+00
    phi[7,6]  R2004     -1.7919402122497559e+00
    phi[7,6]  R2005     -6.3498944044113159e-01
    phi[7,6]  R2006     -7.3582255840301514e-01
    phi[7,6]  R2007     -3.9465361833572388e-01
    phi[7,6]  R2008     -3.3760879039764404e+00
    phi[7,6]  R2009     -6.0313361883163452e-01
    phi[7,6]  R2010     4.1627940535545349e-01
    phi[7,6]  R2011     -2.6833035945892334e+00
    phi[7,6]  R2012     -1.0759689807891846e+00
    phi[7,6]  R2013     -2.1541502475738525e+00
    phi[7,6]  R2014     -2.3699092864990234e+00
    phi[7,6]  R2015     -7.4833959341049194e-01
    phi[7,6]  R2016     -1.3880273103713989e+00
    phi[7,6]  R2017     -2.0127103328704834e+00
    phi[7,6]  R2018     -1.7158116102218628e+00
    phi[7,6]  R2019     -1.84722101688385
    phi[7,6]  R2020     3.7983101606369019e-01
    phi[7,6]  R2021     -3.0747294425964355e-01
    phi[7,6]  R2022     6.5695822238922119e-01
    phi[7,6]  R2023     1.1710835695266724e+00
    phi[7,6]  R2024     -1.1038111448287964e+00
    phi[7,6]  R2025     -1.1836371421813965e+00
    phi[7,6]  R2026     0.763956606388092
    phi[7,6]  R2027     -9.4967238605022430e-02
    phi[7,6]  R2028     -7.8172397613525391e-01
    phi[7,6]  R2029     1.6476583480834961e-01
    phi[7,6]  R2030     -1.1412296295166016e+00
    phi[7,6]  R2031     -1.0948590040206909e+00
    phi[7,6]  R2032     -1.3350919485092163e+00
    phi[7,6]  R2033     -1.3391478061676025e+00
    phi[7,6]  R2034     -1.3376376628875732e+00
    phi[7,6]  R2035     -9.2074757814407349e-01
    phi[7,6]  R2036     -1.0352207422256470e+00
    phi[7,6]  R2037     -2.4766404926776886e-01
    phi[7,6]  R2038     -1.4737188816070557e+00
    phi[7,6]  R2039     -1.4579967260360718e+00
    phi[7,6]  R2040     -5.6584900617599487e-01
    phi[7,6]  R2041     7.6322577893733978e-02
    phi[7,6]  R2042     2.2841393947601318e-01
    phi[7,6]  R2043     -3.4058177471160889e-01
    phi[7,6]  R2044     -9.9476790428161621e-01
    phi[7,6]  R2045     1.6030801832675934e-01
    phi[7,6]  R2046     -2.8927816078066826e-02
    phi[7,6]  R2047     -3.3171486854553223e-01
    phi[7,6]  R2048     -1.1878687143325806e+00
    phi[7,6]  R2049     -9.7641396522521973e-01
    phi[7,6]  R2050     -5.2197760343551636e-01
    phi[7,6]  R2051     -3.8505084812641144e-02
    phi[7,6]  R2052     -6.9030916690826416e-01
    phi[7,6]  R2053     2.0333202183246613e-01
    phi[7,6]  R2054     9.5211789011955261e-02
    phi[7,6]  R2055     -7.2704887390136719e-01
    phi[7,6]  R2056     6.1675316095352173e-01
    phi[7,6]  R2057     -1.7321071028709412e-01
    phi[7,6]  R2058     -8.3599549531936646e-01
    phi[7,6]  R2059     4.0012747049331665e-01
    phi[10,6]  R54       -1
    phi[10,6]  R56       -1.3662186085443053e+00
    phi[10,6]  R57       1.7399764913263560e-02
    phi[10,6]  R58       -6.4662269535883610e-01
    phi[10,6]  R59       -1.4391404286847327e+00
    phi[10,6]  R60       7.1012939330827551e-01
    phi[10,6]  R61       3.6219531726647070e-01
    phi[10,6]  R62       2.0850263072532003e+00
    phi[10,6]  R90       1
    phi[10,6]  R2060     -1.7337812960882630e+00
    phi[10,6]  R2061     -4.4662185131768739e+00
    phi[10,6]  R2062     -2.2573997744500067e+00
    phi[10,6]  R2063     -2.2226002446234796e+00
    phi[10,6]  R2064     -2.4533772092737323e+00
    phi[10,6]  R2065     -3.7466225999914045e+00
    phi[10,6]  R2066     -1.1308595045580652e+00
    phi[10,6]  R2067     -4.00914036192753
    phi[10,6]  R2068     -3.8101292979408439e+00
    phi[10,6]  R2069     -2.3898705113242928e+00
    phi[10,6]  R2070     -2.4521952314357822e+00
    phi[10,6]  R2071     -1.7278045969028408e+00
    phi[10,6]  R2072     -5.1850262118857682e+00
    phi[10,6]  R2073     -1.0149735973793681e+00
    phi[10,6]  R2074     -6.4509681267509666e-02
    phi[10,6]  R2075     -4.1366366656638537e-01
    phi[10,6]  R2076     -5.8626654754343810e-01
    phi[10,6]  R2077     -8.6408932313750242e-02
    phi[10,6]  R2078     -8.6744603551154320e-02
    phi[10,6]  R2079     -5.5895717430695846e-01
    phi[10,6]  R2080     -5.5076228643763669e-01
    phi[10,6]  R2081     -5.0402327499018384e-01
    phi[10,6]  R2082     -7.1563869587750473e-01
    phi[10,6]  R2083     -0.0947626470767452
    phi[10,6]  R2084     -3.7548174589811767e-01
    phi[10,6]  R2085     -3.8098100698260229e-01
    phi[10,6]  R2086     -3.8601662976891105e-01
    phi[10,6]  R2087     -3.9382749656539684e-01
    phi[10,6]  R2088     -3.9426019941989376e-01
    phi[10,6]  R2089     -3.9821422668505557e-01
    phi[10,6]  R2090     -3.9865033327054955e-01
    phi[10,6]  R2091     -4.0103336524785455e-01
    phi[10,6]  R2092     -4.0121395451724284e-01
    phi[10,6]  R2093     -4.0125593928459424e-01
    phi[10,6]  R2094     -3.9540350281497127e-01
    phi[10,6]  R2095     -4.1223012464664632e-01
    phi[10,6]  R2096     -4.1633766825792451e-01
    phi[10,6]  R2097     -4.4013735440988688e-01
    phi[10,6]  R2098     -4.4667721239631508e-01
    phi[10,6]  R2099     -4.5266139182965559e-01
    phi[10,6]  R2100     -4.5520267382877078e-01
    phi[10,6]  R2101     -4.5996543642846455e-01
    phi[10,6]  R2102     -4.6140332859381128e-01
    phi[10,6]  R2103     -4.7617476493690924e-01
    phi[10,6]  R2104     -4.4466041524365452e-01
    phi[10,6]  R2105     -4.5219215477353875e-01
    phi[10,6]  R2106     -4.6357937924999726e-01
    phi[10,6]  R2107     -4.7237076284846491e-01
    phi[10,6]  R2108     -4.7340938277920297e-01
    phi[10,6]  R2109     -4.7593546274488890e-01
    phi[10,6]  R2110     -4.7649441572134243e-01
    phi[10,6]  R2111     -5.1001801185005879e-01
    phi[10,6]  R2112     -5.3949991386972485e-01
    phi[10,6]  R2113     -5.4663280484616861e-01
    phi[7,8]  R63       1
    phi[7,8]  R64       1
    phi[7,8]  R72       -1
    phi[7,8]  R2114     -3.0999999046325684e+00
    phi[7,8]  R2115     -3.0999999046325684e+00
    phi[7,8]  R2116     -2.2400000095367432e+00
    phi[7,8]  R2117     -2.2400000095367432e+00
    phi[7,8]  R2118     -3.0999999046325684e+00
    phi[7,8]  R2119     -3.0999999046325684e+00
    phi[7,8]  R2120     -2.5699999332427979e+00
    phi[7,8]  R2121     -2.5699999332427979e+00
    phi[7,8]  R2122     -3.0999999046325684e+00
    phi[7,8]  R2123     -3.0999999046325684e+00
    phi[7,8]  R2124     -2.0899999141693115e+00
    phi[7,8]  R2125     -2.0899999141693115e+00
    phi[7,8]  R2126     -3.0999999046325684e+00
    phi[7,8]  R2127     -3.0999999046325684e+00
    phi[7,8]  R2128     5.6198436021804810e-01
    phi[7,8]  R2129     -8.2427644729614258e-01
    phi[7,8]  R2130     -3.2499530911445618e-01
    phi[7,8]  R2131     -2.6353514194488525e-01
    phi[7,8]  R2132     9.3139922618865967e-01
    phi[7,8]  R2133     3.5948014259338379e-01
    phi[7,8]  R2134     -0.955192506313324
    phi[7,8]  R2135     -0.307110071182251
    phi[7,8]  R2136     5.0707712769508362e-02
    phi[7,8]  R2137     -7.5300693511962891e-01
    phi[7,8]  R2138     3.0359643697738647e-01
    phi[7,8]  R2139     1.6924470663070679e-01
    phi[7,8]  R2140     2.8592443466186523e-01
    phi[7,8]  R2141     -2.6396626234054565e-01
    phi[7,8]  R2142     -2.4929363727569580e+00
    phi[7,8]  R2143     -6.5929234027862549e-02
    phi[7,8]  R2144     9.9114489555358887e-01
    phi[7,8]  R2145     -6.0865050554275513e-01
    phi[7,8]  R2146     4.9015176296234131e-01
    phi[7,8]  R2147     -5.9932100772857666e-01
    phi[7,8]  R2148     -1.3739583492279053e+00
    phi[7,8]  R2149     -2.1892635822296143e+00
    phi[7,8]  R2150     -1.9274233579635620e+00
    phi[7,8]  R2151     -1.2248547077178955e+00
    phi[7,8]  R2152     -1.2862651348114014e+00
    phi[7,8]  R2153     -1.5805560350418091e+00
    phi[7,8]  R2154     -2.3422415256500244e+00
    phi[7,8]  R2155     -0.31435427069664
    phi[7,8]  R2156     -4.0504133701324463e-01
    phi[7,8]  R2157     -8.2430303096771240e-01
    phi[7,8]  R2158     -7.7555274963378906e-01
    phi[7,8]  R2159     -1.8867025375366211e+00
    phi[7,8]  R2160     -1.1800177097320557e+00
    phi[7,8]  R2161     -1.4688655138015747e+00
    phi[7,8]  R2162     -1.7244472503662109e+00
    phi[7,8]  R2163     -2.2192187309265137e+00
    phi[7,8]  R2164     -3.0467216968536377e+00
    phi[7,8]  R2165     -1.4497781991958618e+00
    phi[7,8]  R2166     -2.2772746086120605e+00
    phi[7,8]  R2167     -2.1594746112823486e+00
    phi[7,8]  R2168     -1.1020239591598511e+00
    phi[7,8]  R2169     -1.9125962257385254e+00
    phi[7,8]  R2170     -2.3267960548400879e+00
    phi[7,8]  R2171     -1.6860114336013794e+00
    phi[7,8]  R2172     -2.0324714183807373e+00
    phi[7,8]  R2173     -2.7791550159454346e+00
    phi[7,8]  R2174     -2.0850756168365479e+00
    phi[7,8]  R2175     -1.4509686231613159e+00
    phi[7,8]  R2176     -8.0248057842254639e-01
    phi[7,8]  R2177     -2.7869641780853271e+00
    phi[7,8]  R2178     -2.7643742561340332e+00
    phi[7,8]  R2179     -1.3069069385528564e+00
    phi[7,8]  R2180     -2.0885956287384033e+00
    phi[7,8]  R2181     -1.6555836200714111e+00
    phi[7,8]  R2182     -1.7919402122497559e+00
    phi[7,8]  R2183     -6.3498944044113159e-01
    phi[7,8]  R2184     -7.3582255840301514e-01
    phi[7,8]  R2185     -3.9465361833572388e-01
    phi[7,8]  R2186     -3.3760879039764404e+00
    phi[7,8]  R2187     -6.0313361883163452e-01
    phi[7,8]  R2188     4.1627940535545349e-01
    phi[7,8]  R2189     -2.6833035945892334e+00
    phi[7,8]  R2190     -1.0759689807891846e+00
    phi[7,8]  R2191     -2.1541502475738525e+00
    phi[7,8]  R2192     -2.3699092864990234e+00
    phi[7,8]  R2193     -7.4833959341049194e-01
    phi[7,8]  R2194     -1.3880273103713989e+00
    phi[7,8]  R2195     -2.0127103328704834e+00
    phi[7,8]  R2196     -1.7158116102218628e+00
    phi[7,8]  R2197     -1.84722101688385
    phi[7,8]  R2198     2.7243900299072266e-01
    phi[7,8]  R2199     -5.5937863886356354e-02
    phi[7,8]  R2200     1.6453427076339722e+00
    phi[7,8]  R2201     -2.0913331508636475e+00
    phi[7,8]  R2202     -1.3725587129592896e+00
    phi[7,8]  R2203     2.1612703800201416e+00
    phi[7,8]  R2204     1.5832393169403076e+00
    phi[7,8]  R2205     1.4197872877120972e+00
    phi[7,8]  R2206     2.3048961162567139e-01
    phi[7,8]  R2207     7.8916825354099274e-02
    phi[7,8]  R2208     -2.6615955829620361e+00
    phi[7,8]  R2209     -1.9303780794143677e+00
    phi[7,8]  R2210     -1.2191613912582397e+00
    phi[7,8]  R2211     -2.5879750251770020e+00
    phi[7,8]  R2212     -2.7915666103363037e+00
    phi[7,8]  R2213     -2.8125281333923340e+00
    phi[7,8]  R2214     -1.7662169933319092e+00
    phi[7,8]  R2215     -2.6342775821685791e+00
    phi[7,8]  R2216     -7.2237354516983032e-01
    phi[7,8]  R2217     -1.5237890481948853e+00
    phi[7,8]  R2218     -1.1457449197769165e+00
    phi[7,8]  R2219     -1.3899503946304321e+00
    phi[7,8]  R2220     0.542015790939331
    phi[7,8]  R2221     1.6061511635780334e-01
    phi[7,8]  R2222     -1.4101532697677612e+00
    phi[7,8]  R2223     -1.5393307805061340e-01
    phi[7,8]  R2224     -2.0948023796081543e+00
    phi[7,8]  R2225     -2.3981873989105225e+00
    phi[7,8]  R2226     -9.9057137966156006e-01
    phi[7,8]  R2227     -1.3538525104522705e+00
    phi[7,8]  R2228     -1.9237126111984253e+00
    phi[7,8]  R2229     -1.47964608669281
    phi[7,8]  R2230     -0.720046877861023
    phi[7,8]  R2231     9.5154517889022827e-01
    phi[7,8]  R2232     -1.1573683470487595e-01
    phi[7,8]  R2233     -1.3346241712570190e+00
    phi[7,8]  R2234     -1.1719300746917725e+00
    phi[7,8]  R2235     -1.2868382930755615e+00
    phi[7,8]  R2236     -1.1167380809783936e+00
    phi[7,8]  R2237     -1.4271928071975708e+00
    phi[7,8]  R2238     -2.7385556697845459e+00
    phi[7,8]  R2239     -2.61669921875
    phi[7,8]  R2240     -3.0045044422149658e+00
    phi[7,8]  R2241     -1.7381310462951660e+00
    phi[7,8]  R2242     -8.0370485782623291e-01
    phi[7,8]  R2243     -5.9897100925445557e-01
    phi[7,8]  R2244     -1.7093245983123779e+00
    phi[7,8]  R2245     -1.8240536451339722e+00
    phi[7,8]  R2246     -1.5236327648162842e+00
    phi[7,8]  R2247     -1.3653445243835449e+00
    phi[8,7]  R63       -1
    phi[8,7]  R72       1
    phi[8,7]  R73       1
    phi[8,7]  R2248     -3.0999999046325684e+00
    phi[8,7]  R2249     -3.0999999046325684e+00
    phi[8,7]  R2250     -2.2400000095367432e+00
    phi[8,7]  R2251     -2.2400000095367432e+00
    phi[8,7]  R2252     -3.0999999046325684e+00
    phi[8,7]  R2253     -3.0999999046325684e+00
    phi[8,7]  R2254     -2.5699999332427979e+00
    phi[8,7]  R2255     -2.5699999332427979e+00
    phi[8,7]  R2256     -3.0999999046325684e+00
    phi[8,7]  R2257     -3.0999999046325684e+00
    phi[8,7]  R2258     -2.0899999141693115e+00
    phi[8,7]  R2259     -2.0899999141693115e+00
    phi[8,7]  R2260     -3.0999999046325684e+00
    phi[8,7]  R2261     -3.0999999046325684e+00
    phi[8,7]  R2262     2.7243900299072266e-01
    phi[8,7]  R2263     -5.5937863886356354e-02
    phi[8,7]  R2264     1.6453427076339722e+00
    phi[8,7]  R2265     -2.0913331508636475e+00
    phi[8,7]  R2266     -1.3725587129592896e+00
    phi[8,7]  R2267     2.1612703800201416e+00
    phi[8,7]  R2268     1.5832393169403076e+00
    phi[8,7]  R2269     1.4197872877120972e+00
    phi[8,7]  R2270     2.3048961162567139e-01
    phi[8,7]  R2271     7.8916825354099274e-02
    phi[8,7]  R2272     -2.6615955829620361e+00
    phi[8,7]  R2273     -1.9303780794143677e+00
    phi[8,7]  R2274     -1.2191613912582397e+00
    phi[8,7]  R2275     -2.5879750251770020e+00
    phi[8,7]  R2276     -2.7915666103363037e+00
    phi[8,7]  R2277     -2.8125281333923340e+00
    phi[8,7]  R2278     -1.7662169933319092e+00
    phi[8,7]  R2279     -2.6342775821685791e+00
    phi[8,7]  R2280     -7.2237354516983032e-01
    phi[8,7]  R2281     -1.5237890481948853e+00
    phi[8,7]  R2282     -1.1457449197769165e+00
    phi[8,7]  R2283     -1.3899503946304321e+00
    phi[8,7]  R2284     0.542015790939331
    phi[8,7]  R2285     1.6061511635780334e-01
    phi[8,7]  R2286     -1.4101532697677612e+00
    phi[8,7]  R2287     -1.5393307805061340e-01
    phi[8,7]  R2288     -2.0948023796081543e+00
    phi[8,7]  R2289     -2.3981873989105225e+00
    phi[8,7]  R2290     -9.9057137966156006e-01
    phi[8,7]  R2291     -1.3538525104522705e+00
    phi[8,7]  R2292     -1.9237126111984253e+00
    phi[8,7]  R2293     -1.47964608669281
    phi[8,7]  R2294     -0.720046877861023
    phi[8,7]  R2295     9.5154517889022827e-01
    phi[8,7]  R2296     -1.1573683470487595e-01
    phi[8,7]  R2297     -1.3346241712570190e+00
    phi[8,7]  R2298     -1.1719300746917725e+00
    phi[8,7]  R2299     -1.2868382930755615e+00
    phi[8,7]  R2300     -1.1167380809783936e+00
    phi[8,7]  R2301     -1.4271928071975708e+00
    phi[8,7]  R2302     -2.7385556697845459e+00
    phi[8,7]  R2303     -2.61669921875
    phi[8,7]  R2304     -3.0045044422149658e+00
    phi[8,7]  R2305     -1.7381310462951660e+00
    phi[8,7]  R2306     -8.0370485782623291e-01
    phi[8,7]  R2307     -5.9897100925445557e-01
    phi[8,7]  R2308     -1.7093245983123779e+00
    phi[8,7]  R2309     -1.8240536451339722e+00
    phi[8,7]  R2310     -1.5236327648162842e+00
    phi[8,7]  R2311     -1.3653445243835449e+00
    phi[8,7]  R2312     5.6198436021804810e-01
    phi[8,7]  R2313     -8.2427644729614258e-01
    phi[8,7]  R2314     -3.2499530911445618e-01
    phi[8,7]  R2315     -2.6353514194488525e-01
    phi[8,7]  R2316     9.3139922618865967e-01
    phi[8,7]  R2317     3.5948014259338379e-01
    phi[8,7]  R2318     -0.955192506313324
    phi[8,7]  R2319     -0.307110071182251
    phi[8,7]  R2320     5.0707712769508362e-02
    phi[8,7]  R2321     -7.5300693511962891e-01
    phi[8,7]  R2322     3.0359643697738647e-01
    phi[8,7]  R2323     1.6924470663070679e-01
    phi[8,7]  R2324     2.8592443466186523e-01
    phi[8,7]  R2325     -2.6396626234054565e-01
    phi[8,7]  R2326     -2.4929363727569580e+00
    phi[8,7]  R2327     -6.5929234027862549e-02
    phi[8,7]  R2328     9.9114489555358887e-01
    phi[8,7]  R2329     -6.0865050554275513e-01
    phi[8,7]  R2330     4.9015176296234131e-01
    phi[8,7]  R2331     -5.9932100772857666e-01
    phi[8,7]  R2332     -1.3739583492279053e+00
    phi[8,7]  R2333     -2.1892635822296143e+00
    phi[8,7]  R2334     -1.9274233579635620e+00
    phi[8,7]  R2335     -1.2248547077178955e+00
    phi[8,7]  R2336     -1.2862651348114014e+00
    phi[8,7]  R2337     -1.5805560350418091e+00
    phi[8,7]  R2338     -2.3422415256500244e+00
    phi[8,7]  R2339     -0.31435427069664
    phi[8,7]  R2340     -4.0504133701324463e-01
    phi[8,7]  R2341     -8.2430303096771240e-01
    phi[8,7]  R2342     -7.7555274963378906e-01
    phi[8,7]  R2343     -1.8867025375366211e+00
    phi[8,7]  R2344     -1.1800177097320557e+00
    phi[8,7]  R2345     -1.4688655138015747e+00
    phi[8,7]  R2346     -1.7244472503662109e+00
    phi[8,7]  R2347     -2.2192187309265137e+00
    phi[8,7]  R2348     -3.0467216968536377e+00
    phi[8,7]  R2349     -1.4497781991958618e+00
    phi[8,7]  R2350     -2.2772746086120605e+00
    phi[8,7]  R2351     -2.1594746112823486e+00
    phi[8,7]  R2352     -1.1020239591598511e+00
    phi[8,7]  R2353     -1.9125962257385254e+00
    phi[8,7]  R2354     -2.3267960548400879e+00
    phi[8,7]  R2355     -1.6860114336013794e+00
    phi[8,7]  R2356     -2.0324714183807373e+00
    phi[8,7]  R2357     -2.7791550159454346e+00
    phi[8,7]  R2358     -2.0850756168365479e+00
    phi[8,7]  R2359     -1.4509686231613159e+00
    phi[8,7]  R2360     -8.0248057842254639e-01
    phi[8,7]  R2361     -2.7869641780853271e+00
    phi[8,7]  R2362     -2.7643742561340332e+00
    phi[8,7]  R2363     -1.3069069385528564e+00
    phi[8,7]  R2364     -2.0885956287384033e+00
    phi[8,7]  R2365     -1.6555836200714111e+00
    phi[8,7]  R2366     -1.7919402122497559e+00
    phi[8,7]  R2367     -6.3498944044113159e-01
    phi[8,7]  R2368     -7.3582255840301514e-01
    phi[8,7]  R2369     -3.9465361833572388e-01
    phi[8,7]  R2370     -3.3760879039764404e+00
    phi[8,7]  R2371     -6.0313361883163452e-01
    phi[8,7]  R2372     4.1627940535545349e-01
    phi[8,7]  R2373     -2.6833035945892334e+00
    phi[8,7]  R2374     -1.0759689807891846e+00
    phi[8,7]  R2375     -2.1541502475738525e+00
    phi[8,7]  R2376     -2.3699092864990234e+00
    phi[8,7]  R2377     -7.4833959341049194e-01
    phi[8,7]  R2378     -1.3880273103713989e+00
    phi[8,7]  R2379     -2.0127103328704834e+00
    phi[8,7]  R2380     -1.7158116102218628e+00
    phi[8,7]  R2381     -1.84722101688385
    phi[8,9]  R72       1
    phi[8,9]  R73       1
    phi[8,9]  R81       -1
    phi[8,9]  R2382     -3.0999999046325684e+00
    phi[8,9]  R2383     -3.0999999046325684e+00
    phi[8,9]  R2384     -2.2400000095367432e+00
    phi[8,9]  R2385     -2.2400000095367432e+00
    phi[8,9]  R2386     -3.0999999046325684e+00
    phi[8,9]  R2387     -3.0999999046325684e+00
    phi[8,9]  R2388     -2.5699999332427979e+00
    phi[8,9]  R2389     -2.5699999332427979e+00
    phi[8,9]  R2390     -3.0999999046325684e+00
    phi[8,9]  R2391     -3.0999999046325684e+00
    phi[8,9]  R2392     -2.0899999141693115e+00
    phi[8,9]  R2393     -2.0899999141693115e+00
    phi[8,9]  R2394     -3.0999999046325684e+00
    phi[8,9]  R2395     -3.0999999046325684e+00
    phi[8,9]  R2396     2.7243900299072266e-01
    phi[8,9]  R2397     -5.5937863886356354e-02
    phi[8,9]  R2398     1.6453427076339722e+00
    phi[8,9]  R2399     -2.0913331508636475e+00
    phi[8,9]  R2400     -1.3725587129592896e+00
    phi[8,9]  R2401     2.1612703800201416e+00
    phi[8,9]  R2402     1.5832393169403076e+00
    phi[8,9]  R2403     1.4197872877120972e+00
    phi[8,9]  R2404     2.3048961162567139e-01
    phi[8,9]  R2405     7.8916825354099274e-02
    phi[8,9]  R2406     -2.6615955829620361e+00
    phi[8,9]  R2407     -1.9303780794143677e+00
    phi[8,9]  R2408     -1.2191613912582397e+00
    phi[8,9]  R2409     -2.5879750251770020e+00
    phi[8,9]  R2410     -2.7915666103363037e+00
    phi[8,9]  R2411     -2.8125281333923340e+00
    phi[8,9]  R2412     -1.7662169933319092e+00
    phi[8,9]  R2413     -2.6342775821685791e+00
    phi[8,9]  R2414     -7.2237354516983032e-01
    phi[8,9]  R2415     -1.5237890481948853e+00
    phi[8,9]  R2416     -1.1457449197769165e+00
    phi[8,9]  R2417     -1.3899503946304321e+00
    phi[8,9]  R2418     0.542015790939331
    phi[8,9]  R2419     1.6061511635780334e-01
    phi[8,9]  R2420     -1.4101532697677612e+00
    phi[8,9]  R2421     -1.5393307805061340e-01
    phi[8,9]  R2422     -2.0948023796081543e+00
    phi[8,9]  R2423     -2.3981873989105225e+00
    phi[8,9]  R2424     -9.9057137966156006e-01
    phi[8,9]  R2425     -1.3538525104522705e+00
    phi[8,9]  R2426     -1.9237126111984253e+00
    phi[8,9]  R2427     -1.47964608669281
    phi[8,9]  R2428     -0.720046877861023
    phi[8,9]  R2429     9.5154517889022827e-01
    phi[8,9]  R2430     -1.1573683470487595e-01
    phi[8,9]  R2431     -1.3346241712570190e+00
    phi[8,9]  R2432     -1.1719300746917725e+00
    phi[8,9]  R2433     -1.2868382930755615e+00
    phi[8,9]  R2434     -1.1167380809783936e+00
    phi[8,9]  R2435     -1.4271928071975708e+00
    phi[8,9]  R2436     -2.7385556697845459e+00
    phi[8,9]  R2437     -2.61669921875
    phi[8,9]  R2438     -3.0045044422149658e+00
    phi[8,9]  R2439     -1.7381310462951660e+00
    phi[8,9]  R2440     -8.0370485782623291e-01
    phi[8,9]  R2441     -5.9897100925445557e-01
    phi[8,9]  R2442     -1.7093245983123779e+00
    phi[8,9]  R2443     -1.8240536451339722e+00
    phi[8,9]  R2444     -1.5236327648162842e+00
    phi[8,9]  R2445     -1.3653445243835449e+00
    phi[8,9]  R2446     1.2838883399963379e+00
    phi[8,9]  R2447     1.9955589771270752e+00
    phi[8,9]  R2448     2.4638538360595703e+00
    phi[8,9]  R2449     2.8913104534149170e+00
    phi[8,9]  R2450     2.9838672280311584e-01
    phi[8,9]  R2451     2.1370922029018402e-01
    phi[8,9]  R2452     -2.2526422142982483e-01
    phi[8,9]  R2453     -1.6878713369369507e+00
    phi[8,9]  R2454     -1.9175196886062622e+00
    phi[8,9]  R2455     8.3669376373291016e-01
    phi[8,9]  R2456     4.1067838668823242e-01
    phi[8,9]  R2457     -1.8640686571598053e-01
    phi[8,9]  R2458     -2.4801020622253418e+00
    phi[8,9]  R2459     -3.0751810073852539e+00
    phi[8,9]  R2460     -2.3866758346557617e+00
    phi[8,9]  R2461     -1.5824452638626099e+00
    phi[8,9]  R2462     -1.9570163488388062e+00
    phi[8,9]  R2463     -2.8287987709045410e+00
    phi[8,9]  R2464     -1.3459985256195068e+00
    phi[8,9]  R2465     -2.7070415019989014e+00
    phi[8,9]  R2466     -1.3946158885955811e+00
    phi[8,9]  R2467     -2.8389842510223389e+00
    phi[8,9]  R2468     -3.2928414344787598e+00
    phi[8,9]  R2469     -2.5906293392181396e+00
    phi[8,9]  R2470     -2.7061665058135986e+00
    phi[9,8]  R72       -1
    phi[9,8]  R81       1
    phi[9,8]  R82       1
    phi[9,8]  R2471     -3.0999999046325684e+00
    phi[9,8]  R2472     -3.0999999046325684e+00
    phi[9,8]  R2473     -2.2400000095367432e+00
    phi[9,8]  R2474     -2.2400000095367432e+00
    phi[9,8]  R2475     -3.0999999046325684e+00
    phi[9,8]  R2476     -3.0999999046325684e+00
    phi[9,8]  R2477     -2.5699999332427979e+00
    phi[9,8]  R2478     -2.5699999332427979e+00
    phi[9,8]  R2479     -3.0999999046325684e+00
    phi[9,8]  R2480     -3.0999999046325684e+00
    phi[9,8]  R2481     -2.0899999141693115e+00
    phi[9,8]  R2482     -2.0899999141693115e+00
    phi[9,8]  R2483     -3.0999999046325684e+00
    phi[9,8]  R2484     -3.0999999046325684e+00
    phi[9,8]  R2485     1.2838883399963379e+00
    phi[9,8]  R2486     1.9955589771270752e+00
    phi[9,8]  R2487     2.4638538360595703e+00
    phi[9,8]  R2488     2.8913104534149170e+00
    phi[9,8]  R2489     2.9838672280311584e-01
    phi[9,8]  R2490     2.1370922029018402e-01
    phi[9,8]  R2491     -2.2526422142982483e-01
    phi[9,8]  R2492     -1.6878713369369507e+00
    phi[9,8]  R2493     -1.9175196886062622e+00
    phi[9,8]  R2494     8.3669376373291016e-01
    phi[9,8]  R2495     4.1067838668823242e-01
    phi[9,8]  R2496     -1.8640686571598053e-01
    phi[9,8]  R2497     -2.4801020622253418e+00
    phi[9,8]  R2498     -3.0751810073852539e+00
    phi[9,8]  R2499     -2.3866758346557617e+00
    phi[9,8]  R2500     -1.5824452638626099e+00
    phi[9,8]  R2501     -1.9570163488388062e+00
    phi[9,8]  R2502     -2.8287987709045410e+00
    phi[9,8]  R2503     -1.3459985256195068e+00
    phi[9,8]  R2504     -2.7070415019989014e+00
    phi[9,8]  R2505     -1.3946158885955811e+00
    phi[9,8]  R2506     -2.8389842510223389e+00
    phi[9,8]  R2507     -3.2928414344787598e+00
    phi[9,8]  R2508     -2.5906293392181396e+00
    phi[9,8]  R2509     -2.7061665058135986e+00
    phi[9,8]  R2510     2.7243900299072266e-01
    phi[9,8]  R2511     -5.5937863886356354e-02
    phi[9,8]  R2512     1.6453427076339722e+00
    phi[9,8]  R2513     -2.0913331508636475e+00
    phi[9,8]  R2514     -1.3725587129592896e+00
    phi[9,8]  R2515     2.1612703800201416e+00
    phi[9,8]  R2516     1.5832393169403076e+00
    phi[9,8]  R2517     1.4197872877120972e+00
    phi[9,8]  R2518     2.3048961162567139e-01
    phi[9,8]  R2519     7.8916825354099274e-02
    phi[9,8]  R2520     -2.6615955829620361e+00
    phi[9,8]  R2521     -1.9303780794143677e+00
    phi[9,8]  R2522     -1.2191613912582397e+00
    phi[9,8]  R2523     -2.5879750251770020e+00
    phi[9,8]  R2524     -2.7915666103363037e+00
    phi[9,8]  R2525     -2.8125281333923340e+00
    phi[9,8]  R2526     -1.7662169933319092e+00
    phi[9,8]  R2527     -2.6342775821685791e+00
    phi[9,8]  R2528     -7.2237354516983032e-01
    phi[9,8]  R2529     -1.5237890481948853e+00
    phi[9,8]  R2530     -1.1457449197769165e+00
    phi[9,8]  R2531     -1.3899503946304321e+00
    phi[9,8]  R2532     0.542015790939331
    phi[9,8]  R2533     1.6061511635780334e-01
    phi[9,8]  R2534     -1.4101532697677612e+00
    phi[9,8]  R2535     -1.5393307805061340e-01
    phi[9,8]  R2536     -2.0948023796081543e+00
    phi[9,8]  R2537     -2.3981873989105225e+00
    phi[9,8]  R2538     -9.9057137966156006e-01
    phi[9,8]  R2539     -1.3538525104522705e+00
    phi[9,8]  R2540     -1.9237126111984253e+00
    phi[9,8]  R2541     -1.47964608669281
    phi[9,8]  R2542     -0.720046877861023
    phi[9,8]  R2543     9.5154517889022827e-01
    phi[9,8]  R2544     -1.1573683470487595e-01
    phi[9,8]  R2545     -1.3346241712570190e+00
    phi[9,8]  R2546     -1.1719300746917725e+00
    phi[9,8]  R2547     -1.2868382930755615e+00
    phi[9,8]  R2548     -1.1167380809783936e+00
    phi[9,8]  R2549     -1.4271928071975708e+00
    phi[9,8]  R2550     -2.7385556697845459e+00
    phi[9,8]  R2551     -2.61669921875
    phi[9,8]  R2552     -3.0045044422149658e+00
    phi[9,8]  R2553     -1.7381310462951660e+00
    phi[9,8]  R2554     -8.0370485782623291e-01
    phi[9,8]  R2555     -5.9897100925445557e-01
    phi[9,8]  R2556     -1.7093245983123779e+00
    phi[9,8]  R2557     -1.8240536451339722e+00
    phi[9,8]  R2558     -1.5236327648162842e+00
    phi[9,8]  R2559     -1.3653445243835449e+00
    phi[9,11]  R81       1
    phi[9,11]  R82       1
    phi[9,11]  R83       3.0859786346867457e-01
    phi[9,11]  R84       -1.3267881320084234e+00
    phi[9,11]  R85       1.5193867570988120e+00
    phi[9,11]  R86       -3.2639590037716371e-01
    phi[9,11]  R87       1.5392165380217271e+00
    phi[9,11]  R88       -1.6226623347846192e+00
    phi[9,11]  R89       1.3995949929412517e+00
    phi[9,11]  R91       -1
    phi[9,11]  R2560     -2.7914020411638938e+00
    phi[9,11]  R2561     -3.4085977681012429e+00
    phi[9,11]  R2562     -3.5667881415451665e+00
    phi[9,11]  R2563     -9.1321187752831978e-01
    phi[9,11]  R2564     -1.5806131475337564e+00
    phi[9,11]  R2565     -4.61938666173138
    phi[9,11]  R2566     -2.8963958336199616e+00
    phi[9,11]  R2567     -2.2436040328656341e+00
    phi[9,11]  R2568     -1.5607833666108413e+00
    phi[9,11]  R2569     -4.6392164426542957e+00
    phi[9,11]  R2570     -3.7126622489539307e+00
    phi[9,11]  R2571     -4.6733757938469234e-01
    phi[9,11]  R2572     -1.7004049116913167e+00
    phi[9,11]  R2573     -4.49959489757382
    phi[9,11]  R2574     -2.5271277364187439e-02
    phi[9,11]  R2575     -2.8855894290042094e-02
    phi[9,11]  R2576     -3.9916532548279537e-02
    phi[9,11]  R2577     -4.0701174456456712e-02
    phi[9,11]  R2578     -4.8989966732413293e-02
    phi[9,11]  R2579     -4.9330386305370844e-02
    phi[9,11]  R2580     -5.4515689065393724e-02
    phi[9,11]  R2581     -6.1849006669167039e-02
    phi[9,11]  R2582     -8.6332805252258060e-02
    phi[9,11]  R2583     -8.9338731593456955e-02
    phi[9,11]  R2584     -1.5746608760768221e-02
    phi[9,11]  R2585     -1.9750501509475327e-02
    phi[9,11]  R2586     -0.381765553263544
    phi[9,11]  R2587     -6.7540459207587444e-01
    phi[9,11]  R2588     -2.0902290894757076e+00
    phi[9,11]  R2589     -1.9532962592677738e-01
    phi[9,11]  R2590     -1.9893254106684211e-01
    phi[9,11]  R2591     -1.1398207708607222e-01
    phi[9,11]  R2592     -1.1500763511824941e-01
    phi[9,11]  R2593     -1.3031230035606596e+00
    phi[9,11]  R2594     -1.2313320074531564e-01
    phi[9,11]  R2595     -1.2586082990646119e-01
    phi[9,11]  R2596     -7.3854229418407336e-01
    phi[9,11]  R2597     -1.4612669801708034e-01
    phi[9,11]  R2598     -1.8529528709299190e+00
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R92       -1
    z[0,1,0]  R93       1
    z[0,1,0]  R106      3.1617248058319092e-01
    z[0,1,0]  R107      5.7669192552566528e-01
    z[0,1,0]  R108      4.7605317831039429e-01
    z[0,1,0]  R109      4.6785807609558105e-01
    z[0,1,0]  R110      8.7497037649154663e-01
    z[0,1,0]  R111      7.1143907308578491e-01
    z[0,1,0]  R112      6.8296575546264648e-01
    z[0,1,0]  R113      8.1498926877975464e-01
    z[0,1,0]  R114      0.185358464717865
    z[0,1,0]  R115      4.7616714239120483e-01
    z[0,1,0]  R116      -4.9223318696022034e-01
    z[0,1,0]  R117      -5.4711413383483887e-01
    z[0,1,0]  R118      -2.4950566887855530e-01
    z[0,1,0]  R119      -4.1189306974411011e-01
    z[0,1,0]  R120      -3.0863013863563538e-01
    z[0,1,0]  R121      -4.8976475000381470e-01
    z[0,1,0]  R122      -1.5400357544422150e-01
    z[0,1,0]  R123      -4.3866270780563354e-01
    z[0,1,0]  R124      -4.7704404592514038e-01
    z[0,1,0]  R125      -2.4821718037128448e-01
    z[0,1,0]  R126      1.1715054512023926e-01
    z[0,1,0]  R127      -7.2085000574588776e-02
    z[0,1,0]  R128      -7.1591906249523163e-02
    z[0,1,0]  R129      2.9847750067710876e-01
    z[0,1,0]  R130      -4.2866292595863342e-01
    z[0,1,0]  R131      -0.407634973526001
    z[0,1,0]  R132      -3.9184358716011047e-01
    z[0,1,0]  R133      -5.7812762260437012e-01
    z[0,1,0]  R134      2.7833279222249985e-02
    z[0,1,0]  R135      -2.9819878935813904e-01
    z[0,1,0]  R136      6.3001766800880432e-02
    z[0,1,0]  R137      0.0899825319647789
    z[0,1,0]  R138      2.5428640842437744e-01
    z[0,1,0]  R139      3.2596611976623535e-01
    z[0,1,0]  R140      3.4396609663963318e-01
    z[0,1,0]  R141      -2.6913258433341980e-01
    z[0,1,0]  R142      -2.6759406924247742e-01
    z[0,1,0]  R143      3.4607195854187012e-01
    z[0,1,0]  R144      4.3527016043663025e-01
    z[0,1,0]  R145      -1.2859259545803070e-01
    z[0,1,0]  R146      9.0489076683297753e-04
    z[0,1,0]  R147      1.2812386453151703e-01
    z[0,1,0]  R148      2.0964090526103973e-01
    z[0,1,0]  R149      3.1280410289764404e-01
    z[0,1,0]  R150      1.2833017110824585e-01
    z[0,1,0]  R151      -0.756442666053772
    z[0,1,0]  R152      -3.5724371671676636e-01
    z[0,1,0]  R153      -3.8763898611068726e-01
    z[0,1,0]  R154      -2.8695088624954224e-01
    z[0,1,0]  R155      -5.0645190477371216e-01
    z[0,1,0]  R156      -6.2723271548748016e-02
    z[0,1,0]  R157      1.7746257781982422e-01
    z[0,1,0]  R158      -7.8412890434265137e-01
    z[0,1,0]  R159      -3.7134975194931030e-01
    z[0,1,0]  R160      -4.2428565025329590e-01
    z[0,1,0]  R161      -3.3557087182998657e-01
    z[0,1,0]  R162      -1.0943162441253662e-01
    z[0,1,0]  R163      -4.9729606509208679e-01
    z[0,1,0]  R164      -8.1524938344955444e-01
    z[0,1,0]  R165      -7.9225832223892212e-01
    z[0,1,0]  R166      2.8589609265327454e-01
    z[0,1,0]  R167      4.8036411404609680e-01
    z[0,1,0]  R168      2.5183260440826416e-01
    z[0,1,0]  R169      3.0372983217239380e-01
    z[0,1,0]  R170      -9.2242234945297241e-01
    z[0,1,0]  R171      -8.9510083198547363e-01
    z[0,1,0]  R172      1.8954648077487946e-01
    z[0,1,0]  R173      -8.5063797235488892e-01
    z[0,1,0]  R174      -8.1500744819641113e-01
    z[0,1,0]  R175      -8.3995550870895386e-01
    z[0,1,0]  R176      8.3946204185485840e-01
    z[0,1,0]  R177      8.5628277063369751e-01
    z[0,1,0]  R178      7.4340730905532837e-01
    z[0,1,0]  R179      7.0932799577713013e-01
    z[0,1,0]  R180      8.0658096075057983e-01
    z[0,1,0]  R181      8.5277885198593140e-01
    z[0,1,0]  R182      6.2278401851654053e-01
    z[0,1,0]  R183      5.2813696861267090e-01
    z[0,1,0]  R184      6.4491635560989380e-01
    z[0,1,0]  R185      4.3566048145294189e-01
    z[0,1,0]  R186      8.1669247150421143e-01
    z[0,1,0]  R187      7.2770011425018311e-01
    z[0,1,0]  R188      5.3186315298080444e-01
    z[0,1,0]  R189      -6.5128237009048462e-01
    z[0,1,0]  R190      8.2274824380874634e-01
    z[0,1,0]  R191      4.9348068237304688e-01
    z[0,1,0]  R192      3.7716588377952576e-01
    z[0,1,0]  R193      -9.0435231104493141e-03
    z[0,1,0]  R194      -6.4122684299945831e-02
    z[0,1,0]  R195      -1.5305294096469879e-01
    z[0,1,0]  R196      7.0274728536605835e-01
    z[0,1,0]  R197      5.2221375703811646e-01
    z[0,1,0]  R198      4.7327014803886414e-01
    z[0,1,0]  R199      5.6887823343276978e-01
    z[0,1,0]  R200      9.1267181560397148e-03
    z[0,1,0]  R201      0.031141497194767
    z[0,1,0]  R202      1.1161900311708450e-01
    z[0,1,0]  R203      -1.6556279733777046e-02
    z[0,1,0]  R204      -1.8656864762306213e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R94       -1
    z[0,1,1]  R95       1
    z[0,1,1]  R106      -2.2488594055175781e-01
    z[0,1,1]  R107      -1.2939150631427765e-01
    z[0,1,1]  R108      -2.1679200232028961e-01
    z[0,1,1]  R109      -4.0721505880355835e-01
    z[0,1,1]  R110      -1.8201905488967896e-01
    z[0,1,1]  R111      -3.6664776504039764e-02
    z[0,1,1]  R112      -3.5846021771430969e-01
    z[0,1,1]  R113      -2.6038247346878052e-01
    z[0,1,1]  R114      -6.8155348300933838e-01
    z[0,1,1]  R115      -2.8164952993392944e-01
    z[0,1,1]  R116      6.2968921661376953e-01
    z[0,1,1]  R117      6.2375122308731079e-01
    z[0,1,1]  R118      6.4590960741043091e-01
    z[0,1,1]  R119      8.7937724590301514e-01
    z[0,1,1]  R120      7.2811561822891235e-01
    z[0,1,1]  R121      4.4551664590835571e-01
    z[0,1,1]  R122      7.0651078224182129e-01
    z[0,1,1]  R123      6.0509574413299561e-01
    z[0,1,1]  R124      4.0943464636802673e-01
    z[0,1,1]  R125      0.868427574634552
    z[0,1,1]  R126      7.7697628736495972e-01
    z[0,1,1]  R127      8.2676619291305542e-01
    z[0,1,1]  R128      7.4282425642013550e-01
    z[0,1,1]  R129      5.9907871484756470e-01
    z[0,1,1]  R130      3.6086297035217285e-01
    z[0,1,1]  R131      -5.0757569074630737e-01
    z[0,1,1]  R132      1.7272317409515381e-01
    z[0,1,1]  R133      -3.2708102464675903e-01
    z[0,1,1]  R134      4.5395290851593018e-01
    z[0,1,1]  R135      -2.8362569212913513e-01
    z[0,1,1]  R136      9.4584661722183228e-01
    z[0,1,1]  R137      8.3826774358749390e-01
    z[0,1,1]  R138      7.8720378875732422e-01
    z[0,1,1]  R139      8.5944074392318726e-01
    z[0,1,1]  R140      7.4405682086944580e-01
    z[0,1,1]  R141      8.2526820898056030e-01
    z[0,1,1]  R142      7.6957190036773682e-01
    z[0,1,1]  R143      0.693574070930481
    z[0,1,1]  R144      7.0397454500198364e-01
    z[0,1,1]  R145      7.1981674432754517e-01
    z[0,1,1]  R146      8.8600194454193115e-01
    z[0,1,1]  R147      8.1919866800308228e-01
    z[0,1,1]  R148      7.5020068883895874e-01
    z[0,1,1]  R149      7.7050465345382690e-01
    z[0,1,1]  R150      7.8837692737579346e-01
    z[0,1,1]  R151      3.5375913977622986e-01
    z[0,1,1]  R152      3.5882890224456787e-01
    z[0,1,1]  R153      2.7233263850212097e-01
    z[0,1,1]  R154      -6.9074638187885284e-02
    z[0,1,1]  R155      3.1501409411430359e-01
    z[0,1,1]  R156      9.6092832088470459e-01
    z[0,1,1]  R157      9.0106505155563354e-01
    z[0,1,1]  R158      3.6725702881813049e-01
    z[0,1,1]  R159      -4.7007972002029419e-01
    z[0,1,1]  R160      -2.9570633172988892e-01
    z[0,1,1]  R161      3.7011715769767761e-01
    z[0,1,1]  R162      -5.1091857254505157e-02
    z[0,1,1]  R163      -3.9350786805152893e-01
    z[0,1,1]  R164      -0.486627459526062
    z[0,1,1]  R165      -5.2580362558364868e-01
    z[0,1,1]  R166      -3.8261207938194275e-01
    z[0,1,1]  R167      -3.9298757910728455e-01
    z[0,1,1]  R168      -3.2411766052246094e-01
    z[0,1,1]  R169      -3.6309796571731567e-01
    z[0,1,1]  R170      1.9612239301204681e-01
    z[0,1,1]  R171      9.2389337718486786e-02
    z[0,1,1]  R172      -2.6568973064422607e-01
    z[0,1,1]  R173      -5.6720346212387085e-02
    z[0,1,1]  R174      1.1615302413702011e-01
    z[0,1,1]  R175      1.9600871205329895e-01
    z[0,1,1]  R176      -1.3788338005542755e-01
    z[0,1,1]  R177      -1.0093265026807785e-01
    z[0,1,1]  R178      -1.5189656615257263e-01
    z[0,1,1]  R179      4.3319123983383179e-01
    z[0,1,1]  R180      2.6871562004089355e-01
    z[0,1,1]  R181      2.2296649217605591e-01
    z[0,1,1]  R182      3.8540813326835632e-01
    z[0,1,1]  R183      -1.6456307470798492e-01
    z[0,1,1]  R184      -6.5834693610668182e-02
    z[0,1,1]  R185      -3.2170256972312927e-01
    z[0,1,1]  R186      2.3825766146183014e-01
    z[0,1,1]  R187      2.3456817865371704e-01
    z[0,1,1]  R188      -1.9221548736095428e-01
    z[0,1,1]  R189      -4.4710376858711243e-01
    z[0,1,1]  R190      -1.9863858819007874e-01
    z[0,1,1]  R191      -9.1180332005023956e-02
    z[0,1,1]  R192      -4.1659852862358093e-01
    z[0,1,1]  R193      -2.4918284267187119e-02
    z[0,1,1]  R194      -1.6778963804244995e-01
    z[0,1,1]  R195      -2.7185013890266418e-01
    z[0,1,1]  R196      -1.0604806989431381e-01
    z[0,1,1]  R197      -2.2762747108936310e-01
    z[0,1,1]  R198      -3.9906290173530579e-01
    z[0,1,1]  R199      -0.128247931599617
    z[0,1,1]  R200      -1.8021407723426819e-01
    z[0,1,1]  R201      8.3533596992492676e-01
    z[0,1,1]  R202      2.8546115756034851e-01
    z[0,1,1]  R203      2.5662371516227722e-01
    z[0,1,1]  R204      -3.9189425110816956e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R96       -1
    z[0,1,2]  R97       1
    z[0,1,2]  R106      6.9641411304473877e-01
    z[0,1,2]  R107      6.1756026744842529e-01
    z[0,1,2]  R108      0.746904730796814
    z[0,1,2]  R109      4.7763559222221375e-01
    z[0,1,2]  R110      3.4936192631721497e-01
    z[0,1,2]  R111      5.7652479410171509e-01
    z[0,1,2]  R112      2.7917012572288513e-01
    z[0,1,2]  R113      7.9882211983203888e-02
    z[0,1,2]  R114      4.9595010280609131e-01
    z[0,1,2]  R115      -3.1767857726663351e-03
    z[0,1,2]  R116      -3.7552466988563538e-01
    z[0,1,2]  R117      -5.4819935560226440e-01
    z[0,1,2]  R118      -5.2614951133728027e-01
    z[0,1,2]  R119      -1.4535656571388245e-01
    z[0,1,2]  R120      -3.7699118256568909e-01
    z[0,1,2]  R121      -5.6106412410736084e-01
    z[0,1,2]  R122      -4.4130784273147583e-01
    z[0,1,2]  R123      -4.3506258726119995e-01
    z[0,1,2]  R124      -5.6248861551284790e-01
    z[0,1,2]  R125      -3.6139541864395142e-01
    z[0,1,2]  R126      1.6493658721446991e-01
    z[0,1,2]  R127      1.7390790581703186e-01
    z[0,1,2]  R128      3.4230497479438782e-01
    z[0,1,2]  R129      -1.2580266594886780e-01
    z[0,1,2]  R130      -1.4868043363094330e-01
    z[0,1,2]  R131      -1.2460289150476456e-01
    z[0,1,2]  R132      -0.503728985786438
    z[0,1,2]  R133      8.4312453866004944e-02
    z[0,1,2]  R134      -2.4389077723026276e-01
    z[0,1,2]  R135      -3.0800363421440125e-01
    z[0,1,2]  R136      1.3863548636436462e-01
    z[0,1,2]  R137      -2.7512248605489731e-02
    z[0,1,2]  R138      -6.1390563845634460e-02
    z[0,1,2]  R139      -1.9287452101707458e-01
    z[0,1,2]  R140      -3.9840704202651978e-01
    z[0,1,2]  R141      -1.1714725941419601e-01
    z[0,1,2]  R142      -2.4716173112392426e-01
    z[0,1,2]  R143      -2.9159530997276306e-01
    z[0,1,2]  R144      -1.0140753537416458e-01
    z[0,1,2]  R145      -3.0194488167762756e-01
    z[0,1,2]  R146      -1.9755041599273682e-01
    z[0,1,2]  R147      -2.4487484991550446e-01
    z[0,1,2]  R148      -0.43577840924263
    z[0,1,2]  R149      -1.1846154229715466e-03
    z[0,1,2]  R150      7.1419939398765564e-02
    z[0,1,2]  R151      -1.8547539412975311e-01
    z[0,1,2]  R152      -3.4186357259750366e-01
    z[0,1,2]  R153      -5.1645022630691528e-01
    z[0,1,2]  R154      -1.0560575872659683e-01
    z[0,1,2]  R155      -1.4410842955112457e-01
    z[0,1,2]  R156      6.8419404327869415e-02
    z[0,1,2]  R157      -4.0451448410749435e-02
    z[0,1,2]  R158      -1.9884806871414185e-01
    z[0,1,2]  R159      -2.1745659410953522e-01
    z[0,1,2]  R160      -2.4599377810955048e-01
    z[0,1,2]  R161      2.0575824379920959e-01
    z[0,1,2]  R162      -4.7127166390419006e-01
    z[0,1,2]  R163      1.4961537718772888e-01
    z[0,1,2]  R164      -1.8319293856620789e-01
    z[0,1,2]  R165      -1.3706816732883453e-01
    z[0,1,2]  R166      0.648175835609436
    z[0,1,2]  R167      5.1874715089797974e-01
    z[0,1,2]  R168      7.2205990552902222e-01
    z[0,1,2]  R169      7.5782293081283569e-01
    z[0,1,2]  R170      -1.7612613737583160e-01
    z[0,1,2]  R171      -8.2908622920513153e-02
    z[0,1,2]  R172      7.3629534244537354e-01
    z[0,1,2]  R173      -1.1637032777070999e-01
    z[0,1,2]  R174      -1.9568027555942535e-01
    z[0,1,2]  R175      3.8976226001977921e-02
    z[0,1,2]  R176      -1.4966638386249542e-01
    z[0,1,2]  R177      -3.7048918008804321e-01
    z[0,1,2]  R178      -5.0181216001510620e-01
    z[0,1,2]  R179      -8.3484664559364319e-02
    z[0,1,2]  R180      -3.1613492965698242e-01
    z[0,1,2]  R181      -3.1253471970558167e-01
    z[0,1,2]  R182      -0.0691266879439354
    z[0,1,2]  R183      -3.6677503585815430e-01
    z[0,1,2]  R184      -3.1109884381294250e-01
    z[0,1,2]  R185      -1.1346743442118168e-02
    z[0,1,2]  R186      -2.7712648734450340e-03
    z[0,1,2]  R187      1.8844065070152283e-01
    z[0,1,2]  R188      -3.8060847669839859e-02
    z[0,1,2]  R189      0.398979514837265
    z[0,1,2]  R190      -2.3419651389122009e-01
    z[0,1,2]  R191      4.8064128495752811e-03
    z[0,1,2]  R192      -1.5498661994934082e-01
    z[0,1,2]  R193      -3.3935699611902237e-02
    z[0,1,2]  R194      -2.2759050130844116e-01
    z[0,1,2]  R195      -2.8109228610992432e-01
    z[0,1,2]  R196      -0.0703529641032219
    z[0,1,2]  R197      1.8172599375247955e-01
    z[0,1,2]  R198      1.3317517936229706e-01
    z[0,1,2]  R199      -4.1968944668769836e-01
    z[0,1,2]  R200      -4.6865735203027725e-02
    z[0,1,2]  R201      -3.4458798170089722e-01
    z[0,1,2]  R202      2.2251743078231812e-01
    z[0,1,2]  R203      6.3858158886432648e-02
    z[0,1,2]  R204      -2.3983417451381683e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R98       -1
    z[0,1,3]  R99       1
    z[0,1,3]  R106      5.1677453517913818e-01
    z[0,1,3]  R107      1.2330103665590286e-01
    z[0,1,3]  R108      1.6277417540550232e-01
    z[0,1,3]  R109      4.2016741633415222e-01
    z[0,1,3]  R110      2.2670869529247284e-01
    z[0,1,3]  R111      2.6785820722579956e-01
    z[0,1,3]  R112      -1.0430599562823772e-02
    z[0,1,3]  R113      3.7662589550018311e-01
    z[0,1,3]  R114      2.8773674368858337e-01
    z[0,1,3]  R115      7.7458918094635010e-01
    z[0,1,3]  R116      1.6704623401165009e-01
    z[0,1,3]  R117      2.3247901350259781e-02
    z[0,1,3]  R118      4.1320866346359253e-01
    z[0,1,3]  R119      0.0545872300863266
    z[0,1,3]  R120      1.2594187259674072e-01
    z[0,1,3]  R121      1.6451855003833771e-01
    z[0,1,3]  R122      3.3085045218467712e-01
    z[0,1,3]  R123      2.4973908066749573e-01
    z[0,1,3]  R124      3.9302092790603638e-01
    z[0,1,3]  R125      -8.9879669249057770e-02
    z[0,1,3]  R126      -5.6031066179275513e-01
    z[0,1,3]  R127      -9.8044604063034058e-02
    z[0,1,3]  R128      -1.3259139657020569e-01
    z[0,1,3]  R129      -0.507114827632904
    z[0,1,3]  R130      -6.7938894033432007e-01
    z[0,1,3]  R131      -6.5618109703063965e-01
    z[0,1,3]  R132      -6.9857668876647949e-01
    z[0,1,3]  R133      -6.7651957273483276e-01
    z[0,1,3]  R134      -0.729148805141449
    z[0,1,3]  R135      -6.4328622817993164e-01
    z[0,1,3]  R136      6.0929656028747559e-02
    z[0,1,3]  R137      4.4564566016197205e-01
    z[0,1,3]  R138      -4.6845340728759766e-01
    z[0,1,3]  R139      0.217659592628479
    z[0,1,3]  R140      -2.1393077075481415e-01
    z[0,1,3]  R141      -2.3716230690479279e-01
    z[0,1,3]  R142      -3.2082572579383850e-01
    z[0,1,3]  R143      4.1865665465593338e-02
    z[0,1,3]  R144      -9.6946984529495239e-02
    z[0,1,3]  R145      8.9062482118606567e-02
    z[0,1,3]  R146      -3.2469424605369568e-01
    z[0,1,3]  R147      -3.8564404845237732e-01
    z[0,1,3]  R148      1.9415273563936353e-03
    z[0,1,3]  R149      -0.000567007577046752
    z[0,1,3]  R150      -0.308651328086853
    z[0,1,3]  R151      2.7416145801544189e-01
    z[0,1,3]  R152      -7.5802463293075562e-01
    z[0,1,3]  R153      -6.2473946809768677e-01
    z[0,1,3]  R154      -0.938624382019043
    z[0,1,3]  R155      -6.4770805835723877e-01
    z[0,1,3]  R156      5.8693759143352509e-02
    z[0,1,3]  R157      1.9043010473251343e-01
    z[0,1,3]  R158      2.8132423758506775e-01
    z[0,1,3]  R159      -7.3013061285018921e-01
    z[0,1,3]  R160      -7.1067994832992554e-01
    z[0,1,3]  R161      -7.9846704006195068e-01
    z[0,1,3]  R162      -0.622801661491394
    z[0,1,3]  R163      -4.3773502111434937e-01
    z[0,1,3]  R164      1.8729162216186523e-01
    z[0,1,3]  R165      -9.3009635806083679e-02
    z[0,1,3]  R166      3.3444768190383911e-01
    z[0,1,3]  R167      5.9844911098480225e-02
    z[0,1,3]  R168      -6.5662041306495667e-02
    z[0,1,3]  R169      2.0085911452770233e-01
    z[0,1,3]  R170      -2.4074444547295570e-02
    z[0,1,3]  R171      2.6086029410362244e-01
    z[0,1,3]  R172      4.0525501966476440e-01
    z[0,1,3]  R173      1.4978574216365814e-01
    z[0,1,3]  R174      -1.8497286736965179e-01
    z[0,1,3]  R175      -1.7799408733844757e-01
    z[0,1,3]  R176      1.1157047748565674e-01
    z[0,1,3]  R177      -1.2984296679496765e-01
    z[0,1,3]  R178      0.353248655796051
    z[0,1,3]  R179      -2.8343278914690018e-02
    z[0,1,3]  R180      2.4139399826526642e-01
    z[0,1,3]  R181      1.1356934905052185e-01
    z[0,1,3]  R182      5.3709405474364758e-03
    z[0,1,3]  R183      -2.2197966277599335e-01
    z[0,1,3]  R184      0.646101176738739
    z[0,1,3]  R185      -1.9571591913700104e-01
    z[0,1,3]  R186      2.3418139666318893e-02
    z[0,1,3]  R187      -2.6679340004920959e-01
    z[0,1,3]  R188      0.672173798084259
    z[0,1,3]  R189      5.7566784322261810e-02
    z[0,1,3]  R190      3.8364630937576294e-01
    z[0,1,3]  R191      7.8136168420314789e-02
    z[0,1,3]  R192      6.0693745035678148e-04
    z[0,1,3]  R193      -6.2518179416656494e-01
    z[0,1,3]  R194      -6.1202096939086914e-01
    z[0,1,3]  R195      -6.0118412971496582e-01
    z[0,1,3]  R196      2.1372371912002563e-01
    z[0,1,3]  R197      -4.8983451724052429e-01
    z[0,1,3]  R198      1.9044023752212524e-01
    z[0,1,3]  R199      -2.2983053326606750e-01
    z[0,1,3]  R200      -0.721270740032196
    z[0,1,3]  R201      3.1372907757759094e-01
    z[0,1,3]  R202      -7.4560415744781494e-01
    z[0,1,3]  R203      -8.3811295032501221e-01
    z[0,1,3]  R204      -6.5260350704193115e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R100      -1
    z[0,1,4]  R101      1
    z[0,1,4]  R106      -4.1218571364879608e-02
    z[0,1,4]  R107      0.352463036775589
    z[0,1,4]  R108      -2.4997876584529877e-01
    z[0,1,4]  R109      3.1200459599494934e-01
    z[0,1,4]  R110      -1.5997199714183807e-01
    z[0,1,4]  R111      -5.0467513501644135e-02
    z[0,1,4]  R112      3.9517077803611755e-01
    z[0,1,4]  R113      -3.3496016263961792e-01
    z[0,1,4]  R114      -2.5108709931373596e-01
    z[0,1,4]  R115      5.7777430862188339e-02
    z[0,1,4]  R116      -2.4556618183851242e-02
    z[0,1,4]  R117      -7.3936069384217262e-03
    z[0,1,4]  R118      1.3218869268894196e-01
    z[0,1,4]  R119      4.1001036763191223e-02
    z[0,1,4]  R120      2.5220713019371033e-01
    z[0,1,4]  R121      1.9193364679813385e-01
    z[0,1,4]  R122      -5.9747759252786636e-02
    z[0,1,4]  R123      -8.6109027266502380e-02
    z[0,1,4]  R124      1.3745196163654327e-01
    z[0,1,4]  R125      0.0350436307489872
    z[0,1,4]  R126      9.5477670431137085e-02
    z[0,1,4]  R127      -3.7079265713691711e-01
    z[0,1,4]  R128      -1.3064685463905334e-01
    z[0,1,4]  R129      3.2557407021522522e-01
    z[0,1,4]  R130      -1.3982348144054413e-01
    z[0,1,4]  R131      1.1141499131917953e-01
    z[0,1,4]  R132      -7.0524394512176514e-02
    z[0,1,4]  R133      8.8269263505935669e-02
    z[0,1,4]  R134      4.1587015986442566e-01
    z[0,1,4]  R135      4.0703928470611572e-01
    z[0,1,4]  R136      -2.1439389884471893e-01
    z[0,1,4]  R137      -2.3072990775108337e-01
    z[0,1,4]  R138      2.6333945989608765e-01
    z[0,1,4]  R139      2.4770571291446686e-01
    z[0,1,4]  R140      2.1385875344276428e-01
    z[0,1,4]  R141      6.0413964092731476e-02
    z[0,1,4]  R142      -2.5798571109771729e-01
    z[0,1,4]  R143      -1.1370173841714859e-01
    z[0,1,4]  R144      0.359660267829895
    z[0,1,4]  R145      5.8230042457580566e-02
    z[0,1,4]  R146      1.2516547739505768e-01
    z[0,1,4]  R147      -3.8943123072385788e-02
    z[0,1,4]  R148      -5.8395609259605408e-02
    z[0,1,4]  R149      0.284589558839798
    z[0,1,4]  R150      -3.4502550959587097e-01
    z[0,1,4]  R151      -6.8094119429588318e-02
    z[0,1,4]  R152      -7.7331632375717163e-02
    z[0,1,4]  R153      2.8215774893760681e-01
    z[0,1,4]  R154      1.0871417075395584e-01
    z[0,1,4]  R155      -1.9560030195862055e-03
    z[0,1,4]  R156      -1.1534772813320160e-01
    z[0,1,4]  R157      1.9251872599124908e-01
    z[0,1,4]  R158      0.0800652801990509
    z[0,1,4]  R159      1.9722582772374153e-02
    z[0,1,4]  R160      5.0033140927553177e-02
    z[0,1,4]  R161      -2.4309885501861572e-01
    z[0,1,4]  R162      9.8878055810928345e-02
    z[0,1,4]  R163      5.3946918249130249e-01
    z[0,1,4]  R164      1.6274869441986084e-01
    z[0,1,4]  R165      -4.7675538808107376e-03
    z[0,1,4]  R166      4.3188986182212830e-01
    z[0,1,4]  R167      5.1608490943908691e-01
    z[0,1,4]  R168      2.9394540190696716e-01
    z[0,1,4]  R169      3.0264088511466980e-01
    z[0,1,4]  R170      -2.4297304451465607e-01
    z[0,1,4]  R171      8.8915683329105377e-02
    z[0,1,4]  R172      -1.4465685188770294e-01
    z[0,1,4]  R173      2.0642970502376556e-01
    z[0,1,4]  R174      0.0165670458227396
    z[0,1,4]  R175      1.5591670572757721e-01
    z[0,1,4]  R176      -3.9095267653465271e-01
    z[0,1,4]  R177      -3.1944859027862549e-01
    z[0,1,4]  R178      -1.4721493422985077e-01
    z[0,1,4]  R179      -7.3048636317253113e-02
    z[0,1,4]  R180      -1.7148011922836304e-01
    z[0,1,4]  R181      2.5958020705729723e-03
    z[0,1,4]  R182      -2.9093879461288452e-01
    z[0,1,4]  R183      2.5505632162094116e-01
    z[0,1,4]  R184      1.1303497850894928e-01
    z[0,1,4]  R185      -1.7424583435058594e-01
    z[0,1,4]  R186      2.5406765937805176e-01
    z[0,1,4]  R187      1.4704677462577820e-01
    z[0,1,4]  R188      2.4635745584964752e-01
    z[0,1,4]  R189      -1.2593010067939758e-01
    z[0,1,4]  R190      1.5354084782302380e-02
    z[0,1,4]  R191      -4.7705590724945068e-01
    z[0,1,4]  R192      -1.6764181852340698e-01
    z[0,1,4]  R193      -0.574489414691925
    z[0,1,4]  R194      -3.4584525227546692e-01
    z[0,1,4]  R195      -4.5444545149803162e-01
    z[0,1,4]  R196      -1.6103319823741913e-01
    z[0,1,4]  R197      -2.2824855521321297e-02
    z[0,1,4]  R198      -4.4511345028877258e-01
    z[0,1,4]  R199      4.6262344717979431e-01
    z[0,1,4]  R200      -6.3724958896636963e-01
    z[0,1,4]  R201      1.2856112420558929e-01
    z[0,1,4]  R202      -5.1871067285537720e-01
    z[0,1,4]  R203      4.2378249764442444e-01
    z[0,1,4]  R204      -3.9718228578567505e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R102      -1
    z[0,1,5]  R103      1
    z[0,1,5]  R106      1.9684407114982605e-01
    z[0,1,5]  R107      2.1400873363018036e-01
    z[0,1,5]  R108      1.7545576393604279e-01
    z[0,1,5]  R109      -8.3863191306591034e-02
    z[0,1,5]  R110      3.5342969000339508e-02
    z[0,1,5]  R111      -2.2698865830898285e-01
    z[0,1,5]  R112      3.7799999117851257e-01
    z[0,1,5]  R113      -7.9122260212898254e-03
    z[0,1,5]  R114      2.4082399904727936e-01
    z[0,1,5]  R115      1.1017414927482605e-01
    z[0,1,5]  R116      3.6226198077201843e-01
    z[0,1,5]  R117      3.0144955962896347e-02
    z[0,1,5]  R118      1.4294551312923431e-01
    z[0,1,5]  R119      1.7544165253639221e-01
    z[0,1,5]  R120      2.3372095823287964e-01
    z[0,1,5]  R121      4.1231876611709595e-01
    z[0,1,5]  R122      3.9987576007843018e-01
    z[0,1,5]  R123      4.1314443945884705e-01
    z[0,1,5]  R124      3.3306348323822021e-01
    z[0,1,5]  R125      1.6043521463871002e-01
    z[0,1,5]  R126      -5.6281950324773788e-02
    z[0,1,5]  R127      -3.6464065313339233e-01
    z[0,1,5]  R128      -3.4621521830558777e-01
    z[0,1,5]  R129      -4.0698921680450439e-01
    z[0,1,5]  R130      -4.0686112642288208e-01
    z[0,1,5]  R131      -2.8368967771530151e-01
    z[0,1,5]  R132      -1.4950375258922577e-01
    z[0,1,5]  R133      -2.9358950257301331e-01
    z[0,1,5]  R134      9.5859030261635780e-03
    z[0,1,5]  R135      -3.9522635936737061e-01
    z[0,1,5]  R136      -1.6145195066928864e-01
    z[0,1,5]  R137      -1.9120676815509796e-01
    z[0,1,5]  R138      -1.1766610294580460e-01
    z[0,1,5]  R139      -2.3118594661355019e-02
    z[0,1,5]  R140      -8.8029861450195312e-02
    z[0,1,5]  R141      -1.0294277220964432e-01
    z[0,1,5]  R142      -3.1823366880416870e-01
    z[0,1,5]  R143      -2.9804265499114990e-01
    z[0,1,5]  R144      -3.8015264272689819e-01
    z[0,1,5]  R145      -5.3212952613830566e-01
    z[0,1,5]  R146      -1.7609718441963196e-01
    z[0,1,5]  R147      -2.2707961499691010e-01
    z[0,1,5]  R148      -2.2068646550178528e-01
    z[0,1,5]  R149      -3.7052431702613831e-01
    z[0,1,5]  R150      1.1809995397925377e-02
    z[0,1,5]  R151      -1.8104976415634155e-01
    z[0,1,5]  R152      1.3202938437461853e-01
    z[0,1,5]  R153      -9.1548189520835876e-03
    z[0,1,5]  R154      -8.9364543557167053e-02
    z[0,1,5]  R155      4.1444590687751770e-01
    z[0,1,5]  R156      7.5835309922695160e-02
    z[0,1,5]  R157      7.5173109769821167e-02
    z[0,1,5]  R158      -1.4381489157676697e-01
    z[0,1,5]  R159      -2.3718622326850891e-01
    z[0,1,5]  R160      -3.9254122972488403e-01
    z[0,1,5]  R161      -6.2953993678092957e-02
    z[0,1,5]  R162      -5.6849384307861328e-01
    z[0,1,5]  R163      3.0457329750061035e-01
    z[0,1,5]  R164      4.8995118588209152e-02
    z[0,1,5]  R165      2.5946235656738281e-01
    z[0,1,5]  R166      -2.1859265863895416e-01
    z[0,1,5]  R167      -4.8749871551990509e-02
    z[0,1,5]  R168      -2.3280568420886993e-01
    z[0,1,5]  R169      2.9659522697329521e-02
    z[0,1,5]  R170      -9.1489471495151520e-02
    z[0,1,5]  R171      -2.2897738218307495e-01
    z[0,1,5]  R172      -3.7888392806053162e-01
    z[0,1,5]  R173      -2.6533809304237366e-01
    z[0,1,5]  R174      -2.4617217481136322e-01
    z[0,1,5]  R175      -6.3933007419109344e-02
    z[0,1,5]  R176      2.6166521012783051e-02
    z[0,1,5]  R177      1.9349291920661926e-02
    z[0,1,5]  R178      -9.4485692679882050e-02
    z[0,1,5]  R179      -4.1054549813270569e-01
    z[0,1,5]  R180      -2.8887656331062317e-01
    z[0,1,5]  R181      -1.6198687255382538e-02
    z[0,1,5]  R182      -5.9515470266342163e-01
    z[0,1,5]  R183      0.511829674243927
    z[0,1,5]  R184      -1.7855094745755196e-02
    z[0,1,5]  R185      7.9831105470657349e-01
    z[0,1,5]  R186      -4.5378437638282776e-01
    z[0,1,5]  R187      -3.8740321993827820e-02
    z[0,1,5]  R188      5.1221899688243866e-02
    z[0,1,5]  R189      4.3502485752105713e-01
    z[0,1,5]  R190      2.8338757157325745e-01
    z[0,1,5]  R191      -5.8941155672073364e-01
    z[0,1,5]  R192      7.1740388870239258e-01
    z[0,1,5]  R193      4.7157999873161316e-01
    z[0,1,5]  R194      6.4506232738494873e-01
    z[0,1,5]  R195      0.470276415348053
    z[0,1,5]  R196      -2.1214704215526581e-01
    z[0,1,5]  R197      6.2924438714981079e-01
    z[0,1,5]  R198      3.6016049981117249e-01
    z[0,1,5]  R199      4.0202996134757996e-01
    z[0,1,5]  R200      1.5639634430408478e-01
    z[0,1,5]  R201      3.5411562770605087e-02
    z[0,1,5]  R202      1.5060894191265106e-01
    z[0,1,5]  R203      -1.3921947777271271e-01
    z[0,1,5]  R204      0.310105562210083
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R104      -1
    z[0,1,6]  R105      1
    z[0,1,6]  R106      -2.3867608606815338e-01
    z[0,1,6]  R107      -2.8994879126548767e-01
    z[0,1,6]  R108      2.2076773643493652e-01
    z[0,1,6]  R109      -3.2592701911926270e-01
    z[0,1,6]  R110      -3.1702980399131775e-02
    z[0,1,6]  R111      1.8523052334785461e-01
    z[0,1,6]  R112      1.6725838184356689e-01
    z[0,1,6]  R113      8.6627446115016937e-02
    z[0,1,6]  R114      2.2655488550662994e-01
    z[0,1,6]  R115      2.8011319041252136e-01
    z[0,1,6]  R116      0.245841383934021
    z[0,1,6]  R117      0.097848080098629
    z[0,1,6]  R118      -1.8725836277008057e-01
    z[0,1,6]  R119      -2.1693013608455658e-02
    z[0,1,6]  R120      3.1365182995796204e-01
    z[0,1,6]  R121      1.1375698447227478e-01
    z[0,1,6]  R122      9.7162231802940369e-02
    z[0,1,6]  R123      -1.0808359831571579e-01
    z[0,1,6]  R124      -6.4100623130798340e-02
    z[0,1,6]  R125      1.3626888394355774e-01
    z[0,1,6]  R126      -1.7072747647762299e-01
    z[0,1,6]  R127      -3.0899396166205406e-02
    z[0,1,6]  R128      -4.1400483250617981e-01
    z[0,1,6]  R129      -8.5938654839992523e-02
    z[0,1,6]  R130      -1.3139389455318451e-01
    z[0,1,6]  R131      -1.9289404153823853e-01
    z[0,1,6]  R132      2.1805499494075775e-01
    z[0,1,6]  R133      -3.6004860885441303e-03
    z[0,1,6]  R134      -1.7021040618419647e-01
    z[0,1,6]  R135      -8.1121474504470825e-03
    z[0,1,6]  R136      -8.0257803201675415e-02
    z[0,1,6]  R137      0.00755949504673481
    z[0,1,6]  R138      -9.6115969121456146e-02
    z[0,1,6]  R139      -9.2945620417594910e-02
    z[0,1,6]  R140      2.6474019885063171e-01
    z[0,1,6]  R141      -4.0284439921379089e-01
    z[0,1,6]  R142      6.5613955259323120e-02
    z[0,1,6]  R143      4.5896759629249573e-01
    z[0,1,6]  R144      -1.4630749821662903e-01
    z[0,1,6]  R145      -2.8226310014724731e-01
    z[0,1,6]  R146      -0.154501274228096
    z[0,1,6]  R147      2.2523556649684906e-01
    z[0,1,6]  R148      3.8888379931449890e-01
    z[0,1,6]  R149      -3.0032485723495483e-01
    z[0,1,6]  R150      3.7741836905479431e-01
    z[0,1,6]  R151      -3.9454710483551025e-01
    z[0,1,6]  R152      1.6951330006122589e-01
    z[0,1,6]  R153      -1.9711382687091827e-01
    z[0,1,6]  R154      -3.0246462672948837e-02
    z[0,1,6]  R155      -1.7947243154048920e-01
    z[0,1,6]  R156      -2.1330793201923370e-01
    z[0,1,6]  R157      -2.7563467621803284e-01
    z[0,1,6]  R158      -3.2324469089508057e-01
    z[0,1,6]  R159      6.4031504094600677e-02
    z[0,1,6]  R160      -1.0182687640190125e-01
    z[0,1,6]  R161      -8.6366616189479828e-02
    z[0,1,6]  R162      2.0609053969383240e-01
    z[0,1,6]  R163      7.7185044065117836e-03
    z[0,1,6]  R164      3.2198838889598846e-02
    z[0,1,6]  R165      0.0327945351600647
    z[0,1,6]  R166      -7.4649795889854431e-02
    z[0,1,6]  R167      -2.7094435691833496e-01
    z[0,1,6]  R168      -4.0650174021720886e-01
    z[0,1,6]  R169      2.6229172945022583e-01
    z[0,1,6]  R170      1.0801345109939575e-01
    z[0,1,6]  R171      2.3452107608318329e-01
    z[0,1,6]  R172      -1.5046596527099609e-01
    z[0,1,6]  R173      -3.5242381691932678e-01
    z[0,1,6]  R174      -4.3461519479751587e-01
    z[0,1,6]  R175      4.4097259640693665e-01
    z[0,1,6]  R176      2.9650470614433289e-01
    z[0,1,6]  R177      -7.0150340907275677e-03
    z[0,1,6]  R178      -1.3066437840461731e-01
    z[0,1,6]  R179      3.5713097453117371e-01
    z[0,1,6]  R180      7.8432798385620117e-02
    z[0,1,6]  R181      3.3497631549835205e-01
    z[0,1,6]  R182      -1.4120413362979889e-01
    z[0,1,6]  R183      0.427981436252594
    z[0,1,6]  R184      2.2896234691143036e-01
    z[0,1,6]  R185      -2.4735176935791969e-02
    z[0,1,6]  R186      7.2249300777912140e-02
    z[0,1,6]  R187      5.3443264961242676e-01
    z[0,1,6]  R188      4.0446621179580688e-01
    z[0,1,6]  R189      -9.1245517134666443e-02
    z[0,1,6]  R190      3.2425481826066971e-02
    z[0,1,6]  R191      -4.0871286392211914e-01
    z[0,1,6]  R192      -3.4263423085212708e-01
    z[0,1,6]  R193      2.3423831164836884e-01
    z[0,1,6]  R194      7.5188823044300079e-02
    z[0,1,6]  R195      1.8589356541633606e-01
    z[0,1,6]  R196      -6.1101114749908447e-01
    z[0,1,6]  R197      -7.7761389315128326e-02
    z[0,1,6]  R198      -4.8468500375747681e-01
    z[0,1,6]  R199      -2.3520238697528839e-01
    z[0,1,6]  R200      1.2026961892843246e-01
    z[0,1,6]  R201      -2.5747832655906677e-01
    z[0,1,6]  R202      9.4179525971412659e-02
    z[0,1,6]  R203      -1.6847959160804749e-01
    z[0,1,6]  R204      -2.7254357933998108e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R205      -1
    z[1,0,0]  R206      1
    z[1,0,0]  R219      2.8589609265327454e-01
    z[1,0,0]  R220      4.8036411404609680e-01
    z[1,0,0]  R221      2.5183260440826416e-01
    z[1,0,0]  R222      3.0372983217239380e-01
    z[1,0,0]  R223      -9.2242234945297241e-01
    z[1,0,0]  R224      -8.9510083198547363e-01
    z[1,0,0]  R225      1.8954648077487946e-01
    z[1,0,0]  R226      -8.5063797235488892e-01
    z[1,0,0]  R227      -8.1500744819641113e-01
    z[1,0,0]  R228      -8.3995550870895386e-01
    z[1,0,0]  R229      8.3946204185485840e-01
    z[1,0,0]  R230      8.5628277063369751e-01
    z[1,0,0]  R231      7.4340730905532837e-01
    z[1,0,0]  R232      7.0932799577713013e-01
    z[1,0,0]  R233      8.0658096075057983e-01
    z[1,0,0]  R234      8.5277885198593140e-01
    z[1,0,0]  R235      6.2278401851654053e-01
    z[1,0,0]  R236      5.2813696861267090e-01
    z[1,0,0]  R237      6.4491635560989380e-01
    z[1,0,0]  R238      4.3566048145294189e-01
    z[1,0,0]  R239      8.1669247150421143e-01
    z[1,0,0]  R240      7.2770011425018311e-01
    z[1,0,0]  R241      5.3186315298080444e-01
    z[1,0,0]  R242      -6.5128237009048462e-01
    z[1,0,0]  R243      8.2274824380874634e-01
    z[1,0,0]  R244      4.9348068237304688e-01
    z[1,0,0]  R245      3.7716588377952576e-01
    z[1,0,0]  R246      -9.0435231104493141e-03
    z[1,0,0]  R247      -6.4122684299945831e-02
    z[1,0,0]  R248      -1.5305294096469879e-01
    z[1,0,0]  R249      7.0274728536605835e-01
    z[1,0,0]  R250      5.2221375703811646e-01
    z[1,0,0]  R251      4.7327014803886414e-01
    z[1,0,0]  R252      5.6887823343276978e-01
    z[1,0,0]  R253      9.1267181560397148e-03
    z[1,0,0]  R254      0.031141497194767
    z[1,0,0]  R255      1.1161900311708450e-01
    z[1,0,0]  R256      -1.6556279733777046e-02
    z[1,0,0]  R257      -1.8656864762306213e-01
    z[1,0,0]  R258      3.1617248058319092e-01
    z[1,0,0]  R259      5.7669192552566528e-01
    z[1,0,0]  R260      4.7605317831039429e-01
    z[1,0,0]  R261      4.6785807609558105e-01
    z[1,0,0]  R262      8.7497037649154663e-01
    z[1,0,0]  R263      7.1143907308578491e-01
    z[1,0,0]  R264      6.8296575546264648e-01
    z[1,0,0]  R265      8.1498926877975464e-01
    z[1,0,0]  R266      0.185358464717865
    z[1,0,0]  R267      4.7616714239120483e-01
    z[1,0,0]  R268      -4.9223318696022034e-01
    z[1,0,0]  R269      -5.4711413383483887e-01
    z[1,0,0]  R270      -2.4950566887855530e-01
    z[1,0,0]  R271      -4.1189306974411011e-01
    z[1,0,0]  R272      -3.0863013863563538e-01
    z[1,0,0]  R273      -4.8976475000381470e-01
    z[1,0,0]  R274      -1.5400357544422150e-01
    z[1,0,0]  R275      -4.3866270780563354e-01
    z[1,0,0]  R276      -4.7704404592514038e-01
    z[1,0,0]  R277      -2.4821718037128448e-01
    z[1,0,0]  R278      1.1715054512023926e-01
    z[1,0,0]  R279      -7.2085000574588776e-02
    z[1,0,0]  R280      -7.1591906249523163e-02
    z[1,0,0]  R281      2.9847750067710876e-01
    z[1,0,0]  R282      -4.2866292595863342e-01
    z[1,0,0]  R283      -0.407634973526001
    z[1,0,0]  R284      -3.9184358716011047e-01
    z[1,0,0]  R285      -5.7812762260437012e-01
    z[1,0,0]  R286      2.7833279222249985e-02
    z[1,0,0]  R287      -2.9819878935813904e-01
    z[1,0,0]  R288      6.3001766800880432e-02
    z[1,0,0]  R289      0.0899825319647789
    z[1,0,0]  R290      2.5428640842437744e-01
    z[1,0,0]  R291      3.2596611976623535e-01
    z[1,0,0]  R292      3.4396609663963318e-01
    z[1,0,0]  R293      -2.6913258433341980e-01
    z[1,0,0]  R294      -2.6759406924247742e-01
    z[1,0,0]  R295      3.4607195854187012e-01
    z[1,0,0]  R296      4.3527016043663025e-01
    z[1,0,0]  R297      -1.2859259545803070e-01
    z[1,0,0]  R298      9.0489076683297753e-04
    z[1,0,0]  R299      1.2812386453151703e-01
    z[1,0,0]  R300      2.0964090526103973e-01
    z[1,0,0]  R301      3.1280410289764404e-01
    z[1,0,0]  R302      1.2833017110824585e-01
    z[1,0,0]  R303      -0.756442666053772
    z[1,0,0]  R304      -3.5724371671676636e-01
    z[1,0,0]  R305      -3.8763898611068726e-01
    z[1,0,0]  R306      -2.8695088624954224e-01
    z[1,0,0]  R307      -5.0645190477371216e-01
    z[1,0,0]  R308      -6.2723271548748016e-02
    z[1,0,0]  R309      1.7746257781982422e-01
    z[1,0,0]  R310      -7.8412890434265137e-01
    z[1,0,0]  R311      -3.7134975194931030e-01
    z[1,0,0]  R312      -4.2428565025329590e-01
    z[1,0,0]  R313      -3.3557087182998657e-01
    z[1,0,0]  R314      -1.0943162441253662e-01
    z[1,0,0]  R315      -4.9729606509208679e-01
    z[1,0,0]  R316      -8.1524938344955444e-01
    z[1,0,0]  R317      -7.9225832223892212e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R207      -1
    z[1,0,1]  R208      1
    z[1,0,1]  R219      -3.8261207938194275e-01
    z[1,0,1]  R220      -3.9298757910728455e-01
    z[1,0,1]  R221      -3.2411766052246094e-01
    z[1,0,1]  R222      -3.6309796571731567e-01
    z[1,0,1]  R223      1.9612239301204681e-01
    z[1,0,1]  R224      9.2389337718486786e-02
    z[1,0,1]  R225      -2.6568973064422607e-01
    z[1,0,1]  R226      -5.6720346212387085e-02
    z[1,0,1]  R227      1.1615302413702011e-01
    z[1,0,1]  R228      1.9600871205329895e-01
    z[1,0,1]  R229      -1.3788338005542755e-01
    z[1,0,1]  R230      -1.0093265026807785e-01
    z[1,0,1]  R231      -1.5189656615257263e-01
    z[1,0,1]  R232      4.3319123983383179e-01
    z[1,0,1]  R233      2.6871562004089355e-01
    z[1,0,1]  R234      2.2296649217605591e-01
    z[1,0,1]  R235      3.8540813326835632e-01
    z[1,0,1]  R236      -1.6456307470798492e-01
    z[1,0,1]  R237      -6.5834693610668182e-02
    z[1,0,1]  R238      -3.2170256972312927e-01
    z[1,0,1]  R239      2.3825766146183014e-01
    z[1,0,1]  R240      2.3456817865371704e-01
    z[1,0,1]  R241      -1.9221548736095428e-01
    z[1,0,1]  R242      -4.4710376858711243e-01
    z[1,0,1]  R243      -1.9863858819007874e-01
    z[1,0,1]  R244      -9.1180332005023956e-02
    z[1,0,1]  R245      -4.1659852862358093e-01
    z[1,0,1]  R246      -2.4918284267187119e-02
    z[1,0,1]  R247      -1.6778963804244995e-01
    z[1,0,1]  R248      -2.7185013890266418e-01
    z[1,0,1]  R249      -1.0604806989431381e-01
    z[1,0,1]  R250      -2.2762747108936310e-01
    z[1,0,1]  R251      -3.9906290173530579e-01
    z[1,0,1]  R252      -0.128247931599617
    z[1,0,1]  R253      -1.8021407723426819e-01
    z[1,0,1]  R254      8.3533596992492676e-01
    z[1,0,1]  R255      2.8546115756034851e-01
    z[1,0,1]  R256      2.5662371516227722e-01
    z[1,0,1]  R257      -3.9189425110816956e-01
    z[1,0,1]  R258      -2.2488594055175781e-01
    z[1,0,1]  R259      -1.2939150631427765e-01
    z[1,0,1]  R260      -2.1679200232028961e-01
    z[1,0,1]  R261      -4.0721505880355835e-01
    z[1,0,1]  R262      -1.8201905488967896e-01
    z[1,0,1]  R263      -3.6664776504039764e-02
    z[1,0,1]  R264      -3.5846021771430969e-01
    z[1,0,1]  R265      -2.6038247346878052e-01
    z[1,0,1]  R266      -6.8155348300933838e-01
    z[1,0,1]  R267      -2.8164952993392944e-01
    z[1,0,1]  R268      6.2968921661376953e-01
    z[1,0,1]  R269      6.2375122308731079e-01
    z[1,0,1]  R270      6.4590960741043091e-01
    z[1,0,1]  R271      8.7937724590301514e-01
    z[1,0,1]  R272      7.2811561822891235e-01
    z[1,0,1]  R273      4.4551664590835571e-01
    z[1,0,1]  R274      7.0651078224182129e-01
    z[1,0,1]  R275      6.0509574413299561e-01
    z[1,0,1]  R276      4.0943464636802673e-01
    z[1,0,1]  R277      0.868427574634552
    z[1,0,1]  R278      7.7697628736495972e-01
    z[1,0,1]  R279      8.2676619291305542e-01
    z[1,0,1]  R280      7.4282425642013550e-01
    z[1,0,1]  R281      5.9907871484756470e-01
    z[1,0,1]  R282      3.6086297035217285e-01
    z[1,0,1]  R283      -5.0757569074630737e-01
    z[1,0,1]  R284      1.7272317409515381e-01
    z[1,0,1]  R285      -3.2708102464675903e-01
    z[1,0,1]  R286      4.5395290851593018e-01
    z[1,0,1]  R287      -2.8362569212913513e-01
    z[1,0,1]  R288      9.4584661722183228e-01
    z[1,0,1]  R289      8.3826774358749390e-01
    z[1,0,1]  R290      7.8720378875732422e-01
    z[1,0,1]  R291      8.5944074392318726e-01
    z[1,0,1]  R292      7.4405682086944580e-01
    z[1,0,1]  R293      8.2526820898056030e-01
    z[1,0,1]  R294      7.6957190036773682e-01
    z[1,0,1]  R295      0.693574070930481
    z[1,0,1]  R296      7.0397454500198364e-01
    z[1,0,1]  R297      7.1981674432754517e-01
    z[1,0,1]  R298      8.8600194454193115e-01
    z[1,0,1]  R299      8.1919866800308228e-01
    z[1,0,1]  R300      7.5020068883895874e-01
    z[1,0,1]  R301      7.7050465345382690e-01
    z[1,0,1]  R302      7.8837692737579346e-01
    z[1,0,1]  R303      3.5375913977622986e-01
    z[1,0,1]  R304      3.5882890224456787e-01
    z[1,0,1]  R305      2.7233263850212097e-01
    z[1,0,1]  R306      -6.9074638187885284e-02
    z[1,0,1]  R307      3.1501409411430359e-01
    z[1,0,1]  R308      9.6092832088470459e-01
    z[1,0,1]  R309      9.0106505155563354e-01
    z[1,0,1]  R310      3.6725702881813049e-01
    z[1,0,1]  R311      -4.7007972002029419e-01
    z[1,0,1]  R312      -2.9570633172988892e-01
    z[1,0,1]  R313      3.7011715769767761e-01
    z[1,0,1]  R314      -5.1091857254505157e-02
    z[1,0,1]  R315      -3.9350786805152893e-01
    z[1,0,1]  R316      -0.486627459526062
    z[1,0,1]  R317      -5.2580362558364868e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R209      -1
    z[1,0,2]  R210      1
    z[1,0,2]  R219      0.648175835609436
    z[1,0,2]  R220      5.1874715089797974e-01
    z[1,0,2]  R221      7.2205990552902222e-01
    z[1,0,2]  R222      7.5782293081283569e-01
    z[1,0,2]  R223      -1.7612613737583160e-01
    z[1,0,2]  R224      -8.2908622920513153e-02
    z[1,0,2]  R225      7.3629534244537354e-01
    z[1,0,2]  R226      -1.1637032777070999e-01
    z[1,0,2]  R227      -1.9568027555942535e-01
    z[1,0,2]  R228      3.8976226001977921e-02
    z[1,0,2]  R229      -1.4966638386249542e-01
    z[1,0,2]  R230      -3.7048918008804321e-01
    z[1,0,2]  R231      -5.0181216001510620e-01
    z[1,0,2]  R232      -8.3484664559364319e-02
    z[1,0,2]  R233      -3.1613492965698242e-01
    z[1,0,2]  R234      -3.1253471970558167e-01
    z[1,0,2]  R235      -0.0691266879439354
    z[1,0,2]  R236      -3.6677503585815430e-01
    z[1,0,2]  R237      -3.1109884381294250e-01
    z[1,0,2]  R238      -1.1346743442118168e-02
    z[1,0,2]  R239      -2.7712648734450340e-03
    z[1,0,2]  R240      1.8844065070152283e-01
    z[1,0,2]  R241      -3.8060847669839859e-02
    z[1,0,2]  R242      0.398979514837265
    z[1,0,2]  R243      -2.3419651389122009e-01
    z[1,0,2]  R244      4.8064128495752811e-03
    z[1,0,2]  R245      -1.5498661994934082e-01
    z[1,0,2]  R246      -3.3935699611902237e-02
    z[1,0,2]  R247      -2.2759050130844116e-01
    z[1,0,2]  R248      -2.8109228610992432e-01
    z[1,0,2]  R249      -0.0703529641032219
    z[1,0,2]  R250      1.8172599375247955e-01
    z[1,0,2]  R251      1.3317517936229706e-01
    z[1,0,2]  R252      -4.1968944668769836e-01
    z[1,0,2]  R253      -4.6865735203027725e-02
    z[1,0,2]  R254      -3.4458798170089722e-01
    z[1,0,2]  R255      2.2251743078231812e-01
    z[1,0,2]  R256      6.3858158886432648e-02
    z[1,0,2]  R257      -2.3983417451381683e-01
    z[1,0,2]  R258      6.9641411304473877e-01
    z[1,0,2]  R259      6.1756026744842529e-01
    z[1,0,2]  R260      0.746904730796814
    z[1,0,2]  R261      4.7763559222221375e-01
    z[1,0,2]  R262      3.4936192631721497e-01
    z[1,0,2]  R263      5.7652479410171509e-01
    z[1,0,2]  R264      2.7917012572288513e-01
    z[1,0,2]  R265      7.9882211983203888e-02
    z[1,0,2]  R266      4.9595010280609131e-01
    z[1,0,2]  R267      -3.1767857726663351e-03
    z[1,0,2]  R268      -3.7552466988563538e-01
    z[1,0,2]  R269      -5.4819935560226440e-01
    z[1,0,2]  R270      -5.2614951133728027e-01
    z[1,0,2]  R271      -1.4535656571388245e-01
    z[1,0,2]  R272      -3.7699118256568909e-01
    z[1,0,2]  R273      -5.6106412410736084e-01
    z[1,0,2]  R274      -4.4130784273147583e-01
    z[1,0,2]  R275      -4.3506258726119995e-01
    z[1,0,2]  R276      -5.6248861551284790e-01
    z[1,0,2]  R277      -3.6139541864395142e-01
    z[1,0,2]  R278      1.6493658721446991e-01
    z[1,0,2]  R279      1.7390790581703186e-01
    z[1,0,2]  R280      3.4230497479438782e-01
    z[1,0,2]  R281      -1.2580266594886780e-01
    z[1,0,2]  R282      -1.4868043363094330e-01
    z[1,0,2]  R283      -1.2460289150476456e-01
    z[1,0,2]  R284      -0.503728985786438
    z[1,0,2]  R285      8.4312453866004944e-02
    z[1,0,2]  R286      -2.4389077723026276e-01
    z[1,0,2]  R287      -3.0800363421440125e-01
    z[1,0,2]  R288      1.3863548636436462e-01
    z[1,0,2]  R289      -2.7512248605489731e-02
    z[1,0,2]  R290      -6.1390563845634460e-02
    z[1,0,2]  R291      -1.9287452101707458e-01
    z[1,0,2]  R292      -3.9840704202651978e-01
    z[1,0,2]  R293      -1.1714725941419601e-01
    z[1,0,2]  R294      -2.4716173112392426e-01
    z[1,0,2]  R295      -2.9159530997276306e-01
    z[1,0,2]  R296      -1.0140753537416458e-01
    z[1,0,2]  R297      -3.0194488167762756e-01
    z[1,0,2]  R298      -1.9755041599273682e-01
    z[1,0,2]  R299      -2.4487484991550446e-01
    z[1,0,2]  R300      -0.43577840924263
    z[1,0,2]  R301      -1.1846154229715466e-03
    z[1,0,2]  R302      7.1419939398765564e-02
    z[1,0,2]  R303      -1.8547539412975311e-01
    z[1,0,2]  R304      -3.4186357259750366e-01
    z[1,0,2]  R305      -5.1645022630691528e-01
    z[1,0,2]  R306      -1.0560575872659683e-01
    z[1,0,2]  R307      -1.4410842955112457e-01
    z[1,0,2]  R308      6.8419404327869415e-02
    z[1,0,2]  R309      -4.0451448410749435e-02
    z[1,0,2]  R310      -1.9884806871414185e-01
    z[1,0,2]  R311      -2.1745659410953522e-01
    z[1,0,2]  R312      -2.4599377810955048e-01
    z[1,0,2]  R313      2.0575824379920959e-01
    z[1,0,2]  R314      -4.7127166390419006e-01
    z[1,0,2]  R315      1.4961537718772888e-01
    z[1,0,2]  R316      -1.8319293856620789e-01
    z[1,0,2]  R317      -1.3706816732883453e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R211      -1
    z[1,0,3]  R212      1
    z[1,0,3]  R219      3.3444768190383911e-01
    z[1,0,3]  R220      5.9844911098480225e-02
    z[1,0,3]  R221      -6.5662041306495667e-02
    z[1,0,3]  R222      2.0085911452770233e-01
    z[1,0,3]  R223      -2.4074444547295570e-02
    z[1,0,3]  R224      2.6086029410362244e-01
    z[1,0,3]  R225      4.0525501966476440e-01
    z[1,0,3]  R226      1.4978574216365814e-01
    z[1,0,3]  R227      -1.8497286736965179e-01
    z[1,0,3]  R228      -1.7799408733844757e-01
    z[1,0,3]  R229      1.1157047748565674e-01
    z[1,0,3]  R230      -1.2984296679496765e-01
    z[1,0,3]  R231      0.353248655796051
    z[1,0,3]  R232      -2.8343278914690018e-02
    z[1,0,3]  R233      2.4139399826526642e-01
    z[1,0,3]  R234      1.1356934905052185e-01
    z[1,0,3]  R235      5.3709405474364758e-03
    z[1,0,3]  R236      -2.2197966277599335e-01
    z[1,0,3]  R237      0.646101176738739
    z[1,0,3]  R238      -1.9571591913700104e-01
    z[1,0,3]  R239      2.3418139666318893e-02
    z[1,0,3]  R240      -2.6679340004920959e-01
    z[1,0,3]  R241      0.672173798084259
    z[1,0,3]  R242      5.7566784322261810e-02
    z[1,0,3]  R243      3.8364630937576294e-01
    z[1,0,3]  R244      7.8136168420314789e-02
    z[1,0,3]  R245      6.0693745035678148e-04
    z[1,0,3]  R246      -6.2518179416656494e-01
    z[1,0,3]  R247      -6.1202096939086914e-01
    z[1,0,3]  R248      -6.0118412971496582e-01
    z[1,0,3]  R249      2.1372371912002563e-01
    z[1,0,3]  R250      -4.8983451724052429e-01
    z[1,0,3]  R251      1.9044023752212524e-01
    z[1,0,3]  R252      -2.2983053326606750e-01
    z[1,0,3]  R253      -0.721270740032196
    z[1,0,3]  R254      3.1372907757759094e-01
    z[1,0,3]  R255      -7.4560415744781494e-01
    z[1,0,3]  R256      -8.3811295032501221e-01
    z[1,0,3]  R257      -6.5260350704193115e-01
    z[1,0,3]  R258      5.1677453517913818e-01
    z[1,0,3]  R259      1.2330103665590286e-01
    z[1,0,3]  R260      1.6277417540550232e-01
    z[1,0,3]  R261      4.2016741633415222e-01
    z[1,0,3]  R262      2.2670869529247284e-01
    z[1,0,3]  R263      2.6785820722579956e-01
    z[1,0,3]  R264      -1.0430599562823772e-02
    z[1,0,3]  R265      3.7662589550018311e-01
    z[1,0,3]  R266      2.8773674368858337e-01
    z[1,0,3]  R267      7.7458918094635010e-01
    z[1,0,3]  R268      1.6704623401165009e-01
    z[1,0,3]  R269      2.3247901350259781e-02
    z[1,0,3]  R270      4.1320866346359253e-01
    z[1,0,3]  R271      0.0545872300863266
    z[1,0,3]  R272      1.2594187259674072e-01
    z[1,0,3]  R273      1.6451855003833771e-01
    z[1,0,3]  R274      3.3085045218467712e-01
    z[1,0,3]  R275      2.4973908066749573e-01
    z[1,0,3]  R276      3.9302092790603638e-01
    z[1,0,3]  R277      -8.9879669249057770e-02
    z[1,0,3]  R278      -5.6031066179275513e-01
    z[1,0,3]  R279      -9.8044604063034058e-02
    z[1,0,3]  R280      -1.3259139657020569e-01
    z[1,0,3]  R281      -0.507114827632904
    z[1,0,3]  R282      -6.7938894033432007e-01
    z[1,0,3]  R283      -6.5618109703063965e-01
    z[1,0,3]  R284      -6.9857668876647949e-01
    z[1,0,3]  R285      -6.7651957273483276e-01
    z[1,0,3]  R286      -0.729148805141449
    z[1,0,3]  R287      -6.4328622817993164e-01
    z[1,0,3]  R288      6.0929656028747559e-02
    z[1,0,3]  R289      4.4564566016197205e-01
    z[1,0,3]  R290      -4.6845340728759766e-01
    z[1,0,3]  R291      0.217659592628479
    z[1,0,3]  R292      -2.1393077075481415e-01
    z[1,0,3]  R293      -2.3716230690479279e-01
    z[1,0,3]  R294      -3.2082572579383850e-01
    z[1,0,3]  R295      4.1865665465593338e-02
    z[1,0,3]  R296      -9.6946984529495239e-02
    z[1,0,3]  R297      8.9062482118606567e-02
    z[1,0,3]  R298      -3.2469424605369568e-01
    z[1,0,3]  R299      -3.8564404845237732e-01
    z[1,0,3]  R300      1.9415273563936353e-03
    z[1,0,3]  R301      -0.000567007577046752
    z[1,0,3]  R302      -0.308651328086853
    z[1,0,3]  R303      2.7416145801544189e-01
    z[1,0,3]  R304      -7.5802463293075562e-01
    z[1,0,3]  R305      -6.2473946809768677e-01
    z[1,0,3]  R306      -0.938624382019043
    z[1,0,3]  R307      -6.4770805835723877e-01
    z[1,0,3]  R308      5.8693759143352509e-02
    z[1,0,3]  R309      1.9043010473251343e-01
    z[1,0,3]  R310      2.8132423758506775e-01
    z[1,0,3]  R311      -7.3013061285018921e-01
    z[1,0,3]  R312      -7.1067994832992554e-01
    z[1,0,3]  R313      -7.9846704006195068e-01
    z[1,0,3]  R314      -0.622801661491394
    z[1,0,3]  R315      -4.3773502111434937e-01
    z[1,0,3]  R316      1.8729162216186523e-01
    z[1,0,3]  R317      -9.3009635806083679e-02
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R213      -1
    z[1,0,4]  R214      1
    z[1,0,4]  R219      4.3188986182212830e-01
    z[1,0,4]  R220      5.1608490943908691e-01
    z[1,0,4]  R221      2.9394540190696716e-01
    z[1,0,4]  R222      3.0264088511466980e-01
    z[1,0,4]  R223      -2.4297304451465607e-01
    z[1,0,4]  R224      8.8915683329105377e-02
    z[1,0,4]  R225      -1.4465685188770294e-01
    z[1,0,4]  R226      2.0642970502376556e-01
    z[1,0,4]  R227      0.0165670458227396
    z[1,0,4]  R228      1.5591670572757721e-01
    z[1,0,4]  R229      -3.9095267653465271e-01
    z[1,0,4]  R230      -3.1944859027862549e-01
    z[1,0,4]  R231      -1.4721493422985077e-01
    z[1,0,4]  R232      -7.3048636317253113e-02
    z[1,0,4]  R233      -1.7148011922836304e-01
    z[1,0,4]  R234      2.5958020705729723e-03
    z[1,0,4]  R235      -2.9093879461288452e-01
    z[1,0,4]  R236      2.5505632162094116e-01
    z[1,0,4]  R237      1.1303497850894928e-01
    z[1,0,4]  R238      -1.7424583435058594e-01
    z[1,0,4]  R239      2.5406765937805176e-01
    z[1,0,4]  R240      1.4704677462577820e-01
    z[1,0,4]  R241      2.4635745584964752e-01
    z[1,0,4]  R242      -1.2593010067939758e-01
    z[1,0,4]  R243      1.5354084782302380e-02
    z[1,0,4]  R244      -4.7705590724945068e-01
    z[1,0,4]  R245      -1.6764181852340698e-01
    z[1,0,4]  R246      -0.574489414691925
    z[1,0,4]  R247      -3.4584525227546692e-01
    z[1,0,4]  R248      -4.5444545149803162e-01
    z[1,0,4]  R249      -1.6103319823741913e-01
    z[1,0,4]  R250      -2.2824855521321297e-02
    z[1,0,4]  R251      -4.4511345028877258e-01
    z[1,0,4]  R252      4.6262344717979431e-01
    z[1,0,4]  R253      -6.3724958896636963e-01
    z[1,0,4]  R254      1.2856112420558929e-01
    z[1,0,4]  R255      -5.1871067285537720e-01
    z[1,0,4]  R256      4.2378249764442444e-01
    z[1,0,4]  R257      -3.9718228578567505e-01
    z[1,0,4]  R258      -4.1218571364879608e-02
    z[1,0,4]  R259      0.352463036775589
    z[1,0,4]  R260      -2.4997876584529877e-01
    z[1,0,4]  R261      3.1200459599494934e-01
    z[1,0,4]  R262      -1.5997199714183807e-01
    z[1,0,4]  R263      -5.0467513501644135e-02
    z[1,0,4]  R264      3.9517077803611755e-01
    z[1,0,4]  R265      -3.3496016263961792e-01
    z[1,0,4]  R266      -2.5108709931373596e-01
    z[1,0,4]  R267      5.7777430862188339e-02
    z[1,0,4]  R268      -2.4556618183851242e-02
    z[1,0,4]  R269      -7.3936069384217262e-03
    z[1,0,4]  R270      1.3218869268894196e-01
    z[1,0,4]  R271      4.1001036763191223e-02
    z[1,0,4]  R272      2.5220713019371033e-01
    z[1,0,4]  R273      1.9193364679813385e-01
    z[1,0,4]  R274      -5.9747759252786636e-02
    z[1,0,4]  R275      -8.6109027266502380e-02
    z[1,0,4]  R276      1.3745196163654327e-01
    z[1,0,4]  R277      0.0350436307489872
    z[1,0,4]  R278      9.5477670431137085e-02
    z[1,0,4]  R279      -3.7079265713691711e-01
    z[1,0,4]  R280      -1.3064685463905334e-01
    z[1,0,4]  R281      3.2557407021522522e-01
    z[1,0,4]  R282      -1.3982348144054413e-01
    z[1,0,4]  R283      1.1141499131917953e-01
    z[1,0,4]  R284      -7.0524394512176514e-02
    z[1,0,4]  R285      8.8269263505935669e-02
    z[1,0,4]  R286      4.1587015986442566e-01
    z[1,0,4]  R287      4.0703928470611572e-01
    z[1,0,4]  R288      -2.1439389884471893e-01
    z[1,0,4]  R289      -2.3072990775108337e-01
    z[1,0,4]  R290      2.6333945989608765e-01
    z[1,0,4]  R291      2.4770571291446686e-01
    z[1,0,4]  R292      2.1385875344276428e-01
    z[1,0,4]  R293      6.0413964092731476e-02
    z[1,0,4]  R294      -2.5798571109771729e-01
    z[1,0,4]  R295      -1.1370173841714859e-01
    z[1,0,4]  R296      0.359660267829895
    z[1,0,4]  R297      5.8230042457580566e-02
    z[1,0,4]  R298      1.2516547739505768e-01
    z[1,0,4]  R299      -3.8943123072385788e-02
    z[1,0,4]  R300      -5.8395609259605408e-02
    z[1,0,4]  R301      0.284589558839798
    z[1,0,4]  R302      -3.4502550959587097e-01
    z[1,0,4]  R303      -6.8094119429588318e-02
    z[1,0,4]  R304      -7.7331632375717163e-02
    z[1,0,4]  R305      2.8215774893760681e-01
    z[1,0,4]  R306      1.0871417075395584e-01
    z[1,0,4]  R307      -1.9560030195862055e-03
    z[1,0,4]  R308      -1.1534772813320160e-01
    z[1,0,4]  R309      1.9251872599124908e-01
    z[1,0,4]  R310      0.0800652801990509
    z[1,0,4]  R311      1.9722582772374153e-02
    z[1,0,4]  R312      5.0033140927553177e-02
    z[1,0,4]  R313      -2.4309885501861572e-01
    z[1,0,4]  R314      9.8878055810928345e-02
    z[1,0,4]  R315      5.3946918249130249e-01
    z[1,0,4]  R316      1.6274869441986084e-01
    z[1,0,4]  R317      -4.7675538808107376e-03
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R215      -1
    z[1,0,5]  R216      1
    z[1,0,5]  R219      -2.1859265863895416e-01
    z[1,0,5]  R220      -4.8749871551990509e-02
    z[1,0,5]  R221      -2.3280568420886993e-01
    z[1,0,5]  R222      2.9659522697329521e-02
    z[1,0,5]  R223      -9.1489471495151520e-02
    z[1,0,5]  R224      -2.2897738218307495e-01
    z[1,0,5]  R225      -3.7888392806053162e-01
    z[1,0,5]  R226      -2.6533809304237366e-01
    z[1,0,5]  R227      -2.4617217481136322e-01
    z[1,0,5]  R228      -6.3933007419109344e-02
    z[1,0,5]  R229      2.6166521012783051e-02
    z[1,0,5]  R230      1.9349291920661926e-02
    z[1,0,5]  R231      -9.4485692679882050e-02
    z[1,0,5]  R232      -4.1054549813270569e-01
    z[1,0,5]  R233      -2.8887656331062317e-01
    z[1,0,5]  R234      -1.6198687255382538e-02
    z[1,0,5]  R235      -5.9515470266342163e-01
    z[1,0,5]  R236      0.511829674243927
    z[1,0,5]  R237      -1.7855094745755196e-02
    z[1,0,5]  R238      7.9831105470657349e-01
    z[1,0,5]  R239      -4.5378437638282776e-01
    z[1,0,5]  R240      -3.8740321993827820e-02
    z[1,0,5]  R241      5.1221899688243866e-02
    z[1,0,5]  R242      4.3502485752105713e-01
    z[1,0,5]  R243      2.8338757157325745e-01
    z[1,0,5]  R244      -5.8941155672073364e-01
    z[1,0,5]  R245      7.1740388870239258e-01
    z[1,0,5]  R246      4.7157999873161316e-01
    z[1,0,5]  R247      6.4506232738494873e-01
    z[1,0,5]  R248      0.470276415348053
    z[1,0,5]  R249      -2.1214704215526581e-01
    z[1,0,5]  R250      6.2924438714981079e-01
    z[1,0,5]  R251      3.6016049981117249e-01
    z[1,0,5]  R252      4.0202996134757996e-01
    z[1,0,5]  R253      1.5639634430408478e-01
    z[1,0,5]  R254      3.5411562770605087e-02
    z[1,0,5]  R255      1.5060894191265106e-01
    z[1,0,5]  R256      -1.3921947777271271e-01
    z[1,0,5]  R257      0.310105562210083
    z[1,0,5]  R258      1.9684407114982605e-01
    z[1,0,5]  R259      2.1400873363018036e-01
    z[1,0,5]  R260      1.7545576393604279e-01
    z[1,0,5]  R261      -8.3863191306591034e-02
    z[1,0,5]  R262      3.5342969000339508e-02
    z[1,0,5]  R263      -2.2698865830898285e-01
    z[1,0,5]  R264      3.7799999117851257e-01
    z[1,0,5]  R265      -7.9122260212898254e-03
    z[1,0,5]  R266      2.4082399904727936e-01
    z[1,0,5]  R267      1.1017414927482605e-01
    z[1,0,5]  R268      3.6226198077201843e-01
    z[1,0,5]  R269      3.0144955962896347e-02
    z[1,0,5]  R270      1.4294551312923431e-01
    z[1,0,5]  R271      1.7544165253639221e-01
    z[1,0,5]  R272      2.3372095823287964e-01
    z[1,0,5]  R273      4.1231876611709595e-01
    z[1,0,5]  R274      3.9987576007843018e-01
    z[1,0,5]  R275      4.1314443945884705e-01
    z[1,0,5]  R276      3.3306348323822021e-01
    z[1,0,5]  R277      1.6043521463871002e-01
    z[1,0,5]  R278      -5.6281950324773788e-02
    z[1,0,5]  R279      -3.6464065313339233e-01
    z[1,0,5]  R280      -3.4621521830558777e-01
    z[1,0,5]  R281      -4.0698921680450439e-01
    z[1,0,5]  R282      -4.0686112642288208e-01
    z[1,0,5]  R283      -2.8368967771530151e-01
    z[1,0,5]  R284      -1.4950375258922577e-01
    z[1,0,5]  R285      -2.9358950257301331e-01
    z[1,0,5]  R286      9.5859030261635780e-03
    z[1,0,5]  R287      -3.9522635936737061e-01
    z[1,0,5]  R288      -1.6145195066928864e-01
    z[1,0,5]  R289      -1.9120676815509796e-01
    z[1,0,5]  R290      -1.1766610294580460e-01
    z[1,0,5]  R291      -2.3118594661355019e-02
    z[1,0,5]  R292      -8.8029861450195312e-02
    z[1,0,5]  R293      -1.0294277220964432e-01
    z[1,0,5]  R294      -3.1823366880416870e-01
    z[1,0,5]  R295      -2.9804265499114990e-01
    z[1,0,5]  R296      -3.8015264272689819e-01
    z[1,0,5]  R297      -5.3212952613830566e-01
    z[1,0,5]  R298      -1.7609718441963196e-01
    z[1,0,5]  R299      -2.2707961499691010e-01
    z[1,0,5]  R300      -2.2068646550178528e-01
    z[1,0,5]  R301      -3.7052431702613831e-01
    z[1,0,5]  R302      1.1809995397925377e-02
    z[1,0,5]  R303      -1.8104976415634155e-01
    z[1,0,5]  R304      1.3202938437461853e-01
    z[1,0,5]  R305      -9.1548189520835876e-03
    z[1,0,5]  R306      -8.9364543557167053e-02
    z[1,0,5]  R307      4.1444590687751770e-01
    z[1,0,5]  R308      7.5835309922695160e-02
    z[1,0,5]  R309      7.5173109769821167e-02
    z[1,0,5]  R310      -1.4381489157676697e-01
    z[1,0,5]  R311      -2.3718622326850891e-01
    z[1,0,5]  R312      -3.9254122972488403e-01
    z[1,0,5]  R313      -6.2953993678092957e-02
    z[1,0,5]  R314      -5.6849384307861328e-01
    z[1,0,5]  R315      3.0457329750061035e-01
    z[1,0,5]  R316      4.8995118588209152e-02
    z[1,0,5]  R317      2.5946235656738281e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R217      -1
    z[1,0,6]  R218      1
    z[1,0,6]  R219      -7.4649795889854431e-02
    z[1,0,6]  R220      -2.7094435691833496e-01
    z[1,0,6]  R221      -4.0650174021720886e-01
    z[1,0,6]  R222      2.6229172945022583e-01
    z[1,0,6]  R223      1.0801345109939575e-01
    z[1,0,6]  R224      2.3452107608318329e-01
    z[1,0,6]  R225      -1.5046596527099609e-01
    z[1,0,6]  R226      -3.5242381691932678e-01
    z[1,0,6]  R227      -4.3461519479751587e-01
    z[1,0,6]  R228      4.4097259640693665e-01
    z[1,0,6]  R229      2.9650470614433289e-01
    z[1,0,6]  R230      -7.0150340907275677e-03
    z[1,0,6]  R231      -1.3066437840461731e-01
    z[1,0,6]  R232      3.5713097453117371e-01
    z[1,0,6]  R233      7.8432798385620117e-02
    z[1,0,6]  R234      3.3497631549835205e-01
    z[1,0,6]  R235      -1.4120413362979889e-01
    z[1,0,6]  R236      0.427981436252594
    z[1,0,6]  R237      2.2896234691143036e-01
    z[1,0,6]  R238      -2.4735176935791969e-02
    z[1,0,6]  R239      7.2249300777912140e-02
    z[1,0,6]  R240      5.3443264961242676e-01
    z[1,0,6]  R241      4.0446621179580688e-01
    z[1,0,6]  R242      -9.1245517134666443e-02
    z[1,0,6]  R243      3.2425481826066971e-02
    z[1,0,6]  R244      -4.0871286392211914e-01
    z[1,0,6]  R245      -3.4263423085212708e-01
    z[1,0,6]  R246      2.3423831164836884e-01
    z[1,0,6]  R247      7.5188823044300079e-02
    z[1,0,6]  R248      1.8589356541633606e-01
    z[1,0,6]  R249      -6.1101114749908447e-01
    z[1,0,6]  R250      -7.7761389315128326e-02
    z[1,0,6]  R251      -4.8468500375747681e-01
    z[1,0,6]  R252      -2.3520238697528839e-01
    z[1,0,6]  R253      1.2026961892843246e-01
    z[1,0,6]  R254      -2.5747832655906677e-01
    z[1,0,6]  R255      9.4179525971412659e-02
    z[1,0,6]  R256      -1.6847959160804749e-01
    z[1,0,6]  R257      -2.7254357933998108e-01
    z[1,0,6]  R258      -2.3867608606815338e-01
    z[1,0,6]  R259      -2.8994879126548767e-01
    z[1,0,6]  R260      2.2076773643493652e-01
    z[1,0,6]  R261      -3.2592701911926270e-01
    z[1,0,6]  R262      -3.1702980399131775e-02
    z[1,0,6]  R263      1.8523052334785461e-01
    z[1,0,6]  R264      1.6725838184356689e-01
    z[1,0,6]  R265      8.6627446115016937e-02
    z[1,0,6]  R266      2.2655488550662994e-01
    z[1,0,6]  R267      2.8011319041252136e-01
    z[1,0,6]  R268      0.245841383934021
    z[1,0,6]  R269      0.097848080098629
    z[1,0,6]  R270      -1.8725836277008057e-01
    z[1,0,6]  R271      -2.1693013608455658e-02
    z[1,0,6]  R272      3.1365182995796204e-01
    z[1,0,6]  R273      1.1375698447227478e-01
    z[1,0,6]  R274      9.7162231802940369e-02
    z[1,0,6]  R275      -1.0808359831571579e-01
    z[1,0,6]  R276      -6.4100623130798340e-02
    z[1,0,6]  R277      1.3626888394355774e-01
    z[1,0,6]  R278      -1.7072747647762299e-01
    z[1,0,6]  R279      -3.0899396166205406e-02
    z[1,0,6]  R280      -4.1400483250617981e-01
    z[1,0,6]  R281      -8.5938654839992523e-02
    z[1,0,6]  R282      -1.3139389455318451e-01
    z[1,0,6]  R283      -1.9289404153823853e-01
    z[1,0,6]  R284      2.1805499494075775e-01
    z[1,0,6]  R285      -3.6004860885441303e-03
    z[1,0,6]  R286      -1.7021040618419647e-01
    z[1,0,6]  R287      -8.1121474504470825e-03
    z[1,0,6]  R288      -8.0257803201675415e-02
    z[1,0,6]  R289      0.00755949504673481
    z[1,0,6]  R290      -9.6115969121456146e-02
    z[1,0,6]  R291      -9.2945620417594910e-02
    z[1,0,6]  R292      2.6474019885063171e-01
    z[1,0,6]  R293      -4.0284439921379089e-01
    z[1,0,6]  R294      6.5613955259323120e-02
    z[1,0,6]  R295      4.5896759629249573e-01
    z[1,0,6]  R296      -1.4630749821662903e-01
    z[1,0,6]  R297      -2.8226310014724731e-01
    z[1,0,6]  R298      -0.154501274228096
    z[1,0,6]  R299      2.2523556649684906e-01
    z[1,0,6]  R300      3.8888379931449890e-01
    z[1,0,6]  R301      -3.0032485723495483e-01
    z[1,0,6]  R302      3.7741836905479431e-01
    z[1,0,6]  R303      -3.9454710483551025e-01
    z[1,0,6]  R304      1.6951330006122589e-01
    z[1,0,6]  R305      -1.9711382687091827e-01
    z[1,0,6]  R306      -3.0246462672948837e-02
    z[1,0,6]  R307      -1.7947243154048920e-01
    z[1,0,6]  R308      -2.1330793201923370e-01
    z[1,0,6]  R309      -2.7563467621803284e-01
    z[1,0,6]  R310      -3.2324469089508057e-01
    z[1,0,6]  R311      6.4031504094600677e-02
    z[1,0,6]  R312      -1.0182687640190125e-01
    z[1,0,6]  R313      -8.6366616189479828e-02
    z[1,0,6]  R314      2.0609053969383240e-01
    z[1,0,6]  R315      7.7185044065117836e-03
    z[1,0,6]  R316      3.2198838889598846e-02
    z[1,0,6]  R317      0.0327945351600647
    z[0,6,0]  R2        -1
    z[0,6,0]  R56       1
    z[0,6,0]  R318      -1
    z[0,6,0]  R319      1
    z[0,6,0]  R332      3.1617248058319092e-01
    z[0,6,0]  R333      5.7669192552566528e-01
    z[0,6,0]  R334      4.7605317831039429e-01
    z[0,6,0]  R335      4.6785807609558105e-01
    z[0,6,0]  R336      8.7497037649154663e-01
    z[0,6,0]  R337      7.1143907308578491e-01
    z[0,6,0]  R338      6.8296575546264648e-01
    z[0,6,0]  R339      8.1498926877975464e-01
    z[0,6,0]  R340      0.185358464717865
    z[0,6,0]  R341      4.7616714239120483e-01
    z[0,6,0]  R342      -4.9223318696022034e-01
    z[0,6,0]  R343      -5.4711413383483887e-01
    z[0,6,0]  R344      -2.4950566887855530e-01
    z[0,6,0]  R345      -4.1189306974411011e-01
    z[0,6,0]  R346      -3.0863013863563538e-01
    z[0,6,0]  R347      -4.8976475000381470e-01
    z[0,6,0]  R348      -1.5400357544422150e-01
    z[0,6,0]  R349      -4.3866270780563354e-01
    z[0,6,0]  R350      -4.7704404592514038e-01
    z[0,6,0]  R351      -2.4821718037128448e-01
    z[0,6,0]  R352      1.1715054512023926e-01
    z[0,6,0]  R353      -7.2085000574588776e-02
    z[0,6,0]  R354      -7.1591906249523163e-02
    z[0,6,0]  R355      2.9847750067710876e-01
    z[0,6,0]  R356      -4.2866292595863342e-01
    z[0,6,0]  R357      -0.407634973526001
    z[0,6,0]  R358      -3.9184358716011047e-01
    z[0,6,0]  R359      -5.7812762260437012e-01
    z[0,6,0]  R360      2.7833279222249985e-02
    z[0,6,0]  R361      -2.9819878935813904e-01
    z[0,6,0]  R362      6.3001766800880432e-02
    z[0,6,0]  R363      0.0899825319647789
    z[0,6,0]  R364      2.5428640842437744e-01
    z[0,6,0]  R365      3.2596611976623535e-01
    z[0,6,0]  R366      3.4396609663963318e-01
    z[0,6,0]  R367      -2.6913258433341980e-01
    z[0,6,0]  R368      -2.6759406924247742e-01
    z[0,6,0]  R369      3.4607195854187012e-01
    z[0,6,0]  R370      4.3527016043663025e-01
    z[0,6,0]  R371      -1.2859259545803070e-01
    z[0,6,0]  R372      9.0489076683297753e-04
    z[0,6,0]  R373      1.2812386453151703e-01
    z[0,6,0]  R374      2.0964090526103973e-01
    z[0,6,0]  R375      3.1280410289764404e-01
    z[0,6,0]  R376      1.2833017110824585e-01
    z[0,6,0]  R377      -0.756442666053772
    z[0,6,0]  R378      -3.5724371671676636e-01
    z[0,6,0]  R379      -3.8763898611068726e-01
    z[0,6,0]  R380      -2.8695088624954224e-01
    z[0,6,0]  R381      -5.0645190477371216e-01
    z[0,6,0]  R382      -6.2723271548748016e-02
    z[0,6,0]  R383      1.7746257781982422e-01
    z[0,6,0]  R384      -7.8412890434265137e-01
    z[0,6,0]  R385      -3.7134975194931030e-01
    z[0,6,0]  R386      -4.2428565025329590e-01
    z[0,6,0]  R387      -3.3557087182998657e-01
    z[0,6,0]  R388      -1.0943162441253662e-01
    z[0,6,0]  R389      -4.9729606509208679e-01
    z[0,6,0]  R390      -8.1524938344955444e-01
    z[0,6,0]  R391      -7.9225832223892212e-01
    z[0,6,0]  R392      5.2997888997197151e-03
    z[0,6,0]  R393      4.1948729753494263e-01
    z[0,6,0]  R394      1.0437027364969254e-01
    z[0,6,0]  R395      1.0525260120630264e-01
    z[0,6,0]  R396      1.1023332178592682e-01
    z[0,6,0]  R397      2.2316236793994904e-01
    z[0,6,0]  R398      2.7278235554695129e-01
    z[0,6,0]  R399      1.1781064420938492e-01
    z[0,6,0]  R400      1.9081214070320129e-01
    z[0,6,0]  R401      -7.6717101037502289e-02
    z[0,6,0]  R402      -4.5044949650764465e-01
    z[0,6,0]  R403      -5.4107826948165894e-01
    z[0,6,0]  R404      -5.1500570774078369e-01
    z[0,6,0]  R405      -3.2864689826965332e-01
    z[0,6,0]  R406      -2.6566559076309204e-01
    z[0,6,0]  R407      -4.6390482783317566e-01
    z[0,6,0]  R408      -3.1404739618301392e-01
    z[0,6,0]  R409      -4.4573992490768433e-01
    z[0,6,0]  R410      -7.2129136323928833e-01
    z[0,6,0]  R411      -3.1751331686973572e-01
    z[0,6,0]  R412      -4.2320832610130310e-01
    z[0,6,0]  R413      3.3356276154518127e-01
    z[0,6,0]  R414      0.257706880569458
    z[0,6,0]  R415      3.8330194354057312e-01
    z[0,6,0]  R416      2.6250192523002625e-01
    z[0,6,0]  R417      1.6237622499465942e-01
    z[0,6,0]  R418      1.7827369272708893e-01
    z[0,6,0]  R419      2.0058463513851166e-01
    z[0,6,0]  R420      3.5954967141151428e-01
    z[0,6,0]  R421      2.3779372870922089e-01
    z[0,6,0]  R422      5.6475032120943069e-02
    z[0,6,0]  R423      -1.8334245681762695e-01
    z[0,6,0]  R424      1.4990578591823578e-01
    z[0,6,0]  R425      -9.8930656909942627e-02
    z[0,6,0]  R426      -3.7739716470241547e-02
    z[0,6,0]  R427      -4.2912218719720840e-02
    z[0,6,0]  R428      -5.2289735525846481e-02
    z[0,6,0]  R429      3.5226665437221527e-02
    z[0,6,0]  R430      0.0677286833524704
    z[0,6,0]  R431      1.6244037076830864e-02
    z[0,6,1]  R3        -1
    z[0,6,1]  R57       1
    z[0,6,1]  R320      -1
    z[0,6,1]  R321      1
    z[0,6,1]  R332      -2.2488594055175781e-01
    z[0,6,1]  R333      -1.2939150631427765e-01
    z[0,6,1]  R334      -2.1679200232028961e-01
    z[0,6,1]  R335      -4.0721505880355835e-01
    z[0,6,1]  R336      -1.8201905488967896e-01
    z[0,6,1]  R337      -3.6664776504039764e-02
    z[0,6,1]  R338      -3.5846021771430969e-01
    z[0,6,1]  R339      -2.6038247346878052e-01
    z[0,6,1]  R340      -6.8155348300933838e-01
    z[0,6,1]  R341      -2.8164952993392944e-01
    z[0,6,1]  R342      6.2968921661376953e-01
    z[0,6,1]  R343      6.2375122308731079e-01
    z[0,6,1]  R344      6.4590960741043091e-01
    z[0,6,1]  R345      8.7937724590301514e-01
    z[0,6,1]  R346      7.2811561822891235e-01
    z[0,6,1]  R347      4.4551664590835571e-01
    z[0,6,1]  R348      7.0651078224182129e-01
    z[0,6,1]  R349      6.0509574413299561e-01
    z[0,6,1]  R350      4.0943464636802673e-01
    z[0,6,1]  R351      0.868427574634552
    z[0,6,1]  R352      7.7697628736495972e-01
    z[0,6,1]  R353      8.2676619291305542e-01
    z[0,6,1]  R354      7.4282425642013550e-01
    z[0,6,1]  R355      5.9907871484756470e-01
    z[0,6,1]  R356      3.6086297035217285e-01
    z[0,6,1]  R357      -5.0757569074630737e-01
    z[0,6,1]  R358      1.7272317409515381e-01
    z[0,6,1]  R359      -3.2708102464675903e-01
    z[0,6,1]  R360      4.5395290851593018e-01
    z[0,6,1]  R361      -2.8362569212913513e-01
    z[0,6,1]  R362      9.4584661722183228e-01
    z[0,6,1]  R363      8.3826774358749390e-01
    z[0,6,1]  R364      7.8720378875732422e-01
    z[0,6,1]  R365      8.5944074392318726e-01
    z[0,6,1]  R366      7.4405682086944580e-01
    z[0,6,1]  R367      8.2526820898056030e-01
    z[0,6,1]  R368      7.6957190036773682e-01
    z[0,6,1]  R369      0.693574070930481
    z[0,6,1]  R370      7.0397454500198364e-01
    z[0,6,1]  R371      7.1981674432754517e-01
    z[0,6,1]  R372      8.8600194454193115e-01
    z[0,6,1]  R373      8.1919866800308228e-01
    z[0,6,1]  R374      7.5020068883895874e-01
    z[0,6,1]  R375      7.7050465345382690e-01
    z[0,6,1]  R376      7.8837692737579346e-01
    z[0,6,1]  R377      3.5375913977622986e-01
    z[0,6,1]  R378      3.5882890224456787e-01
    z[0,6,1]  R379      2.7233263850212097e-01
    z[0,6,1]  R380      -6.9074638187885284e-02
    z[0,6,1]  R381      3.1501409411430359e-01
    z[0,6,1]  R382      9.6092832088470459e-01
    z[0,6,1]  R383      9.0106505155563354e-01
    z[0,6,1]  R384      3.6725702881813049e-01
    z[0,6,1]  R385      -4.7007972002029419e-01
    z[0,6,1]  R386      -2.9570633172988892e-01
    z[0,6,1]  R387      3.7011715769767761e-01
    z[0,6,1]  R388      -5.1091857254505157e-02
    z[0,6,1]  R389      -3.9350786805152893e-01
    z[0,6,1]  R390      -0.486627459526062
    z[0,6,1]  R391      -5.2580362558364868e-01
    z[0,6,1]  R392      -7.3530954122543335e-01
    z[0,6,1]  R393      -4.9588376283645630e-01
    z[0,6,1]  R394      -5.7717734575271606e-01
    z[0,6,1]  R395      -0.414680153131485
    z[0,6,1]  R396      -7.2164130210876465e-01
    z[0,6,1]  R397      -5.0093287229537964e-01
    z[0,6,1]  R398      -4.1679385304450989e-01
    z[0,6,1]  R399      -6.5210425853729248e-01
    z[0,6,1]  R400      -5.0346869230270386e-01
    z[0,6,1]  R401      -4.0078547596931458e-01
    z[0,6,1]  R402      6.4957511425018311e-01
    z[0,6,1]  R403      6.9872868061065674e-01
    z[0,6,1]  R404      7.6962876319885254e-01
    z[0,6,1]  R405      6.7264169454574585e-01
    z[0,6,1]  R406      8.2818859815597534e-01
    z[0,6,1]  R407      0.672106921672821
    z[0,6,1]  R408      6.5434855222702026e-01
    z[0,6,1]  R409      5.9246122837066650e-01
    z[0,6,1]  R410      4.7276049852371216e-01
    z[0,6,1]  R411      7.1293371915817261e-01
    z[0,6,1]  R412      -4.0303513407707214e-01
    z[0,6,1]  R413      9.0070790052413940e-01
    z[0,6,1]  R414      9.1339069604873657e-01
    z[0,6,1]  R415      7.8830051422119141e-01
    z[0,6,1]  R416      8.8143730163574219e-01
    z[0,6,1]  R417      8.4697675704956055e-01
    z[0,6,1]  R418      8.5751402378082275e-01
    z[0,6,1]  R419      8.3328926563262939e-01
    z[0,6,1]  R420      8.0506402254104614e-01
    z[0,6,1]  R421      8.1652712821960449e-01
    z[0,6,1]  R422      9.0135276317596436e-01
    z[0,6,1]  R423      7.3534977436065674e-01
    z[0,6,1]  R424      8.2764226198196411e-01
    z[0,6,1]  R425      8.6859047412872314e-01
    z[0,6,1]  R426      9.2246288061141968e-01
    z[0,6,1]  R427      8.4907406568527222e-01
    z[0,6,1]  R428      8.6507821083068848e-01
    z[0,6,1]  R429      7.8361368179321289e-01
    z[0,6,1]  R430      7.2851365804672241e-01
    z[0,6,1]  R431      7.8142297267913818e-01
    z[0,6,2]  R4        -1
    z[0,6,2]  R58       1
    z[0,6,2]  R322      -1
    z[0,6,2]  R323      1
    z[0,6,2]  R332      6.9641411304473877e-01
    z[0,6,2]  R333      6.1756026744842529e-01
    z[0,6,2]  R334      0.746904730796814
    z[0,6,2]  R335      4.7763559222221375e-01
    z[0,6,2]  R336      3.4936192631721497e-01
    z[0,6,2]  R337      5.7652479410171509e-01
    z[0,6,2]  R338      2.7917012572288513e-01
    z[0,6,2]  R339      7.9882211983203888e-02
    z[0,6,2]  R340      4.9595010280609131e-01
    z[0,6,2]  R341      -3.1767857726663351e-03
    z[0,6,2]  R342      -3.7552466988563538e-01
    z[0,6,2]  R343      -5.4819935560226440e-01
    z[0,6,2]  R344      -5.2614951133728027e-01
    z[0,6,2]  R345      -1.4535656571388245e-01
    z[0,6,2]  R346      -3.7699118256568909e-01
    z[0,6,2]  R347      -5.6106412410736084e-01
    z[0,6,2]  R348      -4.4130784273147583e-01
    z[0,6,2]  R349      -4.3506258726119995e-01
    z[0,6,2]  R350      -5.6248861551284790e-01
    z[0,6,2]  R351      -3.6139541864395142e-01
    z[0,6,2]  R352      1.6493658721446991e-01
    z[0,6,2]  R353      1.7390790581703186e-01
    z[0,6,2]  R354      3.4230497479438782e-01
    z[0,6,2]  R355      -1.2580266594886780e-01
    z[0,6,2]  R356      -1.4868043363094330e-01
    z[0,6,2]  R357      -1.2460289150476456e-01
    z[0,6,2]  R358      -0.503728985786438
    z[0,6,2]  R359      8.4312453866004944e-02
    z[0,6,2]  R360      -2.4389077723026276e-01
    z[0,6,2]  R361      -3.0800363421440125e-01
    z[0,6,2]  R362      1.3863548636436462e-01
    z[0,6,2]  R363      -2.7512248605489731e-02
    z[0,6,2]  R364      -6.1390563845634460e-02
    z[0,6,2]  R365      -1.9287452101707458e-01
    z[0,6,2]  R366      -3.9840704202651978e-01
    z[0,6,2]  R367      -1.1714725941419601e-01
    z[0,6,2]  R368      -2.4716173112392426e-01
    z[0,6,2]  R369      -2.9159530997276306e-01
    z[0,6,2]  R370      -1.0140753537416458e-01
    z[0,6,2]  R371      -3.0194488167762756e-01
    z[0,6,2]  R372      -1.9755041599273682e-01
    z[0,6,2]  R373      -2.4487484991550446e-01
    z[0,6,2]  R374      -0.43577840924263
    z[0,6,2]  R375      -1.1846154229715466e-03
    z[0,6,2]  R376      7.1419939398765564e-02
    z[0,6,2]  R377      -1.8547539412975311e-01
    z[0,6,2]  R378      -3.4186357259750366e-01
    z[0,6,2]  R379      -5.1645022630691528e-01
    z[0,6,2]  R380      -1.0560575872659683e-01
    z[0,6,2]  R381      -1.4410842955112457e-01
    z[0,6,2]  R382      6.8419404327869415e-02
    z[0,6,2]  R383      -4.0451448410749435e-02
    z[0,6,2]  R384      -1.9884806871414185e-01
    z[0,6,2]  R385      -2.1745659410953522e-01
    z[0,6,2]  R386      -2.4599377810955048e-01
    z[0,6,2]  R387      2.0575824379920959e-01
    z[0,6,2]  R388      -4.7127166390419006e-01
    z[0,6,2]  R389      1.4961537718772888e-01
    z[0,6,2]  R390      -1.8319293856620789e-01
    z[0,6,2]  R391      -1.3706816732883453e-01
    z[0,6,2]  R392      -5.4525830782949924e-03
    z[0,6,2]  R393      -2.1860765293240547e-02
    z[0,6,2]  R394      3.9826986193656921e-01
    z[0,6,2]  R395      7.2109901905059814e-01
    z[0,6,2]  R396      2.4163636565208435e-01
    z[0,6,2]  R397      -1.7734654247760773e-01
    z[0,6,2]  R398      1.7134083807468414e-01
    z[0,6,2]  R399      -4.6825617551803589e-02
    z[0,6,2]  R400      1.2852217257022858e-01
    z[0,6,2]  R401      1.9431334733963013e-01
    z[0,6,2]  R402      -4.2230904102325439e-01
    z[0,6,2]  R403      -2.5339594483375549e-01
    z[0,6,2]  R404      -3.4795930981636047e-01
    z[0,6,2]  R405      -6.3886839151382446e-01
    z[0,6,2]  R406      -1.8048506975173950e-01
    z[0,6,2]  R407      -0.401504784822464
    z[0,6,2]  R408      -2.5141322612762451e-01
    z[0,6,2]  R409      -4.0240389108657837e-01
    z[0,6,2]  R410      -4.6404087543487549e-01
    z[0,6,2]  R411      -2.8564265370368958e-01
    z[0,6,2]  R412      -0.062485221773386
    z[0,6,2]  R413      1.3245701789855957e-01
    z[0,6,2]  R414      1.8474271893501282e-01
    z[0,6,2]  R415      3.9558848738670349e-01
    z[0,6,2]  R416      -2.3664797842502594e-01
    z[0,6,2]  R417      1.3192997872829437e-01
    z[0,6,2]  R418      -3.4804251790046692e-01
    z[0,6,2]  R419      1.7199221253395081e-01
    z[0,6,2]  R420      3.8362555205821991e-02
    z[0,6,2]  R421      1.2735572457313538e-01
    z[0,6,2]  R422      -1.3399665057659149e-01
    z[0,6,2]  R423      -3.9168280363082886e-01
    z[0,6,2]  R424      -4.4084903597831726e-01
    z[0,6,2]  R425      -8.7382178753614426e-03
    z[0,6,2]  R426      -1.4443391561508179e-01
    z[0,6,2]  R427      -0.0871066004037857
    z[0,6,2]  R428      -7.0164717733860016e-02
    z[0,6,2]  R429      2.2188569605350494e-01
    z[0,6,2]  R430      -4.7210793942213058e-02
    z[0,6,2]  R431      0.072322316467762
    z[0,6,3]  R5        -1
    z[0,6,3]  R59       1
    z[0,6,3]  R324      -1
    z[0,6,3]  R325      1
    z[0,6,3]  R332      5.1677453517913818e-01
    z[0,6,3]  R333      1.2330103665590286e-01
    z[0,6,3]  R334      1.6277417540550232e-01
    z[0,6,3]  R335      4.2016741633415222e-01
    z[0,6,3]  R336      2.2670869529247284e-01
    z[0,6,3]  R337      2.6785820722579956e-01
    z[0,6,3]  R338      -1.0430599562823772e-02
    z[0,6,3]  R339      3.7662589550018311e-01
    z[0,6,3]  R340      2.8773674368858337e-01
    z[0,6,3]  R341      7.7458918094635010e-01
    z[0,6,3]  R342      1.6704623401165009e-01
    z[0,6,3]  R343      2.3247901350259781e-02
    z[0,6,3]  R344      4.1320866346359253e-01
    z[0,6,3]  R345      0.0545872300863266
    z[0,6,3]  R346      1.2594187259674072e-01
    z[0,6,3]  R347      1.6451855003833771e-01
    z[0,6,3]  R348      3.3085045218467712e-01
    z[0,6,3]  R349      2.4973908066749573e-01
    z[0,6,3]  R350      3.9302092790603638e-01
    z[0,6,3]  R351      -8.9879669249057770e-02
    z[0,6,3]  R352      -5.6031066179275513e-01
    z[0,6,3]  R353      -9.8044604063034058e-02
    z[0,6,3]  R354      -1.3259139657020569e-01
    z[0,6,3]  R355      -0.507114827632904
    z[0,6,3]  R356      -6.7938894033432007e-01
    z[0,6,3]  R357      -6.5618109703063965e-01
    z[0,6,3]  R358      -6.9857668876647949e-01
    z[0,6,3]  R359      -6.7651957273483276e-01
    z[0,6,3]  R360      -0.729148805141449
    z[0,6,3]  R361      -6.4328622817993164e-01
    z[0,6,3]  R362      6.0929656028747559e-02
    z[0,6,3]  R363      4.4564566016197205e-01
    z[0,6,3]  R364      -4.6845340728759766e-01
    z[0,6,3]  R365      0.217659592628479
    z[0,6,3]  R366      -2.1393077075481415e-01
    z[0,6,3]  R367      -2.3716230690479279e-01
    z[0,6,3]  R368      -3.2082572579383850e-01
    z[0,6,3]  R369      4.1865665465593338e-02
    z[0,6,3]  R370      -9.6946984529495239e-02
    z[0,6,3]  R371      8.9062482118606567e-02
    z[0,6,3]  R372      -3.2469424605369568e-01
    z[0,6,3]  R373      -3.8564404845237732e-01
    z[0,6,3]  R374      1.9415273563936353e-03
    z[0,6,3]  R375      -0.000567007577046752
    z[0,6,3]  R376      -0.308651328086853
    z[0,6,3]  R377      2.7416145801544189e-01
    z[0,6,3]  R378      -7.5802463293075562e-01
    z[0,6,3]  R379      -6.2473946809768677e-01
    z[0,6,3]  R380      -0.938624382019043
    z[0,6,3]  R381      -6.4770805835723877e-01
    z[0,6,3]  R382      5.8693759143352509e-02
    z[0,6,3]  R383      1.9043010473251343e-01
    z[0,6,3]  R384      2.8132423758506775e-01
    z[0,6,3]  R385      -7.3013061285018921e-01
    z[0,6,3]  R386      -7.1067994832992554e-01
    z[0,6,3]  R387      -7.9846704006195068e-01
    z[0,6,3]  R388      -0.622801661491394
    z[0,6,3]  R389      -4.3773502111434937e-01
    z[0,6,3]  R390      1.8729162216186523e-01
    z[0,6,3]  R391      -9.3009635806083679e-02
    z[0,6,3]  R392      -7.8702464699745178e-02
    z[0,6,3]  R393      -5.4290610551834106e-01
    z[0,6,3]  R394      -1.7345812916755676e-01
    z[0,6,3]  R395      -2.7939155697822571e-01
    z[0,6,3]  R396      -4.9790588021278381e-01
    z[0,6,3]  R397      -4.0655446052551270e-01
    z[0,6,3]  R398      -4.7898799180984497e-01
    z[0,6,3]  R399      -3.0154135823249817e-01
    z[0,6,3]  R400      -3.7619385123252869e-01
    z[0,6,3]  R401      -0.323411226272583
    z[0,6,3]  R402      3.9414972066879272e-01
    z[0,6,3]  R403      2.9318007826805115e-01
    z[0,6,3]  R404      1.6355967149138451e-02
    z[0,6,3]  R405      -4.4523615390062332e-02
    z[0,6,3]  R406      2.1793028712272644e-01
    z[0,6,3]  R407      -2.7577212080359459e-02
    z[0,6,3]  R408      2.9820641875267029e-01
    z[0,6,3]  R409      4.6124079823493958e-01
    z[0,6,3]  R410      3.5927388817071915e-02
    z[0,6,3]  R411      5.1341433078050613e-02
    z[0,6,3]  R412      7.0136207342147827e-01
    z[0,6,3]  R413      -9.1290250420570374e-02
    z[0,6,3]  R414      -1.4799717068672180e-01
    z[0,6,3]  R415      -1.5839058160781860e-01
    z[0,6,3]  R416      -1.9270788133144379e-01
    z[0,6,3]  R417      2.3124691843986511e-01
    z[0,6,3]  R418      -4.1036497801542282e-02
    z[0,6,3]  R419      2.1468129009008408e-02
    z[0,6,3]  R420      -2.4786441028118134e-01
    z[0,6,3]  R421      8.2508064806461334e-02
    z[0,6,3]  R422      3.2507243752479553e-01
    z[0,6,3]  R423      4.1435372829437256e-01
    z[0,6,3]  R424      9.4971351325511932e-02
    z[0,6,3]  R425      3.5890835523605347e-01
    z[0,6,3]  R426      2.7370864152908325e-01
    z[0,6,3]  R427      1.5111638605594635e-01
    z[0,6,3]  R428      3.9690554141998291e-01
    z[0,6,3]  R429      1.9343625009059906e-01
    z[0,6,3]  R430      -1.6232079267501831e-01
    z[0,6,3]  R431      1.5407501161098480e-01
    z[0,6,4]  R6        -1
    z[0,6,4]  R60       1
    z[0,6,4]  R326      -1
    z[0,6,4]  R327      1
    z[0,6,4]  R332      -4.1218571364879608e-02
    z[0,6,4]  R333      0.352463036775589
    z[0,6,4]  R334      -2.4997876584529877e-01
    z[0,6,4]  R335      3.1200459599494934e-01
    z[0,6,4]  R336      -1.5997199714183807e-01
    z[0,6,4]  R337      -5.0467513501644135e-02
    z[0,6,4]  R338      3.9517077803611755e-01
    z[0,6,4]  R339      -3.3496016263961792e-01
    z[0,6,4]  R340      -2.5108709931373596e-01
    z[0,6,4]  R341      5.7777430862188339e-02
    z[0,6,4]  R342      -2.4556618183851242e-02
    z[0,6,4]  R343      -7.3936069384217262e-03
    z[0,6,4]  R344      1.3218869268894196e-01
    z[0,6,4]  R345      4.1001036763191223e-02
    z[0,6,4]  R346      2.5220713019371033e-01
    z[0,6,4]  R347      1.9193364679813385e-01
    z[0,6,4]  R348      -5.9747759252786636e-02
    z[0,6,4]  R349      -8.6109027266502380e-02
    z[0,6,4]  R350      1.3745196163654327e-01
    z[0,6,4]  R351      0.0350436307489872
    z[0,6,4]  R352      9.5477670431137085e-02
    z[0,6,4]  R353      -3.7079265713691711e-01
    z[0,6,4]  R354      -1.3064685463905334e-01
    z[0,6,4]  R355      3.2557407021522522e-01
    z[0,6,4]  R356      -1.3982348144054413e-01
    z[0,6,4]  R357      1.1141499131917953e-01
    z[0,6,4]  R358      -7.0524394512176514e-02
    z[0,6,4]  R359      8.8269263505935669e-02
    z[0,6,4]  R360      4.1587015986442566e-01
    z[0,6,4]  R361      4.0703928470611572e-01
    z[0,6,4]  R362      -2.1439389884471893e-01
    z[0,6,4]  R363      -2.3072990775108337e-01
    z[0,6,4]  R364      2.6333945989608765e-01
    z[0,6,4]  R365      2.4770571291446686e-01
    z[0,6,4]  R366      2.1385875344276428e-01
    z[0,6,4]  R367      6.0413964092731476e-02
    z[0,6,4]  R368      -2.5798571109771729e-01
    z[0,6,4]  R369      -1.1370173841714859e-01
    z[0,6,4]  R370      0.359660267829895
    z[0,6,4]  R371      5.8230042457580566e-02
    z[0,6,4]  R372      1.2516547739505768e-01
    z[0,6,4]  R373      -3.8943123072385788e-02
    z[0,6,4]  R374      -5.8395609259605408e-02
    z[0,6,4]  R375      0.284589558839798
    z[0,6,4]  R376      -3.4502550959587097e-01
    z[0,6,4]  R377      -6.8094119429588318e-02
    z[0,6,4]  R378      -7.7331632375717163e-02
    z[0,6,4]  R379      2.8215774893760681e-01
    z[0,6,4]  R380      1.0871417075395584e-01
    z[0,6,4]  R381      -1.9560030195862055e-03
    z[0,6,4]  R382      -1.1534772813320160e-01
    z[0,6,4]  R383      1.9251872599124908e-01
    z[0,6,4]  R384      0.0800652801990509
    z[0,6,4]  R385      1.9722582772374153e-02
    z[0,6,4]  R386      5.0033140927553177e-02
    z[0,6,4]  R387      -2.4309885501861572e-01
    z[0,6,4]  R388      9.8878055810928345e-02
    z[0,6,4]  R389      5.3946918249130249e-01
    z[0,6,4]  R390      1.6274869441986084e-01
    z[0,6,4]  R391      -4.7675538808107376e-03
    z[0,6,4]  R392      -6.5583787858486176e-02
    z[0,6,4]  R393      -0.0800815224647522
    z[0,6,4]  R394      -6.0458654165267944e-01
    z[0,6,4]  R395      -1.7526540160179138e-01
    z[0,6,4]  R396      1.7153823375701904e-01
    z[0,6,4]  R397      -5.8877730369567871e-01
    z[0,6,4]  R398      -0.381697416305542
    z[0,6,4]  R399      2.6414009928703308e-01
    z[0,6,4]  R400      -6.7557895183563232e-01
    z[0,6,4]  R401      -8.0988389253616333e-01
    z[0,6,4]  R402      3.0215349048376083e-02
    z[0,6,4]  R403      -1.1738082021474838e-01
    z[0,6,4]  R404      1.1353948712348938e-01
    z[0,6,4]  R405      -4.5189879834651947e-02
    z[0,6,4]  R406      1.2621504068374634e-01
    z[0,6,4]  R407      -2.8321878984570503e-02
    z[0,6,4]  R408      2.0029008388519287e-01
    z[0,6,4]  R409      1.5489107370376587e-01
    z[0,6,4]  R410      -1.4238531701266766e-02
    z[0,6,4]  R411      1.7537397146224976e-01
    z[0,6,4]  R412      -7.3311820626258850e-02
    z[0,6,4]  R413      8.1896416842937469e-02
    z[0,6,4]  R414      -1.5243300795555115e-01
    z[0,6,4]  R415      4.0392596274614334e-02
    z[0,6,4]  R416      -2.4234730750322342e-02
    z[0,6,4]  R417      -2.0024940371513367e-01
    z[0,6,4]  R418      5.5311162024736404e-02
    z[0,6,4]  R419      -3.4424898028373718e-01
    z[0,6,4]  R420      6.6722683608531952e-02
    z[0,6,4]  R421      -2.4594143033027649e-02
    z[0,6,4]  R422      1.2444531172513962e-01
    z[0,6,4]  R423      0.046059750020504
    z[0,6,4]  R424      1.2458857148885727e-01
    z[0,6,4]  R425      -2.6181265711784363e-01
    z[0,6,4]  R426      -1.2470588833093643e-01
    z[0,6,4]  R427      -2.0413656532764435e-01
    z[0,6,4]  R428      -1.0960114002227783e-01
    z[0,6,4]  R429      1.5741668641567230e-01
    z[0,6,4]  R430      8.2987584173679352e-02
    z[0,6,4]  R431      1.7803196609020233e-01
    z[0,6,5]  R7        -1
    z[0,6,5]  R61       1
    z[0,6,5]  R328      -1
    z[0,6,5]  R329      1
    z[0,6,5]  R332      1.9684407114982605e-01
    z[0,6,5]  R333      2.1400873363018036e-01
    z[0,6,5]  R334      1.7545576393604279e-01
    z[0,6,5]  R335      -8.3863191306591034e-02
    z[0,6,5]  R336      3.5342969000339508e-02
    z[0,6,5]  R337      -2.2698865830898285e-01
    z[0,6,5]  R338      3.7799999117851257e-01
    z[0,6,5]  R339      -7.9122260212898254e-03
    z[0,6,5]  R340      2.4082399904727936e-01
    z[0,6,5]  R341      1.1017414927482605e-01
    z[0,6,5]  R342      3.6226198077201843e-01
    z[0,6,5]  R343      3.0144955962896347e-02
    z[0,6,5]  R344      1.4294551312923431e-01
    z[0,6,5]  R345      1.7544165253639221e-01
    z[0,6,5]  R346      2.3372095823287964e-01
    z[0,6,5]  R347      4.1231876611709595e-01
    z[0,6,5]  R348      3.9987576007843018e-01
    z[0,6,5]  R349      4.1314443945884705e-01
    z[0,6,5]  R350      3.3306348323822021e-01
    z[0,6,5]  R351      1.6043521463871002e-01
    z[0,6,5]  R352      -5.6281950324773788e-02
    z[0,6,5]  R353      -3.6464065313339233e-01
    z[0,6,5]  R354      -3.4621521830558777e-01
    z[0,6,5]  R355      -4.0698921680450439e-01
    z[0,6,5]  R356      -4.0686112642288208e-01
    z[0,6,5]  R357      -2.8368967771530151e-01
    z[0,6,5]  R358      -1.4950375258922577e-01
    z[0,6,5]  R359      -2.9358950257301331e-01
    z[0,6,5]  R360      9.5859030261635780e-03
    z[0,6,5]  R361      -3.9522635936737061e-01
    z[0,6,5]  R362      -1.6145195066928864e-01
    z[0,6,5]  R363      -1.9120676815509796e-01
    z[0,6,5]  R364      -1.1766610294580460e-01
    z[0,6,5]  R365      -2.3118594661355019e-02
    z[0,6,5]  R366      -8.8029861450195312e-02
    z[0,6,5]  R367      -1.0294277220964432e-01
    z[0,6,5]  R368      -3.1823366880416870e-01
    z[0,6,5]  R369      -2.9804265499114990e-01
    z[0,6,5]  R370      -3.8015264272689819e-01
    z[0,6,5]  R371      -5.3212952613830566e-01
    z[0,6,5]  R372      -1.7609718441963196e-01
    z[0,6,5]  R373      -2.2707961499691010e-01
    z[0,6,5]  R374      -2.2068646550178528e-01
    z[0,6,5]  R375      -3.7052431702613831e-01
    z[0,6,5]  R376      1.1809995397925377e-02
    z[0,6,5]  R377      -1.8104976415634155e-01
    z[0,6,5]  R378      1.3202938437461853e-01
    z[0,6,5]  R379      -9.1548189520835876e-03
    z[0,6,5]  R380      -8.9364543557167053e-02
    z[0,6,5]  R381      4.1444590687751770e-01
    z[0,6,5]  R382      7.5835309922695160e-02
    z[0,6,5]  R383      7.5173109769821167e-02
    z[0,6,5]  R384      -1.4381489157676697e-01
    z[0,6,5]  R385      -2.3718622326850891e-01
    z[0,6,5]  R386      -3.9254122972488403e-01
    z[0,6,5]  R387      -6.2953993678092957e-02
    z[0,6,5]  R388      -5.6849384307861328e-01
    z[0,6,5]  R389      3.0457329750061035e-01
    z[0,6,5]  R390      4.8995118588209152e-02
    z[0,6,5]  R391      2.5946235656738281e-01
    z[0,6,5]  R392      -6.5855300426483154e-01
    z[0,6,5]  R393      -0.524657666683197
    z[0,6,5]  R394      2.6140136644244194e-02
    z[0,6,5]  R395      -6.4212411642074585e-02
    z[0,6,5]  R396      3.1182447075843811e-01
    z[0,6,5]  R397      -1.8741479516029358e-01
    z[0,6,5]  R398      -1.5266482532024384e-01
    z[0,6,5]  R399      3.9203429222106934e-01
    z[0,6,5]  R400      2.8428819775581360e-01
    z[0,6,5]  R401      -1.8582858145236969e-01
    z[0,6,5]  R402      8.4322936832904816e-02
    z[0,6,5]  R403      2.0743592083454132e-01
    z[0,6,5]  R404      -9.0206608176231384e-02
    z[0,6,5]  R405      1.6514307260513306e-01
    z[0,6,5]  R406      2.6645395159721375e-01
    z[0,6,5]  R407      3.2838270068168640e-01
    z[0,6,5]  R408      5.2637696266174316e-01
    z[0,6,5]  R409      -1.9093910232186317e-02
    z[0,6,5]  R410      1.6806872189044952e-01
    z[0,6,5]  R411      5.1751202344894409e-01
    z[0,6,5]  R412      3.1335690617561340e-01
    z[0,6,5]  R413      -2.0860818028450012e-01
    z[0,6,5]  R414      -5.0855904817581177e-02
    z[0,6,5]  R415      -7.0194430649280548e-02
    z[0,6,5]  R416      -5.6670308113098145e-02
    z[0,6,5]  R417      -3.5609897971153259e-01
    z[0,6,5]  R418      -2.5435757637023926e-01
    z[0,6,5]  R419      -1.9326642155647278e-01
    z[0,6,5]  R420      8.5207270458340645e-03
    z[0,6,5]  R421      -4.3164554983377457e-02
    z[0,6,5]  R422      9.4563901424407959e-02
    z[0,6,5]  R423      2.2803477942943573e-01
    z[0,6,5]  R424      -2.3928210139274597e-01
    z[0,6,5]  R425      1.7281684279441833e-01
    z[0,6,5]  R426      1.2834899127483368e-01
    z[0,6,5]  R427      4.2434215545654297e-01
    z[0,6,5]  R428      -6.4620628952980042e-02
    z[0,6,5]  R429      0.515661358833313
    z[0,6,5]  R430      6.4931267499923706e-01
    z[0,6,5]  R431      3.6160182952880859e-01
    z[0,6,6]  R8        -1
    z[0,6,6]  R62       1
    z[0,6,6]  R330      -1
    z[0,6,6]  R331      1
    z[0,6,6]  R332      -2.3867608606815338e-01
    z[0,6,6]  R333      -2.8994879126548767e-01
    z[0,6,6]  R334      2.2076773643493652e-01
    z[0,6,6]  R335      -3.2592701911926270e-01
    z[0,6,6]  R336      -3.1702980399131775e-02
    z[0,6,6]  R337      1.8523052334785461e-01
    z[0,6,6]  R338      1.6725838184356689e-01
    z[0,6,6]  R339      8.6627446115016937e-02
    z[0,6,6]  R340      2.2655488550662994e-01
    z[0,6,6]  R341      2.8011319041252136e-01
    z[0,6,6]  R342      0.245841383934021
    z[0,6,6]  R343      0.097848080098629
    z[0,6,6]  R344      -1.8725836277008057e-01
    z[0,6,6]  R345      -2.1693013608455658e-02
    z[0,6,6]  R346      3.1365182995796204e-01
    z[0,6,6]  R347      1.1375698447227478e-01
    z[0,6,6]  R348      9.7162231802940369e-02
    z[0,6,6]  R349      -1.0808359831571579e-01
    z[0,6,6]  R350      -6.4100623130798340e-02
    z[0,6,6]  R351      1.3626888394355774e-01
    z[0,6,6]  R352      -1.7072747647762299e-01
    z[0,6,6]  R353      -3.0899396166205406e-02
    z[0,6,6]  R354      -4.1400483250617981e-01
    z[0,6,6]  R355      -8.5938654839992523e-02
    z[0,6,6]  R356      -1.3139389455318451e-01
    z[0,6,6]  R357      -1.9289404153823853e-01
    z[0,6,6]  R358      2.1805499494075775e-01
    z[0,6,6]  R359      -3.6004860885441303e-03
    z[0,6,6]  R360      -1.7021040618419647e-01
    z[0,6,6]  R361      -8.1121474504470825e-03
    z[0,6,6]  R362      -8.0257803201675415e-02
    z[0,6,6]  R363      0.00755949504673481
    z[0,6,6]  R364      -9.6115969121456146e-02
    z[0,6,6]  R365      -9.2945620417594910e-02
    z[0,6,6]  R366      2.6474019885063171e-01
    z[0,6,6]  R367      -4.0284439921379089e-01
    z[0,6,6]  R368      6.5613955259323120e-02
    z[0,6,6]  R369      4.5896759629249573e-01
    z[0,6,6]  R370      -1.4630749821662903e-01
    z[0,6,6]  R371      -2.8226310014724731e-01
    z[0,6,6]  R372      -0.154501274228096
    z[0,6,6]  R373      2.2523556649684906e-01
    z[0,6,6]  R374      3.8888379931449890e-01
    z[0,6,6]  R375      -3.0032485723495483e-01
    z[0,6,6]  R376      3.7741836905479431e-01
    z[0,6,6]  R377      -3.9454710483551025e-01
    z[0,6,6]  R378      1.6951330006122589e-01
    z[0,6,6]  R379      -1.9711382687091827e-01
    z[0,6,6]  R380      -3.0246462672948837e-02
    z[0,6,6]  R381      -1.7947243154048920e-01
    z[0,6,6]  R382      -2.1330793201923370e-01
    z[0,6,6]  R383      -2.7563467621803284e-01
    z[0,6,6]  R384      -3.2324469089508057e-01
    z[0,6,6]  R385      6.4031504094600677e-02
    z[0,6,6]  R386      -1.0182687640190125e-01
    z[0,6,6]  R387      -8.6366616189479828e-02
    z[0,6,6]  R388      2.0609053969383240e-01
    z[0,6,6]  R389      7.7185044065117836e-03
    z[0,6,6]  R390      3.2198838889598846e-02
    z[0,6,6]  R391      0.0327945351600647
    z[0,6,6]  R392      -1.2277911603450775e-01
    z[0,6,6]  R393      -3.5015437752008438e-02
    z[0,6,6]  R394      -3.1789663434028625e-01
    z[0,6,6]  R395      -4.2904266715049744e-01
    z[0,6,6]  R396      1.8472722172737122e-01
    z[0,6,6]  R397      3.4748157858848572e-01
    z[0,6,6]  R398      -5.6928563117980957e-01
    z[0,6,6]  R399      -4.9426713585853577e-01
    z[0,6,6]  R400      1.2183386087417603e-01
    z[0,6,6]  R401      -2.6246858760714531e-02
    z[0,6,6]  R402      0.182825967669487
    z[0,6,6]  R403      0.10972910374403
    z[0,6,6]  R404      -8.3172051236033440e-03
    z[0,6,6]  R405      -0.00973269622772932
    z[0,6,6]  R406      2.7663874626159668e-01
    z[0,6,6]  R407      -2.4992136657238007e-01
    z[0,6,6]  R408      6.2270566821098328e-02
    z[0,6,6]  R409      -2.2644624114036560e-01
    z[0,6,6]  R410      -1.0564853996038437e-01
    z[0,6,6]  R411      9.0046428143978119e-02
    z[0,6,6]  R412      2.4305772781372070e-01
    z[0,6,6]  R413      -3.6850892007350922e-02
    z[0,6,6]  R414      -1.3209588825702667e-01
    z[0,6,6]  R415      2.0862698554992676e-01
    z[0,6,6]  R416      2.3921461403369904e-01
    z[0,6,6]  R417      1.3593156635761261e-01
    z[0,6,6]  R418      -2.0570243895053864e-01
    z[0,6,6]  R419      2.8194564580917358e-01
    z[0,6,6]  R420      3.9390745759010315e-01
    z[0,6,6]  R421      5.0124108791351318e-01
    z[0,6,6]  R422      1.9057209789752960e-01
    z[0,6,6]  R423      -2.1545395255088806e-01
    z[0,6,6]  R424      1.2802718579769135e-01
    z[0,6,6]  R425      -9.1979824006557465e-02
    z[0,6,6]  R426      -1.4083835482597351e-01
    z[0,6,6]  R427      1.5833540260791779e-01
    z[0,6,6]  R428      -2.6506617665290833e-01
    z[0,6,6]  R429      -0.0858563557267189
    z[0,6,6]  R430      -8.7235406041145325e-02
    z[0,6,6]  R431      -4.4462716579437256e-01
    z[6,0,0]  R2        1
    z[6,0,0]  R56       -1
    z[6,0,0]  R432      -1
    z[6,0,0]  R433      1
    z[6,0,0]  R446      5.2997888997197151e-03
    z[6,0,0]  R447      4.1948729753494263e-01
    z[6,0,0]  R448      1.0437027364969254e-01
    z[6,0,0]  R449      1.0525260120630264e-01
    z[6,0,0]  R450      1.1023332178592682e-01
    z[6,0,0]  R451      2.2316236793994904e-01
    z[6,0,0]  R452      2.7278235554695129e-01
    z[6,0,0]  R453      1.1781064420938492e-01
    z[6,0,0]  R454      1.9081214070320129e-01
    z[6,0,0]  R455      -7.6717101037502289e-02
    z[6,0,0]  R456      -4.5044949650764465e-01
    z[6,0,0]  R457      -5.4107826948165894e-01
    z[6,0,0]  R458      -5.1500570774078369e-01
    z[6,0,0]  R459      -3.2864689826965332e-01
    z[6,0,0]  R460      -2.6566559076309204e-01
    z[6,0,0]  R461      -4.6390482783317566e-01
    z[6,0,0]  R462      -3.1404739618301392e-01
    z[6,0,0]  R463      -4.4573992490768433e-01
    z[6,0,0]  R464      -7.2129136323928833e-01
    z[6,0,0]  R465      -3.1751331686973572e-01
    z[6,0,0]  R466      -4.2320832610130310e-01
    z[6,0,0]  R467      3.3356276154518127e-01
    z[6,0,0]  R468      0.257706880569458
    z[6,0,0]  R469      3.8330194354057312e-01
    z[6,0,0]  R470      2.6250192523002625e-01
    z[6,0,0]  R471      1.6237622499465942e-01
    z[6,0,0]  R472      1.7827369272708893e-01
    z[6,0,0]  R473      2.0058463513851166e-01
    z[6,0,0]  R474      3.5954967141151428e-01
    z[6,0,0]  R475      2.3779372870922089e-01
    z[6,0,0]  R476      5.6475032120943069e-02
    z[6,0,0]  R477      -1.8334245681762695e-01
    z[6,0,0]  R478      1.4990578591823578e-01
    z[6,0,0]  R479      -9.8930656909942627e-02
    z[6,0,0]  R480      -3.7739716470241547e-02
    z[6,0,0]  R481      -4.2912218719720840e-02
    z[6,0,0]  R482      -5.2289735525846481e-02
    z[6,0,0]  R483      3.5226665437221527e-02
    z[6,0,0]  R484      0.0677286833524704
    z[6,0,0]  R485      1.6244037076830864e-02
    z[6,0,0]  R486      3.1617248058319092e-01
    z[6,0,0]  R487      5.7669192552566528e-01
    z[6,0,0]  R488      4.7605317831039429e-01
    z[6,0,0]  R489      4.6785807609558105e-01
    z[6,0,0]  R490      8.7497037649154663e-01
    z[6,0,0]  R491      7.1143907308578491e-01
    z[6,0,0]  R492      6.8296575546264648e-01
    z[6,0,0]  R493      8.1498926877975464e-01
    z[6,0,0]  R494      0.185358464717865
    z[6,0,0]  R495      4.7616714239120483e-01
    z[6,0,0]  R496      -4.9223318696022034e-01
    z[6,0,0]  R497      -5.4711413383483887e-01
    z[6,0,0]  R498      -2.4950566887855530e-01
    z[6,0,0]  R499      -4.1189306974411011e-01
    z[6,0,0]  R500      -3.0863013863563538e-01
    z[6,0,0]  R501      -4.8976475000381470e-01
    z[6,0,0]  R502      -1.5400357544422150e-01
    z[6,0,0]  R503      -4.3866270780563354e-01
    z[6,0,0]  R504      -4.7704404592514038e-01
    z[6,0,0]  R505      -2.4821718037128448e-01
    z[6,0,0]  R506      1.1715054512023926e-01
    z[6,0,0]  R507      -7.2085000574588776e-02
    z[6,0,0]  R508      -7.1591906249523163e-02
    z[6,0,0]  R509      2.9847750067710876e-01
    z[6,0,0]  R510      -4.2866292595863342e-01
    z[6,0,0]  R511      -0.407634973526001
    z[6,0,0]  R512      -3.9184358716011047e-01
    z[6,0,0]  R513      -5.7812762260437012e-01
    z[6,0,0]  R514      2.7833279222249985e-02
    z[6,0,0]  R515      -2.9819878935813904e-01
    z[6,0,0]  R516      6.3001766800880432e-02
    z[6,0,0]  R517      0.0899825319647789
    z[6,0,0]  R518      2.5428640842437744e-01
    z[6,0,0]  R519      3.2596611976623535e-01
    z[6,0,0]  R520      3.4396609663963318e-01
    z[6,0,0]  R521      -2.6913258433341980e-01
    z[6,0,0]  R522      -2.6759406924247742e-01
    z[6,0,0]  R523      3.4607195854187012e-01
    z[6,0,0]  R524      4.3527016043663025e-01
    z[6,0,0]  R525      -1.2859259545803070e-01
    z[6,0,0]  R526      9.0489076683297753e-04
    z[6,0,0]  R527      1.2812386453151703e-01
    z[6,0,0]  R528      2.0964090526103973e-01
    z[6,0,0]  R529      3.1280410289764404e-01
    z[6,0,0]  R530      1.2833017110824585e-01
    z[6,0,0]  R531      -0.756442666053772
    z[6,0,0]  R532      -3.5724371671676636e-01
    z[6,0,0]  R533      -3.8763898611068726e-01
    z[6,0,0]  R534      -2.8695088624954224e-01
    z[6,0,0]  R535      -5.0645190477371216e-01
    z[6,0,0]  R536      -6.2723271548748016e-02
    z[6,0,0]  R537      1.7746257781982422e-01
    z[6,0,0]  R538      -7.8412890434265137e-01
    z[6,0,0]  R539      -3.7134975194931030e-01
    z[6,0,0]  R540      -4.2428565025329590e-01
    z[6,0,0]  R541      -3.3557087182998657e-01
    z[6,0,0]  R542      -1.0943162441253662e-01
    z[6,0,0]  R543      -4.9729606509208679e-01
    z[6,0,0]  R544      -8.1524938344955444e-01
    z[6,0,0]  R545      -7.9225832223892212e-01
    z[6,0,1]  R3        1
    z[6,0,1]  R57       -1
    z[6,0,1]  R434      -1
    z[6,0,1]  R435      1
    z[6,0,1]  R446      -7.3530954122543335e-01
    z[6,0,1]  R447      -4.9588376283645630e-01
    z[6,0,1]  R448      -5.7717734575271606e-01
    z[6,0,1]  R449      -0.414680153131485
    z[6,0,1]  R450      -7.2164130210876465e-01
    z[6,0,1]  R451      -5.0093287229537964e-01
    z[6,0,1]  R452      -4.1679385304450989e-01
    z[6,0,1]  R453      -6.5210425853729248e-01
    z[6,0,1]  R454      -5.0346869230270386e-01
    z[6,0,1]  R455      -4.0078547596931458e-01
    z[6,0,1]  R456      6.4957511425018311e-01
    z[6,0,1]  R457      6.9872868061065674e-01
    z[6,0,1]  R458      7.6962876319885254e-01
    z[6,0,1]  R459      6.7264169454574585e-01
    z[6,0,1]  R460      8.2818859815597534e-01
    z[6,0,1]  R461      0.672106921672821
    z[6,0,1]  R462      6.5434855222702026e-01
    z[6,0,1]  R463      5.9246122837066650e-01
    z[6,0,1]  R464      4.7276049852371216e-01
    z[6,0,1]  R465      7.1293371915817261e-01
    z[6,0,1]  R466      -4.0303513407707214e-01
    z[6,0,1]  R467      9.0070790052413940e-01
    z[6,0,1]  R468      9.1339069604873657e-01
    z[6,0,1]  R469      7.8830051422119141e-01
    z[6,0,1]  R470      8.8143730163574219e-01
    z[6,0,1]  R471      8.4697675704956055e-01
    z[6,0,1]  R472      8.5751402378082275e-01
    z[6,0,1]  R473      8.3328926563262939e-01
    z[6,0,1]  R474      8.0506402254104614e-01
    z[6,0,1]  R475      8.1652712821960449e-01
    z[6,0,1]  R476      9.0135276317596436e-01
    z[6,0,1]  R477      7.3534977436065674e-01
    z[6,0,1]  R478      8.2764226198196411e-01
    z[6,0,1]  R479      8.6859047412872314e-01
    z[6,0,1]  R480      9.2246288061141968e-01
    z[6,0,1]  R481      8.4907406568527222e-01
    z[6,0,1]  R482      8.6507821083068848e-01
    z[6,0,1]  R483      7.8361368179321289e-01
    z[6,0,1]  R484      7.2851365804672241e-01
    z[6,0,1]  R485      7.8142297267913818e-01
    z[6,0,1]  R486      -2.2488594055175781e-01
    z[6,0,1]  R487      -1.2939150631427765e-01
    z[6,0,1]  R488      -2.1679200232028961e-01
    z[6,0,1]  R489      -4.0721505880355835e-01
    z[6,0,1]  R490      -1.8201905488967896e-01
    z[6,0,1]  R491      -3.6664776504039764e-02
    z[6,0,1]  R492      -3.5846021771430969e-01
    z[6,0,1]  R493      -2.6038247346878052e-01
    z[6,0,1]  R494      -6.8155348300933838e-01
    z[6,0,1]  R495      -2.8164952993392944e-01
    z[6,0,1]  R496      6.2968921661376953e-01
    z[6,0,1]  R497      6.2375122308731079e-01
    z[6,0,1]  R498      6.4590960741043091e-01
    z[6,0,1]  R499      8.7937724590301514e-01
    z[6,0,1]  R500      7.2811561822891235e-01
    z[6,0,1]  R501      4.4551664590835571e-01
    z[6,0,1]  R502      7.0651078224182129e-01
    z[6,0,1]  R503      6.0509574413299561e-01
    z[6,0,1]  R504      4.0943464636802673e-01
    z[6,0,1]  R505      0.868427574634552
    z[6,0,1]  R506      7.7697628736495972e-01
    z[6,0,1]  R507      8.2676619291305542e-01
    z[6,0,1]  R508      7.4282425642013550e-01
    z[6,0,1]  R509      5.9907871484756470e-01
    z[6,0,1]  R510      3.6086297035217285e-01
    z[6,0,1]  R511      -5.0757569074630737e-01
    z[6,0,1]  R512      1.7272317409515381e-01
    z[6,0,1]  R513      -3.2708102464675903e-01
    z[6,0,1]  R514      4.5395290851593018e-01
    z[6,0,1]  R515      -2.8362569212913513e-01
    z[6,0,1]  R516      9.4584661722183228e-01
    z[6,0,1]  R517      8.3826774358749390e-01
    z[6,0,1]  R518      7.8720378875732422e-01
    z[6,0,1]  R519      8.5944074392318726e-01
    z[6,0,1]  R520      7.4405682086944580e-01
    z[6,0,1]  R521      8.2526820898056030e-01
    z[6,0,1]  R522      7.6957190036773682e-01
    z[6,0,1]  R523      0.693574070930481
    z[6,0,1]  R524      7.0397454500198364e-01
    z[6,0,1]  R525      7.1981674432754517e-01
    z[6,0,1]  R526      8.8600194454193115e-01
    z[6,0,1]  R527      8.1919866800308228e-01
    z[6,0,1]  R528      7.5020068883895874e-01
    z[6,0,1]  R529      7.7050465345382690e-01
    z[6,0,1]  R530      7.8837692737579346e-01
    z[6,0,1]  R531      3.5375913977622986e-01
    z[6,0,1]  R532      3.5882890224456787e-01
    z[6,0,1]  R533      2.7233263850212097e-01
    z[6,0,1]  R534      -6.9074638187885284e-02
    z[6,0,1]  R535      3.1501409411430359e-01
    z[6,0,1]  R536      9.6092832088470459e-01
    z[6,0,1]  R537      9.0106505155563354e-01
    z[6,0,1]  R538      3.6725702881813049e-01
    z[6,0,1]  R539      -4.7007972002029419e-01
    z[6,0,1]  R540      -2.9570633172988892e-01
    z[6,0,1]  R541      3.7011715769767761e-01
    z[6,0,1]  R542      -5.1091857254505157e-02
    z[6,0,1]  R543      -3.9350786805152893e-01
    z[6,0,1]  R544      -0.486627459526062
    z[6,0,1]  R545      -5.2580362558364868e-01
    z[6,0,2]  R4        1
    z[6,0,2]  R58       -1
    z[6,0,2]  R436      -1
    z[6,0,2]  R437      1
    z[6,0,2]  R446      -5.4525830782949924e-03
    z[6,0,2]  R447      -2.1860765293240547e-02
    z[6,0,2]  R448      3.9826986193656921e-01
    z[6,0,2]  R449      7.2109901905059814e-01
    z[6,0,2]  R450      2.4163636565208435e-01
    z[6,0,2]  R451      -1.7734654247760773e-01
    z[6,0,2]  R452      1.7134083807468414e-01
    z[6,0,2]  R453      -4.6825617551803589e-02
    z[6,0,2]  R454      1.2852217257022858e-01
    z[6,0,2]  R455      1.9431334733963013e-01
    z[6,0,2]  R456      -4.2230904102325439e-01
    z[6,0,2]  R457      -2.5339594483375549e-01
    z[6,0,2]  R458      -3.4795930981636047e-01
    z[6,0,2]  R459      -6.3886839151382446e-01
    z[6,0,2]  R460      -1.8048506975173950e-01
    z[6,0,2]  R461      -0.401504784822464
    z[6,0,2]  R462      -2.5141322612762451e-01
    z[6,0,2]  R463      -4.0240389108657837e-01
    z[6,0,2]  R464      -4.6404087543487549e-01
    z[6,0,2]  R465      -2.8564265370368958e-01
    z[6,0,2]  R466      -0.062485221773386
    z[6,0,2]  R467      1.3245701789855957e-01
    z[6,0,2]  R468      1.8474271893501282e-01
    z[6,0,2]  R469      3.9558848738670349e-01
    z[6,0,2]  R470      -2.3664797842502594e-01
    z[6,0,2]  R471      1.3192997872829437e-01
    z[6,0,2]  R472      -3.4804251790046692e-01
    z[6,0,2]  R473      1.7199221253395081e-01
    z[6,0,2]  R474      3.8362555205821991e-02
    z[6,0,2]  R475      1.2735572457313538e-01
    z[6,0,2]  R476      -1.3399665057659149e-01
    z[6,0,2]  R477      -3.9168280363082886e-01
    z[6,0,2]  R478      -4.4084903597831726e-01
    z[6,0,2]  R479      -8.7382178753614426e-03
    z[6,0,2]  R480      -1.4443391561508179e-01
    z[6,0,2]  R481      -0.0871066004037857
    z[6,0,2]  R482      -7.0164717733860016e-02
    z[6,0,2]  R483      2.2188569605350494e-01
    z[6,0,2]  R484      -4.7210793942213058e-02
    z[6,0,2]  R485      0.072322316467762
    z[6,0,2]  R486      6.9641411304473877e-01
    z[6,0,2]  R487      6.1756026744842529e-01
    z[6,0,2]  R488      0.746904730796814
    z[6,0,2]  R489      4.7763559222221375e-01
    z[6,0,2]  R490      3.4936192631721497e-01
    z[6,0,2]  R491      5.7652479410171509e-01
    z[6,0,2]  R492      2.7917012572288513e-01
    z[6,0,2]  R493      7.9882211983203888e-02
    z[6,0,2]  R494      4.9595010280609131e-01
    z[6,0,2]  R495      -3.1767857726663351e-03
    z[6,0,2]  R496      -3.7552466988563538e-01
    z[6,0,2]  R497      -5.4819935560226440e-01
    z[6,0,2]  R498      -5.2614951133728027e-01
    z[6,0,2]  R499      -1.4535656571388245e-01
    z[6,0,2]  R500      -3.7699118256568909e-01
    z[6,0,2]  R501      -5.6106412410736084e-01
    z[6,0,2]  R502      -4.4130784273147583e-01
    z[6,0,2]  R503      -4.3506258726119995e-01
    z[6,0,2]  R504      -5.6248861551284790e-01
    z[6,0,2]  R505      -3.6139541864395142e-01
    z[6,0,2]  R506      1.6493658721446991e-01
    z[6,0,2]  R507      1.7390790581703186e-01
    z[6,0,2]  R508      3.4230497479438782e-01
    z[6,0,2]  R509      -1.2580266594886780e-01
    z[6,0,2]  R510      -1.4868043363094330e-01
    z[6,0,2]  R511      -1.2460289150476456e-01
    z[6,0,2]  R512      -0.503728985786438
    z[6,0,2]  R513      8.4312453866004944e-02
    z[6,0,2]  R514      -2.4389077723026276e-01
    z[6,0,2]  R515      -3.0800363421440125e-01
    z[6,0,2]  R516      1.3863548636436462e-01
    z[6,0,2]  R517      -2.7512248605489731e-02
    z[6,0,2]  R518      -6.1390563845634460e-02
    z[6,0,2]  R519      -1.9287452101707458e-01
    z[6,0,2]  R520      -3.9840704202651978e-01
    z[6,0,2]  R521      -1.1714725941419601e-01
    z[6,0,2]  R522      -2.4716173112392426e-01
    z[6,0,2]  R523      -2.9159530997276306e-01
    z[6,0,2]  R524      -1.0140753537416458e-01
    z[6,0,2]  R525      -3.0194488167762756e-01
    z[6,0,2]  R526      -1.9755041599273682e-01
    z[6,0,2]  R527      -2.4487484991550446e-01
    z[6,0,2]  R528      -0.43577840924263
    z[6,0,2]  R529      -1.1846154229715466e-03
    z[6,0,2]  R530      7.1419939398765564e-02
    z[6,0,2]  R531      -1.8547539412975311e-01
    z[6,0,2]  R532      -3.4186357259750366e-01
    z[6,0,2]  R533      -5.1645022630691528e-01
    z[6,0,2]  R534      -1.0560575872659683e-01
    z[6,0,2]  R535      -1.4410842955112457e-01
    z[6,0,2]  R536      6.8419404327869415e-02
    z[6,0,2]  R537      -4.0451448410749435e-02
    z[6,0,2]  R538      -1.9884806871414185e-01
    z[6,0,2]  R539      -2.1745659410953522e-01
    z[6,0,2]  R540      -2.4599377810955048e-01
    z[6,0,2]  R541      2.0575824379920959e-01
    z[6,0,2]  R542      -4.7127166390419006e-01
    z[6,0,2]  R543      1.4961537718772888e-01
    z[6,0,2]  R544      -1.8319293856620789e-01
    z[6,0,2]  R545      -1.3706816732883453e-01
    z[6,0,3]  R5        1
    z[6,0,3]  R59       -1
    z[6,0,3]  R438      -1
    z[6,0,3]  R439      1
    z[6,0,3]  R446      -7.8702464699745178e-02
    z[6,0,3]  R447      -5.4290610551834106e-01
    z[6,0,3]  R448      -1.7345812916755676e-01
    z[6,0,3]  R449      -2.7939155697822571e-01
    z[6,0,3]  R450      -4.9790588021278381e-01
    z[6,0,3]  R451      -4.0655446052551270e-01
    z[6,0,3]  R452      -4.7898799180984497e-01
    z[6,0,3]  R453      -3.0154135823249817e-01
    z[6,0,3]  R454      -3.7619385123252869e-01
    z[6,0,3]  R455      -0.323411226272583
    z[6,0,3]  R456      3.9414972066879272e-01
    z[6,0,3]  R457      2.9318007826805115e-01
    z[6,0,3]  R458      1.6355967149138451e-02
    z[6,0,3]  R459      -4.4523615390062332e-02
    z[6,0,3]  R460      2.1793028712272644e-01
    z[6,0,3]  R461      -2.7577212080359459e-02
    z[6,0,3]  R462      2.9820641875267029e-01
    z[6,0,3]  R463      4.6124079823493958e-01
    z[6,0,3]  R464      3.5927388817071915e-02
    z[6,0,3]  R465      5.1341433078050613e-02
    z[6,0,3]  R466      7.0136207342147827e-01
    z[6,0,3]  R467      -9.1290250420570374e-02
    z[6,0,3]  R468      -1.4799717068672180e-01
    z[6,0,3]  R469      -1.5839058160781860e-01
    z[6,0,3]  R470      -1.9270788133144379e-01
    z[6,0,3]  R471      2.3124691843986511e-01
    z[6,0,3]  R472      -4.1036497801542282e-02
    z[6,0,3]  R473      2.1468129009008408e-02
    z[6,0,3]  R474      -2.4786441028118134e-01
    z[6,0,3]  R475      8.2508064806461334e-02
    z[6,0,3]  R476      3.2507243752479553e-01
    z[6,0,3]  R477      4.1435372829437256e-01
    z[6,0,3]  R478      9.4971351325511932e-02
    z[6,0,3]  R479      3.5890835523605347e-01
    z[6,0,3]  R480      2.7370864152908325e-01
    z[6,0,3]  R481      1.5111638605594635e-01
    z[6,0,3]  R482      3.9690554141998291e-01
    z[6,0,3]  R483      1.9343625009059906e-01
    z[6,0,3]  R484      -1.6232079267501831e-01
    z[6,0,3]  R485      1.5407501161098480e-01
    z[6,0,3]  R486      5.1677453517913818e-01
    z[6,0,3]  R487      1.2330103665590286e-01
    z[6,0,3]  R488      1.6277417540550232e-01
    z[6,0,3]  R489      4.2016741633415222e-01
    z[6,0,3]  R490      2.2670869529247284e-01
    z[6,0,3]  R491      2.6785820722579956e-01
    z[6,0,3]  R492      -1.0430599562823772e-02
    z[6,0,3]  R493      3.7662589550018311e-01
    z[6,0,3]  R494      2.8773674368858337e-01
    z[6,0,3]  R495      7.7458918094635010e-01
    z[6,0,3]  R496      1.6704623401165009e-01
    z[6,0,3]  R497      2.3247901350259781e-02
    z[6,0,3]  R498      4.1320866346359253e-01
    z[6,0,3]  R499      0.0545872300863266
    z[6,0,3]  R500      1.2594187259674072e-01
    z[6,0,3]  R501      1.6451855003833771e-01
    z[6,0,3]  R502      3.3085045218467712e-01
    z[6,0,3]  R503      2.4973908066749573e-01
    z[6,0,3]  R504      3.9302092790603638e-01
    z[6,0,3]  R505      -8.9879669249057770e-02
    z[6,0,3]  R506      -5.6031066179275513e-01
    z[6,0,3]  R507      -9.8044604063034058e-02
    z[6,0,3]  R508      -1.3259139657020569e-01
    z[6,0,3]  R509      -0.507114827632904
    z[6,0,3]  R510      -6.7938894033432007e-01
    z[6,0,3]  R511      -6.5618109703063965e-01
    z[6,0,3]  R512      -6.9857668876647949e-01
    z[6,0,3]  R513      -6.7651957273483276e-01
    z[6,0,3]  R514      -0.729148805141449
    z[6,0,3]  R515      -6.4328622817993164e-01
    z[6,0,3]  R516      6.0929656028747559e-02
    z[6,0,3]  R517      4.4564566016197205e-01
    z[6,0,3]  R518      -4.6845340728759766e-01
    z[6,0,3]  R519      0.217659592628479
    z[6,0,3]  R520      -2.1393077075481415e-01
    z[6,0,3]  R521      -2.3716230690479279e-01
    z[6,0,3]  R522      -3.2082572579383850e-01
    z[6,0,3]  R523      4.1865665465593338e-02
    z[6,0,3]  R524      -9.6946984529495239e-02
    z[6,0,3]  R525      8.9062482118606567e-02
    z[6,0,3]  R526      -3.2469424605369568e-01
    z[6,0,3]  R527      -3.8564404845237732e-01
    z[6,0,3]  R528      1.9415273563936353e-03
    z[6,0,3]  R529      -0.000567007577046752
    z[6,0,3]  R530      -0.308651328086853
    z[6,0,3]  R531      2.7416145801544189e-01
    z[6,0,3]  R532      -7.5802463293075562e-01
    z[6,0,3]  R533      -6.2473946809768677e-01
    z[6,0,3]  R534      -0.938624382019043
    z[6,0,3]  R535      -6.4770805835723877e-01
    z[6,0,3]  R536      5.8693759143352509e-02
    z[6,0,3]  R537      1.9043010473251343e-01
    z[6,0,3]  R538      2.8132423758506775e-01
    z[6,0,3]  R539      -7.3013061285018921e-01
    z[6,0,3]  R540      -7.1067994832992554e-01
    z[6,0,3]  R541      -7.9846704006195068e-01
    z[6,0,3]  R542      -0.622801661491394
    z[6,0,3]  R543      -4.3773502111434937e-01
    z[6,0,3]  R544      1.8729162216186523e-01
    z[6,0,3]  R545      -9.3009635806083679e-02
    z[6,0,4]  R6        1
    z[6,0,4]  R60       -1
    z[6,0,4]  R440      -1
    z[6,0,4]  R441      1
    z[6,0,4]  R446      -6.5583787858486176e-02
    z[6,0,4]  R447      -0.0800815224647522
    z[6,0,4]  R448      -6.0458654165267944e-01
    z[6,0,4]  R449      -1.7526540160179138e-01
    z[6,0,4]  R450      1.7153823375701904e-01
    z[6,0,4]  R451      -5.8877730369567871e-01
    z[6,0,4]  R452      -0.381697416305542
    z[6,0,4]  R453      2.6414009928703308e-01
    z[6,0,4]  R454      -6.7557895183563232e-01
    z[6,0,4]  R455      -8.0988389253616333e-01
    z[6,0,4]  R456      3.0215349048376083e-02
    z[6,0,4]  R457      -1.1738082021474838e-01
    z[6,0,4]  R458      1.1353948712348938e-01
    z[6,0,4]  R459      -4.5189879834651947e-02
    z[6,0,4]  R460      1.2621504068374634e-01
    z[6,0,4]  R461      -2.8321878984570503e-02
    z[6,0,4]  R462      2.0029008388519287e-01
    z[6,0,4]  R463      1.5489107370376587e-01
    z[6,0,4]  R464      -1.4238531701266766e-02
    z[6,0,4]  R465      1.7537397146224976e-01
    z[6,0,4]  R466      -7.3311820626258850e-02
    z[6,0,4]  R467      8.1896416842937469e-02
    z[6,0,4]  R468      -1.5243300795555115e-01
    z[6,0,4]  R469      4.0392596274614334e-02
    z[6,0,4]  R470      -2.4234730750322342e-02
    z[6,0,4]  R471      -2.0024940371513367e-01
    z[6,0,4]  R472      5.5311162024736404e-02
    z[6,0,4]  R473      -3.4424898028373718e-01
    z[6,0,4]  R474      6.6722683608531952e-02
    z[6,0,4]  R475      -2.4594143033027649e-02
    z[6,0,4]  R476      1.2444531172513962e-01
    z[6,0,4]  R477      0.046059750020504
    z[6,0,4]  R478      1.2458857148885727e-01
    z[6,0,4]  R479      -2.6181265711784363e-01
    z[6,0,4]  R480      -1.2470588833093643e-01
    z[6,0,4]  R481      -2.0413656532764435e-01
    z[6,0,4]  R482      -1.0960114002227783e-01
    z[6,0,4]  R483      1.5741668641567230e-01
    z[6,0,4]  R484      8.2987584173679352e-02
    z[6,0,4]  R485      1.7803196609020233e-01
    z[6,0,4]  R486      -4.1218571364879608e-02
    z[6,0,4]  R487      0.352463036775589
    z[6,0,4]  R488      -2.4997876584529877e-01
    z[6,0,4]  R489      3.1200459599494934e-01
    z[6,0,4]  R490      -1.5997199714183807e-01
    z[6,0,4]  R491      -5.0467513501644135e-02
    z[6,0,4]  R492      3.9517077803611755e-01
    z[6,0,4]  R493      -3.3496016263961792e-01
    z[6,0,4]  R494      -2.5108709931373596e-01
    z[6,0,4]  R495      5.7777430862188339e-02
    z[6,0,4]  R496      -2.4556618183851242e-02
    z[6,0,4]  R497      -7.3936069384217262e-03
    z[6,0,4]  R498      1.3218869268894196e-01
    z[6,0,4]  R499      4.1001036763191223e-02
    z[6,0,4]  R500      2.5220713019371033e-01
    z[6,0,4]  R501      1.9193364679813385e-01
    z[6,0,4]  R502      -5.9747759252786636e-02
    z[6,0,4]  R503      -8.6109027266502380e-02
    z[6,0,4]  R504      1.3745196163654327e-01
    z[6,0,4]  R505      0.0350436307489872
    z[6,0,4]  R506      9.5477670431137085e-02
    z[6,0,4]  R507      -3.7079265713691711e-01
    z[6,0,4]  R508      -1.3064685463905334e-01
    z[6,0,4]  R509      3.2557407021522522e-01
    z[6,0,4]  R510      -1.3982348144054413e-01
    z[6,0,4]  R511      1.1141499131917953e-01
    z[6,0,4]  R512      -7.0524394512176514e-02
    z[6,0,4]  R513      8.8269263505935669e-02
    z[6,0,4]  R514      4.1587015986442566e-01
    z[6,0,4]  R515      4.0703928470611572e-01
    z[6,0,4]  R516      -2.1439389884471893e-01
    z[6,0,4]  R517      -2.3072990775108337e-01
    z[6,0,4]  R518      2.6333945989608765e-01
    z[6,0,4]  R519      2.4770571291446686e-01
    z[6,0,4]  R520      2.1385875344276428e-01
    z[6,0,4]  R521      6.0413964092731476e-02
    z[6,0,4]  R522      -2.5798571109771729e-01
    z[6,0,4]  R523      -1.1370173841714859e-01
    z[6,0,4]  R524      0.359660267829895
    z[6,0,4]  R525      5.8230042457580566e-02
    z[6,0,4]  R526      1.2516547739505768e-01
    z[6,0,4]  R527      -3.8943123072385788e-02
    z[6,0,4]  R528      -5.8395609259605408e-02
    z[6,0,4]  R529      0.284589558839798
    z[6,0,4]  R530      -3.4502550959587097e-01
    z[6,0,4]  R531      -6.8094119429588318e-02
    z[6,0,4]  R532      -7.7331632375717163e-02
    z[6,0,4]  R533      2.8215774893760681e-01
    z[6,0,4]  R534      1.0871417075395584e-01
    z[6,0,4]  R535      -1.9560030195862055e-03
    z[6,0,4]  R536      -1.1534772813320160e-01
    z[6,0,4]  R537      1.9251872599124908e-01
    z[6,0,4]  R538      0.0800652801990509
    z[6,0,4]  R539      1.9722582772374153e-02
    z[6,0,4]  R540      5.0033140927553177e-02
    z[6,0,4]  R541      -2.4309885501861572e-01
    z[6,0,4]  R542      9.8878055810928345e-02
    z[6,0,4]  R543      5.3946918249130249e-01
    z[6,0,4]  R544      1.6274869441986084e-01
    z[6,0,4]  R545      -4.7675538808107376e-03
    z[6,0,5]  R7        1
    z[6,0,5]  R61       -1
    z[6,0,5]  R442      -1
    z[6,0,5]  R443      1
    z[6,0,5]  R446      -6.5855300426483154e-01
    z[6,0,5]  R447      -0.524657666683197
    z[6,0,5]  R448      2.6140136644244194e-02
    z[6,0,5]  R449      -6.4212411642074585e-02
    z[6,0,5]  R450      3.1182447075843811e-01
    z[6,0,5]  R451      -1.8741479516029358e-01
    z[6,0,5]  R452      -1.5266482532024384e-01
    z[6,0,5]  R453      3.9203429222106934e-01
    z[6,0,5]  R454      2.8428819775581360e-01
    z[6,0,5]  R455      -1.8582858145236969e-01
    z[6,0,5]  R456      8.4322936832904816e-02
    z[6,0,5]  R457      2.0743592083454132e-01
    z[6,0,5]  R458      -9.0206608176231384e-02
    z[6,0,5]  R459      1.6514307260513306e-01
    z[6,0,5]  R460      2.6645395159721375e-01
    z[6,0,5]  R461      3.2838270068168640e-01
    z[6,0,5]  R462      5.2637696266174316e-01
    z[6,0,5]  R463      -1.9093910232186317e-02
    z[6,0,5]  R464      1.6806872189044952e-01
    z[6,0,5]  R465      5.1751202344894409e-01
    z[6,0,5]  R466      3.1335690617561340e-01
    z[6,0,5]  R467      -2.0860818028450012e-01
    z[6,0,5]  R468      -5.0855904817581177e-02
    z[6,0,5]  R469      -7.0194430649280548e-02
    z[6,0,5]  R470      -5.6670308113098145e-02
    z[6,0,5]  R471      -3.5609897971153259e-01
    z[6,0,5]  R472      -2.5435757637023926e-01
    z[6,0,5]  R473      -1.9326642155647278e-01
    z[6,0,5]  R474      8.5207270458340645e-03
    z[6,0,5]  R475      -4.3164554983377457e-02
    z[6,0,5]  R476      9.4563901424407959e-02
    z[6,0,5]  R477      2.2803477942943573e-01
    z[6,0,5]  R478      -2.3928210139274597e-01
    z[6,0,5]  R479      1.7281684279441833e-01
    z[6,0,5]  R480      1.2834899127483368e-01
    z[6,0,5]  R481      4.2434215545654297e-01
    z[6,0,5]  R482      -6.4620628952980042e-02
    z[6,0,5]  R483      0.515661358833313
    z[6,0,5]  R484      6.4931267499923706e-01
    z[6,0,5]  R485      3.6160182952880859e-01
    z[6,0,5]  R486      1.9684407114982605e-01
    z[6,0,5]  R487      2.1400873363018036e-01
    z[6,0,5]  R488      1.7545576393604279e-01
    z[6,0,5]  R489      -8.3863191306591034e-02
    z[6,0,5]  R490      3.5342969000339508e-02
    z[6,0,5]  R491      -2.2698865830898285e-01
    z[6,0,5]  R492      3.7799999117851257e-01
    z[6,0,5]  R493      -7.9122260212898254e-03
    z[6,0,5]  R494      2.4082399904727936e-01
    z[6,0,5]  R495      1.1017414927482605e-01
    z[6,0,5]  R496      3.6226198077201843e-01
    z[6,0,5]  R497      3.0144955962896347e-02
    z[6,0,5]  R498      1.4294551312923431e-01
    z[6,0,5]  R499      1.7544165253639221e-01
    z[6,0,5]  R500      2.3372095823287964e-01
    z[6,0,5]  R501      4.1231876611709595e-01
    z[6,0,5]  R502      3.9987576007843018e-01
    z[6,0,5]  R503      4.1314443945884705e-01
    z[6,0,5]  R504      3.3306348323822021e-01
    z[6,0,5]  R505      1.6043521463871002e-01
    z[6,0,5]  R506      -5.6281950324773788e-02
    z[6,0,5]  R507      -3.6464065313339233e-01
    z[6,0,5]  R508      -3.4621521830558777e-01
    z[6,0,5]  R509      -4.0698921680450439e-01
    z[6,0,5]  R510      -4.0686112642288208e-01
    z[6,0,5]  R511      -2.8368967771530151e-01
    z[6,0,5]  R512      -1.4950375258922577e-01
    z[6,0,5]  R513      -2.9358950257301331e-01
    z[6,0,5]  R514      9.5859030261635780e-03
    z[6,0,5]  R515      -3.9522635936737061e-01
    z[6,0,5]  R516      -1.6145195066928864e-01
    z[6,0,5]  R517      -1.9120676815509796e-01
    z[6,0,5]  R518      -1.1766610294580460e-01
    z[6,0,5]  R519      -2.3118594661355019e-02
    z[6,0,5]  R520      -8.8029861450195312e-02
    z[6,0,5]  R521      -1.0294277220964432e-01
    z[6,0,5]  R522      -3.1823366880416870e-01
    z[6,0,5]  R523      -2.9804265499114990e-01
    z[6,0,5]  R524      -3.8015264272689819e-01
    z[6,0,5]  R525      -5.3212952613830566e-01
    z[6,0,5]  R526      -1.7609718441963196e-01
    z[6,0,5]  R527      -2.2707961499691010e-01
    z[6,0,5]  R528      -2.2068646550178528e-01
    z[6,0,5]  R529      -3.7052431702613831e-01
    z[6,0,5]  R530      1.1809995397925377e-02
    z[6,0,5]  R531      -1.8104976415634155e-01
    z[6,0,5]  R532      1.3202938437461853e-01
    z[6,0,5]  R533      -9.1548189520835876e-03
    z[6,0,5]  R534      -8.9364543557167053e-02
    z[6,0,5]  R535      4.1444590687751770e-01
    z[6,0,5]  R536      7.5835309922695160e-02
    z[6,0,5]  R537      7.5173109769821167e-02
    z[6,0,5]  R538      -1.4381489157676697e-01
    z[6,0,5]  R539      -2.3718622326850891e-01
    z[6,0,5]  R540      -3.9254122972488403e-01
    z[6,0,5]  R541      -6.2953993678092957e-02
    z[6,0,5]  R542      -5.6849384307861328e-01
    z[6,0,5]  R543      3.0457329750061035e-01
    z[6,0,5]  R544      4.8995118588209152e-02
    z[6,0,5]  R545      2.5946235656738281e-01
    z[6,0,6]  R8        1
    z[6,0,6]  R62       -1
    z[6,0,6]  R444      -1
    z[6,0,6]  R445      1
    z[6,0,6]  R446      -1.2277911603450775e-01
    z[6,0,6]  R447      -3.5015437752008438e-02
    z[6,0,6]  R448      -3.1789663434028625e-01
    z[6,0,6]  R449      -4.2904266715049744e-01
    z[6,0,6]  R450      1.8472722172737122e-01
    z[6,0,6]  R451      3.4748157858848572e-01
    z[6,0,6]  R452      -5.6928563117980957e-01
    z[6,0,6]  R453      -4.9426713585853577e-01
    z[6,0,6]  R454      1.2183386087417603e-01
    z[6,0,6]  R455      -2.6246858760714531e-02
    z[6,0,6]  R456      0.182825967669487
    z[6,0,6]  R457      0.10972910374403
    z[6,0,6]  R458      -8.3172051236033440e-03
    z[6,0,6]  R459      -0.00973269622772932
    z[6,0,6]  R460      2.7663874626159668e-01
    z[6,0,6]  R461      -2.4992136657238007e-01
    z[6,0,6]  R462      6.2270566821098328e-02
    z[6,0,6]  R463      -2.2644624114036560e-01
    z[6,0,6]  R464      -1.0564853996038437e-01
    z[6,0,6]  R465      9.0046428143978119e-02
    z[6,0,6]  R466      2.4305772781372070e-01
    z[6,0,6]  R467      -3.6850892007350922e-02
    z[6,0,6]  R468      -1.3209588825702667e-01
    z[6,0,6]  R469      2.0862698554992676e-01
    z[6,0,6]  R470      2.3921461403369904e-01
    z[6,0,6]  R471      1.3593156635761261e-01
    z[6,0,6]  R472      -2.0570243895053864e-01
    z[6,0,6]  R473      2.8194564580917358e-01
    z[6,0,6]  R474      3.9390745759010315e-01
    z[6,0,6]  R475      5.0124108791351318e-01
    z[6,0,6]  R476      1.9057209789752960e-01
    z[6,0,6]  R477      -2.1545395255088806e-01
    z[6,0,6]  R478      1.2802718579769135e-01
    z[6,0,6]  R479      -9.1979824006557465e-02
    z[6,0,6]  R480      -1.4083835482597351e-01
    z[6,0,6]  R481      1.5833540260791779e-01
    z[6,0,6]  R482      -2.6506617665290833e-01
    z[6,0,6]  R483      -0.0858563557267189
    z[6,0,6]  R484      -8.7235406041145325e-02
    z[6,0,6]  R485      -4.4462716579437256e-01
    z[6,0,6]  R486      -2.3867608606815338e-01
    z[6,0,6]  R487      -2.8994879126548767e-01
    z[6,0,6]  R488      2.2076773643493652e-01
    z[6,0,6]  R489      -3.2592701911926270e-01
    z[6,0,6]  R490      -3.1702980399131775e-02
    z[6,0,6]  R491      1.8523052334785461e-01
    z[6,0,6]  R492      1.6725838184356689e-01
    z[6,0,6]  R493      8.6627446115016937e-02
    z[6,0,6]  R494      2.2655488550662994e-01
    z[6,0,6]  R495      2.8011319041252136e-01
    z[6,0,6]  R496      0.245841383934021
    z[6,0,6]  R497      0.097848080098629
    z[6,0,6]  R498      -1.8725836277008057e-01
    z[6,0,6]  R499      -2.1693013608455658e-02
    z[6,0,6]  R500      3.1365182995796204e-01
    z[6,0,6]  R501      1.1375698447227478e-01
    z[6,0,6]  R502      9.7162231802940369e-02
    z[6,0,6]  R503      -1.0808359831571579e-01
    z[6,0,6]  R504      -6.4100623130798340e-02
    z[6,0,6]  R505      1.3626888394355774e-01
    z[6,0,6]  R506      -1.7072747647762299e-01
    z[6,0,6]  R507      -3.0899396166205406e-02
    z[6,0,6]  R508      -4.1400483250617981e-01
    z[6,0,6]  R509      -8.5938654839992523e-02
    z[6,0,6]  R510      -1.3139389455318451e-01
    z[6,0,6]  R511      -1.9289404153823853e-01
    z[6,0,6]  R512      2.1805499494075775e-01
    z[6,0,6]  R513      -3.6004860885441303e-03
    z[6,0,6]  R514      -1.7021040618419647e-01
    z[6,0,6]  R515      -8.1121474504470825e-03
    z[6,0,6]  R516      -8.0257803201675415e-02
    z[6,0,6]  R517      0.00755949504673481
    z[6,0,6]  R518      -9.6115969121456146e-02
    z[6,0,6]  R519      -9.2945620417594910e-02
    z[6,0,6]  R520      2.6474019885063171e-01
    z[6,0,6]  R521      -4.0284439921379089e-01
    z[6,0,6]  R522      6.5613955259323120e-02
    z[6,0,6]  R523      4.5896759629249573e-01
    z[6,0,6]  R524      -1.4630749821662903e-01
    z[6,0,6]  R525      -2.8226310014724731e-01
    z[6,0,6]  R526      -0.154501274228096
    z[6,0,6]  R527      2.2523556649684906e-01
    z[6,0,6]  R528      3.8888379931449890e-01
    z[6,0,6]  R529      -3.0032485723495483e-01
    z[6,0,6]  R530      3.7741836905479431e-01
    z[6,0,6]  R531      -3.9454710483551025e-01
    z[6,0,6]  R532      1.6951330006122589e-01
    z[6,0,6]  R533      -1.9711382687091827e-01
    z[6,0,6]  R534      -3.0246462672948837e-02
    z[6,0,6]  R535      -1.7947243154048920e-01
    z[6,0,6]  R536      -2.1330793201923370e-01
    z[6,0,6]  R537      -2.7563467621803284e-01
    z[6,0,6]  R538      -3.2324469089508057e-01
    z[6,0,6]  R539      6.4031504094600677e-02
    z[6,0,6]  R540      -1.0182687640190125e-01
    z[6,0,6]  R541      -8.6366616189479828e-02
    z[6,0,6]  R542      2.0609053969383240e-01
    z[6,0,6]  R543      7.7185044065117836e-03
    z[6,0,6]  R544      3.2198838889598846e-02
    z[6,0,6]  R545      0.0327945351600647
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R620      -1
    z[1,2,0]  R621      1
    z[1,2,0]  R634      2.8589609265327454e-01
    z[1,2,0]  R635      4.8036411404609680e-01
    z[1,2,0]  R636      2.5183260440826416e-01
    z[1,2,0]  R637      3.0372983217239380e-01
    z[1,2,0]  R638      -9.2242234945297241e-01
    z[1,2,0]  R639      -8.9510083198547363e-01
    z[1,2,0]  R640      1.8954648077487946e-01
    z[1,2,0]  R641      -8.5063797235488892e-01
    z[1,2,0]  R642      -8.1500744819641113e-01
    z[1,2,0]  R643      -8.3995550870895386e-01
    z[1,2,0]  R644      8.3946204185485840e-01
    z[1,2,0]  R645      8.5628277063369751e-01
    z[1,2,0]  R646      7.4340730905532837e-01
    z[1,2,0]  R647      7.0932799577713013e-01
    z[1,2,0]  R648      8.0658096075057983e-01
    z[1,2,0]  R649      8.5277885198593140e-01
    z[1,2,0]  R650      6.2278401851654053e-01
    z[1,2,0]  R651      5.2813696861267090e-01
    z[1,2,0]  R652      6.4491635560989380e-01
    z[1,2,0]  R653      4.3566048145294189e-01
    z[1,2,0]  R654      8.1669247150421143e-01
    z[1,2,0]  R655      7.2770011425018311e-01
    z[1,2,0]  R656      5.3186315298080444e-01
    z[1,2,0]  R657      -6.5128237009048462e-01
    z[1,2,0]  R658      8.2274824380874634e-01
    z[1,2,0]  R659      4.9348068237304688e-01
    z[1,2,0]  R660      3.7716588377952576e-01
    z[1,2,0]  R661      -9.0435231104493141e-03
    z[1,2,0]  R662      -6.4122684299945831e-02
    z[1,2,0]  R663      -1.5305294096469879e-01
    z[1,2,0]  R664      7.0274728536605835e-01
    z[1,2,0]  R665      5.2221375703811646e-01
    z[1,2,0]  R666      4.7327014803886414e-01
    z[1,2,0]  R667      5.6887823343276978e-01
    z[1,2,0]  R668      9.1267181560397148e-03
    z[1,2,0]  R669      0.031141497194767
    z[1,2,0]  R670      1.1161900311708450e-01
    z[1,2,0]  R671      -1.6556279733777046e-02
    z[1,2,0]  R672      -1.8656864762306213e-01
    z[1,2,0]  R673      -4.1689458489418030e-01
    z[1,2,0]  R674      -4.8468196392059326e-01
    z[1,2,0]  R675      -5.7306480407714844e-01
    z[1,2,0]  R676      -3.4239238500595093e-01
    z[1,2,0]  R677      -6.0957503318786621e-01
    z[1,2,0]  R678      -3.2015225291252136e-01
    z[1,2,0]  R679      -3.0857360363006592e-01
    z[1,2,0]  R680      -3.9235708117485046e-01
    z[1,2,0]  R681      -3.4801444411277771e-01
    z[1,2,0]  R682      3.6987990140914917e-02
    z[1,2,0]  R683      3.7160363048315048e-02
    z[1,2,0]  R684      4.9446426331996918e-02
    z[1,2,0]  R685      9.2987410724163055e-02
    z[1,2,0]  R686      1.6451187431812286e-01
    z[1,2,0]  R687      3.8392234593629837e-02
    z[1,2,0]  R688      2.3820878937840462e-02
    z[1,2,0]  R689      -3.6871144175529480e-01
    z[1,2,0]  R690      -1.8168369308114052e-02
    z[1,2,0]  R691      4.3558844923973083e-01
    z[1,2,0]  R692      -3.8961544632911682e-02
    z[1,2,0]  R693      2.1219049394130707e-01
    z[1,2,0]  R694      1.0946871340274811e-01
    z[1,2,0]  R695      -1.0069070756435394e-01
    z[1,2,0]  R696      5.2443742752075195e-02
    z[1,2,0]  R697      2.7736195921897888e-01
    z[1,2,0]  R698      -9.2849425971508026e-02
    z[1,2,0]  R699      -9.0580090880393982e-02
    z[1,2,0]  R700      -1.5218126773834229e-01
    z[1,2,0]  R701      -3.0100749805569649e-02
    z[1,2,0]  R702      -3.4075182676315308e-01
    z[1,2,0]  R703      -1.8804021179676056e-01
    z[1,2,0]  R704      -1.2020721286535263e-01
    z[1,2,0]  R705      1.3284712098538876e-02
    z[1,2,0]  R706      -1.1131456494331360e-01
    z[1,2,0]  R707      -1.0430975258350372e-01
    z[1,2,0]  R708      -2.2587503492832184e-01
    z[1,2,0]  R709      -1.0576321184635162e-01
    z[1,2,0]  R710      -2.6120189577341080e-02
    z[1,2,0]  R711      8.6152262985706329e-02
    z[1,2,0]  R712      1.7868988215923309e-01
    z[1,2,0]  R713      2.1687847375869751e-01
    z[1,2,0]  R714      -7.6703220605850220e-02
    z[1,2,0]  R715      -5.7236045598983765e-01
    z[1,2,0]  R716      3.7944954633712769e-01
    z[1,2,0]  R717      -1.9736465811729431e-01
    z[1,2,0]  R718      -3.9486771821975708e-01
    z[1,2,0]  R719      0.0852629616856575
    z[1,2,0]  R720      -2.9006785154342651e-01
    z[1,2,0]  R721      1.5264980494976044e-01
    z[1,2,0]  R722      2.2403240203857422e-01
    z[1,2,0]  R723      -2.2230571508407593e-01
    z[1,2,0]  R724      -3.1105026602745056e-01
    z[1,2,0]  R725      -5.1620435714721680e-01
    z[1,2,0]  R726      -1.7105893790721893e-01
    z[1,2,0]  R727      2.1935540437698364e-01
    z[1,2,0]  R728      1.0663330322131515e-03
    z[1,2,0]  R729      -3.1086322665214539e-01
    z[1,2,0]  R730      4.4636088609695435e-01
    z[1,2,0]  R731      6.9318538904190063e-01
    z[1,2,0]  R732      8.1855165958404541e-01
    z[1,2,0]  R733      4.0272515267133713e-02
    z[1,2,0]  R734      3.4263002872467041e-01
    z[1,2,0]  R735      -1.5010145306587219e-01
    z[1,2,0]  R736      -1.5877915918827057e-01
    z[1,2,0]  R737      -2.8038141131401062e-01
    z[1,2,0]  R738      2.9783645272254944e-01
    z[1,2,0]  R739      -3.5361889004707336e-01
    z[1,2,0]  R740      -2.7545174956321716e-01
    z[1,2,0]  R741      -3.9055564999580383e-01
    z[1,2,0]  R742      3.1482365727424622e-01
    z[1,2,0]  R743      1.7461758852005005e-01
    z[1,2,0]  R744      -2.4204730987548828e-01
    z[1,2,0]  R745      -3.5855054855346680e-01
    z[1,2,0]  R746      -2.6036825776100159e-01
    z[1,2,0]  R747      2.1546375751495361e-01
    z[1,2,0]  R748      6.7238390445709229e-02
    z[1,2,0]  R749      -2.7760851383209229e-01
    z[1,2,0]  R750      7.6810318231582642e-01
    z[1,2,0]  R751      9.5003110170364380e-01
    z[1,2,0]  R752      9.3456918001174927e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R622      -1
    z[1,2,1]  R623      1
    z[1,2,1]  R634      -3.8261207938194275e-01
    z[1,2,1]  R635      -3.9298757910728455e-01
    z[1,2,1]  R636      -3.2411766052246094e-01
    z[1,2,1]  R637      -3.6309796571731567e-01
    z[1,2,1]  R638      1.9612239301204681e-01
    z[1,2,1]  R639      9.2389337718486786e-02
    z[1,2,1]  R640      -2.6568973064422607e-01
    z[1,2,1]  R641      -5.6720346212387085e-02
    z[1,2,1]  R642      1.1615302413702011e-01
    z[1,2,1]  R643      1.9600871205329895e-01
    z[1,2,1]  R644      -1.3788338005542755e-01
    z[1,2,1]  R645      -1.0093265026807785e-01
    z[1,2,1]  R646      -1.5189656615257263e-01
    z[1,2,1]  R647      4.3319123983383179e-01
    z[1,2,1]  R648      2.6871562004089355e-01
    z[1,2,1]  R649      2.2296649217605591e-01
    z[1,2,1]  R650      3.8540813326835632e-01
    z[1,2,1]  R651      -1.6456307470798492e-01
    z[1,2,1]  R652      -6.5834693610668182e-02
    z[1,2,1]  R653      -3.2170256972312927e-01
    z[1,2,1]  R654      2.3825766146183014e-01
    z[1,2,1]  R655      2.3456817865371704e-01
    z[1,2,1]  R656      -1.9221548736095428e-01
    z[1,2,1]  R657      -4.4710376858711243e-01
    z[1,2,1]  R658      -1.9863858819007874e-01
    z[1,2,1]  R659      -9.1180332005023956e-02
    z[1,2,1]  R660      -4.1659852862358093e-01
    z[1,2,1]  R661      -2.4918284267187119e-02
    z[1,2,1]  R662      -1.6778963804244995e-01
    z[1,2,1]  R663      -2.7185013890266418e-01
    z[1,2,1]  R664      -1.0604806989431381e-01
    z[1,2,1]  R665      -2.2762747108936310e-01
    z[1,2,1]  R666      -3.9906290173530579e-01
    z[1,2,1]  R667      -0.128247931599617
    z[1,2,1]  R668      -1.8021407723426819e-01
    z[1,2,1]  R669      8.3533596992492676e-01
    z[1,2,1]  R670      2.8546115756034851e-01
    z[1,2,1]  R671      2.5662371516227722e-01
    z[1,2,1]  R672      -3.9189425110816956e-01
    z[1,2,1]  R673      -3.3204442262649536e-01
    z[1,2,1]  R674      -2.5690299272537231e-01
    z[1,2,1]  R675      -4.6997055411338806e-01
    z[1,2,1]  R676      -4.6174040436744690e-01
    z[1,2,1]  R677      -4.8508054018020630e-01
    z[1,2,1]  R678      -0.602096676826477
    z[1,2,1]  R679      1.2655800208449364e-02
    z[1,2,1]  R680      -1.6722084954380989e-02
    z[1,2,1]  R681      -1.5665067732334137e-01
    z[1,2,1]  R682      2.9285481572151184e-01
    z[1,2,1]  R683      7.0536142587661743e-01
    z[1,2,1]  R684      3.4541028738021851e-01
    z[1,2,1]  R685      0.516209065914154
    z[1,2,1]  R686      4.8548287153244019e-01
    z[1,2,1]  R687      3.3199149370193481e-01
    z[1,2,1]  R688      5.1212704181671143e-01
    z[1,2,1]  R689      5.9532564878463745e-01
    z[1,2,1]  R690      6.3990515470504761e-01
    z[1,2,1]  R691      4.8651802539825439e-01
    z[1,2,1]  R692      4.3544858694076538e-01
    z[1,2,1]  R693      -3.4603667259216309e-01
    z[1,2,1]  R694      0.720102846622467
    z[1,2,1]  R695      -4.8885107971727848e-03
    z[1,2,1]  R696      6.4501903951168060e-02
    z[1,2,1]  R697      -2.0838995277881622e-01
    z[1,2,1]  R698      -2.4802862107753754e-01
    z[1,2,1]  R699      -7.4762886762619019e-01
    z[1,2,1]  R700      4.9201175570487976e-02
    z[1,2,1]  R701      3.2671761512756348e-01
    z[1,2,1]  R702      -1.0198544710874557e-01
    z[1,2,1]  R703      -2.8616625815629959e-02
    z[1,2,1]  R704      3.1933152675628662e-01
    z[1,2,1]  R705      6.5530651807785034e-01
    z[1,2,1]  R706      -7.6302891969680786e-01
    z[1,2,1]  R707      -0.713287353515625
    z[1,2,1]  R708      3.4502479434013367e-01
    z[1,2,1]  R709      -1.5632529556751251e-01
    z[1,2,1]  R710      4.4123733043670654e-01
    z[1,2,1]  R711      -4.0507555007934570e-01
    z[1,2,1]  R712      -7.1970999240875244e-02
    z[1,2,1]  R713      -1.0386711359024048e-01
    z[1,2,1]  R714      -0.826941728591919
    z[1,2,1]  R715      5.5064874887466431e-01
    z[1,2,1]  R716      5.6682562828063965e-01
    z[1,2,1]  R717      -0.637488067150116
    z[1,2,1]  R718      3.1302982568740845e-01
    z[1,2,1]  R719      -4.3343013525009155e-01
    z[1,2,1]  R720      -5.8169806003570557e-01
    z[1,2,1]  R721      8.8284105062484741e-01
    z[1,2,1]  R722      7.3823785781860352e-01
    z[1,2,1]  R723      -7.5214987993240356e-01
    z[1,2,1]  R724      4.9054896831512451e-01
    z[1,2,1]  R725      4.3570250272750854e-01
    z[1,2,1]  R726      9.2652714252471924e-01
    z[1,2,1]  R727      8.0565035343170166e-01
    z[1,2,1]  R728      -5.6556481122970581e-01
    z[1,2,1]  R729      4.0573990345001221e-01
    z[1,2,1]  R730      6.1703330278396606e-01
    z[1,2,1]  R731      -1.1697446554899216e-01
    z[1,2,1]  R732      -1.9792547821998596e-01
    z[1,2,1]  R733      -1.3860097527503967e-01
    z[1,2,1]  R734      0.715706467628479
    z[1,2,1]  R735      6.6889148950576782e-01
    z[1,2,1]  R736      2.9724597930908203e-01
    z[1,2,1]  R737      -6.8008792400360107e-01
    z[1,2,1]  R738      8.8679903745651245e-01
    z[1,2,1]  R739      -7.1929872035980225e-01
    z[1,2,1]  R740      -3.0911669135093689e-01
    z[1,2,1]  R741      3.7147161364555359e-01
    z[1,2,1]  R742      0.74797123670578
    z[1,2,1]  R743      7.5768578052520752e-01
    z[1,2,1]  R744      -3.3206534385681152e-01
    z[1,2,1]  R745      -7.1302127838134766e-01
    z[1,2,1]  R746      6.7258435487747192e-01
    z[1,2,1]  R747      7.0505040884017944e-01
    z[1,2,1]  R748      -6.5480205230414867e-03
    z[1,2,1]  R749      -7.0366328954696655e-01
    z[1,2,1]  R750      -3.0529114603996277e-01
    z[1,2,1]  R751      1.3688798062503338e-02
    z[1,2,1]  R752      4.1255757212638855e-02
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R624      -1
    z[1,2,2]  R625      1
    z[1,2,2]  R634      0.648175835609436
    z[1,2,2]  R635      5.1874715089797974e-01
    z[1,2,2]  R636      7.2205990552902222e-01
    z[1,2,2]  R637      7.5782293081283569e-01
    z[1,2,2]  R638      -1.7612613737583160e-01
    z[1,2,2]  R639      -8.2908622920513153e-02
    z[1,2,2]  R640      7.3629534244537354e-01
    z[1,2,2]  R641      -1.1637032777070999e-01
    z[1,2,2]  R642      -1.9568027555942535e-01
    z[1,2,2]  R643      3.8976226001977921e-02
    z[1,2,2]  R644      -1.4966638386249542e-01
    z[1,2,2]  R645      -3.7048918008804321e-01
    z[1,2,2]  R646      -5.0181216001510620e-01
    z[1,2,2]  R647      -8.3484664559364319e-02
    z[1,2,2]  R648      -3.1613492965698242e-01
    z[1,2,2]  R649      -3.1253471970558167e-01
    z[1,2,2]  R650      -0.0691266879439354
    z[1,2,2]  R651      -3.6677503585815430e-01
    z[1,2,2]  R652      -3.1109884381294250e-01
    z[1,2,2]  R653      -1.1346743442118168e-02
    z[1,2,2]  R654      -2.7712648734450340e-03
    z[1,2,2]  R655      1.8844065070152283e-01
    z[1,2,2]  R656      -3.8060847669839859e-02
    z[1,2,2]  R657      0.398979514837265
    z[1,2,2]  R658      -2.3419651389122009e-01
    z[1,2,2]  R659      4.8064128495752811e-03
    z[1,2,2]  R660      -1.5498661994934082e-01
    z[1,2,2]  R661      -3.3935699611902237e-02
    z[1,2,2]  R662      -2.2759050130844116e-01
    z[1,2,2]  R663      -2.8109228610992432e-01
    z[1,2,2]  R664      -0.0703529641032219
    z[1,2,2]  R665      1.8172599375247955e-01
    z[1,2,2]  R666      1.3317517936229706e-01
    z[1,2,2]  R667      -4.1968944668769836e-01
    z[1,2,2]  R668      -4.6865735203027725e-02
    z[1,2,2]  R669      -3.4458798170089722e-01
    z[1,2,2]  R670      2.2251743078231812e-01
    z[1,2,2]  R671      6.3858158886432648e-02
    z[1,2,2]  R672      -2.3983417451381683e-01
    z[1,2,2]  R673      4.2972904443740845e-01
    z[1,2,2]  R674      2.9859790205955505e-01
    z[1,2,2]  R675      -1.4298494160175323e-01
    z[1,2,2]  R676      1.9827237725257874e-01
    z[1,2,2]  R677      2.4667717516422272e-01
    z[1,2,2]  R678      6.6764909029006958e-01
    z[1,2,2]  R679      0.749691903591156
    z[1,2,2]  R680      0.794209361076355
    z[1,2,2]  R681      7.4640804529190063e-01
    z[1,2,2]  R682      -5.7840985059738159e-01
    z[1,2,2]  R683      -4.9356621503829956e-01
    z[1,2,2]  R684      -5.4023534059524536e-01
    z[1,2,2]  R685      -6.4635413885116577e-01
    z[1,2,2]  R686      -9.2058137059211731e-02
    z[1,2,2]  R687      -7.9390835762023926e-01
    z[1,2,2]  R688      -4.5745104551315308e-01
    z[1,2,2]  R689      -3.7056869268417358e-01
    z[1,2,2]  R690      -4.0922570228576660e-01
    z[1,2,2]  R691      -4.8002764582633972e-01
    z[1,2,2]  R692      -6.8645268678665161e-01
    z[1,2,2]  R693      4.0704756975173950e-01
    z[1,2,2]  R694      -3.5753306746482849e-01
    z[1,2,2]  R695      -3.2452747225761414e-01
    z[1,2,2]  R696      -1.6314937174320221e-01
    z[1,2,2]  R697      1.8298590555787086e-02
    z[1,2,2]  R698      -2.8553183656185865e-03
    z[1,2,2]  R699      -4.5324909687042236e-01
    z[1,2,2]  R700      7.4352012015879154e-03
    z[1,2,2]  R701      1.7782163619995117e-01
    z[1,2,2]  R702      9.8059467971324921e-02
    z[1,2,2]  R703      3.7972810864448547e-01
    z[1,2,2]  R704      -6.2939512729644775e-01
    z[1,2,2]  R705      -0.642380952835083
    z[1,2,2]  R706      -6.9627188146114349e-02
    z[1,2,2]  R707      -1.6084440052509308e-01
    z[1,2,2]  R708      -5.4775995016098022e-01
    z[1,2,2]  R709      -4.4738808274269104e-01
    z[1,2,2]  R710      -5.5230081081390381e-01
    z[1,2,2]  R711      4.3478560447692871e-01
    z[1,2,2]  R712      -5.3456395864486694e-01
    z[1,2,2]  R713      4.4696268439292908e-01
    z[1,2,2]  R714      -2.2541087865829468e-01
    z[1,2,2]  R715      -4.3915849924087524e-01
    z[1,2,2]  R716      -6.5261960029602051e-01
    z[1,2,2]  R717      -1.2304015457630157e-01
    z[1,2,2]  R718      -6.2947779893875122e-01
    z[1,2,2]  R719      -3.2969605177640915e-02
    z[1,2,2]  R720      -3.2634842395782471e-01
    z[1,2,2]  R721      2.6758614182472229e-01
    z[1,2,2]  R722      4.3983215093612671e-01
    z[1,2,2]  R723      -9.5280326902866364e-02
    z[1,2,2]  R724      -0.634859025478363
    z[1,2,2]  R725      -6.4517909288406372e-01
    z[1,2,2]  R726      0.0360434390604496
    z[1,2,2]  R727      4.5218861103057861e-01
    z[1,2,2]  R728      -1.2078131549060345e-02
    z[1,2,2]  R729      1.2855865061283112e-01
    z[1,2,2]  R730      5.5934345722198486e-01
    z[1,2,2]  R731      -2.0315490663051605e-01
    z[1,2,2]  R732      -1.4706824719905853e-01
    z[1,2,2]  R733      1.7670039832592010e-01
    z[1,2,2]  R734      -4.8426979780197144e-01
    z[1,2,2]  R735      -2.8648141026496887e-01
    z[1,2,2]  R736      -6.8398404121398926e-01
    z[1,2,2]  R737      -5.9787672013044357e-02
    z[1,2,2]  R738      -1.4526379108428955e-01
    z[1,2,2]  R739      3.9475105702877045e-02
    z[1,2,2]  R740      2.5788527727127075e-01
    z[1,2,2]  R741      -4.6022129058837891e-01
    z[1,2,2]  R742      5.2115124464035034e-01
    z[1,2,2]  R743      -2.4724586308002472e-01
    z[1,2,2]  R744      3.8947898149490356e-01
    z[1,2,2]  R745      -1.5772011876106262e-01
    z[1,2,2]  R746      -0.574109673500061
    z[1,2,2]  R747      -4.5492088794708252e-01
    z[1,2,2]  R748      4.2822387814521790e-01
    z[1,2,2]  R749      -2.8702369332313538e-01
    z[1,2,2]  R750      -0.175094336271286
    z[1,2,2]  R751      6.2799490988254547e-02
    z[1,2,2]  R752      2.5760421156883240e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R626      -1
    z[1,2,3]  R627      1
    z[1,2,3]  R634      3.3444768190383911e-01
    z[1,2,3]  R635      5.9844911098480225e-02
    z[1,2,3]  R636      -6.5662041306495667e-02
    z[1,2,3]  R637      2.0085911452770233e-01
    z[1,2,3]  R638      -2.4074444547295570e-02
    z[1,2,3]  R639      2.6086029410362244e-01
    z[1,2,3]  R640      4.0525501966476440e-01
    z[1,2,3]  R641      1.4978574216365814e-01
    z[1,2,3]  R642      -1.8497286736965179e-01
    z[1,2,3]  R643      -1.7799408733844757e-01
    z[1,2,3]  R644      1.1157047748565674e-01
    z[1,2,3]  R645      -1.2984296679496765e-01
    z[1,2,3]  R646      0.353248655796051
    z[1,2,3]  R647      -2.8343278914690018e-02
    z[1,2,3]  R648      2.4139399826526642e-01
    z[1,2,3]  R649      1.1356934905052185e-01
    z[1,2,3]  R650      5.3709405474364758e-03
    z[1,2,3]  R651      -2.2197966277599335e-01
    z[1,2,3]  R652      0.646101176738739
    z[1,2,3]  R653      -1.9571591913700104e-01
    z[1,2,3]  R654      2.3418139666318893e-02
    z[1,2,3]  R655      -2.6679340004920959e-01
    z[1,2,3]  R656      0.672173798084259
    z[1,2,3]  R657      5.7566784322261810e-02
    z[1,2,3]  R658      3.8364630937576294e-01
    z[1,2,3]  R659      7.8136168420314789e-02
    z[1,2,3]  R660      6.0693745035678148e-04
    z[1,2,3]  R661      -6.2518179416656494e-01
    z[1,2,3]  R662      -6.1202096939086914e-01
    z[1,2,3]  R663      -6.0118412971496582e-01
    z[1,2,3]  R664      2.1372371912002563e-01
    z[1,2,3]  R665      -4.8983451724052429e-01
    z[1,2,3]  R666      1.9044023752212524e-01
    z[1,2,3]  R667      -2.2983053326606750e-01
    z[1,2,3]  R668      -0.721270740032196
    z[1,2,3]  R669      3.1372907757759094e-01
    z[1,2,3]  R670      -7.4560415744781494e-01
    z[1,2,3]  R671      -8.3811295032501221e-01
    z[1,2,3]  R672      -6.5260350704193115e-01
    z[1,2,3]  R673      7.0460617542266846e-01
    z[1,2,3]  R674      6.3385230302810669e-01
    z[1,2,3]  R675      5.1752287149429321e-01
    z[1,2,3]  R676      0.691716730594635
    z[1,2,3]  R677      -2.8274807333946228e-01
    z[1,2,3]  R678      2.2858205437660217e-01
    z[1,2,3]  R679      -9.3946717679500580e-02
    z[1,2,3]  R680      -9.8623782396316528e-02
    z[1,2,3]  R681      1.6305133700370789e-02
    z[1,2,3]  R682      2.3331997916102409e-02
    z[1,2,3]  R683      6.5564163029193878e-02
    z[1,2,3]  R684      5.2176183462142944e-01
    z[1,2,3]  R685      4.3301886320114136e-01
    z[1,2,3]  R686      -7.2795635461807251e-01
    z[1,2,3]  R687      1.0284223407506943e-01
    z[1,2,3]  R688      5.7892650365829468e-01
    z[1,2,3]  R689      1.1072061210870743e-01
    z[1,2,3]  R690      4.8190414905548096e-01
    z[1,2,3]  R691      5.4360177367925644e-02
    z[1,2,3]  R692      -6.8826384842395782e-02
    z[1,2,3]  R693      -8.1118786334991455e-01
    z[1,2,3]  R694      0.0860656350851059
    z[1,2,3]  R695      -0.528769314289093
    z[1,2,3]  R696      -4.9167567491531372e-01
    z[1,2,3]  R697      -6.5119296312332153e-01
    z[1,2,3]  R698      -7.0396721363067627e-01
    z[1,2,3]  R699      -3.1340688467025757e-01
    z[1,2,3]  R700      -6.6030627489089966e-01
    z[1,2,3]  R701      -4.8219156265258789e-01
    z[1,2,3]  R702      -5.1669472455978394e-01
    z[1,2,3]  R703      -0.783909022808075
    z[1,2,3]  R704      6.4680272340774536e-01
    z[1,2,3]  R705      1.1100284755229950e-02
    z[1,2,3]  R706      -1.9375425577163696e-01
    z[1,2,3]  R707      4.3256103992462158e-02
    z[1,2,3]  R708      6.3257914781570435e-01
    z[1,2,3]  R709      -4.0427660942077637e-01
    z[1,2,3]  R710      2.4229690432548523e-01
    z[1,2,3]  R711      3.9681177586317062e-02
    z[1,2,3]  R712      -7.1501910686492920e-01
    z[1,2,3]  R713      -7.5669950246810913e-01
    z[1,2,3]  R714      4.7563002444803715e-03
    z[1,2,3]  R715      8.6002998054027557e-02
    z[1,2,3]  R716      -1.5803065896034241e-01
    z[1,2,3]  R717      -5.2056068181991577e-01
    z[1,2,3]  R718      -8.8108986616134644e-02
    z[1,2,3]  R719      -1.6161488369107246e-02
    z[1,2,3]  R720      -3.6090412735939026e-01
    z[1,2,3]  R721      2.4224698543548584e-01
    z[1,2,3]  R722      2.5279900431632996e-01
    z[1,2,3]  R723      3.5884881019592285e-01
    z[1,2,3]  R724      1.4230453968048096e-01
    z[1,2,3]  R725      -1.0548471659421921e-01
    z[1,2,3]  R726      9.3076996505260468e-02
    z[1,2,3]  R727      1.9540201127529144e-01
    z[1,2,3]  R728      -3.2591944932937622e-01
    z[1,2,3]  R729      1.2794514000415802e-01
    z[1,2,3]  R730      -3.7251997739076614e-02
    z[1,2,3]  R731      -2.0874477922916412e-01
    z[1,2,3]  R732      -4.8169005662202835e-02
    z[1,2,3]  R733      -5.8753520250320435e-01
    z[1,2,3]  R734      8.5866108536720276e-02
    z[1,2,3]  R735      3.1356829404830933e-01
    z[1,2,3]  R736      3.1444475054740906e-01
    z[1,2,3]  R737      -4.0305379033088684e-01
    z[1,2,3]  R738      1.4074213802814484e-01
    z[1,2,3]  R739      -0.36433145403862
    z[1,2,3]  R740      -1.5327471494674683e-01
    z[1,2,3]  R741      6.5086834132671356e-02
    z[1,2,3]  R742      -1.3650661706924438e-01
    z[1,2,3]  R743      5.3470355272293091e-01
    z[1,2,3]  R744      -1.8591515719890594e-01
    z[1,2,3]  R745      -3.2681983709335327e-01
    z[1,2,3]  R746      -1.1359921097755432e-01
    z[1,2,3]  R747      1.7740766704082489e-01
    z[1,2,3]  R748      -2.6093408465385437e-01
    z[1,2,3]  R749      -2.4626623094081879e-01
    z[1,2,3]  R750      1.6839888691902161e-01
    z[1,2,3]  R751      1.1186099052429199e-01
    z[1,2,3]  R752      2.2514252364635468e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R628      -1
    z[1,2,4]  R629      1
    z[1,2,4]  R634      4.3188986182212830e-01
    z[1,2,4]  R635      5.1608490943908691e-01
    z[1,2,4]  R636      2.9394540190696716e-01
    z[1,2,4]  R637      3.0264088511466980e-01
    z[1,2,4]  R638      -2.4297304451465607e-01
    z[1,2,4]  R639      8.8915683329105377e-02
    z[1,2,4]  R640      -1.4465685188770294e-01
    z[1,2,4]  R641      2.0642970502376556e-01
    z[1,2,4]  R642      0.0165670458227396
    z[1,2,4]  R643      1.5591670572757721e-01
    z[1,2,4]  R644      -3.9095267653465271e-01
    z[1,2,4]  R645      -3.1944859027862549e-01
    z[1,2,4]  R646      -1.4721493422985077e-01
    z[1,2,4]  R647      -7.3048636317253113e-02
    z[1,2,4]  R648      -1.7148011922836304e-01
    z[1,2,4]  R649      2.5958020705729723e-03
    z[1,2,4]  R650      -2.9093879461288452e-01
    z[1,2,4]  R651      2.5505632162094116e-01
    z[1,2,4]  R652      1.1303497850894928e-01
    z[1,2,4]  R653      -1.7424583435058594e-01
    z[1,2,4]  R654      2.5406765937805176e-01
    z[1,2,4]  R655      1.4704677462577820e-01
    z[1,2,4]  R656      2.4635745584964752e-01
    z[1,2,4]  R657      -1.2593010067939758e-01
    z[1,2,4]  R658      1.5354084782302380e-02
    z[1,2,4]  R659      -4.7705590724945068e-01
    z[1,2,4]  R660      -1.6764181852340698e-01
    z[1,2,4]  R661      -0.574489414691925
    z[1,2,4]  R662      -3.4584525227546692e-01
    z[1,2,4]  R663      -4.5444545149803162e-01
    z[1,2,4]  R664      -1.6103319823741913e-01
    z[1,2,4]  R665      -2.2824855521321297e-02
    z[1,2,4]  R666      -4.4511345028877258e-01
    z[1,2,4]  R667      4.6262344717979431e-01
    z[1,2,4]  R668      -6.3724958896636963e-01
    z[1,2,4]  R669      1.2856112420558929e-01
    z[1,2,4]  R670      -5.1871067285537720e-01
    z[1,2,4]  R671      4.2378249764442444e-01
    z[1,2,4]  R672      -3.9718228578567505e-01
    z[1,2,4]  R673      6.0182854533195496e-02
    z[1,2,4]  R674      0.334433376789093
    z[1,2,4]  R675      3.5058698058128357e-01
    z[1,2,4]  R676      -1.5981499850749969e-01
    z[1,2,4]  R677      4.5273166894912720e-01
    z[1,2,4]  R678      7.1975603699684143e-02
    z[1,2,4]  R679      2.0932009816169739e-01
    z[1,2,4]  R680      4.3899127840995789e-01
    z[1,2,4]  R681      4.7448903322219849e-01
    z[1,2,4]  R682      1.0534477978944778e-01
    z[1,2,4]  R683      -2.8116098046302795e-01
    z[1,2,4]  R684      -3.7564691901206970e-01
    z[1,2,4]  R685      -2.3733133077621460e-01
    z[1,2,4]  R686      4.0176185965538025e-01
    z[1,2,4]  R687      -3.4186564385890961e-02
    z[1,2,4]  R688      -2.3181053996086121e-01
    z[1,2,4]  R689      -1.7737166583538055e-01
    z[1,2,4]  R690      1.1563534289598465e-01
    z[1,2,4]  R691      -0.551505982875824
    z[1,2,4]  R692      3.9585113525390625e-01
    z[1,2,4]  R693      1.0906083509325981e-02
    z[1,2,4]  R694      -3.6826786398887634e-01
    z[1,2,4]  R695      -6.5377938747406006e-01
    z[1,2,4]  R696      -7.1659630537033081e-01
    z[1,2,4]  R697      -5.6170392036437988e-01
    z[1,2,4]  R698      -6.2472081184387207e-01
    z[1,2,4]  R699      -0.252750426530838
    z[1,2,4]  R700      -6.1852902173995972e-01
    z[1,2,4]  R701      -7.0063984394073486e-01
    z[1,2,4]  R702      -6.9972926378250122e-01
    z[1,2,4]  R703      2.1617035567760468e-01
    z[1,2,4]  R704      -1.0089616477489471e-01
    z[1,2,4]  R705      3.2417541742324829e-01
    z[1,2,4]  R706      -2.3014199733734131e-01
    z[1,2,4]  R707      -3.6255308985710144e-01
    z[1,2,4]  R708      1.5050463378429413e-01
    z[1,2,4]  R709      2.3566101491451263e-01
    z[1,2,4]  R710      2.0459690690040588e-01
    z[1,2,4]  R711      -4.9369612336158752e-01
    z[1,2,4]  R712      1.3406861573457718e-02
    z[1,2,4]  R713      7.9505115747451782e-02
    z[1,2,4]  R714      -4.9428895115852356e-01
    z[1,2,4]  R715      -0.0761650800704956
    z[1,2,4]  R716      -2.6672041416168213e-01
    z[1,2,4]  R717      3.6464941501617432e-01
    z[1,2,4]  R718      -2.1595989167690277e-01
    z[1,2,4]  R719      -6.0959827899932861e-01
    z[1,2,4]  R720      3.5240563750267029e-01
    z[1,2,4]  R721      1.9147807359695435e-01
    z[1,2,4]  R722      -9.4949059188365936e-02
    z[1,2,4]  R723      -4.2940896749496460e-01
    z[1,2,4]  R724      2.9315361380577087e-01
    z[1,2,4]  R725      -0.0841350331902504
    z[1,2,4]  R726      1.3752470910549164e-01
    z[1,2,4]  R727      1.0821728408336639e-01
    z[1,2,4]  R728      -3.8458526134490967e-02
    z[1,2,4]  R729      7.3545169830322266e-01
    z[1,2,4]  R730      -2.6146358251571655e-01
    z[1,2,4]  R731      2.3412831127643585e-02
    z[1,2,4]  R732      4.8646613955497742e-02
    z[1,2,4]  R733      1.9688895344734192e-01
    z[1,2,4]  R734      -2.6365187764167786e-01
    z[1,2,4]  R735      1.6216847300529480e-01
    z[1,2,4]  R736      1.0183297097682953e-01
    z[1,2,4]  R737      3.6613830924034119e-01
    z[1,2,4]  R738      2.5276171043515205e-02
    z[1,2,4]  R739      3.9034810662269592e-01
    z[1,2,4]  R740      -5.8465617895126343e-01
    z[1,2,4]  R741      -5.4090458154678345e-01
    z[1,2,4]  R742      -2.1702301502227783e-01
    z[1,2,4]  R743      -2.1139633655548096e-01
    z[1,2,4]  R744      -5.1421147584915161e-01
    z[1,2,4]  R745      3.8064935803413391e-01
    z[1,2,4]  R746      2.8179755806922913e-01
    z[1,2,4]  R747      1.6003543511033058e-02
    z[1,2,4]  R748      -2.0782912150025368e-02
    z[1,2,4]  R749      2.2558422386646271e-01
    z[1,2,4]  R750      -1.8514131009578705e-01
    z[1,2,4]  R751      2.2753329575061798e-01
    z[1,2,4]  R752      5.2067141979932785e-02
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R630      -1
    z[1,2,5]  R631      1
    z[1,2,5]  R634      -2.1859265863895416e-01
    z[1,2,5]  R635      -4.8749871551990509e-02
    z[1,2,5]  R636      -2.3280568420886993e-01
    z[1,2,5]  R637      2.9659522697329521e-02
    z[1,2,5]  R638      -9.1489471495151520e-02
    z[1,2,5]  R639      -2.2897738218307495e-01
    z[1,2,5]  R640      -3.7888392806053162e-01
    z[1,2,5]  R641      -2.6533809304237366e-01
    z[1,2,5]  R642      -2.4617217481136322e-01
    z[1,2,5]  R643      -6.3933007419109344e-02
    z[1,2,5]  R644      2.6166521012783051e-02
    z[1,2,5]  R645      1.9349291920661926e-02
    z[1,2,5]  R646      -9.4485692679882050e-02
    z[1,2,5]  R647      -4.1054549813270569e-01
    z[1,2,5]  R648      -2.8887656331062317e-01
    z[1,2,5]  R649      -1.6198687255382538e-02
    z[1,2,5]  R650      -5.9515470266342163e-01
    z[1,2,5]  R651      0.511829674243927
    z[1,2,5]  R652      -1.7855094745755196e-02
    z[1,2,5]  R653      7.9831105470657349e-01
    z[1,2,5]  R654      -4.5378437638282776e-01
    z[1,2,5]  R655      -3.8740321993827820e-02
    z[1,2,5]  R656      5.1221899688243866e-02
    z[1,2,5]  R657      4.3502485752105713e-01
    z[1,2,5]  R658      2.8338757157325745e-01
    z[1,2,5]  R659      -5.8941155672073364e-01
    z[1,2,5]  R660      7.1740388870239258e-01
    z[1,2,5]  R661      4.7157999873161316e-01
    z[1,2,5]  R662      6.4506232738494873e-01
    z[1,2,5]  R663      0.470276415348053
    z[1,2,5]  R664      -2.1214704215526581e-01
    z[1,2,5]  R665      6.2924438714981079e-01
    z[1,2,5]  R666      3.6016049981117249e-01
    z[1,2,5]  R667      4.0202996134757996e-01
    z[1,2,5]  R668      1.5639634430408478e-01
    z[1,2,5]  R669      3.5411562770605087e-02
    z[1,2,5]  R670      1.5060894191265106e-01
    z[1,2,5]  R671      -1.3921947777271271e-01
    z[1,2,5]  R672      0.310105562210083
    z[1,2,5]  R673      -4.0111333131790161e-02
    z[1,2,5]  R674      -2.9458436369895935e-01
    z[1,2,5]  R675      -1.7900609970092773e-01
    z[1,2,5]  R676      -2.3825907707214355e-01
    z[1,2,5]  R677      1.9674451649188995e-01
    z[1,2,5]  R678      -1.5321678481996059e-02
    z[1,2,5]  R679      1.6504010185599327e-02
    z[1,2,5]  R680      -5.1086336374282837e-02
    z[1,2,5]  R681      -2.1501930430531502e-02
    z[1,2,5]  R682      -2.1900095045566559e-01
    z[1,2,5]  R683      -3.8801664113998413e-01
    z[1,2,5]  R684      2.5432538986206055e-01
    z[1,2,5]  R685      7.7942825853824615e-02
    z[1,2,5]  R686      4.9140501767396927e-02
    z[1,2,5]  R687      7.6111115515232086e-02
    z[1,2,5]  R688      2.5701296329498291e-01
    z[1,2,5]  R689      -8.5745364427566528e-02
    z[1,2,5]  R690      -1.9198076426982880e-01
    z[1,2,5]  R691      -9.8238639533519745e-02
    z[1,2,5]  R692      -1.8779900670051575e-01
    z[1,2,5]  R693      9.1455176472663879e-02
    z[1,2,5]  R694      5.8820914477109909e-02
    z[1,2,5]  R695      3.6578190326690674e-01
    z[1,2,5]  R696      3.0248314142227173e-01
    z[1,2,5]  R697      3.5836723446846008e-01
    z[1,2,5]  R698      2.0174258947372437e-01
    z[1,2,5]  R699      2.4466985464096069e-01
    z[1,2,5]  R700      1.2938182055950165e-01
    z[1,2,5]  R701      0.203104168176651
    z[1,2,5]  R702      1.5726454555988312e-01
    z[1,2,5]  R703      2.4988044798374176e-01
    z[1,2,5]  R704      -1.2344833463430405e-01
    z[1,2,5]  R705      1.9207081198692322e-01
    z[1,2,5]  R706      1.0046100616455078e-01
    z[1,2,5]  R707      -9.2327609658241272e-02
    z[1,2,5]  R708      -1.4799048006534576e-01
    z[1,2,5]  R709      4.6228629350662231e-01
    z[1,2,5]  R710      -4.0209221839904785e-01
    z[1,2,5]  R711      2.8853037953376770e-01
    z[1,2,5]  R712      3.7438431382179260e-01
    z[1,2,5]  R713      3.8681104779243469e-01
    z[1,2,5]  R714      -3.5120215266942978e-02
    z[1,2,5]  R715      1.3741073012351990e-01
    z[1,2,5]  R716      2.6251502335071564e-02
    z[1,2,5]  R717      -3.3485063910484314e-01
    z[1,2,5]  R718      5.3847837448120117e-01
    z[1,2,5]  R719      6.3186037540435791e-01
    z[1,2,5]  R720      3.7381444126367569e-02
    z[1,2,5]  R721      9.3511477112770081e-02
    z[1,2,5]  R722      0.371217280626297
    z[1,2,5]  R723      3.6413182970136404e-03
    z[1,2,5]  R724      -2.0216912031173706e-01
    z[1,2,5]  R725      1.0431414842605591e-01
    z[1,2,5]  R726      1.1590618640184402e-02
    z[1,2,5]  R727      -7.2658024728298187e-02
    z[1,2,5]  R728      -6.2452876567840576e-01
    z[1,2,5]  R729      3.4534335136413574e-01
    z[1,2,5]  R730      -1.0845420509576797e-01
    z[1,2,5]  R731      -6.4834314584732056e-01
    z[1,2,5]  R732      -4.9363338947296143e-01
    z[1,2,5]  R733      0.472953200340271
    z[1,2,5]  R734      7.3955051600933075e-02
    z[1,2,5]  R735      5.4328376054763794e-01
    z[1,2,5]  R736      3.9821276068687439e-01
    z[1,2,5]  R737      -1.3570861518383026e-01
    z[1,2,5]  R738      -2.8387421369552612e-01
    z[1,2,5]  R739      1.7517729103565216e-01
    z[1,2,5]  R740      5.7705128192901611e-01
    z[1,2,5]  R741      4.4803205132484436e-01
    z[1,2,5]  R742      -4.0736470371484756e-02
    z[1,2,5]  R743      -3.5944998264312744e-02
    z[1,2,5]  R744      6.0712260007858276e-01
    z[1,2,5]  R745      2.9833678156137466e-02
    z[1,2,5]  R746      -2.2303852438926697e-01
    z[1,2,5]  R747      -4.6621689200401306e-01
    z[1,2,5]  R748      7.1863436698913574e-01
    z[1,2,5]  R749      -3.0003547668457031e-01
    z[1,2,5]  R750      -4.7163897752761841e-01
    z[1,2,5]  R751      1.7729481682181358e-02
    z[1,2,5]  R752      -9.3078408390283585e-03
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R632      -1
    z[1,2,6]  R633      1
    z[1,2,6]  R634      -7.4649795889854431e-02
    z[1,2,6]  R635      -2.7094435691833496e-01
    z[1,2,6]  R636      -4.0650174021720886e-01
    z[1,2,6]  R637      2.6229172945022583e-01
    z[1,2,6]  R638      1.0801345109939575e-01
    z[1,2,6]  R639      2.3452107608318329e-01
    z[1,2,6]  R640      -1.5046596527099609e-01
    z[1,2,6]  R641      -3.5242381691932678e-01
    z[1,2,6]  R642      -4.3461519479751587e-01
    z[1,2,6]  R643      4.4097259640693665e-01
    z[1,2,6]  R644      2.9650470614433289e-01
    z[1,2,6]  R645      -7.0150340907275677e-03
    z[1,2,6]  R646      -1.3066437840461731e-01
    z[1,2,6]  R647      3.5713097453117371e-01
    z[1,2,6]  R648      7.8432798385620117e-02
    z[1,2,6]  R649      3.3497631549835205e-01
    z[1,2,6]  R650      -1.4120413362979889e-01
    z[1,2,6]  R651      0.427981436252594
    z[1,2,6]  R652      2.2896234691143036e-01
    z[1,2,6]  R653      -2.4735176935791969e-02
    z[1,2,6]  R654      7.2249300777912140e-02
    z[1,2,6]  R655      5.3443264961242676e-01
    z[1,2,6]  R656      4.0446621179580688e-01
    z[1,2,6]  R657      -9.1245517134666443e-02
    z[1,2,6]  R658      3.2425481826066971e-02
    z[1,2,6]  R659      -4.0871286392211914e-01
    z[1,2,6]  R660      -3.4263423085212708e-01
    z[1,2,6]  R661      2.3423831164836884e-01
    z[1,2,6]  R662      7.5188823044300079e-02
    z[1,2,6]  R663      1.8589356541633606e-01
    z[1,2,6]  R664      -6.1101114749908447e-01
    z[1,2,6]  R665      -7.7761389315128326e-02
    z[1,2,6]  R666      -4.8468500375747681e-01
    z[1,2,6]  R667      -2.3520238697528839e-01
    z[1,2,6]  R668      1.2026961892843246e-01
    z[1,2,6]  R669      -2.5747832655906677e-01
    z[1,2,6]  R670      9.4179525971412659e-02
    z[1,2,6]  R671      -1.6847959160804749e-01
    z[1,2,6]  R672      -2.7254357933998108e-01
    z[1,2,6]  R673      -1.7198163270950317e-01
    z[1,2,6]  R674      9.7616732120513916e-02
    z[1,2,6]  R675      8.6575500667095184e-02
    z[1,2,6]  R676      2.6357337832450867e-01
    z[1,2,6]  R677      9.2977419495582581e-02
    z[1,2,6]  R678      1.7765671014785767e-01
    z[1,2,6]  R679      0.538210928440094
    z[1,2,6]  R680      -9.9790245294570923e-02
    z[1,2,6]  R681      0.267120897769928
    z[1,2,6]  R682      -7.2021287679672241e-01
    z[1,2,6]  R683      1.5352459251880646e-01
    z[1,2,6]  R684      0.329188734292984
    z[1,2,6]  R685      2.3916792869567871e-01
    z[1,2,6]  R686      -1.8713575601577759e-01
    z[1,2,6]  R687      4.9038669466972351e-01
    z[1,2,6]  R688      -2.7009156346321106e-01
    z[1,2,6]  R689      5.6678575277328491e-01
    z[1,2,6]  R690      3.7452098727226257e-01
    z[1,2,6]  R691      1.6239304840564728e-01
    z[1,2,6]  R692      3.7542721629142761e-01
    z[1,2,6]  R693      -5.5112581700086594e-02
    z[1,2,6]  R694      -4.4175809621810913e-01
    z[1,2,6]  R695      2.0904199779033661e-01
    z[1,2,6]  R696      -3.4600594639778137e-01
    z[1,2,6]  R697      1.0638792812824249e-01
    z[1,2,6]  R698      5.7504154741764069e-02
    z[1,2,6]  R699      7.3766849935054779e-02
    z[1,2,6]  R700      3.7288421392440796e-01
    z[1,2,6]  R701      -3.0995625257492065e-01
    z[1,2,6]  R702      -2.8730648756027222e-01
    z[1,2,6]  R703      -3.0975034832954407e-01
    z[1,2,6]  R704      2.0896416902542114e-01
    z[1,2,6]  R705      1.2505804002285004e-01
    z[1,2,6]  R706      -5.4767656326293945e-01
    z[1,2,6]  R707      -5.5913275480270386e-01
    z[1,2,6]  R708      -2.9187005758285522e-01
    z[1,2,6]  R709      5.7579171657562256e-01
    z[1,2,6]  R710      -4.8718109726905823e-01
    z[1,2,6]  R711      -5.5757766962051392e-01
    z[1,2,6]  R712      1.5979956090450287e-01
    z[1,2,6]  R713      1.1773577332496643e-01
    z[1,2,6]  R714      -1.1788261681795120e-01
    z[1,2,6]  R715      3.7980252504348755e-01
    z[1,2,6]  R716      -1.0959913581609726e-01
    z[1,2,6]  R717      -1.5310059487819672e-01
    z[1,2,6]  R718      -7.4085518717765808e-02
    z[1,2,6]  R719      -1.8072827160358429e-01
    z[1,2,6]  R720      -4.6383801102638245e-01
    z[1,2,6]  R721      1.4695416390895844e-01
    z[1,2,6]  R722      2.5241279974579811e-02
    z[1,2,6]  R723      -2.5018927454948425e-01
    z[1,2,6]  R724      -3.3541226387023926e-01
    z[1,2,6]  R725      3.1361293792724609e-01
    z[1,2,6]  R726      2.8857663273811340e-01
    z[1,2,6]  R727      -2.0775970816612244e-01
    z[1,2,6]  R728      4.2690834403038025e-01
    z[1,2,6]  R729      -2.1375331282615662e-01
    z[1,2,6]  R730      1.6016711294651031e-01
    z[1,2,6]  R731      8.2306535914540291e-03
    z[1,2,6]  R732      1.4425319433212280e-01
    z[1,2,6]  R733      5.8335000276565552e-01
    z[1,2,6]  R734      -2.3129422962665558e-01
    z[1,2,6]  R735      1.6793212294578552e-01
    z[1,2,6]  R736      -3.8830515742301941e-01
    z[1,2,6]  R737      -3.7465396523475647e-01
    z[1,2,6]  R738      5.2417159080505371e-02
    z[1,2,6]  R739      -0.200520858168602
    z[1,2,6]  R740      2.5251591205596924e-01
    z[1,2,6]  R741      -0.011157201603055
    z[1,2,6]  R742      4.9335334450006485e-02
    z[1,2,6]  R743      -4.9009706825017929e-02
    z[1,2,6]  R744      1.0897734016180038e-01
    z[1,2,6]  R745      -2.9252591729164124e-01
    z[1,2,6]  R746      9.0420506894588470e-02
    z[1,2,6]  R747      -2.0941365510225296e-02
    z[1,2,6]  R748      -4.7655689716339111e-01
    z[1,2,6]  R749      -3.7927865982055664e-01
    z[1,2,6]  R750      0.0328315831720829
    z[1,2,6]  R751      -1.6944380104541779e-01
    z[1,2,6]  R752      -7.0934578776359558e-02
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R753      -1
    z[2,1,0]  R754      1
    z[2,1,0]  R767      -4.1689458489418030e-01
    z[2,1,0]  R768      -4.8468196392059326e-01
    z[2,1,0]  R769      -5.7306480407714844e-01
    z[2,1,0]  R770      -3.4239238500595093e-01
    z[2,1,0]  R771      -6.0957503318786621e-01
    z[2,1,0]  R772      -3.2015225291252136e-01
    z[2,1,0]  R773      -3.0857360363006592e-01
    z[2,1,0]  R774      -3.9235708117485046e-01
    z[2,1,0]  R775      -3.4801444411277771e-01
    z[2,1,0]  R776      3.6987990140914917e-02
    z[2,1,0]  R777      3.7160363048315048e-02
    z[2,1,0]  R778      4.9446426331996918e-02
    z[2,1,0]  R779      9.2987410724163055e-02
    z[2,1,0]  R780      1.6451187431812286e-01
    z[2,1,0]  R781      3.8392234593629837e-02
    z[2,1,0]  R782      2.3820878937840462e-02
    z[2,1,0]  R783      -3.6871144175529480e-01
    z[2,1,0]  R784      -1.8168369308114052e-02
    z[2,1,0]  R785      4.3558844923973083e-01
    z[2,1,0]  R786      -3.8961544632911682e-02
    z[2,1,0]  R787      2.1219049394130707e-01
    z[2,1,0]  R788      1.0946871340274811e-01
    z[2,1,0]  R789      -1.0069070756435394e-01
    z[2,1,0]  R790      5.2443742752075195e-02
    z[2,1,0]  R791      2.7736195921897888e-01
    z[2,1,0]  R792      -9.2849425971508026e-02
    z[2,1,0]  R793      -9.0580090880393982e-02
    z[2,1,0]  R794      -1.5218126773834229e-01
    z[2,1,0]  R795      -3.0100749805569649e-02
    z[2,1,0]  R796      -3.4075182676315308e-01
    z[2,1,0]  R797      -1.8804021179676056e-01
    z[2,1,0]  R798      -1.2020721286535263e-01
    z[2,1,0]  R799      1.3284712098538876e-02
    z[2,1,0]  R800      -1.1131456494331360e-01
    z[2,1,0]  R801      -1.0430975258350372e-01
    z[2,1,0]  R802      -2.2587503492832184e-01
    z[2,1,0]  R803      -1.0576321184635162e-01
    z[2,1,0]  R804      -2.6120189577341080e-02
    z[2,1,0]  R805      8.6152262985706329e-02
    z[2,1,0]  R806      1.7868988215923309e-01
    z[2,1,0]  R807      2.1687847375869751e-01
    z[2,1,0]  R808      -7.6703220605850220e-02
    z[2,1,0]  R809      -5.7236045598983765e-01
    z[2,1,0]  R810      3.7944954633712769e-01
    z[2,1,0]  R811      -1.9736465811729431e-01
    z[2,1,0]  R812      -3.9486771821975708e-01
    z[2,1,0]  R813      0.0852629616856575
    z[2,1,0]  R814      -2.9006785154342651e-01
    z[2,1,0]  R815      1.5264980494976044e-01
    z[2,1,0]  R816      2.2403240203857422e-01
    z[2,1,0]  R817      -2.2230571508407593e-01
    z[2,1,0]  R818      -3.1105026602745056e-01
    z[2,1,0]  R819      -5.1620435714721680e-01
    z[2,1,0]  R820      -1.7105893790721893e-01
    z[2,1,0]  R821      2.1935540437698364e-01
    z[2,1,0]  R822      1.0663330322131515e-03
    z[2,1,0]  R823      -3.1086322665214539e-01
    z[2,1,0]  R824      4.4636088609695435e-01
    z[2,1,0]  R825      6.9318538904190063e-01
    z[2,1,0]  R826      8.1855165958404541e-01
    z[2,1,0]  R827      4.0272515267133713e-02
    z[2,1,0]  R828      3.4263002872467041e-01
    z[2,1,0]  R829      -1.5010145306587219e-01
    z[2,1,0]  R830      -1.5877915918827057e-01
    z[2,1,0]  R831      -2.8038141131401062e-01
    z[2,1,0]  R832      2.9783645272254944e-01
    z[2,1,0]  R833      -3.5361889004707336e-01
    z[2,1,0]  R834      -2.7545174956321716e-01
    z[2,1,0]  R835      -3.9055564999580383e-01
    z[2,1,0]  R836      3.1482365727424622e-01
    z[2,1,0]  R837      1.7461758852005005e-01
    z[2,1,0]  R838      -2.4204730987548828e-01
    z[2,1,0]  R839      -3.5855054855346680e-01
    z[2,1,0]  R840      -2.6036825776100159e-01
    z[2,1,0]  R841      2.1546375751495361e-01
    z[2,1,0]  R842      6.7238390445709229e-02
    z[2,1,0]  R843      -2.7760851383209229e-01
    z[2,1,0]  R844      7.6810318231582642e-01
    z[2,1,0]  R845      9.5003110170364380e-01
    z[2,1,0]  R846      9.3456918001174927e-01
    z[2,1,0]  R847      2.8589609265327454e-01
    z[2,1,0]  R848      4.8036411404609680e-01
    z[2,1,0]  R849      2.5183260440826416e-01
    z[2,1,0]  R850      3.0372983217239380e-01
    z[2,1,0]  R851      -9.2242234945297241e-01
    z[2,1,0]  R852      -8.9510083198547363e-01
    z[2,1,0]  R853      1.8954648077487946e-01
    z[2,1,0]  R854      -8.5063797235488892e-01
    z[2,1,0]  R855      -8.1500744819641113e-01
    z[2,1,0]  R856      -8.3995550870895386e-01
    z[2,1,0]  R857      8.3946204185485840e-01
    z[2,1,0]  R858      8.5628277063369751e-01
    z[2,1,0]  R859      7.4340730905532837e-01
    z[2,1,0]  R860      7.0932799577713013e-01
    z[2,1,0]  R861      8.0658096075057983e-01
    z[2,1,0]  R862      8.5277885198593140e-01
    z[2,1,0]  R863      6.2278401851654053e-01
    z[2,1,0]  R864      5.2813696861267090e-01
    z[2,1,0]  R865      6.4491635560989380e-01
    z[2,1,0]  R866      4.3566048145294189e-01
    z[2,1,0]  R867      8.1669247150421143e-01
    z[2,1,0]  R868      7.2770011425018311e-01
    z[2,1,0]  R869      5.3186315298080444e-01
    z[2,1,0]  R870      -6.5128237009048462e-01
    z[2,1,0]  R871      8.2274824380874634e-01
    z[2,1,0]  R872      4.9348068237304688e-01
    z[2,1,0]  R873      3.7716588377952576e-01
    z[2,1,0]  R874      -9.0435231104493141e-03
    z[2,1,0]  R875      -6.4122684299945831e-02
    z[2,1,0]  R876      -1.5305294096469879e-01
    z[2,1,0]  R877      7.0274728536605835e-01
    z[2,1,0]  R878      5.2221375703811646e-01
    z[2,1,0]  R879      4.7327014803886414e-01
    z[2,1,0]  R880      5.6887823343276978e-01
    z[2,1,0]  R881      9.1267181560397148e-03
    z[2,1,0]  R882      0.031141497194767
    z[2,1,0]  R883      1.1161900311708450e-01
    z[2,1,0]  R884      -1.6556279733777046e-02
    z[2,1,0]  R885      -1.8656864762306213e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R755      -1
    z[2,1,1]  R756      1
    z[2,1,1]  R767      -3.3204442262649536e-01
    z[2,1,1]  R768      -2.5690299272537231e-01
    z[2,1,1]  R769      -4.6997055411338806e-01
    z[2,1,1]  R770      -4.6174040436744690e-01
    z[2,1,1]  R771      -4.8508054018020630e-01
    z[2,1,1]  R772      -0.602096676826477
    z[2,1,1]  R773      1.2655800208449364e-02
    z[2,1,1]  R774      -1.6722084954380989e-02
    z[2,1,1]  R775      -1.5665067732334137e-01
    z[2,1,1]  R776      2.9285481572151184e-01
    z[2,1,1]  R777      7.0536142587661743e-01
    z[2,1,1]  R778      3.4541028738021851e-01
    z[2,1,1]  R779      0.516209065914154
    z[2,1,1]  R780      4.8548287153244019e-01
    z[2,1,1]  R781      3.3199149370193481e-01
    z[2,1,1]  R782      5.1212704181671143e-01
    z[2,1,1]  R783      5.9532564878463745e-01
    z[2,1,1]  R784      6.3990515470504761e-01
    z[2,1,1]  R785      4.8651802539825439e-01
    z[2,1,1]  R786      4.3544858694076538e-01
    z[2,1,1]  R787      -3.4603667259216309e-01
    z[2,1,1]  R788      0.720102846622467
    z[2,1,1]  R789      -4.8885107971727848e-03
    z[2,1,1]  R790      6.4501903951168060e-02
    z[2,1,1]  R791      -2.0838995277881622e-01
    z[2,1,1]  R792      -2.4802862107753754e-01
    z[2,1,1]  R793      -7.4762886762619019e-01
    z[2,1,1]  R794      4.9201175570487976e-02
    z[2,1,1]  R795      3.2671761512756348e-01
    z[2,1,1]  R796      -1.0198544710874557e-01
    z[2,1,1]  R797      -2.8616625815629959e-02
    z[2,1,1]  R798      3.1933152675628662e-01
    z[2,1,1]  R799      6.5530651807785034e-01
    z[2,1,1]  R800      -7.6302891969680786e-01
    z[2,1,1]  R801      -0.713287353515625
    z[2,1,1]  R802      3.4502479434013367e-01
    z[2,1,1]  R803      -1.5632529556751251e-01
    z[2,1,1]  R804      4.4123733043670654e-01
    z[2,1,1]  R805      -4.0507555007934570e-01
    z[2,1,1]  R806      -7.1970999240875244e-02
    z[2,1,1]  R807      -1.0386711359024048e-01
    z[2,1,1]  R808      -0.826941728591919
    z[2,1,1]  R809      5.5064874887466431e-01
    z[2,1,1]  R810      5.6682562828063965e-01
    z[2,1,1]  R811      -0.637488067150116
    z[2,1,1]  R812      3.1302982568740845e-01
    z[2,1,1]  R813      -4.3343013525009155e-01
    z[2,1,1]  R814      -5.8169806003570557e-01
    z[2,1,1]  R815      8.8284105062484741e-01
    z[2,1,1]  R816      7.3823785781860352e-01
    z[2,1,1]  R817      -7.5214987993240356e-01
    z[2,1,1]  R818      4.9054896831512451e-01
    z[2,1,1]  R819      4.3570250272750854e-01
    z[2,1,1]  R820      9.2652714252471924e-01
    z[2,1,1]  R821      8.0565035343170166e-01
    z[2,1,1]  R822      -5.6556481122970581e-01
    z[2,1,1]  R823      4.0573990345001221e-01
    z[2,1,1]  R824      6.1703330278396606e-01
    z[2,1,1]  R825      -1.1697446554899216e-01
    z[2,1,1]  R826      -1.9792547821998596e-01
    z[2,1,1]  R827      -1.3860097527503967e-01
    z[2,1,1]  R828      0.715706467628479
    z[2,1,1]  R829      6.6889148950576782e-01
    z[2,1,1]  R830      2.9724597930908203e-01
    z[2,1,1]  R831      -6.8008792400360107e-01
    z[2,1,1]  R832      8.8679903745651245e-01
    z[2,1,1]  R833      -7.1929872035980225e-01
    z[2,1,1]  R834      -3.0911669135093689e-01
    z[2,1,1]  R835      3.7147161364555359e-01
    z[2,1,1]  R836      0.74797123670578
    z[2,1,1]  R837      7.5768578052520752e-01
    z[2,1,1]  R838      -3.3206534385681152e-01
    z[2,1,1]  R839      -7.1302127838134766e-01
    z[2,1,1]  R840      6.7258435487747192e-01
    z[2,1,1]  R841      7.0505040884017944e-01
    z[2,1,1]  R842      -6.5480205230414867e-03
    z[2,1,1]  R843      -7.0366328954696655e-01
    z[2,1,1]  R844      -3.0529114603996277e-01
    z[2,1,1]  R845      1.3688798062503338e-02
    z[2,1,1]  R846      4.1255757212638855e-02
    z[2,1,1]  R847      -3.8261207938194275e-01
    z[2,1,1]  R848      -3.9298757910728455e-01
    z[2,1,1]  R849      -3.2411766052246094e-01
    z[2,1,1]  R850      -3.6309796571731567e-01
    z[2,1,1]  R851      1.9612239301204681e-01
    z[2,1,1]  R852      9.2389337718486786e-02
    z[2,1,1]  R853      -2.6568973064422607e-01
    z[2,1,1]  R854      -5.6720346212387085e-02
    z[2,1,1]  R855      1.1615302413702011e-01
    z[2,1,1]  R856      1.9600871205329895e-01
    z[2,1,1]  R857      -1.3788338005542755e-01
    z[2,1,1]  R858      -1.0093265026807785e-01
    z[2,1,1]  R859      -1.5189656615257263e-01
    z[2,1,1]  R860      4.3319123983383179e-01
    z[2,1,1]  R861      2.6871562004089355e-01
    z[2,1,1]  R862      2.2296649217605591e-01
    z[2,1,1]  R863      3.8540813326835632e-01
    z[2,1,1]  R864      -1.6456307470798492e-01
    z[2,1,1]  R865      -6.5834693610668182e-02
    z[2,1,1]  R866      -3.2170256972312927e-01
    z[2,1,1]  R867      2.3825766146183014e-01
    z[2,1,1]  R868      2.3456817865371704e-01
    z[2,1,1]  R869      -1.9221548736095428e-01
    z[2,1,1]  R870      -4.4710376858711243e-01
    z[2,1,1]  R871      -1.9863858819007874e-01
    z[2,1,1]  R872      -9.1180332005023956e-02
    z[2,1,1]  R873      -4.1659852862358093e-01
    z[2,1,1]  R874      -2.4918284267187119e-02
    z[2,1,1]  R875      -1.6778963804244995e-01
    z[2,1,1]  R876      -2.7185013890266418e-01
    z[2,1,1]  R877      -1.0604806989431381e-01
    z[2,1,1]  R878      -2.2762747108936310e-01
    z[2,1,1]  R879      -3.9906290173530579e-01
    z[2,1,1]  R880      -0.128247931599617
    z[2,1,1]  R881      -1.8021407723426819e-01
    z[2,1,1]  R882      8.3533596992492676e-01
    z[2,1,1]  R883      2.8546115756034851e-01
    z[2,1,1]  R884      2.5662371516227722e-01
    z[2,1,1]  R885      -3.9189425110816956e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R757      -1
    z[2,1,2]  R758      1
    z[2,1,2]  R767      4.2972904443740845e-01
    z[2,1,2]  R768      2.9859790205955505e-01
    z[2,1,2]  R769      -1.4298494160175323e-01
    z[2,1,2]  R770      1.9827237725257874e-01
    z[2,1,2]  R771      2.4667717516422272e-01
    z[2,1,2]  R772      6.6764909029006958e-01
    z[2,1,2]  R773      0.749691903591156
    z[2,1,2]  R774      0.794209361076355
    z[2,1,2]  R775      7.4640804529190063e-01
    z[2,1,2]  R776      -5.7840985059738159e-01
    z[2,1,2]  R777      -4.9356621503829956e-01
    z[2,1,2]  R778      -5.4023534059524536e-01
    z[2,1,2]  R779      -6.4635413885116577e-01
    z[2,1,2]  R780      -9.2058137059211731e-02
    z[2,1,2]  R781      -7.9390835762023926e-01
    z[2,1,2]  R782      -4.5745104551315308e-01
    z[2,1,2]  R783      -3.7056869268417358e-01
    z[2,1,2]  R784      -4.0922570228576660e-01
    z[2,1,2]  R785      -4.8002764582633972e-01
    z[2,1,2]  R786      -6.8645268678665161e-01
    z[2,1,2]  R787      4.0704756975173950e-01
    z[2,1,2]  R788      -3.5753306746482849e-01
    z[2,1,2]  R789      -3.2452747225761414e-01
    z[2,1,2]  R790      -1.6314937174320221e-01
    z[2,1,2]  R791      1.8298590555787086e-02
    z[2,1,2]  R792      -2.8553183656185865e-03
    z[2,1,2]  R793      -4.5324909687042236e-01
    z[2,1,2]  R794      7.4352012015879154e-03
    z[2,1,2]  R795      1.7782163619995117e-01
    z[2,1,2]  R796      9.8059467971324921e-02
    z[2,1,2]  R797      3.7972810864448547e-01
    z[2,1,2]  R798      -6.2939512729644775e-01
    z[2,1,2]  R799      -0.642380952835083
    z[2,1,2]  R800      -6.9627188146114349e-02
    z[2,1,2]  R801      -1.6084440052509308e-01
    z[2,1,2]  R802      -5.4775995016098022e-01
    z[2,1,2]  R803      -4.4738808274269104e-01
    z[2,1,2]  R804      -5.5230081081390381e-01
    z[2,1,2]  R805      4.3478560447692871e-01
    z[2,1,2]  R806      -5.3456395864486694e-01
    z[2,1,2]  R807      4.4696268439292908e-01
    z[2,1,2]  R808      -2.2541087865829468e-01
    z[2,1,2]  R809      -4.3915849924087524e-01
    z[2,1,2]  R810      -6.5261960029602051e-01
    z[2,1,2]  R811      -1.2304015457630157e-01
    z[2,1,2]  R812      -6.2947779893875122e-01
    z[2,1,2]  R813      -3.2969605177640915e-02
    z[2,1,2]  R814      -3.2634842395782471e-01
    z[2,1,2]  R815      2.6758614182472229e-01
    z[2,1,2]  R816      4.3983215093612671e-01
    z[2,1,2]  R817      -9.5280326902866364e-02
    z[2,1,2]  R818      -0.634859025478363
    z[2,1,2]  R819      -6.4517909288406372e-01
    z[2,1,2]  R820      0.0360434390604496
    z[2,1,2]  R821      4.5218861103057861e-01
    z[2,1,2]  R822      -1.2078131549060345e-02
    z[2,1,2]  R823      1.2855865061283112e-01
    z[2,1,2]  R824      5.5934345722198486e-01
    z[2,1,2]  R825      -2.0315490663051605e-01
    z[2,1,2]  R826      -1.4706824719905853e-01
    z[2,1,2]  R827      1.7670039832592010e-01
    z[2,1,2]  R828      -4.8426979780197144e-01
    z[2,1,2]  R829      -2.8648141026496887e-01
    z[2,1,2]  R830      -6.8398404121398926e-01
    z[2,1,2]  R831      -5.9787672013044357e-02
    z[2,1,2]  R832      -1.4526379108428955e-01
    z[2,1,2]  R833      3.9475105702877045e-02
    z[2,1,2]  R834      2.5788527727127075e-01
    z[2,1,2]  R835      -4.6022129058837891e-01
    z[2,1,2]  R836      5.2115124464035034e-01
    z[2,1,2]  R837      -2.4724586308002472e-01
    z[2,1,2]  R838      3.8947898149490356e-01
    z[2,1,2]  R839      -1.5772011876106262e-01
    z[2,1,2]  R840      -0.574109673500061
    z[2,1,2]  R841      -4.5492088794708252e-01
    z[2,1,2]  R842      4.2822387814521790e-01
    z[2,1,2]  R843      -2.8702369332313538e-01
    z[2,1,2]  R844      -0.175094336271286
    z[2,1,2]  R845      6.2799490988254547e-02
    z[2,1,2]  R846      2.5760421156883240e-01
    z[2,1,2]  R847      0.648175835609436
    z[2,1,2]  R848      5.1874715089797974e-01
    z[2,1,2]  R849      7.2205990552902222e-01
    z[2,1,2]  R850      7.5782293081283569e-01
    z[2,1,2]  R851      -1.7612613737583160e-01
    z[2,1,2]  R852      -8.2908622920513153e-02
    z[2,1,2]  R853      7.3629534244537354e-01
    z[2,1,2]  R854      -1.1637032777070999e-01
    z[2,1,2]  R855      -1.9568027555942535e-01
    z[2,1,2]  R856      3.8976226001977921e-02
    z[2,1,2]  R857      -1.4966638386249542e-01
    z[2,1,2]  R858      -3.7048918008804321e-01
    z[2,1,2]  R859      -5.0181216001510620e-01
    z[2,1,2]  R860      -8.3484664559364319e-02
    z[2,1,2]  R861      -3.1613492965698242e-01
    z[2,1,2]  R862      -3.1253471970558167e-01
    z[2,1,2]  R863      -0.0691266879439354
    z[2,1,2]  R864      -3.6677503585815430e-01
    z[2,1,2]  R865      -3.1109884381294250e-01
    z[2,1,2]  R866      -1.1346743442118168e-02
    z[2,1,2]  R867      -2.7712648734450340e-03
    z[2,1,2]  R868      1.8844065070152283e-01
    z[2,1,2]  R869      -3.8060847669839859e-02
    z[2,1,2]  R870      0.398979514837265
    z[2,1,2]  R871      -2.3419651389122009e-01
    z[2,1,2]  R872      4.8064128495752811e-03
    z[2,1,2]  R873      -1.5498661994934082e-01
    z[2,1,2]  R874      -3.3935699611902237e-02
    z[2,1,2]  R875      -2.2759050130844116e-01
    z[2,1,2]  R876      -2.8109228610992432e-01
    z[2,1,2]  R877      -0.0703529641032219
    z[2,1,2]  R878      1.8172599375247955e-01
    z[2,1,2]  R879      1.3317517936229706e-01
    z[2,1,2]  R880      -4.1968944668769836e-01
    z[2,1,2]  R881      -4.6865735203027725e-02
    z[2,1,2]  R882      -3.4458798170089722e-01
    z[2,1,2]  R883      2.2251743078231812e-01
    z[2,1,2]  R884      6.3858158886432648e-02
    z[2,1,2]  R885      -2.3983417451381683e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R759      -1
    z[2,1,3]  R760      1
    z[2,1,3]  R767      7.0460617542266846e-01
    z[2,1,3]  R768      6.3385230302810669e-01
    z[2,1,3]  R769      5.1752287149429321e-01
    z[2,1,3]  R770      0.691716730594635
    z[2,1,3]  R771      -2.8274807333946228e-01
    z[2,1,3]  R772      2.2858205437660217e-01
    z[2,1,3]  R773      -9.3946717679500580e-02
    z[2,1,3]  R774      -9.8623782396316528e-02
    z[2,1,3]  R775      1.6305133700370789e-02
    z[2,1,3]  R776      2.3331997916102409e-02
    z[2,1,3]  R777      6.5564163029193878e-02
    z[2,1,3]  R778      5.2176183462142944e-01
    z[2,1,3]  R779      4.3301886320114136e-01
    z[2,1,3]  R780      -7.2795635461807251e-01
    z[2,1,3]  R781      1.0284223407506943e-01
    z[2,1,3]  R782      5.7892650365829468e-01
    z[2,1,3]  R783      1.1072061210870743e-01
    z[2,1,3]  R784      4.8190414905548096e-01
    z[2,1,3]  R785      5.4360177367925644e-02
    z[2,1,3]  R786      -6.8826384842395782e-02
    z[2,1,3]  R787      -8.1118786334991455e-01
    z[2,1,3]  R788      0.0860656350851059
    z[2,1,3]  R789      -0.528769314289093
    z[2,1,3]  R790      -4.9167567491531372e-01
    z[2,1,3]  R791      -6.5119296312332153e-01
    z[2,1,3]  R792      -7.0396721363067627e-01
    z[2,1,3]  R793      -3.1340688467025757e-01
    z[2,1,3]  R794      -6.6030627489089966e-01
    z[2,1,3]  R795      -4.8219156265258789e-01
    z[2,1,3]  R796      -5.1669472455978394e-01
    z[2,1,3]  R797      -0.783909022808075
    z[2,1,3]  R798      6.4680272340774536e-01
    z[2,1,3]  R799      1.1100284755229950e-02
    z[2,1,3]  R800      -1.9375425577163696e-01
    z[2,1,3]  R801      4.3256103992462158e-02
    z[2,1,3]  R802      6.3257914781570435e-01
    z[2,1,3]  R803      -4.0427660942077637e-01
    z[2,1,3]  R804      2.4229690432548523e-01
    z[2,1,3]  R805      3.9681177586317062e-02
    z[2,1,3]  R806      -7.1501910686492920e-01
    z[2,1,3]  R807      -7.5669950246810913e-01
    z[2,1,3]  R808      4.7563002444803715e-03
    z[2,1,3]  R809      8.6002998054027557e-02
    z[2,1,3]  R810      -1.5803065896034241e-01
    z[2,1,3]  R811      -5.2056068181991577e-01
    z[2,1,3]  R812      -8.8108986616134644e-02
    z[2,1,3]  R813      -1.6161488369107246e-02
    z[2,1,3]  R814      -3.6090412735939026e-01
    z[2,1,3]  R815      2.4224698543548584e-01
    z[2,1,3]  R816      2.5279900431632996e-01
    z[2,1,3]  R817      3.5884881019592285e-01
    z[2,1,3]  R818      1.4230453968048096e-01
    z[2,1,3]  R819      -1.0548471659421921e-01
    z[2,1,3]  R820      9.3076996505260468e-02
    z[2,1,3]  R821      1.9540201127529144e-01
    z[2,1,3]  R822      -3.2591944932937622e-01
    z[2,1,3]  R823      1.2794514000415802e-01
    z[2,1,3]  R824      -3.7251997739076614e-02
    z[2,1,3]  R825      -2.0874477922916412e-01
    z[2,1,3]  R826      -4.8169005662202835e-02
    z[2,1,3]  R827      -5.8753520250320435e-01
    z[2,1,3]  R828      8.5866108536720276e-02
    z[2,1,3]  R829      3.1356829404830933e-01
    z[2,1,3]  R830      3.1444475054740906e-01
    z[2,1,3]  R831      -4.0305379033088684e-01
    z[2,1,3]  R832      1.4074213802814484e-01
    z[2,1,3]  R833      -0.36433145403862
    z[2,1,3]  R834      -1.5327471494674683e-01
    z[2,1,3]  R835      6.5086834132671356e-02
    z[2,1,3]  R836      -1.3650661706924438e-01
    z[2,1,3]  R837      5.3470355272293091e-01
    z[2,1,3]  R838      -1.8591515719890594e-01
    z[2,1,3]  R839      -3.2681983709335327e-01
    z[2,1,3]  R840      -1.1359921097755432e-01
    z[2,1,3]  R841      1.7740766704082489e-01
    z[2,1,3]  R842      -2.6093408465385437e-01
    z[2,1,3]  R843      -2.4626623094081879e-01
    z[2,1,3]  R844      1.6839888691902161e-01
    z[2,1,3]  R845      1.1186099052429199e-01
    z[2,1,3]  R846      2.2514252364635468e-01
    z[2,1,3]  R847      3.3444768190383911e-01
    z[2,1,3]  R848      5.9844911098480225e-02
    z[2,1,3]  R849      -6.5662041306495667e-02
    z[2,1,3]  R850      2.0085911452770233e-01
    z[2,1,3]  R851      -2.4074444547295570e-02
    z[2,1,3]  R852      2.6086029410362244e-01
    z[2,1,3]  R853      4.0525501966476440e-01
    z[2,1,3]  R854      1.4978574216365814e-01
    z[2,1,3]  R855      -1.8497286736965179e-01
    z[2,1,3]  R856      -1.7799408733844757e-01
    z[2,1,3]  R857      1.1157047748565674e-01
    z[2,1,3]  R858      -1.2984296679496765e-01
    z[2,1,3]  R859      0.353248655796051
    z[2,1,3]  R860      -2.8343278914690018e-02
    z[2,1,3]  R861      2.4139399826526642e-01
    z[2,1,3]  R862      1.1356934905052185e-01
    z[2,1,3]  R863      5.3709405474364758e-03
    z[2,1,3]  R864      -2.2197966277599335e-01
    z[2,1,3]  R865      0.646101176738739
    z[2,1,3]  R866      -1.9571591913700104e-01
    z[2,1,3]  R867      2.3418139666318893e-02
    z[2,1,3]  R868      -2.6679340004920959e-01
    z[2,1,3]  R869      0.672173798084259
    z[2,1,3]  R870      5.7566784322261810e-02
    z[2,1,3]  R871      3.8364630937576294e-01
    z[2,1,3]  R872      7.8136168420314789e-02
    z[2,1,3]  R873      6.0693745035678148e-04
    z[2,1,3]  R874      -6.2518179416656494e-01
    z[2,1,3]  R875      -6.1202096939086914e-01
    z[2,1,3]  R876      -6.0118412971496582e-01
    z[2,1,3]  R877      2.1372371912002563e-01
    z[2,1,3]  R878      -4.8983451724052429e-01
    z[2,1,3]  R879      1.9044023752212524e-01
    z[2,1,3]  R880      -2.2983053326606750e-01
    z[2,1,3]  R881      -0.721270740032196
    z[2,1,3]  R882      3.1372907757759094e-01
    z[2,1,3]  R883      -7.4560415744781494e-01
    z[2,1,3]  R884      -8.3811295032501221e-01
    z[2,1,3]  R885      -6.5260350704193115e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R761      -1
    z[2,1,4]  R762      1
    z[2,1,4]  R767      6.0182854533195496e-02
    z[2,1,4]  R768      0.334433376789093
    z[2,1,4]  R769      3.5058698058128357e-01
    z[2,1,4]  R770      -1.5981499850749969e-01
    z[2,1,4]  R771      4.5273166894912720e-01
    z[2,1,4]  R772      7.1975603699684143e-02
    z[2,1,4]  R773      2.0932009816169739e-01
    z[2,1,4]  R774      4.3899127840995789e-01
    z[2,1,4]  R775      4.7448903322219849e-01
    z[2,1,4]  R776      1.0534477978944778e-01
    z[2,1,4]  R777      -2.8116098046302795e-01
    z[2,1,4]  R778      -3.7564691901206970e-01
    z[2,1,4]  R779      -2.3733133077621460e-01
    z[2,1,4]  R780      4.0176185965538025e-01
    z[2,1,4]  R781      -3.4186564385890961e-02
    z[2,1,4]  R782      -2.3181053996086121e-01
    z[2,1,4]  R783      -1.7737166583538055e-01
    z[2,1,4]  R784      1.1563534289598465e-01
    z[2,1,4]  R785      -0.551505982875824
    z[2,1,4]  R786      3.9585113525390625e-01
    z[2,1,4]  R787      1.0906083509325981e-02
    z[2,1,4]  R788      -3.6826786398887634e-01
    z[2,1,4]  R789      -6.5377938747406006e-01
    z[2,1,4]  R790      -7.1659630537033081e-01
    z[2,1,4]  R791      -5.6170392036437988e-01
    z[2,1,4]  R792      -6.2472081184387207e-01
    z[2,1,4]  R793      -0.252750426530838
    z[2,1,4]  R794      -6.1852902173995972e-01
    z[2,1,4]  R795      -7.0063984394073486e-01
    z[2,1,4]  R796      -6.9972926378250122e-01
    z[2,1,4]  R797      2.1617035567760468e-01
    z[2,1,4]  R798      -1.0089616477489471e-01
    z[2,1,4]  R799      3.2417541742324829e-01
    z[2,1,4]  R800      -2.3014199733734131e-01
    z[2,1,4]  R801      -3.6255308985710144e-01
    z[2,1,4]  R802      1.5050463378429413e-01
    z[2,1,4]  R803      2.3566101491451263e-01
    z[2,1,4]  R804      2.0459690690040588e-01
    z[2,1,4]  R805      -4.9369612336158752e-01
    z[2,1,4]  R806      1.3406861573457718e-02
    z[2,1,4]  R807      7.9505115747451782e-02
    z[2,1,4]  R808      -4.9428895115852356e-01
    z[2,1,4]  R809      -0.0761650800704956
    z[2,1,4]  R810      -2.6672041416168213e-01
    z[2,1,4]  R811      3.6464941501617432e-01
    z[2,1,4]  R812      -2.1595989167690277e-01
    z[2,1,4]  R813      -6.0959827899932861e-01
    z[2,1,4]  R814      3.5240563750267029e-01
    z[2,1,4]  R815      1.9147807359695435e-01
    z[2,1,4]  R816      -9.4949059188365936e-02
    z[2,1,4]  R817      -4.2940896749496460e-01
    z[2,1,4]  R818      2.9315361380577087e-01
    z[2,1,4]  R819      -0.0841350331902504
    z[2,1,4]  R820      1.3752470910549164e-01
    z[2,1,4]  R821      1.0821728408336639e-01
    z[2,1,4]  R822      -3.8458526134490967e-02
    z[2,1,4]  R823      7.3545169830322266e-01
    z[2,1,4]  R824      -2.6146358251571655e-01
    z[2,1,4]  R825      2.3412831127643585e-02
    z[2,1,4]  R826      4.8646613955497742e-02
    z[2,1,4]  R827      1.9688895344734192e-01
    z[2,1,4]  R828      -2.6365187764167786e-01
    z[2,1,4]  R829      1.6216847300529480e-01
    z[2,1,4]  R830      1.0183297097682953e-01
    z[2,1,4]  R831      3.6613830924034119e-01
    z[2,1,4]  R832      2.5276171043515205e-02
    z[2,1,4]  R833      3.9034810662269592e-01
    z[2,1,4]  R834      -5.8465617895126343e-01
    z[2,1,4]  R835      -5.4090458154678345e-01
    z[2,1,4]  R836      -2.1702301502227783e-01
    z[2,1,4]  R837      -2.1139633655548096e-01
    z[2,1,4]  R838      -5.1421147584915161e-01
    z[2,1,4]  R839      3.8064935803413391e-01
    z[2,1,4]  R840      2.8179755806922913e-01
    z[2,1,4]  R841      1.6003543511033058e-02
    z[2,1,4]  R842      -2.0782912150025368e-02
    z[2,1,4]  R843      2.2558422386646271e-01
    z[2,1,4]  R844      -1.8514131009578705e-01
    z[2,1,4]  R845      2.2753329575061798e-01
    z[2,1,4]  R846      5.2067141979932785e-02
    z[2,1,4]  R847      4.3188986182212830e-01
    z[2,1,4]  R848      5.1608490943908691e-01
    z[2,1,4]  R849      2.9394540190696716e-01
    z[2,1,4]  R850      3.0264088511466980e-01
    z[2,1,4]  R851      -2.4297304451465607e-01
    z[2,1,4]  R852      8.8915683329105377e-02
    z[2,1,4]  R853      -1.4465685188770294e-01
    z[2,1,4]  R854      2.0642970502376556e-01
    z[2,1,4]  R855      0.0165670458227396
    z[2,1,4]  R856      1.5591670572757721e-01
    z[2,1,4]  R857      -3.9095267653465271e-01
    z[2,1,4]  R858      -3.1944859027862549e-01
    z[2,1,4]  R859      -1.4721493422985077e-01
    z[2,1,4]  R860      -7.3048636317253113e-02
    z[2,1,4]  R861      -1.7148011922836304e-01
    z[2,1,4]  R862      2.5958020705729723e-03
    z[2,1,4]  R863      -2.9093879461288452e-01
    z[2,1,4]  R864      2.5505632162094116e-01
    z[2,1,4]  R865      1.1303497850894928e-01
    z[2,1,4]  R866      -1.7424583435058594e-01
    z[2,1,4]  R867      2.5406765937805176e-01
    z[2,1,4]  R868      1.4704677462577820e-01
    z[2,1,4]  R869      2.4635745584964752e-01
    z[2,1,4]  R870      -1.2593010067939758e-01
    z[2,1,4]  R871      1.5354084782302380e-02
    z[2,1,4]  R872      -4.7705590724945068e-01
    z[2,1,4]  R873      -1.6764181852340698e-01
    z[2,1,4]  R874      -0.574489414691925
    z[2,1,4]  R875      -3.4584525227546692e-01
    z[2,1,4]  R876      -4.5444545149803162e-01
    z[2,1,4]  R877      -1.6103319823741913e-01
    z[2,1,4]  R878      -2.2824855521321297e-02
    z[2,1,4]  R879      -4.4511345028877258e-01
    z[2,1,4]  R880      4.6262344717979431e-01
    z[2,1,4]  R881      -6.3724958896636963e-01
    z[2,1,4]  R882      1.2856112420558929e-01
    z[2,1,4]  R883      -5.1871067285537720e-01
    z[2,1,4]  R884      4.2378249764442444e-01
    z[2,1,4]  R885      -3.9718228578567505e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R763      -1
    z[2,1,5]  R764      1
    z[2,1,5]  R767      -4.0111333131790161e-02
    z[2,1,5]  R768      -2.9458436369895935e-01
    z[2,1,5]  R769      -1.7900609970092773e-01
    z[2,1,5]  R770      -2.3825907707214355e-01
    z[2,1,5]  R771      1.9674451649188995e-01
    z[2,1,5]  R772      -1.5321678481996059e-02
    z[2,1,5]  R773      1.6504010185599327e-02
    z[2,1,5]  R774      -5.1086336374282837e-02
    z[2,1,5]  R775      -2.1501930430531502e-02
    z[2,1,5]  R776      -2.1900095045566559e-01
    z[2,1,5]  R777      -3.8801664113998413e-01
    z[2,1,5]  R778      2.5432538986206055e-01
    z[2,1,5]  R779      7.7942825853824615e-02
    z[2,1,5]  R780      4.9140501767396927e-02
    z[2,1,5]  R781      7.6111115515232086e-02
    z[2,1,5]  R782      2.5701296329498291e-01
    z[2,1,5]  R783      -8.5745364427566528e-02
    z[2,1,5]  R784      -1.9198076426982880e-01
    z[2,1,5]  R785      -9.8238639533519745e-02
    z[2,1,5]  R786      -1.8779900670051575e-01
    z[2,1,5]  R787      9.1455176472663879e-02
    z[2,1,5]  R788      5.8820914477109909e-02
    z[2,1,5]  R789      3.6578190326690674e-01
    z[2,1,5]  R790      3.0248314142227173e-01
    z[2,1,5]  R791      3.5836723446846008e-01
    z[2,1,5]  R792      2.0174258947372437e-01
    z[2,1,5]  R793      2.4466985464096069e-01
    z[2,1,5]  R794      1.2938182055950165e-01
    z[2,1,5]  R795      0.203104168176651
    z[2,1,5]  R796      1.5726454555988312e-01
    z[2,1,5]  R797      2.4988044798374176e-01
    z[2,1,5]  R798      -1.2344833463430405e-01
    z[2,1,5]  R799      1.9207081198692322e-01
    z[2,1,5]  R800      1.0046100616455078e-01
    z[2,1,5]  R801      -9.2327609658241272e-02
    z[2,1,5]  R802      -1.4799048006534576e-01
    z[2,1,5]  R803      4.6228629350662231e-01
    z[2,1,5]  R804      -4.0209221839904785e-01
    z[2,1,5]  R805      2.8853037953376770e-01
    z[2,1,5]  R806      3.7438431382179260e-01
    z[2,1,5]  R807      3.8681104779243469e-01
    z[2,1,5]  R808      -3.5120215266942978e-02
    z[2,1,5]  R809      1.3741073012351990e-01
    z[2,1,5]  R810      2.6251502335071564e-02
    z[2,1,5]  R811      -3.3485063910484314e-01
    z[2,1,5]  R812      5.3847837448120117e-01
    z[2,1,5]  R813      6.3186037540435791e-01
    z[2,1,5]  R814      3.7381444126367569e-02
    z[2,1,5]  R815      9.3511477112770081e-02
    z[2,1,5]  R816      0.371217280626297
    z[2,1,5]  R817      3.6413182970136404e-03
    z[2,1,5]  R818      -2.0216912031173706e-01
    z[2,1,5]  R819      1.0431414842605591e-01
    z[2,1,5]  R820      1.1590618640184402e-02
    z[2,1,5]  R821      -7.2658024728298187e-02
    z[2,1,5]  R822      -6.2452876567840576e-01
    z[2,1,5]  R823      3.4534335136413574e-01
    z[2,1,5]  R824      -1.0845420509576797e-01
    z[2,1,5]  R825      -6.4834314584732056e-01
    z[2,1,5]  R826      -4.9363338947296143e-01
    z[2,1,5]  R827      0.472953200340271
    z[2,1,5]  R828      7.3955051600933075e-02
    z[2,1,5]  R829      5.4328376054763794e-01
    z[2,1,5]  R830      3.9821276068687439e-01
    z[2,1,5]  R831      -1.3570861518383026e-01
    z[2,1,5]  R832      -2.8387421369552612e-01
    z[2,1,5]  R833      1.7517729103565216e-01
    z[2,1,5]  R834      5.7705128192901611e-01
    z[2,1,5]  R835      4.4803205132484436e-01
    z[2,1,5]  R836      -4.0736470371484756e-02
    z[2,1,5]  R837      -3.5944998264312744e-02
    z[2,1,5]  R838      6.0712260007858276e-01
    z[2,1,5]  R839      2.9833678156137466e-02
    z[2,1,5]  R840      -2.2303852438926697e-01
    z[2,1,5]  R841      -4.6621689200401306e-01
    z[2,1,5]  R842      7.1863436698913574e-01
    z[2,1,5]  R843      -3.0003547668457031e-01
    z[2,1,5]  R844      -4.7163897752761841e-01
    z[2,1,5]  R845      1.7729481682181358e-02
    z[2,1,5]  R846      -9.3078408390283585e-03
    z[2,1,5]  R847      -2.1859265863895416e-01
    z[2,1,5]  R848      -4.8749871551990509e-02
    z[2,1,5]  R849      -2.3280568420886993e-01
    z[2,1,5]  R850      2.9659522697329521e-02
    z[2,1,5]  R851      -9.1489471495151520e-02
    z[2,1,5]  R852      -2.2897738218307495e-01
    z[2,1,5]  R853      -3.7888392806053162e-01
    z[2,1,5]  R854      -2.6533809304237366e-01
    z[2,1,5]  R855      -2.4617217481136322e-01
    z[2,1,5]  R856      -6.3933007419109344e-02
    z[2,1,5]  R857      2.6166521012783051e-02
    z[2,1,5]  R858      1.9349291920661926e-02
    z[2,1,5]  R859      -9.4485692679882050e-02
    z[2,1,5]  R860      -4.1054549813270569e-01
    z[2,1,5]  R861      -2.8887656331062317e-01
    z[2,1,5]  R862      -1.6198687255382538e-02
    z[2,1,5]  R863      -5.9515470266342163e-01
    z[2,1,5]  R864      0.511829674243927
    z[2,1,5]  R865      -1.7855094745755196e-02
    z[2,1,5]  R866      7.9831105470657349e-01
    z[2,1,5]  R867      -4.5378437638282776e-01
    z[2,1,5]  R868      -3.8740321993827820e-02
    z[2,1,5]  R869      5.1221899688243866e-02
    z[2,1,5]  R870      4.3502485752105713e-01
    z[2,1,5]  R871      2.8338757157325745e-01
    z[2,1,5]  R872      -5.8941155672073364e-01
    z[2,1,5]  R873      7.1740388870239258e-01
    z[2,1,5]  R874      4.7157999873161316e-01
    z[2,1,5]  R875      6.4506232738494873e-01
    z[2,1,5]  R876      0.470276415348053
    z[2,1,5]  R877      -2.1214704215526581e-01
    z[2,1,5]  R878      6.2924438714981079e-01
    z[2,1,5]  R879      3.6016049981117249e-01
    z[2,1,5]  R880      4.0202996134757996e-01
    z[2,1,5]  R881      1.5639634430408478e-01
    z[2,1,5]  R882      3.5411562770605087e-02
    z[2,1,5]  R883      1.5060894191265106e-01
    z[2,1,5]  R884      -1.3921947777271271e-01
    z[2,1,5]  R885      0.310105562210083
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R765      -1
    z[2,1,6]  R766      1
    z[2,1,6]  R767      -1.7198163270950317e-01
    z[2,1,6]  R768      9.7616732120513916e-02
    z[2,1,6]  R769      8.6575500667095184e-02
    z[2,1,6]  R770      2.6357337832450867e-01
    z[2,1,6]  R771      9.2977419495582581e-02
    z[2,1,6]  R772      1.7765671014785767e-01
    z[2,1,6]  R773      0.538210928440094
    z[2,1,6]  R774      -9.9790245294570923e-02
    z[2,1,6]  R775      0.267120897769928
    z[2,1,6]  R776      -7.2021287679672241e-01
    z[2,1,6]  R777      1.5352459251880646e-01
    z[2,1,6]  R778      0.329188734292984
    z[2,1,6]  R779      2.3916792869567871e-01
    z[2,1,6]  R780      -1.8713575601577759e-01
    z[2,1,6]  R781      4.9038669466972351e-01
    z[2,1,6]  R782      -2.7009156346321106e-01
    z[2,1,6]  R783      5.6678575277328491e-01
    z[2,1,6]  R784      3.7452098727226257e-01
    z[2,1,6]  R785      1.6239304840564728e-01
    z[2,1,6]  R786      3.7542721629142761e-01
    z[2,1,6]  R787      -5.5112581700086594e-02
    z[2,1,6]  R788      -4.4175809621810913e-01
    z[2,1,6]  R789      2.0904199779033661e-01
    z[2,1,6]  R790      -3.4600594639778137e-01
    z[2,1,6]  R791      1.0638792812824249e-01
    z[2,1,6]  R792      5.7504154741764069e-02
    z[2,1,6]  R793      7.3766849935054779e-02
    z[2,1,6]  R794      3.7288421392440796e-01
    z[2,1,6]  R795      -3.0995625257492065e-01
    z[2,1,6]  R796      -2.8730648756027222e-01
    z[2,1,6]  R797      -3.0975034832954407e-01
    z[2,1,6]  R798      2.0896416902542114e-01
    z[2,1,6]  R799      1.2505804002285004e-01
    z[2,1,6]  R800      -5.4767656326293945e-01
    z[2,1,6]  R801      -5.5913275480270386e-01
    z[2,1,6]  R802      -2.9187005758285522e-01
    z[2,1,6]  R803      5.7579171657562256e-01
    z[2,1,6]  R804      -4.8718109726905823e-01
    z[2,1,6]  R805      -5.5757766962051392e-01
    z[2,1,6]  R806      1.5979956090450287e-01
    z[2,1,6]  R807      1.1773577332496643e-01
    z[2,1,6]  R808      -1.1788261681795120e-01
    z[2,1,6]  R809      3.7980252504348755e-01
    z[2,1,6]  R810      -1.0959913581609726e-01
    z[2,1,6]  R811      -1.5310059487819672e-01
    z[2,1,6]  R812      -7.4085518717765808e-02
    z[2,1,6]  R813      -1.8072827160358429e-01
    z[2,1,6]  R814      -4.6383801102638245e-01
    z[2,1,6]  R815      1.4695416390895844e-01
    z[2,1,6]  R816      2.5241279974579811e-02
    z[2,1,6]  R817      -2.5018927454948425e-01
    z[2,1,6]  R818      -3.3541226387023926e-01
    z[2,1,6]  R819      3.1361293792724609e-01
    z[2,1,6]  R820      2.8857663273811340e-01
    z[2,1,6]  R821      -2.0775970816612244e-01
    z[2,1,6]  R822      4.2690834403038025e-01
    z[2,1,6]  R823      -2.1375331282615662e-01
    z[2,1,6]  R824      1.6016711294651031e-01
    z[2,1,6]  R825      8.2306535914540291e-03
    z[2,1,6]  R826      1.4425319433212280e-01
    z[2,1,6]  R827      5.8335000276565552e-01
    z[2,1,6]  R828      -2.3129422962665558e-01
    z[2,1,6]  R829      1.6793212294578552e-01
    z[2,1,6]  R830      -3.8830515742301941e-01
    z[2,1,6]  R831      -3.7465396523475647e-01
    z[2,1,6]  R832      5.2417159080505371e-02
    z[2,1,6]  R833      -0.200520858168602
    z[2,1,6]  R834      2.5251591205596924e-01
    z[2,1,6]  R835      -0.011157201603055
    z[2,1,6]  R836      4.9335334450006485e-02
    z[2,1,6]  R837      -4.9009706825017929e-02
    z[2,1,6]  R838      1.0897734016180038e-01
    z[2,1,6]  R839      -2.9252591729164124e-01
    z[2,1,6]  R840      9.0420506894588470e-02
    z[2,1,6]  R841      -2.0941365510225296e-02
    z[2,1,6]  R842      -4.7655689716339111e-01
    z[2,1,6]  R843      -3.7927865982055664e-01
    z[2,1,6]  R844      0.0328315831720829
    z[2,1,6]  R845      -1.6944380104541779e-01
    z[2,1,6]  R846      -7.0934578776359558e-02
    z[2,1,6]  R847      -7.4649795889854431e-02
    z[2,1,6]  R848      -2.7094435691833496e-01
    z[2,1,6]  R849      -4.0650174021720886e-01
    z[2,1,6]  R850      2.6229172945022583e-01
    z[2,1,6]  R851      1.0801345109939575e-01
    z[2,1,6]  R852      2.3452107608318329e-01
    z[2,1,6]  R853      -1.5046596527099609e-01
    z[2,1,6]  R854      -3.5242381691932678e-01
    z[2,1,6]  R855      -4.3461519479751587e-01
    z[2,1,6]  R856      4.4097259640693665e-01
    z[2,1,6]  R857      2.9650470614433289e-01
    z[2,1,6]  R858      -7.0150340907275677e-03
    z[2,1,6]  R859      -1.3066437840461731e-01
    z[2,1,6]  R860      3.5713097453117371e-01
    z[2,1,6]  R861      7.8432798385620117e-02
    z[2,1,6]  R862      3.3497631549835205e-01
    z[2,1,6]  R863      -1.4120413362979889e-01
    z[2,1,6]  R864      0.427981436252594
    z[2,1,6]  R865      2.2896234691143036e-01
    z[2,1,6]  R866      -2.4735176935791969e-02
    z[2,1,6]  R867      7.2249300777912140e-02
    z[2,1,6]  R868      5.3443264961242676e-01
    z[2,1,6]  R869      4.0446621179580688e-01
    z[2,1,6]  R870      -9.1245517134666443e-02
    z[2,1,6]  R871      3.2425481826066971e-02
    z[2,1,6]  R872      -4.0871286392211914e-01
    z[2,1,6]  R873      -3.4263423085212708e-01
    z[2,1,6]  R874      2.3423831164836884e-01
    z[2,1,6]  R875      7.5188823044300079e-02
    z[2,1,6]  R876      1.8589356541633606e-01
    z[2,1,6]  R877      -6.1101114749908447e-01
    z[2,1,6]  R878      -7.7761389315128326e-02
    z[2,1,6]  R879      -4.8468500375747681e-01
    z[2,1,6]  R880      -2.3520238697528839e-01
    z[2,1,6]  R881      1.2026961892843246e-01
    z[2,1,6]  R882      -2.5747832655906677e-01
    z[2,1,6]  R883      9.4179525971412659e-02
    z[2,1,6]  R884      -1.6847959160804749e-01
    z[2,1,6]  R885      -2.7254357933998108e-01
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R886      -1
    z[2,3,0]  R887      1
    z[2,3,0]  R900      -4.1689458489418030e-01
    z[2,3,0]  R901      -4.8468196392059326e-01
    z[2,3,0]  R902      -5.7306480407714844e-01
    z[2,3,0]  R903      -3.4239238500595093e-01
    z[2,3,0]  R904      -6.0957503318786621e-01
    z[2,3,0]  R905      -3.2015225291252136e-01
    z[2,3,0]  R906      -3.0857360363006592e-01
    z[2,3,0]  R907      -3.9235708117485046e-01
    z[2,3,0]  R908      -3.4801444411277771e-01
    z[2,3,0]  R909      3.6987990140914917e-02
    z[2,3,0]  R910      3.7160363048315048e-02
    z[2,3,0]  R911      4.9446426331996918e-02
    z[2,3,0]  R912      9.2987410724163055e-02
    z[2,3,0]  R913      1.6451187431812286e-01
    z[2,3,0]  R914      3.8392234593629837e-02
    z[2,3,0]  R915      2.3820878937840462e-02
    z[2,3,0]  R916      -3.6871144175529480e-01
    z[2,3,0]  R917      -1.8168369308114052e-02
    z[2,3,0]  R918      4.3558844923973083e-01
    z[2,3,0]  R919      -3.8961544632911682e-02
    z[2,3,0]  R920      2.1219049394130707e-01
    z[2,3,0]  R921      1.0946871340274811e-01
    z[2,3,0]  R922      -1.0069070756435394e-01
    z[2,3,0]  R923      5.2443742752075195e-02
    z[2,3,0]  R924      2.7736195921897888e-01
    z[2,3,0]  R925      -9.2849425971508026e-02
    z[2,3,0]  R926      -9.0580090880393982e-02
    z[2,3,0]  R927      -1.5218126773834229e-01
    z[2,3,0]  R928      -3.0100749805569649e-02
    z[2,3,0]  R929      -3.4075182676315308e-01
    z[2,3,0]  R930      -1.8804021179676056e-01
    z[2,3,0]  R931      -1.2020721286535263e-01
    z[2,3,0]  R932      1.3284712098538876e-02
    z[2,3,0]  R933      -1.1131456494331360e-01
    z[2,3,0]  R934      -1.0430975258350372e-01
    z[2,3,0]  R935      -2.2587503492832184e-01
    z[2,3,0]  R936      -1.0576321184635162e-01
    z[2,3,0]  R937      -2.6120189577341080e-02
    z[2,3,0]  R938      8.6152262985706329e-02
    z[2,3,0]  R939      1.7868988215923309e-01
    z[2,3,0]  R940      2.1687847375869751e-01
    z[2,3,0]  R941      -7.6703220605850220e-02
    z[2,3,0]  R942      -5.7236045598983765e-01
    z[2,3,0]  R943      3.7944954633712769e-01
    z[2,3,0]  R944      -1.9736465811729431e-01
    z[2,3,0]  R945      -3.9486771821975708e-01
    z[2,3,0]  R946      0.0852629616856575
    z[2,3,0]  R947      -2.9006785154342651e-01
    z[2,3,0]  R948      1.5264980494976044e-01
    z[2,3,0]  R949      2.2403240203857422e-01
    z[2,3,0]  R950      -2.2230571508407593e-01
    z[2,3,0]  R951      -3.1105026602745056e-01
    z[2,3,0]  R952      -5.1620435714721680e-01
    z[2,3,0]  R953      -1.7105893790721893e-01
    z[2,3,0]  R954      2.1935540437698364e-01
    z[2,3,0]  R955      1.0663330322131515e-03
    z[2,3,0]  R956      -3.1086322665214539e-01
    z[2,3,0]  R957      4.4636088609695435e-01
    z[2,3,0]  R958      6.9318538904190063e-01
    z[2,3,0]  R959      8.1855165958404541e-01
    z[2,3,0]  R960      4.0272515267133713e-02
    z[2,3,0]  R961      3.4263002872467041e-01
    z[2,3,0]  R962      -1.5010145306587219e-01
    z[2,3,0]  R963      -1.5877915918827057e-01
    z[2,3,0]  R964      -2.8038141131401062e-01
    z[2,3,0]  R965      2.9783645272254944e-01
    z[2,3,0]  R966      -3.5361889004707336e-01
    z[2,3,0]  R967      -2.7545174956321716e-01
    z[2,3,0]  R968      -3.9055564999580383e-01
    z[2,3,0]  R969      3.1482365727424622e-01
    z[2,3,0]  R970      1.7461758852005005e-01
    z[2,3,0]  R971      -2.4204730987548828e-01
    z[2,3,0]  R972      -3.5855054855346680e-01
    z[2,3,0]  R973      -2.6036825776100159e-01
    z[2,3,0]  R974      2.1546375751495361e-01
    z[2,3,0]  R975      6.7238390445709229e-02
    z[2,3,0]  R976      -2.7760851383209229e-01
    z[2,3,0]  R977      7.6810318231582642e-01
    z[2,3,0]  R978      9.5003110170364380e-01
    z[2,3,0]  R979      9.3456918001174927e-01
    z[2,3,0]  R980      3.8435712456703186e-01
    z[2,3,0]  R981      4.6964627504348755e-01
    z[2,3,0]  R982      1.2871317565441132e-01
    z[2,3,0]  R983      3.3063021302223206e-01
    z[2,3,0]  R984      -1.5768514573574066e-01
    z[2,3,0]  R985      -6.0754650831222534e-01
    z[2,3,0]  R986      -4.4395166635513306e-01
    z[2,3,0]  R987      -1.7489361763000488e-01
    z[2,3,0]  R988      -6.6080474853515625e-01
    z[2,3,0]  R989      -6.0426956415176392e-01
    z[2,3,0]  R990      -3.8641926646232605e-01
    z[2,3,0]  R991      -2.2747081518173218e-01
    z[2,3,0]  R992      -1.8546903133392334e-01
    z[2,3,0]  R993      -2.2525892127305269e-03
    z[2,3,0]  R994      -3.2109636068344116e-01
    z[2,3,0]  R995      -2.2801786661148071e-02
    z[2,3,0]  R996      -5.9258061647415161e-01
    z[2,3,0]  R997      -3.0523759126663208e-01
    z[2,3,0]  R998      -4.9144953489303589e-01
    z[2,3,0]  R999      3.5981366038322449e-01
    z[2,3,0]  R1000     4.6973848342895508e-01
    z[2,3,0]  R1001     3.7984788417816162e-01
    z[2,3,0]  R1002     3.2363331317901611e-01
    z[2,3,0]  R1003     -1.0073760896921158e-01
    z[2,3,0]  R1004     -5.3915452957153320e-01
    z[2,3,0]  R1005     0.573432981967926
    z[2,3,0]  R1006     5.8630925416946411e-01
    z[2,3,0]  R1007     6.3679113984107971e-02
    z[2,3,0]  R1008     1.5071780420839787e-02
    z[2,3,0]  R1009     1.0220363736152649e-01
    z[2,3,0]  R1010     7.9044562578201294e-01
    z[2,3,0]  R1011     -8.5493430495262146e-02
    z[2,3,0]  R1012     -2.8234678506851196e-01
    z[2,3,0]  R1013     -1.1949960142374039e-01
    z[2,3,0]  R1014     -4.2563432455062866e-01
    z[2,3,0]  R1015     -3.5032281279563904e-01
    z[2,3,0]  R1016     -2.7937644720077515e-01
    z[2,3,0]  R1017     -3.0842721462249756e-01
    z[2,3,0]  R1018     -6.1874139308929443e-01
    z[2,3,0]  R1019     -4.4269609451293945e-01
    z[2,3,0]  R1020     1.0344447195529938e-01
    z[2,3,0]  R1021     -9.6073616296052933e-03
    z[2,3,0]  R1022     -3.5229781270027161e-01
    z[2,3,0]  R1023     2.1113598719239235e-02
    z[2,3,0]  R1024     -1.6194912791252136e-01
    z[2,3,0]  R1025     1.4746780693531036e-01
    z[2,3,0]  R1026     -3.9892011880874634e-01
    z[2,3,0]  R1027     -2.4754211306571960e-01
    z[2,3,0]  R1028     -5.6692034006118774e-01
    z[2,3,0]  R1029     -6.1223447322845459e-01
    z[2,3,0]  R1030     -8.9415594935417175e-02
    z[2,3,0]  R1031     5.4197525978088379e-01
    z[2,3,0]  R1032     -3.4987998008728027e-01
    z[2,3,0]  R1033     -5.3841060400009155e-01
    z[2,3,0]  R1034     1.6175134107470512e-02
    z[2,3,0]  R1035     1.9008865579962730e-02
    z[2,3,0]  R1036     -1.1379750072956085e-01
    z[2,3,0]  R1037     8.3032414317131042e-02
    z[2,3,0]  R1038     -6.1901800334453583e-02
    z[2,3,0]  R1039     2.9676225781440735e-01
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R888      -1
    z[2,3,1]  R889      1
    z[2,3,1]  R900      -3.3204442262649536e-01
    z[2,3,1]  R901      -2.5690299272537231e-01
    z[2,3,1]  R902      -4.6997055411338806e-01
    z[2,3,1]  R903      -4.6174040436744690e-01
    z[2,3,1]  R904      -4.8508054018020630e-01
    z[2,3,1]  R905      -0.602096676826477
    z[2,3,1]  R906      1.2655800208449364e-02
    z[2,3,1]  R907      -1.6722084954380989e-02
    z[2,3,1]  R908      -1.5665067732334137e-01
    z[2,3,1]  R909      2.9285481572151184e-01
    z[2,3,1]  R910      7.0536142587661743e-01
    z[2,3,1]  R911      3.4541028738021851e-01
    z[2,3,1]  R912      0.516209065914154
    z[2,3,1]  R913      4.8548287153244019e-01
    z[2,3,1]  R914      3.3199149370193481e-01
    z[2,3,1]  R915      5.1212704181671143e-01
    z[2,3,1]  R916      5.9532564878463745e-01
    z[2,3,1]  R917      6.3990515470504761e-01
    z[2,3,1]  R918      4.8651802539825439e-01
    z[2,3,1]  R919      4.3544858694076538e-01
    z[2,3,1]  R920      -3.4603667259216309e-01
    z[2,3,1]  R921      0.720102846622467
    z[2,3,1]  R922      -4.8885107971727848e-03
    z[2,3,1]  R923      6.4501903951168060e-02
    z[2,3,1]  R924      -2.0838995277881622e-01
    z[2,3,1]  R925      -2.4802862107753754e-01
    z[2,3,1]  R926      -7.4762886762619019e-01
    z[2,3,1]  R927      4.9201175570487976e-02
    z[2,3,1]  R928      3.2671761512756348e-01
    z[2,3,1]  R929      -1.0198544710874557e-01
    z[2,3,1]  R930      -2.8616625815629959e-02
    z[2,3,1]  R931      3.1933152675628662e-01
    z[2,3,1]  R932      6.5530651807785034e-01
    z[2,3,1]  R933      -7.6302891969680786e-01
    z[2,3,1]  R934      -0.713287353515625
    z[2,3,1]  R935      3.4502479434013367e-01
    z[2,3,1]  R936      -1.5632529556751251e-01
    z[2,3,1]  R937      4.4123733043670654e-01
    z[2,3,1]  R938      -4.0507555007934570e-01
    z[2,3,1]  R939      -7.1970999240875244e-02
    z[2,3,1]  R940      -1.0386711359024048e-01
    z[2,3,1]  R941      -0.826941728591919
    z[2,3,1]  R942      5.5064874887466431e-01
    z[2,3,1]  R943      5.6682562828063965e-01
    z[2,3,1]  R944      -0.637488067150116
    z[2,3,1]  R945      3.1302982568740845e-01
    z[2,3,1]  R946      -4.3343013525009155e-01
    z[2,3,1]  R947      -5.8169806003570557e-01
    z[2,3,1]  R948      8.8284105062484741e-01
    z[2,3,1]  R949      7.3823785781860352e-01
    z[2,3,1]  R950      -7.5214987993240356e-01
    z[2,3,1]  R951      4.9054896831512451e-01
    z[2,3,1]  R952      4.3570250272750854e-01
    z[2,3,1]  R953      9.2652714252471924e-01
    z[2,3,1]  R954      8.0565035343170166e-01
    z[2,3,1]  R955      -5.6556481122970581e-01
    z[2,3,1]  R956      4.0573990345001221e-01
    z[2,3,1]  R957      6.1703330278396606e-01
    z[2,3,1]  R958      -1.1697446554899216e-01
    z[2,3,1]  R959      -1.9792547821998596e-01
    z[2,3,1]  R960      -1.3860097527503967e-01
    z[2,3,1]  R961      0.715706467628479
    z[2,3,1]  R962      6.6889148950576782e-01
    z[2,3,1]  R963      2.9724597930908203e-01
    z[2,3,1]  R964      -6.8008792400360107e-01
    z[2,3,1]  R965      8.8679903745651245e-01
    z[2,3,1]  R966      -7.1929872035980225e-01
    z[2,3,1]  R967      -3.0911669135093689e-01
    z[2,3,1]  R968      3.7147161364555359e-01
    z[2,3,1]  R969      0.74797123670578
    z[2,3,1]  R970      7.5768578052520752e-01
    z[2,3,1]  R971      -3.3206534385681152e-01
    z[2,3,1]  R972      -7.1302127838134766e-01
    z[2,3,1]  R973      6.7258435487747192e-01
    z[2,3,1]  R974      7.0505040884017944e-01
    z[2,3,1]  R975      -6.5480205230414867e-03
    z[2,3,1]  R976      -7.0366328954696655e-01
    z[2,3,1]  R977      -3.0529114603996277e-01
    z[2,3,1]  R978      1.3688798062503338e-02
    z[2,3,1]  R979      4.1255757212638855e-02
    z[2,3,1]  R980      -3.8943392038345337e-01
    z[2,3,1]  R981      1.0056421905755997e-01
    z[2,3,1]  R982      1.5411810576915741e-01
    z[2,3,1]  R983      -7.9090172052383423e-01
    z[2,3,1]  R984      -0.0875360444188118
    z[2,3,1]  R985      -6.2563389539718628e-01
    z[2,3,1]  R986      -0.704354465007782
    z[2,3,1]  R987      -7.9132989048957825e-02
    z[2,3,1]  R988      -6.2296229600906372e-01
    z[2,3,1]  R989      -6.6563093662261963e-01
    z[2,3,1]  R990      -4.1182957589626312e-02
    z[2,3,1]  R991      -3.4564676880836487e-01
    z[2,3,1]  R992      2.8088864684104919e-01
    z[2,3,1]  R993      3.0188298225402832e-01
    z[2,3,1]  R994      6.1274491250514984e-02
    z[2,3,1]  R995      0.0978856310248375
    z[2,3,1]  R996      2.0466198027133942e-01
    z[2,3,1]  R997      6.6788643598556519e-03
    z[2,3,1]  R998      1.1274852603673935e-01
    z[2,3,1]  R999      4.3839445710182190e-01
    z[2,3,1]  R1000     3.5533255338668823e-01
    z[2,3,1]  R1001     -6.9836688041687012e-01
    z[2,3,1]  R1002     -3.9601841568946838e-01
    z[2,3,1]  R1003     1.1077233403921127e-01
    z[2,3,1]  R1004     2.0387648046016693e-01
    z[2,3,1]  R1005     -2.1392878890037537e-01
    z[2,3,1]  R1006     3.0866166949272156e-01
    z[2,3,1]  R1007     -1.5111443400382996e-01
    z[2,3,1]  R1008     2.5715095922350883e-02
    z[2,3,1]  R1009     -1.4068578183650970e-01
    z[2,3,1]  R1010     -0.302144318819046
    z[2,3,1]  R1011     3.4736540168523788e-02
    z[2,3,1]  R1012     -1.4574143290519714e-01
    z[2,3,1]  R1013     -2.2250409424304962e-01
    z[2,3,1]  R1014     -4.6310713887214661e-01
    z[2,3,1]  R1015     2.1093061566352844e-01
    z[2,3,1]  R1016     -8.5881382226943970e-01
    z[2,3,1]  R1017     -4.4231769442558289e-01
    z[2,3,1]  R1018     -0.606364369392395
    z[2,3,1]  R1019     -7.1295052766799927e-01
    z[2,3,1]  R1020     7.0980495214462280e-01
    z[2,3,1]  R1021     -4.2589294910430908e-01
    z[2,3,1]  R1022     -1.5035982429981232e-01
    z[2,3,1]  R1023     9.3660390377044678e-01
    z[2,3,1]  R1024     9.3908828496932983e-01
    z[2,3,1]  R1025     8.6301565170288086e-01
    z[2,3,1]  R1026     5.0970077514648438e-01
    z[2,3,1]  R1027     7.0335948467254639e-01
    z[2,3,1]  R1028     2.9809432104229927e-02
    z[2,3,1]  R1029     -9.8309412598609924e-02
    z[2,3,1]  R1030     6.9336611032485962e-01
    z[2,3,1]  R1031     -6.0947406291961670e-01
    z[2,3,1]  R1032     -2.0571936666965485e-01
    z[2,3,1]  R1033     -7.4226832389831543e-01
    z[2,3,1]  R1034     1.8295995891094208e-01
    z[2,3,1]  R1035     6.1455290764570236e-02
    z[2,3,1]  R1036     1.7191922664642334e-01
    z[2,3,1]  R1037     2.5506317615509033e-01
    z[2,3,1]  R1038     9.5106415450572968e-02
    z[2,3,1]  R1039     -8.0855406820774078e-02
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R890      -1
    z[2,3,2]  R891      1
    z[2,3,2]  R900      4.2972904443740845e-01
    z[2,3,2]  R901      2.9859790205955505e-01
    z[2,3,2]  R902      -1.4298494160175323e-01
    z[2,3,2]  R903      1.9827237725257874e-01
    z[2,3,2]  R904      2.4667717516422272e-01
    z[2,3,2]  R905      6.6764909029006958e-01
    z[2,3,2]  R906      0.749691903591156
    z[2,3,2]  R907      0.794209361076355
    z[2,3,2]  R908      7.4640804529190063e-01
    z[2,3,2]  R909      -5.7840985059738159e-01
    z[2,3,2]  R910      -4.9356621503829956e-01
    z[2,3,2]  R911      -5.4023534059524536e-01
    z[2,3,2]  R912      -6.4635413885116577e-01
    z[2,3,2]  R913      -9.2058137059211731e-02
    z[2,3,2]  R914      -7.9390835762023926e-01
    z[2,3,2]  R915      -4.5745104551315308e-01
    z[2,3,2]  R916      -3.7056869268417358e-01
    z[2,3,2]  R917      -4.0922570228576660e-01
    z[2,3,2]  R918      -4.8002764582633972e-01
    z[2,3,2]  R919      -6.8645268678665161e-01
    z[2,3,2]  R920      4.0704756975173950e-01
    z[2,3,2]  R921      -3.5753306746482849e-01
    z[2,3,2]  R922      -3.2452747225761414e-01
    z[2,3,2]  R923      -1.6314937174320221e-01
    z[2,3,2]  R924      1.8298590555787086e-02
    z[2,3,2]  R925      -2.8553183656185865e-03
    z[2,3,2]  R926      -4.5324909687042236e-01
    z[2,3,2]  R927      7.4352012015879154e-03
    z[2,3,2]  R928      1.7782163619995117e-01
    z[2,3,2]  R929      9.8059467971324921e-02
    z[2,3,2]  R930      3.7972810864448547e-01
    z[2,3,2]  R931      -6.2939512729644775e-01
    z[2,3,2]  R932      -0.642380952835083
    z[2,3,2]  R933      -6.9627188146114349e-02
    z[2,3,2]  R934      -1.6084440052509308e-01
    z[2,3,2]  R935      -5.4775995016098022e-01
    z[2,3,2]  R936      -4.4738808274269104e-01
    z[2,3,2]  R937      -5.5230081081390381e-01
    z[2,3,2]  R938      4.3478560447692871e-01
    z[2,3,2]  R939      -5.3456395864486694e-01
    z[2,3,2]  R940      4.4696268439292908e-01
    z[2,3,2]  R941      -2.2541087865829468e-01
    z[2,3,2]  R942      -4.3915849924087524e-01
    z[2,3,2]  R943      -6.5261960029602051e-01
    z[2,3,2]  R944      -1.2304015457630157e-01
    z[2,3,2]  R945      -6.2947779893875122e-01
    z[2,3,2]  R946      -3.2969605177640915e-02
    z[2,3,2]  R947      -3.2634842395782471e-01
    z[2,3,2]  R948      2.6758614182472229e-01
    z[2,3,2]  R949      4.3983215093612671e-01
    z[2,3,2]  R950      -9.5280326902866364e-02
    z[2,3,2]  R951      -0.634859025478363
    z[2,3,2]  R952      -6.4517909288406372e-01
    z[2,3,2]  R953      0.0360434390604496
    z[2,3,2]  R954      4.5218861103057861e-01
    z[2,3,2]  R955      -1.2078131549060345e-02
    z[2,3,2]  R956      1.2855865061283112e-01
    z[2,3,2]  R957      5.5934345722198486e-01
    z[2,3,2]  R958      -2.0315490663051605e-01
    z[2,3,2]  R959      -1.4706824719905853e-01
    z[2,3,2]  R960      1.7670039832592010e-01
    z[2,3,2]  R961      -4.8426979780197144e-01
    z[2,3,2]  R962      -2.8648141026496887e-01
    z[2,3,2]  R963      -6.8398404121398926e-01
    z[2,3,2]  R964      -5.9787672013044357e-02
    z[2,3,2]  R965      -1.4526379108428955e-01
    z[2,3,2]  R966      3.9475105702877045e-02
    z[2,3,2]  R967      2.5788527727127075e-01
    z[2,3,2]  R968      -4.6022129058837891e-01
    z[2,3,2]  R969      5.2115124464035034e-01
    z[2,3,2]  R970      -2.4724586308002472e-01
    z[2,3,2]  R971      3.8947898149490356e-01
    z[2,3,2]  R972      -1.5772011876106262e-01
    z[2,3,2]  R973      -0.574109673500061
    z[2,3,2]  R974      -4.5492088794708252e-01
    z[2,3,2]  R975      4.2822387814521790e-01
    z[2,3,2]  R976      -2.8702369332313538e-01
    z[2,3,2]  R977      -0.175094336271286
    z[2,3,2]  R978      6.2799490988254547e-02
    z[2,3,2]  R979      2.5760421156883240e-01
    z[2,3,2]  R980      -1.3613632321357727e-01
    z[2,3,2]  R981      -3.2119369506835938e-01
    z[2,3,2]  R982      0.11175537109375
    z[2,3,2]  R983      3.1654998660087585e-02
    z[2,3,2]  R984      8.4770750999450684e-01
    z[2,3,2]  R985      -1.4828373491764069e-01
    z[2,3,2]  R986      2.9359790682792664e-01
    z[2,3,2]  R987      0.686779260635376
    z[2,3,2]  R988      -3.4933474659919739e-01
    z[2,3,2]  R989      -1.5206056833267212e-01
    z[2,3,2]  R990      1.1364550888538361e-01
    z[2,3,2]  R991      3.4251266717910767e-01
    z[2,3,2]  R992      8.4152139723300934e-02
    z[2,3,2]  R993      -7.0116829872131348e-01
    z[2,3,2]  R994      0.310958594083786
    z[2,3,2]  R995      -4.8581293225288391e-01
    z[2,3,2]  R996      1.5351407229900360e-01
    z[2,3,2]  R997      -2.2517786920070648e-01
    z[2,3,2]  R998      2.1858850494027138e-02
    z[2,3,2]  R999      -4.2397168278694153e-01
    z[2,3,2]  R1000     1.2479174137115479e-01
    z[2,3,2]  R1001     4.9236118793487549e-01
    z[2,3,2]  R1002     7.7350640296936035e-01
    z[2,3,2]  R1003     4.2019265890121460e-01
    z[2,3,2]  R1004     3.5428783297538757e-01
    z[2,3,2]  R1005     3.6612513661384583e-01
    z[2,3,2]  R1006     1.0885686427354813e-01
    z[2,3,2]  R1007     5.1020783185958862e-01
    z[2,3,2]  R1008     6.2840634584426880e-01
    z[2,3,2]  R1009     9.5704257488250732e-02
    z[2,3,2]  R1010     4.8155072331428528e-01
    z[2,3,2]  R1011     0.616873025894165
    z[2,3,2]  R1012     4.6412819623947144e-01
    z[2,3,2]  R1013     1.1298055946826935e-01
    z[2,3,2]  R1014     4.5124284923076630e-02
    z[2,3,2]  R1015     6.3735512085258961e-03
    z[2,3,2]  R1016     -2.0513303577899933e-01
    z[2,3,2]  R1017     -1.2549702823162079e-01
    z[2,3,2]  R1018     -1.3414016366004944e-01
    z[2,3,2]  R1019     2.1963019669055939e-01
    z[2,3,2]  R1020     -4.5000827312469482e-01
    z[2,3,2]  R1021     8.7170645594596863e-02
    z[2,3,2]  R1022     2.8488731384277344e-01
    z[2,3,2]  R1023     2.7279371395707130e-02
    z[2,3,2]  R1024     -1.3675086200237274e-01
    z[2,3,2]  R1025     3.0031827092170715e-01
    z[2,3,2]  R1026     -6.9078212976455688e-01
    z[2,3,2]  R1027     -5.2651494741439819e-01
    z[2,3,2]  R1028     2.8083970770239830e-02
    z[2,3,2]  R1029     2.4156154692173004e-01
    z[2,3,2]  R1030     -5.5537432432174683e-01
    z[2,3,2]  R1031     2.1817199885845184e-01
    z[2,3,2]  R1032     2.2642841935157776e-01
    z[2,3,2]  R1033     -1.9141036272048950e-01
    z[2,3,2]  R1034     1.1570196598768234e-01
    z[2,3,2]  R1035     -0.0828382596373558
    z[2,3,2]  R1036     2.0725773274898529e-01
    z[2,3,2]  R1037     8.0018816515803337e-03
    z[2,3,2]  R1038     -3.0644190311431885e-01
    z[2,3,2]  R1039     -1.1769544333219528e-01
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R892      -1
    z[2,3,3]  R893      1
    z[2,3,3]  R900      7.0460617542266846e-01
    z[2,3,3]  R901      6.3385230302810669e-01
    z[2,3,3]  R902      5.1752287149429321e-01
    z[2,3,3]  R903      0.691716730594635
    z[2,3,3]  R904      -2.8274807333946228e-01
    z[2,3,3]  R905      2.2858205437660217e-01
    z[2,3,3]  R906      -9.3946717679500580e-02
    z[2,3,3]  R907      -9.8623782396316528e-02
    z[2,3,3]  R908      1.6305133700370789e-02
    z[2,3,3]  R909      2.3331997916102409e-02
    z[2,3,3]  R910      6.5564163029193878e-02
    z[2,3,3]  R911      5.2176183462142944e-01
    z[2,3,3]  R912      4.3301886320114136e-01
    z[2,3,3]  R913      -7.2795635461807251e-01
    z[2,3,3]  R914      1.0284223407506943e-01
    z[2,3,3]  R915      5.7892650365829468e-01
    z[2,3,3]  R916      1.1072061210870743e-01
    z[2,3,3]  R917      4.8190414905548096e-01
    z[2,3,3]  R918      5.4360177367925644e-02
    z[2,3,3]  R919      -6.8826384842395782e-02
    z[2,3,3]  R920      -8.1118786334991455e-01
    z[2,3,3]  R921      0.0860656350851059
    z[2,3,3]  R922      -0.528769314289093
    z[2,3,3]  R923      -4.9167567491531372e-01
    z[2,3,3]  R924      -6.5119296312332153e-01
    z[2,3,3]  R925      -7.0396721363067627e-01
    z[2,3,3]  R926      -3.1340688467025757e-01
    z[2,3,3]  R927      -6.6030627489089966e-01
    z[2,3,3]  R928      -4.8219156265258789e-01
    z[2,3,3]  R929      -5.1669472455978394e-01
    z[2,3,3]  R930      -0.783909022808075
    z[2,3,3]  R931      6.4680272340774536e-01
    z[2,3,3]  R932      1.1100284755229950e-02
    z[2,3,3]  R933      -1.9375425577163696e-01
    z[2,3,3]  R934      4.3256103992462158e-02
    z[2,3,3]  R935      6.3257914781570435e-01
    z[2,3,3]  R936      -4.0427660942077637e-01
    z[2,3,3]  R937      2.4229690432548523e-01
    z[2,3,3]  R938      3.9681177586317062e-02
    z[2,3,3]  R939      -7.1501910686492920e-01
    z[2,3,3]  R940      -7.5669950246810913e-01
    z[2,3,3]  R941      4.7563002444803715e-03
    z[2,3,3]  R942      8.6002998054027557e-02
    z[2,3,3]  R943      -1.5803065896034241e-01
    z[2,3,3]  R944      -5.2056068181991577e-01
    z[2,3,3]  R945      -8.8108986616134644e-02
    z[2,3,3]  R946      -1.6161488369107246e-02
    z[2,3,3]  R947      -3.6090412735939026e-01
    z[2,3,3]  R948      2.4224698543548584e-01
    z[2,3,3]  R949      2.5279900431632996e-01
    z[2,3,3]  R950      3.5884881019592285e-01
    z[2,3,3]  R951      1.4230453968048096e-01
    z[2,3,3]  R952      -1.0548471659421921e-01
    z[2,3,3]  R953      9.3076996505260468e-02
    z[2,3,3]  R954      1.9540201127529144e-01
    z[2,3,3]  R955      -3.2591944932937622e-01
    z[2,3,3]  R956      1.2794514000415802e-01
    z[2,3,3]  R957      -3.7251997739076614e-02
    z[2,3,3]  R958      -2.0874477922916412e-01
    z[2,3,3]  R959      -4.8169005662202835e-02
    z[2,3,3]  R960      -5.8753520250320435e-01
    z[2,3,3]  R961      8.5866108536720276e-02
    z[2,3,3]  R962      3.1356829404830933e-01
    z[2,3,3]  R963      3.1444475054740906e-01
    z[2,3,3]  R964      -4.0305379033088684e-01
    z[2,3,3]  R965      1.4074213802814484e-01
    z[2,3,3]  R966      -0.36433145403862
    z[2,3,3]  R967      -1.5327471494674683e-01
    z[2,3,3]  R968      6.5086834132671356e-02
    z[2,3,3]  R969      -1.3650661706924438e-01
    z[2,3,3]  R970      5.3470355272293091e-01
    z[2,3,3]  R971      -1.8591515719890594e-01
    z[2,3,3]  R972      -3.2681983709335327e-01
    z[2,3,3]  R973      -1.1359921097755432e-01
    z[2,3,3]  R974      1.7740766704082489e-01
    z[2,3,3]  R975      -2.6093408465385437e-01
    z[2,3,3]  R976      -2.4626623094081879e-01
    z[2,3,3]  R977      1.6839888691902161e-01
    z[2,3,3]  R978      1.1186099052429199e-01
    z[2,3,3]  R979      2.2514252364635468e-01
    z[2,3,3]  R980      4.5321959257125854e-01
    z[2,3,3]  R981      4.4695851206779480e-01
    z[2,3,3]  R982      9.3673390150070190e-01
    z[2,3,3]  R983      1.9504196941852570e-01
    z[2,3,3]  R984      -2.9698863625526428e-01
    z[2,3,3]  R985      -0.0312623456120491
    z[2,3,3]  R986      -2.2925306856632233e-01
    z[2,3,3]  R987      -4.2882928252220154e-01
    z[2,3,3]  R988      6.9269701838493347e-02
    z[2,3,3]  R989      3.7578254938125610e-01
    z[2,3,3]  R990      -8.1052398681640625e-01
    z[2,3,3]  R991      -5.8123838901519775e-01
    z[2,3,3]  R992      -0.560954213142395
    z[2,3,3]  R993      1.1045350879430771e-01
    z[2,3,3]  R994      -3.7698951363563538e-01
    z[2,3,3]  R995      4.2962488532066345e-01
    z[2,3,3]  R996      -4.0225467085838318e-01
    z[2,3,3]  R997      -5.8202630281448364e-01
    z[2,3,3]  R998      -4.1785049438476562e-01
    z[2,3,3]  R999      -3.0952779576182365e-02
    z[2,3,3]  R1000     2.3720730841159821e-01
    z[2,3,3]  R1001     6.9490201771259308e-02
    z[2,3,3]  R1002     1.2240605801343918e-01
    z[2,3,3]  R1003     -6.0070788860321045e-01
    z[2,3,3]  R1004     -0.522066593170166
    z[2,3,3]  R1005     3.8913151621818542e-01
    z[2,3,3]  R1006     3.6415389180183411e-01
    z[2,3,3]  R1007     -1.9415524601936340e-01
    z[2,3,3]  R1008     -3.3607918024063110e-01
    z[2,3,3]  R1009     -3.9141789078712463e-01
    z[2,3,3]  R1010     -8.4982894361019135e-02
    z[2,3,3]  R1011     -5.5730760097503662e-01
    z[2,3,3]  R1012     -9.1690264642238617e-02
    z[2,3,3]  R1013     -7.2996979951858521e-01
    z[2,3,3]  R1014     -5.5128979682922363e-01
    z[2,3,3]  R1015     -0.838477373123169
    z[2,3,3]  R1016     -2.7604243159294128e-01
    z[2,3,3]  R1017     6.3116061687469482e-01
    z[2,3,3]  R1018     -4.3238624930381775e-02
    z[2,3,3]  R1019     3.6420649290084839e-01
    z[2,3,3]  R1020     -3.9759587496519089e-02
    z[2,3,3]  R1021     -2.7081990242004395e-01
    z[2,3,3]  R1022     3.9089463651180267e-02
    z[2,3,3]  R1023     -1.4939683675765991e-01
    z[2,3,3]  R1024     1.0562177002429962e-01
    z[2,3,3]  R1025     4.4475674629211426e-02
    z[2,3,3]  R1026     2.0891658961772919e-01
    z[2,3,3]  R1027     0.14479960501194
    z[2,3,3]  R1028     -2.2908157110214233e-01
    z[2,3,3]  R1029     -8.4188235923647881e-03
    z[2,3,3]  R1030     3.7611511349678040e-01
    z[2,3,3]  R1031     -2.1606069058179855e-02
    z[2,3,3]  R1032     -2.7403208613395691e-01
    z[2,3,3]  R1033     1.7212149500846863e-01
    z[2,3,3]  R1034     4.7052096575498581e-02
    z[2,3,3]  R1035     -3.6566668748855591e-01
    z[2,3,3]  R1036     -4.7412046790122986e-01
    z[2,3,3]  R1037     -4.2067438364028931e-01
    z[2,3,3]  R1038     -4.8991143703460693e-01
    z[2,3,3]  R1039     -2.5718429684638977e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R894      -1
    z[2,3,4]  R895      1
    z[2,3,4]  R900      6.0182854533195496e-02
    z[2,3,4]  R901      0.334433376789093
    z[2,3,4]  R902      3.5058698058128357e-01
    z[2,3,4]  R903      -1.5981499850749969e-01
    z[2,3,4]  R904      4.5273166894912720e-01
    z[2,3,4]  R905      7.1975603699684143e-02
    z[2,3,4]  R906      2.0932009816169739e-01
    z[2,3,4]  R907      4.3899127840995789e-01
    z[2,3,4]  R908      4.7448903322219849e-01
    z[2,3,4]  R909      1.0534477978944778e-01
    z[2,3,4]  R910      -2.8116098046302795e-01
    z[2,3,4]  R911      -3.7564691901206970e-01
    z[2,3,4]  R912      -2.3733133077621460e-01
    z[2,3,4]  R913      4.0176185965538025e-01
    z[2,3,4]  R914      -3.4186564385890961e-02
    z[2,3,4]  R915      -2.3181053996086121e-01
    z[2,3,4]  R916      -1.7737166583538055e-01
    z[2,3,4]  R917      1.1563534289598465e-01
    z[2,3,4]  R918      -0.551505982875824
    z[2,3,4]  R919      3.9585113525390625e-01
    z[2,3,4]  R920      1.0906083509325981e-02
    z[2,3,4]  R921      -3.6826786398887634e-01
    z[2,3,4]  R922      -6.5377938747406006e-01
    z[2,3,4]  R923      -7.1659630537033081e-01
    z[2,3,4]  R924      -5.6170392036437988e-01
    z[2,3,4]  R925      -6.2472081184387207e-01
    z[2,3,4]  R926      -0.252750426530838
    z[2,3,4]  R927      -6.1852902173995972e-01
    z[2,3,4]  R928      -7.0063984394073486e-01
    z[2,3,4]  R929      -6.9972926378250122e-01
    z[2,3,4]  R930      2.1617035567760468e-01
    z[2,3,4]  R931      -1.0089616477489471e-01
    z[2,3,4]  R932      3.2417541742324829e-01
    z[2,3,4]  R933      -2.3014199733734131e-01
    z[2,3,4]  R934      -3.6255308985710144e-01
    z[2,3,4]  R935      1.5050463378429413e-01
    z[2,3,4]  R936      2.3566101491451263e-01
    z[2,3,4]  R937      2.0459690690040588e-01
    z[2,3,4]  R938      -4.9369612336158752e-01
    z[2,3,4]  R939      1.3406861573457718e-02
    z[2,3,4]  R940      7.9505115747451782e-02
    z[2,3,4]  R941      -4.9428895115852356e-01
    z[2,3,4]  R942      -0.0761650800704956
    z[2,3,4]  R943      -2.6672041416168213e-01
    z[2,3,4]  R944      3.6464941501617432e-01
    z[2,3,4]  R945      -2.1595989167690277e-01
    z[2,3,4]  R946      -6.0959827899932861e-01
    z[2,3,4]  R947      3.5240563750267029e-01
    z[2,3,4]  R948      1.9147807359695435e-01
    z[2,3,4]  R949      -9.4949059188365936e-02
    z[2,3,4]  R950      -4.2940896749496460e-01
    z[2,3,4]  R951      2.9315361380577087e-01
    z[2,3,4]  R952      -0.0841350331902504
    z[2,3,4]  R953      1.3752470910549164e-01
    z[2,3,4]  R954      1.0821728408336639e-01
    z[2,3,4]  R955      -3.8458526134490967e-02
    z[2,3,4]  R956      7.3545169830322266e-01
    z[2,3,4]  R957      -2.6146358251571655e-01
    z[2,3,4]  R958      2.3412831127643585e-02
    z[2,3,4]  R959      4.8646613955497742e-02
    z[2,3,4]  R960      1.9688895344734192e-01
    z[2,3,4]  R961      -2.6365187764167786e-01
    z[2,3,4]  R962      1.6216847300529480e-01
    z[2,3,4]  R963      1.0183297097682953e-01
    z[2,3,4]  R964      3.6613830924034119e-01
    z[2,3,4]  R965      2.5276171043515205e-02
    z[2,3,4]  R966      3.9034810662269592e-01
    z[2,3,4]  R967      -5.8465617895126343e-01
    z[2,3,4]  R968      -5.4090458154678345e-01
    z[2,3,4]  R969      -2.1702301502227783e-01
    z[2,3,4]  R970      -2.1139633655548096e-01
    z[2,3,4]  R971      -5.1421147584915161e-01
    z[2,3,4]  R972      3.8064935803413391e-01
    z[2,3,4]  R973      2.8179755806922913e-01
    z[2,3,4]  R974      1.6003543511033058e-02
    z[2,3,4]  R975      -2.0782912150025368e-02
    z[2,3,4]  R976      2.2558422386646271e-01
    z[2,3,4]  R977      -1.8514131009578705e-01
    z[2,3,4]  R978      2.2753329575061798e-01
    z[2,3,4]  R979      5.2067141979932785e-02
    z[2,3,4]  R980      3.4688645601272583e-01
    z[2,3,4]  R981      5.9636777639389038e-01
    z[2,3,4]  R982      1.8472562730312347e-01
    z[2,3,4]  R983      -5.8635283261537552e-02
    z[2,3,4]  R984      -2.3713652789592743e-01
    z[2,3,4]  R985      4.5625463128089905e-01
    z[2,3,4]  R986      1.0159126482903957e-02
    z[2,3,4]  R987      1.3070702552795410e-01
    z[2,3,4]  R988      -1.1682728677988052e-01
    z[2,3,4]  R989      -4.6683631837368011e-02
    z[2,3,4]  R990      3.4998500347137451e-01
    z[2,3,4]  R991      1.3148643076419830e-01
    z[2,3,4]  R992      5.9449046850204468e-01
    z[2,3,4]  R993      -4.5888105034828186e-01
    z[2,3,4]  R994      3.9809507131576538e-01
    z[2,3,4]  R995      -6.9887173175811768e-01
    z[2,3,4]  R996      3.2974988222122192e-01
    z[2,3,4]  R997      4.0062639117240906e-01
    z[2,3,4]  R998      1.9780324399471283e-01
    z[2,3,4]  R999      -5.7936644554138184e-01
    z[2,3,4]  R1000     -0.341208279132843
    z[2,3,4]  R1001     -2.5814184546470642e-01
    z[2,3,4]  R1002     2.8583295643329620e-03
    z[2,3,4]  R1003     5.9135907888412476e-01
    z[2,3,4]  R1004     2.5743296742439270e-01
    z[2,3,4]  R1005     -5.7720959186553955e-01
    z[2,3,4]  R1006     -5.6938838958740234e-01
    z[2,3,4]  R1007     6.3056260347366333e-01
    z[2,3,4]  R1008     0.110362209379673
    z[2,3,4]  R1009     6.8434321880340576e-01
    z[2,3,4]  R1010     -1.5113914012908936e-01
    z[2,3,4]  R1011     2.0056955516338348e-01
    z[2,3,4]  R1012     4.2378431558609009e-01
    z[2,3,4]  R1013     5.9284854680299759e-02
    z[2,3,4]  R1014     2.3376183211803436e-01
    z[2,3,4]  R1015     1.8640869855880737e-01
    z[2,3,4]  R1016     5.0026741810142994e-03
    z[2,3,4]  R1017     -0.529833972454071
    z[2,3,4]  R1018     -2.1755275130271912e-01
    z[2,3,4]  R1019     3.9323933422565460e-02
    z[2,3,4]  R1020     -2.9293003678321838e-01
    z[2,3,4]  R1021     1.9246637821197510e-01
    z[2,3,4]  R1022     4.1980087757110596e-01
    z[2,3,4]  R1023     -0.105362668633461
    z[2,3,4]  R1024     -9.4741076231002808e-02
    z[2,3,4]  R1025     2.9477930068969727e-01
    z[2,3,4]  R1026     6.4331911504268646e-02
    z[2,3,4]  R1027     -3.6906756460666656e-02
    z[2,3,4]  R1028     -5.6205880641937256e-01
    z[2,3,4]  R1029     -5.7529205083847046e-01
    z[2,3,4]  R1030     -1.3045415282249451e-01
    z[2,3,4]  R1031     -4.6280416846275330e-01
    z[2,3,4]  R1032     6.5524756908416748e-01
    z[2,3,4]  R1033     1.6345609724521637e-01
    z[2,3,4]  R1034     -1.2294919788837433e-01
    z[2,3,4]  R1035     -8.3895868062973022e-01
    z[2,3,4]  R1036     -8.0667078495025635e-01
    z[2,3,4]  R1037     -7.0341515541076660e-01
    z[2,3,4]  R1038     -6.1113911867141724e-01
    z[2,3,4]  R1039     -6.0859465599060059e-01
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R896      -1
    z[2,3,5]  R897      1
    z[2,3,5]  R900      -4.0111333131790161e-02
    z[2,3,5]  R901      -2.9458436369895935e-01
    z[2,3,5]  R902      -1.7900609970092773e-01
    z[2,3,5]  R903      -2.3825907707214355e-01
    z[2,3,5]  R904      1.9674451649188995e-01
    z[2,3,5]  R905      -1.5321678481996059e-02
    z[2,3,5]  R906      1.6504010185599327e-02
    z[2,3,5]  R907      -5.1086336374282837e-02
    z[2,3,5]  R908      -2.1501930430531502e-02
    z[2,3,5]  R909      -2.1900095045566559e-01
    z[2,3,5]  R910      -3.8801664113998413e-01
    z[2,3,5]  R911      2.5432538986206055e-01
    z[2,3,5]  R912      7.7942825853824615e-02
    z[2,3,5]  R913      4.9140501767396927e-02
    z[2,3,5]  R914      7.6111115515232086e-02
    z[2,3,5]  R915      2.5701296329498291e-01
    z[2,3,5]  R916      -8.5745364427566528e-02
    z[2,3,5]  R917      -1.9198076426982880e-01
    z[2,3,5]  R918      -9.8238639533519745e-02
    z[2,3,5]  R919      -1.8779900670051575e-01
    z[2,3,5]  R920      9.1455176472663879e-02
    z[2,3,5]  R921      5.8820914477109909e-02
    z[2,3,5]  R922      3.6578190326690674e-01
    z[2,3,5]  R923      3.0248314142227173e-01
    z[2,3,5]  R924      3.5836723446846008e-01
    z[2,3,5]  R925      2.0174258947372437e-01
    z[2,3,5]  R926      2.4466985464096069e-01
    z[2,3,5]  R927      1.2938182055950165e-01
    z[2,3,5]  R928      0.203104168176651
    z[2,3,5]  R929      1.5726454555988312e-01
    z[2,3,5]  R930      2.4988044798374176e-01
    z[2,3,5]  R931      -1.2344833463430405e-01
    z[2,3,5]  R932      1.9207081198692322e-01
    z[2,3,5]  R933      1.0046100616455078e-01
    z[2,3,5]  R934      -9.2327609658241272e-02
    z[2,3,5]  R935      -1.4799048006534576e-01
    z[2,3,5]  R936      4.6228629350662231e-01
    z[2,3,5]  R937      -4.0209221839904785e-01
    z[2,3,5]  R938      2.8853037953376770e-01
    z[2,3,5]  R939      3.7438431382179260e-01
    z[2,3,5]  R940      3.8681104779243469e-01
    z[2,3,5]  R941      -3.5120215266942978e-02
    z[2,3,5]  R942      1.3741073012351990e-01
    z[2,3,5]  R943      2.6251502335071564e-02
    z[2,3,5]  R944      -3.3485063910484314e-01
    z[2,3,5]  R945      5.3847837448120117e-01
    z[2,3,5]  R946      6.3186037540435791e-01
    z[2,3,5]  R947      3.7381444126367569e-02
    z[2,3,5]  R948      9.3511477112770081e-02
    z[2,3,5]  R949      0.371217280626297
    z[2,3,5]  R950      3.6413182970136404e-03
    z[2,3,5]  R951      -2.0216912031173706e-01
    z[2,3,5]  R952      1.0431414842605591e-01
    z[2,3,5]  R953      1.1590618640184402e-02
    z[2,3,5]  R954      -7.2658024728298187e-02
    z[2,3,5]  R955      -6.2452876567840576e-01
    z[2,3,5]  R956      3.4534335136413574e-01
    z[2,3,5]  R957      -1.0845420509576797e-01
    z[2,3,5]  R958      -6.4834314584732056e-01
    z[2,3,5]  R959      -4.9363338947296143e-01
    z[2,3,5]  R960      0.472953200340271
    z[2,3,5]  R961      7.3955051600933075e-02
    z[2,3,5]  R962      5.4328376054763794e-01
    z[2,3,5]  R963      3.9821276068687439e-01
    z[2,3,5]  R964      -1.3570861518383026e-01
    z[2,3,5]  R965      -2.8387421369552612e-01
    z[2,3,5]  R966      1.7517729103565216e-01
    z[2,3,5]  R967      5.7705128192901611e-01
    z[2,3,5]  R968      4.4803205132484436e-01
    z[2,3,5]  R969      -4.0736470371484756e-02
    z[2,3,5]  R970      -3.5944998264312744e-02
    z[2,3,5]  R971      6.0712260007858276e-01
    z[2,3,5]  R972      2.9833678156137466e-02
    z[2,3,5]  R973      -2.2303852438926697e-01
    z[2,3,5]  R974      -4.6621689200401306e-01
    z[2,3,5]  R975      7.1863436698913574e-01
    z[2,3,5]  R976      -3.0003547668457031e-01
    z[2,3,5]  R977      -4.7163897752761841e-01
    z[2,3,5]  R978      1.7729481682181358e-02
    z[2,3,5]  R979      -9.3078408390283585e-03
    z[2,3,5]  R980      -0.553044319152832
    z[2,3,5]  R981      -4.2993504554033279e-02
    z[2,3,5]  R982      1.1749506741762161e-01
    z[2,3,5]  R983      1.4075703918933868e-01
    z[2,3,5]  R984      3.2285955548286438e-01
    z[2,3,5]  R985      7.0158019661903381e-02
    z[2,3,5]  R986      -1.0275598615407944e-01
    z[2,3,5]  R987      0.0361696258187294
    z[2,3,5]  R988      -3.3468861132860184e-02
    z[2,3,5]  R989      1.3391450047492981e-01
    z[2,3,5]  R990      2.3491376638412476e-01
    z[2,3,5]  R991      5.3270930051803589e-01
    z[2,3,5]  R992      4.1350486874580383e-01
    z[2,3,5]  R993      -4.1556110978126526e-01
    z[2,3,5]  R994      6.7152678966522217e-01
    z[2,3,5]  R995      -0.263075053691864
    z[2,3,5]  R996      5.5658805370330811e-01
    z[2,3,5]  R997      5.5850416421890259e-01
    z[2,3,5]  R998      5.6426358222961426e-01
    z[2,3,5]  R999      -3.5225117206573486e-01
    z[2,3,5]  R1000     -5.2893179655075073e-01
    z[2,3,5]  R1001     1.7745985090732574e-01
    z[2,3,5]  R1002     3.4801909327507019e-01
    z[2,3,5]  R1003     2.7866625785827637e-01
    z[2,3,5]  R1004     4.0741279721260071e-01
    z[2,3,5]  R1005     2.2728929296135902e-02
    z[2,3,5]  R1006     -2.8804320096969604e-01
    z[2,3,5]  R1007     5.1546716690063477e-01
    z[2,3,5]  R1008     6.7101502418518066e-01
    z[2,3,5]  R1009     5.8186775445938110e-01
    z[2,3,5]  R1010     -1.0468350723385811e-02
    z[2,3,5]  R1011     5.1003140211105347e-01
    z[2,3,5]  R1012     6.9440108537673950e-01
    z[2,3,5]  R1013     5.5458873510360718e-01
    z[2,3,5]  R1014     0.413343220949173
    z[2,3,5]  R1015     2.9687958955764771e-01
    z[2,3,5]  R1016     -2.5644791126251221e-01
    z[2,3,5]  R1017     -6.2193788588047028e-02
    z[2,3,5]  R1018     -2.6785546541213989e-01
    z[2,3,5]  R1019     3.3473879098892212e-01
    z[2,3,5]  R1020     -4.3114152550697327e-01
    z[2,3,5]  R1021     8.2911419868469238e-01
    z[2,3,5]  R1022     2.9068300127983093e-01
    z[2,3,5]  R1023     2.2954536974430084e-01
    z[2,3,5]  R1024     2.1932075917720795e-01
    z[2,3,5]  R1025     2.2315025329589844e-01
    z[2,3,5]  R1026     2.0577101409435272e-01
    z[2,3,5]  R1027     3.7524858117103577e-01
    z[2,3,5]  R1028     5.0734555721282959e-01
    z[2,3,5]  R1029     4.7492590546607971e-01
    z[2,3,5]  R1030     -2.1041874587535858e-01
    z[2,3,5]  R1031     -2.5743770599365234e-01
    z[2,3,5]  R1032     1.7963384091854095e-01
    z[2,3,5]  R1033     2.0145660638809204e-01
    z[2,3,5]  R1034     -7.7882564067840576e-01
    z[2,3,5]  R1035     3.7007558345794678e-01
    z[2,3,5]  R1036     1.8400555849075317e-01
    z[2,3,5]  R1037     3.5417270660400391e-01
    z[2,3,5]  R1038     4.2507287859916687e-01
    z[2,3,5]  R1039     6.5993052721023560e-01
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R898      -1
    z[2,3,6]  R899      1
    z[2,3,6]  R900      -1.7198163270950317e-01
    z[2,3,6]  R901      9.7616732120513916e-02
    z[2,3,6]  R902      8.6575500667095184e-02
    z[2,3,6]  R903      2.6357337832450867e-01
    z[2,3,6]  R904      9.2977419495582581e-02
    z[2,3,6]  R905      1.7765671014785767e-01
    z[2,3,6]  R906      0.538210928440094
    z[2,3,6]  R907      -9.9790245294570923e-02
    z[2,3,6]  R908      0.267120897769928
    z[2,3,6]  R909      -7.2021287679672241e-01
    z[2,3,6]  R910      1.5352459251880646e-01
    z[2,3,6]  R911      0.329188734292984
    z[2,3,6]  R912      2.3916792869567871e-01
    z[2,3,6]  R913      -1.8713575601577759e-01
    z[2,3,6]  R914      4.9038669466972351e-01
    z[2,3,6]  R915      -2.7009156346321106e-01
    z[2,3,6]  R916      5.6678575277328491e-01
    z[2,3,6]  R917      3.7452098727226257e-01
    z[2,3,6]  R918      1.6239304840564728e-01
    z[2,3,6]  R919      3.7542721629142761e-01
    z[2,3,6]  R920      -5.5112581700086594e-02
    z[2,3,6]  R921      -4.4175809621810913e-01
    z[2,3,6]  R922      2.0904199779033661e-01
    z[2,3,6]  R923      -3.4600594639778137e-01
    z[2,3,6]  R924      1.0638792812824249e-01
    z[2,3,6]  R925      5.7504154741764069e-02
    z[2,3,6]  R926      7.3766849935054779e-02
    z[2,3,6]  R927      3.7288421392440796e-01
    z[2,3,6]  R928      -3.0995625257492065e-01
    z[2,3,6]  R929      -2.8730648756027222e-01
    z[2,3,6]  R930      -3.0975034832954407e-01
    z[2,3,6]  R931      2.0896416902542114e-01
    z[2,3,6]  R932      1.2505804002285004e-01
    z[2,3,6]  R933      -5.4767656326293945e-01
    z[2,3,6]  R934      -5.5913275480270386e-01
    z[2,3,6]  R935      -2.9187005758285522e-01
    z[2,3,6]  R936      5.7579171657562256e-01
    z[2,3,6]  R937      -4.8718109726905823e-01
    z[2,3,6]  R938      -5.5757766962051392e-01
    z[2,3,6]  R939      1.5979956090450287e-01
    z[2,3,6]  R940      1.1773577332496643e-01
    z[2,3,6]  R941      -1.1788261681795120e-01
    z[2,3,6]  R942      3.7980252504348755e-01
    z[2,3,6]  R943      -1.0959913581609726e-01
    z[2,3,6]  R944      -1.5310059487819672e-01
    z[2,3,6]  R945      -7.4085518717765808e-02
    z[2,3,6]  R946      -1.8072827160358429e-01
    z[2,3,6]  R947      -4.6383801102638245e-01
    z[2,3,6]  R948      1.4695416390895844e-01
    z[2,3,6]  R949      2.5241279974579811e-02
    z[2,3,6]  R950      -2.5018927454948425e-01
    z[2,3,6]  R951      -3.3541226387023926e-01
    z[2,3,6]  R952      3.1361293792724609e-01
    z[2,3,6]  R953      2.8857663273811340e-01
    z[2,3,6]  R954      -2.0775970816612244e-01
    z[2,3,6]  R955      4.2690834403038025e-01
    z[2,3,6]  R956      -2.1375331282615662e-01
    z[2,3,6]  R957      1.6016711294651031e-01
    z[2,3,6]  R958      8.2306535914540291e-03
    z[2,3,6]  R959      1.4425319433212280e-01
    z[2,3,6]  R960      5.8335000276565552e-01
    z[2,3,6]  R961      -2.3129422962665558e-01
    z[2,3,6]  R962      1.6793212294578552e-01
    z[2,3,6]  R963      -3.8830515742301941e-01
    z[2,3,6]  R964      -3.7465396523475647e-01
    z[2,3,6]  R965      5.2417159080505371e-02
    z[2,3,6]  R966      -0.200520858168602
    z[2,3,6]  R967      2.5251591205596924e-01
    z[2,3,6]  R968      -0.011157201603055
    z[2,3,6]  R969      4.9335334450006485e-02
    z[2,3,6]  R970      -4.9009706825017929e-02
    z[2,3,6]  R971      1.0897734016180038e-01
    z[2,3,6]  R972      -2.9252591729164124e-01
    z[2,3,6]  R973      9.0420506894588470e-02
    z[2,3,6]  R974      -2.0941365510225296e-02
    z[2,3,6]  R975      -4.7655689716339111e-01
    z[2,3,6]  R976      -3.7927865982055664e-01
    z[2,3,6]  R977      0.0328315831720829
    z[2,3,6]  R978      -1.6944380104541779e-01
    z[2,3,6]  R979      -7.0934578776359558e-02
    z[2,3,6]  R980      2.2468097507953644e-01
    z[2,3,6]  R981      -3.2996791601181030e-01
    z[2,3,6]  R982      1.4762161672115326e-01
    z[2,3,6]  R983      -4.5040425658226013e-01
    z[2,3,6]  R984      1.3805608265101910e-02
    z[2,3,6]  R985      5.8425735682249069e-02
    z[2,3,6]  R986      3.9670267701148987e-01
    z[2,3,6]  R987      0.537770688533783
    z[2,3,6]  R988      -1.8344806134700775e-01
    z[2,3,6]  R989      -8.5710622370243073e-02
    z[2,3,6]  R990      -3.8023035973310471e-02
    z[2,3,6]  R991      -0.269378125667572
    z[2,3,6]  R992      -2.0136094093322754e-01
    z[2,3,6]  R993      -1.4751872420310974e-01
    z[2,3,6]  R994      -2.1189206838607788e-01
    z[2,3,6]  R995      -1.0805781185626984e-01
    z[2,3,6]  R996      -5.5326286703348160e-02
    z[2,3,6]  R997      -2.1189002692699432e-01
    z[2,3,6]  R998      4.6170207858085632e-01
    z[2,3,6]  R999      -1.9464819133281708e-01
    z[2,3,6]  R1000     4.3017691373825073e-01
    z[2,3,6]  R1001     -1.5040473639965057e-01
    z[2,3,6]  R1002     6.3325248658657074e-02
    z[2,3,6]  R1003     1.1317790299654007e-01
    z[2,3,6]  R1004     1.9343329966068268e-01
    z[2,3,6]  R1005     -7.9061530530452728e-02
    z[2,3,6]  R1006     -9.6641272306442261e-02
    z[2,3,6]  R1007     -1.0856087505817413e-01
    z[2,3,6]  R1008     -1.6978496313095093e-01
    z[2,3,6]  R1009     -2.2336056455969810e-02
    z[2,3,6]  R1010     -1.4777894318103790e-01
    z[2,3,6]  R1011     9.7572272352408618e-05
    z[2,3,6]  R1012     -1.1589463800191879e-01
    z[2,3,6]  R1013     2.8197151422500610e-01
    z[2,3,6]  R1014     2.7002471685409546e-01
    z[2,3,6]  R1015     8.2531832158565521e-02
    z[2,3,6]  R1016     -1.7834395170211792e-02
    z[2,3,6]  R1017     1.0257884860038757e-01
    z[2,3,6]  R1018     3.3247941732406616e-01
    z[2,3,6]  R1019     3.5234186798334122e-02
    z[2,3,6]  R1020     0.0984724834561348
    z[2,3,6]  R1021     1.1448633670806885e-01
    z[2,3,6]  R1022     7.1404480934143066e-01
    z[2,3,6]  R1023     -1.8833881616592407e-01
    z[2,3,6]  R1024     -7.0366062223911285e-02
    z[2,3,6]  R1025     6.7802697420120239e-02
    z[2,3,6]  R1026     1.1730934679508209e-01
    z[2,3,6]  R1027     -6.0412295162677765e-02
    z[2,3,6]  R1028     -2.2613309323787689e-01
    z[2,3,6]  R1029     2.3787630721926689e-02
    z[2,3,6]  R1030     7.1329828351736069e-03
    z[2,3,6]  R1031     -7.9224541783332825e-02
    z[2,3,6]  R1032     4.9727505445480347e-01
    z[2,3,6]  R1033     -1.5995460748672485e-01
    z[2,3,6]  R1034     -5.7356536388397217e-01
    z[2,3,6]  R1035     1.2033274024724960e-01
    z[2,3,6]  R1036     -7.1916177868843079e-02
    z[2,3,6]  R1037     -3.6164382100105286e-01
    z[2,3,6]  R1038     -3.1468236446380615e-01
    z[2,3,6]  R1039     -1.3965220749378204e-01
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R1040     -1
    z[3,2,0]  R1041     1
    z[3,2,0]  R1054     3.8435712456703186e-01
    z[3,2,0]  R1055     4.6964627504348755e-01
    z[3,2,0]  R1056     1.2871317565441132e-01
    z[3,2,0]  R1057     3.3063021302223206e-01
    z[3,2,0]  R1058     -1.5768514573574066e-01
    z[3,2,0]  R1059     -6.0754650831222534e-01
    z[3,2,0]  R1060     -4.4395166635513306e-01
    z[3,2,0]  R1061     -1.7489361763000488e-01
    z[3,2,0]  R1062     -6.6080474853515625e-01
    z[3,2,0]  R1063     -6.0426956415176392e-01
    z[3,2,0]  R1064     -3.8641926646232605e-01
    z[3,2,0]  R1065     -2.2747081518173218e-01
    z[3,2,0]  R1066     -1.8546903133392334e-01
    z[3,2,0]  R1067     -2.2525892127305269e-03
    z[3,2,0]  R1068     -3.2109636068344116e-01
    z[3,2,0]  R1069     -2.2801786661148071e-02
    z[3,2,0]  R1070     -5.9258061647415161e-01
    z[3,2,0]  R1071     -3.0523759126663208e-01
    z[3,2,0]  R1072     -4.9144953489303589e-01
    z[3,2,0]  R1073     3.5981366038322449e-01
    z[3,2,0]  R1074     4.6973848342895508e-01
    z[3,2,0]  R1075     3.7984788417816162e-01
    z[3,2,0]  R1076     3.2363331317901611e-01
    z[3,2,0]  R1077     -1.0073760896921158e-01
    z[3,2,0]  R1078     -5.3915452957153320e-01
    z[3,2,0]  R1079     0.573432981967926
    z[3,2,0]  R1080     5.8630925416946411e-01
    z[3,2,0]  R1081     6.3679113984107971e-02
    z[3,2,0]  R1082     1.5071780420839787e-02
    z[3,2,0]  R1083     1.0220363736152649e-01
    z[3,2,0]  R1084     7.9044562578201294e-01
    z[3,2,0]  R1085     -8.5493430495262146e-02
    z[3,2,0]  R1086     -2.8234678506851196e-01
    z[3,2,0]  R1087     -1.1949960142374039e-01
    z[3,2,0]  R1088     -4.2563432455062866e-01
    z[3,2,0]  R1089     -3.5032281279563904e-01
    z[3,2,0]  R1090     -2.7937644720077515e-01
    z[3,2,0]  R1091     -3.0842721462249756e-01
    z[3,2,0]  R1092     -6.1874139308929443e-01
    z[3,2,0]  R1093     -4.4269609451293945e-01
    z[3,2,0]  R1094     1.0344447195529938e-01
    z[3,2,0]  R1095     -9.6073616296052933e-03
    z[3,2,0]  R1096     -3.5229781270027161e-01
    z[3,2,0]  R1097     2.1113598719239235e-02
    z[3,2,0]  R1098     -1.6194912791252136e-01
    z[3,2,0]  R1099     1.4746780693531036e-01
    z[3,2,0]  R1100     -3.9892011880874634e-01
    z[3,2,0]  R1101     -2.4754211306571960e-01
    z[3,2,0]  R1102     -5.6692034006118774e-01
    z[3,2,0]  R1103     -6.1223447322845459e-01
    z[3,2,0]  R1104     -8.9415594935417175e-02
    z[3,2,0]  R1105     5.4197525978088379e-01
    z[3,2,0]  R1106     -3.4987998008728027e-01
    z[3,2,0]  R1107     -5.3841060400009155e-01
    z[3,2,0]  R1108     1.6175134107470512e-02
    z[3,2,0]  R1109     1.9008865579962730e-02
    z[3,2,0]  R1110     -1.1379750072956085e-01
    z[3,2,0]  R1111     8.3032414317131042e-02
    z[3,2,0]  R1112     -6.1901800334453583e-02
    z[3,2,0]  R1113     2.9676225781440735e-01
    z[3,2,0]  R1114     -4.1689458489418030e-01
    z[3,2,0]  R1115     -4.8468196392059326e-01
    z[3,2,0]  R1116     -5.7306480407714844e-01
    z[3,2,0]  R1117     -3.4239238500595093e-01
    z[3,2,0]  R1118     -6.0957503318786621e-01
    z[3,2,0]  R1119     -3.2015225291252136e-01
    z[3,2,0]  R1120     -3.0857360363006592e-01
    z[3,2,0]  R1121     -3.9235708117485046e-01
    z[3,2,0]  R1122     -3.4801444411277771e-01
    z[3,2,0]  R1123     3.6987990140914917e-02
    z[3,2,0]  R1124     3.7160363048315048e-02
    z[3,2,0]  R1125     4.9446426331996918e-02
    z[3,2,0]  R1126     9.2987410724163055e-02
    z[3,2,0]  R1127     1.6451187431812286e-01
    z[3,2,0]  R1128     3.8392234593629837e-02
    z[3,2,0]  R1129     2.3820878937840462e-02
    z[3,2,0]  R1130     -3.6871144175529480e-01
    z[3,2,0]  R1131     -1.8168369308114052e-02
    z[3,2,0]  R1132     4.3558844923973083e-01
    z[3,2,0]  R1133     -3.8961544632911682e-02
    z[3,2,0]  R1134     2.1219049394130707e-01
    z[3,2,0]  R1135     1.0946871340274811e-01
    z[3,2,0]  R1136     -1.0069070756435394e-01
    z[3,2,0]  R1137     5.2443742752075195e-02
    z[3,2,0]  R1138     2.7736195921897888e-01
    z[3,2,0]  R1139     -9.2849425971508026e-02
    z[3,2,0]  R1140     -9.0580090880393982e-02
    z[3,2,0]  R1141     -1.5218126773834229e-01
    z[3,2,0]  R1142     -3.0100749805569649e-02
    z[3,2,0]  R1143     -3.4075182676315308e-01
    z[3,2,0]  R1144     -1.8804021179676056e-01
    z[3,2,0]  R1145     -1.2020721286535263e-01
    z[3,2,0]  R1146     1.3284712098538876e-02
    z[3,2,0]  R1147     -1.1131456494331360e-01
    z[3,2,0]  R1148     -1.0430975258350372e-01
    z[3,2,0]  R1149     -2.2587503492832184e-01
    z[3,2,0]  R1150     -1.0576321184635162e-01
    z[3,2,0]  R1151     -2.6120189577341080e-02
    z[3,2,0]  R1152     8.6152262985706329e-02
    z[3,2,0]  R1153     1.7868988215923309e-01
    z[3,2,0]  R1154     2.1687847375869751e-01
    z[3,2,0]  R1155     -7.6703220605850220e-02
    z[3,2,0]  R1156     -5.7236045598983765e-01
    z[3,2,0]  R1157     3.7944954633712769e-01
    z[3,2,0]  R1158     -1.9736465811729431e-01
    z[3,2,0]  R1159     -3.9486771821975708e-01
    z[3,2,0]  R1160     0.0852629616856575
    z[3,2,0]  R1161     -2.9006785154342651e-01
    z[3,2,0]  R1162     1.5264980494976044e-01
    z[3,2,0]  R1163     2.2403240203857422e-01
    z[3,2,0]  R1164     -2.2230571508407593e-01
    z[3,2,0]  R1165     -3.1105026602745056e-01
    z[3,2,0]  R1166     -5.1620435714721680e-01
    z[3,2,0]  R1167     -1.7105893790721893e-01
    z[3,2,0]  R1168     2.1935540437698364e-01
    z[3,2,0]  R1169     1.0663330322131515e-03
    z[3,2,0]  R1170     -3.1086322665214539e-01
    z[3,2,0]  R1171     4.4636088609695435e-01
    z[3,2,0]  R1172     6.9318538904190063e-01
    z[3,2,0]  R1173     8.1855165958404541e-01
    z[3,2,0]  R1174     4.0272515267133713e-02
    z[3,2,0]  R1175     3.4263002872467041e-01
    z[3,2,0]  R1176     -1.5010145306587219e-01
    z[3,2,0]  R1177     -1.5877915918827057e-01
    z[3,2,0]  R1178     -2.8038141131401062e-01
    z[3,2,0]  R1179     2.9783645272254944e-01
    z[3,2,0]  R1180     -3.5361889004707336e-01
    z[3,2,0]  R1181     -2.7545174956321716e-01
    z[3,2,0]  R1182     -3.9055564999580383e-01
    z[3,2,0]  R1183     3.1482365727424622e-01
    z[3,2,0]  R1184     1.7461758852005005e-01
    z[3,2,0]  R1185     -2.4204730987548828e-01
    z[3,2,0]  R1186     -3.5855054855346680e-01
    z[3,2,0]  R1187     -2.6036825776100159e-01
    z[3,2,0]  R1188     2.1546375751495361e-01
    z[3,2,0]  R1189     6.7238390445709229e-02
    z[3,2,0]  R1190     -2.7760851383209229e-01
    z[3,2,0]  R1191     7.6810318231582642e-01
    z[3,2,0]  R1192     9.5003110170364380e-01
    z[3,2,0]  R1193     9.3456918001174927e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R1042     -1
    z[3,2,1]  R1043     1
    z[3,2,1]  R1054     -3.8943392038345337e-01
    z[3,2,1]  R1055     1.0056421905755997e-01
    z[3,2,1]  R1056     1.5411810576915741e-01
    z[3,2,1]  R1057     -7.9090172052383423e-01
    z[3,2,1]  R1058     -0.0875360444188118
    z[3,2,1]  R1059     -6.2563389539718628e-01
    z[3,2,1]  R1060     -0.704354465007782
    z[3,2,1]  R1061     -7.9132989048957825e-02
    z[3,2,1]  R1062     -6.2296229600906372e-01
    z[3,2,1]  R1063     -6.6563093662261963e-01
    z[3,2,1]  R1064     -4.1182957589626312e-02
    z[3,2,1]  R1065     -3.4564676880836487e-01
    z[3,2,1]  R1066     2.8088864684104919e-01
    z[3,2,1]  R1067     3.0188298225402832e-01
    z[3,2,1]  R1068     6.1274491250514984e-02
    z[3,2,1]  R1069     0.0978856310248375
    z[3,2,1]  R1070     2.0466198027133942e-01
    z[3,2,1]  R1071     6.6788643598556519e-03
    z[3,2,1]  R1072     1.1274852603673935e-01
    z[3,2,1]  R1073     4.3839445710182190e-01
    z[3,2,1]  R1074     3.5533255338668823e-01
    z[3,2,1]  R1075     -6.9836688041687012e-01
    z[3,2,1]  R1076     -3.9601841568946838e-01
    z[3,2,1]  R1077     1.1077233403921127e-01
    z[3,2,1]  R1078     2.0387648046016693e-01
    z[3,2,1]  R1079     -2.1392878890037537e-01
    z[3,2,1]  R1080     3.0866166949272156e-01
    z[3,2,1]  R1081     -1.5111443400382996e-01
    z[3,2,1]  R1082     2.5715095922350883e-02
    z[3,2,1]  R1083     -1.4068578183650970e-01
    z[3,2,1]  R1084     -0.302144318819046
    z[3,2,1]  R1085     3.4736540168523788e-02
    z[3,2,1]  R1086     -1.4574143290519714e-01
    z[3,2,1]  R1087     -2.2250409424304962e-01
    z[3,2,1]  R1088     -4.6310713887214661e-01
    z[3,2,1]  R1089     2.1093061566352844e-01
    z[3,2,1]  R1090     -8.5881382226943970e-01
    z[3,2,1]  R1091     -4.4231769442558289e-01
    z[3,2,1]  R1092     -0.606364369392395
    z[3,2,1]  R1093     -7.1295052766799927e-01
    z[3,2,1]  R1094     7.0980495214462280e-01
    z[3,2,1]  R1095     -4.2589294910430908e-01
    z[3,2,1]  R1096     -1.5035982429981232e-01
    z[3,2,1]  R1097     9.3660390377044678e-01
    z[3,2,1]  R1098     9.3908828496932983e-01
    z[3,2,1]  R1099     8.6301565170288086e-01
    z[3,2,1]  R1100     5.0970077514648438e-01
    z[3,2,1]  R1101     7.0335948467254639e-01
    z[3,2,1]  R1102     2.9809432104229927e-02
    z[3,2,1]  R1103     -9.8309412598609924e-02
    z[3,2,1]  R1104     6.9336611032485962e-01
    z[3,2,1]  R1105     -6.0947406291961670e-01
    z[3,2,1]  R1106     -2.0571936666965485e-01
    z[3,2,1]  R1107     -7.4226832389831543e-01
    z[3,2,1]  R1108     1.8295995891094208e-01
    z[3,2,1]  R1109     6.1455290764570236e-02
    z[3,2,1]  R1110     1.7191922664642334e-01
    z[3,2,1]  R1111     2.5506317615509033e-01
    z[3,2,1]  R1112     9.5106415450572968e-02
    z[3,2,1]  R1113     -8.0855406820774078e-02
    z[3,2,1]  R1114     -3.3204442262649536e-01
    z[3,2,1]  R1115     -2.5690299272537231e-01
    z[3,2,1]  R1116     -4.6997055411338806e-01
    z[3,2,1]  R1117     -4.6174040436744690e-01
    z[3,2,1]  R1118     -4.8508054018020630e-01
    z[3,2,1]  R1119     -0.602096676826477
    z[3,2,1]  R1120     1.2655800208449364e-02
    z[3,2,1]  R1121     -1.6722084954380989e-02
    z[3,2,1]  R1122     -1.5665067732334137e-01
    z[3,2,1]  R1123     2.9285481572151184e-01
    z[3,2,1]  R1124     7.0536142587661743e-01
    z[3,2,1]  R1125     3.4541028738021851e-01
    z[3,2,1]  R1126     0.516209065914154
    z[3,2,1]  R1127     4.8548287153244019e-01
    z[3,2,1]  R1128     3.3199149370193481e-01
    z[3,2,1]  R1129     5.1212704181671143e-01
    z[3,2,1]  R1130     5.9532564878463745e-01
    z[3,2,1]  R1131     6.3990515470504761e-01
    z[3,2,1]  R1132     4.8651802539825439e-01
    z[3,2,1]  R1133     4.3544858694076538e-01
    z[3,2,1]  R1134     -3.4603667259216309e-01
    z[3,2,1]  R1135     0.720102846622467
    z[3,2,1]  R1136     -4.8885107971727848e-03
    z[3,2,1]  R1137     6.4501903951168060e-02
    z[3,2,1]  R1138     -2.0838995277881622e-01
    z[3,2,1]  R1139     -2.4802862107753754e-01
    z[3,2,1]  R1140     -7.4762886762619019e-01
    z[3,2,1]  R1141     4.9201175570487976e-02
    z[3,2,1]  R1142     3.2671761512756348e-01
    z[3,2,1]  R1143     -1.0198544710874557e-01
    z[3,2,1]  R1144     -2.8616625815629959e-02
    z[3,2,1]  R1145     3.1933152675628662e-01
    z[3,2,1]  R1146     6.5530651807785034e-01
    z[3,2,1]  R1147     -7.6302891969680786e-01
    z[3,2,1]  R1148     -0.713287353515625
    z[3,2,1]  R1149     3.4502479434013367e-01
    z[3,2,1]  R1150     -1.5632529556751251e-01
    z[3,2,1]  R1151     4.4123733043670654e-01
    z[3,2,1]  R1152     -4.0507555007934570e-01
    z[3,2,1]  R1153     -7.1970999240875244e-02
    z[3,2,1]  R1154     -1.0386711359024048e-01
    z[3,2,1]  R1155     -0.826941728591919
    z[3,2,1]  R1156     5.5064874887466431e-01
    z[3,2,1]  R1157     5.6682562828063965e-01
    z[3,2,1]  R1158     -0.637488067150116
    z[3,2,1]  R1159     3.1302982568740845e-01
    z[3,2,1]  R1160     -4.3343013525009155e-01
    z[3,2,1]  R1161     -5.8169806003570557e-01
    z[3,2,1]  R1162     8.8284105062484741e-01
    z[3,2,1]  R1163     7.3823785781860352e-01
    z[3,2,1]  R1164     -7.5214987993240356e-01
    z[3,2,1]  R1165     4.9054896831512451e-01
    z[3,2,1]  R1166     4.3570250272750854e-01
    z[3,2,1]  R1167     9.2652714252471924e-01
    z[3,2,1]  R1168     8.0565035343170166e-01
    z[3,2,1]  R1169     -5.6556481122970581e-01
    z[3,2,1]  R1170     4.0573990345001221e-01
    z[3,2,1]  R1171     6.1703330278396606e-01
    z[3,2,1]  R1172     -1.1697446554899216e-01
    z[3,2,1]  R1173     -1.9792547821998596e-01
    z[3,2,1]  R1174     -1.3860097527503967e-01
    z[3,2,1]  R1175     0.715706467628479
    z[3,2,1]  R1176     6.6889148950576782e-01
    z[3,2,1]  R1177     2.9724597930908203e-01
    z[3,2,1]  R1178     -6.8008792400360107e-01
    z[3,2,1]  R1179     8.8679903745651245e-01
    z[3,2,1]  R1180     -7.1929872035980225e-01
    z[3,2,1]  R1181     -3.0911669135093689e-01
    z[3,2,1]  R1182     3.7147161364555359e-01
    z[3,2,1]  R1183     0.74797123670578
    z[3,2,1]  R1184     7.5768578052520752e-01
    z[3,2,1]  R1185     -3.3206534385681152e-01
    z[3,2,1]  R1186     -7.1302127838134766e-01
    z[3,2,1]  R1187     6.7258435487747192e-01
    z[3,2,1]  R1188     7.0505040884017944e-01
    z[3,2,1]  R1189     -6.5480205230414867e-03
    z[3,2,1]  R1190     -7.0366328954696655e-01
    z[3,2,1]  R1191     -3.0529114603996277e-01
    z[3,2,1]  R1192     1.3688798062503338e-02
    z[3,2,1]  R1193     4.1255757212638855e-02
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R1044     -1
    z[3,2,2]  R1045     1
    z[3,2,2]  R1054     -1.3613632321357727e-01
    z[3,2,2]  R1055     -3.2119369506835938e-01
    z[3,2,2]  R1056     0.11175537109375
    z[3,2,2]  R1057     3.1654998660087585e-02
    z[3,2,2]  R1058     8.4770750999450684e-01
    z[3,2,2]  R1059     -1.4828373491764069e-01
    z[3,2,2]  R1060     2.9359790682792664e-01
    z[3,2,2]  R1061     0.686779260635376
    z[3,2,2]  R1062     -3.4933474659919739e-01
    z[3,2,2]  R1063     -1.5206056833267212e-01
    z[3,2,2]  R1064     1.1364550888538361e-01
    z[3,2,2]  R1065     3.4251266717910767e-01
    z[3,2,2]  R1066     8.4152139723300934e-02
    z[3,2,2]  R1067     -7.0116829872131348e-01
    z[3,2,2]  R1068     0.310958594083786
    z[3,2,2]  R1069     -4.8581293225288391e-01
    z[3,2,2]  R1070     1.5351407229900360e-01
    z[3,2,2]  R1071     -2.2517786920070648e-01
    z[3,2,2]  R1072     2.1858850494027138e-02
    z[3,2,2]  R1073     -4.2397168278694153e-01
    z[3,2,2]  R1074     1.2479174137115479e-01
    z[3,2,2]  R1075     4.9236118793487549e-01
    z[3,2,2]  R1076     7.7350640296936035e-01
    z[3,2,2]  R1077     4.2019265890121460e-01
    z[3,2,2]  R1078     3.5428783297538757e-01
    z[3,2,2]  R1079     3.6612513661384583e-01
    z[3,2,2]  R1080     1.0885686427354813e-01
    z[3,2,2]  R1081     5.1020783185958862e-01
    z[3,2,2]  R1082     6.2840634584426880e-01
    z[3,2,2]  R1083     9.5704257488250732e-02
    z[3,2,2]  R1084     4.8155072331428528e-01
    z[3,2,2]  R1085     0.616873025894165
    z[3,2,2]  R1086     4.6412819623947144e-01
    z[3,2,2]  R1087     1.1298055946826935e-01
    z[3,2,2]  R1088     4.5124284923076630e-02
    z[3,2,2]  R1089     6.3735512085258961e-03
    z[3,2,2]  R1090     -2.0513303577899933e-01
    z[3,2,2]  R1091     -1.2549702823162079e-01
    z[3,2,2]  R1092     -1.3414016366004944e-01
    z[3,2,2]  R1093     2.1963019669055939e-01
    z[3,2,2]  R1094     -4.5000827312469482e-01
    z[3,2,2]  R1095     8.7170645594596863e-02
    z[3,2,2]  R1096     2.8488731384277344e-01
    z[3,2,2]  R1097     2.7279371395707130e-02
    z[3,2,2]  R1098     -1.3675086200237274e-01
    z[3,2,2]  R1099     3.0031827092170715e-01
    z[3,2,2]  R1100     -6.9078212976455688e-01
    z[3,2,2]  R1101     -5.2651494741439819e-01
    z[3,2,2]  R1102     2.8083970770239830e-02
    z[3,2,2]  R1103     2.4156154692173004e-01
    z[3,2,2]  R1104     -5.5537432432174683e-01
    z[3,2,2]  R1105     2.1817199885845184e-01
    z[3,2,2]  R1106     2.2642841935157776e-01
    z[3,2,2]  R1107     -1.9141036272048950e-01
    z[3,2,2]  R1108     1.1570196598768234e-01
    z[3,2,2]  R1109     -0.0828382596373558
    z[3,2,2]  R1110     2.0725773274898529e-01
    z[3,2,2]  R1111     8.0018816515803337e-03
    z[3,2,2]  R1112     -3.0644190311431885e-01
    z[3,2,2]  R1113     -1.1769544333219528e-01
    z[3,2,2]  R1114     4.2972904443740845e-01
    z[3,2,2]  R1115     2.9859790205955505e-01
    z[3,2,2]  R1116     -1.4298494160175323e-01
    z[3,2,2]  R1117     1.9827237725257874e-01
    z[3,2,2]  R1118     2.4667717516422272e-01
    z[3,2,2]  R1119     6.6764909029006958e-01
    z[3,2,2]  R1120     0.749691903591156
    z[3,2,2]  R1121     0.794209361076355
    z[3,2,2]  R1122     7.4640804529190063e-01
    z[3,2,2]  R1123     -5.7840985059738159e-01
    z[3,2,2]  R1124     -4.9356621503829956e-01
    z[3,2,2]  R1125     -5.4023534059524536e-01
    z[3,2,2]  R1126     -6.4635413885116577e-01
    z[3,2,2]  R1127     -9.2058137059211731e-02
    z[3,2,2]  R1128     -7.9390835762023926e-01
    z[3,2,2]  R1129     -4.5745104551315308e-01
    z[3,2,2]  R1130     -3.7056869268417358e-01
    z[3,2,2]  R1131     -4.0922570228576660e-01
    z[3,2,2]  R1132     -4.8002764582633972e-01
    z[3,2,2]  R1133     -6.8645268678665161e-01
    z[3,2,2]  R1134     4.0704756975173950e-01
    z[3,2,2]  R1135     -3.5753306746482849e-01
    z[3,2,2]  R1136     -3.2452747225761414e-01
    z[3,2,2]  R1137     -1.6314937174320221e-01
    z[3,2,2]  R1138     1.8298590555787086e-02
    z[3,2,2]  R1139     -2.8553183656185865e-03
    z[3,2,2]  R1140     -4.5324909687042236e-01
    z[3,2,2]  R1141     7.4352012015879154e-03
    z[3,2,2]  R1142     1.7782163619995117e-01
    z[3,2,2]  R1143     9.8059467971324921e-02
    z[3,2,2]  R1144     3.7972810864448547e-01
    z[3,2,2]  R1145     -6.2939512729644775e-01
    z[3,2,2]  R1146     -0.642380952835083
    z[3,2,2]  R1147     -6.9627188146114349e-02
    z[3,2,2]  R1148     -1.6084440052509308e-01
    z[3,2,2]  R1149     -5.4775995016098022e-01
    z[3,2,2]  R1150     -4.4738808274269104e-01
    z[3,2,2]  R1151     -5.5230081081390381e-01
    z[3,2,2]  R1152     4.3478560447692871e-01
    z[3,2,2]  R1153     -5.3456395864486694e-01
    z[3,2,2]  R1154     4.4696268439292908e-01
    z[3,2,2]  R1155     -2.2541087865829468e-01
    z[3,2,2]  R1156     -4.3915849924087524e-01
    z[3,2,2]  R1157     -6.5261960029602051e-01
    z[3,2,2]  R1158     -1.2304015457630157e-01
    z[3,2,2]  R1159     -6.2947779893875122e-01
    z[3,2,2]  R1160     -3.2969605177640915e-02
    z[3,2,2]  R1161     -3.2634842395782471e-01
    z[3,2,2]  R1162     2.6758614182472229e-01
    z[3,2,2]  R1163     4.3983215093612671e-01
    z[3,2,2]  R1164     -9.5280326902866364e-02
    z[3,2,2]  R1165     -0.634859025478363
    z[3,2,2]  R1166     -6.4517909288406372e-01
    z[3,2,2]  R1167     0.0360434390604496
    z[3,2,2]  R1168     4.5218861103057861e-01
    z[3,2,2]  R1169     -1.2078131549060345e-02
    z[3,2,2]  R1170     1.2855865061283112e-01
    z[3,2,2]  R1171     5.5934345722198486e-01
    z[3,2,2]  R1172     -2.0315490663051605e-01
    z[3,2,2]  R1173     -1.4706824719905853e-01
    z[3,2,2]  R1174     1.7670039832592010e-01
    z[3,2,2]  R1175     -4.8426979780197144e-01
    z[3,2,2]  R1176     -2.8648141026496887e-01
    z[3,2,2]  R1177     -6.8398404121398926e-01
    z[3,2,2]  R1178     -5.9787672013044357e-02
    z[3,2,2]  R1179     -1.4526379108428955e-01
    z[3,2,2]  R1180     3.9475105702877045e-02
    z[3,2,2]  R1181     2.5788527727127075e-01
    z[3,2,2]  R1182     -4.6022129058837891e-01
    z[3,2,2]  R1183     5.2115124464035034e-01
    z[3,2,2]  R1184     -2.4724586308002472e-01
    z[3,2,2]  R1185     3.8947898149490356e-01
    z[3,2,2]  R1186     -1.5772011876106262e-01
    z[3,2,2]  R1187     -0.574109673500061
    z[3,2,2]  R1188     -4.5492088794708252e-01
    z[3,2,2]  R1189     4.2822387814521790e-01
    z[3,2,2]  R1190     -2.8702369332313538e-01
    z[3,2,2]  R1191     -0.175094336271286
    z[3,2,2]  R1192     6.2799490988254547e-02
    z[3,2,2]  R1193     2.5760421156883240e-01
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R1046     -1
    z[3,2,3]  R1047     1
    z[3,2,3]  R1054     4.5321959257125854e-01
    z[3,2,3]  R1055     4.4695851206779480e-01
    z[3,2,3]  R1056     9.3673390150070190e-01
    z[3,2,3]  R1057     1.9504196941852570e-01
    z[3,2,3]  R1058     -2.9698863625526428e-01
    z[3,2,3]  R1059     -0.0312623456120491
    z[3,2,3]  R1060     -2.2925306856632233e-01
    z[3,2,3]  R1061     -4.2882928252220154e-01
    z[3,2,3]  R1062     6.9269701838493347e-02
    z[3,2,3]  R1063     3.7578254938125610e-01
    z[3,2,3]  R1064     -8.1052398681640625e-01
    z[3,2,3]  R1065     -5.8123838901519775e-01
    z[3,2,3]  R1066     -0.560954213142395
    z[3,2,3]  R1067     1.1045350879430771e-01
    z[3,2,3]  R1068     -3.7698951363563538e-01
    z[3,2,3]  R1069     4.2962488532066345e-01
    z[3,2,3]  R1070     -4.0225467085838318e-01
    z[3,2,3]  R1071     -5.8202630281448364e-01
    z[3,2,3]  R1072     -4.1785049438476562e-01
    z[3,2,3]  R1073     -3.0952779576182365e-02
    z[3,2,3]  R1074     2.3720730841159821e-01
    z[3,2,3]  R1075     6.9490201771259308e-02
    z[3,2,3]  R1076     1.2240605801343918e-01
    z[3,2,3]  R1077     -6.0070788860321045e-01
    z[3,2,3]  R1078     -0.522066593170166
    z[3,2,3]  R1079     3.8913151621818542e-01
    z[3,2,3]  R1080     3.6415389180183411e-01
    z[3,2,3]  R1081     -1.9415524601936340e-01
    z[3,2,3]  R1082     -3.3607918024063110e-01
    z[3,2,3]  R1083     -3.9141789078712463e-01
    z[3,2,3]  R1084     -8.4982894361019135e-02
    z[3,2,3]  R1085     -5.5730760097503662e-01
    z[3,2,3]  R1086     -9.1690264642238617e-02
    z[3,2,3]  R1087     -7.2996979951858521e-01
    z[3,2,3]  R1088     -5.5128979682922363e-01
    z[3,2,3]  R1089     -0.838477373123169
    z[3,2,3]  R1090     -2.7604243159294128e-01
    z[3,2,3]  R1091     6.3116061687469482e-01
    z[3,2,3]  R1092     -4.3238624930381775e-02
    z[3,2,3]  R1093     3.6420649290084839e-01
    z[3,2,3]  R1094     -3.9759587496519089e-02
    z[3,2,3]  R1095     -2.7081990242004395e-01
    z[3,2,3]  R1096     3.9089463651180267e-02
    z[3,2,3]  R1097     -1.4939683675765991e-01
    z[3,2,3]  R1098     1.0562177002429962e-01
    z[3,2,3]  R1099     4.4475674629211426e-02
    z[3,2,3]  R1100     2.0891658961772919e-01
    z[3,2,3]  R1101     0.14479960501194
    z[3,2,3]  R1102     -2.2908157110214233e-01
    z[3,2,3]  R1103     -8.4188235923647881e-03
    z[3,2,3]  R1104     3.7611511349678040e-01
    z[3,2,3]  R1105     -2.1606069058179855e-02
    z[3,2,3]  R1106     -2.7403208613395691e-01
    z[3,2,3]  R1107     1.7212149500846863e-01
    z[3,2,3]  R1108     4.7052096575498581e-02
    z[3,2,3]  R1109     -3.6566668748855591e-01
    z[3,2,3]  R1110     -4.7412046790122986e-01
    z[3,2,3]  R1111     -4.2067438364028931e-01
    z[3,2,3]  R1112     -4.8991143703460693e-01
    z[3,2,3]  R1113     -2.5718429684638977e-01
    z[3,2,3]  R1114     7.0460617542266846e-01
    z[3,2,3]  R1115     6.3385230302810669e-01
    z[3,2,3]  R1116     5.1752287149429321e-01
    z[3,2,3]  R1117     0.691716730594635
    z[3,2,3]  R1118     -2.8274807333946228e-01
    z[3,2,3]  R1119     2.2858205437660217e-01
    z[3,2,3]  R1120     -9.3946717679500580e-02
    z[3,2,3]  R1121     -9.8623782396316528e-02
    z[3,2,3]  R1122     1.6305133700370789e-02
    z[3,2,3]  R1123     2.3331997916102409e-02
    z[3,2,3]  R1124     6.5564163029193878e-02
    z[3,2,3]  R1125     5.2176183462142944e-01
    z[3,2,3]  R1126     4.3301886320114136e-01
    z[3,2,3]  R1127     -7.2795635461807251e-01
    z[3,2,3]  R1128     1.0284223407506943e-01
    z[3,2,3]  R1129     5.7892650365829468e-01
    z[3,2,3]  R1130     1.1072061210870743e-01
    z[3,2,3]  R1131     4.8190414905548096e-01
    z[3,2,3]  R1132     5.4360177367925644e-02
    z[3,2,3]  R1133     -6.8826384842395782e-02
    z[3,2,3]  R1134     -8.1118786334991455e-01
    z[3,2,3]  R1135     0.0860656350851059
    z[3,2,3]  R1136     -0.528769314289093
    z[3,2,3]  R1137     -4.9167567491531372e-01
    z[3,2,3]  R1138     -6.5119296312332153e-01
    z[3,2,3]  R1139     -7.0396721363067627e-01
    z[3,2,3]  R1140     -3.1340688467025757e-01
    z[3,2,3]  R1141     -6.6030627489089966e-01
    z[3,2,3]  R1142     -4.8219156265258789e-01
    z[3,2,3]  R1143     -5.1669472455978394e-01
    z[3,2,3]  R1144     -0.783909022808075
    z[3,2,3]  R1145     6.4680272340774536e-01
    z[3,2,3]  R1146     1.1100284755229950e-02
    z[3,2,3]  R1147     -1.9375425577163696e-01
    z[3,2,3]  R1148     4.3256103992462158e-02
    z[3,2,3]  R1149     6.3257914781570435e-01
    z[3,2,3]  R1150     -4.0427660942077637e-01
    z[3,2,3]  R1151     2.4229690432548523e-01
    z[3,2,3]  R1152     3.9681177586317062e-02
    z[3,2,3]  R1153     -7.1501910686492920e-01
    z[3,2,3]  R1154     -7.5669950246810913e-01
    z[3,2,3]  R1155     4.7563002444803715e-03
    z[3,2,3]  R1156     8.6002998054027557e-02
    z[3,2,3]  R1157     -1.5803065896034241e-01
    z[3,2,3]  R1158     -5.2056068181991577e-01
    z[3,2,3]  R1159     -8.8108986616134644e-02
    z[3,2,3]  R1160     -1.6161488369107246e-02
    z[3,2,3]  R1161     -3.6090412735939026e-01
    z[3,2,3]  R1162     2.4224698543548584e-01
    z[3,2,3]  R1163     2.5279900431632996e-01
    z[3,2,3]  R1164     3.5884881019592285e-01
    z[3,2,3]  R1165     1.4230453968048096e-01
    z[3,2,3]  R1166     -1.0548471659421921e-01
    z[3,2,3]  R1167     9.3076996505260468e-02
    z[3,2,3]  R1168     1.9540201127529144e-01
    z[3,2,3]  R1169     -3.2591944932937622e-01
    z[3,2,3]  R1170     1.2794514000415802e-01
    z[3,2,3]  R1171     -3.7251997739076614e-02
    z[3,2,3]  R1172     -2.0874477922916412e-01
    z[3,2,3]  R1173     -4.8169005662202835e-02
    z[3,2,3]  R1174     -5.8753520250320435e-01
    z[3,2,3]  R1175     8.5866108536720276e-02
    z[3,2,3]  R1176     3.1356829404830933e-01
    z[3,2,3]  R1177     3.1444475054740906e-01
    z[3,2,3]  R1178     -4.0305379033088684e-01
    z[3,2,3]  R1179     1.4074213802814484e-01
    z[3,2,3]  R1180     -0.36433145403862
    z[3,2,3]  R1181     -1.5327471494674683e-01
    z[3,2,3]  R1182     6.5086834132671356e-02
    z[3,2,3]  R1183     -1.3650661706924438e-01
    z[3,2,3]  R1184     5.3470355272293091e-01
    z[3,2,3]  R1185     -1.8591515719890594e-01
    z[3,2,3]  R1186     -3.2681983709335327e-01
    z[3,2,3]  R1187     -1.1359921097755432e-01
    z[3,2,3]  R1188     1.7740766704082489e-01
    z[3,2,3]  R1189     -2.6093408465385437e-01
    z[3,2,3]  R1190     -2.4626623094081879e-01
    z[3,2,3]  R1191     1.6839888691902161e-01
    z[3,2,3]  R1192     1.1186099052429199e-01
    z[3,2,3]  R1193     2.2514252364635468e-01
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R1048     -1
    z[3,2,4]  R1049     1
    z[3,2,4]  R1054     3.4688645601272583e-01
    z[3,2,4]  R1055     5.9636777639389038e-01
    z[3,2,4]  R1056     1.8472562730312347e-01
    z[3,2,4]  R1057     -5.8635283261537552e-02
    z[3,2,4]  R1058     -2.3713652789592743e-01
    z[3,2,4]  R1059     4.5625463128089905e-01
    z[3,2,4]  R1060     1.0159126482903957e-02
    z[3,2,4]  R1061     1.3070702552795410e-01
    z[3,2,4]  R1062     -1.1682728677988052e-01
    z[3,2,4]  R1063     -4.6683631837368011e-02
    z[3,2,4]  R1064     3.4998500347137451e-01
    z[3,2,4]  R1065     1.3148643076419830e-01
    z[3,2,4]  R1066     5.9449046850204468e-01
    z[3,2,4]  R1067     -4.5888105034828186e-01
    z[3,2,4]  R1068     3.9809507131576538e-01
    z[3,2,4]  R1069     -6.9887173175811768e-01
    z[3,2,4]  R1070     3.2974988222122192e-01
    z[3,2,4]  R1071     4.0062639117240906e-01
    z[3,2,4]  R1072     1.9780324399471283e-01
    z[3,2,4]  R1073     -5.7936644554138184e-01
    z[3,2,4]  R1074     -0.341208279132843
    z[3,2,4]  R1075     -2.5814184546470642e-01
    z[3,2,4]  R1076     2.8583295643329620e-03
    z[3,2,4]  R1077     5.9135907888412476e-01
    z[3,2,4]  R1078     2.5743296742439270e-01
    z[3,2,4]  R1079     -5.7720959186553955e-01
    z[3,2,4]  R1080     -5.6938838958740234e-01
    z[3,2,4]  R1081     6.3056260347366333e-01
    z[3,2,4]  R1082     0.110362209379673
    z[3,2,4]  R1083     6.8434321880340576e-01
    z[3,2,4]  R1084     -1.5113914012908936e-01
    z[3,2,4]  R1085     2.0056955516338348e-01
    z[3,2,4]  R1086     4.2378431558609009e-01
    z[3,2,4]  R1087     5.9284854680299759e-02
    z[3,2,4]  R1088     2.3376183211803436e-01
    z[3,2,4]  R1089     1.8640869855880737e-01
    z[3,2,4]  R1090     5.0026741810142994e-03
    z[3,2,4]  R1091     -0.529833972454071
    z[3,2,4]  R1092     -2.1755275130271912e-01
    z[3,2,4]  R1093     3.9323933422565460e-02
    z[3,2,4]  R1094     -2.9293003678321838e-01
    z[3,2,4]  R1095     1.9246637821197510e-01
    z[3,2,4]  R1096     4.1980087757110596e-01
    z[3,2,4]  R1097     -0.105362668633461
    z[3,2,4]  R1098     -9.4741076231002808e-02
    z[3,2,4]  R1099     2.9477930068969727e-01
    z[3,2,4]  R1100     6.4331911504268646e-02
    z[3,2,4]  R1101     -3.6906756460666656e-02
    z[3,2,4]  R1102     -5.6205880641937256e-01
    z[3,2,4]  R1103     -5.7529205083847046e-01
    z[3,2,4]  R1104     -1.3045415282249451e-01
    z[3,2,4]  R1105     -4.6280416846275330e-01
    z[3,2,4]  R1106     6.5524756908416748e-01
    z[3,2,4]  R1107     1.6345609724521637e-01
    z[3,2,4]  R1108     -1.2294919788837433e-01
    z[3,2,4]  R1109     -8.3895868062973022e-01
    z[3,2,4]  R1110     -8.0667078495025635e-01
    z[3,2,4]  R1111     -7.0341515541076660e-01
    z[3,2,4]  R1112     -6.1113911867141724e-01
    z[3,2,4]  R1113     -6.0859465599060059e-01
    z[3,2,4]  R1114     6.0182854533195496e-02
    z[3,2,4]  R1115     0.334433376789093
    z[3,2,4]  R1116     3.5058698058128357e-01
    z[3,2,4]  R1117     -1.5981499850749969e-01
    z[3,2,4]  R1118     4.5273166894912720e-01
    z[3,2,4]  R1119     7.1975603699684143e-02
    z[3,2,4]  R1120     2.0932009816169739e-01
    z[3,2,4]  R1121     4.3899127840995789e-01
    z[3,2,4]  R1122     4.7448903322219849e-01
    z[3,2,4]  R1123     1.0534477978944778e-01
    z[3,2,4]  R1124     -2.8116098046302795e-01
    z[3,2,4]  R1125     -3.7564691901206970e-01
    z[3,2,4]  R1126     -2.3733133077621460e-01
    z[3,2,4]  R1127     4.0176185965538025e-01
    z[3,2,4]  R1128     -3.4186564385890961e-02
    z[3,2,4]  R1129     -2.3181053996086121e-01
    z[3,2,4]  R1130     -1.7737166583538055e-01
    z[3,2,4]  R1131     1.1563534289598465e-01
    z[3,2,4]  R1132     -0.551505982875824
    z[3,2,4]  R1133     3.9585113525390625e-01
    z[3,2,4]  R1134     1.0906083509325981e-02
    z[3,2,4]  R1135     -3.6826786398887634e-01
    z[3,2,4]  R1136     -6.5377938747406006e-01
    z[3,2,4]  R1137     -7.1659630537033081e-01
    z[3,2,4]  R1138     -5.6170392036437988e-01
    z[3,2,4]  R1139     -6.2472081184387207e-01
    z[3,2,4]  R1140     -0.252750426530838
    z[3,2,4]  R1141     -6.1852902173995972e-01
    z[3,2,4]  R1142     -7.0063984394073486e-01
    z[3,2,4]  R1143     -6.9972926378250122e-01
    z[3,2,4]  R1144     2.1617035567760468e-01
    z[3,2,4]  R1145     -1.0089616477489471e-01
    z[3,2,4]  R1146     3.2417541742324829e-01
    z[3,2,4]  R1147     -2.3014199733734131e-01
    z[3,2,4]  R1148     -3.6255308985710144e-01
    z[3,2,4]  R1149     1.5050463378429413e-01
    z[3,2,4]  R1150     2.3566101491451263e-01
    z[3,2,4]  R1151     2.0459690690040588e-01
    z[3,2,4]  R1152     -4.9369612336158752e-01
    z[3,2,4]  R1153     1.3406861573457718e-02
    z[3,2,4]  R1154     7.9505115747451782e-02
    z[3,2,4]  R1155     -4.9428895115852356e-01
    z[3,2,4]  R1156     -0.0761650800704956
    z[3,2,4]  R1157     -2.6672041416168213e-01
    z[3,2,4]  R1158     3.6464941501617432e-01
    z[3,2,4]  R1159     -2.1595989167690277e-01
    z[3,2,4]  R1160     -6.0959827899932861e-01
    z[3,2,4]  R1161     3.5240563750267029e-01
    z[3,2,4]  R1162     1.9147807359695435e-01
    z[3,2,4]  R1163     -9.4949059188365936e-02
    z[3,2,4]  R1164     -4.2940896749496460e-01
    z[3,2,4]  R1165     2.9315361380577087e-01
    z[3,2,4]  R1166     -0.0841350331902504
    z[3,2,4]  R1167     1.3752470910549164e-01
    z[3,2,4]  R1168     1.0821728408336639e-01
    z[3,2,4]  R1169     -3.8458526134490967e-02
    z[3,2,4]  R1170     7.3545169830322266e-01
    z[3,2,4]  R1171     -2.6146358251571655e-01
    z[3,2,4]  R1172     2.3412831127643585e-02
    z[3,2,4]  R1173     4.8646613955497742e-02
    z[3,2,4]  R1174     1.9688895344734192e-01
    z[3,2,4]  R1175     -2.6365187764167786e-01
    z[3,2,4]  R1176     1.6216847300529480e-01
    z[3,2,4]  R1177     1.0183297097682953e-01
    z[3,2,4]  R1178     3.6613830924034119e-01
    z[3,2,4]  R1179     2.5276171043515205e-02
    z[3,2,4]  R1180     3.9034810662269592e-01
    z[3,2,4]  R1181     -5.8465617895126343e-01
    z[3,2,4]  R1182     -5.4090458154678345e-01
    z[3,2,4]  R1183     -2.1702301502227783e-01
    z[3,2,4]  R1184     -2.1139633655548096e-01
    z[3,2,4]  R1185     -5.1421147584915161e-01
    z[3,2,4]  R1186     3.8064935803413391e-01
    z[3,2,4]  R1187     2.8179755806922913e-01
    z[3,2,4]  R1188     1.6003543511033058e-02
    z[3,2,4]  R1189     -2.0782912150025368e-02
    z[3,2,4]  R1190     2.2558422386646271e-01
    z[3,2,4]  R1191     -1.8514131009578705e-01
    z[3,2,4]  R1192     2.2753329575061798e-01
    z[3,2,4]  R1193     5.2067141979932785e-02
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R1050     -1
    z[3,2,5]  R1051     1
    z[3,2,5]  R1054     -0.553044319152832
    z[3,2,5]  R1055     -4.2993504554033279e-02
    z[3,2,5]  R1056     1.1749506741762161e-01
    z[3,2,5]  R1057     1.4075703918933868e-01
    z[3,2,5]  R1058     3.2285955548286438e-01
    z[3,2,5]  R1059     7.0158019661903381e-02
    z[3,2,5]  R1060     -1.0275598615407944e-01
    z[3,2,5]  R1061     0.0361696258187294
    z[3,2,5]  R1062     -3.3468861132860184e-02
    z[3,2,5]  R1063     1.3391450047492981e-01
    z[3,2,5]  R1064     2.3491376638412476e-01
    z[3,2,5]  R1065     5.3270930051803589e-01
    z[3,2,5]  R1066     4.1350486874580383e-01
    z[3,2,5]  R1067     -4.1556110978126526e-01
    z[3,2,5]  R1068     6.7152678966522217e-01
    z[3,2,5]  R1069     -0.263075053691864
    z[3,2,5]  R1070     5.5658805370330811e-01
    z[3,2,5]  R1071     5.5850416421890259e-01
    z[3,2,5]  R1072     5.6426358222961426e-01
    z[3,2,5]  R1073     -3.5225117206573486e-01
    z[3,2,5]  R1074     -5.2893179655075073e-01
    z[3,2,5]  R1075     1.7745985090732574e-01
    z[3,2,5]  R1076     3.4801909327507019e-01
    z[3,2,5]  R1077     2.7866625785827637e-01
    z[3,2,5]  R1078     4.0741279721260071e-01
    z[3,2,5]  R1079     2.2728929296135902e-02
    z[3,2,5]  R1080     -2.8804320096969604e-01
    z[3,2,5]  R1081     5.1546716690063477e-01
    z[3,2,5]  R1082     6.7101502418518066e-01
    z[3,2,5]  R1083     5.8186775445938110e-01
    z[3,2,5]  R1084     -1.0468350723385811e-02
    z[3,2,5]  R1085     5.1003140211105347e-01
    z[3,2,5]  R1086     6.9440108537673950e-01
    z[3,2,5]  R1087     5.5458873510360718e-01
    z[3,2,5]  R1088     0.413343220949173
    z[3,2,5]  R1089     2.9687958955764771e-01
    z[3,2,5]  R1090     -2.5644791126251221e-01
    z[3,2,5]  R1091     -6.2193788588047028e-02
    z[3,2,5]  R1092     -2.6785546541213989e-01
    z[3,2,5]  R1093     3.3473879098892212e-01
    z[3,2,5]  R1094     -4.3114152550697327e-01
    z[3,2,5]  R1095     8.2911419868469238e-01
    z[3,2,5]  R1096     2.9068300127983093e-01
    z[3,2,5]  R1097     2.2954536974430084e-01
    z[3,2,5]  R1098     2.1932075917720795e-01
    z[3,2,5]  R1099     2.2315025329589844e-01
    z[3,2,5]  R1100     2.0577101409435272e-01
    z[3,2,5]  R1101     3.7524858117103577e-01
    z[3,2,5]  R1102     5.0734555721282959e-01
    z[3,2,5]  R1103     4.7492590546607971e-01
    z[3,2,5]  R1104     -2.1041874587535858e-01
    z[3,2,5]  R1105     -2.5743770599365234e-01
    z[3,2,5]  R1106     1.7963384091854095e-01
    z[3,2,5]  R1107     2.0145660638809204e-01
    z[3,2,5]  R1108     -7.7882564067840576e-01
    z[3,2,5]  R1109     3.7007558345794678e-01
    z[3,2,5]  R1110     1.8400555849075317e-01
    z[3,2,5]  R1111     3.5417270660400391e-01
    z[3,2,5]  R1112     4.2507287859916687e-01
    z[3,2,5]  R1113     6.5993052721023560e-01
    z[3,2,5]  R1114     -4.0111333131790161e-02
    z[3,2,5]  R1115     -2.9458436369895935e-01
    z[3,2,5]  R1116     -1.7900609970092773e-01
    z[3,2,5]  R1117     -2.3825907707214355e-01
    z[3,2,5]  R1118     1.9674451649188995e-01
    z[3,2,5]  R1119     -1.5321678481996059e-02
    z[3,2,5]  R1120     1.6504010185599327e-02
    z[3,2,5]  R1121     -5.1086336374282837e-02
    z[3,2,5]  R1122     -2.1501930430531502e-02
    z[3,2,5]  R1123     -2.1900095045566559e-01
    z[3,2,5]  R1124     -3.8801664113998413e-01
    z[3,2,5]  R1125     2.5432538986206055e-01
    z[3,2,5]  R1126     7.7942825853824615e-02
    z[3,2,5]  R1127     4.9140501767396927e-02
    z[3,2,5]  R1128     7.6111115515232086e-02
    z[3,2,5]  R1129     2.5701296329498291e-01
    z[3,2,5]  R1130     -8.5745364427566528e-02
    z[3,2,5]  R1131     -1.9198076426982880e-01
    z[3,2,5]  R1132     -9.8238639533519745e-02
    z[3,2,5]  R1133     -1.8779900670051575e-01
    z[3,2,5]  R1134     9.1455176472663879e-02
    z[3,2,5]  R1135     5.8820914477109909e-02
    z[3,2,5]  R1136     3.6578190326690674e-01
    z[3,2,5]  R1137     3.0248314142227173e-01
    z[3,2,5]  R1138     3.5836723446846008e-01
    z[3,2,5]  R1139     2.0174258947372437e-01
    z[3,2,5]  R1140     2.4466985464096069e-01
    z[3,2,5]  R1141     1.2938182055950165e-01
    z[3,2,5]  R1142     0.203104168176651
    z[3,2,5]  R1143     1.5726454555988312e-01
    z[3,2,5]  R1144     2.4988044798374176e-01
    z[3,2,5]  R1145     -1.2344833463430405e-01
    z[3,2,5]  R1146     1.9207081198692322e-01
    z[3,2,5]  R1147     1.0046100616455078e-01
    z[3,2,5]  R1148     -9.2327609658241272e-02
    z[3,2,5]  R1149     -1.4799048006534576e-01
    z[3,2,5]  R1150     4.6228629350662231e-01
    z[3,2,5]  R1151     -4.0209221839904785e-01
    z[3,2,5]  R1152     2.8853037953376770e-01
    z[3,2,5]  R1153     3.7438431382179260e-01
    z[3,2,5]  R1154     3.8681104779243469e-01
    z[3,2,5]  R1155     -3.5120215266942978e-02
    z[3,2,5]  R1156     1.3741073012351990e-01
    z[3,2,5]  R1157     2.6251502335071564e-02
    z[3,2,5]  R1158     -3.3485063910484314e-01
    z[3,2,5]  R1159     5.3847837448120117e-01
    z[3,2,5]  R1160     6.3186037540435791e-01
    z[3,2,5]  R1161     3.7381444126367569e-02
    z[3,2,5]  R1162     9.3511477112770081e-02
    z[3,2,5]  R1163     0.371217280626297
    z[3,2,5]  R1164     3.6413182970136404e-03
    z[3,2,5]  R1165     -2.0216912031173706e-01
    z[3,2,5]  R1166     1.0431414842605591e-01
    z[3,2,5]  R1167     1.1590618640184402e-02
    z[3,2,5]  R1168     -7.2658024728298187e-02
    z[3,2,5]  R1169     -6.2452876567840576e-01
    z[3,2,5]  R1170     3.4534335136413574e-01
    z[3,2,5]  R1171     -1.0845420509576797e-01
    z[3,2,5]  R1172     -6.4834314584732056e-01
    z[3,2,5]  R1173     -4.9363338947296143e-01
    z[3,2,5]  R1174     0.472953200340271
    z[3,2,5]  R1175     7.3955051600933075e-02
    z[3,2,5]  R1176     5.4328376054763794e-01
    z[3,2,5]  R1177     3.9821276068687439e-01
    z[3,2,5]  R1178     -1.3570861518383026e-01
    z[3,2,5]  R1179     -2.8387421369552612e-01
    z[3,2,5]  R1180     1.7517729103565216e-01
    z[3,2,5]  R1181     5.7705128192901611e-01
    z[3,2,5]  R1182     4.4803205132484436e-01
    z[3,2,5]  R1183     -4.0736470371484756e-02
    z[3,2,5]  R1184     -3.5944998264312744e-02
    z[3,2,5]  R1185     6.0712260007858276e-01
    z[3,2,5]  R1186     2.9833678156137466e-02
    z[3,2,5]  R1187     -2.2303852438926697e-01
    z[3,2,5]  R1188     -4.6621689200401306e-01
    z[3,2,5]  R1189     7.1863436698913574e-01
    z[3,2,5]  R1190     -3.0003547668457031e-01
    z[3,2,5]  R1191     -4.7163897752761841e-01
    z[3,2,5]  R1192     1.7729481682181358e-02
    z[3,2,5]  R1193     -9.3078408390283585e-03
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R1052     -1
    z[3,2,6]  R1053     1
    z[3,2,6]  R1054     2.2468097507953644e-01
    z[3,2,6]  R1055     -3.2996791601181030e-01
    z[3,2,6]  R1056     1.4762161672115326e-01
    z[3,2,6]  R1057     -4.5040425658226013e-01
    z[3,2,6]  R1058     1.3805608265101910e-02
    z[3,2,6]  R1059     5.8425735682249069e-02
    z[3,2,6]  R1060     3.9670267701148987e-01
    z[3,2,6]  R1061     0.537770688533783
    z[3,2,6]  R1062     -1.8344806134700775e-01
    z[3,2,6]  R1063     -8.5710622370243073e-02
    z[3,2,6]  R1064     -3.8023035973310471e-02
    z[3,2,6]  R1065     -0.269378125667572
    z[3,2,6]  R1066     -2.0136094093322754e-01
    z[3,2,6]  R1067     -1.4751872420310974e-01
    z[3,2,6]  R1068     -2.1189206838607788e-01
    z[3,2,6]  R1069     -1.0805781185626984e-01
    z[3,2,6]  R1070     -5.5326286703348160e-02
    z[3,2,6]  R1071     -2.1189002692699432e-01
    z[3,2,6]  R1072     4.6170207858085632e-01
    z[3,2,6]  R1073     -1.9464819133281708e-01
    z[3,2,6]  R1074     4.3017691373825073e-01
    z[3,2,6]  R1075     -1.5040473639965057e-01
    z[3,2,6]  R1076     6.3325248658657074e-02
    z[3,2,6]  R1077     1.1317790299654007e-01
    z[3,2,6]  R1078     1.9343329966068268e-01
    z[3,2,6]  R1079     -7.9061530530452728e-02
    z[3,2,6]  R1080     -9.6641272306442261e-02
    z[3,2,6]  R1081     -1.0856087505817413e-01
    z[3,2,6]  R1082     -1.6978496313095093e-01
    z[3,2,6]  R1083     -2.2336056455969810e-02
    z[3,2,6]  R1084     -1.4777894318103790e-01
    z[3,2,6]  R1085     9.7572272352408618e-05
    z[3,2,6]  R1086     -1.1589463800191879e-01
    z[3,2,6]  R1087     2.8197151422500610e-01
    z[3,2,6]  R1088     2.7002471685409546e-01
    z[3,2,6]  R1089     8.2531832158565521e-02
    z[3,2,6]  R1090     -1.7834395170211792e-02
    z[3,2,6]  R1091     1.0257884860038757e-01
    z[3,2,6]  R1092     3.3247941732406616e-01
    z[3,2,6]  R1093     3.5234186798334122e-02
    z[3,2,6]  R1094     0.0984724834561348
    z[3,2,6]  R1095     1.1448633670806885e-01
    z[3,2,6]  R1096     7.1404480934143066e-01
    z[3,2,6]  R1097     -1.8833881616592407e-01
    z[3,2,6]  R1098     -7.0366062223911285e-02
    z[3,2,6]  R1099     6.7802697420120239e-02
    z[3,2,6]  R1100     1.1730934679508209e-01
    z[3,2,6]  R1101     -6.0412295162677765e-02
    z[3,2,6]  R1102     -2.2613309323787689e-01
    z[3,2,6]  R1103     2.3787630721926689e-02
    z[3,2,6]  R1104     7.1329828351736069e-03
    z[3,2,6]  R1105     -7.9224541783332825e-02
    z[3,2,6]  R1106     4.9727505445480347e-01
    z[3,2,6]  R1107     -1.5995460748672485e-01
    z[3,2,6]  R1108     -5.7356536388397217e-01
    z[3,2,6]  R1109     1.2033274024724960e-01
    z[3,2,6]  R1110     -7.1916177868843079e-02
    z[3,2,6]  R1111     -3.6164382100105286e-01
    z[3,2,6]  R1112     -3.1468236446380615e-01
    z[3,2,6]  R1113     -1.3965220749378204e-01
    z[3,2,6]  R1114     -1.7198163270950317e-01
    z[3,2,6]  R1115     9.7616732120513916e-02
    z[3,2,6]  R1116     8.6575500667095184e-02
    z[3,2,6]  R1117     2.6357337832450867e-01
    z[3,2,6]  R1118     9.2977419495582581e-02
    z[3,2,6]  R1119     1.7765671014785767e-01
    z[3,2,6]  R1120     0.538210928440094
    z[3,2,6]  R1121     -9.9790245294570923e-02
    z[3,2,6]  R1122     0.267120897769928
    z[3,2,6]  R1123     -7.2021287679672241e-01
    z[3,2,6]  R1124     1.5352459251880646e-01
    z[3,2,6]  R1125     0.329188734292984
    z[3,2,6]  R1126     2.3916792869567871e-01
    z[3,2,6]  R1127     -1.8713575601577759e-01
    z[3,2,6]  R1128     4.9038669466972351e-01
    z[3,2,6]  R1129     -2.7009156346321106e-01
    z[3,2,6]  R1130     5.6678575277328491e-01
    z[3,2,6]  R1131     3.7452098727226257e-01
    z[3,2,6]  R1132     1.6239304840564728e-01
    z[3,2,6]  R1133     3.7542721629142761e-01
    z[3,2,6]  R1134     -5.5112581700086594e-02
    z[3,2,6]  R1135     -4.4175809621810913e-01
    z[3,2,6]  R1136     2.0904199779033661e-01
    z[3,2,6]  R1137     -3.4600594639778137e-01
    z[3,2,6]  R1138     1.0638792812824249e-01
    z[3,2,6]  R1139     5.7504154741764069e-02
    z[3,2,6]  R1140     7.3766849935054779e-02
    z[3,2,6]  R1141     3.7288421392440796e-01
    z[3,2,6]  R1142     -3.0995625257492065e-01
    z[3,2,6]  R1143     -2.8730648756027222e-01
    z[3,2,6]  R1144     -3.0975034832954407e-01
    z[3,2,6]  R1145     2.0896416902542114e-01
    z[3,2,6]  R1146     1.2505804002285004e-01
    z[3,2,6]  R1147     -5.4767656326293945e-01
    z[3,2,6]  R1148     -5.5913275480270386e-01
    z[3,2,6]  R1149     -2.9187005758285522e-01
    z[3,2,6]  R1150     5.7579171657562256e-01
    z[3,2,6]  R1151     -4.8718109726905823e-01
    z[3,2,6]  R1152     -5.5757766962051392e-01
    z[3,2,6]  R1153     1.5979956090450287e-01
    z[3,2,6]  R1154     1.1773577332496643e-01
    z[3,2,6]  R1155     -1.1788261681795120e-01
    z[3,2,6]  R1156     3.7980252504348755e-01
    z[3,2,6]  R1157     -1.0959913581609726e-01
    z[3,2,6]  R1158     -1.5310059487819672e-01
    z[3,2,6]  R1159     -7.4085518717765808e-02
    z[3,2,6]  R1160     -1.8072827160358429e-01
    z[3,2,6]  R1161     -4.6383801102638245e-01
    z[3,2,6]  R1162     1.4695416390895844e-01
    z[3,2,6]  R1163     2.5241279974579811e-02
    z[3,2,6]  R1164     -2.5018927454948425e-01
    z[3,2,6]  R1165     -3.3541226387023926e-01
    z[3,2,6]  R1166     3.1361293792724609e-01
    z[3,2,6]  R1167     2.8857663273811340e-01
    z[3,2,6]  R1168     -2.0775970816612244e-01
    z[3,2,6]  R1169     4.2690834403038025e-01
    z[3,2,6]  R1170     -2.1375331282615662e-01
    z[3,2,6]  R1171     1.6016711294651031e-01
    z[3,2,6]  R1172     8.2306535914540291e-03
    z[3,2,6]  R1173     1.4425319433212280e-01
    z[3,2,6]  R1174     5.8335000276565552e-01
    z[3,2,6]  R1175     -2.3129422962665558e-01
    z[3,2,6]  R1176     1.6793212294578552e-01
    z[3,2,6]  R1177     -3.8830515742301941e-01
    z[3,2,6]  R1178     -3.7465396523475647e-01
    z[3,2,6]  R1179     5.2417159080505371e-02
    z[3,2,6]  R1180     -0.200520858168602
    z[3,2,6]  R1181     2.5251591205596924e-01
    z[3,2,6]  R1182     -0.011157201603055
    z[3,2,6]  R1183     4.9335334450006485e-02
    z[3,2,6]  R1184     -4.9009706825017929e-02
    z[3,2,6]  R1185     1.0897734016180038e-01
    z[3,2,6]  R1186     -2.9252591729164124e-01
    z[3,2,6]  R1187     9.0420506894588470e-02
    z[3,2,6]  R1188     -2.0941365510225296e-02
    z[3,2,6]  R1189     -4.7655689716339111e-01
    z[3,2,6]  R1190     -3.7927865982055664e-01
    z[3,2,6]  R1191     0.0328315831720829
    z[3,2,6]  R1192     -1.6944380104541779e-01
    z[3,2,6]  R1193     -7.0934578776359558e-02
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R1194     -1
    z[3,4,0]  R1195     1
    z[3,4,0]  R1208     3.8435712456703186e-01
    z[3,4,0]  R1209     4.6964627504348755e-01
    z[3,4,0]  R1210     1.2871317565441132e-01
    z[3,4,0]  R1211     3.3063021302223206e-01
    z[3,4,0]  R1212     -1.5768514573574066e-01
    z[3,4,0]  R1213     -6.0754650831222534e-01
    z[3,4,0]  R1214     -4.4395166635513306e-01
    z[3,4,0]  R1215     -1.7489361763000488e-01
    z[3,4,0]  R1216     -6.6080474853515625e-01
    z[3,4,0]  R1217     -6.0426956415176392e-01
    z[3,4,0]  R1218     -3.8641926646232605e-01
    z[3,4,0]  R1219     -2.2747081518173218e-01
    z[3,4,0]  R1220     -1.8546903133392334e-01
    z[3,4,0]  R1221     -2.2525892127305269e-03
    z[3,4,0]  R1222     -3.2109636068344116e-01
    z[3,4,0]  R1223     -2.2801786661148071e-02
    z[3,4,0]  R1224     -5.9258061647415161e-01
    z[3,4,0]  R1225     -3.0523759126663208e-01
    z[3,4,0]  R1226     -4.9144953489303589e-01
    z[3,4,0]  R1227     3.5981366038322449e-01
    z[3,4,0]  R1228     4.6973848342895508e-01
    z[3,4,0]  R1229     3.7984788417816162e-01
    z[3,4,0]  R1230     3.2363331317901611e-01
    z[3,4,0]  R1231     -1.0073760896921158e-01
    z[3,4,0]  R1232     -5.3915452957153320e-01
    z[3,4,0]  R1233     0.573432981967926
    z[3,4,0]  R1234     5.8630925416946411e-01
    z[3,4,0]  R1235     6.3679113984107971e-02
    z[3,4,0]  R1236     1.5071780420839787e-02
    z[3,4,0]  R1237     1.0220363736152649e-01
    z[3,4,0]  R1238     7.9044562578201294e-01
    z[3,4,0]  R1239     -8.5493430495262146e-02
    z[3,4,0]  R1240     -2.8234678506851196e-01
    z[3,4,0]  R1241     -1.1949960142374039e-01
    z[3,4,0]  R1242     -4.2563432455062866e-01
    z[3,4,0]  R1243     -3.5032281279563904e-01
    z[3,4,0]  R1244     -2.7937644720077515e-01
    z[3,4,0]  R1245     -3.0842721462249756e-01
    z[3,4,0]  R1246     -6.1874139308929443e-01
    z[3,4,0]  R1247     -4.4269609451293945e-01
    z[3,4,0]  R1248     1.0344447195529938e-01
    z[3,4,0]  R1249     -9.6073616296052933e-03
    z[3,4,0]  R1250     -3.5229781270027161e-01
    z[3,4,0]  R1251     2.1113598719239235e-02
    z[3,4,0]  R1252     -1.6194912791252136e-01
    z[3,4,0]  R1253     1.4746780693531036e-01
    z[3,4,0]  R1254     -3.9892011880874634e-01
    z[3,4,0]  R1255     -2.4754211306571960e-01
    z[3,4,0]  R1256     -5.6692034006118774e-01
    z[3,4,0]  R1257     -6.1223447322845459e-01
    z[3,4,0]  R1258     -8.9415594935417175e-02
    z[3,4,0]  R1259     5.4197525978088379e-01
    z[3,4,0]  R1260     -3.4987998008728027e-01
    z[3,4,0]  R1261     -5.3841060400009155e-01
    z[3,4,0]  R1262     1.6175134107470512e-02
    z[3,4,0]  R1263     1.9008865579962730e-02
    z[3,4,0]  R1264     -1.1379750072956085e-01
    z[3,4,0]  R1265     8.3032414317131042e-02
    z[3,4,0]  R1266     -6.1901800334453583e-02
    z[3,4,0]  R1267     2.9676225781440735e-01
    z[3,4,0]  R1268     -3.2573610544204712e-01
    z[3,4,0]  R1269     -2.5934723019599915e-01
    z[3,4,0]  R1270     8.8120587170124054e-02
    z[3,4,0]  R1271     9.8550565540790558e-02
    z[3,4,0]  R1272     6.9516366720199585e-01
    z[3,4,0]  R1273     3.5381710529327393e-01
    z[3,4,0]  R1274     5.3135710954666138e-01
    z[3,4,0]  R1275     5.0062006711959839e-01
    z[3,4,0]  R1276     -0.0803113803267479
    z[3,4,0]  R1277     -4.1130515933036804e-01
    z[3,4,0]  R1278     -0.427592396736145
    z[3,4,0]  R1279     2.0544408261775970e-01
    z[3,4,0]  R1280     0.0890294685959816
    z[3,4,0]  R1281     -6.0372769832611084e-02
    z[3,4,0]  R1282     -3.5978186130523682e-01
    z[3,4,0]  R1283     -2.9932841658592224e-01
    z[3,4,0]  R1284     -1.1968418210744858e-01
    z[3,4,0]  R1285     -1.6735707223415375e-01
    z[3,4,0]  R1286     -7.3670989274978638e-01
    z[3,4,0]  R1287     -7.2185647487640381e-01
    z[3,4,0]  R1288     5.0655186176300049e-01
    z[3,4,0]  R1289     -3.5451275110244751e-01
    z[3,4,0]  R1290     7.0910400152206421e-01
    z[3,4,0]  R1291     -3.2608368992805481e-01
    z[3,4,0]  R1292     -4.0962222218513489e-01
    z[3,4,0]  R1293     -5.7422578334808350e-01
    z[3,4,0]  R1294     4.8209443688392639e-01
    z[3,4,0]  R1295     -2.2729055583477020e-01
    z[3,4,0]  R1296     -5.2984601259231567e-01
    z[3,4,0]  R1297     -8.7798461318016052e-02
    z[3,4,0]  R1298     -2.1332009136676788e-01
    z[3,4,0]  R1299     1.4889524877071381e-01
    z[3,4,0]  R1300     6.1367547512054443e-01
    z[3,4,0]  R1301     3.5424154996871948e-01
    z[3,4,0]  R1302     7.5880038738250732e-01
    z[3,4,0]  R1303     -1.2219431251287460e-01
    z[3,4,0]  R1304     -1.5539045631885529e-01
    z[3,4,0]  R1305     -4.0151676535606384e-01
    z[3,4,0]  R1306     -4.3038254976272583e-01
    z[3,4,0]  R1307     -5.8152490854263306e-01
    z[3,4,0]  R1308     4.6116787195205688e-01
    z[3,4,0]  R1309     7.4232870340347290e-01
    z[3,4,0]  R1310     -2.1970137953758240e-01
    z[3,4,0]  R1311     -2.8013315796852112e-01
    z[3,4,0]  R1312     -2.9905471205711365e-01
    z[3,4,0]  R1313     -5.3870719671249390e-01
    z[3,4,0]  R1314     -2.1344721317291260e-01
    z[3,4,0]  R1315     -6.4537745714187622e-01
    z[3,4,0]  R1316     -6.8506032228469849e-01
    z[3,4,0]  R1317     -1.5146845579147339e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R1196     -1
    z[3,4,1]  R1197     1
    z[3,4,1]  R1208     -3.8943392038345337e-01
    z[3,4,1]  R1209     1.0056421905755997e-01
    z[3,4,1]  R1210     1.5411810576915741e-01
    z[3,4,1]  R1211     -7.9090172052383423e-01
    z[3,4,1]  R1212     -0.0875360444188118
    z[3,4,1]  R1213     -6.2563389539718628e-01
    z[3,4,1]  R1214     -0.704354465007782
    z[3,4,1]  R1215     -7.9132989048957825e-02
    z[3,4,1]  R1216     -6.2296229600906372e-01
    z[3,4,1]  R1217     -6.6563093662261963e-01
    z[3,4,1]  R1218     -4.1182957589626312e-02
    z[3,4,1]  R1219     -3.4564676880836487e-01
    z[3,4,1]  R1220     2.8088864684104919e-01
    z[3,4,1]  R1221     3.0188298225402832e-01
    z[3,4,1]  R1222     6.1274491250514984e-02
    z[3,4,1]  R1223     0.0978856310248375
    z[3,4,1]  R1224     2.0466198027133942e-01
    z[3,4,1]  R1225     6.6788643598556519e-03
    z[3,4,1]  R1226     1.1274852603673935e-01
    z[3,4,1]  R1227     4.3839445710182190e-01
    z[3,4,1]  R1228     3.5533255338668823e-01
    z[3,4,1]  R1229     -6.9836688041687012e-01
    z[3,4,1]  R1230     -3.9601841568946838e-01
    z[3,4,1]  R1231     1.1077233403921127e-01
    z[3,4,1]  R1232     2.0387648046016693e-01
    z[3,4,1]  R1233     -2.1392878890037537e-01
    z[3,4,1]  R1234     3.0866166949272156e-01
    z[3,4,1]  R1235     -1.5111443400382996e-01
    z[3,4,1]  R1236     2.5715095922350883e-02
    z[3,4,1]  R1237     -1.4068578183650970e-01
    z[3,4,1]  R1238     -0.302144318819046
    z[3,4,1]  R1239     3.4736540168523788e-02
    z[3,4,1]  R1240     -1.4574143290519714e-01
    z[3,4,1]  R1241     -2.2250409424304962e-01
    z[3,4,1]  R1242     -4.6310713887214661e-01
    z[3,4,1]  R1243     2.1093061566352844e-01
    z[3,4,1]  R1244     -8.5881382226943970e-01
    z[3,4,1]  R1245     -4.4231769442558289e-01
    z[3,4,1]  R1246     -0.606364369392395
    z[3,4,1]  R1247     -7.1295052766799927e-01
    z[3,4,1]  R1248     7.0980495214462280e-01
    z[3,4,1]  R1249     -4.2589294910430908e-01
    z[3,4,1]  R1250     -1.5035982429981232e-01
    z[3,4,1]  R1251     9.3660390377044678e-01
    z[3,4,1]  R1252     9.3908828496932983e-01
    z[3,4,1]  R1253     8.6301565170288086e-01
    z[3,4,1]  R1254     5.0970077514648438e-01
    z[3,4,1]  R1255     7.0335948467254639e-01
    z[3,4,1]  R1256     2.9809432104229927e-02
    z[3,4,1]  R1257     -9.8309412598609924e-02
    z[3,4,1]  R1258     6.9336611032485962e-01
    z[3,4,1]  R1259     -6.0947406291961670e-01
    z[3,4,1]  R1260     -2.0571936666965485e-01
    z[3,4,1]  R1261     -7.4226832389831543e-01
    z[3,4,1]  R1262     1.8295995891094208e-01
    z[3,4,1]  R1263     6.1455290764570236e-02
    z[3,4,1]  R1264     1.7191922664642334e-01
    z[3,4,1]  R1265     2.5506317615509033e-01
    z[3,4,1]  R1266     9.5106415450572968e-02
    z[3,4,1]  R1267     -8.0855406820774078e-02
    z[3,4,1]  R1268     8.6098372936248779e-02
    z[3,4,1]  R1269     4.0809374302625656e-02
    z[3,4,1]  R1270     1.4856897294521332e-02
    z[3,4,1]  R1271     3.5770680755376816e-02
    z[3,4,1]  R1272     2.9243474826216698e-02
    z[3,4,1]  R1273     3.3882107585668564e-02
    z[3,4,1]  R1274     4.2408645153045654e-02
    z[3,4,1]  R1275     -2.6837334036827087e-02
    z[3,4,1]  R1276     -9.8626506328582764e-01
    z[3,4,1]  R1277     -7.7075231075286865e-01
    z[3,4,1]  R1278     3.3755227923393250e-01
    z[3,4,1]  R1279     4.6453335881233215e-01
    z[3,4,1]  R1280     2.0314882695674896e-01
    z[3,4,1]  R1281     -4.5288348197937012e-01
    z[3,4,1]  R1282     -2.2510962188243866e-01
    z[3,4,1]  R1283     7.5029619038105011e-02
    z[3,4,1]  R1284     -1.1169072240591049e-01
    z[3,4,1]  R1285     -2.0647212862968445e-01
    z[3,4,1]  R1286     3.1193214654922485e-01
    z[3,4,1]  R1287     1.0958223044872284e-01
    z[3,4,1]  R1288     7.0791471004486084e-01
    z[3,4,1]  R1289     7.0677822828292847e-01
    z[3,4,1]  R1290     -9.4216220080852509e-02
    z[3,4,1]  R1291     -1.8292379379272461e-01
    z[3,4,1]  R1292     -3.1834807991981506e-01
    z[3,4,1]  R1293     -2.9790893197059631e-02
    z[3,4,1]  R1294     -6.2753939628601074e-01
    z[3,4,1]  R1295     -2.8487288951873779e-01
    z[3,4,1]  R1296     -2.7020066976547241e-01
    z[3,4,1]  R1297     -8.7465830147266388e-02
    z[3,4,1]  R1298     9.1370832920074463e-01
    z[3,4,1]  R1299     6.0478651523590088e-01
    z[3,4,1]  R1300     -5.3782677650451660e-01
    z[3,4,1]  R1301     -2.0813673734664917e-01
    z[3,4,1]  R1302     -1.4956003427505493e-01
    z[3,4,1]  R1303     -9.1522234678268433e-01
    z[3,4,1]  R1304     -3.5401773452758789e-01
    z[3,4,1]  R1305     -7.9296404123306274e-01
    z[3,4,1]  R1306     -7.6892828941345215e-01
    z[3,4,1]  R1307     -7.2409129142761230e-01
    z[3,4,1]  R1308     2.1006102859973907e-01
    z[3,4,1]  R1309     -0.37724769115448
    z[3,4,1]  R1310     -2.4791140854358673e-01
    z[3,4,1]  R1311     -8.7415516376495361e-01
    z[3,4,1]  R1312     -8.2212585210800171e-01
    z[3,4,1]  R1313     -7.7263385057449341e-01
    z[3,4,1]  R1314     -8.1514602899551392e-01
    z[3,4,1]  R1315     -6.6241323947906494e-01
    z[3,4,1]  R1316     -5.7923221588134766e-01
    z[3,4,1]  R1317     -8.5195028781890869e-01
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R1198     -1
    z[3,4,2]  R1199     1
    z[3,4,2]  R1208     -1.3613632321357727e-01
    z[3,4,2]  R1209     -3.2119369506835938e-01
    z[3,4,2]  R1210     0.11175537109375
    z[3,4,2]  R1211     3.1654998660087585e-02
    z[3,4,2]  R1212     8.4770750999450684e-01
    z[3,4,2]  R1213     -1.4828373491764069e-01
    z[3,4,2]  R1214     2.9359790682792664e-01
    z[3,4,2]  R1215     0.686779260635376
    z[3,4,2]  R1216     -3.4933474659919739e-01
    z[3,4,2]  R1217     -1.5206056833267212e-01
    z[3,4,2]  R1218     1.1364550888538361e-01
    z[3,4,2]  R1219     3.4251266717910767e-01
    z[3,4,2]  R1220     8.4152139723300934e-02
    z[3,4,2]  R1221     -7.0116829872131348e-01
    z[3,4,2]  R1222     0.310958594083786
    z[3,4,2]  R1223     -4.8581293225288391e-01
    z[3,4,2]  R1224     1.5351407229900360e-01
    z[3,4,2]  R1225     -2.2517786920070648e-01
    z[3,4,2]  R1226     2.1858850494027138e-02
    z[3,4,2]  R1227     -4.2397168278694153e-01
    z[3,4,2]  R1228     1.2479174137115479e-01
    z[3,4,2]  R1229     4.9236118793487549e-01
    z[3,4,2]  R1230     7.7350640296936035e-01
    z[3,4,2]  R1231     4.2019265890121460e-01
    z[3,4,2]  R1232     3.5428783297538757e-01
    z[3,4,2]  R1233     3.6612513661384583e-01
    z[3,4,2]  R1234     1.0885686427354813e-01
    z[3,4,2]  R1235     5.1020783185958862e-01
    z[3,4,2]  R1236     6.2840634584426880e-01
    z[3,4,2]  R1237     9.5704257488250732e-02
    z[3,4,2]  R1238     4.8155072331428528e-01
    z[3,4,2]  R1239     0.616873025894165
    z[3,4,2]  R1240     4.6412819623947144e-01
    z[3,4,2]  R1241     1.1298055946826935e-01
    z[3,4,2]  R1242     4.5124284923076630e-02
    z[3,4,2]  R1243     6.3735512085258961e-03
    z[3,4,2]  R1244     -2.0513303577899933e-01
    z[3,4,2]  R1245     -1.2549702823162079e-01
    z[3,4,2]  R1246     -1.3414016366004944e-01
    z[3,4,2]  R1247     2.1963019669055939e-01
    z[3,4,2]  R1248     -4.5000827312469482e-01
    z[3,4,2]  R1249     8.7170645594596863e-02
    z[3,4,2]  R1250     2.8488731384277344e-01
    z[3,4,2]  R1251     2.7279371395707130e-02
    z[3,4,2]  R1252     -1.3675086200237274e-01
    z[3,4,2]  R1253     3.0031827092170715e-01
    z[3,4,2]  R1254     -6.9078212976455688e-01
    z[3,4,2]  R1255     -5.2651494741439819e-01
    z[3,4,2]  R1256     2.8083970770239830e-02
    z[3,4,2]  R1257     2.4156154692173004e-01
    z[3,4,2]  R1258     -5.5537432432174683e-01
    z[3,4,2]  R1259     2.1817199885845184e-01
    z[3,4,2]  R1260     2.2642841935157776e-01
    z[3,4,2]  R1261     -1.9141036272048950e-01
    z[3,4,2]  R1262     1.1570196598768234e-01
    z[3,4,2]  R1263     -0.0828382596373558
    z[3,4,2]  R1264     2.0725773274898529e-01
    z[3,4,2]  R1265     8.0018816515803337e-03
    z[3,4,2]  R1266     -3.0644190311431885e-01
    z[3,4,2]  R1267     -1.1769544333219528e-01
    z[3,4,2]  R1268     8.7004798650741577e-01
    z[3,4,2]  R1269     -3.1570014357566833e-01
    z[3,4,2]  R1270     -3.2411649823188782e-01
    z[3,4,2]  R1271     -4.5273759961128235e-01
    z[3,4,2]  R1272     -3.1902936100959778e-01
    z[3,4,2]  R1273     -3.8057672977447510e-01
    z[3,4,2]  R1274     2.3256923258304596e-01
    z[3,4,2]  R1275     -5.2614736557006836e-01
    z[3,4,2]  R1276     3.5125121474266052e-02
    z[3,4,2]  R1277     -0.135227769613266
    z[3,4,2]  R1278     -6.6119629144668579e-01
    z[3,4,2]  R1279     2.4024224281311035e-01
    z[3,4,2]  R1280     -3.2324683666229248e-01
    z[3,4,2]  R1281     2.6352068781852722e-01
    z[3,4,2]  R1282     1.5180575847625732e-01
    z[3,4,2]  R1283     1.7123924195766449e-01
    z[3,4,2]  R1284     -3.2004401087760925e-02
    z[3,4,2]  R1285     4.7869232296943665e-01
    z[3,4,2]  R1286     3.6024913191795349e-01
    z[3,4,2]  R1287     6.1882162094116211e-01
    z[3,4,2]  R1288     -3.1423881649971008e-01
    z[3,4,2]  R1289     2.6292544603347778e-01
    z[3,4,2]  R1290     2.8887814283370972e-01
    z[3,4,2]  R1291     7.3006629943847656e-01
    z[3,4,2]  R1292     3.7077632546424866e-01
    z[3,4,2]  R1293     4.2833951115608215e-01
    z[3,4,2]  R1294     -2.1611212193965912e-01
    z[3,4,2]  R1295     7.2118914127349854e-01
    z[3,4,2]  R1296     4.2355710268020630e-01
    z[3,4,2]  R1297     3.1084164977073669e-01
    z[3,4,2]  R1298     -1.4423248171806335e-01
    z[3,4,2]  R1299     6.9796758890151978e-01
    z[3,4,2]  R1300     -4.3535566329956055e-01
    z[3,4,2]  R1301     -6.3349805772304535e-02
    z[3,4,2]  R1302     -2.9123482108116150e-01
    z[3,4,2]  R1303     -3.1179878115653992e-01
    z[3,4,2]  R1304     2.2285149991512299e-01
    z[3,4,2]  R1305     -0.224463552236557
    z[3,4,2]  R1306     -3.3415627479553223e-01
    z[3,4,2]  R1307     1.4328600466251373e-01
    z[3,4,2]  R1308     -4.3183878064155579e-01
    z[3,4,2]  R1309     -1.9323955476284027e-01
    z[3,4,2]  R1310     2.3670576512813568e-01
    z[3,4,2]  R1311     -4.6494167298078537e-02
    z[3,4,2]  R1312     -2.1576589345932007e-01
    z[3,4,2]  R1313     -1.8845294415950775e-01
    z[3,4,2]  R1314     8.5460282862186432e-02
    z[3,4,2]  R1315     9.2955529689788818e-02
    z[3,4,2]  R1316     1.5348492562770844e-01
    z[3,4,2]  R1317     3.5969346761703491e-01
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R1200     -1
    z[3,4,3]  R1201     1
    z[3,4,3]  R1208     4.5321959257125854e-01
    z[3,4,3]  R1209     4.4695851206779480e-01
    z[3,4,3]  R1210     9.3673390150070190e-01
    z[3,4,3]  R1211     1.9504196941852570e-01
    z[3,4,3]  R1212     -2.9698863625526428e-01
    z[3,4,3]  R1213     -0.0312623456120491
    z[3,4,3]  R1214     -2.2925306856632233e-01
    z[3,4,3]  R1215     -4.2882928252220154e-01
    z[3,4,3]  R1216     6.9269701838493347e-02
    z[3,4,3]  R1217     3.7578254938125610e-01
    z[3,4,3]  R1218     -8.1052398681640625e-01
    z[3,4,3]  R1219     -5.8123838901519775e-01
    z[3,4,3]  R1220     -0.560954213142395
    z[3,4,3]  R1221     1.1045350879430771e-01
    z[3,4,3]  R1222     -3.7698951363563538e-01
    z[3,4,3]  R1223     4.2962488532066345e-01
    z[3,4,3]  R1224     -4.0225467085838318e-01
    z[3,4,3]  R1225     -5.8202630281448364e-01
    z[3,4,3]  R1226     -4.1785049438476562e-01
    z[3,4,3]  R1227     -3.0952779576182365e-02
    z[3,4,3]  R1228     2.3720730841159821e-01
    z[3,4,3]  R1229     6.9490201771259308e-02
    z[3,4,3]  R1230     1.2240605801343918e-01
    z[3,4,3]  R1231     -6.0070788860321045e-01
    z[3,4,3]  R1232     -0.522066593170166
    z[3,4,3]  R1233     3.8913151621818542e-01
    z[3,4,3]  R1234     3.6415389180183411e-01
    z[3,4,3]  R1235     -1.9415524601936340e-01
    z[3,4,3]  R1236     -3.3607918024063110e-01
    z[3,4,3]  R1237     -3.9141789078712463e-01
    z[3,4,3]  R1238     -8.4982894361019135e-02
    z[3,4,3]  R1239     -5.5730760097503662e-01
    z[3,4,3]  R1240     -9.1690264642238617e-02
    z[3,4,3]  R1241     -7.2996979951858521e-01
    z[3,4,3]  R1242     -5.5128979682922363e-01
    z[3,4,3]  R1243     -0.838477373123169
    z[3,4,3]  R1244     -2.7604243159294128e-01
    z[3,4,3]  R1245     6.3116061687469482e-01
    z[3,4,3]  R1246     -4.3238624930381775e-02
    z[3,4,3]  R1247     3.6420649290084839e-01
    z[3,4,3]  R1248     -3.9759587496519089e-02
    z[3,4,3]  R1249     -2.7081990242004395e-01
    z[3,4,3]  R1250     3.9089463651180267e-02
    z[3,4,3]  R1251     -1.4939683675765991e-01
    z[3,4,3]  R1252     1.0562177002429962e-01
    z[3,4,3]  R1253     4.4475674629211426e-02
    z[3,4,3]  R1254     2.0891658961772919e-01
    z[3,4,3]  R1255     0.14479960501194
    z[3,4,3]  R1256     -2.2908157110214233e-01
    z[3,4,3]  R1257     -8.4188235923647881e-03
    z[3,4,3]  R1258     3.7611511349678040e-01
    z[3,4,3]  R1259     -2.1606069058179855e-02
    z[3,4,3]  R1260     -2.7403208613395691e-01
    z[3,4,3]  R1261     1.7212149500846863e-01
    z[3,4,3]  R1262     4.7052096575498581e-02
    z[3,4,3]  R1263     -3.6566668748855591e-01
    z[3,4,3]  R1264     -4.7412046790122986e-01
    z[3,4,3]  R1265     -4.2067438364028931e-01
    z[3,4,3]  R1266     -4.8991143703460693e-01
    z[3,4,3]  R1267     -2.5718429684638977e-01
    z[3,4,3]  R1268     -2.4330346286296844e-01
    z[3,4,3]  R1269     6.4088380336761475e-01
    z[3,4,3]  R1270     8.3118927478790283e-01
    z[3,4,3]  R1271     5.0202047824859619e-01
    z[3,4,3]  R1272     6.1825442314147949e-01
    z[3,4,3]  R1273     5.3561651706695557e-01
    z[3,4,3]  R1274     -2.1502526104450226e-01
    z[3,4,3]  R1275     3.4871095418930054e-01
    z[3,4,3]  R1276     6.1747943982481956e-03
    z[3,4,3]  R1277     -7.8910492360591888e-02
    z[3,4,3]  R1278     -4.9729026854038239e-02
    z[3,4,3]  R1279     -1.3379671610891819e-02
    z[3,4,3]  R1280     -3.6287495493888855e-01
    z[3,4,3]  R1281     -6.2828463315963745e-01
    z[3,4,3]  R1282     -7.9960060119628906e-01
    z[3,4,3]  R1283     -5.5615299940109253e-01
    z[3,4,3]  R1284     -8.0680477619171143e-01
    z[3,4,3]  R1285     -5.9920346736907959e-01
    z[3,4,3]  R1286     -4.7588801383972168e-01
    z[3,4,3]  R1287     -1.9305257499217987e-01
    z[3,4,3]  R1288     -2.4466849863529205e-01
    z[3,4,3]  R1289     -2.2717629373073578e-01
    z[3,4,3]  R1290     6.1988256871700287e-02
    z[3,4,3]  R1291     -4.9140679836273193e-01
    z[3,4,3]  R1292     -0.562491238117218
    z[3,4,3]  R1293     -6.5210080146789551e-01
    z[3,4,3]  R1294     2.4216838181018829e-01
    z[3,4,3]  R1295     -4.3520128726959229e-01
    z[3,4,3]  R1296     -5.5447423458099365e-01
    z[3,4,3]  R1297     -8.6597663164138794e-01
    z[3,4,3]  R1298     -8.7393987923860550e-03
    z[3,4,3]  R1299     -0.0466126874089241
    z[3,4,3]  R1300     1.2584270536899567e-01
    z[3,4,3]  R1301     3.3088415861129761e-01
    z[3,4,3]  R1302     -2.1796119399368763e-03
    z[3,4,3]  R1303     -2.2579845041036606e-02
    z[3,4,3]  R1304     -5.8057314157485962e-01
    z[3,4,3]  R1305     9.4112195074558258e-03
    z[3,4,3]  R1306     -1.8776719272136688e-01
    z[3,4,3]  R1307     -0.0934593677520752
    z[3,4,3]  R1308     1.7307612299919128e-01
    z[3,4,3]  R1309     8.0016024410724640e-02
    z[3,4,3]  R1310     -7.9326313734054565e-01
    z[3,4,3]  R1311     4.2148139327764511e-02
    z[3,4,3]  R1312     2.2905036807060242e-01
    z[3,4,3]  R1313     1.7671939730644226e-01
    z[3,4,3]  R1314     -5.6692283600568771e-02
    z[3,4,3]  R1315     2.2062557935714722e-01
    z[3,4,3]  R1316     2.2669243812561035e-01
    z[3,4,3]  R1317     -1.0020788758993149e-01
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R1202     -1
    z[3,4,4]  R1203     1
    z[3,4,4]  R1208     3.4688645601272583e-01
    z[3,4,4]  R1209     5.9636777639389038e-01
    z[3,4,4]  R1210     1.8472562730312347e-01
    z[3,4,4]  R1211     -5.8635283261537552e-02
    z[3,4,4]  R1212     -2.3713652789592743e-01
    z[3,4,4]  R1213     4.5625463128089905e-01
    z[3,4,4]  R1214     1.0159126482903957e-02
    z[3,4,4]  R1215     1.3070702552795410e-01
    z[3,4,4]  R1216     -1.1682728677988052e-01
    z[3,4,4]  R1217     -4.6683631837368011e-02
    z[3,4,4]  R1218     3.4998500347137451e-01
    z[3,4,4]  R1219     1.3148643076419830e-01
    z[3,4,4]  R1220     5.9449046850204468e-01
    z[3,4,4]  R1221     -4.5888105034828186e-01
    z[3,4,4]  R1222     3.9809507131576538e-01
    z[3,4,4]  R1223     -6.9887173175811768e-01
    z[3,4,4]  R1224     3.2974988222122192e-01
    z[3,4,4]  R1225     4.0062639117240906e-01
    z[3,4,4]  R1226     1.9780324399471283e-01
    z[3,4,4]  R1227     -5.7936644554138184e-01
    z[3,4,4]  R1228     -0.341208279132843
    z[3,4,4]  R1229     -2.5814184546470642e-01
    z[3,4,4]  R1230     2.8583295643329620e-03
    z[3,4,4]  R1231     5.9135907888412476e-01
    z[3,4,4]  R1232     2.5743296742439270e-01
    z[3,4,4]  R1233     -5.7720959186553955e-01
    z[3,4,4]  R1234     -5.6938838958740234e-01
    z[3,4,4]  R1235     6.3056260347366333e-01
    z[3,4,4]  R1236     0.110362209379673
    z[3,4,4]  R1237     6.8434321880340576e-01
    z[3,4,4]  R1238     -1.5113914012908936e-01
    z[3,4,4]  R1239     2.0056955516338348e-01
    z[3,4,4]  R1240     4.2378431558609009e-01
    z[3,4,4]  R1241     5.9284854680299759e-02
    z[3,4,4]  R1242     2.3376183211803436e-01
    z[3,4,4]  R1243     1.8640869855880737e-01
    z[3,4,4]  R1244     5.0026741810142994e-03
    z[3,4,4]  R1245     -0.529833972454071
    z[3,4,4]  R1246     -2.1755275130271912e-01
    z[3,4,4]  R1247     3.9323933422565460e-02
    z[3,4,4]  R1248     -2.9293003678321838e-01
    z[3,4,4]  R1249     1.9246637821197510e-01
    z[3,4,4]  R1250     4.1980087757110596e-01
    z[3,4,4]  R1251     -0.105362668633461
    z[3,4,4]  R1252     -9.4741076231002808e-02
    z[3,4,4]  R1253     2.9477930068969727e-01
    z[3,4,4]  R1254     6.4331911504268646e-02
    z[3,4,4]  R1255     -3.6906756460666656e-02
    z[3,4,4]  R1256     -5.6205880641937256e-01
    z[3,4,4]  R1257     -5.7529205083847046e-01
    z[3,4,4]  R1258     -1.3045415282249451e-01
    z[3,4,4]  R1259     -4.6280416846275330e-01
    z[3,4,4]  R1260     6.5524756908416748e-01
    z[3,4,4]  R1261     1.6345609724521637e-01
    z[3,4,4]  R1262     -1.2294919788837433e-01
    z[3,4,4]  R1263     -8.3895868062973022e-01
    z[3,4,4]  R1264     -8.0667078495025635e-01
    z[3,4,4]  R1265     -7.0341515541076660e-01
    z[3,4,4]  R1266     -6.1113911867141724e-01
    z[3,4,4]  R1267     -6.0859465599060059e-01
    z[3,4,4]  R1268     1.7166081070899963e-01
    z[3,4,4]  R1269     2.6555103063583374e-01
    z[3,4,4]  R1270     -3.5666882991790771e-01
    z[3,4,4]  R1271     6.2006723880767822e-01
    z[3,4,4]  R1272     7.9848326742649078e-02
    z[3,4,4]  R1273     5.8126222342252731e-02
    z[3,4,4]  R1274     5.9390628337860107e-01
    z[3,4,4]  R1275     -3.8776338100433350e-01
    z[3,4,4]  R1276     2.5676438584923744e-02
    z[3,4,4]  R1277     3.1820493936538696e-01
    z[3,4,4]  R1278     -1.7874620854854584e-01
    z[3,4,4]  R1279     -2.6201993227005005e-01
    z[3,4,4]  R1280     -1.4919523894786835e-01
    z[3,4,4]  R1281     -2.1776072680950165e-01
    z[3,4,4]  R1282     -3.7224754691123962e-01
    z[3,4,4]  R1283     5.7311993837356567e-01
    z[3,4,4]  R1284     3.3144921064376831e-01
    z[3,4,4]  R1285     -5.3990882635116577e-01
    z[3,4,4]  R1286     3.5976175218820572e-02
    z[3,4,4]  R1287     -0.162450909614563
    z[3,4,4]  R1288     2.7533066272735596e-01
    z[3,4,4]  R1289     2.1661397814750671e-01
    z[3,4,4]  R1290     -3.1194350123405457e-01
    z[3,4,4]  R1291     5.3216083906590939e-03
    z[3,4,4]  R1292     2.2346168756484985e-01
    z[3,4,4]  R1293     1.5192779898643494e-01
    z[3,4,4]  R1294     -2.9828497767448425e-01
    z[3,4,4]  R1295     0.280141681432724
    z[3,4,4]  R1296     -2.0264382660388947e-01
    z[3,4,4]  R1297     2.8758466243743896e-01
    z[3,4,4]  R1298     8.5873436182737350e-04
    z[3,4,4]  R1299     -1.1589819192886353e-01
    z[3,4,4]  R1300     -4.7125168144702911e-02
    z[3,4,4]  R1301     -5.8494526147842407e-01
    z[3,4,4]  R1302     -4.6181634068489075e-01
    z[3,4,4]  R1303     1.4247675240039825e-01
    z[3,4,4]  R1304     -1.6923119127750397e-01
    z[3,4,4]  R1305     -2.9892298579216003e-01
    z[3,4,4]  R1306     3.5811014473438263e-02
    z[3,4,4]  R1307     -1.5946429967880249e-01
    z[3,4,4]  R1308     -5.0564610958099365e-01
    z[3,4,4]  R1309     -1.6528847813606262e-01
    z[3,4,4]  R1310     -3.4734913706779480e-01
    z[3,4,4]  R1311     -2.7560099959373474e-01
    z[3,4,4]  R1312     1.1525370180606842e-01
    z[3,4,4]  R1313     -1.2992176413536072e-01
    z[3,4,4]  R1314     2.5555733591318130e-03
    z[3,4,4]  R1315     4.9524795264005661e-02
    z[3,4,4]  R1316     -1.4719154569320381e-04
    z[3,4,4]  R1317     2.0635944604873657e-01
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R1204     -1
    z[3,4,5]  R1205     1
    z[3,4,5]  R1208     -0.553044319152832
    z[3,4,5]  R1209     -4.2993504554033279e-02
    z[3,4,5]  R1210     1.1749506741762161e-01
    z[3,4,5]  R1211     1.4075703918933868e-01
    z[3,4,5]  R1212     3.2285955548286438e-01
    z[3,4,5]  R1213     7.0158019661903381e-02
    z[3,4,5]  R1214     -1.0275598615407944e-01
    z[3,4,5]  R1215     0.0361696258187294
    z[3,4,5]  R1216     -3.3468861132860184e-02
    z[3,4,5]  R1217     1.3391450047492981e-01
    z[3,4,5]  R1218     2.3491376638412476e-01
    z[3,4,5]  R1219     5.3270930051803589e-01
    z[3,4,5]  R1220     4.1350486874580383e-01
    z[3,4,5]  R1221     -4.1556110978126526e-01
    z[3,4,5]  R1222     6.7152678966522217e-01
    z[3,4,5]  R1223     -0.263075053691864
    z[3,4,5]  R1224     5.5658805370330811e-01
    z[3,4,5]  R1225     5.5850416421890259e-01
    z[3,4,5]  R1226     5.6426358222961426e-01
    z[3,4,5]  R1227     -3.5225117206573486e-01
    z[3,4,5]  R1228     -5.2893179655075073e-01
    z[3,4,5]  R1229     1.7745985090732574e-01
    z[3,4,5]  R1230     3.4801909327507019e-01
    z[3,4,5]  R1231     2.7866625785827637e-01
    z[3,4,5]  R1232     4.0741279721260071e-01
    z[3,4,5]  R1233     2.2728929296135902e-02
    z[3,4,5]  R1234     -2.8804320096969604e-01
    z[3,4,5]  R1235     5.1546716690063477e-01
    z[3,4,5]  R1236     6.7101502418518066e-01
    z[3,4,5]  R1237     5.8186775445938110e-01
    z[3,4,5]  R1238     -1.0468350723385811e-02
    z[3,4,5]  R1239     5.1003140211105347e-01
    z[3,4,5]  R1240     6.9440108537673950e-01
    z[3,4,5]  R1241     5.5458873510360718e-01
    z[3,4,5]  R1242     0.413343220949173
    z[3,4,5]  R1243     2.9687958955764771e-01
    z[3,4,5]  R1244     -2.5644791126251221e-01
    z[3,4,5]  R1245     -6.2193788588047028e-02
    z[3,4,5]  R1246     -2.6785546541213989e-01
    z[3,4,5]  R1247     3.3473879098892212e-01
    z[3,4,5]  R1248     -4.3114152550697327e-01
    z[3,4,5]  R1249     8.2911419868469238e-01
    z[3,4,5]  R1250     2.9068300127983093e-01
    z[3,4,5]  R1251     2.2954536974430084e-01
    z[3,4,5]  R1252     2.1932075917720795e-01
    z[3,4,5]  R1253     2.2315025329589844e-01
    z[3,4,5]  R1254     2.0577101409435272e-01
    z[3,4,5]  R1255     3.7524858117103577e-01
    z[3,4,5]  R1256     5.0734555721282959e-01
    z[3,4,5]  R1257     4.7492590546607971e-01
    z[3,4,5]  R1258     -2.1041874587535858e-01
    z[3,4,5]  R1259     -2.5743770599365234e-01
    z[3,4,5]  R1260     1.7963384091854095e-01
    z[3,4,5]  R1261     2.0145660638809204e-01
    z[3,4,5]  R1262     -7.7882564067840576e-01
    z[3,4,5]  R1263     3.7007558345794678e-01
    z[3,4,5]  R1264     1.8400555849075317e-01
    z[3,4,5]  R1265     3.5417270660400391e-01
    z[3,4,5]  R1266     4.2507287859916687e-01
    z[3,4,5]  R1267     6.5993052721023560e-01
    z[3,4,5]  R1268     -8.7248824536800385e-02
    z[3,4,5]  R1269     -3.4173485636711121e-01
    z[3,4,5]  R1270     -2.6238659024238586e-01
    z[3,4,5]  R1271     -3.4383806586265564e-01
    z[3,4,5]  R1272     9.3546412885189056e-02
    z[3,4,5]  R1273     -6.0945028066635132e-01
    z[3,4,5]  R1274     -4.6668532490730286e-01
    z[3,4,5]  R1275     3.9792710542678833e-01
    z[3,4,5]  R1276     1.2828531861305237e-01
    z[3,4,5]  R1277     9.0913869440555573e-02
    z[3,4,5]  R1278     4.4212940335273743e-01
    z[3,4,5]  R1279     7.7977198362350464e-01
    z[3,4,5]  R1280     -4.2695045471191406e-01
    z[3,4,5]  R1281     3.7409138679504395e-01
    z[3,4,5]  R1282     9.4170890748500824e-02
    z[3,4,5]  R1283     3.5449784994125366e-01
    z[3,4,5]  R1284     3.2058224081993103e-01
    z[3,4,5]  R1285     0.0108823636546731
    z[3,4,5]  R1286     -0.0410323366522789
    z[3,4,5]  R1287     5.7950407266616821e-02
    z[3,4,5]  R1288     -2.5654423981904984e-02
    z[3,4,5]  R1289     -3.8571065664291382e-01
    z[3,4,5]  R1290     -2.5312250852584839e-01
    z[3,4,5]  R1291     2.0238001644611359e-01
    z[3,4,5]  R1292     4.6938553452491760e-01
    z[3,4,5]  R1293     1.9093506038188934e-01
    z[3,4,5]  R1294     0.0532853901386261
    z[3,4,5]  R1295     2.6255580782890320e-01
    z[3,4,5]  R1296     2.5324231386184692e-01
    z[3,4,5]  R1297     2.3000319302082062e-01
    z[3,4,5]  R1298     -2.4678705632686615e-01
    z[3,4,5]  R1299     -3.2962822914123535e-01
    z[3,4,5]  R1300     2.6725775003433228e-01
    z[3,4,5]  R1301     -2.3675398528575897e-01
    z[3,4,5]  R1302     -6.3373476266860962e-02
    z[3,4,5]  R1303     2.2593397647142410e-02
    z[3,4,5]  R1304     4.6157222986221313e-01
    z[3,4,5]  R1305     -2.4501267075538635e-01
    z[3,4,5]  R1306     -2.2183151543140411e-01
    z[3,4,5]  R1307     -1.8626582622528076e-01
    z[3,4,5]  R1308     1.2021089345216751e-01
    z[3,4,5]  R1309     -1.2923605740070343e-01
    z[3,4,5]  R1310     2.9020580649375916e-01
    z[3,4,5]  R1311     -2.4687018990516663e-01
    z[3,4,5]  R1312     -7.4510313570499420e-02
    z[3,4,5]  R1313     1.5238919854164124e-01
    z[3,4,5]  R1314     -4.1781923174858093e-01
    z[3,4,5]  R1315     -2.3594839870929718e-01
    z[3,4,5]  R1316     1.7438188195228577e-01
    z[3,4,5]  R1317     -2.5090718269348145e-01
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R1206     -1
    z[3,4,6]  R1207     1
    z[3,4,6]  R1208     2.2468097507953644e-01
    z[3,4,6]  R1209     -3.2996791601181030e-01
    z[3,4,6]  R1210     1.4762161672115326e-01
    z[3,4,6]  R1211     -4.5040425658226013e-01
    z[3,4,6]  R1212     1.3805608265101910e-02
    z[3,4,6]  R1213     5.8425735682249069e-02
    z[3,4,6]  R1214     3.9670267701148987e-01
    z[3,4,6]  R1215     0.537770688533783
    z[3,4,6]  R1216     -1.8344806134700775e-01
    z[3,4,6]  R1217     -8.5710622370243073e-02
    z[3,4,6]  R1218     -3.8023035973310471e-02
    z[3,4,6]  R1219     -0.269378125667572
    z[3,4,6]  R1220     -2.0136094093322754e-01
    z[3,4,6]  R1221     -1.4751872420310974e-01
    z[3,4,6]  R1222     -2.1189206838607788e-01
    z[3,4,6]  R1223     -1.0805781185626984e-01
    z[3,4,6]  R1224     -5.5326286703348160e-02
    z[3,4,6]  R1225     -2.1189002692699432e-01
    z[3,4,6]  R1226     4.6170207858085632e-01
    z[3,4,6]  R1227     -1.9464819133281708e-01
    z[3,4,6]  R1228     4.3017691373825073e-01
    z[3,4,6]  R1229     -1.5040473639965057e-01
    z[3,4,6]  R1230     6.3325248658657074e-02
    z[3,4,6]  R1231     1.1317790299654007e-01
    z[3,4,6]  R1232     1.9343329966068268e-01
    z[3,4,6]  R1233     -7.9061530530452728e-02
    z[3,4,6]  R1234     -9.6641272306442261e-02
    z[3,4,6]  R1235     -1.0856087505817413e-01
    z[3,4,6]  R1236     -1.6978496313095093e-01
    z[3,4,6]  R1237     -2.2336056455969810e-02
    z[3,4,6]  R1238     -1.4777894318103790e-01
    z[3,4,6]  R1239     9.7572272352408618e-05
    z[3,4,6]  R1240     -1.1589463800191879e-01
    z[3,4,6]  R1241     2.8197151422500610e-01
    z[3,4,6]  R1242     2.7002471685409546e-01
    z[3,4,6]  R1243     8.2531832158565521e-02
    z[3,4,6]  R1244     -1.7834395170211792e-02
    z[3,4,6]  R1245     1.0257884860038757e-01
    z[3,4,6]  R1246     3.3247941732406616e-01
    z[3,4,6]  R1247     3.5234186798334122e-02
    z[3,4,6]  R1248     0.0984724834561348
    z[3,4,6]  R1249     1.1448633670806885e-01
    z[3,4,6]  R1250     7.1404480934143066e-01
    z[3,4,6]  R1251     -1.8833881616592407e-01
    z[3,4,6]  R1252     -7.0366062223911285e-02
    z[3,4,6]  R1253     6.7802697420120239e-02
    z[3,4,6]  R1254     1.1730934679508209e-01
    z[3,4,6]  R1255     -6.0412295162677765e-02
    z[3,4,6]  R1256     -2.2613309323787689e-01
    z[3,4,6]  R1257     2.3787630721926689e-02
    z[3,4,6]  R1258     7.1329828351736069e-03
    z[3,4,6]  R1259     -7.9224541783332825e-02
    z[3,4,6]  R1260     4.9727505445480347e-01
    z[3,4,6]  R1261     -1.5995460748672485e-01
    z[3,4,6]  R1262     -5.7356536388397217e-01
    z[3,4,6]  R1263     1.2033274024724960e-01
    z[3,4,6]  R1264     -7.1916177868843079e-02
    z[3,4,6]  R1265     -3.6164382100105286e-01
    z[3,4,6]  R1266     -3.1468236446380615e-01
    z[3,4,6]  R1267     -1.3965220749378204e-01
    z[3,4,6]  R1268     -1.8227215111255646e-01
    z[3,4,6]  R1269     4.8308894038200378e-01
    z[3,4,6]  R1270     -5.2540283650159836e-03
    z[3,4,6]  R1271     -1.7118491232395172e-01
    z[3,4,6]  R1272     -1.2941205501556396e-01
    z[3,4,6]  R1273     0.259101003408432
    z[3,4,6]  R1274     2.1217225492000580e-01
    z[3,4,6]  R1275     -2.0377086102962494e-01
    z[3,4,6]  R1276     4.9424994736909866e-02
    z[3,4,6]  R1277     3.2052415609359741e-01
    z[3,4,6]  R1278     -1.9010773301124573e-01
    z[3,4,6]  R1279     8.6065813899040222e-02
    z[3,4,6]  R1280     -7.1420705318450928e-01
    z[3,4,6]  R1281     -3.7376844882965088e-01
    z[3,4,6]  R1282     -1.0020061582326889e-01
    z[3,4,6]  R1283     3.3467730879783630e-01
    z[3,4,6]  R1284     -3.2956176996231079e-01
    z[3,4,6]  R1285     2.2259773313999176e-01
    z[3,4,6]  R1286     -2.7017902582883835e-02
    z[3,4,6]  R1287     1.3021923601627350e-01
    z[3,4,6]  R1288     8.4782741963863373e-02
    z[3,4,6]  R1289     2.4156148731708527e-01
    z[3,4,6]  R1290     -4.8951196670532227e-01
    z[3,4,6]  R1291     -2.1152982115745544e-01
    z[3,4,6]  R1292     -0.0820658802986145
    z[3,4,6]  R1293     -3.3595755696296692e-02
    z[3,4,6]  R1294     -4.2025718092918396e-01
    z[3,4,6]  R1295     1.0127981007099152e-01
    z[3,4,6]  R1296     2.3284368216991425e-01
    z[3,4,6]  R1297     -4.9966756254434586e-02
    z[3,4,6]  R1298     1.9454509019851685e-01
    z[3,4,6]  R1299     2.5387939065694809e-02
    z[3,4,6]  R1300     -2.3479017615318298e-01
    z[3,4,6]  R1301     -5.6522661447525024e-01
    z[3,4,6]  R1302     -3.1581774353981018e-01
    z[3,4,6]  R1303     -1.6999433934688568e-01
    z[3,4,6]  R1304     -4.7128465771675110e-01
    z[3,4,6]  R1305     -1.0066631436347961e-01
    z[3,4,6]  R1306     1.6159044206142426e-01
    z[3,4,6]  R1307     -2.1938814222812653e-01
    z[3,4,6]  R1308     -5.0658637285232544e-01
    z[3,4,6]  R1309     -4.6783113479614258e-01
    z[3,4,6]  R1310     1.0208971798419952e-02
    z[3,4,6]  R1311     -1.2860514223575592e-01
    z[3,4,6]  R1312     3.4179106354713440e-01
    z[3,4,6]  R1313     -7.7363565564155579e-02
    z[3,4,6]  R1314     3.2385224103927612e-01
    z[3,4,6]  R1315     1.7104333639144897e-01
    z[3,4,6]  R1316     2.9971027374267578e-01
    z[3,4,6]  R1317     -0.0792362168431282
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R1318     -1
    z[4,3,0]  R1319     1
    z[4,3,0]  R1332     -3.2573610544204712e-01
    z[4,3,0]  R1333     -2.5934723019599915e-01
    z[4,3,0]  R1334     8.8120587170124054e-02
    z[4,3,0]  R1335     9.8550565540790558e-02
    z[4,3,0]  R1336     6.9516366720199585e-01
    z[4,3,0]  R1337     3.5381710529327393e-01
    z[4,3,0]  R1338     5.3135710954666138e-01
    z[4,3,0]  R1339     5.0062006711959839e-01
    z[4,3,0]  R1340     -0.0803113803267479
    z[4,3,0]  R1341     -4.1130515933036804e-01
    z[4,3,0]  R1342     -0.427592396736145
    z[4,3,0]  R1343     2.0544408261775970e-01
    z[4,3,0]  R1344     0.0890294685959816
    z[4,3,0]  R1345     -6.0372769832611084e-02
    z[4,3,0]  R1346     -3.5978186130523682e-01
    z[4,3,0]  R1347     -2.9932841658592224e-01
    z[4,3,0]  R1348     -1.1968418210744858e-01
    z[4,3,0]  R1349     -1.6735707223415375e-01
    z[4,3,0]  R1350     -7.3670989274978638e-01
    z[4,3,0]  R1351     -7.2185647487640381e-01
    z[4,3,0]  R1352     5.0655186176300049e-01
    z[4,3,0]  R1353     -3.5451275110244751e-01
    z[4,3,0]  R1354     7.0910400152206421e-01
    z[4,3,0]  R1355     -3.2608368992805481e-01
    z[4,3,0]  R1356     -4.0962222218513489e-01
    z[4,3,0]  R1357     -5.7422578334808350e-01
    z[4,3,0]  R1358     4.8209443688392639e-01
    z[4,3,0]  R1359     -2.2729055583477020e-01
    z[4,3,0]  R1360     -5.2984601259231567e-01
    z[4,3,0]  R1361     -8.7798461318016052e-02
    z[4,3,0]  R1362     -2.1332009136676788e-01
    z[4,3,0]  R1363     1.4889524877071381e-01
    z[4,3,0]  R1364     6.1367547512054443e-01
    z[4,3,0]  R1365     3.5424154996871948e-01
    z[4,3,0]  R1366     7.5880038738250732e-01
    z[4,3,0]  R1367     -1.2219431251287460e-01
    z[4,3,0]  R1368     -1.5539045631885529e-01
    z[4,3,0]  R1369     -4.0151676535606384e-01
    z[4,3,0]  R1370     -4.3038254976272583e-01
    z[4,3,0]  R1371     -5.8152490854263306e-01
    z[4,3,0]  R1372     4.6116787195205688e-01
    z[4,3,0]  R1373     7.4232870340347290e-01
    z[4,3,0]  R1374     -2.1970137953758240e-01
    z[4,3,0]  R1375     -2.8013315796852112e-01
    z[4,3,0]  R1376     -2.9905471205711365e-01
    z[4,3,0]  R1377     -5.3870719671249390e-01
    z[4,3,0]  R1378     -2.1344721317291260e-01
    z[4,3,0]  R1379     -6.4537745714187622e-01
    z[4,3,0]  R1380     -6.8506032228469849e-01
    z[4,3,0]  R1381     -1.5146845579147339e-01
    z[4,3,0]  R1382     3.8435712456703186e-01
    z[4,3,0]  R1383     4.6964627504348755e-01
    z[4,3,0]  R1384     1.2871317565441132e-01
    z[4,3,0]  R1385     3.3063021302223206e-01
    z[4,3,0]  R1386     -1.5768514573574066e-01
    z[4,3,0]  R1387     -6.0754650831222534e-01
    z[4,3,0]  R1388     -4.4395166635513306e-01
    z[4,3,0]  R1389     -1.7489361763000488e-01
    z[4,3,0]  R1390     -6.6080474853515625e-01
    z[4,3,0]  R1391     -6.0426956415176392e-01
    z[4,3,0]  R1392     -3.8641926646232605e-01
    z[4,3,0]  R1393     -2.2747081518173218e-01
    z[4,3,0]  R1394     -1.8546903133392334e-01
    z[4,3,0]  R1395     -2.2525892127305269e-03
    z[4,3,0]  R1396     -3.2109636068344116e-01
    z[4,3,0]  R1397     -2.2801786661148071e-02
    z[4,3,0]  R1398     -5.9258061647415161e-01
    z[4,3,0]  R1399     -3.0523759126663208e-01
    z[4,3,0]  R1400     -4.9144953489303589e-01
    z[4,3,0]  R1401     3.5981366038322449e-01
    z[4,3,0]  R1402     4.6973848342895508e-01
    z[4,3,0]  R1403     3.7984788417816162e-01
    z[4,3,0]  R1404     3.2363331317901611e-01
    z[4,3,0]  R1405     -1.0073760896921158e-01
    z[4,3,0]  R1406     -5.3915452957153320e-01
    z[4,3,0]  R1407     0.573432981967926
    z[4,3,0]  R1408     5.8630925416946411e-01
    z[4,3,0]  R1409     6.3679113984107971e-02
    z[4,3,0]  R1410     1.5071780420839787e-02
    z[4,3,0]  R1411     1.0220363736152649e-01
    z[4,3,0]  R1412     7.9044562578201294e-01
    z[4,3,0]  R1413     -8.5493430495262146e-02
    z[4,3,0]  R1414     -2.8234678506851196e-01
    z[4,3,0]  R1415     -1.1949960142374039e-01
    z[4,3,0]  R1416     -4.2563432455062866e-01
    z[4,3,0]  R1417     -3.5032281279563904e-01
    z[4,3,0]  R1418     -2.7937644720077515e-01
    z[4,3,0]  R1419     -3.0842721462249756e-01
    z[4,3,0]  R1420     -6.1874139308929443e-01
    z[4,3,0]  R1421     -4.4269609451293945e-01
    z[4,3,0]  R1422     1.0344447195529938e-01
    z[4,3,0]  R1423     -9.6073616296052933e-03
    z[4,3,0]  R1424     -3.5229781270027161e-01
    z[4,3,0]  R1425     2.1113598719239235e-02
    z[4,3,0]  R1426     -1.6194912791252136e-01
    z[4,3,0]  R1427     1.4746780693531036e-01
    z[4,3,0]  R1428     -3.9892011880874634e-01
    z[4,3,0]  R1429     -2.4754211306571960e-01
    z[4,3,0]  R1430     -5.6692034006118774e-01
    z[4,3,0]  R1431     -6.1223447322845459e-01
    z[4,3,0]  R1432     -8.9415594935417175e-02
    z[4,3,0]  R1433     5.4197525978088379e-01
    z[4,3,0]  R1434     -3.4987998008728027e-01
    z[4,3,0]  R1435     -5.3841060400009155e-01
    z[4,3,0]  R1436     1.6175134107470512e-02
    z[4,3,0]  R1437     1.9008865579962730e-02
    z[4,3,0]  R1438     -1.1379750072956085e-01
    z[4,3,0]  R1439     8.3032414317131042e-02
    z[4,3,0]  R1440     -6.1901800334453583e-02
    z[4,3,0]  R1441     2.9676225781440735e-01
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R1320     -1
    z[4,3,1]  R1321     1
    z[4,3,1]  R1332     8.6098372936248779e-02
    z[4,3,1]  R1333     4.0809374302625656e-02
    z[4,3,1]  R1334     1.4856897294521332e-02
    z[4,3,1]  R1335     3.5770680755376816e-02
    z[4,3,1]  R1336     2.9243474826216698e-02
    z[4,3,1]  R1337     3.3882107585668564e-02
    z[4,3,1]  R1338     4.2408645153045654e-02
    z[4,3,1]  R1339     -2.6837334036827087e-02
    z[4,3,1]  R1340     -9.8626506328582764e-01
    z[4,3,1]  R1341     -7.7075231075286865e-01
    z[4,3,1]  R1342     3.3755227923393250e-01
    z[4,3,1]  R1343     4.6453335881233215e-01
    z[4,3,1]  R1344     2.0314882695674896e-01
    z[4,3,1]  R1345     -4.5288348197937012e-01
    z[4,3,1]  R1346     -2.2510962188243866e-01
    z[4,3,1]  R1347     7.5029619038105011e-02
    z[4,3,1]  R1348     -1.1169072240591049e-01
    z[4,3,1]  R1349     -2.0647212862968445e-01
    z[4,3,1]  R1350     3.1193214654922485e-01
    z[4,3,1]  R1351     1.0958223044872284e-01
    z[4,3,1]  R1352     7.0791471004486084e-01
    z[4,3,1]  R1353     7.0677822828292847e-01
    z[4,3,1]  R1354     -9.4216220080852509e-02
    z[4,3,1]  R1355     -1.8292379379272461e-01
    z[4,3,1]  R1356     -3.1834807991981506e-01
    z[4,3,1]  R1357     -2.9790893197059631e-02
    z[4,3,1]  R1358     -6.2753939628601074e-01
    z[4,3,1]  R1359     -2.8487288951873779e-01
    z[4,3,1]  R1360     -2.7020066976547241e-01
    z[4,3,1]  R1361     -8.7465830147266388e-02
    z[4,3,1]  R1362     9.1370832920074463e-01
    z[4,3,1]  R1363     6.0478651523590088e-01
    z[4,3,1]  R1364     -5.3782677650451660e-01
    z[4,3,1]  R1365     -2.0813673734664917e-01
    z[4,3,1]  R1366     -1.4956003427505493e-01
    z[4,3,1]  R1367     -9.1522234678268433e-01
    z[4,3,1]  R1368     -3.5401773452758789e-01
    z[4,3,1]  R1369     -7.9296404123306274e-01
    z[4,3,1]  R1370     -7.6892828941345215e-01
    z[4,3,1]  R1371     -7.2409129142761230e-01
    z[4,3,1]  R1372     2.1006102859973907e-01
    z[4,3,1]  R1373     -0.37724769115448
    z[4,3,1]  R1374     -2.4791140854358673e-01
    z[4,3,1]  R1375     -8.7415516376495361e-01
    z[4,3,1]  R1376     -8.2212585210800171e-01
    z[4,3,1]  R1377     -7.7263385057449341e-01
    z[4,3,1]  R1378     -8.1514602899551392e-01
    z[4,3,1]  R1379     -6.6241323947906494e-01
    z[4,3,1]  R1380     -5.7923221588134766e-01
    z[4,3,1]  R1381     -8.5195028781890869e-01
    z[4,3,1]  R1382     -3.8943392038345337e-01
    z[4,3,1]  R1383     1.0056421905755997e-01
    z[4,3,1]  R1384     1.5411810576915741e-01
    z[4,3,1]  R1385     -7.9090172052383423e-01
    z[4,3,1]  R1386     -0.0875360444188118
    z[4,3,1]  R1387     -6.2563389539718628e-01
    z[4,3,1]  R1388     -0.704354465007782
    z[4,3,1]  R1389     -7.9132989048957825e-02
    z[4,3,1]  R1390     -6.2296229600906372e-01
    z[4,3,1]  R1391     -6.6563093662261963e-01
    z[4,3,1]  R1392     -4.1182957589626312e-02
    z[4,3,1]  R1393     -3.4564676880836487e-01
    z[4,3,1]  R1394     2.8088864684104919e-01
    z[4,3,1]  R1395     3.0188298225402832e-01
    z[4,3,1]  R1396     6.1274491250514984e-02
    z[4,3,1]  R1397     0.0978856310248375
    z[4,3,1]  R1398     2.0466198027133942e-01
    z[4,3,1]  R1399     6.6788643598556519e-03
    z[4,3,1]  R1400     1.1274852603673935e-01
    z[4,3,1]  R1401     4.3839445710182190e-01
    z[4,3,1]  R1402     3.5533255338668823e-01
    z[4,3,1]  R1403     -6.9836688041687012e-01
    z[4,3,1]  R1404     -3.9601841568946838e-01
    z[4,3,1]  R1405     1.1077233403921127e-01
    z[4,3,1]  R1406     2.0387648046016693e-01
    z[4,3,1]  R1407     -2.1392878890037537e-01
    z[4,3,1]  R1408     3.0866166949272156e-01
    z[4,3,1]  R1409     -1.5111443400382996e-01
    z[4,3,1]  R1410     2.5715095922350883e-02
    z[4,3,1]  R1411     -1.4068578183650970e-01
    z[4,3,1]  R1412     -0.302144318819046
    z[4,3,1]  R1413     3.4736540168523788e-02
    z[4,3,1]  R1414     -1.4574143290519714e-01
    z[4,3,1]  R1415     -2.2250409424304962e-01
    z[4,3,1]  R1416     -4.6310713887214661e-01
    z[4,3,1]  R1417     2.1093061566352844e-01
    z[4,3,1]  R1418     -8.5881382226943970e-01
    z[4,3,1]  R1419     -4.4231769442558289e-01
    z[4,3,1]  R1420     -0.606364369392395
    z[4,3,1]  R1421     -7.1295052766799927e-01
    z[4,3,1]  R1422     7.0980495214462280e-01
    z[4,3,1]  R1423     -4.2589294910430908e-01
    z[4,3,1]  R1424     -1.5035982429981232e-01
    z[4,3,1]  R1425     9.3660390377044678e-01
    z[4,3,1]  R1426     9.3908828496932983e-01
    z[4,3,1]  R1427     8.6301565170288086e-01
    z[4,3,1]  R1428     5.0970077514648438e-01
    z[4,3,1]  R1429     7.0335948467254639e-01
    z[4,3,1]  R1430     2.9809432104229927e-02
    z[4,3,1]  R1431     -9.8309412598609924e-02
    z[4,3,1]  R1432     6.9336611032485962e-01
    z[4,3,1]  R1433     -6.0947406291961670e-01
    z[4,3,1]  R1434     -2.0571936666965485e-01
    z[4,3,1]  R1435     -7.4226832389831543e-01
    z[4,3,1]  R1436     1.8295995891094208e-01
    z[4,3,1]  R1437     6.1455290764570236e-02
    z[4,3,1]  R1438     1.7191922664642334e-01
    z[4,3,1]  R1439     2.5506317615509033e-01
    z[4,3,1]  R1440     9.5106415450572968e-02
    z[4,3,1]  R1441     -8.0855406820774078e-02
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R1322     -1
    z[4,3,2]  R1323     1
    z[4,3,2]  R1332     8.7004798650741577e-01
    z[4,3,2]  R1333     -3.1570014357566833e-01
    z[4,3,2]  R1334     -3.2411649823188782e-01
    z[4,3,2]  R1335     -4.5273759961128235e-01
    z[4,3,2]  R1336     -3.1902936100959778e-01
    z[4,3,2]  R1337     -3.8057672977447510e-01
    z[4,3,2]  R1338     2.3256923258304596e-01
    z[4,3,2]  R1339     -5.2614736557006836e-01
    z[4,3,2]  R1340     3.5125121474266052e-02
    z[4,3,2]  R1341     -0.135227769613266
    z[4,3,2]  R1342     -6.6119629144668579e-01
    z[4,3,2]  R1343     2.4024224281311035e-01
    z[4,3,2]  R1344     -3.2324683666229248e-01
    z[4,3,2]  R1345     2.6352068781852722e-01
    z[4,3,2]  R1346     1.5180575847625732e-01
    z[4,3,2]  R1347     1.7123924195766449e-01
    z[4,3,2]  R1348     -3.2004401087760925e-02
    z[4,3,2]  R1349     4.7869232296943665e-01
    z[4,3,2]  R1350     3.6024913191795349e-01
    z[4,3,2]  R1351     6.1882162094116211e-01
    z[4,3,2]  R1352     -3.1423881649971008e-01
    z[4,3,2]  R1353     2.6292544603347778e-01
    z[4,3,2]  R1354     2.8887814283370972e-01
    z[4,3,2]  R1355     7.3006629943847656e-01
    z[4,3,2]  R1356     3.7077632546424866e-01
    z[4,3,2]  R1357     4.2833951115608215e-01
    z[4,3,2]  R1358     -2.1611212193965912e-01
    z[4,3,2]  R1359     7.2118914127349854e-01
    z[4,3,2]  R1360     4.2355710268020630e-01
    z[4,3,2]  R1361     3.1084164977073669e-01
    z[4,3,2]  R1362     -1.4423248171806335e-01
    z[4,3,2]  R1363     6.9796758890151978e-01
    z[4,3,2]  R1364     -4.3535566329956055e-01
    z[4,3,2]  R1365     -6.3349805772304535e-02
    z[4,3,2]  R1366     -2.9123482108116150e-01
    z[4,3,2]  R1367     -3.1179878115653992e-01
    z[4,3,2]  R1368     2.2285149991512299e-01
    z[4,3,2]  R1369     -0.224463552236557
    z[4,3,2]  R1370     -3.3415627479553223e-01
    z[4,3,2]  R1371     1.4328600466251373e-01
    z[4,3,2]  R1372     -4.3183878064155579e-01
    z[4,3,2]  R1373     -1.9323955476284027e-01
    z[4,3,2]  R1374     2.3670576512813568e-01
    z[4,3,2]  R1375     -4.6494167298078537e-02
    z[4,3,2]  R1376     -2.1576589345932007e-01
    z[4,3,2]  R1377     -1.8845294415950775e-01
    z[4,3,2]  R1378     8.5460282862186432e-02
    z[4,3,2]  R1379     9.2955529689788818e-02
    z[4,3,2]  R1380     1.5348492562770844e-01
    z[4,3,2]  R1381     3.5969346761703491e-01
    z[4,3,2]  R1382     -1.3613632321357727e-01
    z[4,3,2]  R1383     -3.2119369506835938e-01
    z[4,3,2]  R1384     0.11175537109375
    z[4,3,2]  R1385     3.1654998660087585e-02
    z[4,3,2]  R1386     8.4770750999450684e-01
    z[4,3,2]  R1387     -1.4828373491764069e-01
    z[4,3,2]  R1388     2.9359790682792664e-01
    z[4,3,2]  R1389     0.686779260635376
    z[4,3,2]  R1390     -3.4933474659919739e-01
    z[4,3,2]  R1391     -1.5206056833267212e-01
    z[4,3,2]  R1392     1.1364550888538361e-01
    z[4,3,2]  R1393     3.4251266717910767e-01
    z[4,3,2]  R1394     8.4152139723300934e-02
    z[4,3,2]  R1395     -7.0116829872131348e-01
    z[4,3,2]  R1396     0.310958594083786
    z[4,3,2]  R1397     -4.8581293225288391e-01
    z[4,3,2]  R1398     1.5351407229900360e-01
    z[4,3,2]  R1399     -2.2517786920070648e-01
    z[4,3,2]  R1400     2.1858850494027138e-02
    z[4,3,2]  R1401     -4.2397168278694153e-01
    z[4,3,2]  R1402     1.2479174137115479e-01
    z[4,3,2]  R1403     4.9236118793487549e-01
    z[4,3,2]  R1404     7.7350640296936035e-01
    z[4,3,2]  R1405     4.2019265890121460e-01
    z[4,3,2]  R1406     3.5428783297538757e-01
    z[4,3,2]  R1407     3.6612513661384583e-01
    z[4,3,2]  R1408     1.0885686427354813e-01
    z[4,3,2]  R1409     5.1020783185958862e-01
    z[4,3,2]  R1410     6.2840634584426880e-01
    z[4,3,2]  R1411     9.5704257488250732e-02
    z[4,3,2]  R1412     4.8155072331428528e-01
    z[4,3,2]  R1413     0.616873025894165
    z[4,3,2]  R1414     4.6412819623947144e-01
    z[4,3,2]  R1415     1.1298055946826935e-01
    z[4,3,2]  R1416     4.5124284923076630e-02
    z[4,3,2]  R1417     6.3735512085258961e-03
    z[4,3,2]  R1418     -2.0513303577899933e-01
    z[4,3,2]  R1419     -1.2549702823162079e-01
    z[4,3,2]  R1420     -1.3414016366004944e-01
    z[4,3,2]  R1421     2.1963019669055939e-01
    z[4,3,2]  R1422     -4.5000827312469482e-01
    z[4,3,2]  R1423     8.7170645594596863e-02
    z[4,3,2]  R1424     2.8488731384277344e-01
    z[4,3,2]  R1425     2.7279371395707130e-02
    z[4,3,2]  R1426     -1.3675086200237274e-01
    z[4,3,2]  R1427     3.0031827092170715e-01
    z[4,3,2]  R1428     -6.9078212976455688e-01
    z[4,3,2]  R1429     -5.2651494741439819e-01
    z[4,3,2]  R1430     2.8083970770239830e-02
    z[4,3,2]  R1431     2.4156154692173004e-01
    z[4,3,2]  R1432     -5.5537432432174683e-01
    z[4,3,2]  R1433     2.1817199885845184e-01
    z[4,3,2]  R1434     2.2642841935157776e-01
    z[4,3,2]  R1435     -1.9141036272048950e-01
    z[4,3,2]  R1436     1.1570196598768234e-01
    z[4,3,2]  R1437     -0.0828382596373558
    z[4,3,2]  R1438     2.0725773274898529e-01
    z[4,3,2]  R1439     8.0018816515803337e-03
    z[4,3,2]  R1440     -3.0644190311431885e-01
    z[4,3,2]  R1441     -1.1769544333219528e-01
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R1324     -1
    z[4,3,3]  R1325     1
    z[4,3,3]  R1332     -2.4330346286296844e-01
    z[4,3,3]  R1333     6.4088380336761475e-01
    z[4,3,3]  R1334     8.3118927478790283e-01
    z[4,3,3]  R1335     5.0202047824859619e-01
    z[4,3,3]  R1336     6.1825442314147949e-01
    z[4,3,3]  R1337     5.3561651706695557e-01
    z[4,3,3]  R1338     -2.1502526104450226e-01
    z[4,3,3]  R1339     3.4871095418930054e-01
    z[4,3,3]  R1340     6.1747943982481956e-03
    z[4,3,3]  R1341     -7.8910492360591888e-02
    z[4,3,3]  R1342     -4.9729026854038239e-02
    z[4,3,3]  R1343     -1.3379671610891819e-02
    z[4,3,3]  R1344     -3.6287495493888855e-01
    z[4,3,3]  R1345     -6.2828463315963745e-01
    z[4,3,3]  R1346     -7.9960060119628906e-01
    z[4,3,3]  R1347     -5.5615299940109253e-01
    z[4,3,3]  R1348     -8.0680477619171143e-01
    z[4,3,3]  R1349     -5.9920346736907959e-01
    z[4,3,3]  R1350     -4.7588801383972168e-01
    z[4,3,3]  R1351     -1.9305257499217987e-01
    z[4,3,3]  R1352     -2.4466849863529205e-01
    z[4,3,3]  R1353     -2.2717629373073578e-01
    z[4,3,3]  R1354     6.1988256871700287e-02
    z[4,3,3]  R1355     -4.9140679836273193e-01
    z[4,3,3]  R1356     -0.562491238117218
    z[4,3,3]  R1357     -6.5210080146789551e-01
    z[4,3,3]  R1358     2.4216838181018829e-01
    z[4,3,3]  R1359     -4.3520128726959229e-01
    z[4,3,3]  R1360     -5.5447423458099365e-01
    z[4,3,3]  R1361     -8.6597663164138794e-01
    z[4,3,3]  R1362     -8.7393987923860550e-03
    z[4,3,3]  R1363     -0.0466126874089241
    z[4,3,3]  R1364     1.2584270536899567e-01
    z[4,3,3]  R1365     3.3088415861129761e-01
    z[4,3,3]  R1366     -2.1796119399368763e-03
    z[4,3,3]  R1367     -2.2579845041036606e-02
    z[4,3,3]  R1368     -5.8057314157485962e-01
    z[4,3,3]  R1369     9.4112195074558258e-03
    z[4,3,3]  R1370     -1.8776719272136688e-01
    z[4,3,3]  R1371     -0.0934593677520752
    z[4,3,3]  R1372     1.7307612299919128e-01
    z[4,3,3]  R1373     8.0016024410724640e-02
    z[4,3,3]  R1374     -7.9326313734054565e-01
    z[4,3,3]  R1375     4.2148139327764511e-02
    z[4,3,3]  R1376     2.2905036807060242e-01
    z[4,3,3]  R1377     1.7671939730644226e-01
    z[4,3,3]  R1378     -5.6692283600568771e-02
    z[4,3,3]  R1379     2.2062557935714722e-01
    z[4,3,3]  R1380     2.2669243812561035e-01
    z[4,3,3]  R1381     -1.0020788758993149e-01
    z[4,3,3]  R1382     4.5321959257125854e-01
    z[4,3,3]  R1383     4.4695851206779480e-01
    z[4,3,3]  R1384     9.3673390150070190e-01
    z[4,3,3]  R1385     1.9504196941852570e-01
    z[4,3,3]  R1386     -2.9698863625526428e-01
    z[4,3,3]  R1387     -0.0312623456120491
    z[4,3,3]  R1388     -2.2925306856632233e-01
    z[4,3,3]  R1389     -4.2882928252220154e-01
    z[4,3,3]  R1390     6.9269701838493347e-02
    z[4,3,3]  R1391     3.7578254938125610e-01
    z[4,3,3]  R1392     -8.1052398681640625e-01
    z[4,3,3]  R1393     -5.8123838901519775e-01
    z[4,3,3]  R1394     -0.560954213142395
    z[4,3,3]  R1395     1.1045350879430771e-01
    z[4,3,3]  R1396     -3.7698951363563538e-01
    z[4,3,3]  R1397     4.2962488532066345e-01
    z[4,3,3]  R1398     -4.0225467085838318e-01
    z[4,3,3]  R1399     -5.8202630281448364e-01
    z[4,3,3]  R1400     -4.1785049438476562e-01
    z[4,3,3]  R1401     -3.0952779576182365e-02
    z[4,3,3]  R1402     2.3720730841159821e-01
    z[4,3,3]  R1403     6.9490201771259308e-02
    z[4,3,3]  R1404     1.2240605801343918e-01
    z[4,3,3]  R1405     -6.0070788860321045e-01
    z[4,3,3]  R1406     -0.522066593170166
    z[4,3,3]  R1407     3.8913151621818542e-01
    z[4,3,3]  R1408     3.6415389180183411e-01
    z[4,3,3]  R1409     -1.9415524601936340e-01
    z[4,3,3]  R1410     -3.3607918024063110e-01
    z[4,3,3]  R1411     -3.9141789078712463e-01
    z[4,3,3]  R1412     -8.4982894361019135e-02
    z[4,3,3]  R1413     -5.5730760097503662e-01
    z[4,3,3]  R1414     -9.1690264642238617e-02
    z[4,3,3]  R1415     -7.2996979951858521e-01
    z[4,3,3]  R1416     -5.5128979682922363e-01
    z[4,3,3]  R1417     -0.838477373123169
    z[4,3,3]  R1418     -2.7604243159294128e-01
    z[4,3,3]  R1419     6.3116061687469482e-01
    z[4,3,3]  R1420     -4.3238624930381775e-02
    z[4,3,3]  R1421     3.6420649290084839e-01
    z[4,3,3]  R1422     -3.9759587496519089e-02
    z[4,3,3]  R1423     -2.7081990242004395e-01
    z[4,3,3]  R1424     3.9089463651180267e-02
    z[4,3,3]  R1425     -1.4939683675765991e-01
    z[4,3,3]  R1426     1.0562177002429962e-01
    z[4,3,3]  R1427     4.4475674629211426e-02
    z[4,3,3]  R1428     2.0891658961772919e-01
    z[4,3,3]  R1429     0.14479960501194
    z[4,3,3]  R1430     -2.2908157110214233e-01
    z[4,3,3]  R1431     -8.4188235923647881e-03
    z[4,3,3]  R1432     3.7611511349678040e-01
    z[4,3,3]  R1433     -2.1606069058179855e-02
    z[4,3,3]  R1434     -2.7403208613395691e-01
    z[4,3,3]  R1435     1.7212149500846863e-01
    z[4,3,3]  R1436     4.7052096575498581e-02
    z[4,3,3]  R1437     -3.6566668748855591e-01
    z[4,3,3]  R1438     -4.7412046790122986e-01
    z[4,3,3]  R1439     -4.2067438364028931e-01
    z[4,3,3]  R1440     -4.8991143703460693e-01
    z[4,3,3]  R1441     -2.5718429684638977e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R1326     -1
    z[4,3,4]  R1327     1
    z[4,3,4]  R1332     1.7166081070899963e-01
    z[4,3,4]  R1333     2.6555103063583374e-01
    z[4,3,4]  R1334     -3.5666882991790771e-01
    z[4,3,4]  R1335     6.2006723880767822e-01
    z[4,3,4]  R1336     7.9848326742649078e-02
    z[4,3,4]  R1337     5.8126222342252731e-02
    z[4,3,4]  R1338     5.9390628337860107e-01
    z[4,3,4]  R1339     -3.8776338100433350e-01
    z[4,3,4]  R1340     2.5676438584923744e-02
    z[4,3,4]  R1341     3.1820493936538696e-01
    z[4,3,4]  R1342     -1.7874620854854584e-01
    z[4,3,4]  R1343     -2.6201993227005005e-01
    z[4,3,4]  R1344     -1.4919523894786835e-01
    z[4,3,4]  R1345     -2.1776072680950165e-01
    z[4,3,4]  R1346     -3.7224754691123962e-01
    z[4,3,4]  R1347     5.7311993837356567e-01
    z[4,3,4]  R1348     3.3144921064376831e-01
    z[4,3,4]  R1349     -5.3990882635116577e-01
    z[4,3,4]  R1350     3.5976175218820572e-02
    z[4,3,4]  R1351     -0.162450909614563
    z[4,3,4]  R1352     2.7533066272735596e-01
    z[4,3,4]  R1353     2.1661397814750671e-01
    z[4,3,4]  R1354     -3.1194350123405457e-01
    z[4,3,4]  R1355     5.3216083906590939e-03
    z[4,3,4]  R1356     2.2346168756484985e-01
    z[4,3,4]  R1357     1.5192779898643494e-01
    z[4,3,4]  R1358     -2.9828497767448425e-01
    z[4,3,4]  R1359     0.280141681432724
    z[4,3,4]  R1360     -2.0264382660388947e-01
    z[4,3,4]  R1361     2.8758466243743896e-01
    z[4,3,4]  R1362     8.5873436182737350e-04
    z[4,3,4]  R1363     -1.1589819192886353e-01
    z[4,3,4]  R1364     -4.7125168144702911e-02
    z[4,3,4]  R1365     -5.8494526147842407e-01
    z[4,3,4]  R1366     -4.6181634068489075e-01
    z[4,3,4]  R1367     1.4247675240039825e-01
    z[4,3,4]  R1368     -1.6923119127750397e-01
    z[4,3,4]  R1369     -2.9892298579216003e-01
    z[4,3,4]  R1370     3.5811014473438263e-02
    z[4,3,4]  R1371     -1.5946429967880249e-01
    z[4,3,4]  R1372     -5.0564610958099365e-01
    z[4,3,4]  R1373     -1.6528847813606262e-01
    z[4,3,4]  R1374     -3.4734913706779480e-01
    z[4,3,4]  R1375     -2.7560099959373474e-01
    z[4,3,4]  R1376     1.1525370180606842e-01
    z[4,3,4]  R1377     -1.2992176413536072e-01
    z[4,3,4]  R1378     2.5555733591318130e-03
    z[4,3,4]  R1379     4.9524795264005661e-02
    z[4,3,4]  R1380     -1.4719154569320381e-04
    z[4,3,4]  R1381     2.0635944604873657e-01
    z[4,3,4]  R1382     3.4688645601272583e-01
    z[4,3,4]  R1383     5.9636777639389038e-01
    z[4,3,4]  R1384     1.8472562730312347e-01
    z[4,3,4]  R1385     -5.8635283261537552e-02
    z[4,3,4]  R1386     -2.3713652789592743e-01
    z[4,3,4]  R1387     4.5625463128089905e-01
    z[4,3,4]  R1388     1.0159126482903957e-02
    z[4,3,4]  R1389     1.3070702552795410e-01
    z[4,3,4]  R1390     -1.1682728677988052e-01
    z[4,3,4]  R1391     -4.6683631837368011e-02
    z[4,3,4]  R1392     3.4998500347137451e-01
    z[4,3,4]  R1393     1.3148643076419830e-01
    z[4,3,4]  R1394     5.9449046850204468e-01
    z[4,3,4]  R1395     -4.5888105034828186e-01
    z[4,3,4]  R1396     3.9809507131576538e-01
    z[4,3,4]  R1397     -6.9887173175811768e-01
    z[4,3,4]  R1398     3.2974988222122192e-01
    z[4,3,4]  R1399     4.0062639117240906e-01
    z[4,3,4]  R1400     1.9780324399471283e-01
    z[4,3,4]  R1401     -5.7936644554138184e-01
    z[4,3,4]  R1402     -0.341208279132843
    z[4,3,4]  R1403     -2.5814184546470642e-01
    z[4,3,4]  R1404     2.8583295643329620e-03
    z[4,3,4]  R1405     5.9135907888412476e-01
    z[4,3,4]  R1406     2.5743296742439270e-01
    z[4,3,4]  R1407     -5.7720959186553955e-01
    z[4,3,4]  R1408     -5.6938838958740234e-01
    z[4,3,4]  R1409     6.3056260347366333e-01
    z[4,3,4]  R1410     0.110362209379673
    z[4,3,4]  R1411     6.8434321880340576e-01
    z[4,3,4]  R1412     -1.5113914012908936e-01
    z[4,3,4]  R1413     2.0056955516338348e-01
    z[4,3,4]  R1414     4.2378431558609009e-01
    z[4,3,4]  R1415     5.9284854680299759e-02
    z[4,3,4]  R1416     2.3376183211803436e-01
    z[4,3,4]  R1417     1.8640869855880737e-01
    z[4,3,4]  R1418     5.0026741810142994e-03
    z[4,3,4]  R1419     -0.529833972454071
    z[4,3,4]  R1420     -2.1755275130271912e-01
    z[4,3,4]  R1421     3.9323933422565460e-02
    z[4,3,4]  R1422     -2.9293003678321838e-01
    z[4,3,4]  R1423     1.9246637821197510e-01
    z[4,3,4]  R1424     4.1980087757110596e-01
    z[4,3,4]  R1425     -0.105362668633461
    z[4,3,4]  R1426     -9.4741076231002808e-02
    z[4,3,4]  R1427     2.9477930068969727e-01
    z[4,3,4]  R1428     6.4331911504268646e-02
    z[4,3,4]  R1429     -3.6906756460666656e-02
    z[4,3,4]  R1430     -5.6205880641937256e-01
    z[4,3,4]  R1431     -5.7529205083847046e-01
    z[4,3,4]  R1432     -1.3045415282249451e-01
    z[4,3,4]  R1433     -4.6280416846275330e-01
    z[4,3,4]  R1434     6.5524756908416748e-01
    z[4,3,4]  R1435     1.6345609724521637e-01
    z[4,3,4]  R1436     -1.2294919788837433e-01
    z[4,3,4]  R1437     -8.3895868062973022e-01
    z[4,3,4]  R1438     -8.0667078495025635e-01
    z[4,3,4]  R1439     -7.0341515541076660e-01
    z[4,3,4]  R1440     -6.1113911867141724e-01
    z[4,3,4]  R1441     -6.0859465599060059e-01
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R1328     -1
    z[4,3,5]  R1329     1
    z[4,3,5]  R1332     -8.7248824536800385e-02
    z[4,3,5]  R1333     -3.4173485636711121e-01
    z[4,3,5]  R1334     -2.6238659024238586e-01
    z[4,3,5]  R1335     -3.4383806586265564e-01
    z[4,3,5]  R1336     9.3546412885189056e-02
    z[4,3,5]  R1337     -6.0945028066635132e-01
    z[4,3,5]  R1338     -4.6668532490730286e-01
    z[4,3,5]  R1339     3.9792710542678833e-01
    z[4,3,5]  R1340     1.2828531861305237e-01
    z[4,3,5]  R1341     9.0913869440555573e-02
    z[4,3,5]  R1342     4.4212940335273743e-01
    z[4,3,5]  R1343     7.7977198362350464e-01
    z[4,3,5]  R1344     -4.2695045471191406e-01
    z[4,3,5]  R1345     3.7409138679504395e-01
    z[4,3,5]  R1346     9.4170890748500824e-02
    z[4,3,5]  R1347     3.5449784994125366e-01
    z[4,3,5]  R1348     3.2058224081993103e-01
    z[4,3,5]  R1349     0.0108823636546731
    z[4,3,5]  R1350     -0.0410323366522789
    z[4,3,5]  R1351     5.7950407266616821e-02
    z[4,3,5]  R1352     -2.5654423981904984e-02
    z[4,3,5]  R1353     -3.8571065664291382e-01
    z[4,3,5]  R1354     -2.5312250852584839e-01
    z[4,3,5]  R1355     2.0238001644611359e-01
    z[4,3,5]  R1356     4.6938553452491760e-01
    z[4,3,5]  R1357     1.9093506038188934e-01
    z[4,3,5]  R1358     0.0532853901386261
    z[4,3,5]  R1359     2.6255580782890320e-01
    z[4,3,5]  R1360     2.5324231386184692e-01
    z[4,3,5]  R1361     2.3000319302082062e-01
    z[4,3,5]  R1362     -2.4678705632686615e-01
    z[4,3,5]  R1363     -3.2962822914123535e-01
    z[4,3,5]  R1364     2.6725775003433228e-01
    z[4,3,5]  R1365     -2.3675398528575897e-01
    z[4,3,5]  R1366     -6.3373476266860962e-02
    z[4,3,5]  R1367     2.2593397647142410e-02
    z[4,3,5]  R1368     4.6157222986221313e-01
    z[4,3,5]  R1369     -2.4501267075538635e-01
    z[4,3,5]  R1370     -2.2183151543140411e-01
    z[4,3,5]  R1371     -1.8626582622528076e-01
    z[4,3,5]  R1372     1.2021089345216751e-01
    z[4,3,5]  R1373     -1.2923605740070343e-01
    z[4,3,5]  R1374     2.9020580649375916e-01
    z[4,3,5]  R1375     -2.4687018990516663e-01
    z[4,3,5]  R1376     -7.4510313570499420e-02
    z[4,3,5]  R1377     1.5238919854164124e-01
    z[4,3,5]  R1378     -4.1781923174858093e-01
    z[4,3,5]  R1379     -2.3594839870929718e-01
    z[4,3,5]  R1380     1.7438188195228577e-01
    z[4,3,5]  R1381     -2.5090718269348145e-01
    z[4,3,5]  R1382     -0.553044319152832
    z[4,3,5]  R1383     -4.2993504554033279e-02
    z[4,3,5]  R1384     1.1749506741762161e-01
    z[4,3,5]  R1385     1.4075703918933868e-01
    z[4,3,5]  R1386     3.2285955548286438e-01
    z[4,3,5]  R1387     7.0158019661903381e-02
    z[4,3,5]  R1388     -1.0275598615407944e-01
    z[4,3,5]  R1389     0.0361696258187294
    z[4,3,5]  R1390     -3.3468861132860184e-02
    z[4,3,5]  R1391     1.3391450047492981e-01
    z[4,3,5]  R1392     2.3491376638412476e-01
    z[4,3,5]  R1393     5.3270930051803589e-01
    z[4,3,5]  R1394     4.1350486874580383e-01
    z[4,3,5]  R1395     -4.1556110978126526e-01
    z[4,3,5]  R1396     6.7152678966522217e-01
    z[4,3,5]  R1397     -0.263075053691864
    z[4,3,5]  R1398     5.5658805370330811e-01
    z[4,3,5]  R1399     5.5850416421890259e-01
    z[4,3,5]  R1400     5.6426358222961426e-01
    z[4,3,5]  R1401     -3.5225117206573486e-01
    z[4,3,5]  R1402     -5.2893179655075073e-01
    z[4,3,5]  R1403     1.7745985090732574e-01
    z[4,3,5]  R1404     3.4801909327507019e-01
    z[4,3,5]  R1405     2.7866625785827637e-01
    z[4,3,5]  R1406     4.0741279721260071e-01
    z[4,3,5]  R1407     2.2728929296135902e-02
    z[4,3,5]  R1408     -2.8804320096969604e-01
    z[4,3,5]  R1409     5.1546716690063477e-01
    z[4,3,5]  R1410     6.7101502418518066e-01
    z[4,3,5]  R1411     5.8186775445938110e-01
    z[4,3,5]  R1412     -1.0468350723385811e-02
    z[4,3,5]  R1413     5.1003140211105347e-01
    z[4,3,5]  R1414     6.9440108537673950e-01
    z[4,3,5]  R1415     5.5458873510360718e-01
    z[4,3,5]  R1416     0.413343220949173
    z[4,3,5]  R1417     2.9687958955764771e-01
    z[4,3,5]  R1418     -2.5644791126251221e-01
    z[4,3,5]  R1419     -6.2193788588047028e-02
    z[4,3,5]  R1420     -2.6785546541213989e-01
    z[4,3,5]  R1421     3.3473879098892212e-01
    z[4,3,5]  R1422     -4.3114152550697327e-01
    z[4,3,5]  R1423     8.2911419868469238e-01
    z[4,3,5]  R1424     2.9068300127983093e-01
    z[4,3,5]  R1425     2.2954536974430084e-01
    z[4,3,5]  R1426     2.1932075917720795e-01
    z[4,3,5]  R1427     2.2315025329589844e-01
    z[4,3,5]  R1428     2.0577101409435272e-01
    z[4,3,5]  R1429     3.7524858117103577e-01
    z[4,3,5]  R1430     5.0734555721282959e-01
    z[4,3,5]  R1431     4.7492590546607971e-01
    z[4,3,5]  R1432     -2.1041874587535858e-01
    z[4,3,5]  R1433     -2.5743770599365234e-01
    z[4,3,5]  R1434     1.7963384091854095e-01
    z[4,3,5]  R1435     2.0145660638809204e-01
    z[4,3,5]  R1436     -7.7882564067840576e-01
    z[4,3,5]  R1437     3.7007558345794678e-01
    z[4,3,5]  R1438     1.8400555849075317e-01
    z[4,3,5]  R1439     3.5417270660400391e-01
    z[4,3,5]  R1440     4.2507287859916687e-01
    z[4,3,5]  R1441     6.5993052721023560e-01
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R1330     -1
    z[4,3,6]  R1331     1
    z[4,3,6]  R1332     -1.8227215111255646e-01
    z[4,3,6]  R1333     4.8308894038200378e-01
    z[4,3,6]  R1334     -5.2540283650159836e-03
    z[4,3,6]  R1335     -1.7118491232395172e-01
    z[4,3,6]  R1336     -1.2941205501556396e-01
    z[4,3,6]  R1337     0.259101003408432
    z[4,3,6]  R1338     2.1217225492000580e-01
    z[4,3,6]  R1339     -2.0377086102962494e-01
    z[4,3,6]  R1340     4.9424994736909866e-02
    z[4,3,6]  R1341     3.2052415609359741e-01
    z[4,3,6]  R1342     -1.9010773301124573e-01
    z[4,3,6]  R1343     8.6065813899040222e-02
    z[4,3,6]  R1344     -7.1420705318450928e-01
    z[4,3,6]  R1345     -3.7376844882965088e-01
    z[4,3,6]  R1346     -1.0020061582326889e-01
    z[4,3,6]  R1347     3.3467730879783630e-01
    z[4,3,6]  R1348     -3.2956176996231079e-01
    z[4,3,6]  R1349     2.2259773313999176e-01
    z[4,3,6]  R1350     -2.7017902582883835e-02
    z[4,3,6]  R1351     1.3021923601627350e-01
    z[4,3,6]  R1352     8.4782741963863373e-02
    z[4,3,6]  R1353     2.4156148731708527e-01
    z[4,3,6]  R1354     -4.8951196670532227e-01
    z[4,3,6]  R1355     -2.1152982115745544e-01
    z[4,3,6]  R1356     -0.0820658802986145
    z[4,3,6]  R1357     -3.3595755696296692e-02
    z[4,3,6]  R1358     -4.2025718092918396e-01
    z[4,3,6]  R1359     1.0127981007099152e-01
    z[4,3,6]  R1360     2.3284368216991425e-01
    z[4,3,6]  R1361     -4.9966756254434586e-02
    z[4,3,6]  R1362     1.9454509019851685e-01
    z[4,3,6]  R1363     2.5387939065694809e-02
    z[4,3,6]  R1364     -2.3479017615318298e-01
    z[4,3,6]  R1365     -5.6522661447525024e-01
    z[4,3,6]  R1366     -3.1581774353981018e-01
    z[4,3,6]  R1367     -1.6999433934688568e-01
    z[4,3,6]  R1368     -4.7128465771675110e-01
    z[4,3,6]  R1369     -1.0066631436347961e-01
    z[4,3,6]  R1370     1.6159044206142426e-01
    z[4,3,6]  R1371     -2.1938814222812653e-01
    z[4,3,6]  R1372     -5.0658637285232544e-01
    z[4,3,6]  R1373     -4.6783113479614258e-01
    z[4,3,6]  R1374     1.0208971798419952e-02
    z[4,3,6]  R1375     -1.2860514223575592e-01
    z[4,3,6]  R1376     3.4179106354713440e-01
    z[4,3,6]  R1377     -7.7363565564155579e-02
    z[4,3,6]  R1378     3.2385224103927612e-01
    z[4,3,6]  R1379     1.7104333639144897e-01
    z[4,3,6]  R1380     2.9971027374267578e-01
    z[4,3,6]  R1381     -0.0792362168431282
    z[4,3,6]  R1382     2.2468097507953644e-01
    z[4,3,6]  R1383     -3.2996791601181030e-01
    z[4,3,6]  R1384     1.4762161672115326e-01
    z[4,3,6]  R1385     -4.5040425658226013e-01
    z[4,3,6]  R1386     1.3805608265101910e-02
    z[4,3,6]  R1387     5.8425735682249069e-02
    z[4,3,6]  R1388     3.9670267701148987e-01
    z[4,3,6]  R1389     0.537770688533783
    z[4,3,6]  R1390     -1.8344806134700775e-01
    z[4,3,6]  R1391     -8.5710622370243073e-02
    z[4,3,6]  R1392     -3.8023035973310471e-02
    z[4,3,6]  R1393     -0.269378125667572
    z[4,3,6]  R1394     -2.0136094093322754e-01
    z[4,3,6]  R1395     -1.4751872420310974e-01
    z[4,3,6]  R1396     -2.1189206838607788e-01
    z[4,3,6]  R1397     -1.0805781185626984e-01
    z[4,3,6]  R1398     -5.5326286703348160e-02
    z[4,3,6]  R1399     -2.1189002692699432e-01
    z[4,3,6]  R1400     4.6170207858085632e-01
    z[4,3,6]  R1401     -1.9464819133281708e-01
    z[4,3,6]  R1402     4.3017691373825073e-01
    z[4,3,6]  R1403     -1.5040473639965057e-01
    z[4,3,6]  R1404     6.3325248658657074e-02
    z[4,3,6]  R1405     1.1317790299654007e-01
    z[4,3,6]  R1406     1.9343329966068268e-01
    z[4,3,6]  R1407     -7.9061530530452728e-02
    z[4,3,6]  R1408     -9.6641272306442261e-02
    z[4,3,6]  R1409     -1.0856087505817413e-01
    z[4,3,6]  R1410     -1.6978496313095093e-01
    z[4,3,6]  R1411     -2.2336056455969810e-02
    z[4,3,6]  R1412     -1.4777894318103790e-01
    z[4,3,6]  R1413     9.7572272352408618e-05
    z[4,3,6]  R1414     -1.1589463800191879e-01
    z[4,3,6]  R1415     2.8197151422500610e-01
    z[4,3,6]  R1416     2.7002471685409546e-01
    z[4,3,6]  R1417     8.2531832158565521e-02
    z[4,3,6]  R1418     -1.7834395170211792e-02
    z[4,3,6]  R1419     1.0257884860038757e-01
    z[4,3,6]  R1420     3.3247941732406616e-01
    z[4,3,6]  R1421     3.5234186798334122e-02
    z[4,3,6]  R1422     0.0984724834561348
    z[4,3,6]  R1423     1.1448633670806885e-01
    z[4,3,6]  R1424     7.1404480934143066e-01
    z[4,3,6]  R1425     -1.8833881616592407e-01
    z[4,3,6]  R1426     -7.0366062223911285e-02
    z[4,3,6]  R1427     6.7802697420120239e-02
    z[4,3,6]  R1428     1.1730934679508209e-01
    z[4,3,6]  R1429     -6.0412295162677765e-02
    z[4,3,6]  R1430     -2.2613309323787689e-01
    z[4,3,6]  R1431     2.3787630721926689e-02
    z[4,3,6]  R1432     7.1329828351736069e-03
    z[4,3,6]  R1433     -7.9224541783332825e-02
    z[4,3,6]  R1434     4.9727505445480347e-01
    z[4,3,6]  R1435     -1.5995460748672485e-01
    z[4,3,6]  R1436     -5.7356536388397217e-01
    z[4,3,6]  R1437     1.2033274024724960e-01
    z[4,3,6]  R1438     -7.1916177868843079e-02
    z[4,3,6]  R1439     -3.6164382100105286e-01
    z[4,3,6]  R1440     -3.1468236446380615e-01
    z[4,3,6]  R1441     -1.3965220749378204e-01
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R1442     -1
    z[4,5,0]  R1443     1
    z[4,5,0]  R1456     -3.2573610544204712e-01
    z[4,5,0]  R1457     -2.5934723019599915e-01
    z[4,5,0]  R1458     8.8120587170124054e-02
    z[4,5,0]  R1459     9.8550565540790558e-02
    z[4,5,0]  R1460     6.9516366720199585e-01
    z[4,5,0]  R1461     3.5381710529327393e-01
    z[4,5,0]  R1462     5.3135710954666138e-01
    z[4,5,0]  R1463     5.0062006711959839e-01
    z[4,5,0]  R1464     -0.0803113803267479
    z[4,5,0]  R1465     -4.1130515933036804e-01
    z[4,5,0]  R1466     -0.427592396736145
    z[4,5,0]  R1467     2.0544408261775970e-01
    z[4,5,0]  R1468     0.0890294685959816
    z[4,5,0]  R1469     -6.0372769832611084e-02
    z[4,5,0]  R1470     -3.5978186130523682e-01
    z[4,5,0]  R1471     -2.9932841658592224e-01
    z[4,5,0]  R1472     -1.1968418210744858e-01
    z[4,5,0]  R1473     -1.6735707223415375e-01
    z[4,5,0]  R1474     -7.3670989274978638e-01
    z[4,5,0]  R1475     -7.2185647487640381e-01
    z[4,5,0]  R1476     5.0655186176300049e-01
    z[4,5,0]  R1477     -3.5451275110244751e-01
    z[4,5,0]  R1478     7.0910400152206421e-01
    z[4,5,0]  R1479     -3.2608368992805481e-01
    z[4,5,0]  R1480     -4.0962222218513489e-01
    z[4,5,0]  R1481     -5.7422578334808350e-01
    z[4,5,0]  R1482     4.8209443688392639e-01
    z[4,5,0]  R1483     -2.2729055583477020e-01
    z[4,5,0]  R1484     -5.2984601259231567e-01
    z[4,5,0]  R1485     -8.7798461318016052e-02
    z[4,5,0]  R1486     -2.1332009136676788e-01
    z[4,5,0]  R1487     1.4889524877071381e-01
    z[4,5,0]  R1488     6.1367547512054443e-01
    z[4,5,0]  R1489     3.5424154996871948e-01
    z[4,5,0]  R1490     7.5880038738250732e-01
    z[4,5,0]  R1491     -1.2219431251287460e-01
    z[4,5,0]  R1492     -1.5539045631885529e-01
    z[4,5,0]  R1493     -4.0151676535606384e-01
    z[4,5,0]  R1494     -4.3038254976272583e-01
    z[4,5,0]  R1495     -5.8152490854263306e-01
    z[4,5,0]  R1496     4.6116787195205688e-01
    z[4,5,0]  R1497     7.4232870340347290e-01
    z[4,5,0]  R1498     -2.1970137953758240e-01
    z[4,5,0]  R1499     -2.8013315796852112e-01
    z[4,5,0]  R1500     -2.9905471205711365e-01
    z[4,5,0]  R1501     -5.3870719671249390e-01
    z[4,5,0]  R1502     -2.1344721317291260e-01
    z[4,5,0]  R1503     -6.4537745714187622e-01
    z[4,5,0]  R1504     -6.8506032228469849e-01
    z[4,5,0]  R1505     -1.5146845579147339e-01
    z[4,5,0]  R1506     4.9648988246917725e-01
    z[4,5,0]  R1507     -2.6639136672019958e-01
    z[4,5,0]  R1508     -1.2950626015663147e-01
    z[4,5,0]  R1509     -7.9698067903518677e-01
    z[4,5,0]  R1510     -3.7656205892562866e-01
    z[4,5,0]  R1511     -5.1015269756317139e-01
    z[4,5,0]  R1512     -4.2382824420928955e-01
    z[4,5,0]  R1513     -4.6033310890197754e-01
    z[4,5,0]  R1514     -5.0955390930175781e-01
    z[4,5,0]  R1515     0.242109477519989
    z[4,5,0]  R1516     6.1530214548110962e-01
    z[4,5,0]  R1517     -2.3542794585227966e-01
    z[4,5,0]  R1518     1.2747491896152496e-01
    z[4,5,0]  R1519     -1.9518758356571198e-01
    z[4,5,0]  R1520     7.8302729129791260e-01
    z[4,5,0]  R1521     -5.4339367151260376e-01
    z[4,5,0]  R1522     -3.0413594841957092e-01
    z[4,5,0]  R1523     -3.3105167746543884e-01
    z[4,5,0]  R1524     8.1613563001155853e-02
    z[4,5,0]  R1525     2.4063149094581604e-01
    z[4,5,0]  R1526     3.8187541067600250e-02
    z[4,5,0]  R1527     -1.1935734748840332e-01
    z[4,5,0]  R1528     -1.2596021592617035e-01
    z[4,5,0]  R1529     -1.0391132533550262e-01
    z[4,5,0]  R1530     -6.1322432756423950e-01
    z[4,5,0]  R1531     7.5107455253601074e-01
    z[4,5,0]  R1532     5.7250422239303589e-01
    z[4,5,0]  R1533     6.0374909639358521e-01
    z[4,5,0]  R1534     5.4553002119064331e-01
    z[4,5,0]  R1535     5.9053015708923340e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R1444     -1
    z[4,5,1]  R1445     1
    z[4,5,1]  R1456     8.6098372936248779e-02
    z[4,5,1]  R1457     4.0809374302625656e-02
    z[4,5,1]  R1458     1.4856897294521332e-02
    z[4,5,1]  R1459     3.5770680755376816e-02
    z[4,5,1]  R1460     2.9243474826216698e-02
    z[4,5,1]  R1461     3.3882107585668564e-02
    z[4,5,1]  R1462     4.2408645153045654e-02
    z[4,5,1]  R1463     -2.6837334036827087e-02
    z[4,5,1]  R1464     -9.8626506328582764e-01
    z[4,5,1]  R1465     -7.7075231075286865e-01
    z[4,5,1]  R1466     3.3755227923393250e-01
    z[4,5,1]  R1467     4.6453335881233215e-01
    z[4,5,1]  R1468     2.0314882695674896e-01
    z[4,5,1]  R1469     -4.5288348197937012e-01
    z[4,5,1]  R1470     -2.2510962188243866e-01
    z[4,5,1]  R1471     7.5029619038105011e-02
    z[4,5,1]  R1472     -1.1169072240591049e-01
    z[4,5,1]  R1473     -2.0647212862968445e-01
    z[4,5,1]  R1474     3.1193214654922485e-01
    z[4,5,1]  R1475     1.0958223044872284e-01
    z[4,5,1]  R1476     7.0791471004486084e-01
    z[4,5,1]  R1477     7.0677822828292847e-01
    z[4,5,1]  R1478     -9.4216220080852509e-02
    z[4,5,1]  R1479     -1.8292379379272461e-01
    z[4,5,1]  R1480     -3.1834807991981506e-01
    z[4,5,1]  R1481     -2.9790893197059631e-02
    z[4,5,1]  R1482     -6.2753939628601074e-01
    z[4,5,1]  R1483     -2.8487288951873779e-01
    z[4,5,1]  R1484     -2.7020066976547241e-01
    z[4,5,1]  R1485     -8.7465830147266388e-02
    z[4,5,1]  R1486     9.1370832920074463e-01
    z[4,5,1]  R1487     6.0478651523590088e-01
    z[4,5,1]  R1488     -5.3782677650451660e-01
    z[4,5,1]  R1489     -2.0813673734664917e-01
    z[4,5,1]  R1490     -1.4956003427505493e-01
    z[4,5,1]  R1491     -9.1522234678268433e-01
    z[4,5,1]  R1492     -3.5401773452758789e-01
    z[4,5,1]  R1493     -7.9296404123306274e-01
    z[4,5,1]  R1494     -7.6892828941345215e-01
    z[4,5,1]  R1495     -7.2409129142761230e-01
    z[4,5,1]  R1496     2.1006102859973907e-01
    z[4,5,1]  R1497     -0.37724769115448
    z[4,5,1]  R1498     -2.4791140854358673e-01
    z[4,5,1]  R1499     -8.7415516376495361e-01
    z[4,5,1]  R1500     -8.2212585210800171e-01
    z[4,5,1]  R1501     -7.7263385057449341e-01
    z[4,5,1]  R1502     -8.1514602899551392e-01
    z[4,5,1]  R1503     -6.6241323947906494e-01
    z[4,5,1]  R1504     -5.7923221588134766e-01
    z[4,5,1]  R1505     -8.5195028781890869e-01
    z[4,5,1]  R1506     4.3844223022460938e-02
    z[4,5,1]  R1507     -8.0521166324615479e-01
    z[4,5,1]  R1508     1.7489878460764885e-02
    z[4,5,1]  R1509     6.2313683331012726e-02
    z[4,5,1]  R1510     3.1382761895656586e-02
    z[4,5,1]  R1511     -4.2410698533058167e-01
    z[4,5,1]  R1512     -4.4718232750892639e-01
    z[4,5,1]  R1513     -3.6831203103065491e-01
    z[4,5,1]  R1514     -5.1659411191940308e-01
    z[4,5,1]  R1515     1.9754158332943916e-02
    z[4,5,1]  R1516     1.8612654507160187e-01
    z[4,5,1]  R1517     2.8649359941482544e-01
    z[4,5,1]  R1518     8.9528091251850128e-02
    z[4,5,1]  R1519     1.1711125075817108e-01
    z[4,5,1]  R1520     4.3407621979713440e-01
    z[4,5,1]  R1521     8.4541819989681244e-02
    z[4,5,1]  R1522     -3.3135646581649780e-01
    z[4,5,1]  R1523     -1.7478680610656738e-01
    z[4,5,1]  R1524     6.7083835601806641e-01
    z[4,5,1]  R1525     -4.4888365268707275e-01
    z[4,5,1]  R1526     9.6127837896347046e-01
    z[4,5,1]  R1527     8.2246738672256470e-01
    z[4,5,1]  R1528     4.5424845814704895e-01
    z[4,5,1]  R1529     0.443109393119812
    z[4,5,1]  R1530     -3.7199783325195312e-01
    z[4,5,1]  R1531     -3.4101182222366333e-01
    z[4,5,1]  R1532     -4.5097431540489197e-01
    z[4,5,1]  R1533     -3.9959374070167542e-01
    z[4,5,1]  R1534     -2.4694876372814178e-01
    z[4,5,1]  R1535     -5.7367813587188721e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R1446     -1
    z[4,5,2]  R1447     1
    z[4,5,2]  R1456     8.7004798650741577e-01
    z[4,5,2]  R1457     -3.1570014357566833e-01
    z[4,5,2]  R1458     -3.2411649823188782e-01
    z[4,5,2]  R1459     -4.5273759961128235e-01
    z[4,5,2]  R1460     -3.1902936100959778e-01
    z[4,5,2]  R1461     -3.8057672977447510e-01
    z[4,5,2]  R1462     2.3256923258304596e-01
    z[4,5,2]  R1463     -5.2614736557006836e-01
    z[4,5,2]  R1464     3.5125121474266052e-02
    z[4,5,2]  R1465     -0.135227769613266
    z[4,5,2]  R1466     -6.6119629144668579e-01
    z[4,5,2]  R1467     2.4024224281311035e-01
    z[4,5,2]  R1468     -3.2324683666229248e-01
    z[4,5,2]  R1469     2.6352068781852722e-01
    z[4,5,2]  R1470     1.5180575847625732e-01
    z[4,5,2]  R1471     1.7123924195766449e-01
    z[4,5,2]  R1472     -3.2004401087760925e-02
    z[4,5,2]  R1473     4.7869232296943665e-01
    z[4,5,2]  R1474     3.6024913191795349e-01
    z[4,5,2]  R1475     6.1882162094116211e-01
    z[4,5,2]  R1476     -3.1423881649971008e-01
    z[4,5,2]  R1477     2.6292544603347778e-01
    z[4,5,2]  R1478     2.8887814283370972e-01
    z[4,5,2]  R1479     7.3006629943847656e-01
    z[4,5,2]  R1480     3.7077632546424866e-01
    z[4,5,2]  R1481     4.2833951115608215e-01
    z[4,5,2]  R1482     -2.1611212193965912e-01
    z[4,5,2]  R1483     7.2118914127349854e-01
    z[4,5,2]  R1484     4.2355710268020630e-01
    z[4,5,2]  R1485     3.1084164977073669e-01
    z[4,5,2]  R1486     -1.4423248171806335e-01
    z[4,5,2]  R1487     6.9796758890151978e-01
    z[4,5,2]  R1488     -4.3535566329956055e-01
    z[4,5,2]  R1489     -6.3349805772304535e-02
    z[4,5,2]  R1490     -2.9123482108116150e-01
    z[4,5,2]  R1491     -3.1179878115653992e-01
    z[4,5,2]  R1492     2.2285149991512299e-01
    z[4,5,2]  R1493     -0.224463552236557
    z[4,5,2]  R1494     -3.3415627479553223e-01
    z[4,5,2]  R1495     1.4328600466251373e-01
    z[4,5,2]  R1496     -4.3183878064155579e-01
    z[4,5,2]  R1497     -1.9323955476284027e-01
    z[4,5,2]  R1498     2.3670576512813568e-01
    z[4,5,2]  R1499     -4.6494167298078537e-02
    z[4,5,2]  R1500     -2.1576589345932007e-01
    z[4,5,2]  R1501     -1.8845294415950775e-01
    z[4,5,2]  R1502     8.5460282862186432e-02
    z[4,5,2]  R1503     9.2955529689788818e-02
    z[4,5,2]  R1504     1.5348492562770844e-01
    z[4,5,2]  R1505     3.5969346761703491e-01
    z[4,5,2]  R1506     4.8482915759086609e-01
    z[4,5,2]  R1507     -9.0091131627559662e-02
    z[4,5,2]  R1508     7.8116357326507568e-01
    z[4,5,2]  R1509     1.9263638183474541e-02
    z[4,5,2]  R1510     8.7549078464508057e-01
    z[4,5,2]  R1511     1.1950641125440598e-01
    z[4,5,2]  R1512     0.636570155620575
    z[4,5,2]  R1513     -6.6055871546268463e-02
    z[4,5,2]  R1514     2.6292216777801514e-01
    z[4,5,2]  R1515     4.7815990447998047e-01
    z[4,5,2]  R1516     -3.6712530255317688e-01
    z[4,5,2]  R1517     -4.8442426323890686e-01
    z[4,5,2]  R1518     -8.3194905519485474e-01
    z[4,5,2]  R1519     -4.4412112236022949e-01
    z[4,5,2]  R1520     -8.4590762853622437e-02
    z[4,5,2]  R1521     -0.654270589351654
    z[4,5,2]  R1522     -4.4473114609718323e-01
    z[4,5,2]  R1523     -1.5737813711166382e-01
    z[4,5,2]  R1524     4.3987524509429932e-01
    z[4,5,2]  R1525     -0.320712685585022
    z[4,5,2]  R1526     2.4135455489158630e-01
    z[4,5,2]  R1527     -1.4329555444419384e-02
    z[4,5,2]  R1528     -4.6941635012626648e-01
    z[4,5,2]  R1529     -1.7301650345325470e-01
    z[4,5,2]  R1530     4.5983624458312988e-01
    z[4,5,2]  R1531     -0.0899103432893753
    z[4,5,2]  R1532     2.9243247583508492e-02
    z[4,5,2]  R1533     -3.3227629959583282e-02
    z[4,5,2]  R1534     4.6476915478706360e-01
    z[4,5,2]  R1535     3.0124038457870483e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R1448     -1
    z[4,5,3]  R1449     1
    z[4,5,3]  R1456     -2.4330346286296844e-01
    z[4,5,3]  R1457     6.4088380336761475e-01
    z[4,5,3]  R1458     8.3118927478790283e-01
    z[4,5,3]  R1459     5.0202047824859619e-01
    z[4,5,3]  R1460     6.1825442314147949e-01
    z[4,5,3]  R1461     5.3561651706695557e-01
    z[4,5,3]  R1462     -2.1502526104450226e-01
    z[4,5,3]  R1463     3.4871095418930054e-01
    z[4,5,3]  R1464     6.1747943982481956e-03
    z[4,5,3]  R1465     -7.8910492360591888e-02
    z[4,5,3]  R1466     -4.9729026854038239e-02
    z[4,5,3]  R1467     -1.3379671610891819e-02
    z[4,5,3]  R1468     -3.6287495493888855e-01
    z[4,5,3]  R1469     -6.2828463315963745e-01
    z[4,5,3]  R1470     -7.9960060119628906e-01
    z[4,5,3]  R1471     -5.5615299940109253e-01
    z[4,5,3]  R1472     -8.0680477619171143e-01
    z[4,5,3]  R1473     -5.9920346736907959e-01
    z[4,5,3]  R1474     -4.7588801383972168e-01
    z[4,5,3]  R1475     -1.9305257499217987e-01
    z[4,5,3]  R1476     -2.4466849863529205e-01
    z[4,5,3]  R1477     -2.2717629373073578e-01
    z[4,5,3]  R1478     6.1988256871700287e-02
    z[4,5,3]  R1479     -4.9140679836273193e-01
    z[4,5,3]  R1480     -0.562491238117218
    z[4,5,3]  R1481     -6.5210080146789551e-01
    z[4,5,3]  R1482     2.4216838181018829e-01
    z[4,5,3]  R1483     -4.3520128726959229e-01
    z[4,5,3]  R1484     -5.5447423458099365e-01
    z[4,5,3]  R1485     -8.6597663164138794e-01
    z[4,5,3]  R1486     -8.7393987923860550e-03
    z[4,5,3]  R1487     -0.0466126874089241
    z[4,5,3]  R1488     1.2584270536899567e-01
    z[4,5,3]  R1489     3.3088415861129761e-01
    z[4,5,3]  R1490     -2.1796119399368763e-03
    z[4,5,3]  R1491     -2.2579845041036606e-02
    z[4,5,3]  R1492     -5.8057314157485962e-01
    z[4,5,3]  R1493     9.4112195074558258e-03
    z[4,5,3]  R1494     -1.8776719272136688e-01
    z[4,5,3]  R1495     -0.0934593677520752
    z[4,5,3]  R1496     1.7307612299919128e-01
    z[4,5,3]  R1497     8.0016024410724640e-02
    z[4,5,3]  R1498     -7.9326313734054565e-01
    z[4,5,3]  R1499     4.2148139327764511e-02
    z[4,5,3]  R1500     2.2905036807060242e-01
    z[4,5,3]  R1501     1.7671939730644226e-01
    z[4,5,3]  R1502     -5.6692283600568771e-02
    z[4,5,3]  R1503     2.2062557935714722e-01
    z[4,5,3]  R1504     2.2669243812561035e-01
    z[4,5,3]  R1505     -1.0020788758993149e-01
    z[4,5,3]  R1506     -2.5866144895553589e-01
    z[4,5,3]  R1507     2.8459358215332031e-01
    z[4,5,3]  R1508     -2.8216877579689026e-01
    z[4,5,3]  R1509     -3.9917609095573425e-01
    z[4,5,3]  R1510     -4.4421613216400146e-02
    z[4,5,3]  R1511     3.2486149668693542e-01
    z[4,5,3]  R1512     2.8203946352005005e-01
    z[4,5,3]  R1513     7.6594430208206177e-01
    z[4,5,3]  R1514     7.3680356144905090e-02
    z[4,5,3]  R1515     -2.6583209633827209e-01
    z[4,5,3]  R1516     -2.9930931329727173e-01
    z[4,5,3]  R1517     3.0626082420349121e-01
    z[4,5,3]  R1518     1.1325030773878098e-01
    z[4,5,3]  R1519     -4.4818982481956482e-01
    z[4,5,3]  R1520     1.8112331628799438e-01
    z[4,5,3]  R1521     -2.3785674571990967e-01
    z[4,5,3]  R1522     -5.3479743003845215e-01
    z[4,5,3]  R1523     -0.523095965385437
    z[4,5,3]  R1524     1.0609175264835358e-01
    z[4,5,3]  R1525     -5.9104657173156738e-01
    z[4,5,3]  R1526     5.4408796131610870e-02
    z[4,5,3]  R1527     2.6956740021705627e-01
    z[4,5,3]  R1528     -2.3281428217887878e-01
    z[4,5,3]  R1529     2.6498386263847351e-01
    z[4,5,3]  R1530     -9.6142947673797607e-02
    z[4,5,3]  R1531     -5.0653403997421265e-01
    z[4,5,3]  R1532     -5.6126654148101807e-01
    z[4,5,3]  R1533     -5.6971663236618042e-01
    z[4,5,3]  R1534     -4.8686710000038147e-01
    z[4,5,3]  R1535     -1.4440187811851501e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R1450     -1
    z[4,5,4]  R1451     1
    z[4,5,4]  R1456     1.7166081070899963e-01
    z[4,5,4]  R1457     2.6555103063583374e-01
    z[4,5,4]  R1458     -3.5666882991790771e-01
    z[4,5,4]  R1459     6.2006723880767822e-01
    z[4,5,4]  R1460     7.9848326742649078e-02
    z[4,5,4]  R1461     5.8126222342252731e-02
    z[4,5,4]  R1462     5.9390628337860107e-01
    z[4,5,4]  R1463     -3.8776338100433350e-01
    z[4,5,4]  R1464     2.5676438584923744e-02
    z[4,5,4]  R1465     3.1820493936538696e-01
    z[4,5,4]  R1466     -1.7874620854854584e-01
    z[4,5,4]  R1467     -2.6201993227005005e-01
    z[4,5,4]  R1468     -1.4919523894786835e-01
    z[4,5,4]  R1469     -2.1776072680950165e-01
    z[4,5,4]  R1470     -3.7224754691123962e-01
    z[4,5,4]  R1471     5.7311993837356567e-01
    z[4,5,4]  R1472     3.3144921064376831e-01
    z[4,5,4]  R1473     -5.3990882635116577e-01
    z[4,5,4]  R1474     3.5976175218820572e-02
    z[4,5,4]  R1475     -0.162450909614563
    z[4,5,4]  R1476     2.7533066272735596e-01
    z[4,5,4]  R1477     2.1661397814750671e-01
    z[4,5,4]  R1478     -3.1194350123405457e-01
    z[4,5,4]  R1479     5.3216083906590939e-03
    z[4,5,4]  R1480     2.2346168756484985e-01
    z[4,5,4]  R1481     1.5192779898643494e-01
    z[4,5,4]  R1482     -2.9828497767448425e-01
    z[4,5,4]  R1483     0.280141681432724
    z[4,5,4]  R1484     -2.0264382660388947e-01
    z[4,5,4]  R1485     2.8758466243743896e-01
    z[4,5,4]  R1486     8.5873436182737350e-04
    z[4,5,4]  R1487     -1.1589819192886353e-01
    z[4,5,4]  R1488     -4.7125168144702911e-02
    z[4,5,4]  R1489     -5.8494526147842407e-01
    z[4,5,4]  R1490     -4.6181634068489075e-01
    z[4,5,4]  R1491     1.4247675240039825e-01
    z[4,5,4]  R1492     -1.6923119127750397e-01
    z[4,5,4]  R1493     -2.9892298579216003e-01
    z[4,5,4]  R1494     3.5811014473438263e-02
    z[4,5,4]  R1495     -1.5946429967880249e-01
    z[4,5,4]  R1496     -5.0564610958099365e-01
    z[4,5,4]  R1497     -1.6528847813606262e-01
    z[4,5,4]  R1498     -3.4734913706779480e-01
    z[4,5,4]  R1499     -2.7560099959373474e-01
    z[4,5,4]  R1500     1.1525370180606842e-01
    z[4,5,4]  R1501     -1.2992176413536072e-01
    z[4,5,4]  R1502     2.5555733591318130e-03
    z[4,5,4]  R1503     4.9524795264005661e-02
    z[4,5,4]  R1504     -1.4719154569320381e-04
    z[4,5,4]  R1505     2.0635944604873657e-01
    z[4,5,4]  R1506     -2.9757422208786011e-01
    z[4,5,4]  R1507     2.0776192843914032e-01
    z[4,5,4]  R1508     -3.4446901082992554e-01
    z[4,5,4]  R1509     -3.9735859632492065e-01
    z[4,5,4]  R1510     1.4652957022190094e-01
    z[4,5,4]  R1511     5.7656061649322510e-01
    z[4,5,4]  R1512     3.5364833474159241e-01
    z[4,5,4]  R1513     -1.7526137828826904e-01
    z[4,5,4]  R1514     -3.2261142134666443e-01
    z[4,5,4]  R1515     6.1804372072219849e-01
    z[4,5,4]  R1516     4.1991323814727366e-04
    z[4,5,4]  R1517     -1.4301495254039764e-01
    z[4,5,4]  R1518     1.8313780426979065e-01
    z[4,5,4]  R1519     5.4839968681335449e-01
    z[4,5,4]  R1520     2.6046988368034363e-01
    z[4,5,4]  R1521     1.9126552343368530e-01
    z[4,5,4]  R1522     2.1001639962196350e-01
    z[4,5,4]  R1523     -4.0290430188179016e-01
    z[4,5,4]  R1524     -1.2991668283939362e-01
    z[4,5,4]  R1525     3.6405879259109497e-01
    z[4,5,4]  R1526     1.0645199567079544e-02
    z[4,5,4]  R1527     2.7664875984191895e-01
    z[4,5,4]  R1528     -5.1507055759429932e-01
    z[4,5,4]  R1529     -5.9713596105575562e-01
    z[4,5,4]  R1530     -1.3740111887454987e-01
    z[4,5,4]  R1531     3.2693885266780853e-02
    z[4,5,4]  R1532     2.0006994903087616e-01
    z[4,5,4]  R1533     -2.5432524085044861e-01
    z[4,5,4]  R1534     -1.9584493339061737e-01
    z[4,5,4]  R1535     -2.0171651244163513e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R1452     -1
    z[4,5,5]  R1453     1
    z[4,5,5]  R1456     -8.7248824536800385e-02
    z[4,5,5]  R1457     -3.4173485636711121e-01
    z[4,5,5]  R1458     -2.6238659024238586e-01
    z[4,5,5]  R1459     -3.4383806586265564e-01
    z[4,5,5]  R1460     9.3546412885189056e-02
    z[4,5,5]  R1461     -6.0945028066635132e-01
    z[4,5,5]  R1462     -4.6668532490730286e-01
    z[4,5,5]  R1463     3.9792710542678833e-01
    z[4,5,5]  R1464     1.2828531861305237e-01
    z[4,5,5]  R1465     9.0913869440555573e-02
    z[4,5,5]  R1466     4.4212940335273743e-01
    z[4,5,5]  R1467     7.7977198362350464e-01
    z[4,5,5]  R1468     -4.2695045471191406e-01
    z[4,5,5]  R1469     3.7409138679504395e-01
    z[4,5,5]  R1470     9.4170890748500824e-02
    z[4,5,5]  R1471     3.5449784994125366e-01
    z[4,5,5]  R1472     3.2058224081993103e-01
    z[4,5,5]  R1473     0.0108823636546731
    z[4,5,5]  R1474     -0.0410323366522789
    z[4,5,5]  R1475     5.7950407266616821e-02
    z[4,5,5]  R1476     -2.5654423981904984e-02
    z[4,5,5]  R1477     -3.8571065664291382e-01
    z[4,5,5]  R1478     -2.5312250852584839e-01
    z[4,5,5]  R1479     2.0238001644611359e-01
    z[4,5,5]  R1480     4.6938553452491760e-01
    z[4,5,5]  R1481     1.9093506038188934e-01
    z[4,5,5]  R1482     0.0532853901386261
    z[4,5,5]  R1483     2.6255580782890320e-01
    z[4,5,5]  R1484     2.5324231386184692e-01
    z[4,5,5]  R1485     2.3000319302082062e-01
    z[4,5,5]  R1486     -2.4678705632686615e-01
    z[4,5,5]  R1487     -3.2962822914123535e-01
    z[4,5,5]  R1488     2.6725775003433228e-01
    z[4,5,5]  R1489     -2.3675398528575897e-01
    z[4,5,5]  R1490     -6.3373476266860962e-02
    z[4,5,5]  R1491     2.2593397647142410e-02
    z[4,5,5]  R1492     4.6157222986221313e-01
    z[4,5,5]  R1493     -2.4501267075538635e-01
    z[4,5,5]  R1494     -2.2183151543140411e-01
    z[4,5,5]  R1495     -1.8626582622528076e-01
    z[4,5,5]  R1496     1.2021089345216751e-01
    z[4,5,5]  R1497     -1.2923605740070343e-01
    z[4,5,5]  R1498     2.9020580649375916e-01
    z[4,5,5]  R1499     -2.4687018990516663e-01
    z[4,5,5]  R1500     -7.4510313570499420e-02
    z[4,5,5]  R1501     1.5238919854164124e-01
    z[4,5,5]  R1502     -4.1781923174858093e-01
    z[4,5,5]  R1503     -2.3594839870929718e-01
    z[4,5,5]  R1504     1.7438188195228577e-01
    z[4,5,5]  R1505     -2.5090718269348145e-01
    z[4,5,5]  R1506     -5.6988209486007690e-01
    z[4,5,5]  R1507     -6.3853855244815350e-03
    z[4,5,5]  R1508     -3.9604845643043518e-01
    z[4,5,5]  R1509     -1.6567985713481903e-01
    z[4,5,5]  R1510     -1.9466885924339294e-01
    z[4,5,5]  R1511     -9.0171068906784058e-02
    z[4,5,5]  R1512     2.6869205757975578e-02
    z[4,5,5]  R1513     2.1448722109198570e-02
    z[4,5,5]  R1514     -5.2375471591949463e-01
    z[4,5,5]  R1515     -5.0364631414413452e-01
    z[4,5,5]  R1516     4.7354102134704590e-01
    z[4,5,5]  R1517     6.2358152866363525e-01
    z[4,5,5]  R1518     -1.8069872260093689e-01
    z[4,5,5]  R1519     4.4689774513244629e-01
    z[4,5,5]  R1520     1.8895292282104492e-01
    z[4,5,5]  R1521     -2.3948937654495239e-01
    z[4,5,5]  R1522     4.0278565883636475e-01
    z[4,5,5]  R1523     3.9408656954765320e-01
    z[4,5,5]  R1524     3.2812082767486572e-01
    z[4,5,5]  R1525     -3.1141281127929688e-01
    z[4,5,5]  R1526     -1.1388673633337021e-01
    z[4,5,5]  R1527     -1.6845078766345978e-01
    z[4,5,5]  R1528     -1.9640058279037476e-01
    z[4,5,5]  R1529     -5.7908177375793457e-01
    z[4,5,5]  R1530     4.5114055275917053e-01
    z[4,5,5]  R1531     -2.2129443287849426e-01
    z[4,5,5]  R1532     3.0819091200828552e-01
    z[4,5,5]  R1533     2.7421155571937561e-01
    z[4,5,5]  R1534     1.5060122311115265e-01
    z[4,5,5]  R1535     1.3864484429359436e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R1454     -1
    z[4,5,6]  R1455     1
    z[4,5,6]  R1456     -1.8227215111255646e-01
    z[4,5,6]  R1457     4.8308894038200378e-01
    z[4,5,6]  R1458     -5.2540283650159836e-03
    z[4,5,6]  R1459     -1.7118491232395172e-01
    z[4,5,6]  R1460     -1.2941205501556396e-01
    z[4,5,6]  R1461     0.259101003408432
    z[4,5,6]  R1462     2.1217225492000580e-01
    z[4,5,6]  R1463     -2.0377086102962494e-01
    z[4,5,6]  R1464     4.9424994736909866e-02
    z[4,5,6]  R1465     3.2052415609359741e-01
    z[4,5,6]  R1466     -1.9010773301124573e-01
    z[4,5,6]  R1467     8.6065813899040222e-02
    z[4,5,6]  R1468     -7.1420705318450928e-01
    z[4,5,6]  R1469     -3.7376844882965088e-01
    z[4,5,6]  R1470     -1.0020061582326889e-01
    z[4,5,6]  R1471     3.3467730879783630e-01
    z[4,5,6]  R1472     -3.2956176996231079e-01
    z[4,5,6]  R1473     2.2259773313999176e-01
    z[4,5,6]  R1474     -2.7017902582883835e-02
    z[4,5,6]  R1475     1.3021923601627350e-01
    z[4,5,6]  R1476     8.4782741963863373e-02
    z[4,5,6]  R1477     2.4156148731708527e-01
    z[4,5,6]  R1478     -4.8951196670532227e-01
    z[4,5,6]  R1479     -2.1152982115745544e-01
    z[4,5,6]  R1480     -0.0820658802986145
    z[4,5,6]  R1481     -3.3595755696296692e-02
    z[4,5,6]  R1482     -4.2025718092918396e-01
    z[4,5,6]  R1483     1.0127981007099152e-01
    z[4,5,6]  R1484     2.3284368216991425e-01
    z[4,5,6]  R1485     -4.9966756254434586e-02
    z[4,5,6]  R1486     1.9454509019851685e-01
    z[4,5,6]  R1487     2.5387939065694809e-02
    z[4,5,6]  R1488     -2.3479017615318298e-01
    z[4,5,6]  R1489     -5.6522661447525024e-01
    z[4,5,6]  R1490     -3.1581774353981018e-01
    z[4,5,6]  R1491     -1.6999433934688568e-01
    z[4,5,6]  R1492     -4.7128465771675110e-01
    z[4,5,6]  R1493     -1.0066631436347961e-01
    z[4,5,6]  R1494     1.6159044206142426e-01
    z[4,5,6]  R1495     -2.1938814222812653e-01
    z[4,5,6]  R1496     -5.0658637285232544e-01
    z[4,5,6]  R1497     -4.6783113479614258e-01
    z[4,5,6]  R1498     1.0208971798419952e-02
    z[4,5,6]  R1499     -1.2860514223575592e-01
    z[4,5,6]  R1500     3.4179106354713440e-01
    z[4,5,6]  R1501     -7.7363565564155579e-02
    z[4,5,6]  R1502     3.2385224103927612e-01
    z[4,5,6]  R1503     1.7104333639144897e-01
    z[4,5,6]  R1504     2.9971027374267578e-01
    z[4,5,6]  R1505     -0.0792362168431282
    z[4,5,6]  R1506     1.9051089882850647e-01
    z[4,5,6]  R1507     -0.38516765832901
    z[4,5,6]  R1508     1.3256359100341797e-01
    z[4,5,6]  R1509     -1.2602607905864716e-01
    z[4,5,6]  R1510     1.7144057154655457e-01
    z[4,5,6]  R1511     0.315448522567749
    z[4,5,6]  R1512     -9.9200025200843811e-02
    z[4,5,6]  R1513     1.7386473715305328e-01
    z[4,5,6]  R1514     -1.4328743517398834e-01
    z[4,5,6]  R1515     -7.7792368829250336e-02
    z[4,5,6]  R1516     -3.7168782949447632e-01
    z[4,5,6]  R1517     -3.5316473245620728e-01
    z[4,5,6]  R1518     -4.5230352878570557e-01
    z[4,5,6]  R1519     2.2273132205009460e-01
    z[4,5,6]  R1520     -2.3438625037670135e-01
    z[4,5,6]  R1521     3.4495303034782410e-01
    z[4,5,6]  R1522     3.2797396183013916e-01
    z[4,5,6]  R1523     4.9378228187561035e-01
    z[4,5,6]  R1524     4.6263146400451660e-01
    z[4,5,6]  R1525     2.4267353117465973e-01
    z[4,5,6]  R1526     -1.3771170750260353e-02
    z[4,5,6]  R1527     3.6265552043914795e-01
    z[4,5,6]  R1528     4.4650569558143616e-01
    z[4,5,6]  R1529     -2.8255870565772057e-02
    z[4,5,6]  R1530     2.0609153807163239e-01
    z[4,5,6]  R1531     0.0699809193611145
    z[4,5,6]  R1532     1.3407501578330994e-01
    z[4,5,6]  R1533     1.0127907991409302e-01
    z[4,5,6]  R1534     3.5682967305183411e-01
    z[4,5,6]  R1535     -3.8814684748649597e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R1536     -1
    z[5,4,0]  R1537     1
    z[5,4,0]  R1550     4.9648988246917725e-01
    z[5,4,0]  R1551     -2.6639136672019958e-01
    z[5,4,0]  R1552     -1.2950626015663147e-01
    z[5,4,0]  R1553     -7.9698067903518677e-01
    z[5,4,0]  R1554     -3.7656205892562866e-01
    z[5,4,0]  R1555     -5.1015269756317139e-01
    z[5,4,0]  R1556     -4.2382824420928955e-01
    z[5,4,0]  R1557     -4.6033310890197754e-01
    z[5,4,0]  R1558     -5.0955390930175781e-01
    z[5,4,0]  R1559     0.242109477519989
    z[5,4,0]  R1560     6.1530214548110962e-01
    z[5,4,0]  R1561     -2.3542794585227966e-01
    z[5,4,0]  R1562     1.2747491896152496e-01
    z[5,4,0]  R1563     -1.9518758356571198e-01
    z[5,4,0]  R1564     7.8302729129791260e-01
    z[5,4,0]  R1565     -5.4339367151260376e-01
    z[5,4,0]  R1566     -3.0413594841957092e-01
    z[5,4,0]  R1567     -3.3105167746543884e-01
    z[5,4,0]  R1568     8.1613563001155853e-02
    z[5,4,0]  R1569     2.4063149094581604e-01
    z[5,4,0]  R1570     3.8187541067600250e-02
    z[5,4,0]  R1571     -1.1935734748840332e-01
    z[5,4,0]  R1572     -1.2596021592617035e-01
    z[5,4,0]  R1573     -1.0391132533550262e-01
    z[5,4,0]  R1574     -6.1322432756423950e-01
    z[5,4,0]  R1575     7.5107455253601074e-01
    z[5,4,0]  R1576     5.7250422239303589e-01
    z[5,4,0]  R1577     6.0374909639358521e-01
    z[5,4,0]  R1578     5.4553002119064331e-01
    z[5,4,0]  R1579     5.9053015708923340e-01
    z[5,4,0]  R1580     -3.2573610544204712e-01
    z[5,4,0]  R1581     -2.5934723019599915e-01
    z[5,4,0]  R1582     8.8120587170124054e-02
    z[5,4,0]  R1583     9.8550565540790558e-02
    z[5,4,0]  R1584     6.9516366720199585e-01
    z[5,4,0]  R1585     3.5381710529327393e-01
    z[5,4,0]  R1586     5.3135710954666138e-01
    z[5,4,0]  R1587     5.0062006711959839e-01
    z[5,4,0]  R1588     -0.0803113803267479
    z[5,4,0]  R1589     -4.1130515933036804e-01
    z[5,4,0]  R1590     -0.427592396736145
    z[5,4,0]  R1591     2.0544408261775970e-01
    z[5,4,0]  R1592     0.0890294685959816
    z[5,4,0]  R1593     -6.0372769832611084e-02
    z[5,4,0]  R1594     -3.5978186130523682e-01
    z[5,4,0]  R1595     -2.9932841658592224e-01
    z[5,4,0]  R1596     -1.1968418210744858e-01
    z[5,4,0]  R1597     -1.6735707223415375e-01
    z[5,4,0]  R1598     -7.3670989274978638e-01
    z[5,4,0]  R1599     -7.2185647487640381e-01
    z[5,4,0]  R1600     5.0655186176300049e-01
    z[5,4,0]  R1601     -3.5451275110244751e-01
    z[5,4,0]  R1602     7.0910400152206421e-01
    z[5,4,0]  R1603     -3.2608368992805481e-01
    z[5,4,0]  R1604     -4.0962222218513489e-01
    z[5,4,0]  R1605     -5.7422578334808350e-01
    z[5,4,0]  R1606     4.8209443688392639e-01
    z[5,4,0]  R1607     -2.2729055583477020e-01
    z[5,4,0]  R1608     -5.2984601259231567e-01
    z[5,4,0]  R1609     -8.7798461318016052e-02
    z[5,4,0]  R1610     -2.1332009136676788e-01
    z[5,4,0]  R1611     1.4889524877071381e-01
    z[5,4,0]  R1612     6.1367547512054443e-01
    z[5,4,0]  R1613     3.5424154996871948e-01
    z[5,4,0]  R1614     7.5880038738250732e-01
    z[5,4,0]  R1615     -1.2219431251287460e-01
    z[5,4,0]  R1616     -1.5539045631885529e-01
    z[5,4,0]  R1617     -4.0151676535606384e-01
    z[5,4,0]  R1618     -4.3038254976272583e-01
    z[5,4,0]  R1619     -5.8152490854263306e-01
    z[5,4,0]  R1620     4.6116787195205688e-01
    z[5,4,0]  R1621     7.4232870340347290e-01
    z[5,4,0]  R1622     -2.1970137953758240e-01
    z[5,4,0]  R1623     -2.8013315796852112e-01
    z[5,4,0]  R1624     -2.9905471205711365e-01
    z[5,4,0]  R1625     -5.3870719671249390e-01
    z[5,4,0]  R1626     -2.1344721317291260e-01
    z[5,4,0]  R1627     -6.4537745714187622e-01
    z[5,4,0]  R1628     -6.8506032228469849e-01
    z[5,4,0]  R1629     -1.5146845579147339e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R1538     -1
    z[5,4,1]  R1539     1
    z[5,4,1]  R1550     4.3844223022460938e-02
    z[5,4,1]  R1551     -8.0521166324615479e-01
    z[5,4,1]  R1552     1.7489878460764885e-02
    z[5,4,1]  R1553     6.2313683331012726e-02
    z[5,4,1]  R1554     3.1382761895656586e-02
    z[5,4,1]  R1555     -4.2410698533058167e-01
    z[5,4,1]  R1556     -4.4718232750892639e-01
    z[5,4,1]  R1557     -3.6831203103065491e-01
    z[5,4,1]  R1558     -5.1659411191940308e-01
    z[5,4,1]  R1559     1.9754158332943916e-02
    z[5,4,1]  R1560     1.8612654507160187e-01
    z[5,4,1]  R1561     2.8649359941482544e-01
    z[5,4,1]  R1562     8.9528091251850128e-02
    z[5,4,1]  R1563     1.1711125075817108e-01
    z[5,4,1]  R1564     4.3407621979713440e-01
    z[5,4,1]  R1565     8.4541819989681244e-02
    z[5,4,1]  R1566     -3.3135646581649780e-01
    z[5,4,1]  R1567     -1.7478680610656738e-01
    z[5,4,1]  R1568     6.7083835601806641e-01
    z[5,4,1]  R1569     -4.4888365268707275e-01
    z[5,4,1]  R1570     9.6127837896347046e-01
    z[5,4,1]  R1571     8.2246738672256470e-01
    z[5,4,1]  R1572     4.5424845814704895e-01
    z[5,4,1]  R1573     0.443109393119812
    z[5,4,1]  R1574     -3.7199783325195312e-01
    z[5,4,1]  R1575     -3.4101182222366333e-01
    z[5,4,1]  R1576     -4.5097431540489197e-01
    z[5,4,1]  R1577     -3.9959374070167542e-01
    z[5,4,1]  R1578     -2.4694876372814178e-01
    z[5,4,1]  R1579     -5.7367813587188721e-01
    z[5,4,1]  R1580     8.6098372936248779e-02
    z[5,4,1]  R1581     4.0809374302625656e-02
    z[5,4,1]  R1582     1.4856897294521332e-02
    z[5,4,1]  R1583     3.5770680755376816e-02
    z[5,4,1]  R1584     2.9243474826216698e-02
    z[5,4,1]  R1585     3.3882107585668564e-02
    z[5,4,1]  R1586     4.2408645153045654e-02
    z[5,4,1]  R1587     -2.6837334036827087e-02
    z[5,4,1]  R1588     -9.8626506328582764e-01
    z[5,4,1]  R1589     -7.7075231075286865e-01
    z[5,4,1]  R1590     3.3755227923393250e-01
    z[5,4,1]  R1591     4.6453335881233215e-01
    z[5,4,1]  R1592     2.0314882695674896e-01
    z[5,4,1]  R1593     -4.5288348197937012e-01
    z[5,4,1]  R1594     -2.2510962188243866e-01
    z[5,4,1]  R1595     7.5029619038105011e-02
    z[5,4,1]  R1596     -1.1169072240591049e-01
    z[5,4,1]  R1597     -2.0647212862968445e-01
    z[5,4,1]  R1598     3.1193214654922485e-01
    z[5,4,1]  R1599     1.0958223044872284e-01
    z[5,4,1]  R1600     7.0791471004486084e-01
    z[5,4,1]  R1601     7.0677822828292847e-01
    z[5,4,1]  R1602     -9.4216220080852509e-02
    z[5,4,1]  R1603     -1.8292379379272461e-01
    z[5,4,1]  R1604     -3.1834807991981506e-01
    z[5,4,1]  R1605     -2.9790893197059631e-02
    z[5,4,1]  R1606     -6.2753939628601074e-01
    z[5,4,1]  R1607     -2.8487288951873779e-01
    z[5,4,1]  R1608     -2.7020066976547241e-01
    z[5,4,1]  R1609     -8.7465830147266388e-02
    z[5,4,1]  R1610     9.1370832920074463e-01
    z[5,4,1]  R1611     6.0478651523590088e-01
    z[5,4,1]  R1612     -5.3782677650451660e-01
    z[5,4,1]  R1613     -2.0813673734664917e-01
    z[5,4,1]  R1614     -1.4956003427505493e-01
    z[5,4,1]  R1615     -9.1522234678268433e-01
    z[5,4,1]  R1616     -3.5401773452758789e-01
    z[5,4,1]  R1617     -7.9296404123306274e-01
    z[5,4,1]  R1618     -7.6892828941345215e-01
    z[5,4,1]  R1619     -7.2409129142761230e-01
    z[5,4,1]  R1620     2.1006102859973907e-01
    z[5,4,1]  R1621     -0.37724769115448
    z[5,4,1]  R1622     -2.4791140854358673e-01
    z[5,4,1]  R1623     -8.7415516376495361e-01
    z[5,4,1]  R1624     -8.2212585210800171e-01
    z[5,4,1]  R1625     -7.7263385057449341e-01
    z[5,4,1]  R1626     -8.1514602899551392e-01
    z[5,4,1]  R1627     -6.6241323947906494e-01
    z[5,4,1]  R1628     -5.7923221588134766e-01
    z[5,4,1]  R1629     -8.5195028781890869e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R1540     -1
    z[5,4,2]  R1541     1
    z[5,4,2]  R1550     4.8482915759086609e-01
    z[5,4,2]  R1551     -9.0091131627559662e-02
    z[5,4,2]  R1552     7.8116357326507568e-01
    z[5,4,2]  R1553     1.9263638183474541e-02
    z[5,4,2]  R1554     8.7549078464508057e-01
    z[5,4,2]  R1555     1.1950641125440598e-01
    z[5,4,2]  R1556     0.636570155620575
    z[5,4,2]  R1557     -6.6055871546268463e-02
    z[5,4,2]  R1558     2.6292216777801514e-01
    z[5,4,2]  R1559     4.7815990447998047e-01
    z[5,4,2]  R1560     -3.6712530255317688e-01
    z[5,4,2]  R1561     -4.8442426323890686e-01
    z[5,4,2]  R1562     -8.3194905519485474e-01
    z[5,4,2]  R1563     -4.4412112236022949e-01
    z[5,4,2]  R1564     -8.4590762853622437e-02
    z[5,4,2]  R1565     -0.654270589351654
    z[5,4,2]  R1566     -4.4473114609718323e-01
    z[5,4,2]  R1567     -1.5737813711166382e-01
    z[5,4,2]  R1568     4.3987524509429932e-01
    z[5,4,2]  R1569     -0.320712685585022
    z[5,4,2]  R1570     2.4135455489158630e-01
    z[5,4,2]  R1571     -1.4329555444419384e-02
    z[5,4,2]  R1572     -4.6941635012626648e-01
    z[5,4,2]  R1573     -1.7301650345325470e-01
    z[5,4,2]  R1574     4.5983624458312988e-01
    z[5,4,2]  R1575     -0.0899103432893753
    z[5,4,2]  R1576     2.9243247583508492e-02
    z[5,4,2]  R1577     -3.3227629959583282e-02
    z[5,4,2]  R1578     4.6476915478706360e-01
    z[5,4,2]  R1579     3.0124038457870483e-01
    z[5,4,2]  R1580     8.7004798650741577e-01
    z[5,4,2]  R1581     -3.1570014357566833e-01
    z[5,4,2]  R1582     -3.2411649823188782e-01
    z[5,4,2]  R1583     -4.5273759961128235e-01
    z[5,4,2]  R1584     -3.1902936100959778e-01
    z[5,4,2]  R1585     -3.8057672977447510e-01
    z[5,4,2]  R1586     2.3256923258304596e-01
    z[5,4,2]  R1587     -5.2614736557006836e-01
    z[5,4,2]  R1588     3.5125121474266052e-02
    z[5,4,2]  R1589     -0.135227769613266
    z[5,4,2]  R1590     -6.6119629144668579e-01
    z[5,4,2]  R1591     2.4024224281311035e-01
    z[5,4,2]  R1592     -3.2324683666229248e-01
    z[5,4,2]  R1593     2.6352068781852722e-01
    z[5,4,2]  R1594     1.5180575847625732e-01
    z[5,4,2]  R1595     1.7123924195766449e-01
    z[5,4,2]  R1596     -3.2004401087760925e-02
    z[5,4,2]  R1597     4.7869232296943665e-01
    z[5,4,2]  R1598     3.6024913191795349e-01
    z[5,4,2]  R1599     6.1882162094116211e-01
    z[5,4,2]  R1600     -3.1423881649971008e-01
    z[5,4,2]  R1601     2.6292544603347778e-01
    z[5,4,2]  R1602     2.8887814283370972e-01
    z[5,4,2]  R1603     7.3006629943847656e-01
    z[5,4,2]  R1604     3.7077632546424866e-01
    z[5,4,2]  R1605     4.2833951115608215e-01
    z[5,4,2]  R1606     -2.1611212193965912e-01
    z[5,4,2]  R1607     7.2118914127349854e-01
    z[5,4,2]  R1608     4.2355710268020630e-01
    z[5,4,2]  R1609     3.1084164977073669e-01
    z[5,4,2]  R1610     -1.4423248171806335e-01
    z[5,4,2]  R1611     6.9796758890151978e-01
    z[5,4,2]  R1612     -4.3535566329956055e-01
    z[5,4,2]  R1613     -6.3349805772304535e-02
    z[5,4,2]  R1614     -2.9123482108116150e-01
    z[5,4,2]  R1615     -3.1179878115653992e-01
    z[5,4,2]  R1616     2.2285149991512299e-01
    z[5,4,2]  R1617     -0.224463552236557
    z[5,4,2]  R1618     -3.3415627479553223e-01
    z[5,4,2]  R1619     1.4328600466251373e-01
    z[5,4,2]  R1620     -4.3183878064155579e-01
    z[5,4,2]  R1621     -1.9323955476284027e-01
    z[5,4,2]  R1622     2.3670576512813568e-01
    z[5,4,2]  R1623     -4.6494167298078537e-02
    z[5,4,2]  R1624     -2.1576589345932007e-01
    z[5,4,2]  R1625     -1.8845294415950775e-01
    z[5,4,2]  R1626     8.5460282862186432e-02
    z[5,4,2]  R1627     9.2955529689788818e-02
    z[5,4,2]  R1628     1.5348492562770844e-01
    z[5,4,2]  R1629     3.5969346761703491e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R1542     -1
    z[5,4,3]  R1543     1
    z[5,4,3]  R1550     -2.5866144895553589e-01
    z[5,4,3]  R1551     2.8459358215332031e-01
    z[5,4,3]  R1552     -2.8216877579689026e-01
    z[5,4,3]  R1553     -3.9917609095573425e-01
    z[5,4,3]  R1554     -4.4421613216400146e-02
    z[5,4,3]  R1555     3.2486149668693542e-01
    z[5,4,3]  R1556     2.8203946352005005e-01
    z[5,4,3]  R1557     7.6594430208206177e-01
    z[5,4,3]  R1558     7.3680356144905090e-02
    z[5,4,3]  R1559     -2.6583209633827209e-01
    z[5,4,3]  R1560     -2.9930931329727173e-01
    z[5,4,3]  R1561     3.0626082420349121e-01
    z[5,4,3]  R1562     1.1325030773878098e-01
    z[5,4,3]  R1563     -4.4818982481956482e-01
    z[5,4,3]  R1564     1.8112331628799438e-01
    z[5,4,3]  R1565     -2.3785674571990967e-01
    z[5,4,3]  R1566     -5.3479743003845215e-01
    z[5,4,3]  R1567     -0.523095965385437
    z[5,4,3]  R1568     1.0609175264835358e-01
    z[5,4,3]  R1569     -5.9104657173156738e-01
    z[5,4,3]  R1570     5.4408796131610870e-02
    z[5,4,3]  R1571     2.6956740021705627e-01
    z[5,4,3]  R1572     -2.3281428217887878e-01
    z[5,4,3]  R1573     2.6498386263847351e-01
    z[5,4,3]  R1574     -9.6142947673797607e-02
    z[5,4,3]  R1575     -5.0653403997421265e-01
    z[5,4,3]  R1576     -5.6126654148101807e-01
    z[5,4,3]  R1577     -5.6971663236618042e-01
    z[5,4,3]  R1578     -4.8686710000038147e-01
    z[5,4,3]  R1579     -1.4440187811851501e-01
    z[5,4,3]  R1580     -2.4330346286296844e-01
    z[5,4,3]  R1581     6.4088380336761475e-01
    z[5,4,3]  R1582     8.3118927478790283e-01
    z[5,4,3]  R1583     5.0202047824859619e-01
    z[5,4,3]  R1584     6.1825442314147949e-01
    z[5,4,3]  R1585     5.3561651706695557e-01
    z[5,4,3]  R1586     -2.1502526104450226e-01
    z[5,4,3]  R1587     3.4871095418930054e-01
    z[5,4,3]  R1588     6.1747943982481956e-03
    z[5,4,3]  R1589     -7.8910492360591888e-02
    z[5,4,3]  R1590     -4.9729026854038239e-02
    z[5,4,3]  R1591     -1.3379671610891819e-02
    z[5,4,3]  R1592     -3.6287495493888855e-01
    z[5,4,3]  R1593     -6.2828463315963745e-01
    z[5,4,3]  R1594     -7.9960060119628906e-01
    z[5,4,3]  R1595     -5.5615299940109253e-01
    z[5,4,3]  R1596     -8.0680477619171143e-01
    z[5,4,3]  R1597     -5.9920346736907959e-01
    z[5,4,3]  R1598     -4.7588801383972168e-01
    z[5,4,3]  R1599     -1.9305257499217987e-01
    z[5,4,3]  R1600     -2.4466849863529205e-01
    z[5,4,3]  R1601     -2.2717629373073578e-01
    z[5,4,3]  R1602     6.1988256871700287e-02
    z[5,4,3]  R1603     -4.9140679836273193e-01
    z[5,4,3]  R1604     -0.562491238117218
    z[5,4,3]  R1605     -6.5210080146789551e-01
    z[5,4,3]  R1606     2.4216838181018829e-01
    z[5,4,3]  R1607     -4.3520128726959229e-01
    z[5,4,3]  R1608     -5.5447423458099365e-01
    z[5,4,3]  R1609     -8.6597663164138794e-01
    z[5,4,3]  R1610     -8.7393987923860550e-03
    z[5,4,3]  R1611     -0.0466126874089241
    z[5,4,3]  R1612     1.2584270536899567e-01
    z[5,4,3]  R1613     3.3088415861129761e-01
    z[5,4,3]  R1614     -2.1796119399368763e-03
    z[5,4,3]  R1615     -2.2579845041036606e-02
    z[5,4,3]  R1616     -5.8057314157485962e-01
    z[5,4,3]  R1617     9.4112195074558258e-03
    z[5,4,3]  R1618     -1.8776719272136688e-01
    z[5,4,3]  R1619     -0.0934593677520752
    z[5,4,3]  R1620     1.7307612299919128e-01
    z[5,4,3]  R1621     8.0016024410724640e-02
    z[5,4,3]  R1622     -7.9326313734054565e-01
    z[5,4,3]  R1623     4.2148139327764511e-02
    z[5,4,3]  R1624     2.2905036807060242e-01
    z[5,4,3]  R1625     1.7671939730644226e-01
    z[5,4,3]  R1626     -5.6692283600568771e-02
    z[5,4,3]  R1627     2.2062557935714722e-01
    z[5,4,3]  R1628     2.2669243812561035e-01
    z[5,4,3]  R1629     -1.0020788758993149e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R1544     -1
    z[5,4,4]  R1545     1
    z[5,4,4]  R1550     -2.9757422208786011e-01
    z[5,4,4]  R1551     2.0776192843914032e-01
    z[5,4,4]  R1552     -3.4446901082992554e-01
    z[5,4,4]  R1553     -3.9735859632492065e-01
    z[5,4,4]  R1554     1.4652957022190094e-01
    z[5,4,4]  R1555     5.7656061649322510e-01
    z[5,4,4]  R1556     3.5364833474159241e-01
    z[5,4,4]  R1557     -1.7526137828826904e-01
    z[5,4,4]  R1558     -3.2261142134666443e-01
    z[5,4,4]  R1559     6.1804372072219849e-01
    z[5,4,4]  R1560     4.1991323814727366e-04
    z[5,4,4]  R1561     -1.4301495254039764e-01
    z[5,4,4]  R1562     1.8313780426979065e-01
    z[5,4,4]  R1563     5.4839968681335449e-01
    z[5,4,4]  R1564     2.6046988368034363e-01
    z[5,4,4]  R1565     1.9126552343368530e-01
    z[5,4,4]  R1566     2.1001639962196350e-01
    z[5,4,4]  R1567     -4.0290430188179016e-01
    z[5,4,4]  R1568     -1.2991668283939362e-01
    z[5,4,4]  R1569     3.6405879259109497e-01
    z[5,4,4]  R1570     1.0645199567079544e-02
    z[5,4,4]  R1571     2.7664875984191895e-01
    z[5,4,4]  R1572     -5.1507055759429932e-01
    z[5,4,4]  R1573     -5.9713596105575562e-01
    z[5,4,4]  R1574     -1.3740111887454987e-01
    z[5,4,4]  R1575     3.2693885266780853e-02
    z[5,4,4]  R1576     2.0006994903087616e-01
    z[5,4,4]  R1577     -2.5432524085044861e-01
    z[5,4,4]  R1578     -1.9584493339061737e-01
    z[5,4,4]  R1579     -2.0171651244163513e-01
    z[5,4,4]  R1580     1.7166081070899963e-01
    z[5,4,4]  R1581     2.6555103063583374e-01
    z[5,4,4]  R1582     -3.5666882991790771e-01
    z[5,4,4]  R1583     6.2006723880767822e-01
    z[5,4,4]  R1584     7.9848326742649078e-02
    z[5,4,4]  R1585     5.8126222342252731e-02
    z[5,4,4]  R1586     5.9390628337860107e-01
    z[5,4,4]  R1587     -3.8776338100433350e-01
    z[5,4,4]  R1588     2.5676438584923744e-02
    z[5,4,4]  R1589     3.1820493936538696e-01
    z[5,4,4]  R1590     -1.7874620854854584e-01
    z[5,4,4]  R1591     -2.6201993227005005e-01
    z[5,4,4]  R1592     -1.4919523894786835e-01
    z[5,4,4]  R1593     -2.1776072680950165e-01
    z[5,4,4]  R1594     -3.7224754691123962e-01
    z[5,4,4]  R1595     5.7311993837356567e-01
    z[5,4,4]  R1596     3.3144921064376831e-01
    z[5,4,4]  R1597     -5.3990882635116577e-01
    z[5,4,4]  R1598     3.5976175218820572e-02
    z[5,4,4]  R1599     -0.162450909614563
    z[5,4,4]  R1600     2.7533066272735596e-01
    z[5,4,4]  R1601     2.1661397814750671e-01
    z[5,4,4]  R1602     -3.1194350123405457e-01
    z[5,4,4]  R1603     5.3216083906590939e-03
    z[5,4,4]  R1604     2.2346168756484985e-01
    z[5,4,4]  R1605     1.5192779898643494e-01
    z[5,4,4]  R1606     -2.9828497767448425e-01
    z[5,4,4]  R1607     0.280141681432724
    z[5,4,4]  R1608     -2.0264382660388947e-01
    z[5,4,4]  R1609     2.8758466243743896e-01
    z[5,4,4]  R1610     8.5873436182737350e-04
    z[5,4,4]  R1611     -1.1589819192886353e-01
    z[5,4,4]  R1612     -4.7125168144702911e-02
    z[5,4,4]  R1613     -5.8494526147842407e-01
    z[5,4,4]  R1614     -4.6181634068489075e-01
    z[5,4,4]  R1615     1.4247675240039825e-01
    z[5,4,4]  R1616     -1.6923119127750397e-01
    z[5,4,4]  R1617     -2.9892298579216003e-01
    z[5,4,4]  R1618     3.5811014473438263e-02
    z[5,4,4]  R1619     -1.5946429967880249e-01
    z[5,4,4]  R1620     -5.0564610958099365e-01
    z[5,4,4]  R1621     -1.6528847813606262e-01
    z[5,4,4]  R1622     -3.4734913706779480e-01
    z[5,4,4]  R1623     -2.7560099959373474e-01
    z[5,4,4]  R1624     1.1525370180606842e-01
    z[5,4,4]  R1625     -1.2992176413536072e-01
    z[5,4,4]  R1626     2.5555733591318130e-03
    z[5,4,4]  R1627     4.9524795264005661e-02
    z[5,4,4]  R1628     -1.4719154569320381e-04
    z[5,4,4]  R1629     2.0635944604873657e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R1546     -1
    z[5,4,5]  R1547     1
    z[5,4,5]  R1550     -5.6988209486007690e-01
    z[5,4,5]  R1551     -6.3853855244815350e-03
    z[5,4,5]  R1552     -3.9604845643043518e-01
    z[5,4,5]  R1553     -1.6567985713481903e-01
    z[5,4,5]  R1554     -1.9466885924339294e-01
    z[5,4,5]  R1555     -9.0171068906784058e-02
    z[5,4,5]  R1556     2.6869205757975578e-02
    z[5,4,5]  R1557     2.1448722109198570e-02
    z[5,4,5]  R1558     -5.2375471591949463e-01
    z[5,4,5]  R1559     -5.0364631414413452e-01
    z[5,4,5]  R1560     4.7354102134704590e-01
    z[5,4,5]  R1561     6.2358152866363525e-01
    z[5,4,5]  R1562     -1.8069872260093689e-01
    z[5,4,5]  R1563     4.4689774513244629e-01
    z[5,4,5]  R1564     1.8895292282104492e-01
    z[5,4,5]  R1565     -2.3948937654495239e-01
    z[5,4,5]  R1566     4.0278565883636475e-01
    z[5,4,5]  R1567     3.9408656954765320e-01
    z[5,4,5]  R1568     3.2812082767486572e-01
    z[5,4,5]  R1569     -3.1141281127929688e-01
    z[5,4,5]  R1570     -1.1388673633337021e-01
    z[5,4,5]  R1571     -1.6845078766345978e-01
    z[5,4,5]  R1572     -1.9640058279037476e-01
    z[5,4,5]  R1573     -5.7908177375793457e-01
    z[5,4,5]  R1574     4.5114055275917053e-01
    z[5,4,5]  R1575     -2.2129443287849426e-01
    z[5,4,5]  R1576     3.0819091200828552e-01
    z[5,4,5]  R1577     2.7421155571937561e-01
    z[5,4,5]  R1578     1.5060122311115265e-01
    z[5,4,5]  R1579     1.3864484429359436e-01
    z[5,4,5]  R1580     -8.7248824536800385e-02
    z[5,4,5]  R1581     -3.4173485636711121e-01
    z[5,4,5]  R1582     -2.6238659024238586e-01
    z[5,4,5]  R1583     -3.4383806586265564e-01
    z[5,4,5]  R1584     9.3546412885189056e-02
    z[5,4,5]  R1585     -6.0945028066635132e-01
    z[5,4,5]  R1586     -4.6668532490730286e-01
    z[5,4,5]  R1587     3.9792710542678833e-01
    z[5,4,5]  R1588     1.2828531861305237e-01
    z[5,4,5]  R1589     9.0913869440555573e-02
    z[5,4,5]  R1590     4.4212940335273743e-01
    z[5,4,5]  R1591     7.7977198362350464e-01
    z[5,4,5]  R1592     -4.2695045471191406e-01
    z[5,4,5]  R1593     3.7409138679504395e-01
    z[5,4,5]  R1594     9.4170890748500824e-02
    z[5,4,5]  R1595     3.5449784994125366e-01
    z[5,4,5]  R1596     3.2058224081993103e-01
    z[5,4,5]  R1597     0.0108823636546731
    z[5,4,5]  R1598     -0.0410323366522789
    z[5,4,5]  R1599     5.7950407266616821e-02
    z[5,4,5]  R1600     -2.5654423981904984e-02
    z[5,4,5]  R1601     -3.8571065664291382e-01
    z[5,4,5]  R1602     -2.5312250852584839e-01
    z[5,4,5]  R1603     2.0238001644611359e-01
    z[5,4,5]  R1604     4.6938553452491760e-01
    z[5,4,5]  R1605     1.9093506038188934e-01
    z[5,4,5]  R1606     0.0532853901386261
    z[5,4,5]  R1607     2.6255580782890320e-01
    z[5,4,5]  R1608     2.5324231386184692e-01
    z[5,4,5]  R1609     2.3000319302082062e-01
    z[5,4,5]  R1610     -2.4678705632686615e-01
    z[5,4,5]  R1611     -3.2962822914123535e-01
    z[5,4,5]  R1612     2.6725775003433228e-01
    z[5,4,5]  R1613     -2.3675398528575897e-01
    z[5,4,5]  R1614     -6.3373476266860962e-02
    z[5,4,5]  R1615     2.2593397647142410e-02
    z[5,4,5]  R1616     4.6157222986221313e-01
    z[5,4,5]  R1617     -2.4501267075538635e-01
    z[5,4,5]  R1618     -2.2183151543140411e-01
    z[5,4,5]  R1619     -1.8626582622528076e-01
    z[5,4,5]  R1620     1.2021089345216751e-01
    z[5,4,5]  R1621     -1.2923605740070343e-01
    z[5,4,5]  R1622     2.9020580649375916e-01
    z[5,4,5]  R1623     -2.4687018990516663e-01
    z[5,4,5]  R1624     -7.4510313570499420e-02
    z[5,4,5]  R1625     1.5238919854164124e-01
    z[5,4,5]  R1626     -4.1781923174858093e-01
    z[5,4,5]  R1627     -2.3594839870929718e-01
    z[5,4,5]  R1628     1.7438188195228577e-01
    z[5,4,5]  R1629     -2.5090718269348145e-01
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R1548     -1
    z[5,4,6]  R1549     1
    z[5,4,6]  R1550     1.9051089882850647e-01
    z[5,4,6]  R1551     -0.38516765832901
    z[5,4,6]  R1552     1.3256359100341797e-01
    z[5,4,6]  R1553     -1.2602607905864716e-01
    z[5,4,6]  R1554     1.7144057154655457e-01
    z[5,4,6]  R1555     0.315448522567749
    z[5,4,6]  R1556     -9.9200025200843811e-02
    z[5,4,6]  R1557     1.7386473715305328e-01
    z[5,4,6]  R1558     -1.4328743517398834e-01
    z[5,4,6]  R1559     -7.7792368829250336e-02
    z[5,4,6]  R1560     -3.7168782949447632e-01
    z[5,4,6]  R1561     -3.5316473245620728e-01
    z[5,4,6]  R1562     -4.5230352878570557e-01
    z[5,4,6]  R1563     2.2273132205009460e-01
    z[5,4,6]  R1564     -2.3438625037670135e-01
    z[5,4,6]  R1565     3.4495303034782410e-01
    z[5,4,6]  R1566     3.2797396183013916e-01
    z[5,4,6]  R1567     4.9378228187561035e-01
    z[5,4,6]  R1568     4.6263146400451660e-01
    z[5,4,6]  R1569     2.4267353117465973e-01
    z[5,4,6]  R1570     -1.3771170750260353e-02
    z[5,4,6]  R1571     3.6265552043914795e-01
    z[5,4,6]  R1572     4.4650569558143616e-01
    z[5,4,6]  R1573     -2.8255870565772057e-02
    z[5,4,6]  R1574     2.0609153807163239e-01
    z[5,4,6]  R1575     0.0699809193611145
    z[5,4,6]  R1576     1.3407501578330994e-01
    z[5,4,6]  R1577     1.0127907991409302e-01
    z[5,4,6]  R1578     3.5682967305183411e-01
    z[5,4,6]  R1579     -3.8814684748649597e-01
    z[5,4,6]  R1580     -1.8227215111255646e-01
    z[5,4,6]  R1581     4.8308894038200378e-01
    z[5,4,6]  R1582     -5.2540283650159836e-03
    z[5,4,6]  R1583     -1.7118491232395172e-01
    z[5,4,6]  R1584     -1.2941205501556396e-01
    z[5,4,6]  R1585     0.259101003408432
    z[5,4,6]  R1586     2.1217225492000580e-01
    z[5,4,6]  R1587     -2.0377086102962494e-01
    z[5,4,6]  R1588     4.9424994736909866e-02
    z[5,4,6]  R1589     3.2052415609359741e-01
    z[5,4,6]  R1590     -1.9010773301124573e-01
    z[5,4,6]  R1591     8.6065813899040222e-02
    z[5,4,6]  R1592     -7.1420705318450928e-01
    z[5,4,6]  R1593     -3.7376844882965088e-01
    z[5,4,6]  R1594     -1.0020061582326889e-01
    z[5,4,6]  R1595     3.3467730879783630e-01
    z[5,4,6]  R1596     -3.2956176996231079e-01
    z[5,4,6]  R1597     2.2259773313999176e-01
    z[5,4,6]  R1598     -2.7017902582883835e-02
    z[5,4,6]  R1599     1.3021923601627350e-01
    z[5,4,6]  R1600     8.4782741963863373e-02
    z[5,4,6]  R1601     2.4156148731708527e-01
    z[5,4,6]  R1602     -4.8951196670532227e-01
    z[5,4,6]  R1603     -2.1152982115745544e-01
    z[5,4,6]  R1604     -0.0820658802986145
    z[5,4,6]  R1605     -3.3595755696296692e-02
    z[5,4,6]  R1606     -4.2025718092918396e-01
    z[5,4,6]  R1607     1.0127981007099152e-01
    z[5,4,6]  R1608     2.3284368216991425e-01
    z[5,4,6]  R1609     -4.9966756254434586e-02
    z[5,4,6]  R1610     1.9454509019851685e-01
    z[5,4,6]  R1611     2.5387939065694809e-02
    z[5,4,6]  R1612     -2.3479017615318298e-01
    z[5,4,6]  R1613     -5.6522661447525024e-01
    z[5,4,6]  R1614     -3.1581774353981018e-01
    z[5,4,6]  R1615     -1.6999433934688568e-01
    z[5,4,6]  R1616     -4.7128465771675110e-01
    z[5,4,6]  R1617     -1.0066631436347961e-01
    z[5,4,6]  R1618     1.6159044206142426e-01
    z[5,4,6]  R1619     -2.1938814222812653e-01
    z[5,4,6]  R1620     -5.0658637285232544e-01
    z[5,4,6]  R1621     -4.6783113479614258e-01
    z[5,4,6]  R1622     1.0208971798419952e-02
    z[5,4,6]  R1623     -1.2860514223575592e-01
    z[5,4,6]  R1624     3.4179106354713440e-01
    z[5,4,6]  R1625     -7.7363565564155579e-02
    z[5,4,6]  R1626     3.2385224103927612e-01
    z[5,4,6]  R1627     1.7104333639144897e-01
    z[5,4,6]  R1628     2.9971027374267578e-01
    z[5,4,6]  R1629     -0.0792362168431282
    z[5,9,0]  R47       -1
    z[5,9,0]  R83       1
    z[5,9,0]  R1630     -1
    z[5,9,0]  R1631     1
    z[5,9,0]  R1644     4.9648988246917725e-01
    z[5,9,0]  R1645     -2.6639136672019958e-01
    z[5,9,0]  R1646     -1.2950626015663147e-01
    z[5,9,0]  R1647     -7.9698067903518677e-01
    z[5,9,0]  R1648     -3.7656205892562866e-01
    z[5,9,0]  R1649     -5.1015269756317139e-01
    z[5,9,0]  R1650     -4.2382824420928955e-01
    z[5,9,0]  R1651     -4.6033310890197754e-01
    z[5,9,0]  R1652     -5.0955390930175781e-01
    z[5,9,0]  R1653     0.242109477519989
    z[5,9,0]  R1654     6.1530214548110962e-01
    z[5,9,0]  R1655     -2.3542794585227966e-01
    z[5,9,0]  R1656     1.2747491896152496e-01
    z[5,9,0]  R1657     -1.9518758356571198e-01
    z[5,9,0]  R1658     7.8302729129791260e-01
    z[5,9,0]  R1659     -5.4339367151260376e-01
    z[5,9,0]  R1660     -3.0413594841957092e-01
    z[5,9,0]  R1661     -3.3105167746543884e-01
    z[5,9,0]  R1662     8.1613563001155853e-02
    z[5,9,0]  R1663     2.4063149094581604e-01
    z[5,9,0]  R1664     3.8187541067600250e-02
    z[5,9,0]  R1665     -1.1935734748840332e-01
    z[5,9,0]  R1666     -1.2596021592617035e-01
    z[5,9,0]  R1667     -1.0391132533550262e-01
    z[5,9,0]  R1668     -6.1322432756423950e-01
    z[5,9,0]  R1669     7.5107455253601074e-01
    z[5,9,0]  R1670     5.7250422239303589e-01
    z[5,9,0]  R1671     6.0374909639358521e-01
    z[5,9,0]  R1672     5.4553002119064331e-01
    z[5,9,0]  R1673     5.9053015708923340e-01
    z[5,9,0]  R1674     2.9108244180679321e-01
    z[5,9,0]  R1675     1.0858749598264694e-01
    z[5,9,0]  R1676     -1.3523830473423004e-01
    z[5,9,0]  R1677     -3.9431478828191757e-02
    z[5,9,0]  R1678     -7.5746321678161621e-01
    z[5,9,0]  R1679     -4.9538934230804443e-01
    z[5,9,0]  R1680     -3.5292613506317139e-01
    z[5,9,0]  R1681     -5.4493683576583862e-01
    z[5,9,0]  R1682     -6.1947625875473022e-01
    z[5,9,0]  R1683     2.3906965553760529e-01
    z[5,9,0]  R1684     -1.3276743888854980e-01
    z[5,9,0]  R1685     -8.9868523180484772e-02
    z[5,9,0]  R1686     4.7234547138214111e-01
    z[5,9,0]  R1687     4.7172546386718750e-01
    z[5,9,0]  R1688     6.4668184518814087e-01
    z[5,9,0]  R1689     7.9206550121307373e-01
    z[5,9,0]  R1690     2.9894074797630310e-01
    z[5,9,0]  R1691     -1.5389275550842285e-01
    z[5,9,0]  R1692     4.1839218139648438e-01
    z[5,9,0]  R1693     3.1511563062667847e-01
    z[5,9,0]  R1694     -1.0333719849586487e-01
    z[5,9,0]  R1695     1.1937688291072845e-01
    z[5,9,0]  R1696     2.9293406009674072e-01
    z[5,9,0]  R1697     4.3236732482910156e-02
    z[5,9,0]  R1698     2.5039976835250854e-01
    z[5,9,1]  R48       -1
    z[5,9,1]  R84       1
    z[5,9,1]  R1632     -1
    z[5,9,1]  R1633     1
    z[5,9,1]  R1644     4.3844223022460938e-02
    z[5,9,1]  R1645     -8.0521166324615479e-01
    z[5,9,1]  R1646     1.7489878460764885e-02
    z[5,9,1]  R1647     6.2313683331012726e-02
    z[5,9,1]  R1648     3.1382761895656586e-02
    z[5,9,1]  R1649     -4.2410698533058167e-01
    z[5,9,1]  R1650     -4.4718232750892639e-01
    z[5,9,1]  R1651     -3.6831203103065491e-01
    z[5,9,1]  R1652     -5.1659411191940308e-01
    z[5,9,1]  R1653     1.9754158332943916e-02
    z[5,9,1]  R1654     1.8612654507160187e-01
    z[5,9,1]  R1655     2.8649359941482544e-01
    z[5,9,1]  R1656     8.9528091251850128e-02
    z[5,9,1]  R1657     1.1711125075817108e-01
    z[5,9,1]  R1658     4.3407621979713440e-01
    z[5,9,1]  R1659     8.4541819989681244e-02
    z[5,9,1]  R1660     -3.3135646581649780e-01
    z[5,9,1]  R1661     -1.7478680610656738e-01
    z[5,9,1]  R1662     6.7083835601806641e-01
    z[5,9,1]  R1663     -4.4888365268707275e-01
    z[5,9,1]  R1664     9.6127837896347046e-01
    z[5,9,1]  R1665     8.2246738672256470e-01
    z[5,9,1]  R1666     4.5424845814704895e-01
    z[5,9,1]  R1667     0.443109393119812
    z[5,9,1]  R1668     -3.7199783325195312e-01
    z[5,9,1]  R1669     -3.4101182222366333e-01
    z[5,9,1]  R1670     -4.5097431540489197e-01
    z[5,9,1]  R1671     -3.9959374070167542e-01
    z[5,9,1]  R1672     -2.4694876372814178e-01
    z[5,9,1]  R1673     -5.7367813587188721e-01
    z[5,9,1]  R1674     -8.2997870445251465e-01
    z[5,9,1]  R1675     -7.7935463190078735e-01
    z[5,9,1]  R1676     -5.9373527765274048e-01
    z[5,9,1]  R1677     -6.0379111766815186e-01
    z[5,9,1]  R1678     -4.7035849094390869e-01
    z[5,9,1]  R1679     -1.7054872214794159e-01
    z[5,9,1]  R1680     -3.7646931409835815e-01
    z[5,9,1]  R1681     -4.0305751562118530e-01
    z[5,9,1]  R1682     1.5257827937602997e-01
    z[5,9,1]  R1683     1.5584002435207367e-01
    z[5,9,1]  R1684     6.6454339027404785e-01
    z[5,9,1]  R1685     5.0379019975662231e-01
    z[5,9,1]  R1686     5.3773826360702515e-01
    z[5,9,1]  R1687     5.3363138437271118e-01
    z[5,9,1]  R1688     4.7076827287673950e-01
    z[5,9,1]  R1689     8.5063174366950989e-02
    z[5,9,1]  R1690     -4.7014467418193817e-04
    z[5,9,1]  R1691     6.5266913175582886e-01
    z[5,9,1]  R1692     -1.2414242327213287e-01
    z[5,9,1]  R1693     5.1841062307357788e-01
    z[5,9,1]  R1694     -2.7463731169700623e-01
    z[5,9,1]  R1695     3.5437962412834167e-01
    z[5,9,1]  R1696     4.5150133967399597e-01
    z[5,9,1]  R1697     6.3977748155593872e-01
    z[5,9,1]  R1698     6.2359595298767090e-01
    z[5,9,2]  R49       -1
    z[5,9,2]  R85       1
    z[5,9,2]  R1634     -1
    z[5,9,2]  R1635     1
    z[5,9,2]  R1644     4.8482915759086609e-01
    z[5,9,2]  R1645     -9.0091131627559662e-02
    z[5,9,2]  R1646     7.8116357326507568e-01
    z[5,9,2]  R1647     1.9263638183474541e-02
    z[5,9,2]  R1648     8.7549078464508057e-01
    z[5,9,2]  R1649     1.1950641125440598e-01
    z[5,9,2]  R1650     0.636570155620575
    z[5,9,2]  R1651     -6.6055871546268463e-02
    z[5,9,2]  R1652     2.6292216777801514e-01
    z[5,9,2]  R1653     4.7815990447998047e-01
    z[5,9,2]  R1654     -3.6712530255317688e-01
    z[5,9,2]  R1655     -4.8442426323890686e-01
    z[5,9,2]  R1656     -8.3194905519485474e-01
    z[5,9,2]  R1657     -4.4412112236022949e-01
    z[5,9,2]  R1658     -8.4590762853622437e-02
    z[5,9,2]  R1659     -0.654270589351654
    z[5,9,2]  R1660     -4.4473114609718323e-01
    z[5,9,2]  R1661     -1.5737813711166382e-01
    z[5,9,2]  R1662     4.3987524509429932e-01
    z[5,9,2]  R1663     -0.320712685585022
    z[5,9,2]  R1664     2.4135455489158630e-01
    z[5,9,2]  R1665     -1.4329555444419384e-02
    z[5,9,2]  R1666     -4.6941635012626648e-01
    z[5,9,2]  R1667     -1.7301650345325470e-01
    z[5,9,2]  R1668     4.5983624458312988e-01
    z[5,9,2]  R1669     -0.0899103432893753
    z[5,9,2]  R1670     2.9243247583508492e-02
    z[5,9,2]  R1671     -3.3227629959583282e-02
    z[5,9,2]  R1672     4.6476915478706360e-01
    z[5,9,2]  R1673     3.0124038457870483e-01
    z[5,9,2]  R1674     -3.7251576781272888e-01
    z[5,9,2]  R1675     1.8337865173816681e-01
    z[5,9,2]  R1676     3.5857531428337097e-01
    z[5,9,2]  R1677     0.437838077545166
    z[5,9,2]  R1678     -2.1067656576633453e-01
    z[5,9,2]  R1679     3.9047864079475403e-01
    z[5,9,2]  R1680     -3.7782189249992371e-01
    z[5,9,2]  R1681     -2.3185496032238007e-01
    z[5,9,2]  R1682     -4.4014781713485718e-01
    z[5,9,2]  R1683     7.9295235872268677e-01
    z[5,9,2]  R1684     2.4608774110674858e-02
    z[5,9,2]  R1685     -2.2013923525810242e-01
    z[5,9,2]  R1686     -3.3044016361236572e-01
    z[5,9,2]  R1687     -1.3546082377433777e-01
    z[5,9,2]  R1688     -1.5414842963218689e-01
    z[5,9,2]  R1689     -5.7929926551878452e-03
    z[5,9,2]  R1690     7.7107146382331848e-02
    z[5,9,2]  R1691     -2.2462606430053711e-01
    z[5,9,2]  R1692     -7.6619662344455719e-02
    z[5,9,2]  R1693     -3.8277745246887207e-01
    z[5,9,2]  R1694     -5.3804613649845123e-02
    z[5,9,2]  R1695     -7.9975193738937378e-01
    z[5,9,2]  R1696     -0.514900803565979
    z[5,9,2]  R1697     1.4151570200920105e-01
    z[5,9,2]  R1698     4.7723045572638512e-03
    z[5,9,3]  R50       -1
    z[5,9,3]  R86       1
    z[5,9,3]  R1636     -1
    z[5,9,3]  R1637     1
    z[5,9,3]  R1644     -2.5866144895553589e-01
    z[5,9,3]  R1645     2.8459358215332031e-01
    z[5,9,3]  R1646     -2.8216877579689026e-01
    z[5,9,3]  R1647     -3.9917609095573425e-01
    z[5,9,3]  R1648     -4.4421613216400146e-02
    z[5,9,3]  R1649     3.2486149668693542e-01
    z[5,9,3]  R1650     2.8203946352005005e-01
    z[5,9,3]  R1651     7.6594430208206177e-01
    z[5,9,3]  R1652     7.3680356144905090e-02
    z[5,9,3]  R1653     -2.6583209633827209e-01
    z[5,9,3]  R1654     -2.9930931329727173e-01
    z[5,9,3]  R1655     3.0626082420349121e-01
    z[5,9,3]  R1656     1.1325030773878098e-01
    z[5,9,3]  R1657     -4.4818982481956482e-01
    z[5,9,3]  R1658     1.8112331628799438e-01
    z[5,9,3]  R1659     -2.3785674571990967e-01
    z[5,9,3]  R1660     -5.3479743003845215e-01
    z[5,9,3]  R1661     -0.523095965385437
    z[5,9,3]  R1662     1.0609175264835358e-01
    z[5,9,3]  R1663     -5.9104657173156738e-01
    z[5,9,3]  R1664     5.4408796131610870e-02
    z[5,9,3]  R1665     2.6956740021705627e-01
    z[5,9,3]  R1666     -2.3281428217887878e-01
    z[5,9,3]  R1667     2.6498386263847351e-01
    z[5,9,3]  R1668     -9.6142947673797607e-02
    z[5,9,3]  R1669     -5.0653403997421265e-01
    z[5,9,3]  R1670     -5.6126654148101807e-01
    z[5,9,3]  R1671     -5.6971663236618042e-01
    z[5,9,3]  R1672     -4.8686710000038147e-01
    z[5,9,3]  R1673     -1.4440187811851501e-01
    z[5,9,3]  R1674     0.00329585955478251
    z[5,9,3]  R1675     -3.4972104430198669e-01
    z[5,9,3]  R1676     -2.3019210994243622e-01
    z[5,9,3]  R1677     2.3709204792976379e-01
    z[5,9,3]  R1678     -8.1858143210411072e-02
    z[5,9,3]  R1679     6.4881277084350586e-01
    z[5,9,3]  R1680     5.5613040924072266e-01
    z[5,9,3]  R1681     9.4230584800243378e-02
    z[5,9,3]  R1682     -4.1764503717422485e-01
    z[5,9,3]  R1683     4.4771265983581543e-01
    z[5,9,3]  R1684     1.3020020909607410e-02
    z[5,9,3]  R1685     5.1018267869949341e-01
    z[5,9,3]  R1686     3.1320884823799133e-01
    z[5,9,3]  R1687     -6.6068537533283234e-02
    z[5,9,3]  R1688     -4.3311378359794617e-01
    z[5,9,3]  R1689     1.6431353986263275e-01
    z[5,9,3]  R1690     -1.0704349726438522e-01
    z[5,9,3]  R1691     6.0342226177453995e-02
    z[5,9,3]  R1692     3.1790229678153992e-01
    z[5,9,3]  R1693     -3.4703891724348068e-02
    z[5,9,3]  R1694     -2.5287717580795288e-01
    z[5,9,3]  R1695     -1.0735470056533813e-01
    z[5,9,3]  R1696     -4.0629172325134277e-01
    z[5,9,3]  R1697     -7.2742298245429993e-02
    z[5,9,3]  R1698     -5.4337286949157715e-01
    z[5,9,4]  R51       -1
    z[5,9,4]  R87       1
    z[5,9,4]  R1638     -1
    z[5,9,4]  R1639     1
    z[5,9,4]  R1644     -2.9757422208786011e-01
    z[5,9,4]  R1645     2.0776192843914032e-01
    z[5,9,4]  R1646     -3.4446901082992554e-01
    z[5,9,4]  R1647     -3.9735859632492065e-01
    z[5,9,4]  R1648     1.4652957022190094e-01
    z[5,9,4]  R1649     5.7656061649322510e-01
    z[5,9,4]  R1650     3.5364833474159241e-01
    z[5,9,4]  R1651     -1.7526137828826904e-01
    z[5,9,4]  R1652     -3.2261142134666443e-01
    z[5,9,4]  R1653     6.1804372072219849e-01
    z[5,9,4]  R1654     4.1991323814727366e-04
    z[5,9,4]  R1655     -1.4301495254039764e-01
    z[5,9,4]  R1656     1.8313780426979065e-01
    z[5,9,4]  R1657     5.4839968681335449e-01
    z[5,9,4]  R1658     2.6046988368034363e-01
    z[5,9,4]  R1659     1.9126552343368530e-01
    z[5,9,4]  R1660     2.1001639962196350e-01
    z[5,9,4]  R1661     -4.0290430188179016e-01
    z[5,9,4]  R1662     -1.2991668283939362e-01
    z[5,9,4]  R1663     3.6405879259109497e-01
    z[5,9,4]  R1664     1.0645199567079544e-02
    z[5,9,4]  R1665     2.7664875984191895e-01
    z[5,9,4]  R1666     -5.1507055759429932e-01
    z[5,9,4]  R1667     -5.9713596105575562e-01
    z[5,9,4]  R1668     -1.3740111887454987e-01
    z[5,9,4]  R1669     3.2693885266780853e-02
    z[5,9,4]  R1670     2.0006994903087616e-01
    z[5,9,4]  R1671     -2.5432524085044861e-01
    z[5,9,4]  R1672     -1.9584493339061737e-01
    z[5,9,4]  R1673     -2.0171651244163513e-01
    z[5,9,4]  R1674     2.1075251698493958e-01
    z[5,9,4]  R1675     2.9115694761276245e-01
    z[5,9,4]  R1676     4.3395614624023438e-01
    z[5,9,4]  R1677     2.1299500763416290e-01
    z[5,9,4]  R1678     3.5171902179718018e-01
    z[5,9,4]  R1679     2.6832661032676697e-01
    z[5,9,4]  R1680     4.2752283811569214e-01
    z[5,9,4]  R1681     -2.6234707236289978e-01
    z[5,9,4]  R1682     -4.2021086812019348e-01
    z[5,9,4]  R1683     -2.1181757748126984e-01
    z[5,9,4]  R1684     0.724141538143158
    z[5,9,4]  R1685     1.9579641520977020e-01
    z[5,9,4]  R1686     -3.8013958930969238e-01
    z[5,9,4]  R1687     -4.9037012457847595e-01
    z[5,9,4]  R1688     -0.256389856338501
    z[5,9,4]  R1689     -2.0562279224395752e-01
    z[5,9,4]  R1690     -5.0673949718475342e-01
    z[5,9,4]  R1691     -5.8236700296401978e-01
    z[5,9,4]  R1692     -6.7370104789733887e-01
    z[5,9,4]  R1693     -5.4973214864730835e-01
    z[5,9,4]  R1694     -5.8169674873352051e-01
    z[5,9,4]  R1695     -1.6659784317016602e-01
    z[5,9,4]  R1696     -2.9732853174209595e-01
    z[5,9,4]  R1697     -4.4157716631889343e-01
    z[5,9,4]  R1698     -4.3555518984794617e-01
    z[5,9,5]  R52       -1
    z[5,9,5]  R88       1
    z[5,9,5]  R1640     -1
    z[5,9,5]  R1641     1
    z[5,9,5]  R1644     -5.6988209486007690e-01
    z[5,9,5]  R1645     -6.3853855244815350e-03
    z[5,9,5]  R1646     -3.9604845643043518e-01
    z[5,9,5]  R1647     -1.6567985713481903e-01
    z[5,9,5]  R1648     -1.9466885924339294e-01
    z[5,9,5]  R1649     -9.0171068906784058e-02
    z[5,9,5]  R1650     2.6869205757975578e-02
    z[5,9,5]  R1651     2.1448722109198570e-02
    z[5,9,5]  R1652     -5.2375471591949463e-01
    z[5,9,5]  R1653     -5.0364631414413452e-01
    z[5,9,5]  R1654     4.7354102134704590e-01
    z[5,9,5]  R1655     6.2358152866363525e-01
    z[5,9,5]  R1656     -1.8069872260093689e-01
    z[5,9,5]  R1657     4.4689774513244629e-01
    z[5,9,5]  R1658     1.8895292282104492e-01
    z[5,9,5]  R1659     -2.3948937654495239e-01
    z[5,9,5]  R1660     4.0278565883636475e-01
    z[5,9,5]  R1661     3.9408656954765320e-01
    z[5,9,5]  R1662     3.2812082767486572e-01
    z[5,9,5]  R1663     -3.1141281127929688e-01
    z[5,9,5]  R1664     -1.1388673633337021e-01
    z[5,9,5]  R1665     -1.6845078766345978e-01
    z[5,9,5]  R1666     -1.9640058279037476e-01
    z[5,9,5]  R1667     -5.7908177375793457e-01
    z[5,9,5]  R1668     4.5114055275917053e-01
    z[5,9,5]  R1669     -2.2129443287849426e-01
    z[5,9,5]  R1670     3.0819091200828552e-01
    z[5,9,5]  R1671     2.7421155571937561e-01
    z[5,9,5]  R1672     1.5060122311115265e-01
    z[5,9,5]  R1673     1.3864484429359436e-01
    z[5,9,5]  R1674     -4.7877408564090729e-02
    z[5,9,5]  R1675     -2.8288233280181885e-01
    z[5,9,5]  R1676     1.3415230810642242e-01
    z[5,9,5]  R1677     -3.6059868335723877e-01
    z[5,9,5]  R1678     3.1892888247966766e-02
    z[5,9,5]  R1679     2.2661669552326202e-01
    z[5,9,5]  R1680     1.4870745129883289e-02
    z[5,9,5]  R1681     2.2744987905025482e-01
    z[5,9,5]  R1682     -2.8606725856661797e-02
    z[5,9,5]  R1683     -2.1060074865818024e-01
    z[5,9,5]  R1684     -1.2489126622676849e-01
    z[5,9,5]  R1685     8.5017554461956024e-02
    z[5,9,5]  R1686     -9.6607245504856110e-02
    z[5,9,5]  R1687     4.6893692016601562e-01
    z[5,9,5]  R1688     -2.0405773818492889e-01
    z[5,9,5]  R1689     3.2776159048080444e-01
    z[5,9,5]  R1690     7.9625159502029419e-01
    z[5,9,5]  R1691     -6.5661803819239140e-03
    z[5,9,5]  R1692     -2.2077096998691559e-01
    z[5,9,5]  R1693     -4.2254430055618286e-01
    z[5,9,5]  R1694     6.6329681873321533e-01
    z[5,9,5]  R1695     1.9180832803249359e-01
    z[5,9,5]  R1696     3.3409810066223145e-01
    z[5,9,5]  R1697     5.8726257085800171e-01
    z[5,9,5]  R1698     -1.9228871911764145e-02
    z[5,9,6]  R53       -1
    z[5,9,6]  R89       1
    z[5,9,6]  R1642     -1
    z[5,9,6]  R1643     1
    z[5,9,6]  R1644     1.9051089882850647e-01
    z[5,9,6]  R1645     -0.38516765832901
    z[5,9,6]  R1646     1.3256359100341797e-01
    z[5,9,6]  R1647     -1.2602607905864716e-01
    z[5,9,6]  R1648     1.7144057154655457e-01
    z[5,9,6]  R1649     0.315448522567749
    z[5,9,6]  R1650     -9.9200025200843811e-02
    z[5,9,6]  R1651     1.7386473715305328e-01
    z[5,9,6]  R1652     -1.4328743517398834e-01
    z[5,9,6]  R1653     -7.7792368829250336e-02
    z[5,9,6]  R1654     -3.7168782949447632e-01
    z[5,9,6]  R1655     -3.5316473245620728e-01
    z[5,9,6]  R1656     -4.5230352878570557e-01
    z[5,9,6]  R1657     2.2273132205009460e-01
    z[5,9,6]  R1658     -2.3438625037670135e-01
    z[5,9,6]  R1659     3.4495303034782410e-01
    z[5,9,6]  R1660     3.2797396183013916e-01
    z[5,9,6]  R1661     4.9378228187561035e-01
    z[5,9,6]  R1662     4.6263146400451660e-01
    z[5,9,6]  R1663     2.4267353117465973e-01
    z[5,9,6]  R1664     -1.3771170750260353e-02
    z[5,9,6]  R1665     3.6265552043914795e-01
    z[5,9,6]  R1666     4.4650569558143616e-01
    z[5,9,6]  R1667     -2.8255870565772057e-02
    z[5,9,6]  R1668     2.0609153807163239e-01
    z[5,9,6]  R1669     0.0699809193611145
    z[5,9,6]  R1670     1.3407501578330994e-01
    z[5,9,6]  R1671     1.0127907991409302e-01
    z[5,9,6]  R1672     3.5682967305183411e-01
    z[5,9,6]  R1673     -3.8814684748649597e-01
    z[5,9,6]  R1674     2.0228348672389984e-01
    z[5,9,6]  R1675     -2.4512818455696106e-01
    z[5,9,6]  R1676     4.9123266339302063e-01
    z[5,9,6]  R1677     0.458877295255661
    z[5,9,6]  R1678     -1.7089027166366577e-01
    z[5,9,6]  R1679     -1.6945970058441162e-01
    z[5,9,6]  R1680     -0.314144492149353
    z[5,9,6]  R1681     -5.9782350063323975e-01
    z[5,9,6]  R1682     -2.1775241196155548e-01
    z[5,9,6]  R1683     -1.0965825989842415e-02
    z[5,9,6]  R1684     -9.3064224347472191e-04
    z[5,9,6]  R1685     6.1952179670333862e-01
    z[5,9,6]  R1686     -3.5580569505691528e-01
    z[5,9,6]  R1687     -9.8149202764034271e-02
    z[5,9,6]  R1688     2.0360575616359711e-01
    z[5,9,6]  R1689     -0.434345006942749
    z[5,9,6]  R1690     4.9282174557447433e-02
    z[5,9,6]  R1691     -3.9629215002059937e-01
    z[5,9,6]  R1692     -0.447204053401947
    z[5,9,6]  R1693     -5.8996759355068207e-02
    z[5,9,6]  R1694     2.6214540004730225e-01
    z[5,9,6]  R1695     -3.8011962175369263e-01
    z[5,9,6]  R1696     -2.8304505348205566e-01
    z[5,9,6]  R1697     -1.5371902287006378e-01
    z[5,9,6]  R1698     2.5114363431930542e-01
    z[9,5,0]  R47       1
    z[9,5,0]  R83       -1
    z[9,5,0]  R1699     -1
    z[9,5,0]  R1700     1
    z[9,5,0]  R1713     2.9108244180679321e-01
    z[9,5,0]  R1714     1.0858749598264694e-01
    z[9,5,0]  R1715     -1.3523830473423004e-01
    z[9,5,0]  R1716     -3.9431478828191757e-02
    z[9,5,0]  R1717     -7.5746321678161621e-01
    z[9,5,0]  R1718     -4.9538934230804443e-01
    z[9,5,0]  R1719     -3.5292613506317139e-01
    z[9,5,0]  R1720     -5.4493683576583862e-01
    z[9,5,0]  R1721     -6.1947625875473022e-01
    z[9,5,0]  R1722     2.3906965553760529e-01
    z[9,5,0]  R1723     -1.3276743888854980e-01
    z[9,5,0]  R1724     -8.9868523180484772e-02
    z[9,5,0]  R1725     4.7234547138214111e-01
    z[9,5,0]  R1726     4.7172546386718750e-01
    z[9,5,0]  R1727     6.4668184518814087e-01
    z[9,5,0]  R1728     7.9206550121307373e-01
    z[9,5,0]  R1729     2.9894074797630310e-01
    z[9,5,0]  R1730     -1.5389275550842285e-01
    z[9,5,0]  R1731     4.1839218139648438e-01
    z[9,5,0]  R1732     3.1511563062667847e-01
    z[9,5,0]  R1733     -1.0333719849586487e-01
    z[9,5,0]  R1734     1.1937688291072845e-01
    z[9,5,0]  R1735     2.9293406009674072e-01
    z[9,5,0]  R1736     4.3236732482910156e-02
    z[9,5,0]  R1737     2.5039976835250854e-01
    z[9,5,0]  R1738     4.9648988246917725e-01
    z[9,5,0]  R1739     -2.6639136672019958e-01
    z[9,5,0]  R1740     -1.2950626015663147e-01
    z[9,5,0]  R1741     -7.9698067903518677e-01
    z[9,5,0]  R1742     -3.7656205892562866e-01
    z[9,5,0]  R1743     -5.1015269756317139e-01
    z[9,5,0]  R1744     -4.2382824420928955e-01
    z[9,5,0]  R1745     -4.6033310890197754e-01
    z[9,5,0]  R1746     -5.0955390930175781e-01
    z[9,5,0]  R1747     0.242109477519989
    z[9,5,0]  R1748     6.1530214548110962e-01
    z[9,5,0]  R1749     -2.3542794585227966e-01
    z[9,5,0]  R1750     1.2747491896152496e-01
    z[9,5,0]  R1751     -1.9518758356571198e-01
    z[9,5,0]  R1752     7.8302729129791260e-01
    z[9,5,0]  R1753     -5.4339367151260376e-01
    z[9,5,0]  R1754     -3.0413594841957092e-01
    z[9,5,0]  R1755     -3.3105167746543884e-01
    z[9,5,0]  R1756     8.1613563001155853e-02
    z[9,5,0]  R1757     2.4063149094581604e-01
    z[9,5,0]  R1758     3.8187541067600250e-02
    z[9,5,0]  R1759     -1.1935734748840332e-01
    z[9,5,0]  R1760     -1.2596021592617035e-01
    z[9,5,0]  R1761     -1.0391132533550262e-01
    z[9,5,0]  R1762     -6.1322432756423950e-01
    z[9,5,0]  R1763     7.5107455253601074e-01
    z[9,5,0]  R1764     5.7250422239303589e-01
    z[9,5,0]  R1765     6.0374909639358521e-01
    z[9,5,0]  R1766     5.4553002119064331e-01
    z[9,5,0]  R1767     5.9053015708923340e-01
    z[9,5,1]  R48       1
    z[9,5,1]  R84       -1
    z[9,5,1]  R1701     -1
    z[9,5,1]  R1702     1
    z[9,5,1]  R1713     -8.2997870445251465e-01
    z[9,5,1]  R1714     -7.7935463190078735e-01
    z[9,5,1]  R1715     -5.9373527765274048e-01
    z[9,5,1]  R1716     -6.0379111766815186e-01
    z[9,5,1]  R1717     -4.7035849094390869e-01
    z[9,5,1]  R1718     -1.7054872214794159e-01
    z[9,5,1]  R1719     -3.7646931409835815e-01
    z[9,5,1]  R1720     -4.0305751562118530e-01
    z[9,5,1]  R1721     1.5257827937602997e-01
    z[9,5,1]  R1722     1.5584002435207367e-01
    z[9,5,1]  R1723     6.6454339027404785e-01
    z[9,5,1]  R1724     5.0379019975662231e-01
    z[9,5,1]  R1725     5.3773826360702515e-01
    z[9,5,1]  R1726     5.3363138437271118e-01
    z[9,5,1]  R1727     4.7076827287673950e-01
    z[9,5,1]  R1728     8.5063174366950989e-02
    z[9,5,1]  R1729     -4.7014467418193817e-04
    z[9,5,1]  R1730     6.5266913175582886e-01
    z[9,5,1]  R1731     -1.2414242327213287e-01
    z[9,5,1]  R1732     5.1841062307357788e-01
    z[9,5,1]  R1733     -2.7463731169700623e-01
    z[9,5,1]  R1734     3.5437962412834167e-01
    z[9,5,1]  R1735     4.5150133967399597e-01
    z[9,5,1]  R1736     6.3977748155593872e-01
    z[9,5,1]  R1737     6.2359595298767090e-01
    z[9,5,1]  R1738     4.3844223022460938e-02
    z[9,5,1]  R1739     -8.0521166324615479e-01
    z[9,5,1]  R1740     1.7489878460764885e-02
    z[9,5,1]  R1741     6.2313683331012726e-02
    z[9,5,1]  R1742     3.1382761895656586e-02
    z[9,5,1]  R1743     -4.2410698533058167e-01
    z[9,5,1]  R1744     -4.4718232750892639e-01
    z[9,5,1]  R1745     -3.6831203103065491e-01
    z[9,5,1]  R1746     -5.1659411191940308e-01
    z[9,5,1]  R1747     1.9754158332943916e-02
    z[9,5,1]  R1748     1.8612654507160187e-01
    z[9,5,1]  R1749     2.8649359941482544e-01
    z[9,5,1]  R1750     8.9528091251850128e-02
    z[9,5,1]  R1751     1.1711125075817108e-01
    z[9,5,1]  R1752     4.3407621979713440e-01
    z[9,5,1]  R1753     8.4541819989681244e-02
    z[9,5,1]  R1754     -3.3135646581649780e-01
    z[9,5,1]  R1755     -1.7478680610656738e-01
    z[9,5,1]  R1756     6.7083835601806641e-01
    z[9,5,1]  R1757     -4.4888365268707275e-01
    z[9,5,1]  R1758     9.6127837896347046e-01
    z[9,5,1]  R1759     8.2246738672256470e-01
    z[9,5,1]  R1760     4.5424845814704895e-01
    z[9,5,1]  R1761     0.443109393119812
    z[9,5,1]  R1762     -3.7199783325195312e-01
    z[9,5,1]  R1763     -3.4101182222366333e-01
    z[9,5,1]  R1764     -4.5097431540489197e-01
    z[9,5,1]  R1765     -3.9959374070167542e-01
    z[9,5,1]  R1766     -2.4694876372814178e-01
    z[9,5,1]  R1767     -5.7367813587188721e-01
    z[9,5,2]  R49       1
    z[9,5,2]  R85       -1
    z[9,5,2]  R1703     -1
    z[9,5,2]  R1704     1
    z[9,5,2]  R1713     -3.7251576781272888e-01
    z[9,5,2]  R1714     1.8337865173816681e-01
    z[9,5,2]  R1715     3.5857531428337097e-01
    z[9,5,2]  R1716     0.437838077545166
    z[9,5,2]  R1717     -2.1067656576633453e-01
    z[9,5,2]  R1718     3.9047864079475403e-01
    z[9,5,2]  R1719     -3.7782189249992371e-01
    z[9,5,2]  R1720     -2.3185496032238007e-01
    z[9,5,2]  R1721     -4.4014781713485718e-01
    z[9,5,2]  R1722     7.9295235872268677e-01
    z[9,5,2]  R1723     2.4608774110674858e-02
    z[9,5,2]  R1724     -2.2013923525810242e-01
    z[9,5,2]  R1725     -3.3044016361236572e-01
    z[9,5,2]  R1726     -1.3546082377433777e-01
    z[9,5,2]  R1727     -1.5414842963218689e-01
    z[9,5,2]  R1728     -5.7929926551878452e-03
    z[9,5,2]  R1729     7.7107146382331848e-02
    z[9,5,2]  R1730     -2.2462606430053711e-01
    z[9,5,2]  R1731     -7.6619662344455719e-02
    z[9,5,2]  R1732     -3.8277745246887207e-01
    z[9,5,2]  R1733     -5.3804613649845123e-02
    z[9,5,2]  R1734     -7.9975193738937378e-01
    z[9,5,2]  R1735     -0.514900803565979
    z[9,5,2]  R1736     1.4151570200920105e-01
    z[9,5,2]  R1737     4.7723045572638512e-03
    z[9,5,2]  R1738     4.8482915759086609e-01
    z[9,5,2]  R1739     -9.0091131627559662e-02
    z[9,5,2]  R1740     7.8116357326507568e-01
    z[9,5,2]  R1741     1.9263638183474541e-02
    z[9,5,2]  R1742     8.7549078464508057e-01
    z[9,5,2]  R1743     1.1950641125440598e-01
    z[9,5,2]  R1744     0.636570155620575
    z[9,5,2]  R1745     -6.6055871546268463e-02
    z[9,5,2]  R1746     2.6292216777801514e-01
    z[9,5,2]  R1747     4.7815990447998047e-01
    z[9,5,2]  R1748     -3.6712530255317688e-01
    z[9,5,2]  R1749     -4.8442426323890686e-01
    z[9,5,2]  R1750     -8.3194905519485474e-01
    z[9,5,2]  R1751     -4.4412112236022949e-01
    z[9,5,2]  R1752     -8.4590762853622437e-02
    z[9,5,2]  R1753     -0.654270589351654
    z[9,5,2]  R1754     -4.4473114609718323e-01
    z[9,5,2]  R1755     -1.5737813711166382e-01
    z[9,5,2]  R1756     4.3987524509429932e-01
    z[9,5,2]  R1757     -0.320712685585022
    z[9,5,2]  R1758     2.4135455489158630e-01
    z[9,5,2]  R1759     -1.4329555444419384e-02
    z[9,5,2]  R1760     -4.6941635012626648e-01
    z[9,5,2]  R1761     -1.7301650345325470e-01
    z[9,5,2]  R1762     4.5983624458312988e-01
    z[9,5,2]  R1763     -0.0899103432893753
    z[9,5,2]  R1764     2.9243247583508492e-02
    z[9,5,2]  R1765     -3.3227629959583282e-02
    z[9,5,2]  R1766     4.6476915478706360e-01
    z[9,5,2]  R1767     3.0124038457870483e-01
    z[9,5,3]  R50       1
    z[9,5,3]  R86       -1
    z[9,5,3]  R1705     -1
    z[9,5,3]  R1706     1
    z[9,5,3]  R1713     0.00329585955478251
    z[9,5,3]  R1714     -3.4972104430198669e-01
    z[9,5,3]  R1715     -2.3019210994243622e-01
    z[9,5,3]  R1716     2.3709204792976379e-01
    z[9,5,3]  R1717     -8.1858143210411072e-02
    z[9,5,3]  R1718     6.4881277084350586e-01
    z[9,5,3]  R1719     5.5613040924072266e-01
    z[9,5,3]  R1720     9.4230584800243378e-02
    z[9,5,3]  R1721     -4.1764503717422485e-01
    z[9,5,3]  R1722     4.4771265983581543e-01
    z[9,5,3]  R1723     1.3020020909607410e-02
    z[9,5,3]  R1724     5.1018267869949341e-01
    z[9,5,3]  R1725     3.1320884823799133e-01
    z[9,5,3]  R1726     -6.6068537533283234e-02
    z[9,5,3]  R1727     -4.3311378359794617e-01
    z[9,5,3]  R1728     1.6431353986263275e-01
    z[9,5,3]  R1729     -1.0704349726438522e-01
    z[9,5,3]  R1730     6.0342226177453995e-02
    z[9,5,3]  R1731     3.1790229678153992e-01
    z[9,5,3]  R1732     -3.4703891724348068e-02
    z[9,5,3]  R1733     -2.5287717580795288e-01
    z[9,5,3]  R1734     -1.0735470056533813e-01
    z[9,5,3]  R1735     -4.0629172325134277e-01
    z[9,5,3]  R1736     -7.2742298245429993e-02
    z[9,5,3]  R1737     -5.4337286949157715e-01
    z[9,5,3]  R1738     -2.5866144895553589e-01
    z[9,5,3]  R1739     2.8459358215332031e-01
    z[9,5,3]  R1740     -2.8216877579689026e-01
    z[9,5,3]  R1741     -3.9917609095573425e-01
    z[9,5,3]  R1742     -4.4421613216400146e-02
    z[9,5,3]  R1743     3.2486149668693542e-01
    z[9,5,3]  R1744     2.8203946352005005e-01
    z[9,5,3]  R1745     7.6594430208206177e-01
    z[9,5,3]  R1746     7.3680356144905090e-02
    z[9,5,3]  R1747     -2.6583209633827209e-01
    z[9,5,3]  R1748     -2.9930931329727173e-01
    z[9,5,3]  R1749     3.0626082420349121e-01
    z[9,5,3]  R1750     1.1325030773878098e-01
    z[9,5,3]  R1751     -4.4818982481956482e-01
    z[9,5,3]  R1752     1.8112331628799438e-01
    z[9,5,3]  R1753     -2.3785674571990967e-01
    z[9,5,3]  R1754     -5.3479743003845215e-01
    z[9,5,3]  R1755     -0.523095965385437
    z[9,5,3]  R1756     1.0609175264835358e-01
    z[9,5,3]  R1757     -5.9104657173156738e-01
    z[9,5,3]  R1758     5.4408796131610870e-02
    z[9,5,3]  R1759     2.6956740021705627e-01
    z[9,5,3]  R1760     -2.3281428217887878e-01
    z[9,5,3]  R1761     2.6498386263847351e-01
    z[9,5,3]  R1762     -9.6142947673797607e-02
    z[9,5,3]  R1763     -5.0653403997421265e-01
    z[9,5,3]  R1764     -5.6126654148101807e-01
    z[9,5,3]  R1765     -5.6971663236618042e-01
    z[9,5,3]  R1766     -4.8686710000038147e-01
    z[9,5,3]  R1767     -1.4440187811851501e-01
    z[9,5,4]  R51       1
    z[9,5,4]  R87       -1
    z[9,5,4]  R1707     -1
    z[9,5,4]  R1708     1
    z[9,5,4]  R1713     2.1075251698493958e-01
    z[9,5,4]  R1714     2.9115694761276245e-01
    z[9,5,4]  R1715     4.3395614624023438e-01
    z[9,5,4]  R1716     2.1299500763416290e-01
    z[9,5,4]  R1717     3.5171902179718018e-01
    z[9,5,4]  R1718     2.6832661032676697e-01
    z[9,5,4]  R1719     4.2752283811569214e-01
    z[9,5,4]  R1720     -2.6234707236289978e-01
    z[9,5,4]  R1721     -4.2021086812019348e-01
    z[9,5,4]  R1722     -2.1181757748126984e-01
    z[9,5,4]  R1723     0.724141538143158
    z[9,5,4]  R1724     1.9579641520977020e-01
    z[9,5,4]  R1725     -3.8013958930969238e-01
    z[9,5,4]  R1726     -4.9037012457847595e-01
    z[9,5,4]  R1727     -0.256389856338501
    z[9,5,4]  R1728     -2.0562279224395752e-01
    z[9,5,4]  R1729     -5.0673949718475342e-01
    z[9,5,4]  R1730     -5.8236700296401978e-01
    z[9,5,4]  R1731     -6.7370104789733887e-01
    z[9,5,4]  R1732     -5.4973214864730835e-01
    z[9,5,4]  R1733     -5.8169674873352051e-01
    z[9,5,4]  R1734     -1.6659784317016602e-01
    z[9,5,4]  R1735     -2.9732853174209595e-01
    z[9,5,4]  R1736     -4.4157716631889343e-01
    z[9,5,4]  R1737     -4.3555518984794617e-01
    z[9,5,4]  R1738     -2.9757422208786011e-01
    z[9,5,4]  R1739     2.0776192843914032e-01
    z[9,5,4]  R1740     -3.4446901082992554e-01
    z[9,5,4]  R1741     -3.9735859632492065e-01
    z[9,5,4]  R1742     1.4652957022190094e-01
    z[9,5,4]  R1743     5.7656061649322510e-01
    z[9,5,4]  R1744     3.5364833474159241e-01
    z[9,5,4]  R1745     -1.7526137828826904e-01
    z[9,5,4]  R1746     -3.2261142134666443e-01
    z[9,5,4]  R1747     6.1804372072219849e-01
    z[9,5,4]  R1748     4.1991323814727366e-04
    z[9,5,4]  R1749     -1.4301495254039764e-01
    z[9,5,4]  R1750     1.8313780426979065e-01
    z[9,5,4]  R1751     5.4839968681335449e-01
    z[9,5,4]  R1752     2.6046988368034363e-01
    z[9,5,4]  R1753     1.9126552343368530e-01
    z[9,5,4]  R1754     2.1001639962196350e-01
    z[9,5,4]  R1755     -4.0290430188179016e-01
    z[9,5,4]  R1756     -1.2991668283939362e-01
    z[9,5,4]  R1757     3.6405879259109497e-01
    z[9,5,4]  R1758     1.0645199567079544e-02
    z[9,5,4]  R1759     2.7664875984191895e-01
    z[9,5,4]  R1760     -5.1507055759429932e-01
    z[9,5,4]  R1761     -5.9713596105575562e-01
    z[9,5,4]  R1762     -1.3740111887454987e-01
    z[9,5,4]  R1763     3.2693885266780853e-02
    z[9,5,4]  R1764     2.0006994903087616e-01
    z[9,5,4]  R1765     -2.5432524085044861e-01
    z[9,5,4]  R1766     -1.9584493339061737e-01
    z[9,5,4]  R1767     -2.0171651244163513e-01
    z[9,5,5]  R52       1
    z[9,5,5]  R88       -1
    z[9,5,5]  R1709     -1
    z[9,5,5]  R1710     1
    z[9,5,5]  R1713     -4.7877408564090729e-02
    z[9,5,5]  R1714     -2.8288233280181885e-01
    z[9,5,5]  R1715     1.3415230810642242e-01
    z[9,5,5]  R1716     -3.6059868335723877e-01
    z[9,5,5]  R1717     3.1892888247966766e-02
    z[9,5,5]  R1718     2.2661669552326202e-01
    z[9,5,5]  R1719     1.4870745129883289e-02
    z[9,5,5]  R1720     2.2744987905025482e-01
    z[9,5,5]  R1721     -2.8606725856661797e-02
    z[9,5,5]  R1722     -2.1060074865818024e-01
    z[9,5,5]  R1723     -1.2489126622676849e-01
    z[9,5,5]  R1724     8.5017554461956024e-02
    z[9,5,5]  R1725     -9.6607245504856110e-02
    z[9,5,5]  R1726     4.6893692016601562e-01
    z[9,5,5]  R1727     -2.0405773818492889e-01
    z[9,5,5]  R1728     3.2776159048080444e-01
    z[9,5,5]  R1729     7.9625159502029419e-01
    z[9,5,5]  R1730     -6.5661803819239140e-03
    z[9,5,5]  R1731     -2.2077096998691559e-01
    z[9,5,5]  R1732     -4.2254430055618286e-01
    z[9,5,5]  R1733     6.6329681873321533e-01
    z[9,5,5]  R1734     1.9180832803249359e-01
    z[9,5,5]  R1735     3.3409810066223145e-01
    z[9,5,5]  R1736     5.8726257085800171e-01
    z[9,5,5]  R1737     -1.9228871911764145e-02
    z[9,5,5]  R1738     -5.6988209486007690e-01
    z[9,5,5]  R1739     -6.3853855244815350e-03
    z[9,5,5]  R1740     -3.9604845643043518e-01
    z[9,5,5]  R1741     -1.6567985713481903e-01
    z[9,5,5]  R1742     -1.9466885924339294e-01
    z[9,5,5]  R1743     -9.0171068906784058e-02
    z[9,5,5]  R1744     2.6869205757975578e-02
    z[9,5,5]  R1745     2.1448722109198570e-02
    z[9,5,5]  R1746     -5.2375471591949463e-01
    z[9,5,5]  R1747     -5.0364631414413452e-01
    z[9,5,5]  R1748     4.7354102134704590e-01
    z[9,5,5]  R1749     6.2358152866363525e-01
    z[9,5,5]  R1750     -1.8069872260093689e-01
    z[9,5,5]  R1751     4.4689774513244629e-01
    z[9,5,5]  R1752     1.8895292282104492e-01
    z[9,5,5]  R1753     -2.3948937654495239e-01
    z[9,5,5]  R1754     4.0278565883636475e-01
    z[9,5,5]  R1755     3.9408656954765320e-01
    z[9,5,5]  R1756     3.2812082767486572e-01
    z[9,5,5]  R1757     -3.1141281127929688e-01
    z[9,5,5]  R1758     -1.1388673633337021e-01
    z[9,5,5]  R1759     -1.6845078766345978e-01
    z[9,5,5]  R1760     -1.9640058279037476e-01
    z[9,5,5]  R1761     -5.7908177375793457e-01
    z[9,5,5]  R1762     4.5114055275917053e-01
    z[9,5,5]  R1763     -2.2129443287849426e-01
    z[9,5,5]  R1764     3.0819091200828552e-01
    z[9,5,5]  R1765     2.7421155571937561e-01
    z[9,5,5]  R1766     1.5060122311115265e-01
    z[9,5,5]  R1767     1.3864484429359436e-01
    z[9,5,6]  R53       1
    z[9,5,6]  R89       -1
    z[9,5,6]  R1711     -1
    z[9,5,6]  R1712     1
    z[9,5,6]  R1713     2.0228348672389984e-01
    z[9,5,6]  R1714     -2.4512818455696106e-01
    z[9,5,6]  R1715     4.9123266339302063e-01
    z[9,5,6]  R1716     0.458877295255661
    z[9,5,6]  R1717     -1.7089027166366577e-01
    z[9,5,6]  R1718     -1.6945970058441162e-01
    z[9,5,6]  R1719     -0.314144492149353
    z[9,5,6]  R1720     -5.9782350063323975e-01
    z[9,5,6]  R1721     -2.1775241196155548e-01
    z[9,5,6]  R1722     -1.0965825989842415e-02
    z[9,5,6]  R1723     -9.3064224347472191e-04
    z[9,5,6]  R1724     6.1952179670333862e-01
    z[9,5,6]  R1725     -3.5580569505691528e-01
    z[9,5,6]  R1726     -9.8149202764034271e-02
    z[9,5,6]  R1727     2.0360575616359711e-01
    z[9,5,6]  R1728     -0.434345006942749
    z[9,5,6]  R1729     4.9282174557447433e-02
    z[9,5,6]  R1730     -3.9629215002059937e-01
    z[9,5,6]  R1731     -0.447204053401947
    z[9,5,6]  R1732     -5.8996759355068207e-02
    z[9,5,6]  R1733     2.6214540004730225e-01
    z[9,5,6]  R1734     -3.8011962175369263e-01
    z[9,5,6]  R1735     -2.8304505348205566e-01
    z[9,5,6]  R1736     -1.5371902287006378e-01
    z[9,5,6]  R1737     2.5114363431930542e-01
    z[9,5,6]  R1738     1.9051089882850647e-01
    z[9,5,6]  R1739     -0.38516765832901
    z[9,5,6]  R1740     1.3256359100341797e-01
    z[9,5,6]  R1741     -1.2602607905864716e-01
    z[9,5,6]  R1742     1.7144057154655457e-01
    z[9,5,6]  R1743     0.315448522567749
    z[9,5,6]  R1744     -9.9200025200843811e-02
    z[9,5,6]  R1745     1.7386473715305328e-01
    z[9,5,6]  R1746     -1.4328743517398834e-01
    z[9,5,6]  R1747     -7.7792368829250336e-02
    z[9,5,6]  R1748     -3.7168782949447632e-01
    z[9,5,6]  R1749     -3.5316473245620728e-01
    z[9,5,6]  R1750     -4.5230352878570557e-01
    z[9,5,6]  R1751     2.2273132205009460e-01
    z[9,5,6]  R1752     -2.3438625037670135e-01
    z[9,5,6]  R1753     3.4495303034782410e-01
    z[9,5,6]  R1754     3.2797396183013916e-01
    z[9,5,6]  R1755     4.9378228187561035e-01
    z[9,5,6]  R1756     4.6263146400451660e-01
    z[9,5,6]  R1757     2.4267353117465973e-01
    z[9,5,6]  R1758     -1.3771170750260353e-02
    z[9,5,6]  R1759     3.6265552043914795e-01
    z[9,5,6]  R1760     4.4650569558143616e-01
    z[9,5,6]  R1761     -2.8255870565772057e-02
    z[9,5,6]  R1762     2.0609153807163239e-01
    z[9,5,6]  R1763     0.0699809193611145
    z[9,5,6]  R1764     1.3407501578330994e-01
    z[9,5,6]  R1765     1.0127907991409302e-01
    z[9,5,6]  R1766     3.5682967305183411e-01
    z[9,5,6]  R1767     -3.8814684748649597e-01
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R1812     -1
    z[6,7,0]  R1813     1
    z[6,7,0]  R1826     5.2997888997197151e-03
    z[6,7,0]  R1827     4.1948729753494263e-01
    z[6,7,0]  R1828     1.0437027364969254e-01
    z[6,7,0]  R1829     1.0525260120630264e-01
    z[6,7,0]  R1830     1.1023332178592682e-01
    z[6,7,0]  R1831     2.2316236793994904e-01
    z[6,7,0]  R1832     2.7278235554695129e-01
    z[6,7,0]  R1833     1.1781064420938492e-01
    z[6,7,0]  R1834     1.9081214070320129e-01
    z[6,7,0]  R1835     -7.6717101037502289e-02
    z[6,7,0]  R1836     -4.5044949650764465e-01
    z[6,7,0]  R1837     -5.4107826948165894e-01
    z[6,7,0]  R1838     -5.1500570774078369e-01
    z[6,7,0]  R1839     -3.2864689826965332e-01
    z[6,7,0]  R1840     -2.6566559076309204e-01
    z[6,7,0]  R1841     -4.6390482783317566e-01
    z[6,7,0]  R1842     -3.1404739618301392e-01
    z[6,7,0]  R1843     -4.4573992490768433e-01
    z[6,7,0]  R1844     -7.2129136323928833e-01
    z[6,7,0]  R1845     -3.1751331686973572e-01
    z[6,7,0]  R1846     -4.2320832610130310e-01
    z[6,7,0]  R1847     3.3356276154518127e-01
    z[6,7,0]  R1848     0.257706880569458
    z[6,7,0]  R1849     3.8330194354057312e-01
    z[6,7,0]  R1850     2.6250192523002625e-01
    z[6,7,0]  R1851     1.6237622499465942e-01
    z[6,7,0]  R1852     1.7827369272708893e-01
    z[6,7,0]  R1853     2.0058463513851166e-01
    z[6,7,0]  R1854     3.5954967141151428e-01
    z[6,7,0]  R1855     2.3779372870922089e-01
    z[6,7,0]  R1856     5.6475032120943069e-02
    z[6,7,0]  R1857     -1.8334245681762695e-01
    z[6,7,0]  R1858     1.4990578591823578e-01
    z[6,7,0]  R1859     -9.8930656909942627e-02
    z[6,7,0]  R1860     -3.7739716470241547e-02
    z[6,7,0]  R1861     -4.2912218719720840e-02
    z[6,7,0]  R1862     -5.2289735525846481e-02
    z[6,7,0]  R1863     3.5226665437221527e-02
    z[6,7,0]  R1864     0.0677286833524704
    z[6,7,0]  R1865     1.6244037076830864e-02
    z[6,7,0]  R1866     -4.1742384433746338e-01
    z[6,7,0]  R1867     -2.5374817848205566e-01
    z[6,7,0]  R1868     2.9268631339073181e-01
    z[6,7,0]  R1869     -2.8985580801963806e-01
    z[6,7,0]  R1870     -2.7387583255767822e-01
    z[6,7,0]  R1871     -9.6661873161792755e-02
    z[6,7,0]  R1872     -8.0902941524982452e-02
    z[6,7,0]  R1873     1.9217935204505920e-01
    z[6,7,0]  R1874     -2.7157601714134216e-01
    z[6,7,0]  R1875     -3.7019826471805573e-02
    z[6,7,0]  R1876     -5.1463431119918823e-01
    z[6,7,0]  R1877     -7.5788277387619019e-01
    z[6,7,0]  R1878     -6.9060385227203369e-01
    z[6,7,0]  R1879     -2.5572237372398376e-01
    z[6,7,0]  R1880     0.598052442073822
    z[6,7,0]  R1881     -6.2403172254562378e-01
    z[6,7,0]  R1882     -5.9778302907943726e-01
    z[6,7,0]  R1883     -3.7376496195793152e-01
    z[6,7,0]  R1884     -6.5007936954498291e-01
    z[6,7,0]  R1885     -0.4415283203125
    z[6,7,0]  R1886     4.9268159270286560e-01
    z[6,7,0]  R1887     3.1667700409889221e-01
    z[6,7,0]  R1888     7.0376896858215332e-01
    z[6,7,0]  R1889     1.9855907559394836e-01
    z[6,7,0]  R1890     5.9077608585357666e-01
    z[6,7,0]  R1891     6.7369127273559570e-01
    z[6,7,0]  R1892     4.7348472476005554e-01
    z[6,7,0]  R1893     4.4909808039665222e-01
    z[6,7,0]  R1894     3.1746962666511536e-01
    z[6,7,0]  R1895     5.1115787029266357e-01
    z[6,7,0]  R1896     -4.1719296574592590e-01
    z[6,7,0]  R1897     0.542195200920105
    z[6,7,0]  R1898     6.3908779621124268e-01
    z[6,7,0]  R1899     5.2245211601257324e-01
    z[6,7,0]  R1900     7.3084539175033569e-01
    z[6,7,0]  R1901     2.4125267565250397e-01
    z[6,7,0]  R1902     5.0219660997390747e-01
    z[6,7,0]  R1903     1.3187961280345917e-01
    z[6,7,0]  R1904     -1.3883483409881592e-01
    z[6,7,0]  R1905     2.9321116209030151e-01
    z[6,7,0]  R1906     -2.5262609124183655e-01
    z[6,7,0]  R1907     -8.2698212936520576e-03
    z[6,7,0]  R1908     6.6153752803802490e-01
    z[6,7,0]  R1909     6.0601574182510376e-01
    z[6,7,0]  R1910     5.0554829835891724e-01
    z[6,7,0]  R1911     2.1321113407611847e-01
    z[6,7,0]  R1912     1.7096064984798431e-01
    z[6,7,0]  R1913     3.4136199951171875e-01
    z[6,7,0]  R1914     6.2890779972076416e-01
    z[6,7,0]  R1915     0.561506986618042
    z[6,7,0]  R1916     2.7783498167991638e-01
    z[6,7,0]  R1917     3.9151710271835327e-01
    z[6,7,0]  R1918     4.8872488737106323e-01
    z[6,7,0]  R1919     5.9827280044555664e-01
    z[6,7,0]  R1920     5.3189265727996826e-01
    z[6,7,0]  R1921     -8.0244131386280060e-02
    z[6,7,0]  R1922     6.1898368597030640e-01
    z[6,7,0]  R1923     -1.2636521458625793e-01
    z[6,7,0]  R1924     4.7545289993286133e-01
    z[6,7,0]  R1925     -1.8992806971073151e-01
    z[6,7,0]  R1926     -4.4662123918533325e-01
    z[6,7,0]  R1927     7.5933212041854858e-01
    z[6,7,0]  R1928     1.4641419053077698e-01
    z[6,7,0]  R1929     9.0601153671741486e-02
    z[6,7,0]  R1930     1.4350548386573792e-01
    z[6,7,0]  R1931     4.1983413696289062e-01
    z[6,7,0]  R1932     4.4088366627693176e-01
    z[6,7,0]  R1933     -5.1574579629232176e-07
    z[6,7,0]  R1934     3.0272185802459717e-01
    z[6,7,0]  R1935     2.3438142240047455e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R1814     -1
    z[6,7,1]  R1815     1
    z[6,7,1]  R1826     -7.3530954122543335e-01
    z[6,7,1]  R1827     -4.9588376283645630e-01
    z[6,7,1]  R1828     -5.7717734575271606e-01
    z[6,7,1]  R1829     -0.414680153131485
    z[6,7,1]  R1830     -7.2164130210876465e-01
    z[6,7,1]  R1831     -5.0093287229537964e-01
    z[6,7,1]  R1832     -4.1679385304450989e-01
    z[6,7,1]  R1833     -6.5210425853729248e-01
    z[6,7,1]  R1834     -5.0346869230270386e-01
    z[6,7,1]  R1835     -4.0078547596931458e-01
    z[6,7,1]  R1836     6.4957511425018311e-01
    z[6,7,1]  R1837     6.9872868061065674e-01
    z[6,7,1]  R1838     7.6962876319885254e-01
    z[6,7,1]  R1839     6.7264169454574585e-01
    z[6,7,1]  R1840     8.2818859815597534e-01
    z[6,7,1]  R1841     0.672106921672821
    z[6,7,1]  R1842     6.5434855222702026e-01
    z[6,7,1]  R1843     5.9246122837066650e-01
    z[6,7,1]  R1844     4.7276049852371216e-01
    z[6,7,1]  R1845     7.1293371915817261e-01
    z[6,7,1]  R1846     -4.0303513407707214e-01
    z[6,7,1]  R1847     9.0070790052413940e-01
    z[6,7,1]  R1848     9.1339069604873657e-01
    z[6,7,1]  R1849     7.8830051422119141e-01
    z[6,7,1]  R1850     8.8143730163574219e-01
    z[6,7,1]  R1851     8.4697675704956055e-01
    z[6,7,1]  R1852     8.5751402378082275e-01
    z[6,7,1]  R1853     8.3328926563262939e-01
    z[6,7,1]  R1854     8.0506402254104614e-01
    z[6,7,1]  R1855     8.1652712821960449e-01
    z[6,7,1]  R1856     9.0135276317596436e-01
    z[6,7,1]  R1857     7.3534977436065674e-01
    z[6,7,1]  R1858     8.2764226198196411e-01
    z[6,7,1]  R1859     8.6859047412872314e-01
    z[6,7,1]  R1860     9.2246288061141968e-01
    z[6,7,1]  R1861     8.4907406568527222e-01
    z[6,7,1]  R1862     8.6507821083068848e-01
    z[6,7,1]  R1863     7.8361368179321289e-01
    z[6,7,1]  R1864     7.2851365804672241e-01
    z[6,7,1]  R1865     7.8142297267913818e-01
    z[6,7,1]  R1866     -7.0349895954132080e-01
    z[6,7,1]  R1867     -7.6073330640792847e-01
    z[6,7,1]  R1868     -5.8580768108367920e-01
    z[6,7,1]  R1869     -0.550881564617157
    z[6,7,1]  R1870     -4.3758830428123474e-01
    z[6,7,1]  R1871     -5.0719237327575684e-01
    z[6,7,1]  R1872     -0.727531909942627
    z[6,7,1]  R1873     -6.8581086397171021e-01
    z[6,7,1]  R1874     -5.8624863624572754e-01
    z[6,7,1]  R1875     -5.6832879781723022e-01
    z[6,7,1]  R1876     8.1121939420700073e-01
    z[6,7,1]  R1877     5.9868144989013672e-01
    z[6,7,1]  R1878     0.481892466545105
    z[6,7,1]  R1879     8.4463369846343994e-01
    z[6,7,1]  R1880     5.9536057710647583e-01
    z[6,7,1]  R1881     6.6302919387817383e-01
    z[6,7,1]  R1882     0.513116717338562
    z[6,7,1]  R1883     8.2301336526870728e-01
    z[6,7,1]  R1884     5.3453516960144043e-01
    z[6,7,1]  R1885     7.6250523328781128e-01
    z[6,7,1]  R1886     6.1349582672119141e-01
    z[6,7,1]  R1887     3.7861829996109009e-01
    z[6,7,1]  R1888     2.5431987643241882e-01
    z[6,7,1]  R1889     0.417542427778244
    z[6,7,1]  R1890     1.4204722642898560e-01
    z[6,7,1]  R1891     3.9823630452156067e-01
    z[6,7,1]  R1892     0.381229043006897
    z[6,7,1]  R1893     3.3481189608573914e-01
    z[6,7,1]  R1894     3.3361795544624329e-01
    z[6,7,1]  R1895     3.3566546440124512e-01
    z[6,7,1]  R1896     5.5710178613662720e-01
    z[6,7,1]  R1897     4.2706665396690369e-01
    z[6,7,1]  R1898     2.6934564113616943e-01
    z[6,7,1]  R1899     2.0655032992362976e-01
    z[6,7,1]  R1900     0.293347030878067
    z[6,7,1]  R1901     5.4523384571075439e-01
    z[6,7,1]  R1902     0.469305157661438
    z[6,7,1]  R1903     2.6761990785598755e-01
    z[6,7,1]  R1904     2.3617841303348541e-01
    z[6,7,1]  R1905     6.4018809795379639e-01
    z[6,7,1]  R1906     6.9004052877426147e-01
    z[6,7,1]  R1907     4.9356538057327271e-01
    z[6,7,1]  R1908     3.3252444863319397e-01
    z[6,7,1]  R1909     3.8503104448318481e-01
    z[6,7,1]  R1910     6.2245595455169678e-01
    z[6,7,1]  R1911     6.7525357007980347e-02
    z[6,7,1]  R1912     3.8494072854518890e-02
    z[6,7,1]  R1913     6.1756855249404907e-01
    z[6,7,1]  R1914     3.2897058129310608e-01
    z[6,7,1]  R1915     3.0310752987861633e-01
    z[6,7,1]  R1916     0.330127477645874
    z[6,7,1]  R1917     2.0856209099292755e-01
    z[6,7,1]  R1918     7.3431402444839478e-01
    z[6,7,1]  R1919     2.1689492464065552e-01
    z[6,7,1]  R1920     0.392946720123291
    z[6,7,1]  R1921     3.2396170496940613e-01
    z[6,7,1]  R1922     3.3498492836952209e-01
    z[6,7,1]  R1923     -0.0694834440946579
    z[6,7,1]  R1924     3.7733837962150574e-01
    z[6,7,1]  R1925     2.0810633897781372e-02
    z[6,7,1]  R1926     6.7973607778549194e-01
    z[6,7,1]  R1927     2.9732012748718262e-01
    z[6,7,1]  R1928     3.7649261951446533e-01
    z[6,7,1]  R1929     3.6698821187019348e-01
    z[6,7,1]  R1930     5.4701352491974831e-03
    z[6,7,1]  R1931     4.3893152475357056e-01
    z[6,7,1]  R1932     0.687838613986969
    z[6,7,1]  R1933     3.1641638278961182e-01
    z[6,7,1]  R1934     -0.440679132938385
    z[6,7,1]  R1935     -4.1323426365852356e-01
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R1816     -1
    z[6,7,2]  R1817     1
    z[6,7,2]  R1826     -5.4525830782949924e-03
    z[6,7,2]  R1827     -2.1860765293240547e-02
    z[6,7,2]  R1828     3.9826986193656921e-01
    z[6,7,2]  R1829     7.2109901905059814e-01
    z[6,7,2]  R1830     2.4163636565208435e-01
    z[6,7,2]  R1831     -1.7734654247760773e-01
    z[6,7,2]  R1832     1.7134083807468414e-01
    z[6,7,2]  R1833     -4.6825617551803589e-02
    z[6,7,2]  R1834     1.2852217257022858e-01
    z[6,7,2]  R1835     1.9431334733963013e-01
    z[6,7,2]  R1836     -4.2230904102325439e-01
    z[6,7,2]  R1837     -2.5339594483375549e-01
    z[6,7,2]  R1838     -3.4795930981636047e-01
    z[6,7,2]  R1839     -6.3886839151382446e-01
    z[6,7,2]  R1840     -1.8048506975173950e-01
    z[6,7,2]  R1841     -0.401504784822464
    z[6,7,2]  R1842     -2.5141322612762451e-01
    z[6,7,2]  R1843     -4.0240389108657837e-01
    z[6,7,2]  R1844     -4.6404087543487549e-01
    z[6,7,2]  R1845     -2.8564265370368958e-01
    z[6,7,2]  R1846     -0.062485221773386
    z[6,7,2]  R1847     1.3245701789855957e-01
    z[6,7,2]  R1848     1.8474271893501282e-01
    z[6,7,2]  R1849     3.9558848738670349e-01
    z[6,7,2]  R1850     -2.3664797842502594e-01
    z[6,7,2]  R1851     1.3192997872829437e-01
    z[6,7,2]  R1852     -3.4804251790046692e-01
    z[6,7,2]  R1853     1.7199221253395081e-01
    z[6,7,2]  R1854     3.8362555205821991e-02
    z[6,7,2]  R1855     1.2735572457313538e-01
    z[6,7,2]  R1856     -1.3399665057659149e-01
    z[6,7,2]  R1857     -3.9168280363082886e-01
    z[6,7,2]  R1858     -4.4084903597831726e-01
    z[6,7,2]  R1859     -8.7382178753614426e-03
    z[6,7,2]  R1860     -1.4443391561508179e-01
    z[6,7,2]  R1861     -0.0871066004037857
    z[6,7,2]  R1862     -7.0164717733860016e-02
    z[6,7,2]  R1863     2.2188569605350494e-01
    z[6,7,2]  R1864     -4.7210793942213058e-02
    z[6,7,2]  R1865     0.072322316467762
    z[6,7,2]  R1866     -3.7101060152053833e-02
    z[6,7,2]  R1867     3.2610440254211426e-01
    z[6,7,2]  R1868     4.3813946843147278e-01
    z[6,7,2]  R1869     4.1852509975433350e-01
    z[6,7,2]  R1870     2.9723653197288513e-01
    z[6,7,2]  R1871     3.8061714172363281e-01
    z[6,7,2]  R1872     2.5127744302153587e-02
    z[6,7,2]  R1873     -1.0600391030311584e-01
    z[6,7,2]  R1874     -1.6638176143169403e-01
    z[6,7,2]  R1875     -5.9659677743911743e-01
    z[6,7,2]  R1876     1.8641431629657745e-01
    z[6,7,2]  R1877     -2.8258139267563820e-02
    z[6,7,2]  R1878     4.6208903193473816e-01
    z[6,7,2]  R1879     3.3079397678375244e-01
    z[6,7,2]  R1880     -4.5337709784507751e-01
    z[6,7,2]  R1881     -3.7219825387001038e-01
    z[6,7,2]  R1882     2.0643375813961029e-01
    z[6,7,2]  R1883     -2.2771295905113220e-01
    z[6,7,2]  R1884     1.4864406548440456e-02
    z[6,7,2]  R1885     -3.4367975592613220e-01
    z[6,7,2]  R1886     1.2198777496814728e-01
    z[6,7,2]  R1887     -1.7813597619533539e-01
    z[6,7,2]  R1888     1.8026264011859894e-01
    z[6,7,2]  R1889     -5.3825759887695312e-01
    z[6,7,2]  R1890     -1.8358139693737030e-01
    z[6,7,2]  R1891     1.8783777952194214e-01
    z[6,7,2]  R1892     1.0380639135837555e-01
    z[6,7,2]  R1893     8.4439389407634735e-02
    z[6,7,2]  R1894     -1.6782304644584656e-01
    z[6,7,2]  R1895     -8.1393130123615265e-02
    z[6,7,2]  R1896     1.0979621671140194e-02
    z[6,7,2]  R1897     -1.5255357325077057e-01
    z[6,7,2]  R1898     -1.8891420960426331e-01
    z[6,7,2]  R1899     -2.2009547054767609e-01
    z[6,7,2]  R1900     -2.3043116554617882e-02
    z[6,7,2]  R1901     -4.8352709412574768e-01
    z[6,7,2]  R1902     2.6932433247566223e-01
    z[6,7,2]  R1903     -8.2781696319580078e-01
    z[6,7,2]  R1904     -4.9663653969764709e-01
    z[6,7,2]  R1905     2.2295682132244110e-01
    z[6,7,2]  R1906     -4.5636307448148727e-02
    z[6,7,2]  R1907     -5.5839467048645020e-01
    z[6,7,2]  R1908     -8.6928181350231171e-02
    z[6,7,2]  R1909     -4.7206360846757889e-02
    z[6,7,2]  R1910     2.7449253201484680e-01
    z[6,7,2]  R1911     -7.0911628007888794e-01
    z[6,7,2]  R1912     -8.0570483207702637e-01
    z[6,7,2]  R1913     -4.4521424919366837e-02
    z[6,7,2]  R1914     2.3619423806667328e-01
    z[6,7,2]  R1915     -5.7745543308556080e-03
    z[6,7,2]  R1916     -7.3673325777053833e-01
    z[6,7,2]  R1917     -5.7246792316436768e-01
    z[6,7,2]  R1918     1.7531728744506836e-01
    z[6,7,2]  R1919     -3.1774231791496277e-01
    z[6,7,2]  R1920     -1.6345228999853134e-02
    z[6,7,2]  R1921     -5.2697920799255371e-01
    z[6,7,2]  R1922     3.7351274490356445e-01
    z[6,7,2]  R1923     2.5668165180832148e-03
    z[6,7,2]  R1924     -4.7355074435472488e-02
    z[6,7,2]  R1925     2.9300722479820251e-01
    z[6,7,2]  R1926     1.2888029217720032e-01
    z[6,7,2]  R1927     -1.2716868519783020e-01
    z[6,7,2]  R1928     -3.5650515556335449e-01
    z[6,7,2]  R1929     -0.820137083530426
    z[6,7,2]  R1930     -7.3708117008209229e-01
    z[6,7,2]  R1931     -1.4826372265815735e-01
    z[6,7,2]  R1932     2.5509911775588989e-01
    z[6,7,2]  R1933     -5.1989001035690308e-01
    z[6,7,2]  R1934     -3.2574686408042908e-01
    z[6,7,2]  R1935     -1.7981612682342529e-01
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R1818     -1
    z[6,7,3]  R1819     1
    z[6,7,3]  R1826     -7.8702464699745178e-02
    z[6,7,3]  R1827     -5.4290610551834106e-01
    z[6,7,3]  R1828     -1.7345812916755676e-01
    z[6,7,3]  R1829     -2.7939155697822571e-01
    z[6,7,3]  R1830     -4.9790588021278381e-01
    z[6,7,3]  R1831     -4.0655446052551270e-01
    z[6,7,3]  R1832     -4.7898799180984497e-01
    z[6,7,3]  R1833     -3.0154135823249817e-01
    z[6,7,3]  R1834     -3.7619385123252869e-01
    z[6,7,3]  R1835     -0.323411226272583
    z[6,7,3]  R1836     3.9414972066879272e-01
    z[6,7,3]  R1837     2.9318007826805115e-01
    z[6,7,3]  R1838     1.6355967149138451e-02
    z[6,7,3]  R1839     -4.4523615390062332e-02
    z[6,7,3]  R1840     2.1793028712272644e-01
    z[6,7,3]  R1841     -2.7577212080359459e-02
    z[6,7,3]  R1842     2.9820641875267029e-01
    z[6,7,3]  R1843     4.6124079823493958e-01
    z[6,7,3]  R1844     3.5927388817071915e-02
    z[6,7,3]  R1845     5.1341433078050613e-02
    z[6,7,3]  R1846     7.0136207342147827e-01
    z[6,7,3]  R1847     -9.1290250420570374e-02
    z[6,7,3]  R1848     -1.4799717068672180e-01
    z[6,7,3]  R1849     -1.5839058160781860e-01
    z[6,7,3]  R1850     -1.9270788133144379e-01
    z[6,7,3]  R1851     2.3124691843986511e-01
    z[6,7,3]  R1852     -4.1036497801542282e-02
    z[6,7,3]  R1853     2.1468129009008408e-02
    z[6,7,3]  R1854     -2.4786441028118134e-01
    z[6,7,3]  R1855     8.2508064806461334e-02
    z[6,7,3]  R1856     3.2507243752479553e-01
    z[6,7,3]  R1857     4.1435372829437256e-01
    z[6,7,3]  R1858     9.4971351325511932e-02
    z[6,7,3]  R1859     3.5890835523605347e-01
    z[6,7,3]  R1860     2.7370864152908325e-01
    z[6,7,3]  R1861     1.5111638605594635e-01
    z[6,7,3]  R1862     3.9690554141998291e-01
    z[6,7,3]  R1863     1.9343625009059906e-01
    z[6,7,3]  R1864     -1.6232079267501831e-01
    z[6,7,3]  R1865     1.5407501161098480e-01
    z[6,7,3]  R1866     -2.1796271204948425e-01
    z[6,7,3]  R1867     -3.2439276576042175e-01
    z[6,7,3]  R1868     -5.6626987457275391e-01
    z[6,7,3]  R1869     -0.48638716340065
    z[6,7,3]  R1870     -4.4167909026145935e-01
    z[6,7,3]  R1871     -2.3436361551284790e-01
    z[6,7,3]  R1872     -2.6952078938484192e-01
    z[6,7,3]  R1873     -3.3212468028068542e-01
    z[6,7,3]  R1874     -2.0623359084129333e-01
    z[6,7,3]  R1875     -4.9054530262947083e-01
    z[6,7,3]  R1876     -1.3675317168235779e-01
    z[6,7,3]  R1877     1.4900295436382294e-01
    z[6,7,3]  R1878     -6.4627096056938171e-02
    z[6,7,3]  R1879     1.0589123517274857e-01
    z[6,7,3]  R1880     -6.5986894071102142e-02
    z[6,7,3]  R1881     6.7552458494901657e-03
    z[6,7,3]  R1882     4.8386582732200623e-01
    z[6,7,3]  R1883     2.5144720077514648e-01
    z[6,7,3]  R1884     3.4883657097816467e-01
    z[6,7,3]  R1885     -9.3822255730628967e-02
    z[6,7,3]  R1886     1.0117420926690102e-02
    z[6,7,3]  R1887     4.2367298156023026e-02
    z[6,7,3]  R1888     5.7666087150573730e-01
    z[6,7,3]  R1889     -3.8918060064315796e-01
    z[6,7,3]  R1890     -1.8717030063271523e-02
    z[6,7,3]  R1891     -2.6123163104057312e-01
    z[6,7,3]  R1892     3.8880711793899536e-01
    z[6,7,3]  R1893     1.2805530428886414e-01
    z[6,7,3]  R1894     -2.7015671133995056e-01
    z[6,7,3]  R1895     4.7361102700233459e-01
    z[6,7,3]  R1896     3.4452080726623535e-01
    z[6,7,3]  R1897     0.437370240688324
    z[6,7,3]  R1898     -2.0321829617023468e-01
    z[6,7,3]  R1899     3.1056657433509827e-01
    z[6,7,3]  R1900     -6.8546503782272339e-02
    z[6,7,3]  R1901     1.1138024926185608e-01
    z[6,7,3]  R1902     0.0956350564956665
    z[6,7,3]  R1903     -3.4429600834846497e-01
    z[6,7,3]  R1904     -3.4128466248512268e-01
    z[6,7,3]  R1905     3.4088918566703796e-01
    z[6,7,3]  R1906     1.0349992662668228e-01
    z[6,7,3]  R1907     -2.3556242883205414e-01
    z[6,7,3]  R1908     4.5910966396331787e-01
    z[6,7,3]  R1909     2.2986364364624023e-01
    z[6,7,3]  R1910     4.1589993238449097e-01
    z[6,7,3]  R1911     -3.8168314844369888e-02
    z[6,7,3]  R1912     1.6509534791111946e-02
    z[6,7,3]  R1913     -5.8023923635482788e-01
    z[6,7,3]  R1914     4.0125700831413269e-01
    z[6,7,3]  R1915     5.0967288017272949e-01
    z[6,7,3]  R1916     -1.3190989196300507e-01
    z[6,7,3]  R1917     -2.7765738964080811e-01
    z[6,7,3]  R1918     2.5022971630096436e-01
    z[6,7,3]  R1919     1.6130031645298004e-01
    z[6,7,3]  R1920     1.4988344162702560e-02
    z[6,7,3]  R1921     -2.6825568079948425e-01
    z[6,7,3]  R1922     3.1657463312149048e-01
    z[6,7,3]  R1923     8.1094855070114136e-01
    z[6,7,3]  R1924     -0.509924590587616
    z[6,7,3]  R1925     7.0410865545272827e-01
    z[6,7,3]  R1926     5.1008999347686768e-01
    z[6,7,3]  R1927     9.8537676036357880e-02
    z[6,7,3]  R1928     -5.3781199455261230e-01
    z[6,7,3]  R1929     -2.5534653663635254e-01
    z[6,7,3]  R1930     -4.7703534364700317e-01
    z[6,7,3]  R1931     -3.2695853710174561e-01
    z[6,7,3]  R1932     -0.295698344707489
    z[6,7,3]  R1933     -7.7478241920471191e-01
    z[6,7,3]  R1934     6.7410397529602051e-01
    z[6,7,3]  R1935     0.667834460735321
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R1820     -1
    z[6,7,4]  R1821     1
    z[6,7,4]  R1826     -6.5583787858486176e-02
    z[6,7,4]  R1827     -0.0800815224647522
    z[6,7,4]  R1828     -6.0458654165267944e-01
    z[6,7,4]  R1829     -1.7526540160179138e-01
    z[6,7,4]  R1830     1.7153823375701904e-01
    z[6,7,4]  R1831     -5.8877730369567871e-01
    z[6,7,4]  R1832     -0.381697416305542
    z[6,7,4]  R1833     2.6414009928703308e-01
    z[6,7,4]  R1834     -6.7557895183563232e-01
    z[6,7,4]  R1835     -8.0988389253616333e-01
    z[6,7,4]  R1836     3.0215349048376083e-02
    z[6,7,4]  R1837     -1.1738082021474838e-01
    z[6,7,4]  R1838     1.1353948712348938e-01
    z[6,7,4]  R1839     -4.5189879834651947e-02
    z[6,7,4]  R1840     1.2621504068374634e-01
    z[6,7,4]  R1841     -2.8321878984570503e-02
    z[6,7,4]  R1842     2.0029008388519287e-01
    z[6,7,4]  R1843     1.5489107370376587e-01
    z[6,7,4]  R1844     -1.4238531701266766e-02
    z[6,7,4]  R1845     1.7537397146224976e-01
    z[6,7,4]  R1846     -7.3311820626258850e-02
    z[6,7,4]  R1847     8.1896416842937469e-02
    z[6,7,4]  R1848     -1.5243300795555115e-01
    z[6,7,4]  R1849     4.0392596274614334e-02
    z[6,7,4]  R1850     -2.4234730750322342e-02
    z[6,7,4]  R1851     -2.0024940371513367e-01
    z[6,7,4]  R1852     5.5311162024736404e-02
    z[6,7,4]  R1853     -3.4424898028373718e-01
    z[6,7,4]  R1854     6.6722683608531952e-02
    z[6,7,4]  R1855     -2.4594143033027649e-02
    z[6,7,4]  R1856     1.2444531172513962e-01
    z[6,7,4]  R1857     0.046059750020504
    z[6,7,4]  R1858     1.2458857148885727e-01
    z[6,7,4]  R1859     -2.6181265711784363e-01
    z[6,7,4]  R1860     -1.2470588833093643e-01
    z[6,7,4]  R1861     -2.0413656532764435e-01
    z[6,7,4]  R1862     -1.0960114002227783e-01
    z[6,7,4]  R1863     1.5741668641567230e-01
    z[6,7,4]  R1864     8.2987584173679352e-02
    z[6,7,4]  R1865     1.7803196609020233e-01
    z[6,7,4]  R1866     -3.4477835893630981e-01
    z[6,7,4]  R1867     -9.4077989459037781e-02
    z[6,7,4]  R1868     1.8941025435924530e-01
    z[6,7,4]  R1869     1.7641784250736237e-01
    z[6,7,4]  R1870     6.8979769945144653e-02
    z[6,7,4]  R1871     -3.9085236191749573e-01
    z[6,7,4]  R1872     5.9848743677139282e-01
    z[6,7,4]  R1873     1.4117564260959625e-01
    z[6,7,4]  R1874     5.1248639822006226e-01
    z[6,7,4]  R1875     1.1978673934936523e-01
    z[6,7,4]  R1876     0.097610242664814
    z[6,7,4]  R1877     -1.5691386163234711e-01
    z[6,7,4]  R1878     -1.3203912973403931e-01
    z[6,7,4]  R1879     8.7045609951019287e-02
    z[6,7,4]  R1880     2.8269633185118437e-03
    z[6,7,4]  R1881     -7.5232565402984619e-02
    z[6,7,4]  R1882     3.9024170488119125e-02
    z[6,7,4]  R1883     -5.6769125163555145e-02
    z[6,7,4]  R1884     -1.8793129920959473e-01
    z[6,7,4]  R1885     1.0737630724906921e-01
    z[6,7,4]  R1886     3.2515057921409607e-01
    z[6,7,4]  R1887     -5.4684060811996460e-01
    z[6,7,4]  R1888     -1.5085913240909576e-01
    z[6,7,4]  R1889     1.4507076144218445e-01
    z[6,7,4]  R1890     6.4669072628021240e-02
    z[6,7,4]  R1891     1.7920480668544769e-01
    z[6,7,4]  R1892     -2.2350139915943146e-01
    z[6,7,4]  R1893     4.9102181196212769e-01
    z[6,7,4]  R1894     4.8082631826400757e-01
    z[6,7,4]  R1895     3.9034748077392578e-01
    z[6,7,4]  R1896     -3.8204270601272583e-01
    z[6,7,4]  R1897     -6.4795307815074921e-02
    z[6,7,4]  R1898     3.1710690259933472e-01
    z[6,7,4]  R1899     -1.7232243716716766e-01
    z[6,7,4]  R1900     1.1811833083629608e-01
    z[6,7,4]  R1901     -2.2556933760643005e-01
    z[6,7,4]  R1902     -4.4569936394691467e-01
    z[6,7,4]  R1903     2.0808382332324982e-01
    z[6,7,4]  R1904     -5.1360708475112915e-01
    z[6,7,4]  R1905     -5.0404256582260132e-01
    z[6,7,4]  R1906     8.1670030951499939e-02
    z[6,7,4]  R1907     -4.0133169293403625e-01
    z[6,7,4]  R1908     -3.7903463840484619e-01
    z[6,7,4]  R1909     -1.1011761426925659e-01
    z[6,7,4]  R1910     -1.4226512610912323e-01
    z[6,7,4]  R1911     -6.4063584804534912e-01
    z[6,7,4]  R1912     -4.1146388649940491e-01
    z[6,7,4]  R1913     0.206847682595253
    z[6,7,4]  R1914     3.7891995906829834e-01
    z[6,7,4]  R1915     -2.9972764849662781e-01
    z[6,7,4]  R1916     -4.7512295842170715e-01
    z[6,7,4]  R1917     9.5892600715160370e-02
    z[6,7,4]  R1918     -2.8939386829733849e-03
    z[6,7,4]  R1919     -1.4694561064243317e-01
    z[6,7,4]  R1920     -2.4297364056110382e-01
    z[6,7,4]  R1921     -1.5307384543120861e-02
    z[6,7,4]  R1922     4.6376258134841919e-01
    z[6,7,4]  R1923     1.1937827616930008e-01
    z[6,7,4]  R1924     -5.8907294273376465e-01
    z[6,7,4]  R1925     -4.6194321475923061e-03
    z[6,7,4]  R1926     -1.8133457051590085e-03
    z[6,7,4]  R1927     -3.8105627894401550e-01
    z[6,7,4]  R1928     -4.3600201606750488e-03
    z[6,7,4]  R1929     -1.5064917504787445e-01
    z[6,7,4]  R1930     -3.1293755769729614e-01
    z[6,7,4]  R1931     6.3089394569396973e-01
    z[6,7,4]  R1932     1.5609785914421082e-01
    z[6,7,4]  R1933     -0.0791405513882637
    z[6,7,4]  R1934     -2.6542615890502930e-01
    z[6,7,4]  R1935     -3.0111056566238403e-01
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R1822     -1
    z[6,7,5]  R1823     1
    z[6,7,5]  R1826     -6.5855300426483154e-01
    z[6,7,5]  R1827     -0.524657666683197
    z[6,7,5]  R1828     2.6140136644244194e-02
    z[6,7,5]  R1829     -6.4212411642074585e-02
    z[6,7,5]  R1830     3.1182447075843811e-01
    z[6,7,5]  R1831     -1.8741479516029358e-01
    z[6,7,5]  R1832     -1.5266482532024384e-01
    z[6,7,5]  R1833     3.9203429222106934e-01
    z[6,7,5]  R1834     2.8428819775581360e-01
    z[6,7,5]  R1835     -1.8582858145236969e-01
    z[6,7,5]  R1836     8.4322936832904816e-02
    z[6,7,5]  R1837     2.0743592083454132e-01
    z[6,7,5]  R1838     -9.0206608176231384e-02
    z[6,7,5]  R1839     1.6514307260513306e-01
    z[6,7,5]  R1840     2.6645395159721375e-01
    z[6,7,5]  R1841     3.2838270068168640e-01
    z[6,7,5]  R1842     5.2637696266174316e-01
    z[6,7,5]  R1843     -1.9093910232186317e-02
    z[6,7,5]  R1844     1.6806872189044952e-01
    z[6,7,5]  R1845     5.1751202344894409e-01
    z[6,7,5]  R1846     3.1335690617561340e-01
    z[6,7,5]  R1847     -2.0860818028450012e-01
    z[6,7,5]  R1848     -5.0855904817581177e-02
    z[6,7,5]  R1849     -7.0194430649280548e-02
    z[6,7,5]  R1850     -5.6670308113098145e-02
    z[6,7,5]  R1851     -3.5609897971153259e-01
    z[6,7,5]  R1852     -2.5435757637023926e-01
    z[6,7,5]  R1853     -1.9326642155647278e-01
    z[6,7,5]  R1854     8.5207270458340645e-03
    z[6,7,5]  R1855     -4.3164554983377457e-02
    z[6,7,5]  R1856     9.4563901424407959e-02
    z[6,7,5]  R1857     2.2803477942943573e-01
    z[6,7,5]  R1858     -2.3928210139274597e-01
    z[6,7,5]  R1859     1.7281684279441833e-01
    z[6,7,5]  R1860     1.2834899127483368e-01
    z[6,7,5]  R1861     4.2434215545654297e-01
    z[6,7,5]  R1862     -6.4620628952980042e-02
    z[6,7,5]  R1863     0.515661358833313
    z[6,7,5]  R1864     6.4931267499923706e-01
    z[6,7,5]  R1865     3.6160182952880859e-01
    z[6,7,5]  R1866     -1.0249841958284378e-01
    z[6,7,5]  R1867     1.7503528296947479e-01
    z[6,7,5]  R1868     -1.4425632357597351e-01
    z[6,7,5]  R1869     -3.2255119085311890e-01
    z[6,7,5]  R1870     -0.600347638130188
    z[6,7,5]  R1871     -6.0250550508499146e-01
    z[6,7,5]  R1872     0.0891474261879921
    z[6,7,5]  R1873     4.0151673555374146e-01
    z[6,7,5]  R1874     -4.7962307929992676e-01
    z[6,7,5]  R1875     -3.4413054585456848e-02
    z[6,7,5]  R1876     -1.1766847223043442e-01
    z[6,7,5]  R1877     1.3352537155151367e-01
    z[6,7,5]  R1878     2.3594121634960175e-01
    z[6,7,5]  R1879     7.7845461666584015e-02
    z[6,7,5]  R1880     0.0967373251914978
    z[6,7,5]  R1881     -1.3386048376560211e-01
    z[6,7,5]  R1882     -2.6824557781219482e-01
    z[6,7,5]  R1883     3.7103157490491867e-02
    z[6,7,5]  R1884     -3.6585512757301331e-01
    z[6,7,5]  R1885     2.8318911790847778e-01
    z[6,7,5]  R1886     1.2169913202524185e-01
    z[6,7,5]  R1887     -3.9303097128868103e-01
    z[6,7,5]  R1888     -0.0816449224948883
    z[6,7,5]  R1889     -5.6547236442565918e-01
    z[6,7,5]  R1890     -6.6692757606506348e-01
    z[6,7,5]  R1891     -3.4426271915435791e-01
    z[6,7,5]  R1892     3.6641916632652283e-01
    z[6,7,5]  R1893     -5.0223779678344727e-01
    z[6,7,5]  R1894     -6.3555151224136353e-01
    z[6,7,5]  R1895     -2.2146481275558472e-01
    z[6,7,5]  R1896     -5.1602099090814590e-02
    z[6,7,5]  R1897     1.6430897638201714e-02
    z[6,7,5]  R1898     -5.8209329843521118e-01
    z[6,7,5]  R1899     -6.2541455030441284e-01
    z[6,7,5]  R1900     -3.0523651838302612e-01
    z[6,7,5]  R1901     7.9011030495166779e-02
    z[6,7,5]  R1902     4.8354193568229675e-01
    z[6,7,5]  R1903     -1.7072671651840210e-01
    z[6,7,5]  R1904     -8.4060803055763245e-02
    z[6,7,5]  R1905     -2.6964968442916870e-01
    z[6,7,5]  R1906     6.3986754417419434e-01
    z[6,7,5]  R1907     -3.6593699455261230e-01
    z[6,7,5]  R1908     -2.7578333020210266e-01
    z[6,7,5]  R1909     -5.6960654258728027e-01
    z[6,7,5]  R1910     1.9624894857406616e-01
    z[6,7,5]  R1911     -1.2349840998649597e-01
    z[6,7,5]  R1912     -3.6559337377548218e-01
    z[6,7,5]  R1913     -3.2811611890792847e-01
    z[6,7,5]  R1914     -3.3112549781799316e-01
    z[6,7,5]  R1915     4.6616134047508240e-01
    z[6,7,5]  R1916     3.7009748630225658e-03
    z[6,7,5]  R1917     -5.0836455821990967e-01
    z[6,7,5]  R1918     3.3694821596145630e-01
    z[6,7,5]  R1919     -6.3688290119171143e-01
    z[6,7,5]  R1920     -0.508578896522522
    z[6,7,5]  R1921     -7.3330736160278320e-01
    z[6,7,5]  R1922     -1.1799383908510208e-01
    z[6,7,5]  R1923     5.1627850532531738e-01
    z[6,7,5]  R1924     1.7205353826284409e-02
    z[6,7,5]  R1925     6.1767673492431641e-01
    z[6,7,5]  R1926     -2.2750230133533478e-01
    z[6,7,5]  R1927     -3.3121803402900696e-01
    z[6,7,5]  R1928     -6.4543688297271729e-01
    z[6,7,5]  R1929     -7.2935491800308228e-02
    z[6,7,5]  R1930     -8.6584746837615967e-02
    z[6,7,5]  R1931     -1.9172337651252747e-01
    z[6,7,5]  R1932     -3.9301192760467529e-01
    z[6,7,5]  R1933     -6.5661981701850891e-02
    z[6,7,5]  R1934     6.2302328646183014e-02
    z[6,7,5]  R1935     3.0315449833869934e-01
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R1824     -1
    z[6,7,6]  R1825     1
    z[6,7,6]  R1826     -1.2277911603450775e-01
    z[6,7,6]  R1827     -3.5015437752008438e-02
    z[6,7,6]  R1828     -3.1789663434028625e-01
    z[6,7,6]  R1829     -4.2904266715049744e-01
    z[6,7,6]  R1830     1.8472722172737122e-01
    z[6,7,6]  R1831     3.4748157858848572e-01
    z[6,7,6]  R1832     -5.6928563117980957e-01
    z[6,7,6]  R1833     -4.9426713585853577e-01
    z[6,7,6]  R1834     1.2183386087417603e-01
    z[6,7,6]  R1835     -2.6246858760714531e-02
    z[6,7,6]  R1836     0.182825967669487
    z[6,7,6]  R1837     0.10972910374403
    z[6,7,6]  R1838     -8.3172051236033440e-03
    z[6,7,6]  R1839     -0.00973269622772932
    z[6,7,6]  R1840     2.7663874626159668e-01
    z[6,7,6]  R1841     -2.4992136657238007e-01
    z[6,7,6]  R1842     6.2270566821098328e-02
    z[6,7,6]  R1843     -2.2644624114036560e-01
    z[6,7,6]  R1844     -1.0564853996038437e-01
    z[6,7,6]  R1845     9.0046428143978119e-02
    z[6,7,6]  R1846     2.4305772781372070e-01
    z[6,7,6]  R1847     -3.6850892007350922e-02
    z[6,7,6]  R1848     -1.3209588825702667e-01
    z[6,7,6]  R1849     2.0862698554992676e-01
    z[6,7,6]  R1850     2.3921461403369904e-01
    z[6,7,6]  R1851     1.3593156635761261e-01
    z[6,7,6]  R1852     -2.0570243895053864e-01
    z[6,7,6]  R1853     2.8194564580917358e-01
    z[6,7,6]  R1854     3.9390745759010315e-01
    z[6,7,6]  R1855     5.0124108791351318e-01
    z[6,7,6]  R1856     1.9057209789752960e-01
    z[6,7,6]  R1857     -2.1545395255088806e-01
    z[6,7,6]  R1858     1.2802718579769135e-01
    z[6,7,6]  R1859     -9.1979824006557465e-02
    z[6,7,6]  R1860     -1.4083835482597351e-01
    z[6,7,6]  R1861     1.5833540260791779e-01
    z[6,7,6]  R1862     -2.6506617665290833e-01
    z[6,7,6]  R1863     -0.0858563557267189
    z[6,7,6]  R1864     -8.7235406041145325e-02
    z[6,7,6]  R1865     -4.4462716579437256e-01
    z[6,7,6]  R1866     -3.9062026143074036e-01
    z[6,7,6]  R1867     3.2532146573066711e-01
    z[6,7,6]  R1868     4.3012522161006927e-02
    z[6,7,6]  R1869     2.5615417957305908e-01
    z[6,7,6]  R1870     -2.9138103127479553e-01
    z[6,7,6]  R1871     1.3356015086174011e-01
    z[6,7,6]  R1872     1.5730434656143188e-01
    z[6,7,6]  R1873     -4.3593651056289673e-01
    z[6,7,6]  R1874     -0.140225350856781
    z[6,7,6]  R1875     -2.5206431746482849e-01
    z[6,7,6]  R1876     -1.5787303447723389e-02
    z[6,7,6]  R1877     -4.1746541857719421e-02
    z[6,7,6]  R1878     6.3529871404170990e-03
    z[6,7,6]  R1879     2.9483121633529663e-01
    z[6,7,6]  R1880     2.6193094253540039e-01
    z[6,7,6]  R1881     -9.3920081853866577e-02
    z[6,7,6]  R1882     -1.7072544991970062e-01
    z[6,7,6]  R1883     2.5153619050979614e-01
    z[6,7,6]  R1884     2.4349084123969078e-02
    z[6,7,6]  R1885     -7.0670828223228455e-02
    z[6,7,6]  R1886     -4.9534910917282104e-01
    z[6,7,6]  R1887     -5.1896870136260986e-01
    z[6,7,6]  R1888     -2.1348045766353607e-01
    z[6,7,6]  R1889     6.5155699849128723e-02
    z[6,7,6]  R1890     -3.8442060351371765e-01
    z[6,7,6]  R1891     -3.6522826552391052e-01
    z[6,7,6]  R1892     -5.3321099281311035e-01
    z[6,7,6]  R1893     -4.1150754690170288e-01
    z[6,7,6]  R1894     -2.2725136578083038e-01
    z[6,7,6]  R1895     -4.4010943174362183e-01
    z[6,7,6]  R1896     4.9814966320991516e-01
    z[6,7,6]  R1897     -5.5191016197204590e-01
    z[6,7,6]  R1898     5.1421072334051132e-02
    z[6,7,6]  R1899     -3.4445410966873169e-01
    z[6,7,6]  R1900     -5.1716709136962891e-01
    z[6,7,6]  R1901     -5.8411377668380737e-01
    z[6,7,6]  R1902     -1.1579652875661850e-01
    z[6,7,6]  R1903     -1.8633359670639038e-01
    z[6,7,6]  R1904     5.3940999507904053e-01
    z[6,7,6]  R1905     -1.0724445432424545e-01
    z[6,7,6]  R1906     1.7643353343009949e-01
    z[6,7,6]  R1907     3.0668148398399353e-01
    z[6,7,6]  R1908     -1.1719116568565369e-01
    z[6,7,6]  R1909     3.0471768975257874e-01
    z[6,7,6]  R1910     -2.2337767481803894e-01
    z[6,7,6]  R1911     1.4146524667739868e-01
    z[6,7,6]  R1912     1.2998740375041962e-01
    z[6,7,6]  R1913     -1.1390867084264755e-01
    z[6,7,6]  R1914     1.6196960210800171e-01
    z[6,7,6]  R1915     1.6091284155845642e-01
    z[6,7,6]  R1916     -1.6700872778892517e-01
    z[6,7,6]  R1917     -3.6162579059600830e-01
    z[6,7,6]  R1918     -1.2262653559446335e-01
    z[6,7,6]  R1919     -2.0207743346691132e-01
    z[6,7,6]  R1920     -4.9447190761566162e-01
    z[6,7,6]  R1921     -0.0311052855104208
    z[6,7,6]  R1922     -1.8951158225536346e-01
    z[6,7,6]  R1923     -2.0190356671810150e-01
    z[6,7,6]  R1924     -1.4829598367214203e-01
    z[6,7,6]  R1925     1.8061019480228424e-02
    z[6,7,6]  R1926     9.9628299474716187e-02
    z[6,7,6]  R1927     2.3286198079586029e-01
    z[6,7,6]  R1928     -6.2215197831392288e-02
    z[6,7,6]  R1929     3.0210867524147034e-01
    z[6,7,6]  R1930     3.2108891010284424e-01
    z[6,7,6]  R1931     -2.5963318347930908e-01
    z[6,7,6]  R1932     3.4084182232618332e-02
    z[6,7,6]  R1933     1.3686721026897430e-01
    z[6,7,6]  R1934     2.8160536289215088e-01
    z[6,7,6]  R1935     3.3674296736717224e-01
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R1936     -1
    z[7,6,0]  R1937     1
    z[7,6,0]  R1950     -4.1742384433746338e-01
    z[7,6,0]  R1951     -2.5374817848205566e-01
    z[7,6,0]  R1952     2.9268631339073181e-01
    z[7,6,0]  R1953     -2.8985580801963806e-01
    z[7,6,0]  R1954     -2.7387583255767822e-01
    z[7,6,0]  R1955     -9.6661873161792755e-02
    z[7,6,0]  R1956     -8.0902941524982452e-02
    z[7,6,0]  R1957     1.9217935204505920e-01
    z[7,6,0]  R1958     -2.7157601714134216e-01
    z[7,6,0]  R1959     -3.7019826471805573e-02
    z[7,6,0]  R1960     -5.1463431119918823e-01
    z[7,6,0]  R1961     -7.5788277387619019e-01
    z[7,6,0]  R1962     -6.9060385227203369e-01
    z[7,6,0]  R1963     -2.5572237372398376e-01
    z[7,6,0]  R1964     0.598052442073822
    z[7,6,0]  R1965     -6.2403172254562378e-01
    z[7,6,0]  R1966     -5.9778302907943726e-01
    z[7,6,0]  R1967     -3.7376496195793152e-01
    z[7,6,0]  R1968     -6.5007936954498291e-01
    z[7,6,0]  R1969     -0.4415283203125
    z[7,6,0]  R1970     4.9268159270286560e-01
    z[7,6,0]  R1971     3.1667700409889221e-01
    z[7,6,0]  R1972     7.0376896858215332e-01
    z[7,6,0]  R1973     1.9855907559394836e-01
    z[7,6,0]  R1974     5.9077608585357666e-01
    z[7,6,0]  R1975     6.7369127273559570e-01
    z[7,6,0]  R1976     4.7348472476005554e-01
    z[7,6,0]  R1977     4.4909808039665222e-01
    z[7,6,0]  R1978     3.1746962666511536e-01
    z[7,6,0]  R1979     5.1115787029266357e-01
    z[7,6,0]  R1980     -4.1719296574592590e-01
    z[7,6,0]  R1981     0.542195200920105
    z[7,6,0]  R1982     6.3908779621124268e-01
    z[7,6,0]  R1983     5.2245211601257324e-01
    z[7,6,0]  R1984     7.3084539175033569e-01
    z[7,6,0]  R1985     2.4125267565250397e-01
    z[7,6,0]  R1986     5.0219660997390747e-01
    z[7,6,0]  R1987     1.3187961280345917e-01
    z[7,6,0]  R1988     -1.3883483409881592e-01
    z[7,6,0]  R1989     2.9321116209030151e-01
    z[7,6,0]  R1990     -2.5262609124183655e-01
    z[7,6,0]  R1991     -8.2698212936520576e-03
    z[7,6,0]  R1992     6.6153752803802490e-01
    z[7,6,0]  R1993     6.0601574182510376e-01
    z[7,6,0]  R1994     5.0554829835891724e-01
    z[7,6,0]  R1995     2.1321113407611847e-01
    z[7,6,0]  R1996     1.7096064984798431e-01
    z[7,6,0]  R1997     3.4136199951171875e-01
    z[7,6,0]  R1998     6.2890779972076416e-01
    z[7,6,0]  R1999     0.561506986618042
    z[7,6,0]  R2000     2.7783498167991638e-01
    z[7,6,0]  R2001     3.9151710271835327e-01
    z[7,6,0]  R2002     4.8872488737106323e-01
    z[7,6,0]  R2003     5.9827280044555664e-01
    z[7,6,0]  R2004     5.3189265727996826e-01
    z[7,6,0]  R2005     -8.0244131386280060e-02
    z[7,6,0]  R2006     6.1898368597030640e-01
    z[7,6,0]  R2007     -1.2636521458625793e-01
    z[7,6,0]  R2008     4.7545289993286133e-01
    z[7,6,0]  R2009     -1.8992806971073151e-01
    z[7,6,0]  R2010     -4.4662123918533325e-01
    z[7,6,0]  R2011     7.5933212041854858e-01
    z[7,6,0]  R2012     1.4641419053077698e-01
    z[7,6,0]  R2013     9.0601153671741486e-02
    z[7,6,0]  R2014     1.4350548386573792e-01
    z[7,6,0]  R2015     4.1983413696289062e-01
    z[7,6,0]  R2016     4.4088366627693176e-01
    z[7,6,0]  R2017     -5.1574579629232176e-07
    z[7,6,0]  R2018     3.0272185802459717e-01
    z[7,6,0]  R2019     2.3438142240047455e-01
    z[7,6,0]  R2020     5.2997888997197151e-03
    z[7,6,0]  R2021     4.1948729753494263e-01
    z[7,6,0]  R2022     1.0437027364969254e-01
    z[7,6,0]  R2023     1.0525260120630264e-01
    z[7,6,0]  R2024     1.1023332178592682e-01
    z[7,6,0]  R2025     2.2316236793994904e-01
    z[7,6,0]  R2026     2.7278235554695129e-01
    z[7,6,0]  R2027     1.1781064420938492e-01
    z[7,6,0]  R2028     1.9081214070320129e-01
    z[7,6,0]  R2029     -7.6717101037502289e-02
    z[7,6,0]  R2030     -4.5044949650764465e-01
    z[7,6,0]  R2031     -5.4107826948165894e-01
    z[7,6,0]  R2032     -5.1500570774078369e-01
    z[7,6,0]  R2033     -3.2864689826965332e-01
    z[7,6,0]  R2034     -2.6566559076309204e-01
    z[7,6,0]  R2035     -4.6390482783317566e-01
    z[7,6,0]  R2036     -3.1404739618301392e-01
    z[7,6,0]  R2037     -4.4573992490768433e-01
    z[7,6,0]  R2038     -7.2129136323928833e-01
    z[7,6,0]  R2039     -3.1751331686973572e-01
    z[7,6,0]  R2040     -4.2320832610130310e-01
    z[7,6,0]  R2041     3.3356276154518127e-01
    z[7,6,0]  R2042     0.257706880569458
    z[7,6,0]  R2043     3.8330194354057312e-01
    z[7,6,0]  R2044     2.6250192523002625e-01
    z[7,6,0]  R2045     1.6237622499465942e-01
    z[7,6,0]  R2046     1.7827369272708893e-01
    z[7,6,0]  R2047     2.0058463513851166e-01
    z[7,6,0]  R2048     3.5954967141151428e-01
    z[7,6,0]  R2049     2.3779372870922089e-01
    z[7,6,0]  R2050     5.6475032120943069e-02
    z[7,6,0]  R2051     -1.8334245681762695e-01
    z[7,6,0]  R2052     1.4990578591823578e-01
    z[7,6,0]  R2053     -9.8930656909942627e-02
    z[7,6,0]  R2054     -3.7739716470241547e-02
    z[7,6,0]  R2055     -4.2912218719720840e-02
    z[7,6,0]  R2056     -5.2289735525846481e-02
    z[7,6,0]  R2057     3.5226665437221527e-02
    z[7,6,0]  R2058     0.0677286833524704
    z[7,6,0]  R2059     1.6244037076830864e-02
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R1938     -1
    z[7,6,1]  R1939     1
    z[7,6,1]  R1950     -7.0349895954132080e-01
    z[7,6,1]  R1951     -7.6073330640792847e-01
    z[7,6,1]  R1952     -5.8580768108367920e-01
    z[7,6,1]  R1953     -0.550881564617157
    z[7,6,1]  R1954     -4.3758830428123474e-01
    z[7,6,1]  R1955     -5.0719237327575684e-01
    z[7,6,1]  R1956     -0.727531909942627
    z[7,6,1]  R1957     -6.8581086397171021e-01
    z[7,6,1]  R1958     -5.8624863624572754e-01
    z[7,6,1]  R1959     -5.6832879781723022e-01
    z[7,6,1]  R1960     8.1121939420700073e-01
    z[7,6,1]  R1961     5.9868144989013672e-01
    z[7,6,1]  R1962     0.481892466545105
    z[7,6,1]  R1963     8.4463369846343994e-01
    z[7,6,1]  R1964     5.9536057710647583e-01
    z[7,6,1]  R1965     6.6302919387817383e-01
    z[7,6,1]  R1966     0.513116717338562
    z[7,6,1]  R1967     8.2301336526870728e-01
    z[7,6,1]  R1968     5.3453516960144043e-01
    z[7,6,1]  R1969     7.6250523328781128e-01
    z[7,6,1]  R1970     6.1349582672119141e-01
    z[7,6,1]  R1971     3.7861829996109009e-01
    z[7,6,1]  R1972     2.5431987643241882e-01
    z[7,6,1]  R1973     0.417542427778244
    z[7,6,1]  R1974     1.4204722642898560e-01
    z[7,6,1]  R1975     3.9823630452156067e-01
    z[7,6,1]  R1976     0.381229043006897
    z[7,6,1]  R1977     3.3481189608573914e-01
    z[7,6,1]  R1978     3.3361795544624329e-01
    z[7,6,1]  R1979     3.3566546440124512e-01
    z[7,6,1]  R1980     5.5710178613662720e-01
    z[7,6,1]  R1981     4.2706665396690369e-01
    z[7,6,1]  R1982     2.6934564113616943e-01
    z[7,6,1]  R1983     2.0655032992362976e-01
    z[7,6,1]  R1984     0.293347030878067
    z[7,6,1]  R1985     5.4523384571075439e-01
    z[7,6,1]  R1986     0.469305157661438
    z[7,6,1]  R1987     2.6761990785598755e-01
    z[7,6,1]  R1988     2.3617841303348541e-01
    z[7,6,1]  R1989     6.4018809795379639e-01
    z[7,6,1]  R1990     6.9004052877426147e-01
    z[7,6,1]  R1991     4.9356538057327271e-01
    z[7,6,1]  R1992     3.3252444863319397e-01
    z[7,6,1]  R1993     3.8503104448318481e-01
    z[7,6,1]  R1994     6.2245595455169678e-01
    z[7,6,1]  R1995     6.7525357007980347e-02
    z[7,6,1]  R1996     3.8494072854518890e-02
    z[7,6,1]  R1997     6.1756855249404907e-01
    z[7,6,1]  R1998     3.2897058129310608e-01
    z[7,6,1]  R1999     3.0310752987861633e-01
    z[7,6,1]  R2000     0.330127477645874
    z[7,6,1]  R2001     2.0856209099292755e-01
    z[7,6,1]  R2002     7.3431402444839478e-01
    z[7,6,1]  R2003     2.1689492464065552e-01
    z[7,6,1]  R2004     0.392946720123291
    z[7,6,1]  R2005     3.2396170496940613e-01
    z[7,6,1]  R2006     3.3498492836952209e-01
    z[7,6,1]  R2007     -0.0694834440946579
    z[7,6,1]  R2008     3.7733837962150574e-01
    z[7,6,1]  R2009     2.0810633897781372e-02
    z[7,6,1]  R2010     6.7973607778549194e-01
    z[7,6,1]  R2011     2.9732012748718262e-01
    z[7,6,1]  R2012     3.7649261951446533e-01
    z[7,6,1]  R2013     3.6698821187019348e-01
    z[7,6,1]  R2014     5.4701352491974831e-03
    z[7,6,1]  R2015     4.3893152475357056e-01
    z[7,6,1]  R2016     0.687838613986969
    z[7,6,1]  R2017     3.1641638278961182e-01
    z[7,6,1]  R2018     -0.440679132938385
    z[7,6,1]  R2019     -4.1323426365852356e-01
    z[7,6,1]  R2020     -7.3530954122543335e-01
    z[7,6,1]  R2021     -4.9588376283645630e-01
    z[7,6,1]  R2022     -5.7717734575271606e-01
    z[7,6,1]  R2023     -0.414680153131485
    z[7,6,1]  R2024     -7.2164130210876465e-01
    z[7,6,1]  R2025     -5.0093287229537964e-01
    z[7,6,1]  R2026     -4.1679385304450989e-01
    z[7,6,1]  R2027     -6.5210425853729248e-01
    z[7,6,1]  R2028     -5.0346869230270386e-01
    z[7,6,1]  R2029     -4.0078547596931458e-01
    z[7,6,1]  R2030     6.4957511425018311e-01
    z[7,6,1]  R2031     6.9872868061065674e-01
    z[7,6,1]  R2032     7.6962876319885254e-01
    z[7,6,1]  R2033     6.7264169454574585e-01
    z[7,6,1]  R2034     8.2818859815597534e-01
    z[7,6,1]  R2035     0.672106921672821
    z[7,6,1]  R2036     6.5434855222702026e-01
    z[7,6,1]  R2037     5.9246122837066650e-01
    z[7,6,1]  R2038     4.7276049852371216e-01
    z[7,6,1]  R2039     7.1293371915817261e-01
    z[7,6,1]  R2040     -4.0303513407707214e-01
    z[7,6,1]  R2041     9.0070790052413940e-01
    z[7,6,1]  R2042     9.1339069604873657e-01
    z[7,6,1]  R2043     7.8830051422119141e-01
    z[7,6,1]  R2044     8.8143730163574219e-01
    z[7,6,1]  R2045     8.4697675704956055e-01
    z[7,6,1]  R2046     8.5751402378082275e-01
    z[7,6,1]  R2047     8.3328926563262939e-01
    z[7,6,1]  R2048     8.0506402254104614e-01
    z[7,6,1]  R2049     8.1652712821960449e-01
    z[7,6,1]  R2050     9.0135276317596436e-01
    z[7,6,1]  R2051     7.3534977436065674e-01
    z[7,6,1]  R2052     8.2764226198196411e-01
    z[7,6,1]  R2053     8.6859047412872314e-01
    z[7,6,1]  R2054     9.2246288061141968e-01
    z[7,6,1]  R2055     8.4907406568527222e-01
    z[7,6,1]  R2056     8.6507821083068848e-01
    z[7,6,1]  R2057     7.8361368179321289e-01
    z[7,6,1]  R2058     7.2851365804672241e-01
    z[7,6,1]  R2059     7.8142297267913818e-01
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R1940     -1
    z[7,6,2]  R1941     1
    z[7,6,2]  R1950     -3.7101060152053833e-02
    z[7,6,2]  R1951     3.2610440254211426e-01
    z[7,6,2]  R1952     4.3813946843147278e-01
    z[7,6,2]  R1953     4.1852509975433350e-01
    z[7,6,2]  R1954     2.9723653197288513e-01
    z[7,6,2]  R1955     3.8061714172363281e-01
    z[7,6,2]  R1956     2.5127744302153587e-02
    z[7,6,2]  R1957     -1.0600391030311584e-01
    z[7,6,2]  R1958     -1.6638176143169403e-01
    z[7,6,2]  R1959     -5.9659677743911743e-01
    z[7,6,2]  R1960     1.8641431629657745e-01
    z[7,6,2]  R1961     -2.8258139267563820e-02
    z[7,6,2]  R1962     4.6208903193473816e-01
    z[7,6,2]  R1963     3.3079397678375244e-01
    z[7,6,2]  R1964     -4.5337709784507751e-01
    z[7,6,2]  R1965     -3.7219825387001038e-01
    z[7,6,2]  R1966     2.0643375813961029e-01
    z[7,6,2]  R1967     -2.2771295905113220e-01
    z[7,6,2]  R1968     1.4864406548440456e-02
    z[7,6,2]  R1969     -3.4367975592613220e-01
    z[7,6,2]  R1970     1.2198777496814728e-01
    z[7,6,2]  R1971     -1.7813597619533539e-01
    z[7,6,2]  R1972     1.8026264011859894e-01
    z[7,6,2]  R1973     -5.3825759887695312e-01
    z[7,6,2]  R1974     -1.8358139693737030e-01
    z[7,6,2]  R1975     1.8783777952194214e-01
    z[7,6,2]  R1976     1.0380639135837555e-01
    z[7,6,2]  R1977     8.4439389407634735e-02
    z[7,6,2]  R1978     -1.6782304644584656e-01
    z[7,6,2]  R1979     -8.1393130123615265e-02
    z[7,6,2]  R1980     1.0979621671140194e-02
    z[7,6,2]  R1981     -1.5255357325077057e-01
    z[7,6,2]  R1982     -1.8891420960426331e-01
    z[7,6,2]  R1983     -2.2009547054767609e-01
    z[7,6,2]  R1984     -2.3043116554617882e-02
    z[7,6,2]  R1985     -4.8352709412574768e-01
    z[7,6,2]  R1986     2.6932433247566223e-01
    z[7,6,2]  R1987     -8.2781696319580078e-01
    z[7,6,2]  R1988     -4.9663653969764709e-01
    z[7,6,2]  R1989     2.2295682132244110e-01
    z[7,6,2]  R1990     -4.5636307448148727e-02
    z[7,6,2]  R1991     -5.5839467048645020e-01
    z[7,6,2]  R1992     -8.6928181350231171e-02
    z[7,6,2]  R1993     -4.7206360846757889e-02
    z[7,6,2]  R1994     2.7449253201484680e-01
    z[7,6,2]  R1995     -7.0911628007888794e-01
    z[7,6,2]  R1996     -8.0570483207702637e-01
    z[7,6,2]  R1997     -4.4521424919366837e-02
    z[7,6,2]  R1998     2.3619423806667328e-01
    z[7,6,2]  R1999     -5.7745543308556080e-03
    z[7,6,2]  R2000     -7.3673325777053833e-01
    z[7,6,2]  R2001     -5.7246792316436768e-01
    z[7,6,2]  R2002     1.7531728744506836e-01
    z[7,6,2]  R2003     -3.1774231791496277e-01
    z[7,6,2]  R2004     -1.6345228999853134e-02
    z[7,6,2]  R2005     -5.2697920799255371e-01
    z[7,6,2]  R2006     3.7351274490356445e-01
    z[7,6,2]  R2007     2.5668165180832148e-03
    z[7,6,2]  R2008     -4.7355074435472488e-02
    z[7,6,2]  R2009     2.9300722479820251e-01
    z[7,6,2]  R2010     1.2888029217720032e-01
    z[7,6,2]  R2011     -1.2716868519783020e-01
    z[7,6,2]  R2012     -3.5650515556335449e-01
    z[7,6,2]  R2013     -0.820137083530426
    z[7,6,2]  R2014     -7.3708117008209229e-01
    z[7,6,2]  R2015     -1.4826372265815735e-01
    z[7,6,2]  R2016     2.5509911775588989e-01
    z[7,6,2]  R2017     -5.1989001035690308e-01
    z[7,6,2]  R2018     -3.2574686408042908e-01
    z[7,6,2]  R2019     -1.7981612682342529e-01
    z[7,6,2]  R2020     -5.4525830782949924e-03
    z[7,6,2]  R2021     -2.1860765293240547e-02
    z[7,6,2]  R2022     3.9826986193656921e-01
    z[7,6,2]  R2023     7.2109901905059814e-01
    z[7,6,2]  R2024     2.4163636565208435e-01
    z[7,6,2]  R2025     -1.7734654247760773e-01
    z[7,6,2]  R2026     1.7134083807468414e-01
    z[7,6,2]  R2027     -4.6825617551803589e-02
    z[7,6,2]  R2028     1.2852217257022858e-01
    z[7,6,2]  R2029     1.9431334733963013e-01
    z[7,6,2]  R2030     -4.2230904102325439e-01
    z[7,6,2]  R2031     -2.5339594483375549e-01
    z[7,6,2]  R2032     -3.4795930981636047e-01
    z[7,6,2]  R2033     -6.3886839151382446e-01
    z[7,6,2]  R2034     -1.8048506975173950e-01
    z[7,6,2]  R2035     -0.401504784822464
    z[7,6,2]  R2036     -2.5141322612762451e-01
    z[7,6,2]  R2037     -4.0240389108657837e-01
    z[7,6,2]  R2038     -4.6404087543487549e-01
    z[7,6,2]  R2039     -2.8564265370368958e-01
    z[7,6,2]  R2040     -0.062485221773386
    z[7,6,2]  R2041     1.3245701789855957e-01
    z[7,6,2]  R2042     1.8474271893501282e-01
    z[7,6,2]  R2043     3.9558848738670349e-01
    z[7,6,2]  R2044     -2.3664797842502594e-01
    z[7,6,2]  R2045     1.3192997872829437e-01
    z[7,6,2]  R2046     -3.4804251790046692e-01
    z[7,6,2]  R2047     1.7199221253395081e-01
    z[7,6,2]  R2048     3.8362555205821991e-02
    z[7,6,2]  R2049     1.2735572457313538e-01
    z[7,6,2]  R2050     -1.3399665057659149e-01
    z[7,6,2]  R2051     -3.9168280363082886e-01
    z[7,6,2]  R2052     -4.4084903597831726e-01
    z[7,6,2]  R2053     -8.7382178753614426e-03
    z[7,6,2]  R2054     -1.4443391561508179e-01
    z[7,6,2]  R2055     -0.0871066004037857
    z[7,6,2]  R2056     -7.0164717733860016e-02
    z[7,6,2]  R2057     2.2188569605350494e-01
    z[7,6,2]  R2058     -4.7210793942213058e-02
    z[7,6,2]  R2059     0.072322316467762
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R1942     -1
    z[7,6,3]  R1943     1
    z[7,6,3]  R1950     -2.1796271204948425e-01
    z[7,6,3]  R1951     -3.2439276576042175e-01
    z[7,6,3]  R1952     -5.6626987457275391e-01
    z[7,6,3]  R1953     -0.48638716340065
    z[7,6,3]  R1954     -4.4167909026145935e-01
    z[7,6,3]  R1955     -2.3436361551284790e-01
    z[7,6,3]  R1956     -2.6952078938484192e-01
    z[7,6,3]  R1957     -3.3212468028068542e-01
    z[7,6,3]  R1958     -2.0623359084129333e-01
    z[7,6,3]  R1959     -4.9054530262947083e-01
    z[7,6,3]  R1960     -1.3675317168235779e-01
    z[7,6,3]  R1961     1.4900295436382294e-01
    z[7,6,3]  R1962     -6.4627096056938171e-02
    z[7,6,3]  R1963     1.0589123517274857e-01
    z[7,6,3]  R1964     -6.5986894071102142e-02
    z[7,6,3]  R1965     6.7552458494901657e-03
    z[7,6,3]  R1966     4.8386582732200623e-01
    z[7,6,3]  R1967     2.5144720077514648e-01
    z[7,6,3]  R1968     3.4883657097816467e-01
    z[7,6,3]  R1969     -9.3822255730628967e-02
    z[7,6,3]  R1970     1.0117420926690102e-02
    z[7,6,3]  R1971     4.2367298156023026e-02
    z[7,6,3]  R1972     5.7666087150573730e-01
    z[7,6,3]  R1973     -3.8918060064315796e-01
    z[7,6,3]  R1974     -1.8717030063271523e-02
    z[7,6,3]  R1975     -2.6123163104057312e-01
    z[7,6,3]  R1976     3.8880711793899536e-01
    z[7,6,3]  R1977     1.2805530428886414e-01
    z[7,6,3]  R1978     -2.7015671133995056e-01
    z[7,6,3]  R1979     4.7361102700233459e-01
    z[7,6,3]  R1980     3.4452080726623535e-01
    z[7,6,3]  R1981     0.437370240688324
    z[7,6,3]  R1982     -2.0321829617023468e-01
    z[7,6,3]  R1983     3.1056657433509827e-01
    z[7,6,3]  R1984     -6.8546503782272339e-02
    z[7,6,3]  R1985     1.1138024926185608e-01
    z[7,6,3]  R1986     0.0956350564956665
    z[7,6,3]  R1987     -3.4429600834846497e-01
    z[7,6,3]  R1988     -3.4128466248512268e-01
    z[7,6,3]  R1989     3.4088918566703796e-01
    z[7,6,3]  R1990     1.0349992662668228e-01
    z[7,6,3]  R1991     -2.3556242883205414e-01
    z[7,6,3]  R1992     4.5910966396331787e-01
    z[7,6,3]  R1993     2.2986364364624023e-01
    z[7,6,3]  R1994     4.1589993238449097e-01
    z[7,6,3]  R1995     -3.8168314844369888e-02
    z[7,6,3]  R1996     1.6509534791111946e-02
    z[7,6,3]  R1997     -5.8023923635482788e-01
    z[7,6,3]  R1998     4.0125700831413269e-01
    z[7,6,3]  R1999     5.0967288017272949e-01
    z[7,6,3]  R2000     -1.3190989196300507e-01
    z[7,6,3]  R2001     -2.7765738964080811e-01
    z[7,6,3]  R2002     2.5022971630096436e-01
    z[7,6,3]  R2003     1.6130031645298004e-01
    z[7,6,3]  R2004     1.4988344162702560e-02
    z[7,6,3]  R2005     -2.6825568079948425e-01
    z[7,6,3]  R2006     3.1657463312149048e-01
    z[7,6,3]  R2007     8.1094855070114136e-01
    z[7,6,3]  R2008     -0.509924590587616
    z[7,6,3]  R2009     7.0410865545272827e-01
    z[7,6,3]  R2010     5.1008999347686768e-01
    z[7,6,3]  R2011     9.8537676036357880e-02
    z[7,6,3]  R2012     -5.3781199455261230e-01
    z[7,6,3]  R2013     -2.5534653663635254e-01
    z[7,6,3]  R2014     -4.7703534364700317e-01
    z[7,6,3]  R2015     -3.2695853710174561e-01
    z[7,6,3]  R2016     -0.295698344707489
    z[7,6,3]  R2017     -7.7478241920471191e-01
    z[7,6,3]  R2018     6.7410397529602051e-01
    z[7,6,3]  R2019     0.667834460735321
    z[7,6,3]  R2020     -7.8702464699745178e-02
    z[7,6,3]  R2021     -5.4290610551834106e-01
    z[7,6,3]  R2022     -1.7345812916755676e-01
    z[7,6,3]  R2023     -2.7939155697822571e-01
    z[7,6,3]  R2024     -4.9790588021278381e-01
    z[7,6,3]  R2025     -4.0655446052551270e-01
    z[7,6,3]  R2026     -4.7898799180984497e-01
    z[7,6,3]  R2027     -3.0154135823249817e-01
    z[7,6,3]  R2028     -3.7619385123252869e-01
    z[7,6,3]  R2029     -0.323411226272583
    z[7,6,3]  R2030     3.9414972066879272e-01
    z[7,6,3]  R2031     2.9318007826805115e-01
    z[7,6,3]  R2032     1.6355967149138451e-02
    z[7,6,3]  R2033     -4.4523615390062332e-02
    z[7,6,3]  R2034     2.1793028712272644e-01
    z[7,6,3]  R2035     -2.7577212080359459e-02
    z[7,6,3]  R2036     2.9820641875267029e-01
    z[7,6,3]  R2037     4.6124079823493958e-01
    z[7,6,3]  R2038     3.5927388817071915e-02
    z[7,6,3]  R2039     5.1341433078050613e-02
    z[7,6,3]  R2040     7.0136207342147827e-01
    z[7,6,3]  R2041     -9.1290250420570374e-02
    z[7,6,3]  R2042     -1.4799717068672180e-01
    z[7,6,3]  R2043     -1.5839058160781860e-01
    z[7,6,3]  R2044     -1.9270788133144379e-01
    z[7,6,3]  R2045     2.3124691843986511e-01
    z[7,6,3]  R2046     -4.1036497801542282e-02
    z[7,6,3]  R2047     2.1468129009008408e-02
    z[7,6,3]  R2048     -2.4786441028118134e-01
    z[7,6,3]  R2049     8.2508064806461334e-02
    z[7,6,3]  R2050     3.2507243752479553e-01
    z[7,6,3]  R2051     4.1435372829437256e-01
    z[7,6,3]  R2052     9.4971351325511932e-02
    z[7,6,3]  R2053     3.5890835523605347e-01
    z[7,6,3]  R2054     2.7370864152908325e-01
    z[7,6,3]  R2055     1.5111638605594635e-01
    z[7,6,3]  R2056     3.9690554141998291e-01
    z[7,6,3]  R2057     1.9343625009059906e-01
    z[7,6,3]  R2058     -1.6232079267501831e-01
    z[7,6,3]  R2059     1.5407501161098480e-01
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R1944     -1
    z[7,6,4]  R1945     1
    z[7,6,4]  R1950     -3.4477835893630981e-01
    z[7,6,4]  R1951     -9.4077989459037781e-02
    z[7,6,4]  R1952     1.8941025435924530e-01
    z[7,6,4]  R1953     1.7641784250736237e-01
    z[7,6,4]  R1954     6.8979769945144653e-02
    z[7,6,4]  R1955     -3.9085236191749573e-01
    z[7,6,4]  R1956     5.9848743677139282e-01
    z[7,6,4]  R1957     1.4117564260959625e-01
    z[7,6,4]  R1958     5.1248639822006226e-01
    z[7,6,4]  R1959     1.1978673934936523e-01
    z[7,6,4]  R1960     0.097610242664814
    z[7,6,4]  R1961     -1.5691386163234711e-01
    z[7,6,4]  R1962     -1.3203912973403931e-01
    z[7,6,4]  R1963     8.7045609951019287e-02
    z[7,6,4]  R1964     2.8269633185118437e-03
    z[7,6,4]  R1965     -7.5232565402984619e-02
    z[7,6,4]  R1966     3.9024170488119125e-02
    z[7,6,4]  R1967     -5.6769125163555145e-02
    z[7,6,4]  R1968     -1.8793129920959473e-01
    z[7,6,4]  R1969     1.0737630724906921e-01
    z[7,6,4]  R1970     3.2515057921409607e-01
    z[7,6,4]  R1971     -5.4684060811996460e-01
    z[7,6,4]  R1972     -1.5085913240909576e-01
    z[7,6,4]  R1973     1.4507076144218445e-01
    z[7,6,4]  R1974     6.4669072628021240e-02
    z[7,6,4]  R1975     1.7920480668544769e-01
    z[7,6,4]  R1976     -2.2350139915943146e-01
    z[7,6,4]  R1977     4.9102181196212769e-01
    z[7,6,4]  R1978     4.8082631826400757e-01
    z[7,6,4]  R1979     3.9034748077392578e-01
    z[7,6,4]  R1980     -3.8204270601272583e-01
    z[7,6,4]  R1981     -6.4795307815074921e-02
    z[7,6,4]  R1982     3.1710690259933472e-01
    z[7,6,4]  R1983     -1.7232243716716766e-01
    z[7,6,4]  R1984     1.1811833083629608e-01
    z[7,6,4]  R1985     -2.2556933760643005e-01
    z[7,6,4]  R1986     -4.4569936394691467e-01
    z[7,6,4]  R1987     2.0808382332324982e-01
    z[7,6,4]  R1988     -5.1360708475112915e-01
    z[7,6,4]  R1989     -5.0404256582260132e-01
    z[7,6,4]  R1990     8.1670030951499939e-02
    z[7,6,4]  R1991     -4.0133169293403625e-01
    z[7,6,4]  R1992     -3.7903463840484619e-01
    z[7,6,4]  R1993     -1.1011761426925659e-01
    z[7,6,4]  R1994     -1.4226512610912323e-01
    z[7,6,4]  R1995     -6.4063584804534912e-01
    z[7,6,4]  R1996     -4.1146388649940491e-01
    z[7,6,4]  R1997     0.206847682595253
    z[7,6,4]  R1998     3.7891995906829834e-01
    z[7,6,4]  R1999     -2.9972764849662781e-01
    z[7,6,4]  R2000     -4.7512295842170715e-01
    z[7,6,4]  R2001     9.5892600715160370e-02
    z[7,6,4]  R2002     -2.8939386829733849e-03
    z[7,6,4]  R2003     -1.4694561064243317e-01
    z[7,6,4]  R2004     -2.4297364056110382e-01
    z[7,6,4]  R2005     -1.5307384543120861e-02
    z[7,6,4]  R2006     4.6376258134841919e-01
    z[7,6,4]  R2007     1.1937827616930008e-01
    z[7,6,4]  R2008     -5.8907294273376465e-01
    z[7,6,4]  R2009     -4.6194321475923061e-03
    z[7,6,4]  R2010     -1.8133457051590085e-03
    z[7,6,4]  R2011     -3.8105627894401550e-01
    z[7,6,4]  R2012     -4.3600201606750488e-03
    z[7,6,4]  R2013     -1.5064917504787445e-01
    z[7,6,4]  R2014     -3.1293755769729614e-01
    z[7,6,4]  R2015     6.3089394569396973e-01
    z[7,6,4]  R2016     1.5609785914421082e-01
    z[7,6,4]  R2017     -0.0791405513882637
    z[7,6,4]  R2018     -2.6542615890502930e-01
    z[7,6,4]  R2019     -3.0111056566238403e-01
    z[7,6,4]  R2020     -6.5583787858486176e-02
    z[7,6,4]  R2021     -0.0800815224647522
    z[7,6,4]  R2022     -6.0458654165267944e-01
    z[7,6,4]  R2023     -1.7526540160179138e-01
    z[7,6,4]  R2024     1.7153823375701904e-01
    z[7,6,4]  R2025     -5.8877730369567871e-01
    z[7,6,4]  R2026     -0.381697416305542
    z[7,6,4]  R2027     2.6414009928703308e-01
    z[7,6,4]  R2028     -6.7557895183563232e-01
    z[7,6,4]  R2029     -8.0988389253616333e-01
    z[7,6,4]  R2030     3.0215349048376083e-02
    z[7,6,4]  R2031     -1.1738082021474838e-01
    z[7,6,4]  R2032     1.1353948712348938e-01
    z[7,6,4]  R2033     -4.5189879834651947e-02
    z[7,6,4]  R2034     1.2621504068374634e-01
    z[7,6,4]  R2035     -2.8321878984570503e-02
    z[7,6,4]  R2036     2.0029008388519287e-01
    z[7,6,4]  R2037     1.5489107370376587e-01
    z[7,6,4]  R2038     -1.4238531701266766e-02
    z[7,6,4]  R2039     1.7537397146224976e-01
    z[7,6,4]  R2040     -7.3311820626258850e-02
    z[7,6,4]  R2041     8.1896416842937469e-02
    z[7,6,4]  R2042     -1.5243300795555115e-01
    z[7,6,4]  R2043     4.0392596274614334e-02
    z[7,6,4]  R2044     -2.4234730750322342e-02
    z[7,6,4]  R2045     -2.0024940371513367e-01
    z[7,6,4]  R2046     5.5311162024736404e-02
    z[7,6,4]  R2047     -3.4424898028373718e-01
    z[7,6,4]  R2048     6.6722683608531952e-02
    z[7,6,4]  R2049     -2.4594143033027649e-02
    z[7,6,4]  R2050     1.2444531172513962e-01
    z[7,6,4]  R2051     0.046059750020504
    z[7,6,4]  R2052     1.2458857148885727e-01
    z[7,6,4]  R2053     -2.6181265711784363e-01
    z[7,6,4]  R2054     -1.2470588833093643e-01
    z[7,6,4]  R2055     -2.0413656532764435e-01
    z[7,6,4]  R2056     -1.0960114002227783e-01
    z[7,6,4]  R2057     1.5741668641567230e-01
    z[7,6,4]  R2058     8.2987584173679352e-02
    z[7,6,4]  R2059     1.7803196609020233e-01
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R1946     -1
    z[7,6,5]  R1947     1
    z[7,6,5]  R1950     -1.0249841958284378e-01
    z[7,6,5]  R1951     1.7503528296947479e-01
    z[7,6,5]  R1952     -1.4425632357597351e-01
    z[7,6,5]  R1953     -3.2255119085311890e-01
    z[7,6,5]  R1954     -0.600347638130188
    z[7,6,5]  R1955     -6.0250550508499146e-01
    z[7,6,5]  R1956     0.0891474261879921
    z[7,6,5]  R1957     4.0151673555374146e-01
    z[7,6,5]  R1958     -4.7962307929992676e-01
    z[7,6,5]  R1959     -3.4413054585456848e-02
    z[7,6,5]  R1960     -1.1766847223043442e-01
    z[7,6,5]  R1961     1.3352537155151367e-01
    z[7,6,5]  R1962     2.3594121634960175e-01
    z[7,6,5]  R1963     7.7845461666584015e-02
    z[7,6,5]  R1964     0.0967373251914978
    z[7,6,5]  R1965     -1.3386048376560211e-01
    z[7,6,5]  R1966     -2.6824557781219482e-01
    z[7,6,5]  R1967     3.7103157490491867e-02
    z[7,6,5]  R1968     -3.6585512757301331e-01
    z[7,6,5]  R1969     2.8318911790847778e-01
    z[7,6,5]  R1970     1.2169913202524185e-01
    z[7,6,5]  R1971     -3.9303097128868103e-01
    z[7,6,5]  R1972     -0.0816449224948883
    z[7,6,5]  R1973     -5.6547236442565918e-01
    z[7,6,5]  R1974     -6.6692757606506348e-01
    z[7,6,5]  R1975     -3.4426271915435791e-01
    z[7,6,5]  R1976     3.6641916632652283e-01
    z[7,6,5]  R1977     -5.0223779678344727e-01
    z[7,6,5]  R1978     -6.3555151224136353e-01
    z[7,6,5]  R1979     -2.2146481275558472e-01
    z[7,6,5]  R1980     -5.1602099090814590e-02
    z[7,6,5]  R1981     1.6430897638201714e-02
    z[7,6,5]  R1982     -5.8209329843521118e-01
    z[7,6,5]  R1983     -6.2541455030441284e-01
    z[7,6,5]  R1984     -3.0523651838302612e-01
    z[7,6,5]  R1985     7.9011030495166779e-02
    z[7,6,5]  R1986     4.8354193568229675e-01
    z[7,6,5]  R1987     -1.7072671651840210e-01
    z[7,6,5]  R1988     -8.4060803055763245e-02
    z[7,6,5]  R1989     -2.6964968442916870e-01
    z[7,6,5]  R1990     6.3986754417419434e-01
    z[7,6,5]  R1991     -3.6593699455261230e-01
    z[7,6,5]  R1992     -2.7578333020210266e-01
    z[7,6,5]  R1993     -5.6960654258728027e-01
    z[7,6,5]  R1994     1.9624894857406616e-01
    z[7,6,5]  R1995     -1.2349840998649597e-01
    z[7,6,5]  R1996     -3.6559337377548218e-01
    z[7,6,5]  R1997     -3.2811611890792847e-01
    z[7,6,5]  R1998     -3.3112549781799316e-01
    z[7,6,5]  R1999     4.6616134047508240e-01
    z[7,6,5]  R2000     3.7009748630225658e-03
    z[7,6,5]  R2001     -5.0836455821990967e-01
    z[7,6,5]  R2002     3.3694821596145630e-01
    z[7,6,5]  R2003     -6.3688290119171143e-01
    z[7,6,5]  R2004     -0.508578896522522
    z[7,6,5]  R2005     -7.3330736160278320e-01
    z[7,6,5]  R2006     -1.1799383908510208e-01
    z[7,6,5]  R2007     5.1627850532531738e-01
    z[7,6,5]  R2008     1.7205353826284409e-02
    z[7,6,5]  R2009     6.1767673492431641e-01
    z[7,6,5]  R2010     -2.2750230133533478e-01
    z[7,6,5]  R2011     -3.3121803402900696e-01
    z[7,6,5]  R2012     -6.4543688297271729e-01
    z[7,6,5]  R2013     -7.2935491800308228e-02
    z[7,6,5]  R2014     -8.6584746837615967e-02
    z[7,6,5]  R2015     -1.9172337651252747e-01
    z[7,6,5]  R2016     -3.9301192760467529e-01
    z[7,6,5]  R2017     -6.5661981701850891e-02
    z[7,6,5]  R2018     6.2302328646183014e-02
    z[7,6,5]  R2019     3.0315449833869934e-01
    z[7,6,5]  R2020     -6.5855300426483154e-01
    z[7,6,5]  R2021     -0.524657666683197
    z[7,6,5]  R2022     2.6140136644244194e-02
    z[7,6,5]  R2023     -6.4212411642074585e-02
    z[7,6,5]  R2024     3.1182447075843811e-01
    z[7,6,5]  R2025     -1.8741479516029358e-01
    z[7,6,5]  R2026     -1.5266482532024384e-01
    z[7,6,5]  R2027     3.9203429222106934e-01
    z[7,6,5]  R2028     2.8428819775581360e-01
    z[7,6,5]  R2029     -1.8582858145236969e-01
    z[7,6,5]  R2030     8.4322936832904816e-02
    z[7,6,5]  R2031     2.0743592083454132e-01
    z[7,6,5]  R2032     -9.0206608176231384e-02
    z[7,6,5]  R2033     1.6514307260513306e-01
    z[7,6,5]  R2034     2.6645395159721375e-01
    z[7,6,5]  R2035     3.2838270068168640e-01
    z[7,6,5]  R2036     5.2637696266174316e-01
    z[7,6,5]  R2037     -1.9093910232186317e-02
    z[7,6,5]  R2038     1.6806872189044952e-01
    z[7,6,5]  R2039     5.1751202344894409e-01
    z[7,6,5]  R2040     3.1335690617561340e-01
    z[7,6,5]  R2041     -2.0860818028450012e-01
    z[7,6,5]  R2042     -5.0855904817581177e-02
    z[7,6,5]  R2043     -7.0194430649280548e-02
    z[7,6,5]  R2044     -5.6670308113098145e-02
    z[7,6,5]  R2045     -3.5609897971153259e-01
    z[7,6,5]  R2046     -2.5435757637023926e-01
    z[7,6,5]  R2047     -1.9326642155647278e-01
    z[7,6,5]  R2048     8.5207270458340645e-03
    z[7,6,5]  R2049     -4.3164554983377457e-02
    z[7,6,5]  R2050     9.4563901424407959e-02
    z[7,6,5]  R2051     2.2803477942943573e-01
    z[7,6,5]  R2052     -2.3928210139274597e-01
    z[7,6,5]  R2053     1.7281684279441833e-01
    z[7,6,5]  R2054     1.2834899127483368e-01
    z[7,6,5]  R2055     4.2434215545654297e-01
    z[7,6,5]  R2056     -6.4620628952980042e-02
    z[7,6,5]  R2057     0.515661358833313
    z[7,6,5]  R2058     6.4931267499923706e-01
    z[7,6,5]  R2059     3.6160182952880859e-01
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R1948     -1
    z[7,6,6]  R1949     1
    z[7,6,6]  R1950     -3.9062026143074036e-01
    z[7,6,6]  R1951     3.2532146573066711e-01
    z[7,6,6]  R1952     4.3012522161006927e-02
    z[7,6,6]  R1953     2.5615417957305908e-01
    z[7,6,6]  R1954     -2.9138103127479553e-01
    z[7,6,6]  R1955     1.3356015086174011e-01
    z[7,6,6]  R1956     1.5730434656143188e-01
    z[7,6,6]  R1957     -4.3593651056289673e-01
    z[7,6,6]  R1958     -0.140225350856781
    z[7,6,6]  R1959     -2.5206431746482849e-01
    z[7,6,6]  R1960     -1.5787303447723389e-02
    z[7,6,6]  R1961     -4.1746541857719421e-02
    z[7,6,6]  R1962     6.3529871404170990e-03
    z[7,6,6]  R1963     2.9483121633529663e-01
    z[7,6,6]  R1964     2.6193094253540039e-01
    z[7,6,6]  R1965     -9.3920081853866577e-02
    z[7,6,6]  R1966     -1.7072544991970062e-01
    z[7,6,6]  R1967     2.5153619050979614e-01
    z[7,6,6]  R1968     2.4349084123969078e-02
    z[7,6,6]  R1969     -7.0670828223228455e-02
    z[7,6,6]  R1970     -4.9534910917282104e-01
    z[7,6,6]  R1971     -5.1896870136260986e-01
    z[7,6,6]  R1972     -2.1348045766353607e-01
    z[7,6,6]  R1973     6.5155699849128723e-02
    z[7,6,6]  R1974     -3.8442060351371765e-01
    z[7,6,6]  R1975     -3.6522826552391052e-01
    z[7,6,6]  R1976     -5.3321099281311035e-01
    z[7,6,6]  R1977     -4.1150754690170288e-01
    z[7,6,6]  R1978     -2.2725136578083038e-01
    z[7,6,6]  R1979     -4.4010943174362183e-01
    z[7,6,6]  R1980     4.9814966320991516e-01
    z[7,6,6]  R1981     -5.5191016197204590e-01
    z[7,6,6]  R1982     5.1421072334051132e-02
    z[7,6,6]  R1983     -3.4445410966873169e-01
    z[7,6,6]  R1984     -5.1716709136962891e-01
    z[7,6,6]  R1985     -5.8411377668380737e-01
    z[7,6,6]  R1986     -1.1579652875661850e-01
    z[7,6,6]  R1987     -1.8633359670639038e-01
    z[7,6,6]  R1988     5.3940999507904053e-01
    z[7,6,6]  R1989     -1.0724445432424545e-01
    z[7,6,6]  R1990     1.7643353343009949e-01
    z[7,6,6]  R1991     3.0668148398399353e-01
    z[7,6,6]  R1992     -1.1719116568565369e-01
    z[7,6,6]  R1993     3.0471768975257874e-01
    z[7,6,6]  R1994     -2.2337767481803894e-01
    z[7,6,6]  R1995     1.4146524667739868e-01
    z[7,6,6]  R1996     1.2998740375041962e-01
    z[7,6,6]  R1997     -1.1390867084264755e-01
    z[7,6,6]  R1998     1.6196960210800171e-01
    z[7,6,6]  R1999     1.6091284155845642e-01
    z[7,6,6]  R2000     -1.6700872778892517e-01
    z[7,6,6]  R2001     -3.6162579059600830e-01
    z[7,6,6]  R2002     -1.2262653559446335e-01
    z[7,6,6]  R2003     -2.0207743346691132e-01
    z[7,6,6]  R2004     -4.9447190761566162e-01
    z[7,6,6]  R2005     -0.0311052855104208
    z[7,6,6]  R2006     -1.8951158225536346e-01
    z[7,6,6]  R2007     -2.0190356671810150e-01
    z[7,6,6]  R2008     -1.4829598367214203e-01
    z[7,6,6]  R2009     1.8061019480228424e-02
    z[7,6,6]  R2010     9.9628299474716187e-02
    z[7,6,6]  R2011     2.3286198079586029e-01
    z[7,6,6]  R2012     -6.2215197831392288e-02
    z[7,6,6]  R2013     3.0210867524147034e-01
    z[7,6,6]  R2014     3.2108891010284424e-01
    z[7,6,6]  R2015     -2.5963318347930908e-01
    z[7,6,6]  R2016     3.4084182232618332e-02
    z[7,6,6]  R2017     1.3686721026897430e-01
    z[7,6,6]  R2018     2.8160536289215088e-01
    z[7,6,6]  R2019     3.3674296736717224e-01
    z[7,6,6]  R2020     -1.2277911603450775e-01
    z[7,6,6]  R2021     -3.5015437752008438e-02
    z[7,6,6]  R2022     -3.1789663434028625e-01
    z[7,6,6]  R2023     -4.2904266715049744e-01
    z[7,6,6]  R2024     1.8472722172737122e-01
    z[7,6,6]  R2025     3.4748157858848572e-01
    z[7,6,6]  R2026     -5.6928563117980957e-01
    z[7,6,6]  R2027     -4.9426713585853577e-01
    z[7,6,6]  R2028     1.2183386087417603e-01
    z[7,6,6]  R2029     -2.6246858760714531e-02
    z[7,6,6]  R2030     0.182825967669487
    z[7,6,6]  R2031     0.10972910374403
    z[7,6,6]  R2032     -8.3172051236033440e-03
    z[7,6,6]  R2033     -0.00973269622772932
    z[7,6,6]  R2034     2.7663874626159668e-01
    z[7,6,6]  R2035     -2.4992136657238007e-01
    z[7,6,6]  R2036     6.2270566821098328e-02
    z[7,6,6]  R2037     -2.2644624114036560e-01
    z[7,6,6]  R2038     -1.0564853996038437e-01
    z[7,6,6]  R2039     9.0046428143978119e-02
    z[7,6,6]  R2040     2.4305772781372070e-01
    z[7,6,6]  R2041     -3.6850892007350922e-02
    z[7,6,6]  R2042     -1.3209588825702667e-01
    z[7,6,6]  R2043     2.0862698554992676e-01
    z[7,6,6]  R2044     2.3921461403369904e-01
    z[7,6,6]  R2045     1.3593156635761261e-01
    z[7,6,6]  R2046     -2.0570243895053864e-01
    z[7,6,6]  R2047     2.8194564580917358e-01
    z[7,6,6]  R2048     3.9390745759010315e-01
    z[7,6,6]  R2049     5.0124108791351318e-01
    z[7,6,6]  R2050     1.9057209789752960e-01
    z[7,6,6]  R2051     -2.1545395255088806e-01
    z[7,6,6]  R2052     1.2802718579769135e-01
    z[7,6,6]  R2053     -9.1979824006557465e-02
    z[7,6,6]  R2054     -1.4083835482597351e-01
    z[7,6,6]  R2055     1.5833540260791779e-01
    z[7,6,6]  R2056     -2.6506617665290833e-01
    z[7,6,6]  R2057     -0.0858563557267189
    z[7,6,6]  R2058     -8.7235406041145325e-02
    z[7,6,6]  R2059     -4.4462716579437256e-01
    z[7,8,0]  R65       -1
    z[7,8,0]  R74       1
    z[7,8,0]  R2114     -1
    z[7,8,0]  R2115     1
    z[7,8,0]  R2128     -4.1742384433746338e-01
    z[7,8,0]  R2129     -2.5374817848205566e-01
    z[7,8,0]  R2130     2.9268631339073181e-01
    z[7,8,0]  R2131     -2.8985580801963806e-01
    z[7,8,0]  R2132     -2.7387583255767822e-01
    z[7,8,0]  R2133     -9.6661873161792755e-02
    z[7,8,0]  R2134     -8.0902941524982452e-02
    z[7,8,0]  R2135     1.9217935204505920e-01
    z[7,8,0]  R2136     -2.7157601714134216e-01
    z[7,8,0]  R2137     -3.7019826471805573e-02
    z[7,8,0]  R2138     -5.1463431119918823e-01
    z[7,8,0]  R2139     -7.5788277387619019e-01
    z[7,8,0]  R2140     -6.9060385227203369e-01
    z[7,8,0]  R2141     -2.5572237372398376e-01
    z[7,8,0]  R2142     0.598052442073822
    z[7,8,0]  R2143     -6.2403172254562378e-01
    z[7,8,0]  R2144     -5.9778302907943726e-01
    z[7,8,0]  R2145     -3.7376496195793152e-01
    z[7,8,0]  R2146     -6.5007936954498291e-01
    z[7,8,0]  R2147     -0.4415283203125
    z[7,8,0]  R2148     4.9268159270286560e-01
    z[7,8,0]  R2149     3.1667700409889221e-01
    z[7,8,0]  R2150     7.0376896858215332e-01
    z[7,8,0]  R2151     1.9855907559394836e-01
    z[7,8,0]  R2152     5.9077608585357666e-01
    z[7,8,0]  R2153     6.7369127273559570e-01
    z[7,8,0]  R2154     4.7348472476005554e-01
    z[7,8,0]  R2155     4.4909808039665222e-01
    z[7,8,0]  R2156     3.1746962666511536e-01
    z[7,8,0]  R2157     5.1115787029266357e-01
    z[7,8,0]  R2158     -4.1719296574592590e-01
    z[7,8,0]  R2159     0.542195200920105
    z[7,8,0]  R2160     6.3908779621124268e-01
    z[7,8,0]  R2161     5.2245211601257324e-01
    z[7,8,0]  R2162     7.3084539175033569e-01
    z[7,8,0]  R2163     2.4125267565250397e-01
    z[7,8,0]  R2164     5.0219660997390747e-01
    z[7,8,0]  R2165     1.3187961280345917e-01
    z[7,8,0]  R2166     -1.3883483409881592e-01
    z[7,8,0]  R2167     2.9321116209030151e-01
    z[7,8,0]  R2168     -2.5262609124183655e-01
    z[7,8,0]  R2169     -8.2698212936520576e-03
    z[7,8,0]  R2170     6.6153752803802490e-01
    z[7,8,0]  R2171     6.0601574182510376e-01
    z[7,8,0]  R2172     5.0554829835891724e-01
    z[7,8,0]  R2173     2.1321113407611847e-01
    z[7,8,0]  R2174     1.7096064984798431e-01
    z[7,8,0]  R2175     3.4136199951171875e-01
    z[7,8,0]  R2176     6.2890779972076416e-01
    z[7,8,0]  R2177     0.561506986618042
    z[7,8,0]  R2178     2.7783498167991638e-01
    z[7,8,0]  R2179     3.9151710271835327e-01
    z[7,8,0]  R2180     4.8872488737106323e-01
    z[7,8,0]  R2181     5.9827280044555664e-01
    z[7,8,0]  R2182     5.3189265727996826e-01
    z[7,8,0]  R2183     -8.0244131386280060e-02
    z[7,8,0]  R2184     6.1898368597030640e-01
    z[7,8,0]  R2185     -1.2636521458625793e-01
    z[7,8,0]  R2186     4.7545289993286133e-01
    z[7,8,0]  R2187     -1.8992806971073151e-01
    z[7,8,0]  R2188     -4.4662123918533325e-01
    z[7,8,0]  R2189     7.5933212041854858e-01
    z[7,8,0]  R2190     1.4641419053077698e-01
    z[7,8,0]  R2191     9.0601153671741486e-02
    z[7,8,0]  R2192     1.4350548386573792e-01
    z[7,8,0]  R2193     4.1983413696289062e-01
    z[7,8,0]  R2194     4.4088366627693176e-01
    z[7,8,0]  R2195     -5.1574579629232176e-07
    z[7,8,0]  R2196     3.0272185802459717e-01
    z[7,8,0]  R2197     2.3438142240047455e-01
    z[7,8,0]  R2198     -1.2852829694747925e-01
    z[7,8,0]  R2199     -0.0594470389187336
    z[7,8,0]  R2200     -6.5190011262893677e-01
    z[7,8,0]  R2201     1.6146008670330048e-01
    z[7,8,0]  R2202     -9.2804804444313049e-02
    z[7,8,0]  R2203     -6.5555781126022339e-01
    z[7,8,0]  R2204     -7.3388135433197021e-01
    z[7,8,0]  R2205     -7.4394792318344116e-01
    z[7,8,0]  R2206     -8.0741649866104126e-01
    z[7,8,0]  R2207     -8.0002427101135254e-01
    z[7,8,0]  R2208     -3.9988499134778976e-02
    z[7,8,0]  R2209     2.7581200003623962e-01
    z[7,8,0]  R2210     2.8731355071067810e-01
    z[7,8,0]  R2211     0.05734858289361
    z[7,8,0]  R2212     4.4874057173728943e-01
    z[7,8,0]  R2213     7.2059106826782227e-01
    z[7,8,0]  R2214     6.0280710458755493e-01
    z[7,8,0]  R2215     7.8249531984329224e-01
    z[7,8,0]  R2216     5.7844305038452148e-01
    z[7,8,0]  R2217     6.1135005950927734e-01
    z[7,8,0]  R2218     6.1014586687088013e-01
    z[7,8,0]  R2219     -3.5574698448181152e-01
    z[7,8,0]  R2220     2.7639642357826233e-01
    z[7,8,0]  R2221     -2.6914203166961670e-01
    z[7,8,0]  R2222     4.6433284878730774e-01
    z[7,8,0]  R2223     -0.853218138217926
    z[7,8,0]  R2224     2.8995686769485474e-01
    z[7,8,0]  R2225     3.1004312634468079e-01
    z[7,8,0]  R2226     -2.2425624728202820e-01
    z[7,8,0]  R2227     1.5226773917675018e-01
    z[7,8,0]  R2228     -1.2880882620811462e-01
    z[7,8,0]  R2229     2.9781904071569443e-02
    z[7,8,0]  R2230     -2.7811175584793091e-01
    z[7,8,0]  R2231     -2.7319031953811646e-01
    z[7,8,0]  R2232     -0.69287109375
    z[7,8,0]  R2233     3.6316105723381042e-01
    z[7,8,0]  R2234     3.6248227953910828e-01
    z[7,8,0]  R2235     3.1406599283218384e-01
    z[7,8,0]  R2236     2.3585869371891022e-01
    z[7,8,0]  R2237     3.6995249986648560e-01
    z[7,8,0]  R2238     -4.2968600988388062e-02
    z[7,8,0]  R2239     0.402852863073349
    z[7,8,0]  R2240     4.1930586099624634e-01
    z[7,8,0]  R2241     3.7883815169334412e-01
    z[7,8,0]  R2242     -3.2579079270362854e-02
    z[7,8,0]  R2243     -7.9975659027695656e-03
    z[7,8,0]  R2244     5.0608873367309570e-01
    z[7,8,0]  R2245     3.5544195771217346e-01
    z[7,8,0]  R2246     3.9803826808929443e-01
    z[7,8,0]  R2247     4.8468944430351257e-01
    z[7,8,1]  R66       -1
    z[7,8,1]  R75       1
    z[7,8,1]  R2116     -1
    z[7,8,1]  R2117     1
    z[7,8,1]  R2128     -7.0349895954132080e-01
    z[7,8,1]  R2129     -7.6073330640792847e-01
    z[7,8,1]  R2130     -5.8580768108367920e-01
    z[7,8,1]  R2131     -0.550881564617157
    z[7,8,1]  R2132     -4.3758830428123474e-01
    z[7,8,1]  R2133     -5.0719237327575684e-01
    z[7,8,1]  R2134     -0.727531909942627
    z[7,8,1]  R2135     -6.8581086397171021e-01
    z[7,8,1]  R2136     -5.8624863624572754e-01
    z[7,8,1]  R2137     -5.6832879781723022e-01
    z[7,8,1]  R2138     8.1121939420700073e-01
    z[7,8,1]  R2139     5.9868144989013672e-01
    z[7,8,1]  R2140     0.481892466545105
    z[7,8,1]  R2141     8.4463369846343994e-01
    z[7,8,1]  R2142     5.9536057710647583e-01
    z[7,8,1]  R2143     6.6302919387817383e-01
    z[7,8,1]  R2144     0.513116717338562
    z[7,8,1]  R2145     8.2301336526870728e-01
    z[7,8,1]  R2146     5.3453516960144043e-01
    z[7,8,1]  R2147     7.6250523328781128e-01
    z[7,8,1]  R2148     6.1349582672119141e-01
    z[7,8,1]  R2149     3.7861829996109009e-01
    z[7,8,1]  R2150     2.5431987643241882e-01
    z[7,8,1]  R2151     0.417542427778244
    z[7,8,1]  R2152     1.4204722642898560e-01
    z[7,8,1]  R2153     3.9823630452156067e-01
    z[7,8,1]  R2154     0.381229043006897
    z[7,8,1]  R2155     3.3481189608573914e-01
    z[7,8,1]  R2156     3.3361795544624329e-01
    z[7,8,1]  R2157     3.3566546440124512e-01
    z[7,8,1]  R2158     5.5710178613662720e-01
    z[7,8,1]  R2159     4.2706665396690369e-01
    z[7,8,1]  R2160     2.6934564113616943e-01
    z[7,8,1]  R2161     2.0655032992362976e-01
    z[7,8,1]  R2162     0.293347030878067
    z[7,8,1]  R2163     5.4523384571075439e-01
    z[7,8,1]  R2164     0.469305157661438
    z[7,8,1]  R2165     2.6761990785598755e-01
    z[7,8,1]  R2166     2.3617841303348541e-01
    z[7,8,1]  R2167     6.4018809795379639e-01
    z[7,8,1]  R2168     6.9004052877426147e-01
    z[7,8,1]  R2169     4.9356538057327271e-01
    z[7,8,1]  R2170     3.3252444863319397e-01
    z[7,8,1]  R2171     3.8503104448318481e-01
    z[7,8,1]  R2172     6.2245595455169678e-01
    z[7,8,1]  R2173     6.7525357007980347e-02
    z[7,8,1]  R2174     3.8494072854518890e-02
    z[7,8,1]  R2175     6.1756855249404907e-01
    z[7,8,1]  R2176     3.2897058129310608e-01
    z[7,8,1]  R2177     3.0310752987861633e-01
    z[7,8,1]  R2178     0.330127477645874
    z[7,8,1]  R2179     2.0856209099292755e-01
    z[7,8,1]  R2180     7.3431402444839478e-01
    z[7,8,1]  R2181     2.1689492464065552e-01
    z[7,8,1]  R2182     0.392946720123291
    z[7,8,1]  R2183     3.2396170496940613e-01
    z[7,8,1]  R2184     3.3498492836952209e-01
    z[7,8,1]  R2185     -0.0694834440946579
    z[7,8,1]  R2186     3.7733837962150574e-01
    z[7,8,1]  R2187     2.0810633897781372e-02
    z[7,8,1]  R2188     6.7973607778549194e-01
    z[7,8,1]  R2189     2.9732012748718262e-01
    z[7,8,1]  R2190     3.7649261951446533e-01
    z[7,8,1]  R2191     3.6698821187019348e-01
    z[7,8,1]  R2192     5.4701352491974831e-03
    z[7,8,1]  R2193     4.3893152475357056e-01
    z[7,8,1]  R2194     0.687838613986969
    z[7,8,1]  R2195     3.1641638278961182e-01
    z[7,8,1]  R2196     -0.440679132938385
    z[7,8,1]  R2197     -4.1323426365852356e-01
    z[7,8,1]  R2198     1.1826018244028091e-01
    z[7,8,1]  R2199     8.9327402412891388e-02
    z[7,8,1]  R2200     -0.530619740486145
    z[7,8,1]  R2201     -1.0871769627556205e-03
    z[7,8,1]  R2202     8.6960613727569580e-02
    z[7,8,1]  R2203     -5.6294459104537964e-01
    z[7,8,1]  R2204     -5.4096710681915283e-01
    z[7,8,1]  R2205     -3.8441410660743713e-01
    z[7,8,1]  R2206     1.0363811999559402e-01
    z[7,8,1]  R2207     5.5503904819488525e-02
    z[7,8,1]  R2208     2.9511308670043945e-01
    z[7,8,1]  R2209     1.5450754761695862e-01
    z[7,8,1]  R2210     1.7042127251625061e-01
    z[7,8,1]  R2211     2.0879945158958435e-01
    z[7,8,1]  R2212     3.2493349909782410e-01
    z[7,8,1]  R2213     3.6775767803192139e-01
    z[7,8,1]  R2214     0.314726322889328
    z[7,8,1]  R2215     5.4211676120758057e-01
    z[7,8,1]  R2216     2.5673910975456238e-01
    z[7,8,1]  R2217     2.7103403210639954e-01
    z[7,8,1]  R2218     3.7999680638313293e-01
    z[7,8,1]  R2219     5.8790612220764160e-01
    z[7,8,1]  R2220     5.4605388641357422e-01
    z[7,8,1]  R2221     4.7140055894851685e-01
    z[7,8,1]  R2222     0.66666579246521
    z[7,8,1]  R2223     1.8648330867290497e-01
    z[7,8,1]  R2224     -1.8866054713726044e-01
    z[7,8,1]  R2225     -2.3718793690204620e-01
    z[7,8,1]  R2226     4.1518858075141907e-01
    z[7,8,1]  R2227     -3.0725511908531189e-01
    z[7,8,1]  R2228     3.3868480473756790e-02
    z[7,8,1]  R2229     0.454218327999115
    z[7,8,1]  R2230     -2.0671127364039421e-02
    z[7,8,1]  R2231     -4.8183876276016235e-01
    z[7,8,1]  R2232     2.5234025716781616e-01
    z[7,8,1]  R2233     -1.8473502993583679e-01
    z[7,8,1]  R2234     -3.3799788355827332e-01
    z[7,8,1]  R2235     -5.0157308578491211e-01
    z[7,8,1]  R2236     -5.0875627994537354e-01
    z[7,8,1]  R2237     -4.6851876378059387e-01
    z[7,8,1]  R2238     2.0195086300373077e-01
    z[7,8,1]  R2239     -2.4059966206550598e-01
    z[7,8,1]  R2240     1.0994620621204376e-01
    z[7,8,1]  R2241     -2.4736025929450989e-01
    z[7,8,1]  R2242     -1.8016017973423004e-01
    z[7,8,1]  R2243     -2.6322522759437561e-01
    z[7,8,1]  R2244     -0.670713484287262
    z[7,8,1]  R2245     -8.1953620910644531e-01
    z[7,8,1]  R2246     -6.3240230083465576e-01
    z[7,8,1]  R2247     -7.2972595691680908e-01
    z[7,8,2]  R67       -1
    z[7,8,2]  R76       1
    z[7,8,2]  R2118     -1
    z[7,8,2]  R2119     1
    z[7,8,2]  R2128     -3.7101060152053833e-02
    z[7,8,2]  R2129     3.2610440254211426e-01
    z[7,8,2]  R2130     4.3813946843147278e-01
    z[7,8,2]  R2131     4.1852509975433350e-01
    z[7,8,2]  R2132     2.9723653197288513e-01
    z[7,8,2]  R2133     3.8061714172363281e-01
    z[7,8,2]  R2134     2.5127744302153587e-02
    z[7,8,2]  R2135     -1.0600391030311584e-01
    z[7,8,2]  R2136     -1.6638176143169403e-01
    z[7,8,2]  R2137     -5.9659677743911743e-01
    z[7,8,2]  R2138     1.8641431629657745e-01
    z[7,8,2]  R2139     -2.8258139267563820e-02
    z[7,8,2]  R2140     4.6208903193473816e-01
    z[7,8,2]  R2141     3.3079397678375244e-01
    z[7,8,2]  R2142     -4.5337709784507751e-01
    z[7,8,2]  R2143     -3.7219825387001038e-01
    z[7,8,2]  R2144     2.0643375813961029e-01
    z[7,8,2]  R2145     -2.2771295905113220e-01
    z[7,8,2]  R2146     1.4864406548440456e-02
    z[7,8,2]  R2147     -3.4367975592613220e-01
    z[7,8,2]  R2148     1.2198777496814728e-01
    z[7,8,2]  R2149     -1.7813597619533539e-01
    z[7,8,2]  R2150     1.8026264011859894e-01
    z[7,8,2]  R2151     -5.3825759887695312e-01
    z[7,8,2]  R2152     -1.8358139693737030e-01
    z[7,8,2]  R2153     1.8783777952194214e-01
    z[7,8,2]  R2154     1.0380639135837555e-01
    z[7,8,2]  R2155     8.4439389407634735e-02
    z[7,8,2]  R2156     -1.6782304644584656e-01
    z[7,8,2]  R2157     -8.1393130123615265e-02
    z[7,8,2]  R2158     1.0979621671140194e-02
    z[7,8,2]  R2159     -1.5255357325077057e-01
    z[7,8,2]  R2160     -1.8891420960426331e-01
    z[7,8,2]  R2161     -2.2009547054767609e-01
    z[7,8,2]  R2162     -2.3043116554617882e-02
    z[7,8,2]  R2163     -4.8352709412574768e-01
    z[7,8,2]  R2164     2.6932433247566223e-01
    z[7,8,2]  R2165     -8.2781696319580078e-01
    z[7,8,2]  R2166     -4.9663653969764709e-01
    z[7,8,2]  R2167     2.2295682132244110e-01
    z[7,8,2]  R2168     -4.5636307448148727e-02
    z[7,8,2]  R2169     -5.5839467048645020e-01
    z[7,8,2]  R2170     -8.6928181350231171e-02
    z[7,8,2]  R2171     -4.7206360846757889e-02
    z[7,8,2]  R2172     2.7449253201484680e-01
    z[7,8,2]  R2173     -7.0911628007888794e-01
    z[7,8,2]  R2174     -8.0570483207702637e-01
    z[7,8,2]  R2175     -4.4521424919366837e-02
    z[7,8,2]  R2176     2.3619423806667328e-01
    z[7,8,2]  R2177     -5.7745543308556080e-03
    z[7,8,2]  R2178     -7.3673325777053833e-01
    z[7,8,2]  R2179     -5.7246792316436768e-01
    z[7,8,2]  R2180     1.7531728744506836e-01
    z[7,8,2]  R2181     -3.1774231791496277e-01
    z[7,8,2]  R2182     -1.6345228999853134e-02
    z[7,8,2]  R2183     -5.2697920799255371e-01
    z[7,8,2]  R2184     3.7351274490356445e-01
    z[7,8,2]  R2185     2.5668165180832148e-03
    z[7,8,2]  R2186     -4.7355074435472488e-02
    z[7,8,2]  R2187     2.9300722479820251e-01
    z[7,8,2]  R2188     1.2888029217720032e-01
    z[7,8,2]  R2189     -1.2716868519783020e-01
    z[7,8,2]  R2190     -3.5650515556335449e-01
    z[7,8,2]  R2191     -0.820137083530426
    z[7,8,2]  R2192     -7.3708117008209229e-01
    z[7,8,2]  R2193     -1.4826372265815735e-01
    z[7,8,2]  R2194     2.5509911775588989e-01
    z[7,8,2]  R2195     -5.1989001035690308e-01
    z[7,8,2]  R2196     -3.2574686408042908e-01
    z[7,8,2]  R2197     -1.7981612682342529e-01
    z[7,8,2]  R2198     -4.4401079416275024e-01
    z[7,8,2]  R2199     -3.2758188247680664e-01
    z[7,8,2]  R2200     2.2153076529502869e-01
    z[7,8,2]  R2201     -0.675586462020874
    z[7,8,2]  R2202     -6.5137469768524170e-01
    z[7,8,2]  R2203     1.7457915842533112e-01
    z[7,8,2]  R2204     4.3856389820575714e-02
    z[7,8,2]  R2205     -2.6346400380134583e-02
    z[7,8,2]  R2206     -2.4760743975639343e-01
    z[7,8,2]  R2207     -4.2816975712776184e-01
    z[7,8,2]  R2208     -3.7379637360572815e-01
    z[7,8,2]  R2209     -1.9351994991302490e-01
    z[7,8,2]  R2210     -2.0499213039875031e-01
    z[7,8,2]  R2211     -1.1064240336418152e-01
    z[7,8,2]  R2212     -3.9540970325469971e-01
    z[7,8,2]  R2213     -5.2497762441635132e-01
    z[7,8,2]  R2214     2.4224289227277040e-03
    z[7,8,2]  R2215     -0.0970020443201065
    z[7,8,2]  R2216     -1.9662268459796906e-01
    z[7,8,2]  R2217     -2.8607437014579773e-01
    z[7,8,2]  R2218     -5.1499092578887939e-01
    z[7,8,2]  R2219     -4.9329277127981186e-02
    z[7,8,2]  R2220     1.0384587198495865e-01
    z[7,8,2]  R2221     4.3746861815452576e-01
    z[7,8,2]  R2222     4.8087587952613831e-01
    z[7,8,2]  R2223     -2.3073922097682953e-01
    z[7,8,2]  R2224     -3.6082801222801208e-01
    z[7,8,2]  R2225     -3.0009731650352478e-01
    z[7,8,2]  R2226     0.562061607837677
    z[7,8,2]  R2227     -5.3335064649581909e-01
    z[7,8,2]  R2228     -8.9149087667465210e-01
    z[7,8,2]  R2229     0.189592182636261
    z[7,8,2]  R2230     -5.0809472799301147e-01
    z[7,8,2]  R2231     -5.5949020385742188e-01
    z[7,8,2]  R2232     1.5865002572536469e-01
    z[7,8,2]  R2233     -2.4356766045093536e-01
    z[7,8,2]  R2234     -4.4351139664649963e-01
    z[7,8,2]  R2235     5.8374601602554321e-01
    z[7,8,2]  R2236     5.8935302495956421e-01
    z[7,8,2]  R2237     6.2763148546218872e-01
    z[7,8,2]  R2238     -4.6040698885917664e-01
    z[7,8,2]  R2239     -6.3620215654373169e-01
    z[7,8,2]  R2240     -9.9123053252696991e-02
    z[7,8,2]  R2241     -2.5601658225059509e-01
    z[7,8,2]  R2242     7.2802132368087769e-01
    z[7,8,2]  R2243     6.6893249750137329e-01
    z[7,8,2]  R2244     2.6052811741828918e-01
    z[7,8,2]  R2245     2.3623399436473846e-02
    z[7,8,2]  R2246     7.3987804353237152e-02
    z[7,8,2]  R2247     7.5788281857967377e-02
    z[7,8,3]  R68       -1
    z[7,8,3]  R77       1
    z[7,8,3]  R2120     -1
    z[7,8,3]  R2121     1
    z[7,8,3]  R2128     -2.1796271204948425e-01
    z[7,8,3]  R2129     -3.2439276576042175e-01
    z[7,8,3]  R2130     -5.6626987457275391e-01
    z[7,8,3]  R2131     -0.48638716340065
    z[7,8,3]  R2132     -4.4167909026145935e-01
    z[7,8,3]  R2133     -2.3436361551284790e-01
    z[7,8,3]  R2134     -2.6952078938484192e-01
    z[7,8,3]  R2135     -3.3212468028068542e-01
    z[7,8,3]  R2136     -2.0623359084129333e-01
    z[7,8,3]  R2137     -4.9054530262947083e-01
    z[7,8,3]  R2138     -1.3675317168235779e-01
    z[7,8,3]  R2139     1.4900295436382294e-01
    z[7,8,3]  R2140     -6.4627096056938171e-02
    z[7,8,3]  R2141     1.0589123517274857e-01
    z[7,8,3]  R2142     -6.5986894071102142e-02
    z[7,8,3]  R2143     6.7552458494901657e-03
    z[7,8,3]  R2144     4.8386582732200623e-01
    z[7,8,3]  R2145     2.5144720077514648e-01
    z[7,8,3]  R2146     3.4883657097816467e-01
    z[7,8,3]  R2147     -9.3822255730628967e-02
    z[7,8,3]  R2148     1.0117420926690102e-02
    z[7,8,3]  R2149     4.2367298156023026e-02
    z[7,8,3]  R2150     5.7666087150573730e-01
    z[7,8,3]  R2151     -3.8918060064315796e-01
    z[7,8,3]  R2152     -1.8717030063271523e-02
    z[7,8,3]  R2153     -2.6123163104057312e-01
    z[7,8,3]  R2154     3.8880711793899536e-01
    z[7,8,3]  R2155     1.2805530428886414e-01
    z[7,8,3]  R2156     -2.7015671133995056e-01
    z[7,8,3]  R2157     4.7361102700233459e-01
    z[7,8,3]  R2158     3.4452080726623535e-01
    z[7,8,3]  R2159     0.437370240688324
    z[7,8,3]  R2160     -2.0321829617023468e-01
    z[7,8,3]  R2161     3.1056657433509827e-01
    z[7,8,3]  R2162     -6.8546503782272339e-02
    z[7,8,3]  R2163     1.1138024926185608e-01
    z[7,8,3]  R2164     0.0956350564956665
    z[7,8,3]  R2165     -3.4429600834846497e-01
    z[7,8,3]  R2166     -3.4128466248512268e-01
    z[7,8,3]  R2167     3.4088918566703796e-01
    z[7,8,3]  R2168     1.0349992662668228e-01
    z[7,8,3]  R2169     -2.3556242883205414e-01
    z[7,8,3]  R2170     4.5910966396331787e-01
    z[7,8,3]  R2171     2.2986364364624023e-01
    z[7,8,3]  R2172     4.1589993238449097e-01
    z[7,8,3]  R2173     -3.8168314844369888e-02
    z[7,8,3]  R2174     1.6509534791111946e-02
    z[7,8,3]  R2175     -5.8023923635482788e-01
    z[7,8,3]  R2176     4.0125700831413269e-01
    z[7,8,3]  R2177     5.0967288017272949e-01
    z[7,8,3]  R2178     -1.3190989196300507e-01
    z[7,8,3]  R2179     -2.7765738964080811e-01
    z[7,8,3]  R2180     2.5022971630096436e-01
    z[7,8,3]  R2181     1.6130031645298004e-01
    z[7,8,3]  R2182     1.4988344162702560e-02
    z[7,8,3]  R2183     -2.6825568079948425e-01
    z[7,8,3]  R2184     3.1657463312149048e-01
    z[7,8,3]  R2185     8.1094855070114136e-01
    z[7,8,3]  R2186     -0.509924590587616
    z[7,8,3]  R2187     7.0410865545272827e-01
    z[7,8,3]  R2188     5.1008999347686768e-01
    z[7,8,3]  R2189     9.8537676036357880e-02
    z[7,8,3]  R2190     -5.3781199455261230e-01
    z[7,8,3]  R2191     -2.5534653663635254e-01
    z[7,8,3]  R2192     -4.7703534364700317e-01
    z[7,8,3]  R2193     -3.2695853710174561e-01
    z[7,8,3]  R2194     -0.295698344707489
    z[7,8,3]  R2195     -7.7478241920471191e-01
    z[7,8,3]  R2196     6.7410397529602051e-01
    z[7,8,3]  R2197     0.667834460735321
    z[7,8,3]  R2198     3.7399226427078247e-01
    z[7,8,3]  R2199     8.4463542699813843e-01
    z[7,8,3]  R2200     3.7432754039764404e-01
    z[7,8,3]  R2201     -2.0353691279888153e-01
    z[7,8,3]  R2202     -5.0228089094161987e-01
    z[7,8,3]  R2203     6.9852888584136963e-02
    z[7,8,3]  R2204     -1.5249375998973846e-01
    z[7,8,3]  R2205     3.0748987197875977e-01
    z[7,8,3]  R2206     4.4161000847816467e-01
    z[7,8,3]  R2207     2.7727040648460388e-01
    z[7,8,3]  R2208     -4.6838602423667908e-01
    z[7,8,3]  R2209     2.8910410404205322e-01
    z[7,8,3]  R2210     1.7768730223178864e-01
    z[7,8,3]  R2211     -7.2494372725486755e-02
    z[7,8,3]  R2212     1.2226977199316025e-01
    z[7,8,3]  R2213     -1.2317145615816116e-01
    z[7,8,3]  R2214     -6.4032179117202759e-01
    z[7,8,3]  R2215     -2.4975667893886566e-01
    z[7,8,3]  R2216     -2.7408912777900696e-01
    z[7,8,3]  R2217     -5.5452466011047363e-01
    z[7,8,3]  R2218     1.2485326826572418e-01
    z[7,8,3]  R2219     -6.5923802554607391e-02
    z[7,8,3]  R2220     2.4701729416847229e-01
    z[7,8,3]  R2221     2.1766215562820435e-01
    z[7,8,3]  R2222     5.1282446831464767e-02
    z[7,8,3]  R2223     -1.2317837774753571e-01
    z[7,8,3]  R2224     -6.5467965602874756e-01
    z[7,8,3]  R2225     -6.2769198417663574e-01
    z[7,8,3]  R2226     -2.1077285706996918e-01
    z[7,8,3]  R2227     -6.5159630775451660e-01
    z[7,8,3]  R2228     2.6033643633127213e-02
    z[7,8,3]  R2229     5.2104723453521729e-01
    z[7,8,3]  R2230     1.2494331598281860e-01
    z[7,8,3]  R2231     4.4211512804031372e-01
    z[7,8,3]  R2232     2.0982641726732254e-02
    z[7,8,3]  R2233     -7.5801765918731689e-01
    z[7,8,3]  R2234     -6.4669466018676758e-01
    z[7,8,3]  R2235     -3.5471069812774658e-01
    z[7,8,3]  R2236     -2.7713820338249207e-01
    z[7,8,3]  R2237     -0.333706796169281
    z[7,8,3]  R2238     -2.9114505648612976e-01
    z[7,8,3]  R2239     -0.43654665350914
    z[7,8,3]  R2240     -1.5885820984840393e-01
    z[7,8,3]  R2241     6.0308102518320084e-02
    z[7,8,3]  R2242     -6.2654095888137817e-01
    z[7,8,3]  R2243     -0.657532811164856
    z[7,8,3]  R2244     2.5557219982147217e-01
    z[7,8,3]  R2245     3.0942326411604881e-02
    z[7,8,3]  R2246     1.4529527723789215e-01
    z[7,8,3]  R2247     1.4006929099559784e-01
    z[7,8,4]  R69       -1
    z[7,8,4]  R78       1
    z[7,8,4]  R2122     -1
    z[7,8,4]  R2123     1
    z[7,8,4]  R2128     -3.4477835893630981e-01
    z[7,8,4]  R2129     -9.4077989459037781e-02
    z[7,8,4]  R2130     1.8941025435924530e-01
    z[7,8,4]  R2131     1.7641784250736237e-01
    z[7,8,4]  R2132     6.8979769945144653e-02
    z[7,8,4]  R2133     -3.9085236191749573e-01
    z[7,8,4]  R2134     5.9848743677139282e-01
    z[7,8,4]  R2135     1.4117564260959625e-01
    z[7,8,4]  R2136     5.1248639822006226e-01
    z[7,8,4]  R2137     1.1978673934936523e-01
    z[7,8,4]  R2138     0.097610242664814
    z[7,8,4]  R2139     -1.5691386163234711e-01
    z[7,8,4]  R2140     -1.3203912973403931e-01
    z[7,8,4]  R2141     8.7045609951019287e-02
    z[7,8,4]  R2142     2.8269633185118437e-03
    z[7,8,4]  R2143     -7.5232565402984619e-02
    z[7,8,4]  R2144     3.9024170488119125e-02
    z[7,8,4]  R2145     -5.6769125163555145e-02
    z[7,8,4]  R2146     -1.8793129920959473e-01
    z[7,8,4]  R2147     1.0737630724906921e-01
    z[7,8,4]  R2148     3.2515057921409607e-01
    z[7,8,4]  R2149     -5.4684060811996460e-01
    z[7,8,4]  R2150     -1.5085913240909576e-01
    z[7,8,4]  R2151     1.4507076144218445e-01
    z[7,8,4]  R2152     6.4669072628021240e-02
    z[7,8,4]  R2153     1.7920480668544769e-01
    z[7,8,4]  R2154     -2.2350139915943146e-01
    z[7,8,4]  R2155     4.9102181196212769e-01
    z[7,8,4]  R2156     4.8082631826400757e-01
    z[7,8,4]  R2157     3.9034748077392578e-01
    z[7,8,4]  R2158     -3.8204270601272583e-01
    z[7,8,4]  R2159     -6.4795307815074921e-02
    z[7,8,4]  R2160     3.1710690259933472e-01
    z[7,8,4]  R2161     -1.7232243716716766e-01
    z[7,8,4]  R2162     1.1811833083629608e-01
    z[7,8,4]  R2163     -2.2556933760643005e-01
    z[7,8,4]  R2164     -4.4569936394691467e-01
    z[7,8,4]  R2165     2.0808382332324982e-01
    z[7,8,4]  R2166     -5.1360708475112915e-01
    z[7,8,4]  R2167     -5.0404256582260132e-01
    z[7,8,4]  R2168     8.1670030951499939e-02
    z[7,8,4]  R2169     -4.0133169293403625e-01
    z[7,8,4]  R2170     -3.7903463840484619e-01
    z[7,8,4]  R2171     -1.1011761426925659e-01
    z[7,8,4]  R2172     -1.4226512610912323e-01
    z[7,8,4]  R2173     -6.4063584804534912e-01
    z[7,8,4]  R2174     -4.1146388649940491e-01
    z[7,8,4]  R2175     0.206847682595253
    z[7,8,4]  R2176     3.7891995906829834e-01
    z[7,8,4]  R2177     -2.9972764849662781e-01
    z[7,8,4]  R2178     -4.7512295842170715e-01
    z[7,8,4]  R2179     9.5892600715160370e-02
    z[7,8,4]  R2180     -2.8939386829733849e-03
    z[7,8,4]  R2181     -1.4694561064243317e-01
    z[7,8,4]  R2182     -2.4297364056110382e-01
    z[7,8,4]  R2183     -1.5307384543120861e-02
    z[7,8,4]  R2184     4.6376258134841919e-01
    z[7,8,4]  R2185     1.1937827616930008e-01
    z[7,8,4]  R2186     -5.8907294273376465e-01
    z[7,8,4]  R2187     -4.6194321475923061e-03
    z[7,8,4]  R2188     -1.8133457051590085e-03
    z[7,8,4]  R2189     -3.8105627894401550e-01
    z[7,8,4]  R2190     -4.3600201606750488e-03
    z[7,8,4]  R2191     -1.5064917504787445e-01
    z[7,8,4]  R2192     -3.1293755769729614e-01
    z[7,8,4]  R2193     6.3089394569396973e-01
    z[7,8,4]  R2194     1.5609785914421082e-01
    z[7,8,4]  R2195     -0.0791405513882637
    z[7,8,4]  R2196     -2.6542615890502930e-01
    z[7,8,4]  R2197     -3.0111056566238403e-01
    z[7,8,4]  R2198     2.7456298470497131e-01
    z[7,8,4]  R2199     -9.5664508640766144e-02
    z[7,8,4]  R2200     -4.4944092631340027e-02
    z[7,8,4]  R2201     -4.2058318853378296e-01
    z[7,8,4]  R2202     8.3651952445507050e-02
    z[7,8,4]  R2203     1.6183950006961823e-01
    z[7,8,4]  R2204     1.2228089570999146e-01
    z[7,8,4]  R2205     1.0831851512193680e-01
    z[7,8,4]  R2206     4.1239753365516663e-02
    z[7,8,4]  R2207     2.6689562201499939e-01
    z[7,8,4]  R2208     -1.4906527101993561e-01
    z[7,8,4]  R2209     -2.0540687441825867e-01
    z[7,8,4]  R2210     2.5316244363784790e-01
    z[7,8,4]  R2211     -6.5151840448379517e-01
    z[7,8,4]  R2212     -2.9696115851402283e-01
    z[7,8,4]  R2213     -1.1717782914638519e-01
    z[7,8,4]  R2214     1.4127730391919613e-02
    z[7,8,4]  R2215     -7.0654176175594330e-02
    z[7,8,4]  R2216     4.1520255804061890e-01
    z[7,8,4]  R2217     0.387582391500473
    z[7,8,4]  R2218     2.3515014350414276e-01
    z[7,8,4]  R2219     -3.9228785037994385e-01
    z[7,8,4]  R2220     6.2750995159149170e-01
    z[7,8,4]  R2221     1.9426903128623962e-01
    z[7,8,4]  R2222     -2.2242219746112823e-01
    z[7,8,4]  R2223     3.1424409151077271e-01
    z[7,8,4]  R2224     -4.5627325773239136e-01
    z[7,8,4]  R2225     -5.8904582262039185e-01
    z[7,8,4]  R2226     -1.0184727609157562e-01
    z[7,8,4]  R2227     -1.0739585757255554e-01
    z[7,8,4]  R2228     -2.1908564865589142e-01
    z[7,8,4]  R2229     -4.3875795602798462e-01
    z[7,8,4]  R2230     1.7991036176681519e-01
    z[7,8,4]  R2231     4.2504531145095825e-01
    z[7,8,4]  R2232     1.6858136653900146e-01
    z[7,8,4]  R2233     -1.0200709104537964e-01
    z[7,8,4]  R2234     1.5478786826133728e-01
    z[7,8,4]  R2235     -4.6223394572734833e-02
    z[7,8,4]  R2236     -3.5091400146484375e-02
    z[7,8,4]  R2237     -1.3885188102722168e-01
    z[7,8,4]  R2238     -4.1444721817970276e-01
    z[7,8,4]  R2239     -3.9981588721275330e-01
    z[7,8,4]  R2240     -8.6185067892074585e-01
    z[7,8,4]  R2241     -0.408926784992218
    z[7,8,4]  R2242     -0.0832945927977562
    z[7,8,4]  R2243     7.2540216147899628e-02
    z[7,8,4]  R2244     -9.7592107951641083e-02
    z[7,8,4]  R2245     -0.176550030708313
    z[7,8,4]  R2246     1.3600136339664459e-01
    z[7,8,4]  R2247     2.0202951133251190e-01
    z[7,8,5]  R70       -1
    z[7,8,5]  R79       1
    z[7,8,5]  R2124     -1
    z[7,8,5]  R2125     1
    z[7,8,5]  R2128     -1.0249841958284378e-01
    z[7,8,5]  R2129     1.7503528296947479e-01
    z[7,8,5]  R2130     -1.4425632357597351e-01
    z[7,8,5]  R2131     -3.2255119085311890e-01
    z[7,8,5]  R2132     -0.600347638130188
    z[7,8,5]  R2133     -6.0250550508499146e-01
    z[7,8,5]  R2134     0.0891474261879921
    z[7,8,5]  R2135     4.0151673555374146e-01
    z[7,8,5]  R2136     -4.7962307929992676e-01
    z[7,8,5]  R2137     -3.4413054585456848e-02
    z[7,8,5]  R2138     -1.1766847223043442e-01
    z[7,8,5]  R2139     1.3352537155151367e-01
    z[7,8,5]  R2140     2.3594121634960175e-01
    z[7,8,5]  R2141     7.7845461666584015e-02
    z[7,8,5]  R2142     0.0967373251914978
    z[7,8,5]  R2143     -1.3386048376560211e-01
    z[7,8,5]  R2144     -2.6824557781219482e-01
    z[7,8,5]  R2145     3.7103157490491867e-02
    z[7,8,5]  R2146     -3.6585512757301331e-01
    z[7,8,5]  R2147     2.8318911790847778e-01
    z[7,8,5]  R2148     1.2169913202524185e-01
    z[7,8,5]  R2149     -3.9303097128868103e-01
    z[7,8,5]  R2150     -0.0816449224948883
    z[7,8,5]  R2151     -5.6547236442565918e-01
    z[7,8,5]  R2152     -6.6692757606506348e-01
    z[7,8,5]  R2153     -3.4426271915435791e-01
    z[7,8,5]  R2154     3.6641916632652283e-01
    z[7,8,5]  R2155     -5.0223779678344727e-01
    z[7,8,5]  R2156     -6.3555151224136353e-01
    z[7,8,5]  R2157     -2.2146481275558472e-01
    z[7,8,5]  R2158     -5.1602099090814590e-02
    z[7,8,5]  R2159     1.6430897638201714e-02
    z[7,8,5]  R2160     -5.8209329843521118e-01
    z[7,8,5]  R2161     -6.2541455030441284e-01
    z[7,8,5]  R2162     -3.0523651838302612e-01
    z[7,8,5]  R2163     7.9011030495166779e-02
    z[7,8,5]  R2164     4.8354193568229675e-01
    z[7,8,5]  R2165     -1.7072671651840210e-01
    z[7,8,5]  R2166     -8.4060803055763245e-02
    z[7,8,5]  R2167     -2.6964968442916870e-01
    z[7,8,5]  R2168     6.3986754417419434e-01
    z[7,8,5]  R2169     -3.6593699455261230e-01
    z[7,8,5]  R2170     -2.7578333020210266e-01
    z[7,8,5]  R2171     -5.6960654258728027e-01
    z[7,8,5]  R2172     1.9624894857406616e-01
    z[7,8,5]  R2173     -1.2349840998649597e-01
    z[7,8,5]  R2174     -3.6559337377548218e-01
    z[7,8,5]  R2175     -3.2811611890792847e-01
    z[7,8,5]  R2176     -3.3112549781799316e-01
    z[7,8,5]  R2177     4.6616134047508240e-01
    z[7,8,5]  R2178     3.7009748630225658e-03
    z[7,8,5]  R2179     -5.0836455821990967e-01
    z[7,8,5]  R2180     3.3694821596145630e-01
    z[7,8,5]  R2181     -6.3688290119171143e-01
    z[7,8,5]  R2182     -0.508578896522522
    z[7,8,5]  R2183     -7.3330736160278320e-01
    z[7,8,5]  R2184     -1.1799383908510208e-01
    z[7,8,5]  R2185     5.1627850532531738e-01
    z[7,8,5]  R2186     1.7205353826284409e-02
    z[7,8,5]  R2187     6.1767673492431641e-01
    z[7,8,5]  R2188     -2.2750230133533478e-01
    z[7,8,5]  R2189     -3.3121803402900696e-01
    z[7,8,5]  R2190     -6.4543688297271729e-01
    z[7,8,5]  R2191     -7.2935491800308228e-02
    z[7,8,5]  R2192     -8.6584746837615967e-02
    z[7,8,5]  R2193     -1.9172337651252747e-01
    z[7,8,5]  R2194     -3.9301192760467529e-01
    z[7,8,5]  R2195     -6.5661981701850891e-02
    z[7,8,5]  R2196     6.2302328646183014e-02
    z[7,8,5]  R2197     3.0315449833869934e-01
    z[7,8,5]  R2198     -2.1222855150699615e-01
    z[7,8,5]  R2199     -3.8571909070014954e-01
    z[7,8,5]  R2200     -3.7898812443017960e-02
    z[7,8,5]  R2201     -5.3185838460922241e-01
    z[7,8,5]  R2202     -5.1169478893280029e-01
    z[7,8,5]  R2203     -4.3579104542732239e-01
    z[7,8,5]  R2204     -7.8193083405494690e-02
    z[7,8,5]  R2205     1.4023149013519287e-01
    z[7,8,5]  R2206     -2.3247583210468292e-01
    z[7,8,5]  R2207     1.4512902498245239e-01
    z[7,8,5]  R2208     6.5063685178756714e-01
    z[7,8,5]  R2209     6.4727210998535156e-01
    z[7,8,5]  R2210     7.5353229045867920e-01
    z[7,8,5]  R2211     6.3173079490661621e-01
    z[7,8,5]  R2212     0.648418128490448
    z[7,8,5]  R2213     1.4669895172119141e-01
    z[7,8,5]  R2214     -0.35670205950737
    z[7,8,5]  R2215     4.6691350638866425e-02
    z[7,8,5]  R2216     -5.5635178089141846e-01
    z[7,8,5]  R2217     -1.0013957321643829e-01
    z[7,8,5]  R2218     -3.0002406239509583e-01
    z[7,8,5]  R2219     -5.8322310447692871e-01
    z[7,8,5]  R2220     -3.9679780602455139e-01
    z[7,8,5]  R2221     4.6744191646575928e-01
    z[7,8,5]  R2222     -1.8281127512454987e-01
    z[7,8,5]  R2223     2.6467922329902649e-01
    z[7,8,5]  R2224     -2.7792349457740784e-01
    z[7,8,5]  R2225     -1.1378429830074310e-01
    z[7,8,5]  R2226     1.2139365822076797e-01
    z[7,8,5]  R2227     -2.0855334401130676e-01
    z[7,8,5]  R2228     1.5417899191379547e-01
    z[7,8,5]  R2229     5.1112931966781616e-01
    z[7,8,5]  R2230     -1.4657360315322876e-01
    z[7,8,5]  R2231     4.4567704200744629e-02
    z[7,8,5]  R2232     -1.1271034367382526e-02
    z[7,8,5]  R2233     -4.3017813563346863e-01
    z[7,8,5]  R2234     -1.0735403746366501e-01
    z[7,8,5]  R2235     4.0523451566696167e-01
    z[7,8,5]  R2236     4.9842372536659241e-01
    z[7,8,5]  R2237     3.2940280437469482e-01
    z[7,8,5]  R2238     1.0949368029832840e-01
    z[7,8,5]  R2239     1.5383474528789520e-01
    z[7,8,5]  R2240     -1.6974768042564392e-01
    z[7,8,5]  R2241     -3.8104841113090515e-01
    z[7,8,5]  R2242     1.6225872933864594e-01
    z[7,8,5]  R2243     1.9123287498950958e-01
    z[7,8,5]  R2244     3.8897478580474854e-01
    z[7,8,5]  R2245     3.8984280824661255e-01
    z[7,8,5]  R2246     4.5666497945785522e-01
    z[7,8,5]  R2247     3.3115327358245850e-01
    z[7,8,6]  R71       -1
    z[7,8,6]  R80       1
    z[7,8,6]  R2126     -1
    z[7,8,6]  R2127     1
    z[7,8,6]  R2128     -3.9062026143074036e-01
    z[7,8,6]  R2129     3.2532146573066711e-01
    z[7,8,6]  R2130     4.3012522161006927e-02
    z[7,8,6]  R2131     2.5615417957305908e-01
    z[7,8,6]  R2132     -2.9138103127479553e-01
    z[7,8,6]  R2133     1.3356015086174011e-01
    z[7,8,6]  R2134     1.5730434656143188e-01
    z[7,8,6]  R2135     -4.3593651056289673e-01
    z[7,8,6]  R2136     -0.140225350856781
    z[7,8,6]  R2137     -2.5206431746482849e-01
    z[7,8,6]  R2138     -1.5787303447723389e-02
    z[7,8,6]  R2139     -4.1746541857719421e-02
    z[7,8,6]  R2140     6.3529871404170990e-03
    z[7,8,6]  R2141     2.9483121633529663e-01
    z[7,8,6]  R2142     2.6193094253540039e-01
    z[7,8,6]  R2143     -9.3920081853866577e-02
    z[7,8,6]  R2144     -1.7072544991970062e-01
    z[7,8,6]  R2145     2.5153619050979614e-01
    z[7,8,6]  R2146     2.4349084123969078e-02
    z[7,8,6]  R2147     -7.0670828223228455e-02
    z[7,8,6]  R2148     -4.9534910917282104e-01
    z[7,8,6]  R2149     -5.1896870136260986e-01
    z[7,8,6]  R2150     -2.1348045766353607e-01
    z[7,8,6]  R2151     6.5155699849128723e-02
    z[7,8,6]  R2152     -3.8442060351371765e-01
    z[7,8,6]  R2153     -3.6522826552391052e-01
    z[7,8,6]  R2154     -5.3321099281311035e-01
    z[7,8,6]  R2155     -4.1150754690170288e-01
    z[7,8,6]  R2156     -2.2725136578083038e-01
    z[7,8,6]  R2157     -4.4010943174362183e-01
    z[7,8,6]  R2158     4.9814966320991516e-01
    z[7,8,6]  R2159     -5.5191016197204590e-01
    z[7,8,6]  R2160     5.1421072334051132e-02
    z[7,8,6]  R2161     -3.4445410966873169e-01
    z[7,8,6]  R2162     -5.1716709136962891e-01
    z[7,8,6]  R2163     -5.8411377668380737e-01
    z[7,8,6]  R2164     -1.1579652875661850e-01
    z[7,8,6]  R2165     -1.8633359670639038e-01
    z[7,8,6]  R2166     5.3940999507904053e-01
    z[7,8,6]  R2167     -1.0724445432424545e-01
    z[7,8,6]  R2168     1.7643353343009949e-01
    z[7,8,6]  R2169     3.0668148398399353e-01
    z[7,8,6]  R2170     -1.1719116568565369e-01
    z[7,8,6]  R2171     3.0471768975257874e-01
    z[7,8,6]  R2172     -2.2337767481803894e-01
    z[7,8,6]  R2173     1.4146524667739868e-01
    z[7,8,6]  R2174     1.2998740375041962e-01
    z[7,8,6]  R2175     -1.1390867084264755e-01
    z[7,8,6]  R2176     1.6196960210800171e-01
    z[7,8,6]  R2177     1.6091284155845642e-01
    z[7,8,6]  R2178     -1.6700872778892517e-01
    z[7,8,6]  R2179     -3.6162579059600830e-01
    z[7,8,6]  R2180     -1.2262653559446335e-01
    z[7,8,6]  R2181     -2.0207743346691132e-01
    z[7,8,6]  R2182     -4.9447190761566162e-01
    z[7,8,6]  R2183     -0.0311052855104208
    z[7,8,6]  R2184     -1.8951158225536346e-01
    z[7,8,6]  R2185     -2.0190356671810150e-01
    z[7,8,6]  R2186     -1.4829598367214203e-01
    z[7,8,6]  R2187     1.8061019480228424e-02
    z[7,8,6]  R2188     9.9628299474716187e-02
    z[7,8,6]  R2189     2.3286198079586029e-01
    z[7,8,6]  R2190     -6.2215197831392288e-02
    z[7,8,6]  R2191     3.0210867524147034e-01
    z[7,8,6]  R2192     3.2108891010284424e-01
    z[7,8,6]  R2193     -2.5963318347930908e-01
    z[7,8,6]  R2194     3.4084182232618332e-02
    z[7,8,6]  R2195     1.3686721026897430e-01
    z[7,8,6]  R2196     2.8160536289215088e-01
    z[7,8,6]  R2197     3.3674296736717224e-01
    z[7,8,6]  R2198     0.715579092502594
    z[7,8,6]  R2199     -9.9180653691291809e-02
    z[7,8,6]  R2200     -3.1751450896263123e-01
    z[7,8,6]  R2201     -1.2775610387325287e-01
    z[7,8,6]  R2202     -1.9601227343082428e-01
    z[7,8,6]  R2203     -4.3291427195072174e-02
    z[7,8,6]  R2204     3.5004043579101562e-01
    z[7,8,6]  R2205     4.1487994790077209e-01
    z[7,8,6]  R2206     -1.5894404053688049e-01
    z[7,8,6]  R2207     -0.0661550909280777
    z[7,8,6]  R2208     -3.2657498121261597e-01
    z[7,8,6]  R2209     -5.6380033493041992e-01
    z[7,8,6]  R2210     -4.2768073081970215e-01
    z[7,8,6]  R2211     3.3474865555763245e-01
    z[7,8,6]  R2212     1.1454010009765625e-01
    z[7,8,6]  R2213     1.3956645131111145e-01
    z[7,8,6]  R2214     -1.0822586715221405e-02
    z[7,8,6]  R2215     -1.2186323851346970e-01
    z[7,8,6]  R2216     -6.1505012214183807e-02
    z[7,8,6]  R2217     5.6634787470102310e-02
    z[7,8,6]  R2218     2.3918713629245758e-01
    z[7,8,6]  R2219     1.6429321467876434e-01
    z[7,8,6]  R2220     -4.9106314778327942e-02
    z[7,8,6]  R2221     4.5863509178161621e-01
    z[7,8,6]  R2222     -1.5227811038494110e-01
    z[7,8,6]  R2223     4.9847438931465149e-03
    z[7,8,6]  R2224     1.9000843167304993e-01
    z[7,8,6]  R2225     -6.0314185917377472e-02
    z[7,8,6]  R2226     -6.2600302696228027e-01
    z[7,8,6]  R2227     3.4400549530982971e-01
    z[7,8,6]  R2228     3.3920171856880188e-01
    z[7,8,6]  R2229     1.7776845395565033e-01
    z[7,8,6]  R2230     -7.7110564708709717e-01
    z[7,8,6]  R2231     -4.5317225158214569e-02
    z[7,8,6]  R2232     -6.3411140441894531e-01
    z[7,8,6]  R2233     -6.7915320396423340e-02
    z[7,8,6]  R2234     -3.2243371009826660e-01
    z[7,8,6]  R2235     0.129832461476326
    z[7,8,6]  R2236     -1.0833974182605743e-01
    z[7,8,6]  R2237     -1.0275018960237503e-01
    z[7,8,6]  R2238     -6.9056069850921631e-01
    z[7,8,6]  R2239     -3.1261447817087173e-02
    z[7,8,6]  R2240     -7.3703393340110779e-02
    z[7,8,6]  R2241     -6.4319044351577759e-01
    z[7,8,6]  R2242     -1.0318081825971603e-01
    z[7,8,6]  R2243     -0.0948491171002388
    z[7,8,6]  R2244     -8.9268978626932949e-05
    z[7,8,6]  R2245     1.3175293803215027e-01
    z[7,8,6]  R2246     4.3359977006912231e-01
    z[7,8,6]  R2247     2.3819006979465485e-01
    z[8,7,0]  R65       1
    z[8,7,0]  R74       -1
    z[8,7,0]  R2248     -1
    z[8,7,0]  R2249     1
    z[8,7,0]  R2262     -1.2852829694747925e-01
    z[8,7,0]  R2263     -0.0594470389187336
    z[8,7,0]  R2264     -6.5190011262893677e-01
    z[8,7,0]  R2265     1.6146008670330048e-01
    z[8,7,0]  R2266     -9.2804804444313049e-02
    z[8,7,0]  R2267     -6.5555781126022339e-01
    z[8,7,0]  R2268     -7.3388135433197021e-01
    z[8,7,0]  R2269     -7.4394792318344116e-01
    z[8,7,0]  R2270     -8.0741649866104126e-01
    z[8,7,0]  R2271     -8.0002427101135254e-01
    z[8,7,0]  R2272     -3.9988499134778976e-02
    z[8,7,0]  R2273     2.7581200003623962e-01
    z[8,7,0]  R2274     2.8731355071067810e-01
    z[8,7,0]  R2275     0.05734858289361
    z[8,7,0]  R2276     4.4874057173728943e-01
    z[8,7,0]  R2277     7.2059106826782227e-01
    z[8,7,0]  R2278     6.0280710458755493e-01
    z[8,7,0]  R2279     7.8249531984329224e-01
    z[8,7,0]  R2280     5.7844305038452148e-01
    z[8,7,0]  R2281     6.1135005950927734e-01
    z[8,7,0]  R2282     6.1014586687088013e-01
    z[8,7,0]  R2283     -3.5574698448181152e-01
    z[8,7,0]  R2284     2.7639642357826233e-01
    z[8,7,0]  R2285     -2.6914203166961670e-01
    z[8,7,0]  R2286     4.6433284878730774e-01
    z[8,7,0]  R2287     -0.853218138217926
    z[8,7,0]  R2288     2.8995686769485474e-01
    z[8,7,0]  R2289     3.1004312634468079e-01
    z[8,7,0]  R2290     -2.2425624728202820e-01
    z[8,7,0]  R2291     1.5226773917675018e-01
    z[8,7,0]  R2292     -1.2880882620811462e-01
    z[8,7,0]  R2293     2.9781904071569443e-02
    z[8,7,0]  R2294     -2.7811175584793091e-01
    z[8,7,0]  R2295     -2.7319031953811646e-01
    z[8,7,0]  R2296     -0.69287109375
    z[8,7,0]  R2297     3.6316105723381042e-01
    z[8,7,0]  R2298     3.6248227953910828e-01
    z[8,7,0]  R2299     3.1406599283218384e-01
    z[8,7,0]  R2300     2.3585869371891022e-01
    z[8,7,0]  R2301     3.6995249986648560e-01
    z[8,7,0]  R2302     -4.2968600988388062e-02
    z[8,7,0]  R2303     0.402852863073349
    z[8,7,0]  R2304     4.1930586099624634e-01
    z[8,7,0]  R2305     3.7883815169334412e-01
    z[8,7,0]  R2306     -3.2579079270362854e-02
    z[8,7,0]  R2307     -7.9975659027695656e-03
    z[8,7,0]  R2308     5.0608873367309570e-01
    z[8,7,0]  R2309     3.5544195771217346e-01
    z[8,7,0]  R2310     3.9803826808929443e-01
    z[8,7,0]  R2311     4.8468944430351257e-01
    z[8,7,0]  R2312     -4.1742384433746338e-01
    z[8,7,0]  R2313     -2.5374817848205566e-01
    z[8,7,0]  R2314     2.9268631339073181e-01
    z[8,7,0]  R2315     -2.8985580801963806e-01
    z[8,7,0]  R2316     -2.7387583255767822e-01
    z[8,7,0]  R2317     -9.6661873161792755e-02
    z[8,7,0]  R2318     -8.0902941524982452e-02
    z[8,7,0]  R2319     1.9217935204505920e-01
    z[8,7,0]  R2320     -2.7157601714134216e-01
    z[8,7,0]  R2321     -3.7019826471805573e-02
    z[8,7,0]  R2322     -5.1463431119918823e-01
    z[8,7,0]  R2323     -7.5788277387619019e-01
    z[8,7,0]  R2324     -6.9060385227203369e-01
    z[8,7,0]  R2325     -2.5572237372398376e-01
    z[8,7,0]  R2326     0.598052442073822
    z[8,7,0]  R2327     -6.2403172254562378e-01
    z[8,7,0]  R2328     -5.9778302907943726e-01
    z[8,7,0]  R2329     -3.7376496195793152e-01
    z[8,7,0]  R2330     -6.5007936954498291e-01
    z[8,7,0]  R2331     -0.4415283203125
    z[8,7,0]  R2332     4.9268159270286560e-01
    z[8,7,0]  R2333     3.1667700409889221e-01
    z[8,7,0]  R2334     7.0376896858215332e-01
    z[8,7,0]  R2335     1.9855907559394836e-01
    z[8,7,0]  R2336     5.9077608585357666e-01
    z[8,7,0]  R2337     6.7369127273559570e-01
    z[8,7,0]  R2338     4.7348472476005554e-01
    z[8,7,0]  R2339     4.4909808039665222e-01
    z[8,7,0]  R2340     3.1746962666511536e-01
    z[8,7,0]  R2341     5.1115787029266357e-01
    z[8,7,0]  R2342     -4.1719296574592590e-01
    z[8,7,0]  R2343     0.542195200920105
    z[8,7,0]  R2344     6.3908779621124268e-01
    z[8,7,0]  R2345     5.2245211601257324e-01
    z[8,7,0]  R2346     7.3084539175033569e-01
    z[8,7,0]  R2347     2.4125267565250397e-01
    z[8,7,0]  R2348     5.0219660997390747e-01
    z[8,7,0]  R2349     1.3187961280345917e-01
    z[8,7,0]  R2350     -1.3883483409881592e-01
    z[8,7,0]  R2351     2.9321116209030151e-01
    z[8,7,0]  R2352     -2.5262609124183655e-01
    z[8,7,0]  R2353     -8.2698212936520576e-03
    z[8,7,0]  R2354     6.6153752803802490e-01
    z[8,7,0]  R2355     6.0601574182510376e-01
    z[8,7,0]  R2356     5.0554829835891724e-01
    z[8,7,0]  R2357     2.1321113407611847e-01
    z[8,7,0]  R2358     1.7096064984798431e-01
    z[8,7,0]  R2359     3.4136199951171875e-01
    z[8,7,0]  R2360     6.2890779972076416e-01
    z[8,7,0]  R2361     0.561506986618042
    z[8,7,0]  R2362     2.7783498167991638e-01
    z[8,7,0]  R2363     3.9151710271835327e-01
    z[8,7,0]  R2364     4.8872488737106323e-01
    z[8,7,0]  R2365     5.9827280044555664e-01
    z[8,7,0]  R2366     5.3189265727996826e-01
    z[8,7,0]  R2367     -8.0244131386280060e-02
    z[8,7,0]  R2368     6.1898368597030640e-01
    z[8,7,0]  R2369     -1.2636521458625793e-01
    z[8,7,0]  R2370     4.7545289993286133e-01
    z[8,7,0]  R2371     -1.8992806971073151e-01
    z[8,7,0]  R2372     -4.4662123918533325e-01
    z[8,7,0]  R2373     7.5933212041854858e-01
    z[8,7,0]  R2374     1.4641419053077698e-01
    z[8,7,0]  R2375     9.0601153671741486e-02
    z[8,7,0]  R2376     1.4350548386573792e-01
    z[8,7,0]  R2377     4.1983413696289062e-01
    z[8,7,0]  R2378     4.4088366627693176e-01
    z[8,7,0]  R2379     -5.1574579629232176e-07
    z[8,7,0]  R2380     3.0272185802459717e-01
    z[8,7,0]  R2381     2.3438142240047455e-01
    z[8,7,1]  R66       1
    z[8,7,1]  R75       -1
    z[8,7,1]  R2250     -1
    z[8,7,1]  R2251     1
    z[8,7,1]  R2262     1.1826018244028091e-01
    z[8,7,1]  R2263     8.9327402412891388e-02
    z[8,7,1]  R2264     -0.530619740486145
    z[8,7,1]  R2265     -1.0871769627556205e-03
    z[8,7,1]  R2266     8.6960613727569580e-02
    z[8,7,1]  R2267     -5.6294459104537964e-01
    z[8,7,1]  R2268     -5.4096710681915283e-01
    z[8,7,1]  R2269     -3.8441410660743713e-01
    z[8,7,1]  R2270     1.0363811999559402e-01
    z[8,7,1]  R2271     5.5503904819488525e-02
    z[8,7,1]  R2272     2.9511308670043945e-01
    z[8,7,1]  R2273     1.5450754761695862e-01
    z[8,7,1]  R2274     1.7042127251625061e-01
    z[8,7,1]  R2275     2.0879945158958435e-01
    z[8,7,1]  R2276     3.2493349909782410e-01
    z[8,7,1]  R2277     3.6775767803192139e-01
    z[8,7,1]  R2278     0.314726322889328
    z[8,7,1]  R2279     5.4211676120758057e-01
    z[8,7,1]  R2280     2.5673910975456238e-01
    z[8,7,1]  R2281     2.7103403210639954e-01
    z[8,7,1]  R2282     3.7999680638313293e-01
    z[8,7,1]  R2283     5.8790612220764160e-01
    z[8,7,1]  R2284     5.4605388641357422e-01
    z[8,7,1]  R2285     4.7140055894851685e-01
    z[8,7,1]  R2286     0.66666579246521
    z[8,7,1]  R2287     1.8648330867290497e-01
    z[8,7,1]  R2288     -1.8866054713726044e-01
    z[8,7,1]  R2289     -2.3718793690204620e-01
    z[8,7,1]  R2290     4.1518858075141907e-01
    z[8,7,1]  R2291     -3.0725511908531189e-01
    z[8,7,1]  R2292     3.3868480473756790e-02
    z[8,7,1]  R2293     0.454218327999115
    z[8,7,1]  R2294     -2.0671127364039421e-02
    z[8,7,1]  R2295     -4.8183876276016235e-01
    z[8,7,1]  R2296     2.5234025716781616e-01
    z[8,7,1]  R2297     -1.8473502993583679e-01
    z[8,7,1]  R2298     -3.3799788355827332e-01
    z[8,7,1]  R2299     -5.0157308578491211e-01
    z[8,7,1]  R2300     -5.0875627994537354e-01
    z[8,7,1]  R2301     -4.6851876378059387e-01
    z[8,7,1]  R2302     2.0195086300373077e-01
    z[8,7,1]  R2303     -2.4059966206550598e-01
    z[8,7,1]  R2304     1.0994620621204376e-01
    z[8,7,1]  R2305     -2.4736025929450989e-01
    z[8,7,1]  R2306     -1.8016017973423004e-01
    z[8,7,1]  R2307     -2.6322522759437561e-01
    z[8,7,1]  R2308     -0.670713484287262
    z[8,7,1]  R2309     -8.1953620910644531e-01
    z[8,7,1]  R2310     -6.3240230083465576e-01
    z[8,7,1]  R2311     -7.2972595691680908e-01
    z[8,7,1]  R2312     -7.0349895954132080e-01
    z[8,7,1]  R2313     -7.6073330640792847e-01
    z[8,7,1]  R2314     -5.8580768108367920e-01
    z[8,7,1]  R2315     -0.550881564617157
    z[8,7,1]  R2316     -4.3758830428123474e-01
    z[8,7,1]  R2317     -5.0719237327575684e-01
    z[8,7,1]  R2318     -0.727531909942627
    z[8,7,1]  R2319     -6.8581086397171021e-01
    z[8,7,1]  R2320     -5.8624863624572754e-01
    z[8,7,1]  R2321     -5.6832879781723022e-01
    z[8,7,1]  R2322     8.1121939420700073e-01
    z[8,7,1]  R2323     5.9868144989013672e-01
    z[8,7,1]  R2324     0.481892466545105
    z[8,7,1]  R2325     8.4463369846343994e-01
    z[8,7,1]  R2326     5.9536057710647583e-01
    z[8,7,1]  R2327     6.6302919387817383e-01
    z[8,7,1]  R2328     0.513116717338562
    z[8,7,1]  R2329     8.2301336526870728e-01
    z[8,7,1]  R2330     5.3453516960144043e-01
    z[8,7,1]  R2331     7.6250523328781128e-01
    z[8,7,1]  R2332     6.1349582672119141e-01
    z[8,7,1]  R2333     3.7861829996109009e-01
    z[8,7,1]  R2334     2.5431987643241882e-01
    z[8,7,1]  R2335     0.417542427778244
    z[8,7,1]  R2336     1.4204722642898560e-01
    z[8,7,1]  R2337     3.9823630452156067e-01
    z[8,7,1]  R2338     0.381229043006897
    z[8,7,1]  R2339     3.3481189608573914e-01
    z[8,7,1]  R2340     3.3361795544624329e-01
    z[8,7,1]  R2341     3.3566546440124512e-01
    z[8,7,1]  R2342     5.5710178613662720e-01
    z[8,7,1]  R2343     4.2706665396690369e-01
    z[8,7,1]  R2344     2.6934564113616943e-01
    z[8,7,1]  R2345     2.0655032992362976e-01
    z[8,7,1]  R2346     0.293347030878067
    z[8,7,1]  R2347     5.4523384571075439e-01
    z[8,7,1]  R2348     0.469305157661438
    z[8,7,1]  R2349     2.6761990785598755e-01
    z[8,7,1]  R2350     2.3617841303348541e-01
    z[8,7,1]  R2351     6.4018809795379639e-01
    z[8,7,1]  R2352     6.9004052877426147e-01
    z[8,7,1]  R2353     4.9356538057327271e-01
    z[8,7,1]  R2354     3.3252444863319397e-01
    z[8,7,1]  R2355     3.8503104448318481e-01
    z[8,7,1]  R2356     6.2245595455169678e-01
    z[8,7,1]  R2357     6.7525357007980347e-02
    z[8,7,1]  R2358     3.8494072854518890e-02
    z[8,7,1]  R2359     6.1756855249404907e-01
    z[8,7,1]  R2360     3.2897058129310608e-01
    z[8,7,1]  R2361     3.0310752987861633e-01
    z[8,7,1]  R2362     0.330127477645874
    z[8,7,1]  R2363     2.0856209099292755e-01
    z[8,7,1]  R2364     7.3431402444839478e-01
    z[8,7,1]  R2365     2.1689492464065552e-01
    z[8,7,1]  R2366     0.392946720123291
    z[8,7,1]  R2367     3.2396170496940613e-01
    z[8,7,1]  R2368     3.3498492836952209e-01
    z[8,7,1]  R2369     -0.0694834440946579
    z[8,7,1]  R2370     3.7733837962150574e-01
    z[8,7,1]  R2371     2.0810633897781372e-02
    z[8,7,1]  R2372     6.7973607778549194e-01
    z[8,7,1]  R2373     2.9732012748718262e-01
    z[8,7,1]  R2374     3.7649261951446533e-01
    z[8,7,1]  R2375     3.6698821187019348e-01
    z[8,7,1]  R2376     5.4701352491974831e-03
    z[8,7,1]  R2377     4.3893152475357056e-01
    z[8,7,1]  R2378     0.687838613986969
    z[8,7,1]  R2379     3.1641638278961182e-01
    z[8,7,1]  R2380     -0.440679132938385
    z[8,7,1]  R2381     -4.1323426365852356e-01
    z[8,7,2]  R67       1
    z[8,7,2]  R76       -1
    z[8,7,2]  R2252     -1
    z[8,7,2]  R2253     1
    z[8,7,2]  R2262     -4.4401079416275024e-01
    z[8,7,2]  R2263     -3.2758188247680664e-01
    z[8,7,2]  R2264     2.2153076529502869e-01
    z[8,7,2]  R2265     -0.675586462020874
    z[8,7,2]  R2266     -6.5137469768524170e-01
    z[8,7,2]  R2267     1.7457915842533112e-01
    z[8,7,2]  R2268     4.3856389820575714e-02
    z[8,7,2]  R2269     -2.6346400380134583e-02
    z[8,7,2]  R2270     -2.4760743975639343e-01
    z[8,7,2]  R2271     -4.2816975712776184e-01
    z[8,7,2]  R2272     -3.7379637360572815e-01
    z[8,7,2]  R2273     -1.9351994991302490e-01
    z[8,7,2]  R2274     -2.0499213039875031e-01
    z[8,7,2]  R2275     -1.1064240336418152e-01
    z[8,7,2]  R2276     -3.9540970325469971e-01
    z[8,7,2]  R2277     -5.2497762441635132e-01
    z[8,7,2]  R2278     2.4224289227277040e-03
    z[8,7,2]  R2279     -0.0970020443201065
    z[8,7,2]  R2280     -1.9662268459796906e-01
    z[8,7,2]  R2281     -2.8607437014579773e-01
    z[8,7,2]  R2282     -5.1499092578887939e-01
    z[8,7,2]  R2283     -4.9329277127981186e-02
    z[8,7,2]  R2284     1.0384587198495865e-01
    z[8,7,2]  R2285     4.3746861815452576e-01
    z[8,7,2]  R2286     4.8087587952613831e-01
    z[8,7,2]  R2287     -2.3073922097682953e-01
    z[8,7,2]  R2288     -3.6082801222801208e-01
    z[8,7,2]  R2289     -3.0009731650352478e-01
    z[8,7,2]  R2290     0.562061607837677
    z[8,7,2]  R2291     -5.3335064649581909e-01
    z[8,7,2]  R2292     -8.9149087667465210e-01
    z[8,7,2]  R2293     0.189592182636261
    z[8,7,2]  R2294     -5.0809472799301147e-01
    z[8,7,2]  R2295     -5.5949020385742188e-01
    z[8,7,2]  R2296     1.5865002572536469e-01
    z[8,7,2]  R2297     -2.4356766045093536e-01
    z[8,7,2]  R2298     -4.4351139664649963e-01
    z[8,7,2]  R2299     5.8374601602554321e-01
    z[8,7,2]  R2300     5.8935302495956421e-01
    z[8,7,2]  R2301     6.2763148546218872e-01
    z[8,7,2]  R2302     -4.6040698885917664e-01
    z[8,7,2]  R2303     -6.3620215654373169e-01
    z[8,7,2]  R2304     -9.9123053252696991e-02
    z[8,7,2]  R2305     -2.5601658225059509e-01
    z[8,7,2]  R2306     7.2802132368087769e-01
    z[8,7,2]  R2307     6.6893249750137329e-01
    z[8,7,2]  R2308     2.6052811741828918e-01
    z[8,7,2]  R2309     2.3623399436473846e-02
    z[8,7,2]  R2310     7.3987804353237152e-02
    z[8,7,2]  R2311     7.5788281857967377e-02
    z[8,7,2]  R2312     -3.7101060152053833e-02
    z[8,7,2]  R2313     3.2610440254211426e-01
    z[8,7,2]  R2314     4.3813946843147278e-01
    z[8,7,2]  R2315     4.1852509975433350e-01
    z[8,7,2]  R2316     2.9723653197288513e-01
    z[8,7,2]  R2317     3.8061714172363281e-01
    z[8,7,2]  R2318     2.5127744302153587e-02
    z[8,7,2]  R2319     -1.0600391030311584e-01
    z[8,7,2]  R2320     -1.6638176143169403e-01
    z[8,7,2]  R2321     -5.9659677743911743e-01
    z[8,7,2]  R2322     1.8641431629657745e-01
    z[8,7,2]  R2323     -2.8258139267563820e-02
    z[8,7,2]  R2324     4.6208903193473816e-01
    z[8,7,2]  R2325     3.3079397678375244e-01
    z[8,7,2]  R2326     -4.5337709784507751e-01
    z[8,7,2]  R2327     -3.7219825387001038e-01
    z[8,7,2]  R2328     2.0643375813961029e-01
    z[8,7,2]  R2329     -2.2771295905113220e-01
    z[8,7,2]  R2330     1.4864406548440456e-02
    z[8,7,2]  R2331     -3.4367975592613220e-01
    z[8,7,2]  R2332     1.2198777496814728e-01
    z[8,7,2]  R2333     -1.7813597619533539e-01
    z[8,7,2]  R2334     1.8026264011859894e-01
    z[8,7,2]  R2335     -5.3825759887695312e-01
    z[8,7,2]  R2336     -1.8358139693737030e-01
    z[8,7,2]  R2337     1.8783777952194214e-01
    z[8,7,2]  R2338     1.0380639135837555e-01
    z[8,7,2]  R2339     8.4439389407634735e-02
    z[8,7,2]  R2340     -1.6782304644584656e-01
    z[8,7,2]  R2341     -8.1393130123615265e-02
    z[8,7,2]  R2342     1.0979621671140194e-02
    z[8,7,2]  R2343     -1.5255357325077057e-01
    z[8,7,2]  R2344     -1.8891420960426331e-01
    z[8,7,2]  R2345     -2.2009547054767609e-01
    z[8,7,2]  R2346     -2.3043116554617882e-02
    z[8,7,2]  R2347     -4.8352709412574768e-01
    z[8,7,2]  R2348     2.6932433247566223e-01
    z[8,7,2]  R2349     -8.2781696319580078e-01
    z[8,7,2]  R2350     -4.9663653969764709e-01
    z[8,7,2]  R2351     2.2295682132244110e-01
    z[8,7,2]  R2352     -4.5636307448148727e-02
    z[8,7,2]  R2353     -5.5839467048645020e-01
    z[8,7,2]  R2354     -8.6928181350231171e-02
    z[8,7,2]  R2355     -4.7206360846757889e-02
    z[8,7,2]  R2356     2.7449253201484680e-01
    z[8,7,2]  R2357     -7.0911628007888794e-01
    z[8,7,2]  R2358     -8.0570483207702637e-01
    z[8,7,2]  R2359     -4.4521424919366837e-02
    z[8,7,2]  R2360     2.3619423806667328e-01
    z[8,7,2]  R2361     -5.7745543308556080e-03
    z[8,7,2]  R2362     -7.3673325777053833e-01
    z[8,7,2]  R2363     -5.7246792316436768e-01
    z[8,7,2]  R2364     1.7531728744506836e-01
    z[8,7,2]  R2365     -3.1774231791496277e-01
    z[8,7,2]  R2366     -1.6345228999853134e-02
    z[8,7,2]  R2367     -5.2697920799255371e-01
    z[8,7,2]  R2368     3.7351274490356445e-01
    z[8,7,2]  R2369     2.5668165180832148e-03
    z[8,7,2]  R2370     -4.7355074435472488e-02
    z[8,7,2]  R2371     2.9300722479820251e-01
    z[8,7,2]  R2372     1.2888029217720032e-01
    z[8,7,2]  R2373     -1.2716868519783020e-01
    z[8,7,2]  R2374     -3.5650515556335449e-01
    z[8,7,2]  R2375     -0.820137083530426
    z[8,7,2]  R2376     -7.3708117008209229e-01
    z[8,7,2]  R2377     -1.4826372265815735e-01
    z[8,7,2]  R2378     2.5509911775588989e-01
    z[8,7,2]  R2379     -5.1989001035690308e-01
    z[8,7,2]  R2380     -3.2574686408042908e-01
    z[8,7,2]  R2381     -1.7981612682342529e-01
    z[8,7,3]  R68       1
    z[8,7,3]  R77       -1
    z[8,7,3]  R2254     -1
    z[8,7,3]  R2255     1
    z[8,7,3]  R2262     3.7399226427078247e-01
    z[8,7,3]  R2263     8.4463542699813843e-01
    z[8,7,3]  R2264     3.7432754039764404e-01
    z[8,7,3]  R2265     -2.0353691279888153e-01
    z[8,7,3]  R2266     -5.0228089094161987e-01
    z[8,7,3]  R2267     6.9852888584136963e-02
    z[8,7,3]  R2268     -1.5249375998973846e-01
    z[8,7,3]  R2269     3.0748987197875977e-01
    z[8,7,3]  R2270     4.4161000847816467e-01
    z[8,7,3]  R2271     2.7727040648460388e-01
    z[8,7,3]  R2272     -4.6838602423667908e-01
    z[8,7,3]  R2273     2.8910410404205322e-01
    z[8,7,3]  R2274     1.7768730223178864e-01
    z[8,7,3]  R2275     -7.2494372725486755e-02
    z[8,7,3]  R2276     1.2226977199316025e-01
    z[8,7,3]  R2277     -1.2317145615816116e-01
    z[8,7,3]  R2278     -6.4032179117202759e-01
    z[8,7,3]  R2279     -2.4975667893886566e-01
    z[8,7,3]  R2280     -2.7408912777900696e-01
    z[8,7,3]  R2281     -5.5452466011047363e-01
    z[8,7,3]  R2282     1.2485326826572418e-01
    z[8,7,3]  R2283     -6.5923802554607391e-02
    z[8,7,3]  R2284     2.4701729416847229e-01
    z[8,7,3]  R2285     2.1766215562820435e-01
    z[8,7,3]  R2286     5.1282446831464767e-02
    z[8,7,3]  R2287     -1.2317837774753571e-01
    z[8,7,3]  R2288     -6.5467965602874756e-01
    z[8,7,3]  R2289     -6.2769198417663574e-01
    z[8,7,3]  R2290     -2.1077285706996918e-01
    z[8,7,3]  R2291     -6.5159630775451660e-01
    z[8,7,3]  R2292     2.6033643633127213e-02
    z[8,7,3]  R2293     5.2104723453521729e-01
    z[8,7,3]  R2294     1.2494331598281860e-01
    z[8,7,3]  R2295     4.4211512804031372e-01
    z[8,7,3]  R2296     2.0982641726732254e-02
    z[8,7,3]  R2297     -7.5801765918731689e-01
    z[8,7,3]  R2298     -6.4669466018676758e-01
    z[8,7,3]  R2299     -3.5471069812774658e-01
    z[8,7,3]  R2300     -2.7713820338249207e-01
    z[8,7,3]  R2301     -0.333706796169281
    z[8,7,3]  R2302     -2.9114505648612976e-01
    z[8,7,3]  R2303     -0.43654665350914
    z[8,7,3]  R2304     -1.5885820984840393e-01
    z[8,7,3]  R2305     6.0308102518320084e-02
    z[8,7,3]  R2306     -6.2654095888137817e-01
    z[8,7,3]  R2307     -0.657532811164856
    z[8,7,3]  R2308     2.5557219982147217e-01
    z[8,7,3]  R2309     3.0942326411604881e-02
    z[8,7,3]  R2310     1.4529527723789215e-01
    z[8,7,3]  R2311     1.4006929099559784e-01
    z[8,7,3]  R2312     -2.1796271204948425e-01
    z[8,7,3]  R2313     -3.2439276576042175e-01
    z[8,7,3]  R2314     -5.6626987457275391e-01
    z[8,7,3]  R2315     -0.48638716340065
    z[8,7,3]  R2316     -4.4167909026145935e-01
    z[8,7,3]  R2317     -2.3436361551284790e-01
    z[8,7,3]  R2318     -2.6952078938484192e-01
    z[8,7,3]  R2319     -3.3212468028068542e-01
    z[8,7,3]  R2320     -2.0623359084129333e-01
    z[8,7,3]  R2321     -4.9054530262947083e-01
    z[8,7,3]  R2322     -1.3675317168235779e-01
    z[8,7,3]  R2323     1.4900295436382294e-01
    z[8,7,3]  R2324     -6.4627096056938171e-02
    z[8,7,3]  R2325     1.0589123517274857e-01
    z[8,7,3]  R2326     -6.5986894071102142e-02
    z[8,7,3]  R2327     6.7552458494901657e-03
    z[8,7,3]  R2328     4.8386582732200623e-01
    z[8,7,3]  R2329     2.5144720077514648e-01
    z[8,7,3]  R2330     3.4883657097816467e-01
    z[8,7,3]  R2331     -9.3822255730628967e-02
    z[8,7,3]  R2332     1.0117420926690102e-02
    z[8,7,3]  R2333     4.2367298156023026e-02
    z[8,7,3]  R2334     5.7666087150573730e-01
    z[8,7,3]  R2335     -3.8918060064315796e-01
    z[8,7,3]  R2336     -1.8717030063271523e-02
    z[8,7,3]  R2337     -2.6123163104057312e-01
    z[8,7,3]  R2338     3.8880711793899536e-01
    z[8,7,3]  R2339     1.2805530428886414e-01
    z[8,7,3]  R2340     -2.7015671133995056e-01
    z[8,7,3]  R2341     4.7361102700233459e-01
    z[8,7,3]  R2342     3.4452080726623535e-01
    z[8,7,3]  R2343     0.437370240688324
    z[8,7,3]  R2344     -2.0321829617023468e-01
    z[8,7,3]  R2345     3.1056657433509827e-01
    z[8,7,3]  R2346     -6.8546503782272339e-02
    z[8,7,3]  R2347     1.1138024926185608e-01
    z[8,7,3]  R2348     0.0956350564956665
    z[8,7,3]  R2349     -3.4429600834846497e-01
    z[8,7,3]  R2350     -3.4128466248512268e-01
    z[8,7,3]  R2351     3.4088918566703796e-01
    z[8,7,3]  R2352     1.0349992662668228e-01
    z[8,7,3]  R2353     -2.3556242883205414e-01
    z[8,7,3]  R2354     4.5910966396331787e-01
    z[8,7,3]  R2355     2.2986364364624023e-01
    z[8,7,3]  R2356     4.1589993238449097e-01
    z[8,7,3]  R2357     -3.8168314844369888e-02
    z[8,7,3]  R2358     1.6509534791111946e-02
    z[8,7,3]  R2359     -5.8023923635482788e-01
    z[8,7,3]  R2360     4.0125700831413269e-01
    z[8,7,3]  R2361     5.0967288017272949e-01
    z[8,7,3]  R2362     -1.3190989196300507e-01
    z[8,7,3]  R2363     -2.7765738964080811e-01
    z[8,7,3]  R2364     2.5022971630096436e-01
    z[8,7,3]  R2365     1.6130031645298004e-01
    z[8,7,3]  R2366     1.4988344162702560e-02
    z[8,7,3]  R2367     -2.6825568079948425e-01
    z[8,7,3]  R2368     3.1657463312149048e-01
    z[8,7,3]  R2369     8.1094855070114136e-01
    z[8,7,3]  R2370     -0.509924590587616
    z[8,7,3]  R2371     7.0410865545272827e-01
    z[8,7,3]  R2372     5.1008999347686768e-01
    z[8,7,3]  R2373     9.8537676036357880e-02
    z[8,7,3]  R2374     -5.3781199455261230e-01
    z[8,7,3]  R2375     -2.5534653663635254e-01
    z[8,7,3]  R2376     -4.7703534364700317e-01
    z[8,7,3]  R2377     -3.2695853710174561e-01
    z[8,7,3]  R2378     -0.295698344707489
    z[8,7,3]  R2379     -7.7478241920471191e-01
    z[8,7,3]  R2380     6.7410397529602051e-01
    z[8,7,3]  R2381     0.667834460735321
    z[8,7,4]  R69       1
    z[8,7,4]  R78       -1
    z[8,7,4]  R2256     -1
    z[8,7,4]  R2257     1
    z[8,7,4]  R2262     2.7456298470497131e-01
    z[8,7,4]  R2263     -9.5664508640766144e-02
    z[8,7,4]  R2264     -4.4944092631340027e-02
    z[8,7,4]  R2265     -4.2058318853378296e-01
    z[8,7,4]  R2266     8.3651952445507050e-02
    z[8,7,4]  R2267     1.6183950006961823e-01
    z[8,7,4]  R2268     1.2228089570999146e-01
    z[8,7,4]  R2269     1.0831851512193680e-01
    z[8,7,4]  R2270     4.1239753365516663e-02
    z[8,7,4]  R2271     2.6689562201499939e-01
    z[8,7,4]  R2272     -1.4906527101993561e-01
    z[8,7,4]  R2273     -2.0540687441825867e-01
    z[8,7,4]  R2274     2.5316244363784790e-01
    z[8,7,4]  R2275     -6.5151840448379517e-01
    z[8,7,4]  R2276     -2.9696115851402283e-01
    z[8,7,4]  R2277     -1.1717782914638519e-01
    z[8,7,4]  R2278     1.4127730391919613e-02
    z[8,7,4]  R2279     -7.0654176175594330e-02
    z[8,7,4]  R2280     4.1520255804061890e-01
    z[8,7,4]  R2281     0.387582391500473
    z[8,7,4]  R2282     2.3515014350414276e-01
    z[8,7,4]  R2283     -3.9228785037994385e-01
    z[8,7,4]  R2284     6.2750995159149170e-01
    z[8,7,4]  R2285     1.9426903128623962e-01
    z[8,7,4]  R2286     -2.2242219746112823e-01
    z[8,7,4]  R2287     3.1424409151077271e-01
    z[8,7,4]  R2288     -4.5627325773239136e-01
    z[8,7,4]  R2289     -5.8904582262039185e-01
    z[8,7,4]  R2290     -1.0184727609157562e-01
    z[8,7,4]  R2291     -1.0739585757255554e-01
    z[8,7,4]  R2292     -2.1908564865589142e-01
    z[8,7,4]  R2293     -4.3875795602798462e-01
    z[8,7,4]  R2294     1.7991036176681519e-01
    z[8,7,4]  R2295     4.2504531145095825e-01
    z[8,7,4]  R2296     1.6858136653900146e-01
    z[8,7,4]  R2297     -1.0200709104537964e-01
    z[8,7,4]  R2298     1.5478786826133728e-01
    z[8,7,4]  R2299     -4.6223394572734833e-02
    z[8,7,4]  R2300     -3.5091400146484375e-02
    z[8,7,4]  R2301     -1.3885188102722168e-01
    z[8,7,4]  R2302     -4.1444721817970276e-01
    z[8,7,4]  R2303     -3.9981588721275330e-01
    z[8,7,4]  R2304     -8.6185067892074585e-01
    z[8,7,4]  R2305     -0.408926784992218
    z[8,7,4]  R2306     -0.0832945927977562
    z[8,7,4]  R2307     7.2540216147899628e-02
    z[8,7,4]  R2308     -9.7592107951641083e-02
    z[8,7,4]  R2309     -0.176550030708313
    z[8,7,4]  R2310     1.3600136339664459e-01
    z[8,7,4]  R2311     2.0202951133251190e-01
    z[8,7,4]  R2312     -3.4477835893630981e-01
    z[8,7,4]  R2313     -9.4077989459037781e-02
    z[8,7,4]  R2314     1.8941025435924530e-01
    z[8,7,4]  R2315     1.7641784250736237e-01
    z[8,7,4]  R2316     6.8979769945144653e-02
    z[8,7,4]  R2317     -3.9085236191749573e-01
    z[8,7,4]  R2318     5.9848743677139282e-01
    z[8,7,4]  R2319     1.4117564260959625e-01
    z[8,7,4]  R2320     5.1248639822006226e-01
    z[8,7,4]  R2321     1.1978673934936523e-01
    z[8,7,4]  R2322     0.097610242664814
    z[8,7,4]  R2323     -1.5691386163234711e-01
    z[8,7,4]  R2324     -1.3203912973403931e-01
    z[8,7,4]  R2325     8.7045609951019287e-02
    z[8,7,4]  R2326     2.8269633185118437e-03
    z[8,7,4]  R2327     -7.5232565402984619e-02
    z[8,7,4]  R2328     3.9024170488119125e-02
    z[8,7,4]  R2329     -5.6769125163555145e-02
    z[8,7,4]  R2330     -1.8793129920959473e-01
    z[8,7,4]  R2331     1.0737630724906921e-01
    z[8,7,4]  R2332     3.2515057921409607e-01
    z[8,7,4]  R2333     -5.4684060811996460e-01
    z[8,7,4]  R2334     -1.5085913240909576e-01
    z[8,7,4]  R2335     1.4507076144218445e-01
    z[8,7,4]  R2336     6.4669072628021240e-02
    z[8,7,4]  R2337     1.7920480668544769e-01
    z[8,7,4]  R2338     -2.2350139915943146e-01
    z[8,7,4]  R2339     4.9102181196212769e-01
    z[8,7,4]  R2340     4.8082631826400757e-01
    z[8,7,4]  R2341     3.9034748077392578e-01
    z[8,7,4]  R2342     -3.8204270601272583e-01
    z[8,7,4]  R2343     -6.4795307815074921e-02
    z[8,7,4]  R2344     3.1710690259933472e-01
    z[8,7,4]  R2345     -1.7232243716716766e-01
    z[8,7,4]  R2346     1.1811833083629608e-01
    z[8,7,4]  R2347     -2.2556933760643005e-01
    z[8,7,4]  R2348     -4.4569936394691467e-01
    z[8,7,4]  R2349     2.0808382332324982e-01
    z[8,7,4]  R2350     -5.1360708475112915e-01
    z[8,7,4]  R2351     -5.0404256582260132e-01
    z[8,7,4]  R2352     8.1670030951499939e-02
    z[8,7,4]  R2353     -4.0133169293403625e-01
    z[8,7,4]  R2354     -3.7903463840484619e-01
    z[8,7,4]  R2355     -1.1011761426925659e-01
    z[8,7,4]  R2356     -1.4226512610912323e-01
    z[8,7,4]  R2357     -6.4063584804534912e-01
    z[8,7,4]  R2358     -4.1146388649940491e-01
    z[8,7,4]  R2359     0.206847682595253
    z[8,7,4]  R2360     3.7891995906829834e-01
    z[8,7,4]  R2361     -2.9972764849662781e-01
    z[8,7,4]  R2362     -4.7512295842170715e-01
    z[8,7,4]  R2363     9.5892600715160370e-02
    z[8,7,4]  R2364     -2.8939386829733849e-03
    z[8,7,4]  R2365     -1.4694561064243317e-01
    z[8,7,4]  R2366     -2.4297364056110382e-01
    z[8,7,4]  R2367     -1.5307384543120861e-02
    z[8,7,4]  R2368     4.6376258134841919e-01
    z[8,7,4]  R2369     1.1937827616930008e-01
    z[8,7,4]  R2370     -5.8907294273376465e-01
    z[8,7,4]  R2371     -4.6194321475923061e-03
    z[8,7,4]  R2372     -1.8133457051590085e-03
    z[8,7,4]  R2373     -3.8105627894401550e-01
    z[8,7,4]  R2374     -4.3600201606750488e-03
    z[8,7,4]  R2375     -1.5064917504787445e-01
    z[8,7,4]  R2376     -3.1293755769729614e-01
    z[8,7,4]  R2377     6.3089394569396973e-01
    z[8,7,4]  R2378     1.5609785914421082e-01
    z[8,7,4]  R2379     -0.0791405513882637
    z[8,7,4]  R2380     -2.6542615890502930e-01
    z[8,7,4]  R2381     -3.0111056566238403e-01
    z[8,7,5]  R70       1
    z[8,7,5]  R79       -1
    z[8,7,5]  R2258     -1
    z[8,7,5]  R2259     1
    z[8,7,5]  R2262     -2.1222855150699615e-01
    z[8,7,5]  R2263     -3.8571909070014954e-01
    z[8,7,5]  R2264     -3.7898812443017960e-02
    z[8,7,5]  R2265     -5.3185838460922241e-01
    z[8,7,5]  R2266     -5.1169478893280029e-01
    z[8,7,5]  R2267     -4.3579104542732239e-01
    z[8,7,5]  R2268     -7.8193083405494690e-02
    z[8,7,5]  R2269     1.4023149013519287e-01
    z[8,7,5]  R2270     -2.3247583210468292e-01
    z[8,7,5]  R2271     1.4512902498245239e-01
    z[8,7,5]  R2272     6.5063685178756714e-01
    z[8,7,5]  R2273     6.4727210998535156e-01
    z[8,7,5]  R2274     7.5353229045867920e-01
    z[8,7,5]  R2275     6.3173079490661621e-01
    z[8,7,5]  R2276     0.648418128490448
    z[8,7,5]  R2277     1.4669895172119141e-01
    z[8,7,5]  R2278     -0.35670205950737
    z[8,7,5]  R2279     4.6691350638866425e-02
    z[8,7,5]  R2280     -5.5635178089141846e-01
    z[8,7,5]  R2281     -1.0013957321643829e-01
    z[8,7,5]  R2282     -3.0002406239509583e-01
    z[8,7,5]  R2283     -5.8322310447692871e-01
    z[8,7,5]  R2284     -3.9679780602455139e-01
    z[8,7,5]  R2285     4.6744191646575928e-01
    z[8,7,5]  R2286     -1.8281127512454987e-01
    z[8,7,5]  R2287     2.6467922329902649e-01
    z[8,7,5]  R2288     -2.7792349457740784e-01
    z[8,7,5]  R2289     -1.1378429830074310e-01
    z[8,7,5]  R2290     1.2139365822076797e-01
    z[8,7,5]  R2291     -2.0855334401130676e-01
    z[8,7,5]  R2292     1.5417899191379547e-01
    z[8,7,5]  R2293     5.1112931966781616e-01
    z[8,7,5]  R2294     -1.4657360315322876e-01
    z[8,7,5]  R2295     4.4567704200744629e-02
    z[8,7,5]  R2296     -1.1271034367382526e-02
    z[8,7,5]  R2297     -4.3017813563346863e-01
    z[8,7,5]  R2298     -1.0735403746366501e-01
    z[8,7,5]  R2299     4.0523451566696167e-01
    z[8,7,5]  R2300     4.9842372536659241e-01
    z[8,7,5]  R2301     3.2940280437469482e-01
    z[8,7,5]  R2302     1.0949368029832840e-01
    z[8,7,5]  R2303     1.5383474528789520e-01
    z[8,7,5]  R2304     -1.6974768042564392e-01
    z[8,7,5]  R2305     -3.8104841113090515e-01
    z[8,7,5]  R2306     1.6225872933864594e-01
    z[8,7,5]  R2307     1.9123287498950958e-01
    z[8,7,5]  R2308     3.8897478580474854e-01
    z[8,7,5]  R2309     3.8984280824661255e-01
    z[8,7,5]  R2310     4.5666497945785522e-01
    z[8,7,5]  R2311     3.3115327358245850e-01
    z[8,7,5]  R2312     -1.0249841958284378e-01
    z[8,7,5]  R2313     1.7503528296947479e-01
    z[8,7,5]  R2314     -1.4425632357597351e-01
    z[8,7,5]  R2315     -3.2255119085311890e-01
    z[8,7,5]  R2316     -0.600347638130188
    z[8,7,5]  R2317     -6.0250550508499146e-01
    z[8,7,5]  R2318     0.0891474261879921
    z[8,7,5]  R2319     4.0151673555374146e-01
    z[8,7,5]  R2320     -4.7962307929992676e-01
    z[8,7,5]  R2321     -3.4413054585456848e-02
    z[8,7,5]  R2322     -1.1766847223043442e-01
    z[8,7,5]  R2323     1.3352537155151367e-01
    z[8,7,5]  R2324     2.3594121634960175e-01
    z[8,7,5]  R2325     7.7845461666584015e-02
    z[8,7,5]  R2326     0.0967373251914978
    z[8,7,5]  R2327     -1.3386048376560211e-01
    z[8,7,5]  R2328     -2.6824557781219482e-01
    z[8,7,5]  R2329     3.7103157490491867e-02
    z[8,7,5]  R2330     -3.6585512757301331e-01
    z[8,7,5]  R2331     2.8318911790847778e-01
    z[8,7,5]  R2332     1.2169913202524185e-01
    z[8,7,5]  R2333     -3.9303097128868103e-01
    z[8,7,5]  R2334     -0.0816449224948883
    z[8,7,5]  R2335     -5.6547236442565918e-01
    z[8,7,5]  R2336     -6.6692757606506348e-01
    z[8,7,5]  R2337     -3.4426271915435791e-01
    z[8,7,5]  R2338     3.6641916632652283e-01
    z[8,7,5]  R2339     -5.0223779678344727e-01
    z[8,7,5]  R2340     -6.3555151224136353e-01
    z[8,7,5]  R2341     -2.2146481275558472e-01
    z[8,7,5]  R2342     -5.1602099090814590e-02
    z[8,7,5]  R2343     1.6430897638201714e-02
    z[8,7,5]  R2344     -5.8209329843521118e-01
    z[8,7,5]  R2345     -6.2541455030441284e-01
    z[8,7,5]  R2346     -3.0523651838302612e-01
    z[8,7,5]  R2347     7.9011030495166779e-02
    z[8,7,5]  R2348     4.8354193568229675e-01
    z[8,7,5]  R2349     -1.7072671651840210e-01
    z[8,7,5]  R2350     -8.4060803055763245e-02
    z[8,7,5]  R2351     -2.6964968442916870e-01
    z[8,7,5]  R2352     6.3986754417419434e-01
    z[8,7,5]  R2353     -3.6593699455261230e-01
    z[8,7,5]  R2354     -2.7578333020210266e-01
    z[8,7,5]  R2355     -5.6960654258728027e-01
    z[8,7,5]  R2356     1.9624894857406616e-01
    z[8,7,5]  R2357     -1.2349840998649597e-01
    z[8,7,5]  R2358     -3.6559337377548218e-01
    z[8,7,5]  R2359     -3.2811611890792847e-01
    z[8,7,5]  R2360     -3.3112549781799316e-01
    z[8,7,5]  R2361     4.6616134047508240e-01
    z[8,7,5]  R2362     3.7009748630225658e-03
    z[8,7,5]  R2363     -5.0836455821990967e-01
    z[8,7,5]  R2364     3.3694821596145630e-01
    z[8,7,5]  R2365     -6.3688290119171143e-01
    z[8,7,5]  R2366     -0.508578896522522
    z[8,7,5]  R2367     -7.3330736160278320e-01
    z[8,7,5]  R2368     -1.1799383908510208e-01
    z[8,7,5]  R2369     5.1627850532531738e-01
    z[8,7,5]  R2370     1.7205353826284409e-02
    z[8,7,5]  R2371     6.1767673492431641e-01
    z[8,7,5]  R2372     -2.2750230133533478e-01
    z[8,7,5]  R2373     -3.3121803402900696e-01
    z[8,7,5]  R2374     -6.4543688297271729e-01
    z[8,7,5]  R2375     -7.2935491800308228e-02
    z[8,7,5]  R2376     -8.6584746837615967e-02
    z[8,7,5]  R2377     -1.9172337651252747e-01
    z[8,7,5]  R2378     -3.9301192760467529e-01
    z[8,7,5]  R2379     -6.5661981701850891e-02
    z[8,7,5]  R2380     6.2302328646183014e-02
    z[8,7,5]  R2381     3.0315449833869934e-01
    z[8,7,6]  R71       1
    z[8,7,6]  R80       -1
    z[8,7,6]  R2260     -1
    z[8,7,6]  R2261     1
    z[8,7,6]  R2262     0.715579092502594
    z[8,7,6]  R2263     -9.9180653691291809e-02
    z[8,7,6]  R2264     -3.1751450896263123e-01
    z[8,7,6]  R2265     -1.2775610387325287e-01
    z[8,7,6]  R2266     -1.9601227343082428e-01
    z[8,7,6]  R2267     -4.3291427195072174e-02
    z[8,7,6]  R2268     3.5004043579101562e-01
    z[8,7,6]  R2269     4.1487994790077209e-01
    z[8,7,6]  R2270     -1.5894404053688049e-01
    z[8,7,6]  R2271     -0.0661550909280777
    z[8,7,6]  R2272     -3.2657498121261597e-01
    z[8,7,6]  R2273     -5.6380033493041992e-01
    z[8,7,6]  R2274     -4.2768073081970215e-01
    z[8,7,6]  R2275     3.3474865555763245e-01
    z[8,7,6]  R2276     1.1454010009765625e-01
    z[8,7,6]  R2277     1.3956645131111145e-01
    z[8,7,6]  R2278     -1.0822586715221405e-02
    z[8,7,6]  R2279     -1.2186323851346970e-01
    z[8,7,6]  R2280     -6.1505012214183807e-02
    z[8,7,6]  R2281     5.6634787470102310e-02
    z[8,7,6]  R2282     2.3918713629245758e-01
    z[8,7,6]  R2283     1.6429321467876434e-01
    z[8,7,6]  R2284     -4.9106314778327942e-02
    z[8,7,6]  R2285     4.5863509178161621e-01
    z[8,7,6]  R2286     -1.5227811038494110e-01
    z[8,7,6]  R2287     4.9847438931465149e-03
    z[8,7,6]  R2288     1.9000843167304993e-01
    z[8,7,6]  R2289     -6.0314185917377472e-02
    z[8,7,6]  R2290     -6.2600302696228027e-01
    z[8,7,6]  R2291     3.4400549530982971e-01
    z[8,7,6]  R2292     3.3920171856880188e-01
    z[8,7,6]  R2293     1.7776845395565033e-01
    z[8,7,6]  R2294     -7.7110564708709717e-01
    z[8,7,6]  R2295     -4.5317225158214569e-02
    z[8,7,6]  R2296     -6.3411140441894531e-01
    z[8,7,6]  R2297     -6.7915320396423340e-02
    z[8,7,6]  R2298     -3.2243371009826660e-01
    z[8,7,6]  R2299     0.129832461476326
    z[8,7,6]  R2300     -1.0833974182605743e-01
    z[8,7,6]  R2301     -1.0275018960237503e-01
    z[8,7,6]  R2302     -6.9056069850921631e-01
    z[8,7,6]  R2303     -3.1261447817087173e-02
    z[8,7,6]  R2304     -7.3703393340110779e-02
    z[8,7,6]  R2305     -6.4319044351577759e-01
    z[8,7,6]  R2306     -1.0318081825971603e-01
    z[8,7,6]  R2307     -0.0948491171002388
    z[8,7,6]  R2308     -8.9268978626932949e-05
    z[8,7,6]  R2309     1.3175293803215027e-01
    z[8,7,6]  R2310     4.3359977006912231e-01
    z[8,7,6]  R2311     2.3819006979465485e-01
    z[8,7,6]  R2312     -3.9062026143074036e-01
    z[8,7,6]  R2313     3.2532146573066711e-01
    z[8,7,6]  R2314     4.3012522161006927e-02
    z[8,7,6]  R2315     2.5615417957305908e-01
    z[8,7,6]  R2316     -2.9138103127479553e-01
    z[8,7,6]  R2317     1.3356015086174011e-01
    z[8,7,6]  R2318     1.5730434656143188e-01
    z[8,7,6]  R2319     -4.3593651056289673e-01
    z[8,7,6]  R2320     -0.140225350856781
    z[8,7,6]  R2321     -2.5206431746482849e-01
    z[8,7,6]  R2322     -1.5787303447723389e-02
    z[8,7,6]  R2323     -4.1746541857719421e-02
    z[8,7,6]  R2324     6.3529871404170990e-03
    z[8,7,6]  R2325     2.9483121633529663e-01
    z[8,7,6]  R2326     2.6193094253540039e-01
    z[8,7,6]  R2327     -9.3920081853866577e-02
    z[8,7,6]  R2328     -1.7072544991970062e-01
    z[8,7,6]  R2329     2.5153619050979614e-01
    z[8,7,6]  R2330     2.4349084123969078e-02
    z[8,7,6]  R2331     -7.0670828223228455e-02
    z[8,7,6]  R2332     -4.9534910917282104e-01
    z[8,7,6]  R2333     -5.1896870136260986e-01
    z[8,7,6]  R2334     -2.1348045766353607e-01
    z[8,7,6]  R2335     6.5155699849128723e-02
    z[8,7,6]  R2336     -3.8442060351371765e-01
    z[8,7,6]  R2337     -3.6522826552391052e-01
    z[8,7,6]  R2338     -5.3321099281311035e-01
    z[8,7,6]  R2339     -4.1150754690170288e-01
    z[8,7,6]  R2340     -2.2725136578083038e-01
    z[8,7,6]  R2341     -4.4010943174362183e-01
    z[8,7,6]  R2342     4.9814966320991516e-01
    z[8,7,6]  R2343     -5.5191016197204590e-01
    z[8,7,6]  R2344     5.1421072334051132e-02
    z[8,7,6]  R2345     -3.4445410966873169e-01
    z[8,7,6]  R2346     -5.1716709136962891e-01
    z[8,7,6]  R2347     -5.8411377668380737e-01
    z[8,7,6]  R2348     -1.1579652875661850e-01
    z[8,7,6]  R2349     -1.8633359670639038e-01
    z[8,7,6]  R2350     5.3940999507904053e-01
    z[8,7,6]  R2351     -1.0724445432424545e-01
    z[8,7,6]  R2352     1.7643353343009949e-01
    z[8,7,6]  R2353     3.0668148398399353e-01
    z[8,7,6]  R2354     -1.1719116568565369e-01
    z[8,7,6]  R2355     3.0471768975257874e-01
    z[8,7,6]  R2356     -2.2337767481803894e-01
    z[8,7,6]  R2357     1.4146524667739868e-01
    z[8,7,6]  R2358     1.2998740375041962e-01
    z[8,7,6]  R2359     -1.1390867084264755e-01
    z[8,7,6]  R2360     1.6196960210800171e-01
    z[8,7,6]  R2361     1.6091284155845642e-01
    z[8,7,6]  R2362     -1.6700872778892517e-01
    z[8,7,6]  R2363     -3.6162579059600830e-01
    z[8,7,6]  R2364     -1.2262653559446335e-01
    z[8,7,6]  R2365     -2.0207743346691132e-01
    z[8,7,6]  R2366     -4.9447190761566162e-01
    z[8,7,6]  R2367     -0.0311052855104208
    z[8,7,6]  R2368     -1.8951158225536346e-01
    z[8,7,6]  R2369     -2.0190356671810150e-01
    z[8,7,6]  R2370     -1.4829598367214203e-01
    z[8,7,6]  R2371     1.8061019480228424e-02
    z[8,7,6]  R2372     9.9628299474716187e-02
    z[8,7,6]  R2373     2.3286198079586029e-01
    z[8,7,6]  R2374     -6.2215197831392288e-02
    z[8,7,6]  R2375     3.0210867524147034e-01
    z[8,7,6]  R2376     3.2108891010284424e-01
    z[8,7,6]  R2377     -2.5963318347930908e-01
    z[8,7,6]  R2378     3.4084182232618332e-02
    z[8,7,6]  R2379     1.3686721026897430e-01
    z[8,7,6]  R2380     2.8160536289215088e-01
    z[8,7,6]  R2381     3.3674296736717224e-01
    z[8,9,0]  R74       -1
    z[8,9,0]  R83       1
    z[8,9,0]  R2382     -1
    z[8,9,0]  R2383     1
    z[8,9,0]  R2396     -1.2852829694747925e-01
    z[8,9,0]  R2397     -0.0594470389187336
    z[8,9,0]  R2398     -6.5190011262893677e-01
    z[8,9,0]  R2399     1.6146008670330048e-01
    z[8,9,0]  R2400     -9.2804804444313049e-02
    z[8,9,0]  R2401     -6.5555781126022339e-01
    z[8,9,0]  R2402     -7.3388135433197021e-01
    z[8,9,0]  R2403     -7.4394792318344116e-01
    z[8,9,0]  R2404     -8.0741649866104126e-01
    z[8,9,0]  R2405     -8.0002427101135254e-01
    z[8,9,0]  R2406     -3.9988499134778976e-02
    z[8,9,0]  R2407     2.7581200003623962e-01
    z[8,9,0]  R2408     2.8731355071067810e-01
    z[8,9,0]  R2409     0.05734858289361
    z[8,9,0]  R2410     4.4874057173728943e-01
    z[8,9,0]  R2411     7.2059106826782227e-01
    z[8,9,0]  R2412     6.0280710458755493e-01
    z[8,9,0]  R2413     7.8249531984329224e-01
    z[8,9,0]  R2414     5.7844305038452148e-01
    z[8,9,0]  R2415     6.1135005950927734e-01
    z[8,9,0]  R2416     6.1014586687088013e-01
    z[8,9,0]  R2417     -3.5574698448181152e-01
    z[8,9,0]  R2418     2.7639642357826233e-01
    z[8,9,0]  R2419     -2.6914203166961670e-01
    z[8,9,0]  R2420     4.6433284878730774e-01
    z[8,9,0]  R2421     -0.853218138217926
    z[8,9,0]  R2422     2.8995686769485474e-01
    z[8,9,0]  R2423     3.1004312634468079e-01
    z[8,9,0]  R2424     -2.2425624728202820e-01
    z[8,9,0]  R2425     1.5226773917675018e-01
    z[8,9,0]  R2426     -1.2880882620811462e-01
    z[8,9,0]  R2427     2.9781904071569443e-02
    z[8,9,0]  R2428     -2.7811175584793091e-01
    z[8,9,0]  R2429     -2.7319031953811646e-01
    z[8,9,0]  R2430     -0.69287109375
    z[8,9,0]  R2431     3.6316105723381042e-01
    z[8,9,0]  R2432     3.6248227953910828e-01
    z[8,9,0]  R2433     3.1406599283218384e-01
    z[8,9,0]  R2434     2.3585869371891022e-01
    z[8,9,0]  R2435     3.6995249986648560e-01
    z[8,9,0]  R2436     -4.2968600988388062e-02
    z[8,9,0]  R2437     0.402852863073349
    z[8,9,0]  R2438     4.1930586099624634e-01
    z[8,9,0]  R2439     3.7883815169334412e-01
    z[8,9,0]  R2440     -3.2579079270362854e-02
    z[8,9,0]  R2441     -7.9975659027695656e-03
    z[8,9,0]  R2442     5.0608873367309570e-01
    z[8,9,0]  R2443     3.5544195771217346e-01
    z[8,9,0]  R2444     3.9803826808929443e-01
    z[8,9,0]  R2445     4.8468944430351257e-01
    z[8,9,0]  R2446     2.9108244180679321e-01
    z[8,9,0]  R2447     1.0858749598264694e-01
    z[8,9,0]  R2448     -1.3523830473423004e-01
    z[8,9,0]  R2449     -3.9431478828191757e-02
    z[8,9,0]  R2450     -7.5746321678161621e-01
    z[8,9,0]  R2451     -4.9538934230804443e-01
    z[8,9,0]  R2452     -3.5292613506317139e-01
    z[8,9,0]  R2453     -5.4493683576583862e-01
    z[8,9,0]  R2454     -6.1947625875473022e-01
    z[8,9,0]  R2455     2.3906965553760529e-01
    z[8,9,0]  R2456     -1.3276743888854980e-01
    z[8,9,0]  R2457     -8.9868523180484772e-02
    z[8,9,0]  R2458     4.7234547138214111e-01
    z[8,9,0]  R2459     4.7172546386718750e-01
    z[8,9,0]  R2460     6.4668184518814087e-01
    z[8,9,0]  R2461     7.9206550121307373e-01
    z[8,9,0]  R2462     2.9894074797630310e-01
    z[8,9,0]  R2463     -1.5389275550842285e-01
    z[8,9,0]  R2464     4.1839218139648438e-01
    z[8,9,0]  R2465     3.1511563062667847e-01
    z[8,9,0]  R2466     -1.0333719849586487e-01
    z[8,9,0]  R2467     1.1937688291072845e-01
    z[8,9,0]  R2468     2.9293406009674072e-01
    z[8,9,0]  R2469     4.3236732482910156e-02
    z[8,9,0]  R2470     2.5039976835250854e-01
    z[8,9,1]  R75       -1
    z[8,9,1]  R84       1
    z[8,9,1]  R2384     -1
    z[8,9,1]  R2385     1
    z[8,9,1]  R2396     1.1826018244028091e-01
    z[8,9,1]  R2397     8.9327402412891388e-02
    z[8,9,1]  R2398     -0.530619740486145
    z[8,9,1]  R2399     -1.0871769627556205e-03
    z[8,9,1]  R2400     8.6960613727569580e-02
    z[8,9,1]  R2401     -5.6294459104537964e-01
    z[8,9,1]  R2402     -5.4096710681915283e-01
    z[8,9,1]  R2403     -3.8441410660743713e-01
    z[8,9,1]  R2404     1.0363811999559402e-01
    z[8,9,1]  R2405     5.5503904819488525e-02
    z[8,9,1]  R2406     2.9511308670043945e-01
    z[8,9,1]  R2407     1.5450754761695862e-01
    z[8,9,1]  R2408     1.7042127251625061e-01
    z[8,9,1]  R2409     2.0879945158958435e-01
    z[8,9,1]  R2410     3.2493349909782410e-01
    z[8,9,1]  R2411     3.6775767803192139e-01
    z[8,9,1]  R2412     0.314726322889328
    z[8,9,1]  R2413     5.4211676120758057e-01
    z[8,9,1]  R2414     2.5673910975456238e-01
    z[8,9,1]  R2415     2.7103403210639954e-01
    z[8,9,1]  R2416     3.7999680638313293e-01
    z[8,9,1]  R2417     5.8790612220764160e-01
    z[8,9,1]  R2418     5.4605388641357422e-01
    z[8,9,1]  R2419     4.7140055894851685e-01
    z[8,9,1]  R2420     0.66666579246521
    z[8,9,1]  R2421     1.8648330867290497e-01
    z[8,9,1]  R2422     -1.8866054713726044e-01
    z[8,9,1]  R2423     -2.3718793690204620e-01
    z[8,9,1]  R2424     4.1518858075141907e-01
    z[8,9,1]  R2425     -3.0725511908531189e-01
    z[8,9,1]  R2426     3.3868480473756790e-02
    z[8,9,1]  R2427     0.454218327999115
    z[8,9,1]  R2428     -2.0671127364039421e-02
    z[8,9,1]  R2429     -4.8183876276016235e-01
    z[8,9,1]  R2430     2.5234025716781616e-01
    z[8,9,1]  R2431     -1.8473502993583679e-01
    z[8,9,1]  R2432     -3.3799788355827332e-01
    z[8,9,1]  R2433     -5.0157308578491211e-01
    z[8,9,1]  R2434     -5.0875627994537354e-01
    z[8,9,1]  R2435     -4.6851876378059387e-01
    z[8,9,1]  R2436     2.0195086300373077e-01
    z[8,9,1]  R2437     -2.4059966206550598e-01
    z[8,9,1]  R2438     1.0994620621204376e-01
    z[8,9,1]  R2439     -2.4736025929450989e-01
    z[8,9,1]  R2440     -1.8016017973423004e-01
    z[8,9,1]  R2441     -2.6322522759437561e-01
    z[8,9,1]  R2442     -0.670713484287262
    z[8,9,1]  R2443     -8.1953620910644531e-01
    z[8,9,1]  R2444     -6.3240230083465576e-01
    z[8,9,1]  R2445     -7.2972595691680908e-01
    z[8,9,1]  R2446     -8.2997870445251465e-01
    z[8,9,1]  R2447     -7.7935463190078735e-01
    z[8,9,1]  R2448     -5.9373527765274048e-01
    z[8,9,1]  R2449     -6.0379111766815186e-01
    z[8,9,1]  R2450     -4.7035849094390869e-01
    z[8,9,1]  R2451     -1.7054872214794159e-01
    z[8,9,1]  R2452     -3.7646931409835815e-01
    z[8,9,1]  R2453     -4.0305751562118530e-01
    z[8,9,1]  R2454     1.5257827937602997e-01
    z[8,9,1]  R2455     1.5584002435207367e-01
    z[8,9,1]  R2456     6.6454339027404785e-01
    z[8,9,1]  R2457     5.0379019975662231e-01
    z[8,9,1]  R2458     5.3773826360702515e-01
    z[8,9,1]  R2459     5.3363138437271118e-01
    z[8,9,1]  R2460     4.7076827287673950e-01
    z[8,9,1]  R2461     8.5063174366950989e-02
    z[8,9,1]  R2462     -4.7014467418193817e-04
    z[8,9,1]  R2463     6.5266913175582886e-01
    z[8,9,1]  R2464     -1.2414242327213287e-01
    z[8,9,1]  R2465     5.1841062307357788e-01
    z[8,9,1]  R2466     -2.7463731169700623e-01
    z[8,9,1]  R2467     3.5437962412834167e-01
    z[8,9,1]  R2468     4.5150133967399597e-01
    z[8,9,1]  R2469     6.3977748155593872e-01
    z[8,9,1]  R2470     6.2359595298767090e-01
    z[8,9,2]  R76       -1
    z[8,9,2]  R85       1
    z[8,9,2]  R2386     -1
    z[8,9,2]  R2387     1
    z[8,9,2]  R2396     -4.4401079416275024e-01
    z[8,9,2]  R2397     -3.2758188247680664e-01
    z[8,9,2]  R2398     2.2153076529502869e-01
    z[8,9,2]  R2399     -0.675586462020874
    z[8,9,2]  R2400     -6.5137469768524170e-01
    z[8,9,2]  R2401     1.7457915842533112e-01
    z[8,9,2]  R2402     4.3856389820575714e-02
    z[8,9,2]  R2403     -2.6346400380134583e-02
    z[8,9,2]  R2404     -2.4760743975639343e-01
    z[8,9,2]  R2405     -4.2816975712776184e-01
    z[8,9,2]  R2406     -3.7379637360572815e-01
    z[8,9,2]  R2407     -1.9351994991302490e-01
    z[8,9,2]  R2408     -2.0499213039875031e-01
    z[8,9,2]  R2409     -1.1064240336418152e-01
    z[8,9,2]  R2410     -3.9540970325469971e-01
    z[8,9,2]  R2411     -5.2497762441635132e-01
    z[8,9,2]  R2412     2.4224289227277040e-03
    z[8,9,2]  R2413     -0.0970020443201065
    z[8,9,2]  R2414     -1.9662268459796906e-01
    z[8,9,2]  R2415     -2.8607437014579773e-01
    z[8,9,2]  R2416     -5.1499092578887939e-01
    z[8,9,2]  R2417     -4.9329277127981186e-02
    z[8,9,2]  R2418     1.0384587198495865e-01
    z[8,9,2]  R2419     4.3746861815452576e-01
    z[8,9,2]  R2420     4.8087587952613831e-01
    z[8,9,2]  R2421     -2.3073922097682953e-01
    z[8,9,2]  R2422     -3.6082801222801208e-01
    z[8,9,2]  R2423     -3.0009731650352478e-01
    z[8,9,2]  R2424     0.562061607837677
    z[8,9,2]  R2425     -5.3335064649581909e-01
    z[8,9,2]  R2426     -8.9149087667465210e-01
    z[8,9,2]  R2427     0.189592182636261
    z[8,9,2]  R2428     -5.0809472799301147e-01
    z[8,9,2]  R2429     -5.5949020385742188e-01
    z[8,9,2]  R2430     1.5865002572536469e-01
    z[8,9,2]  R2431     -2.4356766045093536e-01
    z[8,9,2]  R2432     -4.4351139664649963e-01
    z[8,9,2]  R2433     5.8374601602554321e-01
    z[8,9,2]  R2434     5.8935302495956421e-01
    z[8,9,2]  R2435     6.2763148546218872e-01
    z[8,9,2]  R2436     -4.6040698885917664e-01
    z[8,9,2]  R2437     -6.3620215654373169e-01
    z[8,9,2]  R2438     -9.9123053252696991e-02
    z[8,9,2]  R2439     -2.5601658225059509e-01
    z[8,9,2]  R2440     7.2802132368087769e-01
    z[8,9,2]  R2441     6.6893249750137329e-01
    z[8,9,2]  R2442     2.6052811741828918e-01
    z[8,9,2]  R2443     2.3623399436473846e-02
    z[8,9,2]  R2444     7.3987804353237152e-02
    z[8,9,2]  R2445     7.5788281857967377e-02
    z[8,9,2]  R2446     -3.7251576781272888e-01
    z[8,9,2]  R2447     1.8337865173816681e-01
    z[8,9,2]  R2448     3.5857531428337097e-01
    z[8,9,2]  R2449     0.437838077545166
    z[8,9,2]  R2450     -2.1067656576633453e-01
    z[8,9,2]  R2451     3.9047864079475403e-01
    z[8,9,2]  R2452     -3.7782189249992371e-01
    z[8,9,2]  R2453     -2.3185496032238007e-01
    z[8,9,2]  R2454     -4.4014781713485718e-01
    z[8,9,2]  R2455     7.9295235872268677e-01
    z[8,9,2]  R2456     2.4608774110674858e-02
    z[8,9,2]  R2457     -2.2013923525810242e-01
    z[8,9,2]  R2458     -3.3044016361236572e-01
    z[8,9,2]  R2459     -1.3546082377433777e-01
    z[8,9,2]  R2460     -1.5414842963218689e-01
    z[8,9,2]  R2461     -5.7929926551878452e-03
    z[8,9,2]  R2462     7.7107146382331848e-02
    z[8,9,2]  R2463     -2.2462606430053711e-01
    z[8,9,2]  R2464     -7.6619662344455719e-02
    z[8,9,2]  R2465     -3.8277745246887207e-01
    z[8,9,2]  R2466     -5.3804613649845123e-02
    z[8,9,2]  R2467     -7.9975193738937378e-01
    z[8,9,2]  R2468     -0.514900803565979
    z[8,9,2]  R2469     1.4151570200920105e-01
    z[8,9,2]  R2470     4.7723045572638512e-03
    z[8,9,3]  R77       -1
    z[8,9,3]  R86       1
    z[8,9,3]  R2388     -1
    z[8,9,3]  R2389     1
    z[8,9,3]  R2396     3.7399226427078247e-01
    z[8,9,3]  R2397     8.4463542699813843e-01
    z[8,9,3]  R2398     3.7432754039764404e-01
    z[8,9,3]  R2399     -2.0353691279888153e-01
    z[8,9,3]  R2400     -5.0228089094161987e-01
    z[8,9,3]  R2401     6.9852888584136963e-02
    z[8,9,3]  R2402     -1.5249375998973846e-01
    z[8,9,3]  R2403     3.0748987197875977e-01
    z[8,9,3]  R2404     4.4161000847816467e-01
    z[8,9,3]  R2405     2.7727040648460388e-01
    z[8,9,3]  R2406     -4.6838602423667908e-01
    z[8,9,3]  R2407     2.8910410404205322e-01
    z[8,9,3]  R2408     1.7768730223178864e-01
    z[8,9,3]  R2409     -7.2494372725486755e-02
    z[8,9,3]  R2410     1.2226977199316025e-01
    z[8,9,3]  R2411     -1.2317145615816116e-01
    z[8,9,3]  R2412     -6.4032179117202759e-01
    z[8,9,3]  R2413     -2.4975667893886566e-01
    z[8,9,3]  R2414     -2.7408912777900696e-01
    z[8,9,3]  R2415     -5.5452466011047363e-01
    z[8,9,3]  R2416     1.2485326826572418e-01
    z[8,9,3]  R2417     -6.5923802554607391e-02
    z[8,9,3]  R2418     2.4701729416847229e-01
    z[8,9,3]  R2419     2.1766215562820435e-01
    z[8,9,3]  R2420     5.1282446831464767e-02
    z[8,9,3]  R2421     -1.2317837774753571e-01
    z[8,9,3]  R2422     -6.5467965602874756e-01
    z[8,9,3]  R2423     -6.2769198417663574e-01
    z[8,9,3]  R2424     -2.1077285706996918e-01
    z[8,9,3]  R2425     -6.5159630775451660e-01
    z[8,9,3]  R2426     2.6033643633127213e-02
    z[8,9,3]  R2427     5.2104723453521729e-01
    z[8,9,3]  R2428     1.2494331598281860e-01
    z[8,9,3]  R2429     4.4211512804031372e-01
    z[8,9,3]  R2430     2.0982641726732254e-02
    z[8,9,3]  R2431     -7.5801765918731689e-01
    z[8,9,3]  R2432     -6.4669466018676758e-01
    z[8,9,3]  R2433     -3.5471069812774658e-01
    z[8,9,3]  R2434     -2.7713820338249207e-01
    z[8,9,3]  R2435     -0.333706796169281
    z[8,9,3]  R2436     -2.9114505648612976e-01
    z[8,9,3]  R2437     -0.43654665350914
    z[8,9,3]  R2438     -1.5885820984840393e-01
    z[8,9,3]  R2439     6.0308102518320084e-02
    z[8,9,3]  R2440     -6.2654095888137817e-01
    z[8,9,3]  R2441     -0.657532811164856
    z[8,9,3]  R2442     2.5557219982147217e-01
    z[8,9,3]  R2443     3.0942326411604881e-02
    z[8,9,3]  R2444     1.4529527723789215e-01
    z[8,9,3]  R2445     1.4006929099559784e-01
    z[8,9,3]  R2446     0.00329585955478251
    z[8,9,3]  R2447     -3.4972104430198669e-01
    z[8,9,3]  R2448     -2.3019210994243622e-01
    z[8,9,3]  R2449     2.3709204792976379e-01
    z[8,9,3]  R2450     -8.1858143210411072e-02
    z[8,9,3]  R2451     6.4881277084350586e-01
    z[8,9,3]  R2452     5.5613040924072266e-01
    z[8,9,3]  R2453     9.4230584800243378e-02
    z[8,9,3]  R2454     -4.1764503717422485e-01
    z[8,9,3]  R2455     4.4771265983581543e-01
    z[8,9,3]  R2456     1.3020020909607410e-02
    z[8,9,3]  R2457     5.1018267869949341e-01
    z[8,9,3]  R2458     3.1320884823799133e-01
    z[8,9,3]  R2459     -6.6068537533283234e-02
    z[8,9,3]  R2460     -4.3311378359794617e-01
    z[8,9,3]  R2461     1.6431353986263275e-01
    z[8,9,3]  R2462     -1.0704349726438522e-01
    z[8,9,3]  R2463     6.0342226177453995e-02
    z[8,9,3]  R2464     3.1790229678153992e-01
    z[8,9,3]  R2465     -3.4703891724348068e-02
    z[8,9,3]  R2466     -2.5287717580795288e-01
    z[8,9,3]  R2467     -1.0735470056533813e-01
    z[8,9,3]  R2468     -4.0629172325134277e-01
    z[8,9,3]  R2469     -7.2742298245429993e-02
    z[8,9,3]  R2470     -5.4337286949157715e-01
    z[8,9,4]  R78       -1
    z[8,9,4]  R87       1
    z[8,9,4]  R2390     -1
    z[8,9,4]  R2391     1
    z[8,9,4]  R2396     2.7456298470497131e-01
    z[8,9,4]  R2397     -9.5664508640766144e-02
    z[8,9,4]  R2398     -4.4944092631340027e-02
    z[8,9,4]  R2399     -4.2058318853378296e-01
    z[8,9,4]  R2400     8.3651952445507050e-02
    z[8,9,4]  R2401     1.6183950006961823e-01
    z[8,9,4]  R2402     1.2228089570999146e-01
    z[8,9,4]  R2403     1.0831851512193680e-01
    z[8,9,4]  R2404     4.1239753365516663e-02
    z[8,9,4]  R2405     2.6689562201499939e-01
    z[8,9,4]  R2406     -1.4906527101993561e-01
    z[8,9,4]  R2407     -2.0540687441825867e-01
    z[8,9,4]  R2408     2.5316244363784790e-01
    z[8,9,4]  R2409     -6.5151840448379517e-01
    z[8,9,4]  R2410     -2.9696115851402283e-01
    z[8,9,4]  R2411     -1.1717782914638519e-01
    z[8,9,4]  R2412     1.4127730391919613e-02
    z[8,9,4]  R2413     -7.0654176175594330e-02
    z[8,9,4]  R2414     4.1520255804061890e-01
    z[8,9,4]  R2415     0.387582391500473
    z[8,9,4]  R2416     2.3515014350414276e-01
    z[8,9,4]  R2417     -3.9228785037994385e-01
    z[8,9,4]  R2418     6.2750995159149170e-01
    z[8,9,4]  R2419     1.9426903128623962e-01
    z[8,9,4]  R2420     -2.2242219746112823e-01
    z[8,9,4]  R2421     3.1424409151077271e-01
    z[8,9,4]  R2422     -4.5627325773239136e-01
    z[8,9,4]  R2423     -5.8904582262039185e-01
    z[8,9,4]  R2424     -1.0184727609157562e-01
    z[8,9,4]  R2425     -1.0739585757255554e-01
    z[8,9,4]  R2426     -2.1908564865589142e-01
    z[8,9,4]  R2427     -4.3875795602798462e-01
    z[8,9,4]  R2428     1.7991036176681519e-01
    z[8,9,4]  R2429     4.2504531145095825e-01
    z[8,9,4]  R2430     1.6858136653900146e-01
    z[8,9,4]  R2431     -1.0200709104537964e-01
    z[8,9,4]  R2432     1.5478786826133728e-01
    z[8,9,4]  R2433     -4.6223394572734833e-02
    z[8,9,4]  R2434     -3.5091400146484375e-02
    z[8,9,4]  R2435     -1.3885188102722168e-01
    z[8,9,4]  R2436     -4.1444721817970276e-01
    z[8,9,4]  R2437     -3.9981588721275330e-01
    z[8,9,4]  R2438     -8.6185067892074585e-01
    z[8,9,4]  R2439     -0.408926784992218
    z[8,9,4]  R2440     -0.0832945927977562
    z[8,9,4]  R2441     7.2540216147899628e-02
    z[8,9,4]  R2442     -9.7592107951641083e-02
    z[8,9,4]  R2443     -0.176550030708313
    z[8,9,4]  R2444     1.3600136339664459e-01
    z[8,9,4]  R2445     2.0202951133251190e-01
    z[8,9,4]  R2446     2.1075251698493958e-01
    z[8,9,4]  R2447     2.9115694761276245e-01
    z[8,9,4]  R2448     4.3395614624023438e-01
    z[8,9,4]  R2449     2.1299500763416290e-01
    z[8,9,4]  R2450     3.5171902179718018e-01
    z[8,9,4]  R2451     2.6832661032676697e-01
    z[8,9,4]  R2452     4.2752283811569214e-01
    z[8,9,4]  R2453     -2.6234707236289978e-01
    z[8,9,4]  R2454     -4.2021086812019348e-01
    z[8,9,4]  R2455     -2.1181757748126984e-01
    z[8,9,4]  R2456     0.724141538143158
    z[8,9,4]  R2457     1.9579641520977020e-01
    z[8,9,4]  R2458     -3.8013958930969238e-01
    z[8,9,4]  R2459     -4.9037012457847595e-01
    z[8,9,4]  R2460     -0.256389856338501
    z[8,9,4]  R2461     -2.0562279224395752e-01
    z[8,9,4]  R2462     -5.0673949718475342e-01
    z[8,9,4]  R2463     -5.8236700296401978e-01
    z[8,9,4]  R2464     -6.7370104789733887e-01
    z[8,9,4]  R2465     -5.4973214864730835e-01
    z[8,9,4]  R2466     -5.8169674873352051e-01
    z[8,9,4]  R2467     -1.6659784317016602e-01
    z[8,9,4]  R2468     -2.9732853174209595e-01
    z[8,9,4]  R2469     -4.4157716631889343e-01
    z[8,9,4]  R2470     -4.3555518984794617e-01
    z[8,9,5]  R79       -1
    z[8,9,5]  R88       1
    z[8,9,5]  R2392     -1
    z[8,9,5]  R2393     1
    z[8,9,5]  R2396     -2.1222855150699615e-01
    z[8,9,5]  R2397     -3.8571909070014954e-01
    z[8,9,5]  R2398     -3.7898812443017960e-02
    z[8,9,5]  R2399     -5.3185838460922241e-01
    z[8,9,5]  R2400     -5.1169478893280029e-01
    z[8,9,5]  R2401     -4.3579104542732239e-01
    z[8,9,5]  R2402     -7.8193083405494690e-02
    z[8,9,5]  R2403     1.4023149013519287e-01
    z[8,9,5]  R2404     -2.3247583210468292e-01
    z[8,9,5]  R2405     1.4512902498245239e-01
    z[8,9,5]  R2406     6.5063685178756714e-01
    z[8,9,5]  R2407     6.4727210998535156e-01
    z[8,9,5]  R2408     7.5353229045867920e-01
    z[8,9,5]  R2409     6.3173079490661621e-01
    z[8,9,5]  R2410     0.648418128490448
    z[8,9,5]  R2411     1.4669895172119141e-01
    z[8,9,5]  R2412     -0.35670205950737
    z[8,9,5]  R2413     4.6691350638866425e-02
    z[8,9,5]  R2414     -5.5635178089141846e-01
    z[8,9,5]  R2415     -1.0013957321643829e-01
    z[8,9,5]  R2416     -3.0002406239509583e-01
    z[8,9,5]  R2417     -5.8322310447692871e-01
    z[8,9,5]  R2418     -3.9679780602455139e-01
    z[8,9,5]  R2419     4.6744191646575928e-01
    z[8,9,5]  R2420     -1.8281127512454987e-01
    z[8,9,5]  R2421     2.6467922329902649e-01
    z[8,9,5]  R2422     -2.7792349457740784e-01
    z[8,9,5]  R2423     -1.1378429830074310e-01
    z[8,9,5]  R2424     1.2139365822076797e-01
    z[8,9,5]  R2425     -2.0855334401130676e-01
    z[8,9,5]  R2426     1.5417899191379547e-01
    z[8,9,5]  R2427     5.1112931966781616e-01
    z[8,9,5]  R2428     -1.4657360315322876e-01
    z[8,9,5]  R2429     4.4567704200744629e-02
    z[8,9,5]  R2430     -1.1271034367382526e-02
    z[8,9,5]  R2431     -4.3017813563346863e-01
    z[8,9,5]  R2432     -1.0735403746366501e-01
    z[8,9,5]  R2433     4.0523451566696167e-01
    z[8,9,5]  R2434     4.9842372536659241e-01
    z[8,9,5]  R2435     3.2940280437469482e-01
    z[8,9,5]  R2436     1.0949368029832840e-01
    z[8,9,5]  R2437     1.5383474528789520e-01
    z[8,9,5]  R2438     -1.6974768042564392e-01
    z[8,9,5]  R2439     -3.8104841113090515e-01
    z[8,9,5]  R2440     1.6225872933864594e-01
    z[8,9,5]  R2441     1.9123287498950958e-01
    z[8,9,5]  R2442     3.8897478580474854e-01
    z[8,9,5]  R2443     3.8984280824661255e-01
    z[8,9,5]  R2444     4.5666497945785522e-01
    z[8,9,5]  R2445     3.3115327358245850e-01
    z[8,9,5]  R2446     -4.7877408564090729e-02
    z[8,9,5]  R2447     -2.8288233280181885e-01
    z[8,9,5]  R2448     1.3415230810642242e-01
    z[8,9,5]  R2449     -3.6059868335723877e-01
    z[8,9,5]  R2450     3.1892888247966766e-02
    z[8,9,5]  R2451     2.2661669552326202e-01
    z[8,9,5]  R2452     1.4870745129883289e-02
    z[8,9,5]  R2453     2.2744987905025482e-01
    z[8,9,5]  R2454     -2.8606725856661797e-02
    z[8,9,5]  R2455     -2.1060074865818024e-01
    z[8,9,5]  R2456     -1.2489126622676849e-01
    z[8,9,5]  R2457     8.5017554461956024e-02
    z[8,9,5]  R2458     -9.6607245504856110e-02
    z[8,9,5]  R2459     4.6893692016601562e-01
    z[8,9,5]  R2460     -2.0405773818492889e-01
    z[8,9,5]  R2461     3.2776159048080444e-01
    z[8,9,5]  R2462     7.9625159502029419e-01
    z[8,9,5]  R2463     -6.5661803819239140e-03
    z[8,9,5]  R2464     -2.2077096998691559e-01
    z[8,9,5]  R2465     -4.2254430055618286e-01
    z[8,9,5]  R2466     6.6329681873321533e-01
    z[8,9,5]  R2467     1.9180832803249359e-01
    z[8,9,5]  R2468     3.3409810066223145e-01
    z[8,9,5]  R2469     5.8726257085800171e-01
    z[8,9,5]  R2470     -1.9228871911764145e-02
    z[8,9,6]  R80       -1
    z[8,9,6]  R89       1
    z[8,9,6]  R2394     -1
    z[8,9,6]  R2395     1
    z[8,9,6]  R2396     0.715579092502594
    z[8,9,6]  R2397     -9.9180653691291809e-02
    z[8,9,6]  R2398     -3.1751450896263123e-01
    z[8,9,6]  R2399     -1.2775610387325287e-01
    z[8,9,6]  R2400     -1.9601227343082428e-01
    z[8,9,6]  R2401     -4.3291427195072174e-02
    z[8,9,6]  R2402     3.5004043579101562e-01
    z[8,9,6]  R2403     4.1487994790077209e-01
    z[8,9,6]  R2404     -1.5894404053688049e-01
    z[8,9,6]  R2405     -0.0661550909280777
    z[8,9,6]  R2406     -3.2657498121261597e-01
    z[8,9,6]  R2407     -5.6380033493041992e-01
    z[8,9,6]  R2408     -4.2768073081970215e-01
    z[8,9,6]  R2409     3.3474865555763245e-01
    z[8,9,6]  R2410     1.1454010009765625e-01
    z[8,9,6]  R2411     1.3956645131111145e-01
    z[8,9,6]  R2412     -1.0822586715221405e-02
    z[8,9,6]  R2413     -1.2186323851346970e-01
    z[8,9,6]  R2414     -6.1505012214183807e-02
    z[8,9,6]  R2415     5.6634787470102310e-02
    z[8,9,6]  R2416     2.3918713629245758e-01
    z[8,9,6]  R2417     1.6429321467876434e-01
    z[8,9,6]  R2418     -4.9106314778327942e-02
    z[8,9,6]  R2419     4.5863509178161621e-01
    z[8,9,6]  R2420     -1.5227811038494110e-01
    z[8,9,6]  R2421     4.9847438931465149e-03
    z[8,9,6]  R2422     1.9000843167304993e-01
    z[8,9,6]  R2423     -6.0314185917377472e-02
    z[8,9,6]  R2424     -6.2600302696228027e-01
    z[8,9,6]  R2425     3.4400549530982971e-01
    z[8,9,6]  R2426     3.3920171856880188e-01
    z[8,9,6]  R2427     1.7776845395565033e-01
    z[8,9,6]  R2428     -7.7110564708709717e-01
    z[8,9,6]  R2429     -4.5317225158214569e-02
    z[8,9,6]  R2430     -6.3411140441894531e-01
    z[8,9,6]  R2431     -6.7915320396423340e-02
    z[8,9,6]  R2432     -3.2243371009826660e-01
    z[8,9,6]  R2433     0.129832461476326
    z[8,9,6]  R2434     -1.0833974182605743e-01
    z[8,9,6]  R2435     -1.0275018960237503e-01
    z[8,9,6]  R2436     -6.9056069850921631e-01
    z[8,9,6]  R2437     -3.1261447817087173e-02
    z[8,9,6]  R2438     -7.3703393340110779e-02
    z[8,9,6]  R2439     -6.4319044351577759e-01
    z[8,9,6]  R2440     -1.0318081825971603e-01
    z[8,9,6]  R2441     -0.0948491171002388
    z[8,9,6]  R2442     -8.9268978626932949e-05
    z[8,9,6]  R2443     1.3175293803215027e-01
    z[8,9,6]  R2444     4.3359977006912231e-01
    z[8,9,6]  R2445     2.3819006979465485e-01
    z[8,9,6]  R2446     2.0228348672389984e-01
    z[8,9,6]  R2447     -2.4512818455696106e-01
    z[8,9,6]  R2448     4.9123266339302063e-01
    z[8,9,6]  R2449     0.458877295255661
    z[8,9,6]  R2450     -1.7089027166366577e-01
    z[8,9,6]  R2451     -1.6945970058441162e-01
    z[8,9,6]  R2452     -0.314144492149353
    z[8,9,6]  R2453     -5.9782350063323975e-01
    z[8,9,6]  R2454     -2.1775241196155548e-01
    z[8,9,6]  R2455     -1.0965825989842415e-02
    z[8,9,6]  R2456     -9.3064224347472191e-04
    z[8,9,6]  R2457     6.1952179670333862e-01
    z[8,9,6]  R2458     -3.5580569505691528e-01
    z[8,9,6]  R2459     -9.8149202764034271e-02
    z[8,9,6]  R2460     2.0360575616359711e-01
    z[8,9,6]  R2461     -0.434345006942749
    z[8,9,6]  R2462     4.9282174557447433e-02
    z[8,9,6]  R2463     -3.9629215002059937e-01
    z[8,9,6]  R2464     -0.447204053401947
    z[8,9,6]  R2465     -5.8996759355068207e-02
    z[8,9,6]  R2466     2.6214540004730225e-01
    z[8,9,6]  R2467     -3.8011962175369263e-01
    z[8,9,6]  R2468     -2.8304505348205566e-01
    z[8,9,6]  R2469     -1.5371902287006378e-01
    z[8,9,6]  R2470     2.5114363431930542e-01
    z[9,8,0]  R74       1
    z[9,8,0]  R83       -1
    z[9,8,0]  R2471     -1
    z[9,8,0]  R2472     1
    z[9,8,0]  R2485     2.9108244180679321e-01
    z[9,8,0]  R2486     1.0858749598264694e-01
    z[9,8,0]  R2487     -1.3523830473423004e-01
    z[9,8,0]  R2488     -3.9431478828191757e-02
    z[9,8,0]  R2489     -7.5746321678161621e-01
    z[9,8,0]  R2490     -4.9538934230804443e-01
    z[9,8,0]  R2491     -3.5292613506317139e-01
    z[9,8,0]  R2492     -5.4493683576583862e-01
    z[9,8,0]  R2493     -6.1947625875473022e-01
    z[9,8,0]  R2494     2.3906965553760529e-01
    z[9,8,0]  R2495     -1.3276743888854980e-01
    z[9,8,0]  R2496     -8.9868523180484772e-02
    z[9,8,0]  R2497     4.7234547138214111e-01
    z[9,8,0]  R2498     4.7172546386718750e-01
    z[9,8,0]  R2499     6.4668184518814087e-01
    z[9,8,0]  R2500     7.9206550121307373e-01
    z[9,8,0]  R2501     2.9894074797630310e-01
    z[9,8,0]  R2502     -1.5389275550842285e-01
    z[9,8,0]  R2503     4.1839218139648438e-01
    z[9,8,0]  R2504     3.1511563062667847e-01
    z[9,8,0]  R2505     -1.0333719849586487e-01
    z[9,8,0]  R2506     1.1937688291072845e-01
    z[9,8,0]  R2507     2.9293406009674072e-01
    z[9,8,0]  R2508     4.3236732482910156e-02
    z[9,8,0]  R2509     2.5039976835250854e-01
    z[9,8,0]  R2510     -1.2852829694747925e-01
    z[9,8,0]  R2511     -0.0594470389187336
    z[9,8,0]  R2512     -6.5190011262893677e-01
    z[9,8,0]  R2513     1.6146008670330048e-01
    z[9,8,0]  R2514     -9.2804804444313049e-02
    z[9,8,0]  R2515     -6.5555781126022339e-01
    z[9,8,0]  R2516     -7.3388135433197021e-01
    z[9,8,0]  R2517     -7.4394792318344116e-01
    z[9,8,0]  R2518     -8.0741649866104126e-01
    z[9,8,0]  R2519     -8.0002427101135254e-01
    z[9,8,0]  R2520     -3.9988499134778976e-02
    z[9,8,0]  R2521     2.7581200003623962e-01
    z[9,8,0]  R2522     2.8731355071067810e-01
    z[9,8,0]  R2523     0.05734858289361
    z[9,8,0]  R2524     4.4874057173728943e-01
    z[9,8,0]  R2525     7.2059106826782227e-01
    z[9,8,0]  R2526     6.0280710458755493e-01
    z[9,8,0]  R2527     7.8249531984329224e-01
    z[9,8,0]  R2528     5.7844305038452148e-01
    z[9,8,0]  R2529     6.1135005950927734e-01
    z[9,8,0]  R2530     6.1014586687088013e-01
    z[9,8,0]  R2531     -3.5574698448181152e-01
    z[9,8,0]  R2532     2.7639642357826233e-01
    z[9,8,0]  R2533     -2.6914203166961670e-01
    z[9,8,0]  R2534     4.6433284878730774e-01
    z[9,8,0]  R2535     -0.853218138217926
    z[9,8,0]  R2536     2.8995686769485474e-01
    z[9,8,0]  R2537     3.1004312634468079e-01
    z[9,8,0]  R2538     -2.2425624728202820e-01
    z[9,8,0]  R2539     1.5226773917675018e-01
    z[9,8,0]  R2540     -1.2880882620811462e-01
    z[9,8,0]  R2541     2.9781904071569443e-02
    z[9,8,0]  R2542     -2.7811175584793091e-01
    z[9,8,0]  R2543     -2.7319031953811646e-01
    z[9,8,0]  R2544     -0.69287109375
    z[9,8,0]  R2545     3.6316105723381042e-01
    z[9,8,0]  R2546     3.6248227953910828e-01
    z[9,8,0]  R2547     3.1406599283218384e-01
    z[9,8,0]  R2548     2.3585869371891022e-01
    z[9,8,0]  R2549     3.6995249986648560e-01
    z[9,8,0]  R2550     -4.2968600988388062e-02
    z[9,8,0]  R2551     0.402852863073349
    z[9,8,0]  R2552     4.1930586099624634e-01
    z[9,8,0]  R2553     3.7883815169334412e-01
    z[9,8,0]  R2554     -3.2579079270362854e-02
    z[9,8,0]  R2555     -7.9975659027695656e-03
    z[9,8,0]  R2556     5.0608873367309570e-01
    z[9,8,0]  R2557     3.5544195771217346e-01
    z[9,8,0]  R2558     3.9803826808929443e-01
    z[9,8,0]  R2559     4.8468944430351257e-01
    z[9,8,1]  R75       1
    z[9,8,1]  R84       -1
    z[9,8,1]  R2473     -1
    z[9,8,1]  R2474     1
    z[9,8,1]  R2485     -8.2997870445251465e-01
    z[9,8,1]  R2486     -7.7935463190078735e-01
    z[9,8,1]  R2487     -5.9373527765274048e-01
    z[9,8,1]  R2488     -6.0379111766815186e-01
    z[9,8,1]  R2489     -4.7035849094390869e-01
    z[9,8,1]  R2490     -1.7054872214794159e-01
    z[9,8,1]  R2491     -3.7646931409835815e-01
    z[9,8,1]  R2492     -4.0305751562118530e-01
    z[9,8,1]  R2493     1.5257827937602997e-01
    z[9,8,1]  R2494     1.5584002435207367e-01
    z[9,8,1]  R2495     6.6454339027404785e-01
    z[9,8,1]  R2496     5.0379019975662231e-01
    z[9,8,1]  R2497     5.3773826360702515e-01
    z[9,8,1]  R2498     5.3363138437271118e-01
    z[9,8,1]  R2499     4.7076827287673950e-01
    z[9,8,1]  R2500     8.5063174366950989e-02
    z[9,8,1]  R2501     -4.7014467418193817e-04
    z[9,8,1]  R2502     6.5266913175582886e-01
    z[9,8,1]  R2503     -1.2414242327213287e-01
    z[9,8,1]  R2504     5.1841062307357788e-01
    z[9,8,1]  R2505     -2.7463731169700623e-01
    z[9,8,1]  R2506     3.5437962412834167e-01
    z[9,8,1]  R2507     4.5150133967399597e-01
    z[9,8,1]  R2508     6.3977748155593872e-01
    z[9,8,1]  R2509     6.2359595298767090e-01
    z[9,8,1]  R2510     1.1826018244028091e-01
    z[9,8,1]  R2511     8.9327402412891388e-02
    z[9,8,1]  R2512     -0.530619740486145
    z[9,8,1]  R2513     -1.0871769627556205e-03
    z[9,8,1]  R2514     8.6960613727569580e-02
    z[9,8,1]  R2515     -5.6294459104537964e-01
    z[9,8,1]  R2516     -5.4096710681915283e-01
    z[9,8,1]  R2517     -3.8441410660743713e-01
    z[9,8,1]  R2518     1.0363811999559402e-01
    z[9,8,1]  R2519     5.5503904819488525e-02
    z[9,8,1]  R2520     2.9511308670043945e-01
    z[9,8,1]  R2521     1.5450754761695862e-01
    z[9,8,1]  R2522     1.7042127251625061e-01
    z[9,8,1]  R2523     2.0879945158958435e-01
    z[9,8,1]  R2524     3.2493349909782410e-01
    z[9,8,1]  R2525     3.6775767803192139e-01
    z[9,8,1]  R2526     0.314726322889328
    z[9,8,1]  R2527     5.4211676120758057e-01
    z[9,8,1]  R2528     2.5673910975456238e-01
    z[9,8,1]  R2529     2.7103403210639954e-01
    z[9,8,1]  R2530     3.7999680638313293e-01
    z[9,8,1]  R2531     5.8790612220764160e-01
    z[9,8,1]  R2532     5.4605388641357422e-01
    z[9,8,1]  R2533     4.7140055894851685e-01
    z[9,8,1]  R2534     0.66666579246521
    z[9,8,1]  R2535     1.8648330867290497e-01
    z[9,8,1]  R2536     -1.8866054713726044e-01
    z[9,8,1]  R2537     -2.3718793690204620e-01
    z[9,8,1]  R2538     4.1518858075141907e-01
    z[9,8,1]  R2539     -3.0725511908531189e-01
    z[9,8,1]  R2540     3.3868480473756790e-02
    z[9,8,1]  R2541     0.454218327999115
    z[9,8,1]  R2542     -2.0671127364039421e-02
    z[9,8,1]  R2543     -4.8183876276016235e-01
    z[9,8,1]  R2544     2.5234025716781616e-01
    z[9,8,1]  R2545     -1.8473502993583679e-01
    z[9,8,1]  R2546     -3.3799788355827332e-01
    z[9,8,1]  R2547     -5.0157308578491211e-01
    z[9,8,1]  R2548     -5.0875627994537354e-01
    z[9,8,1]  R2549     -4.6851876378059387e-01
    z[9,8,1]  R2550     2.0195086300373077e-01
    z[9,8,1]  R2551     -2.4059966206550598e-01
    z[9,8,1]  R2552     1.0994620621204376e-01
    z[9,8,1]  R2553     -2.4736025929450989e-01
    z[9,8,1]  R2554     -1.8016017973423004e-01
    z[9,8,1]  R2555     -2.6322522759437561e-01
    z[9,8,1]  R2556     -0.670713484287262
    z[9,8,1]  R2557     -8.1953620910644531e-01
    z[9,8,1]  R2558     -6.3240230083465576e-01
    z[9,8,1]  R2559     -7.2972595691680908e-01
    z[9,8,2]  R76       1
    z[9,8,2]  R85       -1
    z[9,8,2]  R2475     -1
    z[9,8,2]  R2476     1
    z[9,8,2]  R2485     -3.7251576781272888e-01
    z[9,8,2]  R2486     1.8337865173816681e-01
    z[9,8,2]  R2487     3.5857531428337097e-01
    z[9,8,2]  R2488     0.437838077545166
    z[9,8,2]  R2489     -2.1067656576633453e-01
    z[9,8,2]  R2490     3.9047864079475403e-01
    z[9,8,2]  R2491     -3.7782189249992371e-01
    z[9,8,2]  R2492     -2.3185496032238007e-01
    z[9,8,2]  R2493     -4.4014781713485718e-01
    z[9,8,2]  R2494     7.9295235872268677e-01
    z[9,8,2]  R2495     2.4608774110674858e-02
    z[9,8,2]  R2496     -2.2013923525810242e-01
    z[9,8,2]  R2497     -3.3044016361236572e-01
    z[9,8,2]  R2498     -1.3546082377433777e-01
    z[9,8,2]  R2499     -1.5414842963218689e-01
    z[9,8,2]  R2500     -5.7929926551878452e-03
    z[9,8,2]  R2501     7.7107146382331848e-02
    z[9,8,2]  R2502     -2.2462606430053711e-01
    z[9,8,2]  R2503     -7.6619662344455719e-02
    z[9,8,2]  R2504     -3.8277745246887207e-01
    z[9,8,2]  R2505     -5.3804613649845123e-02
    z[9,8,2]  R2506     -7.9975193738937378e-01
    z[9,8,2]  R2507     -0.514900803565979
    z[9,8,2]  R2508     1.4151570200920105e-01
    z[9,8,2]  R2509     4.7723045572638512e-03
    z[9,8,2]  R2510     -4.4401079416275024e-01
    z[9,8,2]  R2511     -3.2758188247680664e-01
    z[9,8,2]  R2512     2.2153076529502869e-01
    z[9,8,2]  R2513     -0.675586462020874
    z[9,8,2]  R2514     -6.5137469768524170e-01
    z[9,8,2]  R2515     1.7457915842533112e-01
    z[9,8,2]  R2516     4.3856389820575714e-02
    z[9,8,2]  R2517     -2.6346400380134583e-02
    z[9,8,2]  R2518     -2.4760743975639343e-01
    z[9,8,2]  R2519     -4.2816975712776184e-01
    z[9,8,2]  R2520     -3.7379637360572815e-01
    z[9,8,2]  R2521     -1.9351994991302490e-01
    z[9,8,2]  R2522     -2.0499213039875031e-01
    z[9,8,2]  R2523     -1.1064240336418152e-01
    z[9,8,2]  R2524     -3.9540970325469971e-01
    z[9,8,2]  R2525     -5.2497762441635132e-01
    z[9,8,2]  R2526     2.4224289227277040e-03
    z[9,8,2]  R2527     -0.0970020443201065
    z[9,8,2]  R2528     -1.9662268459796906e-01
    z[9,8,2]  R2529     -2.8607437014579773e-01
    z[9,8,2]  R2530     -5.1499092578887939e-01
    z[9,8,2]  R2531     -4.9329277127981186e-02
    z[9,8,2]  R2532     1.0384587198495865e-01
    z[9,8,2]  R2533     4.3746861815452576e-01
    z[9,8,2]  R2534     4.8087587952613831e-01
    z[9,8,2]  R2535     -2.3073922097682953e-01
    z[9,8,2]  R2536     -3.6082801222801208e-01
    z[9,8,2]  R2537     -3.0009731650352478e-01
    z[9,8,2]  R2538     0.562061607837677
    z[9,8,2]  R2539     -5.3335064649581909e-01
    z[9,8,2]  R2540     -8.9149087667465210e-01
    z[9,8,2]  R2541     0.189592182636261
    z[9,8,2]  R2542     -5.0809472799301147e-01
    z[9,8,2]  R2543     -5.5949020385742188e-01
    z[9,8,2]  R2544     1.5865002572536469e-01
    z[9,8,2]  R2545     -2.4356766045093536e-01
    z[9,8,2]  R2546     -4.4351139664649963e-01
    z[9,8,2]  R2547     5.8374601602554321e-01
    z[9,8,2]  R2548     5.8935302495956421e-01
    z[9,8,2]  R2549     6.2763148546218872e-01
    z[9,8,2]  R2550     -4.6040698885917664e-01
    z[9,8,2]  R2551     -6.3620215654373169e-01
    z[9,8,2]  R2552     -9.9123053252696991e-02
    z[9,8,2]  R2553     -2.5601658225059509e-01
    z[9,8,2]  R2554     7.2802132368087769e-01
    z[9,8,2]  R2555     6.6893249750137329e-01
    z[9,8,2]  R2556     2.6052811741828918e-01
    z[9,8,2]  R2557     2.3623399436473846e-02
    z[9,8,2]  R2558     7.3987804353237152e-02
    z[9,8,2]  R2559     7.5788281857967377e-02
    z[9,8,3]  R77       1
    z[9,8,3]  R86       -1
    z[9,8,3]  R2477     -1
    z[9,8,3]  R2478     1
    z[9,8,3]  R2485     0.00329585955478251
    z[9,8,3]  R2486     -3.4972104430198669e-01
    z[9,8,3]  R2487     -2.3019210994243622e-01
    z[9,8,3]  R2488     2.3709204792976379e-01
    z[9,8,3]  R2489     -8.1858143210411072e-02
    z[9,8,3]  R2490     6.4881277084350586e-01
    z[9,8,3]  R2491     5.5613040924072266e-01
    z[9,8,3]  R2492     9.4230584800243378e-02
    z[9,8,3]  R2493     -4.1764503717422485e-01
    z[9,8,3]  R2494     4.4771265983581543e-01
    z[9,8,3]  R2495     1.3020020909607410e-02
    z[9,8,3]  R2496     5.1018267869949341e-01
    z[9,8,3]  R2497     3.1320884823799133e-01
    z[9,8,3]  R2498     -6.6068537533283234e-02
    z[9,8,3]  R2499     -4.3311378359794617e-01
    z[9,8,3]  R2500     1.6431353986263275e-01
    z[9,8,3]  R2501     -1.0704349726438522e-01
    z[9,8,3]  R2502     6.0342226177453995e-02
    z[9,8,3]  R2503     3.1790229678153992e-01
    z[9,8,3]  R2504     -3.4703891724348068e-02
    z[9,8,3]  R2505     -2.5287717580795288e-01
    z[9,8,3]  R2506     -1.0735470056533813e-01
    z[9,8,3]  R2507     -4.0629172325134277e-01
    z[9,8,3]  R2508     -7.2742298245429993e-02
    z[9,8,3]  R2509     -5.4337286949157715e-01
    z[9,8,3]  R2510     3.7399226427078247e-01
    z[9,8,3]  R2511     8.4463542699813843e-01
    z[9,8,3]  R2512     3.7432754039764404e-01
    z[9,8,3]  R2513     -2.0353691279888153e-01
    z[9,8,3]  R2514     -5.0228089094161987e-01
    z[9,8,3]  R2515     6.9852888584136963e-02
    z[9,8,3]  R2516     -1.5249375998973846e-01
    z[9,8,3]  R2517     3.0748987197875977e-01
    z[9,8,3]  R2518     4.4161000847816467e-01
    z[9,8,3]  R2519     2.7727040648460388e-01
    z[9,8,3]  R2520     -4.6838602423667908e-01
    z[9,8,3]  R2521     2.8910410404205322e-01
    z[9,8,3]  R2522     1.7768730223178864e-01
    z[9,8,3]  R2523     -7.2494372725486755e-02
    z[9,8,3]  R2524     1.2226977199316025e-01
    z[9,8,3]  R2525     -1.2317145615816116e-01
    z[9,8,3]  R2526     -6.4032179117202759e-01
    z[9,8,3]  R2527     -2.4975667893886566e-01
    z[9,8,3]  R2528     -2.7408912777900696e-01
    z[9,8,3]  R2529     -5.5452466011047363e-01
    z[9,8,3]  R2530     1.2485326826572418e-01
    z[9,8,3]  R2531     -6.5923802554607391e-02
    z[9,8,3]  R2532     2.4701729416847229e-01
    z[9,8,3]  R2533     2.1766215562820435e-01
    z[9,8,3]  R2534     5.1282446831464767e-02
    z[9,8,3]  R2535     -1.2317837774753571e-01
    z[9,8,3]  R2536     -6.5467965602874756e-01
    z[9,8,3]  R2537     -6.2769198417663574e-01
    z[9,8,3]  R2538     -2.1077285706996918e-01
    z[9,8,3]  R2539     -6.5159630775451660e-01
    z[9,8,3]  R2540     2.6033643633127213e-02
    z[9,8,3]  R2541     5.2104723453521729e-01
    z[9,8,3]  R2542     1.2494331598281860e-01
    z[9,8,3]  R2543     4.4211512804031372e-01
    z[9,8,3]  R2544     2.0982641726732254e-02
    z[9,8,3]  R2545     -7.5801765918731689e-01
    z[9,8,3]  R2546     -6.4669466018676758e-01
    z[9,8,3]  R2547     -3.5471069812774658e-01
    z[9,8,3]  R2548     -2.7713820338249207e-01
    z[9,8,3]  R2549     -0.333706796169281
    z[9,8,3]  R2550     -2.9114505648612976e-01
    z[9,8,3]  R2551     -0.43654665350914
    z[9,8,3]  R2552     -1.5885820984840393e-01
    z[9,8,3]  R2553     6.0308102518320084e-02
    z[9,8,3]  R2554     -6.2654095888137817e-01
    z[9,8,3]  R2555     -0.657532811164856
    z[9,8,3]  R2556     2.5557219982147217e-01
    z[9,8,3]  R2557     3.0942326411604881e-02
    z[9,8,3]  R2558     1.4529527723789215e-01
    z[9,8,3]  R2559     1.4006929099559784e-01
    z[9,8,4]  R78       1
    z[9,8,4]  R87       -1
    z[9,8,4]  R2479     -1
    z[9,8,4]  R2480     1
    z[9,8,4]  R2485     2.1075251698493958e-01
    z[9,8,4]  R2486     2.9115694761276245e-01
    z[9,8,4]  R2487     4.3395614624023438e-01
    z[9,8,4]  R2488     2.1299500763416290e-01
    z[9,8,4]  R2489     3.5171902179718018e-01
    z[9,8,4]  R2490     2.6832661032676697e-01
    z[9,8,4]  R2491     4.2752283811569214e-01
    z[9,8,4]  R2492     -2.6234707236289978e-01
    z[9,8,4]  R2493     -4.2021086812019348e-01
    z[9,8,4]  R2494     -2.1181757748126984e-01
    z[9,8,4]  R2495     0.724141538143158
    z[9,8,4]  R2496     1.9579641520977020e-01
    z[9,8,4]  R2497     -3.8013958930969238e-01
    z[9,8,4]  R2498     -4.9037012457847595e-01
    z[9,8,4]  R2499     -0.256389856338501
    z[9,8,4]  R2500     -2.0562279224395752e-01
    z[9,8,4]  R2501     -5.0673949718475342e-01
    z[9,8,4]  R2502     -5.8236700296401978e-01
    z[9,8,4]  R2503     -6.7370104789733887e-01
    z[9,8,4]  R2504     -5.4973214864730835e-01
    z[9,8,4]  R2505     -5.8169674873352051e-01
    z[9,8,4]  R2506     -1.6659784317016602e-01
    z[9,8,4]  R2507     -2.9732853174209595e-01
    z[9,8,4]  R2508     -4.4157716631889343e-01
    z[9,8,4]  R2509     -4.3555518984794617e-01
    z[9,8,4]  R2510     2.7456298470497131e-01
    z[9,8,4]  R2511     -9.5664508640766144e-02
    z[9,8,4]  R2512     -4.4944092631340027e-02
    z[9,8,4]  R2513     -4.2058318853378296e-01
    z[9,8,4]  R2514     8.3651952445507050e-02
    z[9,8,4]  R2515     1.6183950006961823e-01
    z[9,8,4]  R2516     1.2228089570999146e-01
    z[9,8,4]  R2517     1.0831851512193680e-01
    z[9,8,4]  R2518     4.1239753365516663e-02
    z[9,8,4]  R2519     2.6689562201499939e-01
    z[9,8,4]  R2520     -1.4906527101993561e-01
    z[9,8,4]  R2521     -2.0540687441825867e-01
    z[9,8,4]  R2522     2.5316244363784790e-01
    z[9,8,4]  R2523     -6.5151840448379517e-01
    z[9,8,4]  R2524     -2.9696115851402283e-01
    z[9,8,4]  R2525     -1.1717782914638519e-01
    z[9,8,4]  R2526     1.4127730391919613e-02
    z[9,8,4]  R2527     -7.0654176175594330e-02
    z[9,8,4]  R2528     4.1520255804061890e-01
    z[9,8,4]  R2529     0.387582391500473
    z[9,8,4]  R2530     2.3515014350414276e-01
    z[9,8,4]  R2531     -3.9228785037994385e-01
    z[9,8,4]  R2532     6.2750995159149170e-01
    z[9,8,4]  R2533     1.9426903128623962e-01
    z[9,8,4]  R2534     -2.2242219746112823e-01
    z[9,8,4]  R2535     3.1424409151077271e-01
    z[9,8,4]  R2536     -4.5627325773239136e-01
    z[9,8,4]  R2537     -5.8904582262039185e-01
    z[9,8,4]  R2538     -1.0184727609157562e-01
    z[9,8,4]  R2539     -1.0739585757255554e-01
    z[9,8,4]  R2540     -2.1908564865589142e-01
    z[9,8,4]  R2541     -4.3875795602798462e-01
    z[9,8,4]  R2542     1.7991036176681519e-01
    z[9,8,4]  R2543     4.2504531145095825e-01
    z[9,8,4]  R2544     1.6858136653900146e-01
    z[9,8,4]  R2545     -1.0200709104537964e-01
    z[9,8,4]  R2546     1.5478786826133728e-01
    z[9,8,4]  R2547     -4.6223394572734833e-02
    z[9,8,4]  R2548     -3.5091400146484375e-02
    z[9,8,4]  R2549     -1.3885188102722168e-01
    z[9,8,4]  R2550     -4.1444721817970276e-01
    z[9,8,4]  R2551     -3.9981588721275330e-01
    z[9,8,4]  R2552     -8.6185067892074585e-01
    z[9,8,4]  R2553     -0.408926784992218
    z[9,8,4]  R2554     -0.0832945927977562
    z[9,8,4]  R2555     7.2540216147899628e-02
    z[9,8,4]  R2556     -9.7592107951641083e-02
    z[9,8,4]  R2557     -0.176550030708313
    z[9,8,4]  R2558     1.3600136339664459e-01
    z[9,8,4]  R2559     2.0202951133251190e-01
    z[9,8,5]  R79       1
    z[9,8,5]  R88       -1
    z[9,8,5]  R2481     -1
    z[9,8,5]  R2482     1
    z[9,8,5]  R2485     -4.7877408564090729e-02
    z[9,8,5]  R2486     -2.8288233280181885e-01
    z[9,8,5]  R2487     1.3415230810642242e-01
    z[9,8,5]  R2488     -3.6059868335723877e-01
    z[9,8,5]  R2489     3.1892888247966766e-02
    z[9,8,5]  R2490     2.2661669552326202e-01
    z[9,8,5]  R2491     1.4870745129883289e-02
    z[9,8,5]  R2492     2.2744987905025482e-01
    z[9,8,5]  R2493     -2.8606725856661797e-02
    z[9,8,5]  R2494     -2.1060074865818024e-01
    z[9,8,5]  R2495     -1.2489126622676849e-01
    z[9,8,5]  R2496     8.5017554461956024e-02
    z[9,8,5]  R2497     -9.6607245504856110e-02
    z[9,8,5]  R2498     4.6893692016601562e-01
    z[9,8,5]  R2499     -2.0405773818492889e-01
    z[9,8,5]  R2500     3.2776159048080444e-01
    z[9,8,5]  R2501     7.9625159502029419e-01
    z[9,8,5]  R2502     -6.5661803819239140e-03
    z[9,8,5]  R2503     -2.2077096998691559e-01
    z[9,8,5]  R2504     -4.2254430055618286e-01
    z[9,8,5]  R2505     6.6329681873321533e-01
    z[9,8,5]  R2506     1.9180832803249359e-01
    z[9,8,5]  R2507     3.3409810066223145e-01
    z[9,8,5]  R2508     5.8726257085800171e-01
    z[9,8,5]  R2509     -1.9228871911764145e-02
    z[9,8,5]  R2510     -2.1222855150699615e-01
    z[9,8,5]  R2511     -3.8571909070014954e-01
    z[9,8,5]  R2512     -3.7898812443017960e-02
    z[9,8,5]  R2513     -5.3185838460922241e-01
    z[9,8,5]  R2514     -5.1169478893280029e-01
    z[9,8,5]  R2515     -4.3579104542732239e-01
    z[9,8,5]  R2516     -7.8193083405494690e-02
    z[9,8,5]  R2517     1.4023149013519287e-01
    z[9,8,5]  R2518     -2.3247583210468292e-01
    z[9,8,5]  R2519     1.4512902498245239e-01
    z[9,8,5]  R2520     6.5063685178756714e-01
    z[9,8,5]  R2521     6.4727210998535156e-01
    z[9,8,5]  R2522     7.5353229045867920e-01
    z[9,8,5]  R2523     6.3173079490661621e-01
    z[9,8,5]  R2524     0.648418128490448
    z[9,8,5]  R2525     1.4669895172119141e-01
    z[9,8,5]  R2526     -0.35670205950737
    z[9,8,5]  R2527     4.6691350638866425e-02
    z[9,8,5]  R2528     -5.5635178089141846e-01
    z[9,8,5]  R2529     -1.0013957321643829e-01
    z[9,8,5]  R2530     -3.0002406239509583e-01
    z[9,8,5]  R2531     -5.8322310447692871e-01
    z[9,8,5]  R2532     -3.9679780602455139e-01
    z[9,8,5]  R2533     4.6744191646575928e-01
    z[9,8,5]  R2534     -1.8281127512454987e-01
    z[9,8,5]  R2535     2.6467922329902649e-01
    z[9,8,5]  R2536     -2.7792349457740784e-01
    z[9,8,5]  R2537     -1.1378429830074310e-01
    z[9,8,5]  R2538     1.2139365822076797e-01
    z[9,8,5]  R2539     -2.0855334401130676e-01
    z[9,8,5]  R2540     1.5417899191379547e-01
    z[9,8,5]  R2541     5.1112931966781616e-01
    z[9,8,5]  R2542     -1.4657360315322876e-01
    z[9,8,5]  R2543     4.4567704200744629e-02
    z[9,8,5]  R2544     -1.1271034367382526e-02
    z[9,8,5]  R2545     -4.3017813563346863e-01
    z[9,8,5]  R2546     -1.0735403746366501e-01
    z[9,8,5]  R2547     4.0523451566696167e-01
    z[9,8,5]  R2548     4.9842372536659241e-01
    z[9,8,5]  R2549     3.2940280437469482e-01
    z[9,8,5]  R2550     1.0949368029832840e-01
    z[9,8,5]  R2551     1.5383474528789520e-01
    z[9,8,5]  R2552     -1.6974768042564392e-01
    z[9,8,5]  R2553     -3.8104841113090515e-01
    z[9,8,5]  R2554     1.6225872933864594e-01
    z[9,8,5]  R2555     1.9123287498950958e-01
    z[9,8,5]  R2556     3.8897478580474854e-01
    z[9,8,5]  R2557     3.8984280824661255e-01
    z[9,8,5]  R2558     4.5666497945785522e-01
    z[9,8,5]  R2559     3.3115327358245850e-01
    z[9,8,6]  R80       1
    z[9,8,6]  R89       -1
    z[9,8,6]  R2483     -1
    z[9,8,6]  R2484     1
    z[9,8,6]  R2485     2.0228348672389984e-01
    z[9,8,6]  R2486     -2.4512818455696106e-01
    z[9,8,6]  R2487     4.9123266339302063e-01
    z[9,8,6]  R2488     0.458877295255661
    z[9,8,6]  R2489     -1.7089027166366577e-01
    z[9,8,6]  R2490     -1.6945970058441162e-01
    z[9,8,6]  R2491     -0.314144492149353
    z[9,8,6]  R2492     -5.9782350063323975e-01
    z[9,8,6]  R2493     -2.1775241196155548e-01
    z[9,8,6]  R2494     -1.0965825989842415e-02
    z[9,8,6]  R2495     -9.3064224347472191e-04
    z[9,8,6]  R2496     6.1952179670333862e-01
    z[9,8,6]  R2497     -3.5580569505691528e-01
    z[9,8,6]  R2498     -9.8149202764034271e-02
    z[9,8,6]  R2499     2.0360575616359711e-01
    z[9,8,6]  R2500     -0.434345006942749
    z[9,8,6]  R2501     4.9282174557447433e-02
    z[9,8,6]  R2502     -3.9629215002059937e-01
    z[9,8,6]  R2503     -0.447204053401947
    z[9,8,6]  R2504     -5.8996759355068207e-02
    z[9,8,6]  R2505     2.6214540004730225e-01
    z[9,8,6]  R2506     -3.8011962175369263e-01
    z[9,8,6]  R2507     -2.8304505348205566e-01
    z[9,8,6]  R2508     -1.5371902287006378e-01
    z[9,8,6]  R2509     2.5114363431930542e-01
    z[9,8,6]  R2510     0.715579092502594
    z[9,8,6]  R2511     -9.9180653691291809e-02
    z[9,8,6]  R2512     -3.1751450896263123e-01
    z[9,8,6]  R2513     -1.2775610387325287e-01
    z[9,8,6]  R2514     -1.9601227343082428e-01
    z[9,8,6]  R2515     -4.3291427195072174e-02
    z[9,8,6]  R2516     3.5004043579101562e-01
    z[9,8,6]  R2517     4.1487994790077209e-01
    z[9,8,6]  R2518     -1.5894404053688049e-01
    z[9,8,6]  R2519     -0.0661550909280777
    z[9,8,6]  R2520     -3.2657498121261597e-01
    z[9,8,6]  R2521     -5.6380033493041992e-01
    z[9,8,6]  R2522     -4.2768073081970215e-01
    z[9,8,6]  R2523     3.3474865555763245e-01
    z[9,8,6]  R2524     1.1454010009765625e-01
    z[9,8,6]  R2525     1.3956645131111145e-01
    z[9,8,6]  R2526     -1.0822586715221405e-02
    z[9,8,6]  R2527     -1.2186323851346970e-01
    z[9,8,6]  R2528     -6.1505012214183807e-02
    z[9,8,6]  R2529     5.6634787470102310e-02
    z[9,8,6]  R2530     2.3918713629245758e-01
    z[9,8,6]  R2531     1.6429321467876434e-01
    z[9,8,6]  R2532     -4.9106314778327942e-02
    z[9,8,6]  R2533     4.5863509178161621e-01
    z[9,8,6]  R2534     -1.5227811038494110e-01
    z[9,8,6]  R2535     4.9847438931465149e-03
    z[9,8,6]  R2536     1.9000843167304993e-01
    z[9,8,6]  R2537     -6.0314185917377472e-02
    z[9,8,6]  R2538     -6.2600302696228027e-01
    z[9,8,6]  R2539     3.4400549530982971e-01
    z[9,8,6]  R2540     3.3920171856880188e-01
    z[9,8,6]  R2541     1.7776845395565033e-01
    z[9,8,6]  R2542     -7.7110564708709717e-01
    z[9,8,6]  R2543     -4.5317225158214569e-02
    z[9,8,6]  R2544     -6.3411140441894531e-01
    z[9,8,6]  R2545     -6.7915320396423340e-02
    z[9,8,6]  R2546     -3.2243371009826660e-01
    z[9,8,6]  R2547     0.129832461476326
    z[9,8,6]  R2548     -1.0833974182605743e-01
    z[9,8,6]  R2549     -1.0275018960237503e-01
    z[9,8,6]  R2550     -6.9056069850921631e-01
    z[9,8,6]  R2551     -3.1261447817087173e-02
    z[9,8,6]  R2552     -7.3703393340110779e-02
    z[9,8,6]  R2553     -6.4319044351577759e-01
    z[9,8,6]  R2554     -1.0318081825971603e-01
    z[9,8,6]  R2555     -0.0948491171002388
    z[9,8,6]  R2556     -8.9268978626932949e-05
    z[9,8,6]  R2557     1.3175293803215027e-01
    z[9,8,6]  R2558     4.3359977006912231e-01
    z[9,8,6]  R2559     2.3819006979465485e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    length[8]  OBJ       1
    length[9]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
    delta[8,0]  R74       1
    delta[8,1]  R75       1
    delta[8,2]  R76       1
    delta[8,3]  R77       1
    delta[8,4]  R78       1
    delta[8,5]  R79       1
    delta[8,6]  R80       1
    delta[9,0]  R83       1
    delta[9,1]  R84       1
    delta[9,2]  R85       1
    delta[9,3]  R86       1
    delta[9,4]  R87       1
    delta[9,5]  R88       1
    delta[9,6]  R89       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R73       1
    RHS1      R82       1
    RHS1      R90       1
    RHS1      R91       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,6]
 BV BND1      phi[6,0]
 BV BND1      phi[10,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[5,9]
 BV BND1      phi[9,5]
 BV BND1      phi[5,11]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[10,6]
 BV BND1      phi[7,8]
 BV BND1      phi[8,7]
 BV BND1      phi[8,9]
 BV BND1      phi[9,8]
 BV BND1      phi[9,11]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,6,0]
 FR BND1      z[0,6,1]
 FR BND1      z[0,6,2]
 FR BND1      z[0,6,3]
 FR BND1      z[0,6,4]
 FR BND1      z[0,6,5]
 FR BND1      z[0,6,6]
 FR BND1      z[6,0,0]
 FR BND1      z[6,0,1]
 FR BND1      z[6,0,2]
 FR BND1      z[6,0,3]
 FR BND1      z[6,0,4]
 FR BND1      z[6,0,5]
 FR BND1      z[6,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[5,9,0]
 FR BND1      z[5,9,1]
 FR BND1      z[5,9,2]
 FR BND1      z[5,9,3]
 FR BND1      z[5,9,4]
 FR BND1      z[5,9,5]
 FR BND1      z[5,9,6]
 FR BND1      z[9,5,0]
 FR BND1      z[9,5,1]
 FR BND1      z[9,5,2]
 FR BND1      z[9,5,3]
 FR BND1      z[9,5,4]
 FR BND1      z[9,5,5]
 FR BND1      z[9,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      z[7,8,0]
 FR BND1      z[7,8,1]
 FR BND1      z[7,8,2]
 FR BND1      z[7,8,3]
 FR BND1      z[7,8,4]
 FR BND1      z[7,8,5]
 FR BND1      z[7,8,6]
 FR BND1      z[8,7,0]
 FR BND1      z[8,7,1]
 FR BND1      z[8,7,2]
 FR BND1      z[8,7,3]
 FR BND1      z[8,7,4]
 FR BND1      z[8,7,5]
 FR BND1      z[8,7,6]
 FR BND1      z[8,9,0]
 FR BND1      z[8,9,1]
 FR BND1      z[8,9,2]
 FR BND1      z[8,9,3]
 FR BND1      z[8,9,4]
 FR BND1      z[8,9,5]
 FR BND1      z[8,9,6]
 FR BND1      z[9,8,0]
 FR BND1      z[9,8,1]
 FR BND1      z[9,8,2]
 FR BND1      z[9,8,3]
 FR BND1      z[9,8,4]
 FR BND1      z[9,8,5]
 FR BND1      z[9,8,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
 FR BND1      delta[8,0]
 FR BND1      delta[8,1]
 FR BND1      delta[8,2]
 FR BND1      delta[8,3]
 FR BND1      delta[8,4]
 FR BND1      delta[8,5]
 FR BND1      delta[8,6]
 FR BND1      delta[9,0]
 FR BND1      delta[9,1]
 FR BND1      delta[9,2]
 FR BND1      delta[9,3]
 FR BND1      delta[9,4]
 FR BND1      delta[9,5]
 FR BND1      delta[9,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
QCMATRIX   qc8     
    length[8]  length[8]  -1
    delta[8,0]  delta[8,0]  1
    delta[8,1]  delta[8,1]  1
    delta[8,2]  delta[8,2]  1
    delta[8,3]  delta[8,3]  1
    delta[8,4]  delta[8,4]  1
    delta[8,5]  delta[8,5]  1
    delta[8,6]  delta[8,6]  1
QCMATRIX   qc9     
    length[9]  length[9]  -1
    delta[9,0]  delta[9,0]  1
    delta[9,1]  delta[9,1]  1
    delta[9,2]  delta[9,2]  1
    delta[9,3]  delta[9,3]  1
    delta[9,4]  delta[9,4]  1
    delta[9,5]  delta[9,5]  1
    delta[9,6]  delta[9,6]  1
ENDATA
