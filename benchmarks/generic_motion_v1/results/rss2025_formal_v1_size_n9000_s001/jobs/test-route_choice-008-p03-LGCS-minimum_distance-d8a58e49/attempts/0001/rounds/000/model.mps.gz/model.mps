NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 E  R46     
 L  R47     
 L  R48     
 L  R49     
 L  R50     
 L  R51     
 L  R52     
 L  R53     
 L  R54     
 L  R55     
 L  R56     
 L  R57     
 L  R58     
 L  R59     
 L  R60     
 L  R61     
 L  R62     
 L  R63     
 L  R64     
 L  R65     
 L  R66     
 L  R67     
 L  R68     
 L  R69     
 L  R70     
 L  R71     
 L  R72     
 L  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R47       -3.0999999046325684e+00
    phi[0,1]  R48       -3.0999999046325684e+00
    phi[0,1]  R49       -2.2400000095367432e+00
    phi[0,1]  R50       -2.2400000095367432e+00
    phi[0,1]  R51       -3.0999999046325684e+00
    phi[0,1]  R52       -3.0999999046325684e+00
    phi[0,1]  R53       -2.5699999332427979e+00
    phi[0,1]  R54       -2.5699999332427979e+00
    phi[0,1]  R55       -3.0999999046325684e+00
    phi[0,1]  R56       -3.0999999046325684e+00
    phi[0,1]  R57       -2.0899999141693115e+00
    phi[0,1]  R58       -2.0899999141693115e+00
    phi[0,1]  R59       -3.0999999046325684e+00
    phi[0,1]  R60       -3.0999999046325684e+00
    phi[0,1]  R61       -1.2341090440750122e+00
    phi[0,1]  R62       -9.8038172721862793e-01
    phi[0,1]  R63       -1.03556489944458
    phi[0,1]  R64       9.0388625860214233e-01
    phi[0,1]  R65       9.7242355346679688e-01
    phi[0,1]  R66       4.2592161893844604e-01
    phi[0,1]  R67       1.2247036695480347e+00
    phi[0,1]  R68       9.6322655677795410e-01
    phi[0,1]  R69       -9.3915200233459473e-01
    phi[0,1]  R70       9.5571047067642212e-01
    phi[0,1]  R71       -9.5137453079223633e-01
    phi[0,1]  R72       -1.3062409162521362e+00
    phi[0,1]  R73       -2.1127641201019287e+00
    phi[0,1]  R74       -1.1656520366668701e+00
    phi[0,1]  R75       -3.3780453205108643e+00
    phi[0,1]  R76       -4.8484435677528381e-01
    phi[0,1]  R77       -6.9695830345153809e-01
    phi[0,1]  R78       -1.8065074682235718e+00
    phi[0,1]  R79       -7.5354123115539551e-01
    phi[0,1]  R80       -2.0101463794708252e+00
    phi[0,1]  R81       -2.4692502021789551e+00
    phi[0,1]  R82       -2.8727500438690186e+00
    phi[0,1]  R83       -3.6658790111541748e+00
    phi[0,1]  R84       -8.4497094154357910e-01
    phi[0,1]  R85       -8.9308500289916992e-01
    phi[0,1]  R86       -1.7221144437789917e+00
    phi[0,1]  R87       -1.6172307729721069e+00
    phi[0,1]  R88       -3.1539819240570068e+00
    phi[0,1]  R89       -2.5537202358245850e+00
    phi[0,1]  R90       -1.4053852558135986e+00
    phi[0,1]  R91       -1.3655986785888672e+00
    phi[0,1]  R92       -7.8273534774780273e-01
    phi[0,1]  R93       -2.4237787723541260e+00
    phi[0,1]  R94       -2.0907337665557861e+00
    phi[0,1]  R95       -1.3551462888717651e+00
    phi[0,1]  R96       8.1263726949691772e-01
    phi[0,1]  R97       -2.1113321781158447e+00
    phi[0,1]  R98       -1.0176339149475098e+00
    phi[0,1]  R99       -8.8592779636383057e-01
    phi[0,1]  R100      -1.3973553180694580e+00
    phi[0,1]  R101      -1.5521695613861084e+00
    phi[0,1]  R102      -1.0973352193832397e+00
    phi[0,1]  R103      -1.7850900888442993e+00
    phi[0,1]  R104      -2.0543990135192871e+00
    phi[0,1]  R105      -5.2965217828750610e-01
    phi[0,1]  R106      -1.0902556180953979e+00
    phi[0,1]  R107      -6.2409496307373047e-01
    phi[0,1]  R108      -1.8844892978668213e+00
    phi[0,1]  R109      -4.3241259455680847e-01
    phi[0,1]  R110      -1.4691774845123291e+00
    phi[0,1]  R111      -8.5957753658294678e-01
    phi[0,1]  R112      -1.9989881515502930e+00
    phi[0,1]  R113      -1.8163536787033081e+00
    phi[0,1]  R114      -1.1768816709518433e+00
    phi[0,1]  R115      -1.3853995800018311e+00
    phi[0,1]  R116      -1.3591876626014709e-01
    phi[0,1]  R117      -1.8913567066192627e+00
    phi[0,1]  R118      -1.1932204961776733e+00
    phi[0,1]  R119      3.4694093465805054e-01
    phi[0,1]  R120      -8.3041828870773315e-01
    phi[0,1]  R121      2.2953796386718750e-01
    phi[0,1]  R122      1.0304706096649170e+00
    phi[0,1]  R123      -4.1439521312713623e-01
    phi[0,1]  R124      0.24210225045681
    phi[0,1]  R125      3.3544987440109253e-01
    phi[0,1]  R126      -9.2660534381866455e-01
    phi[0,1]  R127      -7.5631928443908691e-01
    phi[0,1]  R128      2.1012984216213226e-01
    phi[0,1]  R129      -3.1239548325538635e-01
    phi[0,1]  R130      -1.1931275576353073e-01
    phi[0,1]  R131      -1.9321343898773193e+00
    phi[0,1]  R132      -1.8925678730010986e+00
    phi[0,1]  R133      -1.6593906879425049e+00
    phi[0,1]  R134      1.0698325186967850e-01
    phi[0,1]  R135      1.3713088631629944e-01
    phi[0,1]  R136      3.0111670494079590e-01
    phi[0,1]  R137      0.062712162733078
    phi[0,1]  R138      6.4283460378646851e-01
    phi[0,1]  R139      3.6917710304260254e-01
    phi[0,1]  R140      7.6192575693130493e-01
    phi[0,1]  R141      -1.1395325660705566e+00
    phi[0,1]  R142      -5.9893929958343506e-01
    phi[0,1]  R143      -1.5031230449676514e+00
    phi[0,1]  R144      -1.3366020917892456e+00
    phi[0,1]  R145      -1.1719367504119873e+00
    phi[0,1]  R146      -1.5393635034561157e+00
    phi[0,1]  R147      -2.2131805419921875e+00
    phi[0,1]  R148      -2.2875556349754333e-01
    phi[0,1]  R149      2.0869490504264832e-01
    phi[0,1]  R150      -2.8643736839294434e+00
    phi[0,1]  R151      -2.5076618194580078e+00
    phi[0,1]  R152      -2.14526104927063
    phi[0,1]  R153      -5.2298164367675781e-01
    phi[0,1]  R154      -9.4787108898162842e-01
    phi[0,1]  R155      -1.2137928009033203e+00
    phi[0,1]  R156      -3.8181905746459961e+00
    phi[0,1]  R157      -1.1628155708312988e+00
    phi[0,1]  R158      -1.6416127681732178e+00
    phi[0,1]  R159      -1.6099681854248047e+00
    phi[0,1]  R160      -1.3271917104721069e+00
    phi[0,1]  R161      -2.1820611953735352e+00
    phi[0,1]  R162      -1.3258926868438721e+00
    phi[0,1]  R163      -1.3318003714084625e-01
    phi[0,1]  R164      1.7273834347724915e-01
    phi[0,1]  R165      7.3616409301757812e-01
    phi[0,1]  R166      -3.0655763149261475e+00
    phi[0,1]  R167      -3.2563374042510986e+00
    phi[0,1]  R168      -2.0490498542785645e+00
    phi[0,1]  R169      -5.2686321735382080e-01
    phi[0,1]  R170      -1.1256014108657837e+00
    phi[0,1]  R171      -1.2982035875320435e+00
    phi[0,1]  R172      -7.4548697471618652e-01
    phi[0,1]  R173      -2.6498675346374512e+00
    phi[0,1]  R174      -1.8641465902328491e+00
    phi[0,1]  R175      -6.8749696016311646e-02
    phi[0,1]  R176      -1.6977532207965851e-01
    phi[0,1]  R177      -2.0735110342502594e-01
    phi[0,1]  R178      -0.362966388463974
    phi[0,1]  R179      -1.4825825691223145e+00
    phi[0,1]  R180      7.3841445147991180e-02
    phi[0,1]  R181      -2.1178109645843506e+00
    phi[0,1]  R182      3.5554066300392151e-01
    phi[0,1]  R183      -9.7308611869812012e-01
    phi[0,1]  R184      -6.4851516485214233e-01
    phi[0,1]  R185      -2.1288216114044189e+00
    phi[0,1]  R186      -1.60283362865448
    phi[0,1]  R187      -1.7038503885269165e+00
    phi[0,1]  R188      -2.5109903812408447e+00
    phi[0,1]  R189      -2.2294936180114746e+00
    phi[0,1]  R190      -2.7906489372253418e+00
    phi[0,1]  R191      -1.2178258895874023e+00
    phi[0,1]  R192      -1.7553027868270874e+00
    phi[0,1]  R193      -2.6975861191749573e-01
    phi[0,1]  R194      -2.3918833732604980e+00
    phi[0,1]  R195      -1.2880640029907227e+00
    phi[0,1]  R196      -2.1998276710510254e+00
    phi[0,1]  R197      -2.5881690979003906e+00
    phi[0,1]  R198      -1.7120409011840820e+00
    phi[0,1]  R199      -2.5651578903198242e+00
    phi[0,1]  R200      -2.5395088195800781e+00
    phi[0,1]  R201      -1.3417088985443115e+00
    phi[0,1]  R202      -1.4215285778045654e+00
    phi[0,1]  R203      -3.9309658110141754e-02
    phi[0,1]  R204      -3.3711355924606323e-01
    phi[0,1]  R205      -1.7408809661865234e+00
    phi[0,1]  R206      2.6205414906144142e-02
    phi[0,1]  R207      -1.1624306440353394e+00
    phi[0,1]  R208      -1.0412735939025879e+00
    phi[0,1]  R209      -1.1779898405075073e+00
    phi[0,1]  R210      -7.1380782127380371e-01
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R211      -3.0999999046325684e+00
    phi[1,0]  R212      -3.0999999046325684e+00
    phi[1,0]  R213      -2.2400000095367432e+00
    phi[1,0]  R214      -2.2400000095367432e+00
    phi[1,0]  R215      -3.0999999046325684e+00
    phi[1,0]  R216      -3.0999999046325684e+00
    phi[1,0]  R217      -2.5699999332427979e+00
    phi[1,0]  R218      -2.5699999332427979e+00
    phi[1,0]  R219      -3.0999999046325684e+00
    phi[1,0]  R220      -3.0999999046325684e+00
    phi[1,0]  R221      -2.0899999141693115e+00
    phi[1,0]  R222      -2.0899999141693115e+00
    phi[1,0]  R223      -3.0999999046325684e+00
    phi[1,0]  R224      -3.0999999046325684e+00
    phi[1,0]  R225      2.2953796386718750e-01
    phi[1,0]  R226      1.0304706096649170e+00
    phi[1,0]  R227      -4.1439521312713623e-01
    phi[1,0]  R228      0.24210225045681
    phi[1,0]  R229      3.3544987440109253e-01
    phi[1,0]  R230      -9.2660534381866455e-01
    phi[1,0]  R231      -7.5631928443908691e-01
    phi[1,0]  R232      2.1012984216213226e-01
    phi[1,0]  R233      -3.1239548325538635e-01
    phi[1,0]  R234      -1.1931275576353073e-01
    phi[1,0]  R235      -1.9321343898773193e+00
    phi[1,0]  R236      -1.8925678730010986e+00
    phi[1,0]  R237      -1.6593906879425049e+00
    phi[1,0]  R238      1.0698325186967850e-01
    phi[1,0]  R239      1.3713088631629944e-01
    phi[1,0]  R240      3.0111670494079590e-01
    phi[1,0]  R241      0.062712162733078
    phi[1,0]  R242      6.4283460378646851e-01
    phi[1,0]  R243      3.6917710304260254e-01
    phi[1,0]  R244      7.6192575693130493e-01
    phi[1,0]  R245      -1.1395325660705566e+00
    phi[1,0]  R246      -5.9893929958343506e-01
    phi[1,0]  R247      -1.5031230449676514e+00
    phi[1,0]  R248      -1.3366020917892456e+00
    phi[1,0]  R249      -1.1719367504119873e+00
    phi[1,0]  R250      -1.5393635034561157e+00
    phi[1,0]  R251      -2.2131805419921875e+00
    phi[1,0]  R252      -2.2875556349754333e-01
    phi[1,0]  R253      2.0869490504264832e-01
    phi[1,0]  R254      -2.8643736839294434e+00
    phi[1,0]  R255      -2.5076618194580078e+00
    phi[1,0]  R256      -2.14526104927063
    phi[1,0]  R257      -5.2298164367675781e-01
    phi[1,0]  R258      -9.4787108898162842e-01
    phi[1,0]  R259      -1.2137928009033203e+00
    phi[1,0]  R260      -3.8181905746459961e+00
    phi[1,0]  R261      -1.1628155708312988e+00
    phi[1,0]  R262      -1.6416127681732178e+00
    phi[1,0]  R263      -1.6099681854248047e+00
    phi[1,0]  R264      -1.3271917104721069e+00
    phi[1,0]  R265      -2.1820611953735352e+00
    phi[1,0]  R266      -1.3258926868438721e+00
    phi[1,0]  R267      -1.3318003714084625e-01
    phi[1,0]  R268      1.7273834347724915e-01
    phi[1,0]  R269      7.3616409301757812e-01
    phi[1,0]  R270      -3.0655763149261475e+00
    phi[1,0]  R271      -3.2563374042510986e+00
    phi[1,0]  R272      -2.0490498542785645e+00
    phi[1,0]  R273      -5.2686321735382080e-01
    phi[1,0]  R274      -1.1256014108657837e+00
    phi[1,0]  R275      -1.2982035875320435e+00
    phi[1,0]  R276      -7.4548697471618652e-01
    phi[1,0]  R277      -2.6498675346374512e+00
    phi[1,0]  R278      -1.8641465902328491e+00
    phi[1,0]  R279      -6.8749696016311646e-02
    phi[1,0]  R280      -1.6977532207965851e-01
    phi[1,0]  R281      -2.0735110342502594e-01
    phi[1,0]  R282      -0.362966388463974
    phi[1,0]  R283      -1.4825825691223145e+00
    phi[1,0]  R284      7.3841445147991180e-02
    phi[1,0]  R285      -2.1178109645843506e+00
    phi[1,0]  R286      3.5554066300392151e-01
    phi[1,0]  R287      -9.7308611869812012e-01
    phi[1,0]  R288      -6.4851516485214233e-01
    phi[1,0]  R289      -2.1288216114044189e+00
    phi[1,0]  R290      -1.60283362865448
    phi[1,0]  R291      -1.7038503885269165e+00
    phi[1,0]  R292      -2.5109903812408447e+00
    phi[1,0]  R293      -2.2294936180114746e+00
    phi[1,0]  R294      -2.7906489372253418e+00
    phi[1,0]  R295      -1.2178258895874023e+00
    phi[1,0]  R296      -1.7553027868270874e+00
    phi[1,0]  R297      -2.6975861191749573e-01
    phi[1,0]  R298      -2.3918833732604980e+00
    phi[1,0]  R299      -1.2880640029907227e+00
    phi[1,0]  R300      -2.1998276710510254e+00
    phi[1,0]  R301      -2.5881690979003906e+00
    phi[1,0]  R302      -1.7120409011840820e+00
    phi[1,0]  R303      -2.5651578903198242e+00
    phi[1,0]  R304      -2.5395088195800781e+00
    phi[1,0]  R305      -1.3417088985443115e+00
    phi[1,0]  R306      -1.4215285778045654e+00
    phi[1,0]  R307      -3.9309658110141754e-02
    phi[1,0]  R308      -3.3711355924606323e-01
    phi[1,0]  R309      -1.7408809661865234e+00
    phi[1,0]  R310      2.6205414906144142e-02
    phi[1,0]  R311      -1.1624306440353394e+00
    phi[1,0]  R312      -1.0412735939025879e+00
    phi[1,0]  R313      -1.1779898405075073e+00
    phi[1,0]  R314      -7.1380782127380371e-01
    phi[1,0]  R315      -1.2341090440750122e+00
    phi[1,0]  R316      -9.8038172721862793e-01
    phi[1,0]  R317      -1.03556489944458
    phi[1,0]  R318      9.0388625860214233e-01
    phi[1,0]  R319      9.7242355346679688e-01
    phi[1,0]  R320      4.2592161893844604e-01
    phi[1,0]  R321      1.2247036695480347e+00
    phi[1,0]  R322      9.6322655677795410e-01
    phi[1,0]  R323      -9.3915200233459473e-01
    phi[1,0]  R324      9.5571047067642212e-01
    phi[1,0]  R325      -9.5137453079223633e-01
    phi[1,0]  R326      -1.3062409162521362e+00
    phi[1,0]  R327      -2.1127641201019287e+00
    phi[1,0]  R328      -1.1656520366668701e+00
    phi[1,0]  R329      -3.3780453205108643e+00
    phi[1,0]  R330      -4.8484435677528381e-01
    phi[1,0]  R331      -6.9695830345153809e-01
    phi[1,0]  R332      -1.8065074682235718e+00
    phi[1,0]  R333      -7.5354123115539551e-01
    phi[1,0]  R334      -2.0101463794708252e+00
    phi[1,0]  R335      -2.4692502021789551e+00
    phi[1,0]  R336      -2.8727500438690186e+00
    phi[1,0]  R337      -3.6658790111541748e+00
    phi[1,0]  R338      -8.4497094154357910e-01
    phi[1,0]  R339      -8.9308500289916992e-01
    phi[1,0]  R340      -1.7221144437789917e+00
    phi[1,0]  R341      -1.6172307729721069e+00
    phi[1,0]  R342      -3.1539819240570068e+00
    phi[1,0]  R343      -2.5537202358245850e+00
    phi[1,0]  R344      -1.4053852558135986e+00
    phi[1,0]  R345      -1.3655986785888672e+00
    phi[1,0]  R346      -7.8273534774780273e-01
    phi[1,0]  R347      -2.4237787723541260e+00
    phi[1,0]  R348      -2.0907337665557861e+00
    phi[1,0]  R349      -1.3551462888717651e+00
    phi[1,0]  R350      8.1263726949691772e-01
    phi[1,0]  R351      -2.1113321781158447e+00
    phi[1,0]  R352      -1.0176339149475098e+00
    phi[1,0]  R353      -8.8592779636383057e-01
    phi[1,0]  R354      -1.3973553180694580e+00
    phi[1,0]  R355      -1.5521695613861084e+00
    phi[1,0]  R356      -1.0973352193832397e+00
    phi[1,0]  R357      -1.7850900888442993e+00
    phi[1,0]  R358      -2.0543990135192871e+00
    phi[1,0]  R359      -5.2965217828750610e-01
    phi[1,0]  R360      -1.0902556180953979e+00
    phi[1,0]  R361      -6.2409496307373047e-01
    phi[1,0]  R362      -1.8844892978668213e+00
    phi[1,0]  R363      -4.3241259455680847e-01
    phi[1,0]  R364      -1.4691774845123291e+00
    phi[1,0]  R365      -8.5957753658294678e-01
    phi[1,0]  R366      -1.9989881515502930e+00
    phi[1,0]  R367      -1.8163536787033081e+00
    phi[1,0]  R368      -1.1768816709518433e+00
    phi[1,0]  R369      -1.3853995800018311e+00
    phi[1,0]  R370      -1.3591876626014709e-01
    phi[1,0]  R371      -1.8913567066192627e+00
    phi[1,0]  R372      -1.1932204961776733e+00
    phi[1,0]  R373      3.4694093465805054e-01
    phi[1,0]  R374      -8.3041828870773315e-01
    phi[0,3]  R0        1
    phi[0,3]  R1        1
    phi[0,3]  R27       -1
    phi[0,3]  R375      -3.0999999046325684e+00
    phi[0,3]  R376      -3.0999999046325684e+00
    phi[0,3]  R377      -2.2400000095367432e+00
    phi[0,3]  R378      -2.2400000095367432e+00
    phi[0,3]  R379      -3.0999999046325684e+00
    phi[0,3]  R380      -3.0999999046325684e+00
    phi[0,3]  R381      -2.5699999332427979e+00
    phi[0,3]  R382      -2.5699999332427979e+00
    phi[0,3]  R383      -3.0999999046325684e+00
    phi[0,3]  R384      -3.0999999046325684e+00
    phi[0,3]  R385      -2.0899999141693115e+00
    phi[0,3]  R386      -2.0899999141693115e+00
    phi[0,3]  R387      -3.0999999046325684e+00
    phi[0,3]  R388      -3.0999999046325684e+00
    phi[0,3]  R389      -1.2341090440750122e+00
    phi[0,3]  R390      -9.8038172721862793e-01
    phi[0,3]  R391      -1.03556489944458
    phi[0,3]  R392      9.0388625860214233e-01
    phi[0,3]  R393      9.7242355346679688e-01
    phi[0,3]  R394      4.2592161893844604e-01
    phi[0,3]  R395      1.2247036695480347e+00
    phi[0,3]  R396      9.6322655677795410e-01
    phi[0,3]  R397      -9.3915200233459473e-01
    phi[0,3]  R398      9.5571047067642212e-01
    phi[0,3]  R399      -9.5137453079223633e-01
    phi[0,3]  R400      -1.3062409162521362e+00
    phi[0,3]  R401      -2.1127641201019287e+00
    phi[0,3]  R402      -1.1656520366668701e+00
    phi[0,3]  R403      -3.3780453205108643e+00
    phi[0,3]  R404      -4.8484435677528381e-01
    phi[0,3]  R405      -6.9695830345153809e-01
    phi[0,3]  R406      -1.8065074682235718e+00
    phi[0,3]  R407      -7.5354123115539551e-01
    phi[0,3]  R408      -2.0101463794708252e+00
    phi[0,3]  R409      -2.4692502021789551e+00
    phi[0,3]  R410      -2.8727500438690186e+00
    phi[0,3]  R411      -3.6658790111541748e+00
    phi[0,3]  R412      -8.4497094154357910e-01
    phi[0,3]  R413      -8.9308500289916992e-01
    phi[0,3]  R414      -1.7221144437789917e+00
    phi[0,3]  R415      -1.6172307729721069e+00
    phi[0,3]  R416      -3.1539819240570068e+00
    phi[0,3]  R417      -2.5537202358245850e+00
    phi[0,3]  R418      -1.4053852558135986e+00
    phi[0,3]  R419      -1.3655986785888672e+00
    phi[0,3]  R420      -7.8273534774780273e-01
    phi[0,3]  R421      -2.4237787723541260e+00
    phi[0,3]  R422      -2.0907337665557861e+00
    phi[0,3]  R423      -1.3551462888717651e+00
    phi[0,3]  R424      8.1263726949691772e-01
    phi[0,3]  R425      -2.1113321781158447e+00
    phi[0,3]  R426      -1.0176339149475098e+00
    phi[0,3]  R427      -8.8592779636383057e-01
    phi[0,3]  R428      -1.3973553180694580e+00
    phi[0,3]  R429      -1.5521695613861084e+00
    phi[0,3]  R430      -1.0973352193832397e+00
    phi[0,3]  R431      -1.7850900888442993e+00
    phi[0,3]  R432      -2.0543990135192871e+00
    phi[0,3]  R433      -5.2965217828750610e-01
    phi[0,3]  R434      -1.0902556180953979e+00
    phi[0,3]  R435      -6.2409496307373047e-01
    phi[0,3]  R436      -1.8844892978668213e+00
    phi[0,3]  R437      -4.3241259455680847e-01
    phi[0,3]  R438      -1.4691774845123291e+00
    phi[0,3]  R439      -8.5957753658294678e-01
    phi[0,3]  R440      -1.9989881515502930e+00
    phi[0,3]  R441      -1.8163536787033081e+00
    phi[0,3]  R442      -1.1768816709518433e+00
    phi[0,3]  R443      -1.3853995800018311e+00
    phi[0,3]  R444      -1.3591876626014709e-01
    phi[0,3]  R445      -1.8913567066192627e+00
    phi[0,3]  R446      -1.1932204961776733e+00
    phi[0,3]  R447      3.4694093465805054e-01
    phi[0,3]  R448      -8.3041828870773315e-01
    phi[0,3]  R449      -1.8628000020980835e+00
    phi[0,3]  R450      -1.8884301185607910e+00
    phi[0,3]  R451      -1.8649417161941528e+00
    phi[0,3]  R452      -6.4381957054138184e-01
    phi[0,3]  R453      6.9499778747558594e-01
    phi[0,3]  R454      8.9956074953079224e-01
    phi[0,3]  R455      7.3563170433044434e-01
    phi[0,3]  R456      -1.7262135744094849e+00
    phi[0,3]  R457      -1.2428110837936401e+00
    phi[0,3]  R458      -1.3499498367309570e+00
    phi[0,3]  R459      9.4736057519912720e-01
    phi[0,3]  R460      -5.8488780260086060e-01
    phi[0,3]  R461      -5.2990150451660156e-01
    phi[0,3]  R462      -0.00199287012219429
    phi[0,3]  R463      -7.1599656343460083e-01
    phi[0,3]  R464      -4.1697301864624023e+00
    phi[0,3]  R465      -1.2905484437942505e+00
    phi[0,3]  R466      -2.1979658603668213e+00
    phi[0,3]  R467      -1.8974057435989380e+00
    phi[0,3]  R468      -2.7606399059295654e+00
    phi[0,3]  R469      -3.5632009506225586e+00
    phi[0,3]  R470      -5.4470491409301758e-01
    phi[0,3]  R471      -1.7707933187484741e+00
    phi[0,3]  R472      -3.7486145496368408e+00
    phi[0,3]  R473      -1.8345013856887817e+00
    phi[0,3]  R474      -1.4156557321548462e+00
    phi[0,3]  R475      -3.4021177291870117e+00
    phi[0,3]  R476      -2.01997447013855
    phi[0,3]  R477      -1.2330245971679688e+00
    phi[0,3]  R478      -1.2636178731918335e+00
    phi[0,3]  R479      -1.1317048072814941e+00
    phi[0,3]  R480      -1.0400702953338623e+00
    phi[0,3]  R481      -1.1615731716156006e+00
    phi[0,3]  R482      -4.5204665511846542e-03
    phi[0,3]  R483      8.6048346757888794e-01
    phi[0,3]  R484      0.360653281211853
    phi[0,3]  R485      5.4866266250610352e-01
    phi[0,3]  R486      -2.1474535465240479e+00
    phi[0,3]  R487      -2.2765618562698364e-01
    phi[0,3]  R488      -7.0563733577728271e-01
    phi[0,3]  R489      -1.4656791687011719e+00
    phi[0,3]  R490      -2.0150632858276367e+00
    phi[0,3]  R491      -1.8557472229003906e+00
    phi[0,3]  R492      -1.0790758132934570e+00
    phi[0,3]  R493      -1.1064099073410034e+00
    phi[0,3]  R494      -1.0920997858047485e+00
    phi[0,3]  R495      -2.7300566434860229e-01
    phi[0,3]  R496      -1.6855542659759521e+00
    phi[0,3]  R497      -1.7401901483535767e+00
    phi[0,3]  R498      -2.1001372337341309e+00
    phi[0,3]  R499      -2.1688518524169922e+00
    phi[0,3]  R500      -1.7625073194503784e+00
    phi[0,3]  R501      -2.6412544250488281e+00
    phi[0,3]  R502      -7.0061731338500977e-01
    phi[0,3]  R503      -1.2378821372985840e+00
    phi[0,3]  R504      7.0247960090637207e-01
    phi[0,3]  R505      5.7947534322738647e-01
    phi[0,3]  R506      -1.3546532392501831e+00
    phi[0,3]  R507      -2.8948230743408203e+00
    phi[0,3]  R508      -1.5189614295959473e+00
    phi[0,3]  R509      -1.3839241266250610e+00
    phi[0,3]  R510      -9.4123214483261108e-01
    phi[0,3]  R511      -4.0870947837829590e+00
    phi[0,3]  R512      -1.7704143524169922e+00
    phi[0,3]  R513      -1.2808636426925659e+00
    phi[0,3]  R514      5.3298449516296387e-01
    phi[0,3]  R515      1.2065466642379761e+00
    phi[0,3]  R516      -1.9929404258728027e+00
    phi[0,3]  R517      -1.4228389263153076e+00
    phi[0,3]  R518      -1.3925457000732422e+00
    phi[0,3]  R519      -1.3748539686203003e+00
    phi[0,3]  R520      -4.2888915538787842e-01
    phi[0,3]  R521      -1.5428522825241089e+00
    phi[0,3]  R522      7.1888887882232666e-01
    phi[0,3]  R523      3.1354889273643494e-01
    phi[0,3]  R524      4.9898996949195862e-01
    phi[0,3]  R525      6.9089096784591675e-01
    phi[0,3]  R526      -2.1247973442077637e+00
    phi[0,3]  R527      -1.7874052524566650e+00
    phi[0,3]  R528      -1.8864042758941650e+00
    phi[0,3]  R529      -2.2732176780700684e+00
    phi[0,3]  R530      -1.3407192230224609e+00
    phi[0,3]  R531      -1.6556298732757568e+00
    phi[0,3]  R532      -1.4301735162734985e+00
    phi[0,3]  R533      -1.1262396574020386e+00
    phi[0,3]  R534      -1.6197975873947144e+00
    phi[0,3]  R535      1.06780207157135
    phi[3,0]  R0        -1
    phi[3,0]  R27       1
    phi[3,0]  R28       1
    phi[3,0]  R536      -3.0999999046325684e+00
    phi[3,0]  R537      -3.0999999046325684e+00
    phi[3,0]  R538      -2.2400000095367432e+00
    phi[3,0]  R539      -2.2400000095367432e+00
    phi[3,0]  R540      -3.0999999046325684e+00
    phi[3,0]  R541      -3.0999999046325684e+00
    phi[3,0]  R542      -2.5699999332427979e+00
    phi[3,0]  R543      -2.5699999332427979e+00
    phi[3,0]  R544      -3.0999999046325684e+00
    phi[3,0]  R545      -3.0999999046325684e+00
    phi[3,0]  R546      -2.0899999141693115e+00
    phi[3,0]  R547      -2.0899999141693115e+00
    phi[3,0]  R548      -3.0999999046325684e+00
    phi[3,0]  R549      -3.0999999046325684e+00
    phi[3,0]  R550      -1.8628000020980835e+00
    phi[3,0]  R551      -1.8884301185607910e+00
    phi[3,0]  R552      -1.2341090440750122e+00
    phi[3,0]  R553      -9.8038172721862793e-01
    phi[3,0]  R554      -1.8649417161941528e+00
    phi[3,0]  R555      -1.03556489944458
    phi[3,0]  R556      -6.4381957054138184e-01
    phi[3,0]  R557      6.9499778747558594e-01
    phi[3,0]  R558      8.9956074953079224e-01
    phi[3,0]  R559      7.3563170433044434e-01
    phi[3,0]  R560      -1.7262135744094849e+00
    phi[3,0]  R561      -1.2428110837936401e+00
    phi[3,0]  R562      -1.3499498367309570e+00
    phi[3,0]  R563      9.4736057519912720e-01
    phi[3,0]  R564      -5.8488780260086060e-01
    phi[3,0]  R565      -5.2990150451660156e-01
    phi[3,0]  R566      -0.00199287012219429
    phi[3,0]  R567      -7.1599656343460083e-01
    phi[3,0]  R568      -4.1697301864624023e+00
    phi[3,0]  R569      -1.2905484437942505e+00
    phi[3,0]  R570      -2.1979658603668213e+00
    phi[3,0]  R571      -1.8974057435989380e+00
    phi[3,0]  R572      -2.7606399059295654e+00
    phi[3,0]  R573      -3.5632009506225586e+00
    phi[3,0]  R574      -5.4470491409301758e-01
    phi[3,0]  R575      -1.7707933187484741e+00
    phi[3,0]  R576      -3.7486145496368408e+00
    phi[3,0]  R577      -1.8345013856887817e+00
    phi[3,0]  R578      -1.4156557321548462e+00
    phi[3,0]  R579      -3.4021177291870117e+00
    phi[3,0]  R580      -2.01997447013855
    phi[3,0]  R581      -1.2330245971679688e+00
    phi[3,0]  R582      -1.2636178731918335e+00
    phi[3,0]  R583      -1.1317048072814941e+00
    phi[3,0]  R584      -1.0400702953338623e+00
    phi[3,0]  R585      -1.1615731716156006e+00
    phi[3,0]  R586      -4.5204665511846542e-03
    phi[3,0]  R587      8.6048346757888794e-01
    phi[3,0]  R588      0.360653281211853
    phi[3,0]  R589      5.4866266250610352e-01
    phi[3,0]  R590      -2.1474535465240479e+00
    phi[3,0]  R591      -2.2765618562698364e-01
    phi[3,0]  R592      -7.0563733577728271e-01
    phi[3,0]  R593      -1.4656791687011719e+00
    phi[3,0]  R594      -2.0150632858276367e+00
    phi[3,0]  R595      -1.8557472229003906e+00
    phi[3,0]  R596      -1.0790758132934570e+00
    phi[3,0]  R597      -1.1064099073410034e+00
    phi[3,0]  R598      -1.0920997858047485e+00
    phi[3,0]  R599      -2.7300566434860229e-01
    phi[3,0]  R600      -1.6855542659759521e+00
    phi[3,0]  R601      -1.7401901483535767e+00
    phi[3,0]  R602      -2.1001372337341309e+00
    phi[3,0]  R603      -2.1688518524169922e+00
    phi[3,0]  R604      -1.7625073194503784e+00
    phi[3,0]  R605      -2.6412544250488281e+00
    phi[3,0]  R606      -7.0061731338500977e-01
    phi[3,0]  R607      -1.2378821372985840e+00
    phi[3,0]  R608      7.0247960090637207e-01
    phi[3,0]  R609      5.7947534322738647e-01
    phi[3,0]  R610      -1.3546532392501831e+00
    phi[3,0]  R611      -2.8948230743408203e+00
    phi[3,0]  R612      -1.5189614295959473e+00
    phi[3,0]  R613      -1.3839241266250610e+00
    phi[3,0]  R614      -9.4123214483261108e-01
    phi[3,0]  R615      -4.0870947837829590e+00
    phi[3,0]  R616      -1.7704143524169922e+00
    phi[3,0]  R617      -1.2808636426925659e+00
    phi[3,0]  R618      5.3298449516296387e-01
    phi[3,0]  R619      1.2065466642379761e+00
    phi[3,0]  R620      -1.9929404258728027e+00
    phi[3,0]  R621      -1.4228389263153076e+00
    phi[3,0]  R622      -1.3925457000732422e+00
    phi[3,0]  R623      -1.3748539686203003e+00
    phi[3,0]  R624      -4.2888915538787842e-01
    phi[3,0]  R625      -1.5428522825241089e+00
    phi[3,0]  R626      7.1888887882232666e-01
    phi[3,0]  R627      3.1354889273643494e-01
    phi[3,0]  R628      4.9898996949195862e-01
    phi[3,0]  R629      6.9089096784591675e-01
    phi[3,0]  R630      -2.1247973442077637e+00
    phi[3,0]  R631      -1.7874052524566650e+00
    phi[3,0]  R632      -1.8864042758941650e+00
    phi[3,0]  R633      -2.2732176780700684e+00
    phi[3,0]  R634      -1.3407192230224609e+00
    phi[3,0]  R635      -1.6556298732757568e+00
    phi[3,0]  R636      -1.4301735162734985e+00
    phi[3,0]  R637      -1.1262396574020386e+00
    phi[3,0]  R638      -1.6197975873947144e+00
    phi[3,0]  R639      1.06780207157135
    phi[3,0]  R640      9.0388625860214233e-01
    phi[3,0]  R641      9.7242355346679688e-01
    phi[3,0]  R642      4.2592161893844604e-01
    phi[3,0]  R643      1.2247036695480347e+00
    phi[3,0]  R644      9.6322655677795410e-01
    phi[3,0]  R645      -9.3915200233459473e-01
    phi[3,0]  R646      9.5571047067642212e-01
    phi[3,0]  R647      -9.5137453079223633e-01
    phi[3,0]  R648      -1.3062409162521362e+00
    phi[3,0]  R649      -2.1127641201019287e+00
    phi[3,0]  R650      -1.1656520366668701e+00
    phi[3,0]  R651      -3.3780453205108643e+00
    phi[3,0]  R652      -4.8484435677528381e-01
    phi[3,0]  R653      -6.9695830345153809e-01
    phi[3,0]  R654      -1.8065074682235718e+00
    phi[3,0]  R655      -7.5354123115539551e-01
    phi[3,0]  R656      -2.0101463794708252e+00
    phi[3,0]  R657      -2.4692502021789551e+00
    phi[3,0]  R658      -2.8727500438690186e+00
    phi[3,0]  R659      -3.6658790111541748e+00
    phi[3,0]  R660      -8.4497094154357910e-01
    phi[3,0]  R661      -8.9308500289916992e-01
    phi[3,0]  R662      -1.7221144437789917e+00
    phi[3,0]  R663      -1.6172307729721069e+00
    phi[3,0]  R664      -3.1539819240570068e+00
    phi[3,0]  R665      -2.5537202358245850e+00
    phi[3,0]  R666      -1.4053852558135986e+00
    phi[3,0]  R667      -1.3655986785888672e+00
    phi[3,0]  R668      -7.8273534774780273e-01
    phi[3,0]  R669      -2.4237787723541260e+00
    phi[3,0]  R670      -2.0907337665557861e+00
    phi[3,0]  R671      -1.3551462888717651e+00
    phi[3,0]  R672      8.1263726949691772e-01
    phi[3,0]  R673      -2.1113321781158447e+00
    phi[3,0]  R674      -1.0176339149475098e+00
    phi[3,0]  R675      -8.8592779636383057e-01
    phi[3,0]  R676      -1.3973553180694580e+00
    phi[3,0]  R677      -1.5521695613861084e+00
    phi[3,0]  R678      -1.0973352193832397e+00
    phi[3,0]  R679      -1.7850900888442993e+00
    phi[3,0]  R680      -2.0543990135192871e+00
    phi[3,0]  R681      -5.2965217828750610e-01
    phi[3,0]  R682      -1.0902556180953979e+00
    phi[3,0]  R683      -6.2409496307373047e-01
    phi[3,0]  R684      -1.8844892978668213e+00
    phi[3,0]  R685      -4.3241259455680847e-01
    phi[3,0]  R686      -1.4691774845123291e+00
    phi[3,0]  R687      -8.5957753658294678e-01
    phi[3,0]  R688      -1.9989881515502930e+00
    phi[3,0]  R689      -1.8163536787033081e+00
    phi[3,0]  R690      -1.1768816709518433e+00
    phi[3,0]  R691      -1.3853995800018311e+00
    phi[3,0]  R692      -1.3591876626014709e-01
    phi[3,0]  R693      -1.8913567066192627e+00
    phi[3,0]  R694      -1.1932204961776733e+00
    phi[3,0]  R695      3.4694093465805054e-01
    phi[3,0]  R696      -8.3041828870773315e-01
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R697      -3.0999999046325684e+00
    phi[0,4]  R698      -3.0999999046325684e+00
    phi[0,4]  R699      -2.2400000095367432e+00
    phi[0,4]  R700      -2.2400000095367432e+00
    phi[0,4]  R701      -3.0999999046325684e+00
    phi[0,4]  R702      -3.0999999046325684e+00
    phi[0,4]  R703      -2.5699999332427979e+00
    phi[0,4]  R704      -2.5699999332427979e+00
    phi[0,4]  R705      -3.0999999046325684e+00
    phi[0,4]  R706      -3.0999999046325684e+00
    phi[0,4]  R707      -2.0899999141693115e+00
    phi[0,4]  R708      -2.0899999141693115e+00
    phi[0,4]  R709      -3.0999999046325684e+00
    phi[0,4]  R710      -3.0999999046325684e+00
    phi[0,4]  R711      -1.2341090440750122e+00
    phi[0,4]  R712      -9.8038172721862793e-01
    phi[0,4]  R713      -1.03556489944458
    phi[0,4]  R714      9.0388625860214233e-01
    phi[0,4]  R715      9.7242355346679688e-01
    phi[0,4]  R716      4.2592161893844604e-01
    phi[0,4]  R717      1.2247036695480347e+00
    phi[0,4]  R718      9.6322655677795410e-01
    phi[0,4]  R719      -9.3915200233459473e-01
    phi[0,4]  R720      9.5571047067642212e-01
    phi[0,4]  R721      -9.5137453079223633e-01
    phi[0,4]  R722      -1.3062409162521362e+00
    phi[0,4]  R723      -2.1127641201019287e+00
    phi[0,4]  R724      -1.1656520366668701e+00
    phi[0,4]  R725      -3.3780453205108643e+00
    phi[0,4]  R726      -4.8484435677528381e-01
    phi[0,4]  R727      -6.9695830345153809e-01
    phi[0,4]  R728      -1.8065074682235718e+00
    phi[0,4]  R729      -7.5354123115539551e-01
    phi[0,4]  R730      -2.0101463794708252e+00
    phi[0,4]  R731      -2.4692502021789551e+00
    phi[0,4]  R732      -2.8727500438690186e+00
    phi[0,4]  R733      -3.6658790111541748e+00
    phi[0,4]  R734      -8.4497094154357910e-01
    phi[0,4]  R735      -8.9308500289916992e-01
    phi[0,4]  R736      -1.7221144437789917e+00
    phi[0,4]  R737      -1.6172307729721069e+00
    phi[0,4]  R738      -3.1539819240570068e+00
    phi[0,4]  R739      -2.5537202358245850e+00
    phi[0,4]  R740      -1.4053852558135986e+00
    phi[0,4]  R741      -1.3655986785888672e+00
    phi[0,4]  R742      -7.8273534774780273e-01
    phi[0,4]  R743      -2.4237787723541260e+00
    phi[0,4]  R744      -2.0907337665557861e+00
    phi[0,4]  R745      -1.3551462888717651e+00
    phi[0,4]  R746      8.1263726949691772e-01
    phi[0,4]  R747      -2.1113321781158447e+00
    phi[0,4]  R748      -1.0176339149475098e+00
    phi[0,4]  R749      -8.8592779636383057e-01
    phi[0,4]  R750      -1.3973553180694580e+00
    phi[0,4]  R751      -1.5521695613861084e+00
    phi[0,4]  R752      -1.0973352193832397e+00
    phi[0,4]  R753      -1.7850900888442993e+00
    phi[0,4]  R754      -2.0543990135192871e+00
    phi[0,4]  R755      -5.2965217828750610e-01
    phi[0,4]  R756      -1.0902556180953979e+00
    phi[0,4]  R757      -6.2409496307373047e-01
    phi[0,4]  R758      -1.8844892978668213e+00
    phi[0,4]  R759      -4.3241259455680847e-01
    phi[0,4]  R760      -1.4691774845123291e+00
    phi[0,4]  R761      -8.5957753658294678e-01
    phi[0,4]  R762      -1.9989881515502930e+00
    phi[0,4]  R763      -1.8163536787033081e+00
    phi[0,4]  R764      -1.1768816709518433e+00
    phi[0,4]  R765      -1.3853995800018311e+00
    phi[0,4]  R766      -1.3591876626014709e-01
    phi[0,4]  R767      -1.8913567066192627e+00
    phi[0,4]  R768      -1.1932204961776733e+00
    phi[0,4]  R769      3.4694093465805054e-01
    phi[0,4]  R770      -8.3041828870773315e-01
    phi[0,4]  R771      1.77676522731781
    phi[0,4]  R772      -2.7310687303543091e-01
    phi[0,4]  R773      8.4315592050552368e-01
    phi[0,4]  R774      7.2433346509933472e-01
    phi[0,4]  R775      3.0531431548297405e-03
    phi[0,4]  R776      -2.4557695388793945e+00
    phi[0,4]  R777      -7.8808504343032837e-01
    phi[0,4]  R778      1.0043582916259766e+00
    phi[0,4]  R779      0.432986855506897
    phi[0,4]  R780      7.5547367334365845e-01
    phi[0,4]  R781      -2.2095894813537598e+00
    phi[0,4]  R782      -1.8047202825546265e+00
    phi[0,4]  R783      -1.3643928766250610e+00
    phi[0,4]  R784      -1.6939057111740112e+00
    phi[0,4]  R785      -1.6116505861282349e+00
    phi[0,4]  R786      -6.2830054759979248e-01
    phi[0,4]  R787      -2.1316418647766113e+00
    phi[0,4]  R788      -1.6049240827560425e+00
    phi[0,4]  R789      -2.2179672718048096e+00
    phi[0,4]  R790      -1.1599769592285156e+00
    phi[0,4]  R791      -9.0186208486557007e-01
    phi[0,4]  R792      -1.4049866795539856e-01
    phi[0,4]  R793      -1.4456121921539307e+00
    phi[0,4]  R794      -1.4821659326553345e+00
    phi[0,4]  R795      -1.3954963684082031e+00
    phi[0,4]  R796      -9.7181499004364014e-01
    phi[0,4]  R797      -1.7135679721832275e+00
    phi[0,4]  R798      -2.2601163387298584e+00
    phi[0,4]  R799      -1.7387723922729492e+00
    phi[0,4]  R800      -1.8921539783477783e+00
    phi[0,4]  R801      1.8802841007709503e-01
    phi[0,4]  R802      -8.7025982141494751e-01
    phi[0,4]  R803      -1.2329555749893188e+00
    phi[0,4]  R804      -7.4449771642684937e-01
    phi[0,4]  R805      -1.7946573495864868e+00
    phi[0,4]  R806      -1.3221839666366577e+00
    phi[0,4]  R807      -1.7423173189163208e+00
    phi[0,4]  R808      -2.0342874526977539e+00
    phi[0,4]  R809      -8.9844125509262085e-01
    phi[0,4]  R810      -8.8837021589279175e-01
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R811      -3.0999999046325684e+00
    phi[4,0]  R812      -3.0999999046325684e+00
    phi[4,0]  R813      -2.2400000095367432e+00
    phi[4,0]  R814      -2.2400000095367432e+00
    phi[4,0]  R815      -3.0999999046325684e+00
    phi[4,0]  R816      -3.0999999046325684e+00
    phi[4,0]  R817      -2.5699999332427979e+00
    phi[4,0]  R818      -2.5699999332427979e+00
    phi[4,0]  R819      -3.0999999046325684e+00
    phi[4,0]  R820      -3.0999999046325684e+00
    phi[4,0]  R821      -2.0899999141693115e+00
    phi[4,0]  R822      -2.0899999141693115e+00
    phi[4,0]  R823      -3.0999999046325684e+00
    phi[4,0]  R824      -3.0999999046325684e+00
    phi[4,0]  R825      1.77676522731781
    phi[4,0]  R826      -2.7310687303543091e-01
    phi[4,0]  R827      8.4315592050552368e-01
    phi[4,0]  R828      7.2433346509933472e-01
    phi[4,0]  R829      3.0531431548297405e-03
    phi[4,0]  R830      -2.4557695388793945e+00
    phi[4,0]  R831      -7.8808504343032837e-01
    phi[4,0]  R832      1.0043582916259766e+00
    phi[4,0]  R833      0.432986855506897
    phi[4,0]  R834      7.5547367334365845e-01
    phi[4,0]  R835      -2.2095894813537598e+00
    phi[4,0]  R836      -1.8047202825546265e+00
    phi[4,0]  R837      -1.3643928766250610e+00
    phi[4,0]  R838      -1.6939057111740112e+00
    phi[4,0]  R839      -1.6116505861282349e+00
    phi[4,0]  R840      -6.2830054759979248e-01
    phi[4,0]  R841      -2.1316418647766113e+00
    phi[4,0]  R842      -1.6049240827560425e+00
    phi[4,0]  R843      -2.2179672718048096e+00
    phi[4,0]  R844      -1.1599769592285156e+00
    phi[4,0]  R845      -9.0186208486557007e-01
    phi[4,0]  R846      -1.4049866795539856e-01
    phi[4,0]  R847      -1.4456121921539307e+00
    phi[4,0]  R848      -1.4821659326553345e+00
    phi[4,0]  R849      -1.3954963684082031e+00
    phi[4,0]  R850      -9.7181499004364014e-01
    phi[4,0]  R851      -1.7135679721832275e+00
    phi[4,0]  R852      -2.2601163387298584e+00
    phi[4,0]  R853      -1.7387723922729492e+00
    phi[4,0]  R854      -1.8921539783477783e+00
    phi[4,0]  R855      1.8802841007709503e-01
    phi[4,0]  R856      -8.7025982141494751e-01
    phi[4,0]  R857      -1.2329555749893188e+00
    phi[4,0]  R858      -7.4449771642684937e-01
    phi[4,0]  R859      -1.7946573495864868e+00
    phi[4,0]  R860      -1.3221839666366577e+00
    phi[4,0]  R861      -1.7423173189163208e+00
    phi[4,0]  R862      -2.0342874526977539e+00
    phi[4,0]  R863      -8.9844125509262085e-01
    phi[4,0]  R864      -8.8837021589279175e-01
    phi[4,0]  R865      -1.2341090440750122e+00
    phi[4,0]  R866      -9.8038172721862793e-01
    phi[4,0]  R867      -1.03556489944458
    phi[4,0]  R868      9.0388625860214233e-01
    phi[4,0]  R869      9.7242355346679688e-01
    phi[4,0]  R870      4.2592161893844604e-01
    phi[4,0]  R871      1.2247036695480347e+00
    phi[4,0]  R872      9.6322655677795410e-01
    phi[4,0]  R873      -9.3915200233459473e-01
    phi[4,0]  R874      9.5571047067642212e-01
    phi[4,0]  R875      -9.5137453079223633e-01
    phi[4,0]  R876      -1.3062409162521362e+00
    phi[4,0]  R877      -2.1127641201019287e+00
    phi[4,0]  R878      -1.1656520366668701e+00
    phi[4,0]  R879      -3.3780453205108643e+00
    phi[4,0]  R880      -4.8484435677528381e-01
    phi[4,0]  R881      -6.9695830345153809e-01
    phi[4,0]  R882      -1.8065074682235718e+00
    phi[4,0]  R883      -7.5354123115539551e-01
    phi[4,0]  R884      -2.0101463794708252e+00
    phi[4,0]  R885      -2.4692502021789551e+00
    phi[4,0]  R886      -2.8727500438690186e+00
    phi[4,0]  R887      -3.6658790111541748e+00
    phi[4,0]  R888      -8.4497094154357910e-01
    phi[4,0]  R889      -8.9308500289916992e-01
    phi[4,0]  R890      -1.7221144437789917e+00
    phi[4,0]  R891      -1.6172307729721069e+00
    phi[4,0]  R892      -3.1539819240570068e+00
    phi[4,0]  R893      -2.5537202358245850e+00
    phi[4,0]  R894      -1.4053852558135986e+00
    phi[4,0]  R895      -1.3655986785888672e+00
    phi[4,0]  R896      -7.8273534774780273e-01
    phi[4,0]  R897      -2.4237787723541260e+00
    phi[4,0]  R898      -2.0907337665557861e+00
    phi[4,0]  R899      -1.3551462888717651e+00
    phi[4,0]  R900      8.1263726949691772e-01
    phi[4,0]  R901      -2.1113321781158447e+00
    phi[4,0]  R902      -1.0176339149475098e+00
    phi[4,0]  R903      -8.8592779636383057e-01
    phi[4,0]  R904      -1.3973553180694580e+00
    phi[4,0]  R905      -1.5521695613861084e+00
    phi[4,0]  R906      -1.0973352193832397e+00
    phi[4,0]  R907      -1.7850900888442993e+00
    phi[4,0]  R908      -2.0543990135192871e+00
    phi[4,0]  R909      -5.2965217828750610e-01
    phi[4,0]  R910      -1.0902556180953979e+00
    phi[4,0]  R911      -6.2409496307373047e-01
    phi[4,0]  R912      -1.8844892978668213e+00
    phi[4,0]  R913      -4.3241259455680847e-01
    phi[4,0]  R914      -1.4691774845123291e+00
    phi[4,0]  R915      -8.5957753658294678e-01
    phi[4,0]  R916      -1.9989881515502930e+00
    phi[4,0]  R917      -1.8163536787033081e+00
    phi[4,0]  R918      -1.1768816709518433e+00
    phi[4,0]  R919      -1.3853995800018311e+00
    phi[4,0]  R920      -1.3591876626014709e-01
    phi[4,0]  R921      -1.8913567066192627e+00
    phi[4,0]  R922      -1.1932204961776733e+00
    phi[4,0]  R923      3.4694093465805054e-01
    phi[4,0]  R924      -8.3041828870773315e-01
    phi[5,0]  R0        -1
    phi[5,0]  R2        -2.2778502514963908e+00
    phi[5,0]  R3        9.8689348846324343e-01
    phi[5,0]  R4        2.4473104432550925e+00
    phi[5,0]  R5        5.6725888747584330e-01
    phi[5,0]  R6        -7.9833431042921887e-01
    phi[5,0]  R7        1.0529369927095336e+00
    phi[5,0]  R8        1.2868532219312194e+00
    phi[5,0]  R45       1
    phi[5,0]  R925      -8.2214965313617761e-01
    phi[5,0]  R926      -5.3778501561289591e+00
    phi[5,0]  R927      -3.2268934979999866e+00
    phi[5,0]  R928      -1.2531065210734997e+00
    phi[5,0]  R929      -5.5473103478876613e+00
    phi[5,0]  R930      -6.5268946137747585e-01
    phi[5,0]  R931      -3.1372588207186412e+00
    phi[5,0]  R932      -2.0027410457669546e+00
    phi[5,0]  R933      -2.3016655942033495e+00
    phi[5,0]  R934      -3.8983342150617872e+00
    phi[5,0]  R935      -3.1429369068788451e+00
    phi[5,0]  R936      -1.0370629214597780e+00
    phi[5,0]  R937      -4.3868531265637873e+00
    phi[5,0]  R938      -1.8131466827013489e+00
    phi[5,0]  R939      -3.9135284161170725e-01
    phi[5,0]  R940      -3.9260835551367812e-01
    phi[5,0]  R941      -4.1445385571189286e-01
    phi[5,0]  R942      -4.3833468457264413e-01
    phi[5,0]  R943      -4.7215441900199240e-01
    phi[5,0]  R944      -4.7403899021391105e-01
    phi[5,0]  R945      -4.7960682016178868e-01
    phi[5,0]  R946      -4.9155526298113772e-01
    phi[5,0]  R947      -4.9192794978455423e-01
    phi[5,0]  R948      -4.9779994922507487e-01
    phi[5,0]  R949      -4.1892930231872982e-01
    phi[5,0]  R950      -4.5786811948411921e-01
    phi[5,0]  R951      -4.6706362811231483e-01
    phi[5,0]  R952      -5.0258851128869464e-01
    phi[5,0]  R953      -5.2854361450111664e-01
    phi[5,0]  R954      -0.548778719895141
    phi[5,0]  R955      -5.5482312581517357e-01
    phi[5,0]  R956      -5.7088978160870685e-01
    phi[5,0]  R957      -5.8781964001187059e-01
    phi[5,0]  R958      -6.2392300589124083e-01
    phi[5,0]  R959      -3.0058707465434242e-01
    phi[5,0]  R960      -3.1862396378650359e-01
    phi[5,0]  R961      -3.4841890915881546e-01
    phi[5,0]  R962      -3.6383564244190447e-01
    phi[5,0]  R963      -0.378394253836287
    phi[5,0]  R964      -3.7922170650589160e-01
    phi[5,0]  R965      -3.8631368278459810e-01
    phi[5,0]  R966      -4.3740463131312612e-01
    phi[5,0]  R967      -5.0368127122916651e-01
    phi[5,0]  R968      -5.3984207295860043e-01
    phi[5,0]  R969      -3.4848043655327388e-01
    phi[5,0]  R970      -4.3195003020339617e-01
    phi[5,0]  R971      -5.8227433410797058e-01
    phi[5,0]  R972      -6.4480518910978435e-01
    phi[5,0]  R973      -6.7967088224461081e-01
    phi[5,0]  R974      -0.713514615806027
    phi[5,0]  R975      -7.2221043668209339e-01
    phi[5,0]  R976      -7.3690771314868475e-01
    phi[5,0]  R977      -7.4110516269940774e-01
    phi[5,0]  R978      -7.6175771320852737e-01
    phi[5,0]  R979      -4.4370752477997311e-01
    phi[5,0]  R980      -4.4698788261054134e-01
    phi[5,0]  R981      -6.4656030850006241e-01
    phi[5,0]  R982      -7.3095173710722716e-01
    phi[5,0]  R983      -2.75120792457741
    phi[5,0]  R984      -7.4354105399359560e-01
    phi[5,0]  R985      -7.9431665435050058e-01
    phi[5,0]  R986      -8.1922485535040535e-01
    phi[5,0]  R987      -3.1225112553370216e+00
    phi[5,0]  R988      -8.3417552897418168e-01
    phi[5,0]  R989      -6.1287978190564973e-01
    phi[5,0]  R990      -6.5231997048572987e-01
    phi[5,0]  R991      -6.6548520460778127e-01
    phi[5,0]  R992      -6.7330236848308944e-01
    phi[5,0]  R993      -6.8158294799094865e-01
    phi[5,0]  R994      -7.4127734550623059e-01
    phi[5,0]  R995      -7.9527117659185276e-01
    phi[5,0]  R996      -7.9720480175603758e-01
    phi[5,0]  R997      -1.6253640136208063e+00
    phi[5,0]  R998      -9.6965144319935781e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R999      -3.0999999046325684e+00
    phi[1,2]  R1000     -3.0999999046325684e+00
    phi[1,2]  R1001     -2.2400000095367432e+00
    phi[1,2]  R1002     -2.2400000095367432e+00
    phi[1,2]  R1003     -3.0999999046325684e+00
    phi[1,2]  R1004     -3.0999999046325684e+00
    phi[1,2]  R1005     -2.5699999332427979e+00
    phi[1,2]  R1006     -2.5699999332427979e+00
    phi[1,2]  R1007     -3.0999999046325684e+00
    phi[1,2]  R1008     -3.0999999046325684e+00
    phi[1,2]  R1009     -2.0899999141693115e+00
    phi[1,2]  R1010     -2.0899999141693115e+00
    phi[1,2]  R1011     -3.0999999046325684e+00
    phi[1,2]  R1012     -3.0999999046325684e+00
    phi[1,2]  R1013     2.2953796386718750e-01
    phi[1,2]  R1014     1.0304706096649170e+00
    phi[1,2]  R1015     -4.1439521312713623e-01
    phi[1,2]  R1016     0.24210225045681
    phi[1,2]  R1017     3.3544987440109253e-01
    phi[1,2]  R1018     -9.2660534381866455e-01
    phi[1,2]  R1019     -7.5631928443908691e-01
    phi[1,2]  R1020     2.1012984216213226e-01
    phi[1,2]  R1021     -3.1239548325538635e-01
    phi[1,2]  R1022     -1.1931275576353073e-01
    phi[1,2]  R1023     -1.9321343898773193e+00
    phi[1,2]  R1024     -1.8925678730010986e+00
    phi[1,2]  R1025     -1.6593906879425049e+00
    phi[1,2]  R1026     1.0698325186967850e-01
    phi[1,2]  R1027     1.3713088631629944e-01
    phi[1,2]  R1028     3.0111670494079590e-01
    phi[1,2]  R1029     0.062712162733078
    phi[1,2]  R1030     6.4283460378646851e-01
    phi[1,2]  R1031     3.6917710304260254e-01
    phi[1,2]  R1032     7.6192575693130493e-01
    phi[1,2]  R1033     -1.1395325660705566e+00
    phi[1,2]  R1034     -5.9893929958343506e-01
    phi[1,2]  R1035     -1.5031230449676514e+00
    phi[1,2]  R1036     -1.3366020917892456e+00
    phi[1,2]  R1037     -1.1719367504119873e+00
    phi[1,2]  R1038     -1.5393635034561157e+00
    phi[1,2]  R1039     -2.2131805419921875e+00
    phi[1,2]  R1040     -2.2875556349754333e-01
    phi[1,2]  R1041     2.0869490504264832e-01
    phi[1,2]  R1042     -2.8643736839294434e+00
    phi[1,2]  R1043     -2.5076618194580078e+00
    phi[1,2]  R1044     -2.14526104927063
    phi[1,2]  R1045     -5.2298164367675781e-01
    phi[1,2]  R1046     -9.4787108898162842e-01
    phi[1,2]  R1047     -1.2137928009033203e+00
    phi[1,2]  R1048     -3.8181905746459961e+00
    phi[1,2]  R1049     -1.1628155708312988e+00
    phi[1,2]  R1050     -1.6416127681732178e+00
    phi[1,2]  R1051     -1.6099681854248047e+00
    phi[1,2]  R1052     -1.3271917104721069e+00
    phi[1,2]  R1053     -2.1820611953735352e+00
    phi[1,2]  R1054     -1.3258926868438721e+00
    phi[1,2]  R1055     -1.3318003714084625e-01
    phi[1,2]  R1056     1.7273834347724915e-01
    phi[1,2]  R1057     7.3616409301757812e-01
    phi[1,2]  R1058     -3.0655763149261475e+00
    phi[1,2]  R1059     -3.2563374042510986e+00
    phi[1,2]  R1060     -2.0490498542785645e+00
    phi[1,2]  R1061     -5.2686321735382080e-01
    phi[1,2]  R1062     -1.1256014108657837e+00
    phi[1,2]  R1063     -1.2982035875320435e+00
    phi[1,2]  R1064     -7.4548697471618652e-01
    phi[1,2]  R1065     -2.6498675346374512e+00
    phi[1,2]  R1066     -1.8641465902328491e+00
    phi[1,2]  R1067     -6.8749696016311646e-02
    phi[1,2]  R1068     -1.6977532207965851e-01
    phi[1,2]  R1069     -2.0735110342502594e-01
    phi[1,2]  R1070     -0.362966388463974
    phi[1,2]  R1071     -1.4825825691223145e+00
    phi[1,2]  R1072     7.3841445147991180e-02
    phi[1,2]  R1073     -2.1178109645843506e+00
    phi[1,2]  R1074     3.5554066300392151e-01
    phi[1,2]  R1075     -9.7308611869812012e-01
    phi[1,2]  R1076     -6.4851516485214233e-01
    phi[1,2]  R1077     -2.1288216114044189e+00
    phi[1,2]  R1078     -1.60283362865448
    phi[1,2]  R1079     -1.7038503885269165e+00
    phi[1,2]  R1080     -2.5109903812408447e+00
    phi[1,2]  R1081     -2.2294936180114746e+00
    phi[1,2]  R1082     -2.7906489372253418e+00
    phi[1,2]  R1083     -1.2178258895874023e+00
    phi[1,2]  R1084     -1.7553027868270874e+00
    phi[1,2]  R1085     -2.6975861191749573e-01
    phi[1,2]  R1086     -2.3918833732604980e+00
    phi[1,2]  R1087     -1.2880640029907227e+00
    phi[1,2]  R1088     -2.1998276710510254e+00
    phi[1,2]  R1089     -2.5881690979003906e+00
    phi[1,2]  R1090     -1.7120409011840820e+00
    phi[1,2]  R1091     -2.5651578903198242e+00
    phi[1,2]  R1092     -2.5395088195800781e+00
    phi[1,2]  R1093     -1.3417088985443115e+00
    phi[1,2]  R1094     -1.4215285778045654e+00
    phi[1,2]  R1095     -3.9309658110141754e-02
    phi[1,2]  R1096     -3.3711355924606323e-01
    phi[1,2]  R1097     -1.7408809661865234e+00
    phi[1,2]  R1098     2.6205414906144142e-02
    phi[1,2]  R1099     -1.1624306440353394e+00
    phi[1,2]  R1100     -1.0412735939025879e+00
    phi[1,2]  R1101     -1.1779898405075073e+00
    phi[1,2]  R1102     -7.1380782127380371e-01
    phi[1,2]  R1103     1.9452095031738281e+00
    phi[1,2]  R1104     -6.2412649393081665e-01
    phi[1,2]  R1105     1.6723034381866455e+00
    phi[1,2]  R1106     1.9240204989910126e-01
    phi[1,2]  R1107     -2.7192444801330566e+00
    phi[1,2]  R1108     1.16908860206604
    phi[1,2]  R1109     5.0218605995178223e-01
    phi[1,2]  R1110     -1.1753953695297241e+00
    phi[1,2]  R1111     -1.1711049079895020e+00
    phi[1,2]  R1112     -1.6423443555831909e+00
    phi[1,2]  R1113     -1.1882181167602539e+00
    phi[1,2]  R1114     8.4122262895107269e-02
    phi[1,2]  R1115     -5.0071603059768677e-01
    phi[1,2]  R1116     -1.4752833843231201e+00
    phi[1,2]  R1117     -5.4669743776321411e-01
    phi[1,2]  R1118     3.4834407269954681e-02
    phi[1,2]  R1119     -2.5193035602569580e-01
    phi[1,2]  R1120     -1.2623063325881958e+00
    phi[1,2]  R1121     -1.5422010421752930e+00
    phi[1,2]  R1122     -9.6058857440948486e-01
    phi[1,2]  R1123     3.3337265253067017e-01
    phi[1,2]  R1124     -1.07700777053833
    phi[1,2]  R1125     -9.4294482469558716e-01
    phi[1,2]  R1126     -1.8155435323715210e+00
    phi[1,2]  R1127     -1.8112736940383911e+00
    phi[1,2]  R1128     -5.6068807840347290e-01
    phi[1,2]  R1129     -1.8283889293670654e+00
    phi[1,2]  R1130     -2.0797080993652344e+00
    phi[1,2]  R1131     -1.1033776998519897e+00
    phi[1,2]  R1132     -6.4915165305137634e-02
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R1133     -3.0999999046325684e+00
    phi[2,1]  R1134     -3.0999999046325684e+00
    phi[2,1]  R1135     -2.2400000095367432e+00
    phi[2,1]  R1136     -2.2400000095367432e+00
    phi[2,1]  R1137     -3.0999999046325684e+00
    phi[2,1]  R1138     -3.0999999046325684e+00
    phi[2,1]  R1139     -2.5699999332427979e+00
    phi[2,1]  R1140     -2.5699999332427979e+00
    phi[2,1]  R1141     -3.0999999046325684e+00
    phi[2,1]  R1142     -3.0999999046325684e+00
    phi[2,1]  R1143     -2.0899999141693115e+00
    phi[2,1]  R1144     -2.0899999141693115e+00
    phi[2,1]  R1145     -3.0999999046325684e+00
    phi[2,1]  R1146     -3.0999999046325684e+00
    phi[2,1]  R1147     1.9452095031738281e+00
    phi[2,1]  R1148     -6.2412649393081665e-01
    phi[2,1]  R1149     1.6723034381866455e+00
    phi[2,1]  R1150     1.9240204989910126e-01
    phi[2,1]  R1151     -2.7192444801330566e+00
    phi[2,1]  R1152     1.16908860206604
    phi[2,1]  R1153     5.0218605995178223e-01
    phi[2,1]  R1154     -1.1753953695297241e+00
    phi[2,1]  R1155     -1.1711049079895020e+00
    phi[2,1]  R1156     -1.6423443555831909e+00
    phi[2,1]  R1157     -1.1882181167602539e+00
    phi[2,1]  R1158     8.4122262895107269e-02
    phi[2,1]  R1159     -5.0071603059768677e-01
    phi[2,1]  R1160     -1.4752833843231201e+00
    phi[2,1]  R1161     -5.4669743776321411e-01
    phi[2,1]  R1162     3.4834407269954681e-02
    phi[2,1]  R1163     -2.5193035602569580e-01
    phi[2,1]  R1164     -1.2623063325881958e+00
    phi[2,1]  R1165     -1.5422010421752930e+00
    phi[2,1]  R1166     -9.6058857440948486e-01
    phi[2,1]  R1167     3.3337265253067017e-01
    phi[2,1]  R1168     -1.07700777053833
    phi[2,1]  R1169     -9.4294482469558716e-01
    phi[2,1]  R1170     -1.8155435323715210e+00
    phi[2,1]  R1171     -1.8112736940383911e+00
    phi[2,1]  R1172     -5.6068807840347290e-01
    phi[2,1]  R1173     -1.8283889293670654e+00
    phi[2,1]  R1174     -2.0797080993652344e+00
    phi[2,1]  R1175     -1.1033776998519897e+00
    phi[2,1]  R1176     -6.4915165305137634e-02
    phi[2,1]  R1177     2.2953796386718750e-01
    phi[2,1]  R1178     1.0304706096649170e+00
    phi[2,1]  R1179     -4.1439521312713623e-01
    phi[2,1]  R1180     0.24210225045681
    phi[2,1]  R1181     3.3544987440109253e-01
    phi[2,1]  R1182     -9.2660534381866455e-01
    phi[2,1]  R1183     -7.5631928443908691e-01
    phi[2,1]  R1184     2.1012984216213226e-01
    phi[2,1]  R1185     -3.1239548325538635e-01
    phi[2,1]  R1186     -1.1931275576353073e-01
    phi[2,1]  R1187     -1.9321343898773193e+00
    phi[2,1]  R1188     -1.8925678730010986e+00
    phi[2,1]  R1189     -1.6593906879425049e+00
    phi[2,1]  R1190     1.0698325186967850e-01
    phi[2,1]  R1191     1.3713088631629944e-01
    phi[2,1]  R1192     3.0111670494079590e-01
    phi[2,1]  R1193     0.062712162733078
    phi[2,1]  R1194     6.4283460378646851e-01
    phi[2,1]  R1195     3.6917710304260254e-01
    phi[2,1]  R1196     7.6192575693130493e-01
    phi[2,1]  R1197     -1.1395325660705566e+00
    phi[2,1]  R1198     -5.9893929958343506e-01
    phi[2,1]  R1199     -1.5031230449676514e+00
    phi[2,1]  R1200     -1.3366020917892456e+00
    phi[2,1]  R1201     -1.1719367504119873e+00
    phi[2,1]  R1202     -1.5393635034561157e+00
    phi[2,1]  R1203     -2.2131805419921875e+00
    phi[2,1]  R1204     -2.2875556349754333e-01
    phi[2,1]  R1205     2.0869490504264832e-01
    phi[2,1]  R1206     -2.8643736839294434e+00
    phi[2,1]  R1207     -2.5076618194580078e+00
    phi[2,1]  R1208     -2.14526104927063
    phi[2,1]  R1209     -5.2298164367675781e-01
    phi[2,1]  R1210     -9.4787108898162842e-01
    phi[2,1]  R1211     -1.2137928009033203e+00
    phi[2,1]  R1212     -3.8181905746459961e+00
    phi[2,1]  R1213     -1.1628155708312988e+00
    phi[2,1]  R1214     -1.6416127681732178e+00
    phi[2,1]  R1215     -1.6099681854248047e+00
    phi[2,1]  R1216     -1.3271917104721069e+00
    phi[2,1]  R1217     -2.1820611953735352e+00
    phi[2,1]  R1218     -1.3258926868438721e+00
    phi[2,1]  R1219     -1.3318003714084625e-01
    phi[2,1]  R1220     1.7273834347724915e-01
    phi[2,1]  R1221     7.3616409301757812e-01
    phi[2,1]  R1222     -3.0655763149261475e+00
    phi[2,1]  R1223     -3.2563374042510986e+00
    phi[2,1]  R1224     -2.0490498542785645e+00
    phi[2,1]  R1225     -5.2686321735382080e-01
    phi[2,1]  R1226     -1.1256014108657837e+00
    phi[2,1]  R1227     -1.2982035875320435e+00
    phi[2,1]  R1228     -7.4548697471618652e-01
    phi[2,1]  R1229     -2.6498675346374512e+00
    phi[2,1]  R1230     -1.8641465902328491e+00
    phi[2,1]  R1231     -6.8749696016311646e-02
    phi[2,1]  R1232     -1.6977532207965851e-01
    phi[2,1]  R1233     -2.0735110342502594e-01
    phi[2,1]  R1234     -0.362966388463974
    phi[2,1]  R1235     -1.4825825691223145e+00
    phi[2,1]  R1236     7.3841445147991180e-02
    phi[2,1]  R1237     -2.1178109645843506e+00
    phi[2,1]  R1238     3.5554066300392151e-01
    phi[2,1]  R1239     -9.7308611869812012e-01
    phi[2,1]  R1240     -6.4851516485214233e-01
    phi[2,1]  R1241     -2.1288216114044189e+00
    phi[2,1]  R1242     -1.60283362865448
    phi[2,1]  R1243     -1.7038503885269165e+00
    phi[2,1]  R1244     -2.5109903812408447e+00
    phi[2,1]  R1245     -2.2294936180114746e+00
    phi[2,1]  R1246     -2.7906489372253418e+00
    phi[2,1]  R1247     -1.2178258895874023e+00
    phi[2,1]  R1248     -1.7553027868270874e+00
    phi[2,1]  R1249     -2.6975861191749573e-01
    phi[2,1]  R1250     -2.3918833732604980e+00
    phi[2,1]  R1251     -1.2880640029907227e+00
    phi[2,1]  R1252     -2.1998276710510254e+00
    phi[2,1]  R1253     -2.5881690979003906e+00
    phi[2,1]  R1254     -1.7120409011840820e+00
    phi[2,1]  R1255     -2.5651578903198242e+00
    phi[2,1]  R1256     -2.5395088195800781e+00
    phi[2,1]  R1257     -1.3417088985443115e+00
    phi[2,1]  R1258     -1.4215285778045654e+00
    phi[2,1]  R1259     -3.9309658110141754e-02
    phi[2,1]  R1260     -3.3711355924606323e-01
    phi[2,1]  R1261     -1.7408809661865234e+00
    phi[2,1]  R1262     2.6205414906144142e-02
    phi[2,1]  R1263     -1.1624306440353394e+00
    phi[2,1]  R1264     -1.0412735939025879e+00
    phi[2,1]  R1265     -1.1779898405075073e+00
    phi[2,1]  R1266     -7.1380782127380371e-01
    phi[1,3]  R9        1
    phi[1,3]  R10       1
    phi[1,3]  R27       -1
    phi[1,3]  R1267     -3.0999999046325684e+00
    phi[1,3]  R1268     -3.0999999046325684e+00
    phi[1,3]  R1269     -2.2400000095367432e+00
    phi[1,3]  R1270     -2.2400000095367432e+00
    phi[1,3]  R1271     -3.0999999046325684e+00
    phi[1,3]  R1272     -3.0999999046325684e+00
    phi[1,3]  R1273     -2.5699999332427979e+00
    phi[1,3]  R1274     -2.5699999332427979e+00
    phi[1,3]  R1275     -3.0999999046325684e+00
    phi[1,3]  R1276     -3.0999999046325684e+00
    phi[1,3]  R1277     -2.0899999141693115e+00
    phi[1,3]  R1278     -2.0899999141693115e+00
    phi[1,3]  R1279     -3.0999999046325684e+00
    phi[1,3]  R1280     -3.0999999046325684e+00
    phi[1,3]  R1281     2.2953796386718750e-01
    phi[1,3]  R1282     1.0304706096649170e+00
    phi[1,3]  R1283     -4.1439521312713623e-01
    phi[1,3]  R1284     0.24210225045681
    phi[1,3]  R1285     3.3544987440109253e-01
    phi[1,3]  R1286     -9.2660534381866455e-01
    phi[1,3]  R1287     -7.5631928443908691e-01
    phi[1,3]  R1288     2.1012984216213226e-01
    phi[1,3]  R1289     -3.1239548325538635e-01
    phi[1,3]  R1290     -1.1931275576353073e-01
    phi[1,3]  R1291     -1.9321343898773193e+00
    phi[1,3]  R1292     -1.8925678730010986e+00
    phi[1,3]  R1293     -1.6593906879425049e+00
    phi[1,3]  R1294     1.0698325186967850e-01
    phi[1,3]  R1295     1.3713088631629944e-01
    phi[1,3]  R1296     3.0111670494079590e-01
    phi[1,3]  R1297     0.062712162733078
    phi[1,3]  R1298     6.4283460378646851e-01
    phi[1,3]  R1299     3.6917710304260254e-01
    phi[1,3]  R1300     7.6192575693130493e-01
    phi[1,3]  R1301     -1.1395325660705566e+00
    phi[1,3]  R1302     -5.9893929958343506e-01
    phi[1,3]  R1303     -1.5031230449676514e+00
    phi[1,3]  R1304     -1.3366020917892456e+00
    phi[1,3]  R1305     -1.1719367504119873e+00
    phi[1,3]  R1306     -1.5393635034561157e+00
    phi[1,3]  R1307     -2.2131805419921875e+00
    phi[1,3]  R1308     -2.2875556349754333e-01
    phi[1,3]  R1309     2.0869490504264832e-01
    phi[1,3]  R1310     -2.8643736839294434e+00
    phi[1,3]  R1311     -2.5076618194580078e+00
    phi[1,3]  R1312     -2.14526104927063
    phi[1,3]  R1313     -5.2298164367675781e-01
    phi[1,3]  R1314     -9.4787108898162842e-01
    phi[1,3]  R1315     -1.2137928009033203e+00
    phi[1,3]  R1316     -3.8181905746459961e+00
    phi[1,3]  R1317     -1.1628155708312988e+00
    phi[1,3]  R1318     -1.6416127681732178e+00
    phi[1,3]  R1319     -1.6099681854248047e+00
    phi[1,3]  R1320     -1.3271917104721069e+00
    phi[1,3]  R1321     -2.1820611953735352e+00
    phi[1,3]  R1322     -1.3258926868438721e+00
    phi[1,3]  R1323     -1.3318003714084625e-01
    phi[1,3]  R1324     1.7273834347724915e-01
    phi[1,3]  R1325     7.3616409301757812e-01
    phi[1,3]  R1326     -3.0655763149261475e+00
    phi[1,3]  R1327     -3.2563374042510986e+00
    phi[1,3]  R1328     -2.0490498542785645e+00
    phi[1,3]  R1329     -5.2686321735382080e-01
    phi[1,3]  R1330     -1.1256014108657837e+00
    phi[1,3]  R1331     -1.2982035875320435e+00
    phi[1,3]  R1332     -7.4548697471618652e-01
    phi[1,3]  R1333     -2.6498675346374512e+00
    phi[1,3]  R1334     -1.8641465902328491e+00
    phi[1,3]  R1335     -6.8749696016311646e-02
    phi[1,3]  R1336     -1.6977532207965851e-01
    phi[1,3]  R1337     -2.0735110342502594e-01
    phi[1,3]  R1338     -0.362966388463974
    phi[1,3]  R1339     -1.4825825691223145e+00
    phi[1,3]  R1340     7.3841445147991180e-02
    phi[1,3]  R1341     -2.1178109645843506e+00
    phi[1,3]  R1342     3.5554066300392151e-01
    phi[1,3]  R1343     -9.7308611869812012e-01
    phi[1,3]  R1344     -6.4851516485214233e-01
    phi[1,3]  R1345     -2.1288216114044189e+00
    phi[1,3]  R1346     -1.60283362865448
    phi[1,3]  R1347     -1.7038503885269165e+00
    phi[1,3]  R1348     -2.5109903812408447e+00
    phi[1,3]  R1349     -2.2294936180114746e+00
    phi[1,3]  R1350     -2.7906489372253418e+00
    phi[1,3]  R1351     -1.2178258895874023e+00
    phi[1,3]  R1352     -1.7553027868270874e+00
    phi[1,3]  R1353     -2.6975861191749573e-01
    phi[1,3]  R1354     -2.3918833732604980e+00
    phi[1,3]  R1355     -1.2880640029907227e+00
    phi[1,3]  R1356     -2.1998276710510254e+00
    phi[1,3]  R1357     -2.5881690979003906e+00
    phi[1,3]  R1358     -1.7120409011840820e+00
    phi[1,3]  R1359     -2.5651578903198242e+00
    phi[1,3]  R1360     -2.5395088195800781e+00
    phi[1,3]  R1361     -1.3417088985443115e+00
    phi[1,3]  R1362     -1.4215285778045654e+00
    phi[1,3]  R1363     -3.9309658110141754e-02
    phi[1,3]  R1364     -3.3711355924606323e-01
    phi[1,3]  R1365     -1.7408809661865234e+00
    phi[1,3]  R1366     2.6205414906144142e-02
    phi[1,3]  R1367     -1.1624306440353394e+00
    phi[1,3]  R1368     -1.0412735939025879e+00
    phi[1,3]  R1369     -1.1779898405075073e+00
    phi[1,3]  R1370     -7.1380782127380371e-01
    phi[1,3]  R1371     -1.8628000020980835e+00
    phi[1,3]  R1372     -1.8884301185607910e+00
    phi[1,3]  R1373     -1.2341090440750122e+00
    phi[1,3]  R1374     -9.8038172721862793e-01
    phi[1,3]  R1375     -1.8649417161941528e+00
    phi[1,3]  R1376     -1.03556489944458
    phi[1,3]  R1377     -6.4381957054138184e-01
    phi[1,3]  R1378     6.9499778747558594e-01
    phi[1,3]  R1379     8.9956074953079224e-01
    phi[1,3]  R1380     7.3563170433044434e-01
    phi[1,3]  R1381     -1.7262135744094849e+00
    phi[1,3]  R1382     -1.2428110837936401e+00
    phi[1,3]  R1383     -1.3499498367309570e+00
    phi[1,3]  R1384     9.4736057519912720e-01
    phi[1,3]  R1385     -5.8488780260086060e-01
    phi[1,3]  R1386     -5.2990150451660156e-01
    phi[1,3]  R1387     -0.00199287012219429
    phi[1,3]  R1388     -7.1599656343460083e-01
    phi[1,3]  R1389     -4.1697301864624023e+00
    phi[1,3]  R1390     -1.2905484437942505e+00
    phi[1,3]  R1391     -2.1979658603668213e+00
    phi[1,3]  R1392     -1.8974057435989380e+00
    phi[1,3]  R1393     -2.7606399059295654e+00
    phi[1,3]  R1394     -3.5632009506225586e+00
    phi[1,3]  R1395     -5.4470491409301758e-01
    phi[1,3]  R1396     -1.7707933187484741e+00
    phi[1,3]  R1397     -3.7486145496368408e+00
    phi[1,3]  R1398     -1.8345013856887817e+00
    phi[1,3]  R1399     -1.4156557321548462e+00
    phi[1,3]  R1400     -3.4021177291870117e+00
    phi[1,3]  R1401     -2.01997447013855
    phi[1,3]  R1402     -1.2330245971679688e+00
    phi[1,3]  R1403     -1.2636178731918335e+00
    phi[1,3]  R1404     -1.1317048072814941e+00
    phi[1,3]  R1405     -1.0400702953338623e+00
    phi[1,3]  R1406     -1.1615731716156006e+00
    phi[1,3]  R1407     -4.5204665511846542e-03
    phi[1,3]  R1408     8.6048346757888794e-01
    phi[1,3]  R1409     0.360653281211853
    phi[1,3]  R1410     5.4866266250610352e-01
    phi[1,3]  R1411     -2.1474535465240479e+00
    phi[1,3]  R1412     -2.2765618562698364e-01
    phi[1,3]  R1413     -7.0563733577728271e-01
    phi[1,3]  R1414     -1.4656791687011719e+00
    phi[1,3]  R1415     -2.0150632858276367e+00
    phi[1,3]  R1416     -1.8557472229003906e+00
    phi[1,3]  R1417     -1.0790758132934570e+00
    phi[1,3]  R1418     -1.1064099073410034e+00
    phi[1,3]  R1419     -1.0920997858047485e+00
    phi[1,3]  R1420     -2.7300566434860229e-01
    phi[1,3]  R1421     -1.6855542659759521e+00
    phi[1,3]  R1422     -1.7401901483535767e+00
    phi[1,3]  R1423     -2.1001372337341309e+00
    phi[1,3]  R1424     -2.1688518524169922e+00
    phi[1,3]  R1425     -1.7625073194503784e+00
    phi[1,3]  R1426     -2.6412544250488281e+00
    phi[1,3]  R1427     -7.0061731338500977e-01
    phi[1,3]  R1428     -1.2378821372985840e+00
    phi[1,3]  R1429     7.0247960090637207e-01
    phi[1,3]  R1430     5.7947534322738647e-01
    phi[1,3]  R1431     -1.3546532392501831e+00
    phi[1,3]  R1432     -2.8948230743408203e+00
    phi[1,3]  R1433     -1.5189614295959473e+00
    phi[1,3]  R1434     -1.3839241266250610e+00
    phi[1,3]  R1435     -9.4123214483261108e-01
    phi[1,3]  R1436     -4.0870947837829590e+00
    phi[1,3]  R1437     -1.7704143524169922e+00
    phi[1,3]  R1438     -1.2808636426925659e+00
    phi[1,3]  R1439     5.3298449516296387e-01
    phi[1,3]  R1440     1.2065466642379761e+00
    phi[1,3]  R1441     -1.9929404258728027e+00
    phi[1,3]  R1442     -1.4228389263153076e+00
    phi[1,3]  R1443     -1.3925457000732422e+00
    phi[1,3]  R1444     -1.3748539686203003e+00
    phi[1,3]  R1445     -4.2888915538787842e-01
    phi[1,3]  R1446     -1.5428522825241089e+00
    phi[1,3]  R1447     7.1888887882232666e-01
    phi[1,3]  R1448     3.1354889273643494e-01
    phi[1,3]  R1449     4.9898996949195862e-01
    phi[1,3]  R1450     6.9089096784591675e-01
    phi[1,3]  R1451     -2.1247973442077637e+00
    phi[1,3]  R1452     -1.7874052524566650e+00
    phi[1,3]  R1453     -1.8864042758941650e+00
    phi[1,3]  R1454     -2.2732176780700684e+00
    phi[1,3]  R1455     -1.3407192230224609e+00
    phi[1,3]  R1456     -1.6556298732757568e+00
    phi[1,3]  R1457     -1.4301735162734985e+00
    phi[1,3]  R1458     -1.1262396574020386e+00
    phi[1,3]  R1459     -1.6197975873947144e+00
    phi[1,3]  R1460     1.06780207157135
    phi[3,1]  R9        -1
    phi[3,1]  R27       1
    phi[3,1]  R28       1
    phi[3,1]  R1461     -3.0999999046325684e+00
    phi[3,1]  R1462     -3.0999999046325684e+00
    phi[3,1]  R1463     -2.2400000095367432e+00
    phi[3,1]  R1464     -2.2400000095367432e+00
    phi[3,1]  R1465     -3.0999999046325684e+00
    phi[3,1]  R1466     -3.0999999046325684e+00
    phi[3,1]  R1467     -2.5699999332427979e+00
    phi[3,1]  R1468     -2.5699999332427979e+00
    phi[3,1]  R1469     -3.0999999046325684e+00
    phi[3,1]  R1470     -3.0999999046325684e+00
    phi[3,1]  R1471     -2.0899999141693115e+00
    phi[3,1]  R1472     -2.0899999141693115e+00
    phi[3,1]  R1473     -3.0999999046325684e+00
    phi[3,1]  R1474     -3.0999999046325684e+00
    phi[3,1]  R1475     -1.8628000020980835e+00
    phi[3,1]  R1476     -1.8884301185607910e+00
    phi[3,1]  R1477     -1.2341090440750122e+00
    phi[3,1]  R1478     -9.8038172721862793e-01
    phi[3,1]  R1479     -1.8649417161941528e+00
    phi[3,1]  R1480     -1.03556489944458
    phi[3,1]  R1481     -6.4381957054138184e-01
    phi[3,1]  R1482     6.9499778747558594e-01
    phi[3,1]  R1483     8.9956074953079224e-01
    phi[3,1]  R1484     7.3563170433044434e-01
    phi[3,1]  R1485     -1.7262135744094849e+00
    phi[3,1]  R1486     -1.2428110837936401e+00
    phi[3,1]  R1487     -1.3499498367309570e+00
    phi[3,1]  R1488     9.4736057519912720e-01
    phi[3,1]  R1489     -5.8488780260086060e-01
    phi[3,1]  R1490     -5.2990150451660156e-01
    phi[3,1]  R1491     -0.00199287012219429
    phi[3,1]  R1492     -7.1599656343460083e-01
    phi[3,1]  R1493     -4.1697301864624023e+00
    phi[3,1]  R1494     -1.2905484437942505e+00
    phi[3,1]  R1495     -2.1979658603668213e+00
    phi[3,1]  R1496     -1.8974057435989380e+00
    phi[3,1]  R1497     -2.7606399059295654e+00
    phi[3,1]  R1498     -3.5632009506225586e+00
    phi[3,1]  R1499     -5.4470491409301758e-01
    phi[3,1]  R1500     -1.7707933187484741e+00
    phi[3,1]  R1501     -3.7486145496368408e+00
    phi[3,1]  R1502     -1.8345013856887817e+00
    phi[3,1]  R1503     -1.4156557321548462e+00
    phi[3,1]  R1504     -3.4021177291870117e+00
    phi[3,1]  R1505     -2.01997447013855
    phi[3,1]  R1506     -1.2330245971679688e+00
    phi[3,1]  R1507     -1.2636178731918335e+00
    phi[3,1]  R1508     -1.1317048072814941e+00
    phi[3,1]  R1509     -1.0400702953338623e+00
    phi[3,1]  R1510     -1.1615731716156006e+00
    phi[3,1]  R1511     -4.5204665511846542e-03
    phi[3,1]  R1512     8.6048346757888794e-01
    phi[3,1]  R1513     0.360653281211853
    phi[3,1]  R1514     5.4866266250610352e-01
    phi[3,1]  R1515     -2.1474535465240479e+00
    phi[3,1]  R1516     -2.2765618562698364e-01
    phi[3,1]  R1517     -7.0563733577728271e-01
    phi[3,1]  R1518     -1.4656791687011719e+00
    phi[3,1]  R1519     -2.0150632858276367e+00
    phi[3,1]  R1520     -1.8557472229003906e+00
    phi[3,1]  R1521     -1.0790758132934570e+00
    phi[3,1]  R1522     -1.1064099073410034e+00
    phi[3,1]  R1523     -1.0920997858047485e+00
    phi[3,1]  R1524     -2.7300566434860229e-01
    phi[3,1]  R1525     -1.6855542659759521e+00
    phi[3,1]  R1526     -1.7401901483535767e+00
    phi[3,1]  R1527     -2.1001372337341309e+00
    phi[3,1]  R1528     -2.1688518524169922e+00
    phi[3,1]  R1529     -1.7625073194503784e+00
    phi[3,1]  R1530     -2.6412544250488281e+00
    phi[3,1]  R1531     -7.0061731338500977e-01
    phi[3,1]  R1532     -1.2378821372985840e+00
    phi[3,1]  R1533     7.0247960090637207e-01
    phi[3,1]  R1534     5.7947534322738647e-01
    phi[3,1]  R1535     -1.3546532392501831e+00
    phi[3,1]  R1536     -2.8948230743408203e+00
    phi[3,1]  R1537     -1.5189614295959473e+00
    phi[3,1]  R1538     -1.3839241266250610e+00
    phi[3,1]  R1539     -9.4123214483261108e-01
    phi[3,1]  R1540     -4.0870947837829590e+00
    phi[3,1]  R1541     -1.7704143524169922e+00
    phi[3,1]  R1542     -1.2808636426925659e+00
    phi[3,1]  R1543     5.3298449516296387e-01
    phi[3,1]  R1544     1.2065466642379761e+00
    phi[3,1]  R1545     -1.9929404258728027e+00
    phi[3,1]  R1546     -1.4228389263153076e+00
    phi[3,1]  R1547     -1.3925457000732422e+00
    phi[3,1]  R1548     -1.3748539686203003e+00
    phi[3,1]  R1549     -4.2888915538787842e-01
    phi[3,1]  R1550     -1.5428522825241089e+00
    phi[3,1]  R1551     7.1888887882232666e-01
    phi[3,1]  R1552     3.1354889273643494e-01
    phi[3,1]  R1553     4.9898996949195862e-01
    phi[3,1]  R1554     6.9089096784591675e-01
    phi[3,1]  R1555     -2.1247973442077637e+00
    phi[3,1]  R1556     -1.7874052524566650e+00
    phi[3,1]  R1557     -1.8864042758941650e+00
    phi[3,1]  R1558     -2.2732176780700684e+00
    phi[3,1]  R1559     -1.3407192230224609e+00
    phi[3,1]  R1560     -1.6556298732757568e+00
    phi[3,1]  R1561     -1.4301735162734985e+00
    phi[3,1]  R1562     -1.1262396574020386e+00
    phi[3,1]  R1563     -1.6197975873947144e+00
    phi[3,1]  R1564     1.06780207157135
    phi[3,1]  R1565     2.2953796386718750e-01
    phi[3,1]  R1566     1.0304706096649170e+00
    phi[3,1]  R1567     -4.1439521312713623e-01
    phi[3,1]  R1568     0.24210225045681
    phi[3,1]  R1569     3.3544987440109253e-01
    phi[3,1]  R1570     -9.2660534381866455e-01
    phi[3,1]  R1571     -7.5631928443908691e-01
    phi[3,1]  R1572     2.1012984216213226e-01
    phi[3,1]  R1573     -3.1239548325538635e-01
    phi[3,1]  R1574     -1.1931275576353073e-01
    phi[3,1]  R1575     -1.9321343898773193e+00
    phi[3,1]  R1576     -1.8925678730010986e+00
    phi[3,1]  R1577     -1.6593906879425049e+00
    phi[3,1]  R1578     1.0698325186967850e-01
    phi[3,1]  R1579     1.3713088631629944e-01
    phi[3,1]  R1580     3.0111670494079590e-01
    phi[3,1]  R1581     0.062712162733078
    phi[3,1]  R1582     6.4283460378646851e-01
    phi[3,1]  R1583     3.6917710304260254e-01
    phi[3,1]  R1584     7.6192575693130493e-01
    phi[3,1]  R1585     -1.1395325660705566e+00
    phi[3,1]  R1586     -5.9893929958343506e-01
    phi[3,1]  R1587     -1.5031230449676514e+00
    phi[3,1]  R1588     -1.3366020917892456e+00
    phi[3,1]  R1589     -1.1719367504119873e+00
    phi[3,1]  R1590     -1.5393635034561157e+00
    phi[3,1]  R1591     -2.2131805419921875e+00
    phi[3,1]  R1592     -2.2875556349754333e-01
    phi[3,1]  R1593     2.0869490504264832e-01
    phi[3,1]  R1594     -2.8643736839294434e+00
    phi[3,1]  R1595     -2.5076618194580078e+00
    phi[3,1]  R1596     -2.14526104927063
    phi[3,1]  R1597     -5.2298164367675781e-01
    phi[3,1]  R1598     -9.4787108898162842e-01
    phi[3,1]  R1599     -1.2137928009033203e+00
    phi[3,1]  R1600     -3.8181905746459961e+00
    phi[3,1]  R1601     -1.1628155708312988e+00
    phi[3,1]  R1602     -1.6416127681732178e+00
    phi[3,1]  R1603     -1.6099681854248047e+00
    phi[3,1]  R1604     -1.3271917104721069e+00
    phi[3,1]  R1605     -2.1820611953735352e+00
    phi[3,1]  R1606     -1.3258926868438721e+00
    phi[3,1]  R1607     -1.3318003714084625e-01
    phi[3,1]  R1608     1.7273834347724915e-01
    phi[3,1]  R1609     7.3616409301757812e-01
    phi[3,1]  R1610     -3.0655763149261475e+00
    phi[3,1]  R1611     -3.2563374042510986e+00
    phi[3,1]  R1612     -2.0490498542785645e+00
    phi[3,1]  R1613     -5.2686321735382080e-01
    phi[3,1]  R1614     -1.1256014108657837e+00
    phi[3,1]  R1615     -1.2982035875320435e+00
    phi[3,1]  R1616     -7.4548697471618652e-01
    phi[3,1]  R1617     -2.6498675346374512e+00
    phi[3,1]  R1618     -1.8641465902328491e+00
    phi[3,1]  R1619     -6.8749696016311646e-02
    phi[3,1]  R1620     -1.6977532207965851e-01
    phi[3,1]  R1621     -2.0735110342502594e-01
    phi[3,1]  R1622     -0.362966388463974
    phi[3,1]  R1623     -1.4825825691223145e+00
    phi[3,1]  R1624     7.3841445147991180e-02
    phi[3,1]  R1625     -2.1178109645843506e+00
    phi[3,1]  R1626     3.5554066300392151e-01
    phi[3,1]  R1627     -9.7308611869812012e-01
    phi[3,1]  R1628     -6.4851516485214233e-01
    phi[3,1]  R1629     -2.1288216114044189e+00
    phi[3,1]  R1630     -1.60283362865448
    phi[3,1]  R1631     -1.7038503885269165e+00
    phi[3,1]  R1632     -2.5109903812408447e+00
    phi[3,1]  R1633     -2.2294936180114746e+00
    phi[3,1]  R1634     -2.7906489372253418e+00
    phi[3,1]  R1635     -1.2178258895874023e+00
    phi[3,1]  R1636     -1.7553027868270874e+00
    phi[3,1]  R1637     -2.6975861191749573e-01
    phi[3,1]  R1638     -2.3918833732604980e+00
    phi[3,1]  R1639     -1.2880640029907227e+00
    phi[3,1]  R1640     -2.1998276710510254e+00
    phi[3,1]  R1641     -2.5881690979003906e+00
    phi[3,1]  R1642     -1.7120409011840820e+00
    phi[3,1]  R1643     -2.5651578903198242e+00
    phi[3,1]  R1644     -2.5395088195800781e+00
    phi[3,1]  R1645     -1.3417088985443115e+00
    phi[3,1]  R1646     -1.4215285778045654e+00
    phi[3,1]  R1647     -3.9309658110141754e-02
    phi[3,1]  R1648     -3.3711355924606323e-01
    phi[3,1]  R1649     -1.7408809661865234e+00
    phi[3,1]  R1650     2.6205414906144142e-02
    phi[3,1]  R1651     -1.1624306440353394e+00
    phi[3,1]  R1652     -1.0412735939025879e+00
    phi[3,1]  R1653     -1.1779898405075073e+00
    phi[3,1]  R1654     -7.1380782127380371e-01
    phi[1,4]  R9        1
    phi[1,4]  R10       1
    phi[1,4]  R36       -1
    phi[1,4]  R1655     -3.0999999046325684e+00
    phi[1,4]  R1656     -3.0999999046325684e+00
    phi[1,4]  R1657     -2.2400000095367432e+00
    phi[1,4]  R1658     -2.2400000095367432e+00
    phi[1,4]  R1659     -3.0999999046325684e+00
    phi[1,4]  R1660     -3.0999999046325684e+00
    phi[1,4]  R1661     -2.5699999332427979e+00
    phi[1,4]  R1662     -2.5699999332427979e+00
    phi[1,4]  R1663     -3.0999999046325684e+00
    phi[1,4]  R1664     -3.0999999046325684e+00
    phi[1,4]  R1665     -2.0899999141693115e+00
    phi[1,4]  R1666     -2.0899999141693115e+00
    phi[1,4]  R1667     -3.0999999046325684e+00
    phi[1,4]  R1668     -3.0999999046325684e+00
    phi[1,4]  R1669     2.2953796386718750e-01
    phi[1,4]  R1670     1.0304706096649170e+00
    phi[1,4]  R1671     -4.1439521312713623e-01
    phi[1,4]  R1672     0.24210225045681
    phi[1,4]  R1673     3.3544987440109253e-01
    phi[1,4]  R1674     -9.2660534381866455e-01
    phi[1,4]  R1675     -7.5631928443908691e-01
    phi[1,4]  R1676     2.1012984216213226e-01
    phi[1,4]  R1677     -3.1239548325538635e-01
    phi[1,4]  R1678     -1.1931275576353073e-01
    phi[1,4]  R1679     -1.9321343898773193e+00
    phi[1,4]  R1680     -1.8925678730010986e+00
    phi[1,4]  R1681     -1.6593906879425049e+00
    phi[1,4]  R1682     1.0698325186967850e-01
    phi[1,4]  R1683     1.3713088631629944e-01
    phi[1,4]  R1684     3.0111670494079590e-01
    phi[1,4]  R1685     0.062712162733078
    phi[1,4]  R1686     6.4283460378646851e-01
    phi[1,4]  R1687     3.6917710304260254e-01
    phi[1,4]  R1688     7.6192575693130493e-01
    phi[1,4]  R1689     -1.1395325660705566e+00
    phi[1,4]  R1690     -5.9893929958343506e-01
    phi[1,4]  R1691     -1.5031230449676514e+00
    phi[1,4]  R1692     -1.3366020917892456e+00
    phi[1,4]  R1693     -1.1719367504119873e+00
    phi[1,4]  R1694     -1.5393635034561157e+00
    phi[1,4]  R1695     -2.2131805419921875e+00
    phi[1,4]  R1696     -2.2875556349754333e-01
    phi[1,4]  R1697     2.0869490504264832e-01
    phi[1,4]  R1698     -2.8643736839294434e+00
    phi[1,4]  R1699     -2.5076618194580078e+00
    phi[1,4]  R1700     -2.14526104927063
    phi[1,4]  R1701     -5.2298164367675781e-01
    phi[1,4]  R1702     -9.4787108898162842e-01
    phi[1,4]  R1703     -1.2137928009033203e+00
    phi[1,4]  R1704     -3.8181905746459961e+00
    phi[1,4]  R1705     -1.1628155708312988e+00
    phi[1,4]  R1706     -1.6416127681732178e+00
    phi[1,4]  R1707     -1.6099681854248047e+00
    phi[1,4]  R1708     -1.3271917104721069e+00
    phi[1,4]  R1709     -2.1820611953735352e+00
    phi[1,4]  R1710     -1.3258926868438721e+00
    phi[1,4]  R1711     -1.3318003714084625e-01
    phi[1,4]  R1712     1.7273834347724915e-01
    phi[1,4]  R1713     7.3616409301757812e-01
    phi[1,4]  R1714     -3.0655763149261475e+00
    phi[1,4]  R1715     -3.2563374042510986e+00
    phi[1,4]  R1716     -2.0490498542785645e+00
    phi[1,4]  R1717     -5.2686321735382080e-01
    phi[1,4]  R1718     -1.1256014108657837e+00
    phi[1,4]  R1719     -1.2982035875320435e+00
    phi[1,4]  R1720     -7.4548697471618652e-01
    phi[1,4]  R1721     -2.6498675346374512e+00
    phi[1,4]  R1722     -1.8641465902328491e+00
    phi[1,4]  R1723     -6.8749696016311646e-02
    phi[1,4]  R1724     -1.6977532207965851e-01
    phi[1,4]  R1725     -2.0735110342502594e-01
    phi[1,4]  R1726     -0.362966388463974
    phi[1,4]  R1727     -1.4825825691223145e+00
    phi[1,4]  R1728     7.3841445147991180e-02
    phi[1,4]  R1729     -2.1178109645843506e+00
    phi[1,4]  R1730     3.5554066300392151e-01
    phi[1,4]  R1731     -9.7308611869812012e-01
    phi[1,4]  R1732     -6.4851516485214233e-01
    phi[1,4]  R1733     -2.1288216114044189e+00
    phi[1,4]  R1734     -1.60283362865448
    phi[1,4]  R1735     -1.7038503885269165e+00
    phi[1,4]  R1736     -2.5109903812408447e+00
    phi[1,4]  R1737     -2.2294936180114746e+00
    phi[1,4]  R1738     -2.7906489372253418e+00
    phi[1,4]  R1739     -1.2178258895874023e+00
    phi[1,4]  R1740     -1.7553027868270874e+00
    phi[1,4]  R1741     -2.6975861191749573e-01
    phi[1,4]  R1742     -2.3918833732604980e+00
    phi[1,4]  R1743     -1.2880640029907227e+00
    phi[1,4]  R1744     -2.1998276710510254e+00
    phi[1,4]  R1745     -2.5881690979003906e+00
    phi[1,4]  R1746     -1.7120409011840820e+00
    phi[1,4]  R1747     -2.5651578903198242e+00
    phi[1,4]  R1748     -2.5395088195800781e+00
    phi[1,4]  R1749     -1.3417088985443115e+00
    phi[1,4]  R1750     -1.4215285778045654e+00
    phi[1,4]  R1751     -3.9309658110141754e-02
    phi[1,4]  R1752     -3.3711355924606323e-01
    phi[1,4]  R1753     -1.7408809661865234e+00
    phi[1,4]  R1754     2.6205414906144142e-02
    phi[1,4]  R1755     -1.1624306440353394e+00
    phi[1,4]  R1756     -1.0412735939025879e+00
    phi[1,4]  R1757     -1.1779898405075073e+00
    phi[1,4]  R1758     -7.1380782127380371e-01
    phi[1,4]  R1759     1.77676522731781
    phi[1,4]  R1760     -2.7310687303543091e-01
    phi[1,4]  R1761     8.4315592050552368e-01
    phi[1,4]  R1762     7.2433346509933472e-01
    phi[1,4]  R1763     3.0531431548297405e-03
    phi[1,4]  R1764     -2.4557695388793945e+00
    phi[1,4]  R1765     -7.8808504343032837e-01
    phi[1,4]  R1766     1.0043582916259766e+00
    phi[1,4]  R1767     0.432986855506897
    phi[1,4]  R1768     7.5547367334365845e-01
    phi[1,4]  R1769     -2.2095894813537598e+00
    phi[1,4]  R1770     -1.8047202825546265e+00
    phi[1,4]  R1771     -1.3643928766250610e+00
    phi[1,4]  R1772     -1.6939057111740112e+00
    phi[1,4]  R1773     -1.6116505861282349e+00
    phi[1,4]  R1774     -6.2830054759979248e-01
    phi[1,4]  R1775     -2.1316418647766113e+00
    phi[1,4]  R1776     -1.6049240827560425e+00
    phi[1,4]  R1777     -2.2179672718048096e+00
    phi[1,4]  R1778     -1.1599769592285156e+00
    phi[1,4]  R1779     -9.0186208486557007e-01
    phi[1,4]  R1780     -1.4049866795539856e-01
    phi[1,4]  R1781     -1.4456121921539307e+00
    phi[1,4]  R1782     -1.4821659326553345e+00
    phi[1,4]  R1783     -1.3954963684082031e+00
    phi[1,4]  R1784     -9.7181499004364014e-01
    phi[1,4]  R1785     -1.7135679721832275e+00
    phi[1,4]  R1786     -2.2601163387298584e+00
    phi[1,4]  R1787     -1.7387723922729492e+00
    phi[1,4]  R1788     -1.8921539783477783e+00
    phi[1,4]  R1789     1.8802841007709503e-01
    phi[1,4]  R1790     -8.7025982141494751e-01
    phi[1,4]  R1791     -1.2329555749893188e+00
    phi[1,4]  R1792     -7.4449771642684937e-01
    phi[1,4]  R1793     -1.7946573495864868e+00
    phi[1,4]  R1794     -1.3221839666366577e+00
    phi[1,4]  R1795     -1.7423173189163208e+00
    phi[1,4]  R1796     -2.0342874526977539e+00
    phi[1,4]  R1797     -8.9844125509262085e-01
    phi[1,4]  R1798     -8.8837021589279175e-01
    phi[4,1]  R9        -1
    phi[4,1]  R36       1
    phi[4,1]  R37       1
    phi[4,1]  R1799     -3.0999999046325684e+00
    phi[4,1]  R1800     -3.0999999046325684e+00
    phi[4,1]  R1801     -2.2400000095367432e+00
    phi[4,1]  R1802     -2.2400000095367432e+00
    phi[4,1]  R1803     -3.0999999046325684e+00
    phi[4,1]  R1804     -3.0999999046325684e+00
    phi[4,1]  R1805     -2.5699999332427979e+00
    phi[4,1]  R1806     -2.5699999332427979e+00
    phi[4,1]  R1807     -3.0999999046325684e+00
    phi[4,1]  R1808     -3.0999999046325684e+00
    phi[4,1]  R1809     -2.0899999141693115e+00
    phi[4,1]  R1810     -2.0899999141693115e+00
    phi[4,1]  R1811     -3.0999999046325684e+00
    phi[4,1]  R1812     -3.0999999046325684e+00
    phi[4,1]  R1813     1.77676522731781
    phi[4,1]  R1814     -2.7310687303543091e-01
    phi[4,1]  R1815     8.4315592050552368e-01
    phi[4,1]  R1816     7.2433346509933472e-01
    phi[4,1]  R1817     3.0531431548297405e-03
    phi[4,1]  R1818     -2.4557695388793945e+00
    phi[4,1]  R1819     -7.8808504343032837e-01
    phi[4,1]  R1820     1.0043582916259766e+00
    phi[4,1]  R1821     0.432986855506897
    phi[4,1]  R1822     7.5547367334365845e-01
    phi[4,1]  R1823     -2.2095894813537598e+00
    phi[4,1]  R1824     -1.8047202825546265e+00
    phi[4,1]  R1825     -1.3643928766250610e+00
    phi[4,1]  R1826     -1.6939057111740112e+00
    phi[4,1]  R1827     -1.6116505861282349e+00
    phi[4,1]  R1828     -6.2830054759979248e-01
    phi[4,1]  R1829     -2.1316418647766113e+00
    phi[4,1]  R1830     -1.6049240827560425e+00
    phi[4,1]  R1831     -2.2179672718048096e+00
    phi[4,1]  R1832     -1.1599769592285156e+00
    phi[4,1]  R1833     -9.0186208486557007e-01
    phi[4,1]  R1834     -1.4049866795539856e-01
    phi[4,1]  R1835     -1.4456121921539307e+00
    phi[4,1]  R1836     -1.4821659326553345e+00
    phi[4,1]  R1837     -1.3954963684082031e+00
    phi[4,1]  R1838     -9.7181499004364014e-01
    phi[4,1]  R1839     -1.7135679721832275e+00
    phi[4,1]  R1840     -2.2601163387298584e+00
    phi[4,1]  R1841     -1.7387723922729492e+00
    phi[4,1]  R1842     -1.8921539783477783e+00
    phi[4,1]  R1843     1.8802841007709503e-01
    phi[4,1]  R1844     -8.7025982141494751e-01
    phi[4,1]  R1845     -1.2329555749893188e+00
    phi[4,1]  R1846     -7.4449771642684937e-01
    phi[4,1]  R1847     -1.7946573495864868e+00
    phi[4,1]  R1848     -1.3221839666366577e+00
    phi[4,1]  R1849     -1.7423173189163208e+00
    phi[4,1]  R1850     -2.0342874526977539e+00
    phi[4,1]  R1851     -8.9844125509262085e-01
    phi[4,1]  R1852     -8.8837021589279175e-01
    phi[4,1]  R1853     2.2953796386718750e-01
    phi[4,1]  R1854     1.0304706096649170e+00
    phi[4,1]  R1855     -4.1439521312713623e-01
    phi[4,1]  R1856     0.24210225045681
    phi[4,1]  R1857     3.3544987440109253e-01
    phi[4,1]  R1858     -9.2660534381866455e-01
    phi[4,1]  R1859     -7.5631928443908691e-01
    phi[4,1]  R1860     2.1012984216213226e-01
    phi[4,1]  R1861     -3.1239548325538635e-01
    phi[4,1]  R1862     -1.1931275576353073e-01
    phi[4,1]  R1863     -1.9321343898773193e+00
    phi[4,1]  R1864     -1.8925678730010986e+00
    phi[4,1]  R1865     -1.6593906879425049e+00
    phi[4,1]  R1866     1.0698325186967850e-01
    phi[4,1]  R1867     1.3713088631629944e-01
    phi[4,1]  R1868     3.0111670494079590e-01
    phi[4,1]  R1869     0.062712162733078
    phi[4,1]  R1870     6.4283460378646851e-01
    phi[4,1]  R1871     3.6917710304260254e-01
    phi[4,1]  R1872     7.6192575693130493e-01
    phi[4,1]  R1873     -1.1395325660705566e+00
    phi[4,1]  R1874     -5.9893929958343506e-01
    phi[4,1]  R1875     -1.5031230449676514e+00
    phi[4,1]  R1876     -1.3366020917892456e+00
    phi[4,1]  R1877     -1.1719367504119873e+00
    phi[4,1]  R1878     -1.5393635034561157e+00
    phi[4,1]  R1879     -2.2131805419921875e+00
    phi[4,1]  R1880     -2.2875556349754333e-01
    phi[4,1]  R1881     2.0869490504264832e-01
    phi[4,1]  R1882     -2.8643736839294434e+00
    phi[4,1]  R1883     -2.5076618194580078e+00
    phi[4,1]  R1884     -2.14526104927063
    phi[4,1]  R1885     -5.2298164367675781e-01
    phi[4,1]  R1886     -9.4787108898162842e-01
    phi[4,1]  R1887     -1.2137928009033203e+00
    phi[4,1]  R1888     -3.8181905746459961e+00
    phi[4,1]  R1889     -1.1628155708312988e+00
    phi[4,1]  R1890     -1.6416127681732178e+00
    phi[4,1]  R1891     -1.6099681854248047e+00
    phi[4,1]  R1892     -1.3271917104721069e+00
    phi[4,1]  R1893     -2.1820611953735352e+00
    phi[4,1]  R1894     -1.3258926868438721e+00
    phi[4,1]  R1895     -1.3318003714084625e-01
    phi[4,1]  R1896     1.7273834347724915e-01
    phi[4,1]  R1897     7.3616409301757812e-01
    phi[4,1]  R1898     -3.0655763149261475e+00
    phi[4,1]  R1899     -3.2563374042510986e+00
    phi[4,1]  R1900     -2.0490498542785645e+00
    phi[4,1]  R1901     -5.2686321735382080e-01
    phi[4,1]  R1902     -1.1256014108657837e+00
    phi[4,1]  R1903     -1.2982035875320435e+00
    phi[4,1]  R1904     -7.4548697471618652e-01
    phi[4,1]  R1905     -2.6498675346374512e+00
    phi[4,1]  R1906     -1.8641465902328491e+00
    phi[4,1]  R1907     -6.8749696016311646e-02
    phi[4,1]  R1908     -1.6977532207965851e-01
    phi[4,1]  R1909     -2.0735110342502594e-01
    phi[4,1]  R1910     -0.362966388463974
    phi[4,1]  R1911     -1.4825825691223145e+00
    phi[4,1]  R1912     7.3841445147991180e-02
    phi[4,1]  R1913     -2.1178109645843506e+00
    phi[4,1]  R1914     3.5554066300392151e-01
    phi[4,1]  R1915     -9.7308611869812012e-01
    phi[4,1]  R1916     -6.4851516485214233e-01
    phi[4,1]  R1917     -2.1288216114044189e+00
    phi[4,1]  R1918     -1.60283362865448
    phi[4,1]  R1919     -1.7038503885269165e+00
    phi[4,1]  R1920     -2.5109903812408447e+00
    phi[4,1]  R1921     -2.2294936180114746e+00
    phi[4,1]  R1922     -2.7906489372253418e+00
    phi[4,1]  R1923     -1.2178258895874023e+00
    phi[4,1]  R1924     -1.7553027868270874e+00
    phi[4,1]  R1925     -2.6975861191749573e-01
    phi[4,1]  R1926     -2.3918833732604980e+00
    phi[4,1]  R1927     -1.2880640029907227e+00
    phi[4,1]  R1928     -2.1998276710510254e+00
    phi[4,1]  R1929     -2.5881690979003906e+00
    phi[4,1]  R1930     -1.7120409011840820e+00
    phi[4,1]  R1931     -2.5651578903198242e+00
    phi[4,1]  R1932     -2.5395088195800781e+00
    phi[4,1]  R1933     -1.3417088985443115e+00
    phi[4,1]  R1934     -1.4215285778045654e+00
    phi[4,1]  R1935     -3.9309658110141754e-02
    phi[4,1]  R1936     -3.3711355924606323e-01
    phi[4,1]  R1937     -1.7408809661865234e+00
    phi[4,1]  R1938     2.6205414906144142e-02
    phi[4,1]  R1939     -1.1624306440353394e+00
    phi[4,1]  R1940     -1.0412735939025879e+00
    phi[4,1]  R1941     -1.1779898405075073e+00
    phi[4,1]  R1942     -7.1380782127380371e-01
    phi[2,4]  R18       1
    phi[2,4]  R19       1
    phi[2,4]  R36       -1
    phi[2,4]  R1943     -3.0999999046325684e+00
    phi[2,4]  R1944     -3.0999999046325684e+00
    phi[2,4]  R1945     -2.2400000095367432e+00
    phi[2,4]  R1946     -2.2400000095367432e+00
    phi[2,4]  R1947     -3.0999999046325684e+00
    phi[2,4]  R1948     -3.0999999046325684e+00
    phi[2,4]  R1949     -2.5699999332427979e+00
    phi[2,4]  R1950     -2.5699999332427979e+00
    phi[2,4]  R1951     -3.0999999046325684e+00
    phi[2,4]  R1952     -3.0999999046325684e+00
    phi[2,4]  R1953     -2.0899999141693115e+00
    phi[2,4]  R1954     -2.0899999141693115e+00
    phi[2,4]  R1955     -3.0999999046325684e+00
    phi[2,4]  R1956     -3.0999999046325684e+00
    phi[2,4]  R1957     1.9452095031738281e+00
    phi[2,4]  R1958     -6.2412649393081665e-01
    phi[2,4]  R1959     1.6723034381866455e+00
    phi[2,4]  R1960     1.9240204989910126e-01
    phi[2,4]  R1961     -2.7192444801330566e+00
    phi[2,4]  R1962     1.16908860206604
    phi[2,4]  R1963     5.0218605995178223e-01
    phi[2,4]  R1964     -1.1753953695297241e+00
    phi[2,4]  R1965     -1.1711049079895020e+00
    phi[2,4]  R1966     -1.6423443555831909e+00
    phi[2,4]  R1967     -1.1882181167602539e+00
    phi[2,4]  R1968     8.4122262895107269e-02
    phi[2,4]  R1969     -5.0071603059768677e-01
    phi[2,4]  R1970     -1.4752833843231201e+00
    phi[2,4]  R1971     -5.4669743776321411e-01
    phi[2,4]  R1972     3.4834407269954681e-02
    phi[2,4]  R1973     -2.5193035602569580e-01
    phi[2,4]  R1974     -1.2623063325881958e+00
    phi[2,4]  R1975     -1.5422010421752930e+00
    phi[2,4]  R1976     -9.6058857440948486e-01
    phi[2,4]  R1977     3.3337265253067017e-01
    phi[2,4]  R1978     -1.07700777053833
    phi[2,4]  R1979     -9.4294482469558716e-01
    phi[2,4]  R1980     -1.8155435323715210e+00
    phi[2,4]  R1981     -1.8112736940383911e+00
    phi[2,4]  R1982     -5.6068807840347290e-01
    phi[2,4]  R1983     -1.8283889293670654e+00
    phi[2,4]  R1984     -2.0797080993652344e+00
    phi[2,4]  R1985     -1.1033776998519897e+00
    phi[2,4]  R1986     -6.4915165305137634e-02
    phi[2,4]  R1987     1.77676522731781
    phi[2,4]  R1988     -2.7310687303543091e-01
    phi[2,4]  R1989     8.4315592050552368e-01
    phi[2,4]  R1990     7.2433346509933472e-01
    phi[2,4]  R1991     3.0531431548297405e-03
    phi[2,4]  R1992     -2.4557695388793945e+00
    phi[2,4]  R1993     -7.8808504343032837e-01
    phi[2,4]  R1994     1.0043582916259766e+00
    phi[2,4]  R1995     0.432986855506897
    phi[2,4]  R1996     7.5547367334365845e-01
    phi[2,4]  R1997     -2.2095894813537598e+00
    phi[2,4]  R1998     -1.8047202825546265e+00
    phi[2,4]  R1999     -1.3643928766250610e+00
    phi[2,4]  R2000     -1.6939057111740112e+00
    phi[2,4]  R2001     -1.6116505861282349e+00
    phi[2,4]  R2002     -6.2830054759979248e-01
    phi[2,4]  R2003     -2.1316418647766113e+00
    phi[2,4]  R2004     -1.6049240827560425e+00
    phi[2,4]  R2005     -2.2179672718048096e+00
    phi[2,4]  R2006     -1.1599769592285156e+00
    phi[2,4]  R2007     -9.0186208486557007e-01
    phi[2,4]  R2008     -1.4049866795539856e-01
    phi[2,4]  R2009     -1.4456121921539307e+00
    phi[2,4]  R2010     -1.4821659326553345e+00
    phi[2,4]  R2011     -1.3954963684082031e+00
    phi[2,4]  R2012     -9.7181499004364014e-01
    phi[2,4]  R2013     -1.7135679721832275e+00
    phi[2,4]  R2014     -2.2601163387298584e+00
    phi[2,4]  R2015     -1.7387723922729492e+00
    phi[2,4]  R2016     -1.8921539783477783e+00
    phi[2,4]  R2017     1.8802841007709503e-01
    phi[2,4]  R2018     -8.7025982141494751e-01
    phi[2,4]  R2019     -1.2329555749893188e+00
    phi[2,4]  R2020     -7.4449771642684937e-01
    phi[2,4]  R2021     -1.7946573495864868e+00
    phi[2,4]  R2022     -1.3221839666366577e+00
    phi[2,4]  R2023     -1.7423173189163208e+00
    phi[2,4]  R2024     -2.0342874526977539e+00
    phi[2,4]  R2025     -8.9844125509262085e-01
    phi[2,4]  R2026     -8.8837021589279175e-01
    phi[4,2]  R18       -1
    phi[4,2]  R36       1
    phi[4,2]  R37       1
    phi[4,2]  R2027     -3.0999999046325684e+00
    phi[4,2]  R2028     -3.0999999046325684e+00
    phi[4,2]  R2029     -2.2400000095367432e+00
    phi[4,2]  R2030     -2.2400000095367432e+00
    phi[4,2]  R2031     -3.0999999046325684e+00
    phi[4,2]  R2032     -3.0999999046325684e+00
    phi[4,2]  R2033     -2.5699999332427979e+00
    phi[4,2]  R2034     -2.5699999332427979e+00
    phi[4,2]  R2035     -3.0999999046325684e+00
    phi[4,2]  R2036     -3.0999999046325684e+00
    phi[4,2]  R2037     -2.0899999141693115e+00
    phi[4,2]  R2038     -2.0899999141693115e+00
    phi[4,2]  R2039     -3.0999999046325684e+00
    phi[4,2]  R2040     -3.0999999046325684e+00
    phi[4,2]  R2041     1.77676522731781
    phi[4,2]  R2042     -2.7310687303543091e-01
    phi[4,2]  R2043     8.4315592050552368e-01
    phi[4,2]  R2044     7.2433346509933472e-01
    phi[4,2]  R2045     3.0531431548297405e-03
    phi[4,2]  R2046     -2.4557695388793945e+00
    phi[4,2]  R2047     -7.8808504343032837e-01
    phi[4,2]  R2048     1.0043582916259766e+00
    phi[4,2]  R2049     0.432986855506897
    phi[4,2]  R2050     7.5547367334365845e-01
    phi[4,2]  R2051     -2.2095894813537598e+00
    phi[4,2]  R2052     -1.8047202825546265e+00
    phi[4,2]  R2053     -1.3643928766250610e+00
    phi[4,2]  R2054     -1.6939057111740112e+00
    phi[4,2]  R2055     -1.6116505861282349e+00
    phi[4,2]  R2056     -6.2830054759979248e-01
    phi[4,2]  R2057     -2.1316418647766113e+00
    phi[4,2]  R2058     -1.6049240827560425e+00
    phi[4,2]  R2059     -2.2179672718048096e+00
    phi[4,2]  R2060     -1.1599769592285156e+00
    phi[4,2]  R2061     -9.0186208486557007e-01
    phi[4,2]  R2062     -1.4049866795539856e-01
    phi[4,2]  R2063     -1.4456121921539307e+00
    phi[4,2]  R2064     -1.4821659326553345e+00
    phi[4,2]  R2065     -1.3954963684082031e+00
    phi[4,2]  R2066     -9.7181499004364014e-01
    phi[4,2]  R2067     -1.7135679721832275e+00
    phi[4,2]  R2068     -2.2601163387298584e+00
    phi[4,2]  R2069     -1.7387723922729492e+00
    phi[4,2]  R2070     -1.8921539783477783e+00
    phi[4,2]  R2071     1.8802841007709503e-01
    phi[4,2]  R2072     -8.7025982141494751e-01
    phi[4,2]  R2073     -1.2329555749893188e+00
    phi[4,2]  R2074     -7.4449771642684937e-01
    phi[4,2]  R2075     -1.7946573495864868e+00
    phi[4,2]  R2076     -1.3221839666366577e+00
    phi[4,2]  R2077     -1.7423173189163208e+00
    phi[4,2]  R2078     -2.0342874526977539e+00
    phi[4,2]  R2079     -8.9844125509262085e-01
    phi[4,2]  R2080     -8.8837021589279175e-01
    phi[4,2]  R2081     1.9452095031738281e+00
    phi[4,2]  R2082     -6.2412649393081665e-01
    phi[4,2]  R2083     1.6723034381866455e+00
    phi[4,2]  R2084     1.9240204989910126e-01
    phi[4,2]  R2085     -2.7192444801330566e+00
    phi[4,2]  R2086     1.16908860206604
    phi[4,2]  R2087     5.0218605995178223e-01
    phi[4,2]  R2088     -1.1753953695297241e+00
    phi[4,2]  R2089     -1.1711049079895020e+00
    phi[4,2]  R2090     -1.6423443555831909e+00
    phi[4,2]  R2091     -1.1882181167602539e+00
    phi[4,2]  R2092     8.4122262895107269e-02
    phi[4,2]  R2093     -5.0071603059768677e-01
    phi[4,2]  R2094     -1.4752833843231201e+00
    phi[4,2]  R2095     -5.4669743776321411e-01
    phi[4,2]  R2096     3.4834407269954681e-02
    phi[4,2]  R2097     -2.5193035602569580e-01
    phi[4,2]  R2098     -1.2623063325881958e+00
    phi[4,2]  R2099     -1.5422010421752930e+00
    phi[4,2]  R2100     -9.6058857440948486e-01
    phi[4,2]  R2101     3.3337265253067017e-01
    phi[4,2]  R2102     -1.07700777053833
    phi[4,2]  R2103     -9.4294482469558716e-01
    phi[4,2]  R2104     -1.8155435323715210e+00
    phi[4,2]  R2105     -1.8112736940383911e+00
    phi[4,2]  R2106     -5.6068807840347290e-01
    phi[4,2]  R2107     -1.8283889293670654e+00
    phi[4,2]  R2108     -2.0797080993652344e+00
    phi[4,2]  R2109     -1.1033776998519897e+00
    phi[4,2]  R2110     -6.4915165305137634e-02
    phi[2,6]  R18       1
    phi[2,6]  R19       1
    phi[2,6]  R20       2.0866522834936032e+00
    phi[2,6]  R21       4.8296468740830312e-01
    phi[2,6]  R22       -2.2485101508293783e+00
    phi[2,6]  R23       1.1249467678754212e+00
    phi[2,6]  R24       -9.8130131395476061e-01
    phi[2,6]  R25       2.9952655767751613e-01
    phi[2,6]  R26       1.2604877780593131e+00
    phi[2,6]  R46       -1
    phi[2,6]  R2111     -1.0133476211389651e+00
    phi[2,6]  R2112     -5.1866521881261711e+00
    phi[2,6]  R2113     -1.75703532212844
    phi[2,6]  R2114     -2.7229646969450463e+00
    phi[2,6]  R2115     -5.3485100554619471e+00
    phi[2,6]  R2116     -0.85148975380319
    phi[2,6]  R2117     -1.4450531653673766e+00
    phi[2,6]  R2118     -3.6949467011182193e+00
    phi[2,6]  R2119     -4.0813012185873294e+00
    phi[2,6]  R2120     -2.1186985906778077e+00
    phi[2,6]  R2121     -1.7904733564917954e+00
    phi[2,6]  R2122     -2.3895264718468274e+00
    phi[2,6]  R2123     -1.8395121265732552e+00
    phi[2,6]  R2124     -4.3604876826918817e+00
    phi[2,6]  R2125     -2.8120672350971043e-02
    phi[2,6]  R2126     -3.6046250540633595e-02
    phi[2,6]  R2127     -3.6735291075077114e-02
    phi[2,6]  R2128     -3.6938492503339276e-02
    phi[2,6]  R2129     -1.3381072518611425e-01
    phi[2,6]  R2130     -2.3393660274646355e-01
    phi[2,6]  R2131     -6.8262319570361241e-01
    phi[2,6]  R2132     -1.2900266468172334e+00
    phi[2,6]  R2133     -1.3782583029759112e+00
    phi[2,6]  R2134     -1.1401542978731725e+00
    phi[2,6]  R2135     -6.8819756012880928e-02
    phi[2,6]  R2136     -1.3273601176458924e-01
    phi[2,6]  R2137     -1.7472748432158497e-01
    phi[2,6]  R2138     -0.192412783864085
    phi[2,6]  R2139     -1.9622085972145292e-01
    phi[2,6]  R2140     -1.7774652288655328e+00
    phi[2,6]  R2141     -1.5065368524052520e+00
    phi[2,6]  R2142     -1.8730306918256452e+00
    phi[2,6]  R2143     -1.8017290813961708e+00
    phi[2,6]  R2144     -1.9448451119547570e+00
    phi[2,6]  R2145     -1.4355796956248332e+00
    phi[2,6]  R2146     -1.7149368709670774e+00
    phi[2,6]  R2147     -1.5524177485353388e+00
    phi[2,6]  R2148     -1.6592335513531777e+00
    phi[2,6]  R2149     -1.6371849653219077e+00
    phi[2,6]  R2150     -1.5604484649242429e+00
    phi[2,6]  R2151     -1.9786959208480530e+00
    phi[2,6]  R2152     -1.8440128369026159e+00
    phi[2,6]  R2153     -1.9070801736350163e+00
    phi[2,6]  R2154     -1.5951726898150105e+00
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R2155     -3.0999999046325684e+00
    phi[3,4]  R2156     -3.0999999046325684e+00
    phi[3,4]  R2157     -2.2400000095367432e+00
    phi[3,4]  R2158     -2.2400000095367432e+00
    phi[3,4]  R2159     -3.0999999046325684e+00
    phi[3,4]  R2160     -3.0999999046325684e+00
    phi[3,4]  R2161     -2.5699999332427979e+00
    phi[3,4]  R2162     -2.5699999332427979e+00
    phi[3,4]  R2163     -3.0999999046325684e+00
    phi[3,4]  R2164     -3.0999999046325684e+00
    phi[3,4]  R2165     -2.0899999141693115e+00
    phi[3,4]  R2166     -2.0899999141693115e+00
    phi[3,4]  R2167     -3.0999999046325684e+00
    phi[3,4]  R2168     -3.0999999046325684e+00
    phi[3,4]  R2169     -1.8628000020980835e+00
    phi[3,4]  R2170     -1.8884301185607910e+00
    phi[3,4]  R2171     -1.2341090440750122e+00
    phi[3,4]  R2172     -9.8038172721862793e-01
    phi[3,4]  R2173     -1.8649417161941528e+00
    phi[3,4]  R2174     -1.03556489944458
    phi[3,4]  R2175     -6.4381957054138184e-01
    phi[3,4]  R2176     6.9499778747558594e-01
    phi[3,4]  R2177     8.9956074953079224e-01
    phi[3,4]  R2178     7.3563170433044434e-01
    phi[3,4]  R2179     -1.7262135744094849e+00
    phi[3,4]  R2180     -1.2428110837936401e+00
    phi[3,4]  R2181     -1.3499498367309570e+00
    phi[3,4]  R2182     9.4736057519912720e-01
    phi[3,4]  R2183     -5.8488780260086060e-01
    phi[3,4]  R2184     -5.2990150451660156e-01
    phi[3,4]  R2185     -0.00199287012219429
    phi[3,4]  R2186     -7.1599656343460083e-01
    phi[3,4]  R2187     -4.1697301864624023e+00
    phi[3,4]  R2188     -1.2905484437942505e+00
    phi[3,4]  R2189     -2.1979658603668213e+00
    phi[3,4]  R2190     -1.8974057435989380e+00
    phi[3,4]  R2191     -2.7606399059295654e+00
    phi[3,4]  R2192     -3.5632009506225586e+00
    phi[3,4]  R2193     -5.4470491409301758e-01
    phi[3,4]  R2194     -1.7707933187484741e+00
    phi[3,4]  R2195     -3.7486145496368408e+00
    phi[3,4]  R2196     -1.8345013856887817e+00
    phi[3,4]  R2197     -1.4156557321548462e+00
    phi[3,4]  R2198     -3.4021177291870117e+00
    phi[3,4]  R2199     -2.01997447013855
    phi[3,4]  R2200     -1.2330245971679688e+00
    phi[3,4]  R2201     -1.2636178731918335e+00
    phi[3,4]  R2202     -1.1317048072814941e+00
    phi[3,4]  R2203     -1.0400702953338623e+00
    phi[3,4]  R2204     -1.1615731716156006e+00
    phi[3,4]  R2205     -4.5204665511846542e-03
    phi[3,4]  R2206     8.6048346757888794e-01
    phi[3,4]  R2207     0.360653281211853
    phi[3,4]  R2208     5.4866266250610352e-01
    phi[3,4]  R2209     -2.1474535465240479e+00
    phi[3,4]  R2210     -2.2765618562698364e-01
    phi[3,4]  R2211     -7.0563733577728271e-01
    phi[3,4]  R2212     -1.4656791687011719e+00
    phi[3,4]  R2213     -2.0150632858276367e+00
    phi[3,4]  R2214     -1.8557472229003906e+00
    phi[3,4]  R2215     -1.0790758132934570e+00
    phi[3,4]  R2216     -1.1064099073410034e+00
    phi[3,4]  R2217     -1.0920997858047485e+00
    phi[3,4]  R2218     -2.7300566434860229e-01
    phi[3,4]  R2219     -1.6855542659759521e+00
    phi[3,4]  R2220     -1.7401901483535767e+00
    phi[3,4]  R2221     -2.1001372337341309e+00
    phi[3,4]  R2222     -2.1688518524169922e+00
    phi[3,4]  R2223     -1.7625073194503784e+00
    phi[3,4]  R2224     -2.6412544250488281e+00
    phi[3,4]  R2225     -7.0061731338500977e-01
    phi[3,4]  R2226     -1.2378821372985840e+00
    phi[3,4]  R2227     7.0247960090637207e-01
    phi[3,4]  R2228     5.7947534322738647e-01
    phi[3,4]  R2229     -1.3546532392501831e+00
    phi[3,4]  R2230     -2.8948230743408203e+00
    phi[3,4]  R2231     -1.5189614295959473e+00
    phi[3,4]  R2232     -1.3839241266250610e+00
    phi[3,4]  R2233     -9.4123214483261108e-01
    phi[3,4]  R2234     -4.0870947837829590e+00
    phi[3,4]  R2235     -1.7704143524169922e+00
    phi[3,4]  R2236     -1.2808636426925659e+00
    phi[3,4]  R2237     5.3298449516296387e-01
    phi[3,4]  R2238     1.2065466642379761e+00
    phi[3,4]  R2239     -1.9929404258728027e+00
    phi[3,4]  R2240     -1.4228389263153076e+00
    phi[3,4]  R2241     -1.3925457000732422e+00
    phi[3,4]  R2242     -1.3748539686203003e+00
    phi[3,4]  R2243     -4.2888915538787842e-01
    phi[3,4]  R2244     -1.5428522825241089e+00
    phi[3,4]  R2245     7.1888887882232666e-01
    phi[3,4]  R2246     3.1354889273643494e-01
    phi[3,4]  R2247     4.9898996949195862e-01
    phi[3,4]  R2248     6.9089096784591675e-01
    phi[3,4]  R2249     -2.1247973442077637e+00
    phi[3,4]  R2250     -1.7874052524566650e+00
    phi[3,4]  R2251     -1.8864042758941650e+00
    phi[3,4]  R2252     -2.2732176780700684e+00
    phi[3,4]  R2253     -1.3407192230224609e+00
    phi[3,4]  R2254     -1.6556298732757568e+00
    phi[3,4]  R2255     -1.4301735162734985e+00
    phi[3,4]  R2256     -1.1262396574020386e+00
    phi[3,4]  R2257     -1.6197975873947144e+00
    phi[3,4]  R2258     1.06780207157135
    phi[3,4]  R2259     1.77676522731781
    phi[3,4]  R2260     -2.7310687303543091e-01
    phi[3,4]  R2261     8.4315592050552368e-01
    phi[3,4]  R2262     7.2433346509933472e-01
    phi[3,4]  R2263     3.0531431548297405e-03
    phi[3,4]  R2264     -2.4557695388793945e+00
    phi[3,4]  R2265     -7.8808504343032837e-01
    phi[3,4]  R2266     1.0043582916259766e+00
    phi[3,4]  R2267     0.432986855506897
    phi[3,4]  R2268     7.5547367334365845e-01
    phi[3,4]  R2269     -2.2095894813537598e+00
    phi[3,4]  R2270     -1.8047202825546265e+00
    phi[3,4]  R2271     -1.3643928766250610e+00
    phi[3,4]  R2272     -1.6939057111740112e+00
    phi[3,4]  R2273     -1.6116505861282349e+00
    phi[3,4]  R2274     -6.2830054759979248e-01
    phi[3,4]  R2275     -2.1316418647766113e+00
    phi[3,4]  R2276     -1.6049240827560425e+00
    phi[3,4]  R2277     -2.2179672718048096e+00
    phi[3,4]  R2278     -1.1599769592285156e+00
    phi[3,4]  R2279     -9.0186208486557007e-01
    phi[3,4]  R2280     -1.4049866795539856e-01
    phi[3,4]  R2281     -1.4456121921539307e+00
    phi[3,4]  R2282     -1.4821659326553345e+00
    phi[3,4]  R2283     -1.3954963684082031e+00
    phi[3,4]  R2284     -9.7181499004364014e-01
    phi[3,4]  R2285     -1.7135679721832275e+00
    phi[3,4]  R2286     -2.2601163387298584e+00
    phi[3,4]  R2287     -1.7387723922729492e+00
    phi[3,4]  R2288     -1.8921539783477783e+00
    phi[3,4]  R2289     1.8802841007709503e-01
    phi[3,4]  R2290     -8.7025982141494751e-01
    phi[3,4]  R2291     -1.2329555749893188e+00
    phi[3,4]  R2292     -7.4449771642684937e-01
    phi[3,4]  R2293     -1.7946573495864868e+00
    phi[3,4]  R2294     -1.3221839666366577e+00
    phi[3,4]  R2295     -1.7423173189163208e+00
    phi[3,4]  R2296     -2.0342874526977539e+00
    phi[3,4]  R2297     -8.9844125509262085e-01
    phi[3,4]  R2298     -8.8837021589279175e-01
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R2299     -3.0999999046325684e+00
    phi[4,3]  R2300     -3.0999999046325684e+00
    phi[4,3]  R2301     -2.2400000095367432e+00
    phi[4,3]  R2302     -2.2400000095367432e+00
    phi[4,3]  R2303     -3.0999999046325684e+00
    phi[4,3]  R2304     -3.0999999046325684e+00
    phi[4,3]  R2305     -2.5699999332427979e+00
    phi[4,3]  R2306     -2.5699999332427979e+00
    phi[4,3]  R2307     -3.0999999046325684e+00
    phi[4,3]  R2308     -3.0999999046325684e+00
    phi[4,3]  R2309     -2.0899999141693115e+00
    phi[4,3]  R2310     -2.0899999141693115e+00
    phi[4,3]  R2311     -3.0999999046325684e+00
    phi[4,3]  R2312     -3.0999999046325684e+00
    phi[4,3]  R2313     1.77676522731781
    phi[4,3]  R2314     -2.7310687303543091e-01
    phi[4,3]  R2315     8.4315592050552368e-01
    phi[4,3]  R2316     7.2433346509933472e-01
    phi[4,3]  R2317     3.0531431548297405e-03
    phi[4,3]  R2318     -2.4557695388793945e+00
    phi[4,3]  R2319     -7.8808504343032837e-01
    phi[4,3]  R2320     1.0043582916259766e+00
    phi[4,3]  R2321     0.432986855506897
    phi[4,3]  R2322     7.5547367334365845e-01
    phi[4,3]  R2323     -2.2095894813537598e+00
    phi[4,3]  R2324     -1.8047202825546265e+00
    phi[4,3]  R2325     -1.3643928766250610e+00
    phi[4,3]  R2326     -1.6939057111740112e+00
    phi[4,3]  R2327     -1.6116505861282349e+00
    phi[4,3]  R2328     -6.2830054759979248e-01
    phi[4,3]  R2329     -2.1316418647766113e+00
    phi[4,3]  R2330     -1.6049240827560425e+00
    phi[4,3]  R2331     -2.2179672718048096e+00
    phi[4,3]  R2332     -1.1599769592285156e+00
    phi[4,3]  R2333     -9.0186208486557007e-01
    phi[4,3]  R2334     -1.4049866795539856e-01
    phi[4,3]  R2335     -1.4456121921539307e+00
    phi[4,3]  R2336     -1.4821659326553345e+00
    phi[4,3]  R2337     -1.3954963684082031e+00
    phi[4,3]  R2338     -9.7181499004364014e-01
    phi[4,3]  R2339     -1.7135679721832275e+00
    phi[4,3]  R2340     -2.2601163387298584e+00
    phi[4,3]  R2341     -1.7387723922729492e+00
    phi[4,3]  R2342     -1.8921539783477783e+00
    phi[4,3]  R2343     1.8802841007709503e-01
    phi[4,3]  R2344     -8.7025982141494751e-01
    phi[4,3]  R2345     -1.2329555749893188e+00
    phi[4,3]  R2346     -7.4449771642684937e-01
    phi[4,3]  R2347     -1.7946573495864868e+00
    phi[4,3]  R2348     -1.3221839666366577e+00
    phi[4,3]  R2349     -1.7423173189163208e+00
    phi[4,3]  R2350     -2.0342874526977539e+00
    phi[4,3]  R2351     -8.9844125509262085e-01
    phi[4,3]  R2352     -8.8837021589279175e-01
    phi[4,3]  R2353     -1.8628000020980835e+00
    phi[4,3]  R2354     -1.8884301185607910e+00
    phi[4,3]  R2355     -1.2341090440750122e+00
    phi[4,3]  R2356     -9.8038172721862793e-01
    phi[4,3]  R2357     -1.8649417161941528e+00
    phi[4,3]  R2358     -1.03556489944458
    phi[4,3]  R2359     -6.4381957054138184e-01
    phi[4,3]  R2360     6.9499778747558594e-01
    phi[4,3]  R2361     8.9956074953079224e-01
    phi[4,3]  R2362     7.3563170433044434e-01
    phi[4,3]  R2363     -1.7262135744094849e+00
    phi[4,3]  R2364     -1.2428110837936401e+00
    phi[4,3]  R2365     -1.3499498367309570e+00
    phi[4,3]  R2366     9.4736057519912720e-01
    phi[4,3]  R2367     -5.8488780260086060e-01
    phi[4,3]  R2368     -5.2990150451660156e-01
    phi[4,3]  R2369     -0.00199287012219429
    phi[4,3]  R2370     -7.1599656343460083e-01
    phi[4,3]  R2371     -4.1697301864624023e+00
    phi[4,3]  R2372     -1.2905484437942505e+00
    phi[4,3]  R2373     -2.1979658603668213e+00
    phi[4,3]  R2374     -1.8974057435989380e+00
    phi[4,3]  R2375     -2.7606399059295654e+00
    phi[4,3]  R2376     -3.5632009506225586e+00
    phi[4,3]  R2377     -5.4470491409301758e-01
    phi[4,3]  R2378     -1.7707933187484741e+00
    phi[4,3]  R2379     -3.7486145496368408e+00
    phi[4,3]  R2380     -1.8345013856887817e+00
    phi[4,3]  R2381     -1.4156557321548462e+00
    phi[4,3]  R2382     -3.4021177291870117e+00
    phi[4,3]  R2383     -2.01997447013855
    phi[4,3]  R2384     -1.2330245971679688e+00
    phi[4,3]  R2385     -1.2636178731918335e+00
    phi[4,3]  R2386     -1.1317048072814941e+00
    phi[4,3]  R2387     -1.0400702953338623e+00
    phi[4,3]  R2388     -1.1615731716156006e+00
    phi[4,3]  R2389     -4.5204665511846542e-03
    phi[4,3]  R2390     8.6048346757888794e-01
    phi[4,3]  R2391     0.360653281211853
    phi[4,3]  R2392     5.4866266250610352e-01
    phi[4,3]  R2393     -2.1474535465240479e+00
    phi[4,3]  R2394     -2.2765618562698364e-01
    phi[4,3]  R2395     -7.0563733577728271e-01
    phi[4,3]  R2396     -1.4656791687011719e+00
    phi[4,3]  R2397     -2.0150632858276367e+00
    phi[4,3]  R2398     -1.8557472229003906e+00
    phi[4,3]  R2399     -1.0790758132934570e+00
    phi[4,3]  R2400     -1.1064099073410034e+00
    phi[4,3]  R2401     -1.0920997858047485e+00
    phi[4,3]  R2402     -2.7300566434860229e-01
    phi[4,3]  R2403     -1.6855542659759521e+00
    phi[4,3]  R2404     -1.7401901483535767e+00
    phi[4,3]  R2405     -2.1001372337341309e+00
    phi[4,3]  R2406     -2.1688518524169922e+00
    phi[4,3]  R2407     -1.7625073194503784e+00
    phi[4,3]  R2408     -2.6412544250488281e+00
    phi[4,3]  R2409     -7.0061731338500977e-01
    phi[4,3]  R2410     -1.2378821372985840e+00
    phi[4,3]  R2411     7.0247960090637207e-01
    phi[4,3]  R2412     5.7947534322738647e-01
    phi[4,3]  R2413     -1.3546532392501831e+00
    phi[4,3]  R2414     -2.8948230743408203e+00
    phi[4,3]  R2415     -1.5189614295959473e+00
    phi[4,3]  R2416     -1.3839241266250610e+00
    phi[4,3]  R2417     -9.4123214483261108e-01
    phi[4,3]  R2418     -4.0870947837829590e+00
    phi[4,3]  R2419     -1.7704143524169922e+00
    phi[4,3]  R2420     -1.2808636426925659e+00
    phi[4,3]  R2421     5.3298449516296387e-01
    phi[4,3]  R2422     1.2065466642379761e+00
    phi[4,3]  R2423     -1.9929404258728027e+00
    phi[4,3]  R2424     -1.4228389263153076e+00
    phi[4,3]  R2425     -1.3925457000732422e+00
    phi[4,3]  R2426     -1.3748539686203003e+00
    phi[4,3]  R2427     -4.2888915538787842e-01
    phi[4,3]  R2428     -1.5428522825241089e+00
    phi[4,3]  R2429     7.1888887882232666e-01
    phi[4,3]  R2430     3.1354889273643494e-01
    phi[4,3]  R2431     4.9898996949195862e-01
    phi[4,3]  R2432     6.9089096784591675e-01
    phi[4,3]  R2433     -2.1247973442077637e+00
    phi[4,3]  R2434     -1.7874052524566650e+00
    phi[4,3]  R2435     -1.8864042758941650e+00
    phi[4,3]  R2436     -2.2732176780700684e+00
    phi[4,3]  R2437     -1.3407192230224609e+00
    phi[4,3]  R2438     -1.6556298732757568e+00
    phi[4,3]  R2439     -1.4301735162734985e+00
    phi[4,3]  R2440     -1.1262396574020386e+00
    phi[4,3]  R2441     -1.6197975873947144e+00
    phi[4,3]  R2442     1.06780207157135
    phi[5,3]  R27       -1
    phi[5,3]  R29       -2.2778502514963908e+00
    phi[5,3]  R30       9.8689348846324343e-01
    phi[5,3]  R31       2.4473104432550925e+00
    phi[5,3]  R32       5.6725888747584330e-01
    phi[5,3]  R33       -7.9833431042921887e-01
    phi[5,3]  R34       1.0529369927095336e+00
    phi[5,3]  R35       1.2868532219312194e+00
    phi[5,3]  R45       1
    phi[5,3]  R2443     -8.2214965313617761e-01
    phi[5,3]  R2444     -5.3778501561289591e+00
    phi[5,3]  R2445     -3.2268934979999866e+00
    phi[5,3]  R2446     -1.2531065210734997e+00
    phi[5,3]  R2447     -5.5473103478876613e+00
    phi[5,3]  R2448     -6.5268946137747585e-01
    phi[5,3]  R2449     -3.1372588207186412e+00
    phi[5,3]  R2450     -2.0027410457669546e+00
    phi[5,3]  R2451     -2.3016655942033495e+00
    phi[5,3]  R2452     -3.8983342150617872e+00
    phi[5,3]  R2453     -3.1429369068788451e+00
    phi[5,3]  R2454     -1.0370629214597780e+00
    phi[5,3]  R2455     -4.3868531265637873e+00
    phi[5,3]  R2456     -1.8131466827013489e+00
    phi[5,3]  R2457     -3.3189776178933417e-01
    phi[5,3]  R2458     -3.5841885025381348e-01
    phi[5,3]  R2459     -3.9135284161170725e-01
    phi[5,3]  R2460     -3.9260835551367812e-01
    phi[5,3]  R2461     -3.9571366442991662e-01
    phi[5,3]  R2462     -4.1445385571189286e-01
    phi[5,3]  R2463     -4.1521723589750548e-01
    phi[5,3]  R2464     -1.8458460383755351e+00
    phi[5,3]  R2465     -1.7392153638438606e+00
    phi[5,3]  R2466     -1.0507775359993172e+00
    phi[5,3]  R2467     -0.489740168488092
    phi[5,3]  R2468     -5.1785120266743756e-01
    phi[5,3]  R2469     -5.4829330201245141e-01
    phi[5,3]  R2470     -0.568552120497293
    phi[5,3]  R2471     -5.7333631307223110e-01
    phi[5,3]  R2472     -5.7773829882455052e-01
    phi[5,3]  R2473     -5.7888641958437126e-01
    phi[5,3]  R2474     -6.2900738583402493e-01
    phi[5,3]  R2475     -6.6114001971231628e-01
    phi[5,3]  R2476     -6.6811186312246451e-01
    phi[5,3]  R2477     -3.2792114432531871e-01
    phi[5,3]  R2478     -3.3094324553568066e-01
    phi[5,3]  R2479     -3.6005158294514006e-01
    phi[5,3]  R2480     -3.7172304921936083e-01
    phi[5,3]  R2481     -3.8367999613261794e-01
    phi[5,3]  R2482     -3.8596213871697671e-01
    phi[5,3]  R2483     -0.391608978247838
    phi[5,3]  R2484     -0.434017627216551
    phi[5,3]  R2485     -4.3792929734824593e-01
    phi[5,3]  R2486     -4.4300630707155708e-01
    phi[5,3]  R2487     -3.4040242282157807e-01
    phi[5,3]  R2488     -0.365534587781461
    phi[5,3]  R2489     -5.3196361988115459e-01
    phi[5,3]  R2490     -0.535454476138153
    phi[5,3]  R2491     -5.4184812741162358e-01
    phi[5,3]  R2492     -6.1683468016649234e-01
    phi[5,3]  R2493     -6.5386126675226186e-01
    phi[5,3]  R2494     -6.6220651157027421e-01
    phi[5,3]  R2495     -6.6523139068778692e-01
    phi[5,3]  R2496     -6.7150408327932909e-01
    phi[5,3]  R2497     -3.0082772811469072e-01
    phi[5,3]  R2498     -3.6818591587107030e-01
    phi[5,3]  R2499     -3.7378581022069535e-01
    phi[5,3]  R2500     -3.8283253181217369e-01
    phi[5,3]  R2501     -4.0316077173354126e-01
    phi[5,3]  R2502     -4.0783463966899491e-01
    phi[5,3]  R2503     -4.4776885901272256e-01
    phi[5,3]  R2504     -4.5659277952900246e-01
    phi[5,3]  R2505     -4.6398988727045332e-01
    phi[5,3]  R2506     -5.2981548455885508e-01
    phi[5,3]  R2507     -3.2547673794250032e-01
    phi[5,3]  R2508     -3.3580162213735654e-01
    phi[5,3]  R2509     -0.362086725642234
    phi[5,3]  R2510     -0.368491588145613
    phi[5,3]  R2511     -3.6925675372853450e-01
    phi[5,3]  R2512     -4.0103423661451343e-01
    phi[5,3]  R2513     -5.5806616991562241e-01
    phi[5,3]  R2514     -5.6144668904845718e-01
    phi[5,3]  R2515     -5.9222145374238888e-01
    phi[5,3]  R2516     -5.9338891222013812e-01
    phi[5,3]  R2517     -3.7287392961904020e-01
    phi[5,3]  R2518     -3.9038592236788139e-01
    phi[5,3]  R2519     -3.9449077536070765e-01
    phi[5,3]  R2520     -0.445077883592497
    phi[5,3]  R2521     -4.6142388155438685e-01
    phi[5,3]  R2522     -4.7262410915363651e-01
    phi[5,3]  R2523     -5.2273184760047453e-01
    phi[5,3]  R2524     -5.5727449091921644e-01
    phi[5,3]  R2525     -5.7946686808079617e-01
    phi[5,3]  R2526     -5.9125060041483435e-01
    phi[5,3]  R2527     -3.0174343807615833e-01
    phi[5,3]  R2528     -3.1072973370934953e-01
    phi[5,3]  R2529     -3.2458939826359345e-01
    phi[5,3]  R2530     -3.3604322209150306e-01
    phi[5,3]  R2531     -3.7229783126279670e-01
    phi[5,3]  R2532     -4.6940194928251455e-01
    phi[5,3]  R2533     -5.4719269032715157e-01
    phi[5,3]  R2534     -6.0084362973670979e-01
    phi[5,3]  R2535     -7.0347678697696359e-01
    phi[5,3]  R2536     -7.1281838590288360e-01
    phi[5,3]  R2537     -3.3247093883800893e-01
    phi[5,3]  R2538     -0.36050192537908
    phi[5,3]  R2539     -3.6144877546157006e-01
    phi[5,3]  R2540     -3.7576389015568079e-01
    phi[5,3]  R2541     -4.0560864323754586e-01
    phi[5,3]  R2542     -4.0764622653481153e-01
    phi[5,3]  R2543     -4.0870038917043816e-01
    phi[5,3]  R2544     -4.1707397968725157e-01
    phi[5,3]  R2545     -4.3478469095307082e-01
    phi[5,3]  R2546     -0.627014046234937
    phi[4,6]  R36       1
    phi[4,6]  R37       1
    phi[4,6]  R38       2.0866522834936032e+00
    phi[4,6]  R39       4.8296468740830312e-01
    phi[4,6]  R40       -2.2485101508293783e+00
    phi[4,6]  R41       1.1249467678754212e+00
    phi[4,6]  R42       -9.8130131395476061e-01
    phi[4,6]  R43       2.9952655767751613e-01
    phi[4,6]  R44       1.2604877780593131e+00
    phi[4,6]  R46       -1
    phi[4,6]  R2547     -1.0133476211389651e+00
    phi[4,6]  R2548     -5.1866521881261711e+00
    phi[4,6]  R2549     -1.75703532212844
    phi[4,6]  R2550     -2.7229646969450463e+00
    phi[4,6]  R2551     -5.3485100554619471e+00
    phi[4,6]  R2552     -0.85148975380319
    phi[4,6]  R2553     -1.4450531653673766e+00
    phi[4,6]  R2554     -3.6949467011182193e+00
    phi[4,6]  R2555     -4.0813012185873294e+00
    phi[4,6]  R2556     -2.1186985906778077e+00
    phi[4,6]  R2557     -1.7904733564917954e+00
    phi[4,6]  R2558     -2.3895264718468274e+00
    phi[4,6]  R2559     -1.8395121265732552e+00
    phi[4,6]  R2560     -4.3604876826918817e+00
    phi[4,6]  R2561     -2.8490721050749013e-02
    phi[4,6]  R2562     -3.2840398833024254e-02
    phi[4,6]  R2563     -3.4187064914417364e-02
    phi[4,6]  R2564     -0.0525493035831075
    phi[4,6]  R2565     -0.0584268842486044
    phi[4,6]  R2566     -1.0096945661822065e-01
    phi[4,6]  R2567     -2.7910882170549367e-01
    phi[4,6]  R2568     -3.4692125082773018e-01
    phi[4,6]  R2569     -3.6697652760157085e-01
    phi[4,6]  R2570     -3.7127384041216005e-01
    phi[4,6]  R2571     -1.8650955310224093e-01
    phi[4,6]  R2572     -1.9192778436242985e-01
    phi[4,6]  R2573     -2.0883842786193396e-01
    phi[4,6]  R2574     -2.1243943031726542e-01
    phi[4,6]  R2575     -1.7265604812066511e+00
    phi[4,6]  R2576     -1.4531148036496853e+00
    phi[4,6]  R2577     -9.6352858274823738e-01
    phi[4,6]  R2578     -7.7861937555632543e-01
    phi[4,6]  R2579     -7.8038843316498019e-01
    phi[4,6]  R2580     -8.2511340479564688e-01
    phi[4,6]  R2581     -4.4421383892187127e-01
    phi[4,6]  R2582     -4.9932356880313911e-01
    phi[4,6]  R2583     -1.3598956843671326e+00
    phi[4,6]  R2584     -5.8264374014850362e-01
    phi[4,6]  R2585     -5.9704587330923686e-01
    phi[4,6]  R2586     -6.1685827868840937e-01
    phi[4,6]  R2587     -9.7404071596158970e-01
    phi[4,6]  R2588     -9.3724038817787592e-01
    phi[4,6]  R2589     -8.5863666862844268e-01
    phi[4,6]  R2590     -6.7447840601231057e-01
    phi[4,6]  R2591     -2.3328386079221153e-01
    phi[4,6]  R2592     -3.5193640692584238e-01
    phi[4,6]  R2593     -0.897845469290973
    phi[4,6]  R2594     -0.834188642548152
    phi[4,6]  R2595     -7.8762983288241983e-01
    phi[4,6]  R2596     -1.2731293821605407e+00
    phi[4,6]  R2597     -0.621113908831749
    phi[4,6]  R2598     -1.3286225891659491e+00
    phi[4,6]  R2599     -3.7839461911489458e+00
    phi[4,6]  R2600     -4.0149047132307265e+00
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R47       -1
    z[0,1,0]  R48       1
    z[0,1,0]  R61       -2.7911195158958435e-01
    z[0,1,0]  R62       -2.5956231355667114e-01
    z[0,1,0]  R63       -0.200189471244812
    z[0,1,0]  R64       9.5063948631286621e-01
    z[0,1,0]  R65       5.5172234773635864e-01
    z[0,1,0]  R66       8.2528567314147949e-01
    z[0,1,0]  R67       8.0844157934188843e-01
    z[0,1,0]  R68       8.0433422327041626e-01
    z[0,1,0]  R69       -2.6695212721824646e-01
    z[0,1,0]  R70       4.4909101724624634e-01
    z[0,1,0]  R71       -6.7703330516815186e-01
    z[0,1,0]  R72       -8.4879899024963379e-01
    z[0,1,0]  R73       -7.9707098007202148e-01
    z[0,1,0]  R74       -6.5170717239379883e-01
    z[0,1,0]  R75       -5.3997147083282471e-01
    z[0,1,0]  R76       -5.1643681526184082e-01
    z[0,1,0]  R77       -4.9135014414787292e-01
    z[0,1,0]  R78       -7.3041713237762451e-01
    z[0,1,0]  R79       -4.2066127061843872e-01
    z[0,1,0]  R80       -0.335271954536438
    z[0,1,0]  R81       -7.8593236207962036e-01
    z[0,1,0]  R82       -4.8112070560455322e-01
    z[0,1,0]  R83       -8.0663490295410156e-01
    z[0,1,0]  R84       -4.5488181710243225e-01
    z[0,1,0]  R85       -3.4604361653327942e-01
    z[0,1,0]  R86       -0.739958643913269
    z[0,1,0]  R87       -5.4418420791625977e-01
    z[0,1,0]  R88       -3.8419404625892639e-01
    z[0,1,0]  R89       -3.8750213384628296e-01
    z[0,1,0]  R90       -1.6495670378208160e-01
    z[0,1,0]  R91       -6.4012104272842407e-01
    z[0,1,0]  R92       -4.5631998777389526e-01
    z[0,1,0]  R93       -6.9034153223037720e-01
    z[0,1,0]  R94       -4.7739055752754211e-01
    z[0,1,0]  R95       -3.3747208118438721e-01
    z[0,1,0]  R96       0.616935133934021
    z[0,1,0]  R97       -2.9487824440002441e-01
    z[0,1,0]  R98       -3.2894019037485123e-02
    z[0,1,0]  R99       2.6451559737324715e-02
    z[0,1,0]  R100      -5.9227943420410156e-02
    z[0,1,0]  R101      -3.2220444083213806e-01
    z[0,1,0]  R102      -4.7876590490341187e-01
    z[0,1,0]  R103      -2.2320681810379028e-01
    z[0,1,0]  R104      -3.1698886305093765e-02
    z[0,1,0]  R105      4.0914884209632874e-01
    z[0,1,0]  R106      2.0863594114780426e-01
    z[0,1,0]  R107      4.6707686781883240e-01
    z[0,1,0]  R108      5.0943013280630112e-02
    z[0,1,0]  R109      3.4773871302604675e-01
    z[0,1,0]  R110      8.9614562690258026e-02
    z[0,1,0]  R111      -0.302606999874115
    z[0,1,0]  R112      -8.2195393741130829e-02
    z[0,1,0]  R113      -1.9792994856834412e-01
    z[0,1,0]  R114      -2.2379927337169647e-01
    z[0,1,0]  R115      0.0955568253993988
    z[0,1,0]  R116      5.4114109277725220e-01
    z[0,1,0]  R117      5.3917460143566132e-02
    z[0,1,0]  R118      3.4159538149833679e-01
    z[0,1,0]  R119      4.7162267565727234e-01
    z[0,1,0]  R120      2.4069221317768097e-01
    z[0,1,0]  R121      4.4048145413398743e-01
    z[0,1,0]  R122      4.4716534018516541e-01
    z[0,1,0]  R123      3.1553784012794495e-01
    z[0,1,0]  R124      2.1296481788158417e-01
    z[0,1,0]  R125      2.0398156344890594e-01
    z[0,1,0]  R126      1.4513950049877167e-01
    z[0,1,0]  R127      4.2035266757011414e-01
    z[0,1,0]  R128      1.8896244466304779e-01
    z[0,1,0]  R129      2.6948067545890808e-01
    z[0,1,0]  R130      5.3773349523544312e-01
    z[0,1,0]  R131      -8.8005030155181885e-01
    z[0,1,0]  R132      -8.4766268730163574e-01
    z[0,1,0]  R133      -8.9489394426345825e-01
    z[0,1,0]  R134      5.6491714715957642e-01
    z[0,1,0]  R135      6.4999121427536011e-01
    z[0,1,0]  R136      5.7755821943283081e-01
    z[0,1,0]  R137      1.8908669054508209e-01
    z[0,1,0]  R138      6.9569748640060425e-01
    z[0,1,0]  R139      5.9627151489257812e-01
    z[0,1,0]  R140      5.2757942676544189e-01
    z[0,1,0]  R141      -3.5752275586128235e-01
    z[0,1,0]  R142      -2.9642897844314575e-01
    z[0,1,0]  R143      -6.3600605726242065e-01
    z[0,1,0]  R144      -3.5773396492004395e-01
    z[0,1,0]  R145      -1.8340660631656647e-01
    z[0,1,0]  R146      -3.7775182723999023e-01
    z[0,1,0]  R147      -3.4659394621849060e-01
    z[0,1,0]  R148      6.2411874532699585e-02
    z[0,1,0]  R149      4.5564625412225723e-02
    z[0,1,0]  R150      -5.1198780536651611e-01
    z[0,1,0]  R151      -4.8201125860214233e-01
    z[0,1,0]  R152      -5.8650255203247070e-01
    z[0,1,0]  R153      -4.3368390202522278e-01
    z[0,1,0]  R154      -7.5530534982681274e-01
    z[0,1,0]  R155      0.0590699128806591
    z[0,1,0]  R156      -3.6986050009727478e-01
    z[0,1,0]  R157      1.0634465515613556e-01
    z[0,1,0]  R158      4.4743397831916809e-01
    z[0,1,0]  R159      1.4682547748088837e-01
    z[0,1,0]  R160      0.00492557417601347
    z[0,1,0]  R161      -4.5591101050376892e-01
    z[0,1,0]  R162      -6.2477695941925049e-01
    z[0,1,0]  R163      1.2044054269790649e-01
    z[0,1,0]  R164      2.5214740633964539e-01
    z[0,1,0]  R165      1.6487506031990051e-01
    z[0,1,0]  R166      -3.5710880160331726e-01
    z[0,1,0]  R167      -2.3909138143062592e-01
    z[0,1,0]  R168      -4.0107741951942444e-01
    z[0,1,0]  R169      -2.8470501303672791e-01
    z[0,1,0]  R170      6.0285080224275589e-02
    z[0,1,0]  R171      -4.5614802837371826e-01
    z[0,1,0]  R172      1.6883884370326996e-01
    z[0,1,0]  R173      -5.7301348447799683e-01
    z[0,1,0]  R174      -6.5560430288314819e-01
    z[0,1,0]  R175      4.6026740223169327e-02
    z[0,1,0]  R176      5.9459650516510010e-01
    z[0,1,0]  R177      -8.1936977803707123e-03
    z[0,1,0]  R178      -2.8132265806198120e-01
    z[0,1,0]  R179      -3.0873646959662437e-02
    z[0,1,0]  R180      6.2525354325771332e-02
    z[0,1,0]  R181      -6.5801465511322021e-01
    z[0,1,0]  R182      3.9888685941696167e-01
    z[0,1,0]  R183      -7.6452434062957764e-01
    z[0,1,0]  R184      7.1891725063323975e-01
    z[0,1,0]  R185      1.0193198919296265e-01
    z[0,1,0]  R186      4.0106898546218872e-01
    z[0,1,0]  R187      -1.0802744328975677e-01
    z[0,1,0]  R188      -2.2934605181217194e-01
    z[0,1,0]  R189      -2.3645068705081940e-01
    z[0,1,0]  R190      -6.9124542176723480e-02
    z[0,1,0]  R191      -6.0876989364624023e-01
    z[0,1,0]  R192      -4.0712639689445496e-01
    z[0,1,0]  R193      -1.0106655955314636e-01
    z[0,1,0]  R194      -1.8882115185260773e-01
    z[0,1,0]  R195      3.2330492138862610e-01
    z[0,1,0]  R196      -1.0135262459516525e-01
    z[0,1,0]  R197      -2.3631669580936432e-02
    z[0,1,0]  R198      2.9480382800102234e-02
    z[0,1,0]  R199      -2.4920843541622162e-01
    z[0,1,0]  R200      -1.4453461766242981e-01
    z[0,1,0]  R201      -6.4922505617141724e-01
    z[0,1,0]  R202      -6.0427713394165039e-01
    z[0,1,0]  R203      7.9296268522739410e-02
    z[0,1,0]  R204      5.6043070554733276e-01
    z[0,1,0]  R205      -5.7753247022628784e-01
    z[0,1,0]  R206      1.8766084313392639e-01
    z[0,1,0]  R207      8.5992045700550079e-02
    z[0,1,0]  R208      2.0371274650096893e-01
    z[0,1,0]  R209      1.2180276960134506e-01
    z[0,1,0]  R210      2.2687834501266479e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R49       -1
    z[0,1,1]  R50       1
    z[0,1,1]  R61       5.7454162836074829e-01
    z[0,1,1]  R62       1.6744308173656464e-01
    z[0,1,1]  R63       3.1051808595657349e-01
    z[0,1,1]  R64       1.8348847329616547e-01
    z[0,1,1]  R65       7.3893499374389648e-01
    z[0,1,1]  R66       1.7857621610164642e-01
    z[0,1,1]  R67       5.3061944246292114e-01
    z[0,1,1]  R68       4.6047952771186829e-01
    z[0,1,1]  R69       4.5100402832031250e-01
    z[0,1,1]  R70       0.596885621547699
    z[0,1,1]  R71       -3.4250352531671524e-02
    z[0,1,1]  R72       -2.0875754952430725e-01
    z[0,1,1]  R73       2.0808492600917816e-01
    z[0,1,1]  R74       -4.1754089295864105e-02
    z[0,1,1]  R75       5.3702068328857422e-01
    z[0,1,1]  R76       -3.1882904469966888e-02
    z[0,1,1]  R77       -4.5007994771003723e-01
    z[0,1,1]  R78       -5.1013922691345215e-01
    z[0,1,1]  R79       -2.0662444829940796e-01
    z[0,1,1]  R80       -6.6670411825180054e-01
    z[0,1,1]  R81       4.5394363999366760e-01
    z[0,1,1]  R82       7.4497830867767334e-01
    z[0,1,1]  R83       2.1404880285263062e-01
    z[0,1,1]  R84       7.1047663688659668e-01
    z[0,1,1]  R85       6.4928478002548218e-01
    z[0,1,1]  R86       3.7441188097000122e-01
    z[0,1,1]  R87       1.0908488184213638e-02
    z[0,1,1]  R88       4.2736539244651794e-01
    z[0,1,1]  R89       4.4189310073852539e-01
    z[0,1,1]  R90       2.7838796377182007e-01
    z[0,1,1]  R91       8.7187774479389191e-02
    z[0,1,1]  R92       3.7865081429481506e-01
    z[0,1,1]  R93       -4.3377488851547241e-01
    z[0,1,1]  R94       -6.8070453405380249e-01
    z[0,1,1]  R95       -8.6769664287567139e-01
    z[0,1,1]  R96       2.1589897572994232e-01
    z[0,1,1]  R97       -5.0343447923660278e-01
    z[0,1,1]  R98       -7.4226856231689453e-01
    z[0,1,1]  R99       -9.0129858255386353e-01
    z[0,1,1]  R100      -5.6143432855606079e-01
    z[0,1,1]  R101      6.3973242044448853e-01
    z[0,1,1]  R102      2.6570373773574829e-01
    z[0,1,1]  R103      -7.6507246494293213e-01
    z[0,1,1]  R104      -5.2671676874160767e-01
    z[0,1,1]  R105      -5.2842015027999878e-01
    z[0,1,1]  R106      -4.0489968657493591e-01
    z[0,1,1]  R107      -4.1363832354545593e-01
    z[0,1,1]  R108      -2.0617979764938354e-01
    z[0,1,1]  R109      -5.0428098440170288e-01
    z[0,1,1]  R110      -0.28351891040802
    z[0,1,1]  R111      5.9813719987869263e-01
    z[0,1,1]  R112      -5.6944328546524048e-01
    z[0,1,1]  R113      -7.9107505083084106e-01
    z[0,1,1]  R114      -8.3547854423522949e-01
    z[0,1,1]  R115      -6.2728846073150635e-01
    z[0,1,1]  R116      -1.5642635524272919e-01
    z[0,1,1]  R117      -0.408250629901886
    z[0,1,1]  R118      1.0886962711811066e-01
    z[0,1,1]  R119      -6.0041254758834839e-01
    z[0,1,1]  R120      1.5060398727655411e-03
    z[0,1,1]  R121      7.6852989196777344e-01
    z[0,1,1]  R122      7.1061855554580688e-01
    z[0,1,1]  R123      6.9127148389816284e-01
    z[0,1,1]  R124      6.7748028039932251e-01
    z[0,1,1]  R125      6.6225379705429077e-01
    z[0,1,1]  R126      0.657947301864624
    z[0,1,1]  R127      6.5257954597473145e-01
    z[0,1,1]  R128      6.5442794561386108e-01
    z[0,1,1]  R129      6.3109076023101807e-01
    z[0,1,1]  R130      6.2716007232666016e-01
    z[0,1,1]  R131      1.3539300300180912e-02
    z[0,1,1]  R132      -0.0493953637778759
    z[0,1,1]  R133      -4.1284445673227310e-02
    z[0,1,1]  R134      -5.1278859376907349e-01
    z[0,1,1]  R135      -5.4661726951599121e-01
    z[0,1,1]  R136      -4.9537131190299988e-01
    z[0,1,1]  R137      -5.5065184831619263e-01
    z[0,1,1]  R138      -4.6201971173286438e-01
    z[0,1,1]  R139      -6.0528641939163208e-01
    z[0,1,1]  R140      -3.8753968477249146e-01
    z[0,1,1]  R141      2.2777329385280609e-01
    z[0,1,1]  R142      3.5794261097908020e-01
    z[0,1,1]  R143      -0.0707663968205452
    z[0,1,1]  R144      2.1073617041110992e-01
    z[0,1,1]  R145      2.3412954807281494e-01
    z[0,1,1]  R146      2.5247669219970703e-01
    z[0,1,1]  R147      1.3208749890327454e-01
    z[0,1,1]  R148      6.7550706863403320e-01
    z[0,1,1]  R149      6.7064303159713745e-01
    z[0,1,1]  R150      -4.9852974712848663e-02
    z[0,1,1]  R151      4.2516711354255676e-01
    z[0,1,1]  R152      2.7613270282745361e-01
    z[0,1,1]  R153      2.8282597661018372e-01
    z[0,1,1]  R154      4.4181060791015625e-01
    z[0,1,1]  R155      -1.9234298169612885e-01
    z[0,1,1]  R156      1.0171489417552948e-01
    z[0,1,1]  R157      5.7744336128234863e-01
    z[0,1,1]  R158      -5.2219372987747192e-01
    z[0,1,1]  R159      -3.1241990625858307e-02
    z[0,1,1]  R160      5.3227978944778442e-01
    z[0,1,1]  R161      3.8184702396392822e-01
    z[0,1,1]  R162      -2.7537789195775986e-02
    z[0,1,1]  R163      8.5406959056854248e-01
    z[0,1,1]  R164      8.1836843490600586e-01
    z[0,1,1]  R165      2.6267403364181519e-01
    z[0,1,1]  R166      1.3385763764381409e-01
    z[0,1,1]  R167      2.5609949231147766e-01
    z[0,1,1]  R168      8.2399033010005951e-02
    z[0,1,1]  R169      2.4601301550865173e-01
    z[0,1,1]  R170      6.1969733238220215e-01
    z[0,1,1]  R171      4.0898019075393677e-01
    z[0,1,1]  R172      6.4176046848297119e-01
    z[0,1,1]  R173      1.0565433651208878e-01
    z[0,1,1]  R174      1.3106757402420044e-01
    z[0,1,1]  R175      9.3674689531326294e-01
    z[0,1,1]  R176      5.0609749555587769e-01
    z[0,1,1]  R177      4.6355494856834412e-01
    z[0,1,1]  R178      0.284940242767334
    z[0,1,1]  R179      2.8398683294653893e-02
    z[0,1,1]  R180      2.4847318232059479e-01
    z[0,1,1]  R181      2.6605013012886047e-01
    z[0,1,1]  R182      8.0469900369644165e-01
    z[0,1,1]  R183      4.4193947315216064e-01
    z[0,1,1]  R184      -5.1152259111404419e-01
    z[0,1,1]  R185      -4.2723175883293152e-01
    z[0,1,1]  R186      -4.2270788550376892e-01
    z[0,1,1]  R187      -2.3982043564319611e-01
    z[0,1,1]  R188      -9.1337114572525024e-01
    z[0,1,1]  R189      -8.7942677736282349e-01
    z[0,1,1]  R190      -2.8539735078811646e-01
    z[0,1,1]  R191      3.4915563464164734e-01
    z[0,1,1]  R192      3.8095399737358093e-01
    z[0,1,1]  R193      5.5673009157180786e-01
    z[0,1,1]  R194      -1.8500310182571411e-01
    z[0,1,1]  R195      -3.9021816849708557e-01
    z[0,1,1]  R196      3.8227722048759460e-02
    z[0,1,1]  R197      -2.0226265490055084e-01
    z[0,1,1]  R198      5.9279982000589371e-02
    z[0,1,1]  R199      -0.926781177520752
    z[0,1,1]  R200      -7.5965744256973267e-01
    z[0,1,1]  R201      1.5500506758689880e-01
    z[0,1,1]  R202      7.0526483468711376e-03
    z[0,1,1]  R203      9.5337331295013428e-01
    z[0,1,1]  R204      -6.2721198797225952e-01
    z[0,1,1]  R205      3.7929084897041321e-01
    z[0,1,1]  R206      -1.0878720879554749e-01
    z[0,1,1]  R207      -3.3713793754577637e-01
    z[0,1,1]  R208      -3.9753583073616028e-01
    z[0,1,1]  R209      -0.273084819316864
    z[0,1,1]  R210      -3.3717691898345947e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R51       -1
    z[0,1,2]  R52       1
    z[0,1,2]  R61       1.5083377063274384e-01
    z[0,1,2]  R62       2.3986802995204926e-01
    z[0,1,2]  R63       -1.8829308450222015e-01
    z[0,1,2]  R64       2.4266245961189270e-01
    z[0,1,2]  R65       -3.3070594072341919e-01
    z[0,1,2]  R66       3.0206015706062317e-01
    z[0,1,2]  R67       -1.5245966613292694e-01
    z[0,1,2]  R68       1.9436698406934738e-02
    z[0,1,2]  R69       -3.4611273556947708e-02
    z[0,1,2]  R70       -5.8791655302047729e-01
    z[0,1,2]  R71       -6.1598002910614014e-01
    z[0,1,2]  R72       -3.5712572932243347e-01
    z[0,1,2]  R73       -2.3911079764366150e-01
    z[0,1,2]  R74       -3.2284760475158691e-01
    z[0,1,2]  R75       2.2259363532066345e-01
    z[0,1,2]  R76       -5.8785039186477661e-01
    z[0,1,2]  R77       -5.2049297094345093e-01
    z[0,1,2]  R78       -8.4991287440061569e-03
    z[0,1,2]  R79       -5.2151817083358765e-01
    z[0,1,2]  R80       5.2224820852279663e-01
    z[0,1,2]  R81       -4.9242395907640457e-02
    z[0,1,2]  R82       1.6663928329944611e-01
    z[0,1,2]  R83       2.8458821773529053e-01
    z[0,1,2]  R84       -0.265234112739563
    z[0,1,2]  R85       -2.2192781791090965e-02
    z[0,1,2]  R86       6.0554448515176773e-02
    z[0,1,2]  R87       2.0031755790114403e-02
    z[0,1,2]  R88       3.7380585074424744e-01
    z[0,1,2]  R89       5.7075881958007812e-01
    z[0,1,2]  R90       1.7242784798145294e-01
    z[0,1,2]  R91       1.9863437116146088e-01
    z[0,1,2]  R92       -3.7209963798522949e-01
    z[0,1,2]  R93       1.9737100601196289e-01
    z[0,1,2]  R94       4.5568180084228516e-01
    z[0,1,2]  R95       1.1098874360322952e-01
    z[0,1,2]  R96       -2.9603496193885803e-01
    z[0,1,2]  R97       5.4920607805252075e-01
    z[0,1,2]  R98       3.7952467799186707e-01
    z[0,1,2]  R99       1.7176325619220734e-01
    z[0,1,2]  R100      5.3085041046142578e-01
    z[0,1,2]  R101      -2.8079429268836975e-01
    z[0,1,2]  R102      -4.2123457789421082e-01
    z[0,1,2]  R103      0.408405065536499
    z[0,1,2]  R104      7.0510065555572510e-01
    z[0,1,2]  R105      9.5214679837226868e-02
    z[0,1,2]  R106      1.9265627861022949e-01
    z[0,1,2]  R107      1.5138559043407440e-01
    z[0,1,2]  R108      4.2132866382598877e-01
    z[0,1,2]  R109      -1.5476787090301514e-01
    z[0,1,2]  R110      2.9042625427246094e-01
    z[0,1,2]  R111      -1.1957526206970215e-01
    z[0,1,2]  R112      7.2208935022354126e-01
    z[0,1,2]  R113      4.5464840531349182e-01
    z[0,1,2]  R114      2.3715527355670929e-01
    z[0,1,2]  R115      7.1603232622146606e-01
    z[0,1,2]  R116      4.1160178184509277e-01
    z[0,1,2]  R117      0.485909104347229
    z[0,1,2]  R118      7.6738965511322021e-01
    z[0,1,2]  R119      -2.7881422638893127e-01
    z[0,1,2]  R120      -1.6056613624095917e-01
    z[0,1,2]  R121      1.9762471318244934e-01
    z[0,1,2]  R122      1.8094404041767120e-01
    z[0,1,2]  R123      1.7155742272734642e-02
    z[0,1,2]  R124      2.3242124915122986e-01
    z[0,1,2]  R125      2.0797017216682434e-01
    z[0,1,2]  R126      3.0362471938133240e-01
    z[0,1,2]  R127      1.5505865216255188e-01
    z[0,1,2]  R128      1.7621801793575287e-01
    z[0,1,2]  R129      1.8051068484783173e-01
    z[0,1,2]  R130      -1.3206172734498978e-02
    z[0,1,2]  R131      -6.9564029574394226e-02
    z[0,1,2]  R132      1.7230573296546936e-01
    z[0,1,2]  R133      1.7138895392417908e-01
    z[0,1,2]  R134      -1.4812509715557098e-01
    z[0,1,2]  R135      -1.6373504698276520e-01
    z[0,1,2]  R136      -2.1429817378520966e-01
    z[0,1,2]  R137      -2.5060099363327026e-01
    z[0,1,2]  R138      -6.6603772342205048e-02
    z[0,1,2]  R139      4.1931409388780594e-02
    z[0,1,2]  R140      -1.5611787140369415e-01
    z[0,1,2]  R141      2.7155104279518127e-01
    z[0,1,2]  R142      -1.2577632069587708e-01
    z[0,1,2]  R143      -2.7121728658676147e-01
    z[0,1,2]  R144      0.0661039724946022
    z[0,1,2]  R145      -5.5829749908298254e-04
    z[0,1,2]  R146      -1.6054630279541016e-01
    z[0,1,2]  R147      1.1115300655364990e-01
    z[0,1,2]  R148      -0.4558085501194
    z[0,1,2]  R149      -4.5450708270072937e-01
    z[0,1,2]  R150      6.2247227877378464e-02
    z[0,1,2]  R151      4.6318256855010986e-01
    z[0,1,2]  R152      4.2427086830139160e-01
    z[0,1,2]  R153      1.3735873997211456e-01
    z[0,1,2]  R154      -2.5027480721473694e-01
    z[0,1,2]  R155      1.4518241398036480e-02
    z[0,1,2]  R156      3.6463406682014465e-01
    z[0,1,2]  R157      -3.2373934984207153e-01
    z[0,1,2]  R158      4.8716405034065247e-01
    z[0,1,2]  R159      3.8003337383270264e-01
    z[0,1,2]  R160      -1.1138872057199478e-01
    z[0,1,2]  R161      6.1045867204666138e-01
    z[0,1,2]  R162      -1.4914770424365997e-01
    z[0,1,2]  R163      -3.2510453462600708e-01
    z[0,1,2]  R164      -2.3592798411846161e-01
    z[0,1,2]  R165      -3.6896771192550659e-01
    z[0,1,2]  R166      8.4914974868297577e-02
    z[0,1,2]  R167      2.3748025298118591e-01
    z[0,1,2]  R168      -4.6754304319620132e-02
    z[0,1,2]  R169      4.0193051099777222e-01
    z[0,1,2]  R170      -3.2748410105705261e-01
    z[0,1,2]  R171      3.2034772634506226e-01
    z[0,1,2]  R172      3.4528324007987976e-01
    z[0,1,2]  R173      -9.6078209578990936e-02
    z[0,1,2]  R174      -2.2535999119281769e-01
    z[0,1,2]  R175      -2.2950629889965057e-01
    z[0,1,2]  R176      -1.9488035142421722e-01
    z[0,1,2]  R177      -1.3908736407756805e-01
    z[0,1,2]  R178      3.8566029071807861e-01
    z[0,1,2]  R179      -1.7290504276752472e-01
    z[0,1,2]  R180      -5.4297423362731934e-01
    z[0,1,2]  R181      1.8496979773044586e-01
    z[0,1,2]  R182      -0.244472473859787
    z[0,1,2]  R183      -2.9634317755699158e-01
    z[0,1,2]  R184      3.2215365767478943e-01
    z[0,1,2]  R185      1.1727154999971390e-01
    z[0,1,2]  R186      5.3423233330249786e-02
    z[0,1,2]  R187      3.2155385613441467e-01
    z[0,1,2]  R188      1.3224214315414429e-01
    z[0,1,2]  R189      1.9594286382198334e-01
    z[0,1,2]  R190      2.3662203550338745e-01
    z[0,1,2]  R191      2.2422102093696594e-01
    z[0,1,2]  R192      4.1424378752708435e-01
    z[0,1,2]  R193      -4.9048945307731628e-01
    z[0,1,2]  R194      4.3830013275146484e-01
    z[0,1,2]  R195      0.417977511882782
    z[0,1,2]  R196      4.0899294614791870e-01
    z[0,1,2]  R197      2.4501444399356842e-01
    z[0,1,2]  R198      -1.8349802494049072e-01
    z[0,1,2]  R199      1.4926487207412720e-01
    z[0,1,2]  R200      3.8419011235237122e-01
    z[0,1,2]  R201      2.4462023377418518e-01
    z[0,1,2]  R202      -1.4788176119327545e-01
    z[0,1,2]  R203      -4.7778464853763580e-02
    z[0,1,2]  R204      1.4802455902099609e-01
    z[0,1,2]  R205      -4.2650622129440308e-01
    z[0,1,2]  R206      4.7915931791067123e-03
    z[0,1,2]  R207      -8.4596776962280273e-01
    z[0,1,2]  R208      -7.6929843425750732e-01
    z[0,1,2]  R209      -8.8198131322860718e-01
    z[0,1,2]  R210      -8.0463838577270508e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R53       -1
    z[0,1,3]  R54       1
    z[0,1,3]  R61       -4.8630633950233459e-01
    z[0,1,3]  R62       -9.0782207250595093e-01
    z[0,1,3]  R63       -7.7078616619110107e-01
    z[0,1,3]  R64       2.0572718232870102e-02
    z[0,1,3]  R65       -3.4895248245447874e-03
    z[0,1,3]  R66       -1.3784939050674438e-01
    z[0,1,3]  R67       -1.7129622399806976e-01
    z[0,1,3]  R68       -1.2891253829002380e-01
    z[0,1,3]  R69       -5.7065492868423462e-01
    z[0,1,3]  R70       2.2236967086791992e-01
    z[0,1,3]  R71       1.8083423376083374e-01
    z[0,1,3]  R72       -6.9698132574558258e-02
    z[0,1,3]  R73       1.4075244963169098e-01
    z[0,1,3]  R74       4.2891070246696472e-01
    z[0,1,3]  R75       0.380641371011734
    z[0,1,3]  R76       0.0773368775844574
    z[0,1,3]  R77       3.2796174287796021e-01
    z[0,1,3]  R78       -3.2630673050880432e-01
    z[0,1,3]  R79       2.8481978178024292e-01
    z[0,1,3]  R80       2.4042797088623047e-01
    z[0,1,3]  R81       -1.6804021596908569e-01
    z[0,1,3]  R82       -2.1764262020587921e-01
    z[0,1,3]  R83       -1.5559849143028259e-01
    z[0,1,3]  R84       -2.0663103461265564e-01
    z[0,1,3]  R85       -4.0528619289398193e-01
    z[0,1,3]  R86       -3.3417305350303650e-01
    z[0,1,3]  R87       -6.7320454120635986e-01
    z[0,1,3]  R88       -2.5686460733413696e-01
    z[0,1,3]  R89       -2.0680793095380068e-03
    z[0,1,3]  R90       -4.6091657876968384e-01
    z[0,1,3]  R91       -6.1763554811477661e-01
    z[0,1,3]  R92       -2.4363413453102112e-01
    z[0,1,3]  R93       4.7199773788452148e-01
    z[0,1,3]  R94       -1.1488460004329681e-01
    z[0,1,3]  R95       9.7651846706867218e-02
    z[0,1,3]  R96       4.2816668748855591e-01
    z[0,1,3]  R97       3.2782697677612305e-01
    z[0,1,3]  R98       -4.7279921174049377e-01
    z[0,1,3]  R99       -5.6368038058280945e-02
    z[0,1,3]  R100      -5.9518980979919434e-01
    z[0,1,3]  R101      -1.8755196034908295e-01
    z[0,1,3]  R102      -2.4840892851352692e-01
    z[0,1,3]  R103      -2.1829817444086075e-02
    z[0,1,3]  R104      2.9045999050140381e-01
    z[0,1,3]  R105      -6.3881975412368774e-01
    z[0,1,3]  R106      7.2736620903015137e-01
    z[0,1,3]  R107      0.645383358001709
    z[0,1,3]  R108      6.5305101871490479e-01
    z[0,1,3]  R109      -4.8276394605636597e-01
    z[0,1,3]  R110      8.8347822427749634e-01
    z[0,1,3]  R111      5.1070757210254669e-02
    z[0,1,3]  R112      1.2201625853776932e-01
    z[0,1,3]  R113      1.0796375572681427e-01
    z[0,1,3]  R114      -4.6345632523298264e-02
    z[0,1,3]  R115      -2.7514001727104187e-01
    z[0,1,3]  R116      -4.4121104478836060e-01
    z[0,1,3]  R117      6.0426419973373413e-01
    z[0,1,3]  R118      -0.250192791223526
    z[0,1,3]  R119      -4.0110346674919128e-01
    z[0,1,3]  R120      8.6320447921752930e-01
    z[0,1,3]  R121      2.4325282871723175e-01
    z[0,1,3]  R122      -2.9130894690752029e-02
    z[0,1,3]  R123      -2.5148457288742065e-01
    z[0,1,3]  R124      1.2540750205516815e-01
    z[0,1,3]  R125      -6.9350488483905792e-02
    z[0,1,3]  R126      -2.2384946048259735e-01
    z[0,1,3]  R127      -1.5611016750335693e-01
    z[0,1,3]  R128      0.351661741733551
    z[0,1,3]  R129      -1.9590289890766144e-01
    z[0,1,3]  R130      -1.4304912090301514e-01
    z[0,1,3]  R131      2.1276351809501648e-01
    z[0,1,3]  R132      2.3736884817481041e-02
    z[0,1,3]  R133      2.3033104836940765e-01
    z[0,1,3]  R134      -5.3111881017684937e-01
    z[0,1,3]  R135      -4.1673696041107178e-01
    z[0,1,3]  R136      -6.0401380062103271e-01
    z[0,1,3]  R137      -7.1226024627685547e-01
    z[0,1,3]  R138      -5.0312846899032593e-01
    z[0,1,3]  R139      -3.5064321756362915e-01
    z[0,1,3]  R140      -6.3387966156005859e-01
    z[0,1,3]  R141      -6.4800351858139038e-01
    z[0,1,3]  R142      -7.8793352842330933e-01
    z[0,1,3]  R143      -1.7942821979522705e-01
    z[0,1,3]  R144      -0.599696934223175
    z[0,1,3]  R145      -9.0880846977233887e-01
    z[0,1,3]  R146      -0.678071916103363
    z[0,1,3]  R147      -3.2827010750770569e-01
    z[0,1,3]  R148      -3.1030055880546570e-01
    z[0,1,3]  R149      -5.1563370227813721e-01
    z[0,1,3]  R150      -4.5084246993064880e-01
    z[0,1,3]  R151      4.4007804989814758e-01
    z[0,1,3]  R152      3.3346137404441833e-01
    z[0,1,3]  R153      1.2889523059129715e-02
    z[0,1,3]  R154      -2.9720512032508850e-01
    z[0,1,3]  R155      -0.571692705154419
    z[0,1,3]  R156      -3.4564909338951111e-01
    z[0,1,3]  R157      -2.9619028791785240e-03
    z[0,1,3]  R158      2.4839065968990326e-01
    z[0,1,3]  R159      8.3537089824676514e-01
    z[0,1,3]  R160      6.5786695480346680e-01
    z[0,1,3]  R161      -4.3137678503990173e-01
    z[0,1,3]  R162      -2.2906927764415741e-01
    z[0,1,3]  R163      -2.2457545623183250e-02
    z[0,1,3]  R164      -8.8043145835399628e-02
    z[0,1,3]  R165      -7.6031464338302612e-01
    z[0,1,3]  R166      -4.3721115589141846e-01
    z[0,1,3]  R167      -1.2719729542732239e-01
    z[0,1,3]  R168      -4.4476732611656189e-01
    z[0,1,3]  R169      2.0254816114902496e-01
    z[0,1,3]  R170      1.8693853914737701e-01
    z[0,1,3]  R171      -4.4414305686950684e-01
    z[0,1,3]  R172      4.7506517171859741e-01
    z[0,1,3]  R173      -1.5171146392822266e-01
    z[0,1,3]  R174      -4.6923705935478210e-01
    z[0,1,3]  R175      2.3001782596111298e-02
    z[0,1,3]  R176      1.2662726454436779e-02
    z[0,1,3]  R177      -0.766851007938385
    z[0,1,3]  R178      1.9679950177669525e-01
    z[0,1,3]  R179      -8.5443496704101562e-01
    z[0,1,3]  R180      -7.1599733829498291e-01
    z[0,1,3]  R181      -0.621579110622406
    z[0,1,3]  R182      -1.8579454720020294e-01
    z[0,1,3]  R183      -3.1899437308311462e-01
    z[0,1,3]  R184      2.7757775783538818e-01
    z[0,1,3]  R185      -3.3909055590629578e-01
    z[0,1,3]  R186      1.6180644929409027e-01
    z[0,1,3]  R187      7.4454855918884277e-01
    z[0,1,3]  R188      2.3615576326847076e-02
    z[0,1,3]  R189      -6.1152640730142593e-02
    z[0,1,3]  R190      6.6606956720352173e-01
    z[0,1,3]  R191      -2.6376655697822571e-01
    z[0,1,3]  R192      2.7661317586898804e-01
    z[0,1,3]  R193      -4.9569407105445862e-01
    z[0,1,3]  R194      7.1560466289520264e-01
    z[0,1,3]  R195      1.2439829856157303e-01
    z[0,1,3]  R196      8.8599252700805664e-01
    z[0,1,3]  R197      8.0509597063064575e-01
    z[0,1,3]  R198      9.6395754814147949e-01
    z[0,1,3]  R199      1.3031853735446930e-01
    z[0,1,3]  R200      4.5830440521240234e-01
    z[0,1,3]  R201      2.2185295820236206e-01
    z[0,1,3]  R202      -3.4237092733383179e-01
    z[0,1,3]  R203      1.3089454174041748e-01
    z[0,1,3]  R204      1.9845359027385712e-02
    z[0,1,3]  R205      -1.9326542317867279e-01
    z[0,1,3]  R206      -5.7583391666412354e-01
    z[0,1,3]  R207      0.336665540933609
    z[0,1,3]  R208      3.8043934106826782e-01
    z[0,1,3]  R209      3.3475691080093384e-01
    z[0,1,3]  R210      3.3808118104934692e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R55       -1
    z[0,1,4]  R56       1
    z[0,1,4]  R61       2.0659589767456055e-01
    z[0,1,4]  R62       1.2071436643600464e-01
    z[0,1,4]  R63       -2.7697184681892395e-01
    z[0,1,4]  R64       -2.2041415795683861e-02
    z[0,1,4]  R65       -1.4359714090824127e-01
    z[0,1,4]  R66       -1.9014884531497955e-01
    z[0,1,4]  R67       -1.0998731106519699e-01
    z[0,1,4]  R68       3.2825049757957458e-01
    z[0,1,4]  R69       -8.3933107554912567e-02
    z[0,1,4]  R70       1.6483344137668610e-02
    z[0,1,4]  R71       -2.2064687311649323e-01
    z[0,1,4]  R72       -2.0545309782028198e-01
    z[0,1,4]  R73       3.3019462227821350e-01
    z[0,1,4]  R74       2.6482102274894714e-01
    z[0,1,4]  R75       -3.3414953947067261e-01
    z[0,1,4]  R76       4.2259556055068970e-01
    z[0,1,4]  R77       -9.9161945283412933e-02
    z[0,1,4]  R78       -4.5455410145223141e-03
    z[0,1,4]  R79       3.9835435152053833e-01
    z[0,1,4]  R80       3.1894508004188538e-01
    z[0,1,4]  R81       -8.5877306759357452e-02
    z[0,1,4]  R82       -2.6973801851272583e-01
    z[0,1,4]  R83       -2.0720811560750008e-02
    z[0,1,4]  R84       4.0071615576744080e-01
    z[0,1,4]  R85       4.1808298230171204e-01
    z[0,1,4]  R86       5.7537477463483810e-02
    z[0,1,4]  R87       3.4836444258689880e-01
    z[0,1,4]  R88       3.7266877293586731e-01
    z[0,1,4]  R89       0.363534539937973
    z[0,1,4]  R90       -7.2346520423889160e-01
    z[0,1,4]  R91       2.0305566489696503e-01
    z[0,1,4]  R92       2.0270688831806183e-01
    z[0,1,4]  R93       -1.0040581226348877e-01
    z[0,1,4]  R94       -2.6142343878746033e-01
    z[0,1,4]  R95       -1.0947328805923462e-01
    z[0,1,4]  R96       2.3419323563575745e-01
    z[0,1,4]  R97       -3.2322630286216736e-01
    z[0,1,4]  R98       -2.1963614225387573e-01
    z[0,1,4]  R99       -2.3658205568790436e-01
    z[0,1,4]  R100      -1.5085247159004211e-01
    z[0,1,4]  R101      -6.5335296094417572e-02
    z[0,1,4]  R102      -5.7643568515777588e-01
    z[0,1,4]  R103      -1.8529847264289856e-01
    z[0,1,4]  R104      -2.1317061781883240e-01
    z[0,1,4]  R105      9.3847788870334625e-02
    z[0,1,4]  R106      2.6367539167404175e-01
    z[0,1,4]  R107      -5.5896721780300140e-02
    z[0,1,4]  R108      2.5234678387641907e-01
    z[0,1,4]  R109      4.5455864071846008e-01
    z[0,1,4]  R110      1.9800759851932526e-01
    z[0,1,4]  R111      -2.6005905866622925e-01
    z[0,1,4]  R112      -2.1363671123981476e-01
    z[0,1,4]  R113      7.0633560419082642e-02
    z[0,1,4]  R114      -1.4188164472579956e-01
    z[0,1,4]  R115      9.3043945729732513e-02
    z[0,1,4]  R116      5.0262737274169922e-01
    z[0,1,4]  R117      1.1373239010572433e-01
    z[0,1,4]  R118      4.0888068079948425e-01
    z[0,1,4]  R119      4.2495880275964737e-02
    z[0,1,4]  R120      -3.8691172003746033e-01
    z[0,1,4]  R121      3.9067290723323822e-02
    z[0,1,4]  R122      -2.8967443108558655e-01
    z[0,1,4]  R123      5.9735560417175293e-01
    z[0,1,4]  R124      1.1907239258289337e-01
    z[0,1,4]  R125      -2.6911571621894836e-01
    z[0,1,4]  R126      -4.7039699554443359e-01
    z[0,1,4]  R127      2.0863448083400726e-01
    z[0,1,4]  R128      3.7537318468093872e-01
    z[0,1,4]  R129      -4.9597907066345215e-01
    z[0,1,4]  R130      0.436262845993042
    z[0,1,4]  R131      2.0806825160980225e-01
    z[0,1,4]  R132      -4.7438085079193115e-01
    z[0,1,4]  R133      -1.6129940748214722e-01
    z[0,1,4]  R134      -1.7047438025474548e-01
    z[0,1,4]  R135      1.5612085163593292e-01
    z[0,1,4]  R136      1.6943825408816338e-02
    z[0,1,4]  R137      -9.3334801495075226e-03
    z[0,1,4]  R138      1.4701751992106438e-02
    z[0,1,4]  R139      2.4286296218633652e-02
    z[0,1,4]  R140      6.5779253840446472e-02
    z[0,1,4]  R141      6.7274391651153564e-02
    z[0,1,4]  R142      -5.7650838047266006e-02
    z[0,1,4]  R143      2.0311267673969269e-01
    z[0,1,4]  R144      2.9101410508155823e-01
    z[0,1,4]  R145      2.6428506243973970e-03
    z[0,1,4]  R146      2.0727189257740974e-02
    z[0,1,4]  R147      4.8381105065345764e-01
    z[0,1,4]  R148      2.1485836803913116e-01
    z[0,1,4]  R149      1.8651841580867767e-01
    z[0,1,4]  R150      6.1027181148529053e-01
    z[0,1,4]  R151      2.7737993001937866e-01
    z[0,1,4]  R152      3.2691791653633118e-01
    z[0,1,4]  R153      -3.2753947377204895e-01
    z[0,1,4]  R154      -1.5371769666671753e-01
    z[0,1,4]  R155      1.7633976042270660e-01
    z[0,1,4]  R156      1.0239803791046143e-01
    z[0,1,4]  R157      2.8421280905604362e-02
    z[0,1,4]  R158      -1.8215529620647430e-02
    z[0,1,4]  R159      4.5270342379808426e-02
    z[0,1,4]  R160      -2.9345223307609558e-01
    z[0,1,4]  R161      -9.8966039717197418e-02
    z[0,1,4]  R162      5.8230036497116089e-01
    z[0,1,4]  R163      -7.7445581555366516e-02
    z[0,1,4]  R164      5.4957754909992218e-02
    z[0,1,4]  R165      0.0887366533279419
    z[0,1,4]  R166      1.2271800637245178e-01
    z[0,1,4]  R167      1.7630773782730103e-01
    z[0,1,4]  R168      -2.7799794077873230e-01
    z[0,1,4]  R169      -2.6498362421989441e-01
    z[0,1,4]  R170      4.8734968900680542e-01
    z[0,1,4]  R171      2.7661731839179993e-01
    z[0,1,4]  R172      -3.4113430976867676e-01
    z[0,1,4]  R173      0.190584197640419
    z[0,1,4]  R174      4.2454391717910767e-01
    z[0,1,4]  R175      6.2954194843769073e-02
    z[0,1,4]  R176      5.1860720850527287e-03
    z[0,1,4]  R177      -4.0332680940628052e-01
    z[0,1,4]  R178      -2.6774457097053528e-01
    z[0,1,4]  R179      4.1753351688385010e-01
    z[0,1,4]  R180      2.6212513446807861e-01
    z[0,1,4]  R181      -1.9029390811920166e-01
    z[0,1,4]  R182      -1.3608361780643463e-01
    z[0,1,4]  R183      -6.1558857560157776e-02
    z[0,1,4]  R184      -6.4338847994804382e-02
    z[0,1,4]  R185      5.0951063632965088e-01
    z[0,1,4]  R186      4.8818126320838928e-01
    z[0,1,4]  R187      2.8009146451950073e-01
    z[0,1,4]  R188      1.1476716957986355e-02
    z[0,1,4]  R189      -1.6288541257381439e-01
    z[0,1,4]  R190      -2.3661302030086517e-01
    z[0,1,4]  R191      -2.9888426885008812e-02
    z[0,1,4]  R192      -5.2529531717300415e-01
    z[0,1,4]  R193      1.1386800557374954e-01
    z[0,1,4]  R194      -2.6716282963752747e-01
    z[0,1,4]  R195      2.3903135955333710e-01
    z[0,1,4]  R196      1.6486936807632446e-01
    z[0,1,4]  R197      5.1504410803318024e-02
    z[0,1,4]  R198      1.4756634831428528e-01
    z[0,1,4]  R199      1.8596661090850830e-01
    z[0,1,4]  R200      1.2414073944091797e-01
    z[0,1,4]  R201      -4.9323442578315735e-01
    z[0,1,4]  R202      3.7036576867103577e-01
    z[0,1,4]  R203      -2.0263580977916718e-01
    z[0,1,4]  R204      0.294387549161911
    z[0,1,4]  R205      2.8524341061711311e-02
    z[0,1,4]  R206      -7.0917648077011108e-01
    z[0,1,4]  R207      1.6378301382064819e-01
    z[0,1,4]  R208      -2.4107404053211212e-01
    z[0,1,4]  R209      -0.0662151351571083
    z[0,1,4]  R210      -2.0259568095207214e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R57       -1
    z[0,1,5]  R58       1
    z[0,1,5]  R61       -5.0445652008056641e-01
    z[0,1,5]  R62       -7.6856710016727448e-02
    z[0,1,5]  R63       2.5028528645634651e-02
    z[0,1,5]  R64       -3.2930124551057816e-02
    z[0,1,5]  R65       -1.1862007528543472e-01
    z[0,1,5]  R66       2.8669700026512146e-01
    z[0,1,5]  R67       8.7456069886684418e-03
    z[0,1,5]  R68       9.1848298907279968e-02
    z[0,1,5]  R69       3.6754995584487915e-01
    z[0,1,5]  R70       2.0405404269695282e-01
    z[0,1,5]  R71       0.280277818441391
    z[0,1,5]  R72       -2.3130537569522858e-01
    z[0,1,5]  R73       3.6788681149482727e-01
    z[0,1,5]  R74       -3.6726880073547363e-01
    z[0,1,5]  R75       2.8330111503601074e-01
    z[0,1,5]  R76       -4.9175322055816650e-02
    z[0,1,5]  R77       -4.5591026544570923e-02
    z[0,1,5]  R78       3.1311208009719849e-01
    z[0,1,5]  R79       4.0186995267868042e-01
    z[0,1,5]  R80       -1.1770709417760372e-02
    z[0,1,5]  R81       3.1503564119338989e-01
    z[0,1,5]  R82       2.5389587879180908e-01
    z[0,1,5]  R83       7.6005801558494568e-02
    z[0,1,5]  R84       -1.4338185079395771e-02
    z[0,1,5]  R85       1.1591343581676483e-01
    z[0,1,5]  R86       -6.0779560357332230e-02
    z[0,1,5]  R87       2.6166474819183350e-01
    z[0,1,5]  R88       3.6587905883789062e-01
    z[0,1,5]  R89       1.5322747826576233e-01
    z[0,1,5]  R90       -3.3494135737419128e-01
    z[0,1,5]  R91       -3.2431003451347351e-01
    z[0,1,5]  R92       -4.3392094969749451e-01
    z[0,1,5]  R93       1.3375861942768097e-01
    z[0,1,5]  R94       -6.6862389445304871e-02
    z[0,1,5]  R95       -4.9372907727956772e-02
    z[0,1,5]  R96       -2.2421722114086151e-01
    z[0,1,5]  R97       -3.4554848074913025e-01
    z[0,1,5]  R98       -9.1310754418373108e-02
    z[0,1,5]  R99       1.6689199209213257e-01
    z[0,1,5]  R100      1.0497282445430756e-01
    z[0,1,5]  R101      -2.2765980660915375e-01
    z[0,1,5]  R102      -2.7418437600135803e-01
    z[0,1,5]  R103      3.8546571135520935e-01
    z[0,1,5]  R104      8.5960216820240021e-02
    z[0,1,5]  R105      -3.0100712180137634e-01
    z[0,1,5]  R106      3.7864178419113159e-01
    z[0,1,5]  R107      4.0323731303215027e-01
    z[0,1,5]  R108      4.7610646486282349e-01
    z[0,1,5]  R109      -4.0040472149848938e-01
    z[0,1,5]  R110      -3.4990664571523666e-02
    z[0,1,5]  R111      -6.4122414588928223e-01
    z[0,1,5]  R112      7.6918698847293854e-02
    z[0,1,5]  R113      3.3405745029449463e-01
    z[0,1,5]  R114      -2.5700443983078003e-01
    z[0,1,5]  R115      1.7790308222174644e-02
    z[0,1,5]  R116      1.7716838419437408e-01
    z[0,1,5]  R117      4.1874179244041443e-01
    z[0,1,5]  R118      -5.2343491464853287e-02
    z[0,1,5]  R119      1.1070173233747482e-01
    z[0,1,5]  R120      1.1411818861961365e-01
    z[0,1,5]  R121      3.3873483538627625e-01
    z[0,1,5]  R122      1.2411311268806458e-01
    z[0,1,5]  R123      -4.6913441270589828e-02
    z[0,1,5]  R124      -4.4032388925552368e-01
    z[0,1,5]  R125      -0.530138373374939
    z[0,1,5]  R126      2.3358824849128723e-01
    z[0,1,5]  R127      4.1394233703613281e-01
    z[0,1,5]  R128      4.8824291676282883e-02
    z[0,1,5]  R129      -3.9712780714035034e-01
    z[0,1,5]  R130      2.7972424030303955e-01
    z[0,1,5]  R131      3.5715565085411072e-01
    z[0,1,5]  R132      -1.5061445534229279e-01
    z[0,1,5]  R133      -8.1352427601814270e-02
    z[0,1,5]  R134      -1.8826331198215485e-01
    z[0,1,5]  R135      -1.8314327299594879e-01
    z[0,1,5]  R136      2.1702989935874939e-02
    z[0,1,5]  R137      -2.7365726232528687e-01
    z[0,1,5]  R138      1.4367893338203430e-01
    z[0,1,5]  R139      -2.9355597496032715e-01
    z[0,1,5]  R140      -1.6940365731716156e-01
    z[0,1,5]  R141      2.3928731679916382e-01
    z[0,1,5]  R142      -2.8580215573310852e-01
    z[0,1,5]  R143      -6.6587787866592407e-01
    z[0,1,5]  R144      -5.1513540744781494e-01
    z[0,1,5]  R145      2.9050523042678833e-01
    z[0,1,5]  R146      -5.2687561511993408e-01
    z[0,1,5]  R147      -7.1248096227645874e-01
    z[0,1,5]  R148      -3.8606736063957214e-01
    z[0,1,5]  R149      1.8828584253787994e-01
    z[0,1,5]  R150      -3.4893444180488586e-01
    z[0,1,5]  R151      2.3667345941066742e-01
    z[0,1,5]  R152      -3.8476511836051941e-01
    z[0,1,5]  R153      -6.4561265707015991e-01
    z[0,1,5]  R154      -1.8605917692184448e-01
    z[0,1,5]  R155      7.7510738372802734e-01
    z[0,1,5]  R156      -8.8310331106185913e-02
    z[0,1,5]  R157      -3.1413757801055908e-01
    z[0,1,5]  R158      4.4666835665702820e-01
    z[0,1,5]  R159      3.6467710137367249e-01
    z[0,1,5]  R160      -3.1655681133270264e-01
    z[0,1,5]  R161      2.3101146519184113e-01
    z[0,1,5]  R162      -2.2347655892372131e-01
    z[0,1,5]  R163      -2.3387621343135834e-01
    z[0,1,5]  R164      -4.4238799810409546e-01
    z[0,1,5]  R165      1.2042701244354248e-02
    z[0,1,5]  R166      0.0900174155831337
    z[0,1,5]  R167      -2.4764549732208252e-01
    z[0,1,5]  R168      -5.9273451566696167e-01
    z[0,1,5]  R169      2.1468596160411835e-01
    z[0,1,5]  R170      2.5821685791015625e-02
    z[0,1,5]  R171      4.2101528495550156e-02
    z[0,1,5]  R172      -1.9953294098377228e-01
    z[0,1,5]  R173      -3.8285022974014282e-01
    z[0,1,5]  R174      -3.0303534865379333e-01
    z[0,1,5]  R175      -2.1895058453083038e-01
    z[0,1,5]  R176      -1.7859362065792084e-01
    z[0,1,5]  R177      -1.2226261198520660e-01
    z[0,1,5]  R178      8.4042645990848541e-02
    z[0,1,5]  R179      4.6469278633594513e-02
    z[0,1,5]  R180      -2.3661652207374573e-01
    z[0,1,5]  R181      5.3901232779026031e-02
    z[0,1,5]  R182      -2.5268737226724625e-02
    z[0,1,5]  R183      1.1423484981060028e-01
    z[0,1,5]  R184      9.2856295406818390e-02
    z[0,1,5]  R185      6.0295450687408447e-01
    z[0,1,5]  R186      5.0113433599472046e-01
    z[0,1,5]  R187      1.6589875519275665e-01
    z[0,1,5]  R188      2.8435957431793213e-01
    z[0,1,5]  R189      3.1393593549728394e-01
    z[0,1,5]  R190      2.0554584264755249e-01
    z[0,1,5]  R191      5.3236478567123413e-01
    z[0,1,5]  R192      -3.4749662876129150e-01
    z[0,1,5]  R193      -4.1468435525894165e-01
    z[0,1,5]  R194      3.0284056067466736e-01
    z[0,1,5]  R195      0.639694094657898
    z[0,1,5]  R196      0.0696791484951973
    z[0,1,5]  R197      1.8360999226570129e-01
    z[0,1,5]  R198      -1.0117681324481964e-01
    z[0,1,5]  R199      7.0125319063663483e-02
    z[0,1,5]  R200      1.1617124080657959e-01
    z[0,1,5]  R201      4.4329819083213806e-01
    z[0,1,5]  R202      -5.5636620521545410e-01
    z[0,1,5]  R203      -1.4024247229099274e-01
    z[0,1,5]  R204      4.0735453367233276e-01
    z[0,1,5]  R205      -1.9044749438762665e-01
    z[0,1,5]  R206      -3.1642335653305054e-01
    z[0,1,5]  R207      -1.4758719503879547e-01
    z[0,1,5]  R208      6.5971814095973969e-02
    z[0,1,5]  R209      -4.5893844217061996e-02
    z[0,1,5]  R210      8.5568435490131378e-02
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R59       -1
    z[0,1,6]  R60       1
    z[0,1,6]  R61       1.8866769969463348e-01
    z[0,1,6]  R62       -4.9333442002534866e-02
    z[0,1,6]  R63       0.395723819732666
    z[0,1,6]  R64       4.1688024997711182e-02
    z[0,1,6]  R65       -7.4217252433300018e-02
    z[0,1,6]  R66       -2.4170126020908356e-01
    z[0,1,6]  R67       -1.0254694148898125e-02
    z[0,1,6]  R68       0.088455431163311
    z[0,1,6]  R69       -5.0630939006805420e-01
    z[0,1,6]  R70       7.0999123156070709e-02
    z[0,1,6]  R71       -3.2858546823263168e-02
    z[0,1,6]  R72       8.8604830205440521e-02
    z[0,1,6]  R73       4.9064168706536293e-03
    z[0,1,6]  R74       2.8341269493103027e-01
    z[0,1,6]  R75       -1.8354374170303345e-01
    z[0,1,6]  R76       4.4690284132957458e-01
    z[0,1,6]  R77       4.0696394443511963e-01
    z[0,1,6]  R78       -4.0506433695554733e-02
    z[0,1,6]  R79       3.2720208168029785e-01
    z[0,1,6]  R80       1.0336861759424210e-01
    z[0,1,6]  R81       -1.9738449156284332e-01
    z[0,1,6]  R82       -3.4226831048727036e-02
    z[0,1,6]  R83       4.3831002712249756e-01
    z[0,1,6]  R84       -1.2033692747354507e-01
    z[0,1,6]  R85       -3.2512211799621582e-01
    z[0,1,6]  R86       -4.3581396341323853e-01
    z[0,1,6]  R87       2.4558633565902710e-01
    z[0,1,6]  R88       4.3737164139747620e-01
    z[0,1,6]  R89       -4.1613289713859558e-01
    z[0,1,6]  R90       -1.3238739967346191e-01
    z[0,1,6]  R91       -1.2371501326560974e-01
    z[0,1,6]  R92       4.7032165527343750e-01
    z[0,1,6]  R93       -2.1344347298145294e-01
    z[0,1,6]  R94       -1.2281096726655960e-01
    z[0,1,6]  R95       3.1134957075119019e-01
    z[0,1,6]  R96       4.4350346922874451e-01
    z[0,1,6]  R97       -1.6316774487495422e-01
    z[0,1,6]  R98       1.5427152812480927e-01
    z[0,1,6]  R99       2.6543816924095154e-01
    z[0,1,6]  R100      -1.0702729225158691e-01
    z[0,1,6]  R101      5.6285685300827026e-01
    z[0,1,6]  R102      2.3148207366466522e-01
    z[0,1,6]  R103      -1.2104640156030655e-01
    z[0,1,6]  R104      -0.295296311378479
    z[0,1,6]  R105      -1.9183368980884552e-01
    z[0,1,6]  R106      1.1599563807249069e-01
    z[0,1,6]  R107      0.0747029259800911
    z[0,1,6]  R108      -2.4605879187583923e-01
    z[0,1,6]  R109      2.8579438105225563e-02
    z[0,1,6]  R110      0.0792076513171196
    z[0,1,6]  R111      -2.3442563414573669e-01
    z[0,1,6]  R112      -2.8481602668762207e-01
    z[0,1,6]  R113      8.9047178626060486e-03
    z[0,1,6]  R114      3.2759314775466919e-01
    z[0,1,6]  R115      -1.4143096632324159e-04
    z[0,1,6]  R116      1.8598626554012299e-01
    z[0,1,6]  R117      -2.0224186778068542e-01
    z[0,1,6]  R118      -2.2372610867023468e-01
    z[0,1,6]  R119      4.0545615553855896e-01
    z[0,1,6]  R120      -9.1858208179473877e-02
    z[0,1,6]  R121      2.9033901169896126e-02
    z[0,1,6]  R122      4.0269076824188232e-01
    z[0,1,6]  R123      -2.5250702165067196e-03
    z[0,1,6]  R124      4.6675089001655579e-01
    z[0,1,6]  R125      3.4391921758651733e-01
    z[0,1,6]  R126      -3.5764020681381226e-01
    z[0,1,6]  R127      -3.6626964807510376e-01
    z[0,1,6]  R128      4.8786246776580811e-01
    z[0,1,6]  R129      -2.3331686854362488e-01
    z[0,1,6]  R130      -1.6823986172676086e-01
    z[0,1,6]  R131      -6.6091649234294891e-02
    z[0,1,6]  R132      -3.2455231994390488e-02
    z[0,1,6]  R133      2.8705042600631714e-01
    z[0,1,6]  R134      -2.2222459316253662e-01
    z[0,1,6]  R135      -1.4257307350635529e-01
    z[0,1,6]  R136      -0.0975661426782608
    z[0,1,6]  R137      1.2624484300613403e-01
    z[0,1,6]  R138      1.5527017414569855e-01
    z[0,1,6]  R139      0.258098304271698
    z[0,1,6]  R140      3.3507046103477478e-01
    z[0,1,6]  R141      5.1464933156967163e-01
    z[0,1,6]  R142      2.4968293309211731e-01
    z[0,1,6]  R143      9.3214483931660652e-03
    z[0,1,6]  R144      3.3698195219039917e-01
    z[0,1,6]  R145      3.4815050661563873e-02
    z[0,1,6]  R146      -1.7313238978385925e-01
    z[0,1,6]  R147      -2.4636309593915939e-02
    z[0,1,6]  R148      -2.0133270323276520e-01
    z[0,1,6]  R149      7.3934487998485565e-02
    z[0,1,6]  R150      -1.8456031382083893e-01
    z[0,1,6]  R151      -2.1386298537254333e-01
    z[0,1,6]  R152      1.8342237174510956e-01
    z[0,1,6]  R153      4.3450701236724854e-01
    z[0,1,6]  R154      1.5843538939952850e-01
    z[0,1,6]  R155      2.4175839498639107e-02
    z[0,1,6]  R156      -7.6298236846923828e-01
    z[0,1,6]  R157      -6.7152345180511475e-01
    z[0,1,6]  R158      -1.6806390881538391e-01
    z[0,1,6]  R159      1.2550490908324718e-02
    z[0,1,6]  R160      -2.9177930951118469e-01
    z[0,1,6]  R161      1.5630675852298737e-01
    z[0,1,6]  R162      3.8100153207778931e-01
    z[0,1,6]  R163      -0.298606812953949
    z[0,1,6]  R164      -6.7481301724910736e-02
    z[0,1,6]  R165      4.2612645030021667e-01
    z[0,1,6]  R166      -7.9563081264495850e-01
    z[0,1,6]  R167      -8.4395474195480347e-01
    z[0,1,6]  R168      -4.5136049389839172e-01
    z[0,1,6]  R169      7.3453408479690552e-01
    z[0,1,6]  R170      -4.8163527250289917e-01
    z[0,1,6]  R171      4.9647635221481323e-01
    z[0,1,6]  R172      -2.4195753037929535e-01
    z[0,1,6]  R173      -6.6734445095062256e-01
    z[0,1,6]  R174      -9.9828787147998810e-02
    z[0,1,6]  R175      -1.2361995875835419e-01
    z[0,1,6]  R176      -5.6591433286666870e-01
    z[0,1,6]  R177      -4.8089297488331795e-03
    z[0,1,6]  R178      7.5726640224456787e-01
    z[0,1,6]  R179      -0.248578742146492
    z[0,1,6]  R180      4.6707659959793091e-02
    z[0,1,6]  R181      -1.9116099178791046e-01
    z[0,1,6]  R182      -2.8267496824264526e-01
    z[0,1,6]  R183      1.1737269163131714e-01
    z[0,1,6]  R184      -1.6705824434757233e-01
    z[0,1,6]  R185      -2.3493103682994843e-01
    z[0,1,6]  R186      -3.7678858637809753e-01
    z[0,1,6]  R187      4.0877026319503784e-01
    z[0,1,6]  R188      -1.1880979686975479e-01
    z[0,1,6]  R189      5.8983471244573593e-02
    z[0,1,6]  R190      -5.6204688549041748e-01
    z[0,1,6]  R191      3.2145938277244568e-01
    z[0,1,6]  R192      -2.1052356064319611e-01
    z[0,1,6]  R193      -9.2820391058921814e-02
    z[0,1,6]  R194      -2.5066909193992615e-01
    z[0,1,6]  R195      2.9441300034523010e-01
    z[0,1,6]  R196      -6.3016250729560852e-02
    z[0,1,6]  R197      -4.6255189180374146e-01
    z[0,1,6]  R198      -2.6806166395545006e-02
    z[0,1,6]  R199      -1.4414816163480282e-02
    z[0,1,6]  R200      1.2441301345825195e-01
    z[0,1,6]  R201      7.5026132166385651e-02
    z[0,1,6]  R202      2.2135600447654724e-01
    z[0,1,6]  R203      -6.8161681294441223e-02
    z[0,1,6]  R204      1.3272415101528168e-01
    z[0,1,6]  R205      -5.1599580049514771e-01
    z[0,1,6]  R206      1.3522616028785706e-01
    z[0,1,6]  R207      3.6488026380538940e-02
    z[0,1,6]  R208      -3.7991631776094437e-02
    z[0,1,6]  R209      -1.1893206089735031e-01
    z[0,1,6]  R210      1.5725551545619965e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R211      -1
    z[1,0,0]  R212      1
    z[1,0,0]  R225      4.4048145413398743e-01
    z[1,0,0]  R226      4.4716534018516541e-01
    z[1,0,0]  R227      3.1553784012794495e-01
    z[1,0,0]  R228      2.1296481788158417e-01
    z[1,0,0]  R229      2.0398156344890594e-01
    z[1,0,0]  R230      1.4513950049877167e-01
    z[1,0,0]  R231      4.2035266757011414e-01
    z[1,0,0]  R232      1.8896244466304779e-01
    z[1,0,0]  R233      2.6948067545890808e-01
    z[1,0,0]  R234      5.3773349523544312e-01
    z[1,0,0]  R235      -8.8005030155181885e-01
    z[1,0,0]  R236      -8.4766268730163574e-01
    z[1,0,0]  R237      -8.9489394426345825e-01
    z[1,0,0]  R238      5.6491714715957642e-01
    z[1,0,0]  R239      6.4999121427536011e-01
    z[1,0,0]  R240      5.7755821943283081e-01
    z[1,0,0]  R241      1.8908669054508209e-01
    z[1,0,0]  R242      6.9569748640060425e-01
    z[1,0,0]  R243      5.9627151489257812e-01
    z[1,0,0]  R244      5.2757942676544189e-01
    z[1,0,0]  R245      -3.5752275586128235e-01
    z[1,0,0]  R246      -2.9642897844314575e-01
    z[1,0,0]  R247      -6.3600605726242065e-01
    z[1,0,0]  R248      -3.5773396492004395e-01
    z[1,0,0]  R249      -1.8340660631656647e-01
    z[1,0,0]  R250      -3.7775182723999023e-01
    z[1,0,0]  R251      -3.4659394621849060e-01
    z[1,0,0]  R252      6.2411874532699585e-02
    z[1,0,0]  R253      4.5564625412225723e-02
    z[1,0,0]  R254      -5.1198780536651611e-01
    z[1,0,0]  R255      -4.8201125860214233e-01
    z[1,0,0]  R256      -5.8650255203247070e-01
    z[1,0,0]  R257      -4.3368390202522278e-01
    z[1,0,0]  R258      -7.5530534982681274e-01
    z[1,0,0]  R259      0.0590699128806591
    z[1,0,0]  R260      -3.6986050009727478e-01
    z[1,0,0]  R261      1.0634465515613556e-01
    z[1,0,0]  R262      4.4743397831916809e-01
    z[1,0,0]  R263      1.4682547748088837e-01
    z[1,0,0]  R264      0.00492557417601347
    z[1,0,0]  R265      -4.5591101050376892e-01
    z[1,0,0]  R266      -6.2477695941925049e-01
    z[1,0,0]  R267      1.2044054269790649e-01
    z[1,0,0]  R268      2.5214740633964539e-01
    z[1,0,0]  R269      1.6487506031990051e-01
    z[1,0,0]  R270      -3.5710880160331726e-01
    z[1,0,0]  R271      -2.3909138143062592e-01
    z[1,0,0]  R272      -4.0107741951942444e-01
    z[1,0,0]  R273      -2.8470501303672791e-01
    z[1,0,0]  R274      6.0285080224275589e-02
    z[1,0,0]  R275      -4.5614802837371826e-01
    z[1,0,0]  R276      1.6883884370326996e-01
    z[1,0,0]  R277      -5.7301348447799683e-01
    z[1,0,0]  R278      -6.5560430288314819e-01
    z[1,0,0]  R279      4.6026740223169327e-02
    z[1,0,0]  R280      5.9459650516510010e-01
    z[1,0,0]  R281      -8.1936977803707123e-03
    z[1,0,0]  R282      -2.8132265806198120e-01
    z[1,0,0]  R283      -3.0873646959662437e-02
    z[1,0,0]  R284      6.2525354325771332e-02
    z[1,0,0]  R285      -6.5801465511322021e-01
    z[1,0,0]  R286      3.9888685941696167e-01
    z[1,0,0]  R287      -7.6452434062957764e-01
    z[1,0,0]  R288      7.1891725063323975e-01
    z[1,0,0]  R289      1.0193198919296265e-01
    z[1,0,0]  R290      4.0106898546218872e-01
    z[1,0,0]  R291      -1.0802744328975677e-01
    z[1,0,0]  R292      -2.2934605181217194e-01
    z[1,0,0]  R293      -2.3645068705081940e-01
    z[1,0,0]  R294      -6.9124542176723480e-02
    z[1,0,0]  R295      -6.0876989364624023e-01
    z[1,0,0]  R296      -4.0712639689445496e-01
    z[1,0,0]  R297      -1.0106655955314636e-01
    z[1,0,0]  R298      -1.8882115185260773e-01
    z[1,0,0]  R299      3.2330492138862610e-01
    z[1,0,0]  R300      -1.0135262459516525e-01
    z[1,0,0]  R301      -2.3631669580936432e-02
    z[1,0,0]  R302      2.9480382800102234e-02
    z[1,0,0]  R303      -2.4920843541622162e-01
    z[1,0,0]  R304      -1.4453461766242981e-01
    z[1,0,0]  R305      -6.4922505617141724e-01
    z[1,0,0]  R306      -6.0427713394165039e-01
    z[1,0,0]  R307      7.9296268522739410e-02
    z[1,0,0]  R308      5.6043070554733276e-01
    z[1,0,0]  R309      -5.7753247022628784e-01
    z[1,0,0]  R310      1.8766084313392639e-01
    z[1,0,0]  R311      8.5992045700550079e-02
    z[1,0,0]  R312      2.0371274650096893e-01
    z[1,0,0]  R313      1.2180276960134506e-01
    z[1,0,0]  R314      2.2687834501266479e-01
    z[1,0,0]  R315      -2.7911195158958435e-01
    z[1,0,0]  R316      -2.5956231355667114e-01
    z[1,0,0]  R317      -0.200189471244812
    z[1,0,0]  R318      9.5063948631286621e-01
    z[1,0,0]  R319      5.5172234773635864e-01
    z[1,0,0]  R320      8.2528567314147949e-01
    z[1,0,0]  R321      8.0844157934188843e-01
    z[1,0,0]  R322      8.0433422327041626e-01
    z[1,0,0]  R323      -2.6695212721824646e-01
    z[1,0,0]  R324      4.4909101724624634e-01
    z[1,0,0]  R325      -6.7703330516815186e-01
    z[1,0,0]  R326      -8.4879899024963379e-01
    z[1,0,0]  R327      -7.9707098007202148e-01
    z[1,0,0]  R328      -6.5170717239379883e-01
    z[1,0,0]  R329      -5.3997147083282471e-01
    z[1,0,0]  R330      -5.1643681526184082e-01
    z[1,0,0]  R331      -4.9135014414787292e-01
    z[1,0,0]  R332      -7.3041713237762451e-01
    z[1,0,0]  R333      -4.2066127061843872e-01
    z[1,0,0]  R334      -0.335271954536438
    z[1,0,0]  R335      -7.8593236207962036e-01
    z[1,0,0]  R336      -4.8112070560455322e-01
    z[1,0,0]  R337      -8.0663490295410156e-01
    z[1,0,0]  R338      -4.5488181710243225e-01
    z[1,0,0]  R339      -3.4604361653327942e-01
    z[1,0,0]  R340      -0.739958643913269
    z[1,0,0]  R341      -5.4418420791625977e-01
    z[1,0,0]  R342      -3.8419404625892639e-01
    z[1,0,0]  R343      -3.8750213384628296e-01
    z[1,0,0]  R344      -1.6495670378208160e-01
    z[1,0,0]  R345      -6.4012104272842407e-01
    z[1,0,0]  R346      -4.5631998777389526e-01
    z[1,0,0]  R347      -6.9034153223037720e-01
    z[1,0,0]  R348      -4.7739055752754211e-01
    z[1,0,0]  R349      -3.3747208118438721e-01
    z[1,0,0]  R350      0.616935133934021
    z[1,0,0]  R351      -2.9487824440002441e-01
    z[1,0,0]  R352      -3.2894019037485123e-02
    z[1,0,0]  R353      2.6451559737324715e-02
    z[1,0,0]  R354      -5.9227943420410156e-02
    z[1,0,0]  R355      -3.2220444083213806e-01
    z[1,0,0]  R356      -4.7876590490341187e-01
    z[1,0,0]  R357      -2.2320681810379028e-01
    z[1,0,0]  R358      -3.1698886305093765e-02
    z[1,0,0]  R359      4.0914884209632874e-01
    z[1,0,0]  R360      2.0863594114780426e-01
    z[1,0,0]  R361      4.6707686781883240e-01
    z[1,0,0]  R362      5.0943013280630112e-02
    z[1,0,0]  R363      3.4773871302604675e-01
    z[1,0,0]  R364      8.9614562690258026e-02
    z[1,0,0]  R365      -0.302606999874115
    z[1,0,0]  R366      -8.2195393741130829e-02
    z[1,0,0]  R367      -1.9792994856834412e-01
    z[1,0,0]  R368      -2.2379927337169647e-01
    z[1,0,0]  R369      0.0955568253993988
    z[1,0,0]  R370      5.4114109277725220e-01
    z[1,0,0]  R371      5.3917460143566132e-02
    z[1,0,0]  R372      3.4159538149833679e-01
    z[1,0,0]  R373      4.7162267565727234e-01
    z[1,0,0]  R374      2.4069221317768097e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R213      -1
    z[1,0,1]  R214      1
    z[1,0,1]  R225      7.6852989196777344e-01
    z[1,0,1]  R226      7.1061855554580688e-01
    z[1,0,1]  R227      6.9127148389816284e-01
    z[1,0,1]  R228      6.7748028039932251e-01
    z[1,0,1]  R229      6.6225379705429077e-01
    z[1,0,1]  R230      0.657947301864624
    z[1,0,1]  R231      6.5257954597473145e-01
    z[1,0,1]  R232      6.5442794561386108e-01
    z[1,0,1]  R233      6.3109076023101807e-01
    z[1,0,1]  R234      6.2716007232666016e-01
    z[1,0,1]  R235      1.3539300300180912e-02
    z[1,0,1]  R236      -0.0493953637778759
    z[1,0,1]  R237      -4.1284445673227310e-02
    z[1,0,1]  R238      -5.1278859376907349e-01
    z[1,0,1]  R239      -5.4661726951599121e-01
    z[1,0,1]  R240      -4.9537131190299988e-01
    z[1,0,1]  R241      -5.5065184831619263e-01
    z[1,0,1]  R242      -4.6201971173286438e-01
    z[1,0,1]  R243      -6.0528641939163208e-01
    z[1,0,1]  R244      -3.8753968477249146e-01
    z[1,0,1]  R245      2.2777329385280609e-01
    z[1,0,1]  R246      3.5794261097908020e-01
    z[1,0,1]  R247      -0.0707663968205452
    z[1,0,1]  R248      2.1073617041110992e-01
    z[1,0,1]  R249      2.3412954807281494e-01
    z[1,0,1]  R250      2.5247669219970703e-01
    z[1,0,1]  R251      1.3208749890327454e-01
    z[1,0,1]  R252      6.7550706863403320e-01
    z[1,0,1]  R253      6.7064303159713745e-01
    z[1,0,1]  R254      -4.9852974712848663e-02
    z[1,0,1]  R255      4.2516711354255676e-01
    z[1,0,1]  R256      2.7613270282745361e-01
    z[1,0,1]  R257      2.8282597661018372e-01
    z[1,0,1]  R258      4.4181060791015625e-01
    z[1,0,1]  R259      -1.9234298169612885e-01
    z[1,0,1]  R260      1.0171489417552948e-01
    z[1,0,1]  R261      5.7744336128234863e-01
    z[1,0,1]  R262      -5.2219372987747192e-01
    z[1,0,1]  R263      -3.1241990625858307e-02
    z[1,0,1]  R264      5.3227978944778442e-01
    z[1,0,1]  R265      3.8184702396392822e-01
    z[1,0,1]  R266      -2.7537789195775986e-02
    z[1,0,1]  R267      8.5406959056854248e-01
    z[1,0,1]  R268      8.1836843490600586e-01
    z[1,0,1]  R269      2.6267403364181519e-01
    z[1,0,1]  R270      1.3385763764381409e-01
    z[1,0,1]  R271      2.5609949231147766e-01
    z[1,0,1]  R272      8.2399033010005951e-02
    z[1,0,1]  R273      2.4601301550865173e-01
    z[1,0,1]  R274      6.1969733238220215e-01
    z[1,0,1]  R275      4.0898019075393677e-01
    z[1,0,1]  R276      6.4176046848297119e-01
    z[1,0,1]  R277      1.0565433651208878e-01
    z[1,0,1]  R278      1.3106757402420044e-01
    z[1,0,1]  R279      9.3674689531326294e-01
    z[1,0,1]  R280      5.0609749555587769e-01
    z[1,0,1]  R281      4.6355494856834412e-01
    z[1,0,1]  R282      0.284940242767334
    z[1,0,1]  R283      2.8398683294653893e-02
    z[1,0,1]  R284      2.4847318232059479e-01
    z[1,0,1]  R285      2.6605013012886047e-01
    z[1,0,1]  R286      8.0469900369644165e-01
    z[1,0,1]  R287      4.4193947315216064e-01
    z[1,0,1]  R288      -5.1152259111404419e-01
    z[1,0,1]  R289      -4.2723175883293152e-01
    z[1,0,1]  R290      -4.2270788550376892e-01
    z[1,0,1]  R291      -2.3982043564319611e-01
    z[1,0,1]  R292      -9.1337114572525024e-01
    z[1,0,1]  R293      -8.7942677736282349e-01
    z[1,0,1]  R294      -2.8539735078811646e-01
    z[1,0,1]  R295      3.4915563464164734e-01
    z[1,0,1]  R296      3.8095399737358093e-01
    z[1,0,1]  R297      5.5673009157180786e-01
    z[1,0,1]  R298      -1.8500310182571411e-01
    z[1,0,1]  R299      -3.9021816849708557e-01
    z[1,0,1]  R300      3.8227722048759460e-02
    z[1,0,1]  R301      -2.0226265490055084e-01
    z[1,0,1]  R302      5.9279982000589371e-02
    z[1,0,1]  R303      -0.926781177520752
    z[1,0,1]  R304      -7.5965744256973267e-01
    z[1,0,1]  R305      1.5500506758689880e-01
    z[1,0,1]  R306      7.0526483468711376e-03
    z[1,0,1]  R307      9.5337331295013428e-01
    z[1,0,1]  R308      -6.2721198797225952e-01
    z[1,0,1]  R309      3.7929084897041321e-01
    z[1,0,1]  R310      -1.0878720879554749e-01
    z[1,0,1]  R311      -3.3713793754577637e-01
    z[1,0,1]  R312      -3.9753583073616028e-01
    z[1,0,1]  R313      -0.273084819316864
    z[1,0,1]  R314      -3.3717691898345947e-01
    z[1,0,1]  R315      5.7454162836074829e-01
    z[1,0,1]  R316      1.6744308173656464e-01
    z[1,0,1]  R317      3.1051808595657349e-01
    z[1,0,1]  R318      1.8348847329616547e-01
    z[1,0,1]  R319      7.3893499374389648e-01
    z[1,0,1]  R320      1.7857621610164642e-01
    z[1,0,1]  R321      5.3061944246292114e-01
    z[1,0,1]  R322      4.6047952771186829e-01
    z[1,0,1]  R323      4.5100402832031250e-01
    z[1,0,1]  R324      0.596885621547699
    z[1,0,1]  R325      -3.4250352531671524e-02
    z[1,0,1]  R326      -2.0875754952430725e-01
    z[1,0,1]  R327      2.0808492600917816e-01
    z[1,0,1]  R328      -4.1754089295864105e-02
    z[1,0,1]  R329      5.3702068328857422e-01
    z[1,0,1]  R330      -3.1882904469966888e-02
    z[1,0,1]  R331      -4.5007994771003723e-01
    z[1,0,1]  R332      -5.1013922691345215e-01
    z[1,0,1]  R333      -2.0662444829940796e-01
    z[1,0,1]  R334      -6.6670411825180054e-01
    z[1,0,1]  R335      4.5394363999366760e-01
    z[1,0,1]  R336      7.4497830867767334e-01
    z[1,0,1]  R337      2.1404880285263062e-01
    z[1,0,1]  R338      7.1047663688659668e-01
    z[1,0,1]  R339      6.4928478002548218e-01
    z[1,0,1]  R340      3.7441188097000122e-01
    z[1,0,1]  R341      1.0908488184213638e-02
    z[1,0,1]  R342      4.2736539244651794e-01
    z[1,0,1]  R343      4.4189310073852539e-01
    z[1,0,1]  R344      2.7838796377182007e-01
    z[1,0,1]  R345      8.7187774479389191e-02
    z[1,0,1]  R346      3.7865081429481506e-01
    z[1,0,1]  R347      -4.3377488851547241e-01
    z[1,0,1]  R348      -6.8070453405380249e-01
    z[1,0,1]  R349      -8.6769664287567139e-01
    z[1,0,1]  R350      2.1589897572994232e-01
    z[1,0,1]  R351      -5.0343447923660278e-01
    z[1,0,1]  R352      -7.4226856231689453e-01
    z[1,0,1]  R353      -9.0129858255386353e-01
    z[1,0,1]  R354      -5.6143432855606079e-01
    z[1,0,1]  R355      6.3973242044448853e-01
    z[1,0,1]  R356      2.6570373773574829e-01
    z[1,0,1]  R357      -7.6507246494293213e-01
    z[1,0,1]  R358      -5.2671676874160767e-01
    z[1,0,1]  R359      -5.2842015027999878e-01
    z[1,0,1]  R360      -4.0489968657493591e-01
    z[1,0,1]  R361      -4.1363832354545593e-01
    z[1,0,1]  R362      -2.0617979764938354e-01
    z[1,0,1]  R363      -5.0428098440170288e-01
    z[1,0,1]  R364      -0.28351891040802
    z[1,0,1]  R365      5.9813719987869263e-01
    z[1,0,1]  R366      -5.6944328546524048e-01
    z[1,0,1]  R367      -7.9107505083084106e-01
    z[1,0,1]  R368      -8.3547854423522949e-01
    z[1,0,1]  R369      -6.2728846073150635e-01
    z[1,0,1]  R370      -1.5642635524272919e-01
    z[1,0,1]  R371      -0.408250629901886
    z[1,0,1]  R372      1.0886962711811066e-01
    z[1,0,1]  R373      -6.0041254758834839e-01
    z[1,0,1]  R374      1.5060398727655411e-03
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R215      -1
    z[1,0,2]  R216      1
    z[1,0,2]  R225      1.9762471318244934e-01
    z[1,0,2]  R226      1.8094404041767120e-01
    z[1,0,2]  R227      1.7155742272734642e-02
    z[1,0,2]  R228      2.3242124915122986e-01
    z[1,0,2]  R229      2.0797017216682434e-01
    z[1,0,2]  R230      3.0362471938133240e-01
    z[1,0,2]  R231      1.5505865216255188e-01
    z[1,0,2]  R232      1.7621801793575287e-01
    z[1,0,2]  R233      1.8051068484783173e-01
    z[1,0,2]  R234      -1.3206172734498978e-02
    z[1,0,2]  R235      -6.9564029574394226e-02
    z[1,0,2]  R236      1.7230573296546936e-01
    z[1,0,2]  R237      1.7138895392417908e-01
    z[1,0,2]  R238      -1.4812509715557098e-01
    z[1,0,2]  R239      -1.6373504698276520e-01
    z[1,0,2]  R240      -2.1429817378520966e-01
    z[1,0,2]  R241      -2.5060099363327026e-01
    z[1,0,2]  R242      -6.6603772342205048e-02
    z[1,0,2]  R243      4.1931409388780594e-02
    z[1,0,2]  R244      -1.5611787140369415e-01
    z[1,0,2]  R245      2.7155104279518127e-01
    z[1,0,2]  R246      -1.2577632069587708e-01
    z[1,0,2]  R247      -2.7121728658676147e-01
    z[1,0,2]  R248      0.0661039724946022
    z[1,0,2]  R249      -5.5829749908298254e-04
    z[1,0,2]  R250      -1.6054630279541016e-01
    z[1,0,2]  R251      1.1115300655364990e-01
    z[1,0,2]  R252      -0.4558085501194
    z[1,0,2]  R253      -4.5450708270072937e-01
    z[1,0,2]  R254      6.2247227877378464e-02
    z[1,0,2]  R255      4.6318256855010986e-01
    z[1,0,2]  R256      4.2427086830139160e-01
    z[1,0,2]  R257      1.3735873997211456e-01
    z[1,0,2]  R258      -2.5027480721473694e-01
    z[1,0,2]  R259      1.4518241398036480e-02
    z[1,0,2]  R260      3.6463406682014465e-01
    z[1,0,2]  R261      -3.2373934984207153e-01
    z[1,0,2]  R262      4.8716405034065247e-01
    z[1,0,2]  R263      3.8003337383270264e-01
    z[1,0,2]  R264      -1.1138872057199478e-01
    z[1,0,2]  R265      6.1045867204666138e-01
    z[1,0,2]  R266      -1.4914770424365997e-01
    z[1,0,2]  R267      -3.2510453462600708e-01
    z[1,0,2]  R268      -2.3592798411846161e-01
    z[1,0,2]  R269      -3.6896771192550659e-01
    z[1,0,2]  R270      8.4914974868297577e-02
    z[1,0,2]  R271      2.3748025298118591e-01
    z[1,0,2]  R272      -4.6754304319620132e-02
    z[1,0,2]  R273      4.0193051099777222e-01
    z[1,0,2]  R274      -3.2748410105705261e-01
    z[1,0,2]  R275      3.2034772634506226e-01
    z[1,0,2]  R276      3.4528324007987976e-01
    z[1,0,2]  R277      -9.6078209578990936e-02
    z[1,0,2]  R278      -2.2535999119281769e-01
    z[1,0,2]  R279      -2.2950629889965057e-01
    z[1,0,2]  R280      -1.9488035142421722e-01
    z[1,0,2]  R281      -1.3908736407756805e-01
    z[1,0,2]  R282      3.8566029071807861e-01
    z[1,0,2]  R283      -1.7290504276752472e-01
    z[1,0,2]  R284      -5.4297423362731934e-01
    z[1,0,2]  R285      1.8496979773044586e-01
    z[1,0,2]  R286      -0.244472473859787
    z[1,0,2]  R287      -2.9634317755699158e-01
    z[1,0,2]  R288      3.2215365767478943e-01
    z[1,0,2]  R289      1.1727154999971390e-01
    z[1,0,2]  R290      5.3423233330249786e-02
    z[1,0,2]  R291      3.2155385613441467e-01
    z[1,0,2]  R292      1.3224214315414429e-01
    z[1,0,2]  R293      1.9594286382198334e-01
    z[1,0,2]  R294      2.3662203550338745e-01
    z[1,0,2]  R295      2.2422102093696594e-01
    z[1,0,2]  R296      4.1424378752708435e-01
    z[1,0,2]  R297      -4.9048945307731628e-01
    z[1,0,2]  R298      4.3830013275146484e-01
    z[1,0,2]  R299      0.417977511882782
    z[1,0,2]  R300      4.0899294614791870e-01
    z[1,0,2]  R301      2.4501444399356842e-01
    z[1,0,2]  R302      -1.8349802494049072e-01
    z[1,0,2]  R303      1.4926487207412720e-01
    z[1,0,2]  R304      3.8419011235237122e-01
    z[1,0,2]  R305      2.4462023377418518e-01
    z[1,0,2]  R306      -1.4788176119327545e-01
    z[1,0,2]  R307      -4.7778464853763580e-02
    z[1,0,2]  R308      1.4802455902099609e-01
    z[1,0,2]  R309      -4.2650622129440308e-01
    z[1,0,2]  R310      4.7915931791067123e-03
    z[1,0,2]  R311      -8.4596776962280273e-01
    z[1,0,2]  R312      -7.6929843425750732e-01
    z[1,0,2]  R313      -8.8198131322860718e-01
    z[1,0,2]  R314      -8.0463838577270508e-01
    z[1,0,2]  R315      1.5083377063274384e-01
    z[1,0,2]  R316      2.3986802995204926e-01
    z[1,0,2]  R317      -1.8829308450222015e-01
    z[1,0,2]  R318      2.4266245961189270e-01
    z[1,0,2]  R319      -3.3070594072341919e-01
    z[1,0,2]  R320      3.0206015706062317e-01
    z[1,0,2]  R321      -1.5245966613292694e-01
    z[1,0,2]  R322      1.9436698406934738e-02
    z[1,0,2]  R323      -3.4611273556947708e-02
    z[1,0,2]  R324      -5.8791655302047729e-01
    z[1,0,2]  R325      -6.1598002910614014e-01
    z[1,0,2]  R326      -3.5712572932243347e-01
    z[1,0,2]  R327      -2.3911079764366150e-01
    z[1,0,2]  R328      -3.2284760475158691e-01
    z[1,0,2]  R329      2.2259363532066345e-01
    z[1,0,2]  R330      -5.8785039186477661e-01
    z[1,0,2]  R331      -5.2049297094345093e-01
    z[1,0,2]  R332      -8.4991287440061569e-03
    z[1,0,2]  R333      -5.2151817083358765e-01
    z[1,0,2]  R334      5.2224820852279663e-01
    z[1,0,2]  R335      -4.9242395907640457e-02
    z[1,0,2]  R336      1.6663928329944611e-01
    z[1,0,2]  R337      2.8458821773529053e-01
    z[1,0,2]  R338      -0.265234112739563
    z[1,0,2]  R339      -2.2192781791090965e-02
    z[1,0,2]  R340      6.0554448515176773e-02
    z[1,0,2]  R341      2.0031755790114403e-02
    z[1,0,2]  R342      3.7380585074424744e-01
    z[1,0,2]  R343      5.7075881958007812e-01
    z[1,0,2]  R344      1.7242784798145294e-01
    z[1,0,2]  R345      1.9863437116146088e-01
    z[1,0,2]  R346      -3.7209963798522949e-01
    z[1,0,2]  R347      1.9737100601196289e-01
    z[1,0,2]  R348      4.5568180084228516e-01
    z[1,0,2]  R349      1.1098874360322952e-01
    z[1,0,2]  R350      -2.9603496193885803e-01
    z[1,0,2]  R351      5.4920607805252075e-01
    z[1,0,2]  R352      3.7952467799186707e-01
    z[1,0,2]  R353      1.7176325619220734e-01
    z[1,0,2]  R354      5.3085041046142578e-01
    z[1,0,2]  R355      -2.8079429268836975e-01
    z[1,0,2]  R356      -4.2123457789421082e-01
    z[1,0,2]  R357      0.408405065536499
    z[1,0,2]  R358      7.0510065555572510e-01
    z[1,0,2]  R359      9.5214679837226868e-02
    z[1,0,2]  R360      1.9265627861022949e-01
    z[1,0,2]  R361      1.5138559043407440e-01
    z[1,0,2]  R362      4.2132866382598877e-01
    z[1,0,2]  R363      -1.5476787090301514e-01
    z[1,0,2]  R364      2.9042625427246094e-01
    z[1,0,2]  R365      -1.1957526206970215e-01
    z[1,0,2]  R366      7.2208935022354126e-01
    z[1,0,2]  R367      4.5464840531349182e-01
    z[1,0,2]  R368      2.3715527355670929e-01
    z[1,0,2]  R369      7.1603232622146606e-01
    z[1,0,2]  R370      4.1160178184509277e-01
    z[1,0,2]  R371      0.485909104347229
    z[1,0,2]  R372      7.6738965511322021e-01
    z[1,0,2]  R373      -2.7881422638893127e-01
    z[1,0,2]  R374      -1.6056613624095917e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R217      -1
    z[1,0,3]  R218      1
    z[1,0,3]  R225      2.4325282871723175e-01
    z[1,0,3]  R226      -2.9130894690752029e-02
    z[1,0,3]  R227      -2.5148457288742065e-01
    z[1,0,3]  R228      1.2540750205516815e-01
    z[1,0,3]  R229      -6.9350488483905792e-02
    z[1,0,3]  R230      -2.2384946048259735e-01
    z[1,0,3]  R231      -1.5611016750335693e-01
    z[1,0,3]  R232      0.351661741733551
    z[1,0,3]  R233      -1.9590289890766144e-01
    z[1,0,3]  R234      -1.4304912090301514e-01
    z[1,0,3]  R235      2.1276351809501648e-01
    z[1,0,3]  R236      2.3736884817481041e-02
    z[1,0,3]  R237      2.3033104836940765e-01
    z[1,0,3]  R238      -5.3111881017684937e-01
    z[1,0,3]  R239      -4.1673696041107178e-01
    z[1,0,3]  R240      -6.0401380062103271e-01
    z[1,0,3]  R241      -7.1226024627685547e-01
    z[1,0,3]  R242      -5.0312846899032593e-01
    z[1,0,3]  R243      -3.5064321756362915e-01
    z[1,0,3]  R244      -6.3387966156005859e-01
    z[1,0,3]  R245      -6.4800351858139038e-01
    z[1,0,3]  R246      -7.8793352842330933e-01
    z[1,0,3]  R247      -1.7942821979522705e-01
    z[1,0,3]  R248      -0.599696934223175
    z[1,0,3]  R249      -9.0880846977233887e-01
    z[1,0,3]  R250      -0.678071916103363
    z[1,0,3]  R251      -3.2827010750770569e-01
    z[1,0,3]  R252      -3.1030055880546570e-01
    z[1,0,3]  R253      -5.1563370227813721e-01
    z[1,0,3]  R254      -4.5084246993064880e-01
    z[1,0,3]  R255      4.4007804989814758e-01
    z[1,0,3]  R256      3.3346137404441833e-01
    z[1,0,3]  R257      1.2889523059129715e-02
    z[1,0,3]  R258      -2.9720512032508850e-01
    z[1,0,3]  R259      -0.571692705154419
    z[1,0,3]  R260      -3.4564909338951111e-01
    z[1,0,3]  R261      -2.9619028791785240e-03
    z[1,0,3]  R262      2.4839065968990326e-01
    z[1,0,3]  R263      8.3537089824676514e-01
    z[1,0,3]  R264      6.5786695480346680e-01
    z[1,0,3]  R265      -4.3137678503990173e-01
    z[1,0,3]  R266      -2.2906927764415741e-01
    z[1,0,3]  R267      -2.2457545623183250e-02
    z[1,0,3]  R268      -8.8043145835399628e-02
    z[1,0,3]  R269      -7.6031464338302612e-01
    z[1,0,3]  R270      -4.3721115589141846e-01
    z[1,0,3]  R271      -1.2719729542732239e-01
    z[1,0,3]  R272      -4.4476732611656189e-01
    z[1,0,3]  R273      2.0254816114902496e-01
    z[1,0,3]  R274      1.8693853914737701e-01
    z[1,0,3]  R275      -4.4414305686950684e-01
    z[1,0,3]  R276      4.7506517171859741e-01
    z[1,0,3]  R277      -1.5171146392822266e-01
    z[1,0,3]  R278      -4.6923705935478210e-01
    z[1,0,3]  R279      2.3001782596111298e-02
    z[1,0,3]  R280      1.2662726454436779e-02
    z[1,0,3]  R281      -0.766851007938385
    z[1,0,3]  R282      1.9679950177669525e-01
    z[1,0,3]  R283      -8.5443496704101562e-01
    z[1,0,3]  R284      -7.1599733829498291e-01
    z[1,0,3]  R285      -0.621579110622406
    z[1,0,3]  R286      -1.8579454720020294e-01
    z[1,0,3]  R287      -3.1899437308311462e-01
    z[1,0,3]  R288      2.7757775783538818e-01
    z[1,0,3]  R289      -3.3909055590629578e-01
    z[1,0,3]  R290      1.6180644929409027e-01
    z[1,0,3]  R291      7.4454855918884277e-01
    z[1,0,3]  R292      2.3615576326847076e-02
    z[1,0,3]  R293      -6.1152640730142593e-02
    z[1,0,3]  R294      6.6606956720352173e-01
    z[1,0,3]  R295      -2.6376655697822571e-01
    z[1,0,3]  R296      2.7661317586898804e-01
    z[1,0,3]  R297      -4.9569407105445862e-01
    z[1,0,3]  R298      7.1560466289520264e-01
    z[1,0,3]  R299      1.2439829856157303e-01
    z[1,0,3]  R300      8.8599252700805664e-01
    z[1,0,3]  R301      8.0509597063064575e-01
    z[1,0,3]  R302      9.6395754814147949e-01
    z[1,0,3]  R303      1.3031853735446930e-01
    z[1,0,3]  R304      4.5830440521240234e-01
    z[1,0,3]  R305      2.2185295820236206e-01
    z[1,0,3]  R306      -3.4237092733383179e-01
    z[1,0,3]  R307      1.3089454174041748e-01
    z[1,0,3]  R308      1.9845359027385712e-02
    z[1,0,3]  R309      -1.9326542317867279e-01
    z[1,0,3]  R310      -5.7583391666412354e-01
    z[1,0,3]  R311      0.336665540933609
    z[1,0,3]  R312      3.8043934106826782e-01
    z[1,0,3]  R313      3.3475691080093384e-01
    z[1,0,3]  R314      3.3808118104934692e-01
    z[1,0,3]  R315      -4.8630633950233459e-01
    z[1,0,3]  R316      -9.0782207250595093e-01
    z[1,0,3]  R317      -7.7078616619110107e-01
    z[1,0,3]  R318      2.0572718232870102e-02
    z[1,0,3]  R319      -3.4895248245447874e-03
    z[1,0,3]  R320      -1.3784939050674438e-01
    z[1,0,3]  R321      -1.7129622399806976e-01
    z[1,0,3]  R322      -1.2891253829002380e-01
    z[1,0,3]  R323      -5.7065492868423462e-01
    z[1,0,3]  R324      2.2236967086791992e-01
    z[1,0,3]  R325      1.8083423376083374e-01
    z[1,0,3]  R326      -6.9698132574558258e-02
    z[1,0,3]  R327      1.4075244963169098e-01
    z[1,0,3]  R328      4.2891070246696472e-01
    z[1,0,3]  R329      0.380641371011734
    z[1,0,3]  R330      0.0773368775844574
    z[1,0,3]  R331      3.2796174287796021e-01
    z[1,0,3]  R332      -3.2630673050880432e-01
    z[1,0,3]  R333      2.8481978178024292e-01
    z[1,0,3]  R334      2.4042797088623047e-01
    z[1,0,3]  R335      -1.6804021596908569e-01
    z[1,0,3]  R336      -2.1764262020587921e-01
    z[1,0,3]  R337      -1.5559849143028259e-01
    z[1,0,3]  R338      -2.0663103461265564e-01
    z[1,0,3]  R339      -4.0528619289398193e-01
    z[1,0,3]  R340      -3.3417305350303650e-01
    z[1,0,3]  R341      -6.7320454120635986e-01
    z[1,0,3]  R342      -2.5686460733413696e-01
    z[1,0,3]  R343      -2.0680793095380068e-03
    z[1,0,3]  R344      -4.6091657876968384e-01
    z[1,0,3]  R345      -6.1763554811477661e-01
    z[1,0,3]  R346      -2.4363413453102112e-01
    z[1,0,3]  R347      4.7199773788452148e-01
    z[1,0,3]  R348      -1.1488460004329681e-01
    z[1,0,3]  R349      9.7651846706867218e-02
    z[1,0,3]  R350      4.2816668748855591e-01
    z[1,0,3]  R351      3.2782697677612305e-01
    z[1,0,3]  R352      -4.7279921174049377e-01
    z[1,0,3]  R353      -5.6368038058280945e-02
    z[1,0,3]  R354      -5.9518980979919434e-01
    z[1,0,3]  R355      -1.8755196034908295e-01
    z[1,0,3]  R356      -2.4840892851352692e-01
    z[1,0,3]  R357      -2.1829817444086075e-02
    z[1,0,3]  R358      2.9045999050140381e-01
    z[1,0,3]  R359      -6.3881975412368774e-01
    z[1,0,3]  R360      7.2736620903015137e-01
    z[1,0,3]  R361      0.645383358001709
    z[1,0,3]  R362      6.5305101871490479e-01
    z[1,0,3]  R363      -4.8276394605636597e-01
    z[1,0,3]  R364      8.8347822427749634e-01
    z[1,0,3]  R365      5.1070757210254669e-02
    z[1,0,3]  R366      1.2201625853776932e-01
    z[1,0,3]  R367      1.0796375572681427e-01
    z[1,0,3]  R368      -4.6345632523298264e-02
    z[1,0,3]  R369      -2.7514001727104187e-01
    z[1,0,3]  R370      -4.4121104478836060e-01
    z[1,0,3]  R371      6.0426419973373413e-01
    z[1,0,3]  R372      -0.250192791223526
    z[1,0,3]  R373      -4.0110346674919128e-01
    z[1,0,3]  R374      8.6320447921752930e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R219      -1
    z[1,0,4]  R220      1
    z[1,0,4]  R225      3.9067290723323822e-02
    z[1,0,4]  R226      -2.8967443108558655e-01
    z[1,0,4]  R227      5.9735560417175293e-01
    z[1,0,4]  R228      1.1907239258289337e-01
    z[1,0,4]  R229      -2.6911571621894836e-01
    z[1,0,4]  R230      -4.7039699554443359e-01
    z[1,0,4]  R231      2.0863448083400726e-01
    z[1,0,4]  R232      3.7537318468093872e-01
    z[1,0,4]  R233      -4.9597907066345215e-01
    z[1,0,4]  R234      0.436262845993042
    z[1,0,4]  R235      2.0806825160980225e-01
    z[1,0,4]  R236      -4.7438085079193115e-01
    z[1,0,4]  R237      -1.6129940748214722e-01
    z[1,0,4]  R238      -1.7047438025474548e-01
    z[1,0,4]  R239      1.5612085163593292e-01
    z[1,0,4]  R240      1.6943825408816338e-02
    z[1,0,4]  R241      -9.3334801495075226e-03
    z[1,0,4]  R242      1.4701751992106438e-02
    z[1,0,4]  R243      2.4286296218633652e-02
    z[1,0,4]  R244      6.5779253840446472e-02
    z[1,0,4]  R245      6.7274391651153564e-02
    z[1,0,4]  R246      -5.7650838047266006e-02
    z[1,0,4]  R247      2.0311267673969269e-01
    z[1,0,4]  R248      2.9101410508155823e-01
    z[1,0,4]  R249      2.6428506243973970e-03
    z[1,0,4]  R250      2.0727189257740974e-02
    z[1,0,4]  R251      4.8381105065345764e-01
    z[1,0,4]  R252      2.1485836803913116e-01
    z[1,0,4]  R253      1.8651841580867767e-01
    z[1,0,4]  R254      6.1027181148529053e-01
    z[1,0,4]  R255      2.7737993001937866e-01
    z[1,0,4]  R256      3.2691791653633118e-01
    z[1,0,4]  R257      -3.2753947377204895e-01
    z[1,0,4]  R258      -1.5371769666671753e-01
    z[1,0,4]  R259      1.7633976042270660e-01
    z[1,0,4]  R260      1.0239803791046143e-01
    z[1,0,4]  R261      2.8421280905604362e-02
    z[1,0,4]  R262      -1.8215529620647430e-02
    z[1,0,4]  R263      4.5270342379808426e-02
    z[1,0,4]  R264      -2.9345223307609558e-01
    z[1,0,4]  R265      -9.8966039717197418e-02
    z[1,0,4]  R266      5.8230036497116089e-01
    z[1,0,4]  R267      -7.7445581555366516e-02
    z[1,0,4]  R268      5.4957754909992218e-02
    z[1,0,4]  R269      0.0887366533279419
    z[1,0,4]  R270      1.2271800637245178e-01
    z[1,0,4]  R271      1.7630773782730103e-01
    z[1,0,4]  R272      -2.7799794077873230e-01
    z[1,0,4]  R273      -2.6498362421989441e-01
    z[1,0,4]  R274      4.8734968900680542e-01
    z[1,0,4]  R275      2.7661731839179993e-01
    z[1,0,4]  R276      -3.4113430976867676e-01
    z[1,0,4]  R277      0.190584197640419
    z[1,0,4]  R278      4.2454391717910767e-01
    z[1,0,4]  R279      6.2954194843769073e-02
    z[1,0,4]  R280      5.1860720850527287e-03
    z[1,0,4]  R281      -4.0332680940628052e-01
    z[1,0,4]  R282      -2.6774457097053528e-01
    z[1,0,4]  R283      4.1753351688385010e-01
    z[1,0,4]  R284      2.6212513446807861e-01
    z[1,0,4]  R285      -1.9029390811920166e-01
    z[1,0,4]  R286      -1.3608361780643463e-01
    z[1,0,4]  R287      -6.1558857560157776e-02
    z[1,0,4]  R288      -6.4338847994804382e-02
    z[1,0,4]  R289      5.0951063632965088e-01
    z[1,0,4]  R290      4.8818126320838928e-01
    z[1,0,4]  R291      2.8009146451950073e-01
    z[1,0,4]  R292      1.1476716957986355e-02
    z[1,0,4]  R293      -1.6288541257381439e-01
    z[1,0,4]  R294      -2.3661302030086517e-01
    z[1,0,4]  R295      -2.9888426885008812e-02
    z[1,0,4]  R296      -5.2529531717300415e-01
    z[1,0,4]  R297      1.1386800557374954e-01
    z[1,0,4]  R298      -2.6716282963752747e-01
    z[1,0,4]  R299      2.3903135955333710e-01
    z[1,0,4]  R300      1.6486936807632446e-01
    z[1,0,4]  R301      5.1504410803318024e-02
    z[1,0,4]  R302      1.4756634831428528e-01
    z[1,0,4]  R303      1.8596661090850830e-01
    z[1,0,4]  R304      1.2414073944091797e-01
    z[1,0,4]  R305      -4.9323442578315735e-01
    z[1,0,4]  R306      3.7036576867103577e-01
    z[1,0,4]  R307      -2.0263580977916718e-01
    z[1,0,4]  R308      0.294387549161911
    z[1,0,4]  R309      2.8524341061711311e-02
    z[1,0,4]  R310      -7.0917648077011108e-01
    z[1,0,4]  R311      1.6378301382064819e-01
    z[1,0,4]  R312      -2.4107404053211212e-01
    z[1,0,4]  R313      -0.0662151351571083
    z[1,0,4]  R314      -2.0259568095207214e-01
    z[1,0,4]  R315      2.0659589767456055e-01
    z[1,0,4]  R316      1.2071436643600464e-01
    z[1,0,4]  R317      -2.7697184681892395e-01
    z[1,0,4]  R318      -2.2041415795683861e-02
    z[1,0,4]  R319      -1.4359714090824127e-01
    z[1,0,4]  R320      -1.9014884531497955e-01
    z[1,0,4]  R321      -1.0998731106519699e-01
    z[1,0,4]  R322      3.2825049757957458e-01
    z[1,0,4]  R323      -8.3933107554912567e-02
    z[1,0,4]  R324      1.6483344137668610e-02
    z[1,0,4]  R325      -2.2064687311649323e-01
    z[1,0,4]  R326      -2.0545309782028198e-01
    z[1,0,4]  R327      3.3019462227821350e-01
    z[1,0,4]  R328      2.6482102274894714e-01
    z[1,0,4]  R329      -3.3414953947067261e-01
    z[1,0,4]  R330      4.2259556055068970e-01
    z[1,0,4]  R331      -9.9161945283412933e-02
    z[1,0,4]  R332      -4.5455410145223141e-03
    z[1,0,4]  R333      3.9835435152053833e-01
    z[1,0,4]  R334      3.1894508004188538e-01
    z[1,0,4]  R335      -8.5877306759357452e-02
    z[1,0,4]  R336      -2.6973801851272583e-01
    z[1,0,4]  R337      -2.0720811560750008e-02
    z[1,0,4]  R338      4.0071615576744080e-01
    z[1,0,4]  R339      4.1808298230171204e-01
    z[1,0,4]  R340      5.7537477463483810e-02
    z[1,0,4]  R341      3.4836444258689880e-01
    z[1,0,4]  R342      3.7266877293586731e-01
    z[1,0,4]  R343      0.363534539937973
    z[1,0,4]  R344      -7.2346520423889160e-01
    z[1,0,4]  R345      2.0305566489696503e-01
    z[1,0,4]  R346      2.0270688831806183e-01
    z[1,0,4]  R347      -1.0040581226348877e-01
    z[1,0,4]  R348      -2.6142343878746033e-01
    z[1,0,4]  R349      -1.0947328805923462e-01
    z[1,0,4]  R350      2.3419323563575745e-01
    z[1,0,4]  R351      -3.2322630286216736e-01
    z[1,0,4]  R352      -2.1963614225387573e-01
    z[1,0,4]  R353      -2.3658205568790436e-01
    z[1,0,4]  R354      -1.5085247159004211e-01
    z[1,0,4]  R355      -6.5335296094417572e-02
    z[1,0,4]  R356      -5.7643568515777588e-01
    z[1,0,4]  R357      -1.8529847264289856e-01
    z[1,0,4]  R358      -2.1317061781883240e-01
    z[1,0,4]  R359      9.3847788870334625e-02
    z[1,0,4]  R360      2.6367539167404175e-01
    z[1,0,4]  R361      -5.5896721780300140e-02
    z[1,0,4]  R362      2.5234678387641907e-01
    z[1,0,4]  R363      4.5455864071846008e-01
    z[1,0,4]  R364      1.9800759851932526e-01
    z[1,0,4]  R365      -2.6005905866622925e-01
    z[1,0,4]  R366      -2.1363671123981476e-01
    z[1,0,4]  R367      7.0633560419082642e-02
    z[1,0,4]  R368      -1.4188164472579956e-01
    z[1,0,4]  R369      9.3043945729732513e-02
    z[1,0,4]  R370      5.0262737274169922e-01
    z[1,0,4]  R371      1.1373239010572433e-01
    z[1,0,4]  R372      4.0888068079948425e-01
    z[1,0,4]  R373      4.2495880275964737e-02
    z[1,0,4]  R374      -3.8691172003746033e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R221      -1
    z[1,0,5]  R222      1
    z[1,0,5]  R225      3.3873483538627625e-01
    z[1,0,5]  R226      1.2411311268806458e-01
    z[1,0,5]  R227      -4.6913441270589828e-02
    z[1,0,5]  R228      -4.4032388925552368e-01
    z[1,0,5]  R229      -0.530138373374939
    z[1,0,5]  R230      2.3358824849128723e-01
    z[1,0,5]  R231      4.1394233703613281e-01
    z[1,0,5]  R232      4.8824291676282883e-02
    z[1,0,5]  R233      -3.9712780714035034e-01
    z[1,0,5]  R234      2.7972424030303955e-01
    z[1,0,5]  R235      3.5715565085411072e-01
    z[1,0,5]  R236      -1.5061445534229279e-01
    z[1,0,5]  R237      -8.1352427601814270e-02
    z[1,0,5]  R238      -1.8826331198215485e-01
    z[1,0,5]  R239      -1.8314327299594879e-01
    z[1,0,5]  R240      2.1702989935874939e-02
    z[1,0,5]  R241      -2.7365726232528687e-01
    z[1,0,5]  R242      1.4367893338203430e-01
    z[1,0,5]  R243      -2.9355597496032715e-01
    z[1,0,5]  R244      -1.6940365731716156e-01
    z[1,0,5]  R245      2.3928731679916382e-01
    z[1,0,5]  R246      -2.8580215573310852e-01
    z[1,0,5]  R247      -6.6587787866592407e-01
    z[1,0,5]  R248      -5.1513540744781494e-01
    z[1,0,5]  R249      2.9050523042678833e-01
    z[1,0,5]  R250      -5.2687561511993408e-01
    z[1,0,5]  R251      -7.1248096227645874e-01
    z[1,0,5]  R252      -3.8606736063957214e-01
    z[1,0,5]  R253      1.8828584253787994e-01
    z[1,0,5]  R254      -3.4893444180488586e-01
    z[1,0,5]  R255      2.3667345941066742e-01
    z[1,0,5]  R256      -3.8476511836051941e-01
    z[1,0,5]  R257      -6.4561265707015991e-01
    z[1,0,5]  R258      -1.8605917692184448e-01
    z[1,0,5]  R259      7.7510738372802734e-01
    z[1,0,5]  R260      -8.8310331106185913e-02
    z[1,0,5]  R261      -3.1413757801055908e-01
    z[1,0,5]  R262      4.4666835665702820e-01
    z[1,0,5]  R263      3.6467710137367249e-01
    z[1,0,5]  R264      -3.1655681133270264e-01
    z[1,0,5]  R265      2.3101146519184113e-01
    z[1,0,5]  R266      -2.2347655892372131e-01
    z[1,0,5]  R267      -2.3387621343135834e-01
    z[1,0,5]  R268      -4.4238799810409546e-01
    z[1,0,5]  R269      1.2042701244354248e-02
    z[1,0,5]  R270      0.0900174155831337
    z[1,0,5]  R271      -2.4764549732208252e-01
    z[1,0,5]  R272      -5.9273451566696167e-01
    z[1,0,5]  R273      2.1468596160411835e-01
    z[1,0,5]  R274      2.5821685791015625e-02
    z[1,0,5]  R275      4.2101528495550156e-02
    z[1,0,5]  R276      -1.9953294098377228e-01
    z[1,0,5]  R277      -3.8285022974014282e-01
    z[1,0,5]  R278      -3.0303534865379333e-01
    z[1,0,5]  R279      -2.1895058453083038e-01
    z[1,0,5]  R280      -1.7859362065792084e-01
    z[1,0,5]  R281      -1.2226261198520660e-01
    z[1,0,5]  R282      8.4042645990848541e-02
    z[1,0,5]  R283      4.6469278633594513e-02
    z[1,0,5]  R284      -2.3661652207374573e-01
    z[1,0,5]  R285      5.3901232779026031e-02
    z[1,0,5]  R286      -2.5268737226724625e-02
    z[1,0,5]  R287      1.1423484981060028e-01
    z[1,0,5]  R288      9.2856295406818390e-02
    z[1,0,5]  R289      6.0295450687408447e-01
    z[1,0,5]  R290      5.0113433599472046e-01
    z[1,0,5]  R291      1.6589875519275665e-01
    z[1,0,5]  R292      2.8435957431793213e-01
    z[1,0,5]  R293      3.1393593549728394e-01
    z[1,0,5]  R294      2.0554584264755249e-01
    z[1,0,5]  R295      5.3236478567123413e-01
    z[1,0,5]  R296      -3.4749662876129150e-01
    z[1,0,5]  R297      -4.1468435525894165e-01
    z[1,0,5]  R298      3.0284056067466736e-01
    z[1,0,5]  R299      0.639694094657898
    z[1,0,5]  R300      0.0696791484951973
    z[1,0,5]  R301      1.8360999226570129e-01
    z[1,0,5]  R302      -1.0117681324481964e-01
    z[1,0,5]  R303      7.0125319063663483e-02
    z[1,0,5]  R304      1.1617124080657959e-01
    z[1,0,5]  R305      4.4329819083213806e-01
    z[1,0,5]  R306      -5.5636620521545410e-01
    z[1,0,5]  R307      -1.4024247229099274e-01
    z[1,0,5]  R308      4.0735453367233276e-01
    z[1,0,5]  R309      -1.9044749438762665e-01
    z[1,0,5]  R310      -3.1642335653305054e-01
    z[1,0,5]  R311      -1.4758719503879547e-01
    z[1,0,5]  R312      6.5971814095973969e-02
    z[1,0,5]  R313      -4.5893844217061996e-02
    z[1,0,5]  R314      8.5568435490131378e-02
    z[1,0,5]  R315      -5.0445652008056641e-01
    z[1,0,5]  R316      -7.6856710016727448e-02
    z[1,0,5]  R317      2.5028528645634651e-02
    z[1,0,5]  R318      -3.2930124551057816e-02
    z[1,0,5]  R319      -1.1862007528543472e-01
    z[1,0,5]  R320      2.8669700026512146e-01
    z[1,0,5]  R321      8.7456069886684418e-03
    z[1,0,5]  R322      9.1848298907279968e-02
    z[1,0,5]  R323      3.6754995584487915e-01
    z[1,0,5]  R324      2.0405404269695282e-01
    z[1,0,5]  R325      0.280277818441391
    z[1,0,5]  R326      -2.3130537569522858e-01
    z[1,0,5]  R327      3.6788681149482727e-01
    z[1,0,5]  R328      -3.6726880073547363e-01
    z[1,0,5]  R329      2.8330111503601074e-01
    z[1,0,5]  R330      -4.9175322055816650e-02
    z[1,0,5]  R331      -4.5591026544570923e-02
    z[1,0,5]  R332      3.1311208009719849e-01
    z[1,0,5]  R333      4.0186995267868042e-01
    z[1,0,5]  R334      -1.1770709417760372e-02
    z[1,0,5]  R335      3.1503564119338989e-01
    z[1,0,5]  R336      2.5389587879180908e-01
    z[1,0,5]  R337      7.6005801558494568e-02
    z[1,0,5]  R338      -1.4338185079395771e-02
    z[1,0,5]  R339      1.1591343581676483e-01
    z[1,0,5]  R340      -6.0779560357332230e-02
    z[1,0,5]  R341      2.6166474819183350e-01
    z[1,0,5]  R342      3.6587905883789062e-01
    z[1,0,5]  R343      1.5322747826576233e-01
    z[1,0,5]  R344      -3.3494135737419128e-01
    z[1,0,5]  R345      -3.2431003451347351e-01
    z[1,0,5]  R346      -4.3392094969749451e-01
    z[1,0,5]  R347      1.3375861942768097e-01
    z[1,0,5]  R348      -6.6862389445304871e-02
    z[1,0,5]  R349      -4.9372907727956772e-02
    z[1,0,5]  R350      -2.2421722114086151e-01
    z[1,0,5]  R351      -3.4554848074913025e-01
    z[1,0,5]  R352      -9.1310754418373108e-02
    z[1,0,5]  R353      1.6689199209213257e-01
    z[1,0,5]  R354      1.0497282445430756e-01
    z[1,0,5]  R355      -2.2765980660915375e-01
    z[1,0,5]  R356      -2.7418437600135803e-01
    z[1,0,5]  R357      3.8546571135520935e-01
    z[1,0,5]  R358      8.5960216820240021e-02
    z[1,0,5]  R359      -3.0100712180137634e-01
    z[1,0,5]  R360      3.7864178419113159e-01
    z[1,0,5]  R361      4.0323731303215027e-01
    z[1,0,5]  R362      4.7610646486282349e-01
    z[1,0,5]  R363      -4.0040472149848938e-01
    z[1,0,5]  R364      -3.4990664571523666e-02
    z[1,0,5]  R365      -6.4122414588928223e-01
    z[1,0,5]  R366      7.6918698847293854e-02
    z[1,0,5]  R367      3.3405745029449463e-01
    z[1,0,5]  R368      -2.5700443983078003e-01
    z[1,0,5]  R369      1.7790308222174644e-02
    z[1,0,5]  R370      1.7716838419437408e-01
    z[1,0,5]  R371      4.1874179244041443e-01
    z[1,0,5]  R372      -5.2343491464853287e-02
    z[1,0,5]  R373      1.1070173233747482e-01
    z[1,0,5]  R374      1.1411818861961365e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R223      -1
    z[1,0,6]  R224      1
    z[1,0,6]  R225      2.9033901169896126e-02
    z[1,0,6]  R226      4.0269076824188232e-01
    z[1,0,6]  R227      -2.5250702165067196e-03
    z[1,0,6]  R228      4.6675089001655579e-01
    z[1,0,6]  R229      3.4391921758651733e-01
    z[1,0,6]  R230      -3.5764020681381226e-01
    z[1,0,6]  R231      -3.6626964807510376e-01
    z[1,0,6]  R232      4.8786246776580811e-01
    z[1,0,6]  R233      -2.3331686854362488e-01
    z[1,0,6]  R234      -1.6823986172676086e-01
    z[1,0,6]  R235      -6.6091649234294891e-02
    z[1,0,6]  R236      -3.2455231994390488e-02
    z[1,0,6]  R237      2.8705042600631714e-01
    z[1,0,6]  R238      -2.2222459316253662e-01
    z[1,0,6]  R239      -1.4257307350635529e-01
    z[1,0,6]  R240      -0.0975661426782608
    z[1,0,6]  R241      1.2624484300613403e-01
    z[1,0,6]  R242      1.5527017414569855e-01
    z[1,0,6]  R243      0.258098304271698
    z[1,0,6]  R244      3.3507046103477478e-01
    z[1,0,6]  R245      5.1464933156967163e-01
    z[1,0,6]  R246      2.4968293309211731e-01
    z[1,0,6]  R247      9.3214483931660652e-03
    z[1,0,6]  R248      3.3698195219039917e-01
    z[1,0,6]  R249      3.4815050661563873e-02
    z[1,0,6]  R250      -1.7313238978385925e-01
    z[1,0,6]  R251      -2.4636309593915939e-02
    z[1,0,6]  R252      -2.0133270323276520e-01
    z[1,0,6]  R253      7.3934487998485565e-02
    z[1,0,6]  R254      -1.8456031382083893e-01
    z[1,0,6]  R255      -2.1386298537254333e-01
    z[1,0,6]  R256      1.8342237174510956e-01
    z[1,0,6]  R257      4.3450701236724854e-01
    z[1,0,6]  R258      1.5843538939952850e-01
    z[1,0,6]  R259      2.4175839498639107e-02
    z[1,0,6]  R260      -7.6298236846923828e-01
    z[1,0,6]  R261      -6.7152345180511475e-01
    z[1,0,6]  R262      -1.6806390881538391e-01
    z[1,0,6]  R263      1.2550490908324718e-02
    z[1,0,6]  R264      -2.9177930951118469e-01
    z[1,0,6]  R265      1.5630675852298737e-01
    z[1,0,6]  R266      3.8100153207778931e-01
    z[1,0,6]  R267      -0.298606812953949
    z[1,0,6]  R268      -6.7481301724910736e-02
    z[1,0,6]  R269      4.2612645030021667e-01
    z[1,0,6]  R270      -7.9563081264495850e-01
    z[1,0,6]  R271      -8.4395474195480347e-01
    z[1,0,6]  R272      -4.5136049389839172e-01
    z[1,0,6]  R273      7.3453408479690552e-01
    z[1,0,6]  R274      -4.8163527250289917e-01
    z[1,0,6]  R275      4.9647635221481323e-01
    z[1,0,6]  R276      -2.4195753037929535e-01
    z[1,0,6]  R277      -6.6734445095062256e-01
    z[1,0,6]  R278      -9.9828787147998810e-02
    z[1,0,6]  R279      -1.2361995875835419e-01
    z[1,0,6]  R280      -5.6591433286666870e-01
    z[1,0,6]  R281      -4.8089297488331795e-03
    z[1,0,6]  R282      7.5726640224456787e-01
    z[1,0,6]  R283      -0.248578742146492
    z[1,0,6]  R284      4.6707659959793091e-02
    z[1,0,6]  R285      -1.9116099178791046e-01
    z[1,0,6]  R286      -2.8267496824264526e-01
    z[1,0,6]  R287      1.1737269163131714e-01
    z[1,0,6]  R288      -1.6705824434757233e-01
    z[1,0,6]  R289      -2.3493103682994843e-01
    z[1,0,6]  R290      -3.7678858637809753e-01
    z[1,0,6]  R291      4.0877026319503784e-01
    z[1,0,6]  R292      -1.1880979686975479e-01
    z[1,0,6]  R293      5.8983471244573593e-02
    z[1,0,6]  R294      -5.6204688549041748e-01
    z[1,0,6]  R295      3.2145938277244568e-01
    z[1,0,6]  R296      -2.1052356064319611e-01
    z[1,0,6]  R297      -9.2820391058921814e-02
    z[1,0,6]  R298      -2.5066909193992615e-01
    z[1,0,6]  R299      2.9441300034523010e-01
    z[1,0,6]  R300      -6.3016250729560852e-02
    z[1,0,6]  R301      -4.6255189180374146e-01
    z[1,0,6]  R302      -2.6806166395545006e-02
    z[1,0,6]  R303      -1.4414816163480282e-02
    z[1,0,6]  R304      1.2441301345825195e-01
    z[1,0,6]  R305      7.5026132166385651e-02
    z[1,0,6]  R306      2.2135600447654724e-01
    z[1,0,6]  R307      -6.8161681294441223e-02
    z[1,0,6]  R308      1.3272415101528168e-01
    z[1,0,6]  R309      -5.1599580049514771e-01
    z[1,0,6]  R310      1.3522616028785706e-01
    z[1,0,6]  R311      3.6488026380538940e-02
    z[1,0,6]  R312      -3.7991631776094437e-02
    z[1,0,6]  R313      -1.1893206089735031e-01
    z[1,0,6]  R314      1.5725551545619965e-01
    z[1,0,6]  R315      1.8866769969463348e-01
    z[1,0,6]  R316      -4.9333442002534866e-02
    z[1,0,6]  R317      0.395723819732666
    z[1,0,6]  R318      4.1688024997711182e-02
    z[1,0,6]  R319      -7.4217252433300018e-02
    z[1,0,6]  R320      -2.4170126020908356e-01
    z[1,0,6]  R321      -1.0254694148898125e-02
    z[1,0,6]  R322      0.088455431163311
    z[1,0,6]  R323      -5.0630939006805420e-01
    z[1,0,6]  R324      7.0999123156070709e-02
    z[1,0,6]  R325      -3.2858546823263168e-02
    z[1,0,6]  R326      8.8604830205440521e-02
    z[1,0,6]  R327      4.9064168706536293e-03
    z[1,0,6]  R328      2.8341269493103027e-01
    z[1,0,6]  R329      -1.8354374170303345e-01
    z[1,0,6]  R330      4.4690284132957458e-01
    z[1,0,6]  R331      4.0696394443511963e-01
    z[1,0,6]  R332      -4.0506433695554733e-02
    z[1,0,6]  R333      3.2720208168029785e-01
    z[1,0,6]  R334      1.0336861759424210e-01
    z[1,0,6]  R335      -1.9738449156284332e-01
    z[1,0,6]  R336      -3.4226831048727036e-02
    z[1,0,6]  R337      4.3831002712249756e-01
    z[1,0,6]  R338      -1.2033692747354507e-01
    z[1,0,6]  R339      -3.2512211799621582e-01
    z[1,0,6]  R340      -4.3581396341323853e-01
    z[1,0,6]  R341      2.4558633565902710e-01
    z[1,0,6]  R342      4.3737164139747620e-01
    z[1,0,6]  R343      -4.1613289713859558e-01
    z[1,0,6]  R344      -1.3238739967346191e-01
    z[1,0,6]  R345      -1.2371501326560974e-01
    z[1,0,6]  R346      4.7032165527343750e-01
    z[1,0,6]  R347      -2.1344347298145294e-01
    z[1,0,6]  R348      -1.2281096726655960e-01
    z[1,0,6]  R349      3.1134957075119019e-01
    z[1,0,6]  R350      4.4350346922874451e-01
    z[1,0,6]  R351      -1.6316774487495422e-01
    z[1,0,6]  R352      1.5427152812480927e-01
    z[1,0,6]  R353      2.6543816924095154e-01
    z[1,0,6]  R354      -1.0702729225158691e-01
    z[1,0,6]  R355      5.6285685300827026e-01
    z[1,0,6]  R356      2.3148207366466522e-01
    z[1,0,6]  R357      -1.2104640156030655e-01
    z[1,0,6]  R358      -0.295296311378479
    z[1,0,6]  R359      -1.9183368980884552e-01
    z[1,0,6]  R360      1.1599563807249069e-01
    z[1,0,6]  R361      0.0747029259800911
    z[1,0,6]  R362      -2.4605879187583923e-01
    z[1,0,6]  R363      2.8579438105225563e-02
    z[1,0,6]  R364      0.0792076513171196
    z[1,0,6]  R365      -2.3442563414573669e-01
    z[1,0,6]  R366      -2.8481602668762207e-01
    z[1,0,6]  R367      8.9047178626060486e-03
    z[1,0,6]  R368      3.2759314775466919e-01
    z[1,0,6]  R369      -1.4143096632324159e-04
    z[1,0,6]  R370      1.8598626554012299e-01
    z[1,0,6]  R371      -2.0224186778068542e-01
    z[1,0,6]  R372      -2.2372610867023468e-01
    z[1,0,6]  R373      4.0545615553855896e-01
    z[1,0,6]  R374      -9.1858208179473877e-02
    z[0,3,0]  R2        -1
    z[0,3,0]  R29       1
    z[0,3,0]  R375      -1
    z[0,3,0]  R376      1
    z[0,3,0]  R389      -2.7911195158958435e-01
    z[0,3,0]  R390      -2.5956231355667114e-01
    z[0,3,0]  R391      -0.200189471244812
    z[0,3,0]  R392      9.5063948631286621e-01
    z[0,3,0]  R393      5.5172234773635864e-01
    z[0,3,0]  R394      8.2528567314147949e-01
    z[0,3,0]  R395      8.0844157934188843e-01
    z[0,3,0]  R396      8.0433422327041626e-01
    z[0,3,0]  R397      -2.6695212721824646e-01
    z[0,3,0]  R398      4.4909101724624634e-01
    z[0,3,0]  R399      -6.7703330516815186e-01
    z[0,3,0]  R400      -8.4879899024963379e-01
    z[0,3,0]  R401      -7.9707098007202148e-01
    z[0,3,0]  R402      -6.5170717239379883e-01
    z[0,3,0]  R403      -5.3997147083282471e-01
    z[0,3,0]  R404      -5.1643681526184082e-01
    z[0,3,0]  R405      -4.9135014414787292e-01
    z[0,3,0]  R406      -7.3041713237762451e-01
    z[0,3,0]  R407      -4.2066127061843872e-01
    z[0,3,0]  R408      -0.335271954536438
    z[0,3,0]  R409      -7.8593236207962036e-01
    z[0,3,0]  R410      -4.8112070560455322e-01
    z[0,3,0]  R411      -8.0663490295410156e-01
    z[0,3,0]  R412      -4.5488181710243225e-01
    z[0,3,0]  R413      -3.4604361653327942e-01
    z[0,3,0]  R414      -0.739958643913269
    z[0,3,0]  R415      -5.4418420791625977e-01
    z[0,3,0]  R416      -3.8419404625892639e-01
    z[0,3,0]  R417      -3.8750213384628296e-01
    z[0,3,0]  R418      -1.6495670378208160e-01
    z[0,3,0]  R419      -6.4012104272842407e-01
    z[0,3,0]  R420      -4.5631998777389526e-01
    z[0,3,0]  R421      -6.9034153223037720e-01
    z[0,3,0]  R422      -4.7739055752754211e-01
    z[0,3,0]  R423      -3.3747208118438721e-01
    z[0,3,0]  R424      0.616935133934021
    z[0,3,0]  R425      -2.9487824440002441e-01
    z[0,3,0]  R426      -3.2894019037485123e-02
    z[0,3,0]  R427      2.6451559737324715e-02
    z[0,3,0]  R428      -5.9227943420410156e-02
    z[0,3,0]  R429      -3.2220444083213806e-01
    z[0,3,0]  R430      -4.7876590490341187e-01
    z[0,3,0]  R431      -2.2320681810379028e-01
    z[0,3,0]  R432      -3.1698886305093765e-02
    z[0,3,0]  R433      4.0914884209632874e-01
    z[0,3,0]  R434      2.0863594114780426e-01
    z[0,3,0]  R435      4.6707686781883240e-01
    z[0,3,0]  R436      5.0943013280630112e-02
    z[0,3,0]  R437      3.4773871302604675e-01
    z[0,3,0]  R438      8.9614562690258026e-02
    z[0,3,0]  R439      -0.302606999874115
    z[0,3,0]  R440      -8.2195393741130829e-02
    z[0,3,0]  R441      -1.9792994856834412e-01
    z[0,3,0]  R442      -2.2379927337169647e-01
    z[0,3,0]  R443      0.0955568253993988
    z[0,3,0]  R444      5.4114109277725220e-01
    z[0,3,0]  R445      5.3917460143566132e-02
    z[0,3,0]  R446      3.4159538149833679e-01
    z[0,3,0]  R447      4.7162267565727234e-01
    z[0,3,0]  R448      2.4069221317768097e-01
    z[0,3,0]  R449      -3.4406775236129761e-01
    z[0,3,0]  R450      -3.2790100574493408e-01
    z[0,3,0]  R451      -0.389911025762558
    z[0,3,0]  R452      -2.5247624516487122e-01
    z[0,3,0]  R453      7.9031985998153687e-01
    z[0,3,0]  R454      8.8028162717819214e-01
    z[0,3,0]  R455      8.6288440227508545e-01
    z[0,3,0]  R456      -5.6515991687774658e-01
    z[0,3,0]  R457      -7.2183072566986084e-01
    z[0,3,0]  R458      -1.0561756044626236e-01
    z[0,3,0]  R459      9.0281152725219727e-01
    z[0,3,0]  R460      -5.6377702951431274e-01
    z[0,3,0]  R461      -4.2510709166526794e-01
    z[0,3,0]  R462      -3.1426465511322021e-01
    z[0,3,0]  R463      -0.472042441368103
    z[0,3,0]  R464      -5.2815198898315430e-01
    z[0,3,0]  R465      -4.3587875366210938e-01
    z[0,3,0]  R466      -8.0650782585144043e-01
    z[0,3,0]  R467      -5.4882502555847168e-01
    z[0,3,0]  R468      -5.3742176294326782e-01
    z[0,3,0]  R469      -5.6928426027297974e-01
    z[0,3,0]  R470      -5.6497520208358765e-01
    z[0,3,0]  R471      -6.1704134941101074e-01
    z[0,3,0]  R472      -0.656769335269928
    z[0,3,0]  R473      -7.2379314899444580e-01
    z[0,3,0]  R474      -4.4615957140922546e-01
    z[0,3,0]  R475      -5.2692312002182007e-01
    z[0,3,0]  R476      -3.8040143251419067e-01
    z[0,3,0]  R477      -8.1182342767715454e-01
    z[0,3,0]  R478      -0.684876024723053
    z[0,3,0]  R479      -5.0133860111236572e-01
    z[0,3,0]  R480      -5.6957280635833740e-01
    z[0,3,0]  R481      0.356876015663147
    z[0,3,0]  R482      8.1507444381713867e-01
    z[0,3,0]  R483      9.1206395626068115e-01
    z[0,3,0]  R484      7.6318812370300293e-01
    z[0,3,0]  R485      8.7414103746414185e-01
    z[0,3,0]  R486      -5.3127700090408325e-01
    z[0,3,0]  R487      -3.3868685364723206e-01
    z[0,3,0]  R488      -3.4689253568649292e-01
    z[0,3,0]  R489      -0.587253212928772
    z[0,3,0]  R490      -2.1451064944267273e-01
    z[0,3,0]  R491      -1.4580808579921722e-01
    z[0,3,0]  R492      -5.0207239389419556e-01
    z[0,3,0]  R493      -6.3019603490829468e-01
    z[0,3,0]  R494      -6.6657543182373047e-01
    z[0,3,0]  R495      -4.9757176637649536e-01
    z[0,3,0]  R496      -5.4342097043991089e-01
    z[0,3,0]  R497      -8.4325426816940308e-01
    z[0,3,0]  R498      -8.3551156520843506e-01
    z[0,3,0]  R499      -5.7310348749160767e-01
    z[0,3,0]  R500      -3.0678653717041016e-01
    z[0,3,0]  R501      -0.371635377407074
    z[0,3,0]  R502      -5.5593419075012207e-01
    z[0,3,0]  R503      4.6494059264659882e-02
    z[0,3,0]  R504      8.0510163307189941e-01
    z[0,3,0]  R505      8.6243516206741333e-01
    z[0,3,0]  R506      6.2239643186330795e-02
    z[0,3,0]  R507      -7.6600360870361328e-01
    z[0,3,0]  R508      5.9907469898462296e-02
    z[0,3,0]  R509      -6.7986255884170532e-01
    z[0,3,0]  R510      -6.9654667377471924e-01
    z[0,3,0]  R511      -5.5627793073654175e-01
    z[0,3,0]  R512      -7.0455557107925415e-01
    z[0,3,0]  R513      -2.4017766118049622e-02
    z[0,3,0]  R514      8.6195367574691772e-01
    z[0,3,0]  R515      8.7085694074630737e-01
    z[0,3,0]  R516      -4.1222232580184937e-01
    z[0,3,0]  R517      -3.7235784530639648e-01
    z[0,3,0]  R518      -2.5136863812804222e-02
    z[0,3,0]  R519      -7.5712692737579346e-01
    z[0,3,0]  R520      -5.1961249113082886e-01
    z[0,3,0]  R521      -1.2179906666278839e-01
    z[0,3,0]  R522      9.1755294799804688e-01
    z[0,3,0]  R523      7.9644507169723511e-01
    z[0,3,0]  R524      0.795567512512207
    z[0,3,0]  R525      8.2271134853363037e-01
    z[0,3,0]  R526      -4.8599314689636230e-01
    z[0,3,0]  R527      -6.6693328320980072e-02
    z[0,3,0]  R528      -4.7179032117128372e-02
    z[0,3,0]  R529      -2.1626415848731995e-01
    z[0,3,0]  R530      -2.4165056645870209e-01
    z[0,3,0]  R531      -8.7707346677780151e-01
    z[0,3,0]  R532      -8.2092583179473877e-01
    z[0,3,0]  R533      3.0467975139617920e-01
    z[0,3,0]  R534      -7.1975088119506836e-01
    z[0,3,0]  R535      8.4028869867324829e-01
    z[0,3,1]  R3        -1
    z[0,3,1]  R30       1
    z[0,3,1]  R377      -1
    z[0,3,1]  R378      1
    z[0,3,1]  R389      5.7454162836074829e-01
    z[0,3,1]  R390      1.6744308173656464e-01
    z[0,3,1]  R391      3.1051808595657349e-01
    z[0,3,1]  R392      1.8348847329616547e-01
    z[0,3,1]  R393      7.3893499374389648e-01
    z[0,3,1]  R394      1.7857621610164642e-01
    z[0,3,1]  R395      5.3061944246292114e-01
    z[0,3,1]  R396      4.6047952771186829e-01
    z[0,3,1]  R397      4.5100402832031250e-01
    z[0,3,1]  R398      0.596885621547699
    z[0,3,1]  R399      -3.4250352531671524e-02
    z[0,3,1]  R400      -2.0875754952430725e-01
    z[0,3,1]  R401      2.0808492600917816e-01
    z[0,3,1]  R402      -4.1754089295864105e-02
    z[0,3,1]  R403      5.3702068328857422e-01
    z[0,3,1]  R404      -3.1882904469966888e-02
    z[0,3,1]  R405      -4.5007994771003723e-01
    z[0,3,1]  R406      -5.1013922691345215e-01
    z[0,3,1]  R407      -2.0662444829940796e-01
    z[0,3,1]  R408      -6.6670411825180054e-01
    z[0,3,1]  R409      4.5394363999366760e-01
    z[0,3,1]  R410      7.4497830867767334e-01
    z[0,3,1]  R411      2.1404880285263062e-01
    z[0,3,1]  R412      7.1047663688659668e-01
    z[0,3,1]  R413      6.4928478002548218e-01
    z[0,3,1]  R414      3.7441188097000122e-01
    z[0,3,1]  R415      1.0908488184213638e-02
    z[0,3,1]  R416      4.2736539244651794e-01
    z[0,3,1]  R417      4.4189310073852539e-01
    z[0,3,1]  R418      2.7838796377182007e-01
    z[0,3,1]  R419      8.7187774479389191e-02
    z[0,3,1]  R420      3.7865081429481506e-01
    z[0,3,1]  R421      -4.3377488851547241e-01
    z[0,3,1]  R422      -6.8070453405380249e-01
    z[0,3,1]  R423      -8.6769664287567139e-01
    z[0,3,1]  R424      2.1589897572994232e-01
    z[0,3,1]  R425      -5.0343447923660278e-01
    z[0,3,1]  R426      -7.4226856231689453e-01
    z[0,3,1]  R427      -9.0129858255386353e-01
    z[0,3,1]  R428      -5.6143432855606079e-01
    z[0,3,1]  R429      6.3973242044448853e-01
    z[0,3,1]  R430      2.6570373773574829e-01
    z[0,3,1]  R431      -7.6507246494293213e-01
    z[0,3,1]  R432      -5.2671676874160767e-01
    z[0,3,1]  R433      -5.2842015027999878e-01
    z[0,3,1]  R434      -4.0489968657493591e-01
    z[0,3,1]  R435      -4.1363832354545593e-01
    z[0,3,1]  R436      -2.0617979764938354e-01
    z[0,3,1]  R437      -5.0428098440170288e-01
    z[0,3,1]  R438      -0.28351891040802
    z[0,3,1]  R439      5.9813719987869263e-01
    z[0,3,1]  R440      -5.6944328546524048e-01
    z[0,3,1]  R441      -7.9107505083084106e-01
    z[0,3,1]  R442      -8.3547854423522949e-01
    z[0,3,1]  R443      -6.2728846073150635e-01
    z[0,3,1]  R444      -1.5642635524272919e-01
    z[0,3,1]  R445      -0.408250629901886
    z[0,3,1]  R446      1.0886962711811066e-01
    z[0,3,1]  R447      -6.0041254758834839e-01
    z[0,3,1]  R448      1.5060398727655411e-03
    z[0,3,1]  R449      -4.0743622183799744e-01
    z[0,3,1]  R450      -1.9889074563980103e-01
    z[0,3,1]  R451      -3.1165421009063721e-01
    z[0,3,1]  R452      4.2386922240257263e-01
    z[0,3,1]  R453      -0.0718371719121933
    z[0,3,1]  R454      -8.9955933392047882e-02
    z[0,3,1]  R455      5.7048797607421875e-02
    z[0,3,1]  R456      -1.1104349046945572e-01
    z[0,3,1]  R457      -1.6461621224880219e-01
    z[0,3,1]  R458      -4.3762156367301941e-01
    z[0,3,1]  R459      1.6248683631420135e-01
    z[0,3,1]  R460      1.1134830117225647e-01
    z[0,3,1]  R461      -7.3070541024208069e-02
    z[0,3,1]  R462      9.6246063709259033e-02
    z[0,3,1]  R463      1.1782778799533844e-01
    z[0,3,1]  R464      2.7041202783584595e-01
    z[0,3,1]  R465      -5.4209005832672119e-01
    z[0,3,1]  R466      3.8884720206260681e-01
    z[0,3,1]  R467      -3.4910616278648376e-01
    z[0,3,1]  R468      5.5928987264633179e-01
    z[0,3,1]  R469      4.4444081187248230e-01
    z[0,3,1]  R470      0.575400710105896
    z[0,3,1]  R471      4.9236461520195007e-01
    z[0,3,1]  R472      3.6707437038421631e-01
    z[0,3,1]  R473      -0.401419073343277
    z[0,3,1]  R474      5.9140056371688843e-01
    z[0,3,1]  R475      1.9477939605712891e-01
    z[0,3,1]  R476      5.6616431474685669e-01
    z[0,3,1]  R477      4.7562189400196075e-02
    z[0,3,1]  R478      2.3031720519065857e-01
    z[0,3,1]  R479      -1.3365231454372406e-01
    z[0,3,1]  R480      3.5345628857612610e-02
    z[0,3,1]  R481      -5.4927694797515869e-01
    z[0,3,1]  R482      -2.5580203533172607e-01
    z[0,3,1]  R483      -2.9031846672296524e-02
    z[0,3,1]  R484      2.1840266883373260e-01
    z[0,3,1]  R485      1.0058821178972721e-02
    z[0,3,1]  R486      -4.8622789978981018e-01
    z[0,3,1]  R487      2.0794808864593506e-01
    z[0,3,1]  R488      4.7027045488357544e-01
    z[0,3,1]  R489      -7.0744462311267853e-02
    z[0,3,1]  R490      -2.3843885958194733e-01
    z[0,3,1]  R491      -1.1425514519214630e-01
    z[0,3,1]  R492      -4.8765793442726135e-01
    z[0,3,1]  R493      -2.7695251628756523e-02
    z[0,3,1]  R494      -4.5463964343070984e-02
    z[0,3,1]  R495      3.7216268479824066e-02
    z[0,3,1]  R496      0.563527524471283
    z[0,3,1]  R497      2.7319166064262390e-01
    z[0,3,1]  R498      -1.4385347068309784e-01
    z[0,3,1]  R499      7.2615332901477814e-03
    z[0,3,1]  R500      8.1111228466033936e-01
    z[0,3,1]  R501      3.2436794042587280e-01
    z[0,3,1]  R502      4.0905106067657471e-01
    z[0,3,1]  R503      -6.5500330924987793e-01
    z[0,3,1]  R504      3.4475263953208923e-01
    z[0,3,1]  R505      1.8451488018035889e-01
    z[0,3,1]  R506      -3.3994078636169434e-01
    z[0,3,1]  R507      4.7159090638160706e-01
    z[0,3,1]  R508      -2.5233197212219238e-01
    z[0,3,1]  R509      1.8022919073700905e-02
    z[0,3,1]  R510      0.0539570190012455
    z[0,3,1]  R511      1.6202329099178314e-01
    z[0,3,1]  R512      2.8932240605354309e-01
    z[0,3,1]  R513      -7.3883497714996338e-01
    z[0,3,1]  R514      -1.1312500573694706e-03
    z[0,3,1]  R515      2.0633409917354584e-01
    z[0,3,1]  R516      -0.57985520362854
    z[0,3,1]  R517      5.2900129556655884e-01
    z[0,3,1]  R518      -0.422419011592865
    z[0,3,1]  R519      -3.2618728280067444e-01
    z[0,3,1]  R520      3.6254149675369263e-01
    z[0,3,1]  R521      1.5918913483619690e-01
    z[0,3,1]  R522      9.1630041599273682e-02
    z[0,3,1]  R523      1.0925793647766113e-01
    z[0,3,1]  R524      -1.5200471878051758e-01
    z[0,3,1]  R525      -2.1054264903068542e-01
    z[0,3,1]  R526      2.1635462343692780e-01
    z[0,3,1]  R527      -3.5965493321418762e-01
    z[0,3,1]  R528      -5.1427793502807617e-01
    z[0,3,1]  R529      -3.7195730209350586e-01
    z[0,3,1]  R530      -6.8676269054412842e-01
    z[0,3,1]  R531      1.7070958018302917e-01
    z[0,3,1]  R532      2.0195762813091278e-01
    z[0,3,1]  R533      -6.7172354459762573e-01
    z[0,3,1]  R534      2.9508890584111214e-02
    z[0,3,1]  R535      2.8312578797340393e-01
    z[0,3,2]  R4        -1
    z[0,3,2]  R31       1
    z[0,3,2]  R379      -1
    z[0,3,2]  R380      1
    z[0,3,2]  R389      1.5083377063274384e-01
    z[0,3,2]  R390      2.3986802995204926e-01
    z[0,3,2]  R391      -1.8829308450222015e-01
    z[0,3,2]  R392      2.4266245961189270e-01
    z[0,3,2]  R393      -3.3070594072341919e-01
    z[0,3,2]  R394      3.0206015706062317e-01
    z[0,3,2]  R395      -1.5245966613292694e-01
    z[0,3,2]  R396      1.9436698406934738e-02
    z[0,3,2]  R397      -3.4611273556947708e-02
    z[0,3,2]  R398      -5.8791655302047729e-01
    z[0,3,2]  R399      -6.1598002910614014e-01
    z[0,3,2]  R400      -3.5712572932243347e-01
    z[0,3,2]  R401      -2.3911079764366150e-01
    z[0,3,2]  R402      -3.2284760475158691e-01
    z[0,3,2]  R403      2.2259363532066345e-01
    z[0,3,2]  R404      -5.8785039186477661e-01
    z[0,3,2]  R405      -5.2049297094345093e-01
    z[0,3,2]  R406      -8.4991287440061569e-03
    z[0,3,2]  R407      -5.2151817083358765e-01
    z[0,3,2]  R408      5.2224820852279663e-01
    z[0,3,2]  R409      -4.9242395907640457e-02
    z[0,3,2]  R410      1.6663928329944611e-01
    z[0,3,2]  R411      2.8458821773529053e-01
    z[0,3,2]  R412      -0.265234112739563
    z[0,3,2]  R413      -2.2192781791090965e-02
    z[0,3,2]  R414      6.0554448515176773e-02
    z[0,3,2]  R415      2.0031755790114403e-02
    z[0,3,2]  R416      3.7380585074424744e-01
    z[0,3,2]  R417      5.7075881958007812e-01
    z[0,3,2]  R418      1.7242784798145294e-01
    z[0,3,2]  R419      1.9863437116146088e-01
    z[0,3,2]  R420      -3.7209963798522949e-01
    z[0,3,2]  R421      1.9737100601196289e-01
    z[0,3,2]  R422      4.5568180084228516e-01
    z[0,3,2]  R423      1.1098874360322952e-01
    z[0,3,2]  R424      -2.9603496193885803e-01
    z[0,3,2]  R425      5.4920607805252075e-01
    z[0,3,2]  R426      3.7952467799186707e-01
    z[0,3,2]  R427      1.7176325619220734e-01
    z[0,3,2]  R428      5.3085041046142578e-01
    z[0,3,2]  R429      -2.8079429268836975e-01
    z[0,3,2]  R430      -4.2123457789421082e-01
    z[0,3,2]  R431      0.408405065536499
    z[0,3,2]  R432      7.0510065555572510e-01
    z[0,3,2]  R433      9.5214679837226868e-02
    z[0,3,2]  R434      1.9265627861022949e-01
    z[0,3,2]  R435      1.5138559043407440e-01
    z[0,3,2]  R436      4.2132866382598877e-01
    z[0,3,2]  R437      -1.5476787090301514e-01
    z[0,3,2]  R438      2.9042625427246094e-01
    z[0,3,2]  R439      -1.1957526206970215e-01
    z[0,3,2]  R440      7.2208935022354126e-01
    z[0,3,2]  R441      4.5464840531349182e-01
    z[0,3,2]  R442      2.3715527355670929e-01
    z[0,3,2]  R443      7.1603232622146606e-01
    z[0,3,2]  R444      4.1160178184509277e-01
    z[0,3,2]  R445      0.485909104347229
    z[0,3,2]  R446      7.6738965511322021e-01
    z[0,3,2]  R447      -2.7881422638893127e-01
    z[0,3,2]  R448      -1.6056613624095917e-01
    z[0,3,2]  R449      4.1041958332061768e-01
    z[0,3,2]  R450      4.8243105411529541e-01
    z[0,3,2]  R451      5.3352898359298706e-01
    z[0,3,2]  R452      -6.2303669750690460e-02
    z[0,3,2]  R453      -6.2953778542578220e-03
    z[0,3,2]  R454      -6.2106844037771225e-02
    z[0,3,2]  R455      2.6103788614273071e-01
    z[0,3,2]  R456      1.2965458631515503e-01
    z[0,3,2]  R457      -4.6965414285659790e-01
    z[0,3,2]  R458      2.0638918876647949e-01
    z[0,3,2]  R459      1.6082639992237091e-01
    z[0,3,2]  R460      -6.0505729913711548e-01
    z[0,3,2]  R461      -7.0326203107833862e-01
    z[0,3,2]  R462      -8.3815455436706543e-01
    z[0,3,2]  R463      -6.1573606729507446e-01
    z[0,3,2]  R464      4.2432656884193420e-01
    z[0,3,2]  R465      -3.0441206693649292e-01
    z[0,3,2]  R466      1.5811249613761902e-01
    z[0,3,2]  R467      0.376202791929245
    z[0,3,2]  R468      5.0575062632560730e-02
    z[0,3,2]  R469      2.1942797303199768e-01
    z[0,3,2]  R470      -4.8627737164497375e-01
    z[0,3,2]  R471      -3.4369108080863953e-01
    z[0,3,2]  R472      1.2670375406742096e-01
    z[0,3,2]  R473      -2.3087514936923981e-01
    z[0,3,2]  R474      -4.0249493718147278e-01
    z[0,3,2]  R475      7.9355299472808838e-01
    z[0,3,2]  R476      -6.2529988586902618e-02
    z[0,3,2]  R477      -2.4667935073375702e-01
    z[0,3,2]  R478      -2.9975825548171997e-01
    z[0,3,2]  R479      -1.9519220292568207e-01
    z[0,3,2]  R480      -3.2596173882484436e-01
    z[0,3,2]  R481      5.3519034385681152e-01
    z[0,3,2]  R482      4.2127409577369690e-01
    z[0,3,2]  R483      1.2512315809726715e-01
    z[0,3,2]  R484      3.2611471414566040e-01
    z[0,3,2]  R485      2.5055831670761108e-01
    z[0,3,2]  R486      3.1556525826454163e-01
    z[0,3,2]  R487      -2.1326968073844910e-01
    z[0,3,2]  R488      -2.4498504400253296e-01
    z[0,3,2]  R489      9.8096147179603577e-02
    z[0,3,2]  R490      5.0670439004898071e-01
    z[0,3,2]  R491      5.9198117256164551e-01
    z[0,3,2]  R492      -4.0576282143592834e-01
    z[0,3,2]  R493      -4.5886853337287903e-01
    z[0,3,2]  R494      -4.3549299240112305e-01
    z[0,3,2]  R495      -7.1385937929153442e-01
    z[0,3,2]  R496      -1.5301067614927888e-03
    z[0,3,2]  R497      -4.0854278206825256e-01
    z[0,3,2]  R498      2.4864038452506065e-02
    z[0,3,2]  R499      3.0922656878829002e-02
    z[0,3,2]  R500      -0.0631827712059021
    z[0,3,2]  R501      6.1961793899536133e-01
    z[0,3,2]  R502      -4.2903009057044983e-01
    z[0,3,2]  R503      1.7989465594291687e-01
    z[0,3,2]  R504      3.3121243119239807e-01
    z[0,3,2]  R505      2.1600204706192017e-01
    z[0,3,2]  R506      6.9001567363739014e-01
    z[0,3,2]  R507      -2.2462388500571251e-02
    z[0,3,2]  R508      7.2278487682342529e-01
    z[0,3,2]  R509      -2.3946358263492584e-01
    z[0,3,2]  R510      -5.9312063455581665e-01
    z[0,3,2]  R511      7.0781731605529785e-01
    z[0,3,2]  R512      1.1221123486757278e-01
    z[0,3,2]  R513      1.1881493777036667e-01
    z[0,3,2]  R514      2.9405781626701355e-01
    z[0,3,2]  R515      -1.0706714354455471e-02
    z[0,3,2]  R516      2.5668564438819885e-01
    z[0,3,2]  R517      -3.7382226437330246e-02
    z[0,3,2]  R518      6.8933749198913574e-01
    z[0,3,2]  R519      -3.1472650170326233e-01
    z[0,3,2]  R520      -3.4611481428146362e-01
    z[0,3,2]  R521      7.3608571290969849e-01
    z[0,3,2]  R522      3.4660151600837708e-01
    z[0,3,2]  R523      3.5235700011253357e-01
    z[0,3,2]  R524      -3.8247801363468170e-02
    z[0,3,2]  R525      -1.2653575837612152e-01
    z[0,3,2]  R526      4.0381708741188049e-01
    z[0,3,2]  R527      6.5360546112060547e-01
    z[0,3,2]  R528      5.5261862277984619e-01
    z[0,3,2]  R529      8.4787815809249878e-01
    z[0,3,2]  R530      1.0278853029012680e-01
    z[0,3,2]  R531      -1.9657596945762634e-01
    z[0,3,2]  R532      -1.7647102475166321e-01
    z[0,3,2]  R533      4.9150779843330383e-01
    z[0,3,2]  R534      3.6729894578456879e-02
    z[0,3,2]  R535      -1.0624358803033829e-01
    z[0,3,3]  R5        -1
    z[0,3,3]  R32       1
    z[0,3,3]  R381      -1
    z[0,3,3]  R382      1
    z[0,3,3]  R389      -4.8630633950233459e-01
    z[0,3,3]  R390      -9.0782207250595093e-01
    z[0,3,3]  R391      -7.7078616619110107e-01
    z[0,3,3]  R392      2.0572718232870102e-02
    z[0,3,3]  R393      -3.4895248245447874e-03
    z[0,3,3]  R394      -1.3784939050674438e-01
    z[0,3,3]  R395      -1.7129622399806976e-01
    z[0,3,3]  R396      -1.2891253829002380e-01
    z[0,3,3]  R397      -5.7065492868423462e-01
    z[0,3,3]  R398      2.2236967086791992e-01
    z[0,3,3]  R399      1.8083423376083374e-01
    z[0,3,3]  R400      -6.9698132574558258e-02
    z[0,3,3]  R401      1.4075244963169098e-01
    z[0,3,3]  R402      4.2891070246696472e-01
    z[0,3,3]  R403      0.380641371011734
    z[0,3,3]  R404      0.0773368775844574
    z[0,3,3]  R405      3.2796174287796021e-01
    z[0,3,3]  R406      -3.2630673050880432e-01
    z[0,3,3]  R407      2.8481978178024292e-01
    z[0,3,3]  R408      2.4042797088623047e-01
    z[0,3,3]  R409      -1.6804021596908569e-01
    z[0,3,3]  R410      -2.1764262020587921e-01
    z[0,3,3]  R411      -1.5559849143028259e-01
    z[0,3,3]  R412      -2.0663103461265564e-01
    z[0,3,3]  R413      -4.0528619289398193e-01
    z[0,3,3]  R414      -3.3417305350303650e-01
    z[0,3,3]  R415      -6.7320454120635986e-01
    z[0,3,3]  R416      -2.5686460733413696e-01
    z[0,3,3]  R417      -2.0680793095380068e-03
    z[0,3,3]  R418      -4.6091657876968384e-01
    z[0,3,3]  R419      -6.1763554811477661e-01
    z[0,3,3]  R420      -2.4363413453102112e-01
    z[0,3,3]  R421      4.7199773788452148e-01
    z[0,3,3]  R422      -1.1488460004329681e-01
    z[0,3,3]  R423      9.7651846706867218e-02
    z[0,3,3]  R424      4.2816668748855591e-01
    z[0,3,3]  R425      3.2782697677612305e-01
    z[0,3,3]  R426      -4.7279921174049377e-01
    z[0,3,3]  R427      -5.6368038058280945e-02
    z[0,3,3]  R428      -5.9518980979919434e-01
    z[0,3,3]  R429      -1.8755196034908295e-01
    z[0,3,3]  R430      -2.4840892851352692e-01
    z[0,3,3]  R431      -2.1829817444086075e-02
    z[0,3,3]  R432      2.9045999050140381e-01
    z[0,3,3]  R433      -6.3881975412368774e-01
    z[0,3,3]  R434      7.2736620903015137e-01
    z[0,3,3]  R435      0.645383358001709
    z[0,3,3]  R436      6.5305101871490479e-01
    z[0,3,3]  R437      -4.8276394605636597e-01
    z[0,3,3]  R438      8.8347822427749634e-01
    z[0,3,3]  R439      5.1070757210254669e-02
    z[0,3,3]  R440      1.2201625853776932e-01
    z[0,3,3]  R441      1.0796375572681427e-01
    z[0,3,3]  R442      -4.6345632523298264e-02
    z[0,3,3]  R443      -2.7514001727104187e-01
    z[0,3,3]  R444      -4.4121104478836060e-01
    z[0,3,3]  R445      6.0426419973373413e-01
    z[0,3,3]  R446      -0.250192791223526
    z[0,3,3]  R447      -4.0110346674919128e-01
    z[0,3,3]  R448      8.6320447921752930e-01
    z[0,3,3]  R449      -2.7057039737701416e-01
    z[0,3,3]  R450      2.2242200374603271e-01
    z[0,3,3]  R451      -6.0245823860168457e-01
    z[0,3,3]  R452      -5.7151901721954346e-01
    z[0,3,3]  R453      -4.4974225759506226e-01
    z[0,3,3]  R454      -3.3146941661834717e-01
    z[0,3,3]  R455      -3.7510424852371216e-01
    z[0,3,3]  R456      3.1618601083755493e-01
    z[0,3,3]  R457      -1.8194037675857544e-01
    z[0,3,3]  R458      3.8946425914764404e-01
    z[0,3,3]  R459      0.081110879778862
    z[0,3,3]  R460      1.6585490107536316e-01
    z[0,3,3]  R461      3.3532249927520752e-01
    z[0,3,3]  R462      2.4041488766670227e-01
    z[0,3,3]  R463      5.9478312730789185e-01
    z[0,3,3]  R464      3.0572825670242310e-01
    z[0,3,3]  R465      -9.2390157282352448e-02
    z[0,3,3]  R466      -7.5568921864032745e-02
    z[0,3,3]  R467      -9.7693480551242828e-02
    z[0,3,3]  R468      -1.7162151634693146e-01
    z[0,3,3]  R469      -1.2340348213911057e-01
    z[0,3,3]  R470      -3.6988846957683563e-02
    z[0,3,3]  R471      -2.4959733709692955e-02
    z[0,3,3]  R472      -5.6879818439483643e-03
    z[0,3,3]  R473      4.3359389901161194e-01
    z[0,3,3]  R474      -1.2845497578382492e-02
    z[0,3,3]  R475      -1.7646154761314392e-01
    z[0,3,3]  R476      -4.5771875977516174e-01
    z[0,3,3]  R477      -4.7059425711631775e-01
    z[0,3,3]  R478      2.9010131955146790e-01
    z[0,3,3]  R479      -1.5414546430110931e-01
    z[0,3,3]  R480      2.8731770813465118e-02
    z[0,3,3]  R481      5.1945778541266918e-03
    z[0,3,3]  R482      -0.0582304522395134
    z[0,3,3]  R483      -2.7886587381362915e-01
    z[0,3,3]  R484      1.9689889624714851e-02
    z[0,3,3]  R485      -1.2389860302209854e-01
    z[0,3,3]  R486      2.3909914493560791e-01
    z[0,3,3]  R487      -8.3357393741607666e-01
    z[0,3,3]  R488      -5.2888363599777222e-01
    z[0,3,3]  R489      -6.7985409498214722e-01
    z[0,3,3]  R490      6.0640448331832886e-01
    z[0,3,3]  R491      5.7174468040466309e-01
    z[0,3,3]  R492      -7.3191873729228973e-02
    z[0,3,3]  R493      2.1180571615695953e-01
    z[0,3,3]  R494      -2.2566859424114227e-01
    z[0,3,3]  R495      -1.3528390228748322e-01
    z[0,3,3]  R496      -3.4971076250076294e-01
    z[0,3,3]  R497      -1.2376046925783157e-01
    z[0,3,3]  R498      -1.3576015830039978e-02
    z[0,3,3]  R499      -6.5821069478988647e-01
    z[0,3,3]  R500      -3.2483169436454773e-01
    z[0,3,3]  R501      -4.0063586831092834e-01
    z[0,3,3]  R502      3.1285667419433594e-01
    z[0,3,3]  R503      1.3730789721012115e-01
    z[0,3,3]  R504      -1.4332598447799683e-01
    z[0,3,3]  R505      3.1519293785095215e-01
    z[0,3,3]  R506      -9.5184780657291412e-02
    z[0,3,3]  R507      2.4369803071022034e-01
    z[0,3,3]  R508      0.348730206489563
    z[0,3,3]  R509      0.451188862323761
    z[0,3,3]  R510      3.3942395448684692e-01
    z[0,3,3]  R511      -6.7075587809085846e-02
    z[0,3,3]  R512      1.8302203714847565e-01
    z[0,3,3]  R513      1.1391800642013550e-01
    z[0,3,3]  R514      1.4862108230590820e-01
    z[0,3,3]  R515      -3.2110220193862915e-01
    z[0,3,3]  R516      4.3260562419891357e-01
    z[0,3,3]  R517      -6.7774200439453125e-01
    z[0,3,3]  R518      -4.0927335619926453e-01
    z[0,3,3]  R519      -1.3049960136413574e-02
    z[0,3,3]  R520      -0.502071738243103
    z[0,3,3]  R521      -9.1563336551189423e-02
    z[0,3,3]  R522      -1.4747790992259979e-01
    z[0,3,3]  R523      -7.6781474053859711e-02
    z[0,3,3]  R524      1.6723388433456421e-01
    z[0,3,3]  R525      1.7311847209930420e-01
    z[0,3,3]  R526      -7.0427286624908447e-01
    z[0,3,3]  R527      5.3233772516250610e-01
    z[0,3,3]  R528      4.6594947576522827e-01
    z[0,3,3]  R529      -3.8813658058643341e-02
    z[0,3,3]  R530      -2.1370275318622589e-01
    z[0,3,3]  R531      2.2169852256774902e-01
    z[0,3,3]  R532      1.7748758196830750e-02
    z[0,3,3]  R533      2.0500671863555908e-01
    z[0,3,3]  R534      -8.5821323096752167e-02
    z[0,3,3]  R535      1.5121363103389740e-01
    z[0,3,4]  R6        -1
    z[0,3,4]  R33       1
    z[0,3,4]  R383      -1
    z[0,3,4]  R384      1
    z[0,3,4]  R389      2.0659589767456055e-01
    z[0,3,4]  R390      1.2071436643600464e-01
    z[0,3,4]  R391      -2.7697184681892395e-01
    z[0,3,4]  R392      -2.2041415795683861e-02
    z[0,3,4]  R393      -1.4359714090824127e-01
    z[0,3,4]  R394      -1.9014884531497955e-01
    z[0,3,4]  R395      -1.0998731106519699e-01
    z[0,3,4]  R396      3.2825049757957458e-01
    z[0,3,4]  R397      -8.3933107554912567e-02
    z[0,3,4]  R398      1.6483344137668610e-02
    z[0,3,4]  R399      -2.2064687311649323e-01
    z[0,3,4]  R400      -2.0545309782028198e-01
    z[0,3,4]  R401      3.3019462227821350e-01
    z[0,3,4]  R402      2.6482102274894714e-01
    z[0,3,4]  R403      -3.3414953947067261e-01
    z[0,3,4]  R404      4.2259556055068970e-01
    z[0,3,4]  R405      -9.9161945283412933e-02
    z[0,3,4]  R406      -4.5455410145223141e-03
    z[0,3,4]  R407      3.9835435152053833e-01
    z[0,3,4]  R408      3.1894508004188538e-01
    z[0,3,4]  R409      -8.5877306759357452e-02
    z[0,3,4]  R410      -2.6973801851272583e-01
    z[0,3,4]  R411      -2.0720811560750008e-02
    z[0,3,4]  R412      4.0071615576744080e-01
    z[0,3,4]  R413      4.1808298230171204e-01
    z[0,3,4]  R414      5.7537477463483810e-02
    z[0,3,4]  R415      3.4836444258689880e-01
    z[0,3,4]  R416      3.7266877293586731e-01
    z[0,3,4]  R417      0.363534539937973
    z[0,3,4]  R418      -7.2346520423889160e-01
    z[0,3,4]  R419      2.0305566489696503e-01
    z[0,3,4]  R420      2.0270688831806183e-01
    z[0,3,4]  R421      -1.0040581226348877e-01
    z[0,3,4]  R422      -2.6142343878746033e-01
    z[0,3,4]  R423      -1.0947328805923462e-01
    z[0,3,4]  R424      2.3419323563575745e-01
    z[0,3,4]  R425      -3.2322630286216736e-01
    z[0,3,4]  R426      -2.1963614225387573e-01
    z[0,3,4]  R427      -2.3658205568790436e-01
    z[0,3,4]  R428      -1.5085247159004211e-01
    z[0,3,4]  R429      -6.5335296094417572e-02
    z[0,3,4]  R430      -5.7643568515777588e-01
    z[0,3,4]  R431      -1.8529847264289856e-01
    z[0,3,4]  R432      -2.1317061781883240e-01
    z[0,3,4]  R433      9.3847788870334625e-02
    z[0,3,4]  R434      2.6367539167404175e-01
    z[0,3,4]  R435      -5.5896721780300140e-02
    z[0,3,4]  R436      2.5234678387641907e-01
    z[0,3,4]  R437      4.5455864071846008e-01
    z[0,3,4]  R438      1.9800759851932526e-01
    z[0,3,4]  R439      -2.6005905866622925e-01
    z[0,3,4]  R440      -2.1363671123981476e-01
    z[0,3,4]  R441      7.0633560419082642e-02
    z[0,3,4]  R442      -1.4188164472579956e-01
    z[0,3,4]  R443      9.3043945729732513e-02
    z[0,3,4]  R444      5.0262737274169922e-01
    z[0,3,4]  R445      1.1373239010572433e-01
    z[0,3,4]  R446      4.0888068079948425e-01
    z[0,3,4]  R447      4.2495880275964737e-02
    z[0,3,4]  R448      -3.8691172003746033e-01
    z[0,3,4]  R449      -4.2647701501846313e-01
    z[0,3,4]  R450      6.4936959743499756e-01
    z[0,3,4]  R451      -2.6310819387435913e-01
    z[0,3,4]  R452      -6.3517436385154724e-02
    z[0,3,4]  R453      1.3910956680774689e-01
    z[0,3,4]  R454      -1.1195933073759079e-01
    z[0,3,4]  R455      0.00340811675414443
    z[0,3,4]  R456      2.2796740755438805e-02
    z[0,3,4]  R457      2.9402857646346092e-02
    z[0,3,4]  R458      -2.3719245195388794e-01
    z[0,3,4]  R459      3.0050572752952576e-01
    z[0,3,4]  R460      2.9327198863029480e-01
    z[0,3,4]  R461      1.3792613148689270e-01
    z[0,3,4]  R462      2.5427341461181641e-02
    z[0,3,4]  R463      0.118742436170578
    z[0,3,4]  R464      -3.8816636800765991e-01
    z[0,3,4]  R465      -1.4444314874708652e-02
    z[0,3,4]  R466      2.9218655824661255e-01
    z[0,3,4]  R467      1.4821581542491913e-01
    z[0,3,4]  R468      2.9983353614807129e-01
    z[0,3,4]  R469      -1.4140526950359344e-01
    z[0,3,4]  R470      -7.0724025368690491e-02
    z[0,3,4]  R471      8.9530251920223236e-02
    z[0,3,4]  R472      -2.9376211762428284e-01
    z[0,3,4]  R473      -6.6264927387237549e-02
    z[0,3,4]  R474      -4.9960368871688843e-01
    z[0,3,4]  R475      4.7424253076314926e-02
    z[0,3,4]  R476      -5.2696573734283447e-01
    z[0,3,4]  R477      0.225468710064888
    z[0,3,4]  R478      5.3126358985900879e-01
    z[0,3,4]  R479      -0.645107090473175
    z[0,3,4]  R480      -5.7966804504394531e-01
    z[0,3,4]  R481      -5.1796585321426392e-01
    z[0,3,4]  R482      -2.2337383031845093e-01
    z[0,3,4]  R483      1.0597323998808861e-02
    z[0,3,4]  R484      -3.5800719261169434e-01
    z[0,3,4]  R485      -3.9284643530845642e-01
    z[0,3,4]  R486      -5.3778970241546631e-01
    z[0,3,4]  R487      1.9459785521030426e-01
    z[0,3,4]  R488      1.0053319483995438e-01
    z[0,3,4]  R489      -2.2989268600940704e-01
    z[0,3,4]  R490      -2.9182881116867065e-01
    z[0,3,4]  R491      -2.7246505022048950e-01
    z[0,3,4]  R492      -4.6303052455186844e-02
    z[0,3,4]  R493      -5.5385154485702515e-01
    z[0,3,4]  R494      -3.7276622653007507e-01
    z[0,3,4]  R495      -0.343077689409256
    z[0,3,4]  R496      4.8305603861808777e-01
    z[0,3,4]  R497      -1.0203192383050919e-01
    z[0,3,4]  R498      -0.0925784781575203
    z[0,3,4]  R499      -1.8663829565048218e-01
    z[0,3,4]  R500      8.7267801165580750e-02
    z[0,3,4]  R501      -2.6311576366424561e-01
    z[0,3,4]  R502      1.6780454665422440e-02
    z[0,3,4]  R503      2.5766485929489136e-01
    z[0,3,4]  R504      7.5200520455837250e-02
    z[0,3,4]  R505      4.6823222190141678e-02
    z[0,3,4]  R506      5.6598985195159912e-01
    z[0,3,4]  R507      -3.5769158601760864e-01
    z[0,3,4]  R508      1.4069169759750366e-01
    z[0,3,4]  R509      0.452584832906723
    z[0,3,4]  R510      1.6116510331630707e-01
    z[0,3,4]  R511      -3.5327225923538208e-01
    z[0,3,4]  R512      3.8043644279241562e-02
    z[0,3,4]  R513      -1.6989172995090485e-01
    z[0,3,4]  R514      -1.8061298131942749e-01
    z[0,3,4]  R515      -3.0069085955619812e-01
    z[0,3,4]  R516      2.5757661461830139e-01
    z[0,3,4]  R517      -3.4258410334587097e-01
    z[0,3,4]  R518      0.00994244497269392
    z[0,3,4]  R519      -1.0714717209339142e-01
    z[0,3,4]  R520      1.4907805621623993e-01
    z[0,3,4]  R521      4.5438849925994873e-01
    z[0,3,4]  R522      8.5485167801380157e-02
    z[0,3,4]  R523      -1.6078485175967216e-02
    z[0,3,4]  R524      -4.3499547243118286e-01
    z[0,3,4]  R525      -2.1023973822593689e-01
    z[0,3,4]  R526      7.9031303524971008e-02
    z[0,3,4]  R527      1.9675374031066895e-01
    z[0,3,4]  R528      -2.6867267489433289e-01
    z[0,3,4]  R529      1.1945463716983795e-02
    z[0,3,4]  R530      -4.1314724087715149e-01
    z[0,3,4]  R531      2.9950621537864208e-03
    z[0,3,4]  R532      -9.5723450183868408e-02
    z[0,3,4]  R533      -1.4593677222728729e-01
    z[0,3,4]  R534      -2.2758300602436066e-01
    z[0,3,4]  R535      -2.9370945692062378e-01
    z[0,3,5]  R7        -1
    z[0,3,5]  R34       1
    z[0,3,5]  R385      -1
    z[0,3,5]  R386      1
    z[0,3,5]  R389      -5.0445652008056641e-01
    z[0,3,5]  R390      -7.6856710016727448e-02
    z[0,3,5]  R391      2.5028528645634651e-02
    z[0,3,5]  R392      -3.2930124551057816e-02
    z[0,3,5]  R393      -1.1862007528543472e-01
    z[0,3,5]  R394      2.8669700026512146e-01
    z[0,3,5]  R395      8.7456069886684418e-03
    z[0,3,5]  R396      9.1848298907279968e-02
    z[0,3,5]  R397      3.6754995584487915e-01
    z[0,3,5]  R398      2.0405404269695282e-01
    z[0,3,5]  R399      0.280277818441391
    z[0,3,5]  R400      -2.3130537569522858e-01
    z[0,3,5]  R401      3.6788681149482727e-01
    z[0,3,5]  R402      -3.6726880073547363e-01
    z[0,3,5]  R403      2.8330111503601074e-01
    z[0,3,5]  R404      -4.9175322055816650e-02
    z[0,3,5]  R405      -4.5591026544570923e-02
    z[0,3,5]  R406      3.1311208009719849e-01
    z[0,3,5]  R407      4.0186995267868042e-01
    z[0,3,5]  R408      -1.1770709417760372e-02
    z[0,3,5]  R409      3.1503564119338989e-01
    z[0,3,5]  R410      2.5389587879180908e-01
    z[0,3,5]  R411      7.6005801558494568e-02
    z[0,3,5]  R412      -1.4338185079395771e-02
    z[0,3,5]  R413      1.1591343581676483e-01
    z[0,3,5]  R414      -6.0779560357332230e-02
    z[0,3,5]  R415      2.6166474819183350e-01
    z[0,3,5]  R416      3.6587905883789062e-01
    z[0,3,5]  R417      1.5322747826576233e-01
    z[0,3,5]  R418      -3.3494135737419128e-01
    z[0,3,5]  R419      -3.2431003451347351e-01
    z[0,3,5]  R420      -4.3392094969749451e-01
    z[0,3,5]  R421      1.3375861942768097e-01
    z[0,3,5]  R422      -6.6862389445304871e-02
    z[0,3,5]  R423      -4.9372907727956772e-02
    z[0,3,5]  R424      -2.2421722114086151e-01
    z[0,3,5]  R425      -3.4554848074913025e-01
    z[0,3,5]  R426      -9.1310754418373108e-02
    z[0,3,5]  R427      1.6689199209213257e-01
    z[0,3,5]  R428      1.0497282445430756e-01
    z[0,3,5]  R429      -2.2765980660915375e-01
    z[0,3,5]  R430      -2.7418437600135803e-01
    z[0,3,5]  R431      3.8546571135520935e-01
    z[0,3,5]  R432      8.5960216820240021e-02
    z[0,3,5]  R433      -3.0100712180137634e-01
    z[0,3,5]  R434      3.7864178419113159e-01
    z[0,3,5]  R435      4.0323731303215027e-01
    z[0,3,5]  R436      4.7610646486282349e-01
    z[0,3,5]  R437      -4.0040472149848938e-01
    z[0,3,5]  R438      -3.4990664571523666e-02
    z[0,3,5]  R439      -6.4122414588928223e-01
    z[0,3,5]  R440      7.6918698847293854e-02
    z[0,3,5]  R441      3.3405745029449463e-01
    z[0,3,5]  R442      -2.5700443983078003e-01
    z[0,3,5]  R443      1.7790308222174644e-02
    z[0,3,5]  R444      1.7716838419437408e-01
    z[0,3,5]  R445      4.1874179244041443e-01
    z[0,3,5]  R446      -5.2343491464853287e-02
    z[0,3,5]  R447      1.1070173233747482e-01
    z[0,3,5]  R448      1.1411818861961365e-01
    z[0,3,5]  R449      -4.3386217951774597e-01
    z[0,3,5]  R450      -2.1251513063907623e-01
    z[0,3,5]  R451      -1.6088853776454926e-01
    z[0,3,5]  R452      0.348357617855072
    z[0,3,5]  R453      -3.7620836496353149e-01
    z[0,3,5]  R454      -3.0073845386505127e-01
    z[0,3,5]  R455      -1.9433495402336121e-01
    z[0,3,5]  R456      3.8035976886749268e-01
    z[0,3,5]  R457      -4.6719394624233246e-02
    z[0,3,5]  R458      6.0069918632507324e-01
    z[0,3,5]  R459      1.8863563239574432e-01
    z[0,3,5]  R460      4.0948572754859924e-01
    z[0,3,5]  R461      1.7991185188293457e-01
    z[0,3,5]  R462      0.0920541062951088
    z[0,3,5]  R463      1.2588837742805481e-01
    z[0,3,5]  R464      4.7277545928955078e-01
    z[0,3,5]  R465      5.9156739711761475e-01
    z[0,3,5]  R466      -2.3151063919067383e-01
    z[0,3,5]  R467      0.457425594329834
    z[0,3,5]  R468      2.0204125344753265e-01
    z[0,3,5]  R469      0.598791241645813
    z[0,3,5]  R470      -2.3754674196243286e-01
    z[0,3,5]  R471      4.9399951100349426e-01
    z[0,3,5]  R472      3.6819356679916382e-01
    z[0,3,5]  R473      2.2365932166576385e-01
    z[0,3,5]  R474      1.4212416112422943e-01
    z[0,3,5]  R475      -6.7222595214843750e-02
    z[0,3,5]  R476      -2.0196711644530296e-02
    z[0,3,5]  R477      -4.8286926001310349e-02
    z[0,3,5]  R478      -1.3389208912849426e-01
    z[0,3,5]  R479      2.1183808147907257e-01
    z[0,3,5]  R480      8.8243380188941956e-02
    z[0,3,5]  R481      1.2243386358022690e-01
    z[0,3,5]  R482      2.9019605368375778e-02
    z[0,3,5]  R483      1.3056750595569611e-01
    z[0,3,5]  R484      -1.7010171711444855e-01
    z[0,3,5]  R485      -3.9907835423946381e-02
    z[0,3,5]  R486      1.8827447667717934e-02
    z[0,3,5]  R487      -1.8242919445037842e-01
    z[0,3,5]  R488      -4.0729236602783203e-01
    z[0,3,5]  R489      1.6880555450916290e-01
    z[0,3,5]  R490      -4.3299937248229980e-01
    z[0,3,5]  R491      -3.3952260017395020e-01
    z[0,3,5]  R492      3.7518686056137085e-01
    z[0,3,5]  R493      -1.9954627752304077e-01
    z[0,3,5]  R494      -3.0268070101737976e-01
    z[0,3,5]  R495      2.9153221845626831e-01
    z[0,3,5]  R496      1.7578034102916718e-01
    z[0,3,5]  R497      1.4103178679943085e-01
    z[0,3,5]  R498      -4.5463374257087708e-01
    z[0,3,5]  R499      5.9324383735656738e-02
    z[0,3,5]  R500      -1.2676222622394562e-01
    z[0,3,5]  R501      5.3338032215833664e-02
    z[0,3,5]  R502      -8.9633306488394737e-03
    z[0,3,5]  R503      4.0861195325851440e-01
    z[0,3,5]  R504      -7.8010559082031250e-02
    z[0,3,5]  R505      -2.3163343966007233e-01
    z[0,3,5]  R506      0.273774117231369
    z[0,3,5]  R507      -5.2762970328330994e-02
    z[0,3,5]  R508      2.3675620555877686e-01
    z[0,3,5]  R509      2.2943376004695892e-01
    z[0,3,5]  R510      7.5764514505863190e-02
    z[0,3,5]  R511      1.8387521803379059e-01
    z[0,3,5]  R512      -2.7558884024620056e-01
    z[0,3,5]  R513      5.9021270275115967e-01
    z[0,3,5]  R514      2.2301357984542847e-01
    z[0,3,5]  R515      -7.0829652249813080e-02
    z[0,3,5]  R516      1.4459949731826782e-01
    z[0,3,5]  R517      1.5825821086764336e-02
    z[0,3,5]  R518      3.1916475296020508e-01
    z[0,3,5]  R519      4.4475227594375610e-01
    z[0,3,5]  R520      -4.2168667912483215e-01
    z[0,3,5]  R521      -2.6205161213874817e-01
    z[0,3,5]  R522      1.1747315526008606e-02
    z[0,3,5]  R523      -3.8046085834503174e-01
    z[0,3,5]  R524      -3.9427403360605240e-02
    z[0,3,5]  R525      2.6306691765785217e-01
    z[0,3,5]  R526      -1.9467723369598389e-01
    z[0,3,5]  R527      2.1556799113750458e-01
    z[0,3,5]  R528      -2.4909430742263794e-01
    z[0,3,5]  R529      -3.0473336577415466e-01
    z[0,3,5]  R530      4.8819732666015625e-01
    z[0,3,5]  R531      -2.2189967334270477e-01
    z[0,3,5]  R532      -6.8342939019203186e-02
    z[0,3,5]  R533      3.0620506405830383e-01
    z[0,3,5]  R534      1.1011601239442825e-01
    z[0,3,5]  R535      -2.7557021379470825e-01
    z[0,3,6]  R8        -1
    z[0,3,6]  R35       1
    z[0,3,6]  R387      -1
    z[0,3,6]  R388      1
    z[0,3,6]  R389      1.8866769969463348e-01
    z[0,3,6]  R390      -4.9333442002534866e-02
    z[0,3,6]  R391      0.395723819732666
    z[0,3,6]  R392      4.1688024997711182e-02
    z[0,3,6]  R393      -7.4217252433300018e-02
    z[0,3,6]  R394      -2.4170126020908356e-01
    z[0,3,6]  R395      -1.0254694148898125e-02
    z[0,3,6]  R396      0.088455431163311
    z[0,3,6]  R397      -5.0630939006805420e-01
    z[0,3,6]  R398      7.0999123156070709e-02
    z[0,3,6]  R399      -3.2858546823263168e-02
    z[0,3,6]  R400      8.8604830205440521e-02
    z[0,3,6]  R401      4.9064168706536293e-03
    z[0,3,6]  R402      2.8341269493103027e-01
    z[0,3,6]  R403      -1.8354374170303345e-01
    z[0,3,6]  R404      4.4690284132957458e-01
    z[0,3,6]  R405      4.0696394443511963e-01
    z[0,3,6]  R406      -4.0506433695554733e-02
    z[0,3,6]  R407      3.2720208168029785e-01
    z[0,3,6]  R408      1.0336861759424210e-01
    z[0,3,6]  R409      -1.9738449156284332e-01
    z[0,3,6]  R410      -3.4226831048727036e-02
    z[0,3,6]  R411      4.3831002712249756e-01
    z[0,3,6]  R412      -1.2033692747354507e-01
    z[0,3,6]  R413      -3.2512211799621582e-01
    z[0,3,6]  R414      -4.3581396341323853e-01
    z[0,3,6]  R415      2.4558633565902710e-01
    z[0,3,6]  R416      4.3737164139747620e-01
    z[0,3,6]  R417      -4.1613289713859558e-01
    z[0,3,6]  R418      -1.3238739967346191e-01
    z[0,3,6]  R419      -1.2371501326560974e-01
    z[0,3,6]  R420      4.7032165527343750e-01
    z[0,3,6]  R421      -2.1344347298145294e-01
    z[0,3,6]  R422      -1.2281096726655960e-01
    z[0,3,6]  R423      3.1134957075119019e-01
    z[0,3,6]  R424      4.4350346922874451e-01
    z[0,3,6]  R425      -1.6316774487495422e-01
    z[0,3,6]  R426      1.5427152812480927e-01
    z[0,3,6]  R427      2.6543816924095154e-01
    z[0,3,6]  R428      -1.0702729225158691e-01
    z[0,3,6]  R429      5.6285685300827026e-01
    z[0,3,6]  R430      2.3148207366466522e-01
    z[0,3,6]  R431      -1.2104640156030655e-01
    z[0,3,6]  R432      -0.295296311378479
    z[0,3,6]  R433      -1.9183368980884552e-01
    z[0,3,6]  R434      1.1599563807249069e-01
    z[0,3,6]  R435      0.0747029259800911
    z[0,3,6]  R436      -2.4605879187583923e-01
    z[0,3,6]  R437      2.8579438105225563e-02
    z[0,3,6]  R438      0.0792076513171196
    z[0,3,6]  R439      -2.3442563414573669e-01
    z[0,3,6]  R440      -2.8481602668762207e-01
    z[0,3,6]  R441      8.9047178626060486e-03
    z[0,3,6]  R442      3.2759314775466919e-01
    z[0,3,6]  R443      -1.4143096632324159e-04
    z[0,3,6]  R444      1.8598626554012299e-01
    z[0,3,6]  R445      -2.0224186778068542e-01
    z[0,3,6]  R446      -2.2372610867023468e-01
    z[0,3,6]  R447      4.0545615553855896e-01
    z[0,3,6]  R448      -9.1858208179473877e-02
    z[0,3,6]  R449      3.2224437594413757e-01
    z[0,3,6]  R450      3.2228657603263855e-01
    z[0,3,6]  R451      -0.0901155099272728
    z[0,3,6]  R452      -5.4834973812103271e-01
    z[0,3,6]  R453      8.3916939795017242e-02
    z[0,3,6]  R454      1.7447138205170631e-02
    z[0,3,6]  R455      -7.4526853859424591e-02
    z[0,3,6]  R456      -6.3740599155426025e-01
    z[0,3,6]  R457      0.441743403673172
    z[0,3,6]  R458      -4.3122348189353943e-01
    z[0,3,6]  R459      -1.4081505127251148e-02
    z[0,3,6]  R460      -1.4989298582077026e-01
    z[0,3,6]  R461      3.9437824487686157e-01
    z[0,3,6]  R462      3.5007354617118835e-01
    z[0,3,6]  R463      2.1143538877367973e-02
    z[0,3,6]  R464      1.4839254319667816e-02
    z[0,3,6]  R465      2.5452831387519836e-01
    z[0,3,6]  R466      -1.6930031776428223e-01
    z[0,3,6]  R467      -4.4117712974548340e-01
    z[0,3,6]  R468      4.8542764782905579e-01
    z[0,3,6]  R469      1.9095657765865326e-01
    z[0,3,6]  R470      -2.2461685538291931e-01
    z[0,3,6]  R471      -7.7713549137115479e-02
    z[0,3,6]  R472      4.4267535209655762e-01
    z[0,3,6]  R473      1.3879722356796265e-01
    z[0,3,6]  R474      -1.3862450420856476e-01
    z[0,3,6]  R475      -1.2953819334506989e-01
    z[0,3,6]  R476      2.0793128013610840e-01
    z[0,3,6]  R477      5.6596368551254272e-02
    z[0,3,6]  R478      6.0966953635215759e-02
    z[0,3,6]  R479      -4.5595744252204895e-01
    z[0,3,6]  R480      -4.7271448373794556e-01
    z[0,3,6]  R481      3.4640945494174957e-02
    z[0,3,6]  R482      1.9651544094085693e-01
    z[0,3,6]  R483      2.3814779520034790e-01
    z[0,3,6]  R484      -3.2557934522628784e-01
    z[0,3,6]  R485      -4.1531622409820557e-02
    z[0,3,6]  R486      -1.8709658086299896e-01
    z[0,3,6]  R487      1.7484484612941742e-01
    z[0,3,6]  R488      3.7786448001861572e-01
    z[0,3,6]  R489      -3.1138148903846741e-01
    z[0,3,6]  R490      -1.9536325708031654e-03
    z[0,3,6]  R491      -3.1438705325126648e-01
    z[0,3,6]  R492      4.4407594203948975e-01
    z[0,3,6]  R493      0.00967728067189455
    z[0,3,6]  R494      2.8715759515762329e-01
    z[0,3,6]  R495      -1.4299340546131134e-01
    z[0,3,6]  R496      -2.4260684847831726e-02
    z[0,3,6]  R497      4.2003687471151352e-02
    z[0,3,6]  R498      2.5526729226112366e-01
    z[0,3,6]  R499      4.4603681564331055e-01
    z[0,3,6]  R500      3.3880195021629333e-01
    z[0,3,6]  R501      -3.7438246607780457e-01
    z[0,3,6]  R502      -4.9122944474220276e-01
    z[0,3,6]  R503      5.3314030170440674e-01
    z[0,3,6]  R504      -3.0161604285240173e-01
    z[0,3,6]  R505      1.4251299202442169e-01
    z[0,3,6]  R506      -9.3784462660551071e-03
    z[0,3,6]  R507      -1.4829332008957863e-02
    z[0,3,6]  R508      -4.6136882901191711e-01
    z[0,3,6]  R509      -1.3811211287975311e-01
    z[0,3,6]  R510      1.1487468332052231e-01
    z[0,3,6]  R511      1.3688622973859310e-02
    z[0,3,6]  R512      -5.4443454742431641e-01
    z[0,3,6]  R513      2.2189514338970184e-01
    z[0,3,6]  R514      -2.5713866949081421e-01
    z[0,3,6]  R515      1.9530370831489563e-02
    z[0,3,6]  R516      3.9185574650764465e-01
    z[0,3,6]  R517      -5.6224983185529709e-02
    z[0,3,6]  R518      -2.7617835998535156e-01
    z[0,3,6]  R519      -1.0886877775192261e-01
    z[0,3,6]  R520      1.6325150430202484e-01
    z[0,3,6]  R521      -3.6671221256256104e-01
    z[0,3,6]  R522      1.9295718520879745e-02
    z[0,3,6]  R523      0.280496209859848
    z[0,3,6]  R524      3.5179728269577026e-01
    z[0,3,6]  R525      3.4558865427970886e-01
    z[0,3,6]  R526      1.1742081493139267e-01
    z[0,3,6]  R527      -2.6539623737335205e-01
    z[0,3,6]  R528      2.7670052647590637e-01
    z[0,3,6]  R529      3.8323320448398590e-02
    z[0,3,6]  R530      6.8560346961021423e-02
    z[0,3,6]  R531      -2.5408580899238586e-01
    z[0,3,6]  R532      -4.8990118503570557e-01
    z[0,3,6]  R533      2.3935526609420776e-01
    z[0,3,6]  R534      -6.3910400867462158e-01
    z[0,3,6]  R535      1.3189865648746490e-01
    z[3,0,0]  R2        1
    z[3,0,0]  R29       -1
    z[3,0,0]  R536      -1
    z[3,0,0]  R537      1
    z[3,0,0]  R550      -3.4406775236129761e-01
    z[3,0,0]  R551      -3.2790100574493408e-01
    z[3,0,0]  R552      -2.7911195158958435e-01
    z[3,0,0]  R553      -2.5956231355667114e-01
    z[3,0,0]  R554      -0.389911025762558
    z[3,0,0]  R555      -0.200189471244812
    z[3,0,0]  R556      -2.5247624516487122e-01
    z[3,0,0]  R557      7.9031985998153687e-01
    z[3,0,0]  R558      8.8028162717819214e-01
    z[3,0,0]  R559      8.6288440227508545e-01
    z[3,0,0]  R560      -5.6515991687774658e-01
    z[3,0,0]  R561      -7.2183072566986084e-01
    z[3,0,0]  R562      -1.0561756044626236e-01
    z[3,0,0]  R563      9.0281152725219727e-01
    z[3,0,0]  R564      -5.6377702951431274e-01
    z[3,0,0]  R565      -4.2510709166526794e-01
    z[3,0,0]  R566      -3.1426465511322021e-01
    z[3,0,0]  R567      -0.472042441368103
    z[3,0,0]  R568      -5.2815198898315430e-01
    z[3,0,0]  R569      -4.3587875366210938e-01
    z[3,0,0]  R570      -8.0650782585144043e-01
    z[3,0,0]  R571      -5.4882502555847168e-01
    z[3,0,0]  R572      -5.3742176294326782e-01
    z[3,0,0]  R573      -5.6928426027297974e-01
    z[3,0,0]  R574      -5.6497520208358765e-01
    z[3,0,0]  R575      -6.1704134941101074e-01
    z[3,0,0]  R576      -0.656769335269928
    z[3,0,0]  R577      -7.2379314899444580e-01
    z[3,0,0]  R578      -4.4615957140922546e-01
    z[3,0,0]  R579      -5.2692312002182007e-01
    z[3,0,0]  R580      -3.8040143251419067e-01
    z[3,0,0]  R581      -8.1182342767715454e-01
    z[3,0,0]  R582      -0.684876024723053
    z[3,0,0]  R583      -5.0133860111236572e-01
    z[3,0,0]  R584      -5.6957280635833740e-01
    z[3,0,0]  R585      0.356876015663147
    z[3,0,0]  R586      8.1507444381713867e-01
    z[3,0,0]  R587      9.1206395626068115e-01
    z[3,0,0]  R588      7.6318812370300293e-01
    z[3,0,0]  R589      8.7414103746414185e-01
    z[3,0,0]  R590      -5.3127700090408325e-01
    z[3,0,0]  R591      -3.3868685364723206e-01
    z[3,0,0]  R592      -3.4689253568649292e-01
    z[3,0,0]  R593      -0.587253212928772
    z[3,0,0]  R594      -2.1451064944267273e-01
    z[3,0,0]  R595      -1.4580808579921722e-01
    z[3,0,0]  R596      -5.0207239389419556e-01
    z[3,0,0]  R597      -6.3019603490829468e-01
    z[3,0,0]  R598      -6.6657543182373047e-01
    z[3,0,0]  R599      -4.9757176637649536e-01
    z[3,0,0]  R600      -5.4342097043991089e-01
    z[3,0,0]  R601      -8.4325426816940308e-01
    z[3,0,0]  R602      -8.3551156520843506e-01
    z[3,0,0]  R603      -5.7310348749160767e-01
    z[3,0,0]  R604      -3.0678653717041016e-01
    z[3,0,0]  R605      -0.371635377407074
    z[3,0,0]  R606      -5.5593419075012207e-01
    z[3,0,0]  R607      4.6494059264659882e-02
    z[3,0,0]  R608      8.0510163307189941e-01
    z[3,0,0]  R609      8.6243516206741333e-01
    z[3,0,0]  R610      6.2239643186330795e-02
    z[3,0,0]  R611      -7.6600360870361328e-01
    z[3,0,0]  R612      5.9907469898462296e-02
    z[3,0,0]  R613      -6.7986255884170532e-01
    z[3,0,0]  R614      -6.9654667377471924e-01
    z[3,0,0]  R615      -5.5627793073654175e-01
    z[3,0,0]  R616      -7.0455557107925415e-01
    z[3,0,0]  R617      -2.4017766118049622e-02
    z[3,0,0]  R618      8.6195367574691772e-01
    z[3,0,0]  R619      8.7085694074630737e-01
    z[3,0,0]  R620      -4.1222232580184937e-01
    z[3,0,0]  R621      -3.7235784530639648e-01
    z[3,0,0]  R622      -2.5136863812804222e-02
    z[3,0,0]  R623      -7.5712692737579346e-01
    z[3,0,0]  R624      -5.1961249113082886e-01
    z[3,0,0]  R625      -1.2179906666278839e-01
    z[3,0,0]  R626      9.1755294799804688e-01
    z[3,0,0]  R627      7.9644507169723511e-01
    z[3,0,0]  R628      0.795567512512207
    z[3,0,0]  R629      8.2271134853363037e-01
    z[3,0,0]  R630      -4.8599314689636230e-01
    z[3,0,0]  R631      -6.6693328320980072e-02
    z[3,0,0]  R632      -4.7179032117128372e-02
    z[3,0,0]  R633      -2.1626415848731995e-01
    z[3,0,0]  R634      -2.4165056645870209e-01
    z[3,0,0]  R635      -8.7707346677780151e-01
    z[3,0,0]  R636      -8.2092583179473877e-01
    z[3,0,0]  R637      3.0467975139617920e-01
    z[3,0,0]  R638      -7.1975088119506836e-01
    z[3,0,0]  R639      8.4028869867324829e-01
    z[3,0,0]  R640      9.5063948631286621e-01
    z[3,0,0]  R641      5.5172234773635864e-01
    z[3,0,0]  R642      8.2528567314147949e-01
    z[3,0,0]  R643      8.0844157934188843e-01
    z[3,0,0]  R644      8.0433422327041626e-01
    z[3,0,0]  R645      -2.6695212721824646e-01
    z[3,0,0]  R646      4.4909101724624634e-01
    z[3,0,0]  R647      -6.7703330516815186e-01
    z[3,0,0]  R648      -8.4879899024963379e-01
    z[3,0,0]  R649      -7.9707098007202148e-01
    z[3,0,0]  R650      -6.5170717239379883e-01
    z[3,0,0]  R651      -5.3997147083282471e-01
    z[3,0,0]  R652      -5.1643681526184082e-01
    z[3,0,0]  R653      -4.9135014414787292e-01
    z[3,0,0]  R654      -7.3041713237762451e-01
    z[3,0,0]  R655      -4.2066127061843872e-01
    z[3,0,0]  R656      -0.335271954536438
    z[3,0,0]  R657      -7.8593236207962036e-01
    z[3,0,0]  R658      -4.8112070560455322e-01
    z[3,0,0]  R659      -8.0663490295410156e-01
    z[3,0,0]  R660      -4.5488181710243225e-01
    z[3,0,0]  R661      -3.4604361653327942e-01
    z[3,0,0]  R662      -0.739958643913269
    z[3,0,0]  R663      -5.4418420791625977e-01
    z[3,0,0]  R664      -3.8419404625892639e-01
    z[3,0,0]  R665      -3.8750213384628296e-01
    z[3,0,0]  R666      -1.6495670378208160e-01
    z[3,0,0]  R667      -6.4012104272842407e-01
    z[3,0,0]  R668      -4.5631998777389526e-01
    z[3,0,0]  R669      -6.9034153223037720e-01
    z[3,0,0]  R670      -4.7739055752754211e-01
    z[3,0,0]  R671      -3.3747208118438721e-01
    z[3,0,0]  R672      0.616935133934021
    z[3,0,0]  R673      -2.9487824440002441e-01
    z[3,0,0]  R674      -3.2894019037485123e-02
    z[3,0,0]  R675      2.6451559737324715e-02
    z[3,0,0]  R676      -5.9227943420410156e-02
    z[3,0,0]  R677      -3.2220444083213806e-01
    z[3,0,0]  R678      -4.7876590490341187e-01
    z[3,0,0]  R679      -2.2320681810379028e-01
    z[3,0,0]  R680      -3.1698886305093765e-02
    z[3,0,0]  R681      4.0914884209632874e-01
    z[3,0,0]  R682      2.0863594114780426e-01
    z[3,0,0]  R683      4.6707686781883240e-01
    z[3,0,0]  R684      5.0943013280630112e-02
    z[3,0,0]  R685      3.4773871302604675e-01
    z[3,0,0]  R686      8.9614562690258026e-02
    z[3,0,0]  R687      -0.302606999874115
    z[3,0,0]  R688      -8.2195393741130829e-02
    z[3,0,0]  R689      -1.9792994856834412e-01
    z[3,0,0]  R690      -2.2379927337169647e-01
    z[3,0,0]  R691      0.0955568253993988
    z[3,0,0]  R692      5.4114109277725220e-01
    z[3,0,0]  R693      5.3917460143566132e-02
    z[3,0,0]  R694      3.4159538149833679e-01
    z[3,0,0]  R695      4.7162267565727234e-01
    z[3,0,0]  R696      2.4069221317768097e-01
    z[3,0,1]  R3        1
    z[3,0,1]  R30       -1
    z[3,0,1]  R538      -1
    z[3,0,1]  R539      1
    z[3,0,1]  R550      -4.0743622183799744e-01
    z[3,0,1]  R551      -1.9889074563980103e-01
    z[3,0,1]  R552      5.7454162836074829e-01
    z[3,0,1]  R553      1.6744308173656464e-01
    z[3,0,1]  R554      -3.1165421009063721e-01
    z[3,0,1]  R555      3.1051808595657349e-01
    z[3,0,1]  R556      4.2386922240257263e-01
    z[3,0,1]  R557      -0.0718371719121933
    z[3,0,1]  R558      -8.9955933392047882e-02
    z[3,0,1]  R559      5.7048797607421875e-02
    z[3,0,1]  R560      -1.1104349046945572e-01
    z[3,0,1]  R561      -1.6461621224880219e-01
    z[3,0,1]  R562      -4.3762156367301941e-01
    z[3,0,1]  R563      1.6248683631420135e-01
    z[3,0,1]  R564      1.1134830117225647e-01
    z[3,0,1]  R565      -7.3070541024208069e-02
    z[3,0,1]  R566      9.6246063709259033e-02
    z[3,0,1]  R567      1.1782778799533844e-01
    z[3,0,1]  R568      2.7041202783584595e-01
    z[3,0,1]  R569      -5.4209005832672119e-01
    z[3,0,1]  R570      3.8884720206260681e-01
    z[3,0,1]  R571      -3.4910616278648376e-01
    z[3,0,1]  R572      5.5928987264633179e-01
    z[3,0,1]  R573      4.4444081187248230e-01
    z[3,0,1]  R574      0.575400710105896
    z[3,0,1]  R575      4.9236461520195007e-01
    z[3,0,1]  R576      3.6707437038421631e-01
    z[3,0,1]  R577      -0.401419073343277
    z[3,0,1]  R578      5.9140056371688843e-01
    z[3,0,1]  R579      1.9477939605712891e-01
    z[3,0,1]  R580      5.6616431474685669e-01
    z[3,0,1]  R581      4.7562189400196075e-02
    z[3,0,1]  R582      2.3031720519065857e-01
    z[3,0,1]  R583      -1.3365231454372406e-01
    z[3,0,1]  R584      3.5345628857612610e-02
    z[3,0,1]  R585      -5.4927694797515869e-01
    z[3,0,1]  R586      -2.5580203533172607e-01
    z[3,0,1]  R587      -2.9031846672296524e-02
    z[3,0,1]  R588      2.1840266883373260e-01
    z[3,0,1]  R589      1.0058821178972721e-02
    z[3,0,1]  R590      -4.8622789978981018e-01
    z[3,0,1]  R591      2.0794808864593506e-01
    z[3,0,1]  R592      4.7027045488357544e-01
    z[3,0,1]  R593      -7.0744462311267853e-02
    z[3,0,1]  R594      -2.3843885958194733e-01
    z[3,0,1]  R595      -1.1425514519214630e-01
    z[3,0,1]  R596      -4.8765793442726135e-01
    z[3,0,1]  R597      -2.7695251628756523e-02
    z[3,0,1]  R598      -4.5463964343070984e-02
    z[3,0,1]  R599      3.7216268479824066e-02
    z[3,0,1]  R600      0.563527524471283
    z[3,0,1]  R601      2.7319166064262390e-01
    z[3,0,1]  R602      -1.4385347068309784e-01
    z[3,0,1]  R603      7.2615332901477814e-03
    z[3,0,1]  R604      8.1111228466033936e-01
    z[3,0,1]  R605      3.2436794042587280e-01
    z[3,0,1]  R606      4.0905106067657471e-01
    z[3,0,1]  R607      -6.5500330924987793e-01
    z[3,0,1]  R608      3.4475263953208923e-01
    z[3,0,1]  R609      1.8451488018035889e-01
    z[3,0,1]  R610      -3.3994078636169434e-01
    z[3,0,1]  R611      4.7159090638160706e-01
    z[3,0,1]  R612      -2.5233197212219238e-01
    z[3,0,1]  R613      1.8022919073700905e-02
    z[3,0,1]  R614      0.0539570190012455
    z[3,0,1]  R615      1.6202329099178314e-01
    z[3,0,1]  R616      2.8932240605354309e-01
    z[3,0,1]  R617      -7.3883497714996338e-01
    z[3,0,1]  R618      -1.1312500573694706e-03
    z[3,0,1]  R619      2.0633409917354584e-01
    z[3,0,1]  R620      -0.57985520362854
    z[3,0,1]  R621      5.2900129556655884e-01
    z[3,0,1]  R622      -0.422419011592865
    z[3,0,1]  R623      -3.2618728280067444e-01
    z[3,0,1]  R624      3.6254149675369263e-01
    z[3,0,1]  R625      1.5918913483619690e-01
    z[3,0,1]  R626      9.1630041599273682e-02
    z[3,0,1]  R627      1.0925793647766113e-01
    z[3,0,1]  R628      -1.5200471878051758e-01
    z[3,0,1]  R629      -2.1054264903068542e-01
    z[3,0,1]  R630      2.1635462343692780e-01
    z[3,0,1]  R631      -3.5965493321418762e-01
    z[3,0,1]  R632      -5.1427793502807617e-01
    z[3,0,1]  R633      -3.7195730209350586e-01
    z[3,0,1]  R634      -6.8676269054412842e-01
    z[3,0,1]  R635      1.7070958018302917e-01
    z[3,0,1]  R636      2.0195762813091278e-01
    z[3,0,1]  R637      -6.7172354459762573e-01
    z[3,0,1]  R638      2.9508890584111214e-02
    z[3,0,1]  R639      2.8312578797340393e-01
    z[3,0,1]  R640      1.8348847329616547e-01
    z[3,0,1]  R641      7.3893499374389648e-01
    z[3,0,1]  R642      1.7857621610164642e-01
    z[3,0,1]  R643      5.3061944246292114e-01
    z[3,0,1]  R644      4.6047952771186829e-01
    z[3,0,1]  R645      4.5100402832031250e-01
    z[3,0,1]  R646      0.596885621547699
    z[3,0,1]  R647      -3.4250352531671524e-02
    z[3,0,1]  R648      -2.0875754952430725e-01
    z[3,0,1]  R649      2.0808492600917816e-01
    z[3,0,1]  R650      -4.1754089295864105e-02
    z[3,0,1]  R651      5.3702068328857422e-01
    z[3,0,1]  R652      -3.1882904469966888e-02
    z[3,0,1]  R653      -4.5007994771003723e-01
    z[3,0,1]  R654      -5.1013922691345215e-01
    z[3,0,1]  R655      -2.0662444829940796e-01
    z[3,0,1]  R656      -6.6670411825180054e-01
    z[3,0,1]  R657      4.5394363999366760e-01
    z[3,0,1]  R658      7.4497830867767334e-01
    z[3,0,1]  R659      2.1404880285263062e-01
    z[3,0,1]  R660      7.1047663688659668e-01
    z[3,0,1]  R661      6.4928478002548218e-01
    z[3,0,1]  R662      3.7441188097000122e-01
    z[3,0,1]  R663      1.0908488184213638e-02
    z[3,0,1]  R664      4.2736539244651794e-01
    z[3,0,1]  R665      4.4189310073852539e-01
    z[3,0,1]  R666      2.7838796377182007e-01
    z[3,0,1]  R667      8.7187774479389191e-02
    z[3,0,1]  R668      3.7865081429481506e-01
    z[3,0,1]  R669      -4.3377488851547241e-01
    z[3,0,1]  R670      -6.8070453405380249e-01
    z[3,0,1]  R671      -8.6769664287567139e-01
    z[3,0,1]  R672      2.1589897572994232e-01
    z[3,0,1]  R673      -5.0343447923660278e-01
    z[3,0,1]  R674      -7.4226856231689453e-01
    z[3,0,1]  R675      -9.0129858255386353e-01
    z[3,0,1]  R676      -5.6143432855606079e-01
    z[3,0,1]  R677      6.3973242044448853e-01
    z[3,0,1]  R678      2.6570373773574829e-01
    z[3,0,1]  R679      -7.6507246494293213e-01
    z[3,0,1]  R680      -5.2671676874160767e-01
    z[3,0,1]  R681      -5.2842015027999878e-01
    z[3,0,1]  R682      -4.0489968657493591e-01
    z[3,0,1]  R683      -4.1363832354545593e-01
    z[3,0,1]  R684      -2.0617979764938354e-01
    z[3,0,1]  R685      -5.0428098440170288e-01
    z[3,0,1]  R686      -0.28351891040802
    z[3,0,1]  R687      5.9813719987869263e-01
    z[3,0,1]  R688      -5.6944328546524048e-01
    z[3,0,1]  R689      -7.9107505083084106e-01
    z[3,0,1]  R690      -8.3547854423522949e-01
    z[3,0,1]  R691      -6.2728846073150635e-01
    z[3,0,1]  R692      -1.5642635524272919e-01
    z[3,0,1]  R693      -0.408250629901886
    z[3,0,1]  R694      1.0886962711811066e-01
    z[3,0,1]  R695      -6.0041254758834839e-01
    z[3,0,1]  R696      1.5060398727655411e-03
    z[3,0,2]  R4        1
    z[3,0,2]  R31       -1
    z[3,0,2]  R540      -1
    z[3,0,2]  R541      1
    z[3,0,2]  R550      4.1041958332061768e-01
    z[3,0,2]  R551      4.8243105411529541e-01
    z[3,0,2]  R552      1.5083377063274384e-01
    z[3,0,2]  R553      2.3986802995204926e-01
    z[3,0,2]  R554      5.3352898359298706e-01
    z[3,0,2]  R555      -1.8829308450222015e-01
    z[3,0,2]  R556      -6.2303669750690460e-02
    z[3,0,2]  R557      -6.2953778542578220e-03
    z[3,0,2]  R558      -6.2106844037771225e-02
    z[3,0,2]  R559      2.6103788614273071e-01
    z[3,0,2]  R560      1.2965458631515503e-01
    z[3,0,2]  R561      -4.6965414285659790e-01
    z[3,0,2]  R562      2.0638918876647949e-01
    z[3,0,2]  R563      1.6082639992237091e-01
    z[3,0,2]  R564      -6.0505729913711548e-01
    z[3,0,2]  R565      -7.0326203107833862e-01
    z[3,0,2]  R566      -8.3815455436706543e-01
    z[3,0,2]  R567      -6.1573606729507446e-01
    z[3,0,2]  R568      4.2432656884193420e-01
    z[3,0,2]  R569      -3.0441206693649292e-01
    z[3,0,2]  R570      1.5811249613761902e-01
    z[3,0,2]  R571      0.376202791929245
    z[3,0,2]  R572      5.0575062632560730e-02
    z[3,0,2]  R573      2.1942797303199768e-01
    z[3,0,2]  R574      -4.8627737164497375e-01
    z[3,0,2]  R575      -3.4369108080863953e-01
    z[3,0,2]  R576      1.2670375406742096e-01
    z[3,0,2]  R577      -2.3087514936923981e-01
    z[3,0,2]  R578      -4.0249493718147278e-01
    z[3,0,2]  R579      7.9355299472808838e-01
    z[3,0,2]  R580      -6.2529988586902618e-02
    z[3,0,2]  R581      -2.4667935073375702e-01
    z[3,0,2]  R582      -2.9975825548171997e-01
    z[3,0,2]  R583      -1.9519220292568207e-01
    z[3,0,2]  R584      -3.2596173882484436e-01
    z[3,0,2]  R585      5.3519034385681152e-01
    z[3,0,2]  R586      4.2127409577369690e-01
    z[3,0,2]  R587      1.2512315809726715e-01
    z[3,0,2]  R588      3.2611471414566040e-01
    z[3,0,2]  R589      2.5055831670761108e-01
    z[3,0,2]  R590      3.1556525826454163e-01
    z[3,0,2]  R591      -2.1326968073844910e-01
    z[3,0,2]  R592      -2.4498504400253296e-01
    z[3,0,2]  R593      9.8096147179603577e-02
    z[3,0,2]  R594      5.0670439004898071e-01
    z[3,0,2]  R595      5.9198117256164551e-01
    z[3,0,2]  R596      -4.0576282143592834e-01
    z[3,0,2]  R597      -4.5886853337287903e-01
    z[3,0,2]  R598      -4.3549299240112305e-01
    z[3,0,2]  R599      -7.1385937929153442e-01
    z[3,0,2]  R600      -1.5301067614927888e-03
    z[3,0,2]  R601      -4.0854278206825256e-01
    z[3,0,2]  R602      2.4864038452506065e-02
    z[3,0,2]  R603      3.0922656878829002e-02
    z[3,0,2]  R604      -0.0631827712059021
    z[3,0,2]  R605      6.1961793899536133e-01
    z[3,0,2]  R606      -4.2903009057044983e-01
    z[3,0,2]  R607      1.7989465594291687e-01
    z[3,0,2]  R608      3.3121243119239807e-01
    z[3,0,2]  R609      2.1600204706192017e-01
    z[3,0,2]  R610      6.9001567363739014e-01
    z[3,0,2]  R611      -2.2462388500571251e-02
    z[3,0,2]  R612      7.2278487682342529e-01
    z[3,0,2]  R613      -2.3946358263492584e-01
    z[3,0,2]  R614      -5.9312063455581665e-01
    z[3,0,2]  R615      7.0781731605529785e-01
    z[3,0,2]  R616      1.1221123486757278e-01
    z[3,0,2]  R617      1.1881493777036667e-01
    z[3,0,2]  R618      2.9405781626701355e-01
    z[3,0,2]  R619      -1.0706714354455471e-02
    z[3,0,2]  R620      2.5668564438819885e-01
    z[3,0,2]  R621      -3.7382226437330246e-02
    z[3,0,2]  R622      6.8933749198913574e-01
    z[3,0,2]  R623      -3.1472650170326233e-01
    z[3,0,2]  R624      -3.4611481428146362e-01
    z[3,0,2]  R625      7.3608571290969849e-01
    z[3,0,2]  R626      3.4660151600837708e-01
    z[3,0,2]  R627      3.5235700011253357e-01
    z[3,0,2]  R628      -3.8247801363468170e-02
    z[3,0,2]  R629      -1.2653575837612152e-01
    z[3,0,2]  R630      4.0381708741188049e-01
    z[3,0,2]  R631      6.5360546112060547e-01
    z[3,0,2]  R632      5.5261862277984619e-01
    z[3,0,2]  R633      8.4787815809249878e-01
    z[3,0,2]  R634      1.0278853029012680e-01
    z[3,0,2]  R635      -1.9657596945762634e-01
    z[3,0,2]  R636      -1.7647102475166321e-01
    z[3,0,2]  R637      4.9150779843330383e-01
    z[3,0,2]  R638      3.6729894578456879e-02
    z[3,0,2]  R639      -1.0624358803033829e-01
    z[3,0,2]  R640      2.4266245961189270e-01
    z[3,0,2]  R641      -3.3070594072341919e-01
    z[3,0,2]  R642      3.0206015706062317e-01
    z[3,0,2]  R643      -1.5245966613292694e-01
    z[3,0,2]  R644      1.9436698406934738e-02
    z[3,0,2]  R645      -3.4611273556947708e-02
    z[3,0,2]  R646      -5.8791655302047729e-01
    z[3,0,2]  R647      -6.1598002910614014e-01
    z[3,0,2]  R648      -3.5712572932243347e-01
    z[3,0,2]  R649      -2.3911079764366150e-01
    z[3,0,2]  R650      -3.2284760475158691e-01
    z[3,0,2]  R651      2.2259363532066345e-01
    z[3,0,2]  R652      -5.8785039186477661e-01
    z[3,0,2]  R653      -5.2049297094345093e-01
    z[3,0,2]  R654      -8.4991287440061569e-03
    z[3,0,2]  R655      -5.2151817083358765e-01
    z[3,0,2]  R656      5.2224820852279663e-01
    z[3,0,2]  R657      -4.9242395907640457e-02
    z[3,0,2]  R658      1.6663928329944611e-01
    z[3,0,2]  R659      2.8458821773529053e-01
    z[3,0,2]  R660      -0.265234112739563
    z[3,0,2]  R661      -2.2192781791090965e-02
    z[3,0,2]  R662      6.0554448515176773e-02
    z[3,0,2]  R663      2.0031755790114403e-02
    z[3,0,2]  R664      3.7380585074424744e-01
    z[3,0,2]  R665      5.7075881958007812e-01
    z[3,0,2]  R666      1.7242784798145294e-01
    z[3,0,2]  R667      1.9863437116146088e-01
    z[3,0,2]  R668      -3.7209963798522949e-01
    z[3,0,2]  R669      1.9737100601196289e-01
    z[3,0,2]  R670      4.5568180084228516e-01
    z[3,0,2]  R671      1.1098874360322952e-01
    z[3,0,2]  R672      -2.9603496193885803e-01
    z[3,0,2]  R673      5.4920607805252075e-01
    z[3,0,2]  R674      3.7952467799186707e-01
    z[3,0,2]  R675      1.7176325619220734e-01
    z[3,0,2]  R676      5.3085041046142578e-01
    z[3,0,2]  R677      -2.8079429268836975e-01
    z[3,0,2]  R678      -4.2123457789421082e-01
    z[3,0,2]  R679      0.408405065536499
    z[3,0,2]  R680      7.0510065555572510e-01
    z[3,0,2]  R681      9.5214679837226868e-02
    z[3,0,2]  R682      1.9265627861022949e-01
    z[3,0,2]  R683      1.5138559043407440e-01
    z[3,0,2]  R684      4.2132866382598877e-01
    z[3,0,2]  R685      -1.5476787090301514e-01
    z[3,0,2]  R686      2.9042625427246094e-01
    z[3,0,2]  R687      -1.1957526206970215e-01
    z[3,0,2]  R688      7.2208935022354126e-01
    z[3,0,2]  R689      4.5464840531349182e-01
    z[3,0,2]  R690      2.3715527355670929e-01
    z[3,0,2]  R691      7.1603232622146606e-01
    z[3,0,2]  R692      4.1160178184509277e-01
    z[3,0,2]  R693      0.485909104347229
    z[3,0,2]  R694      7.6738965511322021e-01
    z[3,0,2]  R695      -2.7881422638893127e-01
    z[3,0,2]  R696      -1.6056613624095917e-01
    z[3,0,3]  R5        1
    z[3,0,3]  R32       -1
    z[3,0,3]  R542      -1
    z[3,0,3]  R543      1
    z[3,0,3]  R550      -2.7057039737701416e-01
    z[3,0,3]  R551      2.2242200374603271e-01
    z[3,0,3]  R552      -4.8630633950233459e-01
    z[3,0,3]  R553      -9.0782207250595093e-01
    z[3,0,3]  R554      -6.0245823860168457e-01
    z[3,0,3]  R555      -7.7078616619110107e-01
    z[3,0,3]  R556      -5.7151901721954346e-01
    z[3,0,3]  R557      -4.4974225759506226e-01
    z[3,0,3]  R558      -3.3146941661834717e-01
    z[3,0,3]  R559      -3.7510424852371216e-01
    z[3,0,3]  R560      3.1618601083755493e-01
    z[3,0,3]  R561      -1.8194037675857544e-01
    z[3,0,3]  R562      3.8946425914764404e-01
    z[3,0,3]  R563      0.081110879778862
    z[3,0,3]  R564      1.6585490107536316e-01
    z[3,0,3]  R565      3.3532249927520752e-01
    z[3,0,3]  R566      2.4041488766670227e-01
    z[3,0,3]  R567      5.9478312730789185e-01
    z[3,0,3]  R568      3.0572825670242310e-01
    z[3,0,3]  R569      -9.2390157282352448e-02
    z[3,0,3]  R570      -7.5568921864032745e-02
    z[3,0,3]  R571      -9.7693480551242828e-02
    z[3,0,3]  R572      -1.7162151634693146e-01
    z[3,0,3]  R573      -1.2340348213911057e-01
    z[3,0,3]  R574      -3.6988846957683563e-02
    z[3,0,3]  R575      -2.4959733709692955e-02
    z[3,0,3]  R576      -5.6879818439483643e-03
    z[3,0,3]  R577      4.3359389901161194e-01
    z[3,0,3]  R578      -1.2845497578382492e-02
    z[3,0,3]  R579      -1.7646154761314392e-01
    z[3,0,3]  R580      -4.5771875977516174e-01
    z[3,0,3]  R581      -4.7059425711631775e-01
    z[3,0,3]  R582      2.9010131955146790e-01
    z[3,0,3]  R583      -1.5414546430110931e-01
    z[3,0,3]  R584      2.8731770813465118e-02
    z[3,0,3]  R585      5.1945778541266918e-03
    z[3,0,3]  R586      -0.0582304522395134
    z[3,0,3]  R587      -2.7886587381362915e-01
    z[3,0,3]  R588      1.9689889624714851e-02
    z[3,0,3]  R589      -1.2389860302209854e-01
    z[3,0,3]  R590      2.3909914493560791e-01
    z[3,0,3]  R591      -8.3357393741607666e-01
    z[3,0,3]  R592      -5.2888363599777222e-01
    z[3,0,3]  R593      -6.7985409498214722e-01
    z[3,0,3]  R594      6.0640448331832886e-01
    z[3,0,3]  R595      5.7174468040466309e-01
    z[3,0,3]  R596      -7.3191873729228973e-02
    z[3,0,3]  R597      2.1180571615695953e-01
    z[3,0,3]  R598      -2.2566859424114227e-01
    z[3,0,3]  R599      -1.3528390228748322e-01
    z[3,0,3]  R600      -3.4971076250076294e-01
    z[3,0,3]  R601      -1.2376046925783157e-01
    z[3,0,3]  R602      -1.3576015830039978e-02
    z[3,0,3]  R603      -6.5821069478988647e-01
    z[3,0,3]  R604      -3.2483169436454773e-01
    z[3,0,3]  R605      -4.0063586831092834e-01
    z[3,0,3]  R606      3.1285667419433594e-01
    z[3,0,3]  R607      1.3730789721012115e-01
    z[3,0,3]  R608      -1.4332598447799683e-01
    z[3,0,3]  R609      3.1519293785095215e-01
    z[3,0,3]  R610      -9.5184780657291412e-02
    z[3,0,3]  R611      2.4369803071022034e-01
    z[3,0,3]  R612      0.348730206489563
    z[3,0,3]  R613      0.451188862323761
    z[3,0,3]  R614      3.3942395448684692e-01
    z[3,0,3]  R615      -6.7075587809085846e-02
    z[3,0,3]  R616      1.8302203714847565e-01
    z[3,0,3]  R617      1.1391800642013550e-01
    z[3,0,3]  R618      1.4862108230590820e-01
    z[3,0,3]  R619      -3.2110220193862915e-01
    z[3,0,3]  R620      4.3260562419891357e-01
    z[3,0,3]  R621      -6.7774200439453125e-01
    z[3,0,3]  R622      -4.0927335619926453e-01
    z[3,0,3]  R623      -1.3049960136413574e-02
    z[3,0,3]  R624      -0.502071738243103
    z[3,0,3]  R625      -9.1563336551189423e-02
    z[3,0,3]  R626      -1.4747790992259979e-01
    z[3,0,3]  R627      -7.6781474053859711e-02
    z[3,0,3]  R628      1.6723388433456421e-01
    z[3,0,3]  R629      1.7311847209930420e-01
    z[3,0,3]  R630      -7.0427286624908447e-01
    z[3,0,3]  R631      5.3233772516250610e-01
    z[3,0,3]  R632      4.6594947576522827e-01
    z[3,0,3]  R633      -3.8813658058643341e-02
    z[3,0,3]  R634      -2.1370275318622589e-01
    z[3,0,3]  R635      2.2169852256774902e-01
    z[3,0,3]  R636      1.7748758196830750e-02
    z[3,0,3]  R637      2.0500671863555908e-01
    z[3,0,3]  R638      -8.5821323096752167e-02
    z[3,0,3]  R639      1.5121363103389740e-01
    z[3,0,3]  R640      2.0572718232870102e-02
    z[3,0,3]  R641      -3.4895248245447874e-03
    z[3,0,3]  R642      -1.3784939050674438e-01
    z[3,0,3]  R643      -1.7129622399806976e-01
    z[3,0,3]  R644      -1.2891253829002380e-01
    z[3,0,3]  R645      -5.7065492868423462e-01
    z[3,0,3]  R646      2.2236967086791992e-01
    z[3,0,3]  R647      1.8083423376083374e-01
    z[3,0,3]  R648      -6.9698132574558258e-02
    z[3,0,3]  R649      1.4075244963169098e-01
    z[3,0,3]  R650      4.2891070246696472e-01
    z[3,0,3]  R651      0.380641371011734
    z[3,0,3]  R652      0.0773368775844574
    z[3,0,3]  R653      3.2796174287796021e-01
    z[3,0,3]  R654      -3.2630673050880432e-01
    z[3,0,3]  R655      2.8481978178024292e-01
    z[3,0,3]  R656      2.4042797088623047e-01
    z[3,0,3]  R657      -1.6804021596908569e-01
    z[3,0,3]  R658      -2.1764262020587921e-01
    z[3,0,3]  R659      -1.5559849143028259e-01
    z[3,0,3]  R660      -2.0663103461265564e-01
    z[3,0,3]  R661      -4.0528619289398193e-01
    z[3,0,3]  R662      -3.3417305350303650e-01
    z[3,0,3]  R663      -6.7320454120635986e-01
    z[3,0,3]  R664      -2.5686460733413696e-01
    z[3,0,3]  R665      -2.0680793095380068e-03
    z[3,0,3]  R666      -4.6091657876968384e-01
    z[3,0,3]  R667      -6.1763554811477661e-01
    z[3,0,3]  R668      -2.4363413453102112e-01
    z[3,0,3]  R669      4.7199773788452148e-01
    z[3,0,3]  R670      -1.1488460004329681e-01
    z[3,0,3]  R671      9.7651846706867218e-02
    z[3,0,3]  R672      4.2816668748855591e-01
    z[3,0,3]  R673      3.2782697677612305e-01
    z[3,0,3]  R674      -4.7279921174049377e-01
    z[3,0,3]  R675      -5.6368038058280945e-02
    z[3,0,3]  R676      -5.9518980979919434e-01
    z[3,0,3]  R677      -1.8755196034908295e-01
    z[3,0,3]  R678      -2.4840892851352692e-01
    z[3,0,3]  R679      -2.1829817444086075e-02
    z[3,0,3]  R680      2.9045999050140381e-01
    z[3,0,3]  R681      -6.3881975412368774e-01
    z[3,0,3]  R682      7.2736620903015137e-01
    z[3,0,3]  R683      0.645383358001709
    z[3,0,3]  R684      6.5305101871490479e-01
    z[3,0,3]  R685      -4.8276394605636597e-01
    z[3,0,3]  R686      8.8347822427749634e-01
    z[3,0,3]  R687      5.1070757210254669e-02
    z[3,0,3]  R688      1.2201625853776932e-01
    z[3,0,3]  R689      1.0796375572681427e-01
    z[3,0,3]  R690      -4.6345632523298264e-02
    z[3,0,3]  R691      -2.7514001727104187e-01
    z[3,0,3]  R692      -4.4121104478836060e-01
    z[3,0,3]  R693      6.0426419973373413e-01
    z[3,0,3]  R694      -0.250192791223526
    z[3,0,3]  R695      -4.0110346674919128e-01
    z[3,0,3]  R696      8.6320447921752930e-01
    z[3,0,4]  R6        1
    z[3,0,4]  R33       -1
    z[3,0,4]  R544      -1
    z[3,0,4]  R545      1
    z[3,0,4]  R550      -4.2647701501846313e-01
    z[3,0,4]  R551      6.4936959743499756e-01
    z[3,0,4]  R552      2.0659589767456055e-01
    z[3,0,4]  R553      1.2071436643600464e-01
    z[3,0,4]  R554      -2.6310819387435913e-01
    z[3,0,4]  R555      -2.7697184681892395e-01
    z[3,0,4]  R556      -6.3517436385154724e-02
    z[3,0,4]  R557      1.3910956680774689e-01
    z[3,0,4]  R558      -1.1195933073759079e-01
    z[3,0,4]  R559      0.00340811675414443
    z[3,0,4]  R560      2.2796740755438805e-02
    z[3,0,4]  R561      2.9402857646346092e-02
    z[3,0,4]  R562      -2.3719245195388794e-01
    z[3,0,4]  R563      3.0050572752952576e-01
    z[3,0,4]  R564      2.9327198863029480e-01
    z[3,0,4]  R565      1.3792613148689270e-01
    z[3,0,4]  R566      2.5427341461181641e-02
    z[3,0,4]  R567      0.118742436170578
    z[3,0,4]  R568      -3.8816636800765991e-01
    z[3,0,4]  R569      -1.4444314874708652e-02
    z[3,0,4]  R570      2.9218655824661255e-01
    z[3,0,4]  R571      1.4821581542491913e-01
    z[3,0,4]  R572      2.9983353614807129e-01
    z[3,0,4]  R573      -1.4140526950359344e-01
    z[3,0,4]  R574      -7.0724025368690491e-02
    z[3,0,4]  R575      8.9530251920223236e-02
    z[3,0,4]  R576      -2.9376211762428284e-01
    z[3,0,4]  R577      -6.6264927387237549e-02
    z[3,0,4]  R578      -4.9960368871688843e-01
    z[3,0,4]  R579      4.7424253076314926e-02
    z[3,0,4]  R580      -5.2696573734283447e-01
    z[3,0,4]  R581      0.225468710064888
    z[3,0,4]  R582      5.3126358985900879e-01
    z[3,0,4]  R583      -0.645107090473175
    z[3,0,4]  R584      -5.7966804504394531e-01
    z[3,0,4]  R585      -5.1796585321426392e-01
    z[3,0,4]  R586      -2.2337383031845093e-01
    z[3,0,4]  R587      1.0597323998808861e-02
    z[3,0,4]  R588      -3.5800719261169434e-01
    z[3,0,4]  R589      -3.9284643530845642e-01
    z[3,0,4]  R590      -5.3778970241546631e-01
    z[3,0,4]  R591      1.9459785521030426e-01
    z[3,0,4]  R592      1.0053319483995438e-01
    z[3,0,4]  R593      -2.2989268600940704e-01
    z[3,0,4]  R594      -2.9182881116867065e-01
    z[3,0,4]  R595      -2.7246505022048950e-01
    z[3,0,4]  R596      -4.6303052455186844e-02
    z[3,0,4]  R597      -5.5385154485702515e-01
    z[3,0,4]  R598      -3.7276622653007507e-01
    z[3,0,4]  R599      -0.343077689409256
    z[3,0,4]  R600      4.8305603861808777e-01
    z[3,0,4]  R601      -1.0203192383050919e-01
    z[3,0,4]  R602      -0.0925784781575203
    z[3,0,4]  R603      -1.8663829565048218e-01
    z[3,0,4]  R604      8.7267801165580750e-02
    z[3,0,4]  R605      -2.6311576366424561e-01
    z[3,0,4]  R606      1.6780454665422440e-02
    z[3,0,4]  R607      2.5766485929489136e-01
    z[3,0,4]  R608      7.5200520455837250e-02
    z[3,0,4]  R609      4.6823222190141678e-02
    z[3,0,4]  R610      5.6598985195159912e-01
    z[3,0,4]  R611      -3.5769158601760864e-01
    z[3,0,4]  R612      1.4069169759750366e-01
    z[3,0,4]  R613      0.452584832906723
    z[3,0,4]  R614      1.6116510331630707e-01
    z[3,0,4]  R615      -3.5327225923538208e-01
    z[3,0,4]  R616      3.8043644279241562e-02
    z[3,0,4]  R617      -1.6989172995090485e-01
    z[3,0,4]  R618      -1.8061298131942749e-01
    z[3,0,4]  R619      -3.0069085955619812e-01
    z[3,0,4]  R620      2.5757661461830139e-01
    z[3,0,4]  R621      -3.4258410334587097e-01
    z[3,0,4]  R622      0.00994244497269392
    z[3,0,4]  R623      -1.0714717209339142e-01
    z[3,0,4]  R624      1.4907805621623993e-01
    z[3,0,4]  R625      4.5438849925994873e-01
    z[3,0,4]  R626      8.5485167801380157e-02
    z[3,0,4]  R627      -1.6078485175967216e-02
    z[3,0,4]  R628      -4.3499547243118286e-01
    z[3,0,4]  R629      -2.1023973822593689e-01
    z[3,0,4]  R630      7.9031303524971008e-02
    z[3,0,4]  R631      1.9675374031066895e-01
    z[3,0,4]  R632      -2.6867267489433289e-01
    z[3,0,4]  R633      1.1945463716983795e-02
    z[3,0,4]  R634      -4.1314724087715149e-01
    z[3,0,4]  R635      2.9950621537864208e-03
    z[3,0,4]  R636      -9.5723450183868408e-02
    z[3,0,4]  R637      -1.4593677222728729e-01
    z[3,0,4]  R638      -2.2758300602436066e-01
    z[3,0,4]  R639      -2.9370945692062378e-01
    z[3,0,4]  R640      -2.2041415795683861e-02
    z[3,0,4]  R641      -1.4359714090824127e-01
    z[3,0,4]  R642      -1.9014884531497955e-01
    z[3,0,4]  R643      -1.0998731106519699e-01
    z[3,0,4]  R644      3.2825049757957458e-01
    z[3,0,4]  R645      -8.3933107554912567e-02
    z[3,0,4]  R646      1.6483344137668610e-02
    z[3,0,4]  R647      -2.2064687311649323e-01
    z[3,0,4]  R648      -2.0545309782028198e-01
    z[3,0,4]  R649      3.3019462227821350e-01
    z[3,0,4]  R650      2.6482102274894714e-01
    z[3,0,4]  R651      -3.3414953947067261e-01
    z[3,0,4]  R652      4.2259556055068970e-01
    z[3,0,4]  R653      -9.9161945283412933e-02
    z[3,0,4]  R654      -4.5455410145223141e-03
    z[3,0,4]  R655      3.9835435152053833e-01
    z[3,0,4]  R656      3.1894508004188538e-01
    z[3,0,4]  R657      -8.5877306759357452e-02
    z[3,0,4]  R658      -2.6973801851272583e-01
    z[3,0,4]  R659      -2.0720811560750008e-02
    z[3,0,4]  R660      4.0071615576744080e-01
    z[3,0,4]  R661      4.1808298230171204e-01
    z[3,0,4]  R662      5.7537477463483810e-02
    z[3,0,4]  R663      3.4836444258689880e-01
    z[3,0,4]  R664      3.7266877293586731e-01
    z[3,0,4]  R665      0.363534539937973
    z[3,0,4]  R666      -7.2346520423889160e-01
    z[3,0,4]  R667      2.0305566489696503e-01
    z[3,0,4]  R668      2.0270688831806183e-01
    z[3,0,4]  R669      -1.0040581226348877e-01
    z[3,0,4]  R670      -2.6142343878746033e-01
    z[3,0,4]  R671      -1.0947328805923462e-01
    z[3,0,4]  R672      2.3419323563575745e-01
    z[3,0,4]  R673      -3.2322630286216736e-01
    z[3,0,4]  R674      -2.1963614225387573e-01
    z[3,0,4]  R675      -2.3658205568790436e-01
    z[3,0,4]  R676      -1.5085247159004211e-01
    z[3,0,4]  R677      -6.5335296094417572e-02
    z[3,0,4]  R678      -5.7643568515777588e-01
    z[3,0,4]  R679      -1.8529847264289856e-01
    z[3,0,4]  R680      -2.1317061781883240e-01
    z[3,0,4]  R681      9.3847788870334625e-02
    z[3,0,4]  R682      2.6367539167404175e-01
    z[3,0,4]  R683      -5.5896721780300140e-02
    z[3,0,4]  R684      2.5234678387641907e-01
    z[3,0,4]  R685      4.5455864071846008e-01
    z[3,0,4]  R686      1.9800759851932526e-01
    z[3,0,4]  R687      -2.6005905866622925e-01
    z[3,0,4]  R688      -2.1363671123981476e-01
    z[3,0,4]  R689      7.0633560419082642e-02
    z[3,0,4]  R690      -1.4188164472579956e-01
    z[3,0,4]  R691      9.3043945729732513e-02
    z[3,0,4]  R692      5.0262737274169922e-01
    z[3,0,4]  R693      1.1373239010572433e-01
    z[3,0,4]  R694      4.0888068079948425e-01
    z[3,0,4]  R695      4.2495880275964737e-02
    z[3,0,4]  R696      -3.8691172003746033e-01
    z[3,0,5]  R7        1
    z[3,0,5]  R34       -1
    z[3,0,5]  R546      -1
    z[3,0,5]  R547      1
    z[3,0,5]  R550      -4.3386217951774597e-01
    z[3,0,5]  R551      -2.1251513063907623e-01
    z[3,0,5]  R552      -5.0445652008056641e-01
    z[3,0,5]  R553      -7.6856710016727448e-02
    z[3,0,5]  R554      -1.6088853776454926e-01
    z[3,0,5]  R555      2.5028528645634651e-02
    z[3,0,5]  R556      0.348357617855072
    z[3,0,5]  R557      -3.7620836496353149e-01
    z[3,0,5]  R558      -3.0073845386505127e-01
    z[3,0,5]  R559      -1.9433495402336121e-01
    z[3,0,5]  R560      3.8035976886749268e-01
    z[3,0,5]  R561      -4.6719394624233246e-02
    z[3,0,5]  R562      6.0069918632507324e-01
    z[3,0,5]  R563      1.8863563239574432e-01
    z[3,0,5]  R564      4.0948572754859924e-01
    z[3,0,5]  R565      1.7991185188293457e-01
    z[3,0,5]  R566      0.0920541062951088
    z[3,0,5]  R567      1.2588837742805481e-01
    z[3,0,5]  R568      4.7277545928955078e-01
    z[3,0,5]  R569      5.9156739711761475e-01
    z[3,0,5]  R570      -2.3151063919067383e-01
    z[3,0,5]  R571      0.457425594329834
    z[3,0,5]  R572      2.0204125344753265e-01
    z[3,0,5]  R573      0.598791241645813
    z[3,0,5]  R574      -2.3754674196243286e-01
    z[3,0,5]  R575      4.9399951100349426e-01
    z[3,0,5]  R576      3.6819356679916382e-01
    z[3,0,5]  R577      2.2365932166576385e-01
    z[3,0,5]  R578      1.4212416112422943e-01
    z[3,0,5]  R579      -6.7222595214843750e-02
    z[3,0,5]  R580      -2.0196711644530296e-02
    z[3,0,5]  R581      -4.8286926001310349e-02
    z[3,0,5]  R582      -1.3389208912849426e-01
    z[3,0,5]  R583      2.1183808147907257e-01
    z[3,0,5]  R584      8.8243380188941956e-02
    z[3,0,5]  R585      1.2243386358022690e-01
    z[3,0,5]  R586      2.9019605368375778e-02
    z[3,0,5]  R587      1.3056750595569611e-01
    z[3,0,5]  R588      -1.7010171711444855e-01
    z[3,0,5]  R589      -3.9907835423946381e-02
    z[3,0,5]  R590      1.8827447667717934e-02
    z[3,0,5]  R591      -1.8242919445037842e-01
    z[3,0,5]  R592      -4.0729236602783203e-01
    z[3,0,5]  R593      1.6880555450916290e-01
    z[3,0,5]  R594      -4.3299937248229980e-01
    z[3,0,5]  R595      -3.3952260017395020e-01
    z[3,0,5]  R596      3.7518686056137085e-01
    z[3,0,5]  R597      -1.9954627752304077e-01
    z[3,0,5]  R598      -3.0268070101737976e-01
    z[3,0,5]  R599      2.9153221845626831e-01
    z[3,0,5]  R600      1.7578034102916718e-01
    z[3,0,5]  R601      1.4103178679943085e-01
    z[3,0,5]  R602      -4.5463374257087708e-01
    z[3,0,5]  R603      5.9324383735656738e-02
    z[3,0,5]  R604      -1.2676222622394562e-01
    z[3,0,5]  R605      5.3338032215833664e-02
    z[3,0,5]  R606      -8.9633306488394737e-03
    z[3,0,5]  R607      4.0861195325851440e-01
    z[3,0,5]  R608      -7.8010559082031250e-02
    z[3,0,5]  R609      -2.3163343966007233e-01
    z[3,0,5]  R610      0.273774117231369
    z[3,0,5]  R611      -5.2762970328330994e-02
    z[3,0,5]  R612      2.3675620555877686e-01
    z[3,0,5]  R613      2.2943376004695892e-01
    z[3,0,5]  R614      7.5764514505863190e-02
    z[3,0,5]  R615      1.8387521803379059e-01
    z[3,0,5]  R616      -2.7558884024620056e-01
    z[3,0,5]  R617      5.9021270275115967e-01
    z[3,0,5]  R618      2.2301357984542847e-01
    z[3,0,5]  R619      -7.0829652249813080e-02
    z[3,0,5]  R620      1.4459949731826782e-01
    z[3,0,5]  R621      1.5825821086764336e-02
    z[3,0,5]  R622      3.1916475296020508e-01
    z[3,0,5]  R623      4.4475227594375610e-01
    z[3,0,5]  R624      -4.2168667912483215e-01
    z[3,0,5]  R625      -2.6205161213874817e-01
    z[3,0,5]  R626      1.1747315526008606e-02
    z[3,0,5]  R627      -3.8046085834503174e-01
    z[3,0,5]  R628      -3.9427403360605240e-02
    z[3,0,5]  R629      2.6306691765785217e-01
    z[3,0,5]  R630      -1.9467723369598389e-01
    z[3,0,5]  R631      2.1556799113750458e-01
    z[3,0,5]  R632      -2.4909430742263794e-01
    z[3,0,5]  R633      -3.0473336577415466e-01
    z[3,0,5]  R634      4.8819732666015625e-01
    z[3,0,5]  R635      -2.2189967334270477e-01
    z[3,0,5]  R636      -6.8342939019203186e-02
    z[3,0,5]  R637      3.0620506405830383e-01
    z[3,0,5]  R638      1.1011601239442825e-01
    z[3,0,5]  R639      -2.7557021379470825e-01
    z[3,0,5]  R640      -3.2930124551057816e-02
    z[3,0,5]  R641      -1.1862007528543472e-01
    z[3,0,5]  R642      2.8669700026512146e-01
    z[3,0,5]  R643      8.7456069886684418e-03
    z[3,0,5]  R644      9.1848298907279968e-02
    z[3,0,5]  R645      3.6754995584487915e-01
    z[3,0,5]  R646      2.0405404269695282e-01
    z[3,0,5]  R647      0.280277818441391
    z[3,0,5]  R648      -2.3130537569522858e-01
    z[3,0,5]  R649      3.6788681149482727e-01
    z[3,0,5]  R650      -3.6726880073547363e-01
    z[3,0,5]  R651      2.8330111503601074e-01
    z[3,0,5]  R652      -4.9175322055816650e-02
    z[3,0,5]  R653      -4.5591026544570923e-02
    z[3,0,5]  R654      3.1311208009719849e-01
    z[3,0,5]  R655      4.0186995267868042e-01
    z[3,0,5]  R656      -1.1770709417760372e-02
    z[3,0,5]  R657      3.1503564119338989e-01
    z[3,0,5]  R658      2.5389587879180908e-01
    z[3,0,5]  R659      7.6005801558494568e-02
    z[3,0,5]  R660      -1.4338185079395771e-02
    z[3,0,5]  R661      1.1591343581676483e-01
    z[3,0,5]  R662      -6.0779560357332230e-02
    z[3,0,5]  R663      2.6166474819183350e-01
    z[3,0,5]  R664      3.6587905883789062e-01
    z[3,0,5]  R665      1.5322747826576233e-01
    z[3,0,5]  R666      -3.3494135737419128e-01
    z[3,0,5]  R667      -3.2431003451347351e-01
    z[3,0,5]  R668      -4.3392094969749451e-01
    z[3,0,5]  R669      1.3375861942768097e-01
    z[3,0,5]  R670      -6.6862389445304871e-02
    z[3,0,5]  R671      -4.9372907727956772e-02
    z[3,0,5]  R672      -2.2421722114086151e-01
    z[3,0,5]  R673      -3.4554848074913025e-01
    z[3,0,5]  R674      -9.1310754418373108e-02
    z[3,0,5]  R675      1.6689199209213257e-01
    z[3,0,5]  R676      1.0497282445430756e-01
    z[3,0,5]  R677      -2.2765980660915375e-01
    z[3,0,5]  R678      -2.7418437600135803e-01
    z[3,0,5]  R679      3.8546571135520935e-01
    z[3,0,5]  R680      8.5960216820240021e-02
    z[3,0,5]  R681      -3.0100712180137634e-01
    z[3,0,5]  R682      3.7864178419113159e-01
    z[3,0,5]  R683      4.0323731303215027e-01
    z[3,0,5]  R684      4.7610646486282349e-01
    z[3,0,5]  R685      -4.0040472149848938e-01
    z[3,0,5]  R686      -3.4990664571523666e-02
    z[3,0,5]  R687      -6.4122414588928223e-01
    z[3,0,5]  R688      7.6918698847293854e-02
    z[3,0,5]  R689      3.3405745029449463e-01
    z[3,0,5]  R690      -2.5700443983078003e-01
    z[3,0,5]  R691      1.7790308222174644e-02
    z[3,0,5]  R692      1.7716838419437408e-01
    z[3,0,5]  R693      4.1874179244041443e-01
    z[3,0,5]  R694      -5.2343491464853287e-02
    z[3,0,5]  R695      1.1070173233747482e-01
    z[3,0,5]  R696      1.1411818861961365e-01
    z[3,0,6]  R8        1
    z[3,0,6]  R35       -1
    z[3,0,6]  R548      -1
    z[3,0,6]  R549      1
    z[3,0,6]  R550      3.2224437594413757e-01
    z[3,0,6]  R551      3.2228657603263855e-01
    z[3,0,6]  R552      1.8866769969463348e-01
    z[3,0,6]  R553      -4.9333442002534866e-02
    z[3,0,6]  R554      -0.0901155099272728
    z[3,0,6]  R555      0.395723819732666
    z[3,0,6]  R556      -5.4834973812103271e-01
    z[3,0,6]  R557      8.3916939795017242e-02
    z[3,0,6]  R558      1.7447138205170631e-02
    z[3,0,6]  R559      -7.4526853859424591e-02
    z[3,0,6]  R560      -6.3740599155426025e-01
    z[3,0,6]  R561      0.441743403673172
    z[3,0,6]  R562      -4.3122348189353943e-01
    z[3,0,6]  R563      -1.4081505127251148e-02
    z[3,0,6]  R564      -1.4989298582077026e-01
    z[3,0,6]  R565      3.9437824487686157e-01
    z[3,0,6]  R566      3.5007354617118835e-01
    z[3,0,6]  R567      2.1143538877367973e-02
    z[3,0,6]  R568      1.4839254319667816e-02
    z[3,0,6]  R569      2.5452831387519836e-01
    z[3,0,6]  R570      -1.6930031776428223e-01
    z[3,0,6]  R571      -4.4117712974548340e-01
    z[3,0,6]  R572      4.8542764782905579e-01
    z[3,0,6]  R573      1.9095657765865326e-01
    z[3,0,6]  R574      -2.2461685538291931e-01
    z[3,0,6]  R575      -7.7713549137115479e-02
    z[3,0,6]  R576      4.4267535209655762e-01
    z[3,0,6]  R577      1.3879722356796265e-01
    z[3,0,6]  R578      -1.3862450420856476e-01
    z[3,0,6]  R579      -1.2953819334506989e-01
    z[3,0,6]  R580      2.0793128013610840e-01
    z[3,0,6]  R581      5.6596368551254272e-02
    z[3,0,6]  R582      6.0966953635215759e-02
    z[3,0,6]  R583      -4.5595744252204895e-01
    z[3,0,6]  R584      -4.7271448373794556e-01
    z[3,0,6]  R585      3.4640945494174957e-02
    z[3,0,6]  R586      1.9651544094085693e-01
    z[3,0,6]  R587      2.3814779520034790e-01
    z[3,0,6]  R588      -3.2557934522628784e-01
    z[3,0,6]  R589      -4.1531622409820557e-02
    z[3,0,6]  R590      -1.8709658086299896e-01
    z[3,0,6]  R591      1.7484484612941742e-01
    z[3,0,6]  R592      3.7786448001861572e-01
    z[3,0,6]  R593      -3.1138148903846741e-01
    z[3,0,6]  R594      -1.9536325708031654e-03
    z[3,0,6]  R595      -3.1438705325126648e-01
    z[3,0,6]  R596      4.4407594203948975e-01
    z[3,0,6]  R597      0.00967728067189455
    z[3,0,6]  R598      2.8715759515762329e-01
    z[3,0,6]  R599      -1.4299340546131134e-01
    z[3,0,6]  R600      -2.4260684847831726e-02
    z[3,0,6]  R601      4.2003687471151352e-02
    z[3,0,6]  R602      2.5526729226112366e-01
    z[3,0,6]  R603      4.4603681564331055e-01
    z[3,0,6]  R604      3.3880195021629333e-01
    z[3,0,6]  R605      -3.7438246607780457e-01
    z[3,0,6]  R606      -4.9122944474220276e-01
    z[3,0,6]  R607      5.3314030170440674e-01
    z[3,0,6]  R608      -3.0161604285240173e-01
    z[3,0,6]  R609      1.4251299202442169e-01
    z[3,0,6]  R610      -9.3784462660551071e-03
    z[3,0,6]  R611      -1.4829332008957863e-02
    z[3,0,6]  R612      -4.6136882901191711e-01
    z[3,0,6]  R613      -1.3811211287975311e-01
    z[3,0,6]  R614      1.1487468332052231e-01
    z[3,0,6]  R615      1.3688622973859310e-02
    z[3,0,6]  R616      -5.4443454742431641e-01
    z[3,0,6]  R617      2.2189514338970184e-01
    z[3,0,6]  R618      -2.5713866949081421e-01
    z[3,0,6]  R619      1.9530370831489563e-02
    z[3,0,6]  R620      3.9185574650764465e-01
    z[3,0,6]  R621      -5.6224983185529709e-02
    z[3,0,6]  R622      -2.7617835998535156e-01
    z[3,0,6]  R623      -1.0886877775192261e-01
    z[3,0,6]  R624      1.6325150430202484e-01
    z[3,0,6]  R625      -3.6671221256256104e-01
    z[3,0,6]  R626      1.9295718520879745e-02
    z[3,0,6]  R627      0.280496209859848
    z[3,0,6]  R628      3.5179728269577026e-01
    z[3,0,6]  R629      3.4558865427970886e-01
    z[3,0,6]  R630      1.1742081493139267e-01
    z[3,0,6]  R631      -2.6539623737335205e-01
    z[3,0,6]  R632      2.7670052647590637e-01
    z[3,0,6]  R633      3.8323320448398590e-02
    z[3,0,6]  R634      6.8560346961021423e-02
    z[3,0,6]  R635      -2.5408580899238586e-01
    z[3,0,6]  R636      -4.8990118503570557e-01
    z[3,0,6]  R637      2.3935526609420776e-01
    z[3,0,6]  R638      -6.3910400867462158e-01
    z[3,0,6]  R639      1.3189865648746490e-01
    z[3,0,6]  R640      4.1688024997711182e-02
    z[3,0,6]  R641      -7.4217252433300018e-02
    z[3,0,6]  R642      -2.4170126020908356e-01
    z[3,0,6]  R643      -1.0254694148898125e-02
    z[3,0,6]  R644      0.088455431163311
    z[3,0,6]  R645      -5.0630939006805420e-01
    z[3,0,6]  R646      7.0999123156070709e-02
    z[3,0,6]  R647      -3.2858546823263168e-02
    z[3,0,6]  R648      8.8604830205440521e-02
    z[3,0,6]  R649      4.9064168706536293e-03
    z[3,0,6]  R650      2.8341269493103027e-01
    z[3,0,6]  R651      -1.8354374170303345e-01
    z[3,0,6]  R652      4.4690284132957458e-01
    z[3,0,6]  R653      4.0696394443511963e-01
    z[3,0,6]  R654      -4.0506433695554733e-02
    z[3,0,6]  R655      3.2720208168029785e-01
    z[3,0,6]  R656      1.0336861759424210e-01
    z[3,0,6]  R657      -1.9738449156284332e-01
    z[3,0,6]  R658      -3.4226831048727036e-02
    z[3,0,6]  R659      4.3831002712249756e-01
    z[3,0,6]  R660      -1.2033692747354507e-01
    z[3,0,6]  R661      -3.2512211799621582e-01
    z[3,0,6]  R662      -4.3581396341323853e-01
    z[3,0,6]  R663      2.4558633565902710e-01
    z[3,0,6]  R664      4.3737164139747620e-01
    z[3,0,6]  R665      -4.1613289713859558e-01
    z[3,0,6]  R666      -1.3238739967346191e-01
    z[3,0,6]  R667      -1.2371501326560974e-01
    z[3,0,6]  R668      4.7032165527343750e-01
    z[3,0,6]  R669      -2.1344347298145294e-01
    z[3,0,6]  R670      -1.2281096726655960e-01
    z[3,0,6]  R671      3.1134957075119019e-01
    z[3,0,6]  R672      4.4350346922874451e-01
    z[3,0,6]  R673      -1.6316774487495422e-01
    z[3,0,6]  R674      1.5427152812480927e-01
    z[3,0,6]  R675      2.6543816924095154e-01
    z[3,0,6]  R676      -1.0702729225158691e-01
    z[3,0,6]  R677      5.6285685300827026e-01
    z[3,0,6]  R678      2.3148207366466522e-01
    z[3,0,6]  R679      -1.2104640156030655e-01
    z[3,0,6]  R680      -0.295296311378479
    z[3,0,6]  R681      -1.9183368980884552e-01
    z[3,0,6]  R682      1.1599563807249069e-01
    z[3,0,6]  R683      0.0747029259800911
    z[3,0,6]  R684      -2.4605879187583923e-01
    z[3,0,6]  R685      2.8579438105225563e-02
    z[3,0,6]  R686      0.0792076513171196
    z[3,0,6]  R687      -2.3442563414573669e-01
    z[3,0,6]  R688      -2.8481602668762207e-01
    z[3,0,6]  R689      8.9047178626060486e-03
    z[3,0,6]  R690      3.2759314775466919e-01
    z[3,0,6]  R691      -1.4143096632324159e-04
    z[3,0,6]  R692      1.8598626554012299e-01
    z[3,0,6]  R693      -2.0224186778068542e-01
    z[3,0,6]  R694      -2.2372610867023468e-01
    z[3,0,6]  R695      4.0545615553855896e-01
    z[3,0,6]  R696      -9.1858208179473877e-02
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R697      -1
    z[0,4,0]  R698      1
    z[0,4,0]  R711      -2.7911195158958435e-01
    z[0,4,0]  R712      -2.5956231355667114e-01
    z[0,4,0]  R713      -0.200189471244812
    z[0,4,0]  R714      9.5063948631286621e-01
    z[0,4,0]  R715      5.5172234773635864e-01
    z[0,4,0]  R716      8.2528567314147949e-01
    z[0,4,0]  R717      8.0844157934188843e-01
    z[0,4,0]  R718      8.0433422327041626e-01
    z[0,4,0]  R719      -2.6695212721824646e-01
    z[0,4,0]  R720      4.4909101724624634e-01
    z[0,4,0]  R721      -6.7703330516815186e-01
    z[0,4,0]  R722      -8.4879899024963379e-01
    z[0,4,0]  R723      -7.9707098007202148e-01
    z[0,4,0]  R724      -6.5170717239379883e-01
    z[0,4,0]  R725      -5.3997147083282471e-01
    z[0,4,0]  R726      -5.1643681526184082e-01
    z[0,4,0]  R727      -4.9135014414787292e-01
    z[0,4,0]  R728      -7.3041713237762451e-01
    z[0,4,0]  R729      -4.2066127061843872e-01
    z[0,4,0]  R730      -0.335271954536438
    z[0,4,0]  R731      -7.8593236207962036e-01
    z[0,4,0]  R732      -4.8112070560455322e-01
    z[0,4,0]  R733      -8.0663490295410156e-01
    z[0,4,0]  R734      -4.5488181710243225e-01
    z[0,4,0]  R735      -3.4604361653327942e-01
    z[0,4,0]  R736      -0.739958643913269
    z[0,4,0]  R737      -5.4418420791625977e-01
    z[0,4,0]  R738      -3.8419404625892639e-01
    z[0,4,0]  R739      -3.8750213384628296e-01
    z[0,4,0]  R740      -1.6495670378208160e-01
    z[0,4,0]  R741      -6.4012104272842407e-01
    z[0,4,0]  R742      -4.5631998777389526e-01
    z[0,4,0]  R743      -6.9034153223037720e-01
    z[0,4,0]  R744      -4.7739055752754211e-01
    z[0,4,0]  R745      -3.3747208118438721e-01
    z[0,4,0]  R746      0.616935133934021
    z[0,4,0]  R747      -2.9487824440002441e-01
    z[0,4,0]  R748      -3.2894019037485123e-02
    z[0,4,0]  R749      2.6451559737324715e-02
    z[0,4,0]  R750      -5.9227943420410156e-02
    z[0,4,0]  R751      -3.2220444083213806e-01
    z[0,4,0]  R752      -4.7876590490341187e-01
    z[0,4,0]  R753      -2.2320681810379028e-01
    z[0,4,0]  R754      -3.1698886305093765e-02
    z[0,4,0]  R755      4.0914884209632874e-01
    z[0,4,0]  R756      2.0863594114780426e-01
    z[0,4,0]  R757      4.6707686781883240e-01
    z[0,4,0]  R758      5.0943013280630112e-02
    z[0,4,0]  R759      3.4773871302604675e-01
    z[0,4,0]  R760      8.9614562690258026e-02
    z[0,4,0]  R761      -0.302606999874115
    z[0,4,0]  R762      -8.2195393741130829e-02
    z[0,4,0]  R763      -1.9792994856834412e-01
    z[0,4,0]  R764      -2.2379927337169647e-01
    z[0,4,0]  R765      0.0955568253993988
    z[0,4,0]  R766      5.4114109277725220e-01
    z[0,4,0]  R767      5.3917460143566132e-02
    z[0,4,0]  R768      3.4159538149833679e-01
    z[0,4,0]  R769      4.7162267565727234e-01
    z[0,4,0]  R770      2.4069221317768097e-01
    z[0,4,0]  R771      5.5870389938354492e-01
    z[0,4,0]  R772      9.9818736314773560e-02
    z[0,4,0]  R773      -2.0530523732304573e-02
    z[0,4,0]  R774      8.2103852182626724e-03
    z[0,4,0]  R775      -1.4202977716922760e-01
    z[0,4,0]  R776      -4.8766386508941650e-01
    z[0,4,0]  R777      -1.5281499922275543e-01
    z[0,4,0]  R778      8.8300663232803345e-01
    z[0,4,0]  R779      7.5461864471435547e-01
    z[0,4,0]  R780      8.5505962371826172e-01
    z[0,4,0]  R781      -7.1266913414001465e-01
    z[0,4,0]  R782      -0.489612340927124
    z[0,4,0]  R783      -6.8424749374389648e-01
    z[0,4,0]  R784      -5.7680004835128784e-01
    z[0,4,0]  R785      -0.0508616641163826
    z[0,4,0]  R786      9.8354585468769073e-02
    z[0,4,0]  R787      -1.6463661193847656e-01
    z[0,4,0]  R788      -2.3018735647201538e-01
    z[0,4,0]  R789      -2.4711753427982330e-01
    z[0,4,0]  R790      -7.2288691997528076e-02
    z[0,4,0]  R791      -5.7580053806304932e-01
    z[0,4,0]  R792      2.5338813662528992e-01
    z[0,4,0]  R793      2.2624200209975243e-02
    z[0,4,0]  R794      4.2387198656797409e-02
    z[0,4,0]  R795      4.6951755881309509e-02
    z[0,4,0]  R796      1.1479977518320084e-01
    z[0,4,0]  R797      -7.6783820986747742e-03
    z[0,4,0]  R798      -4.7213941812515259e-02
    z[0,4,0]  R799      2.0390398800373077e-01
    z[0,4,0]  R800      4.9588415771722794e-02
    z[0,4,0]  R801      -0.370315819978714
    z[0,4,0]  R802      -4.2799603939056396e-01
    z[0,4,0]  R803      2.4122430384159088e-01
    z[0,4,0]  R804      0.111538365483284
    z[0,4,0]  R805      2.3198957741260529e-01
    z[0,4,0]  R806      2.9266181588172913e-01
    z[0,4,0]  R807      -2.6075911521911621e-01
    z[0,4,0]  R808      0.12830850481987
    z[0,4,0]  R809      2.7927669882774353e-01
    z[0,4,0]  R810      2.9127854108810425e-01
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R699      -1
    z[0,4,1]  R700      1
    z[0,4,1]  R711      5.7454162836074829e-01
    z[0,4,1]  R712      1.6744308173656464e-01
    z[0,4,1]  R713      3.1051808595657349e-01
    z[0,4,1]  R714      1.8348847329616547e-01
    z[0,4,1]  R715      7.3893499374389648e-01
    z[0,4,1]  R716      1.7857621610164642e-01
    z[0,4,1]  R717      5.3061944246292114e-01
    z[0,4,1]  R718      4.6047952771186829e-01
    z[0,4,1]  R719      4.5100402832031250e-01
    z[0,4,1]  R720      0.596885621547699
    z[0,4,1]  R721      -3.4250352531671524e-02
    z[0,4,1]  R722      -2.0875754952430725e-01
    z[0,4,1]  R723      2.0808492600917816e-01
    z[0,4,1]  R724      -4.1754089295864105e-02
    z[0,4,1]  R725      5.3702068328857422e-01
    z[0,4,1]  R726      -3.1882904469966888e-02
    z[0,4,1]  R727      -4.5007994771003723e-01
    z[0,4,1]  R728      -5.1013922691345215e-01
    z[0,4,1]  R729      -2.0662444829940796e-01
    z[0,4,1]  R730      -6.6670411825180054e-01
    z[0,4,1]  R731      4.5394363999366760e-01
    z[0,4,1]  R732      7.4497830867767334e-01
    z[0,4,1]  R733      2.1404880285263062e-01
    z[0,4,1]  R734      7.1047663688659668e-01
    z[0,4,1]  R735      6.4928478002548218e-01
    z[0,4,1]  R736      3.7441188097000122e-01
    z[0,4,1]  R737      1.0908488184213638e-02
    z[0,4,1]  R738      4.2736539244651794e-01
    z[0,4,1]  R739      4.4189310073852539e-01
    z[0,4,1]  R740      2.7838796377182007e-01
    z[0,4,1]  R741      8.7187774479389191e-02
    z[0,4,1]  R742      3.7865081429481506e-01
    z[0,4,1]  R743      -4.3377488851547241e-01
    z[0,4,1]  R744      -6.8070453405380249e-01
    z[0,4,1]  R745      -8.6769664287567139e-01
    z[0,4,1]  R746      2.1589897572994232e-01
    z[0,4,1]  R747      -5.0343447923660278e-01
    z[0,4,1]  R748      -7.4226856231689453e-01
    z[0,4,1]  R749      -9.0129858255386353e-01
    z[0,4,1]  R750      -5.6143432855606079e-01
    z[0,4,1]  R751      6.3973242044448853e-01
    z[0,4,1]  R752      2.6570373773574829e-01
    z[0,4,1]  R753      -7.6507246494293213e-01
    z[0,4,1]  R754      -5.2671676874160767e-01
    z[0,4,1]  R755      -5.2842015027999878e-01
    z[0,4,1]  R756      -4.0489968657493591e-01
    z[0,4,1]  R757      -4.1363832354545593e-01
    z[0,4,1]  R758      -2.0617979764938354e-01
    z[0,4,1]  R759      -5.0428098440170288e-01
    z[0,4,1]  R760      -0.28351891040802
    z[0,4,1]  R761      5.9813719987869263e-01
    z[0,4,1]  R762      -5.6944328546524048e-01
    z[0,4,1]  R763      -7.9107505083084106e-01
    z[0,4,1]  R764      -8.3547854423522949e-01
    z[0,4,1]  R765      -6.2728846073150635e-01
    z[0,4,1]  R766      -1.5642635524272919e-01
    z[0,4,1]  R767      -0.408250629901886
    z[0,4,1]  R768      1.0886962711811066e-01
    z[0,4,1]  R769      -6.0041254758834839e-01
    z[0,4,1]  R770      1.5060398727655411e-03
    z[0,4,1]  R771      5.6021219491958618e-01
    z[0,4,1]  R772      7.8178036212921143e-01
    z[0,4,1]  R773      7.5345677137374878e-01
    z[0,4,1]  R774      3.8890364766120911e-01
    z[0,4,1]  R775      4.9546009302139282e-01
    z[0,4,1]  R776      1.8506301939487457e-01
    z[0,4,1]  R777      1.7123848199844360e-01
    z[0,4,1]  R778      3.8786649703979492e-02
    z[0,4,1]  R779      -2.4267809092998505e-01
    z[0,4,1]  R780      -2.5800105929374695e-01
    z[0,4,1]  R781      -1.9565564393997192e-01
    z[0,4,1]  R782      -1.5061859786510468e-01
    z[0,4,1]  R783      -3.5446065664291382e-01
    z[0,4,1]  R784      -3.8342043757438660e-01
    z[0,4,1]  R785      -8.9201897382736206e-01
    z[0,4,1]  R786      -7.1640813350677490e-01
    z[0,4,1]  R787      -7.1327060461044312e-01
    z[0,4,1]  R788      -4.8758310079574585e-01
    z[0,4,1]  R789      -8.1594669818878174e-01
    z[0,4,1]  R790      -6.2656390666961670e-01
    z[0,4,1]  R791      1.0611204802989960e-01
    z[0,4,1]  R792      -4.4901618361473083e-01
    z[0,4,1]  R793      -7.4879795312881470e-01
    z[0,4,1]  R794      -8.4246599674224854e-01
    z[0,4,1]  R795      -7.3599445819854736e-01
    z[0,4,1]  R796      -7.6748752593994141e-01
    z[0,4,1]  R797      -8.7122011184692383e-01
    z[0,4,1]  R798      -0.759326159954071
    z[0,4,1]  R799      -8.7563234567642212e-01
    z[0,4,1]  R800      -9.0224641561508179e-01
    z[0,4,1]  R801      4.2711898684501648e-01
    z[0,4,1]  R802      1.1950732767581940e-01
    z[0,4,1]  R803      -7.9304671287536621e-01
    z[0,4,1]  R804      -6.9904738664627075e-01
    z[0,4,1]  R805      -8.7748444080352783e-01
    z[0,4,1]  R806      -8.8935530185699463e-01
    z[0,4,1]  R807      -7.5103670358657837e-01
    z[0,4,1]  R808      -8.4581160545349121e-01
    z[0,4,1]  R809      -1.1033361405134201e-01
    z[0,4,1]  R810      -6.0323875397443771e-02
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R701      -1
    z[0,4,2]  R702      1
    z[0,4,2]  R711      1.5083377063274384e-01
    z[0,4,2]  R712      2.3986802995204926e-01
    z[0,4,2]  R713      -1.8829308450222015e-01
    z[0,4,2]  R714      2.4266245961189270e-01
    z[0,4,2]  R715      -3.3070594072341919e-01
    z[0,4,2]  R716      3.0206015706062317e-01
    z[0,4,2]  R717      -1.5245966613292694e-01
    z[0,4,2]  R718      1.9436698406934738e-02
    z[0,4,2]  R719      -3.4611273556947708e-02
    z[0,4,2]  R720      -5.8791655302047729e-01
    z[0,4,2]  R721      -6.1598002910614014e-01
    z[0,4,2]  R722      -3.5712572932243347e-01
    z[0,4,2]  R723      -2.3911079764366150e-01
    z[0,4,2]  R724      -3.2284760475158691e-01
    z[0,4,2]  R725      2.2259363532066345e-01
    z[0,4,2]  R726      -5.8785039186477661e-01
    z[0,4,2]  R727      -5.2049297094345093e-01
    z[0,4,2]  R728      -8.4991287440061569e-03
    z[0,4,2]  R729      -5.2151817083358765e-01
    z[0,4,2]  R730      5.2224820852279663e-01
    z[0,4,2]  R731      -4.9242395907640457e-02
    z[0,4,2]  R732      1.6663928329944611e-01
    z[0,4,2]  R733      2.8458821773529053e-01
    z[0,4,2]  R734      -0.265234112739563
    z[0,4,2]  R735      -2.2192781791090965e-02
    z[0,4,2]  R736      6.0554448515176773e-02
    z[0,4,2]  R737      2.0031755790114403e-02
    z[0,4,2]  R738      3.7380585074424744e-01
    z[0,4,2]  R739      5.7075881958007812e-01
    z[0,4,2]  R740      1.7242784798145294e-01
    z[0,4,2]  R741      1.9863437116146088e-01
    z[0,4,2]  R742      -3.7209963798522949e-01
    z[0,4,2]  R743      1.9737100601196289e-01
    z[0,4,2]  R744      4.5568180084228516e-01
    z[0,4,2]  R745      1.1098874360322952e-01
    z[0,4,2]  R746      -2.9603496193885803e-01
    z[0,4,2]  R747      5.4920607805252075e-01
    z[0,4,2]  R748      3.7952467799186707e-01
    z[0,4,2]  R749      1.7176325619220734e-01
    z[0,4,2]  R750      5.3085041046142578e-01
    z[0,4,2]  R751      -2.8079429268836975e-01
    z[0,4,2]  R752      -4.2123457789421082e-01
    z[0,4,2]  R753      0.408405065536499
    z[0,4,2]  R754      7.0510065555572510e-01
    z[0,4,2]  R755      9.5214679837226868e-02
    z[0,4,2]  R756      1.9265627861022949e-01
    z[0,4,2]  R757      1.5138559043407440e-01
    z[0,4,2]  R758      4.2132866382598877e-01
    z[0,4,2]  R759      -1.5476787090301514e-01
    z[0,4,2]  R760      2.9042625427246094e-01
    z[0,4,2]  R761      -1.1957526206970215e-01
    z[0,4,2]  R762      7.2208935022354126e-01
    z[0,4,2]  R763      4.5464840531349182e-01
    z[0,4,2]  R764      2.3715527355670929e-01
    z[0,4,2]  R765      7.1603232622146606e-01
    z[0,4,2]  R766      4.1160178184509277e-01
    z[0,4,2]  R767      0.485909104347229
    z[0,4,2]  R768      7.6738965511322021e-01
    z[0,4,2]  R769      -2.7881422638893127e-01
    z[0,4,2]  R770      -1.6056613624095917e-01
    z[0,4,2]  R771      -3.8512402772903442e-01
    z[0,4,2]  R772      5.6504216045141220e-02
    z[0,4,2]  R773      -3.9413750171661377e-01
    z[0,4,2]  R774      1.1042091995477676e-01
    z[0,4,2]  R775      1.2807871401309967e-01
    z[0,4,2]  R776      1.2600994668900967e-02
    z[0,4,2]  R777      1.0695854574441910e-01
    z[0,4,2]  R778      3.7434976547956467e-02
    z[0,4,2]  R779      1.3555747270584106e-01
    z[0,4,2]  R780      -0.0625605583190918
    z[0,4,2]  R781      0.49066162109375
    z[0,4,2]  R782      3.7475490570068359e-01
    z[0,4,2]  R783      -1.8631502985954285e-01
    z[0,4,2]  R784      -5.3598236292600632e-02
    z[0,4,2]  R785      -9.7490988671779633e-02
    z[0,4,2]  R786      -5.3910166025161743e-01
    z[0,4,2]  R787      -1.0701456665992737e-01
    z[0,4,2]  R788      -3.9065742492675781e-01
    z[0,4,2]  R789      -7.0837214589118958e-02
    z[0,4,2]  R790      -4.8441314697265625e-01
    z[0,4,2]  R791      -1.2420298904180527e-01
    z[0,4,2]  R792      -3.6703076958656311e-01
    z[0,4,2]  R793      -8.0870762467384338e-02
    z[0,4,2]  R794      -1.6054618358612061e-01
    z[0,4,2]  R795      -1.4383193850517273e-01
    z[0,4,2]  R796      -2.4992391467094421e-01
    z[0,4,2]  R797      -8.3724528551101685e-02
    z[0,4,2]  R798      3.0607774853706360e-01
    z[0,4,2]  R799      3.2696709036827087e-01
    z[0,4,2]  R800      2.2576428949832916e-01
    z[0,4,2]  R801      -3.0090728402137756e-01
    z[0,4,2]  R802      -2.3227781057357788e-01
    z[0,4,2]  R803      -1.1948853731155396e-01
    z[0,4,2]  R804      -1.9092109799385071e-01
    z[0,4,2]  R805      3.3038997650146484e-01
    z[0,4,2]  R806      1.7247335612773895e-01
    z[0,4,2]  R807      -6.6403280943632126e-03
    z[0,4,2]  R808      3.6510783433914185e-01
    z[0,4,2]  R809      -7.7136582136154175e-01
    z[0,4,2]  R810      -0.623135507106781
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R703      -1
    z[0,4,3]  R704      1
    z[0,4,3]  R711      -4.8630633950233459e-01
    z[0,4,3]  R712      -9.0782207250595093e-01
    z[0,4,3]  R713      -7.7078616619110107e-01
    z[0,4,3]  R714      2.0572718232870102e-02
    z[0,4,3]  R715      -3.4895248245447874e-03
    z[0,4,3]  R716      -1.3784939050674438e-01
    z[0,4,3]  R717      -1.7129622399806976e-01
    z[0,4,3]  R718      -1.2891253829002380e-01
    z[0,4,3]  R719      -5.7065492868423462e-01
    z[0,4,3]  R720      2.2236967086791992e-01
    z[0,4,3]  R721      1.8083423376083374e-01
    z[0,4,3]  R722      -6.9698132574558258e-02
    z[0,4,3]  R723      1.4075244963169098e-01
    z[0,4,3]  R724      4.2891070246696472e-01
    z[0,4,3]  R725      0.380641371011734
    z[0,4,3]  R726      0.0773368775844574
    z[0,4,3]  R727      3.2796174287796021e-01
    z[0,4,3]  R728      -3.2630673050880432e-01
    z[0,4,3]  R729      2.8481978178024292e-01
    z[0,4,3]  R730      2.4042797088623047e-01
    z[0,4,3]  R731      -1.6804021596908569e-01
    z[0,4,3]  R732      -2.1764262020587921e-01
    z[0,4,3]  R733      -1.5559849143028259e-01
    z[0,4,3]  R734      -2.0663103461265564e-01
    z[0,4,3]  R735      -4.0528619289398193e-01
    z[0,4,3]  R736      -3.3417305350303650e-01
    z[0,4,3]  R737      -6.7320454120635986e-01
    z[0,4,3]  R738      -2.5686460733413696e-01
    z[0,4,3]  R739      -2.0680793095380068e-03
    z[0,4,3]  R740      -4.6091657876968384e-01
    z[0,4,3]  R741      -6.1763554811477661e-01
    z[0,4,3]  R742      -2.4363413453102112e-01
    z[0,4,3]  R743      4.7199773788452148e-01
    z[0,4,3]  R744      -1.1488460004329681e-01
    z[0,4,3]  R745      9.7651846706867218e-02
    z[0,4,3]  R746      4.2816668748855591e-01
    z[0,4,3]  R747      3.2782697677612305e-01
    z[0,4,3]  R748      -4.7279921174049377e-01
    z[0,4,3]  R749      -5.6368038058280945e-02
    z[0,4,3]  R750      -5.9518980979919434e-01
    z[0,4,3]  R751      -1.8755196034908295e-01
    z[0,4,3]  R752      -2.4840892851352692e-01
    z[0,4,3]  R753      -2.1829817444086075e-02
    z[0,4,3]  R754      2.9045999050140381e-01
    z[0,4,3]  R755      -6.3881975412368774e-01
    z[0,4,3]  R756      7.2736620903015137e-01
    z[0,4,3]  R757      0.645383358001709
    z[0,4,3]  R758      6.5305101871490479e-01
    z[0,4,3]  R759      -4.8276394605636597e-01
    z[0,4,3]  R760      8.8347822427749634e-01
    z[0,4,3]  R761      5.1070757210254669e-02
    z[0,4,3]  R762      1.2201625853776932e-01
    z[0,4,3]  R763      1.0796375572681427e-01
    z[0,4,3]  R764      -4.6345632523298264e-02
    z[0,4,3]  R765      -2.7514001727104187e-01
    z[0,4,3]  R766      -4.4121104478836060e-01
    z[0,4,3]  R767      6.0426419973373413e-01
    z[0,4,3]  R768      -0.250192791223526
    z[0,4,3]  R769      -4.0110346674919128e-01
    z[0,4,3]  R770      8.6320447921752930e-01
    z[0,4,3]  R771      -3.8021820783615112e-01
    z[0,4,3]  R772      -4.8384204506874084e-01
    z[0,4,3]  R773      -3.6220863461494446e-01
    z[0,4,3]  R774      -4.1754421591758728e-01
    z[0,4,3]  R775      -2.9438000917434692e-01
    z[0,4,3]  R776      -3.1255516409873962e-01
    z[0,4,3]  R777      6.8910324573516846e-01
    z[0,4,3]  R778      -3.0642330646514893e-01
    z[0,4,3]  R779      -0.398311972618103
    z[0,4,3]  R780      -2.8055045008659363e-01
    z[0,4,3]  R781      2.8187143802642822e-01
    z[0,4,3]  R782      4.5860681682825089e-02
    z[0,4,3]  R783      -2.4828857183456421e-01
    z[0,4,3]  R784      -1.3207701034843922e-02
    z[0,4,3]  R785      -8.9316688477993011e-02
    z[0,4,3]  R786      -2.1141889691352844e-01
    z[0,4,3]  R787      9.3292370438575745e-02
    z[0,4,3]  R788      -3.2621735334396362e-01
    z[0,4,3]  R789      -1.0185866057872772e-01
    z[0,4,3]  R790      -3.8146099448204041e-01
    z[0,4,3]  R791      3.0751854181289673e-01
    z[0,4,3]  R792      -6.9934684038162231e-01
    z[0,4,3]  R793      -3.2809826731681824e-01
    z[0,4,3]  R794      -3.1848379969596863e-01
    z[0,4,3]  R795      -3.9895847439765930e-01
    z[0,4,3]  R796      -3.7319111824035645e-01
    z[0,4,3]  R797      3.6862384527921677e-02
    z[0,4,3]  R798      8.2869239151477814e-02
    z[0,4,3]  R799      2.8244696557521820e-02
    z[0,4,3]  R800      -5.6988544762134552e-02
    z[0,4,3]  R801      4.1068476438522339e-01
    z[0,4,3]  R802      3.7810587882995605e-01
    z[0,4,3]  R803      -3.4058916568756104e-01
    z[0,4,3]  R804      -5.4312676191329956e-01
    z[0,4,3]  R805      -9.5807880163192749e-02
    z[0,4,3]  R806      2.8587602078914642e-02
    z[0,4,3]  R807      -3.5784307122230530e-01
    z[0,4,3]  R808      2.3451048135757446e-01
    z[0,4,3]  R809      4.9130004644393921e-01
    z[0,4,3]  R810      4.0348741412162781e-01
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R705      -1
    z[0,4,4]  R706      1
    z[0,4,4]  R711      2.0659589767456055e-01
    z[0,4,4]  R712      1.2071436643600464e-01
    z[0,4,4]  R713      -2.7697184681892395e-01
    z[0,4,4]  R714      -2.2041415795683861e-02
    z[0,4,4]  R715      -1.4359714090824127e-01
    z[0,4,4]  R716      -1.9014884531497955e-01
    z[0,4,4]  R717      -1.0998731106519699e-01
    z[0,4,4]  R718      3.2825049757957458e-01
    z[0,4,4]  R719      -8.3933107554912567e-02
    z[0,4,4]  R720      1.6483344137668610e-02
    z[0,4,4]  R721      -2.2064687311649323e-01
    z[0,4,4]  R722      -2.0545309782028198e-01
    z[0,4,4]  R723      3.3019462227821350e-01
    z[0,4,4]  R724      2.6482102274894714e-01
    z[0,4,4]  R725      -3.3414953947067261e-01
    z[0,4,4]  R726      4.2259556055068970e-01
    z[0,4,4]  R727      -9.9161945283412933e-02
    z[0,4,4]  R728      -4.5455410145223141e-03
    z[0,4,4]  R729      3.9835435152053833e-01
    z[0,4,4]  R730      3.1894508004188538e-01
    z[0,4,4]  R731      -8.5877306759357452e-02
    z[0,4,4]  R732      -2.6973801851272583e-01
    z[0,4,4]  R733      -2.0720811560750008e-02
    z[0,4,4]  R734      4.0071615576744080e-01
    z[0,4,4]  R735      4.1808298230171204e-01
    z[0,4,4]  R736      5.7537477463483810e-02
    z[0,4,4]  R737      3.4836444258689880e-01
    z[0,4,4]  R738      3.7266877293586731e-01
    z[0,4,4]  R739      0.363534539937973
    z[0,4,4]  R740      -7.2346520423889160e-01
    z[0,4,4]  R741      2.0305566489696503e-01
    z[0,4,4]  R742      2.0270688831806183e-01
    z[0,4,4]  R743      -1.0040581226348877e-01
    z[0,4,4]  R744      -2.6142343878746033e-01
    z[0,4,4]  R745      -1.0947328805923462e-01
    z[0,4,4]  R746      2.3419323563575745e-01
    z[0,4,4]  R747      -3.2322630286216736e-01
    z[0,4,4]  R748      -2.1963614225387573e-01
    z[0,4,4]  R749      -2.3658205568790436e-01
    z[0,4,4]  R750      -1.5085247159004211e-01
    z[0,4,4]  R751      -6.5335296094417572e-02
    z[0,4,4]  R752      -5.7643568515777588e-01
    z[0,4,4]  R753      -1.8529847264289856e-01
    z[0,4,4]  R754      -2.1317061781883240e-01
    z[0,4,4]  R755      9.3847788870334625e-02
    z[0,4,4]  R756      2.6367539167404175e-01
    z[0,4,4]  R757      -5.5896721780300140e-02
    z[0,4,4]  R758      2.5234678387641907e-01
    z[0,4,4]  R759      4.5455864071846008e-01
    z[0,4,4]  R760      1.9800759851932526e-01
    z[0,4,4]  R761      -2.6005905866622925e-01
    z[0,4,4]  R762      -2.1363671123981476e-01
    z[0,4,4]  R763      7.0633560419082642e-02
    z[0,4,4]  R764      -1.4188164472579956e-01
    z[0,4,4]  R765      9.3043945729732513e-02
    z[0,4,4]  R766      5.0262737274169922e-01
    z[0,4,4]  R767      1.1373239010572433e-01
    z[0,4,4]  R768      4.0888068079948425e-01
    z[0,4,4]  R769      4.2495880275964737e-02
    z[0,4,4]  R770      -3.8691172003746033e-01
    z[0,4,4]  R771      -1.8614172935485840e-01
    z[0,4,4]  R772      2.1207168698310852e-01
    z[0,4,4]  R773      1.3169211149215698e-01
    z[0,4,4]  R774      -5.8622401952743530e-01
    z[0,4,4]  R775      -7.0075875520706177e-01
    z[0,4,4]  R776      2.7352645993232727e-02
    z[0,4,4]  R777      4.4997197389602661e-01
    z[0,4,4]  R778      -1.1206955462694168e-01
    z[0,4,4]  R779      -3.5753118991851807e-01
    z[0,4,4]  R780      3.3977007865905762e-01
    z[0,4,4]  R781      5.3274929523468018e-02
    z[0,4,4]  R782      4.2905649542808533e-01
    z[0,4,4]  R783      3.0451324582099915e-01
    z[0,4,4]  R784      6.3623654842376709e-01
    z[0,4,4]  R785      -3.5619032382965088e-01
    z[0,4,4]  R786      -7.8622095286846161e-02
    z[0,4,4]  R787      -1.7840167507529259e-02
    z[0,4,4]  R788      -8.1945598125457764e-02
    z[0,4,4]  R789      -6.9304317235946655e-02
    z[0,4,4]  R790      -0.0410560667514801
    z[0,4,4]  R791      -3.1161725521087646e-01
    z[0,4,4]  R792      1.3672819733619690e-01
    z[0,4,4]  R793      -3.2310044765472412e-01
    z[0,4,4]  R794      8.5804097354412079e-02
    z[0,4,4]  R795      -1.7356221377849579e-01
    z[0,4,4]  R796      -7.4332311749458313e-02
    z[0,4,4]  R797      -3.4329265356063843e-02
    z[0,4,4]  R798      -3.0796703696250916e-01
    z[0,4,4]  R799      2.1189035475254059e-01
    z[0,4,4]  R800      5.9805028140544891e-02
    z[0,4,4]  R801      1.9889065623283386e-01
    z[0,4,4]  R802      -2.7678728103637695e-01
    z[0,4,4]  R803      3.1266503036022186e-02
    z[0,4,4]  R804      -3.5277768969535828e-01
    z[0,4,4]  R805      -5.2817653864622116e-02
    z[0,4,4]  R806      -1.7005857825279236e-01
    z[0,4,4]  R807      -3.9837956428527832e-01
    z[0,4,4]  R808      -2.1901425719261169e-01
    z[0,4,4]  R809      -4.2809482663869858e-02
    z[0,4,4]  R810      -4.0744204074144363e-02
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R707      -1
    z[0,4,5]  R708      1
    z[0,4,5]  R711      -5.0445652008056641e-01
    z[0,4,5]  R712      -7.6856710016727448e-02
    z[0,4,5]  R713      2.5028528645634651e-02
    z[0,4,5]  R714      -3.2930124551057816e-02
    z[0,4,5]  R715      -1.1862007528543472e-01
    z[0,4,5]  R716      2.8669700026512146e-01
    z[0,4,5]  R717      8.7456069886684418e-03
    z[0,4,5]  R718      9.1848298907279968e-02
    z[0,4,5]  R719      3.6754995584487915e-01
    z[0,4,5]  R720      2.0405404269695282e-01
    z[0,4,5]  R721      0.280277818441391
    z[0,4,5]  R722      -2.3130537569522858e-01
    z[0,4,5]  R723      3.6788681149482727e-01
    z[0,4,5]  R724      -3.6726880073547363e-01
    z[0,4,5]  R725      2.8330111503601074e-01
    z[0,4,5]  R726      -4.9175322055816650e-02
    z[0,4,5]  R727      -4.5591026544570923e-02
    z[0,4,5]  R728      3.1311208009719849e-01
    z[0,4,5]  R729      4.0186995267868042e-01
    z[0,4,5]  R730      -1.1770709417760372e-02
    z[0,4,5]  R731      3.1503564119338989e-01
    z[0,4,5]  R732      2.5389587879180908e-01
    z[0,4,5]  R733      7.6005801558494568e-02
    z[0,4,5]  R734      -1.4338185079395771e-02
    z[0,4,5]  R735      1.1591343581676483e-01
    z[0,4,5]  R736      -6.0779560357332230e-02
    z[0,4,5]  R737      2.6166474819183350e-01
    z[0,4,5]  R738      3.6587905883789062e-01
    z[0,4,5]  R739      1.5322747826576233e-01
    z[0,4,5]  R740      -3.3494135737419128e-01
    z[0,4,5]  R741      -3.2431003451347351e-01
    z[0,4,5]  R742      -4.3392094969749451e-01
    z[0,4,5]  R743      1.3375861942768097e-01
    z[0,4,5]  R744      -6.6862389445304871e-02
    z[0,4,5]  R745      -4.9372907727956772e-02
    z[0,4,5]  R746      -2.2421722114086151e-01
    z[0,4,5]  R747      -3.4554848074913025e-01
    z[0,4,5]  R748      -9.1310754418373108e-02
    z[0,4,5]  R749      1.6689199209213257e-01
    z[0,4,5]  R750      1.0497282445430756e-01
    z[0,4,5]  R751      -2.2765980660915375e-01
    z[0,4,5]  R752      -2.7418437600135803e-01
    z[0,4,5]  R753      3.8546571135520935e-01
    z[0,4,5]  R754      8.5960216820240021e-02
    z[0,4,5]  R755      -3.0100712180137634e-01
    z[0,4,5]  R756      3.7864178419113159e-01
    z[0,4,5]  R757      4.0323731303215027e-01
    z[0,4,5]  R758      4.7610646486282349e-01
    z[0,4,5]  R759      -4.0040472149848938e-01
    z[0,4,5]  R760      -3.4990664571523666e-02
    z[0,4,5]  R761      -6.4122414588928223e-01
    z[0,4,5]  R762      7.6918698847293854e-02
    z[0,4,5]  R763      3.3405745029449463e-01
    z[0,4,5]  R764      -2.5700443983078003e-01
    z[0,4,5]  R765      1.7790308222174644e-02
    z[0,4,5]  R766      1.7716838419437408e-01
    z[0,4,5]  R767      4.1874179244041443e-01
    z[0,4,5]  R768      -5.2343491464853287e-02
    z[0,4,5]  R769      1.1070173233747482e-01
    z[0,4,5]  R770      1.1411818861961365e-01
    z[0,4,5]  R771      4.5455317944288254e-02
    z[0,4,5]  R772      3.0921491980552673e-01
    z[0,4,5]  R773      -2.7463287115097046e-01
    z[0,4,5]  R774      2.4353665113449097e-01
    z[0,4,5]  R775      -3.5344031453132629e-01
    z[0,4,5]  R776      -8.5938408970832825e-02
    z[0,4,5]  R777      3.4604495763778687e-01
    z[0,4,5]  R778      -3.2464957237243652e-01
    z[0,4,5]  R779      -2.0818535983562469e-01
    z[0,4,5]  R780      -0.0650099441409111
    z[0,4,5]  R781      -1.1607811599969864e-01
    z[0,4,5]  R782      -2.1920476853847504e-01
    z[0,4,5]  R783      0.0813726931810379
    z[0,4,5]  R784      1.1889610439538956e-02
    z[0,4,5]  R785      -1.5509258210659027e-01
    z[0,4,5]  R786      3.3704373240470886e-01
    z[0,4,5]  R787      -2.8847804665565491e-01
    z[0,4,5]  R788      -5.0170928239822388e-01
    z[0,4,5]  R789      -2.4494219571352005e-02
    z[0,4,5]  R790      2.9188964515924454e-02
    z[0,4,5]  R791      5.8514147996902466e-01
    z[0,4,5]  R792      -2.4900746345520020e-01
    z[0,4,5]  R793      -4.3281638622283936e-01
    z[0,4,5]  R794      -1.5920111536979675e-01
    z[0,4,5]  R795      -3.0305919051170349e-01
    z[0,4,5]  R796      1.8946048617362976e-01
    z[0,4,5]  R797      9.4566307961940765e-02
    z[0,4,5]  R798      -2.8468701243400574e-01
    z[0,4,5]  R799      1.9625541567802429e-01
    z[0,4,5]  R800      2.4141949415206909e-01
    z[0,4,5]  R801      6.0804599523544312e-01
    z[0,4,5]  R802      4.3281927704811096e-02
    z[0,4,5]  R803      -3.9834147691726685e-01
    z[0,4,5]  R804      2.0585153996944427e-01
    z[0,4,5]  R805      -0.155070960521698
    z[0,4,5]  R806      2.3658762872219086e-01
    z[0,4,5]  R807      1.8496681749820709e-01
    z[0,4,5]  R808      -0.0867081880569458
    z[0,4,5]  R809      -2.5477465987205505e-01
    z[0,4,5]  R810      -1.9850549101829529e-01
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R709      -1
    z[0,4,6]  R710      1
    z[0,4,6]  R711      1.8866769969463348e-01
    z[0,4,6]  R712      -4.9333442002534866e-02
    z[0,4,6]  R713      0.395723819732666
    z[0,4,6]  R714      4.1688024997711182e-02
    z[0,4,6]  R715      -7.4217252433300018e-02
    z[0,4,6]  R716      -2.4170126020908356e-01
    z[0,4,6]  R717      -1.0254694148898125e-02
    z[0,4,6]  R718      0.088455431163311
    z[0,4,6]  R719      -5.0630939006805420e-01
    z[0,4,6]  R720      7.0999123156070709e-02
    z[0,4,6]  R721      -3.2858546823263168e-02
    z[0,4,6]  R722      8.8604830205440521e-02
    z[0,4,6]  R723      4.9064168706536293e-03
    z[0,4,6]  R724      2.8341269493103027e-01
    z[0,4,6]  R725      -1.8354374170303345e-01
    z[0,4,6]  R726      4.4690284132957458e-01
    z[0,4,6]  R727      4.0696394443511963e-01
    z[0,4,6]  R728      -4.0506433695554733e-02
    z[0,4,6]  R729      3.2720208168029785e-01
    z[0,4,6]  R730      1.0336861759424210e-01
    z[0,4,6]  R731      -1.9738449156284332e-01
    z[0,4,6]  R732      -3.4226831048727036e-02
    z[0,4,6]  R733      4.3831002712249756e-01
    z[0,4,6]  R734      -1.2033692747354507e-01
    z[0,4,6]  R735      -3.2512211799621582e-01
    z[0,4,6]  R736      -4.3581396341323853e-01
    z[0,4,6]  R737      2.4558633565902710e-01
    z[0,4,6]  R738      4.3737164139747620e-01
    z[0,4,6]  R739      -4.1613289713859558e-01
    z[0,4,6]  R740      -1.3238739967346191e-01
    z[0,4,6]  R741      -1.2371501326560974e-01
    z[0,4,6]  R742      4.7032165527343750e-01
    z[0,4,6]  R743      -2.1344347298145294e-01
    z[0,4,6]  R744      -1.2281096726655960e-01
    z[0,4,6]  R745      3.1134957075119019e-01
    z[0,4,6]  R746      4.4350346922874451e-01
    z[0,4,6]  R747      -1.6316774487495422e-01
    z[0,4,6]  R748      1.5427152812480927e-01
    z[0,4,6]  R749      2.6543816924095154e-01
    z[0,4,6]  R750      -1.0702729225158691e-01
    z[0,4,6]  R751      5.6285685300827026e-01
    z[0,4,6]  R752      2.3148207366466522e-01
    z[0,4,6]  R753      -1.2104640156030655e-01
    z[0,4,6]  R754      -0.295296311378479
    z[0,4,6]  R755      -1.9183368980884552e-01
    z[0,4,6]  R756      1.1599563807249069e-01
    z[0,4,6]  R757      0.0747029259800911
    z[0,4,6]  R758      -2.4605879187583923e-01
    z[0,4,6]  R759      2.8579438105225563e-02
    z[0,4,6]  R760      0.0792076513171196
    z[0,4,6]  R761      -2.3442563414573669e-01
    z[0,4,6]  R762      -2.8481602668762207e-01
    z[0,4,6]  R763      8.9047178626060486e-03
    z[0,4,6]  R764      3.2759314775466919e-01
    z[0,4,6]  R765      -1.4143096632324159e-04
    z[0,4,6]  R766      1.8598626554012299e-01
    z[0,4,6]  R767      -2.0224186778068542e-01
    z[0,4,6]  R768      -2.2372610867023468e-01
    z[0,4,6]  R769      4.0545615553855896e-01
    z[0,4,6]  R770      -9.1858208179473877e-02
    z[0,4,6]  R771      -0.210738867521286
    z[0,4,6]  R772      -3.1171094626188278e-02
    z[0,4,6]  R773      2.2929438948631287e-01
    z[0,4,6]  R774      5.0909918546676636e-01
    z[0,4,6]  R775      1.2369374930858612e-01
    z[0,4,6]  R776      -7.8863966464996338e-01
    z[0,4,6]  R777      -3.7255835533142090e-01
    z[0,4,6]  R778      -0.0744401067495346
    z[0,4,6]  R779      -1.5316693484783173e-01
    z[0,4,6]  R780      -3.9936131797730923e-03
    z[0,4,6]  R781      3.4250393509864807e-01
    z[0,4,6]  R782      6.0241949558258057e-01
    z[0,4,6]  R783      4.5875120162963867e-01
    z[0,4,6]  R784      3.3511921763420105e-01
    z[0,4,6]  R785      1.8250516057014465e-01
    z[0,4,6]  R786      -1.4824721217155457e-01
    z[0,4,6]  R787      -6.0037189722061157e-01
    z[0,4,6]  R788      -4.3797045946121216e-01
    z[0,4,6]  R789      -5.0236219167709351e-01
    z[0,4,6]  R790      -4.6849304437637329e-01
    z[0,4,6]  R791      -3.2818296551704407e-01
    z[0,4,6]  R792      1.7228440940380096e-01
    z[0,4,6]  R793      1.8132114410400391e-01
    z[0,4,6]  R794      -3.5852468013763428e-01
    z[0,4,6]  R795      -3.9278939366340637e-01
    z[0,4,6]  R796      -3.9323008060455322e-01
    z[0,4,6]  R797      -4.7162118554115295e-01
    z[0,4,6]  R798      -3.8046449422836304e-01
    z[0,4,6]  R799      -2.3921951651573181e-02
    z[0,4,6]  R800      -2.5964441895484924e-01
    z[0,4,6]  R801      -1.0932006686925888e-01
    z[0,4,6]  R802      -7.2604125738143921e-01
    z[0,4,6]  R803      -1.5151165425777435e-01
    z[0,4,6]  R804      -2.5049192830920219e-02
    z[0,4,6]  R805      -1.7614869773387909e-01
    z[0,4,6]  R806      -8.9096657931804657e-02
    z[0,4,6]  R807      -2.1664224565029144e-01
    z[0,4,6]  R808      -1.5606154501438141e-01
    z[0,4,6]  R809      8.1897906959056854e-02
    z[0,4,6]  R810      5.6511354446411133e-01
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R811      -1
    z[4,0,0]  R812      1
    z[4,0,0]  R825      5.5870389938354492e-01
    z[4,0,0]  R826      9.9818736314773560e-02
    z[4,0,0]  R827      -2.0530523732304573e-02
    z[4,0,0]  R828      8.2103852182626724e-03
    z[4,0,0]  R829      -1.4202977716922760e-01
    z[4,0,0]  R830      -4.8766386508941650e-01
    z[4,0,0]  R831      -1.5281499922275543e-01
    z[4,0,0]  R832      8.8300663232803345e-01
    z[4,0,0]  R833      7.5461864471435547e-01
    z[4,0,0]  R834      8.5505962371826172e-01
    z[4,0,0]  R835      -7.1266913414001465e-01
    z[4,0,0]  R836      -0.489612340927124
    z[4,0,0]  R837      -6.8424749374389648e-01
    z[4,0,0]  R838      -5.7680004835128784e-01
    z[4,0,0]  R839      -0.0508616641163826
    z[4,0,0]  R840      9.8354585468769073e-02
    z[4,0,0]  R841      -1.6463661193847656e-01
    z[4,0,0]  R842      -2.3018735647201538e-01
    z[4,0,0]  R843      -2.4711753427982330e-01
    z[4,0,0]  R844      -7.2288691997528076e-02
    z[4,0,0]  R845      -5.7580053806304932e-01
    z[4,0,0]  R846      2.5338813662528992e-01
    z[4,0,0]  R847      2.2624200209975243e-02
    z[4,0,0]  R848      4.2387198656797409e-02
    z[4,0,0]  R849      4.6951755881309509e-02
    z[4,0,0]  R850      1.1479977518320084e-01
    z[4,0,0]  R851      -7.6783820986747742e-03
    z[4,0,0]  R852      -4.7213941812515259e-02
    z[4,0,0]  R853      2.0390398800373077e-01
    z[4,0,0]  R854      4.9588415771722794e-02
    z[4,0,0]  R855      -0.370315819978714
    z[4,0,0]  R856      -4.2799603939056396e-01
    z[4,0,0]  R857      2.4122430384159088e-01
    z[4,0,0]  R858      0.111538365483284
    z[4,0,0]  R859      2.3198957741260529e-01
    z[4,0,0]  R860      2.9266181588172913e-01
    z[4,0,0]  R861      -2.6075911521911621e-01
    z[4,0,0]  R862      0.12830850481987
    z[4,0,0]  R863      2.7927669882774353e-01
    z[4,0,0]  R864      2.9127854108810425e-01
    z[4,0,0]  R865      -2.7911195158958435e-01
    z[4,0,0]  R866      -2.5956231355667114e-01
    z[4,0,0]  R867      -0.200189471244812
    z[4,0,0]  R868      9.5063948631286621e-01
    z[4,0,0]  R869      5.5172234773635864e-01
    z[4,0,0]  R870      8.2528567314147949e-01
    z[4,0,0]  R871      8.0844157934188843e-01
    z[4,0,0]  R872      8.0433422327041626e-01
    z[4,0,0]  R873      -2.6695212721824646e-01
    z[4,0,0]  R874      4.4909101724624634e-01
    z[4,0,0]  R875      -6.7703330516815186e-01
    z[4,0,0]  R876      -8.4879899024963379e-01
    z[4,0,0]  R877      -7.9707098007202148e-01
    z[4,0,0]  R878      -6.5170717239379883e-01
    z[4,0,0]  R879      -5.3997147083282471e-01
    z[4,0,0]  R880      -5.1643681526184082e-01
    z[4,0,0]  R881      -4.9135014414787292e-01
    z[4,0,0]  R882      -7.3041713237762451e-01
    z[4,0,0]  R883      -4.2066127061843872e-01
    z[4,0,0]  R884      -0.335271954536438
    z[4,0,0]  R885      -7.8593236207962036e-01
    z[4,0,0]  R886      -4.8112070560455322e-01
    z[4,0,0]  R887      -8.0663490295410156e-01
    z[4,0,0]  R888      -4.5488181710243225e-01
    z[4,0,0]  R889      -3.4604361653327942e-01
    z[4,0,0]  R890      -0.739958643913269
    z[4,0,0]  R891      -5.4418420791625977e-01
    z[4,0,0]  R892      -3.8419404625892639e-01
    z[4,0,0]  R893      -3.8750213384628296e-01
    z[4,0,0]  R894      -1.6495670378208160e-01
    z[4,0,0]  R895      -6.4012104272842407e-01
    z[4,0,0]  R896      -4.5631998777389526e-01
    z[4,0,0]  R897      -6.9034153223037720e-01
    z[4,0,0]  R898      -4.7739055752754211e-01
    z[4,0,0]  R899      -3.3747208118438721e-01
    z[4,0,0]  R900      0.616935133934021
    z[4,0,0]  R901      -2.9487824440002441e-01
    z[4,0,0]  R902      -3.2894019037485123e-02
    z[4,0,0]  R903      2.6451559737324715e-02
    z[4,0,0]  R904      -5.9227943420410156e-02
    z[4,0,0]  R905      -3.2220444083213806e-01
    z[4,0,0]  R906      -4.7876590490341187e-01
    z[4,0,0]  R907      -2.2320681810379028e-01
    z[4,0,0]  R908      -3.1698886305093765e-02
    z[4,0,0]  R909      4.0914884209632874e-01
    z[4,0,0]  R910      2.0863594114780426e-01
    z[4,0,0]  R911      4.6707686781883240e-01
    z[4,0,0]  R912      5.0943013280630112e-02
    z[4,0,0]  R913      3.4773871302604675e-01
    z[4,0,0]  R914      8.9614562690258026e-02
    z[4,0,0]  R915      -0.302606999874115
    z[4,0,0]  R916      -8.2195393741130829e-02
    z[4,0,0]  R917      -1.9792994856834412e-01
    z[4,0,0]  R918      -2.2379927337169647e-01
    z[4,0,0]  R919      0.0955568253993988
    z[4,0,0]  R920      5.4114109277725220e-01
    z[4,0,0]  R921      5.3917460143566132e-02
    z[4,0,0]  R922      3.4159538149833679e-01
    z[4,0,0]  R923      4.7162267565727234e-01
    z[4,0,0]  R924      2.4069221317768097e-01
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R813      -1
    z[4,0,1]  R814      1
    z[4,0,1]  R825      5.6021219491958618e-01
    z[4,0,1]  R826      7.8178036212921143e-01
    z[4,0,1]  R827      7.5345677137374878e-01
    z[4,0,1]  R828      3.8890364766120911e-01
    z[4,0,1]  R829      4.9546009302139282e-01
    z[4,0,1]  R830      1.8506301939487457e-01
    z[4,0,1]  R831      1.7123848199844360e-01
    z[4,0,1]  R832      3.8786649703979492e-02
    z[4,0,1]  R833      -2.4267809092998505e-01
    z[4,0,1]  R834      -2.5800105929374695e-01
    z[4,0,1]  R835      -1.9565564393997192e-01
    z[4,0,1]  R836      -1.5061859786510468e-01
    z[4,0,1]  R837      -3.5446065664291382e-01
    z[4,0,1]  R838      -3.8342043757438660e-01
    z[4,0,1]  R839      -8.9201897382736206e-01
    z[4,0,1]  R840      -7.1640813350677490e-01
    z[4,0,1]  R841      -7.1327060461044312e-01
    z[4,0,1]  R842      -4.8758310079574585e-01
    z[4,0,1]  R843      -8.1594669818878174e-01
    z[4,0,1]  R844      -6.2656390666961670e-01
    z[4,0,1]  R845      1.0611204802989960e-01
    z[4,0,1]  R846      -4.4901618361473083e-01
    z[4,0,1]  R847      -7.4879795312881470e-01
    z[4,0,1]  R848      -8.4246599674224854e-01
    z[4,0,1]  R849      -7.3599445819854736e-01
    z[4,0,1]  R850      -7.6748752593994141e-01
    z[4,0,1]  R851      -8.7122011184692383e-01
    z[4,0,1]  R852      -0.759326159954071
    z[4,0,1]  R853      -8.7563234567642212e-01
    z[4,0,1]  R854      -9.0224641561508179e-01
    z[4,0,1]  R855      4.2711898684501648e-01
    z[4,0,1]  R856      1.1950732767581940e-01
    z[4,0,1]  R857      -7.9304671287536621e-01
    z[4,0,1]  R858      -6.9904738664627075e-01
    z[4,0,1]  R859      -8.7748444080352783e-01
    z[4,0,1]  R860      -8.8935530185699463e-01
    z[4,0,1]  R861      -7.5103670358657837e-01
    z[4,0,1]  R862      -8.4581160545349121e-01
    z[4,0,1]  R863      -1.1033361405134201e-01
    z[4,0,1]  R864      -6.0323875397443771e-02
    z[4,0,1]  R865      5.7454162836074829e-01
    z[4,0,1]  R866      1.6744308173656464e-01
    z[4,0,1]  R867      3.1051808595657349e-01
    z[4,0,1]  R868      1.8348847329616547e-01
    z[4,0,1]  R869      7.3893499374389648e-01
    z[4,0,1]  R870      1.7857621610164642e-01
    z[4,0,1]  R871      5.3061944246292114e-01
    z[4,0,1]  R872      4.6047952771186829e-01
    z[4,0,1]  R873      4.5100402832031250e-01
    z[4,0,1]  R874      0.596885621547699
    z[4,0,1]  R875      -3.4250352531671524e-02
    z[4,0,1]  R876      -2.0875754952430725e-01
    z[4,0,1]  R877      2.0808492600917816e-01
    z[4,0,1]  R878      -4.1754089295864105e-02
    z[4,0,1]  R879      5.3702068328857422e-01
    z[4,0,1]  R880      -3.1882904469966888e-02
    z[4,0,1]  R881      -4.5007994771003723e-01
    z[4,0,1]  R882      -5.1013922691345215e-01
    z[4,0,1]  R883      -2.0662444829940796e-01
    z[4,0,1]  R884      -6.6670411825180054e-01
    z[4,0,1]  R885      4.5394363999366760e-01
    z[4,0,1]  R886      7.4497830867767334e-01
    z[4,0,1]  R887      2.1404880285263062e-01
    z[4,0,1]  R888      7.1047663688659668e-01
    z[4,0,1]  R889      6.4928478002548218e-01
    z[4,0,1]  R890      3.7441188097000122e-01
    z[4,0,1]  R891      1.0908488184213638e-02
    z[4,0,1]  R892      4.2736539244651794e-01
    z[4,0,1]  R893      4.4189310073852539e-01
    z[4,0,1]  R894      2.7838796377182007e-01
    z[4,0,1]  R895      8.7187774479389191e-02
    z[4,0,1]  R896      3.7865081429481506e-01
    z[4,0,1]  R897      -4.3377488851547241e-01
    z[4,0,1]  R898      -6.8070453405380249e-01
    z[4,0,1]  R899      -8.6769664287567139e-01
    z[4,0,1]  R900      2.1589897572994232e-01
    z[4,0,1]  R901      -5.0343447923660278e-01
    z[4,0,1]  R902      -7.4226856231689453e-01
    z[4,0,1]  R903      -9.0129858255386353e-01
    z[4,0,1]  R904      -5.6143432855606079e-01
    z[4,0,1]  R905      6.3973242044448853e-01
    z[4,0,1]  R906      2.6570373773574829e-01
    z[4,0,1]  R907      -7.6507246494293213e-01
    z[4,0,1]  R908      -5.2671676874160767e-01
    z[4,0,1]  R909      -5.2842015027999878e-01
    z[4,0,1]  R910      -4.0489968657493591e-01
    z[4,0,1]  R911      -4.1363832354545593e-01
    z[4,0,1]  R912      -2.0617979764938354e-01
    z[4,0,1]  R913      -5.0428098440170288e-01
    z[4,0,1]  R914      -0.28351891040802
    z[4,0,1]  R915      5.9813719987869263e-01
    z[4,0,1]  R916      -5.6944328546524048e-01
    z[4,0,1]  R917      -7.9107505083084106e-01
    z[4,0,1]  R918      -8.3547854423522949e-01
    z[4,0,1]  R919      -6.2728846073150635e-01
    z[4,0,1]  R920      -1.5642635524272919e-01
    z[4,0,1]  R921      -0.408250629901886
    z[4,0,1]  R922      1.0886962711811066e-01
    z[4,0,1]  R923      -6.0041254758834839e-01
    z[4,0,1]  R924      1.5060398727655411e-03
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R815      -1
    z[4,0,2]  R816      1
    z[4,0,2]  R825      -3.8512402772903442e-01
    z[4,0,2]  R826      5.6504216045141220e-02
    z[4,0,2]  R827      -3.9413750171661377e-01
    z[4,0,2]  R828      1.1042091995477676e-01
    z[4,0,2]  R829      1.2807871401309967e-01
    z[4,0,2]  R830      1.2600994668900967e-02
    z[4,0,2]  R831      1.0695854574441910e-01
    z[4,0,2]  R832      3.7434976547956467e-02
    z[4,0,2]  R833      1.3555747270584106e-01
    z[4,0,2]  R834      -0.0625605583190918
    z[4,0,2]  R835      0.49066162109375
    z[4,0,2]  R836      3.7475490570068359e-01
    z[4,0,2]  R837      -1.8631502985954285e-01
    z[4,0,2]  R838      -5.3598236292600632e-02
    z[4,0,2]  R839      -9.7490988671779633e-02
    z[4,0,2]  R840      -5.3910166025161743e-01
    z[4,0,2]  R841      -1.0701456665992737e-01
    z[4,0,2]  R842      -3.9065742492675781e-01
    z[4,0,2]  R843      -7.0837214589118958e-02
    z[4,0,2]  R844      -4.8441314697265625e-01
    z[4,0,2]  R845      -1.2420298904180527e-01
    z[4,0,2]  R846      -3.6703076958656311e-01
    z[4,0,2]  R847      -8.0870762467384338e-02
    z[4,0,2]  R848      -1.6054618358612061e-01
    z[4,0,2]  R849      -1.4383193850517273e-01
    z[4,0,2]  R850      -2.4992391467094421e-01
    z[4,0,2]  R851      -8.3724528551101685e-02
    z[4,0,2]  R852      3.0607774853706360e-01
    z[4,0,2]  R853      3.2696709036827087e-01
    z[4,0,2]  R854      2.2576428949832916e-01
    z[4,0,2]  R855      -3.0090728402137756e-01
    z[4,0,2]  R856      -2.3227781057357788e-01
    z[4,0,2]  R857      -1.1948853731155396e-01
    z[4,0,2]  R858      -1.9092109799385071e-01
    z[4,0,2]  R859      3.3038997650146484e-01
    z[4,0,2]  R860      1.7247335612773895e-01
    z[4,0,2]  R861      -6.6403280943632126e-03
    z[4,0,2]  R862      3.6510783433914185e-01
    z[4,0,2]  R863      -7.7136582136154175e-01
    z[4,0,2]  R864      -0.623135507106781
    z[4,0,2]  R865      1.5083377063274384e-01
    z[4,0,2]  R866      2.3986802995204926e-01
    z[4,0,2]  R867      -1.8829308450222015e-01
    z[4,0,2]  R868      2.4266245961189270e-01
    z[4,0,2]  R869      -3.3070594072341919e-01
    z[4,0,2]  R870      3.0206015706062317e-01
    z[4,0,2]  R871      -1.5245966613292694e-01
    z[4,0,2]  R872      1.9436698406934738e-02
    z[4,0,2]  R873      -3.4611273556947708e-02
    z[4,0,2]  R874      -5.8791655302047729e-01
    z[4,0,2]  R875      -6.1598002910614014e-01
    z[4,0,2]  R876      -3.5712572932243347e-01
    z[4,0,2]  R877      -2.3911079764366150e-01
    z[4,0,2]  R878      -3.2284760475158691e-01
    z[4,0,2]  R879      2.2259363532066345e-01
    z[4,0,2]  R880      -5.8785039186477661e-01
    z[4,0,2]  R881      -5.2049297094345093e-01
    z[4,0,2]  R882      -8.4991287440061569e-03
    z[4,0,2]  R883      -5.2151817083358765e-01
    z[4,0,2]  R884      5.2224820852279663e-01
    z[4,0,2]  R885      -4.9242395907640457e-02
    z[4,0,2]  R886      1.6663928329944611e-01
    z[4,0,2]  R887      2.8458821773529053e-01
    z[4,0,2]  R888      -0.265234112739563
    z[4,0,2]  R889      -2.2192781791090965e-02
    z[4,0,2]  R890      6.0554448515176773e-02
    z[4,0,2]  R891      2.0031755790114403e-02
    z[4,0,2]  R892      3.7380585074424744e-01
    z[4,0,2]  R893      5.7075881958007812e-01
    z[4,0,2]  R894      1.7242784798145294e-01
    z[4,0,2]  R895      1.9863437116146088e-01
    z[4,0,2]  R896      -3.7209963798522949e-01
    z[4,0,2]  R897      1.9737100601196289e-01
    z[4,0,2]  R898      4.5568180084228516e-01
    z[4,0,2]  R899      1.1098874360322952e-01
    z[4,0,2]  R900      -2.9603496193885803e-01
    z[4,0,2]  R901      5.4920607805252075e-01
    z[4,0,2]  R902      3.7952467799186707e-01
    z[4,0,2]  R903      1.7176325619220734e-01
    z[4,0,2]  R904      5.3085041046142578e-01
    z[4,0,2]  R905      -2.8079429268836975e-01
    z[4,0,2]  R906      -4.2123457789421082e-01
    z[4,0,2]  R907      0.408405065536499
    z[4,0,2]  R908      7.0510065555572510e-01
    z[4,0,2]  R909      9.5214679837226868e-02
    z[4,0,2]  R910      1.9265627861022949e-01
    z[4,0,2]  R911      1.5138559043407440e-01
    z[4,0,2]  R912      4.2132866382598877e-01
    z[4,0,2]  R913      -1.5476787090301514e-01
    z[4,0,2]  R914      2.9042625427246094e-01
    z[4,0,2]  R915      -1.1957526206970215e-01
    z[4,0,2]  R916      7.2208935022354126e-01
    z[4,0,2]  R917      4.5464840531349182e-01
    z[4,0,2]  R918      2.3715527355670929e-01
    z[4,0,2]  R919      7.1603232622146606e-01
    z[4,0,2]  R920      4.1160178184509277e-01
    z[4,0,2]  R921      0.485909104347229
    z[4,0,2]  R922      7.6738965511322021e-01
    z[4,0,2]  R923      -2.7881422638893127e-01
    z[4,0,2]  R924      -1.6056613624095917e-01
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R817      -1
    z[4,0,3]  R818      1
    z[4,0,3]  R825      -3.8021820783615112e-01
    z[4,0,3]  R826      -4.8384204506874084e-01
    z[4,0,3]  R827      -3.6220863461494446e-01
    z[4,0,3]  R828      -4.1754421591758728e-01
    z[4,0,3]  R829      -2.9438000917434692e-01
    z[4,0,3]  R830      -3.1255516409873962e-01
    z[4,0,3]  R831      6.8910324573516846e-01
    z[4,0,3]  R832      -3.0642330646514893e-01
    z[4,0,3]  R833      -0.398311972618103
    z[4,0,3]  R834      -2.8055045008659363e-01
    z[4,0,3]  R835      2.8187143802642822e-01
    z[4,0,3]  R836      4.5860681682825089e-02
    z[4,0,3]  R837      -2.4828857183456421e-01
    z[4,0,3]  R838      -1.3207701034843922e-02
    z[4,0,3]  R839      -8.9316688477993011e-02
    z[4,0,3]  R840      -2.1141889691352844e-01
    z[4,0,3]  R841      9.3292370438575745e-02
    z[4,0,3]  R842      -3.2621735334396362e-01
    z[4,0,3]  R843      -1.0185866057872772e-01
    z[4,0,3]  R844      -3.8146099448204041e-01
    z[4,0,3]  R845      3.0751854181289673e-01
    z[4,0,3]  R846      -6.9934684038162231e-01
    z[4,0,3]  R847      -3.2809826731681824e-01
    z[4,0,3]  R848      -3.1848379969596863e-01
    z[4,0,3]  R849      -3.9895847439765930e-01
    z[4,0,3]  R850      -3.7319111824035645e-01
    z[4,0,3]  R851      3.6862384527921677e-02
    z[4,0,3]  R852      8.2869239151477814e-02
    z[4,0,3]  R853      2.8244696557521820e-02
    z[4,0,3]  R854      -5.6988544762134552e-02
    z[4,0,3]  R855      4.1068476438522339e-01
    z[4,0,3]  R856      3.7810587882995605e-01
    z[4,0,3]  R857      -3.4058916568756104e-01
    z[4,0,3]  R858      -5.4312676191329956e-01
    z[4,0,3]  R859      -9.5807880163192749e-02
    z[4,0,3]  R860      2.8587602078914642e-02
    z[4,0,3]  R861      -3.5784307122230530e-01
    z[4,0,3]  R862      2.3451048135757446e-01
    z[4,0,3]  R863      4.9130004644393921e-01
    z[4,0,3]  R864      4.0348741412162781e-01
    z[4,0,3]  R865      -4.8630633950233459e-01
    z[4,0,3]  R866      -9.0782207250595093e-01
    z[4,0,3]  R867      -7.7078616619110107e-01
    z[4,0,3]  R868      2.0572718232870102e-02
    z[4,0,3]  R869      -3.4895248245447874e-03
    z[4,0,3]  R870      -1.3784939050674438e-01
    z[4,0,3]  R871      -1.7129622399806976e-01
    z[4,0,3]  R872      -1.2891253829002380e-01
    z[4,0,3]  R873      -5.7065492868423462e-01
    z[4,0,3]  R874      2.2236967086791992e-01
    z[4,0,3]  R875      1.8083423376083374e-01
    z[4,0,3]  R876      -6.9698132574558258e-02
    z[4,0,3]  R877      1.4075244963169098e-01
    z[4,0,3]  R878      4.2891070246696472e-01
    z[4,0,3]  R879      0.380641371011734
    z[4,0,3]  R880      0.0773368775844574
    z[4,0,3]  R881      3.2796174287796021e-01
    z[4,0,3]  R882      -3.2630673050880432e-01
    z[4,0,3]  R883      2.8481978178024292e-01
    z[4,0,3]  R884      2.4042797088623047e-01
    z[4,0,3]  R885      -1.6804021596908569e-01
    z[4,0,3]  R886      -2.1764262020587921e-01
    z[4,0,3]  R887      -1.5559849143028259e-01
    z[4,0,3]  R888      -2.0663103461265564e-01
    z[4,0,3]  R889      -4.0528619289398193e-01
    z[4,0,3]  R890      -3.3417305350303650e-01
    z[4,0,3]  R891      -6.7320454120635986e-01
    z[4,0,3]  R892      -2.5686460733413696e-01
    z[4,0,3]  R893      -2.0680793095380068e-03
    z[4,0,3]  R894      -4.6091657876968384e-01
    z[4,0,3]  R895      -6.1763554811477661e-01
    z[4,0,3]  R896      -2.4363413453102112e-01
    z[4,0,3]  R897      4.7199773788452148e-01
    z[4,0,3]  R898      -1.1488460004329681e-01
    z[4,0,3]  R899      9.7651846706867218e-02
    z[4,0,3]  R900      4.2816668748855591e-01
    z[4,0,3]  R901      3.2782697677612305e-01
    z[4,0,3]  R902      -4.7279921174049377e-01
    z[4,0,3]  R903      -5.6368038058280945e-02
    z[4,0,3]  R904      -5.9518980979919434e-01
    z[4,0,3]  R905      -1.8755196034908295e-01
    z[4,0,3]  R906      -2.4840892851352692e-01
    z[4,0,3]  R907      -2.1829817444086075e-02
    z[4,0,3]  R908      2.9045999050140381e-01
    z[4,0,3]  R909      -6.3881975412368774e-01
    z[4,0,3]  R910      7.2736620903015137e-01
    z[4,0,3]  R911      0.645383358001709
    z[4,0,3]  R912      6.5305101871490479e-01
    z[4,0,3]  R913      -4.8276394605636597e-01
    z[4,0,3]  R914      8.8347822427749634e-01
    z[4,0,3]  R915      5.1070757210254669e-02
    z[4,0,3]  R916      1.2201625853776932e-01
    z[4,0,3]  R917      1.0796375572681427e-01
    z[4,0,3]  R918      -4.6345632523298264e-02
    z[4,0,3]  R919      -2.7514001727104187e-01
    z[4,0,3]  R920      -4.4121104478836060e-01
    z[4,0,3]  R921      6.0426419973373413e-01
    z[4,0,3]  R922      -0.250192791223526
    z[4,0,3]  R923      -4.0110346674919128e-01
    z[4,0,3]  R924      8.6320447921752930e-01
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R819      -1
    z[4,0,4]  R820      1
    z[4,0,4]  R825      -1.8614172935485840e-01
    z[4,0,4]  R826      2.1207168698310852e-01
    z[4,0,4]  R827      1.3169211149215698e-01
    z[4,0,4]  R828      -5.8622401952743530e-01
    z[4,0,4]  R829      -7.0075875520706177e-01
    z[4,0,4]  R830      2.7352645993232727e-02
    z[4,0,4]  R831      4.4997197389602661e-01
    z[4,0,4]  R832      -1.1206955462694168e-01
    z[4,0,4]  R833      -3.5753118991851807e-01
    z[4,0,4]  R834      3.3977007865905762e-01
    z[4,0,4]  R835      5.3274929523468018e-02
    z[4,0,4]  R836      4.2905649542808533e-01
    z[4,0,4]  R837      3.0451324582099915e-01
    z[4,0,4]  R838      6.3623654842376709e-01
    z[4,0,4]  R839      -3.5619032382965088e-01
    z[4,0,4]  R840      -7.8622095286846161e-02
    z[4,0,4]  R841      -1.7840167507529259e-02
    z[4,0,4]  R842      -8.1945598125457764e-02
    z[4,0,4]  R843      -6.9304317235946655e-02
    z[4,0,4]  R844      -0.0410560667514801
    z[4,0,4]  R845      -3.1161725521087646e-01
    z[4,0,4]  R846      1.3672819733619690e-01
    z[4,0,4]  R847      -3.2310044765472412e-01
    z[4,0,4]  R848      8.5804097354412079e-02
    z[4,0,4]  R849      -1.7356221377849579e-01
    z[4,0,4]  R850      -7.4332311749458313e-02
    z[4,0,4]  R851      -3.4329265356063843e-02
    z[4,0,4]  R852      -3.0796703696250916e-01
    z[4,0,4]  R853      2.1189035475254059e-01
    z[4,0,4]  R854      5.9805028140544891e-02
    z[4,0,4]  R855      1.9889065623283386e-01
    z[4,0,4]  R856      -2.7678728103637695e-01
    z[4,0,4]  R857      3.1266503036022186e-02
    z[4,0,4]  R858      -3.5277768969535828e-01
    z[4,0,4]  R859      -5.2817653864622116e-02
    z[4,0,4]  R860      -1.7005857825279236e-01
    z[4,0,4]  R861      -3.9837956428527832e-01
    z[4,0,4]  R862      -2.1901425719261169e-01
    z[4,0,4]  R863      -4.2809482663869858e-02
    z[4,0,4]  R864      -4.0744204074144363e-02
    z[4,0,4]  R865      2.0659589767456055e-01
    z[4,0,4]  R866      1.2071436643600464e-01
    z[4,0,4]  R867      -2.7697184681892395e-01
    z[4,0,4]  R868      -2.2041415795683861e-02
    z[4,0,4]  R869      -1.4359714090824127e-01
    z[4,0,4]  R870      -1.9014884531497955e-01
    z[4,0,4]  R871      -1.0998731106519699e-01
    z[4,0,4]  R872      3.2825049757957458e-01
    z[4,0,4]  R873      -8.3933107554912567e-02
    z[4,0,4]  R874      1.6483344137668610e-02
    z[4,0,4]  R875      -2.2064687311649323e-01
    z[4,0,4]  R876      -2.0545309782028198e-01
    z[4,0,4]  R877      3.3019462227821350e-01
    z[4,0,4]  R878      2.6482102274894714e-01
    z[4,0,4]  R879      -3.3414953947067261e-01
    z[4,0,4]  R880      4.2259556055068970e-01
    z[4,0,4]  R881      -9.9161945283412933e-02
    z[4,0,4]  R882      -4.5455410145223141e-03
    z[4,0,4]  R883      3.9835435152053833e-01
    z[4,0,4]  R884      3.1894508004188538e-01
    z[4,0,4]  R885      -8.5877306759357452e-02
    z[4,0,4]  R886      -2.6973801851272583e-01
    z[4,0,4]  R887      -2.0720811560750008e-02
    z[4,0,4]  R888      4.0071615576744080e-01
    z[4,0,4]  R889      4.1808298230171204e-01
    z[4,0,4]  R890      5.7537477463483810e-02
    z[4,0,4]  R891      3.4836444258689880e-01
    z[4,0,4]  R892      3.7266877293586731e-01
    z[4,0,4]  R893      0.363534539937973
    z[4,0,4]  R894      -7.2346520423889160e-01
    z[4,0,4]  R895      2.0305566489696503e-01
    z[4,0,4]  R896      2.0270688831806183e-01
    z[4,0,4]  R897      -1.0040581226348877e-01
    z[4,0,4]  R898      -2.6142343878746033e-01
    z[4,0,4]  R899      -1.0947328805923462e-01
    z[4,0,4]  R900      2.3419323563575745e-01
    z[4,0,4]  R901      -3.2322630286216736e-01
    z[4,0,4]  R902      -2.1963614225387573e-01
    z[4,0,4]  R903      -2.3658205568790436e-01
    z[4,0,4]  R904      -1.5085247159004211e-01
    z[4,0,4]  R905      -6.5335296094417572e-02
    z[4,0,4]  R906      -5.7643568515777588e-01
    z[4,0,4]  R907      -1.8529847264289856e-01
    z[4,0,4]  R908      -2.1317061781883240e-01
    z[4,0,4]  R909      9.3847788870334625e-02
    z[4,0,4]  R910      2.6367539167404175e-01
    z[4,0,4]  R911      -5.5896721780300140e-02
    z[4,0,4]  R912      2.5234678387641907e-01
    z[4,0,4]  R913      4.5455864071846008e-01
    z[4,0,4]  R914      1.9800759851932526e-01
    z[4,0,4]  R915      -2.6005905866622925e-01
    z[4,0,4]  R916      -2.1363671123981476e-01
    z[4,0,4]  R917      7.0633560419082642e-02
    z[4,0,4]  R918      -1.4188164472579956e-01
    z[4,0,4]  R919      9.3043945729732513e-02
    z[4,0,4]  R920      5.0262737274169922e-01
    z[4,0,4]  R921      1.1373239010572433e-01
    z[4,0,4]  R922      4.0888068079948425e-01
    z[4,0,4]  R923      4.2495880275964737e-02
    z[4,0,4]  R924      -3.8691172003746033e-01
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R821      -1
    z[4,0,5]  R822      1
    z[4,0,5]  R825      4.5455317944288254e-02
    z[4,0,5]  R826      3.0921491980552673e-01
    z[4,0,5]  R827      -2.7463287115097046e-01
    z[4,0,5]  R828      2.4353665113449097e-01
    z[4,0,5]  R829      -3.5344031453132629e-01
    z[4,0,5]  R830      -8.5938408970832825e-02
    z[4,0,5]  R831      3.4604495763778687e-01
    z[4,0,5]  R832      -3.2464957237243652e-01
    z[4,0,5]  R833      -2.0818535983562469e-01
    z[4,0,5]  R834      -0.0650099441409111
    z[4,0,5]  R835      -1.1607811599969864e-01
    z[4,0,5]  R836      -2.1920476853847504e-01
    z[4,0,5]  R837      0.0813726931810379
    z[4,0,5]  R838      1.1889610439538956e-02
    z[4,0,5]  R839      -1.5509258210659027e-01
    z[4,0,5]  R840      3.3704373240470886e-01
    z[4,0,5]  R841      -2.8847804665565491e-01
    z[4,0,5]  R842      -5.0170928239822388e-01
    z[4,0,5]  R843      -2.4494219571352005e-02
    z[4,0,5]  R844      2.9188964515924454e-02
    z[4,0,5]  R845      5.8514147996902466e-01
    z[4,0,5]  R846      -2.4900746345520020e-01
    z[4,0,5]  R847      -4.3281638622283936e-01
    z[4,0,5]  R848      -1.5920111536979675e-01
    z[4,0,5]  R849      -3.0305919051170349e-01
    z[4,0,5]  R850      1.8946048617362976e-01
    z[4,0,5]  R851      9.4566307961940765e-02
    z[4,0,5]  R852      -2.8468701243400574e-01
    z[4,0,5]  R853      1.9625541567802429e-01
    z[4,0,5]  R854      2.4141949415206909e-01
    z[4,0,5]  R855      6.0804599523544312e-01
    z[4,0,5]  R856      4.3281927704811096e-02
    z[4,0,5]  R857      -3.9834147691726685e-01
    z[4,0,5]  R858      2.0585153996944427e-01
    z[4,0,5]  R859      -0.155070960521698
    z[4,0,5]  R860      2.3658762872219086e-01
    z[4,0,5]  R861      1.8496681749820709e-01
    z[4,0,5]  R862      -0.0867081880569458
    z[4,0,5]  R863      -2.5477465987205505e-01
    z[4,0,5]  R864      -1.9850549101829529e-01
    z[4,0,5]  R865      -5.0445652008056641e-01
    z[4,0,5]  R866      -7.6856710016727448e-02
    z[4,0,5]  R867      2.5028528645634651e-02
    z[4,0,5]  R868      -3.2930124551057816e-02
    z[4,0,5]  R869      -1.1862007528543472e-01
    z[4,0,5]  R870      2.8669700026512146e-01
    z[4,0,5]  R871      8.7456069886684418e-03
    z[4,0,5]  R872      9.1848298907279968e-02
    z[4,0,5]  R873      3.6754995584487915e-01
    z[4,0,5]  R874      2.0405404269695282e-01
    z[4,0,5]  R875      0.280277818441391
    z[4,0,5]  R876      -2.3130537569522858e-01
    z[4,0,5]  R877      3.6788681149482727e-01
    z[4,0,5]  R878      -3.6726880073547363e-01
    z[4,0,5]  R879      2.8330111503601074e-01
    z[4,0,5]  R880      -4.9175322055816650e-02
    z[4,0,5]  R881      -4.5591026544570923e-02
    z[4,0,5]  R882      3.1311208009719849e-01
    z[4,0,5]  R883      4.0186995267868042e-01
    z[4,0,5]  R884      -1.1770709417760372e-02
    z[4,0,5]  R885      3.1503564119338989e-01
    z[4,0,5]  R886      2.5389587879180908e-01
    z[4,0,5]  R887      7.6005801558494568e-02
    z[4,0,5]  R888      -1.4338185079395771e-02
    z[4,0,5]  R889      1.1591343581676483e-01
    z[4,0,5]  R890      -6.0779560357332230e-02
    z[4,0,5]  R891      2.6166474819183350e-01
    z[4,0,5]  R892      3.6587905883789062e-01
    z[4,0,5]  R893      1.5322747826576233e-01
    z[4,0,5]  R894      -3.3494135737419128e-01
    z[4,0,5]  R895      -3.2431003451347351e-01
    z[4,0,5]  R896      -4.3392094969749451e-01
    z[4,0,5]  R897      1.3375861942768097e-01
    z[4,0,5]  R898      -6.6862389445304871e-02
    z[4,0,5]  R899      -4.9372907727956772e-02
    z[4,0,5]  R900      -2.2421722114086151e-01
    z[4,0,5]  R901      -3.4554848074913025e-01
    z[4,0,5]  R902      -9.1310754418373108e-02
    z[4,0,5]  R903      1.6689199209213257e-01
    z[4,0,5]  R904      1.0497282445430756e-01
    z[4,0,5]  R905      -2.2765980660915375e-01
    z[4,0,5]  R906      -2.7418437600135803e-01
    z[4,0,5]  R907      3.8546571135520935e-01
    z[4,0,5]  R908      8.5960216820240021e-02
    z[4,0,5]  R909      -3.0100712180137634e-01
    z[4,0,5]  R910      3.7864178419113159e-01
    z[4,0,5]  R911      4.0323731303215027e-01
    z[4,0,5]  R912      4.7610646486282349e-01
    z[4,0,5]  R913      -4.0040472149848938e-01
    z[4,0,5]  R914      -3.4990664571523666e-02
    z[4,0,5]  R915      -6.4122414588928223e-01
    z[4,0,5]  R916      7.6918698847293854e-02
    z[4,0,5]  R917      3.3405745029449463e-01
    z[4,0,5]  R918      -2.5700443983078003e-01
    z[4,0,5]  R919      1.7790308222174644e-02
    z[4,0,5]  R920      1.7716838419437408e-01
    z[4,0,5]  R921      4.1874179244041443e-01
    z[4,0,5]  R922      -5.2343491464853287e-02
    z[4,0,5]  R923      1.1070173233747482e-01
    z[4,0,5]  R924      1.1411818861961365e-01
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R823      -1
    z[4,0,6]  R824      1
    z[4,0,6]  R825      -0.210738867521286
    z[4,0,6]  R826      -3.1171094626188278e-02
    z[4,0,6]  R827      2.2929438948631287e-01
    z[4,0,6]  R828      5.0909918546676636e-01
    z[4,0,6]  R829      1.2369374930858612e-01
    z[4,0,6]  R830      -7.8863966464996338e-01
    z[4,0,6]  R831      -3.7255835533142090e-01
    z[4,0,6]  R832      -0.0744401067495346
    z[4,0,6]  R833      -1.5316693484783173e-01
    z[4,0,6]  R834      -3.9936131797730923e-03
    z[4,0,6]  R835      3.4250393509864807e-01
    z[4,0,6]  R836      6.0241949558258057e-01
    z[4,0,6]  R837      4.5875120162963867e-01
    z[4,0,6]  R838      3.3511921763420105e-01
    z[4,0,6]  R839      1.8250516057014465e-01
    z[4,0,6]  R840      -1.4824721217155457e-01
    z[4,0,6]  R841      -6.0037189722061157e-01
    z[4,0,6]  R842      -4.3797045946121216e-01
    z[4,0,6]  R843      -5.0236219167709351e-01
    z[4,0,6]  R844      -4.6849304437637329e-01
    z[4,0,6]  R845      -3.2818296551704407e-01
    z[4,0,6]  R846      1.7228440940380096e-01
    z[4,0,6]  R847      1.8132114410400391e-01
    z[4,0,6]  R848      -3.5852468013763428e-01
    z[4,0,6]  R849      -3.9278939366340637e-01
    z[4,0,6]  R850      -3.9323008060455322e-01
    z[4,0,6]  R851      -4.7162118554115295e-01
    z[4,0,6]  R852      -3.8046449422836304e-01
    z[4,0,6]  R853      -2.3921951651573181e-02
    z[4,0,6]  R854      -2.5964441895484924e-01
    z[4,0,6]  R855      -1.0932006686925888e-01
    z[4,0,6]  R856      -7.2604125738143921e-01
    z[4,0,6]  R857      -1.5151165425777435e-01
    z[4,0,6]  R858      -2.5049192830920219e-02
    z[4,0,6]  R859      -1.7614869773387909e-01
    z[4,0,6]  R860      -8.9096657931804657e-02
    z[4,0,6]  R861      -2.1664224565029144e-01
    z[4,0,6]  R862      -1.5606154501438141e-01
    z[4,0,6]  R863      8.1897906959056854e-02
    z[4,0,6]  R864      5.6511354446411133e-01
    z[4,0,6]  R865      1.8866769969463348e-01
    z[4,0,6]  R866      -4.9333442002534866e-02
    z[4,0,6]  R867      0.395723819732666
    z[4,0,6]  R868      4.1688024997711182e-02
    z[4,0,6]  R869      -7.4217252433300018e-02
    z[4,0,6]  R870      -2.4170126020908356e-01
    z[4,0,6]  R871      -1.0254694148898125e-02
    z[4,0,6]  R872      0.088455431163311
    z[4,0,6]  R873      -5.0630939006805420e-01
    z[4,0,6]  R874      7.0999123156070709e-02
    z[4,0,6]  R875      -3.2858546823263168e-02
    z[4,0,6]  R876      8.8604830205440521e-02
    z[4,0,6]  R877      4.9064168706536293e-03
    z[4,0,6]  R878      2.8341269493103027e-01
    z[4,0,6]  R879      -1.8354374170303345e-01
    z[4,0,6]  R880      4.4690284132957458e-01
    z[4,0,6]  R881      4.0696394443511963e-01
    z[4,0,6]  R882      -4.0506433695554733e-02
    z[4,0,6]  R883      3.2720208168029785e-01
    z[4,0,6]  R884      1.0336861759424210e-01
    z[4,0,6]  R885      -1.9738449156284332e-01
    z[4,0,6]  R886      -3.4226831048727036e-02
    z[4,0,6]  R887      4.3831002712249756e-01
    z[4,0,6]  R888      -1.2033692747354507e-01
    z[4,0,6]  R889      -3.2512211799621582e-01
    z[4,0,6]  R890      -4.3581396341323853e-01
    z[4,0,6]  R891      2.4558633565902710e-01
    z[4,0,6]  R892      4.3737164139747620e-01
    z[4,0,6]  R893      -4.1613289713859558e-01
    z[4,0,6]  R894      -1.3238739967346191e-01
    z[4,0,6]  R895      -1.2371501326560974e-01
    z[4,0,6]  R896      4.7032165527343750e-01
    z[4,0,6]  R897      -2.1344347298145294e-01
    z[4,0,6]  R898      -1.2281096726655960e-01
    z[4,0,6]  R899      3.1134957075119019e-01
    z[4,0,6]  R900      4.4350346922874451e-01
    z[4,0,6]  R901      -1.6316774487495422e-01
    z[4,0,6]  R902      1.5427152812480927e-01
    z[4,0,6]  R903      2.6543816924095154e-01
    z[4,0,6]  R904      -1.0702729225158691e-01
    z[4,0,6]  R905      5.6285685300827026e-01
    z[4,0,6]  R906      2.3148207366466522e-01
    z[4,0,6]  R907      -1.2104640156030655e-01
    z[4,0,6]  R908      -0.295296311378479
    z[4,0,6]  R909      -1.9183368980884552e-01
    z[4,0,6]  R910      1.1599563807249069e-01
    z[4,0,6]  R911      0.0747029259800911
    z[4,0,6]  R912      -2.4605879187583923e-01
    z[4,0,6]  R913      2.8579438105225563e-02
    z[4,0,6]  R914      0.0792076513171196
    z[4,0,6]  R915      -2.3442563414573669e-01
    z[4,0,6]  R916      -2.8481602668762207e-01
    z[4,0,6]  R917      8.9047178626060486e-03
    z[4,0,6]  R918      3.2759314775466919e-01
    z[4,0,6]  R919      -1.4143096632324159e-04
    z[4,0,6]  R920      1.8598626554012299e-01
    z[4,0,6]  R921      -2.0224186778068542e-01
    z[4,0,6]  R922      -2.2372610867023468e-01
    z[4,0,6]  R923      4.0545615553855896e-01
    z[4,0,6]  R924      -9.1858208179473877e-02
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R999      -1
    z[1,2,0]  R1000     1
    z[1,2,0]  R1013     4.4048145413398743e-01
    z[1,2,0]  R1014     4.4716534018516541e-01
    z[1,2,0]  R1015     3.1553784012794495e-01
    z[1,2,0]  R1016     2.1296481788158417e-01
    z[1,2,0]  R1017     2.0398156344890594e-01
    z[1,2,0]  R1018     1.4513950049877167e-01
    z[1,2,0]  R1019     4.2035266757011414e-01
    z[1,2,0]  R1020     1.8896244466304779e-01
    z[1,2,0]  R1021     2.6948067545890808e-01
    z[1,2,0]  R1022     5.3773349523544312e-01
    z[1,2,0]  R1023     -8.8005030155181885e-01
    z[1,2,0]  R1024     -8.4766268730163574e-01
    z[1,2,0]  R1025     -8.9489394426345825e-01
    z[1,2,0]  R1026     5.6491714715957642e-01
    z[1,2,0]  R1027     6.4999121427536011e-01
    z[1,2,0]  R1028     5.7755821943283081e-01
    z[1,2,0]  R1029     1.8908669054508209e-01
    z[1,2,0]  R1030     6.9569748640060425e-01
    z[1,2,0]  R1031     5.9627151489257812e-01
    z[1,2,0]  R1032     5.2757942676544189e-01
    z[1,2,0]  R1033     -3.5752275586128235e-01
    z[1,2,0]  R1034     -2.9642897844314575e-01
    z[1,2,0]  R1035     -6.3600605726242065e-01
    z[1,2,0]  R1036     -3.5773396492004395e-01
    z[1,2,0]  R1037     -1.8340660631656647e-01
    z[1,2,0]  R1038     -3.7775182723999023e-01
    z[1,2,0]  R1039     -3.4659394621849060e-01
    z[1,2,0]  R1040     6.2411874532699585e-02
    z[1,2,0]  R1041     4.5564625412225723e-02
    z[1,2,0]  R1042     -5.1198780536651611e-01
    z[1,2,0]  R1043     -4.8201125860214233e-01
    z[1,2,0]  R1044     -5.8650255203247070e-01
    z[1,2,0]  R1045     -4.3368390202522278e-01
    z[1,2,0]  R1046     -7.5530534982681274e-01
    z[1,2,0]  R1047     0.0590699128806591
    z[1,2,0]  R1048     -3.6986050009727478e-01
    z[1,2,0]  R1049     1.0634465515613556e-01
    z[1,2,0]  R1050     4.4743397831916809e-01
    z[1,2,0]  R1051     1.4682547748088837e-01
    z[1,2,0]  R1052     0.00492557417601347
    z[1,2,0]  R1053     -4.5591101050376892e-01
    z[1,2,0]  R1054     -6.2477695941925049e-01
    z[1,2,0]  R1055     1.2044054269790649e-01
    z[1,2,0]  R1056     2.5214740633964539e-01
    z[1,2,0]  R1057     1.6487506031990051e-01
    z[1,2,0]  R1058     -3.5710880160331726e-01
    z[1,2,0]  R1059     -2.3909138143062592e-01
    z[1,2,0]  R1060     -4.0107741951942444e-01
    z[1,2,0]  R1061     -2.8470501303672791e-01
    z[1,2,0]  R1062     6.0285080224275589e-02
    z[1,2,0]  R1063     -4.5614802837371826e-01
    z[1,2,0]  R1064     1.6883884370326996e-01
    z[1,2,0]  R1065     -5.7301348447799683e-01
    z[1,2,0]  R1066     -6.5560430288314819e-01
    z[1,2,0]  R1067     4.6026740223169327e-02
    z[1,2,0]  R1068     5.9459650516510010e-01
    z[1,2,0]  R1069     -8.1936977803707123e-03
    z[1,2,0]  R1070     -2.8132265806198120e-01
    z[1,2,0]  R1071     -3.0873646959662437e-02
    z[1,2,0]  R1072     6.2525354325771332e-02
    z[1,2,0]  R1073     -6.5801465511322021e-01
    z[1,2,0]  R1074     3.9888685941696167e-01
    z[1,2,0]  R1075     -7.6452434062957764e-01
    z[1,2,0]  R1076     7.1891725063323975e-01
    z[1,2,0]  R1077     1.0193198919296265e-01
    z[1,2,0]  R1078     4.0106898546218872e-01
    z[1,2,0]  R1079     -1.0802744328975677e-01
    z[1,2,0]  R1080     -2.2934605181217194e-01
    z[1,2,0]  R1081     -2.3645068705081940e-01
    z[1,2,0]  R1082     -6.9124542176723480e-02
    z[1,2,0]  R1083     -6.0876989364624023e-01
    z[1,2,0]  R1084     -4.0712639689445496e-01
    z[1,2,0]  R1085     -1.0106655955314636e-01
    z[1,2,0]  R1086     -1.8882115185260773e-01
    z[1,2,0]  R1087     3.2330492138862610e-01
    z[1,2,0]  R1088     -1.0135262459516525e-01
    z[1,2,0]  R1089     -2.3631669580936432e-02
    z[1,2,0]  R1090     2.9480382800102234e-02
    z[1,2,0]  R1091     -2.4920843541622162e-01
    z[1,2,0]  R1092     -1.4453461766242981e-01
    z[1,2,0]  R1093     -6.4922505617141724e-01
    z[1,2,0]  R1094     -6.0427713394165039e-01
    z[1,2,0]  R1095     7.9296268522739410e-02
    z[1,2,0]  R1096     5.6043070554733276e-01
    z[1,2,0]  R1097     -5.7753247022628784e-01
    z[1,2,0]  R1098     1.8766084313392639e-01
    z[1,2,0]  R1099     8.5992045700550079e-02
    z[1,2,0]  R1100     2.0371274650096893e-01
    z[1,2,0]  R1101     1.2180276960134506e-01
    z[1,2,0]  R1102     2.2687834501266479e-01
    z[1,2,0]  R1103     2.0851935446262360e-01
    z[1,2,0]  R1104     -1.5403975732624531e-02
    z[1,2,0]  R1105     3.5964307188987732e-01
    z[1,2,0]  R1106     2.5737184286117554e-01
    z[1,2,0]  R1107     -5.0401753187179565e-01
    z[1,2,0]  R1108     5.0322896242141724e-01
    z[1,2,0]  R1109     -2.0297326147556305e-01
    z[1,2,0]  R1110     -4.4124320149421692e-01
    z[1,2,0]  R1111     -4.2562133073806763e-01
    z[1,2,0]  R1112     -4.1262978315353394e-01
    z[1,2,0]  R1113     -8.6052364110946655e-01
    z[1,2,0]  R1114     -5.6854259967803955e-01
    z[1,2,0]  R1115     -7.7454006671905518e-01
    z[1,2,0]  R1116     -6.5631330013275146e-01
    z[1,2,0]  R1117     -6.3293945789337158e-01
    z[1,2,0]  R1118     3.4924343228340149e-01
    z[1,2,0]  R1119     2.7462828159332275e-01
    z[1,2,0]  R1120     5.4640930891036987e-01
    z[1,2,0]  R1121     0.637653648853302
    z[1,2,0]  R1122     6.7432254552841187e-01
    z[1,2,0]  R1123     2.8271627426147461e-01
    z[1,2,0]  R1124     5.7072299718856812e-01
    z[1,2,0]  R1125     5.4416990280151367e-01
    z[1,2,0]  R1126     4.5737496018409729e-01
    z[1,2,0]  R1127     5.2685087919235229e-01
    z[1,2,0]  R1128     5.9256774187088013e-01
    z[1,2,0]  R1129     5.1349717378616333e-01
    z[1,2,0]  R1130     4.4690340757369995e-01
    z[1,2,0]  R1131     5.3048992156982422e-01
    z[1,2,0]  R1132     5.3112769126892090e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R1001     -1
    z[1,2,1]  R1002     1
    z[1,2,1]  R1013     7.6852989196777344e-01
    z[1,2,1]  R1014     7.1061855554580688e-01
    z[1,2,1]  R1015     6.9127148389816284e-01
    z[1,2,1]  R1016     6.7748028039932251e-01
    z[1,2,1]  R1017     6.6225379705429077e-01
    z[1,2,1]  R1018     0.657947301864624
    z[1,2,1]  R1019     6.5257954597473145e-01
    z[1,2,1]  R1020     6.5442794561386108e-01
    z[1,2,1]  R1021     6.3109076023101807e-01
    z[1,2,1]  R1022     6.2716007232666016e-01
    z[1,2,1]  R1023     1.3539300300180912e-02
    z[1,2,1]  R1024     -0.0493953637778759
    z[1,2,1]  R1025     -4.1284445673227310e-02
    z[1,2,1]  R1026     -5.1278859376907349e-01
    z[1,2,1]  R1027     -5.4661726951599121e-01
    z[1,2,1]  R1028     -4.9537131190299988e-01
    z[1,2,1]  R1029     -5.5065184831619263e-01
    z[1,2,1]  R1030     -4.6201971173286438e-01
    z[1,2,1]  R1031     -6.0528641939163208e-01
    z[1,2,1]  R1032     -3.8753968477249146e-01
    z[1,2,1]  R1033     2.2777329385280609e-01
    z[1,2,1]  R1034     3.5794261097908020e-01
    z[1,2,1]  R1035     -0.0707663968205452
    z[1,2,1]  R1036     2.1073617041110992e-01
    z[1,2,1]  R1037     2.3412954807281494e-01
    z[1,2,1]  R1038     2.5247669219970703e-01
    z[1,2,1]  R1039     1.3208749890327454e-01
    z[1,2,1]  R1040     6.7550706863403320e-01
    z[1,2,1]  R1041     6.7064303159713745e-01
    z[1,2,1]  R1042     -4.9852974712848663e-02
    z[1,2,1]  R1043     4.2516711354255676e-01
    z[1,2,1]  R1044     2.7613270282745361e-01
    z[1,2,1]  R1045     2.8282597661018372e-01
    z[1,2,1]  R1046     4.4181060791015625e-01
    z[1,2,1]  R1047     -1.9234298169612885e-01
    z[1,2,1]  R1048     1.0171489417552948e-01
    z[1,2,1]  R1049     5.7744336128234863e-01
    z[1,2,1]  R1050     -5.2219372987747192e-01
    z[1,2,1]  R1051     -3.1241990625858307e-02
    z[1,2,1]  R1052     5.3227978944778442e-01
    z[1,2,1]  R1053     3.8184702396392822e-01
    z[1,2,1]  R1054     -2.7537789195775986e-02
    z[1,2,1]  R1055     8.5406959056854248e-01
    z[1,2,1]  R1056     8.1836843490600586e-01
    z[1,2,1]  R1057     2.6267403364181519e-01
    z[1,2,1]  R1058     1.3385763764381409e-01
    z[1,2,1]  R1059     2.5609949231147766e-01
    z[1,2,1]  R1060     8.2399033010005951e-02
    z[1,2,1]  R1061     2.4601301550865173e-01
    z[1,2,1]  R1062     6.1969733238220215e-01
    z[1,2,1]  R1063     4.0898019075393677e-01
    z[1,2,1]  R1064     6.4176046848297119e-01
    z[1,2,1]  R1065     1.0565433651208878e-01
    z[1,2,1]  R1066     1.3106757402420044e-01
    z[1,2,1]  R1067     9.3674689531326294e-01
    z[1,2,1]  R1068     5.0609749555587769e-01
    z[1,2,1]  R1069     4.6355494856834412e-01
    z[1,2,1]  R1070     0.284940242767334
    z[1,2,1]  R1071     2.8398683294653893e-02
    z[1,2,1]  R1072     2.4847318232059479e-01
    z[1,2,1]  R1073     2.6605013012886047e-01
    z[1,2,1]  R1074     8.0469900369644165e-01
    z[1,2,1]  R1075     4.4193947315216064e-01
    z[1,2,1]  R1076     -5.1152259111404419e-01
    z[1,2,1]  R1077     -4.2723175883293152e-01
    z[1,2,1]  R1078     -4.2270788550376892e-01
    z[1,2,1]  R1079     -2.3982043564319611e-01
    z[1,2,1]  R1080     -9.1337114572525024e-01
    z[1,2,1]  R1081     -8.7942677736282349e-01
    z[1,2,1]  R1082     -2.8539735078811646e-01
    z[1,2,1]  R1083     3.4915563464164734e-01
    z[1,2,1]  R1084     3.8095399737358093e-01
    z[1,2,1]  R1085     5.5673009157180786e-01
    z[1,2,1]  R1086     -1.8500310182571411e-01
    z[1,2,1]  R1087     -3.9021816849708557e-01
    z[1,2,1]  R1088     3.8227722048759460e-02
    z[1,2,1]  R1089     -2.0226265490055084e-01
    z[1,2,1]  R1090     5.9279982000589371e-02
    z[1,2,1]  R1091     -0.926781177520752
    z[1,2,1]  R1092     -7.5965744256973267e-01
    z[1,2,1]  R1093     1.5500506758689880e-01
    z[1,2,1]  R1094     7.0526483468711376e-03
    z[1,2,1]  R1095     9.5337331295013428e-01
    z[1,2,1]  R1096     -6.2721198797225952e-01
    z[1,2,1]  R1097     3.7929084897041321e-01
    z[1,2,1]  R1098     -1.0878720879554749e-01
    z[1,2,1]  R1099     -3.3713793754577637e-01
    z[1,2,1]  R1100     -3.9753583073616028e-01
    z[1,2,1]  R1101     -0.273084819316864
    z[1,2,1]  R1102     -3.3717691898345947e-01
    z[1,2,1]  R1103     5.9952521324157715e-01
    z[1,2,1]  R1104     7.3347389698028564e-01
    z[1,2,1]  R1105     5.4051935672760010e-01
    z[1,2,1]  R1106     7.6075994968414307e-01
    z[1,2,1]  R1107     7.6848263852298260e-03
    z[1,2,1]  R1108     -6.0933738946914673e-01
    z[1,2,1]  R1109     -1.2389837950468063e-01
    z[1,2,1]  R1110     1.5843097865581512e-01
    z[1,2,1]  R1111     6.7712232470512390e-02
    z[1,2,1]  R1112     5.8002066798508167e-03
    z[1,2,1]  R1113     -9.5188491046428680e-02
    z[1,2,1]  R1114     -2.5689724087715149e-01
    z[1,2,1]  R1115     1.6511952504515648e-02
    z[1,2,1]  R1116     1.6391709446907043e-01
    z[1,2,1]  R1117     0.169791579246521
    z[1,2,1]  R1118     0.3975810110569
    z[1,2,1]  R1119     3.8544443249702454e-01
    z[1,2,1]  R1120     -0.354875385761261
    z[1,2,1]  R1121     -3.7354382872581482e-01
    z[1,2,1]  R1122     -1.7746937274932861e-01
    z[1,2,1]  R1123     5.2763038873672485e-01
    z[1,2,1]  R1124     -0.36905637383461
    z[1,2,1]  R1125     -4.2943546175956726e-01
    z[1,2,1]  R1126     -4.2379817366600037e-01
    z[1,2,1]  R1127     -4.1507422924041748e-01
    z[1,2,1]  R1128     -4.2539614439010620e-01
    z[1,2,1]  R1129     -2.7495419979095459e-01
    z[1,2,1]  R1130     -2.7008923888206482e-01
    z[1,2,1]  R1131     -1.9018433988094330e-01
    z[1,2,1]  R1132     -3.8987907767295837e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R1003     -1
    z[1,2,2]  R1004     1
    z[1,2,2]  R1013     1.9762471318244934e-01
    z[1,2,2]  R1014     1.8094404041767120e-01
    z[1,2,2]  R1015     1.7155742272734642e-02
    z[1,2,2]  R1016     2.3242124915122986e-01
    z[1,2,2]  R1017     2.0797017216682434e-01
    z[1,2,2]  R1018     3.0362471938133240e-01
    z[1,2,2]  R1019     1.5505865216255188e-01
    z[1,2,2]  R1020     1.7621801793575287e-01
    z[1,2,2]  R1021     1.8051068484783173e-01
    z[1,2,2]  R1022     -1.3206172734498978e-02
    z[1,2,2]  R1023     -6.9564029574394226e-02
    z[1,2,2]  R1024     1.7230573296546936e-01
    z[1,2,2]  R1025     1.7138895392417908e-01
    z[1,2,2]  R1026     -1.4812509715557098e-01
    z[1,2,2]  R1027     -1.6373504698276520e-01
    z[1,2,2]  R1028     -2.1429817378520966e-01
    z[1,2,2]  R1029     -2.5060099363327026e-01
    z[1,2,2]  R1030     -6.6603772342205048e-02
    z[1,2,2]  R1031     4.1931409388780594e-02
    z[1,2,2]  R1032     -1.5611787140369415e-01
    z[1,2,2]  R1033     2.7155104279518127e-01
    z[1,2,2]  R1034     -1.2577632069587708e-01
    z[1,2,2]  R1035     -2.7121728658676147e-01
    z[1,2,2]  R1036     0.0661039724946022
    z[1,2,2]  R1037     -5.5829749908298254e-04
    z[1,2,2]  R1038     -1.6054630279541016e-01
    z[1,2,2]  R1039     1.1115300655364990e-01
    z[1,2,2]  R1040     -0.4558085501194
    z[1,2,2]  R1041     -4.5450708270072937e-01
    z[1,2,2]  R1042     6.2247227877378464e-02
    z[1,2,2]  R1043     4.6318256855010986e-01
    z[1,2,2]  R1044     4.2427086830139160e-01
    z[1,2,2]  R1045     1.3735873997211456e-01
    z[1,2,2]  R1046     -2.5027480721473694e-01
    z[1,2,2]  R1047     1.4518241398036480e-02
    z[1,2,2]  R1048     3.6463406682014465e-01
    z[1,2,2]  R1049     -3.2373934984207153e-01
    z[1,2,2]  R1050     4.8716405034065247e-01
    z[1,2,2]  R1051     3.8003337383270264e-01
    z[1,2,2]  R1052     -1.1138872057199478e-01
    z[1,2,2]  R1053     6.1045867204666138e-01
    z[1,2,2]  R1054     -1.4914770424365997e-01
    z[1,2,2]  R1055     -3.2510453462600708e-01
    z[1,2,2]  R1056     -2.3592798411846161e-01
    z[1,2,2]  R1057     -3.6896771192550659e-01
    z[1,2,2]  R1058     8.4914974868297577e-02
    z[1,2,2]  R1059     2.3748025298118591e-01
    z[1,2,2]  R1060     -4.6754304319620132e-02
    z[1,2,2]  R1061     4.0193051099777222e-01
    z[1,2,2]  R1062     -3.2748410105705261e-01
    z[1,2,2]  R1063     3.2034772634506226e-01
    z[1,2,2]  R1064     3.4528324007987976e-01
    z[1,2,2]  R1065     -9.6078209578990936e-02
    z[1,2,2]  R1066     -2.2535999119281769e-01
    z[1,2,2]  R1067     -2.2950629889965057e-01
    z[1,2,2]  R1068     -1.9488035142421722e-01
    z[1,2,2]  R1069     -1.3908736407756805e-01
    z[1,2,2]  R1070     3.8566029071807861e-01
    z[1,2,2]  R1071     -1.7290504276752472e-01
    z[1,2,2]  R1072     -5.4297423362731934e-01
    z[1,2,2]  R1073     1.8496979773044586e-01
    z[1,2,2]  R1074     -0.244472473859787
    z[1,2,2]  R1075     -2.9634317755699158e-01
    z[1,2,2]  R1076     3.2215365767478943e-01
    z[1,2,2]  R1077     1.1727154999971390e-01
    z[1,2,2]  R1078     5.3423233330249786e-02
    z[1,2,2]  R1079     3.2155385613441467e-01
    z[1,2,2]  R1080     1.3224214315414429e-01
    z[1,2,2]  R1081     1.9594286382198334e-01
    z[1,2,2]  R1082     2.3662203550338745e-01
    z[1,2,2]  R1083     2.2422102093696594e-01
    z[1,2,2]  R1084     4.1424378752708435e-01
    z[1,2,2]  R1085     -4.9048945307731628e-01
    z[1,2,2]  R1086     4.3830013275146484e-01
    z[1,2,2]  R1087     0.417977511882782
    z[1,2,2]  R1088     4.0899294614791870e-01
    z[1,2,2]  R1089     2.4501444399356842e-01
    z[1,2,2]  R1090     -1.8349802494049072e-01
    z[1,2,2]  R1091     1.4926487207412720e-01
    z[1,2,2]  R1092     3.8419011235237122e-01
    z[1,2,2]  R1093     2.4462023377418518e-01
    z[1,2,2]  R1094     -1.4788176119327545e-01
    z[1,2,2]  R1095     -4.7778464853763580e-02
    z[1,2,2]  R1096     1.4802455902099609e-01
    z[1,2,2]  R1097     -4.2650622129440308e-01
    z[1,2,2]  R1098     4.7915931791067123e-03
    z[1,2,2]  R1099     -8.4596776962280273e-01
    z[1,2,2]  R1100     -7.6929843425750732e-01
    z[1,2,2]  R1101     -8.8198131322860718e-01
    z[1,2,2]  R1102     -8.0463838577270508e-01
    z[1,2,2]  R1103     -4.0175938606262207e-01
    z[1,2,2]  R1104     -0.0754147619009018
    z[1,2,2]  R1105     -5.1272273063659668e-01
    z[1,2,2]  R1106     4.7629281878471375e-02
    z[1,2,2]  R1107     4.2262795567512512e-01
    z[1,2,2]  R1108     -3.9237266778945923e-01
    z[1,2,2]  R1109     0.0480094775557518
    z[1,2,2]  R1110     -3.9981681853532791e-02
    z[1,2,2]  R1111     -5.0601817667484283e-02
    z[1,2,2]  R1112     3.1279647350311279e-01
    z[1,2,2]  R1113     -1.2840218842029572e-01
    z[1,2,2]  R1114     -3.8769415020942688e-01
    z[1,2,2]  R1115     -5.0271785259246826e-01
    z[1,2,2]  R1116     2.7499321103096008e-01
    z[1,2,2]  R1117     3.5533748567104340e-02
    z[1,2,2]  R1118     -4.8125658184289932e-02
    z[1,2,2]  R1119     1.6836115717887878e-01
    z[1,2,2]  R1120     4.5957425236701965e-01
    z[1,2,2]  R1121     3.9908558130264282e-01
    z[1,2,2]  R1122     3.9081260561943054e-01
    z[1,2,2]  R1123     5.9389103204011917e-02
    z[1,2,2]  R1124     0.49821937084198
    z[1,2,2]  R1125     5.1848423480987549e-01
    z[1,2,2]  R1126     6.0682344436645508e-01
    z[1,2,2]  R1127     5.9697711467742920e-01
    z[1,2,2]  R1128     3.2818609476089478e-01
    z[1,2,2]  R1129     4.1627770662307739e-01
    z[1,2,2]  R1130     5.0859099626541138e-01
    z[1,2,2]  R1131     4.5980966091156006e-01
    z[1,2,2]  R1132     2.1257606148719788e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R1005     -1
    z[1,2,3]  R1006     1
    z[1,2,3]  R1013     2.4325282871723175e-01
    z[1,2,3]  R1014     -2.9130894690752029e-02
    z[1,2,3]  R1015     -2.5148457288742065e-01
    z[1,2,3]  R1016     1.2540750205516815e-01
    z[1,2,3]  R1017     -6.9350488483905792e-02
    z[1,2,3]  R1018     -2.2384946048259735e-01
    z[1,2,3]  R1019     -1.5611016750335693e-01
    z[1,2,3]  R1020     0.351661741733551
    z[1,2,3]  R1021     -1.9590289890766144e-01
    z[1,2,3]  R1022     -1.4304912090301514e-01
    z[1,2,3]  R1023     2.1276351809501648e-01
    z[1,2,3]  R1024     2.3736884817481041e-02
    z[1,2,3]  R1025     2.3033104836940765e-01
    z[1,2,3]  R1026     -5.3111881017684937e-01
    z[1,2,3]  R1027     -4.1673696041107178e-01
    z[1,2,3]  R1028     -6.0401380062103271e-01
    z[1,2,3]  R1029     -7.1226024627685547e-01
    z[1,2,3]  R1030     -5.0312846899032593e-01
    z[1,2,3]  R1031     -3.5064321756362915e-01
    z[1,2,3]  R1032     -6.3387966156005859e-01
    z[1,2,3]  R1033     -6.4800351858139038e-01
    z[1,2,3]  R1034     -7.8793352842330933e-01
    z[1,2,3]  R1035     -1.7942821979522705e-01
    z[1,2,3]  R1036     -0.599696934223175
    z[1,2,3]  R1037     -9.0880846977233887e-01
    z[1,2,3]  R1038     -0.678071916103363
    z[1,2,3]  R1039     -3.2827010750770569e-01
    z[1,2,3]  R1040     -3.1030055880546570e-01
    z[1,2,3]  R1041     -5.1563370227813721e-01
    z[1,2,3]  R1042     -4.5084246993064880e-01
    z[1,2,3]  R1043     4.4007804989814758e-01
    z[1,2,3]  R1044     3.3346137404441833e-01
    z[1,2,3]  R1045     1.2889523059129715e-02
    z[1,2,3]  R1046     -2.9720512032508850e-01
    z[1,2,3]  R1047     -0.571692705154419
    z[1,2,3]  R1048     -3.4564909338951111e-01
    z[1,2,3]  R1049     -2.9619028791785240e-03
    z[1,2,3]  R1050     2.4839065968990326e-01
    z[1,2,3]  R1051     8.3537089824676514e-01
    z[1,2,3]  R1052     6.5786695480346680e-01
    z[1,2,3]  R1053     -4.3137678503990173e-01
    z[1,2,3]  R1054     -2.2906927764415741e-01
    z[1,2,3]  R1055     -2.2457545623183250e-02
    z[1,2,3]  R1056     -8.8043145835399628e-02
    z[1,2,3]  R1057     -7.6031464338302612e-01
    z[1,2,3]  R1058     -4.3721115589141846e-01
    z[1,2,3]  R1059     -1.2719729542732239e-01
    z[1,2,3]  R1060     -4.4476732611656189e-01
    z[1,2,3]  R1061     2.0254816114902496e-01
    z[1,2,3]  R1062     1.8693853914737701e-01
    z[1,2,3]  R1063     -4.4414305686950684e-01
    z[1,2,3]  R1064     4.7506517171859741e-01
    z[1,2,3]  R1065     -1.5171146392822266e-01
    z[1,2,3]  R1066     -4.6923705935478210e-01
    z[1,2,3]  R1067     2.3001782596111298e-02
    z[1,2,3]  R1068     1.2662726454436779e-02
    z[1,2,3]  R1069     -0.766851007938385
    z[1,2,3]  R1070     1.9679950177669525e-01
    z[1,2,3]  R1071     -8.5443496704101562e-01
    z[1,2,3]  R1072     -7.1599733829498291e-01
    z[1,2,3]  R1073     -0.621579110622406
    z[1,2,3]  R1074     -1.8579454720020294e-01
    z[1,2,3]  R1075     -3.1899437308311462e-01
    z[1,2,3]  R1076     2.7757775783538818e-01
    z[1,2,3]  R1077     -3.3909055590629578e-01
    z[1,2,3]  R1078     1.6180644929409027e-01
    z[1,2,3]  R1079     7.4454855918884277e-01
    z[1,2,3]  R1080     2.3615576326847076e-02
    z[1,2,3]  R1081     -6.1152640730142593e-02
    z[1,2,3]  R1082     6.6606956720352173e-01
    z[1,2,3]  R1083     -2.6376655697822571e-01
    z[1,2,3]  R1084     2.7661317586898804e-01
    z[1,2,3]  R1085     -4.9569407105445862e-01
    z[1,2,3]  R1086     7.1560466289520264e-01
    z[1,2,3]  R1087     1.2439829856157303e-01
    z[1,2,3]  R1088     8.8599252700805664e-01
    z[1,2,3]  R1089     8.0509597063064575e-01
    z[1,2,3]  R1090     9.6395754814147949e-01
    z[1,2,3]  R1091     1.3031853735446930e-01
    z[1,2,3]  R1092     4.5830440521240234e-01
    z[1,2,3]  R1093     2.2185295820236206e-01
    z[1,2,3]  R1094     -3.4237092733383179e-01
    z[1,2,3]  R1095     1.3089454174041748e-01
    z[1,2,3]  R1096     1.9845359027385712e-02
    z[1,2,3]  R1097     -1.9326542317867279e-01
    z[1,2,3]  R1098     -5.7583391666412354e-01
    z[1,2,3]  R1099     0.336665540933609
    z[1,2,3]  R1100     3.8043934106826782e-01
    z[1,2,3]  R1101     3.3475691080093384e-01
    z[1,2,3]  R1102     3.3808118104934692e-01
    z[1,2,3]  R1103     -3.8041961193084717e-01
    z[1,2,3]  R1104     -4.0003478527069092e-01
    z[1,2,3]  R1105     -3.1106692552566528e-01
    z[1,2,3]  R1106     -4.1161969304084778e-01
    z[1,2,3]  R1107     2.6464501023292542e-01
    z[1,2,3]  R1108     -3.0929449200630188e-01
    z[1,2,3]  R1109     3.8125178217887878e-01
    z[1,2,3]  R1110     7.1631860733032227e-01
    z[1,2,3]  R1111     7.1944117546081543e-01
    z[1,2,3]  R1112     3.1913855671882629e-01
    z[1,2,3]  R1113     -9.6025623381137848e-02
    z[1,2,3]  R1114     2.6896673440933228e-01
    z[1,2,3]  R1115     1.9394946098327637e-01
    z[1,2,3]  R1116     1.8569202721118927e-01
    z[1,2,3]  R1117     3.1972801685333252e-01
    z[1,2,3]  R1118     7.7558934688568115e-01
    z[1,2,3]  R1119     6.8880569934844971e-01
    z[1,2,3]  R1120     5.7362580299377441e-01
    z[1,2,3]  R1121     3.9625069499015808e-01
    z[1,2,3]  R1122     5.5744445323944092e-01
    z[1,2,3]  R1123     7.7658736705780029e-01
    z[1,2,3]  R1124     4.8028782010078430e-01
    z[1,2,3]  R1125     3.7779018282890320e-01
    z[1,2,3]  R1126     3.5796162486076355e-01
    z[1,2,3]  R1127     4.1075026988983154e-01
    z[1,2,3]  R1128     3.3119884133338928e-01
    z[1,2,3]  R1129     4.9578070640563965e-01
    z[1,2,3]  R1130     4.5892271399497986e-01
    z[1,2,3]  R1131     5.3256541490554810e-01
    z[1,2,3]  R1132     3.6666208505630493e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R1007     -1
    z[1,2,4]  R1008     1
    z[1,2,4]  R1013     3.9067290723323822e-02
    z[1,2,4]  R1014     -2.8967443108558655e-01
    z[1,2,4]  R1015     5.9735560417175293e-01
    z[1,2,4]  R1016     1.1907239258289337e-01
    z[1,2,4]  R1017     -2.6911571621894836e-01
    z[1,2,4]  R1018     -4.7039699554443359e-01
    z[1,2,4]  R1019     2.0863448083400726e-01
    z[1,2,4]  R1020     3.7537318468093872e-01
    z[1,2,4]  R1021     -4.9597907066345215e-01
    z[1,2,4]  R1022     0.436262845993042
    z[1,2,4]  R1023     2.0806825160980225e-01
    z[1,2,4]  R1024     -4.7438085079193115e-01
    z[1,2,4]  R1025     -1.6129940748214722e-01
    z[1,2,4]  R1026     -1.7047438025474548e-01
    z[1,2,4]  R1027     1.5612085163593292e-01
    z[1,2,4]  R1028     1.6943825408816338e-02
    z[1,2,4]  R1029     -9.3334801495075226e-03
    z[1,2,4]  R1030     1.4701751992106438e-02
    z[1,2,4]  R1031     2.4286296218633652e-02
    z[1,2,4]  R1032     6.5779253840446472e-02
    z[1,2,4]  R1033     6.7274391651153564e-02
    z[1,2,4]  R1034     -5.7650838047266006e-02
    z[1,2,4]  R1035     2.0311267673969269e-01
    z[1,2,4]  R1036     2.9101410508155823e-01
    z[1,2,4]  R1037     2.6428506243973970e-03
    z[1,2,4]  R1038     2.0727189257740974e-02
    z[1,2,4]  R1039     4.8381105065345764e-01
    z[1,2,4]  R1040     2.1485836803913116e-01
    z[1,2,4]  R1041     1.8651841580867767e-01
    z[1,2,4]  R1042     6.1027181148529053e-01
    z[1,2,4]  R1043     2.7737993001937866e-01
    z[1,2,4]  R1044     3.2691791653633118e-01
    z[1,2,4]  R1045     -3.2753947377204895e-01
    z[1,2,4]  R1046     -1.5371769666671753e-01
    z[1,2,4]  R1047     1.7633976042270660e-01
    z[1,2,4]  R1048     1.0239803791046143e-01
    z[1,2,4]  R1049     2.8421280905604362e-02
    z[1,2,4]  R1050     -1.8215529620647430e-02
    z[1,2,4]  R1051     4.5270342379808426e-02
    z[1,2,4]  R1052     -2.9345223307609558e-01
    z[1,2,4]  R1053     -9.8966039717197418e-02
    z[1,2,4]  R1054     5.8230036497116089e-01
    z[1,2,4]  R1055     -7.7445581555366516e-02
    z[1,2,4]  R1056     5.4957754909992218e-02
    z[1,2,4]  R1057     0.0887366533279419
    z[1,2,4]  R1058     1.2271800637245178e-01
    z[1,2,4]  R1059     1.7630773782730103e-01
    z[1,2,4]  R1060     -2.7799794077873230e-01
    z[1,2,4]  R1061     -2.6498362421989441e-01
    z[1,2,4]  R1062     4.8734968900680542e-01
    z[1,2,4]  R1063     2.7661731839179993e-01
    z[1,2,4]  R1064     -3.4113430976867676e-01
    z[1,2,4]  R1065     0.190584197640419
    z[1,2,4]  R1066     4.2454391717910767e-01
    z[1,2,4]  R1067     6.2954194843769073e-02
    z[1,2,4]  R1068     5.1860720850527287e-03
    z[1,2,4]  R1069     -4.0332680940628052e-01
    z[1,2,4]  R1070     -2.6774457097053528e-01
    z[1,2,4]  R1071     4.1753351688385010e-01
    z[1,2,4]  R1072     2.6212513446807861e-01
    z[1,2,4]  R1073     -1.9029390811920166e-01
    z[1,2,4]  R1074     -1.3608361780643463e-01
    z[1,2,4]  R1075     -6.1558857560157776e-02
    z[1,2,4]  R1076     -6.4338847994804382e-02
    z[1,2,4]  R1077     5.0951063632965088e-01
    z[1,2,4]  R1078     4.8818126320838928e-01
    z[1,2,4]  R1079     2.8009146451950073e-01
    z[1,2,4]  R1080     1.1476716957986355e-02
    z[1,2,4]  R1081     -1.6288541257381439e-01
    z[1,2,4]  R1082     -2.3661302030086517e-01
    z[1,2,4]  R1083     -2.9888426885008812e-02
    z[1,2,4]  R1084     -5.2529531717300415e-01
    z[1,2,4]  R1085     1.1386800557374954e-01
    z[1,2,4]  R1086     -2.6716282963752747e-01
    z[1,2,4]  R1087     2.3903135955333710e-01
    z[1,2,4]  R1088     1.6486936807632446e-01
    z[1,2,4]  R1089     5.1504410803318024e-02
    z[1,2,4]  R1090     1.4756634831428528e-01
    z[1,2,4]  R1091     1.8596661090850830e-01
    z[1,2,4]  R1092     1.2414073944091797e-01
    z[1,2,4]  R1093     -4.9323442578315735e-01
    z[1,2,4]  R1094     3.7036576867103577e-01
    z[1,2,4]  R1095     -2.0263580977916718e-01
    z[1,2,4]  R1096     0.294387549161911
    z[1,2,4]  R1097     2.8524341061711311e-02
    z[1,2,4]  R1098     -7.0917648077011108e-01
    z[1,2,4]  R1099     1.6378301382064819e-01
    z[1,2,4]  R1100     -2.4107404053211212e-01
    z[1,2,4]  R1101     -0.0662151351571083
    z[1,2,4]  R1102     -2.0259568095207214e-01
    z[1,2,4]  R1103     -4.8983284831047058e-01
    z[1,2,4]  R1104     2.7587356045842171e-02
    z[1,2,4]  R1105     3.8253080844879150e-01
    z[1,2,4]  R1106     2.2896544635295868e-01
    z[1,2,4]  R1107     0.61134272813797
    z[1,2,4]  R1108     5.2625991404056549e-02
    z[1,2,4]  R1109     -0.245507150888443
    z[1,2,4]  R1110     -4.7838117927312851e-02
    z[1,2,4]  R1111     -4.5447820425033569e-01
    z[1,2,4]  R1112     -7.2568637132644653e-01
    z[1,2,4]  R1113     -2.4012076854705811e-01
    z[1,2,4]  R1114     -4.1983744502067566e-01
    z[1,2,4]  R1115     -2.0180565118789673e-01
    z[1,2,4]  R1116     -5.9347146749496460e-01
    z[1,2,4]  R1117     -6.8957552313804626e-02
    z[1,2,4]  R1118     -2.2105820477008820e-01
    z[1,2,4]  R1119     -8.8698320090770721e-02
    z[1,2,4]  R1120     -1.4955131709575653e-01
    z[1,2,4]  R1121     -5.1410477608442307e-03
    z[1,2,4]  R1122     1.3310334086418152e-01
    z[1,2,4]  R1123     -1.3876292109489441e-01
    z[1,2,4]  R1124     -2.4128077924251556e-01
    z[1,2,4]  R1125     -3.0206805467605591e-01
    z[1,2,4]  R1126     -2.2211056947708130e-01
    z[1,2,4]  R1127     1.5509857237339020e-01
    z[1,2,4]  R1128     -3.3147913217544556e-01
    z[1,2,4]  R1129     5.0097596831619740e-03
    z[1,2,4]  R1130     2.2887936234474182e-01
    z[1,2,4]  R1131     -1.0418955981731415e-01
    z[1,2,4]  R1132     -5.0786298513412476e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R1009     -1
    z[1,2,5]  R1010     1
    z[1,2,5]  R1013     3.3873483538627625e-01
    z[1,2,5]  R1014     1.2411311268806458e-01
    z[1,2,5]  R1015     -4.6913441270589828e-02
    z[1,2,5]  R1016     -4.4032388925552368e-01
    z[1,2,5]  R1017     -0.530138373374939
    z[1,2,5]  R1018     2.3358824849128723e-01
    z[1,2,5]  R1019     4.1394233703613281e-01
    z[1,2,5]  R1020     4.8824291676282883e-02
    z[1,2,5]  R1021     -3.9712780714035034e-01
    z[1,2,5]  R1022     2.7972424030303955e-01
    z[1,2,5]  R1023     3.5715565085411072e-01
    z[1,2,5]  R1024     -1.5061445534229279e-01
    z[1,2,5]  R1025     -8.1352427601814270e-02
    z[1,2,5]  R1026     -1.8826331198215485e-01
    z[1,2,5]  R1027     -1.8314327299594879e-01
    z[1,2,5]  R1028     2.1702989935874939e-02
    z[1,2,5]  R1029     -2.7365726232528687e-01
    z[1,2,5]  R1030     1.4367893338203430e-01
    z[1,2,5]  R1031     -2.9355597496032715e-01
    z[1,2,5]  R1032     -1.6940365731716156e-01
    z[1,2,5]  R1033     2.3928731679916382e-01
    z[1,2,5]  R1034     -2.8580215573310852e-01
    z[1,2,5]  R1035     -6.6587787866592407e-01
    z[1,2,5]  R1036     -5.1513540744781494e-01
    z[1,2,5]  R1037     2.9050523042678833e-01
    z[1,2,5]  R1038     -5.2687561511993408e-01
    z[1,2,5]  R1039     -7.1248096227645874e-01
    z[1,2,5]  R1040     -3.8606736063957214e-01
    z[1,2,5]  R1041     1.8828584253787994e-01
    z[1,2,5]  R1042     -3.4893444180488586e-01
    z[1,2,5]  R1043     2.3667345941066742e-01
    z[1,2,5]  R1044     -3.8476511836051941e-01
    z[1,2,5]  R1045     -6.4561265707015991e-01
    z[1,2,5]  R1046     -1.8605917692184448e-01
    z[1,2,5]  R1047     7.7510738372802734e-01
    z[1,2,5]  R1048     -8.8310331106185913e-02
    z[1,2,5]  R1049     -3.1413757801055908e-01
    z[1,2,5]  R1050     4.4666835665702820e-01
    z[1,2,5]  R1051     3.6467710137367249e-01
    z[1,2,5]  R1052     -3.1655681133270264e-01
    z[1,2,5]  R1053     2.3101146519184113e-01
    z[1,2,5]  R1054     -2.2347655892372131e-01
    z[1,2,5]  R1055     -2.3387621343135834e-01
    z[1,2,5]  R1056     -4.4238799810409546e-01
    z[1,2,5]  R1057     1.2042701244354248e-02
    z[1,2,5]  R1058     0.0900174155831337
    z[1,2,5]  R1059     -2.4764549732208252e-01
    z[1,2,5]  R1060     -5.9273451566696167e-01
    z[1,2,5]  R1061     2.1468596160411835e-01
    z[1,2,5]  R1062     2.5821685791015625e-02
    z[1,2,5]  R1063     4.2101528495550156e-02
    z[1,2,5]  R1064     -1.9953294098377228e-01
    z[1,2,5]  R1065     -3.8285022974014282e-01
    z[1,2,5]  R1066     -3.0303534865379333e-01
    z[1,2,5]  R1067     -2.1895058453083038e-01
    z[1,2,5]  R1068     -1.7859362065792084e-01
    z[1,2,5]  R1069     -1.2226261198520660e-01
    z[1,2,5]  R1070     8.4042645990848541e-02
    z[1,2,5]  R1071     4.6469278633594513e-02
    z[1,2,5]  R1072     -2.3661652207374573e-01
    z[1,2,5]  R1073     5.3901232779026031e-02
    z[1,2,5]  R1074     -2.5268737226724625e-02
    z[1,2,5]  R1075     1.1423484981060028e-01
    z[1,2,5]  R1076     9.2856295406818390e-02
    z[1,2,5]  R1077     6.0295450687408447e-01
    z[1,2,5]  R1078     5.0113433599472046e-01
    z[1,2,5]  R1079     1.6589875519275665e-01
    z[1,2,5]  R1080     2.8435957431793213e-01
    z[1,2,5]  R1081     3.1393593549728394e-01
    z[1,2,5]  R1082     2.0554584264755249e-01
    z[1,2,5]  R1083     5.3236478567123413e-01
    z[1,2,5]  R1084     -3.4749662876129150e-01
    z[1,2,5]  R1085     -4.1468435525894165e-01
    z[1,2,5]  R1086     3.0284056067466736e-01
    z[1,2,5]  R1087     0.639694094657898
    z[1,2,5]  R1088     0.0696791484951973
    z[1,2,5]  R1089     1.8360999226570129e-01
    z[1,2,5]  R1090     -1.0117681324481964e-01
    z[1,2,5]  R1091     7.0125319063663483e-02
    z[1,2,5]  R1092     1.1617124080657959e-01
    z[1,2,5]  R1093     4.4329819083213806e-01
    z[1,2,5]  R1094     -5.5636620521545410e-01
    z[1,2,5]  R1095     -1.4024247229099274e-01
    z[1,2,5]  R1096     4.0735453367233276e-01
    z[1,2,5]  R1097     -1.9044749438762665e-01
    z[1,2,5]  R1098     -3.1642335653305054e-01
    z[1,2,5]  R1099     -1.4758719503879547e-01
    z[1,2,5]  R1100     6.5971814095973969e-02
    z[1,2,5]  R1101     -4.5893844217061996e-02
    z[1,2,5]  R1102     8.5568435490131378e-02
    z[1,2,5]  R1103     5.6663446128368378e-02
    z[1,2,5]  R1104     -3.8086524605751038e-01
    z[1,2,5]  R1105     -1.1776731908321381e-01
    z[1,2,5]  R1106     3.6166024208068848e-01
    z[1,2,5]  R1107     -3.1754210591316223e-01
    z[1,2,5]  R1108     3.4753009676933289e-01
    z[1,2,5]  R1109     2.7488359808921814e-01
    z[1,2,5]  R1110     5.0187402963638306e-01
    z[1,2,5]  R1111     1.1820279061794281e-01
    z[1,2,5]  R1112     -3.1481122970581055e-01
    z[1,2,5]  R1113     3.7921205163002014e-01
    z[1,2,5]  R1114     -4.5613449811935425e-01
    z[1,2,5]  R1115     1.1303842067718506e-01
    z[1,2,5]  R1116     2.1613454818725586e-01
    z[1,2,5]  R1117     6.1869156360626221e-01
    z[1,2,5]  R1118     -1.5857380628585815e-01
    z[1,2,5]  R1119     -4.9893024563789368e-01
    z[1,2,5]  R1120     4.6290088444948196e-02
    z[1,2,5]  R1121     -2.1705435216426849e-01
    z[1,2,5]  R1122     1.8041309714317322e-01
    z[1,2,5]  R1123     -1.0834795981645584e-01
    z[1,2,5]  R1124     -2.4197725579142570e-02
    z[1,2,5]  R1125     -6.0347881168127060e-02
    z[1,2,5]  R1126     1.8821948766708374e-01
    z[1,2,5]  R1127     -4.2746751569211483e-03
    z[1,2,5]  R1128     -3.6321040987968445e-01
    z[1,2,5]  R1129     2.9662764072418213e-01
    z[1,2,5]  R1130     3.8539204001426697e-01
    z[1,2,5]  R1131     4.2010742425918579e-01
    z[1,2,5]  R1132     -2.9041895270347595e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R1011     -1
    z[1,2,6]  R1012     1
    z[1,2,6]  R1013     2.9033901169896126e-02
    z[1,2,6]  R1014     4.0269076824188232e-01
    z[1,2,6]  R1015     -2.5250702165067196e-03
    z[1,2,6]  R1016     4.6675089001655579e-01
    z[1,2,6]  R1017     3.4391921758651733e-01
    z[1,2,6]  R1018     -3.5764020681381226e-01
    z[1,2,6]  R1019     -3.6626964807510376e-01
    z[1,2,6]  R1020     4.8786246776580811e-01
    z[1,2,6]  R1021     -2.3331686854362488e-01
    z[1,2,6]  R1022     -1.6823986172676086e-01
    z[1,2,6]  R1023     -6.6091649234294891e-02
    z[1,2,6]  R1024     -3.2455231994390488e-02
    z[1,2,6]  R1025     2.8705042600631714e-01
    z[1,2,6]  R1026     -2.2222459316253662e-01
    z[1,2,6]  R1027     -1.4257307350635529e-01
    z[1,2,6]  R1028     -0.0975661426782608
    z[1,2,6]  R1029     1.2624484300613403e-01
    z[1,2,6]  R1030     1.5527017414569855e-01
    z[1,2,6]  R1031     0.258098304271698
    z[1,2,6]  R1032     3.3507046103477478e-01
    z[1,2,6]  R1033     5.1464933156967163e-01
    z[1,2,6]  R1034     2.4968293309211731e-01
    z[1,2,6]  R1035     9.3214483931660652e-03
    z[1,2,6]  R1036     3.3698195219039917e-01
    z[1,2,6]  R1037     3.4815050661563873e-02
    z[1,2,6]  R1038     -1.7313238978385925e-01
    z[1,2,6]  R1039     -2.4636309593915939e-02
    z[1,2,6]  R1040     -2.0133270323276520e-01
    z[1,2,6]  R1041     7.3934487998485565e-02
    z[1,2,6]  R1042     -1.8456031382083893e-01
    z[1,2,6]  R1043     -2.1386298537254333e-01
    z[1,2,6]  R1044     1.8342237174510956e-01
    z[1,2,6]  R1045     4.3450701236724854e-01
    z[1,2,6]  R1046     1.5843538939952850e-01
    z[1,2,6]  R1047     2.4175839498639107e-02
    z[1,2,6]  R1048     -7.6298236846923828e-01
    z[1,2,6]  R1049     -6.7152345180511475e-01
    z[1,2,6]  R1050     -1.6806390881538391e-01
    z[1,2,6]  R1051     1.2550490908324718e-02
    z[1,2,6]  R1052     -2.9177930951118469e-01
    z[1,2,6]  R1053     1.5630675852298737e-01
    z[1,2,6]  R1054     3.8100153207778931e-01
    z[1,2,6]  R1055     -0.298606812953949
    z[1,2,6]  R1056     -6.7481301724910736e-02
    z[1,2,6]  R1057     4.2612645030021667e-01
    z[1,2,6]  R1058     -7.9563081264495850e-01
    z[1,2,6]  R1059     -8.4395474195480347e-01
    z[1,2,6]  R1060     -4.5136049389839172e-01
    z[1,2,6]  R1061     7.3453408479690552e-01
    z[1,2,6]  R1062     -4.8163527250289917e-01
    z[1,2,6]  R1063     4.9647635221481323e-01
    z[1,2,6]  R1064     -2.4195753037929535e-01
    z[1,2,6]  R1065     -6.6734445095062256e-01
    z[1,2,6]  R1066     -9.9828787147998810e-02
    z[1,2,6]  R1067     -1.2361995875835419e-01
    z[1,2,6]  R1068     -5.6591433286666870e-01
    z[1,2,6]  R1069     -4.8089297488331795e-03
    z[1,2,6]  R1070     7.5726640224456787e-01
    z[1,2,6]  R1071     -0.248578742146492
    z[1,2,6]  R1072     4.6707659959793091e-02
    z[1,2,6]  R1073     -1.9116099178791046e-01
    z[1,2,6]  R1074     -2.8267496824264526e-01
    z[1,2,6]  R1075     1.1737269163131714e-01
    z[1,2,6]  R1076     -1.6705824434757233e-01
    z[1,2,6]  R1077     -2.3493103682994843e-01
    z[1,2,6]  R1078     -3.7678858637809753e-01
    z[1,2,6]  R1079     4.0877026319503784e-01
    z[1,2,6]  R1080     -1.1880979686975479e-01
    z[1,2,6]  R1081     5.8983471244573593e-02
    z[1,2,6]  R1082     -5.6204688549041748e-01
    z[1,2,6]  R1083     3.2145938277244568e-01
    z[1,2,6]  R1084     -2.1052356064319611e-01
    z[1,2,6]  R1085     -9.2820391058921814e-02
    z[1,2,6]  R1086     -2.5066909193992615e-01
    z[1,2,6]  R1087     2.9441300034523010e-01
    z[1,2,6]  R1088     -6.3016250729560852e-02
    z[1,2,6]  R1089     -4.6255189180374146e-01
    z[1,2,6]  R1090     -2.6806166395545006e-02
    z[1,2,6]  R1091     -1.4414816163480282e-02
    z[1,2,6]  R1092     1.2441301345825195e-01
    z[1,2,6]  R1093     7.5026132166385651e-02
    z[1,2,6]  R1094     2.2135600447654724e-01
    z[1,2,6]  R1095     -6.8161681294441223e-02
    z[1,2,6]  R1096     1.3272415101528168e-01
    z[1,2,6]  R1097     -5.1599580049514771e-01
    z[1,2,6]  R1098     1.3522616028785706e-01
    z[1,2,6]  R1099     3.6488026380538940e-02
    z[1,2,6]  R1100     -3.7991631776094437e-02
    z[1,2,6]  R1101     -1.1893206089735031e-01
    z[1,2,6]  R1102     1.5725551545619965e-01
    z[1,2,6]  R1103     2.1866075694561005e-01
    z[1,2,6]  R1104     -3.8761323690414429e-01
    z[1,2,6]  R1105     2.4217674136161804e-01
    z[1,2,6]  R1106     0.00902604591101408
    z[1,2,6]  R1107     -1.5060876309871674e-01
    z[1,2,6]  R1108     4.7983929514884949e-02
    z[1,2,6]  R1109     8.1237822771072388e-01
    z[1,2,6]  R1110     -1.0642854869365692e-01
    z[1,2,6]  R1111     -2.7126178145408630e-01
    z[1,2,6]  R1112     0.0654611811041832
    z[1,2,6]  R1113     1.5254659950733185e-01
    z[1,2,6]  R1114     6.1572317034006119e-02
    z[1,2,6]  R1115     -2.3658032715320587e-01
    z[1,2,6]  R1116     -1.8264366686344147e-01
    z[1,2,6]  R1117     2.8202015161514282e-01
    z[1,2,6]  R1118     -2.0516102015972137e-01
    z[1,2,6]  R1119     1.2811851501464844e-01
    z[1,2,6]  R1120     -1.0361919552087784e-01
    z[1,2,6]  R1121     -3.0073219537734985e-01
    z[1,2,6]  R1122     -7.0464448072016239e-03
    z[1,2,6]  R1123     6.3782729208469391e-02
    z[1,2,6]  R1124     -1.9276943057775497e-02
    z[1,2,6]  R1125     1.1413117498159409e-01
    z[1,2,6]  R1126     -0.173413947224617
    z[1,2,6]  R1127     -3.1147781759500504e-02
    z[1,2,6]  R1128     9.3287557363510132e-02
    z[1,2,6]  R1129     -3.9194661378860474e-01
    z[1,2,6]  R1130     -2.3904305696487427e-01
    z[1,2,6]  R1131     -3.7199463695287704e-03
    z[1,2,6]  R1132     2.0976182818412781e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R1133     -1
    z[2,1,0]  R1134     1
    z[2,1,0]  R1147     2.0851935446262360e-01
    z[2,1,0]  R1148     -1.5403975732624531e-02
    z[2,1,0]  R1149     3.5964307188987732e-01
    z[2,1,0]  R1150     2.5737184286117554e-01
    z[2,1,0]  R1151     -5.0401753187179565e-01
    z[2,1,0]  R1152     5.0322896242141724e-01
    z[2,1,0]  R1153     -2.0297326147556305e-01
    z[2,1,0]  R1154     -4.4124320149421692e-01
    z[2,1,0]  R1155     -4.2562133073806763e-01
    z[2,1,0]  R1156     -4.1262978315353394e-01
    z[2,1,0]  R1157     -8.6052364110946655e-01
    z[2,1,0]  R1158     -5.6854259967803955e-01
    z[2,1,0]  R1159     -7.7454006671905518e-01
    z[2,1,0]  R1160     -6.5631330013275146e-01
    z[2,1,0]  R1161     -6.3293945789337158e-01
    z[2,1,0]  R1162     3.4924343228340149e-01
    z[2,1,0]  R1163     2.7462828159332275e-01
    z[2,1,0]  R1164     5.4640930891036987e-01
    z[2,1,0]  R1165     0.637653648853302
    z[2,1,0]  R1166     6.7432254552841187e-01
    z[2,1,0]  R1167     2.8271627426147461e-01
    z[2,1,0]  R1168     5.7072299718856812e-01
    z[2,1,0]  R1169     5.4416990280151367e-01
    z[2,1,0]  R1170     4.5737496018409729e-01
    z[2,1,0]  R1171     5.2685087919235229e-01
    z[2,1,0]  R1172     5.9256774187088013e-01
    z[2,1,0]  R1173     5.1349717378616333e-01
    z[2,1,0]  R1174     4.4690340757369995e-01
    z[2,1,0]  R1175     5.3048992156982422e-01
    z[2,1,0]  R1176     5.3112769126892090e-01
    z[2,1,0]  R1177     4.4048145413398743e-01
    z[2,1,0]  R1178     4.4716534018516541e-01
    z[2,1,0]  R1179     3.1553784012794495e-01
    z[2,1,0]  R1180     2.1296481788158417e-01
    z[2,1,0]  R1181     2.0398156344890594e-01
    z[2,1,0]  R1182     1.4513950049877167e-01
    z[2,1,0]  R1183     4.2035266757011414e-01
    z[2,1,0]  R1184     1.8896244466304779e-01
    z[2,1,0]  R1185     2.6948067545890808e-01
    z[2,1,0]  R1186     5.3773349523544312e-01
    z[2,1,0]  R1187     -8.8005030155181885e-01
    z[2,1,0]  R1188     -8.4766268730163574e-01
    z[2,1,0]  R1189     -8.9489394426345825e-01
    z[2,1,0]  R1190     5.6491714715957642e-01
    z[2,1,0]  R1191     6.4999121427536011e-01
    z[2,1,0]  R1192     5.7755821943283081e-01
    z[2,1,0]  R1193     1.8908669054508209e-01
    z[2,1,0]  R1194     6.9569748640060425e-01
    z[2,1,0]  R1195     5.9627151489257812e-01
    z[2,1,0]  R1196     5.2757942676544189e-01
    z[2,1,0]  R1197     -3.5752275586128235e-01
    z[2,1,0]  R1198     -2.9642897844314575e-01
    z[2,1,0]  R1199     -6.3600605726242065e-01
    z[2,1,0]  R1200     -3.5773396492004395e-01
    z[2,1,0]  R1201     -1.8340660631656647e-01
    z[2,1,0]  R1202     -3.7775182723999023e-01
    z[2,1,0]  R1203     -3.4659394621849060e-01
    z[2,1,0]  R1204     6.2411874532699585e-02
    z[2,1,0]  R1205     4.5564625412225723e-02
    z[2,1,0]  R1206     -5.1198780536651611e-01
    z[2,1,0]  R1207     -4.8201125860214233e-01
    z[2,1,0]  R1208     -5.8650255203247070e-01
    z[2,1,0]  R1209     -4.3368390202522278e-01
    z[2,1,0]  R1210     -7.5530534982681274e-01
    z[2,1,0]  R1211     0.0590699128806591
    z[2,1,0]  R1212     -3.6986050009727478e-01
    z[2,1,0]  R1213     1.0634465515613556e-01
    z[2,1,0]  R1214     4.4743397831916809e-01
    z[2,1,0]  R1215     1.4682547748088837e-01
    z[2,1,0]  R1216     0.00492557417601347
    z[2,1,0]  R1217     -4.5591101050376892e-01
    z[2,1,0]  R1218     -6.2477695941925049e-01
    z[2,1,0]  R1219     1.2044054269790649e-01
    z[2,1,0]  R1220     2.5214740633964539e-01
    z[2,1,0]  R1221     1.6487506031990051e-01
    z[2,1,0]  R1222     -3.5710880160331726e-01
    z[2,1,0]  R1223     -2.3909138143062592e-01
    z[2,1,0]  R1224     -4.0107741951942444e-01
    z[2,1,0]  R1225     -2.8470501303672791e-01
    z[2,1,0]  R1226     6.0285080224275589e-02
    z[2,1,0]  R1227     -4.5614802837371826e-01
    z[2,1,0]  R1228     1.6883884370326996e-01
    z[2,1,0]  R1229     -5.7301348447799683e-01
    z[2,1,0]  R1230     -6.5560430288314819e-01
    z[2,1,0]  R1231     4.6026740223169327e-02
    z[2,1,0]  R1232     5.9459650516510010e-01
    z[2,1,0]  R1233     -8.1936977803707123e-03
    z[2,1,0]  R1234     -2.8132265806198120e-01
    z[2,1,0]  R1235     -3.0873646959662437e-02
    z[2,1,0]  R1236     6.2525354325771332e-02
    z[2,1,0]  R1237     -6.5801465511322021e-01
    z[2,1,0]  R1238     3.9888685941696167e-01
    z[2,1,0]  R1239     -7.6452434062957764e-01
    z[2,1,0]  R1240     7.1891725063323975e-01
    z[2,1,0]  R1241     1.0193198919296265e-01
    z[2,1,0]  R1242     4.0106898546218872e-01
    z[2,1,0]  R1243     -1.0802744328975677e-01
    z[2,1,0]  R1244     -2.2934605181217194e-01
    z[2,1,0]  R1245     -2.3645068705081940e-01
    z[2,1,0]  R1246     -6.9124542176723480e-02
    z[2,1,0]  R1247     -6.0876989364624023e-01
    z[2,1,0]  R1248     -4.0712639689445496e-01
    z[2,1,0]  R1249     -1.0106655955314636e-01
    z[2,1,0]  R1250     -1.8882115185260773e-01
    z[2,1,0]  R1251     3.2330492138862610e-01
    z[2,1,0]  R1252     -1.0135262459516525e-01
    z[2,1,0]  R1253     -2.3631669580936432e-02
    z[2,1,0]  R1254     2.9480382800102234e-02
    z[2,1,0]  R1255     -2.4920843541622162e-01
    z[2,1,0]  R1256     -1.4453461766242981e-01
    z[2,1,0]  R1257     -6.4922505617141724e-01
    z[2,1,0]  R1258     -6.0427713394165039e-01
    z[2,1,0]  R1259     7.9296268522739410e-02
    z[2,1,0]  R1260     5.6043070554733276e-01
    z[2,1,0]  R1261     -5.7753247022628784e-01
    z[2,1,0]  R1262     1.8766084313392639e-01
    z[2,1,0]  R1263     8.5992045700550079e-02
    z[2,1,0]  R1264     2.0371274650096893e-01
    z[2,1,0]  R1265     1.2180276960134506e-01
    z[2,1,0]  R1266     2.2687834501266479e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R1135     -1
    z[2,1,1]  R1136     1
    z[2,1,1]  R1147     5.9952521324157715e-01
    z[2,1,1]  R1148     7.3347389698028564e-01
    z[2,1,1]  R1149     5.4051935672760010e-01
    z[2,1,1]  R1150     7.6075994968414307e-01
    z[2,1,1]  R1151     7.6848263852298260e-03
    z[2,1,1]  R1152     -6.0933738946914673e-01
    z[2,1,1]  R1153     -1.2389837950468063e-01
    z[2,1,1]  R1154     1.5843097865581512e-01
    z[2,1,1]  R1155     6.7712232470512390e-02
    z[2,1,1]  R1156     5.8002066798508167e-03
    z[2,1,1]  R1157     -9.5188491046428680e-02
    z[2,1,1]  R1158     -2.5689724087715149e-01
    z[2,1,1]  R1159     1.6511952504515648e-02
    z[2,1,1]  R1160     1.6391709446907043e-01
    z[2,1,1]  R1161     0.169791579246521
    z[2,1,1]  R1162     0.3975810110569
    z[2,1,1]  R1163     3.8544443249702454e-01
    z[2,1,1]  R1164     -0.354875385761261
    z[2,1,1]  R1165     -3.7354382872581482e-01
    z[2,1,1]  R1166     -1.7746937274932861e-01
    z[2,1,1]  R1167     5.2763038873672485e-01
    z[2,1,1]  R1168     -0.36905637383461
    z[2,1,1]  R1169     -4.2943546175956726e-01
    z[2,1,1]  R1170     -4.2379817366600037e-01
    z[2,1,1]  R1171     -4.1507422924041748e-01
    z[2,1,1]  R1172     -4.2539614439010620e-01
    z[2,1,1]  R1173     -2.7495419979095459e-01
    z[2,1,1]  R1174     -2.7008923888206482e-01
    z[2,1,1]  R1175     -1.9018433988094330e-01
    z[2,1,1]  R1176     -3.8987907767295837e-01
    z[2,1,1]  R1177     7.6852989196777344e-01
    z[2,1,1]  R1178     7.1061855554580688e-01
    z[2,1,1]  R1179     6.9127148389816284e-01
    z[2,1,1]  R1180     6.7748028039932251e-01
    z[2,1,1]  R1181     6.6225379705429077e-01
    z[2,1,1]  R1182     0.657947301864624
    z[2,1,1]  R1183     6.5257954597473145e-01
    z[2,1,1]  R1184     6.5442794561386108e-01
    z[2,1,1]  R1185     6.3109076023101807e-01
    z[2,1,1]  R1186     6.2716007232666016e-01
    z[2,1,1]  R1187     1.3539300300180912e-02
    z[2,1,1]  R1188     -0.0493953637778759
    z[2,1,1]  R1189     -4.1284445673227310e-02
    z[2,1,1]  R1190     -5.1278859376907349e-01
    z[2,1,1]  R1191     -5.4661726951599121e-01
    z[2,1,1]  R1192     -4.9537131190299988e-01
    z[2,1,1]  R1193     -5.5065184831619263e-01
    z[2,1,1]  R1194     -4.6201971173286438e-01
    z[2,1,1]  R1195     -6.0528641939163208e-01
    z[2,1,1]  R1196     -3.8753968477249146e-01
    z[2,1,1]  R1197     2.2777329385280609e-01
    z[2,1,1]  R1198     3.5794261097908020e-01
    z[2,1,1]  R1199     -0.0707663968205452
    z[2,1,1]  R1200     2.1073617041110992e-01
    z[2,1,1]  R1201     2.3412954807281494e-01
    z[2,1,1]  R1202     2.5247669219970703e-01
    z[2,1,1]  R1203     1.3208749890327454e-01
    z[2,1,1]  R1204     6.7550706863403320e-01
    z[2,1,1]  R1205     6.7064303159713745e-01
    z[2,1,1]  R1206     -4.9852974712848663e-02
    z[2,1,1]  R1207     4.2516711354255676e-01
    z[2,1,1]  R1208     2.7613270282745361e-01
    z[2,1,1]  R1209     2.8282597661018372e-01
    z[2,1,1]  R1210     4.4181060791015625e-01
    z[2,1,1]  R1211     -1.9234298169612885e-01
    z[2,1,1]  R1212     1.0171489417552948e-01
    z[2,1,1]  R1213     5.7744336128234863e-01
    z[2,1,1]  R1214     -5.2219372987747192e-01
    z[2,1,1]  R1215     -3.1241990625858307e-02
    z[2,1,1]  R1216     5.3227978944778442e-01
    z[2,1,1]  R1217     3.8184702396392822e-01
    z[2,1,1]  R1218     -2.7537789195775986e-02
    z[2,1,1]  R1219     8.5406959056854248e-01
    z[2,1,1]  R1220     8.1836843490600586e-01
    z[2,1,1]  R1221     2.6267403364181519e-01
    z[2,1,1]  R1222     1.3385763764381409e-01
    z[2,1,1]  R1223     2.5609949231147766e-01
    z[2,1,1]  R1224     8.2399033010005951e-02
    z[2,1,1]  R1225     2.4601301550865173e-01
    z[2,1,1]  R1226     6.1969733238220215e-01
    z[2,1,1]  R1227     4.0898019075393677e-01
    z[2,1,1]  R1228     6.4176046848297119e-01
    z[2,1,1]  R1229     1.0565433651208878e-01
    z[2,1,1]  R1230     1.3106757402420044e-01
    z[2,1,1]  R1231     9.3674689531326294e-01
    z[2,1,1]  R1232     5.0609749555587769e-01
    z[2,1,1]  R1233     4.6355494856834412e-01
    z[2,1,1]  R1234     0.284940242767334
    z[2,1,1]  R1235     2.8398683294653893e-02
    z[2,1,1]  R1236     2.4847318232059479e-01
    z[2,1,1]  R1237     2.6605013012886047e-01
    z[2,1,1]  R1238     8.0469900369644165e-01
    z[2,1,1]  R1239     4.4193947315216064e-01
    z[2,1,1]  R1240     -5.1152259111404419e-01
    z[2,1,1]  R1241     -4.2723175883293152e-01
    z[2,1,1]  R1242     -4.2270788550376892e-01
    z[2,1,1]  R1243     -2.3982043564319611e-01
    z[2,1,1]  R1244     -9.1337114572525024e-01
    z[2,1,1]  R1245     -8.7942677736282349e-01
    z[2,1,1]  R1246     -2.8539735078811646e-01
    z[2,1,1]  R1247     3.4915563464164734e-01
    z[2,1,1]  R1248     3.8095399737358093e-01
    z[2,1,1]  R1249     5.5673009157180786e-01
    z[2,1,1]  R1250     -1.8500310182571411e-01
    z[2,1,1]  R1251     -3.9021816849708557e-01
    z[2,1,1]  R1252     3.8227722048759460e-02
    z[2,1,1]  R1253     -2.0226265490055084e-01
    z[2,1,1]  R1254     5.9279982000589371e-02
    z[2,1,1]  R1255     -0.926781177520752
    z[2,1,1]  R1256     -7.5965744256973267e-01
    z[2,1,1]  R1257     1.5500506758689880e-01
    z[2,1,1]  R1258     7.0526483468711376e-03
    z[2,1,1]  R1259     9.5337331295013428e-01
    z[2,1,1]  R1260     -6.2721198797225952e-01
    z[2,1,1]  R1261     3.7929084897041321e-01
    z[2,1,1]  R1262     -1.0878720879554749e-01
    z[2,1,1]  R1263     -3.3713793754577637e-01
    z[2,1,1]  R1264     -3.9753583073616028e-01
    z[2,1,1]  R1265     -0.273084819316864
    z[2,1,1]  R1266     -3.3717691898345947e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R1137     -1
    z[2,1,2]  R1138     1
    z[2,1,2]  R1147     -4.0175938606262207e-01
    z[2,1,2]  R1148     -0.0754147619009018
    z[2,1,2]  R1149     -5.1272273063659668e-01
    z[2,1,2]  R1150     4.7629281878471375e-02
    z[2,1,2]  R1151     4.2262795567512512e-01
    z[2,1,2]  R1152     -3.9237266778945923e-01
    z[2,1,2]  R1153     0.0480094775557518
    z[2,1,2]  R1154     -3.9981681853532791e-02
    z[2,1,2]  R1155     -5.0601817667484283e-02
    z[2,1,2]  R1156     3.1279647350311279e-01
    z[2,1,2]  R1157     -1.2840218842029572e-01
    z[2,1,2]  R1158     -3.8769415020942688e-01
    z[2,1,2]  R1159     -5.0271785259246826e-01
    z[2,1,2]  R1160     2.7499321103096008e-01
    z[2,1,2]  R1161     3.5533748567104340e-02
    z[2,1,2]  R1162     -4.8125658184289932e-02
    z[2,1,2]  R1163     1.6836115717887878e-01
    z[2,1,2]  R1164     4.5957425236701965e-01
    z[2,1,2]  R1165     3.9908558130264282e-01
    z[2,1,2]  R1166     3.9081260561943054e-01
    z[2,1,2]  R1167     5.9389103204011917e-02
    z[2,1,2]  R1168     0.49821937084198
    z[2,1,2]  R1169     5.1848423480987549e-01
    z[2,1,2]  R1170     6.0682344436645508e-01
    z[2,1,2]  R1171     5.9697711467742920e-01
    z[2,1,2]  R1172     3.2818609476089478e-01
    z[2,1,2]  R1173     4.1627770662307739e-01
    z[2,1,2]  R1174     5.0859099626541138e-01
    z[2,1,2]  R1175     4.5980966091156006e-01
    z[2,1,2]  R1176     2.1257606148719788e-01
    z[2,1,2]  R1177     1.9762471318244934e-01
    z[2,1,2]  R1178     1.8094404041767120e-01
    z[2,1,2]  R1179     1.7155742272734642e-02
    z[2,1,2]  R1180     2.3242124915122986e-01
    z[2,1,2]  R1181     2.0797017216682434e-01
    z[2,1,2]  R1182     3.0362471938133240e-01
    z[2,1,2]  R1183     1.5505865216255188e-01
    z[2,1,2]  R1184     1.7621801793575287e-01
    z[2,1,2]  R1185     1.8051068484783173e-01
    z[2,1,2]  R1186     -1.3206172734498978e-02
    z[2,1,2]  R1187     -6.9564029574394226e-02
    z[2,1,2]  R1188     1.7230573296546936e-01
    z[2,1,2]  R1189     1.7138895392417908e-01
    z[2,1,2]  R1190     -1.4812509715557098e-01
    z[2,1,2]  R1191     -1.6373504698276520e-01
    z[2,1,2]  R1192     -2.1429817378520966e-01
    z[2,1,2]  R1193     -2.5060099363327026e-01
    z[2,1,2]  R1194     -6.6603772342205048e-02
    z[2,1,2]  R1195     4.1931409388780594e-02
    z[2,1,2]  R1196     -1.5611787140369415e-01
    z[2,1,2]  R1197     2.7155104279518127e-01
    z[2,1,2]  R1198     -1.2577632069587708e-01
    z[2,1,2]  R1199     -2.7121728658676147e-01
    z[2,1,2]  R1200     0.0661039724946022
    z[2,1,2]  R1201     -5.5829749908298254e-04
    z[2,1,2]  R1202     -1.6054630279541016e-01
    z[2,1,2]  R1203     1.1115300655364990e-01
    z[2,1,2]  R1204     -0.4558085501194
    z[2,1,2]  R1205     -4.5450708270072937e-01
    z[2,1,2]  R1206     6.2247227877378464e-02
    z[2,1,2]  R1207     4.6318256855010986e-01
    z[2,1,2]  R1208     4.2427086830139160e-01
    z[2,1,2]  R1209     1.3735873997211456e-01
    z[2,1,2]  R1210     -2.5027480721473694e-01
    z[2,1,2]  R1211     1.4518241398036480e-02
    z[2,1,2]  R1212     3.6463406682014465e-01
    z[2,1,2]  R1213     -3.2373934984207153e-01
    z[2,1,2]  R1214     4.8716405034065247e-01
    z[2,1,2]  R1215     3.8003337383270264e-01
    z[2,1,2]  R1216     -1.1138872057199478e-01
    z[2,1,2]  R1217     6.1045867204666138e-01
    z[2,1,2]  R1218     -1.4914770424365997e-01
    z[2,1,2]  R1219     -3.2510453462600708e-01
    z[2,1,2]  R1220     -2.3592798411846161e-01
    z[2,1,2]  R1221     -3.6896771192550659e-01
    z[2,1,2]  R1222     8.4914974868297577e-02
    z[2,1,2]  R1223     2.3748025298118591e-01
    z[2,1,2]  R1224     -4.6754304319620132e-02
    z[2,1,2]  R1225     4.0193051099777222e-01
    z[2,1,2]  R1226     -3.2748410105705261e-01
    z[2,1,2]  R1227     3.2034772634506226e-01
    z[2,1,2]  R1228     3.4528324007987976e-01
    z[2,1,2]  R1229     -9.6078209578990936e-02
    z[2,1,2]  R1230     -2.2535999119281769e-01
    z[2,1,2]  R1231     -2.2950629889965057e-01
    z[2,1,2]  R1232     -1.9488035142421722e-01
    z[2,1,2]  R1233     -1.3908736407756805e-01
    z[2,1,2]  R1234     3.8566029071807861e-01
    z[2,1,2]  R1235     -1.7290504276752472e-01
    z[2,1,2]  R1236     -5.4297423362731934e-01
    z[2,1,2]  R1237     1.8496979773044586e-01
    z[2,1,2]  R1238     -0.244472473859787
    z[2,1,2]  R1239     -2.9634317755699158e-01
    z[2,1,2]  R1240     3.2215365767478943e-01
    z[2,1,2]  R1241     1.1727154999971390e-01
    z[2,1,2]  R1242     5.3423233330249786e-02
    z[2,1,2]  R1243     3.2155385613441467e-01
    z[2,1,2]  R1244     1.3224214315414429e-01
    z[2,1,2]  R1245     1.9594286382198334e-01
    z[2,1,2]  R1246     2.3662203550338745e-01
    z[2,1,2]  R1247     2.2422102093696594e-01
    z[2,1,2]  R1248     4.1424378752708435e-01
    z[2,1,2]  R1249     -4.9048945307731628e-01
    z[2,1,2]  R1250     4.3830013275146484e-01
    z[2,1,2]  R1251     0.417977511882782
    z[2,1,2]  R1252     4.0899294614791870e-01
    z[2,1,2]  R1253     2.4501444399356842e-01
    z[2,1,2]  R1254     -1.8349802494049072e-01
    z[2,1,2]  R1255     1.4926487207412720e-01
    z[2,1,2]  R1256     3.8419011235237122e-01
    z[2,1,2]  R1257     2.4462023377418518e-01
    z[2,1,2]  R1258     -1.4788176119327545e-01
    z[2,1,2]  R1259     -4.7778464853763580e-02
    z[2,1,2]  R1260     1.4802455902099609e-01
    z[2,1,2]  R1261     -4.2650622129440308e-01
    z[2,1,2]  R1262     4.7915931791067123e-03
    z[2,1,2]  R1263     -8.4596776962280273e-01
    z[2,1,2]  R1264     -7.6929843425750732e-01
    z[2,1,2]  R1265     -8.8198131322860718e-01
    z[2,1,2]  R1266     -8.0463838577270508e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R1139     -1
    z[2,1,3]  R1140     1
    z[2,1,3]  R1147     -3.8041961193084717e-01
    z[2,1,3]  R1148     -4.0003478527069092e-01
    z[2,1,3]  R1149     -3.1106692552566528e-01
    z[2,1,3]  R1150     -4.1161969304084778e-01
    z[2,1,3]  R1151     2.6464501023292542e-01
    z[2,1,3]  R1152     -3.0929449200630188e-01
    z[2,1,3]  R1153     3.8125178217887878e-01
    z[2,1,3]  R1154     7.1631860733032227e-01
    z[2,1,3]  R1155     7.1944117546081543e-01
    z[2,1,3]  R1156     3.1913855671882629e-01
    z[2,1,3]  R1157     -9.6025623381137848e-02
    z[2,1,3]  R1158     2.6896673440933228e-01
    z[2,1,3]  R1159     1.9394946098327637e-01
    z[2,1,3]  R1160     1.8569202721118927e-01
    z[2,1,3]  R1161     3.1972801685333252e-01
    z[2,1,3]  R1162     7.7558934688568115e-01
    z[2,1,3]  R1163     6.8880569934844971e-01
    z[2,1,3]  R1164     5.7362580299377441e-01
    z[2,1,3]  R1165     3.9625069499015808e-01
    z[2,1,3]  R1166     5.5744445323944092e-01
    z[2,1,3]  R1167     7.7658736705780029e-01
    z[2,1,3]  R1168     4.8028782010078430e-01
    z[2,1,3]  R1169     3.7779018282890320e-01
    z[2,1,3]  R1170     3.5796162486076355e-01
    z[2,1,3]  R1171     4.1075026988983154e-01
    z[2,1,3]  R1172     3.3119884133338928e-01
    z[2,1,3]  R1173     4.9578070640563965e-01
    z[2,1,3]  R1174     4.5892271399497986e-01
    z[2,1,3]  R1175     5.3256541490554810e-01
    z[2,1,3]  R1176     3.6666208505630493e-01
    z[2,1,3]  R1177     2.4325282871723175e-01
    z[2,1,3]  R1178     -2.9130894690752029e-02
    z[2,1,3]  R1179     -2.5148457288742065e-01
    z[2,1,3]  R1180     1.2540750205516815e-01
    z[2,1,3]  R1181     -6.9350488483905792e-02
    z[2,1,3]  R1182     -2.2384946048259735e-01
    z[2,1,3]  R1183     -1.5611016750335693e-01
    z[2,1,3]  R1184     0.351661741733551
    z[2,1,3]  R1185     -1.9590289890766144e-01
    z[2,1,3]  R1186     -1.4304912090301514e-01
    z[2,1,3]  R1187     2.1276351809501648e-01
    z[2,1,3]  R1188     2.3736884817481041e-02
    z[2,1,3]  R1189     2.3033104836940765e-01
    z[2,1,3]  R1190     -5.3111881017684937e-01
    z[2,1,3]  R1191     -4.1673696041107178e-01
    z[2,1,3]  R1192     -6.0401380062103271e-01
    z[2,1,3]  R1193     -7.1226024627685547e-01
    z[2,1,3]  R1194     -5.0312846899032593e-01
    z[2,1,3]  R1195     -3.5064321756362915e-01
    z[2,1,3]  R1196     -6.3387966156005859e-01
    z[2,1,3]  R1197     -6.4800351858139038e-01
    z[2,1,3]  R1198     -7.8793352842330933e-01
    z[2,1,3]  R1199     -1.7942821979522705e-01
    z[2,1,3]  R1200     -0.599696934223175
    z[2,1,3]  R1201     -9.0880846977233887e-01
    z[2,1,3]  R1202     -0.678071916103363
    z[2,1,3]  R1203     -3.2827010750770569e-01
    z[2,1,3]  R1204     -3.1030055880546570e-01
    z[2,1,3]  R1205     -5.1563370227813721e-01
    z[2,1,3]  R1206     -4.5084246993064880e-01
    z[2,1,3]  R1207     4.4007804989814758e-01
    z[2,1,3]  R1208     3.3346137404441833e-01
    z[2,1,3]  R1209     1.2889523059129715e-02
    z[2,1,3]  R1210     -2.9720512032508850e-01
    z[2,1,3]  R1211     -0.571692705154419
    z[2,1,3]  R1212     -3.4564909338951111e-01
    z[2,1,3]  R1213     -2.9619028791785240e-03
    z[2,1,3]  R1214     2.4839065968990326e-01
    z[2,1,3]  R1215     8.3537089824676514e-01
    z[2,1,3]  R1216     6.5786695480346680e-01
    z[2,1,3]  R1217     -4.3137678503990173e-01
    z[2,1,3]  R1218     -2.2906927764415741e-01
    z[2,1,3]  R1219     -2.2457545623183250e-02
    z[2,1,3]  R1220     -8.8043145835399628e-02
    z[2,1,3]  R1221     -7.6031464338302612e-01
    z[2,1,3]  R1222     -4.3721115589141846e-01
    z[2,1,3]  R1223     -1.2719729542732239e-01
    z[2,1,3]  R1224     -4.4476732611656189e-01
    z[2,1,3]  R1225     2.0254816114902496e-01
    z[2,1,3]  R1226     1.8693853914737701e-01
    z[2,1,3]  R1227     -4.4414305686950684e-01
    z[2,1,3]  R1228     4.7506517171859741e-01
    z[2,1,3]  R1229     -1.5171146392822266e-01
    z[2,1,3]  R1230     -4.6923705935478210e-01
    z[2,1,3]  R1231     2.3001782596111298e-02
    z[2,1,3]  R1232     1.2662726454436779e-02
    z[2,1,3]  R1233     -0.766851007938385
    z[2,1,3]  R1234     1.9679950177669525e-01
    z[2,1,3]  R1235     -8.5443496704101562e-01
    z[2,1,3]  R1236     -7.1599733829498291e-01
    z[2,1,3]  R1237     -0.621579110622406
    z[2,1,3]  R1238     -1.8579454720020294e-01
    z[2,1,3]  R1239     -3.1899437308311462e-01
    z[2,1,3]  R1240     2.7757775783538818e-01
    z[2,1,3]  R1241     -3.3909055590629578e-01
    z[2,1,3]  R1242     1.6180644929409027e-01
    z[2,1,3]  R1243     7.4454855918884277e-01
    z[2,1,3]  R1244     2.3615576326847076e-02
    z[2,1,3]  R1245     -6.1152640730142593e-02
    z[2,1,3]  R1246     6.6606956720352173e-01
    z[2,1,3]  R1247     -2.6376655697822571e-01
    z[2,1,3]  R1248     2.7661317586898804e-01
    z[2,1,3]  R1249     -4.9569407105445862e-01
    z[2,1,3]  R1250     7.1560466289520264e-01
    z[2,1,3]  R1251     1.2439829856157303e-01
    z[2,1,3]  R1252     8.8599252700805664e-01
    z[2,1,3]  R1253     8.0509597063064575e-01
    z[2,1,3]  R1254     9.6395754814147949e-01
    z[2,1,3]  R1255     1.3031853735446930e-01
    z[2,1,3]  R1256     4.5830440521240234e-01
    z[2,1,3]  R1257     2.2185295820236206e-01
    z[2,1,3]  R1258     -3.4237092733383179e-01
    z[2,1,3]  R1259     1.3089454174041748e-01
    z[2,1,3]  R1260     1.9845359027385712e-02
    z[2,1,3]  R1261     -1.9326542317867279e-01
    z[2,1,3]  R1262     -5.7583391666412354e-01
    z[2,1,3]  R1263     0.336665540933609
    z[2,1,3]  R1264     3.8043934106826782e-01
    z[2,1,3]  R1265     3.3475691080093384e-01
    z[2,1,3]  R1266     3.3808118104934692e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R1141     -1
    z[2,1,4]  R1142     1
    z[2,1,4]  R1147     -4.8983284831047058e-01
    z[2,1,4]  R1148     2.7587356045842171e-02
    z[2,1,4]  R1149     3.8253080844879150e-01
    z[2,1,4]  R1150     2.2896544635295868e-01
    z[2,1,4]  R1151     0.61134272813797
    z[2,1,4]  R1152     5.2625991404056549e-02
    z[2,1,4]  R1153     -0.245507150888443
    z[2,1,4]  R1154     -4.7838117927312851e-02
    z[2,1,4]  R1155     -4.5447820425033569e-01
    z[2,1,4]  R1156     -7.2568637132644653e-01
    z[2,1,4]  R1157     -2.4012076854705811e-01
    z[2,1,4]  R1158     -4.1983744502067566e-01
    z[2,1,4]  R1159     -2.0180565118789673e-01
    z[2,1,4]  R1160     -5.9347146749496460e-01
    z[2,1,4]  R1161     -6.8957552313804626e-02
    z[2,1,4]  R1162     -2.2105820477008820e-01
    z[2,1,4]  R1163     -8.8698320090770721e-02
    z[2,1,4]  R1164     -1.4955131709575653e-01
    z[2,1,4]  R1165     -5.1410477608442307e-03
    z[2,1,4]  R1166     1.3310334086418152e-01
    z[2,1,4]  R1167     -1.3876292109489441e-01
    z[2,1,4]  R1168     -2.4128077924251556e-01
    z[2,1,4]  R1169     -3.0206805467605591e-01
    z[2,1,4]  R1170     -2.2211056947708130e-01
    z[2,1,4]  R1171     1.5509857237339020e-01
    z[2,1,4]  R1172     -3.3147913217544556e-01
    z[2,1,4]  R1173     5.0097596831619740e-03
    z[2,1,4]  R1174     2.2887936234474182e-01
    z[2,1,4]  R1175     -1.0418955981731415e-01
    z[2,1,4]  R1176     -5.0786298513412476e-01
    z[2,1,4]  R1177     3.9067290723323822e-02
    z[2,1,4]  R1178     -2.8967443108558655e-01
    z[2,1,4]  R1179     5.9735560417175293e-01
    z[2,1,4]  R1180     1.1907239258289337e-01
    z[2,1,4]  R1181     -2.6911571621894836e-01
    z[2,1,4]  R1182     -4.7039699554443359e-01
    z[2,1,4]  R1183     2.0863448083400726e-01
    z[2,1,4]  R1184     3.7537318468093872e-01
    z[2,1,4]  R1185     -4.9597907066345215e-01
    z[2,1,4]  R1186     0.436262845993042
    z[2,1,4]  R1187     2.0806825160980225e-01
    z[2,1,4]  R1188     -4.7438085079193115e-01
    z[2,1,4]  R1189     -1.6129940748214722e-01
    z[2,1,4]  R1190     -1.7047438025474548e-01
    z[2,1,4]  R1191     1.5612085163593292e-01
    z[2,1,4]  R1192     1.6943825408816338e-02
    z[2,1,4]  R1193     -9.3334801495075226e-03
    z[2,1,4]  R1194     1.4701751992106438e-02
    z[2,1,4]  R1195     2.4286296218633652e-02
    z[2,1,4]  R1196     6.5779253840446472e-02
    z[2,1,4]  R1197     6.7274391651153564e-02
    z[2,1,4]  R1198     -5.7650838047266006e-02
    z[2,1,4]  R1199     2.0311267673969269e-01
    z[2,1,4]  R1200     2.9101410508155823e-01
    z[2,1,4]  R1201     2.6428506243973970e-03
    z[2,1,4]  R1202     2.0727189257740974e-02
    z[2,1,4]  R1203     4.8381105065345764e-01
    z[2,1,4]  R1204     2.1485836803913116e-01
    z[2,1,4]  R1205     1.8651841580867767e-01
    z[2,1,4]  R1206     6.1027181148529053e-01
    z[2,1,4]  R1207     2.7737993001937866e-01
    z[2,1,4]  R1208     3.2691791653633118e-01
    z[2,1,4]  R1209     -3.2753947377204895e-01
    z[2,1,4]  R1210     -1.5371769666671753e-01
    z[2,1,4]  R1211     1.7633976042270660e-01
    z[2,1,4]  R1212     1.0239803791046143e-01
    z[2,1,4]  R1213     2.8421280905604362e-02
    z[2,1,4]  R1214     -1.8215529620647430e-02
    z[2,1,4]  R1215     4.5270342379808426e-02
    z[2,1,4]  R1216     -2.9345223307609558e-01
    z[2,1,4]  R1217     -9.8966039717197418e-02
    z[2,1,4]  R1218     5.8230036497116089e-01
    z[2,1,4]  R1219     -7.7445581555366516e-02
    z[2,1,4]  R1220     5.4957754909992218e-02
    z[2,1,4]  R1221     0.0887366533279419
    z[2,1,4]  R1222     1.2271800637245178e-01
    z[2,1,4]  R1223     1.7630773782730103e-01
    z[2,1,4]  R1224     -2.7799794077873230e-01
    z[2,1,4]  R1225     -2.6498362421989441e-01
    z[2,1,4]  R1226     4.8734968900680542e-01
    z[2,1,4]  R1227     2.7661731839179993e-01
    z[2,1,4]  R1228     -3.4113430976867676e-01
    z[2,1,4]  R1229     0.190584197640419
    z[2,1,4]  R1230     4.2454391717910767e-01
    z[2,1,4]  R1231     6.2954194843769073e-02
    z[2,1,4]  R1232     5.1860720850527287e-03
    z[2,1,4]  R1233     -4.0332680940628052e-01
    z[2,1,4]  R1234     -2.6774457097053528e-01
    z[2,1,4]  R1235     4.1753351688385010e-01
    z[2,1,4]  R1236     2.6212513446807861e-01
    z[2,1,4]  R1237     -1.9029390811920166e-01
    z[2,1,4]  R1238     -1.3608361780643463e-01
    z[2,1,4]  R1239     -6.1558857560157776e-02
    z[2,1,4]  R1240     -6.4338847994804382e-02
    z[2,1,4]  R1241     5.0951063632965088e-01
    z[2,1,4]  R1242     4.8818126320838928e-01
    z[2,1,4]  R1243     2.8009146451950073e-01
    z[2,1,4]  R1244     1.1476716957986355e-02
    z[2,1,4]  R1245     -1.6288541257381439e-01
    z[2,1,4]  R1246     -2.3661302030086517e-01
    z[2,1,4]  R1247     -2.9888426885008812e-02
    z[2,1,4]  R1248     -5.2529531717300415e-01
    z[2,1,4]  R1249     1.1386800557374954e-01
    z[2,1,4]  R1250     -2.6716282963752747e-01
    z[2,1,4]  R1251     2.3903135955333710e-01
    z[2,1,4]  R1252     1.6486936807632446e-01
    z[2,1,4]  R1253     5.1504410803318024e-02
    z[2,1,4]  R1254     1.4756634831428528e-01
    z[2,1,4]  R1255     1.8596661090850830e-01
    z[2,1,4]  R1256     1.2414073944091797e-01
    z[2,1,4]  R1257     -4.9323442578315735e-01
    z[2,1,4]  R1258     3.7036576867103577e-01
    z[2,1,4]  R1259     -2.0263580977916718e-01
    z[2,1,4]  R1260     0.294387549161911
    z[2,1,4]  R1261     2.8524341061711311e-02
    z[2,1,4]  R1262     -7.0917648077011108e-01
    z[2,1,4]  R1263     1.6378301382064819e-01
    z[2,1,4]  R1264     -2.4107404053211212e-01
    z[2,1,4]  R1265     -0.0662151351571083
    z[2,1,4]  R1266     -2.0259568095207214e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R1143     -1
    z[2,1,5]  R1144     1
    z[2,1,5]  R1147     5.6663446128368378e-02
    z[2,1,5]  R1148     -3.8086524605751038e-01
    z[2,1,5]  R1149     -1.1776731908321381e-01
    z[2,1,5]  R1150     3.6166024208068848e-01
    z[2,1,5]  R1151     -3.1754210591316223e-01
    z[2,1,5]  R1152     3.4753009676933289e-01
    z[2,1,5]  R1153     2.7488359808921814e-01
    z[2,1,5]  R1154     5.0187402963638306e-01
    z[2,1,5]  R1155     1.1820279061794281e-01
    z[2,1,5]  R1156     -3.1481122970581055e-01
    z[2,1,5]  R1157     3.7921205163002014e-01
    z[2,1,5]  R1158     -4.5613449811935425e-01
    z[2,1,5]  R1159     1.1303842067718506e-01
    z[2,1,5]  R1160     2.1613454818725586e-01
    z[2,1,5]  R1161     6.1869156360626221e-01
    z[2,1,5]  R1162     -1.5857380628585815e-01
    z[2,1,5]  R1163     -4.9893024563789368e-01
    z[2,1,5]  R1164     4.6290088444948196e-02
    z[2,1,5]  R1165     -2.1705435216426849e-01
    z[2,1,5]  R1166     1.8041309714317322e-01
    z[2,1,5]  R1167     -1.0834795981645584e-01
    z[2,1,5]  R1168     -2.4197725579142570e-02
    z[2,1,5]  R1169     -6.0347881168127060e-02
    z[2,1,5]  R1170     1.8821948766708374e-01
    z[2,1,5]  R1171     -4.2746751569211483e-03
    z[2,1,5]  R1172     -3.6321040987968445e-01
    z[2,1,5]  R1173     2.9662764072418213e-01
    z[2,1,5]  R1174     3.8539204001426697e-01
    z[2,1,5]  R1175     4.2010742425918579e-01
    z[2,1,5]  R1176     -2.9041895270347595e-01
    z[2,1,5]  R1177     3.3873483538627625e-01
    z[2,1,5]  R1178     1.2411311268806458e-01
    z[2,1,5]  R1179     -4.6913441270589828e-02
    z[2,1,5]  R1180     -4.4032388925552368e-01
    z[2,1,5]  R1181     -0.530138373374939
    z[2,1,5]  R1182     2.3358824849128723e-01
    z[2,1,5]  R1183     4.1394233703613281e-01
    z[2,1,5]  R1184     4.8824291676282883e-02
    z[2,1,5]  R1185     -3.9712780714035034e-01
    z[2,1,5]  R1186     2.7972424030303955e-01
    z[2,1,5]  R1187     3.5715565085411072e-01
    z[2,1,5]  R1188     -1.5061445534229279e-01
    z[2,1,5]  R1189     -8.1352427601814270e-02
    z[2,1,5]  R1190     -1.8826331198215485e-01
    z[2,1,5]  R1191     -1.8314327299594879e-01
    z[2,1,5]  R1192     2.1702989935874939e-02
    z[2,1,5]  R1193     -2.7365726232528687e-01
    z[2,1,5]  R1194     1.4367893338203430e-01
    z[2,1,5]  R1195     -2.9355597496032715e-01
    z[2,1,5]  R1196     -1.6940365731716156e-01
    z[2,1,5]  R1197     2.3928731679916382e-01
    z[2,1,5]  R1198     -2.8580215573310852e-01
    z[2,1,5]  R1199     -6.6587787866592407e-01
    z[2,1,5]  R1200     -5.1513540744781494e-01
    z[2,1,5]  R1201     2.9050523042678833e-01
    z[2,1,5]  R1202     -5.2687561511993408e-01
    z[2,1,5]  R1203     -7.1248096227645874e-01
    z[2,1,5]  R1204     -3.8606736063957214e-01
    z[2,1,5]  R1205     1.8828584253787994e-01
    z[2,1,5]  R1206     -3.4893444180488586e-01
    z[2,1,5]  R1207     2.3667345941066742e-01
    z[2,1,5]  R1208     -3.8476511836051941e-01
    z[2,1,5]  R1209     -6.4561265707015991e-01
    z[2,1,5]  R1210     -1.8605917692184448e-01
    z[2,1,5]  R1211     7.7510738372802734e-01
    z[2,1,5]  R1212     -8.8310331106185913e-02
    z[2,1,5]  R1213     -3.1413757801055908e-01
    z[2,1,5]  R1214     4.4666835665702820e-01
    z[2,1,5]  R1215     3.6467710137367249e-01
    z[2,1,5]  R1216     -3.1655681133270264e-01
    z[2,1,5]  R1217     2.3101146519184113e-01
    z[2,1,5]  R1218     -2.2347655892372131e-01
    z[2,1,5]  R1219     -2.3387621343135834e-01
    z[2,1,5]  R1220     -4.4238799810409546e-01
    z[2,1,5]  R1221     1.2042701244354248e-02
    z[2,1,5]  R1222     0.0900174155831337
    z[2,1,5]  R1223     -2.4764549732208252e-01
    z[2,1,5]  R1224     -5.9273451566696167e-01
    z[2,1,5]  R1225     2.1468596160411835e-01
    z[2,1,5]  R1226     2.5821685791015625e-02
    z[2,1,5]  R1227     4.2101528495550156e-02
    z[2,1,5]  R1228     -1.9953294098377228e-01
    z[2,1,5]  R1229     -3.8285022974014282e-01
    z[2,1,5]  R1230     -3.0303534865379333e-01
    z[2,1,5]  R1231     -2.1895058453083038e-01
    z[2,1,5]  R1232     -1.7859362065792084e-01
    z[2,1,5]  R1233     -1.2226261198520660e-01
    z[2,1,5]  R1234     8.4042645990848541e-02
    z[2,1,5]  R1235     4.6469278633594513e-02
    z[2,1,5]  R1236     -2.3661652207374573e-01
    z[2,1,5]  R1237     5.3901232779026031e-02
    z[2,1,5]  R1238     -2.5268737226724625e-02
    z[2,1,5]  R1239     1.1423484981060028e-01
    z[2,1,5]  R1240     9.2856295406818390e-02
    z[2,1,5]  R1241     6.0295450687408447e-01
    z[2,1,5]  R1242     5.0113433599472046e-01
    z[2,1,5]  R1243     1.6589875519275665e-01
    z[2,1,5]  R1244     2.8435957431793213e-01
    z[2,1,5]  R1245     3.1393593549728394e-01
    z[2,1,5]  R1246     2.0554584264755249e-01
    z[2,1,5]  R1247     5.3236478567123413e-01
    z[2,1,5]  R1248     -3.4749662876129150e-01
    z[2,1,5]  R1249     -4.1468435525894165e-01
    z[2,1,5]  R1250     3.0284056067466736e-01
    z[2,1,5]  R1251     0.639694094657898
    z[2,1,5]  R1252     0.0696791484951973
    z[2,1,5]  R1253     1.8360999226570129e-01
    z[2,1,5]  R1254     -1.0117681324481964e-01
    z[2,1,5]  R1255     7.0125319063663483e-02
    z[2,1,5]  R1256     1.1617124080657959e-01
    z[2,1,5]  R1257     4.4329819083213806e-01
    z[2,1,5]  R1258     -5.5636620521545410e-01
    z[2,1,5]  R1259     -1.4024247229099274e-01
    z[2,1,5]  R1260     4.0735453367233276e-01
    z[2,1,5]  R1261     -1.9044749438762665e-01
    z[2,1,5]  R1262     -3.1642335653305054e-01
    z[2,1,5]  R1263     -1.4758719503879547e-01
    z[2,1,5]  R1264     6.5971814095973969e-02
    z[2,1,5]  R1265     -4.5893844217061996e-02
    z[2,1,5]  R1266     8.5568435490131378e-02
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R1145     -1
    z[2,1,6]  R1146     1
    z[2,1,6]  R1147     2.1866075694561005e-01
    z[2,1,6]  R1148     -3.8761323690414429e-01
    z[2,1,6]  R1149     2.4217674136161804e-01
    z[2,1,6]  R1150     0.00902604591101408
    z[2,1,6]  R1151     -1.5060876309871674e-01
    z[2,1,6]  R1152     4.7983929514884949e-02
    z[2,1,6]  R1153     8.1237822771072388e-01
    z[2,1,6]  R1154     -1.0642854869365692e-01
    z[2,1,6]  R1155     -2.7126178145408630e-01
    z[2,1,6]  R1156     0.0654611811041832
    z[2,1,6]  R1157     1.5254659950733185e-01
    z[2,1,6]  R1158     6.1572317034006119e-02
    z[2,1,6]  R1159     -2.3658032715320587e-01
    z[2,1,6]  R1160     -1.8264366686344147e-01
    z[2,1,6]  R1161     2.8202015161514282e-01
    z[2,1,6]  R1162     -2.0516102015972137e-01
    z[2,1,6]  R1163     1.2811851501464844e-01
    z[2,1,6]  R1164     -1.0361919552087784e-01
    z[2,1,6]  R1165     -3.0073219537734985e-01
    z[2,1,6]  R1166     -7.0464448072016239e-03
    z[2,1,6]  R1167     6.3782729208469391e-02
    z[2,1,6]  R1168     -1.9276943057775497e-02
    z[2,1,6]  R1169     1.1413117498159409e-01
    z[2,1,6]  R1170     -0.173413947224617
    z[2,1,6]  R1171     -3.1147781759500504e-02
    z[2,1,6]  R1172     9.3287557363510132e-02
    z[2,1,6]  R1173     -3.9194661378860474e-01
    z[2,1,6]  R1174     -2.3904305696487427e-01
    z[2,1,6]  R1175     -3.7199463695287704e-03
    z[2,1,6]  R1176     2.0976182818412781e-01
    z[2,1,6]  R1177     2.9033901169896126e-02
    z[2,1,6]  R1178     4.0269076824188232e-01
    z[2,1,6]  R1179     -2.5250702165067196e-03
    z[2,1,6]  R1180     4.6675089001655579e-01
    z[2,1,6]  R1181     3.4391921758651733e-01
    z[2,1,6]  R1182     -3.5764020681381226e-01
    z[2,1,6]  R1183     -3.6626964807510376e-01
    z[2,1,6]  R1184     4.8786246776580811e-01
    z[2,1,6]  R1185     -2.3331686854362488e-01
    z[2,1,6]  R1186     -1.6823986172676086e-01
    z[2,1,6]  R1187     -6.6091649234294891e-02
    z[2,1,6]  R1188     -3.2455231994390488e-02
    z[2,1,6]  R1189     2.8705042600631714e-01
    z[2,1,6]  R1190     -2.2222459316253662e-01
    z[2,1,6]  R1191     -1.4257307350635529e-01
    z[2,1,6]  R1192     -0.0975661426782608
    z[2,1,6]  R1193     1.2624484300613403e-01
    z[2,1,6]  R1194     1.5527017414569855e-01
    z[2,1,6]  R1195     0.258098304271698
    z[2,1,6]  R1196     3.3507046103477478e-01
    z[2,1,6]  R1197     5.1464933156967163e-01
    z[2,1,6]  R1198     2.4968293309211731e-01
    z[2,1,6]  R1199     9.3214483931660652e-03
    z[2,1,6]  R1200     3.3698195219039917e-01
    z[2,1,6]  R1201     3.4815050661563873e-02
    z[2,1,6]  R1202     -1.7313238978385925e-01
    z[2,1,6]  R1203     -2.4636309593915939e-02
    z[2,1,6]  R1204     -2.0133270323276520e-01
    z[2,1,6]  R1205     7.3934487998485565e-02
    z[2,1,6]  R1206     -1.8456031382083893e-01
    z[2,1,6]  R1207     -2.1386298537254333e-01
    z[2,1,6]  R1208     1.8342237174510956e-01
    z[2,1,6]  R1209     4.3450701236724854e-01
    z[2,1,6]  R1210     1.5843538939952850e-01
    z[2,1,6]  R1211     2.4175839498639107e-02
    z[2,1,6]  R1212     -7.6298236846923828e-01
    z[2,1,6]  R1213     -6.7152345180511475e-01
    z[2,1,6]  R1214     -1.6806390881538391e-01
    z[2,1,6]  R1215     1.2550490908324718e-02
    z[2,1,6]  R1216     -2.9177930951118469e-01
    z[2,1,6]  R1217     1.5630675852298737e-01
    z[2,1,6]  R1218     3.8100153207778931e-01
    z[2,1,6]  R1219     -0.298606812953949
    z[2,1,6]  R1220     -6.7481301724910736e-02
    z[2,1,6]  R1221     4.2612645030021667e-01
    z[2,1,6]  R1222     -7.9563081264495850e-01
    z[2,1,6]  R1223     -8.4395474195480347e-01
    z[2,1,6]  R1224     -4.5136049389839172e-01
    z[2,1,6]  R1225     7.3453408479690552e-01
    z[2,1,6]  R1226     -4.8163527250289917e-01
    z[2,1,6]  R1227     4.9647635221481323e-01
    z[2,1,6]  R1228     -2.4195753037929535e-01
    z[2,1,6]  R1229     -6.6734445095062256e-01
    z[2,1,6]  R1230     -9.9828787147998810e-02
    z[2,1,6]  R1231     -1.2361995875835419e-01
    z[2,1,6]  R1232     -5.6591433286666870e-01
    z[2,1,6]  R1233     -4.8089297488331795e-03
    z[2,1,6]  R1234     7.5726640224456787e-01
    z[2,1,6]  R1235     -0.248578742146492
    z[2,1,6]  R1236     4.6707659959793091e-02
    z[2,1,6]  R1237     -1.9116099178791046e-01
    z[2,1,6]  R1238     -2.8267496824264526e-01
    z[2,1,6]  R1239     1.1737269163131714e-01
    z[2,1,6]  R1240     -1.6705824434757233e-01
    z[2,1,6]  R1241     -2.3493103682994843e-01
    z[2,1,6]  R1242     -3.7678858637809753e-01
    z[2,1,6]  R1243     4.0877026319503784e-01
    z[2,1,6]  R1244     -1.1880979686975479e-01
    z[2,1,6]  R1245     5.8983471244573593e-02
    z[2,1,6]  R1246     -5.6204688549041748e-01
    z[2,1,6]  R1247     3.2145938277244568e-01
    z[2,1,6]  R1248     -2.1052356064319611e-01
    z[2,1,6]  R1249     -9.2820391058921814e-02
    z[2,1,6]  R1250     -2.5066909193992615e-01
    z[2,1,6]  R1251     2.9441300034523010e-01
    z[2,1,6]  R1252     -6.3016250729560852e-02
    z[2,1,6]  R1253     -4.6255189180374146e-01
    z[2,1,6]  R1254     -2.6806166395545006e-02
    z[2,1,6]  R1255     -1.4414816163480282e-02
    z[2,1,6]  R1256     1.2441301345825195e-01
    z[2,1,6]  R1257     7.5026132166385651e-02
    z[2,1,6]  R1258     2.2135600447654724e-01
    z[2,1,6]  R1259     -6.8161681294441223e-02
    z[2,1,6]  R1260     1.3272415101528168e-01
    z[2,1,6]  R1261     -5.1599580049514771e-01
    z[2,1,6]  R1262     1.3522616028785706e-01
    z[2,1,6]  R1263     3.6488026380538940e-02
    z[2,1,6]  R1264     -3.7991631776094437e-02
    z[2,1,6]  R1265     -1.1893206089735031e-01
    z[2,1,6]  R1266     1.5725551545619965e-01
    z[1,3,0]  R11       -1
    z[1,3,0]  R29       1
    z[1,3,0]  R1267     -1
    z[1,3,0]  R1268     1
    z[1,3,0]  R1281     4.4048145413398743e-01
    z[1,3,0]  R1282     4.4716534018516541e-01
    z[1,3,0]  R1283     3.1553784012794495e-01
    z[1,3,0]  R1284     2.1296481788158417e-01
    z[1,3,0]  R1285     2.0398156344890594e-01
    z[1,3,0]  R1286     1.4513950049877167e-01
    z[1,3,0]  R1287     4.2035266757011414e-01
    z[1,3,0]  R1288     1.8896244466304779e-01
    z[1,3,0]  R1289     2.6948067545890808e-01
    z[1,3,0]  R1290     5.3773349523544312e-01
    z[1,3,0]  R1291     -8.8005030155181885e-01
    z[1,3,0]  R1292     -8.4766268730163574e-01
    z[1,3,0]  R1293     -8.9489394426345825e-01
    z[1,3,0]  R1294     5.6491714715957642e-01
    z[1,3,0]  R1295     6.4999121427536011e-01
    z[1,3,0]  R1296     5.7755821943283081e-01
    z[1,3,0]  R1297     1.8908669054508209e-01
    z[1,3,0]  R1298     6.9569748640060425e-01
    z[1,3,0]  R1299     5.9627151489257812e-01
    z[1,3,0]  R1300     5.2757942676544189e-01
    z[1,3,0]  R1301     -3.5752275586128235e-01
    z[1,3,0]  R1302     -2.9642897844314575e-01
    z[1,3,0]  R1303     -6.3600605726242065e-01
    z[1,3,0]  R1304     -3.5773396492004395e-01
    z[1,3,0]  R1305     -1.8340660631656647e-01
    z[1,3,0]  R1306     -3.7775182723999023e-01
    z[1,3,0]  R1307     -3.4659394621849060e-01
    z[1,3,0]  R1308     6.2411874532699585e-02
    z[1,3,0]  R1309     4.5564625412225723e-02
    z[1,3,0]  R1310     -5.1198780536651611e-01
    z[1,3,0]  R1311     -4.8201125860214233e-01
    z[1,3,0]  R1312     -5.8650255203247070e-01
    z[1,3,0]  R1313     -4.3368390202522278e-01
    z[1,3,0]  R1314     -7.5530534982681274e-01
    z[1,3,0]  R1315     0.0590699128806591
    z[1,3,0]  R1316     -3.6986050009727478e-01
    z[1,3,0]  R1317     1.0634465515613556e-01
    z[1,3,0]  R1318     4.4743397831916809e-01
    z[1,3,0]  R1319     1.4682547748088837e-01
    z[1,3,0]  R1320     0.00492557417601347
    z[1,3,0]  R1321     -4.5591101050376892e-01
    z[1,3,0]  R1322     -6.2477695941925049e-01
    z[1,3,0]  R1323     1.2044054269790649e-01
    z[1,3,0]  R1324     2.5214740633964539e-01
    z[1,3,0]  R1325     1.6487506031990051e-01
    z[1,3,0]  R1326     -3.5710880160331726e-01
    z[1,3,0]  R1327     -2.3909138143062592e-01
    z[1,3,0]  R1328     -4.0107741951942444e-01
    z[1,3,0]  R1329     -2.8470501303672791e-01
    z[1,3,0]  R1330     6.0285080224275589e-02
    z[1,3,0]  R1331     -4.5614802837371826e-01
    z[1,3,0]  R1332     1.6883884370326996e-01
    z[1,3,0]  R1333     -5.7301348447799683e-01
    z[1,3,0]  R1334     -6.5560430288314819e-01
    z[1,3,0]  R1335     4.6026740223169327e-02
    z[1,3,0]  R1336     5.9459650516510010e-01
    z[1,3,0]  R1337     -8.1936977803707123e-03
    z[1,3,0]  R1338     -2.8132265806198120e-01
    z[1,3,0]  R1339     -3.0873646959662437e-02
    z[1,3,0]  R1340     6.2525354325771332e-02
    z[1,3,0]  R1341     -6.5801465511322021e-01
    z[1,3,0]  R1342     3.9888685941696167e-01
    z[1,3,0]  R1343     -7.6452434062957764e-01
    z[1,3,0]  R1344     7.1891725063323975e-01
    z[1,3,0]  R1345     1.0193198919296265e-01
    z[1,3,0]  R1346     4.0106898546218872e-01
    z[1,3,0]  R1347     -1.0802744328975677e-01
    z[1,3,0]  R1348     -2.2934605181217194e-01
    z[1,3,0]  R1349     -2.3645068705081940e-01
    z[1,3,0]  R1350     -6.9124542176723480e-02
    z[1,3,0]  R1351     -6.0876989364624023e-01
    z[1,3,0]  R1352     -4.0712639689445496e-01
    z[1,3,0]  R1353     -1.0106655955314636e-01
    z[1,3,0]  R1354     -1.8882115185260773e-01
    z[1,3,0]  R1355     3.2330492138862610e-01
    z[1,3,0]  R1356     -1.0135262459516525e-01
    z[1,3,0]  R1357     -2.3631669580936432e-02
    z[1,3,0]  R1358     2.9480382800102234e-02
    z[1,3,0]  R1359     -2.4920843541622162e-01
    z[1,3,0]  R1360     -1.4453461766242981e-01
    z[1,3,0]  R1361     -6.4922505617141724e-01
    z[1,3,0]  R1362     -6.0427713394165039e-01
    z[1,3,0]  R1363     7.9296268522739410e-02
    z[1,3,0]  R1364     5.6043070554733276e-01
    z[1,3,0]  R1365     -5.7753247022628784e-01
    z[1,3,0]  R1366     1.8766084313392639e-01
    z[1,3,0]  R1367     8.5992045700550079e-02
    z[1,3,0]  R1368     2.0371274650096893e-01
    z[1,3,0]  R1369     1.2180276960134506e-01
    z[1,3,0]  R1370     2.2687834501266479e-01
    z[1,3,0]  R1371     -3.4406775236129761e-01
    z[1,3,0]  R1372     -3.2790100574493408e-01
    z[1,3,0]  R1373     -2.7911195158958435e-01
    z[1,3,0]  R1374     -2.5956231355667114e-01
    z[1,3,0]  R1375     -0.389911025762558
    z[1,3,0]  R1376     -0.200189471244812
    z[1,3,0]  R1377     -2.5247624516487122e-01
    z[1,3,0]  R1378     7.9031985998153687e-01
    z[1,3,0]  R1379     8.8028162717819214e-01
    z[1,3,0]  R1380     8.6288440227508545e-01
    z[1,3,0]  R1381     -5.6515991687774658e-01
    z[1,3,0]  R1382     -7.2183072566986084e-01
    z[1,3,0]  R1383     -1.0561756044626236e-01
    z[1,3,0]  R1384     9.0281152725219727e-01
    z[1,3,0]  R1385     -5.6377702951431274e-01
    z[1,3,0]  R1386     -4.2510709166526794e-01
    z[1,3,0]  R1387     -3.1426465511322021e-01
    z[1,3,0]  R1388     -0.472042441368103
    z[1,3,0]  R1389     -5.2815198898315430e-01
    z[1,3,0]  R1390     -4.3587875366210938e-01
    z[1,3,0]  R1391     -8.0650782585144043e-01
    z[1,3,0]  R1392     -5.4882502555847168e-01
    z[1,3,0]  R1393     -5.3742176294326782e-01
    z[1,3,0]  R1394     -5.6928426027297974e-01
    z[1,3,0]  R1395     -5.6497520208358765e-01
    z[1,3,0]  R1396     -6.1704134941101074e-01
    z[1,3,0]  R1397     -0.656769335269928
    z[1,3,0]  R1398     -7.2379314899444580e-01
    z[1,3,0]  R1399     -4.4615957140922546e-01
    z[1,3,0]  R1400     -5.2692312002182007e-01
    z[1,3,0]  R1401     -3.8040143251419067e-01
    z[1,3,0]  R1402     -8.1182342767715454e-01
    z[1,3,0]  R1403     -0.684876024723053
    z[1,3,0]  R1404     -5.0133860111236572e-01
    z[1,3,0]  R1405     -5.6957280635833740e-01
    z[1,3,0]  R1406     0.356876015663147
    z[1,3,0]  R1407     8.1507444381713867e-01
    z[1,3,0]  R1408     9.1206395626068115e-01
    z[1,3,0]  R1409     7.6318812370300293e-01
    z[1,3,0]  R1410     8.7414103746414185e-01
    z[1,3,0]  R1411     -5.3127700090408325e-01
    z[1,3,0]  R1412     -3.3868685364723206e-01
    z[1,3,0]  R1413     -3.4689253568649292e-01
    z[1,3,0]  R1414     -0.587253212928772
    z[1,3,0]  R1415     -2.1451064944267273e-01
    z[1,3,0]  R1416     -1.4580808579921722e-01
    z[1,3,0]  R1417     -5.0207239389419556e-01
    z[1,3,0]  R1418     -6.3019603490829468e-01
    z[1,3,0]  R1419     -6.6657543182373047e-01
    z[1,3,0]  R1420     -4.9757176637649536e-01
    z[1,3,0]  R1421     -5.4342097043991089e-01
    z[1,3,0]  R1422     -8.4325426816940308e-01
    z[1,3,0]  R1423     -8.3551156520843506e-01
    z[1,3,0]  R1424     -5.7310348749160767e-01
    z[1,3,0]  R1425     -3.0678653717041016e-01
    z[1,3,0]  R1426     -0.371635377407074
    z[1,3,0]  R1427     -5.5593419075012207e-01
    z[1,3,0]  R1428     4.6494059264659882e-02
    z[1,3,0]  R1429     8.0510163307189941e-01
    z[1,3,0]  R1430     8.6243516206741333e-01
    z[1,3,0]  R1431     6.2239643186330795e-02
    z[1,3,0]  R1432     -7.6600360870361328e-01
    z[1,3,0]  R1433     5.9907469898462296e-02
    z[1,3,0]  R1434     -6.7986255884170532e-01
    z[1,3,0]  R1435     -6.9654667377471924e-01
    z[1,3,0]  R1436     -5.5627793073654175e-01
    z[1,3,0]  R1437     -7.0455557107925415e-01
    z[1,3,0]  R1438     -2.4017766118049622e-02
    z[1,3,0]  R1439     8.6195367574691772e-01
    z[1,3,0]  R1440     8.7085694074630737e-01
    z[1,3,0]  R1441     -4.1222232580184937e-01
    z[1,3,0]  R1442     -3.7235784530639648e-01
    z[1,3,0]  R1443     -2.5136863812804222e-02
    z[1,3,0]  R1444     -7.5712692737579346e-01
    z[1,3,0]  R1445     -5.1961249113082886e-01
    z[1,3,0]  R1446     -1.2179906666278839e-01
    z[1,3,0]  R1447     9.1755294799804688e-01
    z[1,3,0]  R1448     7.9644507169723511e-01
    z[1,3,0]  R1449     0.795567512512207
    z[1,3,0]  R1450     8.2271134853363037e-01
    z[1,3,0]  R1451     -4.8599314689636230e-01
    z[1,3,0]  R1452     -6.6693328320980072e-02
    z[1,3,0]  R1453     -4.7179032117128372e-02
    z[1,3,0]  R1454     -2.1626415848731995e-01
    z[1,3,0]  R1455     -2.4165056645870209e-01
    z[1,3,0]  R1456     -8.7707346677780151e-01
    z[1,3,0]  R1457     -8.2092583179473877e-01
    z[1,3,0]  R1458     3.0467975139617920e-01
    z[1,3,0]  R1459     -7.1975088119506836e-01
    z[1,3,0]  R1460     8.4028869867324829e-01
    z[1,3,1]  R12       -1
    z[1,3,1]  R30       1
    z[1,3,1]  R1269     -1
    z[1,3,1]  R1270     1
    z[1,3,1]  R1281     7.6852989196777344e-01
    z[1,3,1]  R1282     7.1061855554580688e-01
    z[1,3,1]  R1283     6.9127148389816284e-01
    z[1,3,1]  R1284     6.7748028039932251e-01
    z[1,3,1]  R1285     6.6225379705429077e-01
    z[1,3,1]  R1286     0.657947301864624
    z[1,3,1]  R1287     6.5257954597473145e-01
    z[1,3,1]  R1288     6.5442794561386108e-01
    z[1,3,1]  R1289     6.3109076023101807e-01
    z[1,3,1]  R1290     6.2716007232666016e-01
    z[1,3,1]  R1291     1.3539300300180912e-02
    z[1,3,1]  R1292     -0.0493953637778759
    z[1,3,1]  R1293     -4.1284445673227310e-02
    z[1,3,1]  R1294     -5.1278859376907349e-01
    z[1,3,1]  R1295     -5.4661726951599121e-01
    z[1,3,1]  R1296     -4.9537131190299988e-01
    z[1,3,1]  R1297     -5.5065184831619263e-01
    z[1,3,1]  R1298     -4.6201971173286438e-01
    z[1,3,1]  R1299     -6.0528641939163208e-01
    z[1,3,1]  R1300     -3.8753968477249146e-01
    z[1,3,1]  R1301     2.2777329385280609e-01
    z[1,3,1]  R1302     3.5794261097908020e-01
    z[1,3,1]  R1303     -0.0707663968205452
    z[1,3,1]  R1304     2.1073617041110992e-01
    z[1,3,1]  R1305     2.3412954807281494e-01
    z[1,3,1]  R1306     2.5247669219970703e-01
    z[1,3,1]  R1307     1.3208749890327454e-01
    z[1,3,1]  R1308     6.7550706863403320e-01
    z[1,3,1]  R1309     6.7064303159713745e-01
    z[1,3,1]  R1310     -4.9852974712848663e-02
    z[1,3,1]  R1311     4.2516711354255676e-01
    z[1,3,1]  R1312     2.7613270282745361e-01
    z[1,3,1]  R1313     2.8282597661018372e-01
    z[1,3,1]  R1314     4.4181060791015625e-01
    z[1,3,1]  R1315     -1.9234298169612885e-01
    z[1,3,1]  R1316     1.0171489417552948e-01
    z[1,3,1]  R1317     5.7744336128234863e-01
    z[1,3,1]  R1318     -5.2219372987747192e-01
    z[1,3,1]  R1319     -3.1241990625858307e-02
    z[1,3,1]  R1320     5.3227978944778442e-01
    z[1,3,1]  R1321     3.8184702396392822e-01
    z[1,3,1]  R1322     -2.7537789195775986e-02
    z[1,3,1]  R1323     8.5406959056854248e-01
    z[1,3,1]  R1324     8.1836843490600586e-01
    z[1,3,1]  R1325     2.6267403364181519e-01
    z[1,3,1]  R1326     1.3385763764381409e-01
    z[1,3,1]  R1327     2.5609949231147766e-01
    z[1,3,1]  R1328     8.2399033010005951e-02
    z[1,3,1]  R1329     2.4601301550865173e-01
    z[1,3,1]  R1330     6.1969733238220215e-01
    z[1,3,1]  R1331     4.0898019075393677e-01
    z[1,3,1]  R1332     6.4176046848297119e-01
    z[1,3,1]  R1333     1.0565433651208878e-01
    z[1,3,1]  R1334     1.3106757402420044e-01
    z[1,3,1]  R1335     9.3674689531326294e-01
    z[1,3,1]  R1336     5.0609749555587769e-01
    z[1,3,1]  R1337     4.6355494856834412e-01
    z[1,3,1]  R1338     0.284940242767334
    z[1,3,1]  R1339     2.8398683294653893e-02
    z[1,3,1]  R1340     2.4847318232059479e-01
    z[1,3,1]  R1341     2.6605013012886047e-01
    z[1,3,1]  R1342     8.0469900369644165e-01
    z[1,3,1]  R1343     4.4193947315216064e-01
    z[1,3,1]  R1344     -5.1152259111404419e-01
    z[1,3,1]  R1345     -4.2723175883293152e-01
    z[1,3,1]  R1346     -4.2270788550376892e-01
    z[1,3,1]  R1347     -2.3982043564319611e-01
    z[1,3,1]  R1348     -9.1337114572525024e-01
    z[1,3,1]  R1349     -8.7942677736282349e-01
    z[1,3,1]  R1350     -2.8539735078811646e-01
    z[1,3,1]  R1351     3.4915563464164734e-01
    z[1,3,1]  R1352     3.8095399737358093e-01
    z[1,3,1]  R1353     5.5673009157180786e-01
    z[1,3,1]  R1354     -1.8500310182571411e-01
    z[1,3,1]  R1355     -3.9021816849708557e-01
    z[1,3,1]  R1356     3.8227722048759460e-02
    z[1,3,1]  R1357     -2.0226265490055084e-01
    z[1,3,1]  R1358     5.9279982000589371e-02
    z[1,3,1]  R1359     -0.926781177520752
    z[1,3,1]  R1360     -7.5965744256973267e-01
    z[1,3,1]  R1361     1.5500506758689880e-01
    z[1,3,1]  R1362     7.0526483468711376e-03
    z[1,3,1]  R1363     9.5337331295013428e-01
    z[1,3,1]  R1364     -6.2721198797225952e-01
    z[1,3,1]  R1365     3.7929084897041321e-01
    z[1,3,1]  R1366     -1.0878720879554749e-01
    z[1,3,1]  R1367     -3.3713793754577637e-01
    z[1,3,1]  R1368     -3.9753583073616028e-01
    z[1,3,1]  R1369     -0.273084819316864
    z[1,3,1]  R1370     -3.3717691898345947e-01
    z[1,3,1]  R1371     -4.0743622183799744e-01
    z[1,3,1]  R1372     -1.9889074563980103e-01
    z[1,3,1]  R1373     5.7454162836074829e-01
    z[1,3,1]  R1374     1.6744308173656464e-01
    z[1,3,1]  R1375     -3.1165421009063721e-01
    z[1,3,1]  R1376     3.1051808595657349e-01
    z[1,3,1]  R1377     4.2386922240257263e-01
    z[1,3,1]  R1378     -0.0718371719121933
    z[1,3,1]  R1379     -8.9955933392047882e-02
    z[1,3,1]  R1380     5.7048797607421875e-02
    z[1,3,1]  R1381     -1.1104349046945572e-01
    z[1,3,1]  R1382     -1.6461621224880219e-01
    z[1,3,1]  R1383     -4.3762156367301941e-01
    z[1,3,1]  R1384     1.6248683631420135e-01
    z[1,3,1]  R1385     1.1134830117225647e-01
    z[1,3,1]  R1386     -7.3070541024208069e-02
    z[1,3,1]  R1387     9.6246063709259033e-02
    z[1,3,1]  R1388     1.1782778799533844e-01
    z[1,3,1]  R1389     2.7041202783584595e-01
    z[1,3,1]  R1390     -5.4209005832672119e-01
    z[1,3,1]  R1391     3.8884720206260681e-01
    z[1,3,1]  R1392     -3.4910616278648376e-01
    z[1,3,1]  R1393     5.5928987264633179e-01
    z[1,3,1]  R1394     4.4444081187248230e-01
    z[1,3,1]  R1395     0.575400710105896
    z[1,3,1]  R1396     4.9236461520195007e-01
    z[1,3,1]  R1397     3.6707437038421631e-01
    z[1,3,1]  R1398     -0.401419073343277
    z[1,3,1]  R1399     5.9140056371688843e-01
    z[1,3,1]  R1400     1.9477939605712891e-01
    z[1,3,1]  R1401     5.6616431474685669e-01
    z[1,3,1]  R1402     4.7562189400196075e-02
    z[1,3,1]  R1403     2.3031720519065857e-01
    z[1,3,1]  R1404     -1.3365231454372406e-01
    z[1,3,1]  R1405     3.5345628857612610e-02
    z[1,3,1]  R1406     -5.4927694797515869e-01
    z[1,3,1]  R1407     -2.5580203533172607e-01
    z[1,3,1]  R1408     -2.9031846672296524e-02
    z[1,3,1]  R1409     2.1840266883373260e-01
    z[1,3,1]  R1410     1.0058821178972721e-02
    z[1,3,1]  R1411     -4.8622789978981018e-01
    z[1,3,1]  R1412     2.0794808864593506e-01
    z[1,3,1]  R1413     4.7027045488357544e-01
    z[1,3,1]  R1414     -7.0744462311267853e-02
    z[1,3,1]  R1415     -2.3843885958194733e-01
    z[1,3,1]  R1416     -1.1425514519214630e-01
    z[1,3,1]  R1417     -4.8765793442726135e-01
    z[1,3,1]  R1418     -2.7695251628756523e-02
    z[1,3,1]  R1419     -4.5463964343070984e-02
    z[1,3,1]  R1420     3.7216268479824066e-02
    z[1,3,1]  R1421     0.563527524471283
    z[1,3,1]  R1422     2.7319166064262390e-01
    z[1,3,1]  R1423     -1.4385347068309784e-01
    z[1,3,1]  R1424     7.2615332901477814e-03
    z[1,3,1]  R1425     8.1111228466033936e-01
    z[1,3,1]  R1426     3.2436794042587280e-01
    z[1,3,1]  R1427     4.0905106067657471e-01
    z[1,3,1]  R1428     -6.5500330924987793e-01
    z[1,3,1]  R1429     3.4475263953208923e-01
    z[1,3,1]  R1430     1.8451488018035889e-01
    z[1,3,1]  R1431     -3.3994078636169434e-01
    z[1,3,1]  R1432     4.7159090638160706e-01
    z[1,3,1]  R1433     -2.5233197212219238e-01
    z[1,3,1]  R1434     1.8022919073700905e-02
    z[1,3,1]  R1435     0.0539570190012455
    z[1,3,1]  R1436     1.6202329099178314e-01
    z[1,3,1]  R1437     2.8932240605354309e-01
    z[1,3,1]  R1438     -7.3883497714996338e-01
    z[1,3,1]  R1439     -1.1312500573694706e-03
    z[1,3,1]  R1440     2.0633409917354584e-01
    z[1,3,1]  R1441     -0.57985520362854
    z[1,3,1]  R1442     5.2900129556655884e-01
    z[1,3,1]  R1443     -0.422419011592865
    z[1,3,1]  R1444     -3.2618728280067444e-01
    z[1,3,1]  R1445     3.6254149675369263e-01
    z[1,3,1]  R1446     1.5918913483619690e-01
    z[1,3,1]  R1447     9.1630041599273682e-02
    z[1,3,1]  R1448     1.0925793647766113e-01
    z[1,3,1]  R1449     -1.5200471878051758e-01
    z[1,3,1]  R1450     -2.1054264903068542e-01
    z[1,3,1]  R1451     2.1635462343692780e-01
    z[1,3,1]  R1452     -3.5965493321418762e-01
    z[1,3,1]  R1453     -5.1427793502807617e-01
    z[1,3,1]  R1454     -3.7195730209350586e-01
    z[1,3,1]  R1455     -6.8676269054412842e-01
    z[1,3,1]  R1456     1.7070958018302917e-01
    z[1,3,1]  R1457     2.0195762813091278e-01
    z[1,3,1]  R1458     -6.7172354459762573e-01
    z[1,3,1]  R1459     2.9508890584111214e-02
    z[1,3,1]  R1460     2.8312578797340393e-01
    z[1,3,2]  R13       -1
    z[1,3,2]  R31       1
    z[1,3,2]  R1271     -1
    z[1,3,2]  R1272     1
    z[1,3,2]  R1281     1.9762471318244934e-01
    z[1,3,2]  R1282     1.8094404041767120e-01
    z[1,3,2]  R1283     1.7155742272734642e-02
    z[1,3,2]  R1284     2.3242124915122986e-01
    z[1,3,2]  R1285     2.0797017216682434e-01
    z[1,3,2]  R1286     3.0362471938133240e-01
    z[1,3,2]  R1287     1.5505865216255188e-01
    z[1,3,2]  R1288     1.7621801793575287e-01
    z[1,3,2]  R1289     1.8051068484783173e-01
    z[1,3,2]  R1290     -1.3206172734498978e-02
    z[1,3,2]  R1291     -6.9564029574394226e-02
    z[1,3,2]  R1292     1.7230573296546936e-01
    z[1,3,2]  R1293     1.7138895392417908e-01
    z[1,3,2]  R1294     -1.4812509715557098e-01
    z[1,3,2]  R1295     -1.6373504698276520e-01
    z[1,3,2]  R1296     -2.1429817378520966e-01
    z[1,3,2]  R1297     -2.5060099363327026e-01
    z[1,3,2]  R1298     -6.6603772342205048e-02
    z[1,3,2]  R1299     4.1931409388780594e-02
    z[1,3,2]  R1300     -1.5611787140369415e-01
    z[1,3,2]  R1301     2.7155104279518127e-01
    z[1,3,2]  R1302     -1.2577632069587708e-01
    z[1,3,2]  R1303     -2.7121728658676147e-01
    z[1,3,2]  R1304     0.0661039724946022
    z[1,3,2]  R1305     -5.5829749908298254e-04
    z[1,3,2]  R1306     -1.6054630279541016e-01
    z[1,3,2]  R1307     1.1115300655364990e-01
    z[1,3,2]  R1308     -0.4558085501194
    z[1,3,2]  R1309     -4.5450708270072937e-01
    z[1,3,2]  R1310     6.2247227877378464e-02
    z[1,3,2]  R1311     4.6318256855010986e-01
    z[1,3,2]  R1312     4.2427086830139160e-01
    z[1,3,2]  R1313     1.3735873997211456e-01
    z[1,3,2]  R1314     -2.5027480721473694e-01
    z[1,3,2]  R1315     1.4518241398036480e-02
    z[1,3,2]  R1316     3.6463406682014465e-01
    z[1,3,2]  R1317     -3.2373934984207153e-01
    z[1,3,2]  R1318     4.8716405034065247e-01
    z[1,3,2]  R1319     3.8003337383270264e-01
    z[1,3,2]  R1320     -1.1138872057199478e-01
    z[1,3,2]  R1321     6.1045867204666138e-01
    z[1,3,2]  R1322     -1.4914770424365997e-01
    z[1,3,2]  R1323     -3.2510453462600708e-01
    z[1,3,2]  R1324     -2.3592798411846161e-01
    z[1,3,2]  R1325     -3.6896771192550659e-01
    z[1,3,2]  R1326     8.4914974868297577e-02
    z[1,3,2]  R1327     2.3748025298118591e-01
    z[1,3,2]  R1328     -4.6754304319620132e-02
    z[1,3,2]  R1329     4.0193051099777222e-01
    z[1,3,2]  R1330     -3.2748410105705261e-01
    z[1,3,2]  R1331     3.2034772634506226e-01
    z[1,3,2]  R1332     3.4528324007987976e-01
    z[1,3,2]  R1333     -9.6078209578990936e-02
    z[1,3,2]  R1334     -2.2535999119281769e-01
    z[1,3,2]  R1335     -2.2950629889965057e-01
    z[1,3,2]  R1336     -1.9488035142421722e-01
    z[1,3,2]  R1337     -1.3908736407756805e-01
    z[1,3,2]  R1338     3.8566029071807861e-01
    z[1,3,2]  R1339     -1.7290504276752472e-01
    z[1,3,2]  R1340     -5.4297423362731934e-01
    z[1,3,2]  R1341     1.8496979773044586e-01
    z[1,3,2]  R1342     -0.244472473859787
    z[1,3,2]  R1343     -2.9634317755699158e-01
    z[1,3,2]  R1344     3.2215365767478943e-01
    z[1,3,2]  R1345     1.1727154999971390e-01
    z[1,3,2]  R1346     5.3423233330249786e-02
    z[1,3,2]  R1347     3.2155385613441467e-01
    z[1,3,2]  R1348     1.3224214315414429e-01
    z[1,3,2]  R1349     1.9594286382198334e-01
    z[1,3,2]  R1350     2.3662203550338745e-01
    z[1,3,2]  R1351     2.2422102093696594e-01
    z[1,3,2]  R1352     4.1424378752708435e-01
    z[1,3,2]  R1353     -4.9048945307731628e-01
    z[1,3,2]  R1354     4.3830013275146484e-01
    z[1,3,2]  R1355     0.417977511882782
    z[1,3,2]  R1356     4.0899294614791870e-01
    z[1,3,2]  R1357     2.4501444399356842e-01
    z[1,3,2]  R1358     -1.8349802494049072e-01
    z[1,3,2]  R1359     1.4926487207412720e-01
    z[1,3,2]  R1360     3.8419011235237122e-01
    z[1,3,2]  R1361     2.4462023377418518e-01
    z[1,3,2]  R1362     -1.4788176119327545e-01
    z[1,3,2]  R1363     -4.7778464853763580e-02
    z[1,3,2]  R1364     1.4802455902099609e-01
    z[1,3,2]  R1365     -4.2650622129440308e-01
    z[1,3,2]  R1366     4.7915931791067123e-03
    z[1,3,2]  R1367     -8.4596776962280273e-01
    z[1,3,2]  R1368     -7.6929843425750732e-01
    z[1,3,2]  R1369     -8.8198131322860718e-01
    z[1,3,2]  R1370     -8.0463838577270508e-01
    z[1,3,2]  R1371     4.1041958332061768e-01
    z[1,3,2]  R1372     4.8243105411529541e-01
    z[1,3,2]  R1373     1.5083377063274384e-01
    z[1,3,2]  R1374     2.3986802995204926e-01
    z[1,3,2]  R1375     5.3352898359298706e-01
    z[1,3,2]  R1376     -1.8829308450222015e-01
    z[1,3,2]  R1377     -6.2303669750690460e-02
    z[1,3,2]  R1378     -6.2953778542578220e-03
    z[1,3,2]  R1379     -6.2106844037771225e-02
    z[1,3,2]  R1380     2.6103788614273071e-01
    z[1,3,2]  R1381     1.2965458631515503e-01
    z[1,3,2]  R1382     -4.6965414285659790e-01
    z[1,3,2]  R1383     2.0638918876647949e-01
    z[1,3,2]  R1384     1.6082639992237091e-01
    z[1,3,2]  R1385     -6.0505729913711548e-01
    z[1,3,2]  R1386     -7.0326203107833862e-01
    z[1,3,2]  R1387     -8.3815455436706543e-01
    z[1,3,2]  R1388     -6.1573606729507446e-01
    z[1,3,2]  R1389     4.2432656884193420e-01
    z[1,3,2]  R1390     -3.0441206693649292e-01
    z[1,3,2]  R1391     1.5811249613761902e-01
    z[1,3,2]  R1392     0.376202791929245
    z[1,3,2]  R1393     5.0575062632560730e-02
    z[1,3,2]  R1394     2.1942797303199768e-01
    z[1,3,2]  R1395     -4.8627737164497375e-01
    z[1,3,2]  R1396     -3.4369108080863953e-01
    z[1,3,2]  R1397     1.2670375406742096e-01
    z[1,3,2]  R1398     -2.3087514936923981e-01
    z[1,3,2]  R1399     -4.0249493718147278e-01
    z[1,3,2]  R1400     7.9355299472808838e-01
    z[1,3,2]  R1401     -6.2529988586902618e-02
    z[1,3,2]  R1402     -2.4667935073375702e-01
    z[1,3,2]  R1403     -2.9975825548171997e-01
    z[1,3,2]  R1404     -1.9519220292568207e-01
    z[1,3,2]  R1405     -3.2596173882484436e-01
    z[1,3,2]  R1406     5.3519034385681152e-01
    z[1,3,2]  R1407     4.2127409577369690e-01
    z[1,3,2]  R1408     1.2512315809726715e-01
    z[1,3,2]  R1409     3.2611471414566040e-01
    z[1,3,2]  R1410     2.5055831670761108e-01
    z[1,3,2]  R1411     3.1556525826454163e-01
    z[1,3,2]  R1412     -2.1326968073844910e-01
    z[1,3,2]  R1413     -2.4498504400253296e-01
    z[1,3,2]  R1414     9.8096147179603577e-02
    z[1,3,2]  R1415     5.0670439004898071e-01
    z[1,3,2]  R1416     5.9198117256164551e-01
    z[1,3,2]  R1417     -4.0576282143592834e-01
    z[1,3,2]  R1418     -4.5886853337287903e-01
    z[1,3,2]  R1419     -4.3549299240112305e-01
    z[1,3,2]  R1420     -7.1385937929153442e-01
    z[1,3,2]  R1421     -1.5301067614927888e-03
    z[1,3,2]  R1422     -4.0854278206825256e-01
    z[1,3,2]  R1423     2.4864038452506065e-02
    z[1,3,2]  R1424     3.0922656878829002e-02
    z[1,3,2]  R1425     -0.0631827712059021
    z[1,3,2]  R1426     6.1961793899536133e-01
    z[1,3,2]  R1427     -4.2903009057044983e-01
    z[1,3,2]  R1428     1.7989465594291687e-01
    z[1,3,2]  R1429     3.3121243119239807e-01
    z[1,3,2]  R1430     2.1600204706192017e-01
    z[1,3,2]  R1431     6.9001567363739014e-01
    z[1,3,2]  R1432     -2.2462388500571251e-02
    z[1,3,2]  R1433     7.2278487682342529e-01
    z[1,3,2]  R1434     -2.3946358263492584e-01
    z[1,3,2]  R1435     -5.9312063455581665e-01
    z[1,3,2]  R1436     7.0781731605529785e-01
    z[1,3,2]  R1437     1.1221123486757278e-01
    z[1,3,2]  R1438     1.1881493777036667e-01
    z[1,3,2]  R1439     2.9405781626701355e-01
    z[1,3,2]  R1440     -1.0706714354455471e-02
    z[1,3,2]  R1441     2.5668564438819885e-01
    z[1,3,2]  R1442     -3.7382226437330246e-02
    z[1,3,2]  R1443     6.8933749198913574e-01
    z[1,3,2]  R1444     -3.1472650170326233e-01
    z[1,3,2]  R1445     -3.4611481428146362e-01
    z[1,3,2]  R1446     7.3608571290969849e-01
    z[1,3,2]  R1447     3.4660151600837708e-01
    z[1,3,2]  R1448     3.5235700011253357e-01
    z[1,3,2]  R1449     -3.8247801363468170e-02
    z[1,3,2]  R1450     -1.2653575837612152e-01
    z[1,3,2]  R1451     4.0381708741188049e-01
    z[1,3,2]  R1452     6.5360546112060547e-01
    z[1,3,2]  R1453     5.5261862277984619e-01
    z[1,3,2]  R1454     8.4787815809249878e-01
    z[1,3,2]  R1455     1.0278853029012680e-01
    z[1,3,2]  R1456     -1.9657596945762634e-01
    z[1,3,2]  R1457     -1.7647102475166321e-01
    z[1,3,2]  R1458     4.9150779843330383e-01
    z[1,3,2]  R1459     3.6729894578456879e-02
    z[1,3,2]  R1460     -1.0624358803033829e-01
    z[1,3,3]  R14       -1
    z[1,3,3]  R32       1
    z[1,3,3]  R1273     -1
    z[1,3,3]  R1274     1
    z[1,3,3]  R1281     2.4325282871723175e-01
    z[1,3,3]  R1282     -2.9130894690752029e-02
    z[1,3,3]  R1283     -2.5148457288742065e-01
    z[1,3,3]  R1284     1.2540750205516815e-01
    z[1,3,3]  R1285     -6.9350488483905792e-02
    z[1,3,3]  R1286     -2.2384946048259735e-01
    z[1,3,3]  R1287     -1.5611016750335693e-01
    z[1,3,3]  R1288     0.351661741733551
    z[1,3,3]  R1289     -1.9590289890766144e-01
    z[1,3,3]  R1290     -1.4304912090301514e-01
    z[1,3,3]  R1291     2.1276351809501648e-01
    z[1,3,3]  R1292     2.3736884817481041e-02
    z[1,3,3]  R1293     2.3033104836940765e-01
    z[1,3,3]  R1294     -5.3111881017684937e-01
    z[1,3,3]  R1295     -4.1673696041107178e-01
    z[1,3,3]  R1296     -6.0401380062103271e-01
    z[1,3,3]  R1297     -7.1226024627685547e-01
    z[1,3,3]  R1298     -5.0312846899032593e-01
    z[1,3,3]  R1299     -3.5064321756362915e-01
    z[1,3,3]  R1300     -6.3387966156005859e-01
    z[1,3,3]  R1301     -6.4800351858139038e-01
    z[1,3,3]  R1302     -7.8793352842330933e-01
    z[1,3,3]  R1303     -1.7942821979522705e-01
    z[1,3,3]  R1304     -0.599696934223175
    z[1,3,3]  R1305     -9.0880846977233887e-01
    z[1,3,3]  R1306     -0.678071916103363
    z[1,3,3]  R1307     -3.2827010750770569e-01
    z[1,3,3]  R1308     -3.1030055880546570e-01
    z[1,3,3]  R1309     -5.1563370227813721e-01
    z[1,3,3]  R1310     -4.5084246993064880e-01
    z[1,3,3]  R1311     4.4007804989814758e-01
    z[1,3,3]  R1312     3.3346137404441833e-01
    z[1,3,3]  R1313     1.2889523059129715e-02
    z[1,3,3]  R1314     -2.9720512032508850e-01
    z[1,3,3]  R1315     -0.571692705154419
    z[1,3,3]  R1316     -3.4564909338951111e-01
    z[1,3,3]  R1317     -2.9619028791785240e-03
    z[1,3,3]  R1318     2.4839065968990326e-01
    z[1,3,3]  R1319     8.3537089824676514e-01
    z[1,3,3]  R1320     6.5786695480346680e-01
    z[1,3,3]  R1321     -4.3137678503990173e-01
    z[1,3,3]  R1322     -2.2906927764415741e-01
    z[1,3,3]  R1323     -2.2457545623183250e-02
    z[1,3,3]  R1324     -8.8043145835399628e-02
    z[1,3,3]  R1325     -7.6031464338302612e-01
    z[1,3,3]  R1326     -4.3721115589141846e-01
    z[1,3,3]  R1327     -1.2719729542732239e-01
    z[1,3,3]  R1328     -4.4476732611656189e-01
    z[1,3,3]  R1329     2.0254816114902496e-01
    z[1,3,3]  R1330     1.8693853914737701e-01
    z[1,3,3]  R1331     -4.4414305686950684e-01
    z[1,3,3]  R1332     4.7506517171859741e-01
    z[1,3,3]  R1333     -1.5171146392822266e-01
    z[1,3,3]  R1334     -4.6923705935478210e-01
    z[1,3,3]  R1335     2.3001782596111298e-02
    z[1,3,3]  R1336     1.2662726454436779e-02
    z[1,3,3]  R1337     -0.766851007938385
    z[1,3,3]  R1338     1.9679950177669525e-01
    z[1,3,3]  R1339     -8.5443496704101562e-01
    z[1,3,3]  R1340     -7.1599733829498291e-01
    z[1,3,3]  R1341     -0.621579110622406
    z[1,3,3]  R1342     -1.8579454720020294e-01
    z[1,3,3]  R1343     -3.1899437308311462e-01
    z[1,3,3]  R1344     2.7757775783538818e-01
    z[1,3,3]  R1345     -3.3909055590629578e-01
    z[1,3,3]  R1346     1.6180644929409027e-01
    z[1,3,3]  R1347     7.4454855918884277e-01
    z[1,3,3]  R1348     2.3615576326847076e-02
    z[1,3,3]  R1349     -6.1152640730142593e-02
    z[1,3,3]  R1350     6.6606956720352173e-01
    z[1,3,3]  R1351     -2.6376655697822571e-01
    z[1,3,3]  R1352     2.7661317586898804e-01
    z[1,3,3]  R1353     -4.9569407105445862e-01
    z[1,3,3]  R1354     7.1560466289520264e-01
    z[1,3,3]  R1355     1.2439829856157303e-01
    z[1,3,3]  R1356     8.8599252700805664e-01
    z[1,3,3]  R1357     8.0509597063064575e-01
    z[1,3,3]  R1358     9.6395754814147949e-01
    z[1,3,3]  R1359     1.3031853735446930e-01
    z[1,3,3]  R1360     4.5830440521240234e-01
    z[1,3,3]  R1361     2.2185295820236206e-01
    z[1,3,3]  R1362     -3.4237092733383179e-01
    z[1,3,3]  R1363     1.3089454174041748e-01
    z[1,3,3]  R1364     1.9845359027385712e-02
    z[1,3,3]  R1365     -1.9326542317867279e-01
    z[1,3,3]  R1366     -5.7583391666412354e-01
    z[1,3,3]  R1367     0.336665540933609
    z[1,3,3]  R1368     3.8043934106826782e-01
    z[1,3,3]  R1369     3.3475691080093384e-01
    z[1,3,3]  R1370     3.3808118104934692e-01
    z[1,3,3]  R1371     -2.7057039737701416e-01
    z[1,3,3]  R1372     2.2242200374603271e-01
    z[1,3,3]  R1373     -4.8630633950233459e-01
    z[1,3,3]  R1374     -9.0782207250595093e-01
    z[1,3,3]  R1375     -6.0245823860168457e-01
    z[1,3,3]  R1376     -7.7078616619110107e-01
    z[1,3,3]  R1377     -5.7151901721954346e-01
    z[1,3,3]  R1378     -4.4974225759506226e-01
    z[1,3,3]  R1379     -3.3146941661834717e-01
    z[1,3,3]  R1380     -3.7510424852371216e-01
    z[1,3,3]  R1381     3.1618601083755493e-01
    z[1,3,3]  R1382     -1.8194037675857544e-01
    z[1,3,3]  R1383     3.8946425914764404e-01
    z[1,3,3]  R1384     0.081110879778862
    z[1,3,3]  R1385     1.6585490107536316e-01
    z[1,3,3]  R1386     3.3532249927520752e-01
    z[1,3,3]  R1387     2.4041488766670227e-01
    z[1,3,3]  R1388     5.9478312730789185e-01
    z[1,3,3]  R1389     3.0572825670242310e-01
    z[1,3,3]  R1390     -9.2390157282352448e-02
    z[1,3,3]  R1391     -7.5568921864032745e-02
    z[1,3,3]  R1392     -9.7693480551242828e-02
    z[1,3,3]  R1393     -1.7162151634693146e-01
    z[1,3,3]  R1394     -1.2340348213911057e-01
    z[1,3,3]  R1395     -3.6988846957683563e-02
    z[1,3,3]  R1396     -2.4959733709692955e-02
    z[1,3,3]  R1397     -5.6879818439483643e-03
    z[1,3,3]  R1398     4.3359389901161194e-01
    z[1,3,3]  R1399     -1.2845497578382492e-02
    z[1,3,3]  R1400     -1.7646154761314392e-01
    z[1,3,3]  R1401     -4.5771875977516174e-01
    z[1,3,3]  R1402     -4.7059425711631775e-01
    z[1,3,3]  R1403     2.9010131955146790e-01
    z[1,3,3]  R1404     -1.5414546430110931e-01
    z[1,3,3]  R1405     2.8731770813465118e-02
    z[1,3,3]  R1406     5.1945778541266918e-03
    z[1,3,3]  R1407     -0.0582304522395134
    z[1,3,3]  R1408     -2.7886587381362915e-01
    z[1,3,3]  R1409     1.9689889624714851e-02
    z[1,3,3]  R1410     -1.2389860302209854e-01
    z[1,3,3]  R1411     2.3909914493560791e-01
    z[1,3,3]  R1412     -8.3357393741607666e-01
    z[1,3,3]  R1413     -5.2888363599777222e-01
    z[1,3,3]  R1414     -6.7985409498214722e-01
    z[1,3,3]  R1415     6.0640448331832886e-01
    z[1,3,3]  R1416     5.7174468040466309e-01
    z[1,3,3]  R1417     -7.3191873729228973e-02
    z[1,3,3]  R1418     2.1180571615695953e-01
    z[1,3,3]  R1419     -2.2566859424114227e-01
    z[1,3,3]  R1420     -1.3528390228748322e-01
    z[1,3,3]  R1421     -3.4971076250076294e-01
    z[1,3,3]  R1422     -1.2376046925783157e-01
    z[1,3,3]  R1423     -1.3576015830039978e-02
    z[1,3,3]  R1424     -6.5821069478988647e-01
    z[1,3,3]  R1425     -3.2483169436454773e-01
    z[1,3,3]  R1426     -4.0063586831092834e-01
    z[1,3,3]  R1427     3.1285667419433594e-01
    z[1,3,3]  R1428     1.3730789721012115e-01
    z[1,3,3]  R1429     -1.4332598447799683e-01
    z[1,3,3]  R1430     3.1519293785095215e-01
    z[1,3,3]  R1431     -9.5184780657291412e-02
    z[1,3,3]  R1432     2.4369803071022034e-01
    z[1,3,3]  R1433     0.348730206489563
    z[1,3,3]  R1434     0.451188862323761
    z[1,3,3]  R1435     3.3942395448684692e-01
    z[1,3,3]  R1436     -6.7075587809085846e-02
    z[1,3,3]  R1437     1.8302203714847565e-01
    z[1,3,3]  R1438     1.1391800642013550e-01
    z[1,3,3]  R1439     1.4862108230590820e-01
    z[1,3,3]  R1440     -3.2110220193862915e-01
    z[1,3,3]  R1441     4.3260562419891357e-01
    z[1,3,3]  R1442     -6.7774200439453125e-01
    z[1,3,3]  R1443     -4.0927335619926453e-01
    z[1,3,3]  R1444     -1.3049960136413574e-02
    z[1,3,3]  R1445     -0.502071738243103
    z[1,3,3]  R1446     -9.1563336551189423e-02
    z[1,3,3]  R1447     -1.4747790992259979e-01
    z[1,3,3]  R1448     -7.6781474053859711e-02
    z[1,3,3]  R1449     1.6723388433456421e-01
    z[1,3,3]  R1450     1.7311847209930420e-01
    z[1,3,3]  R1451     -7.0427286624908447e-01
    z[1,3,3]  R1452     5.3233772516250610e-01
    z[1,3,3]  R1453     4.6594947576522827e-01
    z[1,3,3]  R1454     -3.8813658058643341e-02
    z[1,3,3]  R1455     -2.1370275318622589e-01
    z[1,3,3]  R1456     2.2169852256774902e-01
    z[1,3,3]  R1457     1.7748758196830750e-02
    z[1,3,3]  R1458     2.0500671863555908e-01
    z[1,3,3]  R1459     -8.5821323096752167e-02
    z[1,3,3]  R1460     1.5121363103389740e-01
    z[1,3,4]  R15       -1
    z[1,3,4]  R33       1
    z[1,3,4]  R1275     -1
    z[1,3,4]  R1276     1
    z[1,3,4]  R1281     3.9067290723323822e-02
    z[1,3,4]  R1282     -2.8967443108558655e-01
    z[1,3,4]  R1283     5.9735560417175293e-01
    z[1,3,4]  R1284     1.1907239258289337e-01
    z[1,3,4]  R1285     -2.6911571621894836e-01
    z[1,3,4]  R1286     -4.7039699554443359e-01
    z[1,3,4]  R1287     2.0863448083400726e-01
    z[1,3,4]  R1288     3.7537318468093872e-01
    z[1,3,4]  R1289     -4.9597907066345215e-01
    z[1,3,4]  R1290     0.436262845993042
    z[1,3,4]  R1291     2.0806825160980225e-01
    z[1,3,4]  R1292     -4.7438085079193115e-01
    z[1,3,4]  R1293     -1.6129940748214722e-01
    z[1,3,4]  R1294     -1.7047438025474548e-01
    z[1,3,4]  R1295     1.5612085163593292e-01
    z[1,3,4]  R1296     1.6943825408816338e-02
    z[1,3,4]  R1297     -9.3334801495075226e-03
    z[1,3,4]  R1298     1.4701751992106438e-02
    z[1,3,4]  R1299     2.4286296218633652e-02
    z[1,3,4]  R1300     6.5779253840446472e-02
    z[1,3,4]  R1301     6.7274391651153564e-02
    z[1,3,4]  R1302     -5.7650838047266006e-02
    z[1,3,4]  R1303     2.0311267673969269e-01
    z[1,3,4]  R1304     2.9101410508155823e-01
    z[1,3,4]  R1305     2.6428506243973970e-03
    z[1,3,4]  R1306     2.0727189257740974e-02
    z[1,3,4]  R1307     4.8381105065345764e-01
    z[1,3,4]  R1308     2.1485836803913116e-01
    z[1,3,4]  R1309     1.8651841580867767e-01
    z[1,3,4]  R1310     6.1027181148529053e-01
    z[1,3,4]  R1311     2.7737993001937866e-01
    z[1,3,4]  R1312     3.2691791653633118e-01
    z[1,3,4]  R1313     -3.2753947377204895e-01
    z[1,3,4]  R1314     -1.5371769666671753e-01
    z[1,3,4]  R1315     1.7633976042270660e-01
    z[1,3,4]  R1316     1.0239803791046143e-01
    z[1,3,4]  R1317     2.8421280905604362e-02
    z[1,3,4]  R1318     -1.8215529620647430e-02
    z[1,3,4]  R1319     4.5270342379808426e-02
    z[1,3,4]  R1320     -2.9345223307609558e-01
    z[1,3,4]  R1321     -9.8966039717197418e-02
    z[1,3,4]  R1322     5.8230036497116089e-01
    z[1,3,4]  R1323     -7.7445581555366516e-02
    z[1,3,4]  R1324     5.4957754909992218e-02
    z[1,3,4]  R1325     0.0887366533279419
    z[1,3,4]  R1326     1.2271800637245178e-01
    z[1,3,4]  R1327     1.7630773782730103e-01
    z[1,3,4]  R1328     -2.7799794077873230e-01
    z[1,3,4]  R1329     -2.6498362421989441e-01
    z[1,3,4]  R1330     4.8734968900680542e-01
    z[1,3,4]  R1331     2.7661731839179993e-01
    z[1,3,4]  R1332     -3.4113430976867676e-01
    z[1,3,4]  R1333     0.190584197640419
    z[1,3,4]  R1334     4.2454391717910767e-01
    z[1,3,4]  R1335     6.2954194843769073e-02
    z[1,3,4]  R1336     5.1860720850527287e-03
    z[1,3,4]  R1337     -4.0332680940628052e-01
    z[1,3,4]  R1338     -2.6774457097053528e-01
    z[1,3,4]  R1339     4.1753351688385010e-01
    z[1,3,4]  R1340     2.6212513446807861e-01
    z[1,3,4]  R1341     -1.9029390811920166e-01
    z[1,3,4]  R1342     -1.3608361780643463e-01
    z[1,3,4]  R1343     -6.1558857560157776e-02
    z[1,3,4]  R1344     -6.4338847994804382e-02
    z[1,3,4]  R1345     5.0951063632965088e-01
    z[1,3,4]  R1346     4.8818126320838928e-01
    z[1,3,4]  R1347     2.8009146451950073e-01
    z[1,3,4]  R1348     1.1476716957986355e-02
    z[1,3,4]  R1349     -1.6288541257381439e-01
    z[1,3,4]  R1350     -2.3661302030086517e-01
    z[1,3,4]  R1351     -2.9888426885008812e-02
    z[1,3,4]  R1352     -5.2529531717300415e-01
    z[1,3,4]  R1353     1.1386800557374954e-01
    z[1,3,4]  R1354     -2.6716282963752747e-01
    z[1,3,4]  R1355     2.3903135955333710e-01
    z[1,3,4]  R1356     1.6486936807632446e-01
    z[1,3,4]  R1357     5.1504410803318024e-02
    z[1,3,4]  R1358     1.4756634831428528e-01
    z[1,3,4]  R1359     1.8596661090850830e-01
    z[1,3,4]  R1360     1.2414073944091797e-01
    z[1,3,4]  R1361     -4.9323442578315735e-01
    z[1,3,4]  R1362     3.7036576867103577e-01
    z[1,3,4]  R1363     -2.0263580977916718e-01
    z[1,3,4]  R1364     0.294387549161911
    z[1,3,4]  R1365     2.8524341061711311e-02
    z[1,3,4]  R1366     -7.0917648077011108e-01
    z[1,3,4]  R1367     1.6378301382064819e-01
    z[1,3,4]  R1368     -2.4107404053211212e-01
    z[1,3,4]  R1369     -0.0662151351571083
    z[1,3,4]  R1370     -2.0259568095207214e-01
    z[1,3,4]  R1371     -4.2647701501846313e-01
    z[1,3,4]  R1372     6.4936959743499756e-01
    z[1,3,4]  R1373     2.0659589767456055e-01
    z[1,3,4]  R1374     1.2071436643600464e-01
    z[1,3,4]  R1375     -2.6310819387435913e-01
    z[1,3,4]  R1376     -2.7697184681892395e-01
    z[1,3,4]  R1377     -6.3517436385154724e-02
    z[1,3,4]  R1378     1.3910956680774689e-01
    z[1,3,4]  R1379     -1.1195933073759079e-01
    z[1,3,4]  R1380     0.00340811675414443
    z[1,3,4]  R1381     2.2796740755438805e-02
    z[1,3,4]  R1382     2.9402857646346092e-02
    z[1,3,4]  R1383     -2.3719245195388794e-01
    z[1,3,4]  R1384     3.0050572752952576e-01
    z[1,3,4]  R1385     2.9327198863029480e-01
    z[1,3,4]  R1386     1.3792613148689270e-01
    z[1,3,4]  R1387     2.5427341461181641e-02
    z[1,3,4]  R1388     0.118742436170578
    z[1,3,4]  R1389     -3.8816636800765991e-01
    z[1,3,4]  R1390     -1.4444314874708652e-02
    z[1,3,4]  R1391     2.9218655824661255e-01
    z[1,3,4]  R1392     1.4821581542491913e-01
    z[1,3,4]  R1393     2.9983353614807129e-01
    z[1,3,4]  R1394     -1.4140526950359344e-01
    z[1,3,4]  R1395     -7.0724025368690491e-02
    z[1,3,4]  R1396     8.9530251920223236e-02
    z[1,3,4]  R1397     -2.9376211762428284e-01
    z[1,3,4]  R1398     -6.6264927387237549e-02
    z[1,3,4]  R1399     -4.9960368871688843e-01
    z[1,3,4]  R1400     4.7424253076314926e-02
    z[1,3,4]  R1401     -5.2696573734283447e-01
    z[1,3,4]  R1402     0.225468710064888
    z[1,3,4]  R1403     5.3126358985900879e-01
    z[1,3,4]  R1404     -0.645107090473175
    z[1,3,4]  R1405     -5.7966804504394531e-01
    z[1,3,4]  R1406     -5.1796585321426392e-01
    z[1,3,4]  R1407     -2.2337383031845093e-01
    z[1,3,4]  R1408     1.0597323998808861e-02
    z[1,3,4]  R1409     -3.5800719261169434e-01
    z[1,3,4]  R1410     -3.9284643530845642e-01
    z[1,3,4]  R1411     -5.3778970241546631e-01
    z[1,3,4]  R1412     1.9459785521030426e-01
    z[1,3,4]  R1413     1.0053319483995438e-01
    z[1,3,4]  R1414     -2.2989268600940704e-01
    z[1,3,4]  R1415     -2.9182881116867065e-01
    z[1,3,4]  R1416     -2.7246505022048950e-01
    z[1,3,4]  R1417     -4.6303052455186844e-02
    z[1,3,4]  R1418     -5.5385154485702515e-01
    z[1,3,4]  R1419     -3.7276622653007507e-01
    z[1,3,4]  R1420     -0.343077689409256
    z[1,3,4]  R1421     4.8305603861808777e-01
    z[1,3,4]  R1422     -1.0203192383050919e-01
    z[1,3,4]  R1423     -0.0925784781575203
    z[1,3,4]  R1424     -1.8663829565048218e-01
    z[1,3,4]  R1425     8.7267801165580750e-02
    z[1,3,4]  R1426     -2.6311576366424561e-01
    z[1,3,4]  R1427     1.6780454665422440e-02
    z[1,3,4]  R1428     2.5766485929489136e-01
    z[1,3,4]  R1429     7.5200520455837250e-02
    z[1,3,4]  R1430     4.6823222190141678e-02
    z[1,3,4]  R1431     5.6598985195159912e-01
    z[1,3,4]  R1432     -3.5769158601760864e-01
    z[1,3,4]  R1433     1.4069169759750366e-01
    z[1,3,4]  R1434     0.452584832906723
    z[1,3,4]  R1435     1.6116510331630707e-01
    z[1,3,4]  R1436     -3.5327225923538208e-01
    z[1,3,4]  R1437     3.8043644279241562e-02
    z[1,3,4]  R1438     -1.6989172995090485e-01
    z[1,3,4]  R1439     -1.8061298131942749e-01
    z[1,3,4]  R1440     -3.0069085955619812e-01
    z[1,3,4]  R1441     2.5757661461830139e-01
    z[1,3,4]  R1442     -3.4258410334587097e-01
    z[1,3,4]  R1443     0.00994244497269392
    z[1,3,4]  R1444     -1.0714717209339142e-01
    z[1,3,4]  R1445     1.4907805621623993e-01
    z[1,3,4]  R1446     4.5438849925994873e-01
    z[1,3,4]  R1447     8.5485167801380157e-02
    z[1,3,4]  R1448     -1.6078485175967216e-02
    z[1,3,4]  R1449     -4.3499547243118286e-01
    z[1,3,4]  R1450     -2.1023973822593689e-01
    z[1,3,4]  R1451     7.9031303524971008e-02
    z[1,3,4]  R1452     1.9675374031066895e-01
    z[1,3,4]  R1453     -2.6867267489433289e-01
    z[1,3,4]  R1454     1.1945463716983795e-02
    z[1,3,4]  R1455     -4.1314724087715149e-01
    z[1,3,4]  R1456     2.9950621537864208e-03
    z[1,3,4]  R1457     -9.5723450183868408e-02
    z[1,3,4]  R1458     -1.4593677222728729e-01
    z[1,3,4]  R1459     -2.2758300602436066e-01
    z[1,3,4]  R1460     -2.9370945692062378e-01
    z[1,3,5]  R16       -1
    z[1,3,5]  R34       1
    z[1,3,5]  R1277     -1
    z[1,3,5]  R1278     1
    z[1,3,5]  R1281     3.3873483538627625e-01
    z[1,3,5]  R1282     1.2411311268806458e-01
    z[1,3,5]  R1283     -4.6913441270589828e-02
    z[1,3,5]  R1284     -4.4032388925552368e-01
    z[1,3,5]  R1285     -0.530138373374939
    z[1,3,5]  R1286     2.3358824849128723e-01
    z[1,3,5]  R1287     4.1394233703613281e-01
    z[1,3,5]  R1288     4.8824291676282883e-02
    z[1,3,5]  R1289     -3.9712780714035034e-01
    z[1,3,5]  R1290     2.7972424030303955e-01
    z[1,3,5]  R1291     3.5715565085411072e-01
    z[1,3,5]  R1292     -1.5061445534229279e-01
    z[1,3,5]  R1293     -8.1352427601814270e-02
    z[1,3,5]  R1294     -1.8826331198215485e-01
    z[1,3,5]  R1295     -1.8314327299594879e-01
    z[1,3,5]  R1296     2.1702989935874939e-02
    z[1,3,5]  R1297     -2.7365726232528687e-01
    z[1,3,5]  R1298     1.4367893338203430e-01
    z[1,3,5]  R1299     -2.9355597496032715e-01
    z[1,3,5]  R1300     -1.6940365731716156e-01
    z[1,3,5]  R1301     2.3928731679916382e-01
    z[1,3,5]  R1302     -2.8580215573310852e-01
    z[1,3,5]  R1303     -6.6587787866592407e-01
    z[1,3,5]  R1304     -5.1513540744781494e-01
    z[1,3,5]  R1305     2.9050523042678833e-01
    z[1,3,5]  R1306     -5.2687561511993408e-01
    z[1,3,5]  R1307     -7.1248096227645874e-01
    z[1,3,5]  R1308     -3.8606736063957214e-01
    z[1,3,5]  R1309     1.8828584253787994e-01
    z[1,3,5]  R1310     -3.4893444180488586e-01
    z[1,3,5]  R1311     2.3667345941066742e-01
    z[1,3,5]  R1312     -3.8476511836051941e-01
    z[1,3,5]  R1313     -6.4561265707015991e-01
    z[1,3,5]  R1314     -1.8605917692184448e-01
    z[1,3,5]  R1315     7.7510738372802734e-01
    z[1,3,5]  R1316     -8.8310331106185913e-02
    z[1,3,5]  R1317     -3.1413757801055908e-01
    z[1,3,5]  R1318     4.4666835665702820e-01
    z[1,3,5]  R1319     3.6467710137367249e-01
    z[1,3,5]  R1320     -3.1655681133270264e-01
    z[1,3,5]  R1321     2.3101146519184113e-01
    z[1,3,5]  R1322     -2.2347655892372131e-01
    z[1,3,5]  R1323     -2.3387621343135834e-01
    z[1,3,5]  R1324     -4.4238799810409546e-01
    z[1,3,5]  R1325     1.2042701244354248e-02
    z[1,3,5]  R1326     0.0900174155831337
    z[1,3,5]  R1327     -2.4764549732208252e-01
    z[1,3,5]  R1328     -5.9273451566696167e-01
    z[1,3,5]  R1329     2.1468596160411835e-01
    z[1,3,5]  R1330     2.5821685791015625e-02
    z[1,3,5]  R1331     4.2101528495550156e-02
    z[1,3,5]  R1332     -1.9953294098377228e-01
    z[1,3,5]  R1333     -3.8285022974014282e-01
    z[1,3,5]  R1334     -3.0303534865379333e-01
    z[1,3,5]  R1335     -2.1895058453083038e-01
    z[1,3,5]  R1336     -1.7859362065792084e-01
    z[1,3,5]  R1337     -1.2226261198520660e-01
    z[1,3,5]  R1338     8.4042645990848541e-02
    z[1,3,5]  R1339     4.6469278633594513e-02
    z[1,3,5]  R1340     -2.3661652207374573e-01
    z[1,3,5]  R1341     5.3901232779026031e-02
    z[1,3,5]  R1342     -2.5268737226724625e-02
    z[1,3,5]  R1343     1.1423484981060028e-01
    z[1,3,5]  R1344     9.2856295406818390e-02
    z[1,3,5]  R1345     6.0295450687408447e-01
    z[1,3,5]  R1346     5.0113433599472046e-01
    z[1,3,5]  R1347     1.6589875519275665e-01
    z[1,3,5]  R1348     2.8435957431793213e-01
    z[1,3,5]  R1349     3.1393593549728394e-01
    z[1,3,5]  R1350     2.0554584264755249e-01
    z[1,3,5]  R1351     5.3236478567123413e-01
    z[1,3,5]  R1352     -3.4749662876129150e-01
    z[1,3,5]  R1353     -4.1468435525894165e-01
    z[1,3,5]  R1354     3.0284056067466736e-01
    z[1,3,5]  R1355     0.639694094657898
    z[1,3,5]  R1356     0.0696791484951973
    z[1,3,5]  R1357     1.8360999226570129e-01
    z[1,3,5]  R1358     -1.0117681324481964e-01
    z[1,3,5]  R1359     7.0125319063663483e-02
    z[1,3,5]  R1360     1.1617124080657959e-01
    z[1,3,5]  R1361     4.4329819083213806e-01
    z[1,3,5]  R1362     -5.5636620521545410e-01
    z[1,3,5]  R1363     -1.4024247229099274e-01
    z[1,3,5]  R1364     4.0735453367233276e-01
    z[1,3,5]  R1365     -1.9044749438762665e-01
    z[1,3,5]  R1366     -3.1642335653305054e-01
    z[1,3,5]  R1367     -1.4758719503879547e-01
    z[1,3,5]  R1368     6.5971814095973969e-02
    z[1,3,5]  R1369     -4.5893844217061996e-02
    z[1,3,5]  R1370     8.5568435490131378e-02
    z[1,3,5]  R1371     -4.3386217951774597e-01
    z[1,3,5]  R1372     -2.1251513063907623e-01
    z[1,3,5]  R1373     -5.0445652008056641e-01
    z[1,3,5]  R1374     -7.6856710016727448e-02
    z[1,3,5]  R1375     -1.6088853776454926e-01
    z[1,3,5]  R1376     2.5028528645634651e-02
    z[1,3,5]  R1377     0.348357617855072
    z[1,3,5]  R1378     -3.7620836496353149e-01
    z[1,3,5]  R1379     -3.0073845386505127e-01
    z[1,3,5]  R1380     -1.9433495402336121e-01
    z[1,3,5]  R1381     3.8035976886749268e-01
    z[1,3,5]  R1382     -4.6719394624233246e-02
    z[1,3,5]  R1383     6.0069918632507324e-01
    z[1,3,5]  R1384     1.8863563239574432e-01
    z[1,3,5]  R1385     4.0948572754859924e-01
    z[1,3,5]  R1386     1.7991185188293457e-01
    z[1,3,5]  R1387     0.0920541062951088
    z[1,3,5]  R1388     1.2588837742805481e-01
    z[1,3,5]  R1389     4.7277545928955078e-01
    z[1,3,5]  R1390     5.9156739711761475e-01
    z[1,3,5]  R1391     -2.3151063919067383e-01
    z[1,3,5]  R1392     0.457425594329834
    z[1,3,5]  R1393     2.0204125344753265e-01
    z[1,3,5]  R1394     0.598791241645813
    z[1,3,5]  R1395     -2.3754674196243286e-01
    z[1,3,5]  R1396     4.9399951100349426e-01
    z[1,3,5]  R1397     3.6819356679916382e-01
    z[1,3,5]  R1398     2.2365932166576385e-01
    z[1,3,5]  R1399     1.4212416112422943e-01
    z[1,3,5]  R1400     -6.7222595214843750e-02
    z[1,3,5]  R1401     -2.0196711644530296e-02
    z[1,3,5]  R1402     -4.8286926001310349e-02
    z[1,3,5]  R1403     -1.3389208912849426e-01
    z[1,3,5]  R1404     2.1183808147907257e-01
    z[1,3,5]  R1405     8.8243380188941956e-02
    z[1,3,5]  R1406     1.2243386358022690e-01
    z[1,3,5]  R1407     2.9019605368375778e-02
    z[1,3,5]  R1408     1.3056750595569611e-01
    z[1,3,5]  R1409     -1.7010171711444855e-01
    z[1,3,5]  R1410     -3.9907835423946381e-02
    z[1,3,5]  R1411     1.8827447667717934e-02
    z[1,3,5]  R1412     -1.8242919445037842e-01
    z[1,3,5]  R1413     -4.0729236602783203e-01
    z[1,3,5]  R1414     1.6880555450916290e-01
    z[1,3,5]  R1415     -4.3299937248229980e-01
    z[1,3,5]  R1416     -3.3952260017395020e-01
    z[1,3,5]  R1417     3.7518686056137085e-01
    z[1,3,5]  R1418     -1.9954627752304077e-01
    z[1,3,5]  R1419     -3.0268070101737976e-01
    z[1,3,5]  R1420     2.9153221845626831e-01
    z[1,3,5]  R1421     1.7578034102916718e-01
    z[1,3,5]  R1422     1.4103178679943085e-01
    z[1,3,5]  R1423     -4.5463374257087708e-01
    z[1,3,5]  R1424     5.9324383735656738e-02
    z[1,3,5]  R1425     -1.2676222622394562e-01
    z[1,3,5]  R1426     5.3338032215833664e-02
    z[1,3,5]  R1427     -8.9633306488394737e-03
    z[1,3,5]  R1428     4.0861195325851440e-01
    z[1,3,5]  R1429     -7.8010559082031250e-02
    z[1,3,5]  R1430     -2.3163343966007233e-01
    z[1,3,5]  R1431     0.273774117231369
    z[1,3,5]  R1432     -5.2762970328330994e-02
    z[1,3,5]  R1433     2.3675620555877686e-01
    z[1,3,5]  R1434     2.2943376004695892e-01
    z[1,3,5]  R1435     7.5764514505863190e-02
    z[1,3,5]  R1436     1.8387521803379059e-01
    z[1,3,5]  R1437     -2.7558884024620056e-01
    z[1,3,5]  R1438     5.9021270275115967e-01
    z[1,3,5]  R1439     2.2301357984542847e-01
    z[1,3,5]  R1440     -7.0829652249813080e-02
    z[1,3,5]  R1441     1.4459949731826782e-01
    z[1,3,5]  R1442     1.5825821086764336e-02
    z[1,3,5]  R1443     3.1916475296020508e-01
    z[1,3,5]  R1444     4.4475227594375610e-01
    z[1,3,5]  R1445     -4.2168667912483215e-01
    z[1,3,5]  R1446     -2.6205161213874817e-01
    z[1,3,5]  R1447     1.1747315526008606e-02
    z[1,3,5]  R1448     -3.8046085834503174e-01
    z[1,3,5]  R1449     -3.9427403360605240e-02
    z[1,3,5]  R1450     2.6306691765785217e-01
    z[1,3,5]  R1451     -1.9467723369598389e-01
    z[1,3,5]  R1452     2.1556799113750458e-01
    z[1,3,5]  R1453     -2.4909430742263794e-01
    z[1,3,5]  R1454     -3.0473336577415466e-01
    z[1,3,5]  R1455     4.8819732666015625e-01
    z[1,3,5]  R1456     -2.2189967334270477e-01
    z[1,3,5]  R1457     -6.8342939019203186e-02
    z[1,3,5]  R1458     3.0620506405830383e-01
    z[1,3,5]  R1459     1.1011601239442825e-01
    z[1,3,5]  R1460     -2.7557021379470825e-01
    z[1,3,6]  R17       -1
    z[1,3,6]  R35       1
    z[1,3,6]  R1279     -1
    z[1,3,6]  R1280     1
    z[1,3,6]  R1281     2.9033901169896126e-02
    z[1,3,6]  R1282     4.0269076824188232e-01
    z[1,3,6]  R1283     -2.5250702165067196e-03
    z[1,3,6]  R1284     4.6675089001655579e-01
    z[1,3,6]  R1285     3.4391921758651733e-01
    z[1,3,6]  R1286     -3.5764020681381226e-01
    z[1,3,6]  R1287     -3.6626964807510376e-01
    z[1,3,6]  R1288     4.8786246776580811e-01
    z[1,3,6]  R1289     -2.3331686854362488e-01
    z[1,3,6]  R1290     -1.6823986172676086e-01
    z[1,3,6]  R1291     -6.6091649234294891e-02
    z[1,3,6]  R1292     -3.2455231994390488e-02
    z[1,3,6]  R1293     2.8705042600631714e-01
    z[1,3,6]  R1294     -2.2222459316253662e-01
    z[1,3,6]  R1295     -1.4257307350635529e-01
    z[1,3,6]  R1296     -0.0975661426782608
    z[1,3,6]  R1297     1.2624484300613403e-01
    z[1,3,6]  R1298     1.5527017414569855e-01
    z[1,3,6]  R1299     0.258098304271698
    z[1,3,6]  R1300     3.3507046103477478e-01
    z[1,3,6]  R1301     5.1464933156967163e-01
    z[1,3,6]  R1302     2.4968293309211731e-01
    z[1,3,6]  R1303     9.3214483931660652e-03
    z[1,3,6]  R1304     3.3698195219039917e-01
    z[1,3,6]  R1305     3.4815050661563873e-02
    z[1,3,6]  R1306     -1.7313238978385925e-01
    z[1,3,6]  R1307     -2.4636309593915939e-02
    z[1,3,6]  R1308     -2.0133270323276520e-01
    z[1,3,6]  R1309     7.3934487998485565e-02
    z[1,3,6]  R1310     -1.8456031382083893e-01
    z[1,3,6]  R1311     -2.1386298537254333e-01
    z[1,3,6]  R1312     1.8342237174510956e-01
    z[1,3,6]  R1313     4.3450701236724854e-01
    z[1,3,6]  R1314     1.5843538939952850e-01
    z[1,3,6]  R1315     2.4175839498639107e-02
    z[1,3,6]  R1316     -7.6298236846923828e-01
    z[1,3,6]  R1317     -6.7152345180511475e-01
    z[1,3,6]  R1318     -1.6806390881538391e-01
    z[1,3,6]  R1319     1.2550490908324718e-02
    z[1,3,6]  R1320     -2.9177930951118469e-01
    z[1,3,6]  R1321     1.5630675852298737e-01
    z[1,3,6]  R1322     3.8100153207778931e-01
    z[1,3,6]  R1323     -0.298606812953949
    z[1,3,6]  R1324     -6.7481301724910736e-02
    z[1,3,6]  R1325     4.2612645030021667e-01
    z[1,3,6]  R1326     -7.9563081264495850e-01
    z[1,3,6]  R1327     -8.4395474195480347e-01
    z[1,3,6]  R1328     -4.5136049389839172e-01
    z[1,3,6]  R1329     7.3453408479690552e-01
    z[1,3,6]  R1330     -4.8163527250289917e-01
    z[1,3,6]  R1331     4.9647635221481323e-01
    z[1,3,6]  R1332     -2.4195753037929535e-01
    z[1,3,6]  R1333     -6.6734445095062256e-01
    z[1,3,6]  R1334     -9.9828787147998810e-02
    z[1,3,6]  R1335     -1.2361995875835419e-01
    z[1,3,6]  R1336     -5.6591433286666870e-01
    z[1,3,6]  R1337     -4.8089297488331795e-03
    z[1,3,6]  R1338     7.5726640224456787e-01
    z[1,3,6]  R1339     -0.248578742146492
    z[1,3,6]  R1340     4.6707659959793091e-02
    z[1,3,6]  R1341     -1.9116099178791046e-01
    z[1,3,6]  R1342     -2.8267496824264526e-01
    z[1,3,6]  R1343     1.1737269163131714e-01
    z[1,3,6]  R1344     -1.6705824434757233e-01
    z[1,3,6]  R1345     -2.3493103682994843e-01
    z[1,3,6]  R1346     -3.7678858637809753e-01
    z[1,3,6]  R1347     4.0877026319503784e-01
    z[1,3,6]  R1348     -1.1880979686975479e-01
    z[1,3,6]  R1349     5.8983471244573593e-02
    z[1,3,6]  R1350     -5.6204688549041748e-01
    z[1,3,6]  R1351     3.2145938277244568e-01
    z[1,3,6]  R1352     -2.1052356064319611e-01
    z[1,3,6]  R1353     -9.2820391058921814e-02
    z[1,3,6]  R1354     -2.5066909193992615e-01
    z[1,3,6]  R1355     2.9441300034523010e-01
    z[1,3,6]  R1356     -6.3016250729560852e-02
    z[1,3,6]  R1357     -4.6255189180374146e-01
    z[1,3,6]  R1358     -2.6806166395545006e-02
    z[1,3,6]  R1359     -1.4414816163480282e-02
    z[1,3,6]  R1360     1.2441301345825195e-01
    z[1,3,6]  R1361     7.5026132166385651e-02
    z[1,3,6]  R1362     2.2135600447654724e-01
    z[1,3,6]  R1363     -6.8161681294441223e-02
    z[1,3,6]  R1364     1.3272415101528168e-01
    z[1,3,6]  R1365     -5.1599580049514771e-01
    z[1,3,6]  R1366     1.3522616028785706e-01
    z[1,3,6]  R1367     3.6488026380538940e-02
    z[1,3,6]  R1368     -3.7991631776094437e-02
    z[1,3,6]  R1369     -1.1893206089735031e-01
    z[1,3,6]  R1370     1.5725551545619965e-01
    z[1,3,6]  R1371     3.2224437594413757e-01
    z[1,3,6]  R1372     3.2228657603263855e-01
    z[1,3,6]  R1373     1.8866769969463348e-01
    z[1,3,6]  R1374     -4.9333442002534866e-02
    z[1,3,6]  R1375     -0.0901155099272728
    z[1,3,6]  R1376     0.395723819732666
    z[1,3,6]  R1377     -5.4834973812103271e-01
    z[1,3,6]  R1378     8.3916939795017242e-02
    z[1,3,6]  R1379     1.7447138205170631e-02
    z[1,3,6]  R1380     -7.4526853859424591e-02
    z[1,3,6]  R1381     -6.3740599155426025e-01
    z[1,3,6]  R1382     0.441743403673172
    z[1,3,6]  R1383     -4.3122348189353943e-01
    z[1,3,6]  R1384     -1.4081505127251148e-02
    z[1,3,6]  R1385     -1.4989298582077026e-01
    z[1,3,6]  R1386     3.9437824487686157e-01
    z[1,3,6]  R1387     3.5007354617118835e-01
    z[1,3,6]  R1388     2.1143538877367973e-02
    z[1,3,6]  R1389     1.4839254319667816e-02
    z[1,3,6]  R1390     2.5452831387519836e-01
    z[1,3,6]  R1391     -1.6930031776428223e-01
    z[1,3,6]  R1392     -4.4117712974548340e-01
    z[1,3,6]  R1393     4.8542764782905579e-01
    z[1,3,6]  R1394     1.9095657765865326e-01
    z[1,3,6]  R1395     -2.2461685538291931e-01
    z[1,3,6]  R1396     -7.7713549137115479e-02
    z[1,3,6]  R1397     4.4267535209655762e-01
    z[1,3,6]  R1398     1.3879722356796265e-01
    z[1,3,6]  R1399     -1.3862450420856476e-01
    z[1,3,6]  R1400     -1.2953819334506989e-01
    z[1,3,6]  R1401     2.0793128013610840e-01
    z[1,3,6]  R1402     5.6596368551254272e-02
    z[1,3,6]  R1403     6.0966953635215759e-02
    z[1,3,6]  R1404     -4.5595744252204895e-01
    z[1,3,6]  R1405     -4.7271448373794556e-01
    z[1,3,6]  R1406     3.4640945494174957e-02
    z[1,3,6]  R1407     1.9651544094085693e-01
    z[1,3,6]  R1408     2.3814779520034790e-01
    z[1,3,6]  R1409     -3.2557934522628784e-01
    z[1,3,6]  R1410     -4.1531622409820557e-02
    z[1,3,6]  R1411     -1.8709658086299896e-01
    z[1,3,6]  R1412     1.7484484612941742e-01
    z[1,3,6]  R1413     3.7786448001861572e-01
    z[1,3,6]  R1414     -3.1138148903846741e-01
    z[1,3,6]  R1415     -1.9536325708031654e-03
    z[1,3,6]  R1416     -3.1438705325126648e-01
    z[1,3,6]  R1417     4.4407594203948975e-01
    z[1,3,6]  R1418     0.00967728067189455
    z[1,3,6]  R1419     2.8715759515762329e-01
    z[1,3,6]  R1420     -1.4299340546131134e-01
    z[1,3,6]  R1421     -2.4260684847831726e-02
    z[1,3,6]  R1422     4.2003687471151352e-02
    z[1,3,6]  R1423     2.5526729226112366e-01
    z[1,3,6]  R1424     4.4603681564331055e-01
    z[1,3,6]  R1425     3.3880195021629333e-01
    z[1,3,6]  R1426     -3.7438246607780457e-01
    z[1,3,6]  R1427     -4.9122944474220276e-01
    z[1,3,6]  R1428     5.3314030170440674e-01
    z[1,3,6]  R1429     -3.0161604285240173e-01
    z[1,3,6]  R1430     1.4251299202442169e-01
    z[1,3,6]  R1431     -9.3784462660551071e-03
    z[1,3,6]  R1432     -1.4829332008957863e-02
    z[1,3,6]  R1433     -4.6136882901191711e-01
    z[1,3,6]  R1434     -1.3811211287975311e-01
    z[1,3,6]  R1435     1.1487468332052231e-01
    z[1,3,6]  R1436     1.3688622973859310e-02
    z[1,3,6]  R1437     -5.4443454742431641e-01
    z[1,3,6]  R1438     2.2189514338970184e-01
    z[1,3,6]  R1439     -2.5713866949081421e-01
    z[1,3,6]  R1440     1.9530370831489563e-02
    z[1,3,6]  R1441     3.9185574650764465e-01
    z[1,3,6]  R1442     -5.6224983185529709e-02
    z[1,3,6]  R1443     -2.7617835998535156e-01
    z[1,3,6]  R1444     -1.0886877775192261e-01
    z[1,3,6]  R1445     1.6325150430202484e-01
    z[1,3,6]  R1446     -3.6671221256256104e-01
    z[1,3,6]  R1447     1.9295718520879745e-02
    z[1,3,6]  R1448     0.280496209859848
    z[1,3,6]  R1449     3.5179728269577026e-01
    z[1,3,6]  R1450     3.4558865427970886e-01
    z[1,3,6]  R1451     1.1742081493139267e-01
    z[1,3,6]  R1452     -2.6539623737335205e-01
    z[1,3,6]  R1453     2.7670052647590637e-01
    z[1,3,6]  R1454     3.8323320448398590e-02
    z[1,3,6]  R1455     6.8560346961021423e-02
    z[1,3,6]  R1456     -2.5408580899238586e-01
    z[1,3,6]  R1457     -4.8990118503570557e-01
    z[1,3,6]  R1458     2.3935526609420776e-01
    z[1,3,6]  R1459     -6.3910400867462158e-01
    z[1,3,6]  R1460     1.3189865648746490e-01
    z[3,1,0]  R11       1
    z[3,1,0]  R29       -1
    z[3,1,0]  R1461     -1
    z[3,1,0]  R1462     1
    z[3,1,0]  R1475     -3.4406775236129761e-01
    z[3,1,0]  R1476     -3.2790100574493408e-01
    z[3,1,0]  R1477     -2.7911195158958435e-01
    z[3,1,0]  R1478     -2.5956231355667114e-01
    z[3,1,0]  R1479     -0.389911025762558
    z[3,1,0]  R1480     -0.200189471244812
    z[3,1,0]  R1481     -2.5247624516487122e-01
    z[3,1,0]  R1482     7.9031985998153687e-01
    z[3,1,0]  R1483     8.8028162717819214e-01
    z[3,1,0]  R1484     8.6288440227508545e-01
    z[3,1,0]  R1485     -5.6515991687774658e-01
    z[3,1,0]  R1486     -7.2183072566986084e-01
    z[3,1,0]  R1487     -1.0561756044626236e-01
    z[3,1,0]  R1488     9.0281152725219727e-01
    z[3,1,0]  R1489     -5.6377702951431274e-01
    z[3,1,0]  R1490     -4.2510709166526794e-01
    z[3,1,0]  R1491     -3.1426465511322021e-01
    z[3,1,0]  R1492     -0.472042441368103
    z[3,1,0]  R1493     -5.2815198898315430e-01
    z[3,1,0]  R1494     -4.3587875366210938e-01
    z[3,1,0]  R1495     -8.0650782585144043e-01
    z[3,1,0]  R1496     -5.4882502555847168e-01
    z[3,1,0]  R1497     -5.3742176294326782e-01
    z[3,1,0]  R1498     -5.6928426027297974e-01
    z[3,1,0]  R1499     -5.6497520208358765e-01
    z[3,1,0]  R1500     -6.1704134941101074e-01
    z[3,1,0]  R1501     -0.656769335269928
    z[3,1,0]  R1502     -7.2379314899444580e-01
    z[3,1,0]  R1503     -4.4615957140922546e-01
    z[3,1,0]  R1504     -5.2692312002182007e-01
    z[3,1,0]  R1505     -3.8040143251419067e-01
    z[3,1,0]  R1506     -8.1182342767715454e-01
    z[3,1,0]  R1507     -0.684876024723053
    z[3,1,0]  R1508     -5.0133860111236572e-01
    z[3,1,0]  R1509     -5.6957280635833740e-01
    z[3,1,0]  R1510     0.356876015663147
    z[3,1,0]  R1511     8.1507444381713867e-01
    z[3,1,0]  R1512     9.1206395626068115e-01
    z[3,1,0]  R1513     7.6318812370300293e-01
    z[3,1,0]  R1514     8.7414103746414185e-01
    z[3,1,0]  R1515     -5.3127700090408325e-01
    z[3,1,0]  R1516     -3.3868685364723206e-01
    z[3,1,0]  R1517     -3.4689253568649292e-01
    z[3,1,0]  R1518     -0.587253212928772
    z[3,1,0]  R1519     -2.1451064944267273e-01
    z[3,1,0]  R1520     -1.4580808579921722e-01
    z[3,1,0]  R1521     -5.0207239389419556e-01
    z[3,1,0]  R1522     -6.3019603490829468e-01
    z[3,1,0]  R1523     -6.6657543182373047e-01
    z[3,1,0]  R1524     -4.9757176637649536e-01
    z[3,1,0]  R1525     -5.4342097043991089e-01
    z[3,1,0]  R1526     -8.4325426816940308e-01
    z[3,1,0]  R1527     -8.3551156520843506e-01
    z[3,1,0]  R1528     -5.7310348749160767e-01
    z[3,1,0]  R1529     -3.0678653717041016e-01
    z[3,1,0]  R1530     -0.371635377407074
    z[3,1,0]  R1531     -5.5593419075012207e-01
    z[3,1,0]  R1532     4.6494059264659882e-02
    z[3,1,0]  R1533     8.0510163307189941e-01
    z[3,1,0]  R1534     8.6243516206741333e-01
    z[3,1,0]  R1535     6.2239643186330795e-02
    z[3,1,0]  R1536     -7.6600360870361328e-01
    z[3,1,0]  R1537     5.9907469898462296e-02
    z[3,1,0]  R1538     -6.7986255884170532e-01
    z[3,1,0]  R1539     -6.9654667377471924e-01
    z[3,1,0]  R1540     -5.5627793073654175e-01
    z[3,1,0]  R1541     -7.0455557107925415e-01
    z[3,1,0]  R1542     -2.4017766118049622e-02
    z[3,1,0]  R1543     8.6195367574691772e-01
    z[3,1,0]  R1544     8.7085694074630737e-01
    z[3,1,0]  R1545     -4.1222232580184937e-01
    z[3,1,0]  R1546     -3.7235784530639648e-01
    z[3,1,0]  R1547     -2.5136863812804222e-02
    z[3,1,0]  R1548     -7.5712692737579346e-01
    z[3,1,0]  R1549     -5.1961249113082886e-01
    z[3,1,0]  R1550     -1.2179906666278839e-01
    z[3,1,0]  R1551     9.1755294799804688e-01
    z[3,1,0]  R1552     7.9644507169723511e-01
    z[3,1,0]  R1553     0.795567512512207
    z[3,1,0]  R1554     8.2271134853363037e-01
    z[3,1,0]  R1555     -4.8599314689636230e-01
    z[3,1,0]  R1556     -6.6693328320980072e-02
    z[3,1,0]  R1557     -4.7179032117128372e-02
    z[3,1,0]  R1558     -2.1626415848731995e-01
    z[3,1,0]  R1559     -2.4165056645870209e-01
    z[3,1,0]  R1560     -8.7707346677780151e-01
    z[3,1,0]  R1561     -8.2092583179473877e-01
    z[3,1,0]  R1562     3.0467975139617920e-01
    z[3,1,0]  R1563     -7.1975088119506836e-01
    z[3,1,0]  R1564     8.4028869867324829e-01
    z[3,1,0]  R1565     4.4048145413398743e-01
    z[3,1,0]  R1566     4.4716534018516541e-01
    z[3,1,0]  R1567     3.1553784012794495e-01
    z[3,1,0]  R1568     2.1296481788158417e-01
    z[3,1,0]  R1569     2.0398156344890594e-01
    z[3,1,0]  R1570     1.4513950049877167e-01
    z[3,1,0]  R1571     4.2035266757011414e-01
    z[3,1,0]  R1572     1.8896244466304779e-01
    z[3,1,0]  R1573     2.6948067545890808e-01
    z[3,1,0]  R1574     5.3773349523544312e-01
    z[3,1,0]  R1575     -8.8005030155181885e-01
    z[3,1,0]  R1576     -8.4766268730163574e-01
    z[3,1,0]  R1577     -8.9489394426345825e-01
    z[3,1,0]  R1578     5.6491714715957642e-01
    z[3,1,0]  R1579     6.4999121427536011e-01
    z[3,1,0]  R1580     5.7755821943283081e-01
    z[3,1,0]  R1581     1.8908669054508209e-01
    z[3,1,0]  R1582     6.9569748640060425e-01
    z[3,1,0]  R1583     5.9627151489257812e-01
    z[3,1,0]  R1584     5.2757942676544189e-01
    z[3,1,0]  R1585     -3.5752275586128235e-01
    z[3,1,0]  R1586     -2.9642897844314575e-01
    z[3,1,0]  R1587     -6.3600605726242065e-01
    z[3,1,0]  R1588     -3.5773396492004395e-01
    z[3,1,0]  R1589     -1.8340660631656647e-01
    z[3,1,0]  R1590     -3.7775182723999023e-01
    z[3,1,0]  R1591     -3.4659394621849060e-01
    z[3,1,0]  R1592     6.2411874532699585e-02
    z[3,1,0]  R1593     4.5564625412225723e-02
    z[3,1,0]  R1594     -5.1198780536651611e-01
    z[3,1,0]  R1595     -4.8201125860214233e-01
    z[3,1,0]  R1596     -5.8650255203247070e-01
    z[3,1,0]  R1597     -4.3368390202522278e-01
    z[3,1,0]  R1598     -7.5530534982681274e-01
    z[3,1,0]  R1599     0.0590699128806591
    z[3,1,0]  R1600     -3.6986050009727478e-01
    z[3,1,0]  R1601     1.0634465515613556e-01
    z[3,1,0]  R1602     4.4743397831916809e-01
    z[3,1,0]  R1603     1.4682547748088837e-01
    z[3,1,0]  R1604     0.00492557417601347
    z[3,1,0]  R1605     -4.5591101050376892e-01
    z[3,1,0]  R1606     -6.2477695941925049e-01
    z[3,1,0]  R1607     1.2044054269790649e-01
    z[3,1,0]  R1608     2.5214740633964539e-01
    z[3,1,0]  R1609     1.6487506031990051e-01
    z[3,1,0]  R1610     -3.5710880160331726e-01
    z[3,1,0]  R1611     -2.3909138143062592e-01
    z[3,1,0]  R1612     -4.0107741951942444e-01
    z[3,1,0]  R1613     -2.8470501303672791e-01
    z[3,1,0]  R1614     6.0285080224275589e-02
    z[3,1,0]  R1615     -4.5614802837371826e-01
    z[3,1,0]  R1616     1.6883884370326996e-01
    z[3,1,0]  R1617     -5.7301348447799683e-01
    z[3,1,0]  R1618     -6.5560430288314819e-01
    z[3,1,0]  R1619     4.6026740223169327e-02
    z[3,1,0]  R1620     5.9459650516510010e-01
    z[3,1,0]  R1621     -8.1936977803707123e-03
    z[3,1,0]  R1622     -2.8132265806198120e-01
    z[3,1,0]  R1623     -3.0873646959662437e-02
    z[3,1,0]  R1624     6.2525354325771332e-02
    z[3,1,0]  R1625     -6.5801465511322021e-01
    z[3,1,0]  R1626     3.9888685941696167e-01
    z[3,1,0]  R1627     -7.6452434062957764e-01
    z[3,1,0]  R1628     7.1891725063323975e-01
    z[3,1,0]  R1629     1.0193198919296265e-01
    z[3,1,0]  R1630     4.0106898546218872e-01
    z[3,1,0]  R1631     -1.0802744328975677e-01
    z[3,1,0]  R1632     -2.2934605181217194e-01
    z[3,1,0]  R1633     -2.3645068705081940e-01
    z[3,1,0]  R1634     -6.9124542176723480e-02
    z[3,1,0]  R1635     -6.0876989364624023e-01
    z[3,1,0]  R1636     -4.0712639689445496e-01
    z[3,1,0]  R1637     -1.0106655955314636e-01
    z[3,1,0]  R1638     -1.8882115185260773e-01
    z[3,1,0]  R1639     3.2330492138862610e-01
    z[3,1,0]  R1640     -1.0135262459516525e-01
    z[3,1,0]  R1641     -2.3631669580936432e-02
    z[3,1,0]  R1642     2.9480382800102234e-02
    z[3,1,0]  R1643     -2.4920843541622162e-01
    z[3,1,0]  R1644     -1.4453461766242981e-01
    z[3,1,0]  R1645     -6.4922505617141724e-01
    z[3,1,0]  R1646     -6.0427713394165039e-01
    z[3,1,0]  R1647     7.9296268522739410e-02
    z[3,1,0]  R1648     5.6043070554733276e-01
    z[3,1,0]  R1649     -5.7753247022628784e-01
    z[3,1,0]  R1650     1.8766084313392639e-01
    z[3,1,0]  R1651     8.5992045700550079e-02
    z[3,1,0]  R1652     2.0371274650096893e-01
    z[3,1,0]  R1653     1.2180276960134506e-01
    z[3,1,0]  R1654     2.2687834501266479e-01
    z[3,1,1]  R12       1
    z[3,1,1]  R30       -1
    z[3,1,1]  R1463     -1
    z[3,1,1]  R1464     1
    z[3,1,1]  R1475     -4.0743622183799744e-01
    z[3,1,1]  R1476     -1.9889074563980103e-01
    z[3,1,1]  R1477     5.7454162836074829e-01
    z[3,1,1]  R1478     1.6744308173656464e-01
    z[3,1,1]  R1479     -3.1165421009063721e-01
    z[3,1,1]  R1480     3.1051808595657349e-01
    z[3,1,1]  R1481     4.2386922240257263e-01
    z[3,1,1]  R1482     -0.0718371719121933
    z[3,1,1]  R1483     -8.9955933392047882e-02
    z[3,1,1]  R1484     5.7048797607421875e-02
    z[3,1,1]  R1485     -1.1104349046945572e-01
    z[3,1,1]  R1486     -1.6461621224880219e-01
    z[3,1,1]  R1487     -4.3762156367301941e-01
    z[3,1,1]  R1488     1.6248683631420135e-01
    z[3,1,1]  R1489     1.1134830117225647e-01
    z[3,1,1]  R1490     -7.3070541024208069e-02
    z[3,1,1]  R1491     9.6246063709259033e-02
    z[3,1,1]  R1492     1.1782778799533844e-01
    z[3,1,1]  R1493     2.7041202783584595e-01
    z[3,1,1]  R1494     -5.4209005832672119e-01
    z[3,1,1]  R1495     3.8884720206260681e-01
    z[3,1,1]  R1496     -3.4910616278648376e-01
    z[3,1,1]  R1497     5.5928987264633179e-01
    z[3,1,1]  R1498     4.4444081187248230e-01
    z[3,1,1]  R1499     0.575400710105896
    z[3,1,1]  R1500     4.9236461520195007e-01
    z[3,1,1]  R1501     3.6707437038421631e-01
    z[3,1,1]  R1502     -0.401419073343277
    z[3,1,1]  R1503     5.9140056371688843e-01
    z[3,1,1]  R1504     1.9477939605712891e-01
    z[3,1,1]  R1505     5.6616431474685669e-01
    z[3,1,1]  R1506     4.7562189400196075e-02
    z[3,1,1]  R1507     2.3031720519065857e-01
    z[3,1,1]  R1508     -1.3365231454372406e-01
    z[3,1,1]  R1509     3.5345628857612610e-02
    z[3,1,1]  R1510     -5.4927694797515869e-01
    z[3,1,1]  R1511     -2.5580203533172607e-01
    z[3,1,1]  R1512     -2.9031846672296524e-02
    z[3,1,1]  R1513     2.1840266883373260e-01
    z[3,1,1]  R1514     1.0058821178972721e-02
    z[3,1,1]  R1515     -4.8622789978981018e-01
    z[3,1,1]  R1516     2.0794808864593506e-01
    z[3,1,1]  R1517     4.7027045488357544e-01
    z[3,1,1]  R1518     -7.0744462311267853e-02
    z[3,1,1]  R1519     -2.3843885958194733e-01
    z[3,1,1]  R1520     -1.1425514519214630e-01
    z[3,1,1]  R1521     -4.8765793442726135e-01
    z[3,1,1]  R1522     -2.7695251628756523e-02
    z[3,1,1]  R1523     -4.5463964343070984e-02
    z[3,1,1]  R1524     3.7216268479824066e-02
    z[3,1,1]  R1525     0.563527524471283
    z[3,1,1]  R1526     2.7319166064262390e-01
    z[3,1,1]  R1527     -1.4385347068309784e-01
    z[3,1,1]  R1528     7.2615332901477814e-03
    z[3,1,1]  R1529     8.1111228466033936e-01
    z[3,1,1]  R1530     3.2436794042587280e-01
    z[3,1,1]  R1531     4.0905106067657471e-01
    z[3,1,1]  R1532     -6.5500330924987793e-01
    z[3,1,1]  R1533     3.4475263953208923e-01
    z[3,1,1]  R1534     1.8451488018035889e-01
    z[3,1,1]  R1535     -3.3994078636169434e-01
    z[3,1,1]  R1536     4.7159090638160706e-01
    z[3,1,1]  R1537     -2.5233197212219238e-01
    z[3,1,1]  R1538     1.8022919073700905e-02
    z[3,1,1]  R1539     0.0539570190012455
    z[3,1,1]  R1540     1.6202329099178314e-01
    z[3,1,1]  R1541     2.8932240605354309e-01
    z[3,1,1]  R1542     -7.3883497714996338e-01
    z[3,1,1]  R1543     -1.1312500573694706e-03
    z[3,1,1]  R1544     2.0633409917354584e-01
    z[3,1,1]  R1545     -0.57985520362854
    z[3,1,1]  R1546     5.2900129556655884e-01
    z[3,1,1]  R1547     -0.422419011592865
    z[3,1,1]  R1548     -3.2618728280067444e-01
    z[3,1,1]  R1549     3.6254149675369263e-01
    z[3,1,1]  R1550     1.5918913483619690e-01
    z[3,1,1]  R1551     9.1630041599273682e-02
    z[3,1,1]  R1552     1.0925793647766113e-01
    z[3,1,1]  R1553     -1.5200471878051758e-01
    z[3,1,1]  R1554     -2.1054264903068542e-01
    z[3,1,1]  R1555     2.1635462343692780e-01
    z[3,1,1]  R1556     -3.5965493321418762e-01
    z[3,1,1]  R1557     -5.1427793502807617e-01
    z[3,1,1]  R1558     -3.7195730209350586e-01
    z[3,1,1]  R1559     -6.8676269054412842e-01
    z[3,1,1]  R1560     1.7070958018302917e-01
    z[3,1,1]  R1561     2.0195762813091278e-01
    z[3,1,1]  R1562     -6.7172354459762573e-01
    z[3,1,1]  R1563     2.9508890584111214e-02
    z[3,1,1]  R1564     2.8312578797340393e-01
    z[3,1,1]  R1565     7.6852989196777344e-01
    z[3,1,1]  R1566     7.1061855554580688e-01
    z[3,1,1]  R1567     6.9127148389816284e-01
    z[3,1,1]  R1568     6.7748028039932251e-01
    z[3,1,1]  R1569     6.6225379705429077e-01
    z[3,1,1]  R1570     0.657947301864624
    z[3,1,1]  R1571     6.5257954597473145e-01
    z[3,1,1]  R1572     6.5442794561386108e-01
    z[3,1,1]  R1573     6.3109076023101807e-01
    z[3,1,1]  R1574     6.2716007232666016e-01
    z[3,1,1]  R1575     1.3539300300180912e-02
    z[3,1,1]  R1576     -0.0493953637778759
    z[3,1,1]  R1577     -4.1284445673227310e-02
    z[3,1,1]  R1578     -5.1278859376907349e-01
    z[3,1,1]  R1579     -5.4661726951599121e-01
    z[3,1,1]  R1580     -4.9537131190299988e-01
    z[3,1,1]  R1581     -5.5065184831619263e-01
    z[3,1,1]  R1582     -4.6201971173286438e-01
    z[3,1,1]  R1583     -6.0528641939163208e-01
    z[3,1,1]  R1584     -3.8753968477249146e-01
    z[3,1,1]  R1585     2.2777329385280609e-01
    z[3,1,1]  R1586     3.5794261097908020e-01
    z[3,1,1]  R1587     -0.0707663968205452
    z[3,1,1]  R1588     2.1073617041110992e-01
    z[3,1,1]  R1589     2.3412954807281494e-01
    z[3,1,1]  R1590     2.5247669219970703e-01
    z[3,1,1]  R1591     1.3208749890327454e-01
    z[3,1,1]  R1592     6.7550706863403320e-01
    z[3,1,1]  R1593     6.7064303159713745e-01
    z[3,1,1]  R1594     -4.9852974712848663e-02
    z[3,1,1]  R1595     4.2516711354255676e-01
    z[3,1,1]  R1596     2.7613270282745361e-01
    z[3,1,1]  R1597     2.8282597661018372e-01
    z[3,1,1]  R1598     4.4181060791015625e-01
    z[3,1,1]  R1599     -1.9234298169612885e-01
    z[3,1,1]  R1600     1.0171489417552948e-01
    z[3,1,1]  R1601     5.7744336128234863e-01
    z[3,1,1]  R1602     -5.2219372987747192e-01
    z[3,1,1]  R1603     -3.1241990625858307e-02
    z[3,1,1]  R1604     5.3227978944778442e-01
    z[3,1,1]  R1605     3.8184702396392822e-01
    z[3,1,1]  R1606     -2.7537789195775986e-02
    z[3,1,1]  R1607     8.5406959056854248e-01
    z[3,1,1]  R1608     8.1836843490600586e-01
    z[3,1,1]  R1609     2.6267403364181519e-01
    z[3,1,1]  R1610     1.3385763764381409e-01
    z[3,1,1]  R1611     2.5609949231147766e-01
    z[3,1,1]  R1612     8.2399033010005951e-02
    z[3,1,1]  R1613     2.4601301550865173e-01
    z[3,1,1]  R1614     6.1969733238220215e-01
    z[3,1,1]  R1615     4.0898019075393677e-01
    z[3,1,1]  R1616     6.4176046848297119e-01
    z[3,1,1]  R1617     1.0565433651208878e-01
    z[3,1,1]  R1618     1.3106757402420044e-01
    z[3,1,1]  R1619     9.3674689531326294e-01
    z[3,1,1]  R1620     5.0609749555587769e-01
    z[3,1,1]  R1621     4.6355494856834412e-01
    z[3,1,1]  R1622     0.284940242767334
    z[3,1,1]  R1623     2.8398683294653893e-02
    z[3,1,1]  R1624     2.4847318232059479e-01
    z[3,1,1]  R1625     2.6605013012886047e-01
    z[3,1,1]  R1626     8.0469900369644165e-01
    z[3,1,1]  R1627     4.4193947315216064e-01
    z[3,1,1]  R1628     -5.1152259111404419e-01
    z[3,1,1]  R1629     -4.2723175883293152e-01
    z[3,1,1]  R1630     -4.2270788550376892e-01
    z[3,1,1]  R1631     -2.3982043564319611e-01
    z[3,1,1]  R1632     -9.1337114572525024e-01
    z[3,1,1]  R1633     -8.7942677736282349e-01
    z[3,1,1]  R1634     -2.8539735078811646e-01
    z[3,1,1]  R1635     3.4915563464164734e-01
    z[3,1,1]  R1636     3.8095399737358093e-01
    z[3,1,1]  R1637     5.5673009157180786e-01
    z[3,1,1]  R1638     -1.8500310182571411e-01
    z[3,1,1]  R1639     -3.9021816849708557e-01
    z[3,1,1]  R1640     3.8227722048759460e-02
    z[3,1,1]  R1641     -2.0226265490055084e-01
    z[3,1,1]  R1642     5.9279982000589371e-02
    z[3,1,1]  R1643     -0.926781177520752
    z[3,1,1]  R1644     -7.5965744256973267e-01
    z[3,1,1]  R1645     1.5500506758689880e-01
    z[3,1,1]  R1646     7.0526483468711376e-03
    z[3,1,1]  R1647     9.5337331295013428e-01
    z[3,1,1]  R1648     -6.2721198797225952e-01
    z[3,1,1]  R1649     3.7929084897041321e-01
    z[3,1,1]  R1650     -1.0878720879554749e-01
    z[3,1,1]  R1651     -3.3713793754577637e-01
    z[3,1,1]  R1652     -3.9753583073616028e-01
    z[3,1,1]  R1653     -0.273084819316864
    z[3,1,1]  R1654     -3.3717691898345947e-01
    z[3,1,2]  R13       1
    z[3,1,2]  R31       -1
    z[3,1,2]  R1465     -1
    z[3,1,2]  R1466     1
    z[3,1,2]  R1475     4.1041958332061768e-01
    z[3,1,2]  R1476     4.8243105411529541e-01
    z[3,1,2]  R1477     1.5083377063274384e-01
    z[3,1,2]  R1478     2.3986802995204926e-01
    z[3,1,2]  R1479     5.3352898359298706e-01
    z[3,1,2]  R1480     -1.8829308450222015e-01
    z[3,1,2]  R1481     -6.2303669750690460e-02
    z[3,1,2]  R1482     -6.2953778542578220e-03
    z[3,1,2]  R1483     -6.2106844037771225e-02
    z[3,1,2]  R1484     2.6103788614273071e-01
    z[3,1,2]  R1485     1.2965458631515503e-01
    z[3,1,2]  R1486     -4.6965414285659790e-01
    z[3,1,2]  R1487     2.0638918876647949e-01
    z[3,1,2]  R1488     1.6082639992237091e-01
    z[3,1,2]  R1489     -6.0505729913711548e-01
    z[3,1,2]  R1490     -7.0326203107833862e-01
    z[3,1,2]  R1491     -8.3815455436706543e-01
    z[3,1,2]  R1492     -6.1573606729507446e-01
    z[3,1,2]  R1493     4.2432656884193420e-01
    z[3,1,2]  R1494     -3.0441206693649292e-01
    z[3,1,2]  R1495     1.5811249613761902e-01
    z[3,1,2]  R1496     0.376202791929245
    z[3,1,2]  R1497     5.0575062632560730e-02
    z[3,1,2]  R1498     2.1942797303199768e-01
    z[3,1,2]  R1499     -4.8627737164497375e-01
    z[3,1,2]  R1500     -3.4369108080863953e-01
    z[3,1,2]  R1501     1.2670375406742096e-01
    z[3,1,2]  R1502     -2.3087514936923981e-01
    z[3,1,2]  R1503     -4.0249493718147278e-01
    z[3,1,2]  R1504     7.9355299472808838e-01
    z[3,1,2]  R1505     -6.2529988586902618e-02
    z[3,1,2]  R1506     -2.4667935073375702e-01
    z[3,1,2]  R1507     -2.9975825548171997e-01
    z[3,1,2]  R1508     -1.9519220292568207e-01
    z[3,1,2]  R1509     -3.2596173882484436e-01
    z[3,1,2]  R1510     5.3519034385681152e-01
    z[3,1,2]  R1511     4.2127409577369690e-01
    z[3,1,2]  R1512     1.2512315809726715e-01
    z[3,1,2]  R1513     3.2611471414566040e-01
    z[3,1,2]  R1514     2.5055831670761108e-01
    z[3,1,2]  R1515     3.1556525826454163e-01
    z[3,1,2]  R1516     -2.1326968073844910e-01
    z[3,1,2]  R1517     -2.4498504400253296e-01
    z[3,1,2]  R1518     9.8096147179603577e-02
    z[3,1,2]  R1519     5.0670439004898071e-01
    z[3,1,2]  R1520     5.9198117256164551e-01
    z[3,1,2]  R1521     -4.0576282143592834e-01
    z[3,1,2]  R1522     -4.5886853337287903e-01
    z[3,1,2]  R1523     -4.3549299240112305e-01
    z[3,1,2]  R1524     -7.1385937929153442e-01
    z[3,1,2]  R1525     -1.5301067614927888e-03
    z[3,1,2]  R1526     -4.0854278206825256e-01
    z[3,1,2]  R1527     2.4864038452506065e-02
    z[3,1,2]  R1528     3.0922656878829002e-02
    z[3,1,2]  R1529     -0.0631827712059021
    z[3,1,2]  R1530     6.1961793899536133e-01
    z[3,1,2]  R1531     -4.2903009057044983e-01
    z[3,1,2]  R1532     1.7989465594291687e-01
    z[3,1,2]  R1533     3.3121243119239807e-01
    z[3,1,2]  R1534     2.1600204706192017e-01
    z[3,1,2]  R1535     6.9001567363739014e-01
    z[3,1,2]  R1536     -2.2462388500571251e-02
    z[3,1,2]  R1537     7.2278487682342529e-01
    z[3,1,2]  R1538     -2.3946358263492584e-01
    z[3,1,2]  R1539     -5.9312063455581665e-01
    z[3,1,2]  R1540     7.0781731605529785e-01
    z[3,1,2]  R1541     1.1221123486757278e-01
    z[3,1,2]  R1542     1.1881493777036667e-01
    z[3,1,2]  R1543     2.9405781626701355e-01
    z[3,1,2]  R1544     -1.0706714354455471e-02
    z[3,1,2]  R1545     2.5668564438819885e-01
    z[3,1,2]  R1546     -3.7382226437330246e-02
    z[3,1,2]  R1547     6.8933749198913574e-01
    z[3,1,2]  R1548     -3.1472650170326233e-01
    z[3,1,2]  R1549     -3.4611481428146362e-01
    z[3,1,2]  R1550     7.3608571290969849e-01
    z[3,1,2]  R1551     3.4660151600837708e-01
    z[3,1,2]  R1552     3.5235700011253357e-01
    z[3,1,2]  R1553     -3.8247801363468170e-02
    z[3,1,2]  R1554     -1.2653575837612152e-01
    z[3,1,2]  R1555     4.0381708741188049e-01
    z[3,1,2]  R1556     6.5360546112060547e-01
    z[3,1,2]  R1557     5.5261862277984619e-01
    z[3,1,2]  R1558     8.4787815809249878e-01
    z[3,1,2]  R1559     1.0278853029012680e-01
    z[3,1,2]  R1560     -1.9657596945762634e-01
    z[3,1,2]  R1561     -1.7647102475166321e-01
    z[3,1,2]  R1562     4.9150779843330383e-01
    z[3,1,2]  R1563     3.6729894578456879e-02
    z[3,1,2]  R1564     -1.0624358803033829e-01
    z[3,1,2]  R1565     1.9762471318244934e-01
    z[3,1,2]  R1566     1.8094404041767120e-01
    z[3,1,2]  R1567     1.7155742272734642e-02
    z[3,1,2]  R1568     2.3242124915122986e-01
    z[3,1,2]  R1569     2.0797017216682434e-01
    z[3,1,2]  R1570     3.0362471938133240e-01
    z[3,1,2]  R1571     1.5505865216255188e-01
    z[3,1,2]  R1572     1.7621801793575287e-01
    z[3,1,2]  R1573     1.8051068484783173e-01
    z[3,1,2]  R1574     -1.3206172734498978e-02
    z[3,1,2]  R1575     -6.9564029574394226e-02
    z[3,1,2]  R1576     1.7230573296546936e-01
    z[3,1,2]  R1577     1.7138895392417908e-01
    z[3,1,2]  R1578     -1.4812509715557098e-01
    z[3,1,2]  R1579     -1.6373504698276520e-01
    z[3,1,2]  R1580     -2.1429817378520966e-01
    z[3,1,2]  R1581     -2.5060099363327026e-01
    z[3,1,2]  R1582     -6.6603772342205048e-02
    z[3,1,2]  R1583     4.1931409388780594e-02
    z[3,1,2]  R1584     -1.5611787140369415e-01
    z[3,1,2]  R1585     2.7155104279518127e-01
    z[3,1,2]  R1586     -1.2577632069587708e-01
    z[3,1,2]  R1587     -2.7121728658676147e-01
    z[3,1,2]  R1588     0.0661039724946022
    z[3,1,2]  R1589     -5.5829749908298254e-04
    z[3,1,2]  R1590     -1.6054630279541016e-01
    z[3,1,2]  R1591     1.1115300655364990e-01
    z[3,1,2]  R1592     -0.4558085501194
    z[3,1,2]  R1593     -4.5450708270072937e-01
    z[3,1,2]  R1594     6.2247227877378464e-02
    z[3,1,2]  R1595     4.6318256855010986e-01
    z[3,1,2]  R1596     4.2427086830139160e-01
    z[3,1,2]  R1597     1.3735873997211456e-01
    z[3,1,2]  R1598     -2.5027480721473694e-01
    z[3,1,2]  R1599     1.4518241398036480e-02
    z[3,1,2]  R1600     3.6463406682014465e-01
    z[3,1,2]  R1601     -3.2373934984207153e-01
    z[3,1,2]  R1602     4.8716405034065247e-01
    z[3,1,2]  R1603     3.8003337383270264e-01
    z[3,1,2]  R1604     -1.1138872057199478e-01
    z[3,1,2]  R1605     6.1045867204666138e-01
    z[3,1,2]  R1606     -1.4914770424365997e-01
    z[3,1,2]  R1607     -3.2510453462600708e-01
    z[3,1,2]  R1608     -2.3592798411846161e-01
    z[3,1,2]  R1609     -3.6896771192550659e-01
    z[3,1,2]  R1610     8.4914974868297577e-02
    z[3,1,2]  R1611     2.3748025298118591e-01
    z[3,1,2]  R1612     -4.6754304319620132e-02
    z[3,1,2]  R1613     4.0193051099777222e-01
    z[3,1,2]  R1614     -3.2748410105705261e-01
    z[3,1,2]  R1615     3.2034772634506226e-01
    z[3,1,2]  R1616     3.4528324007987976e-01
    z[3,1,2]  R1617     -9.6078209578990936e-02
    z[3,1,2]  R1618     -2.2535999119281769e-01
    z[3,1,2]  R1619     -2.2950629889965057e-01
    z[3,1,2]  R1620     -1.9488035142421722e-01
    z[3,1,2]  R1621     -1.3908736407756805e-01
    z[3,1,2]  R1622     3.8566029071807861e-01
    z[3,1,2]  R1623     -1.7290504276752472e-01
    z[3,1,2]  R1624     -5.4297423362731934e-01
    z[3,1,2]  R1625     1.8496979773044586e-01
    z[3,1,2]  R1626     -0.244472473859787
    z[3,1,2]  R1627     -2.9634317755699158e-01
    z[3,1,2]  R1628     3.2215365767478943e-01
    z[3,1,2]  R1629     1.1727154999971390e-01
    z[3,1,2]  R1630     5.3423233330249786e-02
    z[3,1,2]  R1631     3.2155385613441467e-01
    z[3,1,2]  R1632     1.3224214315414429e-01
    z[3,1,2]  R1633     1.9594286382198334e-01
    z[3,1,2]  R1634     2.3662203550338745e-01
    z[3,1,2]  R1635     2.2422102093696594e-01
    z[3,1,2]  R1636     4.1424378752708435e-01
    z[3,1,2]  R1637     -4.9048945307731628e-01
    z[3,1,2]  R1638     4.3830013275146484e-01
    z[3,1,2]  R1639     0.417977511882782
    z[3,1,2]  R1640     4.0899294614791870e-01
    z[3,1,2]  R1641     2.4501444399356842e-01
    z[3,1,2]  R1642     -1.8349802494049072e-01
    z[3,1,2]  R1643     1.4926487207412720e-01
    z[3,1,2]  R1644     3.8419011235237122e-01
    z[3,1,2]  R1645     2.4462023377418518e-01
    z[3,1,2]  R1646     -1.4788176119327545e-01
    z[3,1,2]  R1647     -4.7778464853763580e-02
    z[3,1,2]  R1648     1.4802455902099609e-01
    z[3,1,2]  R1649     -4.2650622129440308e-01
    z[3,1,2]  R1650     4.7915931791067123e-03
    z[3,1,2]  R1651     -8.4596776962280273e-01
    z[3,1,2]  R1652     -7.6929843425750732e-01
    z[3,1,2]  R1653     -8.8198131322860718e-01
    z[3,1,2]  R1654     -8.0463838577270508e-01
    z[3,1,3]  R14       1
    z[3,1,3]  R32       -1
    z[3,1,3]  R1467     -1
    z[3,1,3]  R1468     1
    z[3,1,3]  R1475     -2.7057039737701416e-01
    z[3,1,3]  R1476     2.2242200374603271e-01
    z[3,1,3]  R1477     -4.8630633950233459e-01
    z[3,1,3]  R1478     -9.0782207250595093e-01
    z[3,1,3]  R1479     -6.0245823860168457e-01
    z[3,1,3]  R1480     -7.7078616619110107e-01
    z[3,1,3]  R1481     -5.7151901721954346e-01
    z[3,1,3]  R1482     -4.4974225759506226e-01
    z[3,1,3]  R1483     -3.3146941661834717e-01
    z[3,1,3]  R1484     -3.7510424852371216e-01
    z[3,1,3]  R1485     3.1618601083755493e-01
    z[3,1,3]  R1486     -1.8194037675857544e-01
    z[3,1,3]  R1487     3.8946425914764404e-01
    z[3,1,3]  R1488     0.081110879778862
    z[3,1,3]  R1489     1.6585490107536316e-01
    z[3,1,3]  R1490     3.3532249927520752e-01
    z[3,1,3]  R1491     2.4041488766670227e-01
    z[3,1,3]  R1492     5.9478312730789185e-01
    z[3,1,3]  R1493     3.0572825670242310e-01
    z[3,1,3]  R1494     -9.2390157282352448e-02
    z[3,1,3]  R1495     -7.5568921864032745e-02
    z[3,1,3]  R1496     -9.7693480551242828e-02
    z[3,1,3]  R1497     -1.7162151634693146e-01
    z[3,1,3]  R1498     -1.2340348213911057e-01
    z[3,1,3]  R1499     -3.6988846957683563e-02
    z[3,1,3]  R1500     -2.4959733709692955e-02
    z[3,1,3]  R1501     -5.6879818439483643e-03
    z[3,1,3]  R1502     4.3359389901161194e-01
    z[3,1,3]  R1503     -1.2845497578382492e-02
    z[3,1,3]  R1504     -1.7646154761314392e-01
    z[3,1,3]  R1505     -4.5771875977516174e-01
    z[3,1,3]  R1506     -4.7059425711631775e-01
    z[3,1,3]  R1507     2.9010131955146790e-01
    z[3,1,3]  R1508     -1.5414546430110931e-01
    z[3,1,3]  R1509     2.8731770813465118e-02
    z[3,1,3]  R1510     5.1945778541266918e-03
    z[3,1,3]  R1511     -0.0582304522395134
    z[3,1,3]  R1512     -2.7886587381362915e-01
    z[3,1,3]  R1513     1.9689889624714851e-02
    z[3,1,3]  R1514     -1.2389860302209854e-01
    z[3,1,3]  R1515     2.3909914493560791e-01
    z[3,1,3]  R1516     -8.3357393741607666e-01
    z[3,1,3]  R1517     -5.2888363599777222e-01
    z[3,1,3]  R1518     -6.7985409498214722e-01
    z[3,1,3]  R1519     6.0640448331832886e-01
    z[3,1,3]  R1520     5.7174468040466309e-01
    z[3,1,3]  R1521     -7.3191873729228973e-02
    z[3,1,3]  R1522     2.1180571615695953e-01
    z[3,1,3]  R1523     -2.2566859424114227e-01
    z[3,1,3]  R1524     -1.3528390228748322e-01
    z[3,1,3]  R1525     -3.4971076250076294e-01
    z[3,1,3]  R1526     -1.2376046925783157e-01
    z[3,1,3]  R1527     -1.3576015830039978e-02
    z[3,1,3]  R1528     -6.5821069478988647e-01
    z[3,1,3]  R1529     -3.2483169436454773e-01
    z[3,1,3]  R1530     -4.0063586831092834e-01
    z[3,1,3]  R1531     3.1285667419433594e-01
    z[3,1,3]  R1532     1.3730789721012115e-01
    z[3,1,3]  R1533     -1.4332598447799683e-01
    z[3,1,3]  R1534     3.1519293785095215e-01
    z[3,1,3]  R1535     -9.5184780657291412e-02
    z[3,1,3]  R1536     2.4369803071022034e-01
    z[3,1,3]  R1537     0.348730206489563
    z[3,1,3]  R1538     0.451188862323761
    z[3,1,3]  R1539     3.3942395448684692e-01
    z[3,1,3]  R1540     -6.7075587809085846e-02
    z[3,1,3]  R1541     1.8302203714847565e-01
    z[3,1,3]  R1542     1.1391800642013550e-01
    z[3,1,3]  R1543     1.4862108230590820e-01
    z[3,1,3]  R1544     -3.2110220193862915e-01
    z[3,1,3]  R1545     4.3260562419891357e-01
    z[3,1,3]  R1546     -6.7774200439453125e-01
    z[3,1,3]  R1547     -4.0927335619926453e-01
    z[3,1,3]  R1548     -1.3049960136413574e-02
    z[3,1,3]  R1549     -0.502071738243103
    z[3,1,3]  R1550     -9.1563336551189423e-02
    z[3,1,3]  R1551     -1.4747790992259979e-01
    z[3,1,3]  R1552     -7.6781474053859711e-02
    z[3,1,3]  R1553     1.6723388433456421e-01
    z[3,1,3]  R1554     1.7311847209930420e-01
    z[3,1,3]  R1555     -7.0427286624908447e-01
    z[3,1,3]  R1556     5.3233772516250610e-01
    z[3,1,3]  R1557     4.6594947576522827e-01
    z[3,1,3]  R1558     -3.8813658058643341e-02
    z[3,1,3]  R1559     -2.1370275318622589e-01
    z[3,1,3]  R1560     2.2169852256774902e-01
    z[3,1,3]  R1561     1.7748758196830750e-02
    z[3,1,3]  R1562     2.0500671863555908e-01
    z[3,1,3]  R1563     -8.5821323096752167e-02
    z[3,1,3]  R1564     1.5121363103389740e-01
    z[3,1,3]  R1565     2.4325282871723175e-01
    z[3,1,3]  R1566     -2.9130894690752029e-02
    z[3,1,3]  R1567     -2.5148457288742065e-01
    z[3,1,3]  R1568     1.2540750205516815e-01
    z[3,1,3]  R1569     -6.9350488483905792e-02
    z[3,1,3]  R1570     -2.2384946048259735e-01
    z[3,1,3]  R1571     -1.5611016750335693e-01
    z[3,1,3]  R1572     0.351661741733551
    z[3,1,3]  R1573     -1.9590289890766144e-01
    z[3,1,3]  R1574     -1.4304912090301514e-01
    z[3,1,3]  R1575     2.1276351809501648e-01
    z[3,1,3]  R1576     2.3736884817481041e-02
    z[3,1,3]  R1577     2.3033104836940765e-01
    z[3,1,3]  R1578     -5.3111881017684937e-01
    z[3,1,3]  R1579     -4.1673696041107178e-01
    z[3,1,3]  R1580     -6.0401380062103271e-01
    z[3,1,3]  R1581     -7.1226024627685547e-01
    z[3,1,3]  R1582     -5.0312846899032593e-01
    z[3,1,3]  R1583     -3.5064321756362915e-01
    z[3,1,3]  R1584     -6.3387966156005859e-01
    z[3,1,3]  R1585     -6.4800351858139038e-01
    z[3,1,3]  R1586     -7.8793352842330933e-01
    z[3,1,3]  R1587     -1.7942821979522705e-01
    z[3,1,3]  R1588     -0.599696934223175
    z[3,1,3]  R1589     -9.0880846977233887e-01
    z[3,1,3]  R1590     -0.678071916103363
    z[3,1,3]  R1591     -3.2827010750770569e-01
    z[3,1,3]  R1592     -3.1030055880546570e-01
    z[3,1,3]  R1593     -5.1563370227813721e-01
    z[3,1,3]  R1594     -4.5084246993064880e-01
    z[3,1,3]  R1595     4.4007804989814758e-01
    z[3,1,3]  R1596     3.3346137404441833e-01
    z[3,1,3]  R1597     1.2889523059129715e-02
    z[3,1,3]  R1598     -2.9720512032508850e-01
    z[3,1,3]  R1599     -0.571692705154419
    z[3,1,3]  R1600     -3.4564909338951111e-01
    z[3,1,3]  R1601     -2.9619028791785240e-03
    z[3,1,3]  R1602     2.4839065968990326e-01
    z[3,1,3]  R1603     8.3537089824676514e-01
    z[3,1,3]  R1604     6.5786695480346680e-01
    z[3,1,3]  R1605     -4.3137678503990173e-01
    z[3,1,3]  R1606     -2.2906927764415741e-01
    z[3,1,3]  R1607     -2.2457545623183250e-02
    z[3,1,3]  R1608     -8.8043145835399628e-02
    z[3,1,3]  R1609     -7.6031464338302612e-01
    z[3,1,3]  R1610     -4.3721115589141846e-01
    z[3,1,3]  R1611     -1.2719729542732239e-01
    z[3,1,3]  R1612     -4.4476732611656189e-01
    z[3,1,3]  R1613     2.0254816114902496e-01
    z[3,1,3]  R1614     1.8693853914737701e-01
    z[3,1,3]  R1615     -4.4414305686950684e-01
    z[3,1,3]  R1616     4.7506517171859741e-01
    z[3,1,3]  R1617     -1.5171146392822266e-01
    z[3,1,3]  R1618     -4.6923705935478210e-01
    z[3,1,3]  R1619     2.3001782596111298e-02
    z[3,1,3]  R1620     1.2662726454436779e-02
    z[3,1,3]  R1621     -0.766851007938385
    z[3,1,3]  R1622     1.9679950177669525e-01
    z[3,1,3]  R1623     -8.5443496704101562e-01
    z[3,1,3]  R1624     -7.1599733829498291e-01
    z[3,1,3]  R1625     -0.621579110622406
    z[3,1,3]  R1626     -1.8579454720020294e-01
    z[3,1,3]  R1627     -3.1899437308311462e-01
    z[3,1,3]  R1628     2.7757775783538818e-01
    z[3,1,3]  R1629     -3.3909055590629578e-01
    z[3,1,3]  R1630     1.6180644929409027e-01
    z[3,1,3]  R1631     7.4454855918884277e-01
    z[3,1,3]  R1632     2.3615576326847076e-02
    z[3,1,3]  R1633     -6.1152640730142593e-02
    z[3,1,3]  R1634     6.6606956720352173e-01
    z[3,1,3]  R1635     -2.6376655697822571e-01
    z[3,1,3]  R1636     2.7661317586898804e-01
    z[3,1,3]  R1637     -4.9569407105445862e-01
    z[3,1,3]  R1638     7.1560466289520264e-01
    z[3,1,3]  R1639     1.2439829856157303e-01
    z[3,1,3]  R1640     8.8599252700805664e-01
    z[3,1,3]  R1641     8.0509597063064575e-01
    z[3,1,3]  R1642     9.6395754814147949e-01
    z[3,1,3]  R1643     1.3031853735446930e-01
    z[3,1,3]  R1644     4.5830440521240234e-01
    z[3,1,3]  R1645     2.2185295820236206e-01
    z[3,1,3]  R1646     -3.4237092733383179e-01
    z[3,1,3]  R1647     1.3089454174041748e-01
    z[3,1,3]  R1648     1.9845359027385712e-02
    z[3,1,3]  R1649     -1.9326542317867279e-01
    z[3,1,3]  R1650     -5.7583391666412354e-01
    z[3,1,3]  R1651     0.336665540933609
    z[3,1,3]  R1652     3.8043934106826782e-01
    z[3,1,3]  R1653     3.3475691080093384e-01
    z[3,1,3]  R1654     3.3808118104934692e-01
    z[3,1,4]  R15       1
    z[3,1,4]  R33       -1
    z[3,1,4]  R1469     -1
    z[3,1,4]  R1470     1
    z[3,1,4]  R1475     -4.2647701501846313e-01
    z[3,1,4]  R1476     6.4936959743499756e-01
    z[3,1,4]  R1477     2.0659589767456055e-01
    z[3,1,4]  R1478     1.2071436643600464e-01
    z[3,1,4]  R1479     -2.6310819387435913e-01
    z[3,1,4]  R1480     -2.7697184681892395e-01
    z[3,1,4]  R1481     -6.3517436385154724e-02
    z[3,1,4]  R1482     1.3910956680774689e-01
    z[3,1,4]  R1483     -1.1195933073759079e-01
    z[3,1,4]  R1484     0.00340811675414443
    z[3,1,4]  R1485     2.2796740755438805e-02
    z[3,1,4]  R1486     2.9402857646346092e-02
    z[3,1,4]  R1487     -2.3719245195388794e-01
    z[3,1,4]  R1488     3.0050572752952576e-01
    z[3,1,4]  R1489     2.9327198863029480e-01
    z[3,1,4]  R1490     1.3792613148689270e-01
    z[3,1,4]  R1491     2.5427341461181641e-02
    z[3,1,4]  R1492     0.118742436170578
    z[3,1,4]  R1493     -3.8816636800765991e-01
    z[3,1,4]  R1494     -1.4444314874708652e-02
    z[3,1,4]  R1495     2.9218655824661255e-01
    z[3,1,4]  R1496     1.4821581542491913e-01
    z[3,1,4]  R1497     2.9983353614807129e-01
    z[3,1,4]  R1498     -1.4140526950359344e-01
    z[3,1,4]  R1499     -7.0724025368690491e-02
    z[3,1,4]  R1500     8.9530251920223236e-02
    z[3,1,4]  R1501     -2.9376211762428284e-01
    z[3,1,4]  R1502     -6.6264927387237549e-02
    z[3,1,4]  R1503     -4.9960368871688843e-01
    z[3,1,4]  R1504     4.7424253076314926e-02
    z[3,1,4]  R1505     -5.2696573734283447e-01
    z[3,1,4]  R1506     0.225468710064888
    z[3,1,4]  R1507     5.3126358985900879e-01
    z[3,1,4]  R1508     -0.645107090473175
    z[3,1,4]  R1509     -5.7966804504394531e-01
    z[3,1,4]  R1510     -5.1796585321426392e-01
    z[3,1,4]  R1511     -2.2337383031845093e-01
    z[3,1,4]  R1512     1.0597323998808861e-02
    z[3,1,4]  R1513     -3.5800719261169434e-01
    z[3,1,4]  R1514     -3.9284643530845642e-01
    z[3,1,4]  R1515     -5.3778970241546631e-01
    z[3,1,4]  R1516     1.9459785521030426e-01
    z[3,1,4]  R1517     1.0053319483995438e-01
    z[3,1,4]  R1518     -2.2989268600940704e-01
    z[3,1,4]  R1519     -2.9182881116867065e-01
    z[3,1,4]  R1520     -2.7246505022048950e-01
    z[3,1,4]  R1521     -4.6303052455186844e-02
    z[3,1,4]  R1522     -5.5385154485702515e-01
    z[3,1,4]  R1523     -3.7276622653007507e-01
    z[3,1,4]  R1524     -0.343077689409256
    z[3,1,4]  R1525     4.8305603861808777e-01
    z[3,1,4]  R1526     -1.0203192383050919e-01
    z[3,1,4]  R1527     -0.0925784781575203
    z[3,1,4]  R1528     -1.8663829565048218e-01
    z[3,1,4]  R1529     8.7267801165580750e-02
    z[3,1,4]  R1530     -2.6311576366424561e-01
    z[3,1,4]  R1531     1.6780454665422440e-02
    z[3,1,4]  R1532     2.5766485929489136e-01
    z[3,1,4]  R1533     7.5200520455837250e-02
    z[3,1,4]  R1534     4.6823222190141678e-02
    z[3,1,4]  R1535     5.6598985195159912e-01
    z[3,1,4]  R1536     -3.5769158601760864e-01
    z[3,1,4]  R1537     1.4069169759750366e-01
    z[3,1,4]  R1538     0.452584832906723
    z[3,1,4]  R1539     1.6116510331630707e-01
    z[3,1,4]  R1540     -3.5327225923538208e-01
    z[3,1,4]  R1541     3.8043644279241562e-02
    z[3,1,4]  R1542     -1.6989172995090485e-01
    z[3,1,4]  R1543     -1.8061298131942749e-01
    z[3,1,4]  R1544     -3.0069085955619812e-01
    z[3,1,4]  R1545     2.5757661461830139e-01
    z[3,1,4]  R1546     -3.4258410334587097e-01
    z[3,1,4]  R1547     0.00994244497269392
    z[3,1,4]  R1548     -1.0714717209339142e-01
    z[3,1,4]  R1549     1.4907805621623993e-01
    z[3,1,4]  R1550     4.5438849925994873e-01
    z[3,1,4]  R1551     8.5485167801380157e-02
    z[3,1,4]  R1552     -1.6078485175967216e-02
    z[3,1,4]  R1553     -4.3499547243118286e-01
    z[3,1,4]  R1554     -2.1023973822593689e-01
    z[3,1,4]  R1555     7.9031303524971008e-02
    z[3,1,4]  R1556     1.9675374031066895e-01
    z[3,1,4]  R1557     -2.6867267489433289e-01
    z[3,1,4]  R1558     1.1945463716983795e-02
    z[3,1,4]  R1559     -4.1314724087715149e-01
    z[3,1,4]  R1560     2.9950621537864208e-03
    z[3,1,4]  R1561     -9.5723450183868408e-02
    z[3,1,4]  R1562     -1.4593677222728729e-01
    z[3,1,4]  R1563     -2.2758300602436066e-01
    z[3,1,4]  R1564     -2.9370945692062378e-01
    z[3,1,4]  R1565     3.9067290723323822e-02
    z[3,1,4]  R1566     -2.8967443108558655e-01
    z[3,1,4]  R1567     5.9735560417175293e-01
    z[3,1,4]  R1568     1.1907239258289337e-01
    z[3,1,4]  R1569     -2.6911571621894836e-01
    z[3,1,4]  R1570     -4.7039699554443359e-01
    z[3,1,4]  R1571     2.0863448083400726e-01
    z[3,1,4]  R1572     3.7537318468093872e-01
    z[3,1,4]  R1573     -4.9597907066345215e-01
    z[3,1,4]  R1574     0.436262845993042
    z[3,1,4]  R1575     2.0806825160980225e-01
    z[3,1,4]  R1576     -4.7438085079193115e-01
    z[3,1,4]  R1577     -1.6129940748214722e-01
    z[3,1,4]  R1578     -1.7047438025474548e-01
    z[3,1,4]  R1579     1.5612085163593292e-01
    z[3,1,4]  R1580     1.6943825408816338e-02
    z[3,1,4]  R1581     -9.3334801495075226e-03
    z[3,1,4]  R1582     1.4701751992106438e-02
    z[3,1,4]  R1583     2.4286296218633652e-02
    z[3,1,4]  R1584     6.5779253840446472e-02
    z[3,1,4]  R1585     6.7274391651153564e-02
    z[3,1,4]  R1586     -5.7650838047266006e-02
    z[3,1,4]  R1587     2.0311267673969269e-01
    z[3,1,4]  R1588     2.9101410508155823e-01
    z[3,1,4]  R1589     2.6428506243973970e-03
    z[3,1,4]  R1590     2.0727189257740974e-02
    z[3,1,4]  R1591     4.8381105065345764e-01
    z[3,1,4]  R1592     2.1485836803913116e-01
    z[3,1,4]  R1593     1.8651841580867767e-01
    z[3,1,4]  R1594     6.1027181148529053e-01
    z[3,1,4]  R1595     2.7737993001937866e-01
    z[3,1,4]  R1596     3.2691791653633118e-01
    z[3,1,4]  R1597     -3.2753947377204895e-01
    z[3,1,4]  R1598     -1.5371769666671753e-01
    z[3,1,4]  R1599     1.7633976042270660e-01
    z[3,1,4]  R1600     1.0239803791046143e-01
    z[3,1,4]  R1601     2.8421280905604362e-02
    z[3,1,4]  R1602     -1.8215529620647430e-02
    z[3,1,4]  R1603     4.5270342379808426e-02
    z[3,1,4]  R1604     -2.9345223307609558e-01
    z[3,1,4]  R1605     -9.8966039717197418e-02
    z[3,1,4]  R1606     5.8230036497116089e-01
    z[3,1,4]  R1607     -7.7445581555366516e-02
    z[3,1,4]  R1608     5.4957754909992218e-02
    z[3,1,4]  R1609     0.0887366533279419
    z[3,1,4]  R1610     1.2271800637245178e-01
    z[3,1,4]  R1611     1.7630773782730103e-01
    z[3,1,4]  R1612     -2.7799794077873230e-01
    z[3,1,4]  R1613     -2.6498362421989441e-01
    z[3,1,4]  R1614     4.8734968900680542e-01
    z[3,1,4]  R1615     2.7661731839179993e-01
    z[3,1,4]  R1616     -3.4113430976867676e-01
    z[3,1,4]  R1617     0.190584197640419
    z[3,1,4]  R1618     4.2454391717910767e-01
    z[3,1,4]  R1619     6.2954194843769073e-02
    z[3,1,4]  R1620     5.1860720850527287e-03
    z[3,1,4]  R1621     -4.0332680940628052e-01
    z[3,1,4]  R1622     -2.6774457097053528e-01
    z[3,1,4]  R1623     4.1753351688385010e-01
    z[3,1,4]  R1624     2.6212513446807861e-01
    z[3,1,4]  R1625     -1.9029390811920166e-01
    z[3,1,4]  R1626     -1.3608361780643463e-01
    z[3,1,4]  R1627     -6.1558857560157776e-02
    z[3,1,4]  R1628     -6.4338847994804382e-02
    z[3,1,4]  R1629     5.0951063632965088e-01
    z[3,1,4]  R1630     4.8818126320838928e-01
    z[3,1,4]  R1631     2.8009146451950073e-01
    z[3,1,4]  R1632     1.1476716957986355e-02
    z[3,1,4]  R1633     -1.6288541257381439e-01
    z[3,1,4]  R1634     -2.3661302030086517e-01
    z[3,1,4]  R1635     -2.9888426885008812e-02
    z[3,1,4]  R1636     -5.2529531717300415e-01
    z[3,1,4]  R1637     1.1386800557374954e-01
    z[3,1,4]  R1638     -2.6716282963752747e-01
    z[3,1,4]  R1639     2.3903135955333710e-01
    z[3,1,4]  R1640     1.6486936807632446e-01
    z[3,1,4]  R1641     5.1504410803318024e-02
    z[3,1,4]  R1642     1.4756634831428528e-01
    z[3,1,4]  R1643     1.8596661090850830e-01
    z[3,1,4]  R1644     1.2414073944091797e-01
    z[3,1,4]  R1645     -4.9323442578315735e-01
    z[3,1,4]  R1646     3.7036576867103577e-01
    z[3,1,4]  R1647     -2.0263580977916718e-01
    z[3,1,4]  R1648     0.294387549161911
    z[3,1,4]  R1649     2.8524341061711311e-02
    z[3,1,4]  R1650     -7.0917648077011108e-01
    z[3,1,4]  R1651     1.6378301382064819e-01
    z[3,1,4]  R1652     -2.4107404053211212e-01
    z[3,1,4]  R1653     -0.0662151351571083
    z[3,1,4]  R1654     -2.0259568095207214e-01
    z[3,1,5]  R16       1
    z[3,1,5]  R34       -1
    z[3,1,5]  R1471     -1
    z[3,1,5]  R1472     1
    z[3,1,5]  R1475     -4.3386217951774597e-01
    z[3,1,5]  R1476     -2.1251513063907623e-01
    z[3,1,5]  R1477     -5.0445652008056641e-01
    z[3,1,5]  R1478     -7.6856710016727448e-02
    z[3,1,5]  R1479     -1.6088853776454926e-01
    z[3,1,5]  R1480     2.5028528645634651e-02
    z[3,1,5]  R1481     0.348357617855072
    z[3,1,5]  R1482     -3.7620836496353149e-01
    z[3,1,5]  R1483     -3.0073845386505127e-01
    z[3,1,5]  R1484     -1.9433495402336121e-01
    z[3,1,5]  R1485     3.8035976886749268e-01
    z[3,1,5]  R1486     -4.6719394624233246e-02
    z[3,1,5]  R1487     6.0069918632507324e-01
    z[3,1,5]  R1488     1.8863563239574432e-01
    z[3,1,5]  R1489     4.0948572754859924e-01
    z[3,1,5]  R1490     1.7991185188293457e-01
    z[3,1,5]  R1491     0.0920541062951088
    z[3,1,5]  R1492     1.2588837742805481e-01
    z[3,1,5]  R1493     4.7277545928955078e-01
    z[3,1,5]  R1494     5.9156739711761475e-01
    z[3,1,5]  R1495     -2.3151063919067383e-01
    z[3,1,5]  R1496     0.457425594329834
    z[3,1,5]  R1497     2.0204125344753265e-01
    z[3,1,5]  R1498     0.598791241645813
    z[3,1,5]  R1499     -2.3754674196243286e-01
    z[3,1,5]  R1500     4.9399951100349426e-01
    z[3,1,5]  R1501     3.6819356679916382e-01
    z[3,1,5]  R1502     2.2365932166576385e-01
    z[3,1,5]  R1503     1.4212416112422943e-01
    z[3,1,5]  R1504     -6.7222595214843750e-02
    z[3,1,5]  R1505     -2.0196711644530296e-02
    z[3,1,5]  R1506     -4.8286926001310349e-02
    z[3,1,5]  R1507     -1.3389208912849426e-01
    z[3,1,5]  R1508     2.1183808147907257e-01
    z[3,1,5]  R1509     8.8243380188941956e-02
    z[3,1,5]  R1510     1.2243386358022690e-01
    z[3,1,5]  R1511     2.9019605368375778e-02
    z[3,1,5]  R1512     1.3056750595569611e-01
    z[3,1,5]  R1513     -1.7010171711444855e-01
    z[3,1,5]  R1514     -3.9907835423946381e-02
    z[3,1,5]  R1515     1.8827447667717934e-02
    z[3,1,5]  R1516     -1.8242919445037842e-01
    z[3,1,5]  R1517     -4.0729236602783203e-01
    z[3,1,5]  R1518     1.6880555450916290e-01
    z[3,1,5]  R1519     -4.3299937248229980e-01
    z[3,1,5]  R1520     -3.3952260017395020e-01
    z[3,1,5]  R1521     3.7518686056137085e-01
    z[3,1,5]  R1522     -1.9954627752304077e-01
    z[3,1,5]  R1523     -3.0268070101737976e-01
    z[3,1,5]  R1524     2.9153221845626831e-01
    z[3,1,5]  R1525     1.7578034102916718e-01
    z[3,1,5]  R1526     1.4103178679943085e-01
    z[3,1,5]  R1527     -4.5463374257087708e-01
    z[3,1,5]  R1528     5.9324383735656738e-02
    z[3,1,5]  R1529     -1.2676222622394562e-01
    z[3,1,5]  R1530     5.3338032215833664e-02
    z[3,1,5]  R1531     -8.9633306488394737e-03
    z[3,1,5]  R1532     4.0861195325851440e-01
    z[3,1,5]  R1533     -7.8010559082031250e-02
    z[3,1,5]  R1534     -2.3163343966007233e-01
    z[3,1,5]  R1535     0.273774117231369
    z[3,1,5]  R1536     -5.2762970328330994e-02
    z[3,1,5]  R1537     2.3675620555877686e-01
    z[3,1,5]  R1538     2.2943376004695892e-01
    z[3,1,5]  R1539     7.5764514505863190e-02
    z[3,1,5]  R1540     1.8387521803379059e-01
    z[3,1,5]  R1541     -2.7558884024620056e-01
    z[3,1,5]  R1542     5.9021270275115967e-01
    z[3,1,5]  R1543     2.2301357984542847e-01
    z[3,1,5]  R1544     -7.0829652249813080e-02
    z[3,1,5]  R1545     1.4459949731826782e-01
    z[3,1,5]  R1546     1.5825821086764336e-02
    z[3,1,5]  R1547     3.1916475296020508e-01
    z[3,1,5]  R1548     4.4475227594375610e-01
    z[3,1,5]  R1549     -4.2168667912483215e-01
    z[3,1,5]  R1550     -2.6205161213874817e-01
    z[3,1,5]  R1551     1.1747315526008606e-02
    z[3,1,5]  R1552     -3.8046085834503174e-01
    z[3,1,5]  R1553     -3.9427403360605240e-02
    z[3,1,5]  R1554     2.6306691765785217e-01
    z[3,1,5]  R1555     -1.9467723369598389e-01
    z[3,1,5]  R1556     2.1556799113750458e-01
    z[3,1,5]  R1557     -2.4909430742263794e-01
    z[3,1,5]  R1558     -3.0473336577415466e-01
    z[3,1,5]  R1559     4.8819732666015625e-01
    z[3,1,5]  R1560     -2.2189967334270477e-01
    z[3,1,5]  R1561     -6.8342939019203186e-02
    z[3,1,5]  R1562     3.0620506405830383e-01
    z[3,1,5]  R1563     1.1011601239442825e-01
    z[3,1,5]  R1564     -2.7557021379470825e-01
    z[3,1,5]  R1565     3.3873483538627625e-01
    z[3,1,5]  R1566     1.2411311268806458e-01
    z[3,1,5]  R1567     -4.6913441270589828e-02
    z[3,1,5]  R1568     -4.4032388925552368e-01
    z[3,1,5]  R1569     -0.530138373374939
    z[3,1,5]  R1570     2.3358824849128723e-01
    z[3,1,5]  R1571     4.1394233703613281e-01
    z[3,1,5]  R1572     4.8824291676282883e-02
    z[3,1,5]  R1573     -3.9712780714035034e-01
    z[3,1,5]  R1574     2.7972424030303955e-01
    z[3,1,5]  R1575     3.5715565085411072e-01
    z[3,1,5]  R1576     -1.5061445534229279e-01
    z[3,1,5]  R1577     -8.1352427601814270e-02
    z[3,1,5]  R1578     -1.8826331198215485e-01
    z[3,1,5]  R1579     -1.8314327299594879e-01
    z[3,1,5]  R1580     2.1702989935874939e-02
    z[3,1,5]  R1581     -2.7365726232528687e-01
    z[3,1,5]  R1582     1.4367893338203430e-01
    z[3,1,5]  R1583     -2.9355597496032715e-01
    z[3,1,5]  R1584     -1.6940365731716156e-01
    z[3,1,5]  R1585     2.3928731679916382e-01
    z[3,1,5]  R1586     -2.8580215573310852e-01
    z[3,1,5]  R1587     -6.6587787866592407e-01
    z[3,1,5]  R1588     -5.1513540744781494e-01
    z[3,1,5]  R1589     2.9050523042678833e-01
    z[3,1,5]  R1590     -5.2687561511993408e-01
    z[3,1,5]  R1591     -7.1248096227645874e-01
    z[3,1,5]  R1592     -3.8606736063957214e-01
    z[3,1,5]  R1593     1.8828584253787994e-01
    z[3,1,5]  R1594     -3.4893444180488586e-01
    z[3,1,5]  R1595     2.3667345941066742e-01
    z[3,1,5]  R1596     -3.8476511836051941e-01
    z[3,1,5]  R1597     -6.4561265707015991e-01
    z[3,1,5]  R1598     -1.8605917692184448e-01
    z[3,1,5]  R1599     7.7510738372802734e-01
    z[3,1,5]  R1600     -8.8310331106185913e-02
    z[3,1,5]  R1601     -3.1413757801055908e-01
    z[3,1,5]  R1602     4.4666835665702820e-01
    z[3,1,5]  R1603     3.6467710137367249e-01
    z[3,1,5]  R1604     -3.1655681133270264e-01
    z[3,1,5]  R1605     2.3101146519184113e-01
    z[3,1,5]  R1606     -2.2347655892372131e-01
    z[3,1,5]  R1607     -2.3387621343135834e-01
    z[3,1,5]  R1608     -4.4238799810409546e-01
    z[3,1,5]  R1609     1.2042701244354248e-02
    z[3,1,5]  R1610     0.0900174155831337
    z[3,1,5]  R1611     -2.4764549732208252e-01
    z[3,1,5]  R1612     -5.9273451566696167e-01
    z[3,1,5]  R1613     2.1468596160411835e-01
    z[3,1,5]  R1614     2.5821685791015625e-02
    z[3,1,5]  R1615     4.2101528495550156e-02
    z[3,1,5]  R1616     -1.9953294098377228e-01
    z[3,1,5]  R1617     -3.8285022974014282e-01
    z[3,1,5]  R1618     -3.0303534865379333e-01
    z[3,1,5]  R1619     -2.1895058453083038e-01
    z[3,1,5]  R1620     -1.7859362065792084e-01
    z[3,1,5]  R1621     -1.2226261198520660e-01
    z[3,1,5]  R1622     8.4042645990848541e-02
    z[3,1,5]  R1623     4.6469278633594513e-02
    z[3,1,5]  R1624     -2.3661652207374573e-01
    z[3,1,5]  R1625     5.3901232779026031e-02
    z[3,1,5]  R1626     -2.5268737226724625e-02
    z[3,1,5]  R1627     1.1423484981060028e-01
    z[3,1,5]  R1628     9.2856295406818390e-02
    z[3,1,5]  R1629     6.0295450687408447e-01
    z[3,1,5]  R1630     5.0113433599472046e-01
    z[3,1,5]  R1631     1.6589875519275665e-01
    z[3,1,5]  R1632     2.8435957431793213e-01
    z[3,1,5]  R1633     3.1393593549728394e-01
    z[3,1,5]  R1634     2.0554584264755249e-01
    z[3,1,5]  R1635     5.3236478567123413e-01
    z[3,1,5]  R1636     -3.4749662876129150e-01
    z[3,1,5]  R1637     -4.1468435525894165e-01
    z[3,1,5]  R1638     3.0284056067466736e-01
    z[3,1,5]  R1639     0.639694094657898
    z[3,1,5]  R1640     0.0696791484951973
    z[3,1,5]  R1641     1.8360999226570129e-01
    z[3,1,5]  R1642     -1.0117681324481964e-01
    z[3,1,5]  R1643     7.0125319063663483e-02
    z[3,1,5]  R1644     1.1617124080657959e-01
    z[3,1,5]  R1645     4.4329819083213806e-01
    z[3,1,5]  R1646     -5.5636620521545410e-01
    z[3,1,5]  R1647     -1.4024247229099274e-01
    z[3,1,5]  R1648     4.0735453367233276e-01
    z[3,1,5]  R1649     -1.9044749438762665e-01
    z[3,1,5]  R1650     -3.1642335653305054e-01
    z[3,1,5]  R1651     -1.4758719503879547e-01
    z[3,1,5]  R1652     6.5971814095973969e-02
    z[3,1,5]  R1653     -4.5893844217061996e-02
    z[3,1,5]  R1654     8.5568435490131378e-02
    z[3,1,6]  R17       1
    z[3,1,6]  R35       -1
    z[3,1,6]  R1473     -1
    z[3,1,6]  R1474     1
    z[3,1,6]  R1475     3.2224437594413757e-01
    z[3,1,6]  R1476     3.2228657603263855e-01
    z[3,1,6]  R1477     1.8866769969463348e-01
    z[3,1,6]  R1478     -4.9333442002534866e-02
    z[3,1,6]  R1479     -0.0901155099272728
    z[3,1,6]  R1480     0.395723819732666
    z[3,1,6]  R1481     -5.4834973812103271e-01
    z[3,1,6]  R1482     8.3916939795017242e-02
    z[3,1,6]  R1483     1.7447138205170631e-02
    z[3,1,6]  R1484     -7.4526853859424591e-02
    z[3,1,6]  R1485     -6.3740599155426025e-01
    z[3,1,6]  R1486     0.441743403673172
    z[3,1,6]  R1487     -4.3122348189353943e-01
    z[3,1,6]  R1488     -1.4081505127251148e-02
    z[3,1,6]  R1489     -1.4989298582077026e-01
    z[3,1,6]  R1490     3.9437824487686157e-01
    z[3,1,6]  R1491     3.5007354617118835e-01
    z[3,1,6]  R1492     2.1143538877367973e-02
    z[3,1,6]  R1493     1.4839254319667816e-02
    z[3,1,6]  R1494     2.5452831387519836e-01
    z[3,1,6]  R1495     -1.6930031776428223e-01
    z[3,1,6]  R1496     -4.4117712974548340e-01
    z[3,1,6]  R1497     4.8542764782905579e-01
    z[3,1,6]  R1498     1.9095657765865326e-01
    z[3,1,6]  R1499     -2.2461685538291931e-01
    z[3,1,6]  R1500     -7.7713549137115479e-02
    z[3,1,6]  R1501     4.4267535209655762e-01
    z[3,1,6]  R1502     1.3879722356796265e-01
    z[3,1,6]  R1503     -1.3862450420856476e-01
    z[3,1,6]  R1504     -1.2953819334506989e-01
    z[3,1,6]  R1505     2.0793128013610840e-01
    z[3,1,6]  R1506     5.6596368551254272e-02
    z[3,1,6]  R1507     6.0966953635215759e-02
    z[3,1,6]  R1508     -4.5595744252204895e-01
    z[3,1,6]  R1509     -4.7271448373794556e-01
    z[3,1,6]  R1510     3.4640945494174957e-02
    z[3,1,6]  R1511     1.9651544094085693e-01
    z[3,1,6]  R1512     2.3814779520034790e-01
    z[3,1,6]  R1513     -3.2557934522628784e-01
    z[3,1,6]  R1514     -4.1531622409820557e-02
    z[3,1,6]  R1515     -1.8709658086299896e-01
    z[3,1,6]  R1516     1.7484484612941742e-01
    z[3,1,6]  R1517     3.7786448001861572e-01
    z[3,1,6]  R1518     -3.1138148903846741e-01
    z[3,1,6]  R1519     -1.9536325708031654e-03
    z[3,1,6]  R1520     -3.1438705325126648e-01
    z[3,1,6]  R1521     4.4407594203948975e-01
    z[3,1,6]  R1522     0.00967728067189455
    z[3,1,6]  R1523     2.8715759515762329e-01
    z[3,1,6]  R1524     -1.4299340546131134e-01
    z[3,1,6]  R1525     -2.4260684847831726e-02
    z[3,1,6]  R1526     4.2003687471151352e-02
    z[3,1,6]  R1527     2.5526729226112366e-01
    z[3,1,6]  R1528     4.4603681564331055e-01
    z[3,1,6]  R1529     3.3880195021629333e-01
    z[3,1,6]  R1530     -3.7438246607780457e-01
    z[3,1,6]  R1531     -4.9122944474220276e-01
    z[3,1,6]  R1532     5.3314030170440674e-01
    z[3,1,6]  R1533     -3.0161604285240173e-01
    z[3,1,6]  R1534     1.4251299202442169e-01
    z[3,1,6]  R1535     -9.3784462660551071e-03
    z[3,1,6]  R1536     -1.4829332008957863e-02
    z[3,1,6]  R1537     -4.6136882901191711e-01
    z[3,1,6]  R1538     -1.3811211287975311e-01
    z[3,1,6]  R1539     1.1487468332052231e-01
    z[3,1,6]  R1540     1.3688622973859310e-02
    z[3,1,6]  R1541     -5.4443454742431641e-01
    z[3,1,6]  R1542     2.2189514338970184e-01
    z[3,1,6]  R1543     -2.5713866949081421e-01
    z[3,1,6]  R1544     1.9530370831489563e-02
    z[3,1,6]  R1545     3.9185574650764465e-01
    z[3,1,6]  R1546     -5.6224983185529709e-02
    z[3,1,6]  R1547     -2.7617835998535156e-01
    z[3,1,6]  R1548     -1.0886877775192261e-01
    z[3,1,6]  R1549     1.6325150430202484e-01
    z[3,1,6]  R1550     -3.6671221256256104e-01
    z[3,1,6]  R1551     1.9295718520879745e-02
    z[3,1,6]  R1552     0.280496209859848
    z[3,1,6]  R1553     3.5179728269577026e-01
    z[3,1,6]  R1554     3.4558865427970886e-01
    z[3,1,6]  R1555     1.1742081493139267e-01
    z[3,1,6]  R1556     -2.6539623737335205e-01
    z[3,1,6]  R1557     2.7670052647590637e-01
    z[3,1,6]  R1558     3.8323320448398590e-02
    z[3,1,6]  R1559     6.8560346961021423e-02
    z[3,1,6]  R1560     -2.5408580899238586e-01
    z[3,1,6]  R1561     -4.8990118503570557e-01
    z[3,1,6]  R1562     2.3935526609420776e-01
    z[3,1,6]  R1563     -6.3910400867462158e-01
    z[3,1,6]  R1564     1.3189865648746490e-01
    z[3,1,6]  R1565     2.9033901169896126e-02
    z[3,1,6]  R1566     4.0269076824188232e-01
    z[3,1,6]  R1567     -2.5250702165067196e-03
    z[3,1,6]  R1568     4.6675089001655579e-01
    z[3,1,6]  R1569     3.4391921758651733e-01
    z[3,1,6]  R1570     -3.5764020681381226e-01
    z[3,1,6]  R1571     -3.6626964807510376e-01
    z[3,1,6]  R1572     4.8786246776580811e-01
    z[3,1,6]  R1573     -2.3331686854362488e-01
    z[3,1,6]  R1574     -1.6823986172676086e-01
    z[3,1,6]  R1575     -6.6091649234294891e-02
    z[3,1,6]  R1576     -3.2455231994390488e-02
    z[3,1,6]  R1577     2.8705042600631714e-01
    z[3,1,6]  R1578     -2.2222459316253662e-01
    z[3,1,6]  R1579     -1.4257307350635529e-01
    z[3,1,6]  R1580     -0.0975661426782608
    z[3,1,6]  R1581     1.2624484300613403e-01
    z[3,1,6]  R1582     1.5527017414569855e-01
    z[3,1,6]  R1583     0.258098304271698
    z[3,1,6]  R1584     3.3507046103477478e-01
    z[3,1,6]  R1585     5.1464933156967163e-01
    z[3,1,6]  R1586     2.4968293309211731e-01
    z[3,1,6]  R1587     9.3214483931660652e-03
    z[3,1,6]  R1588     3.3698195219039917e-01
    z[3,1,6]  R1589     3.4815050661563873e-02
    z[3,1,6]  R1590     -1.7313238978385925e-01
    z[3,1,6]  R1591     -2.4636309593915939e-02
    z[3,1,6]  R1592     -2.0133270323276520e-01
    z[3,1,6]  R1593     7.3934487998485565e-02
    z[3,1,6]  R1594     -1.8456031382083893e-01
    z[3,1,6]  R1595     -2.1386298537254333e-01
    z[3,1,6]  R1596     1.8342237174510956e-01
    z[3,1,6]  R1597     4.3450701236724854e-01
    z[3,1,6]  R1598     1.5843538939952850e-01
    z[3,1,6]  R1599     2.4175839498639107e-02
    z[3,1,6]  R1600     -7.6298236846923828e-01
    z[3,1,6]  R1601     -6.7152345180511475e-01
    z[3,1,6]  R1602     -1.6806390881538391e-01
    z[3,1,6]  R1603     1.2550490908324718e-02
    z[3,1,6]  R1604     -2.9177930951118469e-01
    z[3,1,6]  R1605     1.5630675852298737e-01
    z[3,1,6]  R1606     3.8100153207778931e-01
    z[3,1,6]  R1607     -0.298606812953949
    z[3,1,6]  R1608     -6.7481301724910736e-02
    z[3,1,6]  R1609     4.2612645030021667e-01
    z[3,1,6]  R1610     -7.9563081264495850e-01
    z[3,1,6]  R1611     -8.4395474195480347e-01
    z[3,1,6]  R1612     -4.5136049389839172e-01
    z[3,1,6]  R1613     7.3453408479690552e-01
    z[3,1,6]  R1614     -4.8163527250289917e-01
    z[3,1,6]  R1615     4.9647635221481323e-01
    z[3,1,6]  R1616     -2.4195753037929535e-01
    z[3,1,6]  R1617     -6.6734445095062256e-01
    z[3,1,6]  R1618     -9.9828787147998810e-02
    z[3,1,6]  R1619     -1.2361995875835419e-01
    z[3,1,6]  R1620     -5.6591433286666870e-01
    z[3,1,6]  R1621     -4.8089297488331795e-03
    z[3,1,6]  R1622     7.5726640224456787e-01
    z[3,1,6]  R1623     -0.248578742146492
    z[3,1,6]  R1624     4.6707659959793091e-02
    z[3,1,6]  R1625     -1.9116099178791046e-01
    z[3,1,6]  R1626     -2.8267496824264526e-01
    z[3,1,6]  R1627     1.1737269163131714e-01
    z[3,1,6]  R1628     -1.6705824434757233e-01
    z[3,1,6]  R1629     -2.3493103682994843e-01
    z[3,1,6]  R1630     -3.7678858637809753e-01
    z[3,1,6]  R1631     4.0877026319503784e-01
    z[3,1,6]  R1632     -1.1880979686975479e-01
    z[3,1,6]  R1633     5.8983471244573593e-02
    z[3,1,6]  R1634     -5.6204688549041748e-01
    z[3,1,6]  R1635     3.2145938277244568e-01
    z[3,1,6]  R1636     -2.1052356064319611e-01
    z[3,1,6]  R1637     -9.2820391058921814e-02
    z[3,1,6]  R1638     -2.5066909193992615e-01
    z[3,1,6]  R1639     2.9441300034523010e-01
    z[3,1,6]  R1640     -6.3016250729560852e-02
    z[3,1,6]  R1641     -4.6255189180374146e-01
    z[3,1,6]  R1642     -2.6806166395545006e-02
    z[3,1,6]  R1643     -1.4414816163480282e-02
    z[3,1,6]  R1644     1.2441301345825195e-01
    z[3,1,6]  R1645     7.5026132166385651e-02
    z[3,1,6]  R1646     2.2135600447654724e-01
    z[3,1,6]  R1647     -6.8161681294441223e-02
    z[3,1,6]  R1648     1.3272415101528168e-01
    z[3,1,6]  R1649     -5.1599580049514771e-01
    z[3,1,6]  R1650     1.3522616028785706e-01
    z[3,1,6]  R1651     3.6488026380538940e-02
    z[3,1,6]  R1652     -3.7991631776094437e-02
    z[3,1,6]  R1653     -1.1893206089735031e-01
    z[3,1,6]  R1654     1.5725551545619965e-01
    z[1,4,0]  R11       -1
    z[1,4,0]  R38       1
    z[1,4,0]  R1655     -1
    z[1,4,0]  R1656     1
    z[1,4,0]  R1669     4.4048145413398743e-01
    z[1,4,0]  R1670     4.4716534018516541e-01
    z[1,4,0]  R1671     3.1553784012794495e-01
    z[1,4,0]  R1672     2.1296481788158417e-01
    z[1,4,0]  R1673     2.0398156344890594e-01
    z[1,4,0]  R1674     1.4513950049877167e-01
    z[1,4,0]  R1675     4.2035266757011414e-01
    z[1,4,0]  R1676     1.8896244466304779e-01
    z[1,4,0]  R1677     2.6948067545890808e-01
    z[1,4,0]  R1678     5.3773349523544312e-01
    z[1,4,0]  R1679     -8.8005030155181885e-01
    z[1,4,0]  R1680     -8.4766268730163574e-01
    z[1,4,0]  R1681     -8.9489394426345825e-01
    z[1,4,0]  R1682     5.6491714715957642e-01
    z[1,4,0]  R1683     6.4999121427536011e-01
    z[1,4,0]  R1684     5.7755821943283081e-01
    z[1,4,0]  R1685     1.8908669054508209e-01
    z[1,4,0]  R1686     6.9569748640060425e-01
    z[1,4,0]  R1687     5.9627151489257812e-01
    z[1,4,0]  R1688     5.2757942676544189e-01
    z[1,4,0]  R1689     -3.5752275586128235e-01
    z[1,4,0]  R1690     -2.9642897844314575e-01
    z[1,4,0]  R1691     -6.3600605726242065e-01
    z[1,4,0]  R1692     -3.5773396492004395e-01
    z[1,4,0]  R1693     -1.8340660631656647e-01
    z[1,4,0]  R1694     -3.7775182723999023e-01
    z[1,4,0]  R1695     -3.4659394621849060e-01
    z[1,4,0]  R1696     6.2411874532699585e-02
    z[1,4,0]  R1697     4.5564625412225723e-02
    z[1,4,0]  R1698     -5.1198780536651611e-01
    z[1,4,0]  R1699     -4.8201125860214233e-01
    z[1,4,0]  R1700     -5.8650255203247070e-01
    z[1,4,0]  R1701     -4.3368390202522278e-01
    z[1,4,0]  R1702     -7.5530534982681274e-01
    z[1,4,0]  R1703     0.0590699128806591
    z[1,4,0]  R1704     -3.6986050009727478e-01
    z[1,4,0]  R1705     1.0634465515613556e-01
    z[1,4,0]  R1706     4.4743397831916809e-01
    z[1,4,0]  R1707     1.4682547748088837e-01
    z[1,4,0]  R1708     0.00492557417601347
    z[1,4,0]  R1709     -4.5591101050376892e-01
    z[1,4,0]  R1710     -6.2477695941925049e-01
    z[1,4,0]  R1711     1.2044054269790649e-01
    z[1,4,0]  R1712     2.5214740633964539e-01
    z[1,4,0]  R1713     1.6487506031990051e-01
    z[1,4,0]  R1714     -3.5710880160331726e-01
    z[1,4,0]  R1715     -2.3909138143062592e-01
    z[1,4,0]  R1716     -4.0107741951942444e-01
    z[1,4,0]  R1717     -2.8470501303672791e-01
    z[1,4,0]  R1718     6.0285080224275589e-02
    z[1,4,0]  R1719     -4.5614802837371826e-01
    z[1,4,0]  R1720     1.6883884370326996e-01
    z[1,4,0]  R1721     -5.7301348447799683e-01
    z[1,4,0]  R1722     -6.5560430288314819e-01
    z[1,4,0]  R1723     4.6026740223169327e-02
    z[1,4,0]  R1724     5.9459650516510010e-01
    z[1,4,0]  R1725     -8.1936977803707123e-03
    z[1,4,0]  R1726     -2.8132265806198120e-01
    z[1,4,0]  R1727     -3.0873646959662437e-02
    z[1,4,0]  R1728     6.2525354325771332e-02
    z[1,4,0]  R1729     -6.5801465511322021e-01
    z[1,4,0]  R1730     3.9888685941696167e-01
    z[1,4,0]  R1731     -7.6452434062957764e-01
    z[1,4,0]  R1732     7.1891725063323975e-01
    z[1,4,0]  R1733     1.0193198919296265e-01
    z[1,4,0]  R1734     4.0106898546218872e-01
    z[1,4,0]  R1735     -1.0802744328975677e-01
    z[1,4,0]  R1736     -2.2934605181217194e-01
    z[1,4,0]  R1737     -2.3645068705081940e-01
    z[1,4,0]  R1738     -6.9124542176723480e-02
    z[1,4,0]  R1739     -6.0876989364624023e-01
    z[1,4,0]  R1740     -4.0712639689445496e-01
    z[1,4,0]  R1741     -1.0106655955314636e-01
    z[1,4,0]  R1742     -1.8882115185260773e-01
    z[1,4,0]  R1743     3.2330492138862610e-01
    z[1,4,0]  R1744     -1.0135262459516525e-01
    z[1,4,0]  R1745     -2.3631669580936432e-02
    z[1,4,0]  R1746     2.9480382800102234e-02
    z[1,4,0]  R1747     -2.4920843541622162e-01
    z[1,4,0]  R1748     -1.4453461766242981e-01
    z[1,4,0]  R1749     -6.4922505617141724e-01
    z[1,4,0]  R1750     -6.0427713394165039e-01
    z[1,4,0]  R1751     7.9296268522739410e-02
    z[1,4,0]  R1752     5.6043070554733276e-01
    z[1,4,0]  R1753     -5.7753247022628784e-01
    z[1,4,0]  R1754     1.8766084313392639e-01
    z[1,4,0]  R1755     8.5992045700550079e-02
    z[1,4,0]  R1756     2.0371274650096893e-01
    z[1,4,0]  R1757     1.2180276960134506e-01
    z[1,4,0]  R1758     2.2687834501266479e-01
    z[1,4,0]  R1759     5.5870389938354492e-01
    z[1,4,0]  R1760     9.9818736314773560e-02
    z[1,4,0]  R1761     -2.0530523732304573e-02
    z[1,4,0]  R1762     8.2103852182626724e-03
    z[1,4,0]  R1763     -1.4202977716922760e-01
    z[1,4,0]  R1764     -4.8766386508941650e-01
    z[1,4,0]  R1765     -1.5281499922275543e-01
    z[1,4,0]  R1766     8.8300663232803345e-01
    z[1,4,0]  R1767     7.5461864471435547e-01
    z[1,4,0]  R1768     8.5505962371826172e-01
    z[1,4,0]  R1769     -7.1266913414001465e-01
    z[1,4,0]  R1770     -0.489612340927124
    z[1,4,0]  R1771     -6.8424749374389648e-01
    z[1,4,0]  R1772     -5.7680004835128784e-01
    z[1,4,0]  R1773     -0.0508616641163826
    z[1,4,0]  R1774     9.8354585468769073e-02
    z[1,4,0]  R1775     -1.6463661193847656e-01
    z[1,4,0]  R1776     -2.3018735647201538e-01
    z[1,4,0]  R1777     -2.4711753427982330e-01
    z[1,4,0]  R1778     -7.2288691997528076e-02
    z[1,4,0]  R1779     -5.7580053806304932e-01
    z[1,4,0]  R1780     2.5338813662528992e-01
    z[1,4,0]  R1781     2.2624200209975243e-02
    z[1,4,0]  R1782     4.2387198656797409e-02
    z[1,4,0]  R1783     4.6951755881309509e-02
    z[1,4,0]  R1784     1.1479977518320084e-01
    z[1,4,0]  R1785     -7.6783820986747742e-03
    z[1,4,0]  R1786     -4.7213941812515259e-02
    z[1,4,0]  R1787     2.0390398800373077e-01
    z[1,4,0]  R1788     4.9588415771722794e-02
    z[1,4,0]  R1789     -0.370315819978714
    z[1,4,0]  R1790     -4.2799603939056396e-01
    z[1,4,0]  R1791     2.4122430384159088e-01
    z[1,4,0]  R1792     0.111538365483284
    z[1,4,0]  R1793     2.3198957741260529e-01
    z[1,4,0]  R1794     2.9266181588172913e-01
    z[1,4,0]  R1795     -2.6075911521911621e-01
    z[1,4,0]  R1796     0.12830850481987
    z[1,4,0]  R1797     2.7927669882774353e-01
    z[1,4,0]  R1798     2.9127854108810425e-01
    z[1,4,1]  R12       -1
    z[1,4,1]  R39       1
    z[1,4,1]  R1657     -1
    z[1,4,1]  R1658     1
    z[1,4,1]  R1669     7.6852989196777344e-01
    z[1,4,1]  R1670     7.1061855554580688e-01
    z[1,4,1]  R1671     6.9127148389816284e-01
    z[1,4,1]  R1672     6.7748028039932251e-01
    z[1,4,1]  R1673     6.6225379705429077e-01
    z[1,4,1]  R1674     0.657947301864624
    z[1,4,1]  R1675     6.5257954597473145e-01
    z[1,4,1]  R1676     6.5442794561386108e-01
    z[1,4,1]  R1677     6.3109076023101807e-01
    z[1,4,1]  R1678     6.2716007232666016e-01
    z[1,4,1]  R1679     1.3539300300180912e-02
    z[1,4,1]  R1680     -0.0493953637778759
    z[1,4,1]  R1681     -4.1284445673227310e-02
    z[1,4,1]  R1682     -5.1278859376907349e-01
    z[1,4,1]  R1683     -5.4661726951599121e-01
    z[1,4,1]  R1684     -4.9537131190299988e-01
    z[1,4,1]  R1685     -5.5065184831619263e-01
    z[1,4,1]  R1686     -4.6201971173286438e-01
    z[1,4,1]  R1687     -6.0528641939163208e-01
    z[1,4,1]  R1688     -3.8753968477249146e-01
    z[1,4,1]  R1689     2.2777329385280609e-01
    z[1,4,1]  R1690     3.5794261097908020e-01
    z[1,4,1]  R1691     -0.0707663968205452
    z[1,4,1]  R1692     2.1073617041110992e-01
    z[1,4,1]  R1693     2.3412954807281494e-01
    z[1,4,1]  R1694     2.5247669219970703e-01
    z[1,4,1]  R1695     1.3208749890327454e-01
    z[1,4,1]  R1696     6.7550706863403320e-01
    z[1,4,1]  R1697     6.7064303159713745e-01
    z[1,4,1]  R1698     -4.9852974712848663e-02
    z[1,4,1]  R1699     4.2516711354255676e-01
    z[1,4,1]  R1700     2.7613270282745361e-01
    z[1,4,1]  R1701     2.8282597661018372e-01
    z[1,4,1]  R1702     4.4181060791015625e-01
    z[1,4,1]  R1703     -1.9234298169612885e-01
    z[1,4,1]  R1704     1.0171489417552948e-01
    z[1,4,1]  R1705     5.7744336128234863e-01
    z[1,4,1]  R1706     -5.2219372987747192e-01
    z[1,4,1]  R1707     -3.1241990625858307e-02
    z[1,4,1]  R1708     5.3227978944778442e-01
    z[1,4,1]  R1709     3.8184702396392822e-01
    z[1,4,1]  R1710     -2.7537789195775986e-02
    z[1,4,1]  R1711     8.5406959056854248e-01
    z[1,4,1]  R1712     8.1836843490600586e-01
    z[1,4,1]  R1713     2.6267403364181519e-01
    z[1,4,1]  R1714     1.3385763764381409e-01
    z[1,4,1]  R1715     2.5609949231147766e-01
    z[1,4,1]  R1716     8.2399033010005951e-02
    z[1,4,1]  R1717     2.4601301550865173e-01
    z[1,4,1]  R1718     6.1969733238220215e-01
    z[1,4,1]  R1719     4.0898019075393677e-01
    z[1,4,1]  R1720     6.4176046848297119e-01
    z[1,4,1]  R1721     1.0565433651208878e-01
    z[1,4,1]  R1722     1.3106757402420044e-01
    z[1,4,1]  R1723     9.3674689531326294e-01
    z[1,4,1]  R1724     5.0609749555587769e-01
    z[1,4,1]  R1725     4.6355494856834412e-01
    z[1,4,1]  R1726     0.284940242767334
    z[1,4,1]  R1727     2.8398683294653893e-02
    z[1,4,1]  R1728     2.4847318232059479e-01
    z[1,4,1]  R1729     2.6605013012886047e-01
    z[1,4,1]  R1730     8.0469900369644165e-01
    z[1,4,1]  R1731     4.4193947315216064e-01
    z[1,4,1]  R1732     -5.1152259111404419e-01
    z[1,4,1]  R1733     -4.2723175883293152e-01
    z[1,4,1]  R1734     -4.2270788550376892e-01
    z[1,4,1]  R1735     -2.3982043564319611e-01
    z[1,4,1]  R1736     -9.1337114572525024e-01
    z[1,4,1]  R1737     -8.7942677736282349e-01
    z[1,4,1]  R1738     -2.8539735078811646e-01
    z[1,4,1]  R1739     3.4915563464164734e-01
    z[1,4,1]  R1740     3.8095399737358093e-01
    z[1,4,1]  R1741     5.5673009157180786e-01
    z[1,4,1]  R1742     -1.8500310182571411e-01
    z[1,4,1]  R1743     -3.9021816849708557e-01
    z[1,4,1]  R1744     3.8227722048759460e-02
    z[1,4,1]  R1745     -2.0226265490055084e-01
    z[1,4,1]  R1746     5.9279982000589371e-02
    z[1,4,1]  R1747     -0.926781177520752
    z[1,4,1]  R1748     -7.5965744256973267e-01
    z[1,4,1]  R1749     1.5500506758689880e-01
    z[1,4,1]  R1750     7.0526483468711376e-03
    z[1,4,1]  R1751     9.5337331295013428e-01
    z[1,4,1]  R1752     -6.2721198797225952e-01
    z[1,4,1]  R1753     3.7929084897041321e-01
    z[1,4,1]  R1754     -1.0878720879554749e-01
    z[1,4,1]  R1755     -3.3713793754577637e-01
    z[1,4,1]  R1756     -3.9753583073616028e-01
    z[1,4,1]  R1757     -0.273084819316864
    z[1,4,1]  R1758     -3.3717691898345947e-01
    z[1,4,1]  R1759     5.6021219491958618e-01
    z[1,4,1]  R1760     7.8178036212921143e-01
    z[1,4,1]  R1761     7.5345677137374878e-01
    z[1,4,1]  R1762     3.8890364766120911e-01
    z[1,4,1]  R1763     4.9546009302139282e-01
    z[1,4,1]  R1764     1.8506301939487457e-01
    z[1,4,1]  R1765     1.7123848199844360e-01
    z[1,4,1]  R1766     3.8786649703979492e-02
    z[1,4,1]  R1767     -2.4267809092998505e-01
    z[1,4,1]  R1768     -2.5800105929374695e-01
    z[1,4,1]  R1769     -1.9565564393997192e-01
    z[1,4,1]  R1770     -1.5061859786510468e-01
    z[1,4,1]  R1771     -3.5446065664291382e-01
    z[1,4,1]  R1772     -3.8342043757438660e-01
    z[1,4,1]  R1773     -8.9201897382736206e-01
    z[1,4,1]  R1774     -7.1640813350677490e-01
    z[1,4,1]  R1775     -7.1327060461044312e-01
    z[1,4,1]  R1776     -4.8758310079574585e-01
    z[1,4,1]  R1777     -8.1594669818878174e-01
    z[1,4,1]  R1778     -6.2656390666961670e-01
    z[1,4,1]  R1779     1.0611204802989960e-01
    z[1,4,1]  R1780     -4.4901618361473083e-01
    z[1,4,1]  R1781     -7.4879795312881470e-01
    z[1,4,1]  R1782     -8.4246599674224854e-01
    z[1,4,1]  R1783     -7.3599445819854736e-01
    z[1,4,1]  R1784     -7.6748752593994141e-01
    z[1,4,1]  R1785     -8.7122011184692383e-01
    z[1,4,1]  R1786     -0.759326159954071
    z[1,4,1]  R1787     -8.7563234567642212e-01
    z[1,4,1]  R1788     -9.0224641561508179e-01
    z[1,4,1]  R1789     4.2711898684501648e-01
    z[1,4,1]  R1790     1.1950732767581940e-01
    z[1,4,1]  R1791     -7.9304671287536621e-01
    z[1,4,1]  R1792     -6.9904738664627075e-01
    z[1,4,1]  R1793     -8.7748444080352783e-01
    z[1,4,1]  R1794     -8.8935530185699463e-01
    z[1,4,1]  R1795     -7.5103670358657837e-01
    z[1,4,1]  R1796     -8.4581160545349121e-01
    z[1,4,1]  R1797     -1.1033361405134201e-01
    z[1,4,1]  R1798     -6.0323875397443771e-02
    z[1,4,2]  R13       -1
    z[1,4,2]  R40       1
    z[1,4,2]  R1659     -1
    z[1,4,2]  R1660     1
    z[1,4,2]  R1669     1.9762471318244934e-01
    z[1,4,2]  R1670     1.8094404041767120e-01
    z[1,4,2]  R1671     1.7155742272734642e-02
    z[1,4,2]  R1672     2.3242124915122986e-01
    z[1,4,2]  R1673     2.0797017216682434e-01
    z[1,4,2]  R1674     3.0362471938133240e-01
    z[1,4,2]  R1675     1.5505865216255188e-01
    z[1,4,2]  R1676     1.7621801793575287e-01
    z[1,4,2]  R1677     1.8051068484783173e-01
    z[1,4,2]  R1678     -1.3206172734498978e-02
    z[1,4,2]  R1679     -6.9564029574394226e-02
    z[1,4,2]  R1680     1.7230573296546936e-01
    z[1,4,2]  R1681     1.7138895392417908e-01
    z[1,4,2]  R1682     -1.4812509715557098e-01
    z[1,4,2]  R1683     -1.6373504698276520e-01
    z[1,4,2]  R1684     -2.1429817378520966e-01
    z[1,4,2]  R1685     -2.5060099363327026e-01
    z[1,4,2]  R1686     -6.6603772342205048e-02
    z[1,4,2]  R1687     4.1931409388780594e-02
    z[1,4,2]  R1688     -1.5611787140369415e-01
    z[1,4,2]  R1689     2.7155104279518127e-01
    z[1,4,2]  R1690     -1.2577632069587708e-01
    z[1,4,2]  R1691     -2.7121728658676147e-01
    z[1,4,2]  R1692     0.0661039724946022
    z[1,4,2]  R1693     -5.5829749908298254e-04
    z[1,4,2]  R1694     -1.6054630279541016e-01
    z[1,4,2]  R1695     1.1115300655364990e-01
    z[1,4,2]  R1696     -0.4558085501194
    z[1,4,2]  R1697     -4.5450708270072937e-01
    z[1,4,2]  R1698     6.2247227877378464e-02
    z[1,4,2]  R1699     4.6318256855010986e-01
    z[1,4,2]  R1700     4.2427086830139160e-01
    z[1,4,2]  R1701     1.3735873997211456e-01
    z[1,4,2]  R1702     -2.5027480721473694e-01
    z[1,4,2]  R1703     1.4518241398036480e-02
    z[1,4,2]  R1704     3.6463406682014465e-01
    z[1,4,2]  R1705     -3.2373934984207153e-01
    z[1,4,2]  R1706     4.8716405034065247e-01
    z[1,4,2]  R1707     3.8003337383270264e-01
    z[1,4,2]  R1708     -1.1138872057199478e-01
    z[1,4,2]  R1709     6.1045867204666138e-01
    z[1,4,2]  R1710     -1.4914770424365997e-01
    z[1,4,2]  R1711     -3.2510453462600708e-01
    z[1,4,2]  R1712     -2.3592798411846161e-01
    z[1,4,2]  R1713     -3.6896771192550659e-01
    z[1,4,2]  R1714     8.4914974868297577e-02
    z[1,4,2]  R1715     2.3748025298118591e-01
    z[1,4,2]  R1716     -4.6754304319620132e-02
    z[1,4,2]  R1717     4.0193051099777222e-01
    z[1,4,2]  R1718     -3.2748410105705261e-01
    z[1,4,2]  R1719     3.2034772634506226e-01
    z[1,4,2]  R1720     3.4528324007987976e-01
    z[1,4,2]  R1721     -9.6078209578990936e-02
    z[1,4,2]  R1722     -2.2535999119281769e-01
    z[1,4,2]  R1723     -2.2950629889965057e-01
    z[1,4,2]  R1724     -1.9488035142421722e-01
    z[1,4,2]  R1725     -1.3908736407756805e-01
    z[1,4,2]  R1726     3.8566029071807861e-01
    z[1,4,2]  R1727     -1.7290504276752472e-01
    z[1,4,2]  R1728     -5.4297423362731934e-01
    z[1,4,2]  R1729     1.8496979773044586e-01
    z[1,4,2]  R1730     -0.244472473859787
    z[1,4,2]  R1731     -2.9634317755699158e-01
    z[1,4,2]  R1732     3.2215365767478943e-01
    z[1,4,2]  R1733     1.1727154999971390e-01
    z[1,4,2]  R1734     5.3423233330249786e-02
    z[1,4,2]  R1735     3.2155385613441467e-01
    z[1,4,2]  R1736     1.3224214315414429e-01
    z[1,4,2]  R1737     1.9594286382198334e-01
    z[1,4,2]  R1738     2.3662203550338745e-01
    z[1,4,2]  R1739     2.2422102093696594e-01
    z[1,4,2]  R1740     4.1424378752708435e-01
    z[1,4,2]  R1741     -4.9048945307731628e-01
    z[1,4,2]  R1742     4.3830013275146484e-01
    z[1,4,2]  R1743     0.417977511882782
    z[1,4,2]  R1744     4.0899294614791870e-01
    z[1,4,2]  R1745     2.4501444399356842e-01
    z[1,4,2]  R1746     -1.8349802494049072e-01
    z[1,4,2]  R1747     1.4926487207412720e-01
    z[1,4,2]  R1748     3.8419011235237122e-01
    z[1,4,2]  R1749     2.4462023377418518e-01
    z[1,4,2]  R1750     -1.4788176119327545e-01
    z[1,4,2]  R1751     -4.7778464853763580e-02
    z[1,4,2]  R1752     1.4802455902099609e-01
    z[1,4,2]  R1753     -4.2650622129440308e-01
    z[1,4,2]  R1754     4.7915931791067123e-03
    z[1,4,2]  R1755     -8.4596776962280273e-01
    z[1,4,2]  R1756     -7.6929843425750732e-01
    z[1,4,2]  R1757     -8.8198131322860718e-01
    z[1,4,2]  R1758     -8.0463838577270508e-01
    z[1,4,2]  R1759     -3.8512402772903442e-01
    z[1,4,2]  R1760     5.6504216045141220e-02
    z[1,4,2]  R1761     -3.9413750171661377e-01
    z[1,4,2]  R1762     1.1042091995477676e-01
    z[1,4,2]  R1763     1.2807871401309967e-01
    z[1,4,2]  R1764     1.2600994668900967e-02
    z[1,4,2]  R1765     1.0695854574441910e-01
    z[1,4,2]  R1766     3.7434976547956467e-02
    z[1,4,2]  R1767     1.3555747270584106e-01
    z[1,4,2]  R1768     -0.0625605583190918
    z[1,4,2]  R1769     0.49066162109375
    z[1,4,2]  R1770     3.7475490570068359e-01
    z[1,4,2]  R1771     -1.8631502985954285e-01
    z[1,4,2]  R1772     -5.3598236292600632e-02
    z[1,4,2]  R1773     -9.7490988671779633e-02
    z[1,4,2]  R1774     -5.3910166025161743e-01
    z[1,4,2]  R1775     -1.0701456665992737e-01
    z[1,4,2]  R1776     -3.9065742492675781e-01
    z[1,4,2]  R1777     -7.0837214589118958e-02
    z[1,4,2]  R1778     -4.8441314697265625e-01
    z[1,4,2]  R1779     -1.2420298904180527e-01
    z[1,4,2]  R1780     -3.6703076958656311e-01
    z[1,4,2]  R1781     -8.0870762467384338e-02
    z[1,4,2]  R1782     -1.6054618358612061e-01
    z[1,4,2]  R1783     -1.4383193850517273e-01
    z[1,4,2]  R1784     -2.4992391467094421e-01
    z[1,4,2]  R1785     -8.3724528551101685e-02
    z[1,4,2]  R1786     3.0607774853706360e-01
    z[1,4,2]  R1787     3.2696709036827087e-01
    z[1,4,2]  R1788     2.2576428949832916e-01
    z[1,4,2]  R1789     -3.0090728402137756e-01
    z[1,4,2]  R1790     -2.3227781057357788e-01
    z[1,4,2]  R1791     -1.1948853731155396e-01
    z[1,4,2]  R1792     -1.9092109799385071e-01
    z[1,4,2]  R1793     3.3038997650146484e-01
    z[1,4,2]  R1794     1.7247335612773895e-01
    z[1,4,2]  R1795     -6.6403280943632126e-03
    z[1,4,2]  R1796     3.6510783433914185e-01
    z[1,4,2]  R1797     -7.7136582136154175e-01
    z[1,4,2]  R1798     -0.623135507106781
    z[1,4,3]  R14       -1
    z[1,4,3]  R41       1
    z[1,4,3]  R1661     -1
    z[1,4,3]  R1662     1
    z[1,4,3]  R1669     2.4325282871723175e-01
    z[1,4,3]  R1670     -2.9130894690752029e-02
    z[1,4,3]  R1671     -2.5148457288742065e-01
    z[1,4,3]  R1672     1.2540750205516815e-01
    z[1,4,3]  R1673     -6.9350488483905792e-02
    z[1,4,3]  R1674     -2.2384946048259735e-01
    z[1,4,3]  R1675     -1.5611016750335693e-01
    z[1,4,3]  R1676     0.351661741733551
    z[1,4,3]  R1677     -1.9590289890766144e-01
    z[1,4,3]  R1678     -1.4304912090301514e-01
    z[1,4,3]  R1679     2.1276351809501648e-01
    z[1,4,3]  R1680     2.3736884817481041e-02
    z[1,4,3]  R1681     2.3033104836940765e-01
    z[1,4,3]  R1682     -5.3111881017684937e-01
    z[1,4,3]  R1683     -4.1673696041107178e-01
    z[1,4,3]  R1684     -6.0401380062103271e-01
    z[1,4,3]  R1685     -7.1226024627685547e-01
    z[1,4,3]  R1686     -5.0312846899032593e-01
    z[1,4,3]  R1687     -3.5064321756362915e-01
    z[1,4,3]  R1688     -6.3387966156005859e-01
    z[1,4,3]  R1689     -6.4800351858139038e-01
    z[1,4,3]  R1690     -7.8793352842330933e-01
    z[1,4,3]  R1691     -1.7942821979522705e-01
    z[1,4,3]  R1692     -0.599696934223175
    z[1,4,3]  R1693     -9.0880846977233887e-01
    z[1,4,3]  R1694     -0.678071916103363
    z[1,4,3]  R1695     -3.2827010750770569e-01
    z[1,4,3]  R1696     -3.1030055880546570e-01
    z[1,4,3]  R1697     -5.1563370227813721e-01
    z[1,4,3]  R1698     -4.5084246993064880e-01
    z[1,4,3]  R1699     4.4007804989814758e-01
    z[1,4,3]  R1700     3.3346137404441833e-01
    z[1,4,3]  R1701     1.2889523059129715e-02
    z[1,4,3]  R1702     -2.9720512032508850e-01
    z[1,4,3]  R1703     -0.571692705154419
    z[1,4,3]  R1704     -3.4564909338951111e-01
    z[1,4,3]  R1705     -2.9619028791785240e-03
    z[1,4,3]  R1706     2.4839065968990326e-01
    z[1,4,3]  R1707     8.3537089824676514e-01
    z[1,4,3]  R1708     6.5786695480346680e-01
    z[1,4,3]  R1709     -4.3137678503990173e-01
    z[1,4,3]  R1710     -2.2906927764415741e-01
    z[1,4,3]  R1711     -2.2457545623183250e-02
    z[1,4,3]  R1712     -8.8043145835399628e-02
    z[1,4,3]  R1713     -7.6031464338302612e-01
    z[1,4,3]  R1714     -4.3721115589141846e-01
    z[1,4,3]  R1715     -1.2719729542732239e-01
    z[1,4,3]  R1716     -4.4476732611656189e-01
    z[1,4,3]  R1717     2.0254816114902496e-01
    z[1,4,3]  R1718     1.8693853914737701e-01
    z[1,4,3]  R1719     -4.4414305686950684e-01
    z[1,4,3]  R1720     4.7506517171859741e-01
    z[1,4,3]  R1721     -1.5171146392822266e-01
    z[1,4,3]  R1722     -4.6923705935478210e-01
    z[1,4,3]  R1723     2.3001782596111298e-02
    z[1,4,3]  R1724     1.2662726454436779e-02
    z[1,4,3]  R1725     -0.766851007938385
    z[1,4,3]  R1726     1.9679950177669525e-01
    z[1,4,3]  R1727     -8.5443496704101562e-01
    z[1,4,3]  R1728     -7.1599733829498291e-01
    z[1,4,3]  R1729     -0.621579110622406
    z[1,4,3]  R1730     -1.8579454720020294e-01
    z[1,4,3]  R1731     -3.1899437308311462e-01
    z[1,4,3]  R1732     2.7757775783538818e-01
    z[1,4,3]  R1733     -3.3909055590629578e-01
    z[1,4,3]  R1734     1.6180644929409027e-01
    z[1,4,3]  R1735     7.4454855918884277e-01
    z[1,4,3]  R1736     2.3615576326847076e-02
    z[1,4,3]  R1737     -6.1152640730142593e-02
    z[1,4,3]  R1738     6.6606956720352173e-01
    z[1,4,3]  R1739     -2.6376655697822571e-01
    z[1,4,3]  R1740     2.7661317586898804e-01
    z[1,4,3]  R1741     -4.9569407105445862e-01
    z[1,4,3]  R1742     7.1560466289520264e-01
    z[1,4,3]  R1743     1.2439829856157303e-01
    z[1,4,3]  R1744     8.8599252700805664e-01
    z[1,4,3]  R1745     8.0509597063064575e-01
    z[1,4,3]  R1746     9.6395754814147949e-01
    z[1,4,3]  R1747     1.3031853735446930e-01
    z[1,4,3]  R1748     4.5830440521240234e-01
    z[1,4,3]  R1749     2.2185295820236206e-01
    z[1,4,3]  R1750     -3.4237092733383179e-01
    z[1,4,3]  R1751     1.3089454174041748e-01
    z[1,4,3]  R1752     1.9845359027385712e-02
    z[1,4,3]  R1753     -1.9326542317867279e-01
    z[1,4,3]  R1754     -5.7583391666412354e-01
    z[1,4,3]  R1755     0.336665540933609
    z[1,4,3]  R1756     3.8043934106826782e-01
    z[1,4,3]  R1757     3.3475691080093384e-01
    z[1,4,3]  R1758     3.3808118104934692e-01
    z[1,4,3]  R1759     -3.8021820783615112e-01
    z[1,4,3]  R1760     -4.8384204506874084e-01
    z[1,4,3]  R1761     -3.6220863461494446e-01
    z[1,4,3]  R1762     -4.1754421591758728e-01
    z[1,4,3]  R1763     -2.9438000917434692e-01
    z[1,4,3]  R1764     -3.1255516409873962e-01
    z[1,4,3]  R1765     6.8910324573516846e-01
    z[1,4,3]  R1766     -3.0642330646514893e-01
    z[1,4,3]  R1767     -0.398311972618103
    z[1,4,3]  R1768     -2.8055045008659363e-01
    z[1,4,3]  R1769     2.8187143802642822e-01
    z[1,4,3]  R1770     4.5860681682825089e-02
    z[1,4,3]  R1771     -2.4828857183456421e-01
    z[1,4,3]  R1772     -1.3207701034843922e-02
    z[1,4,3]  R1773     -8.9316688477993011e-02
    z[1,4,3]  R1774     -2.1141889691352844e-01
    z[1,4,3]  R1775     9.3292370438575745e-02
    z[1,4,3]  R1776     -3.2621735334396362e-01
    z[1,4,3]  R1777     -1.0185866057872772e-01
    z[1,4,3]  R1778     -3.8146099448204041e-01
    z[1,4,3]  R1779     3.0751854181289673e-01
    z[1,4,3]  R1780     -6.9934684038162231e-01
    z[1,4,3]  R1781     -3.2809826731681824e-01
    z[1,4,3]  R1782     -3.1848379969596863e-01
    z[1,4,3]  R1783     -3.9895847439765930e-01
    z[1,4,3]  R1784     -3.7319111824035645e-01
    z[1,4,3]  R1785     3.6862384527921677e-02
    z[1,4,3]  R1786     8.2869239151477814e-02
    z[1,4,3]  R1787     2.8244696557521820e-02
    z[1,4,3]  R1788     -5.6988544762134552e-02
    z[1,4,3]  R1789     4.1068476438522339e-01
    z[1,4,3]  R1790     3.7810587882995605e-01
    z[1,4,3]  R1791     -3.4058916568756104e-01
    z[1,4,3]  R1792     -5.4312676191329956e-01
    z[1,4,3]  R1793     -9.5807880163192749e-02
    z[1,4,3]  R1794     2.8587602078914642e-02
    z[1,4,3]  R1795     -3.5784307122230530e-01
    z[1,4,3]  R1796     2.3451048135757446e-01
    z[1,4,3]  R1797     4.9130004644393921e-01
    z[1,4,3]  R1798     4.0348741412162781e-01
    z[1,4,4]  R15       -1
    z[1,4,4]  R42       1
    z[1,4,4]  R1663     -1
    z[1,4,4]  R1664     1
    z[1,4,4]  R1669     3.9067290723323822e-02
    z[1,4,4]  R1670     -2.8967443108558655e-01
    z[1,4,4]  R1671     5.9735560417175293e-01
    z[1,4,4]  R1672     1.1907239258289337e-01
    z[1,4,4]  R1673     -2.6911571621894836e-01
    z[1,4,4]  R1674     -4.7039699554443359e-01
    z[1,4,4]  R1675     2.0863448083400726e-01
    z[1,4,4]  R1676     3.7537318468093872e-01
    z[1,4,4]  R1677     -4.9597907066345215e-01
    z[1,4,4]  R1678     0.436262845993042
    z[1,4,4]  R1679     2.0806825160980225e-01
    z[1,4,4]  R1680     -4.7438085079193115e-01
    z[1,4,4]  R1681     -1.6129940748214722e-01
    z[1,4,4]  R1682     -1.7047438025474548e-01
    z[1,4,4]  R1683     1.5612085163593292e-01
    z[1,4,4]  R1684     1.6943825408816338e-02
    z[1,4,4]  R1685     -9.3334801495075226e-03
    z[1,4,4]  R1686     1.4701751992106438e-02
    z[1,4,4]  R1687     2.4286296218633652e-02
    z[1,4,4]  R1688     6.5779253840446472e-02
    z[1,4,4]  R1689     6.7274391651153564e-02
    z[1,4,4]  R1690     -5.7650838047266006e-02
    z[1,4,4]  R1691     2.0311267673969269e-01
    z[1,4,4]  R1692     2.9101410508155823e-01
    z[1,4,4]  R1693     2.6428506243973970e-03
    z[1,4,4]  R1694     2.0727189257740974e-02
    z[1,4,4]  R1695     4.8381105065345764e-01
    z[1,4,4]  R1696     2.1485836803913116e-01
    z[1,4,4]  R1697     1.8651841580867767e-01
    z[1,4,4]  R1698     6.1027181148529053e-01
    z[1,4,4]  R1699     2.7737993001937866e-01
    z[1,4,4]  R1700     3.2691791653633118e-01
    z[1,4,4]  R1701     -3.2753947377204895e-01
    z[1,4,4]  R1702     -1.5371769666671753e-01
    z[1,4,4]  R1703     1.7633976042270660e-01
    z[1,4,4]  R1704     1.0239803791046143e-01
    z[1,4,4]  R1705     2.8421280905604362e-02
    z[1,4,4]  R1706     -1.8215529620647430e-02
    z[1,4,4]  R1707     4.5270342379808426e-02
    z[1,4,4]  R1708     -2.9345223307609558e-01
    z[1,4,4]  R1709     -9.8966039717197418e-02
    z[1,4,4]  R1710     5.8230036497116089e-01
    z[1,4,4]  R1711     -7.7445581555366516e-02
    z[1,4,4]  R1712     5.4957754909992218e-02
    z[1,4,4]  R1713     0.0887366533279419
    z[1,4,4]  R1714     1.2271800637245178e-01
    z[1,4,4]  R1715     1.7630773782730103e-01
    z[1,4,4]  R1716     -2.7799794077873230e-01
    z[1,4,4]  R1717     -2.6498362421989441e-01
    z[1,4,4]  R1718     4.8734968900680542e-01
    z[1,4,4]  R1719     2.7661731839179993e-01
    z[1,4,4]  R1720     -3.4113430976867676e-01
    z[1,4,4]  R1721     0.190584197640419
    z[1,4,4]  R1722     4.2454391717910767e-01
    z[1,4,4]  R1723     6.2954194843769073e-02
    z[1,4,4]  R1724     5.1860720850527287e-03
    z[1,4,4]  R1725     -4.0332680940628052e-01
    z[1,4,4]  R1726     -2.6774457097053528e-01
    z[1,4,4]  R1727     4.1753351688385010e-01
    z[1,4,4]  R1728     2.6212513446807861e-01
    z[1,4,4]  R1729     -1.9029390811920166e-01
    z[1,4,4]  R1730     -1.3608361780643463e-01
    z[1,4,4]  R1731     -6.1558857560157776e-02
    z[1,4,4]  R1732     -6.4338847994804382e-02
    z[1,4,4]  R1733     5.0951063632965088e-01
    z[1,4,4]  R1734     4.8818126320838928e-01
    z[1,4,4]  R1735     2.8009146451950073e-01
    z[1,4,4]  R1736     1.1476716957986355e-02
    z[1,4,4]  R1737     -1.6288541257381439e-01
    z[1,4,4]  R1738     -2.3661302030086517e-01
    z[1,4,4]  R1739     -2.9888426885008812e-02
    z[1,4,4]  R1740     -5.2529531717300415e-01
    z[1,4,4]  R1741     1.1386800557374954e-01
    z[1,4,4]  R1742     -2.6716282963752747e-01
    z[1,4,4]  R1743     2.3903135955333710e-01
    z[1,4,4]  R1744     1.6486936807632446e-01
    z[1,4,4]  R1745     5.1504410803318024e-02
    z[1,4,4]  R1746     1.4756634831428528e-01
    z[1,4,4]  R1747     1.8596661090850830e-01
    z[1,4,4]  R1748     1.2414073944091797e-01
    z[1,4,4]  R1749     -4.9323442578315735e-01
    z[1,4,4]  R1750     3.7036576867103577e-01
    z[1,4,4]  R1751     -2.0263580977916718e-01
    z[1,4,4]  R1752     0.294387549161911
    z[1,4,4]  R1753     2.8524341061711311e-02
    z[1,4,4]  R1754     -7.0917648077011108e-01
    z[1,4,4]  R1755     1.6378301382064819e-01
    z[1,4,4]  R1756     -2.4107404053211212e-01
    z[1,4,4]  R1757     -0.0662151351571083
    z[1,4,4]  R1758     -2.0259568095207214e-01
    z[1,4,4]  R1759     -1.8614172935485840e-01
    z[1,4,4]  R1760     2.1207168698310852e-01
    z[1,4,4]  R1761     1.3169211149215698e-01
    z[1,4,4]  R1762     -5.8622401952743530e-01
    z[1,4,4]  R1763     -7.0075875520706177e-01
    z[1,4,4]  R1764     2.7352645993232727e-02
    z[1,4,4]  R1765     4.4997197389602661e-01
    z[1,4,4]  R1766     -1.1206955462694168e-01
    z[1,4,4]  R1767     -3.5753118991851807e-01
    z[1,4,4]  R1768     3.3977007865905762e-01
    z[1,4,4]  R1769     5.3274929523468018e-02
    z[1,4,4]  R1770     4.2905649542808533e-01
    z[1,4,4]  R1771     3.0451324582099915e-01
    z[1,4,4]  R1772     6.3623654842376709e-01
    z[1,4,4]  R1773     -3.5619032382965088e-01
    z[1,4,4]  R1774     -7.8622095286846161e-02
    z[1,4,4]  R1775     -1.7840167507529259e-02
    z[1,4,4]  R1776     -8.1945598125457764e-02
    z[1,4,4]  R1777     -6.9304317235946655e-02
    z[1,4,4]  R1778     -0.0410560667514801
    z[1,4,4]  R1779     -3.1161725521087646e-01
    z[1,4,4]  R1780     1.3672819733619690e-01
    z[1,4,4]  R1781     -3.2310044765472412e-01
    z[1,4,4]  R1782     8.5804097354412079e-02
    z[1,4,4]  R1783     -1.7356221377849579e-01
    z[1,4,4]  R1784     -7.4332311749458313e-02
    z[1,4,4]  R1785     -3.4329265356063843e-02
    z[1,4,4]  R1786     -3.0796703696250916e-01
    z[1,4,4]  R1787     2.1189035475254059e-01
    z[1,4,4]  R1788     5.9805028140544891e-02
    z[1,4,4]  R1789     1.9889065623283386e-01
    z[1,4,4]  R1790     -2.7678728103637695e-01
    z[1,4,4]  R1791     3.1266503036022186e-02
    z[1,4,4]  R1792     -3.5277768969535828e-01
    z[1,4,4]  R1793     -5.2817653864622116e-02
    z[1,4,4]  R1794     -1.7005857825279236e-01
    z[1,4,4]  R1795     -3.9837956428527832e-01
    z[1,4,4]  R1796     -2.1901425719261169e-01
    z[1,4,4]  R1797     -4.2809482663869858e-02
    z[1,4,4]  R1798     -4.0744204074144363e-02
    z[1,4,5]  R16       -1
    z[1,4,5]  R43       1
    z[1,4,5]  R1665     -1
    z[1,4,5]  R1666     1
    z[1,4,5]  R1669     3.3873483538627625e-01
    z[1,4,5]  R1670     1.2411311268806458e-01
    z[1,4,5]  R1671     -4.6913441270589828e-02
    z[1,4,5]  R1672     -4.4032388925552368e-01
    z[1,4,5]  R1673     -0.530138373374939
    z[1,4,5]  R1674     2.3358824849128723e-01
    z[1,4,5]  R1675     4.1394233703613281e-01
    z[1,4,5]  R1676     4.8824291676282883e-02
    z[1,4,5]  R1677     -3.9712780714035034e-01
    z[1,4,5]  R1678     2.7972424030303955e-01
    z[1,4,5]  R1679     3.5715565085411072e-01
    z[1,4,5]  R1680     -1.5061445534229279e-01
    z[1,4,5]  R1681     -8.1352427601814270e-02
    z[1,4,5]  R1682     -1.8826331198215485e-01
    z[1,4,5]  R1683     -1.8314327299594879e-01
    z[1,4,5]  R1684     2.1702989935874939e-02
    z[1,4,5]  R1685     -2.7365726232528687e-01
    z[1,4,5]  R1686     1.4367893338203430e-01
    z[1,4,5]  R1687     -2.9355597496032715e-01
    z[1,4,5]  R1688     -1.6940365731716156e-01
    z[1,4,5]  R1689     2.3928731679916382e-01
    z[1,4,5]  R1690     -2.8580215573310852e-01
    z[1,4,5]  R1691     -6.6587787866592407e-01
    z[1,4,5]  R1692     -5.1513540744781494e-01
    z[1,4,5]  R1693     2.9050523042678833e-01
    z[1,4,5]  R1694     -5.2687561511993408e-01
    z[1,4,5]  R1695     -7.1248096227645874e-01
    z[1,4,5]  R1696     -3.8606736063957214e-01
    z[1,4,5]  R1697     1.8828584253787994e-01
    z[1,4,5]  R1698     -3.4893444180488586e-01
    z[1,4,5]  R1699     2.3667345941066742e-01
    z[1,4,5]  R1700     -3.8476511836051941e-01
    z[1,4,5]  R1701     -6.4561265707015991e-01
    z[1,4,5]  R1702     -1.8605917692184448e-01
    z[1,4,5]  R1703     7.7510738372802734e-01
    z[1,4,5]  R1704     -8.8310331106185913e-02
    z[1,4,5]  R1705     -3.1413757801055908e-01
    z[1,4,5]  R1706     4.4666835665702820e-01
    z[1,4,5]  R1707     3.6467710137367249e-01
    z[1,4,5]  R1708     -3.1655681133270264e-01
    z[1,4,5]  R1709     2.3101146519184113e-01
    z[1,4,5]  R1710     -2.2347655892372131e-01
    z[1,4,5]  R1711     -2.3387621343135834e-01
    z[1,4,5]  R1712     -4.4238799810409546e-01
    z[1,4,5]  R1713     1.2042701244354248e-02
    z[1,4,5]  R1714     0.0900174155831337
    z[1,4,5]  R1715     -2.4764549732208252e-01
    z[1,4,5]  R1716     -5.9273451566696167e-01
    z[1,4,5]  R1717     2.1468596160411835e-01
    z[1,4,5]  R1718     2.5821685791015625e-02
    z[1,4,5]  R1719     4.2101528495550156e-02
    z[1,4,5]  R1720     -1.9953294098377228e-01
    z[1,4,5]  R1721     -3.8285022974014282e-01
    z[1,4,5]  R1722     -3.0303534865379333e-01
    z[1,4,5]  R1723     -2.1895058453083038e-01
    z[1,4,5]  R1724     -1.7859362065792084e-01
    z[1,4,5]  R1725     -1.2226261198520660e-01
    z[1,4,5]  R1726     8.4042645990848541e-02
    z[1,4,5]  R1727     4.6469278633594513e-02
    z[1,4,5]  R1728     -2.3661652207374573e-01
    z[1,4,5]  R1729     5.3901232779026031e-02
    z[1,4,5]  R1730     -2.5268737226724625e-02
    z[1,4,5]  R1731     1.1423484981060028e-01
    z[1,4,5]  R1732     9.2856295406818390e-02
    z[1,4,5]  R1733     6.0295450687408447e-01
    z[1,4,5]  R1734     5.0113433599472046e-01
    z[1,4,5]  R1735     1.6589875519275665e-01
    z[1,4,5]  R1736     2.8435957431793213e-01
    z[1,4,5]  R1737     3.1393593549728394e-01
    z[1,4,5]  R1738     2.0554584264755249e-01
    z[1,4,5]  R1739     5.3236478567123413e-01
    z[1,4,5]  R1740     -3.4749662876129150e-01
    z[1,4,5]  R1741     -4.1468435525894165e-01
    z[1,4,5]  R1742     3.0284056067466736e-01
    z[1,4,5]  R1743     0.639694094657898
    z[1,4,5]  R1744     0.0696791484951973
    z[1,4,5]  R1745     1.8360999226570129e-01
    z[1,4,5]  R1746     -1.0117681324481964e-01
    z[1,4,5]  R1747     7.0125319063663483e-02
    z[1,4,5]  R1748     1.1617124080657959e-01
    z[1,4,5]  R1749     4.4329819083213806e-01
    z[1,4,5]  R1750     -5.5636620521545410e-01
    z[1,4,5]  R1751     -1.4024247229099274e-01
    z[1,4,5]  R1752     4.0735453367233276e-01
    z[1,4,5]  R1753     -1.9044749438762665e-01
    z[1,4,5]  R1754     -3.1642335653305054e-01
    z[1,4,5]  R1755     -1.4758719503879547e-01
    z[1,4,5]  R1756     6.5971814095973969e-02
    z[1,4,5]  R1757     -4.5893844217061996e-02
    z[1,4,5]  R1758     8.5568435490131378e-02
    z[1,4,5]  R1759     4.5455317944288254e-02
    z[1,4,5]  R1760     3.0921491980552673e-01
    z[1,4,5]  R1761     -2.7463287115097046e-01
    z[1,4,5]  R1762     2.4353665113449097e-01
    z[1,4,5]  R1763     -3.5344031453132629e-01
    z[1,4,5]  R1764     -8.5938408970832825e-02
    z[1,4,5]  R1765     3.4604495763778687e-01
    z[1,4,5]  R1766     -3.2464957237243652e-01
    z[1,4,5]  R1767     -2.0818535983562469e-01
    z[1,4,5]  R1768     -0.0650099441409111
    z[1,4,5]  R1769     -1.1607811599969864e-01
    z[1,4,5]  R1770     -2.1920476853847504e-01
    z[1,4,5]  R1771     0.0813726931810379
    z[1,4,5]  R1772     1.1889610439538956e-02
    z[1,4,5]  R1773     -1.5509258210659027e-01
    z[1,4,5]  R1774     3.3704373240470886e-01
    z[1,4,5]  R1775     -2.8847804665565491e-01
    z[1,4,5]  R1776     -5.0170928239822388e-01
    z[1,4,5]  R1777     -2.4494219571352005e-02
    z[1,4,5]  R1778     2.9188964515924454e-02
    z[1,4,5]  R1779     5.8514147996902466e-01
    z[1,4,5]  R1780     -2.4900746345520020e-01
    z[1,4,5]  R1781     -4.3281638622283936e-01
    z[1,4,5]  R1782     -1.5920111536979675e-01
    z[1,4,5]  R1783     -3.0305919051170349e-01
    z[1,4,5]  R1784     1.8946048617362976e-01
    z[1,4,5]  R1785     9.4566307961940765e-02
    z[1,4,5]  R1786     -2.8468701243400574e-01
    z[1,4,5]  R1787     1.9625541567802429e-01
    z[1,4,5]  R1788     2.4141949415206909e-01
    z[1,4,5]  R1789     6.0804599523544312e-01
    z[1,4,5]  R1790     4.3281927704811096e-02
    z[1,4,5]  R1791     -3.9834147691726685e-01
    z[1,4,5]  R1792     2.0585153996944427e-01
    z[1,4,5]  R1793     -0.155070960521698
    z[1,4,5]  R1794     2.3658762872219086e-01
    z[1,4,5]  R1795     1.8496681749820709e-01
    z[1,4,5]  R1796     -0.0867081880569458
    z[1,4,5]  R1797     -2.5477465987205505e-01
    z[1,4,5]  R1798     -1.9850549101829529e-01
    z[1,4,6]  R17       -1
    z[1,4,6]  R44       1
    z[1,4,6]  R1667     -1
    z[1,4,6]  R1668     1
    z[1,4,6]  R1669     2.9033901169896126e-02
    z[1,4,6]  R1670     4.0269076824188232e-01
    z[1,4,6]  R1671     -2.5250702165067196e-03
    z[1,4,6]  R1672     4.6675089001655579e-01
    z[1,4,6]  R1673     3.4391921758651733e-01
    z[1,4,6]  R1674     -3.5764020681381226e-01
    z[1,4,6]  R1675     -3.6626964807510376e-01
    z[1,4,6]  R1676     4.8786246776580811e-01
    z[1,4,6]  R1677     -2.3331686854362488e-01
    z[1,4,6]  R1678     -1.6823986172676086e-01
    z[1,4,6]  R1679     -6.6091649234294891e-02
    z[1,4,6]  R1680     -3.2455231994390488e-02
    z[1,4,6]  R1681     2.8705042600631714e-01
    z[1,4,6]  R1682     -2.2222459316253662e-01
    z[1,4,6]  R1683     -1.4257307350635529e-01
    z[1,4,6]  R1684     -0.0975661426782608
    z[1,4,6]  R1685     1.2624484300613403e-01
    z[1,4,6]  R1686     1.5527017414569855e-01
    z[1,4,6]  R1687     0.258098304271698
    z[1,4,6]  R1688     3.3507046103477478e-01
    z[1,4,6]  R1689     5.1464933156967163e-01
    z[1,4,6]  R1690     2.4968293309211731e-01
    z[1,4,6]  R1691     9.3214483931660652e-03
    z[1,4,6]  R1692     3.3698195219039917e-01
    z[1,4,6]  R1693     3.4815050661563873e-02
    z[1,4,6]  R1694     -1.7313238978385925e-01
    z[1,4,6]  R1695     -2.4636309593915939e-02
    z[1,4,6]  R1696     -2.0133270323276520e-01
    z[1,4,6]  R1697     7.3934487998485565e-02
    z[1,4,6]  R1698     -1.8456031382083893e-01
    z[1,4,6]  R1699     -2.1386298537254333e-01
    z[1,4,6]  R1700     1.8342237174510956e-01
    z[1,4,6]  R1701     4.3450701236724854e-01
    z[1,4,6]  R1702     1.5843538939952850e-01
    z[1,4,6]  R1703     2.4175839498639107e-02
    z[1,4,6]  R1704     -7.6298236846923828e-01
    z[1,4,6]  R1705     -6.7152345180511475e-01
    z[1,4,6]  R1706     -1.6806390881538391e-01
    z[1,4,6]  R1707     1.2550490908324718e-02
    z[1,4,6]  R1708     -2.9177930951118469e-01
    z[1,4,6]  R1709     1.5630675852298737e-01
    z[1,4,6]  R1710     3.8100153207778931e-01
    z[1,4,6]  R1711     -0.298606812953949
    z[1,4,6]  R1712     -6.7481301724910736e-02
    z[1,4,6]  R1713     4.2612645030021667e-01
    z[1,4,6]  R1714     -7.9563081264495850e-01
    z[1,4,6]  R1715     -8.4395474195480347e-01
    z[1,4,6]  R1716     -4.5136049389839172e-01
    z[1,4,6]  R1717     7.3453408479690552e-01
    z[1,4,6]  R1718     -4.8163527250289917e-01
    z[1,4,6]  R1719     4.9647635221481323e-01
    z[1,4,6]  R1720     -2.4195753037929535e-01
    z[1,4,6]  R1721     -6.6734445095062256e-01
    z[1,4,6]  R1722     -9.9828787147998810e-02
    z[1,4,6]  R1723     -1.2361995875835419e-01
    z[1,4,6]  R1724     -5.6591433286666870e-01
    z[1,4,6]  R1725     -4.8089297488331795e-03
    z[1,4,6]  R1726     7.5726640224456787e-01
    z[1,4,6]  R1727     -0.248578742146492
    z[1,4,6]  R1728     4.6707659959793091e-02
    z[1,4,6]  R1729     -1.9116099178791046e-01
    z[1,4,6]  R1730     -2.8267496824264526e-01
    z[1,4,6]  R1731     1.1737269163131714e-01
    z[1,4,6]  R1732     -1.6705824434757233e-01
    z[1,4,6]  R1733     -2.3493103682994843e-01
    z[1,4,6]  R1734     -3.7678858637809753e-01
    z[1,4,6]  R1735     4.0877026319503784e-01
    z[1,4,6]  R1736     -1.1880979686975479e-01
    z[1,4,6]  R1737     5.8983471244573593e-02
    z[1,4,6]  R1738     -5.6204688549041748e-01
    z[1,4,6]  R1739     3.2145938277244568e-01
    z[1,4,6]  R1740     -2.1052356064319611e-01
    z[1,4,6]  R1741     -9.2820391058921814e-02
    z[1,4,6]  R1742     -2.5066909193992615e-01
    z[1,4,6]  R1743     2.9441300034523010e-01
    z[1,4,6]  R1744     -6.3016250729560852e-02
    z[1,4,6]  R1745     -4.6255189180374146e-01
    z[1,4,6]  R1746     -2.6806166395545006e-02
    z[1,4,6]  R1747     -1.4414816163480282e-02
    z[1,4,6]  R1748     1.2441301345825195e-01
    z[1,4,6]  R1749     7.5026132166385651e-02
    z[1,4,6]  R1750     2.2135600447654724e-01
    z[1,4,6]  R1751     -6.8161681294441223e-02
    z[1,4,6]  R1752     1.3272415101528168e-01
    z[1,4,6]  R1753     -5.1599580049514771e-01
    z[1,4,6]  R1754     1.3522616028785706e-01
    z[1,4,6]  R1755     3.6488026380538940e-02
    z[1,4,6]  R1756     -3.7991631776094437e-02
    z[1,4,6]  R1757     -1.1893206089735031e-01
    z[1,4,6]  R1758     1.5725551545619965e-01
    z[1,4,6]  R1759     -0.210738867521286
    z[1,4,6]  R1760     -3.1171094626188278e-02
    z[1,4,6]  R1761     2.2929438948631287e-01
    z[1,4,6]  R1762     5.0909918546676636e-01
    z[1,4,6]  R1763     1.2369374930858612e-01
    z[1,4,6]  R1764     -7.8863966464996338e-01
    z[1,4,6]  R1765     -3.7255835533142090e-01
    z[1,4,6]  R1766     -0.0744401067495346
    z[1,4,6]  R1767     -1.5316693484783173e-01
    z[1,4,6]  R1768     -3.9936131797730923e-03
    z[1,4,6]  R1769     3.4250393509864807e-01
    z[1,4,6]  R1770     6.0241949558258057e-01
    z[1,4,6]  R1771     4.5875120162963867e-01
    z[1,4,6]  R1772     3.3511921763420105e-01
    z[1,4,6]  R1773     1.8250516057014465e-01
    z[1,4,6]  R1774     -1.4824721217155457e-01
    z[1,4,6]  R1775     -6.0037189722061157e-01
    z[1,4,6]  R1776     -4.3797045946121216e-01
    z[1,4,6]  R1777     -5.0236219167709351e-01
    z[1,4,6]  R1778     -4.6849304437637329e-01
    z[1,4,6]  R1779     -3.2818296551704407e-01
    z[1,4,6]  R1780     1.7228440940380096e-01
    z[1,4,6]  R1781     1.8132114410400391e-01
    z[1,4,6]  R1782     -3.5852468013763428e-01
    z[1,4,6]  R1783     -3.9278939366340637e-01
    z[1,4,6]  R1784     -3.9323008060455322e-01
    z[1,4,6]  R1785     -4.7162118554115295e-01
    z[1,4,6]  R1786     -3.8046449422836304e-01
    z[1,4,6]  R1787     -2.3921951651573181e-02
    z[1,4,6]  R1788     -2.5964441895484924e-01
    z[1,4,6]  R1789     -1.0932006686925888e-01
    z[1,4,6]  R1790     -7.2604125738143921e-01
    z[1,4,6]  R1791     -1.5151165425777435e-01
    z[1,4,6]  R1792     -2.5049192830920219e-02
    z[1,4,6]  R1793     -1.7614869773387909e-01
    z[1,4,6]  R1794     -8.9096657931804657e-02
    z[1,4,6]  R1795     -2.1664224565029144e-01
    z[1,4,6]  R1796     -1.5606154501438141e-01
    z[1,4,6]  R1797     8.1897906959056854e-02
    z[1,4,6]  R1798     5.6511354446411133e-01
    z[4,1,0]  R11       1
    z[4,1,0]  R38       -1
    z[4,1,0]  R1799     -1
    z[4,1,0]  R1800     1
    z[4,1,0]  R1813     5.5870389938354492e-01
    z[4,1,0]  R1814     9.9818736314773560e-02
    z[4,1,0]  R1815     -2.0530523732304573e-02
    z[4,1,0]  R1816     8.2103852182626724e-03
    z[4,1,0]  R1817     -1.4202977716922760e-01
    z[4,1,0]  R1818     -4.8766386508941650e-01
    z[4,1,0]  R1819     -1.5281499922275543e-01
    z[4,1,0]  R1820     8.8300663232803345e-01
    z[4,1,0]  R1821     7.5461864471435547e-01
    z[4,1,0]  R1822     8.5505962371826172e-01
    z[4,1,0]  R1823     -7.1266913414001465e-01
    z[4,1,0]  R1824     -0.489612340927124
    z[4,1,0]  R1825     -6.8424749374389648e-01
    z[4,1,0]  R1826     -5.7680004835128784e-01
    z[4,1,0]  R1827     -0.0508616641163826
    z[4,1,0]  R1828     9.8354585468769073e-02
    z[4,1,0]  R1829     -1.6463661193847656e-01
    z[4,1,0]  R1830     -2.3018735647201538e-01
    z[4,1,0]  R1831     -2.4711753427982330e-01
    z[4,1,0]  R1832     -7.2288691997528076e-02
    z[4,1,0]  R1833     -5.7580053806304932e-01
    z[4,1,0]  R1834     2.5338813662528992e-01
    z[4,1,0]  R1835     2.2624200209975243e-02
    z[4,1,0]  R1836     4.2387198656797409e-02
    z[4,1,0]  R1837     4.6951755881309509e-02
    z[4,1,0]  R1838     1.1479977518320084e-01
    z[4,1,0]  R1839     -7.6783820986747742e-03
    z[4,1,0]  R1840     -4.7213941812515259e-02
    z[4,1,0]  R1841     2.0390398800373077e-01
    z[4,1,0]  R1842     4.9588415771722794e-02
    z[4,1,0]  R1843     -0.370315819978714
    z[4,1,0]  R1844     -4.2799603939056396e-01
    z[4,1,0]  R1845     2.4122430384159088e-01
    z[4,1,0]  R1846     0.111538365483284
    z[4,1,0]  R1847     2.3198957741260529e-01
    z[4,1,0]  R1848     2.9266181588172913e-01
    z[4,1,0]  R1849     -2.6075911521911621e-01
    z[4,1,0]  R1850     0.12830850481987
    z[4,1,0]  R1851     2.7927669882774353e-01
    z[4,1,0]  R1852     2.9127854108810425e-01
    z[4,1,0]  R1853     4.4048145413398743e-01
    z[4,1,0]  R1854     4.4716534018516541e-01
    z[4,1,0]  R1855     3.1553784012794495e-01
    z[4,1,0]  R1856     2.1296481788158417e-01
    z[4,1,0]  R1857     2.0398156344890594e-01
    z[4,1,0]  R1858     1.4513950049877167e-01
    z[4,1,0]  R1859     4.2035266757011414e-01
    z[4,1,0]  R1860     1.8896244466304779e-01
    z[4,1,0]  R1861     2.6948067545890808e-01
    z[4,1,0]  R1862     5.3773349523544312e-01
    z[4,1,0]  R1863     -8.8005030155181885e-01
    z[4,1,0]  R1864     -8.4766268730163574e-01
    z[4,1,0]  R1865     -8.9489394426345825e-01
    z[4,1,0]  R1866     5.6491714715957642e-01
    z[4,1,0]  R1867     6.4999121427536011e-01
    z[4,1,0]  R1868     5.7755821943283081e-01
    z[4,1,0]  R1869     1.8908669054508209e-01
    z[4,1,0]  R1870     6.9569748640060425e-01
    z[4,1,0]  R1871     5.9627151489257812e-01
    z[4,1,0]  R1872     5.2757942676544189e-01
    z[4,1,0]  R1873     -3.5752275586128235e-01
    z[4,1,0]  R1874     -2.9642897844314575e-01
    z[4,1,0]  R1875     -6.3600605726242065e-01
    z[4,1,0]  R1876     -3.5773396492004395e-01
    z[4,1,0]  R1877     -1.8340660631656647e-01
    z[4,1,0]  R1878     -3.7775182723999023e-01
    z[4,1,0]  R1879     -3.4659394621849060e-01
    z[4,1,0]  R1880     6.2411874532699585e-02
    z[4,1,0]  R1881     4.5564625412225723e-02
    z[4,1,0]  R1882     -5.1198780536651611e-01
    z[4,1,0]  R1883     -4.8201125860214233e-01
    z[4,1,0]  R1884     -5.8650255203247070e-01
    z[4,1,0]  R1885     -4.3368390202522278e-01
    z[4,1,0]  R1886     -7.5530534982681274e-01
    z[4,1,0]  R1887     0.0590699128806591
    z[4,1,0]  R1888     -3.6986050009727478e-01
    z[4,1,0]  R1889     1.0634465515613556e-01
    z[4,1,0]  R1890     4.4743397831916809e-01
    z[4,1,0]  R1891     1.4682547748088837e-01
    z[4,1,0]  R1892     0.00492557417601347
    z[4,1,0]  R1893     -4.5591101050376892e-01
    z[4,1,0]  R1894     -6.2477695941925049e-01
    z[4,1,0]  R1895     1.2044054269790649e-01
    z[4,1,0]  R1896     2.5214740633964539e-01
    z[4,1,0]  R1897     1.6487506031990051e-01
    z[4,1,0]  R1898     -3.5710880160331726e-01
    z[4,1,0]  R1899     -2.3909138143062592e-01
    z[4,1,0]  R1900     -4.0107741951942444e-01
    z[4,1,0]  R1901     -2.8470501303672791e-01
    z[4,1,0]  R1902     6.0285080224275589e-02
    z[4,1,0]  R1903     -4.5614802837371826e-01
    z[4,1,0]  R1904     1.6883884370326996e-01
    z[4,1,0]  R1905     -5.7301348447799683e-01
    z[4,1,0]  R1906     -6.5560430288314819e-01
    z[4,1,0]  R1907     4.6026740223169327e-02
    z[4,1,0]  R1908     5.9459650516510010e-01
    z[4,1,0]  R1909     -8.1936977803707123e-03
    z[4,1,0]  R1910     -2.8132265806198120e-01
    z[4,1,0]  R1911     -3.0873646959662437e-02
    z[4,1,0]  R1912     6.2525354325771332e-02
    z[4,1,0]  R1913     -6.5801465511322021e-01
    z[4,1,0]  R1914     3.9888685941696167e-01
    z[4,1,0]  R1915     -7.6452434062957764e-01
    z[4,1,0]  R1916     7.1891725063323975e-01
    z[4,1,0]  R1917     1.0193198919296265e-01
    z[4,1,0]  R1918     4.0106898546218872e-01
    z[4,1,0]  R1919     -1.0802744328975677e-01
    z[4,1,0]  R1920     -2.2934605181217194e-01
    z[4,1,0]  R1921     -2.3645068705081940e-01
    z[4,1,0]  R1922     -6.9124542176723480e-02
    z[4,1,0]  R1923     -6.0876989364624023e-01
    z[4,1,0]  R1924     -4.0712639689445496e-01
    z[4,1,0]  R1925     -1.0106655955314636e-01
    z[4,1,0]  R1926     -1.8882115185260773e-01
    z[4,1,0]  R1927     3.2330492138862610e-01
    z[4,1,0]  R1928     -1.0135262459516525e-01
    z[4,1,0]  R1929     -2.3631669580936432e-02
    z[4,1,0]  R1930     2.9480382800102234e-02
    z[4,1,0]  R1931     -2.4920843541622162e-01
    z[4,1,0]  R1932     -1.4453461766242981e-01
    z[4,1,0]  R1933     -6.4922505617141724e-01
    z[4,1,0]  R1934     -6.0427713394165039e-01
    z[4,1,0]  R1935     7.9296268522739410e-02
    z[4,1,0]  R1936     5.6043070554733276e-01
    z[4,1,0]  R1937     -5.7753247022628784e-01
    z[4,1,0]  R1938     1.8766084313392639e-01
    z[4,1,0]  R1939     8.5992045700550079e-02
    z[4,1,0]  R1940     2.0371274650096893e-01
    z[4,1,0]  R1941     1.2180276960134506e-01
    z[4,1,0]  R1942     2.2687834501266479e-01
    z[4,1,1]  R12       1
    z[4,1,1]  R39       -1
    z[4,1,1]  R1801     -1
    z[4,1,1]  R1802     1
    z[4,1,1]  R1813     5.6021219491958618e-01
    z[4,1,1]  R1814     7.8178036212921143e-01
    z[4,1,1]  R1815     7.5345677137374878e-01
    z[4,1,1]  R1816     3.8890364766120911e-01
    z[4,1,1]  R1817     4.9546009302139282e-01
    z[4,1,1]  R1818     1.8506301939487457e-01
    z[4,1,1]  R1819     1.7123848199844360e-01
    z[4,1,1]  R1820     3.8786649703979492e-02
    z[4,1,1]  R1821     -2.4267809092998505e-01
    z[4,1,1]  R1822     -2.5800105929374695e-01
    z[4,1,1]  R1823     -1.9565564393997192e-01
    z[4,1,1]  R1824     -1.5061859786510468e-01
    z[4,1,1]  R1825     -3.5446065664291382e-01
    z[4,1,1]  R1826     -3.8342043757438660e-01
    z[4,1,1]  R1827     -8.9201897382736206e-01
    z[4,1,1]  R1828     -7.1640813350677490e-01
    z[4,1,1]  R1829     -7.1327060461044312e-01
    z[4,1,1]  R1830     -4.8758310079574585e-01
    z[4,1,1]  R1831     -8.1594669818878174e-01
    z[4,1,1]  R1832     -6.2656390666961670e-01
    z[4,1,1]  R1833     1.0611204802989960e-01
    z[4,1,1]  R1834     -4.4901618361473083e-01
    z[4,1,1]  R1835     -7.4879795312881470e-01
    z[4,1,1]  R1836     -8.4246599674224854e-01
    z[4,1,1]  R1837     -7.3599445819854736e-01
    z[4,1,1]  R1838     -7.6748752593994141e-01
    z[4,1,1]  R1839     -8.7122011184692383e-01
    z[4,1,1]  R1840     -0.759326159954071
    z[4,1,1]  R1841     -8.7563234567642212e-01
    z[4,1,1]  R1842     -9.0224641561508179e-01
    z[4,1,1]  R1843     4.2711898684501648e-01
    z[4,1,1]  R1844     1.1950732767581940e-01
    z[4,1,1]  R1845     -7.9304671287536621e-01
    z[4,1,1]  R1846     -6.9904738664627075e-01
    z[4,1,1]  R1847     -8.7748444080352783e-01
    z[4,1,1]  R1848     -8.8935530185699463e-01
    z[4,1,1]  R1849     -7.5103670358657837e-01
    z[4,1,1]  R1850     -8.4581160545349121e-01
    z[4,1,1]  R1851     -1.1033361405134201e-01
    z[4,1,1]  R1852     -6.0323875397443771e-02
    z[4,1,1]  R1853     7.6852989196777344e-01
    z[4,1,1]  R1854     7.1061855554580688e-01
    z[4,1,1]  R1855     6.9127148389816284e-01
    z[4,1,1]  R1856     6.7748028039932251e-01
    z[4,1,1]  R1857     6.6225379705429077e-01
    z[4,1,1]  R1858     0.657947301864624
    z[4,1,1]  R1859     6.5257954597473145e-01
    z[4,1,1]  R1860     6.5442794561386108e-01
    z[4,1,1]  R1861     6.3109076023101807e-01
    z[4,1,1]  R1862     6.2716007232666016e-01
    z[4,1,1]  R1863     1.3539300300180912e-02
    z[4,1,1]  R1864     -0.0493953637778759
    z[4,1,1]  R1865     -4.1284445673227310e-02
    z[4,1,1]  R1866     -5.1278859376907349e-01
    z[4,1,1]  R1867     -5.4661726951599121e-01
    z[4,1,1]  R1868     -4.9537131190299988e-01
    z[4,1,1]  R1869     -5.5065184831619263e-01
    z[4,1,1]  R1870     -4.6201971173286438e-01
    z[4,1,1]  R1871     -6.0528641939163208e-01
    z[4,1,1]  R1872     -3.8753968477249146e-01
    z[4,1,1]  R1873     2.2777329385280609e-01
    z[4,1,1]  R1874     3.5794261097908020e-01
    z[4,1,1]  R1875     -0.0707663968205452
    z[4,1,1]  R1876     2.1073617041110992e-01
    z[4,1,1]  R1877     2.3412954807281494e-01
    z[4,1,1]  R1878     2.5247669219970703e-01
    z[4,1,1]  R1879     1.3208749890327454e-01
    z[4,1,1]  R1880     6.7550706863403320e-01
    z[4,1,1]  R1881     6.7064303159713745e-01
    z[4,1,1]  R1882     -4.9852974712848663e-02
    z[4,1,1]  R1883     4.2516711354255676e-01
    z[4,1,1]  R1884     2.7613270282745361e-01
    z[4,1,1]  R1885     2.8282597661018372e-01
    z[4,1,1]  R1886     4.4181060791015625e-01
    z[4,1,1]  R1887     -1.9234298169612885e-01
    z[4,1,1]  R1888     1.0171489417552948e-01
    z[4,1,1]  R1889     5.7744336128234863e-01
    z[4,1,1]  R1890     -5.2219372987747192e-01
    z[4,1,1]  R1891     -3.1241990625858307e-02
    z[4,1,1]  R1892     5.3227978944778442e-01
    z[4,1,1]  R1893     3.8184702396392822e-01
    z[4,1,1]  R1894     -2.7537789195775986e-02
    z[4,1,1]  R1895     8.5406959056854248e-01
    z[4,1,1]  R1896     8.1836843490600586e-01
    z[4,1,1]  R1897     2.6267403364181519e-01
    z[4,1,1]  R1898     1.3385763764381409e-01
    z[4,1,1]  R1899     2.5609949231147766e-01
    z[4,1,1]  R1900     8.2399033010005951e-02
    z[4,1,1]  R1901     2.4601301550865173e-01
    z[4,1,1]  R1902     6.1969733238220215e-01
    z[4,1,1]  R1903     4.0898019075393677e-01
    z[4,1,1]  R1904     6.4176046848297119e-01
    z[4,1,1]  R1905     1.0565433651208878e-01
    z[4,1,1]  R1906     1.3106757402420044e-01
    z[4,1,1]  R1907     9.3674689531326294e-01
    z[4,1,1]  R1908     5.0609749555587769e-01
    z[4,1,1]  R1909     4.6355494856834412e-01
    z[4,1,1]  R1910     0.284940242767334
    z[4,1,1]  R1911     2.8398683294653893e-02
    z[4,1,1]  R1912     2.4847318232059479e-01
    z[4,1,1]  R1913     2.6605013012886047e-01
    z[4,1,1]  R1914     8.0469900369644165e-01
    z[4,1,1]  R1915     4.4193947315216064e-01
    z[4,1,1]  R1916     -5.1152259111404419e-01
    z[4,1,1]  R1917     -4.2723175883293152e-01
    z[4,1,1]  R1918     -4.2270788550376892e-01
    z[4,1,1]  R1919     -2.3982043564319611e-01
    z[4,1,1]  R1920     -9.1337114572525024e-01
    z[4,1,1]  R1921     -8.7942677736282349e-01
    z[4,1,1]  R1922     -2.8539735078811646e-01
    z[4,1,1]  R1923     3.4915563464164734e-01
    z[4,1,1]  R1924     3.8095399737358093e-01
    z[4,1,1]  R1925     5.5673009157180786e-01
    z[4,1,1]  R1926     -1.8500310182571411e-01
    z[4,1,1]  R1927     -3.9021816849708557e-01
    z[4,1,1]  R1928     3.8227722048759460e-02
    z[4,1,1]  R1929     -2.0226265490055084e-01
    z[4,1,1]  R1930     5.9279982000589371e-02
    z[4,1,1]  R1931     -0.926781177520752
    z[4,1,1]  R1932     -7.5965744256973267e-01
    z[4,1,1]  R1933     1.5500506758689880e-01
    z[4,1,1]  R1934     7.0526483468711376e-03
    z[4,1,1]  R1935     9.5337331295013428e-01
    z[4,1,1]  R1936     -6.2721198797225952e-01
    z[4,1,1]  R1937     3.7929084897041321e-01
    z[4,1,1]  R1938     -1.0878720879554749e-01
    z[4,1,1]  R1939     -3.3713793754577637e-01
    z[4,1,1]  R1940     -3.9753583073616028e-01
    z[4,1,1]  R1941     -0.273084819316864
    z[4,1,1]  R1942     -3.3717691898345947e-01
    z[4,1,2]  R13       1
    z[4,1,2]  R40       -1
    z[4,1,2]  R1803     -1
    z[4,1,2]  R1804     1
    z[4,1,2]  R1813     -3.8512402772903442e-01
    z[4,1,2]  R1814     5.6504216045141220e-02
    z[4,1,2]  R1815     -3.9413750171661377e-01
    z[4,1,2]  R1816     1.1042091995477676e-01
    z[4,1,2]  R1817     1.2807871401309967e-01
    z[4,1,2]  R1818     1.2600994668900967e-02
    z[4,1,2]  R1819     1.0695854574441910e-01
    z[4,1,2]  R1820     3.7434976547956467e-02
    z[4,1,2]  R1821     1.3555747270584106e-01
    z[4,1,2]  R1822     -0.0625605583190918
    z[4,1,2]  R1823     0.49066162109375
    z[4,1,2]  R1824     3.7475490570068359e-01
    z[4,1,2]  R1825     -1.8631502985954285e-01
    z[4,1,2]  R1826     -5.3598236292600632e-02
    z[4,1,2]  R1827     -9.7490988671779633e-02
    z[4,1,2]  R1828     -5.3910166025161743e-01
    z[4,1,2]  R1829     -1.0701456665992737e-01
    z[4,1,2]  R1830     -3.9065742492675781e-01
    z[4,1,2]  R1831     -7.0837214589118958e-02
    z[4,1,2]  R1832     -4.8441314697265625e-01
    z[4,1,2]  R1833     -1.2420298904180527e-01
    z[4,1,2]  R1834     -3.6703076958656311e-01
    z[4,1,2]  R1835     -8.0870762467384338e-02
    z[4,1,2]  R1836     -1.6054618358612061e-01
    z[4,1,2]  R1837     -1.4383193850517273e-01
    z[4,1,2]  R1838     -2.4992391467094421e-01
    z[4,1,2]  R1839     -8.3724528551101685e-02
    z[4,1,2]  R1840     3.0607774853706360e-01
    z[4,1,2]  R1841     3.2696709036827087e-01
    z[4,1,2]  R1842     2.2576428949832916e-01
    z[4,1,2]  R1843     -3.0090728402137756e-01
    z[4,1,2]  R1844     -2.3227781057357788e-01
    z[4,1,2]  R1845     -1.1948853731155396e-01
    z[4,1,2]  R1846     -1.9092109799385071e-01
    z[4,1,2]  R1847     3.3038997650146484e-01
    z[4,1,2]  R1848     1.7247335612773895e-01
    z[4,1,2]  R1849     -6.6403280943632126e-03
    z[4,1,2]  R1850     3.6510783433914185e-01
    z[4,1,2]  R1851     -7.7136582136154175e-01
    z[4,1,2]  R1852     -0.623135507106781
    z[4,1,2]  R1853     1.9762471318244934e-01
    z[4,1,2]  R1854     1.8094404041767120e-01
    z[4,1,2]  R1855     1.7155742272734642e-02
    z[4,1,2]  R1856     2.3242124915122986e-01
    z[4,1,2]  R1857     2.0797017216682434e-01
    z[4,1,2]  R1858     3.0362471938133240e-01
    z[4,1,2]  R1859     1.5505865216255188e-01
    z[4,1,2]  R1860     1.7621801793575287e-01
    z[4,1,2]  R1861     1.8051068484783173e-01
    z[4,1,2]  R1862     -1.3206172734498978e-02
    z[4,1,2]  R1863     -6.9564029574394226e-02
    z[4,1,2]  R1864     1.7230573296546936e-01
    z[4,1,2]  R1865     1.7138895392417908e-01
    z[4,1,2]  R1866     -1.4812509715557098e-01
    z[4,1,2]  R1867     -1.6373504698276520e-01
    z[4,1,2]  R1868     -2.1429817378520966e-01
    z[4,1,2]  R1869     -2.5060099363327026e-01
    z[4,1,2]  R1870     -6.6603772342205048e-02
    z[4,1,2]  R1871     4.1931409388780594e-02
    z[4,1,2]  R1872     -1.5611787140369415e-01
    z[4,1,2]  R1873     2.7155104279518127e-01
    z[4,1,2]  R1874     -1.2577632069587708e-01
    z[4,1,2]  R1875     -2.7121728658676147e-01
    z[4,1,2]  R1876     0.0661039724946022
    z[4,1,2]  R1877     -5.5829749908298254e-04
    z[4,1,2]  R1878     -1.6054630279541016e-01
    z[4,1,2]  R1879     1.1115300655364990e-01
    z[4,1,2]  R1880     -0.4558085501194
    z[4,1,2]  R1881     -4.5450708270072937e-01
    z[4,1,2]  R1882     6.2247227877378464e-02
    z[4,1,2]  R1883     4.6318256855010986e-01
    z[4,1,2]  R1884     4.2427086830139160e-01
    z[4,1,2]  R1885     1.3735873997211456e-01
    z[4,1,2]  R1886     -2.5027480721473694e-01
    z[4,1,2]  R1887     1.4518241398036480e-02
    z[4,1,2]  R1888     3.6463406682014465e-01
    z[4,1,2]  R1889     -3.2373934984207153e-01
    z[4,1,2]  R1890     4.8716405034065247e-01
    z[4,1,2]  R1891     3.8003337383270264e-01
    z[4,1,2]  R1892     -1.1138872057199478e-01
    z[4,1,2]  R1893     6.1045867204666138e-01
    z[4,1,2]  R1894     -1.4914770424365997e-01
    z[4,1,2]  R1895     -3.2510453462600708e-01
    z[4,1,2]  R1896     -2.3592798411846161e-01
    z[4,1,2]  R1897     -3.6896771192550659e-01
    z[4,1,2]  R1898     8.4914974868297577e-02
    z[4,1,2]  R1899     2.3748025298118591e-01
    z[4,1,2]  R1900     -4.6754304319620132e-02
    z[4,1,2]  R1901     4.0193051099777222e-01
    z[4,1,2]  R1902     -3.2748410105705261e-01
    z[4,1,2]  R1903     3.2034772634506226e-01
    z[4,1,2]  R1904     3.4528324007987976e-01
    z[4,1,2]  R1905     -9.6078209578990936e-02
    z[4,1,2]  R1906     -2.2535999119281769e-01
    z[4,1,2]  R1907     -2.2950629889965057e-01
    z[4,1,2]  R1908     -1.9488035142421722e-01
    z[4,1,2]  R1909     -1.3908736407756805e-01
    z[4,1,2]  R1910     3.8566029071807861e-01
    z[4,1,2]  R1911     -1.7290504276752472e-01
    z[4,1,2]  R1912     -5.4297423362731934e-01
    z[4,1,2]  R1913     1.8496979773044586e-01
    z[4,1,2]  R1914     -0.244472473859787
    z[4,1,2]  R1915     -2.9634317755699158e-01
    z[4,1,2]  R1916     3.2215365767478943e-01
    z[4,1,2]  R1917     1.1727154999971390e-01
    z[4,1,2]  R1918     5.3423233330249786e-02
    z[4,1,2]  R1919     3.2155385613441467e-01
    z[4,1,2]  R1920     1.3224214315414429e-01
    z[4,1,2]  R1921     1.9594286382198334e-01
    z[4,1,2]  R1922     2.3662203550338745e-01
    z[4,1,2]  R1923     2.2422102093696594e-01
    z[4,1,2]  R1924     4.1424378752708435e-01
    z[4,1,2]  R1925     -4.9048945307731628e-01
    z[4,1,2]  R1926     4.3830013275146484e-01
    z[4,1,2]  R1927     0.417977511882782
    z[4,1,2]  R1928     4.0899294614791870e-01
    z[4,1,2]  R1929     2.4501444399356842e-01
    z[4,1,2]  R1930     -1.8349802494049072e-01
    z[4,1,2]  R1931     1.4926487207412720e-01
    z[4,1,2]  R1932     3.8419011235237122e-01
    z[4,1,2]  R1933     2.4462023377418518e-01
    z[4,1,2]  R1934     -1.4788176119327545e-01
    z[4,1,2]  R1935     -4.7778464853763580e-02
    z[4,1,2]  R1936     1.4802455902099609e-01
    z[4,1,2]  R1937     -4.2650622129440308e-01
    z[4,1,2]  R1938     4.7915931791067123e-03
    z[4,1,2]  R1939     -8.4596776962280273e-01
    z[4,1,2]  R1940     -7.6929843425750732e-01
    z[4,1,2]  R1941     -8.8198131322860718e-01
    z[4,1,2]  R1942     -8.0463838577270508e-01
    z[4,1,3]  R14       1
    z[4,1,3]  R41       -1
    z[4,1,3]  R1805     -1
    z[4,1,3]  R1806     1
    z[4,1,3]  R1813     -3.8021820783615112e-01
    z[4,1,3]  R1814     -4.8384204506874084e-01
    z[4,1,3]  R1815     -3.6220863461494446e-01
    z[4,1,3]  R1816     -4.1754421591758728e-01
    z[4,1,3]  R1817     -2.9438000917434692e-01
    z[4,1,3]  R1818     -3.1255516409873962e-01
    z[4,1,3]  R1819     6.8910324573516846e-01
    z[4,1,3]  R1820     -3.0642330646514893e-01
    z[4,1,3]  R1821     -0.398311972618103
    z[4,1,3]  R1822     -2.8055045008659363e-01
    z[4,1,3]  R1823     2.8187143802642822e-01
    z[4,1,3]  R1824     4.5860681682825089e-02
    z[4,1,3]  R1825     -2.4828857183456421e-01
    z[4,1,3]  R1826     -1.3207701034843922e-02
    z[4,1,3]  R1827     -8.9316688477993011e-02
    z[4,1,3]  R1828     -2.1141889691352844e-01
    z[4,1,3]  R1829     9.3292370438575745e-02
    z[4,1,3]  R1830     -3.2621735334396362e-01
    z[4,1,3]  R1831     -1.0185866057872772e-01
    z[4,1,3]  R1832     -3.8146099448204041e-01
    z[4,1,3]  R1833     3.0751854181289673e-01
    z[4,1,3]  R1834     -6.9934684038162231e-01
    z[4,1,3]  R1835     -3.2809826731681824e-01
    z[4,1,3]  R1836     -3.1848379969596863e-01
    z[4,1,3]  R1837     -3.9895847439765930e-01
    z[4,1,3]  R1838     -3.7319111824035645e-01
    z[4,1,3]  R1839     3.6862384527921677e-02
    z[4,1,3]  R1840     8.2869239151477814e-02
    z[4,1,3]  R1841     2.8244696557521820e-02
    z[4,1,3]  R1842     -5.6988544762134552e-02
    z[4,1,3]  R1843     4.1068476438522339e-01
    z[4,1,3]  R1844     3.7810587882995605e-01
    z[4,1,3]  R1845     -3.4058916568756104e-01
    z[4,1,3]  R1846     -5.4312676191329956e-01
    z[4,1,3]  R1847     -9.5807880163192749e-02
    z[4,1,3]  R1848     2.8587602078914642e-02
    z[4,1,3]  R1849     -3.5784307122230530e-01
    z[4,1,3]  R1850     2.3451048135757446e-01
    z[4,1,3]  R1851     4.9130004644393921e-01
    z[4,1,3]  R1852     4.0348741412162781e-01
    z[4,1,3]  R1853     2.4325282871723175e-01
    z[4,1,3]  R1854     -2.9130894690752029e-02
    z[4,1,3]  R1855     -2.5148457288742065e-01
    z[4,1,3]  R1856     1.2540750205516815e-01
    z[4,1,3]  R1857     -6.9350488483905792e-02
    z[4,1,3]  R1858     -2.2384946048259735e-01
    z[4,1,3]  R1859     -1.5611016750335693e-01
    z[4,1,3]  R1860     0.351661741733551
    z[4,1,3]  R1861     -1.9590289890766144e-01
    z[4,1,3]  R1862     -1.4304912090301514e-01
    z[4,1,3]  R1863     2.1276351809501648e-01
    z[4,1,3]  R1864     2.3736884817481041e-02
    z[4,1,3]  R1865     2.3033104836940765e-01
    z[4,1,3]  R1866     -5.3111881017684937e-01
    z[4,1,3]  R1867     -4.1673696041107178e-01
    z[4,1,3]  R1868     -6.0401380062103271e-01
    z[4,1,3]  R1869     -7.1226024627685547e-01
    z[4,1,3]  R1870     -5.0312846899032593e-01
    z[4,1,3]  R1871     -3.5064321756362915e-01
    z[4,1,3]  R1872     -6.3387966156005859e-01
    z[4,1,3]  R1873     -6.4800351858139038e-01
    z[4,1,3]  R1874     -7.8793352842330933e-01
    z[4,1,3]  R1875     -1.7942821979522705e-01
    z[4,1,3]  R1876     -0.599696934223175
    z[4,1,3]  R1877     -9.0880846977233887e-01
    z[4,1,3]  R1878     -0.678071916103363
    z[4,1,3]  R1879     -3.2827010750770569e-01
    z[4,1,3]  R1880     -3.1030055880546570e-01
    z[4,1,3]  R1881     -5.1563370227813721e-01
    z[4,1,3]  R1882     -4.5084246993064880e-01
    z[4,1,3]  R1883     4.4007804989814758e-01
    z[4,1,3]  R1884     3.3346137404441833e-01
    z[4,1,3]  R1885     1.2889523059129715e-02
    z[4,1,3]  R1886     -2.9720512032508850e-01
    z[4,1,3]  R1887     -0.571692705154419
    z[4,1,3]  R1888     -3.4564909338951111e-01
    z[4,1,3]  R1889     -2.9619028791785240e-03
    z[4,1,3]  R1890     2.4839065968990326e-01
    z[4,1,3]  R1891     8.3537089824676514e-01
    z[4,1,3]  R1892     6.5786695480346680e-01
    z[4,1,3]  R1893     -4.3137678503990173e-01
    z[4,1,3]  R1894     -2.2906927764415741e-01
    z[4,1,3]  R1895     -2.2457545623183250e-02
    z[4,1,3]  R1896     -8.8043145835399628e-02
    z[4,1,3]  R1897     -7.6031464338302612e-01
    z[4,1,3]  R1898     -4.3721115589141846e-01
    z[4,1,3]  R1899     -1.2719729542732239e-01
    z[4,1,3]  R1900     -4.4476732611656189e-01
    z[4,1,3]  R1901     2.0254816114902496e-01
    z[4,1,3]  R1902     1.8693853914737701e-01
    z[4,1,3]  R1903     -4.4414305686950684e-01
    z[4,1,3]  R1904     4.7506517171859741e-01
    z[4,1,3]  R1905     -1.5171146392822266e-01
    z[4,1,3]  R1906     -4.6923705935478210e-01
    z[4,1,3]  R1907     2.3001782596111298e-02
    z[4,1,3]  R1908     1.2662726454436779e-02
    z[4,1,3]  R1909     -0.766851007938385
    z[4,1,3]  R1910     1.9679950177669525e-01
    z[4,1,3]  R1911     -8.5443496704101562e-01
    z[4,1,3]  R1912     -7.1599733829498291e-01
    z[4,1,3]  R1913     -0.621579110622406
    z[4,1,3]  R1914     -1.8579454720020294e-01
    z[4,1,3]  R1915     -3.1899437308311462e-01
    z[4,1,3]  R1916     2.7757775783538818e-01
    z[4,1,3]  R1917     -3.3909055590629578e-01
    z[4,1,3]  R1918     1.6180644929409027e-01
    z[4,1,3]  R1919     7.4454855918884277e-01
    z[4,1,3]  R1920     2.3615576326847076e-02
    z[4,1,3]  R1921     -6.1152640730142593e-02
    z[4,1,3]  R1922     6.6606956720352173e-01
    z[4,1,3]  R1923     -2.6376655697822571e-01
    z[4,1,3]  R1924     2.7661317586898804e-01
    z[4,1,3]  R1925     -4.9569407105445862e-01
    z[4,1,3]  R1926     7.1560466289520264e-01
    z[4,1,3]  R1927     1.2439829856157303e-01
    z[4,1,3]  R1928     8.8599252700805664e-01
    z[4,1,3]  R1929     8.0509597063064575e-01
    z[4,1,3]  R1930     9.6395754814147949e-01
    z[4,1,3]  R1931     1.3031853735446930e-01
    z[4,1,3]  R1932     4.5830440521240234e-01
    z[4,1,3]  R1933     2.2185295820236206e-01
    z[4,1,3]  R1934     -3.4237092733383179e-01
    z[4,1,3]  R1935     1.3089454174041748e-01
    z[4,1,3]  R1936     1.9845359027385712e-02
    z[4,1,3]  R1937     -1.9326542317867279e-01
    z[4,1,3]  R1938     -5.7583391666412354e-01
    z[4,1,3]  R1939     0.336665540933609
    z[4,1,3]  R1940     3.8043934106826782e-01
    z[4,1,3]  R1941     3.3475691080093384e-01
    z[4,1,3]  R1942     3.3808118104934692e-01
    z[4,1,4]  R15       1
    z[4,1,4]  R42       -1
    z[4,1,4]  R1807     -1
    z[4,1,4]  R1808     1
    z[4,1,4]  R1813     -1.8614172935485840e-01
    z[4,1,4]  R1814     2.1207168698310852e-01
    z[4,1,4]  R1815     1.3169211149215698e-01
    z[4,1,4]  R1816     -5.8622401952743530e-01
    z[4,1,4]  R1817     -7.0075875520706177e-01
    z[4,1,4]  R1818     2.7352645993232727e-02
    z[4,1,4]  R1819     4.4997197389602661e-01
    z[4,1,4]  R1820     -1.1206955462694168e-01
    z[4,1,4]  R1821     -3.5753118991851807e-01
    z[4,1,4]  R1822     3.3977007865905762e-01
    z[4,1,4]  R1823     5.3274929523468018e-02
    z[4,1,4]  R1824     4.2905649542808533e-01
    z[4,1,4]  R1825     3.0451324582099915e-01
    z[4,1,4]  R1826     6.3623654842376709e-01
    z[4,1,4]  R1827     -3.5619032382965088e-01
    z[4,1,4]  R1828     -7.8622095286846161e-02
    z[4,1,4]  R1829     -1.7840167507529259e-02
    z[4,1,4]  R1830     -8.1945598125457764e-02
    z[4,1,4]  R1831     -6.9304317235946655e-02
    z[4,1,4]  R1832     -0.0410560667514801
    z[4,1,4]  R1833     -3.1161725521087646e-01
    z[4,1,4]  R1834     1.3672819733619690e-01
    z[4,1,4]  R1835     -3.2310044765472412e-01
    z[4,1,4]  R1836     8.5804097354412079e-02
    z[4,1,4]  R1837     -1.7356221377849579e-01
    z[4,1,4]  R1838     -7.4332311749458313e-02
    z[4,1,4]  R1839     -3.4329265356063843e-02
    z[4,1,4]  R1840     -3.0796703696250916e-01
    z[4,1,4]  R1841     2.1189035475254059e-01
    z[4,1,4]  R1842     5.9805028140544891e-02
    z[4,1,4]  R1843     1.9889065623283386e-01
    z[4,1,4]  R1844     -2.7678728103637695e-01
    z[4,1,4]  R1845     3.1266503036022186e-02
    z[4,1,4]  R1846     -3.5277768969535828e-01
    z[4,1,4]  R1847     -5.2817653864622116e-02
    z[4,1,4]  R1848     -1.7005857825279236e-01
    z[4,1,4]  R1849     -3.9837956428527832e-01
    z[4,1,4]  R1850     -2.1901425719261169e-01
    z[4,1,4]  R1851     -4.2809482663869858e-02
    z[4,1,4]  R1852     -4.0744204074144363e-02
    z[4,1,4]  R1853     3.9067290723323822e-02
    z[4,1,4]  R1854     -2.8967443108558655e-01
    z[4,1,4]  R1855     5.9735560417175293e-01
    z[4,1,4]  R1856     1.1907239258289337e-01
    z[4,1,4]  R1857     -2.6911571621894836e-01
    z[4,1,4]  R1858     -4.7039699554443359e-01
    z[4,1,4]  R1859     2.0863448083400726e-01
    z[4,1,4]  R1860     3.7537318468093872e-01
    z[4,1,4]  R1861     -4.9597907066345215e-01
    z[4,1,4]  R1862     0.436262845993042
    z[4,1,4]  R1863     2.0806825160980225e-01
    z[4,1,4]  R1864     -4.7438085079193115e-01
    z[4,1,4]  R1865     -1.6129940748214722e-01
    z[4,1,4]  R1866     -1.7047438025474548e-01
    z[4,1,4]  R1867     1.5612085163593292e-01
    z[4,1,4]  R1868     1.6943825408816338e-02
    z[4,1,4]  R1869     -9.3334801495075226e-03
    z[4,1,4]  R1870     1.4701751992106438e-02
    z[4,1,4]  R1871     2.4286296218633652e-02
    z[4,1,4]  R1872     6.5779253840446472e-02
    z[4,1,4]  R1873     6.7274391651153564e-02
    z[4,1,4]  R1874     -5.7650838047266006e-02
    z[4,1,4]  R1875     2.0311267673969269e-01
    z[4,1,4]  R1876     2.9101410508155823e-01
    z[4,1,4]  R1877     2.6428506243973970e-03
    z[4,1,4]  R1878     2.0727189257740974e-02
    z[4,1,4]  R1879     4.8381105065345764e-01
    z[4,1,4]  R1880     2.1485836803913116e-01
    z[4,1,4]  R1881     1.8651841580867767e-01
    z[4,1,4]  R1882     6.1027181148529053e-01
    z[4,1,4]  R1883     2.7737993001937866e-01
    z[4,1,4]  R1884     3.2691791653633118e-01
    z[4,1,4]  R1885     -3.2753947377204895e-01
    z[4,1,4]  R1886     -1.5371769666671753e-01
    z[4,1,4]  R1887     1.7633976042270660e-01
    z[4,1,4]  R1888     1.0239803791046143e-01
    z[4,1,4]  R1889     2.8421280905604362e-02
    z[4,1,4]  R1890     -1.8215529620647430e-02
    z[4,1,4]  R1891     4.5270342379808426e-02
    z[4,1,4]  R1892     -2.9345223307609558e-01
    z[4,1,4]  R1893     -9.8966039717197418e-02
    z[4,1,4]  R1894     5.8230036497116089e-01
    z[4,1,4]  R1895     -7.7445581555366516e-02
    z[4,1,4]  R1896     5.4957754909992218e-02
    z[4,1,4]  R1897     0.0887366533279419
    z[4,1,4]  R1898     1.2271800637245178e-01
    z[4,1,4]  R1899     1.7630773782730103e-01
    z[4,1,4]  R1900     -2.7799794077873230e-01
    z[4,1,4]  R1901     -2.6498362421989441e-01
    z[4,1,4]  R1902     4.8734968900680542e-01
    z[4,1,4]  R1903     2.7661731839179993e-01
    z[4,1,4]  R1904     -3.4113430976867676e-01
    z[4,1,4]  R1905     0.190584197640419
    z[4,1,4]  R1906     4.2454391717910767e-01
    z[4,1,4]  R1907     6.2954194843769073e-02
    z[4,1,4]  R1908     5.1860720850527287e-03
    z[4,1,4]  R1909     -4.0332680940628052e-01
    z[4,1,4]  R1910     -2.6774457097053528e-01
    z[4,1,4]  R1911     4.1753351688385010e-01
    z[4,1,4]  R1912     2.6212513446807861e-01
    z[4,1,4]  R1913     -1.9029390811920166e-01
    z[4,1,4]  R1914     -1.3608361780643463e-01
    z[4,1,4]  R1915     -6.1558857560157776e-02
    z[4,1,4]  R1916     -6.4338847994804382e-02
    z[4,1,4]  R1917     5.0951063632965088e-01
    z[4,1,4]  R1918     4.8818126320838928e-01
    z[4,1,4]  R1919     2.8009146451950073e-01
    z[4,1,4]  R1920     1.1476716957986355e-02
    z[4,1,4]  R1921     -1.6288541257381439e-01
    z[4,1,4]  R1922     -2.3661302030086517e-01
    z[4,1,4]  R1923     -2.9888426885008812e-02
    z[4,1,4]  R1924     -5.2529531717300415e-01
    z[4,1,4]  R1925     1.1386800557374954e-01
    z[4,1,4]  R1926     -2.6716282963752747e-01
    z[4,1,4]  R1927     2.3903135955333710e-01
    z[4,1,4]  R1928     1.6486936807632446e-01
    z[4,1,4]  R1929     5.1504410803318024e-02
    z[4,1,4]  R1930     1.4756634831428528e-01
    z[4,1,4]  R1931     1.8596661090850830e-01
    z[4,1,4]  R1932     1.2414073944091797e-01
    z[4,1,4]  R1933     -4.9323442578315735e-01
    z[4,1,4]  R1934     3.7036576867103577e-01
    z[4,1,4]  R1935     -2.0263580977916718e-01
    z[4,1,4]  R1936     0.294387549161911
    z[4,1,4]  R1937     2.8524341061711311e-02
    z[4,1,4]  R1938     -7.0917648077011108e-01
    z[4,1,4]  R1939     1.6378301382064819e-01
    z[4,1,4]  R1940     -2.4107404053211212e-01
    z[4,1,4]  R1941     -0.0662151351571083
    z[4,1,4]  R1942     -2.0259568095207214e-01
    z[4,1,5]  R16       1
    z[4,1,5]  R43       -1
    z[4,1,5]  R1809     -1
    z[4,1,5]  R1810     1
    z[4,1,5]  R1813     4.5455317944288254e-02
    z[4,1,5]  R1814     3.0921491980552673e-01
    z[4,1,5]  R1815     -2.7463287115097046e-01
    z[4,1,5]  R1816     2.4353665113449097e-01
    z[4,1,5]  R1817     -3.5344031453132629e-01
    z[4,1,5]  R1818     -8.5938408970832825e-02
    z[4,1,5]  R1819     3.4604495763778687e-01
    z[4,1,5]  R1820     -3.2464957237243652e-01
    z[4,1,5]  R1821     -2.0818535983562469e-01
    z[4,1,5]  R1822     -0.0650099441409111
    z[4,1,5]  R1823     -1.1607811599969864e-01
    z[4,1,5]  R1824     -2.1920476853847504e-01
    z[4,1,5]  R1825     0.0813726931810379
    z[4,1,5]  R1826     1.1889610439538956e-02
    z[4,1,5]  R1827     -1.5509258210659027e-01
    z[4,1,5]  R1828     3.3704373240470886e-01
    z[4,1,5]  R1829     -2.8847804665565491e-01
    z[4,1,5]  R1830     -5.0170928239822388e-01
    z[4,1,5]  R1831     -2.4494219571352005e-02
    z[4,1,5]  R1832     2.9188964515924454e-02
    z[4,1,5]  R1833     5.8514147996902466e-01
    z[4,1,5]  R1834     -2.4900746345520020e-01
    z[4,1,5]  R1835     -4.3281638622283936e-01
    z[4,1,5]  R1836     -1.5920111536979675e-01
    z[4,1,5]  R1837     -3.0305919051170349e-01
    z[4,1,5]  R1838     1.8946048617362976e-01
    z[4,1,5]  R1839     9.4566307961940765e-02
    z[4,1,5]  R1840     -2.8468701243400574e-01
    z[4,1,5]  R1841     1.9625541567802429e-01
    z[4,1,5]  R1842     2.4141949415206909e-01
    z[4,1,5]  R1843     6.0804599523544312e-01
    z[4,1,5]  R1844     4.3281927704811096e-02
    z[4,1,5]  R1845     -3.9834147691726685e-01
    z[4,1,5]  R1846     2.0585153996944427e-01
    z[4,1,5]  R1847     -0.155070960521698
    z[4,1,5]  R1848     2.3658762872219086e-01
    z[4,1,5]  R1849     1.8496681749820709e-01
    z[4,1,5]  R1850     -0.0867081880569458
    z[4,1,5]  R1851     -2.5477465987205505e-01
    z[4,1,5]  R1852     -1.9850549101829529e-01
    z[4,1,5]  R1853     3.3873483538627625e-01
    z[4,1,5]  R1854     1.2411311268806458e-01
    z[4,1,5]  R1855     -4.6913441270589828e-02
    z[4,1,5]  R1856     -4.4032388925552368e-01
    z[4,1,5]  R1857     -0.530138373374939
    z[4,1,5]  R1858     2.3358824849128723e-01
    z[4,1,5]  R1859     4.1394233703613281e-01
    z[4,1,5]  R1860     4.8824291676282883e-02
    z[4,1,5]  R1861     -3.9712780714035034e-01
    z[4,1,5]  R1862     2.7972424030303955e-01
    z[4,1,5]  R1863     3.5715565085411072e-01
    z[4,1,5]  R1864     -1.5061445534229279e-01
    z[4,1,5]  R1865     -8.1352427601814270e-02
    z[4,1,5]  R1866     -1.8826331198215485e-01
    z[4,1,5]  R1867     -1.8314327299594879e-01
    z[4,1,5]  R1868     2.1702989935874939e-02
    z[4,1,5]  R1869     -2.7365726232528687e-01
    z[4,1,5]  R1870     1.4367893338203430e-01
    z[4,1,5]  R1871     -2.9355597496032715e-01
    z[4,1,5]  R1872     -1.6940365731716156e-01
    z[4,1,5]  R1873     2.3928731679916382e-01
    z[4,1,5]  R1874     -2.8580215573310852e-01
    z[4,1,5]  R1875     -6.6587787866592407e-01
    z[4,1,5]  R1876     -5.1513540744781494e-01
    z[4,1,5]  R1877     2.9050523042678833e-01
    z[4,1,5]  R1878     -5.2687561511993408e-01
    z[4,1,5]  R1879     -7.1248096227645874e-01
    z[4,1,5]  R1880     -3.8606736063957214e-01
    z[4,1,5]  R1881     1.8828584253787994e-01
    z[4,1,5]  R1882     -3.4893444180488586e-01
    z[4,1,5]  R1883     2.3667345941066742e-01
    z[4,1,5]  R1884     -3.8476511836051941e-01
    z[4,1,5]  R1885     -6.4561265707015991e-01
    z[4,1,5]  R1886     -1.8605917692184448e-01
    z[4,1,5]  R1887     7.7510738372802734e-01
    z[4,1,5]  R1888     -8.8310331106185913e-02
    z[4,1,5]  R1889     -3.1413757801055908e-01
    z[4,1,5]  R1890     4.4666835665702820e-01
    z[4,1,5]  R1891     3.6467710137367249e-01
    z[4,1,5]  R1892     -3.1655681133270264e-01
    z[4,1,5]  R1893     2.3101146519184113e-01
    z[4,1,5]  R1894     -2.2347655892372131e-01
    z[4,1,5]  R1895     -2.3387621343135834e-01
    z[4,1,5]  R1896     -4.4238799810409546e-01
    z[4,1,5]  R1897     1.2042701244354248e-02
    z[4,1,5]  R1898     0.0900174155831337
    z[4,1,5]  R1899     -2.4764549732208252e-01
    z[4,1,5]  R1900     -5.9273451566696167e-01
    z[4,1,5]  R1901     2.1468596160411835e-01
    z[4,1,5]  R1902     2.5821685791015625e-02
    z[4,1,5]  R1903     4.2101528495550156e-02
    z[4,1,5]  R1904     -1.9953294098377228e-01
    z[4,1,5]  R1905     -3.8285022974014282e-01
    z[4,1,5]  R1906     -3.0303534865379333e-01
    z[4,1,5]  R1907     -2.1895058453083038e-01
    z[4,1,5]  R1908     -1.7859362065792084e-01
    z[4,1,5]  R1909     -1.2226261198520660e-01
    z[4,1,5]  R1910     8.4042645990848541e-02
    z[4,1,5]  R1911     4.6469278633594513e-02
    z[4,1,5]  R1912     -2.3661652207374573e-01
    z[4,1,5]  R1913     5.3901232779026031e-02
    z[4,1,5]  R1914     -2.5268737226724625e-02
    z[4,1,5]  R1915     1.1423484981060028e-01
    z[4,1,5]  R1916     9.2856295406818390e-02
    z[4,1,5]  R1917     6.0295450687408447e-01
    z[4,1,5]  R1918     5.0113433599472046e-01
    z[4,1,5]  R1919     1.6589875519275665e-01
    z[4,1,5]  R1920     2.8435957431793213e-01
    z[4,1,5]  R1921     3.1393593549728394e-01
    z[4,1,5]  R1922     2.0554584264755249e-01
    z[4,1,5]  R1923     5.3236478567123413e-01
    z[4,1,5]  R1924     -3.4749662876129150e-01
    z[4,1,5]  R1925     -4.1468435525894165e-01
    z[4,1,5]  R1926     3.0284056067466736e-01
    z[4,1,5]  R1927     0.639694094657898
    z[4,1,5]  R1928     0.0696791484951973
    z[4,1,5]  R1929     1.8360999226570129e-01
    z[4,1,5]  R1930     -1.0117681324481964e-01
    z[4,1,5]  R1931     7.0125319063663483e-02
    z[4,1,5]  R1932     1.1617124080657959e-01
    z[4,1,5]  R1933     4.4329819083213806e-01
    z[4,1,5]  R1934     -5.5636620521545410e-01
    z[4,1,5]  R1935     -1.4024247229099274e-01
    z[4,1,5]  R1936     4.0735453367233276e-01
    z[4,1,5]  R1937     -1.9044749438762665e-01
    z[4,1,5]  R1938     -3.1642335653305054e-01
    z[4,1,5]  R1939     -1.4758719503879547e-01
    z[4,1,5]  R1940     6.5971814095973969e-02
    z[4,1,5]  R1941     -4.5893844217061996e-02
    z[4,1,5]  R1942     8.5568435490131378e-02
    z[4,1,6]  R17       1
    z[4,1,6]  R44       -1
    z[4,1,6]  R1811     -1
    z[4,1,6]  R1812     1
    z[4,1,6]  R1813     -0.210738867521286
    z[4,1,6]  R1814     -3.1171094626188278e-02
    z[4,1,6]  R1815     2.2929438948631287e-01
    z[4,1,6]  R1816     5.0909918546676636e-01
    z[4,1,6]  R1817     1.2369374930858612e-01
    z[4,1,6]  R1818     -7.8863966464996338e-01
    z[4,1,6]  R1819     -3.7255835533142090e-01
    z[4,1,6]  R1820     -0.0744401067495346
    z[4,1,6]  R1821     -1.5316693484783173e-01
    z[4,1,6]  R1822     -3.9936131797730923e-03
    z[4,1,6]  R1823     3.4250393509864807e-01
    z[4,1,6]  R1824     6.0241949558258057e-01
    z[4,1,6]  R1825     4.5875120162963867e-01
    z[4,1,6]  R1826     3.3511921763420105e-01
    z[4,1,6]  R1827     1.8250516057014465e-01
    z[4,1,6]  R1828     -1.4824721217155457e-01
    z[4,1,6]  R1829     -6.0037189722061157e-01
    z[4,1,6]  R1830     -4.3797045946121216e-01
    z[4,1,6]  R1831     -5.0236219167709351e-01
    z[4,1,6]  R1832     -4.6849304437637329e-01
    z[4,1,6]  R1833     -3.2818296551704407e-01
    z[4,1,6]  R1834     1.7228440940380096e-01
    z[4,1,6]  R1835     1.8132114410400391e-01
    z[4,1,6]  R1836     -3.5852468013763428e-01
    z[4,1,6]  R1837     -3.9278939366340637e-01
    z[4,1,6]  R1838     -3.9323008060455322e-01
    z[4,1,6]  R1839     -4.7162118554115295e-01
    z[4,1,6]  R1840     -3.8046449422836304e-01
    z[4,1,6]  R1841     -2.3921951651573181e-02
    z[4,1,6]  R1842     -2.5964441895484924e-01
    z[4,1,6]  R1843     -1.0932006686925888e-01
    z[4,1,6]  R1844     -7.2604125738143921e-01
    z[4,1,6]  R1845     -1.5151165425777435e-01
    z[4,1,6]  R1846     -2.5049192830920219e-02
    z[4,1,6]  R1847     -1.7614869773387909e-01
    z[4,1,6]  R1848     -8.9096657931804657e-02
    z[4,1,6]  R1849     -2.1664224565029144e-01
    z[4,1,6]  R1850     -1.5606154501438141e-01
    z[4,1,6]  R1851     8.1897906959056854e-02
    z[4,1,6]  R1852     5.6511354446411133e-01
    z[4,1,6]  R1853     2.9033901169896126e-02
    z[4,1,6]  R1854     4.0269076824188232e-01
    z[4,1,6]  R1855     -2.5250702165067196e-03
    z[4,1,6]  R1856     4.6675089001655579e-01
    z[4,1,6]  R1857     3.4391921758651733e-01
    z[4,1,6]  R1858     -3.5764020681381226e-01
    z[4,1,6]  R1859     -3.6626964807510376e-01
    z[4,1,6]  R1860     4.8786246776580811e-01
    z[4,1,6]  R1861     -2.3331686854362488e-01
    z[4,1,6]  R1862     -1.6823986172676086e-01
    z[4,1,6]  R1863     -6.6091649234294891e-02
    z[4,1,6]  R1864     -3.2455231994390488e-02
    z[4,1,6]  R1865     2.8705042600631714e-01
    z[4,1,6]  R1866     -2.2222459316253662e-01
    z[4,1,6]  R1867     -1.4257307350635529e-01
    z[4,1,6]  R1868     -0.0975661426782608
    z[4,1,6]  R1869     1.2624484300613403e-01
    z[4,1,6]  R1870     1.5527017414569855e-01
    z[4,1,6]  R1871     0.258098304271698
    z[4,1,6]  R1872     3.3507046103477478e-01
    z[4,1,6]  R1873     5.1464933156967163e-01
    z[4,1,6]  R1874     2.4968293309211731e-01
    z[4,1,6]  R1875     9.3214483931660652e-03
    z[4,1,6]  R1876     3.3698195219039917e-01
    z[4,1,6]  R1877     3.4815050661563873e-02
    z[4,1,6]  R1878     -1.7313238978385925e-01
    z[4,1,6]  R1879     -2.4636309593915939e-02
    z[4,1,6]  R1880     -2.0133270323276520e-01
    z[4,1,6]  R1881     7.3934487998485565e-02
    z[4,1,6]  R1882     -1.8456031382083893e-01
    z[4,1,6]  R1883     -2.1386298537254333e-01
    z[4,1,6]  R1884     1.8342237174510956e-01
    z[4,1,6]  R1885     4.3450701236724854e-01
    z[4,1,6]  R1886     1.5843538939952850e-01
    z[4,1,6]  R1887     2.4175839498639107e-02
    z[4,1,6]  R1888     -7.6298236846923828e-01
    z[4,1,6]  R1889     -6.7152345180511475e-01
    z[4,1,6]  R1890     -1.6806390881538391e-01
    z[4,1,6]  R1891     1.2550490908324718e-02
    z[4,1,6]  R1892     -2.9177930951118469e-01
    z[4,1,6]  R1893     1.5630675852298737e-01
    z[4,1,6]  R1894     3.8100153207778931e-01
    z[4,1,6]  R1895     -0.298606812953949
    z[4,1,6]  R1896     -6.7481301724910736e-02
    z[4,1,6]  R1897     4.2612645030021667e-01
    z[4,1,6]  R1898     -7.9563081264495850e-01
    z[4,1,6]  R1899     -8.4395474195480347e-01
    z[4,1,6]  R1900     -4.5136049389839172e-01
    z[4,1,6]  R1901     7.3453408479690552e-01
    z[4,1,6]  R1902     -4.8163527250289917e-01
    z[4,1,6]  R1903     4.9647635221481323e-01
    z[4,1,6]  R1904     -2.4195753037929535e-01
    z[4,1,6]  R1905     -6.6734445095062256e-01
    z[4,1,6]  R1906     -9.9828787147998810e-02
    z[4,1,6]  R1907     -1.2361995875835419e-01
    z[4,1,6]  R1908     -5.6591433286666870e-01
    z[4,1,6]  R1909     -4.8089297488331795e-03
    z[4,1,6]  R1910     7.5726640224456787e-01
    z[4,1,6]  R1911     -0.248578742146492
    z[4,1,6]  R1912     4.6707659959793091e-02
    z[4,1,6]  R1913     -1.9116099178791046e-01
    z[4,1,6]  R1914     -2.8267496824264526e-01
    z[4,1,6]  R1915     1.1737269163131714e-01
    z[4,1,6]  R1916     -1.6705824434757233e-01
    z[4,1,6]  R1917     -2.3493103682994843e-01
    z[4,1,6]  R1918     -3.7678858637809753e-01
    z[4,1,6]  R1919     4.0877026319503784e-01
    z[4,1,6]  R1920     -1.1880979686975479e-01
    z[4,1,6]  R1921     5.8983471244573593e-02
    z[4,1,6]  R1922     -5.6204688549041748e-01
    z[4,1,6]  R1923     3.2145938277244568e-01
    z[4,1,6]  R1924     -2.1052356064319611e-01
    z[4,1,6]  R1925     -9.2820391058921814e-02
    z[4,1,6]  R1926     -2.5066909193992615e-01
    z[4,1,6]  R1927     2.9441300034523010e-01
    z[4,1,6]  R1928     -6.3016250729560852e-02
    z[4,1,6]  R1929     -4.6255189180374146e-01
    z[4,1,6]  R1930     -2.6806166395545006e-02
    z[4,1,6]  R1931     -1.4414816163480282e-02
    z[4,1,6]  R1932     1.2441301345825195e-01
    z[4,1,6]  R1933     7.5026132166385651e-02
    z[4,1,6]  R1934     2.2135600447654724e-01
    z[4,1,6]  R1935     -6.8161681294441223e-02
    z[4,1,6]  R1936     1.3272415101528168e-01
    z[4,1,6]  R1937     -5.1599580049514771e-01
    z[4,1,6]  R1938     1.3522616028785706e-01
    z[4,1,6]  R1939     3.6488026380538940e-02
    z[4,1,6]  R1940     -3.7991631776094437e-02
    z[4,1,6]  R1941     -1.1893206089735031e-01
    z[4,1,6]  R1942     1.5725551545619965e-01
    z[2,4,0]  R20       -1
    z[2,4,0]  R38       1
    z[2,4,0]  R1943     -1
    z[2,4,0]  R1944     1
    z[2,4,0]  R1957     2.0851935446262360e-01
    z[2,4,0]  R1958     -1.5403975732624531e-02
    z[2,4,0]  R1959     3.5964307188987732e-01
    z[2,4,0]  R1960     2.5737184286117554e-01
    z[2,4,0]  R1961     -5.0401753187179565e-01
    z[2,4,0]  R1962     5.0322896242141724e-01
    z[2,4,0]  R1963     -2.0297326147556305e-01
    z[2,4,0]  R1964     -4.4124320149421692e-01
    z[2,4,0]  R1965     -4.2562133073806763e-01
    z[2,4,0]  R1966     -4.1262978315353394e-01
    z[2,4,0]  R1967     -8.6052364110946655e-01
    z[2,4,0]  R1968     -5.6854259967803955e-01
    z[2,4,0]  R1969     -7.7454006671905518e-01
    z[2,4,0]  R1970     -6.5631330013275146e-01
    z[2,4,0]  R1971     -6.3293945789337158e-01
    z[2,4,0]  R1972     3.4924343228340149e-01
    z[2,4,0]  R1973     2.7462828159332275e-01
    z[2,4,0]  R1974     5.4640930891036987e-01
    z[2,4,0]  R1975     0.637653648853302
    z[2,4,0]  R1976     6.7432254552841187e-01
    z[2,4,0]  R1977     2.8271627426147461e-01
    z[2,4,0]  R1978     5.7072299718856812e-01
    z[2,4,0]  R1979     5.4416990280151367e-01
    z[2,4,0]  R1980     4.5737496018409729e-01
    z[2,4,0]  R1981     5.2685087919235229e-01
    z[2,4,0]  R1982     5.9256774187088013e-01
    z[2,4,0]  R1983     5.1349717378616333e-01
    z[2,4,0]  R1984     4.4690340757369995e-01
    z[2,4,0]  R1985     5.3048992156982422e-01
    z[2,4,0]  R1986     5.3112769126892090e-01
    z[2,4,0]  R1987     5.5870389938354492e-01
    z[2,4,0]  R1988     9.9818736314773560e-02
    z[2,4,0]  R1989     -2.0530523732304573e-02
    z[2,4,0]  R1990     8.2103852182626724e-03
    z[2,4,0]  R1991     -1.4202977716922760e-01
    z[2,4,0]  R1992     -4.8766386508941650e-01
    z[2,4,0]  R1993     -1.5281499922275543e-01
    z[2,4,0]  R1994     8.8300663232803345e-01
    z[2,4,0]  R1995     7.5461864471435547e-01
    z[2,4,0]  R1996     8.5505962371826172e-01
    z[2,4,0]  R1997     -7.1266913414001465e-01
    z[2,4,0]  R1998     -0.489612340927124
    z[2,4,0]  R1999     -6.8424749374389648e-01
    z[2,4,0]  R2000     -5.7680004835128784e-01
    z[2,4,0]  R2001     -0.0508616641163826
    z[2,4,0]  R2002     9.8354585468769073e-02
    z[2,4,0]  R2003     -1.6463661193847656e-01
    z[2,4,0]  R2004     -2.3018735647201538e-01
    z[2,4,0]  R2005     -2.4711753427982330e-01
    z[2,4,0]  R2006     -7.2288691997528076e-02
    z[2,4,0]  R2007     -5.7580053806304932e-01
    z[2,4,0]  R2008     2.5338813662528992e-01
    z[2,4,0]  R2009     2.2624200209975243e-02
    z[2,4,0]  R2010     4.2387198656797409e-02
    z[2,4,0]  R2011     4.6951755881309509e-02
    z[2,4,0]  R2012     1.1479977518320084e-01
    z[2,4,0]  R2013     -7.6783820986747742e-03
    z[2,4,0]  R2014     -4.7213941812515259e-02
    z[2,4,0]  R2015     2.0390398800373077e-01
    z[2,4,0]  R2016     4.9588415771722794e-02
    z[2,4,0]  R2017     -0.370315819978714
    z[2,4,0]  R2018     -4.2799603939056396e-01
    z[2,4,0]  R2019     2.4122430384159088e-01
    z[2,4,0]  R2020     0.111538365483284
    z[2,4,0]  R2021     2.3198957741260529e-01
    z[2,4,0]  R2022     2.9266181588172913e-01
    z[2,4,0]  R2023     -2.6075911521911621e-01
    z[2,4,0]  R2024     0.12830850481987
    z[2,4,0]  R2025     2.7927669882774353e-01
    z[2,4,0]  R2026     2.9127854108810425e-01
    z[2,4,1]  R21       -1
    z[2,4,1]  R39       1
    z[2,4,1]  R1945     -1
    z[2,4,1]  R1946     1
    z[2,4,1]  R1957     5.9952521324157715e-01
    z[2,4,1]  R1958     7.3347389698028564e-01
    z[2,4,1]  R1959     5.4051935672760010e-01
    z[2,4,1]  R1960     7.6075994968414307e-01
    z[2,4,1]  R1961     7.6848263852298260e-03
    z[2,4,1]  R1962     -6.0933738946914673e-01
    z[2,4,1]  R1963     -1.2389837950468063e-01
    z[2,4,1]  R1964     1.5843097865581512e-01
    z[2,4,1]  R1965     6.7712232470512390e-02
    z[2,4,1]  R1966     5.8002066798508167e-03
    z[2,4,1]  R1967     -9.5188491046428680e-02
    z[2,4,1]  R1968     -2.5689724087715149e-01
    z[2,4,1]  R1969     1.6511952504515648e-02
    z[2,4,1]  R1970     1.6391709446907043e-01
    z[2,4,1]  R1971     0.169791579246521
    z[2,4,1]  R1972     0.3975810110569
    z[2,4,1]  R1973     3.8544443249702454e-01
    z[2,4,1]  R1974     -0.354875385761261
    z[2,4,1]  R1975     -3.7354382872581482e-01
    z[2,4,1]  R1976     -1.7746937274932861e-01
    z[2,4,1]  R1977     5.2763038873672485e-01
    z[2,4,1]  R1978     -0.36905637383461
    z[2,4,1]  R1979     -4.2943546175956726e-01
    z[2,4,1]  R1980     -4.2379817366600037e-01
    z[2,4,1]  R1981     -4.1507422924041748e-01
    z[2,4,1]  R1982     -4.2539614439010620e-01
    z[2,4,1]  R1983     -2.7495419979095459e-01
    z[2,4,1]  R1984     -2.7008923888206482e-01
    z[2,4,1]  R1985     -1.9018433988094330e-01
    z[2,4,1]  R1986     -3.8987907767295837e-01
    z[2,4,1]  R1987     5.6021219491958618e-01
    z[2,4,1]  R1988     7.8178036212921143e-01
    z[2,4,1]  R1989     7.5345677137374878e-01
    z[2,4,1]  R1990     3.8890364766120911e-01
    z[2,4,1]  R1991     4.9546009302139282e-01
    z[2,4,1]  R1992     1.8506301939487457e-01
    z[2,4,1]  R1993     1.7123848199844360e-01
    z[2,4,1]  R1994     3.8786649703979492e-02
    z[2,4,1]  R1995     -2.4267809092998505e-01
    z[2,4,1]  R1996     -2.5800105929374695e-01
    z[2,4,1]  R1997     -1.9565564393997192e-01
    z[2,4,1]  R1998     -1.5061859786510468e-01
    z[2,4,1]  R1999     -3.5446065664291382e-01
    z[2,4,1]  R2000     -3.8342043757438660e-01
    z[2,4,1]  R2001     -8.9201897382736206e-01
    z[2,4,1]  R2002     -7.1640813350677490e-01
    z[2,4,1]  R2003     -7.1327060461044312e-01
    z[2,4,1]  R2004     -4.8758310079574585e-01
    z[2,4,1]  R2005     -8.1594669818878174e-01
    z[2,4,1]  R2006     -6.2656390666961670e-01
    z[2,4,1]  R2007     1.0611204802989960e-01
    z[2,4,1]  R2008     -4.4901618361473083e-01
    z[2,4,1]  R2009     -7.4879795312881470e-01
    z[2,4,1]  R2010     -8.4246599674224854e-01
    z[2,4,1]  R2011     -7.3599445819854736e-01
    z[2,4,1]  R2012     -7.6748752593994141e-01
    z[2,4,1]  R2013     -8.7122011184692383e-01
    z[2,4,1]  R2014     -0.759326159954071
    z[2,4,1]  R2015     -8.7563234567642212e-01
    z[2,4,1]  R2016     -9.0224641561508179e-01
    z[2,4,1]  R2017     4.2711898684501648e-01
    z[2,4,1]  R2018     1.1950732767581940e-01
    z[2,4,1]  R2019     -7.9304671287536621e-01
    z[2,4,1]  R2020     -6.9904738664627075e-01
    z[2,4,1]  R2021     -8.7748444080352783e-01
    z[2,4,1]  R2022     -8.8935530185699463e-01
    z[2,4,1]  R2023     -7.5103670358657837e-01
    z[2,4,1]  R2024     -8.4581160545349121e-01
    z[2,4,1]  R2025     -1.1033361405134201e-01
    z[2,4,1]  R2026     -6.0323875397443771e-02
    z[2,4,2]  R22       -1
    z[2,4,2]  R40       1
    z[2,4,2]  R1947     -1
    z[2,4,2]  R1948     1
    z[2,4,2]  R1957     -4.0175938606262207e-01
    z[2,4,2]  R1958     -0.0754147619009018
    z[2,4,2]  R1959     -5.1272273063659668e-01
    z[2,4,2]  R1960     4.7629281878471375e-02
    z[2,4,2]  R1961     4.2262795567512512e-01
    z[2,4,2]  R1962     -3.9237266778945923e-01
    z[2,4,2]  R1963     0.0480094775557518
    z[2,4,2]  R1964     -3.9981681853532791e-02
    z[2,4,2]  R1965     -5.0601817667484283e-02
    z[2,4,2]  R1966     3.1279647350311279e-01
    z[2,4,2]  R1967     -1.2840218842029572e-01
    z[2,4,2]  R1968     -3.8769415020942688e-01
    z[2,4,2]  R1969     -5.0271785259246826e-01
    z[2,4,2]  R1970     2.7499321103096008e-01
    z[2,4,2]  R1971     3.5533748567104340e-02
    z[2,4,2]  R1972     -4.8125658184289932e-02
    z[2,4,2]  R1973     1.6836115717887878e-01
    z[2,4,2]  R1974     4.5957425236701965e-01
    z[2,4,2]  R1975     3.9908558130264282e-01
    z[2,4,2]  R1976     3.9081260561943054e-01
    z[2,4,2]  R1977     5.9389103204011917e-02
    z[2,4,2]  R1978     0.49821937084198
    z[2,4,2]  R1979     5.1848423480987549e-01
    z[2,4,2]  R1980     6.0682344436645508e-01
    z[2,4,2]  R1981     5.9697711467742920e-01
    z[2,4,2]  R1982     3.2818609476089478e-01
    z[2,4,2]  R1983     4.1627770662307739e-01
    z[2,4,2]  R1984     5.0859099626541138e-01
    z[2,4,2]  R1985     4.5980966091156006e-01
    z[2,4,2]  R1986     2.1257606148719788e-01
    z[2,4,2]  R1987     -3.8512402772903442e-01
    z[2,4,2]  R1988     5.6504216045141220e-02
    z[2,4,2]  R1989     -3.9413750171661377e-01
    z[2,4,2]  R1990     1.1042091995477676e-01
    z[2,4,2]  R1991     1.2807871401309967e-01
    z[2,4,2]  R1992     1.2600994668900967e-02
    z[2,4,2]  R1993     1.0695854574441910e-01
    z[2,4,2]  R1994     3.7434976547956467e-02
    z[2,4,2]  R1995     1.3555747270584106e-01
    z[2,4,2]  R1996     -0.0625605583190918
    z[2,4,2]  R1997     0.49066162109375
    z[2,4,2]  R1998     3.7475490570068359e-01
    z[2,4,2]  R1999     -1.8631502985954285e-01
    z[2,4,2]  R2000     -5.3598236292600632e-02
    z[2,4,2]  R2001     -9.7490988671779633e-02
    z[2,4,2]  R2002     -5.3910166025161743e-01
    z[2,4,2]  R2003     -1.0701456665992737e-01
    z[2,4,2]  R2004     -3.9065742492675781e-01
    z[2,4,2]  R2005     -7.0837214589118958e-02
    z[2,4,2]  R2006     -4.8441314697265625e-01
    z[2,4,2]  R2007     -1.2420298904180527e-01
    z[2,4,2]  R2008     -3.6703076958656311e-01
    z[2,4,2]  R2009     -8.0870762467384338e-02
    z[2,4,2]  R2010     -1.6054618358612061e-01
    z[2,4,2]  R2011     -1.4383193850517273e-01
    z[2,4,2]  R2012     -2.4992391467094421e-01
    z[2,4,2]  R2013     -8.3724528551101685e-02
    z[2,4,2]  R2014     3.0607774853706360e-01
    z[2,4,2]  R2015     3.2696709036827087e-01
    z[2,4,2]  R2016     2.2576428949832916e-01
    z[2,4,2]  R2017     -3.0090728402137756e-01
    z[2,4,2]  R2018     -2.3227781057357788e-01
    z[2,4,2]  R2019     -1.1948853731155396e-01
    z[2,4,2]  R2020     -1.9092109799385071e-01
    z[2,4,2]  R2021     3.3038997650146484e-01
    z[2,4,2]  R2022     1.7247335612773895e-01
    z[2,4,2]  R2023     -6.6403280943632126e-03
    z[2,4,2]  R2024     3.6510783433914185e-01
    z[2,4,2]  R2025     -7.7136582136154175e-01
    z[2,4,2]  R2026     -0.623135507106781
    z[2,4,3]  R23       -1
    z[2,4,3]  R41       1
    z[2,4,3]  R1949     -1
    z[2,4,3]  R1950     1
    z[2,4,3]  R1957     -3.8041961193084717e-01
    z[2,4,3]  R1958     -4.0003478527069092e-01
    z[2,4,3]  R1959     -3.1106692552566528e-01
    z[2,4,3]  R1960     -4.1161969304084778e-01
    z[2,4,3]  R1961     2.6464501023292542e-01
    z[2,4,3]  R1962     -3.0929449200630188e-01
    z[2,4,3]  R1963     3.8125178217887878e-01
    z[2,4,3]  R1964     7.1631860733032227e-01
    z[2,4,3]  R1965     7.1944117546081543e-01
    z[2,4,3]  R1966     3.1913855671882629e-01
    z[2,4,3]  R1967     -9.6025623381137848e-02
    z[2,4,3]  R1968     2.6896673440933228e-01
    z[2,4,3]  R1969     1.9394946098327637e-01
    z[2,4,3]  R1970     1.8569202721118927e-01
    z[2,4,3]  R1971     3.1972801685333252e-01
    z[2,4,3]  R1972     7.7558934688568115e-01
    z[2,4,3]  R1973     6.8880569934844971e-01
    z[2,4,3]  R1974     5.7362580299377441e-01
    z[2,4,3]  R1975     3.9625069499015808e-01
    z[2,4,3]  R1976     5.5744445323944092e-01
    z[2,4,3]  R1977     7.7658736705780029e-01
    z[2,4,3]  R1978     4.8028782010078430e-01
    z[2,4,3]  R1979     3.7779018282890320e-01
    z[2,4,3]  R1980     3.5796162486076355e-01
    z[2,4,3]  R1981     4.1075026988983154e-01
    z[2,4,3]  R1982     3.3119884133338928e-01
    z[2,4,3]  R1983     4.9578070640563965e-01
    z[2,4,3]  R1984     4.5892271399497986e-01
    z[2,4,3]  R1985     5.3256541490554810e-01
    z[2,4,3]  R1986     3.6666208505630493e-01
    z[2,4,3]  R1987     -3.8021820783615112e-01
    z[2,4,3]  R1988     -4.8384204506874084e-01
    z[2,4,3]  R1989     -3.6220863461494446e-01
    z[2,4,3]  R1990     -4.1754421591758728e-01
    z[2,4,3]  R1991     -2.9438000917434692e-01
    z[2,4,3]  R1992     -3.1255516409873962e-01
    z[2,4,3]  R1993     6.8910324573516846e-01
    z[2,4,3]  R1994     -3.0642330646514893e-01
    z[2,4,3]  R1995     -0.398311972618103
    z[2,4,3]  R1996     -2.8055045008659363e-01
    z[2,4,3]  R1997     2.8187143802642822e-01
    z[2,4,3]  R1998     4.5860681682825089e-02
    z[2,4,3]  R1999     -2.4828857183456421e-01
    z[2,4,3]  R2000     -1.3207701034843922e-02
    z[2,4,3]  R2001     -8.9316688477993011e-02
    z[2,4,3]  R2002     -2.1141889691352844e-01
    z[2,4,3]  R2003     9.3292370438575745e-02
    z[2,4,3]  R2004     -3.2621735334396362e-01
    z[2,4,3]  R2005     -1.0185866057872772e-01
    z[2,4,3]  R2006     -3.8146099448204041e-01
    z[2,4,3]  R2007     3.0751854181289673e-01
    z[2,4,3]  R2008     -6.9934684038162231e-01
    z[2,4,3]  R2009     -3.2809826731681824e-01
    z[2,4,3]  R2010     -3.1848379969596863e-01
    z[2,4,3]  R2011     -3.9895847439765930e-01
    z[2,4,3]  R2012     -3.7319111824035645e-01
    z[2,4,3]  R2013     3.6862384527921677e-02
    z[2,4,3]  R2014     8.2869239151477814e-02
    z[2,4,3]  R2015     2.8244696557521820e-02
    z[2,4,3]  R2016     -5.6988544762134552e-02
    z[2,4,3]  R2017     4.1068476438522339e-01
    z[2,4,3]  R2018     3.7810587882995605e-01
    z[2,4,3]  R2019     -3.4058916568756104e-01
    z[2,4,3]  R2020     -5.4312676191329956e-01
    z[2,4,3]  R2021     -9.5807880163192749e-02
    z[2,4,3]  R2022     2.8587602078914642e-02
    z[2,4,3]  R2023     -3.5784307122230530e-01
    z[2,4,3]  R2024     2.3451048135757446e-01
    z[2,4,3]  R2025     4.9130004644393921e-01
    z[2,4,3]  R2026     4.0348741412162781e-01
    z[2,4,4]  R24       -1
    z[2,4,4]  R42       1
    z[2,4,4]  R1951     -1
    z[2,4,4]  R1952     1
    z[2,4,4]  R1957     -4.8983284831047058e-01
    z[2,4,4]  R1958     2.7587356045842171e-02
    z[2,4,4]  R1959     3.8253080844879150e-01
    z[2,4,4]  R1960     2.2896544635295868e-01
    z[2,4,4]  R1961     0.61134272813797
    z[2,4,4]  R1962     5.2625991404056549e-02
    z[2,4,4]  R1963     -0.245507150888443
    z[2,4,4]  R1964     -4.7838117927312851e-02
    z[2,4,4]  R1965     -4.5447820425033569e-01
    z[2,4,4]  R1966     -7.2568637132644653e-01
    z[2,4,4]  R1967     -2.4012076854705811e-01
    z[2,4,4]  R1968     -4.1983744502067566e-01
    z[2,4,4]  R1969     -2.0180565118789673e-01
    z[2,4,4]  R1970     -5.9347146749496460e-01
    z[2,4,4]  R1971     -6.8957552313804626e-02
    z[2,4,4]  R1972     -2.2105820477008820e-01
    z[2,4,4]  R1973     -8.8698320090770721e-02
    z[2,4,4]  R1974     -1.4955131709575653e-01
    z[2,4,4]  R1975     -5.1410477608442307e-03
    z[2,4,4]  R1976     1.3310334086418152e-01
    z[2,4,4]  R1977     -1.3876292109489441e-01
    z[2,4,4]  R1978     -2.4128077924251556e-01
    z[2,4,4]  R1979     -3.0206805467605591e-01
    z[2,4,4]  R1980     -2.2211056947708130e-01
    z[2,4,4]  R1981     1.5509857237339020e-01
    z[2,4,4]  R1982     -3.3147913217544556e-01
    z[2,4,4]  R1983     5.0097596831619740e-03
    z[2,4,4]  R1984     2.2887936234474182e-01
    z[2,4,4]  R1985     -1.0418955981731415e-01
    z[2,4,4]  R1986     -5.0786298513412476e-01
    z[2,4,4]  R1987     -1.8614172935485840e-01
    z[2,4,4]  R1988     2.1207168698310852e-01
    z[2,4,4]  R1989     1.3169211149215698e-01
    z[2,4,4]  R1990     -5.8622401952743530e-01
    z[2,4,4]  R1991     -7.0075875520706177e-01
    z[2,4,4]  R1992     2.7352645993232727e-02
    z[2,4,4]  R1993     4.4997197389602661e-01
    z[2,4,4]  R1994     -1.1206955462694168e-01
    z[2,4,4]  R1995     -3.5753118991851807e-01
    z[2,4,4]  R1996     3.3977007865905762e-01
    z[2,4,4]  R1997     5.3274929523468018e-02
    z[2,4,4]  R1998     4.2905649542808533e-01
    z[2,4,4]  R1999     3.0451324582099915e-01
    z[2,4,4]  R2000     6.3623654842376709e-01
    z[2,4,4]  R2001     -3.5619032382965088e-01
    z[2,4,4]  R2002     -7.8622095286846161e-02
    z[2,4,4]  R2003     -1.7840167507529259e-02
    z[2,4,4]  R2004     -8.1945598125457764e-02
    z[2,4,4]  R2005     -6.9304317235946655e-02
    z[2,4,4]  R2006     -0.0410560667514801
    z[2,4,4]  R2007     -3.1161725521087646e-01
    z[2,4,4]  R2008     1.3672819733619690e-01
    z[2,4,4]  R2009     -3.2310044765472412e-01
    z[2,4,4]  R2010     8.5804097354412079e-02
    z[2,4,4]  R2011     -1.7356221377849579e-01
    z[2,4,4]  R2012     -7.4332311749458313e-02
    z[2,4,4]  R2013     -3.4329265356063843e-02
    z[2,4,4]  R2014     -3.0796703696250916e-01
    z[2,4,4]  R2015     2.1189035475254059e-01
    z[2,4,4]  R2016     5.9805028140544891e-02
    z[2,4,4]  R2017     1.9889065623283386e-01
    z[2,4,4]  R2018     -2.7678728103637695e-01
    z[2,4,4]  R2019     3.1266503036022186e-02
    z[2,4,4]  R2020     -3.5277768969535828e-01
    z[2,4,4]  R2021     -5.2817653864622116e-02
    z[2,4,4]  R2022     -1.7005857825279236e-01
    z[2,4,4]  R2023     -3.9837956428527832e-01
    z[2,4,4]  R2024     -2.1901425719261169e-01
    z[2,4,4]  R2025     -4.2809482663869858e-02
    z[2,4,4]  R2026     -4.0744204074144363e-02
    z[2,4,5]  R25       -1
    z[2,4,5]  R43       1
    z[2,4,5]  R1953     -1
    z[2,4,5]  R1954     1
    z[2,4,5]  R1957     5.6663446128368378e-02
    z[2,4,5]  R1958     -3.8086524605751038e-01
    z[2,4,5]  R1959     -1.1776731908321381e-01
    z[2,4,5]  R1960     3.6166024208068848e-01
    z[2,4,5]  R1961     -3.1754210591316223e-01
    z[2,4,5]  R1962     3.4753009676933289e-01
    z[2,4,5]  R1963     2.7488359808921814e-01
    z[2,4,5]  R1964     5.0187402963638306e-01
    z[2,4,5]  R1965     1.1820279061794281e-01
    z[2,4,5]  R1966     -3.1481122970581055e-01
    z[2,4,5]  R1967     3.7921205163002014e-01
    z[2,4,5]  R1968     -4.5613449811935425e-01
    z[2,4,5]  R1969     1.1303842067718506e-01
    z[2,4,5]  R1970     2.1613454818725586e-01
    z[2,4,5]  R1971     6.1869156360626221e-01
    z[2,4,5]  R1972     -1.5857380628585815e-01
    z[2,4,5]  R1973     -4.9893024563789368e-01
    z[2,4,5]  R1974     4.6290088444948196e-02
    z[2,4,5]  R1975     -2.1705435216426849e-01
    z[2,4,5]  R1976     1.8041309714317322e-01
    z[2,4,5]  R1977     -1.0834795981645584e-01
    z[2,4,5]  R1978     -2.4197725579142570e-02
    z[2,4,5]  R1979     -6.0347881168127060e-02
    z[2,4,5]  R1980     1.8821948766708374e-01
    z[2,4,5]  R1981     -4.2746751569211483e-03
    z[2,4,5]  R1982     -3.6321040987968445e-01
    z[2,4,5]  R1983     2.9662764072418213e-01
    z[2,4,5]  R1984     3.8539204001426697e-01
    z[2,4,5]  R1985     4.2010742425918579e-01
    z[2,4,5]  R1986     -2.9041895270347595e-01
    z[2,4,5]  R1987     4.5455317944288254e-02
    z[2,4,5]  R1988     3.0921491980552673e-01
    z[2,4,5]  R1989     -2.7463287115097046e-01
    z[2,4,5]  R1990     2.4353665113449097e-01
    z[2,4,5]  R1991     -3.5344031453132629e-01
    z[2,4,5]  R1992     -8.5938408970832825e-02
    z[2,4,5]  R1993     3.4604495763778687e-01
    z[2,4,5]  R1994     -3.2464957237243652e-01
    z[2,4,5]  R1995     -2.0818535983562469e-01
    z[2,4,5]  R1996     -0.0650099441409111
    z[2,4,5]  R1997     -1.1607811599969864e-01
    z[2,4,5]  R1998     -2.1920476853847504e-01
    z[2,4,5]  R1999     0.0813726931810379
    z[2,4,5]  R2000     1.1889610439538956e-02
    z[2,4,5]  R2001     -1.5509258210659027e-01
    z[2,4,5]  R2002     3.3704373240470886e-01
    z[2,4,5]  R2003     -2.8847804665565491e-01
    z[2,4,5]  R2004     -5.0170928239822388e-01
    z[2,4,5]  R2005     -2.4494219571352005e-02
    z[2,4,5]  R2006     2.9188964515924454e-02
    z[2,4,5]  R2007     5.8514147996902466e-01
    z[2,4,5]  R2008     -2.4900746345520020e-01
    z[2,4,5]  R2009     -4.3281638622283936e-01
    z[2,4,5]  R2010     -1.5920111536979675e-01
    z[2,4,5]  R2011     -3.0305919051170349e-01
    z[2,4,5]  R2012     1.8946048617362976e-01
    z[2,4,5]  R2013     9.4566307961940765e-02
    z[2,4,5]  R2014     -2.8468701243400574e-01
    z[2,4,5]  R2015     1.9625541567802429e-01
    z[2,4,5]  R2016     2.4141949415206909e-01
    z[2,4,5]  R2017     6.0804599523544312e-01
    z[2,4,5]  R2018     4.3281927704811096e-02
    z[2,4,5]  R2019     -3.9834147691726685e-01
    z[2,4,5]  R2020     2.0585153996944427e-01
    z[2,4,5]  R2021     -0.155070960521698
    z[2,4,5]  R2022     2.3658762872219086e-01
    z[2,4,5]  R2023     1.8496681749820709e-01
    z[2,4,5]  R2024     -0.0867081880569458
    z[2,4,5]  R2025     -2.5477465987205505e-01
    z[2,4,5]  R2026     -1.9850549101829529e-01
    z[2,4,6]  R26       -1
    z[2,4,6]  R44       1
    z[2,4,6]  R1955     -1
    z[2,4,6]  R1956     1
    z[2,4,6]  R1957     2.1866075694561005e-01
    z[2,4,6]  R1958     -3.8761323690414429e-01
    z[2,4,6]  R1959     2.4217674136161804e-01
    z[2,4,6]  R1960     0.00902604591101408
    z[2,4,6]  R1961     -1.5060876309871674e-01
    z[2,4,6]  R1962     4.7983929514884949e-02
    z[2,4,6]  R1963     8.1237822771072388e-01
    z[2,4,6]  R1964     -1.0642854869365692e-01
    z[2,4,6]  R1965     -2.7126178145408630e-01
    z[2,4,6]  R1966     0.0654611811041832
    z[2,4,6]  R1967     1.5254659950733185e-01
    z[2,4,6]  R1968     6.1572317034006119e-02
    z[2,4,6]  R1969     -2.3658032715320587e-01
    z[2,4,6]  R1970     -1.8264366686344147e-01
    z[2,4,6]  R1971     2.8202015161514282e-01
    z[2,4,6]  R1972     -2.0516102015972137e-01
    z[2,4,6]  R1973     1.2811851501464844e-01
    z[2,4,6]  R1974     -1.0361919552087784e-01
    z[2,4,6]  R1975     -3.0073219537734985e-01
    z[2,4,6]  R1976     -7.0464448072016239e-03
    z[2,4,6]  R1977     6.3782729208469391e-02
    z[2,4,6]  R1978     -1.9276943057775497e-02
    z[2,4,6]  R1979     1.1413117498159409e-01
    z[2,4,6]  R1980     -0.173413947224617
    z[2,4,6]  R1981     -3.1147781759500504e-02
    z[2,4,6]  R1982     9.3287557363510132e-02
    z[2,4,6]  R1983     -3.9194661378860474e-01
    z[2,4,6]  R1984     -2.3904305696487427e-01
    z[2,4,6]  R1985     -3.7199463695287704e-03
    z[2,4,6]  R1986     2.0976182818412781e-01
    z[2,4,6]  R1987     -0.210738867521286
    z[2,4,6]  R1988     -3.1171094626188278e-02
    z[2,4,6]  R1989     2.2929438948631287e-01
    z[2,4,6]  R1990     5.0909918546676636e-01
    z[2,4,6]  R1991     1.2369374930858612e-01
    z[2,4,6]  R1992     -7.8863966464996338e-01
    z[2,4,6]  R1993     -3.7255835533142090e-01
    z[2,4,6]  R1994     -0.0744401067495346
    z[2,4,6]  R1995     -1.5316693484783173e-01
    z[2,4,6]  R1996     -3.9936131797730923e-03
    z[2,4,6]  R1997     3.4250393509864807e-01
    z[2,4,6]  R1998     6.0241949558258057e-01
    z[2,4,6]  R1999     4.5875120162963867e-01
    z[2,4,6]  R2000     3.3511921763420105e-01
    z[2,4,6]  R2001     1.8250516057014465e-01
    z[2,4,6]  R2002     -1.4824721217155457e-01
    z[2,4,6]  R2003     -6.0037189722061157e-01
    z[2,4,6]  R2004     -4.3797045946121216e-01
    z[2,4,6]  R2005     -5.0236219167709351e-01
    z[2,4,6]  R2006     -4.6849304437637329e-01
    z[2,4,6]  R2007     -3.2818296551704407e-01
    z[2,4,6]  R2008     1.7228440940380096e-01
    z[2,4,6]  R2009     1.8132114410400391e-01
    z[2,4,6]  R2010     -3.5852468013763428e-01
    z[2,4,6]  R2011     -3.9278939366340637e-01
    z[2,4,6]  R2012     -3.9323008060455322e-01
    z[2,4,6]  R2013     -4.7162118554115295e-01
    z[2,4,6]  R2014     -3.8046449422836304e-01
    z[2,4,6]  R2015     -2.3921951651573181e-02
    z[2,4,6]  R2016     -2.5964441895484924e-01
    z[2,4,6]  R2017     -1.0932006686925888e-01
    z[2,4,6]  R2018     -7.2604125738143921e-01
    z[2,4,6]  R2019     -1.5151165425777435e-01
    z[2,4,6]  R2020     -2.5049192830920219e-02
    z[2,4,6]  R2021     -1.7614869773387909e-01
    z[2,4,6]  R2022     -8.9096657931804657e-02
    z[2,4,6]  R2023     -2.1664224565029144e-01
    z[2,4,6]  R2024     -1.5606154501438141e-01
    z[2,4,6]  R2025     8.1897906959056854e-02
    z[2,4,6]  R2026     5.6511354446411133e-01
    z[4,2,0]  R20       1
    z[4,2,0]  R38       -1
    z[4,2,0]  R2027     -1
    z[4,2,0]  R2028     1
    z[4,2,0]  R2041     5.5870389938354492e-01
    z[4,2,0]  R2042     9.9818736314773560e-02
    z[4,2,0]  R2043     -2.0530523732304573e-02
    z[4,2,0]  R2044     8.2103852182626724e-03
    z[4,2,0]  R2045     -1.4202977716922760e-01
    z[4,2,0]  R2046     -4.8766386508941650e-01
    z[4,2,0]  R2047     -1.5281499922275543e-01
    z[4,2,0]  R2048     8.8300663232803345e-01
    z[4,2,0]  R2049     7.5461864471435547e-01
    z[4,2,0]  R2050     8.5505962371826172e-01
    z[4,2,0]  R2051     -7.1266913414001465e-01
    z[4,2,0]  R2052     -0.489612340927124
    z[4,2,0]  R2053     -6.8424749374389648e-01
    z[4,2,0]  R2054     -5.7680004835128784e-01
    z[4,2,0]  R2055     -0.0508616641163826
    z[4,2,0]  R2056     9.8354585468769073e-02
    z[4,2,0]  R2057     -1.6463661193847656e-01
    z[4,2,0]  R2058     -2.3018735647201538e-01
    z[4,2,0]  R2059     -2.4711753427982330e-01
    z[4,2,0]  R2060     -7.2288691997528076e-02
    z[4,2,0]  R2061     -5.7580053806304932e-01
    z[4,2,0]  R2062     2.5338813662528992e-01
    z[4,2,0]  R2063     2.2624200209975243e-02
    z[4,2,0]  R2064     4.2387198656797409e-02
    z[4,2,0]  R2065     4.6951755881309509e-02
    z[4,2,0]  R2066     1.1479977518320084e-01
    z[4,2,0]  R2067     -7.6783820986747742e-03
    z[4,2,0]  R2068     -4.7213941812515259e-02
    z[4,2,0]  R2069     2.0390398800373077e-01
    z[4,2,0]  R2070     4.9588415771722794e-02
    z[4,2,0]  R2071     -0.370315819978714
    z[4,2,0]  R2072     -4.2799603939056396e-01
    z[4,2,0]  R2073     2.4122430384159088e-01
    z[4,2,0]  R2074     0.111538365483284
    z[4,2,0]  R2075     2.3198957741260529e-01
    z[4,2,0]  R2076     2.9266181588172913e-01
    z[4,2,0]  R2077     -2.6075911521911621e-01
    z[4,2,0]  R2078     0.12830850481987
    z[4,2,0]  R2079     2.7927669882774353e-01
    z[4,2,0]  R2080     2.9127854108810425e-01
    z[4,2,0]  R2081     2.0851935446262360e-01
    z[4,2,0]  R2082     -1.5403975732624531e-02
    z[4,2,0]  R2083     3.5964307188987732e-01
    z[4,2,0]  R2084     2.5737184286117554e-01
    z[4,2,0]  R2085     -5.0401753187179565e-01
    z[4,2,0]  R2086     5.0322896242141724e-01
    z[4,2,0]  R2087     -2.0297326147556305e-01
    z[4,2,0]  R2088     -4.4124320149421692e-01
    z[4,2,0]  R2089     -4.2562133073806763e-01
    z[4,2,0]  R2090     -4.1262978315353394e-01
    z[4,2,0]  R2091     -8.6052364110946655e-01
    z[4,2,0]  R2092     -5.6854259967803955e-01
    z[4,2,0]  R2093     -7.7454006671905518e-01
    z[4,2,0]  R2094     -6.5631330013275146e-01
    z[4,2,0]  R2095     -6.3293945789337158e-01
    z[4,2,0]  R2096     3.4924343228340149e-01
    z[4,2,0]  R2097     2.7462828159332275e-01
    z[4,2,0]  R2098     5.4640930891036987e-01
    z[4,2,0]  R2099     0.637653648853302
    z[4,2,0]  R2100     6.7432254552841187e-01
    z[4,2,0]  R2101     2.8271627426147461e-01
    z[4,2,0]  R2102     5.7072299718856812e-01
    z[4,2,0]  R2103     5.4416990280151367e-01
    z[4,2,0]  R2104     4.5737496018409729e-01
    z[4,2,0]  R2105     5.2685087919235229e-01
    z[4,2,0]  R2106     5.9256774187088013e-01
    z[4,2,0]  R2107     5.1349717378616333e-01
    z[4,2,0]  R2108     4.4690340757369995e-01
    z[4,2,0]  R2109     5.3048992156982422e-01
    z[4,2,0]  R2110     5.3112769126892090e-01
    z[4,2,1]  R21       1
    z[4,2,1]  R39       -1
    z[4,2,1]  R2029     -1
    z[4,2,1]  R2030     1
    z[4,2,1]  R2041     5.6021219491958618e-01
    z[4,2,1]  R2042     7.8178036212921143e-01
    z[4,2,1]  R2043     7.5345677137374878e-01
    z[4,2,1]  R2044     3.8890364766120911e-01
    z[4,2,1]  R2045     4.9546009302139282e-01
    z[4,2,1]  R2046     1.8506301939487457e-01
    z[4,2,1]  R2047     1.7123848199844360e-01
    z[4,2,1]  R2048     3.8786649703979492e-02
    z[4,2,1]  R2049     -2.4267809092998505e-01
    z[4,2,1]  R2050     -2.5800105929374695e-01
    z[4,2,1]  R2051     -1.9565564393997192e-01
    z[4,2,1]  R2052     -1.5061859786510468e-01
    z[4,2,1]  R2053     -3.5446065664291382e-01
    z[4,2,1]  R2054     -3.8342043757438660e-01
    z[4,2,1]  R2055     -8.9201897382736206e-01
    z[4,2,1]  R2056     -7.1640813350677490e-01
    z[4,2,1]  R2057     -7.1327060461044312e-01
    z[4,2,1]  R2058     -4.8758310079574585e-01
    z[4,2,1]  R2059     -8.1594669818878174e-01
    z[4,2,1]  R2060     -6.2656390666961670e-01
    z[4,2,1]  R2061     1.0611204802989960e-01
    z[4,2,1]  R2062     -4.4901618361473083e-01
    z[4,2,1]  R2063     -7.4879795312881470e-01
    z[4,2,1]  R2064     -8.4246599674224854e-01
    z[4,2,1]  R2065     -7.3599445819854736e-01
    z[4,2,1]  R2066     -7.6748752593994141e-01
    z[4,2,1]  R2067     -8.7122011184692383e-01
    z[4,2,1]  R2068     -0.759326159954071
    z[4,2,1]  R2069     -8.7563234567642212e-01
    z[4,2,1]  R2070     -9.0224641561508179e-01
    z[4,2,1]  R2071     4.2711898684501648e-01
    z[4,2,1]  R2072     1.1950732767581940e-01
    z[4,2,1]  R2073     -7.9304671287536621e-01
    z[4,2,1]  R2074     -6.9904738664627075e-01
    z[4,2,1]  R2075     -8.7748444080352783e-01
    z[4,2,1]  R2076     -8.8935530185699463e-01
    z[4,2,1]  R2077     -7.5103670358657837e-01
    z[4,2,1]  R2078     -8.4581160545349121e-01
    z[4,2,1]  R2079     -1.1033361405134201e-01
    z[4,2,1]  R2080     -6.0323875397443771e-02
    z[4,2,1]  R2081     5.9952521324157715e-01
    z[4,2,1]  R2082     7.3347389698028564e-01
    z[4,2,1]  R2083     5.4051935672760010e-01
    z[4,2,1]  R2084     7.6075994968414307e-01
    z[4,2,1]  R2085     7.6848263852298260e-03
    z[4,2,1]  R2086     -6.0933738946914673e-01
    z[4,2,1]  R2087     -1.2389837950468063e-01
    z[4,2,1]  R2088     1.5843097865581512e-01
    z[4,2,1]  R2089     6.7712232470512390e-02
    z[4,2,1]  R2090     5.8002066798508167e-03
    z[4,2,1]  R2091     -9.5188491046428680e-02
    z[4,2,1]  R2092     -2.5689724087715149e-01
    z[4,2,1]  R2093     1.6511952504515648e-02
    z[4,2,1]  R2094     1.6391709446907043e-01
    z[4,2,1]  R2095     0.169791579246521
    z[4,2,1]  R2096     0.3975810110569
    z[4,2,1]  R2097     3.8544443249702454e-01
    z[4,2,1]  R2098     -0.354875385761261
    z[4,2,1]  R2099     -3.7354382872581482e-01
    z[4,2,1]  R2100     -1.7746937274932861e-01
    z[4,2,1]  R2101     5.2763038873672485e-01
    z[4,2,1]  R2102     -0.36905637383461
    z[4,2,1]  R2103     -4.2943546175956726e-01
    z[4,2,1]  R2104     -4.2379817366600037e-01
    z[4,2,1]  R2105     -4.1507422924041748e-01
    z[4,2,1]  R2106     -4.2539614439010620e-01
    z[4,2,1]  R2107     -2.7495419979095459e-01
    z[4,2,1]  R2108     -2.7008923888206482e-01
    z[4,2,1]  R2109     -1.9018433988094330e-01
    z[4,2,1]  R2110     -3.8987907767295837e-01
    z[4,2,2]  R22       1
    z[4,2,2]  R40       -1
    z[4,2,2]  R2031     -1
    z[4,2,2]  R2032     1
    z[4,2,2]  R2041     -3.8512402772903442e-01
    z[4,2,2]  R2042     5.6504216045141220e-02
    z[4,2,2]  R2043     -3.9413750171661377e-01
    z[4,2,2]  R2044     1.1042091995477676e-01
    z[4,2,2]  R2045     1.2807871401309967e-01
    z[4,2,2]  R2046     1.2600994668900967e-02
    z[4,2,2]  R2047     1.0695854574441910e-01
    z[4,2,2]  R2048     3.7434976547956467e-02
    z[4,2,2]  R2049     1.3555747270584106e-01
    z[4,2,2]  R2050     -0.0625605583190918
    z[4,2,2]  R2051     0.49066162109375
    z[4,2,2]  R2052     3.7475490570068359e-01
    z[4,2,2]  R2053     -1.8631502985954285e-01
    z[4,2,2]  R2054     -5.3598236292600632e-02
    z[4,2,2]  R2055     -9.7490988671779633e-02
    z[4,2,2]  R2056     -5.3910166025161743e-01
    z[4,2,2]  R2057     -1.0701456665992737e-01
    z[4,2,2]  R2058     -3.9065742492675781e-01
    z[4,2,2]  R2059     -7.0837214589118958e-02
    z[4,2,2]  R2060     -4.8441314697265625e-01
    z[4,2,2]  R2061     -1.2420298904180527e-01
    z[4,2,2]  R2062     -3.6703076958656311e-01
    z[4,2,2]  R2063     -8.0870762467384338e-02
    z[4,2,2]  R2064     -1.6054618358612061e-01
    z[4,2,2]  R2065     -1.4383193850517273e-01
    z[4,2,2]  R2066     -2.4992391467094421e-01
    z[4,2,2]  R2067     -8.3724528551101685e-02
    z[4,2,2]  R2068     3.0607774853706360e-01
    z[4,2,2]  R2069     3.2696709036827087e-01
    z[4,2,2]  R2070     2.2576428949832916e-01
    z[4,2,2]  R2071     -3.0090728402137756e-01
    z[4,2,2]  R2072     -2.3227781057357788e-01
    z[4,2,2]  R2073     -1.1948853731155396e-01
    z[4,2,2]  R2074     -1.9092109799385071e-01
    z[4,2,2]  R2075     3.3038997650146484e-01
    z[4,2,2]  R2076     1.7247335612773895e-01
    z[4,2,2]  R2077     -6.6403280943632126e-03
    z[4,2,2]  R2078     3.6510783433914185e-01
    z[4,2,2]  R2079     -7.7136582136154175e-01
    z[4,2,2]  R2080     -0.623135507106781
    z[4,2,2]  R2081     -4.0175938606262207e-01
    z[4,2,2]  R2082     -0.0754147619009018
    z[4,2,2]  R2083     -5.1272273063659668e-01
    z[4,2,2]  R2084     4.7629281878471375e-02
    z[4,2,2]  R2085     4.2262795567512512e-01
    z[4,2,2]  R2086     -3.9237266778945923e-01
    z[4,2,2]  R2087     0.0480094775557518
    z[4,2,2]  R2088     -3.9981681853532791e-02
    z[4,2,2]  R2089     -5.0601817667484283e-02
    z[4,2,2]  R2090     3.1279647350311279e-01
    z[4,2,2]  R2091     -1.2840218842029572e-01
    z[4,2,2]  R2092     -3.8769415020942688e-01
    z[4,2,2]  R2093     -5.0271785259246826e-01
    z[4,2,2]  R2094     2.7499321103096008e-01
    z[4,2,2]  R2095     3.5533748567104340e-02
    z[4,2,2]  R2096     -4.8125658184289932e-02
    z[4,2,2]  R2097     1.6836115717887878e-01
    z[4,2,2]  R2098     4.5957425236701965e-01
    z[4,2,2]  R2099     3.9908558130264282e-01
    z[4,2,2]  R2100     3.9081260561943054e-01
    z[4,2,2]  R2101     5.9389103204011917e-02
    z[4,2,2]  R2102     0.49821937084198
    z[4,2,2]  R2103     5.1848423480987549e-01
    z[4,2,2]  R2104     6.0682344436645508e-01
    z[4,2,2]  R2105     5.9697711467742920e-01
    z[4,2,2]  R2106     3.2818609476089478e-01
    z[4,2,2]  R2107     4.1627770662307739e-01
    z[4,2,2]  R2108     5.0859099626541138e-01
    z[4,2,2]  R2109     4.5980966091156006e-01
    z[4,2,2]  R2110     2.1257606148719788e-01
    z[4,2,3]  R23       1
    z[4,2,3]  R41       -1
    z[4,2,3]  R2033     -1
    z[4,2,3]  R2034     1
    z[4,2,3]  R2041     -3.8021820783615112e-01
    z[4,2,3]  R2042     -4.8384204506874084e-01
    z[4,2,3]  R2043     -3.6220863461494446e-01
    z[4,2,3]  R2044     -4.1754421591758728e-01
    z[4,2,3]  R2045     -2.9438000917434692e-01
    z[4,2,3]  R2046     -3.1255516409873962e-01
    z[4,2,3]  R2047     6.8910324573516846e-01
    z[4,2,3]  R2048     -3.0642330646514893e-01
    z[4,2,3]  R2049     -0.398311972618103
    z[4,2,3]  R2050     -2.8055045008659363e-01
    z[4,2,3]  R2051     2.8187143802642822e-01
    z[4,2,3]  R2052     4.5860681682825089e-02
    z[4,2,3]  R2053     -2.4828857183456421e-01
    z[4,2,3]  R2054     -1.3207701034843922e-02
    z[4,2,3]  R2055     -8.9316688477993011e-02
    z[4,2,3]  R2056     -2.1141889691352844e-01
    z[4,2,3]  R2057     9.3292370438575745e-02
    z[4,2,3]  R2058     -3.2621735334396362e-01
    z[4,2,3]  R2059     -1.0185866057872772e-01
    z[4,2,3]  R2060     -3.8146099448204041e-01
    z[4,2,3]  R2061     3.0751854181289673e-01
    z[4,2,3]  R2062     -6.9934684038162231e-01
    z[4,2,3]  R2063     -3.2809826731681824e-01
    z[4,2,3]  R2064     -3.1848379969596863e-01
    z[4,2,3]  R2065     -3.9895847439765930e-01
    z[4,2,3]  R2066     -3.7319111824035645e-01
    z[4,2,3]  R2067     3.6862384527921677e-02
    z[4,2,3]  R2068     8.2869239151477814e-02
    z[4,2,3]  R2069     2.8244696557521820e-02
    z[4,2,3]  R2070     -5.6988544762134552e-02
    z[4,2,3]  R2071     4.1068476438522339e-01
    z[4,2,3]  R2072     3.7810587882995605e-01
    z[4,2,3]  R2073     -3.4058916568756104e-01
    z[4,2,3]  R2074     -5.4312676191329956e-01
    z[4,2,3]  R2075     -9.5807880163192749e-02
    z[4,2,3]  R2076     2.8587602078914642e-02
    z[4,2,3]  R2077     -3.5784307122230530e-01
    z[4,2,3]  R2078     2.3451048135757446e-01
    z[4,2,3]  R2079     4.9130004644393921e-01
    z[4,2,3]  R2080     4.0348741412162781e-01
    z[4,2,3]  R2081     -3.8041961193084717e-01
    z[4,2,3]  R2082     -4.0003478527069092e-01
    z[4,2,3]  R2083     -3.1106692552566528e-01
    z[4,2,3]  R2084     -4.1161969304084778e-01
    z[4,2,3]  R2085     2.6464501023292542e-01
    z[4,2,3]  R2086     -3.0929449200630188e-01
    z[4,2,3]  R2087     3.8125178217887878e-01
    z[4,2,3]  R2088     7.1631860733032227e-01
    z[4,2,3]  R2089     7.1944117546081543e-01
    z[4,2,3]  R2090     3.1913855671882629e-01
    z[4,2,3]  R2091     -9.6025623381137848e-02
    z[4,2,3]  R2092     2.6896673440933228e-01
    z[4,2,3]  R2093     1.9394946098327637e-01
    z[4,2,3]  R2094     1.8569202721118927e-01
    z[4,2,3]  R2095     3.1972801685333252e-01
    z[4,2,3]  R2096     7.7558934688568115e-01
    z[4,2,3]  R2097     6.8880569934844971e-01
    z[4,2,3]  R2098     5.7362580299377441e-01
    z[4,2,3]  R2099     3.9625069499015808e-01
    z[4,2,3]  R2100     5.5744445323944092e-01
    z[4,2,3]  R2101     7.7658736705780029e-01
    z[4,2,3]  R2102     4.8028782010078430e-01
    z[4,2,3]  R2103     3.7779018282890320e-01
    z[4,2,3]  R2104     3.5796162486076355e-01
    z[4,2,3]  R2105     4.1075026988983154e-01
    z[4,2,3]  R2106     3.3119884133338928e-01
    z[4,2,3]  R2107     4.9578070640563965e-01
    z[4,2,3]  R2108     4.5892271399497986e-01
    z[4,2,3]  R2109     5.3256541490554810e-01
    z[4,2,3]  R2110     3.6666208505630493e-01
    z[4,2,4]  R24       1
    z[4,2,4]  R42       -1
    z[4,2,4]  R2035     -1
    z[4,2,4]  R2036     1
    z[4,2,4]  R2041     -1.8614172935485840e-01
    z[4,2,4]  R2042     2.1207168698310852e-01
    z[4,2,4]  R2043     1.3169211149215698e-01
    z[4,2,4]  R2044     -5.8622401952743530e-01
    z[4,2,4]  R2045     -7.0075875520706177e-01
    z[4,2,4]  R2046     2.7352645993232727e-02
    z[4,2,4]  R2047     4.4997197389602661e-01
    z[4,2,4]  R2048     -1.1206955462694168e-01
    z[4,2,4]  R2049     -3.5753118991851807e-01
    z[4,2,4]  R2050     3.3977007865905762e-01
    z[4,2,4]  R2051     5.3274929523468018e-02
    z[4,2,4]  R2052     4.2905649542808533e-01
    z[4,2,4]  R2053     3.0451324582099915e-01
    z[4,2,4]  R2054     6.3623654842376709e-01
    z[4,2,4]  R2055     -3.5619032382965088e-01
    z[4,2,4]  R2056     -7.8622095286846161e-02
    z[4,2,4]  R2057     -1.7840167507529259e-02
    z[4,2,4]  R2058     -8.1945598125457764e-02
    z[4,2,4]  R2059     -6.9304317235946655e-02
    z[4,2,4]  R2060     -0.0410560667514801
    z[4,2,4]  R2061     -3.1161725521087646e-01
    z[4,2,4]  R2062     1.3672819733619690e-01
    z[4,2,4]  R2063     -3.2310044765472412e-01
    z[4,2,4]  R2064     8.5804097354412079e-02
    z[4,2,4]  R2065     -1.7356221377849579e-01
    z[4,2,4]  R2066     -7.4332311749458313e-02
    z[4,2,4]  R2067     -3.4329265356063843e-02
    z[4,2,4]  R2068     -3.0796703696250916e-01
    z[4,2,4]  R2069     2.1189035475254059e-01
    z[4,2,4]  R2070     5.9805028140544891e-02
    z[4,2,4]  R2071     1.9889065623283386e-01
    z[4,2,4]  R2072     -2.7678728103637695e-01
    z[4,2,4]  R2073     3.1266503036022186e-02
    z[4,2,4]  R2074     -3.5277768969535828e-01
    z[4,2,4]  R2075     -5.2817653864622116e-02
    z[4,2,4]  R2076     -1.7005857825279236e-01
    z[4,2,4]  R2077     -3.9837956428527832e-01
    z[4,2,4]  R2078     -2.1901425719261169e-01
    z[4,2,4]  R2079     -4.2809482663869858e-02
    z[4,2,4]  R2080     -4.0744204074144363e-02
    z[4,2,4]  R2081     -4.8983284831047058e-01
    z[4,2,4]  R2082     2.7587356045842171e-02
    z[4,2,4]  R2083     3.8253080844879150e-01
    z[4,2,4]  R2084     2.2896544635295868e-01
    z[4,2,4]  R2085     0.61134272813797
    z[4,2,4]  R2086     5.2625991404056549e-02
    z[4,2,4]  R2087     -0.245507150888443
    z[4,2,4]  R2088     -4.7838117927312851e-02
    z[4,2,4]  R2089     -4.5447820425033569e-01
    z[4,2,4]  R2090     -7.2568637132644653e-01
    z[4,2,4]  R2091     -2.4012076854705811e-01
    z[4,2,4]  R2092     -4.1983744502067566e-01
    z[4,2,4]  R2093     -2.0180565118789673e-01
    z[4,2,4]  R2094     -5.9347146749496460e-01
    z[4,2,4]  R2095     -6.8957552313804626e-02
    z[4,2,4]  R2096     -2.2105820477008820e-01
    z[4,2,4]  R2097     -8.8698320090770721e-02
    z[4,2,4]  R2098     -1.4955131709575653e-01
    z[4,2,4]  R2099     -5.1410477608442307e-03
    z[4,2,4]  R2100     1.3310334086418152e-01
    z[4,2,4]  R2101     -1.3876292109489441e-01
    z[4,2,4]  R2102     -2.4128077924251556e-01
    z[4,2,4]  R2103     -3.0206805467605591e-01
    z[4,2,4]  R2104     -2.2211056947708130e-01
    z[4,2,4]  R2105     1.5509857237339020e-01
    z[4,2,4]  R2106     -3.3147913217544556e-01
    z[4,2,4]  R2107     5.0097596831619740e-03
    z[4,2,4]  R2108     2.2887936234474182e-01
    z[4,2,4]  R2109     -1.0418955981731415e-01
    z[4,2,4]  R2110     -5.0786298513412476e-01
    z[4,2,5]  R25       1
    z[4,2,5]  R43       -1
    z[4,2,5]  R2037     -1
    z[4,2,5]  R2038     1
    z[4,2,5]  R2041     4.5455317944288254e-02
    z[4,2,5]  R2042     3.0921491980552673e-01
    z[4,2,5]  R2043     -2.7463287115097046e-01
    z[4,2,5]  R2044     2.4353665113449097e-01
    z[4,2,5]  R2045     -3.5344031453132629e-01
    z[4,2,5]  R2046     -8.5938408970832825e-02
    z[4,2,5]  R2047     3.4604495763778687e-01
    z[4,2,5]  R2048     -3.2464957237243652e-01
    z[4,2,5]  R2049     -2.0818535983562469e-01
    z[4,2,5]  R2050     -0.0650099441409111
    z[4,2,5]  R2051     -1.1607811599969864e-01
    z[4,2,5]  R2052     -2.1920476853847504e-01
    z[4,2,5]  R2053     0.0813726931810379
    z[4,2,5]  R2054     1.1889610439538956e-02
    z[4,2,5]  R2055     -1.5509258210659027e-01
    z[4,2,5]  R2056     3.3704373240470886e-01
    z[4,2,5]  R2057     -2.8847804665565491e-01
    z[4,2,5]  R2058     -5.0170928239822388e-01
    z[4,2,5]  R2059     -2.4494219571352005e-02
    z[4,2,5]  R2060     2.9188964515924454e-02
    z[4,2,5]  R2061     5.8514147996902466e-01
    z[4,2,5]  R2062     -2.4900746345520020e-01
    z[4,2,5]  R2063     -4.3281638622283936e-01
    z[4,2,5]  R2064     -1.5920111536979675e-01
    z[4,2,5]  R2065     -3.0305919051170349e-01
    z[4,2,5]  R2066     1.8946048617362976e-01
    z[4,2,5]  R2067     9.4566307961940765e-02
    z[4,2,5]  R2068     -2.8468701243400574e-01
    z[4,2,5]  R2069     1.9625541567802429e-01
    z[4,2,5]  R2070     2.4141949415206909e-01
    z[4,2,5]  R2071     6.0804599523544312e-01
    z[4,2,5]  R2072     4.3281927704811096e-02
    z[4,2,5]  R2073     -3.9834147691726685e-01
    z[4,2,5]  R2074     2.0585153996944427e-01
    z[4,2,5]  R2075     -0.155070960521698
    z[4,2,5]  R2076     2.3658762872219086e-01
    z[4,2,5]  R2077     1.8496681749820709e-01
    z[4,2,5]  R2078     -0.0867081880569458
    z[4,2,5]  R2079     -2.5477465987205505e-01
    z[4,2,5]  R2080     -1.9850549101829529e-01
    z[4,2,5]  R2081     5.6663446128368378e-02
    z[4,2,5]  R2082     -3.8086524605751038e-01
    z[4,2,5]  R2083     -1.1776731908321381e-01
    z[4,2,5]  R2084     3.6166024208068848e-01
    z[4,2,5]  R2085     -3.1754210591316223e-01
    z[4,2,5]  R2086     3.4753009676933289e-01
    z[4,2,5]  R2087     2.7488359808921814e-01
    z[4,2,5]  R2088     5.0187402963638306e-01
    z[4,2,5]  R2089     1.1820279061794281e-01
    z[4,2,5]  R2090     -3.1481122970581055e-01
    z[4,2,5]  R2091     3.7921205163002014e-01
    z[4,2,5]  R2092     -4.5613449811935425e-01
    z[4,2,5]  R2093     1.1303842067718506e-01
    z[4,2,5]  R2094     2.1613454818725586e-01
    z[4,2,5]  R2095     6.1869156360626221e-01
    z[4,2,5]  R2096     -1.5857380628585815e-01
    z[4,2,5]  R2097     -4.9893024563789368e-01
    z[4,2,5]  R2098     4.6290088444948196e-02
    z[4,2,5]  R2099     -2.1705435216426849e-01
    z[4,2,5]  R2100     1.8041309714317322e-01
    z[4,2,5]  R2101     -1.0834795981645584e-01
    z[4,2,5]  R2102     -2.4197725579142570e-02
    z[4,2,5]  R2103     -6.0347881168127060e-02
    z[4,2,5]  R2104     1.8821948766708374e-01
    z[4,2,5]  R2105     -4.2746751569211483e-03
    z[4,2,5]  R2106     -3.6321040987968445e-01
    z[4,2,5]  R2107     2.9662764072418213e-01
    z[4,2,5]  R2108     3.8539204001426697e-01
    z[4,2,5]  R2109     4.2010742425918579e-01
    z[4,2,5]  R2110     -2.9041895270347595e-01
    z[4,2,6]  R26       1
    z[4,2,6]  R44       -1
    z[4,2,6]  R2039     -1
    z[4,2,6]  R2040     1
    z[4,2,6]  R2041     -0.210738867521286
    z[4,2,6]  R2042     -3.1171094626188278e-02
    z[4,2,6]  R2043     2.2929438948631287e-01
    z[4,2,6]  R2044     5.0909918546676636e-01
    z[4,2,6]  R2045     1.2369374930858612e-01
    z[4,2,6]  R2046     -7.8863966464996338e-01
    z[4,2,6]  R2047     -3.7255835533142090e-01
    z[4,2,6]  R2048     -0.0744401067495346
    z[4,2,6]  R2049     -1.5316693484783173e-01
    z[4,2,6]  R2050     -3.9936131797730923e-03
    z[4,2,6]  R2051     3.4250393509864807e-01
    z[4,2,6]  R2052     6.0241949558258057e-01
    z[4,2,6]  R2053     4.5875120162963867e-01
    z[4,2,6]  R2054     3.3511921763420105e-01
    z[4,2,6]  R2055     1.8250516057014465e-01
    z[4,2,6]  R2056     -1.4824721217155457e-01
    z[4,2,6]  R2057     -6.0037189722061157e-01
    z[4,2,6]  R2058     -4.3797045946121216e-01
    z[4,2,6]  R2059     -5.0236219167709351e-01
    z[4,2,6]  R2060     -4.6849304437637329e-01
    z[4,2,6]  R2061     -3.2818296551704407e-01
    z[4,2,6]  R2062     1.7228440940380096e-01
    z[4,2,6]  R2063     1.8132114410400391e-01
    z[4,2,6]  R2064     -3.5852468013763428e-01
    z[4,2,6]  R2065     -3.9278939366340637e-01
    z[4,2,6]  R2066     -3.9323008060455322e-01
    z[4,2,6]  R2067     -4.7162118554115295e-01
    z[4,2,6]  R2068     -3.8046449422836304e-01
    z[4,2,6]  R2069     -2.3921951651573181e-02
    z[4,2,6]  R2070     -2.5964441895484924e-01
    z[4,2,6]  R2071     -1.0932006686925888e-01
    z[4,2,6]  R2072     -7.2604125738143921e-01
    z[4,2,6]  R2073     -1.5151165425777435e-01
    z[4,2,6]  R2074     -2.5049192830920219e-02
    z[4,2,6]  R2075     -1.7614869773387909e-01
    z[4,2,6]  R2076     -8.9096657931804657e-02
    z[4,2,6]  R2077     -2.1664224565029144e-01
    z[4,2,6]  R2078     -1.5606154501438141e-01
    z[4,2,6]  R2079     8.1897906959056854e-02
    z[4,2,6]  R2080     5.6511354446411133e-01
    z[4,2,6]  R2081     2.1866075694561005e-01
    z[4,2,6]  R2082     -3.8761323690414429e-01
    z[4,2,6]  R2083     2.4217674136161804e-01
    z[4,2,6]  R2084     0.00902604591101408
    z[4,2,6]  R2085     -1.5060876309871674e-01
    z[4,2,6]  R2086     4.7983929514884949e-02
    z[4,2,6]  R2087     8.1237822771072388e-01
    z[4,2,6]  R2088     -1.0642854869365692e-01
    z[4,2,6]  R2089     -2.7126178145408630e-01
    z[4,2,6]  R2090     0.0654611811041832
    z[4,2,6]  R2091     1.5254659950733185e-01
    z[4,2,6]  R2092     6.1572317034006119e-02
    z[4,2,6]  R2093     -2.3658032715320587e-01
    z[4,2,6]  R2094     -1.8264366686344147e-01
    z[4,2,6]  R2095     2.8202015161514282e-01
    z[4,2,6]  R2096     -2.0516102015972137e-01
    z[4,2,6]  R2097     1.2811851501464844e-01
    z[4,2,6]  R2098     -1.0361919552087784e-01
    z[4,2,6]  R2099     -3.0073219537734985e-01
    z[4,2,6]  R2100     -7.0464448072016239e-03
    z[4,2,6]  R2101     6.3782729208469391e-02
    z[4,2,6]  R2102     -1.9276943057775497e-02
    z[4,2,6]  R2103     1.1413117498159409e-01
    z[4,2,6]  R2104     -0.173413947224617
    z[4,2,6]  R2105     -3.1147781759500504e-02
    z[4,2,6]  R2106     9.3287557363510132e-02
    z[4,2,6]  R2107     -3.9194661378860474e-01
    z[4,2,6]  R2108     -2.3904305696487427e-01
    z[4,2,6]  R2109     -3.7199463695287704e-03
    z[4,2,6]  R2110     2.0976182818412781e-01
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R2155     -1
    z[3,4,0]  R2156     1
    z[3,4,0]  R2169     -3.4406775236129761e-01
    z[3,4,0]  R2170     -3.2790100574493408e-01
    z[3,4,0]  R2171     -2.7911195158958435e-01
    z[3,4,0]  R2172     -2.5956231355667114e-01
    z[3,4,0]  R2173     -0.389911025762558
    z[3,4,0]  R2174     -0.200189471244812
    z[3,4,0]  R2175     -2.5247624516487122e-01
    z[3,4,0]  R2176     7.9031985998153687e-01
    z[3,4,0]  R2177     8.8028162717819214e-01
    z[3,4,0]  R2178     8.6288440227508545e-01
    z[3,4,0]  R2179     -5.6515991687774658e-01
    z[3,4,0]  R2180     -7.2183072566986084e-01
    z[3,4,0]  R2181     -1.0561756044626236e-01
    z[3,4,0]  R2182     9.0281152725219727e-01
    z[3,4,0]  R2183     -5.6377702951431274e-01
    z[3,4,0]  R2184     -4.2510709166526794e-01
    z[3,4,0]  R2185     -3.1426465511322021e-01
    z[3,4,0]  R2186     -0.472042441368103
    z[3,4,0]  R2187     -5.2815198898315430e-01
    z[3,4,0]  R2188     -4.3587875366210938e-01
    z[3,4,0]  R2189     -8.0650782585144043e-01
    z[3,4,0]  R2190     -5.4882502555847168e-01
    z[3,4,0]  R2191     -5.3742176294326782e-01
    z[3,4,0]  R2192     -5.6928426027297974e-01
    z[3,4,0]  R2193     -5.6497520208358765e-01
    z[3,4,0]  R2194     -6.1704134941101074e-01
    z[3,4,0]  R2195     -0.656769335269928
    z[3,4,0]  R2196     -7.2379314899444580e-01
    z[3,4,0]  R2197     -4.4615957140922546e-01
    z[3,4,0]  R2198     -5.2692312002182007e-01
    z[3,4,0]  R2199     -3.8040143251419067e-01
    z[3,4,0]  R2200     -8.1182342767715454e-01
    z[3,4,0]  R2201     -0.684876024723053
    z[3,4,0]  R2202     -5.0133860111236572e-01
    z[3,4,0]  R2203     -5.6957280635833740e-01
    z[3,4,0]  R2204     0.356876015663147
    z[3,4,0]  R2205     8.1507444381713867e-01
    z[3,4,0]  R2206     9.1206395626068115e-01
    z[3,4,0]  R2207     7.6318812370300293e-01
    z[3,4,0]  R2208     8.7414103746414185e-01
    z[3,4,0]  R2209     -5.3127700090408325e-01
    z[3,4,0]  R2210     -3.3868685364723206e-01
    z[3,4,0]  R2211     -3.4689253568649292e-01
    z[3,4,0]  R2212     -0.587253212928772
    z[3,4,0]  R2213     -2.1451064944267273e-01
    z[3,4,0]  R2214     -1.4580808579921722e-01
    z[3,4,0]  R2215     -5.0207239389419556e-01
    z[3,4,0]  R2216     -6.3019603490829468e-01
    z[3,4,0]  R2217     -6.6657543182373047e-01
    z[3,4,0]  R2218     -4.9757176637649536e-01
    z[3,4,0]  R2219     -5.4342097043991089e-01
    z[3,4,0]  R2220     -8.4325426816940308e-01
    z[3,4,0]  R2221     -8.3551156520843506e-01
    z[3,4,0]  R2222     -5.7310348749160767e-01
    z[3,4,0]  R2223     -3.0678653717041016e-01
    z[3,4,0]  R2224     -0.371635377407074
    z[3,4,0]  R2225     -5.5593419075012207e-01
    z[3,4,0]  R2226     4.6494059264659882e-02
    z[3,4,0]  R2227     8.0510163307189941e-01
    z[3,4,0]  R2228     8.6243516206741333e-01
    z[3,4,0]  R2229     6.2239643186330795e-02
    z[3,4,0]  R2230     -7.6600360870361328e-01
    z[3,4,0]  R2231     5.9907469898462296e-02
    z[3,4,0]  R2232     -6.7986255884170532e-01
    z[3,4,0]  R2233     -6.9654667377471924e-01
    z[3,4,0]  R2234     -5.5627793073654175e-01
    z[3,4,0]  R2235     -7.0455557107925415e-01
    z[3,4,0]  R2236     -2.4017766118049622e-02
    z[3,4,0]  R2237     8.6195367574691772e-01
    z[3,4,0]  R2238     8.7085694074630737e-01
    z[3,4,0]  R2239     -4.1222232580184937e-01
    z[3,4,0]  R2240     -3.7235784530639648e-01
    z[3,4,0]  R2241     -2.5136863812804222e-02
    z[3,4,0]  R2242     -7.5712692737579346e-01
    z[3,4,0]  R2243     -5.1961249113082886e-01
    z[3,4,0]  R2244     -1.2179906666278839e-01
    z[3,4,0]  R2245     9.1755294799804688e-01
    z[3,4,0]  R2246     7.9644507169723511e-01
    z[3,4,0]  R2247     0.795567512512207
    z[3,4,0]  R2248     8.2271134853363037e-01
    z[3,4,0]  R2249     -4.8599314689636230e-01
    z[3,4,0]  R2250     -6.6693328320980072e-02
    z[3,4,0]  R2251     -4.7179032117128372e-02
    z[3,4,0]  R2252     -2.1626415848731995e-01
    z[3,4,0]  R2253     -2.4165056645870209e-01
    z[3,4,0]  R2254     -8.7707346677780151e-01
    z[3,4,0]  R2255     -8.2092583179473877e-01
    z[3,4,0]  R2256     3.0467975139617920e-01
    z[3,4,0]  R2257     -7.1975088119506836e-01
    z[3,4,0]  R2258     8.4028869867324829e-01
    z[3,4,0]  R2259     5.5870389938354492e-01
    z[3,4,0]  R2260     9.9818736314773560e-02
    z[3,4,0]  R2261     -2.0530523732304573e-02
    z[3,4,0]  R2262     8.2103852182626724e-03
    z[3,4,0]  R2263     -1.4202977716922760e-01
    z[3,4,0]  R2264     -4.8766386508941650e-01
    z[3,4,0]  R2265     -1.5281499922275543e-01
    z[3,4,0]  R2266     8.8300663232803345e-01
    z[3,4,0]  R2267     7.5461864471435547e-01
    z[3,4,0]  R2268     8.5505962371826172e-01
    z[3,4,0]  R2269     -7.1266913414001465e-01
    z[3,4,0]  R2270     -0.489612340927124
    z[3,4,0]  R2271     -6.8424749374389648e-01
    z[3,4,0]  R2272     -5.7680004835128784e-01
    z[3,4,0]  R2273     -0.0508616641163826
    z[3,4,0]  R2274     9.8354585468769073e-02
    z[3,4,0]  R2275     -1.6463661193847656e-01
    z[3,4,0]  R2276     -2.3018735647201538e-01
    z[3,4,0]  R2277     -2.4711753427982330e-01
    z[3,4,0]  R2278     -7.2288691997528076e-02
    z[3,4,0]  R2279     -5.7580053806304932e-01
    z[3,4,0]  R2280     2.5338813662528992e-01
    z[3,4,0]  R2281     2.2624200209975243e-02
    z[3,4,0]  R2282     4.2387198656797409e-02
    z[3,4,0]  R2283     4.6951755881309509e-02
    z[3,4,0]  R2284     1.1479977518320084e-01
    z[3,4,0]  R2285     -7.6783820986747742e-03
    z[3,4,0]  R2286     -4.7213941812515259e-02
    z[3,4,0]  R2287     2.0390398800373077e-01
    z[3,4,0]  R2288     4.9588415771722794e-02
    z[3,4,0]  R2289     -0.370315819978714
    z[3,4,0]  R2290     -4.2799603939056396e-01
    z[3,4,0]  R2291     2.4122430384159088e-01
    z[3,4,0]  R2292     0.111538365483284
    z[3,4,0]  R2293     2.3198957741260529e-01
    z[3,4,0]  R2294     2.9266181588172913e-01
    z[3,4,0]  R2295     -2.6075911521911621e-01
    z[3,4,0]  R2296     0.12830850481987
    z[3,4,0]  R2297     2.7927669882774353e-01
    z[3,4,0]  R2298     2.9127854108810425e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R2157     -1
    z[3,4,1]  R2158     1
    z[3,4,1]  R2169     -4.0743622183799744e-01
    z[3,4,1]  R2170     -1.9889074563980103e-01
    z[3,4,1]  R2171     5.7454162836074829e-01
    z[3,4,1]  R2172     1.6744308173656464e-01
    z[3,4,1]  R2173     -3.1165421009063721e-01
    z[3,4,1]  R2174     3.1051808595657349e-01
    z[3,4,1]  R2175     4.2386922240257263e-01
    z[3,4,1]  R2176     -0.0718371719121933
    z[3,4,1]  R2177     -8.9955933392047882e-02
    z[3,4,1]  R2178     5.7048797607421875e-02
    z[3,4,1]  R2179     -1.1104349046945572e-01
    z[3,4,1]  R2180     -1.6461621224880219e-01
    z[3,4,1]  R2181     -4.3762156367301941e-01
    z[3,4,1]  R2182     1.6248683631420135e-01
    z[3,4,1]  R2183     1.1134830117225647e-01
    z[3,4,1]  R2184     -7.3070541024208069e-02
    z[3,4,1]  R2185     9.6246063709259033e-02
    z[3,4,1]  R2186     1.1782778799533844e-01
    z[3,4,1]  R2187     2.7041202783584595e-01
    z[3,4,1]  R2188     -5.4209005832672119e-01
    z[3,4,1]  R2189     3.8884720206260681e-01
    z[3,4,1]  R2190     -3.4910616278648376e-01
    z[3,4,1]  R2191     5.5928987264633179e-01
    z[3,4,1]  R2192     4.4444081187248230e-01
    z[3,4,1]  R2193     0.575400710105896
    z[3,4,1]  R2194     4.9236461520195007e-01
    z[3,4,1]  R2195     3.6707437038421631e-01
    z[3,4,1]  R2196     -0.401419073343277
    z[3,4,1]  R2197     5.9140056371688843e-01
    z[3,4,1]  R2198     1.9477939605712891e-01
    z[3,4,1]  R2199     5.6616431474685669e-01
    z[3,4,1]  R2200     4.7562189400196075e-02
    z[3,4,1]  R2201     2.3031720519065857e-01
    z[3,4,1]  R2202     -1.3365231454372406e-01
    z[3,4,1]  R2203     3.5345628857612610e-02
    z[3,4,1]  R2204     -5.4927694797515869e-01
    z[3,4,1]  R2205     -2.5580203533172607e-01
    z[3,4,1]  R2206     -2.9031846672296524e-02
    z[3,4,1]  R2207     2.1840266883373260e-01
    z[3,4,1]  R2208     1.0058821178972721e-02
    z[3,4,1]  R2209     -4.8622789978981018e-01
    z[3,4,1]  R2210     2.0794808864593506e-01
    z[3,4,1]  R2211     4.7027045488357544e-01
    z[3,4,1]  R2212     -7.0744462311267853e-02
    z[3,4,1]  R2213     -2.3843885958194733e-01
    z[3,4,1]  R2214     -1.1425514519214630e-01
    z[3,4,1]  R2215     -4.8765793442726135e-01
    z[3,4,1]  R2216     -2.7695251628756523e-02
    z[3,4,1]  R2217     -4.5463964343070984e-02
    z[3,4,1]  R2218     3.7216268479824066e-02
    z[3,4,1]  R2219     0.563527524471283
    z[3,4,1]  R2220     2.7319166064262390e-01
    z[3,4,1]  R2221     -1.4385347068309784e-01
    z[3,4,1]  R2222     7.2615332901477814e-03
    z[3,4,1]  R2223     8.1111228466033936e-01
    z[3,4,1]  R2224     3.2436794042587280e-01
    z[3,4,1]  R2225     4.0905106067657471e-01
    z[3,4,1]  R2226     -6.5500330924987793e-01
    z[3,4,1]  R2227     3.4475263953208923e-01
    z[3,4,1]  R2228     1.8451488018035889e-01
    z[3,4,1]  R2229     -3.3994078636169434e-01
    z[3,4,1]  R2230     4.7159090638160706e-01
    z[3,4,1]  R2231     -2.5233197212219238e-01
    z[3,4,1]  R2232     1.8022919073700905e-02
    z[3,4,1]  R2233     0.0539570190012455
    z[3,4,1]  R2234     1.6202329099178314e-01
    z[3,4,1]  R2235     2.8932240605354309e-01
    z[3,4,1]  R2236     -7.3883497714996338e-01
    z[3,4,1]  R2237     -1.1312500573694706e-03
    z[3,4,1]  R2238     2.0633409917354584e-01
    z[3,4,1]  R2239     -0.57985520362854
    z[3,4,1]  R2240     5.2900129556655884e-01
    z[3,4,1]  R2241     -0.422419011592865
    z[3,4,1]  R2242     -3.2618728280067444e-01
    z[3,4,1]  R2243     3.6254149675369263e-01
    z[3,4,1]  R2244     1.5918913483619690e-01
    z[3,4,1]  R2245     9.1630041599273682e-02
    z[3,4,1]  R2246     1.0925793647766113e-01
    z[3,4,1]  R2247     -1.5200471878051758e-01
    z[3,4,1]  R2248     -2.1054264903068542e-01
    z[3,4,1]  R2249     2.1635462343692780e-01
    z[3,4,1]  R2250     -3.5965493321418762e-01
    z[3,4,1]  R2251     -5.1427793502807617e-01
    z[3,4,1]  R2252     -3.7195730209350586e-01
    z[3,4,1]  R2253     -6.8676269054412842e-01
    z[3,4,1]  R2254     1.7070958018302917e-01
    z[3,4,1]  R2255     2.0195762813091278e-01
    z[3,4,1]  R2256     -6.7172354459762573e-01
    z[3,4,1]  R2257     2.9508890584111214e-02
    z[3,4,1]  R2258     2.8312578797340393e-01
    z[3,4,1]  R2259     5.6021219491958618e-01
    z[3,4,1]  R2260     7.8178036212921143e-01
    z[3,4,1]  R2261     7.5345677137374878e-01
    z[3,4,1]  R2262     3.8890364766120911e-01
    z[3,4,1]  R2263     4.9546009302139282e-01
    z[3,4,1]  R2264     1.8506301939487457e-01
    z[3,4,1]  R2265     1.7123848199844360e-01
    z[3,4,1]  R2266     3.8786649703979492e-02
    z[3,4,1]  R2267     -2.4267809092998505e-01
    z[3,4,1]  R2268     -2.5800105929374695e-01
    z[3,4,1]  R2269     -1.9565564393997192e-01
    z[3,4,1]  R2270     -1.5061859786510468e-01
    z[3,4,1]  R2271     -3.5446065664291382e-01
    z[3,4,1]  R2272     -3.8342043757438660e-01
    z[3,4,1]  R2273     -8.9201897382736206e-01
    z[3,4,1]  R2274     -7.1640813350677490e-01
    z[3,4,1]  R2275     -7.1327060461044312e-01
    z[3,4,1]  R2276     -4.8758310079574585e-01
    z[3,4,1]  R2277     -8.1594669818878174e-01
    z[3,4,1]  R2278     -6.2656390666961670e-01
    z[3,4,1]  R2279     1.0611204802989960e-01
    z[3,4,1]  R2280     -4.4901618361473083e-01
    z[3,4,1]  R2281     -7.4879795312881470e-01
    z[3,4,1]  R2282     -8.4246599674224854e-01
    z[3,4,1]  R2283     -7.3599445819854736e-01
    z[3,4,1]  R2284     -7.6748752593994141e-01
    z[3,4,1]  R2285     -8.7122011184692383e-01
    z[3,4,1]  R2286     -0.759326159954071
    z[3,4,1]  R2287     -8.7563234567642212e-01
    z[3,4,1]  R2288     -9.0224641561508179e-01
    z[3,4,1]  R2289     4.2711898684501648e-01
    z[3,4,1]  R2290     1.1950732767581940e-01
    z[3,4,1]  R2291     -7.9304671287536621e-01
    z[3,4,1]  R2292     -6.9904738664627075e-01
    z[3,4,1]  R2293     -8.7748444080352783e-01
    z[3,4,1]  R2294     -8.8935530185699463e-01
    z[3,4,1]  R2295     -7.5103670358657837e-01
    z[3,4,1]  R2296     -8.4581160545349121e-01
    z[3,4,1]  R2297     -1.1033361405134201e-01
    z[3,4,1]  R2298     -6.0323875397443771e-02
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R2159     -1
    z[3,4,2]  R2160     1
    z[3,4,2]  R2169     4.1041958332061768e-01
    z[3,4,2]  R2170     4.8243105411529541e-01
    z[3,4,2]  R2171     1.5083377063274384e-01
    z[3,4,2]  R2172     2.3986802995204926e-01
    z[3,4,2]  R2173     5.3352898359298706e-01
    z[3,4,2]  R2174     -1.8829308450222015e-01
    z[3,4,2]  R2175     -6.2303669750690460e-02
    z[3,4,2]  R2176     -6.2953778542578220e-03
    z[3,4,2]  R2177     -6.2106844037771225e-02
    z[3,4,2]  R2178     2.6103788614273071e-01
    z[3,4,2]  R2179     1.2965458631515503e-01
    z[3,4,2]  R2180     -4.6965414285659790e-01
    z[3,4,2]  R2181     2.0638918876647949e-01
    z[3,4,2]  R2182     1.6082639992237091e-01
    z[3,4,2]  R2183     -6.0505729913711548e-01
    z[3,4,2]  R2184     -7.0326203107833862e-01
    z[3,4,2]  R2185     -8.3815455436706543e-01
    z[3,4,2]  R2186     -6.1573606729507446e-01
    z[3,4,2]  R2187     4.2432656884193420e-01
    z[3,4,2]  R2188     -3.0441206693649292e-01
    z[3,4,2]  R2189     1.5811249613761902e-01
    z[3,4,2]  R2190     0.376202791929245
    z[3,4,2]  R2191     5.0575062632560730e-02
    z[3,4,2]  R2192     2.1942797303199768e-01
    z[3,4,2]  R2193     -4.8627737164497375e-01
    z[3,4,2]  R2194     -3.4369108080863953e-01
    z[3,4,2]  R2195     1.2670375406742096e-01
    z[3,4,2]  R2196     -2.3087514936923981e-01
    z[3,4,2]  R2197     -4.0249493718147278e-01
    z[3,4,2]  R2198     7.9355299472808838e-01
    z[3,4,2]  R2199     -6.2529988586902618e-02
    z[3,4,2]  R2200     -2.4667935073375702e-01
    z[3,4,2]  R2201     -2.9975825548171997e-01
    z[3,4,2]  R2202     -1.9519220292568207e-01
    z[3,4,2]  R2203     -3.2596173882484436e-01
    z[3,4,2]  R2204     5.3519034385681152e-01
    z[3,4,2]  R2205     4.2127409577369690e-01
    z[3,4,2]  R2206     1.2512315809726715e-01
    z[3,4,2]  R2207     3.2611471414566040e-01
    z[3,4,2]  R2208     2.5055831670761108e-01
    z[3,4,2]  R2209     3.1556525826454163e-01
    z[3,4,2]  R2210     -2.1326968073844910e-01
    z[3,4,2]  R2211     -2.4498504400253296e-01
    z[3,4,2]  R2212     9.8096147179603577e-02
    z[3,4,2]  R2213     5.0670439004898071e-01
    z[3,4,2]  R2214     5.9198117256164551e-01
    z[3,4,2]  R2215     -4.0576282143592834e-01
    z[3,4,2]  R2216     -4.5886853337287903e-01
    z[3,4,2]  R2217     -4.3549299240112305e-01
    z[3,4,2]  R2218     -7.1385937929153442e-01
    z[3,4,2]  R2219     -1.5301067614927888e-03
    z[3,4,2]  R2220     -4.0854278206825256e-01
    z[3,4,2]  R2221     2.4864038452506065e-02
    z[3,4,2]  R2222     3.0922656878829002e-02
    z[3,4,2]  R2223     -0.0631827712059021
    z[3,4,2]  R2224     6.1961793899536133e-01
    z[3,4,2]  R2225     -4.2903009057044983e-01
    z[3,4,2]  R2226     1.7989465594291687e-01
    z[3,4,2]  R2227     3.3121243119239807e-01
    z[3,4,2]  R2228     2.1600204706192017e-01
    z[3,4,2]  R2229     6.9001567363739014e-01
    z[3,4,2]  R2230     -2.2462388500571251e-02
    z[3,4,2]  R2231     7.2278487682342529e-01
    z[3,4,2]  R2232     -2.3946358263492584e-01
    z[3,4,2]  R2233     -5.9312063455581665e-01
    z[3,4,2]  R2234     7.0781731605529785e-01
    z[3,4,2]  R2235     1.1221123486757278e-01
    z[3,4,2]  R2236     1.1881493777036667e-01
    z[3,4,2]  R2237     2.9405781626701355e-01
    z[3,4,2]  R2238     -1.0706714354455471e-02
    z[3,4,2]  R2239     2.5668564438819885e-01
    z[3,4,2]  R2240     -3.7382226437330246e-02
    z[3,4,2]  R2241     6.8933749198913574e-01
    z[3,4,2]  R2242     -3.1472650170326233e-01
    z[3,4,2]  R2243     -3.4611481428146362e-01
    z[3,4,2]  R2244     7.3608571290969849e-01
    z[3,4,2]  R2245     3.4660151600837708e-01
    z[3,4,2]  R2246     3.5235700011253357e-01
    z[3,4,2]  R2247     -3.8247801363468170e-02
    z[3,4,2]  R2248     -1.2653575837612152e-01
    z[3,4,2]  R2249     4.0381708741188049e-01
    z[3,4,2]  R2250     6.5360546112060547e-01
    z[3,4,2]  R2251     5.5261862277984619e-01
    z[3,4,2]  R2252     8.4787815809249878e-01
    z[3,4,2]  R2253     1.0278853029012680e-01
    z[3,4,2]  R2254     -1.9657596945762634e-01
    z[3,4,2]  R2255     -1.7647102475166321e-01
    z[3,4,2]  R2256     4.9150779843330383e-01
    z[3,4,2]  R2257     3.6729894578456879e-02
    z[3,4,2]  R2258     -1.0624358803033829e-01
    z[3,4,2]  R2259     -3.8512402772903442e-01
    z[3,4,2]  R2260     5.6504216045141220e-02
    z[3,4,2]  R2261     -3.9413750171661377e-01
    z[3,4,2]  R2262     1.1042091995477676e-01
    z[3,4,2]  R2263     1.2807871401309967e-01
    z[3,4,2]  R2264     1.2600994668900967e-02
    z[3,4,2]  R2265     1.0695854574441910e-01
    z[3,4,2]  R2266     3.7434976547956467e-02
    z[3,4,2]  R2267     1.3555747270584106e-01
    z[3,4,2]  R2268     -0.0625605583190918
    z[3,4,2]  R2269     0.49066162109375
    z[3,4,2]  R2270     3.7475490570068359e-01
    z[3,4,2]  R2271     -1.8631502985954285e-01
    z[3,4,2]  R2272     -5.3598236292600632e-02
    z[3,4,2]  R2273     -9.7490988671779633e-02
    z[3,4,2]  R2274     -5.3910166025161743e-01
    z[3,4,2]  R2275     -1.0701456665992737e-01
    z[3,4,2]  R2276     -3.9065742492675781e-01
    z[3,4,2]  R2277     -7.0837214589118958e-02
    z[3,4,2]  R2278     -4.8441314697265625e-01
    z[3,4,2]  R2279     -1.2420298904180527e-01
    z[3,4,2]  R2280     -3.6703076958656311e-01
    z[3,4,2]  R2281     -8.0870762467384338e-02
    z[3,4,2]  R2282     -1.6054618358612061e-01
    z[3,4,2]  R2283     -1.4383193850517273e-01
    z[3,4,2]  R2284     -2.4992391467094421e-01
    z[3,4,2]  R2285     -8.3724528551101685e-02
    z[3,4,2]  R2286     3.0607774853706360e-01
    z[3,4,2]  R2287     3.2696709036827087e-01
    z[3,4,2]  R2288     2.2576428949832916e-01
    z[3,4,2]  R2289     -3.0090728402137756e-01
    z[3,4,2]  R2290     -2.3227781057357788e-01
    z[3,4,2]  R2291     -1.1948853731155396e-01
    z[3,4,2]  R2292     -1.9092109799385071e-01
    z[3,4,2]  R2293     3.3038997650146484e-01
    z[3,4,2]  R2294     1.7247335612773895e-01
    z[3,4,2]  R2295     -6.6403280943632126e-03
    z[3,4,2]  R2296     3.6510783433914185e-01
    z[3,4,2]  R2297     -7.7136582136154175e-01
    z[3,4,2]  R2298     -0.623135507106781
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R2161     -1
    z[3,4,3]  R2162     1
    z[3,4,3]  R2169     -2.7057039737701416e-01
    z[3,4,3]  R2170     2.2242200374603271e-01
    z[3,4,3]  R2171     -4.8630633950233459e-01
    z[3,4,3]  R2172     -9.0782207250595093e-01
    z[3,4,3]  R2173     -6.0245823860168457e-01
    z[3,4,3]  R2174     -7.7078616619110107e-01
    z[3,4,3]  R2175     -5.7151901721954346e-01
    z[3,4,3]  R2176     -4.4974225759506226e-01
    z[3,4,3]  R2177     -3.3146941661834717e-01
    z[3,4,3]  R2178     -3.7510424852371216e-01
    z[3,4,3]  R2179     3.1618601083755493e-01
    z[3,4,3]  R2180     -1.8194037675857544e-01
    z[3,4,3]  R2181     3.8946425914764404e-01
    z[3,4,3]  R2182     0.081110879778862
    z[3,4,3]  R2183     1.6585490107536316e-01
    z[3,4,3]  R2184     3.3532249927520752e-01
    z[3,4,3]  R2185     2.4041488766670227e-01
    z[3,4,3]  R2186     5.9478312730789185e-01
    z[3,4,3]  R2187     3.0572825670242310e-01
    z[3,4,3]  R2188     -9.2390157282352448e-02
    z[3,4,3]  R2189     -7.5568921864032745e-02
    z[3,4,3]  R2190     -9.7693480551242828e-02
    z[3,4,3]  R2191     -1.7162151634693146e-01
    z[3,4,3]  R2192     -1.2340348213911057e-01
    z[3,4,3]  R2193     -3.6988846957683563e-02
    z[3,4,3]  R2194     -2.4959733709692955e-02
    z[3,4,3]  R2195     -5.6879818439483643e-03
    z[3,4,3]  R2196     4.3359389901161194e-01
    z[3,4,3]  R2197     -1.2845497578382492e-02
    z[3,4,3]  R2198     -1.7646154761314392e-01
    z[3,4,3]  R2199     -4.5771875977516174e-01
    z[3,4,3]  R2200     -4.7059425711631775e-01
    z[3,4,3]  R2201     2.9010131955146790e-01
    z[3,4,3]  R2202     -1.5414546430110931e-01
    z[3,4,3]  R2203     2.8731770813465118e-02
    z[3,4,3]  R2204     5.1945778541266918e-03
    z[3,4,3]  R2205     -0.0582304522395134
    z[3,4,3]  R2206     -2.7886587381362915e-01
    z[3,4,3]  R2207     1.9689889624714851e-02
    z[3,4,3]  R2208     -1.2389860302209854e-01
    z[3,4,3]  R2209     2.3909914493560791e-01
    z[3,4,3]  R2210     -8.3357393741607666e-01
    z[3,4,3]  R2211     -5.2888363599777222e-01
    z[3,4,3]  R2212     -6.7985409498214722e-01
    z[3,4,3]  R2213     6.0640448331832886e-01
    z[3,4,3]  R2214     5.7174468040466309e-01
    z[3,4,3]  R2215     -7.3191873729228973e-02
    z[3,4,3]  R2216     2.1180571615695953e-01
    z[3,4,3]  R2217     -2.2566859424114227e-01
    z[3,4,3]  R2218     -1.3528390228748322e-01
    z[3,4,3]  R2219     -3.4971076250076294e-01
    z[3,4,3]  R2220     -1.2376046925783157e-01
    z[3,4,3]  R2221     -1.3576015830039978e-02
    z[3,4,3]  R2222     -6.5821069478988647e-01
    z[3,4,3]  R2223     -3.2483169436454773e-01
    z[3,4,3]  R2224     -4.0063586831092834e-01
    z[3,4,3]  R2225     3.1285667419433594e-01
    z[3,4,3]  R2226     1.3730789721012115e-01
    z[3,4,3]  R2227     -1.4332598447799683e-01
    z[3,4,3]  R2228     3.1519293785095215e-01
    z[3,4,3]  R2229     -9.5184780657291412e-02
    z[3,4,3]  R2230     2.4369803071022034e-01
    z[3,4,3]  R2231     0.348730206489563
    z[3,4,3]  R2232     0.451188862323761
    z[3,4,3]  R2233     3.3942395448684692e-01
    z[3,4,3]  R2234     -6.7075587809085846e-02
    z[3,4,3]  R2235     1.8302203714847565e-01
    z[3,4,3]  R2236     1.1391800642013550e-01
    z[3,4,3]  R2237     1.4862108230590820e-01
    z[3,4,3]  R2238     -3.2110220193862915e-01
    z[3,4,3]  R2239     4.3260562419891357e-01
    z[3,4,3]  R2240     -6.7774200439453125e-01
    z[3,4,3]  R2241     -4.0927335619926453e-01
    z[3,4,3]  R2242     -1.3049960136413574e-02
    z[3,4,3]  R2243     -0.502071738243103
    z[3,4,3]  R2244     -9.1563336551189423e-02
    z[3,4,3]  R2245     -1.4747790992259979e-01
    z[3,4,3]  R2246     -7.6781474053859711e-02
    z[3,4,3]  R2247     1.6723388433456421e-01
    z[3,4,3]  R2248     1.7311847209930420e-01
    z[3,4,3]  R2249     -7.0427286624908447e-01
    z[3,4,3]  R2250     5.3233772516250610e-01
    z[3,4,3]  R2251     4.6594947576522827e-01
    z[3,4,3]  R2252     -3.8813658058643341e-02
    z[3,4,3]  R2253     -2.1370275318622589e-01
    z[3,4,3]  R2254     2.2169852256774902e-01
    z[3,4,3]  R2255     1.7748758196830750e-02
    z[3,4,3]  R2256     2.0500671863555908e-01
    z[3,4,3]  R2257     -8.5821323096752167e-02
    z[3,4,3]  R2258     1.5121363103389740e-01
    z[3,4,3]  R2259     -3.8021820783615112e-01
    z[3,4,3]  R2260     -4.8384204506874084e-01
    z[3,4,3]  R2261     -3.6220863461494446e-01
    z[3,4,3]  R2262     -4.1754421591758728e-01
    z[3,4,3]  R2263     -2.9438000917434692e-01
    z[3,4,3]  R2264     -3.1255516409873962e-01
    z[3,4,3]  R2265     6.8910324573516846e-01
    z[3,4,3]  R2266     -3.0642330646514893e-01
    z[3,4,3]  R2267     -0.398311972618103
    z[3,4,3]  R2268     -2.8055045008659363e-01
    z[3,4,3]  R2269     2.8187143802642822e-01
    z[3,4,3]  R2270     4.5860681682825089e-02
    z[3,4,3]  R2271     -2.4828857183456421e-01
    z[3,4,3]  R2272     -1.3207701034843922e-02
    z[3,4,3]  R2273     -8.9316688477993011e-02
    z[3,4,3]  R2274     -2.1141889691352844e-01
    z[3,4,3]  R2275     9.3292370438575745e-02
    z[3,4,3]  R2276     -3.2621735334396362e-01
    z[3,4,3]  R2277     -1.0185866057872772e-01
    z[3,4,3]  R2278     -3.8146099448204041e-01
    z[3,4,3]  R2279     3.0751854181289673e-01
    z[3,4,3]  R2280     -6.9934684038162231e-01
    z[3,4,3]  R2281     -3.2809826731681824e-01
    z[3,4,3]  R2282     -3.1848379969596863e-01
    z[3,4,3]  R2283     -3.9895847439765930e-01
    z[3,4,3]  R2284     -3.7319111824035645e-01
    z[3,4,3]  R2285     3.6862384527921677e-02
    z[3,4,3]  R2286     8.2869239151477814e-02
    z[3,4,3]  R2287     2.8244696557521820e-02
    z[3,4,3]  R2288     -5.6988544762134552e-02
    z[3,4,3]  R2289     4.1068476438522339e-01
    z[3,4,3]  R2290     3.7810587882995605e-01
    z[3,4,3]  R2291     -3.4058916568756104e-01
    z[3,4,3]  R2292     -5.4312676191329956e-01
    z[3,4,3]  R2293     -9.5807880163192749e-02
    z[3,4,3]  R2294     2.8587602078914642e-02
    z[3,4,3]  R2295     -3.5784307122230530e-01
    z[3,4,3]  R2296     2.3451048135757446e-01
    z[3,4,3]  R2297     4.9130004644393921e-01
    z[3,4,3]  R2298     4.0348741412162781e-01
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R2163     -1
    z[3,4,4]  R2164     1
    z[3,4,4]  R2169     -4.2647701501846313e-01
    z[3,4,4]  R2170     6.4936959743499756e-01
    z[3,4,4]  R2171     2.0659589767456055e-01
    z[3,4,4]  R2172     1.2071436643600464e-01
    z[3,4,4]  R2173     -2.6310819387435913e-01
    z[3,4,4]  R2174     -2.7697184681892395e-01
    z[3,4,4]  R2175     -6.3517436385154724e-02
    z[3,4,4]  R2176     1.3910956680774689e-01
    z[3,4,4]  R2177     -1.1195933073759079e-01
    z[3,4,4]  R2178     0.00340811675414443
    z[3,4,4]  R2179     2.2796740755438805e-02
    z[3,4,4]  R2180     2.9402857646346092e-02
    z[3,4,4]  R2181     -2.3719245195388794e-01
    z[3,4,4]  R2182     3.0050572752952576e-01
    z[3,4,4]  R2183     2.9327198863029480e-01
    z[3,4,4]  R2184     1.3792613148689270e-01
    z[3,4,4]  R2185     2.5427341461181641e-02
    z[3,4,4]  R2186     0.118742436170578
    z[3,4,4]  R2187     -3.8816636800765991e-01
    z[3,4,4]  R2188     -1.4444314874708652e-02
    z[3,4,4]  R2189     2.9218655824661255e-01
    z[3,4,4]  R2190     1.4821581542491913e-01
    z[3,4,4]  R2191     2.9983353614807129e-01
    z[3,4,4]  R2192     -1.4140526950359344e-01
    z[3,4,4]  R2193     -7.0724025368690491e-02
    z[3,4,4]  R2194     8.9530251920223236e-02
    z[3,4,4]  R2195     -2.9376211762428284e-01
    z[3,4,4]  R2196     -6.6264927387237549e-02
    z[3,4,4]  R2197     -4.9960368871688843e-01
    z[3,4,4]  R2198     4.7424253076314926e-02
    z[3,4,4]  R2199     -5.2696573734283447e-01
    z[3,4,4]  R2200     0.225468710064888
    z[3,4,4]  R2201     5.3126358985900879e-01
    z[3,4,4]  R2202     -0.645107090473175
    z[3,4,4]  R2203     -5.7966804504394531e-01
    z[3,4,4]  R2204     -5.1796585321426392e-01
    z[3,4,4]  R2205     -2.2337383031845093e-01
    z[3,4,4]  R2206     1.0597323998808861e-02
    z[3,4,4]  R2207     -3.5800719261169434e-01
    z[3,4,4]  R2208     -3.9284643530845642e-01
    z[3,4,4]  R2209     -5.3778970241546631e-01
    z[3,4,4]  R2210     1.9459785521030426e-01
    z[3,4,4]  R2211     1.0053319483995438e-01
    z[3,4,4]  R2212     -2.2989268600940704e-01
    z[3,4,4]  R2213     -2.9182881116867065e-01
    z[3,4,4]  R2214     -2.7246505022048950e-01
    z[3,4,4]  R2215     -4.6303052455186844e-02
    z[3,4,4]  R2216     -5.5385154485702515e-01
    z[3,4,4]  R2217     -3.7276622653007507e-01
    z[3,4,4]  R2218     -0.343077689409256
    z[3,4,4]  R2219     4.8305603861808777e-01
    z[3,4,4]  R2220     -1.0203192383050919e-01
    z[3,4,4]  R2221     -0.0925784781575203
    z[3,4,4]  R2222     -1.8663829565048218e-01
    z[3,4,4]  R2223     8.7267801165580750e-02
    z[3,4,4]  R2224     -2.6311576366424561e-01
    z[3,4,4]  R2225     1.6780454665422440e-02
    z[3,4,4]  R2226     2.5766485929489136e-01
    z[3,4,4]  R2227     7.5200520455837250e-02
    z[3,4,4]  R2228     4.6823222190141678e-02
    z[3,4,4]  R2229     5.6598985195159912e-01
    z[3,4,4]  R2230     -3.5769158601760864e-01
    z[3,4,4]  R2231     1.4069169759750366e-01
    z[3,4,4]  R2232     0.452584832906723
    z[3,4,4]  R2233     1.6116510331630707e-01
    z[3,4,4]  R2234     -3.5327225923538208e-01
    z[3,4,4]  R2235     3.8043644279241562e-02
    z[3,4,4]  R2236     -1.6989172995090485e-01
    z[3,4,4]  R2237     -1.8061298131942749e-01
    z[3,4,4]  R2238     -3.0069085955619812e-01
    z[3,4,4]  R2239     2.5757661461830139e-01
    z[3,4,4]  R2240     -3.4258410334587097e-01
    z[3,4,4]  R2241     0.00994244497269392
    z[3,4,4]  R2242     -1.0714717209339142e-01
    z[3,4,4]  R2243     1.4907805621623993e-01
    z[3,4,4]  R2244     4.5438849925994873e-01
    z[3,4,4]  R2245     8.5485167801380157e-02
    z[3,4,4]  R2246     -1.6078485175967216e-02
    z[3,4,4]  R2247     -4.3499547243118286e-01
    z[3,4,4]  R2248     -2.1023973822593689e-01
    z[3,4,4]  R2249     7.9031303524971008e-02
    z[3,4,4]  R2250     1.9675374031066895e-01
    z[3,4,4]  R2251     -2.6867267489433289e-01
    z[3,4,4]  R2252     1.1945463716983795e-02
    z[3,4,4]  R2253     -4.1314724087715149e-01
    z[3,4,4]  R2254     2.9950621537864208e-03
    z[3,4,4]  R2255     -9.5723450183868408e-02
    z[3,4,4]  R2256     -1.4593677222728729e-01
    z[3,4,4]  R2257     -2.2758300602436066e-01
    z[3,4,4]  R2258     -2.9370945692062378e-01
    z[3,4,4]  R2259     -1.8614172935485840e-01
    z[3,4,4]  R2260     2.1207168698310852e-01
    z[3,4,4]  R2261     1.3169211149215698e-01
    z[3,4,4]  R2262     -5.8622401952743530e-01
    z[3,4,4]  R2263     -7.0075875520706177e-01
    z[3,4,4]  R2264     2.7352645993232727e-02
    z[3,4,4]  R2265     4.4997197389602661e-01
    z[3,4,4]  R2266     -1.1206955462694168e-01
    z[3,4,4]  R2267     -3.5753118991851807e-01
    z[3,4,4]  R2268     3.3977007865905762e-01
    z[3,4,4]  R2269     5.3274929523468018e-02
    z[3,4,4]  R2270     4.2905649542808533e-01
    z[3,4,4]  R2271     3.0451324582099915e-01
    z[3,4,4]  R2272     6.3623654842376709e-01
    z[3,4,4]  R2273     -3.5619032382965088e-01
    z[3,4,4]  R2274     -7.8622095286846161e-02
    z[3,4,4]  R2275     -1.7840167507529259e-02
    z[3,4,4]  R2276     -8.1945598125457764e-02
    z[3,4,4]  R2277     -6.9304317235946655e-02
    z[3,4,4]  R2278     -0.0410560667514801
    z[3,4,4]  R2279     -3.1161725521087646e-01
    z[3,4,4]  R2280     1.3672819733619690e-01
    z[3,4,4]  R2281     -3.2310044765472412e-01
    z[3,4,4]  R2282     8.5804097354412079e-02
    z[3,4,4]  R2283     -1.7356221377849579e-01
    z[3,4,4]  R2284     -7.4332311749458313e-02
    z[3,4,4]  R2285     -3.4329265356063843e-02
    z[3,4,4]  R2286     -3.0796703696250916e-01
    z[3,4,4]  R2287     2.1189035475254059e-01
    z[3,4,4]  R2288     5.9805028140544891e-02
    z[3,4,4]  R2289     1.9889065623283386e-01
    z[3,4,4]  R2290     -2.7678728103637695e-01
    z[3,4,4]  R2291     3.1266503036022186e-02
    z[3,4,4]  R2292     -3.5277768969535828e-01
    z[3,4,4]  R2293     -5.2817653864622116e-02
    z[3,4,4]  R2294     -1.7005857825279236e-01
    z[3,4,4]  R2295     -3.9837956428527832e-01
    z[3,4,4]  R2296     -2.1901425719261169e-01
    z[3,4,4]  R2297     -4.2809482663869858e-02
    z[3,4,4]  R2298     -4.0744204074144363e-02
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R2165     -1
    z[3,4,5]  R2166     1
    z[3,4,5]  R2169     -4.3386217951774597e-01
    z[3,4,5]  R2170     -2.1251513063907623e-01
    z[3,4,5]  R2171     -5.0445652008056641e-01
    z[3,4,5]  R2172     -7.6856710016727448e-02
    z[3,4,5]  R2173     -1.6088853776454926e-01
    z[3,4,5]  R2174     2.5028528645634651e-02
    z[3,4,5]  R2175     0.348357617855072
    z[3,4,5]  R2176     -3.7620836496353149e-01
    z[3,4,5]  R2177     -3.0073845386505127e-01
    z[3,4,5]  R2178     -1.9433495402336121e-01
    z[3,4,5]  R2179     3.8035976886749268e-01
    z[3,4,5]  R2180     -4.6719394624233246e-02
    z[3,4,5]  R2181     6.0069918632507324e-01
    z[3,4,5]  R2182     1.8863563239574432e-01
    z[3,4,5]  R2183     4.0948572754859924e-01
    z[3,4,5]  R2184     1.7991185188293457e-01
    z[3,4,5]  R2185     0.0920541062951088
    z[3,4,5]  R2186     1.2588837742805481e-01
    z[3,4,5]  R2187     4.7277545928955078e-01
    z[3,4,5]  R2188     5.9156739711761475e-01
    z[3,4,5]  R2189     -2.3151063919067383e-01
    z[3,4,5]  R2190     0.457425594329834
    z[3,4,5]  R2191     2.0204125344753265e-01
    z[3,4,5]  R2192     0.598791241645813
    z[3,4,5]  R2193     -2.3754674196243286e-01
    z[3,4,5]  R2194     4.9399951100349426e-01
    z[3,4,5]  R2195     3.6819356679916382e-01
    z[3,4,5]  R2196     2.2365932166576385e-01
    z[3,4,5]  R2197     1.4212416112422943e-01
    z[3,4,5]  R2198     -6.7222595214843750e-02
    z[3,4,5]  R2199     -2.0196711644530296e-02
    z[3,4,5]  R2200     -4.8286926001310349e-02
    z[3,4,5]  R2201     -1.3389208912849426e-01
    z[3,4,5]  R2202     2.1183808147907257e-01
    z[3,4,5]  R2203     8.8243380188941956e-02
    z[3,4,5]  R2204     1.2243386358022690e-01
    z[3,4,5]  R2205     2.9019605368375778e-02
    z[3,4,5]  R2206     1.3056750595569611e-01
    z[3,4,5]  R2207     -1.7010171711444855e-01
    z[3,4,5]  R2208     -3.9907835423946381e-02
    z[3,4,5]  R2209     1.8827447667717934e-02
    z[3,4,5]  R2210     -1.8242919445037842e-01
    z[3,4,5]  R2211     -4.0729236602783203e-01
    z[3,4,5]  R2212     1.6880555450916290e-01
    z[3,4,5]  R2213     -4.3299937248229980e-01
    z[3,4,5]  R2214     -3.3952260017395020e-01
    z[3,4,5]  R2215     3.7518686056137085e-01
    z[3,4,5]  R2216     -1.9954627752304077e-01
    z[3,4,5]  R2217     -3.0268070101737976e-01
    z[3,4,5]  R2218     2.9153221845626831e-01
    z[3,4,5]  R2219     1.7578034102916718e-01
    z[3,4,5]  R2220     1.4103178679943085e-01
    z[3,4,5]  R2221     -4.5463374257087708e-01
    z[3,4,5]  R2222     5.9324383735656738e-02
    z[3,4,5]  R2223     -1.2676222622394562e-01
    z[3,4,5]  R2224     5.3338032215833664e-02
    z[3,4,5]  R2225     -8.9633306488394737e-03
    z[3,4,5]  R2226     4.0861195325851440e-01
    z[3,4,5]  R2227     -7.8010559082031250e-02
    z[3,4,5]  R2228     -2.3163343966007233e-01
    z[3,4,5]  R2229     0.273774117231369
    z[3,4,5]  R2230     -5.2762970328330994e-02
    z[3,4,5]  R2231     2.3675620555877686e-01
    z[3,4,5]  R2232     2.2943376004695892e-01
    z[3,4,5]  R2233     7.5764514505863190e-02
    z[3,4,5]  R2234     1.8387521803379059e-01
    z[3,4,5]  R2235     -2.7558884024620056e-01
    z[3,4,5]  R2236     5.9021270275115967e-01
    z[3,4,5]  R2237     2.2301357984542847e-01
    z[3,4,5]  R2238     -7.0829652249813080e-02
    z[3,4,5]  R2239     1.4459949731826782e-01
    z[3,4,5]  R2240     1.5825821086764336e-02
    z[3,4,5]  R2241     3.1916475296020508e-01
    z[3,4,5]  R2242     4.4475227594375610e-01
    z[3,4,5]  R2243     -4.2168667912483215e-01
    z[3,4,5]  R2244     -2.6205161213874817e-01
    z[3,4,5]  R2245     1.1747315526008606e-02
    z[3,4,5]  R2246     -3.8046085834503174e-01
    z[3,4,5]  R2247     -3.9427403360605240e-02
    z[3,4,5]  R2248     2.6306691765785217e-01
    z[3,4,5]  R2249     -1.9467723369598389e-01
    z[3,4,5]  R2250     2.1556799113750458e-01
    z[3,4,5]  R2251     -2.4909430742263794e-01
    z[3,4,5]  R2252     -3.0473336577415466e-01
    z[3,4,5]  R2253     4.8819732666015625e-01
    z[3,4,5]  R2254     -2.2189967334270477e-01
    z[3,4,5]  R2255     -6.8342939019203186e-02
    z[3,4,5]  R2256     3.0620506405830383e-01
    z[3,4,5]  R2257     1.1011601239442825e-01
    z[3,4,5]  R2258     -2.7557021379470825e-01
    z[3,4,5]  R2259     4.5455317944288254e-02
    z[3,4,5]  R2260     3.0921491980552673e-01
    z[3,4,5]  R2261     -2.7463287115097046e-01
    z[3,4,5]  R2262     2.4353665113449097e-01
    z[3,4,5]  R2263     -3.5344031453132629e-01
    z[3,4,5]  R2264     -8.5938408970832825e-02
    z[3,4,5]  R2265     3.4604495763778687e-01
    z[3,4,5]  R2266     -3.2464957237243652e-01
    z[3,4,5]  R2267     -2.0818535983562469e-01
    z[3,4,5]  R2268     -0.0650099441409111
    z[3,4,5]  R2269     -1.1607811599969864e-01
    z[3,4,5]  R2270     -2.1920476853847504e-01
    z[3,4,5]  R2271     0.0813726931810379
    z[3,4,5]  R2272     1.1889610439538956e-02
    z[3,4,5]  R2273     -1.5509258210659027e-01
    z[3,4,5]  R2274     3.3704373240470886e-01
    z[3,4,5]  R2275     -2.8847804665565491e-01
    z[3,4,5]  R2276     -5.0170928239822388e-01
    z[3,4,5]  R2277     -2.4494219571352005e-02
    z[3,4,5]  R2278     2.9188964515924454e-02
    z[3,4,5]  R2279     5.8514147996902466e-01
    z[3,4,5]  R2280     -2.4900746345520020e-01
    z[3,4,5]  R2281     -4.3281638622283936e-01
    z[3,4,5]  R2282     -1.5920111536979675e-01
    z[3,4,5]  R2283     -3.0305919051170349e-01
    z[3,4,5]  R2284     1.8946048617362976e-01
    z[3,4,5]  R2285     9.4566307961940765e-02
    z[3,4,5]  R2286     -2.8468701243400574e-01
    z[3,4,5]  R2287     1.9625541567802429e-01
    z[3,4,5]  R2288     2.4141949415206909e-01
    z[3,4,5]  R2289     6.0804599523544312e-01
    z[3,4,5]  R2290     4.3281927704811096e-02
    z[3,4,5]  R2291     -3.9834147691726685e-01
    z[3,4,5]  R2292     2.0585153996944427e-01
    z[3,4,5]  R2293     -0.155070960521698
    z[3,4,5]  R2294     2.3658762872219086e-01
    z[3,4,5]  R2295     1.8496681749820709e-01
    z[3,4,5]  R2296     -0.0867081880569458
    z[3,4,5]  R2297     -2.5477465987205505e-01
    z[3,4,5]  R2298     -1.9850549101829529e-01
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R2167     -1
    z[3,4,6]  R2168     1
    z[3,4,6]  R2169     3.2224437594413757e-01
    z[3,4,6]  R2170     3.2228657603263855e-01
    z[3,4,6]  R2171     1.8866769969463348e-01
    z[3,4,6]  R2172     -4.9333442002534866e-02
    z[3,4,6]  R2173     -0.0901155099272728
    z[3,4,6]  R2174     0.395723819732666
    z[3,4,6]  R2175     -5.4834973812103271e-01
    z[3,4,6]  R2176     8.3916939795017242e-02
    z[3,4,6]  R2177     1.7447138205170631e-02
    z[3,4,6]  R2178     -7.4526853859424591e-02
    z[3,4,6]  R2179     -6.3740599155426025e-01
    z[3,4,6]  R2180     0.441743403673172
    z[3,4,6]  R2181     -4.3122348189353943e-01
    z[3,4,6]  R2182     -1.4081505127251148e-02
    z[3,4,6]  R2183     -1.4989298582077026e-01
    z[3,4,6]  R2184     3.9437824487686157e-01
    z[3,4,6]  R2185     3.5007354617118835e-01
    z[3,4,6]  R2186     2.1143538877367973e-02
    z[3,4,6]  R2187     1.4839254319667816e-02
    z[3,4,6]  R2188     2.5452831387519836e-01
    z[3,4,6]  R2189     -1.6930031776428223e-01
    z[3,4,6]  R2190     -4.4117712974548340e-01
    z[3,4,6]  R2191     4.8542764782905579e-01
    z[3,4,6]  R2192     1.9095657765865326e-01
    z[3,4,6]  R2193     -2.2461685538291931e-01
    z[3,4,6]  R2194     -7.7713549137115479e-02
    z[3,4,6]  R2195     4.4267535209655762e-01
    z[3,4,6]  R2196     1.3879722356796265e-01
    z[3,4,6]  R2197     -1.3862450420856476e-01
    z[3,4,6]  R2198     -1.2953819334506989e-01
    z[3,4,6]  R2199     2.0793128013610840e-01
    z[3,4,6]  R2200     5.6596368551254272e-02
    z[3,4,6]  R2201     6.0966953635215759e-02
    z[3,4,6]  R2202     -4.5595744252204895e-01
    z[3,4,6]  R2203     -4.7271448373794556e-01
    z[3,4,6]  R2204     3.4640945494174957e-02
    z[3,4,6]  R2205     1.9651544094085693e-01
    z[3,4,6]  R2206     2.3814779520034790e-01
    z[3,4,6]  R2207     -3.2557934522628784e-01
    z[3,4,6]  R2208     -4.1531622409820557e-02
    z[3,4,6]  R2209     -1.8709658086299896e-01
    z[3,4,6]  R2210     1.7484484612941742e-01
    z[3,4,6]  R2211     3.7786448001861572e-01
    z[3,4,6]  R2212     -3.1138148903846741e-01
    z[3,4,6]  R2213     -1.9536325708031654e-03
    z[3,4,6]  R2214     -3.1438705325126648e-01
    z[3,4,6]  R2215     4.4407594203948975e-01
    z[3,4,6]  R2216     0.00967728067189455
    z[3,4,6]  R2217     2.8715759515762329e-01
    z[3,4,6]  R2218     -1.4299340546131134e-01
    z[3,4,6]  R2219     -2.4260684847831726e-02
    z[3,4,6]  R2220     4.2003687471151352e-02
    z[3,4,6]  R2221     2.5526729226112366e-01
    z[3,4,6]  R2222     4.4603681564331055e-01
    z[3,4,6]  R2223     3.3880195021629333e-01
    z[3,4,6]  R2224     -3.7438246607780457e-01
    z[3,4,6]  R2225     -4.9122944474220276e-01
    z[3,4,6]  R2226     5.3314030170440674e-01
    z[3,4,6]  R2227     -3.0161604285240173e-01
    z[3,4,6]  R2228     1.4251299202442169e-01
    z[3,4,6]  R2229     -9.3784462660551071e-03
    z[3,4,6]  R2230     -1.4829332008957863e-02
    z[3,4,6]  R2231     -4.6136882901191711e-01
    z[3,4,6]  R2232     -1.3811211287975311e-01
    z[3,4,6]  R2233     1.1487468332052231e-01
    z[3,4,6]  R2234     1.3688622973859310e-02
    z[3,4,6]  R2235     -5.4443454742431641e-01
    z[3,4,6]  R2236     2.2189514338970184e-01
    z[3,4,6]  R2237     -2.5713866949081421e-01
    z[3,4,6]  R2238     1.9530370831489563e-02
    z[3,4,6]  R2239     3.9185574650764465e-01
    z[3,4,6]  R2240     -5.6224983185529709e-02
    z[3,4,6]  R2241     -2.7617835998535156e-01
    z[3,4,6]  R2242     -1.0886877775192261e-01
    z[3,4,6]  R2243     1.6325150430202484e-01
    z[3,4,6]  R2244     -3.6671221256256104e-01
    z[3,4,6]  R2245     1.9295718520879745e-02
    z[3,4,6]  R2246     0.280496209859848
    z[3,4,6]  R2247     3.5179728269577026e-01
    z[3,4,6]  R2248     3.4558865427970886e-01
    z[3,4,6]  R2249     1.1742081493139267e-01
    z[3,4,6]  R2250     -2.6539623737335205e-01
    z[3,4,6]  R2251     2.7670052647590637e-01
    z[3,4,6]  R2252     3.8323320448398590e-02
    z[3,4,6]  R2253     6.8560346961021423e-02
    z[3,4,6]  R2254     -2.5408580899238586e-01
    z[3,4,6]  R2255     -4.8990118503570557e-01
    z[3,4,6]  R2256     2.3935526609420776e-01
    z[3,4,6]  R2257     -6.3910400867462158e-01
    z[3,4,6]  R2258     1.3189865648746490e-01
    z[3,4,6]  R2259     -0.210738867521286
    z[3,4,6]  R2260     -3.1171094626188278e-02
    z[3,4,6]  R2261     2.2929438948631287e-01
    z[3,4,6]  R2262     5.0909918546676636e-01
    z[3,4,6]  R2263     1.2369374930858612e-01
    z[3,4,6]  R2264     -7.8863966464996338e-01
    z[3,4,6]  R2265     -3.7255835533142090e-01
    z[3,4,6]  R2266     -0.0744401067495346
    z[3,4,6]  R2267     -1.5316693484783173e-01
    z[3,4,6]  R2268     -3.9936131797730923e-03
    z[3,4,6]  R2269     3.4250393509864807e-01
    z[3,4,6]  R2270     6.0241949558258057e-01
    z[3,4,6]  R2271     4.5875120162963867e-01
    z[3,4,6]  R2272     3.3511921763420105e-01
    z[3,4,6]  R2273     1.8250516057014465e-01
    z[3,4,6]  R2274     -1.4824721217155457e-01
    z[3,4,6]  R2275     -6.0037189722061157e-01
    z[3,4,6]  R2276     -4.3797045946121216e-01
    z[3,4,6]  R2277     -5.0236219167709351e-01
    z[3,4,6]  R2278     -4.6849304437637329e-01
    z[3,4,6]  R2279     -3.2818296551704407e-01
    z[3,4,6]  R2280     1.7228440940380096e-01
    z[3,4,6]  R2281     1.8132114410400391e-01
    z[3,4,6]  R2282     -3.5852468013763428e-01
    z[3,4,6]  R2283     -3.9278939366340637e-01
    z[3,4,6]  R2284     -3.9323008060455322e-01
    z[3,4,6]  R2285     -4.7162118554115295e-01
    z[3,4,6]  R2286     -3.8046449422836304e-01
    z[3,4,6]  R2287     -2.3921951651573181e-02
    z[3,4,6]  R2288     -2.5964441895484924e-01
    z[3,4,6]  R2289     -1.0932006686925888e-01
    z[3,4,6]  R2290     -7.2604125738143921e-01
    z[3,4,6]  R2291     -1.5151165425777435e-01
    z[3,4,6]  R2292     -2.5049192830920219e-02
    z[3,4,6]  R2293     -1.7614869773387909e-01
    z[3,4,6]  R2294     -8.9096657931804657e-02
    z[3,4,6]  R2295     -2.1664224565029144e-01
    z[3,4,6]  R2296     -1.5606154501438141e-01
    z[3,4,6]  R2297     8.1897906959056854e-02
    z[3,4,6]  R2298     5.6511354446411133e-01
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R2299     -1
    z[4,3,0]  R2300     1
    z[4,3,0]  R2313     5.5870389938354492e-01
    z[4,3,0]  R2314     9.9818736314773560e-02
    z[4,3,0]  R2315     -2.0530523732304573e-02
    z[4,3,0]  R2316     8.2103852182626724e-03
    z[4,3,0]  R2317     -1.4202977716922760e-01
    z[4,3,0]  R2318     -4.8766386508941650e-01
    z[4,3,0]  R2319     -1.5281499922275543e-01
    z[4,3,0]  R2320     8.8300663232803345e-01
    z[4,3,0]  R2321     7.5461864471435547e-01
    z[4,3,0]  R2322     8.5505962371826172e-01
    z[4,3,0]  R2323     -7.1266913414001465e-01
    z[4,3,0]  R2324     -0.489612340927124
    z[4,3,0]  R2325     -6.8424749374389648e-01
    z[4,3,0]  R2326     -5.7680004835128784e-01
    z[4,3,0]  R2327     -0.0508616641163826
    z[4,3,0]  R2328     9.8354585468769073e-02
    z[4,3,0]  R2329     -1.6463661193847656e-01
    z[4,3,0]  R2330     -2.3018735647201538e-01
    z[4,3,0]  R2331     -2.4711753427982330e-01
    z[4,3,0]  R2332     -7.2288691997528076e-02
    z[4,3,0]  R2333     -5.7580053806304932e-01
    z[4,3,0]  R2334     2.5338813662528992e-01
    z[4,3,0]  R2335     2.2624200209975243e-02
    z[4,3,0]  R2336     4.2387198656797409e-02
    z[4,3,0]  R2337     4.6951755881309509e-02
    z[4,3,0]  R2338     1.1479977518320084e-01
    z[4,3,0]  R2339     -7.6783820986747742e-03
    z[4,3,0]  R2340     -4.7213941812515259e-02
    z[4,3,0]  R2341     2.0390398800373077e-01
    z[4,3,0]  R2342     4.9588415771722794e-02
    z[4,3,0]  R2343     -0.370315819978714
    z[4,3,0]  R2344     -4.2799603939056396e-01
    z[4,3,0]  R2345     2.4122430384159088e-01
    z[4,3,0]  R2346     0.111538365483284
    z[4,3,0]  R2347     2.3198957741260529e-01
    z[4,3,0]  R2348     2.9266181588172913e-01
    z[4,3,0]  R2349     -2.6075911521911621e-01
    z[4,3,0]  R2350     0.12830850481987
    z[4,3,0]  R2351     2.7927669882774353e-01
    z[4,3,0]  R2352     2.9127854108810425e-01
    z[4,3,0]  R2353     -3.4406775236129761e-01
    z[4,3,0]  R2354     -3.2790100574493408e-01
    z[4,3,0]  R2355     -2.7911195158958435e-01
    z[4,3,0]  R2356     -2.5956231355667114e-01
    z[4,3,0]  R2357     -0.389911025762558
    z[4,3,0]  R2358     -0.200189471244812
    z[4,3,0]  R2359     -2.5247624516487122e-01
    z[4,3,0]  R2360     7.9031985998153687e-01
    z[4,3,0]  R2361     8.8028162717819214e-01
    z[4,3,0]  R2362     8.6288440227508545e-01
    z[4,3,0]  R2363     -5.6515991687774658e-01
    z[4,3,0]  R2364     -7.2183072566986084e-01
    z[4,3,0]  R2365     -1.0561756044626236e-01
    z[4,3,0]  R2366     9.0281152725219727e-01
    z[4,3,0]  R2367     -5.6377702951431274e-01
    z[4,3,0]  R2368     -4.2510709166526794e-01
    z[4,3,0]  R2369     -3.1426465511322021e-01
    z[4,3,0]  R2370     -0.472042441368103
    z[4,3,0]  R2371     -5.2815198898315430e-01
    z[4,3,0]  R2372     -4.3587875366210938e-01
    z[4,3,0]  R2373     -8.0650782585144043e-01
    z[4,3,0]  R2374     -5.4882502555847168e-01
    z[4,3,0]  R2375     -5.3742176294326782e-01
    z[4,3,0]  R2376     -5.6928426027297974e-01
    z[4,3,0]  R2377     -5.6497520208358765e-01
    z[4,3,0]  R2378     -6.1704134941101074e-01
    z[4,3,0]  R2379     -0.656769335269928
    z[4,3,0]  R2380     -7.2379314899444580e-01
    z[4,3,0]  R2381     -4.4615957140922546e-01
    z[4,3,0]  R2382     -5.2692312002182007e-01
    z[4,3,0]  R2383     -3.8040143251419067e-01
    z[4,3,0]  R2384     -8.1182342767715454e-01
    z[4,3,0]  R2385     -0.684876024723053
    z[4,3,0]  R2386     -5.0133860111236572e-01
    z[4,3,0]  R2387     -5.6957280635833740e-01
    z[4,3,0]  R2388     0.356876015663147
    z[4,3,0]  R2389     8.1507444381713867e-01
    z[4,3,0]  R2390     9.1206395626068115e-01
    z[4,3,0]  R2391     7.6318812370300293e-01
    z[4,3,0]  R2392     8.7414103746414185e-01
    z[4,3,0]  R2393     -5.3127700090408325e-01
    z[4,3,0]  R2394     -3.3868685364723206e-01
    z[4,3,0]  R2395     -3.4689253568649292e-01
    z[4,3,0]  R2396     -0.587253212928772
    z[4,3,0]  R2397     -2.1451064944267273e-01
    z[4,3,0]  R2398     -1.4580808579921722e-01
    z[4,3,0]  R2399     -5.0207239389419556e-01
    z[4,3,0]  R2400     -6.3019603490829468e-01
    z[4,3,0]  R2401     -6.6657543182373047e-01
    z[4,3,0]  R2402     -4.9757176637649536e-01
    z[4,3,0]  R2403     -5.4342097043991089e-01
    z[4,3,0]  R2404     -8.4325426816940308e-01
    z[4,3,0]  R2405     -8.3551156520843506e-01
    z[4,3,0]  R2406     -5.7310348749160767e-01
    z[4,3,0]  R2407     -3.0678653717041016e-01
    z[4,3,0]  R2408     -0.371635377407074
    z[4,3,0]  R2409     -5.5593419075012207e-01
    z[4,3,0]  R2410     4.6494059264659882e-02
    z[4,3,0]  R2411     8.0510163307189941e-01
    z[4,3,0]  R2412     8.6243516206741333e-01
    z[4,3,0]  R2413     6.2239643186330795e-02
    z[4,3,0]  R2414     -7.6600360870361328e-01
    z[4,3,0]  R2415     5.9907469898462296e-02
    z[4,3,0]  R2416     -6.7986255884170532e-01
    z[4,3,0]  R2417     -6.9654667377471924e-01
    z[4,3,0]  R2418     -5.5627793073654175e-01
    z[4,3,0]  R2419     -7.0455557107925415e-01
    z[4,3,0]  R2420     -2.4017766118049622e-02
    z[4,3,0]  R2421     8.6195367574691772e-01
    z[4,3,0]  R2422     8.7085694074630737e-01
    z[4,3,0]  R2423     -4.1222232580184937e-01
    z[4,3,0]  R2424     -3.7235784530639648e-01
    z[4,3,0]  R2425     -2.5136863812804222e-02
    z[4,3,0]  R2426     -7.5712692737579346e-01
    z[4,3,0]  R2427     -5.1961249113082886e-01
    z[4,3,0]  R2428     -1.2179906666278839e-01
    z[4,3,0]  R2429     9.1755294799804688e-01
    z[4,3,0]  R2430     7.9644507169723511e-01
    z[4,3,0]  R2431     0.795567512512207
    z[4,3,0]  R2432     8.2271134853363037e-01
    z[4,3,0]  R2433     -4.8599314689636230e-01
    z[4,3,0]  R2434     -6.6693328320980072e-02
    z[4,3,0]  R2435     -4.7179032117128372e-02
    z[4,3,0]  R2436     -2.1626415848731995e-01
    z[4,3,0]  R2437     -2.4165056645870209e-01
    z[4,3,0]  R2438     -8.7707346677780151e-01
    z[4,3,0]  R2439     -8.2092583179473877e-01
    z[4,3,0]  R2440     3.0467975139617920e-01
    z[4,3,0]  R2441     -7.1975088119506836e-01
    z[4,3,0]  R2442     8.4028869867324829e-01
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R2301     -1
    z[4,3,1]  R2302     1
    z[4,3,1]  R2313     5.6021219491958618e-01
    z[4,3,1]  R2314     7.8178036212921143e-01
    z[4,3,1]  R2315     7.5345677137374878e-01
    z[4,3,1]  R2316     3.8890364766120911e-01
    z[4,3,1]  R2317     4.9546009302139282e-01
    z[4,3,1]  R2318     1.8506301939487457e-01
    z[4,3,1]  R2319     1.7123848199844360e-01
    z[4,3,1]  R2320     3.8786649703979492e-02
    z[4,3,1]  R2321     -2.4267809092998505e-01
    z[4,3,1]  R2322     -2.5800105929374695e-01
    z[4,3,1]  R2323     -1.9565564393997192e-01
    z[4,3,1]  R2324     -1.5061859786510468e-01
    z[4,3,1]  R2325     -3.5446065664291382e-01
    z[4,3,1]  R2326     -3.8342043757438660e-01
    z[4,3,1]  R2327     -8.9201897382736206e-01
    z[4,3,1]  R2328     -7.1640813350677490e-01
    z[4,3,1]  R2329     -7.1327060461044312e-01
    z[4,3,1]  R2330     -4.8758310079574585e-01
    z[4,3,1]  R2331     -8.1594669818878174e-01
    z[4,3,1]  R2332     -6.2656390666961670e-01
    z[4,3,1]  R2333     1.0611204802989960e-01
    z[4,3,1]  R2334     -4.4901618361473083e-01
    z[4,3,1]  R2335     -7.4879795312881470e-01
    z[4,3,1]  R2336     -8.4246599674224854e-01
    z[4,3,1]  R2337     -7.3599445819854736e-01
    z[4,3,1]  R2338     -7.6748752593994141e-01
    z[4,3,1]  R2339     -8.7122011184692383e-01
    z[4,3,1]  R2340     -0.759326159954071
    z[4,3,1]  R2341     -8.7563234567642212e-01
    z[4,3,1]  R2342     -9.0224641561508179e-01
    z[4,3,1]  R2343     4.2711898684501648e-01
    z[4,3,1]  R2344     1.1950732767581940e-01
    z[4,3,1]  R2345     -7.9304671287536621e-01
    z[4,3,1]  R2346     -6.9904738664627075e-01
    z[4,3,1]  R2347     -8.7748444080352783e-01
    z[4,3,1]  R2348     -8.8935530185699463e-01
    z[4,3,1]  R2349     -7.5103670358657837e-01
    z[4,3,1]  R2350     -8.4581160545349121e-01
    z[4,3,1]  R2351     -1.1033361405134201e-01
    z[4,3,1]  R2352     -6.0323875397443771e-02
    z[4,3,1]  R2353     -4.0743622183799744e-01
    z[4,3,1]  R2354     -1.9889074563980103e-01
    z[4,3,1]  R2355     5.7454162836074829e-01
    z[4,3,1]  R2356     1.6744308173656464e-01
    z[4,3,1]  R2357     -3.1165421009063721e-01
    z[4,3,1]  R2358     3.1051808595657349e-01
    z[4,3,1]  R2359     4.2386922240257263e-01
    z[4,3,1]  R2360     -0.0718371719121933
    z[4,3,1]  R2361     -8.9955933392047882e-02
    z[4,3,1]  R2362     5.7048797607421875e-02
    z[4,3,1]  R2363     -1.1104349046945572e-01
    z[4,3,1]  R2364     -1.6461621224880219e-01
    z[4,3,1]  R2365     -4.3762156367301941e-01
    z[4,3,1]  R2366     1.6248683631420135e-01
    z[4,3,1]  R2367     1.1134830117225647e-01
    z[4,3,1]  R2368     -7.3070541024208069e-02
    z[4,3,1]  R2369     9.6246063709259033e-02
    z[4,3,1]  R2370     1.1782778799533844e-01
    z[4,3,1]  R2371     2.7041202783584595e-01
    z[4,3,1]  R2372     -5.4209005832672119e-01
    z[4,3,1]  R2373     3.8884720206260681e-01
    z[4,3,1]  R2374     -3.4910616278648376e-01
    z[4,3,1]  R2375     5.5928987264633179e-01
    z[4,3,1]  R2376     4.4444081187248230e-01
    z[4,3,1]  R2377     0.575400710105896
    z[4,3,1]  R2378     4.9236461520195007e-01
    z[4,3,1]  R2379     3.6707437038421631e-01
    z[4,3,1]  R2380     -0.401419073343277
    z[4,3,1]  R2381     5.9140056371688843e-01
    z[4,3,1]  R2382     1.9477939605712891e-01
    z[4,3,1]  R2383     5.6616431474685669e-01
    z[4,3,1]  R2384     4.7562189400196075e-02
    z[4,3,1]  R2385     2.3031720519065857e-01
    z[4,3,1]  R2386     -1.3365231454372406e-01
    z[4,3,1]  R2387     3.5345628857612610e-02
    z[4,3,1]  R2388     -5.4927694797515869e-01
    z[4,3,1]  R2389     -2.5580203533172607e-01
    z[4,3,1]  R2390     -2.9031846672296524e-02
    z[4,3,1]  R2391     2.1840266883373260e-01
    z[4,3,1]  R2392     1.0058821178972721e-02
    z[4,3,1]  R2393     -4.8622789978981018e-01
    z[4,3,1]  R2394     2.0794808864593506e-01
    z[4,3,1]  R2395     4.7027045488357544e-01
    z[4,3,1]  R2396     -7.0744462311267853e-02
    z[4,3,1]  R2397     -2.3843885958194733e-01
    z[4,3,1]  R2398     -1.1425514519214630e-01
    z[4,3,1]  R2399     -4.8765793442726135e-01
    z[4,3,1]  R2400     -2.7695251628756523e-02
    z[4,3,1]  R2401     -4.5463964343070984e-02
    z[4,3,1]  R2402     3.7216268479824066e-02
    z[4,3,1]  R2403     0.563527524471283
    z[4,3,1]  R2404     2.7319166064262390e-01
    z[4,3,1]  R2405     -1.4385347068309784e-01
    z[4,3,1]  R2406     7.2615332901477814e-03
    z[4,3,1]  R2407     8.1111228466033936e-01
    z[4,3,1]  R2408     3.2436794042587280e-01
    z[4,3,1]  R2409     4.0905106067657471e-01
    z[4,3,1]  R2410     -6.5500330924987793e-01
    z[4,3,1]  R2411     3.4475263953208923e-01
    z[4,3,1]  R2412     1.8451488018035889e-01
    z[4,3,1]  R2413     -3.3994078636169434e-01
    z[4,3,1]  R2414     4.7159090638160706e-01
    z[4,3,1]  R2415     -2.5233197212219238e-01
    z[4,3,1]  R2416     1.8022919073700905e-02
    z[4,3,1]  R2417     0.0539570190012455
    z[4,3,1]  R2418     1.6202329099178314e-01
    z[4,3,1]  R2419     2.8932240605354309e-01
    z[4,3,1]  R2420     -7.3883497714996338e-01
    z[4,3,1]  R2421     -1.1312500573694706e-03
    z[4,3,1]  R2422     2.0633409917354584e-01
    z[4,3,1]  R2423     -0.57985520362854
    z[4,3,1]  R2424     5.2900129556655884e-01
    z[4,3,1]  R2425     -0.422419011592865
    z[4,3,1]  R2426     -3.2618728280067444e-01
    z[4,3,1]  R2427     3.6254149675369263e-01
    z[4,3,1]  R2428     1.5918913483619690e-01
    z[4,3,1]  R2429     9.1630041599273682e-02
    z[4,3,1]  R2430     1.0925793647766113e-01
    z[4,3,1]  R2431     -1.5200471878051758e-01
    z[4,3,1]  R2432     -2.1054264903068542e-01
    z[4,3,1]  R2433     2.1635462343692780e-01
    z[4,3,1]  R2434     -3.5965493321418762e-01
    z[4,3,1]  R2435     -5.1427793502807617e-01
    z[4,3,1]  R2436     -3.7195730209350586e-01
    z[4,3,1]  R2437     -6.8676269054412842e-01
    z[4,3,1]  R2438     1.7070958018302917e-01
    z[4,3,1]  R2439     2.0195762813091278e-01
    z[4,3,1]  R2440     -6.7172354459762573e-01
    z[4,3,1]  R2441     2.9508890584111214e-02
    z[4,3,1]  R2442     2.8312578797340393e-01
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R2303     -1
    z[4,3,2]  R2304     1
    z[4,3,2]  R2313     -3.8512402772903442e-01
    z[4,3,2]  R2314     5.6504216045141220e-02
    z[4,3,2]  R2315     -3.9413750171661377e-01
    z[4,3,2]  R2316     1.1042091995477676e-01
    z[4,3,2]  R2317     1.2807871401309967e-01
    z[4,3,2]  R2318     1.2600994668900967e-02
    z[4,3,2]  R2319     1.0695854574441910e-01
    z[4,3,2]  R2320     3.7434976547956467e-02
    z[4,3,2]  R2321     1.3555747270584106e-01
    z[4,3,2]  R2322     -0.0625605583190918
    z[4,3,2]  R2323     0.49066162109375
    z[4,3,2]  R2324     3.7475490570068359e-01
    z[4,3,2]  R2325     -1.8631502985954285e-01
    z[4,3,2]  R2326     -5.3598236292600632e-02
    z[4,3,2]  R2327     -9.7490988671779633e-02
    z[4,3,2]  R2328     -5.3910166025161743e-01
    z[4,3,2]  R2329     -1.0701456665992737e-01
    z[4,3,2]  R2330     -3.9065742492675781e-01
    z[4,3,2]  R2331     -7.0837214589118958e-02
    z[4,3,2]  R2332     -4.8441314697265625e-01
    z[4,3,2]  R2333     -1.2420298904180527e-01
    z[4,3,2]  R2334     -3.6703076958656311e-01
    z[4,3,2]  R2335     -8.0870762467384338e-02
    z[4,3,2]  R2336     -1.6054618358612061e-01
    z[4,3,2]  R2337     -1.4383193850517273e-01
    z[4,3,2]  R2338     -2.4992391467094421e-01
    z[4,3,2]  R2339     -8.3724528551101685e-02
    z[4,3,2]  R2340     3.0607774853706360e-01
    z[4,3,2]  R2341     3.2696709036827087e-01
    z[4,3,2]  R2342     2.2576428949832916e-01
    z[4,3,2]  R2343     -3.0090728402137756e-01
    z[4,3,2]  R2344     -2.3227781057357788e-01
    z[4,3,2]  R2345     -1.1948853731155396e-01
    z[4,3,2]  R2346     -1.9092109799385071e-01
    z[4,3,2]  R2347     3.3038997650146484e-01
    z[4,3,2]  R2348     1.7247335612773895e-01
    z[4,3,2]  R2349     -6.6403280943632126e-03
    z[4,3,2]  R2350     3.6510783433914185e-01
    z[4,3,2]  R2351     -7.7136582136154175e-01
    z[4,3,2]  R2352     -0.623135507106781
    z[4,3,2]  R2353     4.1041958332061768e-01
    z[4,3,2]  R2354     4.8243105411529541e-01
    z[4,3,2]  R2355     1.5083377063274384e-01
    z[4,3,2]  R2356     2.3986802995204926e-01
    z[4,3,2]  R2357     5.3352898359298706e-01
    z[4,3,2]  R2358     -1.8829308450222015e-01
    z[4,3,2]  R2359     -6.2303669750690460e-02
    z[4,3,2]  R2360     -6.2953778542578220e-03
    z[4,3,2]  R2361     -6.2106844037771225e-02
    z[4,3,2]  R2362     2.6103788614273071e-01
    z[4,3,2]  R2363     1.2965458631515503e-01
    z[4,3,2]  R2364     -4.6965414285659790e-01
    z[4,3,2]  R2365     2.0638918876647949e-01
    z[4,3,2]  R2366     1.6082639992237091e-01
    z[4,3,2]  R2367     -6.0505729913711548e-01
    z[4,3,2]  R2368     -7.0326203107833862e-01
    z[4,3,2]  R2369     -8.3815455436706543e-01
    z[4,3,2]  R2370     -6.1573606729507446e-01
    z[4,3,2]  R2371     4.2432656884193420e-01
    z[4,3,2]  R2372     -3.0441206693649292e-01
    z[4,3,2]  R2373     1.5811249613761902e-01
    z[4,3,2]  R2374     0.376202791929245
    z[4,3,2]  R2375     5.0575062632560730e-02
    z[4,3,2]  R2376     2.1942797303199768e-01
    z[4,3,2]  R2377     -4.8627737164497375e-01
    z[4,3,2]  R2378     -3.4369108080863953e-01
    z[4,3,2]  R2379     1.2670375406742096e-01
    z[4,3,2]  R2380     -2.3087514936923981e-01
    z[4,3,2]  R2381     -4.0249493718147278e-01
    z[4,3,2]  R2382     7.9355299472808838e-01
    z[4,3,2]  R2383     -6.2529988586902618e-02
    z[4,3,2]  R2384     -2.4667935073375702e-01
    z[4,3,2]  R2385     -2.9975825548171997e-01
    z[4,3,2]  R2386     -1.9519220292568207e-01
    z[4,3,2]  R2387     -3.2596173882484436e-01
    z[4,3,2]  R2388     5.3519034385681152e-01
    z[4,3,2]  R2389     4.2127409577369690e-01
    z[4,3,2]  R2390     1.2512315809726715e-01
    z[4,3,2]  R2391     3.2611471414566040e-01
    z[4,3,2]  R2392     2.5055831670761108e-01
    z[4,3,2]  R2393     3.1556525826454163e-01
    z[4,3,2]  R2394     -2.1326968073844910e-01
    z[4,3,2]  R2395     -2.4498504400253296e-01
    z[4,3,2]  R2396     9.8096147179603577e-02
    z[4,3,2]  R2397     5.0670439004898071e-01
    z[4,3,2]  R2398     5.9198117256164551e-01
    z[4,3,2]  R2399     -4.0576282143592834e-01
    z[4,3,2]  R2400     -4.5886853337287903e-01
    z[4,3,2]  R2401     -4.3549299240112305e-01
    z[4,3,2]  R2402     -7.1385937929153442e-01
    z[4,3,2]  R2403     -1.5301067614927888e-03
    z[4,3,2]  R2404     -4.0854278206825256e-01
    z[4,3,2]  R2405     2.4864038452506065e-02
    z[4,3,2]  R2406     3.0922656878829002e-02
    z[4,3,2]  R2407     -0.0631827712059021
    z[4,3,2]  R2408     6.1961793899536133e-01
    z[4,3,2]  R2409     -4.2903009057044983e-01
    z[4,3,2]  R2410     1.7989465594291687e-01
    z[4,3,2]  R2411     3.3121243119239807e-01
    z[4,3,2]  R2412     2.1600204706192017e-01
    z[4,3,2]  R2413     6.9001567363739014e-01
    z[4,3,2]  R2414     -2.2462388500571251e-02
    z[4,3,2]  R2415     7.2278487682342529e-01
    z[4,3,2]  R2416     -2.3946358263492584e-01
    z[4,3,2]  R2417     -5.9312063455581665e-01
    z[4,3,2]  R2418     7.0781731605529785e-01
    z[4,3,2]  R2419     1.1221123486757278e-01
    z[4,3,2]  R2420     1.1881493777036667e-01
    z[4,3,2]  R2421     2.9405781626701355e-01
    z[4,3,2]  R2422     -1.0706714354455471e-02
    z[4,3,2]  R2423     2.5668564438819885e-01
    z[4,3,2]  R2424     -3.7382226437330246e-02
    z[4,3,2]  R2425     6.8933749198913574e-01
    z[4,3,2]  R2426     -3.1472650170326233e-01
    z[4,3,2]  R2427     -3.4611481428146362e-01
    z[4,3,2]  R2428     7.3608571290969849e-01
    z[4,3,2]  R2429     3.4660151600837708e-01
    z[4,3,2]  R2430     3.5235700011253357e-01
    z[4,3,2]  R2431     -3.8247801363468170e-02
    z[4,3,2]  R2432     -1.2653575837612152e-01
    z[4,3,2]  R2433     4.0381708741188049e-01
    z[4,3,2]  R2434     6.5360546112060547e-01
    z[4,3,2]  R2435     5.5261862277984619e-01
    z[4,3,2]  R2436     8.4787815809249878e-01
    z[4,3,2]  R2437     1.0278853029012680e-01
    z[4,3,2]  R2438     -1.9657596945762634e-01
    z[4,3,2]  R2439     -1.7647102475166321e-01
    z[4,3,2]  R2440     4.9150779843330383e-01
    z[4,3,2]  R2441     3.6729894578456879e-02
    z[4,3,2]  R2442     -1.0624358803033829e-01
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R2305     -1
    z[4,3,3]  R2306     1
    z[4,3,3]  R2313     -3.8021820783615112e-01
    z[4,3,3]  R2314     -4.8384204506874084e-01
    z[4,3,3]  R2315     -3.6220863461494446e-01
    z[4,3,3]  R2316     -4.1754421591758728e-01
    z[4,3,3]  R2317     -2.9438000917434692e-01
    z[4,3,3]  R2318     -3.1255516409873962e-01
    z[4,3,3]  R2319     6.8910324573516846e-01
    z[4,3,3]  R2320     -3.0642330646514893e-01
    z[4,3,3]  R2321     -0.398311972618103
    z[4,3,3]  R2322     -2.8055045008659363e-01
    z[4,3,3]  R2323     2.8187143802642822e-01
    z[4,3,3]  R2324     4.5860681682825089e-02
    z[4,3,3]  R2325     -2.4828857183456421e-01
    z[4,3,3]  R2326     -1.3207701034843922e-02
    z[4,3,3]  R2327     -8.9316688477993011e-02
    z[4,3,3]  R2328     -2.1141889691352844e-01
    z[4,3,3]  R2329     9.3292370438575745e-02
    z[4,3,3]  R2330     -3.2621735334396362e-01
    z[4,3,3]  R2331     -1.0185866057872772e-01
    z[4,3,3]  R2332     -3.8146099448204041e-01
    z[4,3,3]  R2333     3.0751854181289673e-01
    z[4,3,3]  R2334     -6.9934684038162231e-01
    z[4,3,3]  R2335     -3.2809826731681824e-01
    z[4,3,3]  R2336     -3.1848379969596863e-01
    z[4,3,3]  R2337     -3.9895847439765930e-01
    z[4,3,3]  R2338     -3.7319111824035645e-01
    z[4,3,3]  R2339     3.6862384527921677e-02
    z[4,3,3]  R2340     8.2869239151477814e-02
    z[4,3,3]  R2341     2.8244696557521820e-02
    z[4,3,3]  R2342     -5.6988544762134552e-02
    z[4,3,3]  R2343     4.1068476438522339e-01
    z[4,3,3]  R2344     3.7810587882995605e-01
    z[4,3,3]  R2345     -3.4058916568756104e-01
    z[4,3,3]  R2346     -5.4312676191329956e-01
    z[4,3,3]  R2347     -9.5807880163192749e-02
    z[4,3,3]  R2348     2.8587602078914642e-02
    z[4,3,3]  R2349     -3.5784307122230530e-01
    z[4,3,3]  R2350     2.3451048135757446e-01
    z[4,3,3]  R2351     4.9130004644393921e-01
    z[4,3,3]  R2352     4.0348741412162781e-01
    z[4,3,3]  R2353     -2.7057039737701416e-01
    z[4,3,3]  R2354     2.2242200374603271e-01
    z[4,3,3]  R2355     -4.8630633950233459e-01
    z[4,3,3]  R2356     -9.0782207250595093e-01
    z[4,3,3]  R2357     -6.0245823860168457e-01
    z[4,3,3]  R2358     -7.7078616619110107e-01
    z[4,3,3]  R2359     -5.7151901721954346e-01
    z[4,3,3]  R2360     -4.4974225759506226e-01
    z[4,3,3]  R2361     -3.3146941661834717e-01
    z[4,3,3]  R2362     -3.7510424852371216e-01
    z[4,3,3]  R2363     3.1618601083755493e-01
    z[4,3,3]  R2364     -1.8194037675857544e-01
    z[4,3,3]  R2365     3.8946425914764404e-01
    z[4,3,3]  R2366     0.081110879778862
    z[4,3,3]  R2367     1.6585490107536316e-01
    z[4,3,3]  R2368     3.3532249927520752e-01
    z[4,3,3]  R2369     2.4041488766670227e-01
    z[4,3,3]  R2370     5.9478312730789185e-01
    z[4,3,3]  R2371     3.0572825670242310e-01
    z[4,3,3]  R2372     -9.2390157282352448e-02
    z[4,3,3]  R2373     -7.5568921864032745e-02
    z[4,3,3]  R2374     -9.7693480551242828e-02
    z[4,3,3]  R2375     -1.7162151634693146e-01
    z[4,3,3]  R2376     -1.2340348213911057e-01
    z[4,3,3]  R2377     -3.6988846957683563e-02
    z[4,3,3]  R2378     -2.4959733709692955e-02
    z[4,3,3]  R2379     -5.6879818439483643e-03
    z[4,3,3]  R2380     4.3359389901161194e-01
    z[4,3,3]  R2381     -1.2845497578382492e-02
    z[4,3,3]  R2382     -1.7646154761314392e-01
    z[4,3,3]  R2383     -4.5771875977516174e-01
    z[4,3,3]  R2384     -4.7059425711631775e-01
    z[4,3,3]  R2385     2.9010131955146790e-01
    z[4,3,3]  R2386     -1.5414546430110931e-01
    z[4,3,3]  R2387     2.8731770813465118e-02
    z[4,3,3]  R2388     5.1945778541266918e-03
    z[4,3,3]  R2389     -0.0582304522395134
    z[4,3,3]  R2390     -2.7886587381362915e-01
    z[4,3,3]  R2391     1.9689889624714851e-02
    z[4,3,3]  R2392     -1.2389860302209854e-01
    z[4,3,3]  R2393     2.3909914493560791e-01
    z[4,3,3]  R2394     -8.3357393741607666e-01
    z[4,3,3]  R2395     -5.2888363599777222e-01
    z[4,3,3]  R2396     -6.7985409498214722e-01
    z[4,3,3]  R2397     6.0640448331832886e-01
    z[4,3,3]  R2398     5.7174468040466309e-01
    z[4,3,3]  R2399     -7.3191873729228973e-02
    z[4,3,3]  R2400     2.1180571615695953e-01
    z[4,3,3]  R2401     -2.2566859424114227e-01
    z[4,3,3]  R2402     -1.3528390228748322e-01
    z[4,3,3]  R2403     -3.4971076250076294e-01
    z[4,3,3]  R2404     -1.2376046925783157e-01
    z[4,3,3]  R2405     -1.3576015830039978e-02
    z[4,3,3]  R2406     -6.5821069478988647e-01
    z[4,3,3]  R2407     -3.2483169436454773e-01
    z[4,3,3]  R2408     -4.0063586831092834e-01
    z[4,3,3]  R2409     3.1285667419433594e-01
    z[4,3,3]  R2410     1.3730789721012115e-01
    z[4,3,3]  R2411     -1.4332598447799683e-01
    z[4,3,3]  R2412     3.1519293785095215e-01
    z[4,3,3]  R2413     -9.5184780657291412e-02
    z[4,3,3]  R2414     2.4369803071022034e-01
    z[4,3,3]  R2415     0.348730206489563
    z[4,3,3]  R2416     0.451188862323761
    z[4,3,3]  R2417     3.3942395448684692e-01
    z[4,3,3]  R2418     -6.7075587809085846e-02
    z[4,3,3]  R2419     1.8302203714847565e-01
    z[4,3,3]  R2420     1.1391800642013550e-01
    z[4,3,3]  R2421     1.4862108230590820e-01
    z[4,3,3]  R2422     -3.2110220193862915e-01
    z[4,3,3]  R2423     4.3260562419891357e-01
    z[4,3,3]  R2424     -6.7774200439453125e-01
    z[4,3,3]  R2425     -4.0927335619926453e-01
    z[4,3,3]  R2426     -1.3049960136413574e-02
    z[4,3,3]  R2427     -0.502071738243103
    z[4,3,3]  R2428     -9.1563336551189423e-02
    z[4,3,3]  R2429     -1.4747790992259979e-01
    z[4,3,3]  R2430     -7.6781474053859711e-02
    z[4,3,3]  R2431     1.6723388433456421e-01
    z[4,3,3]  R2432     1.7311847209930420e-01
    z[4,3,3]  R2433     -7.0427286624908447e-01
    z[4,3,3]  R2434     5.3233772516250610e-01
    z[4,3,3]  R2435     4.6594947576522827e-01
    z[4,3,3]  R2436     -3.8813658058643341e-02
    z[4,3,3]  R2437     -2.1370275318622589e-01
    z[4,3,3]  R2438     2.2169852256774902e-01
    z[4,3,3]  R2439     1.7748758196830750e-02
    z[4,3,3]  R2440     2.0500671863555908e-01
    z[4,3,3]  R2441     -8.5821323096752167e-02
    z[4,3,3]  R2442     1.5121363103389740e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R2307     -1
    z[4,3,4]  R2308     1
    z[4,3,4]  R2313     -1.8614172935485840e-01
    z[4,3,4]  R2314     2.1207168698310852e-01
    z[4,3,4]  R2315     1.3169211149215698e-01
    z[4,3,4]  R2316     -5.8622401952743530e-01
    z[4,3,4]  R2317     -7.0075875520706177e-01
    z[4,3,4]  R2318     2.7352645993232727e-02
    z[4,3,4]  R2319     4.4997197389602661e-01
    z[4,3,4]  R2320     -1.1206955462694168e-01
    z[4,3,4]  R2321     -3.5753118991851807e-01
    z[4,3,4]  R2322     3.3977007865905762e-01
    z[4,3,4]  R2323     5.3274929523468018e-02
    z[4,3,4]  R2324     4.2905649542808533e-01
    z[4,3,4]  R2325     3.0451324582099915e-01
    z[4,3,4]  R2326     6.3623654842376709e-01
    z[4,3,4]  R2327     -3.5619032382965088e-01
    z[4,3,4]  R2328     -7.8622095286846161e-02
    z[4,3,4]  R2329     -1.7840167507529259e-02
    z[4,3,4]  R2330     -8.1945598125457764e-02
    z[4,3,4]  R2331     -6.9304317235946655e-02
    z[4,3,4]  R2332     -0.0410560667514801
    z[4,3,4]  R2333     -3.1161725521087646e-01
    z[4,3,4]  R2334     1.3672819733619690e-01
    z[4,3,4]  R2335     -3.2310044765472412e-01
    z[4,3,4]  R2336     8.5804097354412079e-02
    z[4,3,4]  R2337     -1.7356221377849579e-01
    z[4,3,4]  R2338     -7.4332311749458313e-02
    z[4,3,4]  R2339     -3.4329265356063843e-02
    z[4,3,4]  R2340     -3.0796703696250916e-01
    z[4,3,4]  R2341     2.1189035475254059e-01
    z[4,3,4]  R2342     5.9805028140544891e-02
    z[4,3,4]  R2343     1.9889065623283386e-01
    z[4,3,4]  R2344     -2.7678728103637695e-01
    z[4,3,4]  R2345     3.1266503036022186e-02
    z[4,3,4]  R2346     -3.5277768969535828e-01
    z[4,3,4]  R2347     -5.2817653864622116e-02
    z[4,3,4]  R2348     -1.7005857825279236e-01
    z[4,3,4]  R2349     -3.9837956428527832e-01
    z[4,3,4]  R2350     -2.1901425719261169e-01
    z[4,3,4]  R2351     -4.2809482663869858e-02
    z[4,3,4]  R2352     -4.0744204074144363e-02
    z[4,3,4]  R2353     -4.2647701501846313e-01
    z[4,3,4]  R2354     6.4936959743499756e-01
    z[4,3,4]  R2355     2.0659589767456055e-01
    z[4,3,4]  R2356     1.2071436643600464e-01
    z[4,3,4]  R2357     -2.6310819387435913e-01
    z[4,3,4]  R2358     -2.7697184681892395e-01
    z[4,3,4]  R2359     -6.3517436385154724e-02
    z[4,3,4]  R2360     1.3910956680774689e-01
    z[4,3,4]  R2361     -1.1195933073759079e-01
    z[4,3,4]  R2362     0.00340811675414443
    z[4,3,4]  R2363     2.2796740755438805e-02
    z[4,3,4]  R2364     2.9402857646346092e-02
    z[4,3,4]  R2365     -2.3719245195388794e-01
    z[4,3,4]  R2366     3.0050572752952576e-01
    z[4,3,4]  R2367     2.9327198863029480e-01
    z[4,3,4]  R2368     1.3792613148689270e-01
    z[4,3,4]  R2369     2.5427341461181641e-02
    z[4,3,4]  R2370     0.118742436170578
    z[4,3,4]  R2371     -3.8816636800765991e-01
    z[4,3,4]  R2372     -1.4444314874708652e-02
    z[4,3,4]  R2373     2.9218655824661255e-01
    z[4,3,4]  R2374     1.4821581542491913e-01
    z[4,3,4]  R2375     2.9983353614807129e-01
    z[4,3,4]  R2376     -1.4140526950359344e-01
    z[4,3,4]  R2377     -7.0724025368690491e-02
    z[4,3,4]  R2378     8.9530251920223236e-02
    z[4,3,4]  R2379     -2.9376211762428284e-01
    z[4,3,4]  R2380     -6.6264927387237549e-02
    z[4,3,4]  R2381     -4.9960368871688843e-01
    z[4,3,4]  R2382     4.7424253076314926e-02
    z[4,3,4]  R2383     -5.2696573734283447e-01
    z[4,3,4]  R2384     0.225468710064888
    z[4,3,4]  R2385     5.3126358985900879e-01
    z[4,3,4]  R2386     -0.645107090473175
    z[4,3,4]  R2387     -5.7966804504394531e-01
    z[4,3,4]  R2388     -5.1796585321426392e-01
    z[4,3,4]  R2389     -2.2337383031845093e-01
    z[4,3,4]  R2390     1.0597323998808861e-02
    z[4,3,4]  R2391     -3.5800719261169434e-01
    z[4,3,4]  R2392     -3.9284643530845642e-01
    z[4,3,4]  R2393     -5.3778970241546631e-01
    z[4,3,4]  R2394     1.9459785521030426e-01
    z[4,3,4]  R2395     1.0053319483995438e-01
    z[4,3,4]  R2396     -2.2989268600940704e-01
    z[4,3,4]  R2397     -2.9182881116867065e-01
    z[4,3,4]  R2398     -2.7246505022048950e-01
    z[4,3,4]  R2399     -4.6303052455186844e-02
    z[4,3,4]  R2400     -5.5385154485702515e-01
    z[4,3,4]  R2401     -3.7276622653007507e-01
    z[4,3,4]  R2402     -0.343077689409256
    z[4,3,4]  R2403     4.8305603861808777e-01
    z[4,3,4]  R2404     -1.0203192383050919e-01
    z[4,3,4]  R2405     -0.0925784781575203
    z[4,3,4]  R2406     -1.8663829565048218e-01
    z[4,3,4]  R2407     8.7267801165580750e-02
    z[4,3,4]  R2408     -2.6311576366424561e-01
    z[4,3,4]  R2409     1.6780454665422440e-02
    z[4,3,4]  R2410     2.5766485929489136e-01
    z[4,3,4]  R2411     7.5200520455837250e-02
    z[4,3,4]  R2412     4.6823222190141678e-02
    z[4,3,4]  R2413     5.6598985195159912e-01
    z[4,3,4]  R2414     -3.5769158601760864e-01
    z[4,3,4]  R2415     1.4069169759750366e-01
    z[4,3,4]  R2416     0.452584832906723
    z[4,3,4]  R2417     1.6116510331630707e-01
    z[4,3,4]  R2418     -3.5327225923538208e-01
    z[4,3,4]  R2419     3.8043644279241562e-02
    z[4,3,4]  R2420     -1.6989172995090485e-01
    z[4,3,4]  R2421     -1.8061298131942749e-01
    z[4,3,4]  R2422     -3.0069085955619812e-01
    z[4,3,4]  R2423     2.5757661461830139e-01
    z[4,3,4]  R2424     -3.4258410334587097e-01
    z[4,3,4]  R2425     0.00994244497269392
    z[4,3,4]  R2426     -1.0714717209339142e-01
    z[4,3,4]  R2427     1.4907805621623993e-01
    z[4,3,4]  R2428     4.5438849925994873e-01
    z[4,3,4]  R2429     8.5485167801380157e-02
    z[4,3,4]  R2430     -1.6078485175967216e-02
    z[4,3,4]  R2431     -4.3499547243118286e-01
    z[4,3,4]  R2432     -2.1023973822593689e-01
    z[4,3,4]  R2433     7.9031303524971008e-02
    z[4,3,4]  R2434     1.9675374031066895e-01
    z[4,3,4]  R2435     -2.6867267489433289e-01
    z[4,3,4]  R2436     1.1945463716983795e-02
    z[4,3,4]  R2437     -4.1314724087715149e-01
    z[4,3,4]  R2438     2.9950621537864208e-03
    z[4,3,4]  R2439     -9.5723450183868408e-02
    z[4,3,4]  R2440     -1.4593677222728729e-01
    z[4,3,4]  R2441     -2.2758300602436066e-01
    z[4,3,4]  R2442     -2.9370945692062378e-01
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R2309     -1
    z[4,3,5]  R2310     1
    z[4,3,5]  R2313     4.5455317944288254e-02
    z[4,3,5]  R2314     3.0921491980552673e-01
    z[4,3,5]  R2315     -2.7463287115097046e-01
    z[4,3,5]  R2316     2.4353665113449097e-01
    z[4,3,5]  R2317     -3.5344031453132629e-01
    z[4,3,5]  R2318     -8.5938408970832825e-02
    z[4,3,5]  R2319     3.4604495763778687e-01
    z[4,3,5]  R2320     -3.2464957237243652e-01
    z[4,3,5]  R2321     -2.0818535983562469e-01
    z[4,3,5]  R2322     -0.0650099441409111
    z[4,3,5]  R2323     -1.1607811599969864e-01
    z[4,3,5]  R2324     -2.1920476853847504e-01
    z[4,3,5]  R2325     0.0813726931810379
    z[4,3,5]  R2326     1.1889610439538956e-02
    z[4,3,5]  R2327     -1.5509258210659027e-01
    z[4,3,5]  R2328     3.3704373240470886e-01
    z[4,3,5]  R2329     -2.8847804665565491e-01
    z[4,3,5]  R2330     -5.0170928239822388e-01
    z[4,3,5]  R2331     -2.4494219571352005e-02
    z[4,3,5]  R2332     2.9188964515924454e-02
    z[4,3,5]  R2333     5.8514147996902466e-01
    z[4,3,5]  R2334     -2.4900746345520020e-01
    z[4,3,5]  R2335     -4.3281638622283936e-01
    z[4,3,5]  R2336     -1.5920111536979675e-01
    z[4,3,5]  R2337     -3.0305919051170349e-01
    z[4,3,5]  R2338     1.8946048617362976e-01
    z[4,3,5]  R2339     9.4566307961940765e-02
    z[4,3,5]  R2340     -2.8468701243400574e-01
    z[4,3,5]  R2341     1.9625541567802429e-01
    z[4,3,5]  R2342     2.4141949415206909e-01
    z[4,3,5]  R2343     6.0804599523544312e-01
    z[4,3,5]  R2344     4.3281927704811096e-02
    z[4,3,5]  R2345     -3.9834147691726685e-01
    z[4,3,5]  R2346     2.0585153996944427e-01
    z[4,3,5]  R2347     -0.155070960521698
    z[4,3,5]  R2348     2.3658762872219086e-01
    z[4,3,5]  R2349     1.8496681749820709e-01
    z[4,3,5]  R2350     -0.0867081880569458
    z[4,3,5]  R2351     -2.5477465987205505e-01
    z[4,3,5]  R2352     -1.9850549101829529e-01
    z[4,3,5]  R2353     -4.3386217951774597e-01
    z[4,3,5]  R2354     -2.1251513063907623e-01
    z[4,3,5]  R2355     -5.0445652008056641e-01
    z[4,3,5]  R2356     -7.6856710016727448e-02
    z[4,3,5]  R2357     -1.6088853776454926e-01
    z[4,3,5]  R2358     2.5028528645634651e-02
    z[4,3,5]  R2359     0.348357617855072
    z[4,3,5]  R2360     -3.7620836496353149e-01
    z[4,3,5]  R2361     -3.0073845386505127e-01
    z[4,3,5]  R2362     -1.9433495402336121e-01
    z[4,3,5]  R2363     3.8035976886749268e-01
    z[4,3,5]  R2364     -4.6719394624233246e-02
    z[4,3,5]  R2365     6.0069918632507324e-01
    z[4,3,5]  R2366     1.8863563239574432e-01
    z[4,3,5]  R2367     4.0948572754859924e-01
    z[4,3,5]  R2368     1.7991185188293457e-01
    z[4,3,5]  R2369     0.0920541062951088
    z[4,3,5]  R2370     1.2588837742805481e-01
    z[4,3,5]  R2371     4.7277545928955078e-01
    z[4,3,5]  R2372     5.9156739711761475e-01
    z[4,3,5]  R2373     -2.3151063919067383e-01
    z[4,3,5]  R2374     0.457425594329834
    z[4,3,5]  R2375     2.0204125344753265e-01
    z[4,3,5]  R2376     0.598791241645813
    z[4,3,5]  R2377     -2.3754674196243286e-01
    z[4,3,5]  R2378     4.9399951100349426e-01
    z[4,3,5]  R2379     3.6819356679916382e-01
    z[4,3,5]  R2380     2.2365932166576385e-01
    z[4,3,5]  R2381     1.4212416112422943e-01
    z[4,3,5]  R2382     -6.7222595214843750e-02
    z[4,3,5]  R2383     -2.0196711644530296e-02
    z[4,3,5]  R2384     -4.8286926001310349e-02
    z[4,3,5]  R2385     -1.3389208912849426e-01
    z[4,3,5]  R2386     2.1183808147907257e-01
    z[4,3,5]  R2387     8.8243380188941956e-02
    z[4,3,5]  R2388     1.2243386358022690e-01
    z[4,3,5]  R2389     2.9019605368375778e-02
    z[4,3,5]  R2390     1.3056750595569611e-01
    z[4,3,5]  R2391     -1.7010171711444855e-01
    z[4,3,5]  R2392     -3.9907835423946381e-02
    z[4,3,5]  R2393     1.8827447667717934e-02
    z[4,3,5]  R2394     -1.8242919445037842e-01
    z[4,3,5]  R2395     -4.0729236602783203e-01
    z[4,3,5]  R2396     1.6880555450916290e-01
    z[4,3,5]  R2397     -4.3299937248229980e-01
    z[4,3,5]  R2398     -3.3952260017395020e-01
    z[4,3,5]  R2399     3.7518686056137085e-01
    z[4,3,5]  R2400     -1.9954627752304077e-01
    z[4,3,5]  R2401     -3.0268070101737976e-01
    z[4,3,5]  R2402     2.9153221845626831e-01
    z[4,3,5]  R2403     1.7578034102916718e-01
    z[4,3,5]  R2404     1.4103178679943085e-01
    z[4,3,5]  R2405     -4.5463374257087708e-01
    z[4,3,5]  R2406     5.9324383735656738e-02
    z[4,3,5]  R2407     -1.2676222622394562e-01
    z[4,3,5]  R2408     5.3338032215833664e-02
    z[4,3,5]  R2409     -8.9633306488394737e-03
    z[4,3,5]  R2410     4.0861195325851440e-01
    z[4,3,5]  R2411     -7.8010559082031250e-02
    z[4,3,5]  R2412     -2.3163343966007233e-01
    z[4,3,5]  R2413     0.273774117231369
    z[4,3,5]  R2414     -5.2762970328330994e-02
    z[4,3,5]  R2415     2.3675620555877686e-01
    z[4,3,5]  R2416     2.2943376004695892e-01
    z[4,3,5]  R2417     7.5764514505863190e-02
    z[4,3,5]  R2418     1.8387521803379059e-01
    z[4,3,5]  R2419     -2.7558884024620056e-01
    z[4,3,5]  R2420     5.9021270275115967e-01
    z[4,3,5]  R2421     2.2301357984542847e-01
    z[4,3,5]  R2422     -7.0829652249813080e-02
    z[4,3,5]  R2423     1.4459949731826782e-01
    z[4,3,5]  R2424     1.5825821086764336e-02
    z[4,3,5]  R2425     3.1916475296020508e-01
    z[4,3,5]  R2426     4.4475227594375610e-01
    z[4,3,5]  R2427     -4.2168667912483215e-01
    z[4,3,5]  R2428     -2.6205161213874817e-01
    z[4,3,5]  R2429     1.1747315526008606e-02
    z[4,3,5]  R2430     -3.8046085834503174e-01
    z[4,3,5]  R2431     -3.9427403360605240e-02
    z[4,3,5]  R2432     2.6306691765785217e-01
    z[4,3,5]  R2433     -1.9467723369598389e-01
    z[4,3,5]  R2434     2.1556799113750458e-01
    z[4,3,5]  R2435     -2.4909430742263794e-01
    z[4,3,5]  R2436     -3.0473336577415466e-01
    z[4,3,5]  R2437     4.8819732666015625e-01
    z[4,3,5]  R2438     -2.2189967334270477e-01
    z[4,3,5]  R2439     -6.8342939019203186e-02
    z[4,3,5]  R2440     3.0620506405830383e-01
    z[4,3,5]  R2441     1.1011601239442825e-01
    z[4,3,5]  R2442     -2.7557021379470825e-01
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R2311     -1
    z[4,3,6]  R2312     1
    z[4,3,6]  R2313     -0.210738867521286
    z[4,3,6]  R2314     -3.1171094626188278e-02
    z[4,3,6]  R2315     2.2929438948631287e-01
    z[4,3,6]  R2316     5.0909918546676636e-01
    z[4,3,6]  R2317     1.2369374930858612e-01
    z[4,3,6]  R2318     -7.8863966464996338e-01
    z[4,3,6]  R2319     -3.7255835533142090e-01
    z[4,3,6]  R2320     -0.0744401067495346
    z[4,3,6]  R2321     -1.5316693484783173e-01
    z[4,3,6]  R2322     -3.9936131797730923e-03
    z[4,3,6]  R2323     3.4250393509864807e-01
    z[4,3,6]  R2324     6.0241949558258057e-01
    z[4,3,6]  R2325     4.5875120162963867e-01
    z[4,3,6]  R2326     3.3511921763420105e-01
    z[4,3,6]  R2327     1.8250516057014465e-01
    z[4,3,6]  R2328     -1.4824721217155457e-01
    z[4,3,6]  R2329     -6.0037189722061157e-01
    z[4,3,6]  R2330     -4.3797045946121216e-01
    z[4,3,6]  R2331     -5.0236219167709351e-01
    z[4,3,6]  R2332     -4.6849304437637329e-01
    z[4,3,6]  R2333     -3.2818296551704407e-01
    z[4,3,6]  R2334     1.7228440940380096e-01
    z[4,3,6]  R2335     1.8132114410400391e-01
    z[4,3,6]  R2336     -3.5852468013763428e-01
    z[4,3,6]  R2337     -3.9278939366340637e-01
    z[4,3,6]  R2338     -3.9323008060455322e-01
    z[4,3,6]  R2339     -4.7162118554115295e-01
    z[4,3,6]  R2340     -3.8046449422836304e-01
    z[4,3,6]  R2341     -2.3921951651573181e-02
    z[4,3,6]  R2342     -2.5964441895484924e-01
    z[4,3,6]  R2343     -1.0932006686925888e-01
    z[4,3,6]  R2344     -7.2604125738143921e-01
    z[4,3,6]  R2345     -1.5151165425777435e-01
    z[4,3,6]  R2346     -2.5049192830920219e-02
    z[4,3,6]  R2347     -1.7614869773387909e-01
    z[4,3,6]  R2348     -8.9096657931804657e-02
    z[4,3,6]  R2349     -2.1664224565029144e-01
    z[4,3,6]  R2350     -1.5606154501438141e-01
    z[4,3,6]  R2351     8.1897906959056854e-02
    z[4,3,6]  R2352     5.6511354446411133e-01
    z[4,3,6]  R2353     3.2224437594413757e-01
    z[4,3,6]  R2354     3.2228657603263855e-01
    z[4,3,6]  R2355     1.8866769969463348e-01
    z[4,3,6]  R2356     -4.9333442002534866e-02
    z[4,3,6]  R2357     -0.0901155099272728
    z[4,3,6]  R2358     0.395723819732666
    z[4,3,6]  R2359     -5.4834973812103271e-01
    z[4,3,6]  R2360     8.3916939795017242e-02
    z[4,3,6]  R2361     1.7447138205170631e-02
    z[4,3,6]  R2362     -7.4526853859424591e-02
    z[4,3,6]  R2363     -6.3740599155426025e-01
    z[4,3,6]  R2364     0.441743403673172
    z[4,3,6]  R2365     -4.3122348189353943e-01
    z[4,3,6]  R2366     -1.4081505127251148e-02
    z[4,3,6]  R2367     -1.4989298582077026e-01
    z[4,3,6]  R2368     3.9437824487686157e-01
    z[4,3,6]  R2369     3.5007354617118835e-01
    z[4,3,6]  R2370     2.1143538877367973e-02
    z[4,3,6]  R2371     1.4839254319667816e-02
    z[4,3,6]  R2372     2.5452831387519836e-01
    z[4,3,6]  R2373     -1.6930031776428223e-01
    z[4,3,6]  R2374     -4.4117712974548340e-01
    z[4,3,6]  R2375     4.8542764782905579e-01
    z[4,3,6]  R2376     1.9095657765865326e-01
    z[4,3,6]  R2377     -2.2461685538291931e-01
    z[4,3,6]  R2378     -7.7713549137115479e-02
    z[4,3,6]  R2379     4.4267535209655762e-01
    z[4,3,6]  R2380     1.3879722356796265e-01
    z[4,3,6]  R2381     -1.3862450420856476e-01
    z[4,3,6]  R2382     -1.2953819334506989e-01
    z[4,3,6]  R2383     2.0793128013610840e-01
    z[4,3,6]  R2384     5.6596368551254272e-02
    z[4,3,6]  R2385     6.0966953635215759e-02
    z[4,3,6]  R2386     -4.5595744252204895e-01
    z[4,3,6]  R2387     -4.7271448373794556e-01
    z[4,3,6]  R2388     3.4640945494174957e-02
    z[4,3,6]  R2389     1.9651544094085693e-01
    z[4,3,6]  R2390     2.3814779520034790e-01
    z[4,3,6]  R2391     -3.2557934522628784e-01
    z[4,3,6]  R2392     -4.1531622409820557e-02
    z[4,3,6]  R2393     -1.8709658086299896e-01
    z[4,3,6]  R2394     1.7484484612941742e-01
    z[4,3,6]  R2395     3.7786448001861572e-01
    z[4,3,6]  R2396     -3.1138148903846741e-01
    z[4,3,6]  R2397     -1.9536325708031654e-03
    z[4,3,6]  R2398     -3.1438705325126648e-01
    z[4,3,6]  R2399     4.4407594203948975e-01
    z[4,3,6]  R2400     0.00967728067189455
    z[4,3,6]  R2401     2.8715759515762329e-01
    z[4,3,6]  R2402     -1.4299340546131134e-01
    z[4,3,6]  R2403     -2.4260684847831726e-02
    z[4,3,6]  R2404     4.2003687471151352e-02
    z[4,3,6]  R2405     2.5526729226112366e-01
    z[4,3,6]  R2406     4.4603681564331055e-01
    z[4,3,6]  R2407     3.3880195021629333e-01
    z[4,3,6]  R2408     -3.7438246607780457e-01
    z[4,3,6]  R2409     -4.9122944474220276e-01
    z[4,3,6]  R2410     5.3314030170440674e-01
    z[4,3,6]  R2411     -3.0161604285240173e-01
    z[4,3,6]  R2412     1.4251299202442169e-01
    z[4,3,6]  R2413     -9.3784462660551071e-03
    z[4,3,6]  R2414     -1.4829332008957863e-02
    z[4,3,6]  R2415     -4.6136882901191711e-01
    z[4,3,6]  R2416     -1.3811211287975311e-01
    z[4,3,6]  R2417     1.1487468332052231e-01
    z[4,3,6]  R2418     1.3688622973859310e-02
    z[4,3,6]  R2419     -5.4443454742431641e-01
    z[4,3,6]  R2420     2.2189514338970184e-01
    z[4,3,6]  R2421     -2.5713866949081421e-01
    z[4,3,6]  R2422     1.9530370831489563e-02
    z[4,3,6]  R2423     3.9185574650764465e-01
    z[4,3,6]  R2424     -5.6224983185529709e-02
    z[4,3,6]  R2425     -2.7617835998535156e-01
    z[4,3,6]  R2426     -1.0886877775192261e-01
    z[4,3,6]  R2427     1.6325150430202484e-01
    z[4,3,6]  R2428     -3.6671221256256104e-01
    z[4,3,6]  R2429     1.9295718520879745e-02
    z[4,3,6]  R2430     0.280496209859848
    z[4,3,6]  R2431     3.5179728269577026e-01
    z[4,3,6]  R2432     3.4558865427970886e-01
    z[4,3,6]  R2433     1.1742081493139267e-01
    z[4,3,6]  R2434     -2.6539623737335205e-01
    z[4,3,6]  R2435     2.7670052647590637e-01
    z[4,3,6]  R2436     3.8323320448398590e-02
    z[4,3,6]  R2437     6.8560346961021423e-02
    z[4,3,6]  R2438     -2.5408580899238586e-01
    z[4,3,6]  R2439     -4.8990118503570557e-01
    z[4,3,6]  R2440     2.3935526609420776e-01
    z[4,3,6]  R2441     -6.3910400867462158e-01
    z[4,3,6]  R2442     1.3189865648746490e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R45       1
    RHS1      R46       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,3]
 BV BND1      phi[3,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[5,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,3]
 BV BND1      phi[3,1]
 BV BND1      phi[1,4]
 BV BND1      phi[4,1]
 BV BND1      phi[2,4]
 BV BND1      phi[4,2]
 BV BND1      phi[2,6]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[5,3]
 BV BND1      phi[4,6]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,3,0]
 FR BND1      z[0,3,1]
 FR BND1      z[0,3,2]
 FR BND1      z[0,3,3]
 FR BND1      z[0,3,4]
 FR BND1      z[0,3,5]
 FR BND1      z[0,3,6]
 FR BND1      z[3,0,0]
 FR BND1      z[3,0,1]
 FR BND1      z[3,0,2]
 FR BND1      z[3,0,3]
 FR BND1      z[3,0,4]
 FR BND1      z[3,0,5]
 FR BND1      z[3,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,3,0]
 FR BND1      z[1,3,1]
 FR BND1      z[1,3,2]
 FR BND1      z[1,3,3]
 FR BND1      z[1,3,4]
 FR BND1      z[1,3,5]
 FR BND1      z[1,3,6]
 FR BND1      z[3,1,0]
 FR BND1      z[3,1,1]
 FR BND1      z[3,1,2]
 FR BND1      z[3,1,3]
 FR BND1      z[3,1,4]
 FR BND1      z[3,1,5]
 FR BND1      z[3,1,6]
 FR BND1      z[1,4,0]
 FR BND1      z[1,4,1]
 FR BND1      z[1,4,2]
 FR BND1      z[1,4,3]
 FR BND1      z[1,4,4]
 FR BND1      z[1,4,5]
 FR BND1      z[1,4,6]
 FR BND1      z[4,1,0]
 FR BND1      z[4,1,1]
 FR BND1      z[4,1,2]
 FR BND1      z[4,1,3]
 FR BND1      z[4,1,4]
 FR BND1      z[4,1,5]
 FR BND1      z[4,1,6]
 FR BND1      z[2,4,0]
 FR BND1      z[2,4,1]
 FR BND1      z[2,4,2]
 FR BND1      z[2,4,3]
 FR BND1      z[2,4,4]
 FR BND1      z[2,4,5]
 FR BND1      z[2,4,6]
 FR BND1      z[4,2,0]
 FR BND1      z[4,2,1]
 FR BND1      z[4,2,2]
 FR BND1      z[4,2,3]
 FR BND1      z[4,2,4]
 FR BND1      z[4,2,5]
 FR BND1      z[4,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
ENDATA
