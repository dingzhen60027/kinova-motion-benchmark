NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 E  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R74       -3.0999999046325684e+00
    phi[0,1]  R75       -3.0999999046325684e+00
    phi[0,1]  R76       -2.2400000095367432e+00
    phi[0,1]  R77       -2.2400000095367432e+00
    phi[0,1]  R78       -3.0999999046325684e+00
    phi[0,1]  R79       -3.0999999046325684e+00
    phi[0,1]  R80       -2.5699999332427979e+00
    phi[0,1]  R81       -2.5699999332427979e+00
    phi[0,1]  R82       -3.0999999046325684e+00
    phi[0,1]  R83       -3.0999999046325684e+00
    phi[0,1]  R84       -2.0899999141693115e+00
    phi[0,1]  R85       -2.0899999141693115e+00
    phi[0,1]  R86       -3.0999999046325684e+00
    phi[0,1]  R87       -3.0999999046325684e+00
    phi[0,1]  R88       -1.6772496700286865e-01
    phi[0,1]  R89       -9.0786427259445190e-02
    phi[0,1]  R90       -3.8896876573562622e-01
    phi[0,1]  R91       -8.8517028093338013e-01
    phi[0,1]  R92       -7.0173645019531250e-01
    phi[0,1]  R93       -1.4042408764362335e-01
    phi[0,1]  R94       -3.8958325982093811e-02
    phi[0,1]  R95       -1.1238474398851395e-01
    phi[0,1]  R96       -6.3583290576934814e-01
    phi[0,1]  R97       -6.9769442081451416e-01
    phi[0,1]  R98       -3.1658071279525757e-01
    phi[0,1]  R99       -1.2392506599426270e+00
    phi[0,1]  R100      -1.4163167476654053e+00
    phi[0,1]  R101      -1.9400584697723389e+00
    phi[0,1]  R102      -1.5298696756362915e+00
    phi[0,1]  R103      -2.5756542682647705e+00
    phi[0,1]  R104      -4.9493527412414551e-01
    phi[0,1]  R105      -1.7800240516662598e+00
    phi[0,1]  R106      -7.3697805404663086e-01
    phi[0,1]  R107      -1.3387553691864014e+00
    phi[0,1]  R108      -1.5350072383880615e+00
    phi[0,1]  R109      -1.7462124824523926e+00
    phi[0,1]  R110      -5.1989829540252686e-01
    phi[0,1]  R111      -3.7029820680618286e-01
    phi[0,1]  R112      9.3442851305007935e-01
    phi[0,1]  R113      9.3295753002166748e-01
    phi[0,1]  R114      1.3005604743957520e+00
    phi[0,1]  R115      1.1670202016830444e+00
    phi[0,1]  R116      1.1655584573745728e+00
    phi[0,1]  R117      -6.4660519361495972e-02
    phi[0,1]  R118      9.9162536859512329e-01
    phi[0,1]  R119      6.5581315755844116e-01
    phi[0,1]  R120      -2.3044865131378174e+00
    phi[0,1]  R121      -1.3068441152572632e+00
    phi[0,1]  R122      -2.7989938259124756e+00
    phi[0,1]  R123      -2.1607112884521484e+00
    phi[0,1]  R124      -2.3678085803985596e+00
    phi[0,1]  R125      -2.0446910858154297e+00
    phi[0,1]  R126      -2.4878146648406982e+00
    phi[0,1]  R127      -2.2375507354736328e+00
    phi[0,1]  R128      -1.8481643199920654e+00
    phi[0,1]  R129      -2.6088402271270752e+00
    phi[0,1]  R130      -1.8283008337020874e+00
    phi[0,1]  R131      -2.3509142398834229e+00
    phi[0,1]  R132      -1.7426745891571045e+00
    phi[0,1]  R133      -1.2259695529937744e+00
    phi[0,1]  R134      -1.9445769786834717e+00
    phi[0,1]  R135      -9.0324610471725464e-01
    phi[0,1]  R136      -1.7424603700637817e+00
    phi[0,1]  R137      -2.0823767185211182e+00
    phi[0,1]  R138      -2.3388597965240479e+00
    phi[0,1]  R139      -2.2149832248687744e+00
    phi[0,1]  R140      -2.24546480178833
    phi[0,1]  R141      -2.0764245986938477e+00
    phi[0,1]  R142      -1.4370425939559937e+00
    phi[0,1]  R143      -1.7970991134643555e+00
    phi[0,1]  R144      -1.7371408939361572e+00
    phi[0,1]  R145      -2.1368513107299805e+00
    phi[0,1]  R146      1.3440409302711487e-01
    phi[0,1]  R147      -1.4192200899124146e+00
    phi[0,1]  R148      -1.1024714708328247e+00
    phi[0,1]  R149      -8.2411026954650879e-01
    phi[0,1]  R150      -2.4732048511505127e+00
    phi[0,1]  R151      -1.9318507909774780e+00
    phi[0,1]  R152      -2.2998552322387695e+00
    phi[0,1]  R153      -1.7492371797561646e+00
    phi[0,1]  R154      -1.8323068618774414e+00
    phi[0,1]  R155      -1.8214393854141235e+00
    phi[0,1]  R156      -2.1764872074127197e+00
    phi[0,1]  R157      -1.9425952434539795e+00
    phi[0,1]  R158      -1.9991881847381592e+00
    phi[0,1]  R159      -1.2701107263565063e+00
    phi[0,1]  R160      -1.8041920661926270e+00
    phi[0,1]  R161      -1.5329240560531616e+00
    phi[0,1]  R162      -1.8515257835388184e+00
    phi[0,1]  R163      -2.5192139148712158e+00
    phi[0,1]  R164      -2.1892571449279785e+00
    phi[0,1]  R165      -1.8282463550567627e+00
    phi[0,1]  R166      -2.0184276103973389e+00
    phi[0,1]  R167      -0.801401674747467
    phi[0,1]  R168      -2.2163441181182861e+00
    phi[0,1]  R169      -2.7005395889282227e+00
    phi[0,1]  R170      -2.5229551792144775e+00
    phi[0,1]  R171      -2.2810223102569580e+00
    phi[0,1]  R172      -2.1100912094116211e+00
    phi[0,1]  R173      -2.1076126098632812e+00
    phi[0,1]  R174      -1.8788367509841919e+00
    phi[0,1]  R175      -9.0065437555313110e-01
    phi[0,1]  R176      -1.1431838274002075e+00
    phi[0,1]  R177      -9.8384010791778564e-01
    phi[0,1]  R178      -1.9644778966903687e+00
    phi[0,1]  R179      -1.7368308305740356e+00
    phi[0,1]  R180      -1.9001498222351074e+00
    phi[0,1]  R181      -1.7372353076934814e+00
    phi[0,1]  R182      -1.5661683082580566e+00
    phi[0,1]  R183      -1.8038169145584106e+00
    phi[0,1]  R184      -1.0773172378540039e+00
    phi[0,1]  R185      -5.6647367775440216e-02
    phi[0,1]  R186      -1.3675509691238403e+00
    phi[0,1]  R187      -0.354666143655777
    phi[0,1]  R188      -1.6780707836151123e+00
    phi[0,1]  R189      -1.7840765714645386e+00
    phi[0,1]  R190      -2.1679589748382568e+00
    phi[0,1]  R191      -1.5979975461959839e+00
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R192      -3.0999999046325684e+00
    phi[1,0]  R193      -3.0999999046325684e+00
    phi[1,0]  R194      -2.2400000095367432e+00
    phi[1,0]  R195      -2.2400000095367432e+00
    phi[1,0]  R196      -3.0999999046325684e+00
    phi[1,0]  R197      -3.0999999046325684e+00
    phi[1,0]  R198      -2.5699999332427979e+00
    phi[1,0]  R199      -2.5699999332427979e+00
    phi[1,0]  R200      -3.0999999046325684e+00
    phi[1,0]  R201      -3.0999999046325684e+00
    phi[1,0]  R202      -2.0899999141693115e+00
    phi[1,0]  R203      -2.0899999141693115e+00
    phi[1,0]  R204      -3.0999999046325684e+00
    phi[1,0]  R205      -3.0999999046325684e+00
    phi[1,0]  R206      9.3442851305007935e-01
    phi[1,0]  R207      9.3295753002166748e-01
    phi[1,0]  R208      1.3005604743957520e+00
    phi[1,0]  R209      1.1670202016830444e+00
    phi[1,0]  R210      1.1655584573745728e+00
    phi[1,0]  R211      -6.4660519361495972e-02
    phi[1,0]  R212      9.9162536859512329e-01
    phi[1,0]  R213      6.5581315755844116e-01
    phi[1,0]  R214      -2.3044865131378174e+00
    phi[1,0]  R215      -1.3068441152572632e+00
    phi[1,0]  R216      -2.7989938259124756e+00
    phi[1,0]  R217      -2.1607112884521484e+00
    phi[1,0]  R218      -2.3678085803985596e+00
    phi[1,0]  R219      -2.0446910858154297e+00
    phi[1,0]  R220      -2.4878146648406982e+00
    phi[1,0]  R221      -2.2375507354736328e+00
    phi[1,0]  R222      -1.8481643199920654e+00
    phi[1,0]  R223      -2.6088402271270752e+00
    phi[1,0]  R224      -1.8283008337020874e+00
    phi[1,0]  R225      -2.3509142398834229e+00
    phi[1,0]  R226      -1.7426745891571045e+00
    phi[1,0]  R227      -1.2259695529937744e+00
    phi[1,0]  R228      -1.9445769786834717e+00
    phi[1,0]  R229      -9.0324610471725464e-01
    phi[1,0]  R230      -1.7424603700637817e+00
    phi[1,0]  R231      -2.0823767185211182e+00
    phi[1,0]  R232      -2.3388597965240479e+00
    phi[1,0]  R233      -2.2149832248687744e+00
    phi[1,0]  R234      -2.24546480178833
    phi[1,0]  R235      -2.0764245986938477e+00
    phi[1,0]  R236      -1.4370425939559937e+00
    phi[1,0]  R237      -1.7970991134643555e+00
    phi[1,0]  R238      -1.7371408939361572e+00
    phi[1,0]  R239      -2.1368513107299805e+00
    phi[1,0]  R240      1.3440409302711487e-01
    phi[1,0]  R241      -1.4192200899124146e+00
    phi[1,0]  R242      -1.1024714708328247e+00
    phi[1,0]  R243      -8.2411026954650879e-01
    phi[1,0]  R244      -2.4732048511505127e+00
    phi[1,0]  R245      -1.9318507909774780e+00
    phi[1,0]  R246      -2.2998552322387695e+00
    phi[1,0]  R247      -1.7492371797561646e+00
    phi[1,0]  R248      -1.8323068618774414e+00
    phi[1,0]  R249      -1.8214393854141235e+00
    phi[1,0]  R250      -2.1764872074127197e+00
    phi[1,0]  R251      -1.9425952434539795e+00
    phi[1,0]  R252      -1.9991881847381592e+00
    phi[1,0]  R253      -1.2701107263565063e+00
    phi[1,0]  R254      -1.8041920661926270e+00
    phi[1,0]  R255      -1.5329240560531616e+00
    phi[1,0]  R256      -1.8515257835388184e+00
    phi[1,0]  R257      -2.5192139148712158e+00
    phi[1,0]  R258      -2.1892571449279785e+00
    phi[1,0]  R259      -1.8282463550567627e+00
    phi[1,0]  R260      -2.0184276103973389e+00
    phi[1,0]  R261      -0.801401674747467
    phi[1,0]  R262      -2.2163441181182861e+00
    phi[1,0]  R263      -2.7005395889282227e+00
    phi[1,0]  R264      -2.5229551792144775e+00
    phi[1,0]  R265      -2.2810223102569580e+00
    phi[1,0]  R266      -2.1100912094116211e+00
    phi[1,0]  R267      -2.1076126098632812e+00
    phi[1,0]  R268      -1.8788367509841919e+00
    phi[1,0]  R269      -9.0065437555313110e-01
    phi[1,0]  R270      -1.1431838274002075e+00
    phi[1,0]  R271      -9.8384010791778564e-01
    phi[1,0]  R272      -1.9644778966903687e+00
    phi[1,0]  R273      -1.7368308305740356e+00
    phi[1,0]  R274      -1.9001498222351074e+00
    phi[1,0]  R275      -1.7372353076934814e+00
    phi[1,0]  R276      -1.5661683082580566e+00
    phi[1,0]  R277      -1.8038169145584106e+00
    phi[1,0]  R278      -1.0773172378540039e+00
    phi[1,0]  R279      -5.6647367775440216e-02
    phi[1,0]  R280      -1.3675509691238403e+00
    phi[1,0]  R281      -0.354666143655777
    phi[1,0]  R282      -1.6780707836151123e+00
    phi[1,0]  R283      -1.7840765714645386e+00
    phi[1,0]  R284      -2.1679589748382568e+00
    phi[1,0]  R285      -1.5979975461959839e+00
    phi[1,0]  R286      -1.6772496700286865e-01
    phi[1,0]  R287      -9.0786427259445190e-02
    phi[1,0]  R288      -3.8896876573562622e-01
    phi[1,0]  R289      -8.8517028093338013e-01
    phi[1,0]  R290      -7.0173645019531250e-01
    phi[1,0]  R291      -1.4042408764362335e-01
    phi[1,0]  R292      -3.8958325982093811e-02
    phi[1,0]  R293      -1.1238474398851395e-01
    phi[1,0]  R294      -6.3583290576934814e-01
    phi[1,0]  R295      -6.9769442081451416e-01
    phi[1,0]  R296      -3.1658071279525757e-01
    phi[1,0]  R297      -1.2392506599426270e+00
    phi[1,0]  R298      -1.4163167476654053e+00
    phi[1,0]  R299      -1.9400584697723389e+00
    phi[1,0]  R300      -1.5298696756362915e+00
    phi[1,0]  R301      -2.5756542682647705e+00
    phi[1,0]  R302      -4.9493527412414551e-01
    phi[1,0]  R303      -1.7800240516662598e+00
    phi[1,0]  R304      -7.3697805404663086e-01
    phi[1,0]  R305      -1.3387553691864014e+00
    phi[1,0]  R306      -1.5350072383880615e+00
    phi[1,0]  R307      -1.7462124824523926e+00
    phi[1,0]  R308      -5.1989829540252686e-01
    phi[1,0]  R309      -3.7029820680618286e-01
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R310      -3.0999999046325684e+00
    phi[0,4]  R311      -3.0999999046325684e+00
    phi[0,4]  R312      -2.2400000095367432e+00
    phi[0,4]  R313      -2.2400000095367432e+00
    phi[0,4]  R314      -3.0999999046325684e+00
    phi[0,4]  R315      -3.0999999046325684e+00
    phi[0,4]  R316      -2.5699999332427979e+00
    phi[0,4]  R317      -2.5699999332427979e+00
    phi[0,4]  R318      -3.0999999046325684e+00
    phi[0,4]  R319      -3.0999999046325684e+00
    phi[0,4]  R320      -2.0899999141693115e+00
    phi[0,4]  R321      -2.0899999141693115e+00
    phi[0,4]  R322      -3.0999999046325684e+00
    phi[0,4]  R323      -3.0999999046325684e+00
    phi[0,4]  R324      -1.6772496700286865e-01
    phi[0,4]  R325      -9.0786427259445190e-02
    phi[0,4]  R326      -3.8896876573562622e-01
    phi[0,4]  R327      -8.8517028093338013e-01
    phi[0,4]  R328      -7.0173645019531250e-01
    phi[0,4]  R329      -1.4042408764362335e-01
    phi[0,4]  R330      -3.8958325982093811e-02
    phi[0,4]  R331      -1.1238474398851395e-01
    phi[0,4]  R332      -6.3583290576934814e-01
    phi[0,4]  R333      -6.9769442081451416e-01
    phi[0,4]  R334      -3.1658071279525757e-01
    phi[0,4]  R335      -1.2392506599426270e+00
    phi[0,4]  R336      -1.4163167476654053e+00
    phi[0,4]  R337      -1.9400584697723389e+00
    phi[0,4]  R338      -1.5298696756362915e+00
    phi[0,4]  R339      -2.5756542682647705e+00
    phi[0,4]  R340      -4.9493527412414551e-01
    phi[0,4]  R341      -1.7800240516662598e+00
    phi[0,4]  R342      -7.3697805404663086e-01
    phi[0,4]  R343      -1.3387553691864014e+00
    phi[0,4]  R344      -1.5350072383880615e+00
    phi[0,4]  R345      -1.7462124824523926e+00
    phi[0,4]  R346      -5.1989829540252686e-01
    phi[0,4]  R347      -3.7029820680618286e-01
    phi[0,4]  R348      -5.6884795427322388e-02
    phi[0,4]  R349      -1.9323083758354187e-01
    phi[0,4]  R350      -2.0056156814098358e-01
    phi[0,4]  R351      -8.9799559116363525e-01
    phi[0,4]  R352      2.6325362920761108e-01
    phi[0,4]  R353      -5.1581519842147827e-01
    phi[0,4]  R354      1.2389839887619019e+00
    phi[0,4]  R355      1.4614419937133789e+00
    phi[0,4]  R356      6.8499112129211426e-01
    phi[0,4]  R357      7.0938414335250854e-01
    phi[0,4]  R358      -2.22904896736145
    phi[0,4]  R359      9.0911462903022766e-02
    phi[0,4]  R360      -1.4017367362976074e-01
    phi[0,4]  R361      -3.1433299183845520e-01
    phi[0,4]  R362      -3.2254987955093384e-01
    phi[0,4]  R363      -7.7929389476776123e-01
    phi[0,4]  R364      -5.9074580669403076e-01
    phi[0,4]  R365      -1.0175893306732178e+00
    phi[0,4]  R366      -0.682853639125824
    phi[0,4]  R367      -1.8663799762725830e+00
    phi[0,4]  R368      -2.1879997253417969e+00
    phi[0,4]  R369      -1.3612687587738037e+00
    phi[0,4]  R370      -1.9356726408004761e+00
    phi[0,4]  R371      -1.21638023853302
    phi[0,4]  R372      -1.2458598613739014e+00
    phi[0,4]  R373      -1.5418606996536255e+00
    phi[0,4]  R374      -1.8713152408599854e+00
    phi[0,4]  R375      8.5599708557128906e-01
    phi[0,4]  R376      -1.9824496507644653e+00
    phi[0,4]  R377      -1.5525444746017456e+00
    phi[0,4]  R378      1.0850021839141846e+00
    phi[0,4]  R379      1.9518168270587921e-01
    phi[0,4]  R380      -1.8627785444259644e+00
    phi[0,4]  R381      -1.8236312270164490e-01
    phi[0,4]  R382      -5.4143965244293213e-01
    phi[0,4]  R383      -2.4229078292846680e+00
    phi[0,4]  R384      -6.4661078155040741e-02
    phi[0,4]  R385      -1.14437997341156
    phi[0,4]  R386      -5.3692591190338135e-01
    phi[0,4]  R387      -1.3064095973968506e+00
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R388      -3.0999999046325684e+00
    phi[4,0]  R389      -3.0999999046325684e+00
    phi[4,0]  R390      -2.2400000095367432e+00
    phi[4,0]  R391      -2.2400000095367432e+00
    phi[4,0]  R392      -3.0999999046325684e+00
    phi[4,0]  R393      -3.0999999046325684e+00
    phi[4,0]  R394      -2.5699999332427979e+00
    phi[4,0]  R395      -2.5699999332427979e+00
    phi[4,0]  R396      -3.0999999046325684e+00
    phi[4,0]  R397      -3.0999999046325684e+00
    phi[4,0]  R398      -2.0899999141693115e+00
    phi[4,0]  R399      -2.0899999141693115e+00
    phi[4,0]  R400      -3.0999999046325684e+00
    phi[4,0]  R401      -3.0999999046325684e+00
    phi[4,0]  R402      -5.6884795427322388e-02
    phi[4,0]  R403      -1.9323083758354187e-01
    phi[4,0]  R404      -2.0056156814098358e-01
    phi[4,0]  R405      -8.9799559116363525e-01
    phi[4,0]  R406      2.6325362920761108e-01
    phi[4,0]  R407      -5.1581519842147827e-01
    phi[4,0]  R408      1.2389839887619019e+00
    phi[4,0]  R409      1.4614419937133789e+00
    phi[4,0]  R410      6.8499112129211426e-01
    phi[4,0]  R411      7.0938414335250854e-01
    phi[4,0]  R412      -2.22904896736145
    phi[4,0]  R413      9.0911462903022766e-02
    phi[4,0]  R414      -1.4017367362976074e-01
    phi[4,0]  R415      -3.1433299183845520e-01
    phi[4,0]  R416      -3.2254987955093384e-01
    phi[4,0]  R417      -7.7929389476776123e-01
    phi[4,0]  R418      -5.9074580669403076e-01
    phi[4,0]  R419      -1.0175893306732178e+00
    phi[4,0]  R420      -0.682853639125824
    phi[4,0]  R421      -1.8663799762725830e+00
    phi[4,0]  R422      -2.1879997253417969e+00
    phi[4,0]  R423      -1.3612687587738037e+00
    phi[4,0]  R424      -1.9356726408004761e+00
    phi[4,0]  R425      -1.21638023853302
    phi[4,0]  R426      -1.2458598613739014e+00
    phi[4,0]  R427      -1.5418606996536255e+00
    phi[4,0]  R428      -1.8713152408599854e+00
    phi[4,0]  R429      8.5599708557128906e-01
    phi[4,0]  R430      -1.9824496507644653e+00
    phi[4,0]  R431      -1.5525444746017456e+00
    phi[4,0]  R432      1.0850021839141846e+00
    phi[4,0]  R433      1.9518168270587921e-01
    phi[4,0]  R434      -1.8627785444259644e+00
    phi[4,0]  R435      -1.8236312270164490e-01
    phi[4,0]  R436      -5.4143965244293213e-01
    phi[4,0]  R437      -2.4229078292846680e+00
    phi[4,0]  R438      -6.4661078155040741e-02
    phi[4,0]  R439      -1.14437997341156
    phi[4,0]  R440      -5.3692591190338135e-01
    phi[4,0]  R441      -1.3064095973968506e+00
    phi[4,0]  R442      -1.6772496700286865e-01
    phi[4,0]  R443      -9.0786427259445190e-02
    phi[4,0]  R444      -3.8896876573562622e-01
    phi[4,0]  R445      -8.8517028093338013e-01
    phi[4,0]  R446      -7.0173645019531250e-01
    phi[4,0]  R447      -1.4042408764362335e-01
    phi[4,0]  R448      -3.8958325982093811e-02
    phi[4,0]  R449      -1.1238474398851395e-01
    phi[4,0]  R450      -6.3583290576934814e-01
    phi[4,0]  R451      -6.9769442081451416e-01
    phi[4,0]  R452      -3.1658071279525757e-01
    phi[4,0]  R453      -1.2392506599426270e+00
    phi[4,0]  R454      -1.4163167476654053e+00
    phi[4,0]  R455      -1.9400584697723389e+00
    phi[4,0]  R456      -1.5298696756362915e+00
    phi[4,0]  R457      -2.5756542682647705e+00
    phi[4,0]  R458      -4.9493527412414551e-01
    phi[4,0]  R459      -1.7800240516662598e+00
    phi[4,0]  R460      -7.3697805404663086e-01
    phi[4,0]  R461      -1.3387553691864014e+00
    phi[4,0]  R462      -1.5350072383880615e+00
    phi[4,0]  R463      -1.7462124824523926e+00
    phi[4,0]  R464      -5.1989829540252686e-01
    phi[4,0]  R465      -3.7029820680618286e-01
    phi[8,0]  R0        -1
    phi[8,0]  R2        2.7613511597919760e+00
    phi[8,0]  R3        5.5425283267683767e-01
    phi[8,0]  R4        -1.0219044757007016e+00
    phi[8,0]  R5        -1.4344836015742803e+00
    phi[8,0]  R6        1.2391141283288749e+00
    phi[8,0]  R7        3.5273027881830288e-02
    phi[8,0]  R8        5.4192717946799851e-01
    phi[8,0]  R72       1
    phi[8,0]  R466      -5.8613510644245448e+00
    phi[8,0]  R467      -3.3864874484059238e-01
    phi[8,0]  R468      -2.7942528422135808e+00
    phi[8,0]  R469      -1.6857471768599055e+00
    phi[8,0]  R470      -2.0780954289318667e+00
    phi[8,0]  R471      -4.12190438033327
    phi[8,0]  R472      -1.1355163316685175e+00
    phi[8,0]  R473      -4.0044835348170782e+00
    phi[8,0]  R474      -4.3391140329614437e+00
    phi[8,0]  R475      -1.8608857763036935e+00
    phi[8,0]  R476      -2.1252729420511418e+00
    phi[8,0]  R477      -2.0547268862874812e+00
    phi[8,0]  R478      -3.6419270841005669e+00
    phi[8,0]  R479      -2.55807272516457
    phi[8,0]  R480      -1.5699115757992932e-02
    phi[8,0]  R481      -2.4655434303042650e-02
    phi[8,0]  R482      -4.3362540756983592e-02
    phi[8,0]  R483      -6.7363019381477818e-02
    phi[8,0]  R484      -7.1002287999865188e-02
    phi[8,0]  R485      -3.7218492844708628e-01
    phi[8,0]  R486      -4.5892845970889368e-01
    phi[8,0]  R487      -5.7168588848455726e-01
    phi[8,0]  R488      -6.2300555107947542e-01
    phi[8,0]  R489      -6.3773078425596208e-01
    phi[8,0]  R490      -2.4176412819807158e-01
    phi[8,0]  R491      -0.448472521057552
    phi[8,0]  R492      -4.6797254099306951e-01
    phi[8,0]  R493      -4.7106294967722229e-01
    phi[8,0]  R494      -4.7927909498932797e-01
    phi[8,0]  R495      -4.8209029076068344e-01
    phi[8,0]  R496      -4.8511794099864092e-01
    phi[8,0]  R497      -4.9105930027037159e-01
    phi[8,0]  R498      -4.9182396699854908e-01
    phi[8,0]  R499      -4.9485200229945159e-01
    phi[8,0]  R500      -4.7218619435135567e-01
    phi[8,0]  R501      -4.7869663283774466e-01
    phi[8,0]  R502      -4.9420711378612203e-01
    phi[8,0]  R503      -1.1072731929698922e+00
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R504      -3.0999999046325684e+00
    phi[1,2]  R505      -3.0999999046325684e+00
    phi[1,2]  R506      -2.2400000095367432e+00
    phi[1,2]  R507      -2.2400000095367432e+00
    phi[1,2]  R508      -3.0999999046325684e+00
    phi[1,2]  R509      -3.0999999046325684e+00
    phi[1,2]  R510      -2.5699999332427979e+00
    phi[1,2]  R511      -2.5699999332427979e+00
    phi[1,2]  R512      -3.0999999046325684e+00
    phi[1,2]  R513      -3.0999999046325684e+00
    phi[1,2]  R514      -2.0899999141693115e+00
    phi[1,2]  R515      -2.0899999141693115e+00
    phi[1,2]  R516      -3.0999999046325684e+00
    phi[1,2]  R517      -3.0999999046325684e+00
    phi[1,2]  R518      9.3442851305007935e-01
    phi[1,2]  R519      9.3295753002166748e-01
    phi[1,2]  R520      1.3005604743957520e+00
    phi[1,2]  R521      1.1670202016830444e+00
    phi[1,2]  R522      1.1655584573745728e+00
    phi[1,2]  R523      -6.4660519361495972e-02
    phi[1,2]  R524      9.9162536859512329e-01
    phi[1,2]  R525      6.5581315755844116e-01
    phi[1,2]  R526      -2.3044865131378174e+00
    phi[1,2]  R527      -1.3068441152572632e+00
    phi[1,2]  R528      -2.7989938259124756e+00
    phi[1,2]  R529      -2.1607112884521484e+00
    phi[1,2]  R530      -2.3678085803985596e+00
    phi[1,2]  R531      -2.0446910858154297e+00
    phi[1,2]  R532      -2.4878146648406982e+00
    phi[1,2]  R533      -2.2375507354736328e+00
    phi[1,2]  R534      -1.8481643199920654e+00
    phi[1,2]  R535      -2.6088402271270752e+00
    phi[1,2]  R536      -1.8283008337020874e+00
    phi[1,2]  R537      -2.3509142398834229e+00
    phi[1,2]  R538      -1.7426745891571045e+00
    phi[1,2]  R539      -1.2259695529937744e+00
    phi[1,2]  R540      -1.9445769786834717e+00
    phi[1,2]  R541      -9.0324610471725464e-01
    phi[1,2]  R542      -1.7424603700637817e+00
    phi[1,2]  R543      -2.0823767185211182e+00
    phi[1,2]  R544      -2.3388597965240479e+00
    phi[1,2]  R545      -2.2149832248687744e+00
    phi[1,2]  R546      -2.24546480178833
    phi[1,2]  R547      -2.0764245986938477e+00
    phi[1,2]  R548      -1.4370425939559937e+00
    phi[1,2]  R549      -1.7970991134643555e+00
    phi[1,2]  R550      -1.7371408939361572e+00
    phi[1,2]  R551      -2.1368513107299805e+00
    phi[1,2]  R552      1.3440409302711487e-01
    phi[1,2]  R553      -1.4192200899124146e+00
    phi[1,2]  R554      -1.1024714708328247e+00
    phi[1,2]  R555      -8.2411026954650879e-01
    phi[1,2]  R556      -2.4732048511505127e+00
    phi[1,2]  R557      -1.9318507909774780e+00
    phi[1,2]  R558      -2.2998552322387695e+00
    phi[1,2]  R559      -1.7492371797561646e+00
    phi[1,2]  R560      -1.8323068618774414e+00
    phi[1,2]  R561      -1.8214393854141235e+00
    phi[1,2]  R562      -2.1764872074127197e+00
    phi[1,2]  R563      -1.9425952434539795e+00
    phi[1,2]  R564      -1.9991881847381592e+00
    phi[1,2]  R565      -1.2701107263565063e+00
    phi[1,2]  R566      -1.8041920661926270e+00
    phi[1,2]  R567      -1.5329240560531616e+00
    phi[1,2]  R568      -1.8515257835388184e+00
    phi[1,2]  R569      -2.5192139148712158e+00
    phi[1,2]  R570      -2.1892571449279785e+00
    phi[1,2]  R571      -1.8282463550567627e+00
    phi[1,2]  R572      -2.0184276103973389e+00
    phi[1,2]  R573      -0.801401674747467
    phi[1,2]  R574      -2.2163441181182861e+00
    phi[1,2]  R575      -2.7005395889282227e+00
    phi[1,2]  R576      -2.5229551792144775e+00
    phi[1,2]  R577      -2.2810223102569580e+00
    phi[1,2]  R578      -2.1100912094116211e+00
    phi[1,2]  R579      -2.1076126098632812e+00
    phi[1,2]  R580      -1.8788367509841919e+00
    phi[1,2]  R581      -9.0065437555313110e-01
    phi[1,2]  R582      -1.1431838274002075e+00
    phi[1,2]  R583      -9.8384010791778564e-01
    phi[1,2]  R584      -1.9644778966903687e+00
    phi[1,2]  R585      -1.7368308305740356e+00
    phi[1,2]  R586      -1.9001498222351074e+00
    phi[1,2]  R587      -1.7372353076934814e+00
    phi[1,2]  R588      -1.5661683082580566e+00
    phi[1,2]  R589      -1.8038169145584106e+00
    phi[1,2]  R590      -1.0773172378540039e+00
    phi[1,2]  R591      -5.6647367775440216e-02
    phi[1,2]  R592      -1.3675509691238403e+00
    phi[1,2]  R593      -0.354666143655777
    phi[1,2]  R594      -1.6780707836151123e+00
    phi[1,2]  R595      -1.7840765714645386e+00
    phi[1,2]  R596      -2.1679589748382568e+00
    phi[1,2]  R597      -1.5979975461959839e+00
    phi[1,2]  R598      1.6797727346420288e+00
    phi[1,2]  R599      1.7314949035644531e+00
    phi[1,2]  R600      2.4050773680210114e-01
    phi[1,2]  R601      1.4656069278717041e+00
    phi[1,2]  R602      1.8888834714889526e+00
    phi[1,2]  R603      1.8147637844085693e+00
    phi[1,2]  R604      9.1535615921020508e-01
    phi[1,2]  R605      -7.2203630208969116e-01
    phi[1,2]  R606      -9.7331404685974121e-02
    phi[1,2]  R607      3.8581270724534988e-02
    phi[1,2]  R608      -1.2690995931625366e+00
    phi[1,2]  R609      -1.5621916055679321e+00
    phi[1,2]  R610      -1.2046719789505005e+00
    phi[1,2]  R611      -1.1625746488571167e+00
    phi[1,2]  R612      -2.0187261104583740e+00
    phi[1,2]  R613      -1.6723140478134155e+00
    phi[1,2]  R614      -5.3907716274261475e-01
    phi[1,2]  R615      -1.0212630033493042e+00
    phi[1,2]  R616      -2.1781837940216064e-01
    phi[1,2]  R617      -1.3335298299789429e+00
    phi[1,2]  R618      -2.1715831756591797e-01
    phi[1,2]  R619      -5.7937139272689819e-01
    phi[1,2]  R620      -1.6594679355621338e+00
    phi[1,2]  R621      -9.3273329734802246e-01
    phi[1,2]  R622      -1.1744098663330078e+00
    phi[1,2]  R623      -1.2655849456787109e+00
    phi[1,2]  R624      -1.1704481840133667e+00
    phi[1,2]  R625      -1.0555306673049927e+00
    phi[1,2]  R626      -1.9556213617324829e+00
    phi[1,2]  R627      -1.5842872858047485e+00
    phi[1,2]  R628      3.2965299487113953e-01
    phi[1,2]  R629      -1.1336876153945923e+00
    phi[1,2]  R630      -1.7965011596679688e+00
    phi[1,2]  R631      -7.4406057596206665e-01
    phi[1,2]  R632      -0.869223415851593
    phi[1,2]  R633      -9.9560916423797607e-01
    phi[1,2]  R634      -1.8700834512710571e+00
    phi[1,2]  R635      -1.1200894117355347e+00
    phi[1,2]  R636      -1.2356014251708984e+00
    phi[1,2]  R637      -5.8825856447219849e-01
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R638      -3.0999999046325684e+00
    phi[2,1]  R639      -3.0999999046325684e+00
    phi[2,1]  R640      -2.2400000095367432e+00
    phi[2,1]  R641      -2.2400000095367432e+00
    phi[2,1]  R642      -3.0999999046325684e+00
    phi[2,1]  R643      -3.0999999046325684e+00
    phi[2,1]  R644      -2.5699999332427979e+00
    phi[2,1]  R645      -2.5699999332427979e+00
    phi[2,1]  R646      -3.0999999046325684e+00
    phi[2,1]  R647      -3.0999999046325684e+00
    phi[2,1]  R648      -2.0899999141693115e+00
    phi[2,1]  R649      -2.0899999141693115e+00
    phi[2,1]  R650      -3.0999999046325684e+00
    phi[2,1]  R651      -3.0999999046325684e+00
    phi[2,1]  R652      1.6797727346420288e+00
    phi[2,1]  R653      1.7314949035644531e+00
    phi[2,1]  R654      2.4050773680210114e-01
    phi[2,1]  R655      1.4656069278717041e+00
    phi[2,1]  R656      1.8888834714889526e+00
    phi[2,1]  R657      1.8147637844085693e+00
    phi[2,1]  R658      9.1535615921020508e-01
    phi[2,1]  R659      -7.2203630208969116e-01
    phi[2,1]  R660      -9.7331404685974121e-02
    phi[2,1]  R661      3.8581270724534988e-02
    phi[2,1]  R662      -1.2690995931625366e+00
    phi[2,1]  R663      -1.5621916055679321e+00
    phi[2,1]  R664      -1.2046719789505005e+00
    phi[2,1]  R665      -1.1625746488571167e+00
    phi[2,1]  R666      -2.0187261104583740e+00
    phi[2,1]  R667      -1.6723140478134155e+00
    phi[2,1]  R668      -5.3907716274261475e-01
    phi[2,1]  R669      -1.0212630033493042e+00
    phi[2,1]  R670      -2.1781837940216064e-01
    phi[2,1]  R671      -1.3335298299789429e+00
    phi[2,1]  R672      -2.1715831756591797e-01
    phi[2,1]  R673      -5.7937139272689819e-01
    phi[2,1]  R674      -1.6594679355621338e+00
    phi[2,1]  R675      -9.3273329734802246e-01
    phi[2,1]  R676      -1.1744098663330078e+00
    phi[2,1]  R677      -1.2655849456787109e+00
    phi[2,1]  R678      -1.1704481840133667e+00
    phi[2,1]  R679      -1.0555306673049927e+00
    phi[2,1]  R680      -1.9556213617324829e+00
    phi[2,1]  R681      -1.5842872858047485e+00
    phi[2,1]  R682      3.2965299487113953e-01
    phi[2,1]  R683      -1.1336876153945923e+00
    phi[2,1]  R684      -1.7965011596679688e+00
    phi[2,1]  R685      -7.4406057596206665e-01
    phi[2,1]  R686      -0.869223415851593
    phi[2,1]  R687      -9.9560916423797607e-01
    phi[2,1]  R688      -1.8700834512710571e+00
    phi[2,1]  R689      -1.1200894117355347e+00
    phi[2,1]  R690      -1.2356014251708984e+00
    phi[2,1]  R691      -5.8825856447219849e-01
    phi[2,1]  R692      9.3442851305007935e-01
    phi[2,1]  R693      9.3295753002166748e-01
    phi[2,1]  R694      1.3005604743957520e+00
    phi[2,1]  R695      1.1670202016830444e+00
    phi[2,1]  R696      1.1655584573745728e+00
    phi[2,1]  R697      -6.4660519361495972e-02
    phi[2,1]  R698      9.9162536859512329e-01
    phi[2,1]  R699      6.5581315755844116e-01
    phi[2,1]  R700      -2.3044865131378174e+00
    phi[2,1]  R701      -1.3068441152572632e+00
    phi[2,1]  R702      -2.7989938259124756e+00
    phi[2,1]  R703      -2.1607112884521484e+00
    phi[2,1]  R704      -2.3678085803985596e+00
    phi[2,1]  R705      -2.0446910858154297e+00
    phi[2,1]  R706      -2.4878146648406982e+00
    phi[2,1]  R707      -2.2375507354736328e+00
    phi[2,1]  R708      -1.8481643199920654e+00
    phi[2,1]  R709      -2.6088402271270752e+00
    phi[2,1]  R710      -1.8283008337020874e+00
    phi[2,1]  R711      -2.3509142398834229e+00
    phi[2,1]  R712      -1.7426745891571045e+00
    phi[2,1]  R713      -1.2259695529937744e+00
    phi[2,1]  R714      -1.9445769786834717e+00
    phi[2,1]  R715      -9.0324610471725464e-01
    phi[2,1]  R716      -1.7424603700637817e+00
    phi[2,1]  R717      -2.0823767185211182e+00
    phi[2,1]  R718      -2.3388597965240479e+00
    phi[2,1]  R719      -2.2149832248687744e+00
    phi[2,1]  R720      -2.24546480178833
    phi[2,1]  R721      -2.0764245986938477e+00
    phi[2,1]  R722      -1.4370425939559937e+00
    phi[2,1]  R723      -1.7970991134643555e+00
    phi[2,1]  R724      -1.7371408939361572e+00
    phi[2,1]  R725      -2.1368513107299805e+00
    phi[2,1]  R726      1.3440409302711487e-01
    phi[2,1]  R727      -1.4192200899124146e+00
    phi[2,1]  R728      -1.1024714708328247e+00
    phi[2,1]  R729      -8.2411026954650879e-01
    phi[2,1]  R730      -2.4732048511505127e+00
    phi[2,1]  R731      -1.9318507909774780e+00
    phi[2,1]  R732      -2.2998552322387695e+00
    phi[2,1]  R733      -1.7492371797561646e+00
    phi[2,1]  R734      -1.8323068618774414e+00
    phi[2,1]  R735      -1.8214393854141235e+00
    phi[2,1]  R736      -2.1764872074127197e+00
    phi[2,1]  R737      -1.9425952434539795e+00
    phi[2,1]  R738      -1.9991881847381592e+00
    phi[2,1]  R739      -1.2701107263565063e+00
    phi[2,1]  R740      -1.8041920661926270e+00
    phi[2,1]  R741      -1.5329240560531616e+00
    phi[2,1]  R742      -1.8515257835388184e+00
    phi[2,1]  R743      -2.5192139148712158e+00
    phi[2,1]  R744      -2.1892571449279785e+00
    phi[2,1]  R745      -1.8282463550567627e+00
    phi[2,1]  R746      -2.0184276103973389e+00
    phi[2,1]  R747      -0.801401674747467
    phi[2,1]  R748      -2.2163441181182861e+00
    phi[2,1]  R749      -2.7005395889282227e+00
    phi[2,1]  R750      -2.5229551792144775e+00
    phi[2,1]  R751      -2.2810223102569580e+00
    phi[2,1]  R752      -2.1100912094116211e+00
    phi[2,1]  R753      -2.1076126098632812e+00
    phi[2,1]  R754      -1.8788367509841919e+00
    phi[2,1]  R755      -9.0065437555313110e-01
    phi[2,1]  R756      -1.1431838274002075e+00
    phi[2,1]  R757      -9.8384010791778564e-01
    phi[2,1]  R758      -1.9644778966903687e+00
    phi[2,1]  R759      -1.7368308305740356e+00
    phi[2,1]  R760      -1.9001498222351074e+00
    phi[2,1]  R761      -1.7372353076934814e+00
    phi[2,1]  R762      -1.5661683082580566e+00
    phi[2,1]  R763      -1.8038169145584106e+00
    phi[2,1]  R764      -1.0773172378540039e+00
    phi[2,1]  R765      -5.6647367775440216e-02
    phi[2,1]  R766      -1.3675509691238403e+00
    phi[2,1]  R767      -0.354666143655777
    phi[2,1]  R768      -1.6780707836151123e+00
    phi[2,1]  R769      -1.7840765714645386e+00
    phi[2,1]  R770      -2.1679589748382568e+00
    phi[2,1]  R771      -1.5979975461959839e+00
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R772      -3.0999999046325684e+00
    phi[2,3]  R773      -3.0999999046325684e+00
    phi[2,3]  R774      -2.2400000095367432e+00
    phi[2,3]  R775      -2.2400000095367432e+00
    phi[2,3]  R776      -3.0999999046325684e+00
    phi[2,3]  R777      -3.0999999046325684e+00
    phi[2,3]  R778      -2.5699999332427979e+00
    phi[2,3]  R779      -2.5699999332427979e+00
    phi[2,3]  R780      -3.0999999046325684e+00
    phi[2,3]  R781      -3.0999999046325684e+00
    phi[2,3]  R782      -2.0899999141693115e+00
    phi[2,3]  R783      -2.0899999141693115e+00
    phi[2,3]  R784      -3.0999999046325684e+00
    phi[2,3]  R785      -3.0999999046325684e+00
    phi[2,3]  R786      1.6797727346420288e+00
    phi[2,3]  R787      1.7314949035644531e+00
    phi[2,3]  R788      2.4050773680210114e-01
    phi[2,3]  R789      1.4656069278717041e+00
    phi[2,3]  R790      1.8888834714889526e+00
    phi[2,3]  R791      1.8147637844085693e+00
    phi[2,3]  R792      9.1535615921020508e-01
    phi[2,3]  R793      -7.2203630208969116e-01
    phi[2,3]  R794      -9.7331404685974121e-02
    phi[2,3]  R795      3.8581270724534988e-02
    phi[2,3]  R796      -1.2690995931625366e+00
    phi[2,3]  R797      -1.5621916055679321e+00
    phi[2,3]  R798      -1.2046719789505005e+00
    phi[2,3]  R799      -1.1625746488571167e+00
    phi[2,3]  R800      -2.0187261104583740e+00
    phi[2,3]  R801      -1.6723140478134155e+00
    phi[2,3]  R802      -5.3907716274261475e-01
    phi[2,3]  R803      -1.0212630033493042e+00
    phi[2,3]  R804      -2.1781837940216064e-01
    phi[2,3]  R805      -1.3335298299789429e+00
    phi[2,3]  R806      -2.1715831756591797e-01
    phi[2,3]  R807      -5.7937139272689819e-01
    phi[2,3]  R808      -1.6594679355621338e+00
    phi[2,3]  R809      -9.3273329734802246e-01
    phi[2,3]  R810      -1.1744098663330078e+00
    phi[2,3]  R811      -1.2655849456787109e+00
    phi[2,3]  R812      -1.1704481840133667e+00
    phi[2,3]  R813      -1.0555306673049927e+00
    phi[2,3]  R814      -1.9556213617324829e+00
    phi[2,3]  R815      -1.5842872858047485e+00
    phi[2,3]  R816      3.2965299487113953e-01
    phi[2,3]  R817      -1.1336876153945923e+00
    phi[2,3]  R818      -1.7965011596679688e+00
    phi[2,3]  R819      -7.4406057596206665e-01
    phi[2,3]  R820      -0.869223415851593
    phi[2,3]  R821      -9.9560916423797607e-01
    phi[2,3]  R822      -1.8700834512710571e+00
    phi[2,3]  R823      -1.1200894117355347e+00
    phi[2,3]  R824      -1.2356014251708984e+00
    phi[2,3]  R825      -5.8825856447219849e-01
    phi[2,3]  R826      1.6255304813385010e+00
    phi[2,3]  R827      1.3394410610198975e+00
    phi[2,3]  R828      1.7080281972885132e+00
    phi[2,3]  R829      1.7481615543365479e+00
    phi[2,3]  R830      1.4131139516830444e+00
    phi[2,3]  R831      1.0090367794036865e+00
    phi[2,3]  R832      1.4989339113235474e+00
    phi[2,3]  R833      1.7030323743820190e+00
    phi[2,3]  R834      2.10929799079895
    phi[2,3]  R835      1.2941032648086548e+00
    phi[2,3]  R836      -1.5596798062324524e-01
    phi[2,3]  R837      -1.8309195339679718e-01
    phi[2,3]  R838      1.4068762958049774e-01
    phi[2,3]  R839      -5.2651065587997437e-01
    phi[2,3]  R840      -0.291137158870697
    phi[2,3]  R841      6.0859687626361847e-02
    phi[2,3]  R842      -2.5559618473052979e+00
    phi[2,3]  R843      -3.4473810195922852e+00
    phi[2,3]  R844      -4.33044958114624
    phi[2,3]  R845      -3.3722486495971680e+00
    phi[2,3]  R846      1.1248358488082886e+00
    phi[2,3]  R847      9.8675340414047241e-01
    phi[2,3]  R848      1.4910515546798706e+00
    phi[2,3]  R849      7.9271674156188965e-01
    phi[2,3]  R850      -1.6796854138374329e-01
    phi[2,3]  R851      1.7011246681213379e+00
    phi[2,3]  R852      -1.23859441280365
    phi[2,3]  R853      6.7423880100250244e-01
    phi[2,3]  R854      9.6074837446212769e-01
    phi[2,3]  R855      -4.18573522567749
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R856      -3.0999999046325684e+00
    phi[3,2]  R857      -3.0999999046325684e+00
    phi[3,2]  R858      -2.2400000095367432e+00
    phi[3,2]  R859      -2.2400000095367432e+00
    phi[3,2]  R860      -3.0999999046325684e+00
    phi[3,2]  R861      -3.0999999046325684e+00
    phi[3,2]  R862      -2.5699999332427979e+00
    phi[3,2]  R863      -2.5699999332427979e+00
    phi[3,2]  R864      -3.0999999046325684e+00
    phi[3,2]  R865      -3.0999999046325684e+00
    phi[3,2]  R866      -2.0899999141693115e+00
    phi[3,2]  R867      -2.0899999141693115e+00
    phi[3,2]  R868      -3.0999999046325684e+00
    phi[3,2]  R869      -3.0999999046325684e+00
    phi[3,2]  R870      1.6255304813385010e+00
    phi[3,2]  R871      1.3394410610198975e+00
    phi[3,2]  R872      1.7080281972885132e+00
    phi[3,2]  R873      1.7481615543365479e+00
    phi[3,2]  R874      1.4131139516830444e+00
    phi[3,2]  R875      1.0090367794036865e+00
    phi[3,2]  R876      1.4989339113235474e+00
    phi[3,2]  R877      1.7030323743820190e+00
    phi[3,2]  R878      2.10929799079895
    phi[3,2]  R879      1.2941032648086548e+00
    phi[3,2]  R880      -1.5596798062324524e-01
    phi[3,2]  R881      -1.8309195339679718e-01
    phi[3,2]  R882      1.4068762958049774e-01
    phi[3,2]  R883      -5.2651065587997437e-01
    phi[3,2]  R884      -0.291137158870697
    phi[3,2]  R885      6.0859687626361847e-02
    phi[3,2]  R886      -2.5559618473052979e+00
    phi[3,2]  R887      -3.4473810195922852e+00
    phi[3,2]  R888      -4.33044958114624
    phi[3,2]  R889      -3.3722486495971680e+00
    phi[3,2]  R890      1.1248358488082886e+00
    phi[3,2]  R891      9.8675340414047241e-01
    phi[3,2]  R892      1.4910515546798706e+00
    phi[3,2]  R893      7.9271674156188965e-01
    phi[3,2]  R894      -1.6796854138374329e-01
    phi[3,2]  R895      1.7011246681213379e+00
    phi[3,2]  R896      -1.23859441280365
    phi[3,2]  R897      6.7423880100250244e-01
    phi[3,2]  R898      9.6074837446212769e-01
    phi[3,2]  R899      -4.18573522567749
    phi[3,2]  R900      1.6797727346420288e+00
    phi[3,2]  R901      1.7314949035644531e+00
    phi[3,2]  R902      2.4050773680210114e-01
    phi[3,2]  R903      1.4656069278717041e+00
    phi[3,2]  R904      1.8888834714889526e+00
    phi[3,2]  R905      1.8147637844085693e+00
    phi[3,2]  R906      9.1535615921020508e-01
    phi[3,2]  R907      -7.2203630208969116e-01
    phi[3,2]  R908      -9.7331404685974121e-02
    phi[3,2]  R909      3.8581270724534988e-02
    phi[3,2]  R910      -1.2690995931625366e+00
    phi[3,2]  R911      -1.5621916055679321e+00
    phi[3,2]  R912      -1.2046719789505005e+00
    phi[3,2]  R913      -1.1625746488571167e+00
    phi[3,2]  R914      -2.0187261104583740e+00
    phi[3,2]  R915      -1.6723140478134155e+00
    phi[3,2]  R916      -5.3907716274261475e-01
    phi[3,2]  R917      -1.0212630033493042e+00
    phi[3,2]  R918      -2.1781837940216064e-01
    phi[3,2]  R919      -1.3335298299789429e+00
    phi[3,2]  R920      -2.1715831756591797e-01
    phi[3,2]  R921      -5.7937139272689819e-01
    phi[3,2]  R922      -1.6594679355621338e+00
    phi[3,2]  R923      -9.3273329734802246e-01
    phi[3,2]  R924      -1.1744098663330078e+00
    phi[3,2]  R925      -1.2655849456787109e+00
    phi[3,2]  R926      -1.1704481840133667e+00
    phi[3,2]  R927      -1.0555306673049927e+00
    phi[3,2]  R928      -1.9556213617324829e+00
    phi[3,2]  R929      -1.5842872858047485e+00
    phi[3,2]  R930      3.2965299487113953e-01
    phi[3,2]  R931      -1.1336876153945923e+00
    phi[3,2]  R932      -1.7965011596679688e+00
    phi[3,2]  R933      -7.4406057596206665e-01
    phi[3,2]  R934      -0.869223415851593
    phi[3,2]  R935      -9.9560916423797607e-01
    phi[3,2]  R936      -1.8700834512710571e+00
    phi[3,2]  R937      -1.1200894117355347e+00
    phi[3,2]  R938      -1.2356014251708984e+00
    phi[3,2]  R939      -5.8825856447219849e-01
    phi[2,7]  R18       1
    phi[2,7]  R19       1
    phi[2,7]  R63       -1
    phi[2,7]  R940      -3.0999999046325684e+00
    phi[2,7]  R941      -3.0999999046325684e+00
    phi[2,7]  R942      -2.2400000095367432e+00
    phi[2,7]  R943      -2.2400000095367432e+00
    phi[2,7]  R944      -3.0999999046325684e+00
    phi[2,7]  R945      -3.0999999046325684e+00
    phi[2,7]  R946      -2.5699999332427979e+00
    phi[2,7]  R947      -2.5699999332427979e+00
    phi[2,7]  R948      -3.0999999046325684e+00
    phi[2,7]  R949      -3.0999999046325684e+00
    phi[2,7]  R950      -2.0899999141693115e+00
    phi[2,7]  R951      -2.0899999141693115e+00
    phi[2,7]  R952      -3.0999999046325684e+00
    phi[2,7]  R953      -3.0999999046325684e+00
    phi[2,7]  R954      1.6797727346420288e+00
    phi[2,7]  R955      1.7314949035644531e+00
    phi[2,7]  R956      2.4050773680210114e-01
    phi[2,7]  R957      1.4656069278717041e+00
    phi[2,7]  R958      1.8888834714889526e+00
    phi[2,7]  R959      1.8147637844085693e+00
    phi[2,7]  R960      9.1535615921020508e-01
    phi[2,7]  R961      -7.2203630208969116e-01
    phi[2,7]  R962      -9.7331404685974121e-02
    phi[2,7]  R963      3.8581270724534988e-02
    phi[2,7]  R964      -1.2690995931625366e+00
    phi[2,7]  R965      -1.5621916055679321e+00
    phi[2,7]  R966      -1.2046719789505005e+00
    phi[2,7]  R967      -1.1625746488571167e+00
    phi[2,7]  R968      -2.0187261104583740e+00
    phi[2,7]  R969      -1.6723140478134155e+00
    phi[2,7]  R970      -5.3907716274261475e-01
    phi[2,7]  R971      -1.0212630033493042e+00
    phi[2,7]  R972      -2.1781837940216064e-01
    phi[2,7]  R973      -1.3335298299789429e+00
    phi[2,7]  R974      -2.1715831756591797e-01
    phi[2,7]  R975      -5.7937139272689819e-01
    phi[2,7]  R976      -1.6594679355621338e+00
    phi[2,7]  R977      -9.3273329734802246e-01
    phi[2,7]  R978      -1.1744098663330078e+00
    phi[2,7]  R979      -1.2655849456787109e+00
    phi[2,7]  R980      -1.1704481840133667e+00
    phi[2,7]  R981      -1.0555306673049927e+00
    phi[2,7]  R982      -1.9556213617324829e+00
    phi[2,7]  R983      -1.5842872858047485e+00
    phi[2,7]  R984      3.2965299487113953e-01
    phi[2,7]  R985      -1.1336876153945923e+00
    phi[2,7]  R986      -1.7965011596679688e+00
    phi[2,7]  R987      -7.4406057596206665e-01
    phi[2,7]  R988      -0.869223415851593
    phi[2,7]  R989      -9.9560916423797607e-01
    phi[2,7]  R990      -1.8700834512710571e+00
    phi[2,7]  R991      -1.1200894117355347e+00
    phi[2,7]  R992      -1.2356014251708984e+00
    phi[2,7]  R993      -5.8825856447219849e-01
    phi[2,7]  R994      4.2116031646728516e+00
    phi[2,7]  R995      3.4138472080230713e+00
    phi[2,7]  R996      4.2901096343994141e+00
    phi[2,7]  R997      3.0222723484039307e+00
    phi[2,7]  R998      4.1592078208923340e+00
    phi[2,7]  R999      4.2545056343078613e+00
    phi[2,7]  R1000     2.4969236850738525e+00
    phi[2,7]  R1001     3.0600283145904541e+00
    phi[2,7]  R1002     2.7522335052490234e+00
    phi[2,7]  R1003     3.3764231204986572e+00
    phi[2,7]  R1004     -3.8549666404724121e+00
    phi[2,7]  R1005     -4.4434928894042969e+00
    phi[2,7]  R1006     -2.9593384265899658e+00
    phi[2,7]  R1007     -1.9632083177566528e+00
    phi[2,7]  R1008     -3.6542854309082031e+00
    phi[2,7]  R1009     -2.6399469375610352e+00
    phi[2,7]  R1010     -1.4728292226791382e+00
    phi[2,7]  R1011     -1.2023602724075317e+00
    phi[2,7]  R1012     -1.8999927043914795e+00
    phi[2,7]  R1013     -1.3499851226806641e+00
    phi[2,7]  R1014     1.3041973114013672e-01
    phi[2,7]  R1015     -2.2773522138595581e-01
    phi[2,7]  R1016     -2.6127867698669434e+00
    phi[2,7]  R1017     -1.6811972856521606e+00
    phi[2,7]  R1018     -1.4358745813369751e+00
    phi[2,7]  R1019     -2.7806085348129272e-01
    phi[2,7]  R1020     -4.5568174123764038e-01
    phi[2,7]  R1021     -1.6824655532836914e+00
    phi[2,7]  R1022     -1.7210937738418579e+00
    phi[2,7]  R1023     -2.1806774139404297e+00
    phi[2,7]  R1024     -3.4520354270935059e+00
    phi[2,7]  R1025     -1.7587034702301025e+00
    phi[2,7]  R1026     2.16732120513916
    phi[2,7]  R1027     1.3936084508895874e+00
    phi[2,7]  R1028     4.0089631080627441e-01
    phi[2,7]  R1029     1.4071436226367950e-01
    phi[2,7]  R1030     -6.3863523304462433e-02
    phi[2,7]  R1031     7.9565656185150146e-01
    phi[2,7]  R1032     -1.5228060483932495e+00
    phi[2,7]  R1033     1.5750559568405151e+00
    phi[2,7]  R1034     1.1899360418319702e+00
    phi[2,7]  R1035     -9.7330522537231445e-01
    phi[2,7]  R1036     8.9952367544174194e-01
    phi[2,7]  R1037     1.9052625894546509e+00
    phi[2,7]  R1038     1.2477577924728394e+00
    phi[2,7]  R1039     1.5734981298446655e+00
    phi[2,7]  R1040     -8.9430016279220581e-01
    phi[2,7]  R1041     7.1507312357425690e-02
    phi[2,7]  R1042     -3.4175703525543213e+00
    phi[2,7]  R1043     -2.6516146659851074e+00
    phi[7,2]  R18       -1
    phi[7,2]  R63       1
    phi[7,2]  R64       1
    phi[7,2]  R1044     -3.0999999046325684e+00
    phi[7,2]  R1045     -3.0999999046325684e+00
    phi[7,2]  R1046     -2.2400000095367432e+00
    phi[7,2]  R1047     -2.2400000095367432e+00
    phi[7,2]  R1048     -3.0999999046325684e+00
    phi[7,2]  R1049     -3.0999999046325684e+00
    phi[7,2]  R1050     -2.5699999332427979e+00
    phi[7,2]  R1051     -2.5699999332427979e+00
    phi[7,2]  R1052     -3.0999999046325684e+00
    phi[7,2]  R1053     -3.0999999046325684e+00
    phi[7,2]  R1054     -2.0899999141693115e+00
    phi[7,2]  R1055     -2.0899999141693115e+00
    phi[7,2]  R1056     -3.0999999046325684e+00
    phi[7,2]  R1057     -3.0999999046325684e+00
    phi[7,2]  R1058     4.2116031646728516e+00
    phi[7,2]  R1059     3.4138472080230713e+00
    phi[7,2]  R1060     4.2901096343994141e+00
    phi[7,2]  R1061     3.0222723484039307e+00
    phi[7,2]  R1062     4.1592078208923340e+00
    phi[7,2]  R1063     4.2545056343078613e+00
    phi[7,2]  R1064     2.4969236850738525e+00
    phi[7,2]  R1065     3.0600283145904541e+00
    phi[7,2]  R1066     2.7522335052490234e+00
    phi[7,2]  R1067     3.3764231204986572e+00
    phi[7,2]  R1068     -3.8549666404724121e+00
    phi[7,2]  R1069     -4.4434928894042969e+00
    phi[7,2]  R1070     -2.9593384265899658e+00
    phi[7,2]  R1071     -1.9632083177566528e+00
    phi[7,2]  R1072     -3.6542854309082031e+00
    phi[7,2]  R1073     -2.6399469375610352e+00
    phi[7,2]  R1074     -1.4728292226791382e+00
    phi[7,2]  R1075     -1.2023602724075317e+00
    phi[7,2]  R1076     -1.8999927043914795e+00
    phi[7,2]  R1077     -1.3499851226806641e+00
    phi[7,2]  R1078     1.3041973114013672e-01
    phi[7,2]  R1079     -2.2773522138595581e-01
    phi[7,2]  R1080     -2.6127867698669434e+00
    phi[7,2]  R1081     -1.6811972856521606e+00
    phi[7,2]  R1082     -1.4358745813369751e+00
    phi[7,2]  R1083     -2.7806085348129272e-01
    phi[7,2]  R1084     -4.5568174123764038e-01
    phi[7,2]  R1085     -1.6824655532836914e+00
    phi[7,2]  R1086     -1.7210937738418579e+00
    phi[7,2]  R1087     -2.1806774139404297e+00
    phi[7,2]  R1088     -3.4520354270935059e+00
    phi[7,2]  R1089     -1.7587034702301025e+00
    phi[7,2]  R1090     2.16732120513916
    phi[7,2]  R1091     1.3936084508895874e+00
    phi[7,2]  R1092     4.0089631080627441e-01
    phi[7,2]  R1093     1.4071436226367950e-01
    phi[7,2]  R1094     -6.3863523304462433e-02
    phi[7,2]  R1095     7.9565656185150146e-01
    phi[7,2]  R1096     -1.5228060483932495e+00
    phi[7,2]  R1097     1.5750559568405151e+00
    phi[7,2]  R1098     1.1899360418319702e+00
    phi[7,2]  R1099     -9.7330522537231445e-01
    phi[7,2]  R1100     8.9952367544174194e-01
    phi[7,2]  R1101     1.9052625894546509e+00
    phi[7,2]  R1102     1.2477577924728394e+00
    phi[7,2]  R1103     1.5734981298446655e+00
    phi[7,2]  R1104     -8.9430016279220581e-01
    phi[7,2]  R1105     7.1507312357425690e-02
    phi[7,2]  R1106     -3.4175703525543213e+00
    phi[7,2]  R1107     -2.6516146659851074e+00
    phi[7,2]  R1108     1.6797727346420288e+00
    phi[7,2]  R1109     1.7314949035644531e+00
    phi[7,2]  R1110     2.4050773680210114e-01
    phi[7,2]  R1111     1.4656069278717041e+00
    phi[7,2]  R1112     1.8888834714889526e+00
    phi[7,2]  R1113     1.8147637844085693e+00
    phi[7,2]  R1114     9.1535615921020508e-01
    phi[7,2]  R1115     -7.2203630208969116e-01
    phi[7,2]  R1116     -9.7331404685974121e-02
    phi[7,2]  R1117     3.8581270724534988e-02
    phi[7,2]  R1118     -1.2690995931625366e+00
    phi[7,2]  R1119     -1.5621916055679321e+00
    phi[7,2]  R1120     -1.2046719789505005e+00
    phi[7,2]  R1121     -1.1625746488571167e+00
    phi[7,2]  R1122     -2.0187261104583740e+00
    phi[7,2]  R1123     -1.6723140478134155e+00
    phi[7,2]  R1124     -5.3907716274261475e-01
    phi[7,2]  R1125     -1.0212630033493042e+00
    phi[7,2]  R1126     -2.1781837940216064e-01
    phi[7,2]  R1127     -1.3335298299789429e+00
    phi[7,2]  R1128     -2.1715831756591797e-01
    phi[7,2]  R1129     -5.7937139272689819e-01
    phi[7,2]  R1130     -1.6594679355621338e+00
    phi[7,2]  R1131     -9.3273329734802246e-01
    phi[7,2]  R1132     -1.1744098663330078e+00
    phi[7,2]  R1133     -1.2655849456787109e+00
    phi[7,2]  R1134     -1.1704481840133667e+00
    phi[7,2]  R1135     -1.0555306673049927e+00
    phi[7,2]  R1136     -1.9556213617324829e+00
    phi[7,2]  R1137     -1.5842872858047485e+00
    phi[7,2]  R1138     3.2965299487113953e-01
    phi[7,2]  R1139     -1.1336876153945923e+00
    phi[7,2]  R1140     -1.7965011596679688e+00
    phi[7,2]  R1141     -7.4406057596206665e-01
    phi[7,2]  R1142     -0.869223415851593
    phi[7,2]  R1143     -9.9560916423797607e-01
    phi[7,2]  R1144     -1.8700834512710571e+00
    phi[7,2]  R1145     -1.1200894117355347e+00
    phi[7,2]  R1146     -1.2356014251708984e+00
    phi[7,2]  R1147     -5.8825856447219849e-01
    phi[3,6]  R27       1
    phi[3,6]  R28       1
    phi[3,6]  R54       -1
    phi[3,6]  R1148     -3.0999999046325684e+00
    phi[3,6]  R1149     -3.0999999046325684e+00
    phi[3,6]  R1150     -2.2400000095367432e+00
    phi[3,6]  R1151     -2.2400000095367432e+00
    phi[3,6]  R1152     -3.0999999046325684e+00
    phi[3,6]  R1153     -3.0999999046325684e+00
    phi[3,6]  R1154     -2.5699999332427979e+00
    phi[3,6]  R1155     -2.5699999332427979e+00
    phi[3,6]  R1156     -3.0999999046325684e+00
    phi[3,6]  R1157     -3.0999999046325684e+00
    phi[3,6]  R1158     -2.0899999141693115e+00
    phi[3,6]  R1159     -2.0899999141693115e+00
    phi[3,6]  R1160     -3.0999999046325684e+00
    phi[3,6]  R1161     -3.0999999046325684e+00
    phi[3,6]  R1162     1.6255304813385010e+00
    phi[3,6]  R1163     1.3394410610198975e+00
    phi[3,6]  R1164     1.7080281972885132e+00
    phi[3,6]  R1165     1.7481615543365479e+00
    phi[3,6]  R1166     1.4131139516830444e+00
    phi[3,6]  R1167     1.0090367794036865e+00
    phi[3,6]  R1168     1.4989339113235474e+00
    phi[3,6]  R1169     1.7030323743820190e+00
    phi[3,6]  R1170     2.10929799079895
    phi[3,6]  R1171     1.2941032648086548e+00
    phi[3,6]  R1172     -1.5596798062324524e-01
    phi[3,6]  R1173     -1.8309195339679718e-01
    phi[3,6]  R1174     1.4068762958049774e-01
    phi[3,6]  R1175     -5.2651065587997437e-01
    phi[3,6]  R1176     -0.291137158870697
    phi[3,6]  R1177     6.0859687626361847e-02
    phi[3,6]  R1178     -2.5559618473052979e+00
    phi[3,6]  R1179     -3.4473810195922852e+00
    phi[3,6]  R1180     -4.33044958114624
    phi[3,6]  R1181     -3.3722486495971680e+00
    phi[3,6]  R1182     1.1248358488082886e+00
    phi[3,6]  R1183     9.8675340414047241e-01
    phi[3,6]  R1184     1.4910515546798706e+00
    phi[3,6]  R1185     7.9271674156188965e-01
    phi[3,6]  R1186     -1.6796854138374329e-01
    phi[3,6]  R1187     1.7011246681213379e+00
    phi[3,6]  R1188     -1.23859441280365
    phi[3,6]  R1189     6.7423880100250244e-01
    phi[3,6]  R1190     9.6074837446212769e-01
    phi[3,6]  R1191     -4.18573522567749
    phi[3,6]  R1192     3.7686254978179932e+00
    phi[3,6]  R1193     2.2955231666564941e+00
    phi[3,6]  R1194     2.3304028511047363e+00
    phi[3,6]  R1195     6.4863169193267822e-01
    phi[3,6]  R1196     1.1487245559692383e+00
    phi[3,6]  R1197     0.937908411026001
    phi[3,6]  R1198     1.1473509669303894e-01
    phi[3,6]  R1199     -3.4828877449035645e-01
    phi[3,6]  R1200     5.2384233474731445e-01
    phi[3,6]  R1201     -8.6344015598297119e-01
    phi[3,6]  R1202     -1.0272060632705688e+00
    phi[3,6]  R1203     -1.7721022367477417e+00
    phi[3,6]  R1204     -2.4723310470581055e+00
    phi[3,6]  R1205     3.8504776358604431e-01
    phi[3,6]  R1206     -4.2646297812461853e-01
    phi[3,6]  R1207     -1.8065013885498047e+00
    phi[3,6]  R1208     -2.01804780960083
    phi[3,6]  R1209     -1.5498248338699341e+00
    phi[3,6]  R1210     2.0887978374958038e-01
    phi[3,6]  R1211     1.9482864439487457e-01
    phi[3,6]  R1212     -1.9556102752685547e+00
    phi[3,6]  R1213     -2.9017713069915771e+00
    phi[3,6]  R1214     -2.8074941635131836e+00
    phi[3,6]  R1215     -2.2378945350646973e+00
    phi[3,6]  R1216     -3.6405978202819824e+00
    phi[3,6]  R1217     -2.6378583908081055e+00
    phi[3,6]  R1218     -2.4358222484588623e+00
    phi[3,6]  R1219     -2.5090234279632568e+00
    phi[3,6]  R1220     -0.877528190612793
    phi[3,6]  R1221     -1.1650738716125488e+00
    phi[3,6]  R1222     -1.8786736726760864e+00
    phi[3,6]  R1223     -3.1431269645690918e-01
    phi[3,6]  R1224     -1.0787549018859863e+00
    phi[3,6]  R1225     -1.9995923042297363e+00
    phi[3,6]  R1226     -1.9919240474700928e+00
    phi[3,6]  R1227     8.0690854787826538e-01
    phi[3,6]  R1228     -3.4768075942993164e+00
    phi[3,6]  R1229     -2.2357881069183350e+00
    phi[3,6]  R1230     -1.5666345357894897e+00
    phi[3,6]  R1231     -2.1325898170471191e+00
    phi[3,6]  R1232     0.638489305973053
    phi[3,6]  R1233     7.4470572173595428e-02
    phi[3,6]  R1234     4.8964890837669373e-01
    phi[3,6]  R1235     1.3058813810348511e+00
    phi[3,6]  R1236     -1.3805878162384033e+00
    phi[3,6]  R1237     -1.5060994625091553e+00
    phi[3,6]  R1238     -1.8550305366516113e+00
    phi[3,6]  R1239     -1.1670926809310913e+00
    phi[3,6]  R1240     -8.7404066324234009e-01
    phi[3,6]  R1241     -6.5530198812484741e-01
    phi[3,6]  R1242     -2.6178437471389771e-01
    phi[3,6]  R1243     -2.2829475402832031e+00
    phi[3,6]  R1244     -1.3392615318298340e+00
    phi[3,6]  R1245     -9.6541082859039307e-01
    phi[3,6]  R1246     -6.7886346578598022e-01
    phi[3,6]  R1247     -1.7405290603637695e+00
    phi[3,6]  R1248     -9.0785157680511475e-01
    phi[3,6]  R1249     -1.9395941495895386e+00
    phi[3,6]  R1250     -1.5353186130523682e+00
    phi[3,6]  R1251     -3.7972042560577393e+00
    phi[6,3]  R27       -1
    phi[6,3]  R54       1
    phi[6,3]  R55       1
    phi[6,3]  R1252     -3.0999999046325684e+00
    phi[6,3]  R1253     -3.0999999046325684e+00
    phi[6,3]  R1254     -2.2400000095367432e+00
    phi[6,3]  R1255     -2.2400000095367432e+00
    phi[6,3]  R1256     -3.0999999046325684e+00
    phi[6,3]  R1257     -3.0999999046325684e+00
    phi[6,3]  R1258     -2.5699999332427979e+00
    phi[6,3]  R1259     -2.5699999332427979e+00
    phi[6,3]  R1260     -3.0999999046325684e+00
    phi[6,3]  R1261     -3.0999999046325684e+00
    phi[6,3]  R1262     -2.0899999141693115e+00
    phi[6,3]  R1263     -2.0899999141693115e+00
    phi[6,3]  R1264     -3.0999999046325684e+00
    phi[6,3]  R1265     -3.0999999046325684e+00
    phi[6,3]  R1266     3.7686254978179932e+00
    phi[6,3]  R1267     2.2955231666564941e+00
    phi[6,3]  R1268     2.3304028511047363e+00
    phi[6,3]  R1269     6.4863169193267822e-01
    phi[6,3]  R1270     1.1487245559692383e+00
    phi[6,3]  R1271     0.937908411026001
    phi[6,3]  R1272     1.1473509669303894e-01
    phi[6,3]  R1273     -3.4828877449035645e-01
    phi[6,3]  R1274     5.2384233474731445e-01
    phi[6,3]  R1275     -8.6344015598297119e-01
    phi[6,3]  R1276     -1.0272060632705688e+00
    phi[6,3]  R1277     -1.7721022367477417e+00
    phi[6,3]  R1278     -2.4723310470581055e+00
    phi[6,3]  R1279     3.8504776358604431e-01
    phi[6,3]  R1280     -4.2646297812461853e-01
    phi[6,3]  R1281     -1.8065013885498047e+00
    phi[6,3]  R1282     -2.01804780960083
    phi[6,3]  R1283     -1.5498248338699341e+00
    phi[6,3]  R1284     2.0887978374958038e-01
    phi[6,3]  R1285     1.9482864439487457e-01
    phi[6,3]  R1286     -1.9556102752685547e+00
    phi[6,3]  R1287     -2.9017713069915771e+00
    phi[6,3]  R1288     -2.8074941635131836e+00
    phi[6,3]  R1289     -2.2378945350646973e+00
    phi[6,3]  R1290     -3.6405978202819824e+00
    phi[6,3]  R1291     -2.6378583908081055e+00
    phi[6,3]  R1292     -2.4358222484588623e+00
    phi[6,3]  R1293     -2.5090234279632568e+00
    phi[6,3]  R1294     -0.877528190612793
    phi[6,3]  R1295     -1.1650738716125488e+00
    phi[6,3]  R1296     -1.8786736726760864e+00
    phi[6,3]  R1297     -3.1431269645690918e-01
    phi[6,3]  R1298     -1.0787549018859863e+00
    phi[6,3]  R1299     -1.9995923042297363e+00
    phi[6,3]  R1300     -1.9919240474700928e+00
    phi[6,3]  R1301     8.0690854787826538e-01
    phi[6,3]  R1302     -3.4768075942993164e+00
    phi[6,3]  R1303     -2.2357881069183350e+00
    phi[6,3]  R1304     -1.5666345357894897e+00
    phi[6,3]  R1305     -2.1325898170471191e+00
    phi[6,3]  R1306     0.638489305973053
    phi[6,3]  R1307     7.4470572173595428e-02
    phi[6,3]  R1308     4.8964890837669373e-01
    phi[6,3]  R1309     1.3058813810348511e+00
    phi[6,3]  R1310     -1.3805878162384033e+00
    phi[6,3]  R1311     -1.5060994625091553e+00
    phi[6,3]  R1312     -1.8550305366516113e+00
    phi[6,3]  R1313     -1.1670926809310913e+00
    phi[6,3]  R1314     -8.7404066324234009e-01
    phi[6,3]  R1315     -6.5530198812484741e-01
    phi[6,3]  R1316     -2.6178437471389771e-01
    phi[6,3]  R1317     -2.2829475402832031e+00
    phi[6,3]  R1318     -1.3392615318298340e+00
    phi[6,3]  R1319     -9.6541082859039307e-01
    phi[6,3]  R1320     -6.7886346578598022e-01
    phi[6,3]  R1321     -1.7405290603637695e+00
    phi[6,3]  R1322     -9.0785157680511475e-01
    phi[6,3]  R1323     -1.9395941495895386e+00
    phi[6,3]  R1324     -1.5353186130523682e+00
    phi[6,3]  R1325     -3.7972042560577393e+00
    phi[6,3]  R1326     1.6255304813385010e+00
    phi[6,3]  R1327     1.3394410610198975e+00
    phi[6,3]  R1328     1.7080281972885132e+00
    phi[6,3]  R1329     1.7481615543365479e+00
    phi[6,3]  R1330     1.4131139516830444e+00
    phi[6,3]  R1331     1.0090367794036865e+00
    phi[6,3]  R1332     1.4989339113235474e+00
    phi[6,3]  R1333     1.7030323743820190e+00
    phi[6,3]  R1334     2.10929799079895
    phi[6,3]  R1335     1.2941032648086548e+00
    phi[6,3]  R1336     -1.5596798062324524e-01
    phi[6,3]  R1337     -1.8309195339679718e-01
    phi[6,3]  R1338     1.4068762958049774e-01
    phi[6,3]  R1339     -5.2651065587997437e-01
    phi[6,3]  R1340     -0.291137158870697
    phi[6,3]  R1341     6.0859687626361847e-02
    phi[6,3]  R1342     -2.5559618473052979e+00
    phi[6,3]  R1343     -3.4473810195922852e+00
    phi[6,3]  R1344     -4.33044958114624
    phi[6,3]  R1345     -3.3722486495971680e+00
    phi[6,3]  R1346     1.1248358488082886e+00
    phi[6,3]  R1347     9.8675340414047241e-01
    phi[6,3]  R1348     1.4910515546798706e+00
    phi[6,3]  R1349     7.9271674156188965e-01
    phi[6,3]  R1350     -1.6796854138374329e-01
    phi[6,3]  R1351     1.7011246681213379e+00
    phi[6,3]  R1352     -1.23859441280365
    phi[6,3]  R1353     6.7423880100250244e-01
    phi[6,3]  R1354     9.6074837446212769e-01
    phi[6,3]  R1355     -4.18573522567749
    phi[3,7]  R27       1
    phi[3,7]  R28       1
    phi[3,7]  R63       -1
    phi[3,7]  R1356     -3.0999999046325684e+00
    phi[3,7]  R1357     -3.0999999046325684e+00
    phi[3,7]  R1358     -2.2400000095367432e+00
    phi[3,7]  R1359     -2.2400000095367432e+00
    phi[3,7]  R1360     -3.0999999046325684e+00
    phi[3,7]  R1361     -3.0999999046325684e+00
    phi[3,7]  R1362     -2.5699999332427979e+00
    phi[3,7]  R1363     -2.5699999332427979e+00
    phi[3,7]  R1364     -3.0999999046325684e+00
    phi[3,7]  R1365     -3.0999999046325684e+00
    phi[3,7]  R1366     -2.0899999141693115e+00
    phi[3,7]  R1367     -2.0899999141693115e+00
    phi[3,7]  R1368     -3.0999999046325684e+00
    phi[3,7]  R1369     -3.0999999046325684e+00
    phi[3,7]  R1370     1.6255304813385010e+00
    phi[3,7]  R1371     1.3394410610198975e+00
    phi[3,7]  R1372     1.7080281972885132e+00
    phi[3,7]  R1373     1.7481615543365479e+00
    phi[3,7]  R1374     1.4131139516830444e+00
    phi[3,7]  R1375     1.0090367794036865e+00
    phi[3,7]  R1376     1.4989339113235474e+00
    phi[3,7]  R1377     1.7030323743820190e+00
    phi[3,7]  R1378     2.10929799079895
    phi[3,7]  R1379     1.2941032648086548e+00
    phi[3,7]  R1380     -1.5596798062324524e-01
    phi[3,7]  R1381     -1.8309195339679718e-01
    phi[3,7]  R1382     1.4068762958049774e-01
    phi[3,7]  R1383     -5.2651065587997437e-01
    phi[3,7]  R1384     -0.291137158870697
    phi[3,7]  R1385     6.0859687626361847e-02
    phi[3,7]  R1386     -2.5559618473052979e+00
    phi[3,7]  R1387     -3.4473810195922852e+00
    phi[3,7]  R1388     -4.33044958114624
    phi[3,7]  R1389     -3.3722486495971680e+00
    phi[3,7]  R1390     1.1248358488082886e+00
    phi[3,7]  R1391     9.8675340414047241e-01
    phi[3,7]  R1392     1.4910515546798706e+00
    phi[3,7]  R1393     7.9271674156188965e-01
    phi[3,7]  R1394     -1.6796854138374329e-01
    phi[3,7]  R1395     1.7011246681213379e+00
    phi[3,7]  R1396     -1.23859441280365
    phi[3,7]  R1397     6.7423880100250244e-01
    phi[3,7]  R1398     9.6074837446212769e-01
    phi[3,7]  R1399     -4.18573522567749
    phi[3,7]  R1400     4.2116031646728516e+00
    phi[3,7]  R1401     3.4138472080230713e+00
    phi[3,7]  R1402     4.2901096343994141e+00
    phi[3,7]  R1403     3.0222723484039307e+00
    phi[3,7]  R1404     4.1592078208923340e+00
    phi[3,7]  R1405     4.2545056343078613e+00
    phi[3,7]  R1406     2.4969236850738525e+00
    phi[3,7]  R1407     3.0600283145904541e+00
    phi[3,7]  R1408     2.7522335052490234e+00
    phi[3,7]  R1409     3.3764231204986572e+00
    phi[3,7]  R1410     -3.8549666404724121e+00
    phi[3,7]  R1411     -4.4434928894042969e+00
    phi[3,7]  R1412     -2.9593384265899658e+00
    phi[3,7]  R1413     -1.9632083177566528e+00
    phi[3,7]  R1414     -3.6542854309082031e+00
    phi[3,7]  R1415     -2.6399469375610352e+00
    phi[3,7]  R1416     -1.4728292226791382e+00
    phi[3,7]  R1417     -1.2023602724075317e+00
    phi[3,7]  R1418     -1.8999927043914795e+00
    phi[3,7]  R1419     -1.3499851226806641e+00
    phi[3,7]  R1420     1.3041973114013672e-01
    phi[3,7]  R1421     -2.2773522138595581e-01
    phi[3,7]  R1422     -2.6127867698669434e+00
    phi[3,7]  R1423     -1.6811972856521606e+00
    phi[3,7]  R1424     -1.4358745813369751e+00
    phi[3,7]  R1425     -2.7806085348129272e-01
    phi[3,7]  R1426     -4.5568174123764038e-01
    phi[3,7]  R1427     -1.6824655532836914e+00
    phi[3,7]  R1428     -1.7210937738418579e+00
    phi[3,7]  R1429     -2.1806774139404297e+00
    phi[3,7]  R1430     -3.4520354270935059e+00
    phi[3,7]  R1431     -1.7587034702301025e+00
    phi[3,7]  R1432     2.16732120513916
    phi[3,7]  R1433     1.3936084508895874e+00
    phi[3,7]  R1434     4.0089631080627441e-01
    phi[3,7]  R1435     1.4071436226367950e-01
    phi[3,7]  R1436     -6.3863523304462433e-02
    phi[3,7]  R1437     7.9565656185150146e-01
    phi[3,7]  R1438     -1.5228060483932495e+00
    phi[3,7]  R1439     1.5750559568405151e+00
    phi[3,7]  R1440     1.1899360418319702e+00
    phi[3,7]  R1441     -9.7330522537231445e-01
    phi[3,7]  R1442     8.9952367544174194e-01
    phi[3,7]  R1443     1.9052625894546509e+00
    phi[3,7]  R1444     1.2477577924728394e+00
    phi[3,7]  R1445     1.5734981298446655e+00
    phi[3,7]  R1446     -8.9430016279220581e-01
    phi[3,7]  R1447     7.1507312357425690e-02
    phi[3,7]  R1448     -3.4175703525543213e+00
    phi[3,7]  R1449     -2.6516146659851074e+00
    phi[7,3]  R27       -1
    phi[7,3]  R63       1
    phi[7,3]  R64       1
    phi[7,3]  R1450     -3.0999999046325684e+00
    phi[7,3]  R1451     -3.0999999046325684e+00
    phi[7,3]  R1452     -2.2400000095367432e+00
    phi[7,3]  R1453     -2.2400000095367432e+00
    phi[7,3]  R1454     -3.0999999046325684e+00
    phi[7,3]  R1455     -3.0999999046325684e+00
    phi[7,3]  R1456     -2.5699999332427979e+00
    phi[7,3]  R1457     -2.5699999332427979e+00
    phi[7,3]  R1458     -3.0999999046325684e+00
    phi[7,3]  R1459     -3.0999999046325684e+00
    phi[7,3]  R1460     -2.0899999141693115e+00
    phi[7,3]  R1461     -2.0899999141693115e+00
    phi[7,3]  R1462     -3.0999999046325684e+00
    phi[7,3]  R1463     -3.0999999046325684e+00
    phi[7,3]  R1464     4.2116031646728516e+00
    phi[7,3]  R1465     3.4138472080230713e+00
    phi[7,3]  R1466     4.2901096343994141e+00
    phi[7,3]  R1467     3.0222723484039307e+00
    phi[7,3]  R1468     4.1592078208923340e+00
    phi[7,3]  R1469     4.2545056343078613e+00
    phi[7,3]  R1470     2.4969236850738525e+00
    phi[7,3]  R1471     3.0600283145904541e+00
    phi[7,3]  R1472     2.7522335052490234e+00
    phi[7,3]  R1473     3.3764231204986572e+00
    phi[7,3]  R1474     -3.8549666404724121e+00
    phi[7,3]  R1475     -4.4434928894042969e+00
    phi[7,3]  R1476     -2.9593384265899658e+00
    phi[7,3]  R1477     -1.9632083177566528e+00
    phi[7,3]  R1478     -3.6542854309082031e+00
    phi[7,3]  R1479     -2.6399469375610352e+00
    phi[7,3]  R1480     -1.4728292226791382e+00
    phi[7,3]  R1481     -1.2023602724075317e+00
    phi[7,3]  R1482     -1.8999927043914795e+00
    phi[7,3]  R1483     -1.3499851226806641e+00
    phi[7,3]  R1484     1.3041973114013672e-01
    phi[7,3]  R1485     -2.2773522138595581e-01
    phi[7,3]  R1486     -2.6127867698669434e+00
    phi[7,3]  R1487     -1.6811972856521606e+00
    phi[7,3]  R1488     -1.4358745813369751e+00
    phi[7,3]  R1489     -2.7806085348129272e-01
    phi[7,3]  R1490     -4.5568174123764038e-01
    phi[7,3]  R1491     -1.6824655532836914e+00
    phi[7,3]  R1492     -1.7210937738418579e+00
    phi[7,3]  R1493     -2.1806774139404297e+00
    phi[7,3]  R1494     -3.4520354270935059e+00
    phi[7,3]  R1495     -1.7587034702301025e+00
    phi[7,3]  R1496     2.16732120513916
    phi[7,3]  R1497     1.3936084508895874e+00
    phi[7,3]  R1498     4.0089631080627441e-01
    phi[7,3]  R1499     1.4071436226367950e-01
    phi[7,3]  R1500     -6.3863523304462433e-02
    phi[7,3]  R1501     7.9565656185150146e-01
    phi[7,3]  R1502     -1.5228060483932495e+00
    phi[7,3]  R1503     1.5750559568405151e+00
    phi[7,3]  R1504     1.1899360418319702e+00
    phi[7,3]  R1505     -9.7330522537231445e-01
    phi[7,3]  R1506     8.9952367544174194e-01
    phi[7,3]  R1507     1.9052625894546509e+00
    phi[7,3]  R1508     1.2477577924728394e+00
    phi[7,3]  R1509     1.5734981298446655e+00
    phi[7,3]  R1510     -8.9430016279220581e-01
    phi[7,3]  R1511     7.1507312357425690e-02
    phi[7,3]  R1512     -3.4175703525543213e+00
    phi[7,3]  R1513     -2.6516146659851074e+00
    phi[7,3]  R1514     1.6255304813385010e+00
    phi[7,3]  R1515     1.3394410610198975e+00
    phi[7,3]  R1516     1.7080281972885132e+00
    phi[7,3]  R1517     1.7481615543365479e+00
    phi[7,3]  R1518     1.4131139516830444e+00
    phi[7,3]  R1519     1.0090367794036865e+00
    phi[7,3]  R1520     1.4989339113235474e+00
    phi[7,3]  R1521     1.7030323743820190e+00
    phi[7,3]  R1522     2.10929799079895
    phi[7,3]  R1523     1.2941032648086548e+00
    phi[7,3]  R1524     -1.5596798062324524e-01
    phi[7,3]  R1525     -1.8309195339679718e-01
    phi[7,3]  R1526     1.4068762958049774e-01
    phi[7,3]  R1527     -5.2651065587997437e-01
    phi[7,3]  R1528     -0.291137158870697
    phi[7,3]  R1529     6.0859687626361847e-02
    phi[7,3]  R1530     -2.5559618473052979e+00
    phi[7,3]  R1531     -3.4473810195922852e+00
    phi[7,3]  R1532     -4.33044958114624
    phi[7,3]  R1533     -3.3722486495971680e+00
    phi[7,3]  R1534     1.1248358488082886e+00
    phi[7,3]  R1535     9.8675340414047241e-01
    phi[7,3]  R1536     1.4910515546798706e+00
    phi[7,3]  R1537     7.9271674156188965e-01
    phi[7,3]  R1538     -1.6796854138374329e-01
    phi[7,3]  R1539     1.7011246681213379e+00
    phi[7,3]  R1540     -1.23859441280365
    phi[7,3]  R1541     6.7423880100250244e-01
    phi[7,3]  R1542     9.6074837446212769e-01
    phi[7,3]  R1543     -4.18573522567749
    phi[3,9]  R27       1
    phi[3,9]  R28       1
    phi[3,9]  R29       2.4280726276135445e+00
    phi[3,9]  R30       -1.30359757748381
    phi[3,9]  R31       -1.9895697087971773e+00
    phi[3,9]  R32       -2.4091624680237325e+00
    phi[3,9]  R33       2.1511249901589693e+00
    phi[3,9]  R34       1.1858303673868931e+00
    phi[3,9]  R35       -4.6836383683881033e-01
    phi[3,9]  R73       -1
    phi[3,9]  R1544     -6.7192727701902388e-01
    phi[3,9]  R1545     -5.5280725322461128e+00
    phi[3,9]  R1546     -3.5435975870205532e+00
    phi[3,9]  R1547     -9.3640243205293316e-01
    phi[3,9]  R1548     -5.0895696134297452e+00
    phi[3,9]  R1549     -1.1104301958353910e+00
    phi[3,9]  R1550     -4.97916240126653
    phi[3,9]  R1551     -1.6083746521906539e-01
    phi[3,9]  R1552     -9.4887491447359906e-01
    phi[3,9]  R1553     -5.2511248947915377e+00
    phi[3,9]  R1554     -9.0416954678241845e-01
    phi[3,9]  R1555     -3.2758302815562046e+00
    phi[3,9]  R1556     -3.5683637414713787e+00
    phi[3,9]  R1557     -2.6316360677937580e+00
    phi[3,9]  R1558     -1.4971606577893581e-01
    phi[3,9]  R1559     -1.5553312692342769e-01
    phi[3,9]  R1560     -1.6002544530765905e-01
    phi[3,9]  R1561     -1.6579362108241957e-01
    phi[3,9]  R1562     -1.7033933756871189e-01
    phi[3,9]  R1563     -1.7301972139987987e-01
    phi[3,9]  R1564     -1.9411303170266714e-01
    phi[3,9]  R1565     -2.3901663402891127e-01
    phi[3,9]  R1566     -1.4300614053797909e+00
    phi[3,9]  R1567     -1.2482651997614367e+00
    phi[3,9]  R1568     -2.6110202283221212e-01
    phi[3,9]  R1569     -3.0889929015881618e-01
    phi[3,9]  R1570     -3.7276329933216712e-01
    phi[3,9]  R1571     -3.8397645187261936e-01
    phi[3,9]  R1572     -4.1677757624718664e-01
    phi[3,9]  R1573     -4.7530188044362842e-01
    phi[3,9]  R1574     -6.3542327126128750e-01
    phi[3,9]  R1575     -6.3771340218892592e-01
    phi[3,9]  R1576     -6.4779995541885471e-01
    phi[3,9]  R1577     -0.666261655618376
    phi[3,9]  R1578     -1.1513653426155668e-01
    phi[3,9]  R1579     -1.2768712421323869e-01
    phi[3,9]  R1580     -1.3351519087416719e-01
    phi[3,9]  R1581     -1.4169249258080263e-01
    phi[3,9]  R1582     -1.8629563097716631e-01
    phi[3,9]  R1583     -2.0680723073080776e-01
    phi[3,9]  R1584     -2.2771597423923051e-01
    phi[3,9]  R1585     -1.0580010562659878e+00
    phi[3,9]  R1586     -1.2876419646748039e+00
    phi[3,9]  R1587     -5.4269208551631953e-01
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R1588     -3.0999999046325684e+00
    phi[4,5]  R1589     -3.0999999046325684e+00
    phi[4,5]  R1590     -2.2400000095367432e+00
    phi[4,5]  R1591     -2.2400000095367432e+00
    phi[4,5]  R1592     -3.0999999046325684e+00
    phi[4,5]  R1593     -3.0999999046325684e+00
    phi[4,5]  R1594     -2.5699999332427979e+00
    phi[4,5]  R1595     -2.5699999332427979e+00
    phi[4,5]  R1596     -3.0999999046325684e+00
    phi[4,5]  R1597     -3.0999999046325684e+00
    phi[4,5]  R1598     -2.0899999141693115e+00
    phi[4,5]  R1599     -2.0899999141693115e+00
    phi[4,5]  R1600     -3.0999999046325684e+00
    phi[4,5]  R1601     -3.0999999046325684e+00
    phi[4,5]  R1602     -5.6884795427322388e-02
    phi[4,5]  R1603     -1.9323083758354187e-01
    phi[4,5]  R1604     -2.0056156814098358e-01
    phi[4,5]  R1605     -8.9799559116363525e-01
    phi[4,5]  R1606     2.6325362920761108e-01
    phi[4,5]  R1607     -5.1581519842147827e-01
    phi[4,5]  R1608     1.2389839887619019e+00
    phi[4,5]  R1609     1.4614419937133789e+00
    phi[4,5]  R1610     6.8499112129211426e-01
    phi[4,5]  R1611     7.0938414335250854e-01
    phi[4,5]  R1612     -2.22904896736145
    phi[4,5]  R1613     9.0911462903022766e-02
    phi[4,5]  R1614     -1.4017367362976074e-01
    phi[4,5]  R1615     -3.1433299183845520e-01
    phi[4,5]  R1616     -3.2254987955093384e-01
    phi[4,5]  R1617     -7.7929389476776123e-01
    phi[4,5]  R1618     -5.9074580669403076e-01
    phi[4,5]  R1619     -1.0175893306732178e+00
    phi[4,5]  R1620     -0.682853639125824
    phi[4,5]  R1621     -1.8663799762725830e+00
    phi[4,5]  R1622     -2.1879997253417969e+00
    phi[4,5]  R1623     -1.3612687587738037e+00
    phi[4,5]  R1624     -1.9356726408004761e+00
    phi[4,5]  R1625     -1.21638023853302
    phi[4,5]  R1626     -1.2458598613739014e+00
    phi[4,5]  R1627     -1.5418606996536255e+00
    phi[4,5]  R1628     -1.8713152408599854e+00
    phi[4,5]  R1629     8.5599708557128906e-01
    phi[4,5]  R1630     -1.9824496507644653e+00
    phi[4,5]  R1631     -1.5525444746017456e+00
    phi[4,5]  R1632     1.0850021839141846e+00
    phi[4,5]  R1633     1.9518168270587921e-01
    phi[4,5]  R1634     -1.8627785444259644e+00
    phi[4,5]  R1635     -1.8236312270164490e-01
    phi[4,5]  R1636     -5.4143965244293213e-01
    phi[4,5]  R1637     -2.4229078292846680e+00
    phi[4,5]  R1638     -6.4661078155040741e-02
    phi[4,5]  R1639     -1.14437997341156
    phi[4,5]  R1640     -5.3692591190338135e-01
    phi[4,5]  R1641     -1.3064095973968506e+00
    phi[4,5]  R1642     1.3265429735183716e+00
    phi[4,5]  R1643     1.8667833507061005e-01
    phi[4,5]  R1644     3.1387157738208771e-02
    phi[4,5]  R1645     2.71209716796875
    phi[4,5]  R1646     1.1086074635386467e-02
    phi[4,5]  R1647     1.3586472272872925e+00
    phi[4,5]  R1648     1.4478116035461426e+00
    phi[4,5]  R1649     2.2984068393707275e+00
    phi[4,5]  R1650     -3.6694598197937012e-01
    phi[4,5]  R1651     1.8964515924453735e+00
    phi[4,5]  R1652     -1.4819346666336060e+00
    phi[4,5]  R1653     -1.06892991065979
    phi[4,5]  R1654     -4.9096304178237915e-01
    phi[4,5]  R1655     4.9043959379196167e-01
    phi[4,5]  R1656     -0.681601881980896
    phi[4,5]  R1657     -3.6339042186737061e+00
    phi[4,5]  R1658     -2.8917589187622070e+00
    phi[4,5]  R1659     -1.8324608802795410e+00
    phi[4,5]  R1660     -1.1607475280761719e+00
    phi[4,5]  R1661     -1.0624148845672607e+00
    phi[4,5]  R1662     -1.4833470582962036e+00
    phi[4,5]  R1663     -1.1351577043533325e+00
    phi[4,5]  R1664     -3.3357162475585938e+00
    phi[4,5]  R1665     -2.8723514080047607e+00
    phi[4,5]  R1666     -2.2977497577667236e+00
    phi[4,5]  R1667     -2.4856789112091064e+00
    phi[4,5]  R1668     -2.3838419914245605e+00
    phi[4,5]  R1669     -1.5169771909713745e+00
    phi[4,5]  R1670     -2.5600361824035645e+00
    phi[4,5]  R1671     -9.9979293346405029e-01
    phi[4,5]  R1672     -9.3747019767761230e-01
    phi[4,5]  R1673     1.4601688385009766e+00
    phi[4,5]  R1674     -1.9554009437561035e+00
    phi[4,5]  R1675     0.728429913520813
    phi[4,5]  R1676     -7.9255115985870361e-01
    phi[4,5]  R1677     5.2885907888412476e-01
    phi[4,5]  R1678     -4.6153417229652405e-01
    phi[4,5]  R1679     -1.6005480661988258e-02
    phi[4,5]  R1680     -2.0621390342712402e+00
    phi[4,5]  R1681     1.2588646411895752e+00
    phi[4,5]  R1682     0.833831787109375
    phi[4,5]  R1683     -4.2868316173553467e-02
    phi[4,5]  R1684     -7.8850977122783661e-02
    phi[4,5]  R1685     1.1326497793197632e+00
    phi[4,5]  R1686     -2.4007892608642578e+00
    phi[4,5]  R1687     -1.5567084550857544e+00
    phi[4,5]  R1688     -4.1061463952064514e-01
    phi[4,5]  R1689     -5.3180074691772461e-01
    phi[4,5]  R1690     -2.1874373778700829e-02
    phi[4,5]  R1691     3.5466098785400391e-01
    phi[4,5]  R1692     -1.6185183525085449e+00
    phi[4,5]  R1693     -1.5645451545715332e+00
    phi[4,5]  R1694     -3.4794771671295166e+00
    phi[4,5]  R1695     -1.1175019741058350e+00
    phi[4,5]  R1696     -1.8767470121383667e+00
    phi[4,5]  R1697     -2.4233157634735107e+00
    phi[4,5]  R1698     -2.9036462306976318e+00
    phi[4,5]  R1699     -1.1022492647171021e+00
    phi[4,5]  R1700     1.0850944519042969e+00
    phi[4,5]  R1701     1.9214158058166504e+00
    phi[4,5]  R1702     -1.4244215488433838e+00
    phi[4,5]  R1703     -3.2013249397277832e+00
    phi[4,5]  R1704     -2.21653413772583
    phi[4,5]  R1705     -1.5853463411331177e+00
    phi[4,5]  R1706     -3.4485921859741211e+00
    phi[4,5]  R1707     -3.2433550357818604e+00
    phi[4,5]  R1708     -5.3625851869583130e-01
    phi[4,5]  R1709     -1.3345442712306976e-01
    phi[4,5]  R1710     1.4225482940673828e+00
    phi[4,5]  R1711     1.4407337903976440e+00
    phi[4,5]  R1712     -1.9940199851989746e+00
    phi[4,5]  R1713     -2.5116014480590820e-01
    phi[4,5]  R1714     1.8789811432361603e-01
    phi[4,5]  R1715     -1.1095840930938721e+00
    phi[4,5]  R1716     -1.9580194950103760e+00
    phi[4,5]  R1717     -2.3063633441925049e+00
    phi[4,5]  R1718     -1.6490589380264282e+00
    phi[4,5]  R1719     5.5244535207748413e-01
    phi[4,5]  R1720     5.2731335163116455e-01
    phi[4,5]  R1721     2.6041367650032043e-01
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R1722     -3.0999999046325684e+00
    phi[5,4]  R1723     -3.0999999046325684e+00
    phi[5,4]  R1724     -2.2400000095367432e+00
    phi[5,4]  R1725     -2.2400000095367432e+00
    phi[5,4]  R1726     -3.0999999046325684e+00
    phi[5,4]  R1727     -3.0999999046325684e+00
    phi[5,4]  R1728     -2.5699999332427979e+00
    phi[5,4]  R1729     -2.5699999332427979e+00
    phi[5,4]  R1730     -3.0999999046325684e+00
    phi[5,4]  R1731     -3.0999999046325684e+00
    phi[5,4]  R1732     -2.0899999141693115e+00
    phi[5,4]  R1733     -2.0899999141693115e+00
    phi[5,4]  R1734     -3.0999999046325684e+00
    phi[5,4]  R1735     -3.0999999046325684e+00
    phi[5,4]  R1736     1.3265429735183716e+00
    phi[5,4]  R1737     1.8667833507061005e-01
    phi[5,4]  R1738     3.1387157738208771e-02
    phi[5,4]  R1739     2.71209716796875
    phi[5,4]  R1740     1.1086074635386467e-02
    phi[5,4]  R1741     1.3586472272872925e+00
    phi[5,4]  R1742     1.4478116035461426e+00
    phi[5,4]  R1743     2.2984068393707275e+00
    phi[5,4]  R1744     -3.6694598197937012e-01
    phi[5,4]  R1745     1.8964515924453735e+00
    phi[5,4]  R1746     -1.4819346666336060e+00
    phi[5,4]  R1747     -1.06892991065979
    phi[5,4]  R1748     -4.9096304178237915e-01
    phi[5,4]  R1749     4.9043959379196167e-01
    phi[5,4]  R1750     -0.681601881980896
    phi[5,4]  R1751     -3.6339042186737061e+00
    phi[5,4]  R1752     -2.8917589187622070e+00
    phi[5,4]  R1753     -1.8324608802795410e+00
    phi[5,4]  R1754     -1.1607475280761719e+00
    phi[5,4]  R1755     -1.0624148845672607e+00
    phi[5,4]  R1756     -1.4833470582962036e+00
    phi[5,4]  R1757     -1.1351577043533325e+00
    phi[5,4]  R1758     -3.3357162475585938e+00
    phi[5,4]  R1759     -2.8723514080047607e+00
    phi[5,4]  R1760     -2.2977497577667236e+00
    phi[5,4]  R1761     -2.4856789112091064e+00
    phi[5,4]  R1762     -2.3838419914245605e+00
    phi[5,4]  R1763     -1.5169771909713745e+00
    phi[5,4]  R1764     -2.5600361824035645e+00
    phi[5,4]  R1765     -9.9979293346405029e-01
    phi[5,4]  R1766     -9.3747019767761230e-01
    phi[5,4]  R1767     1.4601688385009766e+00
    phi[5,4]  R1768     -1.9554009437561035e+00
    phi[5,4]  R1769     0.728429913520813
    phi[5,4]  R1770     -7.9255115985870361e-01
    phi[5,4]  R1771     5.2885907888412476e-01
    phi[5,4]  R1772     -4.6153417229652405e-01
    phi[5,4]  R1773     -1.6005480661988258e-02
    phi[5,4]  R1774     -2.0621390342712402e+00
    phi[5,4]  R1775     1.2588646411895752e+00
    phi[5,4]  R1776     0.833831787109375
    phi[5,4]  R1777     -4.2868316173553467e-02
    phi[5,4]  R1778     -7.8850977122783661e-02
    phi[5,4]  R1779     1.1326497793197632e+00
    phi[5,4]  R1780     -2.4007892608642578e+00
    phi[5,4]  R1781     -1.5567084550857544e+00
    phi[5,4]  R1782     -4.1061463952064514e-01
    phi[5,4]  R1783     -5.3180074691772461e-01
    phi[5,4]  R1784     -2.1874373778700829e-02
    phi[5,4]  R1785     3.5466098785400391e-01
    phi[5,4]  R1786     -1.6185183525085449e+00
    phi[5,4]  R1787     -1.5645451545715332e+00
    phi[5,4]  R1788     -3.4794771671295166e+00
    phi[5,4]  R1789     -1.1175019741058350e+00
    phi[5,4]  R1790     -1.8767470121383667e+00
    phi[5,4]  R1791     -2.4233157634735107e+00
    phi[5,4]  R1792     -2.9036462306976318e+00
    phi[5,4]  R1793     -1.1022492647171021e+00
    phi[5,4]  R1794     1.0850944519042969e+00
    phi[5,4]  R1795     1.9214158058166504e+00
    phi[5,4]  R1796     -1.4244215488433838e+00
    phi[5,4]  R1797     -3.2013249397277832e+00
    phi[5,4]  R1798     -2.21653413772583
    phi[5,4]  R1799     -1.5853463411331177e+00
    phi[5,4]  R1800     -3.4485921859741211e+00
    phi[5,4]  R1801     -3.2433550357818604e+00
    phi[5,4]  R1802     -5.3625851869583130e-01
    phi[5,4]  R1803     -1.3345442712306976e-01
    phi[5,4]  R1804     1.4225482940673828e+00
    phi[5,4]  R1805     1.4407337903976440e+00
    phi[5,4]  R1806     -1.9940199851989746e+00
    phi[5,4]  R1807     -2.5116014480590820e-01
    phi[5,4]  R1808     1.8789811432361603e-01
    phi[5,4]  R1809     -1.1095840930938721e+00
    phi[5,4]  R1810     -1.9580194950103760e+00
    phi[5,4]  R1811     -2.3063633441925049e+00
    phi[5,4]  R1812     -1.6490589380264282e+00
    phi[5,4]  R1813     5.5244535207748413e-01
    phi[5,4]  R1814     5.2731335163116455e-01
    phi[5,4]  R1815     2.6041367650032043e-01
    phi[5,4]  R1816     -5.6884795427322388e-02
    phi[5,4]  R1817     -1.9323083758354187e-01
    phi[5,4]  R1818     -2.0056156814098358e-01
    phi[5,4]  R1819     -8.9799559116363525e-01
    phi[5,4]  R1820     2.6325362920761108e-01
    phi[5,4]  R1821     -5.1581519842147827e-01
    phi[5,4]  R1822     1.2389839887619019e+00
    phi[5,4]  R1823     1.4614419937133789e+00
    phi[5,4]  R1824     6.8499112129211426e-01
    phi[5,4]  R1825     7.0938414335250854e-01
    phi[5,4]  R1826     -2.22904896736145
    phi[5,4]  R1827     9.0911462903022766e-02
    phi[5,4]  R1828     -1.4017367362976074e-01
    phi[5,4]  R1829     -3.1433299183845520e-01
    phi[5,4]  R1830     -3.2254987955093384e-01
    phi[5,4]  R1831     -7.7929389476776123e-01
    phi[5,4]  R1832     -5.9074580669403076e-01
    phi[5,4]  R1833     -1.0175893306732178e+00
    phi[5,4]  R1834     -0.682853639125824
    phi[5,4]  R1835     -1.8663799762725830e+00
    phi[5,4]  R1836     -2.1879997253417969e+00
    phi[5,4]  R1837     -1.3612687587738037e+00
    phi[5,4]  R1838     -1.9356726408004761e+00
    phi[5,4]  R1839     -1.21638023853302
    phi[5,4]  R1840     -1.2458598613739014e+00
    phi[5,4]  R1841     -1.5418606996536255e+00
    phi[5,4]  R1842     -1.8713152408599854e+00
    phi[5,4]  R1843     8.5599708557128906e-01
    phi[5,4]  R1844     -1.9824496507644653e+00
    phi[5,4]  R1845     -1.5525444746017456e+00
    phi[5,4]  R1846     1.0850021839141846e+00
    phi[5,4]  R1847     1.9518168270587921e-01
    phi[5,4]  R1848     -1.8627785444259644e+00
    phi[5,4]  R1849     -1.8236312270164490e-01
    phi[5,4]  R1850     -5.4143965244293213e-01
    phi[5,4]  R1851     -2.4229078292846680e+00
    phi[5,4]  R1852     -6.4661078155040741e-02
    phi[5,4]  R1853     -1.14437997341156
    phi[5,4]  R1854     -5.3692591190338135e-01
    phi[5,4]  R1855     -1.3064095973968506e+00
    phi[8,4]  R36       -1
    phi[8,4]  R38       2.7613511597919760e+00
    phi[8,4]  R39       5.5425283267683767e-01
    phi[8,4]  R40       -1.0219044757007016e+00
    phi[8,4]  R41       -1.4344836015742803e+00
    phi[8,4]  R42       1.2391141283288749e+00
    phi[8,4]  R43       3.5273027881830288e-02
    phi[8,4]  R44       5.4192717946799851e-01
    phi[8,4]  R72       1
    phi[8,4]  R1856     -5.8613510644245448e+00
    phi[8,4]  R1857     -3.3864874484059238e-01
    phi[8,4]  R1858     -2.7942528422135808e+00
    phi[8,4]  R1859     -1.6857471768599055e+00
    phi[8,4]  R1860     -2.0780954289318667e+00
    phi[8,4]  R1861     -4.12190438033327
    phi[8,4]  R1862     -1.1355163316685175e+00
    phi[8,4]  R1863     -4.0044835348170782e+00
    phi[8,4]  R1864     -4.3391140329614437e+00
    phi[8,4]  R1865     -1.8608857763036935e+00
    phi[8,4]  R1866     -2.1252729420511418e+00
    phi[8,4]  R1867     -2.0547268862874812e+00
    phi[8,4]  R1868     -3.6419270841005669e+00
    phi[8,4]  R1869     -2.55807272516457
    phi[8,4]  R1870     -1.3514778734371630e-01
    phi[8,4]  R1871     -2.2597833957379468e-01
    phi[8,4]  R1872     -2.4999097028357925e-01
    phi[8,4]  R1873     -2.5418325036891631e-01
    phi[8,4]  R1874     -2.5447487580042627e-01
    phi[8,4]  R1875     -2.7127961647730947e-01
    phi[8,4]  R1876     -2.7416098535741251e-01
    phi[8,4]  R1877     -2.7450018131541110e-01
    phi[8,4]  R1878     -2.7761736037837259e-01
    phi[8,4]  R1879     -3.0107552883218647e-01
    phi[8,4]  R1880     -4.5633114432012816e+00
    phi[8,4]  R1881     -4.7677494838146495e-01
    phi[8,4]  R1882     -4.9225099138736822e-01
    phi[8,4]  R1883     -5.0692205264300083e-01
    phi[8,4]  R1884     -5.1235826206025770e-01
    phi[8,4]  R1885     -5.3489307334395286e-01
    phi[8,4]  R1886     -0.538805530862647
    phi[8,4]  R1887     -5.6535742700585212e-01
    phi[8,4]  R1888     -5.6750315704671039e-01
    phi[8,4]  R1889     -5.8696824054520347e-01
    phi[8,4]  R1890     -4.1072131210144991e-01
    phi[8,4]  R1891     -4.4222971310251080e-01
    phi[8,4]  R1892     -0.452067166824319
    phi[8,4]  R1893     -4.6690073034166124e-01
    phi[8,4]  R1894     -4.6964381079435935e-01
    phi[8,4]  R1895     -4.7178930395855012e-01
    phi[8,4]  R1896     -4.8992887621706327e-01
    phi[8,4]  R1897     -4.9892885478665683e-01
    phi[8,4]  R1898     -5.0058889339270585e-01
    phi[8,4]  R1899     -5.0562496771681587e-01
    phi[8,4]  R1900     -2.6204673879157814e-01
    phi[8,4]  R1901     -3.0820573393551154e-01
    phi[8,4]  R1902     -3.2608017820263324e-01
    phi[8,4]  R1903     -4.5057272190606890e-01
    phi[8,4]  R1904     -4.6692339982815634e-01
    phi[8,4]  R1905     -5.8276098008393040e-01
    phi[8,4]  R1906     -6.1930462081506932e-01
    phi[8,4]  R1907     -6.3497630233498159e-01
    phi[8,4]  R1908     -6.3591605828674669e-01
    phi[8,4]  R1909     -6.6036770565279745e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R1910     -3.0999999046325684e+00
    phi[5,6]  R1911     -3.0999999046325684e+00
    phi[5,6]  R1912     -2.2400000095367432e+00
    phi[5,6]  R1913     -2.2400000095367432e+00
    phi[5,6]  R1914     -3.0999999046325684e+00
    phi[5,6]  R1915     -3.0999999046325684e+00
    phi[5,6]  R1916     -2.5699999332427979e+00
    phi[5,6]  R1917     -2.5699999332427979e+00
    phi[5,6]  R1918     -3.0999999046325684e+00
    phi[5,6]  R1919     -3.0999999046325684e+00
    phi[5,6]  R1920     -2.0899999141693115e+00
    phi[5,6]  R1921     -2.0899999141693115e+00
    phi[5,6]  R1922     -3.0999999046325684e+00
    phi[5,6]  R1923     -3.0999999046325684e+00
    phi[5,6]  R1924     1.3265429735183716e+00
    phi[5,6]  R1925     1.8667833507061005e-01
    phi[5,6]  R1926     3.1387157738208771e-02
    phi[5,6]  R1927     2.71209716796875
    phi[5,6]  R1928     1.1086074635386467e-02
    phi[5,6]  R1929     1.3586472272872925e+00
    phi[5,6]  R1930     1.4478116035461426e+00
    phi[5,6]  R1931     2.2984068393707275e+00
    phi[5,6]  R1932     -3.6694598197937012e-01
    phi[5,6]  R1933     1.8964515924453735e+00
    phi[5,6]  R1934     -1.4819346666336060e+00
    phi[5,6]  R1935     -1.06892991065979
    phi[5,6]  R1936     -4.9096304178237915e-01
    phi[5,6]  R1937     4.9043959379196167e-01
    phi[5,6]  R1938     -0.681601881980896
    phi[5,6]  R1939     -3.6339042186737061e+00
    phi[5,6]  R1940     -2.8917589187622070e+00
    phi[5,6]  R1941     -1.8324608802795410e+00
    phi[5,6]  R1942     -1.1607475280761719e+00
    phi[5,6]  R1943     -1.0624148845672607e+00
    phi[5,6]  R1944     -1.4833470582962036e+00
    phi[5,6]  R1945     -1.1351577043533325e+00
    phi[5,6]  R1946     -3.3357162475585938e+00
    phi[5,6]  R1947     -2.8723514080047607e+00
    phi[5,6]  R1948     -2.2977497577667236e+00
    phi[5,6]  R1949     -2.4856789112091064e+00
    phi[5,6]  R1950     -2.3838419914245605e+00
    phi[5,6]  R1951     -1.5169771909713745e+00
    phi[5,6]  R1952     -2.5600361824035645e+00
    phi[5,6]  R1953     -9.9979293346405029e-01
    phi[5,6]  R1954     -9.3747019767761230e-01
    phi[5,6]  R1955     1.4601688385009766e+00
    phi[5,6]  R1956     -1.9554009437561035e+00
    phi[5,6]  R1957     0.728429913520813
    phi[5,6]  R1958     -7.9255115985870361e-01
    phi[5,6]  R1959     5.2885907888412476e-01
    phi[5,6]  R1960     -4.6153417229652405e-01
    phi[5,6]  R1961     -1.6005480661988258e-02
    phi[5,6]  R1962     -2.0621390342712402e+00
    phi[5,6]  R1963     1.2588646411895752e+00
    phi[5,6]  R1964     0.833831787109375
    phi[5,6]  R1965     -4.2868316173553467e-02
    phi[5,6]  R1966     -7.8850977122783661e-02
    phi[5,6]  R1967     1.1326497793197632e+00
    phi[5,6]  R1968     -2.4007892608642578e+00
    phi[5,6]  R1969     -1.5567084550857544e+00
    phi[5,6]  R1970     -4.1061463952064514e-01
    phi[5,6]  R1971     -5.3180074691772461e-01
    phi[5,6]  R1972     -2.1874373778700829e-02
    phi[5,6]  R1973     3.5466098785400391e-01
    phi[5,6]  R1974     -1.6185183525085449e+00
    phi[5,6]  R1975     -1.5645451545715332e+00
    phi[5,6]  R1976     -3.4794771671295166e+00
    phi[5,6]  R1977     -1.1175019741058350e+00
    phi[5,6]  R1978     -1.8767470121383667e+00
    phi[5,6]  R1979     -2.4233157634735107e+00
    phi[5,6]  R1980     -2.9036462306976318e+00
    phi[5,6]  R1981     -1.1022492647171021e+00
    phi[5,6]  R1982     1.0850944519042969e+00
    phi[5,6]  R1983     1.9214158058166504e+00
    phi[5,6]  R1984     -1.4244215488433838e+00
    phi[5,6]  R1985     -3.2013249397277832e+00
    phi[5,6]  R1986     -2.21653413772583
    phi[5,6]  R1987     -1.5853463411331177e+00
    phi[5,6]  R1988     -3.4485921859741211e+00
    phi[5,6]  R1989     -3.2433550357818604e+00
    phi[5,6]  R1990     -5.3625851869583130e-01
    phi[5,6]  R1991     -1.3345442712306976e-01
    phi[5,6]  R1992     1.4225482940673828e+00
    phi[5,6]  R1993     1.4407337903976440e+00
    phi[5,6]  R1994     -1.9940199851989746e+00
    phi[5,6]  R1995     -2.5116014480590820e-01
    phi[5,6]  R1996     1.8789811432361603e-01
    phi[5,6]  R1997     -1.1095840930938721e+00
    phi[5,6]  R1998     -1.9580194950103760e+00
    phi[5,6]  R1999     -2.3063633441925049e+00
    phi[5,6]  R2000     -1.6490589380264282e+00
    phi[5,6]  R2001     5.5244535207748413e-01
    phi[5,6]  R2002     5.2731335163116455e-01
    phi[5,6]  R2003     2.6041367650032043e-01
    phi[5,6]  R2004     3.7686254978179932e+00
    phi[5,6]  R2005     2.2955231666564941e+00
    phi[5,6]  R2006     2.3304028511047363e+00
    phi[5,6]  R2007     6.4863169193267822e-01
    phi[5,6]  R2008     1.1487245559692383e+00
    phi[5,6]  R2009     0.937908411026001
    phi[5,6]  R2010     1.1473509669303894e-01
    phi[5,6]  R2011     -3.4828877449035645e-01
    phi[5,6]  R2012     5.2384233474731445e-01
    phi[5,6]  R2013     -8.6344015598297119e-01
    phi[5,6]  R2014     -1.0272060632705688e+00
    phi[5,6]  R2015     -1.7721022367477417e+00
    phi[5,6]  R2016     -2.4723310470581055e+00
    phi[5,6]  R2017     3.8504776358604431e-01
    phi[5,6]  R2018     -4.2646297812461853e-01
    phi[5,6]  R2019     -1.8065013885498047e+00
    phi[5,6]  R2020     -2.01804780960083
    phi[5,6]  R2021     -1.5498248338699341e+00
    phi[5,6]  R2022     2.0887978374958038e-01
    phi[5,6]  R2023     1.9482864439487457e-01
    phi[5,6]  R2024     -1.9556102752685547e+00
    phi[5,6]  R2025     -2.9017713069915771e+00
    phi[5,6]  R2026     -2.8074941635131836e+00
    phi[5,6]  R2027     -2.2378945350646973e+00
    phi[5,6]  R2028     -3.6405978202819824e+00
    phi[5,6]  R2029     -2.6378583908081055e+00
    phi[5,6]  R2030     -2.4358222484588623e+00
    phi[5,6]  R2031     -2.5090234279632568e+00
    phi[5,6]  R2032     -0.877528190612793
    phi[5,6]  R2033     -1.1650738716125488e+00
    phi[5,6]  R2034     -1.8786736726760864e+00
    phi[5,6]  R2035     -3.1431269645690918e-01
    phi[5,6]  R2036     -1.0787549018859863e+00
    phi[5,6]  R2037     -1.9995923042297363e+00
    phi[5,6]  R2038     -1.9919240474700928e+00
    phi[5,6]  R2039     8.0690854787826538e-01
    phi[5,6]  R2040     -3.4768075942993164e+00
    phi[5,6]  R2041     -2.2357881069183350e+00
    phi[5,6]  R2042     -1.5666345357894897e+00
    phi[5,6]  R2043     -2.1325898170471191e+00
    phi[5,6]  R2044     0.638489305973053
    phi[5,6]  R2045     7.4470572173595428e-02
    phi[5,6]  R2046     4.8964890837669373e-01
    phi[5,6]  R2047     1.3058813810348511e+00
    phi[5,6]  R2048     -1.3805878162384033e+00
    phi[5,6]  R2049     -1.5060994625091553e+00
    phi[5,6]  R2050     -1.8550305366516113e+00
    phi[5,6]  R2051     -1.1670926809310913e+00
    phi[5,6]  R2052     -8.7404066324234009e-01
    phi[5,6]  R2053     -6.5530198812484741e-01
    phi[5,6]  R2054     -2.6178437471389771e-01
    phi[5,6]  R2055     -2.2829475402832031e+00
    phi[5,6]  R2056     -1.3392615318298340e+00
    phi[5,6]  R2057     -9.6541082859039307e-01
    phi[5,6]  R2058     -6.7886346578598022e-01
    phi[5,6]  R2059     -1.7405290603637695e+00
    phi[5,6]  R2060     -9.0785157680511475e-01
    phi[5,6]  R2061     -1.9395941495895386e+00
    phi[5,6]  R2062     -1.5353186130523682e+00
    phi[5,6]  R2063     -3.7972042560577393e+00
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2064     -3.0999999046325684e+00
    phi[6,5]  R2065     -3.0999999046325684e+00
    phi[6,5]  R2066     -2.2400000095367432e+00
    phi[6,5]  R2067     -2.2400000095367432e+00
    phi[6,5]  R2068     -3.0999999046325684e+00
    phi[6,5]  R2069     -3.0999999046325684e+00
    phi[6,5]  R2070     -2.5699999332427979e+00
    phi[6,5]  R2071     -2.5699999332427979e+00
    phi[6,5]  R2072     -3.0999999046325684e+00
    phi[6,5]  R2073     -3.0999999046325684e+00
    phi[6,5]  R2074     -2.0899999141693115e+00
    phi[6,5]  R2075     -2.0899999141693115e+00
    phi[6,5]  R2076     -3.0999999046325684e+00
    phi[6,5]  R2077     -3.0999999046325684e+00
    phi[6,5]  R2078     3.7686254978179932e+00
    phi[6,5]  R2079     2.2955231666564941e+00
    phi[6,5]  R2080     2.3304028511047363e+00
    phi[6,5]  R2081     6.4863169193267822e-01
    phi[6,5]  R2082     1.1487245559692383e+00
    phi[6,5]  R2083     0.937908411026001
    phi[6,5]  R2084     1.1473509669303894e-01
    phi[6,5]  R2085     -3.4828877449035645e-01
    phi[6,5]  R2086     5.2384233474731445e-01
    phi[6,5]  R2087     -8.6344015598297119e-01
    phi[6,5]  R2088     -1.0272060632705688e+00
    phi[6,5]  R2089     -1.7721022367477417e+00
    phi[6,5]  R2090     -2.4723310470581055e+00
    phi[6,5]  R2091     3.8504776358604431e-01
    phi[6,5]  R2092     -4.2646297812461853e-01
    phi[6,5]  R2093     -1.8065013885498047e+00
    phi[6,5]  R2094     -2.01804780960083
    phi[6,5]  R2095     -1.5498248338699341e+00
    phi[6,5]  R2096     2.0887978374958038e-01
    phi[6,5]  R2097     1.9482864439487457e-01
    phi[6,5]  R2098     -1.9556102752685547e+00
    phi[6,5]  R2099     -2.9017713069915771e+00
    phi[6,5]  R2100     -2.8074941635131836e+00
    phi[6,5]  R2101     -2.2378945350646973e+00
    phi[6,5]  R2102     -3.6405978202819824e+00
    phi[6,5]  R2103     -2.6378583908081055e+00
    phi[6,5]  R2104     -2.4358222484588623e+00
    phi[6,5]  R2105     -2.5090234279632568e+00
    phi[6,5]  R2106     -0.877528190612793
    phi[6,5]  R2107     -1.1650738716125488e+00
    phi[6,5]  R2108     -1.8786736726760864e+00
    phi[6,5]  R2109     -3.1431269645690918e-01
    phi[6,5]  R2110     -1.0787549018859863e+00
    phi[6,5]  R2111     -1.9995923042297363e+00
    phi[6,5]  R2112     -1.9919240474700928e+00
    phi[6,5]  R2113     8.0690854787826538e-01
    phi[6,5]  R2114     -3.4768075942993164e+00
    phi[6,5]  R2115     -2.2357881069183350e+00
    phi[6,5]  R2116     -1.5666345357894897e+00
    phi[6,5]  R2117     -2.1325898170471191e+00
    phi[6,5]  R2118     0.638489305973053
    phi[6,5]  R2119     7.4470572173595428e-02
    phi[6,5]  R2120     4.8964890837669373e-01
    phi[6,5]  R2121     1.3058813810348511e+00
    phi[6,5]  R2122     -1.3805878162384033e+00
    phi[6,5]  R2123     -1.5060994625091553e+00
    phi[6,5]  R2124     -1.8550305366516113e+00
    phi[6,5]  R2125     -1.1670926809310913e+00
    phi[6,5]  R2126     -8.7404066324234009e-01
    phi[6,5]  R2127     -6.5530198812484741e-01
    phi[6,5]  R2128     -2.6178437471389771e-01
    phi[6,5]  R2129     -2.2829475402832031e+00
    phi[6,5]  R2130     -1.3392615318298340e+00
    phi[6,5]  R2131     -9.6541082859039307e-01
    phi[6,5]  R2132     -6.7886346578598022e-01
    phi[6,5]  R2133     -1.7405290603637695e+00
    phi[6,5]  R2134     -9.0785157680511475e-01
    phi[6,5]  R2135     -1.9395941495895386e+00
    phi[6,5]  R2136     -1.5353186130523682e+00
    phi[6,5]  R2137     -3.7972042560577393e+00
    phi[6,5]  R2138     1.3265429735183716e+00
    phi[6,5]  R2139     1.8667833507061005e-01
    phi[6,5]  R2140     3.1387157738208771e-02
    phi[6,5]  R2141     2.71209716796875
    phi[6,5]  R2142     1.1086074635386467e-02
    phi[6,5]  R2143     1.3586472272872925e+00
    phi[6,5]  R2144     1.4478116035461426e+00
    phi[6,5]  R2145     2.2984068393707275e+00
    phi[6,5]  R2146     -3.6694598197937012e-01
    phi[6,5]  R2147     1.8964515924453735e+00
    phi[6,5]  R2148     -1.4819346666336060e+00
    phi[6,5]  R2149     -1.06892991065979
    phi[6,5]  R2150     -4.9096304178237915e-01
    phi[6,5]  R2151     4.9043959379196167e-01
    phi[6,5]  R2152     -0.681601881980896
    phi[6,5]  R2153     -3.6339042186737061e+00
    phi[6,5]  R2154     -2.8917589187622070e+00
    phi[6,5]  R2155     -1.8324608802795410e+00
    phi[6,5]  R2156     -1.1607475280761719e+00
    phi[6,5]  R2157     -1.0624148845672607e+00
    phi[6,5]  R2158     -1.4833470582962036e+00
    phi[6,5]  R2159     -1.1351577043533325e+00
    phi[6,5]  R2160     -3.3357162475585938e+00
    phi[6,5]  R2161     -2.8723514080047607e+00
    phi[6,5]  R2162     -2.2977497577667236e+00
    phi[6,5]  R2163     -2.4856789112091064e+00
    phi[6,5]  R2164     -2.3838419914245605e+00
    phi[6,5]  R2165     -1.5169771909713745e+00
    phi[6,5]  R2166     -2.5600361824035645e+00
    phi[6,5]  R2167     -9.9979293346405029e-01
    phi[6,5]  R2168     -9.3747019767761230e-01
    phi[6,5]  R2169     1.4601688385009766e+00
    phi[6,5]  R2170     -1.9554009437561035e+00
    phi[6,5]  R2171     0.728429913520813
    phi[6,5]  R2172     -7.9255115985870361e-01
    phi[6,5]  R2173     5.2885907888412476e-01
    phi[6,5]  R2174     -4.6153417229652405e-01
    phi[6,5]  R2175     -1.6005480661988258e-02
    phi[6,5]  R2176     -2.0621390342712402e+00
    phi[6,5]  R2177     1.2588646411895752e+00
    phi[6,5]  R2178     0.833831787109375
    phi[6,5]  R2179     -4.2868316173553467e-02
    phi[6,5]  R2180     -7.8850977122783661e-02
    phi[6,5]  R2181     1.1326497793197632e+00
    phi[6,5]  R2182     -2.4007892608642578e+00
    phi[6,5]  R2183     -1.5567084550857544e+00
    phi[6,5]  R2184     -4.1061463952064514e-01
    phi[6,5]  R2185     -5.3180074691772461e-01
    phi[6,5]  R2186     -2.1874373778700829e-02
    phi[6,5]  R2187     3.5466098785400391e-01
    phi[6,5]  R2188     -1.6185183525085449e+00
    phi[6,5]  R2189     -1.5645451545715332e+00
    phi[6,5]  R2190     -3.4794771671295166e+00
    phi[6,5]  R2191     -1.1175019741058350e+00
    phi[6,5]  R2192     -1.8767470121383667e+00
    phi[6,5]  R2193     -2.4233157634735107e+00
    phi[6,5]  R2194     -2.9036462306976318e+00
    phi[6,5]  R2195     -1.1022492647171021e+00
    phi[6,5]  R2196     1.0850944519042969e+00
    phi[6,5]  R2197     1.9214158058166504e+00
    phi[6,5]  R2198     -1.4244215488433838e+00
    phi[6,5]  R2199     -3.2013249397277832e+00
    phi[6,5]  R2200     -2.21653413772583
    phi[6,5]  R2201     -1.5853463411331177e+00
    phi[6,5]  R2202     -3.4485921859741211e+00
    phi[6,5]  R2203     -3.2433550357818604e+00
    phi[6,5]  R2204     -5.3625851869583130e-01
    phi[6,5]  R2205     -1.3345442712306976e-01
    phi[6,5]  R2206     1.4225482940673828e+00
    phi[6,5]  R2207     1.4407337903976440e+00
    phi[6,5]  R2208     -1.9940199851989746e+00
    phi[6,5]  R2209     -2.5116014480590820e-01
    phi[6,5]  R2210     1.8789811432361603e-01
    phi[6,5]  R2211     -1.1095840930938721e+00
    phi[6,5]  R2212     -1.9580194950103760e+00
    phi[6,5]  R2213     -2.3063633441925049e+00
    phi[6,5]  R2214     -1.6490589380264282e+00
    phi[6,5]  R2215     5.5244535207748413e-01
    phi[6,5]  R2216     5.2731335163116455e-01
    phi[6,5]  R2217     2.6041367650032043e-01
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R2218     -3.0999999046325684e+00
    phi[6,7]  R2219     -3.0999999046325684e+00
    phi[6,7]  R2220     -2.2400000095367432e+00
    phi[6,7]  R2221     -2.2400000095367432e+00
    phi[6,7]  R2222     -3.0999999046325684e+00
    phi[6,7]  R2223     -3.0999999046325684e+00
    phi[6,7]  R2224     -2.5699999332427979e+00
    phi[6,7]  R2225     -2.5699999332427979e+00
    phi[6,7]  R2226     -3.0999999046325684e+00
    phi[6,7]  R2227     -3.0999999046325684e+00
    phi[6,7]  R2228     -2.0899999141693115e+00
    phi[6,7]  R2229     -2.0899999141693115e+00
    phi[6,7]  R2230     -3.0999999046325684e+00
    phi[6,7]  R2231     -3.0999999046325684e+00
    phi[6,7]  R2232     3.7686254978179932e+00
    phi[6,7]  R2233     2.2955231666564941e+00
    phi[6,7]  R2234     2.3304028511047363e+00
    phi[6,7]  R2235     6.4863169193267822e-01
    phi[6,7]  R2236     1.1487245559692383e+00
    phi[6,7]  R2237     0.937908411026001
    phi[6,7]  R2238     1.1473509669303894e-01
    phi[6,7]  R2239     -3.4828877449035645e-01
    phi[6,7]  R2240     5.2384233474731445e-01
    phi[6,7]  R2241     -8.6344015598297119e-01
    phi[6,7]  R2242     -1.0272060632705688e+00
    phi[6,7]  R2243     -1.7721022367477417e+00
    phi[6,7]  R2244     -2.4723310470581055e+00
    phi[6,7]  R2245     3.8504776358604431e-01
    phi[6,7]  R2246     -4.2646297812461853e-01
    phi[6,7]  R2247     -1.8065013885498047e+00
    phi[6,7]  R2248     -2.01804780960083
    phi[6,7]  R2249     -1.5498248338699341e+00
    phi[6,7]  R2250     2.0887978374958038e-01
    phi[6,7]  R2251     1.9482864439487457e-01
    phi[6,7]  R2252     -1.9556102752685547e+00
    phi[6,7]  R2253     -2.9017713069915771e+00
    phi[6,7]  R2254     -2.8074941635131836e+00
    phi[6,7]  R2255     -2.2378945350646973e+00
    phi[6,7]  R2256     -3.6405978202819824e+00
    phi[6,7]  R2257     -2.6378583908081055e+00
    phi[6,7]  R2258     -2.4358222484588623e+00
    phi[6,7]  R2259     -2.5090234279632568e+00
    phi[6,7]  R2260     -0.877528190612793
    phi[6,7]  R2261     -1.1650738716125488e+00
    phi[6,7]  R2262     -1.8786736726760864e+00
    phi[6,7]  R2263     -3.1431269645690918e-01
    phi[6,7]  R2264     -1.0787549018859863e+00
    phi[6,7]  R2265     -1.9995923042297363e+00
    phi[6,7]  R2266     -1.9919240474700928e+00
    phi[6,7]  R2267     8.0690854787826538e-01
    phi[6,7]  R2268     -3.4768075942993164e+00
    phi[6,7]  R2269     -2.2357881069183350e+00
    phi[6,7]  R2270     -1.5666345357894897e+00
    phi[6,7]  R2271     -2.1325898170471191e+00
    phi[6,7]  R2272     0.638489305973053
    phi[6,7]  R2273     7.4470572173595428e-02
    phi[6,7]  R2274     4.8964890837669373e-01
    phi[6,7]  R2275     1.3058813810348511e+00
    phi[6,7]  R2276     -1.3805878162384033e+00
    phi[6,7]  R2277     -1.5060994625091553e+00
    phi[6,7]  R2278     -1.8550305366516113e+00
    phi[6,7]  R2279     -1.1670926809310913e+00
    phi[6,7]  R2280     -8.7404066324234009e-01
    phi[6,7]  R2281     -6.5530198812484741e-01
    phi[6,7]  R2282     -2.6178437471389771e-01
    phi[6,7]  R2283     -2.2829475402832031e+00
    phi[6,7]  R2284     -1.3392615318298340e+00
    phi[6,7]  R2285     -9.6541082859039307e-01
    phi[6,7]  R2286     -6.7886346578598022e-01
    phi[6,7]  R2287     -1.7405290603637695e+00
    phi[6,7]  R2288     -9.0785157680511475e-01
    phi[6,7]  R2289     -1.9395941495895386e+00
    phi[6,7]  R2290     -1.5353186130523682e+00
    phi[6,7]  R2291     -3.7972042560577393e+00
    phi[6,7]  R2292     4.2116031646728516e+00
    phi[6,7]  R2293     3.4138472080230713e+00
    phi[6,7]  R2294     4.2901096343994141e+00
    phi[6,7]  R2295     3.0222723484039307e+00
    phi[6,7]  R2296     4.1592078208923340e+00
    phi[6,7]  R2297     4.2545056343078613e+00
    phi[6,7]  R2298     2.4969236850738525e+00
    phi[6,7]  R2299     3.0600283145904541e+00
    phi[6,7]  R2300     2.7522335052490234e+00
    phi[6,7]  R2301     3.3764231204986572e+00
    phi[6,7]  R2302     -3.8549666404724121e+00
    phi[6,7]  R2303     -4.4434928894042969e+00
    phi[6,7]  R2304     -2.9593384265899658e+00
    phi[6,7]  R2305     -1.9632083177566528e+00
    phi[6,7]  R2306     -3.6542854309082031e+00
    phi[6,7]  R2307     -2.6399469375610352e+00
    phi[6,7]  R2308     -1.4728292226791382e+00
    phi[6,7]  R2309     -1.2023602724075317e+00
    phi[6,7]  R2310     -1.8999927043914795e+00
    phi[6,7]  R2311     -1.3499851226806641e+00
    phi[6,7]  R2312     1.3041973114013672e-01
    phi[6,7]  R2313     -2.2773522138595581e-01
    phi[6,7]  R2314     -2.6127867698669434e+00
    phi[6,7]  R2315     -1.6811972856521606e+00
    phi[6,7]  R2316     -1.4358745813369751e+00
    phi[6,7]  R2317     -2.7806085348129272e-01
    phi[6,7]  R2318     -4.5568174123764038e-01
    phi[6,7]  R2319     -1.6824655532836914e+00
    phi[6,7]  R2320     -1.7210937738418579e+00
    phi[6,7]  R2321     -2.1806774139404297e+00
    phi[6,7]  R2322     -3.4520354270935059e+00
    phi[6,7]  R2323     -1.7587034702301025e+00
    phi[6,7]  R2324     2.16732120513916
    phi[6,7]  R2325     1.3936084508895874e+00
    phi[6,7]  R2326     4.0089631080627441e-01
    phi[6,7]  R2327     1.4071436226367950e-01
    phi[6,7]  R2328     -6.3863523304462433e-02
    phi[6,7]  R2329     7.9565656185150146e-01
    phi[6,7]  R2330     -1.5228060483932495e+00
    phi[6,7]  R2331     1.5750559568405151e+00
    phi[6,7]  R2332     1.1899360418319702e+00
    phi[6,7]  R2333     -9.7330522537231445e-01
    phi[6,7]  R2334     8.9952367544174194e-01
    phi[6,7]  R2335     1.9052625894546509e+00
    phi[6,7]  R2336     1.2477577924728394e+00
    phi[6,7]  R2337     1.5734981298446655e+00
    phi[6,7]  R2338     -8.9430016279220581e-01
    phi[6,7]  R2339     7.1507312357425690e-02
    phi[6,7]  R2340     -3.4175703525543213e+00
    phi[6,7]  R2341     -2.6516146659851074e+00
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R2342     -3.0999999046325684e+00
    phi[7,6]  R2343     -3.0999999046325684e+00
    phi[7,6]  R2344     -2.2400000095367432e+00
    phi[7,6]  R2345     -2.2400000095367432e+00
    phi[7,6]  R2346     -3.0999999046325684e+00
    phi[7,6]  R2347     -3.0999999046325684e+00
    phi[7,6]  R2348     -2.5699999332427979e+00
    phi[7,6]  R2349     -2.5699999332427979e+00
    phi[7,6]  R2350     -3.0999999046325684e+00
    phi[7,6]  R2351     -3.0999999046325684e+00
    phi[7,6]  R2352     -2.0899999141693115e+00
    phi[7,6]  R2353     -2.0899999141693115e+00
    phi[7,6]  R2354     -3.0999999046325684e+00
    phi[7,6]  R2355     -3.0999999046325684e+00
    phi[7,6]  R2356     4.2116031646728516e+00
    phi[7,6]  R2357     3.4138472080230713e+00
    phi[7,6]  R2358     4.2901096343994141e+00
    phi[7,6]  R2359     3.0222723484039307e+00
    phi[7,6]  R2360     4.1592078208923340e+00
    phi[7,6]  R2361     4.2545056343078613e+00
    phi[7,6]  R2362     2.4969236850738525e+00
    phi[7,6]  R2363     3.0600283145904541e+00
    phi[7,6]  R2364     2.7522335052490234e+00
    phi[7,6]  R2365     3.3764231204986572e+00
    phi[7,6]  R2366     -3.8549666404724121e+00
    phi[7,6]  R2367     -4.4434928894042969e+00
    phi[7,6]  R2368     -2.9593384265899658e+00
    phi[7,6]  R2369     -1.9632083177566528e+00
    phi[7,6]  R2370     -3.6542854309082031e+00
    phi[7,6]  R2371     -2.6399469375610352e+00
    phi[7,6]  R2372     -1.4728292226791382e+00
    phi[7,6]  R2373     -1.2023602724075317e+00
    phi[7,6]  R2374     -1.8999927043914795e+00
    phi[7,6]  R2375     -1.3499851226806641e+00
    phi[7,6]  R2376     1.3041973114013672e-01
    phi[7,6]  R2377     -2.2773522138595581e-01
    phi[7,6]  R2378     -2.6127867698669434e+00
    phi[7,6]  R2379     -1.6811972856521606e+00
    phi[7,6]  R2380     -1.4358745813369751e+00
    phi[7,6]  R2381     -2.7806085348129272e-01
    phi[7,6]  R2382     -4.5568174123764038e-01
    phi[7,6]  R2383     -1.6824655532836914e+00
    phi[7,6]  R2384     -1.7210937738418579e+00
    phi[7,6]  R2385     -2.1806774139404297e+00
    phi[7,6]  R2386     -3.4520354270935059e+00
    phi[7,6]  R2387     -1.7587034702301025e+00
    phi[7,6]  R2388     2.16732120513916
    phi[7,6]  R2389     1.3936084508895874e+00
    phi[7,6]  R2390     4.0089631080627441e-01
    phi[7,6]  R2391     1.4071436226367950e-01
    phi[7,6]  R2392     -6.3863523304462433e-02
    phi[7,6]  R2393     7.9565656185150146e-01
    phi[7,6]  R2394     -1.5228060483932495e+00
    phi[7,6]  R2395     1.5750559568405151e+00
    phi[7,6]  R2396     1.1899360418319702e+00
    phi[7,6]  R2397     -9.7330522537231445e-01
    phi[7,6]  R2398     8.9952367544174194e-01
    phi[7,6]  R2399     1.9052625894546509e+00
    phi[7,6]  R2400     1.2477577924728394e+00
    phi[7,6]  R2401     1.5734981298446655e+00
    phi[7,6]  R2402     -8.9430016279220581e-01
    phi[7,6]  R2403     7.1507312357425690e-02
    phi[7,6]  R2404     -3.4175703525543213e+00
    phi[7,6]  R2405     -2.6516146659851074e+00
    phi[7,6]  R2406     3.7686254978179932e+00
    phi[7,6]  R2407     2.2955231666564941e+00
    phi[7,6]  R2408     2.3304028511047363e+00
    phi[7,6]  R2409     6.4863169193267822e-01
    phi[7,6]  R2410     1.1487245559692383e+00
    phi[7,6]  R2411     0.937908411026001
    phi[7,6]  R2412     1.1473509669303894e-01
    phi[7,6]  R2413     -3.4828877449035645e-01
    phi[7,6]  R2414     5.2384233474731445e-01
    phi[7,6]  R2415     -8.6344015598297119e-01
    phi[7,6]  R2416     -1.0272060632705688e+00
    phi[7,6]  R2417     -1.7721022367477417e+00
    phi[7,6]  R2418     -2.4723310470581055e+00
    phi[7,6]  R2419     3.8504776358604431e-01
    phi[7,6]  R2420     -4.2646297812461853e-01
    phi[7,6]  R2421     -1.8065013885498047e+00
    phi[7,6]  R2422     -2.01804780960083
    phi[7,6]  R2423     -1.5498248338699341e+00
    phi[7,6]  R2424     2.0887978374958038e-01
    phi[7,6]  R2425     1.9482864439487457e-01
    phi[7,6]  R2426     -1.9556102752685547e+00
    phi[7,6]  R2427     -2.9017713069915771e+00
    phi[7,6]  R2428     -2.8074941635131836e+00
    phi[7,6]  R2429     -2.2378945350646973e+00
    phi[7,6]  R2430     -3.6405978202819824e+00
    phi[7,6]  R2431     -2.6378583908081055e+00
    phi[7,6]  R2432     -2.4358222484588623e+00
    phi[7,6]  R2433     -2.5090234279632568e+00
    phi[7,6]  R2434     -0.877528190612793
    phi[7,6]  R2435     -1.1650738716125488e+00
    phi[7,6]  R2436     -1.8786736726760864e+00
    phi[7,6]  R2437     -3.1431269645690918e-01
    phi[7,6]  R2438     -1.0787549018859863e+00
    phi[7,6]  R2439     -1.9995923042297363e+00
    phi[7,6]  R2440     -1.9919240474700928e+00
    phi[7,6]  R2441     8.0690854787826538e-01
    phi[7,6]  R2442     -3.4768075942993164e+00
    phi[7,6]  R2443     -2.2357881069183350e+00
    phi[7,6]  R2444     -1.5666345357894897e+00
    phi[7,6]  R2445     -2.1325898170471191e+00
    phi[7,6]  R2446     0.638489305973053
    phi[7,6]  R2447     7.4470572173595428e-02
    phi[7,6]  R2448     4.8964890837669373e-01
    phi[7,6]  R2449     1.3058813810348511e+00
    phi[7,6]  R2450     -1.3805878162384033e+00
    phi[7,6]  R2451     -1.5060994625091553e+00
    phi[7,6]  R2452     -1.8550305366516113e+00
    phi[7,6]  R2453     -1.1670926809310913e+00
    phi[7,6]  R2454     -8.7404066324234009e-01
    phi[7,6]  R2455     -6.5530198812484741e-01
    phi[7,6]  R2456     -2.6178437471389771e-01
    phi[7,6]  R2457     -2.2829475402832031e+00
    phi[7,6]  R2458     -1.3392615318298340e+00
    phi[7,6]  R2459     -9.6541082859039307e-01
    phi[7,6]  R2460     -6.7886346578598022e-01
    phi[7,6]  R2461     -1.7405290603637695e+00
    phi[7,6]  R2462     -9.0785157680511475e-01
    phi[7,6]  R2463     -1.9395941495895386e+00
    phi[7,6]  R2464     -1.5353186130523682e+00
    phi[7,6]  R2465     -3.7972042560577393e+00
    phi[7,9]  R63       1
    phi[7,9]  R64       1
    phi[7,9]  R65       2.4280726276135445e+00
    phi[7,9]  R66       -1.30359757748381
    phi[7,9]  R67       -1.9895697087971773e+00
    phi[7,9]  R68       -2.4091624680237325e+00
    phi[7,9]  R69       2.1511249901589693e+00
    phi[7,9]  R70       1.1858303673868931e+00
    phi[7,9]  R71       -4.6836383683881033e-01
    phi[7,9]  R73       -1
    phi[7,9]  R2466     -6.7192727701902388e-01
    phi[7,9]  R2467     -5.5280725322461128e+00
    phi[7,9]  R2468     -3.5435975870205532e+00
    phi[7,9]  R2469     -9.3640243205293316e-01
    phi[7,9]  R2470     -5.0895696134297452e+00
    phi[7,9]  R2471     -1.1104301958353910e+00
    phi[7,9]  R2472     -4.97916240126653
    phi[7,9]  R2473     -1.6083746521906539e-01
    phi[7,9]  R2474     -9.4887491447359906e-01
    phi[7,9]  R2475     -5.2511248947915377e+00
    phi[7,9]  R2476     -9.0416954678241845e-01
    phi[7,9]  R2477     -3.2758302815562046e+00
    phi[7,9]  R2478     -3.5683637414713787e+00
    phi[7,9]  R2479     -2.6316360677937580e+00
    phi[7,9]  R2480     -2.7076132320840252e-01
    phi[7,9]  R2481     -2.7151264558130350e-01
    phi[7,9]  R2482     -2.7492658047857166e-01
    phi[7,9]  R2483     -2.8600098494212434e-01
    phi[7,9]  R2484     -2.8721864857581725e-01
    phi[7,9]  R2485     -0.290422051656579
    phi[7,9]  R2486     -3.2677663201466078e-01
    phi[7,9]  R2487     -5.4086775332852222e-01
    phi[7,9]  R2488     -3.6449596104944249e-01
    phi[7,9]  R2489     -3.9386603596484981e-01
    phi[7,9]  R2490     -5.4623411426206880e-01
    phi[7,9]  R2491     -1.1857666615272748e+00
    phi[7,9]  R2492     -2.7390516400769194e-01
    phi[7,9]  R2493     -5.9164648882628623e-01
    phi[7,9]  R2494     -4.6674992637894341e-01
    phi[7,9]  R2495     -7.1029818025031988e-01
    phi[7,9]  R2496     -2.9985452577598815e-01
    phi[7,9]  R2497     -8.6430983831391961e-01
    phi[7,9]  R2498     -1.24443866780933
    phi[7,9]  R2499     -1.2850133652297497e+00
    phi[7,9]  R2500     -7.9790189652756049e-01
    phi[7,9]  R2501     -1.0420494029099672e+00
    phi[7,9]  R2502     -5.0950415610285837e-01
    phi[7,9]  R2503     -1.0462392146863921e+00
    phi[7,9]  R2504     -9.6515122590727254e-01
    phi[7,9]  R2505     -9.4596445621805292e-01
    phi[7,9]  R2506     -6.7402983761696733e-01
    phi[7,9]  R2507     -1.1305343649472974e+00
    phi[7,9]  R2508     -3.8158689235160481e-01
    phi[7,9]  R2509     -1.5614075636143705e+00
    phi[7,9]  R2510     -1.1187654523688231e+00
    phi[7,9]  R2511     -0.34701099239975
    phi[7,9]  R2512     -3.5112028994036049e-01
    phi[7,9]  R2513     -3.6737149625427645e-01
    phi[7,9]  R2514     -3.8199508897749268e-01
    phi[7,9]  R2515     -4.0471301386109426e-01
    phi[7,9]  R2516     -4.3385584772172070e-01
    phi[7,9]  R2517     -4.4363279786461574e-01
    phi[7,9]  R2518     -4.5423160356149239e-01
    phi[7,9]  R2519     -4.6343393132728661e-01
    phi[7,9]  R2520     -3.5280859549923593e-01
    phi[7,9]  R2521     -9.3866760880627143e-01
    phi[7,9]  R2522     -0.431631969830234
    phi[7,9]  R2523     -5.3099173924898091e-01
    phi[7,9]  R2524     -4.5069282291282109e-01
    phi[7,9]  R2525     -4.7811904754133749e-01
    phi[7,9]  R2526     -5.2562519282903952e-01
    phi[7,9]  R2527     -5.4859571492230530e-01
    phi[7,9]  R2528     -6.5048754620103511e-01
    phi[7,9]  R2529     -7.4315389387848385e-01
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R74       -1
    z[0,1,0]  R75       1
    z[0,1,0]  R88       -4.7193846106529236e-01
    z[0,1,0]  R89       1.1018313467502594e-01
    z[0,1,0]  R90       1.0481964051723480e-01
    z[0,1,0]  R91       -1.0138093680143356e-01
    z[0,1,0]  R92       1.9732140004634857e-01
    z[0,1,0]  R93       1.3901720941066742e-01
    z[0,1,0]  R94       3.7475538253784180e-01
    z[0,1,0]  R95       1.2003602460026741e-02
    z[0,1,0]  R96       5.5702839046716690e-02
    z[0,1,0]  R97       -5.8938987553119659e-02
    z[0,1,0]  R98       -1.3932450115680695e-01
    z[0,1,0]  R99       4.3517518043518066e-01
    z[0,1,0]  R100      4.4730097055435181e-01
    z[0,1,0]  R101      4.6356192231178284e-01
    z[0,1,0]  R102      3.5692679882049561e-01
    z[0,1,0]  R103      6.2341004610061646e-01
    z[0,1,0]  R104      9.8113574087619781e-02
    z[0,1,0]  R105      4.1323477029800415e-01
    z[0,1,0]  R106      1.2854509055614471e-01
    z[0,1,0]  R107      3.6500638723373413e-01
    z[0,1,0]  R108      5.0051051378250122e-01
    z[0,1,0]  R109      3.9290696382522583e-01
    z[0,1,0]  R110      3.7262195348739624e-01
    z[0,1,0]  R111      -4.5882124453783035e-02
    z[0,1,0]  R112      0.792331874370575
    z[0,1,0]  R113      8.2360351085662842e-01
    z[0,1,0]  R114      0.825454592704773
    z[0,1,0]  R115      7.6305472850799561e-01
    z[0,1,0]  R116      9.1392600536346436e-01
    z[0,1,0]  R117      0.52276611328125
    z[0,1,0]  R118      0.848131537437439
    z[0,1,0]  R119      3.7846568226814270e-01
    z[0,1,0]  R120      -8.1787988543510437e-02
    z[0,1,0]  R121      -6.8388646841049194e-01
    z[0,1,0]  R122      -7.1314197778701782e-01
    z[0,1,0]  R123      -7.2746276855468750e-01
    z[0,1,0]  R124      -5.6805860996246338e-01
    z[0,1,0]  R125      -3.9287251234054565e-01
    z[0,1,0]  R126      -4.2372727394104004e-01
    z[0,1,0]  R127      -3.5243424773216248e-01
    z[0,1,0]  R128      -3.3037438988685608e-01
    z[0,1,0]  R129      -5.1508784294128418e-01
    z[0,1,0]  R130      -1.1502622812986374e-01
    z[0,1,0]  R131      -5.5213999748229980e-01
    z[0,1,0]  R132      -8.8299199938774109e-02
    z[0,1,0]  R133      -3.2991442084312439e-01
    z[0,1,0]  R134      -5.8540350198745728e-01
    z[0,1,0]  R135      -1.1914123594760895e-01
    z[0,1,0]  R136      -2.3966337740421295e-01
    z[0,1,0]  R137      -3.7223327159881592e-01
    z[0,1,0]  R138      -8.0146938562393188e-01
    z[0,1,0]  R139      -5.7806009054183960e-01
    z[0,1,0]  R140      -6.4372068643569946e-01
    z[0,1,0]  R141      -5.0161868333816528e-01
    z[0,1,0]  R142      -8.6371667683124542e-02
    z[0,1,0]  R143      1.6991788521409035e-02
    z[0,1,0]  R144      -6.1657375097274780e-01
    z[0,1,0]  R145      -9.1038918495178223e-01
    z[0,1,0]  R146      3.5387545824050903e-01
    z[0,1,0]  R147      -5.5890983343124390e-01
    z[0,1,0]  R148      -4.4688713550567627e-01
    z[0,1,0]  R149      -1.9498790800571442e-01
    z[0,1,0]  R150      -7.7668559551239014e-01
    z[0,1,0]  R151      -3.8441443443298340e-01
    z[0,1,0]  R152      -2.9512861371040344e-01
    z[0,1,0]  R153      -0.0926283597946167
    z[0,1,0]  R154      -8.3295780420303345e-01
    z[0,1,0]  R155      -7.3763936758041382e-01
    z[0,1,0]  R156      -8.3456999063491821e-01
    z[0,1,0]  R157      -7.8176146745681763e-01
    z[0,1,0]  R158      -7.6022058725357056e-01
    z[0,1,0]  R159      -5.2391797304153442e-01
    z[0,1,0]  R160      -8.8238435983657837e-01
    z[0,1,0]  R161      -6.3313668966293335e-01
    z[0,1,0]  R162      -8.8090650737285614e-02
    z[0,1,0]  R163      -2.4210691452026367e-01
    z[0,1,0]  R164      -8.2538688182830811e-01
    z[0,1,0]  R165      -3.1109073758125305e-01
    z[0,1,0]  R166      -2.5181236863136292e-01
    z[0,1,0]  R167      3.0048617720603943e-01
    z[0,1,0]  R168      -3.4604933857917786e-01
    z[0,1,0]  R169      -2.4814704060554504e-01
    z[0,1,0]  R170      -2.2024038434028625e-01
    z[0,1,0]  R171      -1.9153533875942230e-01
    z[0,1,0]  R172      -3.9020866155624390e-01
    z[0,1,0]  R173      -8.9242297410964966e-01
    z[0,1,0]  R174      -9.0254890918731689e-01
    z[0,1,0]  R175      -4.8743051290512085e-01
    z[0,1,0]  R176      -3.9723870158195496e-01
    z[0,1,0]  R177      2.5431382656097412e-01
    z[0,1,0]  R178      -2.8373831510543823e-01
    z[0,1,0]  R179      -7.5022215023636818e-03
    z[0,1,0]  R180      -4.0039947628974915e-01
    z[0,1,0]  R181      -0.390885591506958
    z[0,1,0]  R182      1.3482457399368286e-01
    z[0,1,0]  R183      -7.1054035425186157e-01
    z[0,1,0]  R184      -6.1111062765121460e-01
    z[0,1,0]  R185      3.4063592553138733e-01
    z[0,1,0]  R186      -2.8471186757087708e-01
    z[0,1,0]  R187      -4.9109966494143009e-03
    z[0,1,0]  R188      -4.6274831891059875e-01
    z[0,1,0]  R189      -4.1613438725471497e-01
    z[0,1,0]  R190      -3.3148407936096191e-01
    z[0,1,0]  R191      -0.0384528785943985
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R76       -1
    z[0,1,1]  R77       1
    z[0,1,1]  R88       4.0633219480514526e-01
    z[0,1,1]  R89       3.6497992277145386e-01
    z[0,1,1]  R90       9.1564163565635681e-02
    z[0,1,1]  R91       -6.9874674081802368e-02
    z[0,1,1]  R92       2.0535512268543243e-01
    z[0,1,1]  R93       5.2349686622619629e-01
    z[0,1,1]  R94       3.8399979472160339e-01
    z[0,1,1]  R95       -5.3805607557296753e-01
    z[0,1,1]  R96       -7.4528193473815918e-01
    z[0,1,1]  R97       4.8454570770263672e-01
    z[0,1,1]  R98       -6.3817077875137329e-01
    z[0,1,1]  R99       -5.4885178804397583e-01
    z[0,1,1]  R100      -4.9646717309951782e-01
    z[0,1,1]  R101      -2.5711867213249207e-01
    z[0,1,1]  R102      -5.8885782957077026e-01
    z[0,1,1]  R103      -5.9335255622863770e-01
    z[0,1,1]  R104      -5.0874662399291992e-01
    z[0,1,1]  R105      -1.4740055799484253e-01
    z[0,1,1]  R106      -3.6910966038703918e-01
    z[0,1,1]  R107      -0.593457818031311
    z[0,1,1]  R108      -4.6988964080810547e-01
    z[0,1,1]  R109      -4.5893543958663940e-01
    z[0,1,1]  R110      -7.6876294612884521e-01
    z[0,1,1]  R111      -6.6079491376876831e-01
    z[0,1,1]  R112      -1.0905101150274277e-01
    z[0,1,1]  R113      1.5836556255817413e-01
    z[0,1,1]  R114      1.2569531798362732e-01
    z[0,1,1]  R115      2.5770911574363708e-01
    z[0,1,1]  R116      -1.0237623006105423e-01
    z[0,1,1]  R117      -4.1197243332862854e-01
    z[0,1,1]  R118      -3.0243989825248718e-01
    z[0,1,1]  R119      -2.8250840306282043e-01
    z[0,1,1]  R120      7.2571784257888794e-01
    z[0,1,1]  R121      2.8844487667083740e-01
    z[0,1,1]  R122      1.3543620705604553e-01
    z[0,1,1]  R123      2.1578861773014069e-01
    z[0,1,1]  R124      2.0259724557399750e-01
    z[0,1,1]  R125      4.7164192795753479e-01
    z[0,1,1]  R126      -6.6417090594768524e-02
    z[0,1,1]  R127      -1.0809313505887985e-01
    z[0,1,1]  R128      -2.3711220920085907e-01
    z[0,1,1]  R129      2.8366753458976746e-01
    z[0,1,1]  R130      6.7696201801300049e-01
    z[0,1,1]  R131      -4.1145187616348267e-01
    z[0,1,1]  R132      8.4717440605163574e-01
    z[0,1,1]  R133      8.5122102499008179e-01
    z[0,1,1]  R134      2.0687554776668549e-01
    z[0,1,1]  R135      8.9596009254455566e-01
    z[0,1,1]  R136      0.419808566570282
    z[0,1,1]  R137      7.7928400039672852e-01
    z[0,1,1]  R138      -2.8380360454320908e-02
    z[0,1,1]  R139      0.0535450242459774
    z[0,1,1]  R140      -1.3417863845825195e-01
    z[0,1,1]  R141      4.8361358046531677e-01
    z[0,1,1]  R142      5.3514945507049561e-01
    z[0,1,1]  R143      4.9760690331459045e-01
    z[0,1,1]  R144      -2.2233970463275909e-01
    z[0,1,1]  R145      -3.3424004912376404e-01
    z[0,1,1]  R146      4.5104047656059265e-01
    z[0,1,1]  R147      3.2487812638282776e-01
    z[0,1,1]  R148      3.1988728046417236e-01
    z[0,1,1]  R149      -1.3790245354175568e-01
    z[0,1,1]  R150      1.8276622891426086e-01
    z[0,1,1]  R151      1.6258032619953156e-01
    z[0,1,1]  R152      0.658534049987793
    z[0,1,1]  R153      7.2154521942138672e-01
    z[0,1,1]  R154      9.6430137753486633e-02
    z[0,1,1]  R155      -2.9100757837295532e-01
    z[0,1,1]  R156      -1.7757755517959595e-01
    z[0,1,1]  R157      2.8576648235321045e-01
    z[0,1,1]  R158      3.4093910455703735e-01
    z[0,1,1]  R159      1.8604382872581482e-01
    z[0,1,1]  R160      -1.4244794845581055e-01
    z[0,1,1]  R161      1.3397786021232605e-01
    z[0,1,1]  R162      7.2524315118789673e-01
    z[0,1,1]  R163      6.8998634815216064e-01
    z[0,1,1]  R164      2.6473295688629150e-01
    z[0,1,1]  R165      7.2068822383880615e-01
    z[0,1,1]  R166      7.3601621389389038e-01
    z[0,1,1]  R167      3.9459916949272156e-01
    z[0,1,1]  R168      -0.512565016746521
    z[0,1,1]  R169      -4.3045002222061157e-01
    z[0,1,1]  R170      -4.1318696737289429e-01
    z[0,1,1]  R171      -3.9167153835296631e-01
    z[0,1,1]  R172      8.1174737215042114e-01
    z[0,1,1]  R173      2.1241806447505951e-01
    z[0,1,1]  R174      -1.6283838078379631e-02
    z[0,1,1]  R175      -1.2810570001602173e-01
    z[0,1,1]  R176      1.7376622557640076e-01
    z[0,1,1]  R177      5.9266769886016846e-01
    z[0,1,1]  R178      -6.2614244222640991e-01
    z[0,1,1]  R179      -6.3249868154525757e-01
    z[0,1,1]  R180      -5.1105105876922607e-01
    z[0,1,1]  R181      -3.7430158257484436e-01
    z[0,1,1]  R182      7.7420455217361450e-01
    z[0,1,1]  R183      2.3767906427383423e-01
    z[0,1,1]  R184      -1.1000989377498627e-01
    z[0,1,1]  R185      7.1379250288009644e-01
    z[0,1,1]  R186      -1.3433446176350117e-02
    z[0,1,1]  R187      0.693791925907135
    z[0,1,1]  R188      -4.7620710730552673e-01
    z[0,1,1]  R189      -5.3375661373138428e-01
    z[0,1,1]  R190      -5.4656445980072021e-01
    z[0,1,1]  R191      -0.770487368106842
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R78       -1
    z[0,1,2]  R79       1
    z[0,1,2]  R88       -2.9667532444000244e-01
    z[0,1,2]  R89       -5.8395648002624512e-01
    z[0,1,2]  R90       -1.6161238774657249e-02
    z[0,1,2]  R91       -3.1805202364921570e-01
    z[0,1,2]  R92       -3.6977049708366394e-01
    z[0,1,2]  R93       5.8368629217147827e-01
    z[0,1,2]  R94       6.7640066146850586e-01
    z[0,1,2]  R95       7.1182990074157715e-01
    z[0,1,2]  R96       -8.8471837341785431e-02
    z[0,1,2]  R97       6.7449682950973511e-01
    z[0,1,2]  R98       -3.2637748122215271e-01
    z[0,1,2]  R99       4.3346127867698669e-01
    z[0,1,2]  R100      6.3849735260009766e-01
    z[0,1,2]  R101      5.0912266969680786e-01
    z[0,1,2]  R102      0.470760315656662
    z[0,1,2]  R103      1.4835509657859802e-01
    z[0,1,2]  R104      0.646979570388794
    z[0,1,2]  R105      5.0280445814132690e-01
    z[0,1,2]  R106      7.0748674869537354e-01
    z[0,1,2]  R107      4.7013705968856812e-01
    z[0,1,2]  R108      4.1912484169006348e-01
    z[0,1,2]  R109      4.5609843730926514e-01
    z[0,1,2]  R110      5.1664119958877563e-01
    z[0,1,2]  R111      1.4599700272083282e-01
    z[0,1,2]  R112      4.9007475376129150e-01
    z[0,1,2]  R113      4.3332302570343018e-01
    z[0,1,2]  R114      4.3423864245414734e-01
    z[0,1,2]  R115      4.5883128046989441e-01
    z[0,1,2]  R116      1.3983765617012978e-02
    z[0,1,2]  R117      3.9672231674194336e-01
    z[0,1,2]  R118      -4.8237197101116180e-02
    z[0,1,2]  R119      7.5016999244689941e-01
    z[0,1,2]  R120      4.5759268105030060e-02
    z[0,1,2]  R121      -4.7399401664733887e-01
    z[0,1,2]  R122      -2.5449833273887634e-01
    z[0,1,2]  R123      -3.9830714464187622e-02
    z[0,1,2]  R124      -8.1029146909713745e-02
    z[0,1,2]  R125      -4.7255808115005493e-01
    z[0,1,2]  R126      -3.2451364398002625e-01
    z[0,1,2]  R127      -5.6197357177734375e-01
    z[0,1,2]  R128      -7.3531186580657959e-01
    z[0,1,2]  R129      -3.0125150084495544e-01
    z[0,1,2]  R130      -4.2521965503692627e-01
    z[0,1,2]  R131      -2.5884151458740234e-01
    z[0,1,2]  R132      -8.2246296107769012e-02
    z[0,1,2]  R133      7.3520161211490631e-02
    z[0,1,2]  R134      -6.6690897941589355e-01
    z[0,1,2]  R135      1.5338120982050896e-02
    z[0,1,2]  R136      -5.3181946277618408e-01
    z[0,1,2]  R137      -1.4147794246673584e-01
    z[0,1,2]  R138      -4.2270419001579285e-01
    z[0,1,2]  R139      -0.382876992225647
    z[0,1,2]  R140      -5.3503000736236572e-01
    z[0,1,2]  R141      -4.7239184379577637e-01
    z[0,1,2]  R142      -2.2648519277572632e-01
    z[0,1,2]  R143      -5.0820887088775635e-01
    z[0,1,2]  R144      -4.1381460428237915e-01
    z[0,1,2]  R145      -1.9720740616321564e-01
    z[0,1,2]  R146      -6.2122678756713867e-01
    z[0,1,2]  R147      -4.2674034833908081e-01
    z[0,1,2]  R148      -4.9503925442695618e-01
    z[0,1,2]  R149      -8.2410043478012085e-01
    z[0,1,2]  R150      1.0093321651220322e-01
    z[0,1,2]  R151      -5.6082463264465332e-01
    z[0,1,2]  R152      9.7608342766761780e-02
    z[0,1,2]  R153      -3.7305000424385071e-01
    z[0,1,2]  R154      -2.8750467300415039e-01
    z[0,1,2]  R155      -5.1594811677932739e-01
    z[0,1,2]  R156      -4.1705605387687683e-01
    z[0,1,2]  R157      -7.9808674752712250e-02
    z[0,1,2]  R158      -4.5072114467620850e-01
    z[0,1,2]  R159      -5.7259029150009155e-01
    z[0,1,2]  R160      0.0425020195543766
    z[0,1,2]  R161      -5.8257788419723511e-01
    z[0,1,2]  R162      -2.9622277617454529e-01
    z[0,1,2]  R163      1.0739636421203613e-01
    z[0,1,2]  R164      -2.8401133418083191e-01
    z[0,1,2]  R165      -7.5146481394767761e-02
    z[0,1,2]  R166      4.0949344635009766e-01
    z[0,1,2]  R167      -5.9676694869995117e-01
    z[0,1,2]  R168      7.0104055106639862e-02
    z[0,1,2]  R169      2.5865691900253296e-01
    z[0,1,2]  R170      0.045010045170784
    z[0,1,2]  R171      2.1633841097354889e-03
    z[0,1,2]  R172      1.3381724059581757e-01
    z[0,1,2]  R173      -2.4735182523727417e-01
    z[0,1,2]  R174      -3.2939341664314270e-01
    z[0,1,2]  R175      -6.7971074581146240e-01
    z[0,1,2]  R176      -2.6860460638999939e-01
    z[0,1,2]  R177      -6.2600922584533691e-01
    z[0,1,2]  R178      7.3427930474281311e-02
    z[0,1,2]  R179      -5.4973983764648438e-01
    z[0,1,2]  R180      3.5052296519279480e-01
    z[0,1,2]  R181      1.9565726816654205e-01
    z[0,1,2]  R182      -0.0914430320262909
    z[0,1,2]  R183      -2.7722349762916565e-01
    z[0,1,2]  R184      -6.3867402076721191e-01
    z[0,1,2]  R185      -0.552993655204773
    z[0,1,2]  R186      -6.2353104352951050e-01
    z[0,1,2]  R187      -3.4796708822250366e-01
    z[0,1,2]  R188      2.6201891899108887e-01
    z[0,1,2]  R189      3.3248621225357056e-01
    z[0,1,2]  R190      4.4115567207336426e-01
    z[0,1,2]  R191      -1.0193391889333725e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R80       -1
    z[0,1,3]  R81       1
    z[0,1,3]  R88       -3.6269670724868774e-01
    z[0,1,3]  R89       5.2972659468650818e-02
    z[0,1,3]  R90       -1.9804526865482330e-01
    z[0,1,3]  R91       1.5918588638305664e-01
    z[0,1,3]  R92       6.8287521600723267e-01
    z[0,1,3]  R93       3.6385348439216614e-01
    z[0,1,3]  R94       3.5438263416290283e-01
    z[0,1,3]  R95       -2.3863545060157776e-01
    z[0,1,3]  R96       -4.0655103325843811e-01
    z[0,1,3]  R97       -4.0248352289199829e-01
    z[0,1,3]  R98       -4.9531683325767517e-01
    z[0,1,3]  R99       -3.7554952502250671e-01
    z[0,1,3]  R100      -3.6751943826675415e-01
    z[0,1,3]  R101      -5.6465232372283936e-01
    z[0,1,3]  R102      -4.4723954796791077e-01
    z[0,1,3]  R103      -3.7528955936431885e-01
    z[0,1,3]  R104      -4.0517678856849670e-01
    z[0,1,3]  R105      -5.7033616304397583e-01
    z[0,1,3]  R106      -5.8279848098754883e-01
    z[0,1,3]  R107      -1.9058936834335327e-01
    z[0,1,3]  R108      -3.2990479469299316e-01
    z[0,1,3]  R109      -0.409199982881546
    z[0,1,3]  R110      -1.2543281540274620e-02
    z[0,1,3]  R111      8.3574960008263588e-03
    z[0,1,3]  R112      9.2287629842758179e-02
    z[0,1,3]  R113      -2.0014800131320953e-01
    z[0,1,3]  R114      -8.5034728050231934e-02
    z[0,1,3]  R115      1.3058932125568390e-01
    z[0,1,3]  R116      3.0125194787979126e-01
    z[0,1,3]  R117      0.520189642906189
    z[0,1,3]  R118      1.3079671561717987e-01
    z[0,1,3]  R119      2.5256437063217163e-01
    z[0,1,3]  R120      4.0579503774642944e-01
    z[0,1,3]  R121      0.0964856743812561
    z[0,1,3]  R122      2.9296535253524780e-01
    z[0,1,3]  R123      -3.7418681383132935e-01
    z[0,1,3]  R124      -1.3086028397083282e-01
    z[0,1,3]  R125      -1.7786049842834473e-01
    z[0,1,3]  R126      4.3679423630237579e-02
    z[0,1,3]  R127      1.2698574364185333e-01
    z[0,1,3]  R128      -3.3059798181056976e-02
    z[0,1,3]  R129      2.4960565567016602e-01
    z[0,1,3]  R130      1.2818354368209839e-01
    z[0,1,3]  R131      -2.8161531314253807e-02
    z[0,1,3]  R132      1.8379606306552887e-01
    z[0,1,3]  R133      8.9184358716011047e-02
    z[0,1,3]  R134      3.0218443274497986e-01
    z[0,1,3]  R135      -1.7567628622055054e-01
    z[0,1,3]  R136      5.6137013435363770e-01
    z[0,1,3]  R137      -2.5533020496368408e-02
    z[0,1,3]  R138      7.2698421776294708e-02
    z[0,1,3]  R139      1.2450806796550751e-01
    z[0,1,3]  R140      2.0046686753630638e-02
    z[0,1,3]  R141      4.0017595887184143e-01
    z[0,1,3]  R142      7.2901839017868042e-01
    z[0,1,3]  R143      6.1173772811889648e-01
    z[0,1,3]  R144      2.6643732190132141e-01
    z[0,1,3]  R145      1.3333716988563538e-01
    z[0,1,3]  R146      -4.6903842687606812e-01
    z[0,1,3]  R147      -5.6975334882736206e-01
    z[0,1,3]  R148      -6.2637668848037720e-01
    z[0,1,3]  R149      -1.3208748772740364e-02
    z[0,1,3]  R150      -2.7006399631500244e-01
    z[0,1,3]  R151      -0.284567654132843
    z[0,1,3]  R152      6.2359935045242310e-01
    z[0,1,3]  R153      2.0508620142936707e-01
    z[0,1,3]  R154      -3.4290376305580139e-01
    z[0,1,3]  R155      0.0787176638841629
    z[0,1,3]  R156      -3.1505491584539413e-02
    z[0,1,3]  R157      -1.8802741169929504e-01
    z[0,1,3]  R158      -7.6615914702415466e-02
    z[0,1,3]  R159      -4.5816308259963989e-01
    z[0,1,3]  R160      1.0480262339115143e-02
    z[0,1,3]  R161      -1.6463990509510040e-01
    z[0,1,3]  R162      4.9492558836936951e-01
    z[0,1,3]  R163      5.1039123535156250e-01
    z[0,1,3]  R164      1.5957221388816833e-01
    z[0,1,3]  R165      2.0176191627979279e-01
    z[0,1,3]  R166      2.0435136556625366e-01
    z[0,1,3]  R167      2.4046385660767555e-02
    z[0,1,3]  R168      1.0196488350629807e-01
    z[0,1,3]  R169      -1.8244255334138870e-02
    z[0,1,3]  R170      1.2740735709667206e-01
    z[0,1,3]  R171      1.6273528337478638e-01
    z[0,1,3]  R172      2.0743475854396820e-01
    z[0,1,3]  R173      1.2848366796970367e-01
    z[0,1,3]  R174      1.8277525901794434e-01
    z[0,1,3]  R175      -1.0069535672664642e-01
    z[0,1,3]  R176      -2.6078507304191589e-01
    z[0,1,3]  R177      1.5137994289398193e-01
    z[0,1,3]  R178      2.1282330155372620e-01
    z[0,1,3]  R179      8.2246467471122742e-02
    z[0,1,3]  R180      -4.5397719740867615e-01
    z[0,1,3]  R181      -3.9986866712570190e-01
    z[0,1,3]  R182      4.1989326477050781e-01
    z[0,1,3]  R183      -1.0096883773803711e-01
    z[0,1,3]  R184      -9.7536019980907440e-02
    z[0,1,3]  R185      -2.5212657451629639e-01
    z[0,1,3]  R186      2.8084175661206245e-02
    z[0,1,3]  R187      1.8539489805698395e-01
    z[0,1,3]  R188      -5.8655989170074463e-01
    z[0,1,3]  R189      -4.3416237831115723e-01
    z[0,1,3]  R190      -4.5367926359176636e-01
    z[0,1,3]  R191      -6.1849749088287354e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R82       -1
    z[0,1,4]  R83       1
    z[0,1,4]  R88       4.1067349910736084e-01
    z[0,1,4]  R89       -6.6973263025283813e-01
    z[0,1,4]  R90       -3.4389740228652954e-01
    z[0,1,4]  R91       4.9633234739303589e-01
    z[0,1,4]  R92       2.4827130138874054e-01
    z[0,1,4]  R93       1.9438037276268005e-01
    z[0,1,4]  R94       -2.8037112951278687e-01
    z[0,1,4]  R95       1.6553400456905365e-01
    z[0,1,4]  R96       -4.1912916302680969e-01
    z[0,1,4]  R97       -7.6593488454818726e-02
    z[0,1,4]  R98       -2.5571519136428833e-01
    z[0,1,4]  R99       -3.8300853222608566e-02
    z[0,1,4]  R100      9.6754379570484161e-02
    z[0,1,4]  R101      -5.9946998953819275e-02
    z[0,1,4]  R102      2.5409618020057678e-01
    z[0,1,4]  R103      1.9072329998016357e-01
    z[0,1,4]  R104      4.2938109487295151e-02
    z[0,1,4]  R105      3.1333111226558685e-02
    z[0,1,4]  R106      -3.8230195641517639e-02
    z[0,1,4]  R107      3.7335065007209778e-01
    z[0,1,4]  R108      -1.4024357497692108e-01
    z[0,1,4]  R109      2.4437731504440308e-01
    z[0,1,4]  R110      -3.9964348077774048e-02
    z[0,1,4]  R111      2.2781032323837280e-01
    z[0,1,4]  R112      5.0804324448108673e-02
    z[0,1,4]  R113      -1.2158947438001633e-01
    z[0,1,4]  R114      5.3107652813196182e-02
    z[0,1,4]  R115      3.2538601756095886e-01
    z[0,1,4]  R116      5.5658418685197830e-02
    z[0,1,4]  R117      -1.0907003283500671e-01
    z[0,1,4]  R118      -2.5865745544433594e-01
    z[0,1,4]  R119      3.1789198517799377e-01
    z[0,1,4]  R120      -3.3076703548431396e-01
    z[0,1,4]  R121      2.2788918018341064e-01
    z[0,1,4]  R122      -3.0153882503509521e-01
    z[0,1,4]  R123      -2.3667715489864349e-01
    z[0,1,4]  R124      -3.1775414943695068e-01
    z[0,1,4]  R125      -2.4732597172260284e-01
    z[0,1,4]  R126      -4.9626824259757996e-01
    z[0,1,4]  R127      -3.7221285700798035e-01
    z[0,1,4]  R128      -4.7242611646652222e-01
    z[0,1,4]  R129      -8.9234240353107452e-02
    z[0,1,4]  R130      -6.1968307942152023e-02
    z[0,1,4]  R131      -5.1120370626449585e-01
    z[0,1,4]  R132      -3.1448808312416077e-01
    z[0,1,4]  R133      3.5533782839775085e-01
    z[0,1,4]  R134      -6.0251239687204361e-02
    z[0,1,4]  R135      1.3012728095054626e-01
    z[0,1,4]  R136      1.3269375264644623e-01
    z[0,1,4]  R137      -2.1954169869422913e-01
    z[0,1,4]  R138      -1.6888792812824249e-01
    z[0,1,4]  R139      -3.0619928240776062e-01
    z[0,1,4]  R140      -0.377180278301239
    z[0,1,4]  R141      -1.5033121220767498e-02
    z[0,1,4]  R142      1.1791370809078217e-01
    z[0,1,4]  R143      -1.9858722388744354e-01
    z[0,1,4]  R144      -1.1424652487039566e-01
    z[0,1,4]  R145      -3.3420909196138382e-02
    z[0,1,4]  R146      -1.7674843966960907e-01
    z[0,1,4]  R147      -1.8118312954902649e-01
    z[0,1,4]  R148      -2.3258654773235321e-01
    z[0,1,4]  R149      -1.8965248763561249e-01
    z[0,1,4]  R150      -4.0404719114303589e-01
    z[0,1,4]  R151      -0.604387640953064
    z[0,1,4]  R152      1.1300739832222462e-02
    z[0,1,4]  R153      -2.0947778224945068e-01
    z[0,1,4]  R154      -1.9690012931823730e-01
    z[0,1,4]  R155      -2.1455359458923340e-01
    z[0,1,4]  R156      -2.3748318850994110e-01
    z[0,1,4]  R157      -6.2412753701210022e-02
    z[0,1,4]  R158      -1.3878914760425687e-03
    z[0,1,4]  R159      -2.9972249269485474e-01
    z[0,1,4]  R160      1.0240171849727631e-01
    z[0,1,4]  R161      -5.8105643838644028e-02
    z[0,1,4]  R162      -1.6127350926399231e-01
    z[0,1,4]  R163      -2.2873380780220032e-01
    z[0,1,4]  R164      4.9016959965229034e-02
    z[0,1,4]  R165      -1.7113342881202698e-01
    z[0,1,4]  R166      -1.5119731426239014e-01
    z[0,1,4]  R167      4.2914608120918274e-01
    z[0,1,4]  R168      -2.2236181795597076e-01
    z[0,1,4]  R169      -6.6458338499069214e-01
    z[0,1,4]  R170      -5.0531399250030518e-01
    z[0,1,4]  R171      -3.9694091677665710e-01
    z[0,1,4]  R172      -1.5275681018829346e-01
    z[0,1,4]  R173      1.0644120723009109e-01
    z[0,1,4]  R174      1.7732322216033936e-01
    z[0,1,4]  R175      7.3642139323055744e-03
    z[0,1,4]  R176      -1.9135577976703644e-01
    z[0,1,4]  R177      -1.1073070764541626e-01
    z[0,1,4]  R178      -2.5646522641181946e-01
    z[0,1,4]  R179      3.7055090069770813e-01
    z[0,1,4]  R180      -1.3561026751995087e-01
    z[0,1,4]  R181      1.8353927135467529e-01
    z[0,1,4]  R182      -3.0290371179580688e-01
    z[0,1,4]  R183      -1.1322285234928131e-01
    z[0,1,4]  R184      -4.3514337390661240e-02
    z[0,1,4]  R185      -0.0205116905272007
    z[0,1,4]  R186      -3.3465218544006348e-01
    z[0,1,4]  R187      4.6316260099411011e-01
    z[0,1,4]  R188      1.8530224263668060e-01
    z[0,1,4]  R189      -1.2988176941871643e-01
    z[0,1,4]  R190      -3.2258176803588867e-01
    z[0,1,4]  R191      2.8929686173796654e-02
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R84       -1
    z[0,1,5]  R85       1
    z[0,1,5]  R88       4.2095273733139038e-01
    z[0,1,5]  R89       4.6164900064468384e-02
    z[0,1,5]  R90       0.888314425945282
    z[0,1,5]  R91       0.0393720380961895
    z[0,1,5]  R92       1.5032701194286346e-01
    z[0,1,5]  R93       -4.4183483719825745e-01
    z[0,1,5]  R94       -4.6526364982128143e-02
    z[0,1,5]  R95       -3.4537929296493530e-01
    z[0,1,5]  R96       -1.9897958636283875e-01
    z[0,1,5]  R97       -2.0626088976860046e-01
    z[0,1,5]  R98       -3.5083314776420593e-01
    z[0,1,5]  R99       -3.3018547296524048e-01
    z[0,1,5]  R100      -0.0353008508682251
    z[0,1,5]  R101      -2.8835389018058777e-01
    z[0,1,5]  R102      1.1513948440551758e-01
    z[0,1,5]  R103      -1.8897391855716705e-01
    z[0,1,5]  R104      -3.6671742796897888e-01
    z[0,1,5]  R105      -4.4244265556335449e-01
    z[0,1,5]  R106      -4.8432428389787674e-02
    z[0,1,5]  R107      -3.1014522910118103e-01
    z[0,1,5]  R108      -4.4662556052207947e-01
    z[0,1,5]  R109      -4.4381716847419739e-01
    z[0,1,5]  R110      1.8448434770107269e-02
    z[0,1,5]  R111      1.4546078443527222e-01
    z[0,1,5]  R112      -2.7747803926467896e-01
    z[0,1,5]  R113      8.6794808506965637e-02
    z[0,1,5]  R114      2.6432502269744873e-01
    z[0,1,5]  R115      -1.2706659734249115e-01
    z[0,1,5]  R116      -2.2977589070796967e-01
    z[0,1,5]  R117      2.9454892873764038e-01
    z[0,1,5]  R118      2.3581004142761230e-01
    z[0,1,5]  R119      -1.3369787484407425e-02
    z[0,1,5]  R120      -3.8183709979057312e-01
    z[0,1,5]  R121      2.2445890307426453e-01
    z[0,1,5]  R122      4.2150229215621948e-01
    z[0,1,5]  R123      2.1082273125648499e-01
    z[0,1,5]  R124      5.2028131484985352e-01
    z[0,1,5]  R125      7.8177213668823242e-02
    z[0,1,5]  R126      3.8318881392478943e-01
    z[0,1,5]  R127      0.501187264919281
    z[0,1,5]  R128      -1.0809244960546494e-01
    z[0,1,5]  R129      -3.3803563565015793e-02
    z[0,1,5]  R130      0.270234078168869
    z[0,1,5]  R131      3.6921831965446472e-01
    z[0,1,5]  R132      -1.7713992297649384e-01
    z[0,1,5]  R133      1.2475472688674927e-01
    z[0,1,5]  R134      2.3245538771152496e-01
    z[0,1,5]  R135      3.6535343527793884e-01
    z[0,1,5]  R136      -9.7938925027847290e-03
    z[0,1,5]  R137      3.3562558889389038e-01
    z[0,1,5]  R138      -7.2778813540935516e-02
    z[0,1,5]  R139      5.8214765787124634e-01
    z[0,1,5]  R140      6.7344211041927338e-02
    z[0,1,5]  R141      -3.1684139370918274e-01
    z[0,1,5]  R142      2.0376870408654213e-02
    z[0,1,5]  R143      1.8445710837841034e-01
    z[0,1,5]  R144      5.0468164682388306e-01
    z[0,1,5]  R145      2.7623368427157402e-02
    z[0,1,5]  R146      -9.8482377827167511e-02
    z[0,1,5]  R147      -1.5143278241157532e-01
    z[0,1,5]  R148      5.1329664885997772e-02
    z[0,1,5]  R149      1.0537500679492950e-01
    z[0,1,5]  R150      -8.6735926568508148e-02
    z[0,1,5]  R151      -1.1086606979370117e-01
    z[0,1,5]  R152      -2.3266993463039398e-01
    z[0,1,5]  R153      -4.4520515203475952e-01
    z[0,1,5]  R154      2.3093423247337341e-01
    z[0,1,5]  R155      1.9628649950027466e-01
    z[0,1,5]  R156      4.6226605772972107e-03
    z[0,1,5]  R157      4.9770256876945496e-01
    z[0,1,5]  R158      -1.0162238776683807e-01
    z[0,1,5]  R159      2.3632700741291046e-01
    z[0,1,5]  R160      3.2093369960784912e-01
    z[0,1,5]  R161      -0.42711141705513
    z[0,1,5]  R162      -3.2793802022933960e-01
    z[0,1,5]  R163      1.5501849353313446e-01
    z[0,1,5]  R164      3.2618772983551025e-01
    z[0,1,5]  R165      4.2262414097785950e-01
    z[0,1,5]  R166      3.3062899112701416e-01
    z[0,1,5]  R167      4.0845975279808044e-01
    z[0,1,5]  R168      -7.3691415786743164e-01
    z[0,1,5]  R169      -4.9031883478164673e-01
    z[0,1,5]  R170      -0.678159236907959
    z[0,1,5]  R171      -7.0835208892822266e-01
    z[0,1,5]  R172      2.3761945962905884e-01
    z[0,1,5]  R173      2.4640648066997528e-01
    z[0,1,5]  R174      -5.8739602565765381e-02
    z[0,1,5]  R175      -2.0139248669147491e-01
    z[0,1,5]  R176      5.5107432603836060e-01
    z[0,1,5]  R177      0.358646959066391
    z[0,1,5]  R178      -6.2370300292968750e-01
    z[0,1,5]  R179      -2.7175009250640869e-02
    z[0,1,5]  R180      -4.7938090562820435e-01
    z[0,1,5]  R181      -6.8554812669754028e-01
    z[0,1,5]  R182      0.240728497505188
    z[0,1,5]  R183      5.8204138278961182e-01
    z[0,1,5]  R184      1.8889984115958214e-02
    z[0,1,5]  R185      6.4875751733779907e-02
    z[0,1,5]  R186      6.2053400278091431e-01
    z[0,1,5]  R187      1.5324059128761292e-01
    z[0,1,5]  R188      -3.1326818466186523e-01
    z[0,1,5]  R189      -4.7536367177963257e-01
    z[0,1,5]  R190      -2.0229713618755341e-01
    z[0,1,5]  R191      -8.7680689990520477e-02
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R86       -1
    z[0,1,6]  R87       1
    z[0,1,6]  R88       -2.1621546149253845e-01
    z[0,1,6]  R89       -2.4528577923774719e-01
    z[0,1,6]  R90       1.8378733098506927e-01
    z[0,1,6]  R91       7.8131055831909180e-01
    z[0,1,6]  R92       4.8125660419464111e-01
    z[0,1,6]  R93       -2.3336930200457573e-02
    z[0,1,6]  R94       -2.1960224211215973e-01
    z[0,1,6]  R95       -3.7968782708048820e-03
    z[0,1,6]  R96       2.3038852214813232e-01
    z[0,1,6]  R97       3.1047138571739197e-01
    z[0,1,6]  R98       1.8163545429706573e-01
    z[0,1,6]  R99       -2.6451623439788818e-01
    z[0,1,6]  R100      -0.00923438835889101
    z[0,1,6]  R101      2.3285332322120667e-01
    z[0,1,6]  R102      -1.6244754195213318e-01
    z[0,1,6]  R103      1.5605975687503815e-01
    z[0,1,6]  R104      1.1168923974037170e-01
    z[0,1,6]  R105      -1.8076808750629425e-01
    z[0,1,6]  R106      5.6880284100770950e-02
    z[0,1,6]  R107      -1.4711982011795044e-01
    z[0,1,6]  R108      1.5826404094696045e-01
    z[0,1,6]  R109      5.3272429853677750e-02
    z[0,1,6]  R110      -0.0338151752948761
    z[0,1,6]  R111      -6.8323022127151489e-01
    z[0,1,6]  R112      1.7903280258178711e-01
    z[0,1,6]  R113      2.1552781760692596e-01
    z[0,1,6]  R114      -1.8531921505928040e-01
    z[0,1,6]  R115      -4.1614931076765060e-02
    z[0,1,6]  R116      -8.6111843585968018e-02
    z[0,1,6]  R117      1.7422136664390564e-01
    z[0,1,6]  R118      -2.1738973259925842e-01
    z[0,1,6]  R119      -2.2175389528274536e-01
    z[0,1,6]  R120      2.1136337518692017e-01
    z[0,1,6]  R121      -3.3586272597312927e-01
    z[0,1,6]  R122      2.3215837776660919e-01
    z[0,1,6]  R123      4.2681223154067993e-01
    z[0,1,6]  R124      4.9082913994789124e-01
    z[0,1,6]  R125      0.548614501953125
    z[0,1,6]  R126      5.6188172101974487e-01
    z[0,1,6]  R127      3.7740570306777954e-01
    z[0,1,6]  R128      2.4079778790473938e-01
    z[0,1,6]  R129      7.0146733522415161e-01
    z[0,1,6]  R130      5.0436311960220337e-01
    z[0,1,6]  R131      2.4577486515045166e-01
    z[0,1,6]  R132      -3.2198163866996765e-01
    z[0,1,6]  R133      1.0672981292009354e-01
    z[0,1,6]  R134      1.4407153427600861e-01
    z[0,1,6]  R135      3.9334241300821304e-02
    z[0,1,6]  R136      3.8813695311546326e-01
    z[0,1,6]  R137      2.6953229308128357e-01
    z[0,1,6]  R138      3.7290427088737488e-01
    z[0,1,6]  R139      2.6120588183403015e-01
    z[0,1,6]  R140      3.6627948284149170e-01
    z[0,1,6]  R141      -1.7489218711853027e-01
    z[0,1,6]  R142      -3.3026185631752014e-01
    z[0,1,6]  R143      2.1479737758636475e-01
    z[0,1,6]  R144      -2.4579374492168427e-01
    z[0,1,6]  R145      -3.0421912670135498e-02
    z[0,1,6]  R146      -1.5644830465316772e-01
    z[0,1,6]  R147      1.3995915651321411e-01
    z[0,1,6]  R148      -6.1815753579139709e-02
    z[0,1,6]  R149      -4.6537590026855469e-01
    z[0,1,6]  R150      -3.3084249496459961e-01
    z[0,1,6]  R151      -2.2959616780281067e-01
    z[0,1,6]  R152      1.6298945248126984e-01
    z[0,1,6]  R153      2.1789261698722839e-01
    z[0,1,6]  R154      6.7381441593170166e-02
    z[0,1,6]  R155      -1.1934030055999756e-01
    z[0,1,6]  R156      2.0152233541011810e-01
    z[0,1,6]  R157      1.1772727221250534e-01
    z[0,1,6]  R158      2.9406917095184326e-01
    z[0,1,6]  R159      -8.6259923875331879e-02
    z[0,1,6]  R160      -2.9275509715080261e-01
    z[0,1,6]  R161      -1.6995324194431305e-01
    z[0,1,6]  R162      -3.2412409782409668e-03
    z[0,1,6]  R163      3.4193581342697144e-01
    z[0,1,6]  R164      1.8364654481410980e-01
    z[0,1,6]  R165      -3.5997006297111511e-01
    z[0,1,6]  R166      -2.3075972497463226e-01
    z[0,1,6]  R167      2.1513873338699341e-01
    z[0,1,6]  R168      9.8632358014583588e-02
    z[0,1,6]  R169      6.1773583292961121e-02
    z[0,1,6]  R170      -2.1741646528244019e-01
    z[0,1,6]  R171      -0.35227170586586
    z[0,1,6]  R172      -2.1924762427806854e-01
    z[0,1,6]  R173      9.3395769596099854e-02
    z[0,1,6]  R174      -0.0913204550743103
    z[0,1,6]  R175      -4.8295024037361145e-01
    z[0,1,6]  R176      -5.7580333948135376e-01
    z[0,1,6]  R177      1.6845525801181793e-01
    z[0,1,6]  R178      1.4823305606842041e-01
    z[0,1,6]  R179      3.9097842574119568e-01
    z[0,1,6]  R180      3.6733604967594147e-02
    z[0,1,6]  R181      -7.2574533522129059e-02
    z[0,1,6]  R182      -2.1921820938587189e-01
    z[0,1,6]  R183      1.3556529302150011e-03
    z[0,1,6]  R184      -4.4133153557777405e-01
    z[0,1,6]  R185      -2.1631265059113503e-02
    z[0,1,6]  R186      -1.7923298478126526e-01
    z[0,1,6]  R187      -3.5379937291145325e-01
    z[0,1,6]  R188      1.1794251948595047e-01
    z[0,1,6]  R189      7.2125848382711411e-03
    z[0,1,6]  R190      2.1438100934028625e-01
    z[0,1,6]  R191      5.8446694165468216e-02
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R192      -1
    z[1,0,0]  R193      1
    z[1,0,0]  R206      0.792331874370575
    z[1,0,0]  R207      8.2360351085662842e-01
    z[1,0,0]  R208      0.825454592704773
    z[1,0,0]  R209      7.6305472850799561e-01
    z[1,0,0]  R210      9.1392600536346436e-01
    z[1,0,0]  R211      0.52276611328125
    z[1,0,0]  R212      0.848131537437439
    z[1,0,0]  R213      3.7846568226814270e-01
    z[1,0,0]  R214      -8.1787988543510437e-02
    z[1,0,0]  R215      -6.8388646841049194e-01
    z[1,0,0]  R216      -7.1314197778701782e-01
    z[1,0,0]  R217      -7.2746276855468750e-01
    z[1,0,0]  R218      -5.6805860996246338e-01
    z[1,0,0]  R219      -3.9287251234054565e-01
    z[1,0,0]  R220      -4.2372727394104004e-01
    z[1,0,0]  R221      -3.5243424773216248e-01
    z[1,0,0]  R222      -3.3037438988685608e-01
    z[1,0,0]  R223      -5.1508784294128418e-01
    z[1,0,0]  R224      -1.1502622812986374e-01
    z[1,0,0]  R225      -5.5213999748229980e-01
    z[1,0,0]  R226      -8.8299199938774109e-02
    z[1,0,0]  R227      -3.2991442084312439e-01
    z[1,0,0]  R228      -5.8540350198745728e-01
    z[1,0,0]  R229      -1.1914123594760895e-01
    z[1,0,0]  R230      -2.3966337740421295e-01
    z[1,0,0]  R231      -3.7223327159881592e-01
    z[1,0,0]  R232      -8.0146938562393188e-01
    z[1,0,0]  R233      -5.7806009054183960e-01
    z[1,0,0]  R234      -6.4372068643569946e-01
    z[1,0,0]  R235      -5.0161868333816528e-01
    z[1,0,0]  R236      -8.6371667683124542e-02
    z[1,0,0]  R237      1.6991788521409035e-02
    z[1,0,0]  R238      -6.1657375097274780e-01
    z[1,0,0]  R239      -9.1038918495178223e-01
    z[1,0,0]  R240      3.5387545824050903e-01
    z[1,0,0]  R241      -5.5890983343124390e-01
    z[1,0,0]  R242      -4.4688713550567627e-01
    z[1,0,0]  R243      -1.9498790800571442e-01
    z[1,0,0]  R244      -7.7668559551239014e-01
    z[1,0,0]  R245      -3.8441443443298340e-01
    z[1,0,0]  R246      -2.9512861371040344e-01
    z[1,0,0]  R247      -0.0926283597946167
    z[1,0,0]  R248      -8.3295780420303345e-01
    z[1,0,0]  R249      -7.3763936758041382e-01
    z[1,0,0]  R250      -8.3456999063491821e-01
    z[1,0,0]  R251      -7.8176146745681763e-01
    z[1,0,0]  R252      -7.6022058725357056e-01
    z[1,0,0]  R253      -5.2391797304153442e-01
    z[1,0,0]  R254      -8.8238435983657837e-01
    z[1,0,0]  R255      -6.3313668966293335e-01
    z[1,0,0]  R256      -8.8090650737285614e-02
    z[1,0,0]  R257      -2.4210691452026367e-01
    z[1,0,0]  R258      -8.2538688182830811e-01
    z[1,0,0]  R259      -3.1109073758125305e-01
    z[1,0,0]  R260      -2.5181236863136292e-01
    z[1,0,0]  R261      3.0048617720603943e-01
    z[1,0,0]  R262      -3.4604933857917786e-01
    z[1,0,0]  R263      -2.4814704060554504e-01
    z[1,0,0]  R264      -2.2024038434028625e-01
    z[1,0,0]  R265      -1.9153533875942230e-01
    z[1,0,0]  R266      -3.9020866155624390e-01
    z[1,0,0]  R267      -8.9242297410964966e-01
    z[1,0,0]  R268      -9.0254890918731689e-01
    z[1,0,0]  R269      -4.8743051290512085e-01
    z[1,0,0]  R270      -3.9723870158195496e-01
    z[1,0,0]  R271      2.5431382656097412e-01
    z[1,0,0]  R272      -2.8373831510543823e-01
    z[1,0,0]  R273      -7.5022215023636818e-03
    z[1,0,0]  R274      -4.0039947628974915e-01
    z[1,0,0]  R275      -0.390885591506958
    z[1,0,0]  R276      1.3482457399368286e-01
    z[1,0,0]  R277      -7.1054035425186157e-01
    z[1,0,0]  R278      -6.1111062765121460e-01
    z[1,0,0]  R279      3.4063592553138733e-01
    z[1,0,0]  R280      -2.8471186757087708e-01
    z[1,0,0]  R281      -4.9109966494143009e-03
    z[1,0,0]  R282      -4.6274831891059875e-01
    z[1,0,0]  R283      -4.1613438725471497e-01
    z[1,0,0]  R284      -3.3148407936096191e-01
    z[1,0,0]  R285      -0.0384528785943985
    z[1,0,0]  R286      -4.7193846106529236e-01
    z[1,0,0]  R287      1.1018313467502594e-01
    z[1,0,0]  R288      1.0481964051723480e-01
    z[1,0,0]  R289      -1.0138093680143356e-01
    z[1,0,0]  R290      1.9732140004634857e-01
    z[1,0,0]  R291      1.3901720941066742e-01
    z[1,0,0]  R292      3.7475538253784180e-01
    z[1,0,0]  R293      1.2003602460026741e-02
    z[1,0,0]  R294      5.5702839046716690e-02
    z[1,0,0]  R295      -5.8938987553119659e-02
    z[1,0,0]  R296      -1.3932450115680695e-01
    z[1,0,0]  R297      4.3517518043518066e-01
    z[1,0,0]  R298      4.4730097055435181e-01
    z[1,0,0]  R299      4.6356192231178284e-01
    z[1,0,0]  R300      3.5692679882049561e-01
    z[1,0,0]  R301      6.2341004610061646e-01
    z[1,0,0]  R302      9.8113574087619781e-02
    z[1,0,0]  R303      4.1323477029800415e-01
    z[1,0,0]  R304      1.2854509055614471e-01
    z[1,0,0]  R305      3.6500638723373413e-01
    z[1,0,0]  R306      5.0051051378250122e-01
    z[1,0,0]  R307      3.9290696382522583e-01
    z[1,0,0]  R308      3.7262195348739624e-01
    z[1,0,0]  R309      -4.5882124453783035e-02
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R194      -1
    z[1,0,1]  R195      1
    z[1,0,1]  R206      -1.0905101150274277e-01
    z[1,0,1]  R207      1.5836556255817413e-01
    z[1,0,1]  R208      1.2569531798362732e-01
    z[1,0,1]  R209      2.5770911574363708e-01
    z[1,0,1]  R210      -1.0237623006105423e-01
    z[1,0,1]  R211      -4.1197243332862854e-01
    z[1,0,1]  R212      -3.0243989825248718e-01
    z[1,0,1]  R213      -2.8250840306282043e-01
    z[1,0,1]  R214      7.2571784257888794e-01
    z[1,0,1]  R215      2.8844487667083740e-01
    z[1,0,1]  R216      1.3543620705604553e-01
    z[1,0,1]  R217      2.1578861773014069e-01
    z[1,0,1]  R218      2.0259724557399750e-01
    z[1,0,1]  R219      4.7164192795753479e-01
    z[1,0,1]  R220      -6.6417090594768524e-02
    z[1,0,1]  R221      -1.0809313505887985e-01
    z[1,0,1]  R222      -2.3711220920085907e-01
    z[1,0,1]  R223      2.8366753458976746e-01
    z[1,0,1]  R224      6.7696201801300049e-01
    z[1,0,1]  R225      -4.1145187616348267e-01
    z[1,0,1]  R226      8.4717440605163574e-01
    z[1,0,1]  R227      8.5122102499008179e-01
    z[1,0,1]  R228      2.0687554776668549e-01
    z[1,0,1]  R229      8.9596009254455566e-01
    z[1,0,1]  R230      0.419808566570282
    z[1,0,1]  R231      7.7928400039672852e-01
    z[1,0,1]  R232      -2.8380360454320908e-02
    z[1,0,1]  R233      0.0535450242459774
    z[1,0,1]  R234      -1.3417863845825195e-01
    z[1,0,1]  R235      4.8361358046531677e-01
    z[1,0,1]  R236      5.3514945507049561e-01
    z[1,0,1]  R237      4.9760690331459045e-01
    z[1,0,1]  R238      -2.2233970463275909e-01
    z[1,0,1]  R239      -3.3424004912376404e-01
    z[1,0,1]  R240      4.5104047656059265e-01
    z[1,0,1]  R241      3.2487812638282776e-01
    z[1,0,1]  R242      3.1988728046417236e-01
    z[1,0,1]  R243      -1.3790245354175568e-01
    z[1,0,1]  R244      1.8276622891426086e-01
    z[1,0,1]  R245      1.6258032619953156e-01
    z[1,0,1]  R246      0.658534049987793
    z[1,0,1]  R247      7.2154521942138672e-01
    z[1,0,1]  R248      9.6430137753486633e-02
    z[1,0,1]  R249      -2.9100757837295532e-01
    z[1,0,1]  R250      -1.7757755517959595e-01
    z[1,0,1]  R251      2.8576648235321045e-01
    z[1,0,1]  R252      3.4093910455703735e-01
    z[1,0,1]  R253      1.8604382872581482e-01
    z[1,0,1]  R254      -1.4244794845581055e-01
    z[1,0,1]  R255      1.3397786021232605e-01
    z[1,0,1]  R256      7.2524315118789673e-01
    z[1,0,1]  R257      6.8998634815216064e-01
    z[1,0,1]  R258      2.6473295688629150e-01
    z[1,0,1]  R259      7.2068822383880615e-01
    z[1,0,1]  R260      7.3601621389389038e-01
    z[1,0,1]  R261      3.9459916949272156e-01
    z[1,0,1]  R262      -0.512565016746521
    z[1,0,1]  R263      -4.3045002222061157e-01
    z[1,0,1]  R264      -4.1318696737289429e-01
    z[1,0,1]  R265      -3.9167153835296631e-01
    z[1,0,1]  R266      8.1174737215042114e-01
    z[1,0,1]  R267      2.1241806447505951e-01
    z[1,0,1]  R268      -1.6283838078379631e-02
    z[1,0,1]  R269      -1.2810570001602173e-01
    z[1,0,1]  R270      1.7376622557640076e-01
    z[1,0,1]  R271      5.9266769886016846e-01
    z[1,0,1]  R272      -6.2614244222640991e-01
    z[1,0,1]  R273      -6.3249868154525757e-01
    z[1,0,1]  R274      -5.1105105876922607e-01
    z[1,0,1]  R275      -3.7430158257484436e-01
    z[1,0,1]  R276      7.7420455217361450e-01
    z[1,0,1]  R277      2.3767906427383423e-01
    z[1,0,1]  R278      -1.1000989377498627e-01
    z[1,0,1]  R279      7.1379250288009644e-01
    z[1,0,1]  R280      -1.3433446176350117e-02
    z[1,0,1]  R281      0.693791925907135
    z[1,0,1]  R282      -4.7620710730552673e-01
    z[1,0,1]  R283      -5.3375661373138428e-01
    z[1,0,1]  R284      -5.4656445980072021e-01
    z[1,0,1]  R285      -0.770487368106842
    z[1,0,1]  R286      4.0633219480514526e-01
    z[1,0,1]  R287      3.6497992277145386e-01
    z[1,0,1]  R288      9.1564163565635681e-02
    z[1,0,1]  R289      -6.9874674081802368e-02
    z[1,0,1]  R290      2.0535512268543243e-01
    z[1,0,1]  R291      5.2349686622619629e-01
    z[1,0,1]  R292      3.8399979472160339e-01
    z[1,0,1]  R293      -5.3805607557296753e-01
    z[1,0,1]  R294      -7.4528193473815918e-01
    z[1,0,1]  R295      4.8454570770263672e-01
    z[1,0,1]  R296      -6.3817077875137329e-01
    z[1,0,1]  R297      -5.4885178804397583e-01
    z[1,0,1]  R298      -4.9646717309951782e-01
    z[1,0,1]  R299      -2.5711867213249207e-01
    z[1,0,1]  R300      -5.8885782957077026e-01
    z[1,0,1]  R301      -5.9335255622863770e-01
    z[1,0,1]  R302      -5.0874662399291992e-01
    z[1,0,1]  R303      -1.4740055799484253e-01
    z[1,0,1]  R304      -3.6910966038703918e-01
    z[1,0,1]  R305      -0.593457818031311
    z[1,0,1]  R306      -4.6988964080810547e-01
    z[1,0,1]  R307      -4.5893543958663940e-01
    z[1,0,1]  R308      -7.6876294612884521e-01
    z[1,0,1]  R309      -6.6079491376876831e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R196      -1
    z[1,0,2]  R197      1
    z[1,0,2]  R206      4.9007475376129150e-01
    z[1,0,2]  R207      4.3332302570343018e-01
    z[1,0,2]  R208      4.3423864245414734e-01
    z[1,0,2]  R209      4.5883128046989441e-01
    z[1,0,2]  R210      1.3983765617012978e-02
    z[1,0,2]  R211      3.9672231674194336e-01
    z[1,0,2]  R212      -4.8237197101116180e-02
    z[1,0,2]  R213      7.5016999244689941e-01
    z[1,0,2]  R214      4.5759268105030060e-02
    z[1,0,2]  R215      -4.7399401664733887e-01
    z[1,0,2]  R216      -2.5449833273887634e-01
    z[1,0,2]  R217      -3.9830714464187622e-02
    z[1,0,2]  R218      -8.1029146909713745e-02
    z[1,0,2]  R219      -4.7255808115005493e-01
    z[1,0,2]  R220      -3.2451364398002625e-01
    z[1,0,2]  R221      -5.6197357177734375e-01
    z[1,0,2]  R222      -7.3531186580657959e-01
    z[1,0,2]  R223      -3.0125150084495544e-01
    z[1,0,2]  R224      -4.2521965503692627e-01
    z[1,0,2]  R225      -2.5884151458740234e-01
    z[1,0,2]  R226      -8.2246296107769012e-02
    z[1,0,2]  R227      7.3520161211490631e-02
    z[1,0,2]  R228      -6.6690897941589355e-01
    z[1,0,2]  R229      1.5338120982050896e-02
    z[1,0,2]  R230      -5.3181946277618408e-01
    z[1,0,2]  R231      -1.4147794246673584e-01
    z[1,0,2]  R232      -4.2270419001579285e-01
    z[1,0,2]  R233      -0.382876992225647
    z[1,0,2]  R234      -5.3503000736236572e-01
    z[1,0,2]  R235      -4.7239184379577637e-01
    z[1,0,2]  R236      -2.2648519277572632e-01
    z[1,0,2]  R237      -5.0820887088775635e-01
    z[1,0,2]  R238      -4.1381460428237915e-01
    z[1,0,2]  R239      -1.9720740616321564e-01
    z[1,0,2]  R240      -6.2122678756713867e-01
    z[1,0,2]  R241      -4.2674034833908081e-01
    z[1,0,2]  R242      -4.9503925442695618e-01
    z[1,0,2]  R243      -8.2410043478012085e-01
    z[1,0,2]  R244      1.0093321651220322e-01
    z[1,0,2]  R245      -5.6082463264465332e-01
    z[1,0,2]  R246      9.7608342766761780e-02
    z[1,0,2]  R247      -3.7305000424385071e-01
    z[1,0,2]  R248      -2.8750467300415039e-01
    z[1,0,2]  R249      -5.1594811677932739e-01
    z[1,0,2]  R250      -4.1705605387687683e-01
    z[1,0,2]  R251      -7.9808674752712250e-02
    z[1,0,2]  R252      -4.5072114467620850e-01
    z[1,0,2]  R253      -5.7259029150009155e-01
    z[1,0,2]  R254      0.0425020195543766
    z[1,0,2]  R255      -5.8257788419723511e-01
    z[1,0,2]  R256      -2.9622277617454529e-01
    z[1,0,2]  R257      1.0739636421203613e-01
    z[1,0,2]  R258      -2.8401133418083191e-01
    z[1,0,2]  R259      -7.5146481394767761e-02
    z[1,0,2]  R260      4.0949344635009766e-01
    z[1,0,2]  R261      -5.9676694869995117e-01
    z[1,0,2]  R262      7.0104055106639862e-02
    z[1,0,2]  R263      2.5865691900253296e-01
    z[1,0,2]  R264      0.045010045170784
    z[1,0,2]  R265      2.1633841097354889e-03
    z[1,0,2]  R266      1.3381724059581757e-01
    z[1,0,2]  R267      -2.4735182523727417e-01
    z[1,0,2]  R268      -3.2939341664314270e-01
    z[1,0,2]  R269      -6.7971074581146240e-01
    z[1,0,2]  R270      -2.6860460638999939e-01
    z[1,0,2]  R271      -6.2600922584533691e-01
    z[1,0,2]  R272      7.3427930474281311e-02
    z[1,0,2]  R273      -5.4973983764648438e-01
    z[1,0,2]  R274      3.5052296519279480e-01
    z[1,0,2]  R275      1.9565726816654205e-01
    z[1,0,2]  R276      -0.0914430320262909
    z[1,0,2]  R277      -2.7722349762916565e-01
    z[1,0,2]  R278      -6.3867402076721191e-01
    z[1,0,2]  R279      -0.552993655204773
    z[1,0,2]  R280      -6.2353104352951050e-01
    z[1,0,2]  R281      -3.4796708822250366e-01
    z[1,0,2]  R282      2.6201891899108887e-01
    z[1,0,2]  R283      3.3248621225357056e-01
    z[1,0,2]  R284      4.4115567207336426e-01
    z[1,0,2]  R285      -1.0193391889333725e-01
    z[1,0,2]  R286      -2.9667532444000244e-01
    z[1,0,2]  R287      -5.8395648002624512e-01
    z[1,0,2]  R288      -1.6161238774657249e-02
    z[1,0,2]  R289      -3.1805202364921570e-01
    z[1,0,2]  R290      -3.6977049708366394e-01
    z[1,0,2]  R291      5.8368629217147827e-01
    z[1,0,2]  R292      6.7640066146850586e-01
    z[1,0,2]  R293      7.1182990074157715e-01
    z[1,0,2]  R294      -8.8471837341785431e-02
    z[1,0,2]  R295      6.7449682950973511e-01
    z[1,0,2]  R296      -3.2637748122215271e-01
    z[1,0,2]  R297      4.3346127867698669e-01
    z[1,0,2]  R298      6.3849735260009766e-01
    z[1,0,2]  R299      5.0912266969680786e-01
    z[1,0,2]  R300      0.470760315656662
    z[1,0,2]  R301      1.4835509657859802e-01
    z[1,0,2]  R302      0.646979570388794
    z[1,0,2]  R303      5.0280445814132690e-01
    z[1,0,2]  R304      7.0748674869537354e-01
    z[1,0,2]  R305      4.7013705968856812e-01
    z[1,0,2]  R306      4.1912484169006348e-01
    z[1,0,2]  R307      4.5609843730926514e-01
    z[1,0,2]  R308      5.1664119958877563e-01
    z[1,0,2]  R309      1.4599700272083282e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R198      -1
    z[1,0,3]  R199      1
    z[1,0,3]  R206      9.2287629842758179e-02
    z[1,0,3]  R207      -2.0014800131320953e-01
    z[1,0,3]  R208      -8.5034728050231934e-02
    z[1,0,3]  R209      1.3058932125568390e-01
    z[1,0,3]  R210      3.0125194787979126e-01
    z[1,0,3]  R211      0.520189642906189
    z[1,0,3]  R212      1.3079671561717987e-01
    z[1,0,3]  R213      2.5256437063217163e-01
    z[1,0,3]  R214      4.0579503774642944e-01
    z[1,0,3]  R215      0.0964856743812561
    z[1,0,3]  R216      2.9296535253524780e-01
    z[1,0,3]  R217      -3.7418681383132935e-01
    z[1,0,3]  R218      -1.3086028397083282e-01
    z[1,0,3]  R219      -1.7786049842834473e-01
    z[1,0,3]  R220      4.3679423630237579e-02
    z[1,0,3]  R221      1.2698574364185333e-01
    z[1,0,3]  R222      -3.3059798181056976e-02
    z[1,0,3]  R223      2.4960565567016602e-01
    z[1,0,3]  R224      1.2818354368209839e-01
    z[1,0,3]  R225      -2.8161531314253807e-02
    z[1,0,3]  R226      1.8379606306552887e-01
    z[1,0,3]  R227      8.9184358716011047e-02
    z[1,0,3]  R228      3.0218443274497986e-01
    z[1,0,3]  R229      -1.7567628622055054e-01
    z[1,0,3]  R230      5.6137013435363770e-01
    z[1,0,3]  R231      -2.5533020496368408e-02
    z[1,0,3]  R232      7.2698421776294708e-02
    z[1,0,3]  R233      1.2450806796550751e-01
    z[1,0,3]  R234      2.0046686753630638e-02
    z[1,0,3]  R235      4.0017595887184143e-01
    z[1,0,3]  R236      7.2901839017868042e-01
    z[1,0,3]  R237      6.1173772811889648e-01
    z[1,0,3]  R238      2.6643732190132141e-01
    z[1,0,3]  R239      1.3333716988563538e-01
    z[1,0,3]  R240      -4.6903842687606812e-01
    z[1,0,3]  R241      -5.6975334882736206e-01
    z[1,0,3]  R242      -6.2637668848037720e-01
    z[1,0,3]  R243      -1.3208748772740364e-02
    z[1,0,3]  R244      -2.7006399631500244e-01
    z[1,0,3]  R245      -0.284567654132843
    z[1,0,3]  R246      6.2359935045242310e-01
    z[1,0,3]  R247      2.0508620142936707e-01
    z[1,0,3]  R248      -3.4290376305580139e-01
    z[1,0,3]  R249      0.0787176638841629
    z[1,0,3]  R250      -3.1505491584539413e-02
    z[1,0,3]  R251      -1.8802741169929504e-01
    z[1,0,3]  R252      -7.6615914702415466e-02
    z[1,0,3]  R253      -4.5816308259963989e-01
    z[1,0,3]  R254      1.0480262339115143e-02
    z[1,0,3]  R255      -1.6463990509510040e-01
    z[1,0,3]  R256      4.9492558836936951e-01
    z[1,0,3]  R257      5.1039123535156250e-01
    z[1,0,3]  R258      1.5957221388816833e-01
    z[1,0,3]  R259      2.0176191627979279e-01
    z[1,0,3]  R260      2.0435136556625366e-01
    z[1,0,3]  R261      2.4046385660767555e-02
    z[1,0,3]  R262      1.0196488350629807e-01
    z[1,0,3]  R263      -1.8244255334138870e-02
    z[1,0,3]  R264      1.2740735709667206e-01
    z[1,0,3]  R265      1.6273528337478638e-01
    z[1,0,3]  R266      2.0743475854396820e-01
    z[1,0,3]  R267      1.2848366796970367e-01
    z[1,0,3]  R268      1.8277525901794434e-01
    z[1,0,3]  R269      -1.0069535672664642e-01
    z[1,0,3]  R270      -2.6078507304191589e-01
    z[1,0,3]  R271      1.5137994289398193e-01
    z[1,0,3]  R272      2.1282330155372620e-01
    z[1,0,3]  R273      8.2246467471122742e-02
    z[1,0,3]  R274      -4.5397719740867615e-01
    z[1,0,3]  R275      -3.9986866712570190e-01
    z[1,0,3]  R276      4.1989326477050781e-01
    z[1,0,3]  R277      -1.0096883773803711e-01
    z[1,0,3]  R278      -9.7536019980907440e-02
    z[1,0,3]  R279      -2.5212657451629639e-01
    z[1,0,3]  R280      2.8084175661206245e-02
    z[1,0,3]  R281      1.8539489805698395e-01
    z[1,0,3]  R282      -5.8655989170074463e-01
    z[1,0,3]  R283      -4.3416237831115723e-01
    z[1,0,3]  R284      -4.5367926359176636e-01
    z[1,0,3]  R285      -6.1849749088287354e-01
    z[1,0,3]  R286      -3.6269670724868774e-01
    z[1,0,3]  R287      5.2972659468650818e-02
    z[1,0,3]  R288      -1.9804526865482330e-01
    z[1,0,3]  R289      1.5918588638305664e-01
    z[1,0,3]  R290      6.8287521600723267e-01
    z[1,0,3]  R291      3.6385348439216614e-01
    z[1,0,3]  R292      3.5438263416290283e-01
    z[1,0,3]  R293      -2.3863545060157776e-01
    z[1,0,3]  R294      -4.0655103325843811e-01
    z[1,0,3]  R295      -4.0248352289199829e-01
    z[1,0,3]  R296      -4.9531683325767517e-01
    z[1,0,3]  R297      -3.7554952502250671e-01
    z[1,0,3]  R298      -3.6751943826675415e-01
    z[1,0,3]  R299      -5.6465232372283936e-01
    z[1,0,3]  R300      -4.4723954796791077e-01
    z[1,0,3]  R301      -3.7528955936431885e-01
    z[1,0,3]  R302      -4.0517678856849670e-01
    z[1,0,3]  R303      -5.7033616304397583e-01
    z[1,0,3]  R304      -5.8279848098754883e-01
    z[1,0,3]  R305      -1.9058936834335327e-01
    z[1,0,3]  R306      -3.2990479469299316e-01
    z[1,0,3]  R307      -0.409199982881546
    z[1,0,3]  R308      -1.2543281540274620e-02
    z[1,0,3]  R309      8.3574960008263588e-03
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R200      -1
    z[1,0,4]  R201      1
    z[1,0,4]  R206      5.0804324448108673e-02
    z[1,0,4]  R207      -1.2158947438001633e-01
    z[1,0,4]  R208      5.3107652813196182e-02
    z[1,0,4]  R209      3.2538601756095886e-01
    z[1,0,4]  R210      5.5658418685197830e-02
    z[1,0,4]  R211      -1.0907003283500671e-01
    z[1,0,4]  R212      -2.5865745544433594e-01
    z[1,0,4]  R213      3.1789198517799377e-01
    z[1,0,4]  R214      -3.3076703548431396e-01
    z[1,0,4]  R215      2.2788918018341064e-01
    z[1,0,4]  R216      -3.0153882503509521e-01
    z[1,0,4]  R217      -2.3667715489864349e-01
    z[1,0,4]  R218      -3.1775414943695068e-01
    z[1,0,4]  R219      -2.4732597172260284e-01
    z[1,0,4]  R220      -4.9626824259757996e-01
    z[1,0,4]  R221      -3.7221285700798035e-01
    z[1,0,4]  R222      -4.7242611646652222e-01
    z[1,0,4]  R223      -8.9234240353107452e-02
    z[1,0,4]  R224      -6.1968307942152023e-02
    z[1,0,4]  R225      -5.1120370626449585e-01
    z[1,0,4]  R226      -3.1448808312416077e-01
    z[1,0,4]  R227      3.5533782839775085e-01
    z[1,0,4]  R228      -6.0251239687204361e-02
    z[1,0,4]  R229      1.3012728095054626e-01
    z[1,0,4]  R230      1.3269375264644623e-01
    z[1,0,4]  R231      -2.1954169869422913e-01
    z[1,0,4]  R232      -1.6888792812824249e-01
    z[1,0,4]  R233      -3.0619928240776062e-01
    z[1,0,4]  R234      -0.377180278301239
    z[1,0,4]  R235      -1.5033121220767498e-02
    z[1,0,4]  R236      1.1791370809078217e-01
    z[1,0,4]  R237      -1.9858722388744354e-01
    z[1,0,4]  R238      -1.1424652487039566e-01
    z[1,0,4]  R239      -3.3420909196138382e-02
    z[1,0,4]  R240      -1.7674843966960907e-01
    z[1,0,4]  R241      -1.8118312954902649e-01
    z[1,0,4]  R242      -2.3258654773235321e-01
    z[1,0,4]  R243      -1.8965248763561249e-01
    z[1,0,4]  R244      -4.0404719114303589e-01
    z[1,0,4]  R245      -0.604387640953064
    z[1,0,4]  R246      1.1300739832222462e-02
    z[1,0,4]  R247      -2.0947778224945068e-01
    z[1,0,4]  R248      -1.9690012931823730e-01
    z[1,0,4]  R249      -2.1455359458923340e-01
    z[1,0,4]  R250      -2.3748318850994110e-01
    z[1,0,4]  R251      -6.2412753701210022e-02
    z[1,0,4]  R252      -1.3878914760425687e-03
    z[1,0,4]  R253      -2.9972249269485474e-01
    z[1,0,4]  R254      1.0240171849727631e-01
    z[1,0,4]  R255      -5.8105643838644028e-02
    z[1,0,4]  R256      -1.6127350926399231e-01
    z[1,0,4]  R257      -2.2873380780220032e-01
    z[1,0,4]  R258      4.9016959965229034e-02
    z[1,0,4]  R259      -1.7113342881202698e-01
    z[1,0,4]  R260      -1.5119731426239014e-01
    z[1,0,4]  R261      4.2914608120918274e-01
    z[1,0,4]  R262      -2.2236181795597076e-01
    z[1,0,4]  R263      -6.6458338499069214e-01
    z[1,0,4]  R264      -5.0531399250030518e-01
    z[1,0,4]  R265      -3.9694091677665710e-01
    z[1,0,4]  R266      -1.5275681018829346e-01
    z[1,0,4]  R267      1.0644120723009109e-01
    z[1,0,4]  R268      1.7732322216033936e-01
    z[1,0,4]  R269      7.3642139323055744e-03
    z[1,0,4]  R270      -1.9135577976703644e-01
    z[1,0,4]  R271      -1.1073070764541626e-01
    z[1,0,4]  R272      -2.5646522641181946e-01
    z[1,0,4]  R273      3.7055090069770813e-01
    z[1,0,4]  R274      -1.3561026751995087e-01
    z[1,0,4]  R275      1.8353927135467529e-01
    z[1,0,4]  R276      -3.0290371179580688e-01
    z[1,0,4]  R277      -1.1322285234928131e-01
    z[1,0,4]  R278      -4.3514337390661240e-02
    z[1,0,4]  R279      -0.0205116905272007
    z[1,0,4]  R280      -3.3465218544006348e-01
    z[1,0,4]  R281      4.6316260099411011e-01
    z[1,0,4]  R282      1.8530224263668060e-01
    z[1,0,4]  R283      -1.2988176941871643e-01
    z[1,0,4]  R284      -3.2258176803588867e-01
    z[1,0,4]  R285      2.8929686173796654e-02
    z[1,0,4]  R286      4.1067349910736084e-01
    z[1,0,4]  R287      -6.6973263025283813e-01
    z[1,0,4]  R288      -3.4389740228652954e-01
    z[1,0,4]  R289      4.9633234739303589e-01
    z[1,0,4]  R290      2.4827130138874054e-01
    z[1,0,4]  R291      1.9438037276268005e-01
    z[1,0,4]  R292      -2.8037112951278687e-01
    z[1,0,4]  R293      1.6553400456905365e-01
    z[1,0,4]  R294      -4.1912916302680969e-01
    z[1,0,4]  R295      -7.6593488454818726e-02
    z[1,0,4]  R296      -2.5571519136428833e-01
    z[1,0,4]  R297      -3.8300853222608566e-02
    z[1,0,4]  R298      9.6754379570484161e-02
    z[1,0,4]  R299      -5.9946998953819275e-02
    z[1,0,4]  R300      2.5409618020057678e-01
    z[1,0,4]  R301      1.9072329998016357e-01
    z[1,0,4]  R302      4.2938109487295151e-02
    z[1,0,4]  R303      3.1333111226558685e-02
    z[1,0,4]  R304      -3.8230195641517639e-02
    z[1,0,4]  R305      3.7335065007209778e-01
    z[1,0,4]  R306      -1.4024357497692108e-01
    z[1,0,4]  R307      2.4437731504440308e-01
    z[1,0,4]  R308      -3.9964348077774048e-02
    z[1,0,4]  R309      2.2781032323837280e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R202      -1
    z[1,0,5]  R203      1
    z[1,0,5]  R206      -2.7747803926467896e-01
    z[1,0,5]  R207      8.6794808506965637e-02
    z[1,0,5]  R208      2.6432502269744873e-01
    z[1,0,5]  R209      -1.2706659734249115e-01
    z[1,0,5]  R210      -2.2977589070796967e-01
    z[1,0,5]  R211      2.9454892873764038e-01
    z[1,0,5]  R212      2.3581004142761230e-01
    z[1,0,5]  R213      -1.3369787484407425e-02
    z[1,0,5]  R214      -3.8183709979057312e-01
    z[1,0,5]  R215      2.2445890307426453e-01
    z[1,0,5]  R216      4.2150229215621948e-01
    z[1,0,5]  R217      2.1082273125648499e-01
    z[1,0,5]  R218      5.2028131484985352e-01
    z[1,0,5]  R219      7.8177213668823242e-02
    z[1,0,5]  R220      3.8318881392478943e-01
    z[1,0,5]  R221      0.501187264919281
    z[1,0,5]  R222      -1.0809244960546494e-01
    z[1,0,5]  R223      -3.3803563565015793e-02
    z[1,0,5]  R224      0.270234078168869
    z[1,0,5]  R225      3.6921831965446472e-01
    z[1,0,5]  R226      -1.7713992297649384e-01
    z[1,0,5]  R227      1.2475472688674927e-01
    z[1,0,5]  R228      2.3245538771152496e-01
    z[1,0,5]  R229      3.6535343527793884e-01
    z[1,0,5]  R230      -9.7938925027847290e-03
    z[1,0,5]  R231      3.3562558889389038e-01
    z[1,0,5]  R232      -7.2778813540935516e-02
    z[1,0,5]  R233      5.8214765787124634e-01
    z[1,0,5]  R234      6.7344211041927338e-02
    z[1,0,5]  R235      -3.1684139370918274e-01
    z[1,0,5]  R236      2.0376870408654213e-02
    z[1,0,5]  R237      1.8445710837841034e-01
    z[1,0,5]  R238      5.0468164682388306e-01
    z[1,0,5]  R239      2.7623368427157402e-02
    z[1,0,5]  R240      -9.8482377827167511e-02
    z[1,0,5]  R241      -1.5143278241157532e-01
    z[1,0,5]  R242      5.1329664885997772e-02
    z[1,0,5]  R243      1.0537500679492950e-01
    z[1,0,5]  R244      -8.6735926568508148e-02
    z[1,0,5]  R245      -1.1086606979370117e-01
    z[1,0,5]  R246      -2.3266993463039398e-01
    z[1,0,5]  R247      -4.4520515203475952e-01
    z[1,0,5]  R248      2.3093423247337341e-01
    z[1,0,5]  R249      1.9628649950027466e-01
    z[1,0,5]  R250      4.6226605772972107e-03
    z[1,0,5]  R251      4.9770256876945496e-01
    z[1,0,5]  R252      -1.0162238776683807e-01
    z[1,0,5]  R253      2.3632700741291046e-01
    z[1,0,5]  R254      3.2093369960784912e-01
    z[1,0,5]  R255      -0.42711141705513
    z[1,0,5]  R256      -3.2793802022933960e-01
    z[1,0,5]  R257      1.5501849353313446e-01
    z[1,0,5]  R258      3.2618772983551025e-01
    z[1,0,5]  R259      4.2262414097785950e-01
    z[1,0,5]  R260      3.3062899112701416e-01
    z[1,0,5]  R261      4.0845975279808044e-01
    z[1,0,5]  R262      -7.3691415786743164e-01
    z[1,0,5]  R263      -4.9031883478164673e-01
    z[1,0,5]  R264      -0.678159236907959
    z[1,0,5]  R265      -7.0835208892822266e-01
    z[1,0,5]  R266      2.3761945962905884e-01
    z[1,0,5]  R267      2.4640648066997528e-01
    z[1,0,5]  R268      -5.8739602565765381e-02
    z[1,0,5]  R269      -2.0139248669147491e-01
    z[1,0,5]  R270      5.5107432603836060e-01
    z[1,0,5]  R271      0.358646959066391
    z[1,0,5]  R272      -6.2370300292968750e-01
    z[1,0,5]  R273      -2.7175009250640869e-02
    z[1,0,5]  R274      -4.7938090562820435e-01
    z[1,0,5]  R275      -6.8554812669754028e-01
    z[1,0,5]  R276      0.240728497505188
    z[1,0,5]  R277      5.8204138278961182e-01
    z[1,0,5]  R278      1.8889984115958214e-02
    z[1,0,5]  R279      6.4875751733779907e-02
    z[1,0,5]  R280      6.2053400278091431e-01
    z[1,0,5]  R281      1.5324059128761292e-01
    z[1,0,5]  R282      -3.1326818466186523e-01
    z[1,0,5]  R283      -4.7536367177963257e-01
    z[1,0,5]  R284      -2.0229713618755341e-01
    z[1,0,5]  R285      -8.7680689990520477e-02
    z[1,0,5]  R286      4.2095273733139038e-01
    z[1,0,5]  R287      4.6164900064468384e-02
    z[1,0,5]  R288      0.888314425945282
    z[1,0,5]  R289      0.0393720380961895
    z[1,0,5]  R290      1.5032701194286346e-01
    z[1,0,5]  R291      -4.4183483719825745e-01
    z[1,0,5]  R292      -4.6526364982128143e-02
    z[1,0,5]  R293      -3.4537929296493530e-01
    z[1,0,5]  R294      -1.9897958636283875e-01
    z[1,0,5]  R295      -2.0626088976860046e-01
    z[1,0,5]  R296      -3.5083314776420593e-01
    z[1,0,5]  R297      -3.3018547296524048e-01
    z[1,0,5]  R298      -0.0353008508682251
    z[1,0,5]  R299      -2.8835389018058777e-01
    z[1,0,5]  R300      1.1513948440551758e-01
    z[1,0,5]  R301      -1.8897391855716705e-01
    z[1,0,5]  R302      -3.6671742796897888e-01
    z[1,0,5]  R303      -4.4244265556335449e-01
    z[1,0,5]  R304      -4.8432428389787674e-02
    z[1,0,5]  R305      -3.1014522910118103e-01
    z[1,0,5]  R306      -4.4662556052207947e-01
    z[1,0,5]  R307      -4.4381716847419739e-01
    z[1,0,5]  R308      1.8448434770107269e-02
    z[1,0,5]  R309      1.4546078443527222e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R204      -1
    z[1,0,6]  R205      1
    z[1,0,6]  R206      1.7903280258178711e-01
    z[1,0,6]  R207      2.1552781760692596e-01
    z[1,0,6]  R208      -1.8531921505928040e-01
    z[1,0,6]  R209      -4.1614931076765060e-02
    z[1,0,6]  R210      -8.6111843585968018e-02
    z[1,0,6]  R211      1.7422136664390564e-01
    z[1,0,6]  R212      -2.1738973259925842e-01
    z[1,0,6]  R213      -2.2175389528274536e-01
    z[1,0,6]  R214      2.1136337518692017e-01
    z[1,0,6]  R215      -3.3586272597312927e-01
    z[1,0,6]  R216      2.3215837776660919e-01
    z[1,0,6]  R217      4.2681223154067993e-01
    z[1,0,6]  R218      4.9082913994789124e-01
    z[1,0,6]  R219      0.548614501953125
    z[1,0,6]  R220      5.6188172101974487e-01
    z[1,0,6]  R221      3.7740570306777954e-01
    z[1,0,6]  R222      2.4079778790473938e-01
    z[1,0,6]  R223      7.0146733522415161e-01
    z[1,0,6]  R224      5.0436311960220337e-01
    z[1,0,6]  R225      2.4577486515045166e-01
    z[1,0,6]  R226      -3.2198163866996765e-01
    z[1,0,6]  R227      1.0672981292009354e-01
    z[1,0,6]  R228      1.4407153427600861e-01
    z[1,0,6]  R229      3.9334241300821304e-02
    z[1,0,6]  R230      3.8813695311546326e-01
    z[1,0,6]  R231      2.6953229308128357e-01
    z[1,0,6]  R232      3.7290427088737488e-01
    z[1,0,6]  R233      2.6120588183403015e-01
    z[1,0,6]  R234      3.6627948284149170e-01
    z[1,0,6]  R235      -1.7489218711853027e-01
    z[1,0,6]  R236      -3.3026185631752014e-01
    z[1,0,6]  R237      2.1479737758636475e-01
    z[1,0,6]  R238      -2.4579374492168427e-01
    z[1,0,6]  R239      -3.0421912670135498e-02
    z[1,0,6]  R240      -1.5644830465316772e-01
    z[1,0,6]  R241      1.3995915651321411e-01
    z[1,0,6]  R242      -6.1815753579139709e-02
    z[1,0,6]  R243      -4.6537590026855469e-01
    z[1,0,6]  R244      -3.3084249496459961e-01
    z[1,0,6]  R245      -2.2959616780281067e-01
    z[1,0,6]  R246      1.6298945248126984e-01
    z[1,0,6]  R247      2.1789261698722839e-01
    z[1,0,6]  R248      6.7381441593170166e-02
    z[1,0,6]  R249      -1.1934030055999756e-01
    z[1,0,6]  R250      2.0152233541011810e-01
    z[1,0,6]  R251      1.1772727221250534e-01
    z[1,0,6]  R252      2.9406917095184326e-01
    z[1,0,6]  R253      -8.6259923875331879e-02
    z[1,0,6]  R254      -2.9275509715080261e-01
    z[1,0,6]  R255      -1.6995324194431305e-01
    z[1,0,6]  R256      -3.2412409782409668e-03
    z[1,0,6]  R257      3.4193581342697144e-01
    z[1,0,6]  R258      1.8364654481410980e-01
    z[1,0,6]  R259      -3.5997006297111511e-01
    z[1,0,6]  R260      -2.3075972497463226e-01
    z[1,0,6]  R261      2.1513873338699341e-01
    z[1,0,6]  R262      9.8632358014583588e-02
    z[1,0,6]  R263      6.1773583292961121e-02
    z[1,0,6]  R264      -2.1741646528244019e-01
    z[1,0,6]  R265      -0.35227170586586
    z[1,0,6]  R266      -2.1924762427806854e-01
    z[1,0,6]  R267      9.3395769596099854e-02
    z[1,0,6]  R268      -0.0913204550743103
    z[1,0,6]  R269      -4.8295024037361145e-01
    z[1,0,6]  R270      -5.7580333948135376e-01
    z[1,0,6]  R271      1.6845525801181793e-01
    z[1,0,6]  R272      1.4823305606842041e-01
    z[1,0,6]  R273      3.9097842574119568e-01
    z[1,0,6]  R274      3.6733604967594147e-02
    z[1,0,6]  R275      -7.2574533522129059e-02
    z[1,0,6]  R276      -2.1921820938587189e-01
    z[1,0,6]  R277      1.3556529302150011e-03
    z[1,0,6]  R278      -4.4133153557777405e-01
    z[1,0,6]  R279      -2.1631265059113503e-02
    z[1,0,6]  R280      -1.7923298478126526e-01
    z[1,0,6]  R281      -3.5379937291145325e-01
    z[1,0,6]  R282      1.1794251948595047e-01
    z[1,0,6]  R283      7.2125848382711411e-03
    z[1,0,6]  R284      2.1438100934028625e-01
    z[1,0,6]  R285      5.8446694165468216e-02
    z[1,0,6]  R286      -2.1621546149253845e-01
    z[1,0,6]  R287      -2.4528577923774719e-01
    z[1,0,6]  R288      1.8378733098506927e-01
    z[1,0,6]  R289      7.8131055831909180e-01
    z[1,0,6]  R290      4.8125660419464111e-01
    z[1,0,6]  R291      -2.3336930200457573e-02
    z[1,0,6]  R292      -2.1960224211215973e-01
    z[1,0,6]  R293      -3.7968782708048820e-03
    z[1,0,6]  R294      2.3038852214813232e-01
    z[1,0,6]  R295      3.1047138571739197e-01
    z[1,0,6]  R296      1.8163545429706573e-01
    z[1,0,6]  R297      -2.6451623439788818e-01
    z[1,0,6]  R298      -0.00923438835889101
    z[1,0,6]  R299      2.3285332322120667e-01
    z[1,0,6]  R300      -1.6244754195213318e-01
    z[1,0,6]  R301      1.5605975687503815e-01
    z[1,0,6]  R302      1.1168923974037170e-01
    z[1,0,6]  R303      -1.8076808750629425e-01
    z[1,0,6]  R304      5.6880284100770950e-02
    z[1,0,6]  R305      -1.4711982011795044e-01
    z[1,0,6]  R306      1.5826404094696045e-01
    z[1,0,6]  R307      5.3272429853677750e-02
    z[1,0,6]  R308      -0.0338151752948761
    z[1,0,6]  R309      -6.8323022127151489e-01
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R310      -1
    z[0,4,0]  R311      1
    z[0,4,0]  R324      -4.7193846106529236e-01
    z[0,4,0]  R325      1.1018313467502594e-01
    z[0,4,0]  R326      1.0481964051723480e-01
    z[0,4,0]  R327      -1.0138093680143356e-01
    z[0,4,0]  R328      1.9732140004634857e-01
    z[0,4,0]  R329      1.3901720941066742e-01
    z[0,4,0]  R330      3.7475538253784180e-01
    z[0,4,0]  R331      1.2003602460026741e-02
    z[0,4,0]  R332      5.5702839046716690e-02
    z[0,4,0]  R333      -5.8938987553119659e-02
    z[0,4,0]  R334      -1.3932450115680695e-01
    z[0,4,0]  R335      4.3517518043518066e-01
    z[0,4,0]  R336      4.4730097055435181e-01
    z[0,4,0]  R337      4.6356192231178284e-01
    z[0,4,0]  R338      3.5692679882049561e-01
    z[0,4,0]  R339      6.2341004610061646e-01
    z[0,4,0]  R340      9.8113574087619781e-02
    z[0,4,0]  R341      4.1323477029800415e-01
    z[0,4,0]  R342      1.2854509055614471e-01
    z[0,4,0]  R343      3.6500638723373413e-01
    z[0,4,0]  R344      5.0051051378250122e-01
    z[0,4,0]  R345      3.9290696382522583e-01
    z[0,4,0]  R346      3.7262195348739624e-01
    z[0,4,0]  R347      -4.5882124453783035e-02
    z[0,4,0]  R348      -2.8363308310508728e-01
    z[0,4,0]  R349      6.3270486891269684e-02
    z[0,4,0]  R350      1.0960305109620094e-02
    z[0,4,0]  R351      0.143471822142601
    z[0,4,0]  R352      -1.2894485890865326e-01
    z[0,4,0]  R353      -1.7774090170860291e-01
    z[0,4,0]  R354      -5.9229356050491333e-01
    z[0,4,0]  R355      -6.4346569776535034e-01
    z[0,4,0]  R356      -3.6360916495323181e-01
    z[0,4,0]  R357      -0.664874255657196
    z[0,4,0]  R358      -2.1831926703453064e-01
    z[0,4,0]  R359      2.9715850949287415e-01
    z[0,4,0]  R360      2.9847967624664307e-01
    z[0,4,0]  R361      3.3534556627273560e-01
    z[0,4,0]  R362      3.8330844044685364e-01
    z[0,4,0]  R363      3.4660476446151733e-01
    z[0,4,0]  R364      5.7784989476203918e-02
    z[0,4,0]  R365      3.1476294994354248e-01
    z[0,4,0]  R366      2.1589669585227966e-01
    z[0,4,0]  R367      2.0634412765502930e-01
    z[0,4,0]  R368      6.2413150072097778e-01
    z[0,4,0]  R369      6.6744023561477661e-01
    z[0,4,0]  R370      6.3662898540496826e-01
    z[0,4,0]  R371      5.0223106145858765e-01
    z[0,4,0]  R372      6.4914405345916748e-01
    z[0,4,0]  R373      4.7491988539695740e-01
    z[0,4,0]  R374      4.3309062719345093e-01
    z[0,4,0]  R375      -4.1635531187057495e-01
    z[0,4,0]  R376      5.1093876361846924e-01
    z[0,4,0]  R377      4.8697581887245178e-01
    z[0,4,0]  R378      -3.9949950575828552e-01
    z[0,4,0]  R379      -3.7090122699737549e-01
    z[0,4,0]  R380      6.1859232187271118e-01
    z[0,4,0]  R381      -1.2515333294868469e-01
    z[0,4,0]  R382      2.9414582252502441e-01
    z[0,4,0]  R383      4.4930049777030945e-01
    z[0,4,0]  R384      -1.1720172315835953e-01
    z[0,4,0]  R385      -1.2280052155256271e-01
    z[0,4,0]  R386      -5.0174880772829056e-02
    z[0,4,0]  R387      2.2930721938610077e-01
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R312      -1
    z[0,4,1]  R313      1
    z[0,4,1]  R324      4.0633219480514526e-01
    z[0,4,1]  R325      3.6497992277145386e-01
    z[0,4,1]  R326      9.1564163565635681e-02
    z[0,4,1]  R327      -6.9874674081802368e-02
    z[0,4,1]  R328      2.0535512268543243e-01
    z[0,4,1]  R329      5.2349686622619629e-01
    z[0,4,1]  R330      3.8399979472160339e-01
    z[0,4,1]  R331      -5.3805607557296753e-01
    z[0,4,1]  R332      -7.4528193473815918e-01
    z[0,4,1]  R333      4.8454570770263672e-01
    z[0,4,1]  R334      -6.3817077875137329e-01
    z[0,4,1]  R335      -5.4885178804397583e-01
    z[0,4,1]  R336      -4.9646717309951782e-01
    z[0,4,1]  R337      -2.5711867213249207e-01
    z[0,4,1]  R338      -5.8885782957077026e-01
    z[0,4,1]  R339      -5.9335255622863770e-01
    z[0,4,1]  R340      -5.0874662399291992e-01
    z[0,4,1]  R341      -1.4740055799484253e-01
    z[0,4,1]  R342      -3.6910966038703918e-01
    z[0,4,1]  R343      -0.593457818031311
    z[0,4,1]  R344      -4.6988964080810547e-01
    z[0,4,1]  R345      -4.5893543958663940e-01
    z[0,4,1]  R346      -7.6876294612884521e-01
    z[0,4,1]  R347      -6.6079491376876831e-01
    z[0,4,1]  R348      0.673723042011261
    z[0,4,1]  R349      3.1906521320343018e-01
    z[0,4,1]  R350      3.7437894940376282e-01
    z[0,4,1]  R351      7.3310643434524536e-01
    z[0,4,1]  R352      3.5284972190856934e-01
    z[0,4,1]  R353      4.1465076804161072e-01
    z[0,4,1]  R354      -5.9358751773834229e-01
    z[0,4,1]  R355      -1.6057939827442169e-01
    z[0,4,1]  R356      2.4091082811355591e-01
    z[0,4,1]  R357      -4.6989148855209351e-01
    z[0,4,1]  R358      -3.4238114953041077e-01
    z[0,4,1]  R359      -7.3204773664474487e-01
    z[0,4,1]  R360      -6.7584872245788574e-01
    z[0,4,1]  R361      -6.9339352846145630e-01
    z[0,4,1]  R362      -7.3640400171279907e-01
    z[0,4,1]  R363      -6.5614819526672363e-01
    z[0,4,1]  R364      -5.8755552768707275e-01
    z[0,4,1]  R365      -5.5656814575195312e-01
    z[0,4,1]  R366      -2.9664844274520874e-01
    z[0,4,1]  R367      -0.0769195556640625
    z[0,4,1]  R368      6.2265670299530029e-01
    z[0,4,1]  R369      2.6981109380722046e-01
    z[0,4,1]  R370      -3.9388540387153625e-01
    z[0,4,1]  R371      -5.8104431629180908e-01
    z[0,4,1]  R372      3.3632245659828186e-01
    z[0,4,1]  R373      -5.1232308149337769e-01
    z[0,4,1]  R374      6.2998533248901367e-01
    z[0,4,1]  R375      -5.2235430479049683e-01
    z[0,4,1]  R376      -5.2130079269409180e-01
    z[0,4,1]  R377      4.9059343338012695e-01
    z[0,4,1]  R378      -2.5148870423436165e-02
    z[0,4,1]  R379      2.5600403547286987e-01
    z[0,4,1]  R380      0.571380078792572
    z[0,4,1]  R381      -1.6271811723709106e-01
    z[0,4,1]  R382      -0.809425413608551
    z[0,4,1]  R383      2.4708189070224762e-02
    z[0,4,1]  R384      -3.8372665643692017e-01
    z[0,4,1]  R385      1.2259277701377869e-01
    z[0,4,1]  R386      -4.1192939877510071e-01
    z[0,4,1]  R387      -3.4744560718536377e-01
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R314      -1
    z[0,4,2]  R315      1
    z[0,4,2]  R324      -2.9667532444000244e-01
    z[0,4,2]  R325      -5.8395648002624512e-01
    z[0,4,2]  R326      -1.6161238774657249e-02
    z[0,4,2]  R327      -3.1805202364921570e-01
    z[0,4,2]  R328      -3.6977049708366394e-01
    z[0,4,2]  R329      5.8368629217147827e-01
    z[0,4,2]  R330      6.7640066146850586e-01
    z[0,4,2]  R331      7.1182990074157715e-01
    z[0,4,2]  R332      -8.8471837341785431e-02
    z[0,4,2]  R333      6.7449682950973511e-01
    z[0,4,2]  R334      -3.2637748122215271e-01
    z[0,4,2]  R335      4.3346127867698669e-01
    z[0,4,2]  R336      6.3849735260009766e-01
    z[0,4,2]  R337      5.0912266969680786e-01
    z[0,4,2]  R338      0.470760315656662
    z[0,4,2]  R339      1.4835509657859802e-01
    z[0,4,2]  R340      0.646979570388794
    z[0,4,2]  R341      5.0280445814132690e-01
    z[0,4,2]  R342      7.0748674869537354e-01
    z[0,4,2]  R343      4.7013705968856812e-01
    z[0,4,2]  R344      4.1912484169006348e-01
    z[0,4,2]  R345      4.5609843730926514e-01
    z[0,4,2]  R346      5.1664119958877563e-01
    z[0,4,2]  R347      1.4599700272083282e-01
    z[0,4,2]  R348      -4.8892641067504883e-01
    z[0,4,2]  R349      -6.2998455762863159e-01
    z[0,4,2]  R350      -5.6363517045974731e-01
    z[0,4,2]  R351      -3.2378584146499634e-01
    z[0,4,2]  R352      -1.9953134655952454e-01
    z[0,4,2]  R353      -0.620113730430603
    z[0,4,2]  R354      6.2657386064529419e-02
    z[0,4,2]  R355      -2.6013249158859253e-01
    z[0,4,2]  R356      -0.434576153755188
    z[0,4,2]  R357      3.1460583209991455e-02
    z[0,4,2]  R358      0.271842360496521
    z[0,4,2]  R359      2.4250237643718719e-01
    z[0,4,2]  R360      1.0891170054674149e-01
    z[0,4,2]  R361      2.4245100095868111e-02
    z[0,4,2]  R362      0.0978781208395958
    z[0,4,2]  R363      5.7753545045852661e-01
    z[0,4,2]  R364      1.5783621370792389e-01
    z[0,4,2]  R365      1.7953260242938995e-01
    z[0,4,2]  R366      5.6387925148010254e-01
    z[0,4,2]  R367      0.560340166091919
    z[0,4,2]  R368      2.2890008985996246e-01
    z[0,4,2]  R369      1.7778469622135162e-01
    z[0,4,2]  R370      4.6568965911865234e-01
    z[0,4,2]  R371      3.6825489997863770e-01
    z[0,4,2]  R372      2.3756980895996094e-01
    z[0,4,2]  R373      6.1661440134048462e-01
    z[0,4,2]  R374      3.5787844657897949e-01
    z[0,4,2]  R375      -5.4644995927810669e-01
    z[0,4,2]  R376      2.2522220015525818e-01
    z[0,4,2]  R377      4.9367386102676392e-01
    z[0,4,2]  R378      -4.3730321526527405e-01
    z[0,4,2]  R379      -5.3622430562973022e-01
    z[0,4,2]  R380      -3.2214820384979248e-02
    z[0,4,2]  R381      -6.5103453397750854e-01
    z[0,4,2]  R382      4.4995138049125671e-01
    z[0,4,2]  R383      3.8770538568496704e-01
    z[0,4,2]  R384      0.274767130613327
    z[0,4,2]  R385      2.0365764200687408e-01
    z[0,4,2]  R386      -1.8638806045055389e-01
    z[0,4,2]  R387      4.1917601227760315e-01
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R316      -1
    z[0,4,3]  R317      1
    z[0,4,3]  R324      -3.6269670724868774e-01
    z[0,4,3]  R325      5.2972659468650818e-02
    z[0,4,3]  R326      -1.9804526865482330e-01
    z[0,4,3]  R327      1.5918588638305664e-01
    z[0,4,3]  R328      6.8287521600723267e-01
    z[0,4,3]  R329      3.6385348439216614e-01
    z[0,4,3]  R330      3.5438263416290283e-01
    z[0,4,3]  R331      -2.3863545060157776e-01
    z[0,4,3]  R332      -4.0655103325843811e-01
    z[0,4,3]  R333      -4.0248352289199829e-01
    z[0,4,3]  R334      -4.9531683325767517e-01
    z[0,4,3]  R335      -3.7554952502250671e-01
    z[0,4,3]  R336      -3.6751943826675415e-01
    z[0,4,3]  R337      -5.6465232372283936e-01
    z[0,4,3]  R338      -4.4723954796791077e-01
    z[0,4,3]  R339      -3.7528955936431885e-01
    z[0,4,3]  R340      -4.0517678856849670e-01
    z[0,4,3]  R341      -5.7033616304397583e-01
    z[0,4,3]  R342      -5.8279848098754883e-01
    z[0,4,3]  R343      -1.9058936834335327e-01
    z[0,4,3]  R344      -3.2990479469299316e-01
    z[0,4,3]  R345      -0.409199982881546
    z[0,4,3]  R346      -1.2543281540274620e-02
    z[0,4,3]  R347      8.3574960008263588e-03
    z[0,4,3]  R348      1.7601533234119415e-01
    z[0,4,3]  R349      6.3435681164264679e-02
    z[0,4,3]  R350      5.8566421270370483e-01
    z[0,4,3]  R351      -3.1957533210515976e-02
    z[0,4,3]  R352      5.4880738258361816e-01
    z[0,4,3]  R353      1.8849761784076691e-01
    z[0,4,3]  R354      -4.1592246294021606e-01
    z[0,4,3]  R355      4.2277574539184570e-02
    z[0,4,3]  R356      1.8614079058170319e-01
    z[0,4,3]  R357      -4.5220154523849487e-01
    z[0,4,3]  R358      5.7858824729919434e-01
    z[0,4,3]  R359      5.5579996109008789e-01
    z[0,4,3]  R360      4.6628028154373169e-01
    z[0,4,3]  R361      4.5316961407661438e-01
    z[0,4,3]  R362      3.1654286384582520e-01
    z[0,4,3]  R363      -0.199876606464386
    z[0,4,3]  R364      -8.6203165352344513e-02
    z[0,4,3]  R365      -7.4223525822162628e-02
    z[0,4,3]  R366      -4.8704904317855835e-01
    z[0,4,3]  R367      -7.8237777948379517e-01
    z[0,4,3]  R368      2.0347169041633606e-01
    z[0,4,3]  R369      6.4545780420303345e-01
    z[0,4,3]  R370      -4.2889210581779480e-01
    z[0,4,3]  R371      -2.3227228224277496e-01
    z[0,4,3]  R372      4.8670306801795959e-01
    z[0,4,3]  R373      -3.0853557586669922e-01
    z[0,4,3]  R374      2.4328298866748810e-01
    z[0,4,3]  R375      3.3010223507881165e-01
    z[0,4,3]  R376      -3.7748065590858459e-01
    z[0,4,3]  R377      3.1534847617149353e-01
    z[0,4,3]  R378      -0.0200671274214983
    z[0,4,3]  R379      -3.9867699146270752e-02
    z[0,4,3]  R380      3.2048463821411133e-01
    z[0,4,3]  R381      3.5661211609840393e-01
    z[0,4,3]  R382      -1.7238807678222656e-01
    z[0,4,3]  R383      -5.8072954416275024e-01
    z[0,4,3]  R384      -2.3731626570224762e-01
    z[0,4,3]  R385      -4.9800008535385132e-01
    z[0,4,3]  R386      -5.2545249462127686e-01
    z[0,4,3]  R387      -4.3838983774185181e-01
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R318      -1
    z[0,4,4]  R319      1
    z[0,4,4]  R324      4.1067349910736084e-01
    z[0,4,4]  R325      -6.6973263025283813e-01
    z[0,4,4]  R326      -3.4389740228652954e-01
    z[0,4,4]  R327      4.9633234739303589e-01
    z[0,4,4]  R328      2.4827130138874054e-01
    z[0,4,4]  R329      1.9438037276268005e-01
    z[0,4,4]  R330      -2.8037112951278687e-01
    z[0,4,4]  R331      1.6553400456905365e-01
    z[0,4,4]  R332      -4.1912916302680969e-01
    z[0,4,4]  R333      -7.6593488454818726e-02
    z[0,4,4]  R334      -2.5571519136428833e-01
    z[0,4,4]  R335      -3.8300853222608566e-02
    z[0,4,4]  R336      9.6754379570484161e-02
    z[0,4,4]  R337      -5.9946998953819275e-02
    z[0,4,4]  R338      2.5409618020057678e-01
    z[0,4,4]  R339      1.9072329998016357e-01
    z[0,4,4]  R340      4.2938109487295151e-02
    z[0,4,4]  R341      3.1333111226558685e-02
    z[0,4,4]  R342      -3.8230195641517639e-02
    z[0,4,4]  R343      3.7335065007209778e-01
    z[0,4,4]  R344      -1.4024357497692108e-01
    z[0,4,4]  R345      2.4437731504440308e-01
    z[0,4,4]  R346      -3.9964348077774048e-02
    z[0,4,4]  R347      2.2781032323837280e-01
    z[0,4,4]  R348      1.0856717824935913e-02
    z[0,4,4]  R349      -6.5588361024856567e-01
    z[0,4,4]  R350      1.2484563887119293e-01
    z[0,4,4]  R351      -1.9584220647811890e-01
    z[0,4,4]  R352      4.2634099721908569e-01
    z[0,4,4]  R353      1.5479709208011627e-01
    z[0,4,4]  R354      -1.2218625284731388e-02
    z[0,4,4]  R355      1.0611588507890701e-01
    z[0,4,4]  R356      1.1072899401187897e-01
    z[0,4,4]  R357      2.9332062602043152e-01
    z[0,4,4]  R358      -5.2169007062911987e-01
    z[0,4,4]  R359      1.5225443989038467e-02
    z[0,4,4]  R360      -2.0152826607227325e-01
    z[0,4,4]  R361      -1.9289699196815491e-01
    z[0,4,4]  R362      -3.3994954824447632e-01
    z[0,4,4]  R363      -8.9647211134433746e-02
    z[0,4,4]  R364      1.7738105356693268e-01
    z[0,4,4]  R365      -9.9142849445343018e-02
    z[0,4,4]  R366      -1.1770591139793396e-01
    z[0,4,4]  R367      1.3046446442604065e-01
    z[0,4,4]  R368      3.9614226669073105e-02
    z[0,4,4]  R369      -1.8910236656665802e-02
    z[0,4,4]  R370      -9.0951457619667053e-02
    z[0,4,4]  R371      -1.7323465645313263e-01
    z[0,4,4]  R372      -1.4452171325683594e-01
    z[0,4,4]  R373      1.5978337824344635e-01
    z[0,4,4]  R374      4.5616424083709717e-01
    z[0,4,4]  R375      -1.4891673624515533e-01
    z[0,4,4]  R376      2.0689669251441956e-01
    z[0,4,4]  R377      3.5767704248428345e-01
    z[0,4,4]  R378      -3.1594979763031006e-01
    z[0,4,4]  R379      0.0851435512304306
    z[0,4,4]  R380      -2.1339073777198792e-01
    z[0,4,4]  R381      -2.2136293351650238e-01
    z[0,4,4]  R382      -3.1325586140155792e-02
    z[0,4,4]  R383      -2.7960114181041718e-02
    z[0,4,4]  R384      2.5202789902687073e-01
    z[0,4,4]  R385      3.7080907821655273e-01
    z[0,4,4]  R386      -5.0051814317703247e-01
    z[0,4,4]  R387      -2.6815861463546753e-01
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R320      -1
    z[0,4,5]  R321      1
    z[0,4,5]  R324      4.2095273733139038e-01
    z[0,4,5]  R325      4.6164900064468384e-02
    z[0,4,5]  R326      0.888314425945282
    z[0,4,5]  R327      0.0393720380961895
    z[0,4,5]  R328      1.5032701194286346e-01
    z[0,4,5]  R329      -4.4183483719825745e-01
    z[0,4,5]  R330      -4.6526364982128143e-02
    z[0,4,5]  R331      -3.4537929296493530e-01
    z[0,4,5]  R332      -1.9897958636283875e-01
    z[0,4,5]  R333      -2.0626088976860046e-01
    z[0,4,5]  R334      -3.5083314776420593e-01
    z[0,4,5]  R335      -3.3018547296524048e-01
    z[0,4,5]  R336      -0.0353008508682251
    z[0,4,5]  R337      -2.8835389018058777e-01
    z[0,4,5]  R338      1.1513948440551758e-01
    z[0,4,5]  R339      -1.8897391855716705e-01
    z[0,4,5]  R340      -3.6671742796897888e-01
    z[0,4,5]  R341      -4.4244265556335449e-01
    z[0,4,5]  R342      -4.8432428389787674e-02
    z[0,4,5]  R343      -3.1014522910118103e-01
    z[0,4,5]  R344      -4.4662556052207947e-01
    z[0,4,5]  R345      -4.4381716847419739e-01
    z[0,4,5]  R346      1.8448434770107269e-02
    z[0,4,5]  R347      1.4546078443527222e-01
    z[0,4,5]  R348      4.3001264333724976e-01
    z[0,4,5]  R349      8.8137343525886536e-02
    z[0,4,5]  R350      -2.9693683981895447e-01
    z[0,4,5]  R351      -1.1963365972042084e-01
    z[0,4,5]  R352      1.2636837363243103e-01
    z[0,4,5]  R353      -5.9129250049591064e-01
    z[0,4,5]  R354      3.1540271639823914e-01
    z[0,4,5]  R355      0.552384614944458
    z[0,4,5]  R356      6.9784924387931824e-02
    z[0,4,5]  R357      -7.4164181947708130e-02
    z[0,4,5]  R358      -7.4610225856304169e-03
    z[0,4,5]  R359      4.2120195925235748e-02
    z[0,4,5]  R360      1.1479678004980087e-01
    z[0,4,5]  R361      -2.1093097329139709e-01
    z[0,4,5]  R362      -1.3658192753791809e-01
    z[0,4,5]  R363      -2.2241917252540588e-01
    z[0,4,5]  R364      -7.5781798362731934e-01
    z[0,4,5]  R365      -7.0537918806076050e-01
    z[0,4,5]  R366      -1.0778035968542099e-01
    z[0,4,5]  R367      -4.7113727778196335e-02
    z[0,4,5]  R368      -8.1583723425865173e-02
    z[0,4,5]  R369      1.5470467507839203e-01
    z[0,4,5]  R370      -9.5077134668827057e-02
    z[0,4,5]  R371      -4.2949426174163818e-01
    z[0,4,5]  R372      3.4728178381919861e-01
    z[0,4,5]  R373      0.0904572531580925
    z[0,4,5]  R374      -1.4110137522220612e-01
    z[0,4,5]  R375      1.1845245212316513e-01
    z[0,4,5]  R376      -3.1538268923759460e-01
    z[0,4,5]  R377      1.9393399357795715e-01
    z[0,4,5]  R378      4.2377910017967224e-01
    z[0,4,5]  R379      -0.395780086517334
    z[0,4,5]  R380      -1.7386563122272491e-02
    z[0,4,5]  R381      -2.4130217730998993e-01
    z[0,4,5]  R382      -1.4675861597061157e-01
    z[0,4,5]  R383      -4.1860324144363403e-01
    z[0,4,5]  R384      -4.0268743038177490e-01
    z[0,4,5]  R385      -6.7394733428955078e-01
    z[0,4,5]  R386      -0.511361837387085
    z[0,4,5]  R387      0.00314392801374197
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R322      -1
    z[0,4,6]  R323      1
    z[0,4,6]  R324      -2.1621546149253845e-01
    z[0,4,6]  R325      -2.4528577923774719e-01
    z[0,4,6]  R326      1.8378733098506927e-01
    z[0,4,6]  R327      7.8131055831909180e-01
    z[0,4,6]  R328      4.8125660419464111e-01
    z[0,4,6]  R329      -2.3336930200457573e-02
    z[0,4,6]  R330      -2.1960224211215973e-01
    z[0,4,6]  R331      -3.7968782708048820e-03
    z[0,4,6]  R332      2.3038852214813232e-01
    z[0,4,6]  R333      3.1047138571739197e-01
    z[0,4,6]  R334      1.8163545429706573e-01
    z[0,4,6]  R335      -2.6451623439788818e-01
    z[0,4,6]  R336      -0.00923438835889101
    z[0,4,6]  R337      2.3285332322120667e-01
    z[0,4,6]  R338      -1.6244754195213318e-01
    z[0,4,6]  R339      1.5605975687503815e-01
    z[0,4,6]  R340      1.1168923974037170e-01
    z[0,4,6]  R341      -1.8076808750629425e-01
    z[0,4,6]  R342      5.6880284100770950e-02
    z[0,4,6]  R343      -1.4711982011795044e-01
    z[0,4,6]  R344      1.5826404094696045e-01
    z[0,4,6]  R345      5.3272429853677750e-02
    z[0,4,6]  R346      -0.0338151752948761
    z[0,4,6]  R347      -6.8323022127151489e-01
    z[0,4,6]  R348      1.0290885716676712e-01
    z[0,4,6]  R349      -2.3524037003517151e-01
    z[0,4,6]  R350      -3.0866688489913940e-01
    z[0,4,6]  R351      -5.3239649534225464e-01
    z[0,4,6]  R352      -5.6580251455307007e-01
    z[0,4,6]  R353      -5.3024794906377792e-02
    z[0,4,6]  R354      -1.4246550202369690e-01
    z[0,4,6]  R355      -4.1751712560653687e-01
    z[0,4,6]  R356      -0.754396915435791
    z[0,4,6]  R357      2.0032688975334167e-01
    z[0,4,6]  R358      3.9272508025169373e-01
    z[0,4,6]  R359      7.7948756515979767e-02
    z[0,4,6]  R360      4.1360282897949219e-01
    z[0,4,6]  R361      3.4510451555252075e-01
    z[0,4,6]  R362      2.5842586159706116e-01
    z[0,4,6]  R363      1.3538759946823120e-01
    z[0,4,6]  R364      1.1551665514707565e-01
    z[0,4,6]  R365      0.214536651968956
    z[0,4,6]  R366      -5.3361082077026367e-01
    z[0,4,6]  R367      7.8541055321693420e-02
    z[0,4,6]  R368      3.4747272729873657e-01
    z[0,4,6]  R369      0.0959746390581131
    z[0,4,6]  R370      -1.4639247953891754e-01
    z[0,4,6]  R371      -7.8190825879573822e-02
    z[0,4,6]  R372      -1.7518197000026703e-01
    z[0,4,6]  R373      5.3436309099197388e-02
    z[0,4,6]  R374      -1.7086308449506760e-02
    z[0,4,6]  R375      3.3168086409568787e-01
    z[0,4,6]  R376      -3.6290207505226135e-01
    z[0,4,6]  R377      -1.1606375873088837e-01
    z[0,4,6]  R378      -6.0722154378890991e-01
    z[0,4,6]  R379      -5.8641022443771362e-01
    z[0,4,6]  R380      3.7587514519691467e-01
    z[0,4,6]  R381      0.547369122505188
    z[0,4,6]  R382      -6.0128502547740936e-02
    z[0,4,6]  R383      0.365986168384552
    z[0,4,6]  R384      -6.9392108917236328e-01
    z[0,4,6]  R385      -2.9783570766448975e-01
    z[0,4,6]  R386      -7.0330560207366943e-02
    z[0,4,6]  R387      6.2200218439102173e-01
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R388      -1
    z[4,0,0]  R389      1
    z[4,0,0]  R402      -2.8363308310508728e-01
    z[4,0,0]  R403      6.3270486891269684e-02
    z[4,0,0]  R404      1.0960305109620094e-02
    z[4,0,0]  R405      0.143471822142601
    z[4,0,0]  R406      -1.2894485890865326e-01
    z[4,0,0]  R407      -1.7774090170860291e-01
    z[4,0,0]  R408      -5.9229356050491333e-01
    z[4,0,0]  R409      -6.4346569776535034e-01
    z[4,0,0]  R410      -3.6360916495323181e-01
    z[4,0,0]  R411      -0.664874255657196
    z[4,0,0]  R412      -2.1831926703453064e-01
    z[4,0,0]  R413      2.9715850949287415e-01
    z[4,0,0]  R414      2.9847967624664307e-01
    z[4,0,0]  R415      3.3534556627273560e-01
    z[4,0,0]  R416      3.8330844044685364e-01
    z[4,0,0]  R417      3.4660476446151733e-01
    z[4,0,0]  R418      5.7784989476203918e-02
    z[4,0,0]  R419      3.1476294994354248e-01
    z[4,0,0]  R420      2.1589669585227966e-01
    z[4,0,0]  R421      2.0634412765502930e-01
    z[4,0,0]  R422      6.2413150072097778e-01
    z[4,0,0]  R423      6.6744023561477661e-01
    z[4,0,0]  R424      6.3662898540496826e-01
    z[4,0,0]  R425      5.0223106145858765e-01
    z[4,0,0]  R426      6.4914405345916748e-01
    z[4,0,0]  R427      4.7491988539695740e-01
    z[4,0,0]  R428      4.3309062719345093e-01
    z[4,0,0]  R429      -4.1635531187057495e-01
    z[4,0,0]  R430      5.1093876361846924e-01
    z[4,0,0]  R431      4.8697581887245178e-01
    z[4,0,0]  R432      -3.9949950575828552e-01
    z[4,0,0]  R433      -3.7090122699737549e-01
    z[4,0,0]  R434      6.1859232187271118e-01
    z[4,0,0]  R435      -1.2515333294868469e-01
    z[4,0,0]  R436      2.9414582252502441e-01
    z[4,0,0]  R437      4.4930049777030945e-01
    z[4,0,0]  R438      -1.1720172315835953e-01
    z[4,0,0]  R439      -1.2280052155256271e-01
    z[4,0,0]  R440      -5.0174880772829056e-02
    z[4,0,0]  R441      2.2930721938610077e-01
    z[4,0,0]  R442      -4.7193846106529236e-01
    z[4,0,0]  R443      1.1018313467502594e-01
    z[4,0,0]  R444      1.0481964051723480e-01
    z[4,0,0]  R445      -1.0138093680143356e-01
    z[4,0,0]  R446      1.9732140004634857e-01
    z[4,0,0]  R447      1.3901720941066742e-01
    z[4,0,0]  R448      3.7475538253784180e-01
    z[4,0,0]  R449      1.2003602460026741e-02
    z[4,0,0]  R450      5.5702839046716690e-02
    z[4,0,0]  R451      -5.8938987553119659e-02
    z[4,0,0]  R452      -1.3932450115680695e-01
    z[4,0,0]  R453      4.3517518043518066e-01
    z[4,0,0]  R454      4.4730097055435181e-01
    z[4,0,0]  R455      4.6356192231178284e-01
    z[4,0,0]  R456      3.5692679882049561e-01
    z[4,0,0]  R457      6.2341004610061646e-01
    z[4,0,0]  R458      9.8113574087619781e-02
    z[4,0,0]  R459      4.1323477029800415e-01
    z[4,0,0]  R460      1.2854509055614471e-01
    z[4,0,0]  R461      3.6500638723373413e-01
    z[4,0,0]  R462      5.0051051378250122e-01
    z[4,0,0]  R463      3.9290696382522583e-01
    z[4,0,0]  R464      3.7262195348739624e-01
    z[4,0,0]  R465      -4.5882124453783035e-02
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R390      -1
    z[4,0,1]  R391      1
    z[4,0,1]  R402      0.673723042011261
    z[4,0,1]  R403      3.1906521320343018e-01
    z[4,0,1]  R404      3.7437894940376282e-01
    z[4,0,1]  R405      7.3310643434524536e-01
    z[4,0,1]  R406      3.5284972190856934e-01
    z[4,0,1]  R407      4.1465076804161072e-01
    z[4,0,1]  R408      -5.9358751773834229e-01
    z[4,0,1]  R409      -1.6057939827442169e-01
    z[4,0,1]  R410      2.4091082811355591e-01
    z[4,0,1]  R411      -4.6989148855209351e-01
    z[4,0,1]  R412      -3.4238114953041077e-01
    z[4,0,1]  R413      -7.3204773664474487e-01
    z[4,0,1]  R414      -6.7584872245788574e-01
    z[4,0,1]  R415      -6.9339352846145630e-01
    z[4,0,1]  R416      -7.3640400171279907e-01
    z[4,0,1]  R417      -6.5614819526672363e-01
    z[4,0,1]  R418      -5.8755552768707275e-01
    z[4,0,1]  R419      -5.5656814575195312e-01
    z[4,0,1]  R420      -2.9664844274520874e-01
    z[4,0,1]  R421      -0.0769195556640625
    z[4,0,1]  R422      6.2265670299530029e-01
    z[4,0,1]  R423      2.6981109380722046e-01
    z[4,0,1]  R424      -3.9388540387153625e-01
    z[4,0,1]  R425      -5.8104431629180908e-01
    z[4,0,1]  R426      3.3632245659828186e-01
    z[4,0,1]  R427      -5.1232308149337769e-01
    z[4,0,1]  R428      6.2998533248901367e-01
    z[4,0,1]  R429      -5.2235430479049683e-01
    z[4,0,1]  R430      -5.2130079269409180e-01
    z[4,0,1]  R431      4.9059343338012695e-01
    z[4,0,1]  R432      -2.5148870423436165e-02
    z[4,0,1]  R433      2.5600403547286987e-01
    z[4,0,1]  R434      0.571380078792572
    z[4,0,1]  R435      -1.6271811723709106e-01
    z[4,0,1]  R436      -0.809425413608551
    z[4,0,1]  R437      2.4708189070224762e-02
    z[4,0,1]  R438      -3.8372665643692017e-01
    z[4,0,1]  R439      1.2259277701377869e-01
    z[4,0,1]  R440      -4.1192939877510071e-01
    z[4,0,1]  R441      -3.4744560718536377e-01
    z[4,0,1]  R442      4.0633219480514526e-01
    z[4,0,1]  R443      3.6497992277145386e-01
    z[4,0,1]  R444      9.1564163565635681e-02
    z[4,0,1]  R445      -6.9874674081802368e-02
    z[4,0,1]  R446      2.0535512268543243e-01
    z[4,0,1]  R447      5.2349686622619629e-01
    z[4,0,1]  R448      3.8399979472160339e-01
    z[4,0,1]  R449      -5.3805607557296753e-01
    z[4,0,1]  R450      -7.4528193473815918e-01
    z[4,0,1]  R451      4.8454570770263672e-01
    z[4,0,1]  R452      -6.3817077875137329e-01
    z[4,0,1]  R453      -5.4885178804397583e-01
    z[4,0,1]  R454      -4.9646717309951782e-01
    z[4,0,1]  R455      -2.5711867213249207e-01
    z[4,0,1]  R456      -5.8885782957077026e-01
    z[4,0,1]  R457      -5.9335255622863770e-01
    z[4,0,1]  R458      -5.0874662399291992e-01
    z[4,0,1]  R459      -1.4740055799484253e-01
    z[4,0,1]  R460      -3.6910966038703918e-01
    z[4,0,1]  R461      -0.593457818031311
    z[4,0,1]  R462      -4.6988964080810547e-01
    z[4,0,1]  R463      -4.5893543958663940e-01
    z[4,0,1]  R464      -7.6876294612884521e-01
    z[4,0,1]  R465      -6.6079491376876831e-01
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R392      -1
    z[4,0,2]  R393      1
    z[4,0,2]  R402      -4.8892641067504883e-01
    z[4,0,2]  R403      -6.2998455762863159e-01
    z[4,0,2]  R404      -5.6363517045974731e-01
    z[4,0,2]  R405      -3.2378584146499634e-01
    z[4,0,2]  R406      -1.9953134655952454e-01
    z[4,0,2]  R407      -0.620113730430603
    z[4,0,2]  R408      6.2657386064529419e-02
    z[4,0,2]  R409      -2.6013249158859253e-01
    z[4,0,2]  R410      -0.434576153755188
    z[4,0,2]  R411      3.1460583209991455e-02
    z[4,0,2]  R412      0.271842360496521
    z[4,0,2]  R413      2.4250237643718719e-01
    z[4,0,2]  R414      1.0891170054674149e-01
    z[4,0,2]  R415      2.4245100095868111e-02
    z[4,0,2]  R416      0.0978781208395958
    z[4,0,2]  R417      5.7753545045852661e-01
    z[4,0,2]  R418      1.5783621370792389e-01
    z[4,0,2]  R419      1.7953260242938995e-01
    z[4,0,2]  R420      5.6387925148010254e-01
    z[4,0,2]  R421      0.560340166091919
    z[4,0,2]  R422      2.2890008985996246e-01
    z[4,0,2]  R423      1.7778469622135162e-01
    z[4,0,2]  R424      4.6568965911865234e-01
    z[4,0,2]  R425      3.6825489997863770e-01
    z[4,0,2]  R426      2.3756980895996094e-01
    z[4,0,2]  R427      6.1661440134048462e-01
    z[4,0,2]  R428      3.5787844657897949e-01
    z[4,0,2]  R429      -5.4644995927810669e-01
    z[4,0,2]  R430      2.2522220015525818e-01
    z[4,0,2]  R431      4.9367386102676392e-01
    z[4,0,2]  R432      -4.3730321526527405e-01
    z[4,0,2]  R433      -5.3622430562973022e-01
    z[4,0,2]  R434      -3.2214820384979248e-02
    z[4,0,2]  R435      -6.5103453397750854e-01
    z[4,0,2]  R436      4.4995138049125671e-01
    z[4,0,2]  R437      3.8770538568496704e-01
    z[4,0,2]  R438      0.274767130613327
    z[4,0,2]  R439      2.0365764200687408e-01
    z[4,0,2]  R440      -1.8638806045055389e-01
    z[4,0,2]  R441      4.1917601227760315e-01
    z[4,0,2]  R442      -2.9667532444000244e-01
    z[4,0,2]  R443      -5.8395648002624512e-01
    z[4,0,2]  R444      -1.6161238774657249e-02
    z[4,0,2]  R445      -3.1805202364921570e-01
    z[4,0,2]  R446      -3.6977049708366394e-01
    z[4,0,2]  R447      5.8368629217147827e-01
    z[4,0,2]  R448      6.7640066146850586e-01
    z[4,0,2]  R449      7.1182990074157715e-01
    z[4,0,2]  R450      -8.8471837341785431e-02
    z[4,0,2]  R451      6.7449682950973511e-01
    z[4,0,2]  R452      -3.2637748122215271e-01
    z[4,0,2]  R453      4.3346127867698669e-01
    z[4,0,2]  R454      6.3849735260009766e-01
    z[4,0,2]  R455      5.0912266969680786e-01
    z[4,0,2]  R456      0.470760315656662
    z[4,0,2]  R457      1.4835509657859802e-01
    z[4,0,2]  R458      0.646979570388794
    z[4,0,2]  R459      5.0280445814132690e-01
    z[4,0,2]  R460      7.0748674869537354e-01
    z[4,0,2]  R461      4.7013705968856812e-01
    z[4,0,2]  R462      4.1912484169006348e-01
    z[4,0,2]  R463      4.5609843730926514e-01
    z[4,0,2]  R464      5.1664119958877563e-01
    z[4,0,2]  R465      1.4599700272083282e-01
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R394      -1
    z[4,0,3]  R395      1
    z[4,0,3]  R402      1.7601533234119415e-01
    z[4,0,3]  R403      6.3435681164264679e-02
    z[4,0,3]  R404      5.8566421270370483e-01
    z[4,0,3]  R405      -3.1957533210515976e-02
    z[4,0,3]  R406      5.4880738258361816e-01
    z[4,0,3]  R407      1.8849761784076691e-01
    z[4,0,3]  R408      -4.1592246294021606e-01
    z[4,0,3]  R409      4.2277574539184570e-02
    z[4,0,3]  R410      1.8614079058170319e-01
    z[4,0,3]  R411      -4.5220154523849487e-01
    z[4,0,3]  R412      5.7858824729919434e-01
    z[4,0,3]  R413      5.5579996109008789e-01
    z[4,0,3]  R414      4.6628028154373169e-01
    z[4,0,3]  R415      4.5316961407661438e-01
    z[4,0,3]  R416      3.1654286384582520e-01
    z[4,0,3]  R417      -0.199876606464386
    z[4,0,3]  R418      -8.6203165352344513e-02
    z[4,0,3]  R419      -7.4223525822162628e-02
    z[4,0,3]  R420      -4.8704904317855835e-01
    z[4,0,3]  R421      -7.8237777948379517e-01
    z[4,0,3]  R422      2.0347169041633606e-01
    z[4,0,3]  R423      6.4545780420303345e-01
    z[4,0,3]  R424      -4.2889210581779480e-01
    z[4,0,3]  R425      -2.3227228224277496e-01
    z[4,0,3]  R426      4.8670306801795959e-01
    z[4,0,3]  R427      -3.0853557586669922e-01
    z[4,0,3]  R428      2.4328298866748810e-01
    z[4,0,3]  R429      3.3010223507881165e-01
    z[4,0,3]  R430      -3.7748065590858459e-01
    z[4,0,3]  R431      3.1534847617149353e-01
    z[4,0,3]  R432      -0.0200671274214983
    z[4,0,3]  R433      -3.9867699146270752e-02
    z[4,0,3]  R434      3.2048463821411133e-01
    z[4,0,3]  R435      3.5661211609840393e-01
    z[4,0,3]  R436      -1.7238807678222656e-01
    z[4,0,3]  R437      -5.8072954416275024e-01
    z[4,0,3]  R438      -2.3731626570224762e-01
    z[4,0,3]  R439      -4.9800008535385132e-01
    z[4,0,3]  R440      -5.2545249462127686e-01
    z[4,0,3]  R441      -4.3838983774185181e-01
    z[4,0,3]  R442      -3.6269670724868774e-01
    z[4,0,3]  R443      5.2972659468650818e-02
    z[4,0,3]  R444      -1.9804526865482330e-01
    z[4,0,3]  R445      1.5918588638305664e-01
    z[4,0,3]  R446      6.8287521600723267e-01
    z[4,0,3]  R447      3.6385348439216614e-01
    z[4,0,3]  R448      3.5438263416290283e-01
    z[4,0,3]  R449      -2.3863545060157776e-01
    z[4,0,3]  R450      -4.0655103325843811e-01
    z[4,0,3]  R451      -4.0248352289199829e-01
    z[4,0,3]  R452      -4.9531683325767517e-01
    z[4,0,3]  R453      -3.7554952502250671e-01
    z[4,0,3]  R454      -3.6751943826675415e-01
    z[4,0,3]  R455      -5.6465232372283936e-01
    z[4,0,3]  R456      -4.4723954796791077e-01
    z[4,0,3]  R457      -3.7528955936431885e-01
    z[4,0,3]  R458      -4.0517678856849670e-01
    z[4,0,3]  R459      -5.7033616304397583e-01
    z[4,0,3]  R460      -5.8279848098754883e-01
    z[4,0,3]  R461      -1.9058936834335327e-01
    z[4,0,3]  R462      -3.2990479469299316e-01
    z[4,0,3]  R463      -0.409199982881546
    z[4,0,3]  R464      -1.2543281540274620e-02
    z[4,0,3]  R465      8.3574960008263588e-03
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R396      -1
    z[4,0,4]  R397      1
    z[4,0,4]  R402      1.0856717824935913e-02
    z[4,0,4]  R403      -6.5588361024856567e-01
    z[4,0,4]  R404      1.2484563887119293e-01
    z[4,0,4]  R405      -1.9584220647811890e-01
    z[4,0,4]  R406      4.2634099721908569e-01
    z[4,0,4]  R407      1.5479709208011627e-01
    z[4,0,4]  R408      -1.2218625284731388e-02
    z[4,0,4]  R409      1.0611588507890701e-01
    z[4,0,4]  R410      1.1072899401187897e-01
    z[4,0,4]  R411      2.9332062602043152e-01
    z[4,0,4]  R412      -5.2169007062911987e-01
    z[4,0,4]  R413      1.5225443989038467e-02
    z[4,0,4]  R414      -2.0152826607227325e-01
    z[4,0,4]  R415      -1.9289699196815491e-01
    z[4,0,4]  R416      -3.3994954824447632e-01
    z[4,0,4]  R417      -8.9647211134433746e-02
    z[4,0,4]  R418      1.7738105356693268e-01
    z[4,0,4]  R419      -9.9142849445343018e-02
    z[4,0,4]  R420      -1.1770591139793396e-01
    z[4,0,4]  R421      1.3046446442604065e-01
    z[4,0,4]  R422      3.9614226669073105e-02
    z[4,0,4]  R423      -1.8910236656665802e-02
    z[4,0,4]  R424      -9.0951457619667053e-02
    z[4,0,4]  R425      -1.7323465645313263e-01
    z[4,0,4]  R426      -1.4452171325683594e-01
    z[4,0,4]  R427      1.5978337824344635e-01
    z[4,0,4]  R428      4.5616424083709717e-01
    z[4,0,4]  R429      -1.4891673624515533e-01
    z[4,0,4]  R430      2.0689669251441956e-01
    z[4,0,4]  R431      3.5767704248428345e-01
    z[4,0,4]  R432      -3.1594979763031006e-01
    z[4,0,4]  R433      0.0851435512304306
    z[4,0,4]  R434      -2.1339073777198792e-01
    z[4,0,4]  R435      -2.2136293351650238e-01
    z[4,0,4]  R436      -3.1325586140155792e-02
    z[4,0,4]  R437      -2.7960114181041718e-02
    z[4,0,4]  R438      2.5202789902687073e-01
    z[4,0,4]  R439      3.7080907821655273e-01
    z[4,0,4]  R440      -5.0051814317703247e-01
    z[4,0,4]  R441      -2.6815861463546753e-01
    z[4,0,4]  R442      4.1067349910736084e-01
    z[4,0,4]  R443      -6.6973263025283813e-01
    z[4,0,4]  R444      -3.4389740228652954e-01
    z[4,0,4]  R445      4.9633234739303589e-01
    z[4,0,4]  R446      2.4827130138874054e-01
    z[4,0,4]  R447      1.9438037276268005e-01
    z[4,0,4]  R448      -2.8037112951278687e-01
    z[4,0,4]  R449      1.6553400456905365e-01
    z[4,0,4]  R450      -4.1912916302680969e-01
    z[4,0,4]  R451      -7.6593488454818726e-02
    z[4,0,4]  R452      -2.5571519136428833e-01
    z[4,0,4]  R453      -3.8300853222608566e-02
    z[4,0,4]  R454      9.6754379570484161e-02
    z[4,0,4]  R455      -5.9946998953819275e-02
    z[4,0,4]  R456      2.5409618020057678e-01
    z[4,0,4]  R457      1.9072329998016357e-01
    z[4,0,4]  R458      4.2938109487295151e-02
    z[4,0,4]  R459      3.1333111226558685e-02
    z[4,0,4]  R460      -3.8230195641517639e-02
    z[4,0,4]  R461      3.7335065007209778e-01
    z[4,0,4]  R462      -1.4024357497692108e-01
    z[4,0,4]  R463      2.4437731504440308e-01
    z[4,0,4]  R464      -3.9964348077774048e-02
    z[4,0,4]  R465      2.2781032323837280e-01
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R398      -1
    z[4,0,5]  R399      1
    z[4,0,5]  R402      4.3001264333724976e-01
    z[4,0,5]  R403      8.8137343525886536e-02
    z[4,0,5]  R404      -2.9693683981895447e-01
    z[4,0,5]  R405      -1.1963365972042084e-01
    z[4,0,5]  R406      1.2636837363243103e-01
    z[4,0,5]  R407      -5.9129250049591064e-01
    z[4,0,5]  R408      3.1540271639823914e-01
    z[4,0,5]  R409      0.552384614944458
    z[4,0,5]  R410      6.9784924387931824e-02
    z[4,0,5]  R411      -7.4164181947708130e-02
    z[4,0,5]  R412      -7.4610225856304169e-03
    z[4,0,5]  R413      4.2120195925235748e-02
    z[4,0,5]  R414      1.1479678004980087e-01
    z[4,0,5]  R415      -2.1093097329139709e-01
    z[4,0,5]  R416      -1.3658192753791809e-01
    z[4,0,5]  R417      -2.2241917252540588e-01
    z[4,0,5]  R418      -7.5781798362731934e-01
    z[4,0,5]  R419      -7.0537918806076050e-01
    z[4,0,5]  R420      -1.0778035968542099e-01
    z[4,0,5]  R421      -4.7113727778196335e-02
    z[4,0,5]  R422      -8.1583723425865173e-02
    z[4,0,5]  R423      1.5470467507839203e-01
    z[4,0,5]  R424      -9.5077134668827057e-02
    z[4,0,5]  R425      -4.2949426174163818e-01
    z[4,0,5]  R426      3.4728178381919861e-01
    z[4,0,5]  R427      0.0904572531580925
    z[4,0,5]  R428      -1.4110137522220612e-01
    z[4,0,5]  R429      1.1845245212316513e-01
    z[4,0,5]  R430      -3.1538268923759460e-01
    z[4,0,5]  R431      1.9393399357795715e-01
    z[4,0,5]  R432      4.2377910017967224e-01
    z[4,0,5]  R433      -0.395780086517334
    z[4,0,5]  R434      -1.7386563122272491e-02
    z[4,0,5]  R435      -2.4130217730998993e-01
    z[4,0,5]  R436      -1.4675861597061157e-01
    z[4,0,5]  R437      -4.1860324144363403e-01
    z[4,0,5]  R438      -4.0268743038177490e-01
    z[4,0,5]  R439      -6.7394733428955078e-01
    z[4,0,5]  R440      -0.511361837387085
    z[4,0,5]  R441      0.00314392801374197
    z[4,0,5]  R442      4.2095273733139038e-01
    z[4,0,5]  R443      4.6164900064468384e-02
    z[4,0,5]  R444      0.888314425945282
    z[4,0,5]  R445      0.0393720380961895
    z[4,0,5]  R446      1.5032701194286346e-01
    z[4,0,5]  R447      -4.4183483719825745e-01
    z[4,0,5]  R448      -4.6526364982128143e-02
    z[4,0,5]  R449      -3.4537929296493530e-01
    z[4,0,5]  R450      -1.9897958636283875e-01
    z[4,0,5]  R451      -2.0626088976860046e-01
    z[4,0,5]  R452      -3.5083314776420593e-01
    z[4,0,5]  R453      -3.3018547296524048e-01
    z[4,0,5]  R454      -0.0353008508682251
    z[4,0,5]  R455      -2.8835389018058777e-01
    z[4,0,5]  R456      1.1513948440551758e-01
    z[4,0,5]  R457      -1.8897391855716705e-01
    z[4,0,5]  R458      -3.6671742796897888e-01
    z[4,0,5]  R459      -4.4244265556335449e-01
    z[4,0,5]  R460      -4.8432428389787674e-02
    z[4,0,5]  R461      -3.1014522910118103e-01
    z[4,0,5]  R462      -4.4662556052207947e-01
    z[4,0,5]  R463      -4.4381716847419739e-01
    z[4,0,5]  R464      1.8448434770107269e-02
    z[4,0,5]  R465      1.4546078443527222e-01
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R400      -1
    z[4,0,6]  R401      1
    z[4,0,6]  R402      1.0290885716676712e-01
    z[4,0,6]  R403      -2.3524037003517151e-01
    z[4,0,6]  R404      -3.0866688489913940e-01
    z[4,0,6]  R405      -5.3239649534225464e-01
    z[4,0,6]  R406      -5.6580251455307007e-01
    z[4,0,6]  R407      -5.3024794906377792e-02
    z[4,0,6]  R408      -1.4246550202369690e-01
    z[4,0,6]  R409      -4.1751712560653687e-01
    z[4,0,6]  R410      -0.754396915435791
    z[4,0,6]  R411      2.0032688975334167e-01
    z[4,0,6]  R412      3.9272508025169373e-01
    z[4,0,6]  R413      7.7948756515979767e-02
    z[4,0,6]  R414      4.1360282897949219e-01
    z[4,0,6]  R415      3.4510451555252075e-01
    z[4,0,6]  R416      2.5842586159706116e-01
    z[4,0,6]  R417      1.3538759946823120e-01
    z[4,0,6]  R418      1.1551665514707565e-01
    z[4,0,6]  R419      0.214536651968956
    z[4,0,6]  R420      -5.3361082077026367e-01
    z[4,0,6]  R421      7.8541055321693420e-02
    z[4,0,6]  R422      3.4747272729873657e-01
    z[4,0,6]  R423      0.0959746390581131
    z[4,0,6]  R424      -1.4639247953891754e-01
    z[4,0,6]  R425      -7.8190825879573822e-02
    z[4,0,6]  R426      -1.7518197000026703e-01
    z[4,0,6]  R427      5.3436309099197388e-02
    z[4,0,6]  R428      -1.7086308449506760e-02
    z[4,0,6]  R429      3.3168086409568787e-01
    z[4,0,6]  R430      -3.6290207505226135e-01
    z[4,0,6]  R431      -1.1606375873088837e-01
    z[4,0,6]  R432      -6.0722154378890991e-01
    z[4,0,6]  R433      -5.8641022443771362e-01
    z[4,0,6]  R434      3.7587514519691467e-01
    z[4,0,6]  R435      0.547369122505188
    z[4,0,6]  R436      -6.0128502547740936e-02
    z[4,0,6]  R437      0.365986168384552
    z[4,0,6]  R438      -6.9392108917236328e-01
    z[4,0,6]  R439      -2.9783570766448975e-01
    z[4,0,6]  R440      -7.0330560207366943e-02
    z[4,0,6]  R441      6.2200218439102173e-01
    z[4,0,6]  R442      -2.1621546149253845e-01
    z[4,0,6]  R443      -2.4528577923774719e-01
    z[4,0,6]  R444      1.8378733098506927e-01
    z[4,0,6]  R445      7.8131055831909180e-01
    z[4,0,6]  R446      4.8125660419464111e-01
    z[4,0,6]  R447      -2.3336930200457573e-02
    z[4,0,6]  R448      -2.1960224211215973e-01
    z[4,0,6]  R449      -3.7968782708048820e-03
    z[4,0,6]  R450      2.3038852214813232e-01
    z[4,0,6]  R451      3.1047138571739197e-01
    z[4,0,6]  R452      1.8163545429706573e-01
    z[4,0,6]  R453      -2.6451623439788818e-01
    z[4,0,6]  R454      -0.00923438835889101
    z[4,0,6]  R455      2.3285332322120667e-01
    z[4,0,6]  R456      -1.6244754195213318e-01
    z[4,0,6]  R457      1.5605975687503815e-01
    z[4,0,6]  R458      1.1168923974037170e-01
    z[4,0,6]  R459      -1.8076808750629425e-01
    z[4,0,6]  R460      5.6880284100770950e-02
    z[4,0,6]  R461      -1.4711982011795044e-01
    z[4,0,6]  R462      1.5826404094696045e-01
    z[4,0,6]  R463      5.3272429853677750e-02
    z[4,0,6]  R464      -0.0338151752948761
    z[4,0,6]  R465      -6.8323022127151489e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R504      -1
    z[1,2,0]  R505      1
    z[1,2,0]  R518      0.792331874370575
    z[1,2,0]  R519      8.2360351085662842e-01
    z[1,2,0]  R520      0.825454592704773
    z[1,2,0]  R521      7.6305472850799561e-01
    z[1,2,0]  R522      9.1392600536346436e-01
    z[1,2,0]  R523      0.52276611328125
    z[1,2,0]  R524      0.848131537437439
    z[1,2,0]  R525      3.7846568226814270e-01
    z[1,2,0]  R526      -8.1787988543510437e-02
    z[1,2,0]  R527      -6.8388646841049194e-01
    z[1,2,0]  R528      -7.1314197778701782e-01
    z[1,2,0]  R529      -7.2746276855468750e-01
    z[1,2,0]  R530      -5.6805860996246338e-01
    z[1,2,0]  R531      -3.9287251234054565e-01
    z[1,2,0]  R532      -4.2372727394104004e-01
    z[1,2,0]  R533      -3.5243424773216248e-01
    z[1,2,0]  R534      -3.3037438988685608e-01
    z[1,2,0]  R535      -5.1508784294128418e-01
    z[1,2,0]  R536      -1.1502622812986374e-01
    z[1,2,0]  R537      -5.5213999748229980e-01
    z[1,2,0]  R538      -8.8299199938774109e-02
    z[1,2,0]  R539      -3.2991442084312439e-01
    z[1,2,0]  R540      -5.8540350198745728e-01
    z[1,2,0]  R541      -1.1914123594760895e-01
    z[1,2,0]  R542      -2.3966337740421295e-01
    z[1,2,0]  R543      -3.7223327159881592e-01
    z[1,2,0]  R544      -8.0146938562393188e-01
    z[1,2,0]  R545      -5.7806009054183960e-01
    z[1,2,0]  R546      -6.4372068643569946e-01
    z[1,2,0]  R547      -5.0161868333816528e-01
    z[1,2,0]  R548      -8.6371667683124542e-02
    z[1,2,0]  R549      1.6991788521409035e-02
    z[1,2,0]  R550      -6.1657375097274780e-01
    z[1,2,0]  R551      -9.1038918495178223e-01
    z[1,2,0]  R552      3.5387545824050903e-01
    z[1,2,0]  R553      -5.5890983343124390e-01
    z[1,2,0]  R554      -4.4688713550567627e-01
    z[1,2,0]  R555      -1.9498790800571442e-01
    z[1,2,0]  R556      -7.7668559551239014e-01
    z[1,2,0]  R557      -3.8441443443298340e-01
    z[1,2,0]  R558      -2.9512861371040344e-01
    z[1,2,0]  R559      -0.0926283597946167
    z[1,2,0]  R560      -8.3295780420303345e-01
    z[1,2,0]  R561      -7.3763936758041382e-01
    z[1,2,0]  R562      -8.3456999063491821e-01
    z[1,2,0]  R563      -7.8176146745681763e-01
    z[1,2,0]  R564      -7.6022058725357056e-01
    z[1,2,0]  R565      -5.2391797304153442e-01
    z[1,2,0]  R566      -8.8238435983657837e-01
    z[1,2,0]  R567      -6.3313668966293335e-01
    z[1,2,0]  R568      -8.8090650737285614e-02
    z[1,2,0]  R569      -2.4210691452026367e-01
    z[1,2,0]  R570      -8.2538688182830811e-01
    z[1,2,0]  R571      -3.1109073758125305e-01
    z[1,2,0]  R572      -2.5181236863136292e-01
    z[1,2,0]  R573      3.0048617720603943e-01
    z[1,2,0]  R574      -3.4604933857917786e-01
    z[1,2,0]  R575      -2.4814704060554504e-01
    z[1,2,0]  R576      -2.2024038434028625e-01
    z[1,2,0]  R577      -1.9153533875942230e-01
    z[1,2,0]  R578      -3.9020866155624390e-01
    z[1,2,0]  R579      -8.9242297410964966e-01
    z[1,2,0]  R580      -9.0254890918731689e-01
    z[1,2,0]  R581      -4.8743051290512085e-01
    z[1,2,0]  R582      -3.9723870158195496e-01
    z[1,2,0]  R583      2.5431382656097412e-01
    z[1,2,0]  R584      -2.8373831510543823e-01
    z[1,2,0]  R585      -7.5022215023636818e-03
    z[1,2,0]  R586      -4.0039947628974915e-01
    z[1,2,0]  R587      -0.390885591506958
    z[1,2,0]  R588      1.3482457399368286e-01
    z[1,2,0]  R589      -7.1054035425186157e-01
    z[1,2,0]  R590      -6.1111062765121460e-01
    z[1,2,0]  R591      3.4063592553138733e-01
    z[1,2,0]  R592      -2.8471186757087708e-01
    z[1,2,0]  R593      -4.9109966494143009e-03
    z[1,2,0]  R594      -4.6274831891059875e-01
    z[1,2,0]  R595      -4.1613438725471497e-01
    z[1,2,0]  R596      -3.3148407936096191e-01
    z[1,2,0]  R597      -0.0384528785943985
    z[1,2,0]  R598      8.6434870958328247e-01
    z[1,2,0]  R599      6.6791445016860962e-01
    z[1,2,0]  R600      4.6498170495033264e-01
    z[1,2,0]  R601      0.728111743927002
    z[1,2,0]  R602      4.3952608108520508e-01
    z[1,2,0]  R603      4.9878180027008057e-01
    z[1,2,0]  R604      3.3203712105751038e-01
    z[1,2,0]  R605      -3.1681719422340393e-01
    z[1,2,0]  R606      -2.2113482654094696e-01
    z[1,2,0]  R607      -4.0880167484283447e-01
    z[1,2,0]  R608      1.5702225267887115e-01
    z[1,2,0]  R609      8.3548091351985931e-02
    z[1,2,0]  R610      -1.2691356241703033e-01
    z[1,2,0]  R611      2.9052982106804848e-02
    z[1,2,0]  R612      -3.8130503892898560e-01
    z[1,2,0]  R613      -3.5953405499458313e-01
    z[1,2,0]  R614      1.6758590936660767e-01
    z[1,2,0]  R615      -2.6364507153630257e-02
    z[1,2,0]  R616      4.3519932031631470e-01
    z[1,2,0]  R617      -8.5451684892177582e-02
    z[1,2,0]  R618      1.0135149210691452e-01
    z[1,2,0]  R619      -1.2466557323932648e-01
    z[1,2,0]  R620      -5.1005119085311890e-01
    z[1,2,0]  R621      -2.8411766886711121e-01
    z[1,2,0]  R622      -6.6755360364913940e-01
    z[1,2,0]  R623      -8.4686893224716187e-01
    z[1,2,0]  R624      -6.4801824092864990e-01
    z[1,2,0]  R625      -7.4008554220199585e-01
    z[1,2,0]  R626      -6.8051880598068237e-01
    z[1,2,0]  R627      -8.6460644006729126e-01
    z[1,2,0]  R628      -2.0326793193817139e-01
    z[1,2,0]  R629      -0.0492432564496994
    z[1,2,0]  R630      -3.1620556116104126e-01
    z[1,2,0]  R631      -6.6749915480613708e-02
    z[1,2,0]  R632      -0.070064976811409
    z[1,2,0]  R633      4.1202157735824585e-01
    z[1,2,0]  R634      -8.6416286230087280e-01
    z[1,2,0]  R635      -6.2534677982330322e-01
    z[1,2,0]  R636      -4.6929138898849487e-01
    z[1,2,0]  R637      -4.9503171443939209e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R506      -1
    z[1,2,1]  R507      1
    z[1,2,1]  R518      -1.0905101150274277e-01
    z[1,2,1]  R519      1.5836556255817413e-01
    z[1,2,1]  R520      1.2569531798362732e-01
    z[1,2,1]  R521      2.5770911574363708e-01
    z[1,2,1]  R522      -1.0237623006105423e-01
    z[1,2,1]  R523      -4.1197243332862854e-01
    z[1,2,1]  R524      -3.0243989825248718e-01
    z[1,2,1]  R525      -2.8250840306282043e-01
    z[1,2,1]  R526      7.2571784257888794e-01
    z[1,2,1]  R527      2.8844487667083740e-01
    z[1,2,1]  R528      1.3543620705604553e-01
    z[1,2,1]  R529      2.1578861773014069e-01
    z[1,2,1]  R530      2.0259724557399750e-01
    z[1,2,1]  R531      4.7164192795753479e-01
    z[1,2,1]  R532      -6.6417090594768524e-02
    z[1,2,1]  R533      -1.0809313505887985e-01
    z[1,2,1]  R534      -2.3711220920085907e-01
    z[1,2,1]  R535      2.8366753458976746e-01
    z[1,2,1]  R536      6.7696201801300049e-01
    z[1,2,1]  R537      -4.1145187616348267e-01
    z[1,2,1]  R538      8.4717440605163574e-01
    z[1,2,1]  R539      8.5122102499008179e-01
    z[1,2,1]  R540      2.0687554776668549e-01
    z[1,2,1]  R541      8.9596009254455566e-01
    z[1,2,1]  R542      0.419808566570282
    z[1,2,1]  R543      7.7928400039672852e-01
    z[1,2,1]  R544      -2.8380360454320908e-02
    z[1,2,1]  R545      0.0535450242459774
    z[1,2,1]  R546      -1.3417863845825195e-01
    z[1,2,1]  R547      4.8361358046531677e-01
    z[1,2,1]  R548      5.3514945507049561e-01
    z[1,2,1]  R549      4.9760690331459045e-01
    z[1,2,1]  R550      -2.2233970463275909e-01
    z[1,2,1]  R551      -3.3424004912376404e-01
    z[1,2,1]  R552      4.5104047656059265e-01
    z[1,2,1]  R553      3.2487812638282776e-01
    z[1,2,1]  R554      3.1988728046417236e-01
    z[1,2,1]  R555      -1.3790245354175568e-01
    z[1,2,1]  R556      1.8276622891426086e-01
    z[1,2,1]  R557      1.6258032619953156e-01
    z[1,2,1]  R558      0.658534049987793
    z[1,2,1]  R559      7.2154521942138672e-01
    z[1,2,1]  R560      9.6430137753486633e-02
    z[1,2,1]  R561      -2.9100757837295532e-01
    z[1,2,1]  R562      -1.7757755517959595e-01
    z[1,2,1]  R563      2.8576648235321045e-01
    z[1,2,1]  R564      3.4093910455703735e-01
    z[1,2,1]  R565      1.8604382872581482e-01
    z[1,2,1]  R566      -1.4244794845581055e-01
    z[1,2,1]  R567      1.3397786021232605e-01
    z[1,2,1]  R568      7.2524315118789673e-01
    z[1,2,1]  R569      6.8998634815216064e-01
    z[1,2,1]  R570      2.6473295688629150e-01
    z[1,2,1]  R571      7.2068822383880615e-01
    z[1,2,1]  R572      7.3601621389389038e-01
    z[1,2,1]  R573      3.9459916949272156e-01
    z[1,2,1]  R574      -0.512565016746521
    z[1,2,1]  R575      -4.3045002222061157e-01
    z[1,2,1]  R576      -4.1318696737289429e-01
    z[1,2,1]  R577      -3.9167153835296631e-01
    z[1,2,1]  R578      8.1174737215042114e-01
    z[1,2,1]  R579      2.1241806447505951e-01
    z[1,2,1]  R580      -1.6283838078379631e-02
    z[1,2,1]  R581      -1.2810570001602173e-01
    z[1,2,1]  R582      1.7376622557640076e-01
    z[1,2,1]  R583      5.9266769886016846e-01
    z[1,2,1]  R584      -6.2614244222640991e-01
    z[1,2,1]  R585      -6.3249868154525757e-01
    z[1,2,1]  R586      -5.1105105876922607e-01
    z[1,2,1]  R587      -3.7430158257484436e-01
    z[1,2,1]  R588      7.7420455217361450e-01
    z[1,2,1]  R589      2.3767906427383423e-01
    z[1,2,1]  R590      -1.1000989377498627e-01
    z[1,2,1]  R591      7.1379250288009644e-01
    z[1,2,1]  R592      -1.3433446176350117e-02
    z[1,2,1]  R593      0.693791925907135
    z[1,2,1]  R594      -4.7620710730552673e-01
    z[1,2,1]  R595      -5.3375661373138428e-01
    z[1,2,1]  R596      -5.4656445980072021e-01
    z[1,2,1]  R597      -0.770487368106842
    z[1,2,1]  R598      -4.0723243355751038e-01
    z[1,2,1]  R599      -4.3571284413337708e-01
    z[1,2,1]  R600      -0.633994460105896
    z[1,2,1]  R601      -2.0166671276092529e-01
    z[1,2,1]  R602      -3.9191511273384094e-01
    z[1,2,1]  R603      -9.8720192909240723e-03
    z[1,2,1]  R604      1.8145754933357239e-02
    z[1,2,1]  R605      -6.2250858545303345e-01
    z[1,2,1]  R606      -5.6228274106979370e-01
    z[1,2,1]  R607      -7.7131259441375732e-01
    z[1,2,1]  R608      7.5322926044464111e-01
    z[1,2,1]  R609      6.4812260866165161e-01
    z[1,2,1]  R610      5.3232693672180176e-01
    z[1,2,1]  R611      6.2306547164916992e-01
    z[1,2,1]  R612      6.3632696866989136e-01
    z[1,2,1]  R613      5.3356373310089111e-01
    z[1,2,1]  R614      7.9223489761352539e-01
    z[1,2,1]  R615      6.9819223880767822e-01
    z[1,2,1]  R616      6.7886650562286377e-01
    z[1,2,1]  R617      8.7288916110992432e-01
    z[1,2,1]  R618      -4.1749957203865051e-01
    z[1,2,1]  R619      0.735876202583313
    z[1,2,1]  R620      0.458394318819046
    z[1,2,1]  R621      2.1090948581695557e-01
    z[1,2,1]  R622      3.6799290776252747e-01
    z[1,2,1]  R623      1.1673334985971451e-01
    z[1,2,1]  R624      -9.0482152998447418e-02
    z[1,2,1]  R625      -1.7473979294300079e-01
    z[1,2,1]  R626      3.9658805727958679e-01
    z[1,2,1]  R627      -1.0264360159635544e-01
    z[1,2,1]  R628      -4.9712833762168884e-01
    z[1,2,1]  R629      8.2093644142150879e-01
    z[1,2,1]  R630      8.6742001771926880e-01
    z[1,2,1]  R631      0.866395115852356
    z[1,2,1]  R632      0.307373583316803
    z[1,2,1]  R633      5.8181345462799072e-01
    z[1,2,1]  R634      -1.6553734242916107e-01
    z[1,2,1]  R635      -1.4171253144741058e-01
    z[1,2,1]  R636      -2.8058373928070068e-01
    z[1,2,1]  R637      1.7950499057769775e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R508      -1
    z[1,2,2]  R509      1
    z[1,2,2]  R518      4.9007475376129150e-01
    z[1,2,2]  R519      4.3332302570343018e-01
    z[1,2,2]  R520      4.3423864245414734e-01
    z[1,2,2]  R521      4.5883128046989441e-01
    z[1,2,2]  R522      1.3983765617012978e-02
    z[1,2,2]  R523      3.9672231674194336e-01
    z[1,2,2]  R524      -4.8237197101116180e-02
    z[1,2,2]  R525      7.5016999244689941e-01
    z[1,2,2]  R526      4.5759268105030060e-02
    z[1,2,2]  R527      -4.7399401664733887e-01
    z[1,2,2]  R528      -2.5449833273887634e-01
    z[1,2,2]  R529      -3.9830714464187622e-02
    z[1,2,2]  R530      -8.1029146909713745e-02
    z[1,2,2]  R531      -4.7255808115005493e-01
    z[1,2,2]  R532      -3.2451364398002625e-01
    z[1,2,2]  R533      -5.6197357177734375e-01
    z[1,2,2]  R534      -7.3531186580657959e-01
    z[1,2,2]  R535      -3.0125150084495544e-01
    z[1,2,2]  R536      -4.2521965503692627e-01
    z[1,2,2]  R537      -2.5884151458740234e-01
    z[1,2,2]  R538      -8.2246296107769012e-02
    z[1,2,2]  R539      7.3520161211490631e-02
    z[1,2,2]  R540      -6.6690897941589355e-01
    z[1,2,2]  R541      1.5338120982050896e-02
    z[1,2,2]  R542      -5.3181946277618408e-01
    z[1,2,2]  R543      -1.4147794246673584e-01
    z[1,2,2]  R544      -4.2270419001579285e-01
    z[1,2,2]  R545      -0.382876992225647
    z[1,2,2]  R546      -5.3503000736236572e-01
    z[1,2,2]  R547      -4.7239184379577637e-01
    z[1,2,2]  R548      -2.2648519277572632e-01
    z[1,2,2]  R549      -5.0820887088775635e-01
    z[1,2,2]  R550      -4.1381460428237915e-01
    z[1,2,2]  R551      -1.9720740616321564e-01
    z[1,2,2]  R552      -6.2122678756713867e-01
    z[1,2,2]  R553      -4.2674034833908081e-01
    z[1,2,2]  R554      -4.9503925442695618e-01
    z[1,2,2]  R555      -8.2410043478012085e-01
    z[1,2,2]  R556      1.0093321651220322e-01
    z[1,2,2]  R557      -5.6082463264465332e-01
    z[1,2,2]  R558      9.7608342766761780e-02
    z[1,2,2]  R559      -3.7305000424385071e-01
    z[1,2,2]  R560      -2.8750467300415039e-01
    z[1,2,2]  R561      -5.1594811677932739e-01
    z[1,2,2]  R562      -4.1705605387687683e-01
    z[1,2,2]  R563      -7.9808674752712250e-02
    z[1,2,2]  R564      -4.5072114467620850e-01
    z[1,2,2]  R565      -5.7259029150009155e-01
    z[1,2,2]  R566      0.0425020195543766
    z[1,2,2]  R567      -5.8257788419723511e-01
    z[1,2,2]  R568      -2.9622277617454529e-01
    z[1,2,2]  R569      1.0739636421203613e-01
    z[1,2,2]  R570      -2.8401133418083191e-01
    z[1,2,2]  R571      -7.5146481394767761e-02
    z[1,2,2]  R572      4.0949344635009766e-01
    z[1,2,2]  R573      -5.9676694869995117e-01
    z[1,2,2]  R574      7.0104055106639862e-02
    z[1,2,2]  R575      2.5865691900253296e-01
    z[1,2,2]  R576      0.045010045170784
    z[1,2,2]  R577      2.1633841097354889e-03
    z[1,2,2]  R578      1.3381724059581757e-01
    z[1,2,2]  R579      -2.4735182523727417e-01
    z[1,2,2]  R580      -3.2939341664314270e-01
    z[1,2,2]  R581      -6.7971074581146240e-01
    z[1,2,2]  R582      -2.6860460638999939e-01
    z[1,2,2]  R583      -6.2600922584533691e-01
    z[1,2,2]  R584      7.3427930474281311e-02
    z[1,2,2]  R585      -5.4973983764648438e-01
    z[1,2,2]  R586      3.5052296519279480e-01
    z[1,2,2]  R587      1.9565726816654205e-01
    z[1,2,2]  R588      -0.0914430320262909
    z[1,2,2]  R589      -2.7722349762916565e-01
    z[1,2,2]  R590      -6.3867402076721191e-01
    z[1,2,2]  R591      -0.552993655204773
    z[1,2,2]  R592      -6.2353104352951050e-01
    z[1,2,2]  R593      -3.4796708822250366e-01
    z[1,2,2]  R594      2.6201891899108887e-01
    z[1,2,2]  R595      3.3248621225357056e-01
    z[1,2,2]  R596      4.4115567207336426e-01
    z[1,2,2]  R597      -1.0193391889333725e-01
    z[1,2,2]  R598      6.7390188574790955e-02
    z[1,2,2]  R599      3.0142614245414734e-01
    z[1,2,2]  R600      1.5732099115848541e-01
    z[1,2,2]  R601      2.0724116265773773e-01
    z[1,2,2]  R602      1.4994834363460541e-01
    z[1,2,2]  R603      4.1898164153099060e-01
    z[1,2,2]  R604      4.5498472452163696e-01
    z[1,2,2]  R605      4.7741052508354187e-01
    z[1,2,2]  R606      3.5086354613304138e-01
    z[1,2,2]  R607      2.8349253535270691e-01
    z[1,2,2]  R608      -4.3035313487052917e-01
    z[1,2,2]  R609      -3.2790485024452209e-01
    z[1,2,2]  R610      -6.1819630861282349e-01
    z[1,2,2]  R611      -6.7858254909515381e-01
    z[1,2,2]  R612      -5.1824736595153809e-01
    z[1,2,2]  R613      -3.8327559828758240e-01
    z[1,2,2]  R614      -4.7408428788185120e-01
    z[1,2,2]  R615      -3.9438962936401367e-01
    z[1,2,2]  R616      -4.2634752392768860e-01
    z[1,2,2]  R617      -2.0455385744571686e-01
    z[1,2,2]  R618      3.1482407450675964e-01
    z[1,2,2]  R619      0.0796460285782814
    z[1,2,2]  R620      4.6889832615852356e-01
    z[1,2,2]  R621      6.7965364456176758e-01
    z[1,2,2]  R622      3.7591493129730225e-01
    z[1,2,2]  R623      -3.5959637165069580e-01
    z[1,2,2]  R624      -5.1113218069076538e-01
    z[1,2,2]  R625      -4.6645429730415344e-01
    z[1,2,2]  R626      1.7479488253593445e-01
    z[1,2,2]  R627      -2.1831433475017548e-01
    z[1,2,2]  R628      3.5196727514266968e-01
    z[1,2,2]  R629      -2.9363530874252319e-01
    z[1,2,2]  R630      -1.0206980258226395e-01
    z[1,2,2]  R631      8.3683505654335022e-02
    z[1,2,2]  R632      7.9446166753768921e-01
    z[1,2,2]  R633      2.9570186138153076e-01
    z[1,2,2]  R634      -3.6811664700508118e-01
    z[1,2,2]  R635      -0.686767041683197
    z[1,2,2]  R636      -7.2401577234268188e-01
    z[1,2,2]  R637      -7.6279765367507935e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R510      -1
    z[1,2,3]  R511      1
    z[1,2,3]  R518      9.2287629842758179e-02
    z[1,2,3]  R519      -2.0014800131320953e-01
    z[1,2,3]  R520      -8.5034728050231934e-02
    z[1,2,3]  R521      1.3058932125568390e-01
    z[1,2,3]  R522      3.0125194787979126e-01
    z[1,2,3]  R523      0.520189642906189
    z[1,2,3]  R524      1.3079671561717987e-01
    z[1,2,3]  R525      2.5256437063217163e-01
    z[1,2,3]  R526      4.0579503774642944e-01
    z[1,2,3]  R527      0.0964856743812561
    z[1,2,3]  R528      2.9296535253524780e-01
    z[1,2,3]  R529      -3.7418681383132935e-01
    z[1,2,3]  R530      -1.3086028397083282e-01
    z[1,2,3]  R531      -1.7786049842834473e-01
    z[1,2,3]  R532      4.3679423630237579e-02
    z[1,2,3]  R533      1.2698574364185333e-01
    z[1,2,3]  R534      -3.3059798181056976e-02
    z[1,2,3]  R535      2.4960565567016602e-01
    z[1,2,3]  R536      1.2818354368209839e-01
    z[1,2,3]  R537      -2.8161531314253807e-02
    z[1,2,3]  R538      1.8379606306552887e-01
    z[1,2,3]  R539      8.9184358716011047e-02
    z[1,2,3]  R540      3.0218443274497986e-01
    z[1,2,3]  R541      -1.7567628622055054e-01
    z[1,2,3]  R542      5.6137013435363770e-01
    z[1,2,3]  R543      -2.5533020496368408e-02
    z[1,2,3]  R544      7.2698421776294708e-02
    z[1,2,3]  R545      1.2450806796550751e-01
    z[1,2,3]  R546      2.0046686753630638e-02
    z[1,2,3]  R547      4.0017595887184143e-01
    z[1,2,3]  R548      7.2901839017868042e-01
    z[1,2,3]  R549      6.1173772811889648e-01
    z[1,2,3]  R550      2.6643732190132141e-01
    z[1,2,3]  R551      1.3333716988563538e-01
    z[1,2,3]  R552      -4.6903842687606812e-01
    z[1,2,3]  R553      -5.6975334882736206e-01
    z[1,2,3]  R554      -6.2637668848037720e-01
    z[1,2,3]  R555      -1.3208748772740364e-02
    z[1,2,3]  R556      -2.7006399631500244e-01
    z[1,2,3]  R557      -0.284567654132843
    z[1,2,3]  R558      6.2359935045242310e-01
    z[1,2,3]  R559      2.0508620142936707e-01
    z[1,2,3]  R560      -3.4290376305580139e-01
    z[1,2,3]  R561      0.0787176638841629
    z[1,2,3]  R562      -3.1505491584539413e-02
    z[1,2,3]  R563      -1.8802741169929504e-01
    z[1,2,3]  R564      -7.6615914702415466e-02
    z[1,2,3]  R565      -4.5816308259963989e-01
    z[1,2,3]  R566      1.0480262339115143e-02
    z[1,2,3]  R567      -1.6463990509510040e-01
    z[1,2,3]  R568      4.9492558836936951e-01
    z[1,2,3]  R569      5.1039123535156250e-01
    z[1,2,3]  R570      1.5957221388816833e-01
    z[1,2,3]  R571      2.0176191627979279e-01
    z[1,2,3]  R572      2.0435136556625366e-01
    z[1,2,3]  R573      2.4046385660767555e-02
    z[1,2,3]  R574      1.0196488350629807e-01
    z[1,2,3]  R575      -1.8244255334138870e-02
    z[1,2,3]  R576      1.2740735709667206e-01
    z[1,2,3]  R577      1.6273528337478638e-01
    z[1,2,3]  R578      2.0743475854396820e-01
    z[1,2,3]  R579      1.2848366796970367e-01
    z[1,2,3]  R580      1.8277525901794434e-01
    z[1,2,3]  R581      -1.0069535672664642e-01
    z[1,2,3]  R582      -2.6078507304191589e-01
    z[1,2,3]  R583      1.5137994289398193e-01
    z[1,2,3]  R584      2.1282330155372620e-01
    z[1,2,3]  R585      8.2246467471122742e-02
    z[1,2,3]  R586      -4.5397719740867615e-01
    z[1,2,3]  R587      -3.9986866712570190e-01
    z[1,2,3]  R588      4.1989326477050781e-01
    z[1,2,3]  R589      -1.0096883773803711e-01
    z[1,2,3]  R590      -9.7536019980907440e-02
    z[1,2,3]  R591      -2.5212657451629639e-01
    z[1,2,3]  R592      2.8084175661206245e-02
    z[1,2,3]  R593      1.8539489805698395e-01
    z[1,2,3]  R594      -5.8655989170074463e-01
    z[1,2,3]  R595      -4.3416237831115723e-01
    z[1,2,3]  R596      -4.5367926359176636e-01
    z[1,2,3]  R597      -6.1849749088287354e-01
    z[1,2,3]  R598      -1.5914860367774963e-01
    z[1,2,3]  R599      -5.3766336292028427e-02
    z[1,2,3]  R600      1.4396573603153229e-01
    z[1,2,3]  R601      -2.5104392319917679e-02
    z[1,2,3]  R602      -1.3331703841686249e-01
    z[1,2,3]  R603      -3.7810721993446350e-01
    z[1,2,3]  R604      -5.7165306806564331e-01
    z[1,2,3]  R605      -1.8017520010471344e-01
    z[1,2,3]  R606      -2.6484557986259460e-01
    z[1,2,3]  R607      -2.8375267982482910e-01
    z[1,2,3]  R608      2.5552812218666077e-01
    z[1,2,3]  R609      0.397329717874527
    z[1,2,3]  R610      4.9832960963249207e-01
    z[1,2,3]  R611      3.3659121394157410e-01
    z[1,2,3]  R612      0.315348356962204
    z[1,2,3]  R613      5.1529526710510254e-01
    z[1,2,3]  R614      2.5374817848205566e-01
    z[1,2,3]  R615      3.0752077698707581e-01
    z[1,2,3]  R616      3.7837514281272888e-01
    z[1,2,3]  R617      8.2159496843814850e-02
    z[1,2,3]  R618      -1.5864214301109314e-01
    z[1,2,3]  R619      2.3752050101757050e-01
    z[1,2,3]  R620      -2.7910497784614563e-01
    z[1,2,3]  R621      -3.8216370344161987e-01
    z[1,2,3]  R622      -3.6438465118408203e-01
    z[1,2,3]  R623      -1.6845697164535522e-01
    z[1,2,3]  R624      -2.9784658551216125e-01
    z[1,2,3]  R625      -1.4176808297634125e-01
    z[1,2,3]  R626      2.3424679413437843e-02
    z[1,2,3]  R627      -2.0129530131816864e-01
    z[1,2,3]  R628      -5.1793640851974487e-01
    z[1,2,3]  R629      3.2918041944503784e-01
    z[1,2,3]  R630      2.1268796920776367e-01
    z[1,2,3]  R631      1.9512437283992767e-01
    z[1,2,3]  R632      -3.7618613243103027e-01
    z[1,2,3]  R633      -2.0109087228775024e-01
    z[1,2,3]  R634      0.073503777384758
    z[1,2,3]  R635      -2.3019200563430786e-01
    z[1,2,3]  R636      1.4721383154392242e-01
    z[1,2,3]  R637      -2.4338087439537048e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R512      -1
    z[1,2,4]  R513      1
    z[1,2,4]  R518      5.0804324448108673e-02
    z[1,2,4]  R519      -1.2158947438001633e-01
    z[1,2,4]  R520      5.3107652813196182e-02
    z[1,2,4]  R521      3.2538601756095886e-01
    z[1,2,4]  R522      5.5658418685197830e-02
    z[1,2,4]  R523      -1.0907003283500671e-01
    z[1,2,4]  R524      -2.5865745544433594e-01
    z[1,2,4]  R525      3.1789198517799377e-01
    z[1,2,4]  R526      -3.3076703548431396e-01
    z[1,2,4]  R527      2.2788918018341064e-01
    z[1,2,4]  R528      -3.0153882503509521e-01
    z[1,2,4]  R529      -2.3667715489864349e-01
    z[1,2,4]  R530      -3.1775414943695068e-01
    z[1,2,4]  R531      -2.4732597172260284e-01
    z[1,2,4]  R532      -4.9626824259757996e-01
    z[1,2,4]  R533      -3.7221285700798035e-01
    z[1,2,4]  R534      -4.7242611646652222e-01
    z[1,2,4]  R535      -8.9234240353107452e-02
    z[1,2,4]  R536      -6.1968307942152023e-02
    z[1,2,4]  R537      -5.1120370626449585e-01
    z[1,2,4]  R538      -3.1448808312416077e-01
    z[1,2,4]  R539      3.5533782839775085e-01
    z[1,2,4]  R540      -6.0251239687204361e-02
    z[1,2,4]  R541      1.3012728095054626e-01
    z[1,2,4]  R542      1.3269375264644623e-01
    z[1,2,4]  R543      -2.1954169869422913e-01
    z[1,2,4]  R544      -1.6888792812824249e-01
    z[1,2,4]  R545      -3.0619928240776062e-01
    z[1,2,4]  R546      -0.377180278301239
    z[1,2,4]  R547      -1.5033121220767498e-02
    z[1,2,4]  R548      1.1791370809078217e-01
    z[1,2,4]  R549      -1.9858722388744354e-01
    z[1,2,4]  R550      -1.1424652487039566e-01
    z[1,2,4]  R551      -3.3420909196138382e-02
    z[1,2,4]  R552      -1.7674843966960907e-01
    z[1,2,4]  R553      -1.8118312954902649e-01
    z[1,2,4]  R554      -2.3258654773235321e-01
    z[1,2,4]  R555      -1.8965248763561249e-01
    z[1,2,4]  R556      -4.0404719114303589e-01
    z[1,2,4]  R557      -0.604387640953064
    z[1,2,4]  R558      1.1300739832222462e-02
    z[1,2,4]  R559      -2.0947778224945068e-01
    z[1,2,4]  R560      -1.9690012931823730e-01
    z[1,2,4]  R561      -2.1455359458923340e-01
    z[1,2,4]  R562      -2.3748318850994110e-01
    z[1,2,4]  R563      -6.2412753701210022e-02
    z[1,2,4]  R564      -1.3878914760425687e-03
    z[1,2,4]  R565      -2.9972249269485474e-01
    z[1,2,4]  R566      1.0240171849727631e-01
    z[1,2,4]  R567      -5.8105643838644028e-02
    z[1,2,4]  R568      -1.6127350926399231e-01
    z[1,2,4]  R569      -2.2873380780220032e-01
    z[1,2,4]  R570      4.9016959965229034e-02
    z[1,2,4]  R571      -1.7113342881202698e-01
    z[1,2,4]  R572      -1.5119731426239014e-01
    z[1,2,4]  R573      4.2914608120918274e-01
    z[1,2,4]  R574      -2.2236181795597076e-01
    z[1,2,4]  R575      -6.6458338499069214e-01
    z[1,2,4]  R576      -5.0531399250030518e-01
    z[1,2,4]  R577      -3.9694091677665710e-01
    z[1,2,4]  R578      -1.5275681018829346e-01
    z[1,2,4]  R579      1.0644120723009109e-01
    z[1,2,4]  R580      1.7732322216033936e-01
    z[1,2,4]  R581      7.3642139323055744e-03
    z[1,2,4]  R582      -1.9135577976703644e-01
    z[1,2,4]  R583      -1.1073070764541626e-01
    z[1,2,4]  R584      -2.5646522641181946e-01
    z[1,2,4]  R585      3.7055090069770813e-01
    z[1,2,4]  R586      -1.3561026751995087e-01
    z[1,2,4]  R587      1.8353927135467529e-01
    z[1,2,4]  R588      -3.0290371179580688e-01
    z[1,2,4]  R589      -1.1322285234928131e-01
    z[1,2,4]  R590      -4.3514337390661240e-02
    z[1,2,4]  R591      -0.0205116905272007
    z[1,2,4]  R592      -3.3465218544006348e-01
    z[1,2,4]  R593      4.6316260099411011e-01
    z[1,2,4]  R594      1.8530224263668060e-01
    z[1,2,4]  R595      -1.2988176941871643e-01
    z[1,2,4]  R596      -3.2258176803588867e-01
    z[1,2,4]  R597      2.8929686173796654e-02
    z[1,2,4]  R598      -4.1487328708171844e-02
    z[1,2,4]  R599      4.1146057844161987e-01
    z[1,2,4]  R600      -3.0920660495758057e-01
    z[1,2,4]  R601      -2.9925815761089325e-03
    z[1,2,4]  R602      4.3003222346305847e-01
    z[1,2,4]  R603      4.5306283235549927e-01
    z[1,2,4]  R604      -9.0662069618701935e-02
    z[1,2,4]  R605      -3.3379447460174561e-01
    z[1,2,4]  R606      -2.3181785643100739e-01
    z[1,2,4]  R607      9.9848099052906036e-02
    z[1,2,4]  R608      -3.7160521745681763e-01
    z[1,2,4]  R609      -3.4199967980384827e-01
    z[1,2,4]  R610      -8.8972700759768486e-03
    z[1,2,4]  R611      -1.7658649384975433e-01
    z[1,2,4]  R612      -2.6077610254287720e-01
    z[1,2,4]  R613      5.7250197976827621e-02
    z[1,2,4]  R614      1.6314479708671570e-01
    z[1,2,4]  R615      -1.0265620797872543e-01
    z[1,2,4]  R616      1.2650048732757568e-01
    z[1,2,4]  R617      1.1672622524201870e-02
    z[1,2,4]  R618      -5.2131730318069458e-01
    z[1,2,4]  R619      5.6925231218338013e-01
    z[1,2,4]  R620      1.6688981652259827e-01
    z[1,2,4]  R621      1.3613104820251465e-01
    z[1,2,4]  R622      2.9619839787483215e-01
    z[1,2,4]  R623      2.1729892492294312e-01
    z[1,2,4]  R624      -9.5797322690486908e-02
    z[1,2,4]  R625      1.8221385776996613e-01
    z[1,2,4]  R626      3.6193040013313293e-01
    z[1,2,4]  R627      6.1044171452522278e-02
    z[1,2,4]  R628      1.4343340694904327e-01
    z[1,2,4]  R629      -8.7525574490427971e-03
    z[1,2,4]  R630      -7.3115348815917969e-02
    z[1,2,4]  R631      3.1686764955520630e-01
    z[1,2,4]  R632      -1.0720803588628769e-01
    z[1,2,4]  R633      -5.5371510982513428e-01
    z[1,2,4]  R634      -4.5539274811744690e-02
    z[1,2,4]  R635      -0.117519810795784
    z[1,2,4]  R636      -1.0086910426616669e-01
    z[1,2,4]  R637      2.7862343192100525e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R514      -1
    z[1,2,5]  R515      1
    z[1,2,5]  R518      -2.7747803926467896e-01
    z[1,2,5]  R519      8.6794808506965637e-02
    z[1,2,5]  R520      2.6432502269744873e-01
    z[1,2,5]  R521      -1.2706659734249115e-01
    z[1,2,5]  R522      -2.2977589070796967e-01
    z[1,2,5]  R523      2.9454892873764038e-01
    z[1,2,5]  R524      2.3581004142761230e-01
    z[1,2,5]  R525      -1.3369787484407425e-02
    z[1,2,5]  R526      -3.8183709979057312e-01
    z[1,2,5]  R527      2.2445890307426453e-01
    z[1,2,5]  R528      4.2150229215621948e-01
    z[1,2,5]  R529      2.1082273125648499e-01
    z[1,2,5]  R530      5.2028131484985352e-01
    z[1,2,5]  R531      7.8177213668823242e-02
    z[1,2,5]  R532      3.8318881392478943e-01
    z[1,2,5]  R533      0.501187264919281
    z[1,2,5]  R534      -1.0809244960546494e-01
    z[1,2,5]  R535      -3.3803563565015793e-02
    z[1,2,5]  R536      0.270234078168869
    z[1,2,5]  R537      3.6921831965446472e-01
    z[1,2,5]  R538      -1.7713992297649384e-01
    z[1,2,5]  R539      1.2475472688674927e-01
    z[1,2,5]  R540      2.3245538771152496e-01
    z[1,2,5]  R541      3.6535343527793884e-01
    z[1,2,5]  R542      -9.7938925027847290e-03
    z[1,2,5]  R543      3.3562558889389038e-01
    z[1,2,5]  R544      -7.2778813540935516e-02
    z[1,2,5]  R545      5.8214765787124634e-01
    z[1,2,5]  R546      6.7344211041927338e-02
    z[1,2,5]  R547      -3.1684139370918274e-01
    z[1,2,5]  R548      2.0376870408654213e-02
    z[1,2,5]  R549      1.8445710837841034e-01
    z[1,2,5]  R550      5.0468164682388306e-01
    z[1,2,5]  R551      2.7623368427157402e-02
    z[1,2,5]  R552      -9.8482377827167511e-02
    z[1,2,5]  R553      -1.5143278241157532e-01
    z[1,2,5]  R554      5.1329664885997772e-02
    z[1,2,5]  R555      1.0537500679492950e-01
    z[1,2,5]  R556      -8.6735926568508148e-02
    z[1,2,5]  R557      -1.1086606979370117e-01
    z[1,2,5]  R558      -2.3266993463039398e-01
    z[1,2,5]  R559      -4.4520515203475952e-01
    z[1,2,5]  R560      2.3093423247337341e-01
    z[1,2,5]  R561      1.9628649950027466e-01
    z[1,2,5]  R562      4.6226605772972107e-03
    z[1,2,5]  R563      4.9770256876945496e-01
    z[1,2,5]  R564      -1.0162238776683807e-01
    z[1,2,5]  R565      2.3632700741291046e-01
    z[1,2,5]  R566      3.2093369960784912e-01
    z[1,2,5]  R567      -0.42711141705513
    z[1,2,5]  R568      -3.2793802022933960e-01
    z[1,2,5]  R569      1.5501849353313446e-01
    z[1,2,5]  R570      3.2618772983551025e-01
    z[1,2,5]  R571      4.2262414097785950e-01
    z[1,2,5]  R572      3.3062899112701416e-01
    z[1,2,5]  R573      4.0845975279808044e-01
    z[1,2,5]  R574      -7.3691415786743164e-01
    z[1,2,5]  R575      -4.9031883478164673e-01
    z[1,2,5]  R576      -0.678159236907959
    z[1,2,5]  R577      -7.0835208892822266e-01
    z[1,2,5]  R578      2.3761945962905884e-01
    z[1,2,5]  R579      2.4640648066997528e-01
    z[1,2,5]  R580      -5.8739602565765381e-02
    z[1,2,5]  R581      -2.0139248669147491e-01
    z[1,2,5]  R582      5.5107432603836060e-01
    z[1,2,5]  R583      0.358646959066391
    z[1,2,5]  R584      -6.2370300292968750e-01
    z[1,2,5]  R585      -2.7175009250640869e-02
    z[1,2,5]  R586      -4.7938090562820435e-01
    z[1,2,5]  R587      -6.8554812669754028e-01
    z[1,2,5]  R588      0.240728497505188
    z[1,2,5]  R589      5.8204138278961182e-01
    z[1,2,5]  R590      1.8889984115958214e-02
    z[1,2,5]  R591      6.4875751733779907e-02
    z[1,2,5]  R592      6.2053400278091431e-01
    z[1,2,5]  R593      1.5324059128761292e-01
    z[1,2,5]  R594      -3.1326818466186523e-01
    z[1,2,5]  R595      -4.7536367177963257e-01
    z[1,2,5]  R596      -2.0229713618755341e-01
    z[1,2,5]  R597      -8.7680689990520477e-02
    z[1,2,5]  R598      -2.3540283739566803e-01
    z[1,2,5]  R599      -0.00854957289993763
    z[1,2,5]  R600      4.3783590197563171e-01
    z[1,2,5]  R601      8.3130694925785065e-02
    z[1,2,5]  R602      -2.8458476066589355e-01
    z[1,2,5]  R603      -3.8159853219985962e-01
    z[1,2,5]  R604      -4.0739923715591431e-01
    z[1,2,5]  R605      3.3087518811225891e-01
    z[1,2,5]  R606      2.4915076792240143e-02
    z[1,2,5]  R607      -1.7816540598869324e-01
    z[1,2,5]  R608      1.1467922478914261e-01
    z[1,2,5]  R609      4.2003858089447021e-01
    z[1,2,5]  R610      1.6208250820636749e-01
    z[1,2,5]  R611      -7.4223570525646210e-02
    z[1,2,5]  R612      1.1688430607318878e-01
    z[1,2,5]  R613      4.1198921203613281e-01
    z[1,2,5]  R614      -1.3664972782135010e-01
    z[1,2,5]  R615      1.2237863242626190e-01
    z[1,2,5]  R616      8.1927262246608734e-02
    z[1,2,5]  R617      -3.8340527564287186e-02
    z[1,2,5]  R618      2.3994486033916473e-01
    z[1,2,5]  R619      2.3447552323341370e-01
    z[1,2,5]  R620      -2.8205180168151855e-01
    z[1,2,5]  R621      8.0327279865741730e-02
    z[1,2,5]  R622      -2.2595344483852386e-01
    z[1,2,5]  R623      1.5088914334774017e-01
    z[1,2,5]  R624      4.6108019351959229e-01
    z[1,2,5]  R625      3.8675445318222046e-01
    z[1,2,5]  R626      -4.6548891067504883e-01
    z[1,2,5]  R627      3.6300638318061829e-01
    z[1,2,5]  R628      -4.7204324603080750e-01
    z[1,2,5]  R629      2.2548133134841919e-01
    z[1,2,5]  R630      0.294140487909317
    z[1,2,5]  R631      0.269062876701355
    z[1,2,5]  R632      2.7389529347419739e-01
    z[1,2,5]  R633      1.9392102956771851e-01
    z[1,2,5]  R634      2.6628965139389038e-01
    z[1,2,5]  R635      1.4974293299019337e-02
    z[1,2,5]  R636      3.5737559199333191e-01
    z[1,2,5]  R637      3.9832450449466705e-02
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R516      -1
    z[1,2,6]  R517      1
    z[1,2,6]  R518      1.7903280258178711e-01
    z[1,2,6]  R519      2.1552781760692596e-01
    z[1,2,6]  R520      -1.8531921505928040e-01
    z[1,2,6]  R521      -4.1614931076765060e-02
    z[1,2,6]  R522      -8.6111843585968018e-02
    z[1,2,6]  R523      1.7422136664390564e-01
    z[1,2,6]  R524      -2.1738973259925842e-01
    z[1,2,6]  R525      -2.2175389528274536e-01
    z[1,2,6]  R526      2.1136337518692017e-01
    z[1,2,6]  R527      -3.3586272597312927e-01
    z[1,2,6]  R528      2.3215837776660919e-01
    z[1,2,6]  R529      4.2681223154067993e-01
    z[1,2,6]  R530      4.9082913994789124e-01
    z[1,2,6]  R531      0.548614501953125
    z[1,2,6]  R532      5.6188172101974487e-01
    z[1,2,6]  R533      3.7740570306777954e-01
    z[1,2,6]  R534      2.4079778790473938e-01
    z[1,2,6]  R535      7.0146733522415161e-01
    z[1,2,6]  R536      5.0436311960220337e-01
    z[1,2,6]  R537      2.4577486515045166e-01
    z[1,2,6]  R538      -3.2198163866996765e-01
    z[1,2,6]  R539      1.0672981292009354e-01
    z[1,2,6]  R540      1.4407153427600861e-01
    z[1,2,6]  R541      3.9334241300821304e-02
    z[1,2,6]  R542      3.8813695311546326e-01
    z[1,2,6]  R543      2.6953229308128357e-01
    z[1,2,6]  R544      3.7290427088737488e-01
    z[1,2,6]  R545      2.6120588183403015e-01
    z[1,2,6]  R546      3.6627948284149170e-01
    z[1,2,6]  R547      -1.7489218711853027e-01
    z[1,2,6]  R548      -3.3026185631752014e-01
    z[1,2,6]  R549      2.1479737758636475e-01
    z[1,2,6]  R550      -2.4579374492168427e-01
    z[1,2,6]  R551      -3.0421912670135498e-02
    z[1,2,6]  R552      -1.5644830465316772e-01
    z[1,2,6]  R553      1.3995915651321411e-01
    z[1,2,6]  R554      -6.1815753579139709e-02
    z[1,2,6]  R555      -4.6537590026855469e-01
    z[1,2,6]  R556      -3.3084249496459961e-01
    z[1,2,6]  R557      -2.2959616780281067e-01
    z[1,2,6]  R558      1.6298945248126984e-01
    z[1,2,6]  R559      2.1789261698722839e-01
    z[1,2,6]  R560      6.7381441593170166e-02
    z[1,2,6]  R561      -1.1934030055999756e-01
    z[1,2,6]  R562      2.0152233541011810e-01
    z[1,2,6]  R563      1.1772727221250534e-01
    z[1,2,6]  R564      2.9406917095184326e-01
    z[1,2,6]  R565      -8.6259923875331879e-02
    z[1,2,6]  R566      -2.9275509715080261e-01
    z[1,2,6]  R567      -1.6995324194431305e-01
    z[1,2,6]  R568      -3.2412409782409668e-03
    z[1,2,6]  R569      3.4193581342697144e-01
    z[1,2,6]  R570      1.8364654481410980e-01
    z[1,2,6]  R571      -3.5997006297111511e-01
    z[1,2,6]  R572      -2.3075972497463226e-01
    z[1,2,6]  R573      2.1513873338699341e-01
    z[1,2,6]  R574      9.8632358014583588e-02
    z[1,2,6]  R575      6.1773583292961121e-02
    z[1,2,6]  R576      -2.1741646528244019e-01
    z[1,2,6]  R577      -0.35227170586586
    z[1,2,6]  R578      -2.1924762427806854e-01
    z[1,2,6]  R579      9.3395769596099854e-02
    z[1,2,6]  R580      -0.0913204550743103
    z[1,2,6]  R581      -4.8295024037361145e-01
    z[1,2,6]  R582      -5.7580333948135376e-01
    z[1,2,6]  R583      1.6845525801181793e-01
    z[1,2,6]  R584      1.4823305606842041e-01
    z[1,2,6]  R585      3.9097842574119568e-01
    z[1,2,6]  R586      3.6733604967594147e-02
    z[1,2,6]  R587      -7.2574533522129059e-02
    z[1,2,6]  R588      -2.1921820938587189e-01
    z[1,2,6]  R589      1.3556529302150011e-03
    z[1,2,6]  R590      -4.4133153557777405e-01
    z[1,2,6]  R591      -2.1631265059113503e-02
    z[1,2,6]  R592      -1.7923298478126526e-01
    z[1,2,6]  R593      -3.5379937291145325e-01
    z[1,2,6]  R594      1.1794251948595047e-01
    z[1,2,6]  R595      7.2125848382711411e-03
    z[1,2,6]  R596      2.1438100934028625e-01
    z[1,2,6]  R597      5.8446694165468216e-02
    z[1,2,6]  R598      -7.5831925496459007e-03
    z[1,2,6]  R599      3.1768417358398438e-01
    z[1,2,6]  R600      2.2149063646793365e-01
    z[1,2,6]  R601      -6.1537390947341919e-01
    z[1,2,6]  R602      -5.8910536766052246e-01
    z[1,2,6]  R603      -2.8587639331817627e-01
    z[1,2,6]  R604      -4.2594605684280396e-01
    z[1,2,6]  R605      -1.7558148503303528e-01
    z[1,2,6]  R606      -6.2235742807388306e-01
    z[1,2,6]  R607      -1.8804767727851868e-01
    z[1,2,6]  R608      -7.9052805900573730e-02
    z[1,2,6]  R609      1.1902947723865509e-01
    z[1,2,6]  R610      -2.0897845923900604e-01
    z[1,2,6]  R611      -2.2031184285879135e-02
    z[1,2,6]  R612      -1.8457492114976048e-03
    z[1,2,6]  R613      -2.4557389318943024e-02
    z[1,2,6]  R614      0.099223293364048
    z[1,2,6]  R615      -0.486009806394577
    z[1,2,6]  R616      4.5687224715948105e-02
    z[1,2,6]  R617      4.2492789030075073e-01
    z[1,2,6]  R618      -6.0149419307708740e-01
    z[1,2,6]  R619      3.4033574163913727e-02
    z[1,2,6]  R620      3.5291877388954163e-01
    z[1,2,6]  R621      4.9176418781280518e-01
    z[1,2,6]  R622      0.0779540166258812
    z[1,2,6]  R623      -2.0374687016010284e-01
    z[1,2,6]  R624      1.2019833549857140e-02
    z[1,2,6]  R625      3.5785309970378876e-02
    z[1,2,6]  R626      -2.8921410441398621e-02
    z[1,2,6]  R627      1.3505174219608307e-01
    z[1,2,6]  R628      2.7569654583930969e-01
    z[1,2,6]  R629      -2.7953290939331055e-01
    z[1,2,6]  R630      -8.8077886030077934e-03
    z[1,2,6]  R631      -1.6440071165561676e-01
    z[1,2,6]  R632      2.0350660383701324e-01
    z[1,2,6]  R633      1.4017286896705627e-01
    z[1,2,6]  R634      -1.0919430851936340e-01
    z[1,2,6]  R635      -2.2402319312095642e-01
    z[1,2,6]  R636      -1.3143707811832428e-01
    z[1,2,6]  R637      0.0490855909883976
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R638      -1
    z[2,1,0]  R639      1
    z[2,1,0]  R652      8.6434870958328247e-01
    z[2,1,0]  R653      6.6791445016860962e-01
    z[2,1,0]  R654      4.6498170495033264e-01
    z[2,1,0]  R655      0.728111743927002
    z[2,1,0]  R656      4.3952608108520508e-01
    z[2,1,0]  R657      4.9878180027008057e-01
    z[2,1,0]  R658      3.3203712105751038e-01
    z[2,1,0]  R659      -3.1681719422340393e-01
    z[2,1,0]  R660      -2.2113482654094696e-01
    z[2,1,0]  R661      -4.0880167484283447e-01
    z[2,1,0]  R662      1.5702225267887115e-01
    z[2,1,0]  R663      8.3548091351985931e-02
    z[2,1,0]  R664      -1.2691356241703033e-01
    z[2,1,0]  R665      2.9052982106804848e-02
    z[2,1,0]  R666      -3.8130503892898560e-01
    z[2,1,0]  R667      -3.5953405499458313e-01
    z[2,1,0]  R668      1.6758590936660767e-01
    z[2,1,0]  R669      -2.6364507153630257e-02
    z[2,1,0]  R670      4.3519932031631470e-01
    z[2,1,0]  R671      -8.5451684892177582e-02
    z[2,1,0]  R672      1.0135149210691452e-01
    z[2,1,0]  R673      -1.2466557323932648e-01
    z[2,1,0]  R674      -5.1005119085311890e-01
    z[2,1,0]  R675      -2.8411766886711121e-01
    z[2,1,0]  R676      -6.6755360364913940e-01
    z[2,1,0]  R677      -8.4686893224716187e-01
    z[2,1,0]  R678      -6.4801824092864990e-01
    z[2,1,0]  R679      -7.4008554220199585e-01
    z[2,1,0]  R680      -6.8051880598068237e-01
    z[2,1,0]  R681      -8.6460644006729126e-01
    z[2,1,0]  R682      -2.0326793193817139e-01
    z[2,1,0]  R683      -0.0492432564496994
    z[2,1,0]  R684      -3.1620556116104126e-01
    z[2,1,0]  R685      -6.6749915480613708e-02
    z[2,1,0]  R686      -0.070064976811409
    z[2,1,0]  R687      4.1202157735824585e-01
    z[2,1,0]  R688      -8.6416286230087280e-01
    z[2,1,0]  R689      -6.2534677982330322e-01
    z[2,1,0]  R690      -4.6929138898849487e-01
    z[2,1,0]  R691      -4.9503171443939209e-01
    z[2,1,0]  R692      0.792331874370575
    z[2,1,0]  R693      8.2360351085662842e-01
    z[2,1,0]  R694      0.825454592704773
    z[2,1,0]  R695      7.6305472850799561e-01
    z[2,1,0]  R696      9.1392600536346436e-01
    z[2,1,0]  R697      0.52276611328125
    z[2,1,0]  R698      0.848131537437439
    z[2,1,0]  R699      3.7846568226814270e-01
    z[2,1,0]  R700      -8.1787988543510437e-02
    z[2,1,0]  R701      -6.8388646841049194e-01
    z[2,1,0]  R702      -7.1314197778701782e-01
    z[2,1,0]  R703      -7.2746276855468750e-01
    z[2,1,0]  R704      -5.6805860996246338e-01
    z[2,1,0]  R705      -3.9287251234054565e-01
    z[2,1,0]  R706      -4.2372727394104004e-01
    z[2,1,0]  R707      -3.5243424773216248e-01
    z[2,1,0]  R708      -3.3037438988685608e-01
    z[2,1,0]  R709      -5.1508784294128418e-01
    z[2,1,0]  R710      -1.1502622812986374e-01
    z[2,1,0]  R711      -5.5213999748229980e-01
    z[2,1,0]  R712      -8.8299199938774109e-02
    z[2,1,0]  R713      -3.2991442084312439e-01
    z[2,1,0]  R714      -5.8540350198745728e-01
    z[2,1,0]  R715      -1.1914123594760895e-01
    z[2,1,0]  R716      -2.3966337740421295e-01
    z[2,1,0]  R717      -3.7223327159881592e-01
    z[2,1,0]  R718      -8.0146938562393188e-01
    z[2,1,0]  R719      -5.7806009054183960e-01
    z[2,1,0]  R720      -6.4372068643569946e-01
    z[2,1,0]  R721      -5.0161868333816528e-01
    z[2,1,0]  R722      -8.6371667683124542e-02
    z[2,1,0]  R723      1.6991788521409035e-02
    z[2,1,0]  R724      -6.1657375097274780e-01
    z[2,1,0]  R725      -9.1038918495178223e-01
    z[2,1,0]  R726      3.5387545824050903e-01
    z[2,1,0]  R727      -5.5890983343124390e-01
    z[2,1,0]  R728      -4.4688713550567627e-01
    z[2,1,0]  R729      -1.9498790800571442e-01
    z[2,1,0]  R730      -7.7668559551239014e-01
    z[2,1,0]  R731      -3.8441443443298340e-01
    z[2,1,0]  R732      -2.9512861371040344e-01
    z[2,1,0]  R733      -0.0926283597946167
    z[2,1,0]  R734      -8.3295780420303345e-01
    z[2,1,0]  R735      -7.3763936758041382e-01
    z[2,1,0]  R736      -8.3456999063491821e-01
    z[2,1,0]  R737      -7.8176146745681763e-01
    z[2,1,0]  R738      -7.6022058725357056e-01
    z[2,1,0]  R739      -5.2391797304153442e-01
    z[2,1,0]  R740      -8.8238435983657837e-01
    z[2,1,0]  R741      -6.3313668966293335e-01
    z[2,1,0]  R742      -8.8090650737285614e-02
    z[2,1,0]  R743      -2.4210691452026367e-01
    z[2,1,0]  R744      -8.2538688182830811e-01
    z[2,1,0]  R745      -3.1109073758125305e-01
    z[2,1,0]  R746      -2.5181236863136292e-01
    z[2,1,0]  R747      3.0048617720603943e-01
    z[2,1,0]  R748      -3.4604933857917786e-01
    z[2,1,0]  R749      -2.4814704060554504e-01
    z[2,1,0]  R750      -2.2024038434028625e-01
    z[2,1,0]  R751      -1.9153533875942230e-01
    z[2,1,0]  R752      -3.9020866155624390e-01
    z[2,1,0]  R753      -8.9242297410964966e-01
    z[2,1,0]  R754      -9.0254890918731689e-01
    z[2,1,0]  R755      -4.8743051290512085e-01
    z[2,1,0]  R756      -3.9723870158195496e-01
    z[2,1,0]  R757      2.5431382656097412e-01
    z[2,1,0]  R758      -2.8373831510543823e-01
    z[2,1,0]  R759      -7.5022215023636818e-03
    z[2,1,0]  R760      -4.0039947628974915e-01
    z[2,1,0]  R761      -0.390885591506958
    z[2,1,0]  R762      1.3482457399368286e-01
    z[2,1,0]  R763      -7.1054035425186157e-01
    z[2,1,0]  R764      -6.1111062765121460e-01
    z[2,1,0]  R765      3.4063592553138733e-01
    z[2,1,0]  R766      -2.8471186757087708e-01
    z[2,1,0]  R767      -4.9109966494143009e-03
    z[2,1,0]  R768      -4.6274831891059875e-01
    z[2,1,0]  R769      -4.1613438725471497e-01
    z[2,1,0]  R770      -3.3148407936096191e-01
    z[2,1,0]  R771      -0.0384528785943985
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R640      -1
    z[2,1,1]  R641      1
    z[2,1,1]  R652      -4.0723243355751038e-01
    z[2,1,1]  R653      -4.3571284413337708e-01
    z[2,1,1]  R654      -0.633994460105896
    z[2,1,1]  R655      -2.0166671276092529e-01
    z[2,1,1]  R656      -3.9191511273384094e-01
    z[2,1,1]  R657      -9.8720192909240723e-03
    z[2,1,1]  R658      1.8145754933357239e-02
    z[2,1,1]  R659      -6.2250858545303345e-01
    z[2,1,1]  R660      -5.6228274106979370e-01
    z[2,1,1]  R661      -7.7131259441375732e-01
    z[2,1,1]  R662      7.5322926044464111e-01
    z[2,1,1]  R663      6.4812260866165161e-01
    z[2,1,1]  R664      5.3232693672180176e-01
    z[2,1,1]  R665      6.2306547164916992e-01
    z[2,1,1]  R666      6.3632696866989136e-01
    z[2,1,1]  R667      5.3356373310089111e-01
    z[2,1,1]  R668      7.9223489761352539e-01
    z[2,1,1]  R669      6.9819223880767822e-01
    z[2,1,1]  R670      6.7886650562286377e-01
    z[2,1,1]  R671      8.7288916110992432e-01
    z[2,1,1]  R672      -4.1749957203865051e-01
    z[2,1,1]  R673      0.735876202583313
    z[2,1,1]  R674      0.458394318819046
    z[2,1,1]  R675      2.1090948581695557e-01
    z[2,1,1]  R676      3.6799290776252747e-01
    z[2,1,1]  R677      1.1673334985971451e-01
    z[2,1,1]  R678      -9.0482152998447418e-02
    z[2,1,1]  R679      -1.7473979294300079e-01
    z[2,1,1]  R680      3.9658805727958679e-01
    z[2,1,1]  R681      -1.0264360159635544e-01
    z[2,1,1]  R682      -4.9712833762168884e-01
    z[2,1,1]  R683      8.2093644142150879e-01
    z[2,1,1]  R684      8.6742001771926880e-01
    z[2,1,1]  R685      0.866395115852356
    z[2,1,1]  R686      0.307373583316803
    z[2,1,1]  R687      5.8181345462799072e-01
    z[2,1,1]  R688      -1.6553734242916107e-01
    z[2,1,1]  R689      -1.4171253144741058e-01
    z[2,1,1]  R690      -2.8058373928070068e-01
    z[2,1,1]  R691      1.7950499057769775e-01
    z[2,1,1]  R692      -1.0905101150274277e-01
    z[2,1,1]  R693      1.5836556255817413e-01
    z[2,1,1]  R694      1.2569531798362732e-01
    z[2,1,1]  R695      2.5770911574363708e-01
    z[2,1,1]  R696      -1.0237623006105423e-01
    z[2,1,1]  R697      -4.1197243332862854e-01
    z[2,1,1]  R698      -3.0243989825248718e-01
    z[2,1,1]  R699      -2.8250840306282043e-01
    z[2,1,1]  R700      7.2571784257888794e-01
    z[2,1,1]  R701      2.8844487667083740e-01
    z[2,1,1]  R702      1.3543620705604553e-01
    z[2,1,1]  R703      2.1578861773014069e-01
    z[2,1,1]  R704      2.0259724557399750e-01
    z[2,1,1]  R705      4.7164192795753479e-01
    z[2,1,1]  R706      -6.6417090594768524e-02
    z[2,1,1]  R707      -1.0809313505887985e-01
    z[2,1,1]  R708      -2.3711220920085907e-01
    z[2,1,1]  R709      2.8366753458976746e-01
    z[2,1,1]  R710      6.7696201801300049e-01
    z[2,1,1]  R711      -4.1145187616348267e-01
    z[2,1,1]  R712      8.4717440605163574e-01
    z[2,1,1]  R713      8.5122102499008179e-01
    z[2,1,1]  R714      2.0687554776668549e-01
    z[2,1,1]  R715      8.9596009254455566e-01
    z[2,1,1]  R716      0.419808566570282
    z[2,1,1]  R717      7.7928400039672852e-01
    z[2,1,1]  R718      -2.8380360454320908e-02
    z[2,1,1]  R719      0.0535450242459774
    z[2,1,1]  R720      -1.3417863845825195e-01
    z[2,1,1]  R721      4.8361358046531677e-01
    z[2,1,1]  R722      5.3514945507049561e-01
    z[2,1,1]  R723      4.9760690331459045e-01
    z[2,1,1]  R724      -2.2233970463275909e-01
    z[2,1,1]  R725      -3.3424004912376404e-01
    z[2,1,1]  R726      4.5104047656059265e-01
    z[2,1,1]  R727      3.2487812638282776e-01
    z[2,1,1]  R728      3.1988728046417236e-01
    z[2,1,1]  R729      -1.3790245354175568e-01
    z[2,1,1]  R730      1.8276622891426086e-01
    z[2,1,1]  R731      1.6258032619953156e-01
    z[2,1,1]  R732      0.658534049987793
    z[2,1,1]  R733      7.2154521942138672e-01
    z[2,1,1]  R734      9.6430137753486633e-02
    z[2,1,1]  R735      -2.9100757837295532e-01
    z[2,1,1]  R736      -1.7757755517959595e-01
    z[2,1,1]  R737      2.8576648235321045e-01
    z[2,1,1]  R738      3.4093910455703735e-01
    z[2,1,1]  R739      1.8604382872581482e-01
    z[2,1,1]  R740      -1.4244794845581055e-01
    z[2,1,1]  R741      1.3397786021232605e-01
    z[2,1,1]  R742      7.2524315118789673e-01
    z[2,1,1]  R743      6.8998634815216064e-01
    z[2,1,1]  R744      2.6473295688629150e-01
    z[2,1,1]  R745      7.2068822383880615e-01
    z[2,1,1]  R746      7.3601621389389038e-01
    z[2,1,1]  R747      3.9459916949272156e-01
    z[2,1,1]  R748      -0.512565016746521
    z[2,1,1]  R749      -4.3045002222061157e-01
    z[2,1,1]  R750      -4.1318696737289429e-01
    z[2,1,1]  R751      -3.9167153835296631e-01
    z[2,1,1]  R752      8.1174737215042114e-01
    z[2,1,1]  R753      2.1241806447505951e-01
    z[2,1,1]  R754      -1.6283838078379631e-02
    z[2,1,1]  R755      -1.2810570001602173e-01
    z[2,1,1]  R756      1.7376622557640076e-01
    z[2,1,1]  R757      5.9266769886016846e-01
    z[2,1,1]  R758      -6.2614244222640991e-01
    z[2,1,1]  R759      -6.3249868154525757e-01
    z[2,1,1]  R760      -5.1105105876922607e-01
    z[2,1,1]  R761      -3.7430158257484436e-01
    z[2,1,1]  R762      7.7420455217361450e-01
    z[2,1,1]  R763      2.3767906427383423e-01
    z[2,1,1]  R764      -1.1000989377498627e-01
    z[2,1,1]  R765      7.1379250288009644e-01
    z[2,1,1]  R766      -1.3433446176350117e-02
    z[2,1,1]  R767      0.693791925907135
    z[2,1,1]  R768      -4.7620710730552673e-01
    z[2,1,1]  R769      -5.3375661373138428e-01
    z[2,1,1]  R770      -5.4656445980072021e-01
    z[2,1,1]  R771      -0.770487368106842
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R642      -1
    z[2,1,2]  R643      1
    z[2,1,2]  R652      6.7390188574790955e-02
    z[2,1,2]  R653      3.0142614245414734e-01
    z[2,1,2]  R654      1.5732099115848541e-01
    z[2,1,2]  R655      2.0724116265773773e-01
    z[2,1,2]  R656      1.4994834363460541e-01
    z[2,1,2]  R657      4.1898164153099060e-01
    z[2,1,2]  R658      4.5498472452163696e-01
    z[2,1,2]  R659      4.7741052508354187e-01
    z[2,1,2]  R660      3.5086354613304138e-01
    z[2,1,2]  R661      2.8349253535270691e-01
    z[2,1,2]  R662      -4.3035313487052917e-01
    z[2,1,2]  R663      -3.2790485024452209e-01
    z[2,1,2]  R664      -6.1819630861282349e-01
    z[2,1,2]  R665      -6.7858254909515381e-01
    z[2,1,2]  R666      -5.1824736595153809e-01
    z[2,1,2]  R667      -3.8327559828758240e-01
    z[2,1,2]  R668      -4.7408428788185120e-01
    z[2,1,2]  R669      -3.9438962936401367e-01
    z[2,1,2]  R670      -4.2634752392768860e-01
    z[2,1,2]  R671      -2.0455385744571686e-01
    z[2,1,2]  R672      3.1482407450675964e-01
    z[2,1,2]  R673      0.0796460285782814
    z[2,1,2]  R674      4.6889832615852356e-01
    z[2,1,2]  R675      6.7965364456176758e-01
    z[2,1,2]  R676      3.7591493129730225e-01
    z[2,1,2]  R677      -3.5959637165069580e-01
    z[2,1,2]  R678      -5.1113218069076538e-01
    z[2,1,2]  R679      -4.6645429730415344e-01
    z[2,1,2]  R680      1.7479488253593445e-01
    z[2,1,2]  R681      -2.1831433475017548e-01
    z[2,1,2]  R682      3.5196727514266968e-01
    z[2,1,2]  R683      -2.9363530874252319e-01
    z[2,1,2]  R684      -1.0206980258226395e-01
    z[2,1,2]  R685      8.3683505654335022e-02
    z[2,1,2]  R686      7.9446166753768921e-01
    z[2,1,2]  R687      2.9570186138153076e-01
    z[2,1,2]  R688      -3.6811664700508118e-01
    z[2,1,2]  R689      -0.686767041683197
    z[2,1,2]  R690      -7.2401577234268188e-01
    z[2,1,2]  R691      -7.6279765367507935e-01
    z[2,1,2]  R692      4.9007475376129150e-01
    z[2,1,2]  R693      4.3332302570343018e-01
    z[2,1,2]  R694      4.3423864245414734e-01
    z[2,1,2]  R695      4.5883128046989441e-01
    z[2,1,2]  R696      1.3983765617012978e-02
    z[2,1,2]  R697      3.9672231674194336e-01
    z[2,1,2]  R698      -4.8237197101116180e-02
    z[2,1,2]  R699      7.5016999244689941e-01
    z[2,1,2]  R700      4.5759268105030060e-02
    z[2,1,2]  R701      -4.7399401664733887e-01
    z[2,1,2]  R702      -2.5449833273887634e-01
    z[2,1,2]  R703      -3.9830714464187622e-02
    z[2,1,2]  R704      -8.1029146909713745e-02
    z[2,1,2]  R705      -4.7255808115005493e-01
    z[2,1,2]  R706      -3.2451364398002625e-01
    z[2,1,2]  R707      -5.6197357177734375e-01
    z[2,1,2]  R708      -7.3531186580657959e-01
    z[2,1,2]  R709      -3.0125150084495544e-01
    z[2,1,2]  R710      -4.2521965503692627e-01
    z[2,1,2]  R711      -2.5884151458740234e-01
    z[2,1,2]  R712      -8.2246296107769012e-02
    z[2,1,2]  R713      7.3520161211490631e-02
    z[2,1,2]  R714      -6.6690897941589355e-01
    z[2,1,2]  R715      1.5338120982050896e-02
    z[2,1,2]  R716      -5.3181946277618408e-01
    z[2,1,2]  R717      -1.4147794246673584e-01
    z[2,1,2]  R718      -4.2270419001579285e-01
    z[2,1,2]  R719      -0.382876992225647
    z[2,1,2]  R720      -5.3503000736236572e-01
    z[2,1,2]  R721      -4.7239184379577637e-01
    z[2,1,2]  R722      -2.2648519277572632e-01
    z[2,1,2]  R723      -5.0820887088775635e-01
    z[2,1,2]  R724      -4.1381460428237915e-01
    z[2,1,2]  R725      -1.9720740616321564e-01
    z[2,1,2]  R726      -6.2122678756713867e-01
    z[2,1,2]  R727      -4.2674034833908081e-01
    z[2,1,2]  R728      -4.9503925442695618e-01
    z[2,1,2]  R729      -8.2410043478012085e-01
    z[2,1,2]  R730      1.0093321651220322e-01
    z[2,1,2]  R731      -5.6082463264465332e-01
    z[2,1,2]  R732      9.7608342766761780e-02
    z[2,1,2]  R733      -3.7305000424385071e-01
    z[2,1,2]  R734      -2.8750467300415039e-01
    z[2,1,2]  R735      -5.1594811677932739e-01
    z[2,1,2]  R736      -4.1705605387687683e-01
    z[2,1,2]  R737      -7.9808674752712250e-02
    z[2,1,2]  R738      -4.5072114467620850e-01
    z[2,1,2]  R739      -5.7259029150009155e-01
    z[2,1,2]  R740      0.0425020195543766
    z[2,1,2]  R741      -5.8257788419723511e-01
    z[2,1,2]  R742      -2.9622277617454529e-01
    z[2,1,2]  R743      1.0739636421203613e-01
    z[2,1,2]  R744      -2.8401133418083191e-01
    z[2,1,2]  R745      -7.5146481394767761e-02
    z[2,1,2]  R746      4.0949344635009766e-01
    z[2,1,2]  R747      -5.9676694869995117e-01
    z[2,1,2]  R748      7.0104055106639862e-02
    z[2,1,2]  R749      2.5865691900253296e-01
    z[2,1,2]  R750      0.045010045170784
    z[2,1,2]  R751      2.1633841097354889e-03
    z[2,1,2]  R752      1.3381724059581757e-01
    z[2,1,2]  R753      -2.4735182523727417e-01
    z[2,1,2]  R754      -3.2939341664314270e-01
    z[2,1,2]  R755      -6.7971074581146240e-01
    z[2,1,2]  R756      -2.6860460638999939e-01
    z[2,1,2]  R757      -6.2600922584533691e-01
    z[2,1,2]  R758      7.3427930474281311e-02
    z[2,1,2]  R759      -5.4973983764648438e-01
    z[2,1,2]  R760      3.5052296519279480e-01
    z[2,1,2]  R761      1.9565726816654205e-01
    z[2,1,2]  R762      -0.0914430320262909
    z[2,1,2]  R763      -2.7722349762916565e-01
    z[2,1,2]  R764      -6.3867402076721191e-01
    z[2,1,2]  R765      -0.552993655204773
    z[2,1,2]  R766      -6.2353104352951050e-01
    z[2,1,2]  R767      -3.4796708822250366e-01
    z[2,1,2]  R768      2.6201891899108887e-01
    z[2,1,2]  R769      3.3248621225357056e-01
    z[2,1,2]  R770      4.4115567207336426e-01
    z[2,1,2]  R771      -1.0193391889333725e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R644      -1
    z[2,1,3]  R645      1
    z[2,1,3]  R652      -1.5914860367774963e-01
    z[2,1,3]  R653      -5.3766336292028427e-02
    z[2,1,3]  R654      1.4396573603153229e-01
    z[2,1,3]  R655      -2.5104392319917679e-02
    z[2,1,3]  R656      -1.3331703841686249e-01
    z[2,1,3]  R657      -3.7810721993446350e-01
    z[2,1,3]  R658      -5.7165306806564331e-01
    z[2,1,3]  R659      -1.8017520010471344e-01
    z[2,1,3]  R660      -2.6484557986259460e-01
    z[2,1,3]  R661      -2.8375267982482910e-01
    z[2,1,3]  R662      2.5552812218666077e-01
    z[2,1,3]  R663      0.397329717874527
    z[2,1,3]  R664      4.9832960963249207e-01
    z[2,1,3]  R665      3.3659121394157410e-01
    z[2,1,3]  R666      0.315348356962204
    z[2,1,3]  R667      5.1529526710510254e-01
    z[2,1,3]  R668      2.5374817848205566e-01
    z[2,1,3]  R669      3.0752077698707581e-01
    z[2,1,3]  R670      3.7837514281272888e-01
    z[2,1,3]  R671      8.2159496843814850e-02
    z[2,1,3]  R672      -1.5864214301109314e-01
    z[2,1,3]  R673      2.3752050101757050e-01
    z[2,1,3]  R674      -2.7910497784614563e-01
    z[2,1,3]  R675      -3.8216370344161987e-01
    z[2,1,3]  R676      -3.6438465118408203e-01
    z[2,1,3]  R677      -1.6845697164535522e-01
    z[2,1,3]  R678      -2.9784658551216125e-01
    z[2,1,3]  R679      -1.4176808297634125e-01
    z[2,1,3]  R680      2.3424679413437843e-02
    z[2,1,3]  R681      -2.0129530131816864e-01
    z[2,1,3]  R682      -5.1793640851974487e-01
    z[2,1,3]  R683      3.2918041944503784e-01
    z[2,1,3]  R684      2.1268796920776367e-01
    z[2,1,3]  R685      1.9512437283992767e-01
    z[2,1,3]  R686      -3.7618613243103027e-01
    z[2,1,3]  R687      -2.0109087228775024e-01
    z[2,1,3]  R688      0.073503777384758
    z[2,1,3]  R689      -2.3019200563430786e-01
    z[2,1,3]  R690      1.4721383154392242e-01
    z[2,1,3]  R691      -2.4338087439537048e-01
    z[2,1,3]  R692      9.2287629842758179e-02
    z[2,1,3]  R693      -2.0014800131320953e-01
    z[2,1,3]  R694      -8.5034728050231934e-02
    z[2,1,3]  R695      1.3058932125568390e-01
    z[2,1,3]  R696      3.0125194787979126e-01
    z[2,1,3]  R697      0.520189642906189
    z[2,1,3]  R698      1.3079671561717987e-01
    z[2,1,3]  R699      2.5256437063217163e-01
    z[2,1,3]  R700      4.0579503774642944e-01
    z[2,1,3]  R701      0.0964856743812561
    z[2,1,3]  R702      2.9296535253524780e-01
    z[2,1,3]  R703      -3.7418681383132935e-01
    z[2,1,3]  R704      -1.3086028397083282e-01
    z[2,1,3]  R705      -1.7786049842834473e-01
    z[2,1,3]  R706      4.3679423630237579e-02
    z[2,1,3]  R707      1.2698574364185333e-01
    z[2,1,3]  R708      -3.3059798181056976e-02
    z[2,1,3]  R709      2.4960565567016602e-01
    z[2,1,3]  R710      1.2818354368209839e-01
    z[2,1,3]  R711      -2.8161531314253807e-02
    z[2,1,3]  R712      1.8379606306552887e-01
    z[2,1,3]  R713      8.9184358716011047e-02
    z[2,1,3]  R714      3.0218443274497986e-01
    z[2,1,3]  R715      -1.7567628622055054e-01
    z[2,1,3]  R716      5.6137013435363770e-01
    z[2,1,3]  R717      -2.5533020496368408e-02
    z[2,1,3]  R718      7.2698421776294708e-02
    z[2,1,3]  R719      1.2450806796550751e-01
    z[2,1,3]  R720      2.0046686753630638e-02
    z[2,1,3]  R721      4.0017595887184143e-01
    z[2,1,3]  R722      7.2901839017868042e-01
    z[2,1,3]  R723      6.1173772811889648e-01
    z[2,1,3]  R724      2.6643732190132141e-01
    z[2,1,3]  R725      1.3333716988563538e-01
    z[2,1,3]  R726      -4.6903842687606812e-01
    z[2,1,3]  R727      -5.6975334882736206e-01
    z[2,1,3]  R728      -6.2637668848037720e-01
    z[2,1,3]  R729      -1.3208748772740364e-02
    z[2,1,3]  R730      -2.7006399631500244e-01
    z[2,1,3]  R731      -0.284567654132843
    z[2,1,3]  R732      6.2359935045242310e-01
    z[2,1,3]  R733      2.0508620142936707e-01
    z[2,1,3]  R734      -3.4290376305580139e-01
    z[2,1,3]  R735      0.0787176638841629
    z[2,1,3]  R736      -3.1505491584539413e-02
    z[2,1,3]  R737      -1.8802741169929504e-01
    z[2,1,3]  R738      -7.6615914702415466e-02
    z[2,1,3]  R739      -4.5816308259963989e-01
    z[2,1,3]  R740      1.0480262339115143e-02
    z[2,1,3]  R741      -1.6463990509510040e-01
    z[2,1,3]  R742      4.9492558836936951e-01
    z[2,1,3]  R743      5.1039123535156250e-01
    z[2,1,3]  R744      1.5957221388816833e-01
    z[2,1,3]  R745      2.0176191627979279e-01
    z[2,1,3]  R746      2.0435136556625366e-01
    z[2,1,3]  R747      2.4046385660767555e-02
    z[2,1,3]  R748      1.0196488350629807e-01
    z[2,1,3]  R749      -1.8244255334138870e-02
    z[2,1,3]  R750      1.2740735709667206e-01
    z[2,1,3]  R751      1.6273528337478638e-01
    z[2,1,3]  R752      2.0743475854396820e-01
    z[2,1,3]  R753      1.2848366796970367e-01
    z[2,1,3]  R754      1.8277525901794434e-01
    z[2,1,3]  R755      -1.0069535672664642e-01
    z[2,1,3]  R756      -2.6078507304191589e-01
    z[2,1,3]  R757      1.5137994289398193e-01
    z[2,1,3]  R758      2.1282330155372620e-01
    z[2,1,3]  R759      8.2246467471122742e-02
    z[2,1,3]  R760      -4.5397719740867615e-01
    z[2,1,3]  R761      -3.9986866712570190e-01
    z[2,1,3]  R762      4.1989326477050781e-01
    z[2,1,3]  R763      -1.0096883773803711e-01
    z[2,1,3]  R764      -9.7536019980907440e-02
    z[2,1,3]  R765      -2.5212657451629639e-01
    z[2,1,3]  R766      2.8084175661206245e-02
    z[2,1,3]  R767      1.8539489805698395e-01
    z[2,1,3]  R768      -5.8655989170074463e-01
    z[2,1,3]  R769      -4.3416237831115723e-01
    z[2,1,3]  R770      -4.5367926359176636e-01
    z[2,1,3]  R771      -6.1849749088287354e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R646      -1
    z[2,1,4]  R647      1
    z[2,1,4]  R652      -4.1487328708171844e-02
    z[2,1,4]  R653      4.1146057844161987e-01
    z[2,1,4]  R654      -3.0920660495758057e-01
    z[2,1,4]  R655      -2.9925815761089325e-03
    z[2,1,4]  R656      4.3003222346305847e-01
    z[2,1,4]  R657      4.5306283235549927e-01
    z[2,1,4]  R658      -9.0662069618701935e-02
    z[2,1,4]  R659      -3.3379447460174561e-01
    z[2,1,4]  R660      -2.3181785643100739e-01
    z[2,1,4]  R661      9.9848099052906036e-02
    z[2,1,4]  R662      -3.7160521745681763e-01
    z[2,1,4]  R663      -3.4199967980384827e-01
    z[2,1,4]  R664      -8.8972700759768486e-03
    z[2,1,4]  R665      -1.7658649384975433e-01
    z[2,1,4]  R666      -2.6077610254287720e-01
    z[2,1,4]  R667      5.7250197976827621e-02
    z[2,1,4]  R668      1.6314479708671570e-01
    z[2,1,4]  R669      -1.0265620797872543e-01
    z[2,1,4]  R670      1.2650048732757568e-01
    z[2,1,4]  R671      1.1672622524201870e-02
    z[2,1,4]  R672      -5.2131730318069458e-01
    z[2,1,4]  R673      5.6925231218338013e-01
    z[2,1,4]  R674      1.6688981652259827e-01
    z[2,1,4]  R675      1.3613104820251465e-01
    z[2,1,4]  R676      2.9619839787483215e-01
    z[2,1,4]  R677      2.1729892492294312e-01
    z[2,1,4]  R678      -9.5797322690486908e-02
    z[2,1,4]  R679      1.8221385776996613e-01
    z[2,1,4]  R680      3.6193040013313293e-01
    z[2,1,4]  R681      6.1044171452522278e-02
    z[2,1,4]  R682      1.4343340694904327e-01
    z[2,1,4]  R683      -8.7525574490427971e-03
    z[2,1,4]  R684      -7.3115348815917969e-02
    z[2,1,4]  R685      3.1686764955520630e-01
    z[2,1,4]  R686      -1.0720803588628769e-01
    z[2,1,4]  R687      -5.5371510982513428e-01
    z[2,1,4]  R688      -4.5539274811744690e-02
    z[2,1,4]  R689      -0.117519810795784
    z[2,1,4]  R690      -1.0086910426616669e-01
    z[2,1,4]  R691      2.7862343192100525e-01
    z[2,1,4]  R692      5.0804324448108673e-02
    z[2,1,4]  R693      -1.2158947438001633e-01
    z[2,1,4]  R694      5.3107652813196182e-02
    z[2,1,4]  R695      3.2538601756095886e-01
    z[2,1,4]  R696      5.5658418685197830e-02
    z[2,1,4]  R697      -1.0907003283500671e-01
    z[2,1,4]  R698      -2.5865745544433594e-01
    z[2,1,4]  R699      3.1789198517799377e-01
    z[2,1,4]  R700      -3.3076703548431396e-01
    z[2,1,4]  R701      2.2788918018341064e-01
    z[2,1,4]  R702      -3.0153882503509521e-01
    z[2,1,4]  R703      -2.3667715489864349e-01
    z[2,1,4]  R704      -3.1775414943695068e-01
    z[2,1,4]  R705      -2.4732597172260284e-01
    z[2,1,4]  R706      -4.9626824259757996e-01
    z[2,1,4]  R707      -3.7221285700798035e-01
    z[2,1,4]  R708      -4.7242611646652222e-01
    z[2,1,4]  R709      -8.9234240353107452e-02
    z[2,1,4]  R710      -6.1968307942152023e-02
    z[2,1,4]  R711      -5.1120370626449585e-01
    z[2,1,4]  R712      -3.1448808312416077e-01
    z[2,1,4]  R713      3.5533782839775085e-01
    z[2,1,4]  R714      -6.0251239687204361e-02
    z[2,1,4]  R715      1.3012728095054626e-01
    z[2,1,4]  R716      1.3269375264644623e-01
    z[2,1,4]  R717      -2.1954169869422913e-01
    z[2,1,4]  R718      -1.6888792812824249e-01
    z[2,1,4]  R719      -3.0619928240776062e-01
    z[2,1,4]  R720      -0.377180278301239
    z[2,1,4]  R721      -1.5033121220767498e-02
    z[2,1,4]  R722      1.1791370809078217e-01
    z[2,1,4]  R723      -1.9858722388744354e-01
    z[2,1,4]  R724      -1.1424652487039566e-01
    z[2,1,4]  R725      -3.3420909196138382e-02
    z[2,1,4]  R726      -1.7674843966960907e-01
    z[2,1,4]  R727      -1.8118312954902649e-01
    z[2,1,4]  R728      -2.3258654773235321e-01
    z[2,1,4]  R729      -1.8965248763561249e-01
    z[2,1,4]  R730      -4.0404719114303589e-01
    z[2,1,4]  R731      -0.604387640953064
    z[2,1,4]  R732      1.1300739832222462e-02
    z[2,1,4]  R733      -2.0947778224945068e-01
    z[2,1,4]  R734      -1.9690012931823730e-01
    z[2,1,4]  R735      -2.1455359458923340e-01
    z[2,1,4]  R736      -2.3748318850994110e-01
    z[2,1,4]  R737      -6.2412753701210022e-02
    z[2,1,4]  R738      -1.3878914760425687e-03
    z[2,1,4]  R739      -2.9972249269485474e-01
    z[2,1,4]  R740      1.0240171849727631e-01
    z[2,1,4]  R741      -5.8105643838644028e-02
    z[2,1,4]  R742      -1.6127350926399231e-01
    z[2,1,4]  R743      -2.2873380780220032e-01
    z[2,1,4]  R744      4.9016959965229034e-02
    z[2,1,4]  R745      -1.7113342881202698e-01
    z[2,1,4]  R746      -1.5119731426239014e-01
    z[2,1,4]  R747      4.2914608120918274e-01
    z[2,1,4]  R748      -2.2236181795597076e-01
    z[2,1,4]  R749      -6.6458338499069214e-01
    z[2,1,4]  R750      -5.0531399250030518e-01
    z[2,1,4]  R751      -3.9694091677665710e-01
    z[2,1,4]  R752      -1.5275681018829346e-01
    z[2,1,4]  R753      1.0644120723009109e-01
    z[2,1,4]  R754      1.7732322216033936e-01
    z[2,1,4]  R755      7.3642139323055744e-03
    z[2,1,4]  R756      -1.9135577976703644e-01
    z[2,1,4]  R757      -1.1073070764541626e-01
    z[2,1,4]  R758      -2.5646522641181946e-01
    z[2,1,4]  R759      3.7055090069770813e-01
    z[2,1,4]  R760      -1.3561026751995087e-01
    z[2,1,4]  R761      1.8353927135467529e-01
    z[2,1,4]  R762      -3.0290371179580688e-01
    z[2,1,4]  R763      -1.1322285234928131e-01
    z[2,1,4]  R764      -4.3514337390661240e-02
    z[2,1,4]  R765      -0.0205116905272007
    z[2,1,4]  R766      -3.3465218544006348e-01
    z[2,1,4]  R767      4.6316260099411011e-01
    z[2,1,4]  R768      1.8530224263668060e-01
    z[2,1,4]  R769      -1.2988176941871643e-01
    z[2,1,4]  R770      -3.2258176803588867e-01
    z[2,1,4]  R771      2.8929686173796654e-02
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R648      -1
    z[2,1,5]  R649      1
    z[2,1,5]  R652      -2.3540283739566803e-01
    z[2,1,5]  R653      -0.00854957289993763
    z[2,1,5]  R654      4.3783590197563171e-01
    z[2,1,5]  R655      8.3130694925785065e-02
    z[2,1,5]  R656      -2.8458476066589355e-01
    z[2,1,5]  R657      -3.8159853219985962e-01
    z[2,1,5]  R658      -4.0739923715591431e-01
    z[2,1,5]  R659      3.3087518811225891e-01
    z[2,1,5]  R660      2.4915076792240143e-02
    z[2,1,5]  R661      -1.7816540598869324e-01
    z[2,1,5]  R662      1.1467922478914261e-01
    z[2,1,5]  R663      4.2003858089447021e-01
    z[2,1,5]  R664      1.6208250820636749e-01
    z[2,1,5]  R665      -7.4223570525646210e-02
    z[2,1,5]  R666      1.1688430607318878e-01
    z[2,1,5]  R667      4.1198921203613281e-01
    z[2,1,5]  R668      -1.3664972782135010e-01
    z[2,1,5]  R669      1.2237863242626190e-01
    z[2,1,5]  R670      8.1927262246608734e-02
    z[2,1,5]  R671      -3.8340527564287186e-02
    z[2,1,5]  R672      2.3994486033916473e-01
    z[2,1,5]  R673      2.3447552323341370e-01
    z[2,1,5]  R674      -2.8205180168151855e-01
    z[2,1,5]  R675      8.0327279865741730e-02
    z[2,1,5]  R676      -2.2595344483852386e-01
    z[2,1,5]  R677      1.5088914334774017e-01
    z[2,1,5]  R678      4.6108019351959229e-01
    z[2,1,5]  R679      3.8675445318222046e-01
    z[2,1,5]  R680      -4.6548891067504883e-01
    z[2,1,5]  R681      3.6300638318061829e-01
    z[2,1,5]  R682      -4.7204324603080750e-01
    z[2,1,5]  R683      2.2548133134841919e-01
    z[2,1,5]  R684      0.294140487909317
    z[2,1,5]  R685      0.269062876701355
    z[2,1,5]  R686      2.7389529347419739e-01
    z[2,1,5]  R687      1.9392102956771851e-01
    z[2,1,5]  R688      2.6628965139389038e-01
    z[2,1,5]  R689      1.4974293299019337e-02
    z[2,1,5]  R690      3.5737559199333191e-01
    z[2,1,5]  R691      3.9832450449466705e-02
    z[2,1,5]  R692      -2.7747803926467896e-01
    z[2,1,5]  R693      8.6794808506965637e-02
    z[2,1,5]  R694      2.6432502269744873e-01
    z[2,1,5]  R695      -1.2706659734249115e-01
    z[2,1,5]  R696      -2.2977589070796967e-01
    z[2,1,5]  R697      2.9454892873764038e-01
    z[2,1,5]  R698      2.3581004142761230e-01
    z[2,1,5]  R699      -1.3369787484407425e-02
    z[2,1,5]  R700      -3.8183709979057312e-01
    z[2,1,5]  R701      2.2445890307426453e-01
    z[2,1,5]  R702      4.2150229215621948e-01
    z[2,1,5]  R703      2.1082273125648499e-01
    z[2,1,5]  R704      5.2028131484985352e-01
    z[2,1,5]  R705      7.8177213668823242e-02
    z[2,1,5]  R706      3.8318881392478943e-01
    z[2,1,5]  R707      0.501187264919281
    z[2,1,5]  R708      -1.0809244960546494e-01
    z[2,1,5]  R709      -3.3803563565015793e-02
    z[2,1,5]  R710      0.270234078168869
    z[2,1,5]  R711      3.6921831965446472e-01
    z[2,1,5]  R712      -1.7713992297649384e-01
    z[2,1,5]  R713      1.2475472688674927e-01
    z[2,1,5]  R714      2.3245538771152496e-01
    z[2,1,5]  R715      3.6535343527793884e-01
    z[2,1,5]  R716      -9.7938925027847290e-03
    z[2,1,5]  R717      3.3562558889389038e-01
    z[2,1,5]  R718      -7.2778813540935516e-02
    z[2,1,5]  R719      5.8214765787124634e-01
    z[2,1,5]  R720      6.7344211041927338e-02
    z[2,1,5]  R721      -3.1684139370918274e-01
    z[2,1,5]  R722      2.0376870408654213e-02
    z[2,1,5]  R723      1.8445710837841034e-01
    z[2,1,5]  R724      5.0468164682388306e-01
    z[2,1,5]  R725      2.7623368427157402e-02
    z[2,1,5]  R726      -9.8482377827167511e-02
    z[2,1,5]  R727      -1.5143278241157532e-01
    z[2,1,5]  R728      5.1329664885997772e-02
    z[2,1,5]  R729      1.0537500679492950e-01
    z[2,1,5]  R730      -8.6735926568508148e-02
    z[2,1,5]  R731      -1.1086606979370117e-01
    z[2,1,5]  R732      -2.3266993463039398e-01
    z[2,1,5]  R733      -4.4520515203475952e-01
    z[2,1,5]  R734      2.3093423247337341e-01
    z[2,1,5]  R735      1.9628649950027466e-01
    z[2,1,5]  R736      4.6226605772972107e-03
    z[2,1,5]  R737      4.9770256876945496e-01
    z[2,1,5]  R738      -1.0162238776683807e-01
    z[2,1,5]  R739      2.3632700741291046e-01
    z[2,1,5]  R740      3.2093369960784912e-01
    z[2,1,5]  R741      -0.42711141705513
    z[2,1,5]  R742      -3.2793802022933960e-01
    z[2,1,5]  R743      1.5501849353313446e-01
    z[2,1,5]  R744      3.2618772983551025e-01
    z[2,1,5]  R745      4.2262414097785950e-01
    z[2,1,5]  R746      3.3062899112701416e-01
    z[2,1,5]  R747      4.0845975279808044e-01
    z[2,1,5]  R748      -7.3691415786743164e-01
    z[2,1,5]  R749      -4.9031883478164673e-01
    z[2,1,5]  R750      -0.678159236907959
    z[2,1,5]  R751      -7.0835208892822266e-01
    z[2,1,5]  R752      2.3761945962905884e-01
    z[2,1,5]  R753      2.4640648066997528e-01
    z[2,1,5]  R754      -5.8739602565765381e-02
    z[2,1,5]  R755      -2.0139248669147491e-01
    z[2,1,5]  R756      5.5107432603836060e-01
    z[2,1,5]  R757      0.358646959066391
    z[2,1,5]  R758      -6.2370300292968750e-01
    z[2,1,5]  R759      -2.7175009250640869e-02
    z[2,1,5]  R760      -4.7938090562820435e-01
    z[2,1,5]  R761      -6.8554812669754028e-01
    z[2,1,5]  R762      0.240728497505188
    z[2,1,5]  R763      5.8204138278961182e-01
    z[2,1,5]  R764      1.8889984115958214e-02
    z[2,1,5]  R765      6.4875751733779907e-02
    z[2,1,5]  R766      6.2053400278091431e-01
    z[2,1,5]  R767      1.5324059128761292e-01
    z[2,1,5]  R768      -3.1326818466186523e-01
    z[2,1,5]  R769      -4.7536367177963257e-01
    z[2,1,5]  R770      -2.0229713618755341e-01
    z[2,1,5]  R771      -8.7680689990520477e-02
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R650      -1
    z[2,1,6]  R651      1
    z[2,1,6]  R652      -7.5831925496459007e-03
    z[2,1,6]  R653      3.1768417358398438e-01
    z[2,1,6]  R654      2.2149063646793365e-01
    z[2,1,6]  R655      -6.1537390947341919e-01
    z[2,1,6]  R656      -5.8910536766052246e-01
    z[2,1,6]  R657      -2.8587639331817627e-01
    z[2,1,6]  R658      -4.2594605684280396e-01
    z[2,1,6]  R659      -1.7558148503303528e-01
    z[2,1,6]  R660      -6.2235742807388306e-01
    z[2,1,6]  R661      -1.8804767727851868e-01
    z[2,1,6]  R662      -7.9052805900573730e-02
    z[2,1,6]  R663      1.1902947723865509e-01
    z[2,1,6]  R664      -2.0897845923900604e-01
    z[2,1,6]  R665      -2.2031184285879135e-02
    z[2,1,6]  R666      -1.8457492114976048e-03
    z[2,1,6]  R667      -2.4557389318943024e-02
    z[2,1,6]  R668      0.099223293364048
    z[2,1,6]  R669      -0.486009806394577
    z[2,1,6]  R670      4.5687224715948105e-02
    z[2,1,6]  R671      4.2492789030075073e-01
    z[2,1,6]  R672      -6.0149419307708740e-01
    z[2,1,6]  R673      3.4033574163913727e-02
    z[2,1,6]  R674      3.5291877388954163e-01
    z[2,1,6]  R675      4.9176418781280518e-01
    z[2,1,6]  R676      0.0779540166258812
    z[2,1,6]  R677      -2.0374687016010284e-01
    z[2,1,6]  R678      1.2019833549857140e-02
    z[2,1,6]  R679      3.5785309970378876e-02
    z[2,1,6]  R680      -2.8921410441398621e-02
    z[2,1,6]  R681      1.3505174219608307e-01
    z[2,1,6]  R682      2.7569654583930969e-01
    z[2,1,6]  R683      -2.7953290939331055e-01
    z[2,1,6]  R684      -8.8077886030077934e-03
    z[2,1,6]  R685      -1.6440071165561676e-01
    z[2,1,6]  R686      2.0350660383701324e-01
    z[2,1,6]  R687      1.4017286896705627e-01
    z[2,1,6]  R688      -1.0919430851936340e-01
    z[2,1,6]  R689      -2.2402319312095642e-01
    z[2,1,6]  R690      -1.3143707811832428e-01
    z[2,1,6]  R691      0.0490855909883976
    z[2,1,6]  R692      1.7903280258178711e-01
    z[2,1,6]  R693      2.1552781760692596e-01
    z[2,1,6]  R694      -1.8531921505928040e-01
    z[2,1,6]  R695      -4.1614931076765060e-02
    z[2,1,6]  R696      -8.6111843585968018e-02
    z[2,1,6]  R697      1.7422136664390564e-01
    z[2,1,6]  R698      -2.1738973259925842e-01
    z[2,1,6]  R699      -2.2175389528274536e-01
    z[2,1,6]  R700      2.1136337518692017e-01
    z[2,1,6]  R701      -3.3586272597312927e-01
    z[2,1,6]  R702      2.3215837776660919e-01
    z[2,1,6]  R703      4.2681223154067993e-01
    z[2,1,6]  R704      4.9082913994789124e-01
    z[2,1,6]  R705      0.548614501953125
    z[2,1,6]  R706      5.6188172101974487e-01
    z[2,1,6]  R707      3.7740570306777954e-01
    z[2,1,6]  R708      2.4079778790473938e-01
    z[2,1,6]  R709      7.0146733522415161e-01
    z[2,1,6]  R710      5.0436311960220337e-01
    z[2,1,6]  R711      2.4577486515045166e-01
    z[2,1,6]  R712      -3.2198163866996765e-01
    z[2,1,6]  R713      1.0672981292009354e-01
    z[2,1,6]  R714      1.4407153427600861e-01
    z[2,1,6]  R715      3.9334241300821304e-02
    z[2,1,6]  R716      3.8813695311546326e-01
    z[2,1,6]  R717      2.6953229308128357e-01
    z[2,1,6]  R718      3.7290427088737488e-01
    z[2,1,6]  R719      2.6120588183403015e-01
    z[2,1,6]  R720      3.6627948284149170e-01
    z[2,1,6]  R721      -1.7489218711853027e-01
    z[2,1,6]  R722      -3.3026185631752014e-01
    z[2,1,6]  R723      2.1479737758636475e-01
    z[2,1,6]  R724      -2.4579374492168427e-01
    z[2,1,6]  R725      -3.0421912670135498e-02
    z[2,1,6]  R726      -1.5644830465316772e-01
    z[2,1,6]  R727      1.3995915651321411e-01
    z[2,1,6]  R728      -6.1815753579139709e-02
    z[2,1,6]  R729      -4.6537590026855469e-01
    z[2,1,6]  R730      -3.3084249496459961e-01
    z[2,1,6]  R731      -2.2959616780281067e-01
    z[2,1,6]  R732      1.6298945248126984e-01
    z[2,1,6]  R733      2.1789261698722839e-01
    z[2,1,6]  R734      6.7381441593170166e-02
    z[2,1,6]  R735      -1.1934030055999756e-01
    z[2,1,6]  R736      2.0152233541011810e-01
    z[2,1,6]  R737      1.1772727221250534e-01
    z[2,1,6]  R738      2.9406917095184326e-01
    z[2,1,6]  R739      -8.6259923875331879e-02
    z[2,1,6]  R740      -2.9275509715080261e-01
    z[2,1,6]  R741      -1.6995324194431305e-01
    z[2,1,6]  R742      -3.2412409782409668e-03
    z[2,1,6]  R743      3.4193581342697144e-01
    z[2,1,6]  R744      1.8364654481410980e-01
    z[2,1,6]  R745      -3.5997006297111511e-01
    z[2,1,6]  R746      -2.3075972497463226e-01
    z[2,1,6]  R747      2.1513873338699341e-01
    z[2,1,6]  R748      9.8632358014583588e-02
    z[2,1,6]  R749      6.1773583292961121e-02
    z[2,1,6]  R750      -2.1741646528244019e-01
    z[2,1,6]  R751      -0.35227170586586
    z[2,1,6]  R752      -2.1924762427806854e-01
    z[2,1,6]  R753      9.3395769596099854e-02
    z[2,1,6]  R754      -0.0913204550743103
    z[2,1,6]  R755      -4.8295024037361145e-01
    z[2,1,6]  R756      -5.7580333948135376e-01
    z[2,1,6]  R757      1.6845525801181793e-01
    z[2,1,6]  R758      1.4823305606842041e-01
    z[2,1,6]  R759      3.9097842574119568e-01
    z[2,1,6]  R760      3.6733604967594147e-02
    z[2,1,6]  R761      -7.2574533522129059e-02
    z[2,1,6]  R762      -2.1921820938587189e-01
    z[2,1,6]  R763      1.3556529302150011e-03
    z[2,1,6]  R764      -4.4133153557777405e-01
    z[2,1,6]  R765      -2.1631265059113503e-02
    z[2,1,6]  R766      -1.7923298478126526e-01
    z[2,1,6]  R767      -3.5379937291145325e-01
    z[2,1,6]  R768      1.1794251948595047e-01
    z[2,1,6]  R769      7.2125848382711411e-03
    z[2,1,6]  R770      2.1438100934028625e-01
    z[2,1,6]  R771      5.8446694165468216e-02
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R772      -1
    z[2,3,0]  R773      1
    z[2,3,0]  R786      8.6434870958328247e-01
    z[2,3,0]  R787      6.6791445016860962e-01
    z[2,3,0]  R788      4.6498170495033264e-01
    z[2,3,0]  R789      0.728111743927002
    z[2,3,0]  R790      4.3952608108520508e-01
    z[2,3,0]  R791      4.9878180027008057e-01
    z[2,3,0]  R792      3.3203712105751038e-01
    z[2,3,0]  R793      -3.1681719422340393e-01
    z[2,3,0]  R794      -2.2113482654094696e-01
    z[2,3,0]  R795      -4.0880167484283447e-01
    z[2,3,0]  R796      1.5702225267887115e-01
    z[2,3,0]  R797      8.3548091351985931e-02
    z[2,3,0]  R798      -1.2691356241703033e-01
    z[2,3,0]  R799      2.9052982106804848e-02
    z[2,3,0]  R800      -3.8130503892898560e-01
    z[2,3,0]  R801      -3.5953405499458313e-01
    z[2,3,0]  R802      1.6758590936660767e-01
    z[2,3,0]  R803      -2.6364507153630257e-02
    z[2,3,0]  R804      4.3519932031631470e-01
    z[2,3,0]  R805      -8.5451684892177582e-02
    z[2,3,0]  R806      1.0135149210691452e-01
    z[2,3,0]  R807      -1.2466557323932648e-01
    z[2,3,0]  R808      -5.1005119085311890e-01
    z[2,3,0]  R809      -2.8411766886711121e-01
    z[2,3,0]  R810      -6.6755360364913940e-01
    z[2,3,0]  R811      -8.4686893224716187e-01
    z[2,3,0]  R812      -6.4801824092864990e-01
    z[2,3,0]  R813      -7.4008554220199585e-01
    z[2,3,0]  R814      -6.8051880598068237e-01
    z[2,3,0]  R815      -8.6460644006729126e-01
    z[2,3,0]  R816      -2.0326793193817139e-01
    z[2,3,0]  R817      -0.0492432564496994
    z[2,3,0]  R818      -3.1620556116104126e-01
    z[2,3,0]  R819      -6.6749915480613708e-02
    z[2,3,0]  R820      -0.070064976811409
    z[2,3,0]  R821      4.1202157735824585e-01
    z[2,3,0]  R822      -8.6416286230087280e-01
    z[2,3,0]  R823      -6.2534677982330322e-01
    z[2,3,0]  R824      -4.6929138898849487e-01
    z[2,3,0]  R825      -4.9503171443939209e-01
    z[2,3,0]  R826      2.0798969268798828e-01
    z[2,3,0]  R827      -1.6027653217315674e-01
    z[2,3,0]  R828      4.4577309489250183e-01
    z[2,3,0]  R829      0.485567182302475
    z[2,3,0]  R830      -1.2288659065961838e-01
    z[2,3,0]  R831      3.4876942634582520e-01
    z[2,3,0]  R832      -0.182876855134964
    z[2,3,0]  R833      2.6595833897590637e-01
    z[2,3,0]  R834      8.1409555673599243e-01
    z[2,3,0]  R835      7.9661399126052856e-01
    z[2,3,0]  R836      -7.8262883424758911e-01
    z[2,3,0]  R837      -5.1310819387435913e-01
    z[2,3,0]  R838      -3.4668001532554626e-01
    z[2,3,0]  R839      2.5861239433288574e-01
    z[2,3,0]  R840      -4.4897374510765076e-01
    z[2,3,0]  R841      -2.0265442132949829e-01
    z[2,3,0]  R842      8.8884755969047546e-03
    z[2,3,0]  R843      -7.0157241821289062e-01
    z[2,3,0]  R844      -0.680765688419342
    z[2,3,0]  R845      -5.1564160734415054e-02
    z[2,3,0]  R846      -2.9696670174598694e-01
    z[2,3,0]  R847      -5.6222927570343018e-01
    z[2,3,0]  R848      -4.8878137022256851e-02
    z[2,3,0]  R849      3.4708552062511444e-02
    z[2,3,0]  R850      4.5578765869140625e-01
    z[2,3,0]  R851      2.4165239930152893e-01
    z[2,3,0]  R852      2.3586918413639069e-01
    z[2,3,0]  R853      8.8426578044891357e-01
    z[2,3,0]  R854      0.896182656288147
    z[2,3,0]  R855      -2.9889929294586182e-01
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R774      -1
    z[2,3,1]  R775      1
    z[2,3,1]  R786      -4.0723243355751038e-01
    z[2,3,1]  R787      -4.3571284413337708e-01
    z[2,3,1]  R788      -0.633994460105896
    z[2,3,1]  R789      -2.0166671276092529e-01
    z[2,3,1]  R790      -3.9191511273384094e-01
    z[2,3,1]  R791      -9.8720192909240723e-03
    z[2,3,1]  R792      1.8145754933357239e-02
    z[2,3,1]  R793      -6.2250858545303345e-01
    z[2,3,1]  R794      -5.6228274106979370e-01
    z[2,3,1]  R795      -7.7131259441375732e-01
    z[2,3,1]  R796      7.5322926044464111e-01
    z[2,3,1]  R797      6.4812260866165161e-01
    z[2,3,1]  R798      5.3232693672180176e-01
    z[2,3,1]  R799      6.2306547164916992e-01
    z[2,3,1]  R800      6.3632696866989136e-01
    z[2,3,1]  R801      5.3356373310089111e-01
    z[2,3,1]  R802      7.9223489761352539e-01
    z[2,3,1]  R803      6.9819223880767822e-01
    z[2,3,1]  R804      6.7886650562286377e-01
    z[2,3,1]  R805      8.7288916110992432e-01
    z[2,3,1]  R806      -4.1749957203865051e-01
    z[2,3,1]  R807      0.735876202583313
    z[2,3,1]  R808      0.458394318819046
    z[2,3,1]  R809      2.1090948581695557e-01
    z[2,3,1]  R810      3.6799290776252747e-01
    z[2,3,1]  R811      1.1673334985971451e-01
    z[2,3,1]  R812      -9.0482152998447418e-02
    z[2,3,1]  R813      -1.7473979294300079e-01
    z[2,3,1]  R814      3.9658805727958679e-01
    z[2,3,1]  R815      -1.0264360159635544e-01
    z[2,3,1]  R816      -4.9712833762168884e-01
    z[2,3,1]  R817      8.2093644142150879e-01
    z[2,3,1]  R818      8.6742001771926880e-01
    z[2,3,1]  R819      0.866395115852356
    z[2,3,1]  R820      0.307373583316803
    z[2,3,1]  R821      5.8181345462799072e-01
    z[2,3,1]  R822      -1.6553734242916107e-01
    z[2,3,1]  R823      -1.4171253144741058e-01
    z[2,3,1]  R824      -2.8058373928070068e-01
    z[2,3,1]  R825      1.7950499057769775e-01
    z[2,3,1]  R826      4.7397175431251526e-01
    z[2,3,1]  R827      -5.1044309139251709e-01
    z[2,3,1]  R828      1.0607351548969746e-02
    z[2,3,1]  R829      -6.5003573894500732e-02
    z[2,3,1]  R830      -4.2076998949050903e-01
    z[2,3,1]  R831      3.2847024500370026e-02
    z[2,3,1]  R832      -2.3373763263225555e-01
    z[2,3,1]  R833      3.5103362053632736e-02
    z[2,3,1]  R834      1.5364921092987061e-01
    z[2,3,1]  R835      1.7687892913818359e-01
    z[2,3,1]  R836      -1.2815099954605103e-01
    z[2,3,1]  R837      -2.0230868831276894e-02
    z[2,3,1]  R838      1.3132871687412262e-01
    z[2,3,1]  R839      3.9347603917121887e-02
    z[2,3,1]  R840      4.6784910559654236e-01
    z[2,3,1]  R841      4.3934464454650879e-01
    z[2,3,1]  R842      -9.8866842687129974e-02
    z[2,3,1]  R843      5.0842958688735962e-01
    z[2,3,1]  R844      3.8184297084808350e-01
    z[2,3,1]  R845      1.7891910672187805e-01
    z[2,3,1]  R846      0.16356261074543
    z[2,3,1]  R847      2.4688905104994774e-02
    z[2,3,1]  R848      6.0318535566329956e-01
    z[2,3,1]  R849      -0.68907630443573
    z[2,3,1]  R850      -1.5761137008666992e-01
    z[2,3,1]  R851      8.9654959738254547e-02
    z[2,3,1]  R852      -3.7349554896354675e-01
    z[2,3,1]  R853      1.5629976987838745e-01
    z[2,3,1]  R854      1.6974413767457008e-02
    z[2,3,1]  R855      1.3153521716594696e-01
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R776      -1
    z[2,3,2]  R777      1
    z[2,3,2]  R786      6.7390188574790955e-02
    z[2,3,2]  R787      3.0142614245414734e-01
    z[2,3,2]  R788      1.5732099115848541e-01
    z[2,3,2]  R789      2.0724116265773773e-01
    z[2,3,2]  R790      1.4994834363460541e-01
    z[2,3,2]  R791      4.1898164153099060e-01
    z[2,3,2]  R792      4.5498472452163696e-01
    z[2,3,2]  R793      4.7741052508354187e-01
    z[2,3,2]  R794      3.5086354613304138e-01
    z[2,3,2]  R795      2.8349253535270691e-01
    z[2,3,2]  R796      -4.3035313487052917e-01
    z[2,3,2]  R797      -3.2790485024452209e-01
    z[2,3,2]  R798      -6.1819630861282349e-01
    z[2,3,2]  R799      -6.7858254909515381e-01
    z[2,3,2]  R800      -5.1824736595153809e-01
    z[2,3,2]  R801      -3.8327559828758240e-01
    z[2,3,2]  R802      -4.7408428788185120e-01
    z[2,3,2]  R803      -3.9438962936401367e-01
    z[2,3,2]  R804      -4.2634752392768860e-01
    z[2,3,2]  R805      -2.0455385744571686e-01
    z[2,3,2]  R806      3.1482407450675964e-01
    z[2,3,2]  R807      0.0796460285782814
    z[2,3,2]  R808      4.6889832615852356e-01
    z[2,3,2]  R809      6.7965364456176758e-01
    z[2,3,2]  R810      3.7591493129730225e-01
    z[2,3,2]  R811      -3.5959637165069580e-01
    z[2,3,2]  R812      -5.1113218069076538e-01
    z[2,3,2]  R813      -4.6645429730415344e-01
    z[2,3,2]  R814      1.7479488253593445e-01
    z[2,3,2]  R815      -2.1831433475017548e-01
    z[2,3,2]  R816      3.5196727514266968e-01
    z[2,3,2]  R817      -2.9363530874252319e-01
    z[2,3,2]  R818      -1.0206980258226395e-01
    z[2,3,2]  R819      8.3683505654335022e-02
    z[2,3,2]  R820      7.9446166753768921e-01
    z[2,3,2]  R821      2.9570186138153076e-01
    z[2,3,2]  R822      -3.6811664700508118e-01
    z[2,3,2]  R823      -0.686767041683197
    z[2,3,2]  R824      -7.2401577234268188e-01
    z[2,3,2]  R825      -7.6279765367507935e-01
    z[2,3,2]  R826      -1.4849710464477539e-01
    z[2,3,2]  R827      2.1112892031669617e-01
    z[2,3,2]  R828      4.5270791649818420e-01
    z[2,3,2]  R829      3.3361065387725830e-01
    z[2,3,2]  R830      2.9637560248374939e-01
    z[2,3,2]  R831      2.8770384192466736e-01
    z[2,3,2]  R832      2.3488526046276093e-01
    z[2,3,2]  R833      2.7894172072410583e-01
    z[2,3,2]  R834      -3.7805265188217163e-01
    z[2,3,2]  R835      -2.1345199644565582e-01
    z[2,3,2]  R836      -3.5631260275840759e-01
    z[2,3,2]  R837      -3.1214338541030884e-01
    z[2,3,2]  R838      2.6848953217267990e-02
    z[2,3,2]  R839      -4.7626032028347254e-04
    z[2,3,2]  R840      -5.4760348796844482e-01
    z[2,3,2]  R841      -5.2161341905593872e-01
    z[2,3,2]  R842      -2.7225714921951294e-01
    z[2,3,2]  R843      1.4438579976558685e-01
    z[2,3,2]  R844      2.2329366207122803e-01
    z[2,3,2]  R845      -6.6694356501102448e-02
    z[2,3,2]  R846      5.4491654038429260e-02
    z[2,3,2]  R847      -1.0325080901384354e-01
    z[2,3,2]  R848      -0.209682434797287
    z[2,3,2]  R849      0.529075562953949
    z[2,3,2]  R850      6.2065100669860840e-01
    z[2,3,2]  R851      4.8167562484741211e-01
    z[2,3,2]  R852      2.9683086276054382e-01
    z[2,3,2]  R853      -1.8844637274742126e-01
    z[2,3,2]  R854      -3.7243932485580444e-01
    z[2,3,2]  R855      -3.0112260952591896e-02
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R778      -1
    z[2,3,3]  R779      1
    z[2,3,3]  R786      -1.5914860367774963e-01
    z[2,3,3]  R787      -5.3766336292028427e-02
    z[2,3,3]  R788      1.4396573603153229e-01
    z[2,3,3]  R789      -2.5104392319917679e-02
    z[2,3,3]  R790      -1.3331703841686249e-01
    z[2,3,3]  R791      -3.7810721993446350e-01
    z[2,3,3]  R792      -5.7165306806564331e-01
    z[2,3,3]  R793      -1.8017520010471344e-01
    z[2,3,3]  R794      -2.6484557986259460e-01
    z[2,3,3]  R795      -2.8375267982482910e-01
    z[2,3,3]  R796      2.5552812218666077e-01
    z[2,3,3]  R797      0.397329717874527
    z[2,3,3]  R798      4.9832960963249207e-01
    z[2,3,3]  R799      3.3659121394157410e-01
    z[2,3,3]  R800      0.315348356962204
    z[2,3,3]  R801      5.1529526710510254e-01
    z[2,3,3]  R802      2.5374817848205566e-01
    z[2,3,3]  R803      3.0752077698707581e-01
    z[2,3,3]  R804      3.7837514281272888e-01
    z[2,3,3]  R805      8.2159496843814850e-02
    z[2,3,3]  R806      -1.5864214301109314e-01
    z[2,3,3]  R807      2.3752050101757050e-01
    z[2,3,3]  R808      -2.7910497784614563e-01
    z[2,3,3]  R809      -3.8216370344161987e-01
    z[2,3,3]  R810      -3.6438465118408203e-01
    z[2,3,3]  R811      -1.6845697164535522e-01
    z[2,3,3]  R812      -2.9784658551216125e-01
    z[2,3,3]  R813      -1.4176808297634125e-01
    z[2,3,3]  R814      2.3424679413437843e-02
    z[2,3,3]  R815      -2.0129530131816864e-01
    z[2,3,3]  R816      -5.1793640851974487e-01
    z[2,3,3]  R817      3.2918041944503784e-01
    z[2,3,3]  R818      2.1268796920776367e-01
    z[2,3,3]  R819      1.9512437283992767e-01
    z[2,3,3]  R820      -3.7618613243103027e-01
    z[2,3,3]  R821      -2.0109087228775024e-01
    z[2,3,3]  R822      0.073503777384758
    z[2,3,3]  R823      -2.3019200563430786e-01
    z[2,3,3]  R824      1.4721383154392242e-01
    z[2,3,3]  R825      -2.4338087439537048e-01
    z[2,3,3]  R826      -8.0069136619567871e-01
    z[2,3,3]  R827      -7.5212538242340088e-01
    z[2,3,3]  R828      -5.6111198663711548e-01
    z[2,3,3]  R829      -0.707947850227356
    z[2,3,3]  R830      -4.8851883411407471e-01
    z[2,3,3]  R831      -6.5705120563507080e-01
    z[2,3,3]  R832      -2.1463672816753387e-01
    z[2,3,3]  R833      -1.8314115703105927e-01
    z[2,3,3]  R834      -6.2325548380613327e-02
    z[2,3,3]  R835      -1.2716961093246937e-02
    z[2,3,3]  R836      -3.0760338902473450e-01
    z[2,3,3]  R837      -9.7764588892459869e-02
    z[2,3,3]  R838      -1.7797645926475525e-01
    z[2,3,3]  R839      2.6678565144538879e-01
    z[2,3,3]  R840      1.4053313434123993e-01
    z[2,3,3]  R841      1.2276563793420792e-02
    z[2,3,3]  R842      2.4192081391811371e-01
    z[2,3,3]  R843      1.9215981662273407e-01
    z[2,3,3]  R844      -8.8324718177318573e-02
    z[2,3,3]  R845      1.2633481621742249e-01
    z[2,3,3]  R846      -3.2013097405433655e-01
    z[2,3,3]  R847      -4.3988779187202454e-01
    z[2,3,3]  R848      -1.3065457344055176e-01
    z[2,3,3]  R849      -2.9899996519088745e-01
    z[2,3,3]  R850      3.5970035195350647e-01
    z[2,3,3]  R851      -2.6605978608131409e-01
    z[2,3,3]  R852      5.1785528659820557e-01
    z[2,3,3]  R853      1.1327573657035828e-01
    z[2,3,3]  R854      1.1653125286102295e-01
    z[2,3,3]  R855      2.4402470886707306e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R780      -1
    z[2,3,4]  R781      1
    z[2,3,4]  R786      -4.1487328708171844e-02
    z[2,3,4]  R787      4.1146057844161987e-01
    z[2,3,4]  R788      -3.0920660495758057e-01
    z[2,3,4]  R789      -2.9925815761089325e-03
    z[2,3,4]  R790      4.3003222346305847e-01
    z[2,3,4]  R791      4.5306283235549927e-01
    z[2,3,4]  R792      -9.0662069618701935e-02
    z[2,3,4]  R793      -3.3379447460174561e-01
    z[2,3,4]  R794      -2.3181785643100739e-01
    z[2,3,4]  R795      9.9848099052906036e-02
    z[2,3,4]  R796      -3.7160521745681763e-01
    z[2,3,4]  R797      -3.4199967980384827e-01
    z[2,3,4]  R798      -8.8972700759768486e-03
    z[2,3,4]  R799      -1.7658649384975433e-01
    z[2,3,4]  R800      -2.6077610254287720e-01
    z[2,3,4]  R801      5.7250197976827621e-02
    z[2,3,4]  R802      1.6314479708671570e-01
    z[2,3,4]  R803      -1.0265620797872543e-01
    z[2,3,4]  R804      1.2650048732757568e-01
    z[2,3,4]  R805      1.1672622524201870e-02
    z[2,3,4]  R806      -5.2131730318069458e-01
    z[2,3,4]  R807      5.6925231218338013e-01
    z[2,3,4]  R808      1.6688981652259827e-01
    z[2,3,4]  R809      1.3613104820251465e-01
    z[2,3,4]  R810      2.9619839787483215e-01
    z[2,3,4]  R811      2.1729892492294312e-01
    z[2,3,4]  R812      -9.5797322690486908e-02
    z[2,3,4]  R813      1.8221385776996613e-01
    z[2,3,4]  R814      3.6193040013313293e-01
    z[2,3,4]  R815      6.1044171452522278e-02
    z[2,3,4]  R816      1.4343340694904327e-01
    z[2,3,4]  R817      -8.7525574490427971e-03
    z[2,3,4]  R818      -7.3115348815917969e-02
    z[2,3,4]  R819      3.1686764955520630e-01
    z[2,3,4]  R820      -1.0720803588628769e-01
    z[2,3,4]  R821      -5.5371510982513428e-01
    z[2,3,4]  R822      -4.5539274811744690e-02
    z[2,3,4]  R823      -0.117519810795784
    z[2,3,4]  R824      -1.0086910426616669e-01
    z[2,3,4]  R825      2.7862343192100525e-01
    z[2,3,4]  R826      -1.0060030221939087e-01
    z[2,3,4]  R827      -3.8738641887903214e-02
    z[2,3,4]  R828      2.9095721244812012e-01
    z[2,3,4]  R829      -1.1915315687656403e-01
    z[2,3,4]  R830      1.4073304831981659e-01
    z[2,3,4]  R831      -2.3209522664546967e-01
    z[2,3,4]  R832      8.7771266698837280e-01
    z[2,3,4]  R833      6.1948943138122559e-01
    z[2,3,4]  R834      1.9244116544723511e-01
    z[2,3,4]  R835      -9.9708780646324158e-02
    z[2,3,4]  R836      0.152165487408638
    z[2,3,4]  R837      5.0819325447082520e-01
    z[2,3,4]  R838      1.2793740630149841e-01
    z[2,3,4]  R839      4.4585832953453064e-01
    z[2,3,4]  R840      5.0892066955566406e-01
    z[2,3,4]  R841      4.8616915941238403e-01
    z[2,3,4]  R842      -8.8259071111679077e-01
    z[2,3,4]  R843      0.0740782767534256
    z[2,3,4]  R844      -0.391072154045105
    z[2,3,4]  R845      -6.2394684553146362e-01
    z[2,3,4]  R846      4.9257880449295044e-01
    z[2,3,4]  R847      2.1926164627075195e-01
    z[2,3,4]  R848      7.3666656017303467e-01
    z[2,3,4]  R849      2.8521430492401123e-01
    z[2,3,4]  R850      3.3822399377822876e-01
    z[2,3,4]  R851      4.1451269388198853e-01
    z[2,3,4]  R852      2.5579139590263367e-01
    z[2,3,4]  R853      -2.7272635698318481e-01
    z[2,3,4]  R854      -8.2204639911651611e-02
    z[2,3,4]  R855      -8.7263822555541992e-01
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R782      -1
    z[2,3,5]  R783      1
    z[2,3,5]  R786      -2.3540283739566803e-01
    z[2,3,5]  R787      -0.00854957289993763
    z[2,3,5]  R788      4.3783590197563171e-01
    z[2,3,5]  R789      8.3130694925785065e-02
    z[2,3,5]  R790      -2.8458476066589355e-01
    z[2,3,5]  R791      -3.8159853219985962e-01
    z[2,3,5]  R792      -4.0739923715591431e-01
    z[2,3,5]  R793      3.3087518811225891e-01
    z[2,3,5]  R794      2.4915076792240143e-02
    z[2,3,5]  R795      -1.7816540598869324e-01
    z[2,3,5]  R796      1.1467922478914261e-01
    z[2,3,5]  R797      4.2003858089447021e-01
    z[2,3,5]  R798      1.6208250820636749e-01
    z[2,3,5]  R799      -7.4223570525646210e-02
    z[2,3,5]  R800      1.1688430607318878e-01
    z[2,3,5]  R801      4.1198921203613281e-01
    z[2,3,5]  R802      -1.3664972782135010e-01
    z[2,3,5]  R803      1.2237863242626190e-01
    z[2,3,5]  R804      8.1927262246608734e-02
    z[2,3,5]  R805      -3.8340527564287186e-02
    z[2,3,5]  R806      2.3994486033916473e-01
    z[2,3,5]  R807      2.3447552323341370e-01
    z[2,3,5]  R808      -2.8205180168151855e-01
    z[2,3,5]  R809      8.0327279865741730e-02
    z[2,3,5]  R810      -2.2595344483852386e-01
    z[2,3,5]  R811      1.5088914334774017e-01
    z[2,3,5]  R812      4.6108019351959229e-01
    z[2,3,5]  R813      3.8675445318222046e-01
    z[2,3,5]  R814      -4.6548891067504883e-01
    z[2,3,5]  R815      3.6300638318061829e-01
    z[2,3,5]  R816      -4.7204324603080750e-01
    z[2,3,5]  R817      2.2548133134841919e-01
    z[2,3,5]  R818      0.294140487909317
    z[2,3,5]  R819      0.269062876701355
    z[2,3,5]  R820      2.7389529347419739e-01
    z[2,3,5]  R821      1.9392102956771851e-01
    z[2,3,5]  R822      2.6628965139389038e-01
    z[2,3,5]  R823      1.4974293299019337e-02
    z[2,3,5]  R824      3.5737559199333191e-01
    z[2,3,5]  R825      3.9832450449466705e-02
    z[2,3,5]  R826      -5.3799189627170563e-03
    z[2,3,5]  R827      -1.7999008297920227e-01
    z[2,3,5]  R828      -6.0456082224845886e-02
    z[2,3,5]  R829      -2.2702747583389282e-01
    z[2,3,5]  R830      1.0899110138416290e-01
    z[2,3,5]  R831      1.0334442555904388e-01
    z[2,3,5]  R832      -1.4412897825241089e-01
    z[2,3,5]  R833      -1.4920921623706818e-01
    z[2,3,5]  R834      3.5670313239097595e-01
    z[2,3,5]  R835      5.2504038810729980e-01
    z[2,3,5]  R836      1.7391893267631531e-01
    z[2,3,5]  R837      -3.0043289065361023e-01
    z[2,3,5]  R838      8.5372120141983032e-01
    z[2,3,5]  R839      -7.6600193977355957e-01
    z[2,3,5]  R840      -5.0599616952240467e-03
    z[2,3,5]  R841      -4.6348902583122253e-01
    z[2,3,5]  R842      -1.9151559472084045e-01
    z[2,3,5]  R843      -4.5082513242959976e-02
    z[2,3,5]  R844      -4.1748741269111633e-01
    z[2,3,5]  R845      -7.3961865901947021e-01
    z[2,3,5]  R846      5.6521528959274292e-01
    z[2,3,5]  R847      6.5650010108947754e-01
    z[2,3,5]  R848      1.3824495673179626e-01
    z[2,3,5]  R849      -2.7003097534179688e-01
    z[2,3,5]  R850      1.9309404492378235e-01
    z[2,3,5]  R851      6.2927955389022827e-01
    z[2,3,5]  R852      -0.541400671005249
    z[2,3,5]  R853      1.4162269234657288e-01
    z[2,3,5]  R854      -1.8363635241985321e-01
    z[2,3,5]  R855      -2.4780270457267761e-01
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R784      -1
    z[2,3,6]  R785      1
    z[2,3,6]  R786      -7.5831925496459007e-03
    z[2,3,6]  R787      3.1768417358398438e-01
    z[2,3,6]  R788      2.2149063646793365e-01
    z[2,3,6]  R789      -6.1537390947341919e-01
    z[2,3,6]  R790      -5.8910536766052246e-01
    z[2,3,6]  R791      -2.8587639331817627e-01
    z[2,3,6]  R792      -4.2594605684280396e-01
    z[2,3,6]  R793      -1.7558148503303528e-01
    z[2,3,6]  R794      -6.2235742807388306e-01
    z[2,3,6]  R795      -1.8804767727851868e-01
    z[2,3,6]  R796      -7.9052805900573730e-02
    z[2,3,6]  R797      1.1902947723865509e-01
    z[2,3,6]  R798      -2.0897845923900604e-01
    z[2,3,6]  R799      -2.2031184285879135e-02
    z[2,3,6]  R800      -1.8457492114976048e-03
    z[2,3,6]  R801      -2.4557389318943024e-02
    z[2,3,6]  R802      0.099223293364048
    z[2,3,6]  R803      -0.486009806394577
    z[2,3,6]  R804      4.5687224715948105e-02
    z[2,3,6]  R805      4.2492789030075073e-01
    z[2,3,6]  R806      -6.0149419307708740e-01
    z[2,3,6]  R807      3.4033574163913727e-02
    z[2,3,6]  R808      3.5291877388954163e-01
    z[2,3,6]  R809      4.9176418781280518e-01
    z[2,3,6]  R810      0.0779540166258812
    z[2,3,6]  R811      -2.0374687016010284e-01
    z[2,3,6]  R812      1.2019833549857140e-02
    z[2,3,6]  R813      3.5785309970378876e-02
    z[2,3,6]  R814      -2.8921410441398621e-02
    z[2,3,6]  R815      1.3505174219608307e-01
    z[2,3,6]  R816      2.7569654583930969e-01
    z[2,3,6]  R817      -2.7953290939331055e-01
    z[2,3,6]  R818      -8.8077886030077934e-03
    z[2,3,6]  R819      -1.6440071165561676e-01
    z[2,3,6]  R820      2.0350660383701324e-01
    z[2,3,6]  R821      1.4017286896705627e-01
    z[2,3,6]  R822      -1.0919430851936340e-01
    z[2,3,6]  R823      -2.2402319312095642e-01
    z[2,3,6]  R824      -1.3143707811832428e-01
    z[2,3,6]  R825      0.0490855909883976
    z[2,3,6]  R826      2.4245367944240570e-01
    z[2,3,6]  R827      -0.263807088136673
    z[2,3,6]  R828      4.3939930200576782e-01
    z[2,3,6]  R829      -2.8596135973930359e-01
    z[2,3,6]  R830      -6.7058008909225464e-01
    z[2,3,6]  R831      5.4611617326736450e-01
    z[2,3,6]  R832      -1.3975061476230621e-01
    z[2,3,6]  R833      -6.4082300662994385e-01
    z[2,3,6]  R834      -5.0610471516847610e-02
    z[2,3,6]  R835      5.2794121205806732e-02
    z[2,3,6]  R836      3.0998182296752930e-01
    z[2,3,6]  R837      5.2990466356277466e-01
    z[2,3,6]  R838      2.9148116707801819e-01
    z[2,3,6]  R839      2.7358356118202209e-01
    z[2,3,6]  R840      2.9916131868958473e-02
    z[2,3,6]  R841      -2.0614005625247955e-01
    z[2,3,6]  R842      -2.0457790791988373e-01
    z[2,3,6]  R843      -4.2895531654357910e-01
    z[2,3,6]  R844      -7.6548449695110321e-02
    z[2,3,6]  R845      -9.2601068317890167e-02
    z[2,3,6]  R846      4.6637180447578430e-01
    z[2,3,6]  R847      7.6529458165168762e-03
    z[2,3,6]  R848      -1.0465058684349060e-01
    z[2,3,6]  R849      1.9581615924835205e-02
    z[2,3,6]  R850      3.1803071498870850e-01
    z[2,3,6]  R851      -2.5090509653091431e-01
    z[2,3,6]  R852      3.0006700754165649e-01
    z[2,3,6]  R853      -2.2553144395351410e-01
    z[2,3,6]  R854      -6.1627957969903946e-02
    z[2,3,6]  R855      0.0999956876039505
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R856      -1
    z[3,2,0]  R857      1
    z[3,2,0]  R870      2.0798969268798828e-01
    z[3,2,0]  R871      -1.6027653217315674e-01
    z[3,2,0]  R872      4.4577309489250183e-01
    z[3,2,0]  R873      0.485567182302475
    z[3,2,0]  R874      -1.2288659065961838e-01
    z[3,2,0]  R875      3.4876942634582520e-01
    z[3,2,0]  R876      -0.182876855134964
    z[3,2,0]  R877      2.6595833897590637e-01
    z[3,2,0]  R878      8.1409555673599243e-01
    z[3,2,0]  R879      7.9661399126052856e-01
    z[3,2,0]  R880      -7.8262883424758911e-01
    z[3,2,0]  R881      -5.1310819387435913e-01
    z[3,2,0]  R882      -3.4668001532554626e-01
    z[3,2,0]  R883      2.5861239433288574e-01
    z[3,2,0]  R884      -4.4897374510765076e-01
    z[3,2,0]  R885      -2.0265442132949829e-01
    z[3,2,0]  R886      8.8884755969047546e-03
    z[3,2,0]  R887      -7.0157241821289062e-01
    z[3,2,0]  R888      -0.680765688419342
    z[3,2,0]  R889      -5.1564160734415054e-02
    z[3,2,0]  R890      -2.9696670174598694e-01
    z[3,2,0]  R891      -5.6222927570343018e-01
    z[3,2,0]  R892      -4.8878137022256851e-02
    z[3,2,0]  R893      3.4708552062511444e-02
    z[3,2,0]  R894      4.5578765869140625e-01
    z[3,2,0]  R895      2.4165239930152893e-01
    z[3,2,0]  R896      2.3586918413639069e-01
    z[3,2,0]  R897      8.8426578044891357e-01
    z[3,2,0]  R898      0.896182656288147
    z[3,2,0]  R899      -2.9889929294586182e-01
    z[3,2,0]  R900      8.6434870958328247e-01
    z[3,2,0]  R901      6.6791445016860962e-01
    z[3,2,0]  R902      4.6498170495033264e-01
    z[3,2,0]  R903      0.728111743927002
    z[3,2,0]  R904      4.3952608108520508e-01
    z[3,2,0]  R905      4.9878180027008057e-01
    z[3,2,0]  R906      3.3203712105751038e-01
    z[3,2,0]  R907      -3.1681719422340393e-01
    z[3,2,0]  R908      -2.2113482654094696e-01
    z[3,2,0]  R909      -4.0880167484283447e-01
    z[3,2,0]  R910      1.5702225267887115e-01
    z[3,2,0]  R911      8.3548091351985931e-02
    z[3,2,0]  R912      -1.2691356241703033e-01
    z[3,2,0]  R913      2.9052982106804848e-02
    z[3,2,0]  R914      -3.8130503892898560e-01
    z[3,2,0]  R915      -3.5953405499458313e-01
    z[3,2,0]  R916      1.6758590936660767e-01
    z[3,2,0]  R917      -2.6364507153630257e-02
    z[3,2,0]  R918      4.3519932031631470e-01
    z[3,2,0]  R919      -8.5451684892177582e-02
    z[3,2,0]  R920      1.0135149210691452e-01
    z[3,2,0]  R921      -1.2466557323932648e-01
    z[3,2,0]  R922      -5.1005119085311890e-01
    z[3,2,0]  R923      -2.8411766886711121e-01
    z[3,2,0]  R924      -6.6755360364913940e-01
    z[3,2,0]  R925      -8.4686893224716187e-01
    z[3,2,0]  R926      -6.4801824092864990e-01
    z[3,2,0]  R927      -7.4008554220199585e-01
    z[3,2,0]  R928      -6.8051880598068237e-01
    z[3,2,0]  R929      -8.6460644006729126e-01
    z[3,2,0]  R930      -2.0326793193817139e-01
    z[3,2,0]  R931      -0.0492432564496994
    z[3,2,0]  R932      -3.1620556116104126e-01
    z[3,2,0]  R933      -6.6749915480613708e-02
    z[3,2,0]  R934      -0.070064976811409
    z[3,2,0]  R935      4.1202157735824585e-01
    z[3,2,0]  R936      -8.6416286230087280e-01
    z[3,2,0]  R937      -6.2534677982330322e-01
    z[3,2,0]  R938      -4.6929138898849487e-01
    z[3,2,0]  R939      -4.9503171443939209e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R858      -1
    z[3,2,1]  R859      1
    z[3,2,1]  R870      4.7397175431251526e-01
    z[3,2,1]  R871      -5.1044309139251709e-01
    z[3,2,1]  R872      1.0607351548969746e-02
    z[3,2,1]  R873      -6.5003573894500732e-02
    z[3,2,1]  R874      -4.2076998949050903e-01
    z[3,2,1]  R875      3.2847024500370026e-02
    z[3,2,1]  R876      -2.3373763263225555e-01
    z[3,2,1]  R877      3.5103362053632736e-02
    z[3,2,1]  R878      1.5364921092987061e-01
    z[3,2,1]  R879      1.7687892913818359e-01
    z[3,2,1]  R880      -1.2815099954605103e-01
    z[3,2,1]  R881      -2.0230868831276894e-02
    z[3,2,1]  R882      1.3132871687412262e-01
    z[3,2,1]  R883      3.9347603917121887e-02
    z[3,2,1]  R884      4.6784910559654236e-01
    z[3,2,1]  R885      4.3934464454650879e-01
    z[3,2,1]  R886      -9.8866842687129974e-02
    z[3,2,1]  R887      5.0842958688735962e-01
    z[3,2,1]  R888      3.8184297084808350e-01
    z[3,2,1]  R889      1.7891910672187805e-01
    z[3,2,1]  R890      0.16356261074543
    z[3,2,1]  R891      2.4688905104994774e-02
    z[3,2,1]  R892      6.0318535566329956e-01
    z[3,2,1]  R893      -0.68907630443573
    z[3,2,1]  R894      -1.5761137008666992e-01
    z[3,2,1]  R895      8.9654959738254547e-02
    z[3,2,1]  R896      -3.7349554896354675e-01
    z[3,2,1]  R897      1.5629976987838745e-01
    z[3,2,1]  R898      1.6974413767457008e-02
    z[3,2,1]  R899      1.3153521716594696e-01
    z[3,2,1]  R900      -4.0723243355751038e-01
    z[3,2,1]  R901      -4.3571284413337708e-01
    z[3,2,1]  R902      -0.633994460105896
    z[3,2,1]  R903      -2.0166671276092529e-01
    z[3,2,1]  R904      -3.9191511273384094e-01
    z[3,2,1]  R905      -9.8720192909240723e-03
    z[3,2,1]  R906      1.8145754933357239e-02
    z[3,2,1]  R907      -6.2250858545303345e-01
    z[3,2,1]  R908      -5.6228274106979370e-01
    z[3,2,1]  R909      -7.7131259441375732e-01
    z[3,2,1]  R910      7.5322926044464111e-01
    z[3,2,1]  R911      6.4812260866165161e-01
    z[3,2,1]  R912      5.3232693672180176e-01
    z[3,2,1]  R913      6.2306547164916992e-01
    z[3,2,1]  R914      6.3632696866989136e-01
    z[3,2,1]  R915      5.3356373310089111e-01
    z[3,2,1]  R916      7.9223489761352539e-01
    z[3,2,1]  R917      6.9819223880767822e-01
    z[3,2,1]  R918      6.7886650562286377e-01
    z[3,2,1]  R919      8.7288916110992432e-01
    z[3,2,1]  R920      -4.1749957203865051e-01
    z[3,2,1]  R921      0.735876202583313
    z[3,2,1]  R922      0.458394318819046
    z[3,2,1]  R923      2.1090948581695557e-01
    z[3,2,1]  R924      3.6799290776252747e-01
    z[3,2,1]  R925      1.1673334985971451e-01
    z[3,2,1]  R926      -9.0482152998447418e-02
    z[3,2,1]  R927      -1.7473979294300079e-01
    z[3,2,1]  R928      3.9658805727958679e-01
    z[3,2,1]  R929      -1.0264360159635544e-01
    z[3,2,1]  R930      -4.9712833762168884e-01
    z[3,2,1]  R931      8.2093644142150879e-01
    z[3,2,1]  R932      8.6742001771926880e-01
    z[3,2,1]  R933      0.866395115852356
    z[3,2,1]  R934      0.307373583316803
    z[3,2,1]  R935      5.8181345462799072e-01
    z[3,2,1]  R936      -1.6553734242916107e-01
    z[3,2,1]  R937      -1.4171253144741058e-01
    z[3,2,1]  R938      -2.8058373928070068e-01
    z[3,2,1]  R939      1.7950499057769775e-01
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R860      -1
    z[3,2,2]  R861      1
    z[3,2,2]  R870      -1.4849710464477539e-01
    z[3,2,2]  R871      2.1112892031669617e-01
    z[3,2,2]  R872      4.5270791649818420e-01
    z[3,2,2]  R873      3.3361065387725830e-01
    z[3,2,2]  R874      2.9637560248374939e-01
    z[3,2,2]  R875      2.8770384192466736e-01
    z[3,2,2]  R876      2.3488526046276093e-01
    z[3,2,2]  R877      2.7894172072410583e-01
    z[3,2,2]  R878      -3.7805265188217163e-01
    z[3,2,2]  R879      -2.1345199644565582e-01
    z[3,2,2]  R880      -3.5631260275840759e-01
    z[3,2,2]  R881      -3.1214338541030884e-01
    z[3,2,2]  R882      2.6848953217267990e-02
    z[3,2,2]  R883      -4.7626032028347254e-04
    z[3,2,2]  R884      -5.4760348796844482e-01
    z[3,2,2]  R885      -5.2161341905593872e-01
    z[3,2,2]  R886      -2.7225714921951294e-01
    z[3,2,2]  R887      1.4438579976558685e-01
    z[3,2,2]  R888      2.2329366207122803e-01
    z[3,2,2]  R889      -6.6694356501102448e-02
    z[3,2,2]  R890      5.4491654038429260e-02
    z[3,2,2]  R891      -1.0325080901384354e-01
    z[3,2,2]  R892      -0.209682434797287
    z[3,2,2]  R893      0.529075562953949
    z[3,2,2]  R894      6.2065100669860840e-01
    z[3,2,2]  R895      4.8167562484741211e-01
    z[3,2,2]  R896      2.9683086276054382e-01
    z[3,2,2]  R897      -1.8844637274742126e-01
    z[3,2,2]  R898      -3.7243932485580444e-01
    z[3,2,2]  R899      -3.0112260952591896e-02
    z[3,2,2]  R900      6.7390188574790955e-02
    z[3,2,2]  R901      3.0142614245414734e-01
    z[3,2,2]  R902      1.5732099115848541e-01
    z[3,2,2]  R903      2.0724116265773773e-01
    z[3,2,2]  R904      1.4994834363460541e-01
    z[3,2,2]  R905      4.1898164153099060e-01
    z[3,2,2]  R906      4.5498472452163696e-01
    z[3,2,2]  R907      4.7741052508354187e-01
    z[3,2,2]  R908      3.5086354613304138e-01
    z[3,2,2]  R909      2.8349253535270691e-01
    z[3,2,2]  R910      -4.3035313487052917e-01
    z[3,2,2]  R911      -3.2790485024452209e-01
    z[3,2,2]  R912      -6.1819630861282349e-01
    z[3,2,2]  R913      -6.7858254909515381e-01
    z[3,2,2]  R914      -5.1824736595153809e-01
    z[3,2,2]  R915      -3.8327559828758240e-01
    z[3,2,2]  R916      -4.7408428788185120e-01
    z[3,2,2]  R917      -3.9438962936401367e-01
    z[3,2,2]  R918      -4.2634752392768860e-01
    z[3,2,2]  R919      -2.0455385744571686e-01
    z[3,2,2]  R920      3.1482407450675964e-01
    z[3,2,2]  R921      0.0796460285782814
    z[3,2,2]  R922      4.6889832615852356e-01
    z[3,2,2]  R923      6.7965364456176758e-01
    z[3,2,2]  R924      3.7591493129730225e-01
    z[3,2,2]  R925      -3.5959637165069580e-01
    z[3,2,2]  R926      -5.1113218069076538e-01
    z[3,2,2]  R927      -4.6645429730415344e-01
    z[3,2,2]  R928      1.7479488253593445e-01
    z[3,2,2]  R929      -2.1831433475017548e-01
    z[3,2,2]  R930      3.5196727514266968e-01
    z[3,2,2]  R931      -2.9363530874252319e-01
    z[3,2,2]  R932      -1.0206980258226395e-01
    z[3,2,2]  R933      8.3683505654335022e-02
    z[3,2,2]  R934      7.9446166753768921e-01
    z[3,2,2]  R935      2.9570186138153076e-01
    z[3,2,2]  R936      -3.6811664700508118e-01
    z[3,2,2]  R937      -0.686767041683197
    z[3,2,2]  R938      -7.2401577234268188e-01
    z[3,2,2]  R939      -7.6279765367507935e-01
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R862      -1
    z[3,2,3]  R863      1
    z[3,2,3]  R870      -8.0069136619567871e-01
    z[3,2,3]  R871      -7.5212538242340088e-01
    z[3,2,3]  R872      -5.6111198663711548e-01
    z[3,2,3]  R873      -0.707947850227356
    z[3,2,3]  R874      -4.8851883411407471e-01
    z[3,2,3]  R875      -6.5705120563507080e-01
    z[3,2,3]  R876      -2.1463672816753387e-01
    z[3,2,3]  R877      -1.8314115703105927e-01
    z[3,2,3]  R878      -6.2325548380613327e-02
    z[3,2,3]  R879      -1.2716961093246937e-02
    z[3,2,3]  R880      -3.0760338902473450e-01
    z[3,2,3]  R881      -9.7764588892459869e-02
    z[3,2,3]  R882      -1.7797645926475525e-01
    z[3,2,3]  R883      2.6678565144538879e-01
    z[3,2,3]  R884      1.4053313434123993e-01
    z[3,2,3]  R885      1.2276563793420792e-02
    z[3,2,3]  R886      2.4192081391811371e-01
    z[3,2,3]  R887      1.9215981662273407e-01
    z[3,2,3]  R888      -8.8324718177318573e-02
    z[3,2,3]  R889      1.2633481621742249e-01
    z[3,2,3]  R890      -3.2013097405433655e-01
    z[3,2,3]  R891      -4.3988779187202454e-01
    z[3,2,3]  R892      -1.3065457344055176e-01
    z[3,2,3]  R893      -2.9899996519088745e-01
    z[3,2,3]  R894      3.5970035195350647e-01
    z[3,2,3]  R895      -2.6605978608131409e-01
    z[3,2,3]  R896      5.1785528659820557e-01
    z[3,2,3]  R897      1.1327573657035828e-01
    z[3,2,3]  R898      1.1653125286102295e-01
    z[3,2,3]  R899      2.4402470886707306e-01
    z[3,2,3]  R900      -1.5914860367774963e-01
    z[3,2,3]  R901      -5.3766336292028427e-02
    z[3,2,3]  R902      1.4396573603153229e-01
    z[3,2,3]  R903      -2.5104392319917679e-02
    z[3,2,3]  R904      -1.3331703841686249e-01
    z[3,2,3]  R905      -3.7810721993446350e-01
    z[3,2,3]  R906      -5.7165306806564331e-01
    z[3,2,3]  R907      -1.8017520010471344e-01
    z[3,2,3]  R908      -2.6484557986259460e-01
    z[3,2,3]  R909      -2.8375267982482910e-01
    z[3,2,3]  R910      2.5552812218666077e-01
    z[3,2,3]  R911      0.397329717874527
    z[3,2,3]  R912      4.9832960963249207e-01
    z[3,2,3]  R913      3.3659121394157410e-01
    z[3,2,3]  R914      0.315348356962204
    z[3,2,3]  R915      5.1529526710510254e-01
    z[3,2,3]  R916      2.5374817848205566e-01
    z[3,2,3]  R917      3.0752077698707581e-01
    z[3,2,3]  R918      3.7837514281272888e-01
    z[3,2,3]  R919      8.2159496843814850e-02
    z[3,2,3]  R920      -1.5864214301109314e-01
    z[3,2,3]  R921      2.3752050101757050e-01
    z[3,2,3]  R922      -2.7910497784614563e-01
    z[3,2,3]  R923      -3.8216370344161987e-01
    z[3,2,3]  R924      -3.6438465118408203e-01
    z[3,2,3]  R925      -1.6845697164535522e-01
    z[3,2,3]  R926      -2.9784658551216125e-01
    z[3,2,3]  R927      -1.4176808297634125e-01
    z[3,2,3]  R928      2.3424679413437843e-02
    z[3,2,3]  R929      -2.0129530131816864e-01
    z[3,2,3]  R930      -5.1793640851974487e-01
    z[3,2,3]  R931      3.2918041944503784e-01
    z[3,2,3]  R932      2.1268796920776367e-01
    z[3,2,3]  R933      1.9512437283992767e-01
    z[3,2,3]  R934      -3.7618613243103027e-01
    z[3,2,3]  R935      -2.0109087228775024e-01
    z[3,2,3]  R936      0.073503777384758
    z[3,2,3]  R937      -2.3019200563430786e-01
    z[3,2,3]  R938      1.4721383154392242e-01
    z[3,2,3]  R939      -2.4338087439537048e-01
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R864      -1
    z[3,2,4]  R865      1
    z[3,2,4]  R870      -1.0060030221939087e-01
    z[3,2,4]  R871      -3.8738641887903214e-02
    z[3,2,4]  R872      2.9095721244812012e-01
    z[3,2,4]  R873      -1.1915315687656403e-01
    z[3,2,4]  R874      1.4073304831981659e-01
    z[3,2,4]  R875      -2.3209522664546967e-01
    z[3,2,4]  R876      8.7771266698837280e-01
    z[3,2,4]  R877      6.1948943138122559e-01
    z[3,2,4]  R878      1.9244116544723511e-01
    z[3,2,4]  R879      -9.9708780646324158e-02
    z[3,2,4]  R880      0.152165487408638
    z[3,2,4]  R881      5.0819325447082520e-01
    z[3,2,4]  R882      1.2793740630149841e-01
    z[3,2,4]  R883      4.4585832953453064e-01
    z[3,2,4]  R884      5.0892066955566406e-01
    z[3,2,4]  R885      4.8616915941238403e-01
    z[3,2,4]  R886      -8.8259071111679077e-01
    z[3,2,4]  R887      0.0740782767534256
    z[3,2,4]  R888      -0.391072154045105
    z[3,2,4]  R889      -6.2394684553146362e-01
    z[3,2,4]  R890      4.9257880449295044e-01
    z[3,2,4]  R891      2.1926164627075195e-01
    z[3,2,4]  R892      7.3666656017303467e-01
    z[3,2,4]  R893      2.8521430492401123e-01
    z[3,2,4]  R894      3.3822399377822876e-01
    z[3,2,4]  R895      4.1451269388198853e-01
    z[3,2,4]  R896      2.5579139590263367e-01
    z[3,2,4]  R897      -2.7272635698318481e-01
    z[3,2,4]  R898      -8.2204639911651611e-02
    z[3,2,4]  R899      -8.7263822555541992e-01
    z[3,2,4]  R900      -4.1487328708171844e-02
    z[3,2,4]  R901      4.1146057844161987e-01
    z[3,2,4]  R902      -3.0920660495758057e-01
    z[3,2,4]  R903      -2.9925815761089325e-03
    z[3,2,4]  R904      4.3003222346305847e-01
    z[3,2,4]  R905      4.5306283235549927e-01
    z[3,2,4]  R906      -9.0662069618701935e-02
    z[3,2,4]  R907      -3.3379447460174561e-01
    z[3,2,4]  R908      -2.3181785643100739e-01
    z[3,2,4]  R909      9.9848099052906036e-02
    z[3,2,4]  R910      -3.7160521745681763e-01
    z[3,2,4]  R911      -3.4199967980384827e-01
    z[3,2,4]  R912      -8.8972700759768486e-03
    z[3,2,4]  R913      -1.7658649384975433e-01
    z[3,2,4]  R914      -2.6077610254287720e-01
    z[3,2,4]  R915      5.7250197976827621e-02
    z[3,2,4]  R916      1.6314479708671570e-01
    z[3,2,4]  R917      -1.0265620797872543e-01
    z[3,2,4]  R918      1.2650048732757568e-01
    z[3,2,4]  R919      1.1672622524201870e-02
    z[3,2,4]  R920      -5.2131730318069458e-01
    z[3,2,4]  R921      5.6925231218338013e-01
    z[3,2,4]  R922      1.6688981652259827e-01
    z[3,2,4]  R923      1.3613104820251465e-01
    z[3,2,4]  R924      2.9619839787483215e-01
    z[3,2,4]  R925      2.1729892492294312e-01
    z[3,2,4]  R926      -9.5797322690486908e-02
    z[3,2,4]  R927      1.8221385776996613e-01
    z[3,2,4]  R928      3.6193040013313293e-01
    z[3,2,4]  R929      6.1044171452522278e-02
    z[3,2,4]  R930      1.4343340694904327e-01
    z[3,2,4]  R931      -8.7525574490427971e-03
    z[3,2,4]  R932      -7.3115348815917969e-02
    z[3,2,4]  R933      3.1686764955520630e-01
    z[3,2,4]  R934      -1.0720803588628769e-01
    z[3,2,4]  R935      -5.5371510982513428e-01
    z[3,2,4]  R936      -4.5539274811744690e-02
    z[3,2,4]  R937      -0.117519810795784
    z[3,2,4]  R938      -1.0086910426616669e-01
    z[3,2,4]  R939      2.7862343192100525e-01
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R866      -1
    z[3,2,5]  R867      1
    z[3,2,5]  R870      -5.3799189627170563e-03
    z[3,2,5]  R871      -1.7999008297920227e-01
    z[3,2,5]  R872      -6.0456082224845886e-02
    z[3,2,5]  R873      -2.2702747583389282e-01
    z[3,2,5]  R874      1.0899110138416290e-01
    z[3,2,5]  R875      1.0334442555904388e-01
    z[3,2,5]  R876      -1.4412897825241089e-01
    z[3,2,5]  R877      -1.4920921623706818e-01
    z[3,2,5]  R878      3.5670313239097595e-01
    z[3,2,5]  R879      5.2504038810729980e-01
    z[3,2,5]  R880      1.7391893267631531e-01
    z[3,2,5]  R881      -3.0043289065361023e-01
    z[3,2,5]  R882      8.5372120141983032e-01
    z[3,2,5]  R883      -7.6600193977355957e-01
    z[3,2,5]  R884      -5.0599616952240467e-03
    z[3,2,5]  R885      -4.6348902583122253e-01
    z[3,2,5]  R886      -1.9151559472084045e-01
    z[3,2,5]  R887      -4.5082513242959976e-02
    z[3,2,5]  R888      -4.1748741269111633e-01
    z[3,2,5]  R889      -7.3961865901947021e-01
    z[3,2,5]  R890      5.6521528959274292e-01
    z[3,2,5]  R891      6.5650010108947754e-01
    z[3,2,5]  R892      1.3824495673179626e-01
    z[3,2,5]  R893      -2.7003097534179688e-01
    z[3,2,5]  R894      1.9309404492378235e-01
    z[3,2,5]  R895      6.2927955389022827e-01
    z[3,2,5]  R896      -0.541400671005249
    z[3,2,5]  R897      1.4162269234657288e-01
    z[3,2,5]  R898      -1.8363635241985321e-01
    z[3,2,5]  R899      -2.4780270457267761e-01
    z[3,2,5]  R900      -2.3540283739566803e-01
    z[3,2,5]  R901      -0.00854957289993763
    z[3,2,5]  R902      4.3783590197563171e-01
    z[3,2,5]  R903      8.3130694925785065e-02
    z[3,2,5]  R904      -2.8458476066589355e-01
    z[3,2,5]  R905      -3.8159853219985962e-01
    z[3,2,5]  R906      -4.0739923715591431e-01
    z[3,2,5]  R907      3.3087518811225891e-01
    z[3,2,5]  R908      2.4915076792240143e-02
    z[3,2,5]  R909      -1.7816540598869324e-01
    z[3,2,5]  R910      1.1467922478914261e-01
    z[3,2,5]  R911      4.2003858089447021e-01
    z[3,2,5]  R912      1.6208250820636749e-01
    z[3,2,5]  R913      -7.4223570525646210e-02
    z[3,2,5]  R914      1.1688430607318878e-01
    z[3,2,5]  R915      4.1198921203613281e-01
    z[3,2,5]  R916      -1.3664972782135010e-01
    z[3,2,5]  R917      1.2237863242626190e-01
    z[3,2,5]  R918      8.1927262246608734e-02
    z[3,2,5]  R919      -3.8340527564287186e-02
    z[3,2,5]  R920      2.3994486033916473e-01
    z[3,2,5]  R921      2.3447552323341370e-01
    z[3,2,5]  R922      -2.8205180168151855e-01
    z[3,2,5]  R923      8.0327279865741730e-02
    z[3,2,5]  R924      -2.2595344483852386e-01
    z[3,2,5]  R925      1.5088914334774017e-01
    z[3,2,5]  R926      4.6108019351959229e-01
    z[3,2,5]  R927      3.8675445318222046e-01
    z[3,2,5]  R928      -4.6548891067504883e-01
    z[3,2,5]  R929      3.6300638318061829e-01
    z[3,2,5]  R930      -4.7204324603080750e-01
    z[3,2,5]  R931      2.2548133134841919e-01
    z[3,2,5]  R932      0.294140487909317
    z[3,2,5]  R933      0.269062876701355
    z[3,2,5]  R934      2.7389529347419739e-01
    z[3,2,5]  R935      1.9392102956771851e-01
    z[3,2,5]  R936      2.6628965139389038e-01
    z[3,2,5]  R937      1.4974293299019337e-02
    z[3,2,5]  R938      3.5737559199333191e-01
    z[3,2,5]  R939      3.9832450449466705e-02
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R868      -1
    z[3,2,6]  R869      1
    z[3,2,6]  R870      2.4245367944240570e-01
    z[3,2,6]  R871      -0.263807088136673
    z[3,2,6]  R872      4.3939930200576782e-01
    z[3,2,6]  R873      -2.8596135973930359e-01
    z[3,2,6]  R874      -6.7058008909225464e-01
    z[3,2,6]  R875      5.4611617326736450e-01
    z[3,2,6]  R876      -1.3975061476230621e-01
    z[3,2,6]  R877      -6.4082300662994385e-01
    z[3,2,6]  R878      -5.0610471516847610e-02
    z[3,2,6]  R879      5.2794121205806732e-02
    z[3,2,6]  R880      3.0998182296752930e-01
    z[3,2,6]  R881      5.2990466356277466e-01
    z[3,2,6]  R882      2.9148116707801819e-01
    z[3,2,6]  R883      2.7358356118202209e-01
    z[3,2,6]  R884      2.9916131868958473e-02
    z[3,2,6]  R885      -2.0614005625247955e-01
    z[3,2,6]  R886      -2.0457790791988373e-01
    z[3,2,6]  R887      -4.2895531654357910e-01
    z[3,2,6]  R888      -7.6548449695110321e-02
    z[3,2,6]  R889      -9.2601068317890167e-02
    z[3,2,6]  R890      4.6637180447578430e-01
    z[3,2,6]  R891      7.6529458165168762e-03
    z[3,2,6]  R892      -1.0465058684349060e-01
    z[3,2,6]  R893      1.9581615924835205e-02
    z[3,2,6]  R894      3.1803071498870850e-01
    z[3,2,6]  R895      -2.5090509653091431e-01
    z[3,2,6]  R896      3.0006700754165649e-01
    z[3,2,6]  R897      -2.2553144395351410e-01
    z[3,2,6]  R898      -6.1627957969903946e-02
    z[3,2,6]  R899      0.0999956876039505
    z[3,2,6]  R900      -7.5831925496459007e-03
    z[3,2,6]  R901      3.1768417358398438e-01
    z[3,2,6]  R902      2.2149063646793365e-01
    z[3,2,6]  R903      -6.1537390947341919e-01
    z[3,2,6]  R904      -5.8910536766052246e-01
    z[3,2,6]  R905      -2.8587639331817627e-01
    z[3,2,6]  R906      -4.2594605684280396e-01
    z[3,2,6]  R907      -1.7558148503303528e-01
    z[3,2,6]  R908      -6.2235742807388306e-01
    z[3,2,6]  R909      -1.8804767727851868e-01
    z[3,2,6]  R910      -7.9052805900573730e-02
    z[3,2,6]  R911      1.1902947723865509e-01
    z[3,2,6]  R912      -2.0897845923900604e-01
    z[3,2,6]  R913      -2.2031184285879135e-02
    z[3,2,6]  R914      -1.8457492114976048e-03
    z[3,2,6]  R915      -2.4557389318943024e-02
    z[3,2,6]  R916      0.099223293364048
    z[3,2,6]  R917      -0.486009806394577
    z[3,2,6]  R918      4.5687224715948105e-02
    z[3,2,6]  R919      4.2492789030075073e-01
    z[3,2,6]  R920      -6.0149419307708740e-01
    z[3,2,6]  R921      3.4033574163913727e-02
    z[3,2,6]  R922      3.5291877388954163e-01
    z[3,2,6]  R923      4.9176418781280518e-01
    z[3,2,6]  R924      0.0779540166258812
    z[3,2,6]  R925      -2.0374687016010284e-01
    z[3,2,6]  R926      1.2019833549857140e-02
    z[3,2,6]  R927      3.5785309970378876e-02
    z[3,2,6]  R928      -2.8921410441398621e-02
    z[3,2,6]  R929      1.3505174219608307e-01
    z[3,2,6]  R930      2.7569654583930969e-01
    z[3,2,6]  R931      -2.7953290939331055e-01
    z[3,2,6]  R932      -8.8077886030077934e-03
    z[3,2,6]  R933      -1.6440071165561676e-01
    z[3,2,6]  R934      2.0350660383701324e-01
    z[3,2,6]  R935      1.4017286896705627e-01
    z[3,2,6]  R936      -1.0919430851936340e-01
    z[3,2,6]  R937      -2.2402319312095642e-01
    z[3,2,6]  R938      -1.3143707811832428e-01
    z[3,2,6]  R939      0.0490855909883976
    z[2,7,0]  R20       -1
    z[2,7,0]  R65       1
    z[2,7,0]  R940      -1
    z[2,7,0]  R941      1
    z[2,7,0]  R954      8.6434870958328247e-01
    z[2,7,0]  R955      6.6791445016860962e-01
    z[2,7,0]  R956      4.6498170495033264e-01
    z[2,7,0]  R957      0.728111743927002
    z[2,7,0]  R958      4.3952608108520508e-01
    z[2,7,0]  R959      4.9878180027008057e-01
    z[2,7,0]  R960      3.3203712105751038e-01
    z[2,7,0]  R961      -3.1681719422340393e-01
    z[2,7,0]  R962      -2.2113482654094696e-01
    z[2,7,0]  R963      -4.0880167484283447e-01
    z[2,7,0]  R964      1.5702225267887115e-01
    z[2,7,0]  R965      8.3548091351985931e-02
    z[2,7,0]  R966      -1.2691356241703033e-01
    z[2,7,0]  R967      2.9052982106804848e-02
    z[2,7,0]  R968      -3.8130503892898560e-01
    z[2,7,0]  R969      -3.5953405499458313e-01
    z[2,7,0]  R970      1.6758590936660767e-01
    z[2,7,0]  R971      -2.6364507153630257e-02
    z[2,7,0]  R972      4.3519932031631470e-01
    z[2,7,0]  R973      -8.5451684892177582e-02
    z[2,7,0]  R974      1.0135149210691452e-01
    z[2,7,0]  R975      -1.2466557323932648e-01
    z[2,7,0]  R976      -5.1005119085311890e-01
    z[2,7,0]  R977      -2.8411766886711121e-01
    z[2,7,0]  R978      -6.6755360364913940e-01
    z[2,7,0]  R979      -8.4686893224716187e-01
    z[2,7,0]  R980      -6.4801824092864990e-01
    z[2,7,0]  R981      -7.4008554220199585e-01
    z[2,7,0]  R982      -6.8051880598068237e-01
    z[2,7,0]  R983      -8.6460644006729126e-01
    z[2,7,0]  R984      -2.0326793193817139e-01
    z[2,7,0]  R985      -0.0492432564496994
    z[2,7,0]  R986      -3.1620556116104126e-01
    z[2,7,0]  R987      -6.6749915480613708e-02
    z[2,7,0]  R988      -0.070064976811409
    z[2,7,0]  R989      4.1202157735824585e-01
    z[2,7,0]  R990      -8.6416286230087280e-01
    z[2,7,0]  R991      -6.2534677982330322e-01
    z[2,7,0]  R992      -4.6929138898849487e-01
    z[2,7,0]  R993      -4.9503171443939209e-01
    z[2,7,0]  R994      4.7603544592857361e-01
    z[2,7,0]  R995      3.6790758371353149e-01
    z[2,7,0]  R996      4.1421744227409363e-01
    z[2,7,0]  R997      -3.9302725344896317e-02
    z[2,7,0]  R998      3.1200116872787476e-01
    z[2,7,0]  R999      3.5082545876502991e-01
    z[2,7,0]  R1000     -8.3406277000904083e-02
    z[2,7,0]  R1001     5.2954941987991333e-01
    z[2,7,0]  R1002     3.5198795795440674e-01
    z[2,7,0]  R1003     0.588661253452301
    z[2,7,0]  R1004     -2.9111906886100769e-01
    z[2,7,0]  R1005     5.9338800609111786e-02
    z[2,7,0]  R1006     -1.7377567291259766e-01
    z[2,7,0]  R1007     2.0256677269935608e-01
    z[2,7,0]  R1008     -1.1065188795328140e-01
    z[2,7,0]  R1009     -8.7795235216617584e-02
    z[2,7,0]  R1010     -3.0642268061637878e-01
    z[2,7,0]  R1011     2.7552178502082825e-01
    z[2,7,0]  R1012     3.7211981415748596e-01
    z[2,7,0]  R1013     6.6856807470321655e-01
    z[2,7,0]  R1014     1.3725635409355164e-01
    z[2,7,0]  R1015     3.8982889056205750e-01
    z[2,7,0]  R1016     -0.123763807117939
    z[2,7,0]  R1017     3.7052273750305176e-01
    z[2,7,0]  R1018     4.1609662771224976e-01
    z[2,7,0]  R1019     2.5699424743652344e-01
    z[2,7,0]  R1020     4.1304844617843628e-01
    z[2,7,0]  R1021     4.1018193960189819e-01
    z[2,7,0]  R1022     -3.0694928765296936e-01
    z[2,7,0]  R1023     2.4791166186332703e-01
    z[2,7,0]  R1024     -0.0092205461114645
    z[2,7,0]  R1025     -2.7029192447662354e-01
    z[2,7,0]  R1026     1.2486063875257969e-02
    z[2,7,0]  R1027     -7.6464004814624786e-02
    z[2,7,0]  R1028     -3.1966125965118408e-01
    z[2,7,0]  R1029     -2.7544555068016052e-01
    z[2,7,0]  R1030     -4.4085282087326050e-01
    z[2,7,0]  R1031     -6.3712352514266968e-01
    z[2,7,0]  R1032     -2.3229372501373291e-01
    z[2,7,0]  R1033     5.8029163628816605e-03
    z[2,7,0]  R1034     -5.2021265029907227e-01
    z[2,7,0]  R1035     3.8525256514549255e-01
    z[2,7,0]  R1036     -3.6801743507385254e-01
    z[2,7,0]  R1037     2.2431758046150208e-01
    z[2,7,0]  R1038     1.1507070809602737e-01
    z[2,7,0]  R1039     -2.2654646635055542e-01
    z[2,7,0]  R1040     8.1596441566944122e-02
    z[2,7,0]  R1041     1.6711363196372986e-01
    z[2,7,0]  R1042     -8.7778925895690918e-01
    z[2,7,0]  R1043     -8.5311925411224365e-01
    z[2,7,1]  R21       -1
    z[2,7,1]  R66       1
    z[2,7,1]  R942      -1
    z[2,7,1]  R943      1
    z[2,7,1]  R954      -4.0723243355751038e-01
    z[2,7,1]  R955      -4.3571284413337708e-01
    z[2,7,1]  R956      -0.633994460105896
    z[2,7,1]  R957      -2.0166671276092529e-01
    z[2,7,1]  R958      -3.9191511273384094e-01
    z[2,7,1]  R959      -9.8720192909240723e-03
    z[2,7,1]  R960      1.8145754933357239e-02
    z[2,7,1]  R961      -6.2250858545303345e-01
    z[2,7,1]  R962      -5.6228274106979370e-01
    z[2,7,1]  R963      -7.7131259441375732e-01
    z[2,7,1]  R964      7.5322926044464111e-01
    z[2,7,1]  R965      6.4812260866165161e-01
    z[2,7,1]  R966      5.3232693672180176e-01
    z[2,7,1]  R967      6.2306547164916992e-01
    z[2,7,1]  R968      6.3632696866989136e-01
    z[2,7,1]  R969      5.3356373310089111e-01
    z[2,7,1]  R970      7.9223489761352539e-01
    z[2,7,1]  R971      6.9819223880767822e-01
    z[2,7,1]  R972      6.7886650562286377e-01
    z[2,7,1]  R973      8.7288916110992432e-01
    z[2,7,1]  R974      -4.1749957203865051e-01
    z[2,7,1]  R975      0.735876202583313
    z[2,7,1]  R976      0.458394318819046
    z[2,7,1]  R977      2.1090948581695557e-01
    z[2,7,1]  R978      3.6799290776252747e-01
    z[2,7,1]  R979      1.1673334985971451e-01
    z[2,7,1]  R980      -9.0482152998447418e-02
    z[2,7,1]  R981      -1.7473979294300079e-01
    z[2,7,1]  R982      3.9658805727958679e-01
    z[2,7,1]  R983      -1.0264360159635544e-01
    z[2,7,1]  R984      -4.9712833762168884e-01
    z[2,7,1]  R985      8.2093644142150879e-01
    z[2,7,1]  R986      8.6742001771926880e-01
    z[2,7,1]  R987      0.866395115852356
    z[2,7,1]  R988      0.307373583316803
    z[2,7,1]  R989      5.8181345462799072e-01
    z[2,7,1]  R990      -1.6553734242916107e-01
    z[2,7,1]  R991      -1.4171253144741058e-01
    z[2,7,1]  R992      -2.8058373928070068e-01
    z[2,7,1]  R993      1.7950499057769775e-01
    z[2,7,1]  R994      -1.0660460591316223e-01
    z[2,7,1]  R995      -1.2077955156564713e-01
    z[2,7,1]  R996      -2.0885924994945526e-01
    z[2,7,1]  R997      -5.9599387645721436e-01
    z[2,7,1]  R998      -2.4721232056617737e-01
    z[2,7,1]  R999      -2.8906211256980896e-01
    z[2,7,1]  R1000     -4.9694183468818665e-01
    z[2,7,1]  R1001     -4.0280455350875854e-01
    z[2,7,1]  R1002     -2.8144043684005737e-01
    z[2,7,1]  R1003     -5.1659953594207764e-01
    z[2,7,1]  R1004     -1.8781755119562149e-02
    z[2,7,1]  R1005     2.2174131870269775e-01
    z[2,7,1]  R1006     1.6783127188682556e-01
    z[2,7,1]  R1007     -3.4644204378128052e-01
    z[2,7,1]  R1008     1.6638845205307007e-01
    z[2,7,1]  R1009     3.4050557017326355e-01
    z[2,7,1]  R1010     8.4921658039093018e-01
    z[2,7,1]  R1011     -5.4452598094940186e-02
    z[2,7,1]  R1012     5.2231132984161377e-02
    z[2,7,1]  R1013     0.0165800079703331
    z[2,7,1]  R1014     8.6523312330245972e-01
    z[2,7,1]  R1015     0.849455714225769
    z[2,7,1]  R1016     8.3081424236297607e-01
    z[2,7,1]  R1017     7.5549054145812988e-01
    z[2,7,1]  R1018     6.9476801156997681e-01
    z[2,7,1]  R1019     7.0348227024078369e-01
    z[2,7,1]  R1020     6.7879295349121094e-01
    z[2,7,1]  R1021     6.7431765794754028e-01
    z[2,7,1]  R1022     0.812117338180542
    z[2,7,1]  R1023     6.5174585580825806e-01
    z[2,7,1]  R1024     0.875145673751831
    z[2,7,1]  R1025     7.7661645412445068e-01
    z[2,7,1]  R1026     3.3691346645355225e-01
    z[2,7,1]  R1027     -1.3373208045959473e-01
    z[2,7,1]  R1028     2.1163500845432281e-01
    z[2,7,1]  R1029     1.4521718025207520e-01
    z[2,7,1]  R1030     2.0001755654811859e-01
    z[2,7,1]  R1031     -1.7763268947601318e-01
    z[2,7,1]  R1032     -4.1447395086288452e-01
    z[2,7,1]  R1033     3.2233405113220215e-01
    z[2,7,1]  R1034     -1.6980348154902458e-02
    z[2,7,1]  R1035     6.8088221549987793e-01
    z[2,7,1]  R1036     1.2809453904628754e-01
    z[2,7,1]  R1037     -3.7579932808876038e-01
    z[2,7,1]  R1038     -7.0018756389617920e-01
    z[2,7,1]  R1039     3.0431863665580750e-01
    z[2,7,1]  R1040     -4.0260177105665207e-02
    z[2,7,1]  R1041     -2.2124862670898438e-01
    z[2,7,1]  R1042     1.3861157000064850e-01
    z[2,7,1]  R1043     2.3196747526526451e-02
    z[2,7,2]  R22       -1
    z[2,7,2]  R67       1
    z[2,7,2]  R944      -1
    z[2,7,2]  R945      1
    z[2,7,2]  R954      6.7390188574790955e-02
    z[2,7,2]  R955      3.0142614245414734e-01
    z[2,7,2]  R956      1.5732099115848541e-01
    z[2,7,2]  R957      2.0724116265773773e-01
    z[2,7,2]  R958      1.4994834363460541e-01
    z[2,7,2]  R959      4.1898164153099060e-01
    z[2,7,2]  R960      4.5498472452163696e-01
    z[2,7,2]  R961      4.7741052508354187e-01
    z[2,7,2]  R962      3.5086354613304138e-01
    z[2,7,2]  R963      2.8349253535270691e-01
    z[2,7,2]  R964      -4.3035313487052917e-01
    z[2,7,2]  R965      -3.2790485024452209e-01
    z[2,7,2]  R966      -6.1819630861282349e-01
    z[2,7,2]  R967      -6.7858254909515381e-01
    z[2,7,2]  R968      -5.1824736595153809e-01
    z[2,7,2]  R969      -3.8327559828758240e-01
    z[2,7,2]  R970      -4.7408428788185120e-01
    z[2,7,2]  R971      -3.9438962936401367e-01
    z[2,7,2]  R972      -4.2634752392768860e-01
    z[2,7,2]  R973      -2.0455385744571686e-01
    z[2,7,2]  R974      3.1482407450675964e-01
    z[2,7,2]  R975      0.0796460285782814
    z[2,7,2]  R976      4.6889832615852356e-01
    z[2,7,2]  R977      6.7965364456176758e-01
    z[2,7,2]  R978      3.7591493129730225e-01
    z[2,7,2]  R979      -3.5959637165069580e-01
    z[2,7,2]  R980      -5.1113218069076538e-01
    z[2,7,2]  R981      -4.6645429730415344e-01
    z[2,7,2]  R982      1.7479488253593445e-01
    z[2,7,2]  R983      -2.1831433475017548e-01
    z[2,7,2]  R984      3.5196727514266968e-01
    z[2,7,2]  R985      -2.9363530874252319e-01
    z[2,7,2]  R986      -1.0206980258226395e-01
    z[2,7,2]  R987      8.3683505654335022e-02
    z[2,7,2]  R988      7.9446166753768921e-01
    z[2,7,2]  R989      2.9570186138153076e-01
    z[2,7,2]  R990      -3.6811664700508118e-01
    z[2,7,2]  R991      -0.686767041683197
    z[2,7,2]  R992      -7.2401577234268188e-01
    z[2,7,2]  R993      -7.6279765367507935e-01
    z[2,7,2]  R994      -2.4987235665321350e-01
    z[2,7,2]  R995      8.0049097537994385e-02
    z[2,7,2]  R996      -2.3241643607616425e-01
    z[2,7,2]  R997      -5.9219084680080414e-02
    z[2,7,2]  R998      -1.5208722651004791e-01
    z[2,7,2]  R999      -3.8834550976753235e-01
    z[2,7,2]  R1000     1.2844204902648926e-01
    z[2,7,2]  R1001     7.9727783799171448e-02
    z[2,7,2]  R1002     -3.1406372785568237e-01
    z[2,7,2]  R1003     -2.2537735104560852e-01
    z[2,7,2]  R1004     3.1608071923255920e-01
    z[2,7,2]  R1005     0.568540096282959
    z[2,7,2]  R1006     -1.6008764505386353e-01
    z[2,7,2]  R1007     6.4011670649051666e-02
    z[2,7,2]  R1008     1.6753885149955750e-01
    z[2,7,2]  R1009     -2.5317856669425964e-01
    z[2,7,2]  R1010     5.0702389329671860e-02
    z[2,7,2]  R1011     -3.5285180807113647e-01
    z[2,7,2]  R1012     2.7158821467310190e-03
    z[2,7,2]  R1013     1.0803978657349944e-03
    z[2,7,2]  R1014     -1.3204509019851685e-01
    z[2,7,2]  R1015     -2.4696128070354462e-01
    z[2,7,2]  R1016     1.7244906723499298e-01
    z[2,7,2]  R1017     -6.4365096390247345e-02
    z[2,7,2]  R1018     1.3435410801321268e-03
    z[2,7,2]  R1019     2.3369173705577850e-01
    z[2,7,2]  R1020     -2.3711295425891876e-01
    z[2,7,2]  R1021     4.8450350761413574e-01
    z[2,7,2]  R1022     -4.2923524975776672e-01
    z[2,7,2]  R1023     3.4046009182929993e-01
    z[2,7,2]  R1024     6.1573632061481476e-02
    z[2,7,2]  R1025     -3.5468775033950806e-01
    z[2,7,2]  R1026     6.7794602364301682e-03
    z[2,7,2]  R1027     -7.6889827847480774e-02
    z[2,7,2]  R1028     8.4859818220138550e-02
    z[2,7,2]  R1029     -2.2711716592311859e-01
    z[2,7,2]  R1030     -2.6905193924903870e-01
    z[2,7,2]  R1031     -4.9347379803657532e-01
    z[2,7,2]  R1032     -3.0910629034042358e-01
    z[2,7,2]  R1033     -0.624438464641571
    z[2,7,2]  R1034     -3.9014685153961182e-01
    z[2,7,2]  R1035     3.2838678359985352e-01
    z[2,7,2]  R1036     -6.5237575769424438e-01
    z[2,7,2]  R1037     -2.1648381650447845e-01
    z[2,7,2]  R1038     6.9230437278747559e-02
    z[2,7,2]  R1039     -8.0624055862426758e-01
    z[2,7,2]  R1040     -0.617302417755127
    z[2,7,2]  R1041     -0.723918616771698
    z[2,7,2]  R1042     4.9001105129718781e-02
    z[2,7,2]  R1043     -3.2605963945388794e-01
    z[2,7,3]  R23       -1
    z[2,7,3]  R68       1
    z[2,7,3]  R946      -1
    z[2,7,3]  R947      1
    z[2,7,3]  R954      -1.5914860367774963e-01
    z[2,7,3]  R955      -5.3766336292028427e-02
    z[2,7,3]  R956      1.4396573603153229e-01
    z[2,7,3]  R957      -2.5104392319917679e-02
    z[2,7,3]  R958      -1.3331703841686249e-01
    z[2,7,3]  R959      -3.7810721993446350e-01
    z[2,7,3]  R960      -5.7165306806564331e-01
    z[2,7,3]  R961      -1.8017520010471344e-01
    z[2,7,3]  R962      -2.6484557986259460e-01
    z[2,7,3]  R963      -2.8375267982482910e-01
    z[2,7,3]  R964      2.5552812218666077e-01
    z[2,7,3]  R965      0.397329717874527
    z[2,7,3]  R966      4.9832960963249207e-01
    z[2,7,3]  R967      3.3659121394157410e-01
    z[2,7,3]  R968      0.315348356962204
    z[2,7,3]  R969      5.1529526710510254e-01
    z[2,7,3]  R970      2.5374817848205566e-01
    z[2,7,3]  R971      3.0752077698707581e-01
    z[2,7,3]  R972      3.7837514281272888e-01
    z[2,7,3]  R973      8.2159496843814850e-02
    z[2,7,3]  R974      -1.5864214301109314e-01
    z[2,7,3]  R975      2.3752050101757050e-01
    z[2,7,3]  R976      -2.7910497784614563e-01
    z[2,7,3]  R977      -3.8216370344161987e-01
    z[2,7,3]  R978      -3.6438465118408203e-01
    z[2,7,3]  R979      -1.6845697164535522e-01
    z[2,7,3]  R980      -2.9784658551216125e-01
    z[2,7,3]  R981      -1.4176808297634125e-01
    z[2,7,3]  R982      2.3424679413437843e-02
    z[2,7,3]  R983      -2.0129530131816864e-01
    z[2,7,3]  R984      -5.1793640851974487e-01
    z[2,7,3]  R985      3.2918041944503784e-01
    z[2,7,3]  R986      2.1268796920776367e-01
    z[2,7,3]  R987      1.9512437283992767e-01
    z[2,7,3]  R988      -3.7618613243103027e-01
    z[2,7,3]  R989      -2.0109087228775024e-01
    z[2,7,3]  R990      0.073503777384758
    z[2,7,3]  R991      -2.3019200563430786e-01
    z[2,7,3]  R992      1.4721383154392242e-01
    z[2,7,3]  R993      -2.4338087439537048e-01
    z[2,7,3]  R994      -6.7224484682083130e-01
    z[2,7,3]  R995      -7.0029366016387939e-01
    z[2,7,3]  R996      -6.1937773227691650e-01
    z[2,7,3]  R997      -7.1388387680053711e-01
    z[2,7,3]  R998      -4.9720174074172974e-01
    z[2,7,3]  R999      -6.4908200502395630e-01
    z[2,7,3]  R1000     -5.3357076644897461e-01
    z[2,7,3]  R1001     -7.3130798339843750e-01
    z[2,7,3]  R1002     -6.9445818662643433e-01
    z[2,7,3]  R1003     -5.0333750247955322e-01
    z[2,7,3]  R1004     8.9732266962528229e-02
    z[2,7,3]  R1005     9.4804614782333374e-02
    z[2,7,3]  R1006     1.2280047684907913e-01
    z[2,7,3]  R1007     -5.7932874187827110e-03
    z[2,7,3]  R1008     3.1909137964248657e-02
    z[2,7,3]  R1009     2.1057588979601860e-02
    z[2,7,3]  R1010     -3.4516620635986328e-01
    z[2,7,3]  R1011     8.7836936116218567e-02
    z[2,7,3]  R1012     2.9434330761432648e-02
    z[2,7,3]  R1013     4.8773370683193207e-02
    z[2,7,3]  R1014     -3.7065398693084717e-01
    z[2,7,3]  R1015     -1.7758302390575409e-01
    z[2,7,3]  R1016     2.2660417854785919e-01
    z[2,7,3]  R1017     1.2246348708868027e-01
    z[2,7,3]  R1018     -4.3347876518964767e-02
    z[2,7,3]  R1019     2.0179098471999168e-02
    z[2,7,3]  R1020     1.2138762325048447e-01
    z[2,7,3]  R1021     -8.3573527634143829e-02
    z[2,7,3]  R1022     1.6214302182197571e-01
    z[2,7,3]  R1023     -5.3740464150905609e-02
    z[2,7,3]  R1024     1.3159784674644470e-01
    z[2,7,3]  R1025     -2.7779016643762589e-02
    z[2,7,3]  R1026     -4.5293146371841431e-01
    z[2,7,3]  R1027     -9.1966682672500610e-01
    z[2,7,3]  R1028     -8.2189255952835083e-01
    z[2,7,3]  R1029     -7.0442509651184082e-01
    z[2,7,3]  R1030     -3.1061306595802307e-01
    z[2,7,3]  R1031     -1.7593665421009064e-01
    z[2,7,3]  R1032     1.3717627525329590e-01
    z[2,7,3]  R1033     -3.4871584177017212e-01
    z[2,7,3]  R1034     -0.436395525932312
    z[2,7,3]  R1035     1.4738725125789642e-01
    z[2,7,3]  R1036     -3.3101609349250793e-01
    z[2,7,3]  R1037     -6.1580508947372437e-01
    z[2,7,3]  R1038     -5.5146604776382446e-01
    z[2,7,3]  R1039     -3.0081382393836975e-01
    z[2,7,3]  R1040     1.3018840551376343e-01
    z[2,7,3]  R1041     1.2936544418334961e-01
    z[2,7,3]  R1042     3.0576642602682114e-02
    z[2,7,3]  R1043     -1.2606064788997173e-02
    z[2,7,4]  R24       -1
    z[2,7,4]  R69       1
    z[2,7,4]  R948      -1
    z[2,7,4]  R949      1
    z[2,7,4]  R954      -4.1487328708171844e-02
    z[2,7,4]  R955      4.1146057844161987e-01
    z[2,7,4]  R956      -3.0920660495758057e-01
    z[2,7,4]  R957      -2.9925815761089325e-03
    z[2,7,4]  R958      4.3003222346305847e-01
    z[2,7,4]  R959      4.5306283235549927e-01
    z[2,7,4]  R960      -9.0662069618701935e-02
    z[2,7,4]  R961      -3.3379447460174561e-01
    z[2,7,4]  R962      -2.3181785643100739e-01
    z[2,7,4]  R963      9.9848099052906036e-02
    z[2,7,4]  R964      -3.7160521745681763e-01
    z[2,7,4]  R965      -3.4199967980384827e-01
    z[2,7,4]  R966      -8.8972700759768486e-03
    z[2,7,4]  R967      -1.7658649384975433e-01
    z[2,7,4]  R968      -2.6077610254287720e-01
    z[2,7,4]  R969      5.7250197976827621e-02
    z[2,7,4]  R970      1.6314479708671570e-01
    z[2,7,4]  R971      -1.0265620797872543e-01
    z[2,7,4]  R972      1.2650048732757568e-01
    z[2,7,4]  R973      1.1672622524201870e-02
    z[2,7,4]  R974      -5.2131730318069458e-01
    z[2,7,4]  R975      5.6925231218338013e-01
    z[2,7,4]  R976      1.6688981652259827e-01
    z[2,7,4]  R977      1.3613104820251465e-01
    z[2,7,4]  R978      2.9619839787483215e-01
    z[2,7,4]  R979      2.1729892492294312e-01
    z[2,7,4]  R980      -9.5797322690486908e-02
    z[2,7,4]  R981      1.8221385776996613e-01
    z[2,7,4]  R982      3.6193040013313293e-01
    z[2,7,4]  R983      6.1044171452522278e-02
    z[2,7,4]  R984      1.4343340694904327e-01
    z[2,7,4]  R985      -8.7525574490427971e-03
    z[2,7,4]  R986      -7.3115348815917969e-02
    z[2,7,4]  R987      3.1686764955520630e-01
    z[2,7,4]  R988      -1.0720803588628769e-01
    z[2,7,4]  R989      -5.5371510982513428e-01
    z[2,7,4]  R990      -4.5539274811744690e-02
    z[2,7,4]  R991      -0.117519810795784
    z[2,7,4]  R992      -1.0086910426616669e-01
    z[2,7,4]  R993      2.7862343192100525e-01
    z[2,7,4]  R994      2.4950763583183289e-01
    z[2,7,4]  R995      3.3191773295402527e-01
    z[2,7,4]  R996      5.4609251022338867e-01
    z[2,7,4]  R997      3.4516081213951111e-01
    z[2,7,4]  R998      6.8939322233200073e-01
    z[2,7,4]  R999      3.4546619653701782e-01
    z[2,7,4]  R1000     0.305010050535202
    z[2,7,4]  R1001     3.4637738019227982e-02
    z[2,7,4]  R1002     -1.0367469489574432e-01
    z[2,7,4]  R1003     5.8627333492040634e-02
    z[2,7,4]  R1004     -8.0068618059158325e-01
    z[2,7,4]  R1005     -6.6231417655944824e-01
    z[2,7,4]  R1006     -9.4892930984497070e-01
    z[2,7,4]  R1007     -8.8086354732513428e-01
    z[2,7,4]  R1008     -8.6299884319305420e-01
    z[2,7,4]  R1009     -7.6170092821121216e-01
    z[2,7,4]  R1010     1.0170640423893929e-02
    z[2,7,4]  R1011     -6.8199980258941650e-01
    z[2,7,4]  R1012     -6.5378212928771973e-01
    z[2,7,4]  R1013     -6.9943392276763916e-01
    z[2,7,4]  R1014     2.3832754790782928e-01
    z[2,7,4]  R1015     -1.8893703818321228e-02
    z[2,7,4]  R1016     -1.6697883605957031e-01
    z[2,7,4]  R1017     -3.8166046142578125e-01
    z[2,7,4]  R1018     -1.1869627982378006e-01
    z[2,7,4]  R1019     4.3013298511505127e-01
    z[2,7,4]  R1020     -2.4247787892818451e-01
    z[2,7,4]  R1021     -0.0239796731621027
    z[2,7,4]  R1022     -2.1718394011259079e-02
    z[2,7,4]  R1023     2.4207362532615662e-01
    z[2,7,4]  R1024     -1.6972647607326508e-01
    z[2,7,4]  R1025     -3.5508543252944946e-01
    z[2,7,4]  R1026     4.5013442635536194e-01
    z[2,7,4]  R1027     -2.9802310466766357e-01
    z[2,7,4]  R1028     -1.7271572351455688e-01
    z[2,7,4]  R1029     -5.0280994176864624e-01
    z[2,7,4]  R1030     -2.2354270517826080e-01
    z[2,7,4]  R1031     2.9778888821601868e-01
    z[2,7,4]  R1032     -3.0977034568786621e-01
    z[2,7,4]  R1033     -1.1161712557077408e-01
    z[2,7,4]  R1034     1.7979015409946442e-01
    z[2,7,4]  R1035     2.1449477970600128e-01
    z[2,7,4]  R1036     -1.2893806397914886e-01
    z[2,7,4]  R1037     -3.8652592897415161e-01
    z[2,7,4]  R1038     -7.7593587338924408e-02
    z[2,7,4]  R1039     2.7747648954391479e-01
    z[2,7,4]  R1040     -2.9270559549331665e-01
    z[2,7,4]  R1041     -2.2900177538394928e-01
    z[2,7,4]  R1042     7.7248387038707733e-02
    z[2,7,4]  R1043     1.1837456375360489e-02
    z[2,7,5]  R25       -1
    z[2,7,5]  R70       1
    z[2,7,5]  R950      -1
    z[2,7,5]  R951      1
    z[2,7,5]  R954      -2.3540283739566803e-01
    z[2,7,5]  R955      -0.00854957289993763
    z[2,7,5]  R956      4.3783590197563171e-01
    z[2,7,5]  R957      8.3130694925785065e-02
    z[2,7,5]  R958      -2.8458476066589355e-01
    z[2,7,5]  R959      -3.8159853219985962e-01
    z[2,7,5]  R960      -4.0739923715591431e-01
    z[2,7,5]  R961      3.3087518811225891e-01
    z[2,7,5]  R962      2.4915076792240143e-02
    z[2,7,5]  R963      -1.7816540598869324e-01
    z[2,7,5]  R964      1.1467922478914261e-01
    z[2,7,5]  R965      4.2003858089447021e-01
    z[2,7,5]  R966      1.6208250820636749e-01
    z[2,7,5]  R967      -7.4223570525646210e-02
    z[2,7,5]  R968      1.1688430607318878e-01
    z[2,7,5]  R969      4.1198921203613281e-01
    z[2,7,5]  R970      -1.3664972782135010e-01
    z[2,7,5]  R971      1.2237863242626190e-01
    z[2,7,5]  R972      8.1927262246608734e-02
    z[2,7,5]  R973      -3.8340527564287186e-02
    z[2,7,5]  R974      2.3994486033916473e-01
    z[2,7,5]  R975      2.3447552323341370e-01
    z[2,7,5]  R976      -2.8205180168151855e-01
    z[2,7,5]  R977      8.0327279865741730e-02
    z[2,7,5]  R978      -2.2595344483852386e-01
    z[2,7,5]  R979      1.5088914334774017e-01
    z[2,7,5]  R980      4.6108019351959229e-01
    z[2,7,5]  R981      3.8675445318222046e-01
    z[2,7,5]  R982      -4.6548891067504883e-01
    z[2,7,5]  R983      3.6300638318061829e-01
    z[2,7,5]  R984      -4.7204324603080750e-01
    z[2,7,5]  R985      2.2548133134841919e-01
    z[2,7,5]  R986      0.294140487909317
    z[2,7,5]  R987      0.269062876701355
    z[2,7,5]  R988      2.7389529347419739e-01
    z[2,7,5]  R989      1.9392102956771851e-01
    z[2,7,5]  R990      2.6628965139389038e-01
    z[2,7,5]  R991      1.4974293299019337e-02
    z[2,7,5]  R992      3.5737559199333191e-01
    z[2,7,5]  R993      3.9832450449466705e-02
    z[2,7,5]  R994      4.2622053623199463e-01
    z[2,7,5]  R995      4.2791518568992615e-01
    z[2,7,5]  R996      1.8242482841014862e-01
    z[2,7,5]  R997      7.0057839155197144e-02
    z[2,7,5]  R998      2.5204014778137207e-01
    z[2,7,5]  R999      7.7326498925685883e-02
    z[2,7,5]  R1000     4.1740727424621582e-01
    z[2,7,5]  R1001     1.1308895796537399e-01
    z[2,7,5]  R1002     2.7069875970482826e-02
    z[2,7,5]  R1003     1.0098073631525040e-02
    z[2,7,5]  R1004     -1.9162584841251373e-01
    z[2,7,5]  R1005     -0.361482709646225
    z[2,7,5]  R1006     -2.1384628489613533e-02
    z[2,7,5]  R1007     -2.3538470268249512e-01
    z[2,7,5]  R1008     -2.2064080834388733e-01
    z[2,7,5]  R1009     -2.3851794004440308e-01
    z[2,7,5]  R1010     3.5427961498498917e-02
    z[2,7,5]  R1011     -2.8092318773269653e-01
    z[2,7,5]  R1012     -2.4708215892314911e-01
    z[2,7,5]  R1013     -1.2099565565586090e-01
    z[2,7,5]  R1014     -1.0895001702010632e-02
    z[2,7,5]  R1015     9.1795986518263817e-03
    z[2,7,5]  R1016     4.2843386530876160e-01
    z[2,7,5]  R1017     2.8480908274650574e-01
    z[2,7,5]  R1018     -1.3585822284221649e-01
    z[2,7,5]  R1019     3.5807177424430847e-01
    z[2,7,5]  R1020     4.4925898313522339e-01
    z[2,7,5]  R1021     2.3420919477939606e-01
    z[2,7,5]  R1022     -3.2690837979316711e-02
    z[2,7,5]  R1023     -4.3979048728942871e-01
    z[2,7,5]  R1024     -0.383866548538208
    z[2,7,5]  R1025     1.1409801244735718e-01
    z[2,7,5]  R1026     6.3329619169235229e-01
    z[2,7,5]  R1027     1.0092271864414215e-01
    z[2,7,5]  R1028     2.1092095971107483e-01
    z[2,7,5]  R1029     3.1188043951988220e-01
    z[2,7,5]  R1030     5.7301986217498779e-01
    z[2,7,5]  R1031     2.9715502262115479e-01
    z[2,7,5]  R1032     -0.68267822265625
    z[2,7,5]  R1033     2.9752397537231445e-01
    z[2,7,5]  R1034     5.5984055995941162e-01
    z[2,7,5]  R1035     4.4256573915481567e-01
    z[2,7,5]  R1036     3.0589541792869568e-01
    z[2,7,5]  R1037     8.0975212156772614e-02
    z[2,7,5]  R1038     -4.2513221502304077e-01
    z[2,7,5]  R1039     -1.5970150008797646e-02
    z[2,7,5]  R1040     -0.633258044719696
    z[2,7,5]  R1041     -5.6956237554550171e-01
    z[2,7,5]  R1042     -4.2983183264732361e-01
    z[2,7,5]  R1043     -3.4924387931823730e-01
    z[2,7,6]  R26       -1
    z[2,7,6]  R71       1
    z[2,7,6]  R952      -1
    z[2,7,6]  R953      1
    z[2,7,6]  R954      -7.5831925496459007e-03
    z[2,7,6]  R955      3.1768417358398438e-01
    z[2,7,6]  R956      2.2149063646793365e-01
    z[2,7,6]  R957      -6.1537390947341919e-01
    z[2,7,6]  R958      -5.8910536766052246e-01
    z[2,7,6]  R959      -2.8587639331817627e-01
    z[2,7,6]  R960      -4.2594605684280396e-01
    z[2,7,6]  R961      -1.7558148503303528e-01
    z[2,7,6]  R962      -6.2235742807388306e-01
    z[2,7,6]  R963      -1.8804767727851868e-01
    z[2,7,6]  R964      -7.9052805900573730e-02
    z[2,7,6]  R965      1.1902947723865509e-01
    z[2,7,6]  R966      -2.0897845923900604e-01
    z[2,7,6]  R967      -2.2031184285879135e-02
    z[2,7,6]  R968      -1.8457492114976048e-03
    z[2,7,6]  R969      -2.4557389318943024e-02
    z[2,7,6]  R970      0.099223293364048
    z[2,7,6]  R971      -0.486009806394577
    z[2,7,6]  R972      4.5687224715948105e-02
    z[2,7,6]  R973      4.2492789030075073e-01
    z[2,7,6]  R974      -6.0149419307708740e-01
    z[2,7,6]  R975      3.4033574163913727e-02
    z[2,7,6]  R976      3.5291877388954163e-01
    z[2,7,6]  R977      4.9176418781280518e-01
    z[2,7,6]  R978      0.0779540166258812
    z[2,7,6]  R979      -2.0374687016010284e-01
    z[2,7,6]  R980      1.2019833549857140e-02
    z[2,7,6]  R981      3.5785309970378876e-02
    z[2,7,6]  R982      -2.8921410441398621e-02
    z[2,7,6]  R983      1.3505174219608307e-01
    z[2,7,6]  R984      2.7569654583930969e-01
    z[2,7,6]  R985      -2.7953290939331055e-01
    z[2,7,6]  R986      -8.8077886030077934e-03
    z[2,7,6]  R987      -1.6440071165561676e-01
    z[2,7,6]  R988      2.0350660383701324e-01
    z[2,7,6]  R989      1.4017286896705627e-01
    z[2,7,6]  R990      -1.0919430851936340e-01
    z[2,7,6]  R991      -2.2402319312095642e-01
    z[2,7,6]  R992      -1.3143707811832428e-01
    z[2,7,6]  R993      0.0490855909883976
    z[2,7,6]  R994      -6.1305873095989227e-02
    z[2,7,6]  R995      2.4486029148101807e-01
    z[2,7,6]  R996      1.2513917684555054e-01
    z[2,7,6]  R997      0.0778806284070015
    z[2,7,6]  R998      -1.8003915250301361e-01
    z[2,7,6]  R999      -3.0970746278762817e-01
    z[2,7,6]  R1000     -4.2147025465965271e-01
    z[2,7,6]  R1001     4.6574071049690247e-02
    z[2,7,6]  R1002     4.5222377777099609e-01
    z[2,7,6]  R1003     2.8092715144157410e-01
    z[2,7,6]  R1004     -3.5933154821395874e-01
    z[2,7,6]  R1005     -2.1390192210674286e-01
    z[2,7,6]  R1006     1.5885165194049478e-03
    z[2,7,6]  R1007     5.9050343930721283e-02
    z[2,7,6]  R1008     3.7085619568824768e-01
    z[2,7,6]  R1009     -4.1800227761268616e-01
    z[2,7,6]  R1010     2.4873162806034088e-01
    z[2,7,6]  R1011     -4.9483460187911987e-01
    z[2,7,6]  R1012     -6.0781919956207275e-01
    z[2,7,6]  R1013     -2.1567137539386749e-01
    z[2,7,6]  R1014     -1.4419928193092346e-01
    z[2,7,6]  R1015     -1.8300722539424896e-01
    z[2,7,6]  R1016     -4.3642383068799973e-02
    z[2,7,6]  R1017     -2.1453650295734406e-01
    z[2,7,6]  R1018     5.5653733015060425e-01
    z[2,7,6]  R1019     -2.6611623167991638e-01
    z[2,7,6]  R1020     1.9246926903724670e-01
    z[2,7,6]  R1021     2.8264707326889038e-01
    z[2,7,6]  R1022     -1.8486200273036957e-01
    z[2,7,6]  R1023     -3.7808814644813538e-01
    z[2,7,6]  R1024     -1.9174209237098694e-01
    z[2,7,6]  R1025     -2.4110180139541626e-01
    z[2,7,6]  R1026     -2.7830812335014343e-01
    z[2,7,6]  R1027     1.5989591181278229e-01
    z[2,7,6]  R1028     -3.0983921885490417e-01
    z[2,7,6]  R1029     7.1816518902778625e-02
    z[2,7,6]  R1030     -4.6738538146018982e-01
    z[2,7,6]  R1031     -3.3327281475067139e-01
    z[2,7,6]  R1032     -3.1285735964775085e-01
    z[2,7,6]  R1033     -5.3250551223754883e-01
    z[2,7,6]  R1034     2.0171479880809784e-01
    z[2,7,6]  R1035     1.2863324582576752e-01
    z[2,7,6]  R1036     -4.5032438635826111e-01
    z[2,7,6]  R1037     -4.7583183646202087e-01
    z[2,7,6]  R1038     2.8816403821110725e-02
    z[2,7,6]  R1039     -1.9571878015995026e-01
    z[2,7,6]  R1040     3.2713532447814941e-01
    z[2,7,6]  R1041     0.0740632712841034
    z[2,7,6]  R1042     -1.2733453512191772e-01
    z[2,7,6]  R1043     2.0751886069774628e-01
    z[7,2,0]  R20       1
    z[7,2,0]  R65       -1
    z[7,2,0]  R1044     -1
    z[7,2,0]  R1045     1
    z[7,2,0]  R1058     4.7603544592857361e-01
    z[7,2,0]  R1059     3.6790758371353149e-01
    z[7,2,0]  R1060     4.1421744227409363e-01
    z[7,2,0]  R1061     -3.9302725344896317e-02
    z[7,2,0]  R1062     3.1200116872787476e-01
    z[7,2,0]  R1063     3.5082545876502991e-01
    z[7,2,0]  R1064     -8.3406277000904083e-02
    z[7,2,0]  R1065     5.2954941987991333e-01
    z[7,2,0]  R1066     3.5198795795440674e-01
    z[7,2,0]  R1067     0.588661253452301
    z[7,2,0]  R1068     -2.9111906886100769e-01
    z[7,2,0]  R1069     5.9338800609111786e-02
    z[7,2,0]  R1070     -1.7377567291259766e-01
    z[7,2,0]  R1071     2.0256677269935608e-01
    z[7,2,0]  R1072     -1.1065188795328140e-01
    z[7,2,0]  R1073     -8.7795235216617584e-02
    z[7,2,0]  R1074     -3.0642268061637878e-01
    z[7,2,0]  R1075     2.7552178502082825e-01
    z[7,2,0]  R1076     3.7211981415748596e-01
    z[7,2,0]  R1077     6.6856807470321655e-01
    z[7,2,0]  R1078     1.3725635409355164e-01
    z[7,2,0]  R1079     3.8982889056205750e-01
    z[7,2,0]  R1080     -0.123763807117939
    z[7,2,0]  R1081     3.7052273750305176e-01
    z[7,2,0]  R1082     4.1609662771224976e-01
    z[7,2,0]  R1083     2.5699424743652344e-01
    z[7,2,0]  R1084     4.1304844617843628e-01
    z[7,2,0]  R1085     4.1018193960189819e-01
    z[7,2,0]  R1086     -3.0694928765296936e-01
    z[7,2,0]  R1087     2.4791166186332703e-01
    z[7,2,0]  R1088     -0.0092205461114645
    z[7,2,0]  R1089     -2.7029192447662354e-01
    z[7,2,0]  R1090     1.2486063875257969e-02
    z[7,2,0]  R1091     -7.6464004814624786e-02
    z[7,2,0]  R1092     -3.1966125965118408e-01
    z[7,2,0]  R1093     -2.7544555068016052e-01
    z[7,2,0]  R1094     -4.4085282087326050e-01
    z[7,2,0]  R1095     -6.3712352514266968e-01
    z[7,2,0]  R1096     -2.3229372501373291e-01
    z[7,2,0]  R1097     5.8029163628816605e-03
    z[7,2,0]  R1098     -5.2021265029907227e-01
    z[7,2,0]  R1099     3.8525256514549255e-01
    z[7,2,0]  R1100     -3.6801743507385254e-01
    z[7,2,0]  R1101     2.2431758046150208e-01
    z[7,2,0]  R1102     1.1507070809602737e-01
    z[7,2,0]  R1103     -2.2654646635055542e-01
    z[7,2,0]  R1104     8.1596441566944122e-02
    z[7,2,0]  R1105     1.6711363196372986e-01
    z[7,2,0]  R1106     -8.7778925895690918e-01
    z[7,2,0]  R1107     -8.5311925411224365e-01
    z[7,2,0]  R1108     8.6434870958328247e-01
    z[7,2,0]  R1109     6.6791445016860962e-01
    z[7,2,0]  R1110     4.6498170495033264e-01
    z[7,2,0]  R1111     0.728111743927002
    z[7,2,0]  R1112     4.3952608108520508e-01
    z[7,2,0]  R1113     4.9878180027008057e-01
    z[7,2,0]  R1114     3.3203712105751038e-01
    z[7,2,0]  R1115     -3.1681719422340393e-01
    z[7,2,0]  R1116     -2.2113482654094696e-01
    z[7,2,0]  R1117     -4.0880167484283447e-01
    z[7,2,0]  R1118     1.5702225267887115e-01
    z[7,2,0]  R1119     8.3548091351985931e-02
    z[7,2,0]  R1120     -1.2691356241703033e-01
    z[7,2,0]  R1121     2.9052982106804848e-02
    z[7,2,0]  R1122     -3.8130503892898560e-01
    z[7,2,0]  R1123     -3.5953405499458313e-01
    z[7,2,0]  R1124     1.6758590936660767e-01
    z[7,2,0]  R1125     -2.6364507153630257e-02
    z[7,2,0]  R1126     4.3519932031631470e-01
    z[7,2,0]  R1127     -8.5451684892177582e-02
    z[7,2,0]  R1128     1.0135149210691452e-01
    z[7,2,0]  R1129     -1.2466557323932648e-01
    z[7,2,0]  R1130     -5.1005119085311890e-01
    z[7,2,0]  R1131     -2.8411766886711121e-01
    z[7,2,0]  R1132     -6.6755360364913940e-01
    z[7,2,0]  R1133     -8.4686893224716187e-01
    z[7,2,0]  R1134     -6.4801824092864990e-01
    z[7,2,0]  R1135     -7.4008554220199585e-01
    z[7,2,0]  R1136     -6.8051880598068237e-01
    z[7,2,0]  R1137     -8.6460644006729126e-01
    z[7,2,0]  R1138     -2.0326793193817139e-01
    z[7,2,0]  R1139     -0.0492432564496994
    z[7,2,0]  R1140     -3.1620556116104126e-01
    z[7,2,0]  R1141     -6.6749915480613708e-02
    z[7,2,0]  R1142     -0.070064976811409
    z[7,2,0]  R1143     4.1202157735824585e-01
    z[7,2,0]  R1144     -8.6416286230087280e-01
    z[7,2,0]  R1145     -6.2534677982330322e-01
    z[7,2,0]  R1146     -4.6929138898849487e-01
    z[7,2,0]  R1147     -4.9503171443939209e-01
    z[7,2,1]  R21       1
    z[7,2,1]  R66       -1
    z[7,2,1]  R1046     -1
    z[7,2,1]  R1047     1
    z[7,2,1]  R1058     -1.0660460591316223e-01
    z[7,2,1]  R1059     -1.2077955156564713e-01
    z[7,2,1]  R1060     -2.0885924994945526e-01
    z[7,2,1]  R1061     -5.9599387645721436e-01
    z[7,2,1]  R1062     -2.4721232056617737e-01
    z[7,2,1]  R1063     -2.8906211256980896e-01
    z[7,2,1]  R1064     -4.9694183468818665e-01
    z[7,2,1]  R1065     -4.0280455350875854e-01
    z[7,2,1]  R1066     -2.8144043684005737e-01
    z[7,2,1]  R1067     -5.1659953594207764e-01
    z[7,2,1]  R1068     -1.8781755119562149e-02
    z[7,2,1]  R1069     2.2174131870269775e-01
    z[7,2,1]  R1070     1.6783127188682556e-01
    z[7,2,1]  R1071     -3.4644204378128052e-01
    z[7,2,1]  R1072     1.6638845205307007e-01
    z[7,2,1]  R1073     3.4050557017326355e-01
    z[7,2,1]  R1074     8.4921658039093018e-01
    z[7,2,1]  R1075     -5.4452598094940186e-02
    z[7,2,1]  R1076     5.2231132984161377e-02
    z[7,2,1]  R1077     0.0165800079703331
    z[7,2,1]  R1078     8.6523312330245972e-01
    z[7,2,1]  R1079     0.849455714225769
    z[7,2,1]  R1080     8.3081424236297607e-01
    z[7,2,1]  R1081     7.5549054145812988e-01
    z[7,2,1]  R1082     6.9476801156997681e-01
    z[7,2,1]  R1083     7.0348227024078369e-01
    z[7,2,1]  R1084     6.7879295349121094e-01
    z[7,2,1]  R1085     6.7431765794754028e-01
    z[7,2,1]  R1086     0.812117338180542
    z[7,2,1]  R1087     6.5174585580825806e-01
    z[7,2,1]  R1088     0.875145673751831
    z[7,2,1]  R1089     7.7661645412445068e-01
    z[7,2,1]  R1090     3.3691346645355225e-01
    z[7,2,1]  R1091     -1.3373208045959473e-01
    z[7,2,1]  R1092     2.1163500845432281e-01
    z[7,2,1]  R1093     1.4521718025207520e-01
    z[7,2,1]  R1094     2.0001755654811859e-01
    z[7,2,1]  R1095     -1.7763268947601318e-01
    z[7,2,1]  R1096     -4.1447395086288452e-01
    z[7,2,1]  R1097     3.2233405113220215e-01
    z[7,2,1]  R1098     -1.6980348154902458e-02
    z[7,2,1]  R1099     6.8088221549987793e-01
    z[7,2,1]  R1100     1.2809453904628754e-01
    z[7,2,1]  R1101     -3.7579932808876038e-01
    z[7,2,1]  R1102     -7.0018756389617920e-01
    z[7,2,1]  R1103     3.0431863665580750e-01
    z[7,2,1]  R1104     -4.0260177105665207e-02
    z[7,2,1]  R1105     -2.2124862670898438e-01
    z[7,2,1]  R1106     1.3861157000064850e-01
    z[7,2,1]  R1107     2.3196747526526451e-02
    z[7,2,1]  R1108     -4.0723243355751038e-01
    z[7,2,1]  R1109     -4.3571284413337708e-01
    z[7,2,1]  R1110     -0.633994460105896
    z[7,2,1]  R1111     -2.0166671276092529e-01
    z[7,2,1]  R1112     -3.9191511273384094e-01
    z[7,2,1]  R1113     -9.8720192909240723e-03
    z[7,2,1]  R1114     1.8145754933357239e-02
    z[7,2,1]  R1115     -6.2250858545303345e-01
    z[7,2,1]  R1116     -5.6228274106979370e-01
    z[7,2,1]  R1117     -7.7131259441375732e-01
    z[7,2,1]  R1118     7.5322926044464111e-01
    z[7,2,1]  R1119     6.4812260866165161e-01
    z[7,2,1]  R1120     5.3232693672180176e-01
    z[7,2,1]  R1121     6.2306547164916992e-01
    z[7,2,1]  R1122     6.3632696866989136e-01
    z[7,2,1]  R1123     5.3356373310089111e-01
    z[7,2,1]  R1124     7.9223489761352539e-01
    z[7,2,1]  R1125     6.9819223880767822e-01
    z[7,2,1]  R1126     6.7886650562286377e-01
    z[7,2,1]  R1127     8.7288916110992432e-01
    z[7,2,1]  R1128     -4.1749957203865051e-01
    z[7,2,1]  R1129     0.735876202583313
    z[7,2,1]  R1130     0.458394318819046
    z[7,2,1]  R1131     2.1090948581695557e-01
    z[7,2,1]  R1132     3.6799290776252747e-01
    z[7,2,1]  R1133     1.1673334985971451e-01
    z[7,2,1]  R1134     -9.0482152998447418e-02
    z[7,2,1]  R1135     -1.7473979294300079e-01
    z[7,2,1]  R1136     3.9658805727958679e-01
    z[7,2,1]  R1137     -1.0264360159635544e-01
    z[7,2,1]  R1138     -4.9712833762168884e-01
    z[7,2,1]  R1139     8.2093644142150879e-01
    z[7,2,1]  R1140     8.6742001771926880e-01
    z[7,2,1]  R1141     0.866395115852356
    z[7,2,1]  R1142     0.307373583316803
    z[7,2,1]  R1143     5.8181345462799072e-01
    z[7,2,1]  R1144     -1.6553734242916107e-01
    z[7,2,1]  R1145     -1.4171253144741058e-01
    z[7,2,1]  R1146     -2.8058373928070068e-01
    z[7,2,1]  R1147     1.7950499057769775e-01
    z[7,2,2]  R22       1
    z[7,2,2]  R67       -1
    z[7,2,2]  R1048     -1
    z[7,2,2]  R1049     1
    z[7,2,2]  R1058     -2.4987235665321350e-01
    z[7,2,2]  R1059     8.0049097537994385e-02
    z[7,2,2]  R1060     -2.3241643607616425e-01
    z[7,2,2]  R1061     -5.9219084680080414e-02
    z[7,2,2]  R1062     -1.5208722651004791e-01
    z[7,2,2]  R1063     -3.8834550976753235e-01
    z[7,2,2]  R1064     1.2844204902648926e-01
    z[7,2,2]  R1065     7.9727783799171448e-02
    z[7,2,2]  R1066     -3.1406372785568237e-01
    z[7,2,2]  R1067     -2.2537735104560852e-01
    z[7,2,2]  R1068     3.1608071923255920e-01
    z[7,2,2]  R1069     0.568540096282959
    z[7,2,2]  R1070     -1.6008764505386353e-01
    z[7,2,2]  R1071     6.4011670649051666e-02
    z[7,2,2]  R1072     1.6753885149955750e-01
    z[7,2,2]  R1073     -2.5317856669425964e-01
    z[7,2,2]  R1074     5.0702389329671860e-02
    z[7,2,2]  R1075     -3.5285180807113647e-01
    z[7,2,2]  R1076     2.7158821467310190e-03
    z[7,2,2]  R1077     1.0803978657349944e-03
    z[7,2,2]  R1078     -1.3204509019851685e-01
    z[7,2,2]  R1079     -2.4696128070354462e-01
    z[7,2,2]  R1080     1.7244906723499298e-01
    z[7,2,2]  R1081     -6.4365096390247345e-02
    z[7,2,2]  R1082     1.3435410801321268e-03
    z[7,2,2]  R1083     2.3369173705577850e-01
    z[7,2,2]  R1084     -2.3711295425891876e-01
    z[7,2,2]  R1085     4.8450350761413574e-01
    z[7,2,2]  R1086     -4.2923524975776672e-01
    z[7,2,2]  R1087     3.4046009182929993e-01
    z[7,2,2]  R1088     6.1573632061481476e-02
    z[7,2,2]  R1089     -3.5468775033950806e-01
    z[7,2,2]  R1090     6.7794602364301682e-03
    z[7,2,2]  R1091     -7.6889827847480774e-02
    z[7,2,2]  R1092     8.4859818220138550e-02
    z[7,2,2]  R1093     -2.2711716592311859e-01
    z[7,2,2]  R1094     -2.6905193924903870e-01
    z[7,2,2]  R1095     -4.9347379803657532e-01
    z[7,2,2]  R1096     -3.0910629034042358e-01
    z[7,2,2]  R1097     -0.624438464641571
    z[7,2,2]  R1098     -3.9014685153961182e-01
    z[7,2,2]  R1099     3.2838678359985352e-01
    z[7,2,2]  R1100     -6.5237575769424438e-01
    z[7,2,2]  R1101     -2.1648381650447845e-01
    z[7,2,2]  R1102     6.9230437278747559e-02
    z[7,2,2]  R1103     -8.0624055862426758e-01
    z[7,2,2]  R1104     -0.617302417755127
    z[7,2,2]  R1105     -0.723918616771698
    z[7,2,2]  R1106     4.9001105129718781e-02
    z[7,2,2]  R1107     -3.2605963945388794e-01
    z[7,2,2]  R1108     6.7390188574790955e-02
    z[7,2,2]  R1109     3.0142614245414734e-01
    z[7,2,2]  R1110     1.5732099115848541e-01
    z[7,2,2]  R1111     2.0724116265773773e-01
    z[7,2,2]  R1112     1.4994834363460541e-01
    z[7,2,2]  R1113     4.1898164153099060e-01
    z[7,2,2]  R1114     4.5498472452163696e-01
    z[7,2,2]  R1115     4.7741052508354187e-01
    z[7,2,2]  R1116     3.5086354613304138e-01
    z[7,2,2]  R1117     2.8349253535270691e-01
    z[7,2,2]  R1118     -4.3035313487052917e-01
    z[7,2,2]  R1119     -3.2790485024452209e-01
    z[7,2,2]  R1120     -6.1819630861282349e-01
    z[7,2,2]  R1121     -6.7858254909515381e-01
    z[7,2,2]  R1122     -5.1824736595153809e-01
    z[7,2,2]  R1123     -3.8327559828758240e-01
    z[7,2,2]  R1124     -4.7408428788185120e-01
    z[7,2,2]  R1125     -3.9438962936401367e-01
    z[7,2,2]  R1126     -4.2634752392768860e-01
    z[7,2,2]  R1127     -2.0455385744571686e-01
    z[7,2,2]  R1128     3.1482407450675964e-01
    z[7,2,2]  R1129     0.0796460285782814
    z[7,2,2]  R1130     4.6889832615852356e-01
    z[7,2,2]  R1131     6.7965364456176758e-01
    z[7,2,2]  R1132     3.7591493129730225e-01
    z[7,2,2]  R1133     -3.5959637165069580e-01
    z[7,2,2]  R1134     -5.1113218069076538e-01
    z[7,2,2]  R1135     -4.6645429730415344e-01
    z[7,2,2]  R1136     1.7479488253593445e-01
    z[7,2,2]  R1137     -2.1831433475017548e-01
    z[7,2,2]  R1138     3.5196727514266968e-01
    z[7,2,2]  R1139     -2.9363530874252319e-01
    z[7,2,2]  R1140     -1.0206980258226395e-01
    z[7,2,2]  R1141     8.3683505654335022e-02
    z[7,2,2]  R1142     7.9446166753768921e-01
    z[7,2,2]  R1143     2.9570186138153076e-01
    z[7,2,2]  R1144     -3.6811664700508118e-01
    z[7,2,2]  R1145     -0.686767041683197
    z[7,2,2]  R1146     -7.2401577234268188e-01
    z[7,2,2]  R1147     -7.6279765367507935e-01
    z[7,2,3]  R23       1
    z[7,2,3]  R68       -1
    z[7,2,3]  R1050     -1
    z[7,2,3]  R1051     1
    z[7,2,3]  R1058     -6.7224484682083130e-01
    z[7,2,3]  R1059     -7.0029366016387939e-01
    z[7,2,3]  R1060     -6.1937773227691650e-01
    z[7,2,3]  R1061     -7.1388387680053711e-01
    z[7,2,3]  R1062     -4.9720174074172974e-01
    z[7,2,3]  R1063     -6.4908200502395630e-01
    z[7,2,3]  R1064     -5.3357076644897461e-01
    z[7,2,3]  R1065     -7.3130798339843750e-01
    z[7,2,3]  R1066     -6.9445818662643433e-01
    z[7,2,3]  R1067     -5.0333750247955322e-01
    z[7,2,3]  R1068     8.9732266962528229e-02
    z[7,2,3]  R1069     9.4804614782333374e-02
    z[7,2,3]  R1070     1.2280047684907913e-01
    z[7,2,3]  R1071     -5.7932874187827110e-03
    z[7,2,3]  R1072     3.1909137964248657e-02
    z[7,2,3]  R1073     2.1057588979601860e-02
    z[7,2,3]  R1074     -3.4516620635986328e-01
    z[7,2,3]  R1075     8.7836936116218567e-02
    z[7,2,3]  R1076     2.9434330761432648e-02
    z[7,2,3]  R1077     4.8773370683193207e-02
    z[7,2,3]  R1078     -3.7065398693084717e-01
    z[7,2,3]  R1079     -1.7758302390575409e-01
    z[7,2,3]  R1080     2.2660417854785919e-01
    z[7,2,3]  R1081     1.2246348708868027e-01
    z[7,2,3]  R1082     -4.3347876518964767e-02
    z[7,2,3]  R1083     2.0179098471999168e-02
    z[7,2,3]  R1084     1.2138762325048447e-01
    z[7,2,3]  R1085     -8.3573527634143829e-02
    z[7,2,3]  R1086     1.6214302182197571e-01
    z[7,2,3]  R1087     -5.3740464150905609e-02
    z[7,2,3]  R1088     1.3159784674644470e-01
    z[7,2,3]  R1089     -2.7779016643762589e-02
    z[7,2,3]  R1090     -4.5293146371841431e-01
    z[7,2,3]  R1091     -9.1966682672500610e-01
    z[7,2,3]  R1092     -8.2189255952835083e-01
    z[7,2,3]  R1093     -7.0442509651184082e-01
    z[7,2,3]  R1094     -3.1061306595802307e-01
    z[7,2,3]  R1095     -1.7593665421009064e-01
    z[7,2,3]  R1096     1.3717627525329590e-01
    z[7,2,3]  R1097     -3.4871584177017212e-01
    z[7,2,3]  R1098     -0.436395525932312
    z[7,2,3]  R1099     1.4738725125789642e-01
    z[7,2,3]  R1100     -3.3101609349250793e-01
    z[7,2,3]  R1101     -6.1580508947372437e-01
    z[7,2,3]  R1102     -5.5146604776382446e-01
    z[7,2,3]  R1103     -3.0081382393836975e-01
    z[7,2,3]  R1104     1.3018840551376343e-01
    z[7,2,3]  R1105     1.2936544418334961e-01
    z[7,2,3]  R1106     3.0576642602682114e-02
    z[7,2,3]  R1107     -1.2606064788997173e-02
    z[7,2,3]  R1108     -1.5914860367774963e-01
    z[7,2,3]  R1109     -5.3766336292028427e-02
    z[7,2,3]  R1110     1.4396573603153229e-01
    z[7,2,3]  R1111     -2.5104392319917679e-02
    z[7,2,3]  R1112     -1.3331703841686249e-01
    z[7,2,3]  R1113     -3.7810721993446350e-01
    z[7,2,3]  R1114     -5.7165306806564331e-01
    z[7,2,3]  R1115     -1.8017520010471344e-01
    z[7,2,3]  R1116     -2.6484557986259460e-01
    z[7,2,3]  R1117     -2.8375267982482910e-01
    z[7,2,3]  R1118     2.5552812218666077e-01
    z[7,2,3]  R1119     0.397329717874527
    z[7,2,3]  R1120     4.9832960963249207e-01
    z[7,2,3]  R1121     3.3659121394157410e-01
    z[7,2,3]  R1122     0.315348356962204
    z[7,2,3]  R1123     5.1529526710510254e-01
    z[7,2,3]  R1124     2.5374817848205566e-01
    z[7,2,3]  R1125     3.0752077698707581e-01
    z[7,2,3]  R1126     3.7837514281272888e-01
    z[7,2,3]  R1127     8.2159496843814850e-02
    z[7,2,3]  R1128     -1.5864214301109314e-01
    z[7,2,3]  R1129     2.3752050101757050e-01
    z[7,2,3]  R1130     -2.7910497784614563e-01
    z[7,2,3]  R1131     -3.8216370344161987e-01
    z[7,2,3]  R1132     -3.6438465118408203e-01
    z[7,2,3]  R1133     -1.6845697164535522e-01
    z[7,2,3]  R1134     -2.9784658551216125e-01
    z[7,2,3]  R1135     -1.4176808297634125e-01
    z[7,2,3]  R1136     2.3424679413437843e-02
    z[7,2,3]  R1137     -2.0129530131816864e-01
    z[7,2,3]  R1138     -5.1793640851974487e-01
    z[7,2,3]  R1139     3.2918041944503784e-01
    z[7,2,3]  R1140     2.1268796920776367e-01
    z[7,2,3]  R1141     1.9512437283992767e-01
    z[7,2,3]  R1142     -3.7618613243103027e-01
    z[7,2,3]  R1143     -2.0109087228775024e-01
    z[7,2,3]  R1144     0.073503777384758
    z[7,2,3]  R1145     -2.3019200563430786e-01
    z[7,2,3]  R1146     1.4721383154392242e-01
    z[7,2,3]  R1147     -2.4338087439537048e-01
    z[7,2,4]  R24       1
    z[7,2,4]  R69       -1
    z[7,2,4]  R1052     -1
    z[7,2,4]  R1053     1
    z[7,2,4]  R1058     2.4950763583183289e-01
    z[7,2,4]  R1059     3.3191773295402527e-01
    z[7,2,4]  R1060     5.4609251022338867e-01
    z[7,2,4]  R1061     3.4516081213951111e-01
    z[7,2,4]  R1062     6.8939322233200073e-01
    z[7,2,4]  R1063     3.4546619653701782e-01
    z[7,2,4]  R1064     0.305010050535202
    z[7,2,4]  R1065     3.4637738019227982e-02
    z[7,2,4]  R1066     -1.0367469489574432e-01
    z[7,2,4]  R1067     5.8627333492040634e-02
    z[7,2,4]  R1068     -8.0068618059158325e-01
    z[7,2,4]  R1069     -6.6231417655944824e-01
    z[7,2,4]  R1070     -9.4892930984497070e-01
    z[7,2,4]  R1071     -8.8086354732513428e-01
    z[7,2,4]  R1072     -8.6299884319305420e-01
    z[7,2,4]  R1073     -7.6170092821121216e-01
    z[7,2,4]  R1074     1.0170640423893929e-02
    z[7,2,4]  R1075     -6.8199980258941650e-01
    z[7,2,4]  R1076     -6.5378212928771973e-01
    z[7,2,4]  R1077     -6.9943392276763916e-01
    z[7,2,4]  R1078     2.3832754790782928e-01
    z[7,2,4]  R1079     -1.8893703818321228e-02
    z[7,2,4]  R1080     -1.6697883605957031e-01
    z[7,2,4]  R1081     -3.8166046142578125e-01
    z[7,2,4]  R1082     -1.1869627982378006e-01
    z[7,2,4]  R1083     4.3013298511505127e-01
    z[7,2,4]  R1084     -2.4247787892818451e-01
    z[7,2,4]  R1085     -0.0239796731621027
    z[7,2,4]  R1086     -2.1718394011259079e-02
    z[7,2,4]  R1087     2.4207362532615662e-01
    z[7,2,4]  R1088     -1.6972647607326508e-01
    z[7,2,4]  R1089     -3.5508543252944946e-01
    z[7,2,4]  R1090     4.5013442635536194e-01
    z[7,2,4]  R1091     -2.9802310466766357e-01
    z[7,2,4]  R1092     -1.7271572351455688e-01
    z[7,2,4]  R1093     -5.0280994176864624e-01
    z[7,2,4]  R1094     -2.2354270517826080e-01
    z[7,2,4]  R1095     2.9778888821601868e-01
    z[7,2,4]  R1096     -3.0977034568786621e-01
    z[7,2,4]  R1097     -1.1161712557077408e-01
    z[7,2,4]  R1098     1.7979015409946442e-01
    z[7,2,4]  R1099     2.1449477970600128e-01
    z[7,2,4]  R1100     -1.2893806397914886e-01
    z[7,2,4]  R1101     -3.8652592897415161e-01
    z[7,2,4]  R1102     -7.7593587338924408e-02
    z[7,2,4]  R1103     2.7747648954391479e-01
    z[7,2,4]  R1104     -2.9270559549331665e-01
    z[7,2,4]  R1105     -2.2900177538394928e-01
    z[7,2,4]  R1106     7.7248387038707733e-02
    z[7,2,4]  R1107     1.1837456375360489e-02
    z[7,2,4]  R1108     -4.1487328708171844e-02
    z[7,2,4]  R1109     4.1146057844161987e-01
    z[7,2,4]  R1110     -3.0920660495758057e-01
    z[7,2,4]  R1111     -2.9925815761089325e-03
    z[7,2,4]  R1112     4.3003222346305847e-01
    z[7,2,4]  R1113     4.5306283235549927e-01
    z[7,2,4]  R1114     -9.0662069618701935e-02
    z[7,2,4]  R1115     -3.3379447460174561e-01
    z[7,2,4]  R1116     -2.3181785643100739e-01
    z[7,2,4]  R1117     9.9848099052906036e-02
    z[7,2,4]  R1118     -3.7160521745681763e-01
    z[7,2,4]  R1119     -3.4199967980384827e-01
    z[7,2,4]  R1120     -8.8972700759768486e-03
    z[7,2,4]  R1121     -1.7658649384975433e-01
    z[7,2,4]  R1122     -2.6077610254287720e-01
    z[7,2,4]  R1123     5.7250197976827621e-02
    z[7,2,4]  R1124     1.6314479708671570e-01
    z[7,2,4]  R1125     -1.0265620797872543e-01
    z[7,2,4]  R1126     1.2650048732757568e-01
    z[7,2,4]  R1127     1.1672622524201870e-02
    z[7,2,4]  R1128     -5.2131730318069458e-01
    z[7,2,4]  R1129     5.6925231218338013e-01
    z[7,2,4]  R1130     1.6688981652259827e-01
    z[7,2,4]  R1131     1.3613104820251465e-01
    z[7,2,4]  R1132     2.9619839787483215e-01
    z[7,2,4]  R1133     2.1729892492294312e-01
    z[7,2,4]  R1134     -9.5797322690486908e-02
    z[7,2,4]  R1135     1.8221385776996613e-01
    z[7,2,4]  R1136     3.6193040013313293e-01
    z[7,2,4]  R1137     6.1044171452522278e-02
    z[7,2,4]  R1138     1.4343340694904327e-01
    z[7,2,4]  R1139     -8.7525574490427971e-03
    z[7,2,4]  R1140     -7.3115348815917969e-02
    z[7,2,4]  R1141     3.1686764955520630e-01
    z[7,2,4]  R1142     -1.0720803588628769e-01
    z[7,2,4]  R1143     -5.5371510982513428e-01
    z[7,2,4]  R1144     -4.5539274811744690e-02
    z[7,2,4]  R1145     -0.117519810795784
    z[7,2,4]  R1146     -1.0086910426616669e-01
    z[7,2,4]  R1147     2.7862343192100525e-01
    z[7,2,5]  R25       1
    z[7,2,5]  R70       -1
    z[7,2,5]  R1054     -1
    z[7,2,5]  R1055     1
    z[7,2,5]  R1058     4.2622053623199463e-01
    z[7,2,5]  R1059     4.2791518568992615e-01
    z[7,2,5]  R1060     1.8242482841014862e-01
    z[7,2,5]  R1061     7.0057839155197144e-02
    z[7,2,5]  R1062     2.5204014778137207e-01
    z[7,2,5]  R1063     7.7326498925685883e-02
    z[7,2,5]  R1064     4.1740727424621582e-01
    z[7,2,5]  R1065     1.1308895796537399e-01
    z[7,2,5]  R1066     2.7069875970482826e-02
    z[7,2,5]  R1067     1.0098073631525040e-02
    z[7,2,5]  R1068     -1.9162584841251373e-01
    z[7,2,5]  R1069     -0.361482709646225
    z[7,2,5]  R1070     -2.1384628489613533e-02
    z[7,2,5]  R1071     -2.3538470268249512e-01
    z[7,2,5]  R1072     -2.2064080834388733e-01
    z[7,2,5]  R1073     -2.3851794004440308e-01
    z[7,2,5]  R1074     3.5427961498498917e-02
    z[7,2,5]  R1075     -2.8092318773269653e-01
    z[7,2,5]  R1076     -2.4708215892314911e-01
    z[7,2,5]  R1077     -1.2099565565586090e-01
    z[7,2,5]  R1078     -1.0895001702010632e-02
    z[7,2,5]  R1079     9.1795986518263817e-03
    z[7,2,5]  R1080     4.2843386530876160e-01
    z[7,2,5]  R1081     2.8480908274650574e-01
    z[7,2,5]  R1082     -1.3585822284221649e-01
    z[7,2,5]  R1083     3.5807177424430847e-01
    z[7,2,5]  R1084     4.4925898313522339e-01
    z[7,2,5]  R1085     2.3420919477939606e-01
    z[7,2,5]  R1086     -3.2690837979316711e-02
    z[7,2,5]  R1087     -4.3979048728942871e-01
    z[7,2,5]  R1088     -0.383866548538208
    z[7,2,5]  R1089     1.1409801244735718e-01
    z[7,2,5]  R1090     6.3329619169235229e-01
    z[7,2,5]  R1091     1.0092271864414215e-01
    z[7,2,5]  R1092     2.1092095971107483e-01
    z[7,2,5]  R1093     3.1188043951988220e-01
    z[7,2,5]  R1094     5.7301986217498779e-01
    z[7,2,5]  R1095     2.9715502262115479e-01
    z[7,2,5]  R1096     -0.68267822265625
    z[7,2,5]  R1097     2.9752397537231445e-01
    z[7,2,5]  R1098     5.5984055995941162e-01
    z[7,2,5]  R1099     4.4256573915481567e-01
    z[7,2,5]  R1100     3.0589541792869568e-01
    z[7,2,5]  R1101     8.0975212156772614e-02
    z[7,2,5]  R1102     -4.2513221502304077e-01
    z[7,2,5]  R1103     -1.5970150008797646e-02
    z[7,2,5]  R1104     -0.633258044719696
    z[7,2,5]  R1105     -5.6956237554550171e-01
    z[7,2,5]  R1106     -4.2983183264732361e-01
    z[7,2,5]  R1107     -3.4924387931823730e-01
    z[7,2,5]  R1108     -2.3540283739566803e-01
    z[7,2,5]  R1109     -0.00854957289993763
    z[7,2,5]  R1110     4.3783590197563171e-01
    z[7,2,5]  R1111     8.3130694925785065e-02
    z[7,2,5]  R1112     -2.8458476066589355e-01
    z[7,2,5]  R1113     -3.8159853219985962e-01
    z[7,2,5]  R1114     -4.0739923715591431e-01
    z[7,2,5]  R1115     3.3087518811225891e-01
    z[7,2,5]  R1116     2.4915076792240143e-02
    z[7,2,5]  R1117     -1.7816540598869324e-01
    z[7,2,5]  R1118     1.1467922478914261e-01
    z[7,2,5]  R1119     4.2003858089447021e-01
    z[7,2,5]  R1120     1.6208250820636749e-01
    z[7,2,5]  R1121     -7.4223570525646210e-02
    z[7,2,5]  R1122     1.1688430607318878e-01
    z[7,2,5]  R1123     4.1198921203613281e-01
    z[7,2,5]  R1124     -1.3664972782135010e-01
    z[7,2,5]  R1125     1.2237863242626190e-01
    z[7,2,5]  R1126     8.1927262246608734e-02
    z[7,2,5]  R1127     -3.8340527564287186e-02
    z[7,2,5]  R1128     2.3994486033916473e-01
    z[7,2,5]  R1129     2.3447552323341370e-01
    z[7,2,5]  R1130     -2.8205180168151855e-01
    z[7,2,5]  R1131     8.0327279865741730e-02
    z[7,2,5]  R1132     -2.2595344483852386e-01
    z[7,2,5]  R1133     1.5088914334774017e-01
    z[7,2,5]  R1134     4.6108019351959229e-01
    z[7,2,5]  R1135     3.8675445318222046e-01
    z[7,2,5]  R1136     -4.6548891067504883e-01
    z[7,2,5]  R1137     3.6300638318061829e-01
    z[7,2,5]  R1138     -4.7204324603080750e-01
    z[7,2,5]  R1139     2.2548133134841919e-01
    z[7,2,5]  R1140     0.294140487909317
    z[7,2,5]  R1141     0.269062876701355
    z[7,2,5]  R1142     2.7389529347419739e-01
    z[7,2,5]  R1143     1.9392102956771851e-01
    z[7,2,5]  R1144     2.6628965139389038e-01
    z[7,2,5]  R1145     1.4974293299019337e-02
    z[7,2,5]  R1146     3.5737559199333191e-01
    z[7,2,5]  R1147     3.9832450449466705e-02
    z[7,2,6]  R26       1
    z[7,2,6]  R71       -1
    z[7,2,6]  R1056     -1
    z[7,2,6]  R1057     1
    z[7,2,6]  R1058     -6.1305873095989227e-02
    z[7,2,6]  R1059     2.4486029148101807e-01
    z[7,2,6]  R1060     1.2513917684555054e-01
    z[7,2,6]  R1061     0.0778806284070015
    z[7,2,6]  R1062     -1.8003915250301361e-01
    z[7,2,6]  R1063     -3.0970746278762817e-01
    z[7,2,6]  R1064     -4.2147025465965271e-01
    z[7,2,6]  R1065     4.6574071049690247e-02
    z[7,2,6]  R1066     4.5222377777099609e-01
    z[7,2,6]  R1067     2.8092715144157410e-01
    z[7,2,6]  R1068     -3.5933154821395874e-01
    z[7,2,6]  R1069     -2.1390192210674286e-01
    z[7,2,6]  R1070     1.5885165194049478e-03
    z[7,2,6]  R1071     5.9050343930721283e-02
    z[7,2,6]  R1072     3.7085619568824768e-01
    z[7,2,6]  R1073     -4.1800227761268616e-01
    z[7,2,6]  R1074     2.4873162806034088e-01
    z[7,2,6]  R1075     -4.9483460187911987e-01
    z[7,2,6]  R1076     -6.0781919956207275e-01
    z[7,2,6]  R1077     -2.1567137539386749e-01
    z[7,2,6]  R1078     -1.4419928193092346e-01
    z[7,2,6]  R1079     -1.8300722539424896e-01
    z[7,2,6]  R1080     -4.3642383068799973e-02
    z[7,2,6]  R1081     -2.1453650295734406e-01
    z[7,2,6]  R1082     5.5653733015060425e-01
    z[7,2,6]  R1083     -2.6611623167991638e-01
    z[7,2,6]  R1084     1.9246926903724670e-01
    z[7,2,6]  R1085     2.8264707326889038e-01
    z[7,2,6]  R1086     -1.8486200273036957e-01
    z[7,2,6]  R1087     -3.7808814644813538e-01
    z[7,2,6]  R1088     -1.9174209237098694e-01
    z[7,2,6]  R1089     -2.4110180139541626e-01
    z[7,2,6]  R1090     -2.7830812335014343e-01
    z[7,2,6]  R1091     1.5989591181278229e-01
    z[7,2,6]  R1092     -3.0983921885490417e-01
    z[7,2,6]  R1093     7.1816518902778625e-02
    z[7,2,6]  R1094     -4.6738538146018982e-01
    z[7,2,6]  R1095     -3.3327281475067139e-01
    z[7,2,6]  R1096     -3.1285735964775085e-01
    z[7,2,6]  R1097     -5.3250551223754883e-01
    z[7,2,6]  R1098     2.0171479880809784e-01
    z[7,2,6]  R1099     1.2863324582576752e-01
    z[7,2,6]  R1100     -4.5032438635826111e-01
    z[7,2,6]  R1101     -4.7583183646202087e-01
    z[7,2,6]  R1102     2.8816403821110725e-02
    z[7,2,6]  R1103     -1.9571878015995026e-01
    z[7,2,6]  R1104     3.2713532447814941e-01
    z[7,2,6]  R1105     0.0740632712841034
    z[7,2,6]  R1106     -1.2733453512191772e-01
    z[7,2,6]  R1107     2.0751886069774628e-01
    z[7,2,6]  R1108     -7.5831925496459007e-03
    z[7,2,6]  R1109     3.1768417358398438e-01
    z[7,2,6]  R1110     2.2149063646793365e-01
    z[7,2,6]  R1111     -6.1537390947341919e-01
    z[7,2,6]  R1112     -5.8910536766052246e-01
    z[7,2,6]  R1113     -2.8587639331817627e-01
    z[7,2,6]  R1114     -4.2594605684280396e-01
    z[7,2,6]  R1115     -1.7558148503303528e-01
    z[7,2,6]  R1116     -6.2235742807388306e-01
    z[7,2,6]  R1117     -1.8804767727851868e-01
    z[7,2,6]  R1118     -7.9052805900573730e-02
    z[7,2,6]  R1119     1.1902947723865509e-01
    z[7,2,6]  R1120     -2.0897845923900604e-01
    z[7,2,6]  R1121     -2.2031184285879135e-02
    z[7,2,6]  R1122     -1.8457492114976048e-03
    z[7,2,6]  R1123     -2.4557389318943024e-02
    z[7,2,6]  R1124     0.099223293364048
    z[7,2,6]  R1125     -0.486009806394577
    z[7,2,6]  R1126     4.5687224715948105e-02
    z[7,2,6]  R1127     4.2492789030075073e-01
    z[7,2,6]  R1128     -6.0149419307708740e-01
    z[7,2,6]  R1129     3.4033574163913727e-02
    z[7,2,6]  R1130     3.5291877388954163e-01
    z[7,2,6]  R1131     4.9176418781280518e-01
    z[7,2,6]  R1132     0.0779540166258812
    z[7,2,6]  R1133     -2.0374687016010284e-01
    z[7,2,6]  R1134     1.2019833549857140e-02
    z[7,2,6]  R1135     3.5785309970378876e-02
    z[7,2,6]  R1136     -2.8921410441398621e-02
    z[7,2,6]  R1137     1.3505174219608307e-01
    z[7,2,6]  R1138     2.7569654583930969e-01
    z[7,2,6]  R1139     -2.7953290939331055e-01
    z[7,2,6]  R1140     -8.8077886030077934e-03
    z[7,2,6]  R1141     -1.6440071165561676e-01
    z[7,2,6]  R1142     2.0350660383701324e-01
    z[7,2,6]  R1143     1.4017286896705627e-01
    z[7,2,6]  R1144     -1.0919430851936340e-01
    z[7,2,6]  R1145     -2.2402319312095642e-01
    z[7,2,6]  R1146     -1.3143707811832428e-01
    z[7,2,6]  R1147     0.0490855909883976
    z[3,6,0]  R29       -1
    z[3,6,0]  R56       1
    z[3,6,0]  R1148     -1
    z[3,6,0]  R1149     1
    z[3,6,0]  R1162     2.0798969268798828e-01
    z[3,6,0]  R1163     -1.6027653217315674e-01
    z[3,6,0]  R1164     4.4577309489250183e-01
    z[3,6,0]  R1165     0.485567182302475
    z[3,6,0]  R1166     -1.2288659065961838e-01
    z[3,6,0]  R1167     3.4876942634582520e-01
    z[3,6,0]  R1168     -0.182876855134964
    z[3,6,0]  R1169     2.6595833897590637e-01
    z[3,6,0]  R1170     8.1409555673599243e-01
    z[3,6,0]  R1171     7.9661399126052856e-01
    z[3,6,0]  R1172     -7.8262883424758911e-01
    z[3,6,0]  R1173     -5.1310819387435913e-01
    z[3,6,0]  R1174     -3.4668001532554626e-01
    z[3,6,0]  R1175     2.5861239433288574e-01
    z[3,6,0]  R1176     -4.4897374510765076e-01
    z[3,6,0]  R1177     -2.0265442132949829e-01
    z[3,6,0]  R1178     8.8884755969047546e-03
    z[3,6,0]  R1179     -7.0157241821289062e-01
    z[3,6,0]  R1180     -0.680765688419342
    z[3,6,0]  R1181     -5.1564160734415054e-02
    z[3,6,0]  R1182     -2.9696670174598694e-01
    z[3,6,0]  R1183     -5.6222927570343018e-01
    z[3,6,0]  R1184     -4.8878137022256851e-02
    z[3,6,0]  R1185     3.4708552062511444e-02
    z[3,6,0]  R1186     4.5578765869140625e-01
    z[3,6,0]  R1187     2.4165239930152893e-01
    z[3,6,0]  R1188     2.3586918413639069e-01
    z[3,6,0]  R1189     8.8426578044891357e-01
    z[3,6,0]  R1190     0.896182656288147
    z[3,6,0]  R1191     -2.9889929294586182e-01
    z[3,6,0]  R1192     6.1276221275329590e-01
    z[3,6,0]  R1193     4.5041519403457642e-01
    z[3,6,0]  R1194     7.8865963220596313e-01
    z[3,6,0]  R1195     -2.4639409780502319e-01
    z[3,6,0]  R1196     1.6377098858356476e-02
    z[3,6,0]  R1197     -1.1627390235662460e-01
    z[3,6,0]  R1198     -4.9470996856689453e-01
    z[3,6,0]  R1199     -3.7875732779502869e-01
    z[3,6,0]  R1200     -2.3823419213294983e-01
    z[3,6,0]  R1201     -4.1410744190216064e-01
    z[3,6,0]  R1202     -3.6063289642333984e-01
    z[3,6,0]  R1203     -3.6211588978767395e-01
    z[3,6,0]  R1204     -4.6046221256256104e-01
    z[3,6,0]  R1205     1.6052266582846642e-02
    z[3,6,0]  R1206     -6.8675160408020020e-02
    z[3,6,0]  R1207     -9.4422794878482819e-02
    z[3,6,0]  R1208     -1.9267293810844421e-01
    z[3,6,0]  R1209     -2.9476154595613480e-02
    z[3,6,0]  R1210     -1.4457304775714874e-01
    z[3,6,0]  R1211     -0.0837971493601799
    z[3,6,0]  R1212     -3.1692963838577271e-01
    z[3,6,0]  R1213     -3.5143095254898071e-01
    z[3,6,0]  R1214     4.6653710305690765e-02
    z[3,6,0]  R1215     2.4943938478827477e-02
    z[3,6,0]  R1216     -4.3236187100410461e-01
    z[3,6,0]  R1217     -0.120021753013134
    z[3,6,0]  R1218     -3.5201224684715271e-01
    z[3,6,0]  R1219     4.1558140516281128e-01
    z[3,6,0]  R1220     3.8337224721908569e-01
    z[3,6,0]  R1221     1.3972762227058411e-01
    z[3,6,0]  R1222     2.0932084321975708e-01
    z[3,6,0]  R1223     6.7689009010791779e-02
    z[3,6,0]  R1224     1.3679102063179016e-01
    z[3,6,0]  R1225     -0.0431256964802742
    z[3,6,0]  R1226     1.7754010856151581e-01
    z[3,6,0]  R1227     2.9873788356781006e-02
    z[3,6,0]  R1228     -1.5065731480717659e-02
    z[3,6,0]  R1229     -1.4924864470958710e-01
    z[3,6,0]  R1230     2.8897517919540405e-01
    z[3,6,0]  R1231     3.3578014373779297e-01
    z[3,6,0]  R1232     3.3725729584693909e-01
    z[3,6,0]  R1233     4.0198189020156860e-01
    z[3,6,0]  R1234     2.9496408533304930e-03
    z[3,6,0]  R1235     2.8498345613479614e-01
    z[3,6,0]  R1236     -8.2206851243972778e-01
    z[3,6,0]  R1237     -8.2323813438415527e-01
    z[3,6,0]  R1238     -8.6341661214828491e-01
    z[3,6,0]  R1239     -8.0771315097808838e-01
    z[3,6,0]  R1240     -0.781409502029419
    z[3,6,0]  R1241     -8.3696919679641724e-01
    z[3,6,0]  R1242     6.8571992218494415e-02
    z[3,6,0]  R1243     -1.9584028422832489e-01
    z[3,6,0]  R1244     3.4353566169738770e-01
    z[3,6,0]  R1245     -4.1826122999191284e-01
    z[3,6,0]  R1246     -6.9084864854812622e-01
    z[3,6,0]  R1247     -9.3364083766937256e-01
    z[3,6,0]  R1248     -7.7485686540603638e-01
    z[3,6,0]  R1249     -6.2384098768234253e-01
    z[3,6,0]  R1250     -6.7667406797409058e-01
    z[3,6,0]  R1251     -5.3504264354705811e-01
    z[3,6,1]  R30       -1
    z[3,6,1]  R57       1
    z[3,6,1]  R1150     -1
    z[3,6,1]  R1151     1
    z[3,6,1]  R1162     4.7397175431251526e-01
    z[3,6,1]  R1163     -5.1044309139251709e-01
    z[3,6,1]  R1164     1.0607351548969746e-02
    z[3,6,1]  R1165     -6.5003573894500732e-02
    z[3,6,1]  R1166     -4.2076998949050903e-01
    z[3,6,1]  R1167     3.2847024500370026e-02
    z[3,6,1]  R1168     -2.3373763263225555e-01
    z[3,6,1]  R1169     3.5103362053632736e-02
    z[3,6,1]  R1170     1.5364921092987061e-01
    z[3,6,1]  R1171     1.7687892913818359e-01
    z[3,6,1]  R1172     -1.2815099954605103e-01
    z[3,6,1]  R1173     -2.0230868831276894e-02
    z[3,6,1]  R1174     1.3132871687412262e-01
    z[3,6,1]  R1175     3.9347603917121887e-02
    z[3,6,1]  R1176     4.6784910559654236e-01
    z[3,6,1]  R1177     4.3934464454650879e-01
    z[3,6,1]  R1178     -9.8866842687129974e-02
    z[3,6,1]  R1179     5.0842958688735962e-01
    z[3,6,1]  R1180     3.8184297084808350e-01
    z[3,6,1]  R1181     1.7891910672187805e-01
    z[3,6,1]  R1182     0.16356261074543
    z[3,6,1]  R1183     2.4688905104994774e-02
    z[3,6,1]  R1184     6.0318535566329956e-01
    z[3,6,1]  R1185     -0.68907630443573
    z[3,6,1]  R1186     -1.5761137008666992e-01
    z[3,6,1]  R1187     8.9654959738254547e-02
    z[3,6,1]  R1188     -3.7349554896354675e-01
    z[3,6,1]  R1189     1.5629976987838745e-01
    z[3,6,1]  R1190     1.6974413767457008e-02
    z[3,6,1]  R1191     1.3153521716594696e-01
    z[3,6,1]  R1192     -4.6249288320541382e-01
    z[3,6,1]  R1193     -7.3704510927200317e-01
    z[3,6,1]  R1194     -2.5161647796630859e-01
    z[3,6,1]  R1195     2.3816816508769989e-02
    z[3,6,1]  R1196     2.1788033843040466e-01
    z[3,6,1]  R1197     1.1755845695734024e-01
    z[3,6,1]  R1198     -2.8332084417343140e-01
    z[3,6,1]  R1199     -1.5807604789733887e-01
    z[3,6,1]  R1200     -1.3992689782753587e-03
    z[3,6,1]  R1201     0.117411307990551
    z[3,6,1]  R1202     6.4976739883422852e-01
    z[3,6,1]  R1203     7.0342016220092773e-01
    z[3,6,1]  R1204     0.817271888256073
    z[3,6,1]  R1205     5.7912361621856689e-01
    z[3,6,1]  R1206     4.9411904811859131e-01
    z[3,6,1]  R1207     7.1946346759796143e-01
    z[3,6,1]  R1208     8.8183438777923584e-01
    z[3,6,1]  R1209     7.8212618827819824e-01
    z[3,6,1]  R1210     4.9071976542472839e-01
    z[3,6,1]  R1211     3.7327969074249268e-01
    z[3,6,1]  R1212     -1.2900227308273315e-01
    z[3,6,1]  R1213     1.6237090528011322e-01
    z[3,6,1]  R1214     5.3052014112472534e-01
    z[3,6,1]  R1215     9.3510001897811890e-03
    z[3,6,1]  R1216     -2.6308529078960419e-02
    z[3,6,1]  R1217     -3.0889749526977539e-01
    z[3,6,1]  R1218     -3.7239041924476624e-01
    z[3,6,1]  R1219     2.7739086747169495e-01
    z[3,6,1]  R1220     6.6657519340515137e-01
    z[3,6,1]  R1221     6.6656738519668579e-01
    z[3,6,1]  R1222     7.9936319589614868e-01
    z[3,6,1]  R1223     0.682819664478302
    z[3,6,1]  R1224     9.0550339221954346e-01
    z[3,6,1]  R1225     9.6975505352020264e-01
    z[3,6,1]  R1226     0.919813334941864
    z[3,6,1]  R1227     6.4759099483489990e-01
    z[3,6,1]  R1228     7.2470885515213013e-01
    z[3,6,1]  R1229     6.8037277460098267e-01
    z[3,6,1]  R1230     6.5666466951370239e-01
    z[3,6,1]  R1231     3.5335782170295715e-01
    z[3,6,1]  R1232     4.4173008203506470e-01
    z[3,6,1]  R1233     -3.5165590047836304e-01
    z[3,6,1]  R1234     -6.1881011724472046e-01
    z[3,6,1]  R1235     -2.8727304935455322e-01
    z[3,6,1]  R1236     -3.5088992118835449e-01
    z[3,6,1]  R1237     -2.9102388024330139e-01
    z[3,6,1]  R1238     -3.4433019161224365e-01
    z[3,6,1]  R1239     -3.2974857091903687e-01
    z[3,6,1]  R1240     -0.326667457818985
    z[3,6,1]  R1241     -2.2301189601421356e-01
    z[3,6,1]  R1242     8.7182819843292236e-01
    z[3,6,1]  R1243     -7.9527907073497772e-02
    z[3,6,1]  R1244     0.713519811630249
    z[3,6,1]  R1245     -0.0815548226237297
    z[3,6,1]  R1246     -1.8828220665454865e-01
    z[3,6,1]  R1247     -2.5633990764617920e-01
    z[3,6,1]  R1248     -1.1624956130981445e-01
    z[3,6,1]  R1249     -1.8742233514785767e-01
    z[3,6,1]  R1250     -2.8065502643585205e-01
    z[3,6,1]  R1251     -9.3812316656112671e-02
    z[3,6,2]  R31       -1
    z[3,6,2]  R58       1
    z[3,6,2]  R1152     -1
    z[3,6,2]  R1153     1
    z[3,6,2]  R1162     -1.4849710464477539e-01
    z[3,6,2]  R1163     2.1112892031669617e-01
    z[3,6,2]  R1164     4.5270791649818420e-01
    z[3,6,2]  R1165     3.3361065387725830e-01
    z[3,6,2]  R1166     2.9637560248374939e-01
    z[3,6,2]  R1167     2.8770384192466736e-01
    z[3,6,2]  R1168     2.3488526046276093e-01
    z[3,6,2]  R1169     2.7894172072410583e-01
    z[3,6,2]  R1170     -3.7805265188217163e-01
    z[3,6,2]  R1171     -2.1345199644565582e-01
    z[3,6,2]  R1172     -3.5631260275840759e-01
    z[3,6,2]  R1173     -3.1214338541030884e-01
    z[3,6,2]  R1174     2.6848953217267990e-02
    z[3,6,2]  R1175     -4.7626032028347254e-04
    z[3,6,2]  R1176     -5.4760348796844482e-01
    z[3,6,2]  R1177     -5.2161341905593872e-01
    z[3,6,2]  R1178     -2.7225714921951294e-01
    z[3,6,2]  R1179     1.4438579976558685e-01
    z[3,6,2]  R1180     2.2329366207122803e-01
    z[3,6,2]  R1181     -6.6694356501102448e-02
    z[3,6,2]  R1182     5.4491654038429260e-02
    z[3,6,2]  R1183     -1.0325080901384354e-01
    z[3,6,2]  R1184     -0.209682434797287
    z[3,6,2]  R1185     0.529075562953949
    z[3,6,2]  R1186     6.2065100669860840e-01
    z[3,6,2]  R1187     4.8167562484741211e-01
    z[3,6,2]  R1188     2.9683086276054382e-01
    z[3,6,2]  R1189     -1.8844637274742126e-01
    z[3,6,2]  R1190     -3.7243932485580444e-01
    z[3,6,2]  R1191     -3.0112260952591896e-02
    z[3,6,2]  R1192     -3.7173950672149658e-01
    z[3,6,2]  R1193     -2.8745934367179871e-01
    z[3,6,2]  R1194     -1.4560824632644653e-01
    z[3,6,2]  R1195     -8.7256854772567749e-01
    z[3,6,2]  R1196     -1.1744989454746246e-01
    z[3,6,2]  R1197     -4.3234601616859436e-01
    z[3,6,2]  R1198     -3.4299165010452271e-01
    z[3,6,2]  R1199     2.4135966598987579e-01
    z[3,6,2]  R1200     2.6430648565292358e-01
    z[3,6,2]  R1201     -6.6871635615825653e-02
    z[3,6,2]  R1202     -6.3241875171661377e-01
    z[3,6,2]  R1203     -3.4111383557319641e-01
    z[3,6,2]  R1204     -1.9173752516508102e-02
    z[3,6,2]  R1205     -6.3163924217224121e-01
    z[3,6,2]  R1206     -6.2527966499328613e-01
    z[3,6,2]  R1207     -1.0322622023522854e-02
    z[3,6,2]  R1208     2.7545309066772461e-01
    z[3,6,2]  R1209     -3.8440433144569397e-01
    z[3,6,2]  R1210     -2.7846693992614746e-01
    z[3,6,2]  R1211     -6.2393105030059814e-01
    z[3,6,2]  R1212     -2.9403015971183777e-01
    z[3,6,2]  R1213     -1.2160907685756683e-01
    z[3,6,2]  R1214     -2.1963237226009369e-01
    z[3,6,2]  R1215     7.1824967861175537e-02
    z[3,6,2]  R1216     4.4677847623825073e-01
    z[3,6,2]  R1217     1.7277929186820984e-01
    z[3,6,2]  R1218     2.5712689757347107e-01
    z[3,6,2]  R1219     2.8299024701118469e-01
    z[3,6,2]  R1220     -7.9229570925235748e-02
    z[3,6,2]  R1221     -0.445634663105011
    z[3,6,2]  R1222     -3.2915511727333069e-01
    z[3,6,2]  R1223     -4.6023672819137573e-01
    z[3,6,2]  R1224     -3.5719439387321472e-02
    z[3,6,2]  R1225     -9.5851331949234009e-02
    z[3,6,2]  R1226     -9.6563011407852173e-02
    z[3,6,2]  R1227     -3.4215632826089859e-02
    z[3,6,2]  R1228     6.9477267563343048e-02
    z[3,6,2]  R1229     -1.9786764681339264e-01
    z[3,6,2]  R1230     3.0728954076766968e-01
    z[3,6,2]  R1231     -3.3947271108627319e-01
    z[3,6,2]  R1232     -4.6295535564422607e-01
    z[3,6,2]  R1233     0.504423201084137
    z[3,6,2]  R1234     5.6837552785873413e-01
    z[3,6,2]  R1235     4.2655152082443237e-01
    z[3,6,2]  R1236     -4.1214738041162491e-02
    z[3,6,2]  R1237     -2.4300862848758698e-01
    z[3,6,2]  R1238     1.8729472160339355e-01
    z[3,6,2]  R1239     1.6173353791236877e-01
    z[3,6,2]  R1240     -4.1150562465190887e-02
    z[3,6,2]  R1241     8.1113819032907486e-03
    z[3,6,2]  R1242     -3.6531287431716919e-01
    z[3,6,2]  R1243     -4.5597577095031738e-01
    z[3,6,2]  R1244     2.7931693196296692e-01
    z[3,6,2]  R1245     5.2968554198741913e-02
    z[3,6,2]  R1246     -8.2593835890293121e-02
    z[3,6,2]  R1247     -7.6425760984420776e-02
    z[3,6,2]  R1248     2.7393737435340881e-01
    z[3,6,2]  R1249     4.3622571229934692e-01
    z[3,6,2]  R1250     2.5382798910140991e-01
    z[3,6,2]  R1251     5.5028963088989258e-01
    z[3,6,3]  R32       -1
    z[3,6,3]  R59       1
    z[3,6,3]  R1154     -1
    z[3,6,3]  R1155     1
    z[3,6,3]  R1162     -8.0069136619567871e-01
    z[3,6,3]  R1163     -7.5212538242340088e-01
    z[3,6,3]  R1164     -5.6111198663711548e-01
    z[3,6,3]  R1165     -0.707947850227356
    z[3,6,3]  R1166     -4.8851883411407471e-01
    z[3,6,3]  R1167     -6.5705120563507080e-01
    z[3,6,3]  R1168     -2.1463672816753387e-01
    z[3,6,3]  R1169     -1.8314115703105927e-01
    z[3,6,3]  R1170     -6.2325548380613327e-02
    z[3,6,3]  R1171     -1.2716961093246937e-02
    z[3,6,3]  R1172     -3.0760338902473450e-01
    z[3,6,3]  R1173     -9.7764588892459869e-02
    z[3,6,3]  R1174     -1.7797645926475525e-01
    z[3,6,3]  R1175     2.6678565144538879e-01
    z[3,6,3]  R1176     1.4053313434123993e-01
    z[3,6,3]  R1177     1.2276563793420792e-02
    z[3,6,3]  R1178     2.4192081391811371e-01
    z[3,6,3]  R1179     1.9215981662273407e-01
    z[3,6,3]  R1180     -8.8324718177318573e-02
    z[3,6,3]  R1181     1.2633481621742249e-01
    z[3,6,3]  R1182     -3.2013097405433655e-01
    z[3,6,3]  R1183     -4.3988779187202454e-01
    z[3,6,3]  R1184     -1.3065457344055176e-01
    z[3,6,3]  R1185     -2.9899996519088745e-01
    z[3,6,3]  R1186     3.5970035195350647e-01
    z[3,6,3]  R1187     -2.6605978608131409e-01
    z[3,6,3]  R1188     5.1785528659820557e-01
    z[3,6,3]  R1189     1.1327573657035828e-01
    z[3,6,3]  R1190     1.1653125286102295e-01
    z[3,6,3]  R1191     2.4402470886707306e-01
    z[3,6,3]  R1192     -7.0508822798728943e-02
    z[3,6,3]  R1193     9.4940230250358582e-02
    z[3,6,3]  R1194     -1.3284258544445038e-01
    z[3,6,3]  R1195     1.4472790062427521e-01
    z[3,6,3]  R1196     -1.2247978150844574e-01
    z[3,6,3]  R1197     -6.3021892309188843e-01
    z[3,6,3]  R1198     -5.4533201456069946e-01
    z[3,6,3]  R1199     -6.4684242010116577e-01
    z[3,6,3]  R1200     -4.6773397922515869e-01
    z[3,6,3]  R1201     -6.5646207332611084e-01
    z[3,6,3]  R1202     -1.6425412148237228e-02
    z[3,6,3]  R1203     -1.0423430800437927e-01
    z[3,6,3]  R1204     -3.3338627219200134e-01
    z[3,6,3]  R1205     7.8192614018917084e-02
    z[3,6,3]  R1206     -2.8088778257369995e-01
    z[3,6,3]  R1207     -6.2508940696716309e-01
    z[3,6,3]  R1208     -0.0665508434176445
    z[3,6,3]  R1209     1.7950452864170074e-01
    z[3,6,3]  R1210     -7.0398092269897461e-01
    z[3,6,3]  R1211     -2.9151913523674011e-01
    z[3,6,3]  R1212     1.3151910901069641e-01
    z[3,6,3]  R1213     6.5447628498077393e-02
    z[3,6,3]  R1214     8.8864132761955261e-02
    z[3,6,3]  R1215     -1.2790386378765106e-01
    z[3,6,3]  R1216     6.7232988774776459e-02
    z[3,6,3]  R1217     -1.0288050025701523e-01
    z[3,6,3]  R1218     2.5111887603998184e-02
    z[3,6,3]  R1219     -7.7986180782318115e-02
    z[3,6,3]  R1220     1.1262876540422440e-01
    z[3,6,3]  R1221     3.9240965247154236e-01
    z[3,6,3]  R1222     -5.7974513620138168e-03
    z[3,6,3]  R1223     3.9185520261526108e-02
    z[3,6,3]  R1224     -1.5434567630290985e-01
    z[3,6,3]  R1225     2.6429517194628716e-02
    z[3,6,3]  R1226     4.5138437300920486e-02
    z[3,6,3]  R1227     -3.9570108056068420e-01
    z[3,6,3]  R1228     -7.6664425432682037e-02
    z[3,6,3]  R1229     2.3608018457889557e-01
    z[3,6,3]  R1230     -4.5192936062812805e-01
    z[3,6,3]  R1231     1.4760474860668182e-01
    z[3,6,3]  R1232     -0.664531409740448
    z[3,6,3]  R1233     -4.9170491099357605e-01
    z[3,6,3]  R1234     -3.5445484519004822e-01
    z[3,6,3]  R1235     -2.3440995812416077e-01
    z[3,6,3]  R1236     -4.2044970393180847e-01
    z[3,6,3]  R1237     -3.7721338868141174e-01
    z[3,6,3]  R1238     -3.0410295724868774e-01
    z[3,6,3]  R1239     -3.9489173889160156e-01
    z[3,6,3]  R1240     -4.4229021668434143e-01
    z[3,6,3]  R1241     -3.4535983204841614e-01
    z[3,6,3]  R1242     -2.4242287874221802e-01
    z[3,6,3]  R1243     2.7392679452896118e-01
    z[3,6,3]  R1244     0.0804494097828865
    z[3,6,3]  R1245     -4.0220569819211960e-02
    z[3,6,3]  R1246     -5.7964015007019043e-01
    z[3,6,3]  R1247     -1.2730869650840759e-01
    z[3,6,3]  R1248     -2.5600469112396240e-01
    z[3,6,3]  R1249     -5.8702182769775391e-01
    z[3,6,3]  R1250     -4.7743275761604309e-01
    z[3,6,3]  R1251     8.0001316964626312e-02
    z[3,6,4]  R33       -1
    z[3,6,4]  R60       1
    z[3,6,4]  R1156     -1
    z[3,6,4]  R1157     1
    z[3,6,4]  R1162     -1.0060030221939087e-01
    z[3,6,4]  R1163     -3.8738641887903214e-02
    z[3,6,4]  R1164     2.9095721244812012e-01
    z[3,6,4]  R1165     -1.1915315687656403e-01
    z[3,6,4]  R1166     1.4073304831981659e-01
    z[3,6,4]  R1167     -2.3209522664546967e-01
    z[3,6,4]  R1168     8.7771266698837280e-01
    z[3,6,4]  R1169     6.1948943138122559e-01
    z[3,6,4]  R1170     1.9244116544723511e-01
    z[3,6,4]  R1171     -9.9708780646324158e-02
    z[3,6,4]  R1172     0.152165487408638
    z[3,6,4]  R1173     5.0819325447082520e-01
    z[3,6,4]  R1174     1.2793740630149841e-01
    z[3,6,4]  R1175     4.4585832953453064e-01
    z[3,6,4]  R1176     5.0892066955566406e-01
    z[3,6,4]  R1177     4.8616915941238403e-01
    z[3,6,4]  R1178     -8.8259071111679077e-01
    z[3,6,4]  R1179     0.0740782767534256
    z[3,6,4]  R1180     -0.391072154045105
    z[3,6,4]  R1181     -6.2394684553146362e-01
    z[3,6,4]  R1182     4.9257880449295044e-01
    z[3,6,4]  R1183     2.1926164627075195e-01
    z[3,6,4]  R1184     7.3666656017303467e-01
    z[3,6,4]  R1185     2.8521430492401123e-01
    z[3,6,4]  R1186     3.3822399377822876e-01
    z[3,6,4]  R1187     4.1451269388198853e-01
    z[3,6,4]  R1188     2.5579139590263367e-01
    z[3,6,4]  R1189     -2.7272635698318481e-01
    z[3,6,4]  R1190     -8.2204639911651611e-02
    z[3,6,4]  R1191     -8.7263822555541992e-01
    z[3,6,4]  R1192     6.6281452775001526e-02
    z[3,6,4]  R1193     -1.7785805463790894e-01
    z[3,6,4]  R1194     -1.5330310165882111e-01
    z[3,6,4]  R1195     2.5056928396224976e-01
    z[3,6,4]  R1196     0.855876624584198
    z[3,6,4]  R1197     4.3965995311737061e-01
    z[3,6,4]  R1198     3.1669247150421143e-01
    z[3,6,4]  R1199     4.6119195222854614e-01
    z[3,6,4]  R1200     6.9981914758682251e-01
    z[3,6,4]  R1201     -3.1441470980644226e-01
    z[3,6,4]  R1202     1.7064402997493744e-01
    z[3,6,4]  R1203     -0.20225889980793
    z[3,6,4]  R1204     -5.3948469460010529e-02
    z[3,6,4]  R1205     2.7750173211097717e-01
    z[3,6,4]  R1206     -4.5872992277145386e-01
    z[3,6,4]  R1207     -1.2366724014282227e-01
    z[3,6,4]  R1208     0.23235984146595
    z[3,6,4]  R1209     9.9264852702617645e-02
    z[3,6,4]  R1210     -5.7973209768533707e-02
    z[3,6,4]  R1211     -2.2962737828493118e-02
    z[3,6,4]  R1212     -8.6468023061752319e-01
    z[3,6,4]  R1213     -7.2321105003356934e-01
    z[3,6,4]  R1214     -7.4332869052886963e-01
    z[3,6,4]  R1215     -0.948615550994873
    z[3,6,4]  R1216     -7.4593675136566162e-01
    z[3,6,4]  R1217     -4.9432826042175293e-01
    z[3,6,4]  R1218     -0.514190673828125
    z[3,6,4]  R1219     -6.4000964164733887e-01
    z[3,6,4]  R1220     3.6670404672622681e-01
    z[3,6,4]  R1221     1.2844231724739075e-01
    z[3,6,4]  R1222     -1.9405518472194672e-01
    z[3,6,4]  R1223     -2.5099015235900879e-01
    z[3,6,4]  R1224     -1.7473381757736206e-01
    z[3,6,4]  R1225     8.3880260586738586e-02
    z[3,6,4]  R1226     -1.0158686339855194e-01
    z[3,6,4]  R1227     5.8162909746170044e-01
    z[3,6,4]  R1228     -5.7438635826110840e-01
    z[3,6,4]  R1229     -3.3861798048019409e-01
    z[3,6,4]  R1230     -9.3943439424037933e-02
    z[3,6,4]  R1231     -4.4701397418975830e-01
    z[3,6,4]  R1232     6.1733699403703213e-03
    z[3,6,4]  R1233     2.7794754132628441e-02
    z[3,6,4]  R1234     2.9193648695945740e-01
    z[3,6,4]  R1235     7.4327546358108521e-01
    z[3,6,4]  R1236     -1.4449569582939148e-01
    z[3,6,4]  R1237     -1.2018053978681564e-01
    z[3,6,4]  R1238     3.3682264387607574e-02
    z[3,6,4]  R1239     4.7047054395079613e-03
    z[3,6,4]  R1240     1.2552255392074585e-01
    z[3,6,4]  R1241     2.1860368549823761e-01
    z[3,6,4]  R1242     6.6768713295459747e-02
    z[3,6,4]  R1243     -5.4485595226287842e-01
    z[3,6,4]  R1244     3.0279141664505005e-01
    z[3,6,4]  R1245     -5.5368947982788086e-01
    z[3,6,4]  R1246     3.1811073422431946e-01
    z[3,6,4]  R1247     1.6012330353260040e-01
    z[3,6,4]  R1248     4.5743796229362488e-01
    z[3,6,4]  R1249     -4.7555733472108841e-02
    z[3,6,4]  R1250     -5.4822903126478195e-02
    z[3,6,4]  R1251     -9.4818487763404846e-02
    z[3,6,5]  R34       -1
    z[3,6,5]  R61       1
    z[3,6,5]  R1158     -1
    z[3,6,5]  R1159     1
    z[3,6,5]  R1162     -5.3799189627170563e-03
    z[3,6,5]  R1163     -1.7999008297920227e-01
    z[3,6,5]  R1164     -6.0456082224845886e-02
    z[3,6,5]  R1165     -2.2702747583389282e-01
    z[3,6,5]  R1166     1.0899110138416290e-01
    z[3,6,5]  R1167     1.0334442555904388e-01
    z[3,6,5]  R1168     -1.4412897825241089e-01
    z[3,6,5]  R1169     -1.4920921623706818e-01
    z[3,6,5]  R1170     3.5670313239097595e-01
    z[3,6,5]  R1171     5.2504038810729980e-01
    z[3,6,5]  R1172     1.7391893267631531e-01
    z[3,6,5]  R1173     -3.0043289065361023e-01
    z[3,6,5]  R1174     8.5372120141983032e-01
    z[3,6,5]  R1175     -7.6600193977355957e-01
    z[3,6,5]  R1176     -5.0599616952240467e-03
    z[3,6,5]  R1177     -4.6348902583122253e-01
    z[3,6,5]  R1178     -1.9151559472084045e-01
    z[3,6,5]  R1179     -4.5082513242959976e-02
    z[3,6,5]  R1180     -4.1748741269111633e-01
    z[3,6,5]  R1181     -7.3961865901947021e-01
    z[3,6,5]  R1182     5.6521528959274292e-01
    z[3,6,5]  R1183     6.5650010108947754e-01
    z[3,6,5]  R1184     1.3824495673179626e-01
    z[3,6,5]  R1185     -2.7003097534179688e-01
    z[3,6,5]  R1186     1.9309404492378235e-01
    z[3,6,5]  R1187     6.2927955389022827e-01
    z[3,6,5]  R1188     -0.541400671005249
    z[3,6,5]  R1189     1.4162269234657288e-01
    z[3,6,5]  R1190     -1.8363635241985321e-01
    z[3,6,5]  R1191     -2.4780270457267761e-01
    z[3,6,5]  R1192     4.8542496562004089e-01
    z[3,6,5]  R1193     1.8669515848159790e-01
    z[3,6,5]  R1194     2.8619608283042908e-01
    z[3,6,5]  R1195     7.8315190970897675e-02
    z[3,6,5]  R1196     -6.9425147958099842e-03
    z[3,6,5]  R1197     7.7991865575313568e-02
    z[3,6,5]  R1198     -5.2326135337352753e-02
    z[3,6,5]  R1199     -2.3462414741516113e-02
    z[3,6,5]  R1200     2.8280675411224365e-01
    z[3,6,5]  R1201     5.0893360376358032e-01
    z[3,6,5]  R1202     -1.3342197239398956e-01
    z[3,6,5]  R1203     0.222257599234581
    z[3,6,5]  R1204     -3.2663941383361816e-02
    z[3,6,5]  R1205     1.9224016368389130e-01
    z[3,6,5]  R1206     2.3133309185504913e-01
    z[3,6,5]  R1207     -2.0668709278106689e-01
    z[3,6,5]  R1208     1.1456321924924850e-01
    z[3,6,5]  R1209     -2.9772982001304626e-01
    z[3,6,5]  R1210     3.7308186292648315e-01
    z[3,6,5]  R1211     -9.3137592077255249e-02
    z[3,6,5]  R1212     7.0624001324176788e-02
    z[3,6,5]  R1213     -1.5758909285068512e-01
    z[3,6,5]  R1214     -1.2684494256973267e-01
    z[3,6,5]  R1215     6.4915865659713745e-02
    z[3,6,5]  R1216     1.5939299762248993e-01
    z[3,6,5]  R1217     -7.5848239660263062e-01
    z[3,6,5]  R1218     -1.8899640440940857e-01
    z[3,6,5]  R1219     -1.2374006211757660e-01
    z[3,6,5]  R1220     -3.1909587979316711e-01
    z[3,6,5]  R1221     -1.0499091446399689e-01
    z[3,6,5]  R1222     -3.4750068187713623e-01
    z[3,6,5]  R1223     3.3115780353546143e-01
    z[3,6,5]  R1224     3.2358446717262268e-01
    z[3,6,5]  R1225     -1.4920926094055176e-01
    z[3,6,5]  R1226     -8.8428817689418793e-02
    z[3,6,5]  R1227     2.8305667638778687e-01
    z[3,6,5]  R1228     -2.5510206818580627e-01
    z[3,6,5]  R1229     0.258427232503891
    z[3,6,5]  R1230     -2.9234719276428223e-01
    z[3,6,5]  R1231     -5.8472281694412231e-01
    z[3,6,5]  R1232     -1.7226114869117737e-01
    z[3,6,5]  R1233     -4.4372856616973877e-01
    z[3,6,5]  R1234     -1.9516263902187347e-01
    z[3,6,5]  R1235     -2.1163710951805115e-01
    z[3,6,5]  R1236     4.1152812540531158e-02
    z[3,6,5]  R1237     -9.7449183464050293e-02
    z[3,6,5]  R1238     -7.9647347331047058e-02
    z[3,6,5]  R1239     1.3133837282657623e-01
    z[3,6,5]  R1240     -0.0677766501903534
    z[3,6,5]  R1241     2.7804443240165710e-01
    z[3,6,5]  R1242     1.9148682057857513e-01
    z[3,6,5]  R1243     -5.7763832807540894e-01
    z[3,6,5]  R1244     1.6540817916393280e-02
    z[3,6,5]  R1245     7.1140301227569580e-01
    z[3,6,5]  R1246     -1.2283764779567719e-01
    z[3,6,5]  R1247     -1.1809009313583374e-01
    z[3,6,5]  R1248     1.6198110580444336e-01
    z[3,6,5]  R1249     -3.6141928285360336e-02
    z[3,6,5]  R1250     0.120816171169281
    z[3,6,5]  R1251     -3.4882608056068420e-01
    z[3,6,6]  R35       -1
    z[3,6,6]  R62       1
    z[3,6,6]  R1160     -1
    z[3,6,6]  R1161     1
    z[3,6,6]  R1162     2.4245367944240570e-01
    z[3,6,6]  R1163     -0.263807088136673
    z[3,6,6]  R1164     4.3939930200576782e-01
    z[3,6,6]  R1165     -2.8596135973930359e-01
    z[3,6,6]  R1166     -6.7058008909225464e-01
    z[3,6,6]  R1167     5.4611617326736450e-01
    z[3,6,6]  R1168     -1.3975061476230621e-01
    z[3,6,6]  R1169     -6.4082300662994385e-01
    z[3,6,6]  R1170     -5.0610471516847610e-02
    z[3,6,6]  R1171     5.2794121205806732e-02
    z[3,6,6]  R1172     3.0998182296752930e-01
    z[3,6,6]  R1173     5.2990466356277466e-01
    z[3,6,6]  R1174     2.9148116707801819e-01
    z[3,6,6]  R1175     2.7358356118202209e-01
    z[3,6,6]  R1176     2.9916131868958473e-02
    z[3,6,6]  R1177     -2.0614005625247955e-01
    z[3,6,6]  R1178     -2.0457790791988373e-01
    z[3,6,6]  R1179     -4.2895531654357910e-01
    z[3,6,6]  R1180     -7.6548449695110321e-02
    z[3,6,6]  R1181     -9.2601068317890167e-02
    z[3,6,6]  R1182     4.6637180447578430e-01
    z[3,6,6]  R1183     7.6529458165168762e-03
    z[3,6,6]  R1184     -1.0465058684349060e-01
    z[3,6,6]  R1185     1.9581615924835205e-02
    z[3,6,6]  R1186     3.1803071498870850e-01
    z[3,6,6]  R1187     -2.5090509653091431e-01
    z[3,6,6]  R1188     3.0006700754165649e-01
    z[3,6,6]  R1189     -2.2553144395351410e-01
    z[3,6,6]  R1190     -6.1627957969903946e-02
    z[3,6,6]  R1191     0.0999956876039505
    z[3,6,6]  R1192     -1.6562150418758392e-01
    z[3,6,6]  R1193     3.0944380164146423e-01
    z[3,6,6]  R1194     4.1285109519958496e-01
    z[3,6,6]  R1195     2.9577460885047913e-01
    z[3,6,6]  R1196     -4.3691092729568481e-01
    z[3,6,6]  R1197     4.3494582176208496e-01
    z[3,6,6]  R1198     3.9614251255989075e-01
    z[3,6,6]  R1199     3.7635970115661621e-01
    z[3,6,6]  R1200     2.9134684801101685e-01
    z[3,6,6]  R1201     1.4644193649291992e-01
    z[3,6,6]  R1202     -2.4537183344364166e-02
    z[3,6,6]  R1203     3.9565327763557434e-01
    z[3,6,6]  R1204     6.7452915012836456e-02
    z[3,6,6]  R1205     3.8119873404502869e-01
    z[3,6,6]  R1206     -1.3156446814537048e-01
    z[3,6,6]  R1207     1.5684491395950317e-01
    z[3,6,6]  R1208     1.9448937475681305e-01
    z[3,6,6]  R1209     -3.3003729581832886e-01
    z[3,6,6]  R1210     1.5036197006702423e-01
    z[3,6,6]  R1211     -6.0841190814971924e-01
    z[3,6,6]  R1212     -1.6279883682727814e-01
    z[3,6,6]  R1213     -0.532157301902771
    z[3,6,6]  R1214     -3.0267059803009033e-01
    z[3,6,6]  R1215     -0.271452397108078
    z[3,6,6]  R1216     -1.6251775622367859e-01
    z[3,6,6]  R1217     -0.173447385430336
    z[3,6,6]  R1218     -6.0873341560363770e-01
    z[3,6,6]  R1219     -4.8913916945457458e-01
    z[3,6,6]  R1220     3.9172267913818359e-01
    z[3,6,6]  R1221     3.9505439996719360e-01
    z[3,6,6]  R1222     2.2452731430530548e-01
    z[3,6,6]  R1223     -3.7836560606956482e-01
    z[3,6,6]  R1224     -3.1854078173637390e-02
    z[3,6,6]  R1225     -1.3612571358680725e-01
    z[3,6,6]  R1226     3.0483016371726990e-01
    z[3,6,6]  R1227     -5.9749286621809006e-02
    z[3,6,6]  R1228     2.6242837309837341e-01
    z[3,6,6]  R1229     0.488349974155426
    z[3,6,6]  R1230     -3.0385133624076843e-01
    z[3,6,6]  R1231     2.8920361399650574e-01
    z[3,6,6]  R1232     7.4096307158470154e-02
    z[3,6,6]  R1233     -1.4444592595100403e-01
    z[3,6,6]  R1234     -0.212275892496109
    z[3,6,6]  R1235     -4.5996572822332382e-02
    z[3,6,6]  R1236     5.4994723759591579e-03
    z[3,6,6]  R1237     1.1091116815805435e-01
    z[3,6,6]  R1238     3.0205633491277695e-02
    z[3,6,6]  R1239     -1.9873636960983276e-01
    z[3,6,6]  R1240     -2.5499787926673889e-01
    z[3,6,6]  R1241     7.2888776659965515e-02
    z[3,6,6]  R1242     -4.3196283280849457e-02
    z[3,6,6]  R1243     -2.0454345643520355e-01
    z[3,6,6]  R1244     -4.4320017099380493e-01
    z[3,6,6]  R1245     3.6286197602748871e-02
    z[3,6,6]  R1246     1.6789884865283966e-01
    z[3,6,6]  R1247     -3.1169047579169273e-02
    z[3,6,6]  R1248     -1.0007640719413757e-01
    z[3,6,6]  R1249     1.9297653436660767e-01
    z[3,6,6]  R1250     3.9162772893905640e-01
    z[3,6,6]  R1251     0.514819860458374
    z[6,3,0]  R29       1
    z[6,3,0]  R56       -1
    z[6,3,0]  R1252     -1
    z[6,3,0]  R1253     1
    z[6,3,0]  R1266     6.1276221275329590e-01
    z[6,3,0]  R1267     4.5041519403457642e-01
    z[6,3,0]  R1268     7.8865963220596313e-01
    z[6,3,0]  R1269     -2.4639409780502319e-01
    z[6,3,0]  R1270     1.6377098858356476e-02
    z[6,3,0]  R1271     -1.1627390235662460e-01
    z[6,3,0]  R1272     -4.9470996856689453e-01
    z[6,3,0]  R1273     -3.7875732779502869e-01
    z[6,3,0]  R1274     -2.3823419213294983e-01
    z[6,3,0]  R1275     -4.1410744190216064e-01
    z[6,3,0]  R1276     -3.6063289642333984e-01
    z[6,3,0]  R1277     -3.6211588978767395e-01
    z[6,3,0]  R1278     -4.6046221256256104e-01
    z[6,3,0]  R1279     1.6052266582846642e-02
    z[6,3,0]  R1280     -6.8675160408020020e-02
    z[6,3,0]  R1281     -9.4422794878482819e-02
    z[6,3,0]  R1282     -1.9267293810844421e-01
    z[6,3,0]  R1283     -2.9476154595613480e-02
    z[6,3,0]  R1284     -1.4457304775714874e-01
    z[6,3,0]  R1285     -0.0837971493601799
    z[6,3,0]  R1286     -3.1692963838577271e-01
    z[6,3,0]  R1287     -3.5143095254898071e-01
    z[6,3,0]  R1288     4.6653710305690765e-02
    z[6,3,0]  R1289     2.4943938478827477e-02
    z[6,3,0]  R1290     -4.3236187100410461e-01
    z[6,3,0]  R1291     -0.120021753013134
    z[6,3,0]  R1292     -3.5201224684715271e-01
    z[6,3,0]  R1293     4.1558140516281128e-01
    z[6,3,0]  R1294     3.8337224721908569e-01
    z[6,3,0]  R1295     1.3972762227058411e-01
    z[6,3,0]  R1296     2.0932084321975708e-01
    z[6,3,0]  R1297     6.7689009010791779e-02
    z[6,3,0]  R1298     1.3679102063179016e-01
    z[6,3,0]  R1299     -0.0431256964802742
    z[6,3,0]  R1300     1.7754010856151581e-01
    z[6,3,0]  R1301     2.9873788356781006e-02
    z[6,3,0]  R1302     -1.5065731480717659e-02
    z[6,3,0]  R1303     -1.4924864470958710e-01
    z[6,3,0]  R1304     2.8897517919540405e-01
    z[6,3,0]  R1305     3.3578014373779297e-01
    z[6,3,0]  R1306     3.3725729584693909e-01
    z[6,3,0]  R1307     4.0198189020156860e-01
    z[6,3,0]  R1308     2.9496408533304930e-03
    z[6,3,0]  R1309     2.8498345613479614e-01
    z[6,3,0]  R1310     -8.2206851243972778e-01
    z[6,3,0]  R1311     -8.2323813438415527e-01
    z[6,3,0]  R1312     -8.6341661214828491e-01
    z[6,3,0]  R1313     -8.0771315097808838e-01
    z[6,3,0]  R1314     -0.781409502029419
    z[6,3,0]  R1315     -8.3696919679641724e-01
    z[6,3,0]  R1316     6.8571992218494415e-02
    z[6,3,0]  R1317     -1.9584028422832489e-01
    z[6,3,0]  R1318     3.4353566169738770e-01
    z[6,3,0]  R1319     -4.1826122999191284e-01
    z[6,3,0]  R1320     -6.9084864854812622e-01
    z[6,3,0]  R1321     -9.3364083766937256e-01
    z[6,3,0]  R1322     -7.7485686540603638e-01
    z[6,3,0]  R1323     -6.2384098768234253e-01
    z[6,3,0]  R1324     -6.7667406797409058e-01
    z[6,3,0]  R1325     -5.3504264354705811e-01
    z[6,3,0]  R1326     2.0798969268798828e-01
    z[6,3,0]  R1327     -1.6027653217315674e-01
    z[6,3,0]  R1328     4.4577309489250183e-01
    z[6,3,0]  R1329     0.485567182302475
    z[6,3,0]  R1330     -1.2288659065961838e-01
    z[6,3,0]  R1331     3.4876942634582520e-01
    z[6,3,0]  R1332     -0.182876855134964
    z[6,3,0]  R1333     2.6595833897590637e-01
    z[6,3,0]  R1334     8.1409555673599243e-01
    z[6,3,0]  R1335     7.9661399126052856e-01
    z[6,3,0]  R1336     -7.8262883424758911e-01
    z[6,3,0]  R1337     -5.1310819387435913e-01
    z[6,3,0]  R1338     -3.4668001532554626e-01
    z[6,3,0]  R1339     2.5861239433288574e-01
    z[6,3,0]  R1340     -4.4897374510765076e-01
    z[6,3,0]  R1341     -2.0265442132949829e-01
    z[6,3,0]  R1342     8.8884755969047546e-03
    z[6,3,0]  R1343     -7.0157241821289062e-01
    z[6,3,0]  R1344     -0.680765688419342
    z[6,3,0]  R1345     -5.1564160734415054e-02
    z[6,3,0]  R1346     -2.9696670174598694e-01
    z[6,3,0]  R1347     -5.6222927570343018e-01
    z[6,3,0]  R1348     -4.8878137022256851e-02
    z[6,3,0]  R1349     3.4708552062511444e-02
    z[6,3,0]  R1350     4.5578765869140625e-01
    z[6,3,0]  R1351     2.4165239930152893e-01
    z[6,3,0]  R1352     2.3586918413639069e-01
    z[6,3,0]  R1353     8.8426578044891357e-01
    z[6,3,0]  R1354     0.896182656288147
    z[6,3,0]  R1355     -2.9889929294586182e-01
    z[6,3,1]  R30       1
    z[6,3,1]  R57       -1
    z[6,3,1]  R1254     -1
    z[6,3,1]  R1255     1
    z[6,3,1]  R1266     -4.6249288320541382e-01
    z[6,3,1]  R1267     -7.3704510927200317e-01
    z[6,3,1]  R1268     -2.5161647796630859e-01
    z[6,3,1]  R1269     2.3816816508769989e-02
    z[6,3,1]  R1270     2.1788033843040466e-01
    z[6,3,1]  R1271     1.1755845695734024e-01
    z[6,3,1]  R1272     -2.8332084417343140e-01
    z[6,3,1]  R1273     -1.5807604789733887e-01
    z[6,3,1]  R1274     -1.3992689782753587e-03
    z[6,3,1]  R1275     0.117411307990551
    z[6,3,1]  R1276     6.4976739883422852e-01
    z[6,3,1]  R1277     7.0342016220092773e-01
    z[6,3,1]  R1278     0.817271888256073
    z[6,3,1]  R1279     5.7912361621856689e-01
    z[6,3,1]  R1280     4.9411904811859131e-01
    z[6,3,1]  R1281     7.1946346759796143e-01
    z[6,3,1]  R1282     8.8183438777923584e-01
    z[6,3,1]  R1283     7.8212618827819824e-01
    z[6,3,1]  R1284     4.9071976542472839e-01
    z[6,3,1]  R1285     3.7327969074249268e-01
    z[6,3,1]  R1286     -1.2900227308273315e-01
    z[6,3,1]  R1287     1.6237090528011322e-01
    z[6,3,1]  R1288     5.3052014112472534e-01
    z[6,3,1]  R1289     9.3510001897811890e-03
    z[6,3,1]  R1290     -2.6308529078960419e-02
    z[6,3,1]  R1291     -3.0889749526977539e-01
    z[6,3,1]  R1292     -3.7239041924476624e-01
    z[6,3,1]  R1293     2.7739086747169495e-01
    z[6,3,1]  R1294     6.6657519340515137e-01
    z[6,3,1]  R1295     6.6656738519668579e-01
    z[6,3,1]  R1296     7.9936319589614868e-01
    z[6,3,1]  R1297     0.682819664478302
    z[6,3,1]  R1298     9.0550339221954346e-01
    z[6,3,1]  R1299     9.6975505352020264e-01
    z[6,3,1]  R1300     0.919813334941864
    z[6,3,1]  R1301     6.4759099483489990e-01
    z[6,3,1]  R1302     7.2470885515213013e-01
    z[6,3,1]  R1303     6.8037277460098267e-01
    z[6,3,1]  R1304     6.5666466951370239e-01
    z[6,3,1]  R1305     3.5335782170295715e-01
    z[6,3,1]  R1306     4.4173008203506470e-01
    z[6,3,1]  R1307     -3.5165590047836304e-01
    z[6,3,1]  R1308     -6.1881011724472046e-01
    z[6,3,1]  R1309     -2.8727304935455322e-01
    z[6,3,1]  R1310     -3.5088992118835449e-01
    z[6,3,1]  R1311     -2.9102388024330139e-01
    z[6,3,1]  R1312     -3.4433019161224365e-01
    z[6,3,1]  R1313     -3.2974857091903687e-01
    z[6,3,1]  R1314     -0.326667457818985
    z[6,3,1]  R1315     -2.2301189601421356e-01
    z[6,3,1]  R1316     8.7182819843292236e-01
    z[6,3,1]  R1317     -7.9527907073497772e-02
    z[6,3,1]  R1318     0.713519811630249
    z[6,3,1]  R1319     -0.0815548226237297
    z[6,3,1]  R1320     -1.8828220665454865e-01
    z[6,3,1]  R1321     -2.5633990764617920e-01
    z[6,3,1]  R1322     -1.1624956130981445e-01
    z[6,3,1]  R1323     -1.8742233514785767e-01
    z[6,3,1]  R1324     -2.8065502643585205e-01
    z[6,3,1]  R1325     -9.3812316656112671e-02
    z[6,3,1]  R1326     4.7397175431251526e-01
    z[6,3,1]  R1327     -5.1044309139251709e-01
    z[6,3,1]  R1328     1.0607351548969746e-02
    z[6,3,1]  R1329     -6.5003573894500732e-02
    z[6,3,1]  R1330     -4.2076998949050903e-01
    z[6,3,1]  R1331     3.2847024500370026e-02
    z[6,3,1]  R1332     -2.3373763263225555e-01
    z[6,3,1]  R1333     3.5103362053632736e-02
    z[6,3,1]  R1334     1.5364921092987061e-01
    z[6,3,1]  R1335     1.7687892913818359e-01
    z[6,3,1]  R1336     -1.2815099954605103e-01
    z[6,3,1]  R1337     -2.0230868831276894e-02
    z[6,3,1]  R1338     1.3132871687412262e-01
    z[6,3,1]  R1339     3.9347603917121887e-02
    z[6,3,1]  R1340     4.6784910559654236e-01
    z[6,3,1]  R1341     4.3934464454650879e-01
    z[6,3,1]  R1342     -9.8866842687129974e-02
    z[6,3,1]  R1343     5.0842958688735962e-01
    z[6,3,1]  R1344     3.8184297084808350e-01
    z[6,3,1]  R1345     1.7891910672187805e-01
    z[6,3,1]  R1346     0.16356261074543
    z[6,3,1]  R1347     2.4688905104994774e-02
    z[6,3,1]  R1348     6.0318535566329956e-01
    z[6,3,1]  R1349     -0.68907630443573
    z[6,3,1]  R1350     -1.5761137008666992e-01
    z[6,3,1]  R1351     8.9654959738254547e-02
    z[6,3,1]  R1352     -3.7349554896354675e-01
    z[6,3,1]  R1353     1.5629976987838745e-01
    z[6,3,1]  R1354     1.6974413767457008e-02
    z[6,3,1]  R1355     1.3153521716594696e-01
    z[6,3,2]  R31       1
    z[6,3,2]  R58       -1
    z[6,3,2]  R1256     -1
    z[6,3,2]  R1257     1
    z[6,3,2]  R1266     -3.7173950672149658e-01
    z[6,3,2]  R1267     -2.8745934367179871e-01
    z[6,3,2]  R1268     -1.4560824632644653e-01
    z[6,3,2]  R1269     -8.7256854772567749e-01
    z[6,3,2]  R1270     -1.1744989454746246e-01
    z[6,3,2]  R1271     -4.3234601616859436e-01
    z[6,3,2]  R1272     -3.4299165010452271e-01
    z[6,3,2]  R1273     2.4135966598987579e-01
    z[6,3,2]  R1274     2.6430648565292358e-01
    z[6,3,2]  R1275     -6.6871635615825653e-02
    z[6,3,2]  R1276     -6.3241875171661377e-01
    z[6,3,2]  R1277     -3.4111383557319641e-01
    z[6,3,2]  R1278     -1.9173752516508102e-02
    z[6,3,2]  R1279     -6.3163924217224121e-01
    z[6,3,2]  R1280     -6.2527966499328613e-01
    z[6,3,2]  R1281     -1.0322622023522854e-02
    z[6,3,2]  R1282     2.7545309066772461e-01
    z[6,3,2]  R1283     -3.8440433144569397e-01
    z[6,3,2]  R1284     -2.7846693992614746e-01
    z[6,3,2]  R1285     -6.2393105030059814e-01
    z[6,3,2]  R1286     -2.9403015971183777e-01
    z[6,3,2]  R1287     -1.2160907685756683e-01
    z[6,3,2]  R1288     -2.1963237226009369e-01
    z[6,3,2]  R1289     7.1824967861175537e-02
    z[6,3,2]  R1290     4.4677847623825073e-01
    z[6,3,2]  R1291     1.7277929186820984e-01
    z[6,3,2]  R1292     2.5712689757347107e-01
    z[6,3,2]  R1293     2.8299024701118469e-01
    z[6,3,2]  R1294     -7.9229570925235748e-02
    z[6,3,2]  R1295     -0.445634663105011
    z[6,3,2]  R1296     -3.2915511727333069e-01
    z[6,3,2]  R1297     -4.6023672819137573e-01
    z[6,3,2]  R1298     -3.5719439387321472e-02
    z[6,3,2]  R1299     -9.5851331949234009e-02
    z[6,3,2]  R1300     -9.6563011407852173e-02
    z[6,3,2]  R1301     -3.4215632826089859e-02
    z[6,3,2]  R1302     6.9477267563343048e-02
    z[6,3,2]  R1303     -1.9786764681339264e-01
    z[6,3,2]  R1304     3.0728954076766968e-01
    z[6,3,2]  R1305     -3.3947271108627319e-01
    z[6,3,2]  R1306     -4.6295535564422607e-01
    z[6,3,2]  R1307     0.504423201084137
    z[6,3,2]  R1308     5.6837552785873413e-01
    z[6,3,2]  R1309     4.2655152082443237e-01
    z[6,3,2]  R1310     -4.1214738041162491e-02
    z[6,3,2]  R1311     -2.4300862848758698e-01
    z[6,3,2]  R1312     1.8729472160339355e-01
    z[6,3,2]  R1313     1.6173353791236877e-01
    z[6,3,2]  R1314     -4.1150562465190887e-02
    z[6,3,2]  R1315     8.1113819032907486e-03
    z[6,3,2]  R1316     -3.6531287431716919e-01
    z[6,3,2]  R1317     -4.5597577095031738e-01
    z[6,3,2]  R1318     2.7931693196296692e-01
    z[6,3,2]  R1319     5.2968554198741913e-02
    z[6,3,2]  R1320     -8.2593835890293121e-02
    z[6,3,2]  R1321     -7.6425760984420776e-02
    z[6,3,2]  R1322     2.7393737435340881e-01
    z[6,3,2]  R1323     4.3622571229934692e-01
    z[6,3,2]  R1324     2.5382798910140991e-01
    z[6,3,2]  R1325     5.5028963088989258e-01
    z[6,3,2]  R1326     -1.4849710464477539e-01
    z[6,3,2]  R1327     2.1112892031669617e-01
    z[6,3,2]  R1328     4.5270791649818420e-01
    z[6,3,2]  R1329     3.3361065387725830e-01
    z[6,3,2]  R1330     2.9637560248374939e-01
    z[6,3,2]  R1331     2.8770384192466736e-01
    z[6,3,2]  R1332     2.3488526046276093e-01
    z[6,3,2]  R1333     2.7894172072410583e-01
    z[6,3,2]  R1334     -3.7805265188217163e-01
    z[6,3,2]  R1335     -2.1345199644565582e-01
    z[6,3,2]  R1336     -3.5631260275840759e-01
    z[6,3,2]  R1337     -3.1214338541030884e-01
    z[6,3,2]  R1338     2.6848953217267990e-02
    z[6,3,2]  R1339     -4.7626032028347254e-04
    z[6,3,2]  R1340     -5.4760348796844482e-01
    z[6,3,2]  R1341     -5.2161341905593872e-01
    z[6,3,2]  R1342     -2.7225714921951294e-01
    z[6,3,2]  R1343     1.4438579976558685e-01
    z[6,3,2]  R1344     2.2329366207122803e-01
    z[6,3,2]  R1345     -6.6694356501102448e-02
    z[6,3,2]  R1346     5.4491654038429260e-02
    z[6,3,2]  R1347     -1.0325080901384354e-01
    z[6,3,2]  R1348     -0.209682434797287
    z[6,3,2]  R1349     0.529075562953949
    z[6,3,2]  R1350     6.2065100669860840e-01
    z[6,3,2]  R1351     4.8167562484741211e-01
    z[6,3,2]  R1352     2.9683086276054382e-01
    z[6,3,2]  R1353     -1.8844637274742126e-01
    z[6,3,2]  R1354     -3.7243932485580444e-01
    z[6,3,2]  R1355     -3.0112260952591896e-02
    z[6,3,3]  R32       1
    z[6,3,3]  R59       -1
    z[6,3,3]  R1258     -1
    z[6,3,3]  R1259     1
    z[6,3,3]  R1266     -7.0508822798728943e-02
    z[6,3,3]  R1267     9.4940230250358582e-02
    z[6,3,3]  R1268     -1.3284258544445038e-01
    z[6,3,3]  R1269     1.4472790062427521e-01
    z[6,3,3]  R1270     -1.2247978150844574e-01
    z[6,3,3]  R1271     -6.3021892309188843e-01
    z[6,3,3]  R1272     -5.4533201456069946e-01
    z[6,3,3]  R1273     -6.4684242010116577e-01
    z[6,3,3]  R1274     -4.6773397922515869e-01
    z[6,3,3]  R1275     -6.5646207332611084e-01
    z[6,3,3]  R1276     -1.6425412148237228e-02
    z[6,3,3]  R1277     -1.0423430800437927e-01
    z[6,3,3]  R1278     -3.3338627219200134e-01
    z[6,3,3]  R1279     7.8192614018917084e-02
    z[6,3,3]  R1280     -2.8088778257369995e-01
    z[6,3,3]  R1281     -6.2508940696716309e-01
    z[6,3,3]  R1282     -0.0665508434176445
    z[6,3,3]  R1283     1.7950452864170074e-01
    z[6,3,3]  R1284     -7.0398092269897461e-01
    z[6,3,3]  R1285     -2.9151913523674011e-01
    z[6,3,3]  R1286     1.3151910901069641e-01
    z[6,3,3]  R1287     6.5447628498077393e-02
    z[6,3,3]  R1288     8.8864132761955261e-02
    z[6,3,3]  R1289     -1.2790386378765106e-01
    z[6,3,3]  R1290     6.7232988774776459e-02
    z[6,3,3]  R1291     -1.0288050025701523e-01
    z[6,3,3]  R1292     2.5111887603998184e-02
    z[6,3,3]  R1293     -7.7986180782318115e-02
    z[6,3,3]  R1294     1.1262876540422440e-01
    z[6,3,3]  R1295     3.9240965247154236e-01
    z[6,3,3]  R1296     -5.7974513620138168e-03
    z[6,3,3]  R1297     3.9185520261526108e-02
    z[6,3,3]  R1298     -1.5434567630290985e-01
    z[6,3,3]  R1299     2.6429517194628716e-02
    z[6,3,3]  R1300     4.5138437300920486e-02
    z[6,3,3]  R1301     -3.9570108056068420e-01
    z[6,3,3]  R1302     -7.6664425432682037e-02
    z[6,3,3]  R1303     2.3608018457889557e-01
    z[6,3,3]  R1304     -4.5192936062812805e-01
    z[6,3,3]  R1305     1.4760474860668182e-01
    z[6,3,3]  R1306     -0.664531409740448
    z[6,3,3]  R1307     -4.9170491099357605e-01
    z[6,3,3]  R1308     -3.5445484519004822e-01
    z[6,3,3]  R1309     -2.3440995812416077e-01
    z[6,3,3]  R1310     -4.2044970393180847e-01
    z[6,3,3]  R1311     -3.7721338868141174e-01
    z[6,3,3]  R1312     -3.0410295724868774e-01
    z[6,3,3]  R1313     -3.9489173889160156e-01
    z[6,3,3]  R1314     -4.4229021668434143e-01
    z[6,3,3]  R1315     -3.4535983204841614e-01
    z[6,3,3]  R1316     -2.4242287874221802e-01
    z[6,3,3]  R1317     2.7392679452896118e-01
    z[6,3,3]  R1318     0.0804494097828865
    z[6,3,3]  R1319     -4.0220569819211960e-02
    z[6,3,3]  R1320     -5.7964015007019043e-01
    z[6,3,3]  R1321     -1.2730869650840759e-01
    z[6,3,3]  R1322     -2.5600469112396240e-01
    z[6,3,3]  R1323     -5.8702182769775391e-01
    z[6,3,3]  R1324     -4.7743275761604309e-01
    z[6,3,3]  R1325     8.0001316964626312e-02
    z[6,3,3]  R1326     -8.0069136619567871e-01
    z[6,3,3]  R1327     -7.5212538242340088e-01
    z[6,3,3]  R1328     -5.6111198663711548e-01
    z[6,3,3]  R1329     -0.707947850227356
    z[6,3,3]  R1330     -4.8851883411407471e-01
    z[6,3,3]  R1331     -6.5705120563507080e-01
    z[6,3,3]  R1332     -2.1463672816753387e-01
    z[6,3,3]  R1333     -1.8314115703105927e-01
    z[6,3,3]  R1334     -6.2325548380613327e-02
    z[6,3,3]  R1335     -1.2716961093246937e-02
    z[6,3,3]  R1336     -3.0760338902473450e-01
    z[6,3,3]  R1337     -9.7764588892459869e-02
    z[6,3,3]  R1338     -1.7797645926475525e-01
    z[6,3,3]  R1339     2.6678565144538879e-01
    z[6,3,3]  R1340     1.4053313434123993e-01
    z[6,3,3]  R1341     1.2276563793420792e-02
    z[6,3,3]  R1342     2.4192081391811371e-01
    z[6,3,3]  R1343     1.9215981662273407e-01
    z[6,3,3]  R1344     -8.8324718177318573e-02
    z[6,3,3]  R1345     1.2633481621742249e-01
    z[6,3,3]  R1346     -3.2013097405433655e-01
    z[6,3,3]  R1347     -4.3988779187202454e-01
    z[6,3,3]  R1348     -1.3065457344055176e-01
    z[6,3,3]  R1349     -2.9899996519088745e-01
    z[6,3,3]  R1350     3.5970035195350647e-01
    z[6,3,3]  R1351     -2.6605978608131409e-01
    z[6,3,3]  R1352     5.1785528659820557e-01
    z[6,3,3]  R1353     1.1327573657035828e-01
    z[6,3,3]  R1354     1.1653125286102295e-01
    z[6,3,3]  R1355     2.4402470886707306e-01
    z[6,3,4]  R33       1
    z[6,3,4]  R60       -1
    z[6,3,4]  R1260     -1
    z[6,3,4]  R1261     1
    z[6,3,4]  R1266     6.6281452775001526e-02
    z[6,3,4]  R1267     -1.7785805463790894e-01
    z[6,3,4]  R1268     -1.5330310165882111e-01
    z[6,3,4]  R1269     2.5056928396224976e-01
    z[6,3,4]  R1270     0.855876624584198
    z[6,3,4]  R1271     4.3965995311737061e-01
    z[6,3,4]  R1272     3.1669247150421143e-01
    z[6,3,4]  R1273     4.6119195222854614e-01
    z[6,3,4]  R1274     6.9981914758682251e-01
    z[6,3,4]  R1275     -3.1441470980644226e-01
    z[6,3,4]  R1276     1.7064402997493744e-01
    z[6,3,4]  R1277     -0.20225889980793
    z[6,3,4]  R1278     -5.3948469460010529e-02
    z[6,3,4]  R1279     2.7750173211097717e-01
    z[6,3,4]  R1280     -4.5872992277145386e-01
    z[6,3,4]  R1281     -1.2366724014282227e-01
    z[6,3,4]  R1282     0.23235984146595
    z[6,3,4]  R1283     9.9264852702617645e-02
    z[6,3,4]  R1284     -5.7973209768533707e-02
    z[6,3,4]  R1285     -2.2962737828493118e-02
    z[6,3,4]  R1286     -8.6468023061752319e-01
    z[6,3,4]  R1287     -7.2321105003356934e-01
    z[6,3,4]  R1288     -7.4332869052886963e-01
    z[6,3,4]  R1289     -0.948615550994873
    z[6,3,4]  R1290     -7.4593675136566162e-01
    z[6,3,4]  R1291     -4.9432826042175293e-01
    z[6,3,4]  R1292     -0.514190673828125
    z[6,3,4]  R1293     -6.4000964164733887e-01
    z[6,3,4]  R1294     3.6670404672622681e-01
    z[6,3,4]  R1295     1.2844231724739075e-01
    z[6,3,4]  R1296     -1.9405518472194672e-01
    z[6,3,4]  R1297     -2.5099015235900879e-01
    z[6,3,4]  R1298     -1.7473381757736206e-01
    z[6,3,4]  R1299     8.3880260586738586e-02
    z[6,3,4]  R1300     -1.0158686339855194e-01
    z[6,3,4]  R1301     5.8162909746170044e-01
    z[6,3,4]  R1302     -5.7438635826110840e-01
    z[6,3,4]  R1303     -3.3861798048019409e-01
    z[6,3,4]  R1304     -9.3943439424037933e-02
    z[6,3,4]  R1305     -4.4701397418975830e-01
    z[6,3,4]  R1306     6.1733699403703213e-03
    z[6,3,4]  R1307     2.7794754132628441e-02
    z[6,3,4]  R1308     2.9193648695945740e-01
    z[6,3,4]  R1309     7.4327546358108521e-01
    z[6,3,4]  R1310     -1.4449569582939148e-01
    z[6,3,4]  R1311     -1.2018053978681564e-01
    z[6,3,4]  R1312     3.3682264387607574e-02
    z[6,3,4]  R1313     4.7047054395079613e-03
    z[6,3,4]  R1314     1.2552255392074585e-01
    z[6,3,4]  R1315     2.1860368549823761e-01
    z[6,3,4]  R1316     6.6768713295459747e-02
    z[6,3,4]  R1317     -5.4485595226287842e-01
    z[6,3,4]  R1318     3.0279141664505005e-01
    z[6,3,4]  R1319     -5.5368947982788086e-01
    z[6,3,4]  R1320     3.1811073422431946e-01
    z[6,3,4]  R1321     1.6012330353260040e-01
    z[6,3,4]  R1322     4.5743796229362488e-01
    z[6,3,4]  R1323     -4.7555733472108841e-02
    z[6,3,4]  R1324     -5.4822903126478195e-02
    z[6,3,4]  R1325     -9.4818487763404846e-02
    z[6,3,4]  R1326     -1.0060030221939087e-01
    z[6,3,4]  R1327     -3.8738641887903214e-02
    z[6,3,4]  R1328     2.9095721244812012e-01
    z[6,3,4]  R1329     -1.1915315687656403e-01
    z[6,3,4]  R1330     1.4073304831981659e-01
    z[6,3,4]  R1331     -2.3209522664546967e-01
    z[6,3,4]  R1332     8.7771266698837280e-01
    z[6,3,4]  R1333     6.1948943138122559e-01
    z[6,3,4]  R1334     1.9244116544723511e-01
    z[6,3,4]  R1335     -9.9708780646324158e-02
    z[6,3,4]  R1336     0.152165487408638
    z[6,3,4]  R1337     5.0819325447082520e-01
    z[6,3,4]  R1338     1.2793740630149841e-01
    z[6,3,4]  R1339     4.4585832953453064e-01
    z[6,3,4]  R1340     5.0892066955566406e-01
    z[6,3,4]  R1341     4.8616915941238403e-01
    z[6,3,4]  R1342     -8.8259071111679077e-01
    z[6,3,4]  R1343     0.0740782767534256
    z[6,3,4]  R1344     -0.391072154045105
    z[6,3,4]  R1345     -6.2394684553146362e-01
    z[6,3,4]  R1346     4.9257880449295044e-01
    z[6,3,4]  R1347     2.1926164627075195e-01
    z[6,3,4]  R1348     7.3666656017303467e-01
    z[6,3,4]  R1349     2.8521430492401123e-01
    z[6,3,4]  R1350     3.3822399377822876e-01
    z[6,3,4]  R1351     4.1451269388198853e-01
    z[6,3,4]  R1352     2.5579139590263367e-01
    z[6,3,4]  R1353     -2.7272635698318481e-01
    z[6,3,4]  R1354     -8.2204639911651611e-02
    z[6,3,4]  R1355     -8.7263822555541992e-01
    z[6,3,5]  R34       1
    z[6,3,5]  R61       -1
    z[6,3,5]  R1262     -1
    z[6,3,5]  R1263     1
    z[6,3,5]  R1266     4.8542496562004089e-01
    z[6,3,5]  R1267     1.8669515848159790e-01
    z[6,3,5]  R1268     2.8619608283042908e-01
    z[6,3,5]  R1269     7.8315190970897675e-02
    z[6,3,5]  R1270     -6.9425147958099842e-03
    z[6,3,5]  R1271     7.7991865575313568e-02
    z[6,3,5]  R1272     -5.2326135337352753e-02
    z[6,3,5]  R1273     -2.3462414741516113e-02
    z[6,3,5]  R1274     2.8280675411224365e-01
    z[6,3,5]  R1275     5.0893360376358032e-01
    z[6,3,5]  R1276     -1.3342197239398956e-01
    z[6,3,5]  R1277     0.222257599234581
    z[6,3,5]  R1278     -3.2663941383361816e-02
    z[6,3,5]  R1279     1.9224016368389130e-01
    z[6,3,5]  R1280     2.3133309185504913e-01
    z[6,3,5]  R1281     -2.0668709278106689e-01
    z[6,3,5]  R1282     1.1456321924924850e-01
    z[6,3,5]  R1283     -2.9772982001304626e-01
    z[6,3,5]  R1284     3.7308186292648315e-01
    z[6,3,5]  R1285     -9.3137592077255249e-02
    z[6,3,5]  R1286     7.0624001324176788e-02
    z[6,3,5]  R1287     -1.5758909285068512e-01
    z[6,3,5]  R1288     -1.2684494256973267e-01
    z[6,3,5]  R1289     6.4915865659713745e-02
    z[6,3,5]  R1290     1.5939299762248993e-01
    z[6,3,5]  R1291     -7.5848239660263062e-01
    z[6,3,5]  R1292     -1.8899640440940857e-01
    z[6,3,5]  R1293     -1.2374006211757660e-01
    z[6,3,5]  R1294     -3.1909587979316711e-01
    z[6,3,5]  R1295     -1.0499091446399689e-01
    z[6,3,5]  R1296     -3.4750068187713623e-01
    z[6,3,5]  R1297     3.3115780353546143e-01
    z[6,3,5]  R1298     3.2358446717262268e-01
    z[6,3,5]  R1299     -1.4920926094055176e-01
    z[6,3,5]  R1300     -8.8428817689418793e-02
    z[6,3,5]  R1301     2.8305667638778687e-01
    z[6,3,5]  R1302     -2.5510206818580627e-01
    z[6,3,5]  R1303     0.258427232503891
    z[6,3,5]  R1304     -2.9234719276428223e-01
    z[6,3,5]  R1305     -5.8472281694412231e-01
    z[6,3,5]  R1306     -1.7226114869117737e-01
    z[6,3,5]  R1307     -4.4372856616973877e-01
    z[6,3,5]  R1308     -1.9516263902187347e-01
    z[6,3,5]  R1309     -2.1163710951805115e-01
    z[6,3,5]  R1310     4.1152812540531158e-02
    z[6,3,5]  R1311     -9.7449183464050293e-02
    z[6,3,5]  R1312     -7.9647347331047058e-02
    z[6,3,5]  R1313     1.3133837282657623e-01
    z[6,3,5]  R1314     -0.0677766501903534
    z[6,3,5]  R1315     2.7804443240165710e-01
    z[6,3,5]  R1316     1.9148682057857513e-01
    z[6,3,5]  R1317     -5.7763832807540894e-01
    z[6,3,5]  R1318     1.6540817916393280e-02
    z[6,3,5]  R1319     7.1140301227569580e-01
    z[6,3,5]  R1320     -1.2283764779567719e-01
    z[6,3,5]  R1321     -1.1809009313583374e-01
    z[6,3,5]  R1322     1.6198110580444336e-01
    z[6,3,5]  R1323     -3.6141928285360336e-02
    z[6,3,5]  R1324     0.120816171169281
    z[6,3,5]  R1325     -3.4882608056068420e-01
    z[6,3,5]  R1326     -5.3799189627170563e-03
    z[6,3,5]  R1327     -1.7999008297920227e-01
    z[6,3,5]  R1328     -6.0456082224845886e-02
    z[6,3,5]  R1329     -2.2702747583389282e-01
    z[6,3,5]  R1330     1.0899110138416290e-01
    z[6,3,5]  R1331     1.0334442555904388e-01
    z[6,3,5]  R1332     -1.4412897825241089e-01
    z[6,3,5]  R1333     -1.4920921623706818e-01
    z[6,3,5]  R1334     3.5670313239097595e-01
    z[6,3,5]  R1335     5.2504038810729980e-01
    z[6,3,5]  R1336     1.7391893267631531e-01
    z[6,3,5]  R1337     -3.0043289065361023e-01
    z[6,3,5]  R1338     8.5372120141983032e-01
    z[6,3,5]  R1339     -7.6600193977355957e-01
    z[6,3,5]  R1340     -5.0599616952240467e-03
    z[6,3,5]  R1341     -4.6348902583122253e-01
    z[6,3,5]  R1342     -1.9151559472084045e-01
    z[6,3,5]  R1343     -4.5082513242959976e-02
    z[6,3,5]  R1344     -4.1748741269111633e-01
    z[6,3,5]  R1345     -7.3961865901947021e-01
    z[6,3,5]  R1346     5.6521528959274292e-01
    z[6,3,5]  R1347     6.5650010108947754e-01
    z[6,3,5]  R1348     1.3824495673179626e-01
    z[6,3,5]  R1349     -2.7003097534179688e-01
    z[6,3,5]  R1350     1.9309404492378235e-01
    z[6,3,5]  R1351     6.2927955389022827e-01
    z[6,3,5]  R1352     -0.541400671005249
    z[6,3,5]  R1353     1.4162269234657288e-01
    z[6,3,5]  R1354     -1.8363635241985321e-01
    z[6,3,5]  R1355     -2.4780270457267761e-01
    z[6,3,6]  R35       1
    z[6,3,6]  R62       -1
    z[6,3,6]  R1264     -1
    z[6,3,6]  R1265     1
    z[6,3,6]  R1266     -1.6562150418758392e-01
    z[6,3,6]  R1267     3.0944380164146423e-01
    z[6,3,6]  R1268     4.1285109519958496e-01
    z[6,3,6]  R1269     2.9577460885047913e-01
    z[6,3,6]  R1270     -4.3691092729568481e-01
    z[6,3,6]  R1271     4.3494582176208496e-01
    z[6,3,6]  R1272     3.9614251255989075e-01
    z[6,3,6]  R1273     3.7635970115661621e-01
    z[6,3,6]  R1274     2.9134684801101685e-01
    z[6,3,6]  R1275     1.4644193649291992e-01
    z[6,3,6]  R1276     -2.4537183344364166e-02
    z[6,3,6]  R1277     3.9565327763557434e-01
    z[6,3,6]  R1278     6.7452915012836456e-02
    z[6,3,6]  R1279     3.8119873404502869e-01
    z[6,3,6]  R1280     -1.3156446814537048e-01
    z[6,3,6]  R1281     1.5684491395950317e-01
    z[6,3,6]  R1282     1.9448937475681305e-01
    z[6,3,6]  R1283     -3.3003729581832886e-01
    z[6,3,6]  R1284     1.5036197006702423e-01
    z[6,3,6]  R1285     -6.0841190814971924e-01
    z[6,3,6]  R1286     -1.6279883682727814e-01
    z[6,3,6]  R1287     -0.532157301902771
    z[6,3,6]  R1288     -3.0267059803009033e-01
    z[6,3,6]  R1289     -0.271452397108078
    z[6,3,6]  R1290     -1.6251775622367859e-01
    z[6,3,6]  R1291     -0.173447385430336
    z[6,3,6]  R1292     -6.0873341560363770e-01
    z[6,3,6]  R1293     -4.8913916945457458e-01
    z[6,3,6]  R1294     3.9172267913818359e-01
    z[6,3,6]  R1295     3.9505439996719360e-01
    z[6,3,6]  R1296     2.2452731430530548e-01
    z[6,3,6]  R1297     -3.7836560606956482e-01
    z[6,3,6]  R1298     -3.1854078173637390e-02
    z[6,3,6]  R1299     -1.3612571358680725e-01
    z[6,3,6]  R1300     3.0483016371726990e-01
    z[6,3,6]  R1301     -5.9749286621809006e-02
    z[6,3,6]  R1302     2.6242837309837341e-01
    z[6,3,6]  R1303     0.488349974155426
    z[6,3,6]  R1304     -3.0385133624076843e-01
    z[6,3,6]  R1305     2.8920361399650574e-01
    z[6,3,6]  R1306     7.4096307158470154e-02
    z[6,3,6]  R1307     -1.4444592595100403e-01
    z[6,3,6]  R1308     -0.212275892496109
    z[6,3,6]  R1309     -4.5996572822332382e-02
    z[6,3,6]  R1310     5.4994723759591579e-03
    z[6,3,6]  R1311     1.1091116815805435e-01
    z[6,3,6]  R1312     3.0205633491277695e-02
    z[6,3,6]  R1313     -1.9873636960983276e-01
    z[6,3,6]  R1314     -2.5499787926673889e-01
    z[6,3,6]  R1315     7.2888776659965515e-02
    z[6,3,6]  R1316     -4.3196283280849457e-02
    z[6,3,6]  R1317     -2.0454345643520355e-01
    z[6,3,6]  R1318     -4.4320017099380493e-01
    z[6,3,6]  R1319     3.6286197602748871e-02
    z[6,3,6]  R1320     1.6789884865283966e-01
    z[6,3,6]  R1321     -3.1169047579169273e-02
    z[6,3,6]  R1322     -1.0007640719413757e-01
    z[6,3,6]  R1323     1.9297653436660767e-01
    z[6,3,6]  R1324     3.9162772893905640e-01
    z[6,3,6]  R1325     0.514819860458374
    z[6,3,6]  R1326     2.4245367944240570e-01
    z[6,3,6]  R1327     -0.263807088136673
    z[6,3,6]  R1328     4.3939930200576782e-01
    z[6,3,6]  R1329     -2.8596135973930359e-01
    z[6,3,6]  R1330     -6.7058008909225464e-01
    z[6,3,6]  R1331     5.4611617326736450e-01
    z[6,3,6]  R1332     -1.3975061476230621e-01
    z[6,3,6]  R1333     -6.4082300662994385e-01
    z[6,3,6]  R1334     -5.0610471516847610e-02
    z[6,3,6]  R1335     5.2794121205806732e-02
    z[6,3,6]  R1336     3.0998182296752930e-01
    z[6,3,6]  R1337     5.2990466356277466e-01
    z[6,3,6]  R1338     2.9148116707801819e-01
    z[6,3,6]  R1339     2.7358356118202209e-01
    z[6,3,6]  R1340     2.9916131868958473e-02
    z[6,3,6]  R1341     -2.0614005625247955e-01
    z[6,3,6]  R1342     -2.0457790791988373e-01
    z[6,3,6]  R1343     -4.2895531654357910e-01
    z[6,3,6]  R1344     -7.6548449695110321e-02
    z[6,3,6]  R1345     -9.2601068317890167e-02
    z[6,3,6]  R1346     4.6637180447578430e-01
    z[6,3,6]  R1347     7.6529458165168762e-03
    z[6,3,6]  R1348     -1.0465058684349060e-01
    z[6,3,6]  R1349     1.9581615924835205e-02
    z[6,3,6]  R1350     3.1803071498870850e-01
    z[6,3,6]  R1351     -2.5090509653091431e-01
    z[6,3,6]  R1352     3.0006700754165649e-01
    z[6,3,6]  R1353     -2.2553144395351410e-01
    z[6,3,6]  R1354     -6.1627957969903946e-02
    z[6,3,6]  R1355     0.0999956876039505
    z[3,7,0]  R29       -1
    z[3,7,0]  R65       1
    z[3,7,0]  R1356     -1
    z[3,7,0]  R1357     1
    z[3,7,0]  R1370     2.0798969268798828e-01
    z[3,7,0]  R1371     -1.6027653217315674e-01
    z[3,7,0]  R1372     4.4577309489250183e-01
    z[3,7,0]  R1373     0.485567182302475
    z[3,7,0]  R1374     -1.2288659065961838e-01
    z[3,7,0]  R1375     3.4876942634582520e-01
    z[3,7,0]  R1376     -0.182876855134964
    z[3,7,0]  R1377     2.6595833897590637e-01
    z[3,7,0]  R1378     8.1409555673599243e-01
    z[3,7,0]  R1379     7.9661399126052856e-01
    z[3,7,0]  R1380     -7.8262883424758911e-01
    z[3,7,0]  R1381     -5.1310819387435913e-01
    z[3,7,0]  R1382     -3.4668001532554626e-01
    z[3,7,0]  R1383     2.5861239433288574e-01
    z[3,7,0]  R1384     -4.4897374510765076e-01
    z[3,7,0]  R1385     -2.0265442132949829e-01
    z[3,7,0]  R1386     8.8884755969047546e-03
    z[3,7,0]  R1387     -7.0157241821289062e-01
    z[3,7,0]  R1388     -0.680765688419342
    z[3,7,0]  R1389     -5.1564160734415054e-02
    z[3,7,0]  R1390     -2.9696670174598694e-01
    z[3,7,0]  R1391     -5.6222927570343018e-01
    z[3,7,0]  R1392     -4.8878137022256851e-02
    z[3,7,0]  R1393     3.4708552062511444e-02
    z[3,7,0]  R1394     4.5578765869140625e-01
    z[3,7,0]  R1395     2.4165239930152893e-01
    z[3,7,0]  R1396     2.3586918413639069e-01
    z[3,7,0]  R1397     8.8426578044891357e-01
    z[3,7,0]  R1398     0.896182656288147
    z[3,7,0]  R1399     -2.9889929294586182e-01
    z[3,7,0]  R1400     4.7603544592857361e-01
    z[3,7,0]  R1401     3.6790758371353149e-01
    z[3,7,0]  R1402     4.1421744227409363e-01
    z[3,7,0]  R1403     -3.9302725344896317e-02
    z[3,7,0]  R1404     3.1200116872787476e-01
    z[3,7,0]  R1405     3.5082545876502991e-01
    z[3,7,0]  R1406     -8.3406277000904083e-02
    z[3,7,0]  R1407     5.2954941987991333e-01
    z[3,7,0]  R1408     3.5198795795440674e-01
    z[3,7,0]  R1409     0.588661253452301
    z[3,7,0]  R1410     -2.9111906886100769e-01
    z[3,7,0]  R1411     5.9338800609111786e-02
    z[3,7,0]  R1412     -1.7377567291259766e-01
    z[3,7,0]  R1413     2.0256677269935608e-01
    z[3,7,0]  R1414     -1.1065188795328140e-01
    z[3,7,0]  R1415     -8.7795235216617584e-02
    z[3,7,0]  R1416     -3.0642268061637878e-01
    z[3,7,0]  R1417     2.7552178502082825e-01
    z[3,7,0]  R1418     3.7211981415748596e-01
    z[3,7,0]  R1419     6.6856807470321655e-01
    z[3,7,0]  R1420     1.3725635409355164e-01
    z[3,7,0]  R1421     3.8982889056205750e-01
    z[3,7,0]  R1422     -0.123763807117939
    z[3,7,0]  R1423     3.7052273750305176e-01
    z[3,7,0]  R1424     4.1609662771224976e-01
    z[3,7,0]  R1425     2.5699424743652344e-01
    z[3,7,0]  R1426     4.1304844617843628e-01
    z[3,7,0]  R1427     4.1018193960189819e-01
    z[3,7,0]  R1428     -3.0694928765296936e-01
    z[3,7,0]  R1429     2.4791166186332703e-01
    z[3,7,0]  R1430     -0.0092205461114645
    z[3,7,0]  R1431     -2.7029192447662354e-01
    z[3,7,0]  R1432     1.2486063875257969e-02
    z[3,7,0]  R1433     -7.6464004814624786e-02
    z[3,7,0]  R1434     -3.1966125965118408e-01
    z[3,7,0]  R1435     -2.7544555068016052e-01
    z[3,7,0]  R1436     -4.4085282087326050e-01
    z[3,7,0]  R1437     -6.3712352514266968e-01
    z[3,7,0]  R1438     -2.3229372501373291e-01
    z[3,7,0]  R1439     5.8029163628816605e-03
    z[3,7,0]  R1440     -5.2021265029907227e-01
    z[3,7,0]  R1441     3.8525256514549255e-01
    z[3,7,0]  R1442     -3.6801743507385254e-01
    z[3,7,0]  R1443     2.2431758046150208e-01
    z[3,7,0]  R1444     1.1507070809602737e-01
    z[3,7,0]  R1445     -2.2654646635055542e-01
    z[3,7,0]  R1446     8.1596441566944122e-02
    z[3,7,0]  R1447     1.6711363196372986e-01
    z[3,7,0]  R1448     -8.7778925895690918e-01
    z[3,7,0]  R1449     -8.5311925411224365e-01
    z[3,7,1]  R30       -1
    z[3,7,1]  R66       1
    z[3,7,1]  R1358     -1
    z[3,7,1]  R1359     1
    z[3,7,1]  R1370     4.7397175431251526e-01
    z[3,7,1]  R1371     -5.1044309139251709e-01
    z[3,7,1]  R1372     1.0607351548969746e-02
    z[3,7,1]  R1373     -6.5003573894500732e-02
    z[3,7,1]  R1374     -4.2076998949050903e-01
    z[3,7,1]  R1375     3.2847024500370026e-02
    z[3,7,1]  R1376     -2.3373763263225555e-01
    z[3,7,1]  R1377     3.5103362053632736e-02
    z[3,7,1]  R1378     1.5364921092987061e-01
    z[3,7,1]  R1379     1.7687892913818359e-01
    z[3,7,1]  R1380     -1.2815099954605103e-01
    z[3,7,1]  R1381     -2.0230868831276894e-02
    z[3,7,1]  R1382     1.3132871687412262e-01
    z[3,7,1]  R1383     3.9347603917121887e-02
    z[3,7,1]  R1384     4.6784910559654236e-01
    z[3,7,1]  R1385     4.3934464454650879e-01
    z[3,7,1]  R1386     -9.8866842687129974e-02
    z[3,7,1]  R1387     5.0842958688735962e-01
    z[3,7,1]  R1388     3.8184297084808350e-01
    z[3,7,1]  R1389     1.7891910672187805e-01
    z[3,7,1]  R1390     0.16356261074543
    z[3,7,1]  R1391     2.4688905104994774e-02
    z[3,7,1]  R1392     6.0318535566329956e-01
    z[3,7,1]  R1393     -0.68907630443573
    z[3,7,1]  R1394     -1.5761137008666992e-01
    z[3,7,1]  R1395     8.9654959738254547e-02
    z[3,7,1]  R1396     -3.7349554896354675e-01
    z[3,7,1]  R1397     1.5629976987838745e-01
    z[3,7,1]  R1398     1.6974413767457008e-02
    z[3,7,1]  R1399     1.3153521716594696e-01
    z[3,7,1]  R1400     -1.0660460591316223e-01
    z[3,7,1]  R1401     -1.2077955156564713e-01
    z[3,7,1]  R1402     -2.0885924994945526e-01
    z[3,7,1]  R1403     -5.9599387645721436e-01
    z[3,7,1]  R1404     -2.4721232056617737e-01
    z[3,7,1]  R1405     -2.8906211256980896e-01
    z[3,7,1]  R1406     -4.9694183468818665e-01
    z[3,7,1]  R1407     -4.0280455350875854e-01
    z[3,7,1]  R1408     -2.8144043684005737e-01
    z[3,7,1]  R1409     -5.1659953594207764e-01
    z[3,7,1]  R1410     -1.8781755119562149e-02
    z[3,7,1]  R1411     2.2174131870269775e-01
    z[3,7,1]  R1412     1.6783127188682556e-01
    z[3,7,1]  R1413     -3.4644204378128052e-01
    z[3,7,1]  R1414     1.6638845205307007e-01
    z[3,7,1]  R1415     3.4050557017326355e-01
    z[3,7,1]  R1416     8.4921658039093018e-01
    z[3,7,1]  R1417     -5.4452598094940186e-02
    z[3,7,1]  R1418     5.2231132984161377e-02
    z[3,7,1]  R1419     0.0165800079703331
    z[3,7,1]  R1420     8.6523312330245972e-01
    z[3,7,1]  R1421     0.849455714225769
    z[3,7,1]  R1422     8.3081424236297607e-01
    z[3,7,1]  R1423     7.5549054145812988e-01
    z[3,7,1]  R1424     6.9476801156997681e-01
    z[3,7,1]  R1425     7.0348227024078369e-01
    z[3,7,1]  R1426     6.7879295349121094e-01
    z[3,7,1]  R1427     6.7431765794754028e-01
    z[3,7,1]  R1428     0.812117338180542
    z[3,7,1]  R1429     6.5174585580825806e-01
    z[3,7,1]  R1430     0.875145673751831
    z[3,7,1]  R1431     7.7661645412445068e-01
    z[3,7,1]  R1432     3.3691346645355225e-01
    z[3,7,1]  R1433     -1.3373208045959473e-01
    z[3,7,1]  R1434     2.1163500845432281e-01
    z[3,7,1]  R1435     1.4521718025207520e-01
    z[3,7,1]  R1436     2.0001755654811859e-01
    z[3,7,1]  R1437     -1.7763268947601318e-01
    z[3,7,1]  R1438     -4.1447395086288452e-01
    z[3,7,1]  R1439     3.2233405113220215e-01
    z[3,7,1]  R1440     -1.6980348154902458e-02
    z[3,7,1]  R1441     6.8088221549987793e-01
    z[3,7,1]  R1442     1.2809453904628754e-01
    z[3,7,1]  R1443     -3.7579932808876038e-01
    z[3,7,1]  R1444     -7.0018756389617920e-01
    z[3,7,1]  R1445     3.0431863665580750e-01
    z[3,7,1]  R1446     -4.0260177105665207e-02
    z[3,7,1]  R1447     -2.2124862670898438e-01
    z[3,7,1]  R1448     1.3861157000064850e-01
    z[3,7,1]  R1449     2.3196747526526451e-02
    z[3,7,2]  R31       -1
    z[3,7,2]  R67       1
    z[3,7,2]  R1360     -1
    z[3,7,2]  R1361     1
    z[3,7,2]  R1370     -1.4849710464477539e-01
    z[3,7,2]  R1371     2.1112892031669617e-01
    z[3,7,2]  R1372     4.5270791649818420e-01
    z[3,7,2]  R1373     3.3361065387725830e-01
    z[3,7,2]  R1374     2.9637560248374939e-01
    z[3,7,2]  R1375     2.8770384192466736e-01
    z[3,7,2]  R1376     2.3488526046276093e-01
    z[3,7,2]  R1377     2.7894172072410583e-01
    z[3,7,2]  R1378     -3.7805265188217163e-01
    z[3,7,2]  R1379     -2.1345199644565582e-01
    z[3,7,2]  R1380     -3.5631260275840759e-01
    z[3,7,2]  R1381     -3.1214338541030884e-01
    z[3,7,2]  R1382     2.6848953217267990e-02
    z[3,7,2]  R1383     -4.7626032028347254e-04
    z[3,7,2]  R1384     -5.4760348796844482e-01
    z[3,7,2]  R1385     -5.2161341905593872e-01
    z[3,7,2]  R1386     -2.7225714921951294e-01
    z[3,7,2]  R1387     1.4438579976558685e-01
    z[3,7,2]  R1388     2.2329366207122803e-01
    z[3,7,2]  R1389     -6.6694356501102448e-02
    z[3,7,2]  R1390     5.4491654038429260e-02
    z[3,7,2]  R1391     -1.0325080901384354e-01
    z[3,7,2]  R1392     -0.209682434797287
    z[3,7,2]  R1393     0.529075562953949
    z[3,7,2]  R1394     6.2065100669860840e-01
    z[3,7,2]  R1395     4.8167562484741211e-01
    z[3,7,2]  R1396     2.9683086276054382e-01
    z[3,7,2]  R1397     -1.8844637274742126e-01
    z[3,7,2]  R1398     -3.7243932485580444e-01
    z[3,7,2]  R1399     -3.0112260952591896e-02
    z[3,7,2]  R1400     -2.4987235665321350e-01
    z[3,7,2]  R1401     8.0049097537994385e-02
    z[3,7,2]  R1402     -2.3241643607616425e-01
    z[3,7,2]  R1403     -5.9219084680080414e-02
    z[3,7,2]  R1404     -1.5208722651004791e-01
    z[3,7,2]  R1405     -3.8834550976753235e-01
    z[3,7,2]  R1406     1.2844204902648926e-01
    z[3,7,2]  R1407     7.9727783799171448e-02
    z[3,7,2]  R1408     -3.1406372785568237e-01
    z[3,7,2]  R1409     -2.2537735104560852e-01
    z[3,7,2]  R1410     3.1608071923255920e-01
    z[3,7,2]  R1411     0.568540096282959
    z[3,7,2]  R1412     -1.6008764505386353e-01
    z[3,7,2]  R1413     6.4011670649051666e-02
    z[3,7,2]  R1414     1.6753885149955750e-01
    z[3,7,2]  R1415     -2.5317856669425964e-01
    z[3,7,2]  R1416     5.0702389329671860e-02
    z[3,7,2]  R1417     -3.5285180807113647e-01
    z[3,7,2]  R1418     2.7158821467310190e-03
    z[3,7,2]  R1419     1.0803978657349944e-03
    z[3,7,2]  R1420     -1.3204509019851685e-01
    z[3,7,2]  R1421     -2.4696128070354462e-01
    z[3,7,2]  R1422     1.7244906723499298e-01
    z[3,7,2]  R1423     -6.4365096390247345e-02
    z[3,7,2]  R1424     1.3435410801321268e-03
    z[3,7,2]  R1425     2.3369173705577850e-01
    z[3,7,2]  R1426     -2.3711295425891876e-01
    z[3,7,2]  R1427     4.8450350761413574e-01
    z[3,7,2]  R1428     -4.2923524975776672e-01
    z[3,7,2]  R1429     3.4046009182929993e-01
    z[3,7,2]  R1430     6.1573632061481476e-02
    z[3,7,2]  R1431     -3.5468775033950806e-01
    z[3,7,2]  R1432     6.7794602364301682e-03
    z[3,7,2]  R1433     -7.6889827847480774e-02
    z[3,7,2]  R1434     8.4859818220138550e-02
    z[3,7,2]  R1435     -2.2711716592311859e-01
    z[3,7,2]  R1436     -2.6905193924903870e-01
    z[3,7,2]  R1437     -4.9347379803657532e-01
    z[3,7,2]  R1438     -3.0910629034042358e-01
    z[3,7,2]  R1439     -0.624438464641571
    z[3,7,2]  R1440     -3.9014685153961182e-01
    z[3,7,2]  R1441     3.2838678359985352e-01
    z[3,7,2]  R1442     -6.5237575769424438e-01
    z[3,7,2]  R1443     -2.1648381650447845e-01
    z[3,7,2]  R1444     6.9230437278747559e-02
    z[3,7,2]  R1445     -8.0624055862426758e-01
    z[3,7,2]  R1446     -0.617302417755127
    z[3,7,2]  R1447     -0.723918616771698
    z[3,7,2]  R1448     4.9001105129718781e-02
    z[3,7,2]  R1449     -3.2605963945388794e-01
    z[3,7,3]  R32       -1
    z[3,7,3]  R68       1
    z[3,7,3]  R1362     -1
    z[3,7,3]  R1363     1
    z[3,7,3]  R1370     -8.0069136619567871e-01
    z[3,7,3]  R1371     -7.5212538242340088e-01
    z[3,7,3]  R1372     -5.6111198663711548e-01
    z[3,7,3]  R1373     -0.707947850227356
    z[3,7,3]  R1374     -4.8851883411407471e-01
    z[3,7,3]  R1375     -6.5705120563507080e-01
    z[3,7,3]  R1376     -2.1463672816753387e-01
    z[3,7,3]  R1377     -1.8314115703105927e-01
    z[3,7,3]  R1378     -6.2325548380613327e-02
    z[3,7,3]  R1379     -1.2716961093246937e-02
    z[3,7,3]  R1380     -3.0760338902473450e-01
    z[3,7,3]  R1381     -9.7764588892459869e-02
    z[3,7,3]  R1382     -1.7797645926475525e-01
    z[3,7,3]  R1383     2.6678565144538879e-01
    z[3,7,3]  R1384     1.4053313434123993e-01
    z[3,7,3]  R1385     1.2276563793420792e-02
    z[3,7,3]  R1386     2.4192081391811371e-01
    z[3,7,3]  R1387     1.9215981662273407e-01
    z[3,7,3]  R1388     -8.8324718177318573e-02
    z[3,7,3]  R1389     1.2633481621742249e-01
    z[3,7,3]  R1390     -3.2013097405433655e-01
    z[3,7,3]  R1391     -4.3988779187202454e-01
    z[3,7,3]  R1392     -1.3065457344055176e-01
    z[3,7,3]  R1393     -2.9899996519088745e-01
    z[3,7,3]  R1394     3.5970035195350647e-01
    z[3,7,3]  R1395     -2.6605978608131409e-01
    z[3,7,3]  R1396     5.1785528659820557e-01
    z[3,7,3]  R1397     1.1327573657035828e-01
    z[3,7,3]  R1398     1.1653125286102295e-01
    z[3,7,3]  R1399     2.4402470886707306e-01
    z[3,7,3]  R1400     -6.7224484682083130e-01
    z[3,7,3]  R1401     -7.0029366016387939e-01
    z[3,7,3]  R1402     -6.1937773227691650e-01
    z[3,7,3]  R1403     -7.1388387680053711e-01
    z[3,7,3]  R1404     -4.9720174074172974e-01
    z[3,7,3]  R1405     -6.4908200502395630e-01
    z[3,7,3]  R1406     -5.3357076644897461e-01
    z[3,7,3]  R1407     -7.3130798339843750e-01
    z[3,7,3]  R1408     -6.9445818662643433e-01
    z[3,7,3]  R1409     -5.0333750247955322e-01
    z[3,7,3]  R1410     8.9732266962528229e-02
    z[3,7,3]  R1411     9.4804614782333374e-02
    z[3,7,3]  R1412     1.2280047684907913e-01
    z[3,7,3]  R1413     -5.7932874187827110e-03
    z[3,7,3]  R1414     3.1909137964248657e-02
    z[3,7,3]  R1415     2.1057588979601860e-02
    z[3,7,3]  R1416     -3.4516620635986328e-01
    z[3,7,3]  R1417     8.7836936116218567e-02
    z[3,7,3]  R1418     2.9434330761432648e-02
    z[3,7,3]  R1419     4.8773370683193207e-02
    z[3,7,3]  R1420     -3.7065398693084717e-01
    z[3,7,3]  R1421     -1.7758302390575409e-01
    z[3,7,3]  R1422     2.2660417854785919e-01
    z[3,7,3]  R1423     1.2246348708868027e-01
    z[3,7,3]  R1424     -4.3347876518964767e-02
    z[3,7,3]  R1425     2.0179098471999168e-02
    z[3,7,3]  R1426     1.2138762325048447e-01
    z[3,7,3]  R1427     -8.3573527634143829e-02
    z[3,7,3]  R1428     1.6214302182197571e-01
    z[3,7,3]  R1429     -5.3740464150905609e-02
    z[3,7,3]  R1430     1.3159784674644470e-01
    z[3,7,3]  R1431     -2.7779016643762589e-02
    z[3,7,3]  R1432     -4.5293146371841431e-01
    z[3,7,3]  R1433     -9.1966682672500610e-01
    z[3,7,3]  R1434     -8.2189255952835083e-01
    z[3,7,3]  R1435     -7.0442509651184082e-01
    z[3,7,3]  R1436     -3.1061306595802307e-01
    z[3,7,3]  R1437     -1.7593665421009064e-01
    z[3,7,3]  R1438     1.3717627525329590e-01
    z[3,7,3]  R1439     -3.4871584177017212e-01
    z[3,7,3]  R1440     -0.436395525932312
    z[3,7,3]  R1441     1.4738725125789642e-01
    z[3,7,3]  R1442     -3.3101609349250793e-01
    z[3,7,3]  R1443     -6.1580508947372437e-01
    z[3,7,3]  R1444     -5.5146604776382446e-01
    z[3,7,3]  R1445     -3.0081382393836975e-01
    z[3,7,3]  R1446     1.3018840551376343e-01
    z[3,7,3]  R1447     1.2936544418334961e-01
    z[3,7,3]  R1448     3.0576642602682114e-02
    z[3,7,3]  R1449     -1.2606064788997173e-02
    z[3,7,4]  R33       -1
    z[3,7,4]  R69       1
    z[3,7,4]  R1364     -1
    z[3,7,4]  R1365     1
    z[3,7,4]  R1370     -1.0060030221939087e-01
    z[3,7,4]  R1371     -3.8738641887903214e-02
    z[3,7,4]  R1372     2.9095721244812012e-01
    z[3,7,4]  R1373     -1.1915315687656403e-01
    z[3,7,4]  R1374     1.4073304831981659e-01
    z[3,7,4]  R1375     -2.3209522664546967e-01
    z[3,7,4]  R1376     8.7771266698837280e-01
    z[3,7,4]  R1377     6.1948943138122559e-01
    z[3,7,4]  R1378     1.9244116544723511e-01
    z[3,7,4]  R1379     -9.9708780646324158e-02
    z[3,7,4]  R1380     0.152165487408638
    z[3,7,4]  R1381     5.0819325447082520e-01
    z[3,7,4]  R1382     1.2793740630149841e-01
    z[3,7,4]  R1383     4.4585832953453064e-01
    z[3,7,4]  R1384     5.0892066955566406e-01
    z[3,7,4]  R1385     4.8616915941238403e-01
    z[3,7,4]  R1386     -8.8259071111679077e-01
    z[3,7,4]  R1387     0.0740782767534256
    z[3,7,4]  R1388     -0.391072154045105
    z[3,7,4]  R1389     -6.2394684553146362e-01
    z[3,7,4]  R1390     4.9257880449295044e-01
    z[3,7,4]  R1391     2.1926164627075195e-01
    z[3,7,4]  R1392     7.3666656017303467e-01
    z[3,7,4]  R1393     2.8521430492401123e-01
    z[3,7,4]  R1394     3.3822399377822876e-01
    z[3,7,4]  R1395     4.1451269388198853e-01
    z[3,7,4]  R1396     2.5579139590263367e-01
    z[3,7,4]  R1397     -2.7272635698318481e-01
    z[3,7,4]  R1398     -8.2204639911651611e-02
    z[3,7,4]  R1399     -8.7263822555541992e-01
    z[3,7,4]  R1400     2.4950763583183289e-01
    z[3,7,4]  R1401     3.3191773295402527e-01
    z[3,7,4]  R1402     5.4609251022338867e-01
    z[3,7,4]  R1403     3.4516081213951111e-01
    z[3,7,4]  R1404     6.8939322233200073e-01
    z[3,7,4]  R1405     3.4546619653701782e-01
    z[3,7,4]  R1406     0.305010050535202
    z[3,7,4]  R1407     3.4637738019227982e-02
    z[3,7,4]  R1408     -1.0367469489574432e-01
    z[3,7,4]  R1409     5.8627333492040634e-02
    z[3,7,4]  R1410     -8.0068618059158325e-01
    z[3,7,4]  R1411     -6.6231417655944824e-01
    z[3,7,4]  R1412     -9.4892930984497070e-01
    z[3,7,4]  R1413     -8.8086354732513428e-01
    z[3,7,4]  R1414     -8.6299884319305420e-01
    z[3,7,4]  R1415     -7.6170092821121216e-01
    z[3,7,4]  R1416     1.0170640423893929e-02
    z[3,7,4]  R1417     -6.8199980258941650e-01
    z[3,7,4]  R1418     -6.5378212928771973e-01
    z[3,7,4]  R1419     -6.9943392276763916e-01
    z[3,7,4]  R1420     2.3832754790782928e-01
    z[3,7,4]  R1421     -1.8893703818321228e-02
    z[3,7,4]  R1422     -1.6697883605957031e-01
    z[3,7,4]  R1423     -3.8166046142578125e-01
    z[3,7,4]  R1424     -1.1869627982378006e-01
    z[3,7,4]  R1425     4.3013298511505127e-01
    z[3,7,4]  R1426     -2.4247787892818451e-01
    z[3,7,4]  R1427     -0.0239796731621027
    z[3,7,4]  R1428     -2.1718394011259079e-02
    z[3,7,4]  R1429     2.4207362532615662e-01
    z[3,7,4]  R1430     -1.6972647607326508e-01
    z[3,7,4]  R1431     -3.5508543252944946e-01
    z[3,7,4]  R1432     4.5013442635536194e-01
    z[3,7,4]  R1433     -2.9802310466766357e-01
    z[3,7,4]  R1434     -1.7271572351455688e-01
    z[3,7,4]  R1435     -5.0280994176864624e-01
    z[3,7,4]  R1436     -2.2354270517826080e-01
    z[3,7,4]  R1437     2.9778888821601868e-01
    z[3,7,4]  R1438     -3.0977034568786621e-01
    z[3,7,4]  R1439     -1.1161712557077408e-01
    z[3,7,4]  R1440     1.7979015409946442e-01
    z[3,7,4]  R1441     2.1449477970600128e-01
    z[3,7,4]  R1442     -1.2893806397914886e-01
    z[3,7,4]  R1443     -3.8652592897415161e-01
    z[3,7,4]  R1444     -7.7593587338924408e-02
    z[3,7,4]  R1445     2.7747648954391479e-01
    z[3,7,4]  R1446     -2.9270559549331665e-01
    z[3,7,4]  R1447     -2.2900177538394928e-01
    z[3,7,4]  R1448     7.7248387038707733e-02
    z[3,7,4]  R1449     1.1837456375360489e-02
    z[3,7,5]  R34       -1
    z[3,7,5]  R70       1
    z[3,7,5]  R1366     -1
    z[3,7,5]  R1367     1
    z[3,7,5]  R1370     -5.3799189627170563e-03
    z[3,7,5]  R1371     -1.7999008297920227e-01
    z[3,7,5]  R1372     -6.0456082224845886e-02
    z[3,7,5]  R1373     -2.2702747583389282e-01
    z[3,7,5]  R1374     1.0899110138416290e-01
    z[3,7,5]  R1375     1.0334442555904388e-01
    z[3,7,5]  R1376     -1.4412897825241089e-01
    z[3,7,5]  R1377     -1.4920921623706818e-01
    z[3,7,5]  R1378     3.5670313239097595e-01
    z[3,7,5]  R1379     5.2504038810729980e-01
    z[3,7,5]  R1380     1.7391893267631531e-01
    z[3,7,5]  R1381     -3.0043289065361023e-01
    z[3,7,5]  R1382     8.5372120141983032e-01
    z[3,7,5]  R1383     -7.6600193977355957e-01
    z[3,7,5]  R1384     -5.0599616952240467e-03
    z[3,7,5]  R1385     -4.6348902583122253e-01
    z[3,7,5]  R1386     -1.9151559472084045e-01
    z[3,7,5]  R1387     -4.5082513242959976e-02
    z[3,7,5]  R1388     -4.1748741269111633e-01
    z[3,7,5]  R1389     -7.3961865901947021e-01
    z[3,7,5]  R1390     5.6521528959274292e-01
    z[3,7,5]  R1391     6.5650010108947754e-01
    z[3,7,5]  R1392     1.3824495673179626e-01
    z[3,7,5]  R1393     -2.7003097534179688e-01
    z[3,7,5]  R1394     1.9309404492378235e-01
    z[3,7,5]  R1395     6.2927955389022827e-01
    z[3,7,5]  R1396     -0.541400671005249
    z[3,7,5]  R1397     1.4162269234657288e-01
    z[3,7,5]  R1398     -1.8363635241985321e-01
    z[3,7,5]  R1399     -2.4780270457267761e-01
    z[3,7,5]  R1400     4.2622053623199463e-01
    z[3,7,5]  R1401     4.2791518568992615e-01
    z[3,7,5]  R1402     1.8242482841014862e-01
    z[3,7,5]  R1403     7.0057839155197144e-02
    z[3,7,5]  R1404     2.5204014778137207e-01
    z[3,7,5]  R1405     7.7326498925685883e-02
    z[3,7,5]  R1406     4.1740727424621582e-01
    z[3,7,5]  R1407     1.1308895796537399e-01
    z[3,7,5]  R1408     2.7069875970482826e-02
    z[3,7,5]  R1409     1.0098073631525040e-02
    z[3,7,5]  R1410     -1.9162584841251373e-01
    z[3,7,5]  R1411     -0.361482709646225
    z[3,7,5]  R1412     -2.1384628489613533e-02
    z[3,7,5]  R1413     -2.3538470268249512e-01
    z[3,7,5]  R1414     -2.2064080834388733e-01
    z[3,7,5]  R1415     -2.3851794004440308e-01
    z[3,7,5]  R1416     3.5427961498498917e-02
    z[3,7,5]  R1417     -2.8092318773269653e-01
    z[3,7,5]  R1418     -2.4708215892314911e-01
    z[3,7,5]  R1419     -1.2099565565586090e-01
    z[3,7,5]  R1420     -1.0895001702010632e-02
    z[3,7,5]  R1421     9.1795986518263817e-03
    z[3,7,5]  R1422     4.2843386530876160e-01
    z[3,7,5]  R1423     2.8480908274650574e-01
    z[3,7,5]  R1424     -1.3585822284221649e-01
    z[3,7,5]  R1425     3.5807177424430847e-01
    z[3,7,5]  R1426     4.4925898313522339e-01
    z[3,7,5]  R1427     2.3420919477939606e-01
    z[3,7,5]  R1428     -3.2690837979316711e-02
    z[3,7,5]  R1429     -4.3979048728942871e-01
    z[3,7,5]  R1430     -0.383866548538208
    z[3,7,5]  R1431     1.1409801244735718e-01
    z[3,7,5]  R1432     6.3329619169235229e-01
    z[3,7,5]  R1433     1.0092271864414215e-01
    z[3,7,5]  R1434     2.1092095971107483e-01
    z[3,7,5]  R1435     3.1188043951988220e-01
    z[3,7,5]  R1436     5.7301986217498779e-01
    z[3,7,5]  R1437     2.9715502262115479e-01
    z[3,7,5]  R1438     -0.68267822265625
    z[3,7,5]  R1439     2.9752397537231445e-01
    z[3,7,5]  R1440     5.5984055995941162e-01
    z[3,7,5]  R1441     4.4256573915481567e-01
    z[3,7,5]  R1442     3.0589541792869568e-01
    z[3,7,5]  R1443     8.0975212156772614e-02
    z[3,7,5]  R1444     -4.2513221502304077e-01
    z[3,7,5]  R1445     -1.5970150008797646e-02
    z[3,7,5]  R1446     -0.633258044719696
    z[3,7,5]  R1447     -5.6956237554550171e-01
    z[3,7,5]  R1448     -4.2983183264732361e-01
    z[3,7,5]  R1449     -3.4924387931823730e-01
    z[3,7,6]  R35       -1
    z[3,7,6]  R71       1
    z[3,7,6]  R1368     -1
    z[3,7,6]  R1369     1
    z[3,7,6]  R1370     2.4245367944240570e-01
    z[3,7,6]  R1371     -0.263807088136673
    z[3,7,6]  R1372     4.3939930200576782e-01
    z[3,7,6]  R1373     -2.8596135973930359e-01
    z[3,7,6]  R1374     -6.7058008909225464e-01
    z[3,7,6]  R1375     5.4611617326736450e-01
    z[3,7,6]  R1376     -1.3975061476230621e-01
    z[3,7,6]  R1377     -6.4082300662994385e-01
    z[3,7,6]  R1378     -5.0610471516847610e-02
    z[3,7,6]  R1379     5.2794121205806732e-02
    z[3,7,6]  R1380     3.0998182296752930e-01
    z[3,7,6]  R1381     5.2990466356277466e-01
    z[3,7,6]  R1382     2.9148116707801819e-01
    z[3,7,6]  R1383     2.7358356118202209e-01
    z[3,7,6]  R1384     2.9916131868958473e-02
    z[3,7,6]  R1385     -2.0614005625247955e-01
    z[3,7,6]  R1386     -2.0457790791988373e-01
    z[3,7,6]  R1387     -4.2895531654357910e-01
    z[3,7,6]  R1388     -7.6548449695110321e-02
    z[3,7,6]  R1389     -9.2601068317890167e-02
    z[3,7,6]  R1390     4.6637180447578430e-01
    z[3,7,6]  R1391     7.6529458165168762e-03
    z[3,7,6]  R1392     -1.0465058684349060e-01
    z[3,7,6]  R1393     1.9581615924835205e-02
    z[3,7,6]  R1394     3.1803071498870850e-01
    z[3,7,6]  R1395     -2.5090509653091431e-01
    z[3,7,6]  R1396     3.0006700754165649e-01
    z[3,7,6]  R1397     -2.2553144395351410e-01
    z[3,7,6]  R1398     -6.1627957969903946e-02
    z[3,7,6]  R1399     0.0999956876039505
    z[3,7,6]  R1400     -6.1305873095989227e-02
    z[3,7,6]  R1401     2.4486029148101807e-01
    z[3,7,6]  R1402     1.2513917684555054e-01
    z[3,7,6]  R1403     0.0778806284070015
    z[3,7,6]  R1404     -1.8003915250301361e-01
    z[3,7,6]  R1405     -3.0970746278762817e-01
    z[3,7,6]  R1406     -4.2147025465965271e-01
    z[3,7,6]  R1407     4.6574071049690247e-02
    z[3,7,6]  R1408     4.5222377777099609e-01
    z[3,7,6]  R1409     2.8092715144157410e-01
    z[3,7,6]  R1410     -3.5933154821395874e-01
    z[3,7,6]  R1411     -2.1390192210674286e-01
    z[3,7,6]  R1412     1.5885165194049478e-03
    z[3,7,6]  R1413     5.9050343930721283e-02
    z[3,7,6]  R1414     3.7085619568824768e-01
    z[3,7,6]  R1415     -4.1800227761268616e-01
    z[3,7,6]  R1416     2.4873162806034088e-01
    z[3,7,6]  R1417     -4.9483460187911987e-01
    z[3,7,6]  R1418     -6.0781919956207275e-01
    z[3,7,6]  R1419     -2.1567137539386749e-01
    z[3,7,6]  R1420     -1.4419928193092346e-01
    z[3,7,6]  R1421     -1.8300722539424896e-01
    z[3,7,6]  R1422     -4.3642383068799973e-02
    z[3,7,6]  R1423     -2.1453650295734406e-01
    z[3,7,6]  R1424     5.5653733015060425e-01
    z[3,7,6]  R1425     -2.6611623167991638e-01
    z[3,7,6]  R1426     1.9246926903724670e-01
    z[3,7,6]  R1427     2.8264707326889038e-01
    z[3,7,6]  R1428     -1.8486200273036957e-01
    z[3,7,6]  R1429     -3.7808814644813538e-01
    z[3,7,6]  R1430     -1.9174209237098694e-01
    z[3,7,6]  R1431     -2.4110180139541626e-01
    z[3,7,6]  R1432     -2.7830812335014343e-01
    z[3,7,6]  R1433     1.5989591181278229e-01
    z[3,7,6]  R1434     -3.0983921885490417e-01
    z[3,7,6]  R1435     7.1816518902778625e-02
    z[3,7,6]  R1436     -4.6738538146018982e-01
    z[3,7,6]  R1437     -3.3327281475067139e-01
    z[3,7,6]  R1438     -3.1285735964775085e-01
    z[3,7,6]  R1439     -5.3250551223754883e-01
    z[3,7,6]  R1440     2.0171479880809784e-01
    z[3,7,6]  R1441     1.2863324582576752e-01
    z[3,7,6]  R1442     -4.5032438635826111e-01
    z[3,7,6]  R1443     -4.7583183646202087e-01
    z[3,7,6]  R1444     2.8816403821110725e-02
    z[3,7,6]  R1445     -1.9571878015995026e-01
    z[3,7,6]  R1446     3.2713532447814941e-01
    z[3,7,6]  R1447     0.0740632712841034
    z[3,7,6]  R1448     -1.2733453512191772e-01
    z[3,7,6]  R1449     2.0751886069774628e-01
    z[7,3,0]  R29       1
    z[7,3,0]  R65       -1
    z[7,3,0]  R1450     -1
    z[7,3,0]  R1451     1
    z[7,3,0]  R1464     4.7603544592857361e-01
    z[7,3,0]  R1465     3.6790758371353149e-01
    z[7,3,0]  R1466     4.1421744227409363e-01
    z[7,3,0]  R1467     -3.9302725344896317e-02
    z[7,3,0]  R1468     3.1200116872787476e-01
    z[7,3,0]  R1469     3.5082545876502991e-01
    z[7,3,0]  R1470     -8.3406277000904083e-02
    z[7,3,0]  R1471     5.2954941987991333e-01
    z[7,3,0]  R1472     3.5198795795440674e-01
    z[7,3,0]  R1473     0.588661253452301
    z[7,3,0]  R1474     -2.9111906886100769e-01
    z[7,3,0]  R1475     5.9338800609111786e-02
    z[7,3,0]  R1476     -1.7377567291259766e-01
    z[7,3,0]  R1477     2.0256677269935608e-01
    z[7,3,0]  R1478     -1.1065188795328140e-01
    z[7,3,0]  R1479     -8.7795235216617584e-02
    z[7,3,0]  R1480     -3.0642268061637878e-01
    z[7,3,0]  R1481     2.7552178502082825e-01
    z[7,3,0]  R1482     3.7211981415748596e-01
    z[7,3,0]  R1483     6.6856807470321655e-01
    z[7,3,0]  R1484     1.3725635409355164e-01
    z[7,3,0]  R1485     3.8982889056205750e-01
    z[7,3,0]  R1486     -0.123763807117939
    z[7,3,0]  R1487     3.7052273750305176e-01
    z[7,3,0]  R1488     4.1609662771224976e-01
    z[7,3,0]  R1489     2.5699424743652344e-01
    z[7,3,0]  R1490     4.1304844617843628e-01
    z[7,3,0]  R1491     4.1018193960189819e-01
    z[7,3,0]  R1492     -3.0694928765296936e-01
    z[7,3,0]  R1493     2.4791166186332703e-01
    z[7,3,0]  R1494     -0.0092205461114645
    z[7,3,0]  R1495     -2.7029192447662354e-01
    z[7,3,0]  R1496     1.2486063875257969e-02
    z[7,3,0]  R1497     -7.6464004814624786e-02
    z[7,3,0]  R1498     -3.1966125965118408e-01
    z[7,3,0]  R1499     -2.7544555068016052e-01
    z[7,3,0]  R1500     -4.4085282087326050e-01
    z[7,3,0]  R1501     -6.3712352514266968e-01
    z[7,3,0]  R1502     -2.3229372501373291e-01
    z[7,3,0]  R1503     5.8029163628816605e-03
    z[7,3,0]  R1504     -5.2021265029907227e-01
    z[7,3,0]  R1505     3.8525256514549255e-01
    z[7,3,0]  R1506     -3.6801743507385254e-01
    z[7,3,0]  R1507     2.2431758046150208e-01
    z[7,3,0]  R1508     1.1507070809602737e-01
    z[7,3,0]  R1509     -2.2654646635055542e-01
    z[7,3,0]  R1510     8.1596441566944122e-02
    z[7,3,0]  R1511     1.6711363196372986e-01
    z[7,3,0]  R1512     -8.7778925895690918e-01
    z[7,3,0]  R1513     -8.5311925411224365e-01
    z[7,3,0]  R1514     2.0798969268798828e-01
    z[7,3,0]  R1515     -1.6027653217315674e-01
    z[7,3,0]  R1516     4.4577309489250183e-01
    z[7,3,0]  R1517     0.485567182302475
    z[7,3,0]  R1518     -1.2288659065961838e-01
    z[7,3,0]  R1519     3.4876942634582520e-01
    z[7,3,0]  R1520     -0.182876855134964
    z[7,3,0]  R1521     2.6595833897590637e-01
    z[7,3,0]  R1522     8.1409555673599243e-01
    z[7,3,0]  R1523     7.9661399126052856e-01
    z[7,3,0]  R1524     -7.8262883424758911e-01
    z[7,3,0]  R1525     -5.1310819387435913e-01
    z[7,3,0]  R1526     -3.4668001532554626e-01
    z[7,3,0]  R1527     2.5861239433288574e-01
    z[7,3,0]  R1528     -4.4897374510765076e-01
    z[7,3,0]  R1529     -2.0265442132949829e-01
    z[7,3,0]  R1530     8.8884755969047546e-03
    z[7,3,0]  R1531     -7.0157241821289062e-01
    z[7,3,0]  R1532     -0.680765688419342
    z[7,3,0]  R1533     -5.1564160734415054e-02
    z[7,3,0]  R1534     -2.9696670174598694e-01
    z[7,3,0]  R1535     -5.6222927570343018e-01
    z[7,3,0]  R1536     -4.8878137022256851e-02
    z[7,3,0]  R1537     3.4708552062511444e-02
    z[7,3,0]  R1538     4.5578765869140625e-01
    z[7,3,0]  R1539     2.4165239930152893e-01
    z[7,3,0]  R1540     2.3586918413639069e-01
    z[7,3,0]  R1541     8.8426578044891357e-01
    z[7,3,0]  R1542     0.896182656288147
    z[7,3,0]  R1543     -2.9889929294586182e-01
    z[7,3,1]  R30       1
    z[7,3,1]  R66       -1
    z[7,3,1]  R1452     -1
    z[7,3,1]  R1453     1
    z[7,3,1]  R1464     -1.0660460591316223e-01
    z[7,3,1]  R1465     -1.2077955156564713e-01
    z[7,3,1]  R1466     -2.0885924994945526e-01
    z[7,3,1]  R1467     -5.9599387645721436e-01
    z[7,3,1]  R1468     -2.4721232056617737e-01
    z[7,3,1]  R1469     -2.8906211256980896e-01
    z[7,3,1]  R1470     -4.9694183468818665e-01
    z[7,3,1]  R1471     -4.0280455350875854e-01
    z[7,3,1]  R1472     -2.8144043684005737e-01
    z[7,3,1]  R1473     -5.1659953594207764e-01
    z[7,3,1]  R1474     -1.8781755119562149e-02
    z[7,3,1]  R1475     2.2174131870269775e-01
    z[7,3,1]  R1476     1.6783127188682556e-01
    z[7,3,1]  R1477     -3.4644204378128052e-01
    z[7,3,1]  R1478     1.6638845205307007e-01
    z[7,3,1]  R1479     3.4050557017326355e-01
    z[7,3,1]  R1480     8.4921658039093018e-01
    z[7,3,1]  R1481     -5.4452598094940186e-02
    z[7,3,1]  R1482     5.2231132984161377e-02
    z[7,3,1]  R1483     0.0165800079703331
    z[7,3,1]  R1484     8.6523312330245972e-01
    z[7,3,1]  R1485     0.849455714225769
    z[7,3,1]  R1486     8.3081424236297607e-01
    z[7,3,1]  R1487     7.5549054145812988e-01
    z[7,3,1]  R1488     6.9476801156997681e-01
    z[7,3,1]  R1489     7.0348227024078369e-01
    z[7,3,1]  R1490     6.7879295349121094e-01
    z[7,3,1]  R1491     6.7431765794754028e-01
    z[7,3,1]  R1492     0.812117338180542
    z[7,3,1]  R1493     6.5174585580825806e-01
    z[7,3,1]  R1494     0.875145673751831
    z[7,3,1]  R1495     7.7661645412445068e-01
    z[7,3,1]  R1496     3.3691346645355225e-01
    z[7,3,1]  R1497     -1.3373208045959473e-01
    z[7,3,1]  R1498     2.1163500845432281e-01
    z[7,3,1]  R1499     1.4521718025207520e-01
    z[7,3,1]  R1500     2.0001755654811859e-01
    z[7,3,1]  R1501     -1.7763268947601318e-01
    z[7,3,1]  R1502     -4.1447395086288452e-01
    z[7,3,1]  R1503     3.2233405113220215e-01
    z[7,3,1]  R1504     -1.6980348154902458e-02
    z[7,3,1]  R1505     6.8088221549987793e-01
    z[7,3,1]  R1506     1.2809453904628754e-01
    z[7,3,1]  R1507     -3.7579932808876038e-01
    z[7,3,1]  R1508     -7.0018756389617920e-01
    z[7,3,1]  R1509     3.0431863665580750e-01
    z[7,3,1]  R1510     -4.0260177105665207e-02
    z[7,3,1]  R1511     -2.2124862670898438e-01
    z[7,3,1]  R1512     1.3861157000064850e-01
    z[7,3,1]  R1513     2.3196747526526451e-02
    z[7,3,1]  R1514     4.7397175431251526e-01
    z[7,3,1]  R1515     -5.1044309139251709e-01
    z[7,3,1]  R1516     1.0607351548969746e-02
    z[7,3,1]  R1517     -6.5003573894500732e-02
    z[7,3,1]  R1518     -4.2076998949050903e-01
    z[7,3,1]  R1519     3.2847024500370026e-02
    z[7,3,1]  R1520     -2.3373763263225555e-01
    z[7,3,1]  R1521     3.5103362053632736e-02
    z[7,3,1]  R1522     1.5364921092987061e-01
    z[7,3,1]  R1523     1.7687892913818359e-01
    z[7,3,1]  R1524     -1.2815099954605103e-01
    z[7,3,1]  R1525     -2.0230868831276894e-02
    z[7,3,1]  R1526     1.3132871687412262e-01
    z[7,3,1]  R1527     3.9347603917121887e-02
    z[7,3,1]  R1528     4.6784910559654236e-01
    z[7,3,1]  R1529     4.3934464454650879e-01
    z[7,3,1]  R1530     -9.8866842687129974e-02
    z[7,3,1]  R1531     5.0842958688735962e-01
    z[7,3,1]  R1532     3.8184297084808350e-01
    z[7,3,1]  R1533     1.7891910672187805e-01
    z[7,3,1]  R1534     0.16356261074543
    z[7,3,1]  R1535     2.4688905104994774e-02
    z[7,3,1]  R1536     6.0318535566329956e-01
    z[7,3,1]  R1537     -0.68907630443573
    z[7,3,1]  R1538     -1.5761137008666992e-01
    z[7,3,1]  R1539     8.9654959738254547e-02
    z[7,3,1]  R1540     -3.7349554896354675e-01
    z[7,3,1]  R1541     1.5629976987838745e-01
    z[7,3,1]  R1542     1.6974413767457008e-02
    z[7,3,1]  R1543     1.3153521716594696e-01
    z[7,3,2]  R31       1
    z[7,3,2]  R67       -1
    z[7,3,2]  R1454     -1
    z[7,3,2]  R1455     1
    z[7,3,2]  R1464     -2.4987235665321350e-01
    z[7,3,2]  R1465     8.0049097537994385e-02
    z[7,3,2]  R1466     -2.3241643607616425e-01
    z[7,3,2]  R1467     -5.9219084680080414e-02
    z[7,3,2]  R1468     -1.5208722651004791e-01
    z[7,3,2]  R1469     -3.8834550976753235e-01
    z[7,3,2]  R1470     1.2844204902648926e-01
    z[7,3,2]  R1471     7.9727783799171448e-02
    z[7,3,2]  R1472     -3.1406372785568237e-01
    z[7,3,2]  R1473     -2.2537735104560852e-01
    z[7,3,2]  R1474     3.1608071923255920e-01
    z[7,3,2]  R1475     0.568540096282959
    z[7,3,2]  R1476     -1.6008764505386353e-01
    z[7,3,2]  R1477     6.4011670649051666e-02
    z[7,3,2]  R1478     1.6753885149955750e-01
    z[7,3,2]  R1479     -2.5317856669425964e-01
    z[7,3,2]  R1480     5.0702389329671860e-02
    z[7,3,2]  R1481     -3.5285180807113647e-01
    z[7,3,2]  R1482     2.7158821467310190e-03
    z[7,3,2]  R1483     1.0803978657349944e-03
    z[7,3,2]  R1484     -1.3204509019851685e-01
    z[7,3,2]  R1485     -2.4696128070354462e-01
    z[7,3,2]  R1486     1.7244906723499298e-01
    z[7,3,2]  R1487     -6.4365096390247345e-02
    z[7,3,2]  R1488     1.3435410801321268e-03
    z[7,3,2]  R1489     2.3369173705577850e-01
    z[7,3,2]  R1490     -2.3711295425891876e-01
    z[7,3,2]  R1491     4.8450350761413574e-01
    z[7,3,2]  R1492     -4.2923524975776672e-01
    z[7,3,2]  R1493     3.4046009182929993e-01
    z[7,3,2]  R1494     6.1573632061481476e-02
    z[7,3,2]  R1495     -3.5468775033950806e-01
    z[7,3,2]  R1496     6.7794602364301682e-03
    z[7,3,2]  R1497     -7.6889827847480774e-02
    z[7,3,2]  R1498     8.4859818220138550e-02
    z[7,3,2]  R1499     -2.2711716592311859e-01
    z[7,3,2]  R1500     -2.6905193924903870e-01
    z[7,3,2]  R1501     -4.9347379803657532e-01
    z[7,3,2]  R1502     -3.0910629034042358e-01
    z[7,3,2]  R1503     -0.624438464641571
    z[7,3,2]  R1504     -3.9014685153961182e-01
    z[7,3,2]  R1505     3.2838678359985352e-01
    z[7,3,2]  R1506     -6.5237575769424438e-01
    z[7,3,2]  R1507     -2.1648381650447845e-01
    z[7,3,2]  R1508     6.9230437278747559e-02
    z[7,3,2]  R1509     -8.0624055862426758e-01
    z[7,3,2]  R1510     -0.617302417755127
    z[7,3,2]  R1511     -0.723918616771698
    z[7,3,2]  R1512     4.9001105129718781e-02
    z[7,3,2]  R1513     -3.2605963945388794e-01
    z[7,3,2]  R1514     -1.4849710464477539e-01
    z[7,3,2]  R1515     2.1112892031669617e-01
    z[7,3,2]  R1516     4.5270791649818420e-01
    z[7,3,2]  R1517     3.3361065387725830e-01
    z[7,3,2]  R1518     2.9637560248374939e-01
    z[7,3,2]  R1519     2.8770384192466736e-01
    z[7,3,2]  R1520     2.3488526046276093e-01
    z[7,3,2]  R1521     2.7894172072410583e-01
    z[7,3,2]  R1522     -3.7805265188217163e-01
    z[7,3,2]  R1523     -2.1345199644565582e-01
    z[7,3,2]  R1524     -3.5631260275840759e-01
    z[7,3,2]  R1525     -3.1214338541030884e-01
    z[7,3,2]  R1526     2.6848953217267990e-02
    z[7,3,2]  R1527     -4.7626032028347254e-04
    z[7,3,2]  R1528     -5.4760348796844482e-01
    z[7,3,2]  R1529     -5.2161341905593872e-01
    z[7,3,2]  R1530     -2.7225714921951294e-01
    z[7,3,2]  R1531     1.4438579976558685e-01
    z[7,3,2]  R1532     2.2329366207122803e-01
    z[7,3,2]  R1533     -6.6694356501102448e-02
    z[7,3,2]  R1534     5.4491654038429260e-02
    z[7,3,2]  R1535     -1.0325080901384354e-01
    z[7,3,2]  R1536     -0.209682434797287
    z[7,3,2]  R1537     0.529075562953949
    z[7,3,2]  R1538     6.2065100669860840e-01
    z[7,3,2]  R1539     4.8167562484741211e-01
    z[7,3,2]  R1540     2.9683086276054382e-01
    z[7,3,2]  R1541     -1.8844637274742126e-01
    z[7,3,2]  R1542     -3.7243932485580444e-01
    z[7,3,2]  R1543     -3.0112260952591896e-02
    z[7,3,3]  R32       1
    z[7,3,3]  R68       -1
    z[7,3,3]  R1456     -1
    z[7,3,3]  R1457     1
    z[7,3,3]  R1464     -6.7224484682083130e-01
    z[7,3,3]  R1465     -7.0029366016387939e-01
    z[7,3,3]  R1466     -6.1937773227691650e-01
    z[7,3,3]  R1467     -7.1388387680053711e-01
    z[7,3,3]  R1468     -4.9720174074172974e-01
    z[7,3,3]  R1469     -6.4908200502395630e-01
    z[7,3,3]  R1470     -5.3357076644897461e-01
    z[7,3,3]  R1471     -7.3130798339843750e-01
    z[7,3,3]  R1472     -6.9445818662643433e-01
    z[7,3,3]  R1473     -5.0333750247955322e-01
    z[7,3,3]  R1474     8.9732266962528229e-02
    z[7,3,3]  R1475     9.4804614782333374e-02
    z[7,3,3]  R1476     1.2280047684907913e-01
    z[7,3,3]  R1477     -5.7932874187827110e-03
    z[7,3,3]  R1478     3.1909137964248657e-02
    z[7,3,3]  R1479     2.1057588979601860e-02
    z[7,3,3]  R1480     -3.4516620635986328e-01
    z[7,3,3]  R1481     8.7836936116218567e-02
    z[7,3,3]  R1482     2.9434330761432648e-02
    z[7,3,3]  R1483     4.8773370683193207e-02
    z[7,3,3]  R1484     -3.7065398693084717e-01
    z[7,3,3]  R1485     -1.7758302390575409e-01
    z[7,3,3]  R1486     2.2660417854785919e-01
    z[7,3,3]  R1487     1.2246348708868027e-01
    z[7,3,3]  R1488     -4.3347876518964767e-02
    z[7,3,3]  R1489     2.0179098471999168e-02
    z[7,3,3]  R1490     1.2138762325048447e-01
    z[7,3,3]  R1491     -8.3573527634143829e-02
    z[7,3,3]  R1492     1.6214302182197571e-01
    z[7,3,3]  R1493     -5.3740464150905609e-02
    z[7,3,3]  R1494     1.3159784674644470e-01
    z[7,3,3]  R1495     -2.7779016643762589e-02
    z[7,3,3]  R1496     -4.5293146371841431e-01
    z[7,3,3]  R1497     -9.1966682672500610e-01
    z[7,3,3]  R1498     -8.2189255952835083e-01
    z[7,3,3]  R1499     -7.0442509651184082e-01
    z[7,3,3]  R1500     -3.1061306595802307e-01
    z[7,3,3]  R1501     -1.7593665421009064e-01
    z[7,3,3]  R1502     1.3717627525329590e-01
    z[7,3,3]  R1503     -3.4871584177017212e-01
    z[7,3,3]  R1504     -0.436395525932312
    z[7,3,3]  R1505     1.4738725125789642e-01
    z[7,3,3]  R1506     -3.3101609349250793e-01
    z[7,3,3]  R1507     -6.1580508947372437e-01
    z[7,3,3]  R1508     -5.5146604776382446e-01
    z[7,3,3]  R1509     -3.0081382393836975e-01
    z[7,3,3]  R1510     1.3018840551376343e-01
    z[7,3,3]  R1511     1.2936544418334961e-01
    z[7,3,3]  R1512     3.0576642602682114e-02
    z[7,3,3]  R1513     -1.2606064788997173e-02
    z[7,3,3]  R1514     -8.0069136619567871e-01
    z[7,3,3]  R1515     -7.5212538242340088e-01
    z[7,3,3]  R1516     -5.6111198663711548e-01
    z[7,3,3]  R1517     -0.707947850227356
    z[7,3,3]  R1518     -4.8851883411407471e-01
    z[7,3,3]  R1519     -6.5705120563507080e-01
    z[7,3,3]  R1520     -2.1463672816753387e-01
    z[7,3,3]  R1521     -1.8314115703105927e-01
    z[7,3,3]  R1522     -6.2325548380613327e-02
    z[7,3,3]  R1523     -1.2716961093246937e-02
    z[7,3,3]  R1524     -3.0760338902473450e-01
    z[7,3,3]  R1525     -9.7764588892459869e-02
    z[7,3,3]  R1526     -1.7797645926475525e-01
    z[7,3,3]  R1527     2.6678565144538879e-01
    z[7,3,3]  R1528     1.4053313434123993e-01
    z[7,3,3]  R1529     1.2276563793420792e-02
    z[7,3,3]  R1530     2.4192081391811371e-01
    z[7,3,3]  R1531     1.9215981662273407e-01
    z[7,3,3]  R1532     -8.8324718177318573e-02
    z[7,3,3]  R1533     1.2633481621742249e-01
    z[7,3,3]  R1534     -3.2013097405433655e-01
    z[7,3,3]  R1535     -4.3988779187202454e-01
    z[7,3,3]  R1536     -1.3065457344055176e-01
    z[7,3,3]  R1537     -2.9899996519088745e-01
    z[7,3,3]  R1538     3.5970035195350647e-01
    z[7,3,3]  R1539     -2.6605978608131409e-01
    z[7,3,3]  R1540     5.1785528659820557e-01
    z[7,3,3]  R1541     1.1327573657035828e-01
    z[7,3,3]  R1542     1.1653125286102295e-01
    z[7,3,3]  R1543     2.4402470886707306e-01
    z[7,3,4]  R33       1
    z[7,3,4]  R69       -1
    z[7,3,4]  R1458     -1
    z[7,3,4]  R1459     1
    z[7,3,4]  R1464     2.4950763583183289e-01
    z[7,3,4]  R1465     3.3191773295402527e-01
    z[7,3,4]  R1466     5.4609251022338867e-01
    z[7,3,4]  R1467     3.4516081213951111e-01
    z[7,3,4]  R1468     6.8939322233200073e-01
    z[7,3,4]  R1469     3.4546619653701782e-01
    z[7,3,4]  R1470     0.305010050535202
    z[7,3,4]  R1471     3.4637738019227982e-02
    z[7,3,4]  R1472     -1.0367469489574432e-01
    z[7,3,4]  R1473     5.8627333492040634e-02
    z[7,3,4]  R1474     -8.0068618059158325e-01
    z[7,3,4]  R1475     -6.6231417655944824e-01
    z[7,3,4]  R1476     -9.4892930984497070e-01
    z[7,3,4]  R1477     -8.8086354732513428e-01
    z[7,3,4]  R1478     -8.6299884319305420e-01
    z[7,3,4]  R1479     -7.6170092821121216e-01
    z[7,3,4]  R1480     1.0170640423893929e-02
    z[7,3,4]  R1481     -6.8199980258941650e-01
    z[7,3,4]  R1482     -6.5378212928771973e-01
    z[7,3,4]  R1483     -6.9943392276763916e-01
    z[7,3,4]  R1484     2.3832754790782928e-01
    z[7,3,4]  R1485     -1.8893703818321228e-02
    z[7,3,4]  R1486     -1.6697883605957031e-01
    z[7,3,4]  R1487     -3.8166046142578125e-01
    z[7,3,4]  R1488     -1.1869627982378006e-01
    z[7,3,4]  R1489     4.3013298511505127e-01
    z[7,3,4]  R1490     -2.4247787892818451e-01
    z[7,3,4]  R1491     -0.0239796731621027
    z[7,3,4]  R1492     -2.1718394011259079e-02
    z[7,3,4]  R1493     2.4207362532615662e-01
    z[7,3,4]  R1494     -1.6972647607326508e-01
    z[7,3,4]  R1495     -3.5508543252944946e-01
    z[7,3,4]  R1496     4.5013442635536194e-01
    z[7,3,4]  R1497     -2.9802310466766357e-01
    z[7,3,4]  R1498     -1.7271572351455688e-01
    z[7,3,4]  R1499     -5.0280994176864624e-01
    z[7,3,4]  R1500     -2.2354270517826080e-01
    z[7,3,4]  R1501     2.9778888821601868e-01
    z[7,3,4]  R1502     -3.0977034568786621e-01
    z[7,3,4]  R1503     -1.1161712557077408e-01
    z[7,3,4]  R1504     1.7979015409946442e-01
    z[7,3,4]  R1505     2.1449477970600128e-01
    z[7,3,4]  R1506     -1.2893806397914886e-01
    z[7,3,4]  R1507     -3.8652592897415161e-01
    z[7,3,4]  R1508     -7.7593587338924408e-02
    z[7,3,4]  R1509     2.7747648954391479e-01
    z[7,3,4]  R1510     -2.9270559549331665e-01
    z[7,3,4]  R1511     -2.2900177538394928e-01
    z[7,3,4]  R1512     7.7248387038707733e-02
    z[7,3,4]  R1513     1.1837456375360489e-02
    z[7,3,4]  R1514     -1.0060030221939087e-01
    z[7,3,4]  R1515     -3.8738641887903214e-02
    z[7,3,4]  R1516     2.9095721244812012e-01
    z[7,3,4]  R1517     -1.1915315687656403e-01
    z[7,3,4]  R1518     1.4073304831981659e-01
    z[7,3,4]  R1519     -2.3209522664546967e-01
    z[7,3,4]  R1520     8.7771266698837280e-01
    z[7,3,4]  R1521     6.1948943138122559e-01
    z[7,3,4]  R1522     1.9244116544723511e-01
    z[7,3,4]  R1523     -9.9708780646324158e-02
    z[7,3,4]  R1524     0.152165487408638
    z[7,3,4]  R1525     5.0819325447082520e-01
    z[7,3,4]  R1526     1.2793740630149841e-01
    z[7,3,4]  R1527     4.4585832953453064e-01
    z[7,3,4]  R1528     5.0892066955566406e-01
    z[7,3,4]  R1529     4.8616915941238403e-01
    z[7,3,4]  R1530     -8.8259071111679077e-01
    z[7,3,4]  R1531     0.0740782767534256
    z[7,3,4]  R1532     -0.391072154045105
    z[7,3,4]  R1533     -6.2394684553146362e-01
    z[7,3,4]  R1534     4.9257880449295044e-01
    z[7,3,4]  R1535     2.1926164627075195e-01
    z[7,3,4]  R1536     7.3666656017303467e-01
    z[7,3,4]  R1537     2.8521430492401123e-01
    z[7,3,4]  R1538     3.3822399377822876e-01
    z[7,3,4]  R1539     4.1451269388198853e-01
    z[7,3,4]  R1540     2.5579139590263367e-01
    z[7,3,4]  R1541     -2.7272635698318481e-01
    z[7,3,4]  R1542     -8.2204639911651611e-02
    z[7,3,4]  R1543     -8.7263822555541992e-01
    z[7,3,5]  R34       1
    z[7,3,5]  R70       -1
    z[7,3,5]  R1460     -1
    z[7,3,5]  R1461     1
    z[7,3,5]  R1464     4.2622053623199463e-01
    z[7,3,5]  R1465     4.2791518568992615e-01
    z[7,3,5]  R1466     1.8242482841014862e-01
    z[7,3,5]  R1467     7.0057839155197144e-02
    z[7,3,5]  R1468     2.5204014778137207e-01
    z[7,3,5]  R1469     7.7326498925685883e-02
    z[7,3,5]  R1470     4.1740727424621582e-01
    z[7,3,5]  R1471     1.1308895796537399e-01
    z[7,3,5]  R1472     2.7069875970482826e-02
    z[7,3,5]  R1473     1.0098073631525040e-02
    z[7,3,5]  R1474     -1.9162584841251373e-01
    z[7,3,5]  R1475     -0.361482709646225
    z[7,3,5]  R1476     -2.1384628489613533e-02
    z[7,3,5]  R1477     -2.3538470268249512e-01
    z[7,3,5]  R1478     -2.2064080834388733e-01
    z[7,3,5]  R1479     -2.3851794004440308e-01
    z[7,3,5]  R1480     3.5427961498498917e-02
    z[7,3,5]  R1481     -2.8092318773269653e-01
    z[7,3,5]  R1482     -2.4708215892314911e-01
    z[7,3,5]  R1483     -1.2099565565586090e-01
    z[7,3,5]  R1484     -1.0895001702010632e-02
    z[7,3,5]  R1485     9.1795986518263817e-03
    z[7,3,5]  R1486     4.2843386530876160e-01
    z[7,3,5]  R1487     2.8480908274650574e-01
    z[7,3,5]  R1488     -1.3585822284221649e-01
    z[7,3,5]  R1489     3.5807177424430847e-01
    z[7,3,5]  R1490     4.4925898313522339e-01
    z[7,3,5]  R1491     2.3420919477939606e-01
    z[7,3,5]  R1492     -3.2690837979316711e-02
    z[7,3,5]  R1493     -4.3979048728942871e-01
    z[7,3,5]  R1494     -0.383866548538208
    z[7,3,5]  R1495     1.1409801244735718e-01
    z[7,3,5]  R1496     6.3329619169235229e-01
    z[7,3,5]  R1497     1.0092271864414215e-01
    z[7,3,5]  R1498     2.1092095971107483e-01
    z[7,3,5]  R1499     3.1188043951988220e-01
    z[7,3,5]  R1500     5.7301986217498779e-01
    z[7,3,5]  R1501     2.9715502262115479e-01
    z[7,3,5]  R1502     -0.68267822265625
    z[7,3,5]  R1503     2.9752397537231445e-01
    z[7,3,5]  R1504     5.5984055995941162e-01
    z[7,3,5]  R1505     4.4256573915481567e-01
    z[7,3,5]  R1506     3.0589541792869568e-01
    z[7,3,5]  R1507     8.0975212156772614e-02
    z[7,3,5]  R1508     -4.2513221502304077e-01
    z[7,3,5]  R1509     -1.5970150008797646e-02
    z[7,3,5]  R1510     -0.633258044719696
    z[7,3,5]  R1511     -5.6956237554550171e-01
    z[7,3,5]  R1512     -4.2983183264732361e-01
    z[7,3,5]  R1513     -3.4924387931823730e-01
    z[7,3,5]  R1514     -5.3799189627170563e-03
    z[7,3,5]  R1515     -1.7999008297920227e-01
    z[7,3,5]  R1516     -6.0456082224845886e-02
    z[7,3,5]  R1517     -2.2702747583389282e-01
    z[7,3,5]  R1518     1.0899110138416290e-01
    z[7,3,5]  R1519     1.0334442555904388e-01
    z[7,3,5]  R1520     -1.4412897825241089e-01
    z[7,3,5]  R1521     -1.4920921623706818e-01
    z[7,3,5]  R1522     3.5670313239097595e-01
    z[7,3,5]  R1523     5.2504038810729980e-01
    z[7,3,5]  R1524     1.7391893267631531e-01
    z[7,3,5]  R1525     -3.0043289065361023e-01
    z[7,3,5]  R1526     8.5372120141983032e-01
    z[7,3,5]  R1527     -7.6600193977355957e-01
    z[7,3,5]  R1528     -5.0599616952240467e-03
    z[7,3,5]  R1529     -4.6348902583122253e-01
    z[7,3,5]  R1530     -1.9151559472084045e-01
    z[7,3,5]  R1531     -4.5082513242959976e-02
    z[7,3,5]  R1532     -4.1748741269111633e-01
    z[7,3,5]  R1533     -7.3961865901947021e-01
    z[7,3,5]  R1534     5.6521528959274292e-01
    z[7,3,5]  R1535     6.5650010108947754e-01
    z[7,3,5]  R1536     1.3824495673179626e-01
    z[7,3,5]  R1537     -2.7003097534179688e-01
    z[7,3,5]  R1538     1.9309404492378235e-01
    z[7,3,5]  R1539     6.2927955389022827e-01
    z[7,3,5]  R1540     -0.541400671005249
    z[7,3,5]  R1541     1.4162269234657288e-01
    z[7,3,5]  R1542     -1.8363635241985321e-01
    z[7,3,5]  R1543     -2.4780270457267761e-01
    z[7,3,6]  R35       1
    z[7,3,6]  R71       -1
    z[7,3,6]  R1462     -1
    z[7,3,6]  R1463     1
    z[7,3,6]  R1464     -6.1305873095989227e-02
    z[7,3,6]  R1465     2.4486029148101807e-01
    z[7,3,6]  R1466     1.2513917684555054e-01
    z[7,3,6]  R1467     0.0778806284070015
    z[7,3,6]  R1468     -1.8003915250301361e-01
    z[7,3,6]  R1469     -3.0970746278762817e-01
    z[7,3,6]  R1470     -4.2147025465965271e-01
    z[7,3,6]  R1471     4.6574071049690247e-02
    z[7,3,6]  R1472     4.5222377777099609e-01
    z[7,3,6]  R1473     2.8092715144157410e-01
    z[7,3,6]  R1474     -3.5933154821395874e-01
    z[7,3,6]  R1475     -2.1390192210674286e-01
    z[7,3,6]  R1476     1.5885165194049478e-03
    z[7,3,6]  R1477     5.9050343930721283e-02
    z[7,3,6]  R1478     3.7085619568824768e-01
    z[7,3,6]  R1479     -4.1800227761268616e-01
    z[7,3,6]  R1480     2.4873162806034088e-01
    z[7,3,6]  R1481     -4.9483460187911987e-01
    z[7,3,6]  R1482     -6.0781919956207275e-01
    z[7,3,6]  R1483     -2.1567137539386749e-01
    z[7,3,6]  R1484     -1.4419928193092346e-01
    z[7,3,6]  R1485     -1.8300722539424896e-01
    z[7,3,6]  R1486     -4.3642383068799973e-02
    z[7,3,6]  R1487     -2.1453650295734406e-01
    z[7,3,6]  R1488     5.5653733015060425e-01
    z[7,3,6]  R1489     -2.6611623167991638e-01
    z[7,3,6]  R1490     1.9246926903724670e-01
    z[7,3,6]  R1491     2.8264707326889038e-01
    z[7,3,6]  R1492     -1.8486200273036957e-01
    z[7,3,6]  R1493     -3.7808814644813538e-01
    z[7,3,6]  R1494     -1.9174209237098694e-01
    z[7,3,6]  R1495     -2.4110180139541626e-01
    z[7,3,6]  R1496     -2.7830812335014343e-01
    z[7,3,6]  R1497     1.5989591181278229e-01
    z[7,3,6]  R1498     -3.0983921885490417e-01
    z[7,3,6]  R1499     7.1816518902778625e-02
    z[7,3,6]  R1500     -4.6738538146018982e-01
    z[7,3,6]  R1501     -3.3327281475067139e-01
    z[7,3,6]  R1502     -3.1285735964775085e-01
    z[7,3,6]  R1503     -5.3250551223754883e-01
    z[7,3,6]  R1504     2.0171479880809784e-01
    z[7,3,6]  R1505     1.2863324582576752e-01
    z[7,3,6]  R1506     -4.5032438635826111e-01
    z[7,3,6]  R1507     -4.7583183646202087e-01
    z[7,3,6]  R1508     2.8816403821110725e-02
    z[7,3,6]  R1509     -1.9571878015995026e-01
    z[7,3,6]  R1510     3.2713532447814941e-01
    z[7,3,6]  R1511     0.0740632712841034
    z[7,3,6]  R1512     -1.2733453512191772e-01
    z[7,3,6]  R1513     2.0751886069774628e-01
    z[7,3,6]  R1514     2.4245367944240570e-01
    z[7,3,6]  R1515     -0.263807088136673
    z[7,3,6]  R1516     4.3939930200576782e-01
    z[7,3,6]  R1517     -2.8596135973930359e-01
    z[7,3,6]  R1518     -6.7058008909225464e-01
    z[7,3,6]  R1519     5.4611617326736450e-01
    z[7,3,6]  R1520     -1.3975061476230621e-01
    z[7,3,6]  R1521     -6.4082300662994385e-01
    z[7,3,6]  R1522     -5.0610471516847610e-02
    z[7,3,6]  R1523     5.2794121205806732e-02
    z[7,3,6]  R1524     3.0998182296752930e-01
    z[7,3,6]  R1525     5.2990466356277466e-01
    z[7,3,6]  R1526     2.9148116707801819e-01
    z[7,3,6]  R1527     2.7358356118202209e-01
    z[7,3,6]  R1528     2.9916131868958473e-02
    z[7,3,6]  R1529     -2.0614005625247955e-01
    z[7,3,6]  R1530     -2.0457790791988373e-01
    z[7,3,6]  R1531     -4.2895531654357910e-01
    z[7,3,6]  R1532     -7.6548449695110321e-02
    z[7,3,6]  R1533     -9.2601068317890167e-02
    z[7,3,6]  R1534     4.6637180447578430e-01
    z[7,3,6]  R1535     7.6529458165168762e-03
    z[7,3,6]  R1536     -1.0465058684349060e-01
    z[7,3,6]  R1537     1.9581615924835205e-02
    z[7,3,6]  R1538     3.1803071498870850e-01
    z[7,3,6]  R1539     -2.5090509653091431e-01
    z[7,3,6]  R1540     3.0006700754165649e-01
    z[7,3,6]  R1541     -2.2553144395351410e-01
    z[7,3,6]  R1542     -6.1627957969903946e-02
    z[7,3,6]  R1543     0.0999956876039505
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R1588     -1
    z[4,5,0]  R1589     1
    z[4,5,0]  R1602     -2.8363308310508728e-01
    z[4,5,0]  R1603     6.3270486891269684e-02
    z[4,5,0]  R1604     1.0960305109620094e-02
    z[4,5,0]  R1605     0.143471822142601
    z[4,5,0]  R1606     -1.2894485890865326e-01
    z[4,5,0]  R1607     -1.7774090170860291e-01
    z[4,5,0]  R1608     -5.9229356050491333e-01
    z[4,5,0]  R1609     -6.4346569776535034e-01
    z[4,5,0]  R1610     -3.6360916495323181e-01
    z[4,5,0]  R1611     -0.664874255657196
    z[4,5,0]  R1612     -2.1831926703453064e-01
    z[4,5,0]  R1613     2.9715850949287415e-01
    z[4,5,0]  R1614     2.9847967624664307e-01
    z[4,5,0]  R1615     3.3534556627273560e-01
    z[4,5,0]  R1616     3.8330844044685364e-01
    z[4,5,0]  R1617     3.4660476446151733e-01
    z[4,5,0]  R1618     5.7784989476203918e-02
    z[4,5,0]  R1619     3.1476294994354248e-01
    z[4,5,0]  R1620     2.1589669585227966e-01
    z[4,5,0]  R1621     2.0634412765502930e-01
    z[4,5,0]  R1622     6.2413150072097778e-01
    z[4,5,0]  R1623     6.6744023561477661e-01
    z[4,5,0]  R1624     6.3662898540496826e-01
    z[4,5,0]  R1625     5.0223106145858765e-01
    z[4,5,0]  R1626     6.4914405345916748e-01
    z[4,5,0]  R1627     4.7491988539695740e-01
    z[4,5,0]  R1628     4.3309062719345093e-01
    z[4,5,0]  R1629     -4.1635531187057495e-01
    z[4,5,0]  R1630     5.1093876361846924e-01
    z[4,5,0]  R1631     4.8697581887245178e-01
    z[4,5,0]  R1632     -3.9949950575828552e-01
    z[4,5,0]  R1633     -3.7090122699737549e-01
    z[4,5,0]  R1634     6.1859232187271118e-01
    z[4,5,0]  R1635     -1.2515333294868469e-01
    z[4,5,0]  R1636     2.9414582252502441e-01
    z[4,5,0]  R1637     4.4930049777030945e-01
    z[4,5,0]  R1638     -1.1720172315835953e-01
    z[4,5,0]  R1639     -1.2280052155256271e-01
    z[4,5,0]  R1640     -5.0174880772829056e-02
    z[4,5,0]  R1641     2.2930721938610077e-01
    z[4,5,0]  R1642     -3.3153480291366577e-01
    z[4,5,0]  R1643     -0.270396888256073
    z[4,5,0]  R1644     2.1862052381038666e-01
    z[4,5,0]  R1645     2.7732756733894348e-01
    z[4,5,0]  R1646     -4.0526506304740906e-01
    z[4,5,0]  R1647     -1.5620526671409607e-01
    z[4,5,0]  R1648     -8.9507259428501129e-02
    z[4,5,0]  R1649     -1.6994468867778778e-01
    z[4,5,0]  R1650     -0.250703364610672
    z[4,5,0]  R1651     2.8833541274070740e-01
    z[4,5,0]  R1652     0.385304719209671
    z[4,5,0]  R1653     0.0796690359711647
    z[4,5,0]  R1654     4.2561444640159607e-01
    z[4,5,0]  R1655     3.7661164999008179e-01
    z[4,5,0]  R1656     2.9428660869598389e-01
    z[4,5,0]  R1657     1.0311092436313629e-01
    z[4,5,0]  R1658     4.6421322971582413e-02
    z[4,5,0]  R1659     4.4364559650421143e-01
    z[4,5,0]  R1660     5.0357764959335327e-01
    z[4,5,0]  R1661     2.0000481605529785e-01
    z[4,5,0]  R1662     -1.0121417045593262e-01
    z[4,5,0]  R1663     -1.3475139439105988e-01
    z[4,5,0]  R1664     -1.6032533347606659e-01
    z[4,5,0]  R1665     -3.8989122956991196e-02
    z[4,5,0]  R1666     -1.0579904913902283e-01
    z[4,5,0]  R1667     2.7819040417671204e-01
    z[4,5,0]  R1668     -1.2221422046422958e-01
    z[4,5,0]  R1669     -2.9942116141319275e-01
    z[4,5,0]  R1670     9.1471262276172638e-02
    z[4,5,0]  R1671     5.3104126453399658e-01
    z[4,5,0]  R1672     3.2689875364303589e-01
    z[4,5,0]  R1673     2.6952734589576721e-01
    z[4,5,0]  R1674     8.9986763894557953e-02
    z[4,5,0]  R1675     2.7206912636756897e-01
    z[4,5,0]  R1676     1.6852578148245811e-02
    z[4,5,0]  R1677     4.8067674040794373e-02
    z[4,5,0]  R1678     5.0814390182495117e-02
    z[4,5,0]  R1679     -0.0943196564912796
    z[4,5,0]  R1680     -9.4523094594478607e-02
    z[4,5,0]  R1681     2.4276039004325867e-01
    z[4,5,0]  R1682     3.7563553452491760e-01
    z[4,5,0]  R1683     3.0035263299942017e-01
    z[4,5,0]  R1684     1.8295191228389740e-01
    z[4,5,0]  R1685     4.3913197517395020e-01
    z[4,5,0]  R1686     2.2637119889259338e-01
    z[4,5,0]  R1687     2.5595527887344360e-01
    z[4,5,0]  R1688     3.6129298806190491e-01
    z[4,5,0]  R1689     3.9604946970939636e-01
    z[4,5,0]  R1690     7.9146578907966614e-02
    z[4,5,0]  R1691     4.2139679193496704e-01
    z[4,5,0]  R1692     4.2497593164443970e-01
    z[4,5,0]  R1693     2.0740933716297150e-01
    z[4,5,0]  R1694     1.1835118383169174e-01
    z[4,5,0]  R1695     3.0861017107963562e-01
    z[4,5,0]  R1696     -6.9337459281086922e-03
    z[4,5,0]  R1697     1.9369046390056610e-01
    z[4,5,0]  R1698     -2.3375537991523743e-01
    z[4,5,0]  R1699     3.6900978535413742e-02
    z[4,5,0]  R1700     -2.8620123863220215e-01
    z[4,5,0]  R1701     2.6928946375846863e-01
    z[4,5,0]  R1702     2.8702870011329651e-01
    z[4,5,0]  R1703     3.2271936535835266e-02
    z[4,5,0]  R1704     -0.0276222862303257
    z[4,5,0]  R1705     9.2043019831180573e-03
    z[4,5,0]  R1706     -0.343716561794281
    z[4,5,0]  R1707     -2.2175729274749756e-01
    z[4,5,0]  R1708     -9.4915814697742462e-02
    z[4,5,0]  R1709     -2.2074216604232788e-01
    z[4,5,0]  R1710     2.9744111001491547e-02
    z[4,5,0]  R1711     1.0121062397956848e-01
    z[4,5,0]  R1712     9.6210852265357971e-02
    z[4,5,0]  R1713     1.3581463694572449e-01
    z[4,5,0]  R1714     -1.0095175355672836e-01
    z[4,5,0]  R1715     -5.4806601256132126e-02
    z[4,5,0]  R1716     5.5049747228622437e-01
    z[4,5,0]  R1717     -3.3798721432685852e-01
    z[4,5,0]  R1718     -3.6248758435249329e-01
    z[4,5,0]  R1719     -4.1941866278648376e-01
    z[4,5,0]  R1720     -2.5176367163658142e-01
    z[4,5,0]  R1721     -1.3267327845096588e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R1590     -1
    z[4,5,1]  R1591     1
    z[4,5,1]  R1602     0.673723042011261
    z[4,5,1]  R1603     3.1906521320343018e-01
    z[4,5,1]  R1604     3.7437894940376282e-01
    z[4,5,1]  R1605     7.3310643434524536e-01
    z[4,5,1]  R1606     3.5284972190856934e-01
    z[4,5,1]  R1607     4.1465076804161072e-01
    z[4,5,1]  R1608     -5.9358751773834229e-01
    z[4,5,1]  R1609     -1.6057939827442169e-01
    z[4,5,1]  R1610     2.4091082811355591e-01
    z[4,5,1]  R1611     -4.6989148855209351e-01
    z[4,5,1]  R1612     -3.4238114953041077e-01
    z[4,5,1]  R1613     -7.3204773664474487e-01
    z[4,5,1]  R1614     -6.7584872245788574e-01
    z[4,5,1]  R1615     -6.9339352846145630e-01
    z[4,5,1]  R1616     -7.3640400171279907e-01
    z[4,5,1]  R1617     -6.5614819526672363e-01
    z[4,5,1]  R1618     -5.8755552768707275e-01
    z[4,5,1]  R1619     -5.5656814575195312e-01
    z[4,5,1]  R1620     -2.9664844274520874e-01
    z[4,5,1]  R1621     -0.0769195556640625
    z[4,5,1]  R1622     6.2265670299530029e-01
    z[4,5,1]  R1623     2.6981109380722046e-01
    z[4,5,1]  R1624     -3.9388540387153625e-01
    z[4,5,1]  R1625     -5.8104431629180908e-01
    z[4,5,1]  R1626     3.3632245659828186e-01
    z[4,5,1]  R1627     -5.1232308149337769e-01
    z[4,5,1]  R1628     6.2998533248901367e-01
    z[4,5,1]  R1629     -5.2235430479049683e-01
    z[4,5,1]  R1630     -5.2130079269409180e-01
    z[4,5,1]  R1631     4.9059343338012695e-01
    z[4,5,1]  R1632     -2.5148870423436165e-02
    z[4,5,1]  R1633     2.5600403547286987e-01
    z[4,5,1]  R1634     0.571380078792572
    z[4,5,1]  R1635     -1.6271811723709106e-01
    z[4,5,1]  R1636     -0.809425413608551
    z[4,5,1]  R1637     2.4708189070224762e-02
    z[4,5,1]  R1638     -3.8372665643692017e-01
    z[4,5,1]  R1639     1.2259277701377869e-01
    z[4,5,1]  R1640     -4.1192939877510071e-01
    z[4,5,1]  R1641     -3.4744560718536377e-01
    z[4,5,1]  R1642     0.0476214662194252
    z[4,5,1]  R1643     1.0748263448476791e-01
    z[4,5,1]  R1644     -7.0843541622161865e-01
    z[4,5,1]  R1645     -7.9341602325439453e-01
    z[4,5,1]  R1646     1.4412711560726166e-01
    z[4,5,1]  R1647     4.8449043184518814e-02
    z[4,5,1]  R1648     3.6293938755989075e-02
    z[4,5,1]  R1649     2.6854671537876129e-02
    z[4,5,1]  R1650     1.5831999480724335e-01
    z[4,5,1]  R1651     8.5295155644416809e-02
    z[4,5,1]  R1652     -2.6950734853744507e-01
    z[4,5,1]  R1653     5.7463991641998291e-01
    z[4,5,1]  R1654     5.6482058763504028e-01
    z[4,5,1]  R1655     -3.7953183054924011e-01
    z[4,5,1]  R1656     0.565430760383606
    z[4,5,1]  R1657     5.3390699625015259e-01
    z[4,5,1]  R1658     5.3784149885177612e-01
    z[4,5,1]  R1659     5.2749764919281006e-01
    z[4,5,1]  R1660     5.2360785007476807e-01
    z[4,5,1]  R1661     5.2429425716400146e-01
    z[4,5,1]  R1662     9.0753048658370972e-01
    z[4,5,1]  R1663     0.748072624206543
    z[4,5,1]  R1664     7.4286442995071411e-01
    z[4,5,1]  R1665     6.9485700130462646e-01
    z[4,5,1]  R1666     7.0424479246139526e-01
    z[4,5,1]  R1667     6.7752861976623535e-01
    z[4,5,1]  R1668     9.1798293590545654e-01
    z[4,5,1]  R1669     6.1748200654983521e-01
    z[4,5,1]  R1670     6.4499658346176147e-01
    z[4,5,1]  R1671     5.7632488012313843e-01
    z[4,5,1]  R1672     7.7760022878646851e-01
    z[4,5,1]  R1673     -9.0361207723617554e-01
    z[4,5,1]  R1674     -1.7615698277950287e-01
    z[4,5,1]  R1675     -5.1598149538040161e-01
    z[4,5,1]  R1676     0.626396119594574
    z[4,5,1]  R1677     -7.8454130887985229e-01
    z[4,5,1]  R1678     -0.581381618976593
    z[4,5,1]  R1679     -7.5596773624420166e-01
    z[4,5,1]  R1680     -5.0138765573501587e-01
    z[4,5,1]  R1681     0.490298867225647
    z[4,5,1]  R1682     -6.1461544036865234e-01
    z[4,5,1]  R1683     -6.7476719617843628e-01
    z[4,5,1]  R1684     -6.0727447271347046e-01
    z[4,5,1]  R1685     -5.2752667665481567e-01
    z[4,5,1]  R1686     6.1117631196975708e-01
    z[4,5,1]  R1687     -2.7636510133743286e-01
    z[4,5,1]  R1688     -3.8241308927536011e-01
    z[4,5,1]  R1689     5.4164856672286987e-01
    z[4,5,1]  R1690     5.3805696964263916e-01
    z[4,5,1]  R1691     -5.3642332553863525e-01
    z[4,5,1]  R1692     0.78980952501297
    z[4,5,1]  R1693     -0.394027978181839
    z[4,5,1]  R1694     6.7369186878204346e-01
    z[4,5,1]  R1695     6.8686366081237793e-01
    z[4,5,1]  R1696     6.5545284748077393e-01
    z[4,5,1]  R1697     6.3525545597076416e-01
    z[4,5,1]  R1698     6.1144155263900757e-01
    z[4,5,1]  R1699     -3.1257885694503784e-01
    z[4,5,1]  R1700     2.7013579010963440e-01
    z[4,5,1]  R1701     3.7967661023139954e-01
    z[4,5,1]  R1702     -2.4036408960819244e-01
    z[4,5,1]  R1703     7.7581125497817993e-01
    z[4,5,1]  R1704     6.8602418899536133e-01
    z[4,5,1]  R1705     0.779254138469696
    z[4,5,1]  R1706     7.6636826992034912e-01
    z[4,5,1]  R1707     6.4768815040588379e-01
    z[4,5,1]  R1708     -7.5179100036621094e-01
    z[4,5,1]  R1709     6.0951977968215942e-01
    z[4,5,1]  R1710     5.1368170976638794e-01
    z[4,5,1]  R1711     2.6094493269920349e-01
    z[4,5,1]  R1712     7.8289997577667236e-01
    z[4,5,1]  R1713     -5.7558339834213257e-01
    z[4,5,1]  R1714     6.9318550825119019e-01
    z[4,5,1]  R1715     7.2563600540161133e-01
    z[4,5,1]  R1716     6.3837128877639771e-01
    z[4,5,1]  R1717     6.3189369440078735e-01
    z[4,5,1]  R1718     7.0856159925460815e-01
    z[4,5,1]  R1719     2.7772587537765503e-01
    z[4,5,1]  R1720     -1.1194500327110291e-01
    z[4,5,1]  R1721     0.00939845945686102
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R1592     -1
    z[4,5,2]  R1593     1
    z[4,5,2]  R1602     -4.8892641067504883e-01
    z[4,5,2]  R1603     -6.2998455762863159e-01
    z[4,5,2]  R1604     -5.6363517045974731e-01
    z[4,5,2]  R1605     -3.2378584146499634e-01
    z[4,5,2]  R1606     -1.9953134655952454e-01
    z[4,5,2]  R1607     -0.620113730430603
    z[4,5,2]  R1608     6.2657386064529419e-02
    z[4,5,2]  R1609     -2.6013249158859253e-01
    z[4,5,2]  R1610     -0.434576153755188
    z[4,5,2]  R1611     3.1460583209991455e-02
    z[4,5,2]  R1612     0.271842360496521
    z[4,5,2]  R1613     2.4250237643718719e-01
    z[4,5,2]  R1614     1.0891170054674149e-01
    z[4,5,2]  R1615     2.4245100095868111e-02
    z[4,5,2]  R1616     0.0978781208395958
    z[4,5,2]  R1617     5.7753545045852661e-01
    z[4,5,2]  R1618     1.5783621370792389e-01
    z[4,5,2]  R1619     1.7953260242938995e-01
    z[4,5,2]  R1620     5.6387925148010254e-01
    z[4,5,2]  R1621     0.560340166091919
    z[4,5,2]  R1622     2.2890008985996246e-01
    z[4,5,2]  R1623     1.7778469622135162e-01
    z[4,5,2]  R1624     4.6568965911865234e-01
    z[4,5,2]  R1625     3.6825489997863770e-01
    z[4,5,2]  R1626     2.3756980895996094e-01
    z[4,5,2]  R1627     6.1661440134048462e-01
    z[4,5,2]  R1628     3.5787844657897949e-01
    z[4,5,2]  R1629     -5.4644995927810669e-01
    z[4,5,2]  R1630     2.2522220015525818e-01
    z[4,5,2]  R1631     4.9367386102676392e-01
    z[4,5,2]  R1632     -4.3730321526527405e-01
    z[4,5,2]  R1633     -5.3622430562973022e-01
    z[4,5,2]  R1634     -3.2214820384979248e-02
    z[4,5,2]  R1635     -6.5103453397750854e-01
    z[4,5,2]  R1636     4.4995138049125671e-01
    z[4,5,2]  R1637     3.8770538568496704e-01
    z[4,5,2]  R1638     0.274767130613327
    z[4,5,2]  R1639     2.0365764200687408e-01
    z[4,5,2]  R1640     -1.8638806045055389e-01
    z[4,5,2]  R1641     4.1917601227760315e-01
    z[4,5,2]  R1642     -5.8089841157197952e-02
    z[4,5,2]  R1643     5.3781740367412567e-02
    z[4,5,2]  R1644     -1.1235842853784561e-01
    z[4,5,2]  R1645     -4.2453482747077942e-01
    z[4,5,2]  R1646     -8.6770063638687134e-01
    z[4,5,2]  R1647     1.2496147304773331e-02
    z[4,5,2]  R1648     -7.4474133551120758e-02
    z[4,5,2]  R1649     -1.9873550534248352e-01
    z[4,5,2]  R1650     -7.3844176530838013e-01
    z[4,5,2]  R1651     -9.2770171165466309e-01
    z[4,5,2]  R1652     -2.9775600880384445e-02
    z[4,5,2]  R1653     1.2454776465892792e-01
    z[4,5,2]  R1654     9.0335153043270111e-02
    z[4,5,2]  R1655     -2.0008639991283417e-01
    z[4,5,2]  R1656     -3.3128419518470764e-01
    z[4,5,2]  R1657     3.8284385204315186e-01
    z[4,5,2]  R1658     0.548805832862854
    z[4,5,2]  R1659     -3.3939346671104431e-02
    z[4,5,2]  R1660     2.1307025104761124e-02
    z[4,5,2]  R1661     -2.2281266748905182e-01
    z[4,5,2]  R1662     -1.8753020465373993e-01
    z[4,5,2]  R1663     2.6691302657127380e-01
    z[4,5,2]  R1664     4.9662747979164124e-01
    z[4,5,2]  R1665     3.2873785495758057e-01
    z[4,5,2]  R1666     2.5061208009719849e-01
    z[4,5,2]  R1667     -0.0669524073600769
    z[4,5,2]  R1668     1.6005863249301910e-01
    z[4,5,2]  R1669     -5.4143619537353516e-01
    z[4,5,2]  R1670     7.7883955091238022e-03
    z[4,5,2]  R1671     3.4595331549644470e-01
    z[4,5,2]  R1672     1.3240396045148373e-02
    z[4,5,2]  R1673     -1.9565263390541077e-01
    z[4,5,2]  R1674     1.5860426425933838e-01
    z[4,5,2]  R1675     -1.4689028263092041e-01
    z[4,5,2]  R1676     -1.6035205125808716e-01
    z[4,5,2]  R1677     9.1213919222354889e-02
    z[4,5,2]  R1678     2.4535308778285980e-01
    z[4,5,2]  R1679     3.2142975926399231e-01
    z[4,5,2]  R1680     4.4560468196868896e-01
    z[4,5,2]  R1681     -6.0879337787628174e-01
    z[4,5,2]  R1682     -1.8976964056491852e-01
    z[4,5,2]  R1683     1.0416872799396515e-01
    z[4,5,2]  R1684     -0.0739772841334343
    z[4,5,2]  R1685     -3.9403924345970154e-01
    z[4,5,2]  R1686     -3.6850400269031525e-02
    z[4,5,2]  R1687     9.6790334209799767e-03
    z[4,5,2]  R1688     -1.1283116042613983e-01
    z[4,5,2]  R1689     -5.8049482107162476e-01
    z[4,5,2]  R1690     -3.1603699922561646e-01
    z[4,5,2]  R1691     -2.2508840262889862e-01
    z[4,5,2]  R1692     -2.2061146795749664e-01
    z[4,5,2]  R1693     6.5723694860935211e-02
    z[4,5,2]  R1694     1.0464729368686676e-01
    z[4,5,2]  R1695     -3.3608219027519226e-01
    z[4,5,2]  R1696     1.2708115577697754e-01
    z[4,5,2]  R1697     -1.5526810288429260e-01
    z[4,5,2]  R1698     5.6466263532638550e-01
    z[4,5,2]  R1699     2.2702223062515259e-01
    z[4,5,2]  R1700     3.7101350724697113e-02
    z[4,5,2]  R1701     -7.1581047773361206e-01
    z[4,5,2]  R1702     -5.6525085121393204e-02
    z[4,5,2]  R1703     1.6549895703792572e-01
    z[4,5,2]  R1704     2.0005920529365540e-01
    z[4,5,2]  R1705     5.7398986071348190e-02
    z[4,5,2]  R1706     5.1809096336364746e-01
    z[4,5,2]  R1707     3.2539409399032593e-01
    z[4,5,2]  R1708     4.1225567460060120e-01
    z[4,5,2]  R1709     -5.2013248205184937e-02
    z[4,5,2]  R1710     -0.448064386844635
    z[4,5,2]  R1711     -7.5722610950469971e-01
    z[4,5,2]  R1712     1.5022765100002289e-01
    z[4,5,2]  R1713     3.5219088196754456e-02
    z[4,5,2]  R1714     -2.9492512345314026e-01
    z[4,5,2]  R1715     6.9097101688385010e-02
    z[4,5,2]  R1716     4.5762678980827332e-01
    z[4,5,2]  R1717     2.9374626278877258e-01
    z[4,5,2]  R1718     3.4706103801727295e-01
    z[4,5,2]  R1719     3.4038335084915161e-02
    z[4,5,2]  R1720     4.5589277148246765e-01
    z[4,5,2]  R1721     2.3930977284908295e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R1594     -1
    z[4,5,3]  R1595     1
    z[4,5,3]  R1602     1.7601533234119415e-01
    z[4,5,3]  R1603     6.3435681164264679e-02
    z[4,5,3]  R1604     5.8566421270370483e-01
    z[4,5,3]  R1605     -3.1957533210515976e-02
    z[4,5,3]  R1606     5.4880738258361816e-01
    z[4,5,3]  R1607     1.8849761784076691e-01
    z[4,5,3]  R1608     -4.1592246294021606e-01
    z[4,5,3]  R1609     4.2277574539184570e-02
    z[4,5,3]  R1610     1.8614079058170319e-01
    z[4,5,3]  R1611     -4.5220154523849487e-01
    z[4,5,3]  R1612     5.7858824729919434e-01
    z[4,5,3]  R1613     5.5579996109008789e-01
    z[4,5,3]  R1614     4.6628028154373169e-01
    z[4,5,3]  R1615     4.5316961407661438e-01
    z[4,5,3]  R1616     3.1654286384582520e-01
    z[4,5,3]  R1617     -0.199876606464386
    z[4,5,3]  R1618     -8.6203165352344513e-02
    z[4,5,3]  R1619     -7.4223525822162628e-02
    z[4,5,3]  R1620     -4.8704904317855835e-01
    z[4,5,3]  R1621     -7.8237777948379517e-01
    z[4,5,3]  R1622     2.0347169041633606e-01
    z[4,5,3]  R1623     6.4545780420303345e-01
    z[4,5,3]  R1624     -4.2889210581779480e-01
    z[4,5,3]  R1625     -2.3227228224277496e-01
    z[4,5,3]  R1626     4.8670306801795959e-01
    z[4,5,3]  R1627     -3.0853557586669922e-01
    z[4,5,3]  R1628     2.4328298866748810e-01
    z[4,5,3]  R1629     3.3010223507881165e-01
    z[4,5,3]  R1630     -3.7748065590858459e-01
    z[4,5,3]  R1631     3.1534847617149353e-01
    z[4,5,3]  R1632     -0.0200671274214983
    z[4,5,3]  R1633     -3.9867699146270752e-02
    z[4,5,3]  R1634     3.2048463821411133e-01
    z[4,5,3]  R1635     3.5661211609840393e-01
    z[4,5,3]  R1636     -1.7238807678222656e-01
    z[4,5,3]  R1637     -5.8072954416275024e-01
    z[4,5,3]  R1638     -2.3731626570224762e-01
    z[4,5,3]  R1639     -4.9800008535385132e-01
    z[4,5,3]  R1640     -5.2545249462127686e-01
    z[4,5,3]  R1641     -4.3838983774185181e-01
    z[4,5,3]  R1642     -4.0296635031700134e-01
    z[4,5,3]  R1643     -5.3747254610061646e-01
    z[4,5,3]  R1644     3.8999652862548828e-01
    z[4,5,3]  R1645     1.8943159282207489e-01
    z[4,5,3]  R1646     -5.6672533974051476e-03
    z[4,5,3]  R1647     -6.5534913539886475e-01
    z[4,5,3]  R1648     -7.3129677772521973e-01
    z[4,5,3]  R1649     -4.1921964287757874e-01
    z[4,5,3]  R1650     -5.7796392589807510e-02
    z[4,5,3]  R1651     -1.8595364689826965e-01
    z[4,5,3]  R1652     4.8870390653610229e-01
    z[4,5,3]  R1653     5.2809065580368042e-01
    z[4,5,3]  R1654     -1.1364148557186127e-01
    z[4,5,3]  R1655     1.1756717227399349e-02
    z[4,5,3]  R1656     3.9626678824424744e-01
    z[4,5,3]  R1657     4.6743705868721008e-01
    z[4,5,3]  R1658     -5.4867319762706757e-02
    z[4,5,3]  R1659     3.5917188972234726e-02
    z[4,5,3]  R1660     1.1144948750734329e-01
    z[4,5,3]  R1661     4.9830180406570435e-01
    z[4,5,3]  R1662     -0.0093460688367486
    z[4,5,3]  R1663     -3.8008257746696472e-01
    z[4,5,3]  R1664     3.7454792857170105e-01
    z[4,5,3]  R1665     -2.9269483685493469e-01
    z[4,5,3]  R1666     1.7930108308792114e-01
    z[4,5,3]  R1667     -1.6624249517917633e-01
    z[4,5,3]  R1668     -2.1269553899765015e-01
    z[4,5,3]  R1669     -1.9685249030590057e-01
    z[4,5,3]  R1670     3.4639306366443634e-02
    z[4,5,3]  R1671     2.5832358002662659e-01
    z[4,5,3]  R1672     -2.4320723116397858e-01
    z[4,5,3]  R1673     1.0809340327978134e-01
    z[4,5,3]  R1674     6.3858258724212646e-01
    z[4,5,3]  R1675     6.7080706357955933e-01
    z[4,5,3]  R1676     5.9035187959671021e-01
    z[4,5,3]  R1677     0.41353839635849
    z[4,5,3]  R1678     0.696344792842865
    z[4,5,3]  R1679     5.4434329271316528e-01
    z[4,5,3]  R1680     2.2740148007869720e-01
    z[4,5,3]  R1681     -3.5715955495834351e-01
    z[4,5,3]  R1682     5.2272051572799683e-01
    z[4,5,3]  R1683     1.8101263046264648e-01
    z[4,5,3]  R1684     4.3131539225578308e-01
    z[4,5,3]  R1685     2.4780897796154022e-01
    z[4,5,3]  R1686     0.7169149518013
    z[4,5,3]  R1687     1.5931184589862823e-01
    z[4,5,3]  R1688     -2.0667349454015493e-03
    z[4,5,3]  R1689     -1.7180286347866058e-01
    z[4,5,3]  R1690     -7.6556265354156494e-01
    z[4,5,3]  R1691     -2.7293208241462708e-01
    z[4,5,3]  R1692     -1.2084152549505234e-01
    z[4,5,3]  R1693     3.8940033316612244e-01
    z[4,5,3]  R1694     3.7436354160308838e-01
    z[4,5,3]  R1695     4.2552683502435684e-02
    z[4,5,3]  R1696     0.262176513671875
    z[4,5,3]  R1697     6.1868435144424438e-01
    z[4,5,3]  R1698     -3.8611480593681335e-01
    z[4,5,3]  R1699     7.3401367664337158e-01
    z[4,5,3]  R1700     -4.6521016955375671e-01
    z[4,5,3]  R1701     -7.6276063919067383e-02
    z[4,5,3]  R1702     7.2090637683868408e-01
    z[4,5,3]  R1703     4.6992671489715576e-01
    z[4,5,3]  R1704     -4.0821766853332520e-01
    z[4,5,3]  R1705     3.0732184648513794e-02
    z[4,5,3]  R1706     1.4271210134029388e-01
    z[4,5,3]  R1707     3.1659308820962906e-02
    z[4,5,3]  R1708     4.8740115761756897e-01
    z[4,5,3]  R1709     1.3294823467731476e-01
    z[4,5,3]  R1710     -4.0946012735366821e-01
    z[4,5,3]  R1711     -5.2992874383926392e-01
    z[4,5,3]  R1712     -4.6401867270469666e-01
    z[4,5,3]  R1713     7.6905030012130737e-01
    z[4,5,3]  R1714     -2.9391431808471680e-01
    z[4,5,3]  R1715     -2.2351497411727905e-01
    z[4,5,3]  R1716     1.0619022697210312e-01
    z[4,5,3]  R1717     -1.0161448270082474e-01
    z[4,5,3]  R1718     1.7341688275337219e-02
    z[4,5,3]  R1719     -4.0813955664634705e-01
    z[4,5,3]  R1720     -5.1933777332305908e-01
    z[4,5,3]  R1721     -8.2367813587188721e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R1596     -1
    z[4,5,4]  R1597     1
    z[4,5,4]  R1602     1.0856717824935913e-02
    z[4,5,4]  R1603     -6.5588361024856567e-01
    z[4,5,4]  R1604     1.2484563887119293e-01
    z[4,5,4]  R1605     -1.9584220647811890e-01
    z[4,5,4]  R1606     4.2634099721908569e-01
    z[4,5,4]  R1607     1.5479709208011627e-01
    z[4,5,4]  R1608     -1.2218625284731388e-02
    z[4,5,4]  R1609     1.0611588507890701e-01
    z[4,5,4]  R1610     1.1072899401187897e-01
    z[4,5,4]  R1611     2.9332062602043152e-01
    z[4,5,4]  R1612     -5.2169007062911987e-01
    z[4,5,4]  R1613     1.5225443989038467e-02
    z[4,5,4]  R1614     -2.0152826607227325e-01
    z[4,5,4]  R1615     -1.9289699196815491e-01
    z[4,5,4]  R1616     -3.3994954824447632e-01
    z[4,5,4]  R1617     -8.9647211134433746e-02
    z[4,5,4]  R1618     1.7738105356693268e-01
    z[4,5,4]  R1619     -9.9142849445343018e-02
    z[4,5,4]  R1620     -1.1770591139793396e-01
    z[4,5,4]  R1621     1.3046446442604065e-01
    z[4,5,4]  R1622     3.9614226669073105e-02
    z[4,5,4]  R1623     -1.8910236656665802e-02
    z[4,5,4]  R1624     -9.0951457619667053e-02
    z[4,5,4]  R1625     -1.7323465645313263e-01
    z[4,5,4]  R1626     -1.4452171325683594e-01
    z[4,5,4]  R1627     1.5978337824344635e-01
    z[4,5,4]  R1628     4.5616424083709717e-01
    z[4,5,4]  R1629     -1.4891673624515533e-01
    z[4,5,4]  R1630     2.0689669251441956e-01
    z[4,5,4]  R1631     3.5767704248428345e-01
    z[4,5,4]  R1632     -3.1594979763031006e-01
    z[4,5,4]  R1633     0.0851435512304306
    z[4,5,4]  R1634     -2.1339073777198792e-01
    z[4,5,4]  R1635     -2.2136293351650238e-01
    z[4,5,4]  R1636     -3.1325586140155792e-02
    z[4,5,4]  R1637     -2.7960114181041718e-02
    z[4,5,4]  R1638     2.5202789902687073e-01
    z[4,5,4]  R1639     3.7080907821655273e-01
    z[4,5,4]  R1640     -5.0051814317703247e-01
    z[4,5,4]  R1641     -2.6815861463546753e-01
    z[4,5,4]  R1642     7.5176376104354858e-01
    z[4,5,4]  R1643     -1.4871887862682343e-01
    z[4,5,4]  R1644     -3.7163731455802917e-01
    z[4,5,4]  R1645     1.2865507602691650e-01
    z[4,5,4]  R1646     -0.0733717754483223
    z[4,5,4]  R1647     1.1783973127603531e-01
    z[4,5,4]  R1648     5.4849749803543091e-01
    z[4,5,4]  R1649     6.2639951705932617e-01
    z[4,5,4]  R1650     -3.5146933794021606e-01
    z[4,5,4]  R1651     5.0835222005844116e-02
    z[4,5,4]  R1652     -5.0168275833129883e-01
    z[4,5,4]  R1653     6.0711979866027832e-01
    z[4,5,4]  R1654     4.4273640960454941e-02
    z[4,5,4]  R1655     -6.4374852180480957e-01
    z[4,5,4]  R1656     -1.6002447903156281e-01
    z[4,5,4]  R1657     -8.7334312498569489e-02
    z[4,5,4]  R1658     -1.5916512906551361e-01
    z[4,5,4]  R1659     1.2083603441715240e-01
    z[4,5,4]  R1660     -2.5509238243103027e-01
    z[4,5,4]  R1661     4.1140943765640259e-01
    z[4,5,4]  R1662     1.1140716820955276e-01
    z[4,5,4]  R1663     3.7780648469924927e-01
    z[4,5,4]  R1664     6.9314420223236084e-02
    z[4,5,4]  R1665     -2.4283558130264282e-01
    z[4,5,4]  R1666     -3.4706154465675354e-01
    z[4,5,4]  R1667     -5.9952008724212646e-01
    z[4,5,4]  R1668     -1.4264552295207977e-01
    z[4,5,4]  R1669     -1.0346832871437073e-01
    z[4,5,4]  R1670     -7.5108265876770020e-01
    z[4,5,4]  R1671     2.7828735113143921e-01
    z[4,5,4]  R1672     -9.1508477926254272e-02
    z[4,5,4]  R1673     -1.3764876127243042e-01
    z[4,5,4]  R1674     -6.9223576784133911e-01
    z[4,5,4]  R1675     2.3049761354923248e-01
    z[4,5,4]  R1676     9.2276886105537415e-02
    z[4,5,4]  R1677     -3.3010292053222656e-01
    z[4,5,4]  R1678     -2.3575066030025482e-01
    z[4,5,4]  R1679     1.2148077040910721e-01
    z[4,5,4]  R1680     -3.9655703306198120e-01
    z[4,5,4]  R1681     5.3671054542064667e-02
    z[4,5,4]  R1682     -0.0931900143623352
    z[4,5,4]  R1683     -1.9064508378505707e-01
    z[4,5,4]  R1684     4.2088195681571960e-02
    z[4,5,4]  R1685     -0.507418155670166
    z[4,5,4]  R1686     -1.3674655556678772e-01
    z[4,5,4]  R1687     -8.7358540296554565e-01
    z[4,5,4]  R1688     -8.1932795047760010e-01
    z[4,5,4]  R1689     -2.0943273603916168e-01
    z[4,5,4]  R1690     -1.3228332996368408e-01
    z[4,5,4]  R1691     -4.2033135890960693e-01
    z[4,5,4]  R1692     -2.4451339244842529e-01
    z[4,5,4]  R1693     -6.7833763360977173e-01
    z[4,5,4]  R1694     -4.1297331452369690e-01
    z[4,5,4]  R1695     0.0561286062002182
    z[4,5,4]  R1696     0.399565726518631
    z[4,5,4]  R1697     -3.4178376197814941e-01
    z[4,5,4]  R1698     8.4828995168209076e-02
    z[4,5,4]  R1699     -4.6115365624427795e-01
    z[4,5,4]  R1700     3.9002561569213867e-01
    z[4,5,4]  R1701     0.259692519903183
    z[4,5,4]  R1702     -4.6415838599205017e-01
    z[4,5,4]  R1703     -2.7864843606948853e-01
    z[4,5,4]  R1704     1.4217145740985870e-01
    z[4,5,4]  R1705     2.3603625595569611e-01
    z[4,5,4]  R1706     -4.6134196221828461e-02
    z[4,5,4]  R1707     -5.6159579753875732e-01
    z[4,5,4]  R1708     -1.1255256086587906e-01
    z[4,5,4]  R1709     1.5449588000774384e-01
    z[4,5,4]  R1710     2.8930687904357910e-01
    z[4,5,4]  R1711     2.2097003459930420e-01
    z[4,5,4]  R1712     9.5833852887153625e-02
    z[4,5,4]  R1713     -1.8232512474060059e-01
    z[4,5,4]  R1714     -3.0767528340220451e-02
    z[4,5,4]  R1715     3.5154440999031067e-01
    z[4,5,4]  R1716     -6.1790518462657928e-02
    z[4,5,4]  R1717     -3.3919781446456909e-01
    z[4,5,4]  R1718     4.1360324621200562e-01
    z[4,5,4]  R1719     0.440787136554718
    z[4,5,4]  R1720     3.1244885921478271e-01
    z[4,5,4]  R1721     1.8467611074447632e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R1598     -1
    z[4,5,5]  R1599     1
    z[4,5,5]  R1602     4.3001264333724976e-01
    z[4,5,5]  R1603     8.8137343525886536e-02
    z[4,5,5]  R1604     -2.9693683981895447e-01
    z[4,5,5]  R1605     -1.1963365972042084e-01
    z[4,5,5]  R1606     1.2636837363243103e-01
    z[4,5,5]  R1607     -5.9129250049591064e-01
    z[4,5,5]  R1608     3.1540271639823914e-01
    z[4,5,5]  R1609     0.552384614944458
    z[4,5,5]  R1610     6.9784924387931824e-02
    z[4,5,5]  R1611     -7.4164181947708130e-02
    z[4,5,5]  R1612     -7.4610225856304169e-03
    z[4,5,5]  R1613     4.2120195925235748e-02
    z[4,5,5]  R1614     1.1479678004980087e-01
    z[4,5,5]  R1615     -2.1093097329139709e-01
    z[4,5,5]  R1616     -1.3658192753791809e-01
    z[4,5,5]  R1617     -2.2241917252540588e-01
    z[4,5,5]  R1618     -7.5781798362731934e-01
    z[4,5,5]  R1619     -7.0537918806076050e-01
    z[4,5,5]  R1620     -1.0778035968542099e-01
    z[4,5,5]  R1621     -4.7113727778196335e-02
    z[4,5,5]  R1622     -8.1583723425865173e-02
    z[4,5,5]  R1623     1.5470467507839203e-01
    z[4,5,5]  R1624     -9.5077134668827057e-02
    z[4,5,5]  R1625     -4.2949426174163818e-01
    z[4,5,5]  R1626     3.4728178381919861e-01
    z[4,5,5]  R1627     0.0904572531580925
    z[4,5,5]  R1628     -1.4110137522220612e-01
    z[4,5,5]  R1629     1.1845245212316513e-01
    z[4,5,5]  R1630     -3.1538268923759460e-01
    z[4,5,5]  R1631     1.9393399357795715e-01
    z[4,5,5]  R1632     4.2377910017967224e-01
    z[4,5,5]  R1633     -0.395780086517334
    z[4,5,5]  R1634     -1.7386563122272491e-02
    z[4,5,5]  R1635     -2.4130217730998993e-01
    z[4,5,5]  R1636     -1.4675861597061157e-01
    z[4,5,5]  R1637     -4.1860324144363403e-01
    z[4,5,5]  R1638     -4.0268743038177490e-01
    z[4,5,5]  R1639     -6.7394733428955078e-01
    z[4,5,5]  R1640     -0.511361837387085
    z[4,5,5]  R1641     0.00314392801374197
    z[4,5,5]  R1642     2.9332739114761353e-01
    z[4,5,5]  R1643     7.1510946750640869e-01
    z[4,5,5]  R1644     -5.2475024014711380e-02
    z[4,5,5]  R1645     1.7414024472236633e-01
    z[4,5,5]  R1646     9.1644853353500366e-02
    z[4,5,5]  R1647     6.1001843214035034e-01
    z[4,5,5]  R1648     -2.6714442297816277e-02
    z[4,5,5]  R1649     4.9909198284149170e-01
    z[4,5,5]  R1650     0.280887246131897
    z[4,5,5]  R1651     5.7129483669996262e-02
    z[4,5,5]  R1652     -5.3611123561859131e-01
    z[4,5,5]  R1653     1.0503428988158703e-02
    z[4,5,5]  R1654     7.6457291841506958e-02
    z[4,5,5]  R1655     4.8521704971790314e-02
    z[4,5,5]  R1656     -2.2446073591709137e-02
    z[4,5,5]  R1657     -5.6388586759567261e-01
    z[4,5,5]  R1658     2.0568537712097168e-01
    z[4,5,5]  R1659     -4.4070816040039062e-01
    z[4,5,5]  R1660     4.6067759394645691e-01
    z[4,5,5]  R1661     -2.2795550525188446e-01
    z[4,5,5]  R1662     7.8413665294647217e-02
    z[4,5,5]  R1663     3.5060279071331024e-02
    z[4,5,5]  R1664     -7.6172329485416412e-02
    z[4,5,5]  R1665     -4.0887433290481567e-01
    z[4,5,5]  R1666     2.1426714956760406e-01
    z[4,5,5]  R1667     -2.4813812971115112e-01
    z[4,5,5]  R1668     -3.8117133080959320e-02
    z[4,5,5]  R1669     -2.8980466723442078e-01
    z[4,5,5]  R1670     8.9521482586860657e-02
    z[4,5,5]  R1671     0.304259330034256
    z[4,5,5]  R1672     1.0470122098922729e-01
    z[4,5,5]  R1673     -0.138969287276268
    z[4,5,5]  R1674     1.0573318600654602e-01
    z[4,5,5]  R1675     -0.294136106967926
    z[4,5,5]  R1676     2.9178187251091003e-01
    z[4,5,5]  R1677     3.0617406964302063e-01
    z[4,5,5]  R1678     9.3371786177158356e-02
    z[4,5,5]  R1679     1.0456296615302563e-02
    z[4,5,5]  R1680     -2.1243534982204437e-01
    z[4,5,5]  R1681     1.9443942606449127e-01
    z[4,5,5]  R1682     -2.5983512401580811e-01
    z[4,5,5]  R1683     -5.2789688110351562e-01
    z[4,5,5]  R1684     -3.9663156867027283e-01
    z[4,5,5]  R1685     5.7480856776237488e-02
    z[4,5,5]  R1686     -1.6389995813369751e-01
    z[4,5,5]  R1687     -1.2786342203617096e-01
    z[4,5,5]  R1688     -8.8494569063186646e-02
    z[4,5,5]  R1689     -3.5261037945747375e-01
    z[4,5,5]  R1690     2.0087789744138718e-02
    z[4,5,5]  R1691     -4.8231580853462219e-01
    z[4,5,5]  R1692     -1.7192986607551575e-01
    z[4,5,5]  R1693     -1.9586364924907684e-01
    z[4,5,5]  R1694     -4.2953795194625854e-01
    z[4,5,5]  R1695     -5.1154899597167969e-01
    z[4,5,5]  R1696     -0.486591100692749
    z[4,5,5]  R1697     -1.6131840646266937e-01
    z[4,5,5]  R1698     -2.4157339334487915e-01
    z[4,5,5]  R1699     2.4367275834083557e-01
    z[4,5,5]  R1700     0.526871919631958
    z[4,5,5]  R1701     2.3944175243377686e-01
    z[4,5,5]  R1702     -2.7048933506011963e-01
    z[4,5,5]  R1703     -2.3300358653068542e-01
    z[4,5,5]  R1704     -5.4858249425888062e-01
    z[4,5,5]  R1705     -3.0323502421379089e-01
    z[4,5,5]  R1706     -3.1779669225215912e-02
    z[4,5,5]  R1707     2.1713009476661682e-01
    z[4,5,5]  R1708     1.5094964765012264e-02
    z[4,5,5]  R1709     6.5014606714248657e-01
    z[4,5,5]  R1710     3.6648404598236084e-01
    z[4,5,5]  R1711     -2.4043897166848183e-02
    z[4,5,5]  R1712     -3.4174686670303345e-01
    z[4,5,5]  R1713     -1.9944418221712112e-02
    z[4,5,5]  R1714     5.7126116752624512e-01
    z[4,5,5]  R1715     -2.7853599190711975e-01
    z[4,5,5]  R1716     2.5465330481529236e-01
    z[4,5,5]  R1717     4.6998324990272522e-01
    z[4,5,5]  R1718     1.0797326266765594e-01
    z[4,5,5]  R1719     5.5890262126922607e-01
    z[4,5,5]  R1720     5.9055322408676147e-01
    z[4,5,5]  R1721     3.2658642530441284e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R1600     -1
    z[4,5,6]  R1601     1
    z[4,5,6]  R1602     1.0290885716676712e-01
    z[4,5,6]  R1603     -2.3524037003517151e-01
    z[4,5,6]  R1604     -3.0866688489913940e-01
    z[4,5,6]  R1605     -5.3239649534225464e-01
    z[4,5,6]  R1606     -5.6580251455307007e-01
    z[4,5,6]  R1607     -5.3024794906377792e-02
    z[4,5,6]  R1608     -1.4246550202369690e-01
    z[4,5,6]  R1609     -4.1751712560653687e-01
    z[4,5,6]  R1610     -0.754396915435791
    z[4,5,6]  R1611     2.0032688975334167e-01
    z[4,5,6]  R1612     3.9272508025169373e-01
    z[4,5,6]  R1613     7.7948756515979767e-02
    z[4,5,6]  R1614     4.1360282897949219e-01
    z[4,5,6]  R1615     3.4510451555252075e-01
    z[4,5,6]  R1616     2.5842586159706116e-01
    z[4,5,6]  R1617     1.3538759946823120e-01
    z[4,5,6]  R1618     1.1551665514707565e-01
    z[4,5,6]  R1619     0.214536651968956
    z[4,5,6]  R1620     -5.3361082077026367e-01
    z[4,5,6]  R1621     7.8541055321693420e-02
    z[4,5,6]  R1622     3.4747272729873657e-01
    z[4,5,6]  R1623     0.0959746390581131
    z[4,5,6]  R1624     -1.4639247953891754e-01
    z[4,5,6]  R1625     -7.8190825879573822e-02
    z[4,5,6]  R1626     -1.7518197000026703e-01
    z[4,5,6]  R1627     5.3436309099197388e-02
    z[4,5,6]  R1628     -1.7086308449506760e-02
    z[4,5,6]  R1629     3.3168086409568787e-01
    z[4,5,6]  R1630     -3.6290207505226135e-01
    z[4,5,6]  R1631     -1.1606375873088837e-01
    z[4,5,6]  R1632     -6.0722154378890991e-01
    z[4,5,6]  R1633     -5.8641022443771362e-01
    z[4,5,6]  R1634     3.7587514519691467e-01
    z[4,5,6]  R1635     0.547369122505188
    z[4,5,6]  R1636     -6.0128502547740936e-02
    z[4,5,6]  R1637     0.365986168384552
    z[4,5,6]  R1638     -6.9392108917236328e-01
    z[4,5,6]  R1639     -2.9783570766448975e-01
    z[4,5,6]  R1640     -7.0330560207366943e-02
    z[4,5,6]  R1641     6.2200218439102173e-01
    z[4,5,6]  R1642     2.6621580123901367e-01
    z[4,5,6]  R1643     3.0010810494422913e-01
    z[4,5,6]  R1644     3.8044017553329468e-01
    z[4,5,6]  R1645     -1.7489826679229736e-01
    z[4,5,6]  R1646     -2.1970197558403015e-01
    z[4,5,6]  R1647     -3.9699527621269226e-01
    z[4,5,6]  R1648     -3.8570281863212585e-01
    z[4,5,6]  R1649     -3.3717584609985352e-01
    z[4,5,6]  R1650     4.0127000212669373e-01
    z[4,5,6]  R1651     -9.2358618974685669e-02
    z[4,5,6]  R1652     9.3364212661981583e-03
    z[4,5,6]  R1653     1.8575055524706841e-02
    z[4,5,6]  R1654     -0.686257541179657
    z[4,5,6]  R1655     -5.0712901353836060e-01
    z[4,5,6]  R1656     -5.4844814538955688e-01
    z[4,5,6]  R1657     1.1683385819196701e-01
    z[4,5,6]  R1658     5.8028733730316162e-01
    z[4,5,6]  R1659     5.6005173921585083e-01
    z[4,5,6]  R1660     4.2670068144798279e-01
    z[4,5,6]  R1661     4.0735989809036255e-01
    z[4,5,6]  R1662     3.3515495061874390e-01
    z[4,5,6]  R1663     -2.5011441111564636e-01
    z[4,5,6]  R1664     1.5784989297389984e-01
    z[4,5,6]  R1665     -3.0946299433708191e-01
    z[4,5,6]  R1666     -4.8117381334304810e-01
    z[4,5,6]  R1667     1.0222015529870987e-01
    z[4,5,6]  R1668     -2.2296211123466492e-01
    z[4,5,6]  R1669     -3.2010391354560852e-01
    z[4,5,6]  R1670     -4.7038231045007706e-02
    z[4,5,6]  R1671     -1.7150023579597473e-01
    z[4,5,6]  R1672     -4.5805448293685913e-01
    z[4,5,6]  R1673     1.5038771927356720e-01
    z[4,5,6]  R1674     1.9379927217960358e-01
    z[4,5,6]  R1675     -2.2031220793724060e-01
    z[4,5,6]  R1676     -3.7344902753829956e-01
    z[4,5,6]  R1677     1.1838621459901333e-02
    z[4,5,6]  R1678     -2.2365689277648926e-01
    z[4,5,6]  R1679     7.1575768291950226e-02
    z[4,5,6]  R1680     5.3573727607727051e-01
    z[4,5,6]  R1681     -4.0223711729049683e-01
    z[4,5,6]  R1682     -3.0935063958168030e-01
    z[4,5,6]  R1683     -3.0958059430122375e-01
    z[4,5,6]  R1684     4.9714437127113342e-01
    z[4,5,6]  R1685     -2.2677090764045715e-01
    z[4,5,6]  R1686     1.1971540749073029e-01
    z[4,5,6]  R1687     2.3050977289676666e-01
    z[4,5,6]  R1688     -1.7709574103355408e-01
    z[4,5,6]  R1689     1.2278091907501221e-01
    z[4,5,6]  R1690     -1.9041141495108604e-02
    z[4,5,6]  R1691     -1.4525135047733784e-02
    z[4,5,6]  R1692     2.0731000602245331e-01
    z[4,5,6]  R1693     3.8375315070152283e-01
    z[4,5,6]  R1694     1.6119308769702911e-01
    z[4,5,6]  R1695     -2.3104831576347351e-01
    z[4,5,6]  R1696     -2.9836845397949219e-01
    z[4,5,6]  R1697     9.6001133322715759e-02
    z[4,5,6]  R1698     1.9497525691986084e-01
    z[4,5,6]  R1699     -0.196414053440094
    z[4,5,6]  R1700     -4.4452720880508423e-01
    z[4,5,6]  R1701     -3.7463790178298950e-01
    z[4,5,6]  R1702     2.1984319388866425e-01
    z[4,5,6]  R1703     -1.3007242977619171e-01
    z[4,5,6]  R1704     -2.8052901849150658e-02
    z[4,5,6]  R1705     -4.9068778753280640e-01
    z[4,5,6]  R1706     5.1138266921043396e-02
    z[4,5,6]  R1707     2.4880664050579071e-01
    z[4,5,6]  R1708     0.0734206810593605
    z[4,5,6]  R1709     -3.3588579297065735e-01
    z[4,5,6]  R1710     -3.8576945662498474e-01
    z[4,5,6]  R1711     1.3432259857654572e-01
    z[4,5,6]  R1712     1.1812866479158401e-01
    z[4,5,6]  R1713     1.5472298860549927e-01
    z[4,5,6]  R1714     -0.0930066928267479
    z[4,5,6]  R1715     -4.6319490671157837e-01
    z[4,5,6]  R1716     -8.3471322432160378e-03
    z[4,5,6]  R1717     2.3221366107463837e-01
    z[4,5,6]  R1718     -2.5112757086753845e-01
    z[4,5,6]  R1719     2.6935908198356628e-01
    z[4,5,6]  R1720     1.2492532841861248e-02
    z[4,5,6]  R1721     3.2531628012657166e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R1722     -1
    z[5,4,0]  R1723     1
    z[5,4,0]  R1736     -3.3153480291366577e-01
    z[5,4,0]  R1737     -0.270396888256073
    z[5,4,0]  R1738     2.1862052381038666e-01
    z[5,4,0]  R1739     2.7732756733894348e-01
    z[5,4,0]  R1740     -4.0526506304740906e-01
    z[5,4,0]  R1741     -1.5620526671409607e-01
    z[5,4,0]  R1742     -8.9507259428501129e-02
    z[5,4,0]  R1743     -1.6994468867778778e-01
    z[5,4,0]  R1744     -0.250703364610672
    z[5,4,0]  R1745     2.8833541274070740e-01
    z[5,4,0]  R1746     0.385304719209671
    z[5,4,0]  R1747     0.0796690359711647
    z[5,4,0]  R1748     4.2561444640159607e-01
    z[5,4,0]  R1749     3.7661164999008179e-01
    z[5,4,0]  R1750     2.9428660869598389e-01
    z[5,4,0]  R1751     1.0311092436313629e-01
    z[5,4,0]  R1752     4.6421322971582413e-02
    z[5,4,0]  R1753     4.4364559650421143e-01
    z[5,4,0]  R1754     5.0357764959335327e-01
    z[5,4,0]  R1755     2.0000481605529785e-01
    z[5,4,0]  R1756     -1.0121417045593262e-01
    z[5,4,0]  R1757     -1.3475139439105988e-01
    z[5,4,0]  R1758     -1.6032533347606659e-01
    z[5,4,0]  R1759     -3.8989122956991196e-02
    z[5,4,0]  R1760     -1.0579904913902283e-01
    z[5,4,0]  R1761     2.7819040417671204e-01
    z[5,4,0]  R1762     -1.2221422046422958e-01
    z[5,4,0]  R1763     -2.9942116141319275e-01
    z[5,4,0]  R1764     9.1471262276172638e-02
    z[5,4,0]  R1765     5.3104126453399658e-01
    z[5,4,0]  R1766     3.2689875364303589e-01
    z[5,4,0]  R1767     2.6952734589576721e-01
    z[5,4,0]  R1768     8.9986763894557953e-02
    z[5,4,0]  R1769     2.7206912636756897e-01
    z[5,4,0]  R1770     1.6852578148245811e-02
    z[5,4,0]  R1771     4.8067674040794373e-02
    z[5,4,0]  R1772     5.0814390182495117e-02
    z[5,4,0]  R1773     -0.0943196564912796
    z[5,4,0]  R1774     -9.4523094594478607e-02
    z[5,4,0]  R1775     2.4276039004325867e-01
    z[5,4,0]  R1776     3.7563553452491760e-01
    z[5,4,0]  R1777     3.0035263299942017e-01
    z[5,4,0]  R1778     1.8295191228389740e-01
    z[5,4,0]  R1779     4.3913197517395020e-01
    z[5,4,0]  R1780     2.2637119889259338e-01
    z[5,4,0]  R1781     2.5595527887344360e-01
    z[5,4,0]  R1782     3.6129298806190491e-01
    z[5,4,0]  R1783     3.9604946970939636e-01
    z[5,4,0]  R1784     7.9146578907966614e-02
    z[5,4,0]  R1785     4.2139679193496704e-01
    z[5,4,0]  R1786     4.2497593164443970e-01
    z[5,4,0]  R1787     2.0740933716297150e-01
    z[5,4,0]  R1788     1.1835118383169174e-01
    z[5,4,0]  R1789     3.0861017107963562e-01
    z[5,4,0]  R1790     -6.9337459281086922e-03
    z[5,4,0]  R1791     1.9369046390056610e-01
    z[5,4,0]  R1792     -2.3375537991523743e-01
    z[5,4,0]  R1793     3.6900978535413742e-02
    z[5,4,0]  R1794     -2.8620123863220215e-01
    z[5,4,0]  R1795     2.6928946375846863e-01
    z[5,4,0]  R1796     2.8702870011329651e-01
    z[5,4,0]  R1797     3.2271936535835266e-02
    z[5,4,0]  R1798     -0.0276222862303257
    z[5,4,0]  R1799     9.2043019831180573e-03
    z[5,4,0]  R1800     -0.343716561794281
    z[5,4,0]  R1801     -2.2175729274749756e-01
    z[5,4,0]  R1802     -9.4915814697742462e-02
    z[5,4,0]  R1803     -2.2074216604232788e-01
    z[5,4,0]  R1804     2.9744111001491547e-02
    z[5,4,0]  R1805     1.0121062397956848e-01
    z[5,4,0]  R1806     9.6210852265357971e-02
    z[5,4,0]  R1807     1.3581463694572449e-01
    z[5,4,0]  R1808     -1.0095175355672836e-01
    z[5,4,0]  R1809     -5.4806601256132126e-02
    z[5,4,0]  R1810     5.5049747228622437e-01
    z[5,4,0]  R1811     -3.3798721432685852e-01
    z[5,4,0]  R1812     -3.6248758435249329e-01
    z[5,4,0]  R1813     -4.1941866278648376e-01
    z[5,4,0]  R1814     -2.5176367163658142e-01
    z[5,4,0]  R1815     -1.3267327845096588e-01
    z[5,4,0]  R1816     -2.8363308310508728e-01
    z[5,4,0]  R1817     6.3270486891269684e-02
    z[5,4,0]  R1818     1.0960305109620094e-02
    z[5,4,0]  R1819     0.143471822142601
    z[5,4,0]  R1820     -1.2894485890865326e-01
    z[5,4,0]  R1821     -1.7774090170860291e-01
    z[5,4,0]  R1822     -5.9229356050491333e-01
    z[5,4,0]  R1823     -6.4346569776535034e-01
    z[5,4,0]  R1824     -3.6360916495323181e-01
    z[5,4,0]  R1825     -0.664874255657196
    z[5,4,0]  R1826     -2.1831926703453064e-01
    z[5,4,0]  R1827     2.9715850949287415e-01
    z[5,4,0]  R1828     2.9847967624664307e-01
    z[5,4,0]  R1829     3.3534556627273560e-01
    z[5,4,0]  R1830     3.8330844044685364e-01
    z[5,4,0]  R1831     3.4660476446151733e-01
    z[5,4,0]  R1832     5.7784989476203918e-02
    z[5,4,0]  R1833     3.1476294994354248e-01
    z[5,4,0]  R1834     2.1589669585227966e-01
    z[5,4,0]  R1835     2.0634412765502930e-01
    z[5,4,0]  R1836     6.2413150072097778e-01
    z[5,4,0]  R1837     6.6744023561477661e-01
    z[5,4,0]  R1838     6.3662898540496826e-01
    z[5,4,0]  R1839     5.0223106145858765e-01
    z[5,4,0]  R1840     6.4914405345916748e-01
    z[5,4,0]  R1841     4.7491988539695740e-01
    z[5,4,0]  R1842     4.3309062719345093e-01
    z[5,4,0]  R1843     -4.1635531187057495e-01
    z[5,4,0]  R1844     5.1093876361846924e-01
    z[5,4,0]  R1845     4.8697581887245178e-01
    z[5,4,0]  R1846     -3.9949950575828552e-01
    z[5,4,0]  R1847     -3.7090122699737549e-01
    z[5,4,0]  R1848     6.1859232187271118e-01
    z[5,4,0]  R1849     -1.2515333294868469e-01
    z[5,4,0]  R1850     2.9414582252502441e-01
    z[5,4,0]  R1851     4.4930049777030945e-01
    z[5,4,0]  R1852     -1.1720172315835953e-01
    z[5,4,0]  R1853     -1.2280052155256271e-01
    z[5,4,0]  R1854     -5.0174880772829056e-02
    z[5,4,0]  R1855     2.2930721938610077e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R1724     -1
    z[5,4,1]  R1725     1
    z[5,4,1]  R1736     0.0476214662194252
    z[5,4,1]  R1737     1.0748263448476791e-01
    z[5,4,1]  R1738     -7.0843541622161865e-01
    z[5,4,1]  R1739     -7.9341602325439453e-01
    z[5,4,1]  R1740     1.4412711560726166e-01
    z[5,4,1]  R1741     4.8449043184518814e-02
    z[5,4,1]  R1742     3.6293938755989075e-02
    z[5,4,1]  R1743     2.6854671537876129e-02
    z[5,4,1]  R1744     1.5831999480724335e-01
    z[5,4,1]  R1745     8.5295155644416809e-02
    z[5,4,1]  R1746     -2.6950734853744507e-01
    z[5,4,1]  R1747     5.7463991641998291e-01
    z[5,4,1]  R1748     5.6482058763504028e-01
    z[5,4,1]  R1749     -3.7953183054924011e-01
    z[5,4,1]  R1750     0.565430760383606
    z[5,4,1]  R1751     5.3390699625015259e-01
    z[5,4,1]  R1752     5.3784149885177612e-01
    z[5,4,1]  R1753     5.2749764919281006e-01
    z[5,4,1]  R1754     5.2360785007476807e-01
    z[5,4,1]  R1755     5.2429425716400146e-01
    z[5,4,1]  R1756     9.0753048658370972e-01
    z[5,4,1]  R1757     0.748072624206543
    z[5,4,1]  R1758     7.4286442995071411e-01
    z[5,4,1]  R1759     6.9485700130462646e-01
    z[5,4,1]  R1760     7.0424479246139526e-01
    z[5,4,1]  R1761     6.7752861976623535e-01
    z[5,4,1]  R1762     9.1798293590545654e-01
    z[5,4,1]  R1763     6.1748200654983521e-01
    z[5,4,1]  R1764     6.4499658346176147e-01
    z[5,4,1]  R1765     5.7632488012313843e-01
    z[5,4,1]  R1766     7.7760022878646851e-01
    z[5,4,1]  R1767     -9.0361207723617554e-01
    z[5,4,1]  R1768     -1.7615698277950287e-01
    z[5,4,1]  R1769     -5.1598149538040161e-01
    z[5,4,1]  R1770     0.626396119594574
    z[5,4,1]  R1771     -7.8454130887985229e-01
    z[5,4,1]  R1772     -0.581381618976593
    z[5,4,1]  R1773     -7.5596773624420166e-01
    z[5,4,1]  R1774     -5.0138765573501587e-01
    z[5,4,1]  R1775     0.490298867225647
    z[5,4,1]  R1776     -6.1461544036865234e-01
    z[5,4,1]  R1777     -6.7476719617843628e-01
    z[5,4,1]  R1778     -6.0727447271347046e-01
    z[5,4,1]  R1779     -5.2752667665481567e-01
    z[5,4,1]  R1780     6.1117631196975708e-01
    z[5,4,1]  R1781     -2.7636510133743286e-01
    z[5,4,1]  R1782     -3.8241308927536011e-01
    z[5,4,1]  R1783     5.4164856672286987e-01
    z[5,4,1]  R1784     5.3805696964263916e-01
    z[5,4,1]  R1785     -5.3642332553863525e-01
    z[5,4,1]  R1786     0.78980952501297
    z[5,4,1]  R1787     -0.394027978181839
    z[5,4,1]  R1788     6.7369186878204346e-01
    z[5,4,1]  R1789     6.8686366081237793e-01
    z[5,4,1]  R1790     6.5545284748077393e-01
    z[5,4,1]  R1791     6.3525545597076416e-01
    z[5,4,1]  R1792     6.1144155263900757e-01
    z[5,4,1]  R1793     -3.1257885694503784e-01
    z[5,4,1]  R1794     2.7013579010963440e-01
    z[5,4,1]  R1795     3.7967661023139954e-01
    z[5,4,1]  R1796     -2.4036408960819244e-01
    z[5,4,1]  R1797     7.7581125497817993e-01
    z[5,4,1]  R1798     6.8602418899536133e-01
    z[5,4,1]  R1799     0.779254138469696
    z[5,4,1]  R1800     7.6636826992034912e-01
    z[5,4,1]  R1801     6.4768815040588379e-01
    z[5,4,1]  R1802     -7.5179100036621094e-01
    z[5,4,1]  R1803     6.0951977968215942e-01
    z[5,4,1]  R1804     5.1368170976638794e-01
    z[5,4,1]  R1805     2.6094493269920349e-01
    z[5,4,1]  R1806     7.8289997577667236e-01
    z[5,4,1]  R1807     -5.7558339834213257e-01
    z[5,4,1]  R1808     6.9318550825119019e-01
    z[5,4,1]  R1809     7.2563600540161133e-01
    z[5,4,1]  R1810     6.3837128877639771e-01
    z[5,4,1]  R1811     6.3189369440078735e-01
    z[5,4,1]  R1812     7.0856159925460815e-01
    z[5,4,1]  R1813     2.7772587537765503e-01
    z[5,4,1]  R1814     -1.1194500327110291e-01
    z[5,4,1]  R1815     0.00939845945686102
    z[5,4,1]  R1816     0.673723042011261
    z[5,4,1]  R1817     3.1906521320343018e-01
    z[5,4,1]  R1818     3.7437894940376282e-01
    z[5,4,1]  R1819     7.3310643434524536e-01
    z[5,4,1]  R1820     3.5284972190856934e-01
    z[5,4,1]  R1821     4.1465076804161072e-01
    z[5,4,1]  R1822     -5.9358751773834229e-01
    z[5,4,1]  R1823     -1.6057939827442169e-01
    z[5,4,1]  R1824     2.4091082811355591e-01
    z[5,4,1]  R1825     -4.6989148855209351e-01
    z[5,4,1]  R1826     -3.4238114953041077e-01
    z[5,4,1]  R1827     -7.3204773664474487e-01
    z[5,4,1]  R1828     -6.7584872245788574e-01
    z[5,4,1]  R1829     -6.9339352846145630e-01
    z[5,4,1]  R1830     -7.3640400171279907e-01
    z[5,4,1]  R1831     -6.5614819526672363e-01
    z[5,4,1]  R1832     -5.8755552768707275e-01
    z[5,4,1]  R1833     -5.5656814575195312e-01
    z[5,4,1]  R1834     -2.9664844274520874e-01
    z[5,4,1]  R1835     -0.0769195556640625
    z[5,4,1]  R1836     6.2265670299530029e-01
    z[5,4,1]  R1837     2.6981109380722046e-01
    z[5,4,1]  R1838     -3.9388540387153625e-01
    z[5,4,1]  R1839     -5.8104431629180908e-01
    z[5,4,1]  R1840     3.3632245659828186e-01
    z[5,4,1]  R1841     -5.1232308149337769e-01
    z[5,4,1]  R1842     6.2998533248901367e-01
    z[5,4,1]  R1843     -5.2235430479049683e-01
    z[5,4,1]  R1844     -5.2130079269409180e-01
    z[5,4,1]  R1845     4.9059343338012695e-01
    z[5,4,1]  R1846     -2.5148870423436165e-02
    z[5,4,1]  R1847     2.5600403547286987e-01
    z[5,4,1]  R1848     0.571380078792572
    z[5,4,1]  R1849     -1.6271811723709106e-01
    z[5,4,1]  R1850     -0.809425413608551
    z[5,4,1]  R1851     2.4708189070224762e-02
    z[5,4,1]  R1852     -3.8372665643692017e-01
    z[5,4,1]  R1853     1.2259277701377869e-01
    z[5,4,1]  R1854     -4.1192939877510071e-01
    z[5,4,1]  R1855     -3.4744560718536377e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R1726     -1
    z[5,4,2]  R1727     1
    z[5,4,2]  R1736     -5.8089841157197952e-02
    z[5,4,2]  R1737     5.3781740367412567e-02
    z[5,4,2]  R1738     -1.1235842853784561e-01
    z[5,4,2]  R1739     -4.2453482747077942e-01
    z[5,4,2]  R1740     -8.6770063638687134e-01
    z[5,4,2]  R1741     1.2496147304773331e-02
    z[5,4,2]  R1742     -7.4474133551120758e-02
    z[5,4,2]  R1743     -1.9873550534248352e-01
    z[5,4,2]  R1744     -7.3844176530838013e-01
    z[5,4,2]  R1745     -9.2770171165466309e-01
    z[5,4,2]  R1746     -2.9775600880384445e-02
    z[5,4,2]  R1747     1.2454776465892792e-01
    z[5,4,2]  R1748     9.0335153043270111e-02
    z[5,4,2]  R1749     -2.0008639991283417e-01
    z[5,4,2]  R1750     -3.3128419518470764e-01
    z[5,4,2]  R1751     3.8284385204315186e-01
    z[5,4,2]  R1752     0.548805832862854
    z[5,4,2]  R1753     -3.3939346671104431e-02
    z[5,4,2]  R1754     2.1307025104761124e-02
    z[5,4,2]  R1755     -2.2281266748905182e-01
    z[5,4,2]  R1756     -1.8753020465373993e-01
    z[5,4,2]  R1757     2.6691302657127380e-01
    z[5,4,2]  R1758     4.9662747979164124e-01
    z[5,4,2]  R1759     3.2873785495758057e-01
    z[5,4,2]  R1760     2.5061208009719849e-01
    z[5,4,2]  R1761     -0.0669524073600769
    z[5,4,2]  R1762     1.6005863249301910e-01
    z[5,4,2]  R1763     -5.4143619537353516e-01
    z[5,4,2]  R1764     7.7883955091238022e-03
    z[5,4,2]  R1765     3.4595331549644470e-01
    z[5,4,2]  R1766     1.3240396045148373e-02
    z[5,4,2]  R1767     -1.9565263390541077e-01
    z[5,4,2]  R1768     1.5860426425933838e-01
    z[5,4,2]  R1769     -1.4689028263092041e-01
    z[5,4,2]  R1770     -1.6035205125808716e-01
    z[5,4,2]  R1771     9.1213919222354889e-02
    z[5,4,2]  R1772     2.4535308778285980e-01
    z[5,4,2]  R1773     3.2142975926399231e-01
    z[5,4,2]  R1774     4.4560468196868896e-01
    z[5,4,2]  R1775     -6.0879337787628174e-01
    z[5,4,2]  R1776     -1.8976964056491852e-01
    z[5,4,2]  R1777     1.0416872799396515e-01
    z[5,4,2]  R1778     -0.0739772841334343
    z[5,4,2]  R1779     -3.9403924345970154e-01
    z[5,4,2]  R1780     -3.6850400269031525e-02
    z[5,4,2]  R1781     9.6790334209799767e-03
    z[5,4,2]  R1782     -1.1283116042613983e-01
    z[5,4,2]  R1783     -5.8049482107162476e-01
    z[5,4,2]  R1784     -3.1603699922561646e-01
    z[5,4,2]  R1785     -2.2508840262889862e-01
    z[5,4,2]  R1786     -2.2061146795749664e-01
    z[5,4,2]  R1787     6.5723694860935211e-02
    z[5,4,2]  R1788     1.0464729368686676e-01
    z[5,4,2]  R1789     -3.3608219027519226e-01
    z[5,4,2]  R1790     1.2708115577697754e-01
    z[5,4,2]  R1791     -1.5526810288429260e-01
    z[5,4,2]  R1792     5.6466263532638550e-01
    z[5,4,2]  R1793     2.2702223062515259e-01
    z[5,4,2]  R1794     3.7101350724697113e-02
    z[5,4,2]  R1795     -7.1581047773361206e-01
    z[5,4,2]  R1796     -5.6525085121393204e-02
    z[5,4,2]  R1797     1.6549895703792572e-01
    z[5,4,2]  R1798     2.0005920529365540e-01
    z[5,4,2]  R1799     5.7398986071348190e-02
    z[5,4,2]  R1800     5.1809096336364746e-01
    z[5,4,2]  R1801     3.2539409399032593e-01
    z[5,4,2]  R1802     4.1225567460060120e-01
    z[5,4,2]  R1803     -5.2013248205184937e-02
    z[5,4,2]  R1804     -0.448064386844635
    z[5,4,2]  R1805     -7.5722610950469971e-01
    z[5,4,2]  R1806     1.5022765100002289e-01
    z[5,4,2]  R1807     3.5219088196754456e-02
    z[5,4,2]  R1808     -2.9492512345314026e-01
    z[5,4,2]  R1809     6.9097101688385010e-02
    z[5,4,2]  R1810     4.5762678980827332e-01
    z[5,4,2]  R1811     2.9374626278877258e-01
    z[5,4,2]  R1812     3.4706103801727295e-01
    z[5,4,2]  R1813     3.4038335084915161e-02
    z[5,4,2]  R1814     4.5589277148246765e-01
    z[5,4,2]  R1815     2.3930977284908295e-01
    z[5,4,2]  R1816     -4.8892641067504883e-01
    z[5,4,2]  R1817     -6.2998455762863159e-01
    z[5,4,2]  R1818     -5.6363517045974731e-01
    z[5,4,2]  R1819     -3.2378584146499634e-01
    z[5,4,2]  R1820     -1.9953134655952454e-01
    z[5,4,2]  R1821     -0.620113730430603
    z[5,4,2]  R1822     6.2657386064529419e-02
    z[5,4,2]  R1823     -2.6013249158859253e-01
    z[5,4,2]  R1824     -0.434576153755188
    z[5,4,2]  R1825     3.1460583209991455e-02
    z[5,4,2]  R1826     0.271842360496521
    z[5,4,2]  R1827     2.4250237643718719e-01
    z[5,4,2]  R1828     1.0891170054674149e-01
    z[5,4,2]  R1829     2.4245100095868111e-02
    z[5,4,2]  R1830     0.0978781208395958
    z[5,4,2]  R1831     5.7753545045852661e-01
    z[5,4,2]  R1832     1.5783621370792389e-01
    z[5,4,2]  R1833     1.7953260242938995e-01
    z[5,4,2]  R1834     5.6387925148010254e-01
    z[5,4,2]  R1835     0.560340166091919
    z[5,4,2]  R1836     2.2890008985996246e-01
    z[5,4,2]  R1837     1.7778469622135162e-01
    z[5,4,2]  R1838     4.6568965911865234e-01
    z[5,4,2]  R1839     3.6825489997863770e-01
    z[5,4,2]  R1840     2.3756980895996094e-01
    z[5,4,2]  R1841     6.1661440134048462e-01
    z[5,4,2]  R1842     3.5787844657897949e-01
    z[5,4,2]  R1843     -5.4644995927810669e-01
    z[5,4,2]  R1844     2.2522220015525818e-01
    z[5,4,2]  R1845     4.9367386102676392e-01
    z[5,4,2]  R1846     -4.3730321526527405e-01
    z[5,4,2]  R1847     -5.3622430562973022e-01
    z[5,4,2]  R1848     -3.2214820384979248e-02
    z[5,4,2]  R1849     -6.5103453397750854e-01
    z[5,4,2]  R1850     4.4995138049125671e-01
    z[5,4,2]  R1851     3.8770538568496704e-01
    z[5,4,2]  R1852     0.274767130613327
    z[5,4,2]  R1853     2.0365764200687408e-01
    z[5,4,2]  R1854     -1.8638806045055389e-01
    z[5,4,2]  R1855     4.1917601227760315e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R1728     -1
    z[5,4,3]  R1729     1
    z[5,4,3]  R1736     -4.0296635031700134e-01
    z[5,4,3]  R1737     -5.3747254610061646e-01
    z[5,4,3]  R1738     3.8999652862548828e-01
    z[5,4,3]  R1739     1.8943159282207489e-01
    z[5,4,3]  R1740     -5.6672533974051476e-03
    z[5,4,3]  R1741     -6.5534913539886475e-01
    z[5,4,3]  R1742     -7.3129677772521973e-01
    z[5,4,3]  R1743     -4.1921964287757874e-01
    z[5,4,3]  R1744     -5.7796392589807510e-02
    z[5,4,3]  R1745     -1.8595364689826965e-01
    z[5,4,3]  R1746     4.8870390653610229e-01
    z[5,4,3]  R1747     5.2809065580368042e-01
    z[5,4,3]  R1748     -1.1364148557186127e-01
    z[5,4,3]  R1749     1.1756717227399349e-02
    z[5,4,3]  R1750     3.9626678824424744e-01
    z[5,4,3]  R1751     4.6743705868721008e-01
    z[5,4,3]  R1752     -5.4867319762706757e-02
    z[5,4,3]  R1753     3.5917188972234726e-02
    z[5,4,3]  R1754     1.1144948750734329e-01
    z[5,4,3]  R1755     4.9830180406570435e-01
    z[5,4,3]  R1756     -0.0093460688367486
    z[5,4,3]  R1757     -3.8008257746696472e-01
    z[5,4,3]  R1758     3.7454792857170105e-01
    z[5,4,3]  R1759     -2.9269483685493469e-01
    z[5,4,3]  R1760     1.7930108308792114e-01
    z[5,4,3]  R1761     -1.6624249517917633e-01
    z[5,4,3]  R1762     -2.1269553899765015e-01
    z[5,4,3]  R1763     -1.9685249030590057e-01
    z[5,4,3]  R1764     3.4639306366443634e-02
    z[5,4,3]  R1765     2.5832358002662659e-01
    z[5,4,3]  R1766     -2.4320723116397858e-01
    z[5,4,3]  R1767     1.0809340327978134e-01
    z[5,4,3]  R1768     6.3858258724212646e-01
    z[5,4,3]  R1769     6.7080706357955933e-01
    z[5,4,3]  R1770     5.9035187959671021e-01
    z[5,4,3]  R1771     0.41353839635849
    z[5,4,3]  R1772     0.696344792842865
    z[5,4,3]  R1773     5.4434329271316528e-01
    z[5,4,3]  R1774     2.2740148007869720e-01
    z[5,4,3]  R1775     -3.5715955495834351e-01
    z[5,4,3]  R1776     5.2272051572799683e-01
    z[5,4,3]  R1777     1.8101263046264648e-01
    z[5,4,3]  R1778     4.3131539225578308e-01
    z[5,4,3]  R1779     2.4780897796154022e-01
    z[5,4,3]  R1780     0.7169149518013
    z[5,4,3]  R1781     1.5931184589862823e-01
    z[5,4,3]  R1782     -2.0667349454015493e-03
    z[5,4,3]  R1783     -1.7180286347866058e-01
    z[5,4,3]  R1784     -7.6556265354156494e-01
    z[5,4,3]  R1785     -2.7293208241462708e-01
    z[5,4,3]  R1786     -1.2084152549505234e-01
    z[5,4,3]  R1787     3.8940033316612244e-01
    z[5,4,3]  R1788     3.7436354160308838e-01
    z[5,4,3]  R1789     4.2552683502435684e-02
    z[5,4,3]  R1790     0.262176513671875
    z[5,4,3]  R1791     6.1868435144424438e-01
    z[5,4,3]  R1792     -3.8611480593681335e-01
    z[5,4,3]  R1793     7.3401367664337158e-01
    z[5,4,3]  R1794     -4.6521016955375671e-01
    z[5,4,3]  R1795     -7.6276063919067383e-02
    z[5,4,3]  R1796     7.2090637683868408e-01
    z[5,4,3]  R1797     4.6992671489715576e-01
    z[5,4,3]  R1798     -4.0821766853332520e-01
    z[5,4,3]  R1799     3.0732184648513794e-02
    z[5,4,3]  R1800     1.4271210134029388e-01
    z[5,4,3]  R1801     3.1659308820962906e-02
    z[5,4,3]  R1802     4.8740115761756897e-01
    z[5,4,3]  R1803     1.3294823467731476e-01
    z[5,4,3]  R1804     -4.0946012735366821e-01
    z[5,4,3]  R1805     -5.2992874383926392e-01
    z[5,4,3]  R1806     -4.6401867270469666e-01
    z[5,4,3]  R1807     7.6905030012130737e-01
    z[5,4,3]  R1808     -2.9391431808471680e-01
    z[5,4,3]  R1809     -2.2351497411727905e-01
    z[5,4,3]  R1810     1.0619022697210312e-01
    z[5,4,3]  R1811     -1.0161448270082474e-01
    z[5,4,3]  R1812     1.7341688275337219e-02
    z[5,4,3]  R1813     -4.0813955664634705e-01
    z[5,4,3]  R1814     -5.1933777332305908e-01
    z[5,4,3]  R1815     -8.2367813587188721e-01
    z[5,4,3]  R1816     1.7601533234119415e-01
    z[5,4,3]  R1817     6.3435681164264679e-02
    z[5,4,3]  R1818     5.8566421270370483e-01
    z[5,4,3]  R1819     -3.1957533210515976e-02
    z[5,4,3]  R1820     5.4880738258361816e-01
    z[5,4,3]  R1821     1.8849761784076691e-01
    z[5,4,3]  R1822     -4.1592246294021606e-01
    z[5,4,3]  R1823     4.2277574539184570e-02
    z[5,4,3]  R1824     1.8614079058170319e-01
    z[5,4,3]  R1825     -4.5220154523849487e-01
    z[5,4,3]  R1826     5.7858824729919434e-01
    z[5,4,3]  R1827     5.5579996109008789e-01
    z[5,4,3]  R1828     4.6628028154373169e-01
    z[5,4,3]  R1829     4.5316961407661438e-01
    z[5,4,3]  R1830     3.1654286384582520e-01
    z[5,4,3]  R1831     -0.199876606464386
    z[5,4,3]  R1832     -8.6203165352344513e-02
    z[5,4,3]  R1833     -7.4223525822162628e-02
    z[5,4,3]  R1834     -4.8704904317855835e-01
    z[5,4,3]  R1835     -7.8237777948379517e-01
    z[5,4,3]  R1836     2.0347169041633606e-01
    z[5,4,3]  R1837     6.4545780420303345e-01
    z[5,4,3]  R1838     -4.2889210581779480e-01
    z[5,4,3]  R1839     -2.3227228224277496e-01
    z[5,4,3]  R1840     4.8670306801795959e-01
    z[5,4,3]  R1841     -3.0853557586669922e-01
    z[5,4,3]  R1842     2.4328298866748810e-01
    z[5,4,3]  R1843     3.3010223507881165e-01
    z[5,4,3]  R1844     -3.7748065590858459e-01
    z[5,4,3]  R1845     3.1534847617149353e-01
    z[5,4,3]  R1846     -0.0200671274214983
    z[5,4,3]  R1847     -3.9867699146270752e-02
    z[5,4,3]  R1848     3.2048463821411133e-01
    z[5,4,3]  R1849     3.5661211609840393e-01
    z[5,4,3]  R1850     -1.7238807678222656e-01
    z[5,4,3]  R1851     -5.8072954416275024e-01
    z[5,4,3]  R1852     -2.3731626570224762e-01
    z[5,4,3]  R1853     -4.9800008535385132e-01
    z[5,4,3]  R1854     -5.2545249462127686e-01
    z[5,4,3]  R1855     -4.3838983774185181e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R1730     -1
    z[5,4,4]  R1731     1
    z[5,4,4]  R1736     7.5176376104354858e-01
    z[5,4,4]  R1737     -1.4871887862682343e-01
    z[5,4,4]  R1738     -3.7163731455802917e-01
    z[5,4,4]  R1739     1.2865507602691650e-01
    z[5,4,4]  R1740     -0.0733717754483223
    z[5,4,4]  R1741     1.1783973127603531e-01
    z[5,4,4]  R1742     5.4849749803543091e-01
    z[5,4,4]  R1743     6.2639951705932617e-01
    z[5,4,4]  R1744     -3.5146933794021606e-01
    z[5,4,4]  R1745     5.0835222005844116e-02
    z[5,4,4]  R1746     -5.0168275833129883e-01
    z[5,4,4]  R1747     6.0711979866027832e-01
    z[5,4,4]  R1748     4.4273640960454941e-02
    z[5,4,4]  R1749     -6.4374852180480957e-01
    z[5,4,4]  R1750     -1.6002447903156281e-01
    z[5,4,4]  R1751     -8.7334312498569489e-02
    z[5,4,4]  R1752     -1.5916512906551361e-01
    z[5,4,4]  R1753     1.2083603441715240e-01
    z[5,4,4]  R1754     -2.5509238243103027e-01
    z[5,4,4]  R1755     4.1140943765640259e-01
    z[5,4,4]  R1756     1.1140716820955276e-01
    z[5,4,4]  R1757     3.7780648469924927e-01
    z[5,4,4]  R1758     6.9314420223236084e-02
    z[5,4,4]  R1759     -2.4283558130264282e-01
    z[5,4,4]  R1760     -3.4706154465675354e-01
    z[5,4,4]  R1761     -5.9952008724212646e-01
    z[5,4,4]  R1762     -1.4264552295207977e-01
    z[5,4,4]  R1763     -1.0346832871437073e-01
    z[5,4,4]  R1764     -7.5108265876770020e-01
    z[5,4,4]  R1765     2.7828735113143921e-01
    z[5,4,4]  R1766     -9.1508477926254272e-02
    z[5,4,4]  R1767     -1.3764876127243042e-01
    z[5,4,4]  R1768     -6.9223576784133911e-01
    z[5,4,4]  R1769     2.3049761354923248e-01
    z[5,4,4]  R1770     9.2276886105537415e-02
    z[5,4,4]  R1771     -3.3010292053222656e-01
    z[5,4,4]  R1772     -2.3575066030025482e-01
    z[5,4,4]  R1773     1.2148077040910721e-01
    z[5,4,4]  R1774     -3.9655703306198120e-01
    z[5,4,4]  R1775     5.3671054542064667e-02
    z[5,4,4]  R1776     -0.0931900143623352
    z[5,4,4]  R1777     -1.9064508378505707e-01
    z[5,4,4]  R1778     4.2088195681571960e-02
    z[5,4,4]  R1779     -0.507418155670166
    z[5,4,4]  R1780     -1.3674655556678772e-01
    z[5,4,4]  R1781     -8.7358540296554565e-01
    z[5,4,4]  R1782     -8.1932795047760010e-01
    z[5,4,4]  R1783     -2.0943273603916168e-01
    z[5,4,4]  R1784     -1.3228332996368408e-01
    z[5,4,4]  R1785     -4.2033135890960693e-01
    z[5,4,4]  R1786     -2.4451339244842529e-01
    z[5,4,4]  R1787     -6.7833763360977173e-01
    z[5,4,4]  R1788     -4.1297331452369690e-01
    z[5,4,4]  R1789     0.0561286062002182
    z[5,4,4]  R1790     0.399565726518631
    z[5,4,4]  R1791     -3.4178376197814941e-01
    z[5,4,4]  R1792     8.4828995168209076e-02
    z[5,4,4]  R1793     -4.6115365624427795e-01
    z[5,4,4]  R1794     3.9002561569213867e-01
    z[5,4,4]  R1795     0.259692519903183
    z[5,4,4]  R1796     -4.6415838599205017e-01
    z[5,4,4]  R1797     -2.7864843606948853e-01
    z[5,4,4]  R1798     1.4217145740985870e-01
    z[5,4,4]  R1799     2.3603625595569611e-01
    z[5,4,4]  R1800     -4.6134196221828461e-02
    z[5,4,4]  R1801     -5.6159579753875732e-01
    z[5,4,4]  R1802     -1.1255256086587906e-01
    z[5,4,4]  R1803     1.5449588000774384e-01
    z[5,4,4]  R1804     2.8930687904357910e-01
    z[5,4,4]  R1805     2.2097003459930420e-01
    z[5,4,4]  R1806     9.5833852887153625e-02
    z[5,4,4]  R1807     -1.8232512474060059e-01
    z[5,4,4]  R1808     -3.0767528340220451e-02
    z[5,4,4]  R1809     3.5154440999031067e-01
    z[5,4,4]  R1810     -6.1790518462657928e-02
    z[5,4,4]  R1811     -3.3919781446456909e-01
    z[5,4,4]  R1812     4.1360324621200562e-01
    z[5,4,4]  R1813     0.440787136554718
    z[5,4,4]  R1814     3.1244885921478271e-01
    z[5,4,4]  R1815     1.8467611074447632e-01
    z[5,4,4]  R1816     1.0856717824935913e-02
    z[5,4,4]  R1817     -6.5588361024856567e-01
    z[5,4,4]  R1818     1.2484563887119293e-01
    z[5,4,4]  R1819     -1.9584220647811890e-01
    z[5,4,4]  R1820     4.2634099721908569e-01
    z[5,4,4]  R1821     1.5479709208011627e-01
    z[5,4,4]  R1822     -1.2218625284731388e-02
    z[5,4,4]  R1823     1.0611588507890701e-01
    z[5,4,4]  R1824     1.1072899401187897e-01
    z[5,4,4]  R1825     2.9332062602043152e-01
    z[5,4,4]  R1826     -5.2169007062911987e-01
    z[5,4,4]  R1827     1.5225443989038467e-02
    z[5,4,4]  R1828     -2.0152826607227325e-01
    z[5,4,4]  R1829     -1.9289699196815491e-01
    z[5,4,4]  R1830     -3.3994954824447632e-01
    z[5,4,4]  R1831     -8.9647211134433746e-02
    z[5,4,4]  R1832     1.7738105356693268e-01
    z[5,4,4]  R1833     -9.9142849445343018e-02
    z[5,4,4]  R1834     -1.1770591139793396e-01
    z[5,4,4]  R1835     1.3046446442604065e-01
    z[5,4,4]  R1836     3.9614226669073105e-02
    z[5,4,4]  R1837     -1.8910236656665802e-02
    z[5,4,4]  R1838     -9.0951457619667053e-02
    z[5,4,4]  R1839     -1.7323465645313263e-01
    z[5,4,4]  R1840     -1.4452171325683594e-01
    z[5,4,4]  R1841     1.5978337824344635e-01
    z[5,4,4]  R1842     4.5616424083709717e-01
    z[5,4,4]  R1843     -1.4891673624515533e-01
    z[5,4,4]  R1844     2.0689669251441956e-01
    z[5,4,4]  R1845     3.5767704248428345e-01
    z[5,4,4]  R1846     -3.1594979763031006e-01
    z[5,4,4]  R1847     0.0851435512304306
    z[5,4,4]  R1848     -2.1339073777198792e-01
    z[5,4,4]  R1849     -2.2136293351650238e-01
    z[5,4,4]  R1850     -3.1325586140155792e-02
    z[5,4,4]  R1851     -2.7960114181041718e-02
    z[5,4,4]  R1852     2.5202789902687073e-01
    z[5,4,4]  R1853     3.7080907821655273e-01
    z[5,4,4]  R1854     -5.0051814317703247e-01
    z[5,4,4]  R1855     -2.6815861463546753e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R1732     -1
    z[5,4,5]  R1733     1
    z[5,4,5]  R1736     2.9332739114761353e-01
    z[5,4,5]  R1737     7.1510946750640869e-01
    z[5,4,5]  R1738     -5.2475024014711380e-02
    z[5,4,5]  R1739     1.7414024472236633e-01
    z[5,4,5]  R1740     9.1644853353500366e-02
    z[5,4,5]  R1741     6.1001843214035034e-01
    z[5,4,5]  R1742     -2.6714442297816277e-02
    z[5,4,5]  R1743     4.9909198284149170e-01
    z[5,4,5]  R1744     0.280887246131897
    z[5,4,5]  R1745     5.7129483669996262e-02
    z[5,4,5]  R1746     -5.3611123561859131e-01
    z[5,4,5]  R1747     1.0503428988158703e-02
    z[5,4,5]  R1748     7.6457291841506958e-02
    z[5,4,5]  R1749     4.8521704971790314e-02
    z[5,4,5]  R1750     -2.2446073591709137e-02
    z[5,4,5]  R1751     -5.6388586759567261e-01
    z[5,4,5]  R1752     2.0568537712097168e-01
    z[5,4,5]  R1753     -4.4070816040039062e-01
    z[5,4,5]  R1754     4.6067759394645691e-01
    z[5,4,5]  R1755     -2.2795550525188446e-01
    z[5,4,5]  R1756     7.8413665294647217e-02
    z[5,4,5]  R1757     3.5060279071331024e-02
    z[5,4,5]  R1758     -7.6172329485416412e-02
    z[5,4,5]  R1759     -4.0887433290481567e-01
    z[5,4,5]  R1760     2.1426714956760406e-01
    z[5,4,5]  R1761     -2.4813812971115112e-01
    z[5,4,5]  R1762     -3.8117133080959320e-02
    z[5,4,5]  R1763     -2.8980466723442078e-01
    z[5,4,5]  R1764     8.9521482586860657e-02
    z[5,4,5]  R1765     0.304259330034256
    z[5,4,5]  R1766     1.0470122098922729e-01
    z[5,4,5]  R1767     -0.138969287276268
    z[5,4,5]  R1768     1.0573318600654602e-01
    z[5,4,5]  R1769     -0.294136106967926
    z[5,4,5]  R1770     2.9178187251091003e-01
    z[5,4,5]  R1771     3.0617406964302063e-01
    z[5,4,5]  R1772     9.3371786177158356e-02
    z[5,4,5]  R1773     1.0456296615302563e-02
    z[5,4,5]  R1774     -2.1243534982204437e-01
    z[5,4,5]  R1775     1.9443942606449127e-01
    z[5,4,5]  R1776     -2.5983512401580811e-01
    z[5,4,5]  R1777     -5.2789688110351562e-01
    z[5,4,5]  R1778     -3.9663156867027283e-01
    z[5,4,5]  R1779     5.7480856776237488e-02
    z[5,4,5]  R1780     -1.6389995813369751e-01
    z[5,4,5]  R1781     -1.2786342203617096e-01
    z[5,4,5]  R1782     -8.8494569063186646e-02
    z[5,4,5]  R1783     -3.5261037945747375e-01
    z[5,4,5]  R1784     2.0087789744138718e-02
    z[5,4,5]  R1785     -4.8231580853462219e-01
    z[5,4,5]  R1786     -1.7192986607551575e-01
    z[5,4,5]  R1787     -1.9586364924907684e-01
    z[5,4,5]  R1788     -4.2953795194625854e-01
    z[5,4,5]  R1789     -5.1154899597167969e-01
    z[5,4,5]  R1790     -0.486591100692749
    z[5,4,5]  R1791     -1.6131840646266937e-01
    z[5,4,5]  R1792     -2.4157339334487915e-01
    z[5,4,5]  R1793     2.4367275834083557e-01
    z[5,4,5]  R1794     0.526871919631958
    z[5,4,5]  R1795     2.3944175243377686e-01
    z[5,4,5]  R1796     -2.7048933506011963e-01
    z[5,4,5]  R1797     -2.3300358653068542e-01
    z[5,4,5]  R1798     -5.4858249425888062e-01
    z[5,4,5]  R1799     -3.0323502421379089e-01
    z[5,4,5]  R1800     -3.1779669225215912e-02
    z[5,4,5]  R1801     2.1713009476661682e-01
    z[5,4,5]  R1802     1.5094964765012264e-02
    z[5,4,5]  R1803     6.5014606714248657e-01
    z[5,4,5]  R1804     3.6648404598236084e-01
    z[5,4,5]  R1805     -2.4043897166848183e-02
    z[5,4,5]  R1806     -3.4174686670303345e-01
    z[5,4,5]  R1807     -1.9944418221712112e-02
    z[5,4,5]  R1808     5.7126116752624512e-01
    z[5,4,5]  R1809     -2.7853599190711975e-01
    z[5,4,5]  R1810     2.5465330481529236e-01
    z[5,4,5]  R1811     4.6998324990272522e-01
    z[5,4,5]  R1812     1.0797326266765594e-01
    z[5,4,5]  R1813     5.5890262126922607e-01
    z[5,4,5]  R1814     5.9055322408676147e-01
    z[5,4,5]  R1815     3.2658642530441284e-01
    z[5,4,5]  R1816     4.3001264333724976e-01
    z[5,4,5]  R1817     8.8137343525886536e-02
    z[5,4,5]  R1818     -2.9693683981895447e-01
    z[5,4,5]  R1819     -1.1963365972042084e-01
    z[5,4,5]  R1820     1.2636837363243103e-01
    z[5,4,5]  R1821     -5.9129250049591064e-01
    z[5,4,5]  R1822     3.1540271639823914e-01
    z[5,4,5]  R1823     0.552384614944458
    z[5,4,5]  R1824     6.9784924387931824e-02
    z[5,4,5]  R1825     -7.4164181947708130e-02
    z[5,4,5]  R1826     -7.4610225856304169e-03
    z[5,4,5]  R1827     4.2120195925235748e-02
    z[5,4,5]  R1828     1.1479678004980087e-01
    z[5,4,5]  R1829     -2.1093097329139709e-01
    z[5,4,5]  R1830     -1.3658192753791809e-01
    z[5,4,5]  R1831     -2.2241917252540588e-01
    z[5,4,5]  R1832     -7.5781798362731934e-01
    z[5,4,5]  R1833     -7.0537918806076050e-01
    z[5,4,5]  R1834     -1.0778035968542099e-01
    z[5,4,5]  R1835     -4.7113727778196335e-02
    z[5,4,5]  R1836     -8.1583723425865173e-02
    z[5,4,5]  R1837     1.5470467507839203e-01
    z[5,4,5]  R1838     -9.5077134668827057e-02
    z[5,4,5]  R1839     -4.2949426174163818e-01
    z[5,4,5]  R1840     3.4728178381919861e-01
    z[5,4,5]  R1841     0.0904572531580925
    z[5,4,5]  R1842     -1.4110137522220612e-01
    z[5,4,5]  R1843     1.1845245212316513e-01
    z[5,4,5]  R1844     -3.1538268923759460e-01
    z[5,4,5]  R1845     1.9393399357795715e-01
    z[5,4,5]  R1846     4.2377910017967224e-01
    z[5,4,5]  R1847     -0.395780086517334
    z[5,4,5]  R1848     -1.7386563122272491e-02
    z[5,4,5]  R1849     -2.4130217730998993e-01
    z[5,4,5]  R1850     -1.4675861597061157e-01
    z[5,4,5]  R1851     -4.1860324144363403e-01
    z[5,4,5]  R1852     -4.0268743038177490e-01
    z[5,4,5]  R1853     -6.7394733428955078e-01
    z[5,4,5]  R1854     -0.511361837387085
    z[5,4,5]  R1855     0.00314392801374197
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R1734     -1
    z[5,4,6]  R1735     1
    z[5,4,6]  R1736     2.6621580123901367e-01
    z[5,4,6]  R1737     3.0010810494422913e-01
    z[5,4,6]  R1738     3.8044017553329468e-01
    z[5,4,6]  R1739     -1.7489826679229736e-01
    z[5,4,6]  R1740     -2.1970197558403015e-01
    z[5,4,6]  R1741     -3.9699527621269226e-01
    z[5,4,6]  R1742     -3.8570281863212585e-01
    z[5,4,6]  R1743     -3.3717584609985352e-01
    z[5,4,6]  R1744     4.0127000212669373e-01
    z[5,4,6]  R1745     -9.2358618974685669e-02
    z[5,4,6]  R1746     9.3364212661981583e-03
    z[5,4,6]  R1747     1.8575055524706841e-02
    z[5,4,6]  R1748     -0.686257541179657
    z[5,4,6]  R1749     -5.0712901353836060e-01
    z[5,4,6]  R1750     -5.4844814538955688e-01
    z[5,4,6]  R1751     1.1683385819196701e-01
    z[5,4,6]  R1752     5.8028733730316162e-01
    z[5,4,6]  R1753     5.6005173921585083e-01
    z[5,4,6]  R1754     4.2670068144798279e-01
    z[5,4,6]  R1755     4.0735989809036255e-01
    z[5,4,6]  R1756     3.3515495061874390e-01
    z[5,4,6]  R1757     -2.5011441111564636e-01
    z[5,4,6]  R1758     1.5784989297389984e-01
    z[5,4,6]  R1759     -3.0946299433708191e-01
    z[5,4,6]  R1760     -4.8117381334304810e-01
    z[5,4,6]  R1761     1.0222015529870987e-01
    z[5,4,6]  R1762     -2.2296211123466492e-01
    z[5,4,6]  R1763     -3.2010391354560852e-01
    z[5,4,6]  R1764     -4.7038231045007706e-02
    z[5,4,6]  R1765     -1.7150023579597473e-01
    z[5,4,6]  R1766     -4.5805448293685913e-01
    z[5,4,6]  R1767     1.5038771927356720e-01
    z[5,4,6]  R1768     1.9379927217960358e-01
    z[5,4,6]  R1769     -2.2031220793724060e-01
    z[5,4,6]  R1770     -3.7344902753829956e-01
    z[5,4,6]  R1771     1.1838621459901333e-02
    z[5,4,6]  R1772     -2.2365689277648926e-01
    z[5,4,6]  R1773     7.1575768291950226e-02
    z[5,4,6]  R1774     5.3573727607727051e-01
    z[5,4,6]  R1775     -4.0223711729049683e-01
    z[5,4,6]  R1776     -3.0935063958168030e-01
    z[5,4,6]  R1777     -3.0958059430122375e-01
    z[5,4,6]  R1778     4.9714437127113342e-01
    z[5,4,6]  R1779     -2.2677090764045715e-01
    z[5,4,6]  R1780     1.1971540749073029e-01
    z[5,4,6]  R1781     2.3050977289676666e-01
    z[5,4,6]  R1782     -1.7709574103355408e-01
    z[5,4,6]  R1783     1.2278091907501221e-01
    z[5,4,6]  R1784     -1.9041141495108604e-02
    z[5,4,6]  R1785     -1.4525135047733784e-02
    z[5,4,6]  R1786     2.0731000602245331e-01
    z[5,4,6]  R1787     3.8375315070152283e-01
    z[5,4,6]  R1788     1.6119308769702911e-01
    z[5,4,6]  R1789     -2.3104831576347351e-01
    z[5,4,6]  R1790     -2.9836845397949219e-01
    z[5,4,6]  R1791     9.6001133322715759e-02
    z[5,4,6]  R1792     1.9497525691986084e-01
    z[5,4,6]  R1793     -0.196414053440094
    z[5,4,6]  R1794     -4.4452720880508423e-01
    z[5,4,6]  R1795     -3.7463790178298950e-01
    z[5,4,6]  R1796     2.1984319388866425e-01
    z[5,4,6]  R1797     -1.3007242977619171e-01
    z[5,4,6]  R1798     -2.8052901849150658e-02
    z[5,4,6]  R1799     -4.9068778753280640e-01
    z[5,4,6]  R1800     5.1138266921043396e-02
    z[5,4,6]  R1801     2.4880664050579071e-01
    z[5,4,6]  R1802     0.0734206810593605
    z[5,4,6]  R1803     -3.3588579297065735e-01
    z[5,4,6]  R1804     -3.8576945662498474e-01
    z[5,4,6]  R1805     1.3432259857654572e-01
    z[5,4,6]  R1806     1.1812866479158401e-01
    z[5,4,6]  R1807     1.5472298860549927e-01
    z[5,4,6]  R1808     -0.0930066928267479
    z[5,4,6]  R1809     -4.6319490671157837e-01
    z[5,4,6]  R1810     -8.3471322432160378e-03
    z[5,4,6]  R1811     2.3221366107463837e-01
    z[5,4,6]  R1812     -2.5112757086753845e-01
    z[5,4,6]  R1813     2.6935908198356628e-01
    z[5,4,6]  R1814     1.2492532841861248e-02
    z[5,4,6]  R1815     3.2531628012657166e-01
    z[5,4,6]  R1816     1.0290885716676712e-01
    z[5,4,6]  R1817     -2.3524037003517151e-01
    z[5,4,6]  R1818     -3.0866688489913940e-01
    z[5,4,6]  R1819     -5.3239649534225464e-01
    z[5,4,6]  R1820     -5.6580251455307007e-01
    z[5,4,6]  R1821     -5.3024794906377792e-02
    z[5,4,6]  R1822     -1.4246550202369690e-01
    z[5,4,6]  R1823     -4.1751712560653687e-01
    z[5,4,6]  R1824     -0.754396915435791
    z[5,4,6]  R1825     2.0032688975334167e-01
    z[5,4,6]  R1826     3.9272508025169373e-01
    z[5,4,6]  R1827     7.7948756515979767e-02
    z[5,4,6]  R1828     4.1360282897949219e-01
    z[5,4,6]  R1829     3.4510451555252075e-01
    z[5,4,6]  R1830     2.5842586159706116e-01
    z[5,4,6]  R1831     1.3538759946823120e-01
    z[5,4,6]  R1832     1.1551665514707565e-01
    z[5,4,6]  R1833     0.214536651968956
    z[5,4,6]  R1834     -5.3361082077026367e-01
    z[5,4,6]  R1835     7.8541055321693420e-02
    z[5,4,6]  R1836     3.4747272729873657e-01
    z[5,4,6]  R1837     0.0959746390581131
    z[5,4,6]  R1838     -1.4639247953891754e-01
    z[5,4,6]  R1839     -7.8190825879573822e-02
    z[5,4,6]  R1840     -1.7518197000026703e-01
    z[5,4,6]  R1841     5.3436309099197388e-02
    z[5,4,6]  R1842     -1.7086308449506760e-02
    z[5,4,6]  R1843     3.3168086409568787e-01
    z[5,4,6]  R1844     -3.6290207505226135e-01
    z[5,4,6]  R1845     -1.1606375873088837e-01
    z[5,4,6]  R1846     -6.0722154378890991e-01
    z[5,4,6]  R1847     -5.8641022443771362e-01
    z[5,4,6]  R1848     3.7587514519691467e-01
    z[5,4,6]  R1849     0.547369122505188
    z[5,4,6]  R1850     -6.0128502547740936e-02
    z[5,4,6]  R1851     0.365986168384552
    z[5,4,6]  R1852     -6.9392108917236328e-01
    z[5,4,6]  R1853     -2.9783570766448975e-01
    z[5,4,6]  R1854     -7.0330560207366943e-02
    z[5,4,6]  R1855     6.2200218439102173e-01
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R1910     -1
    z[5,6,0]  R1911     1
    z[5,6,0]  R1924     -3.3153480291366577e-01
    z[5,6,0]  R1925     -0.270396888256073
    z[5,6,0]  R1926     2.1862052381038666e-01
    z[5,6,0]  R1927     2.7732756733894348e-01
    z[5,6,0]  R1928     -4.0526506304740906e-01
    z[5,6,0]  R1929     -1.5620526671409607e-01
    z[5,6,0]  R1930     -8.9507259428501129e-02
    z[5,6,0]  R1931     -1.6994468867778778e-01
    z[5,6,0]  R1932     -0.250703364610672
    z[5,6,0]  R1933     2.8833541274070740e-01
    z[5,6,0]  R1934     0.385304719209671
    z[5,6,0]  R1935     0.0796690359711647
    z[5,6,0]  R1936     4.2561444640159607e-01
    z[5,6,0]  R1937     3.7661164999008179e-01
    z[5,6,0]  R1938     2.9428660869598389e-01
    z[5,6,0]  R1939     1.0311092436313629e-01
    z[5,6,0]  R1940     4.6421322971582413e-02
    z[5,6,0]  R1941     4.4364559650421143e-01
    z[5,6,0]  R1942     5.0357764959335327e-01
    z[5,6,0]  R1943     2.0000481605529785e-01
    z[5,6,0]  R1944     -1.0121417045593262e-01
    z[5,6,0]  R1945     -1.3475139439105988e-01
    z[5,6,0]  R1946     -1.6032533347606659e-01
    z[5,6,0]  R1947     -3.8989122956991196e-02
    z[5,6,0]  R1948     -1.0579904913902283e-01
    z[5,6,0]  R1949     2.7819040417671204e-01
    z[5,6,0]  R1950     -1.2221422046422958e-01
    z[5,6,0]  R1951     -2.9942116141319275e-01
    z[5,6,0]  R1952     9.1471262276172638e-02
    z[5,6,0]  R1953     5.3104126453399658e-01
    z[5,6,0]  R1954     3.2689875364303589e-01
    z[5,6,0]  R1955     2.6952734589576721e-01
    z[5,6,0]  R1956     8.9986763894557953e-02
    z[5,6,0]  R1957     2.7206912636756897e-01
    z[5,6,0]  R1958     1.6852578148245811e-02
    z[5,6,0]  R1959     4.8067674040794373e-02
    z[5,6,0]  R1960     5.0814390182495117e-02
    z[5,6,0]  R1961     -0.0943196564912796
    z[5,6,0]  R1962     -9.4523094594478607e-02
    z[5,6,0]  R1963     2.4276039004325867e-01
    z[5,6,0]  R1964     3.7563553452491760e-01
    z[5,6,0]  R1965     3.0035263299942017e-01
    z[5,6,0]  R1966     1.8295191228389740e-01
    z[5,6,0]  R1967     4.3913197517395020e-01
    z[5,6,0]  R1968     2.2637119889259338e-01
    z[5,6,0]  R1969     2.5595527887344360e-01
    z[5,6,0]  R1970     3.6129298806190491e-01
    z[5,6,0]  R1971     3.9604946970939636e-01
    z[5,6,0]  R1972     7.9146578907966614e-02
    z[5,6,0]  R1973     4.2139679193496704e-01
    z[5,6,0]  R1974     4.2497593164443970e-01
    z[5,6,0]  R1975     2.0740933716297150e-01
    z[5,6,0]  R1976     1.1835118383169174e-01
    z[5,6,0]  R1977     3.0861017107963562e-01
    z[5,6,0]  R1978     -6.9337459281086922e-03
    z[5,6,0]  R1979     1.9369046390056610e-01
    z[5,6,0]  R1980     -2.3375537991523743e-01
    z[5,6,0]  R1981     3.6900978535413742e-02
    z[5,6,0]  R1982     -2.8620123863220215e-01
    z[5,6,0]  R1983     2.6928946375846863e-01
    z[5,6,0]  R1984     2.8702870011329651e-01
    z[5,6,0]  R1985     3.2271936535835266e-02
    z[5,6,0]  R1986     -0.0276222862303257
    z[5,6,0]  R1987     9.2043019831180573e-03
    z[5,6,0]  R1988     -0.343716561794281
    z[5,6,0]  R1989     -2.2175729274749756e-01
    z[5,6,0]  R1990     -9.4915814697742462e-02
    z[5,6,0]  R1991     -2.2074216604232788e-01
    z[5,6,0]  R1992     2.9744111001491547e-02
    z[5,6,0]  R1993     1.0121062397956848e-01
    z[5,6,0]  R1994     9.6210852265357971e-02
    z[5,6,0]  R1995     1.3581463694572449e-01
    z[5,6,0]  R1996     -1.0095175355672836e-01
    z[5,6,0]  R1997     -5.4806601256132126e-02
    z[5,6,0]  R1998     5.5049747228622437e-01
    z[5,6,0]  R1999     -3.3798721432685852e-01
    z[5,6,0]  R2000     -3.6248758435249329e-01
    z[5,6,0]  R2001     -4.1941866278648376e-01
    z[5,6,0]  R2002     -2.5176367163658142e-01
    z[5,6,0]  R2003     -1.3267327845096588e-01
    z[5,6,0]  R2004     6.1276221275329590e-01
    z[5,6,0]  R2005     4.5041519403457642e-01
    z[5,6,0]  R2006     7.8865963220596313e-01
    z[5,6,0]  R2007     -2.4639409780502319e-01
    z[5,6,0]  R2008     1.6377098858356476e-02
    z[5,6,0]  R2009     -1.1627390235662460e-01
    z[5,6,0]  R2010     -4.9470996856689453e-01
    z[5,6,0]  R2011     -3.7875732779502869e-01
    z[5,6,0]  R2012     -2.3823419213294983e-01
    z[5,6,0]  R2013     -4.1410744190216064e-01
    z[5,6,0]  R2014     -3.6063289642333984e-01
    z[5,6,0]  R2015     -3.6211588978767395e-01
    z[5,6,0]  R2016     -4.6046221256256104e-01
    z[5,6,0]  R2017     1.6052266582846642e-02
    z[5,6,0]  R2018     -6.8675160408020020e-02
    z[5,6,0]  R2019     -9.4422794878482819e-02
    z[5,6,0]  R2020     -1.9267293810844421e-01
    z[5,6,0]  R2021     -2.9476154595613480e-02
    z[5,6,0]  R2022     -1.4457304775714874e-01
    z[5,6,0]  R2023     -0.0837971493601799
    z[5,6,0]  R2024     -3.1692963838577271e-01
    z[5,6,0]  R2025     -3.5143095254898071e-01
    z[5,6,0]  R2026     4.6653710305690765e-02
    z[5,6,0]  R2027     2.4943938478827477e-02
    z[5,6,0]  R2028     -4.3236187100410461e-01
    z[5,6,0]  R2029     -0.120021753013134
    z[5,6,0]  R2030     -3.5201224684715271e-01
    z[5,6,0]  R2031     4.1558140516281128e-01
    z[5,6,0]  R2032     3.8337224721908569e-01
    z[5,6,0]  R2033     1.3972762227058411e-01
    z[5,6,0]  R2034     2.0932084321975708e-01
    z[5,6,0]  R2035     6.7689009010791779e-02
    z[5,6,0]  R2036     1.3679102063179016e-01
    z[5,6,0]  R2037     -0.0431256964802742
    z[5,6,0]  R2038     1.7754010856151581e-01
    z[5,6,0]  R2039     2.9873788356781006e-02
    z[5,6,0]  R2040     -1.5065731480717659e-02
    z[5,6,0]  R2041     -1.4924864470958710e-01
    z[5,6,0]  R2042     2.8897517919540405e-01
    z[5,6,0]  R2043     3.3578014373779297e-01
    z[5,6,0]  R2044     3.3725729584693909e-01
    z[5,6,0]  R2045     4.0198189020156860e-01
    z[5,6,0]  R2046     2.9496408533304930e-03
    z[5,6,0]  R2047     2.8498345613479614e-01
    z[5,6,0]  R2048     -8.2206851243972778e-01
    z[5,6,0]  R2049     -8.2323813438415527e-01
    z[5,6,0]  R2050     -8.6341661214828491e-01
    z[5,6,0]  R2051     -8.0771315097808838e-01
    z[5,6,0]  R2052     -0.781409502029419
    z[5,6,0]  R2053     -8.3696919679641724e-01
    z[5,6,0]  R2054     6.8571992218494415e-02
    z[5,6,0]  R2055     -1.9584028422832489e-01
    z[5,6,0]  R2056     3.4353566169738770e-01
    z[5,6,0]  R2057     -4.1826122999191284e-01
    z[5,6,0]  R2058     -6.9084864854812622e-01
    z[5,6,0]  R2059     -9.3364083766937256e-01
    z[5,6,0]  R2060     -7.7485686540603638e-01
    z[5,6,0]  R2061     -6.2384098768234253e-01
    z[5,6,0]  R2062     -6.7667406797409058e-01
    z[5,6,0]  R2063     -5.3504264354705811e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R1912     -1
    z[5,6,1]  R1913     1
    z[5,6,1]  R1924     0.0476214662194252
    z[5,6,1]  R1925     1.0748263448476791e-01
    z[5,6,1]  R1926     -7.0843541622161865e-01
    z[5,6,1]  R1927     -7.9341602325439453e-01
    z[5,6,1]  R1928     1.4412711560726166e-01
    z[5,6,1]  R1929     4.8449043184518814e-02
    z[5,6,1]  R1930     3.6293938755989075e-02
    z[5,6,1]  R1931     2.6854671537876129e-02
    z[5,6,1]  R1932     1.5831999480724335e-01
    z[5,6,1]  R1933     8.5295155644416809e-02
    z[5,6,1]  R1934     -2.6950734853744507e-01
    z[5,6,1]  R1935     5.7463991641998291e-01
    z[5,6,1]  R1936     5.6482058763504028e-01
    z[5,6,1]  R1937     -3.7953183054924011e-01
    z[5,6,1]  R1938     0.565430760383606
    z[5,6,1]  R1939     5.3390699625015259e-01
    z[5,6,1]  R1940     5.3784149885177612e-01
    z[5,6,1]  R1941     5.2749764919281006e-01
    z[5,6,1]  R1942     5.2360785007476807e-01
    z[5,6,1]  R1943     5.2429425716400146e-01
    z[5,6,1]  R1944     9.0753048658370972e-01
    z[5,6,1]  R1945     0.748072624206543
    z[5,6,1]  R1946     7.4286442995071411e-01
    z[5,6,1]  R1947     6.9485700130462646e-01
    z[5,6,1]  R1948     7.0424479246139526e-01
    z[5,6,1]  R1949     6.7752861976623535e-01
    z[5,6,1]  R1950     9.1798293590545654e-01
    z[5,6,1]  R1951     6.1748200654983521e-01
    z[5,6,1]  R1952     6.4499658346176147e-01
    z[5,6,1]  R1953     5.7632488012313843e-01
    z[5,6,1]  R1954     7.7760022878646851e-01
    z[5,6,1]  R1955     -9.0361207723617554e-01
    z[5,6,1]  R1956     -1.7615698277950287e-01
    z[5,6,1]  R1957     -5.1598149538040161e-01
    z[5,6,1]  R1958     0.626396119594574
    z[5,6,1]  R1959     -7.8454130887985229e-01
    z[5,6,1]  R1960     -0.581381618976593
    z[5,6,1]  R1961     -7.5596773624420166e-01
    z[5,6,1]  R1962     -5.0138765573501587e-01
    z[5,6,1]  R1963     0.490298867225647
    z[5,6,1]  R1964     -6.1461544036865234e-01
    z[5,6,1]  R1965     -6.7476719617843628e-01
    z[5,6,1]  R1966     -6.0727447271347046e-01
    z[5,6,1]  R1967     -5.2752667665481567e-01
    z[5,6,1]  R1968     6.1117631196975708e-01
    z[5,6,1]  R1969     -2.7636510133743286e-01
    z[5,6,1]  R1970     -3.8241308927536011e-01
    z[5,6,1]  R1971     5.4164856672286987e-01
    z[5,6,1]  R1972     5.3805696964263916e-01
    z[5,6,1]  R1973     -5.3642332553863525e-01
    z[5,6,1]  R1974     0.78980952501297
    z[5,6,1]  R1975     -0.394027978181839
    z[5,6,1]  R1976     6.7369186878204346e-01
    z[5,6,1]  R1977     6.8686366081237793e-01
    z[5,6,1]  R1978     6.5545284748077393e-01
    z[5,6,1]  R1979     6.3525545597076416e-01
    z[5,6,1]  R1980     6.1144155263900757e-01
    z[5,6,1]  R1981     -3.1257885694503784e-01
    z[5,6,1]  R1982     2.7013579010963440e-01
    z[5,6,1]  R1983     3.7967661023139954e-01
    z[5,6,1]  R1984     -2.4036408960819244e-01
    z[5,6,1]  R1985     7.7581125497817993e-01
    z[5,6,1]  R1986     6.8602418899536133e-01
    z[5,6,1]  R1987     0.779254138469696
    z[5,6,1]  R1988     7.6636826992034912e-01
    z[5,6,1]  R1989     6.4768815040588379e-01
    z[5,6,1]  R1990     -7.5179100036621094e-01
    z[5,6,1]  R1991     6.0951977968215942e-01
    z[5,6,1]  R1992     5.1368170976638794e-01
    z[5,6,1]  R1993     2.6094493269920349e-01
    z[5,6,1]  R1994     7.8289997577667236e-01
    z[5,6,1]  R1995     -5.7558339834213257e-01
    z[5,6,1]  R1996     6.9318550825119019e-01
    z[5,6,1]  R1997     7.2563600540161133e-01
    z[5,6,1]  R1998     6.3837128877639771e-01
    z[5,6,1]  R1999     6.3189369440078735e-01
    z[5,6,1]  R2000     7.0856159925460815e-01
    z[5,6,1]  R2001     2.7772587537765503e-01
    z[5,6,1]  R2002     -1.1194500327110291e-01
    z[5,6,1]  R2003     0.00939845945686102
    z[5,6,1]  R2004     -4.6249288320541382e-01
    z[5,6,1]  R2005     -7.3704510927200317e-01
    z[5,6,1]  R2006     -2.5161647796630859e-01
    z[5,6,1]  R2007     2.3816816508769989e-02
    z[5,6,1]  R2008     2.1788033843040466e-01
    z[5,6,1]  R2009     1.1755845695734024e-01
    z[5,6,1]  R2010     -2.8332084417343140e-01
    z[5,6,1]  R2011     -1.5807604789733887e-01
    z[5,6,1]  R2012     -1.3992689782753587e-03
    z[5,6,1]  R2013     0.117411307990551
    z[5,6,1]  R2014     6.4976739883422852e-01
    z[5,6,1]  R2015     7.0342016220092773e-01
    z[5,6,1]  R2016     0.817271888256073
    z[5,6,1]  R2017     5.7912361621856689e-01
    z[5,6,1]  R2018     4.9411904811859131e-01
    z[5,6,1]  R2019     7.1946346759796143e-01
    z[5,6,1]  R2020     8.8183438777923584e-01
    z[5,6,1]  R2021     7.8212618827819824e-01
    z[5,6,1]  R2022     4.9071976542472839e-01
    z[5,6,1]  R2023     3.7327969074249268e-01
    z[5,6,1]  R2024     -1.2900227308273315e-01
    z[5,6,1]  R2025     1.6237090528011322e-01
    z[5,6,1]  R2026     5.3052014112472534e-01
    z[5,6,1]  R2027     9.3510001897811890e-03
    z[5,6,1]  R2028     -2.6308529078960419e-02
    z[5,6,1]  R2029     -3.0889749526977539e-01
    z[5,6,1]  R2030     -3.7239041924476624e-01
    z[5,6,1]  R2031     2.7739086747169495e-01
    z[5,6,1]  R2032     6.6657519340515137e-01
    z[5,6,1]  R2033     6.6656738519668579e-01
    z[5,6,1]  R2034     7.9936319589614868e-01
    z[5,6,1]  R2035     0.682819664478302
    z[5,6,1]  R2036     9.0550339221954346e-01
    z[5,6,1]  R2037     9.6975505352020264e-01
    z[5,6,1]  R2038     0.919813334941864
    z[5,6,1]  R2039     6.4759099483489990e-01
    z[5,6,1]  R2040     7.2470885515213013e-01
    z[5,6,1]  R2041     6.8037277460098267e-01
    z[5,6,1]  R2042     6.5666466951370239e-01
    z[5,6,1]  R2043     3.5335782170295715e-01
    z[5,6,1]  R2044     4.4173008203506470e-01
    z[5,6,1]  R2045     -3.5165590047836304e-01
    z[5,6,1]  R2046     -6.1881011724472046e-01
    z[5,6,1]  R2047     -2.8727304935455322e-01
    z[5,6,1]  R2048     -3.5088992118835449e-01
    z[5,6,1]  R2049     -2.9102388024330139e-01
    z[5,6,1]  R2050     -3.4433019161224365e-01
    z[5,6,1]  R2051     -3.2974857091903687e-01
    z[5,6,1]  R2052     -0.326667457818985
    z[5,6,1]  R2053     -2.2301189601421356e-01
    z[5,6,1]  R2054     8.7182819843292236e-01
    z[5,6,1]  R2055     -7.9527907073497772e-02
    z[5,6,1]  R2056     0.713519811630249
    z[5,6,1]  R2057     -0.0815548226237297
    z[5,6,1]  R2058     -1.8828220665454865e-01
    z[5,6,1]  R2059     -2.5633990764617920e-01
    z[5,6,1]  R2060     -1.1624956130981445e-01
    z[5,6,1]  R2061     -1.8742233514785767e-01
    z[5,6,1]  R2062     -2.8065502643585205e-01
    z[5,6,1]  R2063     -9.3812316656112671e-02
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R1914     -1
    z[5,6,2]  R1915     1
    z[5,6,2]  R1924     -5.8089841157197952e-02
    z[5,6,2]  R1925     5.3781740367412567e-02
    z[5,6,2]  R1926     -1.1235842853784561e-01
    z[5,6,2]  R1927     -4.2453482747077942e-01
    z[5,6,2]  R1928     -8.6770063638687134e-01
    z[5,6,2]  R1929     1.2496147304773331e-02
    z[5,6,2]  R1930     -7.4474133551120758e-02
    z[5,6,2]  R1931     -1.9873550534248352e-01
    z[5,6,2]  R1932     -7.3844176530838013e-01
    z[5,6,2]  R1933     -9.2770171165466309e-01
    z[5,6,2]  R1934     -2.9775600880384445e-02
    z[5,6,2]  R1935     1.2454776465892792e-01
    z[5,6,2]  R1936     9.0335153043270111e-02
    z[5,6,2]  R1937     -2.0008639991283417e-01
    z[5,6,2]  R1938     -3.3128419518470764e-01
    z[5,6,2]  R1939     3.8284385204315186e-01
    z[5,6,2]  R1940     0.548805832862854
    z[5,6,2]  R1941     -3.3939346671104431e-02
    z[5,6,2]  R1942     2.1307025104761124e-02
    z[5,6,2]  R1943     -2.2281266748905182e-01
    z[5,6,2]  R1944     -1.8753020465373993e-01
    z[5,6,2]  R1945     2.6691302657127380e-01
    z[5,6,2]  R1946     4.9662747979164124e-01
    z[5,6,2]  R1947     3.2873785495758057e-01
    z[5,6,2]  R1948     2.5061208009719849e-01
    z[5,6,2]  R1949     -0.0669524073600769
    z[5,6,2]  R1950     1.6005863249301910e-01
    z[5,6,2]  R1951     -5.4143619537353516e-01
    z[5,6,2]  R1952     7.7883955091238022e-03
    z[5,6,2]  R1953     3.4595331549644470e-01
    z[5,6,2]  R1954     1.3240396045148373e-02
    z[5,6,2]  R1955     -1.9565263390541077e-01
    z[5,6,2]  R1956     1.5860426425933838e-01
    z[5,6,2]  R1957     -1.4689028263092041e-01
    z[5,6,2]  R1958     -1.6035205125808716e-01
    z[5,6,2]  R1959     9.1213919222354889e-02
    z[5,6,2]  R1960     2.4535308778285980e-01
    z[5,6,2]  R1961     3.2142975926399231e-01
    z[5,6,2]  R1962     4.4560468196868896e-01
    z[5,6,2]  R1963     -6.0879337787628174e-01
    z[5,6,2]  R1964     -1.8976964056491852e-01
    z[5,6,2]  R1965     1.0416872799396515e-01
    z[5,6,2]  R1966     -0.0739772841334343
    z[5,6,2]  R1967     -3.9403924345970154e-01
    z[5,6,2]  R1968     -3.6850400269031525e-02
    z[5,6,2]  R1969     9.6790334209799767e-03
    z[5,6,2]  R1970     -1.1283116042613983e-01
    z[5,6,2]  R1971     -5.8049482107162476e-01
    z[5,6,2]  R1972     -3.1603699922561646e-01
    z[5,6,2]  R1973     -2.2508840262889862e-01
    z[5,6,2]  R1974     -2.2061146795749664e-01
    z[5,6,2]  R1975     6.5723694860935211e-02
    z[5,6,2]  R1976     1.0464729368686676e-01
    z[5,6,2]  R1977     -3.3608219027519226e-01
    z[5,6,2]  R1978     1.2708115577697754e-01
    z[5,6,2]  R1979     -1.5526810288429260e-01
    z[5,6,2]  R1980     5.6466263532638550e-01
    z[5,6,2]  R1981     2.2702223062515259e-01
    z[5,6,2]  R1982     3.7101350724697113e-02
    z[5,6,2]  R1983     -7.1581047773361206e-01
    z[5,6,2]  R1984     -5.6525085121393204e-02
    z[5,6,2]  R1985     1.6549895703792572e-01
    z[5,6,2]  R1986     2.0005920529365540e-01
    z[5,6,2]  R1987     5.7398986071348190e-02
    z[5,6,2]  R1988     5.1809096336364746e-01
    z[5,6,2]  R1989     3.2539409399032593e-01
    z[5,6,2]  R1990     4.1225567460060120e-01
    z[5,6,2]  R1991     -5.2013248205184937e-02
    z[5,6,2]  R1992     -0.448064386844635
    z[5,6,2]  R1993     -7.5722610950469971e-01
    z[5,6,2]  R1994     1.5022765100002289e-01
    z[5,6,2]  R1995     3.5219088196754456e-02
    z[5,6,2]  R1996     -2.9492512345314026e-01
    z[5,6,2]  R1997     6.9097101688385010e-02
    z[5,6,2]  R1998     4.5762678980827332e-01
    z[5,6,2]  R1999     2.9374626278877258e-01
    z[5,6,2]  R2000     3.4706103801727295e-01
    z[5,6,2]  R2001     3.4038335084915161e-02
    z[5,6,2]  R2002     4.5589277148246765e-01
    z[5,6,2]  R2003     2.3930977284908295e-01
    z[5,6,2]  R2004     -3.7173950672149658e-01
    z[5,6,2]  R2005     -2.8745934367179871e-01
    z[5,6,2]  R2006     -1.4560824632644653e-01
    z[5,6,2]  R2007     -8.7256854772567749e-01
    z[5,6,2]  R2008     -1.1744989454746246e-01
    z[5,6,2]  R2009     -4.3234601616859436e-01
    z[5,6,2]  R2010     -3.4299165010452271e-01
    z[5,6,2]  R2011     2.4135966598987579e-01
    z[5,6,2]  R2012     2.6430648565292358e-01
    z[5,6,2]  R2013     -6.6871635615825653e-02
    z[5,6,2]  R2014     -6.3241875171661377e-01
    z[5,6,2]  R2015     -3.4111383557319641e-01
    z[5,6,2]  R2016     -1.9173752516508102e-02
    z[5,6,2]  R2017     -6.3163924217224121e-01
    z[5,6,2]  R2018     -6.2527966499328613e-01
    z[5,6,2]  R2019     -1.0322622023522854e-02
    z[5,6,2]  R2020     2.7545309066772461e-01
    z[5,6,2]  R2021     -3.8440433144569397e-01
    z[5,6,2]  R2022     -2.7846693992614746e-01
    z[5,6,2]  R2023     -6.2393105030059814e-01
    z[5,6,2]  R2024     -2.9403015971183777e-01
    z[5,6,2]  R2025     -1.2160907685756683e-01
    z[5,6,2]  R2026     -2.1963237226009369e-01
    z[5,6,2]  R2027     7.1824967861175537e-02
    z[5,6,2]  R2028     4.4677847623825073e-01
    z[5,6,2]  R2029     1.7277929186820984e-01
    z[5,6,2]  R2030     2.5712689757347107e-01
    z[5,6,2]  R2031     2.8299024701118469e-01
    z[5,6,2]  R2032     -7.9229570925235748e-02
    z[5,6,2]  R2033     -0.445634663105011
    z[5,6,2]  R2034     -3.2915511727333069e-01
    z[5,6,2]  R2035     -4.6023672819137573e-01
    z[5,6,2]  R2036     -3.5719439387321472e-02
    z[5,6,2]  R2037     -9.5851331949234009e-02
    z[5,6,2]  R2038     -9.6563011407852173e-02
    z[5,6,2]  R2039     -3.4215632826089859e-02
    z[5,6,2]  R2040     6.9477267563343048e-02
    z[5,6,2]  R2041     -1.9786764681339264e-01
    z[5,6,2]  R2042     3.0728954076766968e-01
    z[5,6,2]  R2043     -3.3947271108627319e-01
    z[5,6,2]  R2044     -4.6295535564422607e-01
    z[5,6,2]  R2045     0.504423201084137
    z[5,6,2]  R2046     5.6837552785873413e-01
    z[5,6,2]  R2047     4.2655152082443237e-01
    z[5,6,2]  R2048     -4.1214738041162491e-02
    z[5,6,2]  R2049     -2.4300862848758698e-01
    z[5,6,2]  R2050     1.8729472160339355e-01
    z[5,6,2]  R2051     1.6173353791236877e-01
    z[5,6,2]  R2052     -4.1150562465190887e-02
    z[5,6,2]  R2053     8.1113819032907486e-03
    z[5,6,2]  R2054     -3.6531287431716919e-01
    z[5,6,2]  R2055     -4.5597577095031738e-01
    z[5,6,2]  R2056     2.7931693196296692e-01
    z[5,6,2]  R2057     5.2968554198741913e-02
    z[5,6,2]  R2058     -8.2593835890293121e-02
    z[5,6,2]  R2059     -7.6425760984420776e-02
    z[5,6,2]  R2060     2.7393737435340881e-01
    z[5,6,2]  R2061     4.3622571229934692e-01
    z[5,6,2]  R2062     2.5382798910140991e-01
    z[5,6,2]  R2063     5.5028963088989258e-01
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R1916     -1
    z[5,6,3]  R1917     1
    z[5,6,3]  R1924     -4.0296635031700134e-01
    z[5,6,3]  R1925     -5.3747254610061646e-01
    z[5,6,3]  R1926     3.8999652862548828e-01
    z[5,6,3]  R1927     1.8943159282207489e-01
    z[5,6,3]  R1928     -5.6672533974051476e-03
    z[5,6,3]  R1929     -6.5534913539886475e-01
    z[5,6,3]  R1930     -7.3129677772521973e-01
    z[5,6,3]  R1931     -4.1921964287757874e-01
    z[5,6,3]  R1932     -5.7796392589807510e-02
    z[5,6,3]  R1933     -1.8595364689826965e-01
    z[5,6,3]  R1934     4.8870390653610229e-01
    z[5,6,3]  R1935     5.2809065580368042e-01
    z[5,6,3]  R1936     -1.1364148557186127e-01
    z[5,6,3]  R1937     1.1756717227399349e-02
    z[5,6,3]  R1938     3.9626678824424744e-01
    z[5,6,3]  R1939     4.6743705868721008e-01
    z[5,6,3]  R1940     -5.4867319762706757e-02
    z[5,6,3]  R1941     3.5917188972234726e-02
    z[5,6,3]  R1942     1.1144948750734329e-01
    z[5,6,3]  R1943     4.9830180406570435e-01
    z[5,6,3]  R1944     -0.0093460688367486
    z[5,6,3]  R1945     -3.8008257746696472e-01
    z[5,6,3]  R1946     3.7454792857170105e-01
    z[5,6,3]  R1947     -2.9269483685493469e-01
    z[5,6,3]  R1948     1.7930108308792114e-01
    z[5,6,3]  R1949     -1.6624249517917633e-01
    z[5,6,3]  R1950     -2.1269553899765015e-01
    z[5,6,3]  R1951     -1.9685249030590057e-01
    z[5,6,3]  R1952     3.4639306366443634e-02
    z[5,6,3]  R1953     2.5832358002662659e-01
    z[5,6,3]  R1954     -2.4320723116397858e-01
    z[5,6,3]  R1955     1.0809340327978134e-01
    z[5,6,3]  R1956     6.3858258724212646e-01
    z[5,6,3]  R1957     6.7080706357955933e-01
    z[5,6,3]  R1958     5.9035187959671021e-01
    z[5,6,3]  R1959     0.41353839635849
    z[5,6,3]  R1960     0.696344792842865
    z[5,6,3]  R1961     5.4434329271316528e-01
    z[5,6,3]  R1962     2.2740148007869720e-01
    z[5,6,3]  R1963     -3.5715955495834351e-01
    z[5,6,3]  R1964     5.2272051572799683e-01
    z[5,6,3]  R1965     1.8101263046264648e-01
    z[5,6,3]  R1966     4.3131539225578308e-01
    z[5,6,3]  R1967     2.4780897796154022e-01
    z[5,6,3]  R1968     0.7169149518013
    z[5,6,3]  R1969     1.5931184589862823e-01
    z[5,6,3]  R1970     -2.0667349454015493e-03
    z[5,6,3]  R1971     -1.7180286347866058e-01
    z[5,6,3]  R1972     -7.6556265354156494e-01
    z[5,6,3]  R1973     -2.7293208241462708e-01
    z[5,6,3]  R1974     -1.2084152549505234e-01
    z[5,6,3]  R1975     3.8940033316612244e-01
    z[5,6,3]  R1976     3.7436354160308838e-01
    z[5,6,3]  R1977     4.2552683502435684e-02
    z[5,6,3]  R1978     0.262176513671875
    z[5,6,3]  R1979     6.1868435144424438e-01
    z[5,6,3]  R1980     -3.8611480593681335e-01
    z[5,6,3]  R1981     7.3401367664337158e-01
    z[5,6,3]  R1982     -4.6521016955375671e-01
    z[5,6,3]  R1983     -7.6276063919067383e-02
    z[5,6,3]  R1984     7.2090637683868408e-01
    z[5,6,3]  R1985     4.6992671489715576e-01
    z[5,6,3]  R1986     -4.0821766853332520e-01
    z[5,6,3]  R1987     3.0732184648513794e-02
    z[5,6,3]  R1988     1.4271210134029388e-01
    z[5,6,3]  R1989     3.1659308820962906e-02
    z[5,6,3]  R1990     4.8740115761756897e-01
    z[5,6,3]  R1991     1.3294823467731476e-01
    z[5,6,3]  R1992     -4.0946012735366821e-01
    z[5,6,3]  R1993     -5.2992874383926392e-01
    z[5,6,3]  R1994     -4.6401867270469666e-01
    z[5,6,3]  R1995     7.6905030012130737e-01
    z[5,6,3]  R1996     -2.9391431808471680e-01
    z[5,6,3]  R1997     -2.2351497411727905e-01
    z[5,6,3]  R1998     1.0619022697210312e-01
    z[5,6,3]  R1999     -1.0161448270082474e-01
    z[5,6,3]  R2000     1.7341688275337219e-02
    z[5,6,3]  R2001     -4.0813955664634705e-01
    z[5,6,3]  R2002     -5.1933777332305908e-01
    z[5,6,3]  R2003     -8.2367813587188721e-01
    z[5,6,3]  R2004     -7.0508822798728943e-02
    z[5,6,3]  R2005     9.4940230250358582e-02
    z[5,6,3]  R2006     -1.3284258544445038e-01
    z[5,6,3]  R2007     1.4472790062427521e-01
    z[5,6,3]  R2008     -1.2247978150844574e-01
    z[5,6,3]  R2009     -6.3021892309188843e-01
    z[5,6,3]  R2010     -5.4533201456069946e-01
    z[5,6,3]  R2011     -6.4684242010116577e-01
    z[5,6,3]  R2012     -4.6773397922515869e-01
    z[5,6,3]  R2013     -6.5646207332611084e-01
    z[5,6,3]  R2014     -1.6425412148237228e-02
    z[5,6,3]  R2015     -1.0423430800437927e-01
    z[5,6,3]  R2016     -3.3338627219200134e-01
    z[5,6,3]  R2017     7.8192614018917084e-02
    z[5,6,3]  R2018     -2.8088778257369995e-01
    z[5,6,3]  R2019     -6.2508940696716309e-01
    z[5,6,3]  R2020     -0.0665508434176445
    z[5,6,3]  R2021     1.7950452864170074e-01
    z[5,6,3]  R2022     -7.0398092269897461e-01
    z[5,6,3]  R2023     -2.9151913523674011e-01
    z[5,6,3]  R2024     1.3151910901069641e-01
    z[5,6,3]  R2025     6.5447628498077393e-02
    z[5,6,3]  R2026     8.8864132761955261e-02
    z[5,6,3]  R2027     -1.2790386378765106e-01
    z[5,6,3]  R2028     6.7232988774776459e-02
    z[5,6,3]  R2029     -1.0288050025701523e-01
    z[5,6,3]  R2030     2.5111887603998184e-02
    z[5,6,3]  R2031     -7.7986180782318115e-02
    z[5,6,3]  R2032     1.1262876540422440e-01
    z[5,6,3]  R2033     3.9240965247154236e-01
    z[5,6,3]  R2034     -5.7974513620138168e-03
    z[5,6,3]  R2035     3.9185520261526108e-02
    z[5,6,3]  R2036     -1.5434567630290985e-01
    z[5,6,3]  R2037     2.6429517194628716e-02
    z[5,6,3]  R2038     4.5138437300920486e-02
    z[5,6,3]  R2039     -3.9570108056068420e-01
    z[5,6,3]  R2040     -7.6664425432682037e-02
    z[5,6,3]  R2041     2.3608018457889557e-01
    z[5,6,3]  R2042     -4.5192936062812805e-01
    z[5,6,3]  R2043     1.4760474860668182e-01
    z[5,6,3]  R2044     -0.664531409740448
    z[5,6,3]  R2045     -4.9170491099357605e-01
    z[5,6,3]  R2046     -3.5445484519004822e-01
    z[5,6,3]  R2047     -2.3440995812416077e-01
    z[5,6,3]  R2048     -4.2044970393180847e-01
    z[5,6,3]  R2049     -3.7721338868141174e-01
    z[5,6,3]  R2050     -3.0410295724868774e-01
    z[5,6,3]  R2051     -3.9489173889160156e-01
    z[5,6,3]  R2052     -4.4229021668434143e-01
    z[5,6,3]  R2053     -3.4535983204841614e-01
    z[5,6,3]  R2054     -2.4242287874221802e-01
    z[5,6,3]  R2055     2.7392679452896118e-01
    z[5,6,3]  R2056     0.0804494097828865
    z[5,6,3]  R2057     -4.0220569819211960e-02
    z[5,6,3]  R2058     -5.7964015007019043e-01
    z[5,6,3]  R2059     -1.2730869650840759e-01
    z[5,6,3]  R2060     -2.5600469112396240e-01
    z[5,6,3]  R2061     -5.8702182769775391e-01
    z[5,6,3]  R2062     -4.7743275761604309e-01
    z[5,6,3]  R2063     8.0001316964626312e-02
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R1918     -1
    z[5,6,4]  R1919     1
    z[5,6,4]  R1924     7.5176376104354858e-01
    z[5,6,4]  R1925     -1.4871887862682343e-01
    z[5,6,4]  R1926     -3.7163731455802917e-01
    z[5,6,4]  R1927     1.2865507602691650e-01
    z[5,6,4]  R1928     -0.0733717754483223
    z[5,6,4]  R1929     1.1783973127603531e-01
    z[5,6,4]  R1930     5.4849749803543091e-01
    z[5,6,4]  R1931     6.2639951705932617e-01
    z[5,6,4]  R1932     -3.5146933794021606e-01
    z[5,6,4]  R1933     5.0835222005844116e-02
    z[5,6,4]  R1934     -5.0168275833129883e-01
    z[5,6,4]  R1935     6.0711979866027832e-01
    z[5,6,4]  R1936     4.4273640960454941e-02
    z[5,6,4]  R1937     -6.4374852180480957e-01
    z[5,6,4]  R1938     -1.6002447903156281e-01
    z[5,6,4]  R1939     -8.7334312498569489e-02
    z[5,6,4]  R1940     -1.5916512906551361e-01
    z[5,6,4]  R1941     1.2083603441715240e-01
    z[5,6,4]  R1942     -2.5509238243103027e-01
    z[5,6,4]  R1943     4.1140943765640259e-01
    z[5,6,4]  R1944     1.1140716820955276e-01
    z[5,6,4]  R1945     3.7780648469924927e-01
    z[5,6,4]  R1946     6.9314420223236084e-02
    z[5,6,4]  R1947     -2.4283558130264282e-01
    z[5,6,4]  R1948     -3.4706154465675354e-01
    z[5,6,4]  R1949     -5.9952008724212646e-01
    z[5,6,4]  R1950     -1.4264552295207977e-01
    z[5,6,4]  R1951     -1.0346832871437073e-01
    z[5,6,4]  R1952     -7.5108265876770020e-01
    z[5,6,4]  R1953     2.7828735113143921e-01
    z[5,6,4]  R1954     -9.1508477926254272e-02
    z[5,6,4]  R1955     -1.3764876127243042e-01
    z[5,6,4]  R1956     -6.9223576784133911e-01
    z[5,6,4]  R1957     2.3049761354923248e-01
    z[5,6,4]  R1958     9.2276886105537415e-02
    z[5,6,4]  R1959     -3.3010292053222656e-01
    z[5,6,4]  R1960     -2.3575066030025482e-01
    z[5,6,4]  R1961     1.2148077040910721e-01
    z[5,6,4]  R1962     -3.9655703306198120e-01
    z[5,6,4]  R1963     5.3671054542064667e-02
    z[5,6,4]  R1964     -0.0931900143623352
    z[5,6,4]  R1965     -1.9064508378505707e-01
    z[5,6,4]  R1966     4.2088195681571960e-02
    z[5,6,4]  R1967     -0.507418155670166
    z[5,6,4]  R1968     -1.3674655556678772e-01
    z[5,6,4]  R1969     -8.7358540296554565e-01
    z[5,6,4]  R1970     -8.1932795047760010e-01
    z[5,6,4]  R1971     -2.0943273603916168e-01
    z[5,6,4]  R1972     -1.3228332996368408e-01
    z[5,6,4]  R1973     -4.2033135890960693e-01
    z[5,6,4]  R1974     -2.4451339244842529e-01
    z[5,6,4]  R1975     -6.7833763360977173e-01
    z[5,6,4]  R1976     -4.1297331452369690e-01
    z[5,6,4]  R1977     0.0561286062002182
    z[5,6,4]  R1978     0.399565726518631
    z[5,6,4]  R1979     -3.4178376197814941e-01
    z[5,6,4]  R1980     8.4828995168209076e-02
    z[5,6,4]  R1981     -4.6115365624427795e-01
    z[5,6,4]  R1982     3.9002561569213867e-01
    z[5,6,4]  R1983     0.259692519903183
    z[5,6,4]  R1984     -4.6415838599205017e-01
    z[5,6,4]  R1985     -2.7864843606948853e-01
    z[5,6,4]  R1986     1.4217145740985870e-01
    z[5,6,4]  R1987     2.3603625595569611e-01
    z[5,6,4]  R1988     -4.6134196221828461e-02
    z[5,6,4]  R1989     -5.6159579753875732e-01
    z[5,6,4]  R1990     -1.1255256086587906e-01
    z[5,6,4]  R1991     1.5449588000774384e-01
    z[5,6,4]  R1992     2.8930687904357910e-01
    z[5,6,4]  R1993     2.2097003459930420e-01
    z[5,6,4]  R1994     9.5833852887153625e-02
    z[5,6,4]  R1995     -1.8232512474060059e-01
    z[5,6,4]  R1996     -3.0767528340220451e-02
    z[5,6,4]  R1997     3.5154440999031067e-01
    z[5,6,4]  R1998     -6.1790518462657928e-02
    z[5,6,4]  R1999     -3.3919781446456909e-01
    z[5,6,4]  R2000     4.1360324621200562e-01
    z[5,6,4]  R2001     0.440787136554718
    z[5,6,4]  R2002     3.1244885921478271e-01
    z[5,6,4]  R2003     1.8467611074447632e-01
    z[5,6,4]  R2004     6.6281452775001526e-02
    z[5,6,4]  R2005     -1.7785805463790894e-01
    z[5,6,4]  R2006     -1.5330310165882111e-01
    z[5,6,4]  R2007     2.5056928396224976e-01
    z[5,6,4]  R2008     0.855876624584198
    z[5,6,4]  R2009     4.3965995311737061e-01
    z[5,6,4]  R2010     3.1669247150421143e-01
    z[5,6,4]  R2011     4.6119195222854614e-01
    z[5,6,4]  R2012     6.9981914758682251e-01
    z[5,6,4]  R2013     -3.1441470980644226e-01
    z[5,6,4]  R2014     1.7064402997493744e-01
    z[5,6,4]  R2015     -0.20225889980793
    z[5,6,4]  R2016     -5.3948469460010529e-02
    z[5,6,4]  R2017     2.7750173211097717e-01
    z[5,6,4]  R2018     -4.5872992277145386e-01
    z[5,6,4]  R2019     -1.2366724014282227e-01
    z[5,6,4]  R2020     0.23235984146595
    z[5,6,4]  R2021     9.9264852702617645e-02
    z[5,6,4]  R2022     -5.7973209768533707e-02
    z[5,6,4]  R2023     -2.2962737828493118e-02
    z[5,6,4]  R2024     -8.6468023061752319e-01
    z[5,6,4]  R2025     -7.2321105003356934e-01
    z[5,6,4]  R2026     -7.4332869052886963e-01
    z[5,6,4]  R2027     -0.948615550994873
    z[5,6,4]  R2028     -7.4593675136566162e-01
    z[5,6,4]  R2029     -4.9432826042175293e-01
    z[5,6,4]  R2030     -0.514190673828125
    z[5,6,4]  R2031     -6.4000964164733887e-01
    z[5,6,4]  R2032     3.6670404672622681e-01
    z[5,6,4]  R2033     1.2844231724739075e-01
    z[5,6,4]  R2034     -1.9405518472194672e-01
    z[5,6,4]  R2035     -2.5099015235900879e-01
    z[5,6,4]  R2036     -1.7473381757736206e-01
    z[5,6,4]  R2037     8.3880260586738586e-02
    z[5,6,4]  R2038     -1.0158686339855194e-01
    z[5,6,4]  R2039     5.8162909746170044e-01
    z[5,6,4]  R2040     -5.7438635826110840e-01
    z[5,6,4]  R2041     -3.3861798048019409e-01
    z[5,6,4]  R2042     -9.3943439424037933e-02
    z[5,6,4]  R2043     -4.4701397418975830e-01
    z[5,6,4]  R2044     6.1733699403703213e-03
    z[5,6,4]  R2045     2.7794754132628441e-02
    z[5,6,4]  R2046     2.9193648695945740e-01
    z[5,6,4]  R2047     7.4327546358108521e-01
    z[5,6,4]  R2048     -1.4449569582939148e-01
    z[5,6,4]  R2049     -1.2018053978681564e-01
    z[5,6,4]  R2050     3.3682264387607574e-02
    z[5,6,4]  R2051     4.7047054395079613e-03
    z[5,6,4]  R2052     1.2552255392074585e-01
    z[5,6,4]  R2053     2.1860368549823761e-01
    z[5,6,4]  R2054     6.6768713295459747e-02
    z[5,6,4]  R2055     -5.4485595226287842e-01
    z[5,6,4]  R2056     3.0279141664505005e-01
    z[5,6,4]  R2057     -5.5368947982788086e-01
    z[5,6,4]  R2058     3.1811073422431946e-01
    z[5,6,4]  R2059     1.6012330353260040e-01
    z[5,6,4]  R2060     4.5743796229362488e-01
    z[5,6,4]  R2061     -4.7555733472108841e-02
    z[5,6,4]  R2062     -5.4822903126478195e-02
    z[5,6,4]  R2063     -9.4818487763404846e-02
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R1920     -1
    z[5,6,5]  R1921     1
    z[5,6,5]  R1924     2.9332739114761353e-01
    z[5,6,5]  R1925     7.1510946750640869e-01
    z[5,6,5]  R1926     -5.2475024014711380e-02
    z[5,6,5]  R1927     1.7414024472236633e-01
    z[5,6,5]  R1928     9.1644853353500366e-02
    z[5,6,5]  R1929     6.1001843214035034e-01
    z[5,6,5]  R1930     -2.6714442297816277e-02
    z[5,6,5]  R1931     4.9909198284149170e-01
    z[5,6,5]  R1932     0.280887246131897
    z[5,6,5]  R1933     5.7129483669996262e-02
    z[5,6,5]  R1934     -5.3611123561859131e-01
    z[5,6,5]  R1935     1.0503428988158703e-02
    z[5,6,5]  R1936     7.6457291841506958e-02
    z[5,6,5]  R1937     4.8521704971790314e-02
    z[5,6,5]  R1938     -2.2446073591709137e-02
    z[5,6,5]  R1939     -5.6388586759567261e-01
    z[5,6,5]  R1940     2.0568537712097168e-01
    z[5,6,5]  R1941     -4.4070816040039062e-01
    z[5,6,5]  R1942     4.6067759394645691e-01
    z[5,6,5]  R1943     -2.2795550525188446e-01
    z[5,6,5]  R1944     7.8413665294647217e-02
    z[5,6,5]  R1945     3.5060279071331024e-02
    z[5,6,5]  R1946     -7.6172329485416412e-02
    z[5,6,5]  R1947     -4.0887433290481567e-01
    z[5,6,5]  R1948     2.1426714956760406e-01
    z[5,6,5]  R1949     -2.4813812971115112e-01
    z[5,6,5]  R1950     -3.8117133080959320e-02
    z[5,6,5]  R1951     -2.8980466723442078e-01
    z[5,6,5]  R1952     8.9521482586860657e-02
    z[5,6,5]  R1953     0.304259330034256
    z[5,6,5]  R1954     1.0470122098922729e-01
    z[5,6,5]  R1955     -0.138969287276268
    z[5,6,5]  R1956     1.0573318600654602e-01
    z[5,6,5]  R1957     -0.294136106967926
    z[5,6,5]  R1958     2.9178187251091003e-01
    z[5,6,5]  R1959     3.0617406964302063e-01
    z[5,6,5]  R1960     9.3371786177158356e-02
    z[5,6,5]  R1961     1.0456296615302563e-02
    z[5,6,5]  R1962     -2.1243534982204437e-01
    z[5,6,5]  R1963     1.9443942606449127e-01
    z[5,6,5]  R1964     -2.5983512401580811e-01
    z[5,6,5]  R1965     -5.2789688110351562e-01
    z[5,6,5]  R1966     -3.9663156867027283e-01
    z[5,6,5]  R1967     5.7480856776237488e-02
    z[5,6,5]  R1968     -1.6389995813369751e-01
    z[5,6,5]  R1969     -1.2786342203617096e-01
    z[5,6,5]  R1970     -8.8494569063186646e-02
    z[5,6,5]  R1971     -3.5261037945747375e-01
    z[5,6,5]  R1972     2.0087789744138718e-02
    z[5,6,5]  R1973     -4.8231580853462219e-01
    z[5,6,5]  R1974     -1.7192986607551575e-01
    z[5,6,5]  R1975     -1.9586364924907684e-01
    z[5,6,5]  R1976     -4.2953795194625854e-01
    z[5,6,5]  R1977     -5.1154899597167969e-01
    z[5,6,5]  R1978     -0.486591100692749
    z[5,6,5]  R1979     -1.6131840646266937e-01
    z[5,6,5]  R1980     -2.4157339334487915e-01
    z[5,6,5]  R1981     2.4367275834083557e-01
    z[5,6,5]  R1982     0.526871919631958
    z[5,6,5]  R1983     2.3944175243377686e-01
    z[5,6,5]  R1984     -2.7048933506011963e-01
    z[5,6,5]  R1985     -2.3300358653068542e-01
    z[5,6,5]  R1986     -5.4858249425888062e-01
    z[5,6,5]  R1987     -3.0323502421379089e-01
    z[5,6,5]  R1988     -3.1779669225215912e-02
    z[5,6,5]  R1989     2.1713009476661682e-01
    z[5,6,5]  R1990     1.5094964765012264e-02
    z[5,6,5]  R1991     6.5014606714248657e-01
    z[5,6,5]  R1992     3.6648404598236084e-01
    z[5,6,5]  R1993     -2.4043897166848183e-02
    z[5,6,5]  R1994     -3.4174686670303345e-01
    z[5,6,5]  R1995     -1.9944418221712112e-02
    z[5,6,5]  R1996     5.7126116752624512e-01
    z[5,6,5]  R1997     -2.7853599190711975e-01
    z[5,6,5]  R1998     2.5465330481529236e-01
    z[5,6,5]  R1999     4.6998324990272522e-01
    z[5,6,5]  R2000     1.0797326266765594e-01
    z[5,6,5]  R2001     5.5890262126922607e-01
    z[5,6,5]  R2002     5.9055322408676147e-01
    z[5,6,5]  R2003     3.2658642530441284e-01
    z[5,6,5]  R2004     4.8542496562004089e-01
    z[5,6,5]  R2005     1.8669515848159790e-01
    z[5,6,5]  R2006     2.8619608283042908e-01
    z[5,6,5]  R2007     7.8315190970897675e-02
    z[5,6,5]  R2008     -6.9425147958099842e-03
    z[5,6,5]  R2009     7.7991865575313568e-02
    z[5,6,5]  R2010     -5.2326135337352753e-02
    z[5,6,5]  R2011     -2.3462414741516113e-02
    z[5,6,5]  R2012     2.8280675411224365e-01
    z[5,6,5]  R2013     5.0893360376358032e-01
    z[5,6,5]  R2014     -1.3342197239398956e-01
    z[5,6,5]  R2015     0.222257599234581
    z[5,6,5]  R2016     -3.2663941383361816e-02
    z[5,6,5]  R2017     1.9224016368389130e-01
    z[5,6,5]  R2018     2.3133309185504913e-01
    z[5,6,5]  R2019     -2.0668709278106689e-01
    z[5,6,5]  R2020     1.1456321924924850e-01
    z[5,6,5]  R2021     -2.9772982001304626e-01
    z[5,6,5]  R2022     3.7308186292648315e-01
    z[5,6,5]  R2023     -9.3137592077255249e-02
    z[5,6,5]  R2024     7.0624001324176788e-02
    z[5,6,5]  R2025     -1.5758909285068512e-01
    z[5,6,5]  R2026     -1.2684494256973267e-01
    z[5,6,5]  R2027     6.4915865659713745e-02
    z[5,6,5]  R2028     1.5939299762248993e-01
    z[5,6,5]  R2029     -7.5848239660263062e-01
    z[5,6,5]  R2030     -1.8899640440940857e-01
    z[5,6,5]  R2031     -1.2374006211757660e-01
    z[5,6,5]  R2032     -3.1909587979316711e-01
    z[5,6,5]  R2033     -1.0499091446399689e-01
    z[5,6,5]  R2034     -3.4750068187713623e-01
    z[5,6,5]  R2035     3.3115780353546143e-01
    z[5,6,5]  R2036     3.2358446717262268e-01
    z[5,6,5]  R2037     -1.4920926094055176e-01
    z[5,6,5]  R2038     -8.8428817689418793e-02
    z[5,6,5]  R2039     2.8305667638778687e-01
    z[5,6,5]  R2040     -2.5510206818580627e-01
    z[5,6,5]  R2041     0.258427232503891
    z[5,6,5]  R2042     -2.9234719276428223e-01
    z[5,6,5]  R2043     -5.8472281694412231e-01
    z[5,6,5]  R2044     -1.7226114869117737e-01
    z[5,6,5]  R2045     -4.4372856616973877e-01
    z[5,6,5]  R2046     -1.9516263902187347e-01
    z[5,6,5]  R2047     -2.1163710951805115e-01
    z[5,6,5]  R2048     4.1152812540531158e-02
    z[5,6,5]  R2049     -9.7449183464050293e-02
    z[5,6,5]  R2050     -7.9647347331047058e-02
    z[5,6,5]  R2051     1.3133837282657623e-01
    z[5,6,5]  R2052     -0.0677766501903534
    z[5,6,5]  R2053     2.7804443240165710e-01
    z[5,6,5]  R2054     1.9148682057857513e-01
    z[5,6,5]  R2055     -5.7763832807540894e-01
    z[5,6,5]  R2056     1.6540817916393280e-02
    z[5,6,5]  R2057     7.1140301227569580e-01
    z[5,6,5]  R2058     -1.2283764779567719e-01
    z[5,6,5]  R2059     -1.1809009313583374e-01
    z[5,6,5]  R2060     1.6198110580444336e-01
    z[5,6,5]  R2061     -3.6141928285360336e-02
    z[5,6,5]  R2062     0.120816171169281
    z[5,6,5]  R2063     -3.4882608056068420e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R1922     -1
    z[5,6,6]  R1923     1
    z[5,6,6]  R1924     2.6621580123901367e-01
    z[5,6,6]  R1925     3.0010810494422913e-01
    z[5,6,6]  R1926     3.8044017553329468e-01
    z[5,6,6]  R1927     -1.7489826679229736e-01
    z[5,6,6]  R1928     -2.1970197558403015e-01
    z[5,6,6]  R1929     -3.9699527621269226e-01
    z[5,6,6]  R1930     -3.8570281863212585e-01
    z[5,6,6]  R1931     -3.3717584609985352e-01
    z[5,6,6]  R1932     4.0127000212669373e-01
    z[5,6,6]  R1933     -9.2358618974685669e-02
    z[5,6,6]  R1934     9.3364212661981583e-03
    z[5,6,6]  R1935     1.8575055524706841e-02
    z[5,6,6]  R1936     -0.686257541179657
    z[5,6,6]  R1937     -5.0712901353836060e-01
    z[5,6,6]  R1938     -5.4844814538955688e-01
    z[5,6,6]  R1939     1.1683385819196701e-01
    z[5,6,6]  R1940     5.8028733730316162e-01
    z[5,6,6]  R1941     5.6005173921585083e-01
    z[5,6,6]  R1942     4.2670068144798279e-01
    z[5,6,6]  R1943     4.0735989809036255e-01
    z[5,6,6]  R1944     3.3515495061874390e-01
    z[5,6,6]  R1945     -2.5011441111564636e-01
    z[5,6,6]  R1946     1.5784989297389984e-01
    z[5,6,6]  R1947     -3.0946299433708191e-01
    z[5,6,6]  R1948     -4.8117381334304810e-01
    z[5,6,6]  R1949     1.0222015529870987e-01
    z[5,6,6]  R1950     -2.2296211123466492e-01
    z[5,6,6]  R1951     -3.2010391354560852e-01
    z[5,6,6]  R1952     -4.7038231045007706e-02
    z[5,6,6]  R1953     -1.7150023579597473e-01
    z[5,6,6]  R1954     -4.5805448293685913e-01
    z[5,6,6]  R1955     1.5038771927356720e-01
    z[5,6,6]  R1956     1.9379927217960358e-01
    z[5,6,6]  R1957     -2.2031220793724060e-01
    z[5,6,6]  R1958     -3.7344902753829956e-01
    z[5,6,6]  R1959     1.1838621459901333e-02
    z[5,6,6]  R1960     -2.2365689277648926e-01
    z[5,6,6]  R1961     7.1575768291950226e-02
    z[5,6,6]  R1962     5.3573727607727051e-01
    z[5,6,6]  R1963     -4.0223711729049683e-01
    z[5,6,6]  R1964     -3.0935063958168030e-01
    z[5,6,6]  R1965     -3.0958059430122375e-01
    z[5,6,6]  R1966     4.9714437127113342e-01
    z[5,6,6]  R1967     -2.2677090764045715e-01
    z[5,6,6]  R1968     1.1971540749073029e-01
    z[5,6,6]  R1969     2.3050977289676666e-01
    z[5,6,6]  R1970     -1.7709574103355408e-01
    z[5,6,6]  R1971     1.2278091907501221e-01
    z[5,6,6]  R1972     -1.9041141495108604e-02
    z[5,6,6]  R1973     -1.4525135047733784e-02
    z[5,6,6]  R1974     2.0731000602245331e-01
    z[5,6,6]  R1975     3.8375315070152283e-01
    z[5,6,6]  R1976     1.6119308769702911e-01
    z[5,6,6]  R1977     -2.3104831576347351e-01
    z[5,6,6]  R1978     -2.9836845397949219e-01
    z[5,6,6]  R1979     9.6001133322715759e-02
    z[5,6,6]  R1980     1.9497525691986084e-01
    z[5,6,6]  R1981     -0.196414053440094
    z[5,6,6]  R1982     -4.4452720880508423e-01
    z[5,6,6]  R1983     -3.7463790178298950e-01
    z[5,6,6]  R1984     2.1984319388866425e-01
    z[5,6,6]  R1985     -1.3007242977619171e-01
    z[5,6,6]  R1986     -2.8052901849150658e-02
    z[5,6,6]  R1987     -4.9068778753280640e-01
    z[5,6,6]  R1988     5.1138266921043396e-02
    z[5,6,6]  R1989     2.4880664050579071e-01
    z[5,6,6]  R1990     0.0734206810593605
    z[5,6,6]  R1991     -3.3588579297065735e-01
    z[5,6,6]  R1992     -3.8576945662498474e-01
    z[5,6,6]  R1993     1.3432259857654572e-01
    z[5,6,6]  R1994     1.1812866479158401e-01
    z[5,6,6]  R1995     1.5472298860549927e-01
    z[5,6,6]  R1996     -0.0930066928267479
    z[5,6,6]  R1997     -4.6319490671157837e-01
    z[5,6,6]  R1998     -8.3471322432160378e-03
    z[5,6,6]  R1999     2.3221366107463837e-01
    z[5,6,6]  R2000     -2.5112757086753845e-01
    z[5,6,6]  R2001     2.6935908198356628e-01
    z[5,6,6]  R2002     1.2492532841861248e-02
    z[5,6,6]  R2003     3.2531628012657166e-01
    z[5,6,6]  R2004     -1.6562150418758392e-01
    z[5,6,6]  R2005     3.0944380164146423e-01
    z[5,6,6]  R2006     4.1285109519958496e-01
    z[5,6,6]  R2007     2.9577460885047913e-01
    z[5,6,6]  R2008     -4.3691092729568481e-01
    z[5,6,6]  R2009     4.3494582176208496e-01
    z[5,6,6]  R2010     3.9614251255989075e-01
    z[5,6,6]  R2011     3.7635970115661621e-01
    z[5,6,6]  R2012     2.9134684801101685e-01
    z[5,6,6]  R2013     1.4644193649291992e-01
    z[5,6,6]  R2014     -2.4537183344364166e-02
    z[5,6,6]  R2015     3.9565327763557434e-01
    z[5,6,6]  R2016     6.7452915012836456e-02
    z[5,6,6]  R2017     3.8119873404502869e-01
    z[5,6,6]  R2018     -1.3156446814537048e-01
    z[5,6,6]  R2019     1.5684491395950317e-01
    z[5,6,6]  R2020     1.9448937475681305e-01
    z[5,6,6]  R2021     -3.3003729581832886e-01
    z[5,6,6]  R2022     1.5036197006702423e-01
    z[5,6,6]  R2023     -6.0841190814971924e-01
    z[5,6,6]  R2024     -1.6279883682727814e-01
    z[5,6,6]  R2025     -0.532157301902771
    z[5,6,6]  R2026     -3.0267059803009033e-01
    z[5,6,6]  R2027     -0.271452397108078
    z[5,6,6]  R2028     -1.6251775622367859e-01
    z[5,6,6]  R2029     -0.173447385430336
    z[5,6,6]  R2030     -6.0873341560363770e-01
    z[5,6,6]  R2031     -4.8913916945457458e-01
    z[5,6,6]  R2032     3.9172267913818359e-01
    z[5,6,6]  R2033     3.9505439996719360e-01
    z[5,6,6]  R2034     2.2452731430530548e-01
    z[5,6,6]  R2035     -3.7836560606956482e-01
    z[5,6,6]  R2036     -3.1854078173637390e-02
    z[5,6,6]  R2037     -1.3612571358680725e-01
    z[5,6,6]  R2038     3.0483016371726990e-01
    z[5,6,6]  R2039     -5.9749286621809006e-02
    z[5,6,6]  R2040     2.6242837309837341e-01
    z[5,6,6]  R2041     0.488349974155426
    z[5,6,6]  R2042     -3.0385133624076843e-01
    z[5,6,6]  R2043     2.8920361399650574e-01
    z[5,6,6]  R2044     7.4096307158470154e-02
    z[5,6,6]  R2045     -1.4444592595100403e-01
    z[5,6,6]  R2046     -0.212275892496109
    z[5,6,6]  R2047     -4.5996572822332382e-02
    z[5,6,6]  R2048     5.4994723759591579e-03
    z[5,6,6]  R2049     1.1091116815805435e-01
    z[5,6,6]  R2050     3.0205633491277695e-02
    z[5,6,6]  R2051     -1.9873636960983276e-01
    z[5,6,6]  R2052     -2.5499787926673889e-01
    z[5,6,6]  R2053     7.2888776659965515e-02
    z[5,6,6]  R2054     -4.3196283280849457e-02
    z[5,6,6]  R2055     -2.0454345643520355e-01
    z[5,6,6]  R2056     -4.4320017099380493e-01
    z[5,6,6]  R2057     3.6286197602748871e-02
    z[5,6,6]  R2058     1.6789884865283966e-01
    z[5,6,6]  R2059     -3.1169047579169273e-02
    z[5,6,6]  R2060     -1.0007640719413757e-01
    z[5,6,6]  R2061     1.9297653436660767e-01
    z[5,6,6]  R2062     3.9162772893905640e-01
    z[5,6,6]  R2063     0.514819860458374
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2064     -1
    z[6,5,0]  R2065     1
    z[6,5,0]  R2078     6.1276221275329590e-01
    z[6,5,0]  R2079     4.5041519403457642e-01
    z[6,5,0]  R2080     7.8865963220596313e-01
    z[6,5,0]  R2081     -2.4639409780502319e-01
    z[6,5,0]  R2082     1.6377098858356476e-02
    z[6,5,0]  R2083     -1.1627390235662460e-01
    z[6,5,0]  R2084     -4.9470996856689453e-01
    z[6,5,0]  R2085     -3.7875732779502869e-01
    z[6,5,0]  R2086     -2.3823419213294983e-01
    z[6,5,0]  R2087     -4.1410744190216064e-01
    z[6,5,0]  R2088     -3.6063289642333984e-01
    z[6,5,0]  R2089     -3.6211588978767395e-01
    z[6,5,0]  R2090     -4.6046221256256104e-01
    z[6,5,0]  R2091     1.6052266582846642e-02
    z[6,5,0]  R2092     -6.8675160408020020e-02
    z[6,5,0]  R2093     -9.4422794878482819e-02
    z[6,5,0]  R2094     -1.9267293810844421e-01
    z[6,5,0]  R2095     -2.9476154595613480e-02
    z[6,5,0]  R2096     -1.4457304775714874e-01
    z[6,5,0]  R2097     -0.0837971493601799
    z[6,5,0]  R2098     -3.1692963838577271e-01
    z[6,5,0]  R2099     -3.5143095254898071e-01
    z[6,5,0]  R2100     4.6653710305690765e-02
    z[6,5,0]  R2101     2.4943938478827477e-02
    z[6,5,0]  R2102     -4.3236187100410461e-01
    z[6,5,0]  R2103     -0.120021753013134
    z[6,5,0]  R2104     -3.5201224684715271e-01
    z[6,5,0]  R2105     4.1558140516281128e-01
    z[6,5,0]  R2106     3.8337224721908569e-01
    z[6,5,0]  R2107     1.3972762227058411e-01
    z[6,5,0]  R2108     2.0932084321975708e-01
    z[6,5,0]  R2109     6.7689009010791779e-02
    z[6,5,0]  R2110     1.3679102063179016e-01
    z[6,5,0]  R2111     -0.0431256964802742
    z[6,5,0]  R2112     1.7754010856151581e-01
    z[6,5,0]  R2113     2.9873788356781006e-02
    z[6,5,0]  R2114     -1.5065731480717659e-02
    z[6,5,0]  R2115     -1.4924864470958710e-01
    z[6,5,0]  R2116     2.8897517919540405e-01
    z[6,5,0]  R2117     3.3578014373779297e-01
    z[6,5,0]  R2118     3.3725729584693909e-01
    z[6,5,0]  R2119     4.0198189020156860e-01
    z[6,5,0]  R2120     2.9496408533304930e-03
    z[6,5,0]  R2121     2.8498345613479614e-01
    z[6,5,0]  R2122     -8.2206851243972778e-01
    z[6,5,0]  R2123     -8.2323813438415527e-01
    z[6,5,0]  R2124     -8.6341661214828491e-01
    z[6,5,0]  R2125     -8.0771315097808838e-01
    z[6,5,0]  R2126     -0.781409502029419
    z[6,5,0]  R2127     -8.3696919679641724e-01
    z[6,5,0]  R2128     6.8571992218494415e-02
    z[6,5,0]  R2129     -1.9584028422832489e-01
    z[6,5,0]  R2130     3.4353566169738770e-01
    z[6,5,0]  R2131     -4.1826122999191284e-01
    z[6,5,0]  R2132     -6.9084864854812622e-01
    z[6,5,0]  R2133     -9.3364083766937256e-01
    z[6,5,0]  R2134     -7.7485686540603638e-01
    z[6,5,0]  R2135     -6.2384098768234253e-01
    z[6,5,0]  R2136     -6.7667406797409058e-01
    z[6,5,0]  R2137     -5.3504264354705811e-01
    z[6,5,0]  R2138     -3.3153480291366577e-01
    z[6,5,0]  R2139     -0.270396888256073
    z[6,5,0]  R2140     2.1862052381038666e-01
    z[6,5,0]  R2141     2.7732756733894348e-01
    z[6,5,0]  R2142     -4.0526506304740906e-01
    z[6,5,0]  R2143     -1.5620526671409607e-01
    z[6,5,0]  R2144     -8.9507259428501129e-02
    z[6,5,0]  R2145     -1.6994468867778778e-01
    z[6,5,0]  R2146     -0.250703364610672
    z[6,5,0]  R2147     2.8833541274070740e-01
    z[6,5,0]  R2148     0.385304719209671
    z[6,5,0]  R2149     0.0796690359711647
    z[6,5,0]  R2150     4.2561444640159607e-01
    z[6,5,0]  R2151     3.7661164999008179e-01
    z[6,5,0]  R2152     2.9428660869598389e-01
    z[6,5,0]  R2153     1.0311092436313629e-01
    z[6,5,0]  R2154     4.6421322971582413e-02
    z[6,5,0]  R2155     4.4364559650421143e-01
    z[6,5,0]  R2156     5.0357764959335327e-01
    z[6,5,0]  R2157     2.0000481605529785e-01
    z[6,5,0]  R2158     -1.0121417045593262e-01
    z[6,5,0]  R2159     -1.3475139439105988e-01
    z[6,5,0]  R2160     -1.6032533347606659e-01
    z[6,5,0]  R2161     -3.8989122956991196e-02
    z[6,5,0]  R2162     -1.0579904913902283e-01
    z[6,5,0]  R2163     2.7819040417671204e-01
    z[6,5,0]  R2164     -1.2221422046422958e-01
    z[6,5,0]  R2165     -2.9942116141319275e-01
    z[6,5,0]  R2166     9.1471262276172638e-02
    z[6,5,0]  R2167     5.3104126453399658e-01
    z[6,5,0]  R2168     3.2689875364303589e-01
    z[6,5,0]  R2169     2.6952734589576721e-01
    z[6,5,0]  R2170     8.9986763894557953e-02
    z[6,5,0]  R2171     2.7206912636756897e-01
    z[6,5,0]  R2172     1.6852578148245811e-02
    z[6,5,0]  R2173     4.8067674040794373e-02
    z[6,5,0]  R2174     5.0814390182495117e-02
    z[6,5,0]  R2175     -0.0943196564912796
    z[6,5,0]  R2176     -9.4523094594478607e-02
    z[6,5,0]  R2177     2.4276039004325867e-01
    z[6,5,0]  R2178     3.7563553452491760e-01
    z[6,5,0]  R2179     3.0035263299942017e-01
    z[6,5,0]  R2180     1.8295191228389740e-01
    z[6,5,0]  R2181     4.3913197517395020e-01
    z[6,5,0]  R2182     2.2637119889259338e-01
    z[6,5,0]  R2183     2.5595527887344360e-01
    z[6,5,0]  R2184     3.6129298806190491e-01
    z[6,5,0]  R2185     3.9604946970939636e-01
    z[6,5,0]  R2186     7.9146578907966614e-02
    z[6,5,0]  R2187     4.2139679193496704e-01
    z[6,5,0]  R2188     4.2497593164443970e-01
    z[6,5,0]  R2189     2.0740933716297150e-01
    z[6,5,0]  R2190     1.1835118383169174e-01
    z[6,5,0]  R2191     3.0861017107963562e-01
    z[6,5,0]  R2192     -6.9337459281086922e-03
    z[6,5,0]  R2193     1.9369046390056610e-01
    z[6,5,0]  R2194     -2.3375537991523743e-01
    z[6,5,0]  R2195     3.6900978535413742e-02
    z[6,5,0]  R2196     -2.8620123863220215e-01
    z[6,5,0]  R2197     2.6928946375846863e-01
    z[6,5,0]  R2198     2.8702870011329651e-01
    z[6,5,0]  R2199     3.2271936535835266e-02
    z[6,5,0]  R2200     -0.0276222862303257
    z[6,5,0]  R2201     9.2043019831180573e-03
    z[6,5,0]  R2202     -0.343716561794281
    z[6,5,0]  R2203     -2.2175729274749756e-01
    z[6,5,0]  R2204     -9.4915814697742462e-02
    z[6,5,0]  R2205     -2.2074216604232788e-01
    z[6,5,0]  R2206     2.9744111001491547e-02
    z[6,5,0]  R2207     1.0121062397956848e-01
    z[6,5,0]  R2208     9.6210852265357971e-02
    z[6,5,0]  R2209     1.3581463694572449e-01
    z[6,5,0]  R2210     -1.0095175355672836e-01
    z[6,5,0]  R2211     -5.4806601256132126e-02
    z[6,5,0]  R2212     5.5049747228622437e-01
    z[6,5,0]  R2213     -3.3798721432685852e-01
    z[6,5,0]  R2214     -3.6248758435249329e-01
    z[6,5,0]  R2215     -4.1941866278648376e-01
    z[6,5,0]  R2216     -2.5176367163658142e-01
    z[6,5,0]  R2217     -1.3267327845096588e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2066     -1
    z[6,5,1]  R2067     1
    z[6,5,1]  R2078     -4.6249288320541382e-01
    z[6,5,1]  R2079     -7.3704510927200317e-01
    z[6,5,1]  R2080     -2.5161647796630859e-01
    z[6,5,1]  R2081     2.3816816508769989e-02
    z[6,5,1]  R2082     2.1788033843040466e-01
    z[6,5,1]  R2083     1.1755845695734024e-01
    z[6,5,1]  R2084     -2.8332084417343140e-01
    z[6,5,1]  R2085     -1.5807604789733887e-01
    z[6,5,1]  R2086     -1.3992689782753587e-03
    z[6,5,1]  R2087     0.117411307990551
    z[6,5,1]  R2088     6.4976739883422852e-01
    z[6,5,1]  R2089     7.0342016220092773e-01
    z[6,5,1]  R2090     0.817271888256073
    z[6,5,1]  R2091     5.7912361621856689e-01
    z[6,5,1]  R2092     4.9411904811859131e-01
    z[6,5,1]  R2093     7.1946346759796143e-01
    z[6,5,1]  R2094     8.8183438777923584e-01
    z[6,5,1]  R2095     7.8212618827819824e-01
    z[6,5,1]  R2096     4.9071976542472839e-01
    z[6,5,1]  R2097     3.7327969074249268e-01
    z[6,5,1]  R2098     -1.2900227308273315e-01
    z[6,5,1]  R2099     1.6237090528011322e-01
    z[6,5,1]  R2100     5.3052014112472534e-01
    z[6,5,1]  R2101     9.3510001897811890e-03
    z[6,5,1]  R2102     -2.6308529078960419e-02
    z[6,5,1]  R2103     -3.0889749526977539e-01
    z[6,5,1]  R2104     -3.7239041924476624e-01
    z[6,5,1]  R2105     2.7739086747169495e-01
    z[6,5,1]  R2106     6.6657519340515137e-01
    z[6,5,1]  R2107     6.6656738519668579e-01
    z[6,5,1]  R2108     7.9936319589614868e-01
    z[6,5,1]  R2109     0.682819664478302
    z[6,5,1]  R2110     9.0550339221954346e-01
    z[6,5,1]  R2111     9.6975505352020264e-01
    z[6,5,1]  R2112     0.919813334941864
    z[6,5,1]  R2113     6.4759099483489990e-01
    z[6,5,1]  R2114     7.2470885515213013e-01
    z[6,5,1]  R2115     6.8037277460098267e-01
    z[6,5,1]  R2116     6.5666466951370239e-01
    z[6,5,1]  R2117     3.5335782170295715e-01
    z[6,5,1]  R2118     4.4173008203506470e-01
    z[6,5,1]  R2119     -3.5165590047836304e-01
    z[6,5,1]  R2120     -6.1881011724472046e-01
    z[6,5,1]  R2121     -2.8727304935455322e-01
    z[6,5,1]  R2122     -3.5088992118835449e-01
    z[6,5,1]  R2123     -2.9102388024330139e-01
    z[6,5,1]  R2124     -3.4433019161224365e-01
    z[6,5,1]  R2125     -3.2974857091903687e-01
    z[6,5,1]  R2126     -0.326667457818985
    z[6,5,1]  R2127     -2.2301189601421356e-01
    z[6,5,1]  R2128     8.7182819843292236e-01
    z[6,5,1]  R2129     -7.9527907073497772e-02
    z[6,5,1]  R2130     0.713519811630249
    z[6,5,1]  R2131     -0.0815548226237297
    z[6,5,1]  R2132     -1.8828220665454865e-01
    z[6,5,1]  R2133     -2.5633990764617920e-01
    z[6,5,1]  R2134     -1.1624956130981445e-01
    z[6,5,1]  R2135     -1.8742233514785767e-01
    z[6,5,1]  R2136     -2.8065502643585205e-01
    z[6,5,1]  R2137     -9.3812316656112671e-02
    z[6,5,1]  R2138     0.0476214662194252
    z[6,5,1]  R2139     1.0748263448476791e-01
    z[6,5,1]  R2140     -7.0843541622161865e-01
    z[6,5,1]  R2141     -7.9341602325439453e-01
    z[6,5,1]  R2142     1.4412711560726166e-01
    z[6,5,1]  R2143     4.8449043184518814e-02
    z[6,5,1]  R2144     3.6293938755989075e-02
    z[6,5,1]  R2145     2.6854671537876129e-02
    z[6,5,1]  R2146     1.5831999480724335e-01
    z[6,5,1]  R2147     8.5295155644416809e-02
    z[6,5,1]  R2148     -2.6950734853744507e-01
    z[6,5,1]  R2149     5.7463991641998291e-01
    z[6,5,1]  R2150     5.6482058763504028e-01
    z[6,5,1]  R2151     -3.7953183054924011e-01
    z[6,5,1]  R2152     0.565430760383606
    z[6,5,1]  R2153     5.3390699625015259e-01
    z[6,5,1]  R2154     5.3784149885177612e-01
    z[6,5,1]  R2155     5.2749764919281006e-01
    z[6,5,1]  R2156     5.2360785007476807e-01
    z[6,5,1]  R2157     5.2429425716400146e-01
    z[6,5,1]  R2158     9.0753048658370972e-01
    z[6,5,1]  R2159     0.748072624206543
    z[6,5,1]  R2160     7.4286442995071411e-01
    z[6,5,1]  R2161     6.9485700130462646e-01
    z[6,5,1]  R2162     7.0424479246139526e-01
    z[6,5,1]  R2163     6.7752861976623535e-01
    z[6,5,1]  R2164     9.1798293590545654e-01
    z[6,5,1]  R2165     6.1748200654983521e-01
    z[6,5,1]  R2166     6.4499658346176147e-01
    z[6,5,1]  R2167     5.7632488012313843e-01
    z[6,5,1]  R2168     7.7760022878646851e-01
    z[6,5,1]  R2169     -9.0361207723617554e-01
    z[6,5,1]  R2170     -1.7615698277950287e-01
    z[6,5,1]  R2171     -5.1598149538040161e-01
    z[6,5,1]  R2172     0.626396119594574
    z[6,5,1]  R2173     -7.8454130887985229e-01
    z[6,5,1]  R2174     -0.581381618976593
    z[6,5,1]  R2175     -7.5596773624420166e-01
    z[6,5,1]  R2176     -5.0138765573501587e-01
    z[6,5,1]  R2177     0.490298867225647
    z[6,5,1]  R2178     -6.1461544036865234e-01
    z[6,5,1]  R2179     -6.7476719617843628e-01
    z[6,5,1]  R2180     -6.0727447271347046e-01
    z[6,5,1]  R2181     -5.2752667665481567e-01
    z[6,5,1]  R2182     6.1117631196975708e-01
    z[6,5,1]  R2183     -2.7636510133743286e-01
    z[6,5,1]  R2184     -3.8241308927536011e-01
    z[6,5,1]  R2185     5.4164856672286987e-01
    z[6,5,1]  R2186     5.3805696964263916e-01
    z[6,5,1]  R2187     -5.3642332553863525e-01
    z[6,5,1]  R2188     0.78980952501297
    z[6,5,1]  R2189     -0.394027978181839
    z[6,5,1]  R2190     6.7369186878204346e-01
    z[6,5,1]  R2191     6.8686366081237793e-01
    z[6,5,1]  R2192     6.5545284748077393e-01
    z[6,5,1]  R2193     6.3525545597076416e-01
    z[6,5,1]  R2194     6.1144155263900757e-01
    z[6,5,1]  R2195     -3.1257885694503784e-01
    z[6,5,1]  R2196     2.7013579010963440e-01
    z[6,5,1]  R2197     3.7967661023139954e-01
    z[6,5,1]  R2198     -2.4036408960819244e-01
    z[6,5,1]  R2199     7.7581125497817993e-01
    z[6,5,1]  R2200     6.8602418899536133e-01
    z[6,5,1]  R2201     0.779254138469696
    z[6,5,1]  R2202     7.6636826992034912e-01
    z[6,5,1]  R2203     6.4768815040588379e-01
    z[6,5,1]  R2204     -7.5179100036621094e-01
    z[6,5,1]  R2205     6.0951977968215942e-01
    z[6,5,1]  R2206     5.1368170976638794e-01
    z[6,5,1]  R2207     2.6094493269920349e-01
    z[6,5,1]  R2208     7.8289997577667236e-01
    z[6,5,1]  R2209     -5.7558339834213257e-01
    z[6,5,1]  R2210     6.9318550825119019e-01
    z[6,5,1]  R2211     7.2563600540161133e-01
    z[6,5,1]  R2212     6.3837128877639771e-01
    z[6,5,1]  R2213     6.3189369440078735e-01
    z[6,5,1]  R2214     7.0856159925460815e-01
    z[6,5,1]  R2215     2.7772587537765503e-01
    z[6,5,1]  R2216     -1.1194500327110291e-01
    z[6,5,1]  R2217     0.00939845945686102
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2068     -1
    z[6,5,2]  R2069     1
    z[6,5,2]  R2078     -3.7173950672149658e-01
    z[6,5,2]  R2079     -2.8745934367179871e-01
    z[6,5,2]  R2080     -1.4560824632644653e-01
    z[6,5,2]  R2081     -8.7256854772567749e-01
    z[6,5,2]  R2082     -1.1744989454746246e-01
    z[6,5,2]  R2083     -4.3234601616859436e-01
    z[6,5,2]  R2084     -3.4299165010452271e-01
    z[6,5,2]  R2085     2.4135966598987579e-01
    z[6,5,2]  R2086     2.6430648565292358e-01
    z[6,5,2]  R2087     -6.6871635615825653e-02
    z[6,5,2]  R2088     -6.3241875171661377e-01
    z[6,5,2]  R2089     -3.4111383557319641e-01
    z[6,5,2]  R2090     -1.9173752516508102e-02
    z[6,5,2]  R2091     -6.3163924217224121e-01
    z[6,5,2]  R2092     -6.2527966499328613e-01
    z[6,5,2]  R2093     -1.0322622023522854e-02
    z[6,5,2]  R2094     2.7545309066772461e-01
    z[6,5,2]  R2095     -3.8440433144569397e-01
    z[6,5,2]  R2096     -2.7846693992614746e-01
    z[6,5,2]  R2097     -6.2393105030059814e-01
    z[6,5,2]  R2098     -2.9403015971183777e-01
    z[6,5,2]  R2099     -1.2160907685756683e-01
    z[6,5,2]  R2100     -2.1963237226009369e-01
    z[6,5,2]  R2101     7.1824967861175537e-02
    z[6,5,2]  R2102     4.4677847623825073e-01
    z[6,5,2]  R2103     1.7277929186820984e-01
    z[6,5,2]  R2104     2.5712689757347107e-01
    z[6,5,2]  R2105     2.8299024701118469e-01
    z[6,5,2]  R2106     -7.9229570925235748e-02
    z[6,5,2]  R2107     -0.445634663105011
    z[6,5,2]  R2108     -3.2915511727333069e-01
    z[6,5,2]  R2109     -4.6023672819137573e-01
    z[6,5,2]  R2110     -3.5719439387321472e-02
    z[6,5,2]  R2111     -9.5851331949234009e-02
    z[6,5,2]  R2112     -9.6563011407852173e-02
    z[6,5,2]  R2113     -3.4215632826089859e-02
    z[6,5,2]  R2114     6.9477267563343048e-02
    z[6,5,2]  R2115     -1.9786764681339264e-01
    z[6,5,2]  R2116     3.0728954076766968e-01
    z[6,5,2]  R2117     -3.3947271108627319e-01
    z[6,5,2]  R2118     -4.6295535564422607e-01
    z[6,5,2]  R2119     0.504423201084137
    z[6,5,2]  R2120     5.6837552785873413e-01
    z[6,5,2]  R2121     4.2655152082443237e-01
    z[6,5,2]  R2122     -4.1214738041162491e-02
    z[6,5,2]  R2123     -2.4300862848758698e-01
    z[6,5,2]  R2124     1.8729472160339355e-01
    z[6,5,2]  R2125     1.6173353791236877e-01
    z[6,5,2]  R2126     -4.1150562465190887e-02
    z[6,5,2]  R2127     8.1113819032907486e-03
    z[6,5,2]  R2128     -3.6531287431716919e-01
    z[6,5,2]  R2129     -4.5597577095031738e-01
    z[6,5,2]  R2130     2.7931693196296692e-01
    z[6,5,2]  R2131     5.2968554198741913e-02
    z[6,5,2]  R2132     -8.2593835890293121e-02
    z[6,5,2]  R2133     -7.6425760984420776e-02
    z[6,5,2]  R2134     2.7393737435340881e-01
    z[6,5,2]  R2135     4.3622571229934692e-01
    z[6,5,2]  R2136     2.5382798910140991e-01
    z[6,5,2]  R2137     5.5028963088989258e-01
    z[6,5,2]  R2138     -5.8089841157197952e-02
    z[6,5,2]  R2139     5.3781740367412567e-02
    z[6,5,2]  R2140     -1.1235842853784561e-01
    z[6,5,2]  R2141     -4.2453482747077942e-01
    z[6,5,2]  R2142     -8.6770063638687134e-01
    z[6,5,2]  R2143     1.2496147304773331e-02
    z[6,5,2]  R2144     -7.4474133551120758e-02
    z[6,5,2]  R2145     -1.9873550534248352e-01
    z[6,5,2]  R2146     -7.3844176530838013e-01
    z[6,5,2]  R2147     -9.2770171165466309e-01
    z[6,5,2]  R2148     -2.9775600880384445e-02
    z[6,5,2]  R2149     1.2454776465892792e-01
    z[6,5,2]  R2150     9.0335153043270111e-02
    z[6,5,2]  R2151     -2.0008639991283417e-01
    z[6,5,2]  R2152     -3.3128419518470764e-01
    z[6,5,2]  R2153     3.8284385204315186e-01
    z[6,5,2]  R2154     0.548805832862854
    z[6,5,2]  R2155     -3.3939346671104431e-02
    z[6,5,2]  R2156     2.1307025104761124e-02
    z[6,5,2]  R2157     -2.2281266748905182e-01
    z[6,5,2]  R2158     -1.8753020465373993e-01
    z[6,5,2]  R2159     2.6691302657127380e-01
    z[6,5,2]  R2160     4.9662747979164124e-01
    z[6,5,2]  R2161     3.2873785495758057e-01
    z[6,5,2]  R2162     2.5061208009719849e-01
    z[6,5,2]  R2163     -0.0669524073600769
    z[6,5,2]  R2164     1.6005863249301910e-01
    z[6,5,2]  R2165     -5.4143619537353516e-01
    z[6,5,2]  R2166     7.7883955091238022e-03
    z[6,5,2]  R2167     3.4595331549644470e-01
    z[6,5,2]  R2168     1.3240396045148373e-02
    z[6,5,2]  R2169     -1.9565263390541077e-01
    z[6,5,2]  R2170     1.5860426425933838e-01
    z[6,5,2]  R2171     -1.4689028263092041e-01
    z[6,5,2]  R2172     -1.6035205125808716e-01
    z[6,5,2]  R2173     9.1213919222354889e-02
    z[6,5,2]  R2174     2.4535308778285980e-01
    z[6,5,2]  R2175     3.2142975926399231e-01
    z[6,5,2]  R2176     4.4560468196868896e-01
    z[6,5,2]  R2177     -6.0879337787628174e-01
    z[6,5,2]  R2178     -1.8976964056491852e-01
    z[6,5,2]  R2179     1.0416872799396515e-01
    z[6,5,2]  R2180     -0.0739772841334343
    z[6,5,2]  R2181     -3.9403924345970154e-01
    z[6,5,2]  R2182     -3.6850400269031525e-02
    z[6,5,2]  R2183     9.6790334209799767e-03
    z[6,5,2]  R2184     -1.1283116042613983e-01
    z[6,5,2]  R2185     -5.8049482107162476e-01
    z[6,5,2]  R2186     -3.1603699922561646e-01
    z[6,5,2]  R2187     -2.2508840262889862e-01
    z[6,5,2]  R2188     -2.2061146795749664e-01
    z[6,5,2]  R2189     6.5723694860935211e-02
    z[6,5,2]  R2190     1.0464729368686676e-01
    z[6,5,2]  R2191     -3.3608219027519226e-01
    z[6,5,2]  R2192     1.2708115577697754e-01
    z[6,5,2]  R2193     -1.5526810288429260e-01
    z[6,5,2]  R2194     5.6466263532638550e-01
    z[6,5,2]  R2195     2.2702223062515259e-01
    z[6,5,2]  R2196     3.7101350724697113e-02
    z[6,5,2]  R2197     -7.1581047773361206e-01
    z[6,5,2]  R2198     -5.6525085121393204e-02
    z[6,5,2]  R2199     1.6549895703792572e-01
    z[6,5,2]  R2200     2.0005920529365540e-01
    z[6,5,2]  R2201     5.7398986071348190e-02
    z[6,5,2]  R2202     5.1809096336364746e-01
    z[6,5,2]  R2203     3.2539409399032593e-01
    z[6,5,2]  R2204     4.1225567460060120e-01
    z[6,5,2]  R2205     -5.2013248205184937e-02
    z[6,5,2]  R2206     -0.448064386844635
    z[6,5,2]  R2207     -7.5722610950469971e-01
    z[6,5,2]  R2208     1.5022765100002289e-01
    z[6,5,2]  R2209     3.5219088196754456e-02
    z[6,5,2]  R2210     -2.9492512345314026e-01
    z[6,5,2]  R2211     6.9097101688385010e-02
    z[6,5,2]  R2212     4.5762678980827332e-01
    z[6,5,2]  R2213     2.9374626278877258e-01
    z[6,5,2]  R2214     3.4706103801727295e-01
    z[6,5,2]  R2215     3.4038335084915161e-02
    z[6,5,2]  R2216     4.5589277148246765e-01
    z[6,5,2]  R2217     2.3930977284908295e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2070     -1
    z[6,5,3]  R2071     1
    z[6,5,3]  R2078     -7.0508822798728943e-02
    z[6,5,3]  R2079     9.4940230250358582e-02
    z[6,5,3]  R2080     -1.3284258544445038e-01
    z[6,5,3]  R2081     1.4472790062427521e-01
    z[6,5,3]  R2082     -1.2247978150844574e-01
    z[6,5,3]  R2083     -6.3021892309188843e-01
    z[6,5,3]  R2084     -5.4533201456069946e-01
    z[6,5,3]  R2085     -6.4684242010116577e-01
    z[6,5,3]  R2086     -4.6773397922515869e-01
    z[6,5,3]  R2087     -6.5646207332611084e-01
    z[6,5,3]  R2088     -1.6425412148237228e-02
    z[6,5,3]  R2089     -1.0423430800437927e-01
    z[6,5,3]  R2090     -3.3338627219200134e-01
    z[6,5,3]  R2091     7.8192614018917084e-02
    z[6,5,3]  R2092     -2.8088778257369995e-01
    z[6,5,3]  R2093     -6.2508940696716309e-01
    z[6,5,3]  R2094     -0.0665508434176445
    z[6,5,3]  R2095     1.7950452864170074e-01
    z[6,5,3]  R2096     -7.0398092269897461e-01
    z[6,5,3]  R2097     -2.9151913523674011e-01
    z[6,5,3]  R2098     1.3151910901069641e-01
    z[6,5,3]  R2099     6.5447628498077393e-02
    z[6,5,3]  R2100     8.8864132761955261e-02
    z[6,5,3]  R2101     -1.2790386378765106e-01
    z[6,5,3]  R2102     6.7232988774776459e-02
    z[6,5,3]  R2103     -1.0288050025701523e-01
    z[6,5,3]  R2104     2.5111887603998184e-02
    z[6,5,3]  R2105     -7.7986180782318115e-02
    z[6,5,3]  R2106     1.1262876540422440e-01
    z[6,5,3]  R2107     3.9240965247154236e-01
    z[6,5,3]  R2108     -5.7974513620138168e-03
    z[6,5,3]  R2109     3.9185520261526108e-02
    z[6,5,3]  R2110     -1.5434567630290985e-01
    z[6,5,3]  R2111     2.6429517194628716e-02
    z[6,5,3]  R2112     4.5138437300920486e-02
    z[6,5,3]  R2113     -3.9570108056068420e-01
    z[6,5,3]  R2114     -7.6664425432682037e-02
    z[6,5,3]  R2115     2.3608018457889557e-01
    z[6,5,3]  R2116     -4.5192936062812805e-01
    z[6,5,3]  R2117     1.4760474860668182e-01
    z[6,5,3]  R2118     -0.664531409740448
    z[6,5,3]  R2119     -4.9170491099357605e-01
    z[6,5,3]  R2120     -3.5445484519004822e-01
    z[6,5,3]  R2121     -2.3440995812416077e-01
    z[6,5,3]  R2122     -4.2044970393180847e-01
    z[6,5,3]  R2123     -3.7721338868141174e-01
    z[6,5,3]  R2124     -3.0410295724868774e-01
    z[6,5,3]  R2125     -3.9489173889160156e-01
    z[6,5,3]  R2126     -4.4229021668434143e-01
    z[6,5,3]  R2127     -3.4535983204841614e-01
    z[6,5,3]  R2128     -2.4242287874221802e-01
    z[6,5,3]  R2129     2.7392679452896118e-01
    z[6,5,3]  R2130     0.0804494097828865
    z[6,5,3]  R2131     -4.0220569819211960e-02
    z[6,5,3]  R2132     -5.7964015007019043e-01
    z[6,5,3]  R2133     -1.2730869650840759e-01
    z[6,5,3]  R2134     -2.5600469112396240e-01
    z[6,5,3]  R2135     -5.8702182769775391e-01
    z[6,5,3]  R2136     -4.7743275761604309e-01
    z[6,5,3]  R2137     8.0001316964626312e-02
    z[6,5,3]  R2138     -4.0296635031700134e-01
    z[6,5,3]  R2139     -5.3747254610061646e-01
    z[6,5,3]  R2140     3.8999652862548828e-01
    z[6,5,3]  R2141     1.8943159282207489e-01
    z[6,5,3]  R2142     -5.6672533974051476e-03
    z[6,5,3]  R2143     -6.5534913539886475e-01
    z[6,5,3]  R2144     -7.3129677772521973e-01
    z[6,5,3]  R2145     -4.1921964287757874e-01
    z[6,5,3]  R2146     -5.7796392589807510e-02
    z[6,5,3]  R2147     -1.8595364689826965e-01
    z[6,5,3]  R2148     4.8870390653610229e-01
    z[6,5,3]  R2149     5.2809065580368042e-01
    z[6,5,3]  R2150     -1.1364148557186127e-01
    z[6,5,3]  R2151     1.1756717227399349e-02
    z[6,5,3]  R2152     3.9626678824424744e-01
    z[6,5,3]  R2153     4.6743705868721008e-01
    z[6,5,3]  R2154     -5.4867319762706757e-02
    z[6,5,3]  R2155     3.5917188972234726e-02
    z[6,5,3]  R2156     1.1144948750734329e-01
    z[6,5,3]  R2157     4.9830180406570435e-01
    z[6,5,3]  R2158     -0.0093460688367486
    z[6,5,3]  R2159     -3.8008257746696472e-01
    z[6,5,3]  R2160     3.7454792857170105e-01
    z[6,5,3]  R2161     -2.9269483685493469e-01
    z[6,5,3]  R2162     1.7930108308792114e-01
    z[6,5,3]  R2163     -1.6624249517917633e-01
    z[6,5,3]  R2164     -2.1269553899765015e-01
    z[6,5,3]  R2165     -1.9685249030590057e-01
    z[6,5,3]  R2166     3.4639306366443634e-02
    z[6,5,3]  R2167     2.5832358002662659e-01
    z[6,5,3]  R2168     -2.4320723116397858e-01
    z[6,5,3]  R2169     1.0809340327978134e-01
    z[6,5,3]  R2170     6.3858258724212646e-01
    z[6,5,3]  R2171     6.7080706357955933e-01
    z[6,5,3]  R2172     5.9035187959671021e-01
    z[6,5,3]  R2173     0.41353839635849
    z[6,5,3]  R2174     0.696344792842865
    z[6,5,3]  R2175     5.4434329271316528e-01
    z[6,5,3]  R2176     2.2740148007869720e-01
    z[6,5,3]  R2177     -3.5715955495834351e-01
    z[6,5,3]  R2178     5.2272051572799683e-01
    z[6,5,3]  R2179     1.8101263046264648e-01
    z[6,5,3]  R2180     4.3131539225578308e-01
    z[6,5,3]  R2181     2.4780897796154022e-01
    z[6,5,3]  R2182     0.7169149518013
    z[6,5,3]  R2183     1.5931184589862823e-01
    z[6,5,3]  R2184     -2.0667349454015493e-03
    z[6,5,3]  R2185     -1.7180286347866058e-01
    z[6,5,3]  R2186     -7.6556265354156494e-01
    z[6,5,3]  R2187     -2.7293208241462708e-01
    z[6,5,3]  R2188     -1.2084152549505234e-01
    z[6,5,3]  R2189     3.8940033316612244e-01
    z[6,5,3]  R2190     3.7436354160308838e-01
    z[6,5,3]  R2191     4.2552683502435684e-02
    z[6,5,3]  R2192     0.262176513671875
    z[6,5,3]  R2193     6.1868435144424438e-01
    z[6,5,3]  R2194     -3.8611480593681335e-01
    z[6,5,3]  R2195     7.3401367664337158e-01
    z[6,5,3]  R2196     -4.6521016955375671e-01
    z[6,5,3]  R2197     -7.6276063919067383e-02
    z[6,5,3]  R2198     7.2090637683868408e-01
    z[6,5,3]  R2199     4.6992671489715576e-01
    z[6,5,3]  R2200     -4.0821766853332520e-01
    z[6,5,3]  R2201     3.0732184648513794e-02
    z[6,5,3]  R2202     1.4271210134029388e-01
    z[6,5,3]  R2203     3.1659308820962906e-02
    z[6,5,3]  R2204     4.8740115761756897e-01
    z[6,5,3]  R2205     1.3294823467731476e-01
    z[6,5,3]  R2206     -4.0946012735366821e-01
    z[6,5,3]  R2207     -5.2992874383926392e-01
    z[6,5,3]  R2208     -4.6401867270469666e-01
    z[6,5,3]  R2209     7.6905030012130737e-01
    z[6,5,3]  R2210     -2.9391431808471680e-01
    z[6,5,3]  R2211     -2.2351497411727905e-01
    z[6,5,3]  R2212     1.0619022697210312e-01
    z[6,5,3]  R2213     -1.0161448270082474e-01
    z[6,5,3]  R2214     1.7341688275337219e-02
    z[6,5,3]  R2215     -4.0813955664634705e-01
    z[6,5,3]  R2216     -5.1933777332305908e-01
    z[6,5,3]  R2217     -8.2367813587188721e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2072     -1
    z[6,5,4]  R2073     1
    z[6,5,4]  R2078     6.6281452775001526e-02
    z[6,5,4]  R2079     -1.7785805463790894e-01
    z[6,5,4]  R2080     -1.5330310165882111e-01
    z[6,5,4]  R2081     2.5056928396224976e-01
    z[6,5,4]  R2082     0.855876624584198
    z[6,5,4]  R2083     4.3965995311737061e-01
    z[6,5,4]  R2084     3.1669247150421143e-01
    z[6,5,4]  R2085     4.6119195222854614e-01
    z[6,5,4]  R2086     6.9981914758682251e-01
    z[6,5,4]  R2087     -3.1441470980644226e-01
    z[6,5,4]  R2088     1.7064402997493744e-01
    z[6,5,4]  R2089     -0.20225889980793
    z[6,5,4]  R2090     -5.3948469460010529e-02
    z[6,5,4]  R2091     2.7750173211097717e-01
    z[6,5,4]  R2092     -4.5872992277145386e-01
    z[6,5,4]  R2093     -1.2366724014282227e-01
    z[6,5,4]  R2094     0.23235984146595
    z[6,5,4]  R2095     9.9264852702617645e-02
    z[6,5,4]  R2096     -5.7973209768533707e-02
    z[6,5,4]  R2097     -2.2962737828493118e-02
    z[6,5,4]  R2098     -8.6468023061752319e-01
    z[6,5,4]  R2099     -7.2321105003356934e-01
    z[6,5,4]  R2100     -7.4332869052886963e-01
    z[6,5,4]  R2101     -0.948615550994873
    z[6,5,4]  R2102     -7.4593675136566162e-01
    z[6,5,4]  R2103     -4.9432826042175293e-01
    z[6,5,4]  R2104     -0.514190673828125
    z[6,5,4]  R2105     -6.4000964164733887e-01
    z[6,5,4]  R2106     3.6670404672622681e-01
    z[6,5,4]  R2107     1.2844231724739075e-01
    z[6,5,4]  R2108     -1.9405518472194672e-01
    z[6,5,4]  R2109     -2.5099015235900879e-01
    z[6,5,4]  R2110     -1.7473381757736206e-01
    z[6,5,4]  R2111     8.3880260586738586e-02
    z[6,5,4]  R2112     -1.0158686339855194e-01
    z[6,5,4]  R2113     5.8162909746170044e-01
    z[6,5,4]  R2114     -5.7438635826110840e-01
    z[6,5,4]  R2115     -3.3861798048019409e-01
    z[6,5,4]  R2116     -9.3943439424037933e-02
    z[6,5,4]  R2117     -4.4701397418975830e-01
    z[6,5,4]  R2118     6.1733699403703213e-03
    z[6,5,4]  R2119     2.7794754132628441e-02
    z[6,5,4]  R2120     2.9193648695945740e-01
    z[6,5,4]  R2121     7.4327546358108521e-01
    z[6,5,4]  R2122     -1.4449569582939148e-01
    z[6,5,4]  R2123     -1.2018053978681564e-01
    z[6,5,4]  R2124     3.3682264387607574e-02
    z[6,5,4]  R2125     4.7047054395079613e-03
    z[6,5,4]  R2126     1.2552255392074585e-01
    z[6,5,4]  R2127     2.1860368549823761e-01
    z[6,5,4]  R2128     6.6768713295459747e-02
    z[6,5,4]  R2129     -5.4485595226287842e-01
    z[6,5,4]  R2130     3.0279141664505005e-01
    z[6,5,4]  R2131     -5.5368947982788086e-01
    z[6,5,4]  R2132     3.1811073422431946e-01
    z[6,5,4]  R2133     1.6012330353260040e-01
    z[6,5,4]  R2134     4.5743796229362488e-01
    z[6,5,4]  R2135     -4.7555733472108841e-02
    z[6,5,4]  R2136     -5.4822903126478195e-02
    z[6,5,4]  R2137     -9.4818487763404846e-02
    z[6,5,4]  R2138     7.5176376104354858e-01
    z[6,5,4]  R2139     -1.4871887862682343e-01
    z[6,5,4]  R2140     -3.7163731455802917e-01
    z[6,5,4]  R2141     1.2865507602691650e-01
    z[6,5,4]  R2142     -0.0733717754483223
    z[6,5,4]  R2143     1.1783973127603531e-01
    z[6,5,4]  R2144     5.4849749803543091e-01
    z[6,5,4]  R2145     6.2639951705932617e-01
    z[6,5,4]  R2146     -3.5146933794021606e-01
    z[6,5,4]  R2147     5.0835222005844116e-02
    z[6,5,4]  R2148     -5.0168275833129883e-01
    z[6,5,4]  R2149     6.0711979866027832e-01
    z[6,5,4]  R2150     4.4273640960454941e-02
    z[6,5,4]  R2151     -6.4374852180480957e-01
    z[6,5,4]  R2152     -1.6002447903156281e-01
    z[6,5,4]  R2153     -8.7334312498569489e-02
    z[6,5,4]  R2154     -1.5916512906551361e-01
    z[6,5,4]  R2155     1.2083603441715240e-01
    z[6,5,4]  R2156     -2.5509238243103027e-01
    z[6,5,4]  R2157     4.1140943765640259e-01
    z[6,5,4]  R2158     1.1140716820955276e-01
    z[6,5,4]  R2159     3.7780648469924927e-01
    z[6,5,4]  R2160     6.9314420223236084e-02
    z[6,5,4]  R2161     -2.4283558130264282e-01
    z[6,5,4]  R2162     -3.4706154465675354e-01
    z[6,5,4]  R2163     -5.9952008724212646e-01
    z[6,5,4]  R2164     -1.4264552295207977e-01
    z[6,5,4]  R2165     -1.0346832871437073e-01
    z[6,5,4]  R2166     -7.5108265876770020e-01
    z[6,5,4]  R2167     2.7828735113143921e-01
    z[6,5,4]  R2168     -9.1508477926254272e-02
    z[6,5,4]  R2169     -1.3764876127243042e-01
    z[6,5,4]  R2170     -6.9223576784133911e-01
    z[6,5,4]  R2171     2.3049761354923248e-01
    z[6,5,4]  R2172     9.2276886105537415e-02
    z[6,5,4]  R2173     -3.3010292053222656e-01
    z[6,5,4]  R2174     -2.3575066030025482e-01
    z[6,5,4]  R2175     1.2148077040910721e-01
    z[6,5,4]  R2176     -3.9655703306198120e-01
    z[6,5,4]  R2177     5.3671054542064667e-02
    z[6,5,4]  R2178     -0.0931900143623352
    z[6,5,4]  R2179     -1.9064508378505707e-01
    z[6,5,4]  R2180     4.2088195681571960e-02
    z[6,5,4]  R2181     -0.507418155670166
    z[6,5,4]  R2182     -1.3674655556678772e-01
    z[6,5,4]  R2183     -8.7358540296554565e-01
    z[6,5,4]  R2184     -8.1932795047760010e-01
    z[6,5,4]  R2185     -2.0943273603916168e-01
    z[6,5,4]  R2186     -1.3228332996368408e-01
    z[6,5,4]  R2187     -4.2033135890960693e-01
    z[6,5,4]  R2188     -2.4451339244842529e-01
    z[6,5,4]  R2189     -6.7833763360977173e-01
    z[6,5,4]  R2190     -4.1297331452369690e-01
    z[6,5,4]  R2191     0.0561286062002182
    z[6,5,4]  R2192     0.399565726518631
    z[6,5,4]  R2193     -3.4178376197814941e-01
    z[6,5,4]  R2194     8.4828995168209076e-02
    z[6,5,4]  R2195     -4.6115365624427795e-01
    z[6,5,4]  R2196     3.9002561569213867e-01
    z[6,5,4]  R2197     0.259692519903183
    z[6,5,4]  R2198     -4.6415838599205017e-01
    z[6,5,4]  R2199     -2.7864843606948853e-01
    z[6,5,4]  R2200     1.4217145740985870e-01
    z[6,5,4]  R2201     2.3603625595569611e-01
    z[6,5,4]  R2202     -4.6134196221828461e-02
    z[6,5,4]  R2203     -5.6159579753875732e-01
    z[6,5,4]  R2204     -1.1255256086587906e-01
    z[6,5,4]  R2205     1.5449588000774384e-01
    z[6,5,4]  R2206     2.8930687904357910e-01
    z[6,5,4]  R2207     2.2097003459930420e-01
    z[6,5,4]  R2208     9.5833852887153625e-02
    z[6,5,4]  R2209     -1.8232512474060059e-01
    z[6,5,4]  R2210     -3.0767528340220451e-02
    z[6,5,4]  R2211     3.5154440999031067e-01
    z[6,5,4]  R2212     -6.1790518462657928e-02
    z[6,5,4]  R2213     -3.3919781446456909e-01
    z[6,5,4]  R2214     4.1360324621200562e-01
    z[6,5,4]  R2215     0.440787136554718
    z[6,5,4]  R2216     3.1244885921478271e-01
    z[6,5,4]  R2217     1.8467611074447632e-01
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2074     -1
    z[6,5,5]  R2075     1
    z[6,5,5]  R2078     4.8542496562004089e-01
    z[6,5,5]  R2079     1.8669515848159790e-01
    z[6,5,5]  R2080     2.8619608283042908e-01
    z[6,5,5]  R2081     7.8315190970897675e-02
    z[6,5,5]  R2082     -6.9425147958099842e-03
    z[6,5,5]  R2083     7.7991865575313568e-02
    z[6,5,5]  R2084     -5.2326135337352753e-02
    z[6,5,5]  R2085     -2.3462414741516113e-02
    z[6,5,5]  R2086     2.8280675411224365e-01
    z[6,5,5]  R2087     5.0893360376358032e-01
    z[6,5,5]  R2088     -1.3342197239398956e-01
    z[6,5,5]  R2089     0.222257599234581
    z[6,5,5]  R2090     -3.2663941383361816e-02
    z[6,5,5]  R2091     1.9224016368389130e-01
    z[6,5,5]  R2092     2.3133309185504913e-01
    z[6,5,5]  R2093     -2.0668709278106689e-01
    z[6,5,5]  R2094     1.1456321924924850e-01
    z[6,5,5]  R2095     -2.9772982001304626e-01
    z[6,5,5]  R2096     3.7308186292648315e-01
    z[6,5,5]  R2097     -9.3137592077255249e-02
    z[6,5,5]  R2098     7.0624001324176788e-02
    z[6,5,5]  R2099     -1.5758909285068512e-01
    z[6,5,5]  R2100     -1.2684494256973267e-01
    z[6,5,5]  R2101     6.4915865659713745e-02
    z[6,5,5]  R2102     1.5939299762248993e-01
    z[6,5,5]  R2103     -7.5848239660263062e-01
    z[6,5,5]  R2104     -1.8899640440940857e-01
    z[6,5,5]  R2105     -1.2374006211757660e-01
    z[6,5,5]  R2106     -3.1909587979316711e-01
    z[6,5,5]  R2107     -1.0499091446399689e-01
    z[6,5,5]  R2108     -3.4750068187713623e-01
    z[6,5,5]  R2109     3.3115780353546143e-01
    z[6,5,5]  R2110     3.2358446717262268e-01
    z[6,5,5]  R2111     -1.4920926094055176e-01
    z[6,5,5]  R2112     -8.8428817689418793e-02
    z[6,5,5]  R2113     2.8305667638778687e-01
    z[6,5,5]  R2114     -2.5510206818580627e-01
    z[6,5,5]  R2115     0.258427232503891
    z[6,5,5]  R2116     -2.9234719276428223e-01
    z[6,5,5]  R2117     -5.8472281694412231e-01
    z[6,5,5]  R2118     -1.7226114869117737e-01
    z[6,5,5]  R2119     -4.4372856616973877e-01
    z[6,5,5]  R2120     -1.9516263902187347e-01
    z[6,5,5]  R2121     -2.1163710951805115e-01
    z[6,5,5]  R2122     4.1152812540531158e-02
    z[6,5,5]  R2123     -9.7449183464050293e-02
    z[6,5,5]  R2124     -7.9647347331047058e-02
    z[6,5,5]  R2125     1.3133837282657623e-01
    z[6,5,5]  R2126     -0.0677766501903534
    z[6,5,5]  R2127     2.7804443240165710e-01
    z[6,5,5]  R2128     1.9148682057857513e-01
    z[6,5,5]  R2129     -5.7763832807540894e-01
    z[6,5,5]  R2130     1.6540817916393280e-02
    z[6,5,5]  R2131     7.1140301227569580e-01
    z[6,5,5]  R2132     -1.2283764779567719e-01
    z[6,5,5]  R2133     -1.1809009313583374e-01
    z[6,5,5]  R2134     1.6198110580444336e-01
    z[6,5,5]  R2135     -3.6141928285360336e-02
    z[6,5,5]  R2136     0.120816171169281
    z[6,5,5]  R2137     -3.4882608056068420e-01
    z[6,5,5]  R2138     2.9332739114761353e-01
    z[6,5,5]  R2139     7.1510946750640869e-01
    z[6,5,5]  R2140     -5.2475024014711380e-02
    z[6,5,5]  R2141     1.7414024472236633e-01
    z[6,5,5]  R2142     9.1644853353500366e-02
    z[6,5,5]  R2143     6.1001843214035034e-01
    z[6,5,5]  R2144     -2.6714442297816277e-02
    z[6,5,5]  R2145     4.9909198284149170e-01
    z[6,5,5]  R2146     0.280887246131897
    z[6,5,5]  R2147     5.7129483669996262e-02
    z[6,5,5]  R2148     -5.3611123561859131e-01
    z[6,5,5]  R2149     1.0503428988158703e-02
    z[6,5,5]  R2150     7.6457291841506958e-02
    z[6,5,5]  R2151     4.8521704971790314e-02
    z[6,5,5]  R2152     -2.2446073591709137e-02
    z[6,5,5]  R2153     -5.6388586759567261e-01
    z[6,5,5]  R2154     2.0568537712097168e-01
    z[6,5,5]  R2155     -4.4070816040039062e-01
    z[6,5,5]  R2156     4.6067759394645691e-01
    z[6,5,5]  R2157     -2.2795550525188446e-01
    z[6,5,5]  R2158     7.8413665294647217e-02
    z[6,5,5]  R2159     3.5060279071331024e-02
    z[6,5,5]  R2160     -7.6172329485416412e-02
    z[6,5,5]  R2161     -4.0887433290481567e-01
    z[6,5,5]  R2162     2.1426714956760406e-01
    z[6,5,5]  R2163     -2.4813812971115112e-01
    z[6,5,5]  R2164     -3.8117133080959320e-02
    z[6,5,5]  R2165     -2.8980466723442078e-01
    z[6,5,5]  R2166     8.9521482586860657e-02
    z[6,5,5]  R2167     0.304259330034256
    z[6,5,5]  R2168     1.0470122098922729e-01
    z[6,5,5]  R2169     -0.138969287276268
    z[6,5,5]  R2170     1.0573318600654602e-01
    z[6,5,5]  R2171     -0.294136106967926
    z[6,5,5]  R2172     2.9178187251091003e-01
    z[6,5,5]  R2173     3.0617406964302063e-01
    z[6,5,5]  R2174     9.3371786177158356e-02
    z[6,5,5]  R2175     1.0456296615302563e-02
    z[6,5,5]  R2176     -2.1243534982204437e-01
    z[6,5,5]  R2177     1.9443942606449127e-01
    z[6,5,5]  R2178     -2.5983512401580811e-01
    z[6,5,5]  R2179     -5.2789688110351562e-01
    z[6,5,5]  R2180     -3.9663156867027283e-01
    z[6,5,5]  R2181     5.7480856776237488e-02
    z[6,5,5]  R2182     -1.6389995813369751e-01
    z[6,5,5]  R2183     -1.2786342203617096e-01
    z[6,5,5]  R2184     -8.8494569063186646e-02
    z[6,5,5]  R2185     -3.5261037945747375e-01
    z[6,5,5]  R2186     2.0087789744138718e-02
    z[6,5,5]  R2187     -4.8231580853462219e-01
    z[6,5,5]  R2188     -1.7192986607551575e-01
    z[6,5,5]  R2189     -1.9586364924907684e-01
    z[6,5,5]  R2190     -4.2953795194625854e-01
    z[6,5,5]  R2191     -5.1154899597167969e-01
    z[6,5,5]  R2192     -0.486591100692749
    z[6,5,5]  R2193     -1.6131840646266937e-01
    z[6,5,5]  R2194     -2.4157339334487915e-01
    z[6,5,5]  R2195     2.4367275834083557e-01
    z[6,5,5]  R2196     0.526871919631958
    z[6,5,5]  R2197     2.3944175243377686e-01
    z[6,5,5]  R2198     -2.7048933506011963e-01
    z[6,5,5]  R2199     -2.3300358653068542e-01
    z[6,5,5]  R2200     -5.4858249425888062e-01
    z[6,5,5]  R2201     -3.0323502421379089e-01
    z[6,5,5]  R2202     -3.1779669225215912e-02
    z[6,5,5]  R2203     2.1713009476661682e-01
    z[6,5,5]  R2204     1.5094964765012264e-02
    z[6,5,5]  R2205     6.5014606714248657e-01
    z[6,5,5]  R2206     3.6648404598236084e-01
    z[6,5,5]  R2207     -2.4043897166848183e-02
    z[6,5,5]  R2208     -3.4174686670303345e-01
    z[6,5,5]  R2209     -1.9944418221712112e-02
    z[6,5,5]  R2210     5.7126116752624512e-01
    z[6,5,5]  R2211     -2.7853599190711975e-01
    z[6,5,5]  R2212     2.5465330481529236e-01
    z[6,5,5]  R2213     4.6998324990272522e-01
    z[6,5,5]  R2214     1.0797326266765594e-01
    z[6,5,5]  R2215     5.5890262126922607e-01
    z[6,5,5]  R2216     5.9055322408676147e-01
    z[6,5,5]  R2217     3.2658642530441284e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2076     -1
    z[6,5,6]  R2077     1
    z[6,5,6]  R2078     -1.6562150418758392e-01
    z[6,5,6]  R2079     3.0944380164146423e-01
    z[6,5,6]  R2080     4.1285109519958496e-01
    z[6,5,6]  R2081     2.9577460885047913e-01
    z[6,5,6]  R2082     -4.3691092729568481e-01
    z[6,5,6]  R2083     4.3494582176208496e-01
    z[6,5,6]  R2084     3.9614251255989075e-01
    z[6,5,6]  R2085     3.7635970115661621e-01
    z[6,5,6]  R2086     2.9134684801101685e-01
    z[6,5,6]  R2087     1.4644193649291992e-01
    z[6,5,6]  R2088     -2.4537183344364166e-02
    z[6,5,6]  R2089     3.9565327763557434e-01
    z[6,5,6]  R2090     6.7452915012836456e-02
    z[6,5,6]  R2091     3.8119873404502869e-01
    z[6,5,6]  R2092     -1.3156446814537048e-01
    z[6,5,6]  R2093     1.5684491395950317e-01
    z[6,5,6]  R2094     1.9448937475681305e-01
    z[6,5,6]  R2095     -3.3003729581832886e-01
    z[6,5,6]  R2096     1.5036197006702423e-01
    z[6,5,6]  R2097     -6.0841190814971924e-01
    z[6,5,6]  R2098     -1.6279883682727814e-01
    z[6,5,6]  R2099     -0.532157301902771
    z[6,5,6]  R2100     -3.0267059803009033e-01
    z[6,5,6]  R2101     -0.271452397108078
    z[6,5,6]  R2102     -1.6251775622367859e-01
    z[6,5,6]  R2103     -0.173447385430336
    z[6,5,6]  R2104     -6.0873341560363770e-01
    z[6,5,6]  R2105     -4.8913916945457458e-01
    z[6,5,6]  R2106     3.9172267913818359e-01
    z[6,5,6]  R2107     3.9505439996719360e-01
    z[6,5,6]  R2108     2.2452731430530548e-01
    z[6,5,6]  R2109     -3.7836560606956482e-01
    z[6,5,6]  R2110     -3.1854078173637390e-02
    z[6,5,6]  R2111     -1.3612571358680725e-01
    z[6,5,6]  R2112     3.0483016371726990e-01
    z[6,5,6]  R2113     -5.9749286621809006e-02
    z[6,5,6]  R2114     2.6242837309837341e-01
    z[6,5,6]  R2115     0.488349974155426
    z[6,5,6]  R2116     -3.0385133624076843e-01
    z[6,5,6]  R2117     2.8920361399650574e-01
    z[6,5,6]  R2118     7.4096307158470154e-02
    z[6,5,6]  R2119     -1.4444592595100403e-01
    z[6,5,6]  R2120     -0.212275892496109
    z[6,5,6]  R2121     -4.5996572822332382e-02
    z[6,5,6]  R2122     5.4994723759591579e-03
    z[6,5,6]  R2123     1.1091116815805435e-01
    z[6,5,6]  R2124     3.0205633491277695e-02
    z[6,5,6]  R2125     -1.9873636960983276e-01
    z[6,5,6]  R2126     -2.5499787926673889e-01
    z[6,5,6]  R2127     7.2888776659965515e-02
    z[6,5,6]  R2128     -4.3196283280849457e-02
    z[6,5,6]  R2129     -2.0454345643520355e-01
    z[6,5,6]  R2130     -4.4320017099380493e-01
    z[6,5,6]  R2131     3.6286197602748871e-02
    z[6,5,6]  R2132     1.6789884865283966e-01
    z[6,5,6]  R2133     -3.1169047579169273e-02
    z[6,5,6]  R2134     -1.0007640719413757e-01
    z[6,5,6]  R2135     1.9297653436660767e-01
    z[6,5,6]  R2136     3.9162772893905640e-01
    z[6,5,6]  R2137     0.514819860458374
    z[6,5,6]  R2138     2.6621580123901367e-01
    z[6,5,6]  R2139     3.0010810494422913e-01
    z[6,5,6]  R2140     3.8044017553329468e-01
    z[6,5,6]  R2141     -1.7489826679229736e-01
    z[6,5,6]  R2142     -2.1970197558403015e-01
    z[6,5,6]  R2143     -3.9699527621269226e-01
    z[6,5,6]  R2144     -3.8570281863212585e-01
    z[6,5,6]  R2145     -3.3717584609985352e-01
    z[6,5,6]  R2146     4.0127000212669373e-01
    z[6,5,6]  R2147     -9.2358618974685669e-02
    z[6,5,6]  R2148     9.3364212661981583e-03
    z[6,5,6]  R2149     1.8575055524706841e-02
    z[6,5,6]  R2150     -0.686257541179657
    z[6,5,6]  R2151     -5.0712901353836060e-01
    z[6,5,6]  R2152     -5.4844814538955688e-01
    z[6,5,6]  R2153     1.1683385819196701e-01
    z[6,5,6]  R2154     5.8028733730316162e-01
    z[6,5,6]  R2155     5.6005173921585083e-01
    z[6,5,6]  R2156     4.2670068144798279e-01
    z[6,5,6]  R2157     4.0735989809036255e-01
    z[6,5,6]  R2158     3.3515495061874390e-01
    z[6,5,6]  R2159     -2.5011441111564636e-01
    z[6,5,6]  R2160     1.5784989297389984e-01
    z[6,5,6]  R2161     -3.0946299433708191e-01
    z[6,5,6]  R2162     -4.8117381334304810e-01
    z[6,5,6]  R2163     1.0222015529870987e-01
    z[6,5,6]  R2164     -2.2296211123466492e-01
    z[6,5,6]  R2165     -3.2010391354560852e-01
    z[6,5,6]  R2166     -4.7038231045007706e-02
    z[6,5,6]  R2167     -1.7150023579597473e-01
    z[6,5,6]  R2168     -4.5805448293685913e-01
    z[6,5,6]  R2169     1.5038771927356720e-01
    z[6,5,6]  R2170     1.9379927217960358e-01
    z[6,5,6]  R2171     -2.2031220793724060e-01
    z[6,5,6]  R2172     -3.7344902753829956e-01
    z[6,5,6]  R2173     1.1838621459901333e-02
    z[6,5,6]  R2174     -2.2365689277648926e-01
    z[6,5,6]  R2175     7.1575768291950226e-02
    z[6,5,6]  R2176     5.3573727607727051e-01
    z[6,5,6]  R2177     -4.0223711729049683e-01
    z[6,5,6]  R2178     -3.0935063958168030e-01
    z[6,5,6]  R2179     -3.0958059430122375e-01
    z[6,5,6]  R2180     4.9714437127113342e-01
    z[6,5,6]  R2181     -2.2677090764045715e-01
    z[6,5,6]  R2182     1.1971540749073029e-01
    z[6,5,6]  R2183     2.3050977289676666e-01
    z[6,5,6]  R2184     -1.7709574103355408e-01
    z[6,5,6]  R2185     1.2278091907501221e-01
    z[6,5,6]  R2186     -1.9041141495108604e-02
    z[6,5,6]  R2187     -1.4525135047733784e-02
    z[6,5,6]  R2188     2.0731000602245331e-01
    z[6,5,6]  R2189     3.8375315070152283e-01
    z[6,5,6]  R2190     1.6119308769702911e-01
    z[6,5,6]  R2191     -2.3104831576347351e-01
    z[6,5,6]  R2192     -2.9836845397949219e-01
    z[6,5,6]  R2193     9.6001133322715759e-02
    z[6,5,6]  R2194     1.9497525691986084e-01
    z[6,5,6]  R2195     -0.196414053440094
    z[6,5,6]  R2196     -4.4452720880508423e-01
    z[6,5,6]  R2197     -3.7463790178298950e-01
    z[6,5,6]  R2198     2.1984319388866425e-01
    z[6,5,6]  R2199     -1.3007242977619171e-01
    z[6,5,6]  R2200     -2.8052901849150658e-02
    z[6,5,6]  R2201     -4.9068778753280640e-01
    z[6,5,6]  R2202     5.1138266921043396e-02
    z[6,5,6]  R2203     2.4880664050579071e-01
    z[6,5,6]  R2204     0.0734206810593605
    z[6,5,6]  R2205     -3.3588579297065735e-01
    z[6,5,6]  R2206     -3.8576945662498474e-01
    z[6,5,6]  R2207     1.3432259857654572e-01
    z[6,5,6]  R2208     1.1812866479158401e-01
    z[6,5,6]  R2209     1.5472298860549927e-01
    z[6,5,6]  R2210     -0.0930066928267479
    z[6,5,6]  R2211     -4.6319490671157837e-01
    z[6,5,6]  R2212     -8.3471322432160378e-03
    z[6,5,6]  R2213     2.3221366107463837e-01
    z[6,5,6]  R2214     -2.5112757086753845e-01
    z[6,5,6]  R2215     2.6935908198356628e-01
    z[6,5,6]  R2216     1.2492532841861248e-02
    z[6,5,6]  R2217     3.2531628012657166e-01
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R2218     -1
    z[6,7,0]  R2219     1
    z[6,7,0]  R2232     6.1276221275329590e-01
    z[6,7,0]  R2233     4.5041519403457642e-01
    z[6,7,0]  R2234     7.8865963220596313e-01
    z[6,7,0]  R2235     -2.4639409780502319e-01
    z[6,7,0]  R2236     1.6377098858356476e-02
    z[6,7,0]  R2237     -1.1627390235662460e-01
    z[6,7,0]  R2238     -4.9470996856689453e-01
    z[6,7,0]  R2239     -3.7875732779502869e-01
    z[6,7,0]  R2240     -2.3823419213294983e-01
    z[6,7,0]  R2241     -4.1410744190216064e-01
    z[6,7,0]  R2242     -3.6063289642333984e-01
    z[6,7,0]  R2243     -3.6211588978767395e-01
    z[6,7,0]  R2244     -4.6046221256256104e-01
    z[6,7,0]  R2245     1.6052266582846642e-02
    z[6,7,0]  R2246     -6.8675160408020020e-02
    z[6,7,0]  R2247     -9.4422794878482819e-02
    z[6,7,0]  R2248     -1.9267293810844421e-01
    z[6,7,0]  R2249     -2.9476154595613480e-02
    z[6,7,0]  R2250     -1.4457304775714874e-01
    z[6,7,0]  R2251     -0.0837971493601799
    z[6,7,0]  R2252     -3.1692963838577271e-01
    z[6,7,0]  R2253     -3.5143095254898071e-01
    z[6,7,0]  R2254     4.6653710305690765e-02
    z[6,7,0]  R2255     2.4943938478827477e-02
    z[6,7,0]  R2256     -4.3236187100410461e-01
    z[6,7,0]  R2257     -0.120021753013134
    z[6,7,0]  R2258     -3.5201224684715271e-01
    z[6,7,0]  R2259     4.1558140516281128e-01
    z[6,7,0]  R2260     3.8337224721908569e-01
    z[6,7,0]  R2261     1.3972762227058411e-01
    z[6,7,0]  R2262     2.0932084321975708e-01
    z[6,7,0]  R2263     6.7689009010791779e-02
    z[6,7,0]  R2264     1.3679102063179016e-01
    z[6,7,0]  R2265     -0.0431256964802742
    z[6,7,0]  R2266     1.7754010856151581e-01
    z[6,7,0]  R2267     2.9873788356781006e-02
    z[6,7,0]  R2268     -1.5065731480717659e-02
    z[6,7,0]  R2269     -1.4924864470958710e-01
    z[6,7,0]  R2270     2.8897517919540405e-01
    z[6,7,0]  R2271     3.3578014373779297e-01
    z[6,7,0]  R2272     3.3725729584693909e-01
    z[6,7,0]  R2273     4.0198189020156860e-01
    z[6,7,0]  R2274     2.9496408533304930e-03
    z[6,7,0]  R2275     2.8498345613479614e-01
    z[6,7,0]  R2276     -8.2206851243972778e-01
    z[6,7,0]  R2277     -8.2323813438415527e-01
    z[6,7,0]  R2278     -8.6341661214828491e-01
    z[6,7,0]  R2279     -8.0771315097808838e-01
    z[6,7,0]  R2280     -0.781409502029419
    z[6,7,0]  R2281     -8.3696919679641724e-01
    z[6,7,0]  R2282     6.8571992218494415e-02
    z[6,7,0]  R2283     -1.9584028422832489e-01
    z[6,7,0]  R2284     3.4353566169738770e-01
    z[6,7,0]  R2285     -4.1826122999191284e-01
    z[6,7,0]  R2286     -6.9084864854812622e-01
    z[6,7,0]  R2287     -9.3364083766937256e-01
    z[6,7,0]  R2288     -7.7485686540603638e-01
    z[6,7,0]  R2289     -6.2384098768234253e-01
    z[6,7,0]  R2290     -6.7667406797409058e-01
    z[6,7,0]  R2291     -5.3504264354705811e-01
    z[6,7,0]  R2292     4.7603544592857361e-01
    z[6,7,0]  R2293     3.6790758371353149e-01
    z[6,7,0]  R2294     4.1421744227409363e-01
    z[6,7,0]  R2295     -3.9302725344896317e-02
    z[6,7,0]  R2296     3.1200116872787476e-01
    z[6,7,0]  R2297     3.5082545876502991e-01
    z[6,7,0]  R2298     -8.3406277000904083e-02
    z[6,7,0]  R2299     5.2954941987991333e-01
    z[6,7,0]  R2300     3.5198795795440674e-01
    z[6,7,0]  R2301     0.588661253452301
    z[6,7,0]  R2302     -2.9111906886100769e-01
    z[6,7,0]  R2303     5.9338800609111786e-02
    z[6,7,0]  R2304     -1.7377567291259766e-01
    z[6,7,0]  R2305     2.0256677269935608e-01
    z[6,7,0]  R2306     -1.1065188795328140e-01
    z[6,7,0]  R2307     -8.7795235216617584e-02
    z[6,7,0]  R2308     -3.0642268061637878e-01
    z[6,7,0]  R2309     2.7552178502082825e-01
    z[6,7,0]  R2310     3.7211981415748596e-01
    z[6,7,0]  R2311     6.6856807470321655e-01
    z[6,7,0]  R2312     1.3725635409355164e-01
    z[6,7,0]  R2313     3.8982889056205750e-01
    z[6,7,0]  R2314     -0.123763807117939
    z[6,7,0]  R2315     3.7052273750305176e-01
    z[6,7,0]  R2316     4.1609662771224976e-01
    z[6,7,0]  R2317     2.5699424743652344e-01
    z[6,7,0]  R2318     4.1304844617843628e-01
    z[6,7,0]  R2319     4.1018193960189819e-01
    z[6,7,0]  R2320     -3.0694928765296936e-01
    z[6,7,0]  R2321     2.4791166186332703e-01
    z[6,7,0]  R2322     -0.0092205461114645
    z[6,7,0]  R2323     -2.7029192447662354e-01
    z[6,7,0]  R2324     1.2486063875257969e-02
    z[6,7,0]  R2325     -7.6464004814624786e-02
    z[6,7,0]  R2326     -3.1966125965118408e-01
    z[6,7,0]  R2327     -2.7544555068016052e-01
    z[6,7,0]  R2328     -4.4085282087326050e-01
    z[6,7,0]  R2329     -6.3712352514266968e-01
    z[6,7,0]  R2330     -2.3229372501373291e-01
    z[6,7,0]  R2331     5.8029163628816605e-03
    z[6,7,0]  R2332     -5.2021265029907227e-01
    z[6,7,0]  R2333     3.8525256514549255e-01
    z[6,7,0]  R2334     -3.6801743507385254e-01
    z[6,7,0]  R2335     2.2431758046150208e-01
    z[6,7,0]  R2336     1.1507070809602737e-01
    z[6,7,0]  R2337     -2.2654646635055542e-01
    z[6,7,0]  R2338     8.1596441566944122e-02
    z[6,7,0]  R2339     1.6711363196372986e-01
    z[6,7,0]  R2340     -8.7778925895690918e-01
    z[6,7,0]  R2341     -8.5311925411224365e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R2220     -1
    z[6,7,1]  R2221     1
    z[6,7,1]  R2232     -4.6249288320541382e-01
    z[6,7,1]  R2233     -7.3704510927200317e-01
    z[6,7,1]  R2234     -2.5161647796630859e-01
    z[6,7,1]  R2235     2.3816816508769989e-02
    z[6,7,1]  R2236     2.1788033843040466e-01
    z[6,7,1]  R2237     1.1755845695734024e-01
    z[6,7,1]  R2238     -2.8332084417343140e-01
    z[6,7,1]  R2239     -1.5807604789733887e-01
    z[6,7,1]  R2240     -1.3992689782753587e-03
    z[6,7,1]  R2241     0.117411307990551
    z[6,7,1]  R2242     6.4976739883422852e-01
    z[6,7,1]  R2243     7.0342016220092773e-01
    z[6,7,1]  R2244     0.817271888256073
    z[6,7,1]  R2245     5.7912361621856689e-01
    z[6,7,1]  R2246     4.9411904811859131e-01
    z[6,7,1]  R2247     7.1946346759796143e-01
    z[6,7,1]  R2248     8.8183438777923584e-01
    z[6,7,1]  R2249     7.8212618827819824e-01
    z[6,7,1]  R2250     4.9071976542472839e-01
    z[6,7,1]  R2251     3.7327969074249268e-01
    z[6,7,1]  R2252     -1.2900227308273315e-01
    z[6,7,1]  R2253     1.6237090528011322e-01
    z[6,7,1]  R2254     5.3052014112472534e-01
    z[6,7,1]  R2255     9.3510001897811890e-03
    z[6,7,1]  R2256     -2.6308529078960419e-02
    z[6,7,1]  R2257     -3.0889749526977539e-01
    z[6,7,1]  R2258     -3.7239041924476624e-01
    z[6,7,1]  R2259     2.7739086747169495e-01
    z[6,7,1]  R2260     6.6657519340515137e-01
    z[6,7,1]  R2261     6.6656738519668579e-01
    z[6,7,1]  R2262     7.9936319589614868e-01
    z[6,7,1]  R2263     0.682819664478302
    z[6,7,1]  R2264     9.0550339221954346e-01
    z[6,7,1]  R2265     9.6975505352020264e-01
    z[6,7,1]  R2266     0.919813334941864
    z[6,7,1]  R2267     6.4759099483489990e-01
    z[6,7,1]  R2268     7.2470885515213013e-01
    z[6,7,1]  R2269     6.8037277460098267e-01
    z[6,7,1]  R2270     6.5666466951370239e-01
    z[6,7,1]  R2271     3.5335782170295715e-01
    z[6,7,1]  R2272     4.4173008203506470e-01
    z[6,7,1]  R2273     -3.5165590047836304e-01
    z[6,7,1]  R2274     -6.1881011724472046e-01
    z[6,7,1]  R2275     -2.8727304935455322e-01
    z[6,7,1]  R2276     -3.5088992118835449e-01
    z[6,7,1]  R2277     -2.9102388024330139e-01
    z[6,7,1]  R2278     -3.4433019161224365e-01
    z[6,7,1]  R2279     -3.2974857091903687e-01
    z[6,7,1]  R2280     -0.326667457818985
    z[6,7,1]  R2281     -2.2301189601421356e-01
    z[6,7,1]  R2282     8.7182819843292236e-01
    z[6,7,1]  R2283     -7.9527907073497772e-02
    z[6,7,1]  R2284     0.713519811630249
    z[6,7,1]  R2285     -0.0815548226237297
    z[6,7,1]  R2286     -1.8828220665454865e-01
    z[6,7,1]  R2287     -2.5633990764617920e-01
    z[6,7,1]  R2288     -1.1624956130981445e-01
    z[6,7,1]  R2289     -1.8742233514785767e-01
    z[6,7,1]  R2290     -2.8065502643585205e-01
    z[6,7,1]  R2291     -9.3812316656112671e-02
    z[6,7,1]  R2292     -1.0660460591316223e-01
    z[6,7,1]  R2293     -1.2077955156564713e-01
    z[6,7,1]  R2294     -2.0885924994945526e-01
    z[6,7,1]  R2295     -5.9599387645721436e-01
    z[6,7,1]  R2296     -2.4721232056617737e-01
    z[6,7,1]  R2297     -2.8906211256980896e-01
    z[6,7,1]  R2298     -4.9694183468818665e-01
    z[6,7,1]  R2299     -4.0280455350875854e-01
    z[6,7,1]  R2300     -2.8144043684005737e-01
    z[6,7,1]  R2301     -5.1659953594207764e-01
    z[6,7,1]  R2302     -1.8781755119562149e-02
    z[6,7,1]  R2303     2.2174131870269775e-01
    z[6,7,1]  R2304     1.6783127188682556e-01
    z[6,7,1]  R2305     -3.4644204378128052e-01
    z[6,7,1]  R2306     1.6638845205307007e-01
    z[6,7,1]  R2307     3.4050557017326355e-01
    z[6,7,1]  R2308     8.4921658039093018e-01
    z[6,7,1]  R2309     -5.4452598094940186e-02
    z[6,7,1]  R2310     5.2231132984161377e-02
    z[6,7,1]  R2311     0.0165800079703331
    z[6,7,1]  R2312     8.6523312330245972e-01
    z[6,7,1]  R2313     0.849455714225769
    z[6,7,1]  R2314     8.3081424236297607e-01
    z[6,7,1]  R2315     7.5549054145812988e-01
    z[6,7,1]  R2316     6.9476801156997681e-01
    z[6,7,1]  R2317     7.0348227024078369e-01
    z[6,7,1]  R2318     6.7879295349121094e-01
    z[6,7,1]  R2319     6.7431765794754028e-01
    z[6,7,1]  R2320     0.812117338180542
    z[6,7,1]  R2321     6.5174585580825806e-01
    z[6,7,1]  R2322     0.875145673751831
    z[6,7,1]  R2323     7.7661645412445068e-01
    z[6,7,1]  R2324     3.3691346645355225e-01
    z[6,7,1]  R2325     -1.3373208045959473e-01
    z[6,7,1]  R2326     2.1163500845432281e-01
    z[6,7,1]  R2327     1.4521718025207520e-01
    z[6,7,1]  R2328     2.0001755654811859e-01
    z[6,7,1]  R2329     -1.7763268947601318e-01
    z[6,7,1]  R2330     -4.1447395086288452e-01
    z[6,7,1]  R2331     3.2233405113220215e-01
    z[6,7,1]  R2332     -1.6980348154902458e-02
    z[6,7,1]  R2333     6.8088221549987793e-01
    z[6,7,1]  R2334     1.2809453904628754e-01
    z[6,7,1]  R2335     -3.7579932808876038e-01
    z[6,7,1]  R2336     -7.0018756389617920e-01
    z[6,7,1]  R2337     3.0431863665580750e-01
    z[6,7,1]  R2338     -4.0260177105665207e-02
    z[6,7,1]  R2339     -2.2124862670898438e-01
    z[6,7,1]  R2340     1.3861157000064850e-01
    z[6,7,1]  R2341     2.3196747526526451e-02
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R2222     -1
    z[6,7,2]  R2223     1
    z[6,7,2]  R2232     -3.7173950672149658e-01
    z[6,7,2]  R2233     -2.8745934367179871e-01
    z[6,7,2]  R2234     -1.4560824632644653e-01
    z[6,7,2]  R2235     -8.7256854772567749e-01
    z[6,7,2]  R2236     -1.1744989454746246e-01
    z[6,7,2]  R2237     -4.3234601616859436e-01
    z[6,7,2]  R2238     -3.4299165010452271e-01
    z[6,7,2]  R2239     2.4135966598987579e-01
    z[6,7,2]  R2240     2.6430648565292358e-01
    z[6,7,2]  R2241     -6.6871635615825653e-02
    z[6,7,2]  R2242     -6.3241875171661377e-01
    z[6,7,2]  R2243     -3.4111383557319641e-01
    z[6,7,2]  R2244     -1.9173752516508102e-02
    z[6,7,2]  R2245     -6.3163924217224121e-01
    z[6,7,2]  R2246     -6.2527966499328613e-01
    z[6,7,2]  R2247     -1.0322622023522854e-02
    z[6,7,2]  R2248     2.7545309066772461e-01
    z[6,7,2]  R2249     -3.8440433144569397e-01
    z[6,7,2]  R2250     -2.7846693992614746e-01
    z[6,7,2]  R2251     -6.2393105030059814e-01
    z[6,7,2]  R2252     -2.9403015971183777e-01
    z[6,7,2]  R2253     -1.2160907685756683e-01
    z[6,7,2]  R2254     -2.1963237226009369e-01
    z[6,7,2]  R2255     7.1824967861175537e-02
    z[6,7,2]  R2256     4.4677847623825073e-01
    z[6,7,2]  R2257     1.7277929186820984e-01
    z[6,7,2]  R2258     2.5712689757347107e-01
    z[6,7,2]  R2259     2.8299024701118469e-01
    z[6,7,2]  R2260     -7.9229570925235748e-02
    z[6,7,2]  R2261     -0.445634663105011
    z[6,7,2]  R2262     -3.2915511727333069e-01
    z[6,7,2]  R2263     -4.6023672819137573e-01
    z[6,7,2]  R2264     -3.5719439387321472e-02
    z[6,7,2]  R2265     -9.5851331949234009e-02
    z[6,7,2]  R2266     -9.6563011407852173e-02
    z[6,7,2]  R2267     -3.4215632826089859e-02
    z[6,7,2]  R2268     6.9477267563343048e-02
    z[6,7,2]  R2269     -1.9786764681339264e-01
    z[6,7,2]  R2270     3.0728954076766968e-01
    z[6,7,2]  R2271     -3.3947271108627319e-01
    z[6,7,2]  R2272     -4.6295535564422607e-01
    z[6,7,2]  R2273     0.504423201084137
    z[6,7,2]  R2274     5.6837552785873413e-01
    z[6,7,2]  R2275     4.2655152082443237e-01
    z[6,7,2]  R2276     -4.1214738041162491e-02
    z[6,7,2]  R2277     -2.4300862848758698e-01
    z[6,7,2]  R2278     1.8729472160339355e-01
    z[6,7,2]  R2279     1.6173353791236877e-01
    z[6,7,2]  R2280     -4.1150562465190887e-02
    z[6,7,2]  R2281     8.1113819032907486e-03
    z[6,7,2]  R2282     -3.6531287431716919e-01
    z[6,7,2]  R2283     -4.5597577095031738e-01
    z[6,7,2]  R2284     2.7931693196296692e-01
    z[6,7,2]  R2285     5.2968554198741913e-02
    z[6,7,2]  R2286     -8.2593835890293121e-02
    z[6,7,2]  R2287     -7.6425760984420776e-02
    z[6,7,2]  R2288     2.7393737435340881e-01
    z[6,7,2]  R2289     4.3622571229934692e-01
    z[6,7,2]  R2290     2.5382798910140991e-01
    z[6,7,2]  R2291     5.5028963088989258e-01
    z[6,7,2]  R2292     -2.4987235665321350e-01
    z[6,7,2]  R2293     8.0049097537994385e-02
    z[6,7,2]  R2294     -2.3241643607616425e-01
    z[6,7,2]  R2295     -5.9219084680080414e-02
    z[6,7,2]  R2296     -1.5208722651004791e-01
    z[6,7,2]  R2297     -3.8834550976753235e-01
    z[6,7,2]  R2298     1.2844204902648926e-01
    z[6,7,2]  R2299     7.9727783799171448e-02
    z[6,7,2]  R2300     -3.1406372785568237e-01
    z[6,7,2]  R2301     -2.2537735104560852e-01
    z[6,7,2]  R2302     3.1608071923255920e-01
    z[6,7,2]  R2303     0.568540096282959
    z[6,7,2]  R2304     -1.6008764505386353e-01
    z[6,7,2]  R2305     6.4011670649051666e-02
    z[6,7,2]  R2306     1.6753885149955750e-01
    z[6,7,2]  R2307     -2.5317856669425964e-01
    z[6,7,2]  R2308     5.0702389329671860e-02
    z[6,7,2]  R2309     -3.5285180807113647e-01
    z[6,7,2]  R2310     2.7158821467310190e-03
    z[6,7,2]  R2311     1.0803978657349944e-03
    z[6,7,2]  R2312     -1.3204509019851685e-01
    z[6,7,2]  R2313     -2.4696128070354462e-01
    z[6,7,2]  R2314     1.7244906723499298e-01
    z[6,7,2]  R2315     -6.4365096390247345e-02
    z[6,7,2]  R2316     1.3435410801321268e-03
    z[6,7,2]  R2317     2.3369173705577850e-01
    z[6,7,2]  R2318     -2.3711295425891876e-01
    z[6,7,2]  R2319     4.8450350761413574e-01
    z[6,7,2]  R2320     -4.2923524975776672e-01
    z[6,7,2]  R2321     3.4046009182929993e-01
    z[6,7,2]  R2322     6.1573632061481476e-02
    z[6,7,2]  R2323     -3.5468775033950806e-01
    z[6,7,2]  R2324     6.7794602364301682e-03
    z[6,7,2]  R2325     -7.6889827847480774e-02
    z[6,7,2]  R2326     8.4859818220138550e-02
    z[6,7,2]  R2327     -2.2711716592311859e-01
    z[6,7,2]  R2328     -2.6905193924903870e-01
    z[6,7,2]  R2329     -4.9347379803657532e-01
    z[6,7,2]  R2330     -3.0910629034042358e-01
    z[6,7,2]  R2331     -0.624438464641571
    z[6,7,2]  R2332     -3.9014685153961182e-01
    z[6,7,2]  R2333     3.2838678359985352e-01
    z[6,7,2]  R2334     -6.5237575769424438e-01
    z[6,7,2]  R2335     -2.1648381650447845e-01
    z[6,7,2]  R2336     6.9230437278747559e-02
    z[6,7,2]  R2337     -8.0624055862426758e-01
    z[6,7,2]  R2338     -0.617302417755127
    z[6,7,2]  R2339     -0.723918616771698
    z[6,7,2]  R2340     4.9001105129718781e-02
    z[6,7,2]  R2341     -3.2605963945388794e-01
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R2224     -1
    z[6,7,3]  R2225     1
    z[6,7,3]  R2232     -7.0508822798728943e-02
    z[6,7,3]  R2233     9.4940230250358582e-02
    z[6,7,3]  R2234     -1.3284258544445038e-01
    z[6,7,3]  R2235     1.4472790062427521e-01
    z[6,7,3]  R2236     -1.2247978150844574e-01
    z[6,7,3]  R2237     -6.3021892309188843e-01
    z[6,7,3]  R2238     -5.4533201456069946e-01
    z[6,7,3]  R2239     -6.4684242010116577e-01
    z[6,7,3]  R2240     -4.6773397922515869e-01
    z[6,7,3]  R2241     -6.5646207332611084e-01
    z[6,7,3]  R2242     -1.6425412148237228e-02
    z[6,7,3]  R2243     -1.0423430800437927e-01
    z[6,7,3]  R2244     -3.3338627219200134e-01
    z[6,7,3]  R2245     7.8192614018917084e-02
    z[6,7,3]  R2246     -2.8088778257369995e-01
    z[6,7,3]  R2247     -6.2508940696716309e-01
    z[6,7,3]  R2248     -0.0665508434176445
    z[6,7,3]  R2249     1.7950452864170074e-01
    z[6,7,3]  R2250     -7.0398092269897461e-01
    z[6,7,3]  R2251     -2.9151913523674011e-01
    z[6,7,3]  R2252     1.3151910901069641e-01
    z[6,7,3]  R2253     6.5447628498077393e-02
    z[6,7,3]  R2254     8.8864132761955261e-02
    z[6,7,3]  R2255     -1.2790386378765106e-01
    z[6,7,3]  R2256     6.7232988774776459e-02
    z[6,7,3]  R2257     -1.0288050025701523e-01
    z[6,7,3]  R2258     2.5111887603998184e-02
    z[6,7,3]  R2259     -7.7986180782318115e-02
    z[6,7,3]  R2260     1.1262876540422440e-01
    z[6,7,3]  R2261     3.9240965247154236e-01
    z[6,7,3]  R2262     -5.7974513620138168e-03
    z[6,7,3]  R2263     3.9185520261526108e-02
    z[6,7,3]  R2264     -1.5434567630290985e-01
    z[6,7,3]  R2265     2.6429517194628716e-02
    z[6,7,3]  R2266     4.5138437300920486e-02
    z[6,7,3]  R2267     -3.9570108056068420e-01
    z[6,7,3]  R2268     -7.6664425432682037e-02
    z[6,7,3]  R2269     2.3608018457889557e-01
    z[6,7,3]  R2270     -4.5192936062812805e-01
    z[6,7,3]  R2271     1.4760474860668182e-01
    z[6,7,3]  R2272     -0.664531409740448
    z[6,7,3]  R2273     -4.9170491099357605e-01
    z[6,7,3]  R2274     -3.5445484519004822e-01
    z[6,7,3]  R2275     -2.3440995812416077e-01
    z[6,7,3]  R2276     -4.2044970393180847e-01
    z[6,7,3]  R2277     -3.7721338868141174e-01
    z[6,7,3]  R2278     -3.0410295724868774e-01
    z[6,7,3]  R2279     -3.9489173889160156e-01
    z[6,7,3]  R2280     -4.4229021668434143e-01
    z[6,7,3]  R2281     -3.4535983204841614e-01
    z[6,7,3]  R2282     -2.4242287874221802e-01
    z[6,7,3]  R2283     2.7392679452896118e-01
    z[6,7,3]  R2284     0.0804494097828865
    z[6,7,3]  R2285     -4.0220569819211960e-02
    z[6,7,3]  R2286     -5.7964015007019043e-01
    z[6,7,3]  R2287     -1.2730869650840759e-01
    z[6,7,3]  R2288     -2.5600469112396240e-01
    z[6,7,3]  R2289     -5.8702182769775391e-01
    z[6,7,3]  R2290     -4.7743275761604309e-01
    z[6,7,3]  R2291     8.0001316964626312e-02
    z[6,7,3]  R2292     -6.7224484682083130e-01
    z[6,7,3]  R2293     -7.0029366016387939e-01
    z[6,7,3]  R2294     -6.1937773227691650e-01
    z[6,7,3]  R2295     -7.1388387680053711e-01
    z[6,7,3]  R2296     -4.9720174074172974e-01
    z[6,7,3]  R2297     -6.4908200502395630e-01
    z[6,7,3]  R2298     -5.3357076644897461e-01
    z[6,7,3]  R2299     -7.3130798339843750e-01
    z[6,7,3]  R2300     -6.9445818662643433e-01
    z[6,7,3]  R2301     -5.0333750247955322e-01
    z[6,7,3]  R2302     8.9732266962528229e-02
    z[6,7,3]  R2303     9.4804614782333374e-02
    z[6,7,3]  R2304     1.2280047684907913e-01
    z[6,7,3]  R2305     -5.7932874187827110e-03
    z[6,7,3]  R2306     3.1909137964248657e-02
    z[6,7,3]  R2307     2.1057588979601860e-02
    z[6,7,3]  R2308     -3.4516620635986328e-01
    z[6,7,3]  R2309     8.7836936116218567e-02
    z[6,7,3]  R2310     2.9434330761432648e-02
    z[6,7,3]  R2311     4.8773370683193207e-02
    z[6,7,3]  R2312     -3.7065398693084717e-01
    z[6,7,3]  R2313     -1.7758302390575409e-01
    z[6,7,3]  R2314     2.2660417854785919e-01
    z[6,7,3]  R2315     1.2246348708868027e-01
    z[6,7,3]  R2316     -4.3347876518964767e-02
    z[6,7,3]  R2317     2.0179098471999168e-02
    z[6,7,3]  R2318     1.2138762325048447e-01
    z[6,7,3]  R2319     -8.3573527634143829e-02
    z[6,7,3]  R2320     1.6214302182197571e-01
    z[6,7,3]  R2321     -5.3740464150905609e-02
    z[6,7,3]  R2322     1.3159784674644470e-01
    z[6,7,3]  R2323     -2.7779016643762589e-02
    z[6,7,3]  R2324     -4.5293146371841431e-01
    z[6,7,3]  R2325     -9.1966682672500610e-01
    z[6,7,3]  R2326     -8.2189255952835083e-01
    z[6,7,3]  R2327     -7.0442509651184082e-01
    z[6,7,3]  R2328     -3.1061306595802307e-01
    z[6,7,3]  R2329     -1.7593665421009064e-01
    z[6,7,3]  R2330     1.3717627525329590e-01
    z[6,7,3]  R2331     -3.4871584177017212e-01
    z[6,7,3]  R2332     -0.436395525932312
    z[6,7,3]  R2333     1.4738725125789642e-01
    z[6,7,3]  R2334     -3.3101609349250793e-01
    z[6,7,3]  R2335     -6.1580508947372437e-01
    z[6,7,3]  R2336     -5.5146604776382446e-01
    z[6,7,3]  R2337     -3.0081382393836975e-01
    z[6,7,3]  R2338     1.3018840551376343e-01
    z[6,7,3]  R2339     1.2936544418334961e-01
    z[6,7,3]  R2340     3.0576642602682114e-02
    z[6,7,3]  R2341     -1.2606064788997173e-02
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R2226     -1
    z[6,7,4]  R2227     1
    z[6,7,4]  R2232     6.6281452775001526e-02
    z[6,7,4]  R2233     -1.7785805463790894e-01
    z[6,7,4]  R2234     -1.5330310165882111e-01
    z[6,7,4]  R2235     2.5056928396224976e-01
    z[6,7,4]  R2236     0.855876624584198
    z[6,7,4]  R2237     4.3965995311737061e-01
    z[6,7,4]  R2238     3.1669247150421143e-01
    z[6,7,4]  R2239     4.6119195222854614e-01
    z[6,7,4]  R2240     6.9981914758682251e-01
    z[6,7,4]  R2241     -3.1441470980644226e-01
    z[6,7,4]  R2242     1.7064402997493744e-01
    z[6,7,4]  R2243     -0.20225889980793
    z[6,7,4]  R2244     -5.3948469460010529e-02
    z[6,7,4]  R2245     2.7750173211097717e-01
    z[6,7,4]  R2246     -4.5872992277145386e-01
    z[6,7,4]  R2247     -1.2366724014282227e-01
    z[6,7,4]  R2248     0.23235984146595
    z[6,7,4]  R2249     9.9264852702617645e-02
    z[6,7,4]  R2250     -5.7973209768533707e-02
    z[6,7,4]  R2251     -2.2962737828493118e-02
    z[6,7,4]  R2252     -8.6468023061752319e-01
    z[6,7,4]  R2253     -7.2321105003356934e-01
    z[6,7,4]  R2254     -7.4332869052886963e-01
    z[6,7,4]  R2255     -0.948615550994873
    z[6,7,4]  R2256     -7.4593675136566162e-01
    z[6,7,4]  R2257     -4.9432826042175293e-01
    z[6,7,4]  R2258     -0.514190673828125
    z[6,7,4]  R2259     -6.4000964164733887e-01
    z[6,7,4]  R2260     3.6670404672622681e-01
    z[6,7,4]  R2261     1.2844231724739075e-01
    z[6,7,4]  R2262     -1.9405518472194672e-01
    z[6,7,4]  R2263     -2.5099015235900879e-01
    z[6,7,4]  R2264     -1.7473381757736206e-01
    z[6,7,4]  R2265     8.3880260586738586e-02
    z[6,7,4]  R2266     -1.0158686339855194e-01
    z[6,7,4]  R2267     5.8162909746170044e-01
    z[6,7,4]  R2268     -5.7438635826110840e-01
    z[6,7,4]  R2269     -3.3861798048019409e-01
    z[6,7,4]  R2270     -9.3943439424037933e-02
    z[6,7,4]  R2271     -4.4701397418975830e-01
    z[6,7,4]  R2272     6.1733699403703213e-03
    z[6,7,4]  R2273     2.7794754132628441e-02
    z[6,7,4]  R2274     2.9193648695945740e-01
    z[6,7,4]  R2275     7.4327546358108521e-01
    z[6,7,4]  R2276     -1.4449569582939148e-01
    z[6,7,4]  R2277     -1.2018053978681564e-01
    z[6,7,4]  R2278     3.3682264387607574e-02
    z[6,7,4]  R2279     4.7047054395079613e-03
    z[6,7,4]  R2280     1.2552255392074585e-01
    z[6,7,4]  R2281     2.1860368549823761e-01
    z[6,7,4]  R2282     6.6768713295459747e-02
    z[6,7,4]  R2283     -5.4485595226287842e-01
    z[6,7,4]  R2284     3.0279141664505005e-01
    z[6,7,4]  R2285     -5.5368947982788086e-01
    z[6,7,4]  R2286     3.1811073422431946e-01
    z[6,7,4]  R2287     1.6012330353260040e-01
    z[6,7,4]  R2288     4.5743796229362488e-01
    z[6,7,4]  R2289     -4.7555733472108841e-02
    z[6,7,4]  R2290     -5.4822903126478195e-02
    z[6,7,4]  R2291     -9.4818487763404846e-02
    z[6,7,4]  R2292     2.4950763583183289e-01
    z[6,7,4]  R2293     3.3191773295402527e-01
    z[6,7,4]  R2294     5.4609251022338867e-01
    z[6,7,4]  R2295     3.4516081213951111e-01
    z[6,7,4]  R2296     6.8939322233200073e-01
    z[6,7,4]  R2297     3.4546619653701782e-01
    z[6,7,4]  R2298     0.305010050535202
    z[6,7,4]  R2299     3.4637738019227982e-02
    z[6,7,4]  R2300     -1.0367469489574432e-01
    z[6,7,4]  R2301     5.8627333492040634e-02
    z[6,7,4]  R2302     -8.0068618059158325e-01
    z[6,7,4]  R2303     -6.6231417655944824e-01
    z[6,7,4]  R2304     -9.4892930984497070e-01
    z[6,7,4]  R2305     -8.8086354732513428e-01
    z[6,7,4]  R2306     -8.6299884319305420e-01
    z[6,7,4]  R2307     -7.6170092821121216e-01
    z[6,7,4]  R2308     1.0170640423893929e-02
    z[6,7,4]  R2309     -6.8199980258941650e-01
    z[6,7,4]  R2310     -6.5378212928771973e-01
    z[6,7,4]  R2311     -6.9943392276763916e-01
    z[6,7,4]  R2312     2.3832754790782928e-01
    z[6,7,4]  R2313     -1.8893703818321228e-02
    z[6,7,4]  R2314     -1.6697883605957031e-01
    z[6,7,4]  R2315     -3.8166046142578125e-01
    z[6,7,4]  R2316     -1.1869627982378006e-01
    z[6,7,4]  R2317     4.3013298511505127e-01
    z[6,7,4]  R2318     -2.4247787892818451e-01
    z[6,7,4]  R2319     -0.0239796731621027
    z[6,7,4]  R2320     -2.1718394011259079e-02
    z[6,7,4]  R2321     2.4207362532615662e-01
    z[6,7,4]  R2322     -1.6972647607326508e-01
    z[6,7,4]  R2323     -3.5508543252944946e-01
    z[6,7,4]  R2324     4.5013442635536194e-01
    z[6,7,4]  R2325     -2.9802310466766357e-01
    z[6,7,4]  R2326     -1.7271572351455688e-01
    z[6,7,4]  R2327     -5.0280994176864624e-01
    z[6,7,4]  R2328     -2.2354270517826080e-01
    z[6,7,4]  R2329     2.9778888821601868e-01
    z[6,7,4]  R2330     -3.0977034568786621e-01
    z[6,7,4]  R2331     -1.1161712557077408e-01
    z[6,7,4]  R2332     1.7979015409946442e-01
    z[6,7,4]  R2333     2.1449477970600128e-01
    z[6,7,4]  R2334     -1.2893806397914886e-01
    z[6,7,4]  R2335     -3.8652592897415161e-01
    z[6,7,4]  R2336     -7.7593587338924408e-02
    z[6,7,4]  R2337     2.7747648954391479e-01
    z[6,7,4]  R2338     -2.9270559549331665e-01
    z[6,7,4]  R2339     -2.2900177538394928e-01
    z[6,7,4]  R2340     7.7248387038707733e-02
    z[6,7,4]  R2341     1.1837456375360489e-02
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R2228     -1
    z[6,7,5]  R2229     1
    z[6,7,5]  R2232     4.8542496562004089e-01
    z[6,7,5]  R2233     1.8669515848159790e-01
    z[6,7,5]  R2234     2.8619608283042908e-01
    z[6,7,5]  R2235     7.8315190970897675e-02
    z[6,7,5]  R2236     -6.9425147958099842e-03
    z[6,7,5]  R2237     7.7991865575313568e-02
    z[6,7,5]  R2238     -5.2326135337352753e-02
    z[6,7,5]  R2239     -2.3462414741516113e-02
    z[6,7,5]  R2240     2.8280675411224365e-01
    z[6,7,5]  R2241     5.0893360376358032e-01
    z[6,7,5]  R2242     -1.3342197239398956e-01
    z[6,7,5]  R2243     0.222257599234581
    z[6,7,5]  R2244     -3.2663941383361816e-02
    z[6,7,5]  R2245     1.9224016368389130e-01
    z[6,7,5]  R2246     2.3133309185504913e-01
    z[6,7,5]  R2247     -2.0668709278106689e-01
    z[6,7,5]  R2248     1.1456321924924850e-01
    z[6,7,5]  R2249     -2.9772982001304626e-01
    z[6,7,5]  R2250     3.7308186292648315e-01
    z[6,7,5]  R2251     -9.3137592077255249e-02
    z[6,7,5]  R2252     7.0624001324176788e-02
    z[6,7,5]  R2253     -1.5758909285068512e-01
    z[6,7,5]  R2254     -1.2684494256973267e-01
    z[6,7,5]  R2255     6.4915865659713745e-02
    z[6,7,5]  R2256     1.5939299762248993e-01
    z[6,7,5]  R2257     -7.5848239660263062e-01
    z[6,7,5]  R2258     -1.8899640440940857e-01
    z[6,7,5]  R2259     -1.2374006211757660e-01
    z[6,7,5]  R2260     -3.1909587979316711e-01
    z[6,7,5]  R2261     -1.0499091446399689e-01
    z[6,7,5]  R2262     -3.4750068187713623e-01
    z[6,7,5]  R2263     3.3115780353546143e-01
    z[6,7,5]  R2264     3.2358446717262268e-01
    z[6,7,5]  R2265     -1.4920926094055176e-01
    z[6,7,5]  R2266     -8.8428817689418793e-02
    z[6,7,5]  R2267     2.8305667638778687e-01
    z[6,7,5]  R2268     -2.5510206818580627e-01
    z[6,7,5]  R2269     0.258427232503891
    z[6,7,5]  R2270     -2.9234719276428223e-01
    z[6,7,5]  R2271     -5.8472281694412231e-01
    z[6,7,5]  R2272     -1.7226114869117737e-01
    z[6,7,5]  R2273     -4.4372856616973877e-01
    z[6,7,5]  R2274     -1.9516263902187347e-01
    z[6,7,5]  R2275     -2.1163710951805115e-01
    z[6,7,5]  R2276     4.1152812540531158e-02
    z[6,7,5]  R2277     -9.7449183464050293e-02
    z[6,7,5]  R2278     -7.9647347331047058e-02
    z[6,7,5]  R2279     1.3133837282657623e-01
    z[6,7,5]  R2280     -0.0677766501903534
    z[6,7,5]  R2281     2.7804443240165710e-01
    z[6,7,5]  R2282     1.9148682057857513e-01
    z[6,7,5]  R2283     -5.7763832807540894e-01
    z[6,7,5]  R2284     1.6540817916393280e-02
    z[6,7,5]  R2285     7.1140301227569580e-01
    z[6,7,5]  R2286     -1.2283764779567719e-01
    z[6,7,5]  R2287     -1.1809009313583374e-01
    z[6,7,5]  R2288     1.6198110580444336e-01
    z[6,7,5]  R2289     -3.6141928285360336e-02
    z[6,7,5]  R2290     0.120816171169281
    z[6,7,5]  R2291     -3.4882608056068420e-01
    z[6,7,5]  R2292     4.2622053623199463e-01
    z[6,7,5]  R2293     4.2791518568992615e-01
    z[6,7,5]  R2294     1.8242482841014862e-01
    z[6,7,5]  R2295     7.0057839155197144e-02
    z[6,7,5]  R2296     2.5204014778137207e-01
    z[6,7,5]  R2297     7.7326498925685883e-02
    z[6,7,5]  R2298     4.1740727424621582e-01
    z[6,7,5]  R2299     1.1308895796537399e-01
    z[6,7,5]  R2300     2.7069875970482826e-02
    z[6,7,5]  R2301     1.0098073631525040e-02
    z[6,7,5]  R2302     -1.9162584841251373e-01
    z[6,7,5]  R2303     -0.361482709646225
    z[6,7,5]  R2304     -2.1384628489613533e-02
    z[6,7,5]  R2305     -2.3538470268249512e-01
    z[6,7,5]  R2306     -2.2064080834388733e-01
    z[6,7,5]  R2307     -2.3851794004440308e-01
    z[6,7,5]  R2308     3.5427961498498917e-02
    z[6,7,5]  R2309     -2.8092318773269653e-01
    z[6,7,5]  R2310     -2.4708215892314911e-01
    z[6,7,5]  R2311     -1.2099565565586090e-01
    z[6,7,5]  R2312     -1.0895001702010632e-02
    z[6,7,5]  R2313     9.1795986518263817e-03
    z[6,7,5]  R2314     4.2843386530876160e-01
    z[6,7,5]  R2315     2.8480908274650574e-01
    z[6,7,5]  R2316     -1.3585822284221649e-01
    z[6,7,5]  R2317     3.5807177424430847e-01
    z[6,7,5]  R2318     4.4925898313522339e-01
    z[6,7,5]  R2319     2.3420919477939606e-01
    z[6,7,5]  R2320     -3.2690837979316711e-02
    z[6,7,5]  R2321     -4.3979048728942871e-01
    z[6,7,5]  R2322     -0.383866548538208
    z[6,7,5]  R2323     1.1409801244735718e-01
    z[6,7,5]  R2324     6.3329619169235229e-01
    z[6,7,5]  R2325     1.0092271864414215e-01
    z[6,7,5]  R2326     2.1092095971107483e-01
    z[6,7,5]  R2327     3.1188043951988220e-01
    z[6,7,5]  R2328     5.7301986217498779e-01
    z[6,7,5]  R2329     2.9715502262115479e-01
    z[6,7,5]  R2330     -0.68267822265625
    z[6,7,5]  R2331     2.9752397537231445e-01
    z[6,7,5]  R2332     5.5984055995941162e-01
    z[6,7,5]  R2333     4.4256573915481567e-01
    z[6,7,5]  R2334     3.0589541792869568e-01
    z[6,7,5]  R2335     8.0975212156772614e-02
    z[6,7,5]  R2336     -4.2513221502304077e-01
    z[6,7,5]  R2337     -1.5970150008797646e-02
    z[6,7,5]  R2338     -0.633258044719696
    z[6,7,5]  R2339     -5.6956237554550171e-01
    z[6,7,5]  R2340     -4.2983183264732361e-01
    z[6,7,5]  R2341     -3.4924387931823730e-01
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R2230     -1
    z[6,7,6]  R2231     1
    z[6,7,6]  R2232     -1.6562150418758392e-01
    z[6,7,6]  R2233     3.0944380164146423e-01
    z[6,7,6]  R2234     4.1285109519958496e-01
    z[6,7,6]  R2235     2.9577460885047913e-01
    z[6,7,6]  R2236     -4.3691092729568481e-01
    z[6,7,6]  R2237     4.3494582176208496e-01
    z[6,7,6]  R2238     3.9614251255989075e-01
    z[6,7,6]  R2239     3.7635970115661621e-01
    z[6,7,6]  R2240     2.9134684801101685e-01
    z[6,7,6]  R2241     1.4644193649291992e-01
    z[6,7,6]  R2242     -2.4537183344364166e-02
    z[6,7,6]  R2243     3.9565327763557434e-01
    z[6,7,6]  R2244     6.7452915012836456e-02
    z[6,7,6]  R2245     3.8119873404502869e-01
    z[6,7,6]  R2246     -1.3156446814537048e-01
    z[6,7,6]  R2247     1.5684491395950317e-01
    z[6,7,6]  R2248     1.9448937475681305e-01
    z[6,7,6]  R2249     -3.3003729581832886e-01
    z[6,7,6]  R2250     1.5036197006702423e-01
    z[6,7,6]  R2251     -6.0841190814971924e-01
    z[6,7,6]  R2252     -1.6279883682727814e-01
    z[6,7,6]  R2253     -0.532157301902771
    z[6,7,6]  R2254     -3.0267059803009033e-01
    z[6,7,6]  R2255     -0.271452397108078
    z[6,7,6]  R2256     -1.6251775622367859e-01
    z[6,7,6]  R2257     -0.173447385430336
    z[6,7,6]  R2258     -6.0873341560363770e-01
    z[6,7,6]  R2259     -4.8913916945457458e-01
    z[6,7,6]  R2260     3.9172267913818359e-01
    z[6,7,6]  R2261     3.9505439996719360e-01
    z[6,7,6]  R2262     2.2452731430530548e-01
    z[6,7,6]  R2263     -3.7836560606956482e-01
    z[6,7,6]  R2264     -3.1854078173637390e-02
    z[6,7,6]  R2265     -1.3612571358680725e-01
    z[6,7,6]  R2266     3.0483016371726990e-01
    z[6,7,6]  R2267     -5.9749286621809006e-02
    z[6,7,6]  R2268     2.6242837309837341e-01
    z[6,7,6]  R2269     0.488349974155426
    z[6,7,6]  R2270     -3.0385133624076843e-01
    z[6,7,6]  R2271     2.8920361399650574e-01
    z[6,7,6]  R2272     7.4096307158470154e-02
    z[6,7,6]  R2273     -1.4444592595100403e-01
    z[6,7,6]  R2274     -0.212275892496109
    z[6,7,6]  R2275     -4.5996572822332382e-02
    z[6,7,6]  R2276     5.4994723759591579e-03
    z[6,7,6]  R2277     1.1091116815805435e-01
    z[6,7,6]  R2278     3.0205633491277695e-02
    z[6,7,6]  R2279     -1.9873636960983276e-01
    z[6,7,6]  R2280     -2.5499787926673889e-01
    z[6,7,6]  R2281     7.2888776659965515e-02
    z[6,7,6]  R2282     -4.3196283280849457e-02
    z[6,7,6]  R2283     -2.0454345643520355e-01
    z[6,7,6]  R2284     -4.4320017099380493e-01
    z[6,7,6]  R2285     3.6286197602748871e-02
    z[6,7,6]  R2286     1.6789884865283966e-01
    z[6,7,6]  R2287     -3.1169047579169273e-02
    z[6,7,6]  R2288     -1.0007640719413757e-01
    z[6,7,6]  R2289     1.9297653436660767e-01
    z[6,7,6]  R2290     3.9162772893905640e-01
    z[6,7,6]  R2291     0.514819860458374
    z[6,7,6]  R2292     -6.1305873095989227e-02
    z[6,7,6]  R2293     2.4486029148101807e-01
    z[6,7,6]  R2294     1.2513917684555054e-01
    z[6,7,6]  R2295     0.0778806284070015
    z[6,7,6]  R2296     -1.8003915250301361e-01
    z[6,7,6]  R2297     -3.0970746278762817e-01
    z[6,7,6]  R2298     -4.2147025465965271e-01
    z[6,7,6]  R2299     4.6574071049690247e-02
    z[6,7,6]  R2300     4.5222377777099609e-01
    z[6,7,6]  R2301     2.8092715144157410e-01
    z[6,7,6]  R2302     -3.5933154821395874e-01
    z[6,7,6]  R2303     -2.1390192210674286e-01
    z[6,7,6]  R2304     1.5885165194049478e-03
    z[6,7,6]  R2305     5.9050343930721283e-02
    z[6,7,6]  R2306     3.7085619568824768e-01
    z[6,7,6]  R2307     -4.1800227761268616e-01
    z[6,7,6]  R2308     2.4873162806034088e-01
    z[6,7,6]  R2309     -4.9483460187911987e-01
    z[6,7,6]  R2310     -6.0781919956207275e-01
    z[6,7,6]  R2311     -2.1567137539386749e-01
    z[6,7,6]  R2312     -1.4419928193092346e-01
    z[6,7,6]  R2313     -1.8300722539424896e-01
    z[6,7,6]  R2314     -4.3642383068799973e-02
    z[6,7,6]  R2315     -2.1453650295734406e-01
    z[6,7,6]  R2316     5.5653733015060425e-01
    z[6,7,6]  R2317     -2.6611623167991638e-01
    z[6,7,6]  R2318     1.9246926903724670e-01
    z[6,7,6]  R2319     2.8264707326889038e-01
    z[6,7,6]  R2320     -1.8486200273036957e-01
    z[6,7,6]  R2321     -3.7808814644813538e-01
    z[6,7,6]  R2322     -1.9174209237098694e-01
    z[6,7,6]  R2323     -2.4110180139541626e-01
    z[6,7,6]  R2324     -2.7830812335014343e-01
    z[6,7,6]  R2325     1.5989591181278229e-01
    z[6,7,6]  R2326     -3.0983921885490417e-01
    z[6,7,6]  R2327     7.1816518902778625e-02
    z[6,7,6]  R2328     -4.6738538146018982e-01
    z[6,7,6]  R2329     -3.3327281475067139e-01
    z[6,7,6]  R2330     -3.1285735964775085e-01
    z[6,7,6]  R2331     -5.3250551223754883e-01
    z[6,7,6]  R2332     2.0171479880809784e-01
    z[6,7,6]  R2333     1.2863324582576752e-01
    z[6,7,6]  R2334     -4.5032438635826111e-01
    z[6,7,6]  R2335     -4.7583183646202087e-01
    z[6,7,6]  R2336     2.8816403821110725e-02
    z[6,7,6]  R2337     -1.9571878015995026e-01
    z[6,7,6]  R2338     3.2713532447814941e-01
    z[6,7,6]  R2339     0.0740632712841034
    z[6,7,6]  R2340     -1.2733453512191772e-01
    z[6,7,6]  R2341     2.0751886069774628e-01
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R2342     -1
    z[7,6,0]  R2343     1
    z[7,6,0]  R2356     4.7603544592857361e-01
    z[7,6,0]  R2357     3.6790758371353149e-01
    z[7,6,0]  R2358     4.1421744227409363e-01
    z[7,6,0]  R2359     -3.9302725344896317e-02
    z[7,6,0]  R2360     3.1200116872787476e-01
    z[7,6,0]  R2361     3.5082545876502991e-01
    z[7,6,0]  R2362     -8.3406277000904083e-02
    z[7,6,0]  R2363     5.2954941987991333e-01
    z[7,6,0]  R2364     3.5198795795440674e-01
    z[7,6,0]  R2365     0.588661253452301
    z[7,6,0]  R2366     -2.9111906886100769e-01
    z[7,6,0]  R2367     5.9338800609111786e-02
    z[7,6,0]  R2368     -1.7377567291259766e-01
    z[7,6,0]  R2369     2.0256677269935608e-01
    z[7,6,0]  R2370     -1.1065188795328140e-01
    z[7,6,0]  R2371     -8.7795235216617584e-02
    z[7,6,0]  R2372     -3.0642268061637878e-01
    z[7,6,0]  R2373     2.7552178502082825e-01
    z[7,6,0]  R2374     3.7211981415748596e-01
    z[7,6,0]  R2375     6.6856807470321655e-01
    z[7,6,0]  R2376     1.3725635409355164e-01
    z[7,6,0]  R2377     3.8982889056205750e-01
    z[7,6,0]  R2378     -0.123763807117939
    z[7,6,0]  R2379     3.7052273750305176e-01
    z[7,6,0]  R2380     4.1609662771224976e-01
    z[7,6,0]  R2381     2.5699424743652344e-01
    z[7,6,0]  R2382     4.1304844617843628e-01
    z[7,6,0]  R2383     4.1018193960189819e-01
    z[7,6,0]  R2384     -3.0694928765296936e-01
    z[7,6,0]  R2385     2.4791166186332703e-01
    z[7,6,0]  R2386     -0.0092205461114645
    z[7,6,0]  R2387     -2.7029192447662354e-01
    z[7,6,0]  R2388     1.2486063875257969e-02
    z[7,6,0]  R2389     -7.6464004814624786e-02
    z[7,6,0]  R2390     -3.1966125965118408e-01
    z[7,6,0]  R2391     -2.7544555068016052e-01
    z[7,6,0]  R2392     -4.4085282087326050e-01
    z[7,6,0]  R2393     -6.3712352514266968e-01
    z[7,6,0]  R2394     -2.3229372501373291e-01
    z[7,6,0]  R2395     5.8029163628816605e-03
    z[7,6,0]  R2396     -5.2021265029907227e-01
    z[7,6,0]  R2397     3.8525256514549255e-01
    z[7,6,0]  R2398     -3.6801743507385254e-01
    z[7,6,0]  R2399     2.2431758046150208e-01
    z[7,6,0]  R2400     1.1507070809602737e-01
    z[7,6,0]  R2401     -2.2654646635055542e-01
    z[7,6,0]  R2402     8.1596441566944122e-02
    z[7,6,0]  R2403     1.6711363196372986e-01
    z[7,6,0]  R2404     -8.7778925895690918e-01
    z[7,6,0]  R2405     -8.5311925411224365e-01
    z[7,6,0]  R2406     6.1276221275329590e-01
    z[7,6,0]  R2407     4.5041519403457642e-01
    z[7,6,0]  R2408     7.8865963220596313e-01
    z[7,6,0]  R2409     -2.4639409780502319e-01
    z[7,6,0]  R2410     1.6377098858356476e-02
    z[7,6,0]  R2411     -1.1627390235662460e-01
    z[7,6,0]  R2412     -4.9470996856689453e-01
    z[7,6,0]  R2413     -3.7875732779502869e-01
    z[7,6,0]  R2414     -2.3823419213294983e-01
    z[7,6,0]  R2415     -4.1410744190216064e-01
    z[7,6,0]  R2416     -3.6063289642333984e-01
    z[7,6,0]  R2417     -3.6211588978767395e-01
    z[7,6,0]  R2418     -4.6046221256256104e-01
    z[7,6,0]  R2419     1.6052266582846642e-02
    z[7,6,0]  R2420     -6.8675160408020020e-02
    z[7,6,0]  R2421     -9.4422794878482819e-02
    z[7,6,0]  R2422     -1.9267293810844421e-01
    z[7,6,0]  R2423     -2.9476154595613480e-02
    z[7,6,0]  R2424     -1.4457304775714874e-01
    z[7,6,0]  R2425     -0.0837971493601799
    z[7,6,0]  R2426     -3.1692963838577271e-01
    z[7,6,0]  R2427     -3.5143095254898071e-01
    z[7,6,0]  R2428     4.6653710305690765e-02
    z[7,6,0]  R2429     2.4943938478827477e-02
    z[7,6,0]  R2430     -4.3236187100410461e-01
    z[7,6,0]  R2431     -0.120021753013134
    z[7,6,0]  R2432     -3.5201224684715271e-01
    z[7,6,0]  R2433     4.1558140516281128e-01
    z[7,6,0]  R2434     3.8337224721908569e-01
    z[7,6,0]  R2435     1.3972762227058411e-01
    z[7,6,0]  R2436     2.0932084321975708e-01
    z[7,6,0]  R2437     6.7689009010791779e-02
    z[7,6,0]  R2438     1.3679102063179016e-01
    z[7,6,0]  R2439     -0.0431256964802742
    z[7,6,0]  R2440     1.7754010856151581e-01
    z[7,6,0]  R2441     2.9873788356781006e-02
    z[7,6,0]  R2442     -1.5065731480717659e-02
    z[7,6,0]  R2443     -1.4924864470958710e-01
    z[7,6,0]  R2444     2.8897517919540405e-01
    z[7,6,0]  R2445     3.3578014373779297e-01
    z[7,6,0]  R2446     3.3725729584693909e-01
    z[7,6,0]  R2447     4.0198189020156860e-01
    z[7,6,0]  R2448     2.9496408533304930e-03
    z[7,6,0]  R2449     2.8498345613479614e-01
    z[7,6,0]  R2450     -8.2206851243972778e-01
    z[7,6,0]  R2451     -8.2323813438415527e-01
    z[7,6,0]  R2452     -8.6341661214828491e-01
    z[7,6,0]  R2453     -8.0771315097808838e-01
    z[7,6,0]  R2454     -0.781409502029419
    z[7,6,0]  R2455     -8.3696919679641724e-01
    z[7,6,0]  R2456     6.8571992218494415e-02
    z[7,6,0]  R2457     -1.9584028422832489e-01
    z[7,6,0]  R2458     3.4353566169738770e-01
    z[7,6,0]  R2459     -4.1826122999191284e-01
    z[7,6,0]  R2460     -6.9084864854812622e-01
    z[7,6,0]  R2461     -9.3364083766937256e-01
    z[7,6,0]  R2462     -7.7485686540603638e-01
    z[7,6,0]  R2463     -6.2384098768234253e-01
    z[7,6,0]  R2464     -6.7667406797409058e-01
    z[7,6,0]  R2465     -5.3504264354705811e-01
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R2344     -1
    z[7,6,1]  R2345     1
    z[7,6,1]  R2356     -1.0660460591316223e-01
    z[7,6,1]  R2357     -1.2077955156564713e-01
    z[7,6,1]  R2358     -2.0885924994945526e-01
    z[7,6,1]  R2359     -5.9599387645721436e-01
    z[7,6,1]  R2360     -2.4721232056617737e-01
    z[7,6,1]  R2361     -2.8906211256980896e-01
    z[7,6,1]  R2362     -4.9694183468818665e-01
    z[7,6,1]  R2363     -4.0280455350875854e-01
    z[7,6,1]  R2364     -2.8144043684005737e-01
    z[7,6,1]  R2365     -5.1659953594207764e-01
    z[7,6,1]  R2366     -1.8781755119562149e-02
    z[7,6,1]  R2367     2.2174131870269775e-01
    z[7,6,1]  R2368     1.6783127188682556e-01
    z[7,6,1]  R2369     -3.4644204378128052e-01
    z[7,6,1]  R2370     1.6638845205307007e-01
    z[7,6,1]  R2371     3.4050557017326355e-01
    z[7,6,1]  R2372     8.4921658039093018e-01
    z[7,6,1]  R2373     -5.4452598094940186e-02
    z[7,6,1]  R2374     5.2231132984161377e-02
    z[7,6,1]  R2375     0.0165800079703331
    z[7,6,1]  R2376     8.6523312330245972e-01
    z[7,6,1]  R2377     0.849455714225769
    z[7,6,1]  R2378     8.3081424236297607e-01
    z[7,6,1]  R2379     7.5549054145812988e-01
    z[7,6,1]  R2380     6.9476801156997681e-01
    z[7,6,1]  R2381     7.0348227024078369e-01
    z[7,6,1]  R2382     6.7879295349121094e-01
    z[7,6,1]  R2383     6.7431765794754028e-01
    z[7,6,1]  R2384     0.812117338180542
    z[7,6,1]  R2385     6.5174585580825806e-01
    z[7,6,1]  R2386     0.875145673751831
    z[7,6,1]  R2387     7.7661645412445068e-01
    z[7,6,1]  R2388     3.3691346645355225e-01
    z[7,6,1]  R2389     -1.3373208045959473e-01
    z[7,6,1]  R2390     2.1163500845432281e-01
    z[7,6,1]  R2391     1.4521718025207520e-01
    z[7,6,1]  R2392     2.0001755654811859e-01
    z[7,6,1]  R2393     -1.7763268947601318e-01
    z[7,6,1]  R2394     -4.1447395086288452e-01
    z[7,6,1]  R2395     3.2233405113220215e-01
    z[7,6,1]  R2396     -1.6980348154902458e-02
    z[7,6,1]  R2397     6.8088221549987793e-01
    z[7,6,1]  R2398     1.2809453904628754e-01
    z[7,6,1]  R2399     -3.7579932808876038e-01
    z[7,6,1]  R2400     -7.0018756389617920e-01
    z[7,6,1]  R2401     3.0431863665580750e-01
    z[7,6,1]  R2402     -4.0260177105665207e-02
    z[7,6,1]  R2403     -2.2124862670898438e-01
    z[7,6,1]  R2404     1.3861157000064850e-01
    z[7,6,1]  R2405     2.3196747526526451e-02
    z[7,6,1]  R2406     -4.6249288320541382e-01
    z[7,6,1]  R2407     -7.3704510927200317e-01
    z[7,6,1]  R2408     -2.5161647796630859e-01
    z[7,6,1]  R2409     2.3816816508769989e-02
    z[7,6,1]  R2410     2.1788033843040466e-01
    z[7,6,1]  R2411     1.1755845695734024e-01
    z[7,6,1]  R2412     -2.8332084417343140e-01
    z[7,6,1]  R2413     -1.5807604789733887e-01
    z[7,6,1]  R2414     -1.3992689782753587e-03
    z[7,6,1]  R2415     0.117411307990551
    z[7,6,1]  R2416     6.4976739883422852e-01
    z[7,6,1]  R2417     7.0342016220092773e-01
    z[7,6,1]  R2418     0.817271888256073
    z[7,6,1]  R2419     5.7912361621856689e-01
    z[7,6,1]  R2420     4.9411904811859131e-01
    z[7,6,1]  R2421     7.1946346759796143e-01
    z[7,6,1]  R2422     8.8183438777923584e-01
    z[7,6,1]  R2423     7.8212618827819824e-01
    z[7,6,1]  R2424     4.9071976542472839e-01
    z[7,6,1]  R2425     3.7327969074249268e-01
    z[7,6,1]  R2426     -1.2900227308273315e-01
    z[7,6,1]  R2427     1.6237090528011322e-01
    z[7,6,1]  R2428     5.3052014112472534e-01
    z[7,6,1]  R2429     9.3510001897811890e-03
    z[7,6,1]  R2430     -2.6308529078960419e-02
    z[7,6,1]  R2431     -3.0889749526977539e-01
    z[7,6,1]  R2432     -3.7239041924476624e-01
    z[7,6,1]  R2433     2.7739086747169495e-01
    z[7,6,1]  R2434     6.6657519340515137e-01
    z[7,6,1]  R2435     6.6656738519668579e-01
    z[7,6,1]  R2436     7.9936319589614868e-01
    z[7,6,1]  R2437     0.682819664478302
    z[7,6,1]  R2438     9.0550339221954346e-01
    z[7,6,1]  R2439     9.6975505352020264e-01
    z[7,6,1]  R2440     0.919813334941864
    z[7,6,1]  R2441     6.4759099483489990e-01
    z[7,6,1]  R2442     7.2470885515213013e-01
    z[7,6,1]  R2443     6.8037277460098267e-01
    z[7,6,1]  R2444     6.5666466951370239e-01
    z[7,6,1]  R2445     3.5335782170295715e-01
    z[7,6,1]  R2446     4.4173008203506470e-01
    z[7,6,1]  R2447     -3.5165590047836304e-01
    z[7,6,1]  R2448     -6.1881011724472046e-01
    z[7,6,1]  R2449     -2.8727304935455322e-01
    z[7,6,1]  R2450     -3.5088992118835449e-01
    z[7,6,1]  R2451     -2.9102388024330139e-01
    z[7,6,1]  R2452     -3.4433019161224365e-01
    z[7,6,1]  R2453     -3.2974857091903687e-01
    z[7,6,1]  R2454     -0.326667457818985
    z[7,6,1]  R2455     -2.2301189601421356e-01
    z[7,6,1]  R2456     8.7182819843292236e-01
    z[7,6,1]  R2457     -7.9527907073497772e-02
    z[7,6,1]  R2458     0.713519811630249
    z[7,6,1]  R2459     -0.0815548226237297
    z[7,6,1]  R2460     -1.8828220665454865e-01
    z[7,6,1]  R2461     -2.5633990764617920e-01
    z[7,6,1]  R2462     -1.1624956130981445e-01
    z[7,6,1]  R2463     -1.8742233514785767e-01
    z[7,6,1]  R2464     -2.8065502643585205e-01
    z[7,6,1]  R2465     -9.3812316656112671e-02
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R2346     -1
    z[7,6,2]  R2347     1
    z[7,6,2]  R2356     -2.4987235665321350e-01
    z[7,6,2]  R2357     8.0049097537994385e-02
    z[7,6,2]  R2358     -2.3241643607616425e-01
    z[7,6,2]  R2359     -5.9219084680080414e-02
    z[7,6,2]  R2360     -1.5208722651004791e-01
    z[7,6,2]  R2361     -3.8834550976753235e-01
    z[7,6,2]  R2362     1.2844204902648926e-01
    z[7,6,2]  R2363     7.9727783799171448e-02
    z[7,6,2]  R2364     -3.1406372785568237e-01
    z[7,6,2]  R2365     -2.2537735104560852e-01
    z[7,6,2]  R2366     3.1608071923255920e-01
    z[7,6,2]  R2367     0.568540096282959
    z[7,6,2]  R2368     -1.6008764505386353e-01
    z[7,6,2]  R2369     6.4011670649051666e-02
    z[7,6,2]  R2370     1.6753885149955750e-01
    z[7,6,2]  R2371     -2.5317856669425964e-01
    z[7,6,2]  R2372     5.0702389329671860e-02
    z[7,6,2]  R2373     -3.5285180807113647e-01
    z[7,6,2]  R2374     2.7158821467310190e-03
    z[7,6,2]  R2375     1.0803978657349944e-03
    z[7,6,2]  R2376     -1.3204509019851685e-01
    z[7,6,2]  R2377     -2.4696128070354462e-01
    z[7,6,2]  R2378     1.7244906723499298e-01
    z[7,6,2]  R2379     -6.4365096390247345e-02
    z[7,6,2]  R2380     1.3435410801321268e-03
    z[7,6,2]  R2381     2.3369173705577850e-01
    z[7,6,2]  R2382     -2.3711295425891876e-01
    z[7,6,2]  R2383     4.8450350761413574e-01
    z[7,6,2]  R2384     -4.2923524975776672e-01
    z[7,6,2]  R2385     3.4046009182929993e-01
    z[7,6,2]  R2386     6.1573632061481476e-02
    z[7,6,2]  R2387     -3.5468775033950806e-01
    z[7,6,2]  R2388     6.7794602364301682e-03
    z[7,6,2]  R2389     -7.6889827847480774e-02
    z[7,6,2]  R2390     8.4859818220138550e-02
    z[7,6,2]  R2391     -2.2711716592311859e-01
    z[7,6,2]  R2392     -2.6905193924903870e-01
    z[7,6,2]  R2393     -4.9347379803657532e-01
    z[7,6,2]  R2394     -3.0910629034042358e-01
    z[7,6,2]  R2395     -0.624438464641571
    z[7,6,2]  R2396     -3.9014685153961182e-01
    z[7,6,2]  R2397     3.2838678359985352e-01
    z[7,6,2]  R2398     -6.5237575769424438e-01
    z[7,6,2]  R2399     -2.1648381650447845e-01
    z[7,6,2]  R2400     6.9230437278747559e-02
    z[7,6,2]  R2401     -8.0624055862426758e-01
    z[7,6,2]  R2402     -0.617302417755127
    z[7,6,2]  R2403     -0.723918616771698
    z[7,6,2]  R2404     4.9001105129718781e-02
    z[7,6,2]  R2405     -3.2605963945388794e-01
    z[7,6,2]  R2406     -3.7173950672149658e-01
    z[7,6,2]  R2407     -2.8745934367179871e-01
    z[7,6,2]  R2408     -1.4560824632644653e-01
    z[7,6,2]  R2409     -8.7256854772567749e-01
    z[7,6,2]  R2410     -1.1744989454746246e-01
    z[7,6,2]  R2411     -4.3234601616859436e-01
    z[7,6,2]  R2412     -3.4299165010452271e-01
    z[7,6,2]  R2413     2.4135966598987579e-01
    z[7,6,2]  R2414     2.6430648565292358e-01
    z[7,6,2]  R2415     -6.6871635615825653e-02
    z[7,6,2]  R2416     -6.3241875171661377e-01
    z[7,6,2]  R2417     -3.4111383557319641e-01
    z[7,6,2]  R2418     -1.9173752516508102e-02
    z[7,6,2]  R2419     -6.3163924217224121e-01
    z[7,6,2]  R2420     -6.2527966499328613e-01
    z[7,6,2]  R2421     -1.0322622023522854e-02
    z[7,6,2]  R2422     2.7545309066772461e-01
    z[7,6,2]  R2423     -3.8440433144569397e-01
    z[7,6,2]  R2424     -2.7846693992614746e-01
    z[7,6,2]  R2425     -6.2393105030059814e-01
    z[7,6,2]  R2426     -2.9403015971183777e-01
    z[7,6,2]  R2427     -1.2160907685756683e-01
    z[7,6,2]  R2428     -2.1963237226009369e-01
    z[7,6,2]  R2429     7.1824967861175537e-02
    z[7,6,2]  R2430     4.4677847623825073e-01
    z[7,6,2]  R2431     1.7277929186820984e-01
    z[7,6,2]  R2432     2.5712689757347107e-01
    z[7,6,2]  R2433     2.8299024701118469e-01
    z[7,6,2]  R2434     -7.9229570925235748e-02
    z[7,6,2]  R2435     -0.445634663105011
    z[7,6,2]  R2436     -3.2915511727333069e-01
    z[7,6,2]  R2437     -4.6023672819137573e-01
    z[7,6,2]  R2438     -3.5719439387321472e-02
    z[7,6,2]  R2439     -9.5851331949234009e-02
    z[7,6,2]  R2440     -9.6563011407852173e-02
    z[7,6,2]  R2441     -3.4215632826089859e-02
    z[7,6,2]  R2442     6.9477267563343048e-02
    z[7,6,2]  R2443     -1.9786764681339264e-01
    z[7,6,2]  R2444     3.0728954076766968e-01
    z[7,6,2]  R2445     -3.3947271108627319e-01
    z[7,6,2]  R2446     -4.6295535564422607e-01
    z[7,6,2]  R2447     0.504423201084137
    z[7,6,2]  R2448     5.6837552785873413e-01
    z[7,6,2]  R2449     4.2655152082443237e-01
    z[7,6,2]  R2450     -4.1214738041162491e-02
    z[7,6,2]  R2451     -2.4300862848758698e-01
    z[7,6,2]  R2452     1.8729472160339355e-01
    z[7,6,2]  R2453     1.6173353791236877e-01
    z[7,6,2]  R2454     -4.1150562465190887e-02
    z[7,6,2]  R2455     8.1113819032907486e-03
    z[7,6,2]  R2456     -3.6531287431716919e-01
    z[7,6,2]  R2457     -4.5597577095031738e-01
    z[7,6,2]  R2458     2.7931693196296692e-01
    z[7,6,2]  R2459     5.2968554198741913e-02
    z[7,6,2]  R2460     -8.2593835890293121e-02
    z[7,6,2]  R2461     -7.6425760984420776e-02
    z[7,6,2]  R2462     2.7393737435340881e-01
    z[7,6,2]  R2463     4.3622571229934692e-01
    z[7,6,2]  R2464     2.5382798910140991e-01
    z[7,6,2]  R2465     5.5028963088989258e-01
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R2348     -1
    z[7,6,3]  R2349     1
    z[7,6,3]  R2356     -6.7224484682083130e-01
    z[7,6,3]  R2357     -7.0029366016387939e-01
    z[7,6,3]  R2358     -6.1937773227691650e-01
    z[7,6,3]  R2359     -7.1388387680053711e-01
    z[7,6,3]  R2360     -4.9720174074172974e-01
    z[7,6,3]  R2361     -6.4908200502395630e-01
    z[7,6,3]  R2362     -5.3357076644897461e-01
    z[7,6,3]  R2363     -7.3130798339843750e-01
    z[7,6,3]  R2364     -6.9445818662643433e-01
    z[7,6,3]  R2365     -5.0333750247955322e-01
    z[7,6,3]  R2366     8.9732266962528229e-02
    z[7,6,3]  R2367     9.4804614782333374e-02
    z[7,6,3]  R2368     1.2280047684907913e-01
    z[7,6,3]  R2369     -5.7932874187827110e-03
    z[7,6,3]  R2370     3.1909137964248657e-02
    z[7,6,3]  R2371     2.1057588979601860e-02
    z[7,6,3]  R2372     -3.4516620635986328e-01
    z[7,6,3]  R2373     8.7836936116218567e-02
    z[7,6,3]  R2374     2.9434330761432648e-02
    z[7,6,3]  R2375     4.8773370683193207e-02
    z[7,6,3]  R2376     -3.7065398693084717e-01
    z[7,6,3]  R2377     -1.7758302390575409e-01
    z[7,6,3]  R2378     2.2660417854785919e-01
    z[7,6,3]  R2379     1.2246348708868027e-01
    z[7,6,3]  R2380     -4.3347876518964767e-02
    z[7,6,3]  R2381     2.0179098471999168e-02
    z[7,6,3]  R2382     1.2138762325048447e-01
    z[7,6,3]  R2383     -8.3573527634143829e-02
    z[7,6,3]  R2384     1.6214302182197571e-01
    z[7,6,3]  R2385     -5.3740464150905609e-02
    z[7,6,3]  R2386     1.3159784674644470e-01
    z[7,6,3]  R2387     -2.7779016643762589e-02
    z[7,6,3]  R2388     -4.5293146371841431e-01
    z[7,6,3]  R2389     -9.1966682672500610e-01
    z[7,6,3]  R2390     -8.2189255952835083e-01
    z[7,6,3]  R2391     -7.0442509651184082e-01
    z[7,6,3]  R2392     -3.1061306595802307e-01
    z[7,6,3]  R2393     -1.7593665421009064e-01
    z[7,6,3]  R2394     1.3717627525329590e-01
    z[7,6,3]  R2395     -3.4871584177017212e-01
    z[7,6,3]  R2396     -0.436395525932312
    z[7,6,3]  R2397     1.4738725125789642e-01
    z[7,6,3]  R2398     -3.3101609349250793e-01
    z[7,6,3]  R2399     -6.1580508947372437e-01
    z[7,6,3]  R2400     -5.5146604776382446e-01
    z[7,6,3]  R2401     -3.0081382393836975e-01
    z[7,6,3]  R2402     1.3018840551376343e-01
    z[7,6,3]  R2403     1.2936544418334961e-01
    z[7,6,3]  R2404     3.0576642602682114e-02
    z[7,6,3]  R2405     -1.2606064788997173e-02
    z[7,6,3]  R2406     -7.0508822798728943e-02
    z[7,6,3]  R2407     9.4940230250358582e-02
    z[7,6,3]  R2408     -1.3284258544445038e-01
    z[7,6,3]  R2409     1.4472790062427521e-01
    z[7,6,3]  R2410     -1.2247978150844574e-01
    z[7,6,3]  R2411     -6.3021892309188843e-01
    z[7,6,3]  R2412     -5.4533201456069946e-01
    z[7,6,3]  R2413     -6.4684242010116577e-01
    z[7,6,3]  R2414     -4.6773397922515869e-01
    z[7,6,3]  R2415     -6.5646207332611084e-01
    z[7,6,3]  R2416     -1.6425412148237228e-02
    z[7,6,3]  R2417     -1.0423430800437927e-01
    z[7,6,3]  R2418     -3.3338627219200134e-01
    z[7,6,3]  R2419     7.8192614018917084e-02
    z[7,6,3]  R2420     -2.8088778257369995e-01
    z[7,6,3]  R2421     -6.2508940696716309e-01
    z[7,6,3]  R2422     -0.0665508434176445
    z[7,6,3]  R2423     1.7950452864170074e-01
    z[7,6,3]  R2424     -7.0398092269897461e-01
    z[7,6,3]  R2425     -2.9151913523674011e-01
    z[7,6,3]  R2426     1.3151910901069641e-01
    z[7,6,3]  R2427     6.5447628498077393e-02
    z[7,6,3]  R2428     8.8864132761955261e-02
    z[7,6,3]  R2429     -1.2790386378765106e-01
    z[7,6,3]  R2430     6.7232988774776459e-02
    z[7,6,3]  R2431     -1.0288050025701523e-01
    z[7,6,3]  R2432     2.5111887603998184e-02
    z[7,6,3]  R2433     -7.7986180782318115e-02
    z[7,6,3]  R2434     1.1262876540422440e-01
    z[7,6,3]  R2435     3.9240965247154236e-01
    z[7,6,3]  R2436     -5.7974513620138168e-03
    z[7,6,3]  R2437     3.9185520261526108e-02
    z[7,6,3]  R2438     -1.5434567630290985e-01
    z[7,6,3]  R2439     2.6429517194628716e-02
    z[7,6,3]  R2440     4.5138437300920486e-02
    z[7,6,3]  R2441     -3.9570108056068420e-01
    z[7,6,3]  R2442     -7.6664425432682037e-02
    z[7,6,3]  R2443     2.3608018457889557e-01
    z[7,6,3]  R2444     -4.5192936062812805e-01
    z[7,6,3]  R2445     1.4760474860668182e-01
    z[7,6,3]  R2446     -0.664531409740448
    z[7,6,3]  R2447     -4.9170491099357605e-01
    z[7,6,3]  R2448     -3.5445484519004822e-01
    z[7,6,3]  R2449     -2.3440995812416077e-01
    z[7,6,3]  R2450     -4.2044970393180847e-01
    z[7,6,3]  R2451     -3.7721338868141174e-01
    z[7,6,3]  R2452     -3.0410295724868774e-01
    z[7,6,3]  R2453     -3.9489173889160156e-01
    z[7,6,3]  R2454     -4.4229021668434143e-01
    z[7,6,3]  R2455     -3.4535983204841614e-01
    z[7,6,3]  R2456     -2.4242287874221802e-01
    z[7,6,3]  R2457     2.7392679452896118e-01
    z[7,6,3]  R2458     0.0804494097828865
    z[7,6,3]  R2459     -4.0220569819211960e-02
    z[7,6,3]  R2460     -5.7964015007019043e-01
    z[7,6,3]  R2461     -1.2730869650840759e-01
    z[7,6,3]  R2462     -2.5600469112396240e-01
    z[7,6,3]  R2463     -5.8702182769775391e-01
    z[7,6,3]  R2464     -4.7743275761604309e-01
    z[7,6,3]  R2465     8.0001316964626312e-02
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R2350     -1
    z[7,6,4]  R2351     1
    z[7,6,4]  R2356     2.4950763583183289e-01
    z[7,6,4]  R2357     3.3191773295402527e-01
    z[7,6,4]  R2358     5.4609251022338867e-01
    z[7,6,4]  R2359     3.4516081213951111e-01
    z[7,6,4]  R2360     6.8939322233200073e-01
    z[7,6,4]  R2361     3.4546619653701782e-01
    z[7,6,4]  R2362     0.305010050535202
    z[7,6,4]  R2363     3.4637738019227982e-02
    z[7,6,4]  R2364     -1.0367469489574432e-01
    z[7,6,4]  R2365     5.8627333492040634e-02
    z[7,6,4]  R2366     -8.0068618059158325e-01
    z[7,6,4]  R2367     -6.6231417655944824e-01
    z[7,6,4]  R2368     -9.4892930984497070e-01
    z[7,6,4]  R2369     -8.8086354732513428e-01
    z[7,6,4]  R2370     -8.6299884319305420e-01
    z[7,6,4]  R2371     -7.6170092821121216e-01
    z[7,6,4]  R2372     1.0170640423893929e-02
    z[7,6,4]  R2373     -6.8199980258941650e-01
    z[7,6,4]  R2374     -6.5378212928771973e-01
    z[7,6,4]  R2375     -6.9943392276763916e-01
    z[7,6,4]  R2376     2.3832754790782928e-01
    z[7,6,4]  R2377     -1.8893703818321228e-02
    z[7,6,4]  R2378     -1.6697883605957031e-01
    z[7,6,4]  R2379     -3.8166046142578125e-01
    z[7,6,4]  R2380     -1.1869627982378006e-01
    z[7,6,4]  R2381     4.3013298511505127e-01
    z[7,6,4]  R2382     -2.4247787892818451e-01
    z[7,6,4]  R2383     -0.0239796731621027
    z[7,6,4]  R2384     -2.1718394011259079e-02
    z[7,6,4]  R2385     2.4207362532615662e-01
    z[7,6,4]  R2386     -1.6972647607326508e-01
    z[7,6,4]  R2387     -3.5508543252944946e-01
    z[7,6,4]  R2388     4.5013442635536194e-01
    z[7,6,4]  R2389     -2.9802310466766357e-01
    z[7,6,4]  R2390     -1.7271572351455688e-01
    z[7,6,4]  R2391     -5.0280994176864624e-01
    z[7,6,4]  R2392     -2.2354270517826080e-01
    z[7,6,4]  R2393     2.9778888821601868e-01
    z[7,6,4]  R2394     -3.0977034568786621e-01
    z[7,6,4]  R2395     -1.1161712557077408e-01
    z[7,6,4]  R2396     1.7979015409946442e-01
    z[7,6,4]  R2397     2.1449477970600128e-01
    z[7,6,4]  R2398     -1.2893806397914886e-01
    z[7,6,4]  R2399     -3.8652592897415161e-01
    z[7,6,4]  R2400     -7.7593587338924408e-02
    z[7,6,4]  R2401     2.7747648954391479e-01
    z[7,6,4]  R2402     -2.9270559549331665e-01
    z[7,6,4]  R2403     -2.2900177538394928e-01
    z[7,6,4]  R2404     7.7248387038707733e-02
    z[7,6,4]  R2405     1.1837456375360489e-02
    z[7,6,4]  R2406     6.6281452775001526e-02
    z[7,6,4]  R2407     -1.7785805463790894e-01
    z[7,6,4]  R2408     -1.5330310165882111e-01
    z[7,6,4]  R2409     2.5056928396224976e-01
    z[7,6,4]  R2410     0.855876624584198
    z[7,6,4]  R2411     4.3965995311737061e-01
    z[7,6,4]  R2412     3.1669247150421143e-01
    z[7,6,4]  R2413     4.6119195222854614e-01
    z[7,6,4]  R2414     6.9981914758682251e-01
    z[7,6,4]  R2415     -3.1441470980644226e-01
    z[7,6,4]  R2416     1.7064402997493744e-01
    z[7,6,4]  R2417     -0.20225889980793
    z[7,6,4]  R2418     -5.3948469460010529e-02
    z[7,6,4]  R2419     2.7750173211097717e-01
    z[7,6,4]  R2420     -4.5872992277145386e-01
    z[7,6,4]  R2421     -1.2366724014282227e-01
    z[7,6,4]  R2422     0.23235984146595
    z[7,6,4]  R2423     9.9264852702617645e-02
    z[7,6,4]  R2424     -5.7973209768533707e-02
    z[7,6,4]  R2425     -2.2962737828493118e-02
    z[7,6,4]  R2426     -8.6468023061752319e-01
    z[7,6,4]  R2427     -7.2321105003356934e-01
    z[7,6,4]  R2428     -7.4332869052886963e-01
    z[7,6,4]  R2429     -0.948615550994873
    z[7,6,4]  R2430     -7.4593675136566162e-01
    z[7,6,4]  R2431     -4.9432826042175293e-01
    z[7,6,4]  R2432     -0.514190673828125
    z[7,6,4]  R2433     -6.4000964164733887e-01
    z[7,6,4]  R2434     3.6670404672622681e-01
    z[7,6,4]  R2435     1.2844231724739075e-01
    z[7,6,4]  R2436     -1.9405518472194672e-01
    z[7,6,4]  R2437     -2.5099015235900879e-01
    z[7,6,4]  R2438     -1.7473381757736206e-01
    z[7,6,4]  R2439     8.3880260586738586e-02
    z[7,6,4]  R2440     -1.0158686339855194e-01
    z[7,6,4]  R2441     5.8162909746170044e-01
    z[7,6,4]  R2442     -5.7438635826110840e-01
    z[7,6,4]  R2443     -3.3861798048019409e-01
    z[7,6,4]  R2444     -9.3943439424037933e-02
    z[7,6,4]  R2445     -4.4701397418975830e-01
    z[7,6,4]  R2446     6.1733699403703213e-03
    z[7,6,4]  R2447     2.7794754132628441e-02
    z[7,6,4]  R2448     2.9193648695945740e-01
    z[7,6,4]  R2449     7.4327546358108521e-01
    z[7,6,4]  R2450     -1.4449569582939148e-01
    z[7,6,4]  R2451     -1.2018053978681564e-01
    z[7,6,4]  R2452     3.3682264387607574e-02
    z[7,6,4]  R2453     4.7047054395079613e-03
    z[7,6,4]  R2454     1.2552255392074585e-01
    z[7,6,4]  R2455     2.1860368549823761e-01
    z[7,6,4]  R2456     6.6768713295459747e-02
    z[7,6,4]  R2457     -5.4485595226287842e-01
    z[7,6,4]  R2458     3.0279141664505005e-01
    z[7,6,4]  R2459     -5.5368947982788086e-01
    z[7,6,4]  R2460     3.1811073422431946e-01
    z[7,6,4]  R2461     1.6012330353260040e-01
    z[7,6,4]  R2462     4.5743796229362488e-01
    z[7,6,4]  R2463     -4.7555733472108841e-02
    z[7,6,4]  R2464     -5.4822903126478195e-02
    z[7,6,4]  R2465     -9.4818487763404846e-02
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R2352     -1
    z[7,6,5]  R2353     1
    z[7,6,5]  R2356     4.2622053623199463e-01
    z[7,6,5]  R2357     4.2791518568992615e-01
    z[7,6,5]  R2358     1.8242482841014862e-01
    z[7,6,5]  R2359     7.0057839155197144e-02
    z[7,6,5]  R2360     2.5204014778137207e-01
    z[7,6,5]  R2361     7.7326498925685883e-02
    z[7,6,5]  R2362     4.1740727424621582e-01
    z[7,6,5]  R2363     1.1308895796537399e-01
    z[7,6,5]  R2364     2.7069875970482826e-02
    z[7,6,5]  R2365     1.0098073631525040e-02
    z[7,6,5]  R2366     -1.9162584841251373e-01
    z[7,6,5]  R2367     -0.361482709646225
    z[7,6,5]  R2368     -2.1384628489613533e-02
    z[7,6,5]  R2369     -2.3538470268249512e-01
    z[7,6,5]  R2370     -2.2064080834388733e-01
    z[7,6,5]  R2371     -2.3851794004440308e-01
    z[7,6,5]  R2372     3.5427961498498917e-02
    z[7,6,5]  R2373     -2.8092318773269653e-01
    z[7,6,5]  R2374     -2.4708215892314911e-01
    z[7,6,5]  R2375     -1.2099565565586090e-01
    z[7,6,5]  R2376     -1.0895001702010632e-02
    z[7,6,5]  R2377     9.1795986518263817e-03
    z[7,6,5]  R2378     4.2843386530876160e-01
    z[7,6,5]  R2379     2.8480908274650574e-01
    z[7,6,5]  R2380     -1.3585822284221649e-01
    z[7,6,5]  R2381     3.5807177424430847e-01
    z[7,6,5]  R2382     4.4925898313522339e-01
    z[7,6,5]  R2383     2.3420919477939606e-01
    z[7,6,5]  R2384     -3.2690837979316711e-02
    z[7,6,5]  R2385     -4.3979048728942871e-01
    z[7,6,5]  R2386     -0.383866548538208
    z[7,6,5]  R2387     1.1409801244735718e-01
    z[7,6,5]  R2388     6.3329619169235229e-01
    z[7,6,5]  R2389     1.0092271864414215e-01
    z[7,6,5]  R2390     2.1092095971107483e-01
    z[7,6,5]  R2391     3.1188043951988220e-01
    z[7,6,5]  R2392     5.7301986217498779e-01
    z[7,6,5]  R2393     2.9715502262115479e-01
    z[7,6,5]  R2394     -0.68267822265625
    z[7,6,5]  R2395     2.9752397537231445e-01
    z[7,6,5]  R2396     5.5984055995941162e-01
    z[7,6,5]  R2397     4.4256573915481567e-01
    z[7,6,5]  R2398     3.0589541792869568e-01
    z[7,6,5]  R2399     8.0975212156772614e-02
    z[7,6,5]  R2400     -4.2513221502304077e-01
    z[7,6,5]  R2401     -1.5970150008797646e-02
    z[7,6,5]  R2402     -0.633258044719696
    z[7,6,5]  R2403     -5.6956237554550171e-01
    z[7,6,5]  R2404     -4.2983183264732361e-01
    z[7,6,5]  R2405     -3.4924387931823730e-01
    z[7,6,5]  R2406     4.8542496562004089e-01
    z[7,6,5]  R2407     1.8669515848159790e-01
    z[7,6,5]  R2408     2.8619608283042908e-01
    z[7,6,5]  R2409     7.8315190970897675e-02
    z[7,6,5]  R2410     -6.9425147958099842e-03
    z[7,6,5]  R2411     7.7991865575313568e-02
    z[7,6,5]  R2412     -5.2326135337352753e-02
    z[7,6,5]  R2413     -2.3462414741516113e-02
    z[7,6,5]  R2414     2.8280675411224365e-01
    z[7,6,5]  R2415     5.0893360376358032e-01
    z[7,6,5]  R2416     -1.3342197239398956e-01
    z[7,6,5]  R2417     0.222257599234581
    z[7,6,5]  R2418     -3.2663941383361816e-02
    z[7,6,5]  R2419     1.9224016368389130e-01
    z[7,6,5]  R2420     2.3133309185504913e-01
    z[7,6,5]  R2421     -2.0668709278106689e-01
    z[7,6,5]  R2422     1.1456321924924850e-01
    z[7,6,5]  R2423     -2.9772982001304626e-01
    z[7,6,5]  R2424     3.7308186292648315e-01
    z[7,6,5]  R2425     -9.3137592077255249e-02
    z[7,6,5]  R2426     7.0624001324176788e-02
    z[7,6,5]  R2427     -1.5758909285068512e-01
    z[7,6,5]  R2428     -1.2684494256973267e-01
    z[7,6,5]  R2429     6.4915865659713745e-02
    z[7,6,5]  R2430     1.5939299762248993e-01
    z[7,6,5]  R2431     -7.5848239660263062e-01
    z[7,6,5]  R2432     -1.8899640440940857e-01
    z[7,6,5]  R2433     -1.2374006211757660e-01
    z[7,6,5]  R2434     -3.1909587979316711e-01
    z[7,6,5]  R2435     -1.0499091446399689e-01
    z[7,6,5]  R2436     -3.4750068187713623e-01
    z[7,6,5]  R2437     3.3115780353546143e-01
    z[7,6,5]  R2438     3.2358446717262268e-01
    z[7,6,5]  R2439     -1.4920926094055176e-01
    z[7,6,5]  R2440     -8.8428817689418793e-02
    z[7,6,5]  R2441     2.8305667638778687e-01
    z[7,6,5]  R2442     -2.5510206818580627e-01
    z[7,6,5]  R2443     0.258427232503891
    z[7,6,5]  R2444     -2.9234719276428223e-01
    z[7,6,5]  R2445     -5.8472281694412231e-01
    z[7,6,5]  R2446     -1.7226114869117737e-01
    z[7,6,5]  R2447     -4.4372856616973877e-01
    z[7,6,5]  R2448     -1.9516263902187347e-01
    z[7,6,5]  R2449     -2.1163710951805115e-01
    z[7,6,5]  R2450     4.1152812540531158e-02
    z[7,6,5]  R2451     -9.7449183464050293e-02
    z[7,6,5]  R2452     -7.9647347331047058e-02
    z[7,6,5]  R2453     1.3133837282657623e-01
    z[7,6,5]  R2454     -0.0677766501903534
    z[7,6,5]  R2455     2.7804443240165710e-01
    z[7,6,5]  R2456     1.9148682057857513e-01
    z[7,6,5]  R2457     -5.7763832807540894e-01
    z[7,6,5]  R2458     1.6540817916393280e-02
    z[7,6,5]  R2459     7.1140301227569580e-01
    z[7,6,5]  R2460     -1.2283764779567719e-01
    z[7,6,5]  R2461     -1.1809009313583374e-01
    z[7,6,5]  R2462     1.6198110580444336e-01
    z[7,6,5]  R2463     -3.6141928285360336e-02
    z[7,6,5]  R2464     0.120816171169281
    z[7,6,5]  R2465     -3.4882608056068420e-01
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R2354     -1
    z[7,6,6]  R2355     1
    z[7,6,6]  R2356     -6.1305873095989227e-02
    z[7,6,6]  R2357     2.4486029148101807e-01
    z[7,6,6]  R2358     1.2513917684555054e-01
    z[7,6,6]  R2359     0.0778806284070015
    z[7,6,6]  R2360     -1.8003915250301361e-01
    z[7,6,6]  R2361     -3.0970746278762817e-01
    z[7,6,6]  R2362     -4.2147025465965271e-01
    z[7,6,6]  R2363     4.6574071049690247e-02
    z[7,6,6]  R2364     4.5222377777099609e-01
    z[7,6,6]  R2365     2.8092715144157410e-01
    z[7,6,6]  R2366     -3.5933154821395874e-01
    z[7,6,6]  R2367     -2.1390192210674286e-01
    z[7,6,6]  R2368     1.5885165194049478e-03
    z[7,6,6]  R2369     5.9050343930721283e-02
    z[7,6,6]  R2370     3.7085619568824768e-01
    z[7,6,6]  R2371     -4.1800227761268616e-01
    z[7,6,6]  R2372     2.4873162806034088e-01
    z[7,6,6]  R2373     -4.9483460187911987e-01
    z[7,6,6]  R2374     -6.0781919956207275e-01
    z[7,6,6]  R2375     -2.1567137539386749e-01
    z[7,6,6]  R2376     -1.4419928193092346e-01
    z[7,6,6]  R2377     -1.8300722539424896e-01
    z[7,6,6]  R2378     -4.3642383068799973e-02
    z[7,6,6]  R2379     -2.1453650295734406e-01
    z[7,6,6]  R2380     5.5653733015060425e-01
    z[7,6,6]  R2381     -2.6611623167991638e-01
    z[7,6,6]  R2382     1.9246926903724670e-01
    z[7,6,6]  R2383     2.8264707326889038e-01
    z[7,6,6]  R2384     -1.8486200273036957e-01
    z[7,6,6]  R2385     -3.7808814644813538e-01
    z[7,6,6]  R2386     -1.9174209237098694e-01
    z[7,6,6]  R2387     -2.4110180139541626e-01
    z[7,6,6]  R2388     -2.7830812335014343e-01
    z[7,6,6]  R2389     1.5989591181278229e-01
    z[7,6,6]  R2390     -3.0983921885490417e-01
    z[7,6,6]  R2391     7.1816518902778625e-02
    z[7,6,6]  R2392     -4.6738538146018982e-01
    z[7,6,6]  R2393     -3.3327281475067139e-01
    z[7,6,6]  R2394     -3.1285735964775085e-01
    z[7,6,6]  R2395     -5.3250551223754883e-01
    z[7,6,6]  R2396     2.0171479880809784e-01
    z[7,6,6]  R2397     1.2863324582576752e-01
    z[7,6,6]  R2398     -4.5032438635826111e-01
    z[7,6,6]  R2399     -4.7583183646202087e-01
    z[7,6,6]  R2400     2.8816403821110725e-02
    z[7,6,6]  R2401     -1.9571878015995026e-01
    z[7,6,6]  R2402     3.2713532447814941e-01
    z[7,6,6]  R2403     0.0740632712841034
    z[7,6,6]  R2404     -1.2733453512191772e-01
    z[7,6,6]  R2405     2.0751886069774628e-01
    z[7,6,6]  R2406     -1.6562150418758392e-01
    z[7,6,6]  R2407     3.0944380164146423e-01
    z[7,6,6]  R2408     4.1285109519958496e-01
    z[7,6,6]  R2409     2.9577460885047913e-01
    z[7,6,6]  R2410     -4.3691092729568481e-01
    z[7,6,6]  R2411     4.3494582176208496e-01
    z[7,6,6]  R2412     3.9614251255989075e-01
    z[7,6,6]  R2413     3.7635970115661621e-01
    z[7,6,6]  R2414     2.9134684801101685e-01
    z[7,6,6]  R2415     1.4644193649291992e-01
    z[7,6,6]  R2416     -2.4537183344364166e-02
    z[7,6,6]  R2417     3.9565327763557434e-01
    z[7,6,6]  R2418     6.7452915012836456e-02
    z[7,6,6]  R2419     3.8119873404502869e-01
    z[7,6,6]  R2420     -1.3156446814537048e-01
    z[7,6,6]  R2421     1.5684491395950317e-01
    z[7,6,6]  R2422     1.9448937475681305e-01
    z[7,6,6]  R2423     -3.3003729581832886e-01
    z[7,6,6]  R2424     1.5036197006702423e-01
    z[7,6,6]  R2425     -6.0841190814971924e-01
    z[7,6,6]  R2426     -1.6279883682727814e-01
    z[7,6,6]  R2427     -0.532157301902771
    z[7,6,6]  R2428     -3.0267059803009033e-01
    z[7,6,6]  R2429     -0.271452397108078
    z[7,6,6]  R2430     -1.6251775622367859e-01
    z[7,6,6]  R2431     -0.173447385430336
    z[7,6,6]  R2432     -6.0873341560363770e-01
    z[7,6,6]  R2433     -4.8913916945457458e-01
    z[7,6,6]  R2434     3.9172267913818359e-01
    z[7,6,6]  R2435     3.9505439996719360e-01
    z[7,6,6]  R2436     2.2452731430530548e-01
    z[7,6,6]  R2437     -3.7836560606956482e-01
    z[7,6,6]  R2438     -3.1854078173637390e-02
    z[7,6,6]  R2439     -1.3612571358680725e-01
    z[7,6,6]  R2440     3.0483016371726990e-01
    z[7,6,6]  R2441     -5.9749286621809006e-02
    z[7,6,6]  R2442     2.6242837309837341e-01
    z[7,6,6]  R2443     0.488349974155426
    z[7,6,6]  R2444     -3.0385133624076843e-01
    z[7,6,6]  R2445     2.8920361399650574e-01
    z[7,6,6]  R2446     7.4096307158470154e-02
    z[7,6,6]  R2447     -1.4444592595100403e-01
    z[7,6,6]  R2448     -0.212275892496109
    z[7,6,6]  R2449     -4.5996572822332382e-02
    z[7,6,6]  R2450     5.4994723759591579e-03
    z[7,6,6]  R2451     1.1091116815805435e-01
    z[7,6,6]  R2452     3.0205633491277695e-02
    z[7,6,6]  R2453     -1.9873636960983276e-01
    z[7,6,6]  R2454     -2.5499787926673889e-01
    z[7,6,6]  R2455     7.2888776659965515e-02
    z[7,6,6]  R2456     -4.3196283280849457e-02
    z[7,6,6]  R2457     -2.0454345643520355e-01
    z[7,6,6]  R2458     -4.4320017099380493e-01
    z[7,6,6]  R2459     3.6286197602748871e-02
    z[7,6,6]  R2460     1.6789884865283966e-01
    z[7,6,6]  R2461     -3.1169047579169273e-02
    z[7,6,6]  R2462     -1.0007640719413757e-01
    z[7,6,6]  R2463     1.9297653436660767e-01
    z[7,6,6]  R2464     3.9162772893905640e-01
    z[7,6,6]  R2465     0.514819860458374
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R72       1
    RHS1      R73       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[8,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[2,7]
 BV BND1      phi[7,2]
 BV BND1      phi[3,6]
 BV BND1      phi[6,3]
 BV BND1      phi[3,7]
 BV BND1      phi[7,3]
 BV BND1      phi[3,9]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[8,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[7,9]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[2,7,0]
 FR BND1      z[2,7,1]
 FR BND1      z[2,7,2]
 FR BND1      z[2,7,3]
 FR BND1      z[2,7,4]
 FR BND1      z[2,7,5]
 FR BND1      z[2,7,6]
 FR BND1      z[7,2,0]
 FR BND1      z[7,2,1]
 FR BND1      z[7,2,2]
 FR BND1      z[7,2,3]
 FR BND1      z[7,2,4]
 FR BND1      z[7,2,5]
 FR BND1      z[7,2,6]
 FR BND1      z[3,6,0]
 FR BND1      z[3,6,1]
 FR BND1      z[3,6,2]
 FR BND1      z[3,6,3]
 FR BND1      z[3,6,4]
 FR BND1      z[3,6,5]
 FR BND1      z[3,6,6]
 FR BND1      z[6,3,0]
 FR BND1      z[6,3,1]
 FR BND1      z[6,3,2]
 FR BND1      z[6,3,3]
 FR BND1      z[6,3,4]
 FR BND1      z[6,3,5]
 FR BND1      z[6,3,6]
 FR BND1      z[3,7,0]
 FR BND1      z[3,7,1]
 FR BND1      z[3,7,2]
 FR BND1      z[3,7,3]
 FR BND1      z[3,7,4]
 FR BND1      z[3,7,5]
 FR BND1      z[3,7,6]
 FR BND1      z[7,3,0]
 FR BND1      z[7,3,1]
 FR BND1      z[7,3,2]
 FR BND1      z[7,3,3]
 FR BND1      z[7,3,4]
 FR BND1      z[7,3,5]
 FR BND1      z[7,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
ENDATA
