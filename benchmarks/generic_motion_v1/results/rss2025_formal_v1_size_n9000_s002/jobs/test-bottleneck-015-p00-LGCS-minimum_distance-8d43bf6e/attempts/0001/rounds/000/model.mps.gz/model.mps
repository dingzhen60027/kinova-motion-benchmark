NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 L  R73     
 E  R74     
 E  R75     
 E  R76     
 E  R77     
 E  R78     
 E  R79     
 E  R80     
 E  R81     
 E  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  R2670   
 L  R2671   
 L  R2672   
 L  R2673   
 L  R2674   
 L  R2675   
 L  R2676   
 L  R2677   
 L  R2678   
 L  R2679   
 L  R2680   
 L  R2681   
 L  R2682   
 L  R2683   
 L  R2684   
 L  R2685   
 L  R2686   
 L  R2687   
 L  R2688   
 L  R2689   
 L  R2690   
 L  R2691   
 L  R2692   
 L  R2693   
 L  R2694   
 L  R2695   
 L  R2696   
 L  R2697   
 L  R2698   
 L  R2699   
 L  R2700   
 L  R2701   
 L  R2702   
 L  R2703   
 L  R2704   
 L  R2705   
 L  R2706   
 L  R2707   
 L  R2708   
 L  R2709   
 L  R2710   
 L  R2711   
 L  R2712   
 L  R2713   
 L  R2714   
 L  R2715   
 L  R2716   
 L  R2717   
 L  R2718   
 L  R2719   
 L  R2720   
 L  R2721   
 L  R2722   
 L  R2723   
 L  R2724   
 L  R2725   
 L  R2726   
 L  R2727   
 L  R2728   
 L  R2729   
 L  R2730   
 L  R2731   
 L  R2732   
 L  R2733   
 L  R2734   
 L  R2735   
 L  R2736   
 L  R2737   
 L  R2738   
 L  R2739   
 L  R2740   
 L  R2741   
 L  R2742   
 L  R2743   
 L  R2744   
 L  R2745   
 L  R2746   
 L  R2747   
 L  R2748   
 L  R2749   
 L  R2750   
 L  R2751   
 L  R2752   
 L  R2753   
 L  R2754   
 L  R2755   
 L  R2756   
 L  R2757   
 L  R2758   
 L  R2759   
 L  R2760   
 L  R2761   
 L  R2762   
 L  R2763   
 L  R2764   
 L  R2765   
 L  R2766   
 L  R2767   
 L  R2768   
 L  R2769   
 L  R2770   
 L  R2771   
 L  R2772   
 L  R2773   
 L  R2774   
 L  R2775   
 L  R2776   
 L  R2777   
 L  R2778   
 L  R2779   
 L  R2780   
 L  R2781   
 L  R2782   
 L  R2783   
 L  R2784   
 L  R2785   
 L  R2786   
 L  R2787   
 L  R2788   
 L  R2789   
 L  R2790   
 L  R2791   
 L  R2792   
 L  R2793   
 L  R2794   
 L  R2795   
 L  R2796   
 L  R2797   
 L  R2798   
 L  R2799   
 L  R2800   
 L  R2801   
 L  R2802   
 L  R2803   
 L  R2804   
 L  R2805   
 L  R2806   
 L  R2807   
 L  R2808   
 L  R2809   
 L  R2810   
 L  R2811   
 L  R2812   
 L  R2813   
 L  R2814   
 L  R2815   
 L  R2816   
 L  R2817   
 L  R2818   
 L  R2819   
 L  R2820   
 L  R2821   
 L  R2822   
 L  R2823   
 L  R2824   
 L  R2825   
 L  R2826   
 L  R2827   
 L  R2828   
 L  R2829   
 L  R2830   
 L  R2831   
 L  R2832   
 L  R2833   
 L  R2834   
 L  R2835   
 L  R2836   
 L  R2837   
 L  R2838   
 L  R2839   
 L  R2840   
 L  R2841   
 L  R2842   
 L  R2843   
 L  R2844   
 L  R2845   
 L  R2846   
 L  R2847   
 L  R2848   
 L  R2849   
 L  R2850   
 L  R2851   
 L  R2852   
 L  R2853   
 L  R2854   
 L  R2855   
 L  R2856   
 L  R2857   
 L  R2858   
 L  R2859   
 L  R2860   
 L  R2861   
 L  R2862   
 L  R2863   
 L  R2864   
 L  R2865   
 L  R2866   
 L  R2867   
 L  R2868   
 L  R2869   
 L  R2870   
 L  R2871   
 L  R2872   
 L  R2873   
 L  R2874   
 L  R2875   
 L  R2876   
 L  R2877   
 L  R2878   
 L  R2879   
 L  R2880   
 L  R2881   
 L  R2882   
 L  R2883   
 L  R2884   
 L  R2885   
 L  R2886   
 L  R2887   
 L  R2888   
 L  R2889   
 L  R2890   
 L  R2891   
 L  R2892   
 L  R2893   
 L  R2894   
 L  R2895   
 L  R2896   
 L  R2897   
 L  R2898   
 L  R2899   
 L  R2900   
 L  R2901   
 L  R2902   
 L  R2903   
 L  R2904   
 L  R2905   
 L  R2906   
 L  R2907   
 L  R2908   
 L  R2909   
 L  R2910   
 L  R2911   
 L  R2912   
 L  R2913   
 L  R2914   
 L  R2915   
 L  R2916   
 L  R2917   
 L  R2918   
 L  R2919   
 L  R2920   
 L  R2921   
 L  R2922   
 L  R2923   
 L  R2924   
 L  R2925   
 L  R2926   
 L  R2927   
 L  R2928   
 L  R2929   
 L  R2930   
 L  R2931   
 L  R2932   
 L  R2933   
 L  R2934   
 L  R2935   
 L  R2936   
 L  R2937   
 L  R2938   
 L  R2939   
 L  R2940   
 L  R2941   
 L  R2942   
 L  R2943   
 L  R2944   
 L  R2945   
 L  R2946   
 L  R2947   
 L  R2948   
 L  R2949   
 L  R2950   
 L  R2951   
 L  R2952   
 L  R2953   
 L  R2954   
 L  R2955   
 L  R2956   
 L  R2957   
 L  R2958   
 L  R2959   
 L  R2960   
 L  R2961   
 L  R2962   
 L  R2963   
 L  R2964   
 L  R2965   
 L  R2966   
 L  R2967   
 L  R2968   
 L  R2969   
 L  R2970   
 L  R2971   
 L  R2972   
 L  R2973   
 L  R2974   
 L  R2975   
 L  R2976   
 L  R2977   
 L  R2978   
 L  R2979   
 L  R2980   
 L  R2981   
 L  R2982   
 L  R2983   
 L  R2984   
 L  R2985   
 L  R2986   
 L  R2987   
 L  R2988   
 L  R2989   
 L  R2990   
 L  R2991   
 L  R2992   
 L  R2993   
 L  R2994   
 L  R2995   
 L  R2996   
 L  R2997   
 L  R2998   
 L  R2999   
 L  R3000   
 L  R3001   
 L  R3002   
 L  R3003   
 L  R3004   
 L  R3005   
 L  R3006   
 L  R3007   
 L  R3008   
 L  R3009   
 L  R3010   
 L  R3011   
 L  R3012   
 L  R3013   
 L  R3014   
 L  R3015   
 L  R3016   
 L  R3017   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
 L  qc8     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R83       -3.0999999046325684e+00
    phi[0,1]  R84       -3.0999999046325684e+00
    phi[0,1]  R85       -2.2400000095367432e+00
    phi[0,1]  R86       -2.2400000095367432e+00
    phi[0,1]  R87       -3.0999999046325684e+00
    phi[0,1]  R88       -3.0999999046325684e+00
    phi[0,1]  R89       -2.5699999332427979e+00
    phi[0,1]  R90       -2.5699999332427979e+00
    phi[0,1]  R91       -3.0999999046325684e+00
    phi[0,1]  R92       -3.0999999046325684e+00
    phi[0,1]  R93       -2.0899999141693115e+00
    phi[0,1]  R94       -2.0899999141693115e+00
    phi[0,1]  R95       -3.0999999046325684e+00
    phi[0,1]  R96       -3.0999999046325684e+00
    phi[0,1]  R97       3.6841323971748352e-01
    phi[0,1]  R98       9.4976775348186493e-02
    phi[0,1]  R99       1.7492553591728210e-01
    phi[0,1]  R100      -6.4902013540267944e-01
    phi[0,1]  R101      -0.544015645980835
    phi[0,1]  R102      -6.5476067364215851e-02
    phi[0,1]  R103      -3.9310938119888306e-01
    phi[0,1]  R104      3.0206134915351868e-01
    phi[0,1]  R105      -1.9510000944137573e+00
    phi[0,1]  R106      2.0395611226558685e-01
    phi[0,1]  R107      -1.8147236108779907e+00
    phi[0,1]  R108      -2.6860964298248291e-01
    phi[0,1]  R109      -1.9700111150741577e+00
    phi[0,1]  R110      -1.7336626350879669e-01
    phi[0,1]  R111      -4.3426451086997986e-01
    phi[0,1]  R112      -0.288415789604187
    phi[0,1]  R113      -1.1381057500839233e+00
    phi[0,1]  R114      -4.0407335758209229e-01
    phi[0,1]  R115      -1.1821454763412476e+00
    phi[0,1]  R116      -7.8241086006164551e-01
    phi[0,1]  R117      -8.7979716062545776e-01
    phi[0,1]  R118      -8.8612926006317139e-01
    phi[0,1]  R119      -8.6342191696166992e-01
    phi[0,1]  R120      -1.5976548194885254e+00
    phi[0,1]  R121      -1.5959037542343140e+00
    phi[0,1]  R122      -1.9106793403625488e+00
    phi[0,1]  R123      -1.3955547809600830e+00
    phi[0,1]  R124      4.5200437307357788e-02
    phi[0,1]  R125      -1.1171829700469971e+00
    phi[0,1]  R126      2.1718165278434753e-01
    phi[0,1]  R127      -0.585711658000946
    phi[0,1]  R128      -1.8141325712203979e+00
    phi[0,1]  R129      -6.3398581743240356e-01
    phi[0,1]  R130      -2.5700739026069641e-01
    phi[0,1]  R131      -7.0124173164367676e-01
    phi[0,1]  R132      -2.9653182625770569e-01
    phi[0,1]  R133      -1.9889379739761353e+00
    phi[0,1]  R134      -1.4039809703826904e+00
    phi[0,1]  R135      -1.6545828580856323e+00
    phi[0,1]  R136      -3.5184672474861145e-01
    phi[0,1]  R137      4.5052725076675415e-01
    phi[0,1]  R138      -8.7487769126892090e-01
    phi[0,1]  R139      -1.2409967184066772e+00
    phi[0,1]  R140      -1.2237194776535034e+00
    phi[0,1]  R141      -3.2166007161140442e-01
    phi[0,1]  R142      -1.6635555028915405e-01
    phi[0,1]  R143      -4.7783127427101135e-01
    phi[0,1]  R144      -6.2624728679656982e-01
    phi[0,1]  R145      -2.4508963525295258e-01
    phi[0,1]  R146      -1.6968902349472046e+00
    phi[0,1]  R147      -1.4033994674682617e+00
    phi[0,1]  R148      -1.5287321805953979e-01
    phi[0,1]  R149      -1.5611131191253662e+00
    phi[0,1]  R150      -8.6895418167114258e-01
    phi[0,1]  R151      -1.9593201875686646e+00
    phi[0,1]  R152      3.3782371878623962e-01
    phi[0,1]  R153      -8.1023555994033813e-01
    phi[0,1]  R154      -1.4772222042083740e+00
    phi[0,1]  R155      -2.5230336189270020e+00
    phi[0,1]  R156      -1.68575119972229
    phi[0,1]  R157      7.0581710338592529e-01
    phi[0,1]  R158      1.2857401371002197e+00
    phi[0,1]  R159      1.2449791431427002e+00
    phi[0,1]  R160      7.8906130790710449e-01
    phi[0,1]  R161      1.1794650554656982e+00
    phi[0,1]  R162      7.7637231349945068e-01
    phi[0,1]  R163      7.7615588903427124e-01
    phi[0,1]  R164      1.0580040216445923e+00
    phi[0,1]  R165      -2.7246564626693726e-01
    phi[0,1]  R166      2.4565458297729492e-01
    phi[0,1]  R167      -2.6234167814254761e-01
    phi[0,1]  R168      1.0746860504150391e-01
    phi[0,1]  R169      2.6697331666946411e-01
    phi[0,1]  R170      -2.2192585468292236e-01
    phi[0,1]  R171      -5.3207254409790039e-01
    phi[0,1]  R172      -1.5096805989742279e-01
    phi[0,1]  R173      3.8666903972625732e-02
    phi[0,1]  R174      -3.6409664154052734e-01
    phi[0,1]  R175      1.8854357302188873e-01
    phi[0,1]  R176      -3.0958032608032227e-01
    phi[0,1]  R177      -1.4523614645004272e+00
    phi[0,1]  R178      -1.3720369338989258e+00
    phi[0,1]  R179      -1.6600272655487061e+00
    phi[0,1]  R180      -1.1131739616394043e+00
    phi[0,1]  R181      -1.2645827531814575e+00
    phi[0,1]  R182      -1.4135037660598755e+00
    phi[0,1]  R183      -1.0055119991302490e+00
    phi[0,1]  R184      -0.899972140789032
    phi[0,1]  R185      -1.0986747741699219e+00
    phi[0,1]  R186      -1.6302769184112549e+00
    phi[0,1]  R187      -4.7918668389320374e-01
    phi[0,1]  R188      -1.6353880167007446e+00
    phi[0,1]  R189      -1.6042659282684326e+00
    phi[0,1]  R190      -1.2693887948989868e+00
    phi[0,1]  R191      -1.9693913459777832e+00
    phi[0,1]  R192      -2.0945181846618652e+00
    phi[0,1]  R193      -1.6770938634872437e+00
    phi[0,1]  R194      -9.3601256608963013e-01
    phi[0,1]  R195      -9.1905772686004639e-01
    phi[0,1]  R196      -1.4506546258926392e+00
    phi[0,1]  R197      -1.3282465934753418e+00
    phi[0,1]  R198      -2.0819027423858643e+00
    phi[0,1]  R199      -1.6788767576217651e+00
    phi[0,1]  R200      -2.1277401447296143e+00
    phi[0,1]  R201      -2.1488819122314453e+00
    phi[0,1]  R202      -2.4454441070556641e+00
    phi[0,1]  R203      -1.2843089103698730e+00
    phi[0,1]  R204      -1.8869365453720093e+00
    phi[0,1]  R205      -1.8735146522521973e+00
    phi[0,1]  R206      -1.3547596931457520e+00
    phi[0,1]  R207      -1.4847203493118286e+00
    phi[0,1]  R208      -3.7128737568855286e-01
    phi[0,1]  R209      -5.9992873668670654e-01
    phi[0,1]  R210      -4.0980595350265503e-01
    phi[0,1]  R211      -8.9902347326278687e-01
    phi[0,1]  R212      -1.5234454870224
    phi[0,1]  R213      -2.1465973854064941e+00
    phi[0,1]  R214      -1.9807113409042358e+00
    phi[0,1]  R215      -1.1907218694686890e+00
    phi[0,1]  R216      -1.6505349874496460e+00
    phi[0,1]  R217      -2.2453193664550781e+00
    phi[0,1]  R218      -8.8201528787612915e-01
    phi[0,1]  R219      -3.8269901275634766e-01
    phi[0,1]  R220      -0.931524932384491
    phi[0,1]  R221      -9.7071743011474609e-01
    phi[0,1]  R222      -0.951265275478363
    phi[0,1]  R223      -1.0983262062072754e+00
    phi[0,1]  R224      -2.1882896423339844e+00
    phi[0,1]  R225      -1.1912208795547485e+00
    phi[0,1]  R226      -1.8264650106430054e+00
    phi[0,1]  R227      -8.3584690093994141e-01
    phi[0,1]  R228      -1.1410133838653564e+00
    phi[0,1]  R229      -1.2361494302749634e+00
    phi[0,1]  R230      -1.3587986230850220e+00
    phi[0,1]  R231      -1.5971895456314087e+00
    phi[0,1]  R232      -1.6416977643966675e+00
    phi[0,1]  R233      -1.9699259996414185e+00
    phi[0,1]  R234      -1.4119985103607178e+00
    phi[0,1]  R235      6.6172605752944946e-01
    phi[0,1]  R236      -1.5155097246170044e+00
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R237      -3.0999999046325684e+00
    phi[1,0]  R238      -3.0999999046325684e+00
    phi[1,0]  R239      -2.2400000095367432e+00
    phi[1,0]  R240      -2.2400000095367432e+00
    phi[1,0]  R241      -3.0999999046325684e+00
    phi[1,0]  R242      -3.0999999046325684e+00
    phi[1,0]  R243      -2.5699999332427979e+00
    phi[1,0]  R244      -2.5699999332427979e+00
    phi[1,0]  R245      -3.0999999046325684e+00
    phi[1,0]  R246      -3.0999999046325684e+00
    phi[1,0]  R247      -2.0899999141693115e+00
    phi[1,0]  R248      -2.0899999141693115e+00
    phi[1,0]  R249      -3.0999999046325684e+00
    phi[1,0]  R250      -3.0999999046325684e+00
    phi[1,0]  R251      7.0581710338592529e-01
    phi[1,0]  R252      1.2857401371002197e+00
    phi[1,0]  R253      1.2449791431427002e+00
    phi[1,0]  R254      7.8906130790710449e-01
    phi[1,0]  R255      1.1794650554656982e+00
    phi[1,0]  R256      7.7637231349945068e-01
    phi[1,0]  R257      7.7615588903427124e-01
    phi[1,0]  R258      1.0580040216445923e+00
    phi[1,0]  R259      -2.7246564626693726e-01
    phi[1,0]  R260      2.4565458297729492e-01
    phi[1,0]  R261      -2.6234167814254761e-01
    phi[1,0]  R262      1.0746860504150391e-01
    phi[1,0]  R263      2.6697331666946411e-01
    phi[1,0]  R264      -2.2192585468292236e-01
    phi[1,0]  R265      -5.3207254409790039e-01
    phi[1,0]  R266      -1.5096805989742279e-01
    phi[1,0]  R267      3.8666903972625732e-02
    phi[1,0]  R268      -3.6409664154052734e-01
    phi[1,0]  R269      1.8854357302188873e-01
    phi[1,0]  R270      -3.0958032608032227e-01
    phi[1,0]  R271      -1.4523614645004272e+00
    phi[1,0]  R272      -1.3720369338989258e+00
    phi[1,0]  R273      -1.6600272655487061e+00
    phi[1,0]  R274      -1.1131739616394043e+00
    phi[1,0]  R275      -1.2645827531814575e+00
    phi[1,0]  R276      -1.4135037660598755e+00
    phi[1,0]  R277      -1.0055119991302490e+00
    phi[1,0]  R278      -0.899972140789032
    phi[1,0]  R279      -1.0986747741699219e+00
    phi[1,0]  R280      -1.6302769184112549e+00
    phi[1,0]  R281      -4.7918668389320374e-01
    phi[1,0]  R282      -1.6353880167007446e+00
    phi[1,0]  R283      -1.6042659282684326e+00
    phi[1,0]  R284      -1.2693887948989868e+00
    phi[1,0]  R285      -1.9693913459777832e+00
    phi[1,0]  R286      -2.0945181846618652e+00
    phi[1,0]  R287      -1.6770938634872437e+00
    phi[1,0]  R288      -9.3601256608963013e-01
    phi[1,0]  R289      -9.1905772686004639e-01
    phi[1,0]  R290      -1.4506546258926392e+00
    phi[1,0]  R291      -1.3282465934753418e+00
    phi[1,0]  R292      -2.0819027423858643e+00
    phi[1,0]  R293      -1.6788767576217651e+00
    phi[1,0]  R294      -2.1277401447296143e+00
    phi[1,0]  R295      -2.1488819122314453e+00
    phi[1,0]  R296      -2.4454441070556641e+00
    phi[1,0]  R297      -1.2843089103698730e+00
    phi[1,0]  R298      -1.8869365453720093e+00
    phi[1,0]  R299      -1.8735146522521973e+00
    phi[1,0]  R300      -1.3547596931457520e+00
    phi[1,0]  R301      -1.4847203493118286e+00
    phi[1,0]  R302      -3.7128737568855286e-01
    phi[1,0]  R303      -5.9992873668670654e-01
    phi[1,0]  R304      -4.0980595350265503e-01
    phi[1,0]  R305      -8.9902347326278687e-01
    phi[1,0]  R306      -1.5234454870224
    phi[1,0]  R307      -2.1465973854064941e+00
    phi[1,0]  R308      -1.9807113409042358e+00
    phi[1,0]  R309      -1.1907218694686890e+00
    phi[1,0]  R310      -1.6505349874496460e+00
    phi[1,0]  R311      -2.2453193664550781e+00
    phi[1,0]  R312      -8.8201528787612915e-01
    phi[1,0]  R313      -3.8269901275634766e-01
    phi[1,0]  R314      -0.931524932384491
    phi[1,0]  R315      -9.7071743011474609e-01
    phi[1,0]  R316      -0.951265275478363
    phi[1,0]  R317      -1.0983262062072754e+00
    phi[1,0]  R318      -2.1882896423339844e+00
    phi[1,0]  R319      -1.1912208795547485e+00
    phi[1,0]  R320      -1.8264650106430054e+00
    phi[1,0]  R321      -8.3584690093994141e-01
    phi[1,0]  R322      -1.1410133838653564e+00
    phi[1,0]  R323      -1.2361494302749634e+00
    phi[1,0]  R324      -1.3587986230850220e+00
    phi[1,0]  R325      -1.5971895456314087e+00
    phi[1,0]  R326      -1.6416977643966675e+00
    phi[1,0]  R327      -1.9699259996414185e+00
    phi[1,0]  R328      -1.4119985103607178e+00
    phi[1,0]  R329      6.6172605752944946e-01
    phi[1,0]  R330      -1.5155097246170044e+00
    phi[1,0]  R331      3.6841323971748352e-01
    phi[1,0]  R332      9.4976775348186493e-02
    phi[1,0]  R333      1.7492553591728210e-01
    phi[1,0]  R334      -6.4902013540267944e-01
    phi[1,0]  R335      -0.544015645980835
    phi[1,0]  R336      -6.5476067364215851e-02
    phi[1,0]  R337      -3.9310938119888306e-01
    phi[1,0]  R338      3.0206134915351868e-01
    phi[1,0]  R339      -1.9510000944137573e+00
    phi[1,0]  R340      2.0395611226558685e-01
    phi[1,0]  R341      -1.8147236108779907e+00
    phi[1,0]  R342      -2.6860964298248291e-01
    phi[1,0]  R343      -1.9700111150741577e+00
    phi[1,0]  R344      -1.7336626350879669e-01
    phi[1,0]  R345      -4.3426451086997986e-01
    phi[1,0]  R346      -0.288415789604187
    phi[1,0]  R347      -1.1381057500839233e+00
    phi[1,0]  R348      -4.0407335758209229e-01
    phi[1,0]  R349      -1.1821454763412476e+00
    phi[1,0]  R350      -7.8241086006164551e-01
    phi[1,0]  R351      -8.7979716062545776e-01
    phi[1,0]  R352      -8.8612926006317139e-01
    phi[1,0]  R353      -8.6342191696166992e-01
    phi[1,0]  R354      -1.5976548194885254e+00
    phi[1,0]  R355      -1.5959037542343140e+00
    phi[1,0]  R356      -1.9106793403625488e+00
    phi[1,0]  R357      -1.3955547809600830e+00
    phi[1,0]  R358      4.5200437307357788e-02
    phi[1,0]  R359      -1.1171829700469971e+00
    phi[1,0]  R360      2.1718165278434753e-01
    phi[1,0]  R361      -0.585711658000946
    phi[1,0]  R362      -1.8141325712203979e+00
    phi[1,0]  R363      -6.3398581743240356e-01
    phi[1,0]  R364      -2.5700739026069641e-01
    phi[1,0]  R365      -7.0124173164367676e-01
    phi[1,0]  R366      -2.9653182625770569e-01
    phi[1,0]  R367      -1.9889379739761353e+00
    phi[1,0]  R368      -1.4039809703826904e+00
    phi[1,0]  R369      -1.6545828580856323e+00
    phi[1,0]  R370      -3.5184672474861145e-01
    phi[1,0]  R371      4.5052725076675415e-01
    phi[1,0]  R372      -8.7487769126892090e-01
    phi[1,0]  R373      -1.2409967184066772e+00
    phi[1,0]  R374      -1.2237194776535034e+00
    phi[1,0]  R375      -3.2166007161140442e-01
    phi[1,0]  R376      -1.6635555028915405e-01
    phi[1,0]  R377      -4.7783127427101135e-01
    phi[1,0]  R378      -6.2624728679656982e-01
    phi[1,0]  R379      -2.4508963525295258e-01
    phi[1,0]  R380      -1.6968902349472046e+00
    phi[1,0]  R381      -1.4033994674682617e+00
    phi[1,0]  R382      -1.5287321805953979e-01
    phi[1,0]  R383      -1.5611131191253662e+00
    phi[1,0]  R384      -8.6895418167114258e-01
    phi[1,0]  R385      -1.9593201875686646e+00
    phi[1,0]  R386      3.3782371878623962e-01
    phi[1,0]  R387      -8.1023555994033813e-01
    phi[1,0]  R388      -1.4772222042083740e+00
    phi[1,0]  R389      -2.5230336189270020e+00
    phi[1,0]  R390      -1.68575119972229
    phi[0,5]  R0        1
    phi[0,5]  R1        1
    phi[0,5]  R45       -1
    phi[0,5]  R391      -3.0999999046325684e+00
    phi[0,5]  R392      -3.0999999046325684e+00
    phi[0,5]  R393      -2.2400000095367432e+00
    phi[0,5]  R394      -2.2400000095367432e+00
    phi[0,5]  R395      -3.0999999046325684e+00
    phi[0,5]  R396      -3.0999999046325684e+00
    phi[0,5]  R397      -2.5699999332427979e+00
    phi[0,5]  R398      -2.5699999332427979e+00
    phi[0,5]  R399      -3.0999999046325684e+00
    phi[0,5]  R400      -3.0999999046325684e+00
    phi[0,5]  R401      -2.0899999141693115e+00
    phi[0,5]  R402      -2.0899999141693115e+00
    phi[0,5]  R403      -3.0999999046325684e+00
    phi[0,5]  R404      -3.0999999046325684e+00
    phi[0,5]  R405      3.6841323971748352e-01
    phi[0,5]  R406      9.4976775348186493e-02
    phi[0,5]  R407      1.7492553591728210e-01
    phi[0,5]  R408      -6.4902013540267944e-01
    phi[0,5]  R409      -0.544015645980835
    phi[0,5]  R410      -6.5476067364215851e-02
    phi[0,5]  R411      -3.9310938119888306e-01
    phi[0,5]  R412      3.0206134915351868e-01
    phi[0,5]  R413      -1.9510000944137573e+00
    phi[0,5]  R414      2.0395611226558685e-01
    phi[0,5]  R415      -1.8147236108779907e+00
    phi[0,5]  R416      -2.6860964298248291e-01
    phi[0,5]  R417      -1.9700111150741577e+00
    phi[0,5]  R418      -1.7336626350879669e-01
    phi[0,5]  R419      -4.3426451086997986e-01
    phi[0,5]  R420      -0.288415789604187
    phi[0,5]  R421      -1.1381057500839233e+00
    phi[0,5]  R422      -4.0407335758209229e-01
    phi[0,5]  R423      -1.1821454763412476e+00
    phi[0,5]  R424      -7.8241086006164551e-01
    phi[0,5]  R425      -8.7979716062545776e-01
    phi[0,5]  R426      -8.8612926006317139e-01
    phi[0,5]  R427      -8.6342191696166992e-01
    phi[0,5]  R428      -1.5976548194885254e+00
    phi[0,5]  R429      -1.5959037542343140e+00
    phi[0,5]  R430      -1.9106793403625488e+00
    phi[0,5]  R431      -1.3955547809600830e+00
    phi[0,5]  R432      4.5200437307357788e-02
    phi[0,5]  R433      -1.1171829700469971e+00
    phi[0,5]  R434      2.1718165278434753e-01
    phi[0,5]  R435      -0.585711658000946
    phi[0,5]  R436      -1.8141325712203979e+00
    phi[0,5]  R437      -6.3398581743240356e-01
    phi[0,5]  R438      -2.5700739026069641e-01
    phi[0,5]  R439      -7.0124173164367676e-01
    phi[0,5]  R440      -2.9653182625770569e-01
    phi[0,5]  R441      -1.9889379739761353e+00
    phi[0,5]  R442      -1.4039809703826904e+00
    phi[0,5]  R443      -1.6545828580856323e+00
    phi[0,5]  R444      -3.5184672474861145e-01
    phi[0,5]  R445      4.5052725076675415e-01
    phi[0,5]  R446      -8.7487769126892090e-01
    phi[0,5]  R447      -1.2409967184066772e+00
    phi[0,5]  R448      -1.2237194776535034e+00
    phi[0,5]  R449      -3.2166007161140442e-01
    phi[0,5]  R450      -1.6635555028915405e-01
    phi[0,5]  R451      -4.7783127427101135e-01
    phi[0,5]  R452      -6.2624728679656982e-01
    phi[0,5]  R453      -2.4508963525295258e-01
    phi[0,5]  R454      -1.6968902349472046e+00
    phi[0,5]  R455      -1.4033994674682617e+00
    phi[0,5]  R456      -1.5287321805953979e-01
    phi[0,5]  R457      -1.5611131191253662e+00
    phi[0,5]  R458      -8.6895418167114258e-01
    phi[0,5]  R459      -1.9593201875686646e+00
    phi[0,5]  R460      3.3782371878623962e-01
    phi[0,5]  R461      -8.1023555994033813e-01
    phi[0,5]  R462      -1.4772222042083740e+00
    phi[0,5]  R463      -2.5230336189270020e+00
    phi[0,5]  R464      -1.68575119972229
    phi[0,5]  R465      2.6831056922674179e-02
    phi[0,5]  R466      -4.2942622303962708e-01
    phi[0,5]  R467      9.7848415374755859e-01
    phi[0,5]  R468      0.0994705855846405
    phi[0,5]  R469      7.0897883176803589e-01
    phi[0,5]  R470      5.9090304374694824e-01
    phi[0,5]  R471      -2.5024530291557312e-01
    phi[0,5]  R472      -1.8264852464199066e-01
    phi[0,5]  R473      -7.1134227514266968e-01
    phi[0,5]  R474      -0.820121169090271
    phi[0,5]  R475      -1.8181357383728027e+00
    phi[0,5]  R476      -2.3563027381896973e+00
    phi[0,5]  R477      -1.9937500953674316e+00
    phi[0,5]  R478      -1.8709206581115723e+00
    phi[0,5]  R479      -1.3309085369110107e+00
    phi[0,5]  R480      -8.7400436401367188e-01
    phi[0,5]  R481      -4.2216670513153076e-01
    phi[0,5]  R482      -1.2581146955490112e+00
    phi[0,5]  R483      -8.7997305393218994e-01
    phi[0,5]  R484      -6.4638954401016235e-01
    phi[0,5]  R485      -9.1535031795501709e-01
    phi[0,5]  R486      -1.1431825160980225e+00
    phi[0,5]  R487      -1.5140734612941742e-01
    phi[0,5]  R488      -6.7351406812667847e-01
    phi[0,5]  R489      -1.2798300981521606e+00
    phi[0,5]  R490      -1.2490893602371216e+00
    phi[0,5]  R491      3.9258778095245361e-01
    phi[0,5]  R492      -1.8112614154815674e+00
    phi[0,5]  R493      3.5978391766548157e-02
    phi[0,5]  R494      -1.6011202335357666e-01
    phi[0,5]  R495      -1.0940562486648560e+00
    phi[0,5]  R496      -7.7748584747314453e-01
    phi[0,5]  R497      -7.9182225465774536e-01
    phi[0,5]  R498      -2.8238520026206970e-01
    phi[0,5]  R499      -1.1029708385467529e+00
    phi[0,5]  R500      -1.7994811534881592e+00
    phi[0,5]  R501      -1.83518648147583
    phi[0,5]  R502      -1.0832253694534302e+00
    phi[0,5]  R503      -2.7434592247009277e+00
    phi[0,5]  R504      -2.8418223857879639e+00
    phi[5,0]  R0        -1
    phi[5,0]  R45       1
    phi[5,0]  R46       1
    phi[5,0]  R505      -3.0999999046325684e+00
    phi[5,0]  R506      -3.0999999046325684e+00
    phi[5,0]  R507      -2.2400000095367432e+00
    phi[5,0]  R508      -2.2400000095367432e+00
    phi[5,0]  R509      -3.0999999046325684e+00
    phi[5,0]  R510      -3.0999999046325684e+00
    phi[5,0]  R511      -2.5699999332427979e+00
    phi[5,0]  R512      -2.5699999332427979e+00
    phi[5,0]  R513      -3.0999999046325684e+00
    phi[5,0]  R514      -3.0999999046325684e+00
    phi[5,0]  R515      -2.0899999141693115e+00
    phi[5,0]  R516      -2.0899999141693115e+00
    phi[5,0]  R517      -3.0999999046325684e+00
    phi[5,0]  R518      -3.0999999046325684e+00
    phi[5,0]  R519      2.6831056922674179e-02
    phi[5,0]  R520      -4.2942622303962708e-01
    phi[5,0]  R521      9.7848415374755859e-01
    phi[5,0]  R522      0.0994705855846405
    phi[5,0]  R523      7.0897883176803589e-01
    phi[5,0]  R524      5.9090304374694824e-01
    phi[5,0]  R525      -2.5024530291557312e-01
    phi[5,0]  R526      -1.8264852464199066e-01
    phi[5,0]  R527      -7.1134227514266968e-01
    phi[5,0]  R528      -0.820121169090271
    phi[5,0]  R529      -1.8181357383728027e+00
    phi[5,0]  R530      -2.3563027381896973e+00
    phi[5,0]  R531      -1.9937500953674316e+00
    phi[5,0]  R532      -1.8709206581115723e+00
    phi[5,0]  R533      -1.3309085369110107e+00
    phi[5,0]  R534      -8.7400436401367188e-01
    phi[5,0]  R535      -4.2216670513153076e-01
    phi[5,0]  R536      -1.2581146955490112e+00
    phi[5,0]  R537      -8.7997305393218994e-01
    phi[5,0]  R538      -6.4638954401016235e-01
    phi[5,0]  R539      -9.1535031795501709e-01
    phi[5,0]  R540      -1.1431825160980225e+00
    phi[5,0]  R541      -1.5140734612941742e-01
    phi[5,0]  R542      -6.7351406812667847e-01
    phi[5,0]  R543      -1.2798300981521606e+00
    phi[5,0]  R544      -1.2490893602371216e+00
    phi[5,0]  R545      3.9258778095245361e-01
    phi[5,0]  R546      -1.8112614154815674e+00
    phi[5,0]  R547      3.5978391766548157e-02
    phi[5,0]  R548      -1.6011202335357666e-01
    phi[5,0]  R549      -1.0940562486648560e+00
    phi[5,0]  R550      -7.7748584747314453e-01
    phi[5,0]  R551      -7.9182225465774536e-01
    phi[5,0]  R552      -2.8238520026206970e-01
    phi[5,0]  R553      -1.1029708385467529e+00
    phi[5,0]  R554      -1.7994811534881592e+00
    phi[5,0]  R555      -1.83518648147583
    phi[5,0]  R556      -1.0832253694534302e+00
    phi[5,0]  R557      -2.7434592247009277e+00
    phi[5,0]  R558      -2.8418223857879639e+00
    phi[5,0]  R559      3.6841323971748352e-01
    phi[5,0]  R560      9.4976775348186493e-02
    phi[5,0]  R561      1.7492553591728210e-01
    phi[5,0]  R562      -6.4902013540267944e-01
    phi[5,0]  R563      -0.544015645980835
    phi[5,0]  R564      -6.5476067364215851e-02
    phi[5,0]  R565      -3.9310938119888306e-01
    phi[5,0]  R566      3.0206134915351868e-01
    phi[5,0]  R567      -1.9510000944137573e+00
    phi[5,0]  R568      2.0395611226558685e-01
    phi[5,0]  R569      -1.8147236108779907e+00
    phi[5,0]  R570      -2.6860964298248291e-01
    phi[5,0]  R571      -1.9700111150741577e+00
    phi[5,0]  R572      -1.7336626350879669e-01
    phi[5,0]  R573      -4.3426451086997986e-01
    phi[5,0]  R574      -0.288415789604187
    phi[5,0]  R575      -1.1381057500839233e+00
    phi[5,0]  R576      -4.0407335758209229e-01
    phi[5,0]  R577      -1.1821454763412476e+00
    phi[5,0]  R578      -7.8241086006164551e-01
    phi[5,0]  R579      -8.7979716062545776e-01
    phi[5,0]  R580      -8.8612926006317139e-01
    phi[5,0]  R581      -8.6342191696166992e-01
    phi[5,0]  R582      -1.5976548194885254e+00
    phi[5,0]  R583      -1.5959037542343140e+00
    phi[5,0]  R584      -1.9106793403625488e+00
    phi[5,0]  R585      -1.3955547809600830e+00
    phi[5,0]  R586      4.5200437307357788e-02
    phi[5,0]  R587      -1.1171829700469971e+00
    phi[5,0]  R588      2.1718165278434753e-01
    phi[5,0]  R589      -0.585711658000946
    phi[5,0]  R590      -1.8141325712203979e+00
    phi[5,0]  R591      -6.3398581743240356e-01
    phi[5,0]  R592      -2.5700739026069641e-01
    phi[5,0]  R593      -7.0124173164367676e-01
    phi[5,0]  R594      -2.9653182625770569e-01
    phi[5,0]  R595      -1.9889379739761353e+00
    phi[5,0]  R596      -1.4039809703826904e+00
    phi[5,0]  R597      -1.6545828580856323e+00
    phi[5,0]  R598      -3.5184672474861145e-01
    phi[5,0]  R599      4.5052725076675415e-01
    phi[5,0]  R600      -8.7487769126892090e-01
    phi[5,0]  R601      -1.2409967184066772e+00
    phi[5,0]  R602      -1.2237194776535034e+00
    phi[5,0]  R603      -3.2166007161140442e-01
    phi[5,0]  R604      -1.6635555028915405e-01
    phi[5,0]  R605      -4.7783127427101135e-01
    phi[5,0]  R606      -6.2624728679656982e-01
    phi[5,0]  R607      -2.4508963525295258e-01
    phi[5,0]  R608      -1.6968902349472046e+00
    phi[5,0]  R609      -1.4033994674682617e+00
    phi[5,0]  R610      -1.5287321805953979e-01
    phi[5,0]  R611      -1.5611131191253662e+00
    phi[5,0]  R612      -8.6895418167114258e-01
    phi[5,0]  R613      -1.9593201875686646e+00
    phi[5,0]  R614      3.3782371878623962e-01
    phi[5,0]  R615      -8.1023555994033813e-01
    phi[5,0]  R616      -1.4772222042083740e+00
    phi[5,0]  R617      -2.5230336189270020e+00
    phi[5,0]  R618      -1.68575119972229
    phi[9,0]  R0        -1
    phi[9,0]  R2        -1.0876942707822710e+00
    phi[9,0]  R3        -1.3864910604887788e+00
    phi[9,0]  R4        -8.0873759611484930e-01
    phi[9,0]  R5        1.7029626216183824e+00
    phi[9,0]  R6        1.5535340012573573e+00
    phi[9,0]  R7        1.2092606776728023e+00
    phi[9,0]  R8        -8.6802718594208583e-01
    phi[9,0]  R81       1
    phi[9,0]  R619      -2.0123056338502971e+00
    phi[9,0]  R620      -4.18769417541484
    phi[9,0]  R621      -8.5350894904796437e-01
    phi[9,0]  R622      -3.6264910700255220e+00
    phi[9,0]  R623      -2.2912623085177191e+00
    phi[9,0]  R624      -3.9087375007474177e+00
    phi[9,0]  R625      -4.2729625548611807e+00
    phi[9,0]  R626      -8.6703731162441544e-01
    phi[9,0]  R627      -4.6535339058899261e+00
    phi[9,0]  R628      -1.5464659033752111e+00
    phi[9,0]  R629      -3.2992605918421138e+00
    phi[9,0]  R630      -8.8073923649650920e-01
    phi[9,0]  R631      -2.2319727186904825e+00
    phi[9,0]  R632      -3.9680270905746542e+00
    phi[9,0]  R633      -1.8471695292999646e-01
    phi[9,0]  R634      -1.9273261307173384e-01
    phi[9,0]  R635      -2.3617925853314509e-01
    phi[9,0]  R636      -3.3435267230712018e-01
    phi[9,0]  R637      -3.4448597604659481e-01
    phi[9,0]  R638      -3.6478838932836233e-01
    phi[9,0]  R639      -1.4620485148583604e+00
    phi[9,0]  R640      -3.9501488868401036e-01
    phi[9,0]  R641      -4.0865379950503433e-01
    phi[9,0]  R642      -8.9020006851867084e-01
    phi[9,0]  R643      -3.4901822571049146e-01
    phi[9,0]  R644      -5.2323891049270566e-01
    phi[9,0]  R645      -6.2255081453916361e-01
    phi[9,0]  R646      -7.0689043925059181e-01
    phi[9,0]  R647      -7.1410592749421831e-01
    phi[9,0]  R648      -7.2134034338886033e-01
    phi[9,0]  R649      -0.734897079717932
    phi[9,0]  R650      -7.3642306361022492e-01
    phi[9,0]  R651      -7.3706720604679243e-01
    phi[9,0]  R652      -7.3946907890239355e-01
    phi[9,0]  R653      -3.3085508765428562e-01
    phi[9,0]  R654      -3.3195368185711494e-01
    phi[9,0]  R655      -3.4137072214843067e-01
    phi[9,0]  R656      -3.4989821445100922e-01
    phi[9,0]  R657      -3.6455694237560832e-01
    phi[9,0]  R658      -3.7749821709133924e-01
    phi[9,0]  R659      -4.4022893512565420e-01
    phi[9,0]  R660      -4.4266742109151080e-01
    phi[9,0]  R661      -4.6559268521137920e-01
    phi[9,0]  R662      -4.7280405216938037e-01
    phi[9,0]  R663      -3.4698008160853422e-01
    phi[9,0]  R664      -3.5783471327815519e-01
    phi[9,0]  R665      -3.6450710144395115e-01
    phi[9,0]  R666      -4.3193402137859449e-01
    phi[9,0]  R667      -4.4968763753966362e-01
    phi[9,0]  R668      -0.514571212830066
    phi[9,0]  R669      -5.3750928449239610e-01
    phi[9,0]  R670      -5.4311248808347468e-01
    phi[9,0]  R671      -6.1818588413527520e-01
    phi[9,0]  R672      -7.2706445458755953e-01
    phi[9,0]  R673      -3.1687430858323251e-01
    phi[9,0]  R674      -0.430505672197259
    phi[9,0]  R675      -4.4434603398691574e-01
    phi[9,0]  R676      -4.7453725882223952e-01
    phi[9,0]  R677      -4.8140848286012583e-01
    phi[9,0]  R678      -1.7861871835413954e+00
    phi[9,0]  R679      -0.637635755665347
    phi[9,0]  R680      -0.666918086961692
    phi[9,0]  R681      -0.671313602395598
    phi[9,0]  R682      -6.8424150571724840e-01
    phi[9,0]  R683      -3.1413791671544433e-01
    phi[9,0]  R684      -3.5026811318816953e-01
    phi[9,0]  R685      -3.6891082389033736e-01
    phi[9,0]  R686      -3.7885232400579882e-01
    phi[9,0]  R687      -3.7951697062704004e-01
    phi[9,0]  R688      -8.1499126921699916e-01
    phi[9,0]  R689      -7.9309826964675967e-01
    phi[9,0]  R690      -8.3832685395828754e-01
    phi[9,0]  R691      -8.5563817674449227e-01
    phi[9,0]  R692      -8.6696788474565112e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R693      -3.0999999046325684e+00
    phi[1,2]  R694      -3.0999999046325684e+00
    phi[1,2]  R695      -2.2400000095367432e+00
    phi[1,2]  R696      -2.2400000095367432e+00
    phi[1,2]  R697      -3.0999999046325684e+00
    phi[1,2]  R698      -3.0999999046325684e+00
    phi[1,2]  R699      -2.5699999332427979e+00
    phi[1,2]  R700      -2.5699999332427979e+00
    phi[1,2]  R701      -3.0999999046325684e+00
    phi[1,2]  R702      -3.0999999046325684e+00
    phi[1,2]  R703      -2.0899999141693115e+00
    phi[1,2]  R704      -2.0899999141693115e+00
    phi[1,2]  R705      -3.0999999046325684e+00
    phi[1,2]  R706      -3.0999999046325684e+00
    phi[1,2]  R707      7.0581710338592529e-01
    phi[1,2]  R708      1.2857401371002197e+00
    phi[1,2]  R709      1.2449791431427002e+00
    phi[1,2]  R710      7.8906130790710449e-01
    phi[1,2]  R711      1.1794650554656982e+00
    phi[1,2]  R712      7.7637231349945068e-01
    phi[1,2]  R713      7.7615588903427124e-01
    phi[1,2]  R714      1.0580040216445923e+00
    phi[1,2]  R715      -2.7246564626693726e-01
    phi[1,2]  R716      2.4565458297729492e-01
    phi[1,2]  R717      -2.6234167814254761e-01
    phi[1,2]  R718      1.0746860504150391e-01
    phi[1,2]  R719      2.6697331666946411e-01
    phi[1,2]  R720      -2.2192585468292236e-01
    phi[1,2]  R721      -5.3207254409790039e-01
    phi[1,2]  R722      -1.5096805989742279e-01
    phi[1,2]  R723      3.8666903972625732e-02
    phi[1,2]  R724      -3.6409664154052734e-01
    phi[1,2]  R725      1.8854357302188873e-01
    phi[1,2]  R726      -3.0958032608032227e-01
    phi[1,2]  R727      -1.4523614645004272e+00
    phi[1,2]  R728      -1.3720369338989258e+00
    phi[1,2]  R729      -1.6600272655487061e+00
    phi[1,2]  R730      -1.1131739616394043e+00
    phi[1,2]  R731      -1.2645827531814575e+00
    phi[1,2]  R732      -1.4135037660598755e+00
    phi[1,2]  R733      -1.0055119991302490e+00
    phi[1,2]  R734      -0.899972140789032
    phi[1,2]  R735      -1.0986747741699219e+00
    phi[1,2]  R736      -1.6302769184112549e+00
    phi[1,2]  R737      -4.7918668389320374e-01
    phi[1,2]  R738      -1.6353880167007446e+00
    phi[1,2]  R739      -1.6042659282684326e+00
    phi[1,2]  R740      -1.2693887948989868e+00
    phi[1,2]  R741      -1.9693913459777832e+00
    phi[1,2]  R742      -2.0945181846618652e+00
    phi[1,2]  R743      -1.6770938634872437e+00
    phi[1,2]  R744      -9.3601256608963013e-01
    phi[1,2]  R745      -9.1905772686004639e-01
    phi[1,2]  R746      -1.4506546258926392e+00
    phi[1,2]  R747      -1.3282465934753418e+00
    phi[1,2]  R748      -2.0819027423858643e+00
    phi[1,2]  R749      -1.6788767576217651e+00
    phi[1,2]  R750      -2.1277401447296143e+00
    phi[1,2]  R751      -2.1488819122314453e+00
    phi[1,2]  R752      -2.4454441070556641e+00
    phi[1,2]  R753      -1.2843089103698730e+00
    phi[1,2]  R754      -1.8869365453720093e+00
    phi[1,2]  R755      -1.8735146522521973e+00
    phi[1,2]  R756      -1.3547596931457520e+00
    phi[1,2]  R757      -1.4847203493118286e+00
    phi[1,2]  R758      -3.7128737568855286e-01
    phi[1,2]  R759      -5.9992873668670654e-01
    phi[1,2]  R760      -4.0980595350265503e-01
    phi[1,2]  R761      -8.9902347326278687e-01
    phi[1,2]  R762      -1.5234454870224
    phi[1,2]  R763      -2.1465973854064941e+00
    phi[1,2]  R764      -1.9807113409042358e+00
    phi[1,2]  R765      -1.1907218694686890e+00
    phi[1,2]  R766      -1.6505349874496460e+00
    phi[1,2]  R767      -2.2453193664550781e+00
    phi[1,2]  R768      -8.8201528787612915e-01
    phi[1,2]  R769      -3.8269901275634766e-01
    phi[1,2]  R770      -0.931524932384491
    phi[1,2]  R771      -9.7071743011474609e-01
    phi[1,2]  R772      -0.951265275478363
    phi[1,2]  R773      -1.0983262062072754e+00
    phi[1,2]  R774      -2.1882896423339844e+00
    phi[1,2]  R775      -1.1912208795547485e+00
    phi[1,2]  R776      -1.8264650106430054e+00
    phi[1,2]  R777      -8.3584690093994141e-01
    phi[1,2]  R778      -1.1410133838653564e+00
    phi[1,2]  R779      -1.2361494302749634e+00
    phi[1,2]  R780      -1.3587986230850220e+00
    phi[1,2]  R781      -1.5971895456314087e+00
    phi[1,2]  R782      -1.6416977643966675e+00
    phi[1,2]  R783      -1.9699259996414185e+00
    phi[1,2]  R784      -1.4119985103607178e+00
    phi[1,2]  R785      6.6172605752944946e-01
    phi[1,2]  R786      -1.5155097246170044e+00
    phi[1,2]  R787      1.4658120870590210e+00
    phi[1,2]  R788      -5.7754196226596832e-02
    phi[1,2]  R789      -7.9105056822299957e-02
    phi[1,2]  R790      8.6138397455215454e-01
    phi[1,2]  R791      1.1949729919433594e+00
    phi[1,2]  R792      1.0626022815704346e+00
    phi[1,2]  R793      1.3570271730422974e+00
    phi[1,2]  R794      1.3911136388778687e+00
    phi[1,2]  R795      6.0133183002471924e-01
    phi[1,2]  R796      2.1430739760398865e-01
    phi[1,2]  R797      -9.1402125358581543e-01
    phi[1,2]  R798      7.3895761743187904e-03
    phi[1,2]  R799      -1.1982066631317139e+00
    phi[1,2]  R800      -1.5418968200683594e+00
    phi[1,2]  R801      -2.1503503322601318e+00
    phi[1,2]  R802      -1.1939885616302490e+00
    phi[1,2]  R803      -0.574803352355957
    phi[1,2]  R804      -9.5286267995834351e-01
    phi[1,2]  R805      -3.2604852318763733e-01
    phi[1,2]  R806      -8.7450706958770752e-01
    phi[1,2]  R807      -7.6050686836242676e-01
    phi[1,2]  R808      -0.953938901424408
    phi[1,2]  R809      -3.3279955387115479e-01
    phi[1,2]  R810      -7.4625766277313232e-01
    phi[1,2]  R811      -9.4432276487350464e-01
    phi[1,2]  R812      -0.905570924282074
    phi[1,2]  R813      -1.2130230665206909e+00
    phi[1,2]  R814      -1.1740211248397827e+00
    phi[1,2]  R815      -1.4113448858261108e+00
    phi[1,2]  R816      -1.2674739360809326e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R817      -3.0999999046325684e+00
    phi[2,1]  R818      -3.0999999046325684e+00
    phi[2,1]  R819      -2.2400000095367432e+00
    phi[2,1]  R820      -2.2400000095367432e+00
    phi[2,1]  R821      -3.0999999046325684e+00
    phi[2,1]  R822      -3.0999999046325684e+00
    phi[2,1]  R823      -2.5699999332427979e+00
    phi[2,1]  R824      -2.5699999332427979e+00
    phi[2,1]  R825      -3.0999999046325684e+00
    phi[2,1]  R826      -3.0999999046325684e+00
    phi[2,1]  R827      -2.0899999141693115e+00
    phi[2,1]  R828      -2.0899999141693115e+00
    phi[2,1]  R829      -3.0999999046325684e+00
    phi[2,1]  R830      -3.0999999046325684e+00
    phi[2,1]  R831      1.4658120870590210e+00
    phi[2,1]  R832      -5.7754196226596832e-02
    phi[2,1]  R833      -7.9105056822299957e-02
    phi[2,1]  R834      8.6138397455215454e-01
    phi[2,1]  R835      1.1949729919433594e+00
    phi[2,1]  R836      1.0626022815704346e+00
    phi[2,1]  R837      1.3570271730422974e+00
    phi[2,1]  R838      1.3911136388778687e+00
    phi[2,1]  R839      6.0133183002471924e-01
    phi[2,1]  R840      2.1430739760398865e-01
    phi[2,1]  R841      -9.1402125358581543e-01
    phi[2,1]  R842      7.3895761743187904e-03
    phi[2,1]  R843      -1.1982066631317139e+00
    phi[2,1]  R844      -1.5418968200683594e+00
    phi[2,1]  R845      -2.1503503322601318e+00
    phi[2,1]  R846      -1.1939885616302490e+00
    phi[2,1]  R847      -0.574803352355957
    phi[2,1]  R848      -9.5286267995834351e-01
    phi[2,1]  R849      -3.2604852318763733e-01
    phi[2,1]  R850      -8.7450706958770752e-01
    phi[2,1]  R851      -7.6050686836242676e-01
    phi[2,1]  R852      -0.953938901424408
    phi[2,1]  R853      -3.3279955387115479e-01
    phi[2,1]  R854      -7.4625766277313232e-01
    phi[2,1]  R855      -9.4432276487350464e-01
    phi[2,1]  R856      -0.905570924282074
    phi[2,1]  R857      -1.2130230665206909e+00
    phi[2,1]  R858      -1.1740211248397827e+00
    phi[2,1]  R859      -1.4113448858261108e+00
    phi[2,1]  R860      -1.2674739360809326e+00
    phi[2,1]  R861      7.0581710338592529e-01
    phi[2,1]  R862      1.2857401371002197e+00
    phi[2,1]  R863      1.2449791431427002e+00
    phi[2,1]  R864      7.8906130790710449e-01
    phi[2,1]  R865      1.1794650554656982e+00
    phi[2,1]  R866      7.7637231349945068e-01
    phi[2,1]  R867      7.7615588903427124e-01
    phi[2,1]  R868      1.0580040216445923e+00
    phi[2,1]  R869      -2.7246564626693726e-01
    phi[2,1]  R870      2.4565458297729492e-01
    phi[2,1]  R871      -2.6234167814254761e-01
    phi[2,1]  R872      1.0746860504150391e-01
    phi[2,1]  R873      2.6697331666946411e-01
    phi[2,1]  R874      -2.2192585468292236e-01
    phi[2,1]  R875      -5.3207254409790039e-01
    phi[2,1]  R876      -1.5096805989742279e-01
    phi[2,1]  R877      3.8666903972625732e-02
    phi[2,1]  R878      -3.6409664154052734e-01
    phi[2,1]  R879      1.8854357302188873e-01
    phi[2,1]  R880      -3.0958032608032227e-01
    phi[2,1]  R881      -1.4523614645004272e+00
    phi[2,1]  R882      -1.3720369338989258e+00
    phi[2,1]  R883      -1.6600272655487061e+00
    phi[2,1]  R884      -1.1131739616394043e+00
    phi[2,1]  R885      -1.2645827531814575e+00
    phi[2,1]  R886      -1.4135037660598755e+00
    phi[2,1]  R887      -1.0055119991302490e+00
    phi[2,1]  R888      -0.899972140789032
    phi[2,1]  R889      -1.0986747741699219e+00
    phi[2,1]  R890      -1.6302769184112549e+00
    phi[2,1]  R891      -4.7918668389320374e-01
    phi[2,1]  R892      -1.6353880167007446e+00
    phi[2,1]  R893      -1.6042659282684326e+00
    phi[2,1]  R894      -1.2693887948989868e+00
    phi[2,1]  R895      -1.9693913459777832e+00
    phi[2,1]  R896      -2.0945181846618652e+00
    phi[2,1]  R897      -1.6770938634872437e+00
    phi[2,1]  R898      -9.3601256608963013e-01
    phi[2,1]  R899      -9.1905772686004639e-01
    phi[2,1]  R900      -1.4506546258926392e+00
    phi[2,1]  R901      -1.3282465934753418e+00
    phi[2,1]  R902      -2.0819027423858643e+00
    phi[2,1]  R903      -1.6788767576217651e+00
    phi[2,1]  R904      -2.1277401447296143e+00
    phi[2,1]  R905      -2.1488819122314453e+00
    phi[2,1]  R906      -2.4454441070556641e+00
    phi[2,1]  R907      -1.2843089103698730e+00
    phi[2,1]  R908      -1.8869365453720093e+00
    phi[2,1]  R909      -1.8735146522521973e+00
    phi[2,1]  R910      -1.3547596931457520e+00
    phi[2,1]  R911      -1.4847203493118286e+00
    phi[2,1]  R912      -3.7128737568855286e-01
    phi[2,1]  R913      -5.9992873668670654e-01
    phi[2,1]  R914      -4.0980595350265503e-01
    phi[2,1]  R915      -8.9902347326278687e-01
    phi[2,1]  R916      -1.5234454870224
    phi[2,1]  R917      -2.1465973854064941e+00
    phi[2,1]  R918      -1.9807113409042358e+00
    phi[2,1]  R919      -1.1907218694686890e+00
    phi[2,1]  R920      -1.6505349874496460e+00
    phi[2,1]  R921      -2.2453193664550781e+00
    phi[2,1]  R922      -8.8201528787612915e-01
    phi[2,1]  R923      -3.8269901275634766e-01
    phi[2,1]  R924      -0.931524932384491
    phi[2,1]  R925      -9.7071743011474609e-01
    phi[2,1]  R926      -0.951265275478363
    phi[2,1]  R927      -1.0983262062072754e+00
    phi[2,1]  R928      -2.1882896423339844e+00
    phi[2,1]  R929      -1.1912208795547485e+00
    phi[2,1]  R930      -1.8264650106430054e+00
    phi[2,1]  R931      -8.3584690093994141e-01
    phi[2,1]  R932      -1.1410133838653564e+00
    phi[2,1]  R933      -1.2361494302749634e+00
    phi[2,1]  R934      -1.3587986230850220e+00
    phi[2,1]  R935      -1.5971895456314087e+00
    phi[2,1]  R936      -1.6416977643966675e+00
    phi[2,1]  R937      -1.9699259996414185e+00
    phi[2,1]  R938      -1.4119985103607178e+00
    phi[2,1]  R939      6.6172605752944946e-01
    phi[2,1]  R940      -1.5155097246170044e+00
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R941      -3.0999999046325684e+00
    phi[2,3]  R942      -3.0999999046325684e+00
    phi[2,3]  R943      -2.2400000095367432e+00
    phi[2,3]  R944      -2.2400000095367432e+00
    phi[2,3]  R945      -3.0999999046325684e+00
    phi[2,3]  R946      -3.0999999046325684e+00
    phi[2,3]  R947      -2.5699999332427979e+00
    phi[2,3]  R948      -2.5699999332427979e+00
    phi[2,3]  R949      -3.0999999046325684e+00
    phi[2,3]  R950      -3.0999999046325684e+00
    phi[2,3]  R951      -2.0899999141693115e+00
    phi[2,3]  R952      -2.0899999141693115e+00
    phi[2,3]  R953      -3.0999999046325684e+00
    phi[2,3]  R954      -3.0999999046325684e+00
    phi[2,3]  R955      1.4658120870590210e+00
    phi[2,3]  R956      -5.7754196226596832e-02
    phi[2,3]  R957      -7.9105056822299957e-02
    phi[2,3]  R958      8.6138397455215454e-01
    phi[2,3]  R959      1.1949729919433594e+00
    phi[2,3]  R960      1.0626022815704346e+00
    phi[2,3]  R961      1.3570271730422974e+00
    phi[2,3]  R962      1.3911136388778687e+00
    phi[2,3]  R963      6.0133183002471924e-01
    phi[2,3]  R964      2.1430739760398865e-01
    phi[2,3]  R965      -9.1402125358581543e-01
    phi[2,3]  R966      7.3895761743187904e-03
    phi[2,3]  R967      -1.1982066631317139e+00
    phi[2,3]  R968      -1.5418968200683594e+00
    phi[2,3]  R969      -2.1503503322601318e+00
    phi[2,3]  R970      -1.1939885616302490e+00
    phi[2,3]  R971      -0.574803352355957
    phi[2,3]  R972      -9.5286267995834351e-01
    phi[2,3]  R973      -3.2604852318763733e-01
    phi[2,3]  R974      -8.7450706958770752e-01
    phi[2,3]  R975      -7.6050686836242676e-01
    phi[2,3]  R976      -0.953938901424408
    phi[2,3]  R977      -3.3279955387115479e-01
    phi[2,3]  R978      -7.4625766277313232e-01
    phi[2,3]  R979      -9.4432276487350464e-01
    phi[2,3]  R980      -0.905570924282074
    phi[2,3]  R981      -1.2130230665206909e+00
    phi[2,3]  R982      -1.1740211248397827e+00
    phi[2,3]  R983      -1.4113448858261108e+00
    phi[2,3]  R984      -1.2674739360809326e+00
    phi[2,3]  R985      2.6116118431091309e+00
    phi[2,3]  R986      2.3428595066070557e+00
    phi[2,3]  R987      1.4125819206237793e+00
    phi[2,3]  R988      2.6769866943359375e+00
    phi[2,3]  R989      1.9768807888031006e+00
    phi[2,3]  R990      1.6142692565917969e+00
    phi[2,3]  R991      1.1479370594024658e+00
    phi[2,3]  R992      -1.8136522769927979e+00
    phi[2,3]  R993      4.7017911076545715e-01
    phi[2,3]  R994      -7.1002656221389771e-01
    phi[2,3]  R995      2.4587005376815796e-01
    phi[2,3]  R996      2.9710370302200317e-01
    phi[2,3]  R997      -2.1677258014678955e+00
    phi[2,3]  R998      -3.63869571685791
    phi[2,3]  R999      -2.3671808242797852e+00
    phi[2,3]  R1000     -2.4654386043548584e+00
    phi[2,3]  R1001     -2.6650042533874512e+00
    phi[2,3]  R1002     -6.5572863817214966e-01
    phi[2,3]  R1003     -1.0876019001007080e+00
    phi[2,3]  R1004     -8.3281016349792480e-01
    phi[2,3]  R1005     -4.8660576343536377e-02
    phi[2,3]  R1006     -2.2645955085754395e+00
    phi[2,3]  R1007     -2.4355671405792236e+00
    phi[2,3]  R1008     -5.5593299865722656e-01
    phi[2,3]  R1009     3.5417163372039795e-01
    phi[2,3]  R1010     -1.7219852209091187e+00
    phi[2,3]  R1011     -0.518085777759552
    phi[2,3]  R1012     -6.5658479928970337e-01
    phi[2,3]  R1013     -1.0012665987014771e+00
    phi[2,3]  R1014     2.8327956795692444e-01
    phi[2,3]  R1015     -1.7369184494018555e+00
    phi[2,3]  R1016     -4.3511375784873962e-01
    phi[2,3]  R1017     -2.9490668773651123e+00
    phi[2,3]  R1018     -7.5623613595962524e-01
    phi[2,3]  R1019     -2.7014782428741455e+00
    phi[2,3]  R1020     2.1670703887939453e+00
    phi[2,3]  R1021     -1.6899530887603760e+00
    phi[2,3]  R1022     -0.929190993309021
    phi[2,3]  R1023     1.5262341499328613e-01
    phi[2,3]  R1024     1.1126598119735718e+00
    phi[2,3]  R1025     4.1260561347007751e-01
    phi[2,3]  R1026     8.8630992174148560e-01
    phi[2,3]  R1027     -2.1805756092071533e+00
    phi[2,3]  R1028     -1.6860339641571045e+00
    phi[2,3]  R1029     -2.9991058632731438e-02
    phi[2,3]  R1030     -2.9526617527008057e+00
    phi[2,3]  R1031     1.8182133436203003e+00
    phi[2,3]  R1032     1.7195028066635132e-01
    phi[2,3]  R1033     1.1798889636993408e+00
    phi[2,3]  R1034     -1.6767480373382568e+00
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R1035     -3.0999999046325684e+00
    phi[3,2]  R1036     -3.0999999046325684e+00
    phi[3,2]  R1037     -2.2400000095367432e+00
    phi[3,2]  R1038     -2.2400000095367432e+00
    phi[3,2]  R1039     -3.0999999046325684e+00
    phi[3,2]  R1040     -3.0999999046325684e+00
    phi[3,2]  R1041     -2.5699999332427979e+00
    phi[3,2]  R1042     -2.5699999332427979e+00
    phi[3,2]  R1043     -3.0999999046325684e+00
    phi[3,2]  R1044     -3.0999999046325684e+00
    phi[3,2]  R1045     -2.0899999141693115e+00
    phi[3,2]  R1046     -2.0899999141693115e+00
    phi[3,2]  R1047     -3.0999999046325684e+00
    phi[3,2]  R1048     -3.0999999046325684e+00
    phi[3,2]  R1049     2.6116118431091309e+00
    phi[3,2]  R1050     2.3428595066070557e+00
    phi[3,2]  R1051     1.4125819206237793e+00
    phi[3,2]  R1052     2.6769866943359375e+00
    phi[3,2]  R1053     1.9768807888031006e+00
    phi[3,2]  R1054     1.6142692565917969e+00
    phi[3,2]  R1055     1.1479370594024658e+00
    phi[3,2]  R1056     -1.8136522769927979e+00
    phi[3,2]  R1057     4.7017911076545715e-01
    phi[3,2]  R1058     -7.1002656221389771e-01
    phi[3,2]  R1059     2.4587005376815796e-01
    phi[3,2]  R1060     2.9710370302200317e-01
    phi[3,2]  R1061     -2.1677258014678955e+00
    phi[3,2]  R1062     -3.63869571685791
    phi[3,2]  R1063     -2.3671808242797852e+00
    phi[3,2]  R1064     -2.4654386043548584e+00
    phi[3,2]  R1065     -2.6650042533874512e+00
    phi[3,2]  R1066     -6.5572863817214966e-01
    phi[3,2]  R1067     -1.0876019001007080e+00
    phi[3,2]  R1068     -8.3281016349792480e-01
    phi[3,2]  R1069     -4.8660576343536377e-02
    phi[3,2]  R1070     -2.2645955085754395e+00
    phi[3,2]  R1071     -2.4355671405792236e+00
    phi[3,2]  R1072     -5.5593299865722656e-01
    phi[3,2]  R1073     3.5417163372039795e-01
    phi[3,2]  R1074     -1.7219852209091187e+00
    phi[3,2]  R1075     -0.518085777759552
    phi[3,2]  R1076     -6.5658479928970337e-01
    phi[3,2]  R1077     -1.0012665987014771e+00
    phi[3,2]  R1078     2.8327956795692444e-01
    phi[3,2]  R1079     -1.7369184494018555e+00
    phi[3,2]  R1080     -4.3511375784873962e-01
    phi[3,2]  R1081     -2.9490668773651123e+00
    phi[3,2]  R1082     -7.5623613595962524e-01
    phi[3,2]  R1083     -2.7014782428741455e+00
    phi[3,2]  R1084     2.1670703887939453e+00
    phi[3,2]  R1085     -1.6899530887603760e+00
    phi[3,2]  R1086     -0.929190993309021
    phi[3,2]  R1087     1.5262341499328613e-01
    phi[3,2]  R1088     1.1126598119735718e+00
    phi[3,2]  R1089     4.1260561347007751e-01
    phi[3,2]  R1090     8.8630992174148560e-01
    phi[3,2]  R1091     -2.1805756092071533e+00
    phi[3,2]  R1092     -1.6860339641571045e+00
    phi[3,2]  R1093     -2.9991058632731438e-02
    phi[3,2]  R1094     -2.9526617527008057e+00
    phi[3,2]  R1095     1.8182133436203003e+00
    phi[3,2]  R1096     1.7195028066635132e-01
    phi[3,2]  R1097     1.1798889636993408e+00
    phi[3,2]  R1098     -1.6767480373382568e+00
    phi[3,2]  R1099     1.4658120870590210e+00
    phi[3,2]  R1100     -5.7754196226596832e-02
    phi[3,2]  R1101     -7.9105056822299957e-02
    phi[3,2]  R1102     8.6138397455215454e-01
    phi[3,2]  R1103     1.1949729919433594e+00
    phi[3,2]  R1104     1.0626022815704346e+00
    phi[3,2]  R1105     1.3570271730422974e+00
    phi[3,2]  R1106     1.3911136388778687e+00
    phi[3,2]  R1107     6.0133183002471924e-01
    phi[3,2]  R1108     2.1430739760398865e-01
    phi[3,2]  R1109     -9.1402125358581543e-01
    phi[3,2]  R1110     7.3895761743187904e-03
    phi[3,2]  R1111     -1.1982066631317139e+00
    phi[3,2]  R1112     -1.5418968200683594e+00
    phi[3,2]  R1113     -2.1503503322601318e+00
    phi[3,2]  R1114     -1.1939885616302490e+00
    phi[3,2]  R1115     -0.574803352355957
    phi[3,2]  R1116     -9.5286267995834351e-01
    phi[3,2]  R1117     -3.2604852318763733e-01
    phi[3,2]  R1118     -8.7450706958770752e-01
    phi[3,2]  R1119     -7.6050686836242676e-01
    phi[3,2]  R1120     -0.953938901424408
    phi[3,2]  R1121     -3.3279955387115479e-01
    phi[3,2]  R1122     -7.4625766277313232e-01
    phi[3,2]  R1123     -9.4432276487350464e-01
    phi[3,2]  R1124     -0.905570924282074
    phi[3,2]  R1125     -1.2130230665206909e+00
    phi[3,2]  R1126     -1.1740211248397827e+00
    phi[3,2]  R1127     -1.4113448858261108e+00
    phi[3,2]  R1128     -1.2674739360809326e+00
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R1129     -3.0999999046325684e+00
    phi[3,4]  R1130     -3.0999999046325684e+00
    phi[3,4]  R1131     -2.2400000095367432e+00
    phi[3,4]  R1132     -2.2400000095367432e+00
    phi[3,4]  R1133     -3.0999999046325684e+00
    phi[3,4]  R1134     -3.0999999046325684e+00
    phi[3,4]  R1135     -2.5699999332427979e+00
    phi[3,4]  R1136     -2.5699999332427979e+00
    phi[3,4]  R1137     -3.0999999046325684e+00
    phi[3,4]  R1138     -3.0999999046325684e+00
    phi[3,4]  R1139     -2.0899999141693115e+00
    phi[3,4]  R1140     -2.0899999141693115e+00
    phi[3,4]  R1141     -3.0999999046325684e+00
    phi[3,4]  R1142     -3.0999999046325684e+00
    phi[3,4]  R1143     2.6116118431091309e+00
    phi[3,4]  R1144     2.3428595066070557e+00
    phi[3,4]  R1145     1.4125819206237793e+00
    phi[3,4]  R1146     2.6769866943359375e+00
    phi[3,4]  R1147     1.9768807888031006e+00
    phi[3,4]  R1148     1.6142692565917969e+00
    phi[3,4]  R1149     1.1479370594024658e+00
    phi[3,4]  R1150     -1.8136522769927979e+00
    phi[3,4]  R1151     4.7017911076545715e-01
    phi[3,4]  R1152     -7.1002656221389771e-01
    phi[3,4]  R1153     2.4587005376815796e-01
    phi[3,4]  R1154     2.9710370302200317e-01
    phi[3,4]  R1155     -2.1677258014678955e+00
    phi[3,4]  R1156     -3.63869571685791
    phi[3,4]  R1157     -2.3671808242797852e+00
    phi[3,4]  R1158     -2.4654386043548584e+00
    phi[3,4]  R1159     -2.6650042533874512e+00
    phi[3,4]  R1160     -6.5572863817214966e-01
    phi[3,4]  R1161     -1.0876019001007080e+00
    phi[3,4]  R1162     -8.3281016349792480e-01
    phi[3,4]  R1163     -4.8660576343536377e-02
    phi[3,4]  R1164     -2.2645955085754395e+00
    phi[3,4]  R1165     -2.4355671405792236e+00
    phi[3,4]  R1166     -5.5593299865722656e-01
    phi[3,4]  R1167     3.5417163372039795e-01
    phi[3,4]  R1168     -1.7219852209091187e+00
    phi[3,4]  R1169     -0.518085777759552
    phi[3,4]  R1170     -6.5658479928970337e-01
    phi[3,4]  R1171     -1.0012665987014771e+00
    phi[3,4]  R1172     2.8327956795692444e-01
    phi[3,4]  R1173     -1.7369184494018555e+00
    phi[3,4]  R1174     -4.3511375784873962e-01
    phi[3,4]  R1175     -2.9490668773651123e+00
    phi[3,4]  R1176     -7.5623613595962524e-01
    phi[3,4]  R1177     -2.7014782428741455e+00
    phi[3,4]  R1178     2.1670703887939453e+00
    phi[3,4]  R1179     -1.6899530887603760e+00
    phi[3,4]  R1180     -0.929190993309021
    phi[3,4]  R1181     1.5262341499328613e-01
    phi[3,4]  R1182     1.1126598119735718e+00
    phi[3,4]  R1183     4.1260561347007751e-01
    phi[3,4]  R1184     8.8630992174148560e-01
    phi[3,4]  R1185     -2.1805756092071533e+00
    phi[3,4]  R1186     -1.6860339641571045e+00
    phi[3,4]  R1187     -2.9991058632731438e-02
    phi[3,4]  R1188     -2.9526617527008057e+00
    phi[3,4]  R1189     1.8182133436203003e+00
    phi[3,4]  R1190     1.7195028066635132e-01
    phi[3,4]  R1191     1.1798889636993408e+00
    phi[3,4]  R1192     -1.6767480373382568e+00
    phi[3,4]  R1193     2.0504984855651855e+00
    phi[3,4]  R1194     1.4607239522954041e+00
    phi[3,4]  R1195     1.8133019208908081e+00
    phi[3,4]  R1196     2.7551195621490479e+00
    phi[3,4]  R1197     1.3843770027160645e+00
    phi[3,4]  R1198     2.7831139564514160e+00
    phi[3,4]  R1199     -1.5238615274429321e+00
    phi[3,4]  R1200     -1.4713011980056763e+00
    phi[3,4]  R1201     -1.1879136562347412e+00
    phi[3,4]  R1202     -1.2052880525588989e+00
    phi[3,4]  R1203     -1.1772027015686035e+00
    phi[3,4]  R1204     -2.5062782764434814e+00
    phi[3,4]  R1205     -1.4135143756866455e+00
    phi[3,4]  R1206     -2.4065425395965576e+00
    phi[3,4]  R1207     -1.8241934776306152e+00
    phi[3,4]  R1208     -1.9043525457382202e+00
    phi[3,4]  R1209     -1.7906099557876587e+00
    phi[3,4]  R1210     -2.6166238784790039e+00
    phi[3,4]  R1211     -1.7834196090698242e+00
    phi[3,4]  R1212     -2.5860879421234131e+00
    phi[3,4]  R1213     -1.6888539791107178e+00
    phi[3,4]  R1214     -3.3092260360717773e+00
    phi[3,4]  R1215     -3.7378447055816650e+00
    phi[3,4]  R1216     -1.6323626041412354e+00
    phi[3,4]  R1217     -3.0610327720642090e+00
    phi[3,4]  R1218     -1.9601497650146484e+00
    phi[3,4]  R1219     -1.3332855701446533e+00
    phi[3,4]  R1220     -2.46878719329834
    phi[3,4]  R1221     -8.2436317205429077e-01
    phi[3,4]  R1222     -2.5422053337097168e+00
    phi[3,4]  R1223     -2.9593608379364014e+00
    phi[3,4]  R1224     -2.4547948837280273e+00
    phi[3,4]  R1225     -3.0957715511322021e+00
    phi[3,4]  R1226     -6.2937736511230469e-01
    phi[3,4]  R1227     -2.1101157665252686e+00
    phi[3,4]  R1228     -3.2142570018768311e+00
    phi[3,4]  R1229     -2.5391712188720703e+00
    phi[3,4]  R1230     -3.8103899359703064e-01
    phi[3,4]  R1231     -5.9473669528961182e-01
    phi[3,4]  R1232     -1.9749791622161865e+00
    phi[3,4]  R1233     -2.6896078586578369e+00
    phi[3,4]  R1234     -2.4965779781341553e+00
    phi[3,4]  R1235     -2.1084840297698975e+00
    phi[3,4]  R1236     -1.3441803455352783e+00
    phi[3,4]  R1237     -1.2918095588684082e+00
    phi[3,4]  R1238     -1.0827403068542480e+00
    phi[3,4]  R1239     -1.2158010005950928e+00
    phi[3,4]  R1240     -1.4672069549560547e+00
    phi[3,4]  R1241     -3.0408098697662354e+00
    phi[3,4]  R1242     -9.9878787994384766e-01
    phi[3,4]  R1243     -1.4728426933288574e+00
    phi[3,4]  R1244     -1.1662852764129639e+00
    phi[3,4]  R1245     -1.5392550230026245e+00
    phi[3,4]  R1246     -2.3524663448333740e+00
    phi[3,4]  R1247     -2.7543728351593018e+00
    phi[3,4]  R1248     -2.4234511852264404e+00
    phi[3,4]  R1249     -1.4371293783187866e+00
    phi[3,4]  R1250     -2.6083736419677734e+00
    phi[3,4]  R1251     -1.8450063467025757e+00
    phi[3,4]  R1252     -1.5023406744003296e+00
    phi[3,4]  R1253     -1.8588010072708130e+00
    phi[3,4]  R1254     -2.5887765884399414e+00
    phi[3,4]  R1255     -2.8790297508239746e+00
    phi[3,4]  R1256     -3.5091674327850342e+00
    phi[3,4]  R1257     -3.1712961196899414e+00
    phi[3,4]  R1258     -1.4492106437683105e+00
    phi[3,4]  R1259     -2.8066310882568359e+00
    phi[3,4]  R1260     -2.8550586700439453e+00
    phi[3,4]  R1261     -9.0011346340179443e-01
    phi[3,4]  R1262     -1.8232712745666504e+00
    phi[3,4]  R1263     -4.0990343093872070e+00
    phi[3,4]  R1264     -3.2912700176239014e+00
    phi[3,4]  R1265     -3.5499916076660156e+00
    phi[3,4]  R1266     -2.0356371402740479e+00
    phi[3,4]  R1267     -1.5581924915313721e+00
    phi[3,4]  R1268     -1.7733958959579468e+00
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R1269     -3.0999999046325684e+00
    phi[4,3]  R1270     -3.0999999046325684e+00
    phi[4,3]  R1271     -2.2400000095367432e+00
    phi[4,3]  R1272     -2.2400000095367432e+00
    phi[4,3]  R1273     -3.0999999046325684e+00
    phi[4,3]  R1274     -3.0999999046325684e+00
    phi[4,3]  R1275     -2.5699999332427979e+00
    phi[4,3]  R1276     -2.5699999332427979e+00
    phi[4,3]  R1277     -3.0999999046325684e+00
    phi[4,3]  R1278     -3.0999999046325684e+00
    phi[4,3]  R1279     -2.0899999141693115e+00
    phi[4,3]  R1280     -2.0899999141693115e+00
    phi[4,3]  R1281     -3.0999999046325684e+00
    phi[4,3]  R1282     -3.0999999046325684e+00
    phi[4,3]  R1283     2.0504984855651855e+00
    phi[4,3]  R1284     1.4607239522954041e+00
    phi[4,3]  R1285     1.8133019208908081e+00
    phi[4,3]  R1286     2.7551195621490479e+00
    phi[4,3]  R1287     1.3843770027160645e+00
    phi[4,3]  R1288     2.7831139564514160e+00
    phi[4,3]  R1289     -1.5238615274429321e+00
    phi[4,3]  R1290     -1.4713011980056763e+00
    phi[4,3]  R1291     -1.1879136562347412e+00
    phi[4,3]  R1292     -1.2052880525588989e+00
    phi[4,3]  R1293     -1.1772027015686035e+00
    phi[4,3]  R1294     -2.5062782764434814e+00
    phi[4,3]  R1295     -1.4135143756866455e+00
    phi[4,3]  R1296     -2.4065425395965576e+00
    phi[4,3]  R1297     -1.8241934776306152e+00
    phi[4,3]  R1298     -1.9043525457382202e+00
    phi[4,3]  R1299     -1.7906099557876587e+00
    phi[4,3]  R1300     -2.6166238784790039e+00
    phi[4,3]  R1301     -1.7834196090698242e+00
    phi[4,3]  R1302     -2.5860879421234131e+00
    phi[4,3]  R1303     -1.6888539791107178e+00
    phi[4,3]  R1304     -3.3092260360717773e+00
    phi[4,3]  R1305     -3.7378447055816650e+00
    phi[4,3]  R1306     -1.6323626041412354e+00
    phi[4,3]  R1307     -3.0610327720642090e+00
    phi[4,3]  R1308     -1.9601497650146484e+00
    phi[4,3]  R1309     -1.3332855701446533e+00
    phi[4,3]  R1310     -2.46878719329834
    phi[4,3]  R1311     -8.2436317205429077e-01
    phi[4,3]  R1312     -2.5422053337097168e+00
    phi[4,3]  R1313     -2.9593608379364014e+00
    phi[4,3]  R1314     -2.4547948837280273e+00
    phi[4,3]  R1315     -3.0957715511322021e+00
    phi[4,3]  R1316     -6.2937736511230469e-01
    phi[4,3]  R1317     -2.1101157665252686e+00
    phi[4,3]  R1318     -3.2142570018768311e+00
    phi[4,3]  R1319     -2.5391712188720703e+00
    phi[4,3]  R1320     -3.8103899359703064e-01
    phi[4,3]  R1321     -5.9473669528961182e-01
    phi[4,3]  R1322     -1.9749791622161865e+00
    phi[4,3]  R1323     -2.6896078586578369e+00
    phi[4,3]  R1324     -2.4965779781341553e+00
    phi[4,3]  R1325     -2.1084840297698975e+00
    phi[4,3]  R1326     -1.3441803455352783e+00
    phi[4,3]  R1327     -1.2918095588684082e+00
    phi[4,3]  R1328     -1.0827403068542480e+00
    phi[4,3]  R1329     -1.2158010005950928e+00
    phi[4,3]  R1330     -1.4672069549560547e+00
    phi[4,3]  R1331     -3.0408098697662354e+00
    phi[4,3]  R1332     -9.9878787994384766e-01
    phi[4,3]  R1333     -1.4728426933288574e+00
    phi[4,3]  R1334     -1.1662852764129639e+00
    phi[4,3]  R1335     -1.5392550230026245e+00
    phi[4,3]  R1336     -2.3524663448333740e+00
    phi[4,3]  R1337     -2.7543728351593018e+00
    phi[4,3]  R1338     -2.4234511852264404e+00
    phi[4,3]  R1339     -1.4371293783187866e+00
    phi[4,3]  R1340     -2.6083736419677734e+00
    phi[4,3]  R1341     -1.8450063467025757e+00
    phi[4,3]  R1342     -1.5023406744003296e+00
    phi[4,3]  R1343     -1.8588010072708130e+00
    phi[4,3]  R1344     -2.5887765884399414e+00
    phi[4,3]  R1345     -2.8790297508239746e+00
    phi[4,3]  R1346     -3.5091674327850342e+00
    phi[4,3]  R1347     -3.1712961196899414e+00
    phi[4,3]  R1348     -1.4492106437683105e+00
    phi[4,3]  R1349     -2.8066310882568359e+00
    phi[4,3]  R1350     -2.8550586700439453e+00
    phi[4,3]  R1351     -9.0011346340179443e-01
    phi[4,3]  R1352     -1.8232712745666504e+00
    phi[4,3]  R1353     -4.0990343093872070e+00
    phi[4,3]  R1354     -3.2912700176239014e+00
    phi[4,3]  R1355     -3.5499916076660156e+00
    phi[4,3]  R1356     -2.0356371402740479e+00
    phi[4,3]  R1357     -1.5581924915313721e+00
    phi[4,3]  R1358     -1.7733958959579468e+00
    phi[4,3]  R1359     2.6116118431091309e+00
    phi[4,3]  R1360     2.3428595066070557e+00
    phi[4,3]  R1361     1.4125819206237793e+00
    phi[4,3]  R1362     2.6769866943359375e+00
    phi[4,3]  R1363     1.9768807888031006e+00
    phi[4,3]  R1364     1.6142692565917969e+00
    phi[4,3]  R1365     1.1479370594024658e+00
    phi[4,3]  R1366     -1.8136522769927979e+00
    phi[4,3]  R1367     4.7017911076545715e-01
    phi[4,3]  R1368     -7.1002656221389771e-01
    phi[4,3]  R1369     2.4587005376815796e-01
    phi[4,3]  R1370     2.9710370302200317e-01
    phi[4,3]  R1371     -2.1677258014678955e+00
    phi[4,3]  R1372     -3.63869571685791
    phi[4,3]  R1373     -2.3671808242797852e+00
    phi[4,3]  R1374     -2.4654386043548584e+00
    phi[4,3]  R1375     -2.6650042533874512e+00
    phi[4,3]  R1376     -6.5572863817214966e-01
    phi[4,3]  R1377     -1.0876019001007080e+00
    phi[4,3]  R1378     -8.3281016349792480e-01
    phi[4,3]  R1379     -4.8660576343536377e-02
    phi[4,3]  R1380     -2.2645955085754395e+00
    phi[4,3]  R1381     -2.4355671405792236e+00
    phi[4,3]  R1382     -5.5593299865722656e-01
    phi[4,3]  R1383     3.5417163372039795e-01
    phi[4,3]  R1384     -1.7219852209091187e+00
    phi[4,3]  R1385     -0.518085777759552
    phi[4,3]  R1386     -6.5658479928970337e-01
    phi[4,3]  R1387     -1.0012665987014771e+00
    phi[4,3]  R1388     2.8327956795692444e-01
    phi[4,3]  R1389     -1.7369184494018555e+00
    phi[4,3]  R1390     -4.3511375784873962e-01
    phi[4,3]  R1391     -2.9490668773651123e+00
    phi[4,3]  R1392     -7.5623613595962524e-01
    phi[4,3]  R1393     -2.7014782428741455e+00
    phi[4,3]  R1394     2.1670703887939453e+00
    phi[4,3]  R1395     -1.6899530887603760e+00
    phi[4,3]  R1396     -0.929190993309021
    phi[4,3]  R1397     1.5262341499328613e-01
    phi[4,3]  R1398     1.1126598119735718e+00
    phi[4,3]  R1399     4.1260561347007751e-01
    phi[4,3]  R1400     8.8630992174148560e-01
    phi[4,3]  R1401     -2.1805756092071533e+00
    phi[4,3]  R1402     -1.6860339641571045e+00
    phi[4,3]  R1403     -2.9991058632731438e-02
    phi[4,3]  R1404     -2.9526617527008057e+00
    phi[4,3]  R1405     1.8182133436203003e+00
    phi[4,3]  R1406     1.7195028066635132e-01
    phi[4,3]  R1407     1.1798889636993408e+00
    phi[4,3]  R1408     -1.6767480373382568e+00
    phi[3,8]  R27       1
    phi[3,8]  R28       1
    phi[3,8]  R72       -1
    phi[3,8]  R1409     -3.0999999046325684e+00
    phi[3,8]  R1410     -3.0999999046325684e+00
    phi[3,8]  R1411     -2.2400000095367432e+00
    phi[3,8]  R1412     -2.2400000095367432e+00
    phi[3,8]  R1413     -3.0999999046325684e+00
    phi[3,8]  R1414     -3.0999999046325684e+00
    phi[3,8]  R1415     -2.5699999332427979e+00
    phi[3,8]  R1416     -2.5699999332427979e+00
    phi[3,8]  R1417     -3.0999999046325684e+00
    phi[3,8]  R1418     -3.0999999046325684e+00
    phi[3,8]  R1419     -2.0899999141693115e+00
    phi[3,8]  R1420     -2.0899999141693115e+00
    phi[3,8]  R1421     -3.0999999046325684e+00
    phi[3,8]  R1422     -3.0999999046325684e+00
    phi[3,8]  R1423     2.6116118431091309e+00
    phi[3,8]  R1424     2.3428595066070557e+00
    phi[3,8]  R1425     1.4125819206237793e+00
    phi[3,8]  R1426     2.6769866943359375e+00
    phi[3,8]  R1427     1.9768807888031006e+00
    phi[3,8]  R1428     1.6142692565917969e+00
    phi[3,8]  R1429     1.1479370594024658e+00
    phi[3,8]  R1430     -1.8136522769927979e+00
    phi[3,8]  R1431     4.7017911076545715e-01
    phi[3,8]  R1432     -7.1002656221389771e-01
    phi[3,8]  R1433     2.4587005376815796e-01
    phi[3,8]  R1434     2.9710370302200317e-01
    phi[3,8]  R1435     -2.1677258014678955e+00
    phi[3,8]  R1436     -3.63869571685791
    phi[3,8]  R1437     -2.3671808242797852e+00
    phi[3,8]  R1438     -2.4654386043548584e+00
    phi[3,8]  R1439     -2.6650042533874512e+00
    phi[3,8]  R1440     -6.5572863817214966e-01
    phi[3,8]  R1441     -1.0876019001007080e+00
    phi[3,8]  R1442     -8.3281016349792480e-01
    phi[3,8]  R1443     -4.8660576343536377e-02
    phi[3,8]  R1444     -2.2645955085754395e+00
    phi[3,8]  R1445     -2.4355671405792236e+00
    phi[3,8]  R1446     -5.5593299865722656e-01
    phi[3,8]  R1447     3.5417163372039795e-01
    phi[3,8]  R1448     -1.7219852209091187e+00
    phi[3,8]  R1449     -0.518085777759552
    phi[3,8]  R1450     -6.5658479928970337e-01
    phi[3,8]  R1451     -1.0012665987014771e+00
    phi[3,8]  R1452     2.8327956795692444e-01
    phi[3,8]  R1453     -1.7369184494018555e+00
    phi[3,8]  R1454     -4.3511375784873962e-01
    phi[3,8]  R1455     -2.9490668773651123e+00
    phi[3,8]  R1456     -7.5623613595962524e-01
    phi[3,8]  R1457     -2.7014782428741455e+00
    phi[3,8]  R1458     2.1670703887939453e+00
    phi[3,8]  R1459     -1.6899530887603760e+00
    phi[3,8]  R1460     -0.929190993309021
    phi[3,8]  R1461     1.5262341499328613e-01
    phi[3,8]  R1462     1.1126598119735718e+00
    phi[3,8]  R1463     4.1260561347007751e-01
    phi[3,8]  R1464     8.8630992174148560e-01
    phi[3,8]  R1465     -2.1805756092071533e+00
    phi[3,8]  R1466     -1.6860339641571045e+00
    phi[3,8]  R1467     -2.9991058632731438e-02
    phi[3,8]  R1468     -2.9526617527008057e+00
    phi[3,8]  R1469     1.8182133436203003e+00
    phi[3,8]  R1470     1.7195028066635132e-01
    phi[3,8]  R1471     1.1798889636993408e+00
    phi[3,8]  R1472     -1.6767480373382568e+00
    phi[3,8]  R1473     0.682270048509034
    phi[3,8]  R1474     1.6301953792572021e+00
    phi[3,8]  R1475     2.4280086408212940e+00
    phi[3,8]  R1476     1.85371732711792
    phi[3,8]  R1477     8.3064395189285278e-01
    phi[3,8]  R1478     -1.6890417337417603e+00
    phi[3,8]  R1479     1.6244244575500488e+00
    phi[3,8]  R1480     1.3833212852478027e-01
    phi[3,8]  R1481     -1.2938052415847778e+00
    phi[3,8]  R1482     4.7077560424804688e-01
    phi[3,8]  R1483     -2.5367214679718018e+00
    phi[3,8]  R1484     -3.5966901779174805e+00
    phi[3,8]  R1485     -2.6237609386444092e+00
    phi[3,8]  R1486     -3.1710565090179443e+00
    phi[3,8]  R1487     -2.1854300498962402e+00
    phi[3,8]  R1488     -2.4231557846069336e+00
    phi[3,8]  R1489     -2.6395745277404785e+00
    phi[3,8]  R1490     -5.8699674904346466e-02
    phi[3,8]  R1491     -2.2481372356414795e+00
    phi[3,8]  R1492     -1.4937937259674072e+00
    phi[3,8]  R1493     -1.3759787082672119e+00
    phi[3,8]  R1494     -4.7226530313491821e-01
    phi[3,8]  R1495     -1.9111098051071167e+00
    phi[3,8]  R1496     -2.4730424880981445e+00
    phi[3,8]  R1497     -2.4188549518585205e+00
    phi[3,8]  R1498     -2.8335824012756348e+00
    phi[3,8]  R1499     -2.4559917449951172e+00
    phi[3,8]  R1500     -2.1814482212066650e+00
    phi[3,8]  R1501     -2.8965513706207275e+00
    phi[3,8]  R1502     -2.5799529552459717e+00
    phi[3,8]  R1503     -1.5517382621765137e+00
    phi[3,8]  R1504     -2.2106435298919678e+00
    phi[3,8]  R1505     -2.5730376243591309e+00
    phi[3,8]  R1506     -9.8869937658309937e-01
    phi[3,8]  R1507     -1.5317547321319580e+00
    phi[3,8]  R1508     -1.7015953063964844e+00
    phi[3,8]  R1509     -2.0936355590820312e+00
    phi[3,8]  R1510     -2.0742316246032715e+00
    phi[3,8]  R1511     -1.1329267024993896e+00
    phi[8,3]  R27       -1
    phi[8,3]  R72       1
    phi[8,3]  R73       1
    phi[8,3]  R1512     -3.0999999046325684e+00
    phi[8,3]  R1513     -3.0999999046325684e+00
    phi[8,3]  R1514     -2.2400000095367432e+00
    phi[8,3]  R1515     -2.2400000095367432e+00
    phi[8,3]  R1516     -3.0999999046325684e+00
    phi[8,3]  R1517     -3.0999999046325684e+00
    phi[8,3]  R1518     -2.5699999332427979e+00
    phi[8,3]  R1519     -2.5699999332427979e+00
    phi[8,3]  R1520     -3.0999999046325684e+00
    phi[8,3]  R1521     -3.0999999046325684e+00
    phi[8,3]  R1522     -2.0899999141693115e+00
    phi[8,3]  R1523     -2.0899999141693115e+00
    phi[8,3]  R1524     -3.0999999046325684e+00
    phi[8,3]  R1525     -3.0999999046325684e+00
    phi[8,3]  R1526     0.682270048509034
    phi[8,3]  R1527     1.6301953792572021e+00
    phi[8,3]  R1528     2.4280086408212940e+00
    phi[8,3]  R1529     1.85371732711792
    phi[8,3]  R1530     8.3064395189285278e-01
    phi[8,3]  R1531     -1.6890417337417603e+00
    phi[8,3]  R1532     1.6244244575500488e+00
    phi[8,3]  R1533     1.3833212852478027e-01
    phi[8,3]  R1534     -1.2938052415847778e+00
    phi[8,3]  R1535     4.7077560424804688e-01
    phi[8,3]  R1536     -2.5367214679718018e+00
    phi[8,3]  R1537     -3.5966901779174805e+00
    phi[8,3]  R1538     -2.6237609386444092e+00
    phi[8,3]  R1539     -3.1710565090179443e+00
    phi[8,3]  R1540     -2.1854300498962402e+00
    phi[8,3]  R1541     -2.4231557846069336e+00
    phi[8,3]  R1542     -2.6395745277404785e+00
    phi[8,3]  R1543     -5.8699674904346466e-02
    phi[8,3]  R1544     -2.2481372356414795e+00
    phi[8,3]  R1545     -1.4937937259674072e+00
    phi[8,3]  R1546     -1.3759787082672119e+00
    phi[8,3]  R1547     -4.7226530313491821e-01
    phi[8,3]  R1548     -1.9111098051071167e+00
    phi[8,3]  R1549     -2.4730424880981445e+00
    phi[8,3]  R1550     -2.4188549518585205e+00
    phi[8,3]  R1551     -2.8335824012756348e+00
    phi[8,3]  R1552     -2.4559917449951172e+00
    phi[8,3]  R1553     -2.1814482212066650e+00
    phi[8,3]  R1554     -2.8965513706207275e+00
    phi[8,3]  R1555     -2.5799529552459717e+00
    phi[8,3]  R1556     -1.5517382621765137e+00
    phi[8,3]  R1557     -2.2106435298919678e+00
    phi[8,3]  R1558     -2.5730376243591309e+00
    phi[8,3]  R1559     -9.8869937658309937e-01
    phi[8,3]  R1560     -1.5317547321319580e+00
    phi[8,3]  R1561     -1.7015953063964844e+00
    phi[8,3]  R1562     -2.0936355590820312e+00
    phi[8,3]  R1563     -2.0742316246032715e+00
    phi[8,3]  R1564     -1.1329267024993896e+00
    phi[8,3]  R1565     2.6116118431091309e+00
    phi[8,3]  R1566     2.3428595066070557e+00
    phi[8,3]  R1567     1.4125819206237793e+00
    phi[8,3]  R1568     2.6769866943359375e+00
    phi[8,3]  R1569     1.9768807888031006e+00
    phi[8,3]  R1570     1.6142692565917969e+00
    phi[8,3]  R1571     1.1479370594024658e+00
    phi[8,3]  R1572     -1.8136522769927979e+00
    phi[8,3]  R1573     4.7017911076545715e-01
    phi[8,3]  R1574     -7.1002656221389771e-01
    phi[8,3]  R1575     2.4587005376815796e-01
    phi[8,3]  R1576     2.9710370302200317e-01
    phi[8,3]  R1577     -2.1677258014678955e+00
    phi[8,3]  R1578     -3.63869571685791
    phi[8,3]  R1579     -2.3671808242797852e+00
    phi[8,3]  R1580     -2.4654386043548584e+00
    phi[8,3]  R1581     -2.6650042533874512e+00
    phi[8,3]  R1582     -6.5572863817214966e-01
    phi[8,3]  R1583     -1.0876019001007080e+00
    phi[8,3]  R1584     -8.3281016349792480e-01
    phi[8,3]  R1585     -4.8660576343536377e-02
    phi[8,3]  R1586     -2.2645955085754395e+00
    phi[8,3]  R1587     -2.4355671405792236e+00
    phi[8,3]  R1588     -5.5593299865722656e-01
    phi[8,3]  R1589     3.5417163372039795e-01
    phi[8,3]  R1590     -1.7219852209091187e+00
    phi[8,3]  R1591     -0.518085777759552
    phi[8,3]  R1592     -6.5658479928970337e-01
    phi[8,3]  R1593     -1.0012665987014771e+00
    phi[8,3]  R1594     2.8327956795692444e-01
    phi[8,3]  R1595     -1.7369184494018555e+00
    phi[8,3]  R1596     -4.3511375784873962e-01
    phi[8,3]  R1597     -2.9490668773651123e+00
    phi[8,3]  R1598     -7.5623613595962524e-01
    phi[8,3]  R1599     -2.7014782428741455e+00
    phi[8,3]  R1600     2.1670703887939453e+00
    phi[8,3]  R1601     -1.6899530887603760e+00
    phi[8,3]  R1602     -0.929190993309021
    phi[8,3]  R1603     1.5262341499328613e-01
    phi[8,3]  R1604     1.1126598119735718e+00
    phi[8,3]  R1605     4.1260561347007751e-01
    phi[8,3]  R1606     8.8630992174148560e-01
    phi[8,3]  R1607     -2.1805756092071533e+00
    phi[8,3]  R1608     -1.6860339641571045e+00
    phi[8,3]  R1609     -2.9991058632731438e-02
    phi[8,3]  R1610     -2.9526617527008057e+00
    phi[8,3]  R1611     1.8182133436203003e+00
    phi[8,3]  R1612     1.7195028066635132e-01
    phi[8,3]  R1613     1.1798889636993408e+00
    phi[8,3]  R1614     -1.6767480373382568e+00
    phi[4,8]  R36       1
    phi[4,8]  R37       1
    phi[4,8]  R72       -1
    phi[4,8]  R1615     -3.0999999046325684e+00
    phi[4,8]  R1616     -3.0999999046325684e+00
    phi[4,8]  R1617     -2.2400000095367432e+00
    phi[4,8]  R1618     -2.2400000095367432e+00
    phi[4,8]  R1619     -3.0999999046325684e+00
    phi[4,8]  R1620     -3.0999999046325684e+00
    phi[4,8]  R1621     -2.5699999332427979e+00
    phi[4,8]  R1622     -2.5699999332427979e+00
    phi[4,8]  R1623     -3.0999999046325684e+00
    phi[4,8]  R1624     -3.0999999046325684e+00
    phi[4,8]  R1625     -2.0899999141693115e+00
    phi[4,8]  R1626     -2.0899999141693115e+00
    phi[4,8]  R1627     -3.0999999046325684e+00
    phi[4,8]  R1628     -3.0999999046325684e+00
    phi[4,8]  R1629     2.0504984855651855e+00
    phi[4,8]  R1630     1.4607239522954041e+00
    phi[4,8]  R1631     1.8133019208908081e+00
    phi[4,8]  R1632     2.7551195621490479e+00
    phi[4,8]  R1633     1.3843770027160645e+00
    phi[4,8]  R1634     2.7831139564514160e+00
    phi[4,8]  R1635     -1.5238615274429321e+00
    phi[4,8]  R1636     -1.4713011980056763e+00
    phi[4,8]  R1637     -1.1879136562347412e+00
    phi[4,8]  R1638     -1.2052880525588989e+00
    phi[4,8]  R1639     -1.1772027015686035e+00
    phi[4,8]  R1640     -2.5062782764434814e+00
    phi[4,8]  R1641     -1.4135143756866455e+00
    phi[4,8]  R1642     -2.4065425395965576e+00
    phi[4,8]  R1643     -1.8241934776306152e+00
    phi[4,8]  R1644     -1.9043525457382202e+00
    phi[4,8]  R1645     -1.7906099557876587e+00
    phi[4,8]  R1646     -2.6166238784790039e+00
    phi[4,8]  R1647     -1.7834196090698242e+00
    phi[4,8]  R1648     -2.5860879421234131e+00
    phi[4,8]  R1649     -1.6888539791107178e+00
    phi[4,8]  R1650     -3.3092260360717773e+00
    phi[4,8]  R1651     -3.7378447055816650e+00
    phi[4,8]  R1652     -1.6323626041412354e+00
    phi[4,8]  R1653     -3.0610327720642090e+00
    phi[4,8]  R1654     -1.9601497650146484e+00
    phi[4,8]  R1655     -1.3332855701446533e+00
    phi[4,8]  R1656     -2.46878719329834
    phi[4,8]  R1657     -8.2436317205429077e-01
    phi[4,8]  R1658     -2.5422053337097168e+00
    phi[4,8]  R1659     -2.9593608379364014e+00
    phi[4,8]  R1660     -2.4547948837280273e+00
    phi[4,8]  R1661     -3.0957715511322021e+00
    phi[4,8]  R1662     -6.2937736511230469e-01
    phi[4,8]  R1663     -2.1101157665252686e+00
    phi[4,8]  R1664     -3.2142570018768311e+00
    phi[4,8]  R1665     -2.5391712188720703e+00
    phi[4,8]  R1666     -3.8103899359703064e-01
    phi[4,8]  R1667     -5.9473669528961182e-01
    phi[4,8]  R1668     -1.9749791622161865e+00
    phi[4,8]  R1669     -2.6896078586578369e+00
    phi[4,8]  R1670     -2.4965779781341553e+00
    phi[4,8]  R1671     -2.1084840297698975e+00
    phi[4,8]  R1672     -1.3441803455352783e+00
    phi[4,8]  R1673     -1.2918095588684082e+00
    phi[4,8]  R1674     -1.0827403068542480e+00
    phi[4,8]  R1675     -1.2158010005950928e+00
    phi[4,8]  R1676     -1.4672069549560547e+00
    phi[4,8]  R1677     -3.0408098697662354e+00
    phi[4,8]  R1678     -9.9878787994384766e-01
    phi[4,8]  R1679     -1.4728426933288574e+00
    phi[4,8]  R1680     -1.1662852764129639e+00
    phi[4,8]  R1681     -1.5392550230026245e+00
    phi[4,8]  R1682     -2.3524663448333740e+00
    phi[4,8]  R1683     -2.7543728351593018e+00
    phi[4,8]  R1684     -2.4234511852264404e+00
    phi[4,8]  R1685     -1.4371293783187866e+00
    phi[4,8]  R1686     -2.6083736419677734e+00
    phi[4,8]  R1687     -1.8450063467025757e+00
    phi[4,8]  R1688     -1.5023406744003296e+00
    phi[4,8]  R1689     -1.8588010072708130e+00
    phi[4,8]  R1690     -2.5887765884399414e+00
    phi[4,8]  R1691     -2.8790297508239746e+00
    phi[4,8]  R1692     -3.5091674327850342e+00
    phi[4,8]  R1693     -3.1712961196899414e+00
    phi[4,8]  R1694     -1.4492106437683105e+00
    phi[4,8]  R1695     -2.8066310882568359e+00
    phi[4,8]  R1696     -2.8550586700439453e+00
    phi[4,8]  R1697     -9.0011346340179443e-01
    phi[4,8]  R1698     -1.8232712745666504e+00
    phi[4,8]  R1699     -4.0990343093872070e+00
    phi[4,8]  R1700     -3.2912700176239014e+00
    phi[4,8]  R1701     -3.5499916076660156e+00
    phi[4,8]  R1702     -2.0356371402740479e+00
    phi[4,8]  R1703     -1.5581924915313721e+00
    phi[4,8]  R1704     -1.7733958959579468e+00
    phi[4,8]  R1705     0.682270048509034
    phi[4,8]  R1706     1.6301953792572021e+00
    phi[4,8]  R1707     2.4280086408212940e+00
    phi[4,8]  R1708     1.85371732711792
    phi[4,8]  R1709     8.3064395189285278e-01
    phi[4,8]  R1710     -1.6890417337417603e+00
    phi[4,8]  R1711     1.6244244575500488e+00
    phi[4,8]  R1712     1.3833212852478027e-01
    phi[4,8]  R1713     -1.2938052415847778e+00
    phi[4,8]  R1714     4.7077560424804688e-01
    phi[4,8]  R1715     -2.5367214679718018e+00
    phi[4,8]  R1716     -3.5966901779174805e+00
    phi[4,8]  R1717     -2.6237609386444092e+00
    phi[4,8]  R1718     -3.1710565090179443e+00
    phi[4,8]  R1719     -2.1854300498962402e+00
    phi[4,8]  R1720     -2.4231557846069336e+00
    phi[4,8]  R1721     -2.6395745277404785e+00
    phi[4,8]  R1722     -5.8699674904346466e-02
    phi[4,8]  R1723     -2.2481372356414795e+00
    phi[4,8]  R1724     -1.4937937259674072e+00
    phi[4,8]  R1725     -1.3759787082672119e+00
    phi[4,8]  R1726     -4.7226530313491821e-01
    phi[4,8]  R1727     -1.9111098051071167e+00
    phi[4,8]  R1728     -2.4730424880981445e+00
    phi[4,8]  R1729     -2.4188549518585205e+00
    phi[4,8]  R1730     -2.8335824012756348e+00
    phi[4,8]  R1731     -2.4559917449951172e+00
    phi[4,8]  R1732     -2.1814482212066650e+00
    phi[4,8]  R1733     -2.8965513706207275e+00
    phi[4,8]  R1734     -2.5799529552459717e+00
    phi[4,8]  R1735     -1.5517382621765137e+00
    phi[4,8]  R1736     -2.2106435298919678e+00
    phi[4,8]  R1737     -2.5730376243591309e+00
    phi[4,8]  R1738     -9.8869937658309937e-01
    phi[4,8]  R1739     -1.5317547321319580e+00
    phi[4,8]  R1740     -1.7015953063964844e+00
    phi[4,8]  R1741     -2.0936355590820312e+00
    phi[4,8]  R1742     -2.0742316246032715e+00
    phi[4,8]  R1743     -1.1329267024993896e+00
    phi[8,4]  R36       -1
    phi[8,4]  R72       1
    phi[8,4]  R73       1
    phi[8,4]  R1744     -3.0999999046325684e+00
    phi[8,4]  R1745     -3.0999999046325684e+00
    phi[8,4]  R1746     -2.2400000095367432e+00
    phi[8,4]  R1747     -2.2400000095367432e+00
    phi[8,4]  R1748     -3.0999999046325684e+00
    phi[8,4]  R1749     -3.0999999046325684e+00
    phi[8,4]  R1750     -2.5699999332427979e+00
    phi[8,4]  R1751     -2.5699999332427979e+00
    phi[8,4]  R1752     -3.0999999046325684e+00
    phi[8,4]  R1753     -3.0999999046325684e+00
    phi[8,4]  R1754     -2.0899999141693115e+00
    phi[8,4]  R1755     -2.0899999141693115e+00
    phi[8,4]  R1756     -3.0999999046325684e+00
    phi[8,4]  R1757     -3.0999999046325684e+00
    phi[8,4]  R1758     0.682270048509034
    phi[8,4]  R1759     1.6301953792572021e+00
    phi[8,4]  R1760     2.4280086408212940e+00
    phi[8,4]  R1761     1.85371732711792
    phi[8,4]  R1762     8.3064395189285278e-01
    phi[8,4]  R1763     -1.6890417337417603e+00
    phi[8,4]  R1764     1.6244244575500488e+00
    phi[8,4]  R1765     1.3833212852478027e-01
    phi[8,4]  R1766     -1.2938052415847778e+00
    phi[8,4]  R1767     4.7077560424804688e-01
    phi[8,4]  R1768     -2.5367214679718018e+00
    phi[8,4]  R1769     -3.5966901779174805e+00
    phi[8,4]  R1770     -2.6237609386444092e+00
    phi[8,4]  R1771     -3.1710565090179443e+00
    phi[8,4]  R1772     -2.1854300498962402e+00
    phi[8,4]  R1773     -2.4231557846069336e+00
    phi[8,4]  R1774     -2.6395745277404785e+00
    phi[8,4]  R1775     -5.8699674904346466e-02
    phi[8,4]  R1776     -2.2481372356414795e+00
    phi[8,4]  R1777     -1.4937937259674072e+00
    phi[8,4]  R1778     -1.3759787082672119e+00
    phi[8,4]  R1779     -4.7226530313491821e-01
    phi[8,4]  R1780     -1.9111098051071167e+00
    phi[8,4]  R1781     -2.4730424880981445e+00
    phi[8,4]  R1782     -2.4188549518585205e+00
    phi[8,4]  R1783     -2.8335824012756348e+00
    phi[8,4]  R1784     -2.4559917449951172e+00
    phi[8,4]  R1785     -2.1814482212066650e+00
    phi[8,4]  R1786     -2.8965513706207275e+00
    phi[8,4]  R1787     -2.5799529552459717e+00
    phi[8,4]  R1788     -1.5517382621765137e+00
    phi[8,4]  R1789     -2.2106435298919678e+00
    phi[8,4]  R1790     -2.5730376243591309e+00
    phi[8,4]  R1791     -9.8869937658309937e-01
    phi[8,4]  R1792     -1.5317547321319580e+00
    phi[8,4]  R1793     -1.7015953063964844e+00
    phi[8,4]  R1794     -2.0936355590820312e+00
    phi[8,4]  R1795     -2.0742316246032715e+00
    phi[8,4]  R1796     -1.1329267024993896e+00
    phi[8,4]  R1797     2.0504984855651855e+00
    phi[8,4]  R1798     1.4607239522954041e+00
    phi[8,4]  R1799     1.8133019208908081e+00
    phi[8,4]  R1800     2.7551195621490479e+00
    phi[8,4]  R1801     1.3843770027160645e+00
    phi[8,4]  R1802     2.7831139564514160e+00
    phi[8,4]  R1803     -1.5238615274429321e+00
    phi[8,4]  R1804     -1.4713011980056763e+00
    phi[8,4]  R1805     -1.1879136562347412e+00
    phi[8,4]  R1806     -1.2052880525588989e+00
    phi[8,4]  R1807     -1.1772027015686035e+00
    phi[8,4]  R1808     -2.5062782764434814e+00
    phi[8,4]  R1809     -1.4135143756866455e+00
    phi[8,4]  R1810     -2.4065425395965576e+00
    phi[8,4]  R1811     -1.8241934776306152e+00
    phi[8,4]  R1812     -1.9043525457382202e+00
    phi[8,4]  R1813     -1.7906099557876587e+00
    phi[8,4]  R1814     -2.6166238784790039e+00
    phi[8,4]  R1815     -1.7834196090698242e+00
    phi[8,4]  R1816     -2.5860879421234131e+00
    phi[8,4]  R1817     -1.6888539791107178e+00
    phi[8,4]  R1818     -3.3092260360717773e+00
    phi[8,4]  R1819     -3.7378447055816650e+00
    phi[8,4]  R1820     -1.6323626041412354e+00
    phi[8,4]  R1821     -3.0610327720642090e+00
    phi[8,4]  R1822     -1.9601497650146484e+00
    phi[8,4]  R1823     -1.3332855701446533e+00
    phi[8,4]  R1824     -2.46878719329834
    phi[8,4]  R1825     -8.2436317205429077e-01
    phi[8,4]  R1826     -2.5422053337097168e+00
    phi[8,4]  R1827     -2.9593608379364014e+00
    phi[8,4]  R1828     -2.4547948837280273e+00
    phi[8,4]  R1829     -3.0957715511322021e+00
    phi[8,4]  R1830     -6.2937736511230469e-01
    phi[8,4]  R1831     -2.1101157665252686e+00
    phi[8,4]  R1832     -3.2142570018768311e+00
    phi[8,4]  R1833     -2.5391712188720703e+00
    phi[8,4]  R1834     -3.8103899359703064e-01
    phi[8,4]  R1835     -5.9473669528961182e-01
    phi[8,4]  R1836     -1.9749791622161865e+00
    phi[8,4]  R1837     -2.6896078586578369e+00
    phi[8,4]  R1838     -2.4965779781341553e+00
    phi[8,4]  R1839     -2.1084840297698975e+00
    phi[8,4]  R1840     -1.3441803455352783e+00
    phi[8,4]  R1841     -1.2918095588684082e+00
    phi[8,4]  R1842     -1.0827403068542480e+00
    phi[8,4]  R1843     -1.2158010005950928e+00
    phi[8,4]  R1844     -1.4672069549560547e+00
    phi[8,4]  R1845     -3.0408098697662354e+00
    phi[8,4]  R1846     -9.9878787994384766e-01
    phi[8,4]  R1847     -1.4728426933288574e+00
    phi[8,4]  R1848     -1.1662852764129639e+00
    phi[8,4]  R1849     -1.5392550230026245e+00
    phi[8,4]  R1850     -2.3524663448333740e+00
    phi[8,4]  R1851     -2.7543728351593018e+00
    phi[8,4]  R1852     -2.4234511852264404e+00
    phi[8,4]  R1853     -1.4371293783187866e+00
    phi[8,4]  R1854     -2.6083736419677734e+00
    phi[8,4]  R1855     -1.8450063467025757e+00
    phi[8,4]  R1856     -1.5023406744003296e+00
    phi[8,4]  R1857     -1.8588010072708130e+00
    phi[8,4]  R1858     -2.5887765884399414e+00
    phi[8,4]  R1859     -2.8790297508239746e+00
    phi[8,4]  R1860     -3.5091674327850342e+00
    phi[8,4]  R1861     -3.1712961196899414e+00
    phi[8,4]  R1862     -1.4492106437683105e+00
    phi[8,4]  R1863     -2.8066310882568359e+00
    phi[8,4]  R1864     -2.8550586700439453e+00
    phi[8,4]  R1865     -9.0011346340179443e-01
    phi[8,4]  R1866     -1.8232712745666504e+00
    phi[8,4]  R1867     -4.0990343093872070e+00
    phi[8,4]  R1868     -3.2912700176239014e+00
    phi[8,4]  R1869     -3.5499916076660156e+00
    phi[8,4]  R1870     -2.0356371402740479e+00
    phi[8,4]  R1871     -1.5581924915313721e+00
    phi[8,4]  R1872     -1.7733958959579468e+00
    phi[4,10]  R36       1
    phi[4,10]  R37       1
    phi[4,10]  R38       -2.3659294656801513e+00
    phi[4,10]  R39       1.61396413869553
    phi[4,10]  R40       7.2004346022925292e-01
    phi[4,10]  R41       -1.1164516108306279e+00
    phi[4,10]  R42       -1.6949008548941715e+00
    phi[4,10]  R43       4.8224095273947909e-01
    phi[4,10]  R44       -6.2122488005295651e-01
    phi[4,10]  R82       -1
    phi[4,10]  R1873     -5.46592937031272
    phi[4,10]  R1874     -7.3407043895241708e-01
    phi[4,10]  R1875     -6.2603587084121326e-01
    phi[4,10]  R1876     -3.8539641482322731e+00
    phi[4,10]  R1877     -2.3799564444033154e+00
    phi[4,10]  R1878     -3.8200433648618213e+00
    phi[4,10]  R1879     -3.6864515440734258e+00
    phi[4,10]  R1880     -1.45354832241217
    phi[4,10]  R1881     -4.79490075952674
    phi[4,10]  R1882     -1.4050990497383968e+00
    phi[4,10]  R1883     -1.6077589614298324e+00
    phi[4,10]  R1884     -2.5722408669087908e+00
    phi[4,10]  R1885     -3.7212247846855249e+00
    phi[4,10]  R1886     -2.4787750245796119e+00
    phi[4,10]  R1887     -1.3431095347016253e-07
    phi[4,10]  R1888     -5.5467881399096086e-08
    phi[4,10]  R1889     -3.8332029727964123e-02
    phi[4,10]  R1890     -3.9661797612338123e-02
    phi[4,10]  R1891     -4.3621473504663832e-02
    phi[4,10]  R1892     -6.9471815079125587e-02
    phi[4,10]  R1893     -6.6236381786016163e-01
    phi[4,10]  R1894     -8.3088436493191908e-01
    phi[4,10]  R1895     -5.2004870577436435e-01
    phi[4,10]  R1896     -5.3006303317286541e-01
    phi[4,10]  R1897     -0.503597650111974
    phi[4,10]  R1898     -7.8115338361524844e-01
    phi[4,10]  R1899     -2.2497650915967671e-01
    phi[4,10]  R1900     -3.3628408104741503e-01
    phi[4,10]  R1901     -8.0062185582463208e-01
    phi[4,10]  R1902     -8.9120439488667014e-01
    phi[4,10]  R1903     -3.5377877765044152e-01
    phi[4,10]  R1904     -6.3355322691226679e-01
    phi[4,10]  R1905     -4.7829687558965839e-01
    phi[4,10]  R1906     -6.3154194327352764e-01
    phi[4,10]  R1907     -3.6652936796193880e-01
    phi[4,10]  R1908     -8.4684897391751512e-01
    phi[4,10]  R1909     -9.6380336656899024e-01
    phi[4,10]  R1910     -3.8634940175701082e-01
    phi[4,10]  R1911     -6.5431408785283685e-01
    phi[4,10]  R1912     -3.9051182468595846e-01
    phi[4,10]  R1913     -3.9874769689498613e-01
    phi[4,10]  R1914     -0.515371085883072
    phi[4,10]  R1915     -4.8306720941682729e-01
    phi[4,10]  R1916     -3.7177356372616810e-01
    phi[4,10]  R1917     -7.0624315154899842e-01
    phi[4,10]  R1918     -3.7586320280001084e-01
    phi[4,10]  R1919     -3.8112122371242130e-01
    phi[4,10]  R1920     -3.8788533416573245e-01
    phi[4,10]  R1921     -3.9119039087691321e-01
    phi[4,10]  R1922     -3.9600525987093826e-01
    phi[4,10]  R1923     -9.7314298503224128e-01
    phi[4,10]  R1924     -2.3342823081836203e-01
    phi[4,10]  R1925     -3.0302633454988648e-01
    phi[4,10]  R1926     -4.1537851462457076e-01
    phi[4,10]  R1927     -6.3008682570172159e-01
    phi[4,10]  R1928     -9.0733104399209474e-01
    phi[4,10]  R1929     -3.5373214058716895e-01
    phi[4,10]  R1930     -4.8618915927410267e-01
    phi[4,10]  R1931     -5.0823061544979276e-01
    phi[4,10]  R1932     -0.339866928955026
    phi[4,10]  R1933     -3.5719314663892265e-01
    phi[4,10]  R1934     -3.4292669372693396e-01
    phi[4,10]  R1935     -8.2164834617385463e-01
    phi[4,10]  R1936     -3.1907925266951942e-01
    phi[4,10]  R1937     -0.751683682369816
    phi[4,10]  R1938     -3.4482930796925626e-01
    phi[4,10]  R1939     -8.1354690848333622e-01
    phi[4,10]  R1940     -3.7283331346692639e-01
    phi[4,10]  R1941     -9.3190146986098976e-01
    phi[4,10]  R1942     -5.9402628916504852e-01
    phi[4,10]  R1943     -3.7628134875699315e-01
    phi[4,10]  R1944     -5.6893531298783317e-01
    phi[4,10]  R1945     -3.3242710400620989e-01
    phi[4,10]  R1946     -3.4588582702144954e-01
    phi[4,10]  R1947     -6.0539088355815807e-01
    phi[4,10]  R1948     -3.6076062081111138e-01
    phi[4,10]  R1949     -3.6802724372672335e-01
    phi[4,10]  R1950     -3.9198539161626833e-01
    phi[4,10]  R1951     -3.9282308313613878e-01
    phi[4,10]  R1952     -5.1275664498164242e-01
    phi[4,10]  R1953     -6.3412109920729609e-01
    phi[4,10]  R1954     -1.0817304486432124e+00
    phi[4,10]  R1955     -3.2903977958095143e-01
    phi[4,10]  R1956     -3.3124213189542639e-01
    phi[4,10]  R1957     -8.2870835566630108e-01
    phi[4,10]  R1958     -3.9232484555103841e-01
    phi[4,10]  R1959     -7.7160681433633149e-01
    phi[4,10]  R1960     -5.1192766111713817e-01
    phi[4,10]  R1961     -5.3061872526906750e-01
    phi[4,10]  R1962     -5.4744376867987432e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R1963     -3.0999999046325684e+00
    phi[5,6]  R1964     -3.0999999046325684e+00
    phi[5,6]  R1965     -2.2400000095367432e+00
    phi[5,6]  R1966     -2.2400000095367432e+00
    phi[5,6]  R1967     -3.0999999046325684e+00
    phi[5,6]  R1968     -3.0999999046325684e+00
    phi[5,6]  R1969     -2.5699999332427979e+00
    phi[5,6]  R1970     -2.5699999332427979e+00
    phi[5,6]  R1971     -3.0999999046325684e+00
    phi[5,6]  R1972     -3.0999999046325684e+00
    phi[5,6]  R1973     -2.0899999141693115e+00
    phi[5,6]  R1974     -2.0899999141693115e+00
    phi[5,6]  R1975     -3.0999999046325684e+00
    phi[5,6]  R1976     -3.0999999046325684e+00
    phi[5,6]  R1977     2.6831056922674179e-02
    phi[5,6]  R1978     -4.2942622303962708e-01
    phi[5,6]  R1979     9.7848415374755859e-01
    phi[5,6]  R1980     0.0994705855846405
    phi[5,6]  R1981     7.0897883176803589e-01
    phi[5,6]  R1982     5.9090304374694824e-01
    phi[5,6]  R1983     -2.5024530291557312e-01
    phi[5,6]  R1984     -1.8264852464199066e-01
    phi[5,6]  R1985     -7.1134227514266968e-01
    phi[5,6]  R1986     -0.820121169090271
    phi[5,6]  R1987     -1.8181357383728027e+00
    phi[5,6]  R1988     -2.3563027381896973e+00
    phi[5,6]  R1989     -1.9937500953674316e+00
    phi[5,6]  R1990     -1.8709206581115723e+00
    phi[5,6]  R1991     -1.3309085369110107e+00
    phi[5,6]  R1992     -8.7400436401367188e-01
    phi[5,6]  R1993     -4.2216670513153076e-01
    phi[5,6]  R1994     -1.2581146955490112e+00
    phi[5,6]  R1995     -8.7997305393218994e-01
    phi[5,6]  R1996     -6.4638954401016235e-01
    phi[5,6]  R1997     -9.1535031795501709e-01
    phi[5,6]  R1998     -1.1431825160980225e+00
    phi[5,6]  R1999     -1.5140734612941742e-01
    phi[5,6]  R2000     -6.7351406812667847e-01
    phi[5,6]  R2001     -1.2798300981521606e+00
    phi[5,6]  R2002     -1.2490893602371216e+00
    phi[5,6]  R2003     3.9258778095245361e-01
    phi[5,6]  R2004     -1.8112614154815674e+00
    phi[5,6]  R2005     3.5978391766548157e-02
    phi[5,6]  R2006     -1.6011202335357666e-01
    phi[5,6]  R2007     -1.0940562486648560e+00
    phi[5,6]  R2008     -7.7748584747314453e-01
    phi[5,6]  R2009     -7.9182225465774536e-01
    phi[5,6]  R2010     -2.8238520026206970e-01
    phi[5,6]  R2011     -1.1029708385467529e+00
    phi[5,6]  R2012     -1.7994811534881592e+00
    phi[5,6]  R2013     -1.83518648147583
    phi[5,6]  R2014     -1.0832253694534302e+00
    phi[5,6]  R2015     -2.7434592247009277e+00
    phi[5,6]  R2016     -2.8418223857879639e+00
    phi[5,6]  R2017     2.1455609798431396e+00
    phi[5,6]  R2018     1.8463429212570190e+00
    phi[5,6]  R2019     1.1803989410400391e+00
    phi[5,6]  R2020     1.4594037532806396e+00
    phi[5,6]  R2021     1.0626080036163330e+00
    phi[5,6]  R2022     1.3806138038635254e+00
    phi[5,6]  R2023     2.2671175003051758e+00
    phi[5,6]  R2024     1.2541002035140991e+00
    phi[5,6]  R2025     1.7347513437271118e+00
    phi[5,6]  R2026     5.9315067529678345e-01
    phi[5,6]  R2027     -2.5544424057006836e+00
    phi[5,6]  R2028     -6.3547378778457642e-01
    phi[5,6]  R2029     -1.2343641519546509e+00
    phi[5,6]  R2030     -1.7027518749237061e+00
    phi[5,6]  R2031     -1.3141212463378906e+00
    phi[5,6]  R2032     -1.64011549949646
    phi[5,6]  R2033     -6.9621282815933228e-01
    phi[5,6]  R2034     -1.6735816001892090e+00
    phi[5,6]  R2035     -2.6978516578674316e+00
    phi[5,6]  R2036     -5.4564619064331055e-01
    phi[5,6]  R2037     -2.9110813140869141e+00
    phi[5,6]  R2038     -2.4890964031219482e+00
    phi[5,6]  R2039     -2.3469438552856445e+00
    phi[5,6]  R2040     -2.3154134750366211e+00
    phi[5,6]  R2041     -2.8138027191162109e+00
    phi[5,6]  R2042     -2.6748182773590088e+00
    phi[5,6]  R2043     -2.9229660034179688e+00
    phi[5,6]  R2044     -2.9159283638000488e+00
    phi[5,6]  R2045     -1.8973672389984131e+00
    phi[5,6]  R2046     -2.0934510231018066e+00
    phi[5,6]  R2047     -2.4994726181030273e+00
    phi[5,6]  R2048     -1.7863827943801880e+00
    phi[5,6]  R2049     -2.4847347736358643e+00
    phi[5,6]  R2050     2.0926742553710938e+00
    phi[5,6]  R2051     -2.1198420524597168e+00
    phi[5,6]  R2052     -3.1505444645881653e-01
    phi[5,6]  R2053     -9.7124058008193970e-01
    phi[5,6]  R2054     -1.3889200687408447e+00
    phi[5,6]  R2055     1.3344401121139526e+00
    phi[5,6]  R2056     -0.511612594127655
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2057     -3.0999999046325684e+00
    phi[6,5]  R2058     -3.0999999046325684e+00
    phi[6,5]  R2059     -2.2400000095367432e+00
    phi[6,5]  R2060     -2.2400000095367432e+00
    phi[6,5]  R2061     -3.0999999046325684e+00
    phi[6,5]  R2062     -3.0999999046325684e+00
    phi[6,5]  R2063     -2.5699999332427979e+00
    phi[6,5]  R2064     -2.5699999332427979e+00
    phi[6,5]  R2065     -3.0999999046325684e+00
    phi[6,5]  R2066     -3.0999999046325684e+00
    phi[6,5]  R2067     -2.0899999141693115e+00
    phi[6,5]  R2068     -2.0899999141693115e+00
    phi[6,5]  R2069     -3.0999999046325684e+00
    phi[6,5]  R2070     -3.0999999046325684e+00
    phi[6,5]  R2071     2.1455609798431396e+00
    phi[6,5]  R2072     1.8463429212570190e+00
    phi[6,5]  R2073     1.1803989410400391e+00
    phi[6,5]  R2074     1.4594037532806396e+00
    phi[6,5]  R2075     1.0626080036163330e+00
    phi[6,5]  R2076     1.3806138038635254e+00
    phi[6,5]  R2077     2.2671175003051758e+00
    phi[6,5]  R2078     1.2541002035140991e+00
    phi[6,5]  R2079     1.7347513437271118e+00
    phi[6,5]  R2080     5.9315067529678345e-01
    phi[6,5]  R2081     -2.5544424057006836e+00
    phi[6,5]  R2082     -6.3547378778457642e-01
    phi[6,5]  R2083     -1.2343641519546509e+00
    phi[6,5]  R2084     -1.7027518749237061e+00
    phi[6,5]  R2085     -1.3141212463378906e+00
    phi[6,5]  R2086     -1.64011549949646
    phi[6,5]  R2087     -6.9621282815933228e-01
    phi[6,5]  R2088     -1.6735816001892090e+00
    phi[6,5]  R2089     -2.6978516578674316e+00
    phi[6,5]  R2090     -5.4564619064331055e-01
    phi[6,5]  R2091     -2.9110813140869141e+00
    phi[6,5]  R2092     -2.4890964031219482e+00
    phi[6,5]  R2093     -2.3469438552856445e+00
    phi[6,5]  R2094     -2.3154134750366211e+00
    phi[6,5]  R2095     -2.8138027191162109e+00
    phi[6,5]  R2096     -2.6748182773590088e+00
    phi[6,5]  R2097     -2.9229660034179688e+00
    phi[6,5]  R2098     -2.9159283638000488e+00
    phi[6,5]  R2099     -1.8973672389984131e+00
    phi[6,5]  R2100     -2.0934510231018066e+00
    phi[6,5]  R2101     -2.4994726181030273e+00
    phi[6,5]  R2102     -1.7863827943801880e+00
    phi[6,5]  R2103     -2.4847347736358643e+00
    phi[6,5]  R2104     2.0926742553710938e+00
    phi[6,5]  R2105     -2.1198420524597168e+00
    phi[6,5]  R2106     -3.1505444645881653e-01
    phi[6,5]  R2107     -9.7124058008193970e-01
    phi[6,5]  R2108     -1.3889200687408447e+00
    phi[6,5]  R2109     1.3344401121139526e+00
    phi[6,5]  R2110     -0.511612594127655
    phi[6,5]  R2111     2.6831056922674179e-02
    phi[6,5]  R2112     -4.2942622303962708e-01
    phi[6,5]  R2113     9.7848415374755859e-01
    phi[6,5]  R2114     0.0994705855846405
    phi[6,5]  R2115     7.0897883176803589e-01
    phi[6,5]  R2116     5.9090304374694824e-01
    phi[6,5]  R2117     -2.5024530291557312e-01
    phi[6,5]  R2118     -1.8264852464199066e-01
    phi[6,5]  R2119     -7.1134227514266968e-01
    phi[6,5]  R2120     -0.820121169090271
    phi[6,5]  R2121     -1.8181357383728027e+00
    phi[6,5]  R2122     -2.3563027381896973e+00
    phi[6,5]  R2123     -1.9937500953674316e+00
    phi[6,5]  R2124     -1.8709206581115723e+00
    phi[6,5]  R2125     -1.3309085369110107e+00
    phi[6,5]  R2126     -8.7400436401367188e-01
    phi[6,5]  R2127     -4.2216670513153076e-01
    phi[6,5]  R2128     -1.2581146955490112e+00
    phi[6,5]  R2129     -8.7997305393218994e-01
    phi[6,5]  R2130     -6.4638954401016235e-01
    phi[6,5]  R2131     -9.1535031795501709e-01
    phi[6,5]  R2132     -1.1431825160980225e+00
    phi[6,5]  R2133     -1.5140734612941742e-01
    phi[6,5]  R2134     -6.7351406812667847e-01
    phi[6,5]  R2135     -1.2798300981521606e+00
    phi[6,5]  R2136     -1.2490893602371216e+00
    phi[6,5]  R2137     3.9258778095245361e-01
    phi[6,5]  R2138     -1.8112614154815674e+00
    phi[6,5]  R2139     3.5978391766548157e-02
    phi[6,5]  R2140     -1.6011202335357666e-01
    phi[6,5]  R2141     -1.0940562486648560e+00
    phi[6,5]  R2142     -7.7748584747314453e-01
    phi[6,5]  R2143     -7.9182225465774536e-01
    phi[6,5]  R2144     -2.8238520026206970e-01
    phi[6,5]  R2145     -1.1029708385467529e+00
    phi[6,5]  R2146     -1.7994811534881592e+00
    phi[6,5]  R2147     -1.83518648147583
    phi[6,5]  R2148     -1.0832253694534302e+00
    phi[6,5]  R2149     -2.7434592247009277e+00
    phi[6,5]  R2150     -2.8418223857879639e+00
    phi[9,5]  R45       -1
    phi[9,5]  R47       -1.0876942707822710e+00
    phi[9,5]  R48       -1.3864910604887788e+00
    phi[9,5]  R49       -8.0873759611484930e-01
    phi[9,5]  R50       1.7029626216183824e+00
    phi[9,5]  R51       1.5535340012573573e+00
    phi[9,5]  R52       1.2092606776728023e+00
    phi[9,5]  R53       -8.6802718594208583e-01
    phi[9,5]  R81       1
    phi[9,5]  R2151     -2.0123056338502971e+00
    phi[9,5]  R2152     -4.18769417541484
    phi[9,5]  R2153     -8.5350894904796437e-01
    phi[9,5]  R2154     -3.6264910700255220e+00
    phi[9,5]  R2155     -2.2912623085177191e+00
    phi[9,5]  R2156     -3.9087375007474177e+00
    phi[9,5]  R2157     -4.2729625548611807e+00
    phi[9,5]  R2158     -8.6703731162441544e-01
    phi[9,5]  R2159     -4.6535339058899261e+00
    phi[9,5]  R2160     -1.5464659033752111e+00
    phi[9,5]  R2161     -3.2992605918421138e+00
    phi[9,5]  R2162     -8.8073923649650920e-01
    phi[9,5]  R2163     -2.2319727186904825e+00
    phi[9,5]  R2164     -3.9680270905746542e+00
    phi[9,5]  R2165     -1.0390150049228603e-01
    phi[9,5]  R2166     -1.0393465399320345e-01
    phi[9,5]  R2167     -1.2650510066765186e-01
    phi[9,5]  R2168     -1.4509022307968403e-01
    phi[9,5]  R2169     -1.4848653635477915e-01
    phi[9,5]  R2170     -1.5311247107028647e-01
    phi[9,5]  R2171     -4.7440798980860549e-01
    phi[9,5]  R2172     -3.2727832896973308e-01
    phi[9,5]  R2173     -6.3827339359666024e-01
    phi[9,5]  R2174     -3.4493078250122916e-01
    phi[9,5]  R2175     -3.2280236590669653e-01
    phi[9,5]  R2176     -3.3589423400809348e-01
    phi[9,5]  R2177     -3.5402535097522914e-01
    phi[9,5]  R2178     -3.5555884794782733e-01
    phi[9,5]  R2179     -4.0750328505352584e-01
    phi[9,5]  R2180     -4.1623766404327867e-01
    phi[9,5]  R2181     -4.6598672845760780e-01
    phi[9,5]  R2182     -4.8328469234358096e-01
    phi[9,5]  R2183     -5.0399483216729557e-01
    phi[9,5]  R2184     -5.1798869837140993e-01
    phi[9,5]  R2185     -1.5483063132922914e-01
    phi[9,5]  R2186     -1.8947365880616596e-01
    phi[9,5]  R2187     -2.0688324746288739e-01
    phi[9,5]  R2188     -2.3117010398635474e-01
    phi[9,5]  R2189     -3.9874444900762496e-01
    phi[9,5]  R2190     -4.0586207949062891e-01
    phi[9,5]  R2191     -4.1593732492734781e-01
    phi[9,5]  R2192     -4.3400461935056844e-01
    phi[9,5]  R2193     -5.8327555920557317e-01
    phi[9,5]  R2194     -5.9589267643120070e-01
    phi[9,5]  R2195     -1.3242471138670375e-01
    phi[9,5]  R2196     -1.3366019889351988e-01
    phi[9,5]  R2197     -2.1623672774899250e-01
    phi[9,5]  R2198     -3.1392357924943565e-01
    phi[9,5]  R2199     -3.2756129140055723e-01
    phi[9,5]  R2200     -7.5320101665544770e-01
    phi[9,5]  R2201     -7.5730322781984283e-01
    phi[9,5]  R2202     -7.9589969153773521e-01
    phi[9,5]  R2203     -1.0804520589302937e+00
    phi[9,5]  R2204     -1.0949751605916485e+00
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R2205     -3.0999999046325684e+00
    phi[6,7]  R2206     -3.0999999046325684e+00
    phi[6,7]  R2207     -2.2400000095367432e+00
    phi[6,7]  R2208     -2.2400000095367432e+00
    phi[6,7]  R2209     -3.0999999046325684e+00
    phi[6,7]  R2210     -3.0999999046325684e+00
    phi[6,7]  R2211     -2.5699999332427979e+00
    phi[6,7]  R2212     -2.5699999332427979e+00
    phi[6,7]  R2213     -3.0999999046325684e+00
    phi[6,7]  R2214     -3.0999999046325684e+00
    phi[6,7]  R2215     -2.0899999141693115e+00
    phi[6,7]  R2216     -2.0899999141693115e+00
    phi[6,7]  R2217     -3.0999999046325684e+00
    phi[6,7]  R2218     -3.0999999046325684e+00
    phi[6,7]  R2219     2.1455609798431396e+00
    phi[6,7]  R2220     1.8463429212570190e+00
    phi[6,7]  R2221     1.1803989410400391e+00
    phi[6,7]  R2222     1.4594037532806396e+00
    phi[6,7]  R2223     1.0626080036163330e+00
    phi[6,7]  R2224     1.3806138038635254e+00
    phi[6,7]  R2225     2.2671175003051758e+00
    phi[6,7]  R2226     1.2541002035140991e+00
    phi[6,7]  R2227     1.7347513437271118e+00
    phi[6,7]  R2228     5.9315067529678345e-01
    phi[6,7]  R2229     -2.5544424057006836e+00
    phi[6,7]  R2230     -6.3547378778457642e-01
    phi[6,7]  R2231     -1.2343641519546509e+00
    phi[6,7]  R2232     -1.7027518749237061e+00
    phi[6,7]  R2233     -1.3141212463378906e+00
    phi[6,7]  R2234     -1.64011549949646
    phi[6,7]  R2235     -6.9621282815933228e-01
    phi[6,7]  R2236     -1.6735816001892090e+00
    phi[6,7]  R2237     -2.6978516578674316e+00
    phi[6,7]  R2238     -5.4564619064331055e-01
    phi[6,7]  R2239     -2.9110813140869141e+00
    phi[6,7]  R2240     -2.4890964031219482e+00
    phi[6,7]  R2241     -2.3469438552856445e+00
    phi[6,7]  R2242     -2.3154134750366211e+00
    phi[6,7]  R2243     -2.8138027191162109e+00
    phi[6,7]  R2244     -2.6748182773590088e+00
    phi[6,7]  R2245     -2.9229660034179688e+00
    phi[6,7]  R2246     -2.9159283638000488e+00
    phi[6,7]  R2247     -1.8973672389984131e+00
    phi[6,7]  R2248     -2.0934510231018066e+00
    phi[6,7]  R2249     -2.4994726181030273e+00
    phi[6,7]  R2250     -1.7863827943801880e+00
    phi[6,7]  R2251     -2.4847347736358643e+00
    phi[6,7]  R2252     2.0926742553710938e+00
    phi[6,7]  R2253     -2.1198420524597168e+00
    phi[6,7]  R2254     -3.1505444645881653e-01
    phi[6,7]  R2255     -9.7124058008193970e-01
    phi[6,7]  R2256     -1.3889200687408447e+00
    phi[6,7]  R2257     1.3344401121139526e+00
    phi[6,7]  R2258     -0.511612594127655
    phi[6,7]  R2259     1.9726645946502686e+00
    phi[6,7]  R2260     1.8604798316955566e+00
    phi[6,7]  R2261     2.4337649345397949e+00
    phi[6,7]  R2262     2.1396627426147461e+00
    phi[6,7]  R2263     2.7631921768188477e+00
    phi[6,7]  R2264     2.3974528312683105e+00
    phi[6,7]  R2265     2.5888528823852539e+00
    phi[6,7]  R2266     1.8842095136642456e+00
    phi[6,7]  R2267     2.4802374839782715e+00
    phi[6,7]  R2268     2.2263290882110596e+00
    phi[6,7]  R2269     -3.2448613643646240e+00
    phi[6,7]  R2270     -2.2085428237915039e+00
    phi[6,7]  R2271     -2.2802715301513672e+00
    phi[6,7]  R2272     -3.1885154247283936e+00
    phi[6,7]  R2273     -2.7944211959838867e+00
    phi[6,7]  R2274     -2.2405292987823486e+00
    phi[6,7]  R2275     -3.9019858837127686e+00
    phi[6,7]  R2276     -2.2846310138702393e+00
    phi[6,7]  R2277     -2.2150826454162598e+00
    phi[6,7]  R2278     -1.6864511966705322e+00
    phi[6,7]  R2279     -1.6877774000167847e+00
    phi[6,7]  R2280     -1.2098628282546997e+00
    phi[6,7]  R2281     -2.1782221794128418e+00
    phi[6,7]  R2282     -1.9762146472930908e+00
    phi[6,7]  R2283     -2.0041620731353760e+00
    phi[6,7]  R2284     -1.7144851684570312e+00
    phi[6,7]  R2285     -3.4222214221954346e+00
    phi[6,7]  R2286     -2.3233988285064697e+00
    phi[6,7]  R2287     -1.1272107362747192e+00
    phi[6,7]  R2288     -1.05417001247406
    phi[6,7]  R2289     -2.1424033641815186e+00
    phi[6,7]  R2290     -2.3262803554534912e+00
    phi[6,7]  R2291     1.7356351613998413e+00
    phi[6,7]  R2292     -1.7954158782958984e+00
    phi[6,7]  R2293     2.1489887237548828e+00
    phi[6,7]  R2294     -1.2473982572555542e+00
    phi[6,7]  R2295     1.0409188270568848e+00
    phi[6,7]  R2296     -1.3474553823471069e+00
    phi[6,7]  R2297     -4.0992081165313721e-01
    phi[6,7]  R2298     7.4367415904998779e-01
    phi[6,7]  R2299     2.8224570751190186e+00
    phi[6,7]  R2300     3.0024294853210449e+00
    phi[6,7]  R2301     -1.1527781486511230e+00
    phi[6,7]  R2302     -8.0709469318389893e-01
    phi[6,7]  R2303     1.2216894626617432e+00
    phi[6,7]  R2304     -2.8090901374816895e+00
    phi[6,7]  R2305     -1.4056240320205688e+00
    phi[6,7]  R2306     1.8050426244735718e+00
    phi[6,7]  R2307     1.6530294418334961e+00
    phi[6,7]  R2308     -1.6570930480957031e+00
    phi[6,7]  R2309     2.3004133701324463e+00
    phi[6,7]  R2310     -1.1170434951782227e+00
    phi[6,7]  R2311     1.6174712181091309e+00
    phi[6,7]  R2312     -1.9546442031860352e+00
    phi[6,7]  R2313     5.9695506095886230e-01
    phi[6,7]  R2314     -1.5379874706268311e+00
    phi[6,7]  R2315     8.0217711627483368e-02
    phi[6,7]  R2316     -2.3345034122467041e+00
    phi[6,7]  R2317     -1.2938904762268066e+00
    phi[6,7]  R2318     -0.0697346180677414
    phi[6,7]  R2319     -2.0384807586669922e+00
    phi[6,7]  R2320     2.5508012771606445e+00
    phi[6,7]  R2321     -2.9807372093200684e+00
    phi[6,7]  R2322     1.6916140317916870e+00
    phi[6,7]  R2323     -3.4535737037658691e+00
    phi[6,7]  R2324     -2.1824295520782471e+00
    phi[6,7]  R2325     -7.9791349172592163e-01
    phi[6,7]  R2326     -8.0982875823974609e-01
    phi[6,7]  R2327     3.2894369959831238e-01
    phi[6,7]  R2328     -6.9238132238388062e-01
    phi[6,7]  R2329     1.5342128276824951e+00
    phi[6,7]  R2330     -8.6259663105010986e-01
    phi[6,7]  R2331     1.3764312267303467e+00
    phi[6,7]  R2332     8.2337492704391479e-01
    phi[6,7]  R2333     -1.1054385900497437e+00
    phi[6,7]  R2334     -2.5875790119171143e+00
    phi[6,7]  R2335     -3.1252326965332031e+00
    phi[6,7]  R2336     -1.9712796211242676e+00
    phi[6,7]  R2337     -1.4752852916717529e+00
    phi[6,7]  R2338     9.5281016826629639e-01
    phi[6,7]  R2339     2.7158682346343994e+00
    phi[6,7]  R2340     -1.1227324008941650e+00
    phi[6,7]  R2341     -2.5368649959564209e+00
    phi[6,7]  R2342     2.7073416113853455e-01
    phi[6,7]  R2343     -1.8868306875228882e+00
    phi[6,7]  R2344     1.2134937942028046e-01
    phi[6,7]  R2345     -2.0222475528717041e+00
    phi[6,7]  R2346     -2.1279733180999756e+00
    phi[6,7]  R2347     -1.4288482069969177e-01
    phi[6,7]  R2348     -1.0307883024215698e+00
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R2349     -3.0999999046325684e+00
    phi[7,6]  R2350     -3.0999999046325684e+00
    phi[7,6]  R2351     -2.2400000095367432e+00
    phi[7,6]  R2352     -2.2400000095367432e+00
    phi[7,6]  R2353     -3.0999999046325684e+00
    phi[7,6]  R2354     -3.0999999046325684e+00
    phi[7,6]  R2355     -2.5699999332427979e+00
    phi[7,6]  R2356     -2.5699999332427979e+00
    phi[7,6]  R2357     -3.0999999046325684e+00
    phi[7,6]  R2358     -3.0999999046325684e+00
    phi[7,6]  R2359     -2.0899999141693115e+00
    phi[7,6]  R2360     -2.0899999141693115e+00
    phi[7,6]  R2361     -3.0999999046325684e+00
    phi[7,6]  R2362     -3.0999999046325684e+00
    phi[7,6]  R2363     1.9726645946502686e+00
    phi[7,6]  R2364     1.8604798316955566e+00
    phi[7,6]  R2365     2.4337649345397949e+00
    phi[7,6]  R2366     2.1396627426147461e+00
    phi[7,6]  R2367     2.7631921768188477e+00
    phi[7,6]  R2368     2.3974528312683105e+00
    phi[7,6]  R2369     2.5888528823852539e+00
    phi[7,6]  R2370     1.8842095136642456e+00
    phi[7,6]  R2371     2.4802374839782715e+00
    phi[7,6]  R2372     2.2263290882110596e+00
    phi[7,6]  R2373     -3.2448613643646240e+00
    phi[7,6]  R2374     -2.2085428237915039e+00
    phi[7,6]  R2375     -2.2802715301513672e+00
    phi[7,6]  R2376     -3.1885154247283936e+00
    phi[7,6]  R2377     -2.7944211959838867e+00
    phi[7,6]  R2378     -2.2405292987823486e+00
    phi[7,6]  R2379     -3.9019858837127686e+00
    phi[7,6]  R2380     -2.2846310138702393e+00
    phi[7,6]  R2381     -2.2150826454162598e+00
    phi[7,6]  R2382     -1.6864511966705322e+00
    phi[7,6]  R2383     -1.6877774000167847e+00
    phi[7,6]  R2384     -1.2098628282546997e+00
    phi[7,6]  R2385     -2.1782221794128418e+00
    phi[7,6]  R2386     -1.9762146472930908e+00
    phi[7,6]  R2387     -2.0041620731353760e+00
    phi[7,6]  R2388     -1.7144851684570312e+00
    phi[7,6]  R2389     -3.4222214221954346e+00
    phi[7,6]  R2390     -2.3233988285064697e+00
    phi[7,6]  R2391     -1.1272107362747192e+00
    phi[7,6]  R2392     -1.05417001247406
    phi[7,6]  R2393     -2.1424033641815186e+00
    phi[7,6]  R2394     -2.3262803554534912e+00
    phi[7,6]  R2395     1.7356351613998413e+00
    phi[7,6]  R2396     -1.7954158782958984e+00
    phi[7,6]  R2397     2.1489887237548828e+00
    phi[7,6]  R2398     -1.2473982572555542e+00
    phi[7,6]  R2399     1.0409188270568848e+00
    phi[7,6]  R2400     -1.3474553823471069e+00
    phi[7,6]  R2401     -4.0992081165313721e-01
    phi[7,6]  R2402     7.4367415904998779e-01
    phi[7,6]  R2403     2.8224570751190186e+00
    phi[7,6]  R2404     3.0024294853210449e+00
    phi[7,6]  R2405     -1.1527781486511230e+00
    phi[7,6]  R2406     -8.0709469318389893e-01
    phi[7,6]  R2407     1.2216894626617432e+00
    phi[7,6]  R2408     -2.8090901374816895e+00
    phi[7,6]  R2409     -1.4056240320205688e+00
    phi[7,6]  R2410     1.8050426244735718e+00
    phi[7,6]  R2411     1.6530294418334961e+00
    phi[7,6]  R2412     -1.6570930480957031e+00
    phi[7,6]  R2413     2.3004133701324463e+00
    phi[7,6]  R2414     -1.1170434951782227e+00
    phi[7,6]  R2415     1.6174712181091309e+00
    phi[7,6]  R2416     -1.9546442031860352e+00
    phi[7,6]  R2417     5.9695506095886230e-01
    phi[7,6]  R2418     -1.5379874706268311e+00
    phi[7,6]  R2419     8.0217711627483368e-02
    phi[7,6]  R2420     -2.3345034122467041e+00
    phi[7,6]  R2421     -1.2938904762268066e+00
    phi[7,6]  R2422     -0.0697346180677414
    phi[7,6]  R2423     -2.0384807586669922e+00
    phi[7,6]  R2424     2.5508012771606445e+00
    phi[7,6]  R2425     -2.9807372093200684e+00
    phi[7,6]  R2426     1.6916140317916870e+00
    phi[7,6]  R2427     -3.4535737037658691e+00
    phi[7,6]  R2428     -2.1824295520782471e+00
    phi[7,6]  R2429     -7.9791349172592163e-01
    phi[7,6]  R2430     -8.0982875823974609e-01
    phi[7,6]  R2431     3.2894369959831238e-01
    phi[7,6]  R2432     -6.9238132238388062e-01
    phi[7,6]  R2433     1.5342128276824951e+00
    phi[7,6]  R2434     -8.6259663105010986e-01
    phi[7,6]  R2435     1.3764312267303467e+00
    phi[7,6]  R2436     8.2337492704391479e-01
    phi[7,6]  R2437     -1.1054385900497437e+00
    phi[7,6]  R2438     -2.5875790119171143e+00
    phi[7,6]  R2439     -3.1252326965332031e+00
    phi[7,6]  R2440     -1.9712796211242676e+00
    phi[7,6]  R2441     -1.4752852916717529e+00
    phi[7,6]  R2442     9.5281016826629639e-01
    phi[7,6]  R2443     2.7158682346343994e+00
    phi[7,6]  R2444     -1.1227324008941650e+00
    phi[7,6]  R2445     -2.5368649959564209e+00
    phi[7,6]  R2446     2.7073416113853455e-01
    phi[7,6]  R2447     -1.8868306875228882e+00
    phi[7,6]  R2448     1.2134937942028046e-01
    phi[7,6]  R2449     -2.0222475528717041e+00
    phi[7,6]  R2450     -2.1279733180999756e+00
    phi[7,6]  R2451     -1.4288482069969177e-01
    phi[7,6]  R2452     -1.0307883024215698e+00
    phi[7,6]  R2453     2.1455609798431396e+00
    phi[7,6]  R2454     1.8463429212570190e+00
    phi[7,6]  R2455     1.1803989410400391e+00
    phi[7,6]  R2456     1.4594037532806396e+00
    phi[7,6]  R2457     1.0626080036163330e+00
    phi[7,6]  R2458     1.3806138038635254e+00
    phi[7,6]  R2459     2.2671175003051758e+00
    phi[7,6]  R2460     1.2541002035140991e+00
    phi[7,6]  R2461     1.7347513437271118e+00
    phi[7,6]  R2462     5.9315067529678345e-01
    phi[7,6]  R2463     -2.5544424057006836e+00
    phi[7,6]  R2464     -6.3547378778457642e-01
    phi[7,6]  R2465     -1.2343641519546509e+00
    phi[7,6]  R2466     -1.7027518749237061e+00
    phi[7,6]  R2467     -1.3141212463378906e+00
    phi[7,6]  R2468     -1.64011549949646
    phi[7,6]  R2469     -6.9621282815933228e-01
    phi[7,6]  R2470     -1.6735816001892090e+00
    phi[7,6]  R2471     -2.6978516578674316e+00
    phi[7,6]  R2472     -5.4564619064331055e-01
    phi[7,6]  R2473     -2.9110813140869141e+00
    phi[7,6]  R2474     -2.4890964031219482e+00
    phi[7,6]  R2475     -2.3469438552856445e+00
    phi[7,6]  R2476     -2.3154134750366211e+00
    phi[7,6]  R2477     -2.8138027191162109e+00
    phi[7,6]  R2478     -2.6748182773590088e+00
    phi[7,6]  R2479     -2.9229660034179688e+00
    phi[7,6]  R2480     -2.9159283638000488e+00
    phi[7,6]  R2481     -1.8973672389984131e+00
    phi[7,6]  R2482     -2.0934510231018066e+00
    phi[7,6]  R2483     -2.4994726181030273e+00
    phi[7,6]  R2484     -1.7863827943801880e+00
    phi[7,6]  R2485     -2.4847347736358643e+00
    phi[7,6]  R2486     2.0926742553710938e+00
    phi[7,6]  R2487     -2.1198420524597168e+00
    phi[7,6]  R2488     -3.1505444645881653e-01
    phi[7,6]  R2489     -9.7124058008193970e-01
    phi[7,6]  R2490     -1.3889200687408447e+00
    phi[7,6]  R2491     1.3344401121139526e+00
    phi[7,6]  R2492     -0.511612594127655
    phi[6,8]  R54       1
    phi[6,8]  R55       1
    phi[6,8]  R72       -1
    phi[6,8]  R2493     -3.0999999046325684e+00
    phi[6,8]  R2494     -3.0999999046325684e+00
    phi[6,8]  R2495     -2.2400000095367432e+00
    phi[6,8]  R2496     -2.2400000095367432e+00
    phi[6,8]  R2497     -3.0999999046325684e+00
    phi[6,8]  R2498     -3.0999999046325684e+00
    phi[6,8]  R2499     -2.5699999332427979e+00
    phi[6,8]  R2500     -2.5699999332427979e+00
    phi[6,8]  R2501     -3.0999999046325684e+00
    phi[6,8]  R2502     -3.0999999046325684e+00
    phi[6,8]  R2503     -2.0899999141693115e+00
    phi[6,8]  R2504     -2.0899999141693115e+00
    phi[6,8]  R2505     -3.0999999046325684e+00
    phi[6,8]  R2506     -3.0999999046325684e+00
    phi[6,8]  R2507     2.1455609798431396e+00
    phi[6,8]  R2508     1.8463429212570190e+00
    phi[6,8]  R2509     1.1803989410400391e+00
    phi[6,8]  R2510     1.4594037532806396e+00
    phi[6,8]  R2511     1.0626080036163330e+00
    phi[6,8]  R2512     1.3806138038635254e+00
    phi[6,8]  R2513     2.2671175003051758e+00
    phi[6,8]  R2514     1.2541002035140991e+00
    phi[6,8]  R2515     1.7347513437271118e+00
    phi[6,8]  R2516     5.9315067529678345e-01
    phi[6,8]  R2517     -2.5544424057006836e+00
    phi[6,8]  R2518     -6.3547378778457642e-01
    phi[6,8]  R2519     -1.2343641519546509e+00
    phi[6,8]  R2520     -1.7027518749237061e+00
    phi[6,8]  R2521     -1.3141212463378906e+00
    phi[6,8]  R2522     -1.64011549949646
    phi[6,8]  R2523     -6.9621282815933228e-01
    phi[6,8]  R2524     -1.6735816001892090e+00
    phi[6,8]  R2525     -2.6978516578674316e+00
    phi[6,8]  R2526     -5.4564619064331055e-01
    phi[6,8]  R2527     -2.9110813140869141e+00
    phi[6,8]  R2528     -2.4890964031219482e+00
    phi[6,8]  R2529     -2.3469438552856445e+00
    phi[6,8]  R2530     -2.3154134750366211e+00
    phi[6,8]  R2531     -2.8138027191162109e+00
    phi[6,8]  R2532     -2.6748182773590088e+00
    phi[6,8]  R2533     -2.9229660034179688e+00
    phi[6,8]  R2534     -2.9159283638000488e+00
    phi[6,8]  R2535     -1.8973672389984131e+00
    phi[6,8]  R2536     -2.0934510231018066e+00
    phi[6,8]  R2537     -2.4994726181030273e+00
    phi[6,8]  R2538     -1.7863827943801880e+00
    phi[6,8]  R2539     -2.4847347736358643e+00
    phi[6,8]  R2540     2.0926742553710938e+00
    phi[6,8]  R2541     -2.1198420524597168e+00
    phi[6,8]  R2542     -3.1505444645881653e-01
    phi[6,8]  R2543     -9.7124058008193970e-01
    phi[6,8]  R2544     -1.3889200687408447e+00
    phi[6,8]  R2545     1.3344401121139526e+00
    phi[6,8]  R2546     -0.511612594127655
    phi[6,8]  R2547     0.682270048509034
    phi[6,8]  R2548     1.6301953792572021e+00
    phi[6,8]  R2549     2.4280086408212940e+00
    phi[6,8]  R2550     1.85371732711792
    phi[6,8]  R2551     8.3064395189285278e-01
    phi[6,8]  R2552     -1.6890417337417603e+00
    phi[6,8]  R2553     1.6244244575500488e+00
    phi[6,8]  R2554     1.3833212852478027e-01
    phi[6,8]  R2555     -1.2938052415847778e+00
    phi[6,8]  R2556     4.7077560424804688e-01
    phi[6,8]  R2557     -2.5367214679718018e+00
    phi[6,8]  R2558     -3.5966901779174805e+00
    phi[6,8]  R2559     -2.6237609386444092e+00
    phi[6,8]  R2560     -3.1710565090179443e+00
    phi[6,8]  R2561     -2.1854300498962402e+00
    phi[6,8]  R2562     -2.4231557846069336e+00
    phi[6,8]  R2563     -2.6395745277404785e+00
    phi[6,8]  R2564     -5.8699674904346466e-02
    phi[6,8]  R2565     -2.2481372356414795e+00
    phi[6,8]  R2566     -1.4937937259674072e+00
    phi[6,8]  R2567     -1.3759787082672119e+00
    phi[6,8]  R2568     -4.7226530313491821e-01
    phi[6,8]  R2569     -1.9111098051071167e+00
    phi[6,8]  R2570     -2.4730424880981445e+00
    phi[6,8]  R2571     -2.4188549518585205e+00
    phi[6,8]  R2572     -2.8335824012756348e+00
    phi[6,8]  R2573     -2.4559917449951172e+00
    phi[6,8]  R2574     -2.1814482212066650e+00
    phi[6,8]  R2575     -2.8965513706207275e+00
    phi[6,8]  R2576     -2.5799529552459717e+00
    phi[6,8]  R2577     -1.5517382621765137e+00
    phi[6,8]  R2578     -2.2106435298919678e+00
    phi[6,8]  R2579     -2.5730376243591309e+00
    phi[6,8]  R2580     -9.8869937658309937e-01
    phi[6,8]  R2581     -1.5317547321319580e+00
    phi[6,8]  R2582     -1.7015953063964844e+00
    phi[6,8]  R2583     -2.0936355590820312e+00
    phi[6,8]  R2584     -2.0742316246032715e+00
    phi[6,8]  R2585     -1.1329267024993896e+00
    phi[8,6]  R54       -1
    phi[8,6]  R72       1
    phi[8,6]  R73       1
    phi[8,6]  R2586     -3.0999999046325684e+00
    phi[8,6]  R2587     -3.0999999046325684e+00
    phi[8,6]  R2588     -2.2400000095367432e+00
    phi[8,6]  R2589     -2.2400000095367432e+00
    phi[8,6]  R2590     -3.0999999046325684e+00
    phi[8,6]  R2591     -3.0999999046325684e+00
    phi[8,6]  R2592     -2.5699999332427979e+00
    phi[8,6]  R2593     -2.5699999332427979e+00
    phi[8,6]  R2594     -3.0999999046325684e+00
    phi[8,6]  R2595     -3.0999999046325684e+00
    phi[8,6]  R2596     -2.0899999141693115e+00
    phi[8,6]  R2597     -2.0899999141693115e+00
    phi[8,6]  R2598     -3.0999999046325684e+00
    phi[8,6]  R2599     -3.0999999046325684e+00
    phi[8,6]  R2600     0.682270048509034
    phi[8,6]  R2601     1.6301953792572021e+00
    phi[8,6]  R2602     2.4280086408212940e+00
    phi[8,6]  R2603     1.85371732711792
    phi[8,6]  R2604     8.3064395189285278e-01
    phi[8,6]  R2605     -1.6890417337417603e+00
    phi[8,6]  R2606     1.6244244575500488e+00
    phi[8,6]  R2607     1.3833212852478027e-01
    phi[8,6]  R2608     -1.2938052415847778e+00
    phi[8,6]  R2609     4.7077560424804688e-01
    phi[8,6]  R2610     -2.5367214679718018e+00
    phi[8,6]  R2611     -3.5966901779174805e+00
    phi[8,6]  R2612     -2.6237609386444092e+00
    phi[8,6]  R2613     -3.1710565090179443e+00
    phi[8,6]  R2614     -2.1854300498962402e+00
    phi[8,6]  R2615     -2.4231557846069336e+00
    phi[8,6]  R2616     -2.6395745277404785e+00
    phi[8,6]  R2617     -5.8699674904346466e-02
    phi[8,6]  R2618     -2.2481372356414795e+00
    phi[8,6]  R2619     -1.4937937259674072e+00
    phi[8,6]  R2620     -1.3759787082672119e+00
    phi[8,6]  R2621     -4.7226530313491821e-01
    phi[8,6]  R2622     -1.9111098051071167e+00
    phi[8,6]  R2623     -2.4730424880981445e+00
    phi[8,6]  R2624     -2.4188549518585205e+00
    phi[8,6]  R2625     -2.8335824012756348e+00
    phi[8,6]  R2626     -2.4559917449951172e+00
    phi[8,6]  R2627     -2.1814482212066650e+00
    phi[8,6]  R2628     -2.8965513706207275e+00
    phi[8,6]  R2629     -2.5799529552459717e+00
    phi[8,6]  R2630     -1.5517382621765137e+00
    phi[8,6]  R2631     -2.2106435298919678e+00
    phi[8,6]  R2632     -2.5730376243591309e+00
    phi[8,6]  R2633     -9.8869937658309937e-01
    phi[8,6]  R2634     -1.5317547321319580e+00
    phi[8,6]  R2635     -1.7015953063964844e+00
    phi[8,6]  R2636     -2.0936355590820312e+00
    phi[8,6]  R2637     -2.0742316246032715e+00
    phi[8,6]  R2638     -1.1329267024993896e+00
    phi[8,6]  R2639     2.1455609798431396e+00
    phi[8,6]  R2640     1.8463429212570190e+00
    phi[8,6]  R2641     1.1803989410400391e+00
    phi[8,6]  R2642     1.4594037532806396e+00
    phi[8,6]  R2643     1.0626080036163330e+00
    phi[8,6]  R2644     1.3806138038635254e+00
    phi[8,6]  R2645     2.2671175003051758e+00
    phi[8,6]  R2646     1.2541002035140991e+00
    phi[8,6]  R2647     1.7347513437271118e+00
    phi[8,6]  R2648     5.9315067529678345e-01
    phi[8,6]  R2649     -2.5544424057006836e+00
    phi[8,6]  R2650     -6.3547378778457642e-01
    phi[8,6]  R2651     -1.2343641519546509e+00
    phi[8,6]  R2652     -1.7027518749237061e+00
    phi[8,6]  R2653     -1.3141212463378906e+00
    phi[8,6]  R2654     -1.64011549949646
    phi[8,6]  R2655     -6.9621282815933228e-01
    phi[8,6]  R2656     -1.6735816001892090e+00
    phi[8,6]  R2657     -2.6978516578674316e+00
    phi[8,6]  R2658     -5.4564619064331055e-01
    phi[8,6]  R2659     -2.9110813140869141e+00
    phi[8,6]  R2660     -2.4890964031219482e+00
    phi[8,6]  R2661     -2.3469438552856445e+00
    phi[8,6]  R2662     -2.3154134750366211e+00
    phi[8,6]  R2663     -2.8138027191162109e+00
    phi[8,6]  R2664     -2.6748182773590088e+00
    phi[8,6]  R2665     -2.9229660034179688e+00
    phi[8,6]  R2666     -2.9159283638000488e+00
    phi[8,6]  R2667     -1.8973672389984131e+00
    phi[8,6]  R2668     -2.0934510231018066e+00
    phi[8,6]  R2669     -2.4994726181030273e+00
    phi[8,6]  R2670     -1.7863827943801880e+00
    phi[8,6]  R2671     -2.4847347736358643e+00
    phi[8,6]  R2672     2.0926742553710938e+00
    phi[8,6]  R2673     -2.1198420524597168e+00
    phi[8,6]  R2674     -3.1505444645881653e-01
    phi[8,6]  R2675     -9.7124058008193970e-01
    phi[8,6]  R2676     -1.3889200687408447e+00
    phi[8,6]  R2677     1.3344401121139526e+00
    phi[8,6]  R2678     -0.511612594127655
    phi[7,8]  R63       1
    phi[7,8]  R64       1
    phi[7,8]  R72       -1
    phi[7,8]  R2679     -3.0999999046325684e+00
    phi[7,8]  R2680     -3.0999999046325684e+00
    phi[7,8]  R2681     -2.2400000095367432e+00
    phi[7,8]  R2682     -2.2400000095367432e+00
    phi[7,8]  R2683     -3.0999999046325684e+00
    phi[7,8]  R2684     -3.0999999046325684e+00
    phi[7,8]  R2685     -2.5699999332427979e+00
    phi[7,8]  R2686     -2.5699999332427979e+00
    phi[7,8]  R2687     -3.0999999046325684e+00
    phi[7,8]  R2688     -3.0999999046325684e+00
    phi[7,8]  R2689     -2.0899999141693115e+00
    phi[7,8]  R2690     -2.0899999141693115e+00
    phi[7,8]  R2691     -3.0999999046325684e+00
    phi[7,8]  R2692     -3.0999999046325684e+00
    phi[7,8]  R2693     1.9726645946502686e+00
    phi[7,8]  R2694     1.8604798316955566e+00
    phi[7,8]  R2695     2.4337649345397949e+00
    phi[7,8]  R2696     2.1396627426147461e+00
    phi[7,8]  R2697     2.7631921768188477e+00
    phi[7,8]  R2698     2.3974528312683105e+00
    phi[7,8]  R2699     2.5888528823852539e+00
    phi[7,8]  R2700     1.8842095136642456e+00
    phi[7,8]  R2701     2.4802374839782715e+00
    phi[7,8]  R2702     2.2263290882110596e+00
    phi[7,8]  R2703     -3.2448613643646240e+00
    phi[7,8]  R2704     -2.2085428237915039e+00
    phi[7,8]  R2705     -2.2802715301513672e+00
    phi[7,8]  R2706     -3.1885154247283936e+00
    phi[7,8]  R2707     -2.7944211959838867e+00
    phi[7,8]  R2708     -2.2405292987823486e+00
    phi[7,8]  R2709     -3.9019858837127686e+00
    phi[7,8]  R2710     -2.2846310138702393e+00
    phi[7,8]  R2711     -2.2150826454162598e+00
    phi[7,8]  R2712     -1.6864511966705322e+00
    phi[7,8]  R2713     -1.6877774000167847e+00
    phi[7,8]  R2714     -1.2098628282546997e+00
    phi[7,8]  R2715     -2.1782221794128418e+00
    phi[7,8]  R2716     -1.9762146472930908e+00
    phi[7,8]  R2717     -2.0041620731353760e+00
    phi[7,8]  R2718     -1.7144851684570312e+00
    phi[7,8]  R2719     -3.4222214221954346e+00
    phi[7,8]  R2720     -2.3233988285064697e+00
    phi[7,8]  R2721     -1.1272107362747192e+00
    phi[7,8]  R2722     -1.05417001247406
    phi[7,8]  R2723     -2.1424033641815186e+00
    phi[7,8]  R2724     -2.3262803554534912e+00
    phi[7,8]  R2725     1.7356351613998413e+00
    phi[7,8]  R2726     -1.7954158782958984e+00
    phi[7,8]  R2727     2.1489887237548828e+00
    phi[7,8]  R2728     -1.2473982572555542e+00
    phi[7,8]  R2729     1.0409188270568848e+00
    phi[7,8]  R2730     -1.3474553823471069e+00
    phi[7,8]  R2731     -4.0992081165313721e-01
    phi[7,8]  R2732     7.4367415904998779e-01
    phi[7,8]  R2733     2.8224570751190186e+00
    phi[7,8]  R2734     3.0024294853210449e+00
    phi[7,8]  R2735     -1.1527781486511230e+00
    phi[7,8]  R2736     -8.0709469318389893e-01
    phi[7,8]  R2737     1.2216894626617432e+00
    phi[7,8]  R2738     -2.8090901374816895e+00
    phi[7,8]  R2739     -1.4056240320205688e+00
    phi[7,8]  R2740     1.8050426244735718e+00
    phi[7,8]  R2741     1.6530294418334961e+00
    phi[7,8]  R2742     -1.6570930480957031e+00
    phi[7,8]  R2743     2.3004133701324463e+00
    phi[7,8]  R2744     -1.1170434951782227e+00
    phi[7,8]  R2745     1.6174712181091309e+00
    phi[7,8]  R2746     -1.9546442031860352e+00
    phi[7,8]  R2747     5.9695506095886230e-01
    phi[7,8]  R2748     -1.5379874706268311e+00
    phi[7,8]  R2749     8.0217711627483368e-02
    phi[7,8]  R2750     -2.3345034122467041e+00
    phi[7,8]  R2751     -1.2938904762268066e+00
    phi[7,8]  R2752     -0.0697346180677414
    phi[7,8]  R2753     -2.0384807586669922e+00
    phi[7,8]  R2754     2.5508012771606445e+00
    phi[7,8]  R2755     -2.9807372093200684e+00
    phi[7,8]  R2756     1.6916140317916870e+00
    phi[7,8]  R2757     -3.4535737037658691e+00
    phi[7,8]  R2758     -2.1824295520782471e+00
    phi[7,8]  R2759     -7.9791349172592163e-01
    phi[7,8]  R2760     -8.0982875823974609e-01
    phi[7,8]  R2761     3.2894369959831238e-01
    phi[7,8]  R2762     -6.9238132238388062e-01
    phi[7,8]  R2763     1.5342128276824951e+00
    phi[7,8]  R2764     -8.6259663105010986e-01
    phi[7,8]  R2765     1.3764312267303467e+00
    phi[7,8]  R2766     8.2337492704391479e-01
    phi[7,8]  R2767     -1.1054385900497437e+00
    phi[7,8]  R2768     -2.5875790119171143e+00
    phi[7,8]  R2769     -3.1252326965332031e+00
    phi[7,8]  R2770     -1.9712796211242676e+00
    phi[7,8]  R2771     -1.4752852916717529e+00
    phi[7,8]  R2772     9.5281016826629639e-01
    phi[7,8]  R2773     2.7158682346343994e+00
    phi[7,8]  R2774     -1.1227324008941650e+00
    phi[7,8]  R2775     -2.5368649959564209e+00
    phi[7,8]  R2776     2.7073416113853455e-01
    phi[7,8]  R2777     -1.8868306875228882e+00
    phi[7,8]  R2778     1.2134937942028046e-01
    phi[7,8]  R2779     -2.0222475528717041e+00
    phi[7,8]  R2780     -2.1279733180999756e+00
    phi[7,8]  R2781     -1.4288482069969177e-01
    phi[7,8]  R2782     -1.0307883024215698e+00
    phi[7,8]  R2783     0.682270048509034
    phi[7,8]  R2784     1.6301953792572021e+00
    phi[7,8]  R2785     2.4280086408212940e+00
    phi[7,8]  R2786     1.85371732711792
    phi[7,8]  R2787     8.3064395189285278e-01
    phi[7,8]  R2788     -1.6890417337417603e+00
    phi[7,8]  R2789     1.6244244575500488e+00
    phi[7,8]  R2790     1.3833212852478027e-01
    phi[7,8]  R2791     -1.2938052415847778e+00
    phi[7,8]  R2792     4.7077560424804688e-01
    phi[7,8]  R2793     -2.5367214679718018e+00
    phi[7,8]  R2794     -3.5966901779174805e+00
    phi[7,8]  R2795     -2.6237609386444092e+00
    phi[7,8]  R2796     -3.1710565090179443e+00
    phi[7,8]  R2797     -2.1854300498962402e+00
    phi[7,8]  R2798     -2.4231557846069336e+00
    phi[7,8]  R2799     -2.6395745277404785e+00
    phi[7,8]  R2800     -5.8699674904346466e-02
    phi[7,8]  R2801     -2.2481372356414795e+00
    phi[7,8]  R2802     -1.4937937259674072e+00
    phi[7,8]  R2803     -1.3759787082672119e+00
    phi[7,8]  R2804     -4.7226530313491821e-01
    phi[7,8]  R2805     -1.9111098051071167e+00
    phi[7,8]  R2806     -2.4730424880981445e+00
    phi[7,8]  R2807     -2.4188549518585205e+00
    phi[7,8]  R2808     -2.8335824012756348e+00
    phi[7,8]  R2809     -2.4559917449951172e+00
    phi[7,8]  R2810     -2.1814482212066650e+00
    phi[7,8]  R2811     -2.8965513706207275e+00
    phi[7,8]  R2812     -2.5799529552459717e+00
    phi[7,8]  R2813     -1.5517382621765137e+00
    phi[7,8]  R2814     -2.2106435298919678e+00
    phi[7,8]  R2815     -2.5730376243591309e+00
    phi[7,8]  R2816     -9.8869937658309937e-01
    phi[7,8]  R2817     -1.5317547321319580e+00
    phi[7,8]  R2818     -1.7015953063964844e+00
    phi[7,8]  R2819     -2.0936355590820312e+00
    phi[7,8]  R2820     -2.0742316246032715e+00
    phi[7,8]  R2821     -1.1329267024993896e+00
    phi[8,7]  R63       -1
    phi[8,7]  R72       1
    phi[8,7]  R73       1
    phi[8,7]  R2822     -3.0999999046325684e+00
    phi[8,7]  R2823     -3.0999999046325684e+00
    phi[8,7]  R2824     -2.2400000095367432e+00
    phi[8,7]  R2825     -2.2400000095367432e+00
    phi[8,7]  R2826     -3.0999999046325684e+00
    phi[8,7]  R2827     -3.0999999046325684e+00
    phi[8,7]  R2828     -2.5699999332427979e+00
    phi[8,7]  R2829     -2.5699999332427979e+00
    phi[8,7]  R2830     -3.0999999046325684e+00
    phi[8,7]  R2831     -3.0999999046325684e+00
    phi[8,7]  R2832     -2.0899999141693115e+00
    phi[8,7]  R2833     -2.0899999141693115e+00
    phi[8,7]  R2834     -3.0999999046325684e+00
    phi[8,7]  R2835     -3.0999999046325684e+00
    phi[8,7]  R2836     0.682270048509034
    phi[8,7]  R2837     1.6301953792572021e+00
    phi[8,7]  R2838     2.4280086408212940e+00
    phi[8,7]  R2839     1.85371732711792
    phi[8,7]  R2840     8.3064395189285278e-01
    phi[8,7]  R2841     -1.6890417337417603e+00
    phi[8,7]  R2842     1.6244244575500488e+00
    phi[8,7]  R2843     1.3833212852478027e-01
    phi[8,7]  R2844     -1.2938052415847778e+00
    phi[8,7]  R2845     4.7077560424804688e-01
    phi[8,7]  R2846     -2.5367214679718018e+00
    phi[8,7]  R2847     -3.5966901779174805e+00
    phi[8,7]  R2848     -2.6237609386444092e+00
    phi[8,7]  R2849     -3.1710565090179443e+00
    phi[8,7]  R2850     -2.1854300498962402e+00
    phi[8,7]  R2851     -2.4231557846069336e+00
    phi[8,7]  R2852     -2.6395745277404785e+00
    phi[8,7]  R2853     -5.8699674904346466e-02
    phi[8,7]  R2854     -2.2481372356414795e+00
    phi[8,7]  R2855     -1.4937937259674072e+00
    phi[8,7]  R2856     -1.3759787082672119e+00
    phi[8,7]  R2857     -4.7226530313491821e-01
    phi[8,7]  R2858     -1.9111098051071167e+00
    phi[8,7]  R2859     -2.4730424880981445e+00
    phi[8,7]  R2860     -2.4188549518585205e+00
    phi[8,7]  R2861     -2.8335824012756348e+00
    phi[8,7]  R2862     -2.4559917449951172e+00
    phi[8,7]  R2863     -2.1814482212066650e+00
    phi[8,7]  R2864     -2.8965513706207275e+00
    phi[8,7]  R2865     -2.5799529552459717e+00
    phi[8,7]  R2866     -1.5517382621765137e+00
    phi[8,7]  R2867     -2.2106435298919678e+00
    phi[8,7]  R2868     -2.5730376243591309e+00
    phi[8,7]  R2869     -9.8869937658309937e-01
    phi[8,7]  R2870     -1.5317547321319580e+00
    phi[8,7]  R2871     -1.7015953063964844e+00
    phi[8,7]  R2872     -2.0936355590820312e+00
    phi[8,7]  R2873     -2.0742316246032715e+00
    phi[8,7]  R2874     -1.1329267024993896e+00
    phi[8,7]  R2875     1.9726645946502686e+00
    phi[8,7]  R2876     1.8604798316955566e+00
    phi[8,7]  R2877     2.4337649345397949e+00
    phi[8,7]  R2878     2.1396627426147461e+00
    phi[8,7]  R2879     2.7631921768188477e+00
    phi[8,7]  R2880     2.3974528312683105e+00
    phi[8,7]  R2881     2.5888528823852539e+00
    phi[8,7]  R2882     1.8842095136642456e+00
    phi[8,7]  R2883     2.4802374839782715e+00
    phi[8,7]  R2884     2.2263290882110596e+00
    phi[8,7]  R2885     -3.2448613643646240e+00
    phi[8,7]  R2886     -2.2085428237915039e+00
    phi[8,7]  R2887     -2.2802715301513672e+00
    phi[8,7]  R2888     -3.1885154247283936e+00
    phi[8,7]  R2889     -2.7944211959838867e+00
    phi[8,7]  R2890     -2.2405292987823486e+00
    phi[8,7]  R2891     -3.9019858837127686e+00
    phi[8,7]  R2892     -2.2846310138702393e+00
    phi[8,7]  R2893     -2.2150826454162598e+00
    phi[8,7]  R2894     -1.6864511966705322e+00
    phi[8,7]  R2895     -1.6877774000167847e+00
    phi[8,7]  R2896     -1.2098628282546997e+00
    phi[8,7]  R2897     -2.1782221794128418e+00
    phi[8,7]  R2898     -1.9762146472930908e+00
    phi[8,7]  R2899     -2.0041620731353760e+00
    phi[8,7]  R2900     -1.7144851684570312e+00
    phi[8,7]  R2901     -3.4222214221954346e+00
    phi[8,7]  R2902     -2.3233988285064697e+00
    phi[8,7]  R2903     -1.1272107362747192e+00
    phi[8,7]  R2904     -1.05417001247406
    phi[8,7]  R2905     -2.1424033641815186e+00
    phi[8,7]  R2906     -2.3262803554534912e+00
    phi[8,7]  R2907     1.7356351613998413e+00
    phi[8,7]  R2908     -1.7954158782958984e+00
    phi[8,7]  R2909     2.1489887237548828e+00
    phi[8,7]  R2910     -1.2473982572555542e+00
    phi[8,7]  R2911     1.0409188270568848e+00
    phi[8,7]  R2912     -1.3474553823471069e+00
    phi[8,7]  R2913     -4.0992081165313721e-01
    phi[8,7]  R2914     7.4367415904998779e-01
    phi[8,7]  R2915     2.8224570751190186e+00
    phi[8,7]  R2916     3.0024294853210449e+00
    phi[8,7]  R2917     -1.1527781486511230e+00
    phi[8,7]  R2918     -8.0709469318389893e-01
    phi[8,7]  R2919     1.2216894626617432e+00
    phi[8,7]  R2920     -2.8090901374816895e+00
    phi[8,7]  R2921     -1.4056240320205688e+00
    phi[8,7]  R2922     1.8050426244735718e+00
    phi[8,7]  R2923     1.6530294418334961e+00
    phi[8,7]  R2924     -1.6570930480957031e+00
    phi[8,7]  R2925     2.3004133701324463e+00
    phi[8,7]  R2926     -1.1170434951782227e+00
    phi[8,7]  R2927     1.6174712181091309e+00
    phi[8,7]  R2928     -1.9546442031860352e+00
    phi[8,7]  R2929     5.9695506095886230e-01
    phi[8,7]  R2930     -1.5379874706268311e+00
    phi[8,7]  R2931     8.0217711627483368e-02
    phi[8,7]  R2932     -2.3345034122467041e+00
    phi[8,7]  R2933     -1.2938904762268066e+00
    phi[8,7]  R2934     -0.0697346180677414
    phi[8,7]  R2935     -2.0384807586669922e+00
    phi[8,7]  R2936     2.5508012771606445e+00
    phi[8,7]  R2937     -2.9807372093200684e+00
    phi[8,7]  R2938     1.6916140317916870e+00
    phi[8,7]  R2939     -3.4535737037658691e+00
    phi[8,7]  R2940     -2.1824295520782471e+00
    phi[8,7]  R2941     -7.9791349172592163e-01
    phi[8,7]  R2942     -8.0982875823974609e-01
    phi[8,7]  R2943     3.2894369959831238e-01
    phi[8,7]  R2944     -6.9238132238388062e-01
    phi[8,7]  R2945     1.5342128276824951e+00
    phi[8,7]  R2946     -8.6259663105010986e-01
    phi[8,7]  R2947     1.3764312267303467e+00
    phi[8,7]  R2948     8.2337492704391479e-01
    phi[8,7]  R2949     -1.1054385900497437e+00
    phi[8,7]  R2950     -2.5875790119171143e+00
    phi[8,7]  R2951     -3.1252326965332031e+00
    phi[8,7]  R2952     -1.9712796211242676e+00
    phi[8,7]  R2953     -1.4752852916717529e+00
    phi[8,7]  R2954     9.5281016826629639e-01
    phi[8,7]  R2955     2.7158682346343994e+00
    phi[8,7]  R2956     -1.1227324008941650e+00
    phi[8,7]  R2957     -2.5368649959564209e+00
    phi[8,7]  R2958     2.7073416113853455e-01
    phi[8,7]  R2959     -1.8868306875228882e+00
    phi[8,7]  R2960     1.2134937942028046e-01
    phi[8,7]  R2961     -2.0222475528717041e+00
    phi[8,7]  R2962     -2.1279733180999756e+00
    phi[8,7]  R2963     -1.4288482069969177e-01
    phi[8,7]  R2964     -1.0307883024215698e+00
    phi[8,10]  R72       1
    phi[8,10]  R73       1
    phi[8,10]  R74       -2.3659294656801513e+00
    phi[8,10]  R75       1.61396413869553
    phi[8,10]  R76       7.2004346022925292e-01
    phi[8,10]  R77       -1.1164516108306279e+00
    phi[8,10]  R78       -1.6949008548941715e+00
    phi[8,10]  R79       4.8224095273947909e-01
    phi[8,10]  R80       -6.2122488005295651e-01
    phi[8,10]  R82       -1
    phi[8,10]  R2965     -5.46592937031272
    phi[8,10]  R2966     -7.3407043895241708e-01
    phi[8,10]  R2967     -6.2603587084121326e-01
    phi[8,10]  R2968     -3.8539641482322731e+00
    phi[8,10]  R2969     -2.3799564444033154e+00
    phi[8,10]  R2970     -3.8200433648618213e+00
    phi[8,10]  R2971     -3.6864515440734258e+00
    phi[8,10]  R2972     -1.45354832241217
    phi[8,10]  R2973     -4.79490075952674
    phi[8,10]  R2974     -1.4050990497383968e+00
    phi[8,10]  R2975     -1.6077589614298324e+00
    phi[8,10]  R2976     -2.5722408669087908e+00
    phi[8,10]  R2977     -3.7212247846855249e+00
    phi[8,10]  R2978     -2.4787750245796119e+00
    phi[8,10]  R2979     -9.29561623230768e-08
    phi[8,10]  R2980     -6.7265640169011931e-08
    phi[8,10]  R2981     -3.4240644541938536e-08
    phi[8,10]  R2982     -0.00823476086823094
    phi[8,10]  R2983     -1.0922271328297928e-02
    phi[8,10]  R2984     -2.0787536397728705e+00
    phi[8,10]  R2985     -8.1229889454864157e-01
    phi[8,10]  R2986     -1.4807132214810110e+00
    phi[8,10]  R2987     -1.4557581500405918e+00
    phi[8,10]  R2988     -1.6163573956615096e-01
    phi[8,10]  R2989     -1.0217775504176232e+00
    phi[8,10]  R2990     -1.0182922830811525e+00
    phi[8,10]  R2991     -6.8294978652697913e-01
    phi[8,10]  R2992     -3.4945908649154589e-01
    phi[8,10]  R2993     -2.5389185806831693e-01
    phi[8,10]  R2994     -3.3395624333024143e-01
    phi[8,10]  R2995     -2.6102337434969103e-01
    phi[8,10]  R2996     -0.328144204502016
    phi[8,10]  R2997     -5.2393047796545233e-01
    phi[8,10]  R2998     -1.29272149408092
    phi[8,10]  R2999     -1.6184974337791473e+00
    phi[8,10]  R3000     -4.0462496988359731e-01
    phi[8,10]  R3001     -4.6910971894158782e-01
    phi[8,10]  R3002     -4.4371516043961146e-01
    phi[8,10]  R3003     -3.1870571695011840e-01
    phi[8,10]  R3004     -3.1971656436742135e-01
    phi[8,10]  R3005     -1.2269371367158721e+00
    phi[8,10]  R3006     -3.2833155528722036e-01
    phi[8,10]  R3007     -3.3318263948355842e-01
    phi[8,10]  R3008     -1.0523250356304972e+00
    phi[8,10]  R3009     -5.3253240201676810e-01
    phi[8,10]  R3010     -7.3799179447586871e-01
    phi[8,10]  R3011     -1.7792000000483128e+00
    phi[8,10]  R3012     -2.4313436779122122e-01
    phi[8,10]  R3013     -3.2208234582916995e-01
    phi[8,10]  R3014     -3.2908772461991065e-01
    phi[8,10]  R3015     -3.3459681304874023e-01
    phi[8,10]  R3016     -3.6038401144646315e-01
    phi[8,10]  R3017     -3.6741463067336311e-01
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R83       -1
    z[0,1,0]  R84       1
    z[0,1,0]  R97       4.9490082263946533e-01
    z[0,1,0]  R98       4.1498789191246033e-01
    z[0,1,0]  R99       5.6200385093688965e-01
    z[0,1,0]  R100      -2.7195507287979126e-01
    z[0,1,0]  R101      -1.5923419594764709e-01
    z[0,1,0]  R102      1.1338619142770767e-01
    z[0,1,0]  R103      -5.6006636470556259e-02
    z[0,1,0]  R104      -2.2266621887683868e-01
    z[0,1,0]  R105      1.8465099856257439e-02
    z[0,1,0]  R106      6.4370214939117432e-02
    z[0,1,0]  R107      1.5307880938053131e-01
    z[0,1,0]  R108      7.3211260139942169e-02
    z[0,1,0]  R109      3.4881255030632019e-01
    z[0,1,0]  R110      -3.8617795705795288e-01
    z[0,1,0]  R111      -1.6033592820167542e-01
    z[0,1,0]  R112      -5.0186461210250854e-01
    z[0,1,0]  R113      -4.7637766599655151e-01
    z[0,1,0]  R114      -0.341469407081604
    z[0,1,0]  R115      -4.7362893819808960e-01
    z[0,1,0]  R116      -2.7223885059356689e-01
    z[0,1,0]  R117      2.4971213936805725e-01
    z[0,1,0]  R118      -6.0493912547826767e-02
    z[0,1,0]  R119      -0.0623035691678524
    z[0,1,0]  R120      1.6990311443805695e-02
    z[0,1,0]  R121      3.0292698740959167e-01
    z[0,1,0]  R122      -1.4488242566585541e-01
    z[0,1,0]  R123      2.6645186543464661e-01
    z[0,1,0]  R124      -1.6680526733398438e-01
    z[0,1,0]  R125      -6.0302621126174927e-01
    z[0,1,0]  R126      -4.7555884718894958e-01
    z[0,1,0]  R127      3.0833488702774048e-01
    z[0,1,0]  R128      3.6954346299171448e-01
    z[0,1,0]  R129      1.3853612542152405e-01
    z[0,1,0]  R130      1.1774213053286076e-02
    z[0,1,0]  R131      -3.4528955817222595e-01
    z[0,1,0]  R132      -0.51384037733078
    z[0,1,0]  R133      2.9657664895057678e-01
    z[0,1,0]  R134      3.4071081876754761e-01
    z[0,1,0]  R135      4.9104800820350647e-01
    z[0,1,0]  R136      -5.7003223896026611e-01
    z[0,1,0]  R137      -0.0688767358660698
    z[0,1,0]  R138      -4.3175253272056580e-01
    z[0,1,0]  R139      1.4744243025779724e-01
    z[0,1,0]  R140      -1.8172748386859894e-01
    z[0,1,0]  R141      6.0729360580444336e-01
    z[0,1,0]  R142      7.0505076646804810e-01
    z[0,1,0]  R143      -5.4727524518966675e-01
    z[0,1,0]  R144      6.3396120071411133e-01
    z[0,1,0]  R145      -4.9636000394821167e-01
    z[0,1,0]  R146      7.1425217390060425e-01
    z[0,1,0]  R147      2.8491258621215820e-01
    z[0,1,0]  R148      2.6955893635749817e-01
    z[0,1,0]  R149      1.4603634178638458e-01
    z[0,1,0]  R150      -6.4753681421279907e-02
    z[0,1,0]  R151      2.0705427229404449e-01
    z[0,1,0]  R152      4.6588051319122314e-01
    z[0,1,0]  R153      -6.0379576683044434e-01
    z[0,1,0]  R154      -7.6082962751388550e-01
    z[0,1,0]  R155      -7.6411402225494385e-01
    z[0,1,0]  R156      -8.1588953733444214e-01
    z[0,1,0]  R157      -6.5858542919158936e-01
    z[0,1,0]  R158      -6.5801924467086792e-01
    z[0,1,0]  R159      -7.1887493133544922e-01
    z[0,1,0]  R160      -4.1052407026290894e-01
    z[0,1,0]  R161      -7.1989625692367554e-01
    z[0,1,0]  R162      -0.59494549036026
    z[0,1,0]  R163      -5.6977653503417969e-01
    z[0,1,0]  R164      -6.3382625579833984e-01
    z[0,1,0]  R165      -0.820820689201355
    z[0,1,0]  R166      -0.791208803653717
    z[0,1,0]  R167      -1.5829540789127350e-01
    z[0,1,0]  R168      1.0571720451116562e-01
    z[0,1,0]  R169      9.0164765715599060e-02
    z[0,1,0]  R170      2.3170144855976105e-01
    z[0,1,0]  R171      1.9998101890087128e-01
    z[0,1,0]  R172      4.8847761750221252e-01
    z[0,1,0]  R173      2.9615685343742371e-01
    z[0,1,0]  R174      3.3222836256027222e-01
    z[0,1,0]  R175      3.5924544930458069e-01
    z[0,1,0]  R176      2.8316259384155273e-01
    z[0,1,0]  R177      4.6913135051727295e-01
    z[0,1,0]  R178      5.9548223018646240e-01
    z[0,1,0]  R179      5.5419504642486572e-01
    z[0,1,0]  R180      7.1332257986068726e-01
    z[0,1,0]  R181      0.413044273853302
    z[0,1,0]  R182      -4.1304641962051392e-01
    z[0,1,0]  R183      4.5895689725875854e-01
    z[0,1,0]  R184      5.3956449031829834e-01
    z[0,1,0]  R185      1.8347802758216858e-01
    z[0,1,0]  R186      8.0835449695587158e-01
    z[0,1,0]  R187      -2.6094338297843933e-01
    z[0,1,0]  R188      -1.0375731438398361e-01
    z[0,1,0]  R189      -1.1744309961795807e-01
    z[0,1,0]  R190      1.6161955893039703e-01
    z[0,1,0]  R191      4.5744961500167847e-01
    z[0,1,0]  R192      2.7871596813201904e-01
    z[0,1,0]  R193      2.7719014883041382e-01
    z[0,1,0]  R194      1.2179224193096161e-01
    z[0,1,0]  R195      -6.3695102930068970e-02
    z[0,1,0]  R196      0.629237711429596
    z[0,1,0]  R197      3.9095136523246765e-01
    z[0,1,0]  R198      3.6560770124197006e-02
    z[0,1,0]  R199      1.7770273983478546e-01
    z[0,1,0]  R200      1.4492644369602203e-01
    z[0,1,0]  R201      0.556480348110199
    z[0,1,0]  R202      5.0131708383560181e-01
    z[0,1,0]  R203      2.5523781776428223e-01
    z[0,1,0]  R204      -1.5742602944374084e-01
    z[0,1,0]  R205      4.6901664137840271e-01
    z[0,1,0]  R206      -0.0424308106303215
    z[0,1,0]  R207      2.9013910889625549e-01
    z[0,1,0]  R208      -2.6687833666801453e-01
    z[0,1,0]  R209      8.5017897188663483e-02
    z[0,1,0]  R210      -1.7064388096332550e-01
    z[0,1,0]  R211      7.6443380117416382e-01
    z[0,1,0]  R212      1.9689476490020752e-01
    z[0,1,0]  R213      8.2556062936782837e-01
    z[0,1,0]  R214      -1.2607698142528534e-01
    z[0,1,0]  R215      7.0532029867172241e-01
    z[0,1,0]  R216      0.554187536239624
    z[0,1,0]  R217      0.498337984085083
    z[0,1,0]  R218      1.3690540194511414e-01
    z[0,1,0]  R219      2.0153930783271790e-01
    z[0,1,0]  R220      3.8671070337295532e-01
    z[0,1,0]  R221      -7.6744019985198975e-02
    z[0,1,0]  R222      2.1289205551147461e-01
    z[0,1,0]  R223      -1.2130734324455261e-01
    z[0,1,0]  R224      4.4750612229108810e-02
    z[0,1,0]  R225      -1.3699607551097870e-01
    z[0,1,0]  R226      1.7185197770595551e-01
    z[0,1,0]  R227      3.0488875508308411e-01
    z[0,1,0]  R228      -2.1510450541973114e-01
    z[0,1,0]  R229      -4.6034038066864014e-01
    z[0,1,0]  R230      4.8502811789512634e-01
    z[0,1,0]  R231      3.1340980529785156e-01
    z[0,1,0]  R232      -3.1027961522340775e-02
    z[0,1,0]  R233      1.2311228550970554e-02
    z[0,1,0]  R234      6.5089219808578491e-01
    z[0,1,0]  R235      2.2151054814457893e-02
    z[0,1,0]  R236      6.4380139112472534e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R85       -1
    z[0,1,1]  R86       1
    z[0,1,1]  R97       -2.3231776058673859e-01
    z[0,1,1]  R98       -4.2521899938583374e-01
    z[0,1,1]  R99       -2.8838777542114258e-01
    z[0,1,1]  R100      -2.9415807127952576e-01
    z[0,1,1]  R101      -1.8136461079120636e-01
    z[0,1,1]  R102      0.614677906036377
    z[0,1,1]  R103      8.8259148597717285e-01
    z[0,1,1]  R104      -1.2112042307853699e-01
    z[0,1,1]  R105      -2.1046364307403564e-01
    z[0,1,1]  R106      8.1843149662017822e-01
    z[0,1,1]  R107      1.2217903882265091e-01
    z[0,1,1]  R108      4.1422221064567566e-01
    z[0,1,1]  R109      -5.2835303544998169e-01
    z[0,1,1]  R110      -6.0785013437271118e-01
    z[0,1,1]  R111      2.9621484875679016e-01
    z[0,1,1]  R112      1.9389666616916656e-01
    z[0,1,1]  R113      -1.0692614316940308e-01
    z[0,1,1]  R114      3.5085476934909821e-02
    z[0,1,1]  R115      0.0629362165927887
    z[0,1,1]  R116      1.1717350780963898e-01
    z[0,1,1]  R117      4.6073517203330994e-01
    z[0,1,1]  R118      7.1917676925659180e-01
    z[0,1,1]  R119      5.5513072013854980e-01
    z[0,1,1]  R120      -5.3189247846603394e-01
    z[0,1,1]  R121      1.9663409888744354e-01
    z[0,1,1]  R122      0.213766410946846
    z[0,1,1]  R123      3.8322755694389343e-01
    z[0,1,1]  R124      6.5201544761657715e-01
    z[0,1,1]  R125      3.3321052789688110e-01
    z[0,1,1]  R126      6.9712668657302856e-01
    z[0,1,1]  R127      6.4458996057510376e-01
    z[0,1,1]  R128      -5.9066683053970337e-01
    z[0,1,1]  R129      -9.1286391019821167e-01
    z[0,1,1]  R130      -0.74636310338974
    z[0,1,1]  R131      -0.783897876739502
    z[0,1,1]  R132      -4.5693665742874146e-01
    z[0,1,1]  R133      -0.637538731098175
    z[0,1,1]  R134      -7.2442001104354858e-01
    z[0,1,1]  R135      -5.1696652173995972e-01
    z[0,1,1]  R136      1.1333186924457550e-01
    z[0,1,1]  R137      -6.8740415573120117e-01
    z[0,1,1]  R138      -5.5598491430282593e-01
    z[0,1,1]  R139      -7.0357513427734375e-01
    z[0,1,1]  R140      2.2914955019950867e-01
    z[0,1,1]  R141      3.8495090603828430e-01
    z[0,1,1]  R142      6.1672019958496094e-01
    z[0,1,1]  R143      1.0403732955455780e-01
    z[0,1,1]  R144      2.6857027783989906e-02
    z[0,1,1]  R145      3.9084741473197937e-01
    z[0,1,1]  R146      -1.0710010677576065e-01
    z[0,1,1]  R147      4.6051979064941406e-01
    z[0,1,1]  R148      -7.3174512386322021e-01
    z[0,1,1]  R149      -9.7263120114803314e-02
    z[0,1,1]  R150      -8.4369462728500366e-01
    z[0,1,1]  R151      1.1094018071889877e-01
    z[0,1,1]  R152      5.9087282419204712e-01
    z[0,1,1]  R153      -1.5158358030021191e-02
    z[0,1,1]  R154      -4.9962759017944336e-02
    z[0,1,1]  R155      -3.1675678491592407e-01
    z[0,1,1]  R156      -1.8333867192268372e-01
    z[0,1,1]  R157      -1.8033710122108459e-01
    z[0,1,1]  R158      -2.2804026305675507e-01
    z[0,1,1]  R159      -6.2383204698562622e-02
    z[0,1,1]  R160      -2.5859877467155457e-01
    z[0,1,1]  R161      -9.5601566135883331e-02
    z[0,1,1]  R162      -1.7058271169662476e-01
    z[0,1,1]  R163      -1.5964622795581818e-01
    z[0,1,1]  R164      -1.4073713123798370e-01
    z[0,1,1]  R165      -2.7701035141944885e-01
    z[0,1,1]  R166      -1.3329532742500305e-01
    z[0,1,1]  R167      0.804551362991333
    z[0,1,1]  R168      8.0172097682952881e-01
    z[0,1,1]  R169      8.9155030250549316e-01
    z[0,1,1]  R170      8.1907963752746582e-01
    z[0,1,1]  R171      8.7900412082672119e-01
    z[0,1,1]  R172      8.1295800209045410e-01
    z[0,1,1]  R173      7.5687986612319946e-01
    z[0,1,1]  R174      7.5830638408660889e-01
    z[0,1,1]  R175      7.4715173244476318e-01
    z[0,1,1]  R176      7.0336920022964478e-01
    z[0,1,1]  R177      -2.7622026205062866e-01
    z[0,1,1]  R178      -3.9142203330993652e-01
    z[0,1,1]  R179      -0.248797208070755
    z[0,1,1]  R180      -2.4576936662197113e-01
    z[0,1,1]  R181      -2.1434900164604187e-01
    z[0,1,1]  R182      1.0257773846387863e-01
    z[0,1,1]  R183      -1.3534389436244965e-01
    z[0,1,1]  R184      -1.5342769026756287e-01
    z[0,1,1]  R185      -2.4239315092563629e-01
    z[0,1,1]  R186      1.2143120914697647e-01
    z[0,1,1]  R187      5.4998785257339478e-01
    z[0,1,1]  R188      -7.4844092130661011e-01
    z[0,1,1]  R189      -5.1669752597808838e-01
    z[0,1,1]  R190      2.8788894414901733e-01
    z[0,1,1]  R191      -7.5884765386581421e-01
    z[0,1,1]  R192      -5.1433372497558594e-01
    z[0,1,1]  R193      -5.9484966099262238e-02
    z[0,1,1]  R194      5.6977644562721252e-02
    z[0,1,1]  R195      -9.7424782812595367e-02
    z[0,1,1]  R196      3.4643688797950745e-01
    z[0,1,1]  R197      -7.4864143133163452e-01
    z[0,1,1]  R198      -7.6750653982162476e-01
    z[0,1,1]  R199      -0.63265460729599
    z[0,1,1]  R200      -7.0288920402526855e-01
    z[0,1,1]  R201      -6.0325086116790771e-01
    z[0,1,1]  R202      -6.3913995027542114e-01
    z[0,1,1]  R203      3.4777700901031494e-01
    z[0,1,1]  R204      1.0955148190259933e-01
    z[0,1,1]  R205      3.3840516209602356e-01
    z[0,1,1]  R206      2.0106829702854156e-01
    z[0,1,1]  R207      2.3183113336563110e-01
    z[0,1,1]  R208      4.2090049386024475e-01
    z[0,1,1]  R209      4.7850003838539124e-01
    z[0,1,1]  R210      5.1707899570465088e-01
    z[0,1,1]  R211      4.5963954925537109e-01
    z[0,1,1]  R212      2.8990250825881958e-01
    z[0,1,1]  R213      6.1392839998006821e-02
    z[0,1,1]  R214      -6.5599137544631958e-01
    z[0,1,1]  R215      4.3035867810249329e-01
    z[0,1,1]  R216      4.1396754980087280e-01
    z[0,1,1]  R217      -5.6772458553314209e-01
    z[0,1,1]  R218      -4.0542924404144287e-01
    z[0,1,1]  R219      -2.9511788487434387e-01
    z[0,1,1]  R220      4.9987000226974487e-01
    z[0,1,1]  R221      4.4165849685668945e-01
    z[0,1,1]  R222      4.4861632585525513e-01
    z[0,1,1]  R223      0.58297199010849
    z[0,1,1]  R224      -0.700998842716217
    z[0,1,1]  R225      2.2690226137638092e-01
    z[0,1,1]  R226      -0.0210583433508873
    z[0,1,1]  R227      6.1287569999694824e-01
    z[0,1,1]  R228      -7.1970504522323608e-01
    z[0,1,1]  R229      -5.1845723390579224e-01
    z[0,1,1]  R230      5.7428580522537231e-01
    z[0,1,1]  R231      3.9865252375602722e-01
    z[0,1,1]  R232      -2.9648298025131226e-01
    z[0,1,1]  R233      3.0242647975683212e-02
    z[0,1,1]  R234      1.9152933359146118e-01
    z[0,1,1]  R235      7.7534466981887817e-01
    z[0,1,1]  R236      2.0321662724018097e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R87       -1
    z[0,1,2]  R88       1
    z[0,1,2]  R97       -5.7488650083541870e-01
    z[0,1,2]  R98       -6.2625670433044434e-01
    z[0,1,2]  R99       -8.8665857911109924e-02
    z[0,1,2]  R100      -5.7745444774627686e-01
    z[0,1,2]  R101      -4.2030754685401917e-01
    z[0,1,2]  R102      -3.2679456472396851e-01
    z[0,1,2]  R103      2.3499237000942230e-01
    z[0,1,2]  R104      -2.5501725077629089e-01
    z[0,1,2]  R105      -6.5312135219573975e-01
    z[0,1,2]  R106      1.2549513578414917e-01
    z[0,1,2]  R107      -2.6208499073982239e-01
    z[0,1,2]  R108      3.5253354907035828e-01
    z[0,1,2]  R109      4.8182269930839539e-01
    z[0,1,2]  R110      3.8683211803436279e-01
    z[0,1,2]  R111      8.2693123817443848e-01
    z[0,1,2]  R112      8.0544006824493408e-01
    z[0,1,2]  R113      8.4311634302139282e-01
    z[0,1,2]  R114      8.9893138408660889e-01
    z[0,1,2]  R115      0.8321533203125
    z[0,1,2]  R116      9.1821324825286865e-01
    z[0,1,2]  R117      -7.1190494298934937e-01
    z[0,1,2]  R118      1.0455914773046970e-02
    z[0,1,2]  R119      2.5464800000190735e-01
    z[0,1,2]  R120      -5.5668348073959351e-01
    z[0,1,2]  R121      -0.676361620426178
    z[0,1,2]  R122      1.8518878519535065e-01
    z[0,1,2]  R123      -1.8845534324645996e-01
    z[0,1,2]  R124      -2.9361501336097717e-01
    z[0,1,2]  R125      1.4269612729549408e-02
    z[0,1,2]  R126      1.4455687999725342e-01
    z[0,1,2]  R127      -4.1292563080787659e-01
    z[0,1,2]  R128      -4.6847561001777649e-01
    z[0,1,2]  R129      2.1335519850254059e-01
    z[0,1,2]  R130      3.4986928105354309e-01
    z[0,1,2]  R131      -4.8542730510234833e-02
    z[0,1,2]  R132      -7.7823407948017120e-02
    z[0,1,2]  R133      -1.1915443092584610e-01
    z[0,1,2]  R134      3.6274176836013794e-01
    z[0,1,2]  R135      2.3225225508213043e-01
    z[0,1,2]  R136      -5.5932450294494629e-01
    z[0,1,2]  R137      1.0764485597610474e-01
    z[0,1,2]  R138      -8.8984228670597076e-02
    z[0,1,2]  R139      1.3610440492630005e-01
    z[0,1,2]  R140      -6.8699955940246582e-01
    z[0,1,2]  R141      1.8842889368534088e-01
    z[0,1,2]  R142      1.2623888254165649e-01
    z[0,1,2]  R143      -5.7087469100952148e-01
    z[0,1,2]  R144      2.1743780374526978e-01
    z[0,1,2]  R145      -6.2400847673416138e-01
    z[0,1,2]  R146      3.4387171268463135e-02
    z[0,1,2]  R147      -4.8959305882453918e-01
    z[0,1,2]  R148      2.3180879652500153e-01
    z[0,1,2]  R149      -4.3938422203063965e-01
    z[0,1,2]  R150      -2.0589542388916016e-01
    z[0,1,2]  R151      -1.7205569148063660e-01
    z[0,1,2]  R152      -2.3169048130512238e-02
    z[0,1,2]  R153      6.9852125644683838e-01
    z[0,1,2]  R154      0.470347136259079
    z[0,1,2]  R155      4.5164796710014343e-01
    z[0,1,2]  R156      3.8815578818321228e-01
    z[0,1,2]  R157      3.6491009593009949e-01
    z[0,1,2]  R158      8.3101242780685425e-02
    z[0,1,2]  R159      1.5813589096069336e-01
    z[0,1,2]  R160      4.2543417215347290e-01
    z[0,1,2]  R161      2.5178456306457520e-01
    z[0,1,2]  R162      6.8271708488464355e-01
    z[0,1,2]  R163      -3.4442096948623657e-01
    z[0,1,2]  R164      -1.5313203446567059e-02
    z[0,1,2]  R165      4.7069203108549118e-02
    z[0,1,2]  R166      -2.3530335724353790e-01
    z[0,1,2]  R167      2.4600613117218018e-01
    z[0,1,2]  R168      1.5599825978279114e-01
    z[0,1,2]  R169      1.8806867301464081e-01
    z[0,1,2]  R170      4.3373140692710876e-01
    z[0,1,2]  R171      -9.5579192042350769e-02
    z[0,1,2]  R172      0.0797993540763855
    z[0,1,2]  R173      6.5456248819828033e-02
    z[0,1,2]  R174      -2.2454971075057983e-01
    z[0,1,2]  R175      1.0154710710048676e-01
    z[0,1,2]  R176      3.5156715661287308e-02
    z[0,1,2]  R177      3.8920834660530090e-02
    z[0,1,2]  R178      -5.9202855825424194e-01
    z[0,1,2]  R179      -5.0289428234100342e-01
    z[0,1,2]  R180      -2.5969842076301575e-01
    z[0,1,2]  R181      -2.9287990927696228e-01
    z[0,1,2]  R182      -5.1057970523834229e-01
    z[0,1,2]  R183      -2.9195931553840637e-01
    z[0,1,2]  R184      -1.5345829725265503e-01
    z[0,1,2]  R185      -5.4529237747192383e-01
    z[0,1,2]  R186      -2.5295522809028625e-01
    z[0,1,2]  R187      9.3944780528545380e-02
    z[0,1,2]  R188      -4.6293100714683533e-01
    z[0,1,2]  R189      -6.5030390024185181e-01
    z[0,1,2]  R190      4.0662553906440735e-01
    z[0,1,2]  R191      4.1330105066299438e-01
    z[0,1,2]  R192      -3.1752744317054749e-01
    z[0,1,2]  R193      -8.1574696302413940e-01
    z[0,1,2]  R194      3.1801056861877441e-01
    z[0,1,2]  R195      -7.5886243581771851e-01
    z[0,1,2]  R196      -4.8464578390121460e-01
    z[0,1,2]  R197      -9.4092048704624176e-02
    z[0,1,2]  R198      -2.3630566895008087e-01
    z[0,1,2]  R199      3.9439156651496887e-02
    z[0,1,2]  R200      -5.8352392911911011e-01
    z[0,1,2]  R201      -4.4249197840690613e-01
    z[0,1,2]  R202      -3.7597176432609558e-01
    z[0,1,2]  R203      -1.0341511666774750e-01
    z[0,1,2]  R204      -0.631401777267456
    z[0,1,2]  R205      -1.3033016026020050e-01
    z[0,1,2]  R206      -0.673624575138092
    z[0,1,2]  R207      8.6111530661582947e-02
    z[0,1,2]  R208      -6.5445655584335327e-01
    z[0,1,2]  R209      -7.5995332002639771e-01
    z[0,1,2]  R210      -0.604049563407898
    z[0,1,2]  R211      -2.5753778219223022e-01
    z[0,1,2]  R212      -5.3976607322692871e-01
    z[0,1,2]  R213      4.2098306119441986e-02
    z[0,1,2]  R214      3.4863191843032837e-01
    z[0,1,2]  R215      4.5605354011058807e-02
    z[0,1,2]  R216      -3.8888771086931229e-02
    z[0,1,2]  R217      -2.9725676774978638e-01
    z[0,1,2]  R218      3.8173702359199524e-01
    z[0,1,2]  R219      -1.8941754102706909e-01
    z[0,1,2]  R220      1.1917474865913391e-01
    z[0,1,2]  R221      -7.8999191522598267e-01
    z[0,1,2]  R222      1.3872574269771576e-01
    z[0,1,2]  R223      4.2276558279991150e-01
    z[0,1,2]  R224      4.0643098950386047e-01
    z[0,1,2]  R225      5.0381618738174438e-01
    z[0,1,2]  R226      -3.2543742656707764e-01
    z[0,1,2]  R227      9.7078546881675720e-02
    z[0,1,2]  R228      -2.7968008071184158e-03
    z[0,1,2]  R229      3.8206619024276733e-01
    z[0,1,2]  R230      -2.5693991780281067e-01
    z[0,1,2]  R231      2.8152132034301758e-01
    z[0,1,2]  R232      -6.1093878746032715e-01
    z[0,1,2]  R233      -3.3857741951942444e-01
    z[0,1,2]  R234      -0.472592294216156
    z[0,1,2]  R235      9.7093977034091949e-02
    z[0,1,2]  R236      -2.3159457743167877e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R89       -1
    z[0,1,3]  R90       1
    z[0,1,3]  R97       -5.7408112287521362e-01
    z[0,1,3]  R98       -3.6551985144615173e-01
    z[0,1,3]  R99       -5.9628689289093018e-01
    z[0,1,3]  R100      -2.9741668701171875e-01
    z[0,1,3]  R101      -4.1337344050407410e-01
    z[0,1,3]  R102      2.0641303062438965e-01
    z[0,1,3]  R103      2.1087038516998291e-01
    z[0,1,3]  R104      -7.0434558391571045e-01
    z[0,1,3]  R105      8.4888547658920288e-02
    z[0,1,3]  R106      8.0051563680171967e-02
    z[0,1,3]  R107      7.6750802993774414e-01
    z[0,1,3]  R108      4.0120804309844971e-01
    z[0,1,3]  R109      5.6791716814041138e-01
    z[0,1,3]  R110      -3.0295112729072571e-01
    z[0,1,3]  R111      1.9151894748210907e-01
    z[0,1,3]  R112      1.3078117370605469e-01
    z[0,1,3]  R113      1.4946061372756958e-01
    z[0,1,3]  R114      0.159884512424469
    z[0,1,3]  R115      9.7060039639472961e-02
    z[0,1,3]  R116      2.1969486773014069e-01
    z[0,1,3]  R117      3.3871078491210938e-01
    z[0,1,3]  R118      4.5961785316467285e-01
    z[0,1,3]  R119      7.3579859733581543e-01
    z[0,1,3]  R120      8.0825246870517731e-02
    z[0,1,3]  R121      4.8096778988838196e-01
    z[0,1,3]  R122      8.0494147539138794e-01
    z[0,1,3]  R123      3.7761631608009338e-01
    z[0,1,3]  R124      1.8257418274879456e-01
    z[0,1,3]  R125      6.4273148775100708e-01
    z[0,1,3]  R126      2.2279354929924011e-01
    z[0,1,3]  R127      2.6987805962562561e-01
    z[0,1,3]  R128      1.9493977725505829e-01
    z[0,1,3]  R129      -1.9338284432888031e-01
    z[0,1,3]  R130      -0.388785719871521
    z[0,1,3]  R131      -1.7030143737792969e-01
    z[0,1,3]  R132      -2.7515235543251038e-01
    z[0,1,3]  R133      6.0826158523559570e-01
    z[0,1,3]  R134      1.6258460283279419e-01
    z[0,1,3]  R135      5.2279084920883179e-01
    z[0,1,3]  R136      -5.2511040121316910e-02
    z[0,1,3]  R137      -0.637824296951294
    z[0,1,3]  R138      -1.9327494502067566e-01
    z[0,1,3]  R139      -1.5178553760051727e-01
    z[0,1,3]  R140      5.1419204473495483e-01
    z[0,1,3]  R141      1.2139932811260223e-01
    z[0,1,3]  R142      3.3413335680961609e-02
    z[0,1,3]  R143      -4.9365319311618805e-02
    z[0,1,3]  R144      2.4444395303726196e-01
    z[0,1,3]  R145      -1.7017644643783569e-01
    z[0,1,3]  R146      5.3708422183990479e-01
    z[0,1,3]  R147      6.0811394453048706e-01
    z[0,1,3]  R148      -3.2972010970115662e-01
    z[0,1,3]  R149      7.2953003644943237e-01
    z[0,1,3]  R150      -2.7185928821563721e-01
    z[0,1,3]  R151      8.5692560672760010e-01
    z[0,1,3]  R152      -6.7722752690315247e-02
    z[0,1,3]  R153      -1.6869744658470154e-01
    z[0,1,3]  R154      -1.0491450130939484e-01
    z[0,1,3]  R155      2.3639321327209473e-01
    z[0,1,3]  R156      -5.7837799191474915e-02
    z[0,1,3]  R157      -3.7720409035682678e-01
    z[0,1,3]  R158      -5.0152492523193359e-01
    z[0,1,3]  R159      -0.620127260684967
    z[0,1,3]  R160      -3.0619978904724121e-01
    z[0,1,3]  R161      -4.6318736672401428e-01
    z[0,1,3]  R162      -2.8145933151245117e-01
    z[0,1,3]  R163      -4.9411794543266296e-01
    z[0,1,3]  R164      -4.7303819656372070e-01
    z[0,1,3]  R165      -1.5031154453754425e-01
    z[0,1,3]  R166      -3.8023716211318970e-01
    z[0,1,3]  R167      4.0187767148017883e-01
    z[0,1,3]  R168      3.0618983507156372e-01
    z[0,1,3]  R169      1.4561046659946442e-01
    z[0,1,3]  R170      2.7717188000679016e-01
    z[0,1,3]  R171      3.1537401676177979e-01
    z[0,1,3]  R172      1.7669594287872314e-01
    z[0,1,3]  R173      2.2975522279739380e-01
    z[0,1,3]  R174      3.0813151597976685e-01
    z[0,1,3]  R175      1.8196175992488861e-01
    z[0,1,3]  R176      3.0411624908447266e-01
    z[0,1,3]  R177      -4.7513264417648315e-01
    z[0,1,3]  R178      -2.9910793900489807e-01
    z[0,1,3]  R179      -4.9415990710258484e-01
    z[0,1,3]  R180      -5.3595000505447388e-01
    z[0,1,3]  R181      -7.0295113325119019e-01
    z[0,1,3]  R182      6.3802433013916016e-01
    z[0,1,3]  R183      -5.2820432186126709e-01
    z[0,1,3]  R184      -7.0321941375732422e-01
    z[0,1,3]  R185      -1.1157199740409851e-01
    z[0,1,3]  R186      4.9584048986434937e-01
    z[0,1,3]  R187      6.3299578428268433e-01
    z[0,1,3]  R188      1.0616496205329895e-01
    z[0,1,3]  R189      2.5820401310920715e-01
    z[0,1,3]  R190      7.9184156656265259e-01
    z[0,1,3]  R191      -8.7833821773529053e-02
    z[0,1,3]  R192      -6.3290582038462162e-03
    z[0,1,3]  R193      3.8389280438423157e-01
    z[0,1,3]  R194      5.2608340978622437e-01
    z[0,1,3]  R195      3.3938249945640564e-01
    z[0,1,3]  R196      2.5562044978141785e-01
    z[0,1,3]  R197      -3.0140110850334167e-01
    z[0,1,3]  R198      -2.7371674776077271e-01
    z[0,1,3]  R199      -0.520424485206604
    z[0,1,3]  R200      5.7561047375202179e-02
    z[0,1,3]  R201      -1.3779722154140472e-01
    z[0,1,3]  R202      1.5111909806728363e-01
    z[0,1,3]  R203      7.1562141180038452e-01
    z[0,1,3]  R204      7.0563733577728271e-01
    z[0,1,3]  R205      6.9247573614120483e-01
    z[0,1,3]  R206      3.9864847064018250e-01
    z[0,1,3]  R207      8.6471486091613770e-01
    z[0,1,3]  R208      2.9924002289772034e-01
    z[0,1,3]  R209      9.8448902368545532e-02
    z[0,1,3]  R210      0.0271736029535532
    z[0,1,3]  R211      1.0608037561178207e-01
    z[0,1,3]  R212      1.6946910321712494e-01
    z[0,1,3]  R213      3.3247882127761841e-01
    z[0,1,3]  R214      0.596255898475647
    z[0,1,3]  R215      1.9995900988578796e-01
    z[0,1,3]  R216      2.9122719168663025e-01
    z[0,1,3]  R217      -1.0755251161754131e-02
    z[0,1,3]  R218      -7.1085256338119507e-01
    z[0,1,3]  R219      -7.3259377479553223e-01
    z[0,1,3]  R220      6.1649543046951294e-01
    z[0,1,3]  R221      3.1919321417808533e-01
    z[0,1,3]  R222      0.474653959274292
    z[0,1,3]  R223      5.7778173685073853e-01
    z[0,1,3]  R224      2.9399591684341431e-01
    z[0,1,3]  R225      5.8195346593856812e-01
    z[0,1,3]  R226      4.9630695581436157e-01
    z[0,1,3]  R227      6.5015846490859985e-01
    z[0,1,3]  R228      1.1039676517248154e-01
    z[0,1,3]  R229      4.3881908059120178e-01
    z[0,1,3]  R230      5.5209094285964966e-01
    z[0,1,3]  R231      5.9213083982467651e-01
    z[0,1,3]  R232      0.625938355922699
    z[0,1,3]  R233      6.1959064006805420e-01
    z[0,1,3]  R234      3.7651520967483521e-01
    z[0,1,3]  R235      -4.0214595198631287e-01
    z[0,1,3]  R236      3.4837007522583008e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R91       -1
    z[0,1,4]  R92       1
    z[0,1,4]  R97       8.9604228734970093e-02
    z[0,1,4]  R98       -2.8744882345199585e-01
    z[0,1,4]  R99       2.0206996798515320e-01
    z[0,1,4]  R100      4.4445816427469254e-02
    z[0,1,4]  R101      5.0837200880050659e-01
    z[0,1,4]  R102      -4.3901059031486511e-01
    z[0,1,4]  R103      1.6942851245403290e-01
    z[0,1,4]  R104      -1.9649676978588104e-02
    z[0,1,4]  R105      4.6485564112663269e-01
    z[0,1,4]  R106      -3.1988048553466797e-01
    z[0,1,4]  R107      4.0406605601310730e-01
    z[0,1,4]  R108      -0.0986860916018486
    z[0,1,4]  R109      1.2505438923835754e-01
    z[0,1,4]  R110      -4.3657961487770081e-01
    z[0,1,4]  R111      2.2704254090785980e-01
    z[0,1,4]  R112      -1.2737950682640076e-01
    z[0,1,4]  R113      -1.2335945852100849e-02
    z[0,1,4]  R114      -1.8066802620887756e-01
    z[0,1,4]  R115      1.6324238479137421e-01
    z[0,1,4]  R116      6.8727836012840271e-02
    z[0,1,4]  R117      2.3454587161540985e-01
    z[0,1,4]  R118      5.1327306032180786e-01
    z[0,1,4]  R119      -1.1139550060033798e-01
    z[0,1,4]  R120      3.7365466356277466e-01
    z[0,1,4]  R121      1.5394628047943115e-01
    z[0,1,4]  R122      3.2040628790855408e-01
    z[0,1,4]  R123      3.3972853422164917e-01
    z[0,1,4]  R124      -6.4457327127456665e-02
    z[0,1,4]  R125      -2.8373605012893677e-01
    z[0,1,4]  R126      -3.2385626435279846e-01
    z[0,1,4]  R127      3.6158025264739990e-02
    z[0,1,4]  R128      2.8707557916641235e-01
    z[0,1,4]  R129      -2.1785897016525269e-01
    z[0,1,4]  R130      1.3910777866840363e-01
    z[0,1,4]  R131      -3.3459064364433289e-01
    z[0,1,4]  R132      -6.3165277242660522e-02
    z[0,1,4]  R133      -3.0165541172027588e-01
    z[0,1,4]  R134      3.2457414269447327e-01
    z[0,1,4]  R135      -6.5735457465052605e-03
    z[0,1,4]  R136      -4.6645230054855347e-01
    z[0,1,4]  R137      -2.1367374062538147e-01
    z[0,1,4]  R138      2.4187627434730530e-01
    z[0,1,4]  R139      0.53766930103302
    z[0,1,4]  R140      -3.9414870738983154e-01
    z[0,1,4]  R141      3.7524050474166870e-01
    z[0,1,4]  R142      -4.3254144489765167e-02
    z[0,1,4]  R143      -1.3490395247936249e-01
    z[0,1,4]  R144      -2.7130043506622314e-01
    z[0,1,4]  R145      -1.6369469463825226e-02
    z[0,1,4]  R146      8.4502868354320526e-02
    z[0,1,4]  R147      2.5334203243255615e-01
    z[0,1,4]  R148      -3.5510438680648804e-01
    z[0,1,4]  R149      -4.4641056656837463e-01
    z[0,1,4]  R150      1.5092290937900543e-02
    z[0,1,4]  R151      -2.3525262251496315e-02
    z[0,1,4]  R152      -0.0577346533536911
    z[0,1,4]  R153      6.4896240830421448e-02
    z[0,1,4]  R154      -1.4085040986537933e-01
    z[0,1,4]  R155      9.8788976669311523e-02
    z[0,1,4]  R156      -4.1376795619726181e-02
    z[0,1,4]  R157      -3.2421648502349854e-01
    z[0,1,4]  R158      -0.287641316652298
    z[0,1,4]  R159      -2.5535440444946289e-01
    z[0,1,4]  R160      -6.8725836277008057e-01
    z[0,1,4]  R161      1.0965451598167419e-01
    z[0,1,4]  R162      -8.6141265928745270e-02
    z[0,1,4]  R163      -3.9865094423294067e-01
    z[0,1,4]  R164      -1.8897384405136108e-01
    z[0,1,4]  R165      2.6522138714790344e-01
    z[0,1,4]  R166      1.8102388083934784e-01
    z[0,1,4]  R167      -7.8041076660156250e-02
    z[0,1,4]  R168      -2.4372771382331848e-01
    z[0,1,4]  R169      1.0159488767385483e-01
    z[0,1,4]  R170      3.1711183488368988e-02
    z[0,1,4]  R171      1.2975813448429108e-01
    z[0,1,4]  R172      3.6978356540203094e-02
    z[0,1,4]  R173      4.7158572822809219e-02
    z[0,1,4]  R174      -2.0836353302001953e-01
    z[0,1,4]  R175      -7.6501868665218353e-02
    z[0,1,4]  R176      -2.3105712607502937e-03
    z[0,1,4]  R177      -2.3320877552032471e-01
    z[0,1,4]  R178      -1.1149710416793823e-01
    z[0,1,4]  R179      1.9031253457069397e-01
    z[0,1,4]  R180      -2.6426789164543152e-01
    z[0,1,4]  R181      3.6705070734024048e-01
    z[0,1,4]  R182      3.2231593132019043e-01
    z[0,1,4]  R183      -1.2098166346549988e-01
    z[0,1,4]  R184      4.6424347907304764e-02
    z[0,1,4]  R185      -2.0061565935611725e-01
    z[0,1,4]  R186      -3.2303226180374622e-03
    z[0,1,4]  R187      -1.9778303802013397e-01
    z[0,1,4]  R188      2.3271875083446503e-01
    z[0,1,4]  R189      -2.0879207551479340e-01
    z[0,1,4]  R190      -1.4656364917755127e-01
    z[0,1,4]  R191      3.8150716572999954e-02
    z[0,1,4]  R192      1.2002401798963547e-01
    z[0,1,4]  R193      3.2161605358123779e-01
    z[0,1,4]  R194      4.0730339288711548e-01
    z[0,1,4]  R195      4.8944327980279922e-02
    z[0,1,4]  R196      3.6813560128211975e-01
    z[0,1,4]  R197      -1.9165527820587158e-01
    z[0,1,4]  R198      4.9533969163894653e-01
    z[0,1,4]  R199      3.0061343312263489e-01
    z[0,1,4]  R200      2.9962889850139618e-02
    z[0,1,4]  R201      4.4709322974085808e-03
    z[0,1,4]  R202      -1.3671702146530151e-01
    z[0,1,4]  R203      1.6357812285423279e-01
    z[0,1,4]  R204      1.9558621942996979e-01
    z[0,1,4]  R205      3.6986431479454041e-01
    z[0,1,4]  R206      2.1674321591854095e-01
    z[0,1,4]  R207      -4.2414046823978424e-02
    z[0,1,4]  R208      -1.7318703234195709e-02
    z[0,1,4]  R209      3.6371055245399475e-01
    z[0,1,4]  R210      4.8381996154785156e-01
    z[0,1,4]  R211      -3.2471738755702972e-02
    z[0,1,4]  R212      5.8499181270599365e-01
    z[0,1,4]  R213      4.3477073311805725e-01
    z[0,1,4]  R214      1.2443201988935471e-01
    z[0,1,4]  R215      1.5923465788364410e-01
    z[0,1,4]  R216      4.4488483667373657e-01
    z[0,1,4]  R217      -1.4953131973743439e-01
    z[0,1,4]  R218      6.2398705631494522e-02
    z[0,1,4]  R219      2.5058604776859283e-02
    z[0,1,4]  R220      -4.4366973638534546e-01
    z[0,1,4]  R221      2.5789496302604675e-01
    z[0,1,4]  R222      4.7080650925636292e-01
    z[0,1,4]  R223      -1.0918192565441132e-03
    z[0,1,4]  R224      -1.5598331391811371e-01
    z[0,1,4]  R225      4.9181395769119263e-01
    z[0,1,4]  R226      7.5598949193954468e-01
    z[0,1,4]  R227      -1.1459868401288986e-01
    z[0,1,4]  R228      -3.6937814950942993e-01
    z[0,1,4]  R229      3.9902281761169434e-01
    z[0,1,4]  R230      2.1089439094066620e-01
    z[0,1,4]  R231      3.0564457178115845e-01
    z[0,1,4]  R232      2.1205591037869453e-02
    z[0,1,4]  R233      6.6968256235122681e-01
    z[0,1,4]  R234      3.4454742074012756e-01
    z[0,1,4]  R235      4.2818868532776833e-03
    z[0,1,4]  R236      4.8093062639236450e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R93       -1
    z[0,1,5]  R94       1
    z[0,1,5]  R97       1.2492982298135757e-01
    z[0,1,5]  R98       0.175779327750206
    z[0,1,5]  R99       3.8542658090591431e-02
    z[0,1,5]  R100      -5.6672483682632446e-01
    z[0,1,5]  R101      -5.7694405317306519e-01
    z[0,1,5]  R102      3.2612487673759460e-01
    z[0,1,5]  R103      -2.9808858036994934e-01
    z[0,1,5]  R104      -4.0076601505279541e-01
    z[0,1,5]  R105      -3.8645300269126892e-01
    z[0,1,5]  R106      1.7766506969928741e-01
    z[0,1,5]  R107      -1.6486328095197678e-02
    z[0,1,5]  R108      0.503727912902832
    z[0,1,5]  R109      0.0744536742568016
    z[0,1,5]  R110      -9.5156140625476837e-02
    z[0,1,5]  R111      1.6693204641342163e-01
    z[0,1,5]  R112      0.0472993366420269
    z[0,1,5]  R113      1.6686005890369415e-01
    z[0,1,5]  R114      1.1024153977632523e-01
    z[0,1,5]  R115      2.0623014867305756e-01
    z[0,1,5]  R116      6.2137570232152939e-02
    z[0,1,5]  R117      9.5437504351139069e-02
    z[0,1,5]  R118      -6.5168537199497223e-02
    z[0,1,5]  R119      2.6004728674888611e-01
    z[0,1,5]  R120      -5.0996005535125732e-01
    z[0,1,5]  R121      -8.8554620742797852e-02
    z[0,1,5]  R122      -2.4945183098316193e-01
    z[0,1,5]  R123      -1.1956793069839478e-01
    z[0,1,5]  R124      2.5355464220046997e-01
    z[0,1,5]  R125      -1.7481237649917603e-01
    z[0,1,5]  R126      1.9550228118896484e-01
    z[0,1,5]  R127      1.8047341704368591e-01
    z[0,1,5]  R128      -3.0346742272377014e-01
    z[0,1,5]  R129      -7.9076945781707764e-02
    z[0,1,5]  R130      -1.2368068844079971e-01
    z[0,1,5]  R131      -3.5012704133987427e-01
    z[0,1,5]  R132      -3.4012833237648010e-01
    z[0,1,5]  R133      7.3924213647842407e-02
    z[0,1,5]  R134      6.5081994980573654e-03
    z[0,1,5]  R135      3.1589362025260925e-01
    z[0,1,5]  R136      -1.6483667492866516e-01
    z[0,1,5]  R137      -7.4559226632118225e-02
    z[0,1,5]  R138      -5.8781629800796509e-01
    z[0,1,5]  R139      -3.9033353328704834e-01
    z[0,1,5]  R140      -5.8267004787921906e-02
    z[0,1,5]  R141      4.9076753854751587e-01
    z[0,1,5]  R142      0.244783416390419
    z[0,1,5]  R143      -2.7149847149848938e-01
    z[0,1,5]  R144      6.3544875383377075e-01
    z[0,1,5]  R145      -2.7017769217491150e-01
    z[0,1,5]  R146      3.8683155179023743e-01
    z[0,1,5]  R147      5.0349522382020950e-02
    z[0,1,5]  R148      9.5458760857582092e-02
    z[0,1,5]  R149      1.5454442799091339e-01
    z[0,1,5]  R150      -4.0873834490776062e-01
    z[0,1,5]  R151      2.3882275447249413e-02
    z[0,1,5]  R152      5.4946172237396240e-01
    z[0,1,5]  R153      2.4371053278446198e-01
    z[0,1,5]  R154      4.0685775876045227e-01
    z[0,1,5]  R155      2.0834033191204071e-01
    z[0,1,5]  R156      2.9766580462455750e-01
    z[0,1,5]  R157      -7.6462127268314362e-02
    z[0,1,5]  R158      3.5775130987167358e-01
    z[0,1,5]  R159      -5.0992354750633240e-02
    z[0,1,5]  R160      6.8135358393192291e-02
    z[0,1,5]  R161      4.2147073149681091e-01
    z[0,1,5]  R162      9.6685782074928284e-02
    z[0,1,5]  R163      2.4848919361829758e-02
    z[0,1,5]  R164      3.7973019480705261e-01
    z[0,1,5]  R165      -3.8027125597000122e-01
    z[0,1,5]  R166      -2.2399128973484039e-01
    z[0,1,5]  R167      1.3740417361259460e-01
    z[0,1,5]  R168      3.0534034967422485e-01
    z[0,1,5]  R169      3.5866221785545349e-01
    z[0,1,5]  R170      5.9211300686001778e-03
    z[0,1,5]  R171      -1.6443461179733276e-02
    z[0,1,5]  R172      2.0932057499885559e-01
    z[0,1,5]  R173      3.7273299694061279e-01
    z[0,1,5]  R174      2.1522977948188782e-01
    z[0,1,5]  R175      0.511130690574646
    z[0,1,5]  R176      3.6250913143157959e-01
    z[0,1,5]  R177      -0.648076057434082
    z[0,1,5]  R178      0.0657590702176094
    z[0,1,5]  R179      -2.9661828279495239e-01
    z[0,1,5]  R180      -7.6879158616065979e-02
    z[0,1,5]  R181      -2.1222910284996033e-01
    z[0,1,5]  R182      1.6392305493354797e-01
    z[0,1,5]  R183      -4.2393404245376587e-01
    z[0,1,5]  R184      -1.5759025514125824e-01
    z[0,1,5]  R185      -3.9872181415557861e-01
    z[0,1,5]  R186      7.0305779576301575e-02
    z[0,1,5]  R187      4.1900908946990967e-01
    z[0,1,5]  R188      1.4060950279235840e-01
    z[0,1,5]  R189      -4.0386593341827393e-01
    z[0,1,5]  R190      2.3328746855258942e-01
    z[0,1,5]  R191      1.4735272526741028e-01
    z[0,1,5]  R192      -1.0939425788819790e-02
    z[0,1,5]  R193      -2.9343429952859879e-02
    z[0,1,5]  R194      6.4921337366104126e-01
    z[0,1,5]  R195      5.4124879837036133e-01
    z[0,1,5]  R196      -2.0792341232299805e-01
    z[0,1,5]  R197      2.0585437119007111e-01
    z[0,1,5]  R198      -9.0375185012817383e-02
    z[0,1,5]  R199      -4.8706404864788055e-02
    z[0,1,5]  R200      -1.5952616930007935e-01
    z[0,1,5]  R201      -4.9883734434843063e-02
    z[0,1,5]  R202      -3.8910800218582153e-01
    z[0,1,5]  R203      4.2181101441383362e-01
    z[0,1,5]  R204      -1.6269692778587341e-01
    z[0,1,5]  R205      -1.3045889139175415e-01
    z[0,1,5]  R206      8.8567227125167847e-02
    z[0,1,5]  R207      3.1192660331726074e-01
    z[0,1,5]  R208      3.9336517453193665e-01
    z[0,1,5]  R209      2.0151710510253906e-01
    z[0,1,5]  R210      9.1979645192623138e-02
    z[0,1,5]  R211      -4.3433707207441330e-02
    z[0,1,5]  R212      -3.8120919466018677e-01
    z[0,1,5]  R213      -1.0739266127347946e-01
    z[0,1,5]  R214      1.6362212598323822e-01
    z[0,1,5]  R215      -3.6934378743171692e-01
    z[0,1,5]  R216      -4.7725012898445129e-01
    z[0,1,5]  R217      -0.523442268371582
    z[0,1,5]  R218      -2.9658830165863037e-01
    z[0,1,5]  R219      2.5670301169157028e-02
    z[0,1,5]  R220      8.1822425127029419e-02
    z[0,1,5]  R221      -6.0947993770241737e-03
    z[0,1,5]  R222      3.6438152194023132e-01
    z[0,1,5]  R223      -3.4555536508560181e-01
    z[0,1,5]  R224      -4.6714732050895691e-01
    z[0,1,5]  R225      1.2319060415029526e-01
    z[0,1,5]  R226      5.1724273711442947e-02
    z[0,1,5]  R227      2.0836119353771210e-01
    z[0,1,5]  R228      -2.1691080927848816e-01
    z[0,1,5]  R229      1.4422725141048431e-01
    z[0,1,5]  R230      -9.9152170121669769e-02
    z[0,1,5]  R231      -1.5527497231960297e-01
    z[0,1,5]  R232      3.7689003348350525e-01
    z[0,1,5]  R233      -8.8169820606708527e-02
    z[0,1,5]  R234      2.3336377739906311e-01
    z[0,1,5]  R235      -1.3693358004093170e-01
    z[0,1,5]  R236      4.8149690032005310e-02
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R95       -1
    z[0,1,6]  R96       1
    z[0,1,6]  R97       1.3191461563110352e-01
    z[0,1,6]  R98       0.0874442458152771
    z[0,1,6]  R99       -4.4186714291572571e-01
    z[0,1,6]  R100      -3.0732482671737671e-01
    z[0,1,6]  R101      -5.3932290524244308e-02
    z[0,1,6]  R102      -0.401030957698822
    z[0,1,6]  R103      -2.5396207347512245e-02
    z[0,1,6]  R104      -4.6218344569206238e-01
    z[0,1,6]  R105      -3.9516305923461914e-01
    z[0,1,6]  R106      -4.1228723526000977e-01
    z[0,1,6]  R107      3.7462085485458374e-01
    z[0,1,6]  R108      5.2376669645309448e-01
    z[0,1,6]  R109      -1.5266944468021393e-01
    z[0,1,6]  R110      2.0077311992645264e-01
    z[0,1,6]  R111      2.9434624314308167e-01
    z[0,1,6]  R112      0.16197469830513
    z[0,1,6]  R113      0.0212846789509058
    z[0,1,6]  R114      6.1095900833606720e-02
    z[0,1,6]  R115      -2.5218958035111427e-02
    z[0,1,6]  R116      -1.1041018366813660e-01
    z[0,1,6]  R117      1.9928197562694550e-01
    z[0,1,6]  R118      8.4426812827587128e-03
    z[0,1,6]  R119      -4.0857456624507904e-02
    z[0,1,6]  R120      0.0263714250177145
    z[0,1,6]  R121      -3.8630792498588562e-01
    z[0,1,6]  R122      -2.9359987378120422e-01
    z[0,1,6]  R123      -6.8870788812637329e-01
    z[0,1,6]  R124      5.9921962022781372e-01
    z[0,1,6]  R125      -3.0938610434532166e-02
    z[0,1,6]  R126      2.7243435382843018e-01
    z[0,1,6]  R127      -4.6066647768020630e-01
    z[0,1,6]  R128      -2.8735786676406860e-01
    z[0,1,6]  R129      -1.0418348759412766e-01
    z[0,1,6]  R130      3.6686885356903076e-01
    z[0,1,6]  R131      1.9505521282553673e-02
    z[0,1,6]  R132      5.7073158025741577e-01
    z[0,1,6]  R133      -1.5794268250465393e-01
    z[0,1,6]  R134      3.0939567089080811e-01
    z[0,1,6]  R135      2.5403586030006409e-01
    z[0,1,6]  R136      3.1916892528533936e-01
    z[0,1,6]  R137      2.3045334219932556e-01
    z[0,1,6]  R138      2.3487238585948944e-01
    z[0,1,6]  R139      1.5198100358247757e-02
    z[0,1,6]  R140      -1.3912385702133179e-01
    z[0,1,6]  R141      2.2606596350669861e-01
    z[0,1,6]  R142      2.0908632874488831e-01
    z[0,1,6]  R143      5.1905751228332520e-01
    z[0,1,6]  R144      -1.1375757306814194e-01
    z[0,1,6]  R145      3.3053648471832275e-01
    z[0,1,6]  R146      -1.7875127494335175e-01
    z[0,1,6]  R147      -1.7471471428871155e-01
    z[0,1,6]  R148      -3.0696097016334534e-01
    z[0,1,6]  R149      -1.4413294196128845e-01
    z[0,1,6]  R150      -1.9780771806836128e-02
    z[0,1,6]  R151      -4.2399564385414124e-01
    z[0,1,6]  R152      3.5136872529983521e-01
    z[0,1,6]  R153      2.3495469987392426e-01
    z[0,1,6]  R154      -0.0321926586329937
    z[0,1,6]  R155      5.2557539194822311e-02
    z[0,1,6]  R156      2.3745338618755341e-01
    z[0,1,6]  R157      -0.383847177028656
    z[0,1,6]  R158      2.1412980556488037e-01
    z[0,1,6]  R159      4.4229626655578613e-02
    z[0,1,6]  R160      -1.1348040401935577e-01
    z[0,1,6]  R161      -7.0780552923679352e-02
    z[0,1,6]  R162      2.3420266807079315e-01
    z[0,1,6]  R163      -3.5714048147201538e-01
    z[0,1,6]  R164      -4.1779378056526184e-01
    z[0,1,6]  R165      -9.8797872662544250e-02
    z[0,1,6]  R166      -2.7079728245735168e-01
    z[0,1,6]  R167      -2.8398019075393677e-01
    z[0,1,6]  R168      2.7448818087577820e-01
    z[0,1,6]  R169      -3.8419350981712341e-02
    z[0,1,6]  R170      9.7134284675121307e-02
    z[0,1,6]  R171      -2.4830566346645355e-01
    z[0,1,6]  R172      -1.3310468196868896e-01
    z[0,1,6]  R173      3.7576359510421753e-01
    z[0,1,6]  R174      -2.8193789720535278e-01
    z[0,1,6]  R175      4.6669259667396545e-02
    z[0,1,6]  R176      -4.4715738296508789e-01
    z[0,1,6]  R177      4.4310346245765686e-02
    z[0,1,6]  R178      1.8833646178245544e-01
    z[0,1,6]  R179      -0.0983353853225708
    z[0,1,6]  R180      1.8292682245373726e-02
    z[0,1,6]  R181      1.5415126085281372e-01
    z[0,1,6]  R182      1.4263746142387390e-01
    z[0,1,6]  R183      4.6091634035110474e-01
    z[0,1,6]  R184      3.7453049421310425e-01
    z[0,1,6]  R185      6.3131886720657349e-01
    z[0,1,6]  R186      -1.3046045601367950e-01
    z[0,1,6]  R187      7.2290033102035522e-02
    z[0,1,6]  R188      3.5995218157768250e-01
    z[0,1,6]  R189      1.5154068171977997e-01
    z[0,1,6]  R190      -1.5079037845134735e-01
    z[0,1,6]  R191      1.1484432965517044e-01
    z[0,1,6]  R192      -0.736470639705658
    z[0,1,6]  R193      5.0123695284128189e-02
    z[0,1,6]  R194      1.2904106080532074e-01
    z[0,1,6]  R195      7.2645372711122036e-03
    z[0,1,6]  R196      7.1147575974464417e-02
    z[0,1,6]  R197      3.2846489548683167e-01
    z[0,1,6]  R198      -1.5908074378967285e-01
    z[0,1,6]  R199      -4.5059084892272949e-01
    z[0,1,6]  R200      -3.3879649639129639e-01
    z[0,1,6]  R201      -3.3033692836761475e-01
    z[0,1,6]  R202      7.6765216886997223e-02
    z[0,1,6]  R203      -2.9396224021911621e-01
    z[0,1,6]  R204      4.3577242642641068e-02
    z[0,1,6]  R205      1.2319776415824890e-01
    z[0,1,6]  R206      -5.3875666856765747e-01
    z[0,1,6]  R207      8.8483437895774841e-02
    z[0,1,6]  R208      2.8057926893234253e-01
    z[0,1,6]  R209      -6.0776922851800919e-02
    z[0,1,6]  R210      3.0879381299018860e-01
    z[0,1,6]  R211      -3.5192728042602539e-01
    z[0,1,6]  R212      -2.6379138231277466e-01
    z[0,1,6]  R213      4.2512655258178711e-02
    z[0,1,6]  R214      -1.8563105165958405e-01
    z[0,1,6]  R215      3.3686894178390503e-01
    z[0,1,6]  R216      -9.7422868013381958e-02
    z[0,1,6]  R217      2.1099606156349182e-01
    z[0,1,6]  R218      2.7201318740844727e-01
    z[0,1,6]  R219      5.4628539085388184e-01
    z[0,1,6]  R220      5.2705843001604080e-02
    z[0,1,6]  R221      -8.0805547535419464e-02
    z[0,1,6]  R222      -3.9299684762954712e-01
    z[0,1,6]  R223      1.1600001901388168e-01
    z[0,1,6]  R224      1.1144879460334778e-01
    z[0,1,6]  R225      2.8317835927009583e-01
    z[0,1,6]  R226      2.0880098640918732e-01
    z[0,1,6]  R227      2.0675741136074066e-01
    z[0,1,6]  R228      4.8996829986572266e-01
    z[0,1,6]  R229      -2.7041694149374962e-02
    z[0,1,6]  R230      9.9062584340572357e-02
    z[0,1,6]  R231      -4.4209539890289307e-01
    z[0,1,6]  R232      -5.9952650219202042e-02
    z[0,1,6]  R233      2.1013806760311127e-01
    z[0,1,6]  R234      -3.7109214812517166e-02
    z[0,1,6]  R235      0.456543892621994
    z[0,1,6]  R236      3.6825588345527649e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R237      -1
    z[1,0,0]  R238      1
    z[1,0,0]  R251      -6.5858542919158936e-01
    z[1,0,0]  R252      -6.5801924467086792e-01
    z[1,0,0]  R253      -7.1887493133544922e-01
    z[1,0,0]  R254      -4.1052407026290894e-01
    z[1,0,0]  R255      -7.1989625692367554e-01
    z[1,0,0]  R256      -0.59494549036026
    z[1,0,0]  R257      -5.6977653503417969e-01
    z[1,0,0]  R258      -6.3382625579833984e-01
    z[1,0,0]  R259      -0.820820689201355
    z[1,0,0]  R260      -0.791208803653717
    z[1,0,0]  R261      -1.5829540789127350e-01
    z[1,0,0]  R262      1.0571720451116562e-01
    z[1,0,0]  R263      9.0164765715599060e-02
    z[1,0,0]  R264      2.3170144855976105e-01
    z[1,0,0]  R265      1.9998101890087128e-01
    z[1,0,0]  R266      4.8847761750221252e-01
    z[1,0,0]  R267      2.9615685343742371e-01
    z[1,0,0]  R268      3.3222836256027222e-01
    z[1,0,0]  R269      3.5924544930458069e-01
    z[1,0,0]  R270      2.8316259384155273e-01
    z[1,0,0]  R271      4.6913135051727295e-01
    z[1,0,0]  R272      5.9548223018646240e-01
    z[1,0,0]  R273      5.5419504642486572e-01
    z[1,0,0]  R274      7.1332257986068726e-01
    z[1,0,0]  R275      0.413044273853302
    z[1,0,0]  R276      -4.1304641962051392e-01
    z[1,0,0]  R277      4.5895689725875854e-01
    z[1,0,0]  R278      5.3956449031829834e-01
    z[1,0,0]  R279      1.8347802758216858e-01
    z[1,0,0]  R280      8.0835449695587158e-01
    z[1,0,0]  R281      -2.6094338297843933e-01
    z[1,0,0]  R282      -1.0375731438398361e-01
    z[1,0,0]  R283      -1.1744309961795807e-01
    z[1,0,0]  R284      1.6161955893039703e-01
    z[1,0,0]  R285      4.5744961500167847e-01
    z[1,0,0]  R286      2.7871596813201904e-01
    z[1,0,0]  R287      2.7719014883041382e-01
    z[1,0,0]  R288      1.2179224193096161e-01
    z[1,0,0]  R289      -6.3695102930068970e-02
    z[1,0,0]  R290      0.629237711429596
    z[1,0,0]  R291      3.9095136523246765e-01
    z[1,0,0]  R292      3.6560770124197006e-02
    z[1,0,0]  R293      1.7770273983478546e-01
    z[1,0,0]  R294      1.4492644369602203e-01
    z[1,0,0]  R295      0.556480348110199
    z[1,0,0]  R296      5.0131708383560181e-01
    z[1,0,0]  R297      2.5523781776428223e-01
    z[1,0,0]  R298      -1.5742602944374084e-01
    z[1,0,0]  R299      4.6901664137840271e-01
    z[1,0,0]  R300      -0.0424308106303215
    z[1,0,0]  R301      2.9013910889625549e-01
    z[1,0,0]  R302      -2.6687833666801453e-01
    z[1,0,0]  R303      8.5017897188663483e-02
    z[1,0,0]  R304      -1.7064388096332550e-01
    z[1,0,0]  R305      7.6443380117416382e-01
    z[1,0,0]  R306      1.9689476490020752e-01
    z[1,0,0]  R307      8.2556062936782837e-01
    z[1,0,0]  R308      -1.2607698142528534e-01
    z[1,0,0]  R309      7.0532029867172241e-01
    z[1,0,0]  R310      0.554187536239624
    z[1,0,0]  R311      0.498337984085083
    z[1,0,0]  R312      1.3690540194511414e-01
    z[1,0,0]  R313      2.0153930783271790e-01
    z[1,0,0]  R314      3.8671070337295532e-01
    z[1,0,0]  R315      -7.6744019985198975e-02
    z[1,0,0]  R316      2.1289205551147461e-01
    z[1,0,0]  R317      -1.2130734324455261e-01
    z[1,0,0]  R318      4.4750612229108810e-02
    z[1,0,0]  R319      -1.3699607551097870e-01
    z[1,0,0]  R320      1.7185197770595551e-01
    z[1,0,0]  R321      3.0488875508308411e-01
    z[1,0,0]  R322      -2.1510450541973114e-01
    z[1,0,0]  R323      -4.6034038066864014e-01
    z[1,0,0]  R324      4.8502811789512634e-01
    z[1,0,0]  R325      3.1340980529785156e-01
    z[1,0,0]  R326      -3.1027961522340775e-02
    z[1,0,0]  R327      1.2311228550970554e-02
    z[1,0,0]  R328      6.5089219808578491e-01
    z[1,0,0]  R329      2.2151054814457893e-02
    z[1,0,0]  R330      6.4380139112472534e-01
    z[1,0,0]  R331      4.9490082263946533e-01
    z[1,0,0]  R332      4.1498789191246033e-01
    z[1,0,0]  R333      5.6200385093688965e-01
    z[1,0,0]  R334      -2.7195507287979126e-01
    z[1,0,0]  R335      -1.5923419594764709e-01
    z[1,0,0]  R336      1.1338619142770767e-01
    z[1,0,0]  R337      -5.6006636470556259e-02
    z[1,0,0]  R338      -2.2266621887683868e-01
    z[1,0,0]  R339      1.8465099856257439e-02
    z[1,0,0]  R340      6.4370214939117432e-02
    z[1,0,0]  R341      1.5307880938053131e-01
    z[1,0,0]  R342      7.3211260139942169e-02
    z[1,0,0]  R343      3.4881255030632019e-01
    z[1,0,0]  R344      -3.8617795705795288e-01
    z[1,0,0]  R345      -1.6033592820167542e-01
    z[1,0,0]  R346      -5.0186461210250854e-01
    z[1,0,0]  R347      -4.7637766599655151e-01
    z[1,0,0]  R348      -0.341469407081604
    z[1,0,0]  R349      -4.7362893819808960e-01
    z[1,0,0]  R350      -2.7223885059356689e-01
    z[1,0,0]  R351      2.4971213936805725e-01
    z[1,0,0]  R352      -6.0493912547826767e-02
    z[1,0,0]  R353      -0.0623035691678524
    z[1,0,0]  R354      1.6990311443805695e-02
    z[1,0,0]  R355      3.0292698740959167e-01
    z[1,0,0]  R356      -1.4488242566585541e-01
    z[1,0,0]  R357      2.6645186543464661e-01
    z[1,0,0]  R358      -1.6680526733398438e-01
    z[1,0,0]  R359      -6.0302621126174927e-01
    z[1,0,0]  R360      -4.7555884718894958e-01
    z[1,0,0]  R361      3.0833488702774048e-01
    z[1,0,0]  R362      3.6954346299171448e-01
    z[1,0,0]  R363      1.3853612542152405e-01
    z[1,0,0]  R364      1.1774213053286076e-02
    z[1,0,0]  R365      -3.4528955817222595e-01
    z[1,0,0]  R366      -0.51384037733078
    z[1,0,0]  R367      2.9657664895057678e-01
    z[1,0,0]  R368      3.4071081876754761e-01
    z[1,0,0]  R369      4.9104800820350647e-01
    z[1,0,0]  R370      -5.7003223896026611e-01
    z[1,0,0]  R371      -0.0688767358660698
    z[1,0,0]  R372      -4.3175253272056580e-01
    z[1,0,0]  R373      1.4744243025779724e-01
    z[1,0,0]  R374      -1.8172748386859894e-01
    z[1,0,0]  R375      6.0729360580444336e-01
    z[1,0,0]  R376      7.0505076646804810e-01
    z[1,0,0]  R377      -5.4727524518966675e-01
    z[1,0,0]  R378      6.3396120071411133e-01
    z[1,0,0]  R379      -4.9636000394821167e-01
    z[1,0,0]  R380      7.1425217390060425e-01
    z[1,0,0]  R381      2.8491258621215820e-01
    z[1,0,0]  R382      2.6955893635749817e-01
    z[1,0,0]  R383      1.4603634178638458e-01
    z[1,0,0]  R384      -6.4753681421279907e-02
    z[1,0,0]  R385      2.0705427229404449e-01
    z[1,0,0]  R386      4.6588051319122314e-01
    z[1,0,0]  R387      -6.0379576683044434e-01
    z[1,0,0]  R388      -7.6082962751388550e-01
    z[1,0,0]  R389      -7.6411402225494385e-01
    z[1,0,0]  R390      -8.1588953733444214e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R239      -1
    z[1,0,1]  R240      1
    z[1,0,1]  R251      -1.8033710122108459e-01
    z[1,0,1]  R252      -2.2804026305675507e-01
    z[1,0,1]  R253      -6.2383204698562622e-02
    z[1,0,1]  R254      -2.5859877467155457e-01
    z[1,0,1]  R255      -9.5601566135883331e-02
    z[1,0,1]  R256      -1.7058271169662476e-01
    z[1,0,1]  R257      -1.5964622795581818e-01
    z[1,0,1]  R258      -1.4073713123798370e-01
    z[1,0,1]  R259      -2.7701035141944885e-01
    z[1,0,1]  R260      -1.3329532742500305e-01
    z[1,0,1]  R261      0.804551362991333
    z[1,0,1]  R262      8.0172097682952881e-01
    z[1,0,1]  R263      8.9155030250549316e-01
    z[1,0,1]  R264      8.1907963752746582e-01
    z[1,0,1]  R265      8.7900412082672119e-01
    z[1,0,1]  R266      8.1295800209045410e-01
    z[1,0,1]  R267      7.5687986612319946e-01
    z[1,0,1]  R268      7.5830638408660889e-01
    z[1,0,1]  R269      7.4715173244476318e-01
    z[1,0,1]  R270      7.0336920022964478e-01
    z[1,0,1]  R271      -2.7622026205062866e-01
    z[1,0,1]  R272      -3.9142203330993652e-01
    z[1,0,1]  R273      -0.248797208070755
    z[1,0,1]  R274      -2.4576936662197113e-01
    z[1,0,1]  R275      -2.1434900164604187e-01
    z[1,0,1]  R276      1.0257773846387863e-01
    z[1,0,1]  R277      -1.3534389436244965e-01
    z[1,0,1]  R278      -1.5342769026756287e-01
    z[1,0,1]  R279      -2.4239315092563629e-01
    z[1,0,1]  R280      1.2143120914697647e-01
    z[1,0,1]  R281      5.4998785257339478e-01
    z[1,0,1]  R282      -7.4844092130661011e-01
    z[1,0,1]  R283      -5.1669752597808838e-01
    z[1,0,1]  R284      2.8788894414901733e-01
    z[1,0,1]  R285      -7.5884765386581421e-01
    z[1,0,1]  R286      -5.1433372497558594e-01
    z[1,0,1]  R287      -5.9484966099262238e-02
    z[1,0,1]  R288      5.6977644562721252e-02
    z[1,0,1]  R289      -9.7424782812595367e-02
    z[1,0,1]  R290      3.4643688797950745e-01
    z[1,0,1]  R291      -7.4864143133163452e-01
    z[1,0,1]  R292      -7.6750653982162476e-01
    z[1,0,1]  R293      -0.63265460729599
    z[1,0,1]  R294      -7.0288920402526855e-01
    z[1,0,1]  R295      -6.0325086116790771e-01
    z[1,0,1]  R296      -6.3913995027542114e-01
    z[1,0,1]  R297      3.4777700901031494e-01
    z[1,0,1]  R298      1.0955148190259933e-01
    z[1,0,1]  R299      3.3840516209602356e-01
    z[1,0,1]  R300      2.0106829702854156e-01
    z[1,0,1]  R301      2.3183113336563110e-01
    z[1,0,1]  R302      4.2090049386024475e-01
    z[1,0,1]  R303      4.7850003838539124e-01
    z[1,0,1]  R304      5.1707899570465088e-01
    z[1,0,1]  R305      4.5963954925537109e-01
    z[1,0,1]  R306      2.8990250825881958e-01
    z[1,0,1]  R307      6.1392839998006821e-02
    z[1,0,1]  R308      -6.5599137544631958e-01
    z[1,0,1]  R309      4.3035867810249329e-01
    z[1,0,1]  R310      4.1396754980087280e-01
    z[1,0,1]  R311      -5.6772458553314209e-01
    z[1,0,1]  R312      -4.0542924404144287e-01
    z[1,0,1]  R313      -2.9511788487434387e-01
    z[1,0,1]  R314      4.9987000226974487e-01
    z[1,0,1]  R315      4.4165849685668945e-01
    z[1,0,1]  R316      4.4861632585525513e-01
    z[1,0,1]  R317      0.58297199010849
    z[1,0,1]  R318      -0.700998842716217
    z[1,0,1]  R319      2.2690226137638092e-01
    z[1,0,1]  R320      -0.0210583433508873
    z[1,0,1]  R321      6.1287569999694824e-01
    z[1,0,1]  R322      -7.1970504522323608e-01
    z[1,0,1]  R323      -5.1845723390579224e-01
    z[1,0,1]  R324      5.7428580522537231e-01
    z[1,0,1]  R325      3.9865252375602722e-01
    z[1,0,1]  R326      -2.9648298025131226e-01
    z[1,0,1]  R327      3.0242647975683212e-02
    z[1,0,1]  R328      1.9152933359146118e-01
    z[1,0,1]  R329      7.7534466981887817e-01
    z[1,0,1]  R330      2.0321662724018097e-01
    z[1,0,1]  R331      -2.3231776058673859e-01
    z[1,0,1]  R332      -4.2521899938583374e-01
    z[1,0,1]  R333      -2.8838777542114258e-01
    z[1,0,1]  R334      -2.9415807127952576e-01
    z[1,0,1]  R335      -1.8136461079120636e-01
    z[1,0,1]  R336      0.614677906036377
    z[1,0,1]  R337      8.8259148597717285e-01
    z[1,0,1]  R338      -1.2112042307853699e-01
    z[1,0,1]  R339      -2.1046364307403564e-01
    z[1,0,1]  R340      8.1843149662017822e-01
    z[1,0,1]  R341      1.2217903882265091e-01
    z[1,0,1]  R342      4.1422221064567566e-01
    z[1,0,1]  R343      -5.2835303544998169e-01
    z[1,0,1]  R344      -6.0785013437271118e-01
    z[1,0,1]  R345      2.9621484875679016e-01
    z[1,0,1]  R346      1.9389666616916656e-01
    z[1,0,1]  R347      -1.0692614316940308e-01
    z[1,0,1]  R348      3.5085476934909821e-02
    z[1,0,1]  R349      0.0629362165927887
    z[1,0,1]  R350      1.1717350780963898e-01
    z[1,0,1]  R351      4.6073517203330994e-01
    z[1,0,1]  R352      7.1917676925659180e-01
    z[1,0,1]  R353      5.5513072013854980e-01
    z[1,0,1]  R354      -5.3189247846603394e-01
    z[1,0,1]  R355      1.9663409888744354e-01
    z[1,0,1]  R356      0.213766410946846
    z[1,0,1]  R357      3.8322755694389343e-01
    z[1,0,1]  R358      6.5201544761657715e-01
    z[1,0,1]  R359      3.3321052789688110e-01
    z[1,0,1]  R360      6.9712668657302856e-01
    z[1,0,1]  R361      6.4458996057510376e-01
    z[1,0,1]  R362      -5.9066683053970337e-01
    z[1,0,1]  R363      -9.1286391019821167e-01
    z[1,0,1]  R364      -0.74636310338974
    z[1,0,1]  R365      -0.783897876739502
    z[1,0,1]  R366      -4.5693665742874146e-01
    z[1,0,1]  R367      -0.637538731098175
    z[1,0,1]  R368      -7.2442001104354858e-01
    z[1,0,1]  R369      -5.1696652173995972e-01
    z[1,0,1]  R370      1.1333186924457550e-01
    z[1,0,1]  R371      -6.8740415573120117e-01
    z[1,0,1]  R372      -5.5598491430282593e-01
    z[1,0,1]  R373      -7.0357513427734375e-01
    z[1,0,1]  R374      2.2914955019950867e-01
    z[1,0,1]  R375      3.8495090603828430e-01
    z[1,0,1]  R376      6.1672019958496094e-01
    z[1,0,1]  R377      1.0403732955455780e-01
    z[1,0,1]  R378      2.6857027783989906e-02
    z[1,0,1]  R379      3.9084741473197937e-01
    z[1,0,1]  R380      -1.0710010677576065e-01
    z[1,0,1]  R381      4.6051979064941406e-01
    z[1,0,1]  R382      -7.3174512386322021e-01
    z[1,0,1]  R383      -9.7263120114803314e-02
    z[1,0,1]  R384      -8.4369462728500366e-01
    z[1,0,1]  R385      1.1094018071889877e-01
    z[1,0,1]  R386      5.9087282419204712e-01
    z[1,0,1]  R387      -1.5158358030021191e-02
    z[1,0,1]  R388      -4.9962759017944336e-02
    z[1,0,1]  R389      -3.1675678491592407e-01
    z[1,0,1]  R390      -1.8333867192268372e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R241      -1
    z[1,0,2]  R242      1
    z[1,0,2]  R251      3.6491009593009949e-01
    z[1,0,2]  R252      8.3101242780685425e-02
    z[1,0,2]  R253      1.5813589096069336e-01
    z[1,0,2]  R254      4.2543417215347290e-01
    z[1,0,2]  R255      2.5178456306457520e-01
    z[1,0,2]  R256      6.8271708488464355e-01
    z[1,0,2]  R257      -3.4442096948623657e-01
    z[1,0,2]  R258      -1.5313203446567059e-02
    z[1,0,2]  R259      4.7069203108549118e-02
    z[1,0,2]  R260      -2.3530335724353790e-01
    z[1,0,2]  R261      2.4600613117218018e-01
    z[1,0,2]  R262      1.5599825978279114e-01
    z[1,0,2]  R263      1.8806867301464081e-01
    z[1,0,2]  R264      4.3373140692710876e-01
    z[1,0,2]  R265      -9.5579192042350769e-02
    z[1,0,2]  R266      0.0797993540763855
    z[1,0,2]  R267      6.5456248819828033e-02
    z[1,0,2]  R268      -2.2454971075057983e-01
    z[1,0,2]  R269      1.0154710710048676e-01
    z[1,0,2]  R270      3.5156715661287308e-02
    z[1,0,2]  R271      3.8920834660530090e-02
    z[1,0,2]  R272      -5.9202855825424194e-01
    z[1,0,2]  R273      -5.0289428234100342e-01
    z[1,0,2]  R274      -2.5969842076301575e-01
    z[1,0,2]  R275      -2.9287990927696228e-01
    z[1,0,2]  R276      -5.1057970523834229e-01
    z[1,0,2]  R277      -2.9195931553840637e-01
    z[1,0,2]  R278      -1.5345829725265503e-01
    z[1,0,2]  R279      -5.4529237747192383e-01
    z[1,0,2]  R280      -2.5295522809028625e-01
    z[1,0,2]  R281      9.3944780528545380e-02
    z[1,0,2]  R282      -4.6293100714683533e-01
    z[1,0,2]  R283      -6.5030390024185181e-01
    z[1,0,2]  R284      4.0662553906440735e-01
    z[1,0,2]  R285      4.1330105066299438e-01
    z[1,0,2]  R286      -3.1752744317054749e-01
    z[1,0,2]  R287      -8.1574696302413940e-01
    z[1,0,2]  R288      3.1801056861877441e-01
    z[1,0,2]  R289      -7.5886243581771851e-01
    z[1,0,2]  R290      -4.8464578390121460e-01
    z[1,0,2]  R291      -9.4092048704624176e-02
    z[1,0,2]  R292      -2.3630566895008087e-01
    z[1,0,2]  R293      3.9439156651496887e-02
    z[1,0,2]  R294      -5.8352392911911011e-01
    z[1,0,2]  R295      -4.4249197840690613e-01
    z[1,0,2]  R296      -3.7597176432609558e-01
    z[1,0,2]  R297      -1.0341511666774750e-01
    z[1,0,2]  R298      -0.631401777267456
    z[1,0,2]  R299      -1.3033016026020050e-01
    z[1,0,2]  R300      -0.673624575138092
    z[1,0,2]  R301      8.6111530661582947e-02
    z[1,0,2]  R302      -6.5445655584335327e-01
    z[1,0,2]  R303      -7.5995332002639771e-01
    z[1,0,2]  R304      -0.604049563407898
    z[1,0,2]  R305      -2.5753778219223022e-01
    z[1,0,2]  R306      -5.3976607322692871e-01
    z[1,0,2]  R307      4.2098306119441986e-02
    z[1,0,2]  R308      3.4863191843032837e-01
    z[1,0,2]  R309      4.5605354011058807e-02
    z[1,0,2]  R310      -3.8888771086931229e-02
    z[1,0,2]  R311      -2.9725676774978638e-01
    z[1,0,2]  R312      3.8173702359199524e-01
    z[1,0,2]  R313      -1.8941754102706909e-01
    z[1,0,2]  R314      1.1917474865913391e-01
    z[1,0,2]  R315      -7.8999191522598267e-01
    z[1,0,2]  R316      1.3872574269771576e-01
    z[1,0,2]  R317      4.2276558279991150e-01
    z[1,0,2]  R318      4.0643098950386047e-01
    z[1,0,2]  R319      5.0381618738174438e-01
    z[1,0,2]  R320      -3.2543742656707764e-01
    z[1,0,2]  R321      9.7078546881675720e-02
    z[1,0,2]  R322      -2.7968008071184158e-03
    z[1,0,2]  R323      3.8206619024276733e-01
    z[1,0,2]  R324      -2.5693991780281067e-01
    z[1,0,2]  R325      2.8152132034301758e-01
    z[1,0,2]  R326      -6.1093878746032715e-01
    z[1,0,2]  R327      -3.3857741951942444e-01
    z[1,0,2]  R328      -0.472592294216156
    z[1,0,2]  R329      9.7093977034091949e-02
    z[1,0,2]  R330      -2.3159457743167877e-01
    z[1,0,2]  R331      -5.7488650083541870e-01
    z[1,0,2]  R332      -6.2625670433044434e-01
    z[1,0,2]  R333      -8.8665857911109924e-02
    z[1,0,2]  R334      -5.7745444774627686e-01
    z[1,0,2]  R335      -4.2030754685401917e-01
    z[1,0,2]  R336      -3.2679456472396851e-01
    z[1,0,2]  R337      2.3499237000942230e-01
    z[1,0,2]  R338      -2.5501725077629089e-01
    z[1,0,2]  R339      -6.5312135219573975e-01
    z[1,0,2]  R340      1.2549513578414917e-01
    z[1,0,2]  R341      -2.6208499073982239e-01
    z[1,0,2]  R342      3.5253354907035828e-01
    z[1,0,2]  R343      4.8182269930839539e-01
    z[1,0,2]  R344      3.8683211803436279e-01
    z[1,0,2]  R345      8.2693123817443848e-01
    z[1,0,2]  R346      8.0544006824493408e-01
    z[1,0,2]  R347      8.4311634302139282e-01
    z[1,0,2]  R348      8.9893138408660889e-01
    z[1,0,2]  R349      0.8321533203125
    z[1,0,2]  R350      9.1821324825286865e-01
    z[1,0,2]  R351      -7.1190494298934937e-01
    z[1,0,2]  R352      1.0455914773046970e-02
    z[1,0,2]  R353      2.5464800000190735e-01
    z[1,0,2]  R354      -5.5668348073959351e-01
    z[1,0,2]  R355      -0.676361620426178
    z[1,0,2]  R356      1.8518878519535065e-01
    z[1,0,2]  R357      -1.8845534324645996e-01
    z[1,0,2]  R358      -2.9361501336097717e-01
    z[1,0,2]  R359      1.4269612729549408e-02
    z[1,0,2]  R360      1.4455687999725342e-01
    z[1,0,2]  R361      -4.1292563080787659e-01
    z[1,0,2]  R362      -4.6847561001777649e-01
    z[1,0,2]  R363      2.1335519850254059e-01
    z[1,0,2]  R364      3.4986928105354309e-01
    z[1,0,2]  R365      -4.8542730510234833e-02
    z[1,0,2]  R366      -7.7823407948017120e-02
    z[1,0,2]  R367      -1.1915443092584610e-01
    z[1,0,2]  R368      3.6274176836013794e-01
    z[1,0,2]  R369      2.3225225508213043e-01
    z[1,0,2]  R370      -5.5932450294494629e-01
    z[1,0,2]  R371      1.0764485597610474e-01
    z[1,0,2]  R372      -8.8984228670597076e-02
    z[1,0,2]  R373      1.3610440492630005e-01
    z[1,0,2]  R374      -6.8699955940246582e-01
    z[1,0,2]  R375      1.8842889368534088e-01
    z[1,0,2]  R376      1.2623888254165649e-01
    z[1,0,2]  R377      -5.7087469100952148e-01
    z[1,0,2]  R378      2.1743780374526978e-01
    z[1,0,2]  R379      -6.2400847673416138e-01
    z[1,0,2]  R380      3.4387171268463135e-02
    z[1,0,2]  R381      -4.8959305882453918e-01
    z[1,0,2]  R382      2.3180879652500153e-01
    z[1,0,2]  R383      -4.3938422203063965e-01
    z[1,0,2]  R384      -2.0589542388916016e-01
    z[1,0,2]  R385      -1.7205569148063660e-01
    z[1,0,2]  R386      -2.3169048130512238e-02
    z[1,0,2]  R387      6.9852125644683838e-01
    z[1,0,2]  R388      0.470347136259079
    z[1,0,2]  R389      4.5164796710014343e-01
    z[1,0,2]  R390      3.8815578818321228e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R243      -1
    z[1,0,3]  R244      1
    z[1,0,3]  R251      -3.7720409035682678e-01
    z[1,0,3]  R252      -5.0152492523193359e-01
    z[1,0,3]  R253      -0.620127260684967
    z[1,0,3]  R254      -3.0619978904724121e-01
    z[1,0,3]  R255      -4.6318736672401428e-01
    z[1,0,3]  R256      -2.8145933151245117e-01
    z[1,0,3]  R257      -4.9411794543266296e-01
    z[1,0,3]  R258      -4.7303819656372070e-01
    z[1,0,3]  R259      -1.5031154453754425e-01
    z[1,0,3]  R260      -3.8023716211318970e-01
    z[1,0,3]  R261      4.0187767148017883e-01
    z[1,0,3]  R262      3.0618983507156372e-01
    z[1,0,3]  R263      1.4561046659946442e-01
    z[1,0,3]  R264      2.7717188000679016e-01
    z[1,0,3]  R265      3.1537401676177979e-01
    z[1,0,3]  R266      1.7669594287872314e-01
    z[1,0,3]  R267      2.2975522279739380e-01
    z[1,0,3]  R268      3.0813151597976685e-01
    z[1,0,3]  R269      1.8196175992488861e-01
    z[1,0,3]  R270      3.0411624908447266e-01
    z[1,0,3]  R271      -4.7513264417648315e-01
    z[1,0,3]  R272      -2.9910793900489807e-01
    z[1,0,3]  R273      -4.9415990710258484e-01
    z[1,0,3]  R274      -5.3595000505447388e-01
    z[1,0,3]  R275      -7.0295113325119019e-01
    z[1,0,3]  R276      6.3802433013916016e-01
    z[1,0,3]  R277      -5.2820432186126709e-01
    z[1,0,3]  R278      -7.0321941375732422e-01
    z[1,0,3]  R279      -1.1157199740409851e-01
    z[1,0,3]  R280      4.9584048986434937e-01
    z[1,0,3]  R281      6.3299578428268433e-01
    z[1,0,3]  R282      1.0616496205329895e-01
    z[1,0,3]  R283      2.5820401310920715e-01
    z[1,0,3]  R284      7.9184156656265259e-01
    z[1,0,3]  R285      -8.7833821773529053e-02
    z[1,0,3]  R286      -6.3290582038462162e-03
    z[1,0,3]  R287      3.8389280438423157e-01
    z[1,0,3]  R288      5.2608340978622437e-01
    z[1,0,3]  R289      3.3938249945640564e-01
    z[1,0,3]  R290      2.5562044978141785e-01
    z[1,0,3]  R291      -3.0140110850334167e-01
    z[1,0,3]  R292      -2.7371674776077271e-01
    z[1,0,3]  R293      -0.520424485206604
    z[1,0,3]  R294      5.7561047375202179e-02
    z[1,0,3]  R295      -1.3779722154140472e-01
    z[1,0,3]  R296      1.5111909806728363e-01
    z[1,0,3]  R297      7.1562141180038452e-01
    z[1,0,3]  R298      7.0563733577728271e-01
    z[1,0,3]  R299      6.9247573614120483e-01
    z[1,0,3]  R300      3.9864847064018250e-01
    z[1,0,3]  R301      8.6471486091613770e-01
    z[1,0,3]  R302      2.9924002289772034e-01
    z[1,0,3]  R303      9.8448902368545532e-02
    z[1,0,3]  R304      0.0271736029535532
    z[1,0,3]  R305      1.0608037561178207e-01
    z[1,0,3]  R306      1.6946910321712494e-01
    z[1,0,3]  R307      3.3247882127761841e-01
    z[1,0,3]  R308      0.596255898475647
    z[1,0,3]  R309      1.9995900988578796e-01
    z[1,0,3]  R310      2.9122719168663025e-01
    z[1,0,3]  R311      -1.0755251161754131e-02
    z[1,0,3]  R312      -7.1085256338119507e-01
    z[1,0,3]  R313      -7.3259377479553223e-01
    z[1,0,3]  R314      6.1649543046951294e-01
    z[1,0,3]  R315      3.1919321417808533e-01
    z[1,0,3]  R316      0.474653959274292
    z[1,0,3]  R317      5.7778173685073853e-01
    z[1,0,3]  R318      2.9399591684341431e-01
    z[1,0,3]  R319      5.8195346593856812e-01
    z[1,0,3]  R320      4.9630695581436157e-01
    z[1,0,3]  R321      6.5015846490859985e-01
    z[1,0,3]  R322      1.1039676517248154e-01
    z[1,0,3]  R323      4.3881908059120178e-01
    z[1,0,3]  R324      5.5209094285964966e-01
    z[1,0,3]  R325      5.9213083982467651e-01
    z[1,0,3]  R326      0.625938355922699
    z[1,0,3]  R327      6.1959064006805420e-01
    z[1,0,3]  R328      3.7651520967483521e-01
    z[1,0,3]  R329      -4.0214595198631287e-01
    z[1,0,3]  R330      3.4837007522583008e-01
    z[1,0,3]  R331      -5.7408112287521362e-01
    z[1,0,3]  R332      -3.6551985144615173e-01
    z[1,0,3]  R333      -5.9628689289093018e-01
    z[1,0,3]  R334      -2.9741668701171875e-01
    z[1,0,3]  R335      -4.1337344050407410e-01
    z[1,0,3]  R336      2.0641303062438965e-01
    z[1,0,3]  R337      2.1087038516998291e-01
    z[1,0,3]  R338      -7.0434558391571045e-01
    z[1,0,3]  R339      8.4888547658920288e-02
    z[1,0,3]  R340      8.0051563680171967e-02
    z[1,0,3]  R341      7.6750802993774414e-01
    z[1,0,3]  R342      4.0120804309844971e-01
    z[1,0,3]  R343      5.6791716814041138e-01
    z[1,0,3]  R344      -3.0295112729072571e-01
    z[1,0,3]  R345      1.9151894748210907e-01
    z[1,0,3]  R346      1.3078117370605469e-01
    z[1,0,3]  R347      1.4946061372756958e-01
    z[1,0,3]  R348      0.159884512424469
    z[1,0,3]  R349      9.7060039639472961e-02
    z[1,0,3]  R350      2.1969486773014069e-01
    z[1,0,3]  R351      3.3871078491210938e-01
    z[1,0,3]  R352      4.5961785316467285e-01
    z[1,0,3]  R353      7.3579859733581543e-01
    z[1,0,3]  R354      8.0825246870517731e-02
    z[1,0,3]  R355      4.8096778988838196e-01
    z[1,0,3]  R356      8.0494147539138794e-01
    z[1,0,3]  R357      3.7761631608009338e-01
    z[1,0,3]  R358      1.8257418274879456e-01
    z[1,0,3]  R359      6.4273148775100708e-01
    z[1,0,3]  R360      2.2279354929924011e-01
    z[1,0,3]  R361      2.6987805962562561e-01
    z[1,0,3]  R362      1.9493977725505829e-01
    z[1,0,3]  R363      -1.9338284432888031e-01
    z[1,0,3]  R364      -0.388785719871521
    z[1,0,3]  R365      -1.7030143737792969e-01
    z[1,0,3]  R366      -2.7515235543251038e-01
    z[1,0,3]  R367      6.0826158523559570e-01
    z[1,0,3]  R368      1.6258460283279419e-01
    z[1,0,3]  R369      5.2279084920883179e-01
    z[1,0,3]  R370      -5.2511040121316910e-02
    z[1,0,3]  R371      -0.637824296951294
    z[1,0,3]  R372      -1.9327494502067566e-01
    z[1,0,3]  R373      -1.5178553760051727e-01
    z[1,0,3]  R374      5.1419204473495483e-01
    z[1,0,3]  R375      1.2139932811260223e-01
    z[1,0,3]  R376      3.3413335680961609e-02
    z[1,0,3]  R377      -4.9365319311618805e-02
    z[1,0,3]  R378      2.4444395303726196e-01
    z[1,0,3]  R379      -1.7017644643783569e-01
    z[1,0,3]  R380      5.3708422183990479e-01
    z[1,0,3]  R381      6.0811394453048706e-01
    z[1,0,3]  R382      -3.2972010970115662e-01
    z[1,0,3]  R383      7.2953003644943237e-01
    z[1,0,3]  R384      -2.7185928821563721e-01
    z[1,0,3]  R385      8.5692560672760010e-01
    z[1,0,3]  R386      -6.7722752690315247e-02
    z[1,0,3]  R387      -1.6869744658470154e-01
    z[1,0,3]  R388      -1.0491450130939484e-01
    z[1,0,3]  R389      2.3639321327209473e-01
    z[1,0,3]  R390      -5.7837799191474915e-02
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R245      -1
    z[1,0,4]  R246      1
    z[1,0,4]  R251      -3.2421648502349854e-01
    z[1,0,4]  R252      -0.287641316652298
    z[1,0,4]  R253      -2.5535440444946289e-01
    z[1,0,4]  R254      -6.8725836277008057e-01
    z[1,0,4]  R255      1.0965451598167419e-01
    z[1,0,4]  R256      -8.6141265928745270e-02
    z[1,0,4]  R257      -3.9865094423294067e-01
    z[1,0,4]  R258      -1.8897384405136108e-01
    z[1,0,4]  R259      2.6522138714790344e-01
    z[1,0,4]  R260      1.8102388083934784e-01
    z[1,0,4]  R261      -7.8041076660156250e-02
    z[1,0,4]  R262      -2.4372771382331848e-01
    z[1,0,4]  R263      1.0159488767385483e-01
    z[1,0,4]  R264      3.1711183488368988e-02
    z[1,0,4]  R265      1.2975813448429108e-01
    z[1,0,4]  R266      3.6978356540203094e-02
    z[1,0,4]  R267      4.7158572822809219e-02
    z[1,0,4]  R268      -2.0836353302001953e-01
    z[1,0,4]  R269      -7.6501868665218353e-02
    z[1,0,4]  R270      -2.3105712607502937e-03
    z[1,0,4]  R271      -2.3320877552032471e-01
    z[1,0,4]  R272      -1.1149710416793823e-01
    z[1,0,4]  R273      1.9031253457069397e-01
    z[1,0,4]  R274      -2.6426789164543152e-01
    z[1,0,4]  R275      3.6705070734024048e-01
    z[1,0,4]  R276      3.2231593132019043e-01
    z[1,0,4]  R277      -1.2098166346549988e-01
    z[1,0,4]  R278      4.6424347907304764e-02
    z[1,0,4]  R279      -2.0061565935611725e-01
    z[1,0,4]  R280      -3.2303226180374622e-03
    z[1,0,4]  R281      -1.9778303802013397e-01
    z[1,0,4]  R282      2.3271875083446503e-01
    z[1,0,4]  R283      -2.0879207551479340e-01
    z[1,0,4]  R284      -1.4656364917755127e-01
    z[1,0,4]  R285      3.8150716572999954e-02
    z[1,0,4]  R286      1.2002401798963547e-01
    z[1,0,4]  R287      3.2161605358123779e-01
    z[1,0,4]  R288      4.0730339288711548e-01
    z[1,0,4]  R289      4.8944327980279922e-02
    z[1,0,4]  R290      3.6813560128211975e-01
    z[1,0,4]  R291      -1.9165527820587158e-01
    z[1,0,4]  R292      4.9533969163894653e-01
    z[1,0,4]  R293      3.0061343312263489e-01
    z[1,0,4]  R294      2.9962889850139618e-02
    z[1,0,4]  R295      4.4709322974085808e-03
    z[1,0,4]  R296      -1.3671702146530151e-01
    z[1,0,4]  R297      1.6357812285423279e-01
    z[1,0,4]  R298      1.9558621942996979e-01
    z[1,0,4]  R299      3.6986431479454041e-01
    z[1,0,4]  R300      2.1674321591854095e-01
    z[1,0,4]  R301      -4.2414046823978424e-02
    z[1,0,4]  R302      -1.7318703234195709e-02
    z[1,0,4]  R303      3.6371055245399475e-01
    z[1,0,4]  R304      4.8381996154785156e-01
    z[1,0,4]  R305      -3.2471738755702972e-02
    z[1,0,4]  R306      5.8499181270599365e-01
    z[1,0,4]  R307      4.3477073311805725e-01
    z[1,0,4]  R308      1.2443201988935471e-01
    z[1,0,4]  R309      1.5923465788364410e-01
    z[1,0,4]  R310      4.4488483667373657e-01
    z[1,0,4]  R311      -1.4953131973743439e-01
    z[1,0,4]  R312      6.2398705631494522e-02
    z[1,0,4]  R313      2.5058604776859283e-02
    z[1,0,4]  R314      -4.4366973638534546e-01
    z[1,0,4]  R315      2.5789496302604675e-01
    z[1,0,4]  R316      4.7080650925636292e-01
    z[1,0,4]  R317      -1.0918192565441132e-03
    z[1,0,4]  R318      -1.5598331391811371e-01
    z[1,0,4]  R319      4.9181395769119263e-01
    z[1,0,4]  R320      7.5598949193954468e-01
    z[1,0,4]  R321      -1.1459868401288986e-01
    z[1,0,4]  R322      -3.6937814950942993e-01
    z[1,0,4]  R323      3.9902281761169434e-01
    z[1,0,4]  R324      2.1089439094066620e-01
    z[1,0,4]  R325      3.0564457178115845e-01
    z[1,0,4]  R326      2.1205591037869453e-02
    z[1,0,4]  R327      6.6968256235122681e-01
    z[1,0,4]  R328      3.4454742074012756e-01
    z[1,0,4]  R329      4.2818868532776833e-03
    z[1,0,4]  R330      4.8093062639236450e-01
    z[1,0,4]  R331      8.9604228734970093e-02
    z[1,0,4]  R332      -2.8744882345199585e-01
    z[1,0,4]  R333      2.0206996798515320e-01
    z[1,0,4]  R334      4.4445816427469254e-02
    z[1,0,4]  R335      5.0837200880050659e-01
    z[1,0,4]  R336      -4.3901059031486511e-01
    z[1,0,4]  R337      1.6942851245403290e-01
    z[1,0,4]  R338      -1.9649676978588104e-02
    z[1,0,4]  R339      4.6485564112663269e-01
    z[1,0,4]  R340      -3.1988048553466797e-01
    z[1,0,4]  R341      4.0406605601310730e-01
    z[1,0,4]  R342      -0.0986860916018486
    z[1,0,4]  R343      1.2505438923835754e-01
    z[1,0,4]  R344      -4.3657961487770081e-01
    z[1,0,4]  R345      2.2704254090785980e-01
    z[1,0,4]  R346      -1.2737950682640076e-01
    z[1,0,4]  R347      -1.2335945852100849e-02
    z[1,0,4]  R348      -1.8066802620887756e-01
    z[1,0,4]  R349      1.6324238479137421e-01
    z[1,0,4]  R350      6.8727836012840271e-02
    z[1,0,4]  R351      2.3454587161540985e-01
    z[1,0,4]  R352      5.1327306032180786e-01
    z[1,0,4]  R353      -1.1139550060033798e-01
    z[1,0,4]  R354      3.7365466356277466e-01
    z[1,0,4]  R355      1.5394628047943115e-01
    z[1,0,4]  R356      3.2040628790855408e-01
    z[1,0,4]  R357      3.3972853422164917e-01
    z[1,0,4]  R358      -6.4457327127456665e-02
    z[1,0,4]  R359      -2.8373605012893677e-01
    z[1,0,4]  R360      -3.2385626435279846e-01
    z[1,0,4]  R361      3.6158025264739990e-02
    z[1,0,4]  R362      2.8707557916641235e-01
    z[1,0,4]  R363      -2.1785897016525269e-01
    z[1,0,4]  R364      1.3910777866840363e-01
    z[1,0,4]  R365      -3.3459064364433289e-01
    z[1,0,4]  R366      -6.3165277242660522e-02
    z[1,0,4]  R367      -3.0165541172027588e-01
    z[1,0,4]  R368      3.2457414269447327e-01
    z[1,0,4]  R369      -6.5735457465052605e-03
    z[1,0,4]  R370      -4.6645230054855347e-01
    z[1,0,4]  R371      -2.1367374062538147e-01
    z[1,0,4]  R372      2.4187627434730530e-01
    z[1,0,4]  R373      0.53766930103302
    z[1,0,4]  R374      -3.9414870738983154e-01
    z[1,0,4]  R375      3.7524050474166870e-01
    z[1,0,4]  R376      -4.3254144489765167e-02
    z[1,0,4]  R377      -1.3490395247936249e-01
    z[1,0,4]  R378      -2.7130043506622314e-01
    z[1,0,4]  R379      -1.6369469463825226e-02
    z[1,0,4]  R380      8.4502868354320526e-02
    z[1,0,4]  R381      2.5334203243255615e-01
    z[1,0,4]  R382      -3.5510438680648804e-01
    z[1,0,4]  R383      -4.4641056656837463e-01
    z[1,0,4]  R384      1.5092290937900543e-02
    z[1,0,4]  R385      -2.3525262251496315e-02
    z[1,0,4]  R386      -0.0577346533536911
    z[1,0,4]  R387      6.4896240830421448e-02
    z[1,0,4]  R388      -1.4085040986537933e-01
    z[1,0,4]  R389      9.8788976669311523e-02
    z[1,0,4]  R390      -4.1376795619726181e-02
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R247      -1
    z[1,0,5]  R248      1
    z[1,0,5]  R251      -7.6462127268314362e-02
    z[1,0,5]  R252      3.5775130987167358e-01
    z[1,0,5]  R253      -5.0992354750633240e-02
    z[1,0,5]  R254      6.8135358393192291e-02
    z[1,0,5]  R255      4.2147073149681091e-01
    z[1,0,5]  R256      9.6685782074928284e-02
    z[1,0,5]  R257      2.4848919361829758e-02
    z[1,0,5]  R258      3.7973019480705261e-01
    z[1,0,5]  R259      -3.8027125597000122e-01
    z[1,0,5]  R260      -2.2399128973484039e-01
    z[1,0,5]  R261      1.3740417361259460e-01
    z[1,0,5]  R262      3.0534034967422485e-01
    z[1,0,5]  R263      3.5866221785545349e-01
    z[1,0,5]  R264      5.9211300686001778e-03
    z[1,0,5]  R265      -1.6443461179733276e-02
    z[1,0,5]  R266      2.0932057499885559e-01
    z[1,0,5]  R267      3.7273299694061279e-01
    z[1,0,5]  R268      2.1522977948188782e-01
    z[1,0,5]  R269      0.511130690574646
    z[1,0,5]  R270      3.6250913143157959e-01
    z[1,0,5]  R271      -0.648076057434082
    z[1,0,5]  R272      0.0657590702176094
    z[1,0,5]  R273      -2.9661828279495239e-01
    z[1,0,5]  R274      -7.6879158616065979e-02
    z[1,0,5]  R275      -2.1222910284996033e-01
    z[1,0,5]  R276      1.6392305493354797e-01
    z[1,0,5]  R277      -4.2393404245376587e-01
    z[1,0,5]  R278      -1.5759025514125824e-01
    z[1,0,5]  R279      -3.9872181415557861e-01
    z[1,0,5]  R280      7.0305779576301575e-02
    z[1,0,5]  R281      4.1900908946990967e-01
    z[1,0,5]  R282      1.4060950279235840e-01
    z[1,0,5]  R283      -4.0386593341827393e-01
    z[1,0,5]  R284      2.3328746855258942e-01
    z[1,0,5]  R285      1.4735272526741028e-01
    z[1,0,5]  R286      -1.0939425788819790e-02
    z[1,0,5]  R287      -2.9343429952859879e-02
    z[1,0,5]  R288      6.4921337366104126e-01
    z[1,0,5]  R289      5.4124879837036133e-01
    z[1,0,5]  R290      -2.0792341232299805e-01
    z[1,0,5]  R291      2.0585437119007111e-01
    z[1,0,5]  R292      -9.0375185012817383e-02
    z[1,0,5]  R293      -4.8706404864788055e-02
    z[1,0,5]  R294      -1.5952616930007935e-01
    z[1,0,5]  R295      -4.9883734434843063e-02
    z[1,0,5]  R296      -3.8910800218582153e-01
    z[1,0,5]  R297      4.2181101441383362e-01
    z[1,0,5]  R298      -1.6269692778587341e-01
    z[1,0,5]  R299      -1.3045889139175415e-01
    z[1,0,5]  R300      8.8567227125167847e-02
    z[1,0,5]  R301      3.1192660331726074e-01
    z[1,0,5]  R302      3.9336517453193665e-01
    z[1,0,5]  R303      2.0151710510253906e-01
    z[1,0,5]  R304      9.1979645192623138e-02
    z[1,0,5]  R305      -4.3433707207441330e-02
    z[1,0,5]  R306      -3.8120919466018677e-01
    z[1,0,5]  R307      -1.0739266127347946e-01
    z[1,0,5]  R308      1.6362212598323822e-01
    z[1,0,5]  R309      -3.6934378743171692e-01
    z[1,0,5]  R310      -4.7725012898445129e-01
    z[1,0,5]  R311      -0.523442268371582
    z[1,0,5]  R312      -2.9658830165863037e-01
    z[1,0,5]  R313      2.5670301169157028e-02
    z[1,0,5]  R314      8.1822425127029419e-02
    z[1,0,5]  R315      -6.0947993770241737e-03
    z[1,0,5]  R316      3.6438152194023132e-01
    z[1,0,5]  R317      -3.4555536508560181e-01
    z[1,0,5]  R318      -4.6714732050895691e-01
    z[1,0,5]  R319      1.2319060415029526e-01
    z[1,0,5]  R320      5.1724273711442947e-02
    z[1,0,5]  R321      2.0836119353771210e-01
    z[1,0,5]  R322      -2.1691080927848816e-01
    z[1,0,5]  R323      1.4422725141048431e-01
    z[1,0,5]  R324      -9.9152170121669769e-02
    z[1,0,5]  R325      -1.5527497231960297e-01
    z[1,0,5]  R326      3.7689003348350525e-01
    z[1,0,5]  R327      -8.8169820606708527e-02
    z[1,0,5]  R328      2.3336377739906311e-01
    z[1,0,5]  R329      -1.3693358004093170e-01
    z[1,0,5]  R330      4.8149690032005310e-02
    z[1,0,5]  R331      1.2492982298135757e-01
    z[1,0,5]  R332      0.175779327750206
    z[1,0,5]  R333      3.8542658090591431e-02
    z[1,0,5]  R334      -5.6672483682632446e-01
    z[1,0,5]  R335      -5.7694405317306519e-01
    z[1,0,5]  R336      3.2612487673759460e-01
    z[1,0,5]  R337      -2.9808858036994934e-01
    z[1,0,5]  R338      -4.0076601505279541e-01
    z[1,0,5]  R339      -3.8645300269126892e-01
    z[1,0,5]  R340      1.7766506969928741e-01
    z[1,0,5]  R341      -1.6486328095197678e-02
    z[1,0,5]  R342      0.503727912902832
    z[1,0,5]  R343      0.0744536742568016
    z[1,0,5]  R344      -9.5156140625476837e-02
    z[1,0,5]  R345      1.6693204641342163e-01
    z[1,0,5]  R346      0.0472993366420269
    z[1,0,5]  R347      1.6686005890369415e-01
    z[1,0,5]  R348      1.1024153977632523e-01
    z[1,0,5]  R349      2.0623014867305756e-01
    z[1,0,5]  R350      6.2137570232152939e-02
    z[1,0,5]  R351      9.5437504351139069e-02
    z[1,0,5]  R352      -6.5168537199497223e-02
    z[1,0,5]  R353      2.6004728674888611e-01
    z[1,0,5]  R354      -5.0996005535125732e-01
    z[1,0,5]  R355      -8.8554620742797852e-02
    z[1,0,5]  R356      -2.4945183098316193e-01
    z[1,0,5]  R357      -1.1956793069839478e-01
    z[1,0,5]  R358      2.5355464220046997e-01
    z[1,0,5]  R359      -1.7481237649917603e-01
    z[1,0,5]  R360      1.9550228118896484e-01
    z[1,0,5]  R361      1.8047341704368591e-01
    z[1,0,5]  R362      -3.0346742272377014e-01
    z[1,0,5]  R363      -7.9076945781707764e-02
    z[1,0,5]  R364      -1.2368068844079971e-01
    z[1,0,5]  R365      -3.5012704133987427e-01
    z[1,0,5]  R366      -3.4012833237648010e-01
    z[1,0,5]  R367      7.3924213647842407e-02
    z[1,0,5]  R368      6.5081994980573654e-03
    z[1,0,5]  R369      3.1589362025260925e-01
    z[1,0,5]  R370      -1.6483667492866516e-01
    z[1,0,5]  R371      -7.4559226632118225e-02
    z[1,0,5]  R372      -5.8781629800796509e-01
    z[1,0,5]  R373      -3.9033353328704834e-01
    z[1,0,5]  R374      -5.8267004787921906e-02
    z[1,0,5]  R375      4.9076753854751587e-01
    z[1,0,5]  R376      0.244783416390419
    z[1,0,5]  R377      -2.7149847149848938e-01
    z[1,0,5]  R378      6.3544875383377075e-01
    z[1,0,5]  R379      -2.7017769217491150e-01
    z[1,0,5]  R380      3.8683155179023743e-01
    z[1,0,5]  R381      5.0349522382020950e-02
    z[1,0,5]  R382      9.5458760857582092e-02
    z[1,0,5]  R383      1.5454442799091339e-01
    z[1,0,5]  R384      -4.0873834490776062e-01
    z[1,0,5]  R385      2.3882275447249413e-02
    z[1,0,5]  R386      5.4946172237396240e-01
    z[1,0,5]  R387      2.4371053278446198e-01
    z[1,0,5]  R388      4.0685775876045227e-01
    z[1,0,5]  R389      2.0834033191204071e-01
    z[1,0,5]  R390      2.9766580462455750e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R249      -1
    z[1,0,6]  R250      1
    z[1,0,6]  R251      -0.383847177028656
    z[1,0,6]  R252      2.1412980556488037e-01
    z[1,0,6]  R253      4.4229626655578613e-02
    z[1,0,6]  R254      -1.1348040401935577e-01
    z[1,0,6]  R255      -7.0780552923679352e-02
    z[1,0,6]  R256      2.3420266807079315e-01
    z[1,0,6]  R257      -3.5714048147201538e-01
    z[1,0,6]  R258      -4.1779378056526184e-01
    z[1,0,6]  R259      -9.8797872662544250e-02
    z[1,0,6]  R260      -2.7079728245735168e-01
    z[1,0,6]  R261      -2.8398019075393677e-01
    z[1,0,6]  R262      2.7448818087577820e-01
    z[1,0,6]  R263      -3.8419350981712341e-02
    z[1,0,6]  R264      9.7134284675121307e-02
    z[1,0,6]  R265      -2.4830566346645355e-01
    z[1,0,6]  R266      -1.3310468196868896e-01
    z[1,0,6]  R267      3.7576359510421753e-01
    z[1,0,6]  R268      -2.8193789720535278e-01
    z[1,0,6]  R269      4.6669259667396545e-02
    z[1,0,6]  R270      -4.4715738296508789e-01
    z[1,0,6]  R271      4.4310346245765686e-02
    z[1,0,6]  R272      1.8833646178245544e-01
    z[1,0,6]  R273      -0.0983353853225708
    z[1,0,6]  R274      1.8292682245373726e-02
    z[1,0,6]  R275      1.5415126085281372e-01
    z[1,0,6]  R276      1.4263746142387390e-01
    z[1,0,6]  R277      4.6091634035110474e-01
    z[1,0,6]  R278      3.7453049421310425e-01
    z[1,0,6]  R279      6.3131886720657349e-01
    z[1,0,6]  R280      -1.3046045601367950e-01
    z[1,0,6]  R281      7.2290033102035522e-02
    z[1,0,6]  R282      3.5995218157768250e-01
    z[1,0,6]  R283      1.5154068171977997e-01
    z[1,0,6]  R284      -1.5079037845134735e-01
    z[1,0,6]  R285      1.1484432965517044e-01
    z[1,0,6]  R286      -0.736470639705658
    z[1,0,6]  R287      5.0123695284128189e-02
    z[1,0,6]  R288      1.2904106080532074e-01
    z[1,0,6]  R289      7.2645372711122036e-03
    z[1,0,6]  R290      7.1147575974464417e-02
    z[1,0,6]  R291      3.2846489548683167e-01
    z[1,0,6]  R292      -1.5908074378967285e-01
    z[1,0,6]  R293      -4.5059084892272949e-01
    z[1,0,6]  R294      -3.3879649639129639e-01
    z[1,0,6]  R295      -3.3033692836761475e-01
    z[1,0,6]  R296      7.6765216886997223e-02
    z[1,0,6]  R297      -2.9396224021911621e-01
    z[1,0,6]  R298      4.3577242642641068e-02
    z[1,0,6]  R299      1.2319776415824890e-01
    z[1,0,6]  R300      -5.3875666856765747e-01
    z[1,0,6]  R301      8.8483437895774841e-02
    z[1,0,6]  R302      2.8057926893234253e-01
    z[1,0,6]  R303      -6.0776922851800919e-02
    z[1,0,6]  R304      3.0879381299018860e-01
    z[1,0,6]  R305      -3.5192728042602539e-01
    z[1,0,6]  R306      -2.6379138231277466e-01
    z[1,0,6]  R307      4.2512655258178711e-02
    z[1,0,6]  R308      -1.8563105165958405e-01
    z[1,0,6]  R309      3.3686894178390503e-01
    z[1,0,6]  R310      -9.7422868013381958e-02
    z[1,0,6]  R311      2.1099606156349182e-01
    z[1,0,6]  R312      2.7201318740844727e-01
    z[1,0,6]  R313      5.4628539085388184e-01
    z[1,0,6]  R314      5.2705843001604080e-02
    z[1,0,6]  R315      -8.0805547535419464e-02
    z[1,0,6]  R316      -3.9299684762954712e-01
    z[1,0,6]  R317      1.1600001901388168e-01
    z[1,0,6]  R318      1.1144879460334778e-01
    z[1,0,6]  R319      2.8317835927009583e-01
    z[1,0,6]  R320      2.0880098640918732e-01
    z[1,0,6]  R321      2.0675741136074066e-01
    z[1,0,6]  R322      4.8996829986572266e-01
    z[1,0,6]  R323      -2.7041694149374962e-02
    z[1,0,6]  R324      9.9062584340572357e-02
    z[1,0,6]  R325      -4.4209539890289307e-01
    z[1,0,6]  R326      -5.9952650219202042e-02
    z[1,0,6]  R327      2.1013806760311127e-01
    z[1,0,6]  R328      -3.7109214812517166e-02
    z[1,0,6]  R329      0.456543892621994
    z[1,0,6]  R330      3.6825588345527649e-01
    z[1,0,6]  R331      1.3191461563110352e-01
    z[1,0,6]  R332      0.0874442458152771
    z[1,0,6]  R333      -4.4186714291572571e-01
    z[1,0,6]  R334      -3.0732482671737671e-01
    z[1,0,6]  R335      -5.3932290524244308e-02
    z[1,0,6]  R336      -0.401030957698822
    z[1,0,6]  R337      -2.5396207347512245e-02
    z[1,0,6]  R338      -4.6218344569206238e-01
    z[1,0,6]  R339      -3.9516305923461914e-01
    z[1,0,6]  R340      -4.1228723526000977e-01
    z[1,0,6]  R341      3.7462085485458374e-01
    z[1,0,6]  R342      5.2376669645309448e-01
    z[1,0,6]  R343      -1.5266944468021393e-01
    z[1,0,6]  R344      2.0077311992645264e-01
    z[1,0,6]  R345      2.9434624314308167e-01
    z[1,0,6]  R346      0.16197469830513
    z[1,0,6]  R347      0.0212846789509058
    z[1,0,6]  R348      6.1095900833606720e-02
    z[1,0,6]  R349      -2.5218958035111427e-02
    z[1,0,6]  R350      -1.1041018366813660e-01
    z[1,0,6]  R351      1.9928197562694550e-01
    z[1,0,6]  R352      8.4426812827587128e-03
    z[1,0,6]  R353      -4.0857456624507904e-02
    z[1,0,6]  R354      0.0263714250177145
    z[1,0,6]  R355      -3.8630792498588562e-01
    z[1,0,6]  R356      -2.9359987378120422e-01
    z[1,0,6]  R357      -6.8870788812637329e-01
    z[1,0,6]  R358      5.9921962022781372e-01
    z[1,0,6]  R359      -3.0938610434532166e-02
    z[1,0,6]  R360      2.7243435382843018e-01
    z[1,0,6]  R361      -4.6066647768020630e-01
    z[1,0,6]  R362      -2.8735786676406860e-01
    z[1,0,6]  R363      -1.0418348759412766e-01
    z[1,0,6]  R364      3.6686885356903076e-01
    z[1,0,6]  R365      1.9505521282553673e-02
    z[1,0,6]  R366      5.7073158025741577e-01
    z[1,0,6]  R367      -1.5794268250465393e-01
    z[1,0,6]  R368      3.0939567089080811e-01
    z[1,0,6]  R369      2.5403586030006409e-01
    z[1,0,6]  R370      3.1916892528533936e-01
    z[1,0,6]  R371      2.3045334219932556e-01
    z[1,0,6]  R372      2.3487238585948944e-01
    z[1,0,6]  R373      1.5198100358247757e-02
    z[1,0,6]  R374      -1.3912385702133179e-01
    z[1,0,6]  R375      2.2606596350669861e-01
    z[1,0,6]  R376      2.0908632874488831e-01
    z[1,0,6]  R377      5.1905751228332520e-01
    z[1,0,6]  R378      -1.1375757306814194e-01
    z[1,0,6]  R379      3.3053648471832275e-01
    z[1,0,6]  R380      -1.7875127494335175e-01
    z[1,0,6]  R381      -1.7471471428871155e-01
    z[1,0,6]  R382      -3.0696097016334534e-01
    z[1,0,6]  R383      -1.4413294196128845e-01
    z[1,0,6]  R384      -1.9780771806836128e-02
    z[1,0,6]  R385      -4.2399564385414124e-01
    z[1,0,6]  R386      3.5136872529983521e-01
    z[1,0,6]  R387      2.3495469987392426e-01
    z[1,0,6]  R388      -0.0321926586329937
    z[1,0,6]  R389      5.2557539194822311e-02
    z[1,0,6]  R390      2.3745338618755341e-01
    z[0,5,0]  R2        -1
    z[0,5,0]  R47       1
    z[0,5,0]  R391      -1
    z[0,5,0]  R392      1
    z[0,5,0]  R405      4.9490082263946533e-01
    z[0,5,0]  R406      4.1498789191246033e-01
    z[0,5,0]  R407      5.6200385093688965e-01
    z[0,5,0]  R408      -2.7195507287979126e-01
    z[0,5,0]  R409      -1.5923419594764709e-01
    z[0,5,0]  R410      1.1338619142770767e-01
    z[0,5,0]  R411      -5.6006636470556259e-02
    z[0,5,0]  R412      -2.2266621887683868e-01
    z[0,5,0]  R413      1.8465099856257439e-02
    z[0,5,0]  R414      6.4370214939117432e-02
    z[0,5,0]  R415      1.5307880938053131e-01
    z[0,5,0]  R416      7.3211260139942169e-02
    z[0,5,0]  R417      3.4881255030632019e-01
    z[0,5,0]  R418      -3.8617795705795288e-01
    z[0,5,0]  R419      -1.6033592820167542e-01
    z[0,5,0]  R420      -5.0186461210250854e-01
    z[0,5,0]  R421      -4.7637766599655151e-01
    z[0,5,0]  R422      -0.341469407081604
    z[0,5,0]  R423      -4.7362893819808960e-01
    z[0,5,0]  R424      -2.7223885059356689e-01
    z[0,5,0]  R425      2.4971213936805725e-01
    z[0,5,0]  R426      -6.0493912547826767e-02
    z[0,5,0]  R427      -0.0623035691678524
    z[0,5,0]  R428      1.6990311443805695e-02
    z[0,5,0]  R429      3.0292698740959167e-01
    z[0,5,0]  R430      -1.4488242566585541e-01
    z[0,5,0]  R431      2.6645186543464661e-01
    z[0,5,0]  R432      -1.6680526733398438e-01
    z[0,5,0]  R433      -6.0302621126174927e-01
    z[0,5,0]  R434      -4.7555884718894958e-01
    z[0,5,0]  R435      3.0833488702774048e-01
    z[0,5,0]  R436      3.6954346299171448e-01
    z[0,5,0]  R437      1.3853612542152405e-01
    z[0,5,0]  R438      1.1774213053286076e-02
    z[0,5,0]  R439      -3.4528955817222595e-01
    z[0,5,0]  R440      -0.51384037733078
    z[0,5,0]  R441      2.9657664895057678e-01
    z[0,5,0]  R442      3.4071081876754761e-01
    z[0,5,0]  R443      4.9104800820350647e-01
    z[0,5,0]  R444      -5.7003223896026611e-01
    z[0,5,0]  R445      -0.0688767358660698
    z[0,5,0]  R446      -4.3175253272056580e-01
    z[0,5,0]  R447      1.4744243025779724e-01
    z[0,5,0]  R448      -1.8172748386859894e-01
    z[0,5,0]  R449      6.0729360580444336e-01
    z[0,5,0]  R450      7.0505076646804810e-01
    z[0,5,0]  R451      -5.4727524518966675e-01
    z[0,5,0]  R452      6.3396120071411133e-01
    z[0,5,0]  R453      -4.9636000394821167e-01
    z[0,5,0]  R454      7.1425217390060425e-01
    z[0,5,0]  R455      2.8491258621215820e-01
    z[0,5,0]  R456      2.6955893635749817e-01
    z[0,5,0]  R457      1.4603634178638458e-01
    z[0,5,0]  R458      -6.4753681421279907e-02
    z[0,5,0]  R459      2.0705427229404449e-01
    z[0,5,0]  R460      4.6588051319122314e-01
    z[0,5,0]  R461      -6.0379576683044434e-01
    z[0,5,0]  R462      -7.6082962751388550e-01
    z[0,5,0]  R463      -7.6411402225494385e-01
    z[0,5,0]  R464      -8.1588953733444214e-01
    z[0,5,0]  R465      -9.8129129037261009e-03
    z[0,5,0]  R466      1.9520588219165802e-01
    z[0,5,0]  R467      -1.5761759877204895e-01
    z[0,5,0]  R468      2.8266796469688416e-01
    z[0,5,0]  R469      -0.0914662703871727
    z[0,5,0]  R470      3.5185284912586212e-02
    z[0,5,0]  R471      -4.4540934264659882e-02
    z[0,5,0]  R472      -1.4993159100413322e-02
    z[0,5,0]  R473      -1.7481365799903870e-01
    z[0,5,0]  R474      -1.2111248821020126e-01
    z[0,5,0]  R475      2.3999631404876709e-01
    z[0,5,0]  R476      3.7114644050598145e-01
    z[0,5,0]  R477      3.3333885669708252e-01
    z[0,5,0]  R478      1.5405425429344177e-01
    z[0,5,0]  R479      0.344827800989151
    z[0,5,0]  R480      1.6298142075538635e-01
    z[0,5,0]  R481      -6.8737521767616272e-02
    z[0,5,0]  R482      1.7824020236730576e-02
    z[0,5,0]  R483      -1.6613408923149109e-01
    z[0,5,0]  R484      -0.219927579164505
    z[0,5,0]  R485      0.153601735830307
    z[0,5,0]  R486      2.2325752675533295e-01
    z[0,5,0]  R487      7.2254180908203125e-02
    z[0,5,0]  R488      3.1756952404975891e-01
    z[0,5,0]  R489      8.4015719592571259e-02
    z[0,5,0]  R490      5.8751013129949570e-02
    z[0,5,0]  R491      -4.2334833741188049e-01
    z[0,5,0]  R492      2.5880929827690125e-01
    z[0,5,0]  R493      -1.4871890842914581e-01
    z[0,5,0]  R494      -0.283314973115921
    z[0,5,0]  R495      4.5690831542015076e-01
    z[0,5,0]  R496      1.1496644467115402e-01
    z[0,5,0]  R497      2.3103404045104980e-01
    z[0,5,0]  R498      -2.2177945077419281e-01
    z[0,5,0]  R499      3.5804096609354019e-02
    z[0,5,0]  R500      -6.4874303340911865e-01
    z[0,5,0]  R501      -7.3766535520553589e-01
    z[0,5,0]  R502      -3.5329201817512512e-01
    z[0,5,0]  R503      -9.5257240533828735e-01
    z[0,5,0]  R504      -9.4518017768859863e-01
    z[0,5,1]  R3        -1
    z[0,5,1]  R48       1
    z[0,5,1]  R393      -1
    z[0,5,1]  R394      1
    z[0,5,1]  R405      -2.3231776058673859e-01
    z[0,5,1]  R406      -4.2521899938583374e-01
    z[0,5,1]  R407      -2.8838777542114258e-01
    z[0,5,1]  R408      -2.9415807127952576e-01
    z[0,5,1]  R409      -1.8136461079120636e-01
    z[0,5,1]  R410      0.614677906036377
    z[0,5,1]  R411      8.8259148597717285e-01
    z[0,5,1]  R412      -1.2112042307853699e-01
    z[0,5,1]  R413      -2.1046364307403564e-01
    z[0,5,1]  R414      8.1843149662017822e-01
    z[0,5,1]  R415      1.2217903882265091e-01
    z[0,5,1]  R416      4.1422221064567566e-01
    z[0,5,1]  R417      -5.2835303544998169e-01
    z[0,5,1]  R418      -6.0785013437271118e-01
    z[0,5,1]  R419      2.9621484875679016e-01
    z[0,5,1]  R420      1.9389666616916656e-01
    z[0,5,1]  R421      -1.0692614316940308e-01
    z[0,5,1]  R422      3.5085476934909821e-02
    z[0,5,1]  R423      0.0629362165927887
    z[0,5,1]  R424      1.1717350780963898e-01
    z[0,5,1]  R425      4.6073517203330994e-01
    z[0,5,1]  R426      7.1917676925659180e-01
    z[0,5,1]  R427      5.5513072013854980e-01
    z[0,5,1]  R428      -5.3189247846603394e-01
    z[0,5,1]  R429      1.9663409888744354e-01
    z[0,5,1]  R430      0.213766410946846
    z[0,5,1]  R431      3.8322755694389343e-01
    z[0,5,1]  R432      6.5201544761657715e-01
    z[0,5,1]  R433      3.3321052789688110e-01
    z[0,5,1]  R434      6.9712668657302856e-01
    z[0,5,1]  R435      6.4458996057510376e-01
    z[0,5,1]  R436      -5.9066683053970337e-01
    z[0,5,1]  R437      -9.1286391019821167e-01
    z[0,5,1]  R438      -0.74636310338974
    z[0,5,1]  R439      -0.783897876739502
    z[0,5,1]  R440      -4.5693665742874146e-01
    z[0,5,1]  R441      -0.637538731098175
    z[0,5,1]  R442      -7.2442001104354858e-01
    z[0,5,1]  R443      -5.1696652173995972e-01
    z[0,5,1]  R444      1.1333186924457550e-01
    z[0,5,1]  R445      -6.8740415573120117e-01
    z[0,5,1]  R446      -5.5598491430282593e-01
    z[0,5,1]  R447      -7.0357513427734375e-01
    z[0,5,1]  R448      2.2914955019950867e-01
    z[0,5,1]  R449      3.8495090603828430e-01
    z[0,5,1]  R450      6.1672019958496094e-01
    z[0,5,1]  R451      1.0403732955455780e-01
    z[0,5,1]  R452      2.6857027783989906e-02
    z[0,5,1]  R453      3.9084741473197937e-01
    z[0,5,1]  R454      -1.0710010677576065e-01
    z[0,5,1]  R455      4.6051979064941406e-01
    z[0,5,1]  R456      -7.3174512386322021e-01
    z[0,5,1]  R457      -9.7263120114803314e-02
    z[0,5,1]  R458      -8.4369462728500366e-01
    z[0,5,1]  R459      1.1094018071889877e-01
    z[0,5,1]  R460      5.9087282419204712e-01
    z[0,5,1]  R461      -1.5158358030021191e-02
    z[0,5,1]  R462      -4.9962759017944336e-02
    z[0,5,1]  R463      -3.1675678491592407e-01
    z[0,5,1]  R464      -1.8333867192268372e-01
    z[0,5,1]  R465      -3.6789214611053467e-01
    z[0,5,1]  R466      -5.0035309791564941e-01
    z[0,5,1]  R467      -3.2951968908309937e-01
    z[0,5,1]  R468      -1.0314059257507324e-01
    z[0,5,1]  R469      -2.8634673357009888e-01
    z[0,5,1]  R470      -1.9924721121788025e-01
    z[0,5,1]  R471      8.7003123760223389e-01
    z[0,5,1]  R472      8.0698674917221069e-01
    z[0,5,1]  R473      6.1325830221176147e-01
    z[0,5,1]  R474      5.8618915081024170e-01
    z[0,5,1]  R475      -6.2944030761718750e-01
    z[0,5,1]  R476      -5.4059320688247681e-01
    z[0,5,1]  R477      -5.4516172409057617e-01
    z[0,5,1]  R478      -6.5914779901504517e-01
    z[0,5,1]  R479      -4.8302519321441650e-01
    z[0,5,1]  R480      -5.9477454423904419e-01
    z[0,5,1]  R481      -5.0718593597412109e-01
    z[0,5,1]  R482      -5.7386404275894165e-01
    z[0,5,1]  R483      1.0970901697874069e-01
    z[0,5,1]  R484      -5.7534945011138916e-01
    z[0,5,1]  R485      -5.3369557857513428e-01
    z[0,5,1]  R486      -8.9994937181472778e-01
    z[0,5,1]  R487      -7.2926950454711914e-01
    z[0,5,1]  R488      -6.6056615114212036e-01
    z[0,5,1]  R489      1.3864208944141865e-02
    z[0,5,1]  R490      5.8342820405960083e-01
    z[0,5,1]  R491      6.5766614675521851e-01
    z[0,5,1]  R492      2.0050309598445892e-01
    z[0,5,1]  R493      5.5003219842910767e-01
    z[0,5,1]  R494      4.6862110495567322e-01
    z[0,5,1]  R495      -0.463623583316803
    z[0,5,1]  R496      -5.8346712589263916e-01
    z[0,5,1]  R497      -7.5760698318481445e-01
    z[0,5,1]  R498      4.2335048317909241e-01
    z[0,5,1]  R499      4.4613838195800781e-01
    z[0,5,1]  R500      1.3833696953952312e-02
    z[0,5,1]  R501      -3.3223412930965424e-02
    z[0,5,1]  R502      2.0151835680007935e-01
    z[0,5,1]  R503      -4.3788510374724865e-03
    z[0,5,1]  R504      -1.3158197514712811e-02
    z[0,5,2]  R4        -1
    z[0,5,2]  R49       1
    z[0,5,2]  R395      -1
    z[0,5,2]  R396      1
    z[0,5,2]  R405      -5.7488650083541870e-01
    z[0,5,2]  R406      -6.2625670433044434e-01
    z[0,5,2]  R407      -8.8665857911109924e-02
    z[0,5,2]  R408      -5.7745444774627686e-01
    z[0,5,2]  R409      -4.2030754685401917e-01
    z[0,5,2]  R410      -3.2679456472396851e-01
    z[0,5,2]  R411      2.3499237000942230e-01
    z[0,5,2]  R412      -2.5501725077629089e-01
    z[0,5,2]  R413      -6.5312135219573975e-01
    z[0,5,2]  R414      1.2549513578414917e-01
    z[0,5,2]  R415      -2.6208499073982239e-01
    z[0,5,2]  R416      3.5253354907035828e-01
    z[0,5,2]  R417      4.8182269930839539e-01
    z[0,5,2]  R418      3.8683211803436279e-01
    z[0,5,2]  R419      8.2693123817443848e-01
    z[0,5,2]  R420      8.0544006824493408e-01
    z[0,5,2]  R421      8.4311634302139282e-01
    z[0,5,2]  R422      8.9893138408660889e-01
    z[0,5,2]  R423      0.8321533203125
    z[0,5,2]  R424      9.1821324825286865e-01
    z[0,5,2]  R425      -7.1190494298934937e-01
    z[0,5,2]  R426      1.0455914773046970e-02
    z[0,5,2]  R427      2.5464800000190735e-01
    z[0,5,2]  R428      -5.5668348073959351e-01
    z[0,5,2]  R429      -0.676361620426178
    z[0,5,2]  R430      1.8518878519535065e-01
    z[0,5,2]  R431      -1.8845534324645996e-01
    z[0,5,2]  R432      -2.9361501336097717e-01
    z[0,5,2]  R433      1.4269612729549408e-02
    z[0,5,2]  R434      1.4455687999725342e-01
    z[0,5,2]  R435      -4.1292563080787659e-01
    z[0,5,2]  R436      -4.6847561001777649e-01
    z[0,5,2]  R437      2.1335519850254059e-01
    z[0,5,2]  R438      3.4986928105354309e-01
    z[0,5,2]  R439      -4.8542730510234833e-02
    z[0,5,2]  R440      -7.7823407948017120e-02
    z[0,5,2]  R441      -1.1915443092584610e-01
    z[0,5,2]  R442      3.6274176836013794e-01
    z[0,5,2]  R443      2.3225225508213043e-01
    z[0,5,2]  R444      -5.5932450294494629e-01
    z[0,5,2]  R445      1.0764485597610474e-01
    z[0,5,2]  R446      -8.8984228670597076e-02
    z[0,5,2]  R447      1.3610440492630005e-01
    z[0,5,2]  R448      -6.8699955940246582e-01
    z[0,5,2]  R449      1.8842889368534088e-01
    z[0,5,2]  R450      1.2623888254165649e-01
    z[0,5,2]  R451      -5.7087469100952148e-01
    z[0,5,2]  R452      2.1743780374526978e-01
    z[0,5,2]  R453      -6.2400847673416138e-01
    z[0,5,2]  R454      3.4387171268463135e-02
    z[0,5,2]  R455      -4.8959305882453918e-01
    z[0,5,2]  R456      2.3180879652500153e-01
    z[0,5,2]  R457      -4.3938422203063965e-01
    z[0,5,2]  R458      -2.0589542388916016e-01
    z[0,5,2]  R459      -1.7205569148063660e-01
    z[0,5,2]  R460      -2.3169048130512238e-02
    z[0,5,2]  R461      6.9852125644683838e-01
    z[0,5,2]  R462      0.470347136259079
    z[0,5,2]  R463      4.5164796710014343e-01
    z[0,5,2]  R464      3.8815578818321228e-01
    z[0,5,2]  R465      -6.9622492790222168e-01
    z[0,5,2]  R466      -7.2611391544342041e-01
    z[0,5,2]  R467      -2.7461823821067810e-01
    z[0,5,2]  R468      -6.0160207748413086e-01
    z[0,5,2]  R469      4.5172579586505890e-02
    z[0,5,2]  R470      1.1268923431634903e-01
    z[0,5,2]  R471      2.4226620793342590e-01
    z[0,5,2]  R472      -3.1493294239044189e-01
    z[0,5,2]  R473      3.6262005567550659e-01
    z[0,5,2]  R474      -2.9705882072448730e-01
    z[0,5,2]  R475      4.5650824904441833e-01
    z[0,5,2]  R476      0.0513649582862854
    z[0,5,2]  R477      4.0688481926918030e-01
    z[0,5,2]  R478      5.0679886341094971e-01
    z[0,5,2]  R479      4.5397931337356567e-01
    z[0,5,2]  R480      3.9233011007308960e-01
    z[0,5,2]  R481      7.6157444715499878e-01
    z[0,5,2]  R482      -1.0714815557003021e-01
    z[0,5,2]  R483      1.4869058132171631e-01
    z[0,5,2]  R484      5.1525270938873291e-01
    z[0,5,2]  R485      1.2777386605739594e-01
    z[0,5,2]  R486      2.8799328207969666e-01
    z[0,5,2]  R487      4.3757927417755127e-01
    z[0,5,2]  R488      3.7901647388935089e-02
    z[0,5,2]  R489      -3.0423361063003540e-01
    z[0,5,2]  R490      0.0686836838722229
    z[0,5,2]  R491      2.3707339167594910e-01
    z[0,5,2]  R492      -3.2546824216842651e-01
    z[0,5,2]  R493      4.7030287981033325e-01
    z[0,5,2]  R494      7.1690547466278076e-01
    z[0,5,2]  R495      -1.5700435638427734e-01
    z[0,5,2]  R496      -1.1567012220621109e-01
    z[0,5,2]  R497      1.6201768815517426e-01
    z[0,5,2]  R498      -0.000394883711123839
    z[0,5,2]  R499      -4.6268694102764130e-02
    z[0,5,2]  R500      0.632844865322113
    z[0,5,2]  R501      6.0275137424468994e-01
    z[0,5,2]  R502      8.0314534902572632e-01
    z[0,5,2]  R503      -8.1650130450725555e-02
    z[0,5,2]  R504      -2.1970146894454956e-01
    z[0,5,3]  R5        -1
    z[0,5,3]  R50       1
    z[0,5,3]  R397      -1
    z[0,5,3]  R398      1
    z[0,5,3]  R405      -5.7408112287521362e-01
    z[0,5,3]  R406      -3.6551985144615173e-01
    z[0,5,3]  R407      -5.9628689289093018e-01
    z[0,5,3]  R408      -2.9741668701171875e-01
    z[0,5,3]  R409      -4.1337344050407410e-01
    z[0,5,3]  R410      2.0641303062438965e-01
    z[0,5,3]  R411      2.1087038516998291e-01
    z[0,5,3]  R412      -7.0434558391571045e-01
    z[0,5,3]  R413      8.4888547658920288e-02
    z[0,5,3]  R414      8.0051563680171967e-02
    z[0,5,3]  R415      7.6750802993774414e-01
    z[0,5,3]  R416      4.0120804309844971e-01
    z[0,5,3]  R417      5.6791716814041138e-01
    z[0,5,3]  R418      -3.0295112729072571e-01
    z[0,5,3]  R419      1.9151894748210907e-01
    z[0,5,3]  R420      1.3078117370605469e-01
    z[0,5,3]  R421      1.4946061372756958e-01
    z[0,5,3]  R422      0.159884512424469
    z[0,5,3]  R423      9.7060039639472961e-02
    z[0,5,3]  R424      2.1969486773014069e-01
    z[0,5,3]  R425      3.3871078491210938e-01
    z[0,5,3]  R426      4.5961785316467285e-01
    z[0,5,3]  R427      7.3579859733581543e-01
    z[0,5,3]  R428      8.0825246870517731e-02
    z[0,5,3]  R429      4.8096778988838196e-01
    z[0,5,3]  R430      8.0494147539138794e-01
    z[0,5,3]  R431      3.7761631608009338e-01
    z[0,5,3]  R432      1.8257418274879456e-01
    z[0,5,3]  R433      6.4273148775100708e-01
    z[0,5,3]  R434      2.2279354929924011e-01
    z[0,5,3]  R435      2.6987805962562561e-01
    z[0,5,3]  R436      1.9493977725505829e-01
    z[0,5,3]  R437      -1.9338284432888031e-01
    z[0,5,3]  R438      -0.388785719871521
    z[0,5,3]  R439      -1.7030143737792969e-01
    z[0,5,3]  R440      -2.7515235543251038e-01
    z[0,5,3]  R441      6.0826158523559570e-01
    z[0,5,3]  R442      1.6258460283279419e-01
    z[0,5,3]  R443      5.2279084920883179e-01
    z[0,5,3]  R444      -5.2511040121316910e-02
    z[0,5,3]  R445      -0.637824296951294
    z[0,5,3]  R446      -1.9327494502067566e-01
    z[0,5,3]  R447      -1.5178553760051727e-01
    z[0,5,3]  R448      5.1419204473495483e-01
    z[0,5,3]  R449      1.2139932811260223e-01
    z[0,5,3]  R450      3.3413335680961609e-02
    z[0,5,3]  R451      -4.9365319311618805e-02
    z[0,5,3]  R452      2.4444395303726196e-01
    z[0,5,3]  R453      -1.7017644643783569e-01
    z[0,5,3]  R454      5.3708422183990479e-01
    z[0,5,3]  R455      6.0811394453048706e-01
    z[0,5,3]  R456      -3.2972010970115662e-01
    z[0,5,3]  R457      7.2953003644943237e-01
    z[0,5,3]  R458      -2.7185928821563721e-01
    z[0,5,3]  R459      8.5692560672760010e-01
    z[0,5,3]  R460      -6.7722752690315247e-02
    z[0,5,3]  R461      -1.6869744658470154e-01
    z[0,5,3]  R462      -1.0491450130939484e-01
    z[0,5,3]  R463      2.3639321327209473e-01
    z[0,5,3]  R464      -5.7837799191474915e-02
    z[0,5,3]  R465      -5.0675177574157715e-01
    z[0,5,3]  R466      -3.2096511125564575e-01
    z[0,5,3]  R467      -7.4928396940231323e-01
    z[0,5,3]  R468      -4.3389534950256348e-01
    z[0,5,3]  R469      -7.7240854501724243e-01
    z[0,5,3]  R470      -8.7970989942550659e-01
    z[0,5,3]  R471      1.8954710662364960e-01
    z[0,5,3]  R472      3.9096572995185852e-01
    z[0,5,3]  R473      4.5994141697883606e-01
    z[0,5,3]  R474      3.7445747852325439e-01
    z[0,5,3]  R475      4.6504649519920349e-01
    z[0,5,3]  R476      3.9717164635658264e-01
    z[0,5,3]  R477      2.4929851293563843e-01
    z[0,5,3]  R478      2.7586460113525391e-01
    z[0,5,3]  R479      3.1510126590728760e-01
    z[0,5,3]  R480      4.0119731426239014e-01
    z[0,5,3]  R481      1.7297795414924622e-01
    z[0,5,3]  R482      5.4737234115600586e-01
    z[0,5,3]  R483      7.9029762744903564e-01
    z[0,5,3]  R484      3.0459839105606079e-01
    z[0,5,3]  R485      -5.2225482463836670e-01
    z[0,5,3]  R486      -6.8153828382492065e-02
    z[0,5,3]  R487      -0.325148344039917
    z[0,5,3]  R488      9.7793549299240112e-02
    z[0,5,3]  R489      8.6659216880798340e-01
    z[0,5,3]  R490      6.6719287633895874e-01
    z[0,5,3]  R491      2.0496146380901337e-01
    z[0,5,3]  R492      7.9203724861145020e-01
    z[0,5,3]  R493      4.9671131372451782e-01
    z[0,5,3]  R494      3.6976906657218933e-01
    z[0,5,3]  R495      -3.4159377217292786e-01
    z[0,5,3]  R496      -5.6467545032501221e-01
    z[0,5,3]  R497      7.7789083123207092e-02
    z[0,5,3]  R498      7.2253561019897461e-01
    z[0,5,3]  R499      8.7832385301589966e-01
    z[0,5,3]  R500      1.3626362383365631e-01
    z[0,5,3]  R501      2.0366945862770081e-01
    z[0,5,3]  R502      3.8393866270780563e-02
    z[0,5,3]  R503      7.4244342744350433e-02
    z[0,5,3]  R504      1.7947238683700562e-01
    z[0,5,4]  R6        -1
    z[0,5,4]  R51       1
    z[0,5,4]  R399      -1
    z[0,5,4]  R400      1
    z[0,5,4]  R405      8.9604228734970093e-02
    z[0,5,4]  R406      -2.8744882345199585e-01
    z[0,5,4]  R407      2.0206996798515320e-01
    z[0,5,4]  R408      4.4445816427469254e-02
    z[0,5,4]  R409      5.0837200880050659e-01
    z[0,5,4]  R410      -4.3901059031486511e-01
    z[0,5,4]  R411      1.6942851245403290e-01
    z[0,5,4]  R412      -1.9649676978588104e-02
    z[0,5,4]  R413      4.6485564112663269e-01
    z[0,5,4]  R414      -3.1988048553466797e-01
    z[0,5,4]  R415      4.0406605601310730e-01
    z[0,5,4]  R416      -0.0986860916018486
    z[0,5,4]  R417      1.2505438923835754e-01
    z[0,5,4]  R418      -4.3657961487770081e-01
    z[0,5,4]  R419      2.2704254090785980e-01
    z[0,5,4]  R420      -1.2737950682640076e-01
    z[0,5,4]  R421      -1.2335945852100849e-02
    z[0,5,4]  R422      -1.8066802620887756e-01
    z[0,5,4]  R423      1.6324238479137421e-01
    z[0,5,4]  R424      6.8727836012840271e-02
    z[0,5,4]  R425      2.3454587161540985e-01
    z[0,5,4]  R426      5.1327306032180786e-01
    z[0,5,4]  R427      -1.1139550060033798e-01
    z[0,5,4]  R428      3.7365466356277466e-01
    z[0,5,4]  R429      1.5394628047943115e-01
    z[0,5,4]  R430      3.2040628790855408e-01
    z[0,5,4]  R431      3.3972853422164917e-01
    z[0,5,4]  R432      -6.4457327127456665e-02
    z[0,5,4]  R433      -2.8373605012893677e-01
    z[0,5,4]  R434      -3.2385626435279846e-01
    z[0,5,4]  R435      3.6158025264739990e-02
    z[0,5,4]  R436      2.8707557916641235e-01
    z[0,5,4]  R437      -2.1785897016525269e-01
    z[0,5,4]  R438      1.3910777866840363e-01
    z[0,5,4]  R439      -3.3459064364433289e-01
    z[0,5,4]  R440      -6.3165277242660522e-02
    z[0,5,4]  R441      -3.0165541172027588e-01
    z[0,5,4]  R442      3.2457414269447327e-01
    z[0,5,4]  R443      -6.5735457465052605e-03
    z[0,5,4]  R444      -4.6645230054855347e-01
    z[0,5,4]  R445      -2.1367374062538147e-01
    z[0,5,4]  R446      2.4187627434730530e-01
    z[0,5,4]  R447      0.53766930103302
    z[0,5,4]  R448      -3.9414870738983154e-01
    z[0,5,4]  R449      3.7524050474166870e-01
    z[0,5,4]  R450      -4.3254144489765167e-02
    z[0,5,4]  R451      -1.3490395247936249e-01
    z[0,5,4]  R452      -2.7130043506622314e-01
    z[0,5,4]  R453      -1.6369469463825226e-02
    z[0,5,4]  R454      8.4502868354320526e-02
    z[0,5,4]  R455      2.5334203243255615e-01
    z[0,5,4]  R456      -3.5510438680648804e-01
    z[0,5,4]  R457      -4.4641056656837463e-01
    z[0,5,4]  R458      1.5092290937900543e-02
    z[0,5,4]  R459      -2.3525262251496315e-02
    z[0,5,4]  R460      -0.0577346533536911
    z[0,5,4]  R461      6.4896240830421448e-02
    z[0,5,4]  R462      -1.4085040986537933e-01
    z[0,5,4]  R463      9.8788976669311523e-02
    z[0,5,4]  R464      -4.1376795619726181e-02
    z[0,5,4]  R465      -2.8575715422630310e-01
    z[0,5,4]  R466      -1.8454520404338837e-01
    z[0,5,4]  R467      -3.4968233108520508e-01
    z[0,5,4]  R468      4.6732294559478760e-01
    z[0,5,4]  R469      2.3781870305538177e-01
    z[0,5,4]  R470      4.1085368394851685e-01
    z[0,5,4]  R471      2.2295117378234863e-01
    z[0,5,4]  R472      -8.1563211977481842e-02
    z[0,5,4]  R473      -2.1220222115516663e-01
    z[0,5,4]  R474      -3.0573877692222595e-01
    z[0,5,4]  R475      2.4600279331207275e-01
    z[0,5,4]  R476      3.3252504467964172e-01
    z[0,5,4]  R477      2.6147800683975220e-01
    z[0,5,4]  R478      3.6177039146423340e-02
    z[0,5,4]  R479      4.2754057049751282e-01
    z[0,5,4]  R480      9.0904332697391510e-02
    z[0,5,4]  R481      -4.3818231672048569e-02
    z[0,5,4]  R482      -3.0275815725326538e-01
    z[0,5,4]  R483      -3.1758925318717957e-01
    z[0,5,4]  R484      -4.6553325653076172e-01
    z[0,5,4]  R485      1.9628149271011353e-01
    z[0,5,4]  R486      0.199002206325531
    z[0,5,4]  R487      4.7966085374355316e-02
    z[0,5,4]  R488      1.9761617481708527e-01
    z[0,5,4]  R489      -2.1794937551021576e-01
    z[0,5,4]  R490      1.8959569931030273e-01
    z[0,5,4]  R491      -5.0455468893051147e-01
    z[0,5,4]  R492      1.9080387055873871e-01
    z[0,5,4]  R493      1.0679747909307480e-01
    z[0,5,4]  R494      -1.2663212604820728e-02
    z[0,5,4]  R495      5.3126418590545654e-01
    z[0,5,4]  R496      1.6516359522938728e-02
    z[0,5,4]  R497      -2.2923249751329422e-02
    z[0,5,4]  R498      -4.8711904883384705e-01
    z[0,5,4]  R499      -5.8242209255695343e-02
    z[0,5,4]  R500      9.7990795969963074e-02
    z[0,5,4]  R501      2.6208689436316490e-02
    z[0,5,4]  R502      1.7035382986068726e-01
    z[0,5,4]  R503      2.7062413096427917e-01
    z[0,5,4]  R504      1.5906998515129089e-01
    z[0,5,5]  R7        -1
    z[0,5,5]  R52       1
    z[0,5,5]  R401      -1
    z[0,5,5]  R402      1
    z[0,5,5]  R405      1.2492982298135757e-01
    z[0,5,5]  R406      0.175779327750206
    z[0,5,5]  R407      3.8542658090591431e-02
    z[0,5,5]  R408      -5.6672483682632446e-01
    z[0,5,5]  R409      -5.7694405317306519e-01
    z[0,5,5]  R410      3.2612487673759460e-01
    z[0,5,5]  R411      -2.9808858036994934e-01
    z[0,5,5]  R412      -4.0076601505279541e-01
    z[0,5,5]  R413      -3.8645300269126892e-01
    z[0,5,5]  R414      1.7766506969928741e-01
    z[0,5,5]  R415      -1.6486328095197678e-02
    z[0,5,5]  R416      0.503727912902832
    z[0,5,5]  R417      0.0744536742568016
    z[0,5,5]  R418      -9.5156140625476837e-02
    z[0,5,5]  R419      1.6693204641342163e-01
    z[0,5,5]  R420      0.0472993366420269
    z[0,5,5]  R421      1.6686005890369415e-01
    z[0,5,5]  R422      1.1024153977632523e-01
    z[0,5,5]  R423      2.0623014867305756e-01
    z[0,5,5]  R424      6.2137570232152939e-02
    z[0,5,5]  R425      9.5437504351139069e-02
    z[0,5,5]  R426      -6.5168537199497223e-02
    z[0,5,5]  R427      2.6004728674888611e-01
    z[0,5,5]  R428      -5.0996005535125732e-01
    z[0,5,5]  R429      -8.8554620742797852e-02
    z[0,5,5]  R430      -2.4945183098316193e-01
    z[0,5,5]  R431      -1.1956793069839478e-01
    z[0,5,5]  R432      2.5355464220046997e-01
    z[0,5,5]  R433      -1.7481237649917603e-01
    z[0,5,5]  R434      1.9550228118896484e-01
    z[0,5,5]  R435      1.8047341704368591e-01
    z[0,5,5]  R436      -3.0346742272377014e-01
    z[0,5,5]  R437      -7.9076945781707764e-02
    z[0,5,5]  R438      -1.2368068844079971e-01
    z[0,5,5]  R439      -3.5012704133987427e-01
    z[0,5,5]  R440      -3.4012833237648010e-01
    z[0,5,5]  R441      7.3924213647842407e-02
    z[0,5,5]  R442      6.5081994980573654e-03
    z[0,5,5]  R443      3.1589362025260925e-01
    z[0,5,5]  R444      -1.6483667492866516e-01
    z[0,5,5]  R445      -7.4559226632118225e-02
    z[0,5,5]  R446      -5.8781629800796509e-01
    z[0,5,5]  R447      -3.9033353328704834e-01
    z[0,5,5]  R448      -5.8267004787921906e-02
    z[0,5,5]  R449      4.9076753854751587e-01
    z[0,5,5]  R450      0.244783416390419
    z[0,5,5]  R451      -2.7149847149848938e-01
    z[0,5,5]  R452      6.3544875383377075e-01
    z[0,5,5]  R453      -2.7017769217491150e-01
    z[0,5,5]  R454      3.8683155179023743e-01
    z[0,5,5]  R455      5.0349522382020950e-02
    z[0,5,5]  R456      9.5458760857582092e-02
    z[0,5,5]  R457      1.5454442799091339e-01
    z[0,5,5]  R458      -4.0873834490776062e-01
    z[0,5,5]  R459      2.3882275447249413e-02
    z[0,5,5]  R460      5.4946172237396240e-01
    z[0,5,5]  R461      2.4371053278446198e-01
    z[0,5,5]  R462      4.0685775876045227e-01
    z[0,5,5]  R463      2.0834033191204071e-01
    z[0,5,5]  R464      2.9766580462455750e-01
    z[0,5,5]  R465      -6.2554180622100830e-02
    z[0,5,5]  R466      1.7089422047138214e-01
    z[0,5,5]  R467      1.0925537347793579e-01
    z[0,5,5]  R468      -3.3133661746978760e-01
    z[0,5,5]  R469      -4.5836070179939270e-01
    z[0,5,5]  R470      -5.0118938088417053e-02
    z[0,5,5]  R471      2.3242565989494324e-01
    z[0,5,5]  R472      2.5213134288787842e-01
    z[0,5,5]  R473      1.7320416867733002e-01
    z[0,5,5]  R474      2.6389557123184204e-01
    z[0,5,5]  R475      -0.0977431982755661
    z[0,5,5]  R476      4.1198879480361938e-02
    z[0,5,5]  R477      5.3055030107498169e-01
    z[0,5,5]  R478      2.8453812003135681e-01
    z[0,5,5]  R479      1.0688146948814392e-01
    z[0,5,5]  R480      -2.1798940002918243e-01
    z[0,5,5]  R481      -1.1671172827482224e-01
    z[0,5,5]  R482      -5.1127374172210693e-01
    z[0,5,5]  R483      -4.3282347917556763e-01
    z[0,5,5]  R484      -2.1012568473815918e-01
    z[0,5,5]  R485      3.9927309751510620e-01
    z[0,5,5]  R486      -7.2717852890491486e-02
    z[0,5,5]  R487      1.4325736463069916e-01
    z[0,5,5]  R488      -1.1089536361396313e-02
    z[0,5,5]  R489      -3.1884121894836426e-01
    z[0,5,5]  R490      -1.4226890169084072e-02
    z[0,5,5]  R491      1.7738994956016541e-01
    z[0,5,5]  R492      -1.8889398872852325e-01
    z[0,5,5]  R493      -3.1160369515419006e-01
    z[0,5,5]  R494      -1.8784089386463165e-01
    z[0,5,5]  R495      3.8963431119918823e-01
    z[0,5,5]  R496      3.4880438446998596e-01
    z[0,5,5]  R497      2.2839890420436859e-01
    z[0,5,5]  R498      -7.1575157344341278e-02
    z[0,5,5]  R499      -9.3093067407608032e-02
    z[0,5,5]  R500      3.8701677322387695e-01
    z[0,5,5]  R501      1.8997497856616974e-01
    z[0,5,5]  R502      3.9809203147888184e-01
    z[0,5,5]  R503      5.3611434996128082e-02
    z[0,5,5]  R504      -2.5995871052145958e-02
    z[0,5,6]  R8        -1
    z[0,5,6]  R53       1
    z[0,5,6]  R403      -1
    z[0,5,6]  R404      1
    z[0,5,6]  R405      1.3191461563110352e-01
    z[0,5,6]  R406      0.0874442458152771
    z[0,5,6]  R407      -4.4186714291572571e-01
    z[0,5,6]  R408      -3.0732482671737671e-01
    z[0,5,6]  R409      -5.3932290524244308e-02
    z[0,5,6]  R410      -0.401030957698822
    z[0,5,6]  R411      -2.5396207347512245e-02
    z[0,5,6]  R412      -4.6218344569206238e-01
    z[0,5,6]  R413      -3.9516305923461914e-01
    z[0,5,6]  R414      -4.1228723526000977e-01
    z[0,5,6]  R415      3.7462085485458374e-01
    z[0,5,6]  R416      5.2376669645309448e-01
    z[0,5,6]  R417      -1.5266944468021393e-01
    z[0,5,6]  R418      2.0077311992645264e-01
    z[0,5,6]  R419      2.9434624314308167e-01
    z[0,5,6]  R420      0.16197469830513
    z[0,5,6]  R421      0.0212846789509058
    z[0,5,6]  R422      6.1095900833606720e-02
    z[0,5,6]  R423      -2.5218958035111427e-02
    z[0,5,6]  R424      -1.1041018366813660e-01
    z[0,5,6]  R425      1.9928197562694550e-01
    z[0,5,6]  R426      8.4426812827587128e-03
    z[0,5,6]  R427      -4.0857456624507904e-02
    z[0,5,6]  R428      0.0263714250177145
    z[0,5,6]  R429      -3.8630792498588562e-01
    z[0,5,6]  R430      -2.9359987378120422e-01
    z[0,5,6]  R431      -6.8870788812637329e-01
    z[0,5,6]  R432      5.9921962022781372e-01
    z[0,5,6]  R433      -3.0938610434532166e-02
    z[0,5,6]  R434      2.7243435382843018e-01
    z[0,5,6]  R435      -4.6066647768020630e-01
    z[0,5,6]  R436      -2.8735786676406860e-01
    z[0,5,6]  R437      -1.0418348759412766e-01
    z[0,5,6]  R438      3.6686885356903076e-01
    z[0,5,6]  R439      1.9505521282553673e-02
    z[0,5,6]  R440      5.7073158025741577e-01
    z[0,5,6]  R441      -1.5794268250465393e-01
    z[0,5,6]  R442      3.0939567089080811e-01
    z[0,5,6]  R443      2.5403586030006409e-01
    z[0,5,6]  R444      3.1916892528533936e-01
    z[0,5,6]  R445      2.3045334219932556e-01
    z[0,5,6]  R446      2.3487238585948944e-01
    z[0,5,6]  R447      1.5198100358247757e-02
    z[0,5,6]  R448      -1.3912385702133179e-01
    z[0,5,6]  R449      2.2606596350669861e-01
    z[0,5,6]  R450      2.0908632874488831e-01
    z[0,5,6]  R451      5.1905751228332520e-01
    z[0,5,6]  R452      -1.1375757306814194e-01
    z[0,5,6]  R453      3.3053648471832275e-01
    z[0,5,6]  R454      -1.7875127494335175e-01
    z[0,5,6]  R455      -1.7471471428871155e-01
    z[0,5,6]  R456      -3.0696097016334534e-01
    z[0,5,6]  R457      -1.4413294196128845e-01
    z[0,5,6]  R458      -1.9780771806836128e-02
    z[0,5,6]  R459      -4.2399564385414124e-01
    z[0,5,6]  R460      3.5136872529983521e-01
    z[0,5,6]  R461      2.3495469987392426e-01
    z[0,5,6]  R462      -0.0321926586329937
    z[0,5,6]  R463      5.2557539194822311e-02
    z[0,5,6]  R464      2.3745338618755341e-01
    z[0,5,6]  R465      -1.9355228543281555e-01
    z[0,5,6]  R466      1.3423733413219452e-01
    z[0,5,6]  R467      0.30905881524086
    z[0,5,6]  R468      1.7634055018424988e-01
    z[0,5,6]  R469      -2.1055087447166443e-01
    z[0,5,6]  R470      -3.4079153090715408e-02
    z[0,5,6]  R471      -2.0666822791099548e-01
    z[0,5,6]  R472      1.6213466227054596e-01
    z[0,5,6]  R473      -4.1867125034332275e-01
    z[0,5,6]  R474      -5.0013452768325806e-01
    z[0,5,6]  R475      -2.2686445713043213e-01
    z[0,5,6]  R476      -5.4530304670333862e-01
    z[0,5,6]  R477      -1.1884658038616180e-01
    z[0,5,6]  R478      -3.5577270388603210e-01
    z[0,5,6]  R479      3.8494133949279785e-01
    z[0,5,6]  R480      4.9901410937309265e-01
    z[0,5,6]  R481      3.3552783727645874e-01
    z[0,5,6]  R482      -7.8751757740974426e-02
    z[0,5,6]  R483      -1.5964034199714661e-01
    z[0,5,6]  R484      3.8278706371784210e-02
    z[0,5,6]  R485      -4.5227617025375366e-01
    z[0,5,6]  R486      -8.8160365819931030e-02
    z[0,5,6]  R487      3.7805411219596863e-01
    z[0,5,6]  R488      6.4236021041870117e-01
    z[0,5,6]  R489      6.8818684667348862e-03
    z[0,5,6]  R490      -4.1248893737792969e-01
    z[0,5,6]  R491      -6.3212528824806213e-02
    z[0,5,6]  R492      -2.9576432704925537e-01
    z[0,5,6]  R493      0.314543753862381
    z[0,5,6]  R494      -1.1832013726234436e-01
    z[0,5,6]  R495      2.9909417033195496e-02
    z[0,5,6]  R496      -4.3837600946426392e-01
    z[0,5,6]  R497      5.3634178638458252e-01
    z[0,5,6]  R498      8.4394156932830811e-02
    z[0,5,6]  R499      -1.1843344569206238e-01
    z[0,5,6]  R500      -2.2284707054495811e-02
    z[0,5,6]  R501      -1.1479567736387253e-01
    z[0,5,6]  R502      -2.3684035986661911e-02
    z[0,5,6]  R503      6.5544582903385162e-02
    z[0,5,6]  R504      -1.7695156857371330e-03
    z[5,0,0]  R2        1
    z[5,0,0]  R47       -1
    z[5,0,0]  R505      -1
    z[5,0,0]  R506      1
    z[5,0,0]  R519      -9.8129129037261009e-03
    z[5,0,0]  R520      1.9520588219165802e-01
    z[5,0,0]  R521      -1.5761759877204895e-01
    z[5,0,0]  R522      2.8266796469688416e-01
    z[5,0,0]  R523      -0.0914662703871727
    z[5,0,0]  R524      3.5185284912586212e-02
    z[5,0,0]  R525      -4.4540934264659882e-02
    z[5,0,0]  R526      -1.4993159100413322e-02
    z[5,0,0]  R527      -1.7481365799903870e-01
    z[5,0,0]  R528      -1.2111248821020126e-01
    z[5,0,0]  R529      2.3999631404876709e-01
    z[5,0,0]  R530      3.7114644050598145e-01
    z[5,0,0]  R531      3.3333885669708252e-01
    z[5,0,0]  R532      1.5405425429344177e-01
    z[5,0,0]  R533      0.344827800989151
    z[5,0,0]  R534      1.6298142075538635e-01
    z[5,0,0]  R535      -6.8737521767616272e-02
    z[5,0,0]  R536      1.7824020236730576e-02
    z[5,0,0]  R537      -1.6613408923149109e-01
    z[5,0,0]  R538      -0.219927579164505
    z[5,0,0]  R539      0.153601735830307
    z[5,0,0]  R540      2.2325752675533295e-01
    z[5,0,0]  R541      7.2254180908203125e-02
    z[5,0,0]  R542      3.1756952404975891e-01
    z[5,0,0]  R543      8.4015719592571259e-02
    z[5,0,0]  R544      5.8751013129949570e-02
    z[5,0,0]  R545      -4.2334833741188049e-01
    z[5,0,0]  R546      2.5880929827690125e-01
    z[5,0,0]  R547      -1.4871890842914581e-01
    z[5,0,0]  R548      -0.283314973115921
    z[5,0,0]  R549      4.5690831542015076e-01
    z[5,0,0]  R550      1.1496644467115402e-01
    z[5,0,0]  R551      2.3103404045104980e-01
    z[5,0,0]  R552      -2.2177945077419281e-01
    z[5,0,0]  R553      3.5804096609354019e-02
    z[5,0,0]  R554      -6.4874303340911865e-01
    z[5,0,0]  R555      -7.3766535520553589e-01
    z[5,0,0]  R556      -3.5329201817512512e-01
    z[5,0,0]  R557      -9.5257240533828735e-01
    z[5,0,0]  R558      -9.4518017768859863e-01
    z[5,0,0]  R559      4.9490082263946533e-01
    z[5,0,0]  R560      4.1498789191246033e-01
    z[5,0,0]  R561      5.6200385093688965e-01
    z[5,0,0]  R562      -2.7195507287979126e-01
    z[5,0,0]  R563      -1.5923419594764709e-01
    z[5,0,0]  R564      1.1338619142770767e-01
    z[5,0,0]  R565      -5.6006636470556259e-02
    z[5,0,0]  R566      -2.2266621887683868e-01
    z[5,0,0]  R567      1.8465099856257439e-02
    z[5,0,0]  R568      6.4370214939117432e-02
    z[5,0,0]  R569      1.5307880938053131e-01
    z[5,0,0]  R570      7.3211260139942169e-02
    z[5,0,0]  R571      3.4881255030632019e-01
    z[5,0,0]  R572      -3.8617795705795288e-01
    z[5,0,0]  R573      -1.6033592820167542e-01
    z[5,0,0]  R574      -5.0186461210250854e-01
    z[5,0,0]  R575      -4.7637766599655151e-01
    z[5,0,0]  R576      -0.341469407081604
    z[5,0,0]  R577      -4.7362893819808960e-01
    z[5,0,0]  R578      -2.7223885059356689e-01
    z[5,0,0]  R579      2.4971213936805725e-01
    z[5,0,0]  R580      -6.0493912547826767e-02
    z[5,0,0]  R581      -0.0623035691678524
    z[5,0,0]  R582      1.6990311443805695e-02
    z[5,0,0]  R583      3.0292698740959167e-01
    z[5,0,0]  R584      -1.4488242566585541e-01
    z[5,0,0]  R585      2.6645186543464661e-01
    z[5,0,0]  R586      -1.6680526733398438e-01
    z[5,0,0]  R587      -6.0302621126174927e-01
    z[5,0,0]  R588      -4.7555884718894958e-01
    z[5,0,0]  R589      3.0833488702774048e-01
    z[5,0,0]  R590      3.6954346299171448e-01
    z[5,0,0]  R591      1.3853612542152405e-01
    z[5,0,0]  R592      1.1774213053286076e-02
    z[5,0,0]  R593      -3.4528955817222595e-01
    z[5,0,0]  R594      -0.51384037733078
    z[5,0,0]  R595      2.9657664895057678e-01
    z[5,0,0]  R596      3.4071081876754761e-01
    z[5,0,0]  R597      4.9104800820350647e-01
    z[5,0,0]  R598      -5.7003223896026611e-01
    z[5,0,0]  R599      -0.0688767358660698
    z[5,0,0]  R600      -4.3175253272056580e-01
    z[5,0,0]  R601      1.4744243025779724e-01
    z[5,0,0]  R602      -1.8172748386859894e-01
    z[5,0,0]  R603      6.0729360580444336e-01
    z[5,0,0]  R604      7.0505076646804810e-01
    z[5,0,0]  R605      -5.4727524518966675e-01
    z[5,0,0]  R606      6.3396120071411133e-01
    z[5,0,0]  R607      -4.9636000394821167e-01
    z[5,0,0]  R608      7.1425217390060425e-01
    z[5,0,0]  R609      2.8491258621215820e-01
    z[5,0,0]  R610      2.6955893635749817e-01
    z[5,0,0]  R611      1.4603634178638458e-01
    z[5,0,0]  R612      -6.4753681421279907e-02
    z[5,0,0]  R613      2.0705427229404449e-01
    z[5,0,0]  R614      4.6588051319122314e-01
    z[5,0,0]  R615      -6.0379576683044434e-01
    z[5,0,0]  R616      -7.6082962751388550e-01
    z[5,0,0]  R617      -7.6411402225494385e-01
    z[5,0,0]  R618      -8.1588953733444214e-01
    z[5,0,1]  R3        1
    z[5,0,1]  R48       -1
    z[5,0,1]  R507      -1
    z[5,0,1]  R508      1
    z[5,0,1]  R519      -3.6789214611053467e-01
    z[5,0,1]  R520      -5.0035309791564941e-01
    z[5,0,1]  R521      -3.2951968908309937e-01
    z[5,0,1]  R522      -1.0314059257507324e-01
    z[5,0,1]  R523      -2.8634673357009888e-01
    z[5,0,1]  R524      -1.9924721121788025e-01
    z[5,0,1]  R525      8.7003123760223389e-01
    z[5,0,1]  R526      8.0698674917221069e-01
    z[5,0,1]  R527      6.1325830221176147e-01
    z[5,0,1]  R528      5.8618915081024170e-01
    z[5,0,1]  R529      -6.2944030761718750e-01
    z[5,0,1]  R530      -5.4059320688247681e-01
    z[5,0,1]  R531      -5.4516172409057617e-01
    z[5,0,1]  R532      -6.5914779901504517e-01
    z[5,0,1]  R533      -4.8302519321441650e-01
    z[5,0,1]  R534      -5.9477454423904419e-01
    z[5,0,1]  R535      -5.0718593597412109e-01
    z[5,0,1]  R536      -5.7386404275894165e-01
    z[5,0,1]  R537      1.0970901697874069e-01
    z[5,0,1]  R538      -5.7534945011138916e-01
    z[5,0,1]  R539      -5.3369557857513428e-01
    z[5,0,1]  R540      -8.9994937181472778e-01
    z[5,0,1]  R541      -7.2926950454711914e-01
    z[5,0,1]  R542      -6.6056615114212036e-01
    z[5,0,1]  R543      1.3864208944141865e-02
    z[5,0,1]  R544      5.8342820405960083e-01
    z[5,0,1]  R545      6.5766614675521851e-01
    z[5,0,1]  R546      2.0050309598445892e-01
    z[5,0,1]  R547      5.5003219842910767e-01
    z[5,0,1]  R548      4.6862110495567322e-01
    z[5,0,1]  R549      -0.463623583316803
    z[5,0,1]  R550      -5.8346712589263916e-01
    z[5,0,1]  R551      -7.5760698318481445e-01
    z[5,0,1]  R552      4.2335048317909241e-01
    z[5,0,1]  R553      4.4613838195800781e-01
    z[5,0,1]  R554      1.3833696953952312e-02
    z[5,0,1]  R555      -3.3223412930965424e-02
    z[5,0,1]  R556      2.0151835680007935e-01
    z[5,0,1]  R557      -4.3788510374724865e-03
    z[5,0,1]  R558      -1.3158197514712811e-02
    z[5,0,1]  R559      -2.3231776058673859e-01
    z[5,0,1]  R560      -4.2521899938583374e-01
    z[5,0,1]  R561      -2.8838777542114258e-01
    z[5,0,1]  R562      -2.9415807127952576e-01
    z[5,0,1]  R563      -1.8136461079120636e-01
    z[5,0,1]  R564      0.614677906036377
    z[5,0,1]  R565      8.8259148597717285e-01
    z[5,0,1]  R566      -1.2112042307853699e-01
    z[5,0,1]  R567      -2.1046364307403564e-01
    z[5,0,1]  R568      8.1843149662017822e-01
    z[5,0,1]  R569      1.2217903882265091e-01
    z[5,0,1]  R570      4.1422221064567566e-01
    z[5,0,1]  R571      -5.2835303544998169e-01
    z[5,0,1]  R572      -6.0785013437271118e-01
    z[5,0,1]  R573      2.9621484875679016e-01
    z[5,0,1]  R574      1.9389666616916656e-01
    z[5,0,1]  R575      -1.0692614316940308e-01
    z[5,0,1]  R576      3.5085476934909821e-02
    z[5,0,1]  R577      0.0629362165927887
    z[5,0,1]  R578      1.1717350780963898e-01
    z[5,0,1]  R579      4.6073517203330994e-01
    z[5,0,1]  R580      7.1917676925659180e-01
    z[5,0,1]  R581      5.5513072013854980e-01
    z[5,0,1]  R582      -5.3189247846603394e-01
    z[5,0,1]  R583      1.9663409888744354e-01
    z[5,0,1]  R584      0.213766410946846
    z[5,0,1]  R585      3.8322755694389343e-01
    z[5,0,1]  R586      6.5201544761657715e-01
    z[5,0,1]  R587      3.3321052789688110e-01
    z[5,0,1]  R588      6.9712668657302856e-01
    z[5,0,1]  R589      6.4458996057510376e-01
    z[5,0,1]  R590      -5.9066683053970337e-01
    z[5,0,1]  R591      -9.1286391019821167e-01
    z[5,0,1]  R592      -0.74636310338974
    z[5,0,1]  R593      -0.783897876739502
    z[5,0,1]  R594      -4.5693665742874146e-01
    z[5,0,1]  R595      -0.637538731098175
    z[5,0,1]  R596      -7.2442001104354858e-01
    z[5,0,1]  R597      -5.1696652173995972e-01
    z[5,0,1]  R598      1.1333186924457550e-01
    z[5,0,1]  R599      -6.8740415573120117e-01
    z[5,0,1]  R600      -5.5598491430282593e-01
    z[5,0,1]  R601      -7.0357513427734375e-01
    z[5,0,1]  R602      2.2914955019950867e-01
    z[5,0,1]  R603      3.8495090603828430e-01
    z[5,0,1]  R604      6.1672019958496094e-01
    z[5,0,1]  R605      1.0403732955455780e-01
    z[5,0,1]  R606      2.6857027783989906e-02
    z[5,0,1]  R607      3.9084741473197937e-01
    z[5,0,1]  R608      -1.0710010677576065e-01
    z[5,0,1]  R609      4.6051979064941406e-01
    z[5,0,1]  R610      -7.3174512386322021e-01
    z[5,0,1]  R611      -9.7263120114803314e-02
    z[5,0,1]  R612      -8.4369462728500366e-01
    z[5,0,1]  R613      1.1094018071889877e-01
    z[5,0,1]  R614      5.9087282419204712e-01
    z[5,0,1]  R615      -1.5158358030021191e-02
    z[5,0,1]  R616      -4.9962759017944336e-02
    z[5,0,1]  R617      -3.1675678491592407e-01
    z[5,0,1]  R618      -1.8333867192268372e-01
    z[5,0,2]  R4        1
    z[5,0,2]  R49       -1
    z[5,0,2]  R509      -1
    z[5,0,2]  R510      1
    z[5,0,2]  R519      -6.9622492790222168e-01
    z[5,0,2]  R520      -7.2611391544342041e-01
    z[5,0,2]  R521      -2.7461823821067810e-01
    z[5,0,2]  R522      -6.0160207748413086e-01
    z[5,0,2]  R523      4.5172579586505890e-02
    z[5,0,2]  R524      1.1268923431634903e-01
    z[5,0,2]  R525      2.4226620793342590e-01
    z[5,0,2]  R526      -3.1493294239044189e-01
    z[5,0,2]  R527      3.6262005567550659e-01
    z[5,0,2]  R528      -2.9705882072448730e-01
    z[5,0,2]  R529      4.5650824904441833e-01
    z[5,0,2]  R530      0.0513649582862854
    z[5,0,2]  R531      4.0688481926918030e-01
    z[5,0,2]  R532      5.0679886341094971e-01
    z[5,0,2]  R533      4.5397931337356567e-01
    z[5,0,2]  R534      3.9233011007308960e-01
    z[5,0,2]  R535      7.6157444715499878e-01
    z[5,0,2]  R536      -1.0714815557003021e-01
    z[5,0,2]  R537      1.4869058132171631e-01
    z[5,0,2]  R538      5.1525270938873291e-01
    z[5,0,2]  R539      1.2777386605739594e-01
    z[5,0,2]  R540      2.8799328207969666e-01
    z[5,0,2]  R541      4.3757927417755127e-01
    z[5,0,2]  R542      3.7901647388935089e-02
    z[5,0,2]  R543      -3.0423361063003540e-01
    z[5,0,2]  R544      0.0686836838722229
    z[5,0,2]  R545      2.3707339167594910e-01
    z[5,0,2]  R546      -3.2546824216842651e-01
    z[5,0,2]  R547      4.7030287981033325e-01
    z[5,0,2]  R548      7.1690547466278076e-01
    z[5,0,2]  R549      -1.5700435638427734e-01
    z[5,0,2]  R550      -1.1567012220621109e-01
    z[5,0,2]  R551      1.6201768815517426e-01
    z[5,0,2]  R552      -0.000394883711123839
    z[5,0,2]  R553      -4.6268694102764130e-02
    z[5,0,2]  R554      0.632844865322113
    z[5,0,2]  R555      6.0275137424468994e-01
    z[5,0,2]  R556      8.0314534902572632e-01
    z[5,0,2]  R557      -8.1650130450725555e-02
    z[5,0,2]  R558      -2.1970146894454956e-01
    z[5,0,2]  R559      -5.7488650083541870e-01
    z[5,0,2]  R560      -6.2625670433044434e-01
    z[5,0,2]  R561      -8.8665857911109924e-02
    z[5,0,2]  R562      -5.7745444774627686e-01
    z[5,0,2]  R563      -4.2030754685401917e-01
    z[5,0,2]  R564      -3.2679456472396851e-01
    z[5,0,2]  R565      2.3499237000942230e-01
    z[5,0,2]  R566      -2.5501725077629089e-01
    z[5,0,2]  R567      -6.5312135219573975e-01
    z[5,0,2]  R568      1.2549513578414917e-01
    z[5,0,2]  R569      -2.6208499073982239e-01
    z[5,0,2]  R570      3.5253354907035828e-01
    z[5,0,2]  R571      4.8182269930839539e-01
    z[5,0,2]  R572      3.8683211803436279e-01
    z[5,0,2]  R573      8.2693123817443848e-01
    z[5,0,2]  R574      8.0544006824493408e-01
    z[5,0,2]  R575      8.4311634302139282e-01
    z[5,0,2]  R576      8.9893138408660889e-01
    z[5,0,2]  R577      0.8321533203125
    z[5,0,2]  R578      9.1821324825286865e-01
    z[5,0,2]  R579      -7.1190494298934937e-01
    z[5,0,2]  R580      1.0455914773046970e-02
    z[5,0,2]  R581      2.5464800000190735e-01
    z[5,0,2]  R582      -5.5668348073959351e-01
    z[5,0,2]  R583      -0.676361620426178
    z[5,0,2]  R584      1.8518878519535065e-01
    z[5,0,2]  R585      -1.8845534324645996e-01
    z[5,0,2]  R586      -2.9361501336097717e-01
    z[5,0,2]  R587      1.4269612729549408e-02
    z[5,0,2]  R588      1.4455687999725342e-01
    z[5,0,2]  R589      -4.1292563080787659e-01
    z[5,0,2]  R590      -4.6847561001777649e-01
    z[5,0,2]  R591      2.1335519850254059e-01
    z[5,0,2]  R592      3.4986928105354309e-01
    z[5,0,2]  R593      -4.8542730510234833e-02
    z[5,0,2]  R594      -7.7823407948017120e-02
    z[5,0,2]  R595      -1.1915443092584610e-01
    z[5,0,2]  R596      3.6274176836013794e-01
    z[5,0,2]  R597      2.3225225508213043e-01
    z[5,0,2]  R598      -5.5932450294494629e-01
    z[5,0,2]  R599      1.0764485597610474e-01
    z[5,0,2]  R600      -8.8984228670597076e-02
    z[5,0,2]  R601      1.3610440492630005e-01
    z[5,0,2]  R602      -6.8699955940246582e-01
    z[5,0,2]  R603      1.8842889368534088e-01
    z[5,0,2]  R604      1.2623888254165649e-01
    z[5,0,2]  R605      -5.7087469100952148e-01
    z[5,0,2]  R606      2.1743780374526978e-01
    z[5,0,2]  R607      -6.2400847673416138e-01
    z[5,0,2]  R608      3.4387171268463135e-02
    z[5,0,2]  R609      -4.8959305882453918e-01
    z[5,0,2]  R610      2.3180879652500153e-01
    z[5,0,2]  R611      -4.3938422203063965e-01
    z[5,0,2]  R612      -2.0589542388916016e-01
    z[5,0,2]  R613      -1.7205569148063660e-01
    z[5,0,2]  R614      -2.3169048130512238e-02
    z[5,0,2]  R615      6.9852125644683838e-01
    z[5,0,2]  R616      0.470347136259079
    z[5,0,2]  R617      4.5164796710014343e-01
    z[5,0,2]  R618      3.8815578818321228e-01
    z[5,0,3]  R5        1
    z[5,0,3]  R50       -1
    z[5,0,3]  R511      -1
    z[5,0,3]  R512      1
    z[5,0,3]  R519      -5.0675177574157715e-01
    z[5,0,3]  R520      -3.2096511125564575e-01
    z[5,0,3]  R521      -7.4928396940231323e-01
    z[5,0,3]  R522      -4.3389534950256348e-01
    z[5,0,3]  R523      -7.7240854501724243e-01
    z[5,0,3]  R524      -8.7970989942550659e-01
    z[5,0,3]  R525      1.8954710662364960e-01
    z[5,0,3]  R526      3.9096572995185852e-01
    z[5,0,3]  R527      4.5994141697883606e-01
    z[5,0,3]  R528      3.7445747852325439e-01
    z[5,0,3]  R529      4.6504649519920349e-01
    z[5,0,3]  R530      3.9717164635658264e-01
    z[5,0,3]  R531      2.4929851293563843e-01
    z[5,0,3]  R532      2.7586460113525391e-01
    z[5,0,3]  R533      3.1510126590728760e-01
    z[5,0,3]  R534      4.0119731426239014e-01
    z[5,0,3]  R535      1.7297795414924622e-01
    z[5,0,3]  R536      5.4737234115600586e-01
    z[5,0,3]  R537      7.9029762744903564e-01
    z[5,0,3]  R538      3.0459839105606079e-01
    z[5,0,3]  R539      -5.2225482463836670e-01
    z[5,0,3]  R540      -6.8153828382492065e-02
    z[5,0,3]  R541      -0.325148344039917
    z[5,0,3]  R542      9.7793549299240112e-02
    z[5,0,3]  R543      8.6659216880798340e-01
    z[5,0,3]  R544      6.6719287633895874e-01
    z[5,0,3]  R545      2.0496146380901337e-01
    z[5,0,3]  R546      7.9203724861145020e-01
    z[5,0,3]  R547      4.9671131372451782e-01
    z[5,0,3]  R548      3.6976906657218933e-01
    z[5,0,3]  R549      -3.4159377217292786e-01
    z[5,0,3]  R550      -5.6467545032501221e-01
    z[5,0,3]  R551      7.7789083123207092e-02
    z[5,0,3]  R552      7.2253561019897461e-01
    z[5,0,3]  R553      8.7832385301589966e-01
    z[5,0,3]  R554      1.3626362383365631e-01
    z[5,0,3]  R555      2.0366945862770081e-01
    z[5,0,3]  R556      3.8393866270780563e-02
    z[5,0,3]  R557      7.4244342744350433e-02
    z[5,0,3]  R558      1.7947238683700562e-01
    z[5,0,3]  R559      -5.7408112287521362e-01
    z[5,0,3]  R560      -3.6551985144615173e-01
    z[5,0,3]  R561      -5.9628689289093018e-01
    z[5,0,3]  R562      -2.9741668701171875e-01
    z[5,0,3]  R563      -4.1337344050407410e-01
    z[5,0,3]  R564      2.0641303062438965e-01
    z[5,0,3]  R565      2.1087038516998291e-01
    z[5,0,3]  R566      -7.0434558391571045e-01
    z[5,0,3]  R567      8.4888547658920288e-02
    z[5,0,3]  R568      8.0051563680171967e-02
    z[5,0,3]  R569      7.6750802993774414e-01
    z[5,0,3]  R570      4.0120804309844971e-01
    z[5,0,3]  R571      5.6791716814041138e-01
    z[5,0,3]  R572      -3.0295112729072571e-01
    z[5,0,3]  R573      1.9151894748210907e-01
    z[5,0,3]  R574      1.3078117370605469e-01
    z[5,0,3]  R575      1.4946061372756958e-01
    z[5,0,3]  R576      0.159884512424469
    z[5,0,3]  R577      9.7060039639472961e-02
    z[5,0,3]  R578      2.1969486773014069e-01
    z[5,0,3]  R579      3.3871078491210938e-01
    z[5,0,3]  R580      4.5961785316467285e-01
    z[5,0,3]  R581      7.3579859733581543e-01
    z[5,0,3]  R582      8.0825246870517731e-02
    z[5,0,3]  R583      4.8096778988838196e-01
    z[5,0,3]  R584      8.0494147539138794e-01
    z[5,0,3]  R585      3.7761631608009338e-01
    z[5,0,3]  R586      1.8257418274879456e-01
    z[5,0,3]  R587      6.4273148775100708e-01
    z[5,0,3]  R588      2.2279354929924011e-01
    z[5,0,3]  R589      2.6987805962562561e-01
    z[5,0,3]  R590      1.9493977725505829e-01
    z[5,0,3]  R591      -1.9338284432888031e-01
    z[5,0,3]  R592      -0.388785719871521
    z[5,0,3]  R593      -1.7030143737792969e-01
    z[5,0,3]  R594      -2.7515235543251038e-01
    z[5,0,3]  R595      6.0826158523559570e-01
    z[5,0,3]  R596      1.6258460283279419e-01
    z[5,0,3]  R597      5.2279084920883179e-01
    z[5,0,3]  R598      -5.2511040121316910e-02
    z[5,0,3]  R599      -0.637824296951294
    z[5,0,3]  R600      -1.9327494502067566e-01
    z[5,0,3]  R601      -1.5178553760051727e-01
    z[5,0,3]  R602      5.1419204473495483e-01
    z[5,0,3]  R603      1.2139932811260223e-01
    z[5,0,3]  R604      3.3413335680961609e-02
    z[5,0,3]  R605      -4.9365319311618805e-02
    z[5,0,3]  R606      2.4444395303726196e-01
    z[5,0,3]  R607      -1.7017644643783569e-01
    z[5,0,3]  R608      5.3708422183990479e-01
    z[5,0,3]  R609      6.0811394453048706e-01
    z[5,0,3]  R610      -3.2972010970115662e-01
    z[5,0,3]  R611      7.2953003644943237e-01
    z[5,0,3]  R612      -2.7185928821563721e-01
    z[5,0,3]  R613      8.5692560672760010e-01
    z[5,0,3]  R614      -6.7722752690315247e-02
    z[5,0,3]  R615      -1.6869744658470154e-01
    z[5,0,3]  R616      -1.0491450130939484e-01
    z[5,0,3]  R617      2.3639321327209473e-01
    z[5,0,3]  R618      -5.7837799191474915e-02
    z[5,0,4]  R6        1
    z[5,0,4]  R51       -1
    z[5,0,4]  R513      -1
    z[5,0,4]  R514      1
    z[5,0,4]  R519      -2.8575715422630310e-01
    z[5,0,4]  R520      -1.8454520404338837e-01
    z[5,0,4]  R521      -3.4968233108520508e-01
    z[5,0,4]  R522      4.6732294559478760e-01
    z[5,0,4]  R523      2.3781870305538177e-01
    z[5,0,4]  R524      4.1085368394851685e-01
    z[5,0,4]  R525      2.2295117378234863e-01
    z[5,0,4]  R526      -8.1563211977481842e-02
    z[5,0,4]  R527      -2.1220222115516663e-01
    z[5,0,4]  R528      -3.0573877692222595e-01
    z[5,0,4]  R529      2.4600279331207275e-01
    z[5,0,4]  R530      3.3252504467964172e-01
    z[5,0,4]  R531      2.6147800683975220e-01
    z[5,0,4]  R532      3.6177039146423340e-02
    z[5,0,4]  R533      4.2754057049751282e-01
    z[5,0,4]  R534      9.0904332697391510e-02
    z[5,0,4]  R535      -4.3818231672048569e-02
    z[5,0,4]  R536      -3.0275815725326538e-01
    z[5,0,4]  R537      -3.1758925318717957e-01
    z[5,0,4]  R538      -4.6553325653076172e-01
    z[5,0,4]  R539      1.9628149271011353e-01
    z[5,0,4]  R540      0.199002206325531
    z[5,0,4]  R541      4.7966085374355316e-02
    z[5,0,4]  R542      1.9761617481708527e-01
    z[5,0,4]  R543      -2.1794937551021576e-01
    z[5,0,4]  R544      1.8959569931030273e-01
    z[5,0,4]  R545      -5.0455468893051147e-01
    z[5,0,4]  R546      1.9080387055873871e-01
    z[5,0,4]  R547      1.0679747909307480e-01
    z[5,0,4]  R548      -1.2663212604820728e-02
    z[5,0,4]  R549      5.3126418590545654e-01
    z[5,0,4]  R550      1.6516359522938728e-02
    z[5,0,4]  R551      -2.2923249751329422e-02
    z[5,0,4]  R552      -4.8711904883384705e-01
    z[5,0,4]  R553      -5.8242209255695343e-02
    z[5,0,4]  R554      9.7990795969963074e-02
    z[5,0,4]  R555      2.6208689436316490e-02
    z[5,0,4]  R556      1.7035382986068726e-01
    z[5,0,4]  R557      2.7062413096427917e-01
    z[5,0,4]  R558      1.5906998515129089e-01
    z[5,0,4]  R559      8.9604228734970093e-02
    z[5,0,4]  R560      -2.8744882345199585e-01
    z[5,0,4]  R561      2.0206996798515320e-01
    z[5,0,4]  R562      4.4445816427469254e-02
    z[5,0,4]  R563      5.0837200880050659e-01
    z[5,0,4]  R564      -4.3901059031486511e-01
    z[5,0,4]  R565      1.6942851245403290e-01
    z[5,0,4]  R566      -1.9649676978588104e-02
    z[5,0,4]  R567      4.6485564112663269e-01
    z[5,0,4]  R568      -3.1988048553466797e-01
    z[5,0,4]  R569      4.0406605601310730e-01
    z[5,0,4]  R570      -0.0986860916018486
    z[5,0,4]  R571      1.2505438923835754e-01
    z[5,0,4]  R572      -4.3657961487770081e-01
    z[5,0,4]  R573      2.2704254090785980e-01
    z[5,0,4]  R574      -1.2737950682640076e-01
    z[5,0,4]  R575      -1.2335945852100849e-02
    z[5,0,4]  R576      -1.8066802620887756e-01
    z[5,0,4]  R577      1.6324238479137421e-01
    z[5,0,4]  R578      6.8727836012840271e-02
    z[5,0,4]  R579      2.3454587161540985e-01
    z[5,0,4]  R580      5.1327306032180786e-01
    z[5,0,4]  R581      -1.1139550060033798e-01
    z[5,0,4]  R582      3.7365466356277466e-01
    z[5,0,4]  R583      1.5394628047943115e-01
    z[5,0,4]  R584      3.2040628790855408e-01
    z[5,0,4]  R585      3.3972853422164917e-01
    z[5,0,4]  R586      -6.4457327127456665e-02
    z[5,0,4]  R587      -2.8373605012893677e-01
    z[5,0,4]  R588      -3.2385626435279846e-01
    z[5,0,4]  R589      3.6158025264739990e-02
    z[5,0,4]  R590      2.8707557916641235e-01
    z[5,0,4]  R591      -2.1785897016525269e-01
    z[5,0,4]  R592      1.3910777866840363e-01
    z[5,0,4]  R593      -3.3459064364433289e-01
    z[5,0,4]  R594      -6.3165277242660522e-02
    z[5,0,4]  R595      -3.0165541172027588e-01
    z[5,0,4]  R596      3.2457414269447327e-01
    z[5,0,4]  R597      -6.5735457465052605e-03
    z[5,0,4]  R598      -4.6645230054855347e-01
    z[5,0,4]  R599      -2.1367374062538147e-01
    z[5,0,4]  R600      2.4187627434730530e-01
    z[5,0,4]  R601      0.53766930103302
    z[5,0,4]  R602      -3.9414870738983154e-01
    z[5,0,4]  R603      3.7524050474166870e-01
    z[5,0,4]  R604      -4.3254144489765167e-02
    z[5,0,4]  R605      -1.3490395247936249e-01
    z[5,0,4]  R606      -2.7130043506622314e-01
    z[5,0,4]  R607      -1.6369469463825226e-02
    z[5,0,4]  R608      8.4502868354320526e-02
    z[5,0,4]  R609      2.5334203243255615e-01
    z[5,0,4]  R610      -3.5510438680648804e-01
    z[5,0,4]  R611      -4.4641056656837463e-01
    z[5,0,4]  R612      1.5092290937900543e-02
    z[5,0,4]  R613      -2.3525262251496315e-02
    z[5,0,4]  R614      -0.0577346533536911
    z[5,0,4]  R615      6.4896240830421448e-02
    z[5,0,4]  R616      -1.4085040986537933e-01
    z[5,0,4]  R617      9.8788976669311523e-02
    z[5,0,4]  R618      -4.1376795619726181e-02
    z[5,0,5]  R7        1
    z[5,0,5]  R52       -1
    z[5,0,5]  R515      -1
    z[5,0,5]  R516      1
    z[5,0,5]  R519      -6.2554180622100830e-02
    z[5,0,5]  R520      1.7089422047138214e-01
    z[5,0,5]  R521      1.0925537347793579e-01
    z[5,0,5]  R522      -3.3133661746978760e-01
    z[5,0,5]  R523      -4.5836070179939270e-01
    z[5,0,5]  R524      -5.0118938088417053e-02
    z[5,0,5]  R525      2.3242565989494324e-01
    z[5,0,5]  R526      2.5213134288787842e-01
    z[5,0,5]  R527      1.7320416867733002e-01
    z[5,0,5]  R528      2.6389557123184204e-01
    z[5,0,5]  R529      -0.0977431982755661
    z[5,0,5]  R530      4.1198879480361938e-02
    z[5,0,5]  R531      5.3055030107498169e-01
    z[5,0,5]  R532      2.8453812003135681e-01
    z[5,0,5]  R533      1.0688146948814392e-01
    z[5,0,5]  R534      -2.1798940002918243e-01
    z[5,0,5]  R535      -1.1671172827482224e-01
    z[5,0,5]  R536      -5.1127374172210693e-01
    z[5,0,5]  R537      -4.3282347917556763e-01
    z[5,0,5]  R538      -2.1012568473815918e-01
    z[5,0,5]  R539      3.9927309751510620e-01
    z[5,0,5]  R540      -7.2717852890491486e-02
    z[5,0,5]  R541      1.4325736463069916e-01
    z[5,0,5]  R542      -1.1089536361396313e-02
    z[5,0,5]  R543      -3.1884121894836426e-01
    z[5,0,5]  R544      -1.4226890169084072e-02
    z[5,0,5]  R545      1.7738994956016541e-01
    z[5,0,5]  R546      -1.8889398872852325e-01
    z[5,0,5]  R547      -3.1160369515419006e-01
    z[5,0,5]  R548      -1.8784089386463165e-01
    z[5,0,5]  R549      3.8963431119918823e-01
    z[5,0,5]  R550      3.4880438446998596e-01
    z[5,0,5]  R551      2.2839890420436859e-01
    z[5,0,5]  R552      -7.1575157344341278e-02
    z[5,0,5]  R553      -9.3093067407608032e-02
    z[5,0,5]  R554      3.8701677322387695e-01
    z[5,0,5]  R555      1.8997497856616974e-01
    z[5,0,5]  R556      3.9809203147888184e-01
    z[5,0,5]  R557      5.3611434996128082e-02
    z[5,0,5]  R558      -2.5995871052145958e-02
    z[5,0,5]  R559      1.2492982298135757e-01
    z[5,0,5]  R560      0.175779327750206
    z[5,0,5]  R561      3.8542658090591431e-02
    z[5,0,5]  R562      -5.6672483682632446e-01
    z[5,0,5]  R563      -5.7694405317306519e-01
    z[5,0,5]  R564      3.2612487673759460e-01
    z[5,0,5]  R565      -2.9808858036994934e-01
    z[5,0,5]  R566      -4.0076601505279541e-01
    z[5,0,5]  R567      -3.8645300269126892e-01
    z[5,0,5]  R568      1.7766506969928741e-01
    z[5,0,5]  R569      -1.6486328095197678e-02
    z[5,0,5]  R570      0.503727912902832
    z[5,0,5]  R571      0.0744536742568016
    z[5,0,5]  R572      -9.5156140625476837e-02
    z[5,0,5]  R573      1.6693204641342163e-01
    z[5,0,5]  R574      0.0472993366420269
    z[5,0,5]  R575      1.6686005890369415e-01
    z[5,0,5]  R576      1.1024153977632523e-01
    z[5,0,5]  R577      2.0623014867305756e-01
    z[5,0,5]  R578      6.2137570232152939e-02
    z[5,0,5]  R579      9.5437504351139069e-02
    z[5,0,5]  R580      -6.5168537199497223e-02
    z[5,0,5]  R581      2.6004728674888611e-01
    z[5,0,5]  R582      -5.0996005535125732e-01
    z[5,0,5]  R583      -8.8554620742797852e-02
    z[5,0,5]  R584      -2.4945183098316193e-01
    z[5,0,5]  R585      -1.1956793069839478e-01
    z[5,0,5]  R586      2.5355464220046997e-01
    z[5,0,5]  R587      -1.7481237649917603e-01
    z[5,0,5]  R588      1.9550228118896484e-01
    z[5,0,5]  R589      1.8047341704368591e-01
    z[5,0,5]  R590      -3.0346742272377014e-01
    z[5,0,5]  R591      -7.9076945781707764e-02
    z[5,0,5]  R592      -1.2368068844079971e-01
    z[5,0,5]  R593      -3.5012704133987427e-01
    z[5,0,5]  R594      -3.4012833237648010e-01
    z[5,0,5]  R595      7.3924213647842407e-02
    z[5,0,5]  R596      6.5081994980573654e-03
    z[5,0,5]  R597      3.1589362025260925e-01
    z[5,0,5]  R598      -1.6483667492866516e-01
    z[5,0,5]  R599      -7.4559226632118225e-02
    z[5,0,5]  R600      -5.8781629800796509e-01
    z[5,0,5]  R601      -3.9033353328704834e-01
    z[5,0,5]  R602      -5.8267004787921906e-02
    z[5,0,5]  R603      4.9076753854751587e-01
    z[5,0,5]  R604      0.244783416390419
    z[5,0,5]  R605      -2.7149847149848938e-01
    z[5,0,5]  R606      6.3544875383377075e-01
    z[5,0,5]  R607      -2.7017769217491150e-01
    z[5,0,5]  R608      3.8683155179023743e-01
    z[5,0,5]  R609      5.0349522382020950e-02
    z[5,0,5]  R610      9.5458760857582092e-02
    z[5,0,5]  R611      1.5454442799091339e-01
    z[5,0,5]  R612      -4.0873834490776062e-01
    z[5,0,5]  R613      2.3882275447249413e-02
    z[5,0,5]  R614      5.4946172237396240e-01
    z[5,0,5]  R615      2.4371053278446198e-01
    z[5,0,5]  R616      4.0685775876045227e-01
    z[5,0,5]  R617      2.0834033191204071e-01
    z[5,0,5]  R618      2.9766580462455750e-01
    z[5,0,6]  R8        1
    z[5,0,6]  R53       -1
    z[5,0,6]  R517      -1
    z[5,0,6]  R518      1
    z[5,0,6]  R519      -1.9355228543281555e-01
    z[5,0,6]  R520      1.3423733413219452e-01
    z[5,0,6]  R521      0.30905881524086
    z[5,0,6]  R522      1.7634055018424988e-01
    z[5,0,6]  R523      -2.1055087447166443e-01
    z[5,0,6]  R524      -3.4079153090715408e-02
    z[5,0,6]  R525      -2.0666822791099548e-01
    z[5,0,6]  R526      1.6213466227054596e-01
    z[5,0,6]  R527      -4.1867125034332275e-01
    z[5,0,6]  R528      -5.0013452768325806e-01
    z[5,0,6]  R529      -2.2686445713043213e-01
    z[5,0,6]  R530      -5.4530304670333862e-01
    z[5,0,6]  R531      -1.1884658038616180e-01
    z[5,0,6]  R532      -3.5577270388603210e-01
    z[5,0,6]  R533      3.8494133949279785e-01
    z[5,0,6]  R534      4.9901410937309265e-01
    z[5,0,6]  R535      3.3552783727645874e-01
    z[5,0,6]  R536      -7.8751757740974426e-02
    z[5,0,6]  R537      -1.5964034199714661e-01
    z[5,0,6]  R538      3.8278706371784210e-02
    z[5,0,6]  R539      -4.5227617025375366e-01
    z[5,0,6]  R540      -8.8160365819931030e-02
    z[5,0,6]  R541      3.7805411219596863e-01
    z[5,0,6]  R542      6.4236021041870117e-01
    z[5,0,6]  R543      6.8818684667348862e-03
    z[5,0,6]  R544      -4.1248893737792969e-01
    z[5,0,6]  R545      -6.3212528824806213e-02
    z[5,0,6]  R546      -2.9576432704925537e-01
    z[5,0,6]  R547      0.314543753862381
    z[5,0,6]  R548      -1.1832013726234436e-01
    z[5,0,6]  R549      2.9909417033195496e-02
    z[5,0,6]  R550      -4.3837600946426392e-01
    z[5,0,6]  R551      5.3634178638458252e-01
    z[5,0,6]  R552      8.4394156932830811e-02
    z[5,0,6]  R553      -1.1843344569206238e-01
    z[5,0,6]  R554      -2.2284707054495811e-02
    z[5,0,6]  R555      -1.1479567736387253e-01
    z[5,0,6]  R556      -2.3684035986661911e-02
    z[5,0,6]  R557      6.5544582903385162e-02
    z[5,0,6]  R558      -1.7695156857371330e-03
    z[5,0,6]  R559      1.3191461563110352e-01
    z[5,0,6]  R560      0.0874442458152771
    z[5,0,6]  R561      -4.4186714291572571e-01
    z[5,0,6]  R562      -3.0732482671737671e-01
    z[5,0,6]  R563      -5.3932290524244308e-02
    z[5,0,6]  R564      -0.401030957698822
    z[5,0,6]  R565      -2.5396207347512245e-02
    z[5,0,6]  R566      -4.6218344569206238e-01
    z[5,0,6]  R567      -3.9516305923461914e-01
    z[5,0,6]  R568      -4.1228723526000977e-01
    z[5,0,6]  R569      3.7462085485458374e-01
    z[5,0,6]  R570      5.2376669645309448e-01
    z[5,0,6]  R571      -1.5266944468021393e-01
    z[5,0,6]  R572      2.0077311992645264e-01
    z[5,0,6]  R573      2.9434624314308167e-01
    z[5,0,6]  R574      0.16197469830513
    z[5,0,6]  R575      0.0212846789509058
    z[5,0,6]  R576      6.1095900833606720e-02
    z[5,0,6]  R577      -2.5218958035111427e-02
    z[5,0,6]  R578      -1.1041018366813660e-01
    z[5,0,6]  R579      1.9928197562694550e-01
    z[5,0,6]  R580      8.4426812827587128e-03
    z[5,0,6]  R581      -4.0857456624507904e-02
    z[5,0,6]  R582      0.0263714250177145
    z[5,0,6]  R583      -3.8630792498588562e-01
    z[5,0,6]  R584      -2.9359987378120422e-01
    z[5,0,6]  R585      -6.8870788812637329e-01
    z[5,0,6]  R586      5.9921962022781372e-01
    z[5,0,6]  R587      -3.0938610434532166e-02
    z[5,0,6]  R588      2.7243435382843018e-01
    z[5,0,6]  R589      -4.6066647768020630e-01
    z[5,0,6]  R590      -2.8735786676406860e-01
    z[5,0,6]  R591      -1.0418348759412766e-01
    z[5,0,6]  R592      3.6686885356903076e-01
    z[5,0,6]  R593      1.9505521282553673e-02
    z[5,0,6]  R594      5.7073158025741577e-01
    z[5,0,6]  R595      -1.5794268250465393e-01
    z[5,0,6]  R596      3.0939567089080811e-01
    z[5,0,6]  R597      2.5403586030006409e-01
    z[5,0,6]  R598      3.1916892528533936e-01
    z[5,0,6]  R599      2.3045334219932556e-01
    z[5,0,6]  R600      2.3487238585948944e-01
    z[5,0,6]  R601      1.5198100358247757e-02
    z[5,0,6]  R602      -1.3912385702133179e-01
    z[5,0,6]  R603      2.2606596350669861e-01
    z[5,0,6]  R604      2.0908632874488831e-01
    z[5,0,6]  R605      5.1905751228332520e-01
    z[5,0,6]  R606      -1.1375757306814194e-01
    z[5,0,6]  R607      3.3053648471832275e-01
    z[5,0,6]  R608      -1.7875127494335175e-01
    z[5,0,6]  R609      -1.7471471428871155e-01
    z[5,0,6]  R610      -3.0696097016334534e-01
    z[5,0,6]  R611      -1.4413294196128845e-01
    z[5,0,6]  R612      -1.9780771806836128e-02
    z[5,0,6]  R613      -4.2399564385414124e-01
    z[5,0,6]  R614      3.5136872529983521e-01
    z[5,0,6]  R615      2.3495469987392426e-01
    z[5,0,6]  R616      -0.0321926586329937
    z[5,0,6]  R617      5.2557539194822311e-02
    z[5,0,6]  R618      2.3745338618755341e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R693      -1
    z[1,2,0]  R694      1
    z[1,2,0]  R707      -6.5858542919158936e-01
    z[1,2,0]  R708      -6.5801924467086792e-01
    z[1,2,0]  R709      -7.1887493133544922e-01
    z[1,2,0]  R710      -4.1052407026290894e-01
    z[1,2,0]  R711      -7.1989625692367554e-01
    z[1,2,0]  R712      -0.59494549036026
    z[1,2,0]  R713      -5.6977653503417969e-01
    z[1,2,0]  R714      -6.3382625579833984e-01
    z[1,2,0]  R715      -0.820820689201355
    z[1,2,0]  R716      -0.791208803653717
    z[1,2,0]  R717      -1.5829540789127350e-01
    z[1,2,0]  R718      1.0571720451116562e-01
    z[1,2,0]  R719      9.0164765715599060e-02
    z[1,2,0]  R720      2.3170144855976105e-01
    z[1,2,0]  R721      1.9998101890087128e-01
    z[1,2,0]  R722      4.8847761750221252e-01
    z[1,2,0]  R723      2.9615685343742371e-01
    z[1,2,0]  R724      3.3222836256027222e-01
    z[1,2,0]  R725      3.5924544930458069e-01
    z[1,2,0]  R726      2.8316259384155273e-01
    z[1,2,0]  R727      4.6913135051727295e-01
    z[1,2,0]  R728      5.9548223018646240e-01
    z[1,2,0]  R729      5.5419504642486572e-01
    z[1,2,0]  R730      7.1332257986068726e-01
    z[1,2,0]  R731      0.413044273853302
    z[1,2,0]  R732      -4.1304641962051392e-01
    z[1,2,0]  R733      4.5895689725875854e-01
    z[1,2,0]  R734      5.3956449031829834e-01
    z[1,2,0]  R735      1.8347802758216858e-01
    z[1,2,0]  R736      8.0835449695587158e-01
    z[1,2,0]  R737      -2.6094338297843933e-01
    z[1,2,0]  R738      -1.0375731438398361e-01
    z[1,2,0]  R739      -1.1744309961795807e-01
    z[1,2,0]  R740      1.6161955893039703e-01
    z[1,2,0]  R741      4.5744961500167847e-01
    z[1,2,0]  R742      2.7871596813201904e-01
    z[1,2,0]  R743      2.7719014883041382e-01
    z[1,2,0]  R744      1.2179224193096161e-01
    z[1,2,0]  R745      -6.3695102930068970e-02
    z[1,2,0]  R746      0.629237711429596
    z[1,2,0]  R747      3.9095136523246765e-01
    z[1,2,0]  R748      3.6560770124197006e-02
    z[1,2,0]  R749      1.7770273983478546e-01
    z[1,2,0]  R750      1.4492644369602203e-01
    z[1,2,0]  R751      0.556480348110199
    z[1,2,0]  R752      5.0131708383560181e-01
    z[1,2,0]  R753      2.5523781776428223e-01
    z[1,2,0]  R754      -1.5742602944374084e-01
    z[1,2,0]  R755      4.6901664137840271e-01
    z[1,2,0]  R756      -0.0424308106303215
    z[1,2,0]  R757      2.9013910889625549e-01
    z[1,2,0]  R758      -2.6687833666801453e-01
    z[1,2,0]  R759      8.5017897188663483e-02
    z[1,2,0]  R760      -1.7064388096332550e-01
    z[1,2,0]  R761      7.6443380117416382e-01
    z[1,2,0]  R762      1.9689476490020752e-01
    z[1,2,0]  R763      8.2556062936782837e-01
    z[1,2,0]  R764      -1.2607698142528534e-01
    z[1,2,0]  R765      7.0532029867172241e-01
    z[1,2,0]  R766      0.554187536239624
    z[1,2,0]  R767      0.498337984085083
    z[1,2,0]  R768      1.3690540194511414e-01
    z[1,2,0]  R769      2.0153930783271790e-01
    z[1,2,0]  R770      3.8671070337295532e-01
    z[1,2,0]  R771      -7.6744019985198975e-02
    z[1,2,0]  R772      2.1289205551147461e-01
    z[1,2,0]  R773      -1.2130734324455261e-01
    z[1,2,0]  R774      4.4750612229108810e-02
    z[1,2,0]  R775      -1.3699607551097870e-01
    z[1,2,0]  R776      1.7185197770595551e-01
    z[1,2,0]  R777      3.0488875508308411e-01
    z[1,2,0]  R778      -2.1510450541973114e-01
    z[1,2,0]  R779      -4.6034038066864014e-01
    z[1,2,0]  R780      4.8502811789512634e-01
    z[1,2,0]  R781      3.1340980529785156e-01
    z[1,2,0]  R782      -3.1027961522340775e-02
    z[1,2,0]  R783      1.2311228550970554e-02
    z[1,2,0]  R784      6.5089219808578491e-01
    z[1,2,0]  R785      2.2151054814457893e-02
    z[1,2,0]  R786      6.4380139112472534e-01
    z[1,2,0]  R787      -1.6967041790485382e-01
    z[1,2,0]  R788      -1.3388785719871521e-01
    z[1,2,0]  R789      3.0542594194412231e-01
    z[1,2,0]  R790      -0.77823805809021
    z[1,2,0]  R791      -7.9751676321029663e-01
    z[1,2,0]  R792      -8.5658162832260132e-01
    z[1,2,0]  R793      -8.0390030145645142e-01
    z[1,2,0]  R794      -7.7379405498504639e-01
    z[1,2,0]  R795      -8.9063447713851929e-01
    z[1,2,0]  R796      -1.7608661949634552e-01
    z[1,2,0]  R797      1.0001166909933090e-01
    z[1,2,0]  R798      4.4433104991912842e-01
    z[1,2,0]  R799      3.6617133021354675e-01
    z[1,2,0]  R800      1.9942130148410797e-01
    z[1,2,0]  R801      -1.2687428295612335e-01
    z[1,2,0]  R802      -3.5667607188224792e-01
    z[1,2,0]  R803      -5.2196753025054932e-01
    z[1,2,0]  R804      -2.4494828283786774e-01
    z[1,2,0]  R805      -7.5037801265716553e-01
    z[1,2,0]  R806      1.8949049711227417e-01
    z[1,2,0]  R807      -6.1510574817657471e-01
    z[1,2,0]  R808      -3.4907853603363037e-01
    z[1,2,0]  R809      -1.6321410238742828e-01
    z[1,2,0]  R810      -3.3627992868423462e-01
    z[1,2,0]  R811      1.2292774766683578e-01
    z[1,2,0]  R812      1.1723812669515610e-01
    z[1,2,0]  R813      2.9016089439392090e-01
    z[1,2,0]  R814      2.1073332428932190e-01
    z[1,2,0]  R815      1.3649851083755493e-01
    z[1,2,0]  R816      3.8373467326164246e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R695      -1
    z[1,2,1]  R696      1
    z[1,2,1]  R707      -1.8033710122108459e-01
    z[1,2,1]  R708      -2.2804026305675507e-01
    z[1,2,1]  R709      -6.2383204698562622e-02
    z[1,2,1]  R710      -2.5859877467155457e-01
    z[1,2,1]  R711      -9.5601566135883331e-02
    z[1,2,1]  R712      -1.7058271169662476e-01
    z[1,2,1]  R713      -1.5964622795581818e-01
    z[1,2,1]  R714      -1.4073713123798370e-01
    z[1,2,1]  R715      -2.7701035141944885e-01
    z[1,2,1]  R716      -1.3329532742500305e-01
    z[1,2,1]  R717      0.804551362991333
    z[1,2,1]  R718      8.0172097682952881e-01
    z[1,2,1]  R719      8.9155030250549316e-01
    z[1,2,1]  R720      8.1907963752746582e-01
    z[1,2,1]  R721      8.7900412082672119e-01
    z[1,2,1]  R722      8.1295800209045410e-01
    z[1,2,1]  R723      7.5687986612319946e-01
    z[1,2,1]  R724      7.5830638408660889e-01
    z[1,2,1]  R725      7.4715173244476318e-01
    z[1,2,1]  R726      7.0336920022964478e-01
    z[1,2,1]  R727      -2.7622026205062866e-01
    z[1,2,1]  R728      -3.9142203330993652e-01
    z[1,2,1]  R729      -0.248797208070755
    z[1,2,1]  R730      -2.4576936662197113e-01
    z[1,2,1]  R731      -2.1434900164604187e-01
    z[1,2,1]  R732      1.0257773846387863e-01
    z[1,2,1]  R733      -1.3534389436244965e-01
    z[1,2,1]  R734      -1.5342769026756287e-01
    z[1,2,1]  R735      -2.4239315092563629e-01
    z[1,2,1]  R736      1.2143120914697647e-01
    z[1,2,1]  R737      5.4998785257339478e-01
    z[1,2,1]  R738      -7.4844092130661011e-01
    z[1,2,1]  R739      -5.1669752597808838e-01
    z[1,2,1]  R740      2.8788894414901733e-01
    z[1,2,1]  R741      -7.5884765386581421e-01
    z[1,2,1]  R742      -5.1433372497558594e-01
    z[1,2,1]  R743      -5.9484966099262238e-02
    z[1,2,1]  R744      5.6977644562721252e-02
    z[1,2,1]  R745      -9.7424782812595367e-02
    z[1,2,1]  R746      3.4643688797950745e-01
    z[1,2,1]  R747      -7.4864143133163452e-01
    z[1,2,1]  R748      -7.6750653982162476e-01
    z[1,2,1]  R749      -0.63265460729599
    z[1,2,1]  R750      -7.0288920402526855e-01
    z[1,2,1]  R751      -6.0325086116790771e-01
    z[1,2,1]  R752      -6.3913995027542114e-01
    z[1,2,1]  R753      3.4777700901031494e-01
    z[1,2,1]  R754      1.0955148190259933e-01
    z[1,2,1]  R755      3.3840516209602356e-01
    z[1,2,1]  R756      2.0106829702854156e-01
    z[1,2,1]  R757      2.3183113336563110e-01
    z[1,2,1]  R758      4.2090049386024475e-01
    z[1,2,1]  R759      4.7850003838539124e-01
    z[1,2,1]  R760      5.1707899570465088e-01
    z[1,2,1]  R761      4.5963954925537109e-01
    z[1,2,1]  R762      2.8990250825881958e-01
    z[1,2,1]  R763      6.1392839998006821e-02
    z[1,2,1]  R764      -6.5599137544631958e-01
    z[1,2,1]  R765      4.3035867810249329e-01
    z[1,2,1]  R766      4.1396754980087280e-01
    z[1,2,1]  R767      -5.6772458553314209e-01
    z[1,2,1]  R768      -4.0542924404144287e-01
    z[1,2,1]  R769      -2.9511788487434387e-01
    z[1,2,1]  R770      4.9987000226974487e-01
    z[1,2,1]  R771      4.4165849685668945e-01
    z[1,2,1]  R772      4.4861632585525513e-01
    z[1,2,1]  R773      0.58297199010849
    z[1,2,1]  R774      -0.700998842716217
    z[1,2,1]  R775      2.2690226137638092e-01
    z[1,2,1]  R776      -0.0210583433508873
    z[1,2,1]  R777      6.1287569999694824e-01
    z[1,2,1]  R778      -7.1970504522323608e-01
    z[1,2,1]  R779      -5.1845723390579224e-01
    z[1,2,1]  R780      5.7428580522537231e-01
    z[1,2,1]  R781      3.9865252375602722e-01
    z[1,2,1]  R782      -2.9648298025131226e-01
    z[1,2,1]  R783      3.0242647975683212e-02
    z[1,2,1]  R784      1.9152933359146118e-01
    z[1,2,1]  R785      7.7534466981887817e-01
    z[1,2,1]  R786      2.0321662724018097e-01
    z[1,2,1]  R787      7.5533652305603027e-01
    z[1,2,1]  R788      1.5082035958766937e-01
    z[1,2,1]  R789      3.2670933008193970e-01
    z[1,2,1]  R790      -8.6420841515064240e-02
    z[1,2,1]  R791      -9.3506224453449249e-02
    z[1,2,1]  R792      -8.2904092967510223e-02
    z[1,2,1]  R793      7.6480291783809662e-02
    z[1,2,1]  R794      -4.5369766652584076e-02
    z[1,2,1]  R795      -4.7882851213216782e-02
    z[1,2,1]  R796      -1.4118745923042297e-01
    z[1,2,1]  R797      1.1222476139664650e-02
    z[1,2,1]  R798      4.5571732521057129e-01
    z[1,2,1]  R799      -4.6389934420585632e-01
    z[1,2,1]  R800      -4.7327658534049988e-01
    z[1,2,1]  R801      -4.2640617489814758e-01
    z[1,2,1]  R802      -4.0584355592727661e-01
    z[1,2,1]  R803      -0.498304545879364
    z[1,2,1]  R804      -0.765228807926178
    z[1,2,1]  R805      -4.2069500684738159e-01
    z[1,2,1]  R806      -3.6247938871383667e-01
    z[1,2,1]  R807      -5.1551681756973267e-01
    z[1,2,1]  R808      -7.5431865453720093e-01
    z[1,2,1]  R809      -4.4682428240776062e-01
    z[1,2,1]  R810      -7.0357149839401245e-01
    z[1,2,1]  R811      -6.1069816350936890e-01
    z[1,2,1]  R812      -6.9779038429260254e-01
    z[1,2,1]  R813      -0.66790372133255
    z[1,2,1]  R814      -7.9137659072875977e-01
    z[1,2,1]  R815      -6.8418294191360474e-01
    z[1,2,1]  R816      -7.2239428758621216e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R697      -1
    z[1,2,2]  R698      1
    z[1,2,2]  R707      3.6491009593009949e-01
    z[1,2,2]  R708      8.3101242780685425e-02
    z[1,2,2]  R709      1.5813589096069336e-01
    z[1,2,2]  R710      4.2543417215347290e-01
    z[1,2,2]  R711      2.5178456306457520e-01
    z[1,2,2]  R712      6.8271708488464355e-01
    z[1,2,2]  R713      -3.4442096948623657e-01
    z[1,2,2]  R714      -1.5313203446567059e-02
    z[1,2,2]  R715      4.7069203108549118e-02
    z[1,2,2]  R716      -2.3530335724353790e-01
    z[1,2,2]  R717      2.4600613117218018e-01
    z[1,2,2]  R718      1.5599825978279114e-01
    z[1,2,2]  R719      1.8806867301464081e-01
    z[1,2,2]  R720      4.3373140692710876e-01
    z[1,2,2]  R721      -9.5579192042350769e-02
    z[1,2,2]  R722      0.0797993540763855
    z[1,2,2]  R723      6.5456248819828033e-02
    z[1,2,2]  R724      -2.2454971075057983e-01
    z[1,2,2]  R725      1.0154710710048676e-01
    z[1,2,2]  R726      3.5156715661287308e-02
    z[1,2,2]  R727      3.8920834660530090e-02
    z[1,2,2]  R728      -5.9202855825424194e-01
    z[1,2,2]  R729      -5.0289428234100342e-01
    z[1,2,2]  R730      -2.5969842076301575e-01
    z[1,2,2]  R731      -2.9287990927696228e-01
    z[1,2,2]  R732      -5.1057970523834229e-01
    z[1,2,2]  R733      -2.9195931553840637e-01
    z[1,2,2]  R734      -1.5345829725265503e-01
    z[1,2,2]  R735      -5.4529237747192383e-01
    z[1,2,2]  R736      -2.5295522809028625e-01
    z[1,2,2]  R737      9.3944780528545380e-02
    z[1,2,2]  R738      -4.6293100714683533e-01
    z[1,2,2]  R739      -6.5030390024185181e-01
    z[1,2,2]  R740      4.0662553906440735e-01
    z[1,2,2]  R741      4.1330105066299438e-01
    z[1,2,2]  R742      -3.1752744317054749e-01
    z[1,2,2]  R743      -8.1574696302413940e-01
    z[1,2,2]  R744      3.1801056861877441e-01
    z[1,2,2]  R745      -7.5886243581771851e-01
    z[1,2,2]  R746      -4.8464578390121460e-01
    z[1,2,2]  R747      -9.4092048704624176e-02
    z[1,2,2]  R748      -2.3630566895008087e-01
    z[1,2,2]  R749      3.9439156651496887e-02
    z[1,2,2]  R750      -5.8352392911911011e-01
    z[1,2,2]  R751      -4.4249197840690613e-01
    z[1,2,2]  R752      -3.7597176432609558e-01
    z[1,2,2]  R753      -1.0341511666774750e-01
    z[1,2,2]  R754      -0.631401777267456
    z[1,2,2]  R755      -1.3033016026020050e-01
    z[1,2,2]  R756      -0.673624575138092
    z[1,2,2]  R757      8.6111530661582947e-02
    z[1,2,2]  R758      -6.5445655584335327e-01
    z[1,2,2]  R759      -7.5995332002639771e-01
    z[1,2,2]  R760      -0.604049563407898
    z[1,2,2]  R761      -2.5753778219223022e-01
    z[1,2,2]  R762      -5.3976607322692871e-01
    z[1,2,2]  R763      4.2098306119441986e-02
    z[1,2,2]  R764      3.4863191843032837e-01
    z[1,2,2]  R765      4.5605354011058807e-02
    z[1,2,2]  R766      -3.8888771086931229e-02
    z[1,2,2]  R767      -2.9725676774978638e-01
    z[1,2,2]  R768      3.8173702359199524e-01
    z[1,2,2]  R769      -1.8941754102706909e-01
    z[1,2,2]  R770      1.1917474865913391e-01
    z[1,2,2]  R771      -7.8999191522598267e-01
    z[1,2,2]  R772      1.3872574269771576e-01
    z[1,2,2]  R773      4.2276558279991150e-01
    z[1,2,2]  R774      4.0643098950386047e-01
    z[1,2,2]  R775      5.0381618738174438e-01
    z[1,2,2]  R776      -3.2543742656707764e-01
    z[1,2,2]  R777      9.7078546881675720e-02
    z[1,2,2]  R778      -2.7968008071184158e-03
    z[1,2,2]  R779      3.8206619024276733e-01
    z[1,2,2]  R780      -2.5693991780281067e-01
    z[1,2,2]  R781      2.8152132034301758e-01
    z[1,2,2]  R782      -6.1093878746032715e-01
    z[1,2,2]  R783      -3.3857741951942444e-01
    z[1,2,2]  R784      -0.472592294216156
    z[1,2,2]  R785      9.7093977034091949e-02
    z[1,2,2]  R786      -2.3159457743167877e-01
    z[1,2,2]  R787      -3.1709957867860794e-02
    z[1,2,2]  R788      -1.1720193177461624e-01
    z[1,2,2]  R789      8.2046687602996826e-01
    z[1,2,2]  R790      4.8310512304306030e-01
    z[1,2,2]  R791      3.8264030218124390e-01
    z[1,2,2]  R792      3.7091696262359619e-01
    z[1,2,2]  R793      2.1323429048061371e-01
    z[1,2,2]  R794      -3.1985055655241013e-02
    z[1,2,2]  R795      -3.7263888120651245e-01
    z[1,2,2]  R796      -5.7381969690322876e-01
    z[1,2,2]  R797      -9.8400421440601349e-02
    z[1,2,2]  R798      -5.2164769172668457e-01
    z[1,2,2]  R799      -6.6140770912170410e-01
    z[1,2,2]  R800      -9.3525443226099014e-03
    z[1,2,2]  R801      -6.2786054611206055e-01
    z[1,2,2]  R802      -7.6410883665084839e-01
    z[1,2,2]  R803      -1.3354372978210449e-01
    z[1,2,2]  R804      -5.2212452888488770e-01
    z[1,2,2]  R805      2.8210720419883728e-01
    z[1,2,2]  R806      -5.5925279855728149e-01
    z[1,2,2]  R807      -0.313320517539978
    z[1,2,2]  R808      2.8686714172363281e-01
    z[1,2,2]  R809      4.6897572278976440e-01
    z[1,2,2]  R810      -4.2075714468955994e-01
    z[1,2,2]  R811      -4.1321775317192078e-01
    z[1,2,2]  R812      -1.0324368625879288e-01
    z[1,2,2]  R813      -5.2678704261779785e-02
    z[1,2,2]  R814      -2.9144442081451416e-01
    z[1,2,2]  R815      -2.6429215073585510e-01
    z[1,2,2]  R816      1.5398591756820679e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R699      -1
    z[1,2,3]  R700      1
    z[1,2,3]  R707      -3.7720409035682678e-01
    z[1,2,3]  R708      -5.0152492523193359e-01
    z[1,2,3]  R709      -0.620127260684967
    z[1,2,3]  R710      -3.0619978904724121e-01
    z[1,2,3]  R711      -4.6318736672401428e-01
    z[1,2,3]  R712      -2.8145933151245117e-01
    z[1,2,3]  R713      -4.9411794543266296e-01
    z[1,2,3]  R714      -4.7303819656372070e-01
    z[1,2,3]  R715      -1.5031154453754425e-01
    z[1,2,3]  R716      -3.8023716211318970e-01
    z[1,2,3]  R717      4.0187767148017883e-01
    z[1,2,3]  R718      3.0618983507156372e-01
    z[1,2,3]  R719      1.4561046659946442e-01
    z[1,2,3]  R720      2.7717188000679016e-01
    z[1,2,3]  R721      3.1537401676177979e-01
    z[1,2,3]  R722      1.7669594287872314e-01
    z[1,2,3]  R723      2.2975522279739380e-01
    z[1,2,3]  R724      3.0813151597976685e-01
    z[1,2,3]  R725      1.8196175992488861e-01
    z[1,2,3]  R726      3.0411624908447266e-01
    z[1,2,3]  R727      -4.7513264417648315e-01
    z[1,2,3]  R728      -2.9910793900489807e-01
    z[1,2,3]  R729      -4.9415990710258484e-01
    z[1,2,3]  R730      -5.3595000505447388e-01
    z[1,2,3]  R731      -7.0295113325119019e-01
    z[1,2,3]  R732      6.3802433013916016e-01
    z[1,2,3]  R733      -5.2820432186126709e-01
    z[1,2,3]  R734      -7.0321941375732422e-01
    z[1,2,3]  R735      -1.1157199740409851e-01
    z[1,2,3]  R736      4.9584048986434937e-01
    z[1,2,3]  R737      6.3299578428268433e-01
    z[1,2,3]  R738      1.0616496205329895e-01
    z[1,2,3]  R739      2.5820401310920715e-01
    z[1,2,3]  R740      7.9184156656265259e-01
    z[1,2,3]  R741      -8.7833821773529053e-02
    z[1,2,3]  R742      -6.3290582038462162e-03
    z[1,2,3]  R743      3.8389280438423157e-01
    z[1,2,3]  R744      5.2608340978622437e-01
    z[1,2,3]  R745      3.3938249945640564e-01
    z[1,2,3]  R746      2.5562044978141785e-01
    z[1,2,3]  R747      -3.0140110850334167e-01
    z[1,2,3]  R748      -2.7371674776077271e-01
    z[1,2,3]  R749      -0.520424485206604
    z[1,2,3]  R750      5.7561047375202179e-02
    z[1,2,3]  R751      -1.3779722154140472e-01
    z[1,2,3]  R752      1.5111909806728363e-01
    z[1,2,3]  R753      7.1562141180038452e-01
    z[1,2,3]  R754      7.0563733577728271e-01
    z[1,2,3]  R755      6.9247573614120483e-01
    z[1,2,3]  R756      3.9864847064018250e-01
    z[1,2,3]  R757      8.6471486091613770e-01
    z[1,2,3]  R758      2.9924002289772034e-01
    z[1,2,3]  R759      9.8448902368545532e-02
    z[1,2,3]  R760      0.0271736029535532
    z[1,2,3]  R761      1.0608037561178207e-01
    z[1,2,3]  R762      1.6946910321712494e-01
    z[1,2,3]  R763      3.3247882127761841e-01
    z[1,2,3]  R764      0.596255898475647
    z[1,2,3]  R765      1.9995900988578796e-01
    z[1,2,3]  R766      2.9122719168663025e-01
    z[1,2,3]  R767      -1.0755251161754131e-02
    z[1,2,3]  R768      -7.1085256338119507e-01
    z[1,2,3]  R769      -7.3259377479553223e-01
    z[1,2,3]  R770      6.1649543046951294e-01
    z[1,2,3]  R771      3.1919321417808533e-01
    z[1,2,3]  R772      0.474653959274292
    z[1,2,3]  R773      5.7778173685073853e-01
    z[1,2,3]  R774      2.9399591684341431e-01
    z[1,2,3]  R775      5.8195346593856812e-01
    z[1,2,3]  R776      4.9630695581436157e-01
    z[1,2,3]  R777      6.5015846490859985e-01
    z[1,2,3]  R778      1.1039676517248154e-01
    z[1,2,3]  R779      4.3881908059120178e-01
    z[1,2,3]  R780      5.5209094285964966e-01
    z[1,2,3]  R781      5.9213083982467651e-01
    z[1,2,3]  R782      0.625938355922699
    z[1,2,3]  R783      6.1959064006805420e-01
    z[1,2,3]  R784      3.7651520967483521e-01
    z[1,2,3]  R785      -4.0214595198631287e-01
    z[1,2,3]  R786      3.4837007522583008e-01
    z[1,2,3]  R787      2.4858303368091583e-01
    z[1,2,3]  R788      4.2554402351379395e-01
    z[1,2,3]  R789      0.0343628004193306
    z[1,2,3]  R790      -3.8013058900833130e-01
    z[1,2,3]  R791      -2.9829597473144531e-01
    z[1,2,3]  R792      -3.3759616315364838e-02
    z[1,2,3]  R793      -4.6697562932968140e-01
    z[1,2,3]  R794      -3.4522190690040588e-01
    z[1,2,3]  R795      -1.0063122212886810e-01
    z[1,2,3]  R796      -0.532974362373352
    z[1,2,3]  R797      0.795096755027771
    z[1,2,3]  R798      -6.5679289400577545e-02
    z[1,2,3]  R799      2.1196436882019043e-01
    z[1,2,3]  R800      -5.1714515686035156e-01
    z[1,2,3]  R801      -3.2441899180412292e-01
    z[1,2,3]  R802      2.2344872355461121e-01
    z[1,2,3]  R803      -2.0596009492874146e-01
    z[1,2,3]  R804      -2.5589501857757568e-01
    z[1,2,3]  R805      -2.2315208613872528e-01
    z[1,2,3]  R806      -4.5817753672599792e-01
    z[1,2,3]  R807      -1.4972835779190063e-01
    z[1,2,3]  R808      2.0119418203830719e-01
    z[1,2,3]  R809      -7.1833759546279907e-01
    z[1,2,3]  R810      7.2061540558934212e-03
    z[1,2,3]  R811      -4.4673284888267517e-01
    z[1,2,3]  R812      -6.6427075862884521e-01
    z[1,2,3]  R813      -4.9844187498092651e-01
    z[1,2,3]  R814      -3.5893306136131287e-01
    z[1,2,3]  R815      -3.5574150085449219e-01
    z[1,2,3]  R816      -1.9878847897052765e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R701      -1
    z[1,2,4]  R702      1
    z[1,2,4]  R707      -3.2421648502349854e-01
    z[1,2,4]  R708      -0.287641316652298
    z[1,2,4]  R709      -2.5535440444946289e-01
    z[1,2,4]  R710      -6.8725836277008057e-01
    z[1,2,4]  R711      1.0965451598167419e-01
    z[1,2,4]  R712      -8.6141265928745270e-02
    z[1,2,4]  R713      -3.9865094423294067e-01
    z[1,2,4]  R714      -1.8897384405136108e-01
    z[1,2,4]  R715      2.6522138714790344e-01
    z[1,2,4]  R716      1.8102388083934784e-01
    z[1,2,4]  R717      -7.8041076660156250e-02
    z[1,2,4]  R718      -2.4372771382331848e-01
    z[1,2,4]  R719      1.0159488767385483e-01
    z[1,2,4]  R720      3.1711183488368988e-02
    z[1,2,4]  R721      1.2975813448429108e-01
    z[1,2,4]  R722      3.6978356540203094e-02
    z[1,2,4]  R723      4.7158572822809219e-02
    z[1,2,4]  R724      -2.0836353302001953e-01
    z[1,2,4]  R725      -7.6501868665218353e-02
    z[1,2,4]  R726      -2.3105712607502937e-03
    z[1,2,4]  R727      -2.3320877552032471e-01
    z[1,2,4]  R728      -1.1149710416793823e-01
    z[1,2,4]  R729      1.9031253457069397e-01
    z[1,2,4]  R730      -2.6426789164543152e-01
    z[1,2,4]  R731      3.6705070734024048e-01
    z[1,2,4]  R732      3.2231593132019043e-01
    z[1,2,4]  R733      -1.2098166346549988e-01
    z[1,2,4]  R734      4.6424347907304764e-02
    z[1,2,4]  R735      -2.0061565935611725e-01
    z[1,2,4]  R736      -3.2303226180374622e-03
    z[1,2,4]  R737      -1.9778303802013397e-01
    z[1,2,4]  R738      2.3271875083446503e-01
    z[1,2,4]  R739      -2.0879207551479340e-01
    z[1,2,4]  R740      -1.4656364917755127e-01
    z[1,2,4]  R741      3.8150716572999954e-02
    z[1,2,4]  R742      1.2002401798963547e-01
    z[1,2,4]  R743      3.2161605358123779e-01
    z[1,2,4]  R744      4.0730339288711548e-01
    z[1,2,4]  R745      4.8944327980279922e-02
    z[1,2,4]  R746      3.6813560128211975e-01
    z[1,2,4]  R747      -1.9165527820587158e-01
    z[1,2,4]  R748      4.9533969163894653e-01
    z[1,2,4]  R749      3.0061343312263489e-01
    z[1,2,4]  R750      2.9962889850139618e-02
    z[1,2,4]  R751      4.4709322974085808e-03
    z[1,2,4]  R752      -1.3671702146530151e-01
    z[1,2,4]  R753      1.6357812285423279e-01
    z[1,2,4]  R754      1.9558621942996979e-01
    z[1,2,4]  R755      3.6986431479454041e-01
    z[1,2,4]  R756      2.1674321591854095e-01
    z[1,2,4]  R757      -4.2414046823978424e-02
    z[1,2,4]  R758      -1.7318703234195709e-02
    z[1,2,4]  R759      3.6371055245399475e-01
    z[1,2,4]  R760      4.8381996154785156e-01
    z[1,2,4]  R761      -3.2471738755702972e-02
    z[1,2,4]  R762      5.8499181270599365e-01
    z[1,2,4]  R763      4.3477073311805725e-01
    z[1,2,4]  R764      1.2443201988935471e-01
    z[1,2,4]  R765      1.5923465788364410e-01
    z[1,2,4]  R766      4.4488483667373657e-01
    z[1,2,4]  R767      -1.4953131973743439e-01
    z[1,2,4]  R768      6.2398705631494522e-02
    z[1,2,4]  R769      2.5058604776859283e-02
    z[1,2,4]  R770      -4.4366973638534546e-01
    z[1,2,4]  R771      2.5789496302604675e-01
    z[1,2,4]  R772      4.7080650925636292e-01
    z[1,2,4]  R773      -1.0918192565441132e-03
    z[1,2,4]  R774      -1.5598331391811371e-01
    z[1,2,4]  R775      4.9181395769119263e-01
    z[1,2,4]  R776      7.5598949193954468e-01
    z[1,2,4]  R777      -1.1459868401288986e-01
    z[1,2,4]  R778      -3.6937814950942993e-01
    z[1,2,4]  R779      3.9902281761169434e-01
    z[1,2,4]  R780      2.1089439094066620e-01
    z[1,2,4]  R781      3.0564457178115845e-01
    z[1,2,4]  R782      2.1205591037869453e-02
    z[1,2,4]  R783      6.6968256235122681e-01
    z[1,2,4]  R784      3.4454742074012756e-01
    z[1,2,4]  R785      4.2818868532776833e-03
    z[1,2,4]  R786      4.8093062639236450e-01
    z[1,2,4]  R787      2.2210077941417694e-01
    z[1,2,4]  R788      0.52739018201828
    z[1,2,4]  R789      6.0279220342636108e-02
    z[1,2,4]  R790      2.4187561124563217e-02
    z[1,2,4]  R791      -0.0906379222869873
    z[1,2,4]  R792      -3.1904366612434387e-01
    z[1,2,4]  R793      -1.3254015147686005e-01
    z[1,2,4]  R794      -5.0502443313598633e-01
    z[1,2,4]  R795      -1.4713397622108459e-01
    z[1,2,4]  R796      -2.8011593222618103e-01
    z[1,2,4]  R797      -3.7752330303192139e-01
    z[1,2,4]  R798      -2.7722901105880737e-01
    z[1,2,4]  R799      -3.1362017989158630e-01
    z[1,2,4]  R800      4.6093329787254333e-01
    z[1,2,4]  R801      4.8824116587638855e-01
    z[1,2,4]  R802      5.0413936376571655e-02
    z[1,2,4]  R803      -2.4194929003715515e-01
    z[1,2,4]  R804      -6.4516708254814148e-02
    z[1,2,4]  R805      2.3263719677925110e-01
    z[1,2,4]  R806      -2.1304479241371155e-01
    z[1,2,4]  R807      2.3986525833606720e-02
    z[1,2,4]  R808      9.1045916080474854e-02
    z[1,2,4]  R809      4.5402288436889648e-02
    z[1,2,4]  R810      -1.3329149782657623e-01
    z[1,2,4]  R811      -4.3217939138412476e-01
    z[1,2,4]  R812      -2.0710915327072144e-01
    z[1,2,4]  R813      -4.0176659822463989e-01
    z[1,2,4]  R814      -3.0604231357574463e-01
    z[1,2,4]  R815      -3.3184453845024109e-01
    z[1,2,4]  R816      1.4250871725380421e-02
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R703      -1
    z[1,2,5]  R704      1
    z[1,2,5]  R707      -7.6462127268314362e-02
    z[1,2,5]  R708      3.5775130987167358e-01
    z[1,2,5]  R709      -5.0992354750633240e-02
    z[1,2,5]  R710      6.8135358393192291e-02
    z[1,2,5]  R711      4.2147073149681091e-01
    z[1,2,5]  R712      9.6685782074928284e-02
    z[1,2,5]  R713      2.4848919361829758e-02
    z[1,2,5]  R714      3.7973019480705261e-01
    z[1,2,5]  R715      -3.8027125597000122e-01
    z[1,2,5]  R716      -2.2399128973484039e-01
    z[1,2,5]  R717      1.3740417361259460e-01
    z[1,2,5]  R718      3.0534034967422485e-01
    z[1,2,5]  R719      3.5866221785545349e-01
    z[1,2,5]  R720      5.9211300686001778e-03
    z[1,2,5]  R721      -1.6443461179733276e-02
    z[1,2,5]  R722      2.0932057499885559e-01
    z[1,2,5]  R723      3.7273299694061279e-01
    z[1,2,5]  R724      2.1522977948188782e-01
    z[1,2,5]  R725      0.511130690574646
    z[1,2,5]  R726      3.6250913143157959e-01
    z[1,2,5]  R727      -0.648076057434082
    z[1,2,5]  R728      0.0657590702176094
    z[1,2,5]  R729      -2.9661828279495239e-01
    z[1,2,5]  R730      -7.6879158616065979e-02
    z[1,2,5]  R731      -2.1222910284996033e-01
    z[1,2,5]  R732      1.6392305493354797e-01
    z[1,2,5]  R733      -4.2393404245376587e-01
    z[1,2,5]  R734      -1.5759025514125824e-01
    z[1,2,5]  R735      -3.9872181415557861e-01
    z[1,2,5]  R736      7.0305779576301575e-02
    z[1,2,5]  R737      4.1900908946990967e-01
    z[1,2,5]  R738      1.4060950279235840e-01
    z[1,2,5]  R739      -4.0386593341827393e-01
    z[1,2,5]  R740      2.3328746855258942e-01
    z[1,2,5]  R741      1.4735272526741028e-01
    z[1,2,5]  R742      -1.0939425788819790e-02
    z[1,2,5]  R743      -2.9343429952859879e-02
    z[1,2,5]  R744      6.4921337366104126e-01
    z[1,2,5]  R745      5.4124879837036133e-01
    z[1,2,5]  R746      -2.0792341232299805e-01
    z[1,2,5]  R747      2.0585437119007111e-01
    z[1,2,5]  R748      -9.0375185012817383e-02
    z[1,2,5]  R749      -4.8706404864788055e-02
    z[1,2,5]  R750      -1.5952616930007935e-01
    z[1,2,5]  R751      -4.9883734434843063e-02
    z[1,2,5]  R752      -3.8910800218582153e-01
    z[1,2,5]  R753      4.2181101441383362e-01
    z[1,2,5]  R754      -1.6269692778587341e-01
    z[1,2,5]  R755      -1.3045889139175415e-01
    z[1,2,5]  R756      8.8567227125167847e-02
    z[1,2,5]  R757      3.1192660331726074e-01
    z[1,2,5]  R758      3.9336517453193665e-01
    z[1,2,5]  R759      2.0151710510253906e-01
    z[1,2,5]  R760      9.1979645192623138e-02
    z[1,2,5]  R761      -4.3433707207441330e-02
    z[1,2,5]  R762      -3.8120919466018677e-01
    z[1,2,5]  R763      -1.0739266127347946e-01
    z[1,2,5]  R764      1.6362212598323822e-01
    z[1,2,5]  R765      -3.6934378743171692e-01
    z[1,2,5]  R766      -4.7725012898445129e-01
    z[1,2,5]  R767      -0.523442268371582
    z[1,2,5]  R768      -2.9658830165863037e-01
    z[1,2,5]  R769      2.5670301169157028e-02
    z[1,2,5]  R770      8.1822425127029419e-02
    z[1,2,5]  R771      -6.0947993770241737e-03
    z[1,2,5]  R772      3.6438152194023132e-01
    z[1,2,5]  R773      -3.4555536508560181e-01
    z[1,2,5]  R774      -4.6714732050895691e-01
    z[1,2,5]  R775      1.2319060415029526e-01
    z[1,2,5]  R776      5.1724273711442947e-02
    z[1,2,5]  R777      2.0836119353771210e-01
    z[1,2,5]  R778      -2.1691080927848816e-01
    z[1,2,5]  R779      1.4422725141048431e-01
    z[1,2,5]  R780      -9.9152170121669769e-02
    z[1,2,5]  R781      -1.5527497231960297e-01
    z[1,2,5]  R782      3.7689003348350525e-01
    z[1,2,5]  R783      -8.8169820606708527e-02
    z[1,2,5]  R784      2.3336377739906311e-01
    z[1,2,5]  R785      -1.3693358004093170e-01
    z[1,2,5]  R786      4.8149690032005310e-02
    z[1,2,5]  R787      1.9332119822502136e-01
    z[1,2,5]  R788      5.3401970863342285e-01
    z[1,2,5]  R789      -1.6601161658763885e-01
    z[1,2,5]  R790      -2.6130869984626770e-02
    z[1,2,5]  R791      3.3052659034729004e-01
    z[1,2,5]  R792      1.1951579898595810e-01
    z[1,2,5]  R793      1.1675358563661575e-01
    z[1,2,5]  R794      1.0763483494520187e-01
    z[1,2,5]  R795      -1.8017560243606567e-01
    z[1,2,5]  R796      -1.7369458079338074e-01
    z[1,2,5]  R797      -4.4999197125434875e-01
    z[1,2,5]  R798      -2.0654010772705078e-01
    z[1,2,5]  R799      2.0217722654342651e-01
    z[1,2,5]  R800      2.8861439228057861e-01
    z[1,2,5]  R801      -1.7662626504898071e-01
    z[1,2,5]  R802      -1.4387050271034241e-01
    z[1,2,5]  R803      -0.556344211101532
    z[1,2,5]  R804      1.0969237983226776e-01
    z[1,2,5]  R805      -2.7493458986282349e-01
    z[1,2,5]  R806      -9.7647741436958313e-02
    z[1,2,5]  R807      -3.8001391291618347e-01
    z[1,2,5]  R808      1.6607622802257538e-01
    z[1,2,5]  R809      -1.3904532790184021e-01
    z[1,2,5]  R810      0.0678798034787178
    z[1,2,5]  R811      -2.3103940486907959e-01
    z[1,2,5]  R812      -2.0109573379158974e-02
    z[1,2,5]  R813      -2.1075604856014252e-01
    z[1,2,5]  R814      1.0331179201602936e-01
    z[1,2,5]  R815      -2.6430118083953857e-01
    z[1,2,5]  R816      5.0883638858795166e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R705      -1
    z[1,2,6]  R706      1
    z[1,2,6]  R707      -0.383847177028656
    z[1,2,6]  R708      2.1412980556488037e-01
    z[1,2,6]  R709      4.4229626655578613e-02
    z[1,2,6]  R710      -1.1348040401935577e-01
    z[1,2,6]  R711      -7.0780552923679352e-02
    z[1,2,6]  R712      2.3420266807079315e-01
    z[1,2,6]  R713      -3.5714048147201538e-01
    z[1,2,6]  R714      -4.1779378056526184e-01
    z[1,2,6]  R715      -9.8797872662544250e-02
    z[1,2,6]  R716      -2.7079728245735168e-01
    z[1,2,6]  R717      -2.8398019075393677e-01
    z[1,2,6]  R718      2.7448818087577820e-01
    z[1,2,6]  R719      -3.8419350981712341e-02
    z[1,2,6]  R720      9.7134284675121307e-02
    z[1,2,6]  R721      -2.4830566346645355e-01
    z[1,2,6]  R722      -1.3310468196868896e-01
    z[1,2,6]  R723      3.7576359510421753e-01
    z[1,2,6]  R724      -2.8193789720535278e-01
    z[1,2,6]  R725      4.6669259667396545e-02
    z[1,2,6]  R726      -4.4715738296508789e-01
    z[1,2,6]  R727      4.4310346245765686e-02
    z[1,2,6]  R728      1.8833646178245544e-01
    z[1,2,6]  R729      -0.0983353853225708
    z[1,2,6]  R730      1.8292682245373726e-02
    z[1,2,6]  R731      1.5415126085281372e-01
    z[1,2,6]  R732      1.4263746142387390e-01
    z[1,2,6]  R733      4.6091634035110474e-01
    z[1,2,6]  R734      3.7453049421310425e-01
    z[1,2,6]  R735      6.3131886720657349e-01
    z[1,2,6]  R736      -1.3046045601367950e-01
    z[1,2,6]  R737      7.2290033102035522e-02
    z[1,2,6]  R738      3.5995218157768250e-01
    z[1,2,6]  R739      1.5154068171977997e-01
    z[1,2,6]  R740      -1.5079037845134735e-01
    z[1,2,6]  R741      1.1484432965517044e-01
    z[1,2,6]  R742      -0.736470639705658
    z[1,2,6]  R743      5.0123695284128189e-02
    z[1,2,6]  R744      1.2904106080532074e-01
    z[1,2,6]  R745      7.2645372711122036e-03
    z[1,2,6]  R746      7.1147575974464417e-02
    z[1,2,6]  R747      3.2846489548683167e-01
    z[1,2,6]  R748      -1.5908074378967285e-01
    z[1,2,6]  R749      -4.5059084892272949e-01
    z[1,2,6]  R750      -3.3879649639129639e-01
    z[1,2,6]  R751      -3.3033692836761475e-01
    z[1,2,6]  R752      7.6765216886997223e-02
    z[1,2,6]  R753      -2.9396224021911621e-01
    z[1,2,6]  R754      4.3577242642641068e-02
    z[1,2,6]  R755      1.2319776415824890e-01
    z[1,2,6]  R756      -5.3875666856765747e-01
    z[1,2,6]  R757      8.8483437895774841e-02
    z[1,2,6]  R758      2.8057926893234253e-01
    z[1,2,6]  R759      -6.0776922851800919e-02
    z[1,2,6]  R760      3.0879381299018860e-01
    z[1,2,6]  R761      -3.5192728042602539e-01
    z[1,2,6]  R762      -2.6379138231277466e-01
    z[1,2,6]  R763      4.2512655258178711e-02
    z[1,2,6]  R764      -1.8563105165958405e-01
    z[1,2,6]  R765      3.3686894178390503e-01
    z[1,2,6]  R766      -9.7422868013381958e-02
    z[1,2,6]  R767      2.1099606156349182e-01
    z[1,2,6]  R768      2.7201318740844727e-01
    z[1,2,6]  R769      5.4628539085388184e-01
    z[1,2,6]  R770      5.2705843001604080e-02
    z[1,2,6]  R771      -8.0805547535419464e-02
    z[1,2,6]  R772      -3.9299684762954712e-01
    z[1,2,6]  R773      1.1600001901388168e-01
    z[1,2,6]  R774      1.1144879460334778e-01
    z[1,2,6]  R775      2.8317835927009583e-01
    z[1,2,6]  R776      2.0880098640918732e-01
    z[1,2,6]  R777      2.0675741136074066e-01
    z[1,2,6]  R778      4.8996829986572266e-01
    z[1,2,6]  R779      -2.7041694149374962e-02
    z[1,2,6]  R780      9.9062584340572357e-02
    z[1,2,6]  R781      -4.4209539890289307e-01
    z[1,2,6]  R782      -5.9952650219202042e-02
    z[1,2,6]  R783      2.1013806760311127e-01
    z[1,2,6]  R784      -3.7109214812517166e-02
    z[1,2,6]  R785      0.456543892621994
    z[1,2,6]  R786      3.6825588345527649e-01
    z[1,2,6]  R787      5.0117647647857666e-01
    z[1,2,6]  R788      -4.4853731989860535e-01
    z[1,2,6]  R789      -3.0730417370796204e-01
    z[1,2,6]  R790      8.7859280407428741e-02
    z[1,2,6]  R791      -4.8645719885826111e-02
    z[1,2,6]  R792      -6.7843578755855560e-02
    z[1,2,6]  R793      -2.3056827485561371e-01
    z[1,2,6]  R794      1.1112280935049057e-01
    z[1,2,6]  R795      -3.7142220884561539e-02
    z[1,2,6]  R796      0.476544052362442
    z[1,2,6]  R797      -5.4714262485504150e-02
    z[1,2,6]  R798      -4.4603458046913147e-01
    z[1,2,6]  R799      1.7056821286678314e-01
    z[1,2,6]  R800      4.1587987542152405e-01
    z[1,2,6]  R801      1.8179066479206085e-01
    z[1,2,6]  R802      2.2592335939407349e-01
    z[1,2,6]  R803      2.2567810118198395e-01
    z[1,2,6]  R804      1.1582200415432453e-02
    z[1,2,6]  R805      2.9293093830347061e-02
    z[1,2,6]  R806      -5.0506293773651123e-01
    z[1,2,6]  R807      -3.0052134394645691e-01
    z[1,2,6]  R808      3.8794970512390137e-01
    z[1,2,6]  R809      1.2793380022048950e-01
    z[1,2,6]  R810      4.3868002295494080e-01
    z[1,2,6]  R811      3.8199447095394135e-02
    z[1,2,6]  R812      -6.4267016947269440e-02
    z[1,2,6]  R813      -1.1250492185354233e-01
    z[1,2,6]  R814      1.0586041212081909e-01
    z[1,2,6]  R815      -3.6997777223587036e-01
    z[1,2,6]  R816      -9.2456437647342682e-02
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R817      -1
    z[2,1,0]  R818      1
    z[2,1,0]  R831      -1.6967041790485382e-01
    z[2,1,0]  R832      -1.3388785719871521e-01
    z[2,1,0]  R833      3.0542594194412231e-01
    z[2,1,0]  R834      -0.77823805809021
    z[2,1,0]  R835      -7.9751676321029663e-01
    z[2,1,0]  R836      -8.5658162832260132e-01
    z[2,1,0]  R837      -8.0390030145645142e-01
    z[2,1,0]  R838      -7.7379405498504639e-01
    z[2,1,0]  R839      -8.9063447713851929e-01
    z[2,1,0]  R840      -1.7608661949634552e-01
    z[2,1,0]  R841      1.0001166909933090e-01
    z[2,1,0]  R842      4.4433104991912842e-01
    z[2,1,0]  R843      3.6617133021354675e-01
    z[2,1,0]  R844      1.9942130148410797e-01
    z[2,1,0]  R845      -1.2687428295612335e-01
    z[2,1,0]  R846      -3.5667607188224792e-01
    z[2,1,0]  R847      -5.2196753025054932e-01
    z[2,1,0]  R848      -2.4494828283786774e-01
    z[2,1,0]  R849      -7.5037801265716553e-01
    z[2,1,0]  R850      1.8949049711227417e-01
    z[2,1,0]  R851      -6.1510574817657471e-01
    z[2,1,0]  R852      -3.4907853603363037e-01
    z[2,1,0]  R853      -1.6321410238742828e-01
    z[2,1,0]  R854      -3.3627992868423462e-01
    z[2,1,0]  R855      1.2292774766683578e-01
    z[2,1,0]  R856      1.1723812669515610e-01
    z[2,1,0]  R857      2.9016089439392090e-01
    z[2,1,0]  R858      2.1073332428932190e-01
    z[2,1,0]  R859      1.3649851083755493e-01
    z[2,1,0]  R860      3.8373467326164246e-01
    z[2,1,0]  R861      -6.5858542919158936e-01
    z[2,1,0]  R862      -6.5801924467086792e-01
    z[2,1,0]  R863      -7.1887493133544922e-01
    z[2,1,0]  R864      -4.1052407026290894e-01
    z[2,1,0]  R865      -7.1989625692367554e-01
    z[2,1,0]  R866      -0.59494549036026
    z[2,1,0]  R867      -5.6977653503417969e-01
    z[2,1,0]  R868      -6.3382625579833984e-01
    z[2,1,0]  R869      -0.820820689201355
    z[2,1,0]  R870      -0.791208803653717
    z[2,1,0]  R871      -1.5829540789127350e-01
    z[2,1,0]  R872      1.0571720451116562e-01
    z[2,1,0]  R873      9.0164765715599060e-02
    z[2,1,0]  R874      2.3170144855976105e-01
    z[2,1,0]  R875      1.9998101890087128e-01
    z[2,1,0]  R876      4.8847761750221252e-01
    z[2,1,0]  R877      2.9615685343742371e-01
    z[2,1,0]  R878      3.3222836256027222e-01
    z[2,1,0]  R879      3.5924544930458069e-01
    z[2,1,0]  R880      2.8316259384155273e-01
    z[2,1,0]  R881      4.6913135051727295e-01
    z[2,1,0]  R882      5.9548223018646240e-01
    z[2,1,0]  R883      5.5419504642486572e-01
    z[2,1,0]  R884      7.1332257986068726e-01
    z[2,1,0]  R885      0.413044273853302
    z[2,1,0]  R886      -4.1304641962051392e-01
    z[2,1,0]  R887      4.5895689725875854e-01
    z[2,1,0]  R888      5.3956449031829834e-01
    z[2,1,0]  R889      1.8347802758216858e-01
    z[2,1,0]  R890      8.0835449695587158e-01
    z[2,1,0]  R891      -2.6094338297843933e-01
    z[2,1,0]  R892      -1.0375731438398361e-01
    z[2,1,0]  R893      -1.1744309961795807e-01
    z[2,1,0]  R894      1.6161955893039703e-01
    z[2,1,0]  R895      4.5744961500167847e-01
    z[2,1,0]  R896      2.7871596813201904e-01
    z[2,1,0]  R897      2.7719014883041382e-01
    z[2,1,0]  R898      1.2179224193096161e-01
    z[2,1,0]  R899      -6.3695102930068970e-02
    z[2,1,0]  R900      0.629237711429596
    z[2,1,0]  R901      3.9095136523246765e-01
    z[2,1,0]  R902      3.6560770124197006e-02
    z[2,1,0]  R903      1.7770273983478546e-01
    z[2,1,0]  R904      1.4492644369602203e-01
    z[2,1,0]  R905      0.556480348110199
    z[2,1,0]  R906      5.0131708383560181e-01
    z[2,1,0]  R907      2.5523781776428223e-01
    z[2,1,0]  R908      -1.5742602944374084e-01
    z[2,1,0]  R909      4.6901664137840271e-01
    z[2,1,0]  R910      -0.0424308106303215
    z[2,1,0]  R911      2.9013910889625549e-01
    z[2,1,0]  R912      -2.6687833666801453e-01
    z[2,1,0]  R913      8.5017897188663483e-02
    z[2,1,0]  R914      -1.7064388096332550e-01
    z[2,1,0]  R915      7.6443380117416382e-01
    z[2,1,0]  R916      1.9689476490020752e-01
    z[2,1,0]  R917      8.2556062936782837e-01
    z[2,1,0]  R918      -1.2607698142528534e-01
    z[2,1,0]  R919      7.0532029867172241e-01
    z[2,1,0]  R920      0.554187536239624
    z[2,1,0]  R921      0.498337984085083
    z[2,1,0]  R922      1.3690540194511414e-01
    z[2,1,0]  R923      2.0153930783271790e-01
    z[2,1,0]  R924      3.8671070337295532e-01
    z[2,1,0]  R925      -7.6744019985198975e-02
    z[2,1,0]  R926      2.1289205551147461e-01
    z[2,1,0]  R927      -1.2130734324455261e-01
    z[2,1,0]  R928      4.4750612229108810e-02
    z[2,1,0]  R929      -1.3699607551097870e-01
    z[2,1,0]  R930      1.7185197770595551e-01
    z[2,1,0]  R931      3.0488875508308411e-01
    z[2,1,0]  R932      -2.1510450541973114e-01
    z[2,1,0]  R933      -4.6034038066864014e-01
    z[2,1,0]  R934      4.8502811789512634e-01
    z[2,1,0]  R935      3.1340980529785156e-01
    z[2,1,0]  R936      -3.1027961522340775e-02
    z[2,1,0]  R937      1.2311228550970554e-02
    z[2,1,0]  R938      6.5089219808578491e-01
    z[2,1,0]  R939      2.2151054814457893e-02
    z[2,1,0]  R940      6.4380139112472534e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R819      -1
    z[2,1,1]  R820      1
    z[2,1,1]  R831      7.5533652305603027e-01
    z[2,1,1]  R832      1.5082035958766937e-01
    z[2,1,1]  R833      3.2670933008193970e-01
    z[2,1,1]  R834      -8.6420841515064240e-02
    z[2,1,1]  R835      -9.3506224453449249e-02
    z[2,1,1]  R836      -8.2904092967510223e-02
    z[2,1,1]  R837      7.6480291783809662e-02
    z[2,1,1]  R838      -4.5369766652584076e-02
    z[2,1,1]  R839      -4.7882851213216782e-02
    z[2,1,1]  R840      -1.4118745923042297e-01
    z[2,1,1]  R841      1.1222476139664650e-02
    z[2,1,1]  R842      4.5571732521057129e-01
    z[2,1,1]  R843      -4.6389934420585632e-01
    z[2,1,1]  R844      -4.7327658534049988e-01
    z[2,1,1]  R845      -4.2640617489814758e-01
    z[2,1,1]  R846      -4.0584355592727661e-01
    z[2,1,1]  R847      -0.498304545879364
    z[2,1,1]  R848      -0.765228807926178
    z[2,1,1]  R849      -4.2069500684738159e-01
    z[2,1,1]  R850      -3.6247938871383667e-01
    z[2,1,1]  R851      -5.1551681756973267e-01
    z[2,1,1]  R852      -7.5431865453720093e-01
    z[2,1,1]  R853      -4.4682428240776062e-01
    z[2,1,1]  R854      -7.0357149839401245e-01
    z[2,1,1]  R855      -6.1069816350936890e-01
    z[2,1,1]  R856      -6.9779038429260254e-01
    z[2,1,1]  R857      -0.66790372133255
    z[2,1,1]  R858      -7.9137659072875977e-01
    z[2,1,1]  R859      -6.8418294191360474e-01
    z[2,1,1]  R860      -7.2239428758621216e-01
    z[2,1,1]  R861      -1.8033710122108459e-01
    z[2,1,1]  R862      -2.2804026305675507e-01
    z[2,1,1]  R863      -6.2383204698562622e-02
    z[2,1,1]  R864      -2.5859877467155457e-01
    z[2,1,1]  R865      -9.5601566135883331e-02
    z[2,1,1]  R866      -1.7058271169662476e-01
    z[2,1,1]  R867      -1.5964622795581818e-01
    z[2,1,1]  R868      -1.4073713123798370e-01
    z[2,1,1]  R869      -2.7701035141944885e-01
    z[2,1,1]  R870      -1.3329532742500305e-01
    z[2,1,1]  R871      0.804551362991333
    z[2,1,1]  R872      8.0172097682952881e-01
    z[2,1,1]  R873      8.9155030250549316e-01
    z[2,1,1]  R874      8.1907963752746582e-01
    z[2,1,1]  R875      8.7900412082672119e-01
    z[2,1,1]  R876      8.1295800209045410e-01
    z[2,1,1]  R877      7.5687986612319946e-01
    z[2,1,1]  R878      7.5830638408660889e-01
    z[2,1,1]  R879      7.4715173244476318e-01
    z[2,1,1]  R880      7.0336920022964478e-01
    z[2,1,1]  R881      -2.7622026205062866e-01
    z[2,1,1]  R882      -3.9142203330993652e-01
    z[2,1,1]  R883      -0.248797208070755
    z[2,1,1]  R884      -2.4576936662197113e-01
    z[2,1,1]  R885      -2.1434900164604187e-01
    z[2,1,1]  R886      1.0257773846387863e-01
    z[2,1,1]  R887      -1.3534389436244965e-01
    z[2,1,1]  R888      -1.5342769026756287e-01
    z[2,1,1]  R889      -2.4239315092563629e-01
    z[2,1,1]  R890      1.2143120914697647e-01
    z[2,1,1]  R891      5.4998785257339478e-01
    z[2,1,1]  R892      -7.4844092130661011e-01
    z[2,1,1]  R893      -5.1669752597808838e-01
    z[2,1,1]  R894      2.8788894414901733e-01
    z[2,1,1]  R895      -7.5884765386581421e-01
    z[2,1,1]  R896      -5.1433372497558594e-01
    z[2,1,1]  R897      -5.9484966099262238e-02
    z[2,1,1]  R898      5.6977644562721252e-02
    z[2,1,1]  R899      -9.7424782812595367e-02
    z[2,1,1]  R900      3.4643688797950745e-01
    z[2,1,1]  R901      -7.4864143133163452e-01
    z[2,1,1]  R902      -7.6750653982162476e-01
    z[2,1,1]  R903      -0.63265460729599
    z[2,1,1]  R904      -7.0288920402526855e-01
    z[2,1,1]  R905      -6.0325086116790771e-01
    z[2,1,1]  R906      -6.3913995027542114e-01
    z[2,1,1]  R907      3.4777700901031494e-01
    z[2,1,1]  R908      1.0955148190259933e-01
    z[2,1,1]  R909      3.3840516209602356e-01
    z[2,1,1]  R910      2.0106829702854156e-01
    z[2,1,1]  R911      2.3183113336563110e-01
    z[2,1,1]  R912      4.2090049386024475e-01
    z[2,1,1]  R913      4.7850003838539124e-01
    z[2,1,1]  R914      5.1707899570465088e-01
    z[2,1,1]  R915      4.5963954925537109e-01
    z[2,1,1]  R916      2.8990250825881958e-01
    z[2,1,1]  R917      6.1392839998006821e-02
    z[2,1,1]  R918      -6.5599137544631958e-01
    z[2,1,1]  R919      4.3035867810249329e-01
    z[2,1,1]  R920      4.1396754980087280e-01
    z[2,1,1]  R921      -5.6772458553314209e-01
    z[2,1,1]  R922      -4.0542924404144287e-01
    z[2,1,1]  R923      -2.9511788487434387e-01
    z[2,1,1]  R924      4.9987000226974487e-01
    z[2,1,1]  R925      4.4165849685668945e-01
    z[2,1,1]  R926      4.4861632585525513e-01
    z[2,1,1]  R927      0.58297199010849
    z[2,1,1]  R928      -0.700998842716217
    z[2,1,1]  R929      2.2690226137638092e-01
    z[2,1,1]  R930      -0.0210583433508873
    z[2,1,1]  R931      6.1287569999694824e-01
    z[2,1,1]  R932      -7.1970504522323608e-01
    z[2,1,1]  R933      -5.1845723390579224e-01
    z[2,1,1]  R934      5.7428580522537231e-01
    z[2,1,1]  R935      3.9865252375602722e-01
    z[2,1,1]  R936      -2.9648298025131226e-01
    z[2,1,1]  R937      3.0242647975683212e-02
    z[2,1,1]  R938      1.9152933359146118e-01
    z[2,1,1]  R939      7.7534466981887817e-01
    z[2,1,1]  R940      2.0321662724018097e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R821      -1
    z[2,1,2]  R822      1
    z[2,1,2]  R831      -3.1709957867860794e-02
    z[2,1,2]  R832      -1.1720193177461624e-01
    z[2,1,2]  R833      8.2046687602996826e-01
    z[2,1,2]  R834      4.8310512304306030e-01
    z[2,1,2]  R835      3.8264030218124390e-01
    z[2,1,2]  R836      3.7091696262359619e-01
    z[2,1,2]  R837      2.1323429048061371e-01
    z[2,1,2]  R838      -3.1985055655241013e-02
    z[2,1,2]  R839      -3.7263888120651245e-01
    z[2,1,2]  R840      -5.7381969690322876e-01
    z[2,1,2]  R841      -9.8400421440601349e-02
    z[2,1,2]  R842      -5.2164769172668457e-01
    z[2,1,2]  R843      -6.6140770912170410e-01
    z[2,1,2]  R844      -9.3525443226099014e-03
    z[2,1,2]  R845      -6.2786054611206055e-01
    z[2,1,2]  R846      -7.6410883665084839e-01
    z[2,1,2]  R847      -1.3354372978210449e-01
    z[2,1,2]  R848      -5.2212452888488770e-01
    z[2,1,2]  R849      2.8210720419883728e-01
    z[2,1,2]  R850      -5.5925279855728149e-01
    z[2,1,2]  R851      -0.313320517539978
    z[2,1,2]  R852      2.8686714172363281e-01
    z[2,1,2]  R853      4.6897572278976440e-01
    z[2,1,2]  R854      -4.2075714468955994e-01
    z[2,1,2]  R855      -4.1321775317192078e-01
    z[2,1,2]  R856      -1.0324368625879288e-01
    z[2,1,2]  R857      -5.2678704261779785e-02
    z[2,1,2]  R858      -2.9144442081451416e-01
    z[2,1,2]  R859      -2.6429215073585510e-01
    z[2,1,2]  R860      1.5398591756820679e-01
    z[2,1,2]  R861      3.6491009593009949e-01
    z[2,1,2]  R862      8.3101242780685425e-02
    z[2,1,2]  R863      1.5813589096069336e-01
    z[2,1,2]  R864      4.2543417215347290e-01
    z[2,1,2]  R865      2.5178456306457520e-01
    z[2,1,2]  R866      6.8271708488464355e-01
    z[2,1,2]  R867      -3.4442096948623657e-01
    z[2,1,2]  R868      -1.5313203446567059e-02
    z[2,1,2]  R869      4.7069203108549118e-02
    z[2,1,2]  R870      -2.3530335724353790e-01
    z[2,1,2]  R871      2.4600613117218018e-01
    z[2,1,2]  R872      1.5599825978279114e-01
    z[2,1,2]  R873      1.8806867301464081e-01
    z[2,1,2]  R874      4.3373140692710876e-01
    z[2,1,2]  R875      -9.5579192042350769e-02
    z[2,1,2]  R876      0.0797993540763855
    z[2,1,2]  R877      6.5456248819828033e-02
    z[2,1,2]  R878      -2.2454971075057983e-01
    z[2,1,2]  R879      1.0154710710048676e-01
    z[2,1,2]  R880      3.5156715661287308e-02
    z[2,1,2]  R881      3.8920834660530090e-02
    z[2,1,2]  R882      -5.9202855825424194e-01
    z[2,1,2]  R883      -5.0289428234100342e-01
    z[2,1,2]  R884      -2.5969842076301575e-01
    z[2,1,2]  R885      -2.9287990927696228e-01
    z[2,1,2]  R886      -5.1057970523834229e-01
    z[2,1,2]  R887      -2.9195931553840637e-01
    z[2,1,2]  R888      -1.5345829725265503e-01
    z[2,1,2]  R889      -5.4529237747192383e-01
    z[2,1,2]  R890      -2.5295522809028625e-01
    z[2,1,2]  R891      9.3944780528545380e-02
    z[2,1,2]  R892      -4.6293100714683533e-01
    z[2,1,2]  R893      -6.5030390024185181e-01
    z[2,1,2]  R894      4.0662553906440735e-01
    z[2,1,2]  R895      4.1330105066299438e-01
    z[2,1,2]  R896      -3.1752744317054749e-01
    z[2,1,2]  R897      -8.1574696302413940e-01
    z[2,1,2]  R898      3.1801056861877441e-01
    z[2,1,2]  R899      -7.5886243581771851e-01
    z[2,1,2]  R900      -4.8464578390121460e-01
    z[2,1,2]  R901      -9.4092048704624176e-02
    z[2,1,2]  R902      -2.3630566895008087e-01
    z[2,1,2]  R903      3.9439156651496887e-02
    z[2,1,2]  R904      -5.8352392911911011e-01
    z[2,1,2]  R905      -4.4249197840690613e-01
    z[2,1,2]  R906      -3.7597176432609558e-01
    z[2,1,2]  R907      -1.0341511666774750e-01
    z[2,1,2]  R908      -0.631401777267456
    z[2,1,2]  R909      -1.3033016026020050e-01
    z[2,1,2]  R910      -0.673624575138092
    z[2,1,2]  R911      8.6111530661582947e-02
    z[2,1,2]  R912      -6.5445655584335327e-01
    z[2,1,2]  R913      -7.5995332002639771e-01
    z[2,1,2]  R914      -0.604049563407898
    z[2,1,2]  R915      -2.5753778219223022e-01
    z[2,1,2]  R916      -5.3976607322692871e-01
    z[2,1,2]  R917      4.2098306119441986e-02
    z[2,1,2]  R918      3.4863191843032837e-01
    z[2,1,2]  R919      4.5605354011058807e-02
    z[2,1,2]  R920      -3.8888771086931229e-02
    z[2,1,2]  R921      -2.9725676774978638e-01
    z[2,1,2]  R922      3.8173702359199524e-01
    z[2,1,2]  R923      -1.8941754102706909e-01
    z[2,1,2]  R924      1.1917474865913391e-01
    z[2,1,2]  R925      -7.8999191522598267e-01
    z[2,1,2]  R926      1.3872574269771576e-01
    z[2,1,2]  R927      4.2276558279991150e-01
    z[2,1,2]  R928      4.0643098950386047e-01
    z[2,1,2]  R929      5.0381618738174438e-01
    z[2,1,2]  R930      -3.2543742656707764e-01
    z[2,1,2]  R931      9.7078546881675720e-02
    z[2,1,2]  R932      -2.7968008071184158e-03
    z[2,1,2]  R933      3.8206619024276733e-01
    z[2,1,2]  R934      -2.5693991780281067e-01
    z[2,1,2]  R935      2.8152132034301758e-01
    z[2,1,2]  R936      -6.1093878746032715e-01
    z[2,1,2]  R937      -3.3857741951942444e-01
    z[2,1,2]  R938      -0.472592294216156
    z[2,1,2]  R939      9.7093977034091949e-02
    z[2,1,2]  R940      -2.3159457743167877e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R823      -1
    z[2,1,3]  R824      1
    z[2,1,3]  R831      2.4858303368091583e-01
    z[2,1,3]  R832      4.2554402351379395e-01
    z[2,1,3]  R833      0.0343628004193306
    z[2,1,3]  R834      -3.8013058900833130e-01
    z[2,1,3]  R835      -2.9829597473144531e-01
    z[2,1,3]  R836      -3.3759616315364838e-02
    z[2,1,3]  R837      -4.6697562932968140e-01
    z[2,1,3]  R838      -3.4522190690040588e-01
    z[2,1,3]  R839      -1.0063122212886810e-01
    z[2,1,3]  R840      -0.532974362373352
    z[2,1,3]  R841      0.795096755027771
    z[2,1,3]  R842      -6.5679289400577545e-02
    z[2,1,3]  R843      2.1196436882019043e-01
    z[2,1,3]  R844      -5.1714515686035156e-01
    z[2,1,3]  R845      -3.2441899180412292e-01
    z[2,1,3]  R846      2.2344872355461121e-01
    z[2,1,3]  R847      -2.0596009492874146e-01
    z[2,1,3]  R848      -2.5589501857757568e-01
    z[2,1,3]  R849      -2.2315208613872528e-01
    z[2,1,3]  R850      -4.5817753672599792e-01
    z[2,1,3]  R851      -1.4972835779190063e-01
    z[2,1,3]  R852      2.0119418203830719e-01
    z[2,1,3]  R853      -7.1833759546279907e-01
    z[2,1,3]  R854      7.2061540558934212e-03
    z[2,1,3]  R855      -4.4673284888267517e-01
    z[2,1,3]  R856      -6.6427075862884521e-01
    z[2,1,3]  R857      -4.9844187498092651e-01
    z[2,1,3]  R858      -3.5893306136131287e-01
    z[2,1,3]  R859      -3.5574150085449219e-01
    z[2,1,3]  R860      -1.9878847897052765e-01
    z[2,1,3]  R861      -3.7720409035682678e-01
    z[2,1,3]  R862      -5.0152492523193359e-01
    z[2,1,3]  R863      -0.620127260684967
    z[2,1,3]  R864      -3.0619978904724121e-01
    z[2,1,3]  R865      -4.6318736672401428e-01
    z[2,1,3]  R866      -2.8145933151245117e-01
    z[2,1,3]  R867      -4.9411794543266296e-01
    z[2,1,3]  R868      -4.7303819656372070e-01
    z[2,1,3]  R869      -1.5031154453754425e-01
    z[2,1,3]  R870      -3.8023716211318970e-01
    z[2,1,3]  R871      4.0187767148017883e-01
    z[2,1,3]  R872      3.0618983507156372e-01
    z[2,1,3]  R873      1.4561046659946442e-01
    z[2,1,3]  R874      2.7717188000679016e-01
    z[2,1,3]  R875      3.1537401676177979e-01
    z[2,1,3]  R876      1.7669594287872314e-01
    z[2,1,3]  R877      2.2975522279739380e-01
    z[2,1,3]  R878      3.0813151597976685e-01
    z[2,1,3]  R879      1.8196175992488861e-01
    z[2,1,3]  R880      3.0411624908447266e-01
    z[2,1,3]  R881      -4.7513264417648315e-01
    z[2,1,3]  R882      -2.9910793900489807e-01
    z[2,1,3]  R883      -4.9415990710258484e-01
    z[2,1,3]  R884      -5.3595000505447388e-01
    z[2,1,3]  R885      -7.0295113325119019e-01
    z[2,1,3]  R886      6.3802433013916016e-01
    z[2,1,3]  R887      -5.2820432186126709e-01
    z[2,1,3]  R888      -7.0321941375732422e-01
    z[2,1,3]  R889      -1.1157199740409851e-01
    z[2,1,3]  R890      4.9584048986434937e-01
    z[2,1,3]  R891      6.3299578428268433e-01
    z[2,1,3]  R892      1.0616496205329895e-01
    z[2,1,3]  R893      2.5820401310920715e-01
    z[2,1,3]  R894      7.9184156656265259e-01
    z[2,1,3]  R895      -8.7833821773529053e-02
    z[2,1,3]  R896      -6.3290582038462162e-03
    z[2,1,3]  R897      3.8389280438423157e-01
    z[2,1,3]  R898      5.2608340978622437e-01
    z[2,1,3]  R899      3.3938249945640564e-01
    z[2,1,3]  R900      2.5562044978141785e-01
    z[2,1,3]  R901      -3.0140110850334167e-01
    z[2,1,3]  R902      -2.7371674776077271e-01
    z[2,1,3]  R903      -0.520424485206604
    z[2,1,3]  R904      5.7561047375202179e-02
    z[2,1,3]  R905      -1.3779722154140472e-01
    z[2,1,3]  R906      1.5111909806728363e-01
    z[2,1,3]  R907      7.1562141180038452e-01
    z[2,1,3]  R908      7.0563733577728271e-01
    z[2,1,3]  R909      6.9247573614120483e-01
    z[2,1,3]  R910      3.9864847064018250e-01
    z[2,1,3]  R911      8.6471486091613770e-01
    z[2,1,3]  R912      2.9924002289772034e-01
    z[2,1,3]  R913      9.8448902368545532e-02
    z[2,1,3]  R914      0.0271736029535532
    z[2,1,3]  R915      1.0608037561178207e-01
    z[2,1,3]  R916      1.6946910321712494e-01
    z[2,1,3]  R917      3.3247882127761841e-01
    z[2,1,3]  R918      0.596255898475647
    z[2,1,3]  R919      1.9995900988578796e-01
    z[2,1,3]  R920      2.9122719168663025e-01
    z[2,1,3]  R921      -1.0755251161754131e-02
    z[2,1,3]  R922      -7.1085256338119507e-01
    z[2,1,3]  R923      -7.3259377479553223e-01
    z[2,1,3]  R924      6.1649543046951294e-01
    z[2,1,3]  R925      3.1919321417808533e-01
    z[2,1,3]  R926      0.474653959274292
    z[2,1,3]  R927      5.7778173685073853e-01
    z[2,1,3]  R928      2.9399591684341431e-01
    z[2,1,3]  R929      5.8195346593856812e-01
    z[2,1,3]  R930      4.9630695581436157e-01
    z[2,1,3]  R931      6.5015846490859985e-01
    z[2,1,3]  R932      1.1039676517248154e-01
    z[2,1,3]  R933      4.3881908059120178e-01
    z[2,1,3]  R934      5.5209094285964966e-01
    z[2,1,3]  R935      5.9213083982467651e-01
    z[2,1,3]  R936      0.625938355922699
    z[2,1,3]  R937      6.1959064006805420e-01
    z[2,1,3]  R938      3.7651520967483521e-01
    z[2,1,3]  R939      -4.0214595198631287e-01
    z[2,1,3]  R940      3.4837007522583008e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R825      -1
    z[2,1,4]  R826      1
    z[2,1,4]  R831      2.2210077941417694e-01
    z[2,1,4]  R832      0.52739018201828
    z[2,1,4]  R833      6.0279220342636108e-02
    z[2,1,4]  R834      2.4187561124563217e-02
    z[2,1,4]  R835      -0.0906379222869873
    z[2,1,4]  R836      -3.1904366612434387e-01
    z[2,1,4]  R837      -1.3254015147686005e-01
    z[2,1,4]  R838      -5.0502443313598633e-01
    z[2,1,4]  R839      -1.4713397622108459e-01
    z[2,1,4]  R840      -2.8011593222618103e-01
    z[2,1,4]  R841      -3.7752330303192139e-01
    z[2,1,4]  R842      -2.7722901105880737e-01
    z[2,1,4]  R843      -3.1362017989158630e-01
    z[2,1,4]  R844      4.6093329787254333e-01
    z[2,1,4]  R845      4.8824116587638855e-01
    z[2,1,4]  R846      5.0413936376571655e-02
    z[2,1,4]  R847      -2.4194929003715515e-01
    z[2,1,4]  R848      -6.4516708254814148e-02
    z[2,1,4]  R849      2.3263719677925110e-01
    z[2,1,4]  R850      -2.1304479241371155e-01
    z[2,1,4]  R851      2.3986525833606720e-02
    z[2,1,4]  R852      9.1045916080474854e-02
    z[2,1,4]  R853      4.5402288436889648e-02
    z[2,1,4]  R854      -1.3329149782657623e-01
    z[2,1,4]  R855      -4.3217939138412476e-01
    z[2,1,4]  R856      -2.0710915327072144e-01
    z[2,1,4]  R857      -4.0176659822463989e-01
    z[2,1,4]  R858      -3.0604231357574463e-01
    z[2,1,4]  R859      -3.3184453845024109e-01
    z[2,1,4]  R860      1.4250871725380421e-02
    z[2,1,4]  R861      -3.2421648502349854e-01
    z[2,1,4]  R862      -0.287641316652298
    z[2,1,4]  R863      -2.5535440444946289e-01
    z[2,1,4]  R864      -6.8725836277008057e-01
    z[2,1,4]  R865      1.0965451598167419e-01
    z[2,1,4]  R866      -8.6141265928745270e-02
    z[2,1,4]  R867      -3.9865094423294067e-01
    z[2,1,4]  R868      -1.8897384405136108e-01
    z[2,1,4]  R869      2.6522138714790344e-01
    z[2,1,4]  R870      1.8102388083934784e-01
    z[2,1,4]  R871      -7.8041076660156250e-02
    z[2,1,4]  R872      -2.4372771382331848e-01
    z[2,1,4]  R873      1.0159488767385483e-01
    z[2,1,4]  R874      3.1711183488368988e-02
    z[2,1,4]  R875      1.2975813448429108e-01
    z[2,1,4]  R876      3.6978356540203094e-02
    z[2,1,4]  R877      4.7158572822809219e-02
    z[2,1,4]  R878      -2.0836353302001953e-01
    z[2,1,4]  R879      -7.6501868665218353e-02
    z[2,1,4]  R880      -2.3105712607502937e-03
    z[2,1,4]  R881      -2.3320877552032471e-01
    z[2,1,4]  R882      -1.1149710416793823e-01
    z[2,1,4]  R883      1.9031253457069397e-01
    z[2,1,4]  R884      -2.6426789164543152e-01
    z[2,1,4]  R885      3.6705070734024048e-01
    z[2,1,4]  R886      3.2231593132019043e-01
    z[2,1,4]  R887      -1.2098166346549988e-01
    z[2,1,4]  R888      4.6424347907304764e-02
    z[2,1,4]  R889      -2.0061565935611725e-01
    z[2,1,4]  R890      -3.2303226180374622e-03
    z[2,1,4]  R891      -1.9778303802013397e-01
    z[2,1,4]  R892      2.3271875083446503e-01
    z[2,1,4]  R893      -2.0879207551479340e-01
    z[2,1,4]  R894      -1.4656364917755127e-01
    z[2,1,4]  R895      3.8150716572999954e-02
    z[2,1,4]  R896      1.2002401798963547e-01
    z[2,1,4]  R897      3.2161605358123779e-01
    z[2,1,4]  R898      4.0730339288711548e-01
    z[2,1,4]  R899      4.8944327980279922e-02
    z[2,1,4]  R900      3.6813560128211975e-01
    z[2,1,4]  R901      -1.9165527820587158e-01
    z[2,1,4]  R902      4.9533969163894653e-01
    z[2,1,4]  R903      3.0061343312263489e-01
    z[2,1,4]  R904      2.9962889850139618e-02
    z[2,1,4]  R905      4.4709322974085808e-03
    z[2,1,4]  R906      -1.3671702146530151e-01
    z[2,1,4]  R907      1.6357812285423279e-01
    z[2,1,4]  R908      1.9558621942996979e-01
    z[2,1,4]  R909      3.6986431479454041e-01
    z[2,1,4]  R910      2.1674321591854095e-01
    z[2,1,4]  R911      -4.2414046823978424e-02
    z[2,1,4]  R912      -1.7318703234195709e-02
    z[2,1,4]  R913      3.6371055245399475e-01
    z[2,1,4]  R914      4.8381996154785156e-01
    z[2,1,4]  R915      -3.2471738755702972e-02
    z[2,1,4]  R916      5.8499181270599365e-01
    z[2,1,4]  R917      4.3477073311805725e-01
    z[2,1,4]  R918      1.2443201988935471e-01
    z[2,1,4]  R919      1.5923465788364410e-01
    z[2,1,4]  R920      4.4488483667373657e-01
    z[2,1,4]  R921      -1.4953131973743439e-01
    z[2,1,4]  R922      6.2398705631494522e-02
    z[2,1,4]  R923      2.5058604776859283e-02
    z[2,1,4]  R924      -4.4366973638534546e-01
    z[2,1,4]  R925      2.5789496302604675e-01
    z[2,1,4]  R926      4.7080650925636292e-01
    z[2,1,4]  R927      -1.0918192565441132e-03
    z[2,1,4]  R928      -1.5598331391811371e-01
    z[2,1,4]  R929      4.9181395769119263e-01
    z[2,1,4]  R930      7.5598949193954468e-01
    z[2,1,4]  R931      -1.1459868401288986e-01
    z[2,1,4]  R932      -3.6937814950942993e-01
    z[2,1,4]  R933      3.9902281761169434e-01
    z[2,1,4]  R934      2.1089439094066620e-01
    z[2,1,4]  R935      3.0564457178115845e-01
    z[2,1,4]  R936      2.1205591037869453e-02
    z[2,1,4]  R937      6.6968256235122681e-01
    z[2,1,4]  R938      3.4454742074012756e-01
    z[2,1,4]  R939      4.2818868532776833e-03
    z[2,1,4]  R940      4.8093062639236450e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R827      -1
    z[2,1,5]  R828      1
    z[2,1,5]  R831      1.9332119822502136e-01
    z[2,1,5]  R832      5.3401970863342285e-01
    z[2,1,5]  R833      -1.6601161658763885e-01
    z[2,1,5]  R834      -2.6130869984626770e-02
    z[2,1,5]  R835      3.3052659034729004e-01
    z[2,1,5]  R836      1.1951579898595810e-01
    z[2,1,5]  R837      1.1675358563661575e-01
    z[2,1,5]  R838      1.0763483494520187e-01
    z[2,1,5]  R839      -1.8017560243606567e-01
    z[2,1,5]  R840      -1.7369458079338074e-01
    z[2,1,5]  R841      -4.4999197125434875e-01
    z[2,1,5]  R842      -2.0654010772705078e-01
    z[2,1,5]  R843      2.0217722654342651e-01
    z[2,1,5]  R844      2.8861439228057861e-01
    z[2,1,5]  R845      -1.7662626504898071e-01
    z[2,1,5]  R846      -1.4387050271034241e-01
    z[2,1,5]  R847      -0.556344211101532
    z[2,1,5]  R848      1.0969237983226776e-01
    z[2,1,5]  R849      -2.7493458986282349e-01
    z[2,1,5]  R850      -9.7647741436958313e-02
    z[2,1,5]  R851      -3.8001391291618347e-01
    z[2,1,5]  R852      1.6607622802257538e-01
    z[2,1,5]  R853      -1.3904532790184021e-01
    z[2,1,5]  R854      0.0678798034787178
    z[2,1,5]  R855      -2.3103940486907959e-01
    z[2,1,5]  R856      -2.0109573379158974e-02
    z[2,1,5]  R857      -2.1075604856014252e-01
    z[2,1,5]  R858      1.0331179201602936e-01
    z[2,1,5]  R859      -2.6430118083953857e-01
    z[2,1,5]  R860      5.0883638858795166e-01
    z[2,1,5]  R861      -7.6462127268314362e-02
    z[2,1,5]  R862      3.5775130987167358e-01
    z[2,1,5]  R863      -5.0992354750633240e-02
    z[2,1,5]  R864      6.8135358393192291e-02
    z[2,1,5]  R865      4.2147073149681091e-01
    z[2,1,5]  R866      9.6685782074928284e-02
    z[2,1,5]  R867      2.4848919361829758e-02
    z[2,1,5]  R868      3.7973019480705261e-01
    z[2,1,5]  R869      -3.8027125597000122e-01
    z[2,1,5]  R870      -2.2399128973484039e-01
    z[2,1,5]  R871      1.3740417361259460e-01
    z[2,1,5]  R872      3.0534034967422485e-01
    z[2,1,5]  R873      3.5866221785545349e-01
    z[2,1,5]  R874      5.9211300686001778e-03
    z[2,1,5]  R875      -1.6443461179733276e-02
    z[2,1,5]  R876      2.0932057499885559e-01
    z[2,1,5]  R877      3.7273299694061279e-01
    z[2,1,5]  R878      2.1522977948188782e-01
    z[2,1,5]  R879      0.511130690574646
    z[2,1,5]  R880      3.6250913143157959e-01
    z[2,1,5]  R881      -0.648076057434082
    z[2,1,5]  R882      0.0657590702176094
    z[2,1,5]  R883      -2.9661828279495239e-01
    z[2,1,5]  R884      -7.6879158616065979e-02
    z[2,1,5]  R885      -2.1222910284996033e-01
    z[2,1,5]  R886      1.6392305493354797e-01
    z[2,1,5]  R887      -4.2393404245376587e-01
    z[2,1,5]  R888      -1.5759025514125824e-01
    z[2,1,5]  R889      -3.9872181415557861e-01
    z[2,1,5]  R890      7.0305779576301575e-02
    z[2,1,5]  R891      4.1900908946990967e-01
    z[2,1,5]  R892      1.4060950279235840e-01
    z[2,1,5]  R893      -4.0386593341827393e-01
    z[2,1,5]  R894      2.3328746855258942e-01
    z[2,1,5]  R895      1.4735272526741028e-01
    z[2,1,5]  R896      -1.0939425788819790e-02
    z[2,1,5]  R897      -2.9343429952859879e-02
    z[2,1,5]  R898      6.4921337366104126e-01
    z[2,1,5]  R899      5.4124879837036133e-01
    z[2,1,5]  R900      -2.0792341232299805e-01
    z[2,1,5]  R901      2.0585437119007111e-01
    z[2,1,5]  R902      -9.0375185012817383e-02
    z[2,1,5]  R903      -4.8706404864788055e-02
    z[2,1,5]  R904      -1.5952616930007935e-01
    z[2,1,5]  R905      -4.9883734434843063e-02
    z[2,1,5]  R906      -3.8910800218582153e-01
    z[2,1,5]  R907      4.2181101441383362e-01
    z[2,1,5]  R908      -1.6269692778587341e-01
    z[2,1,5]  R909      -1.3045889139175415e-01
    z[2,1,5]  R910      8.8567227125167847e-02
    z[2,1,5]  R911      3.1192660331726074e-01
    z[2,1,5]  R912      3.9336517453193665e-01
    z[2,1,5]  R913      2.0151710510253906e-01
    z[2,1,5]  R914      9.1979645192623138e-02
    z[2,1,5]  R915      -4.3433707207441330e-02
    z[2,1,5]  R916      -3.8120919466018677e-01
    z[2,1,5]  R917      -1.0739266127347946e-01
    z[2,1,5]  R918      1.6362212598323822e-01
    z[2,1,5]  R919      -3.6934378743171692e-01
    z[2,1,5]  R920      -4.7725012898445129e-01
    z[2,1,5]  R921      -0.523442268371582
    z[2,1,5]  R922      -2.9658830165863037e-01
    z[2,1,5]  R923      2.5670301169157028e-02
    z[2,1,5]  R924      8.1822425127029419e-02
    z[2,1,5]  R925      -6.0947993770241737e-03
    z[2,1,5]  R926      3.6438152194023132e-01
    z[2,1,5]  R927      -3.4555536508560181e-01
    z[2,1,5]  R928      -4.6714732050895691e-01
    z[2,1,5]  R929      1.2319060415029526e-01
    z[2,1,5]  R930      5.1724273711442947e-02
    z[2,1,5]  R931      2.0836119353771210e-01
    z[2,1,5]  R932      -2.1691080927848816e-01
    z[2,1,5]  R933      1.4422725141048431e-01
    z[2,1,5]  R934      -9.9152170121669769e-02
    z[2,1,5]  R935      -1.5527497231960297e-01
    z[2,1,5]  R936      3.7689003348350525e-01
    z[2,1,5]  R937      -8.8169820606708527e-02
    z[2,1,5]  R938      2.3336377739906311e-01
    z[2,1,5]  R939      -1.3693358004093170e-01
    z[2,1,5]  R940      4.8149690032005310e-02
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R829      -1
    z[2,1,6]  R830      1
    z[2,1,6]  R831      5.0117647647857666e-01
    z[2,1,6]  R832      -4.4853731989860535e-01
    z[2,1,6]  R833      -3.0730417370796204e-01
    z[2,1,6]  R834      8.7859280407428741e-02
    z[2,1,6]  R835      -4.8645719885826111e-02
    z[2,1,6]  R836      -6.7843578755855560e-02
    z[2,1,6]  R837      -2.3056827485561371e-01
    z[2,1,6]  R838      1.1112280935049057e-01
    z[2,1,6]  R839      -3.7142220884561539e-02
    z[2,1,6]  R840      0.476544052362442
    z[2,1,6]  R841      -5.4714262485504150e-02
    z[2,1,6]  R842      -4.4603458046913147e-01
    z[2,1,6]  R843      1.7056821286678314e-01
    z[2,1,6]  R844      4.1587987542152405e-01
    z[2,1,6]  R845      1.8179066479206085e-01
    z[2,1,6]  R846      2.2592335939407349e-01
    z[2,1,6]  R847      2.2567810118198395e-01
    z[2,1,6]  R848      1.1582200415432453e-02
    z[2,1,6]  R849      2.9293093830347061e-02
    z[2,1,6]  R850      -5.0506293773651123e-01
    z[2,1,6]  R851      -3.0052134394645691e-01
    z[2,1,6]  R852      3.8794970512390137e-01
    z[2,1,6]  R853      1.2793380022048950e-01
    z[2,1,6]  R854      4.3868002295494080e-01
    z[2,1,6]  R855      3.8199447095394135e-02
    z[2,1,6]  R856      -6.4267016947269440e-02
    z[2,1,6]  R857      -1.1250492185354233e-01
    z[2,1,6]  R858      1.0586041212081909e-01
    z[2,1,6]  R859      -3.6997777223587036e-01
    z[2,1,6]  R860      -9.2456437647342682e-02
    z[2,1,6]  R861      -0.383847177028656
    z[2,1,6]  R862      2.1412980556488037e-01
    z[2,1,6]  R863      4.4229626655578613e-02
    z[2,1,6]  R864      -1.1348040401935577e-01
    z[2,1,6]  R865      -7.0780552923679352e-02
    z[2,1,6]  R866      2.3420266807079315e-01
    z[2,1,6]  R867      -3.5714048147201538e-01
    z[2,1,6]  R868      -4.1779378056526184e-01
    z[2,1,6]  R869      -9.8797872662544250e-02
    z[2,1,6]  R870      -2.7079728245735168e-01
    z[2,1,6]  R871      -2.8398019075393677e-01
    z[2,1,6]  R872      2.7448818087577820e-01
    z[2,1,6]  R873      -3.8419350981712341e-02
    z[2,1,6]  R874      9.7134284675121307e-02
    z[2,1,6]  R875      -2.4830566346645355e-01
    z[2,1,6]  R876      -1.3310468196868896e-01
    z[2,1,6]  R877      3.7576359510421753e-01
    z[2,1,6]  R878      -2.8193789720535278e-01
    z[2,1,6]  R879      4.6669259667396545e-02
    z[2,1,6]  R880      -4.4715738296508789e-01
    z[2,1,6]  R881      4.4310346245765686e-02
    z[2,1,6]  R882      1.8833646178245544e-01
    z[2,1,6]  R883      -0.0983353853225708
    z[2,1,6]  R884      1.8292682245373726e-02
    z[2,1,6]  R885      1.5415126085281372e-01
    z[2,1,6]  R886      1.4263746142387390e-01
    z[2,1,6]  R887      4.6091634035110474e-01
    z[2,1,6]  R888      3.7453049421310425e-01
    z[2,1,6]  R889      6.3131886720657349e-01
    z[2,1,6]  R890      -1.3046045601367950e-01
    z[2,1,6]  R891      7.2290033102035522e-02
    z[2,1,6]  R892      3.5995218157768250e-01
    z[2,1,6]  R893      1.5154068171977997e-01
    z[2,1,6]  R894      -1.5079037845134735e-01
    z[2,1,6]  R895      1.1484432965517044e-01
    z[2,1,6]  R896      -0.736470639705658
    z[2,1,6]  R897      5.0123695284128189e-02
    z[2,1,6]  R898      1.2904106080532074e-01
    z[2,1,6]  R899      7.2645372711122036e-03
    z[2,1,6]  R900      7.1147575974464417e-02
    z[2,1,6]  R901      3.2846489548683167e-01
    z[2,1,6]  R902      -1.5908074378967285e-01
    z[2,1,6]  R903      -4.5059084892272949e-01
    z[2,1,6]  R904      -3.3879649639129639e-01
    z[2,1,6]  R905      -3.3033692836761475e-01
    z[2,1,6]  R906      7.6765216886997223e-02
    z[2,1,6]  R907      -2.9396224021911621e-01
    z[2,1,6]  R908      4.3577242642641068e-02
    z[2,1,6]  R909      1.2319776415824890e-01
    z[2,1,6]  R910      -5.3875666856765747e-01
    z[2,1,6]  R911      8.8483437895774841e-02
    z[2,1,6]  R912      2.8057926893234253e-01
    z[2,1,6]  R913      -6.0776922851800919e-02
    z[2,1,6]  R914      3.0879381299018860e-01
    z[2,1,6]  R915      -3.5192728042602539e-01
    z[2,1,6]  R916      -2.6379138231277466e-01
    z[2,1,6]  R917      4.2512655258178711e-02
    z[2,1,6]  R918      -1.8563105165958405e-01
    z[2,1,6]  R919      3.3686894178390503e-01
    z[2,1,6]  R920      -9.7422868013381958e-02
    z[2,1,6]  R921      2.1099606156349182e-01
    z[2,1,6]  R922      2.7201318740844727e-01
    z[2,1,6]  R923      5.4628539085388184e-01
    z[2,1,6]  R924      5.2705843001604080e-02
    z[2,1,6]  R925      -8.0805547535419464e-02
    z[2,1,6]  R926      -3.9299684762954712e-01
    z[2,1,6]  R927      1.1600001901388168e-01
    z[2,1,6]  R928      1.1144879460334778e-01
    z[2,1,6]  R929      2.8317835927009583e-01
    z[2,1,6]  R930      2.0880098640918732e-01
    z[2,1,6]  R931      2.0675741136074066e-01
    z[2,1,6]  R932      4.8996829986572266e-01
    z[2,1,6]  R933      -2.7041694149374962e-02
    z[2,1,6]  R934      9.9062584340572357e-02
    z[2,1,6]  R935      -4.4209539890289307e-01
    z[2,1,6]  R936      -5.9952650219202042e-02
    z[2,1,6]  R937      2.1013806760311127e-01
    z[2,1,6]  R938      -3.7109214812517166e-02
    z[2,1,6]  R939      0.456543892621994
    z[2,1,6]  R940      3.6825588345527649e-01
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R941      -1
    z[2,3,0]  R942      1
    z[2,3,0]  R955      -1.6967041790485382e-01
    z[2,3,0]  R956      -1.3388785719871521e-01
    z[2,3,0]  R957      3.0542594194412231e-01
    z[2,3,0]  R958      -0.77823805809021
    z[2,3,0]  R959      -7.9751676321029663e-01
    z[2,3,0]  R960      -8.5658162832260132e-01
    z[2,3,0]  R961      -8.0390030145645142e-01
    z[2,3,0]  R962      -7.7379405498504639e-01
    z[2,3,0]  R963      -8.9063447713851929e-01
    z[2,3,0]  R964      -1.7608661949634552e-01
    z[2,3,0]  R965      1.0001166909933090e-01
    z[2,3,0]  R966      4.4433104991912842e-01
    z[2,3,0]  R967      3.6617133021354675e-01
    z[2,3,0]  R968      1.9942130148410797e-01
    z[2,3,0]  R969      -1.2687428295612335e-01
    z[2,3,0]  R970      -3.5667607188224792e-01
    z[2,3,0]  R971      -5.2196753025054932e-01
    z[2,3,0]  R972      -2.4494828283786774e-01
    z[2,3,0]  R973      -7.5037801265716553e-01
    z[2,3,0]  R974      1.8949049711227417e-01
    z[2,3,0]  R975      -6.1510574817657471e-01
    z[2,3,0]  R976      -3.4907853603363037e-01
    z[2,3,0]  R977      -1.6321410238742828e-01
    z[2,3,0]  R978      -3.3627992868423462e-01
    z[2,3,0]  R979      1.2292774766683578e-01
    z[2,3,0]  R980      1.1723812669515610e-01
    z[2,3,0]  R981      2.9016089439392090e-01
    z[2,3,0]  R982      2.1073332428932190e-01
    z[2,3,0]  R983      1.3649851083755493e-01
    z[2,3,0]  R984      3.8373467326164246e-01
    z[2,3,0]  R985      -5.4624056816101074e-01
    z[2,3,0]  R986      -0.424212247133255
    z[2,3,0]  R987      7.1994647383689880e-02
    z[2,3,0]  R988      -6.1272311210632324e-01
    z[2,3,0]  R989      -6.4805978536605835e-01
    z[2,3,0]  R990      -3.4386971592903137e-01
    z[2,3,0]  R991      -8.9542247354984283e-02
    z[2,3,0]  R992      1.1211939901113510e-01
    z[2,3,0]  R993      -2.8060302138328552e-01
    z[2,3,0]  R994      3.1735548377037048e-01
    z[2,3,0]  R995      -6.1525338888168335e-01
    z[2,3,0]  R996      -8.6321853101253510e-02
    z[2,3,0]  R997      1.6740697622299194e-01
    z[2,3,0]  R998      3.4569454193115234e-01
    z[2,3,0]  R999      5.2569651603698730e-01
    z[2,3,0]  R1000     3.9396968483924866e-01
    z[2,3,0]  R1001     2.5449299812316895e-01
    z[2,3,0]  R1002     -6.4478024840354919e-02
    z[2,3,0]  R1003     -3.1391513347625732e-01
    z[2,3,0]  R1004     0.0785473957657814
    z[2,3,0]  R1005     -0.202298104763031
    z[2,3,0]  R1006     -3.6601746082305908e-01
    z[2,3,0]  R1007     1.3802783191204071e-01
    z[2,3,0]  R1008     -0.574720025062561
    z[2,3,0]  R1009     -1.1223085224628448e-01
    z[2,3,0]  R1010     -2.9490327835083008e-01
    z[2,3,0]  R1011     3.1449355185031891e-02
    z[2,3,0]  R1012     -2.7709737420082092e-02
    z[2,3,0]  R1013     -7.8968949615955353e-02
    z[2,3,0]  R1014     1.7646408081054688e-01
    z[2,3,0]  R1015     -1.8827441334724426e-01
    z[2,3,0]  R1016     -2.2635528445243835e-01
    z[2,3,0]  R1017     2.1855413913726807e-01
    z[2,3,0]  R1018     -4.7770336270332336e-02
    z[2,3,0]  R1019     1.0365481674671173e-01
    z[2,3,0]  R1020     -1.7878907918930054e-01
    z[2,3,0]  R1021     -4.6802438795566559e-02
    z[2,3,0]  R1022     -5.0883240997791290e-02
    z[2,3,0]  R1023     1.4553122222423553e-01
    z[2,3,0]  R1024     2.3893390595912933e-01
    z[2,3,0]  R1025     -8.7573036551475525e-02
    z[2,3,0]  R1026     3.5484347492456436e-02
    z[2,3,0]  R1027     -1.9336035475134850e-02
    z[2,3,0]  R1028     5.8665376156568527e-02
    z[2,3,0]  R1029     -3.2212796807289124e-01
    z[2,3,0]  R1030     2.3365199565887451e-01
    z[2,3,0]  R1031     -1.0389288514852524e-01
    z[2,3,0]  R1032     -4.9414080381393433e-01
    z[2,3,0]  R1033     -4.2689168453216553e-01
    z[2,3,0]  R1034     2.8846862912178040e-01
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R943      -1
    z[2,3,1]  R944      1
    z[2,3,1]  R955      7.5533652305603027e-01
    z[2,3,1]  R956      1.5082035958766937e-01
    z[2,3,1]  R957      3.2670933008193970e-01
    z[2,3,1]  R958      -8.6420841515064240e-02
    z[2,3,1]  R959      -9.3506224453449249e-02
    z[2,3,1]  R960      -8.2904092967510223e-02
    z[2,3,1]  R961      7.6480291783809662e-02
    z[2,3,1]  R962      -4.5369766652584076e-02
    z[2,3,1]  R963      -4.7882851213216782e-02
    z[2,3,1]  R964      -1.4118745923042297e-01
    z[2,3,1]  R965      1.1222476139664650e-02
    z[2,3,1]  R966      4.5571732521057129e-01
    z[2,3,1]  R967      -4.6389934420585632e-01
    z[2,3,1]  R968      -4.7327658534049988e-01
    z[2,3,1]  R969      -4.2640617489814758e-01
    z[2,3,1]  R970      -4.0584355592727661e-01
    z[2,3,1]  R971      -0.498304545879364
    z[2,3,1]  R972      -0.765228807926178
    z[2,3,1]  R973      -4.2069500684738159e-01
    z[2,3,1]  R974      -3.6247938871383667e-01
    z[2,3,1]  R975      -5.1551681756973267e-01
    z[2,3,1]  R976      -7.5431865453720093e-01
    z[2,3,1]  R977      -4.4682428240776062e-01
    z[2,3,1]  R978      -7.0357149839401245e-01
    z[2,3,1]  R979      -6.1069816350936890e-01
    z[2,3,1]  R980      -6.9779038429260254e-01
    z[2,3,1]  R981      -0.66790372133255
    z[2,3,1]  R982      -7.9137659072875977e-01
    z[2,3,1]  R983      -6.8418294191360474e-01
    z[2,3,1]  R984      -7.2239428758621216e-01
    z[2,3,1]  R985      7.9328608512878418e-01
    z[2,3,1]  R986      7.6735401153564453e-01
    z[2,3,1]  R987      6.3840603828430176e-01
    z[2,3,1]  R988      1.1874987185001373e-01
    z[2,3,1]  R989      1.6845221817493439e-01
    z[2,3,1]  R990      1.1892323940992355e-01
    z[2,3,1]  R991      -4.9029093235731125e-02
    z[2,3,1]  R992      -2.0932072773575783e-02
    z[2,3,1]  R993      -5.1081206649541855e-02
    z[2,3,1]  R994      -4.6568468213081360e-02
    z[2,3,1]  R995      -6.5252298116683960e-01
    z[2,3,1]  R996      -6.6241371631622314e-01
    z[2,3,1]  R997      -6.3512933254241943e-01
    z[2,3,1]  R998      -5.6671643257141113e-01
    z[2,3,1]  R999      -5.8184927701950073e-01
    z[2,3,1]  R1000     -8.0940610170364380e-01
    z[2,3,1]  R1001     -5.6583595275878906e-01
    z[2,3,1]  R1002     -5.6445431709289551e-01
    z[2,3,1]  R1003     -6.2445646524429321e-01
    z[2,3,1]  R1004     -5.3245031833648682e-01
    z[2,3,1]  R1005     -7.7334809303283691e-01
    z[2,3,1]  R1006     -6.9144630432128906e-01
    z[2,3,1]  R1007     -0.743336021900177
    z[2,3,1]  R1008     -6.4037960767745972e-01
    z[2,3,1]  R1009     4.4405010342597961e-01
    z[2,3,1]  R1010     -6.9568479061126709e-01
    z[2,3,1]  R1011     0.522428035736084
    z[2,3,1]  R1012     -5.3287369012832642e-01
    z[2,3,1]  R1013     4.8844003677368164e-01
    z[2,3,1]  R1014     6.3939177989959717e-01
    z[2,3,1]  R1015     -8.4677040576934814e-01
    z[2,3,1]  R1016     -8.7058031558990479e-01
    z[2,3,1]  R1017     -8.9668089151382446e-01
    z[2,3,1]  R1018     -7.2005736827850342e-01
    z[2,3,1]  R1019     -6.7852222919464111e-01
    z[2,3,1]  R1020     0.713131844997406
    z[2,3,1]  R1021     -6.1013668775558472e-01
    z[2,3,1]  R1022     -6.1674284934997559e-01
    z[2,3,1]  R1023     6.5785801410675049e-01
    z[2,3,1]  R1024     8.5632407665252686e-01
    z[2,3,1]  R1025     6.4206200838088989e-01
    z[2,3,1]  R1026     8.7107646465301514e-01
    z[2,3,1]  R1027     -7.5011372566223145e-01
    z[2,3,1]  R1028     -8.7947982549667358e-01
    z[2,3,1]  R1029     4.7453027963638306e-01
    z[2,3,1]  R1030     -6.2827903032302856e-01
    z[2,3,1]  R1031     6.8753391504287720e-01
    z[2,3,1]  R1032     3.6887449026107788e-01
    z[2,3,1]  R1033     3.3512553572654724e-01
    z[2,3,1]  R1034     -0.559316098690033
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R945      -1
    z[2,3,2]  R946      1
    z[2,3,2]  R955      -3.1709957867860794e-02
    z[2,3,2]  R956      -1.1720193177461624e-01
    z[2,3,2]  R957      8.2046687602996826e-01
    z[2,3,2]  R958      4.8310512304306030e-01
    z[2,3,2]  R959      3.8264030218124390e-01
    z[2,3,2]  R960      3.7091696262359619e-01
    z[2,3,2]  R961      2.1323429048061371e-01
    z[2,3,2]  R962      -3.1985055655241013e-02
    z[2,3,2]  R963      -3.7263888120651245e-01
    z[2,3,2]  R964      -5.7381969690322876e-01
    z[2,3,2]  R965      -9.8400421440601349e-02
    z[2,3,2]  R966      -5.2164769172668457e-01
    z[2,3,2]  R967      -6.6140770912170410e-01
    z[2,3,2]  R968      -9.3525443226099014e-03
    z[2,3,2]  R969      -6.2786054611206055e-01
    z[2,3,2]  R970      -7.6410883665084839e-01
    z[2,3,2]  R971      -1.3354372978210449e-01
    z[2,3,2]  R972      -5.2212452888488770e-01
    z[2,3,2]  R973      2.8210720419883728e-01
    z[2,3,2]  R974      -5.5925279855728149e-01
    z[2,3,2]  R975      -0.313320517539978
    z[2,3,2]  R976      2.8686714172363281e-01
    z[2,3,2]  R977      4.6897572278976440e-01
    z[2,3,2]  R978      -4.2075714468955994e-01
    z[2,3,2]  R979      -4.1321775317192078e-01
    z[2,3,2]  R980      -1.0324368625879288e-01
    z[2,3,2]  R981      -5.2678704261779785e-02
    z[2,3,2]  R982      -2.9144442081451416e-01
    z[2,3,2]  R983      -2.6429215073585510e-01
    z[2,3,2]  R984      1.5398591756820679e-01
    z[2,3,2]  R985      2.4101685732603073e-02
    z[2,3,2]  R986      -1.2400750815868378e-01
    z[2,3,2]  R987      5.2930307388305664e-01
    z[2,3,2]  R988      5.2981162071228027e-01
    z[2,3,2]  R989      5.2514404058456421e-01
    z[2,3,2]  R990      3.1009066104888916e-01
    z[2,3,2]  R991      -4.4367730617523193e-01
    z[2,3,2]  R992      -8.0586922168731689e-01
    z[2,3,2]  R993      -7.8454381227493286e-01
    z[2,3,2]  R994      8.0022051930427551e-02
    z[2,3,2]  R995      0.0970572754740715
    z[2,3,2]  R996      0.152975931763649
    z[2,3,2]  R997      3.4097391366958618e-01
    z[2,3,2]  R998      -3.8507252931594849e-01
    z[2,3,2]  R999      -6.8089894950389862e-02
    z[2,3,2]  R1000     -2.3545506596565247e-01
    z[2,3,2]  R1001     -5.0401028245687485e-02
    z[2,3,2]  R1002     8.3726853132247925e-02
    z[2,3,2]  R1003     1.0667237639427185e-01
    z[2,3,2]  R1004     -2.7492982149124146e-01
    z[2,3,2]  R1005     -4.1653178632259369e-02
    z[2,3,2]  R1006     2.7315405011177063e-01
    z[2,3,2]  R1007     1.5096355974674225e-01
    z[2,3,2]  R1008     4.1382029652595520e-01
    z[2,3,2]  R1009     5.0347495079040527e-01
    z[2,3,2]  R1010     -9.3935750424861908e-02
    z[2,3,2]  R1011     4.3033921718597412e-01
    z[2,3,2]  R1012     -4.3597763776779175e-01
    z[2,3,2]  R1013     1.1288274079561234e-01
    z[2,3,2]  R1014     6.4795380830764771e-01
    z[2,3,2]  R1015     -2.4157375097274780e-01
    z[2,3,2]  R1016     -3.2371073961257935e-02
    z[2,3,2]  R1017     0.0947737991809845
    z[2,3,2]  R1018     -2.7153888344764709e-01
    z[2,3,2]  R1019     -5.3877639770507812e-01
    z[2,3,2]  R1020     3.5098394751548767e-01
    z[2,3,2]  R1021     -2.7506032586097717e-01
    z[2,3,2]  R1022     3.3013519644737244e-01
    z[2,3,2]  R1023     3.1272286176681519e-01
    z[2,3,2]  R1024     3.6370927095413208e-01
    z[2,3,2]  R1025     4.2421030998229980e-01
    z[2,3,2]  R1026     1.8731613457202911e-01
    z[2,3,2]  R1027     2.3560628294944763e-02
    z[2,3,2]  R1028     2.8810295462608337e-01
    z[2,3,2]  R1029     1.2663708627223969e-01
    z[2,3,2]  R1030     -3.2625325024127960e-02
    z[2,3,2]  R1031     2.0188353955745697e-02
    z[2,3,2]  R1032     4.5583987236022949e-01
    z[2,3,2]  R1033     5.1397567987442017e-01
    z[2,3,2]  R1034     0.0961170494556427
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R947      -1
    z[2,3,3]  R948      1
    z[2,3,3]  R955      2.4858303368091583e-01
    z[2,3,3]  R956      4.2554402351379395e-01
    z[2,3,3]  R957      0.0343628004193306
    z[2,3,3]  R958      -3.8013058900833130e-01
    z[2,3,3]  R959      -2.9829597473144531e-01
    z[2,3,3]  R960      -3.3759616315364838e-02
    z[2,3,3]  R961      -4.6697562932968140e-01
    z[2,3,3]  R962      -3.4522190690040588e-01
    z[2,3,3]  R963      -1.0063122212886810e-01
    z[2,3,3]  R964      -0.532974362373352
    z[2,3,3]  R965      0.795096755027771
    z[2,3,3]  R966      -6.5679289400577545e-02
    z[2,3,3]  R967      2.1196436882019043e-01
    z[2,3,3]  R968      -5.1714515686035156e-01
    z[2,3,3]  R969      -3.2441899180412292e-01
    z[2,3,3]  R970      2.2344872355461121e-01
    z[2,3,3]  R971      -2.0596009492874146e-01
    z[2,3,3]  R972      -2.5589501857757568e-01
    z[2,3,3]  R973      -2.2315208613872528e-01
    z[2,3,3]  R974      -4.5817753672599792e-01
    z[2,3,3]  R975      -1.4972835779190063e-01
    z[2,3,3]  R976      2.0119418203830719e-01
    z[2,3,3]  R977      -7.1833759546279907e-01
    z[2,3,3]  R978      7.2061540558934212e-03
    z[2,3,3]  R979      -4.4673284888267517e-01
    z[2,3,3]  R980      -6.6427075862884521e-01
    z[2,3,3]  R981      -4.9844187498092651e-01
    z[2,3,3]  R982      -3.5893306136131287e-01
    z[2,3,3]  R983      -3.5574150085449219e-01
    z[2,3,3]  R984      -1.9878847897052765e-01
    z[2,3,3]  R985      1.5139020979404449e-01
    z[2,3,3]  R986      2.9603728652000427e-01
    z[2,3,3]  R987      1.5822613239288330e-01
    z[2,3,3]  R988      2.4612200260162354e-01
    z[2,3,3]  R989      1.1945197731256485e-01
    z[2,3,3]  R990      0.0224288459867239
    z[2,3,3]  R991      -5.5111384391784668e-01
    z[2,3,3]  R992      4.6425831317901611e-01
    z[2,3,3]  R993      -4.1696190834045410e-01
    z[2,3,3]  R994      -8.2614302635192871e-01
    z[2,3,3]  R995      -4.0400597453117371e-01
    z[2,3,3]  R996      -0.0763794332742691
    z[2,3,3]  R997      -2.2706650197505951e-01
    z[2,3,3]  R998      -7.7574424445629120e-02
    z[2,3,3]  R999      -5.6893610954284668e-01
    z[2,3,3]  R1000     -3.5073789954185486e-01
    z[2,3,3]  R1001     -1.8418912589550018e-01
    z[2,3,3]  R1002     3.3512806892395020e-01
    z[2,3,3]  R1003     1.7176859080791473e-01
    z[2,3,3]  R1004     -1.3978110253810883e-01
    z[2,3,3]  R1005     -4.3832760304212570e-02
    z[2,3,3]  R1006     0.148304283618927
    z[2,3,3]  R1007     4.6387454867362976e-01
    z[2,3,3]  R1008     2.2624848783016205e-01
    z[2,3,3]  R1009     6.2244117259979248e-01
    z[2,3,3]  R1010     4.6368911862373352e-01
    z[2,3,3]  R1011     5.2992373704910278e-01
    z[2,3,3]  R1012     -3.0490031838417053e-01
    z[2,3,3]  R1013     6.3828772306442261e-01
    z[2,3,3]  R1014     5.4679099470376968e-02
    z[2,3,3]  R1015     2.2161155939102173e-01
    z[2,3,3]  R1016     1.2202896922826767e-01
    z[2,3,3]  R1017     3.0636712908744812e-01
    z[2,3,3]  R1018     -5.1346111297607422e-01
    z[2,3,3]  R1019     -0.125356987118721
    z[2,3,3]  R1020     -1.5767522156238556e-01
    z[2,3,3]  R1021     -0.00643932493403554
    z[2,3,3]  R1022     -5.5639952421188354e-01
    z[2,3,3]  R1023     2.8882962465286255e-01
    z[2,3,3]  R1024     -1.5325054526329041e-01
    z[2,3,3]  R1025     5.3501695394515991e-01
    z[2,3,3]  R1026     2.5933426618576050e-01
    z[2,3,3]  R1027     -1.9293682649731636e-02
    z[2,3,3]  R1028     -8.1855103373527527e-02
    z[2,3,3]  R1029     7.2345834970474243e-01
    z[2,3,3]  R1030     -2.1861200034618378e-01
    z[2,3,3]  R1031     1.4545749127864838e-01
    z[2,3,3]  R1032     2.9838341474533081e-01
    z[2,3,3]  R1033     2.6166230440139771e-01
    z[2,3,3]  R1034     -4.8168757557868958e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R949      -1
    z[2,3,4]  R950      1
    z[2,3,4]  R955      2.2210077941417694e-01
    z[2,3,4]  R956      0.52739018201828
    z[2,3,4]  R957      6.0279220342636108e-02
    z[2,3,4]  R958      2.4187561124563217e-02
    z[2,3,4]  R959      -0.0906379222869873
    z[2,3,4]  R960      -3.1904366612434387e-01
    z[2,3,4]  R961      -1.3254015147686005e-01
    z[2,3,4]  R962      -5.0502443313598633e-01
    z[2,3,4]  R963      -1.4713397622108459e-01
    z[2,3,4]  R964      -2.8011593222618103e-01
    z[2,3,4]  R965      -3.7752330303192139e-01
    z[2,3,4]  R966      -2.7722901105880737e-01
    z[2,3,4]  R967      -3.1362017989158630e-01
    z[2,3,4]  R968      4.6093329787254333e-01
    z[2,3,4]  R969      4.8824116587638855e-01
    z[2,3,4]  R970      5.0413936376571655e-02
    z[2,3,4]  R971      -2.4194929003715515e-01
    z[2,3,4]  R972      -6.4516708254814148e-02
    z[2,3,4]  R973      2.3263719677925110e-01
    z[2,3,4]  R974      -2.1304479241371155e-01
    z[2,3,4]  R975      2.3986525833606720e-02
    z[2,3,4]  R976      9.1045916080474854e-02
    z[2,3,4]  R977      4.5402288436889648e-02
    z[2,3,4]  R978      -1.3329149782657623e-01
    z[2,3,4]  R979      -4.3217939138412476e-01
    z[2,3,4]  R980      -2.0710915327072144e-01
    z[2,3,4]  R981      -4.0176659822463989e-01
    z[2,3,4]  R982      -3.0604231357574463e-01
    z[2,3,4]  R983      -3.3184453845024109e-01
    z[2,3,4]  R984      1.4250871725380421e-02
    z[2,3,4]  R985      -9.9260888993740082e-02
    z[2,3,4]  R986      -1.8220679461956024e-01
    z[2,3,4]  R987      1.9566479325294495e-01
    z[2,3,4]  R988      -4.1278502345085144e-01
    z[2,3,4]  R989      1.5285915136337280e-01
    z[2,3,4]  R990      2.2578676044940948e-01
    z[2,3,4]  R991      -6.1166834831237793e-01
    z[2,3,4]  R992      6.0078907757997513e-02
    z[2,3,4]  R993      -1.0044468194246292e-01
    z[2,3,4]  R994      1.9026717543601990e-01
    z[2,3,4]  R995      -0.0942695364356041
    z[2,3,4]  R996      -0.530070424079895
    z[2,3,4]  R997      0.572259247303009
    z[2,3,4]  R998      0.281680703163147
    z[2,3,4]  R999      4.8072297126054764e-02
    z[2,3,4]  R1000     1.2790170498192310e-02
    z[2,3,4]  R1001     5.2944332361221313e-01
    z[2,3,4]  R1002     5.0449732691049576e-02
    z[2,3,4]  R1003     1.2470442801713943e-01
    z[2,3,4]  R1004     -5.2881163358688354e-01
    z[2,3,4]  R1005     -6.7869938910007477e-02
    z[2,3,4]  R1006     0.330610454082489
    z[2,3,4]  R1007     -8.7898708879947662e-02
    z[2,3,4]  R1008     1.6543485224246979e-01
    z[2,3,4]  R1009     3.1123638153076172e-01
    z[2,3,4]  R1010     -1.7848348617553711e-01
    z[2,3,4]  R1011     1.1690960079431534e-01
    z[2,3,4]  R1012     1.5920451283454895e-01
    z[2,3,4]  R1013     3.0334630608558655e-01
    z[2,3,4]  R1014     0.0460958406329155
    z[2,3,4]  R1015     2.8051629662513733e-02
    z[2,3,4]  R1016     -2.2514438629150391e-01
    z[2,3,4]  R1017     4.8451088368892670e-02
    z[2,3,4]  R1018     -2.8541529178619385e-01
    z[2,3,4]  R1019     2.3641730844974518e-01
    z[2,3,4]  R1020     -4.1492116451263428e-01
    z[2,3,4]  R1021     3.7780386209487915e-01
    z[2,3,4]  R1022     3.3900007605552673e-02
    z[2,3,4]  R1023     -5.9458520263433456e-02
    z[2,3,4]  R1024     2.0541921257972717e-01
    z[2,3,4]  R1025     9.1188631951808929e-02
    z[2,3,4]  R1026     7.1426816284656525e-02
    z[2,3,4]  R1027     -1.2145414017140865e-02
    z[2,3,4]  R1028     -2.1761940419673920e-01
    z[2,3,4]  R1029     1.8333357572555542e-01
    z[2,3,4]  R1030     1.2594452500343323e-01
    z[2,3,4]  R1031     2.7962759137153625e-01
    z[2,3,4]  R1032     5.1990884542465210e-01
    z[2,3,4]  R1033     1.6360929608345032e-01
    z[2,3,4]  R1034     9.3086190521717072e-02
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R951      -1
    z[2,3,5]  R952      1
    z[2,3,5]  R955      1.9332119822502136e-01
    z[2,3,5]  R956      5.3401970863342285e-01
    z[2,3,5]  R957      -1.6601161658763885e-01
    z[2,3,5]  R958      -2.6130869984626770e-02
    z[2,3,5]  R959      3.3052659034729004e-01
    z[2,3,5]  R960      1.1951579898595810e-01
    z[2,3,5]  R961      1.1675358563661575e-01
    z[2,3,5]  R962      1.0763483494520187e-01
    z[2,3,5]  R963      -1.8017560243606567e-01
    z[2,3,5]  R964      -1.7369458079338074e-01
    z[2,3,5]  R965      -4.4999197125434875e-01
    z[2,3,5]  R966      -2.0654010772705078e-01
    z[2,3,5]  R967      2.0217722654342651e-01
    z[2,3,5]  R968      2.8861439228057861e-01
    z[2,3,5]  R969      -1.7662626504898071e-01
    z[2,3,5]  R970      -1.4387050271034241e-01
    z[2,3,5]  R971      -0.556344211101532
    z[2,3,5]  R972      1.0969237983226776e-01
    z[2,3,5]  R973      -2.7493458986282349e-01
    z[2,3,5]  R974      -9.7647741436958313e-02
    z[2,3,5]  R975      -3.8001391291618347e-01
    z[2,3,5]  R976      1.6607622802257538e-01
    z[2,3,5]  R977      -1.3904532790184021e-01
    z[2,3,5]  R978      0.0678798034787178
    z[2,3,5]  R979      -2.3103940486907959e-01
    z[2,3,5]  R980      -2.0109573379158974e-02
    z[2,3,5]  R981      -2.1075604856014252e-01
    z[2,3,5]  R982      1.0331179201602936e-01
    z[2,3,5]  R983      -2.6430118083953857e-01
    z[2,3,5]  R984      5.0883638858795166e-01
    z[2,3,5]  R985      -1.4690301613882184e-03
    z[2,3,5]  R986      7.7183679677546024e-03
    z[2,3,5]  R987      0.411602646112442
    z[2,3,5]  R988      3.0027794837951660e-01
    z[2,3,5]  R989      4.4443616271018982e-01
    z[2,3,5]  R990      7.7148318290710449e-01
    z[2,3,5]  R991      -7.3083013296127319e-02
    z[2,3,5]  R992      3.0366408824920654e-01
    z[2,3,5]  R993      1.6252642869949341e-01
    z[2,3,5]  R994      1.2806795537471771e-01
    z[2,3,5]  R995      -3.5857267677783966e-02
    z[2,3,5]  R996      0.175323948264122
    z[2,3,5]  R997      2.4659889936447144e-01
    z[2,3,5]  R998      -5.7021111249923706e-01
    z[2,3,5]  R999      -2.3316358029842377e-01
    z[2,3,5]  R1000     -7.3266260325908661e-02
    z[2,3,5]  R1001     5.0397776067256927e-02
    z[2,3,5]  R1002     4.6938300132751465e-01
    z[2,3,5]  R1003     4.2848322540521622e-02
    z[2,3,5]  R1004     -3.4131422638893127e-01
    z[2,3,5]  R1005     5.9016084671020508e-01
    z[2,3,5]  R1006     -4.1576853394508362e-01
    z[2,3,5]  R1007     -2.4785226583480835e-01
    z[2,3,5]  R1008     7.4764534831047058e-02
    z[2,3,5]  R1009     1.9420921802520752e-01
    z[2,3,5]  R1010     -3.9852684736251831e-01
    z[2,3,5]  R1011     -4.8294299840927124e-01
    z[2,3,5]  R1012     4.3299004435539246e-01
    z[2,3,5]  R1013     -4.8052871227264404e-01
    z[2,3,5]  R1014     -3.6589032411575317e-01
    z[2,3,5]  R1015     1.8955765292048454e-02
    z[2,3,5]  R1016     3.3537667989730835e-01
    z[2,3,5]  R1017     -1.8424670398235321e-01
    z[2,3,5]  R1018     -1.2360414117574692e-01
    z[2,3,5]  R1019     -2.2777855396270752e-01
    z[2,3,5]  R1020     -3.6247935891151428e-01
    z[2,3,5]  R1021     2.7795165777206421e-01
    z[2,3,5]  R1022     -1.0404511541128159e-01
    z[2,3,5]  R1023     -4.3667447566986084e-01
    z[2,3,5]  R1024     8.2699991762638092e-02
    z[2,3,5]  R1025     -2.6953813433647156e-01
    z[2,3,5]  R1026     -2.2505274415016174e-01
    z[2,3,5]  R1027     -3.7162205576896667e-01
    z[2,3,5]  R1028     -2.0590139925479889e-01
    z[2,3,5]  R1029     -3.0605033040046692e-01
    z[2,3,5]  R1030     -0.577193021774292
    z[2,3,5]  R1031     6.0814291238784790e-01
    z[2,3,5]  R1032     -1.1223967373371124e-01
    z[2,3,5]  R1033     1.0405306518077850e-01
    z[2,3,5]  R1034     -6.3074208796024323e-02
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R953      -1
    z[2,3,6]  R954      1
    z[2,3,6]  R955      5.0117647647857666e-01
    z[2,3,6]  R956      -4.4853731989860535e-01
    z[2,3,6]  R957      -3.0730417370796204e-01
    z[2,3,6]  R958      8.7859280407428741e-02
    z[2,3,6]  R959      -4.8645719885826111e-02
    z[2,3,6]  R960      -6.7843578755855560e-02
    z[2,3,6]  R961      -2.3056827485561371e-01
    z[2,3,6]  R962      1.1112280935049057e-01
    z[2,3,6]  R963      -3.7142220884561539e-02
    z[2,3,6]  R964      0.476544052362442
    z[2,3,6]  R965      -5.4714262485504150e-02
    z[2,3,6]  R966      -4.4603458046913147e-01
    z[2,3,6]  R967      1.7056821286678314e-01
    z[2,3,6]  R968      4.1587987542152405e-01
    z[2,3,6]  R969      1.8179066479206085e-01
    z[2,3,6]  R970      2.2592335939407349e-01
    z[2,3,6]  R971      2.2567810118198395e-01
    z[2,3,6]  R972      1.1582200415432453e-02
    z[2,3,6]  R973      2.9293093830347061e-02
    z[2,3,6]  R974      -5.0506293773651123e-01
    z[2,3,6]  R975      -3.0052134394645691e-01
    z[2,3,6]  R976      3.8794970512390137e-01
    z[2,3,6]  R977      1.2793380022048950e-01
    z[2,3,6]  R978      4.3868002295494080e-01
    z[2,3,6]  R979      3.8199447095394135e-02
    z[2,3,6]  R980      -6.4267016947269440e-02
    z[2,3,6]  R981      -1.1250492185354233e-01
    z[2,3,6]  R982      1.0586041212081909e-01
    z[2,3,6]  R983      -3.6997777223587036e-01
    z[2,3,6]  R984      -9.2456437647342682e-02
    z[2,3,6]  R985      1.9739234447479248e-01
    z[2,3,6]  R986      -3.0811837315559387e-01
    z[2,3,6]  R987      -2.7268251776695251e-01
    z[2,3,6]  R988      -9.2920534312725067e-02
    z[2,3,6]  R989      -2.0176212489604950e-01
    z[2,3,6]  R990      3.5325026512145996e-01
    z[2,3,6]  R991      -3.3094260096549988e-01
    z[2,3,6]  R992      1.6189102828502655e-01
    z[2,3,6]  R993      3.0460205674171448e-01
    z[2,3,6]  R994      3.9445933699607849e-01
    z[2,3,6]  R995      -1.1341780424118042e-01
    z[2,3,6]  R996      -4.6131104230880737e-01
    z[2,3,6]  R997      1.1167629063129425e-01
    z[2,3,6]  R998      2.3331305012106895e-02
    z[2,3,6]  R999      9.6927117556333542e-03
    z[2,3,6]  R1000     7.5245589017868042e-02
    z[2,3,6]  R1001     5.4382622241973877e-01
    z[2,3,6]  R1002     -5.7883268594741821e-01
    z[2,3,6]  R1003     6.7323154211044312e-01
    z[2,3,6]  R1004     -4.6804344654083252e-01
    z[2,3,6]  R1005     6.6752098500728607e-02
    z[2,3,6]  R1006     9.5703966915607452e-02
    z[2,3,6]  R1007     -3.4824347496032715e-01
    z[2,3,6]  R1008     6.4936473965644836e-02
    z[2,3,6]  R1009     -1.2131937593221664e-01
    z[2,3,6]  R1010     1.2059555947780609e-01
    z[2,3,6]  R1011     -1.1474822461605072e-01
    z[2,3,6]  R1012     -4.6841281652450562e-01
    z[2,3,6]  R1013     1.1004430055618286e-01
    z[2,3,6]  R1014     3.4700807183980942e-02
    z[2,3,6]  R1015     -0.372715562582016
    z[2,3,6]  R1016     -1.0838195681571960e-01
    z[2,3,6]  R1017     -9.5185093581676483e-02
    z[2,3,6]  R1018     2.1241450309753418e-01
    z[2,3,6]  R1019     3.3925303816795349e-01
    z[2,3,6]  R1020     -8.8744185864925385e-02
    z[2,3,6]  R1021     5.7432585954666138e-01
    z[2,3,6]  R1022     4.3185046315193176e-01
    z[2,3,6]  R1023     -4.1304412484169006e-01
    z[2,3,6]  R1024     -6.9377802312374115e-02
    z[2,3,6]  R1025     -1.8144853413105011e-01
    z[2,3,6]  R1026     -2.8613728284835815e-01
    z[2,3,6]  R1027     0.54569011926651
    z[2,3,6]  R1028     2.0884558558464050e-01
    z[2,3,6]  R1029     6.5937139093875885e-02
    z[2,3,6]  R1030     -3.9090004563331604e-01
    z[2,3,6]  R1031     -2.1658392250537872e-01
    z[2,3,6]  R1032     2.0007678866386414e-01
    z[2,3,6]  R1033     5.7898283004760742e-01
    z[2,3,6]  R1034     -5.9164726734161377e-01
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R1035     -1
    z[3,2,0]  R1036     1
    z[3,2,0]  R1049     -5.4624056816101074e-01
    z[3,2,0]  R1050     -0.424212247133255
    z[3,2,0]  R1051     7.1994647383689880e-02
    z[3,2,0]  R1052     -6.1272311210632324e-01
    z[3,2,0]  R1053     -6.4805978536605835e-01
    z[3,2,0]  R1054     -3.4386971592903137e-01
    z[3,2,0]  R1055     -8.9542247354984283e-02
    z[3,2,0]  R1056     1.1211939901113510e-01
    z[3,2,0]  R1057     -2.8060302138328552e-01
    z[3,2,0]  R1058     3.1735548377037048e-01
    z[3,2,0]  R1059     -6.1525338888168335e-01
    z[3,2,0]  R1060     -8.6321853101253510e-02
    z[3,2,0]  R1061     1.6740697622299194e-01
    z[3,2,0]  R1062     3.4569454193115234e-01
    z[3,2,0]  R1063     5.2569651603698730e-01
    z[3,2,0]  R1064     3.9396968483924866e-01
    z[3,2,0]  R1065     2.5449299812316895e-01
    z[3,2,0]  R1066     -6.4478024840354919e-02
    z[3,2,0]  R1067     -3.1391513347625732e-01
    z[3,2,0]  R1068     0.0785473957657814
    z[3,2,0]  R1069     -0.202298104763031
    z[3,2,0]  R1070     -3.6601746082305908e-01
    z[3,2,0]  R1071     1.3802783191204071e-01
    z[3,2,0]  R1072     -0.574720025062561
    z[3,2,0]  R1073     -1.1223085224628448e-01
    z[3,2,0]  R1074     -2.9490327835083008e-01
    z[3,2,0]  R1075     3.1449355185031891e-02
    z[3,2,0]  R1076     -2.7709737420082092e-02
    z[3,2,0]  R1077     -7.8968949615955353e-02
    z[3,2,0]  R1078     1.7646408081054688e-01
    z[3,2,0]  R1079     -1.8827441334724426e-01
    z[3,2,0]  R1080     -2.2635528445243835e-01
    z[3,2,0]  R1081     2.1855413913726807e-01
    z[3,2,0]  R1082     -4.7770336270332336e-02
    z[3,2,0]  R1083     1.0365481674671173e-01
    z[3,2,0]  R1084     -1.7878907918930054e-01
    z[3,2,0]  R1085     -4.6802438795566559e-02
    z[3,2,0]  R1086     -5.0883240997791290e-02
    z[3,2,0]  R1087     1.4553122222423553e-01
    z[3,2,0]  R1088     2.3893390595912933e-01
    z[3,2,0]  R1089     -8.7573036551475525e-02
    z[3,2,0]  R1090     3.5484347492456436e-02
    z[3,2,0]  R1091     -1.9336035475134850e-02
    z[3,2,0]  R1092     5.8665376156568527e-02
    z[3,2,0]  R1093     -3.2212796807289124e-01
    z[3,2,0]  R1094     2.3365199565887451e-01
    z[3,2,0]  R1095     -1.0389288514852524e-01
    z[3,2,0]  R1096     -4.9414080381393433e-01
    z[3,2,0]  R1097     -4.2689168453216553e-01
    z[3,2,0]  R1098     2.8846862912178040e-01
    z[3,2,0]  R1099     -1.6967041790485382e-01
    z[3,2,0]  R1100     -1.3388785719871521e-01
    z[3,2,0]  R1101     3.0542594194412231e-01
    z[3,2,0]  R1102     -0.77823805809021
    z[3,2,0]  R1103     -7.9751676321029663e-01
    z[3,2,0]  R1104     -8.5658162832260132e-01
    z[3,2,0]  R1105     -8.0390030145645142e-01
    z[3,2,0]  R1106     -7.7379405498504639e-01
    z[3,2,0]  R1107     -8.9063447713851929e-01
    z[3,2,0]  R1108     -1.7608661949634552e-01
    z[3,2,0]  R1109     1.0001166909933090e-01
    z[3,2,0]  R1110     4.4433104991912842e-01
    z[3,2,0]  R1111     3.6617133021354675e-01
    z[3,2,0]  R1112     1.9942130148410797e-01
    z[3,2,0]  R1113     -1.2687428295612335e-01
    z[3,2,0]  R1114     -3.5667607188224792e-01
    z[3,2,0]  R1115     -5.2196753025054932e-01
    z[3,2,0]  R1116     -2.4494828283786774e-01
    z[3,2,0]  R1117     -7.5037801265716553e-01
    z[3,2,0]  R1118     1.8949049711227417e-01
    z[3,2,0]  R1119     -6.1510574817657471e-01
    z[3,2,0]  R1120     -3.4907853603363037e-01
    z[3,2,0]  R1121     -1.6321410238742828e-01
    z[3,2,0]  R1122     -3.3627992868423462e-01
    z[3,2,0]  R1123     1.2292774766683578e-01
    z[3,2,0]  R1124     1.1723812669515610e-01
    z[3,2,0]  R1125     2.9016089439392090e-01
    z[3,2,0]  R1126     2.1073332428932190e-01
    z[3,2,0]  R1127     1.3649851083755493e-01
    z[3,2,0]  R1128     3.8373467326164246e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R1037     -1
    z[3,2,1]  R1038     1
    z[3,2,1]  R1049     7.9328608512878418e-01
    z[3,2,1]  R1050     7.6735401153564453e-01
    z[3,2,1]  R1051     6.3840603828430176e-01
    z[3,2,1]  R1052     1.1874987185001373e-01
    z[3,2,1]  R1053     1.6845221817493439e-01
    z[3,2,1]  R1054     1.1892323940992355e-01
    z[3,2,1]  R1055     -4.9029093235731125e-02
    z[3,2,1]  R1056     -2.0932072773575783e-02
    z[3,2,1]  R1057     -5.1081206649541855e-02
    z[3,2,1]  R1058     -4.6568468213081360e-02
    z[3,2,1]  R1059     -6.5252298116683960e-01
    z[3,2,1]  R1060     -6.6241371631622314e-01
    z[3,2,1]  R1061     -6.3512933254241943e-01
    z[3,2,1]  R1062     -5.6671643257141113e-01
    z[3,2,1]  R1063     -5.8184927701950073e-01
    z[3,2,1]  R1064     -8.0940610170364380e-01
    z[3,2,1]  R1065     -5.6583595275878906e-01
    z[3,2,1]  R1066     -5.6445431709289551e-01
    z[3,2,1]  R1067     -6.2445646524429321e-01
    z[3,2,1]  R1068     -5.3245031833648682e-01
    z[3,2,1]  R1069     -7.7334809303283691e-01
    z[3,2,1]  R1070     -6.9144630432128906e-01
    z[3,2,1]  R1071     -0.743336021900177
    z[3,2,1]  R1072     -6.4037960767745972e-01
    z[3,2,1]  R1073     4.4405010342597961e-01
    z[3,2,1]  R1074     -6.9568479061126709e-01
    z[3,2,1]  R1075     0.522428035736084
    z[3,2,1]  R1076     -5.3287369012832642e-01
    z[3,2,1]  R1077     4.8844003677368164e-01
    z[3,2,1]  R1078     6.3939177989959717e-01
    z[3,2,1]  R1079     -8.4677040576934814e-01
    z[3,2,1]  R1080     -8.7058031558990479e-01
    z[3,2,1]  R1081     -8.9668089151382446e-01
    z[3,2,1]  R1082     -7.2005736827850342e-01
    z[3,2,1]  R1083     -6.7852222919464111e-01
    z[3,2,1]  R1084     0.713131844997406
    z[3,2,1]  R1085     -6.1013668775558472e-01
    z[3,2,1]  R1086     -6.1674284934997559e-01
    z[3,2,1]  R1087     6.5785801410675049e-01
    z[3,2,1]  R1088     8.5632407665252686e-01
    z[3,2,1]  R1089     6.4206200838088989e-01
    z[3,2,1]  R1090     8.7107646465301514e-01
    z[3,2,1]  R1091     -7.5011372566223145e-01
    z[3,2,1]  R1092     -8.7947982549667358e-01
    z[3,2,1]  R1093     4.7453027963638306e-01
    z[3,2,1]  R1094     -6.2827903032302856e-01
    z[3,2,1]  R1095     6.8753391504287720e-01
    z[3,2,1]  R1096     3.6887449026107788e-01
    z[3,2,1]  R1097     3.3512553572654724e-01
    z[3,2,1]  R1098     -0.559316098690033
    z[3,2,1]  R1099     7.5533652305603027e-01
    z[3,2,1]  R1100     1.5082035958766937e-01
    z[3,2,1]  R1101     3.2670933008193970e-01
    z[3,2,1]  R1102     -8.6420841515064240e-02
    z[3,2,1]  R1103     -9.3506224453449249e-02
    z[3,2,1]  R1104     -8.2904092967510223e-02
    z[3,2,1]  R1105     7.6480291783809662e-02
    z[3,2,1]  R1106     -4.5369766652584076e-02
    z[3,2,1]  R1107     -4.7882851213216782e-02
    z[3,2,1]  R1108     -1.4118745923042297e-01
    z[3,2,1]  R1109     1.1222476139664650e-02
    z[3,2,1]  R1110     4.5571732521057129e-01
    z[3,2,1]  R1111     -4.6389934420585632e-01
    z[3,2,1]  R1112     -4.7327658534049988e-01
    z[3,2,1]  R1113     -4.2640617489814758e-01
    z[3,2,1]  R1114     -4.0584355592727661e-01
    z[3,2,1]  R1115     -0.498304545879364
    z[3,2,1]  R1116     -0.765228807926178
    z[3,2,1]  R1117     -4.2069500684738159e-01
    z[3,2,1]  R1118     -3.6247938871383667e-01
    z[3,2,1]  R1119     -5.1551681756973267e-01
    z[3,2,1]  R1120     -7.5431865453720093e-01
    z[3,2,1]  R1121     -4.4682428240776062e-01
    z[3,2,1]  R1122     -7.0357149839401245e-01
    z[3,2,1]  R1123     -6.1069816350936890e-01
    z[3,2,1]  R1124     -6.9779038429260254e-01
    z[3,2,1]  R1125     -0.66790372133255
    z[3,2,1]  R1126     -7.9137659072875977e-01
    z[3,2,1]  R1127     -6.8418294191360474e-01
    z[3,2,1]  R1128     -7.2239428758621216e-01
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R1039     -1
    z[3,2,2]  R1040     1
    z[3,2,2]  R1049     2.4101685732603073e-02
    z[3,2,2]  R1050     -1.2400750815868378e-01
    z[3,2,2]  R1051     5.2930307388305664e-01
    z[3,2,2]  R1052     5.2981162071228027e-01
    z[3,2,2]  R1053     5.2514404058456421e-01
    z[3,2,2]  R1054     3.1009066104888916e-01
    z[3,2,2]  R1055     -4.4367730617523193e-01
    z[3,2,2]  R1056     -8.0586922168731689e-01
    z[3,2,2]  R1057     -7.8454381227493286e-01
    z[3,2,2]  R1058     8.0022051930427551e-02
    z[3,2,2]  R1059     0.0970572754740715
    z[3,2,2]  R1060     0.152975931763649
    z[3,2,2]  R1061     3.4097391366958618e-01
    z[3,2,2]  R1062     -3.8507252931594849e-01
    z[3,2,2]  R1063     -6.8089894950389862e-02
    z[3,2,2]  R1064     -2.3545506596565247e-01
    z[3,2,2]  R1065     -5.0401028245687485e-02
    z[3,2,2]  R1066     8.3726853132247925e-02
    z[3,2,2]  R1067     1.0667237639427185e-01
    z[3,2,2]  R1068     -2.7492982149124146e-01
    z[3,2,2]  R1069     -4.1653178632259369e-02
    z[3,2,2]  R1070     2.7315405011177063e-01
    z[3,2,2]  R1071     1.5096355974674225e-01
    z[3,2,2]  R1072     4.1382029652595520e-01
    z[3,2,2]  R1073     5.0347495079040527e-01
    z[3,2,2]  R1074     -9.3935750424861908e-02
    z[3,2,2]  R1075     4.3033921718597412e-01
    z[3,2,2]  R1076     -4.3597763776779175e-01
    z[3,2,2]  R1077     1.1288274079561234e-01
    z[3,2,2]  R1078     6.4795380830764771e-01
    z[3,2,2]  R1079     -2.4157375097274780e-01
    z[3,2,2]  R1080     -3.2371073961257935e-02
    z[3,2,2]  R1081     0.0947737991809845
    z[3,2,2]  R1082     -2.7153888344764709e-01
    z[3,2,2]  R1083     -5.3877639770507812e-01
    z[3,2,2]  R1084     3.5098394751548767e-01
    z[3,2,2]  R1085     -2.7506032586097717e-01
    z[3,2,2]  R1086     3.3013519644737244e-01
    z[3,2,2]  R1087     3.1272286176681519e-01
    z[3,2,2]  R1088     3.6370927095413208e-01
    z[3,2,2]  R1089     4.2421030998229980e-01
    z[3,2,2]  R1090     1.8731613457202911e-01
    z[3,2,2]  R1091     2.3560628294944763e-02
    z[3,2,2]  R1092     2.8810295462608337e-01
    z[3,2,2]  R1093     1.2663708627223969e-01
    z[3,2,2]  R1094     -3.2625325024127960e-02
    z[3,2,2]  R1095     2.0188353955745697e-02
    z[3,2,2]  R1096     4.5583987236022949e-01
    z[3,2,2]  R1097     5.1397567987442017e-01
    z[3,2,2]  R1098     0.0961170494556427
    z[3,2,2]  R1099     -3.1709957867860794e-02
    z[3,2,2]  R1100     -1.1720193177461624e-01
    z[3,2,2]  R1101     8.2046687602996826e-01
    z[3,2,2]  R1102     4.8310512304306030e-01
    z[3,2,2]  R1103     3.8264030218124390e-01
    z[3,2,2]  R1104     3.7091696262359619e-01
    z[3,2,2]  R1105     2.1323429048061371e-01
    z[3,2,2]  R1106     -3.1985055655241013e-02
    z[3,2,2]  R1107     -3.7263888120651245e-01
    z[3,2,2]  R1108     -5.7381969690322876e-01
    z[3,2,2]  R1109     -9.8400421440601349e-02
    z[3,2,2]  R1110     -5.2164769172668457e-01
    z[3,2,2]  R1111     -6.6140770912170410e-01
    z[3,2,2]  R1112     -9.3525443226099014e-03
    z[3,2,2]  R1113     -6.2786054611206055e-01
    z[3,2,2]  R1114     -7.6410883665084839e-01
    z[3,2,2]  R1115     -1.3354372978210449e-01
    z[3,2,2]  R1116     -5.2212452888488770e-01
    z[3,2,2]  R1117     2.8210720419883728e-01
    z[3,2,2]  R1118     -5.5925279855728149e-01
    z[3,2,2]  R1119     -0.313320517539978
    z[3,2,2]  R1120     2.8686714172363281e-01
    z[3,2,2]  R1121     4.6897572278976440e-01
    z[3,2,2]  R1122     -4.2075714468955994e-01
    z[3,2,2]  R1123     -4.1321775317192078e-01
    z[3,2,2]  R1124     -1.0324368625879288e-01
    z[3,2,2]  R1125     -5.2678704261779785e-02
    z[3,2,2]  R1126     -2.9144442081451416e-01
    z[3,2,2]  R1127     -2.6429215073585510e-01
    z[3,2,2]  R1128     1.5398591756820679e-01
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R1041     -1
    z[3,2,3]  R1042     1
    z[3,2,3]  R1049     1.5139020979404449e-01
    z[3,2,3]  R1050     2.9603728652000427e-01
    z[3,2,3]  R1051     1.5822613239288330e-01
    z[3,2,3]  R1052     2.4612200260162354e-01
    z[3,2,3]  R1053     1.1945197731256485e-01
    z[3,2,3]  R1054     0.0224288459867239
    z[3,2,3]  R1055     -5.5111384391784668e-01
    z[3,2,3]  R1056     4.6425831317901611e-01
    z[3,2,3]  R1057     -4.1696190834045410e-01
    z[3,2,3]  R1058     -8.2614302635192871e-01
    z[3,2,3]  R1059     -4.0400597453117371e-01
    z[3,2,3]  R1060     -0.0763794332742691
    z[3,2,3]  R1061     -2.2706650197505951e-01
    z[3,2,3]  R1062     -7.7574424445629120e-02
    z[3,2,3]  R1063     -5.6893610954284668e-01
    z[3,2,3]  R1064     -3.5073789954185486e-01
    z[3,2,3]  R1065     -1.8418912589550018e-01
    z[3,2,3]  R1066     3.3512806892395020e-01
    z[3,2,3]  R1067     1.7176859080791473e-01
    z[3,2,3]  R1068     -1.3978110253810883e-01
    z[3,2,3]  R1069     -4.3832760304212570e-02
    z[3,2,3]  R1070     0.148304283618927
    z[3,2,3]  R1071     4.6387454867362976e-01
    z[3,2,3]  R1072     2.2624848783016205e-01
    z[3,2,3]  R1073     6.2244117259979248e-01
    z[3,2,3]  R1074     4.6368911862373352e-01
    z[3,2,3]  R1075     5.2992373704910278e-01
    z[3,2,3]  R1076     -3.0490031838417053e-01
    z[3,2,3]  R1077     6.3828772306442261e-01
    z[3,2,3]  R1078     5.4679099470376968e-02
    z[3,2,3]  R1079     2.2161155939102173e-01
    z[3,2,3]  R1080     1.2202896922826767e-01
    z[3,2,3]  R1081     3.0636712908744812e-01
    z[3,2,3]  R1082     -5.1346111297607422e-01
    z[3,2,3]  R1083     -0.125356987118721
    z[3,2,3]  R1084     -1.5767522156238556e-01
    z[3,2,3]  R1085     -0.00643932493403554
    z[3,2,3]  R1086     -5.5639952421188354e-01
    z[3,2,3]  R1087     2.8882962465286255e-01
    z[3,2,3]  R1088     -1.5325054526329041e-01
    z[3,2,3]  R1089     5.3501695394515991e-01
    z[3,2,3]  R1090     2.5933426618576050e-01
    z[3,2,3]  R1091     -1.9293682649731636e-02
    z[3,2,3]  R1092     -8.1855103373527527e-02
    z[3,2,3]  R1093     7.2345834970474243e-01
    z[3,2,3]  R1094     -2.1861200034618378e-01
    z[3,2,3]  R1095     1.4545749127864838e-01
    z[3,2,3]  R1096     2.9838341474533081e-01
    z[3,2,3]  R1097     2.6166230440139771e-01
    z[3,2,3]  R1098     -4.8168757557868958e-01
    z[3,2,3]  R1099     2.4858303368091583e-01
    z[3,2,3]  R1100     4.2554402351379395e-01
    z[3,2,3]  R1101     0.0343628004193306
    z[3,2,3]  R1102     -3.8013058900833130e-01
    z[3,2,3]  R1103     -2.9829597473144531e-01
    z[3,2,3]  R1104     -3.3759616315364838e-02
    z[3,2,3]  R1105     -4.6697562932968140e-01
    z[3,2,3]  R1106     -3.4522190690040588e-01
    z[3,2,3]  R1107     -1.0063122212886810e-01
    z[3,2,3]  R1108     -0.532974362373352
    z[3,2,3]  R1109     0.795096755027771
    z[3,2,3]  R1110     -6.5679289400577545e-02
    z[3,2,3]  R1111     2.1196436882019043e-01
    z[3,2,3]  R1112     -5.1714515686035156e-01
    z[3,2,3]  R1113     -3.2441899180412292e-01
    z[3,2,3]  R1114     2.2344872355461121e-01
    z[3,2,3]  R1115     -2.0596009492874146e-01
    z[3,2,3]  R1116     -2.5589501857757568e-01
    z[3,2,3]  R1117     -2.2315208613872528e-01
    z[3,2,3]  R1118     -4.5817753672599792e-01
    z[3,2,3]  R1119     -1.4972835779190063e-01
    z[3,2,3]  R1120     2.0119418203830719e-01
    z[3,2,3]  R1121     -7.1833759546279907e-01
    z[3,2,3]  R1122     7.2061540558934212e-03
    z[3,2,3]  R1123     -4.4673284888267517e-01
    z[3,2,3]  R1124     -6.6427075862884521e-01
    z[3,2,3]  R1125     -4.9844187498092651e-01
    z[3,2,3]  R1126     -3.5893306136131287e-01
    z[3,2,3]  R1127     -3.5574150085449219e-01
    z[3,2,3]  R1128     -1.9878847897052765e-01
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R1043     -1
    z[3,2,4]  R1044     1
    z[3,2,4]  R1049     -9.9260888993740082e-02
    z[3,2,4]  R1050     -1.8220679461956024e-01
    z[3,2,4]  R1051     1.9566479325294495e-01
    z[3,2,4]  R1052     -4.1278502345085144e-01
    z[3,2,4]  R1053     1.5285915136337280e-01
    z[3,2,4]  R1054     2.2578676044940948e-01
    z[3,2,4]  R1055     -6.1166834831237793e-01
    z[3,2,4]  R1056     6.0078907757997513e-02
    z[3,2,4]  R1057     -1.0044468194246292e-01
    z[3,2,4]  R1058     1.9026717543601990e-01
    z[3,2,4]  R1059     -0.0942695364356041
    z[3,2,4]  R1060     -0.530070424079895
    z[3,2,4]  R1061     0.572259247303009
    z[3,2,4]  R1062     0.281680703163147
    z[3,2,4]  R1063     4.8072297126054764e-02
    z[3,2,4]  R1064     1.2790170498192310e-02
    z[3,2,4]  R1065     5.2944332361221313e-01
    z[3,2,4]  R1066     5.0449732691049576e-02
    z[3,2,4]  R1067     1.2470442801713943e-01
    z[3,2,4]  R1068     -5.2881163358688354e-01
    z[3,2,4]  R1069     -6.7869938910007477e-02
    z[3,2,4]  R1070     0.330610454082489
    z[3,2,4]  R1071     -8.7898708879947662e-02
    z[3,2,4]  R1072     1.6543485224246979e-01
    z[3,2,4]  R1073     3.1123638153076172e-01
    z[3,2,4]  R1074     -1.7848348617553711e-01
    z[3,2,4]  R1075     1.1690960079431534e-01
    z[3,2,4]  R1076     1.5920451283454895e-01
    z[3,2,4]  R1077     3.0334630608558655e-01
    z[3,2,4]  R1078     0.0460958406329155
    z[3,2,4]  R1079     2.8051629662513733e-02
    z[3,2,4]  R1080     -2.2514438629150391e-01
    z[3,2,4]  R1081     4.8451088368892670e-02
    z[3,2,4]  R1082     -2.8541529178619385e-01
    z[3,2,4]  R1083     2.3641730844974518e-01
    z[3,2,4]  R1084     -4.1492116451263428e-01
    z[3,2,4]  R1085     3.7780386209487915e-01
    z[3,2,4]  R1086     3.3900007605552673e-02
    z[3,2,4]  R1087     -5.9458520263433456e-02
    z[3,2,4]  R1088     2.0541921257972717e-01
    z[3,2,4]  R1089     9.1188631951808929e-02
    z[3,2,4]  R1090     7.1426816284656525e-02
    z[3,2,4]  R1091     -1.2145414017140865e-02
    z[3,2,4]  R1092     -2.1761940419673920e-01
    z[3,2,4]  R1093     1.8333357572555542e-01
    z[3,2,4]  R1094     1.2594452500343323e-01
    z[3,2,4]  R1095     2.7962759137153625e-01
    z[3,2,4]  R1096     5.1990884542465210e-01
    z[3,2,4]  R1097     1.6360929608345032e-01
    z[3,2,4]  R1098     9.3086190521717072e-02
    z[3,2,4]  R1099     2.2210077941417694e-01
    z[3,2,4]  R1100     0.52739018201828
    z[3,2,4]  R1101     6.0279220342636108e-02
    z[3,2,4]  R1102     2.4187561124563217e-02
    z[3,2,4]  R1103     -0.0906379222869873
    z[3,2,4]  R1104     -3.1904366612434387e-01
    z[3,2,4]  R1105     -1.3254015147686005e-01
    z[3,2,4]  R1106     -5.0502443313598633e-01
    z[3,2,4]  R1107     -1.4713397622108459e-01
    z[3,2,4]  R1108     -2.8011593222618103e-01
    z[3,2,4]  R1109     -3.7752330303192139e-01
    z[3,2,4]  R1110     -2.7722901105880737e-01
    z[3,2,4]  R1111     -3.1362017989158630e-01
    z[3,2,4]  R1112     4.6093329787254333e-01
    z[3,2,4]  R1113     4.8824116587638855e-01
    z[3,2,4]  R1114     5.0413936376571655e-02
    z[3,2,4]  R1115     -2.4194929003715515e-01
    z[3,2,4]  R1116     -6.4516708254814148e-02
    z[3,2,4]  R1117     2.3263719677925110e-01
    z[3,2,4]  R1118     -2.1304479241371155e-01
    z[3,2,4]  R1119     2.3986525833606720e-02
    z[3,2,4]  R1120     9.1045916080474854e-02
    z[3,2,4]  R1121     4.5402288436889648e-02
    z[3,2,4]  R1122     -1.3329149782657623e-01
    z[3,2,4]  R1123     -4.3217939138412476e-01
    z[3,2,4]  R1124     -2.0710915327072144e-01
    z[3,2,4]  R1125     -4.0176659822463989e-01
    z[3,2,4]  R1126     -3.0604231357574463e-01
    z[3,2,4]  R1127     -3.3184453845024109e-01
    z[3,2,4]  R1128     1.4250871725380421e-02
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R1045     -1
    z[3,2,5]  R1046     1
    z[3,2,5]  R1049     -1.4690301613882184e-03
    z[3,2,5]  R1050     7.7183679677546024e-03
    z[3,2,5]  R1051     0.411602646112442
    z[3,2,5]  R1052     3.0027794837951660e-01
    z[3,2,5]  R1053     4.4443616271018982e-01
    z[3,2,5]  R1054     7.7148318290710449e-01
    z[3,2,5]  R1055     -7.3083013296127319e-02
    z[3,2,5]  R1056     3.0366408824920654e-01
    z[3,2,5]  R1057     1.6252642869949341e-01
    z[3,2,5]  R1058     1.2806795537471771e-01
    z[3,2,5]  R1059     -3.5857267677783966e-02
    z[3,2,5]  R1060     0.175323948264122
    z[3,2,5]  R1061     2.4659889936447144e-01
    z[3,2,5]  R1062     -5.7021111249923706e-01
    z[3,2,5]  R1063     -2.3316358029842377e-01
    z[3,2,5]  R1064     -7.3266260325908661e-02
    z[3,2,5]  R1065     5.0397776067256927e-02
    z[3,2,5]  R1066     4.6938300132751465e-01
    z[3,2,5]  R1067     4.2848322540521622e-02
    z[3,2,5]  R1068     -3.4131422638893127e-01
    z[3,2,5]  R1069     5.9016084671020508e-01
    z[3,2,5]  R1070     -4.1576853394508362e-01
    z[3,2,5]  R1071     -2.4785226583480835e-01
    z[3,2,5]  R1072     7.4764534831047058e-02
    z[3,2,5]  R1073     1.9420921802520752e-01
    z[3,2,5]  R1074     -3.9852684736251831e-01
    z[3,2,5]  R1075     -4.8294299840927124e-01
    z[3,2,5]  R1076     4.3299004435539246e-01
    z[3,2,5]  R1077     -4.8052871227264404e-01
    z[3,2,5]  R1078     -3.6589032411575317e-01
    z[3,2,5]  R1079     1.8955765292048454e-02
    z[3,2,5]  R1080     3.3537667989730835e-01
    z[3,2,5]  R1081     -1.8424670398235321e-01
    z[3,2,5]  R1082     -1.2360414117574692e-01
    z[3,2,5]  R1083     -2.2777855396270752e-01
    z[3,2,5]  R1084     -3.6247935891151428e-01
    z[3,2,5]  R1085     2.7795165777206421e-01
    z[3,2,5]  R1086     -1.0404511541128159e-01
    z[3,2,5]  R1087     -4.3667447566986084e-01
    z[3,2,5]  R1088     8.2699991762638092e-02
    z[3,2,5]  R1089     -2.6953813433647156e-01
    z[3,2,5]  R1090     -2.2505274415016174e-01
    z[3,2,5]  R1091     -3.7162205576896667e-01
    z[3,2,5]  R1092     -2.0590139925479889e-01
    z[3,2,5]  R1093     -3.0605033040046692e-01
    z[3,2,5]  R1094     -0.577193021774292
    z[3,2,5]  R1095     6.0814291238784790e-01
    z[3,2,5]  R1096     -1.1223967373371124e-01
    z[3,2,5]  R1097     1.0405306518077850e-01
    z[3,2,5]  R1098     -6.3074208796024323e-02
    z[3,2,5]  R1099     1.9332119822502136e-01
    z[3,2,5]  R1100     5.3401970863342285e-01
    z[3,2,5]  R1101     -1.6601161658763885e-01
    z[3,2,5]  R1102     -2.6130869984626770e-02
    z[3,2,5]  R1103     3.3052659034729004e-01
    z[3,2,5]  R1104     1.1951579898595810e-01
    z[3,2,5]  R1105     1.1675358563661575e-01
    z[3,2,5]  R1106     1.0763483494520187e-01
    z[3,2,5]  R1107     -1.8017560243606567e-01
    z[3,2,5]  R1108     -1.7369458079338074e-01
    z[3,2,5]  R1109     -4.4999197125434875e-01
    z[3,2,5]  R1110     -2.0654010772705078e-01
    z[3,2,5]  R1111     2.0217722654342651e-01
    z[3,2,5]  R1112     2.8861439228057861e-01
    z[3,2,5]  R1113     -1.7662626504898071e-01
    z[3,2,5]  R1114     -1.4387050271034241e-01
    z[3,2,5]  R1115     -0.556344211101532
    z[3,2,5]  R1116     1.0969237983226776e-01
    z[3,2,5]  R1117     -2.7493458986282349e-01
    z[3,2,5]  R1118     -9.7647741436958313e-02
    z[3,2,5]  R1119     -3.8001391291618347e-01
    z[3,2,5]  R1120     1.6607622802257538e-01
    z[3,2,5]  R1121     -1.3904532790184021e-01
    z[3,2,5]  R1122     0.0678798034787178
    z[3,2,5]  R1123     -2.3103940486907959e-01
    z[3,2,5]  R1124     -2.0109573379158974e-02
    z[3,2,5]  R1125     -2.1075604856014252e-01
    z[3,2,5]  R1126     1.0331179201602936e-01
    z[3,2,5]  R1127     -2.6430118083953857e-01
    z[3,2,5]  R1128     5.0883638858795166e-01
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R1047     -1
    z[3,2,6]  R1048     1
    z[3,2,6]  R1049     1.9739234447479248e-01
    z[3,2,6]  R1050     -3.0811837315559387e-01
    z[3,2,6]  R1051     -2.7268251776695251e-01
    z[3,2,6]  R1052     -9.2920534312725067e-02
    z[3,2,6]  R1053     -2.0176212489604950e-01
    z[3,2,6]  R1054     3.5325026512145996e-01
    z[3,2,6]  R1055     -3.3094260096549988e-01
    z[3,2,6]  R1056     1.6189102828502655e-01
    z[3,2,6]  R1057     3.0460205674171448e-01
    z[3,2,6]  R1058     3.9445933699607849e-01
    z[3,2,6]  R1059     -1.1341780424118042e-01
    z[3,2,6]  R1060     -4.6131104230880737e-01
    z[3,2,6]  R1061     1.1167629063129425e-01
    z[3,2,6]  R1062     2.3331305012106895e-02
    z[3,2,6]  R1063     9.6927117556333542e-03
    z[3,2,6]  R1064     7.5245589017868042e-02
    z[3,2,6]  R1065     5.4382622241973877e-01
    z[3,2,6]  R1066     -5.7883268594741821e-01
    z[3,2,6]  R1067     6.7323154211044312e-01
    z[3,2,6]  R1068     -4.6804344654083252e-01
    z[3,2,6]  R1069     6.6752098500728607e-02
    z[3,2,6]  R1070     9.5703966915607452e-02
    z[3,2,6]  R1071     -3.4824347496032715e-01
    z[3,2,6]  R1072     6.4936473965644836e-02
    z[3,2,6]  R1073     -1.2131937593221664e-01
    z[3,2,6]  R1074     1.2059555947780609e-01
    z[3,2,6]  R1075     -1.1474822461605072e-01
    z[3,2,6]  R1076     -4.6841281652450562e-01
    z[3,2,6]  R1077     1.1004430055618286e-01
    z[3,2,6]  R1078     3.4700807183980942e-02
    z[3,2,6]  R1079     -0.372715562582016
    z[3,2,6]  R1080     -1.0838195681571960e-01
    z[3,2,6]  R1081     -9.5185093581676483e-02
    z[3,2,6]  R1082     2.1241450309753418e-01
    z[3,2,6]  R1083     3.3925303816795349e-01
    z[3,2,6]  R1084     -8.8744185864925385e-02
    z[3,2,6]  R1085     5.7432585954666138e-01
    z[3,2,6]  R1086     4.3185046315193176e-01
    z[3,2,6]  R1087     -4.1304412484169006e-01
    z[3,2,6]  R1088     -6.9377802312374115e-02
    z[3,2,6]  R1089     -1.8144853413105011e-01
    z[3,2,6]  R1090     -2.8613728284835815e-01
    z[3,2,6]  R1091     0.54569011926651
    z[3,2,6]  R1092     2.0884558558464050e-01
    z[3,2,6]  R1093     6.5937139093875885e-02
    z[3,2,6]  R1094     -3.9090004563331604e-01
    z[3,2,6]  R1095     -2.1658392250537872e-01
    z[3,2,6]  R1096     2.0007678866386414e-01
    z[3,2,6]  R1097     5.7898283004760742e-01
    z[3,2,6]  R1098     -5.9164726734161377e-01
    z[3,2,6]  R1099     5.0117647647857666e-01
    z[3,2,6]  R1100     -4.4853731989860535e-01
    z[3,2,6]  R1101     -3.0730417370796204e-01
    z[3,2,6]  R1102     8.7859280407428741e-02
    z[3,2,6]  R1103     -4.8645719885826111e-02
    z[3,2,6]  R1104     -6.7843578755855560e-02
    z[3,2,6]  R1105     -2.3056827485561371e-01
    z[3,2,6]  R1106     1.1112280935049057e-01
    z[3,2,6]  R1107     -3.7142220884561539e-02
    z[3,2,6]  R1108     0.476544052362442
    z[3,2,6]  R1109     -5.4714262485504150e-02
    z[3,2,6]  R1110     -4.4603458046913147e-01
    z[3,2,6]  R1111     1.7056821286678314e-01
    z[3,2,6]  R1112     4.1587987542152405e-01
    z[3,2,6]  R1113     1.8179066479206085e-01
    z[3,2,6]  R1114     2.2592335939407349e-01
    z[3,2,6]  R1115     2.2567810118198395e-01
    z[3,2,6]  R1116     1.1582200415432453e-02
    z[3,2,6]  R1117     2.9293093830347061e-02
    z[3,2,6]  R1118     -5.0506293773651123e-01
    z[3,2,6]  R1119     -3.0052134394645691e-01
    z[3,2,6]  R1120     3.8794970512390137e-01
    z[3,2,6]  R1121     1.2793380022048950e-01
    z[3,2,6]  R1122     4.3868002295494080e-01
    z[3,2,6]  R1123     3.8199447095394135e-02
    z[3,2,6]  R1124     -6.4267016947269440e-02
    z[3,2,6]  R1125     -1.1250492185354233e-01
    z[3,2,6]  R1126     1.0586041212081909e-01
    z[3,2,6]  R1127     -3.6997777223587036e-01
    z[3,2,6]  R1128     -9.2456437647342682e-02
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R1129     -1
    z[3,4,0]  R1130     1
    z[3,4,0]  R1143     -5.4624056816101074e-01
    z[3,4,0]  R1144     -0.424212247133255
    z[3,4,0]  R1145     7.1994647383689880e-02
    z[3,4,0]  R1146     -6.1272311210632324e-01
    z[3,4,0]  R1147     -6.4805978536605835e-01
    z[3,4,0]  R1148     -3.4386971592903137e-01
    z[3,4,0]  R1149     -8.9542247354984283e-02
    z[3,4,0]  R1150     1.1211939901113510e-01
    z[3,4,0]  R1151     -2.8060302138328552e-01
    z[3,4,0]  R1152     3.1735548377037048e-01
    z[3,4,0]  R1153     -6.1525338888168335e-01
    z[3,4,0]  R1154     -8.6321853101253510e-02
    z[3,4,0]  R1155     1.6740697622299194e-01
    z[3,4,0]  R1156     3.4569454193115234e-01
    z[3,4,0]  R1157     5.2569651603698730e-01
    z[3,4,0]  R1158     3.9396968483924866e-01
    z[3,4,0]  R1159     2.5449299812316895e-01
    z[3,4,0]  R1160     -6.4478024840354919e-02
    z[3,4,0]  R1161     -3.1391513347625732e-01
    z[3,4,0]  R1162     0.0785473957657814
    z[3,4,0]  R1163     -0.202298104763031
    z[3,4,0]  R1164     -3.6601746082305908e-01
    z[3,4,0]  R1165     1.3802783191204071e-01
    z[3,4,0]  R1166     -0.574720025062561
    z[3,4,0]  R1167     -1.1223085224628448e-01
    z[3,4,0]  R1168     -2.9490327835083008e-01
    z[3,4,0]  R1169     3.1449355185031891e-02
    z[3,4,0]  R1170     -2.7709737420082092e-02
    z[3,4,0]  R1171     -7.8968949615955353e-02
    z[3,4,0]  R1172     1.7646408081054688e-01
    z[3,4,0]  R1173     -1.8827441334724426e-01
    z[3,4,0]  R1174     -2.2635528445243835e-01
    z[3,4,0]  R1175     2.1855413913726807e-01
    z[3,4,0]  R1176     -4.7770336270332336e-02
    z[3,4,0]  R1177     1.0365481674671173e-01
    z[3,4,0]  R1178     -1.7878907918930054e-01
    z[3,4,0]  R1179     -4.6802438795566559e-02
    z[3,4,0]  R1180     -5.0883240997791290e-02
    z[3,4,0]  R1181     1.4553122222423553e-01
    z[3,4,0]  R1182     2.3893390595912933e-01
    z[3,4,0]  R1183     -8.7573036551475525e-02
    z[3,4,0]  R1184     3.5484347492456436e-02
    z[3,4,0]  R1185     -1.9336035475134850e-02
    z[3,4,0]  R1186     5.8665376156568527e-02
    z[3,4,0]  R1187     -3.2212796807289124e-01
    z[3,4,0]  R1188     2.3365199565887451e-01
    z[3,4,0]  R1189     -1.0389288514852524e-01
    z[3,4,0]  R1190     -4.9414080381393433e-01
    z[3,4,0]  R1191     -4.2689168453216553e-01
    z[3,4,0]  R1192     2.8846862912178040e-01
    z[3,4,0]  R1193     -7.8451806306838989e-01
    z[3,4,0]  R1194     -2.3863452672958374e-01
    z[3,4,0]  R1195     -4.2138642072677612e-01
    z[3,4,0]  R1196     -2.3271121084690094e-01
    z[3,4,0]  R1197     9.3946374952793121e-02
    z[3,4,0]  R1198     -6.3066649436950684e-01
    z[3,4,0]  R1199     -2.2421675920486450e-01
    z[3,4,0]  R1200     0.221639484167099
    z[3,4,0]  R1201     2.5867444276809692e-01
    z[3,4,0]  R1202     2.9126021265983582e-01
    z[3,4,0]  R1203     3.7454894185066223e-01
    z[3,4,0]  R1204     2.7899321913719177e-01
    z[3,4,0]  R1205     3.8191944360733032e-01
    z[3,4,0]  R1206     2.9376068711280823e-01
    z[3,4,0]  R1207     -0.0978270173072815
    z[3,4,0]  R1208     -2.9137728735804558e-02
    z[3,4,0]  R1209     7.4456967413425446e-02
    z[3,4,0]  R1210     1.8401703238487244e-01
    z[3,4,0]  R1211     0.302244633436203
    z[3,4,0]  R1212     1.1519994586706161e-01
    z[3,4,0]  R1213     -3.0517500638961792e-01
    z[3,4,0]  R1214     4.6974033117294312e-01
    z[3,4,0]  R1215     4.7435140609741211e-01
    z[3,4,0]  R1216     -2.6120521128177643e-02
    z[3,4,0]  R1217     0.317367821931839
    z[3,4,0]  R1218     -1.7612075433135033e-02
    z[3,4,0]  R1219     -1.6793097555637360e-01
    z[3,4,0]  R1220     -1.0067898780107498e-01
    z[3,4,0]  R1221     -1.6538232564926147e-02
    z[3,4,0]  R1222     -1.2822266668081284e-02
    z[3,4,0]  R1223     3.6187297105789185e-01
    z[3,4,0]  R1224     2.9852783679962158e-01
    z[3,4,0]  R1225     3.7791994214057922e-01
    z[3,4,0]  R1226     -3.7840750813484192e-01
    z[3,4,0]  R1227     -2.8823024034500122e-01
    z[3,4,0]  R1228     2.5137278437614441e-01
    z[3,4,0]  R1229     3.0971741676330566e-01
    z[3,4,0]  R1230     -0.0793575644493103
    z[3,4,0]  R1231     -1.8650509417057037e-01
    z[3,4,0]  R1232     1.6907888650894165e-01
    z[3,4,0]  R1233     3.1163122504949570e-02
    z[3,4,0]  R1234     1.5796346962451935e-01
    z[3,4,0]  R1235     2.8270235657691956e-01
    z[3,4,0]  R1236     -3.6034090444445610e-03
    z[3,4,0]  R1237     -1.9155786931514740e-01
    z[3,4,0]  R1238     -1.3722683489322662e-01
    z[3,4,0]  R1239     -2.5865417718887329e-01
    z[3,4,0]  R1240     -3.6463830620050430e-02
    z[3,4,0]  R1241     7.2248607873916626e-01
    z[3,4,0]  R1242     -9.6755206584930420e-02
    z[3,4,0]  R1243     -0.223170205950737
    z[3,4,0]  R1244     -4.9366939812898636e-02
    z[3,4,0]  R1245     2.2083133459091187e-01
    z[3,4,0]  R1246     1.7553773522377014e-01
    z[3,4,0]  R1247     4.5671370625495911e-01
    z[3,4,0]  R1248     -1.8355819582939148e-01
    z[3,4,0]  R1249     -2.1551392972469330e-01
    z[3,4,0]  R1250     0.100338414311409
    z[3,4,0]  R1251     -1.9112358568236232e-03
    z[3,4,0]  R1252     -1.3800835609436035e-01
    z[3,4,0]  R1253     2.6239061355590820e-01
    z[3,4,0]  R1254     3.1615287065505981e-01
    z[3,4,0]  R1255     3.3481448888778687e-01
    z[3,4,0]  R1256     6.4860087633132935e-01
    z[3,4,0]  R1257     2.3486499488353729e-01
    z[3,4,0]  R1258     3.1915476918220520e-01
    z[3,4,0]  R1259     4.6502545475959778e-01
    z[3,4,0]  R1260     6.9791865348815918e-01
    z[3,4,0]  R1261     -2.4639932811260223e-01
    z[3,4,0]  R1262     1.2444227188825607e-01
    z[3,4,0]  R1263     0.422778844833374
    z[3,4,0]  R1264     1.8694639205932617e-01
    z[3,4,0]  R1265     0.463606595993042
    z[3,4,0]  R1266     0.695311427116394
    z[3,4,0]  R1267     7.3519617319107056e-01
    z[3,4,0]  R1268     0.730003833770752
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R1131     -1
    z[3,4,1]  R1132     1
    z[3,4,1]  R1143     7.9328608512878418e-01
    z[3,4,1]  R1144     7.6735401153564453e-01
    z[3,4,1]  R1145     6.3840603828430176e-01
    z[3,4,1]  R1146     1.1874987185001373e-01
    z[3,4,1]  R1147     1.6845221817493439e-01
    z[3,4,1]  R1148     1.1892323940992355e-01
    z[3,4,1]  R1149     -4.9029093235731125e-02
    z[3,4,1]  R1150     -2.0932072773575783e-02
    z[3,4,1]  R1151     -5.1081206649541855e-02
    z[3,4,1]  R1152     -4.6568468213081360e-02
    z[3,4,1]  R1153     -6.5252298116683960e-01
    z[3,4,1]  R1154     -6.6241371631622314e-01
    z[3,4,1]  R1155     -6.3512933254241943e-01
    z[3,4,1]  R1156     -5.6671643257141113e-01
    z[3,4,1]  R1157     -5.8184927701950073e-01
    z[3,4,1]  R1158     -8.0940610170364380e-01
    z[3,4,1]  R1159     -5.6583595275878906e-01
    z[3,4,1]  R1160     -5.6445431709289551e-01
    z[3,4,1]  R1161     -6.2445646524429321e-01
    z[3,4,1]  R1162     -5.3245031833648682e-01
    z[3,4,1]  R1163     -7.7334809303283691e-01
    z[3,4,1]  R1164     -6.9144630432128906e-01
    z[3,4,1]  R1165     -0.743336021900177
    z[3,4,1]  R1166     -6.4037960767745972e-01
    z[3,4,1]  R1167     4.4405010342597961e-01
    z[3,4,1]  R1168     -6.9568479061126709e-01
    z[3,4,1]  R1169     0.522428035736084
    z[3,4,1]  R1170     -5.3287369012832642e-01
    z[3,4,1]  R1171     4.8844003677368164e-01
    z[3,4,1]  R1172     6.3939177989959717e-01
    z[3,4,1]  R1173     -8.4677040576934814e-01
    z[3,4,1]  R1174     -8.7058031558990479e-01
    z[3,4,1]  R1175     -8.9668089151382446e-01
    z[3,4,1]  R1176     -7.2005736827850342e-01
    z[3,4,1]  R1177     -6.7852222919464111e-01
    z[3,4,1]  R1178     0.713131844997406
    z[3,4,1]  R1179     -6.1013668775558472e-01
    z[3,4,1]  R1180     -6.1674284934997559e-01
    z[3,4,1]  R1181     6.5785801410675049e-01
    z[3,4,1]  R1182     8.5632407665252686e-01
    z[3,4,1]  R1183     6.4206200838088989e-01
    z[3,4,1]  R1184     8.7107646465301514e-01
    z[3,4,1]  R1185     -7.5011372566223145e-01
    z[3,4,1]  R1186     -8.7947982549667358e-01
    z[3,4,1]  R1187     4.7453027963638306e-01
    z[3,4,1]  R1188     -6.2827903032302856e-01
    z[3,4,1]  R1189     6.8753391504287720e-01
    z[3,4,1]  R1190     3.6887449026107788e-01
    z[3,4,1]  R1191     3.3512553572654724e-01
    z[3,4,1]  R1192     -0.559316098690033
    z[3,4,1]  R1193     2.8132668137550354e-01
    z[3,4,1]  R1194     4.2940124869346619e-01
    z[3,4,1]  R1195     7.5325970537960529e-03
    z[3,4,1]  R1196     5.7901513576507568e-01
    z[3,4,1]  R1197     2.0204983651638031e-01
    z[3,4,1]  R1198     8.6046881973743439e-02
    z[3,4,1]  R1199     2.8027138113975525e-01
    z[3,4,1]  R1200     4.9292293190956116e-01
    z[3,4,1]  R1201     3.1568199396133423e-01
    z[3,4,1]  R1202     6.7493891716003418e-01
    z[3,4,1]  R1203     5.9162467718124390e-01
    z[3,4,1]  R1204     1.0954042524099350e-01
    z[3,4,1]  R1205     4.5639863610267639e-01
    z[3,4,1]  R1206     1.4886243641376495e-01
    z[3,4,1]  R1207     -7.7556276321411133e-01
    z[3,4,1]  R1208     -6.4946508407592773e-01
    z[3,4,1]  R1209     -9.1136246919631958e-01
    z[3,4,1]  R1210     -8.9713948965072632e-01
    z[3,4,1]  R1211     -5.0371998548507690e-01
    z[3,4,1]  R1212     -8.0799359083175659e-01
    z[3,4,1]  R1213     -0.572062611579895
    z[3,4,1]  R1214     -7.7519947290420532e-01
    z[3,4,1]  R1215     -0.589427649974823
    z[3,4,1]  R1216     -6.5192335844039917e-01
    z[3,4,1]  R1217     -7.6822096109390259e-01
    z[3,4,1]  R1218     -4.5647367835044861e-01
    z[3,4,1]  R1219     -4.7322675585746765e-01
    z[3,4,1]  R1220     -6.4571005105972290e-01
    z[3,4,1]  R1221     -6.9772607088088989e-01
    z[3,4,1]  R1222     -8.3203715085983276e-01
    z[3,4,1]  R1223     -5.7106351852416992e-01
    z[3,4,1]  R1224     -4.4708859920501709e-01
    z[3,4,1]  R1225     -8.0021435022354126e-01
    z[3,4,1]  R1226     -7.7876365184783936e-01
    z[3,4,1]  R1227     -7.6200026273727417e-01
    z[3,4,1]  R1228     -7.6768219470977783e-01
    z[3,4,1]  R1229     -7.3314839601516724e-01
    z[3,4,1]  R1230     7.0500272512435913e-01
    z[3,4,1]  R1231     4.0483522415161133e-01
    z[3,4,1]  R1232     -5.5599248409271240e-01
    z[3,4,1]  R1233     -6.6381967067718506e-01
    z[3,4,1]  R1234     -9.0491241216659546e-01
    z[3,4,1]  R1235     -0.619698166847229
    z[3,4,1]  R1236     -5.0538444519042969e-01
    z[3,4,1]  R1237     -8.6528658866882324e-01
    z[3,4,1]  R1238     -7.7655076980590820e-01
    z[3,4,1]  R1239     -9.0143078565597534e-01
    z[3,4,1]  R1240     -7.0040273666381836e-01
    z[3,4,1]  R1241     2.1460117772221565e-02
    z[3,4,1]  R1242     -5.5794847011566162e-01
    z[3,4,1]  R1243     -8.7596380710601807e-01
    z[3,4,1]  R1244     -9.1440171003341675e-01
    z[3,4,1]  R1245     -6.7542958259582520e-01
    z[3,4,1]  R1246     -8.2888710498809814e-01
    z[3,4,1]  R1247     -6.4825212955474854e-01
    z[3,4,1]  R1248     -7.9127651453018188e-01
    z[3,4,1]  R1249     -8.2369971275329590e-01
    z[3,4,1]  R1250     -7.7229762077331543e-01
    z[3,4,1]  R1251     -8.8891887664794922e-01
    z[3,4,1]  R1252     -8.8942545652389526e-01
    z[3,4,1]  R1253     -0.79151850938797
    z[3,4,1]  R1254     -8.1461596488952637e-01
    z[3,4,1]  R1255     -8.2109457254409790e-01
    z[3,4,1]  R1256     -1.7773827910423279e-01
    z[3,4,1]  R1257     -7.5015085935592651e-01
    z[3,4,1]  R1258     -7.3993182182312012e-01
    z[3,4,1]  R1259     1.6175159811973572e-01
    z[3,4,1]  R1260     0.035215113312006
    z[3,4,1]  R1261     -0.937619686126709
    z[3,4,1]  R1262     -8.9324432611465454e-01
    z[3,4,1]  R1263     -7.7389258146286011e-01
    z[3,4,1]  R1264     -8.1678217649459839e-01
    z[3,4,1]  R1265     -4.9182184040546417e-02
    z[3,4,1]  R1266     4.4177651405334473e-01
    z[3,4,1]  R1267     4.1015404462814331e-01
    z[3,4,1]  R1268     3.9751288294792175e-01
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R1133     -1
    z[3,4,2]  R1134     1
    z[3,4,2]  R1143     2.4101685732603073e-02
    z[3,4,2]  R1144     -1.2400750815868378e-01
    z[3,4,2]  R1145     5.2930307388305664e-01
    z[3,4,2]  R1146     5.2981162071228027e-01
    z[3,4,2]  R1147     5.2514404058456421e-01
    z[3,4,2]  R1148     3.1009066104888916e-01
    z[3,4,2]  R1149     -4.4367730617523193e-01
    z[3,4,2]  R1150     -8.0586922168731689e-01
    z[3,4,2]  R1151     -7.8454381227493286e-01
    z[3,4,2]  R1152     8.0022051930427551e-02
    z[3,4,2]  R1153     0.0970572754740715
    z[3,4,2]  R1154     0.152975931763649
    z[3,4,2]  R1155     3.4097391366958618e-01
    z[3,4,2]  R1156     -3.8507252931594849e-01
    z[3,4,2]  R1157     -6.8089894950389862e-02
    z[3,4,2]  R1158     -2.3545506596565247e-01
    z[3,4,2]  R1159     -5.0401028245687485e-02
    z[3,4,2]  R1160     8.3726853132247925e-02
    z[3,4,2]  R1161     1.0667237639427185e-01
    z[3,4,2]  R1162     -2.7492982149124146e-01
    z[3,4,2]  R1163     -4.1653178632259369e-02
    z[3,4,2]  R1164     2.7315405011177063e-01
    z[3,4,2]  R1165     1.5096355974674225e-01
    z[3,4,2]  R1166     4.1382029652595520e-01
    z[3,4,2]  R1167     5.0347495079040527e-01
    z[3,4,2]  R1168     -9.3935750424861908e-02
    z[3,4,2]  R1169     4.3033921718597412e-01
    z[3,4,2]  R1170     -4.3597763776779175e-01
    z[3,4,2]  R1171     1.1288274079561234e-01
    z[3,4,2]  R1172     6.4795380830764771e-01
    z[3,4,2]  R1173     -2.4157375097274780e-01
    z[3,4,2]  R1174     -3.2371073961257935e-02
    z[3,4,2]  R1175     0.0947737991809845
    z[3,4,2]  R1176     -2.7153888344764709e-01
    z[3,4,2]  R1177     -5.3877639770507812e-01
    z[3,4,2]  R1178     3.5098394751548767e-01
    z[3,4,2]  R1179     -2.7506032586097717e-01
    z[3,4,2]  R1180     3.3013519644737244e-01
    z[3,4,2]  R1181     3.1272286176681519e-01
    z[3,4,2]  R1182     3.6370927095413208e-01
    z[3,4,2]  R1183     4.2421030998229980e-01
    z[3,4,2]  R1184     1.8731613457202911e-01
    z[3,4,2]  R1185     2.3560628294944763e-02
    z[3,4,2]  R1186     2.8810295462608337e-01
    z[3,4,2]  R1187     1.2663708627223969e-01
    z[3,4,2]  R1188     -3.2625325024127960e-02
    z[3,4,2]  R1189     2.0188353955745697e-02
    z[3,4,2]  R1190     4.5583987236022949e-01
    z[3,4,2]  R1191     5.1397567987442017e-01
    z[3,4,2]  R1192     0.0961170494556427
    z[3,4,2]  R1193     1.2565425038337708e-01
    z[3,4,2]  R1194     -7.2990462183952332e-02
    z[3,4,2]  R1195     -1.2438035011291504e-01
    z[3,4,2]  R1196     -1.6645358502864838e-01
    z[3,4,2]  R1197     -9.1014020144939423e-02
    z[3,4,2]  R1198     0.626151442527771
    z[3,4,2]  R1199     -2.4900703132152557e-01
    z[3,4,2]  R1200     1.0611472278833389e-01
    z[3,4,2]  R1201     9.1054454445838928e-02
    z[3,4,2]  R1202     -1.5911756455898285e-01
    z[3,4,2]  R1203     3.1160160899162292e-01
    z[3,4,2]  R1204     -1.1797026731073856e-02
    z[3,4,2]  R1205     -2.3035086691379547e-01
    z[3,4,2]  R1206     8.2876391708850861e-02
    z[3,4,2]  R1207     -3.3033519983291626e-01
    z[3,4,2]  R1208     -4.6171391010284424e-01
    z[3,4,2]  R1209     -3.1455031037330627e-01
    z[3,4,2]  R1210     1.0135427117347717e-01
    z[3,4,2]  R1211     -4.3890568614006042e-01
    z[3,4,2]  R1212     0.136931911110878
    z[3,4,2]  R1213     -6.8476319313049316e-01
    z[3,4,2]  R1214     -9.9444175139069557e-03
    z[3,4,2]  R1215     -4.6268993616104126e-01
    z[3,4,2]  R1216     -5.4729342460632324e-01
    z[3,4,2]  R1217     2.4883045256137848e-01
    z[3,4,2]  R1218     -6.9945007562637329e-01
    z[3,4,2]  R1219     -8.0823624134063721e-01
    z[3,4,2]  R1220     -6.4133191108703613e-01
    z[3,4,2]  R1221     -1.8304759636521339e-02
    z[3,4,2]  R1222     2.4319043755531311e-01
    z[3,4,2]  R1223     -6.8353205919265747e-01
    z[3,4,2]  R1224     -7.9876106977462769e-01
    z[3,4,2]  R1225     6.4935930073261261e-02
    z[3,4,2]  R1226     2.7095427736639977e-02
    z[3,4,2]  R1227     -1.4205268025398254e-01
    z[3,4,2]  R1228     -9.6215203404426575e-02
    z[3,4,2]  R1229     -1.0724537819623947e-01
    z[3,4,2]  R1230     -1.6476549208164215e-02
    z[3,4,2]  R1231     -2.6660233736038208e-01
    z[3,4,2]  R1232     -7.3061013221740723e-01
    z[3,4,2]  R1233     -6.6492223739624023e-01
    z[3,4,2]  R1234     1.3585336506366730e-01
    z[3,4,2]  R1235     -5.5617189407348633e-01
    z[3,4,2]  R1236     -5.2972149848937988e-01
    z[3,4,2]  R1237     -1.8511453270912170e-01
    z[3,4,2]  R1238     -2.8458639979362488e-01
    z[3,4,2]  R1239     3.7137895822525024e-02
    z[3,4,2]  R1240     -6.5151625871658325e-01
    z[3,4,2]  R1241     -4.9594688415527344e-01
    z[3,4,2]  R1242     -5.4087972640991211e-01
    z[3,4,2]  R1243     -1.7047224566340446e-02
    z[3,4,2]  R1244     2.7067303657531738e-01
    z[3,4,2]  R1245     -2.6017594337463379e-01
    z[3,4,2]  R1246     3.2183980941772461e-01
    z[3,4,2]  R1247     -1.6664777696132660e-01
    z[3,4,2]  R1248     -2.0325869321823120e-02
    z[3,4,2]  R1249     1.1372482031583786e-01
    z[3,4,2]  R1250     -5.3918910026550293e-01
    z[3,4,2]  R1251     -2.1300375461578369e-01
    z[3,4,2]  R1252     1.8503311276435852e-01
    z[3,4,2]  R1253     -3.3325843513011932e-02
    z[3,4,2]  R1254     -3.8550995290279388e-02
    z[3,4,2]  R1255     2.6382654905319214e-01
    z[3,4,2]  R1256     -9.6111074090003967e-02
    z[3,4,2]  R1257     -1.9729016721248627e-01
    z[3,4,2]  R1258     1.6195631027221680e-01
    z[3,4,2]  R1259     -1.3061526417732239e-01
    z[3,4,2]  R1260     -4.5849704742431641e-01
    z[3,4,2]  R1261     5.3239818662405014e-02
    z[3,4,2]  R1262     -4.7729674726724625e-02
    z[3,4,2]  R1263     -9.9238239228725433e-02
    z[3,4,2]  R1264     -1.8111547827720642e-01
    z[3,4,2]  R1265     -9.2884004116058350e-03
    z[3,4,2]  R1266     0.0757242813706398
    z[3,4,2]  R1267     0.326010137796402
    z[3,4,2]  R1268     1.1096108704805374e-01
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R1135     -1
    z[3,4,3]  R1136     1
    z[3,4,3]  R1143     1.5139020979404449e-01
    z[3,4,3]  R1144     2.9603728652000427e-01
    z[3,4,3]  R1145     1.5822613239288330e-01
    z[3,4,3]  R1146     2.4612200260162354e-01
    z[3,4,3]  R1147     1.1945197731256485e-01
    z[3,4,3]  R1148     0.0224288459867239
    z[3,4,3]  R1149     -5.5111384391784668e-01
    z[3,4,3]  R1150     4.6425831317901611e-01
    z[3,4,3]  R1151     -4.1696190834045410e-01
    z[3,4,3]  R1152     -8.2614302635192871e-01
    z[3,4,3]  R1153     -4.0400597453117371e-01
    z[3,4,3]  R1154     -0.0763794332742691
    z[3,4,3]  R1155     -2.2706650197505951e-01
    z[3,4,3]  R1156     -7.7574424445629120e-02
    z[3,4,3]  R1157     -5.6893610954284668e-01
    z[3,4,3]  R1158     -3.5073789954185486e-01
    z[3,4,3]  R1159     -1.8418912589550018e-01
    z[3,4,3]  R1160     3.3512806892395020e-01
    z[3,4,3]  R1161     1.7176859080791473e-01
    z[3,4,3]  R1162     -1.3978110253810883e-01
    z[3,4,3]  R1163     -4.3832760304212570e-02
    z[3,4,3]  R1164     0.148304283618927
    z[3,4,3]  R1165     4.6387454867362976e-01
    z[3,4,3]  R1166     2.2624848783016205e-01
    z[3,4,3]  R1167     6.2244117259979248e-01
    z[3,4,3]  R1168     4.6368911862373352e-01
    z[3,4,3]  R1169     5.2992373704910278e-01
    z[3,4,3]  R1170     -3.0490031838417053e-01
    z[3,4,3]  R1171     6.3828772306442261e-01
    z[3,4,3]  R1172     5.4679099470376968e-02
    z[3,4,3]  R1173     2.2161155939102173e-01
    z[3,4,3]  R1174     1.2202896922826767e-01
    z[3,4,3]  R1175     3.0636712908744812e-01
    z[3,4,3]  R1176     -5.1346111297607422e-01
    z[3,4,3]  R1177     -0.125356987118721
    z[3,4,3]  R1178     -1.5767522156238556e-01
    z[3,4,3]  R1179     -0.00643932493403554
    z[3,4,3]  R1180     -5.5639952421188354e-01
    z[3,4,3]  R1181     2.8882962465286255e-01
    z[3,4,3]  R1182     -1.5325054526329041e-01
    z[3,4,3]  R1183     5.3501695394515991e-01
    z[3,4,3]  R1184     2.5933426618576050e-01
    z[3,4,3]  R1185     -1.9293682649731636e-02
    z[3,4,3]  R1186     -8.1855103373527527e-02
    z[3,4,3]  R1187     7.2345834970474243e-01
    z[3,4,3]  R1188     -2.1861200034618378e-01
    z[3,4,3]  R1189     1.4545749127864838e-01
    z[3,4,3]  R1190     2.9838341474533081e-01
    z[3,4,3]  R1191     2.6166230440139771e-01
    z[3,4,3]  R1192     -4.8168757557868958e-01
    z[3,4,3]  R1193     -2.8652116656303406e-01
    z[3,4,3]  R1194     3.5964247584342957e-01
    z[3,4,3]  R1195     2.0728701353073120e-01
    z[3,4,3]  R1196     -5.2693802118301392e-01
    z[3,4,3]  R1197     -6.0815256834030151e-01
    z[3,4,3]  R1198     2.3736244067549706e-02
    z[3,4,3]  R1199     3.3163344860076904e-01
    z[3,4,3]  R1200     7.7075809240341187e-01
    z[3,4,3]  R1201     8.5122185945510864e-01
    z[3,4,3]  R1202     0.625590443611145
    z[3,4,3]  R1203     6.2528085708618164e-01
    z[3,4,3]  R1204     9.3912720680236816e-01
    z[3,4,3]  R1205     6.7131775617599487e-01
    z[3,4,3]  R1206     7.4573343992233276e-01
    z[3,4,3]  R1207     -1.6835495829582214e-01
    z[3,4,3]  R1208     -1.0739649832248688e-01
    z[3,4,3]  R1209     -2.1419250965118408e-01
    z[3,4,3]  R1210     -1.6170606017112732e-01
    z[3,4,3]  R1211     -6.2765496969223022e-01
    z[3,4,3]  R1212     3.4590315818786621e-01
    z[3,4,3]  R1213     7.9685494303703308e-02
    z[3,4,3]  R1214     1.6408908367156982e-01
    z[3,4,3]  R1215     -2.7080511674284935e-02
    z[3,4,3]  R1216     -3.9443865418434143e-01
    z[3,4,3]  R1217     2.4014189839363098e-01
    z[3,4,3]  R1218     -1.2927785515785217e-01
    z[3,4,3]  R1219     0.0540459118783474
    z[3,4,3]  R1220     7.0934325456619263e-02
    z[3,4,3]  R1221     -5.7334297895431519e-01
    z[3,4,3]  R1222     2.5984886288642883e-01
    z[3,4,3]  R1223     1.1943177878856659e-01
    z[3,4,3]  R1224     -1.2809245288372040e-01
    z[3,4,3]  R1225     9.6224442124366760e-02
    z[3,4,3]  R1226     -3.6655715107917786e-01
    z[3,4,3]  R1227     0.0673820897936821
    z[3,4,3]  R1228     4.0417218208312988e-01
    z[3,4,3]  R1229     2.4162137508392334e-01
    z[3,4,3]  R1230     3.8890153169631958e-01
    z[3,4,3]  R1231     5.7501119375228882e-01
    z[3,4,3]  R1232     -2.3392596840858459e-01
    z[3,4,3]  R1233     4.7164112329483032e-02
    z[3,4,3]  R1234     1.7356034368276596e-02
    z[3,4,3]  R1235     -4.5801591873168945e-01
    z[3,4,3]  R1236     -3.3098584413528442e-01
    z[3,4,3]  R1237     -1.4017856121063232e-01
    z[3,4,3]  R1238     -4.1113600134849548e-01
    z[3,4,3]  R1239     6.7720770835876465e-02
    z[3,4,3]  R1240     -2.7207341790199280e-01
    z[3,4,3]  R1241     2.9130643606185913e-01
    z[3,4,3]  R1242     -0.48995241522789
    z[3,4,3]  R1243     0.154449462890625
    z[3,4,3]  R1244     -2.7712401747703552e-01
    z[3,4,3]  R1245     -3.0682352185249329e-01
    z[3,4,3]  R1246     -8.2297712564468384e-02
    z[3,4,3]  R1247     -3.5729256272315979e-01
    z[3,4,3]  R1248     7.8484527766704559e-02
    z[3,4,3]  R1249     -1.7783628404140472e-01
    z[3,4,3]  R1250     -8.9961253106594086e-02
    z[3,4,3]  R1251     1.8062674999237061e-01
    z[3,4,3]  R1252     -1.3411337137222290e-01
    z[3,4,3]  R1253     -5.0566357374191284e-01
    z[3,4,3]  R1254     2.0418265461921692e-01
    z[3,4,3]  R1255     5.1924187690019608e-02
    z[3,4,3]  R1256     2.6497477293014526e-01
    z[3,4,3]  R1257     -1.2366843223571777e-01
    z[3,4,3]  R1258     -2.4484993517398834e-01
    z[3,4,3]  R1259     2.2541526705026627e-02
    z[3,4,3]  R1260     3.8468053936958313e-01
    z[3,4,3]  R1261     -2.2348362207412720e-01
    z[3,4,3]  R1262     -2.5302174687385559e-01
    z[3,4,3]  R1263     2.5384664535522461e-01
    z[3,4,3]  R1264     5.5681776255369186e-02
    z[3,4,3]  R1265     5.7787474244832993e-02
    z[3,4,3]  R1266     -2.5616058707237244e-01
    z[3,4,3]  R1267     -2.4824059009552002e-01
    z[3,4,3]  R1268     -2.2069209814071655e-01
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R1137     -1
    z[3,4,4]  R1138     1
    z[3,4,4]  R1143     -9.9260888993740082e-02
    z[3,4,4]  R1144     -1.8220679461956024e-01
    z[3,4,4]  R1145     1.9566479325294495e-01
    z[3,4,4]  R1146     -4.1278502345085144e-01
    z[3,4,4]  R1147     1.5285915136337280e-01
    z[3,4,4]  R1148     2.2578676044940948e-01
    z[3,4,4]  R1149     -6.1166834831237793e-01
    z[3,4,4]  R1150     6.0078907757997513e-02
    z[3,4,4]  R1151     -1.0044468194246292e-01
    z[3,4,4]  R1152     1.9026717543601990e-01
    z[3,4,4]  R1153     -0.0942695364356041
    z[3,4,4]  R1154     -0.530070424079895
    z[3,4,4]  R1155     0.572259247303009
    z[3,4,4]  R1156     0.281680703163147
    z[3,4,4]  R1157     4.8072297126054764e-02
    z[3,4,4]  R1158     1.2790170498192310e-02
    z[3,4,4]  R1159     5.2944332361221313e-01
    z[3,4,4]  R1160     5.0449732691049576e-02
    z[3,4,4]  R1161     1.2470442801713943e-01
    z[3,4,4]  R1162     -5.2881163358688354e-01
    z[3,4,4]  R1163     -6.7869938910007477e-02
    z[3,4,4]  R1164     0.330610454082489
    z[3,4,4]  R1165     -8.7898708879947662e-02
    z[3,4,4]  R1166     1.6543485224246979e-01
    z[3,4,4]  R1167     3.1123638153076172e-01
    z[3,4,4]  R1168     -1.7848348617553711e-01
    z[3,4,4]  R1169     1.1690960079431534e-01
    z[3,4,4]  R1170     1.5920451283454895e-01
    z[3,4,4]  R1171     3.0334630608558655e-01
    z[3,4,4]  R1172     0.0460958406329155
    z[3,4,4]  R1173     2.8051629662513733e-02
    z[3,4,4]  R1174     -2.2514438629150391e-01
    z[3,4,4]  R1175     4.8451088368892670e-02
    z[3,4,4]  R1176     -2.8541529178619385e-01
    z[3,4,4]  R1177     2.3641730844974518e-01
    z[3,4,4]  R1178     -4.1492116451263428e-01
    z[3,4,4]  R1179     3.7780386209487915e-01
    z[3,4,4]  R1180     3.3900007605552673e-02
    z[3,4,4]  R1181     -5.9458520263433456e-02
    z[3,4,4]  R1182     2.0541921257972717e-01
    z[3,4,4]  R1183     9.1188631951808929e-02
    z[3,4,4]  R1184     7.1426816284656525e-02
    z[3,4,4]  R1185     -1.2145414017140865e-02
    z[3,4,4]  R1186     -2.1761940419673920e-01
    z[3,4,4]  R1187     1.8333357572555542e-01
    z[3,4,4]  R1188     1.2594452500343323e-01
    z[3,4,4]  R1189     2.7962759137153625e-01
    z[3,4,4]  R1190     5.1990884542465210e-01
    z[3,4,4]  R1191     1.6360929608345032e-01
    z[3,4,4]  R1192     9.3086190521717072e-02
    z[3,4,4]  R1193     2.0960272848606110e-01
    z[3,4,4]  R1194     -3.7107229232788086e-02
    z[3,4,4]  R1195     -7.0225065946578979e-01
    z[3,4,4]  R1196     -4.7506490349769592e-01
    z[3,4,4]  R1197     -3.6551004648208618e-01
    z[3,4,4]  R1198     -4.3038591742515564e-01
    z[3,4,4]  R1199     4.4329786300659180e-01
    z[3,4,4]  R1200     -5.3792528808116913e-02
    z[3,4,4]  R1201     -4.5282721519470215e-02
    z[3,4,4]  R1202     6.5043777227401733e-02
    z[3,4,4]  R1203     1.4205466210842133e-01
    z[3,4,4]  R1204     8.2762479782104492e-02
    z[3,4,4]  R1205     1.7623870074748993e-01
    z[3,4,4]  R1206     3.9861190319061279e-01
    z[3,4,4]  R1207     -2.0020754635334015e-01
    z[3,4,4]  R1208     -1.9458557665348053e-01
    z[3,4,4]  R1209     -8.5982456803321838e-02
    z[3,4,4]  R1210     1.6359147429466248e-01
    z[3,4,4]  R1211     1.9855398684740067e-02
    z[3,4,4]  R1212     0.178420752286911
    z[3,4,4]  R1213     2.1477924287319183e-01
    z[3,4,4]  R1214     -1.5897114574909210e-01
    z[3,4,4]  R1215     2.6159333065152168e-02
    z[3,4,4]  R1216     1.6524660587310791e-01
    z[3,4,4]  R1217     0.0753258541226387
    z[3,4,4]  R1218     3.3169826865196228e-01
    z[3,4,4]  R1219     0.0411791168153286
    z[3,4,4]  R1220     2.2157919406890869e-01
    z[3,4,4]  R1221     -4.7878913581371307e-02
    z[3,4,4]  R1222     3.7933662533760071e-01
    z[3,4,4]  R1223     -1.9451610743999481e-02
    z[3,4,4]  R1224     1.8401028215885162e-01
    z[3,4,4]  R1225     2.4931050837039948e-01
    z[3,4,4]  R1226     9.7140751779079437e-02
    z[3,4,4]  R1227     4.1627818346023560e-01
    z[3,4,4]  R1228     3.2874977588653564e-01
    z[3,4,4]  R1229     -2.6751694083213806e-01
    z[3,4,4]  R1230     4.1147032380104065e-01
    z[3,4,4]  R1231     4.1332921385765076e-01
    z[3,4,4]  R1232     4.8051834106445312e-02
    z[3,4,4]  R1233     1.0222673416137695e-01
    z[3,4,4]  R1234     -2.2699016332626343e-01
    z[3,4,4]  R1235     6.3473515212535858e-02
    z[3,4,4]  R1236     8.2612454891204834e-02
    z[3,4,4]  R1237     -2.8288796544075012e-02
    z[3,4,4]  R1238     7.2491921484470367e-02
    z[3,4,4]  R1239     9.1149166226387024e-02
    z[3,4,4]  R1240     -7.5300313532352448e-02
    z[3,4,4]  R1241     1.7393555492162704e-02
    z[3,4,4]  R1242     8.6900874972343445e-02
    z[3,4,4]  R1243     -1.9447323679924011e-01
    z[3,4,4]  R1244     1.8232997506856918e-02
    z[3,4,4]  R1245     -3.6176049709320068e-01
    z[3,4,4]  R1246     2.2238619625568390e-01
    z[3,4,4]  R1247     -9.1401286423206329e-02
    z[3,4,4]  R1248     3.6532336473464966e-01
    z[3,4,4]  R1249     1.1237250268459320e-01
    z[3,4,4]  R1250     1.1224296689033508e-01
    z[3,4,4]  R1251     7.5787985697388649e-03
    z[3,4,4]  R1252     6.4320690929889679e-02
    z[3,4,4]  R1253     -1.3239432871341705e-01
    z[3,4,4]  R1254     2.5776756927371025e-02
    z[3,4,4]  R1255     3.5215219855308533e-01
    z[3,4,4]  R1256     6.4503157138824463e-01
    z[3,4,4]  R1257     4.3805581331253052e-01
    z[3,4,4]  R1258     -1.5390609204769135e-01
    z[3,4,4]  R1259     6.7675316333770752e-01
    z[3,4,4]  R1260     -3.6997926235198975e-01
    z[3,4,4]  R1261     -6.6607259213924408e-02
    z[3,4,4]  R1262     1.2064320594072342e-01
    z[3,4,4]  R1263     2.6603901386260986e-01
    z[3,4,4]  R1264     4.8441749811172485e-01
    z[3,4,4]  R1265     7.0256847143173218e-01
    z[3,4,4]  R1266     4.4332712888717651e-01
    z[3,4,4]  R1267     3.2140663266181946e-01
    z[3,4,4]  R1268     1.5471938252449036e-01
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R1139     -1
    z[3,4,5]  R1140     1
    z[3,4,5]  R1143     -1.4690301613882184e-03
    z[3,4,5]  R1144     7.7183679677546024e-03
    z[3,4,5]  R1145     0.411602646112442
    z[3,4,5]  R1146     3.0027794837951660e-01
    z[3,4,5]  R1147     4.4443616271018982e-01
    z[3,4,5]  R1148     7.7148318290710449e-01
    z[3,4,5]  R1149     -7.3083013296127319e-02
    z[3,4,5]  R1150     3.0366408824920654e-01
    z[3,4,5]  R1151     1.6252642869949341e-01
    z[3,4,5]  R1152     1.2806795537471771e-01
    z[3,4,5]  R1153     -3.5857267677783966e-02
    z[3,4,5]  R1154     0.175323948264122
    z[3,4,5]  R1155     2.4659889936447144e-01
    z[3,4,5]  R1156     -5.7021111249923706e-01
    z[3,4,5]  R1157     -2.3316358029842377e-01
    z[3,4,5]  R1158     -7.3266260325908661e-02
    z[3,4,5]  R1159     5.0397776067256927e-02
    z[3,4,5]  R1160     4.6938300132751465e-01
    z[3,4,5]  R1161     4.2848322540521622e-02
    z[3,4,5]  R1162     -3.4131422638893127e-01
    z[3,4,5]  R1163     5.9016084671020508e-01
    z[3,4,5]  R1164     -4.1576853394508362e-01
    z[3,4,5]  R1165     -2.4785226583480835e-01
    z[3,4,5]  R1166     7.4764534831047058e-02
    z[3,4,5]  R1167     1.9420921802520752e-01
    z[3,4,5]  R1168     -3.9852684736251831e-01
    z[3,4,5]  R1169     -4.8294299840927124e-01
    z[3,4,5]  R1170     4.3299004435539246e-01
    z[3,4,5]  R1171     -4.8052871227264404e-01
    z[3,4,5]  R1172     -3.6589032411575317e-01
    z[3,4,5]  R1173     1.8955765292048454e-02
    z[3,4,5]  R1174     3.3537667989730835e-01
    z[3,4,5]  R1175     -1.8424670398235321e-01
    z[3,4,5]  R1176     -1.2360414117574692e-01
    z[3,4,5]  R1177     -2.2777855396270752e-01
    z[3,4,5]  R1178     -3.6247935891151428e-01
    z[3,4,5]  R1179     2.7795165777206421e-01
    z[3,4,5]  R1180     -1.0404511541128159e-01
    z[3,4,5]  R1181     -4.3667447566986084e-01
    z[3,4,5]  R1182     8.2699991762638092e-02
    z[3,4,5]  R1183     -2.6953813433647156e-01
    z[3,4,5]  R1184     -2.2505274415016174e-01
    z[3,4,5]  R1185     -3.7162205576896667e-01
    z[3,4,5]  R1186     -2.0590139925479889e-01
    z[3,4,5]  R1187     -3.0605033040046692e-01
    z[3,4,5]  R1188     -0.577193021774292
    z[3,4,5]  R1189     6.0814291238784790e-01
    z[3,4,5]  R1190     -1.1223967373371124e-01
    z[3,4,5]  R1191     1.0405306518077850e-01
    z[3,4,5]  R1192     -6.3074208796024323e-02
    z[3,4,5]  R1193     -2.9125988483428955e-01
    z[3,4,5]  R1194     2.8395307064056396e-01
    z[3,4,5]  R1195     3.8931244611740112e-01
    z[3,4,5]  R1196     -1.9168801605701447e-01
    z[3,4,5]  R1197     5.8619940280914307e-01
    z[3,4,5]  R1198     -2.4412751197814941e-02
    z[3,4,5]  R1199     -2.9837164282798767e-01
    z[3,4,5]  R1200     -2.8865331411361694e-01
    z[3,4,5]  R1201     1.4389933645725250e-01
    z[3,4,5]  R1202     -9.0629987418651581e-02
    z[3,4,5]  R1203     -3.2613296061754227e-02
    z[3,4,5]  R1204     -1.4074572920799255e-01
    z[3,4,5]  R1205     3.2871791720390320e-01
    z[3,4,5]  R1206     1.4860203862190247e-01
    z[3,4,5]  R1207     -4.4143116474151611e-01
    z[3,4,5]  R1208     -5.3421151638031006e-01
    z[3,4,5]  R1209     1.0798743367195129e-01
    z[3,4,5]  R1210     -2.9459038376808167e-01
    z[3,4,5]  R1211     -2.6060670614242554e-01
    z[3,4,5]  R1212     -7.2829827666282654e-02
    z[3,4,5]  R1213     -2.1018789708614349e-01
    z[3,4,5]  R1214     7.5851596891880035e-02
    z[3,4,5]  R1215     -3.5586071014404297e-01
    z[3,4,5]  R1216     -2.5549063086509705e-01
    z[3,4,5]  R1217     1.1772985756397247e-01
    z[3,4,5]  R1218     -2.9082307219505310e-01
    z[3,4,5]  R1219     -7.5395785272121429e-02
    z[3,4,5]  R1220     -2.9266867041587830e-01
    z[3,4,5]  R1221     -3.0513831973075867e-01
    z[3,4,5]  R1222     3.6092754453420639e-02
    z[3,4,5]  R1223     -0.0642428919672966
    z[3,4,5]  R1224     -1.3352457899600267e-03
    z[3,4,5]  R1225     2.5755900144577026e-01
    z[3,4,5]  R1226     -3.2464000582695007e-01
    z[3,4,5]  R1227     -0.275749534368515
    z[3,4,5]  R1228     2.5408431887626648e-01
    z[3,4,5]  R1229     -0.0939953550696373
    z[3,4,5]  R1230     -2.5288176536560059e-01
    z[3,4,5]  R1231     -2.3178742825984955e-01
    z[3,4,5]  R1232     -0.127928227186203
    z[3,4,5]  R1233     -3.0584850907325745e-01
    z[3,4,5]  R1234     -2.4475468695163727e-01
    z[3,4,5]  R1235     -6.1415430158376694e-02
    z[3,4,5]  R1236     -3.7571245431900024e-01
    z[3,4,5]  R1237     -2.3396830260753632e-01
    z[3,4,5]  R1238     -2.2887107729911804e-01
    z[3,4,5]  R1239     -2.9069520533084869e-02
    z[3,4,5]  R1240     -0.0584476999938488
    z[3,4,5]  R1241     -1.2071265280246735e-01
    z[3,4,5]  R1242     -3.0844411253929138e-01
    z[3,4,5]  R1243     -2.5860235095024109e-01
    z[3,4,5]  R1244     -2.2496019955724478e-03
    z[3,4,5]  R1245     -2.4236641824245453e-01
    z[3,4,5]  R1246     7.9531274735927582e-02
    z[3,4,5]  R1247     -4.3636941909790039e-01
    z[3,4,5]  R1248     -4.3903324007987976e-01
    z[3,4,5]  R1249     -9.9482253193855286e-02
    z[3,4,5]  R1250     -2.7293553948402405e-01
    z[3,4,5]  R1251     2.2007305920124054e-01
    z[3,4,5]  R1252     1.1336227878928185e-02
    z[3,4,5]  R1253     -1.5972651541233063e-01
    z[3,4,5]  R1254     4.2401656508445740e-01
    z[3,4,5]  R1255     1.3125570118427277e-01
    z[3,4,5]  R1256     4.9722746014595032e-02
    z[3,4,5]  R1257     -9.0187273919582367e-02
    z[3,4,5]  R1258     0.148108571767807
    z[3,4,5]  R1259     -4.6637412905693054e-01
    z[3,4,5]  R1260     -1.2660789489746094e-01
    z[3,4,5]  R1261     -2.2432606667280197e-02
    z[3,4,5]  R1262     -3.3498124685138464e-03
    z[3,4,5]  R1263     -2.0628614723682404e-01
    z[3,4,5]  R1264     -6.0372814536094666e-02
    z[3,4,5]  R1265     -5.1319307088851929e-01
    z[3,4,5]  R1266     -1.2096808850765228e-01
    z[3,4,5]  R1267     -1.0360217653214931e-02
    z[3,4,5]  R1268     1.5313176810741425e-01
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R1141     -1
    z[3,4,6]  R1142     1
    z[3,4,6]  R1143     1.9739234447479248e-01
    z[3,4,6]  R1144     -3.0811837315559387e-01
    z[3,4,6]  R1145     -2.7268251776695251e-01
    z[3,4,6]  R1146     -9.2920534312725067e-02
    z[3,4,6]  R1147     -2.0176212489604950e-01
    z[3,4,6]  R1148     3.5325026512145996e-01
    z[3,4,6]  R1149     -3.3094260096549988e-01
    z[3,4,6]  R1150     1.6189102828502655e-01
    z[3,4,6]  R1151     3.0460205674171448e-01
    z[3,4,6]  R1152     3.9445933699607849e-01
    z[3,4,6]  R1153     -1.1341780424118042e-01
    z[3,4,6]  R1154     -4.6131104230880737e-01
    z[3,4,6]  R1155     1.1167629063129425e-01
    z[3,4,6]  R1156     2.3331305012106895e-02
    z[3,4,6]  R1157     9.6927117556333542e-03
    z[3,4,6]  R1158     7.5245589017868042e-02
    z[3,4,6]  R1159     5.4382622241973877e-01
    z[3,4,6]  R1160     -5.7883268594741821e-01
    z[3,4,6]  R1161     6.7323154211044312e-01
    z[3,4,6]  R1162     -4.6804344654083252e-01
    z[3,4,6]  R1163     6.6752098500728607e-02
    z[3,4,6]  R1164     9.5703966915607452e-02
    z[3,4,6]  R1165     -3.4824347496032715e-01
    z[3,4,6]  R1166     6.4936473965644836e-02
    z[3,4,6]  R1167     -1.2131937593221664e-01
    z[3,4,6]  R1168     1.2059555947780609e-01
    z[3,4,6]  R1169     -1.1474822461605072e-01
    z[3,4,6]  R1170     -4.6841281652450562e-01
    z[3,4,6]  R1171     1.1004430055618286e-01
    z[3,4,6]  R1172     3.4700807183980942e-02
    z[3,4,6]  R1173     -0.372715562582016
    z[3,4,6]  R1174     -1.0838195681571960e-01
    z[3,4,6]  R1175     -9.5185093581676483e-02
    z[3,4,6]  R1176     2.1241450309753418e-01
    z[3,4,6]  R1177     3.3925303816795349e-01
    z[3,4,6]  R1178     -8.8744185864925385e-02
    z[3,4,6]  R1179     5.7432585954666138e-01
    z[3,4,6]  R1180     4.3185046315193176e-01
    z[3,4,6]  R1181     -4.1304412484169006e-01
    z[3,4,6]  R1182     -6.9377802312374115e-02
    z[3,4,6]  R1183     -1.8144853413105011e-01
    z[3,4,6]  R1184     -2.8613728284835815e-01
    z[3,4,6]  R1185     0.54569011926651
    z[3,4,6]  R1186     2.0884558558464050e-01
    z[3,4,6]  R1187     6.5937139093875885e-02
    z[3,4,6]  R1188     -3.9090004563331604e-01
    z[3,4,6]  R1189     -2.1658392250537872e-01
    z[3,4,6]  R1190     2.0007678866386414e-01
    z[3,4,6]  R1191     5.7898283004760742e-01
    z[3,4,6]  R1192     -5.9164726734161377e-01
    z[3,4,6]  R1193     2.8060242533683777e-01
    z[3,4,6]  R1194     -7.3620069026947021e-01
    z[3,4,6]  R1195     3.4527981281280518e-01
    z[3,4,6]  R1196     -2.0684666931629181e-01
    z[3,4,6]  R1197     3.0820357799530029e-01
    z[3,4,6]  R1198     -0.128057062625885
    z[3,4,6]  R1199     6.4315706491470337e-01
    z[3,4,6]  R1200     1.2790703773498535e-01
    z[3,4,6]  R1201     -2.7893617749214172e-01
    z[3,4,6]  R1202     1.7463859915733337e-01
    z[3,4,6]  R1203     1.9452748820185661e-02
    z[3,4,6]  R1204     -3.7492178380489349e-02
    z[3,4,6]  R1205     -5.4711066186428070e-02
    z[3,4,6]  R1206     3.8416630029678345e-01
    z[3,4,6]  R1207     0.128541499376297
    z[3,4,6]  R1208     -1.7142567038536072e-01
    z[3,4,6]  R1209     3.5137572558596730e-04
    z[3,4,6]  R1210     -1.0635446012020111e-01
    z[3,4,6]  R1211     3.9185993373394012e-03
    z[3,4,6]  R1212     -3.9791685342788696e-01
    z[3,4,6]  R1213     1.1854583024978638e-01
    z[3,4,6]  R1214     3.4693002700805664e-01
    z[3,4,6]  R1215     2.9228290915489197e-01
    z[3,4,6]  R1216     -1.6315580904483795e-01
    z[3,4,6]  R1217     4.1230472922325134e-01
    z[3,4,6]  R1218     -3.0129143595695496e-01
    z[3,4,6]  R1219     -2.9035961627960205e-01
    z[3,4,6]  R1220     1.4775559306144714e-01
    z[3,4,6]  R1221     -2.9739844799041748e-01
    z[3,4,6]  R1222     1.8891172111034393e-01
    z[3,4,6]  R1223     -2.3863962292671204e-01
    z[3,4,6]  R1224     -1.5067948400974274e-01
    z[3,4,6]  R1225     2.7361556887626648e-01
    z[3,4,6]  R1226     -2.0225435495376587e-02
    z[3,4,6]  R1227     2.4946808815002441e-01
    z[3,4,6]  R1228     4.7203049063682556e-02
    z[3,4,6]  R1229     -4.6506536006927490e-01
    z[3,4,6]  R1230     3.3451551198959351e-01
    z[3,4,6]  R1231     -4.1838163137435913e-01
    z[3,4,6]  R1232     -2.3472876846790314e-01
    z[3,4,6]  R1233     1.0016328841447830e-01
    z[3,4,6]  R1234     1.6122755408287048e-01
    z[3,4,6]  R1235     9.5639698207378387e-02
    z[3,4,6]  R1236     -4.5434826612472534e-01
    z[3,4,6]  R1237     -3.2423120737075806e-01
    z[3,4,6]  R1238     -2.6547786593437195e-01
    z[3,4,6]  R1239     -3.2465690374374390e-01
    z[3,4,6]  R1240     2.2864004597067833e-02
    z[3,4,6]  R1241     -3.6312052607536316e-01
    z[3,4,6]  R1242     -2.0985266566276550e-01
    z[3,4,6]  R1243     -2.3246988654136658e-01
    z[3,4,6]  R1244     -1.0503920912742615e-01
    z[3,4,6]  R1245     -3.7892490625381470e-01
    z[3,4,6]  R1246     3.4058490395545959e-01
    z[3,4,6]  R1247     -1.3030645251274109e-01
    z[3,4,6]  R1248     8.6043469607830048e-02
    z[3,4,6]  R1249     4.5605826377868652e-01
    z[3,4,6]  R1250     -0.087053082883358
    z[3,4,6]  R1251     -2.8867509961128235e-01
    z[3,4,6]  R1252     3.6522147059440613e-01
    z[3,4,6]  R1253     0.0693008303642273
    z[3,4,6]  R1254     1.1321227252483368e-01
    z[3,4,6]  R1255     -1.2769292108714581e-02
    z[3,4,6]  R1256     -2.2302225232124329e-01
    z[3,4,6]  R1257     3.5758644342422485e-01
    z[3,4,6]  R1258     -4.6779972314834595e-01
    z[3,4,6]  R1259     -2.5400716066360474e-01
    z[3,4,6]  R1260     -2.3589698597788811e-02
    z[3,4,6]  R1261     4.9371778964996338e-02
    z[3,4,6]  R1262     -3.2521459460258484e-01
    z[3,4,6]  R1263     1.8636316061019897e-01
    z[3,4,6]  R1264     1.5397830307483673e-01
    z[3,4,6]  R1265     1.4918014407157898e-01
    z[3,4,6]  R1266     1.9710658490657806e-01
    z[3,4,6]  R1267     -1.4122587442398071e-01
    z[3,4,6]  R1268     0.447965532541275
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R1269     -1
    z[4,3,0]  R1270     1
    z[4,3,0]  R1283     -7.8451806306838989e-01
    z[4,3,0]  R1284     -2.3863452672958374e-01
    z[4,3,0]  R1285     -4.2138642072677612e-01
    z[4,3,0]  R1286     -2.3271121084690094e-01
    z[4,3,0]  R1287     9.3946374952793121e-02
    z[4,3,0]  R1288     -6.3066649436950684e-01
    z[4,3,0]  R1289     -2.2421675920486450e-01
    z[4,3,0]  R1290     0.221639484167099
    z[4,3,0]  R1291     2.5867444276809692e-01
    z[4,3,0]  R1292     2.9126021265983582e-01
    z[4,3,0]  R1293     3.7454894185066223e-01
    z[4,3,0]  R1294     2.7899321913719177e-01
    z[4,3,0]  R1295     3.8191944360733032e-01
    z[4,3,0]  R1296     2.9376068711280823e-01
    z[4,3,0]  R1297     -0.0978270173072815
    z[4,3,0]  R1298     -2.9137728735804558e-02
    z[4,3,0]  R1299     7.4456967413425446e-02
    z[4,3,0]  R1300     1.8401703238487244e-01
    z[4,3,0]  R1301     0.302244633436203
    z[4,3,0]  R1302     1.1519994586706161e-01
    z[4,3,0]  R1303     -3.0517500638961792e-01
    z[4,3,0]  R1304     4.6974033117294312e-01
    z[4,3,0]  R1305     4.7435140609741211e-01
    z[4,3,0]  R1306     -2.6120521128177643e-02
    z[4,3,0]  R1307     0.317367821931839
    z[4,3,0]  R1308     -1.7612075433135033e-02
    z[4,3,0]  R1309     -1.6793097555637360e-01
    z[4,3,0]  R1310     -1.0067898780107498e-01
    z[4,3,0]  R1311     -1.6538232564926147e-02
    z[4,3,0]  R1312     -1.2822266668081284e-02
    z[4,3,0]  R1313     3.6187297105789185e-01
    z[4,3,0]  R1314     2.9852783679962158e-01
    z[4,3,0]  R1315     3.7791994214057922e-01
    z[4,3,0]  R1316     -3.7840750813484192e-01
    z[4,3,0]  R1317     -2.8823024034500122e-01
    z[4,3,0]  R1318     2.5137278437614441e-01
    z[4,3,0]  R1319     3.0971741676330566e-01
    z[4,3,0]  R1320     -0.0793575644493103
    z[4,3,0]  R1321     -1.8650509417057037e-01
    z[4,3,0]  R1322     1.6907888650894165e-01
    z[4,3,0]  R1323     3.1163122504949570e-02
    z[4,3,0]  R1324     1.5796346962451935e-01
    z[4,3,0]  R1325     2.8270235657691956e-01
    z[4,3,0]  R1326     -3.6034090444445610e-03
    z[4,3,0]  R1327     -1.9155786931514740e-01
    z[4,3,0]  R1328     -1.3722683489322662e-01
    z[4,3,0]  R1329     -2.5865417718887329e-01
    z[4,3,0]  R1330     -3.6463830620050430e-02
    z[4,3,0]  R1331     7.2248607873916626e-01
    z[4,3,0]  R1332     -9.6755206584930420e-02
    z[4,3,0]  R1333     -0.223170205950737
    z[4,3,0]  R1334     -4.9366939812898636e-02
    z[4,3,0]  R1335     2.2083133459091187e-01
    z[4,3,0]  R1336     1.7553773522377014e-01
    z[4,3,0]  R1337     4.5671370625495911e-01
    z[4,3,0]  R1338     -1.8355819582939148e-01
    z[4,3,0]  R1339     -2.1551392972469330e-01
    z[4,3,0]  R1340     0.100338414311409
    z[4,3,0]  R1341     -1.9112358568236232e-03
    z[4,3,0]  R1342     -1.3800835609436035e-01
    z[4,3,0]  R1343     2.6239061355590820e-01
    z[4,3,0]  R1344     3.1615287065505981e-01
    z[4,3,0]  R1345     3.3481448888778687e-01
    z[4,3,0]  R1346     6.4860087633132935e-01
    z[4,3,0]  R1347     2.3486499488353729e-01
    z[4,3,0]  R1348     3.1915476918220520e-01
    z[4,3,0]  R1349     4.6502545475959778e-01
    z[4,3,0]  R1350     6.9791865348815918e-01
    z[4,3,0]  R1351     -2.4639932811260223e-01
    z[4,3,0]  R1352     1.2444227188825607e-01
    z[4,3,0]  R1353     0.422778844833374
    z[4,3,0]  R1354     1.8694639205932617e-01
    z[4,3,0]  R1355     0.463606595993042
    z[4,3,0]  R1356     0.695311427116394
    z[4,3,0]  R1357     7.3519617319107056e-01
    z[4,3,0]  R1358     0.730003833770752
    z[4,3,0]  R1359     -5.4624056816101074e-01
    z[4,3,0]  R1360     -0.424212247133255
    z[4,3,0]  R1361     7.1994647383689880e-02
    z[4,3,0]  R1362     -6.1272311210632324e-01
    z[4,3,0]  R1363     -6.4805978536605835e-01
    z[4,3,0]  R1364     -3.4386971592903137e-01
    z[4,3,0]  R1365     -8.9542247354984283e-02
    z[4,3,0]  R1366     1.1211939901113510e-01
    z[4,3,0]  R1367     -2.8060302138328552e-01
    z[4,3,0]  R1368     3.1735548377037048e-01
    z[4,3,0]  R1369     -6.1525338888168335e-01
    z[4,3,0]  R1370     -8.6321853101253510e-02
    z[4,3,0]  R1371     1.6740697622299194e-01
    z[4,3,0]  R1372     3.4569454193115234e-01
    z[4,3,0]  R1373     5.2569651603698730e-01
    z[4,3,0]  R1374     3.9396968483924866e-01
    z[4,3,0]  R1375     2.5449299812316895e-01
    z[4,3,0]  R1376     -6.4478024840354919e-02
    z[4,3,0]  R1377     -3.1391513347625732e-01
    z[4,3,0]  R1378     0.0785473957657814
    z[4,3,0]  R1379     -0.202298104763031
    z[4,3,0]  R1380     -3.6601746082305908e-01
    z[4,3,0]  R1381     1.3802783191204071e-01
    z[4,3,0]  R1382     -0.574720025062561
    z[4,3,0]  R1383     -1.1223085224628448e-01
    z[4,3,0]  R1384     -2.9490327835083008e-01
    z[4,3,0]  R1385     3.1449355185031891e-02
    z[4,3,0]  R1386     -2.7709737420082092e-02
    z[4,3,0]  R1387     -7.8968949615955353e-02
    z[4,3,0]  R1388     1.7646408081054688e-01
    z[4,3,0]  R1389     -1.8827441334724426e-01
    z[4,3,0]  R1390     -2.2635528445243835e-01
    z[4,3,0]  R1391     2.1855413913726807e-01
    z[4,3,0]  R1392     -4.7770336270332336e-02
    z[4,3,0]  R1393     1.0365481674671173e-01
    z[4,3,0]  R1394     -1.7878907918930054e-01
    z[4,3,0]  R1395     -4.6802438795566559e-02
    z[4,3,0]  R1396     -5.0883240997791290e-02
    z[4,3,0]  R1397     1.4553122222423553e-01
    z[4,3,0]  R1398     2.3893390595912933e-01
    z[4,3,0]  R1399     -8.7573036551475525e-02
    z[4,3,0]  R1400     3.5484347492456436e-02
    z[4,3,0]  R1401     -1.9336035475134850e-02
    z[4,3,0]  R1402     5.8665376156568527e-02
    z[4,3,0]  R1403     -3.2212796807289124e-01
    z[4,3,0]  R1404     2.3365199565887451e-01
    z[4,3,0]  R1405     -1.0389288514852524e-01
    z[4,3,0]  R1406     -4.9414080381393433e-01
    z[4,3,0]  R1407     -4.2689168453216553e-01
    z[4,3,0]  R1408     2.8846862912178040e-01
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R1271     -1
    z[4,3,1]  R1272     1
    z[4,3,1]  R1283     2.8132668137550354e-01
    z[4,3,1]  R1284     4.2940124869346619e-01
    z[4,3,1]  R1285     7.5325970537960529e-03
    z[4,3,1]  R1286     5.7901513576507568e-01
    z[4,3,1]  R1287     2.0204983651638031e-01
    z[4,3,1]  R1288     8.6046881973743439e-02
    z[4,3,1]  R1289     2.8027138113975525e-01
    z[4,3,1]  R1290     4.9292293190956116e-01
    z[4,3,1]  R1291     3.1568199396133423e-01
    z[4,3,1]  R1292     6.7493891716003418e-01
    z[4,3,1]  R1293     5.9162467718124390e-01
    z[4,3,1]  R1294     1.0954042524099350e-01
    z[4,3,1]  R1295     4.5639863610267639e-01
    z[4,3,1]  R1296     1.4886243641376495e-01
    z[4,3,1]  R1297     -7.7556276321411133e-01
    z[4,3,1]  R1298     -6.4946508407592773e-01
    z[4,3,1]  R1299     -9.1136246919631958e-01
    z[4,3,1]  R1300     -8.9713948965072632e-01
    z[4,3,1]  R1301     -5.0371998548507690e-01
    z[4,3,1]  R1302     -8.0799359083175659e-01
    z[4,3,1]  R1303     -0.572062611579895
    z[4,3,1]  R1304     -7.7519947290420532e-01
    z[4,3,1]  R1305     -0.589427649974823
    z[4,3,1]  R1306     -6.5192335844039917e-01
    z[4,3,1]  R1307     -7.6822096109390259e-01
    z[4,3,1]  R1308     -4.5647367835044861e-01
    z[4,3,1]  R1309     -4.7322675585746765e-01
    z[4,3,1]  R1310     -6.4571005105972290e-01
    z[4,3,1]  R1311     -6.9772607088088989e-01
    z[4,3,1]  R1312     -8.3203715085983276e-01
    z[4,3,1]  R1313     -5.7106351852416992e-01
    z[4,3,1]  R1314     -4.4708859920501709e-01
    z[4,3,1]  R1315     -8.0021435022354126e-01
    z[4,3,1]  R1316     -7.7876365184783936e-01
    z[4,3,1]  R1317     -7.6200026273727417e-01
    z[4,3,1]  R1318     -7.6768219470977783e-01
    z[4,3,1]  R1319     -7.3314839601516724e-01
    z[4,3,1]  R1320     7.0500272512435913e-01
    z[4,3,1]  R1321     4.0483522415161133e-01
    z[4,3,1]  R1322     -5.5599248409271240e-01
    z[4,3,1]  R1323     -6.6381967067718506e-01
    z[4,3,1]  R1324     -9.0491241216659546e-01
    z[4,3,1]  R1325     -0.619698166847229
    z[4,3,1]  R1326     -5.0538444519042969e-01
    z[4,3,1]  R1327     -8.6528658866882324e-01
    z[4,3,1]  R1328     -7.7655076980590820e-01
    z[4,3,1]  R1329     -9.0143078565597534e-01
    z[4,3,1]  R1330     -7.0040273666381836e-01
    z[4,3,1]  R1331     2.1460117772221565e-02
    z[4,3,1]  R1332     -5.5794847011566162e-01
    z[4,3,1]  R1333     -8.7596380710601807e-01
    z[4,3,1]  R1334     -9.1440171003341675e-01
    z[4,3,1]  R1335     -6.7542958259582520e-01
    z[4,3,1]  R1336     -8.2888710498809814e-01
    z[4,3,1]  R1337     -6.4825212955474854e-01
    z[4,3,1]  R1338     -7.9127651453018188e-01
    z[4,3,1]  R1339     -8.2369971275329590e-01
    z[4,3,1]  R1340     -7.7229762077331543e-01
    z[4,3,1]  R1341     -8.8891887664794922e-01
    z[4,3,1]  R1342     -8.8942545652389526e-01
    z[4,3,1]  R1343     -0.79151850938797
    z[4,3,1]  R1344     -8.1461596488952637e-01
    z[4,3,1]  R1345     -8.2109457254409790e-01
    z[4,3,1]  R1346     -1.7773827910423279e-01
    z[4,3,1]  R1347     -7.5015085935592651e-01
    z[4,3,1]  R1348     -7.3993182182312012e-01
    z[4,3,1]  R1349     1.6175159811973572e-01
    z[4,3,1]  R1350     0.035215113312006
    z[4,3,1]  R1351     -0.937619686126709
    z[4,3,1]  R1352     -8.9324432611465454e-01
    z[4,3,1]  R1353     -7.7389258146286011e-01
    z[4,3,1]  R1354     -8.1678217649459839e-01
    z[4,3,1]  R1355     -4.9182184040546417e-02
    z[4,3,1]  R1356     4.4177651405334473e-01
    z[4,3,1]  R1357     4.1015404462814331e-01
    z[4,3,1]  R1358     3.9751288294792175e-01
    z[4,3,1]  R1359     7.9328608512878418e-01
    z[4,3,1]  R1360     7.6735401153564453e-01
    z[4,3,1]  R1361     6.3840603828430176e-01
    z[4,3,1]  R1362     1.1874987185001373e-01
    z[4,3,1]  R1363     1.6845221817493439e-01
    z[4,3,1]  R1364     1.1892323940992355e-01
    z[4,3,1]  R1365     -4.9029093235731125e-02
    z[4,3,1]  R1366     -2.0932072773575783e-02
    z[4,3,1]  R1367     -5.1081206649541855e-02
    z[4,3,1]  R1368     -4.6568468213081360e-02
    z[4,3,1]  R1369     -6.5252298116683960e-01
    z[4,3,1]  R1370     -6.6241371631622314e-01
    z[4,3,1]  R1371     -6.3512933254241943e-01
    z[4,3,1]  R1372     -5.6671643257141113e-01
    z[4,3,1]  R1373     -5.8184927701950073e-01
    z[4,3,1]  R1374     -8.0940610170364380e-01
    z[4,3,1]  R1375     -5.6583595275878906e-01
    z[4,3,1]  R1376     -5.6445431709289551e-01
    z[4,3,1]  R1377     -6.2445646524429321e-01
    z[4,3,1]  R1378     -5.3245031833648682e-01
    z[4,3,1]  R1379     -7.7334809303283691e-01
    z[4,3,1]  R1380     -6.9144630432128906e-01
    z[4,3,1]  R1381     -0.743336021900177
    z[4,3,1]  R1382     -6.4037960767745972e-01
    z[4,3,1]  R1383     4.4405010342597961e-01
    z[4,3,1]  R1384     -6.9568479061126709e-01
    z[4,3,1]  R1385     0.522428035736084
    z[4,3,1]  R1386     -5.3287369012832642e-01
    z[4,3,1]  R1387     4.8844003677368164e-01
    z[4,3,1]  R1388     6.3939177989959717e-01
    z[4,3,1]  R1389     -8.4677040576934814e-01
    z[4,3,1]  R1390     -8.7058031558990479e-01
    z[4,3,1]  R1391     -8.9668089151382446e-01
    z[4,3,1]  R1392     -7.2005736827850342e-01
    z[4,3,1]  R1393     -6.7852222919464111e-01
    z[4,3,1]  R1394     0.713131844997406
    z[4,3,1]  R1395     -6.1013668775558472e-01
    z[4,3,1]  R1396     -6.1674284934997559e-01
    z[4,3,1]  R1397     6.5785801410675049e-01
    z[4,3,1]  R1398     8.5632407665252686e-01
    z[4,3,1]  R1399     6.4206200838088989e-01
    z[4,3,1]  R1400     8.7107646465301514e-01
    z[4,3,1]  R1401     -7.5011372566223145e-01
    z[4,3,1]  R1402     -8.7947982549667358e-01
    z[4,3,1]  R1403     4.7453027963638306e-01
    z[4,3,1]  R1404     -6.2827903032302856e-01
    z[4,3,1]  R1405     6.8753391504287720e-01
    z[4,3,1]  R1406     3.6887449026107788e-01
    z[4,3,1]  R1407     3.3512553572654724e-01
    z[4,3,1]  R1408     -0.559316098690033
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R1273     -1
    z[4,3,2]  R1274     1
    z[4,3,2]  R1283     1.2565425038337708e-01
    z[4,3,2]  R1284     -7.2990462183952332e-02
    z[4,3,2]  R1285     -1.2438035011291504e-01
    z[4,3,2]  R1286     -1.6645358502864838e-01
    z[4,3,2]  R1287     -9.1014020144939423e-02
    z[4,3,2]  R1288     0.626151442527771
    z[4,3,2]  R1289     -2.4900703132152557e-01
    z[4,3,2]  R1290     1.0611472278833389e-01
    z[4,3,2]  R1291     9.1054454445838928e-02
    z[4,3,2]  R1292     -1.5911756455898285e-01
    z[4,3,2]  R1293     3.1160160899162292e-01
    z[4,3,2]  R1294     -1.1797026731073856e-02
    z[4,3,2]  R1295     -2.3035086691379547e-01
    z[4,3,2]  R1296     8.2876391708850861e-02
    z[4,3,2]  R1297     -3.3033519983291626e-01
    z[4,3,2]  R1298     -4.6171391010284424e-01
    z[4,3,2]  R1299     -3.1455031037330627e-01
    z[4,3,2]  R1300     1.0135427117347717e-01
    z[4,3,2]  R1301     -4.3890568614006042e-01
    z[4,3,2]  R1302     0.136931911110878
    z[4,3,2]  R1303     -6.8476319313049316e-01
    z[4,3,2]  R1304     -9.9444175139069557e-03
    z[4,3,2]  R1305     -4.6268993616104126e-01
    z[4,3,2]  R1306     -5.4729342460632324e-01
    z[4,3,2]  R1307     2.4883045256137848e-01
    z[4,3,2]  R1308     -6.9945007562637329e-01
    z[4,3,2]  R1309     -8.0823624134063721e-01
    z[4,3,2]  R1310     -6.4133191108703613e-01
    z[4,3,2]  R1311     -1.8304759636521339e-02
    z[4,3,2]  R1312     2.4319043755531311e-01
    z[4,3,2]  R1313     -6.8353205919265747e-01
    z[4,3,2]  R1314     -7.9876106977462769e-01
    z[4,3,2]  R1315     6.4935930073261261e-02
    z[4,3,2]  R1316     2.7095427736639977e-02
    z[4,3,2]  R1317     -1.4205268025398254e-01
    z[4,3,2]  R1318     -9.6215203404426575e-02
    z[4,3,2]  R1319     -1.0724537819623947e-01
    z[4,3,2]  R1320     -1.6476549208164215e-02
    z[4,3,2]  R1321     -2.6660233736038208e-01
    z[4,3,2]  R1322     -7.3061013221740723e-01
    z[4,3,2]  R1323     -6.6492223739624023e-01
    z[4,3,2]  R1324     1.3585336506366730e-01
    z[4,3,2]  R1325     -5.5617189407348633e-01
    z[4,3,2]  R1326     -5.2972149848937988e-01
    z[4,3,2]  R1327     -1.8511453270912170e-01
    z[4,3,2]  R1328     -2.8458639979362488e-01
    z[4,3,2]  R1329     3.7137895822525024e-02
    z[4,3,2]  R1330     -6.5151625871658325e-01
    z[4,3,2]  R1331     -4.9594688415527344e-01
    z[4,3,2]  R1332     -5.4087972640991211e-01
    z[4,3,2]  R1333     -1.7047224566340446e-02
    z[4,3,2]  R1334     2.7067303657531738e-01
    z[4,3,2]  R1335     -2.6017594337463379e-01
    z[4,3,2]  R1336     3.2183980941772461e-01
    z[4,3,2]  R1337     -1.6664777696132660e-01
    z[4,3,2]  R1338     -2.0325869321823120e-02
    z[4,3,2]  R1339     1.1372482031583786e-01
    z[4,3,2]  R1340     -5.3918910026550293e-01
    z[4,3,2]  R1341     -2.1300375461578369e-01
    z[4,3,2]  R1342     1.8503311276435852e-01
    z[4,3,2]  R1343     -3.3325843513011932e-02
    z[4,3,2]  R1344     -3.8550995290279388e-02
    z[4,3,2]  R1345     2.6382654905319214e-01
    z[4,3,2]  R1346     -9.6111074090003967e-02
    z[4,3,2]  R1347     -1.9729016721248627e-01
    z[4,3,2]  R1348     1.6195631027221680e-01
    z[4,3,2]  R1349     -1.3061526417732239e-01
    z[4,3,2]  R1350     -4.5849704742431641e-01
    z[4,3,2]  R1351     5.3239818662405014e-02
    z[4,3,2]  R1352     -4.7729674726724625e-02
    z[4,3,2]  R1353     -9.9238239228725433e-02
    z[4,3,2]  R1354     -1.8111547827720642e-01
    z[4,3,2]  R1355     -9.2884004116058350e-03
    z[4,3,2]  R1356     0.0757242813706398
    z[4,3,2]  R1357     0.326010137796402
    z[4,3,2]  R1358     1.1096108704805374e-01
    z[4,3,2]  R1359     2.4101685732603073e-02
    z[4,3,2]  R1360     -1.2400750815868378e-01
    z[4,3,2]  R1361     5.2930307388305664e-01
    z[4,3,2]  R1362     5.2981162071228027e-01
    z[4,3,2]  R1363     5.2514404058456421e-01
    z[4,3,2]  R1364     3.1009066104888916e-01
    z[4,3,2]  R1365     -4.4367730617523193e-01
    z[4,3,2]  R1366     -8.0586922168731689e-01
    z[4,3,2]  R1367     -7.8454381227493286e-01
    z[4,3,2]  R1368     8.0022051930427551e-02
    z[4,3,2]  R1369     0.0970572754740715
    z[4,3,2]  R1370     0.152975931763649
    z[4,3,2]  R1371     3.4097391366958618e-01
    z[4,3,2]  R1372     -3.8507252931594849e-01
    z[4,3,2]  R1373     -6.8089894950389862e-02
    z[4,3,2]  R1374     -2.3545506596565247e-01
    z[4,3,2]  R1375     -5.0401028245687485e-02
    z[4,3,2]  R1376     8.3726853132247925e-02
    z[4,3,2]  R1377     1.0667237639427185e-01
    z[4,3,2]  R1378     -2.7492982149124146e-01
    z[4,3,2]  R1379     -4.1653178632259369e-02
    z[4,3,2]  R1380     2.7315405011177063e-01
    z[4,3,2]  R1381     1.5096355974674225e-01
    z[4,3,2]  R1382     4.1382029652595520e-01
    z[4,3,2]  R1383     5.0347495079040527e-01
    z[4,3,2]  R1384     -9.3935750424861908e-02
    z[4,3,2]  R1385     4.3033921718597412e-01
    z[4,3,2]  R1386     -4.3597763776779175e-01
    z[4,3,2]  R1387     1.1288274079561234e-01
    z[4,3,2]  R1388     6.4795380830764771e-01
    z[4,3,2]  R1389     -2.4157375097274780e-01
    z[4,3,2]  R1390     -3.2371073961257935e-02
    z[4,3,2]  R1391     0.0947737991809845
    z[4,3,2]  R1392     -2.7153888344764709e-01
    z[4,3,2]  R1393     -5.3877639770507812e-01
    z[4,3,2]  R1394     3.5098394751548767e-01
    z[4,3,2]  R1395     -2.7506032586097717e-01
    z[4,3,2]  R1396     3.3013519644737244e-01
    z[4,3,2]  R1397     3.1272286176681519e-01
    z[4,3,2]  R1398     3.6370927095413208e-01
    z[4,3,2]  R1399     4.2421030998229980e-01
    z[4,3,2]  R1400     1.8731613457202911e-01
    z[4,3,2]  R1401     2.3560628294944763e-02
    z[4,3,2]  R1402     2.8810295462608337e-01
    z[4,3,2]  R1403     1.2663708627223969e-01
    z[4,3,2]  R1404     -3.2625325024127960e-02
    z[4,3,2]  R1405     2.0188353955745697e-02
    z[4,3,2]  R1406     4.5583987236022949e-01
    z[4,3,2]  R1407     5.1397567987442017e-01
    z[4,3,2]  R1408     0.0961170494556427
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R1275     -1
    z[4,3,3]  R1276     1
    z[4,3,3]  R1283     -2.8652116656303406e-01
    z[4,3,3]  R1284     3.5964247584342957e-01
    z[4,3,3]  R1285     2.0728701353073120e-01
    z[4,3,3]  R1286     -5.2693802118301392e-01
    z[4,3,3]  R1287     -6.0815256834030151e-01
    z[4,3,3]  R1288     2.3736244067549706e-02
    z[4,3,3]  R1289     3.3163344860076904e-01
    z[4,3,3]  R1290     7.7075809240341187e-01
    z[4,3,3]  R1291     8.5122185945510864e-01
    z[4,3,3]  R1292     0.625590443611145
    z[4,3,3]  R1293     6.2528085708618164e-01
    z[4,3,3]  R1294     9.3912720680236816e-01
    z[4,3,3]  R1295     6.7131775617599487e-01
    z[4,3,3]  R1296     7.4573343992233276e-01
    z[4,3,3]  R1297     -1.6835495829582214e-01
    z[4,3,3]  R1298     -1.0739649832248688e-01
    z[4,3,3]  R1299     -2.1419250965118408e-01
    z[4,3,3]  R1300     -1.6170606017112732e-01
    z[4,3,3]  R1301     -6.2765496969223022e-01
    z[4,3,3]  R1302     3.4590315818786621e-01
    z[4,3,3]  R1303     7.9685494303703308e-02
    z[4,3,3]  R1304     1.6408908367156982e-01
    z[4,3,3]  R1305     -2.7080511674284935e-02
    z[4,3,3]  R1306     -3.9443865418434143e-01
    z[4,3,3]  R1307     2.4014189839363098e-01
    z[4,3,3]  R1308     -1.2927785515785217e-01
    z[4,3,3]  R1309     0.0540459118783474
    z[4,3,3]  R1310     7.0934325456619263e-02
    z[4,3,3]  R1311     -5.7334297895431519e-01
    z[4,3,3]  R1312     2.5984886288642883e-01
    z[4,3,3]  R1313     1.1943177878856659e-01
    z[4,3,3]  R1314     -1.2809245288372040e-01
    z[4,3,3]  R1315     9.6224442124366760e-02
    z[4,3,3]  R1316     -3.6655715107917786e-01
    z[4,3,3]  R1317     0.0673820897936821
    z[4,3,3]  R1318     4.0417218208312988e-01
    z[4,3,3]  R1319     2.4162137508392334e-01
    z[4,3,3]  R1320     3.8890153169631958e-01
    z[4,3,3]  R1321     5.7501119375228882e-01
    z[4,3,3]  R1322     -2.3392596840858459e-01
    z[4,3,3]  R1323     4.7164112329483032e-02
    z[4,3,3]  R1324     1.7356034368276596e-02
    z[4,3,3]  R1325     -4.5801591873168945e-01
    z[4,3,3]  R1326     -3.3098584413528442e-01
    z[4,3,3]  R1327     -1.4017856121063232e-01
    z[4,3,3]  R1328     -4.1113600134849548e-01
    z[4,3,3]  R1329     6.7720770835876465e-02
    z[4,3,3]  R1330     -2.7207341790199280e-01
    z[4,3,3]  R1331     2.9130643606185913e-01
    z[4,3,3]  R1332     -0.48995241522789
    z[4,3,3]  R1333     0.154449462890625
    z[4,3,3]  R1334     -2.7712401747703552e-01
    z[4,3,3]  R1335     -3.0682352185249329e-01
    z[4,3,3]  R1336     -8.2297712564468384e-02
    z[4,3,3]  R1337     -3.5729256272315979e-01
    z[4,3,3]  R1338     7.8484527766704559e-02
    z[4,3,3]  R1339     -1.7783628404140472e-01
    z[4,3,3]  R1340     -8.9961253106594086e-02
    z[4,3,3]  R1341     1.8062674999237061e-01
    z[4,3,3]  R1342     -1.3411337137222290e-01
    z[4,3,3]  R1343     -5.0566357374191284e-01
    z[4,3,3]  R1344     2.0418265461921692e-01
    z[4,3,3]  R1345     5.1924187690019608e-02
    z[4,3,3]  R1346     2.6497477293014526e-01
    z[4,3,3]  R1347     -1.2366843223571777e-01
    z[4,3,3]  R1348     -2.4484993517398834e-01
    z[4,3,3]  R1349     2.2541526705026627e-02
    z[4,3,3]  R1350     3.8468053936958313e-01
    z[4,3,3]  R1351     -2.2348362207412720e-01
    z[4,3,3]  R1352     -2.5302174687385559e-01
    z[4,3,3]  R1353     2.5384664535522461e-01
    z[4,3,3]  R1354     5.5681776255369186e-02
    z[4,3,3]  R1355     5.7787474244832993e-02
    z[4,3,3]  R1356     -2.5616058707237244e-01
    z[4,3,3]  R1357     -2.4824059009552002e-01
    z[4,3,3]  R1358     -2.2069209814071655e-01
    z[4,3,3]  R1359     1.5139020979404449e-01
    z[4,3,3]  R1360     2.9603728652000427e-01
    z[4,3,3]  R1361     1.5822613239288330e-01
    z[4,3,3]  R1362     2.4612200260162354e-01
    z[4,3,3]  R1363     1.1945197731256485e-01
    z[4,3,3]  R1364     0.0224288459867239
    z[4,3,3]  R1365     -5.5111384391784668e-01
    z[4,3,3]  R1366     4.6425831317901611e-01
    z[4,3,3]  R1367     -4.1696190834045410e-01
    z[4,3,3]  R1368     -8.2614302635192871e-01
    z[4,3,3]  R1369     -4.0400597453117371e-01
    z[4,3,3]  R1370     -0.0763794332742691
    z[4,3,3]  R1371     -2.2706650197505951e-01
    z[4,3,3]  R1372     -7.7574424445629120e-02
    z[4,3,3]  R1373     -5.6893610954284668e-01
    z[4,3,3]  R1374     -3.5073789954185486e-01
    z[4,3,3]  R1375     -1.8418912589550018e-01
    z[4,3,3]  R1376     3.3512806892395020e-01
    z[4,3,3]  R1377     1.7176859080791473e-01
    z[4,3,3]  R1378     -1.3978110253810883e-01
    z[4,3,3]  R1379     -4.3832760304212570e-02
    z[4,3,3]  R1380     0.148304283618927
    z[4,3,3]  R1381     4.6387454867362976e-01
    z[4,3,3]  R1382     2.2624848783016205e-01
    z[4,3,3]  R1383     6.2244117259979248e-01
    z[4,3,3]  R1384     4.6368911862373352e-01
    z[4,3,3]  R1385     5.2992373704910278e-01
    z[4,3,3]  R1386     -3.0490031838417053e-01
    z[4,3,3]  R1387     6.3828772306442261e-01
    z[4,3,3]  R1388     5.4679099470376968e-02
    z[4,3,3]  R1389     2.2161155939102173e-01
    z[4,3,3]  R1390     1.2202896922826767e-01
    z[4,3,3]  R1391     3.0636712908744812e-01
    z[4,3,3]  R1392     -5.1346111297607422e-01
    z[4,3,3]  R1393     -0.125356987118721
    z[4,3,3]  R1394     -1.5767522156238556e-01
    z[4,3,3]  R1395     -0.00643932493403554
    z[4,3,3]  R1396     -5.5639952421188354e-01
    z[4,3,3]  R1397     2.8882962465286255e-01
    z[4,3,3]  R1398     -1.5325054526329041e-01
    z[4,3,3]  R1399     5.3501695394515991e-01
    z[4,3,3]  R1400     2.5933426618576050e-01
    z[4,3,3]  R1401     -1.9293682649731636e-02
    z[4,3,3]  R1402     -8.1855103373527527e-02
    z[4,3,3]  R1403     7.2345834970474243e-01
    z[4,3,3]  R1404     -2.1861200034618378e-01
    z[4,3,3]  R1405     1.4545749127864838e-01
    z[4,3,3]  R1406     2.9838341474533081e-01
    z[4,3,3]  R1407     2.6166230440139771e-01
    z[4,3,3]  R1408     -4.8168757557868958e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R1277     -1
    z[4,3,4]  R1278     1
    z[4,3,4]  R1283     2.0960272848606110e-01
    z[4,3,4]  R1284     -3.7107229232788086e-02
    z[4,3,4]  R1285     -7.0225065946578979e-01
    z[4,3,4]  R1286     -4.7506490349769592e-01
    z[4,3,4]  R1287     -3.6551004648208618e-01
    z[4,3,4]  R1288     -4.3038591742515564e-01
    z[4,3,4]  R1289     4.4329786300659180e-01
    z[4,3,4]  R1290     -5.3792528808116913e-02
    z[4,3,4]  R1291     -4.5282721519470215e-02
    z[4,3,4]  R1292     6.5043777227401733e-02
    z[4,3,4]  R1293     1.4205466210842133e-01
    z[4,3,4]  R1294     8.2762479782104492e-02
    z[4,3,4]  R1295     1.7623870074748993e-01
    z[4,3,4]  R1296     3.9861190319061279e-01
    z[4,3,4]  R1297     -2.0020754635334015e-01
    z[4,3,4]  R1298     -1.9458557665348053e-01
    z[4,3,4]  R1299     -8.5982456803321838e-02
    z[4,3,4]  R1300     1.6359147429466248e-01
    z[4,3,4]  R1301     1.9855398684740067e-02
    z[4,3,4]  R1302     0.178420752286911
    z[4,3,4]  R1303     2.1477924287319183e-01
    z[4,3,4]  R1304     -1.5897114574909210e-01
    z[4,3,4]  R1305     2.6159333065152168e-02
    z[4,3,4]  R1306     1.6524660587310791e-01
    z[4,3,4]  R1307     0.0753258541226387
    z[4,3,4]  R1308     3.3169826865196228e-01
    z[4,3,4]  R1309     0.0411791168153286
    z[4,3,4]  R1310     2.2157919406890869e-01
    z[4,3,4]  R1311     -4.7878913581371307e-02
    z[4,3,4]  R1312     3.7933662533760071e-01
    z[4,3,4]  R1313     -1.9451610743999481e-02
    z[4,3,4]  R1314     1.8401028215885162e-01
    z[4,3,4]  R1315     2.4931050837039948e-01
    z[4,3,4]  R1316     9.7140751779079437e-02
    z[4,3,4]  R1317     4.1627818346023560e-01
    z[4,3,4]  R1318     3.2874977588653564e-01
    z[4,3,4]  R1319     -2.6751694083213806e-01
    z[4,3,4]  R1320     4.1147032380104065e-01
    z[4,3,4]  R1321     4.1332921385765076e-01
    z[4,3,4]  R1322     4.8051834106445312e-02
    z[4,3,4]  R1323     1.0222673416137695e-01
    z[4,3,4]  R1324     -2.2699016332626343e-01
    z[4,3,4]  R1325     6.3473515212535858e-02
    z[4,3,4]  R1326     8.2612454891204834e-02
    z[4,3,4]  R1327     -2.8288796544075012e-02
    z[4,3,4]  R1328     7.2491921484470367e-02
    z[4,3,4]  R1329     9.1149166226387024e-02
    z[4,3,4]  R1330     -7.5300313532352448e-02
    z[4,3,4]  R1331     1.7393555492162704e-02
    z[4,3,4]  R1332     8.6900874972343445e-02
    z[4,3,4]  R1333     -1.9447323679924011e-01
    z[4,3,4]  R1334     1.8232997506856918e-02
    z[4,3,4]  R1335     -3.6176049709320068e-01
    z[4,3,4]  R1336     2.2238619625568390e-01
    z[4,3,4]  R1337     -9.1401286423206329e-02
    z[4,3,4]  R1338     3.6532336473464966e-01
    z[4,3,4]  R1339     1.1237250268459320e-01
    z[4,3,4]  R1340     1.1224296689033508e-01
    z[4,3,4]  R1341     7.5787985697388649e-03
    z[4,3,4]  R1342     6.4320690929889679e-02
    z[4,3,4]  R1343     -1.3239432871341705e-01
    z[4,3,4]  R1344     2.5776756927371025e-02
    z[4,3,4]  R1345     3.5215219855308533e-01
    z[4,3,4]  R1346     6.4503157138824463e-01
    z[4,3,4]  R1347     4.3805581331253052e-01
    z[4,3,4]  R1348     -1.5390609204769135e-01
    z[4,3,4]  R1349     6.7675316333770752e-01
    z[4,3,4]  R1350     -3.6997926235198975e-01
    z[4,3,4]  R1351     -6.6607259213924408e-02
    z[4,3,4]  R1352     1.2064320594072342e-01
    z[4,3,4]  R1353     2.6603901386260986e-01
    z[4,3,4]  R1354     4.8441749811172485e-01
    z[4,3,4]  R1355     7.0256847143173218e-01
    z[4,3,4]  R1356     4.4332712888717651e-01
    z[4,3,4]  R1357     3.2140663266181946e-01
    z[4,3,4]  R1358     1.5471938252449036e-01
    z[4,3,4]  R1359     -9.9260888993740082e-02
    z[4,3,4]  R1360     -1.8220679461956024e-01
    z[4,3,4]  R1361     1.9566479325294495e-01
    z[4,3,4]  R1362     -4.1278502345085144e-01
    z[4,3,4]  R1363     1.5285915136337280e-01
    z[4,3,4]  R1364     2.2578676044940948e-01
    z[4,3,4]  R1365     -6.1166834831237793e-01
    z[4,3,4]  R1366     6.0078907757997513e-02
    z[4,3,4]  R1367     -1.0044468194246292e-01
    z[4,3,4]  R1368     1.9026717543601990e-01
    z[4,3,4]  R1369     -0.0942695364356041
    z[4,3,4]  R1370     -0.530070424079895
    z[4,3,4]  R1371     0.572259247303009
    z[4,3,4]  R1372     0.281680703163147
    z[4,3,4]  R1373     4.8072297126054764e-02
    z[4,3,4]  R1374     1.2790170498192310e-02
    z[4,3,4]  R1375     5.2944332361221313e-01
    z[4,3,4]  R1376     5.0449732691049576e-02
    z[4,3,4]  R1377     1.2470442801713943e-01
    z[4,3,4]  R1378     -5.2881163358688354e-01
    z[4,3,4]  R1379     -6.7869938910007477e-02
    z[4,3,4]  R1380     0.330610454082489
    z[4,3,4]  R1381     -8.7898708879947662e-02
    z[4,3,4]  R1382     1.6543485224246979e-01
    z[4,3,4]  R1383     3.1123638153076172e-01
    z[4,3,4]  R1384     -1.7848348617553711e-01
    z[4,3,4]  R1385     1.1690960079431534e-01
    z[4,3,4]  R1386     1.5920451283454895e-01
    z[4,3,4]  R1387     3.0334630608558655e-01
    z[4,3,4]  R1388     0.0460958406329155
    z[4,3,4]  R1389     2.8051629662513733e-02
    z[4,3,4]  R1390     -2.2514438629150391e-01
    z[4,3,4]  R1391     4.8451088368892670e-02
    z[4,3,4]  R1392     -2.8541529178619385e-01
    z[4,3,4]  R1393     2.3641730844974518e-01
    z[4,3,4]  R1394     -4.1492116451263428e-01
    z[4,3,4]  R1395     3.7780386209487915e-01
    z[4,3,4]  R1396     3.3900007605552673e-02
    z[4,3,4]  R1397     -5.9458520263433456e-02
    z[4,3,4]  R1398     2.0541921257972717e-01
    z[4,3,4]  R1399     9.1188631951808929e-02
    z[4,3,4]  R1400     7.1426816284656525e-02
    z[4,3,4]  R1401     -1.2145414017140865e-02
    z[4,3,4]  R1402     -2.1761940419673920e-01
    z[4,3,4]  R1403     1.8333357572555542e-01
    z[4,3,4]  R1404     1.2594452500343323e-01
    z[4,3,4]  R1405     2.7962759137153625e-01
    z[4,3,4]  R1406     5.1990884542465210e-01
    z[4,3,4]  R1407     1.6360929608345032e-01
    z[4,3,4]  R1408     9.3086190521717072e-02
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R1279     -1
    z[4,3,5]  R1280     1
    z[4,3,5]  R1283     -2.9125988483428955e-01
    z[4,3,5]  R1284     2.8395307064056396e-01
    z[4,3,5]  R1285     3.8931244611740112e-01
    z[4,3,5]  R1286     -1.9168801605701447e-01
    z[4,3,5]  R1287     5.8619940280914307e-01
    z[4,3,5]  R1288     -2.4412751197814941e-02
    z[4,3,5]  R1289     -2.9837164282798767e-01
    z[4,3,5]  R1290     -2.8865331411361694e-01
    z[4,3,5]  R1291     1.4389933645725250e-01
    z[4,3,5]  R1292     -9.0629987418651581e-02
    z[4,3,5]  R1293     -3.2613296061754227e-02
    z[4,3,5]  R1294     -1.4074572920799255e-01
    z[4,3,5]  R1295     3.2871791720390320e-01
    z[4,3,5]  R1296     1.4860203862190247e-01
    z[4,3,5]  R1297     -4.4143116474151611e-01
    z[4,3,5]  R1298     -5.3421151638031006e-01
    z[4,3,5]  R1299     1.0798743367195129e-01
    z[4,3,5]  R1300     -2.9459038376808167e-01
    z[4,3,5]  R1301     -2.6060670614242554e-01
    z[4,3,5]  R1302     -7.2829827666282654e-02
    z[4,3,5]  R1303     -2.1018789708614349e-01
    z[4,3,5]  R1304     7.5851596891880035e-02
    z[4,3,5]  R1305     -3.5586071014404297e-01
    z[4,3,5]  R1306     -2.5549063086509705e-01
    z[4,3,5]  R1307     1.1772985756397247e-01
    z[4,3,5]  R1308     -2.9082307219505310e-01
    z[4,3,5]  R1309     -7.5395785272121429e-02
    z[4,3,5]  R1310     -2.9266867041587830e-01
    z[4,3,5]  R1311     -3.0513831973075867e-01
    z[4,3,5]  R1312     3.6092754453420639e-02
    z[4,3,5]  R1313     -0.0642428919672966
    z[4,3,5]  R1314     -1.3352457899600267e-03
    z[4,3,5]  R1315     2.5755900144577026e-01
    z[4,3,5]  R1316     -3.2464000582695007e-01
    z[4,3,5]  R1317     -0.275749534368515
    z[4,3,5]  R1318     2.5408431887626648e-01
    z[4,3,5]  R1319     -0.0939953550696373
    z[4,3,5]  R1320     -2.5288176536560059e-01
    z[4,3,5]  R1321     -2.3178742825984955e-01
    z[4,3,5]  R1322     -0.127928227186203
    z[4,3,5]  R1323     -3.0584850907325745e-01
    z[4,3,5]  R1324     -2.4475468695163727e-01
    z[4,3,5]  R1325     -6.1415430158376694e-02
    z[4,3,5]  R1326     -3.7571245431900024e-01
    z[4,3,5]  R1327     -2.3396830260753632e-01
    z[4,3,5]  R1328     -2.2887107729911804e-01
    z[4,3,5]  R1329     -2.9069520533084869e-02
    z[4,3,5]  R1330     -0.0584476999938488
    z[4,3,5]  R1331     -1.2071265280246735e-01
    z[4,3,5]  R1332     -3.0844411253929138e-01
    z[4,3,5]  R1333     -2.5860235095024109e-01
    z[4,3,5]  R1334     -2.2496019955724478e-03
    z[4,3,5]  R1335     -2.4236641824245453e-01
    z[4,3,5]  R1336     7.9531274735927582e-02
    z[4,3,5]  R1337     -4.3636941909790039e-01
    z[4,3,5]  R1338     -4.3903324007987976e-01
    z[4,3,5]  R1339     -9.9482253193855286e-02
    z[4,3,5]  R1340     -2.7293553948402405e-01
    z[4,3,5]  R1341     2.2007305920124054e-01
    z[4,3,5]  R1342     1.1336227878928185e-02
    z[4,3,5]  R1343     -1.5972651541233063e-01
    z[4,3,5]  R1344     4.2401656508445740e-01
    z[4,3,5]  R1345     1.3125570118427277e-01
    z[4,3,5]  R1346     4.9722746014595032e-02
    z[4,3,5]  R1347     -9.0187273919582367e-02
    z[4,3,5]  R1348     0.148108571767807
    z[4,3,5]  R1349     -4.6637412905693054e-01
    z[4,3,5]  R1350     -1.2660789489746094e-01
    z[4,3,5]  R1351     -2.2432606667280197e-02
    z[4,3,5]  R1352     -3.3498124685138464e-03
    z[4,3,5]  R1353     -2.0628614723682404e-01
    z[4,3,5]  R1354     -6.0372814536094666e-02
    z[4,3,5]  R1355     -5.1319307088851929e-01
    z[4,3,5]  R1356     -1.2096808850765228e-01
    z[4,3,5]  R1357     -1.0360217653214931e-02
    z[4,3,5]  R1358     1.5313176810741425e-01
    z[4,3,5]  R1359     -1.4690301613882184e-03
    z[4,3,5]  R1360     7.7183679677546024e-03
    z[4,3,5]  R1361     0.411602646112442
    z[4,3,5]  R1362     3.0027794837951660e-01
    z[4,3,5]  R1363     4.4443616271018982e-01
    z[4,3,5]  R1364     7.7148318290710449e-01
    z[4,3,5]  R1365     -7.3083013296127319e-02
    z[4,3,5]  R1366     3.0366408824920654e-01
    z[4,3,5]  R1367     1.6252642869949341e-01
    z[4,3,5]  R1368     1.2806795537471771e-01
    z[4,3,5]  R1369     -3.5857267677783966e-02
    z[4,3,5]  R1370     0.175323948264122
    z[4,3,5]  R1371     2.4659889936447144e-01
    z[4,3,5]  R1372     -5.7021111249923706e-01
    z[4,3,5]  R1373     -2.3316358029842377e-01
    z[4,3,5]  R1374     -7.3266260325908661e-02
    z[4,3,5]  R1375     5.0397776067256927e-02
    z[4,3,5]  R1376     4.6938300132751465e-01
    z[4,3,5]  R1377     4.2848322540521622e-02
    z[4,3,5]  R1378     -3.4131422638893127e-01
    z[4,3,5]  R1379     5.9016084671020508e-01
    z[4,3,5]  R1380     -4.1576853394508362e-01
    z[4,3,5]  R1381     -2.4785226583480835e-01
    z[4,3,5]  R1382     7.4764534831047058e-02
    z[4,3,5]  R1383     1.9420921802520752e-01
    z[4,3,5]  R1384     -3.9852684736251831e-01
    z[4,3,5]  R1385     -4.8294299840927124e-01
    z[4,3,5]  R1386     4.3299004435539246e-01
    z[4,3,5]  R1387     -4.8052871227264404e-01
    z[4,3,5]  R1388     -3.6589032411575317e-01
    z[4,3,5]  R1389     1.8955765292048454e-02
    z[4,3,5]  R1390     3.3537667989730835e-01
    z[4,3,5]  R1391     -1.8424670398235321e-01
    z[4,3,5]  R1392     -1.2360414117574692e-01
    z[4,3,5]  R1393     -2.2777855396270752e-01
    z[4,3,5]  R1394     -3.6247935891151428e-01
    z[4,3,5]  R1395     2.7795165777206421e-01
    z[4,3,5]  R1396     -1.0404511541128159e-01
    z[4,3,5]  R1397     -4.3667447566986084e-01
    z[4,3,5]  R1398     8.2699991762638092e-02
    z[4,3,5]  R1399     -2.6953813433647156e-01
    z[4,3,5]  R1400     -2.2505274415016174e-01
    z[4,3,5]  R1401     -3.7162205576896667e-01
    z[4,3,5]  R1402     -2.0590139925479889e-01
    z[4,3,5]  R1403     -3.0605033040046692e-01
    z[4,3,5]  R1404     -0.577193021774292
    z[4,3,5]  R1405     6.0814291238784790e-01
    z[4,3,5]  R1406     -1.1223967373371124e-01
    z[4,3,5]  R1407     1.0405306518077850e-01
    z[4,3,5]  R1408     -6.3074208796024323e-02
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R1281     -1
    z[4,3,6]  R1282     1
    z[4,3,6]  R1283     2.8060242533683777e-01
    z[4,3,6]  R1284     -7.3620069026947021e-01
    z[4,3,6]  R1285     3.4527981281280518e-01
    z[4,3,6]  R1286     -2.0684666931629181e-01
    z[4,3,6]  R1287     3.0820357799530029e-01
    z[4,3,6]  R1288     -0.128057062625885
    z[4,3,6]  R1289     6.4315706491470337e-01
    z[4,3,6]  R1290     1.2790703773498535e-01
    z[4,3,6]  R1291     -2.7893617749214172e-01
    z[4,3,6]  R1292     1.7463859915733337e-01
    z[4,3,6]  R1293     1.9452748820185661e-02
    z[4,3,6]  R1294     -3.7492178380489349e-02
    z[4,3,6]  R1295     -5.4711066186428070e-02
    z[4,3,6]  R1296     3.8416630029678345e-01
    z[4,3,6]  R1297     0.128541499376297
    z[4,3,6]  R1298     -1.7142567038536072e-01
    z[4,3,6]  R1299     3.5137572558596730e-04
    z[4,3,6]  R1300     -1.0635446012020111e-01
    z[4,3,6]  R1301     3.9185993373394012e-03
    z[4,3,6]  R1302     -3.9791685342788696e-01
    z[4,3,6]  R1303     1.1854583024978638e-01
    z[4,3,6]  R1304     3.4693002700805664e-01
    z[4,3,6]  R1305     2.9228290915489197e-01
    z[4,3,6]  R1306     -1.6315580904483795e-01
    z[4,3,6]  R1307     4.1230472922325134e-01
    z[4,3,6]  R1308     -3.0129143595695496e-01
    z[4,3,6]  R1309     -2.9035961627960205e-01
    z[4,3,6]  R1310     1.4775559306144714e-01
    z[4,3,6]  R1311     -2.9739844799041748e-01
    z[4,3,6]  R1312     1.8891172111034393e-01
    z[4,3,6]  R1313     -2.3863962292671204e-01
    z[4,3,6]  R1314     -1.5067948400974274e-01
    z[4,3,6]  R1315     2.7361556887626648e-01
    z[4,3,6]  R1316     -2.0225435495376587e-02
    z[4,3,6]  R1317     2.4946808815002441e-01
    z[4,3,6]  R1318     4.7203049063682556e-02
    z[4,3,6]  R1319     -4.6506536006927490e-01
    z[4,3,6]  R1320     3.3451551198959351e-01
    z[4,3,6]  R1321     -4.1838163137435913e-01
    z[4,3,6]  R1322     -2.3472876846790314e-01
    z[4,3,6]  R1323     1.0016328841447830e-01
    z[4,3,6]  R1324     1.6122755408287048e-01
    z[4,3,6]  R1325     9.5639698207378387e-02
    z[4,3,6]  R1326     -4.5434826612472534e-01
    z[4,3,6]  R1327     -3.2423120737075806e-01
    z[4,3,6]  R1328     -2.6547786593437195e-01
    z[4,3,6]  R1329     -3.2465690374374390e-01
    z[4,3,6]  R1330     2.2864004597067833e-02
    z[4,3,6]  R1331     -3.6312052607536316e-01
    z[4,3,6]  R1332     -2.0985266566276550e-01
    z[4,3,6]  R1333     -2.3246988654136658e-01
    z[4,3,6]  R1334     -1.0503920912742615e-01
    z[4,3,6]  R1335     -3.7892490625381470e-01
    z[4,3,6]  R1336     3.4058490395545959e-01
    z[4,3,6]  R1337     -1.3030645251274109e-01
    z[4,3,6]  R1338     8.6043469607830048e-02
    z[4,3,6]  R1339     4.5605826377868652e-01
    z[4,3,6]  R1340     -0.087053082883358
    z[4,3,6]  R1341     -2.8867509961128235e-01
    z[4,3,6]  R1342     3.6522147059440613e-01
    z[4,3,6]  R1343     0.0693008303642273
    z[4,3,6]  R1344     1.1321227252483368e-01
    z[4,3,6]  R1345     -1.2769292108714581e-02
    z[4,3,6]  R1346     -2.2302225232124329e-01
    z[4,3,6]  R1347     3.5758644342422485e-01
    z[4,3,6]  R1348     -4.6779972314834595e-01
    z[4,3,6]  R1349     -2.5400716066360474e-01
    z[4,3,6]  R1350     -2.3589698597788811e-02
    z[4,3,6]  R1351     4.9371778964996338e-02
    z[4,3,6]  R1352     -3.2521459460258484e-01
    z[4,3,6]  R1353     1.8636316061019897e-01
    z[4,3,6]  R1354     1.5397830307483673e-01
    z[4,3,6]  R1355     1.4918014407157898e-01
    z[4,3,6]  R1356     1.9710658490657806e-01
    z[4,3,6]  R1357     -1.4122587442398071e-01
    z[4,3,6]  R1358     0.447965532541275
    z[4,3,6]  R1359     1.9739234447479248e-01
    z[4,3,6]  R1360     -3.0811837315559387e-01
    z[4,3,6]  R1361     -2.7268251776695251e-01
    z[4,3,6]  R1362     -9.2920534312725067e-02
    z[4,3,6]  R1363     -2.0176212489604950e-01
    z[4,3,6]  R1364     3.5325026512145996e-01
    z[4,3,6]  R1365     -3.3094260096549988e-01
    z[4,3,6]  R1366     1.6189102828502655e-01
    z[4,3,6]  R1367     3.0460205674171448e-01
    z[4,3,6]  R1368     3.9445933699607849e-01
    z[4,3,6]  R1369     -1.1341780424118042e-01
    z[4,3,6]  R1370     -4.6131104230880737e-01
    z[4,3,6]  R1371     1.1167629063129425e-01
    z[4,3,6]  R1372     2.3331305012106895e-02
    z[4,3,6]  R1373     9.6927117556333542e-03
    z[4,3,6]  R1374     7.5245589017868042e-02
    z[4,3,6]  R1375     5.4382622241973877e-01
    z[4,3,6]  R1376     -5.7883268594741821e-01
    z[4,3,6]  R1377     6.7323154211044312e-01
    z[4,3,6]  R1378     -4.6804344654083252e-01
    z[4,3,6]  R1379     6.6752098500728607e-02
    z[4,3,6]  R1380     9.5703966915607452e-02
    z[4,3,6]  R1381     -3.4824347496032715e-01
    z[4,3,6]  R1382     6.4936473965644836e-02
    z[4,3,6]  R1383     -1.2131937593221664e-01
    z[4,3,6]  R1384     1.2059555947780609e-01
    z[4,3,6]  R1385     -1.1474822461605072e-01
    z[4,3,6]  R1386     -4.6841281652450562e-01
    z[4,3,6]  R1387     1.1004430055618286e-01
    z[4,3,6]  R1388     3.4700807183980942e-02
    z[4,3,6]  R1389     -0.372715562582016
    z[4,3,6]  R1390     -1.0838195681571960e-01
    z[4,3,6]  R1391     -9.5185093581676483e-02
    z[4,3,6]  R1392     2.1241450309753418e-01
    z[4,3,6]  R1393     3.3925303816795349e-01
    z[4,3,6]  R1394     -8.8744185864925385e-02
    z[4,3,6]  R1395     5.7432585954666138e-01
    z[4,3,6]  R1396     4.3185046315193176e-01
    z[4,3,6]  R1397     -4.1304412484169006e-01
    z[4,3,6]  R1398     -6.9377802312374115e-02
    z[4,3,6]  R1399     -1.8144853413105011e-01
    z[4,3,6]  R1400     -2.8613728284835815e-01
    z[4,3,6]  R1401     0.54569011926651
    z[4,3,6]  R1402     2.0884558558464050e-01
    z[4,3,6]  R1403     6.5937139093875885e-02
    z[4,3,6]  R1404     -3.9090004563331604e-01
    z[4,3,6]  R1405     -2.1658392250537872e-01
    z[4,3,6]  R1406     2.0007678866386414e-01
    z[4,3,6]  R1407     5.7898283004760742e-01
    z[4,3,6]  R1408     -5.9164726734161377e-01
    z[3,8,0]  R29       -1
    z[3,8,0]  R74       1
    z[3,8,0]  R1409     -1
    z[3,8,0]  R1410     1
    z[3,8,0]  R1423     -5.4624056816101074e-01
    z[3,8,0]  R1424     -0.424212247133255
    z[3,8,0]  R1425     7.1994647383689880e-02
    z[3,8,0]  R1426     -6.1272311210632324e-01
    z[3,8,0]  R1427     -6.4805978536605835e-01
    z[3,8,0]  R1428     -3.4386971592903137e-01
    z[3,8,0]  R1429     -8.9542247354984283e-02
    z[3,8,0]  R1430     1.1211939901113510e-01
    z[3,8,0]  R1431     -2.8060302138328552e-01
    z[3,8,0]  R1432     3.1735548377037048e-01
    z[3,8,0]  R1433     -6.1525338888168335e-01
    z[3,8,0]  R1434     -8.6321853101253510e-02
    z[3,8,0]  R1435     1.6740697622299194e-01
    z[3,8,0]  R1436     3.4569454193115234e-01
    z[3,8,0]  R1437     5.2569651603698730e-01
    z[3,8,0]  R1438     3.9396968483924866e-01
    z[3,8,0]  R1439     2.5449299812316895e-01
    z[3,8,0]  R1440     -6.4478024840354919e-02
    z[3,8,0]  R1441     -3.1391513347625732e-01
    z[3,8,0]  R1442     0.0785473957657814
    z[3,8,0]  R1443     -0.202298104763031
    z[3,8,0]  R1444     -3.6601746082305908e-01
    z[3,8,0]  R1445     1.3802783191204071e-01
    z[3,8,0]  R1446     -0.574720025062561
    z[3,8,0]  R1447     -1.1223085224628448e-01
    z[3,8,0]  R1448     -2.9490327835083008e-01
    z[3,8,0]  R1449     3.1449355185031891e-02
    z[3,8,0]  R1450     -2.7709737420082092e-02
    z[3,8,0]  R1451     -7.8968949615955353e-02
    z[3,8,0]  R1452     1.7646408081054688e-01
    z[3,8,0]  R1453     -1.8827441334724426e-01
    z[3,8,0]  R1454     -2.2635528445243835e-01
    z[3,8,0]  R1455     2.1855413913726807e-01
    z[3,8,0]  R1456     -4.7770336270332336e-02
    z[3,8,0]  R1457     1.0365481674671173e-01
    z[3,8,0]  R1458     -1.7878907918930054e-01
    z[3,8,0]  R1459     -4.6802438795566559e-02
    z[3,8,0]  R1460     -5.0883240997791290e-02
    z[3,8,0]  R1461     1.4553122222423553e-01
    z[3,8,0]  R1462     2.3893390595912933e-01
    z[3,8,0]  R1463     -8.7573036551475525e-02
    z[3,8,0]  R1464     3.5484347492456436e-02
    z[3,8,0]  R1465     -1.9336035475134850e-02
    z[3,8,0]  R1466     5.8665376156568527e-02
    z[3,8,0]  R1467     -3.2212796807289124e-01
    z[3,8,0]  R1468     2.3365199565887451e-01
    z[3,8,0]  R1469     -1.0389288514852524e-01
    z[3,8,0]  R1470     -4.9414080381393433e-01
    z[3,8,0]  R1471     -4.2689168453216553e-01
    z[3,8,0]  R1472     2.8846862912178040e-01
    z[3,8,0]  R1473     -5.4492527246475220e-01
    z[3,8,0]  R1474     -2.1534349024295807e-01
    z[3,8,0]  R1475     -4.7673907876014709e-01
    z[3,8,0]  R1476     -9.1472655534744263e-01
    z[3,8,0]  R1477     -4.9899551272392273e-01
    z[3,8,0]  R1478     1.7937442660331726e-01
    z[3,8,0]  R1479     8.3233872428536415e-03
    z[3,8,0]  R1480     -1.1779731512069702e-01
    z[3,8,0]  R1481     7.5718045234680176e-02
    z[3,8,0]  R1482     4.3023101985454559e-02
    z[3,8,0]  R1483     2.5510627031326294e-01
    z[3,8,0]  R1484     0.611352801322937
    z[3,8,0]  R1485     6.4501678943634033e-01
    z[3,8,0]  R1486     5.7139158248901367e-01
    z[3,8,0]  R1487     5.8158326148986816e-01
    z[3,8,0]  R1488     3.6221036314964294e-01
    z[3,8,0]  R1489     2.8853756189346313e-01
    z[3,8,0]  R1490     3.1469497084617615e-01
    z[3,8,0]  R1491     2.6581883430480957e-01
    z[3,8,0]  R1492     5.8376115560531616e-01
    z[3,8,0]  R1493     3.7380585074424744e-01
    z[3,8,0]  R1494     4.8549342155456543e-01
    z[3,8,0]  R1495     6.9221824407577515e-01
    z[3,8,0]  R1496     2.0233023166656494e-01
    z[3,8,0]  R1497     1.2574322521686554e-01
    z[3,8,0]  R1498     2.5684067606925964e-01
    z[3,8,0]  R1499     1.1671365052461624e-01
    z[3,8,0]  R1500     2.3870217800140381e-01
    z[3,8,0]  R1501     1.5381184220314026e-01
    z[3,8,0]  R1502     5.1420134305953979e-01
    z[3,8,0]  R1503     2.2655582427978516e-01
    z[3,8,0]  R1504     0.283189594745636
    z[3,8,0]  R1505     2.7601400017738342e-01
    z[3,8,0]  R1506     3.5650694370269775e-01
    z[3,8,0]  R1507     2.8758205473423004e-02
    z[3,8,0]  R1508     2.2294494509696960e-01
    z[3,8,0]  R1509     2.8574812412261963e-01
    z[3,8,0]  R1510     -5.9725034981966019e-02
    z[3,8,0]  R1511     -0.0819258838891983
    z[3,8,1]  R30       -1
    z[3,8,1]  R75       1
    z[3,8,1]  R1411     -1
    z[3,8,1]  R1412     1
    z[3,8,1]  R1423     7.9328608512878418e-01
    z[3,8,1]  R1424     7.6735401153564453e-01
    z[3,8,1]  R1425     6.3840603828430176e-01
    z[3,8,1]  R1426     1.1874987185001373e-01
    z[3,8,1]  R1427     1.6845221817493439e-01
    z[3,8,1]  R1428     1.1892323940992355e-01
    z[3,8,1]  R1429     -4.9029093235731125e-02
    z[3,8,1]  R1430     -2.0932072773575783e-02
    z[3,8,1]  R1431     -5.1081206649541855e-02
    z[3,8,1]  R1432     -4.6568468213081360e-02
    z[3,8,1]  R1433     -6.5252298116683960e-01
    z[3,8,1]  R1434     -6.6241371631622314e-01
    z[3,8,1]  R1435     -6.3512933254241943e-01
    z[3,8,1]  R1436     -5.6671643257141113e-01
    z[3,8,1]  R1437     -5.8184927701950073e-01
    z[3,8,1]  R1438     -8.0940610170364380e-01
    z[3,8,1]  R1439     -5.6583595275878906e-01
    z[3,8,1]  R1440     -5.6445431709289551e-01
    z[3,8,1]  R1441     -6.2445646524429321e-01
    z[3,8,1]  R1442     -5.3245031833648682e-01
    z[3,8,1]  R1443     -7.7334809303283691e-01
    z[3,8,1]  R1444     -6.9144630432128906e-01
    z[3,8,1]  R1445     -0.743336021900177
    z[3,8,1]  R1446     -6.4037960767745972e-01
    z[3,8,1]  R1447     4.4405010342597961e-01
    z[3,8,1]  R1448     -6.9568479061126709e-01
    z[3,8,1]  R1449     0.522428035736084
    z[3,8,1]  R1450     -5.3287369012832642e-01
    z[3,8,1]  R1451     4.8844003677368164e-01
    z[3,8,1]  R1452     6.3939177989959717e-01
    z[3,8,1]  R1453     -8.4677040576934814e-01
    z[3,8,1]  R1454     -8.7058031558990479e-01
    z[3,8,1]  R1455     -8.9668089151382446e-01
    z[3,8,1]  R1456     -7.2005736827850342e-01
    z[3,8,1]  R1457     -6.7852222919464111e-01
    z[3,8,1]  R1458     0.713131844997406
    z[3,8,1]  R1459     -6.1013668775558472e-01
    z[3,8,1]  R1460     -6.1674284934997559e-01
    z[3,8,1]  R1461     6.5785801410675049e-01
    z[3,8,1]  R1462     8.5632407665252686e-01
    z[3,8,1]  R1463     6.4206200838088989e-01
    z[3,8,1]  R1464     8.7107646465301514e-01
    z[3,8,1]  R1465     -7.5011372566223145e-01
    z[3,8,1]  R1466     -8.7947982549667358e-01
    z[3,8,1]  R1467     4.7453027963638306e-01
    z[3,8,1]  R1468     -6.2827903032302856e-01
    z[3,8,1]  R1469     6.8753391504287720e-01
    z[3,8,1]  R1470     3.6887449026107788e-01
    z[3,8,1]  R1471     3.3512553572654724e-01
    z[3,8,1]  R1472     -0.559316098690033
    z[3,8,1]  R1473     4.3278518319129944e-01
    z[3,8,1]  R1474     5.2865236997604370e-01
    z[3,8,1]  R1475     3.2280489802360535e-02
    z[3,8,1]  R1476     -1.0213023424148560e-01
    z[3,8,1]  R1477     3.5205683112144470e-01
    z[3,8,1]  R1478     0.0873582735657692
    z[3,8,1]  R1479     3.0650734901428223e-01
    z[3,8,1]  R1480     -1.1546940356492996e-01
    z[3,8,1]  R1481     -8.3069734275341034e-02
    z[3,8,1]  R1482     2.9835087060928345e-01
    z[3,8,1]  R1483     -0.0591592937707901
    z[3,8,1]  R1484     -6.5233409404754639e-02
    z[3,8,1]  R1485     -1.7246234416961670e-01
    z[3,8,1]  R1486     5.4489899426698685e-02
    z[3,8,1]  R1487     -7.5519219040870667e-02
    z[3,8,1]  R1488     -2.4127402901649475e-01
    z[3,8,1]  R1489     -6.4986400306224823e-02
    z[3,8,1]  R1490     6.6145914793014526e-01
    z[3,8,1]  R1491     -8.6502122879028320e-01
    z[3,8,1]  R1492     2.5387245416641235e-01
    z[3,8,1]  R1493     3.3545008301734924e-01
    z[3,8,1]  R1494     0.605156421661377
    z[3,8,1]  R1495     1.9629713892936707e-01
    z[3,8,1]  R1496     -0.922296404838562
    z[3,8,1]  R1497     -9.0870171785354614e-01
    z[3,8,1]  R1498     -9.0678805112838745e-01
    z[3,8,1]  R1499     -9.0038394927978516e-01
    z[3,8,1]  R1500     -8.7704312801361084e-01
    z[3,8,1]  R1501     -8.8701063394546509e-01
    z[3,8,1]  R1502     1.3998055458068848e-01
    z[3,8,1]  R1503     4.0884265303611755e-01
    z[3,8,1]  R1504     2.9602622613310814e-02
    z[3,8,1]  R1505     2.5092095136642456e-02
    z[3,8,1]  R1506     4.8419770598411560e-01
    z[3,8,1]  R1507     -0.950893223285675
    z[3,8,1]  R1508     -8.8206022977828979e-01
    z[3,8,1]  R1509     -8.9106363058090210e-01
    z[3,8,1]  R1510     -7.3857551813125610e-01
    z[3,8,1]  R1511     -6.0511809587478638e-01
    z[3,8,2]  R31       -1
    z[3,8,2]  R76       1
    z[3,8,2]  R1413     -1
    z[3,8,2]  R1414     1
    z[3,8,2]  R1423     2.4101685732603073e-02
    z[3,8,2]  R1424     -1.2400750815868378e-01
    z[3,8,2]  R1425     5.2930307388305664e-01
    z[3,8,2]  R1426     5.2981162071228027e-01
    z[3,8,2]  R1427     5.2514404058456421e-01
    z[3,8,2]  R1428     3.1009066104888916e-01
    z[3,8,2]  R1429     -4.4367730617523193e-01
    z[3,8,2]  R1430     -8.0586922168731689e-01
    z[3,8,2]  R1431     -7.8454381227493286e-01
    z[3,8,2]  R1432     8.0022051930427551e-02
    z[3,8,2]  R1433     0.0970572754740715
    z[3,8,2]  R1434     0.152975931763649
    z[3,8,2]  R1435     3.4097391366958618e-01
    z[3,8,2]  R1436     -3.8507252931594849e-01
    z[3,8,2]  R1437     -6.8089894950389862e-02
    z[3,8,2]  R1438     -2.3545506596565247e-01
    z[3,8,2]  R1439     -5.0401028245687485e-02
    z[3,8,2]  R1440     8.3726853132247925e-02
    z[3,8,2]  R1441     1.0667237639427185e-01
    z[3,8,2]  R1442     -2.7492982149124146e-01
    z[3,8,2]  R1443     -4.1653178632259369e-02
    z[3,8,2]  R1444     2.7315405011177063e-01
    z[3,8,2]  R1445     1.5096355974674225e-01
    z[3,8,2]  R1446     4.1382029652595520e-01
    z[3,8,2]  R1447     5.0347495079040527e-01
    z[3,8,2]  R1448     -9.3935750424861908e-02
    z[3,8,2]  R1449     4.3033921718597412e-01
    z[3,8,2]  R1450     -4.3597763776779175e-01
    z[3,8,2]  R1451     1.1288274079561234e-01
    z[3,8,2]  R1452     6.4795380830764771e-01
    z[3,8,2]  R1453     -2.4157375097274780e-01
    z[3,8,2]  R1454     -3.2371073961257935e-02
    z[3,8,2]  R1455     0.0947737991809845
    z[3,8,2]  R1456     -2.7153888344764709e-01
    z[3,8,2]  R1457     -5.3877639770507812e-01
    z[3,8,2]  R1458     3.5098394751548767e-01
    z[3,8,2]  R1459     -2.7506032586097717e-01
    z[3,8,2]  R1460     3.3013519644737244e-01
    z[3,8,2]  R1461     3.1272286176681519e-01
    z[3,8,2]  R1462     3.6370927095413208e-01
    z[3,8,2]  R1463     4.2421030998229980e-01
    z[3,8,2]  R1464     1.8731613457202911e-01
    z[3,8,2]  R1465     2.3560628294944763e-02
    z[3,8,2]  R1466     2.8810295462608337e-01
    z[3,8,2]  R1467     1.2663708627223969e-01
    z[3,8,2]  R1468     -3.2625325024127960e-02
    z[3,8,2]  R1469     2.0188353955745697e-02
    z[3,8,2]  R1470     4.5583987236022949e-01
    z[3,8,2]  R1471     5.1397567987442017e-01
    z[3,8,2]  R1472     0.0961170494556427
    z[3,8,2]  R1473     4.4297706335783005e-02
    z[3,8,2]  R1474     -1.0253424942493439e-01
    z[3,8,2]  R1475     3.4196120500564575e-01
    z[3,8,2]  R1476     1.9986394047737122e-01
    z[3,8,2]  R1477     -8.1668362021446228e-02
    z[3,8,2]  R1478     2.2891965508460999e-01
    z[3,8,2]  R1479     5.2468216419219971e-01
    z[3,8,2]  R1480     -3.9801257848739624e-01
    z[3,8,2]  R1481     -4.8457396030426025e-01
    z[3,8,2]  R1482     -6.3851737976074219e-01
    z[3,8,2]  R1483     -3.4500178694725037e-01
    z[3,8,2]  R1484     -3.0746594071388245e-02
    z[3,8,2]  R1485     0.0672302395105362
    z[3,8,2]  R1486     -1.6945162415504456e-01
    z[3,8,2]  R1487     3.5668212175369263e-01
    z[3,8,2]  R1488     4.5615750551223755e-01
    z[3,8,2]  R1489     1.0421478748321533e-01
    z[3,8,2]  R1490     2.2317555546760559e-01
    z[3,8,2]  R1491     1.8342211842536926e-01
    z[3,8,2]  R1492     3.2977712154388428e-01
    z[3,8,2]  R1493     2.5324460864067078e-01
    z[3,8,2]  R1494     2.0797833800315857e-01
    z[3,8,2]  R1495     5.5952745676040649e-01
    z[3,8,2]  R1496     -1.7250286042690277e-01
    z[3,8,2]  R1497     1.0942266322672367e-02
    z[3,8,2]  R1498     -9.7748890519142151e-02
    z[3,8,2]  R1499     -1.1095040291547775e-01
    z[3,8,2]  R1500     8.1540994346141815e-02
    z[3,8,2]  R1501     1.9990071654319763e-02
    z[3,8,2]  R1502     3.3385327458381653e-01
    z[3,8,2]  R1503     -6.5134182572364807e-02
    z[3,8,2]  R1504     4.1693288087844849e-01
    z[3,8,2]  R1505     -3.3540013432502747e-01
    z[3,8,2]  R1506     3.5556885600090027e-01
    z[3,8,2]  R1507     -1.6824441030621529e-02
    z[3,8,2]  R1508     1.4960496127605438e-01
    z[3,8,2]  R1509     3.2649624347686768e-01
    z[3,8,2]  R1510     -5.8190923929214478e-01
    z[3,8,2]  R1511     -5.5336314439773560e-01
    z[3,8,3]  R32       -1
    z[3,8,3]  R77       1
    z[3,8,3]  R1415     -1
    z[3,8,3]  R1416     1
    z[3,8,3]  R1423     1.5139020979404449e-01
    z[3,8,3]  R1424     2.9603728652000427e-01
    z[3,8,3]  R1425     1.5822613239288330e-01
    z[3,8,3]  R1426     2.4612200260162354e-01
    z[3,8,3]  R1427     1.1945197731256485e-01
    z[3,8,3]  R1428     0.0224288459867239
    z[3,8,3]  R1429     -5.5111384391784668e-01
    z[3,8,3]  R1430     4.6425831317901611e-01
    z[3,8,3]  R1431     -4.1696190834045410e-01
    z[3,8,3]  R1432     -8.2614302635192871e-01
    z[3,8,3]  R1433     -4.0400597453117371e-01
    z[3,8,3]  R1434     -0.0763794332742691
    z[3,8,3]  R1435     -2.2706650197505951e-01
    z[3,8,3]  R1436     -7.7574424445629120e-02
    z[3,8,3]  R1437     -5.6893610954284668e-01
    z[3,8,3]  R1438     -3.5073789954185486e-01
    z[3,8,3]  R1439     -1.8418912589550018e-01
    z[3,8,3]  R1440     3.3512806892395020e-01
    z[3,8,3]  R1441     1.7176859080791473e-01
    z[3,8,3]  R1442     -1.3978110253810883e-01
    z[3,8,3]  R1443     -4.3832760304212570e-02
    z[3,8,3]  R1444     0.148304283618927
    z[3,8,3]  R1445     4.6387454867362976e-01
    z[3,8,3]  R1446     2.2624848783016205e-01
    z[3,8,3]  R1447     6.2244117259979248e-01
    z[3,8,3]  R1448     4.6368911862373352e-01
    z[3,8,3]  R1449     5.2992373704910278e-01
    z[3,8,3]  R1450     -3.0490031838417053e-01
    z[3,8,3]  R1451     6.3828772306442261e-01
    z[3,8,3]  R1452     5.4679099470376968e-02
    z[3,8,3]  R1453     2.2161155939102173e-01
    z[3,8,3]  R1454     1.2202896922826767e-01
    z[3,8,3]  R1455     3.0636712908744812e-01
    z[3,8,3]  R1456     -5.1346111297607422e-01
    z[3,8,3]  R1457     -0.125356987118721
    z[3,8,3]  R1458     -1.5767522156238556e-01
    z[3,8,3]  R1459     -0.00643932493403554
    z[3,8,3]  R1460     -5.5639952421188354e-01
    z[3,8,3]  R1461     2.8882962465286255e-01
    z[3,8,3]  R1462     -1.5325054526329041e-01
    z[3,8,3]  R1463     5.3501695394515991e-01
    z[3,8,3]  R1464     2.5933426618576050e-01
    z[3,8,3]  R1465     -1.9293682649731636e-02
    z[3,8,3]  R1466     -8.1855103373527527e-02
    z[3,8,3]  R1467     7.2345834970474243e-01
    z[3,8,3]  R1468     -2.1861200034618378e-01
    z[3,8,3]  R1469     1.4545749127864838e-01
    z[3,8,3]  R1470     2.9838341474533081e-01
    z[3,8,3]  R1471     2.6166230440139771e-01
    z[3,8,3]  R1472     -4.8168757557868958e-01
    z[3,8,3]  R1473     3.3893135190010071e-01
    z[3,8,3]  R1474     1.7238068580627441e-01
    z[3,8,3]  R1475     -8.0694389343261719e-01
    z[3,8,3]  R1476     2.2265070676803589e-01
    z[3,8,3]  R1477     -1.2656930088996887e-01
    z[3,8,3]  R1478     4.0449026226997375e-01
    z[3,8,3]  R1479     -0.569337010383606
    z[3,8,3]  R1480     -6.4385145902633667e-01
    z[3,8,3]  R1481     1.1762108653783798e-02
    z[3,8,3]  R1482     -2.0890416204929352e-01
    z[3,8,3]  R1483     0.820968508720398
    z[3,8,3]  R1484     6.7245924472808838e-01
    z[3,8,3]  R1485     6.3162380456924438e-01
    z[3,8,3]  R1486     7.0842069387435913e-01
    z[3,8,3]  R1487     6.5730887651443481e-01
    z[3,8,3]  R1488     7.4381065368652344e-01
    z[3,8,3]  R1489     8.7322556972503662e-01
    z[3,8,3]  R1490     2.5221675634384155e-01
    z[3,8,3]  R1491     -2.6172018051147461e-01
    z[3,8,3]  R1492     3.6002656817436218e-01
    z[3,8,3]  R1493     3.9744228124618530e-01
    z[3,8,3]  R1494     2.2856892645359039e-01
    z[3,8,3]  R1495     3.2866531610488892e-01
    z[3,8,3]  R1496     -1.9448810815811157e-01
    z[3,8,3]  R1497     -1.3624049723148346e-01
    z[3,8,3]  R1498     1.0560864955186844e-01
    z[3,8,3]  R1499     8.2533389329910278e-02
    z[3,8,3]  R1500     3.7692766636610031e-02
    z[3,8,3]  R1501     1.9963359832763672e-01
    z[3,8,3]  R1502     6.4280843734741211e-01
    z[3,8,3]  R1503     7.4181818962097168e-01
    z[3,8,3]  R1504     8.2144778966903687e-01
    z[3,8,3]  R1505     6.5293055772781372e-01
    z[3,8,3]  R1506     6.0793638229370117e-01
    z[3,8,3]  R1507     -2.7843394875526428e-01
    z[3,8,3]  R1508     -1.4027177821844816e-03
    z[3,8,3]  R1509     -1.1982208490371704e-01
    z[3,8,3]  R1510     -1.3696564733982086e-01
    z[3,8,3]  R1511     -4.2138215899467468e-01
    z[3,8,4]  R33       -1
    z[3,8,4]  R78       1
    z[3,8,4]  R1417     -1
    z[3,8,4]  R1418     1
    z[3,8,4]  R1423     -9.9260888993740082e-02
    z[3,8,4]  R1424     -1.8220679461956024e-01
    z[3,8,4]  R1425     1.9566479325294495e-01
    z[3,8,4]  R1426     -4.1278502345085144e-01
    z[3,8,4]  R1427     1.5285915136337280e-01
    z[3,8,4]  R1428     2.2578676044940948e-01
    z[3,8,4]  R1429     -6.1166834831237793e-01
    z[3,8,4]  R1430     6.0078907757997513e-02
    z[3,8,4]  R1431     -1.0044468194246292e-01
    z[3,8,4]  R1432     1.9026717543601990e-01
    z[3,8,4]  R1433     -0.0942695364356041
    z[3,8,4]  R1434     -0.530070424079895
    z[3,8,4]  R1435     0.572259247303009
    z[3,8,4]  R1436     0.281680703163147
    z[3,8,4]  R1437     4.8072297126054764e-02
    z[3,8,4]  R1438     1.2790170498192310e-02
    z[3,8,4]  R1439     5.2944332361221313e-01
    z[3,8,4]  R1440     5.0449732691049576e-02
    z[3,8,4]  R1441     1.2470442801713943e-01
    z[3,8,4]  R1442     -5.2881163358688354e-01
    z[3,8,4]  R1443     -6.7869938910007477e-02
    z[3,8,4]  R1444     0.330610454082489
    z[3,8,4]  R1445     -8.7898708879947662e-02
    z[3,8,4]  R1446     1.6543485224246979e-01
    z[3,8,4]  R1447     3.1123638153076172e-01
    z[3,8,4]  R1448     -1.7848348617553711e-01
    z[3,8,4]  R1449     1.1690960079431534e-01
    z[3,8,4]  R1450     1.5920451283454895e-01
    z[3,8,4]  R1451     3.0334630608558655e-01
    z[3,8,4]  R1452     0.0460958406329155
    z[3,8,4]  R1453     2.8051629662513733e-02
    z[3,8,4]  R1454     -2.2514438629150391e-01
    z[3,8,4]  R1455     4.8451088368892670e-02
    z[3,8,4]  R1456     -2.8541529178619385e-01
    z[3,8,4]  R1457     2.3641730844974518e-01
    z[3,8,4]  R1458     -4.1492116451263428e-01
    z[3,8,4]  R1459     3.7780386209487915e-01
    z[3,8,4]  R1460     3.3900007605552673e-02
    z[3,8,4]  R1461     -5.9458520263433456e-02
    z[3,8,4]  R1462     2.0541921257972717e-01
    z[3,8,4]  R1463     9.1188631951808929e-02
    z[3,8,4]  R1464     7.1426816284656525e-02
    z[3,8,4]  R1465     -1.2145414017140865e-02
    z[3,8,4]  R1466     -2.1761940419673920e-01
    z[3,8,4]  R1467     1.8333357572555542e-01
    z[3,8,4]  R1468     1.2594452500343323e-01
    z[3,8,4]  R1469     2.7962759137153625e-01
    z[3,8,4]  R1470     5.1990884542465210e-01
    z[3,8,4]  R1471     1.6360929608345032e-01
    z[3,8,4]  R1472     9.3086190521717072e-02
    z[3,8,4]  R1473     6.1544120311737061e-01
    z[3,8,4]  R1474     -1.6038011014461517e-01
    z[3,8,4]  R1475     -4.4960159808397293e-02
    z[3,8,4]  R1476     3.2772939652204514e-02
    z[3,8,4]  R1477     2.4203942716121674e-01
    z[3,8,4]  R1478     -7.1600514650344849e-01
    z[3,8,4]  R1479     -4.7515761852264404e-01
    z[3,8,4]  R1480     -4.7687861323356628e-01
    z[3,8,4]  R1481     -1.4801302552223206e-01
    z[3,8,4]  R1482     -8.6326800286769867e-02
    z[3,8,4]  R1483     -1.1482661962509155e-01
    z[3,8,4]  R1484     -7.4615702033042908e-03
    z[3,8,4]  R1485     -1.4398986101150513e-01
    z[3,8,4]  R1486     3.1648358702659607e-01
    z[3,8,4]  R1487     8.5796646773815155e-02
    z[3,8,4]  R1488     1.6937313973903656e-01
    z[3,8,4]  R1489     3.5484090447425842e-01
    z[3,8,4]  R1490     -5.3575527854263783e-03
    z[3,8,4]  R1491     -5.2903532981872559e-02
    z[3,8,4]  R1492     -5.3471463918685913e-01
    z[3,8,4]  R1493     -0.59151291847229
    z[3,8,4]  R1494     -7.9646848142147064e-02
    z[3,8,4]  R1495     -0.0201775711029768
    z[3,8,4]  R1496     4.5154165476560593e-02
    z[3,8,4]  R1497     1.6619296371936798e-01
    z[3,8,4]  R1498     1.6266991198062897e-01
    z[3,8,4]  R1499     -3.7581852078437805e-01
    z[3,8,4]  R1500     -2.7733482420444489e-03
    z[3,8,4]  R1501     2.2970676422119141e-01
    z[3,8,4]  R1502     -1.4652857184410095e-01
    z[3,8,4]  R1503     1.3311018049716949e-01
    z[3,8,4]  R1504     2.1338362246751785e-02
    z[3,8,4]  R1505     -4.9263462424278259e-01
    z[3,8,4]  R1506     1.3779577612876892e-01
    z[3,8,4]  R1507     -3.4126002341508865e-02
    z[3,8,4]  R1508     -1.0386031121015549e-01
    z[3,8,4]  R1509     -1.1333167552947998e-02
    z[3,8,4]  R1510     1.8678863346576691e-01
    z[3,8,4]  R1511     1.9302532076835632e-02
    z[3,8,5]  R34       -1
    z[3,8,5]  R79       1
    z[3,8,5]  R1419     -1
    z[3,8,5]  R1420     1
    z[3,8,5]  R1423     -1.4690301613882184e-03
    z[3,8,5]  R1424     7.7183679677546024e-03
    z[3,8,5]  R1425     0.411602646112442
    z[3,8,5]  R1426     3.0027794837951660e-01
    z[3,8,5]  R1427     4.4443616271018982e-01
    z[3,8,5]  R1428     7.7148318290710449e-01
    z[3,8,5]  R1429     -7.3083013296127319e-02
    z[3,8,5]  R1430     3.0366408824920654e-01
    z[3,8,5]  R1431     1.6252642869949341e-01
    z[3,8,5]  R1432     1.2806795537471771e-01
    z[3,8,5]  R1433     -3.5857267677783966e-02
    z[3,8,5]  R1434     0.175323948264122
    z[3,8,5]  R1435     2.4659889936447144e-01
    z[3,8,5]  R1436     -5.7021111249923706e-01
    z[3,8,5]  R1437     -2.3316358029842377e-01
    z[3,8,5]  R1438     -7.3266260325908661e-02
    z[3,8,5]  R1439     5.0397776067256927e-02
    z[3,8,5]  R1440     4.6938300132751465e-01
    z[3,8,5]  R1441     4.2848322540521622e-02
    z[3,8,5]  R1442     -3.4131422638893127e-01
    z[3,8,5]  R1443     5.9016084671020508e-01
    z[3,8,5]  R1444     -4.1576853394508362e-01
    z[3,8,5]  R1445     -2.4785226583480835e-01
    z[3,8,5]  R1446     7.4764534831047058e-02
    z[3,8,5]  R1447     1.9420921802520752e-01
    z[3,8,5]  R1448     -3.9852684736251831e-01
    z[3,8,5]  R1449     -4.8294299840927124e-01
    z[3,8,5]  R1450     4.3299004435539246e-01
    z[3,8,5]  R1451     -4.8052871227264404e-01
    z[3,8,5]  R1452     -3.6589032411575317e-01
    z[3,8,5]  R1453     1.8955765292048454e-02
    z[3,8,5]  R1454     3.3537667989730835e-01
    z[3,8,5]  R1455     -1.8424670398235321e-01
    z[3,8,5]  R1456     -1.2360414117574692e-01
    z[3,8,5]  R1457     -2.2777855396270752e-01
    z[3,8,5]  R1458     -3.6247935891151428e-01
    z[3,8,5]  R1459     2.7795165777206421e-01
    z[3,8,5]  R1460     -1.0404511541128159e-01
    z[3,8,5]  R1461     -4.3667447566986084e-01
    z[3,8,5]  R1462     8.2699991762638092e-02
    z[3,8,5]  R1463     -2.6953813433647156e-01
    z[3,8,5]  R1464     -2.2505274415016174e-01
    z[3,8,5]  R1465     -3.7162205576896667e-01
    z[3,8,5]  R1466     -2.0590139925479889e-01
    z[3,8,5]  R1467     -3.0605033040046692e-01
    z[3,8,5]  R1468     -0.577193021774292
    z[3,8,5]  R1469     6.0814291238784790e-01
    z[3,8,5]  R1470     -1.1223967373371124e-01
    z[3,8,5]  R1471     1.0405306518077850e-01
    z[3,8,5]  R1472     -6.3074208796024323e-02
    z[3,8,5]  R1473     1.3929626345634460e-01
    z[3,8,5]  R1474     -3.5279604792594910e-01
    z[3,8,5]  R1475     3.8220237940549850e-02
    z[3,8,5]  R1476     2.1354711055755615e-01
    z[3,8,5]  R1477     -4.0999558568000793e-01
    z[3,8,5]  R1478     8.4200963377952576e-02
    z[3,8,5]  R1479     2.8404369950294495e-01
    z[3,8,5]  R1480     3.8109812140464783e-01
    z[3,8,5]  R1481     7.8728175163269043e-01
    z[3,8,5]  R1482     6.7090344429016113e-01
    z[3,8,5]  R1483     3.5295647382736206e-01
    z[3,8,5]  R1484     -2.4163994938135147e-02
    z[3,8,5]  R1485     2.7940610051155090e-01
    z[3,8,5]  R1486     2.9542475938796997e-02
    z[3,8,5]  R1487     2.8805750608444214e-01
    z[3,8,5]  R1488     -1.4151780307292938e-01
    z[3,8,5]  R1489     -5.8375686407089233e-02
    z[3,8,5]  R1490     5.0904947519302368e-01
    z[3,8,5]  R1491     -2.0721639692783356e-01
    z[3,8,5]  R1492     2.2999155521392822e-01
    z[3,8,5]  R1493     1.7055776715278625e-01
    z[3,8,5]  R1494     4.8161312937736511e-01
    z[3,8,5]  R1495     -1.8148081004619598e-01
    z[3,8,5]  R1496     0.072996124625206
    z[3,8,5]  R1497     -1.3415264897048473e-02
    z[3,8,5]  R1498     2.1625134348869324e-01
    z[3,8,5]  R1499     0.118670254945755
    z[3,8,5]  R1500     -0.221003919839859
    z[3,8,5]  R1501     -3.0883875489234924e-01
    z[3,8,5]  R1502     -1.3896717131137848e-01
    z[3,8,5]  R1503     3.2583504915237427e-01
    z[3,8,5]  R1504     -8.8345922529697418e-02
    z[3,8,5]  R1505     2.5804251432418823e-01
    z[3,8,5]  R1506     2.5488847494125366e-01
    z[3,8,5]  R1507     -0.0645069107413292
    z[3,8,5]  R1508     2.2342254221439362e-01
    z[3,8,5]  R1509     5.1044980064034462e-03
    z[3,8,5]  R1510     -2.3616391420364380e-01
    z[3,8,5]  R1511     -3.1501868367195129e-01
    z[3,8,6]  R35       -1
    z[3,8,6]  R80       1
    z[3,8,6]  R1421     -1
    z[3,8,6]  R1422     1
    z[3,8,6]  R1423     1.9739234447479248e-01
    z[3,8,6]  R1424     -3.0811837315559387e-01
    z[3,8,6]  R1425     -2.7268251776695251e-01
    z[3,8,6]  R1426     -9.2920534312725067e-02
    z[3,8,6]  R1427     -2.0176212489604950e-01
    z[3,8,6]  R1428     3.5325026512145996e-01
    z[3,8,6]  R1429     -3.3094260096549988e-01
    z[3,8,6]  R1430     1.6189102828502655e-01
    z[3,8,6]  R1431     3.0460205674171448e-01
    z[3,8,6]  R1432     3.9445933699607849e-01
    z[3,8,6]  R1433     -1.1341780424118042e-01
    z[3,8,6]  R1434     -4.6131104230880737e-01
    z[3,8,6]  R1435     1.1167629063129425e-01
    z[3,8,6]  R1436     2.3331305012106895e-02
    z[3,8,6]  R1437     9.6927117556333542e-03
    z[3,8,6]  R1438     7.5245589017868042e-02
    z[3,8,6]  R1439     5.4382622241973877e-01
    z[3,8,6]  R1440     -5.7883268594741821e-01
    z[3,8,6]  R1441     6.7323154211044312e-01
    z[3,8,6]  R1442     -4.6804344654083252e-01
    z[3,8,6]  R1443     6.6752098500728607e-02
    z[3,8,6]  R1444     9.5703966915607452e-02
    z[3,8,6]  R1445     -3.4824347496032715e-01
    z[3,8,6]  R1446     6.4936473965644836e-02
    z[3,8,6]  R1447     -1.2131937593221664e-01
    z[3,8,6]  R1448     1.2059555947780609e-01
    z[3,8,6]  R1449     -1.1474822461605072e-01
    z[3,8,6]  R1450     -4.6841281652450562e-01
    z[3,8,6]  R1451     1.1004430055618286e-01
    z[3,8,6]  R1452     3.4700807183980942e-02
    z[3,8,6]  R1453     -0.372715562582016
    z[3,8,6]  R1454     -1.0838195681571960e-01
    z[3,8,6]  R1455     -9.5185093581676483e-02
    z[3,8,6]  R1456     2.1241450309753418e-01
    z[3,8,6]  R1457     3.3925303816795349e-01
    z[3,8,6]  R1458     -8.8744185864925385e-02
    z[3,8,6]  R1459     5.7432585954666138e-01
    z[3,8,6]  R1460     4.3185046315193176e-01
    z[3,8,6]  R1461     -4.1304412484169006e-01
    z[3,8,6]  R1462     -6.9377802312374115e-02
    z[3,8,6]  R1463     -1.8144853413105011e-01
    z[3,8,6]  R1464     -2.8613728284835815e-01
    z[3,8,6]  R1465     0.54569011926651
    z[3,8,6]  R1466     2.0884558558464050e-01
    z[3,8,6]  R1467     6.5937139093875885e-02
    z[3,8,6]  R1468     -3.9090004563331604e-01
    z[3,8,6]  R1469     -2.1658392250537872e-01
    z[3,8,6]  R1470     2.0007678866386414e-01
    z[3,8,6]  R1471     5.7898283004760742e-01
    z[3,8,6]  R1472     -5.9164726734161377e-01
    z[3,8,6]  R1473     -2.7296485379338264e-02
    z[3,8,6]  R1474     -6.9551318883895874e-01
    z[3,8,6]  R1475     -9.9850669503211975e-03
    z[3,8,6]  R1476     1.2903241813182831e-01
    z[3,8,6]  R1477     0.614565372467041
    z[3,8,6]  R1478     4.7373369336128235e-01
    z[3,8,6]  R1479     -9.6105104312300682e-03
    z[3,8,6]  R1480     -1.6487258672714233e-01
    z[3,8,6]  R1481     -3.3270925283432007e-01
    z[3,8,6]  R1482     -1.5050514601171017e-02
    z[3,8,6]  R1483     2.5339301675558090e-02
    z[3,8,6]  R1484     4.1012936830520630e-01
    z[3,8,6]  R1485     -2.2790496051311493e-01
    z[3,8,6]  R1486     1.9731713831424713e-01
    z[3,8,6]  R1487     -8.0265142023563385e-02
    z[3,8,6]  R1488     -2.3283023387193680e-02
    z[3,8,6]  R1489     9.9094063043594360e-02
    z[3,8,6]  R1490     3.0142712593078613e-01
    z[3,8,6]  R1491     1.8220894038677216e-01
    z[3,8,6]  R1492     1.3260385394096375e-01
    z[3,8,6]  R1493     3.8297748565673828e-01
    z[3,8,6]  R1494     2.5355115532875061e-01
    z[3,8,6]  R1495     1.6693432629108429e-01
    z[3,8,6]  R1496     1.8298017978668213e-01
    z[3,8,6]  R1497     3.3461713790893555e-01
    z[3,8,6]  R1498     1.3354423642158508e-01
    z[3,8,6]  R1499     3.5253062844276428e-02
    z[3,8,6]  R1500     -3.4190145134925842e-01
    z[3,8,6]  R1501     3.3973187208175659e-02
    z[3,8,6]  R1502     3.8801971077919006e-01
    z[3,8,6]  R1503     3.2108667492866516e-01
    z[3,8,6]  R1504     2.4911326169967651e-01
    z[3,8,6]  R1505     2.7404436469078064e-01
    z[3,8,6]  R1506     2.4183419346809387e-01
    z[3,8,6]  R1507     -1.0881573706865311e-01
    z[3,8,6]  R1508     -2.9862526059150696e-01
    z[3,8,6]  R1509     0.0569380484521389
    z[3,8,6]  R1510     -5.3832545876502991e-02
    z[3,8,6]  R1511     -2.0913438498973846e-01
    z[8,3,0]  R29       1
    z[8,3,0]  R74       -1
    z[8,3,0]  R1512     -1
    z[8,3,0]  R1513     1
    z[8,3,0]  R1526     -5.4492527246475220e-01
    z[8,3,0]  R1527     -2.1534349024295807e-01
    z[8,3,0]  R1528     -4.7673907876014709e-01
    z[8,3,0]  R1529     -9.1472655534744263e-01
    z[8,3,0]  R1530     -4.9899551272392273e-01
    z[8,3,0]  R1531     1.7937442660331726e-01
    z[8,3,0]  R1532     8.3233872428536415e-03
    z[8,3,0]  R1533     -1.1779731512069702e-01
    z[8,3,0]  R1534     7.5718045234680176e-02
    z[8,3,0]  R1535     4.3023101985454559e-02
    z[8,3,0]  R1536     2.5510627031326294e-01
    z[8,3,0]  R1537     0.611352801322937
    z[8,3,0]  R1538     6.4501678943634033e-01
    z[8,3,0]  R1539     5.7139158248901367e-01
    z[8,3,0]  R1540     5.8158326148986816e-01
    z[8,3,0]  R1541     3.6221036314964294e-01
    z[8,3,0]  R1542     2.8853756189346313e-01
    z[8,3,0]  R1543     3.1469497084617615e-01
    z[8,3,0]  R1544     2.6581883430480957e-01
    z[8,3,0]  R1545     5.8376115560531616e-01
    z[8,3,0]  R1546     3.7380585074424744e-01
    z[8,3,0]  R1547     4.8549342155456543e-01
    z[8,3,0]  R1548     6.9221824407577515e-01
    z[8,3,0]  R1549     2.0233023166656494e-01
    z[8,3,0]  R1550     1.2574322521686554e-01
    z[8,3,0]  R1551     2.5684067606925964e-01
    z[8,3,0]  R1552     1.1671365052461624e-01
    z[8,3,0]  R1553     2.3870217800140381e-01
    z[8,3,0]  R1554     1.5381184220314026e-01
    z[8,3,0]  R1555     5.1420134305953979e-01
    z[8,3,0]  R1556     2.2655582427978516e-01
    z[8,3,0]  R1557     0.283189594745636
    z[8,3,0]  R1558     2.7601400017738342e-01
    z[8,3,0]  R1559     3.5650694370269775e-01
    z[8,3,0]  R1560     2.8758205473423004e-02
    z[8,3,0]  R1561     2.2294494509696960e-01
    z[8,3,0]  R1562     2.8574812412261963e-01
    z[8,3,0]  R1563     -5.9725034981966019e-02
    z[8,3,0]  R1564     -0.0819258838891983
    z[8,3,0]  R1565     -5.4624056816101074e-01
    z[8,3,0]  R1566     -0.424212247133255
    z[8,3,0]  R1567     7.1994647383689880e-02
    z[8,3,0]  R1568     -6.1272311210632324e-01
    z[8,3,0]  R1569     -6.4805978536605835e-01
    z[8,3,0]  R1570     -3.4386971592903137e-01
    z[8,3,0]  R1571     -8.9542247354984283e-02
    z[8,3,0]  R1572     1.1211939901113510e-01
    z[8,3,0]  R1573     -2.8060302138328552e-01
    z[8,3,0]  R1574     3.1735548377037048e-01
    z[8,3,0]  R1575     -6.1525338888168335e-01
    z[8,3,0]  R1576     -8.6321853101253510e-02
    z[8,3,0]  R1577     1.6740697622299194e-01
    z[8,3,0]  R1578     3.4569454193115234e-01
    z[8,3,0]  R1579     5.2569651603698730e-01
    z[8,3,0]  R1580     3.9396968483924866e-01
    z[8,3,0]  R1581     2.5449299812316895e-01
    z[8,3,0]  R1582     -6.4478024840354919e-02
    z[8,3,0]  R1583     -3.1391513347625732e-01
    z[8,3,0]  R1584     0.0785473957657814
    z[8,3,0]  R1585     -0.202298104763031
    z[8,3,0]  R1586     -3.6601746082305908e-01
    z[8,3,0]  R1587     1.3802783191204071e-01
    z[8,3,0]  R1588     -0.574720025062561
    z[8,3,0]  R1589     -1.1223085224628448e-01
    z[8,3,0]  R1590     -2.9490327835083008e-01
    z[8,3,0]  R1591     3.1449355185031891e-02
    z[8,3,0]  R1592     -2.7709737420082092e-02
    z[8,3,0]  R1593     -7.8968949615955353e-02
    z[8,3,0]  R1594     1.7646408081054688e-01
    z[8,3,0]  R1595     -1.8827441334724426e-01
    z[8,3,0]  R1596     -2.2635528445243835e-01
    z[8,3,0]  R1597     2.1855413913726807e-01
    z[8,3,0]  R1598     -4.7770336270332336e-02
    z[8,3,0]  R1599     1.0365481674671173e-01
    z[8,3,0]  R1600     -1.7878907918930054e-01
    z[8,3,0]  R1601     -4.6802438795566559e-02
    z[8,3,0]  R1602     -5.0883240997791290e-02
    z[8,3,0]  R1603     1.4553122222423553e-01
    z[8,3,0]  R1604     2.3893390595912933e-01
    z[8,3,0]  R1605     -8.7573036551475525e-02
    z[8,3,0]  R1606     3.5484347492456436e-02
    z[8,3,0]  R1607     -1.9336035475134850e-02
    z[8,3,0]  R1608     5.8665376156568527e-02
    z[8,3,0]  R1609     -3.2212796807289124e-01
    z[8,3,0]  R1610     2.3365199565887451e-01
    z[8,3,0]  R1611     -1.0389288514852524e-01
    z[8,3,0]  R1612     -4.9414080381393433e-01
    z[8,3,0]  R1613     -4.2689168453216553e-01
    z[8,3,0]  R1614     2.8846862912178040e-01
    z[8,3,1]  R30       1
    z[8,3,1]  R75       -1
    z[8,3,1]  R1514     -1
    z[8,3,1]  R1515     1
    z[8,3,1]  R1526     4.3278518319129944e-01
    z[8,3,1]  R1527     5.2865236997604370e-01
    z[8,3,1]  R1528     3.2280489802360535e-02
    z[8,3,1]  R1529     -1.0213023424148560e-01
    z[8,3,1]  R1530     3.5205683112144470e-01
    z[8,3,1]  R1531     0.0873582735657692
    z[8,3,1]  R1532     3.0650734901428223e-01
    z[8,3,1]  R1533     -1.1546940356492996e-01
    z[8,3,1]  R1534     -8.3069734275341034e-02
    z[8,3,1]  R1535     2.9835087060928345e-01
    z[8,3,1]  R1536     -0.0591592937707901
    z[8,3,1]  R1537     -6.5233409404754639e-02
    z[8,3,1]  R1538     -1.7246234416961670e-01
    z[8,3,1]  R1539     5.4489899426698685e-02
    z[8,3,1]  R1540     -7.5519219040870667e-02
    z[8,3,1]  R1541     -2.4127402901649475e-01
    z[8,3,1]  R1542     -6.4986400306224823e-02
    z[8,3,1]  R1543     6.6145914793014526e-01
    z[8,3,1]  R1544     -8.6502122879028320e-01
    z[8,3,1]  R1545     2.5387245416641235e-01
    z[8,3,1]  R1546     3.3545008301734924e-01
    z[8,3,1]  R1547     0.605156421661377
    z[8,3,1]  R1548     1.9629713892936707e-01
    z[8,3,1]  R1549     -0.922296404838562
    z[8,3,1]  R1550     -9.0870171785354614e-01
    z[8,3,1]  R1551     -9.0678805112838745e-01
    z[8,3,1]  R1552     -9.0038394927978516e-01
    z[8,3,1]  R1553     -8.7704312801361084e-01
    z[8,3,1]  R1554     -8.8701063394546509e-01
    z[8,3,1]  R1555     1.3998055458068848e-01
    z[8,3,1]  R1556     4.0884265303611755e-01
    z[8,3,1]  R1557     2.9602622613310814e-02
    z[8,3,1]  R1558     2.5092095136642456e-02
    z[8,3,1]  R1559     4.8419770598411560e-01
    z[8,3,1]  R1560     -0.950893223285675
    z[8,3,1]  R1561     -8.8206022977828979e-01
    z[8,3,1]  R1562     -8.9106363058090210e-01
    z[8,3,1]  R1563     -7.3857551813125610e-01
    z[8,3,1]  R1564     -6.0511809587478638e-01
    z[8,3,1]  R1565     7.9328608512878418e-01
    z[8,3,1]  R1566     7.6735401153564453e-01
    z[8,3,1]  R1567     6.3840603828430176e-01
    z[8,3,1]  R1568     1.1874987185001373e-01
    z[8,3,1]  R1569     1.6845221817493439e-01
    z[8,3,1]  R1570     1.1892323940992355e-01
    z[8,3,1]  R1571     -4.9029093235731125e-02
    z[8,3,1]  R1572     -2.0932072773575783e-02
    z[8,3,1]  R1573     -5.1081206649541855e-02
    z[8,3,1]  R1574     -4.6568468213081360e-02
    z[8,3,1]  R1575     -6.5252298116683960e-01
    z[8,3,1]  R1576     -6.6241371631622314e-01
    z[8,3,1]  R1577     -6.3512933254241943e-01
    z[8,3,1]  R1578     -5.6671643257141113e-01
    z[8,3,1]  R1579     -5.8184927701950073e-01
    z[8,3,1]  R1580     -8.0940610170364380e-01
    z[8,3,1]  R1581     -5.6583595275878906e-01
    z[8,3,1]  R1582     -5.6445431709289551e-01
    z[8,3,1]  R1583     -6.2445646524429321e-01
    z[8,3,1]  R1584     -5.3245031833648682e-01
    z[8,3,1]  R1585     -7.7334809303283691e-01
    z[8,3,1]  R1586     -6.9144630432128906e-01
    z[8,3,1]  R1587     -0.743336021900177
    z[8,3,1]  R1588     -6.4037960767745972e-01
    z[8,3,1]  R1589     4.4405010342597961e-01
    z[8,3,1]  R1590     -6.9568479061126709e-01
    z[8,3,1]  R1591     0.522428035736084
    z[8,3,1]  R1592     -5.3287369012832642e-01
    z[8,3,1]  R1593     4.8844003677368164e-01
    z[8,3,1]  R1594     6.3939177989959717e-01
    z[8,3,1]  R1595     -8.4677040576934814e-01
    z[8,3,1]  R1596     -8.7058031558990479e-01
    z[8,3,1]  R1597     -8.9668089151382446e-01
    z[8,3,1]  R1598     -7.2005736827850342e-01
    z[8,3,1]  R1599     -6.7852222919464111e-01
    z[8,3,1]  R1600     0.713131844997406
    z[8,3,1]  R1601     -6.1013668775558472e-01
    z[8,3,1]  R1602     -6.1674284934997559e-01
    z[8,3,1]  R1603     6.5785801410675049e-01
    z[8,3,1]  R1604     8.5632407665252686e-01
    z[8,3,1]  R1605     6.4206200838088989e-01
    z[8,3,1]  R1606     8.7107646465301514e-01
    z[8,3,1]  R1607     -7.5011372566223145e-01
    z[8,3,1]  R1608     -8.7947982549667358e-01
    z[8,3,1]  R1609     4.7453027963638306e-01
    z[8,3,1]  R1610     -6.2827903032302856e-01
    z[8,3,1]  R1611     6.8753391504287720e-01
    z[8,3,1]  R1612     3.6887449026107788e-01
    z[8,3,1]  R1613     3.3512553572654724e-01
    z[8,3,1]  R1614     -0.559316098690033
    z[8,3,2]  R31       1
    z[8,3,2]  R76       -1
    z[8,3,2]  R1516     -1
    z[8,3,2]  R1517     1
    z[8,3,2]  R1526     4.4297706335783005e-02
    z[8,3,2]  R1527     -1.0253424942493439e-01
    z[8,3,2]  R1528     3.4196120500564575e-01
    z[8,3,2]  R1529     1.9986394047737122e-01
    z[8,3,2]  R1530     -8.1668362021446228e-02
    z[8,3,2]  R1531     2.2891965508460999e-01
    z[8,3,2]  R1532     5.2468216419219971e-01
    z[8,3,2]  R1533     -3.9801257848739624e-01
    z[8,3,2]  R1534     -4.8457396030426025e-01
    z[8,3,2]  R1535     -6.3851737976074219e-01
    z[8,3,2]  R1536     -3.4500178694725037e-01
    z[8,3,2]  R1537     -3.0746594071388245e-02
    z[8,3,2]  R1538     0.0672302395105362
    z[8,3,2]  R1539     -1.6945162415504456e-01
    z[8,3,2]  R1540     3.5668212175369263e-01
    z[8,3,2]  R1541     4.5615750551223755e-01
    z[8,3,2]  R1542     1.0421478748321533e-01
    z[8,3,2]  R1543     2.2317555546760559e-01
    z[8,3,2]  R1544     1.8342211842536926e-01
    z[8,3,2]  R1545     3.2977712154388428e-01
    z[8,3,2]  R1546     2.5324460864067078e-01
    z[8,3,2]  R1547     2.0797833800315857e-01
    z[8,3,2]  R1548     5.5952745676040649e-01
    z[8,3,2]  R1549     -1.7250286042690277e-01
    z[8,3,2]  R1550     1.0942266322672367e-02
    z[8,3,2]  R1551     -9.7748890519142151e-02
    z[8,3,2]  R1552     -1.1095040291547775e-01
    z[8,3,2]  R1553     8.1540994346141815e-02
    z[8,3,2]  R1554     1.9990071654319763e-02
    z[8,3,2]  R1555     3.3385327458381653e-01
    z[8,3,2]  R1556     -6.5134182572364807e-02
    z[8,3,2]  R1557     4.1693288087844849e-01
    z[8,3,2]  R1558     -3.3540013432502747e-01
    z[8,3,2]  R1559     3.5556885600090027e-01
    z[8,3,2]  R1560     -1.6824441030621529e-02
    z[8,3,2]  R1561     1.4960496127605438e-01
    z[8,3,2]  R1562     3.2649624347686768e-01
    z[8,3,2]  R1563     -5.8190923929214478e-01
    z[8,3,2]  R1564     -5.5336314439773560e-01
    z[8,3,2]  R1565     2.4101685732603073e-02
    z[8,3,2]  R1566     -1.2400750815868378e-01
    z[8,3,2]  R1567     5.2930307388305664e-01
    z[8,3,2]  R1568     5.2981162071228027e-01
    z[8,3,2]  R1569     5.2514404058456421e-01
    z[8,3,2]  R1570     3.1009066104888916e-01
    z[8,3,2]  R1571     -4.4367730617523193e-01
    z[8,3,2]  R1572     -8.0586922168731689e-01
    z[8,3,2]  R1573     -7.8454381227493286e-01
    z[8,3,2]  R1574     8.0022051930427551e-02
    z[8,3,2]  R1575     0.0970572754740715
    z[8,3,2]  R1576     0.152975931763649
    z[8,3,2]  R1577     3.4097391366958618e-01
    z[8,3,2]  R1578     -3.8507252931594849e-01
    z[8,3,2]  R1579     -6.8089894950389862e-02
    z[8,3,2]  R1580     -2.3545506596565247e-01
    z[8,3,2]  R1581     -5.0401028245687485e-02
    z[8,3,2]  R1582     8.3726853132247925e-02
    z[8,3,2]  R1583     1.0667237639427185e-01
    z[8,3,2]  R1584     -2.7492982149124146e-01
    z[8,3,2]  R1585     -4.1653178632259369e-02
    z[8,3,2]  R1586     2.7315405011177063e-01
    z[8,3,2]  R1587     1.5096355974674225e-01
    z[8,3,2]  R1588     4.1382029652595520e-01
    z[8,3,2]  R1589     5.0347495079040527e-01
    z[8,3,2]  R1590     -9.3935750424861908e-02
    z[8,3,2]  R1591     4.3033921718597412e-01
    z[8,3,2]  R1592     -4.3597763776779175e-01
    z[8,3,2]  R1593     1.1288274079561234e-01
    z[8,3,2]  R1594     6.4795380830764771e-01
    z[8,3,2]  R1595     -2.4157375097274780e-01
    z[8,3,2]  R1596     -3.2371073961257935e-02
    z[8,3,2]  R1597     0.0947737991809845
    z[8,3,2]  R1598     -2.7153888344764709e-01
    z[8,3,2]  R1599     -5.3877639770507812e-01
    z[8,3,2]  R1600     3.5098394751548767e-01
    z[8,3,2]  R1601     -2.7506032586097717e-01
    z[8,3,2]  R1602     3.3013519644737244e-01
    z[8,3,2]  R1603     3.1272286176681519e-01
    z[8,3,2]  R1604     3.6370927095413208e-01
    z[8,3,2]  R1605     4.2421030998229980e-01
    z[8,3,2]  R1606     1.8731613457202911e-01
    z[8,3,2]  R1607     2.3560628294944763e-02
    z[8,3,2]  R1608     2.8810295462608337e-01
    z[8,3,2]  R1609     1.2663708627223969e-01
    z[8,3,2]  R1610     -3.2625325024127960e-02
    z[8,3,2]  R1611     2.0188353955745697e-02
    z[8,3,2]  R1612     4.5583987236022949e-01
    z[8,3,2]  R1613     5.1397567987442017e-01
    z[8,3,2]  R1614     0.0961170494556427
    z[8,3,3]  R32       1
    z[8,3,3]  R77       -1
    z[8,3,3]  R1518     -1
    z[8,3,3]  R1519     1
    z[8,3,3]  R1526     3.3893135190010071e-01
    z[8,3,3]  R1527     1.7238068580627441e-01
    z[8,3,3]  R1528     -8.0694389343261719e-01
    z[8,3,3]  R1529     2.2265070676803589e-01
    z[8,3,3]  R1530     -1.2656930088996887e-01
    z[8,3,3]  R1531     4.0449026226997375e-01
    z[8,3,3]  R1532     -0.569337010383606
    z[8,3,3]  R1533     -6.4385145902633667e-01
    z[8,3,3]  R1534     1.1762108653783798e-02
    z[8,3,3]  R1535     -2.0890416204929352e-01
    z[8,3,3]  R1536     0.820968508720398
    z[8,3,3]  R1537     6.7245924472808838e-01
    z[8,3,3]  R1538     6.3162380456924438e-01
    z[8,3,3]  R1539     7.0842069387435913e-01
    z[8,3,3]  R1540     6.5730887651443481e-01
    z[8,3,3]  R1541     7.4381065368652344e-01
    z[8,3,3]  R1542     8.7322556972503662e-01
    z[8,3,3]  R1543     2.5221675634384155e-01
    z[8,3,3]  R1544     -2.6172018051147461e-01
    z[8,3,3]  R1545     3.6002656817436218e-01
    z[8,3,3]  R1546     3.9744228124618530e-01
    z[8,3,3]  R1547     2.2856892645359039e-01
    z[8,3,3]  R1548     3.2866531610488892e-01
    z[8,3,3]  R1549     -1.9448810815811157e-01
    z[8,3,3]  R1550     -1.3624049723148346e-01
    z[8,3,3]  R1551     1.0560864955186844e-01
    z[8,3,3]  R1552     8.2533389329910278e-02
    z[8,3,3]  R1553     3.7692766636610031e-02
    z[8,3,3]  R1554     1.9963359832763672e-01
    z[8,3,3]  R1555     6.4280843734741211e-01
    z[8,3,3]  R1556     7.4181818962097168e-01
    z[8,3,3]  R1557     8.2144778966903687e-01
    z[8,3,3]  R1558     6.5293055772781372e-01
    z[8,3,3]  R1559     6.0793638229370117e-01
    z[8,3,3]  R1560     -2.7843394875526428e-01
    z[8,3,3]  R1561     -1.4027177821844816e-03
    z[8,3,3]  R1562     -1.1982208490371704e-01
    z[8,3,3]  R1563     -1.3696564733982086e-01
    z[8,3,3]  R1564     -4.2138215899467468e-01
    z[8,3,3]  R1565     1.5139020979404449e-01
    z[8,3,3]  R1566     2.9603728652000427e-01
    z[8,3,3]  R1567     1.5822613239288330e-01
    z[8,3,3]  R1568     2.4612200260162354e-01
    z[8,3,3]  R1569     1.1945197731256485e-01
    z[8,3,3]  R1570     0.0224288459867239
    z[8,3,3]  R1571     -5.5111384391784668e-01
    z[8,3,3]  R1572     4.6425831317901611e-01
    z[8,3,3]  R1573     -4.1696190834045410e-01
    z[8,3,3]  R1574     -8.2614302635192871e-01
    z[8,3,3]  R1575     -4.0400597453117371e-01
    z[8,3,3]  R1576     -0.0763794332742691
    z[8,3,3]  R1577     -2.2706650197505951e-01
    z[8,3,3]  R1578     -7.7574424445629120e-02
    z[8,3,3]  R1579     -5.6893610954284668e-01
    z[8,3,3]  R1580     -3.5073789954185486e-01
    z[8,3,3]  R1581     -1.8418912589550018e-01
    z[8,3,3]  R1582     3.3512806892395020e-01
    z[8,3,3]  R1583     1.7176859080791473e-01
    z[8,3,3]  R1584     -1.3978110253810883e-01
    z[8,3,3]  R1585     -4.3832760304212570e-02
    z[8,3,3]  R1586     0.148304283618927
    z[8,3,3]  R1587     4.6387454867362976e-01
    z[8,3,3]  R1588     2.2624848783016205e-01
    z[8,3,3]  R1589     6.2244117259979248e-01
    z[8,3,3]  R1590     4.6368911862373352e-01
    z[8,3,3]  R1591     5.2992373704910278e-01
    z[8,3,3]  R1592     -3.0490031838417053e-01
    z[8,3,3]  R1593     6.3828772306442261e-01
    z[8,3,3]  R1594     5.4679099470376968e-02
    z[8,3,3]  R1595     2.2161155939102173e-01
    z[8,3,3]  R1596     1.2202896922826767e-01
    z[8,3,3]  R1597     3.0636712908744812e-01
    z[8,3,3]  R1598     -5.1346111297607422e-01
    z[8,3,3]  R1599     -0.125356987118721
    z[8,3,3]  R1600     -1.5767522156238556e-01
    z[8,3,3]  R1601     -0.00643932493403554
    z[8,3,3]  R1602     -5.5639952421188354e-01
    z[8,3,3]  R1603     2.8882962465286255e-01
    z[8,3,3]  R1604     -1.5325054526329041e-01
    z[8,3,3]  R1605     5.3501695394515991e-01
    z[8,3,3]  R1606     2.5933426618576050e-01
    z[8,3,3]  R1607     -1.9293682649731636e-02
    z[8,3,3]  R1608     -8.1855103373527527e-02
    z[8,3,3]  R1609     7.2345834970474243e-01
    z[8,3,3]  R1610     -2.1861200034618378e-01
    z[8,3,3]  R1611     1.4545749127864838e-01
    z[8,3,3]  R1612     2.9838341474533081e-01
    z[8,3,3]  R1613     2.6166230440139771e-01
    z[8,3,3]  R1614     -4.8168757557868958e-01
    z[8,3,4]  R33       1
    z[8,3,4]  R78       -1
    z[8,3,4]  R1520     -1
    z[8,3,4]  R1521     1
    z[8,3,4]  R1526     6.1544120311737061e-01
    z[8,3,4]  R1527     -1.6038011014461517e-01
    z[8,3,4]  R1528     -4.4960159808397293e-02
    z[8,3,4]  R1529     3.2772939652204514e-02
    z[8,3,4]  R1530     2.4203942716121674e-01
    z[8,3,4]  R1531     -7.1600514650344849e-01
    z[8,3,4]  R1532     -4.7515761852264404e-01
    z[8,3,4]  R1533     -4.7687861323356628e-01
    z[8,3,4]  R1534     -1.4801302552223206e-01
    z[8,3,4]  R1535     -8.6326800286769867e-02
    z[8,3,4]  R1536     -1.1482661962509155e-01
    z[8,3,4]  R1537     -7.4615702033042908e-03
    z[8,3,4]  R1538     -1.4398986101150513e-01
    z[8,3,4]  R1539     3.1648358702659607e-01
    z[8,3,4]  R1540     8.5796646773815155e-02
    z[8,3,4]  R1541     1.6937313973903656e-01
    z[8,3,4]  R1542     3.5484090447425842e-01
    z[8,3,4]  R1543     -5.3575527854263783e-03
    z[8,3,4]  R1544     -5.2903532981872559e-02
    z[8,3,4]  R1545     -5.3471463918685913e-01
    z[8,3,4]  R1546     -0.59151291847229
    z[8,3,4]  R1547     -7.9646848142147064e-02
    z[8,3,4]  R1548     -0.0201775711029768
    z[8,3,4]  R1549     4.5154165476560593e-02
    z[8,3,4]  R1550     1.6619296371936798e-01
    z[8,3,4]  R1551     1.6266991198062897e-01
    z[8,3,4]  R1552     -3.7581852078437805e-01
    z[8,3,4]  R1553     -2.7733482420444489e-03
    z[8,3,4]  R1554     2.2970676422119141e-01
    z[8,3,4]  R1555     -1.4652857184410095e-01
    z[8,3,4]  R1556     1.3311018049716949e-01
    z[8,3,4]  R1557     2.1338362246751785e-02
    z[8,3,4]  R1558     -4.9263462424278259e-01
    z[8,3,4]  R1559     1.3779577612876892e-01
    z[8,3,4]  R1560     -3.4126002341508865e-02
    z[8,3,4]  R1561     -1.0386031121015549e-01
    z[8,3,4]  R1562     -1.1333167552947998e-02
    z[8,3,4]  R1563     1.8678863346576691e-01
    z[8,3,4]  R1564     1.9302532076835632e-02
    z[8,3,4]  R1565     -9.9260888993740082e-02
    z[8,3,4]  R1566     -1.8220679461956024e-01
    z[8,3,4]  R1567     1.9566479325294495e-01
    z[8,3,4]  R1568     -4.1278502345085144e-01
    z[8,3,4]  R1569     1.5285915136337280e-01
    z[8,3,4]  R1570     2.2578676044940948e-01
    z[8,3,4]  R1571     -6.1166834831237793e-01
    z[8,3,4]  R1572     6.0078907757997513e-02
    z[8,3,4]  R1573     -1.0044468194246292e-01
    z[8,3,4]  R1574     1.9026717543601990e-01
    z[8,3,4]  R1575     -0.0942695364356041
    z[8,3,4]  R1576     -0.530070424079895
    z[8,3,4]  R1577     0.572259247303009
    z[8,3,4]  R1578     0.281680703163147
    z[8,3,4]  R1579     4.8072297126054764e-02
    z[8,3,4]  R1580     1.2790170498192310e-02
    z[8,3,4]  R1581     5.2944332361221313e-01
    z[8,3,4]  R1582     5.0449732691049576e-02
    z[8,3,4]  R1583     1.2470442801713943e-01
    z[8,3,4]  R1584     -5.2881163358688354e-01
    z[8,3,4]  R1585     -6.7869938910007477e-02
    z[8,3,4]  R1586     0.330610454082489
    z[8,3,4]  R1587     -8.7898708879947662e-02
    z[8,3,4]  R1588     1.6543485224246979e-01
    z[8,3,4]  R1589     3.1123638153076172e-01
    z[8,3,4]  R1590     -1.7848348617553711e-01
    z[8,3,4]  R1591     1.1690960079431534e-01
    z[8,3,4]  R1592     1.5920451283454895e-01
    z[8,3,4]  R1593     3.0334630608558655e-01
    z[8,3,4]  R1594     0.0460958406329155
    z[8,3,4]  R1595     2.8051629662513733e-02
    z[8,3,4]  R1596     -2.2514438629150391e-01
    z[8,3,4]  R1597     4.8451088368892670e-02
    z[8,3,4]  R1598     -2.8541529178619385e-01
    z[8,3,4]  R1599     2.3641730844974518e-01
    z[8,3,4]  R1600     -4.1492116451263428e-01
    z[8,3,4]  R1601     3.7780386209487915e-01
    z[8,3,4]  R1602     3.3900007605552673e-02
    z[8,3,4]  R1603     -5.9458520263433456e-02
    z[8,3,4]  R1604     2.0541921257972717e-01
    z[8,3,4]  R1605     9.1188631951808929e-02
    z[8,3,4]  R1606     7.1426816284656525e-02
    z[8,3,4]  R1607     -1.2145414017140865e-02
    z[8,3,4]  R1608     -2.1761940419673920e-01
    z[8,3,4]  R1609     1.8333357572555542e-01
    z[8,3,4]  R1610     1.2594452500343323e-01
    z[8,3,4]  R1611     2.7962759137153625e-01
    z[8,3,4]  R1612     5.1990884542465210e-01
    z[8,3,4]  R1613     1.6360929608345032e-01
    z[8,3,4]  R1614     9.3086190521717072e-02
    z[8,3,5]  R34       1
    z[8,3,5]  R79       -1
    z[8,3,5]  R1522     -1
    z[8,3,5]  R1523     1
    z[8,3,5]  R1526     1.3929626345634460e-01
    z[8,3,5]  R1527     -3.5279604792594910e-01
    z[8,3,5]  R1528     3.8220237940549850e-02
    z[8,3,5]  R1529     2.1354711055755615e-01
    z[8,3,5]  R1530     -4.0999558568000793e-01
    z[8,3,5]  R1531     8.4200963377952576e-02
    z[8,3,5]  R1532     2.8404369950294495e-01
    z[8,3,5]  R1533     3.8109812140464783e-01
    z[8,3,5]  R1534     7.8728175163269043e-01
    z[8,3,5]  R1535     6.7090344429016113e-01
    z[8,3,5]  R1536     3.5295647382736206e-01
    z[8,3,5]  R1537     -2.4163994938135147e-02
    z[8,3,5]  R1538     2.7940610051155090e-01
    z[8,3,5]  R1539     2.9542475938796997e-02
    z[8,3,5]  R1540     2.8805750608444214e-01
    z[8,3,5]  R1541     -1.4151780307292938e-01
    z[8,3,5]  R1542     -5.8375686407089233e-02
    z[8,3,5]  R1543     5.0904947519302368e-01
    z[8,3,5]  R1544     -2.0721639692783356e-01
    z[8,3,5]  R1545     2.2999155521392822e-01
    z[8,3,5]  R1546     1.7055776715278625e-01
    z[8,3,5]  R1547     4.8161312937736511e-01
    z[8,3,5]  R1548     -1.8148081004619598e-01
    z[8,3,5]  R1549     0.072996124625206
    z[8,3,5]  R1550     -1.3415264897048473e-02
    z[8,3,5]  R1551     2.1625134348869324e-01
    z[8,3,5]  R1552     0.118670254945755
    z[8,3,5]  R1553     -0.221003919839859
    z[8,3,5]  R1554     -3.0883875489234924e-01
    z[8,3,5]  R1555     -1.3896717131137848e-01
    z[8,3,5]  R1556     3.2583504915237427e-01
    z[8,3,5]  R1557     -8.8345922529697418e-02
    z[8,3,5]  R1558     2.5804251432418823e-01
    z[8,3,5]  R1559     2.5488847494125366e-01
    z[8,3,5]  R1560     -0.0645069107413292
    z[8,3,5]  R1561     2.2342254221439362e-01
    z[8,3,5]  R1562     5.1044980064034462e-03
    z[8,3,5]  R1563     -2.3616391420364380e-01
    z[8,3,5]  R1564     -3.1501868367195129e-01
    z[8,3,5]  R1565     -1.4690301613882184e-03
    z[8,3,5]  R1566     7.7183679677546024e-03
    z[8,3,5]  R1567     0.411602646112442
    z[8,3,5]  R1568     3.0027794837951660e-01
    z[8,3,5]  R1569     4.4443616271018982e-01
    z[8,3,5]  R1570     7.7148318290710449e-01
    z[8,3,5]  R1571     -7.3083013296127319e-02
    z[8,3,5]  R1572     3.0366408824920654e-01
    z[8,3,5]  R1573     1.6252642869949341e-01
    z[8,3,5]  R1574     1.2806795537471771e-01
    z[8,3,5]  R1575     -3.5857267677783966e-02
    z[8,3,5]  R1576     0.175323948264122
    z[8,3,5]  R1577     2.4659889936447144e-01
    z[8,3,5]  R1578     -5.7021111249923706e-01
    z[8,3,5]  R1579     -2.3316358029842377e-01
    z[8,3,5]  R1580     -7.3266260325908661e-02
    z[8,3,5]  R1581     5.0397776067256927e-02
    z[8,3,5]  R1582     4.6938300132751465e-01
    z[8,3,5]  R1583     4.2848322540521622e-02
    z[8,3,5]  R1584     -3.4131422638893127e-01
    z[8,3,5]  R1585     5.9016084671020508e-01
    z[8,3,5]  R1586     -4.1576853394508362e-01
    z[8,3,5]  R1587     -2.4785226583480835e-01
    z[8,3,5]  R1588     7.4764534831047058e-02
    z[8,3,5]  R1589     1.9420921802520752e-01
    z[8,3,5]  R1590     -3.9852684736251831e-01
    z[8,3,5]  R1591     -4.8294299840927124e-01
    z[8,3,5]  R1592     4.3299004435539246e-01
    z[8,3,5]  R1593     -4.8052871227264404e-01
    z[8,3,5]  R1594     -3.6589032411575317e-01
    z[8,3,5]  R1595     1.8955765292048454e-02
    z[8,3,5]  R1596     3.3537667989730835e-01
    z[8,3,5]  R1597     -1.8424670398235321e-01
    z[8,3,5]  R1598     -1.2360414117574692e-01
    z[8,3,5]  R1599     -2.2777855396270752e-01
    z[8,3,5]  R1600     -3.6247935891151428e-01
    z[8,3,5]  R1601     2.7795165777206421e-01
    z[8,3,5]  R1602     -1.0404511541128159e-01
    z[8,3,5]  R1603     -4.3667447566986084e-01
    z[8,3,5]  R1604     8.2699991762638092e-02
    z[8,3,5]  R1605     -2.6953813433647156e-01
    z[8,3,5]  R1606     -2.2505274415016174e-01
    z[8,3,5]  R1607     -3.7162205576896667e-01
    z[8,3,5]  R1608     -2.0590139925479889e-01
    z[8,3,5]  R1609     -3.0605033040046692e-01
    z[8,3,5]  R1610     -0.577193021774292
    z[8,3,5]  R1611     6.0814291238784790e-01
    z[8,3,5]  R1612     -1.1223967373371124e-01
    z[8,3,5]  R1613     1.0405306518077850e-01
    z[8,3,5]  R1614     -6.3074208796024323e-02
    z[8,3,6]  R35       1
    z[8,3,6]  R80       -1
    z[8,3,6]  R1524     -1
    z[8,3,6]  R1525     1
    z[8,3,6]  R1526     -2.7296485379338264e-02
    z[8,3,6]  R1527     -6.9551318883895874e-01
    z[8,3,6]  R1528     -9.9850669503211975e-03
    z[8,3,6]  R1529     1.2903241813182831e-01
    z[8,3,6]  R1530     0.614565372467041
    z[8,3,6]  R1531     4.7373369336128235e-01
    z[8,3,6]  R1532     -9.6105104312300682e-03
    z[8,3,6]  R1533     -1.6487258672714233e-01
    z[8,3,6]  R1534     -3.3270925283432007e-01
    z[8,3,6]  R1535     -1.5050514601171017e-02
    z[8,3,6]  R1536     2.5339301675558090e-02
    z[8,3,6]  R1537     4.1012936830520630e-01
    z[8,3,6]  R1538     -2.2790496051311493e-01
    z[8,3,6]  R1539     1.9731713831424713e-01
    z[8,3,6]  R1540     -8.0265142023563385e-02
    z[8,3,6]  R1541     -2.3283023387193680e-02
    z[8,3,6]  R1542     9.9094063043594360e-02
    z[8,3,6]  R1543     3.0142712593078613e-01
    z[8,3,6]  R1544     1.8220894038677216e-01
    z[8,3,6]  R1545     1.3260385394096375e-01
    z[8,3,6]  R1546     3.8297748565673828e-01
    z[8,3,6]  R1547     2.5355115532875061e-01
    z[8,3,6]  R1548     1.6693432629108429e-01
    z[8,3,6]  R1549     1.8298017978668213e-01
    z[8,3,6]  R1550     3.3461713790893555e-01
    z[8,3,6]  R1551     1.3354423642158508e-01
    z[8,3,6]  R1552     3.5253062844276428e-02
    z[8,3,6]  R1553     -3.4190145134925842e-01
    z[8,3,6]  R1554     3.3973187208175659e-02
    z[8,3,6]  R1555     3.8801971077919006e-01
    z[8,3,6]  R1556     3.2108667492866516e-01
    z[8,3,6]  R1557     2.4911326169967651e-01
    z[8,3,6]  R1558     2.7404436469078064e-01
    z[8,3,6]  R1559     2.4183419346809387e-01
    z[8,3,6]  R1560     -1.0881573706865311e-01
    z[8,3,6]  R1561     -2.9862526059150696e-01
    z[8,3,6]  R1562     0.0569380484521389
    z[8,3,6]  R1563     -5.3832545876502991e-02
    z[8,3,6]  R1564     -2.0913438498973846e-01
    z[8,3,6]  R1565     1.9739234447479248e-01
    z[8,3,6]  R1566     -3.0811837315559387e-01
    z[8,3,6]  R1567     -2.7268251776695251e-01
    z[8,3,6]  R1568     -9.2920534312725067e-02
    z[8,3,6]  R1569     -2.0176212489604950e-01
    z[8,3,6]  R1570     3.5325026512145996e-01
    z[8,3,6]  R1571     -3.3094260096549988e-01
    z[8,3,6]  R1572     1.6189102828502655e-01
    z[8,3,6]  R1573     3.0460205674171448e-01
    z[8,3,6]  R1574     3.9445933699607849e-01
    z[8,3,6]  R1575     -1.1341780424118042e-01
    z[8,3,6]  R1576     -4.6131104230880737e-01
    z[8,3,6]  R1577     1.1167629063129425e-01
    z[8,3,6]  R1578     2.3331305012106895e-02
    z[8,3,6]  R1579     9.6927117556333542e-03
    z[8,3,6]  R1580     7.5245589017868042e-02
    z[8,3,6]  R1581     5.4382622241973877e-01
    z[8,3,6]  R1582     -5.7883268594741821e-01
    z[8,3,6]  R1583     6.7323154211044312e-01
    z[8,3,6]  R1584     -4.6804344654083252e-01
    z[8,3,6]  R1585     6.6752098500728607e-02
    z[8,3,6]  R1586     9.5703966915607452e-02
    z[8,3,6]  R1587     -3.4824347496032715e-01
    z[8,3,6]  R1588     6.4936473965644836e-02
    z[8,3,6]  R1589     -1.2131937593221664e-01
    z[8,3,6]  R1590     1.2059555947780609e-01
    z[8,3,6]  R1591     -1.1474822461605072e-01
    z[8,3,6]  R1592     -4.6841281652450562e-01
    z[8,3,6]  R1593     1.1004430055618286e-01
    z[8,3,6]  R1594     3.4700807183980942e-02
    z[8,3,6]  R1595     -0.372715562582016
    z[8,3,6]  R1596     -1.0838195681571960e-01
    z[8,3,6]  R1597     -9.5185093581676483e-02
    z[8,3,6]  R1598     2.1241450309753418e-01
    z[8,3,6]  R1599     3.3925303816795349e-01
    z[8,3,6]  R1600     -8.8744185864925385e-02
    z[8,3,6]  R1601     5.7432585954666138e-01
    z[8,3,6]  R1602     4.3185046315193176e-01
    z[8,3,6]  R1603     -4.1304412484169006e-01
    z[8,3,6]  R1604     -6.9377802312374115e-02
    z[8,3,6]  R1605     -1.8144853413105011e-01
    z[8,3,6]  R1606     -2.8613728284835815e-01
    z[8,3,6]  R1607     0.54569011926651
    z[8,3,6]  R1608     2.0884558558464050e-01
    z[8,3,6]  R1609     6.5937139093875885e-02
    z[8,3,6]  R1610     -3.9090004563331604e-01
    z[8,3,6]  R1611     -2.1658392250537872e-01
    z[8,3,6]  R1612     2.0007678866386414e-01
    z[8,3,6]  R1613     5.7898283004760742e-01
    z[8,3,6]  R1614     -5.9164726734161377e-01
    z[4,8,0]  R38       -1
    z[4,8,0]  R74       1
    z[4,8,0]  R1615     -1
    z[4,8,0]  R1616     1
    z[4,8,0]  R1629     -7.8451806306838989e-01
    z[4,8,0]  R1630     -2.3863452672958374e-01
    z[4,8,0]  R1631     -4.2138642072677612e-01
    z[4,8,0]  R1632     -2.3271121084690094e-01
    z[4,8,0]  R1633     9.3946374952793121e-02
    z[4,8,0]  R1634     -6.3066649436950684e-01
    z[4,8,0]  R1635     -2.2421675920486450e-01
    z[4,8,0]  R1636     0.221639484167099
    z[4,8,0]  R1637     2.5867444276809692e-01
    z[4,8,0]  R1638     2.9126021265983582e-01
    z[4,8,0]  R1639     3.7454894185066223e-01
    z[4,8,0]  R1640     2.7899321913719177e-01
    z[4,8,0]  R1641     3.8191944360733032e-01
    z[4,8,0]  R1642     2.9376068711280823e-01
    z[4,8,0]  R1643     -0.0978270173072815
    z[4,8,0]  R1644     -2.9137728735804558e-02
    z[4,8,0]  R1645     7.4456967413425446e-02
    z[4,8,0]  R1646     1.8401703238487244e-01
    z[4,8,0]  R1647     0.302244633436203
    z[4,8,0]  R1648     1.1519994586706161e-01
    z[4,8,0]  R1649     -3.0517500638961792e-01
    z[4,8,0]  R1650     4.6974033117294312e-01
    z[4,8,0]  R1651     4.7435140609741211e-01
    z[4,8,0]  R1652     -2.6120521128177643e-02
    z[4,8,0]  R1653     0.317367821931839
    z[4,8,0]  R1654     -1.7612075433135033e-02
    z[4,8,0]  R1655     -1.6793097555637360e-01
    z[4,8,0]  R1656     -1.0067898780107498e-01
    z[4,8,0]  R1657     -1.6538232564926147e-02
    z[4,8,0]  R1658     -1.2822266668081284e-02
    z[4,8,0]  R1659     3.6187297105789185e-01
    z[4,8,0]  R1660     2.9852783679962158e-01
    z[4,8,0]  R1661     3.7791994214057922e-01
    z[4,8,0]  R1662     -3.7840750813484192e-01
    z[4,8,0]  R1663     -2.8823024034500122e-01
    z[4,8,0]  R1664     2.5137278437614441e-01
    z[4,8,0]  R1665     3.0971741676330566e-01
    z[4,8,0]  R1666     -0.0793575644493103
    z[4,8,0]  R1667     -1.8650509417057037e-01
    z[4,8,0]  R1668     1.6907888650894165e-01
    z[4,8,0]  R1669     3.1163122504949570e-02
    z[4,8,0]  R1670     1.5796346962451935e-01
    z[4,8,0]  R1671     2.8270235657691956e-01
    z[4,8,0]  R1672     -3.6034090444445610e-03
    z[4,8,0]  R1673     -1.9155786931514740e-01
    z[4,8,0]  R1674     -1.3722683489322662e-01
    z[4,8,0]  R1675     -2.5865417718887329e-01
    z[4,8,0]  R1676     -3.6463830620050430e-02
    z[4,8,0]  R1677     7.2248607873916626e-01
    z[4,8,0]  R1678     -9.6755206584930420e-02
    z[4,8,0]  R1679     -0.223170205950737
    z[4,8,0]  R1680     -4.9366939812898636e-02
    z[4,8,0]  R1681     2.2083133459091187e-01
    z[4,8,0]  R1682     1.7553773522377014e-01
    z[4,8,0]  R1683     4.5671370625495911e-01
    z[4,8,0]  R1684     -1.8355819582939148e-01
    z[4,8,0]  R1685     -2.1551392972469330e-01
    z[4,8,0]  R1686     0.100338414311409
    z[4,8,0]  R1687     -1.9112358568236232e-03
    z[4,8,0]  R1688     -1.3800835609436035e-01
    z[4,8,0]  R1689     2.6239061355590820e-01
    z[4,8,0]  R1690     3.1615287065505981e-01
    z[4,8,0]  R1691     3.3481448888778687e-01
    z[4,8,0]  R1692     6.4860087633132935e-01
    z[4,8,0]  R1693     2.3486499488353729e-01
    z[4,8,0]  R1694     3.1915476918220520e-01
    z[4,8,0]  R1695     4.6502545475959778e-01
    z[4,8,0]  R1696     6.9791865348815918e-01
    z[4,8,0]  R1697     -2.4639932811260223e-01
    z[4,8,0]  R1698     1.2444227188825607e-01
    z[4,8,0]  R1699     0.422778844833374
    z[4,8,0]  R1700     1.8694639205932617e-01
    z[4,8,0]  R1701     0.463606595993042
    z[4,8,0]  R1702     0.695311427116394
    z[4,8,0]  R1703     7.3519617319107056e-01
    z[4,8,0]  R1704     0.730003833770752
    z[4,8,0]  R1705     -5.4492527246475220e-01
    z[4,8,0]  R1706     -2.1534349024295807e-01
    z[4,8,0]  R1707     -4.7673907876014709e-01
    z[4,8,0]  R1708     -9.1472655534744263e-01
    z[4,8,0]  R1709     -4.9899551272392273e-01
    z[4,8,0]  R1710     1.7937442660331726e-01
    z[4,8,0]  R1711     8.3233872428536415e-03
    z[4,8,0]  R1712     -1.1779731512069702e-01
    z[4,8,0]  R1713     7.5718045234680176e-02
    z[4,8,0]  R1714     4.3023101985454559e-02
    z[4,8,0]  R1715     2.5510627031326294e-01
    z[4,8,0]  R1716     0.611352801322937
    z[4,8,0]  R1717     6.4501678943634033e-01
    z[4,8,0]  R1718     5.7139158248901367e-01
    z[4,8,0]  R1719     5.8158326148986816e-01
    z[4,8,0]  R1720     3.6221036314964294e-01
    z[4,8,0]  R1721     2.8853756189346313e-01
    z[4,8,0]  R1722     3.1469497084617615e-01
    z[4,8,0]  R1723     2.6581883430480957e-01
    z[4,8,0]  R1724     5.8376115560531616e-01
    z[4,8,0]  R1725     3.7380585074424744e-01
    z[4,8,0]  R1726     4.8549342155456543e-01
    z[4,8,0]  R1727     6.9221824407577515e-01
    z[4,8,0]  R1728     2.0233023166656494e-01
    z[4,8,0]  R1729     1.2574322521686554e-01
    z[4,8,0]  R1730     2.5684067606925964e-01
    z[4,8,0]  R1731     1.1671365052461624e-01
    z[4,8,0]  R1732     2.3870217800140381e-01
    z[4,8,0]  R1733     1.5381184220314026e-01
    z[4,8,0]  R1734     5.1420134305953979e-01
    z[4,8,0]  R1735     2.2655582427978516e-01
    z[4,8,0]  R1736     0.283189594745636
    z[4,8,0]  R1737     2.7601400017738342e-01
    z[4,8,0]  R1738     3.5650694370269775e-01
    z[4,8,0]  R1739     2.8758205473423004e-02
    z[4,8,0]  R1740     2.2294494509696960e-01
    z[4,8,0]  R1741     2.8574812412261963e-01
    z[4,8,0]  R1742     -5.9725034981966019e-02
    z[4,8,0]  R1743     -0.0819258838891983
    z[4,8,1]  R39       -1
    z[4,8,1]  R75       1
    z[4,8,1]  R1617     -1
    z[4,8,1]  R1618     1
    z[4,8,1]  R1629     2.8132668137550354e-01
    z[4,8,1]  R1630     4.2940124869346619e-01
    z[4,8,1]  R1631     7.5325970537960529e-03
    z[4,8,1]  R1632     5.7901513576507568e-01
    z[4,8,1]  R1633     2.0204983651638031e-01
    z[4,8,1]  R1634     8.6046881973743439e-02
    z[4,8,1]  R1635     2.8027138113975525e-01
    z[4,8,1]  R1636     4.9292293190956116e-01
    z[4,8,1]  R1637     3.1568199396133423e-01
    z[4,8,1]  R1638     6.7493891716003418e-01
    z[4,8,1]  R1639     5.9162467718124390e-01
    z[4,8,1]  R1640     1.0954042524099350e-01
    z[4,8,1]  R1641     4.5639863610267639e-01
    z[4,8,1]  R1642     1.4886243641376495e-01
    z[4,8,1]  R1643     -7.7556276321411133e-01
    z[4,8,1]  R1644     -6.4946508407592773e-01
    z[4,8,1]  R1645     -9.1136246919631958e-01
    z[4,8,1]  R1646     -8.9713948965072632e-01
    z[4,8,1]  R1647     -5.0371998548507690e-01
    z[4,8,1]  R1648     -8.0799359083175659e-01
    z[4,8,1]  R1649     -0.572062611579895
    z[4,8,1]  R1650     -7.7519947290420532e-01
    z[4,8,1]  R1651     -0.589427649974823
    z[4,8,1]  R1652     -6.5192335844039917e-01
    z[4,8,1]  R1653     -7.6822096109390259e-01
    z[4,8,1]  R1654     -4.5647367835044861e-01
    z[4,8,1]  R1655     -4.7322675585746765e-01
    z[4,8,1]  R1656     -6.4571005105972290e-01
    z[4,8,1]  R1657     -6.9772607088088989e-01
    z[4,8,1]  R1658     -8.3203715085983276e-01
    z[4,8,1]  R1659     -5.7106351852416992e-01
    z[4,8,1]  R1660     -4.4708859920501709e-01
    z[4,8,1]  R1661     -8.0021435022354126e-01
    z[4,8,1]  R1662     -7.7876365184783936e-01
    z[4,8,1]  R1663     -7.6200026273727417e-01
    z[4,8,1]  R1664     -7.6768219470977783e-01
    z[4,8,1]  R1665     -7.3314839601516724e-01
    z[4,8,1]  R1666     7.0500272512435913e-01
    z[4,8,1]  R1667     4.0483522415161133e-01
    z[4,8,1]  R1668     -5.5599248409271240e-01
    z[4,8,1]  R1669     -6.6381967067718506e-01
    z[4,8,1]  R1670     -9.0491241216659546e-01
    z[4,8,1]  R1671     -0.619698166847229
    z[4,8,1]  R1672     -5.0538444519042969e-01
    z[4,8,1]  R1673     -8.6528658866882324e-01
    z[4,8,1]  R1674     -7.7655076980590820e-01
    z[4,8,1]  R1675     -9.0143078565597534e-01
    z[4,8,1]  R1676     -7.0040273666381836e-01
    z[4,8,1]  R1677     2.1460117772221565e-02
    z[4,8,1]  R1678     -5.5794847011566162e-01
    z[4,8,1]  R1679     -8.7596380710601807e-01
    z[4,8,1]  R1680     -9.1440171003341675e-01
    z[4,8,1]  R1681     -6.7542958259582520e-01
    z[4,8,1]  R1682     -8.2888710498809814e-01
    z[4,8,1]  R1683     -6.4825212955474854e-01
    z[4,8,1]  R1684     -7.9127651453018188e-01
    z[4,8,1]  R1685     -8.2369971275329590e-01
    z[4,8,1]  R1686     -7.7229762077331543e-01
    z[4,8,1]  R1687     -8.8891887664794922e-01
    z[4,8,1]  R1688     -8.8942545652389526e-01
    z[4,8,1]  R1689     -0.79151850938797
    z[4,8,1]  R1690     -8.1461596488952637e-01
    z[4,8,1]  R1691     -8.2109457254409790e-01
    z[4,8,1]  R1692     -1.7773827910423279e-01
    z[4,8,1]  R1693     -7.5015085935592651e-01
    z[4,8,1]  R1694     -7.3993182182312012e-01
    z[4,8,1]  R1695     1.6175159811973572e-01
    z[4,8,1]  R1696     0.035215113312006
    z[4,8,1]  R1697     -0.937619686126709
    z[4,8,1]  R1698     -8.9324432611465454e-01
    z[4,8,1]  R1699     -7.7389258146286011e-01
    z[4,8,1]  R1700     -8.1678217649459839e-01
    z[4,8,1]  R1701     -4.9182184040546417e-02
    z[4,8,1]  R1702     4.4177651405334473e-01
    z[4,8,1]  R1703     4.1015404462814331e-01
    z[4,8,1]  R1704     3.9751288294792175e-01
    z[4,8,1]  R1705     4.3278518319129944e-01
    z[4,8,1]  R1706     5.2865236997604370e-01
    z[4,8,1]  R1707     3.2280489802360535e-02
    z[4,8,1]  R1708     -1.0213023424148560e-01
    z[4,8,1]  R1709     3.5205683112144470e-01
    z[4,8,1]  R1710     0.0873582735657692
    z[4,8,1]  R1711     3.0650734901428223e-01
    z[4,8,1]  R1712     -1.1546940356492996e-01
    z[4,8,1]  R1713     -8.3069734275341034e-02
    z[4,8,1]  R1714     2.9835087060928345e-01
    z[4,8,1]  R1715     -0.0591592937707901
    z[4,8,1]  R1716     -6.5233409404754639e-02
    z[4,8,1]  R1717     -1.7246234416961670e-01
    z[4,8,1]  R1718     5.4489899426698685e-02
    z[4,8,1]  R1719     -7.5519219040870667e-02
    z[4,8,1]  R1720     -2.4127402901649475e-01
    z[4,8,1]  R1721     -6.4986400306224823e-02
    z[4,8,1]  R1722     6.6145914793014526e-01
    z[4,8,1]  R1723     -8.6502122879028320e-01
    z[4,8,1]  R1724     2.5387245416641235e-01
    z[4,8,1]  R1725     3.3545008301734924e-01
    z[4,8,1]  R1726     0.605156421661377
    z[4,8,1]  R1727     1.9629713892936707e-01
    z[4,8,1]  R1728     -0.922296404838562
    z[4,8,1]  R1729     -9.0870171785354614e-01
    z[4,8,1]  R1730     -9.0678805112838745e-01
    z[4,8,1]  R1731     -9.0038394927978516e-01
    z[4,8,1]  R1732     -8.7704312801361084e-01
    z[4,8,1]  R1733     -8.8701063394546509e-01
    z[4,8,1]  R1734     1.3998055458068848e-01
    z[4,8,1]  R1735     4.0884265303611755e-01
    z[4,8,1]  R1736     2.9602622613310814e-02
    z[4,8,1]  R1737     2.5092095136642456e-02
    z[4,8,1]  R1738     4.8419770598411560e-01
    z[4,8,1]  R1739     -0.950893223285675
    z[4,8,1]  R1740     -8.8206022977828979e-01
    z[4,8,1]  R1741     -8.9106363058090210e-01
    z[4,8,1]  R1742     -7.3857551813125610e-01
    z[4,8,1]  R1743     -6.0511809587478638e-01
    z[4,8,2]  R40       -1
    z[4,8,2]  R76       1
    z[4,8,2]  R1619     -1
    z[4,8,2]  R1620     1
    z[4,8,2]  R1629     1.2565425038337708e-01
    z[4,8,2]  R1630     -7.2990462183952332e-02
    z[4,8,2]  R1631     -1.2438035011291504e-01
    z[4,8,2]  R1632     -1.6645358502864838e-01
    z[4,8,2]  R1633     -9.1014020144939423e-02
    z[4,8,2]  R1634     0.626151442527771
    z[4,8,2]  R1635     -2.4900703132152557e-01
    z[4,8,2]  R1636     1.0611472278833389e-01
    z[4,8,2]  R1637     9.1054454445838928e-02
    z[4,8,2]  R1638     -1.5911756455898285e-01
    z[4,8,2]  R1639     3.1160160899162292e-01
    z[4,8,2]  R1640     -1.1797026731073856e-02
    z[4,8,2]  R1641     -2.3035086691379547e-01
    z[4,8,2]  R1642     8.2876391708850861e-02
    z[4,8,2]  R1643     -3.3033519983291626e-01
    z[4,8,2]  R1644     -4.6171391010284424e-01
    z[4,8,2]  R1645     -3.1455031037330627e-01
    z[4,8,2]  R1646     1.0135427117347717e-01
    z[4,8,2]  R1647     -4.3890568614006042e-01
    z[4,8,2]  R1648     0.136931911110878
    z[4,8,2]  R1649     -6.8476319313049316e-01
    z[4,8,2]  R1650     -9.9444175139069557e-03
    z[4,8,2]  R1651     -4.6268993616104126e-01
    z[4,8,2]  R1652     -5.4729342460632324e-01
    z[4,8,2]  R1653     2.4883045256137848e-01
    z[4,8,2]  R1654     -6.9945007562637329e-01
    z[4,8,2]  R1655     -8.0823624134063721e-01
    z[4,8,2]  R1656     -6.4133191108703613e-01
    z[4,8,2]  R1657     -1.8304759636521339e-02
    z[4,8,2]  R1658     2.4319043755531311e-01
    z[4,8,2]  R1659     -6.8353205919265747e-01
    z[4,8,2]  R1660     -7.9876106977462769e-01
    z[4,8,2]  R1661     6.4935930073261261e-02
    z[4,8,2]  R1662     2.7095427736639977e-02
    z[4,8,2]  R1663     -1.4205268025398254e-01
    z[4,8,2]  R1664     -9.6215203404426575e-02
    z[4,8,2]  R1665     -1.0724537819623947e-01
    z[4,8,2]  R1666     -1.6476549208164215e-02
    z[4,8,2]  R1667     -2.6660233736038208e-01
    z[4,8,2]  R1668     -7.3061013221740723e-01
    z[4,8,2]  R1669     -6.6492223739624023e-01
    z[4,8,2]  R1670     1.3585336506366730e-01
    z[4,8,2]  R1671     -5.5617189407348633e-01
    z[4,8,2]  R1672     -5.2972149848937988e-01
    z[4,8,2]  R1673     -1.8511453270912170e-01
    z[4,8,2]  R1674     -2.8458639979362488e-01
    z[4,8,2]  R1675     3.7137895822525024e-02
    z[4,8,2]  R1676     -6.5151625871658325e-01
    z[4,8,2]  R1677     -4.9594688415527344e-01
    z[4,8,2]  R1678     -5.4087972640991211e-01
    z[4,8,2]  R1679     -1.7047224566340446e-02
    z[4,8,2]  R1680     2.7067303657531738e-01
    z[4,8,2]  R1681     -2.6017594337463379e-01
    z[4,8,2]  R1682     3.2183980941772461e-01
    z[4,8,2]  R1683     -1.6664777696132660e-01
    z[4,8,2]  R1684     -2.0325869321823120e-02
    z[4,8,2]  R1685     1.1372482031583786e-01
    z[4,8,2]  R1686     -5.3918910026550293e-01
    z[4,8,2]  R1687     -2.1300375461578369e-01
    z[4,8,2]  R1688     1.8503311276435852e-01
    z[4,8,2]  R1689     -3.3325843513011932e-02
    z[4,8,2]  R1690     -3.8550995290279388e-02
    z[4,8,2]  R1691     2.6382654905319214e-01
    z[4,8,2]  R1692     -9.6111074090003967e-02
    z[4,8,2]  R1693     -1.9729016721248627e-01
    z[4,8,2]  R1694     1.6195631027221680e-01
    z[4,8,2]  R1695     -1.3061526417732239e-01
    z[4,8,2]  R1696     -4.5849704742431641e-01
    z[4,8,2]  R1697     5.3239818662405014e-02
    z[4,8,2]  R1698     -4.7729674726724625e-02
    z[4,8,2]  R1699     -9.9238239228725433e-02
    z[4,8,2]  R1700     -1.8111547827720642e-01
    z[4,8,2]  R1701     -9.2884004116058350e-03
    z[4,8,2]  R1702     0.0757242813706398
    z[4,8,2]  R1703     0.326010137796402
    z[4,8,2]  R1704     1.1096108704805374e-01
    z[4,8,2]  R1705     4.4297706335783005e-02
    z[4,8,2]  R1706     -1.0253424942493439e-01
    z[4,8,2]  R1707     3.4196120500564575e-01
    z[4,8,2]  R1708     1.9986394047737122e-01
    z[4,8,2]  R1709     -8.1668362021446228e-02
    z[4,8,2]  R1710     2.2891965508460999e-01
    z[4,8,2]  R1711     5.2468216419219971e-01
    z[4,8,2]  R1712     -3.9801257848739624e-01
    z[4,8,2]  R1713     -4.8457396030426025e-01
    z[4,8,2]  R1714     -6.3851737976074219e-01
    z[4,8,2]  R1715     -3.4500178694725037e-01
    z[4,8,2]  R1716     -3.0746594071388245e-02
    z[4,8,2]  R1717     0.0672302395105362
    z[4,8,2]  R1718     -1.6945162415504456e-01
    z[4,8,2]  R1719     3.5668212175369263e-01
    z[4,8,2]  R1720     4.5615750551223755e-01
    z[4,8,2]  R1721     1.0421478748321533e-01
    z[4,8,2]  R1722     2.2317555546760559e-01
    z[4,8,2]  R1723     1.8342211842536926e-01
    z[4,8,2]  R1724     3.2977712154388428e-01
    z[4,8,2]  R1725     2.5324460864067078e-01
    z[4,8,2]  R1726     2.0797833800315857e-01
    z[4,8,2]  R1727     5.5952745676040649e-01
    z[4,8,2]  R1728     -1.7250286042690277e-01
    z[4,8,2]  R1729     1.0942266322672367e-02
    z[4,8,2]  R1730     -9.7748890519142151e-02
    z[4,8,2]  R1731     -1.1095040291547775e-01
    z[4,8,2]  R1732     8.1540994346141815e-02
    z[4,8,2]  R1733     1.9990071654319763e-02
    z[4,8,2]  R1734     3.3385327458381653e-01
    z[4,8,2]  R1735     -6.5134182572364807e-02
    z[4,8,2]  R1736     4.1693288087844849e-01
    z[4,8,2]  R1737     -3.3540013432502747e-01
    z[4,8,2]  R1738     3.5556885600090027e-01
    z[4,8,2]  R1739     -1.6824441030621529e-02
    z[4,8,2]  R1740     1.4960496127605438e-01
    z[4,8,2]  R1741     3.2649624347686768e-01
    z[4,8,2]  R1742     -5.8190923929214478e-01
    z[4,8,2]  R1743     -5.5336314439773560e-01
    z[4,8,3]  R41       -1
    z[4,8,3]  R77       1
    z[4,8,3]  R1621     -1
    z[4,8,3]  R1622     1
    z[4,8,3]  R1629     -2.8652116656303406e-01
    z[4,8,3]  R1630     3.5964247584342957e-01
    z[4,8,3]  R1631     2.0728701353073120e-01
    z[4,8,3]  R1632     -5.2693802118301392e-01
    z[4,8,3]  R1633     -6.0815256834030151e-01
    z[4,8,3]  R1634     2.3736244067549706e-02
    z[4,8,3]  R1635     3.3163344860076904e-01
    z[4,8,3]  R1636     7.7075809240341187e-01
    z[4,8,3]  R1637     8.5122185945510864e-01
    z[4,8,3]  R1638     0.625590443611145
    z[4,8,3]  R1639     6.2528085708618164e-01
    z[4,8,3]  R1640     9.3912720680236816e-01
    z[4,8,3]  R1641     6.7131775617599487e-01
    z[4,8,3]  R1642     7.4573343992233276e-01
    z[4,8,3]  R1643     -1.6835495829582214e-01
    z[4,8,3]  R1644     -1.0739649832248688e-01
    z[4,8,3]  R1645     -2.1419250965118408e-01
    z[4,8,3]  R1646     -1.6170606017112732e-01
    z[4,8,3]  R1647     -6.2765496969223022e-01
    z[4,8,3]  R1648     3.4590315818786621e-01
    z[4,8,3]  R1649     7.9685494303703308e-02
    z[4,8,3]  R1650     1.6408908367156982e-01
    z[4,8,3]  R1651     -2.7080511674284935e-02
    z[4,8,3]  R1652     -3.9443865418434143e-01
    z[4,8,3]  R1653     2.4014189839363098e-01
    z[4,8,3]  R1654     -1.2927785515785217e-01
    z[4,8,3]  R1655     0.0540459118783474
    z[4,8,3]  R1656     7.0934325456619263e-02
    z[4,8,3]  R1657     -5.7334297895431519e-01
    z[4,8,3]  R1658     2.5984886288642883e-01
    z[4,8,3]  R1659     1.1943177878856659e-01
    z[4,8,3]  R1660     -1.2809245288372040e-01
    z[4,8,3]  R1661     9.6224442124366760e-02
    z[4,8,3]  R1662     -3.6655715107917786e-01
    z[4,8,3]  R1663     0.0673820897936821
    z[4,8,3]  R1664     4.0417218208312988e-01
    z[4,8,3]  R1665     2.4162137508392334e-01
    z[4,8,3]  R1666     3.8890153169631958e-01
    z[4,8,3]  R1667     5.7501119375228882e-01
    z[4,8,3]  R1668     -2.3392596840858459e-01
    z[4,8,3]  R1669     4.7164112329483032e-02
    z[4,8,3]  R1670     1.7356034368276596e-02
    z[4,8,3]  R1671     -4.5801591873168945e-01
    z[4,8,3]  R1672     -3.3098584413528442e-01
    z[4,8,3]  R1673     -1.4017856121063232e-01
    z[4,8,3]  R1674     -4.1113600134849548e-01
    z[4,8,3]  R1675     6.7720770835876465e-02
    z[4,8,3]  R1676     -2.7207341790199280e-01
    z[4,8,3]  R1677     2.9130643606185913e-01
    z[4,8,3]  R1678     -0.48995241522789
    z[4,8,3]  R1679     0.154449462890625
    z[4,8,3]  R1680     -2.7712401747703552e-01
    z[4,8,3]  R1681     -3.0682352185249329e-01
    z[4,8,3]  R1682     -8.2297712564468384e-02
    z[4,8,3]  R1683     -3.5729256272315979e-01
    z[4,8,3]  R1684     7.8484527766704559e-02
    z[4,8,3]  R1685     -1.7783628404140472e-01
    z[4,8,3]  R1686     -8.9961253106594086e-02
    z[4,8,3]  R1687     1.8062674999237061e-01
    z[4,8,3]  R1688     -1.3411337137222290e-01
    z[4,8,3]  R1689     -5.0566357374191284e-01
    z[4,8,3]  R1690     2.0418265461921692e-01
    z[4,8,3]  R1691     5.1924187690019608e-02
    z[4,8,3]  R1692     2.6497477293014526e-01
    z[4,8,3]  R1693     -1.2366843223571777e-01
    z[4,8,3]  R1694     -2.4484993517398834e-01
    z[4,8,3]  R1695     2.2541526705026627e-02
    z[4,8,3]  R1696     3.8468053936958313e-01
    z[4,8,3]  R1697     -2.2348362207412720e-01
    z[4,8,3]  R1698     -2.5302174687385559e-01
    z[4,8,3]  R1699     2.5384664535522461e-01
    z[4,8,3]  R1700     5.5681776255369186e-02
    z[4,8,3]  R1701     5.7787474244832993e-02
    z[4,8,3]  R1702     -2.5616058707237244e-01
    z[4,8,3]  R1703     -2.4824059009552002e-01
    z[4,8,3]  R1704     -2.2069209814071655e-01
    z[4,8,3]  R1705     3.3893135190010071e-01
    z[4,8,3]  R1706     1.7238068580627441e-01
    z[4,8,3]  R1707     -8.0694389343261719e-01
    z[4,8,3]  R1708     2.2265070676803589e-01
    z[4,8,3]  R1709     -1.2656930088996887e-01
    z[4,8,3]  R1710     4.0449026226997375e-01
    z[4,8,3]  R1711     -0.569337010383606
    z[4,8,3]  R1712     -6.4385145902633667e-01
    z[4,8,3]  R1713     1.1762108653783798e-02
    z[4,8,3]  R1714     -2.0890416204929352e-01
    z[4,8,3]  R1715     0.820968508720398
    z[4,8,3]  R1716     6.7245924472808838e-01
    z[4,8,3]  R1717     6.3162380456924438e-01
    z[4,8,3]  R1718     7.0842069387435913e-01
    z[4,8,3]  R1719     6.5730887651443481e-01
    z[4,8,3]  R1720     7.4381065368652344e-01
    z[4,8,3]  R1721     8.7322556972503662e-01
    z[4,8,3]  R1722     2.5221675634384155e-01
    z[4,8,3]  R1723     -2.6172018051147461e-01
    z[4,8,3]  R1724     3.6002656817436218e-01
    z[4,8,3]  R1725     3.9744228124618530e-01
    z[4,8,3]  R1726     2.2856892645359039e-01
    z[4,8,3]  R1727     3.2866531610488892e-01
    z[4,8,3]  R1728     -1.9448810815811157e-01
    z[4,8,3]  R1729     -1.3624049723148346e-01
    z[4,8,3]  R1730     1.0560864955186844e-01
    z[4,8,3]  R1731     8.2533389329910278e-02
    z[4,8,3]  R1732     3.7692766636610031e-02
    z[4,8,3]  R1733     1.9963359832763672e-01
    z[4,8,3]  R1734     6.4280843734741211e-01
    z[4,8,3]  R1735     7.4181818962097168e-01
    z[4,8,3]  R1736     8.2144778966903687e-01
    z[4,8,3]  R1737     6.5293055772781372e-01
    z[4,8,3]  R1738     6.0793638229370117e-01
    z[4,8,3]  R1739     -2.7843394875526428e-01
    z[4,8,3]  R1740     -1.4027177821844816e-03
    z[4,8,3]  R1741     -1.1982208490371704e-01
    z[4,8,3]  R1742     -1.3696564733982086e-01
    z[4,8,3]  R1743     -4.2138215899467468e-01
    z[4,8,4]  R42       -1
    z[4,8,4]  R78       1
    z[4,8,4]  R1623     -1
    z[4,8,4]  R1624     1
    z[4,8,4]  R1629     2.0960272848606110e-01
    z[4,8,4]  R1630     -3.7107229232788086e-02
    z[4,8,4]  R1631     -7.0225065946578979e-01
    z[4,8,4]  R1632     -4.7506490349769592e-01
    z[4,8,4]  R1633     -3.6551004648208618e-01
    z[4,8,4]  R1634     -4.3038591742515564e-01
    z[4,8,4]  R1635     4.4329786300659180e-01
    z[4,8,4]  R1636     -5.3792528808116913e-02
    z[4,8,4]  R1637     -4.5282721519470215e-02
    z[4,8,4]  R1638     6.5043777227401733e-02
    z[4,8,4]  R1639     1.4205466210842133e-01
    z[4,8,4]  R1640     8.2762479782104492e-02
    z[4,8,4]  R1641     1.7623870074748993e-01
    z[4,8,4]  R1642     3.9861190319061279e-01
    z[4,8,4]  R1643     -2.0020754635334015e-01
    z[4,8,4]  R1644     -1.9458557665348053e-01
    z[4,8,4]  R1645     -8.5982456803321838e-02
    z[4,8,4]  R1646     1.6359147429466248e-01
    z[4,8,4]  R1647     1.9855398684740067e-02
    z[4,8,4]  R1648     0.178420752286911
    z[4,8,4]  R1649     2.1477924287319183e-01
    z[4,8,4]  R1650     -1.5897114574909210e-01
    z[4,8,4]  R1651     2.6159333065152168e-02
    z[4,8,4]  R1652     1.6524660587310791e-01
    z[4,8,4]  R1653     0.0753258541226387
    z[4,8,4]  R1654     3.3169826865196228e-01
    z[4,8,4]  R1655     0.0411791168153286
    z[4,8,4]  R1656     2.2157919406890869e-01
    z[4,8,4]  R1657     -4.7878913581371307e-02
    z[4,8,4]  R1658     3.7933662533760071e-01
    z[4,8,4]  R1659     -1.9451610743999481e-02
    z[4,8,4]  R1660     1.8401028215885162e-01
    z[4,8,4]  R1661     2.4931050837039948e-01
    z[4,8,4]  R1662     9.7140751779079437e-02
    z[4,8,4]  R1663     4.1627818346023560e-01
    z[4,8,4]  R1664     3.2874977588653564e-01
    z[4,8,4]  R1665     -2.6751694083213806e-01
    z[4,8,4]  R1666     4.1147032380104065e-01
    z[4,8,4]  R1667     4.1332921385765076e-01
    z[4,8,4]  R1668     4.8051834106445312e-02
    z[4,8,4]  R1669     1.0222673416137695e-01
    z[4,8,4]  R1670     -2.2699016332626343e-01
    z[4,8,4]  R1671     6.3473515212535858e-02
    z[4,8,4]  R1672     8.2612454891204834e-02
    z[4,8,4]  R1673     -2.8288796544075012e-02
    z[4,8,4]  R1674     7.2491921484470367e-02
    z[4,8,4]  R1675     9.1149166226387024e-02
    z[4,8,4]  R1676     -7.5300313532352448e-02
    z[4,8,4]  R1677     1.7393555492162704e-02
    z[4,8,4]  R1678     8.6900874972343445e-02
    z[4,8,4]  R1679     -1.9447323679924011e-01
    z[4,8,4]  R1680     1.8232997506856918e-02
    z[4,8,4]  R1681     -3.6176049709320068e-01
    z[4,8,4]  R1682     2.2238619625568390e-01
    z[4,8,4]  R1683     -9.1401286423206329e-02
    z[4,8,4]  R1684     3.6532336473464966e-01
    z[4,8,4]  R1685     1.1237250268459320e-01
    z[4,8,4]  R1686     1.1224296689033508e-01
    z[4,8,4]  R1687     7.5787985697388649e-03
    z[4,8,4]  R1688     6.4320690929889679e-02
    z[4,8,4]  R1689     -1.3239432871341705e-01
    z[4,8,4]  R1690     2.5776756927371025e-02
    z[4,8,4]  R1691     3.5215219855308533e-01
    z[4,8,4]  R1692     6.4503157138824463e-01
    z[4,8,4]  R1693     4.3805581331253052e-01
    z[4,8,4]  R1694     -1.5390609204769135e-01
    z[4,8,4]  R1695     6.7675316333770752e-01
    z[4,8,4]  R1696     -3.6997926235198975e-01
    z[4,8,4]  R1697     -6.6607259213924408e-02
    z[4,8,4]  R1698     1.2064320594072342e-01
    z[4,8,4]  R1699     2.6603901386260986e-01
    z[4,8,4]  R1700     4.8441749811172485e-01
    z[4,8,4]  R1701     7.0256847143173218e-01
    z[4,8,4]  R1702     4.4332712888717651e-01
    z[4,8,4]  R1703     3.2140663266181946e-01
    z[4,8,4]  R1704     1.5471938252449036e-01
    z[4,8,4]  R1705     6.1544120311737061e-01
    z[4,8,4]  R1706     -1.6038011014461517e-01
    z[4,8,4]  R1707     -4.4960159808397293e-02
    z[4,8,4]  R1708     3.2772939652204514e-02
    z[4,8,4]  R1709     2.4203942716121674e-01
    z[4,8,4]  R1710     -7.1600514650344849e-01
    z[4,8,4]  R1711     -4.7515761852264404e-01
    z[4,8,4]  R1712     -4.7687861323356628e-01
    z[4,8,4]  R1713     -1.4801302552223206e-01
    z[4,8,4]  R1714     -8.6326800286769867e-02
    z[4,8,4]  R1715     -1.1482661962509155e-01
    z[4,8,4]  R1716     -7.4615702033042908e-03
    z[4,8,4]  R1717     -1.4398986101150513e-01
    z[4,8,4]  R1718     3.1648358702659607e-01
    z[4,8,4]  R1719     8.5796646773815155e-02
    z[4,8,4]  R1720     1.6937313973903656e-01
    z[4,8,4]  R1721     3.5484090447425842e-01
    z[4,8,4]  R1722     -5.3575527854263783e-03
    z[4,8,4]  R1723     -5.2903532981872559e-02
    z[4,8,4]  R1724     -5.3471463918685913e-01
    z[4,8,4]  R1725     -0.59151291847229
    z[4,8,4]  R1726     -7.9646848142147064e-02
    z[4,8,4]  R1727     -0.0201775711029768
    z[4,8,4]  R1728     4.5154165476560593e-02
    z[4,8,4]  R1729     1.6619296371936798e-01
    z[4,8,4]  R1730     1.6266991198062897e-01
    z[4,8,4]  R1731     -3.7581852078437805e-01
    z[4,8,4]  R1732     -2.7733482420444489e-03
    z[4,8,4]  R1733     2.2970676422119141e-01
    z[4,8,4]  R1734     -1.4652857184410095e-01
    z[4,8,4]  R1735     1.3311018049716949e-01
    z[4,8,4]  R1736     2.1338362246751785e-02
    z[4,8,4]  R1737     -4.9263462424278259e-01
    z[4,8,4]  R1738     1.3779577612876892e-01
    z[4,8,4]  R1739     -3.4126002341508865e-02
    z[4,8,4]  R1740     -1.0386031121015549e-01
    z[4,8,4]  R1741     -1.1333167552947998e-02
    z[4,8,4]  R1742     1.8678863346576691e-01
    z[4,8,4]  R1743     1.9302532076835632e-02
    z[4,8,5]  R43       -1
    z[4,8,5]  R79       1
    z[4,8,5]  R1625     -1
    z[4,8,5]  R1626     1
    z[4,8,5]  R1629     -2.9125988483428955e-01
    z[4,8,5]  R1630     2.8395307064056396e-01
    z[4,8,5]  R1631     3.8931244611740112e-01
    z[4,8,5]  R1632     -1.9168801605701447e-01
    z[4,8,5]  R1633     5.8619940280914307e-01
    z[4,8,5]  R1634     -2.4412751197814941e-02
    z[4,8,5]  R1635     -2.9837164282798767e-01
    z[4,8,5]  R1636     -2.8865331411361694e-01
    z[4,8,5]  R1637     1.4389933645725250e-01
    z[4,8,5]  R1638     -9.0629987418651581e-02
    z[4,8,5]  R1639     -3.2613296061754227e-02
    z[4,8,5]  R1640     -1.4074572920799255e-01
    z[4,8,5]  R1641     3.2871791720390320e-01
    z[4,8,5]  R1642     1.4860203862190247e-01
    z[4,8,5]  R1643     -4.4143116474151611e-01
    z[4,8,5]  R1644     -5.3421151638031006e-01
    z[4,8,5]  R1645     1.0798743367195129e-01
    z[4,8,5]  R1646     -2.9459038376808167e-01
    z[4,8,5]  R1647     -2.6060670614242554e-01
    z[4,8,5]  R1648     -7.2829827666282654e-02
    z[4,8,5]  R1649     -2.1018789708614349e-01
    z[4,8,5]  R1650     7.5851596891880035e-02
    z[4,8,5]  R1651     -3.5586071014404297e-01
    z[4,8,5]  R1652     -2.5549063086509705e-01
    z[4,8,5]  R1653     1.1772985756397247e-01
    z[4,8,5]  R1654     -2.9082307219505310e-01
    z[4,8,5]  R1655     -7.5395785272121429e-02
    z[4,8,5]  R1656     -2.9266867041587830e-01
    z[4,8,5]  R1657     -3.0513831973075867e-01
    z[4,8,5]  R1658     3.6092754453420639e-02
    z[4,8,5]  R1659     -0.0642428919672966
    z[4,8,5]  R1660     -1.3352457899600267e-03
    z[4,8,5]  R1661     2.5755900144577026e-01
    z[4,8,5]  R1662     -3.2464000582695007e-01
    z[4,8,5]  R1663     -0.275749534368515
    z[4,8,5]  R1664     2.5408431887626648e-01
    z[4,8,5]  R1665     -0.0939953550696373
    z[4,8,5]  R1666     -2.5288176536560059e-01
    z[4,8,5]  R1667     -2.3178742825984955e-01
    z[4,8,5]  R1668     -0.127928227186203
    z[4,8,5]  R1669     -3.0584850907325745e-01
    z[4,8,5]  R1670     -2.4475468695163727e-01
    z[4,8,5]  R1671     -6.1415430158376694e-02
    z[4,8,5]  R1672     -3.7571245431900024e-01
    z[4,8,5]  R1673     -2.3396830260753632e-01
    z[4,8,5]  R1674     -2.2887107729911804e-01
    z[4,8,5]  R1675     -2.9069520533084869e-02
    z[4,8,5]  R1676     -0.0584476999938488
    z[4,8,5]  R1677     -1.2071265280246735e-01
    z[4,8,5]  R1678     -3.0844411253929138e-01
    z[4,8,5]  R1679     -2.5860235095024109e-01
    z[4,8,5]  R1680     -2.2496019955724478e-03
    z[4,8,5]  R1681     -2.4236641824245453e-01
    z[4,8,5]  R1682     7.9531274735927582e-02
    z[4,8,5]  R1683     -4.3636941909790039e-01
    z[4,8,5]  R1684     -4.3903324007987976e-01
    z[4,8,5]  R1685     -9.9482253193855286e-02
    z[4,8,5]  R1686     -2.7293553948402405e-01
    z[4,8,5]  R1687     2.2007305920124054e-01
    z[4,8,5]  R1688     1.1336227878928185e-02
    z[4,8,5]  R1689     -1.5972651541233063e-01
    z[4,8,5]  R1690     4.2401656508445740e-01
    z[4,8,5]  R1691     1.3125570118427277e-01
    z[4,8,5]  R1692     4.9722746014595032e-02
    z[4,8,5]  R1693     -9.0187273919582367e-02
    z[4,8,5]  R1694     0.148108571767807
    z[4,8,5]  R1695     -4.6637412905693054e-01
    z[4,8,5]  R1696     -1.2660789489746094e-01
    z[4,8,5]  R1697     -2.2432606667280197e-02
    z[4,8,5]  R1698     -3.3498124685138464e-03
    z[4,8,5]  R1699     -2.0628614723682404e-01
    z[4,8,5]  R1700     -6.0372814536094666e-02
    z[4,8,5]  R1701     -5.1319307088851929e-01
    z[4,8,5]  R1702     -1.2096808850765228e-01
    z[4,8,5]  R1703     -1.0360217653214931e-02
    z[4,8,5]  R1704     1.5313176810741425e-01
    z[4,8,5]  R1705     1.3929626345634460e-01
    z[4,8,5]  R1706     -3.5279604792594910e-01
    z[4,8,5]  R1707     3.8220237940549850e-02
    z[4,8,5]  R1708     2.1354711055755615e-01
    z[4,8,5]  R1709     -4.0999558568000793e-01
    z[4,8,5]  R1710     8.4200963377952576e-02
    z[4,8,5]  R1711     2.8404369950294495e-01
    z[4,8,5]  R1712     3.8109812140464783e-01
    z[4,8,5]  R1713     7.8728175163269043e-01
    z[4,8,5]  R1714     6.7090344429016113e-01
    z[4,8,5]  R1715     3.5295647382736206e-01
    z[4,8,5]  R1716     -2.4163994938135147e-02
    z[4,8,5]  R1717     2.7940610051155090e-01
    z[4,8,5]  R1718     2.9542475938796997e-02
    z[4,8,5]  R1719     2.8805750608444214e-01
    z[4,8,5]  R1720     -1.4151780307292938e-01
    z[4,8,5]  R1721     -5.8375686407089233e-02
    z[4,8,5]  R1722     5.0904947519302368e-01
    z[4,8,5]  R1723     -2.0721639692783356e-01
    z[4,8,5]  R1724     2.2999155521392822e-01
    z[4,8,5]  R1725     1.7055776715278625e-01
    z[4,8,5]  R1726     4.8161312937736511e-01
    z[4,8,5]  R1727     -1.8148081004619598e-01
    z[4,8,5]  R1728     0.072996124625206
    z[4,8,5]  R1729     -1.3415264897048473e-02
    z[4,8,5]  R1730     2.1625134348869324e-01
    z[4,8,5]  R1731     0.118670254945755
    z[4,8,5]  R1732     -0.221003919839859
    z[4,8,5]  R1733     -3.0883875489234924e-01
    z[4,8,5]  R1734     -1.3896717131137848e-01
    z[4,8,5]  R1735     3.2583504915237427e-01
    z[4,8,5]  R1736     -8.8345922529697418e-02
    z[4,8,5]  R1737     2.5804251432418823e-01
    z[4,8,5]  R1738     2.5488847494125366e-01
    z[4,8,5]  R1739     -0.0645069107413292
    z[4,8,5]  R1740     2.2342254221439362e-01
    z[4,8,5]  R1741     5.1044980064034462e-03
    z[4,8,5]  R1742     -2.3616391420364380e-01
    z[4,8,5]  R1743     -3.1501868367195129e-01
    z[4,8,6]  R44       -1
    z[4,8,6]  R80       1
    z[4,8,6]  R1627     -1
    z[4,8,6]  R1628     1
    z[4,8,6]  R1629     2.8060242533683777e-01
    z[4,8,6]  R1630     -7.3620069026947021e-01
    z[4,8,6]  R1631     3.4527981281280518e-01
    z[4,8,6]  R1632     -2.0684666931629181e-01
    z[4,8,6]  R1633     3.0820357799530029e-01
    z[4,8,6]  R1634     -0.128057062625885
    z[4,8,6]  R1635     6.4315706491470337e-01
    z[4,8,6]  R1636     1.2790703773498535e-01
    z[4,8,6]  R1637     -2.7893617749214172e-01
    z[4,8,6]  R1638     1.7463859915733337e-01
    z[4,8,6]  R1639     1.9452748820185661e-02
    z[4,8,6]  R1640     -3.7492178380489349e-02
    z[4,8,6]  R1641     -5.4711066186428070e-02
    z[4,8,6]  R1642     3.8416630029678345e-01
    z[4,8,6]  R1643     0.128541499376297
    z[4,8,6]  R1644     -1.7142567038536072e-01
    z[4,8,6]  R1645     3.5137572558596730e-04
    z[4,8,6]  R1646     -1.0635446012020111e-01
    z[4,8,6]  R1647     3.9185993373394012e-03
    z[4,8,6]  R1648     -3.9791685342788696e-01
    z[4,8,6]  R1649     1.1854583024978638e-01
    z[4,8,6]  R1650     3.4693002700805664e-01
    z[4,8,6]  R1651     2.9228290915489197e-01
    z[4,8,6]  R1652     -1.6315580904483795e-01
    z[4,8,6]  R1653     4.1230472922325134e-01
    z[4,8,6]  R1654     -3.0129143595695496e-01
    z[4,8,6]  R1655     -2.9035961627960205e-01
    z[4,8,6]  R1656     1.4775559306144714e-01
    z[4,8,6]  R1657     -2.9739844799041748e-01
    z[4,8,6]  R1658     1.8891172111034393e-01
    z[4,8,6]  R1659     -2.3863962292671204e-01
    z[4,8,6]  R1660     -1.5067948400974274e-01
    z[4,8,6]  R1661     2.7361556887626648e-01
    z[4,8,6]  R1662     -2.0225435495376587e-02
    z[4,8,6]  R1663     2.4946808815002441e-01
    z[4,8,6]  R1664     4.7203049063682556e-02
    z[4,8,6]  R1665     -4.6506536006927490e-01
    z[4,8,6]  R1666     3.3451551198959351e-01
    z[4,8,6]  R1667     -4.1838163137435913e-01
    z[4,8,6]  R1668     -2.3472876846790314e-01
    z[4,8,6]  R1669     1.0016328841447830e-01
    z[4,8,6]  R1670     1.6122755408287048e-01
    z[4,8,6]  R1671     9.5639698207378387e-02
    z[4,8,6]  R1672     -4.5434826612472534e-01
    z[4,8,6]  R1673     -3.2423120737075806e-01
    z[4,8,6]  R1674     -2.6547786593437195e-01
    z[4,8,6]  R1675     -3.2465690374374390e-01
    z[4,8,6]  R1676     2.2864004597067833e-02
    z[4,8,6]  R1677     -3.6312052607536316e-01
    z[4,8,6]  R1678     -2.0985266566276550e-01
    z[4,8,6]  R1679     -2.3246988654136658e-01
    z[4,8,6]  R1680     -1.0503920912742615e-01
    z[4,8,6]  R1681     -3.7892490625381470e-01
    z[4,8,6]  R1682     3.4058490395545959e-01
    z[4,8,6]  R1683     -1.3030645251274109e-01
    z[4,8,6]  R1684     8.6043469607830048e-02
    z[4,8,6]  R1685     4.5605826377868652e-01
    z[4,8,6]  R1686     -0.087053082883358
    z[4,8,6]  R1687     -2.8867509961128235e-01
    z[4,8,6]  R1688     3.6522147059440613e-01
    z[4,8,6]  R1689     0.0693008303642273
    z[4,8,6]  R1690     1.1321227252483368e-01
    z[4,8,6]  R1691     -1.2769292108714581e-02
    z[4,8,6]  R1692     -2.2302225232124329e-01
    z[4,8,6]  R1693     3.5758644342422485e-01
    z[4,8,6]  R1694     -4.6779972314834595e-01
    z[4,8,6]  R1695     -2.5400716066360474e-01
    z[4,8,6]  R1696     -2.3589698597788811e-02
    z[4,8,6]  R1697     4.9371778964996338e-02
    z[4,8,6]  R1698     -3.2521459460258484e-01
    z[4,8,6]  R1699     1.8636316061019897e-01
    z[4,8,6]  R1700     1.5397830307483673e-01
    z[4,8,6]  R1701     1.4918014407157898e-01
    z[4,8,6]  R1702     1.9710658490657806e-01
    z[4,8,6]  R1703     -1.4122587442398071e-01
    z[4,8,6]  R1704     0.447965532541275
    z[4,8,6]  R1705     -2.7296485379338264e-02
    z[4,8,6]  R1706     -6.9551318883895874e-01
    z[4,8,6]  R1707     -9.9850669503211975e-03
    z[4,8,6]  R1708     1.2903241813182831e-01
    z[4,8,6]  R1709     0.614565372467041
    z[4,8,6]  R1710     4.7373369336128235e-01
    z[4,8,6]  R1711     -9.6105104312300682e-03
    z[4,8,6]  R1712     -1.6487258672714233e-01
    z[4,8,6]  R1713     -3.3270925283432007e-01
    z[4,8,6]  R1714     -1.5050514601171017e-02
    z[4,8,6]  R1715     2.5339301675558090e-02
    z[4,8,6]  R1716     4.1012936830520630e-01
    z[4,8,6]  R1717     -2.2790496051311493e-01
    z[4,8,6]  R1718     1.9731713831424713e-01
    z[4,8,6]  R1719     -8.0265142023563385e-02
    z[4,8,6]  R1720     -2.3283023387193680e-02
    z[4,8,6]  R1721     9.9094063043594360e-02
    z[4,8,6]  R1722     3.0142712593078613e-01
    z[4,8,6]  R1723     1.8220894038677216e-01
    z[4,8,6]  R1724     1.3260385394096375e-01
    z[4,8,6]  R1725     3.8297748565673828e-01
    z[4,8,6]  R1726     2.5355115532875061e-01
    z[4,8,6]  R1727     1.6693432629108429e-01
    z[4,8,6]  R1728     1.8298017978668213e-01
    z[4,8,6]  R1729     3.3461713790893555e-01
    z[4,8,6]  R1730     1.3354423642158508e-01
    z[4,8,6]  R1731     3.5253062844276428e-02
    z[4,8,6]  R1732     -3.4190145134925842e-01
    z[4,8,6]  R1733     3.3973187208175659e-02
    z[4,8,6]  R1734     3.8801971077919006e-01
    z[4,8,6]  R1735     3.2108667492866516e-01
    z[4,8,6]  R1736     2.4911326169967651e-01
    z[4,8,6]  R1737     2.7404436469078064e-01
    z[4,8,6]  R1738     2.4183419346809387e-01
    z[4,8,6]  R1739     -1.0881573706865311e-01
    z[4,8,6]  R1740     -2.9862526059150696e-01
    z[4,8,6]  R1741     0.0569380484521389
    z[4,8,6]  R1742     -5.3832545876502991e-02
    z[4,8,6]  R1743     -2.0913438498973846e-01
    z[8,4,0]  R38       1
    z[8,4,0]  R74       -1
    z[8,4,0]  R1744     -1
    z[8,4,0]  R1745     1
    z[8,4,0]  R1758     -5.4492527246475220e-01
    z[8,4,0]  R1759     -2.1534349024295807e-01
    z[8,4,0]  R1760     -4.7673907876014709e-01
    z[8,4,0]  R1761     -9.1472655534744263e-01
    z[8,4,0]  R1762     -4.9899551272392273e-01
    z[8,4,0]  R1763     1.7937442660331726e-01
    z[8,4,0]  R1764     8.3233872428536415e-03
    z[8,4,0]  R1765     -1.1779731512069702e-01
    z[8,4,0]  R1766     7.5718045234680176e-02
    z[8,4,0]  R1767     4.3023101985454559e-02
    z[8,4,0]  R1768     2.5510627031326294e-01
    z[8,4,0]  R1769     0.611352801322937
    z[8,4,0]  R1770     6.4501678943634033e-01
    z[8,4,0]  R1771     5.7139158248901367e-01
    z[8,4,0]  R1772     5.8158326148986816e-01
    z[8,4,0]  R1773     3.6221036314964294e-01
    z[8,4,0]  R1774     2.8853756189346313e-01
    z[8,4,0]  R1775     3.1469497084617615e-01
    z[8,4,0]  R1776     2.6581883430480957e-01
    z[8,4,0]  R1777     5.8376115560531616e-01
    z[8,4,0]  R1778     3.7380585074424744e-01
    z[8,4,0]  R1779     4.8549342155456543e-01
    z[8,4,0]  R1780     6.9221824407577515e-01
    z[8,4,0]  R1781     2.0233023166656494e-01
    z[8,4,0]  R1782     1.2574322521686554e-01
    z[8,4,0]  R1783     2.5684067606925964e-01
    z[8,4,0]  R1784     1.1671365052461624e-01
    z[8,4,0]  R1785     2.3870217800140381e-01
    z[8,4,0]  R1786     1.5381184220314026e-01
    z[8,4,0]  R1787     5.1420134305953979e-01
    z[8,4,0]  R1788     2.2655582427978516e-01
    z[8,4,0]  R1789     0.283189594745636
    z[8,4,0]  R1790     2.7601400017738342e-01
    z[8,4,0]  R1791     3.5650694370269775e-01
    z[8,4,0]  R1792     2.8758205473423004e-02
    z[8,4,0]  R1793     2.2294494509696960e-01
    z[8,4,0]  R1794     2.8574812412261963e-01
    z[8,4,0]  R1795     -5.9725034981966019e-02
    z[8,4,0]  R1796     -0.0819258838891983
    z[8,4,0]  R1797     -7.8451806306838989e-01
    z[8,4,0]  R1798     -2.3863452672958374e-01
    z[8,4,0]  R1799     -4.2138642072677612e-01
    z[8,4,0]  R1800     -2.3271121084690094e-01
    z[8,4,0]  R1801     9.3946374952793121e-02
    z[8,4,0]  R1802     -6.3066649436950684e-01
    z[8,4,0]  R1803     -2.2421675920486450e-01
    z[8,4,0]  R1804     0.221639484167099
    z[8,4,0]  R1805     2.5867444276809692e-01
    z[8,4,0]  R1806     2.9126021265983582e-01
    z[8,4,0]  R1807     3.7454894185066223e-01
    z[8,4,0]  R1808     2.7899321913719177e-01
    z[8,4,0]  R1809     3.8191944360733032e-01
    z[8,4,0]  R1810     2.9376068711280823e-01
    z[8,4,0]  R1811     -0.0978270173072815
    z[8,4,0]  R1812     -2.9137728735804558e-02
    z[8,4,0]  R1813     7.4456967413425446e-02
    z[8,4,0]  R1814     1.8401703238487244e-01
    z[8,4,0]  R1815     0.302244633436203
    z[8,4,0]  R1816     1.1519994586706161e-01
    z[8,4,0]  R1817     -3.0517500638961792e-01
    z[8,4,0]  R1818     4.6974033117294312e-01
    z[8,4,0]  R1819     4.7435140609741211e-01
    z[8,4,0]  R1820     -2.6120521128177643e-02
    z[8,4,0]  R1821     0.317367821931839
    z[8,4,0]  R1822     -1.7612075433135033e-02
    z[8,4,0]  R1823     -1.6793097555637360e-01
    z[8,4,0]  R1824     -1.0067898780107498e-01
    z[8,4,0]  R1825     -1.6538232564926147e-02
    z[8,4,0]  R1826     -1.2822266668081284e-02
    z[8,4,0]  R1827     3.6187297105789185e-01
    z[8,4,0]  R1828     2.9852783679962158e-01
    z[8,4,0]  R1829     3.7791994214057922e-01
    z[8,4,0]  R1830     -3.7840750813484192e-01
    z[8,4,0]  R1831     -2.8823024034500122e-01
    z[8,4,0]  R1832     2.5137278437614441e-01
    z[8,4,0]  R1833     3.0971741676330566e-01
    z[8,4,0]  R1834     -0.0793575644493103
    z[8,4,0]  R1835     -1.8650509417057037e-01
    z[8,4,0]  R1836     1.6907888650894165e-01
    z[8,4,0]  R1837     3.1163122504949570e-02
    z[8,4,0]  R1838     1.5796346962451935e-01
    z[8,4,0]  R1839     2.8270235657691956e-01
    z[8,4,0]  R1840     -3.6034090444445610e-03
    z[8,4,0]  R1841     -1.9155786931514740e-01
    z[8,4,0]  R1842     -1.3722683489322662e-01
    z[8,4,0]  R1843     -2.5865417718887329e-01
    z[8,4,0]  R1844     -3.6463830620050430e-02
    z[8,4,0]  R1845     7.2248607873916626e-01
    z[8,4,0]  R1846     -9.6755206584930420e-02
    z[8,4,0]  R1847     -0.223170205950737
    z[8,4,0]  R1848     -4.9366939812898636e-02
    z[8,4,0]  R1849     2.2083133459091187e-01
    z[8,4,0]  R1850     1.7553773522377014e-01
    z[8,4,0]  R1851     4.5671370625495911e-01
    z[8,4,0]  R1852     -1.8355819582939148e-01
    z[8,4,0]  R1853     -2.1551392972469330e-01
    z[8,4,0]  R1854     0.100338414311409
    z[8,4,0]  R1855     -1.9112358568236232e-03
    z[8,4,0]  R1856     -1.3800835609436035e-01
    z[8,4,0]  R1857     2.6239061355590820e-01
    z[8,4,0]  R1858     3.1615287065505981e-01
    z[8,4,0]  R1859     3.3481448888778687e-01
    z[8,4,0]  R1860     6.4860087633132935e-01
    z[8,4,0]  R1861     2.3486499488353729e-01
    z[8,4,0]  R1862     3.1915476918220520e-01
    z[8,4,0]  R1863     4.6502545475959778e-01
    z[8,4,0]  R1864     6.9791865348815918e-01
    z[8,4,0]  R1865     -2.4639932811260223e-01
    z[8,4,0]  R1866     1.2444227188825607e-01
    z[8,4,0]  R1867     0.422778844833374
    z[8,4,0]  R1868     1.8694639205932617e-01
    z[8,4,0]  R1869     0.463606595993042
    z[8,4,0]  R1870     0.695311427116394
    z[8,4,0]  R1871     7.3519617319107056e-01
    z[8,4,0]  R1872     0.730003833770752
    z[8,4,1]  R39       1
    z[8,4,1]  R75       -1
    z[8,4,1]  R1746     -1
    z[8,4,1]  R1747     1
    z[8,4,1]  R1758     4.3278518319129944e-01
    z[8,4,1]  R1759     5.2865236997604370e-01
    z[8,4,1]  R1760     3.2280489802360535e-02
    z[8,4,1]  R1761     -1.0213023424148560e-01
    z[8,4,1]  R1762     3.5205683112144470e-01
    z[8,4,1]  R1763     0.0873582735657692
    z[8,4,1]  R1764     3.0650734901428223e-01
    z[8,4,1]  R1765     -1.1546940356492996e-01
    z[8,4,1]  R1766     -8.3069734275341034e-02
    z[8,4,1]  R1767     2.9835087060928345e-01
    z[8,4,1]  R1768     -0.0591592937707901
    z[8,4,1]  R1769     -6.5233409404754639e-02
    z[8,4,1]  R1770     -1.7246234416961670e-01
    z[8,4,1]  R1771     5.4489899426698685e-02
    z[8,4,1]  R1772     -7.5519219040870667e-02
    z[8,4,1]  R1773     -2.4127402901649475e-01
    z[8,4,1]  R1774     -6.4986400306224823e-02
    z[8,4,1]  R1775     6.6145914793014526e-01
    z[8,4,1]  R1776     -8.6502122879028320e-01
    z[8,4,1]  R1777     2.5387245416641235e-01
    z[8,4,1]  R1778     3.3545008301734924e-01
    z[8,4,1]  R1779     0.605156421661377
    z[8,4,1]  R1780     1.9629713892936707e-01
    z[8,4,1]  R1781     -0.922296404838562
    z[8,4,1]  R1782     -9.0870171785354614e-01
    z[8,4,1]  R1783     -9.0678805112838745e-01
    z[8,4,1]  R1784     -9.0038394927978516e-01
    z[8,4,1]  R1785     -8.7704312801361084e-01
    z[8,4,1]  R1786     -8.8701063394546509e-01
    z[8,4,1]  R1787     1.3998055458068848e-01
    z[8,4,1]  R1788     4.0884265303611755e-01
    z[8,4,1]  R1789     2.9602622613310814e-02
    z[8,4,1]  R1790     2.5092095136642456e-02
    z[8,4,1]  R1791     4.8419770598411560e-01
    z[8,4,1]  R1792     -0.950893223285675
    z[8,4,1]  R1793     -8.8206022977828979e-01
    z[8,4,1]  R1794     -8.9106363058090210e-01
    z[8,4,1]  R1795     -7.3857551813125610e-01
    z[8,4,1]  R1796     -6.0511809587478638e-01
    z[8,4,1]  R1797     2.8132668137550354e-01
    z[8,4,1]  R1798     4.2940124869346619e-01
    z[8,4,1]  R1799     7.5325970537960529e-03
    z[8,4,1]  R1800     5.7901513576507568e-01
    z[8,4,1]  R1801     2.0204983651638031e-01
    z[8,4,1]  R1802     8.6046881973743439e-02
    z[8,4,1]  R1803     2.8027138113975525e-01
    z[8,4,1]  R1804     4.9292293190956116e-01
    z[8,4,1]  R1805     3.1568199396133423e-01
    z[8,4,1]  R1806     6.7493891716003418e-01
    z[8,4,1]  R1807     5.9162467718124390e-01
    z[8,4,1]  R1808     1.0954042524099350e-01
    z[8,4,1]  R1809     4.5639863610267639e-01
    z[8,4,1]  R1810     1.4886243641376495e-01
    z[8,4,1]  R1811     -7.7556276321411133e-01
    z[8,4,1]  R1812     -6.4946508407592773e-01
    z[8,4,1]  R1813     -9.1136246919631958e-01
    z[8,4,1]  R1814     -8.9713948965072632e-01
    z[8,4,1]  R1815     -5.0371998548507690e-01
    z[8,4,1]  R1816     -8.0799359083175659e-01
    z[8,4,1]  R1817     -0.572062611579895
    z[8,4,1]  R1818     -7.7519947290420532e-01
    z[8,4,1]  R1819     -0.589427649974823
    z[8,4,1]  R1820     -6.5192335844039917e-01
    z[8,4,1]  R1821     -7.6822096109390259e-01
    z[8,4,1]  R1822     -4.5647367835044861e-01
    z[8,4,1]  R1823     -4.7322675585746765e-01
    z[8,4,1]  R1824     -6.4571005105972290e-01
    z[8,4,1]  R1825     -6.9772607088088989e-01
    z[8,4,1]  R1826     -8.3203715085983276e-01
    z[8,4,1]  R1827     -5.7106351852416992e-01
    z[8,4,1]  R1828     -4.4708859920501709e-01
    z[8,4,1]  R1829     -8.0021435022354126e-01
    z[8,4,1]  R1830     -7.7876365184783936e-01
    z[8,4,1]  R1831     -7.6200026273727417e-01
    z[8,4,1]  R1832     -7.6768219470977783e-01
    z[8,4,1]  R1833     -7.3314839601516724e-01
    z[8,4,1]  R1834     7.0500272512435913e-01
    z[8,4,1]  R1835     4.0483522415161133e-01
    z[8,4,1]  R1836     -5.5599248409271240e-01
    z[8,4,1]  R1837     -6.6381967067718506e-01
    z[8,4,1]  R1838     -9.0491241216659546e-01
    z[8,4,1]  R1839     -0.619698166847229
    z[8,4,1]  R1840     -5.0538444519042969e-01
    z[8,4,1]  R1841     -8.6528658866882324e-01
    z[8,4,1]  R1842     -7.7655076980590820e-01
    z[8,4,1]  R1843     -9.0143078565597534e-01
    z[8,4,1]  R1844     -7.0040273666381836e-01
    z[8,4,1]  R1845     2.1460117772221565e-02
    z[8,4,1]  R1846     -5.5794847011566162e-01
    z[8,4,1]  R1847     -8.7596380710601807e-01
    z[8,4,1]  R1848     -9.1440171003341675e-01
    z[8,4,1]  R1849     -6.7542958259582520e-01
    z[8,4,1]  R1850     -8.2888710498809814e-01
    z[8,4,1]  R1851     -6.4825212955474854e-01
    z[8,4,1]  R1852     -7.9127651453018188e-01
    z[8,4,1]  R1853     -8.2369971275329590e-01
    z[8,4,1]  R1854     -7.7229762077331543e-01
    z[8,4,1]  R1855     -8.8891887664794922e-01
    z[8,4,1]  R1856     -8.8942545652389526e-01
    z[8,4,1]  R1857     -0.79151850938797
    z[8,4,1]  R1858     -8.1461596488952637e-01
    z[8,4,1]  R1859     -8.2109457254409790e-01
    z[8,4,1]  R1860     -1.7773827910423279e-01
    z[8,4,1]  R1861     -7.5015085935592651e-01
    z[8,4,1]  R1862     -7.3993182182312012e-01
    z[8,4,1]  R1863     1.6175159811973572e-01
    z[8,4,1]  R1864     0.035215113312006
    z[8,4,1]  R1865     -0.937619686126709
    z[8,4,1]  R1866     -8.9324432611465454e-01
    z[8,4,1]  R1867     -7.7389258146286011e-01
    z[8,4,1]  R1868     -8.1678217649459839e-01
    z[8,4,1]  R1869     -4.9182184040546417e-02
    z[8,4,1]  R1870     4.4177651405334473e-01
    z[8,4,1]  R1871     4.1015404462814331e-01
    z[8,4,1]  R1872     3.9751288294792175e-01
    z[8,4,2]  R40       1
    z[8,4,2]  R76       -1
    z[8,4,2]  R1748     -1
    z[8,4,2]  R1749     1
    z[8,4,2]  R1758     4.4297706335783005e-02
    z[8,4,2]  R1759     -1.0253424942493439e-01
    z[8,4,2]  R1760     3.4196120500564575e-01
    z[8,4,2]  R1761     1.9986394047737122e-01
    z[8,4,2]  R1762     -8.1668362021446228e-02
    z[8,4,2]  R1763     2.2891965508460999e-01
    z[8,4,2]  R1764     5.2468216419219971e-01
    z[8,4,2]  R1765     -3.9801257848739624e-01
    z[8,4,2]  R1766     -4.8457396030426025e-01
    z[8,4,2]  R1767     -6.3851737976074219e-01
    z[8,4,2]  R1768     -3.4500178694725037e-01
    z[8,4,2]  R1769     -3.0746594071388245e-02
    z[8,4,2]  R1770     0.0672302395105362
    z[8,4,2]  R1771     -1.6945162415504456e-01
    z[8,4,2]  R1772     3.5668212175369263e-01
    z[8,4,2]  R1773     4.5615750551223755e-01
    z[8,4,2]  R1774     1.0421478748321533e-01
    z[8,4,2]  R1775     2.2317555546760559e-01
    z[8,4,2]  R1776     1.8342211842536926e-01
    z[8,4,2]  R1777     3.2977712154388428e-01
    z[8,4,2]  R1778     2.5324460864067078e-01
    z[8,4,2]  R1779     2.0797833800315857e-01
    z[8,4,2]  R1780     5.5952745676040649e-01
    z[8,4,2]  R1781     -1.7250286042690277e-01
    z[8,4,2]  R1782     1.0942266322672367e-02
    z[8,4,2]  R1783     -9.7748890519142151e-02
    z[8,4,2]  R1784     -1.1095040291547775e-01
    z[8,4,2]  R1785     8.1540994346141815e-02
    z[8,4,2]  R1786     1.9990071654319763e-02
    z[8,4,2]  R1787     3.3385327458381653e-01
    z[8,4,2]  R1788     -6.5134182572364807e-02
    z[8,4,2]  R1789     4.1693288087844849e-01
    z[8,4,2]  R1790     -3.3540013432502747e-01
    z[8,4,2]  R1791     3.5556885600090027e-01
    z[8,4,2]  R1792     -1.6824441030621529e-02
    z[8,4,2]  R1793     1.4960496127605438e-01
    z[8,4,2]  R1794     3.2649624347686768e-01
    z[8,4,2]  R1795     -5.8190923929214478e-01
    z[8,4,2]  R1796     -5.5336314439773560e-01
    z[8,4,2]  R1797     1.2565425038337708e-01
    z[8,4,2]  R1798     -7.2990462183952332e-02
    z[8,4,2]  R1799     -1.2438035011291504e-01
    z[8,4,2]  R1800     -1.6645358502864838e-01
    z[8,4,2]  R1801     -9.1014020144939423e-02
    z[8,4,2]  R1802     0.626151442527771
    z[8,4,2]  R1803     -2.4900703132152557e-01
    z[8,4,2]  R1804     1.0611472278833389e-01
    z[8,4,2]  R1805     9.1054454445838928e-02
    z[8,4,2]  R1806     -1.5911756455898285e-01
    z[8,4,2]  R1807     3.1160160899162292e-01
    z[8,4,2]  R1808     -1.1797026731073856e-02
    z[8,4,2]  R1809     -2.3035086691379547e-01
    z[8,4,2]  R1810     8.2876391708850861e-02
    z[8,4,2]  R1811     -3.3033519983291626e-01
    z[8,4,2]  R1812     -4.6171391010284424e-01
    z[8,4,2]  R1813     -3.1455031037330627e-01
    z[8,4,2]  R1814     1.0135427117347717e-01
    z[8,4,2]  R1815     -4.3890568614006042e-01
    z[8,4,2]  R1816     0.136931911110878
    z[8,4,2]  R1817     -6.8476319313049316e-01
    z[8,4,2]  R1818     -9.9444175139069557e-03
    z[8,4,2]  R1819     -4.6268993616104126e-01
    z[8,4,2]  R1820     -5.4729342460632324e-01
    z[8,4,2]  R1821     2.4883045256137848e-01
    z[8,4,2]  R1822     -6.9945007562637329e-01
    z[8,4,2]  R1823     -8.0823624134063721e-01
    z[8,4,2]  R1824     -6.4133191108703613e-01
    z[8,4,2]  R1825     -1.8304759636521339e-02
    z[8,4,2]  R1826     2.4319043755531311e-01
    z[8,4,2]  R1827     -6.8353205919265747e-01
    z[8,4,2]  R1828     -7.9876106977462769e-01
    z[8,4,2]  R1829     6.4935930073261261e-02
    z[8,4,2]  R1830     2.7095427736639977e-02
    z[8,4,2]  R1831     -1.4205268025398254e-01
    z[8,4,2]  R1832     -9.6215203404426575e-02
    z[8,4,2]  R1833     -1.0724537819623947e-01
    z[8,4,2]  R1834     -1.6476549208164215e-02
    z[8,4,2]  R1835     -2.6660233736038208e-01
    z[8,4,2]  R1836     -7.3061013221740723e-01
    z[8,4,2]  R1837     -6.6492223739624023e-01
    z[8,4,2]  R1838     1.3585336506366730e-01
    z[8,4,2]  R1839     -5.5617189407348633e-01
    z[8,4,2]  R1840     -5.2972149848937988e-01
    z[8,4,2]  R1841     -1.8511453270912170e-01
    z[8,4,2]  R1842     -2.8458639979362488e-01
    z[8,4,2]  R1843     3.7137895822525024e-02
    z[8,4,2]  R1844     -6.5151625871658325e-01
    z[8,4,2]  R1845     -4.9594688415527344e-01
    z[8,4,2]  R1846     -5.4087972640991211e-01
    z[8,4,2]  R1847     -1.7047224566340446e-02
    z[8,4,2]  R1848     2.7067303657531738e-01
    z[8,4,2]  R1849     -2.6017594337463379e-01
    z[8,4,2]  R1850     3.2183980941772461e-01
    z[8,4,2]  R1851     -1.6664777696132660e-01
    z[8,4,2]  R1852     -2.0325869321823120e-02
    z[8,4,2]  R1853     1.1372482031583786e-01
    z[8,4,2]  R1854     -5.3918910026550293e-01
    z[8,4,2]  R1855     -2.1300375461578369e-01
    z[8,4,2]  R1856     1.8503311276435852e-01
    z[8,4,2]  R1857     -3.3325843513011932e-02
    z[8,4,2]  R1858     -3.8550995290279388e-02
    z[8,4,2]  R1859     2.6382654905319214e-01
    z[8,4,2]  R1860     -9.6111074090003967e-02
    z[8,4,2]  R1861     -1.9729016721248627e-01
    z[8,4,2]  R1862     1.6195631027221680e-01
    z[8,4,2]  R1863     -1.3061526417732239e-01
    z[8,4,2]  R1864     -4.5849704742431641e-01
    z[8,4,2]  R1865     5.3239818662405014e-02
    z[8,4,2]  R1866     -4.7729674726724625e-02
    z[8,4,2]  R1867     -9.9238239228725433e-02
    z[8,4,2]  R1868     -1.8111547827720642e-01
    z[8,4,2]  R1869     -9.2884004116058350e-03
    z[8,4,2]  R1870     0.0757242813706398
    z[8,4,2]  R1871     0.326010137796402
    z[8,4,2]  R1872     1.1096108704805374e-01
    z[8,4,3]  R41       1
    z[8,4,3]  R77       -1
    z[8,4,3]  R1750     -1
    z[8,4,3]  R1751     1
    z[8,4,3]  R1758     3.3893135190010071e-01
    z[8,4,3]  R1759     1.7238068580627441e-01
    z[8,4,3]  R1760     -8.0694389343261719e-01
    z[8,4,3]  R1761     2.2265070676803589e-01
    z[8,4,3]  R1762     -1.2656930088996887e-01
    z[8,4,3]  R1763     4.0449026226997375e-01
    z[8,4,3]  R1764     -0.569337010383606
    z[8,4,3]  R1765     -6.4385145902633667e-01
    z[8,4,3]  R1766     1.1762108653783798e-02
    z[8,4,3]  R1767     -2.0890416204929352e-01
    z[8,4,3]  R1768     0.820968508720398
    z[8,4,3]  R1769     6.7245924472808838e-01
    z[8,4,3]  R1770     6.3162380456924438e-01
    z[8,4,3]  R1771     7.0842069387435913e-01
    z[8,4,3]  R1772     6.5730887651443481e-01
    z[8,4,3]  R1773     7.4381065368652344e-01
    z[8,4,3]  R1774     8.7322556972503662e-01
    z[8,4,3]  R1775     2.5221675634384155e-01
    z[8,4,3]  R1776     -2.6172018051147461e-01
    z[8,4,3]  R1777     3.6002656817436218e-01
    z[8,4,3]  R1778     3.9744228124618530e-01
    z[8,4,3]  R1779     2.2856892645359039e-01
    z[8,4,3]  R1780     3.2866531610488892e-01
    z[8,4,3]  R1781     -1.9448810815811157e-01
    z[8,4,3]  R1782     -1.3624049723148346e-01
    z[8,4,3]  R1783     1.0560864955186844e-01
    z[8,4,3]  R1784     8.2533389329910278e-02
    z[8,4,3]  R1785     3.7692766636610031e-02
    z[8,4,3]  R1786     1.9963359832763672e-01
    z[8,4,3]  R1787     6.4280843734741211e-01
    z[8,4,3]  R1788     7.4181818962097168e-01
    z[8,4,3]  R1789     8.2144778966903687e-01
    z[8,4,3]  R1790     6.5293055772781372e-01
    z[8,4,3]  R1791     6.0793638229370117e-01
    z[8,4,3]  R1792     -2.7843394875526428e-01
    z[8,4,3]  R1793     -1.4027177821844816e-03
    z[8,4,3]  R1794     -1.1982208490371704e-01
    z[8,4,3]  R1795     -1.3696564733982086e-01
    z[8,4,3]  R1796     -4.2138215899467468e-01
    z[8,4,3]  R1797     -2.8652116656303406e-01
    z[8,4,3]  R1798     3.5964247584342957e-01
    z[8,4,3]  R1799     2.0728701353073120e-01
    z[8,4,3]  R1800     -5.2693802118301392e-01
    z[8,4,3]  R1801     -6.0815256834030151e-01
    z[8,4,3]  R1802     2.3736244067549706e-02
    z[8,4,3]  R1803     3.3163344860076904e-01
    z[8,4,3]  R1804     7.7075809240341187e-01
    z[8,4,3]  R1805     8.5122185945510864e-01
    z[8,4,3]  R1806     0.625590443611145
    z[8,4,3]  R1807     6.2528085708618164e-01
    z[8,4,3]  R1808     9.3912720680236816e-01
    z[8,4,3]  R1809     6.7131775617599487e-01
    z[8,4,3]  R1810     7.4573343992233276e-01
    z[8,4,3]  R1811     -1.6835495829582214e-01
    z[8,4,3]  R1812     -1.0739649832248688e-01
    z[8,4,3]  R1813     -2.1419250965118408e-01
    z[8,4,3]  R1814     -1.6170606017112732e-01
    z[8,4,3]  R1815     -6.2765496969223022e-01
    z[8,4,3]  R1816     3.4590315818786621e-01
    z[8,4,3]  R1817     7.9685494303703308e-02
    z[8,4,3]  R1818     1.6408908367156982e-01
    z[8,4,3]  R1819     -2.7080511674284935e-02
    z[8,4,3]  R1820     -3.9443865418434143e-01
    z[8,4,3]  R1821     2.4014189839363098e-01
    z[8,4,3]  R1822     -1.2927785515785217e-01
    z[8,4,3]  R1823     0.0540459118783474
    z[8,4,3]  R1824     7.0934325456619263e-02
    z[8,4,3]  R1825     -5.7334297895431519e-01
    z[8,4,3]  R1826     2.5984886288642883e-01
    z[8,4,3]  R1827     1.1943177878856659e-01
    z[8,4,3]  R1828     -1.2809245288372040e-01
    z[8,4,3]  R1829     9.6224442124366760e-02
    z[8,4,3]  R1830     -3.6655715107917786e-01
    z[8,4,3]  R1831     0.0673820897936821
    z[8,4,3]  R1832     4.0417218208312988e-01
    z[8,4,3]  R1833     2.4162137508392334e-01
    z[8,4,3]  R1834     3.8890153169631958e-01
    z[8,4,3]  R1835     5.7501119375228882e-01
    z[8,4,3]  R1836     -2.3392596840858459e-01
    z[8,4,3]  R1837     4.7164112329483032e-02
    z[8,4,3]  R1838     1.7356034368276596e-02
    z[8,4,3]  R1839     -4.5801591873168945e-01
    z[8,4,3]  R1840     -3.3098584413528442e-01
    z[8,4,3]  R1841     -1.4017856121063232e-01
    z[8,4,3]  R1842     -4.1113600134849548e-01
    z[8,4,3]  R1843     6.7720770835876465e-02
    z[8,4,3]  R1844     -2.7207341790199280e-01
    z[8,4,3]  R1845     2.9130643606185913e-01
    z[8,4,3]  R1846     -0.48995241522789
    z[8,4,3]  R1847     0.154449462890625
    z[8,4,3]  R1848     -2.7712401747703552e-01
    z[8,4,3]  R1849     -3.0682352185249329e-01
    z[8,4,3]  R1850     -8.2297712564468384e-02
    z[8,4,3]  R1851     -3.5729256272315979e-01
    z[8,4,3]  R1852     7.8484527766704559e-02
    z[8,4,3]  R1853     -1.7783628404140472e-01
    z[8,4,3]  R1854     -8.9961253106594086e-02
    z[8,4,3]  R1855     1.8062674999237061e-01
    z[8,4,3]  R1856     -1.3411337137222290e-01
    z[8,4,3]  R1857     -5.0566357374191284e-01
    z[8,4,3]  R1858     2.0418265461921692e-01
    z[8,4,3]  R1859     5.1924187690019608e-02
    z[8,4,3]  R1860     2.6497477293014526e-01
    z[8,4,3]  R1861     -1.2366843223571777e-01
    z[8,4,3]  R1862     -2.4484993517398834e-01
    z[8,4,3]  R1863     2.2541526705026627e-02
    z[8,4,3]  R1864     3.8468053936958313e-01
    z[8,4,3]  R1865     -2.2348362207412720e-01
    z[8,4,3]  R1866     -2.5302174687385559e-01
    z[8,4,3]  R1867     2.5384664535522461e-01
    z[8,4,3]  R1868     5.5681776255369186e-02
    z[8,4,3]  R1869     5.7787474244832993e-02
    z[8,4,3]  R1870     -2.5616058707237244e-01
    z[8,4,3]  R1871     -2.4824059009552002e-01
    z[8,4,3]  R1872     -2.2069209814071655e-01
    z[8,4,4]  R42       1
    z[8,4,4]  R78       -1
    z[8,4,4]  R1752     -1
    z[8,4,4]  R1753     1
    z[8,4,4]  R1758     6.1544120311737061e-01
    z[8,4,4]  R1759     -1.6038011014461517e-01
    z[8,4,4]  R1760     -4.4960159808397293e-02
    z[8,4,4]  R1761     3.2772939652204514e-02
    z[8,4,4]  R1762     2.4203942716121674e-01
    z[8,4,4]  R1763     -7.1600514650344849e-01
    z[8,4,4]  R1764     -4.7515761852264404e-01
    z[8,4,4]  R1765     -4.7687861323356628e-01
    z[8,4,4]  R1766     -1.4801302552223206e-01
    z[8,4,4]  R1767     -8.6326800286769867e-02
    z[8,4,4]  R1768     -1.1482661962509155e-01
    z[8,4,4]  R1769     -7.4615702033042908e-03
    z[8,4,4]  R1770     -1.4398986101150513e-01
    z[8,4,4]  R1771     3.1648358702659607e-01
    z[8,4,4]  R1772     8.5796646773815155e-02
    z[8,4,4]  R1773     1.6937313973903656e-01
    z[8,4,4]  R1774     3.5484090447425842e-01
    z[8,4,4]  R1775     -5.3575527854263783e-03
    z[8,4,4]  R1776     -5.2903532981872559e-02
    z[8,4,4]  R1777     -5.3471463918685913e-01
    z[8,4,4]  R1778     -0.59151291847229
    z[8,4,4]  R1779     -7.9646848142147064e-02
    z[8,4,4]  R1780     -0.0201775711029768
    z[8,4,4]  R1781     4.5154165476560593e-02
    z[8,4,4]  R1782     1.6619296371936798e-01
    z[8,4,4]  R1783     1.6266991198062897e-01
    z[8,4,4]  R1784     -3.7581852078437805e-01
    z[8,4,4]  R1785     -2.7733482420444489e-03
    z[8,4,4]  R1786     2.2970676422119141e-01
    z[8,4,4]  R1787     -1.4652857184410095e-01
    z[8,4,4]  R1788     1.3311018049716949e-01
    z[8,4,4]  R1789     2.1338362246751785e-02
    z[8,4,4]  R1790     -4.9263462424278259e-01
    z[8,4,4]  R1791     1.3779577612876892e-01
    z[8,4,4]  R1792     -3.4126002341508865e-02
    z[8,4,4]  R1793     -1.0386031121015549e-01
    z[8,4,4]  R1794     -1.1333167552947998e-02
    z[8,4,4]  R1795     1.8678863346576691e-01
    z[8,4,4]  R1796     1.9302532076835632e-02
    z[8,4,4]  R1797     2.0960272848606110e-01
    z[8,4,4]  R1798     -3.7107229232788086e-02
    z[8,4,4]  R1799     -7.0225065946578979e-01
    z[8,4,4]  R1800     -4.7506490349769592e-01
    z[8,4,4]  R1801     -3.6551004648208618e-01
    z[8,4,4]  R1802     -4.3038591742515564e-01
    z[8,4,4]  R1803     4.4329786300659180e-01
    z[8,4,4]  R1804     -5.3792528808116913e-02
    z[8,4,4]  R1805     -4.5282721519470215e-02
    z[8,4,4]  R1806     6.5043777227401733e-02
    z[8,4,4]  R1807     1.4205466210842133e-01
    z[8,4,4]  R1808     8.2762479782104492e-02
    z[8,4,4]  R1809     1.7623870074748993e-01
    z[8,4,4]  R1810     3.9861190319061279e-01
    z[8,4,4]  R1811     -2.0020754635334015e-01
    z[8,4,4]  R1812     -1.9458557665348053e-01
    z[8,4,4]  R1813     -8.5982456803321838e-02
    z[8,4,4]  R1814     1.6359147429466248e-01
    z[8,4,4]  R1815     1.9855398684740067e-02
    z[8,4,4]  R1816     0.178420752286911
    z[8,4,4]  R1817     2.1477924287319183e-01
    z[8,4,4]  R1818     -1.5897114574909210e-01
    z[8,4,4]  R1819     2.6159333065152168e-02
    z[8,4,4]  R1820     1.6524660587310791e-01
    z[8,4,4]  R1821     0.0753258541226387
    z[8,4,4]  R1822     3.3169826865196228e-01
    z[8,4,4]  R1823     0.0411791168153286
    z[8,4,4]  R1824     2.2157919406890869e-01
    z[8,4,4]  R1825     -4.7878913581371307e-02
    z[8,4,4]  R1826     3.7933662533760071e-01
    z[8,4,4]  R1827     -1.9451610743999481e-02
    z[8,4,4]  R1828     1.8401028215885162e-01
    z[8,4,4]  R1829     2.4931050837039948e-01
    z[8,4,4]  R1830     9.7140751779079437e-02
    z[8,4,4]  R1831     4.1627818346023560e-01
    z[8,4,4]  R1832     3.2874977588653564e-01
    z[8,4,4]  R1833     -2.6751694083213806e-01
    z[8,4,4]  R1834     4.1147032380104065e-01
    z[8,4,4]  R1835     4.1332921385765076e-01
    z[8,4,4]  R1836     4.8051834106445312e-02
    z[8,4,4]  R1837     1.0222673416137695e-01
    z[8,4,4]  R1838     -2.2699016332626343e-01
    z[8,4,4]  R1839     6.3473515212535858e-02
    z[8,4,4]  R1840     8.2612454891204834e-02
    z[8,4,4]  R1841     -2.8288796544075012e-02
    z[8,4,4]  R1842     7.2491921484470367e-02
    z[8,4,4]  R1843     9.1149166226387024e-02
    z[8,4,4]  R1844     -7.5300313532352448e-02
    z[8,4,4]  R1845     1.7393555492162704e-02
    z[8,4,4]  R1846     8.6900874972343445e-02
    z[8,4,4]  R1847     -1.9447323679924011e-01
    z[8,4,4]  R1848     1.8232997506856918e-02
    z[8,4,4]  R1849     -3.6176049709320068e-01
    z[8,4,4]  R1850     2.2238619625568390e-01
    z[8,4,4]  R1851     -9.1401286423206329e-02
    z[8,4,4]  R1852     3.6532336473464966e-01
    z[8,4,4]  R1853     1.1237250268459320e-01
    z[8,4,4]  R1854     1.1224296689033508e-01
    z[8,4,4]  R1855     7.5787985697388649e-03
    z[8,4,4]  R1856     6.4320690929889679e-02
    z[8,4,4]  R1857     -1.3239432871341705e-01
    z[8,4,4]  R1858     2.5776756927371025e-02
    z[8,4,4]  R1859     3.5215219855308533e-01
    z[8,4,4]  R1860     6.4503157138824463e-01
    z[8,4,4]  R1861     4.3805581331253052e-01
    z[8,4,4]  R1862     -1.5390609204769135e-01
    z[8,4,4]  R1863     6.7675316333770752e-01
    z[8,4,4]  R1864     -3.6997926235198975e-01
    z[8,4,4]  R1865     -6.6607259213924408e-02
    z[8,4,4]  R1866     1.2064320594072342e-01
    z[8,4,4]  R1867     2.6603901386260986e-01
    z[8,4,4]  R1868     4.8441749811172485e-01
    z[8,4,4]  R1869     7.0256847143173218e-01
    z[8,4,4]  R1870     4.4332712888717651e-01
    z[8,4,4]  R1871     3.2140663266181946e-01
    z[8,4,4]  R1872     1.5471938252449036e-01
    z[8,4,5]  R43       1
    z[8,4,5]  R79       -1
    z[8,4,5]  R1754     -1
    z[8,4,5]  R1755     1
    z[8,4,5]  R1758     1.3929626345634460e-01
    z[8,4,5]  R1759     -3.5279604792594910e-01
    z[8,4,5]  R1760     3.8220237940549850e-02
    z[8,4,5]  R1761     2.1354711055755615e-01
    z[8,4,5]  R1762     -4.0999558568000793e-01
    z[8,4,5]  R1763     8.4200963377952576e-02
    z[8,4,5]  R1764     2.8404369950294495e-01
    z[8,4,5]  R1765     3.8109812140464783e-01
    z[8,4,5]  R1766     7.8728175163269043e-01
    z[8,4,5]  R1767     6.7090344429016113e-01
    z[8,4,5]  R1768     3.5295647382736206e-01
    z[8,4,5]  R1769     -2.4163994938135147e-02
    z[8,4,5]  R1770     2.7940610051155090e-01
    z[8,4,5]  R1771     2.9542475938796997e-02
    z[8,4,5]  R1772     2.8805750608444214e-01
    z[8,4,5]  R1773     -1.4151780307292938e-01
    z[8,4,5]  R1774     -5.8375686407089233e-02
    z[8,4,5]  R1775     5.0904947519302368e-01
    z[8,4,5]  R1776     -2.0721639692783356e-01
    z[8,4,5]  R1777     2.2999155521392822e-01
    z[8,4,5]  R1778     1.7055776715278625e-01
    z[8,4,5]  R1779     4.8161312937736511e-01
    z[8,4,5]  R1780     -1.8148081004619598e-01
    z[8,4,5]  R1781     0.072996124625206
    z[8,4,5]  R1782     -1.3415264897048473e-02
    z[8,4,5]  R1783     2.1625134348869324e-01
    z[8,4,5]  R1784     0.118670254945755
    z[8,4,5]  R1785     -0.221003919839859
    z[8,4,5]  R1786     -3.0883875489234924e-01
    z[8,4,5]  R1787     -1.3896717131137848e-01
    z[8,4,5]  R1788     3.2583504915237427e-01
    z[8,4,5]  R1789     -8.8345922529697418e-02
    z[8,4,5]  R1790     2.5804251432418823e-01
    z[8,4,5]  R1791     2.5488847494125366e-01
    z[8,4,5]  R1792     -0.0645069107413292
    z[8,4,5]  R1793     2.2342254221439362e-01
    z[8,4,5]  R1794     5.1044980064034462e-03
    z[8,4,5]  R1795     -2.3616391420364380e-01
    z[8,4,5]  R1796     -3.1501868367195129e-01
    z[8,4,5]  R1797     -2.9125988483428955e-01
    z[8,4,5]  R1798     2.8395307064056396e-01
    z[8,4,5]  R1799     3.8931244611740112e-01
    z[8,4,5]  R1800     -1.9168801605701447e-01
    z[8,4,5]  R1801     5.8619940280914307e-01
    z[8,4,5]  R1802     -2.4412751197814941e-02
    z[8,4,5]  R1803     -2.9837164282798767e-01
    z[8,4,5]  R1804     -2.8865331411361694e-01
    z[8,4,5]  R1805     1.4389933645725250e-01
    z[8,4,5]  R1806     -9.0629987418651581e-02
    z[8,4,5]  R1807     -3.2613296061754227e-02
    z[8,4,5]  R1808     -1.4074572920799255e-01
    z[8,4,5]  R1809     3.2871791720390320e-01
    z[8,4,5]  R1810     1.4860203862190247e-01
    z[8,4,5]  R1811     -4.4143116474151611e-01
    z[8,4,5]  R1812     -5.3421151638031006e-01
    z[8,4,5]  R1813     1.0798743367195129e-01
    z[8,4,5]  R1814     -2.9459038376808167e-01
    z[8,4,5]  R1815     -2.6060670614242554e-01
    z[8,4,5]  R1816     -7.2829827666282654e-02
    z[8,4,5]  R1817     -2.1018789708614349e-01
    z[8,4,5]  R1818     7.5851596891880035e-02
    z[8,4,5]  R1819     -3.5586071014404297e-01
    z[8,4,5]  R1820     -2.5549063086509705e-01
    z[8,4,5]  R1821     1.1772985756397247e-01
    z[8,4,5]  R1822     -2.9082307219505310e-01
    z[8,4,5]  R1823     -7.5395785272121429e-02
    z[8,4,5]  R1824     -2.9266867041587830e-01
    z[8,4,5]  R1825     -3.0513831973075867e-01
    z[8,4,5]  R1826     3.6092754453420639e-02
    z[8,4,5]  R1827     -0.0642428919672966
    z[8,4,5]  R1828     -1.3352457899600267e-03
    z[8,4,5]  R1829     2.5755900144577026e-01
    z[8,4,5]  R1830     -3.2464000582695007e-01
    z[8,4,5]  R1831     -0.275749534368515
    z[8,4,5]  R1832     2.5408431887626648e-01
    z[8,4,5]  R1833     -0.0939953550696373
    z[8,4,5]  R1834     -2.5288176536560059e-01
    z[8,4,5]  R1835     -2.3178742825984955e-01
    z[8,4,5]  R1836     -0.127928227186203
    z[8,4,5]  R1837     -3.0584850907325745e-01
    z[8,4,5]  R1838     -2.4475468695163727e-01
    z[8,4,5]  R1839     -6.1415430158376694e-02
    z[8,4,5]  R1840     -3.7571245431900024e-01
    z[8,4,5]  R1841     -2.3396830260753632e-01
    z[8,4,5]  R1842     -2.2887107729911804e-01
    z[8,4,5]  R1843     -2.9069520533084869e-02
    z[8,4,5]  R1844     -0.0584476999938488
    z[8,4,5]  R1845     -1.2071265280246735e-01
    z[8,4,5]  R1846     -3.0844411253929138e-01
    z[8,4,5]  R1847     -2.5860235095024109e-01
    z[8,4,5]  R1848     -2.2496019955724478e-03
    z[8,4,5]  R1849     -2.4236641824245453e-01
    z[8,4,5]  R1850     7.9531274735927582e-02
    z[8,4,5]  R1851     -4.3636941909790039e-01
    z[8,4,5]  R1852     -4.3903324007987976e-01
    z[8,4,5]  R1853     -9.9482253193855286e-02
    z[8,4,5]  R1854     -2.7293553948402405e-01
    z[8,4,5]  R1855     2.2007305920124054e-01
    z[8,4,5]  R1856     1.1336227878928185e-02
    z[8,4,5]  R1857     -1.5972651541233063e-01
    z[8,4,5]  R1858     4.2401656508445740e-01
    z[8,4,5]  R1859     1.3125570118427277e-01
    z[8,4,5]  R1860     4.9722746014595032e-02
    z[8,4,5]  R1861     -9.0187273919582367e-02
    z[8,4,5]  R1862     0.148108571767807
    z[8,4,5]  R1863     -4.6637412905693054e-01
    z[8,4,5]  R1864     -1.2660789489746094e-01
    z[8,4,5]  R1865     -2.2432606667280197e-02
    z[8,4,5]  R1866     -3.3498124685138464e-03
    z[8,4,5]  R1867     -2.0628614723682404e-01
    z[8,4,5]  R1868     -6.0372814536094666e-02
    z[8,4,5]  R1869     -5.1319307088851929e-01
    z[8,4,5]  R1870     -1.2096808850765228e-01
    z[8,4,5]  R1871     -1.0360217653214931e-02
    z[8,4,5]  R1872     1.5313176810741425e-01
    z[8,4,6]  R44       1
    z[8,4,6]  R80       -1
    z[8,4,6]  R1756     -1
    z[8,4,6]  R1757     1
    z[8,4,6]  R1758     -2.7296485379338264e-02
    z[8,4,6]  R1759     -6.9551318883895874e-01
    z[8,4,6]  R1760     -9.9850669503211975e-03
    z[8,4,6]  R1761     1.2903241813182831e-01
    z[8,4,6]  R1762     0.614565372467041
    z[8,4,6]  R1763     4.7373369336128235e-01
    z[8,4,6]  R1764     -9.6105104312300682e-03
    z[8,4,6]  R1765     -1.6487258672714233e-01
    z[8,4,6]  R1766     -3.3270925283432007e-01
    z[8,4,6]  R1767     -1.5050514601171017e-02
    z[8,4,6]  R1768     2.5339301675558090e-02
    z[8,4,6]  R1769     4.1012936830520630e-01
    z[8,4,6]  R1770     -2.2790496051311493e-01
    z[8,4,6]  R1771     1.9731713831424713e-01
    z[8,4,6]  R1772     -8.0265142023563385e-02
    z[8,4,6]  R1773     -2.3283023387193680e-02
    z[8,4,6]  R1774     9.9094063043594360e-02
    z[8,4,6]  R1775     3.0142712593078613e-01
    z[8,4,6]  R1776     1.8220894038677216e-01
    z[8,4,6]  R1777     1.3260385394096375e-01
    z[8,4,6]  R1778     3.8297748565673828e-01
    z[8,4,6]  R1779     2.5355115532875061e-01
    z[8,4,6]  R1780     1.6693432629108429e-01
    z[8,4,6]  R1781     1.8298017978668213e-01
    z[8,4,6]  R1782     3.3461713790893555e-01
    z[8,4,6]  R1783     1.3354423642158508e-01
    z[8,4,6]  R1784     3.5253062844276428e-02
    z[8,4,6]  R1785     -3.4190145134925842e-01
    z[8,4,6]  R1786     3.3973187208175659e-02
    z[8,4,6]  R1787     3.8801971077919006e-01
    z[8,4,6]  R1788     3.2108667492866516e-01
    z[8,4,6]  R1789     2.4911326169967651e-01
    z[8,4,6]  R1790     2.7404436469078064e-01
    z[8,4,6]  R1791     2.4183419346809387e-01
    z[8,4,6]  R1792     -1.0881573706865311e-01
    z[8,4,6]  R1793     -2.9862526059150696e-01
    z[8,4,6]  R1794     0.0569380484521389
    z[8,4,6]  R1795     -5.3832545876502991e-02
    z[8,4,6]  R1796     -2.0913438498973846e-01
    z[8,4,6]  R1797     2.8060242533683777e-01
    z[8,4,6]  R1798     -7.3620069026947021e-01
    z[8,4,6]  R1799     3.4527981281280518e-01
    z[8,4,6]  R1800     -2.0684666931629181e-01
    z[8,4,6]  R1801     3.0820357799530029e-01
    z[8,4,6]  R1802     -0.128057062625885
    z[8,4,6]  R1803     6.4315706491470337e-01
    z[8,4,6]  R1804     1.2790703773498535e-01
    z[8,4,6]  R1805     -2.7893617749214172e-01
    z[8,4,6]  R1806     1.7463859915733337e-01
    z[8,4,6]  R1807     1.9452748820185661e-02
    z[8,4,6]  R1808     -3.7492178380489349e-02
    z[8,4,6]  R1809     -5.4711066186428070e-02
    z[8,4,6]  R1810     3.8416630029678345e-01
    z[8,4,6]  R1811     0.128541499376297
    z[8,4,6]  R1812     -1.7142567038536072e-01
    z[8,4,6]  R1813     3.5137572558596730e-04
    z[8,4,6]  R1814     -1.0635446012020111e-01
    z[8,4,6]  R1815     3.9185993373394012e-03
    z[8,4,6]  R1816     -3.9791685342788696e-01
    z[8,4,6]  R1817     1.1854583024978638e-01
    z[8,4,6]  R1818     3.4693002700805664e-01
    z[8,4,6]  R1819     2.9228290915489197e-01
    z[8,4,6]  R1820     -1.6315580904483795e-01
    z[8,4,6]  R1821     4.1230472922325134e-01
    z[8,4,6]  R1822     -3.0129143595695496e-01
    z[8,4,6]  R1823     -2.9035961627960205e-01
    z[8,4,6]  R1824     1.4775559306144714e-01
    z[8,4,6]  R1825     -2.9739844799041748e-01
    z[8,4,6]  R1826     1.8891172111034393e-01
    z[8,4,6]  R1827     -2.3863962292671204e-01
    z[8,4,6]  R1828     -1.5067948400974274e-01
    z[8,4,6]  R1829     2.7361556887626648e-01
    z[8,4,6]  R1830     -2.0225435495376587e-02
    z[8,4,6]  R1831     2.4946808815002441e-01
    z[8,4,6]  R1832     4.7203049063682556e-02
    z[8,4,6]  R1833     -4.6506536006927490e-01
    z[8,4,6]  R1834     3.3451551198959351e-01
    z[8,4,6]  R1835     -4.1838163137435913e-01
    z[8,4,6]  R1836     -2.3472876846790314e-01
    z[8,4,6]  R1837     1.0016328841447830e-01
    z[8,4,6]  R1838     1.6122755408287048e-01
    z[8,4,6]  R1839     9.5639698207378387e-02
    z[8,4,6]  R1840     -4.5434826612472534e-01
    z[8,4,6]  R1841     -3.2423120737075806e-01
    z[8,4,6]  R1842     -2.6547786593437195e-01
    z[8,4,6]  R1843     -3.2465690374374390e-01
    z[8,4,6]  R1844     2.2864004597067833e-02
    z[8,4,6]  R1845     -3.6312052607536316e-01
    z[8,4,6]  R1846     -2.0985266566276550e-01
    z[8,4,6]  R1847     -2.3246988654136658e-01
    z[8,4,6]  R1848     -1.0503920912742615e-01
    z[8,4,6]  R1849     -3.7892490625381470e-01
    z[8,4,6]  R1850     3.4058490395545959e-01
    z[8,4,6]  R1851     -1.3030645251274109e-01
    z[8,4,6]  R1852     8.6043469607830048e-02
    z[8,4,6]  R1853     4.5605826377868652e-01
    z[8,4,6]  R1854     -0.087053082883358
    z[8,4,6]  R1855     -2.8867509961128235e-01
    z[8,4,6]  R1856     3.6522147059440613e-01
    z[8,4,6]  R1857     0.0693008303642273
    z[8,4,6]  R1858     1.1321227252483368e-01
    z[8,4,6]  R1859     -1.2769292108714581e-02
    z[8,4,6]  R1860     -2.2302225232124329e-01
    z[8,4,6]  R1861     3.5758644342422485e-01
    z[8,4,6]  R1862     -4.6779972314834595e-01
    z[8,4,6]  R1863     -2.5400716066360474e-01
    z[8,4,6]  R1864     -2.3589698597788811e-02
    z[8,4,6]  R1865     4.9371778964996338e-02
    z[8,4,6]  R1866     -3.2521459460258484e-01
    z[8,4,6]  R1867     1.8636316061019897e-01
    z[8,4,6]  R1868     1.5397830307483673e-01
    z[8,4,6]  R1869     1.4918014407157898e-01
    z[8,4,6]  R1870     1.9710658490657806e-01
    z[8,4,6]  R1871     -1.4122587442398071e-01
    z[8,4,6]  R1872     0.447965532541275
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R1963     -1
    z[5,6,0]  R1964     1
    z[5,6,0]  R1977     -9.8129129037261009e-03
    z[5,6,0]  R1978     1.9520588219165802e-01
    z[5,6,0]  R1979     -1.5761759877204895e-01
    z[5,6,0]  R1980     2.8266796469688416e-01
    z[5,6,0]  R1981     -0.0914662703871727
    z[5,6,0]  R1982     3.5185284912586212e-02
    z[5,6,0]  R1983     -4.4540934264659882e-02
    z[5,6,0]  R1984     -1.4993159100413322e-02
    z[5,6,0]  R1985     -1.7481365799903870e-01
    z[5,6,0]  R1986     -1.2111248821020126e-01
    z[5,6,0]  R1987     2.3999631404876709e-01
    z[5,6,0]  R1988     3.7114644050598145e-01
    z[5,6,0]  R1989     3.3333885669708252e-01
    z[5,6,0]  R1990     1.5405425429344177e-01
    z[5,6,0]  R1991     0.344827800989151
    z[5,6,0]  R1992     1.6298142075538635e-01
    z[5,6,0]  R1993     -6.8737521767616272e-02
    z[5,6,0]  R1994     1.7824020236730576e-02
    z[5,6,0]  R1995     -1.6613408923149109e-01
    z[5,6,0]  R1996     -0.219927579164505
    z[5,6,0]  R1997     0.153601735830307
    z[5,6,0]  R1998     2.2325752675533295e-01
    z[5,6,0]  R1999     7.2254180908203125e-02
    z[5,6,0]  R2000     3.1756952404975891e-01
    z[5,6,0]  R2001     8.4015719592571259e-02
    z[5,6,0]  R2002     5.8751013129949570e-02
    z[5,6,0]  R2003     -4.2334833741188049e-01
    z[5,6,0]  R2004     2.5880929827690125e-01
    z[5,6,0]  R2005     -1.4871890842914581e-01
    z[5,6,0]  R2006     -0.283314973115921
    z[5,6,0]  R2007     4.5690831542015076e-01
    z[5,6,0]  R2008     1.1496644467115402e-01
    z[5,6,0]  R2009     2.3103404045104980e-01
    z[5,6,0]  R2010     -2.2177945077419281e-01
    z[5,6,0]  R2011     3.5804096609354019e-02
    z[5,6,0]  R2012     -6.4874303340911865e-01
    z[5,6,0]  R2013     -7.3766535520553589e-01
    z[5,6,0]  R2014     -3.5329201817512512e-01
    z[5,6,0]  R2015     -9.5257240533828735e-01
    z[5,6,0]  R2016     -9.4518017768859863e-01
    z[5,6,0]  R2017     -8.1584942340850830e-01
    z[5,6,0]  R2018     -8.3547770977020264e-01
    z[5,6,0]  R2019     -7.3414427042007446e-01
    z[5,6,0]  R2020     -7.2544336318969727e-01
    z[5,6,0]  R2021     -4.9633827805519104e-01
    z[5,6,0]  R2022     -6.7537021636962891e-01
    z[5,6,0]  R2023     -7.6199799776077271e-01
    z[5,6,0]  R2024     -4.8303210735321045e-01
    z[5,6,0]  R2025     -8.3185464143753052e-01
    z[5,6,0]  R2026     -4.0691459178924561e-01
    z[5,6,0]  R2027     4.9099221825599670e-01
    z[5,6,0]  R2028     9.3766905367374420e-02
    z[5,6,0]  R2029     5.0753045082092285e-01
    z[5,6,0]  R2030     4.2190632224082947e-01
    z[5,6,0]  R2031     4.9894136190414429e-01
    z[5,6,0]  R2032     5.4266828298568726e-01
    z[5,6,0]  R2033     2.8890156745910645e-01
    z[5,6,0]  R2034     3.7113168835639954e-01
    z[5,6,0]  R2035     5.5590659379959106e-01
    z[5,6,0]  R2036     6.8955369293689728e-02
    z[5,6,0]  R2037     8.2336896657943726e-01
    z[5,6,0]  R2038     0.833395779132843
    z[5,6,0]  R2039     7.7884292602539062e-01
    z[5,6,0]  R2040     7.2519683837890625e-01
    z[5,6,0]  R2041     9.1842484474182129e-01
    z[5,6,0]  R2042     0.709715723991394
    z[5,6,0]  R2043     7.4419897794723511e-01
    z[5,6,0]  R2044     8.4135973453521729e-01
    z[5,6,0]  R2045     0.773284912109375
    z[5,6,0]  R2046     7.9004669189453125e-01
    z[5,6,0]  R2047     8.4471255540847778e-01
    z[5,6,0]  R2048     7.1160227060317993e-01
    z[5,6,0]  R2049     7.2750610113143921e-01
    z[5,6,0]  R2050     -6.0652363300323486e-01
    z[5,6,0]  R2051     3.0945724248886108e-01
    z[5,6,0]  R2052     -6.7812144756317139e-02
    z[5,6,0]  R2053     -1.1857558786869049e-01
    z[5,6,0]  R2054     -4.5286703854799271e-02
    z[5,6,0]  R2055     -3.7151089310646057e-01
    z[5,6,0]  R2056     -8.5053868591785431e-02
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R1965     -1
    z[5,6,1]  R1966     1
    z[5,6,1]  R1977     -3.6789214611053467e-01
    z[5,6,1]  R1978     -5.0035309791564941e-01
    z[5,6,1]  R1979     -3.2951968908309937e-01
    z[5,6,1]  R1980     -1.0314059257507324e-01
    z[5,6,1]  R1981     -2.8634673357009888e-01
    z[5,6,1]  R1982     -1.9924721121788025e-01
    z[5,6,1]  R1983     8.7003123760223389e-01
    z[5,6,1]  R1984     8.0698674917221069e-01
    z[5,6,1]  R1985     6.1325830221176147e-01
    z[5,6,1]  R1986     5.8618915081024170e-01
    z[5,6,1]  R1987     -6.2944030761718750e-01
    z[5,6,1]  R1988     -5.4059320688247681e-01
    z[5,6,1]  R1989     -5.4516172409057617e-01
    z[5,6,1]  R1990     -6.5914779901504517e-01
    z[5,6,1]  R1991     -4.8302519321441650e-01
    z[5,6,1]  R1992     -5.9477454423904419e-01
    z[5,6,1]  R1993     -5.0718593597412109e-01
    z[5,6,1]  R1994     -5.7386404275894165e-01
    z[5,6,1]  R1995     1.0970901697874069e-01
    z[5,6,1]  R1996     -5.7534945011138916e-01
    z[5,6,1]  R1997     -5.3369557857513428e-01
    z[5,6,1]  R1998     -8.9994937181472778e-01
    z[5,6,1]  R1999     -7.2926950454711914e-01
    z[5,6,1]  R2000     -6.6056615114212036e-01
    z[5,6,1]  R2001     1.3864208944141865e-02
    z[5,6,1]  R2002     5.8342820405960083e-01
    z[5,6,1]  R2003     6.5766614675521851e-01
    z[5,6,1]  R2004     2.0050309598445892e-01
    z[5,6,1]  R2005     5.5003219842910767e-01
    z[5,6,1]  R2006     4.6862110495567322e-01
    z[5,6,1]  R2007     -0.463623583316803
    z[5,6,1]  R2008     -5.8346712589263916e-01
    z[5,6,1]  R2009     -7.5760698318481445e-01
    z[5,6,1]  R2010     4.2335048317909241e-01
    z[5,6,1]  R2011     4.4613838195800781e-01
    z[5,6,1]  R2012     1.3833696953952312e-02
    z[5,6,1]  R2013     -3.3223412930965424e-02
    z[5,6,1]  R2014     2.0151835680007935e-01
    z[5,6,1]  R2015     -4.3788510374724865e-03
    z[5,6,1]  R2016     -1.3158197514712811e-02
    z[5,6,1]  R2017     -1.8467040359973907e-01
    z[5,6,1]  R2018     -1.3740491867065430e-01
    z[5,6,1]  R2019     -0.263480544090271
    z[5,6,1]  R2020     -1.7347732186317444e-01
    z[5,6,1]  R2021     -0.11562529951334
    z[5,6,1]  R2022     1.0543778538703918e-01
    z[5,6,1]  R2023     1.0626516491174698e-01
    z[5,6,1]  R2024     2.3209260404109955e-01
    z[5,6,1]  R2025     -1.7743978649377823e-02
    z[5,6,1]  R2026     -7.4440743774175644e-03
    z[5,6,1]  R2027     -6.4555935561656952e-02
    z[5,6,1]  R2028     0.802198052406311
    z[5,6,1]  R2029     -2.0031096041202545e-01
    z[5,6,1]  R2030     -4.7008499503135681e-01
    z[5,6,1]  R2031     1.9505453109741211e-01
    z[5,6,1]  R2032     2.5065168738365173e-01
    z[5,6,1]  R2033     3.4602823853492737e-01
    z[5,6,1]  R2034     1.4450013637542725e-01
    z[5,6,1]  R2035     -3.8335135579109192e-01
    z[5,6,1]  R2036     9.0766036510467529e-01
    z[5,6,1]  R2037     -1.2319023162126541e-01
    z[5,6,1]  R2038     1.5052442252635956e-01
    z[5,6,1]  R2039     -5.3521089255809784e-02
    z[5,6,1]  R2040     -3.0439051985740662e-01
    z[5,6,1]  R2041     7.6228104531764984e-02
    z[5,6,1]  R2042     -4.0170428156852722e-01
    z[5,6,1]  R2043     -0.518860399723053
    z[5,6,1]  R2044     0.0714452788233757
    z[5,6,1]  R2045     1.4823582768440247e-01
    z[5,6,1]  R2046     1.9825264811515808e-01
    z[5,6,1]  R2047     -1.4329980313777924e-01
    z[5,6,1]  R2048     -2.7208226919174194e-01
    z[5,6,1]  R2049     -3.5209563374519348e-01
    z[5,6,1]  R2050     5.8529919385910034e-01
    z[5,6,1]  R2051     4.4666466116905212e-01
    z[5,6,1]  R2052     7.4827569723129272e-01
    z[5,6,1]  R2053     4.2190197110176086e-01
    z[5,6,1]  R2054     4.2537638545036316e-01
    z[5,6,1]  R2055     1.8803621828556061e-01
    z[5,6,1]  R2056     2.5354531407356262e-01
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R1967     -1
    z[5,6,2]  R1968     1
    z[5,6,2]  R1977     -6.9622492790222168e-01
    z[5,6,2]  R1978     -7.2611391544342041e-01
    z[5,6,2]  R1979     -2.7461823821067810e-01
    z[5,6,2]  R1980     -6.0160207748413086e-01
    z[5,6,2]  R1981     4.5172579586505890e-02
    z[5,6,2]  R1982     1.1268923431634903e-01
    z[5,6,2]  R1983     2.4226620793342590e-01
    z[5,6,2]  R1984     -3.1493294239044189e-01
    z[5,6,2]  R1985     3.6262005567550659e-01
    z[5,6,2]  R1986     -2.9705882072448730e-01
    z[5,6,2]  R1987     4.5650824904441833e-01
    z[5,6,2]  R1988     0.0513649582862854
    z[5,6,2]  R1989     4.0688481926918030e-01
    z[5,6,2]  R1990     5.0679886341094971e-01
    z[5,6,2]  R1991     4.5397931337356567e-01
    z[5,6,2]  R1992     3.9233011007308960e-01
    z[5,6,2]  R1993     7.6157444715499878e-01
    z[5,6,2]  R1994     -1.0714815557003021e-01
    z[5,6,2]  R1995     1.4869058132171631e-01
    z[5,6,2]  R1996     5.1525270938873291e-01
    z[5,6,2]  R1997     1.2777386605739594e-01
    z[5,6,2]  R1998     2.8799328207969666e-01
    z[5,6,2]  R1999     4.3757927417755127e-01
    z[5,6,2]  R2000     3.7901647388935089e-02
    z[5,6,2]  R2001     -3.0423361063003540e-01
    z[5,6,2]  R2002     0.0686836838722229
    z[5,6,2]  R2003     2.3707339167594910e-01
    z[5,6,2]  R2004     -3.2546824216842651e-01
    z[5,6,2]  R2005     4.7030287981033325e-01
    z[5,6,2]  R2006     7.1690547466278076e-01
    z[5,6,2]  R2007     -1.5700435638427734e-01
    z[5,6,2]  R2008     -1.1567012220621109e-01
    z[5,6,2]  R2009     1.6201768815517426e-01
    z[5,6,2]  R2010     -0.000394883711123839
    z[5,6,2]  R2011     -4.6268694102764130e-02
    z[5,6,2]  R2012     0.632844865322113
    z[5,6,2]  R2013     6.0275137424468994e-01
    z[5,6,2]  R2014     8.0314534902572632e-01
    z[5,6,2]  R2015     -8.1650130450725555e-02
    z[5,6,2]  R2016     -2.1970146894454956e-01
    z[5,6,2]  R2017     2.8686735033988953e-01
    z[5,6,2]  R2018     4.7996678948402405e-01
    z[5,6,2]  R2019     3.2032766938209534e-01
    z[5,6,2]  R2020     0.468130499124527
    z[5,6,2]  R2021     8.5109126567840576e-01
    z[5,6,2]  R2022     5.6741166114807129e-01
    z[5,6,2]  R2023     5.0181424617767334e-01
    z[5,6,2]  R2024     6.3314098119735718e-01
    z[5,6,2]  R2025     -4.0242251753807068e-01
    z[5,6,2]  R2026     6.1131817102432251e-01
    z[5,6,2]  R2027     2.3638445138931274e-01
    z[5,6,2]  R2028     -2.1357320249080658e-02
    z[5,6,2]  R2029     1.7076766490936279e-01
    z[5,6,2]  R2030     3.5945731401443481e-01
    z[5,6,2]  R2031     3.8796633481979370e-01
    z[5,6,2]  R2032     3.3352798223495483e-01
    z[5,6,2]  R2033     -7.1650457382202148e-01
    z[5,6,2]  R2034     -7.4348253011703491e-01
    z[5,6,2]  R2035     -4.6164166927337646e-01
    z[5,6,2]  R2036     9.9883466958999634e-02
    z[5,6,2]  R2037     -2.6978502050042152e-02
    z[5,6,2]  R2038     3.1799456477165222e-01
    z[5,6,2]  R2039     5.3231620788574219e-01
    z[5,6,2]  R2040     4.8598667979240417e-01
    z[5,6,2]  R2041     2.3269085586071014e-01
    z[5,6,2]  R2042     3.8618156313896179e-01
    z[5,6,2]  R2043     1.1577173322439194e-01
    z[5,6,2]  R2044     -2.1999187767505646e-01
    z[5,6,2]  R2045     3.9089924097061157e-01
    z[5,6,2]  R2046     3.9018783718347549e-02
    z[5,6,2]  R2047     -3.4256213903427124e-01
    z[5,6,2]  R2048     8.4643848240375519e-02
    z[5,6,2]  R2049     -0.0328790545463562
    z[5,6,2]  R2050     -3.7224420905113220e-01
    z[5,6,2]  R2051     0.0223090797662735
    z[5,6,2]  R2052     7.9673487925902009e-04
    z[5,6,2]  R2053     -1.5540605783462524e-01
    z[5,6,2]  R2054     2.8781020641326904e-01
    z[5,6,2]  R2055     -6.6818159818649292e-01
    z[5,6,2]  R2056     3.0707883834838867e-01
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R1969     -1
    z[5,6,3]  R1970     1
    z[5,6,3]  R1977     -5.0675177574157715e-01
    z[5,6,3]  R1978     -3.2096511125564575e-01
    z[5,6,3]  R1979     -7.4928396940231323e-01
    z[5,6,3]  R1980     -4.3389534950256348e-01
    z[5,6,3]  R1981     -7.7240854501724243e-01
    z[5,6,3]  R1982     -8.7970989942550659e-01
    z[5,6,3]  R1983     1.8954710662364960e-01
    z[5,6,3]  R1984     3.9096572995185852e-01
    z[5,6,3]  R1985     4.5994141697883606e-01
    z[5,6,3]  R1986     3.7445747852325439e-01
    z[5,6,3]  R1987     4.6504649519920349e-01
    z[5,6,3]  R1988     3.9717164635658264e-01
    z[5,6,3]  R1989     2.4929851293563843e-01
    z[5,6,3]  R1990     2.7586460113525391e-01
    z[5,6,3]  R1991     3.1510126590728760e-01
    z[5,6,3]  R1992     4.0119731426239014e-01
    z[5,6,3]  R1993     1.7297795414924622e-01
    z[5,6,3]  R1994     5.4737234115600586e-01
    z[5,6,3]  R1995     7.9029762744903564e-01
    z[5,6,3]  R1996     3.0459839105606079e-01
    z[5,6,3]  R1997     -5.2225482463836670e-01
    z[5,6,3]  R1998     -6.8153828382492065e-02
    z[5,6,3]  R1999     -0.325148344039917
    z[5,6,3]  R2000     9.7793549299240112e-02
    z[5,6,3]  R2001     8.6659216880798340e-01
    z[5,6,3]  R2002     6.6719287633895874e-01
    z[5,6,3]  R2003     2.0496146380901337e-01
    z[5,6,3]  R2004     7.9203724861145020e-01
    z[5,6,3]  R2005     4.9671131372451782e-01
    z[5,6,3]  R2006     3.6976906657218933e-01
    z[5,6,3]  R2007     -3.4159377217292786e-01
    z[5,6,3]  R2008     -5.6467545032501221e-01
    z[5,6,3]  R2009     7.7789083123207092e-02
    z[5,6,3]  R2010     7.2253561019897461e-01
    z[5,6,3]  R2011     8.7832385301589966e-01
    z[5,6,3]  R2012     1.3626362383365631e-01
    z[5,6,3]  R2013     2.0366945862770081e-01
    z[5,6,3]  R2014     3.8393866270780563e-02
    z[5,6,3]  R2015     7.4244342744350433e-02
    z[5,6,3]  R2016     1.7947238683700562e-01
    z[5,6,3]  R2017     -0.258035808801651
    z[5,6,3]  R2018     1.2278497964143753e-01
    z[5,6,3]  R2019     1.5831816196441650e-01
    z[5,6,3]  R2020     -8.6031429469585419e-02
    z[5,6,3]  R2021     1.6550848260521889e-02
    z[5,6,3]  R2022     3.3472830057144165e-01
    z[5,6,3]  R2023     -1.8150122463703156e-01
    z[5,6,3]  R2024     4.3236851692199707e-02
    z[5,6,3]  R2025     2.4676360189914703e-01
    z[5,6,3]  R2026     2.7102762460708618e-01
    z[5,6,3]  R2027     8.2595801353454590e-01
    z[5,6,3]  R2028     5.1190227270126343e-01
    z[5,6,3]  R2029     -4.7305294871330261e-01
    z[5,6,3]  R2030     -4.7772252559661865e-01
    z[5,6,3]  R2031     -2.2916845977306366e-01
    z[5,6,3]  R2032     3.6530005931854248e-01
    z[5,6,3]  R2033     2.2059649229049683e-01
    z[5,6,3]  R2034     0.436553955078125
    z[5,6,3]  R2035     2.1341089904308319e-01
    z[5,6,3]  R2036     8.2821629941463470e-02
    z[5,6,3]  R2037     4.1775268316268921e-01
    z[5,6,3]  R2038     1.7087125778198242e-01
    z[5,6,3]  R2039     6.1872269958257675e-02
    z[5,6,3]  R2040     -2.9044350981712341e-01
    z[5,6,3]  R2041     2.3048759996891022e-01
    z[5,6,3]  R2042     1.4789731800556183e-01
    z[5,6,3]  R2043     2.0402505993843079e-02
    z[5,6,3]  R2044     4.0229588747024536e-01
    z[5,6,3]  R2045     5.2630184218287468e-03
    z[5,6,3]  R2046     8.6509138345718384e-02
    z[5,6,3]  R2047     -2.4839197099208832e-01
    z[5,6,3]  R2048     -4.9620926380157471e-01
    z[5,6,3]  R2049     -2.7569499611854553e-01
    z[5,6,3]  R2050     -1.9026175141334534e-02
    z[5,6,3]  R2051     5.1256150007247925e-01
    z[5,6,3]  R2052     3.8620454072952271e-01
    z[5,6,3]  R2053     7.3760688304901123e-01
    z[5,6,3]  R2054     5.5118137598037720e-01
    z[5,6,3]  R2055     -5.6256562471389771e-01
    z[5,6,3]  R2056     4.1415810585021973e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R1971     -1
    z[5,6,4]  R1972     1
    z[5,6,4]  R1977     -2.8575715422630310e-01
    z[5,6,4]  R1978     -1.8454520404338837e-01
    z[5,6,4]  R1979     -3.4968233108520508e-01
    z[5,6,4]  R1980     4.6732294559478760e-01
    z[5,6,4]  R1981     2.3781870305538177e-01
    z[5,6,4]  R1982     4.1085368394851685e-01
    z[5,6,4]  R1983     2.2295117378234863e-01
    z[5,6,4]  R1984     -8.1563211977481842e-02
    z[5,6,4]  R1985     -2.1220222115516663e-01
    z[5,6,4]  R1986     -3.0573877692222595e-01
    z[5,6,4]  R1987     2.4600279331207275e-01
    z[5,6,4]  R1988     3.3252504467964172e-01
    z[5,6,4]  R1989     2.6147800683975220e-01
    z[5,6,4]  R1990     3.6177039146423340e-02
    z[5,6,4]  R1991     4.2754057049751282e-01
    z[5,6,4]  R1992     9.0904332697391510e-02
    z[5,6,4]  R1993     -4.3818231672048569e-02
    z[5,6,4]  R1994     -3.0275815725326538e-01
    z[5,6,4]  R1995     -3.1758925318717957e-01
    z[5,6,4]  R1996     -4.6553325653076172e-01
    z[5,6,4]  R1997     1.9628149271011353e-01
    z[5,6,4]  R1998     0.199002206325531
    z[5,6,4]  R1999     4.7966085374355316e-02
    z[5,6,4]  R2000     1.9761617481708527e-01
    z[5,6,4]  R2001     -2.1794937551021576e-01
    z[5,6,4]  R2002     1.8959569931030273e-01
    z[5,6,4]  R2003     -5.0455468893051147e-01
    z[5,6,4]  R2004     1.9080387055873871e-01
    z[5,6,4]  R2005     1.0679747909307480e-01
    z[5,6,4]  R2006     -1.2663212604820728e-02
    z[5,6,4]  R2007     5.3126418590545654e-01
    z[5,6,4]  R2008     1.6516359522938728e-02
    z[5,6,4]  R2009     -2.2923249751329422e-02
    z[5,6,4]  R2010     -4.8711904883384705e-01
    z[5,6,4]  R2011     -5.8242209255695343e-02
    z[5,6,4]  R2012     9.7990795969963074e-02
    z[5,6,4]  R2013     2.6208689436316490e-02
    z[5,6,4]  R2014     1.7035382986068726e-01
    z[5,6,4]  R2015     2.7062413096427917e-01
    z[5,6,4]  R2016     1.5906998515129089e-01
    z[5,6,4]  R2017     3.0593115091323853e-01
    z[5,6,4]  R2018     6.5106144174933434e-03
    z[5,6,4]  R2019     -4.5229992270469666e-01
    z[5,6,4]  R2020     -3.1586790084838867e-01
    z[5,6,4]  R2021     0.0892091765999794
    z[5,6,4]  R2022     -2.5338403880596161e-02
    z[5,6,4]  R2023     -8.6166240274906158e-02
    z[5,6,4]  R2024     -4.0733799338340759e-01
    z[5,6,4]  R2025     -1.0798192024230957e-01
    z[5,6,4]  R2026     -3.9711430668830872e-01
    z[5,6,4]  R2027     2.8151612728834152e-02
    z[5,6,4]  R2028     9.6242956817150116e-02
    z[5,6,4]  R2029     0.629560112953186
    z[5,6,4]  R2030     2.3625931143760681e-01
    z[5,6,4]  R2031     -9.6024684607982635e-02
    z[5,6,4]  R2032     5.7412409782409668e-01
    z[5,6,4]  R2033     3.5405838489532471e-01
    z[5,6,4]  R2034     7.6192080974578857e-02
    z[5,6,4]  R2035     -3.4034612774848938e-01
    z[5,6,4]  R2036     1.1436818540096283e-01
    z[5,6,4]  R2037     3.0561983585357666e-01
    z[5,6,4]  R2038     -2.8432181477546692e-01
    z[5,6,4]  R2039     2.3806239664554596e-01
    z[5,6,4]  R2040     -2.4416035413742065e-01
    z[5,6,4]  R2041     5.5884812027215958e-02
    z[5,6,4]  R2042     4.0759924799203873e-02
    z[5,6,4]  R2043     -0.142137348651886
    z[5,6,4]  R2044     -1.2161013484001160e-01
    z[5,6,4]  R2045     2.0110353827476501e-01
    z[5,6,4]  R2046     4.0101557970046997e-01
    z[5,6,4]  R2047     -2.5878927111625671e-01
    z[5,6,4]  R2048     3.3145558834075928e-01
    z[5,6,4]  R2049     -1.4004895463585854e-02
    z[5,6,4]  R2050     8.0085322260856628e-02
    z[5,6,4]  R2051     -1.9381056725978851e-01
    z[5,6,4]  R2052     2.7783846855163574e-01
    z[5,6,4]  R2053     -4.5912593603134155e-02
    z[5,6,4]  R2054     -4.2880815267562866e-01
    z[5,6,4]  R2055     -2.3255331814289093e-01
    z[5,6,4]  R2056     7.3434972763061523e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R1973     -1
    z[5,6,5]  R1974     1
    z[5,6,5]  R1977     -6.2554180622100830e-02
    z[5,6,5]  R1978     1.7089422047138214e-01
    z[5,6,5]  R1979     1.0925537347793579e-01
    z[5,6,5]  R1980     -3.3133661746978760e-01
    z[5,6,5]  R1981     -4.5836070179939270e-01
    z[5,6,5]  R1982     -5.0118938088417053e-02
    z[5,6,5]  R1983     2.3242565989494324e-01
    z[5,6,5]  R1984     2.5213134288787842e-01
    z[5,6,5]  R1985     1.7320416867733002e-01
    z[5,6,5]  R1986     2.6389557123184204e-01
    z[5,6,5]  R1987     -0.0977431982755661
    z[5,6,5]  R1988     4.1198879480361938e-02
    z[5,6,5]  R1989     5.3055030107498169e-01
    z[5,6,5]  R1990     2.8453812003135681e-01
    z[5,6,5]  R1991     1.0688146948814392e-01
    z[5,6,5]  R1992     -2.1798940002918243e-01
    z[5,6,5]  R1993     -1.1671172827482224e-01
    z[5,6,5]  R1994     -5.1127374172210693e-01
    z[5,6,5]  R1995     -4.3282347917556763e-01
    z[5,6,5]  R1996     -2.1012568473815918e-01
    z[5,6,5]  R1997     3.9927309751510620e-01
    z[5,6,5]  R1998     -7.2717852890491486e-02
    z[5,6,5]  R1999     1.4325736463069916e-01
    z[5,6,5]  R2000     -1.1089536361396313e-02
    z[5,6,5]  R2001     -3.1884121894836426e-01
    z[5,6,5]  R2002     -1.4226890169084072e-02
    z[5,6,5]  R2003     1.7738994956016541e-01
    z[5,6,5]  R2004     -1.8889398872852325e-01
    z[5,6,5]  R2005     -3.1160369515419006e-01
    z[5,6,5]  R2006     -1.8784089386463165e-01
    z[5,6,5]  R2007     3.8963431119918823e-01
    z[5,6,5]  R2008     3.4880438446998596e-01
    z[5,6,5]  R2009     2.2839890420436859e-01
    z[5,6,5]  R2010     -7.1575157344341278e-02
    z[5,6,5]  R2011     -9.3093067407608032e-02
    z[5,6,5]  R2012     3.8701677322387695e-01
    z[5,6,5]  R2013     1.8997497856616974e-01
    z[5,6,5]  R2014     3.9809203147888184e-01
    z[5,6,5]  R2015     5.3611434996128082e-02
    z[5,6,5]  R2016     -2.5995871052145958e-02
    z[5,6,5]  R2017     -1.1195619404315948e-01
    z[5,6,5]  R2018     1.8842902779579163e-01
    z[5,6,5]  R2019     2.4268217384815216e-01
    z[5,6,5]  R2020     -2.8632253408432007e-01
    z[5,6,5]  R2021     -7.0227861404418945e-02
    z[5,6,5]  R2022     -3.1152474880218506e-01
    z[5,6,5]  R2023     1.0080326348543167e-01
    z[5,6,5]  R2024     -1.7867214977741241e-01
    z[5,6,5]  R2025     2.6090887188911438e-01
    z[5,6,5]  R2026     3.1812575459480286e-01
    z[5,6,5]  R2027     3.4749977290630341e-02
    z[5,6,5]  R2028     2.6824250817298889e-01
    z[5,6,5]  R2029     -1.3079972565174103e-01
    z[5,6,5]  R2030     1.5704709291458130e-01
    z[5,6,5]  R2031     -7.0687431097030640e-01
    z[5,6,5]  R2032     -2.5559765100479126e-01
    z[5,6,5]  R2033     2.6255035400390625e-01
    z[5,6,5]  R2034     -1.4988008141517639e-01
    z[5,6,5]  R2035     0.286690354347229
    z[5,6,5]  R2036     2.8930592536926270e-01
    z[5,6,5]  R2037     3.4431774169206619e-02
    z[5,6,5]  R2038     -1.0478625446557999e-01
    z[5,6,5]  R2039     -2.1493105590343475e-01
    z[5,6,5]  R2040     -3.1095145270228386e-02
    z[5,6,5]  R2041     -1.9912435114383698e-01
    z[5,6,5]  R2042     0.402570903301239
    z[5,6,5]  R2043     3.1461000442504883e-01
    z[5,6,5]  R2044     -2.0663768053054810e-01
    z[5,6,5]  R2045     1.7251954972743988e-01
    z[5,6,5]  R2046     -4.0156453847885132e-01
    z[5,6,5]  R2047     1.4101035892963409e-01
    z[5,6,5]  R2048     2.3707848787307739e-01
    z[5,6,5]  R2049     -2.9156050086021423e-01
    z[5,6,5]  R2050     -3.1166058778762817e-01
    z[5,6,5]  R2051     5.4415595531463623e-01
    z[5,6,5]  R2052     -2.9116401076316833e-01
    z[5,6,5]  R2053     -6.4724549651145935e-02
    z[5,6,5]  R2054     2.5215440988540649e-01
    z[5,6,5]  R2055     -3.9865810424089432e-02
    z[5,6,5]  R2056     0.284146785736084
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R1975     -1
    z[5,6,6]  R1976     1
    z[5,6,6]  R1977     -1.9355228543281555e-01
    z[5,6,6]  R1978     1.3423733413219452e-01
    z[5,6,6]  R1979     0.30905881524086
    z[5,6,6]  R1980     1.7634055018424988e-01
    z[5,6,6]  R1981     -2.1055087447166443e-01
    z[5,6,6]  R1982     -3.4079153090715408e-02
    z[5,6,6]  R1983     -2.0666822791099548e-01
    z[5,6,6]  R1984     1.6213466227054596e-01
    z[5,6,6]  R1985     -4.1867125034332275e-01
    z[5,6,6]  R1986     -5.0013452768325806e-01
    z[5,6,6]  R1987     -2.2686445713043213e-01
    z[5,6,6]  R1988     -5.4530304670333862e-01
    z[5,6,6]  R1989     -1.1884658038616180e-01
    z[5,6,6]  R1990     -3.5577270388603210e-01
    z[5,6,6]  R1991     3.8494133949279785e-01
    z[5,6,6]  R1992     4.9901410937309265e-01
    z[5,6,6]  R1993     3.3552783727645874e-01
    z[5,6,6]  R1994     -7.8751757740974426e-02
    z[5,6,6]  R1995     -1.5964034199714661e-01
    z[5,6,6]  R1996     3.8278706371784210e-02
    z[5,6,6]  R1997     -4.5227617025375366e-01
    z[5,6,6]  R1998     -8.8160365819931030e-02
    z[5,6,6]  R1999     3.7805411219596863e-01
    z[5,6,6]  R2000     6.4236021041870117e-01
    z[5,6,6]  R2001     6.8818684667348862e-03
    z[5,6,6]  R2002     -4.1248893737792969e-01
    z[5,6,6]  R2003     -6.3212528824806213e-02
    z[5,6,6]  R2004     -2.9576432704925537e-01
    z[5,6,6]  R2005     0.314543753862381
    z[5,6,6]  R2006     -1.1832013726234436e-01
    z[5,6,6]  R2007     2.9909417033195496e-02
    z[5,6,6]  R2008     -4.3837600946426392e-01
    z[5,6,6]  R2009     5.3634178638458252e-01
    z[5,6,6]  R2010     8.4394156932830811e-02
    z[5,6,6]  R2011     -1.1843344569206238e-01
    z[5,6,6]  R2012     -2.2284707054495811e-02
    z[5,6,6]  R2013     -1.1479567736387253e-01
    z[5,6,6]  R2014     -2.3684035986661911e-02
    z[5,6,6]  R2015     6.5544582903385162e-02
    z[5,6,6]  R2016     -1.7695156857371330e-03
    z[5,6,6]  R2017     -2.1279849112033844e-01
    z[5,6,6]  R2018     4.5877873897552490e-02
    z[5,6,6]  R2019     -2.1587008610367775e-02
    z[5,6,6]  R2020     -1.8798071146011353e-01
    z[5,6,6]  R2021     5.2520852535963058e-02
    z[5,6,6]  R2022     -3.2697860151529312e-02
    z[5,6,6]  R2023     3.2514709234237671e-01
    z[5,6,6]  R2024     3.3500474691390991e-01
    z[5,6,6]  R2025     -7.1647331118583679e-02
    z[5,6,6]  R2026     3.5818368196487427e-01
    z[5,6,6]  R2027     -1.2113984674215317e-01
    z[5,6,6]  R2028     0.0630001500248909
    z[5,6,6]  R2029     -1.8945485353469849e-01
    z[5,6,6]  R2030     -4.0386196970939636e-01
    z[5,6,6]  R2031     -0.0329107791185379
    z[5,6,6]  R2032     5.5236298590898514e-02
    z[5,6,6]  R2033     2.0116844773292542e-01
    z[5,6,6]  R2034     -2.6413249969482422e-01
    z[5,6,6]  R2035     -2.9550895094871521e-01
    z[5,6,6]  R2036     -2.4038228392601013e-01
    z[5,6,6]  R2037     -1.9249269366264343e-01
    z[5,6,6]  R2038     2.4628737568855286e-01
    z[5,6,6]  R2039     -2.1937627345323563e-02
    z[5,6,6]  R2040     -1.7732024192810059e-02
    z[5,6,6]  R2041     2.5335814803838730e-02
    z[5,6,6]  R2042     -1.4237202703952789e-02
    z[5,6,6]  R2043     -2.0964252948760986e-01
    z[5,6,6]  R2044     -1.3886238634586334e-01
    z[5,6,6]  R2045     0.396258682012558
    z[5,6,6]  R2046     -7.3812879621982574e-02
    z[5,6,6]  R2047     -4.7473390586674213e-03
    z[5,6,6]  R2048     1.1666963808238506e-02
    z[5,6,6]  R2049     -4.2950114607810974e-01
    z[5,6,6]  R2050     2.1697996556758881e-01
    z[5,6,6]  R2051     -3.2839265465736389e-01
    z[5,6,6]  R2052     -3.5264673829078674e-01
    z[5,6,6]  R2053     -4.8314219713211060e-01
    z[5,6,6]  R2054     -4.2768004536628723e-01
    z[5,6,6]  R2055     8.9470840990543365e-02
    z[5,6,6]  R2056     -2.0651248097419739e-01
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2057     -1
    z[6,5,0]  R2058     1
    z[6,5,0]  R2071     -8.1584942340850830e-01
    z[6,5,0]  R2072     -8.3547770977020264e-01
    z[6,5,0]  R2073     -7.3414427042007446e-01
    z[6,5,0]  R2074     -7.2544336318969727e-01
    z[6,5,0]  R2075     -4.9633827805519104e-01
    z[6,5,0]  R2076     -6.7537021636962891e-01
    z[6,5,0]  R2077     -7.6199799776077271e-01
    z[6,5,0]  R2078     -4.8303210735321045e-01
    z[6,5,0]  R2079     -8.3185464143753052e-01
    z[6,5,0]  R2080     -4.0691459178924561e-01
    z[6,5,0]  R2081     4.9099221825599670e-01
    z[6,5,0]  R2082     9.3766905367374420e-02
    z[6,5,0]  R2083     5.0753045082092285e-01
    z[6,5,0]  R2084     4.2190632224082947e-01
    z[6,5,0]  R2085     4.9894136190414429e-01
    z[6,5,0]  R2086     5.4266828298568726e-01
    z[6,5,0]  R2087     2.8890156745910645e-01
    z[6,5,0]  R2088     3.7113168835639954e-01
    z[6,5,0]  R2089     5.5590659379959106e-01
    z[6,5,0]  R2090     6.8955369293689728e-02
    z[6,5,0]  R2091     8.2336896657943726e-01
    z[6,5,0]  R2092     0.833395779132843
    z[6,5,0]  R2093     7.7884292602539062e-01
    z[6,5,0]  R2094     7.2519683837890625e-01
    z[6,5,0]  R2095     9.1842484474182129e-01
    z[6,5,0]  R2096     0.709715723991394
    z[6,5,0]  R2097     7.4419897794723511e-01
    z[6,5,0]  R2098     8.4135973453521729e-01
    z[6,5,0]  R2099     0.773284912109375
    z[6,5,0]  R2100     7.9004669189453125e-01
    z[6,5,0]  R2101     8.4471255540847778e-01
    z[6,5,0]  R2102     7.1160227060317993e-01
    z[6,5,0]  R2103     7.2750610113143921e-01
    z[6,5,0]  R2104     -6.0652363300323486e-01
    z[6,5,0]  R2105     3.0945724248886108e-01
    z[6,5,0]  R2106     -6.7812144756317139e-02
    z[6,5,0]  R2107     -1.1857558786869049e-01
    z[6,5,0]  R2108     -4.5286703854799271e-02
    z[6,5,0]  R2109     -3.7151089310646057e-01
    z[6,5,0]  R2110     -8.5053868591785431e-02
    z[6,5,0]  R2111     -9.8129129037261009e-03
    z[6,5,0]  R2112     1.9520588219165802e-01
    z[6,5,0]  R2113     -1.5761759877204895e-01
    z[6,5,0]  R2114     2.8266796469688416e-01
    z[6,5,0]  R2115     -0.0914662703871727
    z[6,5,0]  R2116     3.5185284912586212e-02
    z[6,5,0]  R2117     -4.4540934264659882e-02
    z[6,5,0]  R2118     -1.4993159100413322e-02
    z[6,5,0]  R2119     -1.7481365799903870e-01
    z[6,5,0]  R2120     -1.2111248821020126e-01
    z[6,5,0]  R2121     2.3999631404876709e-01
    z[6,5,0]  R2122     3.7114644050598145e-01
    z[6,5,0]  R2123     3.3333885669708252e-01
    z[6,5,0]  R2124     1.5405425429344177e-01
    z[6,5,0]  R2125     0.344827800989151
    z[6,5,0]  R2126     1.6298142075538635e-01
    z[6,5,0]  R2127     -6.8737521767616272e-02
    z[6,5,0]  R2128     1.7824020236730576e-02
    z[6,5,0]  R2129     -1.6613408923149109e-01
    z[6,5,0]  R2130     -0.219927579164505
    z[6,5,0]  R2131     0.153601735830307
    z[6,5,0]  R2132     2.2325752675533295e-01
    z[6,5,0]  R2133     7.2254180908203125e-02
    z[6,5,0]  R2134     3.1756952404975891e-01
    z[6,5,0]  R2135     8.4015719592571259e-02
    z[6,5,0]  R2136     5.8751013129949570e-02
    z[6,5,0]  R2137     -4.2334833741188049e-01
    z[6,5,0]  R2138     2.5880929827690125e-01
    z[6,5,0]  R2139     -1.4871890842914581e-01
    z[6,5,0]  R2140     -0.283314973115921
    z[6,5,0]  R2141     4.5690831542015076e-01
    z[6,5,0]  R2142     1.1496644467115402e-01
    z[6,5,0]  R2143     2.3103404045104980e-01
    z[6,5,0]  R2144     -2.2177945077419281e-01
    z[6,5,0]  R2145     3.5804096609354019e-02
    z[6,5,0]  R2146     -6.4874303340911865e-01
    z[6,5,0]  R2147     -7.3766535520553589e-01
    z[6,5,0]  R2148     -3.5329201817512512e-01
    z[6,5,0]  R2149     -9.5257240533828735e-01
    z[6,5,0]  R2150     -9.4518017768859863e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2059     -1
    z[6,5,1]  R2060     1
    z[6,5,1]  R2071     -1.8467040359973907e-01
    z[6,5,1]  R2072     -1.3740491867065430e-01
    z[6,5,1]  R2073     -0.263480544090271
    z[6,5,1]  R2074     -1.7347732186317444e-01
    z[6,5,1]  R2075     -0.11562529951334
    z[6,5,1]  R2076     1.0543778538703918e-01
    z[6,5,1]  R2077     1.0626516491174698e-01
    z[6,5,1]  R2078     2.3209260404109955e-01
    z[6,5,1]  R2079     -1.7743978649377823e-02
    z[6,5,1]  R2080     -7.4440743774175644e-03
    z[6,5,1]  R2081     -6.4555935561656952e-02
    z[6,5,1]  R2082     0.802198052406311
    z[6,5,1]  R2083     -2.0031096041202545e-01
    z[6,5,1]  R2084     -4.7008499503135681e-01
    z[6,5,1]  R2085     1.9505453109741211e-01
    z[6,5,1]  R2086     2.5065168738365173e-01
    z[6,5,1]  R2087     3.4602823853492737e-01
    z[6,5,1]  R2088     1.4450013637542725e-01
    z[6,5,1]  R2089     -3.8335135579109192e-01
    z[6,5,1]  R2090     9.0766036510467529e-01
    z[6,5,1]  R2091     -1.2319023162126541e-01
    z[6,5,1]  R2092     1.5052442252635956e-01
    z[6,5,1]  R2093     -5.3521089255809784e-02
    z[6,5,1]  R2094     -3.0439051985740662e-01
    z[6,5,1]  R2095     7.6228104531764984e-02
    z[6,5,1]  R2096     -4.0170428156852722e-01
    z[6,5,1]  R2097     -0.518860399723053
    z[6,5,1]  R2098     0.0714452788233757
    z[6,5,1]  R2099     1.4823582768440247e-01
    z[6,5,1]  R2100     1.9825264811515808e-01
    z[6,5,1]  R2101     -1.4329980313777924e-01
    z[6,5,1]  R2102     -2.7208226919174194e-01
    z[6,5,1]  R2103     -3.5209563374519348e-01
    z[6,5,1]  R2104     5.8529919385910034e-01
    z[6,5,1]  R2105     4.4666466116905212e-01
    z[6,5,1]  R2106     7.4827569723129272e-01
    z[6,5,1]  R2107     4.2190197110176086e-01
    z[6,5,1]  R2108     4.2537638545036316e-01
    z[6,5,1]  R2109     1.8803621828556061e-01
    z[6,5,1]  R2110     2.5354531407356262e-01
    z[6,5,1]  R2111     -3.6789214611053467e-01
    z[6,5,1]  R2112     -5.0035309791564941e-01
    z[6,5,1]  R2113     -3.2951968908309937e-01
    z[6,5,1]  R2114     -1.0314059257507324e-01
    z[6,5,1]  R2115     -2.8634673357009888e-01
    z[6,5,1]  R2116     -1.9924721121788025e-01
    z[6,5,1]  R2117     8.7003123760223389e-01
    z[6,5,1]  R2118     8.0698674917221069e-01
    z[6,5,1]  R2119     6.1325830221176147e-01
    z[6,5,1]  R2120     5.8618915081024170e-01
    z[6,5,1]  R2121     -6.2944030761718750e-01
    z[6,5,1]  R2122     -5.4059320688247681e-01
    z[6,5,1]  R2123     -5.4516172409057617e-01
    z[6,5,1]  R2124     -6.5914779901504517e-01
    z[6,5,1]  R2125     -4.8302519321441650e-01
    z[6,5,1]  R2126     -5.9477454423904419e-01
    z[6,5,1]  R2127     -5.0718593597412109e-01
    z[6,5,1]  R2128     -5.7386404275894165e-01
    z[6,5,1]  R2129     1.0970901697874069e-01
    z[6,5,1]  R2130     -5.7534945011138916e-01
    z[6,5,1]  R2131     -5.3369557857513428e-01
    z[6,5,1]  R2132     -8.9994937181472778e-01
    z[6,5,1]  R2133     -7.2926950454711914e-01
    z[6,5,1]  R2134     -6.6056615114212036e-01
    z[6,5,1]  R2135     1.3864208944141865e-02
    z[6,5,1]  R2136     5.8342820405960083e-01
    z[6,5,1]  R2137     6.5766614675521851e-01
    z[6,5,1]  R2138     2.0050309598445892e-01
    z[6,5,1]  R2139     5.5003219842910767e-01
    z[6,5,1]  R2140     4.6862110495567322e-01
    z[6,5,1]  R2141     -0.463623583316803
    z[6,5,1]  R2142     -5.8346712589263916e-01
    z[6,5,1]  R2143     -7.5760698318481445e-01
    z[6,5,1]  R2144     4.2335048317909241e-01
    z[6,5,1]  R2145     4.4613838195800781e-01
    z[6,5,1]  R2146     1.3833696953952312e-02
    z[6,5,1]  R2147     -3.3223412930965424e-02
    z[6,5,1]  R2148     2.0151835680007935e-01
    z[6,5,1]  R2149     -4.3788510374724865e-03
    z[6,5,1]  R2150     -1.3158197514712811e-02
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2061     -1
    z[6,5,2]  R2062     1
    z[6,5,2]  R2071     2.8686735033988953e-01
    z[6,5,2]  R2072     4.7996678948402405e-01
    z[6,5,2]  R2073     3.2032766938209534e-01
    z[6,5,2]  R2074     0.468130499124527
    z[6,5,2]  R2075     8.5109126567840576e-01
    z[6,5,2]  R2076     5.6741166114807129e-01
    z[6,5,2]  R2077     5.0181424617767334e-01
    z[6,5,2]  R2078     6.3314098119735718e-01
    z[6,5,2]  R2079     -4.0242251753807068e-01
    z[6,5,2]  R2080     6.1131817102432251e-01
    z[6,5,2]  R2081     2.3638445138931274e-01
    z[6,5,2]  R2082     -2.1357320249080658e-02
    z[6,5,2]  R2083     1.7076766490936279e-01
    z[6,5,2]  R2084     3.5945731401443481e-01
    z[6,5,2]  R2085     3.8796633481979370e-01
    z[6,5,2]  R2086     3.3352798223495483e-01
    z[6,5,2]  R2087     -7.1650457382202148e-01
    z[6,5,2]  R2088     -7.4348253011703491e-01
    z[6,5,2]  R2089     -4.6164166927337646e-01
    z[6,5,2]  R2090     9.9883466958999634e-02
    z[6,5,2]  R2091     -2.6978502050042152e-02
    z[6,5,2]  R2092     3.1799456477165222e-01
    z[6,5,2]  R2093     5.3231620788574219e-01
    z[6,5,2]  R2094     4.8598667979240417e-01
    z[6,5,2]  R2095     2.3269085586071014e-01
    z[6,5,2]  R2096     3.8618156313896179e-01
    z[6,5,2]  R2097     1.1577173322439194e-01
    z[6,5,2]  R2098     -2.1999187767505646e-01
    z[6,5,2]  R2099     3.9089924097061157e-01
    z[6,5,2]  R2100     3.9018783718347549e-02
    z[6,5,2]  R2101     -3.4256213903427124e-01
    z[6,5,2]  R2102     8.4643848240375519e-02
    z[6,5,2]  R2103     -0.0328790545463562
    z[6,5,2]  R2104     -3.7224420905113220e-01
    z[6,5,2]  R2105     0.0223090797662735
    z[6,5,2]  R2106     7.9673487925902009e-04
    z[6,5,2]  R2107     -1.5540605783462524e-01
    z[6,5,2]  R2108     2.8781020641326904e-01
    z[6,5,2]  R2109     -6.6818159818649292e-01
    z[6,5,2]  R2110     3.0707883834838867e-01
    z[6,5,2]  R2111     -6.9622492790222168e-01
    z[6,5,2]  R2112     -7.2611391544342041e-01
    z[6,5,2]  R2113     -2.7461823821067810e-01
    z[6,5,2]  R2114     -6.0160207748413086e-01
    z[6,5,2]  R2115     4.5172579586505890e-02
    z[6,5,2]  R2116     1.1268923431634903e-01
    z[6,5,2]  R2117     2.4226620793342590e-01
    z[6,5,2]  R2118     -3.1493294239044189e-01
    z[6,5,2]  R2119     3.6262005567550659e-01
    z[6,5,2]  R2120     -2.9705882072448730e-01
    z[6,5,2]  R2121     4.5650824904441833e-01
    z[6,5,2]  R2122     0.0513649582862854
    z[6,5,2]  R2123     4.0688481926918030e-01
    z[6,5,2]  R2124     5.0679886341094971e-01
    z[6,5,2]  R2125     4.5397931337356567e-01
    z[6,5,2]  R2126     3.9233011007308960e-01
    z[6,5,2]  R2127     7.6157444715499878e-01
    z[6,5,2]  R2128     -1.0714815557003021e-01
    z[6,5,2]  R2129     1.4869058132171631e-01
    z[6,5,2]  R2130     5.1525270938873291e-01
    z[6,5,2]  R2131     1.2777386605739594e-01
    z[6,5,2]  R2132     2.8799328207969666e-01
    z[6,5,2]  R2133     4.3757927417755127e-01
    z[6,5,2]  R2134     3.7901647388935089e-02
    z[6,5,2]  R2135     -3.0423361063003540e-01
    z[6,5,2]  R2136     0.0686836838722229
    z[6,5,2]  R2137     2.3707339167594910e-01
    z[6,5,2]  R2138     -3.2546824216842651e-01
    z[6,5,2]  R2139     4.7030287981033325e-01
    z[6,5,2]  R2140     7.1690547466278076e-01
    z[6,5,2]  R2141     -1.5700435638427734e-01
    z[6,5,2]  R2142     -1.1567012220621109e-01
    z[6,5,2]  R2143     1.6201768815517426e-01
    z[6,5,2]  R2144     -0.000394883711123839
    z[6,5,2]  R2145     -4.6268694102764130e-02
    z[6,5,2]  R2146     0.632844865322113
    z[6,5,2]  R2147     6.0275137424468994e-01
    z[6,5,2]  R2148     8.0314534902572632e-01
    z[6,5,2]  R2149     -8.1650130450725555e-02
    z[6,5,2]  R2150     -2.1970146894454956e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2063     -1
    z[6,5,3]  R2064     1
    z[6,5,3]  R2071     -0.258035808801651
    z[6,5,3]  R2072     1.2278497964143753e-01
    z[6,5,3]  R2073     1.5831816196441650e-01
    z[6,5,3]  R2074     -8.6031429469585419e-02
    z[6,5,3]  R2075     1.6550848260521889e-02
    z[6,5,3]  R2076     3.3472830057144165e-01
    z[6,5,3]  R2077     -1.8150122463703156e-01
    z[6,5,3]  R2078     4.3236851692199707e-02
    z[6,5,3]  R2079     2.4676360189914703e-01
    z[6,5,3]  R2080     2.7102762460708618e-01
    z[6,5,3]  R2081     8.2595801353454590e-01
    z[6,5,3]  R2082     5.1190227270126343e-01
    z[6,5,3]  R2083     -4.7305294871330261e-01
    z[6,5,3]  R2084     -4.7772252559661865e-01
    z[6,5,3]  R2085     -2.2916845977306366e-01
    z[6,5,3]  R2086     3.6530005931854248e-01
    z[6,5,3]  R2087     2.2059649229049683e-01
    z[6,5,3]  R2088     0.436553955078125
    z[6,5,3]  R2089     2.1341089904308319e-01
    z[6,5,3]  R2090     8.2821629941463470e-02
    z[6,5,3]  R2091     4.1775268316268921e-01
    z[6,5,3]  R2092     1.7087125778198242e-01
    z[6,5,3]  R2093     6.1872269958257675e-02
    z[6,5,3]  R2094     -2.9044350981712341e-01
    z[6,5,3]  R2095     2.3048759996891022e-01
    z[6,5,3]  R2096     1.4789731800556183e-01
    z[6,5,3]  R2097     2.0402505993843079e-02
    z[6,5,3]  R2098     4.0229588747024536e-01
    z[6,5,3]  R2099     5.2630184218287468e-03
    z[6,5,3]  R2100     8.6509138345718384e-02
    z[6,5,3]  R2101     -2.4839197099208832e-01
    z[6,5,3]  R2102     -4.9620926380157471e-01
    z[6,5,3]  R2103     -2.7569499611854553e-01
    z[6,5,3]  R2104     -1.9026175141334534e-02
    z[6,5,3]  R2105     5.1256150007247925e-01
    z[6,5,3]  R2106     3.8620454072952271e-01
    z[6,5,3]  R2107     7.3760688304901123e-01
    z[6,5,3]  R2108     5.5118137598037720e-01
    z[6,5,3]  R2109     -5.6256562471389771e-01
    z[6,5,3]  R2110     4.1415810585021973e-01
    z[6,5,3]  R2111     -5.0675177574157715e-01
    z[6,5,3]  R2112     -3.2096511125564575e-01
    z[6,5,3]  R2113     -7.4928396940231323e-01
    z[6,5,3]  R2114     -4.3389534950256348e-01
    z[6,5,3]  R2115     -7.7240854501724243e-01
    z[6,5,3]  R2116     -8.7970989942550659e-01
    z[6,5,3]  R2117     1.8954710662364960e-01
    z[6,5,3]  R2118     3.9096572995185852e-01
    z[6,5,3]  R2119     4.5994141697883606e-01
    z[6,5,3]  R2120     3.7445747852325439e-01
    z[6,5,3]  R2121     4.6504649519920349e-01
    z[6,5,3]  R2122     3.9717164635658264e-01
    z[6,5,3]  R2123     2.4929851293563843e-01
    z[6,5,3]  R2124     2.7586460113525391e-01
    z[6,5,3]  R2125     3.1510126590728760e-01
    z[6,5,3]  R2126     4.0119731426239014e-01
    z[6,5,3]  R2127     1.7297795414924622e-01
    z[6,5,3]  R2128     5.4737234115600586e-01
    z[6,5,3]  R2129     7.9029762744903564e-01
    z[6,5,3]  R2130     3.0459839105606079e-01
    z[6,5,3]  R2131     -5.2225482463836670e-01
    z[6,5,3]  R2132     -6.8153828382492065e-02
    z[6,5,3]  R2133     -0.325148344039917
    z[6,5,3]  R2134     9.7793549299240112e-02
    z[6,5,3]  R2135     8.6659216880798340e-01
    z[6,5,3]  R2136     6.6719287633895874e-01
    z[6,5,3]  R2137     2.0496146380901337e-01
    z[6,5,3]  R2138     7.9203724861145020e-01
    z[6,5,3]  R2139     4.9671131372451782e-01
    z[6,5,3]  R2140     3.6976906657218933e-01
    z[6,5,3]  R2141     -3.4159377217292786e-01
    z[6,5,3]  R2142     -5.6467545032501221e-01
    z[6,5,3]  R2143     7.7789083123207092e-02
    z[6,5,3]  R2144     7.2253561019897461e-01
    z[6,5,3]  R2145     8.7832385301589966e-01
    z[6,5,3]  R2146     1.3626362383365631e-01
    z[6,5,3]  R2147     2.0366945862770081e-01
    z[6,5,3]  R2148     3.8393866270780563e-02
    z[6,5,3]  R2149     7.4244342744350433e-02
    z[6,5,3]  R2150     1.7947238683700562e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2065     -1
    z[6,5,4]  R2066     1
    z[6,5,4]  R2071     3.0593115091323853e-01
    z[6,5,4]  R2072     6.5106144174933434e-03
    z[6,5,4]  R2073     -4.5229992270469666e-01
    z[6,5,4]  R2074     -3.1586790084838867e-01
    z[6,5,4]  R2075     0.0892091765999794
    z[6,5,4]  R2076     -2.5338403880596161e-02
    z[6,5,4]  R2077     -8.6166240274906158e-02
    z[6,5,4]  R2078     -4.0733799338340759e-01
    z[6,5,4]  R2079     -1.0798192024230957e-01
    z[6,5,4]  R2080     -3.9711430668830872e-01
    z[6,5,4]  R2081     2.8151612728834152e-02
    z[6,5,4]  R2082     9.6242956817150116e-02
    z[6,5,4]  R2083     0.629560112953186
    z[6,5,4]  R2084     2.3625931143760681e-01
    z[6,5,4]  R2085     -9.6024684607982635e-02
    z[6,5,4]  R2086     5.7412409782409668e-01
    z[6,5,4]  R2087     3.5405838489532471e-01
    z[6,5,4]  R2088     7.6192080974578857e-02
    z[6,5,4]  R2089     -3.4034612774848938e-01
    z[6,5,4]  R2090     1.1436818540096283e-01
    z[6,5,4]  R2091     3.0561983585357666e-01
    z[6,5,4]  R2092     -2.8432181477546692e-01
    z[6,5,4]  R2093     2.3806239664554596e-01
    z[6,5,4]  R2094     -2.4416035413742065e-01
    z[6,5,4]  R2095     5.5884812027215958e-02
    z[6,5,4]  R2096     4.0759924799203873e-02
    z[6,5,4]  R2097     -0.142137348651886
    z[6,5,4]  R2098     -1.2161013484001160e-01
    z[6,5,4]  R2099     2.0110353827476501e-01
    z[6,5,4]  R2100     4.0101557970046997e-01
    z[6,5,4]  R2101     -2.5878927111625671e-01
    z[6,5,4]  R2102     3.3145558834075928e-01
    z[6,5,4]  R2103     -1.4004895463585854e-02
    z[6,5,4]  R2104     8.0085322260856628e-02
    z[6,5,4]  R2105     -1.9381056725978851e-01
    z[6,5,4]  R2106     2.7783846855163574e-01
    z[6,5,4]  R2107     -4.5912593603134155e-02
    z[6,5,4]  R2108     -4.2880815267562866e-01
    z[6,5,4]  R2109     -2.3255331814289093e-01
    z[6,5,4]  R2110     7.3434972763061523e-01
    z[6,5,4]  R2111     -2.8575715422630310e-01
    z[6,5,4]  R2112     -1.8454520404338837e-01
    z[6,5,4]  R2113     -3.4968233108520508e-01
    z[6,5,4]  R2114     4.6732294559478760e-01
    z[6,5,4]  R2115     2.3781870305538177e-01
    z[6,5,4]  R2116     4.1085368394851685e-01
    z[6,5,4]  R2117     2.2295117378234863e-01
    z[6,5,4]  R2118     -8.1563211977481842e-02
    z[6,5,4]  R2119     -2.1220222115516663e-01
    z[6,5,4]  R2120     -3.0573877692222595e-01
    z[6,5,4]  R2121     2.4600279331207275e-01
    z[6,5,4]  R2122     3.3252504467964172e-01
    z[6,5,4]  R2123     2.6147800683975220e-01
    z[6,5,4]  R2124     3.6177039146423340e-02
    z[6,5,4]  R2125     4.2754057049751282e-01
    z[6,5,4]  R2126     9.0904332697391510e-02
    z[6,5,4]  R2127     -4.3818231672048569e-02
    z[6,5,4]  R2128     -3.0275815725326538e-01
    z[6,5,4]  R2129     -3.1758925318717957e-01
    z[6,5,4]  R2130     -4.6553325653076172e-01
    z[6,5,4]  R2131     1.9628149271011353e-01
    z[6,5,4]  R2132     0.199002206325531
    z[6,5,4]  R2133     4.7966085374355316e-02
    z[6,5,4]  R2134     1.9761617481708527e-01
    z[6,5,4]  R2135     -2.1794937551021576e-01
    z[6,5,4]  R2136     1.8959569931030273e-01
    z[6,5,4]  R2137     -5.0455468893051147e-01
    z[6,5,4]  R2138     1.9080387055873871e-01
    z[6,5,4]  R2139     1.0679747909307480e-01
    z[6,5,4]  R2140     -1.2663212604820728e-02
    z[6,5,4]  R2141     5.3126418590545654e-01
    z[6,5,4]  R2142     1.6516359522938728e-02
    z[6,5,4]  R2143     -2.2923249751329422e-02
    z[6,5,4]  R2144     -4.8711904883384705e-01
    z[6,5,4]  R2145     -5.8242209255695343e-02
    z[6,5,4]  R2146     9.7990795969963074e-02
    z[6,5,4]  R2147     2.6208689436316490e-02
    z[6,5,4]  R2148     1.7035382986068726e-01
    z[6,5,4]  R2149     2.7062413096427917e-01
    z[6,5,4]  R2150     1.5906998515129089e-01
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2067     -1
    z[6,5,5]  R2068     1
    z[6,5,5]  R2071     -1.1195619404315948e-01
    z[6,5,5]  R2072     1.8842902779579163e-01
    z[6,5,5]  R2073     2.4268217384815216e-01
    z[6,5,5]  R2074     -2.8632253408432007e-01
    z[6,5,5]  R2075     -7.0227861404418945e-02
    z[6,5,5]  R2076     -3.1152474880218506e-01
    z[6,5,5]  R2077     1.0080326348543167e-01
    z[6,5,5]  R2078     -1.7867214977741241e-01
    z[6,5,5]  R2079     2.6090887188911438e-01
    z[6,5,5]  R2080     3.1812575459480286e-01
    z[6,5,5]  R2081     3.4749977290630341e-02
    z[6,5,5]  R2082     2.6824250817298889e-01
    z[6,5,5]  R2083     -1.3079972565174103e-01
    z[6,5,5]  R2084     1.5704709291458130e-01
    z[6,5,5]  R2085     -7.0687431097030640e-01
    z[6,5,5]  R2086     -2.5559765100479126e-01
    z[6,5,5]  R2087     2.6255035400390625e-01
    z[6,5,5]  R2088     -1.4988008141517639e-01
    z[6,5,5]  R2089     0.286690354347229
    z[6,5,5]  R2090     2.8930592536926270e-01
    z[6,5,5]  R2091     3.4431774169206619e-02
    z[6,5,5]  R2092     -1.0478625446557999e-01
    z[6,5,5]  R2093     -2.1493105590343475e-01
    z[6,5,5]  R2094     -3.1095145270228386e-02
    z[6,5,5]  R2095     -1.9912435114383698e-01
    z[6,5,5]  R2096     0.402570903301239
    z[6,5,5]  R2097     3.1461000442504883e-01
    z[6,5,5]  R2098     -2.0663768053054810e-01
    z[6,5,5]  R2099     1.7251954972743988e-01
    z[6,5,5]  R2100     -4.0156453847885132e-01
    z[6,5,5]  R2101     1.4101035892963409e-01
    z[6,5,5]  R2102     2.3707848787307739e-01
    z[6,5,5]  R2103     -2.9156050086021423e-01
    z[6,5,5]  R2104     -3.1166058778762817e-01
    z[6,5,5]  R2105     5.4415595531463623e-01
    z[6,5,5]  R2106     -2.9116401076316833e-01
    z[6,5,5]  R2107     -6.4724549651145935e-02
    z[6,5,5]  R2108     2.5215440988540649e-01
    z[6,5,5]  R2109     -3.9865810424089432e-02
    z[6,5,5]  R2110     0.284146785736084
    z[6,5,5]  R2111     -6.2554180622100830e-02
    z[6,5,5]  R2112     1.7089422047138214e-01
    z[6,5,5]  R2113     1.0925537347793579e-01
    z[6,5,5]  R2114     -3.3133661746978760e-01
    z[6,5,5]  R2115     -4.5836070179939270e-01
    z[6,5,5]  R2116     -5.0118938088417053e-02
    z[6,5,5]  R2117     2.3242565989494324e-01
    z[6,5,5]  R2118     2.5213134288787842e-01
    z[6,5,5]  R2119     1.7320416867733002e-01
    z[6,5,5]  R2120     2.6389557123184204e-01
    z[6,5,5]  R2121     -0.0977431982755661
    z[6,5,5]  R2122     4.1198879480361938e-02
    z[6,5,5]  R2123     5.3055030107498169e-01
    z[6,5,5]  R2124     2.8453812003135681e-01
    z[6,5,5]  R2125     1.0688146948814392e-01
    z[6,5,5]  R2126     -2.1798940002918243e-01
    z[6,5,5]  R2127     -1.1671172827482224e-01
    z[6,5,5]  R2128     -5.1127374172210693e-01
    z[6,5,5]  R2129     -4.3282347917556763e-01
    z[6,5,5]  R2130     -2.1012568473815918e-01
    z[6,5,5]  R2131     3.9927309751510620e-01
    z[6,5,5]  R2132     -7.2717852890491486e-02
    z[6,5,5]  R2133     1.4325736463069916e-01
    z[6,5,5]  R2134     -1.1089536361396313e-02
    z[6,5,5]  R2135     -3.1884121894836426e-01
    z[6,5,5]  R2136     -1.4226890169084072e-02
    z[6,5,5]  R2137     1.7738994956016541e-01
    z[6,5,5]  R2138     -1.8889398872852325e-01
    z[6,5,5]  R2139     -3.1160369515419006e-01
    z[6,5,5]  R2140     -1.8784089386463165e-01
    z[6,5,5]  R2141     3.8963431119918823e-01
    z[6,5,5]  R2142     3.4880438446998596e-01
    z[6,5,5]  R2143     2.2839890420436859e-01
    z[6,5,5]  R2144     -7.1575157344341278e-02
    z[6,5,5]  R2145     -9.3093067407608032e-02
    z[6,5,5]  R2146     3.8701677322387695e-01
    z[6,5,5]  R2147     1.8997497856616974e-01
    z[6,5,5]  R2148     3.9809203147888184e-01
    z[6,5,5]  R2149     5.3611434996128082e-02
    z[6,5,5]  R2150     -2.5995871052145958e-02
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2069     -1
    z[6,5,6]  R2070     1
    z[6,5,6]  R2071     -2.1279849112033844e-01
    z[6,5,6]  R2072     4.5877873897552490e-02
    z[6,5,6]  R2073     -2.1587008610367775e-02
    z[6,5,6]  R2074     -1.8798071146011353e-01
    z[6,5,6]  R2075     5.2520852535963058e-02
    z[6,5,6]  R2076     -3.2697860151529312e-02
    z[6,5,6]  R2077     3.2514709234237671e-01
    z[6,5,6]  R2078     3.3500474691390991e-01
    z[6,5,6]  R2079     -7.1647331118583679e-02
    z[6,5,6]  R2080     3.5818368196487427e-01
    z[6,5,6]  R2081     -1.2113984674215317e-01
    z[6,5,6]  R2082     0.0630001500248909
    z[6,5,6]  R2083     -1.8945485353469849e-01
    z[6,5,6]  R2084     -4.0386196970939636e-01
    z[6,5,6]  R2085     -0.0329107791185379
    z[6,5,6]  R2086     5.5236298590898514e-02
    z[6,5,6]  R2087     2.0116844773292542e-01
    z[6,5,6]  R2088     -2.6413249969482422e-01
    z[6,5,6]  R2089     -2.9550895094871521e-01
    z[6,5,6]  R2090     -2.4038228392601013e-01
    z[6,5,6]  R2091     -1.9249269366264343e-01
    z[6,5,6]  R2092     2.4628737568855286e-01
    z[6,5,6]  R2093     -2.1937627345323563e-02
    z[6,5,6]  R2094     -1.7732024192810059e-02
    z[6,5,6]  R2095     2.5335814803838730e-02
    z[6,5,6]  R2096     -1.4237202703952789e-02
    z[6,5,6]  R2097     -2.0964252948760986e-01
    z[6,5,6]  R2098     -1.3886238634586334e-01
    z[6,5,6]  R2099     0.396258682012558
    z[6,5,6]  R2100     -7.3812879621982574e-02
    z[6,5,6]  R2101     -4.7473390586674213e-03
    z[6,5,6]  R2102     1.1666963808238506e-02
    z[6,5,6]  R2103     -4.2950114607810974e-01
    z[6,5,6]  R2104     2.1697996556758881e-01
    z[6,5,6]  R2105     -3.2839265465736389e-01
    z[6,5,6]  R2106     -3.5264673829078674e-01
    z[6,5,6]  R2107     -4.8314219713211060e-01
    z[6,5,6]  R2108     -4.2768004536628723e-01
    z[6,5,6]  R2109     8.9470840990543365e-02
    z[6,5,6]  R2110     -2.0651248097419739e-01
    z[6,5,6]  R2111     -1.9355228543281555e-01
    z[6,5,6]  R2112     1.3423733413219452e-01
    z[6,5,6]  R2113     0.30905881524086
    z[6,5,6]  R2114     1.7634055018424988e-01
    z[6,5,6]  R2115     -2.1055087447166443e-01
    z[6,5,6]  R2116     -3.4079153090715408e-02
    z[6,5,6]  R2117     -2.0666822791099548e-01
    z[6,5,6]  R2118     1.6213466227054596e-01
    z[6,5,6]  R2119     -4.1867125034332275e-01
    z[6,5,6]  R2120     -5.0013452768325806e-01
    z[6,5,6]  R2121     -2.2686445713043213e-01
    z[6,5,6]  R2122     -5.4530304670333862e-01
    z[6,5,6]  R2123     -1.1884658038616180e-01
    z[6,5,6]  R2124     -3.5577270388603210e-01
    z[6,5,6]  R2125     3.8494133949279785e-01
    z[6,5,6]  R2126     4.9901410937309265e-01
    z[6,5,6]  R2127     3.3552783727645874e-01
    z[6,5,6]  R2128     -7.8751757740974426e-02
    z[6,5,6]  R2129     -1.5964034199714661e-01
    z[6,5,6]  R2130     3.8278706371784210e-02
    z[6,5,6]  R2131     -4.5227617025375366e-01
    z[6,5,6]  R2132     -8.8160365819931030e-02
    z[6,5,6]  R2133     3.7805411219596863e-01
    z[6,5,6]  R2134     6.4236021041870117e-01
    z[6,5,6]  R2135     6.8818684667348862e-03
    z[6,5,6]  R2136     -4.1248893737792969e-01
    z[6,5,6]  R2137     -6.3212528824806213e-02
    z[6,5,6]  R2138     -2.9576432704925537e-01
    z[6,5,6]  R2139     0.314543753862381
    z[6,5,6]  R2140     -1.1832013726234436e-01
    z[6,5,6]  R2141     2.9909417033195496e-02
    z[6,5,6]  R2142     -4.3837600946426392e-01
    z[6,5,6]  R2143     5.3634178638458252e-01
    z[6,5,6]  R2144     8.4394156932830811e-02
    z[6,5,6]  R2145     -1.1843344569206238e-01
    z[6,5,6]  R2146     -2.2284707054495811e-02
    z[6,5,6]  R2147     -1.1479567736387253e-01
    z[6,5,6]  R2148     -2.3684035986661911e-02
    z[6,5,6]  R2149     6.5544582903385162e-02
    z[6,5,6]  R2150     -1.7695156857371330e-03
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R2205     -1
    z[6,7,0]  R2206     1
    z[6,7,0]  R2219     -8.1584942340850830e-01
    z[6,7,0]  R2220     -8.3547770977020264e-01
    z[6,7,0]  R2221     -7.3414427042007446e-01
    z[6,7,0]  R2222     -7.2544336318969727e-01
    z[6,7,0]  R2223     -4.9633827805519104e-01
    z[6,7,0]  R2224     -6.7537021636962891e-01
    z[6,7,0]  R2225     -7.6199799776077271e-01
    z[6,7,0]  R2226     -4.8303210735321045e-01
    z[6,7,0]  R2227     -8.3185464143753052e-01
    z[6,7,0]  R2228     -4.0691459178924561e-01
    z[6,7,0]  R2229     4.9099221825599670e-01
    z[6,7,0]  R2230     9.3766905367374420e-02
    z[6,7,0]  R2231     5.0753045082092285e-01
    z[6,7,0]  R2232     4.2190632224082947e-01
    z[6,7,0]  R2233     4.9894136190414429e-01
    z[6,7,0]  R2234     5.4266828298568726e-01
    z[6,7,0]  R2235     2.8890156745910645e-01
    z[6,7,0]  R2236     3.7113168835639954e-01
    z[6,7,0]  R2237     5.5590659379959106e-01
    z[6,7,0]  R2238     6.8955369293689728e-02
    z[6,7,0]  R2239     8.2336896657943726e-01
    z[6,7,0]  R2240     0.833395779132843
    z[6,7,0]  R2241     7.7884292602539062e-01
    z[6,7,0]  R2242     7.2519683837890625e-01
    z[6,7,0]  R2243     9.1842484474182129e-01
    z[6,7,0]  R2244     0.709715723991394
    z[6,7,0]  R2245     7.4419897794723511e-01
    z[6,7,0]  R2246     8.4135973453521729e-01
    z[6,7,0]  R2247     0.773284912109375
    z[6,7,0]  R2248     7.9004669189453125e-01
    z[6,7,0]  R2249     8.4471255540847778e-01
    z[6,7,0]  R2250     7.1160227060317993e-01
    z[6,7,0]  R2251     7.2750610113143921e-01
    z[6,7,0]  R2252     -6.0652363300323486e-01
    z[6,7,0]  R2253     3.0945724248886108e-01
    z[6,7,0]  R2254     -6.7812144756317139e-02
    z[6,7,0]  R2255     -1.1857558786869049e-01
    z[6,7,0]  R2256     -4.5286703854799271e-02
    z[6,7,0]  R2257     -3.7151089310646057e-01
    z[6,7,0]  R2258     -8.5053868591785431e-02
    z[6,7,0]  R2259     -3.9254170656204224e-01
    z[6,7,0]  R2260     -2.3913398385047913e-01
    z[6,7,0]  R2261     -4.2164230346679688e-01
    z[6,7,0]  R2262     -4.6761247515678406e-01
    z[6,7,0]  R2263     -6.8008285760879517e-01
    z[6,7,0]  R2264     -6.4544725418090820e-01
    z[6,7,0]  R2265     -9.2244094610214233e-01
    z[6,7,0]  R2266     -4.7562113404273987e-01
    z[6,7,0]  R2267     -5.7857674360275269e-01
    z[6,7,0]  R2268     -0.748253583908081
    z[6,7,0]  R2269     5.2099150419235229e-01
    z[6,7,0]  R2270     5.5208230018615723e-01
    z[6,7,0]  R2271     4.7966101765632629e-01
    z[6,7,0]  R2272     5.6979340314865112e-01
    z[6,7,0]  R2273     0.41551673412323
    z[6,7,0]  R2274     3.0027130246162415e-01
    z[6,7,0]  R2275     5.6916791200637817e-01
    z[6,7,0]  R2276     3.7578943371772766e-01
    z[6,7,0]  R2277     2.2402296960353851e-01
    z[6,7,0]  R2278     3.7969928979873657e-01
    z[6,7,0]  R2279     2.6223802566528320e-01
    z[6,7,0]  R2280     3.6775204539299011e-01
    z[6,7,0]  R2281     -2.1203437820076942e-02
    z[6,7,0]  R2282     -1.3206343166530132e-02
    z[6,7,0]  R2283     2.8164750337600708e-01
    z[6,7,0]  R2284     -8.9676812291145325e-02
    z[6,7,0]  R2285     6.2856757640838623e-01
    z[6,7,0]  R2286     3.4075993299484253e-01
    z[6,7,0]  R2287     -1.3045547902584076e-01
    z[6,7,0]  R2288     -3.4689339995384216e-01
    z[6,7,0]  R2289     3.5286378860473633e-01
    z[6,7,0]  R2290     3.8080233335494995e-01
    z[6,7,0]  R2291     -0.586037814617157
    z[6,7,0]  R2292     -0.0869353786110878
    z[6,7,0]  R2293     -7.7154916524887085e-01
    z[6,7,0]  R2294     5.7940429449081421e-01
    z[6,7,0]  R2295     -6.0262113809585571e-01
    z[6,7,0]  R2296     -9.5427431166172028e-02
    z[6,7,0]  R2297     -3.0859872698783875e-01
    z[6,7,0]  R2298     -5.2074217796325684e-01
    z[6,7,0]  R2299     -9.4161635637283325e-01
    z[6,7,0]  R2300     -8.1056392192840576e-01
    z[6,7,0]  R2301     3.9836764335632324e-01
    z[6,7,0]  R2302     7.0478290319442749e-02
    z[6,7,0]  R2303     -5.9895825386047363e-01
    z[6,7,0]  R2304     2.6351484656333923e-01
    z[6,7,0]  R2305     -1.5788662433624268e-01
    z[6,7,0]  R2306     -6.1514323949813843e-01
    z[6,7,0]  R2307     -3.8206470012664795e-01
    z[6,7,0]  R2308     -1.1098635941743851e-01
    z[6,7,0]  R2309     -6.7380934953689575e-01
    z[6,7,0]  R2310     0.543727457523346
    z[6,7,0]  R2311     -7.9898262023925781e-01
    z[6,7,0]  R2312     7.9587094485759735e-02
    z[6,7,0]  R2313     -5.8735519647598267e-01
    z[6,7,0]  R2314     -1.9871200621128082e-01
    z[6,7,0]  R2315     -5.9651982784271240e-01
    z[6,7,0]  R2316     1.5138798952102661e-01
    z[6,7,0]  R2317     -1.5813054144382477e-01
    z[6,7,0]  R2318     -4.7670900821685791e-01
    z[6,7,0]  R2319     3.3887746930122375e-01
    z[6,7,0]  R2320     -8.8683640956878662e-01
    z[6,7,0]  R2321     3.9698880910873413e-01
    z[6,7,0]  R2322     -5.4121297597885132e-01
    z[6,7,0]  R2323     2.5448048114776611e-01
    z[6,7,0]  R2324     1.7015197873115540e-01
    z[6,7,0]  R2325     -3.7779429554939270e-01
    z[6,7,0]  R2326     -4.4674339890480042e-01
    z[6,7,0]  R2327     -3.5545790195465088e-01
    z[6,7,0]  R2328     6.5151005983352661e-01
    z[6,7,0]  R2329     -6.8009203672409058e-01
    z[6,7,0]  R2330     3.2066974788904190e-02
    z[6,7,0]  R2331     -7.2874939441680908e-01
    z[6,7,0]  R2332     -5.9182637929916382e-01
    z[6,7,0]  R2333     -2.6132553815841675e-01
    z[6,7,0]  R2334     2.8182464838027954e-01
    z[6,7,0]  R2335     2.1349306404590607e-01
    z[6,7,0]  R2336     -9.1540098190307617e-02
    z[6,7,0]  R2337     -5.4024338722229004e-02
    z[6,7,0]  R2338     3.6885675042867661e-02
    z[6,7,0]  R2339     -8.9066106081008911e-01
    z[6,7,0]  R2340     4.4937521219253540e-01
    z[6,7,0]  R2341     0.754943311214447
    z[6,7,0]  R2342     -5.8507156372070312e-01
    z[6,7,0]  R2343     2.8378924727439880e-01
    z[6,7,0]  R2344     7.8624807298183441e-02
    z[6,7,0]  R2345     1.2666773796081543e-01
    z[6,7,0]  R2346     9.6525497734546661e-02
    z[6,7,0]  R2347     -1.7874591052532196e-01
    z[6,7,0]  R2348     -1.5020088851451874e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R2207     -1
    z[6,7,1]  R2208     1
    z[6,7,1]  R2219     -1.8467040359973907e-01
    z[6,7,1]  R2220     -1.3740491867065430e-01
    z[6,7,1]  R2221     -0.263480544090271
    z[6,7,1]  R2222     -1.7347732186317444e-01
    z[6,7,1]  R2223     -0.11562529951334
    z[6,7,1]  R2224     1.0543778538703918e-01
    z[6,7,1]  R2225     1.0626516491174698e-01
    z[6,7,1]  R2226     2.3209260404109955e-01
    z[6,7,1]  R2227     -1.7743978649377823e-02
    z[6,7,1]  R2228     -7.4440743774175644e-03
    z[6,7,1]  R2229     -6.4555935561656952e-02
    z[6,7,1]  R2230     0.802198052406311
    z[6,7,1]  R2231     -2.0031096041202545e-01
    z[6,7,1]  R2232     -4.7008499503135681e-01
    z[6,7,1]  R2233     1.9505453109741211e-01
    z[6,7,1]  R2234     2.5065168738365173e-01
    z[6,7,1]  R2235     3.4602823853492737e-01
    z[6,7,1]  R2236     1.4450013637542725e-01
    z[6,7,1]  R2237     -3.8335135579109192e-01
    z[6,7,1]  R2238     9.0766036510467529e-01
    z[6,7,1]  R2239     -1.2319023162126541e-01
    z[6,7,1]  R2240     1.5052442252635956e-01
    z[6,7,1]  R2241     -5.3521089255809784e-02
    z[6,7,1]  R2242     -3.0439051985740662e-01
    z[6,7,1]  R2243     7.6228104531764984e-02
    z[6,7,1]  R2244     -4.0170428156852722e-01
    z[6,7,1]  R2245     -0.518860399723053
    z[6,7,1]  R2246     0.0714452788233757
    z[6,7,1]  R2247     1.4823582768440247e-01
    z[6,7,1]  R2248     1.9825264811515808e-01
    z[6,7,1]  R2249     -1.4329980313777924e-01
    z[6,7,1]  R2250     -2.7208226919174194e-01
    z[6,7,1]  R2251     -3.5209563374519348e-01
    z[6,7,1]  R2252     5.8529919385910034e-01
    z[6,7,1]  R2253     4.4666466116905212e-01
    z[6,7,1]  R2254     7.4827569723129272e-01
    z[6,7,1]  R2255     4.2190197110176086e-01
    z[6,7,1]  R2256     4.2537638545036316e-01
    z[6,7,1]  R2257     1.8803621828556061e-01
    z[6,7,1]  R2258     2.5354531407356262e-01
    z[6,7,1]  R2259     8.6168175935745239e-01
    z[6,7,1]  R2260     9.5194482803344727e-01
    z[6,7,1]  R2261     8.3967870473861694e-01
    z[6,7,1]  R2262     7.5791954994201660e-01
    z[6,7,1]  R2263     6.5164351463317871e-01
    z[6,7,1]  R2264     0.60193932056427
    z[6,7,1]  R2265     1.8296839296817780e-01
    z[6,7,1]  R2266     7.0275247097015381e-01
    z[6,7,1]  R2267     6.4181548357009888e-01
    z[6,7,1]  R2268     6.2443137168884277e-01
    z[6,7,1]  R2269     -0.166351318359375
    z[6,7,1]  R2270     1.9614227116107941e-01
    z[6,7,1]  R2271     1.2256369739770889e-01
    z[6,7,1]  R2272     -6.2041327357292175e-02
    z[6,7,1]  R2273     -3.0906911939382553e-02
    z[6,7,1]  R2274     1.1112090200185776e-01
    z[6,7,1]  R2275     -3.3025091886520386e-01
    z[6,7,1]  R2276     -2.3501524329185486e-01
    z[6,7,1]  R2277     -8.1570070981979370e-01
    z[6,7,1]  R2278     -1.1152768507599831e-02
    z[6,7,1]  R2279     4.8224860429763794e-01
    z[6,7,1]  R2280     2.8804332017898560e-01
    z[6,7,1]  R2281     -0.904996395111084
    z[6,7,1]  R2282     -8.0651009082794189e-01
    z[6,7,1]  R2283     -7.4384588003158569e-01
    z[6,7,1]  R2284     -6.9912791252136230e-01
    z[6,7,1]  R2285     -7.4209755659103394e-01
    z[6,7,1]  R2286     -7.4391418695449829e-01
    z[6,7,1]  R2287     -8.3136105537414551e-01
    z[6,7,1]  R2288     -7.9074168205261230e-01
    z[6,7,1]  R2289     3.5440880060195923e-01
    z[6,7,1]  R2290     -1.8497738242149353e-01
    z[6,7,1]  R2291     3.6687543988227844e-01
    z[6,7,1]  R2292     -8.6033952236175537e-01
    z[6,7,1]  R2293     -0.104481041431427
    z[6,7,1]  R2294     5.4912644624710083e-01
    z[6,7,1]  R2295     -2.0457734167575836e-01
    z[6,7,1]  R2296     -8.8429284095764160e-01
    z[6,7,1]  R2297     -7.8451168537139893e-01
    z[6,7,1]  R2298     -0.317264199256897
    z[6,7,1]  R2299     0.0891835018992424
    z[6,7,1]  R2300     3.3691781759262085e-01
    z[6,7,1]  R2301     4.4969987869262695e-01
    z[6,7,1]  R2302     2.7287730574607849e-01
    z[6,7,1]  R2303     1.3377930968999863e-02
    z[6,7,1]  R2304     -9.3052148818969727e-01
    z[6,7,1]  R2305     -8.7759679555892944e-01
    z[6,7,1]  R2306     9.5067918300628662e-02
    z[6,7,1]  R2307     4.3363296985626221e-01
    z[6,7,1]  R2308     -8.2585883140563965e-01
    z[6,7,1]  R2309     2.8689932823181152e-01
    z[6,7,1]  R2310     5.7964378595352173e-01
    z[6,7,1]  R2311     3.8527809083461761e-02
    z[6,7,1]  R2312     -2.5478392839431763e-01
    z[6,7,1]  R2313     0.0353827103972435
    z[6,7,1]  R2314     -9.1124457120895386e-01
    z[6,7,1]  R2315     -0.662040114402771
    z[6,7,1]  R2316     -7.8357911109924316e-01
    z[6,7,1]  R2317     -7.6083678007125854e-01
    z[6,7,1]  R2318     -4.1661381721496582e-01
    z[6,7,1]  R2319     -1.3202227652072906e-02
    z[6,7,1]  R2320     2.2526440024375916e-01
    z[6,7,1]  R2321     -4.9321573227643967e-02
    z[6,7,1]  R2322     3.2392221689224243e-01
    z[6,7,1]  R2323     -8.1055295467376709e-01
    z[6,7,1]  R2324     -7.8756111860275269e-01
    z[6,7,1]  R2325     -7.8263121843338013e-01
    z[6,7,1]  R2326     -7.6649588346481323e-01
    z[6,7,1]  R2327     -3.5260787606239319e-01
    z[6,7,1]  R2328     6.2596333026885986e-01
    z[6,7,1]  R2329     3.2141822576522827e-01
    z[6,7,1]  R2330     3.8521626591682434e-01
    z[6,7,1]  R2331     -5.0963733345270157e-02
    z[6,7,1]  R2332     -2.4608006700873375e-02
    z[6,7,1]  R2333     -8.7529158592224121e-01
    z[6,7,1]  R2334     -8.6956137418746948e-01
    z[6,7,1]  R2335     -8.2586467266082764e-01
    z[6,7,1]  R2336     -8.3300560712814331e-01
    z[6,7,1]  R2337     -9.1836810111999512e-01
    z[6,7,1]  R2338     5.6905514001846313e-01
    z[6,7,1]  R2339     3.3987060189247131e-01
    z[6,7,1]  R2340     5.3938800096511841e-01
    z[6,7,1]  R2341     1.8245634436607361e-01
    z[6,7,1]  R2342     -5.8379560708999634e-01
    z[6,7,1]  R2343     -0.758469820022583
    z[6,7,1]  R2344     0.500398576259613
    z[6,7,1]  R2345     -4.0672817826271057e-01
    z[6,7,1]  R2346     -2.7699694037437439e-01
    z[6,7,1]  R2347     -1.3899168372154236e-01
    z[6,7,1]  R2348     -2.8170236945152283e-01
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R2209     -1
    z[6,7,2]  R2210     1
    z[6,7,2]  R2219     2.8686735033988953e-01
    z[6,7,2]  R2220     4.7996678948402405e-01
    z[6,7,2]  R2221     3.2032766938209534e-01
    z[6,7,2]  R2222     0.468130499124527
    z[6,7,2]  R2223     8.5109126567840576e-01
    z[6,7,2]  R2224     5.6741166114807129e-01
    z[6,7,2]  R2225     5.0181424617767334e-01
    z[6,7,2]  R2226     6.3314098119735718e-01
    z[6,7,2]  R2227     -4.0242251753807068e-01
    z[6,7,2]  R2228     6.1131817102432251e-01
    z[6,7,2]  R2229     2.3638445138931274e-01
    z[6,7,2]  R2230     -2.1357320249080658e-02
    z[6,7,2]  R2231     1.7076766490936279e-01
    z[6,7,2]  R2232     3.5945731401443481e-01
    z[6,7,2]  R2233     3.8796633481979370e-01
    z[6,7,2]  R2234     3.3352798223495483e-01
    z[6,7,2]  R2235     -7.1650457382202148e-01
    z[6,7,2]  R2236     -7.4348253011703491e-01
    z[6,7,2]  R2237     -4.6164166927337646e-01
    z[6,7,2]  R2238     9.9883466958999634e-02
    z[6,7,2]  R2239     -2.6978502050042152e-02
    z[6,7,2]  R2240     3.1799456477165222e-01
    z[6,7,2]  R2241     5.3231620788574219e-01
    z[6,7,2]  R2242     4.8598667979240417e-01
    z[6,7,2]  R2243     2.3269085586071014e-01
    z[6,7,2]  R2244     3.8618156313896179e-01
    z[6,7,2]  R2245     1.1577173322439194e-01
    z[6,7,2]  R2246     -2.1999187767505646e-01
    z[6,7,2]  R2247     3.9089924097061157e-01
    z[6,7,2]  R2248     3.9018783718347549e-02
    z[6,7,2]  R2249     -3.4256213903427124e-01
    z[6,7,2]  R2250     8.4643848240375519e-02
    z[6,7,2]  R2251     -0.0328790545463562
    z[6,7,2]  R2252     -3.7224420905113220e-01
    z[6,7,2]  R2253     0.0223090797662735
    z[6,7,2]  R2254     7.9673487925902009e-04
    z[6,7,2]  R2255     -1.5540605783462524e-01
    z[6,7,2]  R2256     2.8781020641326904e-01
    z[6,7,2]  R2257     -6.6818159818649292e-01
    z[6,7,2]  R2258     3.0707883834838867e-01
    z[6,7,2]  R2259     -4.6933200210332870e-02
    z[6,7,2]  R2260     -1.1756887659430504e-02
    z[6,7,2]  R2261     0.148001566529274
    z[6,7,2]  R2262     1.7065636813640594e-01
    z[6,7,2]  R2263     -1.1008264124393463e-01
    z[6,7,2]  R2264     1.7419527471065521e-01
    z[6,7,2]  R2265     2.6829114556312561e-01
    z[6,7,2]  R2266     3.6461880803108215e-01
    z[6,7,2]  R2267     1.4063043892383575e-01
    z[6,7,2]  R2268     -0.0342351458966732
    z[6,7,2]  R2269     2.0866812765598297e-01
    z[6,7,2]  R2270     3.6729472875595093e-01
    z[6,7,2]  R2271     3.6069635301828384e-02
    z[6,7,2]  R2272     -5.5398438125848770e-02
    z[6,7,2]  R2273     3.2442143559455872e-01
    z[6,7,2]  R2274     5.2716922014951706e-02
    z[6,7,2]  R2275     -1.0509991645812988e-01
    z[6,7,2]  R2276     1.1707766354084015e-01
    z[6,7,2]  R2277     -4.1049256920814514e-01
    z[6,7,2]  R2278     -3.7668108940124512e-02
    z[6,7,2]  R2279     -3.5654169321060181e-01
    z[6,7,2]  R2280     -0.135230153799057
    z[6,7,2]  R2281     1.7250137403607368e-02
    z[6,7,2]  R2282     -1.4609888195991516e-01
    z[6,7,2]  R2283     -6.6297873854637146e-02
    z[6,7,2]  R2284     2.2318531572818756e-01
    z[6,7,2]  R2285     3.1908690929412842e-02
    z[6,7,2]  R2286     7.6484262943267822e-02
    z[6,7,2]  R2287     6.1499748378992081e-02
    z[6,7,2]  R2288     2.4359221756458282e-01
    z[6,7,2]  R2289     1.7425008118152618e-01
    z[6,7,2]  R2290     -1.3354432582855225e-01
    z[6,7,2]  R2291     -1.3887584209442139e-01
    z[6,7,2]  R2292     -3.9314043521881104e-01
    z[6,7,2]  R2293     1.2395108491182327e-01
    z[6,7,2]  R2294     1.6706761717796326e-01
    z[6,7,2]  R2295     4.9057373404502869e-01
    z[6,7,2]  R2296     2.4277816712856293e-01
    z[6,7,2]  R2297     -1.8345075845718384e-01
    z[6,7,2]  R2298     5.1877623796463013e-01
    z[6,7,2]  R2299     0.0737726092338562
    z[6,7,2]  R2300     4.3167144060134888e-02
    z[6,7,2]  R2301     6.4395293593406677e-02
    z[6,7,2]  R2302     2.7652397751808167e-01
    z[6,7,2]  R2303     6.4655095338821411e-01
    z[6,7,2]  R2304     1.6862362623214722e-01
    z[6,7,2]  R2305     -2.0928969606757164e-02
    z[6,7,2]  R2306     1.7930777370929718e-01
    z[6,7,2]  R2307     3.1241157650947571e-01
    z[6,7,2]  R2308     -1.7183783650398254e-01
    z[6,7,2]  R2309     3.9254274964332581e-01
    z[6,7,2]  R2310     2.8326365351676941e-01
    z[6,7,2]  R2311     4.5729362964630127e-01
    z[6,7,2]  R2312     1.0710256546735764e-01
    z[6,7,2]  R2313     2.5877770781517029e-01
    z[6,7,2]  R2314     2.4274586141109467e-01
    z[6,7,2]  R2315     4.1924878954887390e-01
    z[6,7,2]  R2316     -3.1090310215950012e-01
    z[6,7,2]  R2317     4.1387838125228882e-01
    z[6,7,2]  R2318     2.2290448844432831e-01
    z[6,7,2]  R2319     1.3754753768444061e-01
    z[6,7,2]  R2320     -2.9798170551657677e-02
    z[6,7,2]  R2321     -2.5615268945693970e-01
    z[6,7,2]  R2322     3.2194903492927551e-01
    z[6,7,2]  R2323     -0.251189261674881
    z[6,7,2]  R2324     -1.7484319210052490e-01
    z[6,7,2]  R2325     -1.2572652101516724e-01
    z[6,7,2]  R2326     1.7241321504116058e-02
    z[6,7,2]  R2327     7.6796674728393555e-01
    z[6,7,2]  R2328     -7.9537652432918549e-02
    z[6,7,2]  R2329     3.1214842200279236e-01
    z[6,7,2]  R2330     -4.9438709020614624e-01
    z[6,7,2]  R2331     0.512950599193573
    z[6,7,2]  R2332     3.3939656615257263e-01
    z[6,7,2]  R2333     6.9249749183654785e-02
    z[6,7,2]  R2334     -2.1348603069782257e-01
    z[6,7,2]  R2335     -0.0791369378566742
    z[6,7,2]  R2336     2.7444148436188698e-02
    z[6,7,2]  R2337     -2.9958806931972504e-02
    z[6,7,2]  R2338     -6.3811767101287842e-01
    z[6,7,2]  R2339     2.1972709894180298e-01
    z[6,7,2]  R2340     2.5459833443164825e-02
    z[6,7,2]  R2341     5.6263640522956848e-02
    z[6,7,2]  R2342     3.9968156814575195e-01
    z[6,7,2]  R2343     -1.6684535145759583e-01
    z[6,7,2]  R2344     -6.5829616785049438e-01
    z[6,7,2]  R2345     -4.8338127136230469e-01
    z[6,7,2]  R2346     -6.8979966640472412e-01
    z[6,7,2]  R2347     5.9844231605529785e-01
    z[6,7,2]  R2348     -6.1854153871536255e-01
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R2211     -1
    z[6,7,3]  R2212     1
    z[6,7,3]  R2219     -0.258035808801651
    z[6,7,3]  R2220     1.2278497964143753e-01
    z[6,7,3]  R2221     1.5831816196441650e-01
    z[6,7,3]  R2222     -8.6031429469585419e-02
    z[6,7,3]  R2223     1.6550848260521889e-02
    z[6,7,3]  R2224     3.3472830057144165e-01
    z[6,7,3]  R2225     -1.8150122463703156e-01
    z[6,7,3]  R2226     4.3236851692199707e-02
    z[6,7,3]  R2227     2.4676360189914703e-01
    z[6,7,3]  R2228     2.7102762460708618e-01
    z[6,7,3]  R2229     8.2595801353454590e-01
    z[6,7,3]  R2230     5.1190227270126343e-01
    z[6,7,3]  R2231     -4.7305294871330261e-01
    z[6,7,3]  R2232     -4.7772252559661865e-01
    z[6,7,3]  R2233     -2.2916845977306366e-01
    z[6,7,3]  R2234     3.6530005931854248e-01
    z[6,7,3]  R2235     2.2059649229049683e-01
    z[6,7,3]  R2236     0.436553955078125
    z[6,7,3]  R2237     2.1341089904308319e-01
    z[6,7,3]  R2238     8.2821629941463470e-02
    z[6,7,3]  R2239     4.1775268316268921e-01
    z[6,7,3]  R2240     1.7087125778198242e-01
    z[6,7,3]  R2241     6.1872269958257675e-02
    z[6,7,3]  R2242     -2.9044350981712341e-01
    z[6,7,3]  R2243     2.3048759996891022e-01
    z[6,7,3]  R2244     1.4789731800556183e-01
    z[6,7,3]  R2245     2.0402505993843079e-02
    z[6,7,3]  R2246     4.0229588747024536e-01
    z[6,7,3]  R2247     5.2630184218287468e-03
    z[6,7,3]  R2248     8.6509138345718384e-02
    z[6,7,3]  R2249     -2.4839197099208832e-01
    z[6,7,3]  R2250     -4.9620926380157471e-01
    z[6,7,3]  R2251     -2.7569499611854553e-01
    z[6,7,3]  R2252     -1.9026175141334534e-02
    z[6,7,3]  R2253     5.1256150007247925e-01
    z[6,7,3]  R2254     3.8620454072952271e-01
    z[6,7,3]  R2255     7.3760688304901123e-01
    z[6,7,3]  R2256     5.5118137598037720e-01
    z[6,7,3]  R2257     -5.6256562471389771e-01
    z[6,7,3]  R2258     4.1415810585021973e-01
    z[6,7,3]  R2259     2.5789457559585571e-01
    z[6,7,3]  R2260     7.6679818332195282e-02
    z[6,7,3]  R2261     7.4222676455974579e-02
    z[6,7,3]  R2262     6.7925274372100830e-02
    z[6,7,3]  R2263     4.2619869112968445e-02
    z[6,7,3]  R2264     1.5018087625503540e-01
    z[6,7,3]  R2265     -2.2287322208285332e-02
    z[6,7,3]  R2266     1.7334936559200287e-01
    z[6,7,3]  R2267     1.5530005097389221e-01
    z[6,7,3]  R2268     0.0453343540430069
    z[6,7,3]  R2269     6.0690528154373169e-01
    z[6,7,3]  R2270     5.7045966386795044e-01
    z[6,7,3]  R2271     5.9706658124923706e-01
    z[6,7,3]  R2272     6.5926498174667358e-01
    z[6,7,3]  R2273     5.5603188276290894e-01
    z[6,7,3]  R2274     5.6152331829071045e-01
    z[6,7,3]  R2275     6.3624918460845947e-01
    z[6,7,3]  R2276     4.3104144930839539e-01
    z[6,7,3]  R2277     -1.4310272037982941e-01
    z[6,7,3]  R2278     3.2803124189376831e-01
    z[6,7,3]  R2279     6.1675232648849487e-01
    z[6,7,3]  R2280     4.8381385207176208e-01
    z[6,7,3]  R2281     1.1437595635652542e-01
    z[6,7,3]  R2282     4.5385140925645828e-02
    z[6,7,3]  R2283     -4.7429639101028442e-01
    z[6,7,3]  R2284     -1.3199462555348873e-02
    z[6,7,3]  R2285     2.3878661915659904e-02
    z[6,7,3]  R2286     -1.5798424184322357e-01
    z[6,7,3]  R2287     -1.9470445811748505e-01
    z[6,7,3]  R2288     2.4173672497272491e-01
    z[6,7,3]  R2289     6.5899646282196045e-01
    z[6,7,3]  R2290     7.6095026731491089e-01
    z[6,7,3]  R2291     -7.1903415024280548e-02
    z[6,7,3]  R2292     7.1365468204021454e-02
    z[6,7,3]  R2293     -2.8981423377990723e-01
    z[6,7,3]  R2294     3.6298626661300659e-01
    z[6,7,3]  R2295     1.3017773628234863e-01
    z[6,7,3]  R2296     -1.4988839626312256e-01
    z[6,7,3]  R2297     -3.9614096283912659e-01
    z[6,7,3]  R2298     -3.0419471859931946e-01
    z[6,7,3]  R2299     -2.1315976977348328e-01
    z[6,7,3]  R2300     -2.4674201011657715e-01
    z[6,7,3]  R2301     6.0045200586318970e-01
    z[6,7,3]  R2302     0.831079363822937
    z[6,7,3]  R2303     2.4031335115432739e-01
    z[6,7,3]  R2304     1.3446410000324249e-01
    z[6,7,3]  R2305     1.8834297358989716e-01
    z[6,7,3]  R2306     -4.5580846071243286e-01
    z[6,7,3]  R2307     -4.4311785697937012e-01
    z[6,7,3]  R2308     3.0654057860374451e-01
    z[6,7,3]  R2309     -3.5950881242752075e-01
    z[6,7,3]  R2310     4.5377832651138306e-01
    z[6,7,3]  R2311     1.6288067400455475e-01
    z[6,7,3]  R2312     7.8887414932250977e-01
    z[6,7,3]  R2313     6.0306102037429810e-01
    z[6,7,3]  R2314     2.2944065928459167e-01
    z[6,7,3]  R2315     1.3756365515291691e-02
    z[6,7,3]  R2316     1.4490705728530884e-01
    z[6,7,3]  R2317     9.3097344040870667e-02
    z[6,7,3]  R2318     -8.0060526728630066e-02
    z[6,7,3]  R2319     7.7907508611679077e-01
    z[6,7,3]  R2320     7.3133997619152069e-02
    z[6,7,3]  R2321     7.1731686592102051e-01
    z[6,7,3]  R2322     -1.1281068623065948e-01
    z[6,7,3]  R2323     4.0450257062911987e-01
    z[6,7,3]  R2324     0.00385760678909719
    z[6,7,3]  R2325     -8.1982992589473724e-02
    z[6,7,3]  R2326     1.7649991810321808e-01
    z[6,7,3]  R2327     -2.6585987210273743e-01
    z[6,7,3]  R2328     -2.9219236969947815e-01
    z[6,7,3]  R2329     4.7909659147262573e-01
    z[6,7,3]  R2330     6.0675078630447388e-01
    z[6,7,3]  R2331     7.6968587934970856e-02
    z[6,7,3]  R2332     5.7475709915161133e-01
    z[6,7,3]  R2333     -1.0565434396266937e-01
    z[6,7,3]  R2334     -7.3891326785087585e-02
    z[6,7,3]  R2335     4.7077399492263794e-01
    z[6,7,3]  R2336     3.1705811619758606e-01
    z[6,7,3]  R2337     -3.5898125171661377e-01
    z[6,7,3]  R2338     -4.4451120495796204e-01
    z[6,7,3]  R2339     1.5172217041254044e-02
    z[6,7,3]  R2340     6.6756260395050049e-01
    z[6,7,3]  R2341     4.9172133207321167e-01
    z[6,7,3]  R2342     1.4260038733482361e-01
    z[6,7,3]  R2343     -4.7486531734466553e-01
    z[6,7,3]  R2344     -3.3216324448585510e-01
    z[6,7,3]  R2345     -2.8205469250679016e-01
    z[6,7,3]  R2346     -5.6749057024717331e-02
    z[6,7,3]  R2347     -1.0599813610315323e-01
    z[6,7,3]  R2348     -1.9939118623733521e-01
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R2213     -1
    z[6,7,4]  R2214     1
    z[6,7,4]  R2219     3.0593115091323853e-01
    z[6,7,4]  R2220     6.5106144174933434e-03
    z[6,7,4]  R2221     -4.5229992270469666e-01
    z[6,7,4]  R2222     -3.1586790084838867e-01
    z[6,7,4]  R2223     0.0892091765999794
    z[6,7,4]  R2224     -2.5338403880596161e-02
    z[6,7,4]  R2225     -8.6166240274906158e-02
    z[6,7,4]  R2226     -4.0733799338340759e-01
    z[6,7,4]  R2227     -1.0798192024230957e-01
    z[6,7,4]  R2228     -3.9711430668830872e-01
    z[6,7,4]  R2229     2.8151612728834152e-02
    z[6,7,4]  R2230     9.6242956817150116e-02
    z[6,7,4]  R2231     0.629560112953186
    z[6,7,4]  R2232     2.3625931143760681e-01
    z[6,7,4]  R2233     -9.6024684607982635e-02
    z[6,7,4]  R2234     5.7412409782409668e-01
    z[6,7,4]  R2235     3.5405838489532471e-01
    z[6,7,4]  R2236     7.6192080974578857e-02
    z[6,7,4]  R2237     -3.4034612774848938e-01
    z[6,7,4]  R2238     1.1436818540096283e-01
    z[6,7,4]  R2239     3.0561983585357666e-01
    z[6,7,4]  R2240     -2.8432181477546692e-01
    z[6,7,4]  R2241     2.3806239664554596e-01
    z[6,7,4]  R2242     -2.4416035413742065e-01
    z[6,7,4]  R2243     5.5884812027215958e-02
    z[6,7,4]  R2244     4.0759924799203873e-02
    z[6,7,4]  R2245     -0.142137348651886
    z[6,7,4]  R2246     -1.2161013484001160e-01
    z[6,7,4]  R2247     2.0110353827476501e-01
    z[6,7,4]  R2248     4.0101557970046997e-01
    z[6,7,4]  R2249     -2.5878927111625671e-01
    z[6,7,4]  R2250     3.3145558834075928e-01
    z[6,7,4]  R2251     -1.4004895463585854e-02
    z[6,7,4]  R2252     8.0085322260856628e-02
    z[6,7,4]  R2253     -1.9381056725978851e-01
    z[6,7,4]  R2254     2.7783846855163574e-01
    z[6,7,4]  R2255     -4.5912593603134155e-02
    z[6,7,4]  R2256     -4.2880815267562866e-01
    z[6,7,4]  R2257     -2.3255331814289093e-01
    z[6,7,4]  R2258     7.3434972763061523e-01
    z[6,7,4]  R2259     -1.1496312171220779e-01
    z[6,7,4]  R2260     6.1036888509988785e-02
    z[6,7,4]  R2261     1.1571945995092392e-01
    z[6,7,4]  R2262     -3.8888859748840332e-01
    z[6,7,4]  R2263     -1.1638686805963516e-01
    z[6,7,4]  R2264     -2.9812756180763245e-01
    z[6,7,4]  R2265     -1.9319224357604980e-01
    z[6,7,4]  R2266     1.6015812754631042e-01
    z[6,7,4]  R2267     4.2423516511917114e-01
    z[6,7,4]  R2268     -1.7063283594325185e-03
    z[6,7,4]  R2269     -3.7976670265197754e-01
    z[6,7,4]  R2270     -5.4631937295198441e-02
    z[6,7,4]  R2271     -4.7857353091239929e-01
    z[6,7,4]  R2272     1.5906213223934174e-01
    z[6,7,4]  R2273     1.1276460252702236e-02
    z[6,7,4]  R2274     5.0584155321121216e-01
    z[6,7,4]  R2275     2.3941858112812042e-01
    z[6,7,4]  R2276     -0.562581479549408
    z[6,7,4]  R2277     8.6790435016155243e-02
    z[6,7,4]  R2278     -1.2445009499788284e-01
    z[6,7,4]  R2279     4.0344062447547913e-01
    z[6,7,4]  R2280     -2.3010616004467010e-01
    z[6,7,4]  R2281     -2.1427439153194427e-01
    z[6,7,4]  R2282     -5.6533205509185791e-01
    z[6,7,4]  R2283     -1.5597687661647797e-01
    z[6,7,4]  R2284     -4.6064171195030212e-01
    z[6,7,4]  R2285     -6.3801310956478119e-02
    z[6,7,4]  R2286     5.2818089723587036e-01
    z[6,7,4]  R2287     4.9443128705024719e-01
    z[6,7,4]  R2288     -2.1657621860504150e-01
    z[6,7,4]  R2289     -1.7721369862556458e-02
    z[6,7,4]  R2290     3.4907300025224686e-02
    z[6,7,4]  R2291     -1.4428691565990448e-01
    z[6,7,4]  R2292     5.3972166031599045e-02
    z[6,7,4]  R2293     3.9959940314292908e-01
    z[6,7,4]  R2294     -4.4225663878023624e-03
    z[6,7,4]  R2295     5.6520360708236694e-01
    z[6,7,4]  R2296     2.9839816689491272e-01
    z[6,7,4]  R2297     -1.2828929722309113e-01
    z[6,7,4]  R2298     2.1192553639411926e-01
    z[6,7,4]  R2299     8.9194908738136292e-02
    z[6,7,4]  R2300     3.6870828270912170e-01
    z[6,7,4]  R2301     -3.1754696369171143e-01
    z[6,7,4]  R2302     2.1599155664443970e-01
    z[6,7,4]  R2303     3.5281282663345337e-01
    z[6,7,4]  R2304     -0.0717427060008049
    z[6,7,4]  R2305     1.4988392591476440e-01
    z[6,7,4]  R2306     1.9288735091686249e-01
    z[6,7,4]  R2307     -3.0036326497793198e-02
    z[6,7,4]  R2308     -2.2175274789333344e-02
    z[6,7,4]  R2309     -5.9873346239328384e-02
    z[6,7,4]  R2310     1.8889187276363373e-01
    z[6,7,4]  R2311     -2.0365279912948608e-01
    z[6,7,4]  R2312     -5.0281536579132080e-01
    z[6,7,4]  R2313     -7.1040540933609009e-02
    z[6,7,4]  R2314     7.4606128036975861e-02
    z[6,7,4]  R2315     2.8247093781828880e-02
    z[6,7,4]  R2316     8.0307433381676674e-04
    z[6,7,4]  R2317     -8.1252768635749817e-02
    z[6,7,4]  R2318     -6.5929013490676880e-01
    z[6,7,4]  R2319     -3.4355142712593079e-01
    z[6,7,4]  R2320     1.5855866670608521e-01
    z[6,7,4]  R2321     4.9937221407890320e-01
    z[6,7,4]  R2322     2.7032768726348877e-01
    z[6,7,4]  R2323     9.5205254852771759e-02
    z[6,7,4]  R2324     2.9664269089698792e-01
    z[6,7,4]  R2325     -3.3074134588241577e-01
    z[6,7,4]  R2326     -3.5192474722862244e-01
    z[6,7,4]  R2327     -2.4802875518798828e-01
    z[6,7,4]  R2328     -1.7932142317295074e-01
    z[6,7,4]  R2329     -1.3013717532157898e-01
    z[6,7,4]  R2330     -2.1842719614505768e-01
    z[6,7,4]  R2331     -3.3131629228591919e-01
    z[6,7,4]  R2332     3.6168730258941650e-01
    z[6,7,4]  R2333     7.0028595626354218e-02
    z[6,7,4]  R2334     3.1607393175363541e-02
    z[6,7,4]  R2335     -3.6443449556827545e-02
    z[6,7,4]  R2336     -7.0717319846153259e-02
    z[6,7,4]  R2337     -8.0152988433837891e-02
    z[6,7,4]  R2338     -9.5381431281566620e-02
    z[6,7,4]  R2339     -8.0028679221868515e-03
    z[6,7,4]  R2340     -4.6683689579367638e-03
    z[6,7,4]  R2341     2.3104159533977509e-01
    z[6,7,4]  R2342     -4.9141305498778820e-04
    z[6,7,4]  R2343     2.8214901685714722e-01
    z[6,7,4]  R2344     1.9687581062316895e-01
    z[6,7,4]  R2345     6.2029594182968140e-01
    z[6,7,4]  R2346     6.0424196720123291e-01
    z[6,7,4]  R2347     -3.1634208559989929e-01
    z[6,7,4]  R2348     6.7752408981323242e-01
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R2215     -1
    z[6,7,5]  R2216     1
    z[6,7,5]  R2219     -1.1195619404315948e-01
    z[6,7,5]  R2220     1.8842902779579163e-01
    z[6,7,5]  R2221     2.4268217384815216e-01
    z[6,7,5]  R2222     -2.8632253408432007e-01
    z[6,7,5]  R2223     -7.0227861404418945e-02
    z[6,7,5]  R2224     -3.1152474880218506e-01
    z[6,7,5]  R2225     1.0080326348543167e-01
    z[6,7,5]  R2226     -1.7867214977741241e-01
    z[6,7,5]  R2227     2.6090887188911438e-01
    z[6,7,5]  R2228     3.1812575459480286e-01
    z[6,7,5]  R2229     3.4749977290630341e-02
    z[6,7,5]  R2230     2.6824250817298889e-01
    z[6,7,5]  R2231     -1.3079972565174103e-01
    z[6,7,5]  R2232     1.5704709291458130e-01
    z[6,7,5]  R2233     -7.0687431097030640e-01
    z[6,7,5]  R2234     -2.5559765100479126e-01
    z[6,7,5]  R2235     2.6255035400390625e-01
    z[6,7,5]  R2236     -1.4988008141517639e-01
    z[6,7,5]  R2237     0.286690354347229
    z[6,7,5]  R2238     2.8930592536926270e-01
    z[6,7,5]  R2239     3.4431774169206619e-02
    z[6,7,5]  R2240     -1.0478625446557999e-01
    z[6,7,5]  R2241     -2.1493105590343475e-01
    z[6,7,5]  R2242     -3.1095145270228386e-02
    z[6,7,5]  R2243     -1.9912435114383698e-01
    z[6,7,5]  R2244     0.402570903301239
    z[6,7,5]  R2245     3.1461000442504883e-01
    z[6,7,5]  R2246     -2.0663768053054810e-01
    z[6,7,5]  R2247     1.7251954972743988e-01
    z[6,7,5]  R2248     -4.0156453847885132e-01
    z[6,7,5]  R2249     1.4101035892963409e-01
    z[6,7,5]  R2250     2.3707848787307739e-01
    z[6,7,5]  R2251     -2.9156050086021423e-01
    z[6,7,5]  R2252     -3.1166058778762817e-01
    z[6,7,5]  R2253     5.4415595531463623e-01
    z[6,7,5]  R2254     -2.9116401076316833e-01
    z[6,7,5]  R2255     -6.4724549651145935e-02
    z[6,7,5]  R2256     2.5215440988540649e-01
    z[6,7,5]  R2257     -3.9865810424089432e-02
    z[6,7,5]  R2258     0.284146785736084
    z[6,7,5]  R2259     0.0596165657043457
    z[6,7,5]  R2260     -1.5421052277088165e-01
    z[6,7,5]  R2261     2.5916749238967896e-01
    z[6,7,5]  R2262     3.5540476441383362e-02
    z[6,7,5]  R2263     2.4593852460384369e-01
    z[6,7,5]  R2264     2.6339060068130493e-01
    z[6,7,5]  R2265     -3.1690327450633049e-03
    z[6,7,5]  R2266     -2.6576307415962219e-01
    z[6,7,5]  R2267     7.5584337115287781e-02
    z[6,7,5]  R2268     -1.3800999522209167e-01
    z[6,7,5]  R2269     -2.3829996585845947e-01
    z[6,7,5]  R2270     -4.3946501612663269e-01
    z[6,7,5]  R2271     -3.5648146271705627e-01
    z[6,7,5]  R2272     -4.4333106279373169e-01
    z[6,7,5]  R2273     -1.6065049916505814e-02
    z[6,7,5]  R2274     1.9907447695732117e-01
    z[6,7,5]  R2275     1.5110961161553860e-02
    z[6,7,5]  R2276     4.7820255160331726e-01
    z[6,7,5]  R2277     3.8310371339321136e-02
    z[6,7,5]  R2278     8.0996805429458618e-01
    z[6,7,5]  R2279     -1.6127489507198334e-01
    z[6,7,5]  R2280     0.690273106098175
    z[6,7,5]  R2281     -3.0313533544540405e-01
    z[6,7,5]  R2282     7.4939350597560406e-03
    z[6,7,5]  R2283     0.0902993455529213
    z[6,7,5]  R2284     -4.8316949605941772e-01
    z[6,7,5]  R2285     1.0509271919727325e-01
    z[6,7,5]  R2286     -1.3863454759120941e-01
    z[6,7,5]  R2287     -5.6824021041393280e-02
    z[6,7,5]  R2288     2.8457471728324890e-01
    z[6,7,5]  R2289     -7.8652210533618927e-02
    z[6,7,5]  R2290     1.3941408693790436e-01
    z[6,7,5]  R2291     -5.6810826063156128e-01
    z[6,7,5]  R2292     2.0864079892635345e-01
    z[6,7,5]  R2293     3.5150960087776184e-01
    z[6,7,5]  R2294     3.6750671267509460e-01
    z[6,7,5]  R2295     8.7569728493690491e-02
    z[6,7,5]  R2296     5.7715136557817459e-02
    z[6,7,5]  R2297     2.7905693650245667e-01
    z[6,7,5]  R2298     -3.2278639078140259e-01
    z[6,7,5]  R2299     2.1576821804046631e-01
    z[6,7,5]  R2300     1.7159767448902130e-01
    z[6,7,5]  R2301     4.1267678141593933e-01
    z[6,7,5]  R2302     -1.2315607070922852e-01
    z[6,7,5]  R2303     -7.2828345000743866e-02
    z[6,7,5]  R2304     1.3304447755217552e-02
    z[6,7,5]  R2305     3.5721620917320251e-01
    z[6,7,5]  R2306     -5.7846039533615112e-01
    z[6,7,5]  R2307     -5.3011399507522583e-01
    z[6,7,5]  R2308     2.8076618909835815e-01
    z[6,7,5]  R2309     -2.3221983015537262e-01
    z[6,7,5]  R2310     1.2673947215080261e-01
    z[6,7,5]  R2311     -2.8106454014778137e-01
    z[6,7,5]  R2312     1.4398138225078583e-01
    z[6,7,5]  R2313     -2.9013365507125854e-01
    z[6,7,5]  R2314     1.1404684931039810e-01
    z[6,7,5]  R2315     -0.0963074192404747
    z[6,7,5]  R2316     -1.9495855271816254e-01
    z[6,7,5]  R2317     2.8034153580665588e-01
    z[6,7,5]  R2318     -0.323823481798172
    z[6,7,5]  R2319     3.7357372045516968e-01
    z[6,7,5]  R2320     -5.8438368141651154e-02
    z[6,7,5]  R2321     -7.9122297465801239e-02
    z[6,7,5]  R2322     -6.4036726951599121e-01
    z[6,7,5]  R2323     -1.8583790957927704e-01
    z[6,7,5]  R2324     -3.2547211647033691e-01
    z[6,7,5]  R2325     -2.4672269821166992e-01
    z[6,7,5]  R2326     -1.0942756384611130e-01
    z[6,7,5]  R2327     8.1528417766094208e-02
    z[6,7,5]  R2328     2.4342155456542969e-01
    z[6,7,5]  R2329     -2.1648842096328735e-01
    z[6,7,5]  R2330     -1.0613638907670975e-01
    z[6,7,5]  R2331     -6.7212902009487152e-02
    z[6,7,5]  R2332     2.4922121316194534e-02
    z[6,7,5]  R2333     -3.5402163863182068e-01
    z[6,7,5]  R2334     -2.4613919854164124e-01
    z[6,7,5]  R2335     -1.1041836440563202e-01
    z[6,7,5]  R2336     -0.289393812417984
    z[6,7,5]  R2337     -1.6315674409270287e-02
    z[6,7,5]  R2338     9.6302941441535950e-02
    z[6,7,5]  R2339     -1.8625985085964203e-01
    z[6,7,5]  R2340     1.9237220287322998e-01
    z[6,7,5]  R2341     -2.5953933596611023e-01
    z[6,7,5]  R2342     2.0789082348346710e-01
    z[6,7,5]  R2343     2.5498500093817711e-02
    z[6,7,5]  R2344     3.3535334467887878e-01
    z[6,7,5]  R2345     -2.5545755028724670e-01
    z[6,7,5]  R2346     -2.6062300801277161e-01
    z[6,7,5]  R2347     -3.4602773189544678e-01
    z[6,7,5]  R2348     8.0022260546684265e-02
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R2217     -1
    z[6,7,6]  R2218     1
    z[6,7,6]  R2219     -2.1279849112033844e-01
    z[6,7,6]  R2220     4.5877873897552490e-02
    z[6,7,6]  R2221     -2.1587008610367775e-02
    z[6,7,6]  R2222     -1.8798071146011353e-01
    z[6,7,6]  R2223     5.2520852535963058e-02
    z[6,7,6]  R2224     -3.2697860151529312e-02
    z[6,7,6]  R2225     3.2514709234237671e-01
    z[6,7,6]  R2226     3.3500474691390991e-01
    z[6,7,6]  R2227     -7.1647331118583679e-02
    z[6,7,6]  R2228     3.5818368196487427e-01
    z[6,7,6]  R2229     -1.2113984674215317e-01
    z[6,7,6]  R2230     0.0630001500248909
    z[6,7,6]  R2231     -1.8945485353469849e-01
    z[6,7,6]  R2232     -4.0386196970939636e-01
    z[6,7,6]  R2233     -0.0329107791185379
    z[6,7,6]  R2234     5.5236298590898514e-02
    z[6,7,6]  R2235     2.0116844773292542e-01
    z[6,7,6]  R2236     -2.6413249969482422e-01
    z[6,7,6]  R2237     -2.9550895094871521e-01
    z[6,7,6]  R2238     -2.4038228392601013e-01
    z[6,7,6]  R2239     -1.9249269366264343e-01
    z[6,7,6]  R2240     2.4628737568855286e-01
    z[6,7,6]  R2241     -2.1937627345323563e-02
    z[6,7,6]  R2242     -1.7732024192810059e-02
    z[6,7,6]  R2243     2.5335814803838730e-02
    z[6,7,6]  R2244     -1.4237202703952789e-02
    z[6,7,6]  R2245     -2.0964252948760986e-01
    z[6,7,6]  R2246     -1.3886238634586334e-01
    z[6,7,6]  R2247     0.396258682012558
    z[6,7,6]  R2248     -7.3812879621982574e-02
    z[6,7,6]  R2249     -4.7473390586674213e-03
    z[6,7,6]  R2250     1.1666963808238506e-02
    z[6,7,6]  R2251     -4.2950114607810974e-01
    z[6,7,6]  R2252     2.1697996556758881e-01
    z[6,7,6]  R2253     -3.2839265465736389e-01
    z[6,7,6]  R2254     -3.5264673829078674e-01
    z[6,7,6]  R2255     -4.8314219713211060e-01
    z[6,7,6]  R2256     -4.2768004536628723e-01
    z[6,7,6]  R2257     8.9470840990543365e-02
    z[6,7,6]  R2258     -2.0651248097419739e-01
    z[6,7,6]  R2259     -1.3391232490539551e-01
    z[6,7,6]  R2260     -5.5602509528398514e-02
    z[6,7,6]  R2261     9.5840133726596832e-02
    z[6,7,6]  R2262     1.4374126493930817e-01
    z[6,7,6]  R2263     -1.5773972868919373e-01
    z[6,7,6]  R2264     0.0995691567659378
    z[6,7,6]  R2265     -7.6256953179836273e-02
    z[6,7,6]  R2266     1.4368730783462524e-01
    z[6,7,6]  R2267     -1.5407225489616394e-01
    z[6,7,6]  R2268     1.6710811853408813e-01
    z[6,7,6]  R2269     2.9666331410408020e-01
    z[6,7,6]  R2270     1.7016613855957985e-02
    z[6,7,6]  R2271     -2.0249038934707642e-01
    z[6,7,6]  R2272     -1.0928864032030106e-01
    z[6,7,6]  R2273     6.4154869318008423e-01
    z[6,7,6]  R2274     5.3281837701797485e-01
    z[6,7,6]  R2275     3.0589789152145386e-01
    z[6,7,6]  R2276     2.4263255298137665e-01
    z[6,7,6]  R2277     -2.9404631257057190e-01
    z[6,7,6]  R2278     2.7412512898445129e-01
    z[6,7,6]  R2279     4.8868253827095032e-02
    z[6,7,6]  R2280     8.0984615487977862e-04
    z[6,7,6]  R2281     -1.7131294310092926e-01
    z[6,7,6]  R2282     -7.9409822821617126e-02
    z[6,7,6]  R2283     3.2485806941986084e-01
    z[6,7,6]  R2284     8.6883746087551117e-02
    z[6,7,6]  R2285     1.9362498819828033e-01
    z[6,7,6]  R2286     3.8350574672222137e-02
    z[6,7,6]  R2287     -0.0493636429309845
    z[6,7,6]  R2288     9.3438185751438141e-02
    z[6,7,6]  R2289     5.2796018123626709e-01
    z[6,7,6]  R2290     -4.5082005858421326e-01
    z[6,7,6]  R2291     -3.9235156774520874e-01
    z[6,7,6]  R2292     -2.1485263109207153e-01
    z[6,7,6]  R2293     1.0583304613828659e-01
    z[6,7,6]  R2294     2.6076692342758179e-01
    z[6,7,6]  R2295     0.101309634745121
    z[6,7,6]  R2296     1.8745566904544830e-01
    z[6,7,6]  R2297     6.6299118101596832e-02
    z[6,7,6]  R2298     3.4264308214187622e-01
    z[6,7,6]  R2299     3.6983732134103775e-03
    z[6,7,6]  R2300     -3.6549825221300125e-02
    z[6,7,6]  R2301     5.6970596313476562e-02
    z[6,7,6]  R2302     -3.0264276266098022e-01
    z[6,7,6]  R2303     1.8844233453273773e-01
    z[6,7,6]  R2304     1.1336199194192886e-01
    z[6,7,6]  R2305     -1.3753518462181091e-01
    z[6,7,6]  R2306     2.8746657073497772e-02
    z[6,7,6]  R2307     3.0018597841262817e-01
    z[6,7,6]  R2308     -3.2065957784652710e-01
    z[6,7,6]  R2309     3.5046026110649109e-01
    z[6,7,6]  R2310     1.7457805573940277e-01
    z[6,7,6]  R2311     6.3427664339542389e-02
    z[6,7,6]  R2312     -1.4630000293254852e-01
    z[6,7,6]  R2313     -3.6590874195098877e-01
    z[6,7,6]  R2314     2.3407968692481518e-03
    z[6,7,6]  R2315     1.4083732664585114e-01
    z[6,7,6]  R2316     -4.5543056726455688e-01
    z[6,7,6]  R2317     3.6189281940460205e-01
    z[6,7,6]  R2318     5.9667207300662994e-02
    z[6,7,6]  R2319     3.9056394249200821e-02
    z[6,7,6]  R2320     -3.5774940252304077e-01
    z[6,7,6]  R2321     6.4626209437847137e-02
    z[6,7,6]  R2322     -5.1362957805395126e-02
    z[6,7,6]  R2323     -8.9024573564529419e-02
    z[6,7,6]  R2324     -3.5536146163940430e-01
    z[6,7,6]  R2325     -2.2796842455863953e-01
    z[6,7,6]  R2326     -2.1361030638217926e-01
    z[6,7,6]  R2327     1.4386756718158722e-01
    z[6,7,6]  R2328     -2.4325957521796227e-02
    z[6,7,6]  R2329     -2.0830747485160828e-01
    z[6,7,6]  R2330     -4.2313057184219360e-01
    z[6,7,6]  R2331     2.8809100389480591e-01
    z[6,7,6]  R2332     -2.6862871646881104e-01
    z[6,7,6]  R2333     -1.3921138644218445e-01
    z[6,7,6]  R2334     -2.2763611376285553e-01
    z[6,7,6]  R2335     -1.7594610154628754e-01
    z[6,7,6]  R2336     -3.2816660404205322e-01
    z[6,7,6]  R2337     1.3124649226665497e-01
    z[6,7,6]  R2338     -2.2728709876537323e-01
    z[6,7,6]  R2339     -8.9128427207469940e-02
    z[6,7,6]  R2340     -1.5429088473320007e-01
    z[6,7,6]  R2341     -1.7627786099910736e-01
    z[6,7,6]  R2342     -3.0590042471885681e-01
    z[6,7,6]  R2343     1.0293000936508179e-01
    z[6,7,6]  R2344     2.2025278210639954e-01
    z[6,7,6]  R2345     2.3513735830783844e-01
    z[6,7,6]  R2346     4.3343797326087952e-02
    z[6,7,6]  R2347     -5.9962904453277588e-01
    z[6,7,6]  R2348     1.0144189745187759e-01
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R2349     -1
    z[7,6,0]  R2350     1
    z[7,6,0]  R2363     -3.9254170656204224e-01
    z[7,6,0]  R2364     -2.3913398385047913e-01
    z[7,6,0]  R2365     -4.2164230346679688e-01
    z[7,6,0]  R2366     -4.6761247515678406e-01
    z[7,6,0]  R2367     -6.8008285760879517e-01
    z[7,6,0]  R2368     -6.4544725418090820e-01
    z[7,6,0]  R2369     -9.2244094610214233e-01
    z[7,6,0]  R2370     -4.7562113404273987e-01
    z[7,6,0]  R2371     -5.7857674360275269e-01
    z[7,6,0]  R2372     -0.748253583908081
    z[7,6,0]  R2373     5.2099150419235229e-01
    z[7,6,0]  R2374     5.5208230018615723e-01
    z[7,6,0]  R2375     4.7966101765632629e-01
    z[7,6,0]  R2376     5.6979340314865112e-01
    z[7,6,0]  R2377     0.41551673412323
    z[7,6,0]  R2378     3.0027130246162415e-01
    z[7,6,0]  R2379     5.6916791200637817e-01
    z[7,6,0]  R2380     3.7578943371772766e-01
    z[7,6,0]  R2381     2.2402296960353851e-01
    z[7,6,0]  R2382     3.7969928979873657e-01
    z[7,6,0]  R2383     2.6223802566528320e-01
    z[7,6,0]  R2384     3.6775204539299011e-01
    z[7,6,0]  R2385     -2.1203437820076942e-02
    z[7,6,0]  R2386     -1.3206343166530132e-02
    z[7,6,0]  R2387     2.8164750337600708e-01
    z[7,6,0]  R2388     -8.9676812291145325e-02
    z[7,6,0]  R2389     6.2856757640838623e-01
    z[7,6,0]  R2390     3.4075993299484253e-01
    z[7,6,0]  R2391     -1.3045547902584076e-01
    z[7,6,0]  R2392     -3.4689339995384216e-01
    z[7,6,0]  R2393     3.5286378860473633e-01
    z[7,6,0]  R2394     3.8080233335494995e-01
    z[7,6,0]  R2395     -0.586037814617157
    z[7,6,0]  R2396     -0.0869353786110878
    z[7,6,0]  R2397     -7.7154916524887085e-01
    z[7,6,0]  R2398     5.7940429449081421e-01
    z[7,6,0]  R2399     -6.0262113809585571e-01
    z[7,6,0]  R2400     -9.5427431166172028e-02
    z[7,6,0]  R2401     -3.0859872698783875e-01
    z[7,6,0]  R2402     -5.2074217796325684e-01
    z[7,6,0]  R2403     -9.4161635637283325e-01
    z[7,6,0]  R2404     -8.1056392192840576e-01
    z[7,6,0]  R2405     3.9836764335632324e-01
    z[7,6,0]  R2406     7.0478290319442749e-02
    z[7,6,0]  R2407     -5.9895825386047363e-01
    z[7,6,0]  R2408     2.6351484656333923e-01
    z[7,6,0]  R2409     -1.5788662433624268e-01
    z[7,6,0]  R2410     -6.1514323949813843e-01
    z[7,6,0]  R2411     -3.8206470012664795e-01
    z[7,6,0]  R2412     -1.1098635941743851e-01
    z[7,6,0]  R2413     -6.7380934953689575e-01
    z[7,6,0]  R2414     0.543727457523346
    z[7,6,0]  R2415     -7.9898262023925781e-01
    z[7,6,0]  R2416     7.9587094485759735e-02
    z[7,6,0]  R2417     -5.8735519647598267e-01
    z[7,6,0]  R2418     -1.9871200621128082e-01
    z[7,6,0]  R2419     -5.9651982784271240e-01
    z[7,6,0]  R2420     1.5138798952102661e-01
    z[7,6,0]  R2421     -1.5813054144382477e-01
    z[7,6,0]  R2422     -4.7670900821685791e-01
    z[7,6,0]  R2423     3.3887746930122375e-01
    z[7,6,0]  R2424     -8.8683640956878662e-01
    z[7,6,0]  R2425     3.9698880910873413e-01
    z[7,6,0]  R2426     -5.4121297597885132e-01
    z[7,6,0]  R2427     2.5448048114776611e-01
    z[7,6,0]  R2428     1.7015197873115540e-01
    z[7,6,0]  R2429     -3.7779429554939270e-01
    z[7,6,0]  R2430     -4.4674339890480042e-01
    z[7,6,0]  R2431     -3.5545790195465088e-01
    z[7,6,0]  R2432     6.5151005983352661e-01
    z[7,6,0]  R2433     -6.8009203672409058e-01
    z[7,6,0]  R2434     3.2066974788904190e-02
    z[7,6,0]  R2435     -7.2874939441680908e-01
    z[7,6,0]  R2436     -5.9182637929916382e-01
    z[7,6,0]  R2437     -2.6132553815841675e-01
    z[7,6,0]  R2438     2.8182464838027954e-01
    z[7,6,0]  R2439     2.1349306404590607e-01
    z[7,6,0]  R2440     -9.1540098190307617e-02
    z[7,6,0]  R2441     -5.4024338722229004e-02
    z[7,6,0]  R2442     3.6885675042867661e-02
    z[7,6,0]  R2443     -8.9066106081008911e-01
    z[7,6,0]  R2444     4.4937521219253540e-01
    z[7,6,0]  R2445     0.754943311214447
    z[7,6,0]  R2446     -5.8507156372070312e-01
    z[7,6,0]  R2447     2.8378924727439880e-01
    z[7,6,0]  R2448     7.8624807298183441e-02
    z[7,6,0]  R2449     1.2666773796081543e-01
    z[7,6,0]  R2450     9.6525497734546661e-02
    z[7,6,0]  R2451     -1.7874591052532196e-01
    z[7,6,0]  R2452     -1.5020088851451874e-01
    z[7,6,0]  R2453     -8.1584942340850830e-01
    z[7,6,0]  R2454     -8.3547770977020264e-01
    z[7,6,0]  R2455     -7.3414427042007446e-01
    z[7,6,0]  R2456     -7.2544336318969727e-01
    z[7,6,0]  R2457     -4.9633827805519104e-01
    z[7,6,0]  R2458     -6.7537021636962891e-01
    z[7,6,0]  R2459     -7.6199799776077271e-01
    z[7,6,0]  R2460     -4.8303210735321045e-01
    z[7,6,0]  R2461     -8.3185464143753052e-01
    z[7,6,0]  R2462     -4.0691459178924561e-01
    z[7,6,0]  R2463     4.9099221825599670e-01
    z[7,6,0]  R2464     9.3766905367374420e-02
    z[7,6,0]  R2465     5.0753045082092285e-01
    z[7,6,0]  R2466     4.2190632224082947e-01
    z[7,6,0]  R2467     4.9894136190414429e-01
    z[7,6,0]  R2468     5.4266828298568726e-01
    z[7,6,0]  R2469     2.8890156745910645e-01
    z[7,6,0]  R2470     3.7113168835639954e-01
    z[7,6,0]  R2471     5.5590659379959106e-01
    z[7,6,0]  R2472     6.8955369293689728e-02
    z[7,6,0]  R2473     8.2336896657943726e-01
    z[7,6,0]  R2474     0.833395779132843
    z[7,6,0]  R2475     7.7884292602539062e-01
    z[7,6,0]  R2476     7.2519683837890625e-01
    z[7,6,0]  R2477     9.1842484474182129e-01
    z[7,6,0]  R2478     0.709715723991394
    z[7,6,0]  R2479     7.4419897794723511e-01
    z[7,6,0]  R2480     8.4135973453521729e-01
    z[7,6,0]  R2481     0.773284912109375
    z[7,6,0]  R2482     7.9004669189453125e-01
    z[7,6,0]  R2483     8.4471255540847778e-01
    z[7,6,0]  R2484     7.1160227060317993e-01
    z[7,6,0]  R2485     7.2750610113143921e-01
    z[7,6,0]  R2486     -6.0652363300323486e-01
    z[7,6,0]  R2487     3.0945724248886108e-01
    z[7,6,0]  R2488     -6.7812144756317139e-02
    z[7,6,0]  R2489     -1.1857558786869049e-01
    z[7,6,0]  R2490     -4.5286703854799271e-02
    z[7,6,0]  R2491     -3.7151089310646057e-01
    z[7,6,0]  R2492     -8.5053868591785431e-02
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R2351     -1
    z[7,6,1]  R2352     1
    z[7,6,1]  R2363     8.6168175935745239e-01
    z[7,6,1]  R2364     9.5194482803344727e-01
    z[7,6,1]  R2365     8.3967870473861694e-01
    z[7,6,1]  R2366     7.5791954994201660e-01
    z[7,6,1]  R2367     6.5164351463317871e-01
    z[7,6,1]  R2368     0.60193932056427
    z[7,6,1]  R2369     1.8296839296817780e-01
    z[7,6,1]  R2370     7.0275247097015381e-01
    z[7,6,1]  R2371     6.4181548357009888e-01
    z[7,6,1]  R2372     6.2443137168884277e-01
    z[7,6,1]  R2373     -0.166351318359375
    z[7,6,1]  R2374     1.9614227116107941e-01
    z[7,6,1]  R2375     1.2256369739770889e-01
    z[7,6,1]  R2376     -6.2041327357292175e-02
    z[7,6,1]  R2377     -3.0906911939382553e-02
    z[7,6,1]  R2378     1.1112090200185776e-01
    z[7,6,1]  R2379     -3.3025091886520386e-01
    z[7,6,1]  R2380     -2.3501524329185486e-01
    z[7,6,1]  R2381     -8.1570070981979370e-01
    z[7,6,1]  R2382     -1.1152768507599831e-02
    z[7,6,1]  R2383     4.8224860429763794e-01
    z[7,6,1]  R2384     2.8804332017898560e-01
    z[7,6,1]  R2385     -0.904996395111084
    z[7,6,1]  R2386     -8.0651009082794189e-01
    z[7,6,1]  R2387     -7.4384588003158569e-01
    z[7,6,1]  R2388     -6.9912791252136230e-01
    z[7,6,1]  R2389     -7.4209755659103394e-01
    z[7,6,1]  R2390     -7.4391418695449829e-01
    z[7,6,1]  R2391     -8.3136105537414551e-01
    z[7,6,1]  R2392     -7.9074168205261230e-01
    z[7,6,1]  R2393     3.5440880060195923e-01
    z[7,6,1]  R2394     -1.8497738242149353e-01
    z[7,6,1]  R2395     3.6687543988227844e-01
    z[7,6,1]  R2396     -8.6033952236175537e-01
    z[7,6,1]  R2397     -0.104481041431427
    z[7,6,1]  R2398     5.4912644624710083e-01
    z[7,6,1]  R2399     -2.0457734167575836e-01
    z[7,6,1]  R2400     -8.8429284095764160e-01
    z[7,6,1]  R2401     -7.8451168537139893e-01
    z[7,6,1]  R2402     -0.317264199256897
    z[7,6,1]  R2403     0.0891835018992424
    z[7,6,1]  R2404     3.3691781759262085e-01
    z[7,6,1]  R2405     4.4969987869262695e-01
    z[7,6,1]  R2406     2.7287730574607849e-01
    z[7,6,1]  R2407     1.3377930968999863e-02
    z[7,6,1]  R2408     -9.3052148818969727e-01
    z[7,6,1]  R2409     -8.7759679555892944e-01
    z[7,6,1]  R2410     9.5067918300628662e-02
    z[7,6,1]  R2411     4.3363296985626221e-01
    z[7,6,1]  R2412     -8.2585883140563965e-01
    z[7,6,1]  R2413     2.8689932823181152e-01
    z[7,6,1]  R2414     5.7964378595352173e-01
    z[7,6,1]  R2415     3.8527809083461761e-02
    z[7,6,1]  R2416     -2.5478392839431763e-01
    z[7,6,1]  R2417     0.0353827103972435
    z[7,6,1]  R2418     -9.1124457120895386e-01
    z[7,6,1]  R2419     -0.662040114402771
    z[7,6,1]  R2420     -7.8357911109924316e-01
    z[7,6,1]  R2421     -7.6083678007125854e-01
    z[7,6,1]  R2422     -4.1661381721496582e-01
    z[7,6,1]  R2423     -1.3202227652072906e-02
    z[7,6,1]  R2424     2.2526440024375916e-01
    z[7,6,1]  R2425     -4.9321573227643967e-02
    z[7,6,1]  R2426     3.2392221689224243e-01
    z[7,6,1]  R2427     -8.1055295467376709e-01
    z[7,6,1]  R2428     -7.8756111860275269e-01
    z[7,6,1]  R2429     -7.8263121843338013e-01
    z[7,6,1]  R2430     -7.6649588346481323e-01
    z[7,6,1]  R2431     -3.5260787606239319e-01
    z[7,6,1]  R2432     6.2596333026885986e-01
    z[7,6,1]  R2433     3.2141822576522827e-01
    z[7,6,1]  R2434     3.8521626591682434e-01
    z[7,6,1]  R2435     -5.0963733345270157e-02
    z[7,6,1]  R2436     -2.4608006700873375e-02
    z[7,6,1]  R2437     -8.7529158592224121e-01
    z[7,6,1]  R2438     -8.6956137418746948e-01
    z[7,6,1]  R2439     -8.2586467266082764e-01
    z[7,6,1]  R2440     -8.3300560712814331e-01
    z[7,6,1]  R2441     -9.1836810111999512e-01
    z[7,6,1]  R2442     5.6905514001846313e-01
    z[7,6,1]  R2443     3.3987060189247131e-01
    z[7,6,1]  R2444     5.3938800096511841e-01
    z[7,6,1]  R2445     1.8245634436607361e-01
    z[7,6,1]  R2446     -5.8379560708999634e-01
    z[7,6,1]  R2447     -0.758469820022583
    z[7,6,1]  R2448     0.500398576259613
    z[7,6,1]  R2449     -4.0672817826271057e-01
    z[7,6,1]  R2450     -2.7699694037437439e-01
    z[7,6,1]  R2451     -1.3899168372154236e-01
    z[7,6,1]  R2452     -2.8170236945152283e-01
    z[7,6,1]  R2453     -1.8467040359973907e-01
    z[7,6,1]  R2454     -1.3740491867065430e-01
    z[7,6,1]  R2455     -0.263480544090271
    z[7,6,1]  R2456     -1.7347732186317444e-01
    z[7,6,1]  R2457     -0.11562529951334
    z[7,6,1]  R2458     1.0543778538703918e-01
    z[7,6,1]  R2459     1.0626516491174698e-01
    z[7,6,1]  R2460     2.3209260404109955e-01
    z[7,6,1]  R2461     -1.7743978649377823e-02
    z[7,6,1]  R2462     -7.4440743774175644e-03
    z[7,6,1]  R2463     -6.4555935561656952e-02
    z[7,6,1]  R2464     0.802198052406311
    z[7,6,1]  R2465     -2.0031096041202545e-01
    z[7,6,1]  R2466     -4.7008499503135681e-01
    z[7,6,1]  R2467     1.9505453109741211e-01
    z[7,6,1]  R2468     2.5065168738365173e-01
    z[7,6,1]  R2469     3.4602823853492737e-01
    z[7,6,1]  R2470     1.4450013637542725e-01
    z[7,6,1]  R2471     -3.8335135579109192e-01
    z[7,6,1]  R2472     9.0766036510467529e-01
    z[7,6,1]  R2473     -1.2319023162126541e-01
    z[7,6,1]  R2474     1.5052442252635956e-01
    z[7,6,1]  R2475     -5.3521089255809784e-02
    z[7,6,1]  R2476     -3.0439051985740662e-01
    z[7,6,1]  R2477     7.6228104531764984e-02
    z[7,6,1]  R2478     -4.0170428156852722e-01
    z[7,6,1]  R2479     -0.518860399723053
    z[7,6,1]  R2480     0.0714452788233757
    z[7,6,1]  R2481     1.4823582768440247e-01
    z[7,6,1]  R2482     1.9825264811515808e-01
    z[7,6,1]  R2483     -1.4329980313777924e-01
    z[7,6,1]  R2484     -2.7208226919174194e-01
    z[7,6,1]  R2485     -3.5209563374519348e-01
    z[7,6,1]  R2486     5.8529919385910034e-01
    z[7,6,1]  R2487     4.4666466116905212e-01
    z[7,6,1]  R2488     7.4827569723129272e-01
    z[7,6,1]  R2489     4.2190197110176086e-01
    z[7,6,1]  R2490     4.2537638545036316e-01
    z[7,6,1]  R2491     1.8803621828556061e-01
    z[7,6,1]  R2492     2.5354531407356262e-01
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R2353     -1
    z[7,6,2]  R2354     1
    z[7,6,2]  R2363     -4.6933200210332870e-02
    z[7,6,2]  R2364     -1.1756887659430504e-02
    z[7,6,2]  R2365     0.148001566529274
    z[7,6,2]  R2366     1.7065636813640594e-01
    z[7,6,2]  R2367     -1.1008264124393463e-01
    z[7,6,2]  R2368     1.7419527471065521e-01
    z[7,6,2]  R2369     2.6829114556312561e-01
    z[7,6,2]  R2370     3.6461880803108215e-01
    z[7,6,2]  R2371     1.4063043892383575e-01
    z[7,6,2]  R2372     -0.0342351458966732
    z[7,6,2]  R2373     2.0866812765598297e-01
    z[7,6,2]  R2374     3.6729472875595093e-01
    z[7,6,2]  R2375     3.6069635301828384e-02
    z[7,6,2]  R2376     -5.5398438125848770e-02
    z[7,6,2]  R2377     3.2442143559455872e-01
    z[7,6,2]  R2378     5.2716922014951706e-02
    z[7,6,2]  R2379     -1.0509991645812988e-01
    z[7,6,2]  R2380     1.1707766354084015e-01
    z[7,6,2]  R2381     -4.1049256920814514e-01
    z[7,6,2]  R2382     -3.7668108940124512e-02
    z[7,6,2]  R2383     -3.5654169321060181e-01
    z[7,6,2]  R2384     -0.135230153799057
    z[7,6,2]  R2385     1.7250137403607368e-02
    z[7,6,2]  R2386     -1.4609888195991516e-01
    z[7,6,2]  R2387     -6.6297873854637146e-02
    z[7,6,2]  R2388     2.2318531572818756e-01
    z[7,6,2]  R2389     3.1908690929412842e-02
    z[7,6,2]  R2390     7.6484262943267822e-02
    z[7,6,2]  R2391     6.1499748378992081e-02
    z[7,6,2]  R2392     2.4359221756458282e-01
    z[7,6,2]  R2393     1.7425008118152618e-01
    z[7,6,2]  R2394     -1.3354432582855225e-01
    z[7,6,2]  R2395     -1.3887584209442139e-01
    z[7,6,2]  R2396     -3.9314043521881104e-01
    z[7,6,2]  R2397     1.2395108491182327e-01
    z[7,6,2]  R2398     1.6706761717796326e-01
    z[7,6,2]  R2399     4.9057373404502869e-01
    z[7,6,2]  R2400     2.4277816712856293e-01
    z[7,6,2]  R2401     -1.8345075845718384e-01
    z[7,6,2]  R2402     5.1877623796463013e-01
    z[7,6,2]  R2403     0.0737726092338562
    z[7,6,2]  R2404     4.3167144060134888e-02
    z[7,6,2]  R2405     6.4395293593406677e-02
    z[7,6,2]  R2406     2.7652397751808167e-01
    z[7,6,2]  R2407     6.4655095338821411e-01
    z[7,6,2]  R2408     1.6862362623214722e-01
    z[7,6,2]  R2409     -2.0928969606757164e-02
    z[7,6,2]  R2410     1.7930777370929718e-01
    z[7,6,2]  R2411     3.1241157650947571e-01
    z[7,6,2]  R2412     -1.7183783650398254e-01
    z[7,6,2]  R2413     3.9254274964332581e-01
    z[7,6,2]  R2414     2.8326365351676941e-01
    z[7,6,2]  R2415     4.5729362964630127e-01
    z[7,6,2]  R2416     1.0710256546735764e-01
    z[7,6,2]  R2417     2.5877770781517029e-01
    z[7,6,2]  R2418     2.4274586141109467e-01
    z[7,6,2]  R2419     4.1924878954887390e-01
    z[7,6,2]  R2420     -3.1090310215950012e-01
    z[7,6,2]  R2421     4.1387838125228882e-01
    z[7,6,2]  R2422     2.2290448844432831e-01
    z[7,6,2]  R2423     1.3754753768444061e-01
    z[7,6,2]  R2424     -2.9798170551657677e-02
    z[7,6,2]  R2425     -2.5615268945693970e-01
    z[7,6,2]  R2426     3.2194903492927551e-01
    z[7,6,2]  R2427     -0.251189261674881
    z[7,6,2]  R2428     -1.7484319210052490e-01
    z[7,6,2]  R2429     -1.2572652101516724e-01
    z[7,6,2]  R2430     1.7241321504116058e-02
    z[7,6,2]  R2431     7.6796674728393555e-01
    z[7,6,2]  R2432     -7.9537652432918549e-02
    z[7,6,2]  R2433     3.1214842200279236e-01
    z[7,6,2]  R2434     -4.9438709020614624e-01
    z[7,6,2]  R2435     0.512950599193573
    z[7,6,2]  R2436     3.3939656615257263e-01
    z[7,6,2]  R2437     6.9249749183654785e-02
    z[7,6,2]  R2438     -2.1348603069782257e-01
    z[7,6,2]  R2439     -0.0791369378566742
    z[7,6,2]  R2440     2.7444148436188698e-02
    z[7,6,2]  R2441     -2.9958806931972504e-02
    z[7,6,2]  R2442     -6.3811767101287842e-01
    z[7,6,2]  R2443     2.1972709894180298e-01
    z[7,6,2]  R2444     2.5459833443164825e-02
    z[7,6,2]  R2445     5.6263640522956848e-02
    z[7,6,2]  R2446     3.9968156814575195e-01
    z[7,6,2]  R2447     -1.6684535145759583e-01
    z[7,6,2]  R2448     -6.5829616785049438e-01
    z[7,6,2]  R2449     -4.8338127136230469e-01
    z[7,6,2]  R2450     -6.8979966640472412e-01
    z[7,6,2]  R2451     5.9844231605529785e-01
    z[7,6,2]  R2452     -6.1854153871536255e-01
    z[7,6,2]  R2453     2.8686735033988953e-01
    z[7,6,2]  R2454     4.7996678948402405e-01
    z[7,6,2]  R2455     3.2032766938209534e-01
    z[7,6,2]  R2456     0.468130499124527
    z[7,6,2]  R2457     8.5109126567840576e-01
    z[7,6,2]  R2458     5.6741166114807129e-01
    z[7,6,2]  R2459     5.0181424617767334e-01
    z[7,6,2]  R2460     6.3314098119735718e-01
    z[7,6,2]  R2461     -4.0242251753807068e-01
    z[7,6,2]  R2462     6.1131817102432251e-01
    z[7,6,2]  R2463     2.3638445138931274e-01
    z[7,6,2]  R2464     -2.1357320249080658e-02
    z[7,6,2]  R2465     1.7076766490936279e-01
    z[7,6,2]  R2466     3.5945731401443481e-01
    z[7,6,2]  R2467     3.8796633481979370e-01
    z[7,6,2]  R2468     3.3352798223495483e-01
    z[7,6,2]  R2469     -7.1650457382202148e-01
    z[7,6,2]  R2470     -7.4348253011703491e-01
    z[7,6,2]  R2471     -4.6164166927337646e-01
    z[7,6,2]  R2472     9.9883466958999634e-02
    z[7,6,2]  R2473     -2.6978502050042152e-02
    z[7,6,2]  R2474     3.1799456477165222e-01
    z[7,6,2]  R2475     5.3231620788574219e-01
    z[7,6,2]  R2476     4.8598667979240417e-01
    z[7,6,2]  R2477     2.3269085586071014e-01
    z[7,6,2]  R2478     3.8618156313896179e-01
    z[7,6,2]  R2479     1.1577173322439194e-01
    z[7,6,2]  R2480     -2.1999187767505646e-01
    z[7,6,2]  R2481     3.9089924097061157e-01
    z[7,6,2]  R2482     3.9018783718347549e-02
    z[7,6,2]  R2483     -3.4256213903427124e-01
    z[7,6,2]  R2484     8.4643848240375519e-02
    z[7,6,2]  R2485     -0.0328790545463562
    z[7,6,2]  R2486     -3.7224420905113220e-01
    z[7,6,2]  R2487     0.0223090797662735
    z[7,6,2]  R2488     7.9673487925902009e-04
    z[7,6,2]  R2489     -1.5540605783462524e-01
    z[7,6,2]  R2490     2.8781020641326904e-01
    z[7,6,2]  R2491     -6.6818159818649292e-01
    z[7,6,2]  R2492     3.0707883834838867e-01
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R2355     -1
    z[7,6,3]  R2356     1
    z[7,6,3]  R2363     2.5789457559585571e-01
    z[7,6,3]  R2364     7.6679818332195282e-02
    z[7,6,3]  R2365     7.4222676455974579e-02
    z[7,6,3]  R2366     6.7925274372100830e-02
    z[7,6,3]  R2367     4.2619869112968445e-02
    z[7,6,3]  R2368     1.5018087625503540e-01
    z[7,6,3]  R2369     -2.2287322208285332e-02
    z[7,6,3]  R2370     1.7334936559200287e-01
    z[7,6,3]  R2371     1.5530005097389221e-01
    z[7,6,3]  R2372     0.0453343540430069
    z[7,6,3]  R2373     6.0690528154373169e-01
    z[7,6,3]  R2374     5.7045966386795044e-01
    z[7,6,3]  R2375     5.9706658124923706e-01
    z[7,6,3]  R2376     6.5926498174667358e-01
    z[7,6,3]  R2377     5.5603188276290894e-01
    z[7,6,3]  R2378     5.6152331829071045e-01
    z[7,6,3]  R2379     6.3624918460845947e-01
    z[7,6,3]  R2380     4.3104144930839539e-01
    z[7,6,3]  R2381     -1.4310272037982941e-01
    z[7,6,3]  R2382     3.2803124189376831e-01
    z[7,6,3]  R2383     6.1675232648849487e-01
    z[7,6,3]  R2384     4.8381385207176208e-01
    z[7,6,3]  R2385     1.1437595635652542e-01
    z[7,6,3]  R2386     4.5385140925645828e-02
    z[7,6,3]  R2387     -4.7429639101028442e-01
    z[7,6,3]  R2388     -1.3199462555348873e-02
    z[7,6,3]  R2389     2.3878661915659904e-02
    z[7,6,3]  R2390     -1.5798424184322357e-01
    z[7,6,3]  R2391     -1.9470445811748505e-01
    z[7,6,3]  R2392     2.4173672497272491e-01
    z[7,6,3]  R2393     6.5899646282196045e-01
    z[7,6,3]  R2394     7.6095026731491089e-01
    z[7,6,3]  R2395     -7.1903415024280548e-02
    z[7,6,3]  R2396     7.1365468204021454e-02
    z[7,6,3]  R2397     -2.8981423377990723e-01
    z[7,6,3]  R2398     3.6298626661300659e-01
    z[7,6,3]  R2399     1.3017773628234863e-01
    z[7,6,3]  R2400     -1.4988839626312256e-01
    z[7,6,3]  R2401     -3.9614096283912659e-01
    z[7,6,3]  R2402     -3.0419471859931946e-01
    z[7,6,3]  R2403     -2.1315976977348328e-01
    z[7,6,3]  R2404     -2.4674201011657715e-01
    z[7,6,3]  R2405     6.0045200586318970e-01
    z[7,6,3]  R2406     0.831079363822937
    z[7,6,3]  R2407     2.4031335115432739e-01
    z[7,6,3]  R2408     1.3446410000324249e-01
    z[7,6,3]  R2409     1.8834297358989716e-01
    z[7,6,3]  R2410     -4.5580846071243286e-01
    z[7,6,3]  R2411     -4.4311785697937012e-01
    z[7,6,3]  R2412     3.0654057860374451e-01
    z[7,6,3]  R2413     -3.5950881242752075e-01
    z[7,6,3]  R2414     4.5377832651138306e-01
    z[7,6,3]  R2415     1.6288067400455475e-01
    z[7,6,3]  R2416     7.8887414932250977e-01
    z[7,6,3]  R2417     6.0306102037429810e-01
    z[7,6,3]  R2418     2.2944065928459167e-01
    z[7,6,3]  R2419     1.3756365515291691e-02
    z[7,6,3]  R2420     1.4490705728530884e-01
    z[7,6,3]  R2421     9.3097344040870667e-02
    z[7,6,3]  R2422     -8.0060526728630066e-02
    z[7,6,3]  R2423     7.7907508611679077e-01
    z[7,6,3]  R2424     7.3133997619152069e-02
    z[7,6,3]  R2425     7.1731686592102051e-01
    z[7,6,3]  R2426     -1.1281068623065948e-01
    z[7,6,3]  R2427     4.0450257062911987e-01
    z[7,6,3]  R2428     0.00385760678909719
    z[7,6,3]  R2429     -8.1982992589473724e-02
    z[7,6,3]  R2430     1.7649991810321808e-01
    z[7,6,3]  R2431     -2.6585987210273743e-01
    z[7,6,3]  R2432     -2.9219236969947815e-01
    z[7,6,3]  R2433     4.7909659147262573e-01
    z[7,6,3]  R2434     6.0675078630447388e-01
    z[7,6,3]  R2435     7.6968587934970856e-02
    z[7,6,3]  R2436     5.7475709915161133e-01
    z[7,6,3]  R2437     -1.0565434396266937e-01
    z[7,6,3]  R2438     -7.3891326785087585e-02
    z[7,6,3]  R2439     4.7077399492263794e-01
    z[7,6,3]  R2440     3.1705811619758606e-01
    z[7,6,3]  R2441     -3.5898125171661377e-01
    z[7,6,3]  R2442     -4.4451120495796204e-01
    z[7,6,3]  R2443     1.5172217041254044e-02
    z[7,6,3]  R2444     6.6756260395050049e-01
    z[7,6,3]  R2445     4.9172133207321167e-01
    z[7,6,3]  R2446     1.4260038733482361e-01
    z[7,6,3]  R2447     -4.7486531734466553e-01
    z[7,6,3]  R2448     -3.3216324448585510e-01
    z[7,6,3]  R2449     -2.8205469250679016e-01
    z[7,6,3]  R2450     -5.6749057024717331e-02
    z[7,6,3]  R2451     -1.0599813610315323e-01
    z[7,6,3]  R2452     -1.9939118623733521e-01
    z[7,6,3]  R2453     -0.258035808801651
    z[7,6,3]  R2454     1.2278497964143753e-01
    z[7,6,3]  R2455     1.5831816196441650e-01
    z[7,6,3]  R2456     -8.6031429469585419e-02
    z[7,6,3]  R2457     1.6550848260521889e-02
    z[7,6,3]  R2458     3.3472830057144165e-01
    z[7,6,3]  R2459     -1.8150122463703156e-01
    z[7,6,3]  R2460     4.3236851692199707e-02
    z[7,6,3]  R2461     2.4676360189914703e-01
    z[7,6,3]  R2462     2.7102762460708618e-01
    z[7,6,3]  R2463     8.2595801353454590e-01
    z[7,6,3]  R2464     5.1190227270126343e-01
    z[7,6,3]  R2465     -4.7305294871330261e-01
    z[7,6,3]  R2466     -4.7772252559661865e-01
    z[7,6,3]  R2467     -2.2916845977306366e-01
    z[7,6,3]  R2468     3.6530005931854248e-01
    z[7,6,3]  R2469     2.2059649229049683e-01
    z[7,6,3]  R2470     0.436553955078125
    z[7,6,3]  R2471     2.1341089904308319e-01
    z[7,6,3]  R2472     8.2821629941463470e-02
    z[7,6,3]  R2473     4.1775268316268921e-01
    z[7,6,3]  R2474     1.7087125778198242e-01
    z[7,6,3]  R2475     6.1872269958257675e-02
    z[7,6,3]  R2476     -2.9044350981712341e-01
    z[7,6,3]  R2477     2.3048759996891022e-01
    z[7,6,3]  R2478     1.4789731800556183e-01
    z[7,6,3]  R2479     2.0402505993843079e-02
    z[7,6,3]  R2480     4.0229588747024536e-01
    z[7,6,3]  R2481     5.2630184218287468e-03
    z[7,6,3]  R2482     8.6509138345718384e-02
    z[7,6,3]  R2483     -2.4839197099208832e-01
    z[7,6,3]  R2484     -4.9620926380157471e-01
    z[7,6,3]  R2485     -2.7569499611854553e-01
    z[7,6,3]  R2486     -1.9026175141334534e-02
    z[7,6,3]  R2487     5.1256150007247925e-01
    z[7,6,3]  R2488     3.8620454072952271e-01
    z[7,6,3]  R2489     7.3760688304901123e-01
    z[7,6,3]  R2490     5.5118137598037720e-01
    z[7,6,3]  R2491     -5.6256562471389771e-01
    z[7,6,3]  R2492     4.1415810585021973e-01
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R2357     -1
    z[7,6,4]  R2358     1
    z[7,6,4]  R2363     -1.1496312171220779e-01
    z[7,6,4]  R2364     6.1036888509988785e-02
    z[7,6,4]  R2365     1.1571945995092392e-01
    z[7,6,4]  R2366     -3.8888859748840332e-01
    z[7,6,4]  R2367     -1.1638686805963516e-01
    z[7,6,4]  R2368     -2.9812756180763245e-01
    z[7,6,4]  R2369     -1.9319224357604980e-01
    z[7,6,4]  R2370     1.6015812754631042e-01
    z[7,6,4]  R2371     4.2423516511917114e-01
    z[7,6,4]  R2372     -1.7063283594325185e-03
    z[7,6,4]  R2373     -3.7976670265197754e-01
    z[7,6,4]  R2374     -5.4631937295198441e-02
    z[7,6,4]  R2375     -4.7857353091239929e-01
    z[7,6,4]  R2376     1.5906213223934174e-01
    z[7,6,4]  R2377     1.1276460252702236e-02
    z[7,6,4]  R2378     5.0584155321121216e-01
    z[7,6,4]  R2379     2.3941858112812042e-01
    z[7,6,4]  R2380     -0.562581479549408
    z[7,6,4]  R2381     8.6790435016155243e-02
    z[7,6,4]  R2382     -1.2445009499788284e-01
    z[7,6,4]  R2383     4.0344062447547913e-01
    z[7,6,4]  R2384     -2.3010616004467010e-01
    z[7,6,4]  R2385     -2.1427439153194427e-01
    z[7,6,4]  R2386     -5.6533205509185791e-01
    z[7,6,4]  R2387     -1.5597687661647797e-01
    z[7,6,4]  R2388     -4.6064171195030212e-01
    z[7,6,4]  R2389     -6.3801310956478119e-02
    z[7,6,4]  R2390     5.2818089723587036e-01
    z[7,6,4]  R2391     4.9443128705024719e-01
    z[7,6,4]  R2392     -2.1657621860504150e-01
    z[7,6,4]  R2393     -1.7721369862556458e-02
    z[7,6,4]  R2394     3.4907300025224686e-02
    z[7,6,4]  R2395     -1.4428691565990448e-01
    z[7,6,4]  R2396     5.3972166031599045e-02
    z[7,6,4]  R2397     3.9959940314292908e-01
    z[7,6,4]  R2398     -4.4225663878023624e-03
    z[7,6,4]  R2399     5.6520360708236694e-01
    z[7,6,4]  R2400     2.9839816689491272e-01
    z[7,6,4]  R2401     -1.2828929722309113e-01
    z[7,6,4]  R2402     2.1192553639411926e-01
    z[7,6,4]  R2403     8.9194908738136292e-02
    z[7,6,4]  R2404     3.6870828270912170e-01
    z[7,6,4]  R2405     -3.1754696369171143e-01
    z[7,6,4]  R2406     2.1599155664443970e-01
    z[7,6,4]  R2407     3.5281282663345337e-01
    z[7,6,4]  R2408     -0.0717427060008049
    z[7,6,4]  R2409     1.4988392591476440e-01
    z[7,6,4]  R2410     1.9288735091686249e-01
    z[7,6,4]  R2411     -3.0036326497793198e-02
    z[7,6,4]  R2412     -2.2175274789333344e-02
    z[7,6,4]  R2413     -5.9873346239328384e-02
    z[7,6,4]  R2414     1.8889187276363373e-01
    z[7,6,4]  R2415     -2.0365279912948608e-01
    z[7,6,4]  R2416     -5.0281536579132080e-01
    z[7,6,4]  R2417     -7.1040540933609009e-02
    z[7,6,4]  R2418     7.4606128036975861e-02
    z[7,6,4]  R2419     2.8247093781828880e-02
    z[7,6,4]  R2420     8.0307433381676674e-04
    z[7,6,4]  R2421     -8.1252768635749817e-02
    z[7,6,4]  R2422     -6.5929013490676880e-01
    z[7,6,4]  R2423     -3.4355142712593079e-01
    z[7,6,4]  R2424     1.5855866670608521e-01
    z[7,6,4]  R2425     4.9937221407890320e-01
    z[7,6,4]  R2426     2.7032768726348877e-01
    z[7,6,4]  R2427     9.5205254852771759e-02
    z[7,6,4]  R2428     2.9664269089698792e-01
    z[7,6,4]  R2429     -3.3074134588241577e-01
    z[7,6,4]  R2430     -3.5192474722862244e-01
    z[7,6,4]  R2431     -2.4802875518798828e-01
    z[7,6,4]  R2432     -1.7932142317295074e-01
    z[7,6,4]  R2433     -1.3013717532157898e-01
    z[7,6,4]  R2434     -2.1842719614505768e-01
    z[7,6,4]  R2435     -3.3131629228591919e-01
    z[7,6,4]  R2436     3.6168730258941650e-01
    z[7,6,4]  R2437     7.0028595626354218e-02
    z[7,6,4]  R2438     3.1607393175363541e-02
    z[7,6,4]  R2439     -3.6443449556827545e-02
    z[7,6,4]  R2440     -7.0717319846153259e-02
    z[7,6,4]  R2441     -8.0152988433837891e-02
    z[7,6,4]  R2442     -9.5381431281566620e-02
    z[7,6,4]  R2443     -8.0028679221868515e-03
    z[7,6,4]  R2444     -4.6683689579367638e-03
    z[7,6,4]  R2445     2.3104159533977509e-01
    z[7,6,4]  R2446     -4.9141305498778820e-04
    z[7,6,4]  R2447     2.8214901685714722e-01
    z[7,6,4]  R2448     1.9687581062316895e-01
    z[7,6,4]  R2449     6.2029594182968140e-01
    z[7,6,4]  R2450     6.0424196720123291e-01
    z[7,6,4]  R2451     -3.1634208559989929e-01
    z[7,6,4]  R2452     6.7752408981323242e-01
    z[7,6,4]  R2453     3.0593115091323853e-01
    z[7,6,4]  R2454     6.5106144174933434e-03
    z[7,6,4]  R2455     -4.5229992270469666e-01
    z[7,6,4]  R2456     -3.1586790084838867e-01
    z[7,6,4]  R2457     0.0892091765999794
    z[7,6,4]  R2458     -2.5338403880596161e-02
    z[7,6,4]  R2459     -8.6166240274906158e-02
    z[7,6,4]  R2460     -4.0733799338340759e-01
    z[7,6,4]  R2461     -1.0798192024230957e-01
    z[7,6,4]  R2462     -3.9711430668830872e-01
    z[7,6,4]  R2463     2.8151612728834152e-02
    z[7,6,4]  R2464     9.6242956817150116e-02
    z[7,6,4]  R2465     0.629560112953186
    z[7,6,4]  R2466     2.3625931143760681e-01
    z[7,6,4]  R2467     -9.6024684607982635e-02
    z[7,6,4]  R2468     5.7412409782409668e-01
    z[7,6,4]  R2469     3.5405838489532471e-01
    z[7,6,4]  R2470     7.6192080974578857e-02
    z[7,6,4]  R2471     -3.4034612774848938e-01
    z[7,6,4]  R2472     1.1436818540096283e-01
    z[7,6,4]  R2473     3.0561983585357666e-01
    z[7,6,4]  R2474     -2.8432181477546692e-01
    z[7,6,4]  R2475     2.3806239664554596e-01
    z[7,6,4]  R2476     -2.4416035413742065e-01
    z[7,6,4]  R2477     5.5884812027215958e-02
    z[7,6,4]  R2478     4.0759924799203873e-02
    z[7,6,4]  R2479     -0.142137348651886
    z[7,6,4]  R2480     -1.2161013484001160e-01
    z[7,6,4]  R2481     2.0110353827476501e-01
    z[7,6,4]  R2482     4.0101557970046997e-01
    z[7,6,4]  R2483     -2.5878927111625671e-01
    z[7,6,4]  R2484     3.3145558834075928e-01
    z[7,6,4]  R2485     -1.4004895463585854e-02
    z[7,6,4]  R2486     8.0085322260856628e-02
    z[7,6,4]  R2487     -1.9381056725978851e-01
    z[7,6,4]  R2488     2.7783846855163574e-01
    z[7,6,4]  R2489     -4.5912593603134155e-02
    z[7,6,4]  R2490     -4.2880815267562866e-01
    z[7,6,4]  R2491     -2.3255331814289093e-01
    z[7,6,4]  R2492     7.3434972763061523e-01
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R2359     -1
    z[7,6,5]  R2360     1
    z[7,6,5]  R2363     0.0596165657043457
    z[7,6,5]  R2364     -1.5421052277088165e-01
    z[7,6,5]  R2365     2.5916749238967896e-01
    z[7,6,5]  R2366     3.5540476441383362e-02
    z[7,6,5]  R2367     2.4593852460384369e-01
    z[7,6,5]  R2368     2.6339060068130493e-01
    z[7,6,5]  R2369     -3.1690327450633049e-03
    z[7,6,5]  R2370     -2.6576307415962219e-01
    z[7,6,5]  R2371     7.5584337115287781e-02
    z[7,6,5]  R2372     -1.3800999522209167e-01
    z[7,6,5]  R2373     -2.3829996585845947e-01
    z[7,6,5]  R2374     -4.3946501612663269e-01
    z[7,6,5]  R2375     -3.5648146271705627e-01
    z[7,6,5]  R2376     -4.4333106279373169e-01
    z[7,6,5]  R2377     -1.6065049916505814e-02
    z[7,6,5]  R2378     1.9907447695732117e-01
    z[7,6,5]  R2379     1.5110961161553860e-02
    z[7,6,5]  R2380     4.7820255160331726e-01
    z[7,6,5]  R2381     3.8310371339321136e-02
    z[7,6,5]  R2382     8.0996805429458618e-01
    z[7,6,5]  R2383     -1.6127489507198334e-01
    z[7,6,5]  R2384     0.690273106098175
    z[7,6,5]  R2385     -3.0313533544540405e-01
    z[7,6,5]  R2386     7.4939350597560406e-03
    z[7,6,5]  R2387     0.0902993455529213
    z[7,6,5]  R2388     -4.8316949605941772e-01
    z[7,6,5]  R2389     1.0509271919727325e-01
    z[7,6,5]  R2390     -1.3863454759120941e-01
    z[7,6,5]  R2391     -5.6824021041393280e-02
    z[7,6,5]  R2392     2.8457471728324890e-01
    z[7,6,5]  R2393     -7.8652210533618927e-02
    z[7,6,5]  R2394     1.3941408693790436e-01
    z[7,6,5]  R2395     -5.6810826063156128e-01
    z[7,6,5]  R2396     2.0864079892635345e-01
    z[7,6,5]  R2397     3.5150960087776184e-01
    z[7,6,5]  R2398     3.6750671267509460e-01
    z[7,6,5]  R2399     8.7569728493690491e-02
    z[7,6,5]  R2400     5.7715136557817459e-02
    z[7,6,5]  R2401     2.7905693650245667e-01
    z[7,6,5]  R2402     -3.2278639078140259e-01
    z[7,6,5]  R2403     2.1576821804046631e-01
    z[7,6,5]  R2404     1.7159767448902130e-01
    z[7,6,5]  R2405     4.1267678141593933e-01
    z[7,6,5]  R2406     -1.2315607070922852e-01
    z[7,6,5]  R2407     -7.2828345000743866e-02
    z[7,6,5]  R2408     1.3304447755217552e-02
    z[7,6,5]  R2409     3.5721620917320251e-01
    z[7,6,5]  R2410     -5.7846039533615112e-01
    z[7,6,5]  R2411     -5.3011399507522583e-01
    z[7,6,5]  R2412     2.8076618909835815e-01
    z[7,6,5]  R2413     -2.3221983015537262e-01
    z[7,6,5]  R2414     1.2673947215080261e-01
    z[7,6,5]  R2415     -2.8106454014778137e-01
    z[7,6,5]  R2416     1.4398138225078583e-01
    z[7,6,5]  R2417     -2.9013365507125854e-01
    z[7,6,5]  R2418     1.1404684931039810e-01
    z[7,6,5]  R2419     -0.0963074192404747
    z[7,6,5]  R2420     -1.9495855271816254e-01
    z[7,6,5]  R2421     2.8034153580665588e-01
    z[7,6,5]  R2422     -0.323823481798172
    z[7,6,5]  R2423     3.7357372045516968e-01
    z[7,6,5]  R2424     -5.8438368141651154e-02
    z[7,6,5]  R2425     -7.9122297465801239e-02
    z[7,6,5]  R2426     -6.4036726951599121e-01
    z[7,6,5]  R2427     -1.8583790957927704e-01
    z[7,6,5]  R2428     -3.2547211647033691e-01
    z[7,6,5]  R2429     -2.4672269821166992e-01
    z[7,6,5]  R2430     -1.0942756384611130e-01
    z[7,6,5]  R2431     8.1528417766094208e-02
    z[7,6,5]  R2432     2.4342155456542969e-01
    z[7,6,5]  R2433     -2.1648842096328735e-01
    z[7,6,5]  R2434     -1.0613638907670975e-01
    z[7,6,5]  R2435     -6.7212902009487152e-02
    z[7,6,5]  R2436     2.4922121316194534e-02
    z[7,6,5]  R2437     -3.5402163863182068e-01
    z[7,6,5]  R2438     -2.4613919854164124e-01
    z[7,6,5]  R2439     -1.1041836440563202e-01
    z[7,6,5]  R2440     -0.289393812417984
    z[7,6,5]  R2441     -1.6315674409270287e-02
    z[7,6,5]  R2442     9.6302941441535950e-02
    z[7,6,5]  R2443     -1.8625985085964203e-01
    z[7,6,5]  R2444     1.9237220287322998e-01
    z[7,6,5]  R2445     -2.5953933596611023e-01
    z[7,6,5]  R2446     2.0789082348346710e-01
    z[7,6,5]  R2447     2.5498500093817711e-02
    z[7,6,5]  R2448     3.3535334467887878e-01
    z[7,6,5]  R2449     -2.5545755028724670e-01
    z[7,6,5]  R2450     -2.6062300801277161e-01
    z[7,6,5]  R2451     -3.4602773189544678e-01
    z[7,6,5]  R2452     8.0022260546684265e-02
    z[7,6,5]  R2453     -1.1195619404315948e-01
    z[7,6,5]  R2454     1.8842902779579163e-01
    z[7,6,5]  R2455     2.4268217384815216e-01
    z[7,6,5]  R2456     -2.8632253408432007e-01
    z[7,6,5]  R2457     -7.0227861404418945e-02
    z[7,6,5]  R2458     -3.1152474880218506e-01
    z[7,6,5]  R2459     1.0080326348543167e-01
    z[7,6,5]  R2460     -1.7867214977741241e-01
    z[7,6,5]  R2461     2.6090887188911438e-01
    z[7,6,5]  R2462     3.1812575459480286e-01
    z[7,6,5]  R2463     3.4749977290630341e-02
    z[7,6,5]  R2464     2.6824250817298889e-01
    z[7,6,5]  R2465     -1.3079972565174103e-01
    z[7,6,5]  R2466     1.5704709291458130e-01
    z[7,6,5]  R2467     -7.0687431097030640e-01
    z[7,6,5]  R2468     -2.5559765100479126e-01
    z[7,6,5]  R2469     2.6255035400390625e-01
    z[7,6,5]  R2470     -1.4988008141517639e-01
    z[7,6,5]  R2471     0.286690354347229
    z[7,6,5]  R2472     2.8930592536926270e-01
    z[7,6,5]  R2473     3.4431774169206619e-02
    z[7,6,5]  R2474     -1.0478625446557999e-01
    z[7,6,5]  R2475     -2.1493105590343475e-01
    z[7,6,5]  R2476     -3.1095145270228386e-02
    z[7,6,5]  R2477     -1.9912435114383698e-01
    z[7,6,5]  R2478     0.402570903301239
    z[7,6,5]  R2479     3.1461000442504883e-01
    z[7,6,5]  R2480     -2.0663768053054810e-01
    z[7,6,5]  R2481     1.7251954972743988e-01
    z[7,6,5]  R2482     -4.0156453847885132e-01
    z[7,6,5]  R2483     1.4101035892963409e-01
    z[7,6,5]  R2484     2.3707848787307739e-01
    z[7,6,5]  R2485     -2.9156050086021423e-01
    z[7,6,5]  R2486     -3.1166058778762817e-01
    z[7,6,5]  R2487     5.4415595531463623e-01
    z[7,6,5]  R2488     -2.9116401076316833e-01
    z[7,6,5]  R2489     -6.4724549651145935e-02
    z[7,6,5]  R2490     2.5215440988540649e-01
    z[7,6,5]  R2491     -3.9865810424089432e-02
    z[7,6,5]  R2492     0.284146785736084
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R2361     -1
    z[7,6,6]  R2362     1
    z[7,6,6]  R2363     -1.3391232490539551e-01
    z[7,6,6]  R2364     -5.5602509528398514e-02
    z[7,6,6]  R2365     9.5840133726596832e-02
    z[7,6,6]  R2366     1.4374126493930817e-01
    z[7,6,6]  R2367     -1.5773972868919373e-01
    z[7,6,6]  R2368     0.0995691567659378
    z[7,6,6]  R2369     -7.6256953179836273e-02
    z[7,6,6]  R2370     1.4368730783462524e-01
    z[7,6,6]  R2371     -1.5407225489616394e-01
    z[7,6,6]  R2372     1.6710811853408813e-01
    z[7,6,6]  R2373     2.9666331410408020e-01
    z[7,6,6]  R2374     1.7016613855957985e-02
    z[7,6,6]  R2375     -2.0249038934707642e-01
    z[7,6,6]  R2376     -1.0928864032030106e-01
    z[7,6,6]  R2377     6.4154869318008423e-01
    z[7,6,6]  R2378     5.3281837701797485e-01
    z[7,6,6]  R2379     3.0589789152145386e-01
    z[7,6,6]  R2380     2.4263255298137665e-01
    z[7,6,6]  R2381     -2.9404631257057190e-01
    z[7,6,6]  R2382     2.7412512898445129e-01
    z[7,6,6]  R2383     4.8868253827095032e-02
    z[7,6,6]  R2384     8.0984615487977862e-04
    z[7,6,6]  R2385     -1.7131294310092926e-01
    z[7,6,6]  R2386     -7.9409822821617126e-02
    z[7,6,6]  R2387     3.2485806941986084e-01
    z[7,6,6]  R2388     8.6883746087551117e-02
    z[7,6,6]  R2389     1.9362498819828033e-01
    z[7,6,6]  R2390     3.8350574672222137e-02
    z[7,6,6]  R2391     -0.0493636429309845
    z[7,6,6]  R2392     9.3438185751438141e-02
    z[7,6,6]  R2393     5.2796018123626709e-01
    z[7,6,6]  R2394     -4.5082005858421326e-01
    z[7,6,6]  R2395     -3.9235156774520874e-01
    z[7,6,6]  R2396     -2.1485263109207153e-01
    z[7,6,6]  R2397     1.0583304613828659e-01
    z[7,6,6]  R2398     2.6076692342758179e-01
    z[7,6,6]  R2399     0.101309634745121
    z[7,6,6]  R2400     1.8745566904544830e-01
    z[7,6,6]  R2401     6.6299118101596832e-02
    z[7,6,6]  R2402     3.4264308214187622e-01
    z[7,6,6]  R2403     3.6983732134103775e-03
    z[7,6,6]  R2404     -3.6549825221300125e-02
    z[7,6,6]  R2405     5.6970596313476562e-02
    z[7,6,6]  R2406     -3.0264276266098022e-01
    z[7,6,6]  R2407     1.8844233453273773e-01
    z[7,6,6]  R2408     1.1336199194192886e-01
    z[7,6,6]  R2409     -1.3753518462181091e-01
    z[7,6,6]  R2410     2.8746657073497772e-02
    z[7,6,6]  R2411     3.0018597841262817e-01
    z[7,6,6]  R2412     -3.2065957784652710e-01
    z[7,6,6]  R2413     3.5046026110649109e-01
    z[7,6,6]  R2414     1.7457805573940277e-01
    z[7,6,6]  R2415     6.3427664339542389e-02
    z[7,6,6]  R2416     -1.4630000293254852e-01
    z[7,6,6]  R2417     -3.6590874195098877e-01
    z[7,6,6]  R2418     2.3407968692481518e-03
    z[7,6,6]  R2419     1.4083732664585114e-01
    z[7,6,6]  R2420     -4.5543056726455688e-01
    z[7,6,6]  R2421     3.6189281940460205e-01
    z[7,6,6]  R2422     5.9667207300662994e-02
    z[7,6,6]  R2423     3.9056394249200821e-02
    z[7,6,6]  R2424     -3.5774940252304077e-01
    z[7,6,6]  R2425     6.4626209437847137e-02
    z[7,6,6]  R2426     -5.1362957805395126e-02
    z[7,6,6]  R2427     -8.9024573564529419e-02
    z[7,6,6]  R2428     -3.5536146163940430e-01
    z[7,6,6]  R2429     -2.2796842455863953e-01
    z[7,6,6]  R2430     -2.1361030638217926e-01
    z[7,6,6]  R2431     1.4386756718158722e-01
    z[7,6,6]  R2432     -2.4325957521796227e-02
    z[7,6,6]  R2433     -2.0830747485160828e-01
    z[7,6,6]  R2434     -4.2313057184219360e-01
    z[7,6,6]  R2435     2.8809100389480591e-01
    z[7,6,6]  R2436     -2.6862871646881104e-01
    z[7,6,6]  R2437     -1.3921138644218445e-01
    z[7,6,6]  R2438     -2.2763611376285553e-01
    z[7,6,6]  R2439     -1.7594610154628754e-01
    z[7,6,6]  R2440     -3.2816660404205322e-01
    z[7,6,6]  R2441     1.3124649226665497e-01
    z[7,6,6]  R2442     -2.2728709876537323e-01
    z[7,6,6]  R2443     -8.9128427207469940e-02
    z[7,6,6]  R2444     -1.5429088473320007e-01
    z[7,6,6]  R2445     -1.7627786099910736e-01
    z[7,6,6]  R2446     -3.0590042471885681e-01
    z[7,6,6]  R2447     1.0293000936508179e-01
    z[7,6,6]  R2448     2.2025278210639954e-01
    z[7,6,6]  R2449     2.3513735830783844e-01
    z[7,6,6]  R2450     4.3343797326087952e-02
    z[7,6,6]  R2451     -5.9962904453277588e-01
    z[7,6,6]  R2452     1.0144189745187759e-01
    z[7,6,6]  R2453     -2.1279849112033844e-01
    z[7,6,6]  R2454     4.5877873897552490e-02
    z[7,6,6]  R2455     -2.1587008610367775e-02
    z[7,6,6]  R2456     -1.8798071146011353e-01
    z[7,6,6]  R2457     5.2520852535963058e-02
    z[7,6,6]  R2458     -3.2697860151529312e-02
    z[7,6,6]  R2459     3.2514709234237671e-01
    z[7,6,6]  R2460     3.3500474691390991e-01
    z[7,6,6]  R2461     -7.1647331118583679e-02
    z[7,6,6]  R2462     3.5818368196487427e-01
    z[7,6,6]  R2463     -1.2113984674215317e-01
    z[7,6,6]  R2464     0.0630001500248909
    z[7,6,6]  R2465     -1.8945485353469849e-01
    z[7,6,6]  R2466     -4.0386196970939636e-01
    z[7,6,6]  R2467     -0.0329107791185379
    z[7,6,6]  R2468     5.5236298590898514e-02
    z[7,6,6]  R2469     2.0116844773292542e-01
    z[7,6,6]  R2470     -2.6413249969482422e-01
    z[7,6,6]  R2471     -2.9550895094871521e-01
    z[7,6,6]  R2472     -2.4038228392601013e-01
    z[7,6,6]  R2473     -1.9249269366264343e-01
    z[7,6,6]  R2474     2.4628737568855286e-01
    z[7,6,6]  R2475     -2.1937627345323563e-02
    z[7,6,6]  R2476     -1.7732024192810059e-02
    z[7,6,6]  R2477     2.5335814803838730e-02
    z[7,6,6]  R2478     -1.4237202703952789e-02
    z[7,6,6]  R2479     -2.0964252948760986e-01
    z[7,6,6]  R2480     -1.3886238634586334e-01
    z[7,6,6]  R2481     0.396258682012558
    z[7,6,6]  R2482     -7.3812879621982574e-02
    z[7,6,6]  R2483     -4.7473390586674213e-03
    z[7,6,6]  R2484     1.1666963808238506e-02
    z[7,6,6]  R2485     -4.2950114607810974e-01
    z[7,6,6]  R2486     2.1697996556758881e-01
    z[7,6,6]  R2487     -3.2839265465736389e-01
    z[7,6,6]  R2488     -3.5264673829078674e-01
    z[7,6,6]  R2489     -4.8314219713211060e-01
    z[7,6,6]  R2490     -4.2768004536628723e-01
    z[7,6,6]  R2491     8.9470840990543365e-02
    z[7,6,6]  R2492     -2.0651248097419739e-01
    z[6,8,0]  R56       -1
    z[6,8,0]  R74       1
    z[6,8,0]  R2493     -1
    z[6,8,0]  R2494     1
    z[6,8,0]  R2507     -8.1584942340850830e-01
    z[6,8,0]  R2508     -8.3547770977020264e-01
    z[6,8,0]  R2509     -7.3414427042007446e-01
    z[6,8,0]  R2510     -7.2544336318969727e-01
    z[6,8,0]  R2511     -4.9633827805519104e-01
    z[6,8,0]  R2512     -6.7537021636962891e-01
    z[6,8,0]  R2513     -7.6199799776077271e-01
    z[6,8,0]  R2514     -4.8303210735321045e-01
    z[6,8,0]  R2515     -8.3185464143753052e-01
    z[6,8,0]  R2516     -4.0691459178924561e-01
    z[6,8,0]  R2517     4.9099221825599670e-01
    z[6,8,0]  R2518     9.3766905367374420e-02
    z[6,8,0]  R2519     5.0753045082092285e-01
    z[6,8,0]  R2520     4.2190632224082947e-01
    z[6,8,0]  R2521     4.9894136190414429e-01
    z[6,8,0]  R2522     5.4266828298568726e-01
    z[6,8,0]  R2523     2.8890156745910645e-01
    z[6,8,0]  R2524     3.7113168835639954e-01
    z[6,8,0]  R2525     5.5590659379959106e-01
    z[6,8,0]  R2526     6.8955369293689728e-02
    z[6,8,0]  R2527     8.2336896657943726e-01
    z[6,8,0]  R2528     0.833395779132843
    z[6,8,0]  R2529     7.7884292602539062e-01
    z[6,8,0]  R2530     7.2519683837890625e-01
    z[6,8,0]  R2531     9.1842484474182129e-01
    z[6,8,0]  R2532     0.709715723991394
    z[6,8,0]  R2533     7.4419897794723511e-01
    z[6,8,0]  R2534     8.4135973453521729e-01
    z[6,8,0]  R2535     0.773284912109375
    z[6,8,0]  R2536     7.9004669189453125e-01
    z[6,8,0]  R2537     8.4471255540847778e-01
    z[6,8,0]  R2538     7.1160227060317993e-01
    z[6,8,0]  R2539     7.2750610113143921e-01
    z[6,8,0]  R2540     -6.0652363300323486e-01
    z[6,8,0]  R2541     3.0945724248886108e-01
    z[6,8,0]  R2542     -6.7812144756317139e-02
    z[6,8,0]  R2543     -1.1857558786869049e-01
    z[6,8,0]  R2544     -4.5286703854799271e-02
    z[6,8,0]  R2545     -3.7151089310646057e-01
    z[6,8,0]  R2546     -8.5053868591785431e-02
    z[6,8,0]  R2547     -5.4492527246475220e-01
    z[6,8,0]  R2548     -2.1534349024295807e-01
    z[6,8,0]  R2549     -4.7673907876014709e-01
    z[6,8,0]  R2550     -9.1472655534744263e-01
    z[6,8,0]  R2551     -4.9899551272392273e-01
    z[6,8,0]  R2552     1.7937442660331726e-01
    z[6,8,0]  R2553     8.3233872428536415e-03
    z[6,8,0]  R2554     -1.1779731512069702e-01
    z[6,8,0]  R2555     7.5718045234680176e-02
    z[6,8,0]  R2556     4.3023101985454559e-02
    z[6,8,0]  R2557     2.5510627031326294e-01
    z[6,8,0]  R2558     0.611352801322937
    z[6,8,0]  R2559     6.4501678943634033e-01
    z[6,8,0]  R2560     5.7139158248901367e-01
    z[6,8,0]  R2561     5.8158326148986816e-01
    z[6,8,0]  R2562     3.6221036314964294e-01
    z[6,8,0]  R2563     2.8853756189346313e-01
    z[6,8,0]  R2564     3.1469497084617615e-01
    z[6,8,0]  R2565     2.6581883430480957e-01
    z[6,8,0]  R2566     5.8376115560531616e-01
    z[6,8,0]  R2567     3.7380585074424744e-01
    z[6,8,0]  R2568     4.8549342155456543e-01
    z[6,8,0]  R2569     6.9221824407577515e-01
    z[6,8,0]  R2570     2.0233023166656494e-01
    z[6,8,0]  R2571     1.2574322521686554e-01
    z[6,8,0]  R2572     2.5684067606925964e-01
    z[6,8,0]  R2573     1.1671365052461624e-01
    z[6,8,0]  R2574     2.3870217800140381e-01
    z[6,8,0]  R2575     1.5381184220314026e-01
    z[6,8,0]  R2576     5.1420134305953979e-01
    z[6,8,0]  R2577     2.2655582427978516e-01
    z[6,8,0]  R2578     0.283189594745636
    z[6,8,0]  R2579     2.7601400017738342e-01
    z[6,8,0]  R2580     3.5650694370269775e-01
    z[6,8,0]  R2581     2.8758205473423004e-02
    z[6,8,0]  R2582     2.2294494509696960e-01
    z[6,8,0]  R2583     2.8574812412261963e-01
    z[6,8,0]  R2584     -5.9725034981966019e-02
    z[6,8,0]  R2585     -0.0819258838891983
    z[6,8,1]  R57       -1
    z[6,8,1]  R75       1
    z[6,8,1]  R2495     -1
    z[6,8,1]  R2496     1
    z[6,8,1]  R2507     -1.8467040359973907e-01
    z[6,8,1]  R2508     -1.3740491867065430e-01
    z[6,8,1]  R2509     -0.263480544090271
    z[6,8,1]  R2510     -1.7347732186317444e-01
    z[6,8,1]  R2511     -0.11562529951334
    z[6,8,1]  R2512     1.0543778538703918e-01
    z[6,8,1]  R2513     1.0626516491174698e-01
    z[6,8,1]  R2514     2.3209260404109955e-01
    z[6,8,1]  R2515     -1.7743978649377823e-02
    z[6,8,1]  R2516     -7.4440743774175644e-03
    z[6,8,1]  R2517     -6.4555935561656952e-02
    z[6,8,1]  R2518     0.802198052406311
    z[6,8,1]  R2519     -2.0031096041202545e-01
    z[6,8,1]  R2520     -4.7008499503135681e-01
    z[6,8,1]  R2521     1.9505453109741211e-01
    z[6,8,1]  R2522     2.5065168738365173e-01
    z[6,8,1]  R2523     3.4602823853492737e-01
    z[6,8,1]  R2524     1.4450013637542725e-01
    z[6,8,1]  R2525     -3.8335135579109192e-01
    z[6,8,1]  R2526     9.0766036510467529e-01
    z[6,8,1]  R2527     -1.2319023162126541e-01
    z[6,8,1]  R2528     1.5052442252635956e-01
    z[6,8,1]  R2529     -5.3521089255809784e-02
    z[6,8,1]  R2530     -3.0439051985740662e-01
    z[6,8,1]  R2531     7.6228104531764984e-02
    z[6,8,1]  R2532     -4.0170428156852722e-01
    z[6,8,1]  R2533     -0.518860399723053
    z[6,8,1]  R2534     0.0714452788233757
    z[6,8,1]  R2535     1.4823582768440247e-01
    z[6,8,1]  R2536     1.9825264811515808e-01
    z[6,8,1]  R2537     -1.4329980313777924e-01
    z[6,8,1]  R2538     -2.7208226919174194e-01
    z[6,8,1]  R2539     -3.5209563374519348e-01
    z[6,8,1]  R2540     5.8529919385910034e-01
    z[6,8,1]  R2541     4.4666466116905212e-01
    z[6,8,1]  R2542     7.4827569723129272e-01
    z[6,8,1]  R2543     4.2190197110176086e-01
    z[6,8,1]  R2544     4.2537638545036316e-01
    z[6,8,1]  R2545     1.8803621828556061e-01
    z[6,8,1]  R2546     2.5354531407356262e-01
    z[6,8,1]  R2547     4.3278518319129944e-01
    z[6,8,1]  R2548     5.2865236997604370e-01
    z[6,8,1]  R2549     3.2280489802360535e-02
    z[6,8,1]  R2550     -1.0213023424148560e-01
    z[6,8,1]  R2551     3.5205683112144470e-01
    z[6,8,1]  R2552     0.0873582735657692
    z[6,8,1]  R2553     3.0650734901428223e-01
    z[6,8,1]  R2554     -1.1546940356492996e-01
    z[6,8,1]  R2555     -8.3069734275341034e-02
    z[6,8,1]  R2556     2.9835087060928345e-01
    z[6,8,1]  R2557     -0.0591592937707901
    z[6,8,1]  R2558     -6.5233409404754639e-02
    z[6,8,1]  R2559     -1.7246234416961670e-01
    z[6,8,1]  R2560     5.4489899426698685e-02
    z[6,8,1]  R2561     -7.5519219040870667e-02
    z[6,8,1]  R2562     -2.4127402901649475e-01
    z[6,8,1]  R2563     -6.4986400306224823e-02
    z[6,8,1]  R2564     6.6145914793014526e-01
    z[6,8,1]  R2565     -8.6502122879028320e-01
    z[6,8,1]  R2566     2.5387245416641235e-01
    z[6,8,1]  R2567     3.3545008301734924e-01
    z[6,8,1]  R2568     0.605156421661377
    z[6,8,1]  R2569     1.9629713892936707e-01
    z[6,8,1]  R2570     -0.922296404838562
    z[6,8,1]  R2571     -9.0870171785354614e-01
    z[6,8,1]  R2572     -9.0678805112838745e-01
    z[6,8,1]  R2573     -9.0038394927978516e-01
    z[6,8,1]  R2574     -8.7704312801361084e-01
    z[6,8,1]  R2575     -8.8701063394546509e-01
    z[6,8,1]  R2576     1.3998055458068848e-01
    z[6,8,1]  R2577     4.0884265303611755e-01
    z[6,8,1]  R2578     2.9602622613310814e-02
    z[6,8,1]  R2579     2.5092095136642456e-02
    z[6,8,1]  R2580     4.8419770598411560e-01
    z[6,8,1]  R2581     -0.950893223285675
    z[6,8,1]  R2582     -8.8206022977828979e-01
    z[6,8,1]  R2583     -8.9106363058090210e-01
    z[6,8,1]  R2584     -7.3857551813125610e-01
    z[6,8,1]  R2585     -6.0511809587478638e-01
    z[6,8,2]  R58       -1
    z[6,8,2]  R76       1
    z[6,8,2]  R2497     -1
    z[6,8,2]  R2498     1
    z[6,8,2]  R2507     2.8686735033988953e-01
    z[6,8,2]  R2508     4.7996678948402405e-01
    z[6,8,2]  R2509     3.2032766938209534e-01
    z[6,8,2]  R2510     0.468130499124527
    z[6,8,2]  R2511     8.5109126567840576e-01
    z[6,8,2]  R2512     5.6741166114807129e-01
    z[6,8,2]  R2513     5.0181424617767334e-01
    z[6,8,2]  R2514     6.3314098119735718e-01
    z[6,8,2]  R2515     -4.0242251753807068e-01
    z[6,8,2]  R2516     6.1131817102432251e-01
    z[6,8,2]  R2517     2.3638445138931274e-01
    z[6,8,2]  R2518     -2.1357320249080658e-02
    z[6,8,2]  R2519     1.7076766490936279e-01
    z[6,8,2]  R2520     3.5945731401443481e-01
    z[6,8,2]  R2521     3.8796633481979370e-01
    z[6,8,2]  R2522     3.3352798223495483e-01
    z[6,8,2]  R2523     -7.1650457382202148e-01
    z[6,8,2]  R2524     -7.4348253011703491e-01
    z[6,8,2]  R2525     -4.6164166927337646e-01
    z[6,8,2]  R2526     9.9883466958999634e-02
    z[6,8,2]  R2527     -2.6978502050042152e-02
    z[6,8,2]  R2528     3.1799456477165222e-01
    z[6,8,2]  R2529     5.3231620788574219e-01
    z[6,8,2]  R2530     4.8598667979240417e-01
    z[6,8,2]  R2531     2.3269085586071014e-01
    z[6,8,2]  R2532     3.8618156313896179e-01
    z[6,8,2]  R2533     1.1577173322439194e-01
    z[6,8,2]  R2534     -2.1999187767505646e-01
    z[6,8,2]  R2535     3.9089924097061157e-01
    z[6,8,2]  R2536     3.9018783718347549e-02
    z[6,8,2]  R2537     -3.4256213903427124e-01
    z[6,8,2]  R2538     8.4643848240375519e-02
    z[6,8,2]  R2539     -0.0328790545463562
    z[6,8,2]  R2540     -3.7224420905113220e-01
    z[6,8,2]  R2541     0.0223090797662735
    z[6,8,2]  R2542     7.9673487925902009e-04
    z[6,8,2]  R2543     -1.5540605783462524e-01
    z[6,8,2]  R2544     2.8781020641326904e-01
    z[6,8,2]  R2545     -6.6818159818649292e-01
    z[6,8,2]  R2546     3.0707883834838867e-01
    z[6,8,2]  R2547     4.4297706335783005e-02
    z[6,8,2]  R2548     -1.0253424942493439e-01
    z[6,8,2]  R2549     3.4196120500564575e-01
    z[6,8,2]  R2550     1.9986394047737122e-01
    z[6,8,2]  R2551     -8.1668362021446228e-02
    z[6,8,2]  R2552     2.2891965508460999e-01
    z[6,8,2]  R2553     5.2468216419219971e-01
    z[6,8,2]  R2554     -3.9801257848739624e-01
    z[6,8,2]  R2555     -4.8457396030426025e-01
    z[6,8,2]  R2556     -6.3851737976074219e-01
    z[6,8,2]  R2557     -3.4500178694725037e-01
    z[6,8,2]  R2558     -3.0746594071388245e-02
    z[6,8,2]  R2559     0.0672302395105362
    z[6,8,2]  R2560     -1.6945162415504456e-01
    z[6,8,2]  R2561     3.5668212175369263e-01
    z[6,8,2]  R2562     4.5615750551223755e-01
    z[6,8,2]  R2563     1.0421478748321533e-01
    z[6,8,2]  R2564     2.2317555546760559e-01
    z[6,8,2]  R2565     1.8342211842536926e-01
    z[6,8,2]  R2566     3.2977712154388428e-01
    z[6,8,2]  R2567     2.5324460864067078e-01
    z[6,8,2]  R2568     2.0797833800315857e-01
    z[6,8,2]  R2569     5.5952745676040649e-01
    z[6,8,2]  R2570     -1.7250286042690277e-01
    z[6,8,2]  R2571     1.0942266322672367e-02
    z[6,8,2]  R2572     -9.7748890519142151e-02
    z[6,8,2]  R2573     -1.1095040291547775e-01
    z[6,8,2]  R2574     8.1540994346141815e-02
    z[6,8,2]  R2575     1.9990071654319763e-02
    z[6,8,2]  R2576     3.3385327458381653e-01
    z[6,8,2]  R2577     -6.5134182572364807e-02
    z[6,8,2]  R2578     4.1693288087844849e-01
    z[6,8,2]  R2579     -3.3540013432502747e-01
    z[6,8,2]  R2580     3.5556885600090027e-01
    z[6,8,2]  R2581     -1.6824441030621529e-02
    z[6,8,2]  R2582     1.4960496127605438e-01
    z[6,8,2]  R2583     3.2649624347686768e-01
    z[6,8,2]  R2584     -5.8190923929214478e-01
    z[6,8,2]  R2585     -5.5336314439773560e-01
    z[6,8,3]  R59       -1
    z[6,8,3]  R77       1
    z[6,8,3]  R2499     -1
    z[6,8,3]  R2500     1
    z[6,8,3]  R2507     -0.258035808801651
    z[6,8,3]  R2508     1.2278497964143753e-01
    z[6,8,3]  R2509     1.5831816196441650e-01
    z[6,8,3]  R2510     -8.6031429469585419e-02
    z[6,8,3]  R2511     1.6550848260521889e-02
    z[6,8,3]  R2512     3.3472830057144165e-01
    z[6,8,3]  R2513     -1.8150122463703156e-01
    z[6,8,3]  R2514     4.3236851692199707e-02
    z[6,8,3]  R2515     2.4676360189914703e-01
    z[6,8,3]  R2516     2.7102762460708618e-01
    z[6,8,3]  R2517     8.2595801353454590e-01
    z[6,8,3]  R2518     5.1190227270126343e-01
    z[6,8,3]  R2519     -4.7305294871330261e-01
    z[6,8,3]  R2520     -4.7772252559661865e-01
    z[6,8,3]  R2521     -2.2916845977306366e-01
    z[6,8,3]  R2522     3.6530005931854248e-01
    z[6,8,3]  R2523     2.2059649229049683e-01
    z[6,8,3]  R2524     0.436553955078125
    z[6,8,3]  R2525     2.1341089904308319e-01
    z[6,8,3]  R2526     8.2821629941463470e-02
    z[6,8,3]  R2527     4.1775268316268921e-01
    z[6,8,3]  R2528     1.7087125778198242e-01
    z[6,8,3]  R2529     6.1872269958257675e-02
    z[6,8,3]  R2530     -2.9044350981712341e-01
    z[6,8,3]  R2531     2.3048759996891022e-01
    z[6,8,3]  R2532     1.4789731800556183e-01
    z[6,8,3]  R2533     2.0402505993843079e-02
    z[6,8,3]  R2534     4.0229588747024536e-01
    z[6,8,3]  R2535     5.2630184218287468e-03
    z[6,8,3]  R2536     8.6509138345718384e-02
    z[6,8,3]  R2537     -2.4839197099208832e-01
    z[6,8,3]  R2538     -4.9620926380157471e-01
    z[6,8,3]  R2539     -2.7569499611854553e-01
    z[6,8,3]  R2540     -1.9026175141334534e-02
    z[6,8,3]  R2541     5.1256150007247925e-01
    z[6,8,3]  R2542     3.8620454072952271e-01
    z[6,8,3]  R2543     7.3760688304901123e-01
    z[6,8,3]  R2544     5.5118137598037720e-01
    z[6,8,3]  R2545     -5.6256562471389771e-01
    z[6,8,3]  R2546     4.1415810585021973e-01
    z[6,8,3]  R2547     3.3893135190010071e-01
    z[6,8,3]  R2548     1.7238068580627441e-01
    z[6,8,3]  R2549     -8.0694389343261719e-01
    z[6,8,3]  R2550     2.2265070676803589e-01
    z[6,8,3]  R2551     -1.2656930088996887e-01
    z[6,8,3]  R2552     4.0449026226997375e-01
    z[6,8,3]  R2553     -0.569337010383606
    z[6,8,3]  R2554     -6.4385145902633667e-01
    z[6,8,3]  R2555     1.1762108653783798e-02
    z[6,8,3]  R2556     -2.0890416204929352e-01
    z[6,8,3]  R2557     0.820968508720398
    z[6,8,3]  R2558     6.7245924472808838e-01
    z[6,8,3]  R2559     6.3162380456924438e-01
    z[6,8,3]  R2560     7.0842069387435913e-01
    z[6,8,3]  R2561     6.5730887651443481e-01
    z[6,8,3]  R2562     7.4381065368652344e-01
    z[6,8,3]  R2563     8.7322556972503662e-01
    z[6,8,3]  R2564     2.5221675634384155e-01
    z[6,8,3]  R2565     -2.6172018051147461e-01
    z[6,8,3]  R2566     3.6002656817436218e-01
    z[6,8,3]  R2567     3.9744228124618530e-01
    z[6,8,3]  R2568     2.2856892645359039e-01
    z[6,8,3]  R2569     3.2866531610488892e-01
    z[6,8,3]  R2570     -1.9448810815811157e-01
    z[6,8,3]  R2571     -1.3624049723148346e-01
    z[6,8,3]  R2572     1.0560864955186844e-01
    z[6,8,3]  R2573     8.2533389329910278e-02
    z[6,8,3]  R2574     3.7692766636610031e-02
    z[6,8,3]  R2575     1.9963359832763672e-01
    z[6,8,3]  R2576     6.4280843734741211e-01
    z[6,8,3]  R2577     7.4181818962097168e-01
    z[6,8,3]  R2578     8.2144778966903687e-01
    z[6,8,3]  R2579     6.5293055772781372e-01
    z[6,8,3]  R2580     6.0793638229370117e-01
    z[6,8,3]  R2581     -2.7843394875526428e-01
    z[6,8,3]  R2582     -1.4027177821844816e-03
    z[6,8,3]  R2583     -1.1982208490371704e-01
    z[6,8,3]  R2584     -1.3696564733982086e-01
    z[6,8,3]  R2585     -4.2138215899467468e-01
    z[6,8,4]  R60       -1
    z[6,8,4]  R78       1
    z[6,8,4]  R2501     -1
    z[6,8,4]  R2502     1
    z[6,8,4]  R2507     3.0593115091323853e-01
    z[6,8,4]  R2508     6.5106144174933434e-03
    z[6,8,4]  R2509     -4.5229992270469666e-01
    z[6,8,4]  R2510     -3.1586790084838867e-01
    z[6,8,4]  R2511     0.0892091765999794
    z[6,8,4]  R2512     -2.5338403880596161e-02
    z[6,8,4]  R2513     -8.6166240274906158e-02
    z[6,8,4]  R2514     -4.0733799338340759e-01
    z[6,8,4]  R2515     -1.0798192024230957e-01
    z[6,8,4]  R2516     -3.9711430668830872e-01
    z[6,8,4]  R2517     2.8151612728834152e-02
    z[6,8,4]  R2518     9.6242956817150116e-02
    z[6,8,4]  R2519     0.629560112953186
    z[6,8,4]  R2520     2.3625931143760681e-01
    z[6,8,4]  R2521     -9.6024684607982635e-02
    z[6,8,4]  R2522     5.7412409782409668e-01
    z[6,8,4]  R2523     3.5405838489532471e-01
    z[6,8,4]  R2524     7.6192080974578857e-02
    z[6,8,4]  R2525     -3.4034612774848938e-01
    z[6,8,4]  R2526     1.1436818540096283e-01
    z[6,8,4]  R2527     3.0561983585357666e-01
    z[6,8,4]  R2528     -2.8432181477546692e-01
    z[6,8,4]  R2529     2.3806239664554596e-01
    z[6,8,4]  R2530     -2.4416035413742065e-01
    z[6,8,4]  R2531     5.5884812027215958e-02
    z[6,8,4]  R2532     4.0759924799203873e-02
    z[6,8,4]  R2533     -0.142137348651886
    z[6,8,4]  R2534     -1.2161013484001160e-01
    z[6,8,4]  R2535     2.0110353827476501e-01
    z[6,8,4]  R2536     4.0101557970046997e-01
    z[6,8,4]  R2537     -2.5878927111625671e-01
    z[6,8,4]  R2538     3.3145558834075928e-01
    z[6,8,4]  R2539     -1.4004895463585854e-02
    z[6,8,4]  R2540     8.0085322260856628e-02
    z[6,8,4]  R2541     -1.9381056725978851e-01
    z[6,8,4]  R2542     2.7783846855163574e-01
    z[6,8,4]  R2543     -4.5912593603134155e-02
    z[6,8,4]  R2544     -4.2880815267562866e-01
    z[6,8,4]  R2545     -2.3255331814289093e-01
    z[6,8,4]  R2546     7.3434972763061523e-01
    z[6,8,4]  R2547     6.1544120311737061e-01
    z[6,8,4]  R2548     -1.6038011014461517e-01
    z[6,8,4]  R2549     -4.4960159808397293e-02
    z[6,8,4]  R2550     3.2772939652204514e-02
    z[6,8,4]  R2551     2.4203942716121674e-01
    z[6,8,4]  R2552     -7.1600514650344849e-01
    z[6,8,4]  R2553     -4.7515761852264404e-01
    z[6,8,4]  R2554     -4.7687861323356628e-01
    z[6,8,4]  R2555     -1.4801302552223206e-01
    z[6,8,4]  R2556     -8.6326800286769867e-02
    z[6,8,4]  R2557     -1.1482661962509155e-01
    z[6,8,4]  R2558     -7.4615702033042908e-03
    z[6,8,4]  R2559     -1.4398986101150513e-01
    z[6,8,4]  R2560     3.1648358702659607e-01
    z[6,8,4]  R2561     8.5796646773815155e-02
    z[6,8,4]  R2562     1.6937313973903656e-01
    z[6,8,4]  R2563     3.5484090447425842e-01
    z[6,8,4]  R2564     -5.3575527854263783e-03
    z[6,8,4]  R2565     -5.2903532981872559e-02
    z[6,8,4]  R2566     -5.3471463918685913e-01
    z[6,8,4]  R2567     -0.59151291847229
    z[6,8,4]  R2568     -7.9646848142147064e-02
    z[6,8,4]  R2569     -0.0201775711029768
    z[6,8,4]  R2570     4.5154165476560593e-02
    z[6,8,4]  R2571     1.6619296371936798e-01
    z[6,8,4]  R2572     1.6266991198062897e-01
    z[6,8,4]  R2573     -3.7581852078437805e-01
    z[6,8,4]  R2574     -2.7733482420444489e-03
    z[6,8,4]  R2575     2.2970676422119141e-01
    z[6,8,4]  R2576     -1.4652857184410095e-01
    z[6,8,4]  R2577     1.3311018049716949e-01
    z[6,8,4]  R2578     2.1338362246751785e-02
    z[6,8,4]  R2579     -4.9263462424278259e-01
    z[6,8,4]  R2580     1.3779577612876892e-01
    z[6,8,4]  R2581     -3.4126002341508865e-02
    z[6,8,4]  R2582     -1.0386031121015549e-01
    z[6,8,4]  R2583     -1.1333167552947998e-02
    z[6,8,4]  R2584     1.8678863346576691e-01
    z[6,8,4]  R2585     1.9302532076835632e-02
    z[6,8,5]  R61       -1
    z[6,8,5]  R79       1
    z[6,8,5]  R2503     -1
    z[6,8,5]  R2504     1
    z[6,8,5]  R2507     -1.1195619404315948e-01
    z[6,8,5]  R2508     1.8842902779579163e-01
    z[6,8,5]  R2509     2.4268217384815216e-01
    z[6,8,5]  R2510     -2.8632253408432007e-01
    z[6,8,5]  R2511     -7.0227861404418945e-02
    z[6,8,5]  R2512     -3.1152474880218506e-01
    z[6,8,5]  R2513     1.0080326348543167e-01
    z[6,8,5]  R2514     -1.7867214977741241e-01
    z[6,8,5]  R2515     2.6090887188911438e-01
    z[6,8,5]  R2516     3.1812575459480286e-01
    z[6,8,5]  R2517     3.4749977290630341e-02
    z[6,8,5]  R2518     2.6824250817298889e-01
    z[6,8,5]  R2519     -1.3079972565174103e-01
    z[6,8,5]  R2520     1.5704709291458130e-01
    z[6,8,5]  R2521     -7.0687431097030640e-01
    z[6,8,5]  R2522     -2.5559765100479126e-01
    z[6,8,5]  R2523     2.6255035400390625e-01
    z[6,8,5]  R2524     -1.4988008141517639e-01
    z[6,8,5]  R2525     0.286690354347229
    z[6,8,5]  R2526     2.8930592536926270e-01
    z[6,8,5]  R2527     3.4431774169206619e-02
    z[6,8,5]  R2528     -1.0478625446557999e-01
    z[6,8,5]  R2529     -2.1493105590343475e-01
    z[6,8,5]  R2530     -3.1095145270228386e-02
    z[6,8,5]  R2531     -1.9912435114383698e-01
    z[6,8,5]  R2532     0.402570903301239
    z[6,8,5]  R2533     3.1461000442504883e-01
    z[6,8,5]  R2534     -2.0663768053054810e-01
    z[6,8,5]  R2535     1.7251954972743988e-01
    z[6,8,5]  R2536     -4.0156453847885132e-01
    z[6,8,5]  R2537     1.4101035892963409e-01
    z[6,8,5]  R2538     2.3707848787307739e-01
    z[6,8,5]  R2539     -2.9156050086021423e-01
    z[6,8,5]  R2540     -3.1166058778762817e-01
    z[6,8,5]  R2541     5.4415595531463623e-01
    z[6,8,5]  R2542     -2.9116401076316833e-01
    z[6,8,5]  R2543     -6.4724549651145935e-02
    z[6,8,5]  R2544     2.5215440988540649e-01
    z[6,8,5]  R2545     -3.9865810424089432e-02
    z[6,8,5]  R2546     0.284146785736084
    z[6,8,5]  R2547     1.3929626345634460e-01
    z[6,8,5]  R2548     -3.5279604792594910e-01
    z[6,8,5]  R2549     3.8220237940549850e-02
    z[6,8,5]  R2550     2.1354711055755615e-01
    z[6,8,5]  R2551     -4.0999558568000793e-01
    z[6,8,5]  R2552     8.4200963377952576e-02
    z[6,8,5]  R2553     2.8404369950294495e-01
    z[6,8,5]  R2554     3.8109812140464783e-01
    z[6,8,5]  R2555     7.8728175163269043e-01
    z[6,8,5]  R2556     6.7090344429016113e-01
    z[6,8,5]  R2557     3.5295647382736206e-01
    z[6,8,5]  R2558     -2.4163994938135147e-02
    z[6,8,5]  R2559     2.7940610051155090e-01
    z[6,8,5]  R2560     2.9542475938796997e-02
    z[6,8,5]  R2561     2.8805750608444214e-01
    z[6,8,5]  R2562     -1.4151780307292938e-01
    z[6,8,5]  R2563     -5.8375686407089233e-02
    z[6,8,5]  R2564     5.0904947519302368e-01
    z[6,8,5]  R2565     -2.0721639692783356e-01
    z[6,8,5]  R2566     2.2999155521392822e-01
    z[6,8,5]  R2567     1.7055776715278625e-01
    z[6,8,5]  R2568     4.8161312937736511e-01
    z[6,8,5]  R2569     -1.8148081004619598e-01
    z[6,8,5]  R2570     0.072996124625206
    z[6,8,5]  R2571     -1.3415264897048473e-02
    z[6,8,5]  R2572     2.1625134348869324e-01
    z[6,8,5]  R2573     0.118670254945755
    z[6,8,5]  R2574     -0.221003919839859
    z[6,8,5]  R2575     -3.0883875489234924e-01
    z[6,8,5]  R2576     -1.3896717131137848e-01
    z[6,8,5]  R2577     3.2583504915237427e-01
    z[6,8,5]  R2578     -8.8345922529697418e-02
    z[6,8,5]  R2579     2.5804251432418823e-01
    z[6,8,5]  R2580     2.5488847494125366e-01
    z[6,8,5]  R2581     -0.0645069107413292
    z[6,8,5]  R2582     2.2342254221439362e-01
    z[6,8,5]  R2583     5.1044980064034462e-03
    z[6,8,5]  R2584     -2.3616391420364380e-01
    z[6,8,5]  R2585     -3.1501868367195129e-01
    z[6,8,6]  R62       -1
    z[6,8,6]  R80       1
    z[6,8,6]  R2505     -1
    z[6,8,6]  R2506     1
    z[6,8,6]  R2507     -2.1279849112033844e-01
    z[6,8,6]  R2508     4.5877873897552490e-02
    z[6,8,6]  R2509     -2.1587008610367775e-02
    z[6,8,6]  R2510     -1.8798071146011353e-01
    z[6,8,6]  R2511     5.2520852535963058e-02
    z[6,8,6]  R2512     -3.2697860151529312e-02
    z[6,8,6]  R2513     3.2514709234237671e-01
    z[6,8,6]  R2514     3.3500474691390991e-01
    z[6,8,6]  R2515     -7.1647331118583679e-02
    z[6,8,6]  R2516     3.5818368196487427e-01
    z[6,8,6]  R2517     -1.2113984674215317e-01
    z[6,8,6]  R2518     0.0630001500248909
    z[6,8,6]  R2519     -1.8945485353469849e-01
    z[6,8,6]  R2520     -4.0386196970939636e-01
    z[6,8,6]  R2521     -0.0329107791185379
    z[6,8,6]  R2522     5.5236298590898514e-02
    z[6,8,6]  R2523     2.0116844773292542e-01
    z[6,8,6]  R2524     -2.6413249969482422e-01
    z[6,8,6]  R2525     -2.9550895094871521e-01
    z[6,8,6]  R2526     -2.4038228392601013e-01
    z[6,8,6]  R2527     -1.9249269366264343e-01
    z[6,8,6]  R2528     2.4628737568855286e-01
    z[6,8,6]  R2529     -2.1937627345323563e-02
    z[6,8,6]  R2530     -1.7732024192810059e-02
    z[6,8,6]  R2531     2.5335814803838730e-02
    z[6,8,6]  R2532     -1.4237202703952789e-02
    z[6,8,6]  R2533     -2.0964252948760986e-01
    z[6,8,6]  R2534     -1.3886238634586334e-01
    z[6,8,6]  R2535     0.396258682012558
    z[6,8,6]  R2536     -7.3812879621982574e-02
    z[6,8,6]  R2537     -4.7473390586674213e-03
    z[6,8,6]  R2538     1.1666963808238506e-02
    z[6,8,6]  R2539     -4.2950114607810974e-01
    z[6,8,6]  R2540     2.1697996556758881e-01
    z[6,8,6]  R2541     -3.2839265465736389e-01
    z[6,8,6]  R2542     -3.5264673829078674e-01
    z[6,8,6]  R2543     -4.8314219713211060e-01
    z[6,8,6]  R2544     -4.2768004536628723e-01
    z[6,8,6]  R2545     8.9470840990543365e-02
    z[6,8,6]  R2546     -2.0651248097419739e-01
    z[6,8,6]  R2547     -2.7296485379338264e-02
    z[6,8,6]  R2548     -6.9551318883895874e-01
    z[6,8,6]  R2549     -9.9850669503211975e-03
    z[6,8,6]  R2550     1.2903241813182831e-01
    z[6,8,6]  R2551     0.614565372467041
    z[6,8,6]  R2552     4.7373369336128235e-01
    z[6,8,6]  R2553     -9.6105104312300682e-03
    z[6,8,6]  R2554     -1.6487258672714233e-01
    z[6,8,6]  R2555     -3.3270925283432007e-01
    z[6,8,6]  R2556     -1.5050514601171017e-02
    z[6,8,6]  R2557     2.5339301675558090e-02
    z[6,8,6]  R2558     4.1012936830520630e-01
    z[6,8,6]  R2559     -2.2790496051311493e-01
    z[6,8,6]  R2560     1.9731713831424713e-01
    z[6,8,6]  R2561     -8.0265142023563385e-02
    z[6,8,6]  R2562     -2.3283023387193680e-02
    z[6,8,6]  R2563     9.9094063043594360e-02
    z[6,8,6]  R2564     3.0142712593078613e-01
    z[6,8,6]  R2565     1.8220894038677216e-01
    z[6,8,6]  R2566     1.3260385394096375e-01
    z[6,8,6]  R2567     3.8297748565673828e-01
    z[6,8,6]  R2568     2.5355115532875061e-01
    z[6,8,6]  R2569     1.6693432629108429e-01
    z[6,8,6]  R2570     1.8298017978668213e-01
    z[6,8,6]  R2571     3.3461713790893555e-01
    z[6,8,6]  R2572     1.3354423642158508e-01
    z[6,8,6]  R2573     3.5253062844276428e-02
    z[6,8,6]  R2574     -3.4190145134925842e-01
    z[6,8,6]  R2575     3.3973187208175659e-02
    z[6,8,6]  R2576     3.8801971077919006e-01
    z[6,8,6]  R2577     3.2108667492866516e-01
    z[6,8,6]  R2578     2.4911326169967651e-01
    z[6,8,6]  R2579     2.7404436469078064e-01
    z[6,8,6]  R2580     2.4183419346809387e-01
    z[6,8,6]  R2581     -1.0881573706865311e-01
    z[6,8,6]  R2582     -2.9862526059150696e-01
    z[6,8,6]  R2583     0.0569380484521389
    z[6,8,6]  R2584     -5.3832545876502991e-02
    z[6,8,6]  R2585     -2.0913438498973846e-01
    z[8,6,0]  R56       1
    z[8,6,0]  R74       -1
    z[8,6,0]  R2586     -1
    z[8,6,0]  R2587     1
    z[8,6,0]  R2600     -5.4492527246475220e-01
    z[8,6,0]  R2601     -2.1534349024295807e-01
    z[8,6,0]  R2602     -4.7673907876014709e-01
    z[8,6,0]  R2603     -9.1472655534744263e-01
    z[8,6,0]  R2604     -4.9899551272392273e-01
    z[8,6,0]  R2605     1.7937442660331726e-01
    z[8,6,0]  R2606     8.3233872428536415e-03
    z[8,6,0]  R2607     -1.1779731512069702e-01
    z[8,6,0]  R2608     7.5718045234680176e-02
    z[8,6,0]  R2609     4.3023101985454559e-02
    z[8,6,0]  R2610     2.5510627031326294e-01
    z[8,6,0]  R2611     0.611352801322937
    z[8,6,0]  R2612     6.4501678943634033e-01
    z[8,6,0]  R2613     5.7139158248901367e-01
    z[8,6,0]  R2614     5.8158326148986816e-01
    z[8,6,0]  R2615     3.6221036314964294e-01
    z[8,6,0]  R2616     2.8853756189346313e-01
    z[8,6,0]  R2617     3.1469497084617615e-01
    z[8,6,0]  R2618     2.6581883430480957e-01
    z[8,6,0]  R2619     5.8376115560531616e-01
    z[8,6,0]  R2620     3.7380585074424744e-01
    z[8,6,0]  R2621     4.8549342155456543e-01
    z[8,6,0]  R2622     6.9221824407577515e-01
    z[8,6,0]  R2623     2.0233023166656494e-01
    z[8,6,0]  R2624     1.2574322521686554e-01
    z[8,6,0]  R2625     2.5684067606925964e-01
    z[8,6,0]  R2626     1.1671365052461624e-01
    z[8,6,0]  R2627     2.3870217800140381e-01
    z[8,6,0]  R2628     1.5381184220314026e-01
    z[8,6,0]  R2629     5.1420134305953979e-01
    z[8,6,0]  R2630     2.2655582427978516e-01
    z[8,6,0]  R2631     0.283189594745636
    z[8,6,0]  R2632     2.7601400017738342e-01
    z[8,6,0]  R2633     3.5650694370269775e-01
    z[8,6,0]  R2634     2.8758205473423004e-02
    z[8,6,0]  R2635     2.2294494509696960e-01
    z[8,6,0]  R2636     2.8574812412261963e-01
    z[8,6,0]  R2637     -5.9725034981966019e-02
    z[8,6,0]  R2638     -0.0819258838891983
    z[8,6,0]  R2639     -8.1584942340850830e-01
    z[8,6,0]  R2640     -8.3547770977020264e-01
    z[8,6,0]  R2641     -7.3414427042007446e-01
    z[8,6,0]  R2642     -7.2544336318969727e-01
    z[8,6,0]  R2643     -4.9633827805519104e-01
    z[8,6,0]  R2644     -6.7537021636962891e-01
    z[8,6,0]  R2645     -7.6199799776077271e-01
    z[8,6,0]  R2646     -4.8303210735321045e-01
    z[8,6,0]  R2647     -8.3185464143753052e-01
    z[8,6,0]  R2648     -4.0691459178924561e-01
    z[8,6,0]  R2649     4.9099221825599670e-01
    z[8,6,0]  R2650     9.3766905367374420e-02
    z[8,6,0]  R2651     5.0753045082092285e-01
    z[8,6,0]  R2652     4.2190632224082947e-01
    z[8,6,0]  R2653     4.9894136190414429e-01
    z[8,6,0]  R2654     5.4266828298568726e-01
    z[8,6,0]  R2655     2.8890156745910645e-01
    z[8,6,0]  R2656     3.7113168835639954e-01
    z[8,6,0]  R2657     5.5590659379959106e-01
    z[8,6,0]  R2658     6.8955369293689728e-02
    z[8,6,0]  R2659     8.2336896657943726e-01
    z[8,6,0]  R2660     0.833395779132843
    z[8,6,0]  R2661     7.7884292602539062e-01
    z[8,6,0]  R2662     7.2519683837890625e-01
    z[8,6,0]  R2663     9.1842484474182129e-01
    z[8,6,0]  R2664     0.709715723991394
    z[8,6,0]  R2665     7.4419897794723511e-01
    z[8,6,0]  R2666     8.4135973453521729e-01
    z[8,6,0]  R2667     0.773284912109375
    z[8,6,0]  R2668     7.9004669189453125e-01
    z[8,6,0]  R2669     8.4471255540847778e-01
    z[8,6,0]  R2670     7.1160227060317993e-01
    z[8,6,0]  R2671     7.2750610113143921e-01
    z[8,6,0]  R2672     -6.0652363300323486e-01
    z[8,6,0]  R2673     3.0945724248886108e-01
    z[8,6,0]  R2674     -6.7812144756317139e-02
    z[8,6,0]  R2675     -1.1857558786869049e-01
    z[8,6,0]  R2676     -4.5286703854799271e-02
    z[8,6,0]  R2677     -3.7151089310646057e-01
    z[8,6,0]  R2678     -8.5053868591785431e-02
    z[8,6,1]  R57       1
    z[8,6,1]  R75       -1
    z[8,6,1]  R2588     -1
    z[8,6,1]  R2589     1
    z[8,6,1]  R2600     4.3278518319129944e-01
    z[8,6,1]  R2601     5.2865236997604370e-01
    z[8,6,1]  R2602     3.2280489802360535e-02
    z[8,6,1]  R2603     -1.0213023424148560e-01
    z[8,6,1]  R2604     3.5205683112144470e-01
    z[8,6,1]  R2605     0.0873582735657692
    z[8,6,1]  R2606     3.0650734901428223e-01
    z[8,6,1]  R2607     -1.1546940356492996e-01
    z[8,6,1]  R2608     -8.3069734275341034e-02
    z[8,6,1]  R2609     2.9835087060928345e-01
    z[8,6,1]  R2610     -0.0591592937707901
    z[8,6,1]  R2611     -6.5233409404754639e-02
    z[8,6,1]  R2612     -1.7246234416961670e-01
    z[8,6,1]  R2613     5.4489899426698685e-02
    z[8,6,1]  R2614     -7.5519219040870667e-02
    z[8,6,1]  R2615     -2.4127402901649475e-01
    z[8,6,1]  R2616     -6.4986400306224823e-02
    z[8,6,1]  R2617     6.6145914793014526e-01
    z[8,6,1]  R2618     -8.6502122879028320e-01
    z[8,6,1]  R2619     2.5387245416641235e-01
    z[8,6,1]  R2620     3.3545008301734924e-01
    z[8,6,1]  R2621     0.605156421661377
    z[8,6,1]  R2622     1.9629713892936707e-01
    z[8,6,1]  R2623     -0.922296404838562
    z[8,6,1]  R2624     -9.0870171785354614e-01
    z[8,6,1]  R2625     -9.0678805112838745e-01
    z[8,6,1]  R2626     -9.0038394927978516e-01
    z[8,6,1]  R2627     -8.7704312801361084e-01
    z[8,6,1]  R2628     -8.8701063394546509e-01
    z[8,6,1]  R2629     1.3998055458068848e-01
    z[8,6,1]  R2630     4.0884265303611755e-01
    z[8,6,1]  R2631     2.9602622613310814e-02
    z[8,6,1]  R2632     2.5092095136642456e-02
    z[8,6,1]  R2633     4.8419770598411560e-01
    z[8,6,1]  R2634     -0.950893223285675
    z[8,6,1]  R2635     -8.8206022977828979e-01
    z[8,6,1]  R2636     -8.9106363058090210e-01
    z[8,6,1]  R2637     -7.3857551813125610e-01
    z[8,6,1]  R2638     -6.0511809587478638e-01
    z[8,6,1]  R2639     -1.8467040359973907e-01
    z[8,6,1]  R2640     -1.3740491867065430e-01
    z[8,6,1]  R2641     -0.263480544090271
    z[8,6,1]  R2642     -1.7347732186317444e-01
    z[8,6,1]  R2643     -0.11562529951334
    z[8,6,1]  R2644     1.0543778538703918e-01
    z[8,6,1]  R2645     1.0626516491174698e-01
    z[8,6,1]  R2646     2.3209260404109955e-01
    z[8,6,1]  R2647     -1.7743978649377823e-02
    z[8,6,1]  R2648     -7.4440743774175644e-03
    z[8,6,1]  R2649     -6.4555935561656952e-02
    z[8,6,1]  R2650     0.802198052406311
    z[8,6,1]  R2651     -2.0031096041202545e-01
    z[8,6,1]  R2652     -4.7008499503135681e-01
    z[8,6,1]  R2653     1.9505453109741211e-01
    z[8,6,1]  R2654     2.5065168738365173e-01
    z[8,6,1]  R2655     3.4602823853492737e-01
    z[8,6,1]  R2656     1.4450013637542725e-01
    z[8,6,1]  R2657     -3.8335135579109192e-01
    z[8,6,1]  R2658     9.0766036510467529e-01
    z[8,6,1]  R2659     -1.2319023162126541e-01
    z[8,6,1]  R2660     1.5052442252635956e-01
    z[8,6,1]  R2661     -5.3521089255809784e-02
    z[8,6,1]  R2662     -3.0439051985740662e-01
    z[8,6,1]  R2663     7.6228104531764984e-02
    z[8,6,1]  R2664     -4.0170428156852722e-01
    z[8,6,1]  R2665     -0.518860399723053
    z[8,6,1]  R2666     0.0714452788233757
    z[8,6,1]  R2667     1.4823582768440247e-01
    z[8,6,1]  R2668     1.9825264811515808e-01
    z[8,6,1]  R2669     -1.4329980313777924e-01
    z[8,6,1]  R2670     -2.7208226919174194e-01
    z[8,6,1]  R2671     -3.5209563374519348e-01
    z[8,6,1]  R2672     5.8529919385910034e-01
    z[8,6,1]  R2673     4.4666466116905212e-01
    z[8,6,1]  R2674     7.4827569723129272e-01
    z[8,6,1]  R2675     4.2190197110176086e-01
    z[8,6,1]  R2676     4.2537638545036316e-01
    z[8,6,1]  R2677     1.8803621828556061e-01
    z[8,6,1]  R2678     2.5354531407356262e-01
    z[8,6,2]  R58       1
    z[8,6,2]  R76       -1
    z[8,6,2]  R2590     -1
    z[8,6,2]  R2591     1
    z[8,6,2]  R2600     4.4297706335783005e-02
    z[8,6,2]  R2601     -1.0253424942493439e-01
    z[8,6,2]  R2602     3.4196120500564575e-01
    z[8,6,2]  R2603     1.9986394047737122e-01
    z[8,6,2]  R2604     -8.1668362021446228e-02
    z[8,6,2]  R2605     2.2891965508460999e-01
    z[8,6,2]  R2606     5.2468216419219971e-01
    z[8,6,2]  R2607     -3.9801257848739624e-01
    z[8,6,2]  R2608     -4.8457396030426025e-01
    z[8,6,2]  R2609     -6.3851737976074219e-01
    z[8,6,2]  R2610     -3.4500178694725037e-01
    z[8,6,2]  R2611     -3.0746594071388245e-02
    z[8,6,2]  R2612     0.0672302395105362
    z[8,6,2]  R2613     -1.6945162415504456e-01
    z[8,6,2]  R2614     3.5668212175369263e-01
    z[8,6,2]  R2615     4.5615750551223755e-01
    z[8,6,2]  R2616     1.0421478748321533e-01
    z[8,6,2]  R2617     2.2317555546760559e-01
    z[8,6,2]  R2618     1.8342211842536926e-01
    z[8,6,2]  R2619     3.2977712154388428e-01
    z[8,6,2]  R2620     2.5324460864067078e-01
    z[8,6,2]  R2621     2.0797833800315857e-01
    z[8,6,2]  R2622     5.5952745676040649e-01
    z[8,6,2]  R2623     -1.7250286042690277e-01
    z[8,6,2]  R2624     1.0942266322672367e-02
    z[8,6,2]  R2625     -9.7748890519142151e-02
    z[8,6,2]  R2626     -1.1095040291547775e-01
    z[8,6,2]  R2627     8.1540994346141815e-02
    z[8,6,2]  R2628     1.9990071654319763e-02
    z[8,6,2]  R2629     3.3385327458381653e-01
    z[8,6,2]  R2630     -6.5134182572364807e-02
    z[8,6,2]  R2631     4.1693288087844849e-01
    z[8,6,2]  R2632     -3.3540013432502747e-01
    z[8,6,2]  R2633     3.5556885600090027e-01
    z[8,6,2]  R2634     -1.6824441030621529e-02
    z[8,6,2]  R2635     1.4960496127605438e-01
    z[8,6,2]  R2636     3.2649624347686768e-01
    z[8,6,2]  R2637     -5.8190923929214478e-01
    z[8,6,2]  R2638     -5.5336314439773560e-01
    z[8,6,2]  R2639     2.8686735033988953e-01
    z[8,6,2]  R2640     4.7996678948402405e-01
    z[8,6,2]  R2641     3.2032766938209534e-01
    z[8,6,2]  R2642     0.468130499124527
    z[8,6,2]  R2643     8.5109126567840576e-01
    z[8,6,2]  R2644     5.6741166114807129e-01
    z[8,6,2]  R2645     5.0181424617767334e-01
    z[8,6,2]  R2646     6.3314098119735718e-01
    z[8,6,2]  R2647     -4.0242251753807068e-01
    z[8,6,2]  R2648     6.1131817102432251e-01
    z[8,6,2]  R2649     2.3638445138931274e-01
    z[8,6,2]  R2650     -2.1357320249080658e-02
    z[8,6,2]  R2651     1.7076766490936279e-01
    z[8,6,2]  R2652     3.5945731401443481e-01
    z[8,6,2]  R2653     3.8796633481979370e-01
    z[8,6,2]  R2654     3.3352798223495483e-01
    z[8,6,2]  R2655     -7.1650457382202148e-01
    z[8,6,2]  R2656     -7.4348253011703491e-01
    z[8,6,2]  R2657     -4.6164166927337646e-01
    z[8,6,2]  R2658     9.9883466958999634e-02
    z[8,6,2]  R2659     -2.6978502050042152e-02
    z[8,6,2]  R2660     3.1799456477165222e-01
    z[8,6,2]  R2661     5.3231620788574219e-01
    z[8,6,2]  R2662     4.8598667979240417e-01
    z[8,6,2]  R2663     2.3269085586071014e-01
    z[8,6,2]  R2664     3.8618156313896179e-01
    z[8,6,2]  R2665     1.1577173322439194e-01
    z[8,6,2]  R2666     -2.1999187767505646e-01
    z[8,6,2]  R2667     3.9089924097061157e-01
    z[8,6,2]  R2668     3.9018783718347549e-02
    z[8,6,2]  R2669     -3.4256213903427124e-01
    z[8,6,2]  R2670     8.4643848240375519e-02
    z[8,6,2]  R2671     -0.0328790545463562
    z[8,6,2]  R2672     -3.7224420905113220e-01
    z[8,6,2]  R2673     0.0223090797662735
    z[8,6,2]  R2674     7.9673487925902009e-04
    z[8,6,2]  R2675     -1.5540605783462524e-01
    z[8,6,2]  R2676     2.8781020641326904e-01
    z[8,6,2]  R2677     -6.6818159818649292e-01
    z[8,6,2]  R2678     3.0707883834838867e-01
    z[8,6,3]  R59       1
    z[8,6,3]  R77       -1
    z[8,6,3]  R2592     -1
    z[8,6,3]  R2593     1
    z[8,6,3]  R2600     3.3893135190010071e-01
    z[8,6,3]  R2601     1.7238068580627441e-01
    z[8,6,3]  R2602     -8.0694389343261719e-01
    z[8,6,3]  R2603     2.2265070676803589e-01
    z[8,6,3]  R2604     -1.2656930088996887e-01
    z[8,6,3]  R2605     4.0449026226997375e-01
    z[8,6,3]  R2606     -0.569337010383606
    z[8,6,3]  R2607     -6.4385145902633667e-01
    z[8,6,3]  R2608     1.1762108653783798e-02
    z[8,6,3]  R2609     -2.0890416204929352e-01
    z[8,6,3]  R2610     0.820968508720398
    z[8,6,3]  R2611     6.7245924472808838e-01
    z[8,6,3]  R2612     6.3162380456924438e-01
    z[8,6,3]  R2613     7.0842069387435913e-01
    z[8,6,3]  R2614     6.5730887651443481e-01
    z[8,6,3]  R2615     7.4381065368652344e-01
    z[8,6,3]  R2616     8.7322556972503662e-01
    z[8,6,3]  R2617     2.5221675634384155e-01
    z[8,6,3]  R2618     -2.6172018051147461e-01
    z[8,6,3]  R2619     3.6002656817436218e-01
    z[8,6,3]  R2620     3.9744228124618530e-01
    z[8,6,3]  R2621     2.2856892645359039e-01
    z[8,6,3]  R2622     3.2866531610488892e-01
    z[8,6,3]  R2623     -1.9448810815811157e-01
    z[8,6,3]  R2624     -1.3624049723148346e-01
    z[8,6,3]  R2625     1.0560864955186844e-01
    z[8,6,3]  R2626     8.2533389329910278e-02
    z[8,6,3]  R2627     3.7692766636610031e-02
    z[8,6,3]  R2628     1.9963359832763672e-01
    z[8,6,3]  R2629     6.4280843734741211e-01
    z[8,6,3]  R2630     7.4181818962097168e-01
    z[8,6,3]  R2631     8.2144778966903687e-01
    z[8,6,3]  R2632     6.5293055772781372e-01
    z[8,6,3]  R2633     6.0793638229370117e-01
    z[8,6,3]  R2634     -2.7843394875526428e-01
    z[8,6,3]  R2635     -1.4027177821844816e-03
    z[8,6,3]  R2636     -1.1982208490371704e-01
    z[8,6,3]  R2637     -1.3696564733982086e-01
    z[8,6,3]  R2638     -4.2138215899467468e-01
    z[8,6,3]  R2639     -0.258035808801651
    z[8,6,3]  R2640     1.2278497964143753e-01
    z[8,6,3]  R2641     1.5831816196441650e-01
    z[8,6,3]  R2642     -8.6031429469585419e-02
    z[8,6,3]  R2643     1.6550848260521889e-02
    z[8,6,3]  R2644     3.3472830057144165e-01
    z[8,6,3]  R2645     -1.8150122463703156e-01
    z[8,6,3]  R2646     4.3236851692199707e-02
    z[8,6,3]  R2647     2.4676360189914703e-01
    z[8,6,3]  R2648     2.7102762460708618e-01
    z[8,6,3]  R2649     8.2595801353454590e-01
    z[8,6,3]  R2650     5.1190227270126343e-01
    z[8,6,3]  R2651     -4.7305294871330261e-01
    z[8,6,3]  R2652     -4.7772252559661865e-01
    z[8,6,3]  R2653     -2.2916845977306366e-01
    z[8,6,3]  R2654     3.6530005931854248e-01
    z[8,6,3]  R2655     2.2059649229049683e-01
    z[8,6,3]  R2656     0.436553955078125
    z[8,6,3]  R2657     2.1341089904308319e-01
    z[8,6,3]  R2658     8.2821629941463470e-02
    z[8,6,3]  R2659     4.1775268316268921e-01
    z[8,6,3]  R2660     1.7087125778198242e-01
    z[8,6,3]  R2661     6.1872269958257675e-02
    z[8,6,3]  R2662     -2.9044350981712341e-01
    z[8,6,3]  R2663     2.3048759996891022e-01
    z[8,6,3]  R2664     1.4789731800556183e-01
    z[8,6,3]  R2665     2.0402505993843079e-02
    z[8,6,3]  R2666     4.0229588747024536e-01
    z[8,6,3]  R2667     5.2630184218287468e-03
    z[8,6,3]  R2668     8.6509138345718384e-02
    z[8,6,3]  R2669     -2.4839197099208832e-01
    z[8,6,3]  R2670     -4.9620926380157471e-01
    z[8,6,3]  R2671     -2.7569499611854553e-01
    z[8,6,3]  R2672     -1.9026175141334534e-02
    z[8,6,3]  R2673     5.1256150007247925e-01
    z[8,6,3]  R2674     3.8620454072952271e-01
    z[8,6,3]  R2675     7.3760688304901123e-01
    z[8,6,3]  R2676     5.5118137598037720e-01
    z[8,6,3]  R2677     -5.6256562471389771e-01
    z[8,6,3]  R2678     4.1415810585021973e-01
    z[8,6,4]  R60       1
    z[8,6,4]  R78       -1
    z[8,6,4]  R2594     -1
    z[8,6,4]  R2595     1
    z[8,6,4]  R2600     6.1544120311737061e-01
    z[8,6,4]  R2601     -1.6038011014461517e-01
    z[8,6,4]  R2602     -4.4960159808397293e-02
    z[8,6,4]  R2603     3.2772939652204514e-02
    z[8,6,4]  R2604     2.4203942716121674e-01
    z[8,6,4]  R2605     -7.1600514650344849e-01
    z[8,6,4]  R2606     -4.7515761852264404e-01
    z[8,6,4]  R2607     -4.7687861323356628e-01
    z[8,6,4]  R2608     -1.4801302552223206e-01
    z[8,6,4]  R2609     -8.6326800286769867e-02
    z[8,6,4]  R2610     -1.1482661962509155e-01
    z[8,6,4]  R2611     -7.4615702033042908e-03
    z[8,6,4]  R2612     -1.4398986101150513e-01
    z[8,6,4]  R2613     3.1648358702659607e-01
    z[8,6,4]  R2614     8.5796646773815155e-02
    z[8,6,4]  R2615     1.6937313973903656e-01
    z[8,6,4]  R2616     3.5484090447425842e-01
    z[8,6,4]  R2617     -5.3575527854263783e-03
    z[8,6,4]  R2618     -5.2903532981872559e-02
    z[8,6,4]  R2619     -5.3471463918685913e-01
    z[8,6,4]  R2620     -0.59151291847229
    z[8,6,4]  R2621     -7.9646848142147064e-02
    z[8,6,4]  R2622     -0.0201775711029768
    z[8,6,4]  R2623     4.5154165476560593e-02
    z[8,6,4]  R2624     1.6619296371936798e-01
    z[8,6,4]  R2625     1.6266991198062897e-01
    z[8,6,4]  R2626     -3.7581852078437805e-01
    z[8,6,4]  R2627     -2.7733482420444489e-03
    z[8,6,4]  R2628     2.2970676422119141e-01
    z[8,6,4]  R2629     -1.4652857184410095e-01
    z[8,6,4]  R2630     1.3311018049716949e-01
    z[8,6,4]  R2631     2.1338362246751785e-02
    z[8,6,4]  R2632     -4.9263462424278259e-01
    z[8,6,4]  R2633     1.3779577612876892e-01
    z[8,6,4]  R2634     -3.4126002341508865e-02
    z[8,6,4]  R2635     -1.0386031121015549e-01
    z[8,6,4]  R2636     -1.1333167552947998e-02
    z[8,6,4]  R2637     1.8678863346576691e-01
    z[8,6,4]  R2638     1.9302532076835632e-02
    z[8,6,4]  R2639     3.0593115091323853e-01
    z[8,6,4]  R2640     6.5106144174933434e-03
    z[8,6,4]  R2641     -4.5229992270469666e-01
    z[8,6,4]  R2642     -3.1586790084838867e-01
    z[8,6,4]  R2643     0.0892091765999794
    z[8,6,4]  R2644     -2.5338403880596161e-02
    z[8,6,4]  R2645     -8.6166240274906158e-02
    z[8,6,4]  R2646     -4.0733799338340759e-01
    z[8,6,4]  R2647     -1.0798192024230957e-01
    z[8,6,4]  R2648     -3.9711430668830872e-01
    z[8,6,4]  R2649     2.8151612728834152e-02
    z[8,6,4]  R2650     9.6242956817150116e-02
    z[8,6,4]  R2651     0.629560112953186
    z[8,6,4]  R2652     2.3625931143760681e-01
    z[8,6,4]  R2653     -9.6024684607982635e-02
    z[8,6,4]  R2654     5.7412409782409668e-01
    z[8,6,4]  R2655     3.5405838489532471e-01
    z[8,6,4]  R2656     7.6192080974578857e-02
    z[8,6,4]  R2657     -3.4034612774848938e-01
    z[8,6,4]  R2658     1.1436818540096283e-01
    z[8,6,4]  R2659     3.0561983585357666e-01
    z[8,6,4]  R2660     -2.8432181477546692e-01
    z[8,6,4]  R2661     2.3806239664554596e-01
    z[8,6,4]  R2662     -2.4416035413742065e-01
    z[8,6,4]  R2663     5.5884812027215958e-02
    z[8,6,4]  R2664     4.0759924799203873e-02
    z[8,6,4]  R2665     -0.142137348651886
    z[8,6,4]  R2666     -1.2161013484001160e-01
    z[8,6,4]  R2667     2.0110353827476501e-01
    z[8,6,4]  R2668     4.0101557970046997e-01
    z[8,6,4]  R2669     -2.5878927111625671e-01
    z[8,6,4]  R2670     3.3145558834075928e-01
    z[8,6,4]  R2671     -1.4004895463585854e-02
    z[8,6,4]  R2672     8.0085322260856628e-02
    z[8,6,4]  R2673     -1.9381056725978851e-01
    z[8,6,4]  R2674     2.7783846855163574e-01
    z[8,6,4]  R2675     -4.5912593603134155e-02
    z[8,6,4]  R2676     -4.2880815267562866e-01
    z[8,6,4]  R2677     -2.3255331814289093e-01
    z[8,6,4]  R2678     7.3434972763061523e-01
    z[8,6,5]  R61       1
    z[8,6,5]  R79       -1
    z[8,6,5]  R2596     -1
    z[8,6,5]  R2597     1
    z[8,6,5]  R2600     1.3929626345634460e-01
    z[8,6,5]  R2601     -3.5279604792594910e-01
    z[8,6,5]  R2602     3.8220237940549850e-02
    z[8,6,5]  R2603     2.1354711055755615e-01
    z[8,6,5]  R2604     -4.0999558568000793e-01
    z[8,6,5]  R2605     8.4200963377952576e-02
    z[8,6,5]  R2606     2.8404369950294495e-01
    z[8,6,5]  R2607     3.8109812140464783e-01
    z[8,6,5]  R2608     7.8728175163269043e-01
    z[8,6,5]  R2609     6.7090344429016113e-01
    z[8,6,5]  R2610     3.5295647382736206e-01
    z[8,6,5]  R2611     -2.4163994938135147e-02
    z[8,6,5]  R2612     2.7940610051155090e-01
    z[8,6,5]  R2613     2.9542475938796997e-02
    z[8,6,5]  R2614     2.8805750608444214e-01
    z[8,6,5]  R2615     -1.4151780307292938e-01
    z[8,6,5]  R2616     -5.8375686407089233e-02
    z[8,6,5]  R2617     5.0904947519302368e-01
    z[8,6,5]  R2618     -2.0721639692783356e-01
    z[8,6,5]  R2619     2.2999155521392822e-01
    z[8,6,5]  R2620     1.7055776715278625e-01
    z[8,6,5]  R2621     4.8161312937736511e-01
    z[8,6,5]  R2622     -1.8148081004619598e-01
    z[8,6,5]  R2623     0.072996124625206
    z[8,6,5]  R2624     -1.3415264897048473e-02
    z[8,6,5]  R2625     2.1625134348869324e-01
    z[8,6,5]  R2626     0.118670254945755
    z[8,6,5]  R2627     -0.221003919839859
    z[8,6,5]  R2628     -3.0883875489234924e-01
    z[8,6,5]  R2629     -1.3896717131137848e-01
    z[8,6,5]  R2630     3.2583504915237427e-01
    z[8,6,5]  R2631     -8.8345922529697418e-02
    z[8,6,5]  R2632     2.5804251432418823e-01
    z[8,6,5]  R2633     2.5488847494125366e-01
    z[8,6,5]  R2634     -0.0645069107413292
    z[8,6,5]  R2635     2.2342254221439362e-01
    z[8,6,5]  R2636     5.1044980064034462e-03
    z[8,6,5]  R2637     -2.3616391420364380e-01
    z[8,6,5]  R2638     -3.1501868367195129e-01
    z[8,6,5]  R2639     -1.1195619404315948e-01
    z[8,6,5]  R2640     1.8842902779579163e-01
    z[8,6,5]  R2641     2.4268217384815216e-01
    z[8,6,5]  R2642     -2.8632253408432007e-01
    z[8,6,5]  R2643     -7.0227861404418945e-02
    z[8,6,5]  R2644     -3.1152474880218506e-01
    z[8,6,5]  R2645     1.0080326348543167e-01
    z[8,6,5]  R2646     -1.7867214977741241e-01
    z[8,6,5]  R2647     2.6090887188911438e-01
    z[8,6,5]  R2648     3.1812575459480286e-01
    z[8,6,5]  R2649     3.4749977290630341e-02
    z[8,6,5]  R2650     2.6824250817298889e-01
    z[8,6,5]  R2651     -1.3079972565174103e-01
    z[8,6,5]  R2652     1.5704709291458130e-01
    z[8,6,5]  R2653     -7.0687431097030640e-01
    z[8,6,5]  R2654     -2.5559765100479126e-01
    z[8,6,5]  R2655     2.6255035400390625e-01
    z[8,6,5]  R2656     -1.4988008141517639e-01
    z[8,6,5]  R2657     0.286690354347229
    z[8,6,5]  R2658     2.8930592536926270e-01
    z[8,6,5]  R2659     3.4431774169206619e-02
    z[8,6,5]  R2660     -1.0478625446557999e-01
    z[8,6,5]  R2661     -2.1493105590343475e-01
    z[8,6,5]  R2662     -3.1095145270228386e-02
    z[8,6,5]  R2663     -1.9912435114383698e-01
    z[8,6,5]  R2664     0.402570903301239
    z[8,6,5]  R2665     3.1461000442504883e-01
    z[8,6,5]  R2666     -2.0663768053054810e-01
    z[8,6,5]  R2667     1.7251954972743988e-01
    z[8,6,5]  R2668     -4.0156453847885132e-01
    z[8,6,5]  R2669     1.4101035892963409e-01
    z[8,6,5]  R2670     2.3707848787307739e-01
    z[8,6,5]  R2671     -2.9156050086021423e-01
    z[8,6,5]  R2672     -3.1166058778762817e-01
    z[8,6,5]  R2673     5.4415595531463623e-01
    z[8,6,5]  R2674     -2.9116401076316833e-01
    z[8,6,5]  R2675     -6.4724549651145935e-02
    z[8,6,5]  R2676     2.5215440988540649e-01
    z[8,6,5]  R2677     -3.9865810424089432e-02
    z[8,6,5]  R2678     0.284146785736084
    z[8,6,6]  R62       1
    z[8,6,6]  R80       -1
    z[8,6,6]  R2598     -1
    z[8,6,6]  R2599     1
    z[8,6,6]  R2600     -2.7296485379338264e-02
    z[8,6,6]  R2601     -6.9551318883895874e-01
    z[8,6,6]  R2602     -9.9850669503211975e-03
    z[8,6,6]  R2603     1.2903241813182831e-01
    z[8,6,6]  R2604     0.614565372467041
    z[8,6,6]  R2605     4.7373369336128235e-01
    z[8,6,6]  R2606     -9.6105104312300682e-03
    z[8,6,6]  R2607     -1.6487258672714233e-01
    z[8,6,6]  R2608     -3.3270925283432007e-01
    z[8,6,6]  R2609     -1.5050514601171017e-02
    z[8,6,6]  R2610     2.5339301675558090e-02
    z[8,6,6]  R2611     4.1012936830520630e-01
    z[8,6,6]  R2612     -2.2790496051311493e-01
    z[8,6,6]  R2613     1.9731713831424713e-01
    z[8,6,6]  R2614     -8.0265142023563385e-02
    z[8,6,6]  R2615     -2.3283023387193680e-02
    z[8,6,6]  R2616     9.9094063043594360e-02
    z[8,6,6]  R2617     3.0142712593078613e-01
    z[8,6,6]  R2618     1.8220894038677216e-01
    z[8,6,6]  R2619     1.3260385394096375e-01
    z[8,6,6]  R2620     3.8297748565673828e-01
    z[8,6,6]  R2621     2.5355115532875061e-01
    z[8,6,6]  R2622     1.6693432629108429e-01
    z[8,6,6]  R2623     1.8298017978668213e-01
    z[8,6,6]  R2624     3.3461713790893555e-01
    z[8,6,6]  R2625     1.3354423642158508e-01
    z[8,6,6]  R2626     3.5253062844276428e-02
    z[8,6,6]  R2627     -3.4190145134925842e-01
    z[8,6,6]  R2628     3.3973187208175659e-02
    z[8,6,6]  R2629     3.8801971077919006e-01
    z[8,6,6]  R2630     3.2108667492866516e-01
    z[8,6,6]  R2631     2.4911326169967651e-01
    z[8,6,6]  R2632     2.7404436469078064e-01
    z[8,6,6]  R2633     2.4183419346809387e-01
    z[8,6,6]  R2634     -1.0881573706865311e-01
    z[8,6,6]  R2635     -2.9862526059150696e-01
    z[8,6,6]  R2636     0.0569380484521389
    z[8,6,6]  R2637     -5.3832545876502991e-02
    z[8,6,6]  R2638     -2.0913438498973846e-01
    z[8,6,6]  R2639     -2.1279849112033844e-01
    z[8,6,6]  R2640     4.5877873897552490e-02
    z[8,6,6]  R2641     -2.1587008610367775e-02
    z[8,6,6]  R2642     -1.8798071146011353e-01
    z[8,6,6]  R2643     5.2520852535963058e-02
    z[8,6,6]  R2644     -3.2697860151529312e-02
    z[8,6,6]  R2645     3.2514709234237671e-01
    z[8,6,6]  R2646     3.3500474691390991e-01
    z[8,6,6]  R2647     -7.1647331118583679e-02
    z[8,6,6]  R2648     3.5818368196487427e-01
    z[8,6,6]  R2649     -1.2113984674215317e-01
    z[8,6,6]  R2650     0.0630001500248909
    z[8,6,6]  R2651     -1.8945485353469849e-01
    z[8,6,6]  R2652     -4.0386196970939636e-01
    z[8,6,6]  R2653     -0.0329107791185379
    z[8,6,6]  R2654     5.5236298590898514e-02
    z[8,6,6]  R2655     2.0116844773292542e-01
    z[8,6,6]  R2656     -2.6413249969482422e-01
    z[8,6,6]  R2657     -2.9550895094871521e-01
    z[8,6,6]  R2658     -2.4038228392601013e-01
    z[8,6,6]  R2659     -1.9249269366264343e-01
    z[8,6,6]  R2660     2.4628737568855286e-01
    z[8,6,6]  R2661     -2.1937627345323563e-02
    z[8,6,6]  R2662     -1.7732024192810059e-02
    z[8,6,6]  R2663     2.5335814803838730e-02
    z[8,6,6]  R2664     -1.4237202703952789e-02
    z[8,6,6]  R2665     -2.0964252948760986e-01
    z[8,6,6]  R2666     -1.3886238634586334e-01
    z[8,6,6]  R2667     0.396258682012558
    z[8,6,6]  R2668     -7.3812879621982574e-02
    z[8,6,6]  R2669     -4.7473390586674213e-03
    z[8,6,6]  R2670     1.1666963808238506e-02
    z[8,6,6]  R2671     -4.2950114607810974e-01
    z[8,6,6]  R2672     2.1697996556758881e-01
    z[8,6,6]  R2673     -3.2839265465736389e-01
    z[8,6,6]  R2674     -3.5264673829078674e-01
    z[8,6,6]  R2675     -4.8314219713211060e-01
    z[8,6,6]  R2676     -4.2768004536628723e-01
    z[8,6,6]  R2677     8.9470840990543365e-02
    z[8,6,6]  R2678     -2.0651248097419739e-01
    z[7,8,0]  R65       -1
    z[7,8,0]  R74       1
    z[7,8,0]  R2679     -1
    z[7,8,0]  R2680     1
    z[7,8,0]  R2693     -3.9254170656204224e-01
    z[7,8,0]  R2694     -2.3913398385047913e-01
    z[7,8,0]  R2695     -4.2164230346679688e-01
    z[7,8,0]  R2696     -4.6761247515678406e-01
    z[7,8,0]  R2697     -6.8008285760879517e-01
    z[7,8,0]  R2698     -6.4544725418090820e-01
    z[7,8,0]  R2699     -9.2244094610214233e-01
    z[7,8,0]  R2700     -4.7562113404273987e-01
    z[7,8,0]  R2701     -5.7857674360275269e-01
    z[7,8,0]  R2702     -0.748253583908081
    z[7,8,0]  R2703     5.2099150419235229e-01
    z[7,8,0]  R2704     5.5208230018615723e-01
    z[7,8,0]  R2705     4.7966101765632629e-01
    z[7,8,0]  R2706     5.6979340314865112e-01
    z[7,8,0]  R2707     0.41551673412323
    z[7,8,0]  R2708     3.0027130246162415e-01
    z[7,8,0]  R2709     5.6916791200637817e-01
    z[7,8,0]  R2710     3.7578943371772766e-01
    z[7,8,0]  R2711     2.2402296960353851e-01
    z[7,8,0]  R2712     3.7969928979873657e-01
    z[7,8,0]  R2713     2.6223802566528320e-01
    z[7,8,0]  R2714     3.6775204539299011e-01
    z[7,8,0]  R2715     -2.1203437820076942e-02
    z[7,8,0]  R2716     -1.3206343166530132e-02
    z[7,8,0]  R2717     2.8164750337600708e-01
    z[7,8,0]  R2718     -8.9676812291145325e-02
    z[7,8,0]  R2719     6.2856757640838623e-01
    z[7,8,0]  R2720     3.4075993299484253e-01
    z[7,8,0]  R2721     -1.3045547902584076e-01
    z[7,8,0]  R2722     -3.4689339995384216e-01
    z[7,8,0]  R2723     3.5286378860473633e-01
    z[7,8,0]  R2724     3.8080233335494995e-01
    z[7,8,0]  R2725     -0.586037814617157
    z[7,8,0]  R2726     -0.0869353786110878
    z[7,8,0]  R2727     -7.7154916524887085e-01
    z[7,8,0]  R2728     5.7940429449081421e-01
    z[7,8,0]  R2729     -6.0262113809585571e-01
    z[7,8,0]  R2730     -9.5427431166172028e-02
    z[7,8,0]  R2731     -3.0859872698783875e-01
    z[7,8,0]  R2732     -5.2074217796325684e-01
    z[7,8,0]  R2733     -9.4161635637283325e-01
    z[7,8,0]  R2734     -8.1056392192840576e-01
    z[7,8,0]  R2735     3.9836764335632324e-01
    z[7,8,0]  R2736     7.0478290319442749e-02
    z[7,8,0]  R2737     -5.9895825386047363e-01
    z[7,8,0]  R2738     2.6351484656333923e-01
    z[7,8,0]  R2739     -1.5788662433624268e-01
    z[7,8,0]  R2740     -6.1514323949813843e-01
    z[7,8,0]  R2741     -3.8206470012664795e-01
    z[7,8,0]  R2742     -1.1098635941743851e-01
    z[7,8,0]  R2743     -6.7380934953689575e-01
    z[7,8,0]  R2744     0.543727457523346
    z[7,8,0]  R2745     -7.9898262023925781e-01
    z[7,8,0]  R2746     7.9587094485759735e-02
    z[7,8,0]  R2747     -5.8735519647598267e-01
    z[7,8,0]  R2748     -1.9871200621128082e-01
    z[7,8,0]  R2749     -5.9651982784271240e-01
    z[7,8,0]  R2750     1.5138798952102661e-01
    z[7,8,0]  R2751     -1.5813054144382477e-01
    z[7,8,0]  R2752     -4.7670900821685791e-01
    z[7,8,0]  R2753     3.3887746930122375e-01
    z[7,8,0]  R2754     -8.8683640956878662e-01
    z[7,8,0]  R2755     3.9698880910873413e-01
    z[7,8,0]  R2756     -5.4121297597885132e-01
    z[7,8,0]  R2757     2.5448048114776611e-01
    z[7,8,0]  R2758     1.7015197873115540e-01
    z[7,8,0]  R2759     -3.7779429554939270e-01
    z[7,8,0]  R2760     -4.4674339890480042e-01
    z[7,8,0]  R2761     -3.5545790195465088e-01
    z[7,8,0]  R2762     6.5151005983352661e-01
    z[7,8,0]  R2763     -6.8009203672409058e-01
    z[7,8,0]  R2764     3.2066974788904190e-02
    z[7,8,0]  R2765     -7.2874939441680908e-01
    z[7,8,0]  R2766     -5.9182637929916382e-01
    z[7,8,0]  R2767     -2.6132553815841675e-01
    z[7,8,0]  R2768     2.8182464838027954e-01
    z[7,8,0]  R2769     2.1349306404590607e-01
    z[7,8,0]  R2770     -9.1540098190307617e-02
    z[7,8,0]  R2771     -5.4024338722229004e-02
    z[7,8,0]  R2772     3.6885675042867661e-02
    z[7,8,0]  R2773     -8.9066106081008911e-01
    z[7,8,0]  R2774     4.4937521219253540e-01
    z[7,8,0]  R2775     0.754943311214447
    z[7,8,0]  R2776     -5.8507156372070312e-01
    z[7,8,0]  R2777     2.8378924727439880e-01
    z[7,8,0]  R2778     7.8624807298183441e-02
    z[7,8,0]  R2779     1.2666773796081543e-01
    z[7,8,0]  R2780     9.6525497734546661e-02
    z[7,8,0]  R2781     -1.7874591052532196e-01
    z[7,8,0]  R2782     -1.5020088851451874e-01
    z[7,8,0]  R2783     -5.4492527246475220e-01
    z[7,8,0]  R2784     -2.1534349024295807e-01
    z[7,8,0]  R2785     -4.7673907876014709e-01
    z[7,8,0]  R2786     -9.1472655534744263e-01
    z[7,8,0]  R2787     -4.9899551272392273e-01
    z[7,8,0]  R2788     1.7937442660331726e-01
    z[7,8,0]  R2789     8.3233872428536415e-03
    z[7,8,0]  R2790     -1.1779731512069702e-01
    z[7,8,0]  R2791     7.5718045234680176e-02
    z[7,8,0]  R2792     4.3023101985454559e-02
    z[7,8,0]  R2793     2.5510627031326294e-01
    z[7,8,0]  R2794     0.611352801322937
    z[7,8,0]  R2795     6.4501678943634033e-01
    z[7,8,0]  R2796     5.7139158248901367e-01
    z[7,8,0]  R2797     5.8158326148986816e-01
    z[7,8,0]  R2798     3.6221036314964294e-01
    z[7,8,0]  R2799     2.8853756189346313e-01
    z[7,8,0]  R2800     3.1469497084617615e-01
    z[7,8,0]  R2801     2.6581883430480957e-01
    z[7,8,0]  R2802     5.8376115560531616e-01
    z[7,8,0]  R2803     3.7380585074424744e-01
    z[7,8,0]  R2804     4.8549342155456543e-01
    z[7,8,0]  R2805     6.9221824407577515e-01
    z[7,8,0]  R2806     2.0233023166656494e-01
    z[7,8,0]  R2807     1.2574322521686554e-01
    z[7,8,0]  R2808     2.5684067606925964e-01
    z[7,8,0]  R2809     1.1671365052461624e-01
    z[7,8,0]  R2810     2.3870217800140381e-01
    z[7,8,0]  R2811     1.5381184220314026e-01
    z[7,8,0]  R2812     5.1420134305953979e-01
    z[7,8,0]  R2813     2.2655582427978516e-01
    z[7,8,0]  R2814     0.283189594745636
    z[7,8,0]  R2815     2.7601400017738342e-01
    z[7,8,0]  R2816     3.5650694370269775e-01
    z[7,8,0]  R2817     2.8758205473423004e-02
    z[7,8,0]  R2818     2.2294494509696960e-01
    z[7,8,0]  R2819     2.8574812412261963e-01
    z[7,8,0]  R2820     -5.9725034981966019e-02
    z[7,8,0]  R2821     -0.0819258838891983
    z[7,8,1]  R66       -1
    z[7,8,1]  R75       1
    z[7,8,1]  R2681     -1
    z[7,8,1]  R2682     1
    z[7,8,1]  R2693     8.6168175935745239e-01
    z[7,8,1]  R2694     9.5194482803344727e-01
    z[7,8,1]  R2695     8.3967870473861694e-01
    z[7,8,1]  R2696     7.5791954994201660e-01
    z[7,8,1]  R2697     6.5164351463317871e-01
    z[7,8,1]  R2698     0.60193932056427
    z[7,8,1]  R2699     1.8296839296817780e-01
    z[7,8,1]  R2700     7.0275247097015381e-01
    z[7,8,1]  R2701     6.4181548357009888e-01
    z[7,8,1]  R2702     6.2443137168884277e-01
    z[7,8,1]  R2703     -0.166351318359375
    z[7,8,1]  R2704     1.9614227116107941e-01
    z[7,8,1]  R2705     1.2256369739770889e-01
    z[7,8,1]  R2706     -6.2041327357292175e-02
    z[7,8,1]  R2707     -3.0906911939382553e-02
    z[7,8,1]  R2708     1.1112090200185776e-01
    z[7,8,1]  R2709     -3.3025091886520386e-01
    z[7,8,1]  R2710     -2.3501524329185486e-01
    z[7,8,1]  R2711     -8.1570070981979370e-01
    z[7,8,1]  R2712     -1.1152768507599831e-02
    z[7,8,1]  R2713     4.8224860429763794e-01
    z[7,8,1]  R2714     2.8804332017898560e-01
    z[7,8,1]  R2715     -0.904996395111084
    z[7,8,1]  R2716     -8.0651009082794189e-01
    z[7,8,1]  R2717     -7.4384588003158569e-01
    z[7,8,1]  R2718     -6.9912791252136230e-01
    z[7,8,1]  R2719     -7.4209755659103394e-01
    z[7,8,1]  R2720     -7.4391418695449829e-01
    z[7,8,1]  R2721     -8.3136105537414551e-01
    z[7,8,1]  R2722     -7.9074168205261230e-01
    z[7,8,1]  R2723     3.5440880060195923e-01
    z[7,8,1]  R2724     -1.8497738242149353e-01
    z[7,8,1]  R2725     3.6687543988227844e-01
    z[7,8,1]  R2726     -8.6033952236175537e-01
    z[7,8,1]  R2727     -0.104481041431427
    z[7,8,1]  R2728     5.4912644624710083e-01
    z[7,8,1]  R2729     -2.0457734167575836e-01
    z[7,8,1]  R2730     -8.8429284095764160e-01
    z[7,8,1]  R2731     -7.8451168537139893e-01
    z[7,8,1]  R2732     -0.317264199256897
    z[7,8,1]  R2733     0.0891835018992424
    z[7,8,1]  R2734     3.3691781759262085e-01
    z[7,8,1]  R2735     4.4969987869262695e-01
    z[7,8,1]  R2736     2.7287730574607849e-01
    z[7,8,1]  R2737     1.3377930968999863e-02
    z[7,8,1]  R2738     -9.3052148818969727e-01
    z[7,8,1]  R2739     -8.7759679555892944e-01
    z[7,8,1]  R2740     9.5067918300628662e-02
    z[7,8,1]  R2741     4.3363296985626221e-01
    z[7,8,1]  R2742     -8.2585883140563965e-01
    z[7,8,1]  R2743     2.8689932823181152e-01
    z[7,8,1]  R2744     5.7964378595352173e-01
    z[7,8,1]  R2745     3.8527809083461761e-02
    z[7,8,1]  R2746     -2.5478392839431763e-01
    z[7,8,1]  R2747     0.0353827103972435
    z[7,8,1]  R2748     -9.1124457120895386e-01
    z[7,8,1]  R2749     -0.662040114402771
    z[7,8,1]  R2750     -7.8357911109924316e-01
    z[7,8,1]  R2751     -7.6083678007125854e-01
    z[7,8,1]  R2752     -4.1661381721496582e-01
    z[7,8,1]  R2753     -1.3202227652072906e-02
    z[7,8,1]  R2754     2.2526440024375916e-01
    z[7,8,1]  R2755     -4.9321573227643967e-02
    z[7,8,1]  R2756     3.2392221689224243e-01
    z[7,8,1]  R2757     -8.1055295467376709e-01
    z[7,8,1]  R2758     -7.8756111860275269e-01
    z[7,8,1]  R2759     -7.8263121843338013e-01
    z[7,8,1]  R2760     -7.6649588346481323e-01
    z[7,8,1]  R2761     -3.5260787606239319e-01
    z[7,8,1]  R2762     6.2596333026885986e-01
    z[7,8,1]  R2763     3.2141822576522827e-01
    z[7,8,1]  R2764     3.8521626591682434e-01
    z[7,8,1]  R2765     -5.0963733345270157e-02
    z[7,8,1]  R2766     -2.4608006700873375e-02
    z[7,8,1]  R2767     -8.7529158592224121e-01
    z[7,8,1]  R2768     -8.6956137418746948e-01
    z[7,8,1]  R2769     -8.2586467266082764e-01
    z[7,8,1]  R2770     -8.3300560712814331e-01
    z[7,8,1]  R2771     -9.1836810111999512e-01
    z[7,8,1]  R2772     5.6905514001846313e-01
    z[7,8,1]  R2773     3.3987060189247131e-01
    z[7,8,1]  R2774     5.3938800096511841e-01
    z[7,8,1]  R2775     1.8245634436607361e-01
    z[7,8,1]  R2776     -5.8379560708999634e-01
    z[7,8,1]  R2777     -0.758469820022583
    z[7,8,1]  R2778     0.500398576259613
    z[7,8,1]  R2779     -4.0672817826271057e-01
    z[7,8,1]  R2780     -2.7699694037437439e-01
    z[7,8,1]  R2781     -1.3899168372154236e-01
    z[7,8,1]  R2782     -2.8170236945152283e-01
    z[7,8,1]  R2783     4.3278518319129944e-01
    z[7,8,1]  R2784     5.2865236997604370e-01
    z[7,8,1]  R2785     3.2280489802360535e-02
    z[7,8,1]  R2786     -1.0213023424148560e-01
    z[7,8,1]  R2787     3.5205683112144470e-01
    z[7,8,1]  R2788     0.0873582735657692
    z[7,8,1]  R2789     3.0650734901428223e-01
    z[7,8,1]  R2790     -1.1546940356492996e-01
    z[7,8,1]  R2791     -8.3069734275341034e-02
    z[7,8,1]  R2792     2.9835087060928345e-01
    z[7,8,1]  R2793     -0.0591592937707901
    z[7,8,1]  R2794     -6.5233409404754639e-02
    z[7,8,1]  R2795     -1.7246234416961670e-01
    z[7,8,1]  R2796     5.4489899426698685e-02
    z[7,8,1]  R2797     -7.5519219040870667e-02
    z[7,8,1]  R2798     -2.4127402901649475e-01
    z[7,8,1]  R2799     -6.4986400306224823e-02
    z[7,8,1]  R2800     6.6145914793014526e-01
    z[7,8,1]  R2801     -8.6502122879028320e-01
    z[7,8,1]  R2802     2.5387245416641235e-01
    z[7,8,1]  R2803     3.3545008301734924e-01
    z[7,8,1]  R2804     0.605156421661377
    z[7,8,1]  R2805     1.9629713892936707e-01
    z[7,8,1]  R2806     -0.922296404838562
    z[7,8,1]  R2807     -9.0870171785354614e-01
    z[7,8,1]  R2808     -9.0678805112838745e-01
    z[7,8,1]  R2809     -9.0038394927978516e-01
    z[7,8,1]  R2810     -8.7704312801361084e-01
    z[7,8,1]  R2811     -8.8701063394546509e-01
    z[7,8,1]  R2812     1.3998055458068848e-01
    z[7,8,1]  R2813     4.0884265303611755e-01
    z[7,8,1]  R2814     2.9602622613310814e-02
    z[7,8,1]  R2815     2.5092095136642456e-02
    z[7,8,1]  R2816     4.8419770598411560e-01
    z[7,8,1]  R2817     -0.950893223285675
    z[7,8,1]  R2818     -8.8206022977828979e-01
    z[7,8,1]  R2819     -8.9106363058090210e-01
    z[7,8,1]  R2820     -7.3857551813125610e-01
    z[7,8,1]  R2821     -6.0511809587478638e-01
    z[7,8,2]  R67       -1
    z[7,8,2]  R76       1
    z[7,8,2]  R2683     -1
    z[7,8,2]  R2684     1
    z[7,8,2]  R2693     -4.6933200210332870e-02
    z[7,8,2]  R2694     -1.1756887659430504e-02
    z[7,8,2]  R2695     0.148001566529274
    z[7,8,2]  R2696     1.7065636813640594e-01
    z[7,8,2]  R2697     -1.1008264124393463e-01
    z[7,8,2]  R2698     1.7419527471065521e-01
    z[7,8,2]  R2699     2.6829114556312561e-01
    z[7,8,2]  R2700     3.6461880803108215e-01
    z[7,8,2]  R2701     1.4063043892383575e-01
    z[7,8,2]  R2702     -0.0342351458966732
    z[7,8,2]  R2703     2.0866812765598297e-01
    z[7,8,2]  R2704     3.6729472875595093e-01
    z[7,8,2]  R2705     3.6069635301828384e-02
    z[7,8,2]  R2706     -5.5398438125848770e-02
    z[7,8,2]  R2707     3.2442143559455872e-01
    z[7,8,2]  R2708     5.2716922014951706e-02
    z[7,8,2]  R2709     -1.0509991645812988e-01
    z[7,8,2]  R2710     1.1707766354084015e-01
    z[7,8,2]  R2711     -4.1049256920814514e-01
    z[7,8,2]  R2712     -3.7668108940124512e-02
    z[7,8,2]  R2713     -3.5654169321060181e-01
    z[7,8,2]  R2714     -0.135230153799057
    z[7,8,2]  R2715     1.7250137403607368e-02
    z[7,8,2]  R2716     -1.4609888195991516e-01
    z[7,8,2]  R2717     -6.6297873854637146e-02
    z[7,8,2]  R2718     2.2318531572818756e-01
    z[7,8,2]  R2719     3.1908690929412842e-02
    z[7,8,2]  R2720     7.6484262943267822e-02
    z[7,8,2]  R2721     6.1499748378992081e-02
    z[7,8,2]  R2722     2.4359221756458282e-01
    z[7,8,2]  R2723     1.7425008118152618e-01
    z[7,8,2]  R2724     -1.3354432582855225e-01
    z[7,8,2]  R2725     -1.3887584209442139e-01
    z[7,8,2]  R2726     -3.9314043521881104e-01
    z[7,8,2]  R2727     1.2395108491182327e-01
    z[7,8,2]  R2728     1.6706761717796326e-01
    z[7,8,2]  R2729     4.9057373404502869e-01
    z[7,8,2]  R2730     2.4277816712856293e-01
    z[7,8,2]  R2731     -1.8345075845718384e-01
    z[7,8,2]  R2732     5.1877623796463013e-01
    z[7,8,2]  R2733     0.0737726092338562
    z[7,8,2]  R2734     4.3167144060134888e-02
    z[7,8,2]  R2735     6.4395293593406677e-02
    z[7,8,2]  R2736     2.7652397751808167e-01
    z[7,8,2]  R2737     6.4655095338821411e-01
    z[7,8,2]  R2738     1.6862362623214722e-01
    z[7,8,2]  R2739     -2.0928969606757164e-02
    z[7,8,2]  R2740     1.7930777370929718e-01
    z[7,8,2]  R2741     3.1241157650947571e-01
    z[7,8,2]  R2742     -1.7183783650398254e-01
    z[7,8,2]  R2743     3.9254274964332581e-01
    z[7,8,2]  R2744     2.8326365351676941e-01
    z[7,8,2]  R2745     4.5729362964630127e-01
    z[7,8,2]  R2746     1.0710256546735764e-01
    z[7,8,2]  R2747     2.5877770781517029e-01
    z[7,8,2]  R2748     2.4274586141109467e-01
    z[7,8,2]  R2749     4.1924878954887390e-01
    z[7,8,2]  R2750     -3.1090310215950012e-01
    z[7,8,2]  R2751     4.1387838125228882e-01
    z[7,8,2]  R2752     2.2290448844432831e-01
    z[7,8,2]  R2753     1.3754753768444061e-01
    z[7,8,2]  R2754     -2.9798170551657677e-02
    z[7,8,2]  R2755     -2.5615268945693970e-01
    z[7,8,2]  R2756     3.2194903492927551e-01
    z[7,8,2]  R2757     -0.251189261674881
    z[7,8,2]  R2758     -1.7484319210052490e-01
    z[7,8,2]  R2759     -1.2572652101516724e-01
    z[7,8,2]  R2760     1.7241321504116058e-02
    z[7,8,2]  R2761     7.6796674728393555e-01
    z[7,8,2]  R2762     -7.9537652432918549e-02
    z[7,8,2]  R2763     3.1214842200279236e-01
    z[7,8,2]  R2764     -4.9438709020614624e-01
    z[7,8,2]  R2765     0.512950599193573
    z[7,8,2]  R2766     3.3939656615257263e-01
    z[7,8,2]  R2767     6.9249749183654785e-02
    z[7,8,2]  R2768     -2.1348603069782257e-01
    z[7,8,2]  R2769     -0.0791369378566742
    z[7,8,2]  R2770     2.7444148436188698e-02
    z[7,8,2]  R2771     -2.9958806931972504e-02
    z[7,8,2]  R2772     -6.3811767101287842e-01
    z[7,8,2]  R2773     2.1972709894180298e-01
    z[7,8,2]  R2774     2.5459833443164825e-02
    z[7,8,2]  R2775     5.6263640522956848e-02
    z[7,8,2]  R2776     3.9968156814575195e-01
    z[7,8,2]  R2777     -1.6684535145759583e-01
    z[7,8,2]  R2778     -6.5829616785049438e-01
    z[7,8,2]  R2779     -4.8338127136230469e-01
    z[7,8,2]  R2780     -6.8979966640472412e-01
    z[7,8,2]  R2781     5.9844231605529785e-01
    z[7,8,2]  R2782     -6.1854153871536255e-01
    z[7,8,2]  R2783     4.4297706335783005e-02
    z[7,8,2]  R2784     -1.0253424942493439e-01
    z[7,8,2]  R2785     3.4196120500564575e-01
    z[7,8,2]  R2786     1.9986394047737122e-01
    z[7,8,2]  R2787     -8.1668362021446228e-02
    z[7,8,2]  R2788     2.2891965508460999e-01
    z[7,8,2]  R2789     5.2468216419219971e-01
    z[7,8,2]  R2790     -3.9801257848739624e-01
    z[7,8,2]  R2791     -4.8457396030426025e-01
    z[7,8,2]  R2792     -6.3851737976074219e-01
    z[7,8,2]  R2793     -3.4500178694725037e-01
    z[7,8,2]  R2794     -3.0746594071388245e-02
    z[7,8,2]  R2795     0.0672302395105362
    z[7,8,2]  R2796     -1.6945162415504456e-01
    z[7,8,2]  R2797     3.5668212175369263e-01
    z[7,8,2]  R2798     4.5615750551223755e-01
    z[7,8,2]  R2799     1.0421478748321533e-01
    z[7,8,2]  R2800     2.2317555546760559e-01
    z[7,8,2]  R2801     1.8342211842536926e-01
    z[7,8,2]  R2802     3.2977712154388428e-01
    z[7,8,2]  R2803     2.5324460864067078e-01
    z[7,8,2]  R2804     2.0797833800315857e-01
    z[7,8,2]  R2805     5.5952745676040649e-01
    z[7,8,2]  R2806     -1.7250286042690277e-01
    z[7,8,2]  R2807     1.0942266322672367e-02
    z[7,8,2]  R2808     -9.7748890519142151e-02
    z[7,8,2]  R2809     -1.1095040291547775e-01
    z[7,8,2]  R2810     8.1540994346141815e-02
    z[7,8,2]  R2811     1.9990071654319763e-02
    z[7,8,2]  R2812     3.3385327458381653e-01
    z[7,8,2]  R2813     -6.5134182572364807e-02
    z[7,8,2]  R2814     4.1693288087844849e-01
    z[7,8,2]  R2815     -3.3540013432502747e-01
    z[7,8,2]  R2816     3.5556885600090027e-01
    z[7,8,2]  R2817     -1.6824441030621529e-02
    z[7,8,2]  R2818     1.4960496127605438e-01
    z[7,8,2]  R2819     3.2649624347686768e-01
    z[7,8,2]  R2820     -5.8190923929214478e-01
    z[7,8,2]  R2821     -5.5336314439773560e-01
    z[7,8,3]  R68       -1
    z[7,8,3]  R77       1
    z[7,8,3]  R2685     -1
    z[7,8,3]  R2686     1
    z[7,8,3]  R2693     2.5789457559585571e-01
    z[7,8,3]  R2694     7.6679818332195282e-02
    z[7,8,3]  R2695     7.4222676455974579e-02
    z[7,8,3]  R2696     6.7925274372100830e-02
    z[7,8,3]  R2697     4.2619869112968445e-02
    z[7,8,3]  R2698     1.5018087625503540e-01
    z[7,8,3]  R2699     -2.2287322208285332e-02
    z[7,8,3]  R2700     1.7334936559200287e-01
    z[7,8,3]  R2701     1.5530005097389221e-01
    z[7,8,3]  R2702     0.0453343540430069
    z[7,8,3]  R2703     6.0690528154373169e-01
    z[7,8,3]  R2704     5.7045966386795044e-01
    z[7,8,3]  R2705     5.9706658124923706e-01
    z[7,8,3]  R2706     6.5926498174667358e-01
    z[7,8,3]  R2707     5.5603188276290894e-01
    z[7,8,3]  R2708     5.6152331829071045e-01
    z[7,8,3]  R2709     6.3624918460845947e-01
    z[7,8,3]  R2710     4.3104144930839539e-01
    z[7,8,3]  R2711     -1.4310272037982941e-01
    z[7,8,3]  R2712     3.2803124189376831e-01
    z[7,8,3]  R2713     6.1675232648849487e-01
    z[7,8,3]  R2714     4.8381385207176208e-01
    z[7,8,3]  R2715     1.1437595635652542e-01
    z[7,8,3]  R2716     4.5385140925645828e-02
    z[7,8,3]  R2717     -4.7429639101028442e-01
    z[7,8,3]  R2718     -1.3199462555348873e-02
    z[7,8,3]  R2719     2.3878661915659904e-02
    z[7,8,3]  R2720     -1.5798424184322357e-01
    z[7,8,3]  R2721     -1.9470445811748505e-01
    z[7,8,3]  R2722     2.4173672497272491e-01
    z[7,8,3]  R2723     6.5899646282196045e-01
    z[7,8,3]  R2724     7.6095026731491089e-01
    z[7,8,3]  R2725     -7.1903415024280548e-02
    z[7,8,3]  R2726     7.1365468204021454e-02
    z[7,8,3]  R2727     -2.8981423377990723e-01
    z[7,8,3]  R2728     3.6298626661300659e-01
    z[7,8,3]  R2729     1.3017773628234863e-01
    z[7,8,3]  R2730     -1.4988839626312256e-01
    z[7,8,3]  R2731     -3.9614096283912659e-01
    z[7,8,3]  R2732     -3.0419471859931946e-01
    z[7,8,3]  R2733     -2.1315976977348328e-01
    z[7,8,3]  R2734     -2.4674201011657715e-01
    z[7,8,3]  R2735     6.0045200586318970e-01
    z[7,8,3]  R2736     0.831079363822937
    z[7,8,3]  R2737     2.4031335115432739e-01
    z[7,8,3]  R2738     1.3446410000324249e-01
    z[7,8,3]  R2739     1.8834297358989716e-01
    z[7,8,3]  R2740     -4.5580846071243286e-01
    z[7,8,3]  R2741     -4.4311785697937012e-01
    z[7,8,3]  R2742     3.0654057860374451e-01
    z[7,8,3]  R2743     -3.5950881242752075e-01
    z[7,8,3]  R2744     4.5377832651138306e-01
    z[7,8,3]  R2745     1.6288067400455475e-01
    z[7,8,3]  R2746     7.8887414932250977e-01
    z[7,8,3]  R2747     6.0306102037429810e-01
    z[7,8,3]  R2748     2.2944065928459167e-01
    z[7,8,3]  R2749     1.3756365515291691e-02
    z[7,8,3]  R2750     1.4490705728530884e-01
    z[7,8,3]  R2751     9.3097344040870667e-02
    z[7,8,3]  R2752     -8.0060526728630066e-02
    z[7,8,3]  R2753     7.7907508611679077e-01
    z[7,8,3]  R2754     7.3133997619152069e-02
    z[7,8,3]  R2755     7.1731686592102051e-01
    z[7,8,3]  R2756     -1.1281068623065948e-01
    z[7,8,3]  R2757     4.0450257062911987e-01
    z[7,8,3]  R2758     0.00385760678909719
    z[7,8,3]  R2759     -8.1982992589473724e-02
    z[7,8,3]  R2760     1.7649991810321808e-01
    z[7,8,3]  R2761     -2.6585987210273743e-01
    z[7,8,3]  R2762     -2.9219236969947815e-01
    z[7,8,3]  R2763     4.7909659147262573e-01
    z[7,8,3]  R2764     6.0675078630447388e-01
    z[7,8,3]  R2765     7.6968587934970856e-02
    z[7,8,3]  R2766     5.7475709915161133e-01
    z[7,8,3]  R2767     -1.0565434396266937e-01
    z[7,8,3]  R2768     -7.3891326785087585e-02
    z[7,8,3]  R2769     4.7077399492263794e-01
    z[7,8,3]  R2770     3.1705811619758606e-01
    z[7,8,3]  R2771     -3.5898125171661377e-01
    z[7,8,3]  R2772     -4.4451120495796204e-01
    z[7,8,3]  R2773     1.5172217041254044e-02
    z[7,8,3]  R2774     6.6756260395050049e-01
    z[7,8,3]  R2775     4.9172133207321167e-01
    z[7,8,3]  R2776     1.4260038733482361e-01
    z[7,8,3]  R2777     -4.7486531734466553e-01
    z[7,8,3]  R2778     -3.3216324448585510e-01
    z[7,8,3]  R2779     -2.8205469250679016e-01
    z[7,8,3]  R2780     -5.6749057024717331e-02
    z[7,8,3]  R2781     -1.0599813610315323e-01
    z[7,8,3]  R2782     -1.9939118623733521e-01
    z[7,8,3]  R2783     3.3893135190010071e-01
    z[7,8,3]  R2784     1.7238068580627441e-01
    z[7,8,3]  R2785     -8.0694389343261719e-01
    z[7,8,3]  R2786     2.2265070676803589e-01
    z[7,8,3]  R2787     -1.2656930088996887e-01
    z[7,8,3]  R2788     4.0449026226997375e-01
    z[7,8,3]  R2789     -0.569337010383606
    z[7,8,3]  R2790     -6.4385145902633667e-01
    z[7,8,3]  R2791     1.1762108653783798e-02
    z[7,8,3]  R2792     -2.0890416204929352e-01
    z[7,8,3]  R2793     0.820968508720398
    z[7,8,3]  R2794     6.7245924472808838e-01
    z[7,8,3]  R2795     6.3162380456924438e-01
    z[7,8,3]  R2796     7.0842069387435913e-01
    z[7,8,3]  R2797     6.5730887651443481e-01
    z[7,8,3]  R2798     7.4381065368652344e-01
    z[7,8,3]  R2799     8.7322556972503662e-01
    z[7,8,3]  R2800     2.5221675634384155e-01
    z[7,8,3]  R2801     -2.6172018051147461e-01
    z[7,8,3]  R2802     3.6002656817436218e-01
    z[7,8,3]  R2803     3.9744228124618530e-01
    z[7,8,3]  R2804     2.2856892645359039e-01
    z[7,8,3]  R2805     3.2866531610488892e-01
    z[7,8,3]  R2806     -1.9448810815811157e-01
    z[7,8,3]  R2807     -1.3624049723148346e-01
    z[7,8,3]  R2808     1.0560864955186844e-01
    z[7,8,3]  R2809     8.2533389329910278e-02
    z[7,8,3]  R2810     3.7692766636610031e-02
    z[7,8,3]  R2811     1.9963359832763672e-01
    z[7,8,3]  R2812     6.4280843734741211e-01
    z[7,8,3]  R2813     7.4181818962097168e-01
    z[7,8,3]  R2814     8.2144778966903687e-01
    z[7,8,3]  R2815     6.5293055772781372e-01
    z[7,8,3]  R2816     6.0793638229370117e-01
    z[7,8,3]  R2817     -2.7843394875526428e-01
    z[7,8,3]  R2818     -1.4027177821844816e-03
    z[7,8,3]  R2819     -1.1982208490371704e-01
    z[7,8,3]  R2820     -1.3696564733982086e-01
    z[7,8,3]  R2821     -4.2138215899467468e-01
    z[7,8,4]  R69       -1
    z[7,8,4]  R78       1
    z[7,8,4]  R2687     -1
    z[7,8,4]  R2688     1
    z[7,8,4]  R2693     -1.1496312171220779e-01
    z[7,8,4]  R2694     6.1036888509988785e-02
    z[7,8,4]  R2695     1.1571945995092392e-01
    z[7,8,4]  R2696     -3.8888859748840332e-01
    z[7,8,4]  R2697     -1.1638686805963516e-01
    z[7,8,4]  R2698     -2.9812756180763245e-01
    z[7,8,4]  R2699     -1.9319224357604980e-01
    z[7,8,4]  R2700     1.6015812754631042e-01
    z[7,8,4]  R2701     4.2423516511917114e-01
    z[7,8,4]  R2702     -1.7063283594325185e-03
    z[7,8,4]  R2703     -3.7976670265197754e-01
    z[7,8,4]  R2704     -5.4631937295198441e-02
    z[7,8,4]  R2705     -4.7857353091239929e-01
    z[7,8,4]  R2706     1.5906213223934174e-01
    z[7,8,4]  R2707     1.1276460252702236e-02
    z[7,8,4]  R2708     5.0584155321121216e-01
    z[7,8,4]  R2709     2.3941858112812042e-01
    z[7,8,4]  R2710     -0.562581479549408
    z[7,8,4]  R2711     8.6790435016155243e-02
    z[7,8,4]  R2712     -1.2445009499788284e-01
    z[7,8,4]  R2713     4.0344062447547913e-01
    z[7,8,4]  R2714     -2.3010616004467010e-01
    z[7,8,4]  R2715     -2.1427439153194427e-01
    z[7,8,4]  R2716     -5.6533205509185791e-01
    z[7,8,4]  R2717     -1.5597687661647797e-01
    z[7,8,4]  R2718     -4.6064171195030212e-01
    z[7,8,4]  R2719     -6.3801310956478119e-02
    z[7,8,4]  R2720     5.2818089723587036e-01
    z[7,8,4]  R2721     4.9443128705024719e-01
    z[7,8,4]  R2722     -2.1657621860504150e-01
    z[7,8,4]  R2723     -1.7721369862556458e-02
    z[7,8,4]  R2724     3.4907300025224686e-02
    z[7,8,4]  R2725     -1.4428691565990448e-01
    z[7,8,4]  R2726     5.3972166031599045e-02
    z[7,8,4]  R2727     3.9959940314292908e-01
    z[7,8,4]  R2728     -4.4225663878023624e-03
    z[7,8,4]  R2729     5.6520360708236694e-01
    z[7,8,4]  R2730     2.9839816689491272e-01
    z[7,8,4]  R2731     -1.2828929722309113e-01
    z[7,8,4]  R2732     2.1192553639411926e-01
    z[7,8,4]  R2733     8.9194908738136292e-02
    z[7,8,4]  R2734     3.6870828270912170e-01
    z[7,8,4]  R2735     -3.1754696369171143e-01
    z[7,8,4]  R2736     2.1599155664443970e-01
    z[7,8,4]  R2737     3.5281282663345337e-01
    z[7,8,4]  R2738     -0.0717427060008049
    z[7,8,4]  R2739     1.4988392591476440e-01
    z[7,8,4]  R2740     1.9288735091686249e-01
    z[7,8,4]  R2741     -3.0036326497793198e-02
    z[7,8,4]  R2742     -2.2175274789333344e-02
    z[7,8,4]  R2743     -5.9873346239328384e-02
    z[7,8,4]  R2744     1.8889187276363373e-01
    z[7,8,4]  R2745     -2.0365279912948608e-01
    z[7,8,4]  R2746     -5.0281536579132080e-01
    z[7,8,4]  R2747     -7.1040540933609009e-02
    z[7,8,4]  R2748     7.4606128036975861e-02
    z[7,8,4]  R2749     2.8247093781828880e-02
    z[7,8,4]  R2750     8.0307433381676674e-04
    z[7,8,4]  R2751     -8.1252768635749817e-02
    z[7,8,4]  R2752     -6.5929013490676880e-01
    z[7,8,4]  R2753     -3.4355142712593079e-01
    z[7,8,4]  R2754     1.5855866670608521e-01
    z[7,8,4]  R2755     4.9937221407890320e-01
    z[7,8,4]  R2756     2.7032768726348877e-01
    z[7,8,4]  R2757     9.5205254852771759e-02
    z[7,8,4]  R2758     2.9664269089698792e-01
    z[7,8,4]  R2759     -3.3074134588241577e-01
    z[7,8,4]  R2760     -3.5192474722862244e-01
    z[7,8,4]  R2761     -2.4802875518798828e-01
    z[7,8,4]  R2762     -1.7932142317295074e-01
    z[7,8,4]  R2763     -1.3013717532157898e-01
    z[7,8,4]  R2764     -2.1842719614505768e-01
    z[7,8,4]  R2765     -3.3131629228591919e-01
    z[7,8,4]  R2766     3.6168730258941650e-01
    z[7,8,4]  R2767     7.0028595626354218e-02
    z[7,8,4]  R2768     3.1607393175363541e-02
    z[7,8,4]  R2769     -3.6443449556827545e-02
    z[7,8,4]  R2770     -7.0717319846153259e-02
    z[7,8,4]  R2771     -8.0152988433837891e-02
    z[7,8,4]  R2772     -9.5381431281566620e-02
    z[7,8,4]  R2773     -8.0028679221868515e-03
    z[7,8,4]  R2774     -4.6683689579367638e-03
    z[7,8,4]  R2775     2.3104159533977509e-01
    z[7,8,4]  R2776     -4.9141305498778820e-04
    z[7,8,4]  R2777     2.8214901685714722e-01
    z[7,8,4]  R2778     1.9687581062316895e-01
    z[7,8,4]  R2779     6.2029594182968140e-01
    z[7,8,4]  R2780     6.0424196720123291e-01
    z[7,8,4]  R2781     -3.1634208559989929e-01
    z[7,8,4]  R2782     6.7752408981323242e-01
    z[7,8,4]  R2783     6.1544120311737061e-01
    z[7,8,4]  R2784     -1.6038011014461517e-01
    z[7,8,4]  R2785     -4.4960159808397293e-02
    z[7,8,4]  R2786     3.2772939652204514e-02
    z[7,8,4]  R2787     2.4203942716121674e-01
    z[7,8,4]  R2788     -7.1600514650344849e-01
    z[7,8,4]  R2789     -4.7515761852264404e-01
    z[7,8,4]  R2790     -4.7687861323356628e-01
    z[7,8,4]  R2791     -1.4801302552223206e-01
    z[7,8,4]  R2792     -8.6326800286769867e-02
    z[7,8,4]  R2793     -1.1482661962509155e-01
    z[7,8,4]  R2794     -7.4615702033042908e-03
    z[7,8,4]  R2795     -1.4398986101150513e-01
    z[7,8,4]  R2796     3.1648358702659607e-01
    z[7,8,4]  R2797     8.5796646773815155e-02
    z[7,8,4]  R2798     1.6937313973903656e-01
    z[7,8,4]  R2799     3.5484090447425842e-01
    z[7,8,4]  R2800     -5.3575527854263783e-03
    z[7,8,4]  R2801     -5.2903532981872559e-02
    z[7,8,4]  R2802     -5.3471463918685913e-01
    z[7,8,4]  R2803     -0.59151291847229
    z[7,8,4]  R2804     -7.9646848142147064e-02
    z[7,8,4]  R2805     -0.0201775711029768
    z[7,8,4]  R2806     4.5154165476560593e-02
    z[7,8,4]  R2807     1.6619296371936798e-01
    z[7,8,4]  R2808     1.6266991198062897e-01
    z[7,8,4]  R2809     -3.7581852078437805e-01
    z[7,8,4]  R2810     -2.7733482420444489e-03
    z[7,8,4]  R2811     2.2970676422119141e-01
    z[7,8,4]  R2812     -1.4652857184410095e-01
    z[7,8,4]  R2813     1.3311018049716949e-01
    z[7,8,4]  R2814     2.1338362246751785e-02
    z[7,8,4]  R2815     -4.9263462424278259e-01
    z[7,8,4]  R2816     1.3779577612876892e-01
    z[7,8,4]  R2817     -3.4126002341508865e-02
    z[7,8,4]  R2818     -1.0386031121015549e-01
    z[7,8,4]  R2819     -1.1333167552947998e-02
    z[7,8,4]  R2820     1.8678863346576691e-01
    z[7,8,4]  R2821     1.9302532076835632e-02
    z[7,8,5]  R70       -1
    z[7,8,5]  R79       1
    z[7,8,5]  R2689     -1
    z[7,8,5]  R2690     1
    z[7,8,5]  R2693     0.0596165657043457
    z[7,8,5]  R2694     -1.5421052277088165e-01
    z[7,8,5]  R2695     2.5916749238967896e-01
    z[7,8,5]  R2696     3.5540476441383362e-02
    z[7,8,5]  R2697     2.4593852460384369e-01
    z[7,8,5]  R2698     2.6339060068130493e-01
    z[7,8,5]  R2699     -3.1690327450633049e-03
    z[7,8,5]  R2700     -2.6576307415962219e-01
    z[7,8,5]  R2701     7.5584337115287781e-02
    z[7,8,5]  R2702     -1.3800999522209167e-01
    z[7,8,5]  R2703     -2.3829996585845947e-01
    z[7,8,5]  R2704     -4.3946501612663269e-01
    z[7,8,5]  R2705     -3.5648146271705627e-01
    z[7,8,5]  R2706     -4.4333106279373169e-01
    z[7,8,5]  R2707     -1.6065049916505814e-02
    z[7,8,5]  R2708     1.9907447695732117e-01
    z[7,8,5]  R2709     1.5110961161553860e-02
    z[7,8,5]  R2710     4.7820255160331726e-01
    z[7,8,5]  R2711     3.8310371339321136e-02
    z[7,8,5]  R2712     8.0996805429458618e-01
    z[7,8,5]  R2713     -1.6127489507198334e-01
    z[7,8,5]  R2714     0.690273106098175
    z[7,8,5]  R2715     -3.0313533544540405e-01
    z[7,8,5]  R2716     7.4939350597560406e-03
    z[7,8,5]  R2717     0.0902993455529213
    z[7,8,5]  R2718     -4.8316949605941772e-01
    z[7,8,5]  R2719     1.0509271919727325e-01
    z[7,8,5]  R2720     -1.3863454759120941e-01
    z[7,8,5]  R2721     -5.6824021041393280e-02
    z[7,8,5]  R2722     2.8457471728324890e-01
    z[7,8,5]  R2723     -7.8652210533618927e-02
    z[7,8,5]  R2724     1.3941408693790436e-01
    z[7,8,5]  R2725     -5.6810826063156128e-01
    z[7,8,5]  R2726     2.0864079892635345e-01
    z[7,8,5]  R2727     3.5150960087776184e-01
    z[7,8,5]  R2728     3.6750671267509460e-01
    z[7,8,5]  R2729     8.7569728493690491e-02
    z[7,8,5]  R2730     5.7715136557817459e-02
    z[7,8,5]  R2731     2.7905693650245667e-01
    z[7,8,5]  R2732     -3.2278639078140259e-01
    z[7,8,5]  R2733     2.1576821804046631e-01
    z[7,8,5]  R2734     1.7159767448902130e-01
    z[7,8,5]  R2735     4.1267678141593933e-01
    z[7,8,5]  R2736     -1.2315607070922852e-01
    z[7,8,5]  R2737     -7.2828345000743866e-02
    z[7,8,5]  R2738     1.3304447755217552e-02
    z[7,8,5]  R2739     3.5721620917320251e-01
    z[7,8,5]  R2740     -5.7846039533615112e-01
    z[7,8,5]  R2741     -5.3011399507522583e-01
    z[7,8,5]  R2742     2.8076618909835815e-01
    z[7,8,5]  R2743     -2.3221983015537262e-01
    z[7,8,5]  R2744     1.2673947215080261e-01
    z[7,8,5]  R2745     -2.8106454014778137e-01
    z[7,8,5]  R2746     1.4398138225078583e-01
    z[7,8,5]  R2747     -2.9013365507125854e-01
    z[7,8,5]  R2748     1.1404684931039810e-01
    z[7,8,5]  R2749     -0.0963074192404747
    z[7,8,5]  R2750     -1.9495855271816254e-01
    z[7,8,5]  R2751     2.8034153580665588e-01
    z[7,8,5]  R2752     -0.323823481798172
    z[7,8,5]  R2753     3.7357372045516968e-01
    z[7,8,5]  R2754     -5.8438368141651154e-02
    z[7,8,5]  R2755     -7.9122297465801239e-02
    z[7,8,5]  R2756     -6.4036726951599121e-01
    z[7,8,5]  R2757     -1.8583790957927704e-01
    z[7,8,5]  R2758     -3.2547211647033691e-01
    z[7,8,5]  R2759     -2.4672269821166992e-01
    z[7,8,5]  R2760     -1.0942756384611130e-01
    z[7,8,5]  R2761     8.1528417766094208e-02
    z[7,8,5]  R2762     2.4342155456542969e-01
    z[7,8,5]  R2763     -2.1648842096328735e-01
    z[7,8,5]  R2764     -1.0613638907670975e-01
    z[7,8,5]  R2765     -6.7212902009487152e-02
    z[7,8,5]  R2766     2.4922121316194534e-02
    z[7,8,5]  R2767     -3.5402163863182068e-01
    z[7,8,5]  R2768     -2.4613919854164124e-01
    z[7,8,5]  R2769     -1.1041836440563202e-01
    z[7,8,5]  R2770     -0.289393812417984
    z[7,8,5]  R2771     -1.6315674409270287e-02
    z[7,8,5]  R2772     9.6302941441535950e-02
    z[7,8,5]  R2773     -1.8625985085964203e-01
    z[7,8,5]  R2774     1.9237220287322998e-01
    z[7,8,5]  R2775     -2.5953933596611023e-01
    z[7,8,5]  R2776     2.0789082348346710e-01
    z[7,8,5]  R2777     2.5498500093817711e-02
    z[7,8,5]  R2778     3.3535334467887878e-01
    z[7,8,5]  R2779     -2.5545755028724670e-01
    z[7,8,5]  R2780     -2.6062300801277161e-01
    z[7,8,5]  R2781     -3.4602773189544678e-01
    z[7,8,5]  R2782     8.0022260546684265e-02
    z[7,8,5]  R2783     1.3929626345634460e-01
    z[7,8,5]  R2784     -3.5279604792594910e-01
    z[7,8,5]  R2785     3.8220237940549850e-02
    z[7,8,5]  R2786     2.1354711055755615e-01
    z[7,8,5]  R2787     -4.0999558568000793e-01
    z[7,8,5]  R2788     8.4200963377952576e-02
    z[7,8,5]  R2789     2.8404369950294495e-01
    z[7,8,5]  R2790     3.8109812140464783e-01
    z[7,8,5]  R2791     7.8728175163269043e-01
    z[7,8,5]  R2792     6.7090344429016113e-01
    z[7,8,5]  R2793     3.5295647382736206e-01
    z[7,8,5]  R2794     -2.4163994938135147e-02
    z[7,8,5]  R2795     2.7940610051155090e-01
    z[7,8,5]  R2796     2.9542475938796997e-02
    z[7,8,5]  R2797     2.8805750608444214e-01
    z[7,8,5]  R2798     -1.4151780307292938e-01
    z[7,8,5]  R2799     -5.8375686407089233e-02
    z[7,8,5]  R2800     5.0904947519302368e-01
    z[7,8,5]  R2801     -2.0721639692783356e-01
    z[7,8,5]  R2802     2.2999155521392822e-01
    z[7,8,5]  R2803     1.7055776715278625e-01
    z[7,8,5]  R2804     4.8161312937736511e-01
    z[7,8,5]  R2805     -1.8148081004619598e-01
    z[7,8,5]  R2806     0.072996124625206
    z[7,8,5]  R2807     -1.3415264897048473e-02
    z[7,8,5]  R2808     2.1625134348869324e-01
    z[7,8,5]  R2809     0.118670254945755
    z[7,8,5]  R2810     -0.221003919839859
    z[7,8,5]  R2811     -3.0883875489234924e-01
    z[7,8,5]  R2812     -1.3896717131137848e-01
    z[7,8,5]  R2813     3.2583504915237427e-01
    z[7,8,5]  R2814     -8.8345922529697418e-02
    z[7,8,5]  R2815     2.5804251432418823e-01
    z[7,8,5]  R2816     2.5488847494125366e-01
    z[7,8,5]  R2817     -0.0645069107413292
    z[7,8,5]  R2818     2.2342254221439362e-01
    z[7,8,5]  R2819     5.1044980064034462e-03
    z[7,8,5]  R2820     -2.3616391420364380e-01
    z[7,8,5]  R2821     -3.1501868367195129e-01
    z[7,8,6]  R71       -1
    z[7,8,6]  R80       1
    z[7,8,6]  R2691     -1
    z[7,8,6]  R2692     1
    z[7,8,6]  R2693     -1.3391232490539551e-01
    z[7,8,6]  R2694     -5.5602509528398514e-02
    z[7,8,6]  R2695     9.5840133726596832e-02
    z[7,8,6]  R2696     1.4374126493930817e-01
    z[7,8,6]  R2697     -1.5773972868919373e-01
    z[7,8,6]  R2698     0.0995691567659378
    z[7,8,6]  R2699     -7.6256953179836273e-02
    z[7,8,6]  R2700     1.4368730783462524e-01
    z[7,8,6]  R2701     -1.5407225489616394e-01
    z[7,8,6]  R2702     1.6710811853408813e-01
    z[7,8,6]  R2703     2.9666331410408020e-01
    z[7,8,6]  R2704     1.7016613855957985e-02
    z[7,8,6]  R2705     -2.0249038934707642e-01
    z[7,8,6]  R2706     -1.0928864032030106e-01
    z[7,8,6]  R2707     6.4154869318008423e-01
    z[7,8,6]  R2708     5.3281837701797485e-01
    z[7,8,6]  R2709     3.0589789152145386e-01
    z[7,8,6]  R2710     2.4263255298137665e-01
    z[7,8,6]  R2711     -2.9404631257057190e-01
    z[7,8,6]  R2712     2.7412512898445129e-01
    z[7,8,6]  R2713     4.8868253827095032e-02
    z[7,8,6]  R2714     8.0984615487977862e-04
    z[7,8,6]  R2715     -1.7131294310092926e-01
    z[7,8,6]  R2716     -7.9409822821617126e-02
    z[7,8,6]  R2717     3.2485806941986084e-01
    z[7,8,6]  R2718     8.6883746087551117e-02
    z[7,8,6]  R2719     1.9362498819828033e-01
    z[7,8,6]  R2720     3.8350574672222137e-02
    z[7,8,6]  R2721     -0.0493636429309845
    z[7,8,6]  R2722     9.3438185751438141e-02
    z[7,8,6]  R2723     5.2796018123626709e-01
    z[7,8,6]  R2724     -4.5082005858421326e-01
    z[7,8,6]  R2725     -3.9235156774520874e-01
    z[7,8,6]  R2726     -2.1485263109207153e-01
    z[7,8,6]  R2727     1.0583304613828659e-01
    z[7,8,6]  R2728     2.6076692342758179e-01
    z[7,8,6]  R2729     0.101309634745121
    z[7,8,6]  R2730     1.8745566904544830e-01
    z[7,8,6]  R2731     6.6299118101596832e-02
    z[7,8,6]  R2732     3.4264308214187622e-01
    z[7,8,6]  R2733     3.6983732134103775e-03
    z[7,8,6]  R2734     -3.6549825221300125e-02
    z[7,8,6]  R2735     5.6970596313476562e-02
    z[7,8,6]  R2736     -3.0264276266098022e-01
    z[7,8,6]  R2737     1.8844233453273773e-01
    z[7,8,6]  R2738     1.1336199194192886e-01
    z[7,8,6]  R2739     -1.3753518462181091e-01
    z[7,8,6]  R2740     2.8746657073497772e-02
    z[7,8,6]  R2741     3.0018597841262817e-01
    z[7,8,6]  R2742     -3.2065957784652710e-01
    z[7,8,6]  R2743     3.5046026110649109e-01
    z[7,8,6]  R2744     1.7457805573940277e-01
    z[7,8,6]  R2745     6.3427664339542389e-02
    z[7,8,6]  R2746     -1.4630000293254852e-01
    z[7,8,6]  R2747     -3.6590874195098877e-01
    z[7,8,6]  R2748     2.3407968692481518e-03
    z[7,8,6]  R2749     1.4083732664585114e-01
    z[7,8,6]  R2750     -4.5543056726455688e-01
    z[7,8,6]  R2751     3.6189281940460205e-01
    z[7,8,6]  R2752     5.9667207300662994e-02
    z[7,8,6]  R2753     3.9056394249200821e-02
    z[7,8,6]  R2754     -3.5774940252304077e-01
    z[7,8,6]  R2755     6.4626209437847137e-02
    z[7,8,6]  R2756     -5.1362957805395126e-02
    z[7,8,6]  R2757     -8.9024573564529419e-02
    z[7,8,6]  R2758     -3.5536146163940430e-01
    z[7,8,6]  R2759     -2.2796842455863953e-01
    z[7,8,6]  R2760     -2.1361030638217926e-01
    z[7,8,6]  R2761     1.4386756718158722e-01
    z[7,8,6]  R2762     -2.4325957521796227e-02
    z[7,8,6]  R2763     -2.0830747485160828e-01
    z[7,8,6]  R2764     -4.2313057184219360e-01
    z[7,8,6]  R2765     2.8809100389480591e-01
    z[7,8,6]  R2766     -2.6862871646881104e-01
    z[7,8,6]  R2767     -1.3921138644218445e-01
    z[7,8,6]  R2768     -2.2763611376285553e-01
    z[7,8,6]  R2769     -1.7594610154628754e-01
    z[7,8,6]  R2770     -3.2816660404205322e-01
    z[7,8,6]  R2771     1.3124649226665497e-01
    z[7,8,6]  R2772     -2.2728709876537323e-01
    z[7,8,6]  R2773     -8.9128427207469940e-02
    z[7,8,6]  R2774     -1.5429088473320007e-01
    z[7,8,6]  R2775     -1.7627786099910736e-01
    z[7,8,6]  R2776     -3.0590042471885681e-01
    z[7,8,6]  R2777     1.0293000936508179e-01
    z[7,8,6]  R2778     2.2025278210639954e-01
    z[7,8,6]  R2779     2.3513735830783844e-01
    z[7,8,6]  R2780     4.3343797326087952e-02
    z[7,8,6]  R2781     -5.9962904453277588e-01
    z[7,8,6]  R2782     1.0144189745187759e-01
    z[7,8,6]  R2783     -2.7296485379338264e-02
    z[7,8,6]  R2784     -6.9551318883895874e-01
    z[7,8,6]  R2785     -9.9850669503211975e-03
    z[7,8,6]  R2786     1.2903241813182831e-01
    z[7,8,6]  R2787     0.614565372467041
    z[7,8,6]  R2788     4.7373369336128235e-01
    z[7,8,6]  R2789     -9.6105104312300682e-03
    z[7,8,6]  R2790     -1.6487258672714233e-01
    z[7,8,6]  R2791     -3.3270925283432007e-01
    z[7,8,6]  R2792     -1.5050514601171017e-02
    z[7,8,6]  R2793     2.5339301675558090e-02
    z[7,8,6]  R2794     4.1012936830520630e-01
    z[7,8,6]  R2795     -2.2790496051311493e-01
    z[7,8,6]  R2796     1.9731713831424713e-01
    z[7,8,6]  R2797     -8.0265142023563385e-02
    z[7,8,6]  R2798     -2.3283023387193680e-02
    z[7,8,6]  R2799     9.9094063043594360e-02
    z[7,8,6]  R2800     3.0142712593078613e-01
    z[7,8,6]  R2801     1.8220894038677216e-01
    z[7,8,6]  R2802     1.3260385394096375e-01
    z[7,8,6]  R2803     3.8297748565673828e-01
    z[7,8,6]  R2804     2.5355115532875061e-01
    z[7,8,6]  R2805     1.6693432629108429e-01
    z[7,8,6]  R2806     1.8298017978668213e-01
    z[7,8,6]  R2807     3.3461713790893555e-01
    z[7,8,6]  R2808     1.3354423642158508e-01
    z[7,8,6]  R2809     3.5253062844276428e-02
    z[7,8,6]  R2810     -3.4190145134925842e-01
    z[7,8,6]  R2811     3.3973187208175659e-02
    z[7,8,6]  R2812     3.8801971077919006e-01
    z[7,8,6]  R2813     3.2108667492866516e-01
    z[7,8,6]  R2814     2.4911326169967651e-01
    z[7,8,6]  R2815     2.7404436469078064e-01
    z[7,8,6]  R2816     2.4183419346809387e-01
    z[7,8,6]  R2817     -1.0881573706865311e-01
    z[7,8,6]  R2818     -2.9862526059150696e-01
    z[7,8,6]  R2819     0.0569380484521389
    z[7,8,6]  R2820     -5.3832545876502991e-02
    z[7,8,6]  R2821     -2.0913438498973846e-01
    z[8,7,0]  R65       1
    z[8,7,0]  R74       -1
    z[8,7,0]  R2822     -1
    z[8,7,0]  R2823     1
    z[8,7,0]  R2836     -5.4492527246475220e-01
    z[8,7,0]  R2837     -2.1534349024295807e-01
    z[8,7,0]  R2838     -4.7673907876014709e-01
    z[8,7,0]  R2839     -9.1472655534744263e-01
    z[8,7,0]  R2840     -4.9899551272392273e-01
    z[8,7,0]  R2841     1.7937442660331726e-01
    z[8,7,0]  R2842     8.3233872428536415e-03
    z[8,7,0]  R2843     -1.1779731512069702e-01
    z[8,7,0]  R2844     7.5718045234680176e-02
    z[8,7,0]  R2845     4.3023101985454559e-02
    z[8,7,0]  R2846     2.5510627031326294e-01
    z[8,7,0]  R2847     0.611352801322937
    z[8,7,0]  R2848     6.4501678943634033e-01
    z[8,7,0]  R2849     5.7139158248901367e-01
    z[8,7,0]  R2850     5.8158326148986816e-01
    z[8,7,0]  R2851     3.6221036314964294e-01
    z[8,7,0]  R2852     2.8853756189346313e-01
    z[8,7,0]  R2853     3.1469497084617615e-01
    z[8,7,0]  R2854     2.6581883430480957e-01
    z[8,7,0]  R2855     5.8376115560531616e-01
    z[8,7,0]  R2856     3.7380585074424744e-01
    z[8,7,0]  R2857     4.8549342155456543e-01
    z[8,7,0]  R2858     6.9221824407577515e-01
    z[8,7,0]  R2859     2.0233023166656494e-01
    z[8,7,0]  R2860     1.2574322521686554e-01
    z[8,7,0]  R2861     2.5684067606925964e-01
    z[8,7,0]  R2862     1.1671365052461624e-01
    z[8,7,0]  R2863     2.3870217800140381e-01
    z[8,7,0]  R2864     1.5381184220314026e-01
    z[8,7,0]  R2865     5.1420134305953979e-01
    z[8,7,0]  R2866     2.2655582427978516e-01
    z[8,7,0]  R2867     0.283189594745636
    z[8,7,0]  R2868     2.7601400017738342e-01
    z[8,7,0]  R2869     3.5650694370269775e-01
    z[8,7,0]  R2870     2.8758205473423004e-02
    z[8,7,0]  R2871     2.2294494509696960e-01
    z[8,7,0]  R2872     2.8574812412261963e-01
    z[8,7,0]  R2873     -5.9725034981966019e-02
    z[8,7,0]  R2874     -0.0819258838891983
    z[8,7,0]  R2875     -3.9254170656204224e-01
    z[8,7,0]  R2876     -2.3913398385047913e-01
    z[8,7,0]  R2877     -4.2164230346679688e-01
    z[8,7,0]  R2878     -4.6761247515678406e-01
    z[8,7,0]  R2879     -6.8008285760879517e-01
    z[8,7,0]  R2880     -6.4544725418090820e-01
    z[8,7,0]  R2881     -9.2244094610214233e-01
    z[8,7,0]  R2882     -4.7562113404273987e-01
    z[8,7,0]  R2883     -5.7857674360275269e-01
    z[8,7,0]  R2884     -0.748253583908081
    z[8,7,0]  R2885     5.2099150419235229e-01
    z[8,7,0]  R2886     5.5208230018615723e-01
    z[8,7,0]  R2887     4.7966101765632629e-01
    z[8,7,0]  R2888     5.6979340314865112e-01
    z[8,7,0]  R2889     0.41551673412323
    z[8,7,0]  R2890     3.0027130246162415e-01
    z[8,7,0]  R2891     5.6916791200637817e-01
    z[8,7,0]  R2892     3.7578943371772766e-01
    z[8,7,0]  R2893     2.2402296960353851e-01
    z[8,7,0]  R2894     3.7969928979873657e-01
    z[8,7,0]  R2895     2.6223802566528320e-01
    z[8,7,0]  R2896     3.6775204539299011e-01
    z[8,7,0]  R2897     -2.1203437820076942e-02
    z[8,7,0]  R2898     -1.3206343166530132e-02
    z[8,7,0]  R2899     2.8164750337600708e-01
    z[8,7,0]  R2900     -8.9676812291145325e-02
    z[8,7,0]  R2901     6.2856757640838623e-01
    z[8,7,0]  R2902     3.4075993299484253e-01
    z[8,7,0]  R2903     -1.3045547902584076e-01
    z[8,7,0]  R2904     -3.4689339995384216e-01
    z[8,7,0]  R2905     3.5286378860473633e-01
    z[8,7,0]  R2906     3.8080233335494995e-01
    z[8,7,0]  R2907     -0.586037814617157
    z[8,7,0]  R2908     -0.0869353786110878
    z[8,7,0]  R2909     -7.7154916524887085e-01
    z[8,7,0]  R2910     5.7940429449081421e-01
    z[8,7,0]  R2911     -6.0262113809585571e-01
    z[8,7,0]  R2912     -9.5427431166172028e-02
    z[8,7,0]  R2913     -3.0859872698783875e-01
    z[8,7,0]  R2914     -5.2074217796325684e-01
    z[8,7,0]  R2915     -9.4161635637283325e-01
    z[8,7,0]  R2916     -8.1056392192840576e-01
    z[8,7,0]  R2917     3.9836764335632324e-01
    z[8,7,0]  R2918     7.0478290319442749e-02
    z[8,7,0]  R2919     -5.9895825386047363e-01
    z[8,7,0]  R2920     2.6351484656333923e-01
    z[8,7,0]  R2921     -1.5788662433624268e-01
    z[8,7,0]  R2922     -6.1514323949813843e-01
    z[8,7,0]  R2923     -3.8206470012664795e-01
    z[8,7,0]  R2924     -1.1098635941743851e-01
    z[8,7,0]  R2925     -6.7380934953689575e-01
    z[8,7,0]  R2926     0.543727457523346
    z[8,7,0]  R2927     -7.9898262023925781e-01
    z[8,7,0]  R2928     7.9587094485759735e-02
    z[8,7,0]  R2929     -5.8735519647598267e-01
    z[8,7,0]  R2930     -1.9871200621128082e-01
    z[8,7,0]  R2931     -5.9651982784271240e-01
    z[8,7,0]  R2932     1.5138798952102661e-01
    z[8,7,0]  R2933     -1.5813054144382477e-01
    z[8,7,0]  R2934     -4.7670900821685791e-01
    z[8,7,0]  R2935     3.3887746930122375e-01
    z[8,7,0]  R2936     -8.8683640956878662e-01
    z[8,7,0]  R2937     3.9698880910873413e-01
    z[8,7,0]  R2938     -5.4121297597885132e-01
    z[8,7,0]  R2939     2.5448048114776611e-01
    z[8,7,0]  R2940     1.7015197873115540e-01
    z[8,7,0]  R2941     -3.7779429554939270e-01
    z[8,7,0]  R2942     -4.4674339890480042e-01
    z[8,7,0]  R2943     -3.5545790195465088e-01
    z[8,7,0]  R2944     6.5151005983352661e-01
    z[8,7,0]  R2945     -6.8009203672409058e-01
    z[8,7,0]  R2946     3.2066974788904190e-02
    z[8,7,0]  R2947     -7.2874939441680908e-01
    z[8,7,0]  R2948     -5.9182637929916382e-01
    z[8,7,0]  R2949     -2.6132553815841675e-01
    z[8,7,0]  R2950     2.8182464838027954e-01
    z[8,7,0]  R2951     2.1349306404590607e-01
    z[8,7,0]  R2952     -9.1540098190307617e-02
    z[8,7,0]  R2953     -5.4024338722229004e-02
    z[8,7,0]  R2954     3.6885675042867661e-02
    z[8,7,0]  R2955     -8.9066106081008911e-01
    z[8,7,0]  R2956     4.4937521219253540e-01
    z[8,7,0]  R2957     0.754943311214447
    z[8,7,0]  R2958     -5.8507156372070312e-01
    z[8,7,0]  R2959     2.8378924727439880e-01
    z[8,7,0]  R2960     7.8624807298183441e-02
    z[8,7,0]  R2961     1.2666773796081543e-01
    z[8,7,0]  R2962     9.6525497734546661e-02
    z[8,7,0]  R2963     -1.7874591052532196e-01
    z[8,7,0]  R2964     -1.5020088851451874e-01
    z[8,7,1]  R66       1
    z[8,7,1]  R75       -1
    z[8,7,1]  R2824     -1
    z[8,7,1]  R2825     1
    z[8,7,1]  R2836     4.3278518319129944e-01
    z[8,7,1]  R2837     5.2865236997604370e-01
    z[8,7,1]  R2838     3.2280489802360535e-02
    z[8,7,1]  R2839     -1.0213023424148560e-01
    z[8,7,1]  R2840     3.5205683112144470e-01
    z[8,7,1]  R2841     0.0873582735657692
    z[8,7,1]  R2842     3.0650734901428223e-01
    z[8,7,1]  R2843     -1.1546940356492996e-01
    z[8,7,1]  R2844     -8.3069734275341034e-02
    z[8,7,1]  R2845     2.9835087060928345e-01
    z[8,7,1]  R2846     -0.0591592937707901
    z[8,7,1]  R2847     -6.5233409404754639e-02
    z[8,7,1]  R2848     -1.7246234416961670e-01
    z[8,7,1]  R2849     5.4489899426698685e-02
    z[8,7,1]  R2850     -7.5519219040870667e-02
    z[8,7,1]  R2851     -2.4127402901649475e-01
    z[8,7,1]  R2852     -6.4986400306224823e-02
    z[8,7,1]  R2853     6.6145914793014526e-01
    z[8,7,1]  R2854     -8.6502122879028320e-01
    z[8,7,1]  R2855     2.5387245416641235e-01
    z[8,7,1]  R2856     3.3545008301734924e-01
    z[8,7,1]  R2857     0.605156421661377
    z[8,7,1]  R2858     1.9629713892936707e-01
    z[8,7,1]  R2859     -0.922296404838562
    z[8,7,1]  R2860     -9.0870171785354614e-01
    z[8,7,1]  R2861     -9.0678805112838745e-01
    z[8,7,1]  R2862     -9.0038394927978516e-01
    z[8,7,1]  R2863     -8.7704312801361084e-01
    z[8,7,1]  R2864     -8.8701063394546509e-01
    z[8,7,1]  R2865     1.3998055458068848e-01
    z[8,7,1]  R2866     4.0884265303611755e-01
    z[8,7,1]  R2867     2.9602622613310814e-02
    z[8,7,1]  R2868     2.5092095136642456e-02
    z[8,7,1]  R2869     4.8419770598411560e-01
    z[8,7,1]  R2870     -0.950893223285675
    z[8,7,1]  R2871     -8.8206022977828979e-01
    z[8,7,1]  R2872     -8.9106363058090210e-01
    z[8,7,1]  R2873     -7.3857551813125610e-01
    z[8,7,1]  R2874     -6.0511809587478638e-01
    z[8,7,1]  R2875     8.6168175935745239e-01
    z[8,7,1]  R2876     9.5194482803344727e-01
    z[8,7,1]  R2877     8.3967870473861694e-01
    z[8,7,1]  R2878     7.5791954994201660e-01
    z[8,7,1]  R2879     6.5164351463317871e-01
    z[8,7,1]  R2880     0.60193932056427
    z[8,7,1]  R2881     1.8296839296817780e-01
    z[8,7,1]  R2882     7.0275247097015381e-01
    z[8,7,1]  R2883     6.4181548357009888e-01
    z[8,7,1]  R2884     6.2443137168884277e-01
    z[8,7,1]  R2885     -0.166351318359375
    z[8,7,1]  R2886     1.9614227116107941e-01
    z[8,7,1]  R2887     1.2256369739770889e-01
    z[8,7,1]  R2888     -6.2041327357292175e-02
    z[8,7,1]  R2889     -3.0906911939382553e-02
    z[8,7,1]  R2890     1.1112090200185776e-01
    z[8,7,1]  R2891     -3.3025091886520386e-01
    z[8,7,1]  R2892     -2.3501524329185486e-01
    z[8,7,1]  R2893     -8.1570070981979370e-01
    z[8,7,1]  R2894     -1.1152768507599831e-02
    z[8,7,1]  R2895     4.8224860429763794e-01
    z[8,7,1]  R2896     2.8804332017898560e-01
    z[8,7,1]  R2897     -0.904996395111084
    z[8,7,1]  R2898     -8.0651009082794189e-01
    z[8,7,1]  R2899     -7.4384588003158569e-01
    z[8,7,1]  R2900     -6.9912791252136230e-01
    z[8,7,1]  R2901     -7.4209755659103394e-01
    z[8,7,1]  R2902     -7.4391418695449829e-01
    z[8,7,1]  R2903     -8.3136105537414551e-01
    z[8,7,1]  R2904     -7.9074168205261230e-01
    z[8,7,1]  R2905     3.5440880060195923e-01
    z[8,7,1]  R2906     -1.8497738242149353e-01
    z[8,7,1]  R2907     3.6687543988227844e-01
    z[8,7,1]  R2908     -8.6033952236175537e-01
    z[8,7,1]  R2909     -0.104481041431427
    z[8,7,1]  R2910     5.4912644624710083e-01
    z[8,7,1]  R2911     -2.0457734167575836e-01
    z[8,7,1]  R2912     -8.8429284095764160e-01
    z[8,7,1]  R2913     -7.8451168537139893e-01
    z[8,7,1]  R2914     -0.317264199256897
    z[8,7,1]  R2915     0.0891835018992424
    z[8,7,1]  R2916     3.3691781759262085e-01
    z[8,7,1]  R2917     4.4969987869262695e-01
    z[8,7,1]  R2918     2.7287730574607849e-01
    z[8,7,1]  R2919     1.3377930968999863e-02
    z[8,7,1]  R2920     -9.3052148818969727e-01
    z[8,7,1]  R2921     -8.7759679555892944e-01
    z[8,7,1]  R2922     9.5067918300628662e-02
    z[8,7,1]  R2923     4.3363296985626221e-01
    z[8,7,1]  R2924     -8.2585883140563965e-01
    z[8,7,1]  R2925     2.8689932823181152e-01
    z[8,7,1]  R2926     5.7964378595352173e-01
    z[8,7,1]  R2927     3.8527809083461761e-02
    z[8,7,1]  R2928     -2.5478392839431763e-01
    z[8,7,1]  R2929     0.0353827103972435
    z[8,7,1]  R2930     -9.1124457120895386e-01
    z[8,7,1]  R2931     -0.662040114402771
    z[8,7,1]  R2932     -7.8357911109924316e-01
    z[8,7,1]  R2933     -7.6083678007125854e-01
    z[8,7,1]  R2934     -4.1661381721496582e-01
    z[8,7,1]  R2935     -1.3202227652072906e-02
    z[8,7,1]  R2936     2.2526440024375916e-01
    z[8,7,1]  R2937     -4.9321573227643967e-02
    z[8,7,1]  R2938     3.2392221689224243e-01
    z[8,7,1]  R2939     -8.1055295467376709e-01
    z[8,7,1]  R2940     -7.8756111860275269e-01
    z[8,7,1]  R2941     -7.8263121843338013e-01
    z[8,7,1]  R2942     -7.6649588346481323e-01
    z[8,7,1]  R2943     -3.5260787606239319e-01
    z[8,7,1]  R2944     6.2596333026885986e-01
    z[8,7,1]  R2945     3.2141822576522827e-01
    z[8,7,1]  R2946     3.8521626591682434e-01
    z[8,7,1]  R2947     -5.0963733345270157e-02
    z[8,7,1]  R2948     -2.4608006700873375e-02
    z[8,7,1]  R2949     -8.7529158592224121e-01
    z[8,7,1]  R2950     -8.6956137418746948e-01
    z[8,7,1]  R2951     -8.2586467266082764e-01
    z[8,7,1]  R2952     -8.3300560712814331e-01
    z[8,7,1]  R2953     -9.1836810111999512e-01
    z[8,7,1]  R2954     5.6905514001846313e-01
    z[8,7,1]  R2955     3.3987060189247131e-01
    z[8,7,1]  R2956     5.3938800096511841e-01
    z[8,7,1]  R2957     1.8245634436607361e-01
    z[8,7,1]  R2958     -5.8379560708999634e-01
    z[8,7,1]  R2959     -0.758469820022583
    z[8,7,1]  R2960     0.500398576259613
    z[8,7,1]  R2961     -4.0672817826271057e-01
    z[8,7,1]  R2962     -2.7699694037437439e-01
    z[8,7,1]  R2963     -1.3899168372154236e-01
    z[8,7,1]  R2964     -2.8170236945152283e-01
    z[8,7,2]  R67       1
    z[8,7,2]  R76       -1
    z[8,7,2]  R2826     -1
    z[8,7,2]  R2827     1
    z[8,7,2]  R2836     4.4297706335783005e-02
    z[8,7,2]  R2837     -1.0253424942493439e-01
    z[8,7,2]  R2838     3.4196120500564575e-01
    z[8,7,2]  R2839     1.9986394047737122e-01
    z[8,7,2]  R2840     -8.1668362021446228e-02
    z[8,7,2]  R2841     2.2891965508460999e-01
    z[8,7,2]  R2842     5.2468216419219971e-01
    z[8,7,2]  R2843     -3.9801257848739624e-01
    z[8,7,2]  R2844     -4.8457396030426025e-01
    z[8,7,2]  R2845     -6.3851737976074219e-01
    z[8,7,2]  R2846     -3.4500178694725037e-01
    z[8,7,2]  R2847     -3.0746594071388245e-02
    z[8,7,2]  R2848     0.0672302395105362
    z[8,7,2]  R2849     -1.6945162415504456e-01
    z[8,7,2]  R2850     3.5668212175369263e-01
    z[8,7,2]  R2851     4.5615750551223755e-01
    z[8,7,2]  R2852     1.0421478748321533e-01
    z[8,7,2]  R2853     2.2317555546760559e-01
    z[8,7,2]  R2854     1.8342211842536926e-01
    z[8,7,2]  R2855     3.2977712154388428e-01
    z[8,7,2]  R2856     2.5324460864067078e-01
    z[8,7,2]  R2857     2.0797833800315857e-01
    z[8,7,2]  R2858     5.5952745676040649e-01
    z[8,7,2]  R2859     -1.7250286042690277e-01
    z[8,7,2]  R2860     1.0942266322672367e-02
    z[8,7,2]  R2861     -9.7748890519142151e-02
    z[8,7,2]  R2862     -1.1095040291547775e-01
    z[8,7,2]  R2863     8.1540994346141815e-02
    z[8,7,2]  R2864     1.9990071654319763e-02
    z[8,7,2]  R2865     3.3385327458381653e-01
    z[8,7,2]  R2866     -6.5134182572364807e-02
    z[8,7,2]  R2867     4.1693288087844849e-01
    z[8,7,2]  R2868     -3.3540013432502747e-01
    z[8,7,2]  R2869     3.5556885600090027e-01
    z[8,7,2]  R2870     -1.6824441030621529e-02
    z[8,7,2]  R2871     1.4960496127605438e-01
    z[8,7,2]  R2872     3.2649624347686768e-01
    z[8,7,2]  R2873     -5.8190923929214478e-01
    z[8,7,2]  R2874     -5.5336314439773560e-01
    z[8,7,2]  R2875     -4.6933200210332870e-02
    z[8,7,2]  R2876     -1.1756887659430504e-02
    z[8,7,2]  R2877     0.148001566529274
    z[8,7,2]  R2878     1.7065636813640594e-01
    z[8,7,2]  R2879     -1.1008264124393463e-01
    z[8,7,2]  R2880     1.7419527471065521e-01
    z[8,7,2]  R2881     2.6829114556312561e-01
    z[8,7,2]  R2882     3.6461880803108215e-01
    z[8,7,2]  R2883     1.4063043892383575e-01
    z[8,7,2]  R2884     -0.0342351458966732
    z[8,7,2]  R2885     2.0866812765598297e-01
    z[8,7,2]  R2886     3.6729472875595093e-01
    z[8,7,2]  R2887     3.6069635301828384e-02
    z[8,7,2]  R2888     -5.5398438125848770e-02
    z[8,7,2]  R2889     3.2442143559455872e-01
    z[8,7,2]  R2890     5.2716922014951706e-02
    z[8,7,2]  R2891     -1.0509991645812988e-01
    z[8,7,2]  R2892     1.1707766354084015e-01
    z[8,7,2]  R2893     -4.1049256920814514e-01
    z[8,7,2]  R2894     -3.7668108940124512e-02
    z[8,7,2]  R2895     -3.5654169321060181e-01
    z[8,7,2]  R2896     -0.135230153799057
    z[8,7,2]  R2897     1.7250137403607368e-02
    z[8,7,2]  R2898     -1.4609888195991516e-01
    z[8,7,2]  R2899     -6.6297873854637146e-02
    z[8,7,2]  R2900     2.2318531572818756e-01
    z[8,7,2]  R2901     3.1908690929412842e-02
    z[8,7,2]  R2902     7.6484262943267822e-02
    z[8,7,2]  R2903     6.1499748378992081e-02
    z[8,7,2]  R2904     2.4359221756458282e-01
    z[8,7,2]  R2905     1.7425008118152618e-01
    z[8,7,2]  R2906     -1.3354432582855225e-01
    z[8,7,2]  R2907     -1.3887584209442139e-01
    z[8,7,2]  R2908     -3.9314043521881104e-01
    z[8,7,2]  R2909     1.2395108491182327e-01
    z[8,7,2]  R2910     1.6706761717796326e-01
    z[8,7,2]  R2911     4.9057373404502869e-01
    z[8,7,2]  R2912     2.4277816712856293e-01
    z[8,7,2]  R2913     -1.8345075845718384e-01
    z[8,7,2]  R2914     5.1877623796463013e-01
    z[8,7,2]  R2915     0.0737726092338562
    z[8,7,2]  R2916     4.3167144060134888e-02
    z[8,7,2]  R2917     6.4395293593406677e-02
    z[8,7,2]  R2918     2.7652397751808167e-01
    z[8,7,2]  R2919     6.4655095338821411e-01
    z[8,7,2]  R2920     1.6862362623214722e-01
    z[8,7,2]  R2921     -2.0928969606757164e-02
    z[8,7,2]  R2922     1.7930777370929718e-01
    z[8,7,2]  R2923     3.1241157650947571e-01
    z[8,7,2]  R2924     -1.7183783650398254e-01
    z[8,7,2]  R2925     3.9254274964332581e-01
    z[8,7,2]  R2926     2.8326365351676941e-01
    z[8,7,2]  R2927     4.5729362964630127e-01
    z[8,7,2]  R2928     1.0710256546735764e-01
    z[8,7,2]  R2929     2.5877770781517029e-01
    z[8,7,2]  R2930     2.4274586141109467e-01
    z[8,7,2]  R2931     4.1924878954887390e-01
    z[8,7,2]  R2932     -3.1090310215950012e-01
    z[8,7,2]  R2933     4.1387838125228882e-01
    z[8,7,2]  R2934     2.2290448844432831e-01
    z[8,7,2]  R2935     1.3754753768444061e-01
    z[8,7,2]  R2936     -2.9798170551657677e-02
    z[8,7,2]  R2937     -2.5615268945693970e-01
    z[8,7,2]  R2938     3.2194903492927551e-01
    z[8,7,2]  R2939     -0.251189261674881
    z[8,7,2]  R2940     -1.7484319210052490e-01
    z[8,7,2]  R2941     -1.2572652101516724e-01
    z[8,7,2]  R2942     1.7241321504116058e-02
    z[8,7,2]  R2943     7.6796674728393555e-01
    z[8,7,2]  R2944     -7.9537652432918549e-02
    z[8,7,2]  R2945     3.1214842200279236e-01
    z[8,7,2]  R2946     -4.9438709020614624e-01
    z[8,7,2]  R2947     0.512950599193573
    z[8,7,2]  R2948     3.3939656615257263e-01
    z[8,7,2]  R2949     6.9249749183654785e-02
    z[8,7,2]  R2950     -2.1348603069782257e-01
    z[8,7,2]  R2951     -0.0791369378566742
    z[8,7,2]  R2952     2.7444148436188698e-02
    z[8,7,2]  R2953     -2.9958806931972504e-02
    z[8,7,2]  R2954     -6.3811767101287842e-01
    z[8,7,2]  R2955     2.1972709894180298e-01
    z[8,7,2]  R2956     2.5459833443164825e-02
    z[8,7,2]  R2957     5.6263640522956848e-02
    z[8,7,2]  R2958     3.9968156814575195e-01
    z[8,7,2]  R2959     -1.6684535145759583e-01
    z[8,7,2]  R2960     -6.5829616785049438e-01
    z[8,7,2]  R2961     -4.8338127136230469e-01
    z[8,7,2]  R2962     -6.8979966640472412e-01
    z[8,7,2]  R2963     5.9844231605529785e-01
    z[8,7,2]  R2964     -6.1854153871536255e-01
    z[8,7,3]  R68       1
    z[8,7,3]  R77       -1
    z[8,7,3]  R2828     -1
    z[8,7,3]  R2829     1
    z[8,7,3]  R2836     3.3893135190010071e-01
    z[8,7,3]  R2837     1.7238068580627441e-01
    z[8,7,3]  R2838     -8.0694389343261719e-01
    z[8,7,3]  R2839     2.2265070676803589e-01
    z[8,7,3]  R2840     -1.2656930088996887e-01
    z[8,7,3]  R2841     4.0449026226997375e-01
    z[8,7,3]  R2842     -0.569337010383606
    z[8,7,3]  R2843     -6.4385145902633667e-01
    z[8,7,3]  R2844     1.1762108653783798e-02
    z[8,7,3]  R2845     -2.0890416204929352e-01
    z[8,7,3]  R2846     0.820968508720398
    z[8,7,3]  R2847     6.7245924472808838e-01
    z[8,7,3]  R2848     6.3162380456924438e-01
    z[8,7,3]  R2849     7.0842069387435913e-01
    z[8,7,3]  R2850     6.5730887651443481e-01
    z[8,7,3]  R2851     7.4381065368652344e-01
    z[8,7,3]  R2852     8.7322556972503662e-01
    z[8,7,3]  R2853     2.5221675634384155e-01
    z[8,7,3]  R2854     -2.6172018051147461e-01
    z[8,7,3]  R2855     3.6002656817436218e-01
    z[8,7,3]  R2856     3.9744228124618530e-01
    z[8,7,3]  R2857     2.2856892645359039e-01
    z[8,7,3]  R2858     3.2866531610488892e-01
    z[8,7,3]  R2859     -1.9448810815811157e-01
    z[8,7,3]  R2860     -1.3624049723148346e-01
    z[8,7,3]  R2861     1.0560864955186844e-01
    z[8,7,3]  R2862     8.2533389329910278e-02
    z[8,7,3]  R2863     3.7692766636610031e-02
    z[8,7,3]  R2864     1.9963359832763672e-01
    z[8,7,3]  R2865     6.4280843734741211e-01
    z[8,7,3]  R2866     7.4181818962097168e-01
    z[8,7,3]  R2867     8.2144778966903687e-01
    z[8,7,3]  R2868     6.5293055772781372e-01
    z[8,7,3]  R2869     6.0793638229370117e-01
    z[8,7,3]  R2870     -2.7843394875526428e-01
    z[8,7,3]  R2871     -1.4027177821844816e-03
    z[8,7,3]  R2872     -1.1982208490371704e-01
    z[8,7,3]  R2873     -1.3696564733982086e-01
    z[8,7,3]  R2874     -4.2138215899467468e-01
    z[8,7,3]  R2875     2.5789457559585571e-01
    z[8,7,3]  R2876     7.6679818332195282e-02
    z[8,7,3]  R2877     7.4222676455974579e-02
    z[8,7,3]  R2878     6.7925274372100830e-02
    z[8,7,3]  R2879     4.2619869112968445e-02
    z[8,7,3]  R2880     1.5018087625503540e-01
    z[8,7,3]  R2881     -2.2287322208285332e-02
    z[8,7,3]  R2882     1.7334936559200287e-01
    z[8,7,3]  R2883     1.5530005097389221e-01
    z[8,7,3]  R2884     0.0453343540430069
    z[8,7,3]  R2885     6.0690528154373169e-01
    z[8,7,3]  R2886     5.7045966386795044e-01
    z[8,7,3]  R2887     5.9706658124923706e-01
    z[8,7,3]  R2888     6.5926498174667358e-01
    z[8,7,3]  R2889     5.5603188276290894e-01
    z[8,7,3]  R2890     5.6152331829071045e-01
    z[8,7,3]  R2891     6.3624918460845947e-01
    z[8,7,3]  R2892     4.3104144930839539e-01
    z[8,7,3]  R2893     -1.4310272037982941e-01
    z[8,7,3]  R2894     3.2803124189376831e-01
    z[8,7,3]  R2895     6.1675232648849487e-01
    z[8,7,3]  R2896     4.8381385207176208e-01
    z[8,7,3]  R2897     1.1437595635652542e-01
    z[8,7,3]  R2898     4.5385140925645828e-02
    z[8,7,3]  R2899     -4.7429639101028442e-01
    z[8,7,3]  R2900     -1.3199462555348873e-02
    z[8,7,3]  R2901     2.3878661915659904e-02
    z[8,7,3]  R2902     -1.5798424184322357e-01
    z[8,7,3]  R2903     -1.9470445811748505e-01
    z[8,7,3]  R2904     2.4173672497272491e-01
    z[8,7,3]  R2905     6.5899646282196045e-01
    z[8,7,3]  R2906     7.6095026731491089e-01
    z[8,7,3]  R2907     -7.1903415024280548e-02
    z[8,7,3]  R2908     7.1365468204021454e-02
    z[8,7,3]  R2909     -2.8981423377990723e-01
    z[8,7,3]  R2910     3.6298626661300659e-01
    z[8,7,3]  R2911     1.3017773628234863e-01
    z[8,7,3]  R2912     -1.4988839626312256e-01
    z[8,7,3]  R2913     -3.9614096283912659e-01
    z[8,7,3]  R2914     -3.0419471859931946e-01
    z[8,7,3]  R2915     -2.1315976977348328e-01
    z[8,7,3]  R2916     -2.4674201011657715e-01
    z[8,7,3]  R2917     6.0045200586318970e-01
    z[8,7,3]  R2918     0.831079363822937
    z[8,7,3]  R2919     2.4031335115432739e-01
    z[8,7,3]  R2920     1.3446410000324249e-01
    z[8,7,3]  R2921     1.8834297358989716e-01
    z[8,7,3]  R2922     -4.5580846071243286e-01
    z[8,7,3]  R2923     -4.4311785697937012e-01
    z[8,7,3]  R2924     3.0654057860374451e-01
    z[8,7,3]  R2925     -3.5950881242752075e-01
    z[8,7,3]  R2926     4.5377832651138306e-01
    z[8,7,3]  R2927     1.6288067400455475e-01
    z[8,7,3]  R2928     7.8887414932250977e-01
    z[8,7,3]  R2929     6.0306102037429810e-01
    z[8,7,3]  R2930     2.2944065928459167e-01
    z[8,7,3]  R2931     1.3756365515291691e-02
    z[8,7,3]  R2932     1.4490705728530884e-01
    z[8,7,3]  R2933     9.3097344040870667e-02
    z[8,7,3]  R2934     -8.0060526728630066e-02
    z[8,7,3]  R2935     7.7907508611679077e-01
    z[8,7,3]  R2936     7.3133997619152069e-02
    z[8,7,3]  R2937     7.1731686592102051e-01
    z[8,7,3]  R2938     -1.1281068623065948e-01
    z[8,7,3]  R2939     4.0450257062911987e-01
    z[8,7,3]  R2940     0.00385760678909719
    z[8,7,3]  R2941     -8.1982992589473724e-02
    z[8,7,3]  R2942     1.7649991810321808e-01
    z[8,7,3]  R2943     -2.6585987210273743e-01
    z[8,7,3]  R2944     -2.9219236969947815e-01
    z[8,7,3]  R2945     4.7909659147262573e-01
    z[8,7,3]  R2946     6.0675078630447388e-01
    z[8,7,3]  R2947     7.6968587934970856e-02
    z[8,7,3]  R2948     5.7475709915161133e-01
    z[8,7,3]  R2949     -1.0565434396266937e-01
    z[8,7,3]  R2950     -7.3891326785087585e-02
    z[8,7,3]  R2951     4.7077399492263794e-01
    z[8,7,3]  R2952     3.1705811619758606e-01
    z[8,7,3]  R2953     -3.5898125171661377e-01
    z[8,7,3]  R2954     -4.4451120495796204e-01
    z[8,7,3]  R2955     1.5172217041254044e-02
    z[8,7,3]  R2956     6.6756260395050049e-01
    z[8,7,3]  R2957     4.9172133207321167e-01
    z[8,7,3]  R2958     1.4260038733482361e-01
    z[8,7,3]  R2959     -4.7486531734466553e-01
    z[8,7,3]  R2960     -3.3216324448585510e-01
    z[8,7,3]  R2961     -2.8205469250679016e-01
    z[8,7,3]  R2962     -5.6749057024717331e-02
    z[8,7,3]  R2963     -1.0599813610315323e-01
    z[8,7,3]  R2964     -1.9939118623733521e-01
    z[8,7,4]  R69       1
    z[8,7,4]  R78       -1
    z[8,7,4]  R2830     -1
    z[8,7,4]  R2831     1
    z[8,7,4]  R2836     6.1544120311737061e-01
    z[8,7,4]  R2837     -1.6038011014461517e-01
    z[8,7,4]  R2838     -4.4960159808397293e-02
    z[8,7,4]  R2839     3.2772939652204514e-02
    z[8,7,4]  R2840     2.4203942716121674e-01
    z[8,7,4]  R2841     -7.1600514650344849e-01
    z[8,7,4]  R2842     -4.7515761852264404e-01
    z[8,7,4]  R2843     -4.7687861323356628e-01
    z[8,7,4]  R2844     -1.4801302552223206e-01
    z[8,7,4]  R2845     -8.6326800286769867e-02
    z[8,7,4]  R2846     -1.1482661962509155e-01
    z[8,7,4]  R2847     -7.4615702033042908e-03
    z[8,7,4]  R2848     -1.4398986101150513e-01
    z[8,7,4]  R2849     3.1648358702659607e-01
    z[8,7,4]  R2850     8.5796646773815155e-02
    z[8,7,4]  R2851     1.6937313973903656e-01
    z[8,7,4]  R2852     3.5484090447425842e-01
    z[8,7,4]  R2853     -5.3575527854263783e-03
    z[8,7,4]  R2854     -5.2903532981872559e-02
    z[8,7,4]  R2855     -5.3471463918685913e-01
    z[8,7,4]  R2856     -0.59151291847229
    z[8,7,4]  R2857     -7.9646848142147064e-02
    z[8,7,4]  R2858     -0.0201775711029768
    z[8,7,4]  R2859     4.5154165476560593e-02
    z[8,7,4]  R2860     1.6619296371936798e-01
    z[8,7,4]  R2861     1.6266991198062897e-01
    z[8,7,4]  R2862     -3.7581852078437805e-01
    z[8,7,4]  R2863     -2.7733482420444489e-03
    z[8,7,4]  R2864     2.2970676422119141e-01
    z[8,7,4]  R2865     -1.4652857184410095e-01
    z[8,7,4]  R2866     1.3311018049716949e-01
    z[8,7,4]  R2867     2.1338362246751785e-02
    z[8,7,4]  R2868     -4.9263462424278259e-01
    z[8,7,4]  R2869     1.3779577612876892e-01
    z[8,7,4]  R2870     -3.4126002341508865e-02
    z[8,7,4]  R2871     -1.0386031121015549e-01
    z[8,7,4]  R2872     -1.1333167552947998e-02
    z[8,7,4]  R2873     1.8678863346576691e-01
    z[8,7,4]  R2874     1.9302532076835632e-02
    z[8,7,4]  R2875     -1.1496312171220779e-01
    z[8,7,4]  R2876     6.1036888509988785e-02
    z[8,7,4]  R2877     1.1571945995092392e-01
    z[8,7,4]  R2878     -3.8888859748840332e-01
    z[8,7,4]  R2879     -1.1638686805963516e-01
    z[8,7,4]  R2880     -2.9812756180763245e-01
    z[8,7,4]  R2881     -1.9319224357604980e-01
    z[8,7,4]  R2882     1.6015812754631042e-01
    z[8,7,4]  R2883     4.2423516511917114e-01
    z[8,7,4]  R2884     -1.7063283594325185e-03
    z[8,7,4]  R2885     -3.7976670265197754e-01
    z[8,7,4]  R2886     -5.4631937295198441e-02
    z[8,7,4]  R2887     -4.7857353091239929e-01
    z[8,7,4]  R2888     1.5906213223934174e-01
    z[8,7,4]  R2889     1.1276460252702236e-02
    z[8,7,4]  R2890     5.0584155321121216e-01
    z[8,7,4]  R2891     2.3941858112812042e-01
    z[8,7,4]  R2892     -0.562581479549408
    z[8,7,4]  R2893     8.6790435016155243e-02
    z[8,7,4]  R2894     -1.2445009499788284e-01
    z[8,7,4]  R2895     4.0344062447547913e-01
    z[8,7,4]  R2896     -2.3010616004467010e-01
    z[8,7,4]  R2897     -2.1427439153194427e-01
    z[8,7,4]  R2898     -5.6533205509185791e-01
    z[8,7,4]  R2899     -1.5597687661647797e-01
    z[8,7,4]  R2900     -4.6064171195030212e-01
    z[8,7,4]  R2901     -6.3801310956478119e-02
    z[8,7,4]  R2902     5.2818089723587036e-01
    z[8,7,4]  R2903     4.9443128705024719e-01
    z[8,7,4]  R2904     -2.1657621860504150e-01
    z[8,7,4]  R2905     -1.7721369862556458e-02
    z[8,7,4]  R2906     3.4907300025224686e-02
    z[8,7,4]  R2907     -1.4428691565990448e-01
    z[8,7,4]  R2908     5.3972166031599045e-02
    z[8,7,4]  R2909     3.9959940314292908e-01
    z[8,7,4]  R2910     -4.4225663878023624e-03
    z[8,7,4]  R2911     5.6520360708236694e-01
    z[8,7,4]  R2912     2.9839816689491272e-01
    z[8,7,4]  R2913     -1.2828929722309113e-01
    z[8,7,4]  R2914     2.1192553639411926e-01
    z[8,7,4]  R2915     8.9194908738136292e-02
    z[8,7,4]  R2916     3.6870828270912170e-01
    z[8,7,4]  R2917     -3.1754696369171143e-01
    z[8,7,4]  R2918     2.1599155664443970e-01
    z[8,7,4]  R2919     3.5281282663345337e-01
    z[8,7,4]  R2920     -0.0717427060008049
    z[8,7,4]  R2921     1.4988392591476440e-01
    z[8,7,4]  R2922     1.9288735091686249e-01
    z[8,7,4]  R2923     -3.0036326497793198e-02
    z[8,7,4]  R2924     -2.2175274789333344e-02
    z[8,7,4]  R2925     -5.9873346239328384e-02
    z[8,7,4]  R2926     1.8889187276363373e-01
    z[8,7,4]  R2927     -2.0365279912948608e-01
    z[8,7,4]  R2928     -5.0281536579132080e-01
    z[8,7,4]  R2929     -7.1040540933609009e-02
    z[8,7,4]  R2930     7.4606128036975861e-02
    z[8,7,4]  R2931     2.8247093781828880e-02
    z[8,7,4]  R2932     8.0307433381676674e-04
    z[8,7,4]  R2933     -8.1252768635749817e-02
    z[8,7,4]  R2934     -6.5929013490676880e-01
    z[8,7,4]  R2935     -3.4355142712593079e-01
    z[8,7,4]  R2936     1.5855866670608521e-01
    z[8,7,4]  R2937     4.9937221407890320e-01
    z[8,7,4]  R2938     2.7032768726348877e-01
    z[8,7,4]  R2939     9.5205254852771759e-02
    z[8,7,4]  R2940     2.9664269089698792e-01
    z[8,7,4]  R2941     -3.3074134588241577e-01
    z[8,7,4]  R2942     -3.5192474722862244e-01
    z[8,7,4]  R2943     -2.4802875518798828e-01
    z[8,7,4]  R2944     -1.7932142317295074e-01
    z[8,7,4]  R2945     -1.3013717532157898e-01
    z[8,7,4]  R2946     -2.1842719614505768e-01
    z[8,7,4]  R2947     -3.3131629228591919e-01
    z[8,7,4]  R2948     3.6168730258941650e-01
    z[8,7,4]  R2949     7.0028595626354218e-02
    z[8,7,4]  R2950     3.1607393175363541e-02
    z[8,7,4]  R2951     -3.6443449556827545e-02
    z[8,7,4]  R2952     -7.0717319846153259e-02
    z[8,7,4]  R2953     -8.0152988433837891e-02
    z[8,7,4]  R2954     -9.5381431281566620e-02
    z[8,7,4]  R2955     -8.0028679221868515e-03
    z[8,7,4]  R2956     -4.6683689579367638e-03
    z[8,7,4]  R2957     2.3104159533977509e-01
    z[8,7,4]  R2958     -4.9141305498778820e-04
    z[8,7,4]  R2959     2.8214901685714722e-01
    z[8,7,4]  R2960     1.9687581062316895e-01
    z[8,7,4]  R2961     6.2029594182968140e-01
    z[8,7,4]  R2962     6.0424196720123291e-01
    z[8,7,4]  R2963     -3.1634208559989929e-01
    z[8,7,4]  R2964     6.7752408981323242e-01
    z[8,7,5]  R70       1
    z[8,7,5]  R79       -1
    z[8,7,5]  R2832     -1
    z[8,7,5]  R2833     1
    z[8,7,5]  R2836     1.3929626345634460e-01
    z[8,7,5]  R2837     -3.5279604792594910e-01
    z[8,7,5]  R2838     3.8220237940549850e-02
    z[8,7,5]  R2839     2.1354711055755615e-01
    z[8,7,5]  R2840     -4.0999558568000793e-01
    z[8,7,5]  R2841     8.4200963377952576e-02
    z[8,7,5]  R2842     2.8404369950294495e-01
    z[8,7,5]  R2843     3.8109812140464783e-01
    z[8,7,5]  R2844     7.8728175163269043e-01
    z[8,7,5]  R2845     6.7090344429016113e-01
    z[8,7,5]  R2846     3.5295647382736206e-01
    z[8,7,5]  R2847     -2.4163994938135147e-02
    z[8,7,5]  R2848     2.7940610051155090e-01
    z[8,7,5]  R2849     2.9542475938796997e-02
    z[8,7,5]  R2850     2.8805750608444214e-01
    z[8,7,5]  R2851     -1.4151780307292938e-01
    z[8,7,5]  R2852     -5.8375686407089233e-02
    z[8,7,5]  R2853     5.0904947519302368e-01
    z[8,7,5]  R2854     -2.0721639692783356e-01
    z[8,7,5]  R2855     2.2999155521392822e-01
    z[8,7,5]  R2856     1.7055776715278625e-01
    z[8,7,5]  R2857     4.8161312937736511e-01
    z[8,7,5]  R2858     -1.8148081004619598e-01
    z[8,7,5]  R2859     0.072996124625206
    z[8,7,5]  R2860     -1.3415264897048473e-02
    z[8,7,5]  R2861     2.1625134348869324e-01
    z[8,7,5]  R2862     0.118670254945755
    z[8,7,5]  R2863     -0.221003919839859
    z[8,7,5]  R2864     -3.0883875489234924e-01
    z[8,7,5]  R2865     -1.3896717131137848e-01
    z[8,7,5]  R2866     3.2583504915237427e-01
    z[8,7,5]  R2867     -8.8345922529697418e-02
    z[8,7,5]  R2868     2.5804251432418823e-01
    z[8,7,5]  R2869     2.5488847494125366e-01
    z[8,7,5]  R2870     -0.0645069107413292
    z[8,7,5]  R2871     2.2342254221439362e-01
    z[8,7,5]  R2872     5.1044980064034462e-03
    z[8,7,5]  R2873     -2.3616391420364380e-01
    z[8,7,5]  R2874     -3.1501868367195129e-01
    z[8,7,5]  R2875     0.0596165657043457
    z[8,7,5]  R2876     -1.5421052277088165e-01
    z[8,7,5]  R2877     2.5916749238967896e-01
    z[8,7,5]  R2878     3.5540476441383362e-02
    z[8,7,5]  R2879     2.4593852460384369e-01
    z[8,7,5]  R2880     2.6339060068130493e-01
    z[8,7,5]  R2881     -3.1690327450633049e-03
    z[8,7,5]  R2882     -2.6576307415962219e-01
    z[8,7,5]  R2883     7.5584337115287781e-02
    z[8,7,5]  R2884     -1.3800999522209167e-01
    z[8,7,5]  R2885     -2.3829996585845947e-01
    z[8,7,5]  R2886     -4.3946501612663269e-01
    z[8,7,5]  R2887     -3.5648146271705627e-01
    z[8,7,5]  R2888     -4.4333106279373169e-01
    z[8,7,5]  R2889     -1.6065049916505814e-02
    z[8,7,5]  R2890     1.9907447695732117e-01
    z[8,7,5]  R2891     1.5110961161553860e-02
    z[8,7,5]  R2892     4.7820255160331726e-01
    z[8,7,5]  R2893     3.8310371339321136e-02
    z[8,7,5]  R2894     8.0996805429458618e-01
    z[8,7,5]  R2895     -1.6127489507198334e-01
    z[8,7,5]  R2896     0.690273106098175
    z[8,7,5]  R2897     -3.0313533544540405e-01
    z[8,7,5]  R2898     7.4939350597560406e-03
    z[8,7,5]  R2899     0.0902993455529213
    z[8,7,5]  R2900     -4.8316949605941772e-01
    z[8,7,5]  R2901     1.0509271919727325e-01
    z[8,7,5]  R2902     -1.3863454759120941e-01
    z[8,7,5]  R2903     -5.6824021041393280e-02
    z[8,7,5]  R2904     2.8457471728324890e-01
    z[8,7,5]  R2905     -7.8652210533618927e-02
    z[8,7,5]  R2906     1.3941408693790436e-01
    z[8,7,5]  R2907     -5.6810826063156128e-01
    z[8,7,5]  R2908     2.0864079892635345e-01
    z[8,7,5]  R2909     3.5150960087776184e-01
    z[8,7,5]  R2910     3.6750671267509460e-01
    z[8,7,5]  R2911     8.7569728493690491e-02
    z[8,7,5]  R2912     5.7715136557817459e-02
    z[8,7,5]  R2913     2.7905693650245667e-01
    z[8,7,5]  R2914     -3.2278639078140259e-01
    z[8,7,5]  R2915     2.1576821804046631e-01
    z[8,7,5]  R2916     1.7159767448902130e-01
    z[8,7,5]  R2917     4.1267678141593933e-01
    z[8,7,5]  R2918     -1.2315607070922852e-01
    z[8,7,5]  R2919     -7.2828345000743866e-02
    z[8,7,5]  R2920     1.3304447755217552e-02
    z[8,7,5]  R2921     3.5721620917320251e-01
    z[8,7,5]  R2922     -5.7846039533615112e-01
    z[8,7,5]  R2923     -5.3011399507522583e-01
    z[8,7,5]  R2924     2.8076618909835815e-01
    z[8,7,5]  R2925     -2.3221983015537262e-01
    z[8,7,5]  R2926     1.2673947215080261e-01
    z[8,7,5]  R2927     -2.8106454014778137e-01
    z[8,7,5]  R2928     1.4398138225078583e-01
    z[8,7,5]  R2929     -2.9013365507125854e-01
    z[8,7,5]  R2930     1.1404684931039810e-01
    z[8,7,5]  R2931     -0.0963074192404747
    z[8,7,5]  R2932     -1.9495855271816254e-01
    z[8,7,5]  R2933     2.8034153580665588e-01
    z[8,7,5]  R2934     -0.323823481798172
    z[8,7,5]  R2935     3.7357372045516968e-01
    z[8,7,5]  R2936     -5.8438368141651154e-02
    z[8,7,5]  R2937     -7.9122297465801239e-02
    z[8,7,5]  R2938     -6.4036726951599121e-01
    z[8,7,5]  R2939     -1.8583790957927704e-01
    z[8,7,5]  R2940     -3.2547211647033691e-01
    z[8,7,5]  R2941     -2.4672269821166992e-01
    z[8,7,5]  R2942     -1.0942756384611130e-01
    z[8,7,5]  R2943     8.1528417766094208e-02
    z[8,7,5]  R2944     2.4342155456542969e-01
    z[8,7,5]  R2945     -2.1648842096328735e-01
    z[8,7,5]  R2946     -1.0613638907670975e-01
    z[8,7,5]  R2947     -6.7212902009487152e-02
    z[8,7,5]  R2948     2.4922121316194534e-02
    z[8,7,5]  R2949     -3.5402163863182068e-01
    z[8,7,5]  R2950     -2.4613919854164124e-01
    z[8,7,5]  R2951     -1.1041836440563202e-01
    z[8,7,5]  R2952     -0.289393812417984
    z[8,7,5]  R2953     -1.6315674409270287e-02
    z[8,7,5]  R2954     9.6302941441535950e-02
    z[8,7,5]  R2955     -1.8625985085964203e-01
    z[8,7,5]  R2956     1.9237220287322998e-01
    z[8,7,5]  R2957     -2.5953933596611023e-01
    z[8,7,5]  R2958     2.0789082348346710e-01
    z[8,7,5]  R2959     2.5498500093817711e-02
    z[8,7,5]  R2960     3.3535334467887878e-01
    z[8,7,5]  R2961     -2.5545755028724670e-01
    z[8,7,5]  R2962     -2.6062300801277161e-01
    z[8,7,5]  R2963     -3.4602773189544678e-01
    z[8,7,5]  R2964     8.0022260546684265e-02
    z[8,7,6]  R71       1
    z[8,7,6]  R80       -1
    z[8,7,6]  R2834     -1
    z[8,7,6]  R2835     1
    z[8,7,6]  R2836     -2.7296485379338264e-02
    z[8,7,6]  R2837     -6.9551318883895874e-01
    z[8,7,6]  R2838     -9.9850669503211975e-03
    z[8,7,6]  R2839     1.2903241813182831e-01
    z[8,7,6]  R2840     0.614565372467041
    z[8,7,6]  R2841     4.7373369336128235e-01
    z[8,7,6]  R2842     -9.6105104312300682e-03
    z[8,7,6]  R2843     -1.6487258672714233e-01
    z[8,7,6]  R2844     -3.3270925283432007e-01
    z[8,7,6]  R2845     -1.5050514601171017e-02
    z[8,7,6]  R2846     2.5339301675558090e-02
    z[8,7,6]  R2847     4.1012936830520630e-01
    z[8,7,6]  R2848     -2.2790496051311493e-01
    z[8,7,6]  R2849     1.9731713831424713e-01
    z[8,7,6]  R2850     -8.0265142023563385e-02
    z[8,7,6]  R2851     -2.3283023387193680e-02
    z[8,7,6]  R2852     9.9094063043594360e-02
    z[8,7,6]  R2853     3.0142712593078613e-01
    z[8,7,6]  R2854     1.8220894038677216e-01
    z[8,7,6]  R2855     1.3260385394096375e-01
    z[8,7,6]  R2856     3.8297748565673828e-01
    z[8,7,6]  R2857     2.5355115532875061e-01
    z[8,7,6]  R2858     1.6693432629108429e-01
    z[8,7,6]  R2859     1.8298017978668213e-01
    z[8,7,6]  R2860     3.3461713790893555e-01
    z[8,7,6]  R2861     1.3354423642158508e-01
    z[8,7,6]  R2862     3.5253062844276428e-02
    z[8,7,6]  R2863     -3.4190145134925842e-01
    z[8,7,6]  R2864     3.3973187208175659e-02
    z[8,7,6]  R2865     3.8801971077919006e-01
    z[8,7,6]  R2866     3.2108667492866516e-01
    z[8,7,6]  R2867     2.4911326169967651e-01
    z[8,7,6]  R2868     2.7404436469078064e-01
    z[8,7,6]  R2869     2.4183419346809387e-01
    z[8,7,6]  R2870     -1.0881573706865311e-01
    z[8,7,6]  R2871     -2.9862526059150696e-01
    z[8,7,6]  R2872     0.0569380484521389
    z[8,7,6]  R2873     -5.3832545876502991e-02
    z[8,7,6]  R2874     -2.0913438498973846e-01
    z[8,7,6]  R2875     -1.3391232490539551e-01
    z[8,7,6]  R2876     -5.5602509528398514e-02
    z[8,7,6]  R2877     9.5840133726596832e-02
    z[8,7,6]  R2878     1.4374126493930817e-01
    z[8,7,6]  R2879     -1.5773972868919373e-01
    z[8,7,6]  R2880     0.0995691567659378
    z[8,7,6]  R2881     -7.6256953179836273e-02
    z[8,7,6]  R2882     1.4368730783462524e-01
    z[8,7,6]  R2883     -1.5407225489616394e-01
    z[8,7,6]  R2884     1.6710811853408813e-01
    z[8,7,6]  R2885     2.9666331410408020e-01
    z[8,7,6]  R2886     1.7016613855957985e-02
    z[8,7,6]  R2887     -2.0249038934707642e-01
    z[8,7,6]  R2888     -1.0928864032030106e-01
    z[8,7,6]  R2889     6.4154869318008423e-01
    z[8,7,6]  R2890     5.3281837701797485e-01
    z[8,7,6]  R2891     3.0589789152145386e-01
    z[8,7,6]  R2892     2.4263255298137665e-01
    z[8,7,6]  R2893     -2.9404631257057190e-01
    z[8,7,6]  R2894     2.7412512898445129e-01
    z[8,7,6]  R2895     4.8868253827095032e-02
    z[8,7,6]  R2896     8.0984615487977862e-04
    z[8,7,6]  R2897     -1.7131294310092926e-01
    z[8,7,6]  R2898     -7.9409822821617126e-02
    z[8,7,6]  R2899     3.2485806941986084e-01
    z[8,7,6]  R2900     8.6883746087551117e-02
    z[8,7,6]  R2901     1.9362498819828033e-01
    z[8,7,6]  R2902     3.8350574672222137e-02
    z[8,7,6]  R2903     -0.0493636429309845
    z[8,7,6]  R2904     9.3438185751438141e-02
    z[8,7,6]  R2905     5.2796018123626709e-01
    z[8,7,6]  R2906     -4.5082005858421326e-01
    z[8,7,6]  R2907     -3.9235156774520874e-01
    z[8,7,6]  R2908     -2.1485263109207153e-01
    z[8,7,6]  R2909     1.0583304613828659e-01
    z[8,7,6]  R2910     2.6076692342758179e-01
    z[8,7,6]  R2911     0.101309634745121
    z[8,7,6]  R2912     1.8745566904544830e-01
    z[8,7,6]  R2913     6.6299118101596832e-02
    z[8,7,6]  R2914     3.4264308214187622e-01
    z[8,7,6]  R2915     3.6983732134103775e-03
    z[8,7,6]  R2916     -3.6549825221300125e-02
    z[8,7,6]  R2917     5.6970596313476562e-02
    z[8,7,6]  R2918     -3.0264276266098022e-01
    z[8,7,6]  R2919     1.8844233453273773e-01
    z[8,7,6]  R2920     1.1336199194192886e-01
    z[8,7,6]  R2921     -1.3753518462181091e-01
    z[8,7,6]  R2922     2.8746657073497772e-02
    z[8,7,6]  R2923     3.0018597841262817e-01
    z[8,7,6]  R2924     -3.2065957784652710e-01
    z[8,7,6]  R2925     3.5046026110649109e-01
    z[8,7,6]  R2926     1.7457805573940277e-01
    z[8,7,6]  R2927     6.3427664339542389e-02
    z[8,7,6]  R2928     -1.4630000293254852e-01
    z[8,7,6]  R2929     -3.6590874195098877e-01
    z[8,7,6]  R2930     2.3407968692481518e-03
    z[8,7,6]  R2931     1.4083732664585114e-01
    z[8,7,6]  R2932     -4.5543056726455688e-01
    z[8,7,6]  R2933     3.6189281940460205e-01
    z[8,7,6]  R2934     5.9667207300662994e-02
    z[8,7,6]  R2935     3.9056394249200821e-02
    z[8,7,6]  R2936     -3.5774940252304077e-01
    z[8,7,6]  R2937     6.4626209437847137e-02
    z[8,7,6]  R2938     -5.1362957805395126e-02
    z[8,7,6]  R2939     -8.9024573564529419e-02
    z[8,7,6]  R2940     -3.5536146163940430e-01
    z[8,7,6]  R2941     -2.2796842455863953e-01
    z[8,7,6]  R2942     -2.1361030638217926e-01
    z[8,7,6]  R2943     1.4386756718158722e-01
    z[8,7,6]  R2944     -2.4325957521796227e-02
    z[8,7,6]  R2945     -2.0830747485160828e-01
    z[8,7,6]  R2946     -4.2313057184219360e-01
    z[8,7,6]  R2947     2.8809100389480591e-01
    z[8,7,6]  R2948     -2.6862871646881104e-01
    z[8,7,6]  R2949     -1.3921138644218445e-01
    z[8,7,6]  R2950     -2.2763611376285553e-01
    z[8,7,6]  R2951     -1.7594610154628754e-01
    z[8,7,6]  R2952     -3.2816660404205322e-01
    z[8,7,6]  R2953     1.3124649226665497e-01
    z[8,7,6]  R2954     -2.2728709876537323e-01
    z[8,7,6]  R2955     -8.9128427207469940e-02
    z[8,7,6]  R2956     -1.5429088473320007e-01
    z[8,7,6]  R2957     -1.7627786099910736e-01
    z[8,7,6]  R2958     -3.0590042471885681e-01
    z[8,7,6]  R2959     1.0293000936508179e-01
    z[8,7,6]  R2960     2.2025278210639954e-01
    z[8,7,6]  R2961     2.3513735830783844e-01
    z[8,7,6]  R2962     4.3343797326087952e-02
    z[8,7,6]  R2963     -5.9962904453277588e-01
    z[8,7,6]  R2964     1.0144189745187759e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    length[8]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
    delta[8,0]  R74       1
    delta[8,1]  R75       1
    delta[8,2]  R76       1
    delta[8,3]  R77       1
    delta[8,4]  R78       1
    delta[8,5]  R79       1
    delta[8,6]  R80       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R73       1
    RHS1      R81       1
    RHS1      R82       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,5]
 BV BND1      phi[5,0]
 BV BND1      phi[9,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[3,8]
 BV BND1      phi[8,3]
 BV BND1      phi[4,8]
 BV BND1      phi[8,4]
 BV BND1      phi[4,10]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[9,5]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[6,8]
 BV BND1      phi[8,6]
 BV BND1      phi[7,8]
 BV BND1      phi[8,7]
 BV BND1      phi[8,10]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,5,0]
 FR BND1      z[0,5,1]
 FR BND1      z[0,5,2]
 FR BND1      z[0,5,3]
 FR BND1      z[0,5,4]
 FR BND1      z[0,5,5]
 FR BND1      z[0,5,6]
 FR BND1      z[5,0,0]
 FR BND1      z[5,0,1]
 FR BND1      z[5,0,2]
 FR BND1      z[5,0,3]
 FR BND1      z[5,0,4]
 FR BND1      z[5,0,5]
 FR BND1      z[5,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[3,8,0]
 FR BND1      z[3,8,1]
 FR BND1      z[3,8,2]
 FR BND1      z[3,8,3]
 FR BND1      z[3,8,4]
 FR BND1      z[3,8,5]
 FR BND1      z[3,8,6]
 FR BND1      z[8,3,0]
 FR BND1      z[8,3,1]
 FR BND1      z[8,3,2]
 FR BND1      z[8,3,3]
 FR BND1      z[8,3,4]
 FR BND1      z[8,3,5]
 FR BND1      z[8,3,6]
 FR BND1      z[4,8,0]
 FR BND1      z[4,8,1]
 FR BND1      z[4,8,2]
 FR BND1      z[4,8,3]
 FR BND1      z[4,8,4]
 FR BND1      z[4,8,5]
 FR BND1      z[4,8,6]
 FR BND1      z[8,4,0]
 FR BND1      z[8,4,1]
 FR BND1      z[8,4,2]
 FR BND1      z[8,4,3]
 FR BND1      z[8,4,4]
 FR BND1      z[8,4,5]
 FR BND1      z[8,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      z[6,8,0]
 FR BND1      z[6,8,1]
 FR BND1      z[6,8,2]
 FR BND1      z[6,8,3]
 FR BND1      z[6,8,4]
 FR BND1      z[6,8,5]
 FR BND1      z[6,8,6]
 FR BND1      z[8,6,0]
 FR BND1      z[8,6,1]
 FR BND1      z[8,6,2]
 FR BND1      z[8,6,3]
 FR BND1      z[8,6,4]
 FR BND1      z[8,6,5]
 FR BND1      z[8,6,6]
 FR BND1      z[7,8,0]
 FR BND1      z[7,8,1]
 FR BND1      z[7,8,2]
 FR BND1      z[7,8,3]
 FR BND1      z[7,8,4]
 FR BND1      z[7,8,5]
 FR BND1      z[7,8,6]
 FR BND1      z[8,7,0]
 FR BND1      z[8,7,1]
 FR BND1      z[8,7,2]
 FR BND1      z[8,7,3]
 FR BND1      z[8,7,4]
 FR BND1      z[8,7,5]
 FR BND1      z[8,7,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
 FR BND1      delta[8,0]
 FR BND1      delta[8,1]
 FR BND1      delta[8,2]
 FR BND1      delta[8,3]
 FR BND1      delta[8,4]
 FR BND1      delta[8,5]
 FR BND1      delta[8,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
QCMATRIX   qc8     
    length[8]  length[8]  -1
    delta[8,0]  delta[8,0]  1
    delta[8,1]  delta[8,1]  1
    delta[8,2]  delta[8,2]  1
    delta[8,3]  delta[8,3]  1
    delta[8,4]  delta[8,4]  1
    delta[8,5]  delta[8,5]  1
    delta[8,6]  delta[8,6]  1
ENDATA
