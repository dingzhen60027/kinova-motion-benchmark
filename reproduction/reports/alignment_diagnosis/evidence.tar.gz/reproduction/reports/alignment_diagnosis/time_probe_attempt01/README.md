# 保留的首轮诊断失败

CPU 求解的 12 项均成功，但汇总代码使用 `status == "success"`，而既有案例实际状态为 `success_numerical`，因此严格有效子集被误判为空，生成 NaN 汇总并触发 NumPy warning。

此目录保留当时的脚本、JSON 和完整日志，不能作为最终汇总使用。上一级最终脚本改为匹配真实状态，并以 `allow_nan=False` 写出最终 JSON。没有修改任何原始案例或实验判定。
